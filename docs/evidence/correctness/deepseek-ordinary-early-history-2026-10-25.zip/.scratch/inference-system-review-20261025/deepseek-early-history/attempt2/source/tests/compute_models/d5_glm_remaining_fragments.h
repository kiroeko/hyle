#pragma once

#include "d5_kimi_remaining_fragments.h"
#include "d5_glm_mtp_head_test.h"
#include "d5_dynamic_fp8_fragments.h"
#include "d5_grouped_fp8_fragments.h"

// Model consumers, not product kernels. Native ggml storage and the exact
// source formulas are fixed by d5_glm_remaining_facts.json and the D5 card.
namespace d5_glm_remaining_fragments {
namespace c = hyle::compute;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace core = d5_moe_semantic_fragments;
namespace linear = d5_kda_full_fragments;
namespace moe = d5_moe_execution_fragments;
namespace kimi = d5_kimi_remaining_fragments;
using sem::Fragment;
using sem::ValueId;
using sem::bytes;
using sem::dense;
using core::reshape;
using core::binary;
using core::unary;
using core::filled;
using linear::Storage;

struct MixedProjection final {
  ValueId output;
  std::function<std::vector<float>(std::span<const float>)> reference;
};
inline MixedProjection projection(Fragment &f, ValueId input, std::int64_t n,
                                   std::int64_t k, int seed, bool fp8,
                                   Storage plain = Storage::kQ8_0, bool fp8_fma = true) {
  if (fp8) {
    auto value = d5_dynamic_fp8_fragments::model_linear(f, input, n, k, seed);
    value.fused_scale_accumulation = fp8_fma;
    const auto output = value.output;
    return {output, [value = std::move(value)](auto x) { return value.reference(x); }};
  }
  auto value = linear::projection(f, input, n, k, plain, seed);
  const auto output = value.output;
  return {output, [value = std::move(value)](auto x) { return value.reference(x); }};
}

struct Case final {
  const c::ModelArtifactProfileDescription *profile;
  std::int64_t hidden, query_rank;
  bool flash, official;
  bool fp8_fma = true;
};
inline constexpr std::array kCases{
    Case{&core::profiles::glm53_official, 6144, 2048, false, true},
    Case{&core::profiles::glm53_primary_gguf, 6144, 2048, false, false},
    Case{&core::profiles::glm53_fidelity_gguf, 6144, 2048, false, false},
    Case{&core::profiles::glm53_flash_official, 4096, 1536, true, true},
    Case{&core::profiles::glm53_flash_primary_gguf, 4096, 1536, true, false},
    Case{&core::profiles::glm53_flash_fidelity_gguf, 4096, 1536, true, false}};
// MLX Safe compilation and CPU ATen use separately rounded multiply/add nodes. This is
// one whole-fixture oracle policy, fixed before execution, never selected by
// comparing outputs. CUDA's original FMA policy remains the default.
inline constexpr auto kUnfusedFp8Cases = [] {
  auto cases = kCases;
  for (auto &model : cases) model.fp8_fma = false;
  return cases;
}();
inline constexpr std::int64_t kHeads = 64, kLatent = 512, kValue = 256;
inline constexpr float kNormEpsilon = 1.0e-5F;

inline ValueId permute(Fragment &f, ValueId value,
                       std::initializer_list<std::int32_t> axes) {
  return f.one(c::Operation(c::View::permute({axes.begin(), axes.size()}).value()),
               {value});
}
inline ValueId reduce(Fragment &f, ValueId value, std::int32_t axis,
                      c::ReductionKind kind = c::ReductionKind::kSum) {
  return f.one(c::Operation(c::Reduce{
      .kind = kind, .axes = c::Axes::from(std::span(&axis, 1)).value(),
      .accumulation_type = c::DataType::kFloat32}), {value});
}

// Attach an existing model recipe to actual upstream values. This only maps
// public operation descriptions; execution stays with each native route.
inline std::vector<ValueId> attach(Fragment &f, Fragment child,
                                   std::initializer_list<ValueId> inputs) {
  if (inputs.size() != child.inputs.size())
    throw std::runtime_error("model fragment input count mismatch");
  std::vector<ValueId> mapped(child.descriptions.size());
  if (child.preparation) {
    if (f.preparation) throw std::runtime_error("duplicate model weight preparation");
    f.preparation = std::move(child.preparation);
    for (auto slot : child.prepared_constants)
      f.prepared_constants.push_back(f.constants.size() + slot);
  }
  std::size_t i = 0;
  for (auto input : inputs) mapped[child.inputs[i++].ordinal()] = input;
  for (i = 0; i < child.constants.size(); ++i) {
    auto id = child.constants[i];
    mapped[id.ordinal()] = f.constant(child.description(id), std::move(child.constant_bytes[i]));
  }
  for (auto node : child.nodes) {
    for (auto &input : node.inputs) input = mapped[input.ordinal()];
    for (auto &output : node.outputs) {
      auto value = f.value(child.description(output), sem::ValueKind::kNodeOutput);
      mapped[output.ordinal()] = value;
      output = value;
    }
    f.nodes.push_back(std::move(node));
  }
  std::vector<ValueId> outputs;
  for (auto output : child.outputs) outputs.push_back(mapped[output.ordinal()]);
  return outputs;
}

// GLM Flash mHC explicitly calls fn.float(): weights retain their exact BF16
// values but the input is F32. Do not insert an extra BF16 activation boundary.
inline linear::Projection mhc_projection(Fragment &f, ValueId input, bool official) {
  if (!official)
    return linear::projection(f, input, 24, 16384, Storage::kQ8_0, 233);
  auto weight = sem::weight(24, 16384, c::GgufQuantizedType::kQ8_0, true, 233);
  std::vector<sem::q::BF16> encoded(weight.storage.size() / sizeof(float));
  for (std::size_t i = 0; i < encoded.size(); ++i) {
    float value;
    std::memcpy(&value, weight.storage.data() + i * sizeof(float), sizeof(float));
    encoded[i] = sem::q::encode(value);
  }
  for (auto &row : weight.decoded)
    for (auto &[column, value] : row) value = linear::bf16(value);
  auto stored = f.constant(dense({24, 16384}, c::DataType::kBFloat16), bytes(encoded));
  auto fp32 = f.one(c::Operation(c::Cast{c::DataType::kFloat32}), {stored});
  auto output = f.one(c::Operation(c::MatMul{}), {input, permute(f, fp32, {1, 0})});
  return {std::move(weight), Storage::kF32, output};
}

inline ValueId norm(Fragment &f, ValueId x, std::vector<float> &scales,
                     bool bfloat = false) {
  auto weight = linear::parameter(f, dense({std::int64_t(scales.size())}),
                                   scales, bfloat);
  return f.one(c::Operation(c::RmsNorm{.epsilon = kNormEpsilon}), {x, weight});
}

inline Fragment dense_ffn(const Case &model) {
  Fragment f{.profile = model.profile, .region = 0x02030801, .quantized = !model.official};
  auto x = f.input(dense({1, model.hidden}));
  auto scales = sem::oracle::scale(model.hidden);
  auto normalized = norm(f, x, scales, model.official);
  auto g = projection(f, normalized, 12288, model.hidden, 173, model.official, Storage::kQ8_0, model.fp8_fma);
  auto u = projection(f, normalized, 12288, model.hidden, 179, model.official, Storage::kQ8_0, model.fp8_fma);
  const auto &moe_model = moe::cases::kCases[model.flash ? 11 : 8];
  auto gated = moe::gated(f, moe_model, g.output, u.output);
  auto down = projection(f, gated, model.hidden, 12288, 181, model.official, Storage::kQ8_0, model.fp8_fma);
  auto residual = binary(f, c::BinaryKind::kAdd, x, down.output);
  f.outputs = {normalized, g.output, u.output, gated, down.output, residual};
  if (model.official) f.bfloat_chain_outputs = {1, 2, 3, 4, 5};
  for (int seed : {3, 17, 29}) {
    auto input = d5_gguf_test::activation(model.hidden, seed);
    auto nx = sem::oracle::rms_norm_rows(input, scales, model.hidden, kNormEpsilon);
    auto gv = g.reference(nx), uv = u.reference(nx);
    auto av = moe::gate_reference(moe_model, gv, uv);
    auto dv = down.reference(av), result = dv;
    for (std::size_t i = 0; i < result.size(); ++i) result[i] += input[i];
    f.replays.push_back({{bytes(input)}, {nx, gv, uv, av, dv, result}});
  }
  return f;
}

// Independent NextN input boundary. The decoder attention/MoE and final head
// still require their own complete-chain receipts; this is not a whole MTP.
using InputReference = std::function<moe::ReferenceOutputs(
    std::span<const float>, std::span<const float>)>;
inline Fragment mtp_input(const Case &model, InputReference *reference = nullptr,
                           bool normalize_output = true) {
  Fragment f{.profile = model.profile, .region = 0x0d030801,
             .quantized = !model.official};
  auto hidden = f.input(dense({1, model.hidden}));
  auto embedding = f.input(dense({1, model.hidden}));
  auto hs = sem::oracle::scale(model.hidden), es = hs;
  std::reverse(es.begin(), es.end());
  for (std::size_t i = 0; i < es.size(); ++i) es[i] += float(i % 3) * 0.0037F;
  auto hn = norm(f, hidden, hs, model.official);
  auto en = norm(f, embedding, es, model.official);
  // glm-dsa.cpp uses [normalized token embedding, normalized hidden].
  // The pinned converter preserves the EH columns; do not swap the halves.
  auto joined = f.one(c::Operation(c::Concat{.axis = 1}), {en, hn});
  auto eh = linear::projection(f, joined, model.hidden, 2 * model.hidden,
      model.official ? Storage::kBFloat16 : Storage::kQ8_0, 193);
  auto ns = sem::oracle::scale(model.hidden);
  f.outputs = {hn, en, joined, eh.output};
  if (normalize_output) f.outputs.push_back(norm(f, eh.output, ns, model.official));
  if (model.official) f.bfloat_chain_outputs = {3, 4};
  auto evaluate = [model, hs, es, ns, eh = std::move(eh)](
      std::span<const float> h, std::span<const float> e) -> moe::ReferenceOutputs {
    auto hv = sem::oracle::rms_norm_rows(h, hs, model.hidden, kNormEpsilon);
    auto ev = sem::oracle::rms_norm_rows(e, es, model.hidden, kNormEpsilon);
    auto j = ev; j.insert(j.end(), hv.begin(), hv.end());
    auto projected = eh.reference(j);
    auto expected = sem::oracle::rms_norm_rows(projected, ns, model.hidden, kNormEpsilon);
    return {std::move(hv), std::move(ev), std::move(j), std::move(projected), std::move(expected)};
  };
  if (reference) {
    *reference = std::move(evaluate);
    return f;
  }
  for (int seed : {5, 23, 37}) {
    auto h = d5_gguf_test::activation(model.hidden, seed);
    auto e = d5_gguf_test::activation(model.hidden, seed + 7);
    f.replays.push_back({{bytes(h), bytes(e)}, evaluate(h, e)});
  }
  return f;
}

inline Fragment hyper_connection(const Case &model) {
  if (!model.flash) throw std::runtime_error("GLM DSA has no mHC streams");
  Fragment f{.profile = model.profile, .region = 0x0c030801,
             .quantized = !model.official};
  auto residual = f.input(dense({1, 4, model.hidden}));
  auto branch = f.input(dense({1, model.hidden}));
  auto flat = reshape(f, residual, {1, 4 * model.hidden});
  auto ones = filled(f, dense({4 * model.hidden}), 1.0F);
  auto normalized = f.one(c::Operation(c::RmsNorm{.epsilon = kNormEpsilon}),
                          {flat, ones});
  auto fn = mhc_projection(f, normalized, model.official);
  auto core_outputs = attach(f, core::hyper_connection({model.profile, model.hidden}),
                            {fn.output, residual, branch});
  auto mean = reduce(f, core_outputs[2], 1, c::ReductionKind::kMean);
  auto final_scale = sem::oracle::scale(model.hidden);
  auto final = norm(f, mean, final_scale, model.official);
  f.outputs = {core_outputs[2], normalized, fn.output, core_outputs[0],
               core_outputs[1], mean, final};
  f.state_ports = {{0, 0}};
  std::vector<float> scales{0.125F, 0.25F, 0.5F}, bases(24);
  for (int i = 0; i < 24; ++i) bases[i] = float(i % 7 - 3) / 8.0F;
  auto state = d5_gguf_test::values(4, model.hidden, 31);
  const std::vector<float> unweighted(4 * model.hidden, 1.0F);
  for (int seed : {3, 17, 29, 41}) {
    auto b = d5_gguf_test::activation(model.hidden, seed);
    auto nv = sem::oracle::rms_norm_rows(state, unweighted, 4 * model.hidden, kNormEpsilon);
    auto projected = fn.reference(nv);
    auto core_values = core::hyper_reference(projected, state, b, model.hidden, scales, bases);
    std::vector<float> mv(model.hidden);
    for (std::int64_t d = 0; d < model.hidden; ++d) {
      double sum = 0;
      for (int s = 0; s < 4; ++s) sum += core_values[2][s * model.hidden + d];
      mv[d] = float(sum / 4.0);
    }
    auto fv = sem::oracle::rms_norm_rows(mv, final_scale, model.hidden, kNormEpsilon);
    f.replays.push_back({{bytes(state), bytes(b)},
                         {core_values[2], nv, projected, core_values[0], core_values[1], mv, fv}});
    state = std::move(core_values[2]);
  }
  return f;
}

struct HeadProjection final {
  sem::Weight weight;
  std::int64_t n, k;
  ValueId output;
  bool bfloat = false;
  std::vector<float> reference(std::span<const float> x) const {
    std::vector<std::int32_t> ids(kHeads);
    std::iota(ids.begin(), ids.end(), 0);
    if (!bfloat) return moe::project(x, weight, ids, n, k);
    std::vector<float> rounded(x.begin(), x.end());
    for (auto &value : rounded) value = linear::bf16(value);
    auto result = moe::project(rounded, weight, ids, n, k);
    for (auto &value : result) value = linear::bf16(value);
    return result;
  }
};
inline HeadProjection apply_head_projection(Fragment &f, ValueId x, sem::Weight w,
    ValueId weight, std::int64_t n, std::int64_t k, bool bfloat) {
  std::vector<std::int32_t> ids(kHeads);
  std::iota(ids.begin(), ids.end(), 0);
  auto heads = f.constant(dense({1, kHeads}, c::DataType::kInt32), bytes(ids));
  const auto round = [&](ValueId value) {
    value = f.one(c::Operation(c::Cast{c::DataType::kBFloat16}), {value});
    return f.one(c::Operation(c::Cast{c::DataType::kFloat32}), {value});
  };
  if (bfloat) x = round(x);
  auto output = f.one(c::model_ops::grouped_matmul(), {weight, x, heads});
  if (bfloat) output = round(output);
  return {std::move(w), n, k, output, bfloat};
}
inline HeadProjection head_projection(Fragment &f, ValueId x,
                                       std::int64_t n, std::int64_t k, int seed, bool bfloat = false) {
  auto w = moe::weight(kHeads, n, k, bfloat ? moe::Storage::kBFloat16 : moe::Storage::kQ8_0, seed);
  const auto weight = f.constant(w.description, std::move(w.storage));
  return apply_head_projection(f, x, std::move(w), weight, n, k, bfloat);
}

struct PreparedKv final { sem::Weight key, value; ValueId keys, values; };
inline PreparedKv prepare_kv(Fragment &consumer) {
  constexpr std::int64_t nope = 192, width = nope + kValue, n = kHeads * width;
  auto cold = std::make_shared<Fragment>(Fragment{
      .profile = consumer.profile, .region = 0x0e030801});
  const auto encoded = c::float8_weight_description(kLatent, n,
      c::Float8ScaleMode::kFloat32Block128).value();
  std::vector<std::byte> storage(encoded.required_bytes().value());
  sem::Weight key{dense({kHeads, kLatent, nope}, c::DataType::kBFloat16), {},
      std::vector<std::vector<std::pair<std::size_t, float>>>(kHeads * kLatent)};
  sem::Weight value{dense({kHeads, kValue, kLatent}, c::DataType::kBFloat16), {},
      std::vector<std::vector<std::pair<std::size_t, float>>>(kHeads * kValue)};
  std::vector<float> key_expected(kHeads * kLatent * nope), value_expected(kHeads * kValue * kLatent);
  // A single real block128 kv_b payload supplies both absorbed projections.
  // The independent sparse oracle is never uploaded as a cached weight.
  for (std::int64_t block = 0; block < n / 128; ++block)
    for (std::int64_t group = 0; group < kLatent / 128; ++group) {
      const float scale = float(17 + (block * 3 + group + 223) % 11) / 1024.0F;
      std::memcpy(storage.data() + n * kLatent + (block * 4 + group) * 4, &scale, 4);
    }
  for (std::int64_t row = 0; row < n; ++row)
    for (int term = 0; term < 2; ++term) {
      const auto col = (row * 17 + 223 + term * 269) % kLatent;
      const auto code = std::size_t((row + term * 3) % 8);
      storage[row * kLatent + col] = std::byte{d5_official_fp8_fragments::kCodes[code]};
      const float scale = float(17 + ((row / 128) * 3 + col / 128 + 223) % 11) / 1024.0F;
      const float coefficient = linear::bf16(d5_official_fp8_fragments::kValues[code] * scale);
      const auto head = row / width, within = row % width;
      if (within < nope) {
        key.decoded[head * kLatent + col].emplace_back(std::size_t(within), coefficient);
        key_expected[(head * kLatent + col) * nope + within] = coefficient;
      } else {
        value.decoded[head * kValue + within - nope].emplace_back(std::size_t(col), coefficient);
        value_expected[(head * kValue + within - nope) * kLatent + col] = coefficient;
      }
    }
  auto w = cold->constant(encoded, std::move(storage));
  auto decoded = cold->one(c::model_ops::float8_weight_decode(), {w});
  auto heads = reshape(*cold, decoded, {kHeads, width, kLatent});
  auto key_slice = cold->one(c::Operation(c::View::slice(1, 0, nope).value()), {heads});
  auto value_slice = cold->one(c::Operation(c::View::slice(1, nope, kValue).value()), {heads});
  cold->outputs = {
      cold->one(c::Operation(c::Copy{}), {permute(*cold, key_slice, {0, 2, 1})}),
      cold->one(c::Operation(c::Copy{}), {value_slice})};
  cold->replays.push_back({{}, {std::move(key_expected), std::move(value_expected)}});
  const auto first_slot = consumer.constants.size();
  auto keys = consumer.constant(key.description, {});
  auto values = consumer.constant(value.description, {});
  consumer.preparation = std::move(cold);
  consumer.prepared_constants = {first_slot, first_slot + 1};
  return {std::move(key), std::move(value), keys, values};
}

inline void rotate_pairs(std::vector<float> &x, std::span<const float> cosine,
                     std::span<const float> sine) {
  for (std::size_t row = 0; row < x.size() / 64; ++row)
    for (std::size_t p = 0; p < 32; ++p) {
      const auto i = row * 64 + 2 * p;
      const double a = x[i], b = x[i + 1];
      x[i] = float(a * cosine[p] - b * sine[p]);
      x[i + 1] = float(a * sine[p] + b * cosine[p]);
    }
}

inline Fragment official_flash_clamped_activation() {
  namespace dynamic = d5_dynamic_fp8_fragments;
  Fragment f{.profile = &core::profiles::glm53_flash_official, .region = 0x02030802};
  auto input = f.input(dense({2, 128}, c::DataType::kBFloat16));
  f.outputs = {dynamic::visible(f, dynamic::glm_gated(f, input, true), true)};
  constexpr std::array values{-32.0F, -12.0F, -10.0F, -0.0F, 9.5F, 10.0F, 10.5F, 32.0F};
  for (int seed : {0, 1}) {
    std::vector<float> x(256), expected(128);
    for (int row = 0; row < 2; ++row) for (int col = 0; col < 64; ++col) {
      const float gate = values[(col + seed + row) % values.size()];
      const float up = values[(col * 3 + seed + row + 2) % values.size()];
      x[row * 128 + col] = gate; x[row * 128 + 64 + col] = up;
      const double a = std::min(double(gate), 10.0), b = std::clamp(double(up), -10.0, 10.0);
      expected[row * 64 + col] = dynamic::bfloat(float(a / (1 + std::exp(-a)) * b));
    }
    f.replays.push_back({{dynamic::input_bytes(x, true)}, {std::move(expected)}});
  }
  dynamic::strict_output_check(f, true, 1);
  return f;
}

inline std::vector<float> layer_norm(std::span<const float> input,
                                     std::span<const float> scale,
                                     std::span<const float> bias) {
  double mean = 0, variance = 0;
  for (auto v : input) mean += v;
  mean /= double(input.size());
  for (auto v : input) variance += (v - mean) * (v - mean);
  const double inverse = 1.0 / std::sqrt(variance / double(input.size()) + 1.0e-6);
  std::vector<float> output(input.size());
  for (std::size_t i = 0; i < input.size(); ++i)
    output[i] = float((input[i] - mean) * inverse * scale[i] + bias[i]);
  return output;
}

// Decode DSA at its actual 32x128 indexer boundary. The cache exceeds top-2048;
// Flash has 513 complete K4 pools (top-512), left padding, and 0..3 tail tokens.
// Only positions/validity are host model policy. Projections, learned pooling,
// scoring, TopK and expansion all execute through mature route operations.
inline Fragment indexer(const Case &model, std::int64_t tail = 0,
                         bool quantized_scores = false,
                         bool reverse_history = false) {
  if (tail < 0 || tail > 3 || (!model.flash && tail))
    throw std::runtime_error("invalid GLM pool tail fixture");
  constexpr std::int64_t heads = 32, depth = 128, padding = 2, pools = 513;
  const std::int64_t count = padding + 2052 + tail, history_count = count - 1;
  const auto storage = model.official ? Storage::kBFloat16 : Storage::kQ8_0;
  Fragment f{.profile = model.profile, .region = 0x08030801 + std::uint64_t(tail),
             .quantized = !model.official};
  auto x = f.input(dense({1, model.hidden}));
  auto q_resid = f.input(dense({1, model.query_rank}));
  auto past_key = f.input(dense({history_count, depth}));
  ValueId past_gate{}, positions{};
  if (model.flash) past_gate = f.input(dense({history_count, depth}));
  else positions = f.input(dense({1}, c::DataType::kInt32));
  auto wq = projection(f, q_resid, heads * depth, model.query_rank, 239, model.official && !model.flash, storage, model.fp8_fma);
  auto wk = projection(f, x, depth, model.hidden, 241, model.official && !model.flash, storage, model.fp8_fma);
  const auto score_storage = model.official ? Storage::kBFloat16
      : quantized_scores ? Storage::kQ8_0 : Storage::kF32;
  auto ws = linear::projection(f, x, heads, model.hidden, score_storage, 251);
  auto scales = sem::oracle::scale(depth);
  std::vector<float> bias(depth);
  for (std::int64_t d = 0; d < depth; ++d) bias[d] = float(d % 7 - 3) / 32.0F;
  auto scale = linear::parameter(f, dense({depth}), scales, model.official);
  auto offset = linear::parameter(f, dense({depth}), bias, model.official);
  auto key = f.one(c::Operation(c::LayerNorm{.epsilon = 1.0e-6F}), {wk.output, scale, offset});
  auto query = reshape(f, wq.output, {1, heads, depth});
  std::vector<float> frequencies(32);
  if (!model.flash) {
    for (int p = 0; p < 32; ++p) frequencies[p] = float(1.0 / std::pow(8000000.0, double(p) / 32));
    auto frequency = f.constant(dense({32}), bytes(frequencies));
    auto qp = kimi::slice_heads(f, query, heads, depth, 0, 64);
    auto kp = kimi::slice_heads(f, key, 1, depth, 0, 64);
    c::Operation rope(c::RoPE{.rotary_dimensions = 64, .sequence_axis = 1,
                              .layout = c::RopeLayout::kInterleaved});
    qp = reshape(f, f.one(rope, {reshape(f, qp, {1, 1, heads, 64}), positions, frequency}), {1, heads, 64});
    kp = reshape(f, f.one(rope, {reshape(f, kp, {1, 1, 1, 64}), positions, frequency}), {1, 1, 64});
    query = f.one(c::Operation(c::Concat{.axis = 2}),
        {qp, kimi::slice_heads(f, query, heads, depth, 64, 64)});
    key = reshape(f, f.one(c::Operation(c::Concat{.axis = 2}),
        {kp, kimi::slice_heads(f, key, 1, depth, 64, 64)}), {1, depth});
  }
  auto cache = f.one(c::Operation(c::Concat{.axis = 0}), {past_key, key});
  std::vector<std::int32_t> next_ids;
  for (std::int32_t t = 0; t < count; ++t) if (t != padding) next_ids.push_back(t);
  auto next_index = f.constant(dense({history_count}, c::DataType::kInt32), bytes(next_ids));
  auto next_cache = f.one(c::Operation(c::Gather{}), {cache, next_index});
  auto keys = cache;
  linear::Projection wg{};
  ValueId next_gates{}, pool_index{};
  std::vector<float> ape(4 * depth);
  std::vector<std::int32_t> pool_ids(pools * 4);
  if (model.flash) {
    wg = linear::projection(f, x, depth, model.hidden, storage, 257);
    auto gates = f.one(c::Operation(c::Concat{.axis = 0}), {past_gate, wg.output});
    next_gates = f.one(c::Operation(c::Gather{}), {gates, next_index});
    for (std::int32_t i = 0; i < pools * 4; ++i) pool_ids[i] = std::int32_t(padding) + i;
    pool_index = f.constant(dense({pools, 4}, c::DataType::kInt32), bytes(pool_ids));
    auto grouped_key = f.one(c::Operation(c::Gather{}), {cache, pool_index});
    auto grouped_gate = f.one(c::Operation(c::Gather{}), {gates, pool_index});
    for (std::size_t i = 0; i < ape.size(); ++i) ape[i] = float(int(i * 7 % 19) - 9) / 16.0F;
    auto pos_bias = linear::parameter(f, dense({1, 4, depth}), ape, model.official);
    auto logits = binary(f, c::BinaryKind::kAdd, grouped_gate, pos_bias);
    // ggml Softmax consumes contiguous rows. Put the four pool tokens last,
    // materialize that native layout, and restore the logical key layout.
    auto transposed = f.one(c::Operation(c::Copy{}), {permute(f, logits, {0, 2, 1})});
    auto probabilities = f.one(c::Operation(c::Softmax{}),
        {reshape(f, transposed, {pools * depth, 4})});
    probabilities = f.one(c::Operation(c::Copy{}),
        {permute(f, reshape(f, probabilities, {pools, depth, 4}), {0, 2, 1})});
    keys = reduce(f, binary(f, c::BinaryKind::kMultiply, probabilities, grouped_key), 1);
  }
  const auto candidates = model.flash ? pools : count;
  auto dot = f.one(c::Operation(c::MatMul{}),
      {reshape(f, query, {heads, depth}), permute(f, keys, {1, 0})});
  dot = binary(f, c::BinaryKind::kMultiply, dot,
               filled(f, dense({1}), 1.0F / std::sqrt(float(depth))));
  dot = f.one(c::model_ops::clamp(0.0F, std::numeric_limits<float>::max()), {dot});
  auto weights = binary(f, c::BinaryKind::kMultiply, ws.output,
                        filled(f, dense({1}), 1.0F / std::sqrt(float(heads))));
  auto scores = reshape(f, reduce(f, binary(f, c::BinaryKind::kMultiply,
      reshape(f, weights, {heads, 1}), dot), 0), {1, candidates});
  if (!model.flash) {
    std::vector<float> mask(count);
    std::fill_n(mask.begin(), padding, -1.0e9F);
    scores = binary(f, c::BinaryKind::kAdd, scores,
                     f.constant(dense({1, count}), bytes(mask)));
  }
  const std::size_t top_count = model.flash ? 512 : 2048;
  auto selected = f.append(c::Operation(c::TopK{.count = top_count}), {scores}, 2);
  auto ids = selected[1];
  if (model.flash) {
    ids = reshape(f, f.one(c::Operation(c::Gather{}), {pool_index, ids}), {1, 2048});
    std::vector<std::int32_t> tail_ids(3, -1);
    for (int i = 0; i < tail; ++i) tail_ids[i] = std::int32_t(padding + 2052 + i);
    ids = f.one(c::Operation(c::Concat{.axis = 1}),
                {ids, f.constant(dense({1, 3}, c::DataType::kInt32), bytes(tail_ids))});
  }
  // Diagnostic Q/K publications own storage; their reshape aliases remain
  // internal to the model program and are not separately rebound by Graph.
  auto query_check = f.one(c::Operation(c::Copy{}), {query});
  auto key_check = f.one(c::Operation(c::Copy{}), {key});
  auto score_check = f.one(c::Operation(c::Copy{}), {scores});
  f.outputs = {next_cache, query_check, key_check, weights, keys, score_check, ids};
  if (model.official && !model.flash) f.bfloat_chain_outputs = {0, 1, 2, 4, 5};
  f.state_ports = {{2, 0}};
  if (model.flash) { f.outputs.push_back(next_gates); f.state_ports.push_back({3, 7}); }
  f.unordered_ids = Fragment::UnorderedIds{6, model.flash ? 2051U : 2048U,
                                         count, true, model.flash};
  std::vector<float> past(history_count * depth), gate_history(past.size());
  for (std::int64_t t = padding; t < history_count; ++t)
    for (std::int64_t d = 0; d < depth; ++d) {
      const auto age = reverse_history ? history_count - 1 - t : t - padding;
      past[t * depth + d] = (0.125F + float(age) / 8.0F) *
                            (0.5F + float(d % 11) / 32.0F);
      gate_history[t * depth + d] = float((t * 7 + d * 11) % 29 - 14) / 8.0F;
    }
  for (int step = 0; step < 4; ++step) {
    auto input = d5_gguf_test::activation(model.hidden, 5 + step * 14);
    auto qr = d5_gguf_test::activation(model.query_rank, 11 + step * 14);
    for (auto &value : input) value = std::abs(value) + 0.5F;
    for (auto &value : qr) value = std::abs(value) + 0.5F;
    sem::Replay replay{{bytes(input), bytes(qr), bytes(past)}, {}};
    auto qv = wq.reference(qr), projected_key = wk.reference(input);
    auto kv = layer_norm(projected_key, scales, bias);
    auto wv = ws.reference(input);
    for (auto &value : wv) value *= 1.0F / std::sqrt(float(heads));
    if (!model.flash) {
      const std::int32_t position = 2061 + step;
      replay.inputs.push_back(bytes(std::vector<std::int32_t>{position}));
      std::vector<float> cs(32), sn(32);
      for (int p = 0; p < 32; ++p) {
        cs[p] = float(std::cos(double(position) * frequencies[p]));
        sn[p] = float(std::sin(double(position) * frequencies[p]));
      }
      auto qp = kimi::slice(qv, heads, depth, 0, 64), kp = kimi::slice(kv, 1, depth, 0, 64);
      rotate_pairs(qp, cs, sn); rotate_pairs(kp, cs, sn);
      for (int h = 0; h < heads; ++h)
        std::copy_n(qp.begin() + h * 64, 64, qv.begin() + h * depth);
      std::copy(kp.begin(), kp.end(), kv.begin());
    }
    auto full = past; full.insert(full.end(), kv.begin(), kv.end());
    auto pool_keys = full;
    std::vector<float> next_gate_values;
    if (model.flash) {
      replay.inputs.push_back(bytes(gate_history));
      auto gv = wg.reference(input);
      auto full_gates = gate_history; full_gates.insert(full_gates.end(), gv.begin(), gv.end());
      pool_keys.assign(pools * depth, 0.0F);
      for (std::int64_t p = 0; p < pools; ++p)
        for (std::int64_t d = 0; d < depth; ++d) {
          std::array<double, 4> probability{};
          double maximum = -INFINITY, sum = 0;
          for (int k = 0; k < 4; ++k) {
            probability[k] = full_gates[(padding + p * 4 + k) * depth + d] + ape[k * depth + d];
            maximum = std::max(maximum, probability[k]);
          }
          for (auto &value : probability) sum += value = std::exp(value - maximum);
          double value = 0;
          for (int k = 0; k < 4; ++k)
            value += probability[k] / sum * full[(padding + p * 4 + k) * depth + d];
          pool_keys[p * depth + d] = float(value);
        }
      for (auto index : next_ids)
        next_gate_values.insert(next_gate_values.end(), full_gates.begin() + index * depth,
                               full_gates.begin() + (index + 1) * depth);
    }
    std::vector<float> index_scores(candidates), half_product_scores(candidates);
    const auto half = [](float value) {
      return half_test::decode(half_test::encode<hyle::simd::float16_t>(value));
    };
    const bool native_half_products = model.flash && model.official;
    std::vector<double> half_query, half_keys;
    if (native_half_products) {
      half_query.reserve(qv.size());
      half_keys.reserve(pool_keys.size());
      for (auto value : qv) half_query.push_back(half(value));
      for (auto value : pool_keys) half_keys.push_back(half(value));
    }
    for (std::int64_t t = 0; t < candidates; ++t) {
      double sum = 0, half_sum = 0;
      for (int h = 0; h < heads; ++h) {
        double dot_value = 0, half_dot = 0;
        for (int d = 0; d < depth; ++d) {
          dot_value += double(qv[h * depth + d]) * pool_keys[t * depth + d];
          if (native_half_products)
            half_dot += half_query[h * depth + d] * half_keys[t * depth + d];
        }
        sum += wv[h] * std::max(0.0, dot_value / std::sqrt(double(depth)));
        half_sum += wv[h] * std::max(0.0, half_dot / std::sqrt(double(depth)));
      }
      index_scores[t] = float(sum) + ((!model.flash && t < padding) ? -1.0e9F : 0.0F);
      half_product_scores[t] = float(half_sum);
    }
    std::vector<std::int32_t> order(candidates);
    std::iota(order.begin(), order.end(), 0);
    std::stable_sort(order.begin(), order.end(), [&](auto a, auto b) {
      return index_scores[a] > index_scores[b];
    });
    std::vector<float> selected_ids;
    for (std::size_t i = 0; i < top_count; ++i) {
      if (model.flash) for (int j = 0; j < 4; ++j) selected_ids.push_back(float(pool_ids[order[i] * 4 + j]));
      else selected_ids.push_back(float(order[i]));
    }
    if (model.flash) for (int i = 0; i < 3; ++i)
      selected_ids.push_back(i < tail ? float(padding + 2052 + i) : -1.0F);
    past.clear();
    for (auto index : next_ids)
      past.insert(past.end(), full.begin() + index * depth, full.begin() + (index + 1) * depth);
    replay.outputs = {past, qv, kv, wv, pool_keys, index_scores, selected_ids};
    if (model.flash) { replay.outputs.push_back(next_gate_values); gate_history = std::move(next_gate_values); }
    if (native_half_products) {
      // The pinned ggml Vulkan coopmat2 MatMul converts both F32 operands to
      // F16, independently of its F32 accumulation setting. Check only that
      // score boundary against the independent rounded oracle AND the existing
      // full-F32 accuracy gate. Cache, pooling and exact TopK members stay strict.
      replay.native_outputs.resize(replay.outputs.size());
      replay.native_outputs[5] = std::move(half_product_scores);
    }
    f.replays.push_back(std::move(replay));
  }
  return f;
}

// Exact ggml absorbed-MLA program. DSA selection is a separate shared region;
// this cache consumer validates native projection, RoPE and actual feedback.
using MlaReference = std::function<moe::ReferenceOutputs(
    std::span<const float>, std::span<const float>, std::int32_t)>;
inline Fragment mla(const Case &model, MlaReference *reference = nullptr) {
  const std::int64_t rotary = model.flash ? 0 : 64;
  const auto no_pe = 256 - rotary, cached_width = kLatent + rotary;
  Fragment f{.profile = model.profile, .region = 0x07030801, .quantized = !model.official};
  auto x = f.input(dense({1, model.hidden}));
  auto history = f.input(dense({3, cached_width}));
  ValueId positions{}, frequencies{};
  std::vector<float> frequency_values(32);
  if (rotary) {
    positions = f.input(dense({1}, c::DataType::kInt32));
    for (std::size_t p = 0; p < frequency_values.size(); ++p)
      frequency_values[p] = float(1.0 / std::pow(8000000.0, double(p) / 32.0));
    frequencies = f.constant(dense({32}), bytes(frequency_values));
  }
  auto input_scale = sem::oracle::scale(model.hidden);
  auto nx = norm(f, x, input_scale, model.official);
  auto qa = projection(f, nx, model.query_rank, model.hidden, 197, model.official, Storage::kQ8_0, model.fp8_fma);
  auto qscale = sem::oracle::scale(model.query_rank);
  auto qr = norm(f, qa.output, qscale, model.official);
  auto qb = projection(f, qr, kHeads * 256, model.query_rank, 199, model.official, Storage::kQ8_0, model.fp8_fma);
  auto kva = projection(f, nx, cached_width, model.hidden, 211, model.official, Storage::kQ8_0, model.fp8_fma);
  auto latent = reshape(f, core::rows(f, reshape(f, kva.output, {cached_width, 1}), 0, kLatent), {1, kLatent});
  auto kvscale = sem::oracle::scale(kLatent);
  latent = norm(f, latent, kvscale, model.official);
  auto query_nope = kimi::slice_heads(f, qb.output, kHeads, 256, 0, no_pe);
  std::optional<PreparedKv> prepared;
  if (model.official && !model.flash) prepared = prepare_kv(f);
  auto kb = prepared
      ? apply_head_projection(f, query_nope, std::move(prepared->key), prepared->keys, kLatent, no_pe, true)
      : head_projection(f, query_nope, kLatent, no_pe, 223, model.official);
  auto query = kb.output, current = latent;
  if (rotary) {
    auto qp = kimi::slice_heads(f, qb.output, kHeads, 256, no_pe, rotary);
    auto kp = reshape(f, core::rows(f, reshape(f, kva.output, {cached_width, 1}), kLatent, rotary), {1, 1, rotary});
    const c::Operation rope(c::RoPE{.rotary_dimensions = 64, .sequence_axis = 1,
                                    .layout = c::RopeLayout::kInterleaved});
    qp = reshape(f, f.one(rope, {reshape(f, qp, {1, 1, kHeads, 64}), positions, frequencies}), {1, kHeads, 64});
    kp = reshape(f, f.one(rope, {reshape(f, kp, {1, 1, 1, 64}), positions, frequencies}), {1, 1, 64});
    query = f.one(c::Operation(c::Concat{.axis = 2}), {query, qp});
    current = f.one(c::Operation(c::Concat{.axis = 1}),
                     {latent, reshape(f, kp, {1, rotary})});
  }
  auto cache = f.one(c::Operation(c::Concat{.axis = 0}), {history, current});
  auto next_cache = core::rows(f, cache, 1, 3);
  auto cv = kimi::slice_heads(f, cache, 4, cached_width, 0, kLatent);
  auto attention = f.one(c::Operation(c::ScaledDotProductAttention{
      .scale = 1.0F / 16.0F, .causal = true,
      .accumulation_type = c::DataType::kFloat32}),
      {reshape(f, query, {1, 1, kHeads, cached_width}),
       reshape(f, cache, {1, 4, 1, cached_width}), reshape(f, cv, {1, 4, 1, kLatent})});
  auto attended = reshape(f, attention, {1, kHeads, kLatent});
  auto vb = prepared
      ? apply_head_projection(f, attended, std::move(prepared->value), prepared->values, kValue, kLatent, true)
      : head_projection(f, attended, kValue, kLatent, 227, model.official);
  auto out = projection(f, reshape(f, vb.output, {1, kHeads * kValue}),
                         model.hidden, kHeads * kValue, 229, model.official, Storage::kQ8_0, model.fp8_fma);
  f.outputs = {next_cache, qb.output, query, attention, vb.output, out.output};
  if (model.official) f.bfloat_chain_outputs = {0, 1, 2, 3, 4, 5};
  f.state_ports = {{1, 0}};
  auto evaluate = [model, rotary, no_pe, cached_width, input_scale, qscale,
      kvscale, frequency_values, qa = std::move(qa), qb = std::move(qb),
      kva = std::move(kva), kb = std::move(kb), vb = std::move(vb), out = std::move(out)](
      std::span<const float> input, std::span<const float> history,
      std::int32_t position) -> moe::ReferenceOutputs {
    auto xv = sem::oracle::rms_norm_rows(input, input_scale, model.hidden, kNormEpsilon);
    auto av = qa.reference(xv);
    av = sem::oracle::rms_norm_rows(av, qscale, model.query_rank, kNormEpsilon);
    auto qv = qb.reference(av), kv = kva.reference(xv);
    auto lv = sem::oracle::rms_norm_rows(std::span(kv).first(kLatent), kvscale, kLatent, kNormEpsilon);
    auto qn = kimi::slice(qv, kHeads, 256, 0, no_pe);
    auto absorbed = kb.reference(qn);
    if (rotary) {
      std::vector<float> cs(32), sn(32);
      for (std::size_t p = 0; p < cs.size(); ++p) {
        const double angle = double(position) * frequency_values[p];
        cs[p] = float(std::cos(angle)); sn[p] = float(std::sin(angle));
      }
      auto qp = kimi::slice(qv, kHeads, 256, no_pe, 64);
      std::vector<float> kp(kv.begin() + kLatent, kv.end());
      rotate_pairs(qp, cs, sn); rotate_pairs(kp, cs, sn);
      lv.insert(lv.end(), kp.begin(), kp.end());
      std::vector<float> joined;
      for (std::int64_t h = 0; h < kHeads; ++h) {
        joined.insert(joined.end(), absorbed.begin() + h * kLatent, absorbed.begin() + (h + 1) * kLatent);
        joined.insert(joined.end(), qp.begin() + h * 64, qp.begin() + (h + 1) * 64);
      }
      absorbed = std::move(joined);
    }
    std::vector<float> full(history.begin(), history.end());
    full.insert(full.end(), lv.begin(), lv.end());
    std::vector<float> past(full.begin() + cached_width, full.end());
    std::vector<float> attended(kHeads * kLatent);
    for (std::int64_t h = 0; h < kHeads; ++h) {
      std::array<double, 4> score{};
      for (int t = 0; t < 4; ++t)
        for (std::int64_t d = 0; d < cached_width; ++d)
          score[t] += double(absorbed[h * cached_width + d]) * full[t * cached_width + d] / 16.0;
      const double largest = *std::max_element(score.begin(), score.end());
      double total = 0;
      for (auto &value : score) total += value = std::exp(value - largest);
      for (std::int64_t d = 0; d < kLatent; ++d) {
        double sum = 0;
        for (int t = 0; t < 4; ++t) sum += score[t] / total * full[t * cached_width + d];
        attended[h * kLatent + d] = float(sum);
      }
    }
    auto projected = vb.reference(attended);
    return {std::move(past), std::move(qv), std::move(absorbed), std::move(attended),
             projected, out.reference(projected)};
  };
  if (reference) {
    *reference = std::move(evaluate);
    return f;
  }
  auto past = d5_gguf_test::activation(3 * cached_width, 31);
  for (int step = 0; step < 4; ++step) {
    auto input = d5_gguf_test::activation(model.hidden, 3 + 14 * step);
    sem::Replay replay{{bytes(input), bytes(past)}, evaluate(input, past, 13 + step)};
    if (rotary) replay.inputs.push_back(bytes(std::vector<std::int32_t>{13 + step}));
    past = replay.outputs[0];
    f.replays.push_back(std::move(replay));
  }
  return f;
}
// NextN is a separate decoder: unlike the Flash trunk it has ordinary
// attention/FFN residuals and no mHC tensors. Its normalized hidden and MLA
// cache are actual recurrent ports. Vocabulary/head and sparse-index carry
// qualification remain separate, explicit consumers of these boundaries.
inline Fragment mtp_decoder(const Case &model) {
  const auto found = std::ranges::find_if(moe::cases::kCases,
      [&](const auto &candidate) { return candidate.profile == model.profile; });
  if (found == moe::cases::kCases.end())
    throw std::runtime_error("NextN MoE profile missing");
  InputReference input_reference;
  MlaReference attention_reference;
  moe::MoeReference feed_forward_reference;
  auto input_recipe = mtp_input(model, &input_reference, false);
  auto attention_recipe = mla(model, &attention_reference);
  // Normalized decoder activations have unit scale. A 0.5 synthetic router
  // coefficient avoids the saturation produced by the standalone fixture's
  // gain64, whose deliberately small input has a different scale.
  auto moe_recipe = model.official
      ? d5_grouped_fp8_fragments::glm_moe(model.flash, &feed_forward_reference, 0.5F)
      : moe::moe_chain(*found, false, false, &feed_forward_reference, 0.5F);
  const auto moe_output = model.official ? 7u : 5u;
  const auto cached_width = kLatent + (model.flash ? 0 : 64);
  Fragment f{.profile = model.profile, .region = 0x0d030802, .quantized = !model.official};
  auto hidden = f.input(dense({1, model.hidden}));
  auto embedding = f.input(dense({1, model.hidden}));
  auto history = f.input(dense({3, cached_width}));
  ValueId position{};
  if (!model.flash) position = f.input(dense({1}, c::DataType::kInt32));
  auto eh = attach(f, std::move(input_recipe), {hidden, embedding})[3];
  auto attention = model.flash
      ? attach(f, std::move(attention_recipe), {eh, history})
      : attach(f, std::move(attention_recipe), {eh, history, position});
  auto residual = binary(f, c::BinaryKind::kAdd, eh, attention[5]);
  auto ffn_scale = sem::oracle::scale(model.hidden);
  auto ffn_input = norm(f, residual, ffn_scale, model.official);
  auto feed_forward = attach(f, std::move(moe_recipe), {ffn_input});
  auto combined = binary(f, c::BinaryKind::kAdd, residual,
      reshape(f, feed_forward[moe_output], {1, model.hidden}));
  auto head_scale = sem::oracle::scale(model.hidden);
  std::reverse(head_scale.begin(), head_scale.end());
  auto next_hidden = norm(f, combined, head_scale, model.official);
  // Quantized upstream projections may swap the order of two selected experts
  // without changing their membership. Canonicalize only diagnostic ports so
  // weights are compared by expert ID; the actual MoE retains its native order.
  auto ordered = f.append(c::Operation(c::TopK{
      .count = std::size_t(found->top_k), .largest = false}),
      {reshape(f, feed_forward[0], {1, found->top_k})}, 2);
  auto ordered_weights = f.one(c::Operation(c::Gather{}),
      {reshape(f, feed_forward[1], {found->top_k, 1}), ordered[1]});
  f.outputs = {next_hidden, attention[0], eh, attention[5], ffn_input,
               feed_forward[moe_output], ordered[0], ordered_weights};
  if (model.official) f.bfloat_chain_outputs = {0, 1, 2, 3, 4, 5, 7};
  f.exact_outputs = {6};
  f.state_ports = {{0, 0}, {2, 1}};
  auto hidden_values = d5_gguf_test::activation(model.hidden, 5);
  auto past = d5_gguf_test::activation(3 * cached_width, 31);
  for (int step = 0; step < 4; ++step) {
    auto token = d5_gguf_test::activation(model.hidden, 12 + 14 * step);
    sem::Replay replay{{bytes(hidden_values), bytes(token), bytes(past)}, {}};
    const std::int32_t pos = 13 + step;
    if (!model.flash) replay.inputs.push_back(bytes(std::vector<std::int32_t>{pos}));
    auto input_values = input_reference(hidden_values, token);
    auto av = attention_reference(input_values[3], past, pos);
    std::vector<float> rv(model.hidden);
    for (std::size_t d = 0; d < rv.size(); ++d)
      rv[d] = input_values[3][d] + av[5][d];
    auto normalized = sem::oracle::rms_norm_rows(rv, ffn_scale, model.hidden, kNormEpsilon);
    auto mv = feed_forward_reference(normalized);
    std::vector<std::size_t> order(mv[0].size());
    std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(), [&](auto a, auto b) { return mv[0][a] < mv[0][b]; });
    auto ids = mv[0], weights = mv[1];
    for (std::size_t i = 0; i < order.size(); ++i) {
      ids[i] = mv[0][order[i]];
      weights[i] = mv[1][order[i]];
    }
    for (std::size_t d = 0; d < rv.size(); ++d) rv[d] += mv[moe_output][d];
    hidden_values = sem::oracle::rms_norm_rows(rv, head_scale, model.hidden, kNormEpsilon);
    past = av[0];
    replay.outputs = {hidden_values, past, std::move(input_values[3]), std::move(av[5]),
        std::move(normalized), std::move(mv[moe_output]), std::move(ids), std::move(weights)};
    f.replays.push_back(std::move(replay));
  }
  return f;
}
inline std::vector<float> attention_reference(
    std::span<const float> q, std::span<const float> cache,
    std::span<const float> selected_ids, std::int64_t selected, std::int64_t width) {
  const auto tokens = static_cast<std::int64_t>(cache.size()) / width;
  std::vector<float> expected(kHeads * kLatent);
  for (std::int64_t h = 0; h < kHeads; ++h) {
    std::vector<double> scores(selected);
    for (std::int64_t t = 0; t < selected; ++t) {
      const auto row = std::int64_t(selected_ids[t]);
      if (row < 0 || row >= tokens) throw std::runtime_error("invalid DSA reference row");
      for (std::int64_t d = 0; d < width; ++d)
        scores[t] += double(q[h * width + d]) * cache[row * width + d] / 16.0;
    }
    const double largest = *std::max_element(scores.begin(), scores.end());
    double total = 0;
    for (auto &score : scores) total += score = std::exp(score - largest);
    for (std::int64_t d = 0; d < kLatent; ++d) {
      double value = 0;
      for (std::int64_t t = 0; t < selected; ++t)
        value += scores[t] / total * cache[std::int64_t(selected_ids[t]) * width + d];
      expected[h * kLatent + d] = float(value);
    }
  }
  return expected;
}
// Connect actual DSA-selected token IDs to the compressed MLA cache. Projection
// outputs are explicit fragment ports; no host readback selects the rows.
inline Fragment sparse_attention(const Case &model, std::int64_t tail = 0) {
  auto f = indexer(model, tail);
  f.region = 0x07080310 + std::uint64_t(tail);
  const auto width = kLatent + (model.flash ? 0 : 64);
  const std::int64_t tokens = 2054 + tail, selected = 2048 + tail;
  const auto past_port = f.inputs.size() + 1;
  auto query = f.input(dense({1, 1, kHeads, width}));
  auto history = f.input(dense({tokens - 1, width}));
  auto current = f.input(dense({1, width}));
  auto full = f.one(c::Operation(c::Concat{.axis = 0}), {history, current});
  auto ids = f.outputs[6];
  if (model.flash) {
    // Tail length is known model metadata. Remove the -1 padding by a public
    // view/copy before checked Gather; never silently treat -1 as row zero.
    ids = reshape(f, core::rows(f, reshape(f, ids, {2051, 1}), 0, selected), {selected});
  } else ids = reshape(f, ids, {selected});
  auto chosen = f.one(c::Operation(c::Gather{}), {full, ids});
  auto values = kimi::slice_heads(f, chosen, selected, width, 0, kLatent);
  auto attention = f.one(c::Operation(c::ScaledDotProductAttention{
      // One decode query attends all already-selected past/current entries;
      // the right-aligned causal mask contains no future entries to remove.
      .scale = 1.0F / 16.0F, .causal = true,
      .accumulation_type = c::DataType::kFloat32}),
      {query, reshape(f, chosen, {1, selected, 1, width}),
       reshape(f, values, {1, selected, 1, kLatent})});
  std::vector<std::int32_t> retained;
  for (std::int32_t t = 0; t < tokens; ++t) if (t != 2) retained.push_back(t);
  auto retain_ids = f.constant(dense({tokens - 1}, c::DataType::kInt32), bytes(retained));
  auto next = f.one(c::Operation(c::Gather{}), {full, retain_ids});
  const auto next_port = f.outputs.size();
  f.outputs.push_back(next);
  f.outputs.push_back(attention);
  f.state_ports.push_back({past_port, next_port});
  f.exact_outputs.push_back(next_port);
  auto past = d5_gguf_test::activation((tokens - 1) * width, 31);
  for (std::size_t step = 0; step < f.replays.size(); ++step) {
    auto &replay = f.replays[step];
    auto q = d5_gguf_test::activation(kHeads * width, 101 + int(step) * 14);
    auto kv = d5_gguf_test::activation(width, 113 + int(step) * 14);
    replay.inputs.push_back(bytes(q));
    replay.inputs.push_back(bytes(past));
    replay.inputs.push_back(bytes(kv));
    auto cache = past;
    cache.insert(cache.end(), kv.begin(), kv.end());
    const auto &selected_ids = replay.outputs[6];
    auto expected = attention_reference(q, cache, selected_ids, selected, width);
    past.clear();
    for (auto row : retained)
      past.insert(past.end(), cache.begin() + row * width, cache.begin() + (row + 1) * width);
    replay.outputs.push_back(past);
    replay.outputs.push_back(std::move(expected));
  }
  return f;
}
inline std::array<moe::cases::Case, 4> mixed_expert_variants() {
  // All-layer header triples are recorded in d5_glm_expert_variants.json.
  // Common Q4/Q4/Q5 and all-Q8 chains already run in the shared MoE batch.
  auto ordinary = moe::cases::kCases[8], flash = moe::cases::kCases[11];
  ordinary.down = flash.down = moe::cases::Storage::kQ6K;
  auto ordinary_high = ordinary, flash_high = flash;
  ordinary_high.gate = ordinary_high.up = moe::cases::Storage::kQ5K;
  flash_high.gate = flash_high.up = moe::cases::Storage::kQ5K;
  return {ordinary, ordinary_high, flash, flash_high};
}

// Cross the declared staging boundary using real decoder outputs. The head's
// oracle instead receives the independently evolved decoder trajectory.
template <class Run> void check_mtp_head(const Case &model, Run run) {
  auto fragment = mtp_decoder(model);
  std::vector<std::vector<float>> observed, reference;
  for (const auto &replay : fragment.replays) reference.push_back(replay.outputs[0]);
  fragment.observe = [&](std::size_t port, std::span<const float> values) {
    if (port == 0) observed.emplace_back(values.begin(), values.end());
  };
  run(std::move(fragment));
  ASSERT_FALSE(::testing::Test::HasFatalFailure());
  ASSERT_EQ(observed.size(), reference.size());
  const auto found = std::ranges::find_if(core::profiles::kVocabulary,
      [&](const auto &candidate) { return candidate.profile == model.profile; });
  ASSERT_NE(found, core::profiles::kVocabulary.end());
  ASSERT_EQ(found->vocabulary_rows, 154880);
  d5_glm_mtp_test::check_head(*found, observed, reference);
}

// The model consumer controls when a carried selection is invalidated. Each
// native invocation sees either a fresh I32 seed or its own preceding output;
// no indexer is executed during these reuse steps.
template <class Run> void check_index_carry(const Case &model, Run run) {
  for (int tail : {0, 3}) {
    if (!model.flash && tail) continue;
    SCOPED_TRACE(tail);
    std::array<std::vector<float>, 2> observed, reference;
    for (std::size_t iteration = 0; iteration < 2; ++iteration) {
      // A different context has a reversed initial history; both selections
      // come from the real indexer and are checked against its independent oracle.
      auto seed = indexer(model, tail, false, iteration != 0);
      seed.replays.resize(1);
      reference[iteration] = seed.replays[0].outputs[6];
      seed.observe = [&](std::size_t port, std::span<const float> values) {
        if (port == 6) observed[iteration].assign(values.begin(), values.end());
      };
      run(std::move(seed));
      ASSERT_FALSE(::testing::Test::HasFatalFailure());
      ASSERT_EQ(observed[iteration].size(), reference[iteration].size());
    }
    ASSERT_FALSE(std::is_permutation(reference[0].begin(), reference[0].end(),
                                    reference[1].begin(), reference[1].end()));
    const std::int64_t count = model.flash ? 2051 : 2048;
    const std::int64_t selected = 2048 + tail, tokens = 2054 + tail;
    const auto width = kLatent + (model.flash ? 0 : 64);
    Fragment f{.profile = model.profile, .region = 0x0d030820 + std::uint64_t(tail)};
    auto ids = f.input(dense({count}, c::DataType::kInt32));
    auto query = f.input(dense({1, 1, kHeads, width}));
    auto cache = f.input(dense({tokens, width}));
    std::vector<std::int32_t> all(count);
    std::iota(all.begin(), all.end(), 0);
    auto all_ids = f.constant(dense({count}, c::DataType::kInt32), bytes(all));
    auto carried = f.one(c::Operation(c::Gather{}), {ids, all_ids});
    auto valid = carried;
    if (count != selected)
      valid = reshape(f, core::rows(f, reshape(f, valid, {count, 1}), 0, selected), {selected});
    auto chosen = f.one(c::Operation(c::Gather{}), {cache, valid});
    auto values = kimi::slice_heads(f, chosen, selected, width, 0, kLatent);
    auto attention = f.one(c::Operation(c::ScaledDotProductAttention{
        .scale = 1.0F / 16.0F, .causal = true,
        .accumulation_type = c::DataType::kFloat32}),
        {query, reshape(f, chosen, {1, selected, 1, width}),
         reshape(f, values, {1, selected, 1, kLatent})});
    f.outputs = {carried, attention};
    f.state_ports = {{0, 0}};
    f.exact_outputs = {0};
    for (int step = 0; step < 4; ++step) {
      const auto iteration = static_cast<std::size_t>(step / 2);
      std::vector<std::int32_t> input(count, -1);
      if (step % 2 == 0)
        std::transform(observed[iteration].begin(), observed[iteration].end(),
                       input.begin(), [](float value) { return static_cast<std::int32_t>(value); });
      auto q = d5_gguf_test::activation(kHeads * width, 101 + step * 14);
      auto kv = d5_gguf_test::activation(tokens * width, 113 + step * 14);
      for (auto &value : q) value /= 4;
      for (auto &value : kv) value *= 4;
      sem::Replay replay{{bytes(input), bytes(q), bytes(kv)},
          {observed[iteration], attention_reference(q, kv, reference[iteration], selected, width)}};
      replay.reset_state = step == 2;
      f.replays.push_back(std::move(replay));
    }
    run(std::move(f));
    ASSERT_FALSE(::testing::Test::HasFatalFailure());
  }
}
} // namespace d5_glm_remaining_fragments
