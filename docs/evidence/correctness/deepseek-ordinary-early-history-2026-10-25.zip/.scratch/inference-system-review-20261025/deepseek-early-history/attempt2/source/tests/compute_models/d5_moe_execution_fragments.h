#pragma once

#include <numeric>
#include <limits>
#include <functional>

#include "d5_moe_execution_cases.h"
#include "d5_moe_semantic_fragments.h"
#include "d5_official_fp4_storage.h"

// Model consumer recipes and independent numerical oracles, never product math.
namespace d5_moe_execution_fragments {
namespace c = hyle::compute;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace core = d5_moe_semantic_fragments;
namespace cases = d5_moe_execution_cases;
using cases::Case;
using cases::Storage;
using sem::bytes;
using sem::dense;
using sem::Fragment;
using sem::ValueId;
using core::binary;
using core::filled;
using core::reshape;
using core::unary;

inline ValueId bound(Fragment &f, ValueId input, float limit, bool upper) {
  const auto infinity = std::numeric_limits<float>::infinity();
  return f.one(c::model_ops::clamp(upper ? -infinity : limit,
                                  upper ? limit : infinity), {input});
}

inline Fragment clamp_boundaries() {
  Fragment f{.profile = cases::kCases[0].profile, .region = 0x0a0603};
  const auto inf = std::numeric_limits<float>::infinity();
  std::vector<float> x{-inf, -11, -10, -0.25F, 0.25F, 10, 11, inf};
  auto input = f.input(dense({1, 2, 2, 2}));
  f.outputs = {f.one(c::model_ops::clamp(-10, 10), {input})};
  f.exact_outputs = {0};
  for (int replay = 0; replay < 2; ++replay) {
    std::vector<float> expected;
    for (float value : x)
      expected.push_back(std::clamp(value, -10.0F, 10.0F));
    f.replays.push_back({{bytes(x)}, {std::move(expected)}});
    std::reverse(x.begin(), x.end());
  }
  return f;
}

inline ValueId sum(Fragment &f, ValueId input, std::int32_t axis) {
  return f.one(c::Operation(c::Reduce{
                   .kind = c::ReductionKind::kSum,
                   .axes = c::Axes::from(std::array{axis}).value(),
                   .keep_dimensions = true,
                   .accumulation_type = c::DataType::kFloat32}), {input});
}
inline ValueId gathered_ids(Fragment &f, const Case &model, ValueId ids) {
  std::vector<float> tags(model.experts);
  std::iota(tags.begin(), tags.end(), 0.0F);
  auto stored = f.constant(dense({model.experts, 1}), bytes(tags));
  return f.one(c::Operation(c::Gather{}), {stored, ids});
}

struct Routing final { ValueId ids, weights; };
struct HashInputs final { ValueId tokens, table; };
inline constexpr std::int64_t kHashVocabulary = 129280;

inline Routing hash_routing(Fragment &f, ValueId logits, HashInputs lookup,
                             bool native, float scaling) {
  ValueId ids, weights;
  if (native) {
    auto outputs = f.append(c::model_ops::sqrt_softplus_hash_routing(),
                            {logits, lookup.tokens, lookup.table}, 2);
    weights = outputs[0];
    ids = outputs[1];
  } else {
    // Single-token model consumer: preserve the table's I32 payload and order.
    // No score sorting, bias, float conversion of IDs, or host selection.
    const auto shape = f.description(logits).dimensions();
    if (shape[0] != 1)
      throw std::runtime_error("portable hash recipe requires one token");
    const auto experts = shape[1];
    ids = f.one(c::Operation(c::Gather{}), {lookup.table, lookup.tokens});
    auto rows = reshape(f, logits, {experts, 1});
    auto selected = reshape(f, f.one(c::Operation(c::Gather{}), {rows, ids}), {1, 6});
    auto scores = unary(f, c::UnaryKind::kSqrt,
                         unary(f, c::UnaryKind::kSoftplus, selected));
    auto denominator = sum(f, scores, -1);
    weights = binary(f, c::BinaryKind::kDivide, scores, denominator);
  }
  const auto weight_desc = f.description(weights);
  weights = binary(f, c::BinaryKind::kMultiply, weights,
                    filled(f, weight_desc, scaling));
  return {ids, weights};
}

inline std::vector<std::int32_t> hash_table(std::int64_t experts, int replay) {
  std::vector<std::int32_t> result(kHashVocabulary * 6);
  for (std::int64_t token = 0; token < kHashVocabulary; ++token)
    for (std::int64_t slot = 0; slot < 6; ++slot)
      result[token * 6 + slot] = std::int32_t((token * 3 + slot * 2 + replay) % experts);
  return result;
}
inline std::vector<std::byte> hash_tokens(std::span<const std::int64_t> tokens,
                                          bool native) {
  if (native) return bytes(tokens);
  std::vector<std::int32_t> portable;
  portable.reserve(tokens.size());
  for (auto token : tokens) {
    if (token < std::numeric_limits<std::int32_t>::min() ||
        token > std::numeric_limits<std::int32_t>::max())
      throw std::runtime_error("portable hash fixture token exceeds I32");
    portable.push_back(static_cast<std::int32_t>(token));
  }
  return bytes(portable);
}

inline Routing routing(Fragment &f, const Case &model, ValueId input,
                        bool native_routing = false, float router_gain = 64.0F,
                        std::optional<HashInputs> lookup = std::nullopt) {
  const auto resident = model.top_k + 1;
  auto desc = dense({model.experts, model.hidden}, model.router_bf16
                    ? c::DataType::kBFloat16 : c::DataType::kFloat32);
  std::vector<std::byte> storage(desc.required_bytes().value());
  for (std::int64_t e = 0; e < resident; ++e) {
    const auto offset = e * model.hidden + e;
    if (model.router_bf16) {
      const auto value = sem::q::encode(router_gain);
      std::memcpy(storage.data() + offset * sizeof(value), &value, sizeof(value));
    } else {
      const float value = router_gain;
      std::memcpy(storage.data() + offset * sizeof(value), &value, sizeof(value));
    }
  }
  ValueId logits;
  if (model.router_bf16) {
    auto x = f.one(c::Operation(c::Cast{c::DataType::kBFloat16}), {input});
    auto weight = f.constant(desc, std::move(storage));
    logits = f.one(c::model_ops::dense_linear_f32(), {x, weight});
  } else {
    auto weight = f.constant(desc.transposed().value(), std::move(storage));
    logits = f.one(c::Operation(c::MatMul{}), {input, weight});
  }
  if (lookup)
    return hash_routing(f, logits, *lookup, native_routing, model.scaling);
  std::vector<float> bias(model.experts, -4.0F);
  for (std::int64_t e = 0; e < resident; ++e)
    bias[e] = float(e % 3 - 1) / 16.0F;
  if (model.sqrt_softplus)
    for (auto &value : bias)
      value = float(sem::q::decode(sem::q::encode(value)));
  if (model.sqrt_softplus && native_routing) {
    auto correction = f.constant(dense({model.experts}), bytes(bias));
    auto outputs = f.append(c::model_ops::sqrt_softplus_routing(model.scaling),
                            {logits, correction}, 2);
    return {outputs[1], outputs[0]};
  }
  auto scores = model.sqrt_softplus
      ? unary(f, c::UnaryKind::kSqrt, unary(f, c::UnaryKind::kSoftplus, logits))
      : unary(f, c::UnaryKind::kSigmoid, logits);
  auto correction = f.constant(dense({1, model.experts}), bytes(bias));
  auto selection = binary(f, c::BinaryKind::kAdd, scores, correction);
  auto top = f.append(c::Operation(c::TopK{.count = std::size_t(model.top_k)}),
                       {selection}, 2);
  // TopK guarantees each ID is in this score row's expert extent. Select
  // directly, retaining T*K values instead of a T*T*K Cartesian intermediate.
  auto selected=f.one(c::model_ops::gather_elements(-1,c::IndexBoundsPolicy::kUnchecked),
                       {scores,top[1]});
  auto total = sum(f, selected, -1);
  // Sqrt-softplus uses the exact divide-by-sum formula, including 0/0.
  // The separate sigmoid model recipes retain their own normalization floor.
  if (!model.sqrt_softplus) total = bound(f, total, 6.103515625e-5F, false);
  auto normalized = binary(f, c::BinaryKind::kDivide, selected, total);
  normalized = binary(f, c::BinaryKind::kMultiply, normalized,
                       filled(f, dense({1, model.top_k}), model.scaling));
  return {top[1], normalized};
}

inline std::vector<float> activation(const Case &model, int replay) {
  auto values = d5_gguf_test::activation(model.hidden, 3 + 14 * replay);
  // BF16-representable common input for both F32 and BF16 router weights.
  // Keep the FFN activation scale balanced. The router's 64x weight creates
  // the selected logits, rather than synthetic 3-5 outliers among 0.06 values.
  // Those outliers triggered the native Q8 activation quantizer (retained
  // diagnostic evidence), not a routing or weight-format disagreement.
  for (auto &v : values)
    v = float(sem::q::decode(sem::q::encode(v)));
  for (std::int64_t e = 0; e <= model.top_k; ++e)
    values[e] = (2.0F + float(replay == 1 ? model.top_k - e : e) / 8.0F) / 64.0F;
  if (replay == 2)
    values[0] = 5.0F / 64.0F;
  return values;
}
// Independent host oracle: retain the declared F32 softplus and sqrt
// boundaries before normalization; double exp/sqrt are not native helpers.
inline float sqrt_softplus_reference(float value) {
  const double wide = value;
  const float exponential = float(std::exp(-std::abs(wide)));
  const float logarithm = float(std::log1p(double(exponential)));
  const float softplus = float(std::max(wide, 0.0) + double(logarithm));
  return float(std::sqrt(double(softplus)));
}
struct RouteReference final {
  std::vector<std::int32_t> ids;
  std::vector<float> scores, weights, tags;
};
inline RouteReference route_reference(const Case &model,
                                       std::span<const float> input,
                                       float router_gain = 64.0F,
                                       std::span<const std::int32_t> hash_ids = {}) {
  RouteReference r;
  r.scores.resize(model.experts);
  r.ids.resize(model.experts);
  std::iota(r.ids.begin(), r.ids.end(), 0);
  std::vector<double> selection(model.experts);
  for (std::int64_t e = 0; e < model.experts; ++e) {
    const double logit = e <= model.top_k ? double(input[e]) * router_gain : 0;
    const double score = model.sqrt_softplus ? sqrt_softplus_reference(float(logit))
                                             : core::sigmoid(logit);
    r.scores[e] = float(score);
    selection[e] = score + (e <= model.top_k ? double(e % 3 - 1) / 16.0 : -4.0);
  }
  if (hash_ids.empty()) {
    std::stable_sort(r.ids.begin(), r.ids.end(), [&](auto a, auto b) {
      return selection[a] > selection[b];
    });
    r.ids.resize(model.top_k);
  } else {
    r.ids.assign(hash_ids.begin(), hash_ids.end());
  }
  double denominator = 0;
  for (auto id : r.ids)
    denominator += r.scores[id];
  for (auto id : r.ids) {
    r.weights.push_back(float(r.scores[id] / denominator * model.scaling));
    r.tags.push_back(float(id));
  }
  return r;
}
inline Fragment router(const Case &model, bool native_routing = false) {
  Fragment f{.profile = model.profile, .region = 0x0a0601};
  auto input = f.input(dense({1, model.hidden}));
  auto route = routing(f, model, input, native_routing);
  f.outputs = {gathered_ids(f, model, route.ids), route.weights};
  f.exact_outputs = {0};
  for (int replay = 0; replay < 3; ++replay) {
    auto x = activation(model, replay);
    auto reference = route_reference(model, x);
    f.replays.push_back({{bytes(x)}, {std::move(reference.tags),
                                    std::move(reference.weights)}});
  }
  return f;
}

inline Fragment hash_router(const Case &model, bool native_routing = false,
                              std::int64_t rows = 1, int mode = 0) {
  Fragment f{.profile = model.profile, .region = 0x0a0605};
  auto logits = f.input(dense({rows, model.experts}));
  auto tokens = f.input(dense({rows}, native_routing ? c::DataType::kInt64
                                                   : c::DataType::kInt32));
  auto table_input = f.input(dense({kHashVocabulary, 6}, c::DataType::kInt32));
  auto route = hash_routing(f, logits, {tokens, table_input}, native_routing,
                            model.scaling);
  f.outputs = {route.weights, route.ids};
  f.exact_outputs = {1};
  for (int replay = 0; replay != 3; ++replay) {
    auto table = hash_table(model.experts, replay);
    std::vector<std::int64_t> ids(rows);
    std::vector<float> x(rows * model.experts), weights(rows * 6), selected(rows * 6);
    for (std::int64_t row = 0; row < rows; ++row) {
      ids[row] = replay == 0 ? row % kHashVocabulary
                 : replay == 1 ? kHashVocabulary - 1 - row % kHashVocabulary
                               : (row * 13 + 37) % kHashVocabulary;
      // Duplicate expert IDs are a valid table payload, not a dedup request.
      if (mode == 4) table[ids[row] * 6 + 1] = table[ids[row] * 6];
      for (std::int64_t e = 0; e < model.experts; ++e)
        x[row * model.experts + e] = mode == 1 ? -100.0F + float(e % 7) / 8.0F
              : mode == 2 ? -1000.0F : mode == 3 ? 1000.0F + float(e)
              : float((e * 7 + row * 3 + replay * 11) % 81 - 40);
      std::array<float, 6> scores;
      double denominator = 0;
      for (std::size_t slot = 0; slot < 6; ++slot) {
        const auto expert = table[ids[row] * 6 + slot];
        selected[row * 6 + slot] = float(expert);
        scores[slot] = sqrt_softplus_reference(x[row * model.experts + expert]);
        denominator += scores[slot];
      }
      for (std::size_t slot = 0; slot < 6; ++slot)
        weights[row * 6 + slot] = float(scores[slot] / denominator * model.scaling);
    }
    f.replays.push_back({{bytes(x), hash_tokens(ids, native_routing), bytes(table)},
                          {std::move(weights), std::move(selected)}});
  }
  return f;
}

// The original CUDA program has two launch branches at T=512. Ties have
// intentionally unspecified membership, while non-ties retain exact IDs.
inline Fragment native_router_boundary(std::int64_t experts,
                                        std::int64_t tokens, int mode) {
  const auto &model = experts == 384 ? cases::kCases[3] : cases::kCases[4];
  Fragment f{.profile = model.profile, .region = 0x0a0604};
  auto logits = f.input(dense({tokens, experts}));
  std::vector<float> bias(experts, 0.0F);
  auto correction = f.constant(dense({experts}), bytes(bias));
  auto outputs = f.append(c::model_ops::sqrt_softplus_routing(model.scaling),
                          {logits, correction}, 2);
  f.outputs = {outputs[0], gathered_ids(f, model, outputs[1])};
  f.exact_outputs = {1};
  if (mode == 1 || mode == 2 || mode == 6)
    f.unordered_ids = Fragment::UnorderedIds{1, 6, experts};
  for (int replay = 0; replay < 2; ++replay) {
    std::vector<float> x(tokens * experts), weights(tokens * 6), tags(tokens * 6);
    for (std::int64_t row = 0; row < tokens; ++row) {
      std::vector<std::int32_t> selected(experts);
      std::iota(selected.begin(), selected.end(), 0);
      std::vector<double> scores(experts);
      for (std::int64_t e = 0; e < experts; ++e) {
        const auto index = replay == 0 ? e : experts - 1 - e;
        const auto value = mode == 1 ? 0.0F : mode == 2 ? -1000.0F
                         : mode == 3 ? std::numeric_limits<float>::quiet_NaN()
                         : mode == 4 ? -80.0F + float(index) / 512.0F
                         : mode == 5 ? 1.0F + float(index) / 65536.0F
                         : mode == 6 ? -100.0F
                         : float((index * 7 + row * 11) % 81 - 40) + float(index) / 512.0F;
        x[row * experts + e] = value;
        scores[e] = mode == 3 ? 0.0F : sqrt_softplus_reference(value);
      }
      std::stable_sort(selected.begin(), selected.end(), [&](auto a, auto b) {
        return scores[a] > scores[b];
      });
      double denominator = 0;
      for (std::size_t slot = 0; slot < 6; ++slot) denominator += scores[selected[slot]];
      for (std::size_t slot = 0; slot < 6; ++slot) {
        weights[row * 6 + slot] = float(scores[selected[slot]] / denominator * model.scaling);
        tags[row * 6 + slot] = mode == 3 ? 0.0F : float(selected[slot]);
      }
    }
    f.replays.push_back({{bytes(x)}, {std::move(weights), std::move(tags)}});
  }
  return f;
}

inline ValueId gated(Fragment &f, const Case &model, ValueId gate, ValueId up) {
  if (model.latent != model.hidden) {
    const auto desc = f.description(gate);
    auto a = unary(f, c::UnaryKind::kTanh,
                    binary(f, c::BinaryKind::kMultiply, gate, filled(f, desc, 0.25F)));
    a = binary(f, c::BinaryKind::kMultiply, a, filled(f, desc, 4.0F));
    a = binary(f, c::BinaryKind::kMultiply, a,
                unary(f, c::UnaryKind::kSigmoid, gate));
    auto b = unary(f, c::UnaryKind::kTanh,
                    binary(f, c::BinaryKind::kMultiply, up, filled(f, desc, 0.04F)));
    b = binary(f, c::BinaryKind::kMultiply, b, filled(f, desc, 25.0F));
    return binary(f, c::BinaryKind::kMultiply, a, b);
  }
  if (model.sqrt_softplus || model.profile->model_name == "GLM-5.3-Flash") {
    gate = bound(f, gate, 10.0F, true);
    up = bound(f, bound(f, up, -10.0F, false), 10.0F, true);
  }
  return f.one(c::Operation(c::GatedActivation{
                   .inputs = c::GatedInputKind::kSeparate}), {gate, up});
}
inline std::vector<float> gate_reference(const Case &model,
                                        std::span<const float> gate,
                                        std::span<const float> up) {
  std::vector<float> out(gate.size());
  for (std::size_t i = 0; i < out.size(); ++i) {
    double a = gate[i], b = up[i];
    if (model.latent != model.hidden)
      out[i] = float(4.0 * std::tanh(a / 4.0) * core::sigmoid(a) *
                     25.0 * std::tanh(b / 25.0));
    else {
      if (model.sqrt_softplus || model.profile->model_name == "GLM-5.3-Flash") {
        a = std::min(a, 10.0);
        b = std::clamp(b, -10.0, 10.0);
      }
      out[i] = float(a * core::sigmoid(a) * b);
    }
  }
  return out;
}
inline Fragment activation_core(const Case &model) {
  Fragment f{.profile = model.profile, .region = 0x020602};
  auto desc = dense({1, model.intermediate});
  auto a = f.input(desc), b = f.input(desc);
  f.outputs = {gated(f, model, a, b)};
  for (int seed : {3, 19}) {
    std::vector<float> x(model.intermediate), y(model.intermediate);
    for (std::int64_t i = 0; i < model.intermediate; ++i) {
      x[i] = float((i * 7 + seed) % 257 - 128) / 4.0F;
      y[i] = float((i * 13 + seed) % 257 - 128) / 2.0F;
    }
    f.replays.push_back({{bytes(x), bytes(y)}, {gate_reference(model, x, y)}});
  }
  return f;
}

inline c::GgufQuantizedType quantized_type(Storage storage) {
  switch (storage) {
  case Storage::kQ4K: return c::GgufQuantizedType::kQ4K;
  case Storage::kQ5K: return c::GgufQuantizedType::kQ5K;
  case Storage::kQ6K: return c::GgufQuantizedType::kQ6K;
  case Storage::kQ8_0: return c::GgufQuantizedType::kQ8_0;
  case Storage::kMxfp4: return c::GgufQuantizedType::kMxfp4;
  case Storage::kBFloat16: break;
  }
  throw std::runtime_error("BF16 has no quantized block identity");
}
inline sem::Weight weight(std::int64_t experts, std::int64_t n, std::int64_t k,
                           Storage storage, int seed) {
  if (storage != Storage::kBFloat16) {
    auto result = sem::weight(experts * n, k, quantized_type(storage), false, seed);
    result.description = c::gguf_grouped_weight_description(
        quantized_type(storage), c::DataType::kFloat32, experts, n, k).value();
    return result;
  }
  auto desc = dense({experts, n, k}, c::DataType::kBFloat16);
  sem::Weight result{desc, std::vector<std::byte>(desc.required_bytes().value()),
                     std::vector<std::vector<std::pair<std::size_t, float>>>(experts * n)};
  for (std::int64_t row = 0; row < experts * n; ++row) {
    const auto column = (17 * row + seed) % k;
    const auto value = sem::q::encode(0.5 + double((row + seed) % 13) / 32.0);
    std::memcpy(result.storage.data() + (row * k + column) * sizeof(value),
                 &value, sizeof(value));
    result.decoded[row].emplace_back(std::size_t(column), float(sem::q::decode(value)));
  }
  return result;
}
inline std::vector<float> project(std::span<const float> input,
                                  const sem::Weight &weight,
                                  std::span<const std::int32_t> ids,
                                  std::int64_t n, std::int64_t k) {
  std::vector<float> out(ids.size() * n);
  for (std::size_t slot = 0; slot < ids.size(); ++slot)
    for (std::int64_t row = 0; row < n; ++row) {
      double value = 0;
      for (auto [column, coefficient] : weight.decoded[ids[slot] * n + row])
        value += double(input[slot * k + column]) * coefficient;
      out[slot * n + row] = float(value);
    }
  return out;
}

inline Fragment official_fp4_projection(const Case &model, bool down) {
  if (model.gguf || (model.profile != cases::kCases[0].profile &&
                    model.profile != cases::kCases[3].profile &&
                    model.profile != cases::kCases[4].profile))
    throw std::runtime_error("profile has no audited official FP4 expert packing");
  Fragment f{.profile = model.profile, .region = 0x0b0602, .quantized = true};
  const auto n = down ? model.latent : model.intermediate;
  const auto k = down ? model.intermediate : model.latent;
  const auto resident = model.top_k + 1;
  auto w = d5_official_fp4_storage::weight(resident, n, k, down ? 83 : 71);
  auto stored = f.constant(w.description, std::move(w.storage));
  auto input = f.input(dense({1, model.top_k, k}));
  auto ids = f.input(dense({1, model.top_k}, c::DataType::kInt32));
  f.outputs = {f.one(c::model_ops::grouped_matmul(), {stored, input, ids})};
  for (int replay = 0; replay < 2; ++replay) {
    auto x = d5_gguf_test::activation(model.top_k * k, 17 + replay * 31);
    std::vector<std::int32_t> selected(model.top_k);
    for (std::int64_t slot = 0; slot < model.top_k; ++slot)
      selected[slot] = std::int32_t(replay ? resident - 1 - slot : slot);
    f.replays.push_back({{bytes(x), bytes(selected)}, {project(x, w, selected, n, k)}});
  }
  return f;
}

using ReferenceOutputs = std::vector<std::vector<float>>;
using MoeReference = std::function<ReferenceOutputs(std::span<const float>)>;

inline Fragment moe_chain(const Case &model, bool native_routing,
                            bool official_fp4, MoeReference *reference_out = nullptr,
                            float router_gain = 64.0F, bool use_hash = false) {
  if (!model.gguf && !(official_fp4 && model.profile == cases::kCases[0].profile))
    throw std::runtime_error("official expert packing is a separate qualification");
  if (use_hash && (!model.sqrt_softplus || reference_out))
    throw std::runtime_error("hash MoE requires its token/table replay oracle");
  Fragment f{.profile = model.profile, .region = use_hash ? 0x0a0b0602u : 0x0a0b0601u,
             .quantized = true};
  auto input = f.input(dense({1, model.hidden}));
  std::optional<HashInputs> lookup;
  if (use_hash)
    lookup = HashInputs{f.input(dense({1}, native_routing ? c::DataType::kInt64
                                                        : c::DataType::kInt32)),
                         f.input(dense({kHashVocabulary, 6}, c::DataType::kInt32))};
  auto route = routing(f, model, input, native_routing, router_gain, lookup);
  const auto resident = model.top_k + 1;
  const std::vector<std::int32_t> zero{0};
  auto zero_id = f.constant(dense({1, 1}, c::DataType::kInt32), bytes(zero));
  const auto grouped = [&](sem::Weight &w, ValueId x, ValueId ids) {
    auto stored = f.constant(w.description, std::move(w.storage));
    return f.one(c::model_ops::grouped_matmul(), {stored, x, ids});
  };
  std::optional<sem::Weight> latent_down, latent_up;
  auto routed_input = reshape(f, input, {1, 1, model.hidden});
  if (model.latent != model.hidden) {
    latent_down = weight(1, model.latent, model.hidden, model.latent_storage, 151);
    latent_up = weight(1, model.hidden, model.latent, model.latent_storage, 157);
    routed_input = grouped(*latent_down, routed_input, zero_id);
  }
  auto flat_input = reshape(f, routed_input, {1, model.latent});
  auto replicate = f.constant(dense({model.top_k}, c::DataType::kInt32),
                               bytes(std::vector<std::int32_t>(model.top_k, 0)));
  auto slots = reshape(f, f.one(c::Operation(c::Gather{}), {flat_input, replicate}),
                        {1, model.top_k, model.latent});
  const auto expert_weight = [&](std::int64_t n, std::int64_t k, Storage type, int seed) {
    return official_fp4 ? d5_official_fp4_storage::weight(resident, n, k, seed)
                         : weight(resident, n, k, type, seed);
  };
  auto wg = expert_weight(model.intermediate, model.latent, model.gate, 71);
  auto wu = expert_weight(model.intermediate, model.latent, model.up, 79);
  auto wd = expert_weight(model.latent, model.intermediate, model.down, 83);
  auto gate = grouped(wg, slots, route.ids), up = grouped(wu, slots, route.ids);
  auto activated = gated(f, model, gate, up);
  auto routed = grouped(wd, activated, route.ids);
  auto weights = reshape(f, route.weights, {1, model.top_k, 1});
  auto combined = sum(f, binary(f, c::BinaryKind::kMultiply, routed, weights), 1);
  std::vector<float> norm_values;
  if (latent_up) {
    norm_values = sem::oracle::scale(model.latent);
    auto scale = f.constant(dense({model.latent}), bytes(norm_values));
    combined = f.one(c::Operation(c::RmsNorm{.epsilon = 1.0e-5F}), {combined, scale});
    combined = grouped(*latent_up, combined, zero_id);
  }
  auto sg = weight(1, model.shared_intermediate, model.hidden, model.shared_gate, 113);
  auto su = weight(1, model.shared_intermediate, model.hidden, model.shared_up, 127);
  auto sd = weight(1, model.hidden, model.shared_intermediate, model.shared_down, 139);
  auto shared_input = reshape(f, input, {1, 1, model.hidden});
  auto shared_gate = grouped(sg, shared_input, zero_id);
  auto shared_up = grouped(su, shared_input, zero_id);
  auto shared_activated = gated(f, model, shared_gate, shared_up);
  auto shared = grouped(sd, shared_activated, zero_id);
  auto output = binary(f, c::BinaryKind::kAdd, combined, shared);
  f.outputs = {gathered_ids(f, model, route.ids), route.weights, routed, combined,
                shared, output, gate, up, activated,
                shared_gate, shared_up, shared_activated};
  f.exact_outputs = {0};
  auto evaluate = [model, router_gain, zero, norm_values,
      latent_down = std::move(latent_down), latent_up = std::move(latent_up),
      wg = std::move(wg), wu = std::move(wu), wd = std::move(wd),
      sg = std::move(sg), su = std::move(su), sd = std::move(sd)]
      (std::span<const float> x, std::span<const std::int32_t> hash_ids) -> ReferenceOutputs {
    auto reference = route_reference(model, x, router_gain, hash_ids);
    auto latent = latent_down ? project(x, *latent_down, zero, model.latent, model.hidden)
                              : std::vector<float>(x.begin(), x.end());
    std::vector<float> replicated;
    for (std::int64_t slot = 0; slot < model.top_k; ++slot)
      replicated.insert(replicated.end(), latent.begin(), latent.end());
    auto g = project(replicated, wg, reference.ids, model.intermediate, model.latent);
    auto u = project(replicated, wu, reference.ids, model.intermediate, model.latent);
    auto act = gate_reference(model, g, u);
    auto routed_value = project(act, wd, reference.ids,
                                model.latent, model.intermediate);
    std::vector<float> combined_value(model.latent);
    for (std::int64_t d = 0; d < model.latent; ++d) {
      double value = 0;
      for (std::int64_t slot = 0; slot < model.top_k; ++slot)
        value += routed_value[slot * model.latent + d] * double(reference.weights[slot]);
      combined_value[d] = float(value);
    }
    if (latent_up) {
      auto normalized = sem::oracle::rms_norm_rows(combined_value, norm_values,
                                                    model.latent, 1.0e-5F);
      combined_value = project(normalized, *latent_up, zero, model.hidden, model.latent);
    }
    auto sgate = project(x, sg, zero, model.shared_intermediate, model.hidden);
    auto sup = project(x, su, zero, model.shared_intermediate, model.hidden);
    auto sact = gate_reference(model, sgate, sup);
    auto shared_value = project(sact, sd, zero,
                                model.hidden, model.shared_intermediate);
    std::vector<float> full(model.hidden);
    for (std::int64_t d = 0; d < model.hidden; ++d)
      full[d] = combined_value[d] + shared_value[d];
    return {std::move(reference.tags),
        std::move(reference.weights), std::move(routed_value),
        std::move(combined_value), std::move(shared_value), std::move(full),
        std::move(g), std::move(u), std::move(act),
        std::move(sgate), std::move(sup), std::move(sact)};
  };
  if (reference_out) {
    *reference_out = [evaluate = std::move(evaluate)](std::span<const float> x) {
      return evaluate(x, {});
    };
    return f;
  }
  for (int replay = 0; replay < 3; ++replay) {
    auto x = activation(model, replay);
    if (use_hash) {
      const std::array<std::int64_t, 3> tokens{0, kHashVocabulary - 1, 37};
      const std::array token{tokens[replay]};
      auto table = hash_table(resident, replay);
      const auto ids = std::span<const std::int32_t>(table).subspan(token[0] * 6, 6);
      auto expected = evaluate(x, ids);
      f.replays.push_back({{bytes(x), hash_tokens(token, native_routing), bytes(table)},
                            std::move(expected)});
    } else {
      f.replays.push_back({{bytes(x)}, evaluate(x, {})});
    }
  }
  return f;
}

inline Fragment hash_moe(const Case &model, bool native_routing = false) {
  return moe_chain(model, native_routing, false, nullptr, 64.0F, true);
}

inline Fragment gguf_moe(const Case &model, bool native_routing = false) {
  return moe_chain(model, native_routing, false);
}
inline Fragment official_kimi_moe() {
  return moe_chain(cases::kCases[0], false, true);
}
} // namespace d5_moe_execution_fragments
