from pathlib import Path
import importlib.util,sys,os,json,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-system-review-20261025/deepseek-early-history/attempt2'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(D/'ready.json');assert b.pin(D/'checks.exe')==ready['image']
for pin in ready['sources']:assert b.pin(Path(pin['path']))==pin
out=D/'actual';env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR=str(R/'.scratch/dspark-original-target-tail-20261023/original-target'),HYLE_DSPARK_SHARED_VOCAB_DIR=str(R/'.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary'))
env['PATH']=str(D)+';'+b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')['PATH']
b.save(D/'actual-inputs.json',{k:v for k,v in env.items() if k.startswith(('HYLE_DSPARK_','HF_','TRANSFORMERS_'))})
b.execute([str(D/'checks.exe'),'--gtest_color=no','--gtest_filter=DSparkOriginalEarlyHistory.*','--gtest_output=xml:'+str(out/'results.xml')],out,env,600)
x=ET.parse(out/'results.xml').getroot();assert int(x.get('tests'))==1 and int(x.get('failures'))==0 and not list(x.iter('skipped'))
b.save(out/'summary.json',dict(status='PASS',tests=1,skips=0,episodes=['empty0to1','first4compression2to4','given126prefix127first128compressionand128SWAwrap'],model_processes=1,SDK_builds=0,HTTP=0))
print('PASS one ordinary original Flash component; no fullmodel/quality/TPS claim',flush=True)
