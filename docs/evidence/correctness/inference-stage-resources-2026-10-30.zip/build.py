"""Refresh actual affected graph CXX objects and finite current consumers."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PREV = R / '.scratch/inference-input-schema-20261030'
spec = importlib.util.spec_from_file_location('source_build', R / '.scratch/inference-source-binding-20261030/build.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
s.W = s.b.W = W
read, save, pin, exact, key = s.read, s.save, s.pin, s.exact, s.key


def prepare():
    assert not (W / 'plan.json').exists()
    base = read(PREV / 'model-link-base.json')
    prior = read(PREV / 'plan.json')
    sdk = read(base['sdk_engine_dependencies']['path'])
    changed = {key(R / x) for x in subprocess.check_output(
        ['git', 'diff', '--name-only', '--', 'include', 'src', 'engine'], cwd=R, text=True).splitlines()}
    rows = {key(x['object']): x for x in sdk['inspected']}
    rows.update({key(x['object']): x for x in sdk['engine_consumers'] if 'dependencies' in x})
    units, actual_rows, unavailable = {}, [], []
    for item in base['retained']:
        exact(item)
        adjacent = Path(item['path']).parent / 'dependencies.json'
        row = rows.get(key(item['path']))
        if adjacent.is_file() and 'Data' in read(adjacent):
            row = dict(object=item['path'], dependencies=pin(adjacent))
        if row is None:
            unavailable.append(item['path'])
            continue
        actual_rows.append(row)
        d = read(row['dependencies']['path'])['Data']
        if not any(key(x) in changed for x in [d['Source'], *d['Includes']]):
            continue
        args, recipe = s.command_for(item['path'], d['Source'])
        name = 'sdk-' + str(Path(d['Source']).relative_to(R)).replace('\\', '__').replace('.', '_')
        units[name] = dict(source=d['Source'], original=item, recipe=recipe,
            compile=s.relocated(args, name), old_dependencies=row['dependencies'], kind='sdk')
    consumers = {name: dict(unit, compile=s.relocated(unit['compile'], name))
                 for name, unit in prior['consumers'].items()}
    source_old = read(R / '.scratch/inference-source-binding-20261030/plan.json')
    for name in ('source-test', 'paged-test', 'mixed-test', 'indexed-test', 'readback-test'):
        unit = source_old['consumers'][name]
        consumers[name] = dict(unit, compile=s.relocated(unit['compile'], name))
    # Native CPU and CUDA definitions match the retained engine's Backend.
    for name, source in [('slot-test', R / 'tests/tools/inference_slot_transactions_test.cc'),
                         ('append-test', R / 'tests/graph_batch/paged_append_graph_test.cc')]:
        consumers[name] = dict(source=str(source), compile=s.relocated(consumers['cli']['compile'], name, source), kind='gtest')
    old_header = subprocess.check_output(['git', 'show', 'HEAD:include/hyle/graph/executable.h'], cwd=R)
    overlay = W / 'baseline/include/hyle/graph/executable.h'
    overlay.parent.mkdir(parents=True, exist_ok=True)
    overlay.write_bytes(old_header)
    baseline = W / 'baseline/slot_test.cc'
    text = (R / 'tests/tools/inference_slot_transactions_test.cc').read_text(encoding='utf-8')
    original_include = '#include "../../engine/inference/slot_transactions.h"'
    assert text.count(original_include) == 1
    baseline.write_text(text.replace(original_include, '#include "' + (W / 'baseline/slot_transactions.h').as_posix() + '"'), encoding='utf-8')
    args = s.relocated(consumers['slot-test']['compile'], 'baseline-test', baseline)
    args.insert(1, '/I' + str(W / 'baseline/include'))
    consumers['baseline-test'] = dict(source=str(baseline), compile=args, kind='gtest')
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    ordinary = W / 'ordinary-input'
    ordinary.mkdir(exist_ok=True)
    for file in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(PREV / 'ordinary-input' / file, ordinary / file)
    cases = {name: prior['cases'][name] for name in ('single-auto', 'recursive', 'threshold', 'restore', 'natural', 'batch', 'group',
        'carrier_cpu', 'carrier_cuda', 'packet_cpu', 'packet_cuda', 'runner-cpu', 'ds-pro-cpu', 'ds-flash-cpu',
        'ds-early-cuda', 'glm-cuda', 'glm-early-cuda', 'glm-flash-cuda', 'kimi-cuda')}
    cases['ordinary'] = dict(unit='ordinary', args=['--cuda-continuous', str(ordinary)])
    cases['source-tests'] = dict(unit='source-tests', filter='GraphOutputSourceCuda.*:GraphPagedAppendSourceCuda.*:GgmlCudaMixedReadySource.*:GgmlCudaPendingIndexedState.*:QwenBackendCpuCuda.ReadbackI32WriterSupportsTheOriginalSubmissionSource', tests=29)
    cases['append-cpu'] = dict(unit='append-test', filter='GraphPagedAppend.*:GraphBatchQueryOffsets.*', tests=6)
    cases['slots-cpu'] = dict(unit='slot-test', filter='InferenceSlotTransactions.*', tests=5)
    save(W / 'plan.json', dict(base=pin(PREV / 'model-link-base.json'), base_commit='4dbe9aa05',
        units=units, consumers=consumers, retained=base['retained'], runtime=base['runtime'],
        original_link=base['link'], original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        old_cli=base['current_consumers']['cli']['object'], sdk=base['sdk_engine_dependencies'],
        actual_dependency_rows=actual_rows, unavailable_dependencies=unavailable,
        environments=prior['environments'], cases=cases, sdk_compiles=len(units), nvcc_compiles=0, downloads=0))
    print('Prepared affected SDK CXX:', len(units), '; consumers:', len(consumers), '; no NVCC/download.', flush=True)


def compile_group(attempt, names):
    errors = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs = {pool.submit(s.compile_one, name, attempt): name for name in names}
        for job in as_completed(jobs):
            try: job.result()
            except BaseException as error: errors.append(dict(unit=jobs[job], error=str(error)))
    save(W / ('compile-' + attempt + '-' + names[0] + '.json'), dict(names=names, errors=errors, max_concurrency=2))
    assert not errors, errors


def link(name, attempt):
    p = read(W / 'plan.json')
    control = name in ('control', 'baseline-test')
    retained = p['retained'] if control else p['candidate_retained']
    members = ['source-test', 'paged-test', 'mixed-test', 'indexed-test', 'readback-test'] if name == 'source-tests' else ['ds', 'ds-original'] if name == 'ds' else [name]
    objects = [p['old_cli']] if name == 'control' else [read(W / 'compile' / x / 'receipt.json')['object'] for x in members]
    for item in [*retained, *objects]: exact(item)
    replacements = {key(a['path']): c['path'] for a, c in zip(p['retained'], retained)}
    args = []
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']):
            args.extend(x['path'] for x in objects)
            continue
        arg = replacements.get(key(arg), arg)
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                break
        args.append(arg)
    if name not in ('cli', 'natural', 'ordinary', 'control'):
        args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / x) for x in ('gtest_main.lib', 'gtest.lib'))
    s.b.execute(args, W / 'link' / name / attempt, 240)
    save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))


def run(name, attempt):
    p = read(W / 'plan.json')
    baseline = name == 'baseline'
    case = dict(unit='baseline-test', filter='InferenceSlotTransactions.OriginalInvocationIdentitySurvivesMoveAndRebind', tests=1) if baseline else p['cases'][name if name != 'control' else 'single-auto']
    unit = 'control' if name == 'control' else case['unit']
    image = read(W / ('ready-' + unit + '.json')); exact(image)
    folder = W / 'runs' / name / attempt
    os.environ.update(p['environments'].get(case.get('env'), {}))
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
        HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS='0', HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS='0', HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS='0',
        HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0', HYLE_GLM_MLX_WAIT_FOR_EXPERTS='0', HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS='0',
        HYLE_DSPARK_PRO_FRONTIER_FILE=str(folder/'missing-pro.json'), HYLE_DSPARK_FLASH_FRONTIER_FILE=str(folder/'missing-flash.json'))
    save(folder / 'image.json', image)
    if 'filter' in case:
        try:
            s.b.execute([image['path'], '--gtest_color=no', '--gtest_fail_fast', '--gtest_filter=' + case['filter'],
                '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
        except SystemExit as error:
            if not baseline or error.code != 1: raise
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('errors', '0') == '0' and not result.findall('.//skipped')
        assert result.get('failures') == ('1' if baseline else '0')
        if baseline:
            assert 'a foreign Invocation returned its transaction' in (folder / 'stdout.log').read_text(encoding='utf-8')
        report = dict(status='EXPECTED_OLD_HELPER_FAILURE' if baseline else 'PASS', tests=case['tests'],
            failures=int(result.get('failures')), skipped=0,
            cases=[dict(name=t.get('classname') + '.' + t.get('name'), seconds=t.get('time')) for t in result.findall('.//testcase')])
    else:
        s.b.execute([image['path'], *case['args']], folder, 300)
        report = read(folder / 'stdout.log')
        if unit in ('cli', 'control'):
            assert report['live_committed_versions'] == 0 and report['generated_tokens'] == (32 if name == 'restore' else 64)
        else: assert report['status'] == 'PASS'
    save(folder / 'report.json', report)
    print(report.get('status', 'PASS'), name, flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': s.compile_one(*sys.argv[2:])
    elif action == 'compile-sdk': compile_group(sys.argv[2], list(read(W / 'plan.json')['units']))
    elif action == 'compile-group': compile_group(sys.argv[2], sys.argv[3:])
    elif action == 'seal': s.seal()
    elif action == 'link': link(*sys.argv[2:])
    elif action == 'link-selected':
        for name in sys.argv[3:]: link(name, sys.argv[2])
    elif action == 'run': run(*sys.argv[2:])
    elif action == 'run-selected':
        for name in sys.argv[3:]: run(name, sys.argv[2])
    else: raise ValueError(action)
