"""Retain current object/link receipts; remove only verified rebuildable images."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    assert a['status'] == 'PASS_FINITE_STAGE_RESOURCE_CHECKS'
    base = read(p['base']['path'])
    consumers = {}
    for name in p['consumers']:
        if name == 'baseline-test':
            continue
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    replacements = {key(x['path']): y['path'] for x, y in zip(p['retained'], p['candidate_retained'])}
    replacements[key(p['original_consumer'])] = consumers['cli']['object']['path']
    base.update(schema='hyle.stage-resources.current-link-base.v1', base=p['base'],
        retained=p['candidate_retained'], sdk_engine_dependencies=p['candidate_sdk'],
        current_consumers=consumers, previous_consumer=consumers['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'],
        link=[replacements.get(key(arg), arg) for arg in p['original_link']])
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
        targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    (W / 'product.diff').write_bytes(subprocess.check_output(
        ['git', 'diff', '--', 'cmake', 'engine', 'include', 'src', 'tests'], cwd=R))
    print('Retained current227 SDK/engine inputs and18 current consumer objects; image targets', len(targets))


def finish():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R / 'test.ps1', W / 'cleanup.ps1')
    changed = subprocess.check_output(['git', 'diff', '--name-only', '--',
        'cmake', 'engine', 'include', 'src', 'tests'], cwd=R, text=True).splitlines()
    value = dict(schema='hyle.correctness.stage-resources.v1', date='2026-10-30',
        status='ORIGINAL_INVOCATION_GUARD_AND_BORROWED_STAGE_ARGUMENTS_FINITE_CHECKED',
        base_commit=p['base_commit'],
        contract=dict(transaction='SlotTransactions remembers the original Invocation state identity while Graph owns a cohort. Foreign take/take_all/recover reject before mutation. Moving the original Invocation and legal later rebind remain supported. Identity is borrowed while state lives, not resource permission.',
            stage='GLM/DeepSeek project existing immutable phase input IDs into the original live lease table using a static borrowed range. Eager bounds check precedes any Graph bind. Same execute body, no argument vector or extra ReadLease pin.',
            phase='Existing cold split already proves producer/availability. Routed expert selection and bounded upload require the original host phase boundary; do not add a parallel plan or erase that boundary.',
            lifetime='Original live/completed outputs, resident expert-bank generation, Invocation, Completion, reset, Status, publication and actual retirement remain at their original release points.',
            allocation='StoreSource tickets/coordinates inline up to2 with original allocator overflow; native paged instructions inline up to4. Retained group words reserve before revoke/upload and commit trivial content after upload. All original actual permission/layout/coordinate checks remain.',
            memory='No new GPU buffer. Inline owner allocation is charged with actual sizeof; removes small child allocations but may increase single-view metadata bytes. No claim of lower total metadata or VRAM.'),
        implementation=dict(sources=[pin(R / x) for x in changed], diff=pin(W / 'product.diff'),
            **a['implementation'], current_link_base=pin(W / 'model-link-base.json')),
        checks=dict(old_helper_expected_failure=a['old_helper_baseline'],
            regression='Same compiled Store nodes, two original Invocations with independent cohorts. Old helper really returned the peer transaction; fixed helper rejects, preserves both cohorts, survives move and legal rebind.',
            gtests=61, finite_consumer_processes=12, failures=0, skipped=0,
            cases=a['cases'], original_non_timing_comparisons=a['original_non_timing_comparisons'],
            build_manifest_check=a['build_manifest_check'], analysis=pin(W / 'analysis.json')),
        limited_screening=a['abba'], performance_claim=False, limits=a['limits'],
        cleanup=dict(script=pin(R / 'test.ps1'), archived_script=pin(W / 'cleanup.ps1'),
            manifest=pin(W / 'cleanup-targets.json'), result=cleanup),
        evidence_archive='inference-stage-resources-2026-10-30.zip')
    out = R / 'docs/evidence/correctness/inference-stage-resources-2026-10-30.json'
    save(out, value)
    with zipfile.ZipFile(out.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or any(x in ('bin', '__pycache__', 'ordinary-input') for x in path.relative_to(W).parts):
                continue
            if path.suffix.lower() in ('.json', '.py', '.ps1', '.cc', '.h', '.diff', '.log', '.xml'):
                z.write(path, path.relative_to(W).as_posix())
    with zipfile.ZipFile(out.with_suffix('.zip')) as z:
        assert z.testzip() is None
    print('Evidence saved and archive checked', pin(out), pin(out.with_suffix('.zip')))


if __name__ == '__main__':
    {'prepare': prepare, 'finish': finish}[sys.argv[1]]()
