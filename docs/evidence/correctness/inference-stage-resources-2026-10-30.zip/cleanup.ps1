$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$batch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-stage-resources-20261030'))
$manifest = Get-Content -LiteralPath (Join-Path $batch 'cleanup-targets.json') -Raw | ConvertFrom-Json
$bin = [IO.Path]::GetFullPath((Join-Path $batch 'bin'))
if ($manifest.boundary -cne $bin) { throw 'Unexpected cleanup boundary' }
$targets = $manifest.targets
foreach ($target in $targets) {
  $path = [IO.Path]::GetFullPath($target.path)
  if ([IO.Path]::GetDirectoryName($path) -cne $bin -or -not $path.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar)) { throw ('Unexpected cleanup target: ' + $path) }
  $item = Get-Item -LiteralPath $path
  if ($item.PSIsContainer -or $item.Length -ne $target.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.sha256) { throw ('Changed cleanup target: ' + $path) }
}
$removed = @()
foreach ($target in $targets) {
  Remove-Item -LiteralPath $target.path -Force
  $removed += $target
}
$report = @{ status='REMOVED_EXACT_FLAT_BATCH_IMAGES'; files=$removed.Count; bytes=($removed | Measure-Object -Property bytes -Sum).Sum; targets=$removed }
$report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $batch 'cleanup-report.json') -Encoding utf8
$report | Select-Object status,files,bytes | Format-List
