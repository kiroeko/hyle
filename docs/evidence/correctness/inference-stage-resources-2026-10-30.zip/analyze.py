"""Finite original-consumer checks, explicit old-helper failure and bounded ABBA."""
from pathlib import Path
import importlib.util
import statistics
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
                if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def differences(a, c, path=''):
    if isinstance(a, dict) and isinstance(c, dict):
        return [d for k in sorted(a.keys() | c.keys())
                for d in differences(a.get(k), c.get(k), path + '/' + str(k))]
    if isinstance(a, list) and isinstance(c, list) and len(a) == len(c):
        return [d for i, (x, y) in enumerate(zip(a, c))
                for d in differences(x, y, path + '/' + str(i))]
    return [] if a == c else [dict(path=path, before=a, after=c)]


def main():
    p = read(W / 'plan.json')
    reports = {name: read(W / 'runs' / name / 'attempt1/report.json') for name in p['cases']}
    baseline = read(W / 'runs/baseline/attempt1/report.json')
    assert baseline['status'] == 'EXPECTED_OLD_HELPER_FAILURE'
    assert baseline['tests'] == baseline['failures'] == 1 and baseline['skipped'] == 0
    comparisons = []
    for name in ('single-auto', 'recursive', 'threshold', 'restore', 'natural', 'ordinary', 'batch',
                 'carrier_cpu', 'carrier_cuda', 'packet_cpu', 'packet_cuda'):
        anchor = b.PREV / 'runs' / name / 'attempt1/report.json'
        diff = differences(stable(read(anchor)), stable(reports[name]))
        comparisons.append(dict(case=name, anchor=pin(anchor), differences=diff,
                                complete_non_timing_equal=not diff))
    for name, report in reports.items():
        if 'tests' in report:
            assert report['status'] == 'PASS' and report['failures'] == report['skipped'] == 0
    assert sum(x.get('tests', 0) for x in reports.values()) == 61
    assert sum('tests' not in x for x in reports.values()) == 12
    samples = []
    for arm, case, attempt in [('A', 'control', 'abba-1'), ('B', 'single-auto', 'abba-2'),
                               ('B', 'single-auto', 'abba-3'), ('A', 'control', 'abba-4')]:
        path = W / 'runs' / case / attempt / 'report.json'
        report = read(path)
        samples.append(dict(arm=arm, report=pin(path),
            decode_tokens_per_second=report['decode_output_tokens_per_second'],
            decode_seconds=report['decode_seconds'], stable_report=stable(report)))
    for row in samples:
        assert row['stable_report'] == stable(reports['single-auto']), (row['arm'],
            differences(row['stable_report'], stable(reports['single-auto'])))
        del row['stable_report']
    old = statistics.median(x['decode_tokens_per_second'] for x in samples if x['arm'] == 'A')
    new = statistics.median(x['decode_tokens_per_second'] for x in samples if x['arm'] == 'B')
    for name in p['consumers'] | p['units']:
        receipt = read(W / 'compile' / name / 'receipt.json')
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
    result = dict(status='PASS_FINITE_STAGE_RESOURCE_CHECKS',
        old_helper_baseline=pin(W / 'runs/baseline/attempt1/report.json'),
        cases={name: pin(W / 'runs' / name / 'attempt1/report.json') for name in reports},
        gtests=61, finite_consumer_processes=12, failures=0, skipped=0,
        original_non_timing_comparisons=comparisons,
        abba=dict(order='ABBA', samples=samples, old_median_tokens_per_second=old,
            current_median_tokens_per_second=new, change_percent=(new / old - 1) * 100,
            performance_claim=False, reason='Two samples per version; bounded screening only, no peer or full performance/memory window.'),
        implementation=dict(SDK_engine_CXX_refresh=len(p['units']), retained_unchanged=227-len(p['units']),
            current_consumer_CXX_TUs=len(p['consumers'])-1, old_header_negative_test_CXX_TUs=1,
            NVCC_compiles=0, downloads=0, dependency_records=len(p['actual_dependency_rows']),
            unavailable_dependency_records=len(p['unavailable_dependencies'])),
        build_manifest_check=pin(W / 'configure/components/attempt1/process.json'),
        limits=['No new Apple/Vulkan native execution or entire large-model run.',
                'No new performance attribution, peer/full-window or VRAM measurement.',
                'Inline metadata removes child allocations, not necessarily total metadata bytes.',
                'No new allocator fault injection or native metadata upload failure injection.',
                'Original live/completed owners remain until episode end; no last-use retirement change.',
                'Stage arguments and resource boundaries improved; full shared execution architecture remains incomplete.'])
    save(W / 'analysis.json', result)
    print(result['status'], 'gtests61; finite consumers12; comparison differences',
          sum(len(x['differences']) for x in comparisons), 'ABBA', round(old, 2), round(new, 2))


if __name__ == '__main__':
    main()
