from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
R=Path.cwd();S=R/'.scratch/qwen-original-stochastic-tails-20261024'
spec=importlib.util.spec_from_file_location('b',S/'build.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);m=a.m.m
headers={'GGUF':'.scratch/qwen-gguf-selected-20261023/S01/generated/qwen_gguf_original_artifacts.h','B07':'.scratch/qwen-gguf-selected-20261023/B07/generated/qwen_gguf_b07_artifacts.h','B04':'.scratch/qwen-gguf-selected-20261023/B04/generated/qwen_gguf_b04_artifacts.h','Q14':'.scratch/qwen-gguf-selected-20261023/Q14/generated/qwen_gguf_q14_artifacts.h',**{x:f'.scratch/qwen-bfloat-selected-20261023/derived/{x}/generated/qwen_{x.lower()}_original_pins.h' for x in ('Q03','Q01','Q09','Q10')}}
results=[];source=R/'tests/compute_models/qwen_mtp_state_consumer_test.cc';before=m.ident(source)
for endpoint,recipe in [('cpu',R/'.scratch/qwen-original-stochastic-20261024/cpu-syntax4/command.json'),('cpu-cuda',S/'compile2/command.json')]:
 command=[];skip=False
 for flag in m.read(recipe)['command']:
  if skip:skip=False;continue
  if flag=='/sourceDependencies':skip=True;continue
  if flag.startswith(('/Fo','/Fd')) or flag.endswith('qwen_mtp_state_consumer_test.cc'):continue
  command.append(flag)
 command+=['/Zs']+[f'/DHYLE_TEST_QWEN_{name}_ARTIFACTS_HEADER="{(R/path).as_posix()}"' for name,path in headers.items()]+[str(source)]
 env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 out=S/('wrappers-'+endpoint+'-syntax');m.b.execute(command,env,out,timeout=120);assert m.ident(source)==before
 results.append(dict(endpoint=endpoint,result=m.read(out/'process.json')))
m.save(S/'wrappers-syntax.json',dict(status='PASS',source=before,headers={k:m.ident(R/v) for k,v in headers.items()},new_SDK_TUs=0,device_runs=0,results=results))
print('PASS limits wrappers CPU and CPU/CUDA eight artifact gates')
