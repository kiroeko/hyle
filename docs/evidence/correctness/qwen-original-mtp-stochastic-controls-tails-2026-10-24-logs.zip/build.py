from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('original',R/'.scratch/qwen-original-stochastic-20261024/build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.S=S
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('actions',nargs='+',choices=['compile','link','run']);p.add_argument('--attempt',type=int,default=2);a=p.parse_args()
 for action in a.actions:getattr(m,action)(a.attempt)
