from pathlib import Path
import hashlib,json,shutil,xml.etree.ElementTree as ET
root=Path.cwd();out=root/'.scratch/architecture-refactor-2026-10-18/ct-packed-vulkan';checks=out/'checks'
def identity(path):
 path=Path(path);data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(name,value):(out/name).write_bytes((json.dumps(value,indent=2)+'\n').encode())
sources=['src/graph_route_vulkan/native_region.cc','src/compute_route_vulkan/vulkan_ct_packed.cc','src/compute_route_vulkan/shaders/ct_packed.comp','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/vulkan_tensor.h','src/compute_route_vulkan/build_shaders.py','src/compute_route_vulkan/CMakeLists.txt','tests/graph_route_vulkan/ct_packed_linear_test.cc','tests/graph_route_vulkan/CMakeLists.txt']
shared=['src/graph/ct_packed_region.h','src/graph/mapped_native_region.h','src/compute_packed_shared/ct_packed_linear.h','src/compute_shader_shared/ct_packed.h','src/compute_shader_shared/nvfp4_f32.h','tests/compute_models/ct_packed_graph_fixture.h','tests/compute_models/ct_packed_linear_fixture.h','src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_iree.cc','src/compute_route_vulkan/vulkan_run.cc']
assert all((root/p).is_file()for p in sources+shared)
snapshot=[]
for relative in sources+shared:
 original=root/relative;target=out/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
 snapshot.append(dict(original=identity(original),snapshot=identity(target),role='current owned Vulkan task'if relative in sources else 'shared dependency or original-route source evidence'))
save('source-freeze.json',dict(files=snapshot))
# Confirm generation used exactly the current shared arithmetic text.
def raw(path):return (root/path).read_text(encoding='utf-8').split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0]
generated=(out/'shaders/ct_packed.generated.comp').read_text(encoding='utf-8')
expected=(root/'src/compute_route_vulkan/shaders/ct_packed.comp').read_text(encoding='utf-8').replace('// HYLE_CT_F32_SOURCE',raw('src/compute_shader_shared/nvfp4_f32.h')+'\n'+raw('src/compute_shader_shared/ct_packed.h'))
assert generated==expected
owners=['native_region','vulkan_operations','vulkan_ct_packed','vulkan_shaders','ct-test'];drift=[]
for owner in owners:
 receipt=json.loads((checks/(owner+'-identity.json')).read_bytes())
 for entry in receipt['dependencies']:
  current=identity(entry['path'])
  if current['sha256']!=entry['sha256']:drift.append(dict(owner=owner,compiled=entry,current=current))
assert not drift,drift
xml=ET.parse(checks/'ct-packed-tests.xml').getroot();assert int(xml.attrib['tests'])==18 and int(xml.attrib['failures'])==0 and int(xml.attrib['errors'])==0
assert sum(int(s.attrib.get('skipped',0))for s in xml)==0
performance=json.loads((checks/'performance-summary.json').read_bytes())
report=dict(status='completed actual Windows Vulkan GPU execution',backend='Vulkan native ExecutionSource, RTX4070',
 implementation='Two native whole-region proposals: original route1, closed CT-contracted route4. Reuse shared CtPackedPattern and original Program/Invocation/Queue/lifetimes.',
 numerical_contract='Rscale((q-z)*s) -> Rdecode -> Roperand; F32 dot and output RNE. Shared U32 typed/source math, native precise ordinary dot and U32 exceptional/FTZ-sensitive replay. Symmetric z=8; asymmetric K-packed W and N-packed Z preserve original bytes.',
 capacity=dict(dense_weight_bank=False,activation_qdq_bank=False,bounded_transient='64 shared partial words plus 64 exceptional flags per workgroup; scalar weight decode per participating lane',native_plan_probe=dict(M=3,N=257,K=1024,output_invocation_payload_bytes=3084,original_constant_capacity_bytes=152256,excluded_dense_bf16_weight_bytes=526336,excluded_dense_f32_weight_bytes=1052672),limits='Actual original carriers/output padded byte capacities and native dispatch/U32 bounds. Existing generic Program descriptor bounds still apply; no fake dense N*K allowance.'),
 default_policy='All supported M and F32/F16/BF16 boundaries remain capable as route4. Packed rank199 only if every contraction has flattened M1 and BF16 scale/decode/operand; others rank201, original rank200. No model allowlist or public force switch.',
 tests=dict(total=18,failed=0,skipped=0,ct=5,nvfp4_neighbors=2,native_region_neighbors=11,source_round_profiles=7,selection='Test-side filtering of the real native source region proposals only; real source/resource/compile/submit unchanged.',scope='source-round one-hot equality, legal nonfinite/subnormal amplified weights, two slots/four original-byte rebinds and retained old results, published/view/control escapes, materialized original constant lifetime/no dense native storage',validation_layer_enabled=False,other_backends='Not run or signed by this Vulkan task'),
 performance=performance,
 performance_interpretation='M1 original median262.85us vs packed80.2us (~3.28x faster); M128 original452.25us vs packed1946.35us (~4.30x slower). Both arms execute same public Graph with original constants, bind once/prepare before timing and identical submit+wait scope; original route1 still includes per-replay ArtifactWeightDecode and original mature MatMul. This is current-path comparison, not a separately cached dense-weight GEMM baseline, not GPU timestamps, no crossover claim.',
 performance_timing_version='Measured before the final cold default-rank and metadata bad_alloc handling change. Actual hot shader/lowering objects unchanged; test-side arm filtering excludes other candidates and therefore ignores default rank. Exact bench source/compile dependency identities and retained executable are in checks. Later final wrapper adds default-policy assertions.',
 original_route_evidence=['source/src/compute_route_vulkan/vulkan_program.cc:159 prepare_constant_casts only folds direct constant Cast/View; decoded output is not an original constant','source/src/compute_route_vulkan/vulkan_program.cc:212 pack_matrix_constants requires actual constant MatMul source','source/src/compute_route_vulkan/vulkan_program.cc:448 original ArtifactWeightDecode lowers as IREE managed stage','source/src/compute_route_vulkan/vulkan_iree.cc:494 artifact inputs are outside constant whitelist; per-replay input copy/dispatch remain'],
 corrected_initial_failures=['GLSL compile rejected reserved identifier active; renamed valid, no mathematics change.','Test CXX missing shared Pattern include and explicit const callback return; corrected before GPU.','First actual5tests had2 harness failures: odd exact16bit output correctly rejected TransferSlot padded-range requirement; test uses existing exact Context.download. ConstantBinding lease without StorageOwner correctly rejected; test uses Materialize with empty owner/lease and verifies native-owned constants after external owners drop. No product range/ownership relaxation.'],
 metadata_failure='New propose vector allocation is caught as ResourceExhausted, not noexcept termination.',
 unchanged_shaders=dict(previous=13,byte_equal=13,comparison='checks/shader-comparison.json'),
 build_scope='Incremental strict MSVC /W4 /WX: native_region, vulkan_operations, vulkan_ct_packed, generated Vulkan shaders; one new CT wrapper. Existing SDK/libs/other linked objects reused. CMake source/dependency edits included; no full CMake target/SDK rebuild.',
 source_freeze='source-freeze.json',final_command='python .scratch/architecture-refactor-2026-10-18/ct-packed-vulkan/build.py run VulkanCtPackedLinear.*:VulkanNvfp4ReferenceGraph.*:VulkanNativeRegion.*',
 receipts=[identity(p)for p in [checks/'link-plan.json',checks/'commands-run.json',checks/'ct-packed-tests.xml',checks/'ct-packed-tests.stdout.log',checks/'ct-packed-tests-harness-red.xml',checks/'ct-packed-tests-harness-red.stdout.log',checks/'ct-paired-perf.xml',checks/'ct-paired-perf.stdout.log',checks/'commands-perfrun.json',checks/'ct-perf-identity.json',checks/'perf-link-plan.json',checks/'performance-summary.json',checks/'shader-comparison.json']],
 limitations=['Reference row kernel repeats weight decode per M; no performance claims for unmeasured shapes/types/hardware.','Invocation private managed memory remains unknown for original native route; no claim runtime OOM automatically reselects packed.','No Vulkan validation layer enabled in this batch.','No full eight-model payload or end-to-end inference test in this batch.'])
save('final-receipt.json',report)
all_files=[p for p in out.rglob('*')if p.is_file()];binary=[p for p in all_files if p.suffix.lower()in {'.exe','.obj','.map','.pdb','.spv'}]
save('artifact-sizes.json',dict(total_bytes=sum(p.stat().st_size for p in all_files),rebuildable_binary_bytes=sum(p.stat().st_size for p in binary),rebuildable_files=[dict(path=str(p),bytes=p.stat().st_size)for p in binary],cleanup='Do not delete before root seals evidence; root test.ps1 only. Keep compact sources/commands/results; exe/obj/map/pdb/spv are rebuildable after archive.'))
print(json.dumps(dict(report=str(out/'final-receipt.json'),tests=xml.attrib['tests'],failures=xml.attrib['failures'],total_bytes=sum(p.stat().st_size for p in all_files),dependencies_current=True),indent=2))
