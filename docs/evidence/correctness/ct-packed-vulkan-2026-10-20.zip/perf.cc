#include "C:/public/project-hyle/hyle/tests/graph_route_vulkan/ct_packed_linear_test.cc"
#include <chrono>
#include <iostream>

TEST(VulkanCtPackedPerformance, SameGraphBindOncePairedReplay) {
  Harness h;
  for (const auto m : {1LL, 128LL}) {
    auto graph = f::build({true, Type::kBFloat16, Type::kBFloat16, Type::kBFloat16, m},
        512, 1024, f::Escape::kNone, true);
    Data data(h, graph, 3);
    std::vector<f::g::ConstantBinding> constants;
    for (std::size_t i = 1; i < graph.ports.size(); ++i)
      constants.push_back({graph.ports[i], f::take(data.inputs[i].tensor(graph.descriptions[i]), "perf constant"),
          f::g::ConstantPolicy::kMaterialize, {}, {}});
    std::array programs{
      f::take(h.compile(graph, Selection::kOriginal, {.constants = constants}), "original same Graph"),
      f::take(h.compile(graph, Selection::kPacked, {.constants = constants}), "packed same Graph")};
    selected(programs[0].report, false); selected(programs[1].report, true);
    std::array slots{f::invocation(programs[0].executable), f::invocation(programs[1].executable)};
    for (auto &slot : slots) { bind(graph, data, slot); f::check(slot.prepare_replay({}), "prepare before timing"); }
    const auto replay = [&](unsigned arm) {
      const auto start = std::chrono::steady_clock::now();
      { auto completion = f::take(slots[arm].submit({}), "bindonce replay"); f::check(completion.wait(), "bindonce retirement"); }
      return std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - start).count();
    };
    for (unsigned warm = 0; warm < 2; ++warm) { replay(warm & 1U); replay(1U - (warm & 1U)); }
    std::array<std::vector<double>, 2> times;
    for (unsigned pair = 0; pair < 10; ++pair)
      for (unsigned order = 0; order < 2; ++order) {
        const auto arm = (pair & 1U) ^ order;
        times[arm].push_back(replay(arm));
      }
    for (unsigned arm = 0; arm < 2; ++arm) {
      expect_dot(graph, data, output(h, slots[arm], graph.output));
      std::cout << "CT_PAIRED {\"M\":" << m << ",\"N\":512,\"K\":1024,\"arm\":\""
          << (arm ? "packed" : "original") << "\",\"microseconds\":[";
      for (std::size_t sample = 0; sample < times[arm].size(); ++sample) {
        if (sample) std::cout << ',';
        std::cout << times[arm][sample];
      }
      std::cout << "]}" << std::endl;
    }
  }
}
