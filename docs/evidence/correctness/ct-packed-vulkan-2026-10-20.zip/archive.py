from pathlib import Path
import hashlib,json,re,shutil,statistics,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();task=root/'.scratch/architecture-refactor-2026-10-18/ct-packed-vulkan';checks=task/'checks';staging=task/'archive';staging.mkdir(exist_ok=True)
public=root/'docs/evidence/correctness';name='ct-packed-vulkan-2026-10-20'
def sha(data):return hashlib.sha256(data).hexdigest()
def data(path):return Path(path).read_bytes()
def identity(path):
 path=Path(path);content=data(path);return dict(path=str(path),bytes=len(content),sha256=sha(content))
def write(path,value):Path(path).write_bytes((json.dumps(value,indent=2)+'\n').encode())
freeze=json.loads(data(task/'source-freeze.json'))
for entry in freeze['files']:
 assert identity(entry['snapshot']['path'])==entry['snapshot']
 assert entry['snapshot']['sha256']==entry['original']['sha256']
def raw(relative):return (task/'source'/relative).read_text(encoding='utf-8').split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0]
template=task/'source/src/compute_route_vulkan/shaders/ct_packed.comp'
f32=task/'source/src/compute_shader_shared/nvfp4_f32.h';typed=task/'source/src/compute_shader_shared/ct_packed.h'
expected=template.read_text(encoding='utf-8').replace('// HYLE_CT_F32_SOURCE',raw('src/compute_shader_shared/nvfp4_f32.h')+'\n'+raw('src/compute_shader_shared/ct_packed.h'))
actual=(task/'shaders/ct_packed.generated.comp').read_text(encoding='utf-8');assert expected==actual
shared_proof=dict(status='exact_generated_text_equal',template=identity(template),f32=identity(f32),typed=identity(typed),generated=identity(task/'shaders/ct_packed.generated.comp'),expected_utf8_sha256=sha(expected.encode('utf-8')),actual_utf8_sha256=sha(actual.encode('utf-8')),method='Extract exactly one R"HYLE_SHADER raw-string body from each frozen header; concatenate with one newline; replace exactly one CT marker in frozen GLSL template; compare full generated text. This proves source injection identity, not independent GPU mathematics or a validation-layer run.')
write(checks/'ct-exact-shared-source-proof.json',shared_proof)
comparisons=json.loads(data(checks/'shader-comparison.json'));assert len(comparisons)==13 and all(c['equal'] and c['old']['sha256']==c['new']['sha256'] for c in comparisons)
final_xml=ET.fromstring(data(checks/'ct-packed-tests.xml'));assert final_xml.attrib['tests']=='18' and final_xml.attrib['failures']=='0' and final_xml.attrib['errors']=='0';assert sum(int(s.attrib.get('skipped','0'))for s in final_xml)==0
for command in json.loads(data(checks/'commands-run.json')):assert command['exit_code']==0
paired=[json.loads(line.removeprefix('CT_PAIRED '))for line in (checks/'ct-paired-perf.stdout.log').read_text().splitlines()if line.startswith('CT_PAIRED ')]
assert len(paired)==4 and all(len(x['microseconds'])==10 for x in paired)
perf=json.loads(data(checks/'performance-summary.json'))
for item in paired:
 summary=next(x for x in perf['samples']if x['M']==item['M'] and x['arm']==item['arm'])
 assert summary['microseconds']==item['microseconds'] and summary['median_us']==statistics.median(item['microseconds'])
members={}
for path in sorted((task/'source').rglob('*')):
 if path.is_file():members[path.relative_to(task).as_posix()]=data(path)
for path in sorted(checks.iterdir()):
 if path.is_file() and path.suffix in {'.json','.xml','.log'}:members[path.relative_to(task).as_posix()]=data(path)
for relative in ['final-receipt.json','source-freeze.json','build.py','perf.cc','freeze.py','archive.py','shaders/ct_packed.generated.comp','shaders/ct_packed.spv']:
 members[relative]=data(task/relative)
# Preserve the exact older test include bytes used by the benchmark. The final
# wrapper only adds cold default-policy assertions and one typed profile.
perf_test=members['source/tests/graph_route_vulkan/ct_packed_linear_test.cc'].decode('utf-8')
perf_test=perf_test.replace('      f::Profile{true, Type::kBFloat16, Type::kBFloat16, Type::kBFloat16, 1},\n','')
perf_test=perf_test.replace('    auto default_route = f::take(h.compile(graph, Selection::kDefault), "default public Graph compile");\n    selected(default_route.report, profile.m == 1 && profile.scale == Type::kBFloat16 &&\n        profile.decode == Type::kBFloat16 && profile.operand == Type::kBFloat16);\n','')
compiled=json.loads(data(checks/'ct-perf-identity.json'));old_test=next(d for d in compiled['dependencies']if d['path'].replace('\\','/').endswith('/tests/graph_route_vulkan/ct_packed_linear_test.cc'))
assert sha(perf_test.encode('utf-8'))==old_test['sha256']
members['performance-compiled-source/ct_packed_linear_test.cc']=perf_test.encode('utf-8')
members['performance-compiled-source/identity.json']=(json.dumps(dict(method='Reconstructed by reversing only the later two explicit wrapper changes; exact bytes verified against actual compiler dependency SHA256.',compiled_dependency=old_test,archive_member='performance-compiled-source/ct_packed_linear_test.cc',hot_product='Performance predates only final cold default rank and metadata bad_alloc catch. Shader/lowering objects unchanged; forced test arm selection ignores default rank. No claim final native_region source was the literal source at timing.'),indent=2)+'\n').encode()
for member in members:
 assert not any(member.lower().endswith(suffix)for suffix in ('.exe','.obj','.map','.pdb','.lib','.exp'))
 assert not member.startswith('/')and '..'not in Path(member).parts
 assert not member.endswith('.spv')or member=='shaders/ct_packed.spv'
manifest=[dict(member=member,bytes=len(content),sha256=sha(content))for member,content in sorted(members.items())]
archive=staging/(name+'.zip')
assert not archive.exists() and not (public/(name+'.json')).exists() and not (public/(name+'.zip')).exists(),'Archive already exists; do not overwrite one-shot evidence.'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for member,content in sorted(members.items()):z.writestr(member,content)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 assert len(z.namelist())==len(set(z.namelist()))==len(manifest)
 assert set(z.namelist())==set(members)
 for entry in manifest:
  content=z.read(entry['member']);assert len(content)==entry['bytes']and sha(content)==entry['sha256']
final=json.loads(data(task/'final-receipt.json'))
summary=dict(date='2026-10-20',status='implemented_actual_vulkan_focused_correctness_and_two_shape_paired_performance_complete',scope='Synthetic ordinary public Graph CT symmetric/asymmetric INT4 native packed contraction on Windows NVIDIA RTX4070. No selected artifact payload, whole-model inference or validation-layer execution.',
 architecture=final['implementation'],numerical_contract=final['numerical_contract'],storage=final['capacity'],default_route=final['default_policy'],
 validation=dict(total=18,failures=0,skipped=0,suites=[dict(name=s.attrib['name'],tests=int(s.attrib['tests']),failures=int(s.attrib['failures']),skipped=int(s.attrib.get('skipped',0)))for s in final_xml],route_default_assertions='Seven source-round profiles: actual default selects M1 BF16/BF16/BF16; M3 and other precision profiles use original route. Every profile also executes forced-existing packed and original candidates through test-only proposal filtering.',final_xml='checks/ct-packed-tests.xml',commands='checks/commands-run.json',initial_errors='checks/ct-packed-tests-harness-red.xml and original compile logs are preserved; no product range/ownership checks were weakened.'),
 performance=dict(scope=perf['scope'],method='Same public Graph, same source/resource, constant materialize/compile/bind/prepare excluded; two warmups per arm, ten AB/BA paired samples per arm; steady_clock wall submit+wait. Original route1 includes hot ArtifactWeightDecode/IREE input copies plus its mature MatMul; this is not a separately predecoded dense-weight GEMM comparison.',samples=perf['samples'],M1_speedup=262.85/80.2,M128_packed_slowdown=1946.35/452.25,interpretation='M1 BF16: original262.85us vs packed80.2us median, ~3.28x faster. M128 BF16: original452.25us vs packed1946.35us, ~4.30x slower. Preserve full capability but default favor only measured M1 BF16 boundary branch. No crossover or general shape/hardware claim.',raw='checks/ct-paired-perf.stdout.log',summary='checks/performance-summary.json',timing_version=final['performance_timing_version']),
 shader_proofs=dict(old_variants=13,old_variants_byte_identical=13,comparison='checks/shader-comparison.json',new_ct_only_spirv='shaders/ct_packed.spv',shared_source='checks/ct-exact-shared-source-proof.json',shared_exact=True),
 explicit_limits=dict(selected_artifact_payload_run=False,whole_model_run=False,validation_layer_run=False,other_backend_run=False,original_native_private_memory='unknown',real_invocation_oom_reselects_packed=False,capacity_scope='Only actual direct native CT PlanFacts payload probe; not global RSS/VRAM peak or all model capacity acceptance.'),
 build_scope=final['build_scope'],source_freeze='source-freeze.json',product_snapshots='source/',full_report='final-receipt.json',
 evidence_archive=dict(path='docs/evidence/correctness/'+archive.name,bytes=archive.stat().st_size,sha256=sha(data(archive)),member_count=len(manifest),uncompressed_bytes=sum(x['bytes']for x in manifest),members=manifest,verification='Every zip member SHA256/size checked against collected frozen bytes; duplicate/path escape/binary SDK members rejected; zip CRC test passed.'),
 exclusions='No exe/obj/map/pdb/lib/SDK, no 13 duplicated old SPIRVs, no model payload. Only the new CT SPIRV is included.')
pending=staging/(name+'.json');write(pending,summary)
shutil.copyfile(archive,public/archive.name);shutil.copyfile(pending,public/pending.name)
assert data(public/archive.name)==data(archive)and data(public/pending.name)==data(pending)
cleanup=[checks/'ct-perf.exe',checks/'ct-perf.map']
proposal=dict(status='proposal only; no deletion executed',files=[identity(p)for p in cleanup],bytes=sum(p.stat().st_size for p in cleanup),preserve=[str(checks/'ct-packed-test.exe'),'all current .obj files','latest CT product/test sources and commands/results','all existing shared SDK/build dependency caches'],reason='Older performance executable/map are reproducible from archived exact bench wrapper and commands; final current correctness image, all objects and SDK remain reusable.',execution='Parent root test.ps1 only after reviewing exact targets.')
write(staging/'minimal-cleanup-proposal.json',proposal)
print(json.dumps(dict(public_json=identity(public/pending.name),public_zip=identity(public/archive.name),members=len(manifest),member_verification=True,cleanup_proposal=str(staging/'minimal-cleanup-proposal.json'),proposed_delete_bytes=proposal['bytes']),indent=2))
