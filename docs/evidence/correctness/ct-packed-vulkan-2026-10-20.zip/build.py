from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();a=root/'.scratch/architecture-refactor-2026-10-18';out=a/'ct-packed-vulkan';phase=sys.argv[1]if len(sys.argv)>1 else 'host';folder=out/'checks';folder.mkdir(parents=True,exist_ok=True)
basepath=a/'nvfp4-vulkan-reference/checks/link-plan.json';base=json.loads(basepath.read_bytes());env=os.environ.copy();r=subprocess.run(['cmd','/d','/c',str(a/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '='in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
prior=json.loads((a/'vulkan-mlx-constant-bank-reuse/checks/runtime-environment.json').read_bytes());env['PATH']=';'.join(prior['runtime']+[env.get('PATH','')])
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
records=[]
def run(label,command):
 start=time.time();r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');(folder/(label+'.stdout.log')).write_bytes(r.stdout.encode());(folder/(label+'.stderr.log')).write_bytes(r.stderr.encode());records.append(dict(label=label,command=command,exit_code=r.returncode,seconds=time.time()-start));(folder/('commands-'+phase+'.json')).write_bytes((json.dumps(records,indent=2)+'\n').encode());print(label,r.returncode,flush=True)
 if r.returncode:print((r.stdout+r.stderr)[-7000:]);raise SystemExit(r.returncode)
 return r
def compile_one(source,recipe,tag):
 source=Path(source);old=load(recipe)['command'];command=[];skip=False
 for arg in old:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd'))or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 command.insert(1,'-I'+str(out/'shaders'));obj=folder/(tag+'.obj');command+=['/W4','/WX','/sourceDependencies',str(folder/(tag+'-deps.json')),str(source),'/Fo'+str(obj),'/Fd'+str(folder/(tag+'.pdb'))];run(tag+'-compile',command);d=load(folder/(tag+'-deps.json'))['Data'];receipt=dict(command=command,source=ident(source),object=ident(obj),recipe=ident(recipe),dependencies=[ident(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]);(folder/(tag+'-identity.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode());return receipt
ops=a/'nvfp4-vulkan-reference/checks/vulkan_operations-identity.json';graph=a/'mlx-moe-typed-inputs/vulkan/checks/graph_route_vulkan-native_region-identity.json';test=a/'nvfp4-vulkan-reference/checks/nvfp4-test-current-identity.json'
if phase=='shaders':
 run('shader-generation',['python',str(root/'src/compute_route_vulkan/build_shaders.py'),'--compiler','C:/public/tools/glslang/glslangValidator.exe','--source',str(root/'third_party/ggml_vulkan_shaders/shaders'),'--tensor-source',str(root/'src/compute_route_vulkan/shaders'),'--output',str(out/'shaders')])
 old=a/'nvfp4-vulkan-reference/shaders';checks=[]
 for p in sorted(old.glob('*.spv')):
  fresh=out/'shaders'/p.name;checks.append(dict(old=ident(p),new=ident(fresh),equal=p.read_bytes()==fresh.read_bytes()))
 assert len(checks)==13 and all(x['equal']for x in checks),checks
 (folder/'shader-comparison.json').write_bytes((json.dumps(checks,indent=2)+'\n').encode());print('13/13 previous shader variants unchanged',flush=True)
elif phase=='host':
 compile_one(root/'src/graph_route_vulkan/native_region.cc',graph,'native_region');compile_one(root/'src/compute_route_vulkan/vulkan_operations.cc',ops,'vulkan_operations');compile_one(root/'src/compute_route_vulkan/vulkan_ct_packed.cc',ops,'vulkan_ct_packed');compile_one(out/'shaders/vulkan_shaders.cc',ops,'vulkan_shaders')
elif phase=='rank':
 compile_one(root/'src/graph_route_vulkan/native_region.cc',graph,'native_region')
elif phase=='test':
 compile_one(root/'tests/graph_route_vulkan/ct_packed_linear_test.cc',test,'ct-test')
elif phase=='perfbuild':
 compile_one(out/'perf.cc',test,'ct-perf')
 current=load(folder/'link-plan.json');command=[]
 for arg in current['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:')):continue
  command.append(str(folder/'ct-perf.obj') if arg==str(folder/'ct-test.obj')else arg)
 command+=['/OUT:'+str(folder/'ct-perf.exe'),'/MAP:'+str(folder/'ct-perf.map'),'/IMPLIB:'+str(folder/'ct-perf.lib')]
 run('perf-link',command);(folder/'perf-link-plan.json').write_bytes((json.dumps(dict(command=command,executable=ident(folder/'ct-perf.exe')),indent=2)+'\n').encode())
elif phase=='perfrun':
 run('ct-paired-perf',[str(folder/'ct-perf.exe'),'--gtest_filter=VulkanCtPackedPerformance.*','--gtest_output=xml:'+str(folder/'ct-paired-perf.xml')])
elif phase=='link':
 replacements={str(a/'mlx-moe-typed-inputs/vulkan/checks/graph_route_vulkan-native_region.obj'):str(folder/'native_region.obj'),str(a/'nvfp4-vulkan-reference/checks/vulkan_operations.obj'):str(folder/'vulkan_operations.obj'),str(a/'nvfp4-vulkan-reference/checks/vulkan_shaders.obj'):str(folder/'vulkan_shaders.obj')}
 replacements={str(Path(k)).lower():v for k,v in replacements.items()};seen=set();command=[]
 for arg in base['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:')):continue
  key=str(Path(arg)).lower()
  if key in replacements:command.append(replacements[key]);seen.add(key)
  else:command.append(arg)
 assert seen==set(replacements),(seen,replacements)
 command[1:1]=[str(folder/'vulkan_ct_packed.obj'),str(folder/'ct-test.obj')]
 command+=['/OUT:'+str(folder/'ct-packed-test.exe'),'/MAP:'+str(folder/'ct-packed-test.map'),'/IMPLIB:'+str(folder/'ct-packed-test.lib')]
 inputs=[ident(p)for p in command[1:]if Path(p).is_file()];run('link',command)
 (folder/'link-plan.json').write_bytes((json.dumps(dict(command=command,inputs=inputs,executable=ident(folder/'ct-packed-test.exe')),indent=2)+'\n').encode())
elif phase=='run':
 command=[str(folder/'ct-packed-test.exe'),'--gtest_filter='+ (sys.argv[2] if len(sys.argv)>2 else 'VulkanCtPackedLinear.*'),'--gtest_output=xml:'+str(folder/'ct-packed-tests.xml')]
 run('ct-packed-tests',command)
 (folder/'runtime-environment.json').write_bytes((json.dumps(dict(runtime=prior['runtime'],exe=ident(command[0])),indent=2)+'\n').encode())
elif phase=='list':
 r=run('list',[str(folder/'ct-packed-test.exe'),'--gtest_list_tests']);print(r.stdout)
else:raise ValueError(phase)
