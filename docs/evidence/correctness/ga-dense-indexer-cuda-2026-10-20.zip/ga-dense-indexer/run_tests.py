"""Run directed dense-score cases or the current packed/paged source regressions."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dense_test_build', STAGE / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
m.check(plan)
assert c.read(path.parent / 'summary.json')['passed']
group = sys.argv[2] if len(sys.argv) > 2 else 'all'
assert group in ('all', 'dense', 'regression')
destination = sys.argv[3] if len(sys.argv) > 3 else ('tests' if group == 'all' else 'tests-' + group)
assert Path(destination).name == destination and destination.startswith('tests')
out = STAGE / destination
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
names = [
    'CudaDenseIndexer.DyadicStagesAndMaskKeepThreeBfloatRoundsAndNonfiniteValues',
    'CudaDenseIndexer.PaddedBatchKeysKeepIndependentSlotsAndRetainedResults',
    'CudaDenseIndexer.EscapingCoreIntermediatesKeepOrdinaryBoundaries',
    'CudaDenseIndexer.EmptyBatchTokenAndHistoryProduceNoWork',
    'CudaRowCacheIndexer.DefaultDirectKeepsBfloatStagesRangesAndIndependentSlots',
    'CudaRowCacheIndexer.DefaultGraphPublishesScoresAndDownstreamAcrossPhases',
    'CudaRowCacheIndexer.EmptyIntervalsAndEmptyAxesKeepValidation',
    'CudaPagedRowCacheIndexerGraph.FirstPrefillTopKAndRawWindowPaddingUseExactPages',
    'CudaPagedRowCacheIndexerGraph.RequestLocalRangesCrossTheBoundedKeyTile',
    'CudaPagedRowCacheIndexerGraph.InvalidPaddingAndPrivateCapacityCannotEscape',
    'CudaPagedRowCacheIndexerGraph.ColdSpanFailureInvalidatesTheBatchAndSameSlotCanReplan']
if group == 'dense':
    names = names[:4]
elif group == 'regression':
    names = names[4:]
link = plan['links']['dense']
image = b.identity(link['image'])
assert image == c.read(path.parent / 'dense-image.json')
env, _ = b.environment(link['command'], link['inputs'], out)
command = [image['path'], '--gtest_filter=' + ':'.join(names),
           '--gtest_output=xml:' + str(out / 'results.xml')]
try:
    c.execute('dense', command, env, out)
finally:
    cases = ET.parse(out / 'results.xml').findall('.//testcase') if (out / 'results.xml').exists() else []
    actual = [r.attrib['classname'] + '.' + r.attrib['name'] for r in cases]
    passed = (len(cases) == len(names) and set(actual) == set(names) and
        all(not any(r.find(tag) is not None for tag in ('failure', 'error', 'skipped')) for r in cases))
    c.save(out / 'summary.json', dict(passed=passed, cases=len(cases), names=actual,
        exact_filters=names, skipped=sum(r.find('skipped') is not None for r in cases),
        image=image, build_plan=b.identity(path), GPU_run=True, SDK_rebuild=False))
if not passed:
    raise ValueError('Expected every selected CUDA case without skip/failure')
print('DENSE_INDEXER_TESTS', len(cases), 'passed', flush=True)
