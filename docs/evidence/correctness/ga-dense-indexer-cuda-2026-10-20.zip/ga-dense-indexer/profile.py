"""Collect one directed carrier/capture trace; do not interpret it as throughput."""
from pathlib import Path
import collections
import importlib.util
import sqlite3
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dense_profile_build', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(c.read(S / 'latest-check.json')['plan'])
plan = c.read(path)
m.check(plan)
assert c.read(S / 'tests-final/summary.json')['passed']
assert c.read(S / 'correctness-final/summary.json')['passed']
out = S / 'profile'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
link = plan['links']['dense']
image = b.identity(link['image'])
assert image == c.read(path.parent / 'dense-image.json')
tool = c.read(S.parent / 'cast-stable-silu/profile/profile.command.json')['command'][0]
argv = [tool, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
    '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only',
    '--discard-environment=true', '--output=' + str(out / 'capture'),
    image['path'], '--gtest_filter=CudaDenseIndexer.PaddedBatchKeysKeepIndependentSlotsAndRetainedResults']
env, _ = b.environment(link['command'], link['inputs'], out)
c.save(out / 'inputs.json', dict(runner=b.identity(Path(__file__)), build_plan=b.identity(path),
    image=image, command=argv, fresh_model_processes=0, directed_test_processes=1,
    profiler=True, throughput_claim=False))
c.execute('profile', argv, env, out)
c.execute('export', [tool, 'export', '--type=sqlite', '--output=' + str(out / 'capture.sqlite'),
    str(out / 'capture.nsys-rep')], env, out)
db = sqlite3.connect('file:' + (out / 'capture.sqlite').resolve().as_posix() + '?mode=ro', uri=True)
db.row_factory = sqlite3.Row
strings = dict(db.execute('SELECT id,value FROM StringIds'))
kernels = [dict(r) for r in db.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL')]
symbols = collections.Counter(strings[r['demangledName']] for r in kernels)
launches = [dict(r) for r in db.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_RUNTIME')
    if strings[r['nameId']].startswith('cudaGraphLaunch')]
db.close()
publishes = {k: v for k, v in symbols.items() if 'write_dense_scores<' in k}
summary = dict(passed=len(launches) == 8 and sum(publishes.values()) == 32,
    kernels=len(kernels), graph_launches=len(launches), publish_kernels=publishes,
    per_symbol=dict(symbols), image=image, sqlite=b.identity(out / 'capture.sqlite'),
    captured_runs_expected=8, actual_B2_key_tiles_per_run=4,
    physical_kernel_count_is_observed_not_the_region_dispatch_cost=True,
    throughput_claim=False, model_speed_claim=False,
    limits='One B2/T2/H3/D32/L257 test with +2B batch gap, two slots/two rounds, mask/no-mask. No full GA model, cross-platform, empty bus-read or peak memory claim.')
c.save(out / 'summary.json', summary)
print('DENSE_PROFILE', {k: v for k, v in summary.items() if k in ('passed', 'kernels', 'graph_launches', 'publish_kernels')}, flush=True)
if not summary['passed']:
    raise ValueError('Expected eight captured submissions and thirty-two actual typed publications')
