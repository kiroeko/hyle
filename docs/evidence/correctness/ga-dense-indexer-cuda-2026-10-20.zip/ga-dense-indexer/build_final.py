"""Refresh three metadata-boundary owners and the migrated paged fixture only."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dense_final_build', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
BASE = S / 'checks/20261019T182917'
REG = S / 'regression-build'
out = S / 'checks' / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-metadata-boundaries')
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
frozen = [b.identity(Path(__file__)), b.identity(S / 'build.py')]
for name in ('provider-source-freeze.json', 'graph-source-freeze.json',
             'tests-source-freeze.json', 'paged-fixture-source-freeze.json'):
    seal = S / name
    frozen.append(b.identity(seal))
    document = c.read(seal)
    files = document.get('files', [document] if 'after' in document else [])
    for row in files:
        after = row['after']
        actual = b.identity(after['path'])
        assert all(actual[k] == after[k] for k in ('bytes', 'sha256'))
        frozen.append(actual)
rows = []
for tag, recipe_path in [('native-provider', BASE / 'native-provider-identity.json'),
                         ('indexer-provider', BASE / 'indexer-provider-identity.json'),
                         ('region', BASE / 'region-identity.json'),
                         ('paged-test', REG / 'paged-test-identity.json')]:
    recipe = c.read(recipe_path)
    source = Path(recipe['source']['path'])
    command = b.host_command(recipe['command'], source, tag, out)
    row = dict(tag=tag, kind='host', source=b.identity(source), recipe=b.identity(recipe_path),
        command=command, object=str(out / (tag + '.obj')), old_object=recipe['object'])
    rows.append(row)
    frozen += [row['source'], row['recipe'], *(b.identity(p) for p in b.host_dependencies(recipe['command']))]
    snapshot = out / 'compiled-source' / source.relative_to(m.ROOT)
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    frozen.append(b.identity(snapshot))
qwen = c.read(BASE / 'qwen-link-plan.json')
dense = c.read(REG / 'dense-link-plan.json')
cached = {c.key(r['path']): r for link in (qwen, dense) for r in link['inputs']}
for row in rows:
    assert cached[c.key(row['old_object']['path'])] == row['old_object']
replacement = {c.key(r['old_object']['path']): r['object'] for r in rows}
links = {}
for arm, base in [('qwen', qwen), ('dense', dense)]:
    command = [replacement.get(c.key(x), x) for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    inputs = [x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj', '.lib'))
              and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    assert len(inputs) == (130 if arm == 'qwen' else 134)
    links[arm] = dict(command=command, inputs=inputs, image=str(image))
plan = dict(compile=rows, links=links, cached_inputs=list(cached.values()),
    frozen=list({c.key(r['path']): r for r in frozen}.values()),
    fresh_product_host_TUs=3, fresh_test_host_TUs=1, native_TUs=0,
    SDK_build=False, common_executor_changed=False, public_ABI_changed=False,
    scope='Metadata Views remain original Graph boundaries. All typed CUDA tile kernels and contexts are reused.')
path = out / 'plan.json'
c.save(path, plan)
print('PLAN', path, flush=True)
m.check(plan)
for row in plan['cached_inputs']:
    assert b.same(row), row['path']
identities = dict(cached)
env, _ = b.environment(links['qwen']['command'], [r['path'] for r in cached.values()], out)
for row in rows:
    c.execute(row['tag'] + '-compile', row['command'], env, out)
    m.check(plan)
    data = c.read(out / (row['tag'] + '-deps.json'))['Data']
    record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
        dependencies=[b.identity(p) for p in [data['Source'], *data['Includes']]])
    c.save(out / (row['tag'] + '-identity.json'), record)
    identities[c.key(row['object'])] = record['object']
for arm, link in links.items():
    c.execute(arm + '-link', link['command'], env, out)
    m.check(plan)
    c.save(out / (arm + '-link-plan.json'), dict(command=link['command'],
        inputs=[identities[c.key(p)] for p in link['inputs']]))
    c.save(out / (arm + '-image.json'), b.identity(link['image']))
c.save(out / 'summary.json', dict(passed=True, fresh_product_host_TUs=3,
    fresh_test_host_TUs=1, native_TUs=0, SDK_build=False, GPU_run=False))
c.save(S / 'latest-check.json', dict(plan=str(path)))
print('BUILD_COMPLETE', path, flush=True)
