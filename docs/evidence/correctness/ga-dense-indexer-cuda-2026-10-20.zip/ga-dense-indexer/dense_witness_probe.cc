// Diagnostic replacement for the existing graph-test TU. Run only
// CudaDenseIndexerDiagnostic.WitnessColdNativeAndGraphSelection. No product edit.
#include "C:/public/project-hyle/hyle/tests/graph_route_cuda/ga_dense_indexer_test.cc"
#include "C:/public/project-hyle/hyle/src/compute_provider_cuda/dense_bfloat_scores.h"
#include "C:/public/project-hyle/hyle/src/compute_provider_cuda/row_cache_indexer_provider.h"
#include <iostream>

TEST(CudaDenseIndexerDiagnostic, WitnessColdNativeAndGraphSelection) {
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  const auto f = build({});
  const auto operation = c::Operation::custom(
      c::cuda_native::internal::DenseBfloatScores{true,c::DataType::kFloat32});
  std::array<c::TensorDesc,1> output_desc{f.graph.value_description(f.score).value()};
  std::array<c::detail::ResourceBindingRequirement,4> input_requirements{};
  std::array<c::detail::ResourceBindingRequirement,1> output_requirements{};
  c::detail::ProviderOperationProposal proposal;
  const auto proposed = c::cuda_native::row_cache_indexer::propose(
      {.operation=operation,.inputs=f.descriptions,.outputs=output_desc},
      input_requirements,output_requirements,&proposal);
  std::cout << "DENSE_WITNESS_NATIVE_PROPOSE ok=" << proposed.ok()
            << " route=" << proposal.route << " message=" << proposed.message() << '\n';
  ASSERT_TRUE(proposed.ok()) << proposed.message();
  // Allocate truthful views only; do not upload data, create an invocation,
  // submit math or call an alternative Lt implementation.
  auto bindings = allocate(f,memory.ref(),0,true,false);
  std::array<c::ConstTensorView,4> inputs;
  for (std::size_t i=0;i<inputs.size();++i) inputs[i]=bindings.input[i].view.as_const();
  std::array<c::TensorView,1> outputs{bindings.output.view};
  auto native = c::prepare(context,operation,inputs,outputs);
  std::cout << "DENSE_WITNESS_NATIVE_PREPARE ok=" << bool(native);
  if (native) std::cout << " workspace=" << native->workspace_requirement().size;
  else std::cout << " message=" << native.error().message();
  std::cout << '\n';
  auto compiled = g::cuda::compile(f.graph,context,memory.ref());
  ASSERT_TRUE(compiled) << compiled.error().message();
  const auto search = compiled->report.search();
  std::cout << "DENSE_WITNESS_GRAPH_SEARCH region_proposals=" << search.region_proposals
            << " region_route_rejections=" << search.region_route_rejections << '\n';
  std::size_t dense_steps=0;
  for (std::size_t i=0;i<compiled->report.step_count();++i) {
    const auto step=compiled->report.step(i);
    ASSERT_TRUE(step);
    dense_steps += step->policy==kScorePolicy;
    std::cout << "DENSE_WITNESS_STEP index=" << i << " kind=" << unsigned(step->kind)
              << " native_score=" << (step->policy==kScorePolicy)
              << " nodes=" << step->node_count << '\n';
  }
  std::cout << "DENSE_WITNESS_CONCLUSION native_prepared=" << bool(native)
            << " selected_dense_regions=" << dense_steps << '\n';
}
