"""Keep five compiled owners; correct nvcc dependency flags and add capture assertions."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dense_finish_build', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
old_path = Path(sys.argv[1]).resolve()
old = c.read(old_path)
out = old_path.parent
assert not (out / 'summary.json').exists()
assert c.read(out / 'indexer-kernel-compile-1.result.json')['exit'] != 0
assert 'requires one of' in ''.join((out / ('indexer-kernel-compile-1.' + kind + '.log')).read_text()
                                  for kind in ('stdout', 'stderr'))
assert not (out / 'indexer-kernel.obj').exists()
assert not (out / 'graph-test-identity.json').exists()
for row in old['compile'][:5]:
    actual = c.read(out / (row['tag'] + '-identity.json'))
    assert b.same(actual['object']) and all(b.same(dep) for dep in actual['dependencies'])
plan = c.read(old_path)
changed = {c.key(m.ROOT / 'tests/graph_route_cuda/ga_dense_indexer_test.cc'),
           c.key(S / 'tests-source-freeze.json')}
for row in plan['frozen']:
    if c.key(row['path']) in changed:
        row.update(b.identity(row['path']))
    else:
        assert b.same(row), row['path']
kernel = next(r for r in plan['compile'] if r['tag'] == 'indexer-kernel')
assert '-MF' in kernel['command'] and not any(x in kernel['command'] for x in ('-M', '-MM', '-MD', '-MMD'))
kernel['command'].append('-MD')
test = next(r for r in plan['compile'] if r['tag'] == 'graph-test')
test['source'] = b.identity(test['source']['path'])
snapshot = out / 'compiled-source-capture/tests/graph_route_cuda/ga_dense_indexer_test.cc'
snapshot.parent.mkdir(parents=True, exist_ok=False)
snapshot.write_bytes(Path(test['source']['path']).read_bytes())
test['actual_source_snapshot'] = b.identity(snapshot)
plan['frozen'] += [test['actual_source_snapshot'], b.identity(Path(__file__)), b.identity(old_path)]
plan['initial_build'] = dict(plan=b.identity(old_path), compiled_host_TUs=5,
    successful_device_compiles=0, product_compile_errors=0,
    driver_error='nvcc -MF without -MD; dependency option parser rejected before device compile',
    final_test_update='RequireCapture assertions in the same four cases before first test compilation')
path = out / 'plan-capture.json'
assert not path.exists()
c.save(path, plan)
m.check(plan)
print('RESUME_PLAN', path, flush=True)
