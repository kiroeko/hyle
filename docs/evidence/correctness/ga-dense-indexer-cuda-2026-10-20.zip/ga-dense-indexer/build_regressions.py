"""Refresh two current fixture owners; do not link retired Graph API objects."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dense_regression_build', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(sys.argv[1]).resolve()
base = c.read(path)
m.check(base)
out = S / 'regression-build'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
recipe = c.read(path.parent / 'graph-test-identity.json')
review = c.read(S / 'regression-owner-review.json')
rows = []
for tag, entry in zip(('paged-test', 'packed-test'), review['tests']):
    source = Path(entry['source']['path'])
    command = b.host_command(recipe['command'], source, tag, out)
    command[1:1] = ['/I' + str(m.ROOT)]
    if tag == 'paged-test':
        command[1:1] = ['/DHYLE_ROW_CACHE_GRAPH_CUDA=1']
    rows.append(dict(tag=tag, source=b.identity(source), command=command,
                     object=str(out / (tag + '.obj'))))
link = dict(base['links']['dense'])
link['command'] = [x for x in link['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
link['command'][1:1] = [r['object'] for r in rows]
link['inputs'] = [*link['inputs'], *(r['object'] for r in rows)]
link['image'] = str(out / 'regression.exe')
link['command'] += ['/OUT:' + link['image'], '/MAP:' + str(out / 'regression.map'),
                    '/IMPLIB:' + str(out / 'regression.lib')]
identities = {c.key(r['path']): r for r in c.read(path.parent / 'dense-link-plan.json')['inputs']}
assert len(identities) == 132
plan = dict(compile=rows, links={'dense': link},
    frozen=[b.identity(Path(__file__)), b.identity(path), b.identity(S / 'regression-owner-review.json'),
            *(r['source'] for r in rows)], cached_inputs=list(identities.values()),
    product_TUs=0, test_TUs=2, SDK_build=False)
c.save(out / 'plan.json', plan)
for r in plan['cached_inputs']:
    assert b.same(r), r['path']
env, _ = b.environment(link['command'], link['inputs'], out)
for row in rows:
    c.execute(row['tag'] + '-compile', row['command'], env, out)
    data = c.read(out / (row['tag'] + '-deps.json'))['Data']
    record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
                  dependencies=[b.identity(p) for p in [data['Source'], *data['Includes']]])
    c.save(out / (row['tag'] + '-identity.json'), record)
    identities[c.key(row['object'])] = record['object']
    m.check(plan)
c.execute('regression-link', link['command'], env, out)
m.check(plan)
c.save(out / 'dense-link-plan.json', dict(command=link['command'],
    inputs=[identities[c.key(p)] for p in link['inputs']]))
c.save(out / 'dense-image.json', b.identity(link['image']))
c.save(out / 'summary.json', dict(passed=True, test_TUs=2, product_TUs=0, SDK_build=False, GPU_run=False))
print('REGRESSION_IMAGE_READY', out / 'plan.json', flush=True)
