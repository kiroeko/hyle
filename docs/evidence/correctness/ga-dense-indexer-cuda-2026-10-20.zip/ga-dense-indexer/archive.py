"""Archive final dense-score evidence only after real tests/model pass.

No build, GPU work, cleanup or duplicate tensor payloads. Historical attempts
remain evidence, including the first private-port diagnostic and failed links.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT / 'docs/evidence/correctness/ga-dense-indexer-cuda-2026-10-20.zip'
PREFIX = 'ga-dense-indexer/'
OMIT = {'.exe','.obj','.map','.lib','.exp','.pdb','.dll','.pyc','.tmp',
        '.ptx','.cubin','.fatbin','.res','.ilk','.zip','.bin','.bf16','.f32',
        '.f16','.raw','.pt','.safetensors','.gguf','.so','.dylib'}
SOURCE = {'.h','.hpp','.cuh','.cc','.cpp','.c','.cu','.cmake'}
DOCS = ('docs/architecture/compute-design.md','docs/architecture/graph-design.md',
        'docs/implementation/model-operators.md','docs/developer/current-work.md',
        'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def key(path):
    return str(Path(path).resolve()).casefold()


def matches(path, row):
    actual = identity(path)
    return all(actual[field] == row[field] for field in ('bytes','sha256'))


def save(path, value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def eligible(path):
    parts = {part.casefold() for part in path.relative_to(STAGE).parts}
    return (path.suffix.casefold() not in OMIT and
        not parts.intersection({'tmp','__pycache__','sdk','cache','trace','vectors','models'}) and
        not re.search(r'\.(?:cudafe|fatbin|module_id|cu\.cpp)',path.name,re.I) and
        path.name not in {'archive-receipt.json','archive-verification.json',
            'archive-scope.json','payload-sha256.json'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan',type=Path)
    args = parser.parse_args()
    plan_path = (args.build_plan or Path(read(STAGE/'latest-check.json')['plan'])).resolve()
    assert plan_path.is_relative_to(STAGE/'checks')
    plan, plan_id = read(plan_path), identity(plan_path)
    assert read(plan_path.parent/'summary.json')['passed']
    assert key(read(STAGE/'latest-check.json')['plan']) == key(plan_path)
    if DEST.exists():
        raise ValueError('Archive already exists; refusing replacement')
    tests = read(STAGE/'tests-final/summary.json')
    cases = ET.parse(STAGE/'tests-final/results.xml').findall('.//testcase')
    names = [case.attrib['classname']+'.'+case.attrib['name'] for case in cases]
    assert tests['passed'] and tests['cases']==len(cases)==11 and tests['skipped']==0
    assert len(set(names))==11 and set(names)==set(tests['names'])==set(tests['exact_filters'])
    assert all(not any(case.find(tag) is not None for tag in ('failure','error','skipped')) for case in cases)
    assert tests['build_plan']==plan_id
    test_run=read(STAGE/'tests-final/dense.result.json')
    assert test_run['exit']==0 and test_run['terminal']
    model=read(STAGE/'correctness-final/summary.json')
    observed=model['observation']
    assert model['passed'] and observed['equal_vectors']==len(observed['vectors'])==64
    assert observed['all_outputs_finite'] and observed['same_greedy_ids_as_reference']
    assert observed['same_fixed_decode_inputs'] and len(observed['generated_ids'])==32
    assert len(observed['decode_input_ids'])==31
    assert observed['process']['exit']==0 and observed['process']['terminal']
    assert all(row['byte_equal'] and row['actual']['sha256']==row['reference']['sha256']
               and row['actual']['bytes']==row['reference']['bytes'] for row in observed['vectors'])
    assert read(STAGE/'correctness-final/inputs.json')['plan']==plan_id
    qwen=read(plan_path.parent/'qwen-image.json')
    dense=read(plan_path.parent/'dense-image.json')
    assert observed['image']==qwen and tests['image']==dense
    # Check final tested images once; retain their identities, not image bytes.
    assert matches(qwen['path'],qwen) and matches(dense['path'],dense)

    payloads, sources, owners = {}, [], []
    def add(path,name):
        path=Path(path).resolve()
        assert path.is_file() and path.is_relative_to(ROOT) and not path.is_symlink(),path
        assert name not in payloads or payloads[name]==path,name
        payloads[name]=path

    # All actual stage failures, before/after snapshots, diagnostics, commands,
    # sourceDependencies and identities are dynamic: do not freeze incomplete
    # results while this helper is merely being prepared.
    stage_files=[path for path in STAGE.rglob('*') if path.is_file() and eligible(path)]
    candidates={}
    for path in stage_files:
        if path.suffix.casefold() in SOURCE or path.name=='CMakeLists.txt':
            candidates.setdefault(path.name,[]).append(path)
    def source_for(row):
        path=Path(row['path']).resolve()
        if path.is_file() and matches(path,row):
            return path
        # Older owner receipts legitimately refer to headers/source superseded
        # in this batch. Resolve by exact bytes to retained historical snapshots.
        for snapshot in candidates.get(path.name,[]):
            if matches(snapshot,row):
                return snapshot
        raise ValueError('No exact retained source for compiled identity: '+str(path))

    for freeze_name in ('provider-source-freeze.json','graph-source-freeze.json',
                        'tests-source-freeze.json','paged-fixture-source-freeze.json'):
        freeze=read(STAGE/freeze_name)
        rows=freeze.get('files',[freeze] if 'after' in freeze else [])
        assert rows,freeze_name
        for row in rows:
            name=row.get('path',row.get('source'))
            for version in ('before','after'):
                record=row.get(version)
                if not record or not record.get('exists',True): continue
                path=source_for(record)
                add(path,PREFIX+version+'-source/'+name)
                sources.append(dict(logical_path=name,version=version,identity=record,
                                    retained_payload_source=identity(path)))
            assert matches(ROOT/name,row['after']),name

    for receipt_path in sorted(STAGE.rglob('*-identity.json')):
        record=read(receipt_path)
        if not isinstance(record,dict) or not all(k in record for k in ('source','object','command')):
            continue
        if not isinstance(record['source'],dict) or not isinstance(record['object'],dict):
            continue
        for row in [record['source'],*record.get('dependencies',[])]:
            path=Path(row['path']).resolve()
            if (not path.is_relative_to(ROOT) or
                    path.relative_to(ROOT).parts[0] not in ('include','src','tests','third_party','cmake')):
                continue
            if path.suffix.casefold() not in SOURCE and path.name!='CMakeLists.txt': continue
            retained=source_for(row)
            # Namespace by content identity so old/new private schemas both
            # remain truthful even when their original physical path is equal.
            add(retained,PREFIX+'compiled-dependencies/'+row['sha256']+'/'+path.relative_to(ROOT).as_posix())
        owners.append(dict(receipt=identity(receipt_path),source=record['source'],object=record['object']))
    for row in plan['frozen']:
        path=Path(row['path']).resolve()
        if path.suffix.casefold() in OMIT: continue
        assert matches(path,row),path
        if not path.is_relative_to(STAGE):
            add(path,PREFIX+'support/'+path.relative_to(ROOT).as_posix())
    # Retain literal Python helper imports only, never recursively copy an SDK
    # or an older stage. Their historical source-freeze routines are not run.
    pending,seen=list(STAGE.rglob('*.py')),set()
    while pending:
        path=pending.pop().resolve()
        if path in seen or '__pycache__' in path.parts: continue
        assert path.is_file() and path.is_relative_to(ROOT),path
        seen.add(path)
        for variable,base in (('ARCH',ARCH),('STAGE',path.parent),('ROOT',ROOT)):
            pending += [base/name for name in re.findall(variable+r"\s*/\s*['\"]([^'\"]+\.py)['\"]",path.read_text(encoding='utf-8'))]
        if not path.is_relative_to(STAGE):
            add(path,PREFIX+'support/'+path.relative_to(ROOT).as_posix())
    for name in DOCS:
        add(ROOT/name,PREFIX+'support/'+name)
    for name in ('cast-stable-silu/archive-receipt.json','batch-graph-capture/archive-receipt.json',
                 'binding-port-reuse/archive-receipt.json'):
        path=ARCH/name
        if path.is_file(): add(path,PREFIX+'reference-provenance/'+name)
    for dirname in ('correctness','correctness-final'):
        path=STAGE/dirname/'inputs.json'
        if path.exists():
            for name in ('manifest','prompt','decode'):
                row=read(path)[name]
                assert matches(row['path'],row)
                target=Path(row['path']).resolve()
                add(target,PREFIX+'support/'+target.relative_to(ROOT).as_posix())
    for path in stage_files:
        add(path,PREFIX+path.relative_to(STAGE).as_posix())
    links={arm:identity(plan_path.parent/(arm+'-link-plan.json')) for arm in ('qwen','dense')}
    scope=dict(final_build_plan=plan_id,final_links=links,final_images=dict(qwen=qwen,dense=dense),
        tests=names,equal_vectors=64,source_versions=sources,owner_receipts=owners,
        private_ports_version=2,public_Op_changed=False,new_executor=False,SDK_rebuilt=False,
        retained_history='Initial fixture type/name/driver-link corrections, retired-API regression-object rejection, first mixed-port math pass but dense witness region miss, cold native/Lt probe and actual View-boundary correction are retained with actual commands/logs/source identities.',
        historical_probe_limit='The probe was actually compiled against the retained first rank3-K/W private schema. It proved the first Lt cold path and first Graph selection miss. It is historical evidence; do not compile it unchanged against the new rank4-Kt/Wr schema.',
        raw_vector_policy='No repeated BF16/F32 vector bodies. Both actual comparison records preserve every actual/reference path, bytes and SHA; prior archive receipts establish provenance chains without asserting each prior ZIP contains raw vectors.',
        omitted='Images/objects/maps/libraries/debug/SDK/CUDA temporary code/model payloads/duplicate64tensor bodies. JSON identities, native dependency paths and all actual raw command logs remain.',
        limits='Directed CUDA typed scorer/packed/paged regressions and fixed-tape Qwen64 comparison; not GA full-model execution, model quality, all hardware/Lt shapes or a throughput claim.',
        build_or_GPU_run_by_archive=False,cleanup_executed=False)
    manifest={name:identity(path) for name,path in sorted(payloads.items())}
    scope_bytes=(json.dumps(scope,ensure_ascii=False,indent=2)+'\n').encode()
    manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(payloads.items()): archive.write(path,name)
        archive.writestr('archive-scope.json',scope_bytes)
        archive.writestr('payload-sha256.json',manifest_bytes)
    expected={name:row['sha256'] for name,row in manifest.items()}
    expected.update({'archive-scope.json':digest(scope_bytes),'payload-sha256.json':digest(manifest_bytes)})
    # One decompression pass checks CRC, byte length and SHA of every payload.
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist())==len(expected)
        for info in archive.infolist():
            h,crc,size=hashlib.sha256(),0,0
            with archive.open(info) as stream:
                while chunk:=stream.read(1024*1024):
                    h.update(chunk);crc=zlib.crc32(chunk,crc);size+=len(chunk)
            assert size==info.file_size and crc&0xffffffff==info.CRC,info.filename
            assert h.hexdigest()==expected[info.filename],info.filename
    receipt=dict(**identity(DEST),entries=len(expected),payloads=len(manifest),
        CRC_and_every_payload_SHA_verified=True,crc_verified=True,payload_sha256_verified=True,
        verification_passes=1,build_plan=plan_id,tests=11,equal_vectors=64,
        duplicate_raw_vectors_omitted=True,historical_failures_and_probe_retained=True,
        SDK_rebuilt=False,throughput_claim=False,cleanup_executed=False)
    save(STAGE/'archive-receipt.json',receipt)
    save(DEST.with_name(DEST.stem+'-archive.json'),receipt)
    print(json.dumps(receipt,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
