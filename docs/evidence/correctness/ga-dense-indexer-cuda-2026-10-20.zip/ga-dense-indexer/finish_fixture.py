"""Refresh the test fixture type name only; retain all six compiled product owners."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dense_fixture_build', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
old_path = Path(sys.argv[1]).resolve()
out = old_path.parent
plan = c.read(old_path)
assert not (out / 'summary.json').exists()
assert not (out / 'graph-test-identity.json').exists()
for row in plan['compile'][:-1]:
    actual = c.read(out / (row['tag'] + '-identity.json'))
    assert b.same(actual['object']) and all(b.same(dep) for dep in actual['dependencies'])
changed = {c.key(m.ROOT / 'tests/graph_route_cuda/ga_dense_indexer_test.cc'),
           c.key(S / 'tests-source-freeze.json')}
for row in plan['frozen']:
    if c.key(row['path']) in changed:
        row.update(b.identity(row['path']))
    else:
        assert b.same(row), row['path']
test = next(r for r in plan['compile'] if r['tag'] == 'graph-test')
test['source'] = b.identity(test['source']['path'])
snapshot = out / 'compiled-source-fixture/tests/graph_route_cuda/ga_dense_indexer_test.cc'
snapshot.parent.mkdir(parents=True, exist_ok=False)
snapshot.write_bytes(Path(test['source']['path']).read_bytes())
test['actual_source_snapshot'] = b.identity(snapshot)
plan['frozen'] += [test['actual_source_snapshot'], b.identity(Path(__file__)), b.identity(old_path)]
plan['fixture_correction'] = dict(prior_plan=b.identity(old_path),
    completed_product_host_TUs=5, completed_native_TUs=1,
    change='Rename namespace fixture Run to Bindings to avoid GTest Test::Run name lookup inside TEST',
    assertions_and_math_changed=False, prior_compile_result=b.identity(out / 'graph-test-compile-1.result.json'))
path = out / 'plan-fixture.json'
assert not path.exists()
c.save(path, plan)
m.check(plan)
print('RESUME_PLAN', path, flush=True)
