"""Build one source-only diagnostic against the actual current CUDA owners."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dense_probe_build', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
base = S / 'checks/20261019T182917'
out = S / 'probe'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
recipe = c.read(base / 'graph-test-identity.json')
command = b.host_command(recipe['command'], S / 'dense_witness_probe.cc', 'probe', out)
link = c.read(base / 'dense-link-plan.json')
argv = [str(out / 'probe.obj') if c.key(x) == c.key(recipe['object']['path']) else x
        for x in link['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
argv += ['/OUT:' + str(out / 'probe.exe'), '/MAP:' + str(out / 'probe.map'),
         '/IMPLIB:' + str(out / 'probe.lib')]
env, _ = b.environment(argv, [r['path'] for r in link['inputs']], out)
c.save(out / 'inputs.json', dict(runner=b.identity(Path(__file__)),
    source=b.identity(S / 'dense_witness_probe.cc'), template=b.identity(base / 'graph-test-identity.json'),
    base_link=b.identity(base / 'dense-link-plan.json'), inputs=link['inputs']))
c.execute('probe-compile', command, env, out)
c.execute('probe-link', argv, env, out)
c.save(out / 'probe-image.json', b.identity(out / 'probe.exe'))
c.execute('probe', [str(out / 'probe.exe'),
    '--gtest_filter=CudaDenseIndexerDiagnostic.WitnessColdNativeAndGraphSelection'], env, out)
print((out / 'probe.stdout.log').read_text(), flush=True)
