from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-identical-capture-inputs-20261027'
spec = importlib.util.spec_from_file_location('generic_output_previous', B / 'build.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
m, h, exact = old.m, old.h, old.exact
m.W = W
CASES = ['GraphOutputSourceCuda.' + name for name in [
    'PendingF32FullWriterSharesIntegerSubmission', 'PendingF16FullWriterSharesIntegerSubmission',
    'PendingBF16FullWriterSharesIntegerSubmission', 'MixedFullWritersPreserveOriginalProducerFailure',
    'TwoOutputsShareOneOriginalSubmissionAndAtomicBundle',
    'ProducerCheckedFailureRejectsConsumerPublicationAfterRetirement',
    'RetiredSourceDetachesWhileReaderPendingAndProducerReusesNewWriter',
    'PendingI32UsesOriginalQueueAndLeasesForCheckedGather']]
PINS = {'src/graph/resources.cc': '1f9d1859b6b444b719d1d163ac00448705d7b8bd40666767d0035bd41f86ae38',
        'include/hyle/graph/detail/output_source.h': 'cd6c66d50ad62ac78f51b31b64581f1ed7dbc9c3f62de483cfc62a0c9ed01799',
        'tests/graph/output_source_cuda_test.cc': '5681c509acaba32d68af7c3a0bd48c27525e0da8d02ab7db550e99af579d6fc7'}

def environment():
    env = dict(os.environ); env.update(m.read(B / 'environment.json'))
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    for key in ['HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE']: env[key] = '1'
    return env

def tokens(text):
    return re.findall(r'\w+|[^\s]', re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S))

def freeze():
    assert not (W / 'plan.json').exists()
    cli = m.read(B / 'cli-link-inputs.json'); component = m.read(B / 'test-link-inputs2.json')
    assert len(cli) == 224 and len(component) == 241
    for row in {m.key(x['path']): x for x in cli + component}.values(): exact(row)
    ci, ti = m.index(cli), m.index(component)
    resource = ci[m.key(R / 'src/graph/resources.cc')]
    test = ti[m.key(R / 'tests/graph/output_source_cuda_test.cc')]
    assert resource['object'] == ti[m.key(R / 'src/graph/resources.cc')]['object']
    graph = ci[m.key(R / 'src/graph/executable.cc')]
    assert graph['object'] == ti[m.key(R / 'src/graph/executable.cc')]['object']
    assert hashlib.sha256(Path(graph['data']['Source']).read_bytes()).hexdigest() == 'f160c92d3d369de9b469b0976ae4a42a1928f6c4265f13345c2cbff1d1010e6f'
    owned = []
    for relative, digest in PINS.items():
        source = R / relative; pin = m.pin(source); assert pin['sha256'] == digest
        snapshot = W / 'source' / relative; snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes()); owned.append(dict(original=pin, snapshot=m.pin(snapshot)))
    header = 'include/hyle/graph/detail/output_source.h'
    previous = subprocess.run(['git', 'show', 'HEAD:' + header], cwd=R, check=True, capture_output=True).stdout
    current = (R / header).read_bytes()
    assert tokens(previous.decode()) == tokens(current.decode()), 'public detail header changed executable tokens'
    baseline_header = W / 'source/output_source-before.h'; baseline_header.write_bytes(previous)
    pre, units = {}, []
    specifications = [
        ('resources', 'src/graph/resources.cc', resource,
         R / '.scratch/inference-generation-continuation-20261027/logs/resources2/command.json'),
        ('output-test', 'tests/graph/output_source_cuda_test.cc', test,
         R / '.scratch/inference-deferred-source-bind-20261027/logs/output_source/command.json')]
    for name, relative, record, recipe in specifications:
        source = R / relative; snapshot = W / 'source' / relative; out = W / 'compile' / name
        template = m.read(recipe)['command']; command = []
        for i, arg in enumerate(template):
            if i and template[i - 1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(snapshot)
            command.append(arg)
        command[1:1] = ['/I' + str(R / 'include'), '/I' + str(source.parent)]
        assert m.build_contract(command) == m.build_contract(template)
        for path in [record['data']['Source'], *record['data']['Includes'], source, snapshot]:
            pre[m.key(path)] = m.pin(path)
        m.save(W / 'recipes' / (name + '.json'), dict(command=command, template=m.pin(recipe)))
        units.append(dict(name=name, source=m.pin(snapshot), original_source=m.pin(source),
                          original=record, recipe=m.pin(recipe), command=command, object=str(out / 'unit.obj')))
    for row in owned: pre[m.key(row['original']['path'])] = row['original']
    source_text = (R / 'tests/graph/output_source_cuda_test.cc').read_text()
    names = [a + '.' + b for a, b in re.findall(r'\bTEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', source_text)]
    assert len(names) == len(set(names)) and set(CASES) <= set(names)
    (W / 'bin').mkdir(exist_ok=True)
    runtime = m.read(R / '.scratch/inference-generation-batch-continuation-20261027/runtime.json')
    cpu = runtime['original_native_cpu']; exact(cpu)
    alias = W / 'bin' / Path(cpu['path']).name
    if not alias.exists(): os.link(cpu['path'], alias)
    env = environment()
    m.save(W / 'environment.json', {k: env.get(k, '') for k in ['PATH', 'INCLUDE', 'LIB', 'LIBPATH']})
    m.save(W / 'runtime.json', dict(baseline=m.pin(B / 'runtime.json'), original_native_cpu=cpu,
                                   alias=m.pin(alias), PATH=env['PATH']))
    m.save(W / 'precompile-dependencies.json', list(pre.values()))
    m.save(W / 'plan.json', dict(status='FROZEN_NOT_BUILT', sources=owned, units=units,
        baselines=dict(cli=dict(ready=m.pin(B / 'ready-cli.json'), inputs=m.pin(B / 'cli-link-inputs.json'),
                                recipe=m.pin(B / 'link-cli/command.json')),
                       component=dict(ready=m.pin(B / 'ready-test2.json'), inputs=m.pin(B / 'test-link-inputs2.json'),
                                      recipe=m.pin(B / 'link-test2/command.json'))),
        dependencies=m.pin(W / 'precompile-dependencies.json'), runtime=m.pin(W / 'runtime.json'), tests=CASES,
        header_reuse_exception=dict(before=m.pin(baseline_header), after=m.pin(R / header),
            tokens_equal=True, reason='Only comments changed in detail header; declarations/layout unchanged. Reuse Model/Graph/other old objects.'),
        counts=dict(CXX=2, links=2, cli_inputs=224, component_inputs=241, unique_tests=8, SDK=0, NVCC=0, downloads=0),
        scope='Full caller-owned plain dense tensor relay; finite real CUDA F32/F16/BF16 Gather consumers. No Store subset, MTP relay or model/TPS run. Baseline deleted component image is not required or rehashed.'))
    print('FROZEN 2 CXX / 2 links / 8 unique cases; GPU not run', flush=True)

def compile_unit(name):
    plan = m.read(W / 'plan.json'); unit = next(x for x in plan['units'] if x['name'] == name)
    for row in plan['sources']: exact(row['original']); exact(row['snapshot'])
    exact(unit['recipe']); pre = {m.key(x['path']): x for x in m.read(plan['dependencies']['path'])}
    for row in pre.values(): exact(row)
    out = Path(unit['object']).parent; out.mkdir(parents=True, exist_ok=False)
    process = h.execute(unit['command'], environment(), W / 'logs' / name, timeout=240)
    data = m.read(out / 'dependencies.json')['Data']; assert m.key(data['Source']) == m.key(unit['source']['path'])
    deps = [m.pin(x) for x in dict.fromkeys([data['Source'], *data['Includes']])]
    for row in deps:
        before = pre.get(m.key(row['path']))
        if before: assert row == before, ('changed during CXX', row['path'])
        else: assert not Path(row['path']).resolve().is_relative_to(R), ('unfrozen local include', row['path'])
    for row in plan['sources']: exact(row['original']); exact(row['snapshot'])
    m.save(out / 'actual-dependencies.json', deps)
    m.save(out / 'compiled.json', dict(name=name, source=unit['source'], original_source=unit['original_source'],
        object=m.pin(out / 'unit.obj'), command=m.pin(W / 'logs' / name / 'command.json'), process=process,
        compiler_dependencies=m.pin(out / 'dependencies.json'), actual_dependencies=m.pin(out / 'actual-dependencies.json')))
    print('COMPILED ' + name, flush=True)

def link(kind):
    plan = m.read(W / 'plan.json'); base = plan['baselines'][kind]
    selected = [x for x in plan['units'] if kind == 'component' or x['name'] == 'resources']
    compiled = {u['name']: m.read(W / 'compile' / u['name'] / 'compiled.json') for u in selected}
    substitutions = {m.key(u['original']['object']['path']): compiled[u['name']]['object']['path'] for u in selected}
    replacement_rows = {m.key(u['original']['object']['path']): compiled[u['name']]['object'] for u in selected}
    inputs = [replacement_rows.get(m.key(x['path']), x) for x in m.read(base['inputs']['path'])]
    assert len(inputs) == (224 if kind == 'cli' else 241)
    for row in inputs: exact(row)
    for value in compiled.values():
        for field in ['source', 'original_source', 'object']: exact(value[field])
        for row in m.read(value['actual_dependencies']['path']): exact(row)
    image = W / 'bin' / ('hyle.exe' if kind == 'cli' else 'generic-output-source-test.exe')
    argv = m.link_command(m.read(base['recipe']['path'])['command'], substitutions, [], image)
    m.save(W / (kind + '-link-inputs.json'), inputs)
    process = h.execute(argv, environment(), W / ('link-' + kind), timeout=180)
    for row in inputs: exact(row)
    m.save(W / ('ready-' + kind + '.json'), dict(image=m.pin(image), link=process,
        inputs=m.pin(W / (kind + '-link-inputs.json')), recipe=m.pin(W / ('link-' + kind) / 'command.json'),
        runtime=m.pin(W / 'runtime.json'), plan=m.pin(W / 'plan.json')))
    print('LINKED ' + kind + ' ' + m.pin(image)['sha256'], flush=True)

def run():
    ready = m.read(W / 'ready-component.json'); exact(ready['image'])
    for row in m.read(ready['inputs']['path']): exact(row)
    process = h.execute([ready['image']['path'], '--gtest_color=no', '--gtest_fail_fast',
        '--gtest_filter=' + ':'.join(CASES), '--gtest_output=xml:' + str(W / 'run/results.xml')],
        environment(), W / 'run', timeout=180)
    cases = ET.parse(W / 'run/results.xml').getroot().findall('./testsuite/testcase')
    assert sorted(x.attrib['classname'] + '.' + x.attrib['name'] for x in cases) == sorted(CASES)
    assert all(x.find(tag) is None for x in cases for tag in ['failure', 'error', 'skipped'])
    m.save(W / 'summary.json', dict(status='PASS', process=process, tests=CASES,
        xml=m.pin(W / 'run/results.xml'), cli=m.pin(W / 'ready-cli.json'), component=m.pin(W / 'ready-component.json'),
        counts=dict(CXX=2, links=2, GPU_test_processes=1, passed=8, model_processes=0, SDK=0, NVCC=0, downloads=0),
        scope='Only selected original native Gather consumers and adjacent Source contracts; no general dtype operator or MTP continuation claim.'))
    print('PASS 8/8, 0 skip', flush=True)

if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'freeze': freeze()
        elif action == 'compile': compile_unit(sys.argv[2])
        elif action == 'link': link(sys.argv[2])
        elif action == 'run': run()
        else: raise ValueError(action)
    except BaseException:
        (W / ('failure-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc())
        raise
