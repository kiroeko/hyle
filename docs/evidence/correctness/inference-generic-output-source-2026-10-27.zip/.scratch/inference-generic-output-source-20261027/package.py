"""Package the completed finite W9 window. No build, test, or binary inclusion.

Run only when the owner releases the measurement/diagnostic window. Commands
and dependency hashes describe the original local-cache build; this archive
does not duplicate the SDK or promise a standalone toolchain distribution.
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness'
STEM = 'inference-generic-output-source-2026-10-27'
CASES = ['GraphOutputSourceCuda.' + name for name in [
    'PendingF32FullWriterSharesIntegerSubmission',
    'PendingF16FullWriterSharesIntegerSubmission',
    'PendingBF16FullWriterSharesIntegerSubmission',
    'MixedFullWritersPreserveOriginalProducerFailure',
    'TwoOutputsShareOneOriginalSubmissionAndAtomicBundle',
    'ProducerCheckedFailureRejectsConsumerPublicationAfterRetirement',
    'RetiredSourceDetachesWhileReaderPendingAndProducerReusesNewWriter',
    'PendingI32UsesOriginalQueueAndLeasesForCheckedGather']]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(record):
    assert pin(record['path']) == record, ('changed recorded file', record['path'])


def tokens(text):
    return re.findall(r'\w+|[^\s]', re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    plan, result = read(W / 'plan.json'), read(W / 'summary.json')
    assert result['status'] == 'PASS' and result['process']['exit'] == 0
    assert sorted(result['tests']) == sorted(CASES)
    xml = ET.parse(W / 'run/results.xml').getroot()
    tests = xml.findall('./testsuite/testcase')
    assert sorted(x.attrib['classname'] + '.' + x.attrib['name'] for x in tests) == sorted(CASES)
    assert all(x.find(tag) is None for x in tests for tag in ('failure', 'error', 'skipped'))
    assert result['counts'] == dict(CXX=2, links=2, GPU_test_processes=1, passed=8,
                                   model_processes=0, SDK=0, NVCC=0, downloads=0)
    for item in plan['sources']:
        exact(item['original']); exact(item['snapshot'])
        assert item['original']['sha256'] == item['snapshot']['sha256']
    exception = plan['header_reuse_exception']
    exact(exception['before']); exact(exception['after'])
    assert tokens(Path(exception['before']['path']).read_text()) == tokens(Path(exception['after']['path']).read_text())
    assert exception['tokens_equal'] is True
    builds = [read(W / 'compile' / name / 'compiled.json') for name in ('resources', 'output-test')]
    for build in builds:
        assert build['process']['exit'] == 0
        for field in ('source', 'original_source', 'command', 'compiler_dependencies', 'actual_dependencies'):
            exact(build[field])
    ready = {kind: read(W / ('ready-' + kind + '.json')) for kind in ('cli', 'component')}
    for kind, count in [('cli', 224), ('component', 241)]:
        item = ready[kind]
        assert item['link']['exit'] == 0
        for field in ('image', 'inputs', 'recipe', 'runtime', 'plan'):
            exact(item[field])
        assert len(read(item['inputs']['path'])) == count
    exact(result['xml']); exact(result['cli']); exact(result['component'])
    assert read(W / 'run/process.json') == result['process']
    assert 'KeyError:' in (W / 'failure-freeze.log').read_text()

    # Deliberately enumerate only W9 receipts, sources and text logs. Never walk
    # old cache trees, rehash old images, or include executable/object payloads.
    files = set()
    for name in ['package.py', 'check.py', 'check-attempt1.py', 'failure-freeze.log',
                 'plan.json', 'precompile-dependencies.json', 'environment.json',
                 'runtime.json', 'cli-link-inputs.json', 'component-link-inputs.json',
                 'ready-cli.json', 'ready-component.json', 'summary.json']:
        files.add(W / name)
    for folder in ('source', 'recipes', 'logs', 'run', 'link-cli', 'link-component'):
        files.update(x for x in (W / folder).rglob('*') if x.is_file())
    for name in ('resources', 'output-test'):
        for filename in ('compiled.json', 'dependencies.json', 'actual-dependencies.json'):
            files.add(W / 'compile' / name / filename)
    # Preserve baseline/template receipts, not their deleted or retained bins.
    external = {Path(unit['recipe']['path']) for unit in plan['units']}
    for baseline in plan['baselines'].values():
        external.update(Path(baseline[key]['path']) for key in ('ready', 'inputs', 'recipe'))
    external.update([R / '.scratch/inference-identical-capture-inputs-20261027/build.py',
                     R / '.scratch/inference-relay-carriers-20261027/prepare.py'])
    files.update(external)
    forbidden = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.pt', '.gguf', '.spv'}
    members = []
    for path in sorted(files):
        assert path.is_file() and path.suffix.lower() not in forbidden, str(path)
        assert path.resolve().is_relative_to(R)
        name = path.relative_to(R).as_posix()
        data = path.read_bytes()
        members.append(dict(member=name, bytes=len(data), sha256=sha(data)))
    manifest = dict(schema=1, scope='Necessary W9 source, command, dependency and result receipts only.',
                    members=members)
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST / (STEM + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for member in members:
            out.write(R / member['member'], member['member'])
        out.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        assert set(check.namelist()) == {x['member'] for x in members} | {'manifest.json'}
        for member in members:
            data = check.read(member['member'])
            assert len(data) == member['bytes'] and sha(data) == member['sha256']
        assert json.loads(check.read('manifest.json')) == manifest

    receipt = dict(
        schema=1, status='PASS', date='2026-10-27', platform='Windows / actual CUDA shared Queue',
        subject='Generic full caller-owned dense tensor OutputSource',
        implementation=[
            'Removed only the dense-I32 creation policy; retained nonempty plain dense, complete original caller-owned writer and exact tensor/resource/range checks.',
            'Original StorageOwner, pool, actual Queue, one submission Completion and whole Status/retirement contracts remain.',
            'No subview, hidden-source adapter, new executor, native kernel or provider flag changes.'],
        sources=[item['original'] for item in plan['sources']],
        validation=dict(
            counts=result['counts'], tests=CASES, process=result['process'],
            new_cases=CASES[:4], adjacent_cases=CASES[4:],
            actual_checks=[
                'Each finite F32/F16/BF16 case shares one actual I32 plus floating-output submission, then consumes both through a real native checked Gather.',
                'Host gate keeps A pending while B prepares/submits; source_count=1, device_wait_count=1, host_wait_count=0.',
                'Bad last foreign bundle input rejects atomically; ordinary submit rejects pending input; exact output bytes and true retirement are checked.',
                'Both views and common source detach after producer retirement while B remains pending; A reuses different writers and B still reads the original bytes.',
                'Invalid producer index preserves complete native code/message through consumer and detach control cleanup.'],
            builds=[dict(name=x['name'], process=x['process'], object=x['object'],
                         compiler_dependencies=x['compiler_dependencies'], actual_dependencies=x['actual_dependencies']) for x in builds],
            images={kind: dict(image=item['image'], link=item['link'], inputs=item['inputs'],
                               execution='selected component tests' if kind == 'component' else 'linked; not run in this window')
                    for kind, item in ready.items()},
            reuse=dict(cli_inputs=224, component_inputs=241, cli_replaced_objects=1, component_replaced_objects=2,
                       unchanged_graph_sha256='f160c92d3d369de9b469b0976ae4a42a1928f6c4265f13345c2cbff1d1010e6f',
                       detail_header_exception=exception,
                       note='Only comment tokens changed in the reused header. Actual original SDK/include pins and build contract are retained; no SDK copy or rebuild.'),
            failure=dict(kind='Harness freeze mapping only', record='failure-freeze.log',
                         detail='First freeze indexed executable.cc by canonical product path, but actual compiler Data.Source was the frozen W7 source. KeyError occurred before CXX/link/GPU; corrected unique compiler-source suffix plus exact source SHA check. Original script and traceback retained.'),
            first_product_build_and_run_attempts='Both CXX, both links and the one eight-case CUDA process passed on their first actual attempts.'),
        boundaries=[
            'Finite native Gather consumers prove raw tensor handoff, not all floating-type operators, arbitrary nonfinite inputs or numeric-model quality.',
            'Only full original writers are supported by this change; selected Store prefixes and complete cross-round MTP continuation are separate work.',
            'No model, performance, CPU, Apple, Vulkan, multi-Queue or new native fault-injection run occurred in this window.',
            'The CLI was only relinked; its new image is available for separate diagnosis and is not a model validation claim.',
            'Baseline component EXE had already been removed. Its retained objects/recipes/dependencies were reused without requiring or rehashing that old image.'],
        evidence=dict(archive=pin(archive), file_count=len(members) + 1,
                      uncompressed_member_bytes=sum(x['bytes'] for x in members),
                      member_manifest='manifest.json', every_member_read_back=True,
                      omitted='EXE/OBJ/PDB/DLL/LIB/EXP, SDK, shaders and model payloads'))
    output = DEST / (STEM + '.json')
    save(output, receipt)
    save(W / 'package-result.json', dict(receipt=pin(output), archive=pin(archive),
                                       members=len(members) + 1, verification='all member bytes/SHA read back'))
    print(json.dumps(read(W / 'package-result.json'), indent=2))


if __name__ == '__main__':
    assert len(sys.argv) == 1, 'No build/run or extra actions are supported.'
    main()
