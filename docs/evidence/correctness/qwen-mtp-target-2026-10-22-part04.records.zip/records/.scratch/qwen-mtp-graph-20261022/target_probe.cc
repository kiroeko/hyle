// Real target-verify state selection, not a draft or acceptance-rate benchmark.
#define main hyle_qwen35_text_consumer_main
#include "../../tools/qwen35_text/main.cc"
#undef main

#include <cstring>
#include "hyle/compute/detail/paged_arena_access.h"

namespace {
namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;

void require(bool condition, const char *message) {
  if (!condition) throw std::runtime_error(message);
}

std::string quoted(std::string_view value) {
  std::ostringstream out; out << '"';
  for (const auto ch : value) {
    if (ch == '"' || ch == '\\') out << '\\' << ch;
    else if (ch == '\n') out << "\\n";
    else if (ch == '\r') out << "\\r";
    else if (ch == '\t') out << "\\t";
    else if (static_cast<unsigned char>(ch) < 32) out << '?';
    else out << ch;
  }
  out << '"'; return out.str();
}

Bytes bytes(c::ReadLease const &lease) {
  Bytes result(lease.size()); q::check(q::take(lease.view()).read(result)); return result;
}

Bytes bytes(q::mem::ConstBufferView view) {
  Bytes result(view.size()); q::check(view.read(result)); return result;
}

void write_file(const std::filesystem::path &path, const Bytes &data) {
  std::ofstream stream(path, std::ios::binary);
  stream.write(reinterpret_cast<const char *>(data.data()), static_cast<std::streamsize>(data.size()));
  require(static_cast<bool>(stream), "cannot write target probe raw vector");
}

Bytes read_file(const std::filesystem::path &path) {
  std::ifstream stream(path, std::ios::binary | std::ios::ate);
  require(static_cast<bool>(stream), "missing target probe raw vector");
  const auto size = stream.tellg(); require(size >= 0, "invalid raw vector extent");
  Bytes result(static_cast<std::size_t>(size)); stream.seekg(0);
  stream.read(reinterpret_cast<char *>(result.data()), static_cast<std::streamsize>(result.size()));
  require(static_cast<bool>(stream), "cannot read target probe raw vector"); return result;
}

bool disjoint(c::ReadLease const &lease, q::mem::ConstBufferView other) {
  const auto view = q::take(lease.view());
  return view.resource() != other.resource() || view.native_handle() != other.native_handle() ||
      q::cache::add(view.offset(), view.size()) <= other.offset() ||
      q::cache::add(other.offset(), other.size()) <= view.offset();
}

struct Saved final {
  q::cache::SnapshotRef head;
  std::vector<Bytes> pages, states;
  Bytes carry, prior;
};

Saved save(q::cache::SnapshotRef head) {
  require(static_cast<bool>(head), "missing original snapshot"); Saved result; result.head = std::move(head);
  for (std::size_t layer = 0; layer < result.head->keys.size(); ++layer)
    for (const auto *frame : {&result.head->keys[layer], &result.head->values[layer]})
      for (const auto &lease : c::detail::PagedArenaAccess::pages(*frame)) result.pages.push_back(bytes(lease));
  for (const auto &state : result.head->state)
    for (const auto *lease : {&state.history, &state.recurrent}) if (lease->valid()) result.states.push_back(bytes(*lease));
  require(result.states.size() == 36, "old snapshot lacks one of its36 recurrent states");
  if (result.head->carry_hidden.valid()) result.carry = bytes(result.head->carry_hidden);
  if (result.head->prior_hidden.valid()) result.prior = bytes(result.head->prior_hidden);
  return result;
}

bool unchanged(const Saved &old) {
  const auto now = save(old.head);
  return now.pages == old.pages && now.states == old.states && now.carry == old.carry && now.prior == old.prior;
}

void check_frames(const q::Session &session, std::size_t length, bool partial) {
  const auto &head = *session.head;
  require(head.length == length, "selected target snapshot has wrong length");
  const auto count = (length + q::cache::Plan::page_rows - 1) / q::cache::Plan::page_rows;
  require(head.pages.size() == count, "accepted target inventory retains a rejected page");
  for (std::size_t layer = 0; layer < head.keys.size(); ++layer)
    for (const auto *frame : {&head.keys[layer], &head.values[layer]}) {
      const auto layout = frame->layout(); const auto host = layout.host();
      require(layout.facts().requests == 1 && host.page_indices.size() == count && frame->page_count() == count,
              "selected target frame has an extra/missing page guard");
      require(host.last_page_lengths.size() == 1 &&
              (count - 1) * q::cache::Plan::page_rows + static_cast<std::size_t>(host.last_page_lengths[0]) == length,
              "selected target attention still exposes the rejected suffix");
      for (std::size_t i = 0; i < count; ++i)
        require(host.page_indices[i] == static_cast<std::int32_t>(head.pages[i].page()),
                "selected frame and policy page inventory disagree");
    }
  if (partial) for (const auto &tail : session.tails)
    require(!tail.valid(), "partial accept retained a mutable verified tail");
}

struct Metric final {
  std::string name, reference, actual, dtype;
  std::size_t bytes = 0, elements = 0, nonfinite_reference = 0, nonfinite_actual = 0;
  double max_abs = 0, squared_error = 0, reference_squared = 0;
  bool byte_equal = false;
};

Metric compare(std::string name, const std::filesystem::path &reference,
               const std::filesystem::path &actual, bool bf16) {
  const auto a = read_file(reference), b = read_file(actual);
  require(a.size() == b.size(), "comparison vectors differ in exact extent");
  Metric result; result.name = std::move(name); result.reference = reference.string(); result.actual = actual.string();
  result.dtype = bf16 ? "BF16" : "F32"; result.bytes = a.size(); result.byte_equal = a == b;
  const auto width = bf16 ? sizeof(std::uint16_t) : sizeof(float);
  require(a.size() % width == 0, "comparison vector is not scalar aligned"); result.elements = a.size() / width;
  const auto scalar = [&](const Bytes &data, std::size_t i) {
    if (bf16) { std::uint16_t word = 0; std::memcpy(&word, data.data() + i * width, width);
      return std::bit_cast<float>(static_cast<std::uint32_t>(word) << 16); }
    float value = 0; std::memcpy(&value, data.data() + i * width, width); return value;
  };
  for (std::size_t i = 0; i < result.elements; ++i) {
    const double x = scalar(a, i), y = scalar(b, i);
    result.nonfinite_reference += !std::isfinite(x); result.nonfinite_actual += !std::isfinite(y);
    if (!std::isfinite(x) || !std::isfinite(y)) continue;
    result.max_abs = (std::max)(result.max_abs, std::abs(y - x));
    result.squared_error += (y - x) * (y - x); result.reference_squared += x * x;
  }
  return result;
}

struct Step final {
  std::string name;
  std::int32_t next = -1;
  std::array<std::int32_t, 2> target_ids{-1, -1};
  std::size_t base_length = 0, verified_rows = 0, accepted_rows = 0, length = 0, pages = 0;
  bool injected = false, carry_independent = false, carry_equals_selected_row = false;
};

struct Observation final {
  std::filesystem::path output;
  std::vector<Metric> metrics;
  std::vector<Step> steps;
  bool old_base_unchanged = false, old_row16_unchanged = false, carry_survived_replay = false;
  bool all_finite = true;
  std::size_t backing_bytes = 0;
  void write(std::string_view status, std::string_view error = {}) const {
    std::ofstream out(output / "observation.json"); require(static_cast<bool>(out), "cannot write target observation");
    out << std::setprecision(17) << "{\"status\":" << quoted(status) << ",\"error\":" << quoted(error)
        << ",\"capacity\":64,\"residents\":8,\"active_sequences\":1,\"candidate_boundaries\":2"
        << ",\"injected_acceptance\":true,\"natural_acceptance_rate\":null,\"numeric_tolerance\":null"
        << ",\"numeric_acceptance\":false,\"throughput_evidence\":false,\"cancel_tested\":false"
        << ",\"old_base_unchanged\":" << (old_base_unchanged ? "true" : "false")
        << ",\"old_row16_unchanged\":" << (old_row16_unchanged ? "true" : "false")
        << ",\"independent_carry_survived_carrier_replay\":" << (carry_survived_replay ? "true" : "false")
        << ",\"all_compared_vectors_finite\":" << (all_finite ? "true" : "false")
        << ",\"managed_state_backing_bytes\":" << backing_bytes
        << ",\"numerical_scope\":\"Raw T1-versus-T2 and verify-role differences are measured, not waived or asserted byte-equal. Equal IDs are separately reported, not a quality decision.\",\"steps\":[";
    for (std::size_t i = 0; i < steps.size(); ++i) {
      const auto &s = steps[i]; out << (i ? "," : "") << "{\"name\":" << quoted(s.name)
          << ",\"base_length\":" << s.base_length << ",\"verified_rows\":" << s.verified_rows
          << ",\"accepted_rows\":" << s.accepted_rows << ",\"visible_tokens\":" << s.length
          << ",\"pages\":" << s.pages << ",\"next_id\":" << s.next
          << ",\"target_ids\":[" << s.target_ids[0] << ',' << s.target_ids[1] << ']'
          << ",\"injected_acceptance\":" << (s.injected ? "true" : "false")
          << ",\"carry_independent\":" << (s.carry_independent ? "true" : "false")
          << ",\"carry_equals_selected_row\":" << (s.carry_equals_selected_row ? "true" : "false") << '}';
    }
    out << "],\"metrics\":[";
    for (std::size_t i = 0; i < metrics.size(); ++i) {
      const auto &m = metrics[i]; out << (i ? "," : "") << "{\"name\":" << quoted(m.name)
          << ",\"reference\":" << quoted(m.reference) << ",\"actual\":" << quoted(m.actual)
          << ",\"dtype\":" << quoted(m.dtype) << ",\"bytes\":" << m.bytes << ",\"elements\":" << m.elements
          << ",\"byte_equal\":" << (m.byte_equal ? "true" : "false") << ",\"max_abs\":" << m.max_abs
          << ",\"squared_error\":" << m.squared_error << ",\"reference_squared\":" << m.reference_squared
          << ",\"nonfinite_reference\":" << m.nonfinite_reference << ",\"nonfinite_actual\":" << m.nonfinite_actual << '}';
    }
    out << "]}\n"; require(static_cast<bool>(out), "cannot finish target observation");
  }
};

void record(q::Model &model, Observation &observation, Step step,
            const std::shared_ptr<q::Session> &session, q::Phase &phase) {
  const auto directory = observation.output / "trace" / step.name;
  std::filesystem::create_directories(directory);
  const auto hidden = bytes(q::mem::ConstBufferView(phase.final_hidden.buffer.view()));
  const auto logits = bytes(q::mem::ConstBufferView(phase.logits.buffer.view()));
  const auto row = step.injected ? step.accepted_rows - 1 : 0;
  const auto hidden_bytes = static_cast<std::size_t>(q::hidden) * sizeof(std::uint16_t);
  const auto logits_bytes = static_cast<std::size_t>(q::vocabulary) * sizeof(float);
  require(hidden.size() == hidden_bytes * (step.injected ? 2U : 1U) &&
          logits.size() == logits_bytes * (step.injected ? 2U : 1U), "target-role fixed IO has wrong row count");
  write_file(directory / "all-hidden.bf16", hidden); write_file(directory / "all-logits.f32", logits);
  const auto selected = [&](const Bytes &input, std::size_t size) {
    return Bytes(input.begin() + static_cast<std::ptrdiff_t>(row * size),
                 input.begin() + static_cast<std::ptrdiff_t>((row + 1) * size));
  };
  const auto selected_hidden = selected(hidden, hidden_bytes);
  write_file(directory / "hidden.bf16", selected_hidden);
  write_file(directory / "logits.f32", selected(logits, logits_bytes));
  if (step.injected) {
    require(session->head->carry_hidden.valid() && session->head->carry_hidden.size() == hidden_bytes,
            "verification did not preserve an independent target carry");
    step.carry_independent = disjoint(session->head->carry_hidden, q::mem::ConstBufferView(phase.final_hidden.buffer.view()));
    step.carry_equals_selected_row = bytes(session->head->carry_hidden) == selected_hidden;
    require(step.carry_independent && step.carry_equals_selected_row, "selected carry aliases reusable IO or differs from selected target row");
    write_file(directory / "carry.bf16", bytes(session->head->carry_hidden));
    if (step.accepted_rows == 2) {
      require(session->head->prior_hidden.valid() &&
              bytes(session->head->prior_hidden) == Bytes(hidden.begin(), hidden.begin() + static_cast<std::ptrdiff_t>(hidden_bytes)),
              "full accept did not preserve exact target row0 prior hidden");
      require(disjoint(session->head->prior_hidden, q::take(session->head->carry_hidden.view())), "carry and prior hidden roots overlap");
      write_file(directory / "prior.bf16", bytes(session->head->prior_hidden));
    } else require(!session->head->prior_hidden.valid(), "partial accept retained an unselected prior hidden");
  }
  for (std::size_t layer = 0; layer < model.state_schema.size(); ++layer) if (layer % 4 != 3) {
    const auto prefix = "layer" + std::to_string(layer);
    write_file(directory / (prefix + ".conv.bf16"), bytes(session->head->state[layer].history));
    write_file(directory / (prefix + ".gdn.f32"), bytes(session->head->state[layer].recurrent));
  }
  step.length = session->length(); step.pages = session->head->pages.size();
  check_frames(*session, step.base_length + step.accepted_rows, step.injected && step.accepted_rows == 1);
  observation.steps.push_back(std::move(step)); observation.write("RUNNING");
}

std::int32_t text(q::Model &model, Observation &observation,
                  const std::shared_ptr<q::Session> &session, std::span<const std::int32_t> input,
                  std::string name, bool record_output = true) {
  Step step; step.name = std::move(name); step.base_length = session->length();
  step.verified_rows = step.accepted_rows = input.size();
  model.prepare_evaluation(*session, input); auto *phase = model.active_step->phase;
  model.submit_evaluation(*session); step.next = model.finish_evaluation(*session, step.name);
  step.target_ids[0] = step.next;
  if (record_output) record(model, observation, step, session, *phase);
  return step.next;
}

void verify(q::Model &model, Observation &observation,
            const std::shared_ptr<q::Session> &session, std::span<const std::int32_t> input,
            std::size_t accepted, std::string name) {
  require(input.size() == 2 && (accepted == 1 || accepted == 2), "probe verify selection outside K1 boundaries");
  Step step; step.name = std::move(name); step.base_length = session->length();
  step.injected = true; step.verified_rows = 2; step.accepted_rows = accepted;
  model.prepare_evaluation(*session, input, nullptr, q::GraphRole::kVerify);
  auto *phase = model.active_step->phase;
  require(session->length() == step.base_length && session->pending && model.carrier_borrowed,
          "verify prepare changed the committed head or omitted original episode admission");
  model.submit_evaluation(*session);
  const std::array outputs{q::EvaluationOutput{.session = session, .name = step.name}};
  std::array<std::int32_t, 1> next{-1};
  model.finish_selected_evaluations(outputs, next,
      [&](std::span<const std::int32_t> candidates, q::StepState &active, std::span<std::int32_t> selected) {
        require(candidates.size() == 2 && active.members.size() == 1 && selected.size() == 1,
                "verify callback did not receive original row-major two target IDs");
        std::copy(candidates.begin(), candidates.end(), step.target_ids.begin());
        active.members[0].accepted_tokens = accepted; selected[0] = candidates[accepted - 1];
      });
  step.next = next[0]; require(step.next == step.target_ids[accepted - 1], "committed nextID differs from selected target row");
  record(model, observation, step, session, *phase);
}

void compare_pair(q::Model &model, Observation &observation, std::string_view a, std::string_view b) {
  const auto root = observation.output / "trace";
  const auto add = [&](std::string filename, bool bf16) {
    auto metric = compare(std::string(a) + "_vs_" + std::string(b) + "/" + filename,
                          root / a / filename, root / b / filename, bf16);
    observation.all_finite = observation.all_finite && !metric.nonfinite_reference && !metric.nonfinite_actual;
    observation.metrics.push_back(std::move(metric));
  };
  add("hidden.bf16", true); add("logits.f32", false);
  for (std::size_t layer = 0; layer < model.state_schema.size(); ++layer) if (layer % 4 != 3) {
    add("layer" + std::to_string(layer) + ".conv.bf16", true);
    add("layer" + std::to_string(layer) + ".gdn.f32", false);
  }
  observation.write("RUNNING");
}

void run(const std::filesystem::path &inputs, const std::filesystem::path &output) {
  std::filesystem::create_directories(output);
  require(!std::filesystem::exists(output / "observation.json") && !std::filesystem::exists(output / "trace"),
          "target probe output already contains a prior run");
  Observation observation; observation.output = output;
  try {
    const auto prompt = q::read_ids(inputs / "prompt.ids");
    require(prompt.size() >= 20, "target probe needs original prompt containing at least20 IDs");
    constexpr std::size_t capacity = 64, residents = 8;
    const auto plan = q::cache::plan(capacity, residents, 15,
        q::recurrent_bytes(q::state_schema_for(capacity)), 1, 2);
    q::Model model(inputs / "weights.tsv", capacity, plan, {}, false, q::ReplayPolicy::kAuto, plan.backing_bytes);
    const std::array<std::size_t, 3> chunks{15, 1, 2};
    const std::array<std::size_t, 1> two{2}, seed_calls{15};
    const std::array<std::size_t, 2> two_ones{1, 1}, two_then_one{2, 1};
    const std::array<std::size_t, 12> text_calls{15,1,1,1,1,2,1,1,1,1,1,1};
    const std::array<std::size_t, 3> verify_calls{2,2,2};
    model.prepare_family(chunks); model.prepare_family(two, false, 1, q::GraphRole::kVerify);
    model.plan_execution(text_calls, true); model.plan_execution(verify_calls, true, 1, q::GraphRole::kVerify);
    auto seed = model.create_session(seed_calls);
    (void)text(model, observation, seed, std::span(prompt).first(15), "seed15", false);
    const auto base = save(seed->head);
    const std::array<std::int32_t, 2> proposed{prompt[15], prompt[16]};
    const std::array<std::int32_t, 1> continuation{prompt[19]};
    observation.backing_bytes = q::take(model.cache_budget.usage(model.memory.ref())).live_bytes;
    require(observation.backing_bytes == plan.backing_bytes, "actual prepared state backing differs from declared complete target budget");

    auto baseline1 = model.create_session(two_ones, base.head);
    auto selected1 = model.create_session(two_then_one, base.head);
    (void)text(model, observation, baseline1, std::span(proposed).first(1), "ordinary_a1");
    verify(model, observation, selected1, proposed, 1, "verify_a1_crosspage");
    compare_pair(model, observation, "ordinary_a1", "verify_a1_crosspage");
    require(selected1->length() == 16 && selected1->head->pages.size() == 1, "L15 partial accept failed to trim rejected second physical page");
    const auto row16 = save(selected1->head);
    const auto old_carry = selected1->head->carry_hidden;
    const auto old_carry_bytes = bytes(old_carry);
    (void)text(model, observation, baseline1, continuation, "ordinary_a1_continue");
    (void)text(model, observation, selected1, continuation, "verify_a1_continue");
    compare_pair(model, observation, "ordinary_a1_continue", "verify_a1_continue");
    baseline1.reset(); selected1.reset();

    auto baseline2 = model.create_session(two_then_one, base.head);
    auto selected2 = model.create_session(two_then_one, base.head);
    (void)text(model, observation, baseline2, proposed, "ordinary_a2");
    verify(model, observation, selected2, proposed, 2, "verify_a2");
    compare_pair(model, observation, "ordinary_a2", "verify_a2");
    (void)text(model, observation, baseline2, continuation, "ordinary_a2_continue");
    (void)text(model, observation, selected2, continuation, "verify_a2_continue");
    compare_pair(model, observation, "ordinary_a2_continue", "verify_a2_continue");
    baseline2.reset(); selected2.reset();

    const std::array<std::int32_t, 2> samepage{prompt[17], prompt[18]};
    auto baseline3 = model.create_session(two_ones, row16.head);
    auto selected3 = model.create_session(two_then_one, row16.head);
    (void)text(model, observation, baseline3, std::span(samepage).first(1), "ordinary_samepage_a1");
    verify(model, observation, selected3, samepage, 1, "verify_a1_samepage");
    compare_pair(model, observation, "ordinary_samepage_a1", "verify_a1_samepage");
    (void)text(model, observation, baseline3, continuation, "ordinary_samepage_continue");
    (void)text(model, observation, selected3, continuation, "verify_samepage_continue");
    compare_pair(model, observation, "ordinary_samepage_continue", "verify_samepage_continue");
    observation.old_base_unchanged = unchanged(base);
    observation.old_row16_unchanged = unchanged(row16);
    observation.carry_survived_replay = bytes(old_carry) == old_carry_bytes;
    require(observation.old_base_unchanged && observation.old_row16_unchanged && observation.carry_survived_replay,
            "subsequent execution modified an original snapshot or independent hidden carry");
    require(observation.all_finite && observation.metrics.size() == 228,
            "missing/nonfinite selected hidden, logits or36state raw comparisons");
    observation.write("PASS actual target boundary selection/isolation/continuation; numeric metrics only, injected acceptance");
    std::cout << "Target verifyT2 a1/a2 crosspage+samepage exact-state projection/carry isolation and T1 continuation PASS; raw numeric differences only\n";
  } catch (const std::exception &error) { observation.write("FAIL", error.what()); throw; }
}
} // namespace

int main(int argc, char **argv) {
  try {
    std::filesystem::path inputs, output;
    for (int i = 1; i < argc; ++i) {
      const std::string_view option(argv[i]);
      if ((option != "--inputs" && option != "--output") || i + 1 == argc)
        throw std::runtime_error("usage: target_probe --inputs DIR --output DIR");
      (option == "--inputs" ? inputs : output) = argv[++i];
    }
    require(!inputs.empty() && !output.empty(), "usage: target_probe --inputs DIR --output DIR");
    run(inputs, output); return 0;
  } catch (const std::exception &error) { std::cerr << "target probe: " << error.what() << '\n'; return 1; }
}
