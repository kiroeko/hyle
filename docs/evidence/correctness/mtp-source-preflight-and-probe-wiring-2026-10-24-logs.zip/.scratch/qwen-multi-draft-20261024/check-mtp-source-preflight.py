from pathlib import Path
import importlib.util
import json
import os
import shlex
import subprocess
import sys
import time

ROOT = Path.cwd()
BASE = ROOT / '.scratch/qwen-multi-draft-20261024'
OUT = BASE / 'mtp-source-preflight-check2'
spec = importlib.util.spec_from_file_location('mtp_source_preflight_host', ROOT / '.scratch/engine-product-20261024/cpu-build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
prior = BASE / 'geometry-cpu-check2'
command = b.read(prior / 'compile-command.json')
compiler = command[0]
native = b.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':compiler,
    'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'}, backends=())
flags = [x for x in command[1:] if not x.lower().startswith(('/fo','/fd')) and not x.endswith('.cc')]
reuse = sys.argv[1:] == ['--run-existing']
if sys.argv[1:] and not reuse:
    raise ValueError('Only --run-existing is supported')
OUT.mkdir(exist_ok=reuse)
source = BASE / 'mtp-source-preflight.cc'
headers = [ROOT / 'engine/models/qwen35' / x for x in ['main.cc','backend.h','model_geometry.h','session_state.h']]
before = [b.identity(p) for p in headers]
source_record=dict(headers=before,source=b.identity(source))
if reuse:
    assert b.read(OUT/'source-before-compile.json') == source_record
else:
    b.save(OUT/'source-before-compile.json',source_record)
obj = OUT / 'preflight.obj'
if not reuse:
    b.execute([compiler,*flags,str(source),'/Fo'+str(obj)],native.env,OUT/'compile',timeout=180)
link = b.read(prior / 'link-command.json')
exe = OUT / 'preflight.exe'
link = [str(obj) if x == str(prior/'test.obj') else '/OUT:'+str(exe) if x.lower().startswith('/out:') else x for x in link]
assert str(obj) in link and not any(x == str(prior/'test.obj') for x in link)
if not reuse:
    b.execute(link,native.env,OUT/'link',timeout=180)
if before != [b.identity(p) for p in headers]:
    raise RuntimeError('Source changed during preflight build')
original = ROOT / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
lines = (original / 'weights.tsv').read_text(encoding='utf-8').splitlines()
index = next(i for i,line in enumerate(lines) if line.split(maxsplit=1)[0] == 'geometry')
tokens = shlex.split(lines[index])
assert len(tokens) == 21 and tokens[18] == '1'
tokens[18] = '0'
lines[index] = ' '.join(tokens[:-1])+' '+json.dumps(tokens[-1])
fixture = OUT/'no-nextn-source';fixture.mkdir(exist_ok=reuse)
# Intentionally no prompt or weight bodies: CLI must reject from source metadata.
(fixture/'weights.tsv').write_text('\n'.join(lines[:index+1])+'\n',encoding='utf-8')
results = []
ready=b.read(ROOT/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cpu.json')
runtime=dict(native.env,PATH=str(OUT)+os.pathsep+ready['PATH'])
for name,args,code,needle in [
    ('direct-model',['--direct-source-check',str(original)],0,'PASS direct Model'),
    ('cli',['--inputs',str(fixture),'--mtp','on','--capacity','64','--steps','2'],1,
     'MTP requires one NextN layer in the prepared source geometry')]:
    folder=OUT/(name+('-runtime2' if reuse else ''));folder.mkdir()
    cmd=[str(exe),*args];started=time.perf_counter()
    run=subprocess.run(cmd,cwd=ROOT,env=runtime,capture_output=True,timeout=30,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    (folder/'stdout.log').write_bytes(run.stdout);(folder/'stderr.log').write_bytes(run.stderr)
    result=dict(command=cmd,exit=run.returncode,expected_exit=code,seconds=time.perf_counter()-started,
                passed=run.returncode==code and needle.encode()in run.stdout+run.stderr)
    b.save(folder/'result.json',result);results.append(result)
    if not result['passed']:raise RuntimeError('Incorrect source preflight: '+name)
b.save(OUT/'result.json',dict(passed=True,cases=results,source=b.identity(source),headers=before,
    SDK_builds=0,HTTP=0,weight_body_reads=0,scope='Unavailable NextN fails in CLI and direct Model before backend creation or model IO; no inference/performance result.'))
print(json.dumps(dict(passed=True,cases=2,weight_body_reads=0)))
