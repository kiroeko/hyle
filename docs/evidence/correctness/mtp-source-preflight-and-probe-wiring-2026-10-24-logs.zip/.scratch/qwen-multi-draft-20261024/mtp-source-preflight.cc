#include "C:/public/project-hyle/hyle/engine/models/qwen35/main.cc"

int main(int argc, char **argv) {
  if (argc == 3 && std::string_view(argv[1]) == "--direct-source-check") {
    auto geometry = qwen35::read_weight_geometry(std::filesystem::path(argv[2]) / "weights.tsv");
    auto plan = qwen35::cache::plan(geometry, 64, 1, 1,
        qwen35::recurrent_bytes(qwen35::state_schema_for(geometry, 64), geometry), 1, 2, true);
    geometry.mtp_layers = 0;
    qwen35::validate_mtp_source(geometry, false); // Ordinary source remains legal.
    try {
      // The invalid draft plan must fail before creating the endpoint or
      // trying to open this intentionally nonexistent weights file.
      qwen35::Model model("unreachable-source-preflight-weights.tsv", geometry, 64, plan);
    } catch (const std::runtime_error &error) {
      if (std::string_view(error.what()) == "MTP requires one NextN layer in the prepared source geometry") {
        std::cout << "PASS direct Model rejects unavailable NextN before backend/weight IO\n";
        return 0;
      }
      throw;
    }
    return 2;
  }
  return qwen35::run(argc, argv);
}
