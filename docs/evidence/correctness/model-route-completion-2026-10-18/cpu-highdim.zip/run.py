from pathlib import Path
import hashlib, importlib.util, json, subprocess, time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cached_cpu', ROOT / '.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cpu)
cfg = dict(cpu.PINS['mixed'], folder=Path('mixed'))
flags = cpu.hyle_flags(cfg) + ['/I' + str(ROOT)]
records = []

def run(label, command):
    start = time.monotonic()
    result = subprocess.run(list(map(str, command)), cwd=ROOT, env=cpu.ENV, capture_output=True, timeout=180)
    (OUT / (label + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (label + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(label=label, command=list(map(str, command)), exit=result.returncode,
                        seconds=time.monotonic() - start))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, result.returncode, result.stdout.decode(errors='replace')[-5000:],
          result.stderr.decode(errors='replace')[-2000:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

def compile(source, name):
    output = OUT / (name + '.obj')
    run(name + '-compile', [cpu.CL, *flags, source, '/Fo' + str(output)])
    return output

ffa4 = ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/ops.cpp'
mixed = ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/ops.cpp'
def attention(path):
    data = path.read_text(encoding='utf-8')
    data = data[data.index('// Private CPU page-address adapter.'):data.index('// ggml_compute_forward_flash_attn_back')]
    # The two revisions move the unused softcap block around padding and gate
    # the tiled SIMD divisibility check differently. This batch always uses
    # softcap=0, and VO=512 satisfies either divisibility check.
    softcap = '''            if (logit_softcap != 0.0f) {
                ggml_vec_tanh_f32(Q_TILE_SZ * KV_TILE_SZ, KQ, KQ);
                ggml_vec_scale_f32(Q_TILE_SZ * KV_TILE_SZ, KQ, logit_softcap);
            }

'''
    assert data.count(softcap) == 1
    return data.replace(softcap, '').replace('#if defined(GGML_SIMD) && !defined(__x86_64__) && !defined(_M_X64)', '#ifdef GGML_SIMD')
assert attention(ffa4) == attention(mixed), 'cached mixed attention differs from current CPU attention patch'
manifest = json.loads((ROOT / 'third_party/ggml_cpu_runtime/patches.json').read_text())
expected = next(f['after_sha256'] for f in manifest['files'] if f['path'] == 'src/ggml-cpu/ops.cpp')
assert hashlib.sha256(ffa4.read_bytes()).hexdigest() == expected
print('Mixed attention matches current patch apart from inactive softcap ordering and satisfied VO SIMD check', flush=True)

provider = compile(ROOT / 'src/compute_provider_ggml/ggml_cpu_provider.cc', 'provider')
batch = compile(ROOT / 'src/compute_provider_ggml/native_batch.cc', 'batch')
execution = compile(ROOT / 'src/compute_batch/batch_execution.cc', 'batch-execution')
test = compile(ROOT / 'tests/compute_provider_ggml/native_paged_test.cc', 'canonical-native-paged-test')
cached = ROOT / '.scratch/mtp-gdn-2026-10-18'
native = ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj'
objects = [cached / p for p in ['ffa4/operation.obj', 'mixed/selector-baseline.obj', 'mixed/allocator.obj']]
objects += [native, provider, batch, execution, test]
libs = cpu.common_libs(cfg) + [cpu.BASE / 'lib/gtest.lib', cpu.BASE / 'lib/gtest_main.lib']
exe = OUT / 'cpu-highdim.exe'
run('link', [cpu.LINK, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
             '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(exe), '/MAP:' + str(exe.with_suffix('.map')),
             *objects, *libs, *cpu.SYSTEM])
run('tests', [exe, '--gtest_filter=GgmlCpuBoxed.PlainHighdimMixedContinuationUsesOriginalPagesAndRaggedRoots'])
identity_paths = [ROOT / p for p in ['src/compute_provider_ggml/native_batch.cc',
    'src/compute_provider_ggml/ggml_cpu_provider.cc', 'tests/compute_provider_ggml/native_paged_test.cc']]
identity_paths += [ffa4, mixed, native, *objects[:3], *libs]
(OUT / 'identities.json').write_text(json.dumps([dict(path=str(p), bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in identity_paths], indent=2) + '\n')
