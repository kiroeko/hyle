from pathlib import Path
import hashlib, json, subprocess, zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sources = ['src/compute_provider_ggml/native_batch.cc',
           'src/compute_provider_ggml/ggml_cpu_provider.cc',
           'tests/compute_provider_ggml/native_paged_test.cc']
summary = {
    'change': 'Qualify plain F16/BF16 CPU native ragged/paged 512->512 and 576->512 through both existing adapter gates.',
    'qualification_preserved': ['same query/output/cache dtype', 'coherent host resource',
        'integer/layout/page bounds', 'direct native KV/page root checks', 'known workspace budget',
        'existing precision and numerical tolerances'],
    'test': 'Canonical native_paged_test.cc: GgmlCpuBoxed.PlainHighdimMixedContinuationUsesOriginalPagesAndRaggedRoots',
    'cases': '8: paged/ragged x F16/BF16 x QK512/VO512/H64/KV1 or QK576/VO512/H96/KV1',
    'journey': 'Each batch contains Q2/Q1 requests and logical KV31/33. Paged table is [3,1,0,2,1] with partial tails; oracle independently decodes input storage and computes attention in FP64.',
    'max_abs_error': 3.49039647665e-5,
    'existing_abs_budget': 0.0025,
    'fresh_host_tus': ['ggml_cpu_provider.cc', 'native_batch.cc', 'batch_execution.cc', 'native_paged_test.cc'],
    'cached_native': '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj plus mixed456 ggml libraries',
    'native_source_check': 'Current ffa4 ops.cpp SHA matches canonical manifest after_sha256. Cached mixed attention matches after excluding only softcap ordering (softcap=0 here) and the SIMD gate (VO512 satisfies both).',
    'cache_note': 'Initial old batch library queried an older BatchPlanning extension ID; fresh current batch_execution.cc restored the current host ABI. This required no product change beyond the two admission gates.',
    'boundary': 'Canonical test TU compiled and the named 8-case test executed. No full-suite/model/highdim Graph run, SDK/native rebuild, performance claim, or Q8 domain expansion.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(OUT / 'product.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', *sources], cwd=ROOT))
archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in [OUT / n for n in ['run.py', 'pack.py', 'summary.json', 'commands.json', 'identities.json', 'product.diff']]:
        z.write(p, p.name)
    for p in sorted(OUT.glob('*.log')):
        z.write(p, p.name)
    for p in sources:
        z.write(ROOT / p, p)
print(str(archive), archive.stat().st_size, hashlib.sha256(archive.read_bytes()).hexdigest())
