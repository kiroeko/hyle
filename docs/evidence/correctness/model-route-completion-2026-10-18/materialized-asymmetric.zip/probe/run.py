from pathlib import Path
import importlib.util, json, subprocess, time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cached_cpu', ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cpu)
cfg = dict(cpu.PINS['mixed'], folder=Path('mixed'))
flags = cpu.hyle_flags(cfg) + ['/I'+str(ROOT)]
records = []

def run(label, command, expected=0):
    start = time.monotonic()
    p = subprocess.run(list(map(str,command)), cwd=ROOT, env=cpu.ENV, capture_output=True, timeout=150)
    (OUT/(label+'.stdout.log')).write_bytes(p.stdout)
    (OUT/(label+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(label=label,command=list(map(str,command)),exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label, p.returncode, p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-1500:],flush=True)
    assert p.returncode == expected, label

def compile(source, name):
    output = OUT/(name+'.obj')
    run(name+'-compile',[cpu.CL,*flags,source,'/Fo'+str(output)])
    return output

test = OUT/'test.cc'
test.write_text('''#include "tests/compute_batch/materialized_asymmetric_fixture.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
TEST(MaterializedClosure, AsymmetricDepths) {
  auto context=hyle::compute::Context::create(hyle::compute::cpu::device(),
      hyle::compute::ggml_cpu::provider()).value();
  materialized_asymmetric_test::exercise(context);
}
''')
test_obj = compile(test, 'test')
baseline = OUT/'materialized.before.cc'
baseline.write_bytes(subprocess.check_output(['git','show','HEAD:src/graph_batch/materialized_invocation.cc'],cwd=ROOT))
objects = [ROOT/'.scratch/mtp-gdn-2026-10-18'/p for p in
           ['ffa4/operation.obj','mixed/provider.obj','mixed/selector-baseline.obj','mixed/allocator.obj']]
objects += [ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj',test_obj]
libs = [cpu.BASE/'bin'/p for p in ['hyle_graph_batch.lib','hyle_graph.lib','hyle_compute_state.lib']]
libs += cpu.common_libs(cfg) + [cpu.BASE/'lib/gtest.lib',cpu.BASE/'lib/gtest_main.lib']
for mode, source, expected in [('before',baseline,1),('after',ROOT/'src/graph_batch/materialized_invocation.cc',0)]:
    obj=compile(source,mode)
    exe=OUT/(mode+'.exe')
    run(mode+'-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(exe),'/MAP:'+str(exe.with_suffix('.map')),obj,*objects,*libs,*cpu.SYSTEM])
    run(mode+'-test',[exe],expected)
