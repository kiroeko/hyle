#include "tests/compute_batch/materialized_asymmetric_fixture.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
TEST(MaterializedClosure, AsymmetricDepths) {
  auto context=hyle::compute::Context::create(hyle::compute::cpu::device(),
      hyle::compute::ggml_cpu::provider()).value();
  materialized_asymmetric_test::exercise(context);
}
