from pathlib import Path
import importlib.util
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cached_cpu', ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cpu)
(OUT/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(BatchTestWiring LANGUAGES CXX)
enable_testing()
set(HYLE_SOURCE_DIR "'''+ROOT.as_posix()+'''")
include("${HYLE_SOURCE_DIR}/cmake/HyleModule.cmake")
function(hyle_add_header_self_contained_test)
endfunction()
function(hyle_apply_warnings)
endfunction()
function(hyle_apply_sanitizer)
endfunction()
function(hyle_stage_runtime)
endfunction()
add_library(hyle_graph_batch INTERFACE)
add_library(hyle_simd INTERFACE)
add_library(gtest_main INTERFACE)
add_library(GTest::gtest_main ALIAS gtest_main)
set(_HYLE_COMPUTE_HAVE_CPU ${FIXTURE_CPU})
set(_HYLE_COMPUTE_HAVE_CUDA ${FIXTURE_CUDA})
if(FIXTURE_CPU)
  add_library(hyle_graph_route_cpu INTERFACE)
endif()
if(FIXTURE_CUDA)
  add_library(hyle_compute_route_cuda INTERFACE)
  add_library(hyle_compute_provider_flashinfer INTERFACE)
endif()
add_subdirectory("${HYLE_SOURCE_DIR}/tests/graph_batch" graph-batch)
foreach(kind IN ITEMS cpu_materialized cuda_public_native)
  if((kind STREQUAL "cpu_materialized" AND FIXTURE_CPU) OR
     (kind STREQUAL "cuda_public_native" AND FIXTURE_CUDA))
    if(NOT TARGET hyle_graph_batch_${kind}_test)
      message(FATAL_ERROR "Missing ${kind} target")
    endif()
    get_target_property(deps hyle_graph_batch_${kind}_test LINK_LIBRARIES)
    if(NOT hyle_simd IN_LIST deps)
      message(FATAL_ERROR "Missing simd dependency for ${kind}")
    endif()
  elseif(TARGET hyle_graph_batch_${kind}_test)
    message(FATAL_ERROR "Unexpected ${kind} target")
  endif()
endforeach()
get_directory_property(tests DIRECTORY "${HYLE_SOURCE_DIR}/tests/graph_batch" TESTS)
file(WRITE "${CMAKE_BINARY_DIR}/registered-tests.txt" "${tests}\\n")
''', encoding='utf-8')
records=[]
for name, enabled_cpu, enabled_cuda in [('both','ON','ON'),('cpu','ON','OFF'),('none','OFF','OFF')]:
    command=['cmake','-S',str(OUT),'-B',str(OUT/name),'-G','Ninja',
        '-DCMAKE_CXX_COMPILER='+str(cpu.CL),'-DFIXTURE_CPU='+enabled_cpu,'-DFIXTURE_CUDA='+enabled_cuda]
    result=subprocess.run(command,cwd=ROOT,env=cpu.ENV,capture_output=True,timeout=60)
    (OUT/(name+'.stdout.log')).write_bytes(result.stdout)
    (OUT/(name+'.stderr.log')).write_bytes(result.stderr)
    records.append(dict(name=name,command=command,exit=result.returncode))
    print(name,result.returncode,result.stderr.decode(errors='replace')[-1500:],flush=True)
    assert result.returncode==0
    print((OUT/name/'registered-tests.txt').read_text(),flush=True)
(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
