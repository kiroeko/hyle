from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
path=ROOT/'cmake/HyleDependencyLock.json'
text=path.read_text(encoding='utf-8');lock=json.loads(text)
entry=next(x for x in lock['dependencies'] if x['name']=='mlx_cast_patches')
vendor=ROOT/entry['vendored']['path']
def digest(p): return hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')).hexdigest()
items=sorted((p for p in vendor.rglob('*') if p.is_file()),key=lambda p:p.relative_to(vendor).as_posix())
manifest=''.join(f'{p.relative_to(vendor).as_posix()}|{digest(p)}\n' for p in items)
notice=next(x for x in entry['license']['files'] if x['path'].endswith('NOTICE.md'))
updates={entry['version']:'hyle-apple-native-patches-v3',entry['vendored']['tree_sha256']:hashlib.sha256(manifest.encode()).hexdigest(),notice['sha256']:digest(ROOT/notice['path'])}
for old,new in updates.items():
 assert text.count(old)==1
 text=text.replace(old,new,1)
path.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps(updates,indent=2))
