from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
PRODUCT=['include/hyle/compute/apple_batch.h','include/hyle/compute/detail/apple_batch_access.h','src/compute_route_apple/apple_batch.cc','src/compute_route_apple/apple_materialized_invocation.cc','tests/compute_route_apple/native_cache_test.cc','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md']
def rec(p): return dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name,value): (ROOT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not (ROOT/'source-results.zip').exists()
for name in [*PRODUCT,'cmake/HyleDependencyLock.json']:
 p=ROOT/'frozen'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/name,p)
 if name!='cmake/HyleDependencyLock.json':
  old=ROOT/'head-baseline'/name;old.parent.mkdir(parents=True,exist_ok=True)
  old.write_bytes(subprocess.check_output(['git','show','HEAD:'+name],cwd=REPO))
diff=subprocess.check_output(['git','diff','--',*PRODUCT],cwd=REPO)
(ROOT/'product.diff').write_bytes(diff)
native=(ROOT/'native-candidate/mlx/backend/metal/scaled_dot_product_attention.cpp').read_text(encoding='utf-8')
diag=(ROOT/'diagnostic-host.cpp').read_text(encoding='utf-8')
(ROOT/'diagnostic-only.diff').write_text(''.join(difflib.unified_diff(native.splitlines(True),diag.splitlines(True),fromfile='product-host.cpp',tofile='probe-only-host.cpp')),encoding='utf-8',newline='\n')
applied=''
for name in ['src/compute_route_apple/apple_batch.cc','src/compute_route_apple/apple_materialized_invocation.cc']:
 applied+=''.join(difflib.unified_diff((ROOT/'measured'/name).read_text(encoding='utf-8').splitlines(True),(REPO/name).read_text(encoding='utf-8').splitlines(True),fromfile='measured/'+name,tofile='applied/'+name))
(ROOT/'measured-to-applied.diff').write_text(applied,encoding='utf-8',newline='\n')
manifest=json.loads((REPO/'third_party/mlx_cast/patches.json').read_text(encoding='utf-8'))
for rel in ['mlx/fast.cpp','mlx/backend/metal/scaled_dot_product_attention.cpp']:
 current=next(x for x in manifest['files'] if x['path']==rel)
 assert rec(ROOT/'native-candidate'/rel)['sha256']==current['after_sha256']
objects=json.loads((ROOT/'results/final-artifacts.json').read_text())
assert len(objects)==14 and len({x['path'] for x in objects})==14
save('cleanup-candidates.json',dict(host='kiro@172.22.10.198',root='/Users/kiro/hyle-scratch/compute-unified/inference-feature-completion-20261018-apple-highdim',files=objects,count=len(objects),logical_bytes=sum(x['bytes'] for x in objects),performed_cleanup=False,preserve='Every source, command, log, map, data, archive, symlink, SDK and shared native/MTP cache; root owns exact test.ps1 cleanup.'))
summary=dict(status='PASS_no_performance_claim',hardware='MacBook Air Mac16,12 Apple M4, actual PSO device limit 32768 bytes',toolchain='Apple clang 21.0.0, arm64, release O3/NDEBUG, MLX_METAL_NO_NAX',native_pin='1f8e74e3f12f31365464a6867c6579f0e9b29d85 (MLX 0.32.2)',
 implementation=dict(plain_dtypes=['F16','BF16'],QK_V_pairs=[[512,512],[576,512]],reuse='Existing Steel compact BQ8/BK8/WM1/WN1, page/window loaders, F32 QK/online-softmax/PV; narrow only final output store',private_Q1_path='Same compact full tile; do not instantiate unsupported vector widths',actual_PSO=dict(D512_bytes=16384,D576_V512_bytes=18432,device_limit_bytes=32768,max_threads=32),unchanged=['low-dimensional plain','Q8 domain','ordinary attention','NAX selection','native queues/Job/cancellation/lease/completion contracts']),
 final_validation=dict(test='AppleCache.PlainHighDimensionsKeepPageMappingAndIndependentValues',tests=1,cases=8,heads={'512/512':[64,1],'576/512':[96,1]},dtypes=['F16','BF16'],storage=['ragged','paged page16'],per_request_queries=[1,17],logical_KV=[31,33],pages=[3,1,0,2,1],page_tails=[15,1],oracle='All output elements checked with independent FP64 from actual rounded input payloads; original abs budgets .0025 F16/.008 BF16 unchanged',maximum_absolute_error=0.0000610358813,full_oracle_seconds=24.390,commands='results/compile-models-test.command.json, link-models-test.command.json, models-tests.command.json',execution='Actual public Apple native-route Context/prepare_ragged_batch/PagedBatchInvocation; probe-only identical native host additionally prints PSO metadata'),
 early_probe=dict(heads=[8,2],cases=8,maximum_absolute_error=0.000121990328,status='PASS retained; not the final selected-model geometry'),
 measured_applied_boundary=dict(native_and_highdim_algorithm='Byte-identical through final model run',final_change='Move the same cache_domain predicate into existing private PagedBatchAccess; controller now shares the complete dtype/encoding/geometry check with paged/ragged prepare',post_change='Only these two applied host TUs compiled successfully, no numerical rerun per root; measured-to-applied.diff preserves exact difference'),
 failures_retained=['Probe diagnostic dtype printf initially tried int(Dtype), failed compilation; changed logging to string only.', 'Initial current context compilation missed native_program.h in staged private-header closure; added that unchanged header.', 'Initial link used nonexistent nested recurrent.o path; corrected to actual retained MTP root recurrent.o. No runtime numerical failure.'],
 limits=['No timing or global/peak-memory measurement; PSO threadgroup bytes are actual queried pipeline resources, not total VRAM.', 'Only causal=true/window=-1 and scale=1/sqrt(QK depth) exercised in new highdim runtime checks; existing generic window/noncausal/finite-scale code reused, not separately retested.', 'No custom mask, sink, Q8 highdim or dedicated CKV/KPE MLA cache API expansion.', 'Independent Q/K/V native paged/ragged math and selected head geometries tested; not an entire GLM/Kimi model engine.', 'No generic Graph consumer/default graph-route rebuild or install/shared-package validation this batch.', 'Original SDK and metallib reused; current product/native host overlays and selected current MTP operation/recurrent objects precede original static archives. No SDK copy/download/full build.'],
 lock=dict(entry='mlx_cast_patches',version='hyle-apple-native-patches-v3',tree_sha256='b12f6c0f248971d37470bf08bb4c7979b987563ff7e7cfb0b299ea59fea8c022',notice_sha256='c1c95c4a932863ab52cfa3657de581d76d2e9be2d280e93743b80e5f06d7049f',audit='Parent independently reported three-resource CMake audit PASS, wall .61s; not an agent-generated execution log.'),source_identities=[rec(ROOT/'frozen'/name) for name in PRODUCT])
save('summary.json',summary)
paths=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix not in ['.zip','.gz'] and 'source-results' not in p.name]
# Include the small header/source-only initial stage tar for exact compile inputs.
paths.append(ROOT/'staged-sources.tar.gz')
assert len(paths)==len(set(paths))
with zipfile.ZipFile(ROOT/'source-results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths,key=lambda p:p.relative_to(ROOT).as_posix()): z.write(p,p.relative_to(ROOT).as_posix())
save('archive-identity.json',rec(ROOT/'source-results.zip'))
print(json.dumps(rec(ROOT/'source-results.zip'),indent=2))
