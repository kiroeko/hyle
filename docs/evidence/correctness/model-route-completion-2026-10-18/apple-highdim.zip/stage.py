from pathlib import Path
import hashlib,io,json,subprocess,tarfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-feature-completion-20261018-apple-highdim'
files={}
for base in ['include','src/compute_route_apple','src/compute']:
 for p in (REPO/base).rglob('*.h'): files[p.relative_to(REPO).as_posix()]=p
for name in ['apple_context','apple_operations','apple_tensor','apple_batch','apple_materialized_invocation']:
 p=REPO/'src/compute_route_apple'/(name+'.cc'); files[p.relative_to(REPO).as_posix()]=p
for rel in ['tests/compute_route_apple/native_cache_test.cc','tests/compute_provider_native/half_test_support.h']:
 files[rel]=REPO/rel
for p in (ROOT/'native-candidate').rglob('*'):
 if p.is_file(): files[p.relative_to(ROOT).as_posix()]=p
host=(ROOT/'native-candidate/mlx/backend/metal/scaled_dot_product_attention.cpp').read_text()
before='  MTL::Size group_dims = MTL::Size(32, wm, wn);\n'
after='  if (highdim_cache) std::fprintf(stderr, "HYLE_HIGH_DIM_PSO D=%d V=%d dtype=%d Q=%d BQ=%d BK=%d WM=%d WN=%d static=%lu limit=%lu maxthreads=%lu\\n", bd,bv,int(q.dtype()),qL,bq,bk,wm,wn,(unsigned long)kernel->staticThreadgroupMemoryLength(),(unsigned long)d.mtl_device()->maxThreadgroupMemoryLength(),(unsigned long)kernel->maxTotalThreadsPerThreadgroup());\n'+before
position=host.index(before,host.index('  const bool highdim_cache'))
host='#include <cstdio>\n'+host[:position]+host[position:].replace(before,after,1)
(ROOT/'diagnostic-host.cpp').write_bytes(host.encode())
files['diagnostic-host.cpp']=ROOT/'diagnostic-host.cpp';files['run_remote.py']=ROOT/'run_remote.py'
items=[dict(path=rel,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for rel,p in sorted(files.items())]
(ROOT/'staged-sources.json').write_text(json.dumps(items,indent=2)+'\n')
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w:gz') as t:
 for rel,p in sorted(files.items()): t.add(p,arcname=rel)
(ROOT/'staged-sources.tar.gz').write_bytes(data.getvalue())
code=f'''import pathlib,sys,tarfile,io
root=pathlib.Path({REMOTE!r})
assert not root.exists(), 'fresh fixed directory only'
root.mkdir()
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and m.isfile()
 t.extractall(root)
print(root)
'''
# The script is the SSH command, stdin contains only the small source tar.
import base64
command='python3 -c '+repr('import base64;exec(base64.b64decode('+repr(base64.b64encode(code.encode()).decode())+'))')
r=subprocess.run(['ssh','kiro@172.22.10.198',command],input=data.getvalue(),capture_output=True)
(ROOT/'stage.stdout.log').write_bytes(r.stdout);(ROOT/'stage.stderr.log').write_bytes(r.stderr)
print('source bytes',sum(x['bytes'] for x in items),'compressed',len(data.getvalue()),'exit',r.returncode)
print(r.stdout.decode(),r.stderr.decode());r.check_returncode()
