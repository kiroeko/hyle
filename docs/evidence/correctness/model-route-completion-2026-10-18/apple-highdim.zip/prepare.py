from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
OLD = REPO / '.scratch/perf-review-2026-10-18/apple-native-mask-mixed/candidate'
MANIFEST = REPO / 'third_party/mlx_cast/patches.json'
manifest = json.loads(MANIFEST.read_text())

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode())

def change(relative, before, after):
    path = REPO / relative
    text = path.read_text()
    assert text.count(before) == 1, relative
    frozen = ROOT / 'baseline' / relative
    if not frozen.exists():
        frozen.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, frozen)
    write(path, text.replace(before, after))

for relative, edits in {
    'mlx/fast.cpp': [(
        '      (dk != 64 && dk != 128 && dk != 256) || (dv != dk && !(dk == 64 && dv == 128)) ||\n',
        '      !(((dk == 64 || dk == 128 || dk == 256) &&\n'
        '         (dv == dk || (dk == 64 && dv == 128))) ||\n'
        '        (!q8 && (dk == 512 || dk == 576) && dv == 512)) ||\n')],
    'mlx/backend/metal/scaled_dot_product_attention.cpp': [(
        '  const bool half_query = page && page->q8 && page->query_f16;\n',
        '  // Private plain high-dimensional cache attention reuses the compact\n'
        '  // Steel template, including single-query decode. No large PSO is built.\n'
        '  const bool highdim_cache = page && !page->q8 &&\n'
        '      (q.dtype() == float16 || q.dtype() == bfloat16) &&\n'
        '      (bd == 512 || bd == 576) && bv == 512;\n'
        '  if (highdim_cache) { bq = bk = 8; wm = wn = 1; }\n'
        '  const bool half_query = page && page->q8 && page->query_f16;\n'), (
        '  // We are in vector mode ie single query\n  if (q_pre.shape(2) <= 8) {\n',
        '  const bool highdim_cache = page && !page->q8 &&\n'
        '      (q_pre.dtype() == float16 || q_pre.dtype() == bfloat16) &&\n'
        '      (q_pre.shape(-1) == 512 || q_pre.shape(-1) == 576) &&\n'
        '      v_pre.shape(-1) == 512;\n'
        '  // The existing vector specializations stop at D256.\n'
        '  if (q_pre.shape(2) <= 8 && !highdim_cache) {\n')]
}.items():
    record = next(x for x in manifest['files'] if x['path'] == relative)
    original = (OLD / relative).read_bytes()
    assert hashlib.sha256(original).hexdigest() == record['after_sha256']
    write(ROOT / 'native-baseline' / relative, original.decode())
    text = original.decode()
    for before, after in edits:
        assert text.count(before) == 1
        text = text.replace(before, after)
        record['edits'].append(dict(before=before, after=after))
    record['after_sha256'] = hashlib.sha256(text.encode()).hexdigest()
    write(ROOT / 'native-candidate' / relative, text)

shutil.copyfile(MANIFEST, ROOT / 'patches.before.json')
write(MANIFEST, json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')

change('src/compute_route_apple/apple_batch.cc',
    '       (c.qk_head_dim==64 && c.value_head_dim==128));',
    '       (c.qk_head_dim==64 && c.value_head_dim==128) ||\n'
    '       (plain && (c.qk_head_dim==512 || c.qk_head_dim==576) &&\n'
    '        c.value_head_dim==512));')
change('src/compute_route_apple/apple_batch.cc',
    '      c.page_size!=16 || c.max_pages>std::uint32_t(INT32_MAX/16) ||\n'
    '      (c.qk_head_dim!=64 && c.qk_head_dim!=128 && c.qk_head_dim!=256))',
    '      c.page_size!=16 || c.max_pages>std::uint32_t(INT32_MAX/16))')
change('src/compute_route_apple/apple_batch.cc',
    '  if((c.query_type!=DataType::kFloat16&&c.query_type!=DataType::kBFloat16)||\n'
    '     (c.qk_head_dim!=64&&c.qk_head_dim!=128&&c.qk_head_dim!=256))',
    '  if(c.query_type!=DataType::kFloat16&&c.query_type!=DataType::kBFloat16)')
change('tests/compute_route_apple/native_cache_test.cc',
    'TEST(AppleCache, MainDepthsAndLongPrefill) {',
    'TEST(AppleCache, PlainHighDimensionsKeepPageMappingAndIndependentValues) {\n'
    '  // The first request is Q1; the second is Q17, including the last tile.\n'
    '  // Keep the existing independent FP64 oracle and dtype-specific budgets.\n'
    '  for(bool paged:{false,true})for(unsigned dk:{512u,576u}) {\n'
    '    boxed_case<F16>(paged,false,dk,512,true,-1);\n'
    '    boxed_case<BF16>(paged,false,dk,512,true,-1);\n'
    '  }\n'
    '}\n'
    'TEST(AppleCache, MainDepthsAndLongPrefill) {')
change('include/hyle/compute/apple_batch.h',
    '// Cold immutable host-known ragged layout, F16/BF16 D64/128/256. Three original',
    '// Cold immutable host-known ragged layout, F16/BF16 D64/128/256 and plain\n'
    '// 512/576-to-512. Three original')
change('include/hyle/compute/apple_batch.h',
    '// Exact-frame native page16 attention, F16/BF16 D64/128/256. Preparation',
    '// Exact-frame native page16 attention, F16/BF16 D64/128/256 and plain\n'
    '// 512/576-to-512. Preparation')
change('third_party/mlx_cast/NOTICE.md',
    'The same Apple integration carries `metal-shared-ptr.json`',
    'Plain F16/BF16 private paged/ragged attention also admits QK512/576 with\n'
    'V512. It selects the existing compact Steel BQ8/BK8/WM1/WN1 template\n'
    'before pipeline creation, including Q1, and checks actual pipeline static\n'
    'threadgroup memory against the device limit. QK, online softmax and PV\n'
    'accumulate in F32; only the original output store narrows. Low-dimensional,\n'
    'Q8, ordinary attention and NAX selection remain unchanged.\n\n'
    'The same Apple integration carries `metal-shared-ptr.json`')
print('Prepared Apple highdim patch and focused fixture')
