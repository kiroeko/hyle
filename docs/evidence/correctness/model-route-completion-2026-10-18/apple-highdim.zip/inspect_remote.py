from pathlib import Path
import subprocess
ROOT = Path(__file__).resolve().parent
script = r'''
import pathlib,json,subprocess,hashlib
p=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/mtp-gdn-snapshots-20261018')
def rec(p):
 p=pathlib.Path(p)
 return dict(path=str(p),exists=p.is_file(),bytes=p.stat().st_size if p.is_file() else None,sha256=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None)
compile=json.loads((p/'compile-probe.command.json').read_text())
link=json.loads((p/'link-probe.command.json').read_text())
print(json.dumps(dict(model=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip(),compiler=subprocess.check_output(['/usr/bin/clang++','--version'],text=True),compile=compile,link=link,linked=[rec(x) for x in link if x.endswith(('.a','.o'))],native=[rec('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate/'+s) for s in ['fast.o','native-host.o']],steel=rec('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate/steel_attention.o')),indent=2))
'''
p=subprocess.run(['ssh','kiro@172.22.10.198','python3 -'],input=script.encode(),capture_output=True)
(ROOT/'inspect-remote.stdout.json').write_bytes(p.stdout)
(ROOT/'inspect-remote.stderr.log').write_bytes(p.stderr)
print('exit',p.returncode)
print(p.stdout.decode()[:15000])
print(p.stderr.decode())
