from pathlib import Path
import hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parent
def rec(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,args):
 assert not (ROOT/(tag+'.command.json')).exists()
 start=time.monotonic();p=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=120)
 (ROOT/(tag+'.command.json')).write_text(json.dumps(dict(argv=args,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n')
 (ROOT/(tag+'.stdout.log')).write_bytes(p.stdout);(ROOT/(tag+'.stderr.log')).write_bytes(p.stderr)
 print(tag,p.returncode,flush=True)
 if p.returncode: print(p.stdout.decode(errors='replace')[-5000:],p.stderr.decode(errors='replace')[-5000:],flush=True)
 p.check_returncode()
command=json.loads((ROOT/'compile-test.command.json').read_text())['argv']
command[command.index('-c')+1]=str(ROOT/'tests/compute_route_apple/native_cache_models_test.cc')
command[command.index('-o')+1]=str(ROOT/'models-test.o')
run('compile-models-test',command)
command=json.loads((ROOT/'link-recurrent-path-fix.command.json').read_text())['argv']
command=[str(ROOT/'models-test.o') if x==str(ROOT/'test.o') else x for x in command]
command[command.index('-o')+1]=str(ROOT/'highdim-models-tests')
command[-1]='-Wl,-map,'+str(ROOT/'highdim-models-tests.map')
run('link-models-test',command)
run('models-tests',[str(ROOT/'highdim-models-tests'),'--gtest_filter=AppleCache.PlainHighDimensionsKeepPageMappingAndIndependentValues','--gtest_throw_on_failure','--gtest_fail_fast','--gtest_output=json:'+str(ROOT/'models-tests.json')])
result=json.loads((ROOT/'models-tests.json').read_text());assert result['tests']==1 and result['failures']==result['errors']==0
(ROOT/'model-artifacts.json').write_text(json.dumps([rec(ROOT/name) for name in ['models-test.o','highdim-models-tests']],indent=2)+'\n')
