from pathlib import Path
import hashlib,json,os,re,subprocess,time

ROOT=Path(__file__).resolve().parent
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CORE=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
MLX=CORE/'hyle/_deps/mlx-490c5876b63c15e8/source'
FMT=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/fmt-407c905e45ad-cd0d9446fff4/include')
GTEST=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
MTP=ROOT.parent/'mtp-gdn-snapshots-20261018'
STRIDE=ROOT.parent/'library-review-20261018-apple-native-mask-strides'
FLAGS=['-O3','-DNDEBUG','-std=c++23','-arch','arm64','-DHYLE_STATIC','-DMLX_STATIC','-DHYLE_COMPUTE_APPLE=1','-DHYLE_COMPUTE_ROUTE_APPLE_API=','-Wall','-Wextra','-Wpedantic','-Werror']
FLAGS += ['-D'+macro+'=' for macro in sorted(set().union(*(set(re.findall(r'\bHYLE_[A-Z0-9_]+_API\b',p.read_text())) for p in (ROOT/'include').rglob('*.h')))) if macro!='HYLE_COMPUTE_ROUTE_APPLE_API']
INC=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(ROOT/'src/compute'),'-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp'),'-isystem',str(GTEST)]
LIBS=[SDK/'lib'/('lib'+name+'.a') for name in ['hyle_graph','hyle_compute_route_apple','hyle_compute_stream','hyle_compute_state','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_simd','hyle_sched','hyle_container','hyle_mem_vm','hyle_mem','mimalloc_static','hyle_platform_thread','hyle_time','hyle_platform','hyle_error','hyle_compute_provider_ggml_metal','hyle_compute_ggml_runtime','ggml','ggml-metal','ggml-base','mlx']]
FRAMEWORKS=['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore']
commands=json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
def save(name,obj): (ROOT/name).write_text(json.dumps(obj,indent=2)+'\n')
def record(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,args):
 assert not (ROOT/(tag+'.command.json')).exists(),tag
 args=list(map(str,args));start=time.monotonic();p=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=300)
 item=dict(tag=tag,argv=args,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start)
 commands.append(item);save(tag+'.command.json',item);save('commands.json',commands)
 (ROOT/(tag+'.stdout.log')).write_bytes(p.stdout);(ROOT/(tag+'.stderr.log')).write_bytes(p.stderr)
 print(tag,p.returncode,item['seconds'],flush=True)
 if p.returncode:
  print(p.stdout.decode(errors='replace')[-4500:],p.stderr.decode(errors='replace')[-6000:],flush=True)
  raise SystemExit(p.returncode)

model=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip();assert model=='Mac16,12'
if not (ROOT/'mlx.metallib').exists(): (ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
assert (ROOT/'mlx.metallib').resolve()==(SDK/'lib/mlx.metallib').resolve()
steel=STRIDE/'candidate/steel_attention.o'
assert record(steel)['sha256']=='868bdff604640df9aa6a94eb01910ad11c5975de3a2b74905fcd6d98ddf2d351'
save('runtime-identities.json',dict(model=model,hardware=subprocess.check_output(['/usr/sbin/sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True),compiler=subprocess.check_output(['/usr/bin/clang++','--version'],text=True),retained_steel=record(steel),SDK_libraries=[record(p) for p in LIBS],metallib=str((ROOT/'mlx.metallib').resolve()),environment={k:v for k,v in os.environ.items() if k.startswith(('MLX_','MTL_','METAL_','HYLE_'))},full_SDK_rebuild=False,SDK_copied=False,perf_run=False))
nativeflags=[*FLAGS,'-Wno-unused-parameter','-Wno-sign-compare','-Wno-unused-lambda-capture','-DFMT_HEADER_ONLY=1','-DMLX_METAL_NO_NAX']
nativeinc=['-I'+str(ROOT/'native-candidate'),'-I'+str(STRIDE/'candidate'),'-isystem',str(MLX),'-isystem',str(FMT),'-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp')]
artifacts=[]
try:
 for tag,source,obj,flags,inc in [
  ('fast','native-candidate/mlx/fast.cpp','fast.o',nativeflags,nativeinc),
  ('native-host','native-candidate/mlx/backend/metal/scaled_dot_product_attention.cpp','native-host.o',nativeflags,nativeinc),
  ('diagnostic-host-fix','diagnostic-host.cpp','diagnostic-host.o',nativeflags,nativeinc),
  ('apple_context-private-header-fix','src/compute_route_apple/apple_context.cc','apple_context.o',FLAGS,INC),
  *[(name,'src/compute_route_apple/'+name+'.cc',name+'.o',FLAGS,INC) for name in ['apple_operations','apple_tensor','apple_batch','apple_materialized_invocation']],
  ('test','tests/compute_route_apple/native_cache_test.cc','test.o',FLAGS,INC)]:
  prior=ROOT/('compile-'+tag+'.command.json')
  if prior.exists():
   assert json.loads(prior.read_text())['exit']==0 and (ROOT/obj).is_file()
  else: run('compile-'+tag,['/usr/bin/clang++',*flags,*inc,'-c',ROOT/source,'-o',ROOT/obj])
  artifacts.append(ROOT/obj)
 # Current schema operation object from the MTP batch avoids old operation ABI.
 ops=[MTP/name for name in ['ops.o','ops-tensor_desc.cc.o','ops-low_precision.cc.o','ops-weight_decode.cc.o','ops-sampling_ops.cc.o']]
 recurrent=MTP/'recurrent.o'
 leading=[ROOT/'test.o',*[ROOT/(n+'.o') for n in ['apple_context','apple_operations','apple_tensor','apple_batch','apple_materialized_invocation']],recurrent,MTP/'native.o',ROOT/'fast.o',ROOT/'diagnostic-host.o',steel,*ops]
 exe=ROOT/'highdim-tests'
 run('link-recurrent-path-fix',['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64','-o',exe,*leading,*LIBS,CORE/'lib/libgtest_main.a',CORE/'lib/libgtest.a',*FRAMEWORKS,'-Wl,-map,'+str(ROOT/'highdim-tests.map')]);artifacts.append(exe)
 mapping=(ROOT/'highdim-tests.map').read_text()
 assert all(str(p) in mapping for p in leading)
 assert all('libmlx.a('+name+')' not in mapping for name in ['fast.cpp.o','scaled_dot_product_attention.cpp.o','steel_attention.cpp.o'])
 run('tests',[exe,'--gtest_filter=AppleCache.PlainHighDimensionsKeepPageMappingAndIndependentValues','--gtest_throw_on_failure','--gtest_fail_fast','--gtest_output=json:'+str(ROOT/'tests.json')])
 result=json.loads((ROOT/'tests.json').read_text());assert result['tests']==1 and result['failures']==result['errors']==0
 save('completed.json',dict(status='passed',tests=1,cases=8,normal_host_compiled=True,executed_host='product plus probe-only highdim PSO stderr print',retained_ops=[record(p) for p in ops]))
finally:
 save('cleanup-candidates.json',dict(host='kiro@172.22.10.198',files=[record(p) for p in artifacts if p.exists()],performed_cleanup=False,retain='all source/log/maps/data/archives, SDK/cache, original native and MTP objects'))
