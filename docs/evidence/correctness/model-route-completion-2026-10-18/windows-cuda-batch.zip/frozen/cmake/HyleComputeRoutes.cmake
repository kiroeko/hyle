include_guard(GLOBAL)

# Keep route identity, public expert roots and hybrid bridges together. This is
# private assembly metadata, not another user selector or a second factor DAG.
function(_hyle_compute_route_names output)
  set(${output} cpu cuda apple vulkan PARENT_SCOPE)
endfunction()

function(_hyle_compute_route_metadata route prefix)
  set(_shared "")
  set(_compute "compute_route_${route}")
  set(_graph "graph_route_${route}")
  set(_bridge "")
  set(_processor "")
  if(route STREQUAL "cpu")
    set(_shared compute_backend_cpu compute_provider_native
      compute_provider_onednn compute_provider_ggml)
    list(APPEND _graph graph_provider_onednn)
    set(_anchors ${_shared})
    # Exact CPU factors need not carry the complete route's ATen SDK.
    set(_systems ".*")
  elseif(route STREQUAL "cuda")
    set(_shared compute_backend_cuda compute_provider_cublas
      compute_provider_cuda compute_provider_ggml_cuda compute_provider_torch_cuda)
    list(APPEND _shared compute_provider_flashinfer)
    list(APPEND _graph graph_provider_ggml_cuda)
    set(_anchors compute_backend_cuda)
    set(_systems "Windows|Linux")
    set(_bridge graph_route_cpu_cuda)
  elseif(route STREQUAL "apple")
    set(_anchors compute_route_apple compute_provider_ggml_metal)
    set(_systems Darwin)
    set(_processor aarch64)
    set(_bridge graph_route_cpu_apple)
  elseif(route STREQUAL "vulkan")
    set(_anchors compute_route_vulkan compute_provider_ggml_vulkan
      compute_provider_iree_vulkan)
    set(_systems "Windows|Linux|Darwin")
    set(_bridge graph_route_cpu_vulkan)
  else()
    message(FATAL_ERROR "Unknown internal Compute route '${route}'")
  endif()
  foreach(_field IN ITEMS shared compute graph bridge anchors systems processor)
    set(${prefix}_${_field} "${_${_field}}" PARENT_SCOPE)
  endforeach()
endfunction()

function(_hyle_compute_cpu_provider_supported provider output)
  set(_supported OFF)
  if(provider STREQUAL "onednn")
    if(CMAKE_SYSTEM_NAME MATCHES "^(Windows|Linux|Darwin)$" AND
       HYLE_TARGET_PROCESSOR STREQUAL "x86_64")
      set(_supported ON)
    endif()
  elseif(provider STREQUAL "torch_cpu")
    if((CMAKE_SYSTEM_NAME MATCHES "^(Windows|Linux)$" AND
        HYLE_TARGET_PROCESSOR STREQUAL "x86_64") OR
       (CMAKE_SYSTEM_NAME STREQUAL "Darwin" AND
        HYLE_TARGET_PROCESSOR STREQUAL "aarch64"))
      set(_supported ON)
    endif()
  else()
    message(FATAL_ERROR "Unknown internal CPU Provider '${provider}'")
  endif()
  set(${output} "${_supported}" PARENT_SCOPE)
endfunction()

function(_hyle_compute_route_supported route output)
  _hyle_compute_route_metadata("${route}" _route)
  set(_supported OFF)
  if(CMAKE_SYSTEM_NAME MATCHES "^(${_route_systems})$" AND
      (_route_processor STREQUAL "" OR
       HYLE_TARGET_PROCESSOR STREQUAL _route_processor))
    set(_supported ON)
  endif()
  set(${output} "${_supported}" PARENT_SCOPE)
endfunction()

function(hyle_compute_product_roots product routes output)
  if(product STREQUAL "compute")
    set(_roots compute compute_state compute_batch)
  elseif(product STREQUAL "graph")
    set(_roots graph graph_batch)
  else()
    message(FATAL_ERROR "Not a Compute/Graph product: '${product}'")
  endif()
  foreach(_route IN LISTS routes)
    _hyle_compute_route_metadata("${_route}" _data)
    list(APPEND _roots ${_data_shared} ${_data_${product}})
    if(product STREQUAL "graph" AND "cpu" IN_LIST routes AND _data_bridge)
      list(APPEND _roots ${_data_bridge})
    endif()
  endforeach()
  list(REMOVE_DUPLICATES _roots)
  set(${output} "${_roots}" PARENT_SCOPE)
endfunction()

# Public products select one complete route set. Maintenance factors derive
# private availability from their actual DAG rather than offering a lite SKU.
function(_hyle_reject_legacy_compute_options)
  foreach(_name IN ITEMS HYLE_COMPUTE_CPU HYLE_COMPUTE_CUDA HYLE_COMPUTE_APPLE
      HYLE_COMPUTE_VULKAN HYLE_COMPUTE_ONEDNN HYLE_COMPUTE_TORCH_CPU)
    if(DEFINED ${_name})
      message(FATAL_ERROR
        "${_name} is no longer a public build option. Use "
        "HYLE_COMPUTE_ROUTES=cpu, cuda, apple, vulkan, or a semicolon-separated "
        "set such as 'cpu;cuda'. Remove the old option from the parent/preset "
        "or clear its cached value with cmake -U ${_name}; required Providers are automatic.")
    endif()
  endforeach()
endfunction()

function(_hyle_parse_compute_routes value output)
  if(value STREQUAL "")
    message(FATAL_ERROR "HYLE_COMPUTE_ROUTES must be a nonempty route set")
  endif()
  set(_requested "${value}")
  _hyle_compute_route_names(_known)
  set(_normalized "")
  foreach(_route IN LISTS _requested)
    string(STRIP "${_route}" _route)
    string(TOLOWER "${_route}" _route)
    if(NOT _route IN_LIST _known)
      message(FATAL_ERROR
        "Unknown HYLE_COMPUTE_ROUTES item '${_route}'; use cpu, cuda, apple, "
        "vulkan or a semicolon-separated set. AUTO and empty items are not routes.")
    endif()
    list(APPEND _normalized "${_route}")
  endforeach()
  # Canonical order is identity only, never provider/device preference.
  set(_canonical "")
  foreach(_route IN LISTS _known)
    if(_route IN_LIST _normalized)
      list(APPEND _canonical "${_route}")
    endif()
  endforeach()
  set(${output} "${_canonical}" PARENT_SCOPE)
endfunction()

function(_hyle_check_compute_route_platform routes)
  foreach(_route IN LISTS routes)
    if(_route STREQUAL "cpu")
      _hyle_compute_cpu_provider_supported(torch_cpu _supported)
      if(NOT _supported)
        message(FATAL_ERROR
          "The complete CPU route requires Windows/Linux x86_64 or macOS ARM64 "
          "for its locked ATen SDK; '${CMAKE_SYSTEM_NAME}/${HYLE_TARGET_PROCESSOR}' "
          "has no supported complete CPU recipe. Select another supported route.")
      endif()
    elseif(_route STREQUAL "cuda")
      # A complete CUDA product also carries the locked ATen CPU host runtime.
      # Exact backend factors retain their own, broader SDK platform checks.
      _hyle_compute_route_supported(cuda _supported)
      _hyle_compute_cpu_provider_supported(torch_cpu _host_supported)
      if(NOT _supported OR NOT _host_supported)
        message(FATAL_ERROR
          "The complete CUDA route requires Windows/Linux x86_64 for its locked "
          "ATen host SDK; '${CMAKE_SYSTEM_NAME}/${HYLE_TARGET_PROCESSOR}' has no "
          "supported complete CUDA recipe. Select another supported route.")
      endif()
    else()
      _hyle_compute_route_supported("${_route}" _supported)
      if(_supported)
        continue()
      elseif(_route STREQUAL "apple")
        message(FATAL_ERROR "The Apple route requires macOS Apple Silicon")
      else()
        message(FATAL_ERROR "The Vulkan route requires Windows, Linux, or macOS")
      endif()
    endif()
  endforeach()
endfunction()

# Used inside the resolver functions; publish to their calling project scope.
macro(_hyle_publish_compute_routes routes)
  set(_active "${routes}")
  set(HYLE_COMPUTE_ROUTE_LIST "${_active}" PARENT_SCOPE)
  _hyle_compute_route_names(_known)
  foreach(_route IN LISTS _known)
    string(TOUPPER "${_route}" _upper)
    if(_route IN_LIST _active)
      set(_HYLE_COMPUTE_REQUEST_${_upper} ON PARENT_SCOPE)
    else()
      set(_HYLE_COMPUTE_REQUEST_${_upper} OFF PARENT_SCOPE)
    endif()
  endforeach()
endmacro()

function(hyle_resolve_compute_product_routes products)
  _hyle_reject_legacy_compute_options()
  if(NOT "compute" IN_LIST products AND NOT "graph" IN_LIST products)
    _hyle_publish_compute_routes("")
    return()
  endif()
  if(DEFINED HYLE_COMPUTE_ROUTES)
    set(_input "${HYLE_COMPUTE_ROUTES}")
  else()
    set(_input cpu)
  endif()
  _hyle_parse_compute_routes("${_input}" _routes)
  _hyle_check_compute_route_platform("${_routes}")
  set(HYLE_COMPUTE_ROUTES "${_routes}" CACHE STRING
    "Complete Compute routes: cpu;cuda;apple;vulkan (a nonempty subset)" FORCE)
  set(HYLE_COMPUTE_ROUTES "${_routes}" PARENT_SCOPE)
  _hyle_publish_compute_routes("${_routes}")
endfunction()

function(hyle_resolve_compute_factor_routes)
  _hyle_reject_legacy_compute_options()
  if(DEFINED HYLE_COMPUTE_ROUTES)
    message(FATAL_ERROR
      "HYLE_DEV_FACTORS derives native availability from its exact factor/test "
      "closure. Do not combine it with the product selector HYLE_COMPUTE_ROUTES; "
      "clear a previous product selection with cmake -U HYLE_COMPUTE_ROUTES.")
  endif()
  set(_routes "")
  _hyle_compute_route_names(_known)
  foreach(_route IN LISTS _known)
    _hyle_compute_route_supported("${_route}" _supported)
    if(NOT _supported)
      continue()
    endif()
    _hyle_compute_route_metadata("${_route}" _data)
    foreach(_anchor IN LISTS _data_anchors)
      string(TOUPPER "${_anchor}" _upper)
      if(HYLE_BUILD_${_upper})
        list(APPEND _routes "${_route}")
        break()
      endif()
    endforeach()
  endforeach()
  _hyle_publish_compute_routes("${_routes}")
endfunction()
