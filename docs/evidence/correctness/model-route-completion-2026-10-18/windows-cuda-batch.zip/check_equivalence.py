from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
SOURCE = ROOT / '.scratch/g04-bf16-product-c6-vendor/materialized-canonical'
CURRENT = OUT / 'verified-headers/include/flashinfer'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pairs = []
for name, relative in [('math', 'math.cuh'), ('pos_enc', 'pos_enc.cuh'),
                       ('scheduler', 'attention/scheduler.cuh'),
                       ('decode', 'attention/decode.cuh')]:
    measured, current = OUT / (name + '.portable.cuh'), CURRENT / relative
    assert measured.read_bytes() == current.read_bytes(), relative
    pairs.append(dict(current=str(current), measured=str(measured), sha256=sha(current),
                      comparison='byte-identical'))
current = (CURRENT / 'vec_dtypes.cuh').read_text()
selected = ('#if defined(_MSC_VER)\n#define FLASHINFER_INLINE __forceinline__ __device__\n#else\n'
            '#define FLASHINFER_INLINE inline __attribute__((always_inline)) __device__\n#endif')
assert current.count(selected) == 1
assert current.replace(selected, '#define FLASHINFER_INLINE __forceinline__ __device__') == (
    OUT / 'vec_dtypes.portable.cuh').read_text()
pairs.append(dict(current=str(CURRENT / 'vec_dtypes.cuh'),
                  measured=str(OUT / 'vec_dtypes.portable.cuh'),
                  comparison='exactly the same FLASHINFER_INLINE selected when _MSC_VER is defined'))
for name in ['prefill.cuh', 'cascade.cuh']:
    measured, current = SOURCE / 'include/flashinfer/attention' / name, CURRENT / 'attention' / name
    assert measured.read_bytes() == current.read_bytes()
    pairs.append(dict(current=str(current), measured=str(measured), sha256=sha(current),
                      comparison='byte-identical original v15 algorithm patch'))
(OUT / 'current-vs-compiled-headers.json').write_text(json.dumps(dict(
    comparisons=pairs,
    note='Measured native_batch/cache/attention used the retained canonical v15 source and explicit header overlays. Current manifest replay has the same selected header content; native_cache_encoder.current.obj also compiled directly with the final replay recipe.',
), indent=2) + '\n')
print('PASS current-manifest versus compiled header equivalence')
