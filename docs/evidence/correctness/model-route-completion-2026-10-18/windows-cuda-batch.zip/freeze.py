from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
owned = [
    'cmake/HyleComputeRoutes.cmake', 'cmake/HyleDependencyLock.json',
    'src/compute_provider_flashinfer/CMakeLists.txt',
    'src/compute_provider_flashinfer/flashinfer_provider.cc',
    'src/compute_provider_flashinfer/native_attention.cu',
    'src/compute_provider_flashinfer/native_batch.cu',
    'src/compute_provider_flashinfer/native_cache.cu',
    'src/compute_provider_flashinfer/native_cache_encoder.cu',
    'src/compute_provider_flashinfer/native_attention.h',
    'src/compute_provider_flashinfer/native_batch.h',
    'src/compute_route_cuda/CMakeLists.txt',
    'tests/compute_provider_flashinfer/CMakeLists.txt',
    'tests/compute_batch/public_batch_cuda_consumer.cc',
    'tests/tooling/product_macro_contract_test.py',
    'third_party/flashinfer_cache/patches.json',
    'third_party/flashinfer_cache/NOTICE.md',
    'include/hyle/compute/cuda.h', 'include/hyle/compute/providers/flashinfer.h',
    'include/hyle/compute/detail/batch_provider.h', 'src/compute/provider_internal.h',
]
for name in ['component', 'default', 'default-kernels', 'batch-host']:
    for entry in json.loads((OUT / (name + '-identities.json')).read_text()):
        source = Path(entry['source'])
        assert sha(source) == entry['source_sha256'], source
        relative = source.relative_to(ROOT).as_posix()
        if relative not in owned:
            owned.append(relative)
snapshot = OUT / 'frozen'
identities = []
for relative in owned:
    source, destination = ROOT / relative, snapshot / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    identities.append(dict(path=relative, bytes=source.stat().st_size, sha256=sha(source)))
(OUT / 'canonical-source-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
diff = subprocess.check_output(['git', 'diff', '--', *owned,
    'tests/compute_batch/public_batch_cuda_absence_consumer.cc'], cwd=ROOT)
(OUT / 'product.diff').write_bytes(diff)
for path in OUT.glob('*hostsyntax.cpp'):
    text = path.read_text(errors='replace')
    lines = text.splitlines()
    matches = [i for i, line in enumerate(lines) if 'BatchQKApplyLlama31Rotary' in line]
    excerpts = '\n'.join('\n'.join(lines[max(0, i-2):i+8]) for i in matches)
    (OUT / (path.stem + '.excerpt.txt')).write_text(excerpts + '\n')
    (OUT / (path.stem + '.identity.json')).write_text(json.dumps(dict(
        path=str(path), bytes=path.stat().st_size, sha256=sha(path),
        disposition='generated nvcc host source, reproducible from preserved command; only the relevant restrict excerpt is archived',
    ), indent=2) + '\n')
run = (OUT / 'public-default-batch-run.stdout.log').read_text()
assert run.count('Direct/Graph GQA/causal/active-capacity/page-tail/old-output PASS') == 8
errors = [float(value) for value in re.findall(r'maxError=([0-9.e+-]+)', run)]
assert len(errors) == 16 and max(errors) < .007
commands = json.loads((OUT / 'host-commands.json').read_text())
native_commands = [json.loads((OUT / filename).read_text()) for filename in [
    'native-batch-portable-llp64-posenc-command.json',
    'native-cache-portable-llp64-posenc-command.json',
    'native-attention-portable-llp64-posenc-decode-command.json',
    'native_cache_encoder.cu.current.command.json',
]]
assert all(command['exit'] == 0 for command in native_commands)
summary = dict(
    result='PASS bounded Windows native FlashInfer batch port and GQA ratio six',
    platform=dict(os='Windows x64', gpu='NVIDIA GeForce RTX 4070', sm='8.9',
                  driver='617.14', vram_mib=12282, cuda='13.3', msvc='19.50 / toolset 14.50.35717'),
    dependency=dict(revision='69ff11fc4954396d98326656dc85debd2223f637',
                    archive_sha256='4fc85abaa6210d6a1773e6011ff572aa0c04b7030644b74f75a2db2dbda472a9',
                    manifest_sha256=sha(ROOT / 'third_party/flashinfer_cache/patches.json'),
                    version='hyle-flashinfer-msvc-portability-v16',
                    tree_sha256='074deb1bf532d5d613cfa7db01d8fdd0a5c2fc45cbc605dc4cf980eee115ca68',
                    notice_sha256=sha(ROOT / 'third_party/flashinfer_cache/NOTICE.md'),
                    upgrade=False, custom_kernel=False),
    native_compile=[dict(command=entry['command'], seconds=entry['seconds'], exit=entry['exit'])
                    for entry in native_commands],
    runtime=dict(exit=0, seconds=commands[-1]['seconds'],
                 ordinary_default_context='Actual complete current default CUDA factory linked with real native/ggml/Torch/cuBLAS factories; create_context and H24/KV4 D256 BatchProgram::prepare PASS',
                 component_consumer='Actual Direct BatchInvocation and generic Graph batch provider wrapper using FlashInfer, two requests, active capacity, nonuniform payload, causal bottom-right, permuted physical page IDs/page tails and old-output retention',
                 storage=['ragged', 'paged'], types=['F16', 'BF16'],
                 heads=[dict(query=4, kv=2), dict(query=24, kv=4)],
                 depth=256, direct_graph_cases=8, complete_output_oracles=16,
                 fp64_oracle_absolute_budget=.007, maximum_absolute_error=max(errors),
                 all_maximum_absolute_errors=errors,
                 ordinary_default_graph_runtime=False),
    source_proof=dict(group6='BatchPrefill scheduler uses runtime gqa_group_size and uint_fastdiv; no power-of-two GQA template dispatch in this batch path. Only add six to existing qualifier.',
                      portability='MSVC CUDA forceinline; unsigned short for two 16-bit temporaries; seven size_t/int64_t max calls independent of LP64/LLP64; CUDA shared spelling; remove only two unused host-wrapper restrict annotations.',
                      numeric_algorithm_or_storage_change=False),
    controls=dict(
        product_macro='Agent ran the single product macro fixture PASS (Windows/Linux); root independently repeated with python -X utf8 and reported 1.077s PASS. No SDK configure/build.',
        dependency_audit='Root independently ran check_flashinfer_lock.cmake, exit0, 0.62s; FlashInfer vendor tree and license identities agree with lock.',
        diff_check='Owned source git diff --check PASS'),
    failures_retained=[
        'Initial CCCL missing conforming MSVC preprocessor, GNU always_inline, ushort/LLP64 max, and nvcc host restrict failures; global restrict macro attempt rejected because it damages CRT declspec.',
        'Initial native_attention exposed equivalent decode max/shared portability failures; corrected in the current exact manifest.',
        'First full default link exposed two stale cached native CUDA seams: concat_prepare signature and absent sampling launch. Rebuilt only their two small current kernel TUs; second link PASS.',
        'First runtime used stale compute_batch/graph_batch host cache and reported no native BatchPlanning. Fresh current batch_execution.cc and graph_batch/batch.cc restored the current private extension contract; final runtime PASS. Exact contribution of the two stale host objects was not isolated.',
    ],
    replay=dict(final='replay_current.py validates before/edit/after SHA from cached original source and writes only seven overlay headers; optional TU argument compiles against the current manifest.',
                verified='Current replay compiled native_cache_encoder.cu successfully. Other three compiled overlays are byte-identical to the final headers except vec_dtypes conditional, whose MSVC branch is exactly the measured definition; check_equivalence.py PASS.',
                historical='probe.py explicitly uses patches.before.json and the old prepared v15 source plus local overlays. It reproduces historical failure stages, not a standalone final product build.'),
    limits=[
        'Runtime only this Windows RTX4070 SM89. Existing Linux runtime not rerun; no new GPU architecture qualification.',
        'Runtime depths only D256, plain F16/BF16; native D64/128 and existing encoded/cache variants were compiled, not requalified across all numerical/resource/failure domains.',
        'D512/576 MLA BatchPlanning remains unsupported; no general arbitrary GQA expansion beyond added ratio six.',
        'Ordinary default compute Context discovery/prepare is real; numerical Direct/Graph runs use the component wrapper, not a complete default Graph route runtime or installed SDK consumer.',
        'Full default registry reuses cached unrelated device-kernel and Torch/ggml objects with exact recorded identities. The legacy ggml validation tensor object declines three unrelated IQ1 formats; this is not evidence for those features.',
        'No throughput, latency or peak-space measurement; CUDA graph capture/fault injection/installation runtime not rerun.',
    ],
    sdk_copy_or_download=False, operations_after_runtime='source/log/identity packaging only; no further compile or GPU run',
)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
retain_names = {p.name for p in [
    OUT / 'native-batch-portable-llp64-posenc.obj', OUT / 'native-cache-portable-llp64-posenc.obj',
    OUT / 'native-attention-portable-llp64-posenc-decode.obj', OUT / 'native_cache_encoder.current.obj']}
files, retained = [], []
for path in sorted(OUT.iterdir(), key=lambda p:p.name):
    if path.is_file() and (path.suffix in ['.obj', '.exe', '.exp', '.lib', '.pdb', '.ilk'] or path.name.endswith('hostsyntax.cpp')):
        entry = dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=sha(path))
        (retained if path.name in retain_names else files).append(entry)
assert len({entry['path'] for entry in files + retained}) == len(files + retained)
(OUT / 'cleanup-candidates.json').write_text(json.dumps(dict(
    platform='Windows', root=str(OUT), delete_candidates=files,
    retain_suggested=retained,
    rationale='The four completed FlashInfer native objects cost about 13 minutes for the large cache TU and are useful shared validation cache. Parent chooses retention; no deletion performed.',
    delete_count=len(files), delete_logical_bytes=sum(entry['bytes'] for entry in files),
    retain_count=len(retained), retain_logical_bytes=sum(entry['bytes'] for entry in retained),
    shared_cache_sdk_sources_logs_maps_archives='retain; no external path is a deletion candidate',
), indent=2) + '\n')
for name in ['sync_flashinfer_lock.py', 'check_flashinfer_lock.cmake']:
    shutil.copyfile(OUT.parent / name, OUT / name)
zip_path = OUT / 'source-results.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(OUT.rglob('*'), key=lambda p:p.as_posix()):
        if (not path.is_file() or '__pycache__' in path.parts or path == zip_path
                or path.name == 'archive-identity.json'):
            continue
        if path.suffix.lower() in ['.py', '.json', '.log', '.txt', '.md', '.diff', '.cmake', '.cc', '.cu', '.cuh', '.h', '.map']:
            archive.write(path, path.relative_to(OUT).as_posix())
identity = dict(path=str(zip_path), bytes=zip_path.stat().st_size, sha256=sha(zip_path),
                summary_sha256=sha(OUT / 'summary.json'),
                cleanup_sha256=sha(OUT / 'cleanup-candidates.json'))
(OUT / 'archive-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity, indent=2))
