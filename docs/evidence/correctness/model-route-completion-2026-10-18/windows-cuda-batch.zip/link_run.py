from pathlib import Path
import json
import os
import sys
import build_host as b

ROOT, OUT, BASE, TOOLKIT = b.ROOT, b.OUT, b.BASE, b.TOOLKIT
native = ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-static'
strict = ROOT / '.scratch/perf-review-2026-10-18/ggml-attention-provider/ggml-cuda.strict.obj'
mtp = ROOT / '.scratch/mtp-completion'
old_device = ROOT / '.scratch/b-cuda-d5/src/compute_provider_cuda/CMakeFiles/hyle_compute_provider_cuda.dir'
native_objects = [
    OUT / 'native-batch-portable-llp64-posenc.obj',
    OUT / 'native-cache-portable-llp64-posenc.obj',
    OUT / 'native-attention-portable-llp64-posenc-decode.obj',
    OUT / 'native_cache_encoder.current.obj',
]
objects = [OUT / 'public-consumer.obj', OUT / 'flashinfer-provider.obj', *native_objects]
objects += [OUT / (name + '.obj') for name in ['batch-execution', 'graph-batch']]
objects += [Path(entry['object']) for entry in json.loads((OUT / 'default-identities.json').read_text())]
objects += [mtp / (name + '.obj') for name in ['operation', 'provider', 'tensor', 'region']]
objects += [old_device / name for name in [
    'collectives.cu.obj', 'native_kernel.cu.obj',
    'norm_kernel.cu.obj', 'reduction_kernel.cu.obj', 'scatter_kernel.cu.obj',
    'sglang_kernel.cu.obj', 'sglang_norm_kernel.cu.obj', 'sglang_router_kernel.cu.obj',
    'tensor_kernel.cu.obj',
]]
objects += [OUT / (name + '.current.obj') for name in ['concat_kernel', 'sampling_kernel']]
objects.append(strict)
libs = [BASE / 'bin' / (name + '.lib') for name in [
    'hyle_graph', 'hyle_graph_batch', 'hyle_compute_backend_cuda', 'hyle_compute_state',
    'hyle_compute_batch', 'hyle_compute_ggml_runtime', 'hyle_compute_provider_torch_cuda',
    'hyle_compute', 'hyle_compute_ops', 'hyle_container', 'hyle_mem', 'mimalloc_static',
    'hyle_platform', 'hyle_error', 'hyle_platform_thread', 'hyle_time', 'hyle_simd',
]]
libs += [native / 'bin' / (name + '.lib') for name in ['ggml', 'ggml-cuda', 'ggml-base']]
torch_link = json.loads((ROOT / '.scratch/perf-review-2026-10-18/bf16-sdpa-hyle/link-command.json').read_text())
torch_libs = list(dict.fromkeys(Path(p) for p in torch_link if Path(p).is_absolute() and p.endswith('.lib')))
libs += torch_libs
libs += [TOOLKIT / 'lib/x64' / (name + '.lib') for name in ['cudart', 'cublas', 'cublasLt', 'cuda']]
libs = list(dict.fromkeys(libs))
system = ['bcrypt.lib', 'PowrProf.lib', 'Synchronization.lib', 'advapi32.lib', 'user32.lib',
          'shell32.lib', 'ole32.lib', 'ws2_32.lib', 'gdi32.lib', 'winspool.lib',
          'oleaut32.lib', 'uuid.lib', 'comdlg32.lib']
for lib in torch_libs:
    b.env['PATH'] = str(lib.parent) + os.pathsep + b.env['PATH']
b.env['PATH'] = str(TOOLKIT / 'bin') + os.pathsep + b.env['PATH']
exe = OUT / 'public-batch.exe'
if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'link':
        for path in [*objects, *libs]:
            assert path.is_file(), path
        b.run('public-default-batch-link', [b.link, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE',
              '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(exe),
              '/MAP:' + str(OUT / 'public-batch.map'), *objects, *libs, *system])
        (OUT / 'link-identities.json').write_text(json.dumps([
            dict(path=str(p), bytes=p.stat().st_size, sha256=b.sha(p)) for p in [*objects, *libs, exe]
        ], indent=2) + '\n')
    elif action == 'run':
        b.run('hardware', ['nvidia-smi', '--query-gpu=name,compute_cap,driver_version,memory.total', '--format=csv'])
        b.run('public-default-batch-run', [exe])
    else:
        raise ValueError(action)
