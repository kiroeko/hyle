include("${CMAKE_CURRENT_LIST_DIR}/../../cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(flashinfer_cache_patches)
message(STATUS "FlashInfer vendor tree and license identities agree with lock")
