"""Replay the current exact manifest onto cached upstream headers; no SDK copy/download.

Usage: python replay_current.py [native_batch.cu|native_cache.cu|native_attention.cu|native_cache_encoder.cu]
Without a TU, only verifies/writes the seven changed headers. Historical probe.py
uses patches.before.json and explicit overlays and is not the final build recipe.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RAW = ROOT / '.scratch/g04-bf16-partials-vendor/upstream'
OVERLAY = OUT / 'verified-headers'
manifest_path = ROOT / 'third_party/flashinfer_cache/patches.json'
manifest = json.loads(manifest_path.read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
identities = []
for entry in manifest['files']:
    data = (RAW / entry['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == entry['before_sha256'], entry['path']
    for edit in entry['edits']:
        before, after = edit['before'].encode(), edit['after'].encode()
        assert data.count(before) == 1, (entry['path'], edit['before'])
        data = data.replace(before, after, 1)
    assert sha(data) == entry['after_sha256'], entry['path']
    destination = OVERLAY / entry['path']
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    identities.append(dict(path=entry['path'], sha256=sha(data)))
(OUT / 'current-replay-identities.json').write_text(json.dumps(dict(
    upstream_revision=manifest['upstream_revision'], manifest_sha256=sha(manifest_path.read_bytes()),
    raw_cached_source=str(RAW), headers=identities, sdk_copy_or_download=False,
    overlay_only=True), indent=2) + '\n')
if len(sys.argv) == 1:
    print('PASS current manifest exact replay', len(identities), 'headers')
    raise SystemExit(0)
unit = sys.argv[1]
assert unit in ['native_batch.cu', 'native_cache.cu', 'native_attention.cu', 'native_cache_encoder.cu']
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache = read_cache(ROOT / '.scratch/build-compute-v2-dev')
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
toolkit = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
env['PATH'] = str(toolkit / 'bin/x64') + os.pathsep + env['PATH']
command = [str(toolkit / 'bin/nvcc.exe'), '--std=c++17', '--gpu-architecture=sm_89',
           '--compiler-bindir', str(Path(cache['CMAKE_CXX_COMPILER']).parent),
           '-Xcompiler=/MD,/EHsc,/Zc:preprocessor,/utf-8', '-O2', '-DNDEBUG', '-DNOMINMAX',
           '-DFLASHINFER_ENABLE_BF16', '-DFLASHINFER_ENABLE_F16']
for directory in [OVERLAY / 'include', OVERLAY / 'include/flashinfer',
                  OVERLAY / 'include/flashinfer/attention', RAW / 'include',
                  RAW / 'include/flashinfer', RAW / 'include/flashinfer/attention']:
    command.append('-I' + str(directory))
# Relative includes in upstream headers must not bypass verified replacements.
for relative in ['vec_dtypes.cuh', 'math.cuh', 'pos_enc.cuh',
                 'attention/scheduler.cuh', 'attention/decode.cuh',
                 'attention/prefill.cuh', 'attention/cascade.cuh']:
    header = OVERLAY / 'include/flashinfer' / relative
    if header.exists():
        command += ['--pre-include', str(header)]
command += ['-c', str(ROOT / 'src/compute_provider_flashinfer' / unit),
            '-o', str(OUT / (Path(unit).stem + '.current.obj'))]
start = time.monotonic()
p = subprocess.run(command, cwd=OUT, env=env, capture_output=True)
(OUT / (unit + '.current.stdout.log')).write_bytes(p.stdout)
(OUT / (unit + '.current.stderr.log')).write_bytes(p.stderr)
(OUT / (unit + '.current.command.json')).write_text(json.dumps(dict(
    command=command, cwd=str(OUT), exit=p.returncode, seconds=time.monotonic()-start), indent=2) + '\n')
print(unit, 'exit', p.returncode)
raise SystemExit(p.returncode)
