from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[2]
lock_path = root / 'cmake/HyleDependencyLock.json'
text = lock_path.read_text(encoding='utf-8')
lock = json.loads(text)
entry = next(d for d in lock['dependencies'] if d['name'] == 'flashinfer_cache_patches')
vendor = root / entry['vendored']['path']

def digest(path):
    data = path.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
    return hashlib.sha256(data).hexdigest()

manifest = ''.join(f'{p.relative_to(vendor).as_posix()}|{digest(p)}\n'
                   for p in sorted(vendor.rglob('*')) if p.is_file())
notice = next(f for f in entry['license']['files'] if f['path'].endswith('NOTICE.md'))
updates = {
    entry['version']: 'hyle-flashinfer-msvc-portability-v16',
    entry['vendored']['tree_sha256']: hashlib.sha256(manifest.encode()).hexdigest(),
    notice['sha256']: digest(root / notice['path']),
}
for before, after in updates.items():
    assert text.count(before) == 1, before
    text = text.replace(before, after, 1)
lock_path.write_text(text, encoding='utf-8', newline='\n')
print(json.dumps(updates, indent=2))
