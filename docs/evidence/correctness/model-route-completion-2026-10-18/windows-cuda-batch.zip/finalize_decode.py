from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RAW = ROOT / '.scratch/g04-bf16-partials-vendor/upstream'
path = ROOT / 'third_party/flashinfer_cache/patches.json'
manifest = json.loads(path.read_text())
relative = 'include/flashinfer/attention/decode.cuh'
assert all(entry['path'] != relative for entry in manifest['files'])
original = (RAW / relative).read_bytes().replace(b'\r\n', b'\n')
text = original.decode()
edits = []
for context in ['const uint32_t seq_len = params.kv_len;',
                'const uint32_t padded_batch_size = params.padded_batch_size;']:
    before = context + '\n\n  constexpr uint32_t vec_size = std::max(16UL / sizeof(DTypeKV), HEAD_DIM / 32UL);'
    after = before.replace('std::max(16UL / sizeof(DTypeKV), HEAD_DIM / 32UL)',
                           'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM / 32)')
    assert text.count(before) == 1
    text = text.replace(before, after)
    edits.append(dict(before=before, after=after))
for before, after in [
    ('std::max(16UL / sizeof(DTypeKV), HEAD_DIM_CKV / 32UL)',
     'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM_CKV / 32)'),
    ('extern __attribute__((shared)) uint8_t smem[];',
     'extern __shared__ uint8_t smem[];'),
]:
    assert text.count(before) == 1
    text = text.replace(before, after)
    edits.append(dict(before=before, after=after))
assert text == (OUT / 'decode.portable.cuh').read_text()
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest['files'].append(dict(path=relative, before_sha256=sha(original),
                              after_sha256=sha(text.encode()), edits=edits))
manifest['scope'] += '; decode host launch templates use the same LLP64-neutral max types and CUDA shared spelling'
path.write_text(json.dumps(manifest, indent=2) + '\n', newline='\n')
notice = ROOT / 'third_party/flashinfer_cache/NOTICE.md'
text = notice.read_text().replace('and makes four scheduler max expressions',
                                'and makes seven scheduler/decode max expressions')
text = text.replace('are removed from an unused host-only rotary launch wrapper because nvcc',
                    'are removed from an unused host-only rotary launch wrapper because nvcc')
text += ('The decode header also uses CUDA __shared__ instead of a GNU shared\n'
         'attribute for the same dynamic shared-memory declaration.\n')
notice.write_text(text, newline='\n')
print('current manifest decode portability finalized', sha(path.read_bytes()))
