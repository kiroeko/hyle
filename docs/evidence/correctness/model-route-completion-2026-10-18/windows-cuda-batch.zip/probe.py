from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = ROOT / '.scratch/build-compute-v2-dev'
SOURCE = ROOT / '.scratch/g04-bf16-product-c6-vendor/materialized-canonical'
TOOLKIT = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache

cache = read_cache(BASE)
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
env['PATH'] = str(TOOLKIT / 'bin/x64') + os.pathsep + env['PATH']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest_file = OUT / 'patches.before.json'
if not manifest_file.exists():
    manifest_file = ROOT / 'third_party/flashinfer_cache/patches.json'
manifest = json.loads(manifest_file.read_text())
headers = []
for entry in manifest['files']:
    path = SOURCE / entry['path']
    assert sha(path) == entry['after_sha256'], (path, sha(path), entry['after_sha256'])
    headers.append({'path': str(path), 'sha256': sha(path)})
(OUT / 'source-identities.json').write_text(json.dumps({
    'revision': manifest['upstream_revision'], 'headers': headers,
    'manifest_sha256': sha(ROOT / 'third_party/flashinfer_cache/patches.json'),
    'compiler': cache['CMAKE_CXX_COMPILER'], 'sdk_copy_or_download': False,
}, indent=2) + '\n')
nvcc = TOOLKIT / 'bin/nvcc.exe'
tag = sys.argv[1] if len(sys.argv) > 1 else 'native-batch'
translation_unit = ROOT / 'src/compute_provider_flashinfer' / (sys.argv[2] if len(sys.argv) > 2 else 'native_batch.cu')
if tag.startswith('headers'):
    translation_unit = OUT / 'host_headers.cu'
    translation_unit.write_text('#include <flashinfer/pos_enc.cuh>\nint hyle_headers_probe() { return 0; }\n', newline='\n')
cmd = [str(nvcc), '--std=c++17', '--gpu-architecture=sm_89',
       '--compiler-bindir', str(Path(cache['CMAKE_CXX_COMPILER']).parent),
       '-Xcompiler=/MD,/EHsc,/Zc:preprocessor,/utf-8', '-O2', '-DNDEBUG', '-DNOMINMAX',
       '-DFLASHINFER_ENABLE_BF16', '-DFLASHINFER_ENABLE_F16',
       '-I' + str(SOURCE / 'include'),
       '-c', str(translation_unit),
       '-o', str(OUT / (tag + '.obj'))]
if 'portable' in tag:
    text = (SOURCE / 'include/flashinfer/vec_dtypes.cuh').read_text()
    before = '#define FLASHINFER_INLINE inline __attribute__((always_inline)) __device__'
    assert text.count(before) == 1
    header = OUT / 'vec_dtypes.portable.cuh'
    header.write_text(text.replace(before, '#define FLASHINFER_INLINE __forceinline__ __device__'), newline='\n')
    cmd += ['--pre-include', str(header)]
if 'llp64' in tag:
    text = (SOURCE / 'include/flashinfer/math.cuh').read_text()
    assert text.count('ushort y_u16;') == 2
    header = OUT / 'math.portable.cuh'
    header.write_text(text.replace('ushort y_u16;', 'unsigned short y_u16;'), newline='\n')
    cmd += ['--pre-include', str(header)]
    if 'posenc' in tag:
        text = (SOURCE / 'include/flashinfer/pos_enc.cuh').read_text()
        before = ('cudaError_t BatchQKApplyLlama31Rotary(\n'
                  '    DType* q, DType* k, DType* q_rope, DType* k_rope, IdType* __restrict__ indptr,\n'
                  '    IdType* __restrict__ offsets, uint32_t batch_size')
        after = before.replace('IdType* __restrict__', 'IdType*')
        assert text.count(before) == 1
        header = OUT / 'pos_enc.portable.cuh'
        header.write_text(text.replace(before, after), newline='\n')
        cmd += ['-I' + str(SOURCE / 'include/flashinfer'), '--pre-include', str(header)]
    text = (SOURCE / 'include/flashinfer/attention/scheduler.cuh').read_text()
    for before, after in [
        ('std::max(16UL / sizeof(DTypeKV), HEAD_DIM / 32UL)',
         'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM / 32)'),
        ('std::max(16UL / sizeof(DTypeKV), HEAD_DIM_CKV / 32UL)',
         'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM_CKV / 32)'),
        ('std::max(ceil_div(total_kv_lens * num_kv_heads, num_clusters), 1L)',
         'std::max<int64_t>(ceil_div(total_kv_lens * num_kv_heads, num_clusters), 1)'),
        ('std::max(ceil_div(total_kv_lens, num_clusters), 1L)',
         'std::max<int64_t>(ceil_div(total_kv_lens, num_clusters), 1)'),
    ]:
        assert text.count(before) == 1
        text = text.replace(before, after)
    header = OUT / 'scheduler.portable.cuh'
    header.write_text(text, newline='\n')
    cmd += ['-I' + str(SOURCE / 'include/flashinfer/attention'), '--pre-include', str(header)]
if 'keyword' in tag:
    cmd += ['-Xcompiler=/Drestrict=__restrict']
if 'decode' in tag:
    text = (SOURCE / 'include/flashinfer/attention/decode.cuh').read_text()
    before = 'std::max(16UL / sizeof(DTypeKV), HEAD_DIM / 32UL)'
    assert text.count(before) == 2
    text = text.replace(before, 'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM / 32)')
    before = 'std::max(16UL / sizeof(DTypeKV), HEAD_DIM_CKV / 32UL)'
    assert text.count(before) == 1
    text = text.replace(before, 'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM_CKV / 32)')
    before = 'extern __attribute__((shared)) uint8_t smem[];'
    assert text.count(before) == 1
    text = text.replace(before, 'extern __shared__ uint8_t smem[];')
    header = OUT / 'decode.portable.cuh'
    header.write_text(text, newline='\n')
    cmd += ['--pre-include', str(header)]
if 'hostsyntax' in tag:
    cmd[cmd.index('-c')] = '--cuda'
    cmd[cmd.index('-o') + 1] = str(OUT / (tag + '.cpp'))
start = time.monotonic()
p = subprocess.run(cmd, cwd=OUT, env=env, capture_output=True)
(OUT / (tag + '.stdout.log')).write_bytes(p.stdout)
(OUT / (tag + '.stderr.log')).write_bytes(p.stderr)
(OUT / (tag + '-command.json')).write_text(json.dumps({
    'command': cmd, 'cwd': str(OUT), 'exit': p.returncode,
    'seconds': time.monotonic() - start,
}, indent=2) + '\n')
print('native-batch compile exit', p.returncode, flush=True)
if p.returncode:
    for line in (p.stdout + p.stderr).decode(errors='replace').splitlines():
        if 'error' in line.lower() and 'warning' not in line.lower():
            print(line[:900])
sys.exit(p.returncode)
