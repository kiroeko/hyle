from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
RAW = ROOT / '.scratch/g04-bf16-partials-vendor/upstream'
SOURCE = ROOT / '.scratch/g04-bf16-product-c6-vendor/materialized-canonical'
path = ROOT / 'third_party/flashinfer_cache/patches.json'
before = path.read_bytes()
manifest = json.loads(before)
assert len(manifest['files']) == 3
(OUT / 'patches.before.json').write_bytes(before)
sha = lambda b: hashlib.sha256(b).hexdigest()
records = []

def add(relative, edits):
    current = (SOURCE / relative).read_bytes().replace(b'\r\n', b'\n')
    initial = current
    for old, new in edits:
        assert current.count(old.encode()) == 1, (relative, old)
        current = current.replace(old.encode(), new.encode(), 1)
    previous = next((item for item in manifest['files'] if item['path'] == relative), None)
    if previous is None:
        original = (RAW / relative).read_bytes().replace(b'\r\n', b'\n')
        assert original == initial
        previous = {'path': relative, 'before_sha256': sha(original),
                    'after_sha256': sha(current), 'edits': []}
        manifest['files'].append(previous)
    else:
        assert sha(initial) == previous['after_sha256']
    previous['edits'].extend({'before': old, 'after': new} for old, new in edits)
    previous['after_sha256'] = sha(current)
    records.append({'path': relative, 'before': sha(initial), 'after': sha(current),
                    'new_edits': len(edits)})

add('include/flashinfer/vec_dtypes.cuh', [(
    '#define FLASHINFER_INLINE inline __attribute__((always_inline)) __device__',
    '#if defined(_MSC_VER)\n#define FLASHINFER_INLINE __forceinline__ __device__\n#else\n'
    '#define FLASHINFER_INLINE inline __attribute__((always_inline)) __device__\n#endif')])
add('include/flashinfer/math.cuh', [(
    '  ushort y_u16;\n  asm volatile("ex2.approx.f16',
    '  unsigned short y_u16;\n  asm volatile("ex2.approx.f16'), (
    '  ushort y_u16;\n  asm volatile("tanh.approx.f16',
    '  unsigned short y_u16;\n  asm volatile("tanh.approx.f16')])
add('include/flashinfer/attention/scheduler.cuh', [(
    'std::max(16UL / sizeof(DTypeKV), HEAD_DIM / 32UL)',
    'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM / 32)'), (
    'std::max(16UL / sizeof(DTypeKV), HEAD_DIM_CKV / 32UL)',
    'std::max<size_t>(16 / sizeof(DTypeKV), HEAD_DIM_CKV / 32)'), (
    'std::max(ceil_div(total_kv_lens * num_kv_heads, num_clusters), 1L)',
    'std::max<int64_t>(ceil_div(total_kv_lens * num_kv_heads, num_clusters), 1)'), (
    'std::max(ceil_div(total_kv_lens, num_clusters), 1L)',
    'std::max<int64_t>(ceil_div(total_kv_lens, num_clusters), 1)')])
old = ('cudaError_t BatchQKApplyLlama31Rotary(\n'
       '    DType* q, DType* k, DType* q_rope, DType* k_rope, IdType* __restrict__ indptr,\n'
       '    IdType* __restrict__ offsets, uint32_t batch_size')
add('include/flashinfer/pos_enc.cuh', [(old, old.replace('IdType* __restrict__', 'IdType*'))])
manifest['scope'] += '; MSVC CUDA portability uses native forceinline, explicit 16-bit and LP64/LLP64-neutral max types, and removes two unsupported restrict annotations from an unused host-only rotary launch wrapper; attention device kernels and numerical paths are unchanged'
path.write_text(json.dumps(manifest, indent=2) + '\n', newline='\n')
notice = ROOT / 'third_party/flashinfer_cache/NOTICE.md'
(OUT / 'NOTICE.before.md').write_bytes(notice.read_bytes())
with notice.open('a', encoding='utf-8', newline='\n') as file:
    file.write('\nWindows CUDA uses the same attention and cache kernels. The verified header\n'
               'set additionally selects CUDA forceinline for MSVC, spells two 16-bit\n'
               'temporaries as unsigned short, and makes four scheduler max expressions\n'
               'independent of LP64 versus LLP64 integer aliases. Two restrict annotations\n'
               'are removed from an unused host-only rotary launch wrapper because nvcc\n'
               'emits them as unsupported C99 restrict in MSVC C++. Device kernels,\n'
               'thread/block dispatch, storage layouts and numerical contracts are unchanged.\n')
(OUT / 'portability-changes.json').write_text(json.dumps({
    'manifest_before_sha256': sha(before), 'manifest_after_sha256': sha(path.read_bytes()),
    'changes': records, 'dependency_upgrade': False, 'kernel_algorithm_change': False,
}, indent=2) + '\n')
print(json.dumps(records, indent=2))
