from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = ROOT / '.scratch/build-compute-v2-dev'
TOOLKIT = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache = read_cache(BASE)
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
env['PATH'] = str(TOOLKIT / 'bin/x64') + os.pathsep + str(BASE / 'bin') + os.pathsep + env['PATH']
cl = Path(cache['CMAKE_CXX_COMPILER'])
link = cl.with_name('link.exe')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
flags = ['/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus',
         '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/permissive-', '/bigobj',
         '/DHYLE_STATIC', '/DNOMINMAX', '/DHYLE_COMPUTE_CUDA=1', '/DHYLE_COMPUTE_FLASHINFER=1',
         '/DHYLE_COMPUTE_GGML_CUDA=1', '/DHYLE_COMPUTE_TORCH_CUDA=1']
for relative in ['include', 'src/compute', 'src/compute_backend_cuda', 'src/compute_provider_cuda',
                 'src/compute_provider_flashinfer', 'third_party/sglang_activation',
                 'third_party/deepseek_fp8', 'third_party/deepseek_quantization']:
    flags.append('/I' + str(ROOT / relative))
flags += ['/external:I' + str(TOOLKIT / 'include'), '/external:I' + str(TOOLKIT / 'include/cccl'), '/external:W0']
records = json.loads((OUT / 'host-commands.json').read_text()) if (OUT / 'host-commands.json').exists() else []

def run(tag, command, timeout=180):
    command = list(map(str, command))
    attempt = sum(record['tag'] == tag for record in records)
    if attempt:
        for stream in ['stdout', 'stderr']:
            previous = OUT / (tag + '.' + stream + '.log')
            if previous.exists():
                (OUT / (tag + '.previous-' + str(attempt) + '.' + stream + '.log')).write_bytes(previous.read_bytes())
    start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=timeout)
    (OUT / (tag + '.stdout.log')).write_bytes(p.stdout)
    (OUT / (tag + '.stderr.log')).write_bytes(p.stderr)
    record = {'tag': tag, 'command': command, 'cwd': str(ROOT), 'exit': p.returncode,
              'seconds': time.monotonic() - start}
    records.append(record)
    (OUT / 'host-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(tag, p.returncode, round(record['seconds'], 2), flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-6000:])
        print(p.stderr.decode(errors='replace')[-1500:])
        raise SystemExit(p.returncode)
    return p

def comp(relative, name):
    path = ROOT / relative
    run(name + '-compile', [cl, *flags, path, '/Fo' + str(OUT / (name + '.obj'))])
    return {'source': str(path), 'source_sha256': sha(path), 'object': str(OUT / (name + '.obj')),
            'object_sha256': sha(OUT / (name + '.obj'))}

if __name__ == '__main__':
    action = sys.argv[1]
    identities = []
    if action == 'component':
        identities.append(comp('src/compute_provider_flashinfer/flashinfer_provider.cc', 'flashinfer-provider'))
        identities.append(comp('tests/compute_batch/public_batch_cuda_consumer.cc', 'public-consumer'))
    elif action == 'default':
        directory = ROOT / 'src/compute_provider_cuda'
        # Fresh all host adapters; only their unchanged native device objects are reused.
        for path in sorted(directory.glob('*.cc')):
            identities.append(comp(path.relative_to(ROOT).as_posix(), 'cuda-' + path.stem))
        for relative, name in [
            ('src/compute_provider_cublas/cublas_provider.cc', 'cublas-provider'),
            ('src/compute_route_cuda/cuda_context.cc', 'default-context'),
            ('src/compute_route_cuda/default_policy.cc', 'default-policy'),
            ('src/compute_route_cuda/best_of.cc', 'best-of'),
        ]:
            identities.append(comp(relative, name))
    elif action == 'default-kernels':
        for stem in ['concat_kernel', 'sampling_kernel']:
            source = ROOT / 'src/compute_provider_cuda' / (stem + '.cu')
            output = OUT / (stem + '.current.obj')
            run(stem + '-current-compile', [TOOLKIT / 'bin/nvcc.exe', '--std=c++20',
                '--gpu-architecture=sm_89', '--compiler-bindir', cl.parent,
                '-Xcompiler=/MD,/EHsc,/Zc:preprocessor,/utf-8', '-O2', '-DNDEBUG', '-DNOMINMAX',
                '-DHYLE_STATIC', '-I' + str(ROOT / 'include'),
                '-I' + str(ROOT / 'src/compute_backend_cuda'),
                '-c', source, '-o', output])
            identities.append(dict(source=str(source), source_sha256=sha(source),
                                   object=str(output), object_sha256=sha(output)))
    elif action == 'batch-host':
        for relative, name in [('src/compute_batch/batch_execution.cc', 'batch-execution'),
                               ('src/graph_batch/batch.cc', 'graph-batch')]:
            identities.append(comp(relative, name))
    else:
        raise ValueError(action)
    (OUT / (action + '-identities.json')).write_text(json.dumps(identities, indent=2) + '\n')
