from pathlib import Path
import json,subprocess,time
ROOT=Path(__file__).resolve().parent
CACHE=Path('/Users/kiro/hyle-scratch/compute-unified/mtp-gdn-snapshots-20261018')
records=[]
def run(tag,cmd):
    start=time.monotonic();p=subprocess.run(cmd,cwd=CACHE,capture_output=True,text=True)
    (ROOT/(tag+'.stdout.log')).write_text(p.stdout);(ROOT/(tag+'.stderr.log')).write_text(p.stderr)
    records.append(dict(tag=tag,command=cmd,cwd=str(CACHE),exit=p.returncode,seconds=time.monotonic()-start));(ROOT/'metal-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout[-3500:],p.stderr[-2500:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
command=json.loads((CACHE/'compile-probe.command.json').read_text());command[command.index('-c')+1]=str(ROOT/'kda_metal.mm');command[command.index('-o')+1]=str(ROOT/'kda-metal.o')
run('metal-compile',command)
command=json.loads((CACHE/'link-probe.command.json').read_text());command[command.index('-o')+1]=str(ROOT/'kda-metal');command=[str(ROOT/'kda-metal.o') if x==str(CACHE/'probe.o') else x for x in command]
run('metal-link',command);run('metal-test',[str(ROOT/'kda-metal')])
