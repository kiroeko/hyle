from pathlib import Path
import importlib.util,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
had=module('fusion_had',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cuda=module('fusion_cuda',ROOT/'.scratch/mtp-completion/run.py')
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,cmd,env):
    cmd=list(map(str,cmd));start=time.monotonic()
    result=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=180)
    (OUT/(tag+'.stdout.log')).write_bytes(result.stdout);(OUT/(tag+'.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag,command=cmd,cwd=str(ROOT),exit=result.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    (OUT/(tag+'.json')).write_text(json.dumps(records[-1],indent=2)+'\n')
    print(tag,result.returncode,result.stdout.decode(errors='replace')[-3500:],result.stderr.decode(errors='replace')[-2500:],flush=True)
    if result.returncode:raise SystemExit(result.returncode)
def compile_cpp(tag,source,flags,env):
    target=OUT/(tag+'.obj');run(tag,[had.CL,*flags,source,'/Fo'+str(target)],env);return target
action=sys.argv[1]
if action=='cpu':
    cfg=dict(had.PINS['mixed'],folder=Path('mixed'))
    flags=had.hyle_flags(cfg)+['/I'+str(ROOT)]
    region=compile_cpp('cpu-region',ROOT/'src/graph_route_cpu/ggml_region.cc',flags,had.ENV)
    test=compile_cpp('cpu-test',OUT/'fusion_test.cc',flags,had.ENV)
    cached=ROOT/'.scratch/mtp-gdn-2026-10-18'
    objects=[cached/'ffa4/operation.obj',cached/'mixed/provider.obj',cached/'mixed/selector-baseline.obj',cached/'mixed/allocator.obj',ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj',region,test]
    libs=[had.BASE/'bin/hyle_graph.lib',*had.common_libs(cfg),had.BASE/'lib/gtest.lib',had.BASE/'lib/gtest_main.lib']
    exe=OUT/'cpu-tests.exe'
    run('cpu-link',[had.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(exe.with_suffix('.map')),*objects,*libs,*had.SYSTEM],had.ENV)
    run('cpu-tests',[exe],had.ENV)
elif action=='cuda':
    flags=cuda.flags+['/I'+str(ROOT),'/DFUSION_TEST_CUDA=1']
    region=compile_cpp('cuda-region',ROOT/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',flags,cuda.env)
    test=compile_cpp('cuda-test',OUT/'fusion_test.cc',flags,cuda.env)
    cached=ROOT/'.scratch/mtp-completion'
    objects=[cached/(name+'.obj') for name in ['operation','provider','tensor']]+[region,test]
    exe=OUT/'cuda-tests.exe'
    run('cuda-link',[cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(exe.with_suffix('.map')),*objects,cuda.OLD/'ggml-cuda.strict.obj',*cuda.libs,had.BASE/'lib/gtest.lib',had.BASE/'lib/gtest_main.lib',*cuda.system],cuda.env)
    run('cuda-tests',[exe],cuda.env)
elif action=='canonical':
    cfg=dict(had.PINS['mixed'],folder=Path('mixed'))
    compile_cpp('canonical-cpu-test',ROOT/'tests/graph_route_cpu/graph_test.cc',had.hyle_flags(cfg)+['/I'+str(ROOT)],had.ENV)
    compile_cpp('canonical-cuda-test',ROOT/'tests/graph_provider_ggml_cuda/region_test.cc',cuda.flags+['/I'+str(ROOT)],cuda.env)
else:raise SystemExit(action)
