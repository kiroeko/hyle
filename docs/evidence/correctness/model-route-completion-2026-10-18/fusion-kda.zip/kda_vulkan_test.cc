#include <gtest/gtest.h>
#include "tests/compute_models/gdn_snapshot_fixture.h"
#include "tests/compute_route_vulkan/tensor_test_support.h"

TEST(KdaPrefix, VulkanKeepsFullChannelDecayStateOnDevice) {
  namespace c=hyle::compute;namespace v=c::vulkan;
  const gdn_snapshot_fixture::Fixture fixture(7,1,5,2,6,128,true);
  auto context=v::Context::create().value();
  std::array<v::Tensor,6> inputs;
  std::vector<v::Argument> arguments;
  for(std::size_t port=0;port<6;++port){
    inputs[port]=context.upload(fixture.inputs[port],std::as_bytes(std::span(fixture.data[port]))).value();
    arguments.emplace_back(fixture.inputs[port]);
  }
  auto program=v::prepare(context,c::Operation(c::GatedDeltaNet{.snapshot_count=3}),arguments).value();
  auto invocation=program.create_invocation().value();
  ASSERT_TRUE(invocation.bind(inputs).ok());
  auto submitted=invocation.submit().value();
  auto completed=submitted.wait();ASSERT_TRUE(completed)<<completed.error().message();
  const auto outputs=completed->get()->tensors();
  auto expected=fixture.oracle(3);
  const auto check=[&](const v::Tensor &tensor,std::span<const double> reference){
    std::vector<float> actual(reference.size());
    const auto status=context.download(tensor,std::as_writable_bytes(std::span(actual)));
    EXPECT_TRUE(status.ok())<<status.message();double maximum=0;
    for(std::size_t i=0;i<actual.size();++i){EXPECT_TRUE(std::isfinite(actual[i]));maximum=std::max(maximum,std::abs(double(actual[i])-reference[i]));}
    std::printf("KDA Vulkan compared=%zu max_abs=%.12g\n",actual.size(),maximum);
    EXPECT_LT(maximum,3e-6);
  };
  check(outputs[0],expected[0]);check(outputs[1],expected[1]);
  std::array<v::Tensor,6> next;
  for(std::size_t port=0;port<5;++port){
    auto selected=inputs[port].view(c::View::slice(1,4,1).value());
    ASSERT_TRUE(selected)<<port<<':'<<selected.error().message();
    auto token=std::move(*selected);
    // Native GDN requires descriptor-aligned ports; the generic native Copy
    // materializes the small token view without reading its payload on host.
    auto copied=vulkan_tensor_test::execute(context,c::Operation(c::Copy{}),std::span(&token,1));
    ASSERT_TRUE(copied)<<copied.error().message();next[port]=std::move(*copied);
  }
  const std::array flat_shape{std::int64_t{3},
      static_cast<std::int64_t>(fixture.inputs[5].element_count().value())};
  auto flat=outputs[1].view(c::View::reshape(c::TensorShape::create(flat_shape).value()).value()).value();
  auto selected=flat.view(c::View::slice(0,1,1).value());
  ASSERT_TRUE(selected)<<selected.error().message();auto middle=std::move(*selected);
  auto selected_state=middle.view(c::View::reshape(c::TensorShape::create(fixture.inputs[5].dimensions()).value()).value());
  ASSERT_TRUE(selected_state)<<selected_state.error().message();next[5]=std::move(*selected_state);
  arguments.clear();for(const auto &input:next)arguments.emplace_back(input.description());
  auto prepared=v::prepare(context,c::Operation(c::GatedDeltaNet{}),arguments);
  ASSERT_TRUE(prepared)<<prepared.error().message();auto continuation=std::move(*prepared);
  auto slot=continuation.create_invocation().value();const auto bound=slot.bind(next);ASSERT_TRUE(bound.ok())<<bound.message();
  auto submitted_next=slot.submit();ASSERT_TRUE(submitted_next)<<submitted_next.error().message();auto work=std::move(*submitted_next);auto result=work.wait();ASSERT_TRUE(result)<<result.error().message();
  const auto final=result->get()->tensors();expected=fixture.oracle(1);
  check(final[0],std::span(expected[0]).last(final[0].description().element_count().value()));
  check(final[1],expected[1]);
}
