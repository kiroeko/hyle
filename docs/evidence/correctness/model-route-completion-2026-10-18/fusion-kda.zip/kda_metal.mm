#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include "src/compute_provider_ggml_metal/native_program.h"
#include "tests/compute_models/gdn_snapshot_fixture.h"
namespace c=hyle::compute;namespace n=c::ggml_metal;
struct Buffers{std::vector<id<MTLBuffer>> values;~Buffers(){for(auto b:values)[b release];}};
int main(){@autoreleasepool{
  id<MTLDevice> device=MTLCreateSystemDefaultDevice();if(!device)return 2;
  const gdn_snapshot_fixture::Fixture fixture(7,1,5,2,6,128,true);
  Buffers buffers;
  auto first=n::NativeProgram::create(c::Operation(c::GatedDeltaNet{.snapshot_count=3}),fixture.inputs);
  if(!first){std::fprintf(stderr,"create: %.*s\n",int(first.error().message().size()),first.error().message().data());return 3;}
  std::vector<n::BufferView> ports;
  for(std::size_t port=0;port<6;++port){
    auto b=[device newBufferWithLength:fixture.inputs[port].required_bytes().value() options:MTLResourceStorageModeShared];
    if(!b)return 4;buffers.values.push_back(b);std::memcpy([b contents],fixture.data[port].data(),fixture.data[port].size()*sizeof(float));ports.push_back({(__bridge void*)b,0});
  }
  auto history=[device newBufferWithLength:(*first)->output_bytes() options:MTLResourceStorageModeShared];
  if(!history)return 4;buffers.values.push_back(history);ports.push_back({(__bridge void*)history,0});
  auto status=(*first)->run(ports);if(!status.ok())return 5;
  const auto check=[](const n::NativeProgram &program,id<MTLBuffer> buffer,const std::array<std::vector<double>,2>&expected,bool last_token){
    bool okay=true;
    for(std::size_t port=0;port<2;++port){
      const auto count=program.output_description(port).element_count().value();
      const auto *actual=reinterpret_cast<const float*>(static_cast<const std::byte*>([buffer contents])+program.output_offset(port));
      const auto offset=last_token&&port==0?expected[0].size()-count:0;
      double maximum=0;for(std::size_t i=0;i<count;++i){if(!std::isfinite(actual[i]))okay=false;maximum=std::max(maximum,std::abs(double(actual[i])-expected[port][offset+i]));}
      std::printf("KDA Metal continued=%d port=%zu compared=%zu max_abs=%.12g\n",last_token,port,count,maximum);okay=okay&&maximum<3e-6;
    }return okay;
  };
  if(!check(**first,history,fixture.oracle(3),false))return 6;
  std::array<c::TensorDesc,6> descriptions=fixture.inputs;
  std::vector<n::BufferView> continued(ports.begin(),ports.begin()+6);
  for(std::size_t port=0;port<5;++port){
    const auto shape=fixture.inputs[port].dimensions();const std::array token_shape{shape[0],std::int64_t{1},shape[2],shape[3]};
    descriptions[port]=c::TensorDesc::dense(c::DataType::kFloat32,token_shape).value();continued[port].offset=4*descriptions[port].required_bytes().value();
  }
  continued[5]={(__bridge void*)history,(*first)->output_offset(1)+fixture.inputs[5].required_bytes().value()};
  auto next=n::NativeProgram::create(c::Operation(c::GatedDeltaNet{}),descriptions);if(!next)return 7;
  auto output=[device newBufferWithLength:(*next)->output_bytes() options:MTLResourceStorageModeShared];if(!output)return 4;buffers.values.push_back(output);continued.push_back({(__bridge void*)output,0});
  status=(*next)->run(continued);if(!status.ok())return 8;
  const bool okay=check(**next,output,fixture.oracle(1),true);[device release];return okay?0:9;
}}
