#include <gtest/gtest.h>
#include "tests/compute_models/gdn_region_test.h"
#if defined(FUSION_TEST_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/providers/ggml_cuda.h"
TEST(FusionClosure, CudaGdnRegionAndKdaAcceptedPrefix) {
  namespace c=hyle::compute;namespace g=hyle::graph;
  auto context=c::Context::create(c::cuda::device(0).value(),g::ggml_cuda::provider()).value();
  auto memory=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice).value();
  gdn_region_test::exercise(context,memory.ref(),[&](const g::Graph &logical){
    const std::array storage{g::StorageDomain{.resource=memory.ref()}};
    const std::array targets{g::ExecutionTarget{.context=&context,.default_storage=g::StorageDomainId{0}}};
    const std::array lanes{g::ExecutionLane{.target=g::ExecutionTargetId{0}}};
    return g::compile(logical,{.storage_domains=storage,.targets=targets,.lanes=lanes});
  });
}
#else
#include "hyle/compute/backends/cpu.h"
#include "src/graph_route_cpu/ggml_region.h"
TEST(FusionClosure, CpuGdnRegionAndKdaAcceptedPrefix) {
  namespace c=hyle::compute;namespace g=hyle::graph;
  const std::array providers{c::ProviderBinding{g::cpu::internal::ggml_regions({}),100},c::ProviderBinding{c::ggml_cpu::provider(),900}};
  auto context=c::Context::create(c::cpu::device(),{.providers=providers}).value();
  gdn_region_test::exercise(context,hyle::mem::system_resource(),[&](const g::Graph &logical){return g::compile(logical,context);});
}
#endif
