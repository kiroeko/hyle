from pathlib import Path
import json,os,subprocess,sys,time,importlib.util
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fusion_had',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py');had=importlib.util.module_from_spec(spec);spec.loader.exec_module(had)
env=dict(had.ENV,DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~')
cached=json.loads((ROOT/'.scratch/mtp-gdn-2026-10-18/vulkan/commands.json').read_text());records=[]
def run(tag,cmd):
    cmd=list(map(str,cmd));start=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=180)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=cmd,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start));(OUT/'vulkan-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-2500:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
source=ROOT/'.scratch/inference-feature-completion-2026-10-18/fusion/kda_vulkan_test.cc';obj=OUT/'kda-vulkan.obj'
command=list(next(x['command'] for x in cached if x['label']=='compile-compute_route_vulkan-recurrent_test'))
command[command.index('/c')+1]=str(source);command=[('/Fo'+str(obj)) if x.startswith('/Fo') else x for x in command];command+=['/I'+str(ROOT)]
run('vulkan-compile',command)
command=list(next(x['command'] for x in cached if x['label']=='link'));command=[x for x in command if not x.endswith('compute_route_vulkan-recurrent_test.obj')]
exe=OUT/'kda-vulkan.exe';command=[('/OUT:'+str(exe)) if x.startswith('/OUT:') else ('/MAP:'+str(exe.with_suffix('.map'))) if x.startswith('/MAP:') else x for x in command];command.append(str(obj))
run('vulkan-link',command);run('vulkan-test',[exe])
