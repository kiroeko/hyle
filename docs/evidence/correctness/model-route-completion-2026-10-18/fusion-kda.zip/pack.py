from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
owned=['src/graph_route_cpu/ggml_region.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
       'tests/compute_models/gdn_snapshot_fixture.h','tests/compute_models/gdn_region_test.h',
       'tests/graph_route_cpu/graph_test.cc','tests/graph_provider_ggml_cuda/region_test.cc']
def identity(path):
    path=Path(path);return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
patch=subprocess.check_output(['git','diff','--',*owned],cwd=ROOT).decode()
new='tests/compute_models/gdn_region_test.h'
patch+='diff --git a/'+new+' b/'+new+'\nnew file mode 100644\n'
patch+=''.join(difflib.unified_diff([], (ROOT/new).read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+new))
(OUT/'product.diff').write_text(patch)
paths=set()
for name in ['commands.json','vulkan-commands.json']:
    for row in json.loads((OUT/name).read_text()):
        for value in row['command']:
            path=Path(value)
            if path.is_file() and path.suffix.lower() in ['.lib','.obj'] and OUT not in path.parents:paths.add(path)
cached=ROOT/'.scratch/mtp-gdn-2026-10-18'
paths.update([cached/'ffa4/operation.obj',*[cached/'mixed'/(n+'.obj') for n in ['provider','selector-baseline','allocator']],ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj'])
base=ROOT/'.scratch/build-compute-v2-dev'
paths.update(base/'bin'/(n+'.lib') for n in ['hyle_graph','hyle_compute_backend_cpu','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_container','hyle_mem','mimalloc_static','hyle_platform','hyle_error','hyle_platform_thread','hyle_time','hyle_simd','hyle_compute_provider_ggml','hyle_compute_ggml_runtime'])
paths.update(ROOT/'.scratch/build-cpu-final-mixed-probe/ggml/src'/(n+'.lib') for n in ['ggml','ggml-base','ggml-cpu'])
identity_data=dict(sources=[identity(ROOT/p) for p in owned],dependencies=[identity(p) for p in sorted(paths)],
  windows_gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True).strip(),
  compiler='MSVC 14.50.35717 / CUDA toolkit 13.3; exact paths and options in commands/scripts',
  reused_cpu_manifest=str(cached/'source-identities.json'),reused_cuda_manifest=str(ROOT/'.scratch/mtp-completion/identities.json'),
  native_rebuilt=False,full_sdk_rebuilt=False)
(OUT/'identities.json').write_text(json.dumps(identity_data,indent=2)+'\n')
summary=dict(
  change='CPU/CUDA ggml region adapters now carry every node output through capability checks, boundary alignment and native Recipe IDs. No named-op whitelist, numeric kernel or default route preference change.',
  cpu_cuda_runtime=dict(exit=0,mode='Small gtest component closure executing the exact helper used by canonical regressions; fresh region/test host TUs with existing native/provider/foundation cache.',
    cases=['B2/T5/Hk2/Hv6/D32 scalar decay K3','B1/T5/Hk2/Hv6/D128 per-channel decay K3','B1/T3/H16/D128 raw RecurrentGatedDeltaNet K3'],
    assertions='One region / one step / three nodes; both raw outputs published and independently consumed by Neg; two replays; independent FP64 oracle at 3e-6. KDA additionally accepts snapshot after token4 and really continues token5 using actual device state.'),
  canonical_tu_compile=dict(exit=0,files=owned[-2:],full_canonical_test_binaries_run=False),
  vulkan=dict(exit=0,mode='Ordinary public Vulkan route with existing current host/native cache, fresh one-test TU; no product edit.',max_absolute_error=4.83731443617e-9),
  metal=dict(exit=0,mode='NativeProgram small probe; one fresh ObjC++ probe TU with cached current host/native objects; no product edit.',max_absolute_error=5.46260910811e-9),
  common_kda='B1/T5/Hk2/Hv6/D128 per-channel decay, K3 full matrix snapshots, select middle retained state and compute token5; no host payload supplies continuation. Vulkan token alignment uses ordinary device Copy; snapshot selection uses reshape/slice/reshape metadata.',
  static_fusion_scan=['CPU/CUDA multi-output adapter rejection fixed; native GDN and raw recurrent already support both outputs.',
    'CPU ggml region_operation and native supports retain separate semantic qualification; generic GatedActivation stable-tail and unsupported modes keep ordinary leaf implementations.',
    'CUDA attention intentionally remains its already-complete native Compute program outside tensor-region batching; no new inference function is inferred missing from that boundary.',
    'Apple fixed_ggml_model_operation and compile_regions use current model_ops custom_as descriptors, support multiple schema outputs and retain mature native/MLX regions.',
    'Vulkan ordinary Graph/node output vectors already carry qualified recurrent two-output schemas; region admission already has 6/8 input counts and current snapshot_count. No additional arity/new-ID miswiring identified.',
    'No named model fusion op added. GLM/DeepSeek multi-query sparse causality was separately reviewed by root. This work does not claim 8 complete model / 22 profile runtime validation.'],
  limitations='Component cache validation, not full SDK rebuild, complete model inference or throughput evidence. Reused CUDA validation tensor object explicitly declines three unrelated IQ1 codecs because its legacy native cache lacks them; product codec admission was not changed here.',
  reproduce=['python .scratch/inference-feature-completion-2026-10-18/fusion/run.py cpu','python .scratch/inference-feature-completion-2026-10-18/fusion/run.py cuda','python .scratch/inference-feature-completion-2026-10-18/fusion/run.py canonical','python .scratch/inference-feature-completion-2026-10-18/fusion/run_vulkan.py','python3 /Users/kiro/hyle-scratch/compute-unified/mtp-gdn-snapshots-20261018/fusion/run_metal.py'])
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(OUT/'source-results.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in OUT.iterdir():
        if path.is_file() and path.suffix in ['.py','.cc','.mm','.log','.json','.diff']:archive.write(path,path.name)
    for name in owned:archive.write(ROOT/name,'sources/'+name)
print(json.dumps(identity(OUT/'source-results.zip'),indent=2))
