#include <hyle/compute/batch_execution.h>
#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/providers/flashinfer.h>
#include <array>
#include <cstdint>
#include <cstdio>

namespace c = hyle::compute;
hyle::Status run() {
  HYLE_ASSIGN_OR_RETURN(auto device, c::cuda::device(0));
  HYLE_ASSIGN_OR_RETURN(auto context, c::Context::create(device, c::flashinfer::provider()));
  HYLE_ASSIGN_OR_RETURN(auto gpu, c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto host, c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
  for (unsigned depth : {64u, 128u, 256u, 512u}) {
    const unsigned heads = unsigned(INT32_MAX) / depth + 1;
    const c::BatchCapacity capacity{
        .storage = c::BatchStorage::kRagged,
        .max_requests = 1, .max_query_rows = 1, .max_kv_rows = 1,
        .max_pages = 0, .max_page_refs = 0,
        .query_heads = heads, .kv_heads = heads / 2,
        .qk_head_dim = depth, .value_head_dim = depth, .page_size = 1};
    HYLE_ASSIGN_OR_RETURN(auto schema, c::BatchSchema::create(capacity));
    auto program = c::BatchProgram::prepare(context, schema, {
        .resource = gpu.ref(), .host_workspace = host.ref(),
        .max_float_workspace_bytes = 1u << 20,
        .max_int_workspace_bytes = 64u << 10, .scale = .0625F});
    if (program || !program.error().IsOutOfRange())
      return hyle::Status::Internal("FlashInfer int32 stride overflow was not rejected");
    std::printf("D%u QH%u queryStride=%llu public prepare OutOfRange PASS (no payload allocated)\n",
                depth, heads, static_cast<unsigned long long>(heads) * depth);
  }
  for (bool query : {true, false}) {
    const c::BatchCapacity capacity{
        .storage = c::BatchStorage::kRagged,
        .max_requests = 1,
        .max_query_rows = query ? UINT32_MAX / (64u * 512u) + 1 : 1,
        .max_kv_rows = query ? 1 : UINT32_MAX / 512u + 1,
        .max_pages = 0, .max_page_refs = 0,
        .query_heads = 64, .kv_heads = 1,
        .qk_head_dim = 512, .value_head_dim = 512, .page_size = 1};
    HYLE_ASSIGN_OR_RETURN(auto schema, c::BatchSchema::create(capacity));
    auto program = c::BatchProgram::prepare(context, schema, {
        .resource = gpu.ref(), .host_workspace = host.ref(),
        .max_float_workspace_bytes = 1u << 20,
        .max_int_workspace_bytes = 64u << 10, .scale = .0625F});
    if (program || !program.error().IsOutOfRange())
      return hyle::Status::Internal("FlashInfer uint32 tensor offset overflow was not rejected");
    std::printf("D512 %s extent public prepare OutOfRange PASS (no payload allocated)\n",
                query ? "query" : "ragged KV");
  }
  return context.drain();
}
int main() {
  const auto status = run();
  if (status.ok()) return 0;
  char text[512]{};
  status.ToString(text, sizeof(text));
  std::fprintf(stderr, "%s\n", text);
  return 1;
}
