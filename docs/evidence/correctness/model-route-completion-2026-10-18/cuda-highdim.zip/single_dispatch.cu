#include <cuda_fp16.h>
#include <flashinfer/attention/default_prefill_params.cuh>
#include <flashinfer/attention/prefill.cuh>
#include <flashinfer/attention/variants.cuh>

using Params = flashinfer::BatchPrefillPagedParams<half, half, half, int>;
cudaError_t hyle_single_highdim_dispatch(Params params, half *temporary,
                                       float *scores, cudaStream_t stream) {
  using Variant = flashinfer::DefaultAttention<false, true, false, false>;
  return flashinfer::BatchPrefillWithPagedKVCacheDispatched<
      32, 512, 512, flashinfer::PosEncodingMode::kNone, false,
      flashinfer::MaskMode::kCausal, Variant>(params, temporary, scores, false, stream);
}
