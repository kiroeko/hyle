from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
PARENT = OUT.parent
ROOT = OUT.parents[3]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = ['src/compute_provider_flashinfer/native_highdim.cu',
         'src/compute_provider_flashinfer/native_batch.h',
         'src/compute_provider_flashinfer/flashinfer_provider.cc',
         'src/compute_provider_flashinfer/CMakeLists.txt',
         'tests/compute_batch/public_batch_cuda_consumer.cc']
identities = []
for relative in paths:
    source, destination = ROOT / relative, OUT / 'frozen' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    identities.append(dict(path=relative, bytes=source.stat().st_size, sha256=sha(source)))
(OUT / 'canonical-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
old_header = (PARENT / 'frozen/src/compute_provider_flashinfer/native_batch.h').read_text()
new_header = (ROOT / 'src/compute_provider_flashinfer/native_batch.h').read_text()
assert new_header.replace('cudaError_t run_highdim_batch(const void *,BatchSpec,const void *,const void *,const void *,const void *,void *,void *,void *,cudaStream_t);\n', '') == old_header
diff = subprocess.check_output(['git', 'diff', '--', *paths], cwd=ROOT)
newfile = subprocess.run(['git', 'diff', '--no-index', '--', 'NUL', paths[0]],
                         cwd=ROOT, capture_output=True)
assert newfile.returncode in [0, 1]
(OUT / 'product.diff').write_bytes(diff + newfile.stdout)
logs = OUT / 'logs'
logs.mkdir(exist_ok=True)
for source in PARENT.glob('highdim-*.log'):
    shutil.copyfile(source, logs / source.name)
commands = [entry for entry in json.loads((PARENT / 'host-commands.json').read_text())
            if entry['tag'].startswith('highdim-')]
(OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
stdout = (logs / 'highdim-public-default-batch-run.stdout.log').read_text()
errors = [float(value) for value in re.findall(r'maxError=([0-9.e+-]+)', stdout)]
assert len(errors) == 32 and max(errors) < .007
assert stdout.count('D512 CTA16 Direct/Graph') == 4
assert stdout.count('D512 CTA32 Direct/Graph') == 4
assert 'H64/KV1 D512 PASS' in stdout
bounds = (logs / 'highdim-bounds-run.stdout.log').read_text()
assert bounds.count('OutOfRange PASS') == 6
summary = dict(
    result='PASS native plain D512 batch binding on Windows SM89',
    prior_windows_port_archive=dict(path=str(PARENT / 'source-results.zip'),
        bytes=2556720, sha256='ede71433ca1a6d5199f9eebf15de18bb1554b15ab1b9144146ba7594a1b33d2f'),
    hardware=dict(os='Windows x64', gpu='RTX 4070', sm='8.9', driver='617.14',
                  cuda='13.3', msvc='14.50.35717', shared_block_optin_bytes=101376),
    binding=dict(native_entry='Existing BatchPrefillWithPagedKVCacheDispatched/BatchPrefillWithRaggedKVCacheDispatched<16 or 32,512,512>',
        planner='Existing PrefillPlanInfo, PrefillPlanWorkspaceSize, PrefillPlan, unchanged old native_batch.obj',
        new_native_tu='src/compute_provider_flashinfer/native_highdim.cu',
        same_type_plain_ports=['F16', 'BF16'], qk_depth=512, value_depth=512,
        groups='Runtime positive integral GQA subject to actual native field/extent bounds; no legacy power-of-two head whitelist in this new domain',
        scale='Positive finite scale; zero/negative explicitly declined for new D512 domain',
        metadata_and_lifetime='Same native NHD/page IDs/tails, current Batch Queue, workspace and accepted-prefix owner rules',
        masks='Native causal/full and existing causal window fields bound; no explicit mask or learned sink port'),
    actual_numerical_run=dict(exit=0, seconds=.98,
        default_context='Ordinary CUDA create_context + native BatchProgram::prepare H64/KV1 D512 PASS',
        new_cases='paged/ragged x F16/BF16 x H4/KV2 CTA16/H64/KV1 CTA32',
        new_direct_graph_cases=8, new_complete_fp64_oracles=16,
        original_d256_cases_rechecked=8, original_complete_fp64_oracles=16,
        unchanged_absolute_budget=.007, all_max_errors=errors, max_error=max(errors),
        scale='1/sqrt(512) for D512 fixture; model geometry coverage, not an entire GLM model run',
        features='Nonuniform Q/K/V, causal bottom-right, active capacity, page permutations/tails, output-retention rejection',
        ordinary_default_graph_runtime=False),
    final_guards=dict(
        measured_applied='Numerical kernel/provider run predates only the added rejecting stride/extent guards. Native kernel and positive measured path unchanged. Final host source separately recompiled and checked by public negative prepares.',
        shared_query_stride='All FlashInfer batch domains require QH*Dq<=INT32_MAX because PagedParams.q_stride_n is IdType=int32; global BatchSchema not tightened',
        highdim_query_span='maxQ*QH*512<=UINT32_MAX because Q offset products are uint32',
        highdim_ragged_span='maxKV*KVH*512<=UINT32_MAX; paged physical page offsets use size_t, so not incorrectly tightened to this ragged limit',
        packed_rounding='Highdim query-span bound gives packedQ<=UINT32_MAX/(KVH*512)<=8388607. qstride bound gives group<=4194303. Even CTA31 plus group-1 ceil rounding remains far below UINT32_MAX. Host main planner packed lengths/ceil use int64.',
        negative_public_prepares='D64/128/256/512 queryStride=2147483648, plus D512 uint32 query/ragged-KV span overflow: six OutOfRange PASS without allocating payload',
        final_host_seconds=1.03, final_bounds_seconds=.81),
    compilation=dict(single_native_specialization_seconds=10.36,
        full_new_native_tu_seconds=57.05, new_native_object_bytes=7361496,
        old_four_flashinfer_native_tus_recompiled=False, sdk_copy_or_download=False),
    source_review=dict(
        independent_review='matched_http2_source_review checked plan binding, split v/s/merge offsets, window and scale, Queue ownership; no blocker',
        smem_probe='Only host sizeof and CUDA device-property query, no attention kernel launched',
        smem_512_512_cta16_32=[84512, 68128], smem_576_512_cta16_32=[160272, 109072],
        smem_576_not_fit_sm89=True,
        dedicated_mla_header_failure='Initial host probe failed on three dependent .template method calls lacking <> in mla.cuh887/926/967; retained, no vendor patch applied',
        ggml_alternative='Has dense 512/576 flash but no native CUDA page-index interface and Turing+ F16 PV accumulator; not adopted as strict F32 native paged substitute'),
    boundaries=[
        '576->512 independent Q/K/V native batch remains unsupported on SM89; explicit MLA cache API draft is design only',
        'No claim that no-sink D512 batch implements DeepSeek per-query visibility/learned sinks',
        'Runtime tested causal positive-scale plain D512 only. Full/window and split-KV code compiled and source-reviewed, not separately runtime exercised here',
        'No FP8 highdim, F32 caller ports, extra GPU architecture, graph capture, performance or installed-consumer run',
        'Unrelated nativeCuda/Torch/ggml cached closure boundaries are inherited from prior Windows port archive; no stubs used',
    ],
    operations_after_bounds='packaging only; no further native compile or numerical rerun',
)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
owned_generated = [p for p in OUT.iterdir() if p.is_file() and p.suffix in ['.exe', '.obj', '.lib', '.exp']]
owned_generated += [PARENT / (name + '.obj') for name in [
    'highdim-provider', 'highdim-consumer', 'highdim-provider-final', 'highdim-bounds']]
owned_generated = sorted(set(owned_generated), key=lambda p:str(p))
retain = [p for p in owned_generated if p.name in ['native_highdim.obj', 'highdim-provider-final.obj']]
delete = [p for p in owned_generated if p not in retain]
record = lambda p: dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=sha(p))
(OUT / 'cleanup-candidates.json').write_text(json.dumps(dict(
    roots=[str(OUT), str(PARENT)], delete_candidates=[record(p) for p in delete],
    retain_suggested=[record(p) for p in retain],
    delete_count=len(delete), delete_logical_bytes=sum(p.stat().st_size for p in delete),
    retain_count=len(retain), retain_logical_bytes=sum(p.stat().st_size for p in retain),
    preserve='All prior four FlashInfer objects, shared SDK/foundation, all source/log/data/maps/archive. No deletion performed.',
), indent=2) + '\n')
zip_path = OUT / 'source-results.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(OUT.rglob('*'), key=lambda p:p.as_posix()):
        if not path.is_file() or '__pycache__' in path.parts or path == zip_path or path.name == 'archive-identity.json':
            continue
        if path.suffix in ['.py', '.cu', '.cc', '.h', '.json', '.diff', '.log', '.map', '.txt']:
            archive.write(path, path.relative_to(OUT).as_posix())
identity = dict(path=str(zip_path), bytes=zip_path.stat().st_size, sha256=sha(zip_path),
                summary_sha256=sha(OUT / 'summary.json'),
                cleanup_sha256=sha(OUT / 'cleanup-candidates.json'))
(OUT / 'archive-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity, indent=2))
