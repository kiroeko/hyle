from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import build_host as b

OUT = Path(__file__).resolve().parent
action = sys.argv[1]
recipe = json.loads((OUT.parent / 'native_cache_encoder.cu.current.command.json').read_text())['command']
command = recipe[:recipe.index('-c')]
source = (OUT / 'single_dispatch.cu' if action == 'single'
          else b.ROOT / 'src/compute_provider_flashinfer/native_highdim.cu')
obj = OUT / ('single_dispatch.obj' if action == 'single' else 'native_highdim.obj')
command += ['-c', str(source), '-o', str(obj)]
b.run('highdim-' + action + '-compile', command, timeout=900)
(OUT / (action + '-identity.json')).write_text(json.dumps(dict(
    source=str(source), source_sha256=b.sha(source), object=str(obj),
    object_sha256=b.sha(obj), command=command,
), indent=2) + '\n')
