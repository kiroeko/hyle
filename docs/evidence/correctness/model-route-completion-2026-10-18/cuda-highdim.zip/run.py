from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import build_host as b

OUT = Path(__file__).resolve().parent
old = json.loads((OUT.parent / 'native_cache_encoder.cu.current.command.json').read_text())['command']
command = old[:old.index('-c')]
command += ['--cudart', 'shared', str(OUT / 'smem_probe.cu'), '-o', str(OUT / 'smem_probe.exe')]
b.run('highdim-smem-header-compile', command)
b.run('highdim-smem-header-run', [OUT / 'smem_probe.exe'])
