from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import build_host as b
import link_run as previous

OUT = Path(__file__).resolve().parent
action = sys.argv[1]
if action == 'host':
    entries = [b.comp('src/compute_provider_flashinfer/flashinfer_provider.cc', 'highdim-provider'),
               b.comp('tests/compute_batch/public_batch_cuda_consumer.cc', 'highdim-consumer')]
    (OUT / 'host-identities.json').write_text(json.dumps(entries, indent=2) + '\n')
elif action == 'link':
    objects = [b.OUT / 'highdim-consumer.obj' if path == b.OUT / 'public-consumer.obj'
               else b.OUT / 'highdim-provider.obj' if path == b.OUT / 'flashinfer-provider.obj'
               else path for path in previous.objects]
    objects.append(OUT / 'native_highdim.obj')
    executable = OUT / 'public-highdim-batch.exe'
    command = [b.link, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
               '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(executable),
               '/MAP:' + str(OUT / 'public-highdim-batch.map'),
               *objects, *previous.libs, *previous.system]
    b.run('highdim-default-batch-link', command)
    (OUT / 'link-identities.json').write_text(json.dumps([dict(
        path=str(path), bytes=path.stat().st_size, sha256=b.sha(path),
    ) for path in [*objects, *previous.libs, executable]], indent=2) + '\n')
elif action == 'run':
    b.run('highdim-public-default-batch-run', [OUT / 'public-highdim-batch.exe'])
elif action == 'bounds':
    records = [b.comp('src/compute_provider_flashinfer/flashinfer_provider.cc', 'highdim-provider-final'),
               b.comp((OUT / 'bounds.cc').relative_to(b.ROOT), 'highdim-bounds')]
    objects = [b.OUT / 'highdim-bounds.obj' if path == b.OUT / 'public-consumer.obj'
               else b.OUT / 'highdim-provider-final.obj' if path == b.OUT / 'flashinfer-provider.obj'
               else path for path in previous.objects]
    objects.append(OUT / 'native_highdim.obj')
    executable = OUT / 'bounds.exe'
    b.run('highdim-bounds-link', [b.link, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE',
          '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(executable),
          '/MAP:' + str(OUT / 'bounds.map'), *objects, *previous.libs, *previous.system])
    b.run('highdim-bounds-run', [executable])
    (OUT / 'bounds-identities.json').write_text(json.dumps(records, indent=2) + '\n')
else:
    raise ValueError(action)
