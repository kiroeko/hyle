#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <flashinfer/attention/prefill.cuh>
#include <cstdio>

namespace fi = flashinfer;
template <unsigned QK, unsigned VO, unsigned Tile> void ordinary() {
  constexpr unsigned WQ = Tile == 32 ? 2 : 1;
  constexpr unsigned WKV = Tile == 32 ? 2 : 4;
  using Variant = fi::DefaultAttention<false, false, false, false>;
  using Traits = fi::KernelTraits<fi::MaskMode::kCausal, Tile, 1, 1, QK / 16, VO / 16,
      WQ, WKV, fi::PosEncodingMode::kNone, half, half, half, float, int, Variant>;
  std::printf("ordinary QK=%u VO=%u CTA=%u KVRows=%u sharedPaged=%zu sharedPlain=%zu invalid=%d kvShared=%d\n",
      QK, VO, Tile, Traits::CTA_TILE_KV, sizeof(typename Traits::SharedStoragePaged),
      sizeof(typename Traits::SharedStorage), int(Traits::IsInvalid()),
      int(Traits::USE_KV_SHARED_SMEM));
}
int main() {
  cudaDeviceProp prop{};
  const auto status = cudaGetDeviceProperties(&prop, 0);
  if (status != cudaSuccess) {
    std::fprintf(stderr, "%s\n", cudaGetErrorString(status));
    return 1;
  }
  std::printf("device=%s sm=%d.%d sharedSM=%zu sharedBlockOptin=%zu\n", prop.name,
              prop.major, prop.minor, prop.sharedMemPerMultiprocessor, prop.sharedMemPerBlockOptin);
  ordinary<512, 512, 16>();
  ordinary<512, 512, 32>();
  ordinary<576, 512, 16>();
  ordinary<576, 512, 32>();
  return 0;
}
