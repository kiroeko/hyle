from pathlib import Path
import importlib.util,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cached_cuda',ROOT/'.scratch/mtp-completion/run.py');cuda=importlib.util.module_from_spec(spec);spec.loader.exec_module(cuda)
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,cmd):
 cmd=list(map(str,cmd));t=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=cuda.env,capture_output=True,timeout=180)
 (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-4800:],p.stderr.decode(errors='replace')[-2000:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
source=ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc';data=source.read_text()
for codec in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
 assert data.count('return GGML_TYPE_'+codec+';')==1
 data=data.replace('return GGML_TYPE_'+codec+';','return GGML_TYPE_COUNT; // Validation only: legacy native lacks this unrelated IQ1 codec.')
probe=OUT/'tensor_program.probe.cc';probe.write_text(data)
flags=cuda.flags+['/I'+str(ROOT)]
if '--reuse-tensor' not in sys.argv:
 run('tensor-compile',[cuda.cl,*flags,probe,'/Fo'+str(OUT/'tensor.obj')])
run('test-compile-2',[cuda.cl,*flags,OUT/'tests.cc','/Fo'+str(OUT/'tests.obj')])
objects=[ROOT/'.scratch/mtp-completion/operation.obj',ROOT/'.scratch/mtp-completion/provider.obj',OUT/'tensor.obj',ROOT/'.scratch/inference-feature-completion-2026-10-18/fusion/cuda-region.obj',OUT/'tests.obj',cuda.OLD/'ggml-cuda.strict.obj']
exe=OUT/'tests.exe'
run('test-link',[cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/'tests.map'),*objects,*cuda.libs,cuda.BASE/'lib/gtest_main.lib',cuda.BASE/'lib/gtest.lib',*cuda.system])
run('tests',[exe,'--gtest_filter=GgmlCudaTensor.BatchedF32MatMulRebindsIndependentSlotsWithoutNarrowing:BatchedF32Graph.*','--gtest_color=no'])
