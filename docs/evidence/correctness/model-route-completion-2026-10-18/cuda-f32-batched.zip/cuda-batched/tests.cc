#include "tests/compute_provider_ggml_cuda/tensor_test.cc"
#include "hyle/graph/providers/ggml_cuda.h"
#include "hyle/graph/graph.h"
#include "hyle/graph/executable.h"

TEST(BatchedF32Graph, MatMulAndNegativeShareRegionAndKeepPublishedResults) {
  namespace c=hyle::compute;namespace g=hyle::graph;
  constexpr std::int64_t m=17,k=37,n=19;
  const auto a_desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array{2LL,m,k}).value();
  const auto b_desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array{1LL,k,n}).value();
  const auto o_desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array{2LL,m,n}).value();
  auto builder=g::GraphBuilder::create().value();auto a=builder.input(a_desc).value(),b=builder.input(b_desc).value();
  auto y=builder.add(c::MatMul{},a,b).value();auto z=builder.add(c::Unary{c::UnaryKind::kNeg},y).value();
  ASSERT_TRUE(builder.publish(y).ok());ASSERT_TRUE(builder.publish(z).ok());
  auto ctx=c::Context::create(c::cuda::device(0).value(),g::ggml_cuda::provider()).value();
  auto memory=c::cuda::MemoryResource::create(ctx,c::cuda::MemoryKind::kDevice).value();
  const std::array domains{g::StorageDomain{.resource=memory.ref()}};
  const std::array targets{g::ExecutionTarget{.context=&ctx,.default_storage=g::StorageDomainId{0}}};
  const std::array lanes{g::ExecutionLane{.target=g::ExecutionTargetId{0}}};
  auto compiled=g::compile(std::move(builder).finish().value(),{.storage_domains=domains,.targets=targets,.lanes=lanes});
  ASSERT_TRUE(compiled)<<compiled.error().message();ASSERT_EQ(compiled->report.step_count(),1U);
  EXPECT_EQ(compiled->report.step(0)->provider.id,c::ggml_cuda::kProviderId);
  auto queue=ctx.create_queue().value();const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&queue}};
  hyle::mem::Buffer old;std::vector<float> old_values;
  for(int phase:{0,1}) {
    std::vector<float> av(2*m*k),bv(k*n);
    for(std::size_t i=0;i<av.size();++i)av[i]=float(0.15+double(i%19)*0.037+phase*0.013);
    for(std::size_t i=0;i<bv.size();++i)bv[i]=float(0.11+double(i%23)*0.029-phase*0.007);
    auto ab=ggml_cuda_tensor_test::upload<float>(memory.ref(),av),bb=ggml_cuda_tensor_test::upload<float>(memory.ref(),bv);
    auto yb=ggml_cuda_tensor_test::output_buffer(memory.ref(),o_desc),zb=ggml_cuda_tensor_test::output_buffer(memory.ref(),o_desc);
    auto invocation=compiled->executable.create_invocation().value();
    ASSERT_TRUE(invocation.bind(a,c::ConstTensorView::create(a_desc,ab.view()).value()).ok());
    ASSERT_TRUE(invocation.bind(b,c::ConstTensorView::create(b_desc,bb.view()).value()).ok());
    ASSERT_TRUE(invocation.bind(y,c::TensorView::create(o_desc,yb.view()).value()).ok());
    ASSERT_TRUE(invocation.bind(z,c::TensorView::create(o_desc,zb.view()).value()).ok());
    ASSERT_TRUE(invocation.prepare_replay(queues).ok());auto done=invocation.submit(queue);ASSERT_TRUE(done)<<done.error().message();ASSERT_TRUE(done->wait().ok());
    const auto actual=half_test::read<float>(yb),negative=half_test::read<float>(zb);
    for(std::size_t batch=0;batch<2;++batch)for(std::size_t r=0;r<m;++r)for(std::size_t col=0;col<n;++col){
      double expected=0;for(std::size_t inner=0;inner<k;++inner)expected+=double(av[(batch*m+r)*k+inner])*bv[inner*n+col];
      const auto i=(batch*m+r)*n+col;EXPECT_NEAR(actual[i],expected,2e-6+6e-6*std::abs(expected));EXPECT_NEAR(negative[i],-expected,2e-6+6e-6*std::abs(expected));
    }
    if(!phase){old_values=actual;old=std::move(yb);}else EXPECT_EQ(half_test::read<float>(old),old_values);
  }
}
