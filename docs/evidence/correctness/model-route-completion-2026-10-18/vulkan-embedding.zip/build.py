from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
CACHE=ROOT/'.scratch/bench-api-runtime/vulkan/build';FOUNDATION=ROOT/'.scratch/build-compute-v2-dev'
old=json.loads((ROOT/'.scratch/perf-review-2026-10-18/concat-cpu-vulkan/commands.json').read_text())
cmd=next(x['command'] for x in old if x['label']=='vulkan-candidate-compile')
cl=Path(cmd[0]);link=cl.with_name('link.exe');flags=cmd[1:-2]
flags=[x for x in flags if not x.startswith('/DHYLE_GGML_CPU')]
flags += ['/DHYLE_COMPUTE_VULKAN=1','/I'+str(ROOT/'src/compute_route_vulkan'),'/W4','/WX','/wd4324']
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':str(cl),'CMAKE_C_COMPILER':str(cl)})
env['PATH']=str(FOUNDATION/'bin')+os.pathsep+env['PATH']
env['DISABLE_VULKAN_OBS_CAPTURE']='1';env['VK_LOADER_LAYERS_DISABLE']='~all~'
records=[]
def run(label,cmd):
 cmd=list(map(str,cmd));start=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (OUT/(label+'.stdout.txt')).write_bytes(p.stdout);(OUT/(label+'.stderr.txt')).write_bytes(p.stderr)
 records.append({'label':label,'command':cmd,'cwd':str(ROOT),'exit_code':p.returncode,'seconds':time.monotonic()-start});(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,p.returncode,p.stdout.decode(errors='replace')[-2800:],p.stderr.decode(errors='replace')[-1500:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run('region-compile',[cl,*flags,ROOT/'src/compute_provider_ggml_vulkan/region.cc','/Fo'+str(OUT/'region.obj')])
run('test-compile',[cl,*flags,ROOT/'tests/compute_route_vulkan/gguf_test.cc','/Fo'+str(OUT/'gguf-test.obj')])
line=next(l for l in (CACHE/'build.ninja').read_text().splitlines() if l.startswith('  LINK_LIBRARIES = ') and 'hyle_compute_route_vulkan.lib' in l)
libs=[]
for token in shlex.split(line.split(' = ',1)[1],posix=False):
 token=token.strip('"');p=Path(token)
 if p.suffix=='.lib' and len(p.parts)>1:
  if p.stem.startswith('g01_'):continue
  actual=p if p.is_absolute() else CACHE/p
  current=FOUNDATION/'bin'/p.name
  # Current F1/F2 foundations, cached Vulkan route and native closure.
  if p.stem not in ['hyle_compute_route_vulkan','hyle_compute_provider_iree_vulkan','hyle_compute_provider_ggml_vulkan','hyle_compute_ggml_runtime','ggml','ggml-base','ggml-vulkan','iree_runtime_unified','flatcc_parsing'] and current.exists():actual=current
  libs.append(str(actual))
 else:libs.append(token)
libs += [str(FOUNDATION/'lib/gtest.lib'),str(FOUNDATION/'lib/gtest_main.lib')]
run('test-link',[link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/'gguf-tests.exe'),OUT/'region.obj',OUT/'gguf-test.obj',*libs])
run('embedding-test',[OUT/'gguf-tests.exe','--gtest_filter=VulkanGguf.TargetEmbeddingFormatsUseNativeRowsAndCheckedPublication','--gtest_color=no'])
