"""Offline evidence only; invoke after all four recorded cases pass parsing."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-mixed-lag-2026-10-29'
spec = importlib.util.spec_from_file_location('mixed_lag_package_recorder', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
CASES = {'mixed-cpu': 'cpu', 'mixed-cuda': 'cuda', 'ragged-cuda': 'cuda', 'chunked-cpu': 'cpu'}
SOURCES = ('engine/models/qwen35/main.cc', 'engine/models/qwen35/execution_mode.h', 'engine/models/qwen35/mtp_graph.h',
    'tests/tools/qwen_chunked_prefill_case.h', 'tests/tools/qwen_packed_prefill_case.h', 'tests/tools/qwen_ragged_prefill_case.h',
    'tests/tools/qwen_mtp_chunked_prefill_case.h', 'tests/tools/qwen_mtp_packed_prefill_case.h',
    'tests/tools/qwen_mtp_ragged_prefill_case.h', 'tests/tools/qwen_mtp_mixed_lag_case.h', 'tests/tools/qwen_host_image_test.cc')


def encode(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
def sha(body): return hashlib.sha256(body).hexdigest()
def terminal(row): assert row['state'] == 'TERMINAL' and row['exit'] == 0 and row['timed_out'] is False, row


def main():
    outjson, outzip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not outjson.exists() and not outzip.exists(), 'Preserve prior evidence'
    plan, frozen, compiled, ready = map(t.read, (W / 'plan.json', W / 'source-freeze.json',
                                               W / 'compile/tiny/compiled.json', W / 'ready-tiny.json'))
    cxx, link = t.read(W / 'logs/compile-tiny/process.json'), t.read(W / 'logs/link-tiny/process.json')
    terminal(cxx); terminal(link)
    assert compiled['process'] == cxx and ready['compiled'] == compiled and ready['process'] == link
    assert t.read(W / 'logs/compile-tiny/command.json')['command'] == plan['compile']
    assert t.read(W / 'logs/link-tiny/command.json')['command'] == plan['link']
    assert ready['inputs'] == plan['retained'] + [compiled['object']] and len(ready['inputs']) == 228
    assert len(plan['retained']) == 227 and len({t.key(row['path']) for row in ready['inputs']}) == 228
    t.exact(ready['source_freeze']); t.exact(plan['fixture']); t.exact(plan['prompt'])
    pins = {t.key(row['path']): row for row in frozen}
    deps = {t.key(row['path']): row for row in compiled['project_dependencies']}
    sources = [pins[t.key(R / relative)] for relative in SOURCES]
    archive, cases, events = {}, [], []
    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert name not in archive and 'environment' not in path.name.casefold()
        assert path.suffix.lower() not in ('.exe', '.obj', '.dll', '.lib', '.pdb', '.bin', '.bf16', '.f32', '.safetensors', '.gguf')
        archive[name] = path.read_bytes()
    for relative in ('package.py', 'run.py', 'plan.json', 'source-freeze.json', 'compile/tiny/compiled.json',
                     'compile/tiny/dependencies.json', 'ready-tiny.json'): add(W / relative)
    for row in sources:
        t.exact(row)
        if t.key(row['path']) in deps: assert deps[t.key(row['path'])] == row
        add(row['path'], 'source/' + Path(row['path']).relative_to(R).as_posix())
    for name, backend in CASES.items():
        directory = W / 'runs' / name; process = t.read(directory / 'process.json'); terminal(process)
        report = t.read(directory / 'report.json')
        raw = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert raw == [report] and report['status'] == 'PASS' and report['backend'] == backend
        assert report['performance_claim'] is False and report['final_versions'] == 0
        if name.startswith('mixed-'): assert (report['target_submissions'], report['mixed_target_submissions']) == (13, 2)
        facts = {k: v for k, v in report.items() if not isinstance(v, (dict, list))}
        if isinstance(report.get('state_checks'), list): facts['state_check_records'] = len(report['state_checks'])
        cases.append(dict(name=name, process=process, facts=facts, report=t.pin(directory / 'report.json')))
    assert len({(row['process']['pid'], row['process']['started']) for row in cases}) == 4
    # Keep all existing logs in these bounded directories, including failures.
    names = {'command.json', 'process.json', 'running.json', 'stdout.log', 'stderr.log', 'report.json', 'summary.json'}
    for folder in ('logs', 'runs'):
        for path in sorted((W / folder).rglob('*')):
            if path.is_file() and path.name in names:
                add(path)
                if path.name == 'process.json': events.append(dict(record=str(path.relative_to(W)), process=t.read(path)))
    for name, row in (('weights.tsv', plan['fixture']), ('prompt.ids', plan['prompt'])): add(row['path'], 'fixture/' + name)
    archive['fixture/identity.json'] = encode(dict(manifest=plan['fixture'], prompt=plan['prompt'], payloads_included=False))
    manifest = encode([dict(name=name, bytes=len(body), sha256=sha(body)) for name, body in sorted(archive.items())])
    archive['MANIFEST.json'] = manifest
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, body in sorted(archive.items()): z.writestr(name, body)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, body in archive.items(): assert sha(z.read(name)) == sha(body), name
    failures = [row for row in events if row['process']['state'] != 'TERMINAL' or row['process']['exit'] != 0 or row['process']['timed_out']]
    result = dict(schema='hyle.correctness.mixed-lag.v1', date='2026-10-29', status='PASS_FOUR_FINITE_CASES',
        change='Compact mixed-lag B2 K1 draft uses three actual rows in a four-row physical carrier; target remains two rows per member.',
        counts=dict(successful_CXX=1, successful_links=1, successful_finite_processes=len(cases), SDK_CXX=0, NVCC=0, downloads=0),
        build=dict(compile_process=cxx, link_process=link, source=compiled['source'], image=ready['image'],
                   inherited_inputs=227, source_freeze=t.pin(W / 'source-freeze.json')),
        sources=sources, snapshot_only_sources=[row['path'] for row in sources if t.key(row['path']) not in deps],
        cases=cases, recorded_processes=events, prior_failed_or_incomplete_processes=failures,
        limits=['CPU/CUDA synthetic GA C16 finite dispatch only: mixed generation plus ragged/chunked regressions.',
                'The frozen run.py parsers retain original per-case state checks and GDN 3e-6 budget; complete reports are in the archive.',
                'No complete RequestLoop regrouping/history-import, quality, performance, cross-platform or device D2 claim.',
                'SDK/weights are inherited; only actual dependency metadata and the eleven explicit source files are archived.'],
        archive=dict(**t.pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', member_SHA256='PASS'))
    with outjson.open('xb') as out: out.write(encode(result))
    receipt = dict(JSON=t.pin(outjson), ZIP=t.pin(outzip), members=len(archive), CRC='PASS', member_SHA256='PASS')
    t.save(W / 'package-readback.json', receipt); print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
