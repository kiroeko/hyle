from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('mlx_orientation_test_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def main():
    out = S/'tests/checks'/sys.argv[1]
    out.mkdir(parents=True, exist_ok=True)
    rows = [
        ('schema-test', 'tests/compute_ops/operation_test.cc',
         'grouped-fp8-power2-reference/cpu/checks/attempt1/affected0-identity.json'),
        ('cpu-mlx-neighbor', 'tests/compute_route_cpu/cpu_mlx_quantized_test.cc',
         'mlx-moe-typed-inputs/checks/cpu-test-identity.json')
    ]

    def build(row):
        tag, name, recipe_name = row
        source = ROOT/name
        recipe = A/recipe_name
        old = c.read(recipe)
        assert c.key(old['source']['path']) == c.key(source)
        job = out/tag
        job.mkdir(exist_ok=True)
        (job/'tmp').mkdir(exist_ok=True)
        assert not (job/'compile.result.json').exists()
        template = [arg for arg in old['command'] if arg not in ('/W3', '/W0')]
        for flag in ('/W4', '/WX'):
            if flag not in template:
                template.append(flag)
        command = b.host_command(template, source, tag, job)
        source_before = b.identity(source)
        c.save(job/'plan.json', dict(source=source_before, command=command,
            recipe=b.identity(recipe), old_object=old['object'], SDK_builds=0, GPU_runs=0))
        env, _ = b.environment(command, [], job)
        c.execute('compile', command, env, job)
        deps = job/(tag+'-deps.json')
        data = c.read(deps)['Data']
        assert b.same(source_before)
        record = dict(source=source_before, object=b.identity(job/(tag+'.obj')),
            command=command, recipe=b.identity(recipe), old_object=old['object'],
            source_dependencies=b.identity(deps),
            dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])])
        c.save(job/'identity.json', record)
        return dict(tag=tag, identity=b.identity(job/'identity.json'), object=record['object'],
            replaces=old['object'])

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(build, rows))
    c.save(out/'summary.json', dict(CXX=2, links=0, GPU_runs=0, SDK_builds=0, owners=results))
    print(out/'summary.json')


if __name__ == '__main__':
    main()
