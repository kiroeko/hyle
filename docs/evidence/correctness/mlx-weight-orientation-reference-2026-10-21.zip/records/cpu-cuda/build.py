from pathlib import Path
import concurrent.futures
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('mlx_orientation_build_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
spec = importlib.util.spec_from_file_location('mlx_orientation_native_command', A/'ct-packed-grouped-space/cpu-cuda/build.py')
n = importlib.util.module_from_spec(spec)
spec.loader.exec_module(n)
BASES = {arm: A/'precise-role-consumers-2026-10-21'/arm/'checks/link1/link-plan.json'
         for arm in ('cpu', 'cuda')}


def native_dependencies(path):
    text = path.read_text('utf-8').replace('\\\n', ' ')
    text = text.split(' : ', 1)[1]
    paths = [Path(part.replace('\\ ', ' ')) for part in re.split(r'(?<!\\)\s+', text.strip())]
    paths = list(dict.fromkeys(paths))
    assert paths and all(p.is_file() for p in paths), [str(p) for p in paths if not p.is_file()]
    return paths


def main():
    out = S/'checks'/sys.argv[1]
    out.mkdir(parents=True, exist_ok=True)
    plans = {arm: c.read(path) for arm, path in BASES.items()}
    metadata = h.metadata(plans)
    jobs = [
        ('cpu', 'src/compute_provider_native/torch_cpu_program.cc', 'torch-cpu'),
        ('cuda', 'src/compute_provider_torch_cuda/artifact_provider.cc', 'artifact-provider'),
        ('cuda', 'src/compute_route_cuda/default_policy.cc', 'default-policy'),
        ('cuda', 'src/compute_provider_torch_cuda/mlx_packed_kernel.cu', 'mlx-packed-kernel')
    ]
    if len(sys.argv) > 2:
        jobs = [row for row in jobs if row[2] == sys.argv[2]]
    assert jobs

    def build(row):
        arm, name, tag = row
        source = ROOT/name
        matches = [(item, metadata.get(c.key(item['path']))) for item in plans[arm]['inputs']
                   if c.key(metadata.get(c.key(item['path']), {}).get('source_path', '')) == c.key(source)]
        assert len(matches) == 1, (name, len(matches))
        old, recipe = matches[0]
        job = out/tag
        job.mkdir(exist_ok=True)
        (job/'tmp').mkdir(exist_ok=True)
        assert not (job/'compile.result.json').exists(), 'Preserve previous attempt'
        native = source.suffix == '.cu'
        template = list(recipe['command'])
        if not native:
            template = [arg for arg in template if arg not in ('/W3', '/W0')]
            for arg in ('/W4', '/WX'):
                if arg not in template:
                    template.append(arg)
        command = (n.native_command if native else b.host_command)(template, source, tag, job)
        if native:
            # Match the existing strict host warning exceptions. NVCC's
            # generated DecodeOnly host stub sees the old constexpr return.
            command.append('-Xcompiler=/W4,/WX,/wd4324,/wd4702')
        source_before = b.identity(source)
        c.save(job/'plan.json', dict(command=command, source=source_before,
            old_object=old, recipe=b.identity(recipe['recipe']), base=b.identity(BASES[arm]),
            compile_only=True, GPU_runs=0, SDK_builds=0))
        environment_command = command
        if native:
            compiler = Path(command[command.index('-ccbin')+1])/'cl.exe'
            assert compiler.is_file()
            environment_command = [str(compiler), *command[1:]]
        env, _ = b.environment(environment_command, [], job)
        c.execute('compile', command, env, job)
        if native:
            deps = job/(tag+'.d')
            paths = native_dependencies(deps)
        else:
            deps = job/(tag+'-deps.json')
            data = c.read(deps)['Data']
            paths = list(dict.fromkeys([data['Source'], *data['Includes']]))
        assert b.same(source_before)
        identity = dict(source=source_before, object=b.identity(job/(tag+'.obj')),
            old_object=old, command=command, recipe=b.identity(recipe['recipe']),
            source_dependencies=b.identity(deps), dependencies=[b.identity(path) for path in paths],
            native=native, GPU_runs=0)
        c.save(job/'identity.json', identity)
        return dict(tag=tag, identity=b.identity(job/'identity.json'), object=identity['object'],
            old_object=old)

    successes, failures = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = {pool.submit(build, row): row for row in jobs}
        for future in concurrent.futures.as_completed(futures):
            try:
                record = future.result()
                successes.append(record)
                print(json.dumps(record), flush=True)
            except Exception as error:
                failures.append(dict(job=futures[future], error=str(error)))
                print(str(error), flush=True)
    c.save(out/'summary.json', dict(successes=successes, failures=failures,
        CXX_attempts=sum(not row[1].endswith('.cu') for row in jobs),
        NVCC_attempts=sum(row[1].endswith('.cu') for row in jobs), links=0, GPU_runs=0, SDK_builds=0))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
