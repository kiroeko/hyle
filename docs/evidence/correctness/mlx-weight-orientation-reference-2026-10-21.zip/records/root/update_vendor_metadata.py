from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def digest(data):return hashlib.sha256(data).hexdigest()
def normalized(path):return digest(path.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n'))
def tree(path):
 files=sorted(p for p in path.rglob('*') if p.is_file())
 assert all(not p.is_symlink() for p in files)
 return digest(''.join(p.relative_to(path).as_posix()+'|'+normalized(p)+'\n' for p in files).encode())
before=P/'root/vendor-before';before.mkdir(exist_ok=True)
paths=['cmake/HyleDependencyLock.json','third_party/mlx_cpu_quant/SOURCE.json','third_party/mlx_cpu_quant/NOTICE.md']
for s in paths:
 target=before/s.replace('/','--');assert not target.exists();target.write_bytes((R/s).read_bytes())
source=R/paths[1];d=read(source)
d['adaptation']['matrix_orientation']='Affine A*W^T retains the original K-group branch. Explicit A*W keeps physical W[N,K] and K groups, decodes only selected Ntile<=64 x Kgroup tiles, then accumulates F32 products before the declared final cast. N is not required to divide a quantization group. No full NK/ENK floating bank.'
save(source,d)
notice=R/paths[2]
notice.write_text(notice.read_text()+'\nExplicit affine A*W keeps the original physical K bitstream and scale groups.\nThe adapter bounds decoding to an N tile of at most64 rows and one K group\nof selected heads/experts, then uses F32 ATen matmul and accumulation. N may\nhave a tail. It does not physically transpose or expand a full float bank.\n',encoding='utf-8')
lockpath=R/paths[0];lock=read(lockpath)
for entry in lock['dependencies']:
 if entry['name'] not in ('mlx_cpu_quant','iree_vulkan_runtime_patches'):continue
 folder=R/entry['vendored']['path'];entry['vendored']['tree_sha256']=tree(folder)
 for item in entry['license']['files']:
  if item['root']=='hyle':item['sha256']=normalized(R/item['path'])
save(lockpath,lock)
rows=[dict(path=s,bytes=(R/s).stat().st_size,sha256=digest((R/s).read_bytes())) for s in paths]
save(P/'root/vendor-metadata.json',dict(sources=rows,entries=[e for e in lock['dependencies'] if e['name'] in ('mlx_cpu_quant','iree_vulkan_runtime_patches')]))
print({e['name']:e['vendored']['tree_sha256'] for e in lock['dependencies'] if e['name'] in ('mlx_cpu_quant','iree_vulkan_runtime_patches')})
