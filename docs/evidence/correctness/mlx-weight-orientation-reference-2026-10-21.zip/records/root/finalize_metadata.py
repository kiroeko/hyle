from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def digest(b):return hashlib.sha256(b).hexdigest()
def normalized(p):return digest(p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n'))
def tree(folder):
 files=sorted(p for p in folder.rglob('*') if p.is_file());assert all(not p.is_symlink() for p in files)
 return digest(''.join(p.relative_to(folder).as_posix()+'|'+normalized(p)+'\n' for p in files).encode())
path=R/'cmake/HyleDependencyLock.json';d=read(path)
entries=[x for x in d['dependencies'] if x['name'] in ('mlx_cpu_quant','iree_vulkan_runtime_patches')]
for entry in entries:
 entry['vendored']['tree_sha256']=tree(R/entry['vendored']['path'])
 for item in entry['license']['files']:
  if item['root']=='hyle':item['sha256']=normalized(R/item['path'])
assert next(x for x in entries if x['name']=='iree_vulkan_runtime_patches')['vendored']['tree_sha256']==read(P/'vulkan/entry-hashes.json')['tree_sha256']
save(path,d);save(P/'root/vendor-metadata-final.json',dict(entries=entries,lock=dict(path=str(path),bytes=path.stat().st_size,sha256=digest(path.read_bytes()))))
path=R/'docs/implementation/model-quantizations.json';d=read(path)
follow=next(x for x in d['followup_reviews'] if x['evidence']=='docs/evidence/correctness/mlx-weight-orientation-reference-2026-10-21.json')
assert follow['partial_backend_snapshot']
follow['partial_backend_snapshot']=False
follow['scope']=follow['scope'].replace('CPU/CUDA/Apple','CPU/CUDA/Vulkan/Apple')
follow['backend_validation']['Vulkan']=dict(status='passed',cases=3,skipped=0,scope='Three new ordinary consumers; original typed-output contamination failure, actual raw attribution and equivalent explicit-zero group fix retained')
follow.update(distinct_cases=26,new_cases=13,neighbor_cases=13,new_Graph_successful_submissions=140,new_Graph_expected_failed_completions=8)
previous=next(x for x in d['followup_reviews'] if x['evidence']=='docs/evidence/correctness/precise-role-consumers-reference-2026-10-21.json')
previous['scope']=previous['scope'].replace('Catalog31 non-transposed packed-W prefill remains an explicit interface gap.','That earlier batch identified catalog31 non-transposed packed-W prefill as an interface gap; the later weight-orientation follow-up records its repair.')
assert len(d['artifacts'])==33 and all(x['provider_coverage']['artifact_execution_verified'] is False for x in d['artifacts'])
save(path,d)
print('Updated final Vulkan dependency identity and 26 passing cases; all33 artifact execution flags remain false.')
