from pathlib import Path
import json
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
for arm in ('cpu','cuda','vulkan'):
    receipt=json.loads((P/arm/'validation/final2/receipt.json').read_text(encoding='utf-8-sig'))
    assert receipt['passed'] and not receipt['failed'] and not receipt['skipped']
apple=json.loads((P/'apple/final-validation.json').read_text(encoding='utf-8-sig'))
assert apple['tests']==7 and apple['failed']==apple['skipped']==0
before=P/'root/docs-before';before.mkdir(exist_ok=True)
def update(name,replacements):
    p=R/name;s=p.read_text(encoding='utf-8');target=before/name.replace('/','--')
    assert not target.exists();target.write_bytes(p.read_bytes())
    for a,b in replacements:
        assert s.count(a)==1,(name,a);s=s.replace(a,b)
    p.write_text(s,encoding='utf-8')
update('docs/user/compute.md',[
('MLX 使用 `MlxQuantized{format, kind, bits, group_size}`；默认是 `kAffine/kLinear/4/64`。',
 'MLX 使用 `MlxQuantized{format, kind, bits, group_size, orientation}`；默认是 `kAffine/kLinear/4/64/kTransposeWeight`。'),
('覆盖两种专家数、双槽与更新后的旧结果；不代表某个GLM整层。当前packed乘法只表达`A*W^T`方向，\nattention head prefill所需的`A*W`仍待补，不能把rank3 head bank直接视作普通专家路由。',
 '覆盖两种专家数、双槽与更新后的旧结果；不代表某个GLM整层。\n\n'
 '`mlx_quantized_matmul`／`mlx_grouped_matmul`的末参数可传`MlxMatmulOrientation::kWeightAsStored`，\n'
 '表达affine的`A*W`：物理压缩W仍为`[N,K]`，scale/bias仍沿K分组，A末维变为N、输出末维为K。\n'
 '默认`kTransposeWeight`表达`A*W^T`，A末维K、输出末维N。grouped的IDs、共享A与slot规则不变。\n'
 '只有物理K要求按group对齐，N允许尾块；不对压缩bank作物理转置或整bank浮点展开。\n'
 'MX及embedding不接受`kWeightAsStored`。同一个head-bank的两方向、显式小query Copy、\n'
 '四端数值／旧结果及CUDA捕获边界见[本批实测](../evidence/correctness/mlx-weight-orientation-reference-2026-10-21.json)。\n'
 '这是现有F32 affine解码／点积合同的有限回归，未签上游原生低精度kernel全域逐位等价或具体GLM制品。')])
update('docs/implementation/model-operators.md',[
('MLX 的 affine4/5/6/8 基础入口已接通；六份制品的完整header集合现已核对，实际资源导入、producer舍入和完整执行仍须分别验证；',
 'MLX 的 affine4/5/6/8 基础入口及`A*W^T`／`A*W`两方向已接四端，物理K打包与分组保持不变。\n'
 '[同bank head decode／prefill及寿命回归](../evidence/correctness/mlx-weight-orientation-reference-2026-10-21.json)已通过；\n'
 '六份制品的完整header集合现已核对，实际资源导入、producer舍入和完整执行仍须分别验证；')])
update('docs/developer/current-work.md',[
('第8包进行中；原始F32 scale冷导入已补四端消费，Apple通用mixed MoE已实跑；下一项修MLX head prefill所需的非转置packed乘法',
 '第8包进行中；MLX affine非转置packed乘法已补四端，同head-bank的decode／prefill与寿命回归通过；继续精确角色导入与剩余资源／状态旅程'),
('**当前下一动作**：扩展现MLX affine packed乘法的方向，补attention head的`transpose=False` prefill，并以同一head-bank核decode／prefill与资源寿命。\n'
 '物理W仍按K打包／分组，不能交换N/K或展开整W冒充压缩执行；复用原descriptor、冷规划与各后端程序，不加模型特判或另一套executor。\n'
 '固定源码已确认GLM31的156个rank3 bank是head投影；L=1可用现grouped入口与固定head IDs表达，L>1另需非转置方向。',
 '**当前下一动作**：继续第8包的精确角色导入复核，并衔接交付3的GA非CUDA状态／资源旅程；不把通用算子通过写成整制品执行。\n'
 'MLX head prefill所需的非转置affine乘法已沿原descriptor、冷规划和四端程序落地。\n'
 '同一压缩W保物理K打包／分组，两方向覆盖H64/N512/K192、padded query显式小Copy与双槽旧结果；\n'
 '[13项新增与13项邻居](../evidence/correctness/mlx-weight-orientation-reference-2026-10-21.json)通过、无跳过，CUDA要求并实际使用捕获。\n'
 '另修CUDA原生MLX遗漏的捕获标记及Vulkan输出组初始累加污染，保原数学与逐字节检查；\n'
 '未导入156个原head payload、未签原生低dtype全域等价、整模型或吞吐。'),
('但不能外推显式dtype转换或同低dtype原生QMM逐位等价。MLX head的非转置packed prefill是本轮新确认的必修接口缺口。',
 '但不能外推显式dtype转换或同低dtype原生QMM逐位等价。MLX head的非转置packed prefill接口缺口已补，\n'
 'H64/N512/K192同bank两方向的有限数值／资源旅程已四端执行；实际publisher payload导入与完整角色组合仍须分别核定。')])
print('Updated public MLX contract, operator table and current work; capability7/8 and delivery0/3 retained.')
