from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent
spec=importlib.util.spec_from_file_location('expert_link',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];basepath=Path(c.read(P/'root/common-plan.json')['bases'][arm]['path']);base=c.read(basepath)
replacements={};extras=[];drops=set()
for summary in sorted((P/'common/checks').glob('*/summary.json')):
 for row in c.read(summary)['identities']:
  rec=c.read(row['path'])
  if arm in rec['arms']:replacements[c.key(rec['replaces']['path'])]=rec['object']
for row in c.read(P/'cpu-cuda/current-objects.json'):
 if (row['tag']=='torch-cpu' and arm in ['cpu','vulkan']) or (row['tag']!='torch-cpu' and arm=='cuda'):
  replacements[c.key(row['replaces']['path'])]=row['object']
if arm=='vulkan':
 for row in c.read(P/'vulkan/ready-for-root-link.json')['product_replacements']:
  replacements[c.key(row['old_object']['path'])]=row['object']
audit=c.read(A/'precise-role-consumers-2026-10-21/mlx-orientation-actual-owners.json')['windows_current_focused_closures'][arm]
for row in audit['owners']:
 sources=[source.replace('\\','/') for match in row['source_recipe_matches'] for source in match['source']]
 if any('/tests/' in source or '/reproduction_test.cc' in source for source in sources):drops.add(c.key(row['path']))
if arm=='cpu':
 for row in c.read(P/'cpu-cuda/tests/checks/attempt1/summary.json')['owners']:
  if row['tag']=='schema-test':
   drops.discard(c.key(row['replaces']['path']));replacements[c.key(row['replaces']['path'])]=row['object']
  else:extras.append(row['object'])
if len(sys.argv)>3:
 wrapper=Path(sys.argv[3]);test=c.read(wrapper if wrapper.is_file() else P/arm/'checks'/sys.argv[3]/'test-identity.json');extras.append(test['object'])
assert all(sum(c.key(x['path'])==k for x in base['inputs'])==1 for k in replacements)
assert not (drops & set(replacements))
assert all(c.key(x['path']) in replacements or c.key(x['path']) in drops for x in audit['owners'])
inputs=[*extras,*[replacements.get(c.key(x['path']),x) for x in base['inputs'] if c.key(x['path']) not in drops]]
assert all(b.same(row) for row in inputs)
out=P/arm/'checks'/sys.argv[2];out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'link.result.json').exists()
command=[replacements.get(c.key(x),{}).get('path',x) for x in base['command'] if c.key(x) not in drops and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command[1:1]=[x['path'] for x in extras]
image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replaced=len(replacements),added=len(extras),dropped_test_objects=sorted(drops),SDK_builds=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print(out/'link-plan.json')
