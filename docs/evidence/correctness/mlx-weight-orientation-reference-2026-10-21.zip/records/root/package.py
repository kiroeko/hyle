from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(row):
 p=resolve(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cases=[];receipts=[]
def collect(arm,path):
 for x in ET.parse(path).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name')
  cases.append(dict(backend=arm,name=name,new='Orientation' in name,
   properties={p.get('name'):p.get('value') for p in x.findall('./properties/property')}))
for arm in ('cpu','cuda','vulkan'):
 p=P/arm/'validation/final2/receipt.json';d=read(p)
 assert d['passed'] and not d['failed'] and not d['skipped']
 for k in ('image','xml','link_plan'):check(d[k])
 for row in read(resolve(d['link_plan']['path']))['inputs']:check(row)
 collect(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
ap=P/'apple/final-validation.json';ad=read(ap);assert ad['tests']==7 and ad['failed']==ad['skipped']==0
check(ad['gtest']);collect('apple',resolve(ad['gtest']['path']))
assert len(cases)==26 and sum(x['new'] for x in cases)==13
submits=sum(int(x['properties'].get('successful_submissions','0')) for x in cases if x['new'])
failures=sum(int(x['properties'].get('expected_failed_completions','0')) for x in cases if x['new'])
assert (submits,failures)==(140,8)
objects=[]
for row in read(P/'cpu-cuda/current-objects.json'):
 check(row['source']);check(row['object']);check(row['identity']);objects.append(row)
ready=read(P/'vulkan/ready-for-root-link.json')
for row in ready['product_replacements']:
 check(row['source']);check(row['object'])
assert '/embedded2/' in ready['product_replacements'][-1]['object']['path'].replace('\\','/')
assert all(x['provider_coverage']['artifact_execution_verified'] is False for x in read(R/'docs/implementation/model-quantizations.json')['artifacts'])
sources=[
 'include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc',
 'src/compute_provider_native/torch_cpu_program.cc','third_party/mlx_cpu_quant/mlx_cpu_quant.h',
 'third_party/mlx_cpu_quant/SOURCE.json','third_party/mlx_cpu_quant/NOTICE.md',
 'src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_provider_torch_cuda/mlx_packed_kernel.h',
 'src/compute_provider_torch_cuda/mlx_packed_kernel.cu','src/compute_route_cuda/default_policy.cc',
 'src/compute_route_vulkan/vulkan_mlx.cc','src/compute_route_vulkan/vulkan_iree.cc',
 'src/compute_provider_iree_vulkan/native_program.cc','src/compute_route_apple/apple_tensor.cc',
 'src/compute_provider_iree_vulkan/native_program.h','src/compute_provider_iree_vulkan/programs.h','third_party/iree_vulkan_runtime/programs/mlx.vmfb.b64',
 'third_party/iree_vulkan_runtime/programs/generate_mlx.py','third_party/iree_vulkan_runtime/programs/compile_mlx.py',
 'third_party/iree_vulkan_runtime/programs/mlx.mlir','third_party/iree_vulkan_runtime/programs/manifest.json',
 'third_party/iree_vulkan_runtime/NOTICE.md','cmake/HyleDependencyLock.json',
 'tests/compute_ops/operation_test.cc','tests/compute_route_cpu/cpu_mlx_quantized_test.cc',
 'tests/compute_models/mlx_orientation_fixture.h','tests/compute_models/mlx_affine_bitstream.h',
 'tests/compute_models/nvfp4_reference_fixture.h','tests/compute_models/mlx_grouped_shared_fixture.h',
 'docs/user/compute.md','docs/developer/current-work.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
sources += [f'tests/graph_route_{a}/{name}' for a in ('cpu','cuda','vulkan','apple') for name in ('mlx_orientation_test.cc','CMakeLists.txt')]
missing=[s for s in sources if not (R/s).is_file()];assert not missing,missing
for a in ('cpu','cuda','vulkan','apple'):assert 'mlx_orientation_test.cc' in (R/f'tests/graph_route_{a}/CMakeLists.txt').read_text(encoding='utf-8')
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c','.md','.cu','.d','.metal','.comp','.mm','.ps1','.mlir','.vmfb'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
previous=P.parent/'precise-role-consumers-2026-10-21'
for name in ('mlx-orientation-design.json','mlx-orientation-actual-owners.json','mlx-head-review.json'):
 p=previous/name;assert p.is_file();entries['prior-source-review/'+name]=p
archive=R/'docs/evidence/correctness/mlx-weight-orientation-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='affine_packed_weight_both_directions_four_backend_passed',
 implementation='Original MlxQuantized descriptor gains explicit orientation, current20-byte/operation-ID3 only. Affine AsStored computes A*W with original physical W[N,K], K-directed bit packing and scale groups; original default A*W^T retained. A.depth/output.width become N/K. No shape inference, physical transpose, full NK/ENK float bank, new executor or model policy.',
 numerical_contract='F32 pointwise code*scale+bias, F32 dot and declared final cast; same activation/metadata dtype keeps type, mixed yieldsF32. MX and embedding reject AsStored. N may have a real tail; only physicalK must align with group. This signs finite independent witnesses, not arbitrary upstream same-low-type QMM bit equivalence.',
 regression=dict(total=26,new=13,neighbors=13,failed=0,skipped=0,windows=receipts,apple=ident(ap),cases=cases,
  successful_new_Graph_submissions=140,expected_new_Graph_failed_Completions=8,
  count='3 orientation Graph tests on each of4backends plus1 CPU descriptor/infer test;9 original CPU MLX Graph neighbors plus4 Apple MLX/MoE neighbors.',
  dense='Same original bank both directions:bits5/group32/N7/K96/F32;bits6/group128/N13/K256/BF16 A+F16SF->F32;bits4/group64/N9/K192/BF16;bits8/group32/N67/K64/F16. Independent single-bit packing, dyadic metadata and3 nonzero A pulses avoid reduction-order ambiguity; final bytes compare without tolerance.',
  heads='Original-shape H64/N512/K192/bits4/group64/BF16 bank, T3, unchanged head IDs and bank for both directions. Default transposed query keeps256-backed row pitch and poisoned unused lanes, explicit ordinary small Copy only; AsStored sharedN512 A returnsK192. Additional E3 mixed shared/zero-slot-stride/independent A, duplicate and changing IDs.',
  lifetime='Two independent slots and2content generations; outputs retained through opposite-slot updates, rebind/result gating, and invocation/compiled release. Negative and E IDs fail Completion before bank addressing; fresh consumers recover. CUDA requires/asserts actual captured replay.',
  schema='Unknown orientation, invalid depths, MX AsStored and embedding AsStored rejected; default direction, mixed dtype, non-group-complete N and shared stride accepted.'),
 fixes=dict(CUDA='All original MLX variants are already native launches with no ATen invocation/prepare/submit or hot allocation; propose and prepare now reuse the existing capture-compatible native packed runtime. First actual RequireCapture rejection and source audit retained. Test requirement unchanged.',
  Vulkan='Original group accumulator slice carried already written first-group values into later disjoint output groups. Actual raw160/160 low-dtype witness values equal RNE(current_dot+first_group_dot). Each independent output-group accumulator now explicitly starts from F32 zero; no redundant read of sum. Final insert and mathematical operations unchanged. Original33 exported bodies preserved; only new affine AsStored body refreshed.',
  fixture='First CPU window failed two caller-owned-output cases because invocation factory omitted ResourceOptions. Fixed test setup only; current canonical fixture passes allfour. Initial compile/header-warning and offline shape failures are retained as actual failures, not successful product checks.'),
 resources='CPU and Vulkan tile selected N by at most64 rows and one physical K output group. CUDA reads selected packed values directly. Apple forwards orientation to original native affine QMM/gather. Shared constants/IDs/owner/completion stay on existing programs and Invocation. CPU managed runtime allocation is not claimed zero or strictly budgeted.',
 source_review=dict(prior_head_design=ident(previous/'mlx-orientation-design.json'),actual_descriptor_owners=ident(previous/'mlx-orientation-actual-owners.json'),independent_review=ident(P/'apple/independent-orientation-review.json'),CUDA_native_capture_audit=ident(P/'cpu-cuda/capture-runtime/runtime-review.json'),Vulkan_raw_attribution=ident(P/'vulkan/runtime-red-attribution.json')),
 build='Reused existing SDKs, toolchains, dependencies and unaffected link objects. Fresh actual descriptor constructors/extractors avoid mixing old16-byte and new20-byte template owners. One native CUDA TU plus one offline MLX module and focused CXX owners; no full SDK build. NVCC retry retains W4/WX with existing /wd4702 for unchanged CT/GPTQ constexpr-tail diagnostics; no CT/GPTQ math edits.',
 remaining_required='Capability7/8 and delivery0/3 stay open. Continue exact source-role import/resource/state journeys, including catalog31 original payload and separate unembed_out roles, catalog32 F16-metadata model journey and GA non-CUDA state/role consumers. No whole-artifact execution is inferred from these primitive/shape tests.',
 limitations=['No original MLX numeric payload import, whole GLM attention/model, Linux, quality, throughput or peak-memory acceptance. All33 catalog artifact_execution_verified flags remainfalse.',
 'Default upstream loader promotion and native same-low-type arithmetic remain distinct contracts. This batch uses the declared Hyle F32 reference; it does not change numerical rules to gain coverage.',
 'No new Qwen BF16 decode speed claim; this new packed orientation is not on that current consumer path.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],current_sources=len(sources),cases=26,new=13,neighbors=13)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
