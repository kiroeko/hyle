from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
old=A/'precise-role-consumers-2026-10-21'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for name in ('build_common.py','build_wrapper.py','run_windows.py','link_windows.py'):
 (P/'root'/name).write_bytes((old/'root'/name).read_bytes())
audit=read(old/'mlx-orientation-actual-owners.json')['windows_current_focused_closures']
entry=next(x for x in audit['cpu']['owners'] if any('src\\compute_ops\\weight_decode.cc' in source for m in x['source_recipe_matches'] for source in m['source']))
recipe=Path(entry['source_recipe_matches'][0]['identity']);rec=read(recipe)
source=R/'src/compute_ops/weight_decode.cc'
bases={arm:ident(old/arm/'checks/link1/link-plan.json') for arm in ('cpu','cuda','vulkan')}
rows=[dict(old_object={k:entry[k] for k in ('path','bytes','sha256')},source=ident(source),recipe=ident(recipe),command=rec['command'],arms=['cpu','cuda','vulkan'])]
(P/'root/common-plan.json').write_text(json.dumps(dict(bases=bases,owners=rows),indent=2)+'\n',encoding='utf-8')
for arm in ('cpu','cuda'):
 path=R/f'tests/graph_route_{arm}/CMakeLists.txt';text=path.read_text()
 assert 'mlx_orientation_test.cc' not in text
 path.write_text(text.replace('e8m0_weight_import_test.cc','e8m0_weight_import_test.cc mlx_orientation_test.cc',1),encoding='utf-8')
print('Prepared shared schema owner and two thin-wrapper targets.')
