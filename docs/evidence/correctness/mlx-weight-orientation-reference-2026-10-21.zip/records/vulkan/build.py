from pathlib import Path
import json,hashlib,subprocess,os,concurrent.futures,time,sys
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'mlx-weight-orientation-2026-10-21/vulkan';B=A/'precise-role-consumers-2026-10-21/vulkan/checks/link1/link-plan.json';C=S/('checks/'+('test1' if sys.argv[1]=='test' else sys.argv[1]) if len(sys.argv)>1 and (sys.argv[1].startswith('test') or sys.argv[1].startswith('embedded')) else 'checks/attempt1');C.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(Path(p).read_bytes())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
base=read(B);recipes={}
for obj in base['inputs']:
 p=Path(obj['path'])
 if p.suffix.lower()!='.obj':continue
 for candidate in p.parent.glob('*identity.json'):
  try:d=read(candidate)
  except Exception:continue
  if Path(d.get('object',{}).get('path',''))==p:
   src=[x for x in d.get('command',[]) if Path(x).suffix.lower() in ['.cc','.cpp']]
   if src:recipes[Path(src[-1]).name]=(p,candidate)
selected=[('native-program','native_program.cc',R/'src/compute_provider_iree_vulkan/native_program.cc'),('mlx','vulkan_mlx.cc',R/'src/compute_route_vulkan/vulkan_mlx.cc'),('iree','vulkan_iree.cc',R/'src/compute_route_vulkan/vulkan_iree.cc'),('embedded','programs.cc',S/'generated/programs.cc')]
if len(sys.argv)>1 and sys.argv[1].startswith('test'):selected=[('orientation-test','e8m0_weight_import_test.cc',R/'tests/graph_route_vulkan/mlx_orientation_test.cc')]
if len(sys.argv)>1 and sys.argv[1].startswith('embedded'):selected=[('embedded','programs.cc',S/'generated/programs.cc')]
env=os.environ.copy();out=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in out.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
TMP=S/'tmp';TMP.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(TMP)
def one(item):
 tag,name,source=item;old,recipe=recipes[name];command=[];skip=False
 for arg in read(recipe)['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or Path(arg).suffix.lower() in ['.cc','.cpp']:continue
  command.append(arg)
 command+=['/W4','/WX','/sourceDependencies',str(C/(tag+'-deps.json')),str(source),'/Fo'+str(C/(tag+'.obj')),'/Fd'+str(C/(tag+'.pdb'))]
 save(C/(tag+'-plan.json'),dict(command=command,old_object=identity(old),recipe=identity(recipe),source=identity(source)))
 start=time.time();p=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace');save(C/(tag+'-command.json'),dict(command=command,exit_code=p.returncode,seconds=time.time()-start,cwd=str(R)));(C/(tag+'-stdout.txt')).write_text(p.stdout);(C/(tag+'-stderr.txt')).write_text(p.stderr);print(tag,p.returncode,flush=True)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr)[-5000:])
 deps=read(C/(tag+'-deps.json'))['Data'];d=dict(command=command,source=identity(source),object=identity(C/(tag+'.obj')),recipe=identity(recipe),replaces=identity(old),dependencies=[identity(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]);
 if source.name=='mlx_orientation_test.cc':d['recipe_object']=d.pop('replaces');d['new_link_input']=True
 save(C/(tag+'-identity.json'),d);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(one,selected))
save(C/'objects-ready.json',dict(CXX_success=len(rows),SDK_build=0,GPU=0,base=identity(B),objects=[dict(source=x['source'],object=x['object'],**(dict(recipe_object=x['recipe_object'],new_link_input=True) if x.get('new_link_input') else dict(old_object=x['replaces']))) for x in rows]))
