import subprocess,json,time
from pathlib import Path
cmd=['python', '-B', 'C:\\public\\project-hyle\\hyle\\third_party\\iree_vulkan_runtime\\programs\\compile_mlx.py', '--compiler', 'C:\\public\\project-hyle\\hyle\\.scratch\\tools\\iree-6ef606b6\\package\\iree\\compiler\\_mlir_libs\\iree-compile.exe', '--output', 'C:\\public\\project-hyle\\hyle\\.scratch\\architecture-refactor-2026-10-18\\mlx-weight-orientation-2026-10-21\\vulkan\\offline\\attempt3']
p=Path('C:\\public\\project-hyle\\hyle\\.scratch\\architecture-refactor-2026-10-18\\mlx-weight-orientation-2026-10-21\\vulkan\\offline\\attempt3')
start=time.time();r=subprocess.run(cmd,capture_output=True,text=True)
(p/"runner.stdout.txt").write_text(r.stdout);(p/"runner.stderr.txt").write_text(r.stderr)
(p/"runner.json").write_text(json.dumps(dict(command=cmd,cwd=str(Path.cwd()),exit_code=r.returncode,seconds=time.time()-start),indent=2)+"\n")
print("offline",r.returncode,flush=True)
print((r.stdout+r.stderr)[-7000:])
raise SystemExit(r.returncode)
