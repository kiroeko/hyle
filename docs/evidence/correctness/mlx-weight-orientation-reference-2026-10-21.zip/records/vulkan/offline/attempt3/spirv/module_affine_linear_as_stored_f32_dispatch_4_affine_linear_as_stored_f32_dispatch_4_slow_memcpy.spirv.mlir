spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<9 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_linear_as_stored_f32_dispatch_4_slow_memcpy() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst5_i32 = spirv.Constant 5 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst-64_i32 = spirv.Constant -64 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<9 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst1_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<9 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst3_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<9 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst5_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<9 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst7_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<9 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %8 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %9 = spirv.CompositeExtract %8[0 : i32] : vector<3xi32>
    %10 = spirv.SLessThanEqual %5, %cst0_i32 : i32
    %11 = spirv.ISub %cst0_i32, %5 : i32
    %12 = spirv.ISub %5, %cst1_i32 : i32
    %13 = spirv.Select %10, %11, %12 : i1, i32
    %14 = spirv.SDiv %13, %cst64_i32 : i32
    %15 = spirv.ISub %cst0_i32, %14 : i32
    %16 = spirv.IAdd %14, %cst1_i32 : i32
    %17 = spirv.Select %10, %15, %16 : i1, i32
    %18 = spirv.IMul %3, %17 : i32
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %19 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %20 = spirv.CompositeExtract %19[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %21 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %22 = spirv.CompositeExtract %21[0 : i32] : vector<3xi32>
    spirv.mlir.loop {
      spirv.Branch ^bb1(%20 : i32)
    ^bb1(%23: i32):  // 2 preds: ^bb0, ^bb2
      %24 = spirv.SLessThan %23, %18 : i32
      spirv.BranchConditional %24, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %25 = spirv.SDiv %23, %17 : i32
      %26 = spirv.IMul %25, %17 : i32
      %27 = spirv.INotEqual %23, %26 : i32
      %28 = spirv.SLessThan %23, %cst0_i32 : i32
      %29 = spirv.SLessThan %17, %cst0_i32 : i32
      %30 = spirv.LogicalNotEqual %28, %29 : i1
      %31 = spirv.LogicalAnd %27, %30 : i1
      %32 = spirv.IAdd %25, %cst-1_i32 : i32
      %33 = spirv.Select %31, %32, %25 : i1, i32
      %34 = spirv.GL.SAbs %23 : i32
      %35 = spirv.GL.SAbs %17 : i32
      %36 = spirv.UMod %34, %35 : i32
      %37 = spirv.IEqual %23, %34 : i32
      %38 = spirv.SNegate %36 : i32
      %39 = spirv.Select %37, %36, %38 : i1, i32
      %40 = spirv.SLessThan %39, %cst0_i32 : i32
      %41 = spirv.IAdd %39, %17 : i32
      %42 = spirv.Select %40, %41, %39 : i1, i32
      %43 = spirv.IMul %42, %cst-64_i32 : i32
      %44 = spirv.IAdd %43, %5 : i32
      %45 = spirv.GL.SMin %44, %cst64_i32 : i32
      %46 = spirv.SGreaterThan %45, %9 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %46, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %48 = spirv.IMul %42, %cst64_i32 : i32
        %49 = spirv.IAdd %48, %9 : i32
        %50 = spirv.IMul %33, %5 : i32
        %51 = spirv.IAdd %49, %50 : i32
        %52 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %51] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %53 = spirv.Load "StorageBuffer" %52 : f32
        %54 = spirv.IAdd %48, %1 : i32
        %55 = spirv.IAdd %54, %9 : i32
        %56 = spirv.IMul %33, %7 : i32
        %57 = spirv.IAdd %55, %56 : i32
        %58 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %57] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %58, %53 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %47 = spirv.IAdd %23, %22 : i32
      spirv.Branch ^bb1(%47 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_linear_as_stored_f32_dispatch_4_slow_memcpy, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_linear_as_stored_f32_dispatch_4_slow_memcpy "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_linear_as_stored_f32_dispatch_4_slow_memcpy "SignedZeroInfNanPreserve", 32
}