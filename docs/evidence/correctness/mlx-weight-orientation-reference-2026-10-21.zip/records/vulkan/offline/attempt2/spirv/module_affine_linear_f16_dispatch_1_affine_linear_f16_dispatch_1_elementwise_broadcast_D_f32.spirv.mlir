spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Float16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst29_i32 = spirv.Constant 29 : i32
    %cst27_i32 = spirv.Constant 27 : i32
    %cst25_i32 = spirv.Constant 25 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst21_i32 = spirv.Constant 21 : i32
    %cst19_i32 = spirv.Constant 19 : i32
    %cst17_i32 = spirv.Constant 17 : i32
    %cst15_i32 = spirv.Constant 15 : i32
    %cst13_i32 = spirv.Constant 13 : i32
    %cst11_i32 = spirv.Constant 11 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst32_i32 = spirv.Constant 32 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst31_i32 = spirv.Constant 31 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst11_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst13_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst15_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %18 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst17_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %19 = spirv.Load "PushConstant" %18 : i32
    %20 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst19_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %21 = spirv.Load "PushConstant" %20 : i32
    %22 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst21_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %23 = spirv.Load "PushConstant" %22 : i32
    %24 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst23_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %25 = spirv.Load "PushConstant" %24 : i32
    %26 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst25_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %27 = spirv.Load "PushConstant" %26 : i32
    %28 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst27_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %29 = spirv.Load "PushConstant" %28 : i32
    %30 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst29_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<31 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %31 = spirv.Load "PushConstant" %30 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
    %32 = spirv.SLessThan %1, %cst0_i32 : i32
    %33 = spirv.ISub %cst-1_i32, %1 : i32
    %34 = spirv.Select %32, %33, %1 : i1, i32
    %35 = spirv.SDiv %34, %cst4_i32 : i32
    %36 = spirv.ISub %cst-1_i32, %35 : i32
    %37 = spirv.Select %32, %36, %35 : i1, i32
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %38 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %39 = spirv.CompositeExtract %38[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %40 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %41 = spirv.CompositeExtract %40[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %42 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %43 = spirv.CompositeExtract %42[0 : i32] : vector<3xi32>
    %44 = spirv.IMul %41, %cst64_i32 : i32
    %45 = spirv.IMul %43, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%44 : i32)
    ^bb1(%46: i32):  // 2 preds: ^bb0, ^bb2
      %47 = spirv.SLessThan %46, %3 : i32
      spirv.BranchConditional %47, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %48 = spirv.ISub %3, %46 : i32
      %49 = spirv.GL.SMin %48, %cst64_i32 : i32
      %50 = spirv.SGreaterThan %49, %39 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %50, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %52 = spirv.IAdd %46, %39 : i32
        %53 = spirv.GL.SAbs %52 : i32
        %54 = spirv.GL.SAbs %5 : i32
        %55 = spirv.UMod %53, %54 : i32
        %56 = spirv.IEqual %52, %53 : i32
        %57 = spirv.SNegate %55 : i32
        %58 = spirv.Select %56, %55, %57 : i1, i32
        %59 = spirv.SDiv %52, %5 : i32
        %60 = spirv.GL.SAbs %59 : i32
        %61 = spirv.GL.SAbs %17 : i32
        %62 = spirv.UMod %60, %61 : i32
        %63 = spirv.IEqual %59, %60 : i32
        %64 = spirv.SNegate %62 : i32
        %65 = spirv.Select %63, %62, %64 : i1, i32
        %66 = spirv.IAdd %7, %58 : i32
        %67 = spirv.UDiv %66, %cst32_i32 : i32
        %68 = spirv.UMod %66, %cst32_i32 : i32
        %69 = spirv.IMul %67, %9 : i32
        %70 = spirv.IMul %68, %9 : i32
        %71 = spirv.UDiv %70, %cst32_i32 : i32
        %72 = spirv.IAdd %69, %71 : i32
        %73 = spirv.UMod %70, %cst32_i32 : i32
        %74 = spirv.IAdd %73, %9 : i32
        %75 = spirv.UGreaterThan %74, %cst32_i32 : i32
        %76 = spirv.IAdd %72, %cst1_i32 : i32
        %77 = spirv.Select %75, %76, %72 : i1, i32
        %78 = spirv.IMul %65, %19 : i32
        %79 = spirv.IAdd %78, %72 : i32
        %80 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %79] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %81 = spirv.Load "StorageBuffer" %80 : i32
        %82 = spirv.IAdd %78, %77 : i32
        %83 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %82] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %84 = spirv.Load "StorageBuffer" %83 : i32
        %85 = spirv.ShiftRightLogical %81, %73 : i32, i32
        %86 = spirv.ISub %cst32_i32, %73 : i32
        %87 = spirv.BitwiseAnd %86, %cst31_i32 : i32
        %88 = spirv.ShiftLeftLogical %84, %87 : i32, i32
        %89 = spirv.Select %75, %88, %cst0_i32 : i1, i32
        %90 = spirv.BitwiseOr %85, %89 : i32
        %91 = spirv.BitwiseAnd %90, %11 : i32
        %92 = spirv.ConvertUToF %91 : i32 to f32
        %93 = spirv.IMul %65, %25 : i32
        %94 = spirv.IAdd %93, %13 : i32
        %95 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %94] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f16, StorageBuffer>
        %96 = spirv.Load "StorageBuffer" %95 : f16
        %97 = spirv.IMul %65, %31 : i32
        %98 = spirv.IAdd %97, %13 : i32
        %99 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %98] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f16, StorageBuffer>
        %100 = spirv.Load "StorageBuffer" %99 : f16
        %101 = spirv.FConvert %96 : f16 to f32
        %102 = spirv.FConvert %100 : f16 to f32
        %103 = spirv.FMul %92, %101 : f32
        %104 = spirv.FAdd %103, %102 : f32
        %105 = spirv.IAdd %52, %37 : i32
        %106 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %105] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %106, %104 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %51 = spirv.IAdd %46, %45 : i32
      spirv.Branch ^bb1(%51 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}