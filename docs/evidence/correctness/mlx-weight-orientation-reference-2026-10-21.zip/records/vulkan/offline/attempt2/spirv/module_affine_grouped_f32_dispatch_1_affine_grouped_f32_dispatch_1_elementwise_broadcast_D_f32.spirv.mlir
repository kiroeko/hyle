spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_4_ bind(0, 4) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst29_i32 = spirv.Constant 29 : i32
    %cst27_i32 = spirv.Constant 27 : i32
    %cst25_i32 = spirv.Constant 25 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst21_i32 = spirv.Constant 21 : i32
    %cst19_i32 = spirv.Constant 19 : i32
    %cst17_i32 = spirv.Constant 17 : i32
    %cst15_i32 = spirv.Constant 15 : i32
    %cst13_i32 = spirv.Constant 13 : i32
    %cst11_i32 = spirv.Constant 11 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst32_i32 = spirv.Constant 32 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst31_i32 = spirv.Constant 31 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst11_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst13_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst15_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %18 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst17_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %19 = spirv.Load "PushConstant" %18 : i32
    %20 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst19_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %21 = spirv.Load "PushConstant" %20 : i32
    %22 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst21_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %23 = spirv.Load "PushConstant" %22 : i32
    %24 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst23_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %25 = spirv.Load "PushConstant" %24 : i32
    %26 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst25_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %27 = spirv.Load "PushConstant" %26 : i32
    %28 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst27_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %29 = spirv.Load "PushConstant" %28 : i32
    %30 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst29_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %31 = spirv.Load "PushConstant" %30 : i32
    %32 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst31_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<33 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %33 = spirv.Load "PushConstant" %32 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %34 = spirv.SLessThan %1, %cst0_i32 : i32
    %35 = spirv.ISub %cst-1_i32, %1 : i32
    %36 = spirv.Select %34, %35, %1 : i1, i32
    %37 = spirv.SDiv %36, %cst4_i32 : i32
    %38 = spirv.ISub %cst-1_i32, %37 : i32
    %39 = spirv.Select %34, %38, %37 : i1, i32
    %__resource_var_0_4__addr = spirv.mlir.addressof @__resource_var_0_4_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %40 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %41 = spirv.CompositeExtract %40[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %42 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %43 = spirv.CompositeExtract %42[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %44 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %45 = spirv.CompositeExtract %44[0 : i32] : vector<3xi32>
    %46 = spirv.IMul %43, %cst64_i32 : i32
    %47 = spirv.IMul %45, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%46 : i32)
    ^bb1(%48: i32):  // 2 preds: ^bb0, ^bb2
      %49 = spirv.SLessThan %48, %3 : i32
      spirv.BranchConditional %49, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %50 = spirv.ISub %3, %48 : i32
      %51 = spirv.GL.SMin %50, %cst64_i32 : i32
      %52 = spirv.SGreaterThan %51, %41 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %52, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %54 = spirv.IAdd %48, %41 : i32
        %55 = spirv.GL.SAbs %54 : i32
        %56 = spirv.GL.SAbs %5 : i32
        %57 = spirv.UMod %55, %56 : i32
        %58 = spirv.IEqual %54, %55 : i32
        %59 = spirv.SNegate %57 : i32
        %60 = spirv.Select %58, %57, %59 : i1, i32
        %61 = spirv.SDiv %54, %5 : i32
        %62 = spirv.GL.SAbs %61 : i32
        %63 = spirv.GL.SAbs %19 : i32
        %64 = spirv.UMod %62, %63 : i32
        %65 = spirv.IEqual %61, %62 : i32
        %66 = spirv.SNegate %64 : i32
        %67 = spirv.Select %65, %64, %66 : i1, i32
        %68 = spirv.SDiv %61, %19 : i32
        %69 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %68] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %70 = spirv.Load "StorageBuffer" %69 : i32
        %71 = spirv.IAdd %7, %60 : i32
        %72 = spirv.UDiv %71, %cst32_i32 : i32
        %73 = spirv.UMod %71, %cst32_i32 : i32
        %74 = spirv.IMul %72, %9 : i32
        %75 = spirv.IMul %73, %9 : i32
        %76 = spirv.UDiv %75, %cst32_i32 : i32
        %77 = spirv.IAdd %74, %76 : i32
        %78 = spirv.UMod %75, %cst32_i32 : i32
        %79 = spirv.IAdd %78, %9 : i32
        %80 = spirv.UGreaterThan %79, %cst32_i32 : i32
        %81 = spirv.IAdd %77, %cst1_i32 : i32
        %82 = spirv.Select %80, %81, %77 : i1, i32
        %83 = spirv.IMul %70, %19 : i32
        %84 = spirv.IAdd %67, %83 : i32
        %85 = spirv.IMul %84, %21 : i32
        %86 = spirv.IAdd %77, %85 : i32
        %87 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %86] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %88 = spirv.Load "StorageBuffer" %87 : i32
        %89 = spirv.IAdd %82, %85 : i32
        %90 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %89] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %91 = spirv.Load "StorageBuffer" %90 : i32
        %92 = spirv.ShiftRightLogical %88, %78 : i32, i32
        %93 = spirv.ISub %cst32_i32, %78 : i32
        %94 = spirv.BitwiseAnd %93, %cst31_i32 : i32
        %95 = spirv.ShiftLeftLogical %91, %94 : i32, i32
        %96 = spirv.Select %80, %95, %cst0_i32 : i1, i32
        %97 = spirv.BitwiseOr %92, %96 : i32
        %98 = spirv.BitwiseAnd %97, %11 : i32
        %99 = spirv.ConvertUToF %98 : i32 to f32
        %100 = spirv.IMul %70, %25 : i32
        %101 = spirv.IAdd %67, %100 : i32
        %102 = spirv.IMul %101, %27 : i32
        %103 = spirv.IAdd %13, %102 : i32
        %104 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %103] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %105 = spirv.Load "StorageBuffer" %104 : f32
        %106 = spirv.IMul %70, %31 : i32
        %107 = spirv.IAdd %67, %106 : i32
        %108 = spirv.IMul %107, %33 : i32
        %109 = spirv.IAdd %13, %108 : i32
        %110 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %109] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %111 = spirv.Load "StorageBuffer" %110 : f32
        %112 = spirv.FMul %99, %105 : f32
        %113 = spirv.FAdd %112, %111 : f32
        %114 = spirv.IAdd %54, %39 : i32
        %115 = spirv.AccessChain %__resource_var_0_4__addr[%cst0_i32, %114] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %115, %113 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %53 = spirv.IAdd %48, %47 : i32
      spirv.Branch ^bb1(%53 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}