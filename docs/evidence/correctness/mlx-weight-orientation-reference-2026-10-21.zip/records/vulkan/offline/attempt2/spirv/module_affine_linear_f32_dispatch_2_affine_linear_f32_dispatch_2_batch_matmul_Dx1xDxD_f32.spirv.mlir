spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<6 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst-64_i32 = spirv.Constant -64 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst_f32 = spirv.Constant 0.000000e+00 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<6 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<6 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<6 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<6 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %6 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %7 = spirv.CompositeExtract %6[0 : i32] : vector<3xi32>
    %8 = spirv.SLessThanEqual %5, %cst0_i32 : i32
    %9 = spirv.ISub %cst0_i32, %5 : i32
    %10 = spirv.ISub %5, %cst1_i32 : i32
    %11 = spirv.Select %8, %9, %10 : i1, i32
    %12 = spirv.SDiv %11, %cst64_i32 : i32
    %13 = spirv.ISub %cst0_i32, %12 : i32
    %14 = spirv.IAdd %12, %cst1_i32 : i32
    %15 = spirv.Select %8, %13, %14 : i1, i32
    %16 = spirv.IMul %1, %15 : i32
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %17 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %18 = spirv.CompositeExtract %17[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %19 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %20 = spirv.CompositeExtract %19[0 : i32] : vector<3xi32>
    spirv.mlir.loop {
      spirv.Branch ^bb1(%18 : i32)
    ^bb1(%21: i32):  // 2 preds: ^bb0, ^bb2
      %22 = spirv.SLessThan %21, %16 : i32
      spirv.BranchConditional %22, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %23 = spirv.SDiv %21, %15 : i32
      %24 = spirv.IMul %23, %15 : i32
      %25 = spirv.INotEqual %21, %24 : i32
      %26 = spirv.SLessThan %21, %cst0_i32 : i32
      %27 = spirv.SLessThan %15, %cst0_i32 : i32
      %28 = spirv.LogicalNotEqual %26, %27 : i1
      %29 = spirv.LogicalAnd %25, %28 : i1
      %30 = spirv.IAdd %23, %cst-1_i32 : i32
      %31 = spirv.Select %29, %30, %23 : i1, i32
      %32 = spirv.GL.SAbs %21 : i32
      %33 = spirv.GL.SAbs %15 : i32
      %34 = spirv.UMod %32, %33 : i32
      %35 = spirv.IEqual %21, %32 : i32
      %36 = spirv.SNegate %34 : i32
      %37 = spirv.Select %35, %34, %36 : i1, i32
      %38 = spirv.SLessThan %37, %cst0_i32 : i32
      %39 = spirv.IAdd %37, %15 : i32
      %40 = spirv.Select %38, %39, %37 : i1, i32
      %41 = spirv.IMul %40, %cst-64_i32 : i32
      %42 = spirv.IAdd %41, %5 : i32
      %43 = spirv.GL.SMin %42, %cst64_i32 : i32
      %44 = spirv.SGreaterThan %43, %7 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %44, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %46 = spirv.IMul %40, %cst64_i32 : i32
        %47 = spirv.IAdd %46, %7 : i32
        %48 = spirv.IMul %31, %5 : i32
        %49 = spirv.IAdd %47, %48 : i32
        %50 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %49] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %50, %cst_f32 : f32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%51: i32):  // 2 preds: ^bb0, ^bb2
          %52 = spirv.SLessThan %51, %3 : i32
          spirv.BranchConditional %52, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %53 = spirv.IMul %31, %3 : i32
          %54 = spirv.IAdd %53, %51 : i32
          %55 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %54] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %56 = spirv.Load "StorageBuffer" %55 : f32
          %57 = spirv.IMul %49, %3 : i32
          %58 = spirv.IAdd %57, %51 : i32
          %59 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %58] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %60 = spirv.Load "StorageBuffer" %59 : f32
          %61 = spirv.Load "StorageBuffer" %50 : f32
          %62 = spirv.FMul %56, %60 : f32
          %63 = spirv.FAdd %61, %62 : f32
          spirv.Store "StorageBuffer" %50, %63 : f32
          %64 = spirv.IAdd %51, %cst1_i32 : i32
          spirv.Branch ^bb1(%64 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %45 = spirv.IAdd %21, %20 : i32
      spirv.Branch ^bb1(%45 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32 "SignedZeroInfNanPreserve", 32
}