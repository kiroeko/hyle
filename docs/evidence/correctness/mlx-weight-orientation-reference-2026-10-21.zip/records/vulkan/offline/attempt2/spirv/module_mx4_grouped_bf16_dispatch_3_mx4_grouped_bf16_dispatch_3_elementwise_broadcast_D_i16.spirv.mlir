spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.func @mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst24_i32 = spirv.Constant 24 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst14_i32 = spirv.Constant 14 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst32704_i16 = spirv.Constant 32704 : i16
    %cst32767_i32 = spirv.Constant 32767 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst4194304_i32 = spirv.Constant 4194304 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst12_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst14_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<16 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %16 = spirv.SLessThan %1, %cst0_i32 : i32
    %17 = spirv.ISub %cst-1_i32, %1 : i32
    %18 = spirv.Select %16, %17, %1 : i1, i32
    %19 = spirv.SDiv %18, %cst2_i32 : i32
    %20 = spirv.ISub %cst-1_i32, %19 : i32
    %21 = spirv.Select %16, %20, %19 : i1, i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %22 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %23 = spirv.CompositeExtract %22[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %24 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %25 = spirv.CompositeExtract %24[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %26 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %27 = spirv.CompositeExtract %26[0 : i32] : vector<3xi32>
    %28 = spirv.IMul %25, %cst64_i32 : i32
    %29 = spirv.IMul %27, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%28 : i32)
    ^bb1(%30: i32):  // 2 preds: ^bb0, ^bb2
      %31 = spirv.SLessThan %30, %3 : i32
      spirv.BranchConditional %31, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %32 = spirv.ISub %3, %30 : i32
      %33 = spirv.GL.SMin %32, %cst64_i32 : i32
      %34 = spirv.SGreaterThan %33, %23 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %34, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %36 = spirv.IAdd %30, %23 : i32
        %37 = spirv.GL.SAbs %36 : i32
        %38 = spirv.GL.SAbs %5 : i32
        %39 = spirv.UMod %37, %38 : i32
        %40 = spirv.IEqual %36, %37 : i32
        %41 = spirv.SNegate %39 : i32
        %42 = spirv.Select %40, %39, %41 : i1, i32
        %43 = spirv.SDiv %36, %5 : i32
        %44 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %43] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %45 = spirv.Load "StorageBuffer" %44 : i32
        %46 = spirv.IMul %45, %13 : i32
        %47 = spirv.IAdd %42, %46 : i32
        %48 = spirv.IMul %47, %15 : i32
        %49 = spirv.IAdd %7, %48 : i32
        %50 = spirv.SDiv %49, %cst4_i32 : i32
        %51 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %50] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %52 = spirv.Load "StorageBuffer" %51 : i32
        %53 = spirv.UMod %49, %cst4_i32 : i32
        %54 = spirv.IMul %53, %cst8_i32 : i32
        %55 = spirv.ShiftRightArithmetic %52, %54 : i32, i32
        %56 = spirv.BitwiseAnd %55, %cst255_i32 : i32
        %57 = spirv.ShiftLeftLogical %56, %cst24_i32 : i32, i32
        %58 = spirv.ShiftRightArithmetic %57, %cst24_i32 : i32, i32
        %59 = spirv.BitwiseAnd %58, %cst255_i32 : i32
        %60 = spirv.ShiftLeftLogical %59, %cst23_i32 : i32, i32
        %61 = spirv.IEqual %59, %cst0_i32 : i32
        %62 = spirv.Select %61, %cst4194304_i32, %60 : i1, i32
        %63 = spirv.Bitcast %62 : i32 to f32
        %64 = spirv.FUnordNotEqual %63, %63 : f32
        %65 = spirv.ShiftRightLogical %62, %cst16_i32 : i32, i32
        %66 = spirv.BitwiseAnd %65, %cst1_i32 : i32
        %67 = spirv.IAdd %66, %cst32767_i32 : i32
        %68 = spirv.IAdd %62, %67 : i32
        %69 = spirv.ShiftRightLogical %68, %cst16_i32 : i32, i32
        %70 = spirv.SConvert %69 : i32 to i16
        %71 = spirv.Select %64, %cst32704_i16, %70 : i1, i16
        %72 = spirv.IAdd %36, %21 : i32
        %73 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %72] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        spirv.Store "StorageBuffer" %73, %71 : i16
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %35 = spirv.IAdd %30, %29 : i32
      spirv.Branch ^bb1(%35 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16 "SignedZeroInfNanPreserve", 32
}