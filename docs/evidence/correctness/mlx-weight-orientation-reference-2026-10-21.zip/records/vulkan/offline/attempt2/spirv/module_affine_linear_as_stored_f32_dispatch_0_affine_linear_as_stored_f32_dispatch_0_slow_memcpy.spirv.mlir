spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_linear_as_stored_f32_dispatch_0_slow_memcpy() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst-64_i32 = spirv.Constant -64 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %10 = spirv.SLessThan %1, %cst0_i32 : i32
    %11 = spirv.ISub %cst-1_i32, %1 : i32
    %12 = spirv.Select %10, %11, %1 : i1, i32
    %13 = spirv.SDiv %12, %cst4_i32 : i32
    %14 = spirv.ISub %cst-1_i32, %13 : i32
    %15 = spirv.Select %10, %14, %13 : i1, i32
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %16 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %17 = spirv.CompositeExtract %16[0 : i32] : vector<3xi32>
    %18 = spirv.SLessThanEqual %9, %cst0_i32 : i32
    %19 = spirv.ISub %cst0_i32, %9 : i32
    %20 = spirv.ISub %9, %cst1_i32 : i32
    %21 = spirv.Select %18, %19, %20 : i1, i32
    %22 = spirv.SDiv %21, %cst64_i32 : i32
    %23 = spirv.ISub %cst0_i32, %22 : i32
    %24 = spirv.IAdd %22, %cst1_i32 : i32
    %25 = spirv.Select %18, %23, %24 : i1, i32
    %26 = spirv.IMul %5, %25 : i32
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %27 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %28 = spirv.CompositeExtract %27[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %29 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %30 = spirv.CompositeExtract %29[0 : i32] : vector<3xi32>
    spirv.mlir.loop {
      spirv.Branch ^bb1(%28 : i32)
    ^bb1(%31: i32):  // 2 preds: ^bb0, ^bb2
      %32 = spirv.SLessThan %31, %26 : i32
      spirv.BranchConditional %32, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %33 = spirv.SDiv %31, %25 : i32
      %34 = spirv.IMul %33, %25 : i32
      %35 = spirv.INotEqual %31, %34 : i32
      %36 = spirv.SLessThan %31, %cst0_i32 : i32
      %37 = spirv.SLessThan %25, %cst0_i32 : i32
      %38 = spirv.LogicalNotEqual %36, %37 : i1
      %39 = spirv.LogicalAnd %35, %38 : i1
      %40 = spirv.IAdd %33, %cst-1_i32 : i32
      %41 = spirv.Select %39, %40, %33 : i1, i32
      %42 = spirv.GL.SAbs %31 : i32
      %43 = spirv.GL.SAbs %25 : i32
      %44 = spirv.UMod %42, %43 : i32
      %45 = spirv.IEqual %31, %42 : i32
      %46 = spirv.SNegate %44 : i32
      %47 = spirv.Select %45, %44, %46 : i1, i32
      %48 = spirv.SLessThan %47, %cst0_i32 : i32
      %49 = spirv.IAdd %47, %25 : i32
      %50 = spirv.Select %48, %49, %47 : i1, i32
      %51 = spirv.IMul %50, %cst-64_i32 : i32
      %52 = spirv.IAdd %51, %9 : i32
      %53 = spirv.GL.SMin %52, %cst64_i32 : i32
      %54 = spirv.SGreaterThan %53, %17 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %54, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %56 = spirv.IMul %50, %cst64_i32 : i32
        %57 = spirv.IAdd %56, %3 : i32
        %58 = spirv.IAdd %57, %17 : i32
        %59 = spirv.IMul %41, %7 : i32
        %60 = spirv.IAdd %58, %59 : i32
        %61 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %60] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %62 = spirv.Load "StorageBuffer" %61 : f32
        %63 = spirv.IAdd %56, %15 : i32
        %64 = spirv.IMul %41, %9 : i32
        %65 = spirv.IAdd %63, %64 : i32
        %66 = spirv.IAdd %65, %17 : i32
        %67 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %66] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %67, %62 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %55 = spirv.IAdd %31, %30 : i32
      spirv.Branch ^bb1(%55 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_linear_as_stored_f32_dispatch_0_slow_memcpy, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_linear_as_stored_f32_dispatch_0_slow_memcpy "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_linear_as_stored_f32_dispatch_0_slow_memcpy "SignedZeroInfNanPreserve", 32
}