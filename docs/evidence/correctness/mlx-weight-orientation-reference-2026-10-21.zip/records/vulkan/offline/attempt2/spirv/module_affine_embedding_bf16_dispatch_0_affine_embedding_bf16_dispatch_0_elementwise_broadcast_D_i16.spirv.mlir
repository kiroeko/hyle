spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.func @affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst17_i32 = spirv.Constant 17 : i32
    %cst15_i32 = spirv.Constant 15 : i32
    %cst13_i32 = spirv.Constant 13 : i32
    %cst11_i32 = spirv.Constant 11 : i32
    %cst9_i32 = spirv.Constant 9 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst32704_i16 = spirv.Constant 32704 : i16
    %cst32767_i32 = spirv.Constant 32767 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst32_i32 = spirv.Constant 32 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst31_i32 = spirv.Constant 31 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst7_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst9_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst11_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst13_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst15_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %18 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst17_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<19 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %19 = spirv.Load "PushConstant" %18 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %20 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %21 = spirv.CompositeExtract %20[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %22 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %23 = spirv.CompositeExtract %22[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %24 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %25 = spirv.CompositeExtract %24[0 : i32] : vector<3xi32>
    %26 = spirv.IMul %23, %cst64_i32 : i32
    %27 = spirv.IMul %25, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%26 : i32)
    ^bb1(%28: i32):  // 2 preds: ^bb0, ^bb2
      %29 = spirv.SLessThan %28, %1 : i32
      spirv.BranchConditional %29, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %30 = spirv.ISub %1, %28 : i32
      %31 = spirv.GL.SMin %30, %cst64_i32 : i32
      %32 = spirv.SGreaterThan %31, %21 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %32, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %34 = spirv.IAdd %28, %21 : i32
        %35 = spirv.GL.SAbs %34 : i32
        %36 = spirv.GL.SAbs %3 : i32
        %37 = spirv.UMod %35, %36 : i32
        %38 = spirv.IEqual %34, %35 : i32
        %39 = spirv.SNegate %37 : i32
        %40 = spirv.Select %38, %37, %39 : i1, i32
        %41 = spirv.SDiv %34, %3 : i32
        %42 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %41] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %43 = spirv.Load "StorageBuffer" %42 : i32
        %44 = spirv.UDiv %40, %cst32_i32 : i32
        %45 = spirv.UMod %40, %cst32_i32 : i32
        %46 = spirv.IMul %44, %5 : i32
        %47 = spirv.IMul %45, %5 : i32
        %48 = spirv.UDiv %47, %cst32_i32 : i32
        %49 = spirv.IAdd %46, %48 : i32
        %50 = spirv.UMod %47, %cst32_i32 : i32
        %51 = spirv.IAdd %50, %5 : i32
        %52 = spirv.UGreaterThan %51, %cst32_i32 : i32
        %53 = spirv.IAdd %49, %cst1_i32 : i32
        %54 = spirv.Select %52, %53, %49 : i1, i32
        %55 = spirv.IMul %43, %15 : i32
        %56 = spirv.IAdd %55, %49 : i32
        %57 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %56] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %58 = spirv.Load "StorageBuffer" %57 : i32
        %59 = spirv.IAdd %55, %54 : i32
        %60 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %59] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %61 = spirv.Load "StorageBuffer" %60 : i32
        %62 = spirv.ShiftRightLogical %58, %50 : i32, i32
        %63 = spirv.ISub %cst32_i32, %50 : i32
        %64 = spirv.BitwiseAnd %63, %cst31_i32 : i32
        %65 = spirv.ShiftLeftLogical %61, %64 : i32, i32
        %66 = spirv.Select %52, %65, %cst0_i32 : i1, i32
        %67 = spirv.BitwiseOr %62, %66 : i32
        %68 = spirv.BitwiseAnd %67, %7 : i32
        %69 = spirv.ConvertUToF %68 : i32 to f32
        %70 = spirv.UDiv %40, %9 : i32
        %71 = spirv.IMul %43, %19 : i32
        %72 = spirv.IAdd %71, %70 : i32
        %73 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %72] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %74 = spirv.Load "StorageBuffer" %73 : i16
        %75 = spirv.UConvert %74 : i16 to i32
        %76 = spirv.ShiftLeftLogical %75, %cst16_i32 : i32, i32
        %77 = spirv.Bitcast %76 : i32 to f32
        %78 = spirv.FMul %69, %77 : f32
        %79 = spirv.FUnordNotEqual %78, %78 : f32
        %80 = spirv.Bitcast %78 : f32 to i32
        %81 = spirv.ShiftRightLogical %80, %cst16_i32 : i32, i32
        %82 = spirv.BitwiseAnd %81, %cst1_i32 : i32
        %83 = spirv.IAdd %82, %cst32767_i32 : i32
        %84 = spirv.IAdd %80, %83 : i32
        %85 = spirv.ShiftRightLogical %84, %cst16_i32 : i32, i32
        %86 = spirv.SConvert %85 : i32 to i16
        %87 = spirv.Select %79, %cst32704_i16, %86 : i1, i16
        %88 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        spirv.Store "StorageBuffer" %88, %87 : i16
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %33 = spirv.IAdd %28, %27 : i32
      spirv.Branch ^bb1(%33 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16 "SignedZeroInfNanPreserve", 32
}