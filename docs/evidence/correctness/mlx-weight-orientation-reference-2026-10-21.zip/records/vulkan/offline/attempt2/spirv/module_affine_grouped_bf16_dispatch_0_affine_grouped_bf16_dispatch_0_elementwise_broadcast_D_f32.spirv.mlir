spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_16bit_storage, SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_grouped_bf16_dispatch_0_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %true = spirv.Constant true
    %false = spirv.Constant false
    %cst1_i32 = spirv.Constant 1 : i32
    %cst13_i32 = spirv.Constant 13 : i32
    %cst11_i32 = spirv.Constant 11 : i32
    %cst9_i32 = spirv.Constant 9 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst9_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst11_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst13_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<15 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.BitwiseAnd %9, %cst1_i32 : i32
    %17 = spirv.IEqual %16, %cst1_i32 : i32
    %18 = spirv.Select %17, %true, %false : i1, i1
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %19 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %20 = spirv.CompositeExtract %19[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %21 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %22 = spirv.CompositeExtract %21[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %23 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %24 = spirv.CompositeExtract %23[0 : i32] : vector<3xi32>
    %25 = spirv.IMul %22, %cst64_i32 : i32
    %26 = spirv.IMul %24, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%25 : i32)
    ^bb1(%27: i32):  // 2 preds: ^bb0, ^bb2
      %28 = spirv.SLessThan %27, %1 : i32
      spirv.BranchConditional %28, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %29 = spirv.ISub %1, %27 : i32
      %30 = spirv.GL.SMin %29, %cst64_i32 : i32
      %31 = spirv.SGreaterThan %30, %20 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %31, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %33 = spirv.IAdd %27, %20 : i32
        %34 = spirv.GL.SAbs %33 : i32
        %35 = spirv.GL.SAbs %3 : i32
        %36 = spirv.UMod %34, %35 : i32
        %37 = spirv.IEqual %33, %34 : i32
        %38 = spirv.SNegate %36 : i32
        %39 = spirv.Select %37, %36, %38 : i1, i32
        %40 = spirv.SDiv %33, %3 : i32
        %41 = spirv.IAdd %5, %39 : i32
        %42 = spirv.UDiv %40, %7 : i32
        %43 = spirv.UMod %40, %7 : i32
        %44 = spirv.Select %18, %cst0_i32, %43 : i1, i32
        %45 = spirv.IMul %42, %11 : i32
        %46 = spirv.IMul %44, %13 : i32
        %47 = spirv.IAdd %45, %46 : i32
        %48 = spirv.IAdd %47, %41 : i32
        %49 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %48] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %50 = spirv.Load "StorageBuffer" %49 : i16
        %51 = spirv.UConvert %50 : i16 to i32
        %52 = spirv.ShiftLeftLogical %51, %cst16_i32 : i32, i32
        %53 = spirv.Bitcast %52 : i32 to f32
        %54 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %33] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %54, %53 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %32 = spirv.IAdd %27, %26 : i32
      spirv.Branch ^bb1(%32 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_grouped_bf16_dispatch_0_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_grouped_bf16_dispatch_0_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_grouped_bf16_dispatch_0_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}