spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_linear_as_stored_f32_bf16_dispatch_2_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst30_i32 = spirv.Constant 30 : i32
    %cst28_i32 = spirv.Constant 28 : i32
    %cst26_i32 = spirv.Constant 26 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst22_i32 = spirv.Constant 22 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst18_i32 = spirv.Constant 18 : i32
    %cst14_i32 = spirv.Constant 14 : i32
    %cst13_i32 = spirv.Constant 13 : i32
    %cst11_i32 = spirv.Constant 11 : i32
    %cst9_i32 = spirv.Constant 9 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst5_i32 = spirv.Constant 5 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst32_i32 = spirv.Constant 32 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst31_i32 = spirv.Constant 31 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst5_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst7_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst9_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst11_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst13_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst14_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %18 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst16_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %19 = spirv.Load "PushConstant" %18 : i32
    %20 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst18_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %21 = spirv.Load "PushConstant" %20 : i32
    %22 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst20_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %23 = spirv.Load "PushConstant" %22 : i32
    %24 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst22_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %25 = spirv.Load "PushConstant" %24 : i32
    %26 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst24_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %27 = spirv.Load "PushConstant" %26 : i32
    %28 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst26_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %29 = spirv.Load "PushConstant" %28 : i32
    %30 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst28_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %31 = spirv.Load "PushConstant" %30 : i32
    %32 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst30_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %33 = spirv.Load "PushConstant" %32 : i32
    %34 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst32_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<34 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %35 = spirv.Load "PushConstant" %34 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %36 = spirv.SLessThan %1, %cst0_i32 : i32
    %37 = spirv.ISub %cst-1_i32, %1 : i32
    %38 = spirv.Select %36, %37, %1 : i1, i32
    %39 = spirv.SDiv %38, %cst4_i32 : i32
    %40 = spirv.ISub %cst-1_i32, %39 : i32
    %41 = spirv.Select %36, %40, %39 : i1, i32
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %42 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %43 = spirv.CompositeExtract %42[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %44 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %45 = spirv.CompositeExtract %44[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %46 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %47 = spirv.CompositeExtract %46[0 : i32] : vector<3xi32>
    %48 = spirv.IMul %45, %cst64_i32 : i32
    %49 = spirv.IMul %47, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%48 : i32)
    ^bb1(%50: i32):  // 2 preds: ^bb0, ^bb2
      %51 = spirv.SLessThan %50, %3 : i32
      spirv.BranchConditional %51, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %52 = spirv.ISub %3, %50 : i32
      %53 = spirv.GL.SMin %52, %cst64_i32 : i32
      %54 = spirv.SGreaterThan %53, %43 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %54, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %56 = spirv.IAdd %50, %43 : i32
        %57 = spirv.GL.SAbs %56 : i32
        %58 = spirv.GL.SAbs %5 : i32
        %59 = spirv.UMod %57, %58 : i32
        %60 = spirv.IEqual %56, %57 : i32
        %61 = spirv.SNegate %59 : i32
        %62 = spirv.Select %60, %59, %61 : i1, i32
        %63 = spirv.SDiv %56, %5 : i32
        %64 = spirv.GL.SAbs %63 : i32
        %65 = spirv.GL.SAbs %7 : i32
        %66 = spirv.UMod %64, %65 : i32
        %67 = spirv.IEqual %63, %64 : i32
        %68 = spirv.SNegate %66 : i32
        %69 = spirv.Select %67, %66, %68 : i1, i32
        %70 = spirv.IAdd %9, %62 : i32
        %71 = spirv.IAdd %11, %69 : i32
        %72 = spirv.UDiv %71, %cst32_i32 : i32
        %73 = spirv.UMod %71, %cst32_i32 : i32
        %74 = spirv.IMul %72, %13 : i32
        %75 = spirv.IMul %73, %13 : i32
        %76 = spirv.UDiv %75, %cst32_i32 : i32
        %77 = spirv.IAdd %74, %76 : i32
        %78 = spirv.UMod %75, %cst32_i32 : i32
        %79 = spirv.IAdd %78, %13 : i32
        %80 = spirv.UGreaterThan %79, %cst32_i32 : i32
        %81 = spirv.IAdd %77, %cst1_i32 : i32
        %82 = spirv.Select %80, %81, %77 : i1, i32
        %83 = spirv.IMul %70, %23 : i32
        %84 = spirv.IAdd %83, %77 : i32
        %85 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %84] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %86 = spirv.Load "StorageBuffer" %85 : i32
        %87 = spirv.IAdd %83, %82 : i32
        %88 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %87] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %89 = spirv.Load "StorageBuffer" %88 : i32
        %90 = spirv.ShiftRightLogical %86, %78 : i32, i32
        %91 = spirv.ISub %cst32_i32, %78 : i32
        %92 = spirv.BitwiseAnd %91, %cst31_i32 : i32
        %93 = spirv.ShiftLeftLogical %89, %92 : i32, i32
        %94 = spirv.Select %80, %93, %cst0_i32 : i1, i32
        %95 = spirv.BitwiseOr %90, %94 : i32
        %96 = spirv.BitwiseAnd %95, %15 : i32
        %97 = spirv.ConvertUToF %96 : i32 to f32
        %98 = spirv.IMul %70, %29 : i32
        %99 = spirv.IAdd %98, %17 : i32
        %100 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %99] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %101 = spirv.Load "StorageBuffer" %100 : i16
        %102 = spirv.IMul %70, %35 : i32
        %103 = spirv.IAdd %102, %17 : i32
        %104 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %103] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %105 = spirv.Load "StorageBuffer" %104 : i16
        %106 = spirv.UConvert %101 : i16 to i32
        %107 = spirv.ShiftLeftLogical %106, %cst16_i32 : i32, i32
        %108 = spirv.Bitcast %107 : i32 to f32
        %109 = spirv.UConvert %105 : i16 to i32
        %110 = spirv.ShiftLeftLogical %109, %cst16_i32 : i32, i32
        %111 = spirv.Bitcast %110 : i32 to f32
        %112 = spirv.FMul %97, %108 : f32
        %113 = spirv.FAdd %112, %111 : f32
        %114 = spirv.IAdd %56, %41 : i32
        %115 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %114] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %115, %113 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %55 = spirv.IAdd %50, %49 : i32
      spirv.Branch ^bb1(%55 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_linear_as_stored_f32_bf16_dispatch_2_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_linear_as_stored_f32_bf16_dispatch_2_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_linear_as_stored_f32_bf16_dispatch_2_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}