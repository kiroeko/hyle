spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst12_i32 = spirv.Constant 12 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst_f32 = spirv.Constant 0.001953125 : f32
    %cst31_i32 = spirv.Constant 31 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2143289344_i32 = spirv.Constant 2143289344 : i32
    %cst15_i32 = spirv.Constant 15 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst120_i32 = spirv.Constant 120 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst_f32_0 = spirv.Constant 0x7FC00000 : f32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst127_i32 = spirv.Constant 127 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst12_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<14 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %14 = spirv.SLessThan %1, %cst0_i32 : i32
    %15 = spirv.ISub %cst-1_i32, %1 : i32
    %16 = spirv.Select %14, %15, %1 : i1, i32
    %17 = spirv.SDiv %16, %cst4_i32 : i32
    %18 = spirv.ISub %cst-1_i32, %17 : i32
    %19 = spirv.Select %14, %18, %17 : i1, i32
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %20 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %21 = spirv.CompositeExtract %20[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %22 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %23 = spirv.CompositeExtract %22[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %24 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %25 = spirv.CompositeExtract %24[0 : i32] : vector<3xi32>
    %26 = spirv.IMul %23, %cst64_i32 : i32
    %27 = spirv.IMul %25, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%26 : i32)
    ^bb1(%28: i32):  // 2 preds: ^bb0, ^bb2
      %29 = spirv.SLessThan %28, %3 : i32
      spirv.BranchConditional %29, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %30 = spirv.ISub %3, %28 : i32
      %31 = spirv.GL.SMin %30, %cst64_i32 : i32
      %32 = spirv.SGreaterThan %31, %21 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %32, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %34 = spirv.IAdd %28, %21 : i32
        %35 = spirv.GL.SAbs %34 : i32
        %36 = spirv.GL.SAbs %5 : i32
        %37 = spirv.UMod %35, %36 : i32
        %38 = spirv.IEqual %34, %35 : i32
        %39 = spirv.SNegate %37 : i32
        %40 = spirv.Select %38, %37, %39 : i1, i32
        %41 = spirv.SDiv %34, %5 : i32
        %42 = spirv.GL.SAbs %41 : i32
        %43 = spirv.GL.SAbs %11 : i32
        %44 = spirv.UMod %42, %43 : i32
        %45 = spirv.IEqual %41, %42 : i32
        %46 = spirv.SNegate %44 : i32
        %47 = spirv.Select %45, %44, %46 : i1, i32
        %48 = spirv.IAdd %7, %40 : i32
        %49 = spirv.UDiv %48, %cst4_i32 : i32
        %50 = spirv.UMod %48, %cst4_i32 : i32
        %51 = spirv.IMul %50, %cst8_i32 : i32
        %52 = spirv.IMul %47, %13 : i32
        %53 = spirv.IAdd %52, %49 : i32
        %54 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %53] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %55 = spirv.Load "StorageBuffer" %54 : i32
        %56 = spirv.ShiftRightLogical %55, %51 : i32, i32
        %57 = spirv.BitwiseAnd %56, %cst255_i32 : i32
        %58 = spirv.BitwiseAnd %57, %cst255_i32 : i32
        %59 = spirv.BitwiseAnd %58, %cst255_i32 : i32
        %60 = spirv.ShiftRightLogical %59, %cst7_i32 : i32, i32
        %61 = spirv.ShiftRightLogical %59, %cst3_i32 : i32, i32
        %62 = spirv.BitwiseAnd %61, %cst15_i32 : i32
        %63 = spirv.BitwiseAnd %59, %cst7_i32 : i32
        %64 = spirv.ShiftLeftLogical %60, %cst31_i32 : i32, i32
        %65 = spirv.IEqual %63, %cst0_i32 : i32
        %66 = spirv.INotEqual %63, %cst0_i32 : i32
        %67 = spirv.IEqual %59, %cst127_i32 : i32
        %68 = spirv.IEqual %62, %cst0_i32 : i32
        %69 = spirv.LogicalAnd %68, %65 : i1
        %70 = spirv.LogicalAnd %68, %66 : i1
        %71 = spirv.IAdd %62, %cst120_i32 : i32
        %72 = spirv.ShiftLeftLogical %63, %cst20_i32 : i32, i32
        %73 = spirv.ShiftLeftLogical %71, %cst23_i32 : i32, i32
        %74 = spirv.BitwiseOr %73, %72 : i32
        %75 = spirv.BitwiseOr %64, %74 : i32
        %76 = spirv.ConvertUToF %63 : i32 to f32
        %77 = spirv.FMul %76, %cst_f32 : f32
        %78 = spirv.Bitcast %77 : f32 to i32
        %79 = spirv.BitwiseOr %64, %78 : i32
        %80 = spirv.Select %70, %79, %75 : i1, i32
        %81 = spirv.Select %69, %64, %80 : i1, i32
        %82 = spirv.Select %67, %cst2143289344_i32, %81 : i1, i32
        %83 = spirv.Bitcast %82 : i32 to f32
        %84 = spirv.BitwiseAnd %56, %cst127_i32 : i32
        %85 = spirv.IEqual %84, %cst127_i32 : i32
        %86 = spirv.Select %85, %cst_f32_0, %83 : i1, f32
        %87 = spirv.IAdd %34, %19 : i32
        %88 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %87] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %88, %86 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %33 = spirv.IAdd %28, %27 : i32
      spirv.Branch ^bb1(%33 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}