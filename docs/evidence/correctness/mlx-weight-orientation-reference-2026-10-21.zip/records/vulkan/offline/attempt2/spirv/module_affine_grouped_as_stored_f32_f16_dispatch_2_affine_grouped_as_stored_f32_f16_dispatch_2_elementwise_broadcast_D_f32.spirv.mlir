spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Float16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_4_ bind(0, 4) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @affine_grouped_as_stored_f32_f16_dispatch_2_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst34_i32 = spirv.Constant 34 : i32
    %cst30_i32 = spirv.Constant 30 : i32
    %cst28_i32 = spirv.Constant 28 : i32
    %cst26_i32 = spirv.Constant 26 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst22_i32 = spirv.Constant 22 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst18_i32 = spirv.Constant 18 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst14_i32 = spirv.Constant 14 : i32
    %cst13_i32 = spirv.Constant 13 : i32
    %cst11_i32 = spirv.Constant 11 : i32
    %cst9_i32 = spirv.Constant 9 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst5_i32 = spirv.Constant 5 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst32_i32 = spirv.Constant 32 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst31_i32 = spirv.Constant 31 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst5_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst7_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst9_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst11_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst13_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst14_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %18 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst16_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %19 = spirv.Load "PushConstant" %18 : i32
    %20 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst18_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %21 = spirv.Load "PushConstant" %20 : i32
    %22 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst20_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %23 = spirv.Load "PushConstant" %22 : i32
    %24 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst22_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %25 = spirv.Load "PushConstant" %24 : i32
    %26 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst24_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %27 = spirv.Load "PushConstant" %26 : i32
    %28 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst26_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %29 = spirv.Load "PushConstant" %28 : i32
    %30 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst28_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %31 = spirv.Load "PushConstant" %30 : i32
    %32 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst30_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %33 = spirv.Load "PushConstant" %32 : i32
    %34 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst32_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %35 = spirv.Load "PushConstant" %34 : i32
    %36 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst34_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<36 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %37 = spirv.Load "PushConstant" %36 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
    %38 = spirv.SLessThan %1, %cst0_i32 : i32
    %39 = spirv.ISub %cst-1_i32, %1 : i32
    %40 = spirv.Select %38, %39, %1 : i1, i32
    %41 = spirv.SDiv %40, %cst4_i32 : i32
    %42 = spirv.ISub %cst-1_i32, %41 : i32
    %43 = spirv.Select %38, %42, %41 : i1, i32
    %__resource_var_0_4__addr = spirv.mlir.addressof @__resource_var_0_4_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %44 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %45 = spirv.CompositeExtract %44[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %46 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %47 = spirv.CompositeExtract %46[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %48 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %49 = spirv.CompositeExtract %48[0 : i32] : vector<3xi32>
    %50 = spirv.IMul %47, %cst64_i32 : i32
    %51 = spirv.IMul %49, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%50 : i32)
    ^bb1(%52: i32):  // 2 preds: ^bb0, ^bb2
      %53 = spirv.SLessThan %52, %3 : i32
      spirv.BranchConditional %53, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %54 = spirv.ISub %3, %52 : i32
      %55 = spirv.GL.SMin %54, %cst64_i32 : i32
      %56 = spirv.SGreaterThan %55, %45 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %56, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %58 = spirv.IAdd %52, %45 : i32
        %59 = spirv.GL.SAbs %58 : i32
        %60 = spirv.GL.SAbs %5 : i32
        %61 = spirv.UMod %59, %60 : i32
        %62 = spirv.IEqual %58, %59 : i32
        %63 = spirv.SNegate %61 : i32
        %64 = spirv.Select %62, %61, %63 : i1, i32
        %65 = spirv.SDiv %58, %5 : i32
        %66 = spirv.GL.SAbs %65 : i32
        %67 = spirv.GL.SAbs %7 : i32
        %68 = spirv.UMod %66, %67 : i32
        %69 = spirv.IEqual %65, %66 : i32
        %70 = spirv.SNegate %68 : i32
        %71 = spirv.Select %69, %68, %70 : i1, i32
        %72 = spirv.SDiv %65, %7 : i32
        %73 = spirv.IAdd %9, %64 : i32
        %74 = spirv.IAdd %11, %71 : i32
        %75 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %72] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %76 = spirv.Load "StorageBuffer" %75 : i32
        %77 = spirv.UDiv %74, %cst32_i32 : i32
        %78 = spirv.UMod %74, %cst32_i32 : i32
        %79 = spirv.IMul %77, %13 : i32
        %80 = spirv.IMul %78, %13 : i32
        %81 = spirv.UDiv %80, %cst32_i32 : i32
        %82 = spirv.IAdd %79, %81 : i32
        %83 = spirv.UMod %80, %cst32_i32 : i32
        %84 = spirv.IAdd %83, %13 : i32
        %85 = spirv.UGreaterThan %84, %cst32_i32 : i32
        %86 = spirv.IAdd %82, %cst1_i32 : i32
        %87 = spirv.Select %85, %86, %82 : i1, i32
        %88 = spirv.IMul %76, %23 : i32
        %89 = spirv.IAdd %73, %88 : i32
        %90 = spirv.IMul %89, %25 : i32
        %91 = spirv.IAdd %82, %90 : i32
        %92 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %91] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %93 = spirv.Load "StorageBuffer" %92 : i32
        %94 = spirv.IAdd %87, %90 : i32
        %95 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %94] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %96 = spirv.Load "StorageBuffer" %95 : i32
        %97 = spirv.ShiftRightLogical %93, %83 : i32, i32
        %98 = spirv.ISub %cst32_i32, %83 : i32
        %99 = spirv.BitwiseAnd %98, %cst31_i32 : i32
        %100 = spirv.ShiftLeftLogical %96, %99 : i32, i32
        %101 = spirv.Select %85, %100, %cst0_i32 : i1, i32
        %102 = spirv.BitwiseOr %97, %101 : i32
        %103 = spirv.BitwiseAnd %102, %15 : i32
        %104 = spirv.ConvertUToF %103 : i32 to f32
        %105 = spirv.IMul %76, %29 : i32
        %106 = spirv.IAdd %73, %105 : i32
        %107 = spirv.IMul %106, %31 : i32
        %108 = spirv.IAdd %17, %107 : i32
        %109 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %108] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f16, StorageBuffer>
        %110 = spirv.Load "StorageBuffer" %109 : f16
        %111 = spirv.IMul %76, %35 : i32
        %112 = spirv.IAdd %73, %111 : i32
        %113 = spirv.IMul %112, %37 : i32
        %114 = spirv.IAdd %17, %113 : i32
        %115 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %114] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f16, StorageBuffer>
        %116 = spirv.Load "StorageBuffer" %115 : f16
        %117 = spirv.FConvert %110 : f16 to f32
        %118 = spirv.FConvert %116 : f16 to f32
        %119 = spirv.FMul %104, %117 : f32
        %120 = spirv.FAdd %119, %118 : f32
        %121 = spirv.IAdd %58, %43 : i32
        %122 = spirv.AccessChain %__resource_var_0_4__addr[%cst0_i32, %121] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %122, %120 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %57 = spirv.IAdd %52, %51 : i32
      spirv.Branch ^bb1(%57 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @affine_grouped_as_stored_f32_f16_dispatch_2_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @affine_grouped_as_stored_f32_f16_dispatch_2_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @affine_grouped_as_stored_f32_f16_dispatch_2_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}