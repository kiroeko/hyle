from pathlib import Path
import copy
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
NAME = 'docs/implementation/model-quantizations.json'
EVIDENCE = 'docs/evidence/correctness/mlx-weight-orientation-reference-2026-10-21.json'
INDICES = [4, 5, 11, 12, 31, 32]
before = (S/'before'/NAME).read_bytes()
assert (ROOT/NAME).read_bytes() == before, 'Canonical changed after snapshot'
old = json.loads(before)
data = copy.deepcopy(old)

for index in INDICES:
    coverage = data['artifacts'][index]['provider_coverage']
    coverage['weight_orientation_reference'] = {
        'observed_on': '2026-10-21',
        'evidence': EVIDENCE,
        'operation': 'MlxQuantized revision3: MlxMatmulOrientation{kTransposeWeight,kWeightAsStored}; linear/grouped factory final parameter, default kTransposeWeight',
        'contract': 'Affine4/5/6/8, physical K groups32/64/128. Original packed W[N,K] or W[E,N,K] and SF/bias axes do not change; default A[...,K] -> Y[...,N], AsStored A[...,N] -> Y[...,K]. N need not be a complete quantization group. AsStored is rejected for embedding/MX formats and unknown enum values.',
        'execution': 'F32 pointwise affine multiply then add, F32 dot/accumulation and unchanged same/mixed-source output promotion; no scale hoist or whole NK/ENK floating bank. Grouped shared/independent/zero-slot A and full checked IDs use the original execution and resource system.',
        'validation_scope': 'Finite software reference and original-default neighbors; actual passed/pending backend windows are in the batch followup below, not a claim of complete artifact execution.',
        'artifact_execution_verified': False
    }

head = data['artifacts'][31]['provider_coverage']
head['mapping_status'] = (
    'Stored affine4 g64 U32/BF16 triples fit the existing codec and scale-type domains. '
    'The 156 attention head-bank triples are 78 embed_q plus 78 unembed_out with 64 heads, not MoE experts. '
    'The missing non-transposed packed-W interface is implemented without changing the physical bank. '
    'A same-bank synthetic H64/N512/K192 BF16 graph now checks both decode/prefill directions, padded query slice Copy '
    'and restored head order under the declared Hyle F32-affine reference in the passed backend windows. '
    'Original artifact payload, the separate unembed_out role and native low-type MLX bitwise equivalence remain unexecuted/unqualified.'
)
head['role_domains'][0]['observed'] = head['mapping_status']
head['role_domains'][0]['followup_evidence'] = EVIDENCE
remaining = [
    'Bind original catalog31 packed W/SF/bias payload and qualify the actual head consumer. The same-bank H64/N512/K192 BF16 synthetic decode/prefill reference repairs the interface gap but does not execute checkpoint payload.',
    'The separate unembed_out W[64,256,512] role and whole MLA/attention composition are not signed by this same-bank projection graph; preserve exact head order and surrounding operations in that consumer.',
    'Native same-low-type MLX QMM tile arithmetic and original exporter identity are not signed as equivalent to the declared Hyle F32 affine decode/dot reference.',
    'No whole-artifact or Linux execution, quality, throughput or peak-memory acceptance.'
]
head['artifact_unaligned_or_unverified'] = copy.deepcopy(remaining)
head['missing_capabilities'] = copy.deepcopy(remaining)
head['role_domains'][0]['unresolved'] = copy.deepcopy(remaining)
head['weight_orientation_reference']['head_role'] = (
    'Synthetic original-shape affine4/g64 W[64,512,24]U32 and BF16 SF/bias[64,512,3] are shared by both orientations. '
    'Identity head IDs preserve all64 heads; BF16 query K192 is sliced from a256-wide backing and explicitly copied, '
    'while BF16 latent N512 uses shared A for AsStored prefill. Original Graph outputs/slots and constants retain their ownership lifetimes. '
    'This is not the GLM32 default F16-metadata mixed-type role.'
)
prior = head.get('precise_role_consumer_reference', {})
if 'head_bank_source_review' in prior:
    prior['head_bank_source_review'] = prior['head_bank_source_review'].replace(
        'Source review only, no head-role execution or original exporter-version identity claim.',
        'That earlier evidence is source review only; the subsequent same-bank synthetic execution is recorded in weight_orientation_reference. Original exporter-version identity and artifact payload remain unqualified.')

data['followup_reviews'].append({
    'observed_on': '2026-10-21',
    'evidence': EVIDENCE,
    'artifact_indices': INDICES,
    'scope': 'Generic affine packed weight orientation interface and bounded CPU/CUDA/Apple reference, including original-shape catalog31 H64/N512/K192 BF16 decode/prefill geometry. The new orientation is a primitive capability for the other MLX descriptor domains, not proof that their exact stored roles require or execute it.',
    'partial_backend_snapshot': True,
    'backend_validation': {
        'CPU': {'status': 'passed', 'cases': 13, 'skipped': 0, 'scope': 'New ordinary orientation consumers, one orientation schema case and current MLX Graph neighbors'},
        'CUDA': {'status': 'passed', 'cases': 3, 'skipped': 0, 'scope': 'Three new ordinary consumers with strict RequireCapture and actual captured route; retained initial capture-property rejection'},
        'Apple': {'status': 'passed', 'cases': 7, 'skipped': 0, 'scope': 'Three new orientation consumers and four original MLX/ordinary-MoE neighbors'},
        'Vulkan': {'status': 'pending', 'reason': 'Typed-output issue under correction/retest; no final successful window claimed by this snapshot'}
    },
    'new_successful_submissions_per_executed_backend': 35,
    'new_expected_failed_completions_per_executed_backend': 2,
    'limits': 'All33 artifact_execution_verified remain false. Synthetic primitive/role geometry, not original numeric payload, whole GLM attention/model, GLM32 F16-metadata producer consumer, native low-type MLX bitwise equivalence, Linux, quality, performance or peak-memory acceptance.'
})

changed = [i for i, (a, b) in enumerate(zip(old['artifacts'], data['artifacts'])) if a != b]
assert changed == INDICES, changed
for index in changed:
    a = copy.deepcopy(old['artifacts'][index])
    b = copy.deepcopy(data['artifacts'][index])
    a.pop('provider_coverage'); b.pop('provider_coverage')
    assert a == b
    previous = old['artifacts'][index]['provider_coverage']
    current = data['artifacts'][index]['provider_coverage']
    for key in ('metadata_sources', 'required_format_domain', 'fixed_source_role_binding', 'reachable_entry_points'):
        assert previous.get(key) == current.get(key), (index, key)
for key in old:
    if key not in ('artifacts', 'followup_reviews'):
        assert data[key] == old[key]
assert data['followup_reviews'][:-1] == old['followup_reviews']
assert len(data['artifacts']) == 33
assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in data['artifacts'])
after = (json.dumps(data, ensure_ascii=False, indent=2)+'\n').replace('\n', '\r\n').encode('utf-8')
(ROOT/NAME).write_bytes(after)
target = S/'after'/NAME
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(after)
(S/'implementation.diff').write_text(''.join(difflib.unified_diff(
    before.decode().splitlines(True), after.decode().splitlines(True),
    fromfile='before/'+NAME, tofile='after/'+NAME)), encoding='utf-8', newline='')
identity = {'path': NAME, 'bytes': len(after), 'sha256': hashlib.sha256(after).hexdigest()}
validation = {
    'status': 'documentation_only_partial_backend_snapshot_applied',
    'changed_artifact_indices': changed,
    'changed_artifact_fields': 'provider_coverage only; shared orientation reference on six MLX artifacts, precise catalog31 role status',
    'unchanged_metadata_and_source_role_facts': True,
    'unchanged_reachable_entry_point_history': True,
    'prior_followups_unchanged': True,
    'followup_review_count': len(data['followup_reviews']),
    'all33_artifact_execution_verified_false': True,
    'CRLF_preserved': after.count(b'\n') == after.count(b'\r\n'),
    'no_product_build_GPU_or_other_docs_changes': True,
    'evidence_publication_owned_by_root': EVIDENCE,
    'source': identity
}
(S/'validation.json').write_text(json.dumps(validation, indent=2)+'\n', encoding='utf-8')
(S/'source-freeze.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')
print(json.dumps(validation, indent=2))
