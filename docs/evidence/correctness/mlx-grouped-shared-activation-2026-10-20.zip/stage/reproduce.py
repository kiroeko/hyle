"""Compile the frozen pre-change inference source and prove the missing modes."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=load('mlx_shared_red_helpers',A/'projected-bind-cold-index/build.py');b,c=h.b,h.c
metadata=load('mlx_shared_red_metadata',A/'grouped-shared-activation/build_host.py').metadata
def main():
    out=S/'reproduction';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    base=c.read(A/'batch-output-tail/checks/cpu-link-plan.json')
    owners=metadata({'cpu':base})
    candidates=[(row,owners[c.key(row['path'])]) for row in base['inputs'] if c.key(row['path']) in owners and
        c.key(owners[c.key(row['path'])]['source_path'])==c.key(ROOT/'src/compute_ops/weight_decode.cc')]
    assert len(candidates)==1,len(candidates)
    old,owner=candidates[0]
    source=S/'before/src/compute_ops/weight_decode.cc'
    wanted=next(row for row in c.read(S/'design.json')['before'] if row['path']=='src/compute_ops/weight_decode.cc')
    assert b.identity(source)['sha256']==wanted['sha256']
    recipes=[('frozen-before',source,owner['command']),
        ('shared-probe',S/'reproduction_test.cc',c.read(A/'batch-output-tail/checks/typed-test-identity.json')['command'])]
    for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(base['command'],[row['path'] for row in base['inputs']],out)
    objects=[]
    for tag,path,recipe in recipes:
        command=b.host_command(recipe,path,tag,out);c.execute(tag+'-compile',command,env,out)
        data=c.read(out/(tag+'-deps.json'))['Data'];obj=b.identity(out/(tag+'.obj'));objects.append(obj)
        c.save(out/(tag+'-identity.json'),dict(command=command,source=b.identity(path),object=obj,
            dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]))
    lookup={c.key(row['path']):row for row in [*base['inputs'],*objects]}
    command=[objects[0]['path'] if c.key(arg)==c.key(old['path']) else arg for arg in base['command']
        if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    image=out/'tests.exe';command += [objects[1]['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
    for row in inputs:assert b.same(row)
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs));c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    try:c.execute('tests',[str(image),'--gtest_filter=MlxSharedActivationAdmission.*','--gtest_output=xml:'+str(out/'results.xml')],env,out)
    except RuntimeError:assert c.read(out/'tests.result.json')['exit']==1
    cases=ET.parse(out/'results.xml').findall('.//testcase')
    failures=[case.attrib['name'] for case in cases if case.findall('failure')]
    assert len(cases)==3 and len(failures)==2 and not any(case.findall('skipped') for case in cases)
    c.save(out/'summary.json',dict(executed=True,expected_red=True,cases=3,failed_cases=failures,exit=1,skipped=0,
        frozen_actual_prechange_source=b.identity(source),feature_gap='Dense A[T,1,K] and real zero-slot-stride shared A are rejected; independent A[T,S,K] and invalid A2/S3 guards remain correct.',
        host_compiles=2,native_compiles=0,GPU_runs=0,new_executor=False))
    print('MLX_GROUPED_SHARED_OLD_ADMISSION_REJECT_CONFIRMED',flush=True)
if __name__=='__main__':main()
