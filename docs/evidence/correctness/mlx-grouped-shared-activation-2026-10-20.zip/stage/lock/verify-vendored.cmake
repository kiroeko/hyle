cmake_minimum_required(VERSION 3.25)
include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(mlx_cpu_quant mlx_cuda_quant iree_vulkan_runtime_patches)
