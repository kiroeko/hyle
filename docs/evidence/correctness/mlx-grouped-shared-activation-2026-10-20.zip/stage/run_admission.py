"""Run the unchanged old-red object against the new common inference owner."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('mlx_admission_helpers',S.parent/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
out=S/'checks';link=c.read(out/'cpu-link-plan.json')
env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
c.execute('admission-tests',[str(out/'cpu.exe'),'--gtest_filter=MlxSharedActivationAdmission.*',
    '--gtest_output=xml:'+str(out/'admission-results.xml')],env,out)
cases=ET.parse(out/'admission-results.xml').findall('.//testcase')
assert len(cases)==3 and not any(case.findall('failure') or case.findall('skipped') for case in cases)
c.save(out/'admission-summary.json',dict(executed=True,passed=True,cases=3,skipped=0,
    original_red_object_reused=True,scope='Common admission only; not native math, provider capture or cross-platform execution.'))
print('MLX_SHARED_ADMISSION_RED_TO_GREEN',flush=True)
