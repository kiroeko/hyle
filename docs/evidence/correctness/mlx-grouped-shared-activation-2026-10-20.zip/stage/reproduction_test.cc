#include <gtest/gtest.h>
#include <array>
#include "hyle/compute/model_ops.h"

namespace {
namespace c = hyle::compute;
namespace mo = c::model_ops;
auto descriptions(c::TensorDesc activation) {
  return std::array{activation,
      c::TensorDesc::dense(c::DataType::kUInt32, std::array<std::int64_t,3>{3,2,8}).value(),
      c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t,3>{3,2,2}).value(),
      c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t,3>{3,2,2}).value(),
      c::TensorDesc::dense(c::DataType::kInt32, std::array<std::int64_t,2>{2,3}).value()};
}
const mo::MlxQuantized operation{.format=mo::MlxWeightFormat::kAffine,
    .kind=mo::MlxQuantizedKind::kGrouped,.bits=4,.group_size=32};

TEST(MlxSharedActivationAdmission, DenseOneActivationPerTokenProducesEverySelectedExpert) {
  const auto in = descriptions(c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,3>{2,1,64}).value());
  std::array<c::TensorDesc,1> out;
  const auto status = operation.infer_output_descriptions(in,out);
  ASSERT_TRUE(status.ok()) << status.message();
  EXPECT_EQ(out[0], c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,3>{2,3,2}).value());
}

TEST(MlxSharedActivationAdmission, RealZeroSlotStrideDoesNotRequireExpandedPayload) {
  const auto shared = c::TensorDesc::strided_bytes(c::DataType::kFloat32,
      std::array<std::int64_t,3>{2,3,64}, std::array<std::int64_t,3>{320,0,4}).value();
  ASSERT_EQ(shared.required_bytes().value(), 576u); // Two K64 rows with a real gap.
  const auto in = descriptions(shared);
  std::array<c::TensorDesc,1> out;
  const auto status = operation.infer_output_descriptions(in,out);
  ASSERT_TRUE(status.ok()) << status.message();
  EXPECT_EQ(out[0], c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,3>{2,3,2}).value());
}

TEST(MlxSharedActivationAdmission, IndependentRowsAndInvalidSlotCountsStayDistinct) {
  std::array<c::TensorDesc,1> out;
  auto in = descriptions(c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,3>{2,3,64}).value());
  EXPECT_TRUE(operation.infer_output_descriptions(in,out).ok());
  in[0] = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,3>{2,2,64}).value();
  EXPECT_TRUE(operation.infer_output_descriptions(in,out).IsInvalidArgument());
}
} // namespace
