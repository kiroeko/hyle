"""Build only permanent MLX test owners, then run focused CPU/CUDA tests."""
import concurrent.futures, importlib.util, sys, xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('mlx_shared_focused_helpers',S/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
out=S/'checks/tests';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
bases={arm:c.read(S/'checks'/(arm+'-link-plan.json')) for arm in ['cpu','cuda']}
owners=c.read(S/'checks/test-owner-inventory.json');rows=[]
for owner in owners['cpu_mlx_quantized_test.cc']:
 graph=any('HYLE_TEST_GRAPH_ROUTE_CPU' in arg for arg in owner['command']);tag='cpu-graph-test' if graph else 'cpu-direct-test';source=ROOT/'tests/compute_route_cpu/cpu_mlx_quantized_test.cc'
 rows.append(dict(tag=tag,arm='cpu',source=b.identity(source),old_object=owner['object'],command=b.host_command(owner['command'],source,tag,out),object=str(out/(tag+'.obj'))))
assert len(rows)==2
prior=c.read(A/'mlx-affine-widths/cuda/checks/20261019T135721/precision-test-identity.json');source=ROOT/'tests/compute_provider_torch_cuda/mlx_precision_test.cc';tag='cuda-test'
rows.append(dict(tag=tag,arm='cuda',source=b.identity(source),old_object=None,command=b.host_command(prior['command'],source,tag,out),object=str(out/(tag+'.obj')),recipe=str(A/'mlx-affine-widths/cuda/checks/20261019T135721/precision-test-identity.json')))
frozen=[b.identity(ROOT/rel) for rel in ['tests/compute_models/mlx_grouped_shared_fixture.h','tests/compute_route_cpu/cpu_mlx_quantized_test.cc','tests/compute_provider_torch_cuda/mlx_precision_test.cc']]
c.save(S/'tests/source-freeze.json',dict(source=frozen,scope='Root authored permanent fixtures; compile and focused runtime only'))
legacy=c.read(A/'ct-packed-linear/checks/legacy-mlx/test-identity.json');assert b.same(legacy['source']) and b.same(legacy['object'])
comment=c.read(S/'checks/closure-proof.json')['comments_only_public_header'];drift=[]
for dep in legacy['dependencies']:
 if not b.same(dep):
  assert c.key(dep['path'])==c.key(ROOT/'include/hyle/compute/model_ops.h') and dep['sha256']==comment['before']['sha256'];drift.append(dep)
assert len(drift)==1
c.save(out/'reused-legacy-mlx.json',dict(receipt=legacy,only_dependency_drift=drift,comment_equivalence_proof=b.identity(S/'checks/closure-proof.json'),no_test_recompile=True))
c.save(out/'plan.json',dict(compile=rows,frozen=frozen,host_TUs=3,native_TUs=0,SDK_rebuild=False,reused_legacy_MLX=legacy['object']))
def check():
 for row in frozen:assert b.same(row),row['path']
for base in bases.values():
 for row in base['inputs']:assert b.same(row),row['path']
env,runtime=b.environment(bases['cuda']['command'],[row['path'] for base in bases.values() for row in base['inputs']],out)
c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
def compile_one(row):
 check();c.execute(row['tag']+'-compile',row['command'],env,out);check();deps=c.read(out/(row['tag']+'-deps.json'))['Data'];result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]);c.save(out/(row['tag']+'-identity.json'),result);print('COMPILED',row['tag'],flush=True);return row['tag'],result
finished={};errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
  try:tag,result=future.result();finished[tag]=result
  except Exception as error:errors.append(repr(error))
c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors,host_TUs=3,native_TUs=0))
if errors:raise RuntimeError(errors)
for arm,base in bases.items():
 replacements={c.key(row['old_object']['path']):finished[row['tag']]['object'] for row in rows if row['arm']==arm and row['old_object']}
 additions=[finished[row['tag']]['object'] for row in rows if row['arm']==arm and not row['old_object']]
 if arm=='cuda':additions.append(legacy['object'])
 lookup={c.key(row['path']):row for row in [*base['inputs'],*replacements.values(),*additions]}
 command=[replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 image=out/(arm+'.exe');command += [row['path'] for row in additions]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')];assert len(inputs)==len({c.key(row['path']) for row in inputs})
 for row in inputs:assert b.same(row),row['path']
 check();c.save(out/(arm+'-link-plan.json'),dict(command=command,inputs=inputs));c.execute(arm+'-link',command,env,out);c.save(out/(arm+'-image.json'),b.identity(image))
summary={}
for arm,filter in [('cpu','CpuMlxQuantizedDirect.*:CpuMlxQuantizedGraph.*:MlxSharedActivationAdmission.*'),('cuda','OriginalDtypes/CudaMlxPrecision.*:CudaMlxSharedActivation.*:CudaPackedWeights.*:CudaCtPackedLinear.*:MlxSharedActivationAdmission.*')]:
 command=[str(out/(arm+'.exe')),'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/(arm+'-results.xml'))]
 try:c.execute(arm+'-tests',command,env,out)
 except RuntimeError:pass
 cases=ET.parse(out/(arm+'-results.xml')).findall('.//testcase');assert cases
 failed=[case.attrib['classname']+'.'+case.attrib['name'] for case in cases if case.findall('failure')];skipped=[case.attrib['name'] for case in cases if case.findall('skipped')]
 summary[arm]=dict(executed=True,passed=not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,names=[case.attrib['classname']+'.'+case.attrib['name'] for case in cases],exit=c.read(out/(arm+'-tests.result.json'))['exit'])
c.save(out/'summary.json',dict(arms=summary,passed=all(arm['passed'] for arm in summary.values()),scope='F32/BF16 denseA1 and genuine zero-slot/token-gap shared activations, two updates, repeated expert IDs, failure preserves outputs; related MLX/CT neighbors. No whole model or throughput.'))
print('MLX_SHARED_FOCUSED_RESULTS',summary,flush=True)
if not all(arm['passed'] for arm in summary.values()):raise SystemExit(1)
