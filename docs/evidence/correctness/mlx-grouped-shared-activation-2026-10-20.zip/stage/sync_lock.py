"""Refresh only changed in-tree adapter identities with the canonical CMake hash."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('mlx_lock_helpers',S.parent/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
def visit(value):
    if isinstance(value,dict):
        yield value
        for child in value.values():yield from visit(child)
    elif isinstance(value,list):
        for child in value:yield from visit(child)
def main():
    out=S/'lock';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    path=ROOT/'cmake/HyleDependencyLock.json';before=out/'HyleDependencyLock.before.json'
    if not before.exists():before.write_bytes(path.read_bytes())
    initial=out/'initial-expanded-hash-error'
    if not initial.exists() and (out/'canonical-verify.result.json').exists():
        initial.mkdir()
        for file in [*out.glob('canonical-hash.*'),*out.glob('canonical-verify.*')]:shutil.copy2(file,initial/file.name)
        (initial/'HyleDependencyLock.json').write_bytes(path.read_bytes())
    text=path.read_text();doc=json.loads(text)
    names=('mlx_cpu_quant','mlx_cuda_quant','iree_vulkan_runtime_patches')
    rows={row['name']:row for row in visit(doc) if row.get('name') in names}
    assert set(rows)==set(names)
    script=out/'canonical-vendored.cmake'
    script.write_text('cmake_minimum_required(VERSION 3.25)\ninclude("'+(ROOT/'cmake/HyleDependencyVersions.cmake').as_posix()+'")\n'+''.join(
        '_hyle_dependency_tree_sha256("'+(ROOT/rows[name]['vendored']['path']).as_posix()+'" tree)\n'
        'message(STATUS "HYLE vendored source tree '+name+': ${tree}")\n'
        '_hyle_dependency_normalized_sha256("'+(ROOT/rows[name]['vendored']['path']/'NOTICE.md').as_posix()+'" notice)\n'
        'message(STATUS "HYLE normalized notice '+name+': ${notice}")\n' for name in names),encoding='utf-8')
    env=dict(os.environ,TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
    c.execute('canonical-hash',[shutil.which('cmake'),'-P',str(script)],env,out)
    output=(out/'canonical-hash.stdout.log').read_text()
    hashes=dict(re.findall(r'HYLE vendored source tree (\w+): ([0-9a-f]{64})',output))
    notices=dict(re.findall(r'HYLE normalized notice (\w+): ([0-9a-f]{64})',output))
    assert set(hashes)==set(names)
    changes=[]
    for name,row in rows.items():
        old=row['vendored']['tree_sha256'];new=hashes[name]
        assert old!=new and text.count(old)==1
        text=text.replace(old,new);changes.append(dict(name=name,field='vendored.tree_sha256',before=old,after=new))
        for license in row['license']['files']:
            data=(ROOT/license['path']).read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
            now=hashlib.sha256(data).hexdigest()
            if license['path'].endswith('/NOTICE.md'):assert now==notices[name]
            if now==license['sha256']:continue
            assert license['path'].endswith('/NOTICE.md') and text.count(license['sha256'])==1
            text=text.replace(license['sha256'],now)
            changes.append(dict(name=name,field=license['path'],before=license['sha256'],after=now))
    path.write_text(text,encoding='utf-8',newline='\n')
    verify=out/'verify-vendored.cmake'
    verify.write_text('cmake_minimum_required(VERSION 3.25)\ninclude("'+(ROOT/'cmake/HyleDependencyVersions.cmake').as_posix()+'")\nhyle_audit_in_tree_dependencies('+ ' '.join(names)+')\n',encoding='utf-8')
    c.execute('canonical-verify',[shutil.which('cmake'),'-P',str(verify)],env,out)
    c.save(out/'summary.json',dict(passed=True,before=b.identity(before),after=b.identity(path),changes=changes,
        upstream_revisions_changed=False,SDK_rebuild=False,initial_error='First script used expanded archive raw hash for in-tree adapters; canonical verify rejected the dependency category. Corrected to existing normalized vendored implementation and preserved first logs/intermediate lock.',
        scope='Three modified local adapter trees and changed NOTICE identities only; canonical CMake vendored implementation verified the refreshed lock.'))
    print('MLX_LOCAL_SOURCE_LOCK_UPDATED',len(changes),flush=True)
if __name__=='__main__':main()
