"""Frozen current Vulkan MLX Direct/Graph cases, no throughput or full suite."""
from pathlib import Path
import importlib.util,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1]
spec=importlib.util.spec_from_file_location('mlx_run_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c;out=S/'test-checks';phase=sys.argv[1]
names={
 'shared':['VulkanIree.MlxGroupedSharesOriginalActivationAcrossSelectedExperts','VulkanGraph.MlxGroupedSharesOriginalActivationAcrossSelectedExperts'],
 'neighbors':['VulkanIree.OriginalMlxBatchPreservesGroupsSourceTypesAndCheckedSlots','VulkanGraph.OriginalMlxBatchUsesOrdinaryTypedNodesAndCheckedSlots','VulkanIree.OriginalMlxAffineWidthsUseContinuousBitstreamsAndCheckedRebinding','VulkanGraph.OriginalMlxAffineWidthsUseContinuousBitstreamsAndCheckedRebinding','VulkanIree.OriginalMlxConstantsKeepBanksAcrossRebindingAndSlots','VulkanGraph.OriginalMlxConstantsKeepBanksAcrossRebindingAndSlots','VulkanIree.OriginalMlxAffineWidthsKeepDecodedWeightsInF32BeforeDot']
}[phase]
image=c.read(out/'image.json');plan=c.read(out/'plan.json');link=c.read(out/'link-plan.json')
for identity in [image,*plan['frozen'],*link['inputs']]:assert h.same_identity(identity),identity['path']
env=os.environ.copy();env['PATH']=c.read(out/'runtime-environment.json')['PATH'];env['TEMP']=env['TMP']=str(out/'tmp')
xml=out/(phase+'.xml');command=[image['path'],'--gtest_filter='+':'.join(names),'--gtest_output=xml:'+str(xml)]
c.save(out/(phase+'-plan.json'),dict(image=image,names=names,inputs=link['inputs'],source_freeze=plan['frozen'],full_suite=False,throughput=False))
c.execute(phase,command,env,out)
root=ET.parse(xml).getroot();actual=[case.attrib['classname']+'.'+case.attrib['name']for suite in root.findall('testsuite')for case in suite.findall('testcase')]
assert sorted(actual)==sorted(names),(actual,names)
assert int(root.attrib['failures'])==0 and int(root.attrib['disabled'])==0 and int(root.attrib['errors'])==0
assert not root.findall('.//skipped')
c.save(out/(phase+'-summary.json'),dict(passed=True,tests=len(actual),failures=0,errors=0,skipped=0,image=image,xml=b.identity(xml),stdout=b.identity(out/(phase+'.stdout.log')),GPU_runs=1,selected_cases=actual))
print(phase.upper()+'_PASS',len(actual),'0skip',flush=True)
