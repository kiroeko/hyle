"""Actual V3 private-host closure plus embedded artifact, no SDK build or GPU."""
from pathlib import Path
import importlib.util,sys,json,hashlib,base64,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];ROOT=A.parents[1];out=S/'host';(out/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('mlx_vk_h',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
spec=importlib.util.spec_from_file_location('extent_vk_old',A/'batch-query-extent/vulkan/build.py');previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
inv=c.read(out/'abi-inventory.json');base=inv['base'];meta=h.metadata({'vulkan':base})
for row in base['inputs']:assert h.same_identity(row),row['path']
# Run exactly the embedded-program generation portion of the original module
# recipe. No upstream source tree, SDK, runtime archive or build copy is touched.
prepare=ROOT/'src/compute_provider_iree_vulkan/prepare_source.py'
text=prepare.read_text();start=text.index('    programs = json.loads(');end=text.index('    print(f"IREE source:',start)
block=text[start:end];envgen={'json':json,'base64':base64,'sha':lambda x:hashlib.sha256(x).hexdigest(),
    'vendor':ROOT/'third_party/iree_vulkan_runtime','generated':out/'generated'}
envgen['generated'].mkdir(exist_ok=True)
exec('\n'.join(line[4:] if line.startswith('    ')else line for line in block.splitlines()),envgen)
generated=out/'generated/programs.cc'
c.save(out/'embedded-generation.json',dict(recipe=b.identity(prepare),method='Exact unchanged embedding block from prepare_source.py; upstream preparation omitted',source=b.identity(generated),SDK_rebuilt=False))
selected={c.key(row['object']['path']):row['owner']for row in inv['private_abi_owners']}
gen=inv['generated_program_owners'];assert len(gen)==1;selected[c.key(gen[0]['object']['path'])]=gen[0]['owner']
# These have actual changed source outside the private layout closure.
extra={c.key(ROOT/rel) for rel in ['src/compute_route_vulkan/vulkan_batch.cc','src/compute_provider_ggml/native_batch.cc','src/compute_ops/weight_decode.cc','src/compute_provider_native/torch_cpu_program.cc']}
for obj in base['inputs']:
 rec=meta.get(c.key(obj['path']))
 if rec and c.key(rec['source_path'])in extra:selected[c.key(obj['path'])]=rec
canonical=previous.canonical
cache={}
for name in ['weight-decode','torch-cpu']:
 receipt=A/'mlx-grouped-shared-activation/checks'/(name+'-identity.json')
 r=c.read(receipt);cache[c.key(r['source']['path'])]=(receipt,r)
rows=[];reused=[];replacements={}
lookup={c.key(row['path']):row for row in base['inputs']}
for objkey,rec in selected.items():
 source=Path(rec['source_path']);source=generated if source.name=='programs.cc'else source
 old=lookup[objkey];cached=cache.get(c.key(source))
 if cached:
  path,r=cached
  if canonical(rec['command'],source)==canonical(r['command'],source) and h.same_identity(r['source'])and h.same_identity(r['object'])and all(h.same_identity(d)for d in r['dependencies']):
   reused.append(dict(source=r['source'],object=r['object'],receipt=str(path),canonical_commands_equal=True));replacements[objkey]=r['object'];continue
 tag=source.parent.name+'-'+source.stem
 if source==generated:tag='embedded-programs'
 command=b.host_command(rec['command'],source,tag,out)
 row=dict(tag=tag,source=b.identity(source),recipe=rec['recipe'],command=command,old_object=old,object=str(out/(tag+'.obj')))
 rows.append(row)
frozen=[b.identity(S/'source-freeze.json'),*[b.identity(ROOT/row['path'])for row in c.read(S/'source-freeze.json')['product']]]
plan=dict(base_path=inv['base_path'],compile=rows,reused_new_common=reused,frozen=frozen,private_ABI_owners=len(inv['private_abi_owners']),embedded_owners=1,host_TUs=len(rows),SDK_rebuilt=False,GPU_run=False,
    retained_input_scope='All original input object/library hashes checked. Requested V3 SourceDeps closure refreshed plus actual changed Vulkan batch/CPU batch/weight decode/Torch CPU sources. Other retained backend/SDK owners reused, not a whole-tree freshness claim.')
c.save(out/'plan.json',plan);print('PLAN',len(rows),'CXX',len(reused),'new common reused',flush=True)
if '--build'not in sys.argv:raise SystemExit(0)
env,runtime=b.environment(base['command'],[x['path']for x in base['inputs']],out);env['PYTHONDONTWRITEBYTECODE']='1';c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
def frozen_check():
 for row in frozen:assert h.same_identity(row),row['path']
def compile_one(row):
 frozen_check();rp=out/(row['tag']+'-identity.json')
 if rp.exists():
  old=c.read(rp)
  if old['command']==row['command']and h.same_identity(old['object'])and h.same_identity(old['source'])and all(h.same_identity(d)for d in old['dependencies']):return old
 c.execute(row['tag']+'-compile',row['command'],env,out);frozen_check()
 depfile=out/(row['tag']+'-deps.json');d=c.read(depfile)['Data']
 result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),source_dependencies=b.identity(depfile),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=row['recipe'])
 c.save(rp,result);return result
finished=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for task in concurrent.futures.as_completed([pool.submit(compile_one,row)for row in rows]):
  try:finished.append(task.result())
  except Exception as e:errors.append(repr(e))
c.save(out/'compile-summary.json',dict(passed=not errors,host_TUs=len(rows),reused=len(reused),errors=errors,GPU_run=False,SDK_rebuilt=False))
if errors:raise RuntimeError(errors)
for row in rows:
 record=next(x for x in finished if c.key(x['source']['path'])==c.key(row['source']['path']));replacements[c.key(row['old_object']['path'])]=record['object']
command=[replacements[c.key(arg)]['path']if c.key(arg)in replacements else arg for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'vulkan.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
lookup.update({c.key(row['path']):row for row in replacements.values()});inputs=[lookup[c.key(arg)]for arg in command if Path(arg).is_absolute()and Path(arg).suffix.lower()in('.obj','.lib')]
for row in inputs:assert h.same_identity(row),row['path']
frozen_check();c.save(out/'link-plan.json',dict(command=command,inputs=inputs));c.execute('vulkan-link',command,env,out);frozen_check();c.save(out/'image.json',b.identity(image));c.save(out/'summary.json',dict(passed=True,host_TUs=len(rows),reused_common=len(reused),private_ABI_owners=23,generated_owners=1,links=1,SDK_rebuilt=False,GPU_runs=0,image=b.identity(image)))
print('VULKAN_HOST_READY_NO_GPU',flush=True)
