"""Two existing MLX fixture owners on the frozen V3 host closure."""
from pathlib import Path
import concurrent.futures,importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('mlx_test_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'test-checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
base=c.read(S/'host/link-plan.json')
for row in base['inputs']:assert h.same_identity(row),row['path']
freeze=[b.identity(S/'source-freeze.json'),b.identity(S/'tests/source-freeze.json')]
freeze += [b.identity(ROOT/row['path'])for row in c.read(S/'source-freeze.json')['product']]
freeze += [b.identity(ROOT/row['path'])for row in c.read(S/'tests/source-freeze.json')['files']]
freeze += [b.identity(ROOT/'tests/compute_models/mlx_grouped_shared_fixture.h')]
old=A/'mlx-affine-widths/vulkan/refresh-20261019T140912';rows=[]
for route in ['compute_route_vulkan','graph_route_vulkan']:
 source=ROOT/'tests'/route/'iree_test.cc';tag=route+'-iree-test';recipe=old/('tests--'+route+'--iree_test-identity.json')
 command=b.host_command(c.read(recipe)['command'],source,tag,out)
 rows.append(dict(tag=tag,source=b.identity(source),command=command,recipe=b.identity(recipe),object=str(out/(tag+'.obj'))))
c.save(out/'plan.json',dict(compile=rows,base=b.identity(S/'host/link-plan.json'),frozen=freeze,new_targets=0,SDK_rebuilt=False))
env,runtime=b.environment(rows[0]['command'],[r['path']for r in base['inputs']],out);env['PYTHONDONTWRITEBYTECODE']='1'
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
def frozen_check():
 for row in freeze:assert h.same_identity(row),row['path']
def compile_one(row):
 frozen_check();rp=out/(row['tag']+'-identity.json')
 if rp.exists():
  old=c.read(rp)
  if old['command']==row['command']and h.same_identity(old['object'])and h.same_identity(old['source'])and all(h.same_identity(d)for d in old['dependencies']):return old
 c.execute(row['tag']+'-compile',row['command'],env,out);frozen_check()
 depfile=out/(row['tag']+'-deps.json');d=c.read(depfile)['Data']
 rec=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),source_dependencies=b.identity(depfile),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=row['recipe'])
 c.save(rp,rec);return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:finished=list(pool.map(compile_one,rows))
command=[arg for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command.extend(row['object']['path']for row in finished)
image=out/'vulkan-mlx.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[*base['inputs'],*[row['object']for row in finished]]
for row in inputs:assert h.same_identity(row),row['path']
frozen_check();c.save(out/'link-plan.json',dict(command=command,inputs=inputs));c.execute('vulkan-mlx-link',command,env,out);frozen_check()
c.save(out/'image.json',b.identity(image));c.save(out/'summary.json',dict(passed=True,host_CXX=2,links=1,SDK_rebuilt=False,GPU_runs=0,image=b.identity(image)))
print('VULKAN_MLX_TEST_IMAGE_READY',flush=True)
