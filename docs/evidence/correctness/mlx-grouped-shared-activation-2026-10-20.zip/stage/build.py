"""Refresh three host owners and one private CUDA owner; never run an image."""
import argparse, concurrent.futures, importlib.util, shlex, sys
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
h=load('mlx_shared_build_helpers',A/'projected-bind-cold-index/build.py');b,c=h.b,h.c

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--build',action='store_true');parser.add_argument('--resume',action='store_true');args=parser.parse_args()
 out=S/'checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
 bases={arm:c.read(A/'batch-output-tail/checks'/(arm+'-link-plan.json')) for arm in ('cpu','cuda')}
 owners=c.read(out/'owner-inventory.json');rows=[]
 specs=[('weight-decode','weight_decode.cc','src/compute_ops/weight_decode.cc','host'),('torch-cpu','torch_cpu_program.cc','src/compute_provider_native/torch_cpu_program.cc','host'),('torch-cuda','artifact_provider.cc','src/compute_provider_torch_cuda/artifact_provider.cc','host'),('mlx-kernel','mlx_packed_kernel.cu','src/compute_provider_torch_cuda/mlx_packed_kernel.cu','native')]
 for tag,name,rel,kind in specs:
  records=owners[name];source=ROOT/rel
  if kind=='host':
   command=b.host_command(records[0]['command'],source,tag,out)
   if len(records)>1:
    assert all(b.host_command(record['command'],source,tag,out)==command for record in records),name
  else:
   command=[];skip=False
   for arg in records[0]['command']:
    if skip:skip=False;continue
    if arg in ('-c','-o','-MT','-MF'):skip=True
    elif not arg.startswith('-Xcompiler=-Fd'):command.append(arg)
   command+=['-MT',str(out/(tag+'.obj')),'-MF',str(out/(tag+'.d')),'-c',str(source),'-o',str(out/(tag+'.obj')),'-Xcompiler=-Fd'+str(out/(tag+'.pdb'))+',-FS']
   assert '-std=c++20' in command and '--generate-code=arch=compute_89,code=[compute_89,sm_89]' in command and '--use_fast_math' not in command
  rows.append(dict(tag=tag,kind=kind,source=b.identity(source),command=command,object=str(out/(tag+'.obj')),old_objects=[dict(arm=record['arm'],object=record['object'],recipe=record['recipe']) for record in records]))
 freeze=c.read(S/'source-freeze.json');frozen=[b.identity(ROOT/row['path']) for row in freeze['source']]
 for row in frozen:assert row['sha256']==next(x['sha256'] for x in freeze['source'] if c.key(ROOT/x['path'])==c.key(row['path']))
 probe=c.read(S/'reproduction/shared-probe-identity.json')['object'];assert b.same(probe)
 plan=dict(compile=rows,frozen=frozen,common_weight_recipe_identical=True,base_paths={arm:str(A/'batch-output-tail/checks'/(arm+'-link-plan.json')) for arm in bases},retained_red_probe=probe,host_TUs=3,native_TUs=1,SDK_rebuild=False,GPU_run=False)
 c.save(out/'plan.json',plan);print('MLX_SHARED_BUILD_PLAN 3 host 1 native',flush=True)
 if not args.build:return
 def check():
  for row in frozen:assert b.same(row),row['path']
 for base in bases.values():
  for row in base['inputs']:assert b.same(row),row['path']
 env,runtime=b.environment(bases['cuda']['command'],[row['path'] for base in bases.values() for row in base['inputs']],out)
 c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
 def compile_one(row):
  check();receipt=out/(row['tag']+'-identity.json')
  if args.resume and receipt.exists():
   prior=c.read(receipt)
   if prior['command']==row['command'] and b.same(prior['object']) and all(b.same(x) for x in prior['dependencies']):return row['tag'],prior
  c.execute(row['tag']+'-compile',row['command'],env,out);check()
  if row['kind']=='host':
   data=c.read(out/(row['tag']+'-deps.json'))['Data'];paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
  else:
   dep=(out/(row['tag']+'.d')).read_text(encoding='utf-8');body=dep.split(' : ',1)[1].replace('\\\n',' ');paths=list(dict.fromkeys(str(Path(p).resolve()) for p in shlex.split(body,posix=True)))
   assert paths and all(Path(p).is_file() for p in paths)
  result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=[b.identity(path) for path in paths])
  c.save(receipt,result);print('COMPILED',row['tag'],len(paths),flush=True);return row['tag'],result
 finished={};errors=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
   try:tag,result=future.result();finished[tag]=result
   except Exception as error:errors.append(repr(error))
 c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors,finished=list(finished),host_TUs=3,native_TUs=1,SDK_rebuild=False,GPU_run=False))
 if errors:raise RuntimeError(errors)
 for arm,base in bases.items():
  replacements={c.key(old['object']['path']):finished[row['tag']]['object'] for row in rows for old in row['old_objects'] if old['arm']==arm}
  lookup={c.key(row['path']):row for row in [*base['inputs'],probe,*replacements.values()]}
  command=[replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
  image=out/(arm+'.exe');command+=[probe['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
  inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
  assert len(inputs)==len({c.key(row['path']) for row in inputs})
  for row in inputs:assert b.same(row),row['path']
  check();link=dict(command=command,inputs=inputs);c.save(out/(arm+'-link-plan.json'),link);c.execute(arm+'-link',command,env,out);c.save(out/(arm+'-image.json'),b.identity(image));print('LINKED',arm,flush=True)
 c.save(out/'summary.json',dict(passed=True,host_TUs=3,native_TUs=1,SDK_rebuild=False,GPU_run=False,red_probe_reused=True,common_owner_shared=True))
 print('MLX_SHARED_BUILT_NO_RUNTIME',flush=True)
if __name__=='__main__':main()
