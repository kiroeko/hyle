"""Publish the frozen MLX batch only; never read the next common implementation."""
from pathlib import Path
import base64,hashlib,json,zipfile
S=Path(__file__).resolve().parent;ROOT=S.parents[2];DEST=ROOT/'docs/evidence/correctness';NAME='mlx-grouped-shared-activation-2026-10-20'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(data):return hashlib.sha256(data).hexdigest()
def frozen(row,base):
 p=Path(row['path']);p=p if p.is_absolute() else base/p
 assert sha(p.read_bytes())==row['sha256'],p
old=read(S/'reproduction/summary.json');assert old['expected_red'] and old['cases']==3 and len(old['failed_cases'])==2
windows=read(S/'checks/tests/summary.json');assert windows['passed']
assert windows['arms']['cpu']['cases']==19 and windows['arms']['cuda']['cases']==31
assert all(not r['failed'] and not r['skipped'] for r in windows['arms'].values())
apple=read(S/'apple-verification/final-validation.json');vulkan=read(S/'apple-vulkan/final-validation.json');lock=read(S/'lock/summary.json')
assert apple['passed'] and apple['tests']==9 and apple['skipped']==0
assert vulkan['passed'] and sum(x['tests']for x in vulkan['selected_runs'])==9 and all(x['skipped']==0 for x in vulkan['selected_runs'])
assert lock['passed'] and read(S/'lock/canonical-verify.result.json')['exit']==0
for r in read(S/'source-freeze.json')['source']:frozen(r,S/'after')
for r in read(S/'apple-vulkan/source-freeze.json')['product']:frozen(r,S/'apple-vulkan/after')
for r in read(S/'apple-vulkan/tests/source-freeze.json')['files']:frozen(r,S/'apple-vulkan/after')
module=base64.b64decode((S/'apple-vulkan/after/third_party/iree_vulkan_runtime/programs/mlx.vmfb.b64').read_bytes())
assert sha(module)==read(S/'apple-vulkan/artifact-consistency.json')['vmfb_sha256']
body={'schema':1,'date':'2026-10-20','topic':'MLX packed grouped shared activations','result':'Implemented and directed tested on CPU, CUDA, Apple and Vulkan; no full-artifact/model or performance acceptance.','contract':{'inputs':'A[T,A,K], A=1 or S; IDs dense I32[T,S], output[T,S,N]. Existing dtype/codec/group and mixed-affine promotion remain.','views':'Actual zero-slot-stride view with contiguous K and element-aligned nonoverlapping token rows; test token pitch80 for K64.','math':'Original codec, scale/bias dtype, F32 affine product/add and dot/group accumulation, MX scale cast, final output boundaries unchanged. No implicit precision change.','storage':'No full T*S*K activation expansion required. CPU collapses before casts and uses selected per-slot group dots; CUDA addresses original A; Apple uses native indexed broadcast; Vulkan stages physical A span and retains per-group workspaces.','architecture':'Existing schema/carriers/Queue/Invocation; no model whitelist, executor, hidden ID readback or public descriptor ABI field. Private CUDA host/native geometry updated together; private Vulkan ProgramSpecV3 prevents silent old by-value callers.'},'evidence':{'old_admission':{'tests':3,'failed':2,'control_passed':1,'source':'stage/reproduction/summary.json','frozen_before_compiled':True},'CPU':{'gtests':19,'common_inference_probes':3,'provider_Direct_Graph_tests':16,'new_shared_tests':2,'failures':0,'skipped':0,'result':'stage/checks/tests/summary.json'},'CUDA':{'gtests':31,'common_inference_probes':3,'device_provider_tests':28,'new_shared_tests':1,'neighbors':'18 precision,5 original packed,4 CT Graph; common probes are not GPU tests','failures':0,'skipped':0,'result':'stage/checks/tests/summary.json','hardware_observation':'stage/checks/tests/hardware-query.stdout.log'},'Apple':{'gtests':9,'new_shared_tests':2,'neighbor_tests':7,'internal_domains_per_new_test':4,'failures':0,'skipped':0,'host':'Mac16,12 Apple M4 16GiB; macOS27.0.1 clang21','CXX':6,'SDK_or_Metal_rebuild':False,'result':'stage/apple-verification/final-validation.json','frozen_common_before_next_batch':'stage/apple-verification/retained-common/freeze.json'},'Vulkan':{'gtests':9,'new_shared_tests':2,'neighbor_tests':7,'failures':0,'skipped':0,'fresh_product_CXX':26,'reused_current_common_owners':2,'fresh_test_CXX':2,'SDK_rebuild':False,'result':'stage/apple-vulkan/final-validation.json'},'local_lock':{'canonical_verify_exit':0,'upstream_revision_change':False,'source':'stage/lock/summary.json'}},'retained_failures':['Original frozen inference source rejects dense A1 and true shared View; both controls and exact same probe object retained.','Initial 3 test compiles fail because two SCOPED_TRACE macros shared one source line; root split lines,3 test owners rebuilt and passed.','Initial in-tree lock update used expanded raw tree hashes; canonical CMake audit rejected the category. Correct normalized vendored hash and NOTICE identities then verified.','Offline IREE compiler schedule-count32 assertion was brittle after grouped ABI change; export set/signatures remain21 and actual generated count recorded.','MSVC C4838 in private IREE physical extent list fixed with existing bounded iree_hal_dim_t conversion; failed source,command and log retained.'],'limits':['New shared execution witnesses cover F32/BF16 affine5, denseA1 and real zero-slot/token-gap80, duplicate IDs, two value updates and checked invalid IDs. Other shared format/precision domains are not exhaustively runtime tested.','Apple arbitrary nested lazy Views, general decode/QMV contraction and typed embedding two-RNE equivalence are not established by this batch.','Vulkan retains per-K-group activation/weight workspaces and native staging; no zero-allocation,zero-copy or peak-memory claim.','Windows hardware was separately queried as RTX4070 SM8.9 driver617.14; fixtures use default contexts and do not emit selected physical-device UUID. The Vulkan default-context run does not independently pin a device identity.','No full selected artifact payload/model, quality, throughput, peak-memory or Linux acceptance.','Later common binding/layout architecture edits are a separate batch; this package preserves the actual earlier common snapshot and does not rebuild against later source.'],'reproduction':'Current canonical checkout plus recorded toolchains/caches and source snapshots. Exact commands/dependencies/logs are retained; SDK binaries, executables,objects,maps and caches are intentionally excluded. Final MLX encoded module and canonical regeneration scripts are included.'}
allowed={'.json','.py','.cc','.cpp','.h','.hpp','.c','.cmake','.ps1','.log','.xml','.md','.txt','.d','.diff','.mlir','.b64'}
exclude_dirs={'tmp','cache','CMakeFiles','spirv','__pycache__','generated'}
exclude_names={'publication.json','archive-verification.json','publish-plan.json','payload.json','configured.mlir','annotated.mlir'}
items={}
for p in sorted(S.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(S)
 if p.name in exclude_names or any(part in exclude_dirs for part in rel.parts) or 'cleanup' in p.name.lower():continue
 if p.suffix.lower() not in allowed:continue
 if 'objects' in rel.parts and p.suffix.lower()!='.d':continue
 items['stage/'+rel.as_posix()]=p.read_bytes()
items['summary.json']=(json.dumps(body,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
manifest={'payload':[{'path':name,'bytes':len(data),'sha256':sha(data)}for name,data in sorted(items.items())]}
man=(json.dumps(manifest,indent=2)+'\n').encode();items['manifest.json']=man
DEST.mkdir(parents=True,exist_ok=True);archive=DEST/(NAME+'.zip')
assert not archive.exists(),archive
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(items.items()):z.writestr(name,data)
with zipfile.ZipFile(archive)as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(items)
 for row in manifest['payload']:
  actual=z.read(row['path']);assert len(actual)==row['bytes'] and sha(actual)==row['sha256'],row['path']
 assert sha(z.read('manifest.json'))==sha(man)
primary=dict(body,archive={'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(items),'CRC_verified':True,'all_payload_SHA256_verified':True,'manifest_sha256':sha(man),'uncompressed_payload_bytes':sum(map(len,items.values()))})
index=DEST/(NAME+'.json');assert not index.exists(),index;index.write_text(json.dumps(primary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='')
result={'index':{'path':str(index),'bytes':index.stat().st_size,'sha256':sha(index.read_bytes())},'archive':primary['archive']}
(S/'publication.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='');print(json.dumps(result,indent=2))
