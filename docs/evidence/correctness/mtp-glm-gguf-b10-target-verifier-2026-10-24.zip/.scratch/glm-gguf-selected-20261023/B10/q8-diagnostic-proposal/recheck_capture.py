"""Read-only independent recheck of B10's tiny original A/W/Y failure capture."""
from pathlib import Path
import hashlib,json,math,re,struct

R=next(p for p in Path(__file__).resolve().parents if (p/'AGENTS.md').is_file())
A=R/'.scratch/glm-gguf-selected-20261023/B10';N=A/'native-integration'
C=N/'capture-cpu2/failure-0';OUT=Path(__file__).with_name('rca.json')
def identity(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.relative_to(R)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def bits(x):return hex(struct.unpack('<I',struct.pack('<f',x))[0])
def away(x):return math.floor(x+0.5) if x>=0 else -math.floor(-x+0.5)


def main():
    raw=(C/'input.f32').read_bytes();w=(C/'weight-row.q8_0').read_bytes();yraw=(C/'actual-y.f32').read_bytes()
    assert (len(raw),len(w),len(yraw))==(2048,544,4)
    x=struct.unpack('<512f',raw);y=struct.unpack('<f',yraw)[0]
    terms={'scalar':[],'avx':[]};packed={'scalar':bytearray(),'avx':bytearray()};differences=[]
    for group in range(16):
        values=x[group*32:group*32+32];maximum=max(map(abs,values));d=f32(maximum/127)
        stored=struct.unpack('<e',struct.pack('<e',d))[0];ids={'scalar':f32(1/d),'avx':f32(127/maximum)}
        codes={name:[away(f32(v*ids[name])) if name=='scalar' else round(f32(v*ids[name])) for v in values] for name in ids}
        weight_scale=struct.unpack_from('<e',w,group*34)[0];weights=struct.unpack_from('<32b',w,group*34+2)
        for name in ids:
            assert all(-127<=q<=127 for q in codes[name])
            packed[name]+=struct.pack('<e32b',stored,*codes[name])
            terms[name].append(weight_scale*stored*sum(q*v for q,v in zip(codes[name],weights)))
        for lane in range(32):
            if codes['scalar'][lane]!=codes['avx'][lane]:
                differences.append(dict(group=group,lane=lane,input=values[lane],input_bits=bits(values[lane]),weight=weights[lane],
                    d=d,d_bits=bits(d),stored_scale=stored,weight_scale=weight_scale,
                    scalar_id=ids['scalar'],avx_id=ids['avx'],scalar_scaled=f32(values[lane]*ids['scalar']),avx_scaled=f32(values[lane]*ids['avx']),
                    scalar_q=codes['scalar'][lane],avx_q=codes['avx'][lane],
                    exact_center_delta=weight_scale*stored*weights[lane]*(codes['scalar'][lane]-codes['avx'][lane])))
    centers={k:math.fsum(v) for k,v in terms.items()}
    for name in packed:assert bytes(packed[name])==(C/f'independent-{name}.q8_0').read_bytes()
    meta=dict(line.split('=',1) for line in (C/'metadata.txt').read_text().splitlines())
    bound=float(meta['original_bound']);assert centers['avx']==float(meta['original_oracle'])
    assert abs(y-centers['scalar'])<bound<abs(y-centers['avx'])
    assert len(differences)==1 and (differences[0]['group'],differences[0]['lane'])==(6,5)
    log=(N/'checks2-cpu/run/stdout.log').read_text()
    match=re.search(r'source=(\S+) head=(\d+) input_value=(\d+) output_value=(\d+) W=\[(\d+),(\d+),(\d+)\] head_stride=(\d+) position=(\d+)',log)
    assert match
    role,head,iv,ov,heads,outputs,k,stride,position=match.groups();head,outputs,k,stride=int(head),int(outputs),int(k),int(stride)
    scenario=re.findall(r'\(\d+\): GLM Pro K1 scenario=(\d+)',log)[-1]
    source=A/'original-static'/(role+'.bin');offset=head*stride
    with source.open('rb') as stream:stream.seek(offset);assert stream.read(len(w))==w
    manifest=json.loads((A/'original-static/manifest.json').read_text());original=next(v for v in manifest['roles'] if v['name']==role)
    assert original['gguf_dimensions']==[512,256,64] and (k,outputs,stride)==(512,256,139264)
    driver=json.loads((N/'checks2-cpu/frontier.driver.json').read_text());summary=json.loads((N/'checks2-cpu/summary.json').read_text())
    assert driver['native']['exit']==driver['exit']==3 and len(driver['fetches'])==0 and driver['job_cleanup']['remaining_descendants']==0 and summary['passed']is False
    record=dict(classification='Scratch validation runtime assembly mismatch; no production CMake defect or MTP-specific arithmetic defect identified.',
        failure=dict(role=role,head=head,output_row=0,scenario=int(scenario),position=int(position),input_value=int(iv),output_value=int(ov),native_exit=3,wrapper_passed=False),
        raw_capture=[identity(p)for p in sorted(C.iterdir()) if p.is_file()],
        original_weight=dict(manifest=identity(A/'original-static/manifest.json'),role=original,row_byte_offset=offset,row_bytes=len(w),captured_row_matches_original=True),
        independent_check=dict(actual=y,actual_bits=bits(y),centers=centers,errors={k:abs(y-v)for k,v in centers.items()},unchanged_bound=bound,code_differences=differences,
            scalar_and_avx_bytes_match_cpp_capture=True,code_sources='Independent Python F32/F16 round/store and integer equations; no native reference call.'),
        cause='At exactly -80.5, scalar roundf rounds away to -81; AVX nearest-even gives -80. The captured native Y matches scalar within9.15e-9. The retained baseline quants object delegated to scalar_ref, despite the manually assembled worker using AVX2 ops.',
        production_build=dict(source=identity(R/'src/compute_ggml_runtime/cpu_program.cmake'),fact='The complete hyle_ggml_cpu_avx2 target applies GGML_AVX/AVX2/FMA/F16C/BMI2 and AVX2 ISA flags to its entire source composition.'),
        action='Rebuild/stage the complete correct AVX2 validation runtime. Keep the existing AVX oracle and numerical bound; do not add a production quantizer-selection mechanism for this incorrect scratch assembly.',
        evidence=dict(summary=identity(N/'checks2-cpu/summary.json'),driver=identity(N/'checks2-cpu/frontier.driver.json'),log=identity(N/'checks2-cpu/run/stdout.log')),
        HTTP=0,native_runs_by_this_script=0,acceptance_changed=False,scope_increment=0)
    OUT.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'RCA':identity(OUT),'failure':record['failure'],'independent_check':record['independent_check']}))


if __name__=='__main__':main()
