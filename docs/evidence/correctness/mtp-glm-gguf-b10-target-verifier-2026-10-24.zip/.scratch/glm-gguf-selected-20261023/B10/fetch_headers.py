"""B10 metadata only, using the frozen B09 structural/strict HTTP reader.

No body acquisition, implicit download, guessed offset or B09 payload pin.
Root executes actual mode under the existing exclusive net-only run_batch.
"""
from pathlib import Path
import collections,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[2]
BASE=R/'.scratch/glm-gguf-selected-20261023/B09/fetch_headers.py'
BASE_SHA='5651141004eaa025b59fa24f2048a925d934d8678a6abf6e9a18fabeb016786c'

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 assert sha(BASE)==BASE_SHA,'Frozen common structural reader changed'
 spec=importlib.util.spec_from_file_location('_glm_b10_existing_header_reader',BASE)
 common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
 common.S=S;common.R=R;common.NEED=S/'headers-needed.json';common.SCHEMA=S/'roles-schema.json'
 common.LIMIT=18*1024*1024
 def checked():
  need,schema=read(common.NEED),read(common.SCHEMA)
  assert need['id']==schema['id']=='B10'
  assert (need['repository'],need['revision'])==(schema['repository'],schema['revision'])==('unsloth/GLM-5.3-GGUF','346b3591c7f28d1a23716f97a065ecf12ec14771')
  assert schema['variant']=='Q8_0' and schema['audit_key']=='glm53_q8_0'
  assert need['maximum_request_bytes']==common.REQUEST==262144
  assert [x['shard'] for x in need['files']]==[1,16,17]
  assert [x['metadata_limit_bytes'] for x in need['files']]==[16*1024*1024,1024*1024,1024*1024]
  assert need['metadata_upper_bound_bytes']==sum(x['metadata_limit_bytes'] for x in need['files'])==common.LIMIT
  assert common.identity(R/need['evidence']['path'])==need['evidence']==schema['evidence']
  census=read(R/need['evidence']['path'])[schema['audit_key']]
  assert census['complete'] and len(census['tensors'])==census['tensor_count']==1809
  assert (census['repo'],census['revision'],census['variant'])==(need['repository'],need['revision'],'Q8_0')
  rows={x['name']:x for x in census['tensors']};assert len(rows)==1809
  assert schema['physical_role_count']==len(schema['roles'])==53 and schema['static_roles']==47
  static=[x for x in schema['roles'] if not x['selected_source']]
  assert len(static)==47 and sum(x['bytes'] for x in static)==schema['static_bytes']==2566508544
  assert schema['expert_bytes_per_id']=={'layer77':40108032,'layer78':40108032}
  counts=collections.Counter(x['shard'] for x in census['tensors'])
  for source in need['files']:
   assert source['expected_tensor_count']==counts[source['shard']]
   assert source['file']==f"Q8_0/GLM-5.3-Q8_0-{source['shard']:05d}-of-00017.gguf"
   assert source['url']==f"https://huggingface.co/{need['repository']}/resolve/{need['revision']}/{source['file']}"
  for role in schema['roles']:
   row=rows[role['name']]
   assert (row['shard'],row['dtype'],list(map(int,row['shape'])))==(role['source_shard'],role['dtype'],role['gguf_dimensions'])
  for name,(path,pin) in common.PINNED.items():assert common.identity(R/path)['sha256']==pin,'Frozen metadata helper changed: '+name
  return need,schema,census
 common.checked=checked
 common.main()

if __name__=='__main__':main()
