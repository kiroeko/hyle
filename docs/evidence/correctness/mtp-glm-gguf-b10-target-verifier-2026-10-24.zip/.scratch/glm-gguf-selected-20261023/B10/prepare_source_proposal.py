"""Offline shared source/codec proposal; never edits canonical files."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess

S=Path(__file__).resolve().parent/'source-proposal';R=S.parents[3]
NAMES=['glm_gguf_named_parameters.h','glm_gguf_runtime_source.h','glm_gguf_expert_frontier.h',
       'glm_gguf_projection_fragment.h','glm_gguf_mtp_fragment.h','glm_pro_mtp_state_consumer_test.cc']
for name in NAMES:
 rel=Path('tests/compute_models')/name
 old=S/'before'/rel;new=S/'next-source'/rel
 old.parent.mkdir(parents=True,exist_ok=True);new.parent.mkdir(parents=True,exist_ok=True)
 if old.exists():assert old.read_bytes()==(R/rel).read_bytes(),'before source changed'
 else:old.write_bytes((R/rel).read_bytes())
 new.write_bytes(old.read_bytes())

def edit(name,fn):
 p=S/'next-source/tests/compute_models'/name;t=p.read_text();t=fn(t)
 original=(S/'before/tests/compute_models'/name).read_bytes()
 t=t.replace('\r\n','\n')
 if b'\r\n' in original:t=t.replace('\n','\r\n')
 p.write_bytes(t.encode('utf8'))
def once(t,a,b):
 assert t.count(a)==1,(a[:100],t.count(a));return t.replace(a,b)

def named(t):
 t=once(t,'inline constexpr std::size_t kStaticRoles=47;',
     'inline constexpr std::int64_t kTargetLayer=77,kNextnLayer=78;\ninline constexpr std::size_t kStaticRoles=47;')
 t=once(t,'''  if(s.native!=8)throw std::runtime_error("B09 static packed source is not its original Q8_0");
  if(s.rank!=2&&s.rank!=3)throw std::runtime_error("B09 static packed rank differs");
  auto d=s.rank==2?c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,
      c::DataType::kFloat32,s.gguf_dimensions[0],s.gguf_dimensions[1]):
      c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,
      c::DataType::kFloat32,s.gguf_dimensions[2],s.gguf_dimensions[1],s.gguf_dimensions[0]);''',
'''  const auto codec=s.native==8?c::GgufQuantizedType::kQ8_0:
      s.native==12?c::GgufQuantizedType::kQ4K:s.native==13?c::GgufQuantizedType::kQ5K:
      s.native==14?c::GgufQuantizedType::kQ6K:throw std::runtime_error("converted source native codec is not implemented");
  if(s.rank!=2&&s.rank!=3)throw std::runtime_error("converted packed source rank differs");
  auto d=s.rank==2?c::gguf_weight_description(codec,
      c::DataType::kFloat32,s.gguf_dimensions[0],s.gguf_dimensions[1]):
      c::gguf_grouped_weight_description(codec,
      c::DataType::kFloat32,s.gguf_dimensions[2],s.gguf_dimensions[1],s.gguf_dimensions[0]);''')
 t=once(t,'''    std::span<const original_named_role_source::PinnedFile> files) {
  if(files.size()!=kStaticRoles)throw std::runtime_error("B09 needs all 47 distinct actual static pins");
  std::vector<original_named_role_source::ManifestSpec> result;result.reserve(kStaticRoles);
  std::uint64_t extent=0;
  for(std::size_t i=0;i<kStaticRoles;++i) {
    const auto &s=kStaticSpecs[i];auto d=description(s);''',
'''    std::span<const Spec> specs,std::span<const original_named_role_source::PinnedFile> files,std::uint64_t expected_bytes) {
  if(specs.empty()||files.size()!=specs.size())throw std::runtime_error("converted manifest needs every distinct actual static pin");
  std::vector<original_named_role_source::ManifestSpec> result;result.reserve(specs.size());
  std::uint64_t extent=0;
  for(std::size_t i=0;i<specs.size();++i) {
    const auto &s=specs[i];auto d=description(s);''')
 t=once(t,'    extent+=s.bytes;',
'''    if(s.bytes>std::numeric_limits<std::uint64_t>::max()-extent)throw std::runtime_error("converted static extent overflows");
    extent+=s.bytes;''')
 t=once(t,'  if(extent!=kStaticBytes)throw std::runtime_error("B09 static role byte accounting differs");',
'''  if(extent==0||extent!=expected_bytes)throw std::runtime_error("converted static role byte accounting differs from its explicit manifest");''')
 t=once(t,'Parameters parameter_values(const Lookup &value) {',
'''Parameters parameter_values(const Lookup &value,std::int64_t target_layer,std::int64_t nextn_layer) {
  if(target_layer<0||nextn_layer<=target_layer)throw std::runtime_error("converted source requires its actual target/NextN layer names");''')
 t=once(t,'    const auto name="blk."+std::to_string(77+index)+".";',
            '    const auto name="blk."+std::to_string(index==0?target_layer:nextn_layer)+".";')
 t=once(t,'''  p.eh=value("blk.78.nextn.eh_proj.weight");p.embedding_norm=value("blk.78.nextn.enorm.weight");
  p.hidden_norm=value("blk.78.nextn.hnorm.weight");p.shared_norm=value("blk.78.nextn.shared_head_norm.weight");''',
'''  const auto nextn="blk."+std::to_string(nextn_layer)+".nextn.";
  p.eh=value(nextn+"eh_proj.weight");p.embedding_norm=value(nextn+"enorm.weight");
  p.hidden_norm=value(nextn+"hnorm.weight");p.shared_norm=value(nextn+"shared_head_norm.weight");''')
 t=once(t,'''Connected<Bound> connect(sem::Fragment &f,Bound bound) {
  if(!bound.source)throw std::runtime_error("B09 actual named source is absent");
  const auto &id=bound.source->identity();
  if(id.repository!=kRepository||id.revision!=kRevision||id.variant!=kVariant||id.file!=kFirstFile||
      bound.source->size()!=kStaticRoles)
    throw std::runtime_error("B09 source identity/count cannot borrow another GLM layer or artifact");
  Connected<Bound> result{std::move(bound),{}, {}};
  result.constants.reserve(kStaticRoles);
  std::unordered_map<std::string_view,Value> values;values.reserve(kStaticRoles);
  for(const auto &s:kStaticSpecs) {
    const auto d=description(s);const auto &role=result.bound.at(s.name);''',
'''Connected<Bound> connect(sem::Fragment &f,Bound bound,std::int64_t target_layer,std::int64_t nextn_layer) {
  if(!bound.source)throw std::runtime_error("converted actual named source is absent");
  // Data::load has already authenticated the explicit identity and every
  // native/descriptor/name/file/SHA. Do not reselect an artifact by model ID.
  Connected<Bound> result{std::move(bound),{}, {}};
  const auto count=result.bound.source->size();result.constants.reserve(count);
  std::unordered_map<std::string_view,Value> values;values.reserve(count);
  for(std::size_t slot=0;slot<count;++slot) {
    const auto &s=result.bound.source->spec(result.bound.source->name(slot));
    const auto &d=s.description;const auto &role=result.bound.at(s.name);''')
 t=once(t,'  result.parameters=parameter_values(value);','  result.parameters=parameter_values(value,target_layer,nextn_layer);')
 return t
edit(NAMES[0],named)

def source(t):
 start=t.index('struct Contract final {');end=t.index('class ExpertSet final {')
 t=t[:start]+'''struct Bank final {
  std::string name;ggml_type native;
  c::TensorDesc description; // Logical full canonical metadata; no full W.
};
struct Contract final {
  Section section;
  std::string plan_sha256,repository,revision,variant;
  std::array<Bank,3> banks;
};
inline c::TensorDesc expert_bank_description(const Bank &bank) {
  const auto &d=bank.description;const auto codec=c::gguf_quantized_type(d.storage_format());
  if(!codec||d.rank()!=3||d.data_type()!=c::DataType::kFloat32||
      named::native_codec(*codec)!=bank.native||std::ranges::any_of(d.dimensions(),[](auto n){return n<=0;}))
    throw std::runtime_error("converted expert bank native/canonical descriptor differs");
  const auto canonical=c::gguf_grouped_weight_description(*codec,c::DataType::kFloat32,
      d.dimensions()[0],d.dimensions()[1],d.dimensions()[2]);
  if(!canonical||*canonical!=d||!d.required_bytes())
    throw std::runtime_error("converted original expert bank layout differs");return d;
}
inline Contract contract(Section section,std::string plan_sha256,const named::Identity &identity,
                         std::span<const data::Spec> actual_banks,std::int64_t layer) {
  (void)label(section);
  if(!data::actual_pin(plan_sha256)||identity.repository.empty()||identity.variant.empty()||identity.file.empty()||
      !named::pinned(identity.revision,40)||layer<0)
    throw std::runtime_error("converted selected source needs explicit authenticated identity/layer/range-plan");
  Contract r{section,std::move(plan_sha256),std::string(identity.repository),std::string(identity.revision),std::string(identity.variant),{}};
  constexpr std::array<std::string_view,3> suffix{"ffn_gate_exps.weight","ffn_up_exps.weight","ffn_down_exps.weight"};
  for(std::size_t leg=0;leg<3;++leg) {
    const auto name="blk."+std::to_string(layer)+"."+std::string(suffix[leg]);
    const data::Spec *found=nullptr;
    for(const auto &spec:actual_banks)if(spec.name==name) {
      if(found)throw std::runtime_error("duplicate converted original expert bank metadata");found=&spec;
    }
    if(!found||found->rank!=3)throw std::runtime_error("converted original expert bank metadata is absent");
    const auto d=data::description(*found);
    if(!d.required_bytes()||*d.required_bytes()!=found->bytes)
      throw std::runtime_error("converted original expert bank byte extent differs");
    r.banks[leg]={name,static_cast<ggml_type>(found->native),d};
    (void)expert_bank_description(r.banks[leg]);
  }
  const auto domain=r.banks[0].description.dimensions()[0];
  if(domain>std::numeric_limits<std::int32_t>::max()||r.banks[1].description.dimensions()[0]!=domain||
      r.banks[2].description.dimensions()[0]!=domain)
    throw std::runtime_error("converted expert legs disagree about their original domain");return r;
}
'''+t[end:]
 t=once(t,'global<0||global>=256)','global<0||global>=expert_bank_description(c.banks[0]).dimensions()[0])')
 t=once(t,'''  Experts(Contract c,const glm_moe_geometry::Geometry &g):contract_(std::move(c)),geometry(g){glm_moe_geometry::require(g);}''',
'''  Experts(Contract c,const glm_moe_geometry::Geometry &g):contract_(std::move(c)),geometry(g){
    glm_moe_geometry::require(g);
    for(std::size_t leg=0;leg<3;++leg) {
      const auto d=expert_bank_description(contract_.banks[leg]);
      if(d.dimensions()[0]!=g.experts||d.dimensions()[1]!=(leg==2?g.hidden:g.intermediate)||
          d.dimensions()[2]!=(leg==2?g.intermediate:g.hidden))
        throw std::runtime_error("converted source geometry differs from the three actual expert descriptors");
    }
  }''')
 t=once(t,'''    if(!set||set->source_contract().section!=contract_.section||set->source_contract().plan_sha256!=contract_.plan_sha256)''',
'''    if(!set||set->source_contract().section!=contract_.section||set->source_contract().plan_sha256!=contract_.plan_sha256||
        set->source_contract().repository!=contract_.repository||set->source_contract().revision!=contract_.revision||
        set->source_contract().variant!=contract_.variant)''')
 return t
edit(NAMES[1],source)

def frontier(t):
 return once(t,'''string(t,"repository")!=source::data::kRepository||string(t,"revision")!=source::data::kRevision||''',
'''string(t,"repository")!=c.repository||string(t,"revision")!=c.revision||string(t,"variant")!=c.variant||''')
edit(NAMES[2],frontier)

def projection(t):
 return once(t,'''    return glm_gguf_projection_fragment::linear(f,input,weight);''',
'''    return f.description(weight).is_plain()?glm_gguf_projection_fragment::f32_linear(f,input,weight):
        glm_gguf_projection_fragment::linear(f,input,weight);''')
edit(NAMES[3],projection)
edit(NAMES[4],lambda t:once(t,'r.ports.index_weights=leaf::f32_linear(f,prefix.input_norm.output,p.block.index_weights);',
                          'r.ports.index_weights=project.linear(f,prefix.input_norm.output,p.block.index_weights);'))

def consumer(t):
 t=once(t,'''  return converted_data::parameter_values([&](std::string_view name) {''',
'''  return converted_data::parameter_values([&](std::string_view name) {''')
 t=once(t,'''    return step.recipe.fragment.constants.at(found->slot);
  });
}
glm_gguf_named_parameters::Parameters converted_parameters''',
'''    return step.recipe.fragment.constants.at(found->slot);
  },converted_data::kTargetLayer,converted_data::kNextnLayer);
}
glm_gguf_named_parameters::Parameters converted_parameters''')
 t=once(t,'converted_data::connect(r.fragment,bound);',
            'converted_data::connect(r.fragment,bound,converted_data::kTargetLayer,converted_data::kNextnLayer);')
 t=once(t,'converted_data::manifest(artifact::kStaticPins)',
            'converted_data::manifest(converted_data::kStaticSpecs,artifact::kStaticPins,converted_data::kStaticBytes)')
 t=once(t,'''        std::string(artifact::kExpertSourcePlanSha256)),kMoe);''',
'''        std::string(artifact::kExpertSourcePlanSha256),data->identity(),converted_data::kExpertSpecs,converted_data::kNextnLayer),kMoe);''')
 t=once(t,'''        nextn.experts.source->source_contract().plan_sha256),kMoe);''',
'''        nextn.experts.source->source_contract().plan_sha256,nextn.parameters.source->identity(),
        converted_data::kExpertSpecs,converted_data::kTargetLayer),kMoe);''')
 return t
edit(NAMES[5],consumer)

patch=[];identities=[]
def identity(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for name in NAMES:
 rel=Path('tests/compute_models')/name;old=S/'before'/rel;new=S/'next-source'/rel
 patch.append(f'diff --git a/{rel.as_posix()} b/{rel.as_posix()}\n')
 patch.extend(difflib.unified_diff(old.read_bytes().decode().splitlines(keepends=True),new.read_bytes().decode().splitlines(keepends=True),fromfile='a/'+rel.as_posix(),tofile='b/'+rel.as_posix()))
 identities.append(dict(path=rel.as_posix(),before=identity(old),after=identity(new)))
p=S/'source.patch';p.write_text(''.join(patch),encoding='utf8',newline='\n')
check=subprocess.run(['git','apply','--check',str(p)],cwd=R,text=True,capture_output=True)
assert check.returncode==0,check.stderr
ready=dict(scope='offline six-source cold metadata/descriptor proposal;0HTTP/build/native/apply',patch=identity(p),sources=identities,
    git_apply_check=dict(exit_code=check.returncode,stderr=check.stderr),
    changes=['Common named binding iterates actual authenticated Data metadata; identity authentication remains Data::load with explicit fixture identity',
             'Manifest accepts caller explicit immutable specs and pins; duplicate/dtype/shape/byte SHA checks remain in the same Data',
             'Three-bank Contract owns identity/name/descriptor; no string_view refers to a temporary schema',
             'Q8_0 and Kquant expert admission uses canonical descriptor/native mapping; domain/shape/stride derive from actual bank',
             'Index weight uses descriptor-selected plain F32 or packed leaf; B09 plain path generates the same nodes',
             'B09 fixture passes original47 specs/pins, original77/78 names and originalbank facts explicitly; no second runtime/controller'],
    remaining=['Actual B10 metadata/absolute plans/static acquisition/pins not yet present; no B10 case registered',
               'Future B10 fixture supplies its own identity/specs/pins/profile/env to the same converted Runtime preparation seam; same Pro geometry must be checked from actual header',
               'B12/B13 Flash pooled index+HC/KDA source adapters remain separate implementation work, not claimed by this Pro source patch'],
    unverified=['No compile/native performed; parent applies and checks the affected Pro TU using actual cached artifacts'])
(S/'ready.json').write_text(json.dumps(ready,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(patch=identity(p),ready=identity(S/'ready.json'),files=len(NAMES),git_apply_check=0)))
