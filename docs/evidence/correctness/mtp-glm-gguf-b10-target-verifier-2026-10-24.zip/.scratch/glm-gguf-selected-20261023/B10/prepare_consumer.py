"""Offline B10 thin fixture delta; never modifies canonical product files."""
from pathlib import Path
import hashlib
import json
import difflib

R=Path(__file__).resolve().parents[3]
S=Path(__file__).resolve().parent
P=S/'consumer-proposal'
TU='tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
HEADER='tests/compute_models/glm_gguf_runtime_source.h'
BEFORE={TU:'ef8bf223fd7d100a32f610a220d4f4e8a910f8abe8ffac026134dbe3a31019df',
 HEADER:'2638dea8b131fc14484c9622193baccc201556fe44bfea7570e6c455732c1d55'}
def identity(path):
 b=path.read_bytes();return dict(path=path.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def replace(text,old,new):
 assert text.count(old)==1,old[:100]
 return text.replace(old,new)
def source_bytes(original,text):
 # Preserve every unchanged source line's exact original newline; do not turn
 # prior mixed-CRLF snapshots into an unrelated whole-file formatting delta.
 raw=original.decode().splitlines(keepends=True)
 before=[line.rstrip('\r\n') for line in raw];after=text.splitlines()
 output=[]
 for kind,i,j,k,l in difflib.SequenceMatcher(a=before,b=after,autojunk=False).get_opcodes():
  output.extend(raw[i:j] if kind=='equal' else [line+'\r\n' for line in after[k:l]])
 return ''.join(output).encode()

def main():
 originals={}
 for name,pin in BEFORE.items():
  path=R/name;assert identity(path)['sha256']==pin,name
  originals[name]=path.read_bytes()
  p=P/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(originals[name])
 h=originals[HEADER].decode().replace('\r\n','\n')
 h=replace(h,'#include <functional>','#include <functional>\n#include <optional>\n#include "hyle/compute/workload.h"')
 h=replace(h,'  using CpuBatch=Batch;','  using CpuBatch=Batch;\n  const c::ModelArtifactProfileDescription *profile=nullptr; // Cold actual artifact, never selected in execution.')
 h=replace(h,'struct Source final:ResidentSource {named::Roles parameters;Words words;std::array<Readonly,2> prepared;};',
 '''struct Source final:ResidentSource {
  named::Roles parameters;Words words;std::array<Readonly,2> prepared;
  std::optional<Contract> target_contract;
  std::filesystem::path expert_directory,frontier_file;
  bool wait_for_experts=false;
};''')
 t=originals[TU].decode().replace('\r\n','\n')
 t=replace(t,'#include <memory>','#include <memory>\n#include <mutex>')
 t=replace(t,'#define HYLE_TEST_GLM_B09_ACTUAL_PINS 1\n#endif',
 '''#define HYLE_TEST_GLM_B09_ACTUAL_PINS 1
#endif
#if __has_include("glm_gguf_b10_artifacts.h")
#include "glm_gguf_b10_artifacts.h"
#define HYLE_TEST_GLM_B10_ACTUAL_PINS 1
#endif''')
 first=t.index('std::function<void(std::span<const std::int32_t>)> converted_frontier(')
 last=t.index('std::vector<float> converted_fixture(',first)
 t=t[:first]+'''// Each explicit fixture owns its authenticated host source cache. No common
// static Data can accidentally retain B09 while a B10 case changes its path.
struct ConvertedFixture final {
  const c::ModelArtifactProfileDescription *profile;
  original_named_role_source::Identity identity;
  std::span<const converted_data::Spec> statics,experts;
  std::span<const original_named_role_source::PinnedFile> pins;
  std::uint64_t static_bytes;
  std::string_view expert_plan;
  const char *role_env,*expert_env,*frontier_env,*wait_env;
  mutable std::mutex mutex;
  mutable std::filesystem::path loaded_directory;
  mutable std::shared_ptr<const original_named_role_source::Data> loaded;
  std::shared_ptr<const original_named_role_source::Data> data()const {
    if(!profile||profile->artifact_repository!=identity.repository||profile->artifact_revision!=identity.revision||
        profile->variant!=identity.variant||profile->format_family!="gguf"||statics.size()!=47||experts.size()!=6||
        pins.size()!=statics.size()||!converted_data::actual_pin(expert_plan))
      throw std::runtime_error("converted fixture profile/source/schema/pins differ");
    const auto path=directory(role_env);if(path.empty())throw std::runtime_error("converted actual role directory is absent");
    const auto canonical=std::filesystem::weakly_canonical(path);std::lock_guard lock(mutex);
    if(loaded) {
      if(canonical!=loaded_directory)throw std::runtime_error("converted fixture path changed after its authenticated source was cached");
      return loaded;
    }
    loaded=original_named_role_source::Data::load(canonical,identity,converted_data::manifest(statics,pins,static_bytes));
    loaded_directory=canonical;return loaded;
  }
};
const ConvertedFixture &converted_b09_fixture() {
#if !defined(HYLE_TEST_GLM_B09_ACTUAL_PINS)
  throw std::runtime_error("B09 complete actual static47 payload pins are absent; metadata is not executable supply");
#else
  namespace artifact=glm_gguf_b09_artifacts;
  static const ConvertedFixture fixture{&d5_moe_profile_cases::glm53_primary_gguf,
      {converted_data::kRepository,converted_data::kRevision,converted_data::kVariant,converted_data::kFirstFile},
      converted_data::kStaticSpecs,converted_data::kExpertSpecs,artifact::kStaticPins,converted_data::kStaticBytes,
      artifact::kExpertSourcePlanSha256,"HYLE_GLM_GGUF_B09_DIR","HYLE_GLM_GGUF_B09_EXPERT_DIR",
      "HYLE_GLM_GGUF_FRONTIER_FILE","HYLE_GLM_GGUF_WAIT_FOR_EXPERTS"};
  return fixture;
#endif
}
const ConvertedFixture &converted_b10_fixture() {
#if !defined(HYLE_TEST_GLM_B10_ACTUAL_PINS)
  throw std::runtime_error("B10 complete actual static47 payload pins are absent; metadata is not executable supply");
#else
  namespace artifact=glm_gguf_b10_artifacts;
  static const ConvertedFixture fixture{&d5_moe_profile_cases::glm53_fidelity_gguf,
      {artifact::kRepository,artifact::kRevision,artifact::kVariant,artifact::kFirstFile},
      artifact::kStaticSpecs47,artifact::kExpertSpecs6,artifact::kStaticPins47,artifact::kStaticBytes,
      artifact::kExpertSourcePlanSha256,"HYLE_GLM_GGUF_B10_DIR","HYLE_GLM_GGUF_B10_EXPERT_DIR",
      "HYLE_GLM_GGUF_FRONTIER_FILE","HYLE_GLM_GGUF_WAIT_FOR_EXPERTS"};
  return fixture;
#endif
}
std::function<void(std::span<const std::int32_t>)> converted_frontier(std::shared_ptr<converted_source::Experts> selected,
    const std::filesystem::path &expert_root,const std::filesystem::path &request,bool wait) {
  if(expert_root.empty())throw std::runtime_error("converted explicit selected-expert cache directory is absent");
  auto frontier=std::make_shared<glm_gguf_expert_frontier::Frontier>(glm_gguf_expert_frontier::Frontier{
      std::move(selected),expert_root,request,wait});
  return [frontier](std::span<const std::int32_t> actual_ids){frontier->ensure(actual_ids);};
}
const c::ModelArtifactProfileDescription *converted_profile(const converted_source::ResidentSource &source) {
  if(!source.profile)throw std::runtime_error("converted cold Graph needs its bound artifact profile");return source.profile;
}
''' +t[last:]
 # Only converted factories use the existing primary pointer; the old official
 # model factories retain their existing metadata and arithmetic verbatim.
 first=t.index('namespace converted=glm_gguf_mtp_fragment;')
 last=t.index('template<class Runtime=OfficialRuntime>',first)
 chunk=t[first:last]
 assert chunk.count('f.profile=&d5_moe_profile_cases::glm53_primary_gguf;')==5
 chunk=chunk.replace('f.profile=&d5_moe_profile_cases::glm53_primary_gguf;','f.profile=converted_profile(source);')
 t=t[:first]+chunk+t[last:]
 first=t.index('  static std::shared_ptr<converted_source::Source> prepare_source(',t.index('struct ConvertedRuntime final'))
 last=t.index('  static Initial build_initial()',first)
 t=t[:first]+'''  static std::shared_ptr<converted_source::Source> prepare_source(c::Context &,const c::StorageOwner &owner,c::Queue &,bool cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      ,const c::cuda::MemoryResource *
#endif
      ,const ConvertedFixture *selected_fixture=nullptr) {
    const auto &fixture=selected_fixture?*selected_fixture:converted_b09_fixture();
    const auto expert_directory=directory(fixture.expert_env);
    if(expert_directory.empty())throw std::runtime_error("converted selected-expert cache directory is absent");
    const auto data=fixture.data();
    auto source=std::make_shared<converted_source::Source>();source->parameters=original_named_role_source::bind(data,owner);
    source->cuda=cuda;source->profile=fixture.profile;source->expert_directory=expert_directory;
    source->frontier_file=directory(fixture.frontier_env);source->wait_for_experts=directory(fixture.wait_env)=="1";
    source->words.source=data;
    source->words.roles={converted_source::readonly(source->parameters.at("token_embd.weight")),
        converted_source::readonly(source->parameters.at("output.weight")),converted_source::readonly(source->parameters.at("blk.78.nextn.shared_head_norm.weight"))};
    source->target_contract=converted_source::contract(converted_source::Section::kTarget,
        std::string(fixture.expert_plan),data->identity(),fixture.experts,converted_data::kTargetLayer);
    auto selected=std::make_shared<converted_source::Experts>(converted_source::contract(converted_source::Section::kDraft,
        std::string(fixture.expert_plan),data->identity(),fixture.experts,converted_data::kNextnLayer),kMoe);
    source->experts.source=selected;
    source->before_upload=converted_frontier(selected,source->expert_directory,source->frontier_file,source->wait_for_experts);
    source->cpu_supply=std::make_unique<converted_source::Supply>(take(converted_source::Supply::create(owner,*selected),"converted packed selected native pool"));return source;
  }
  static std::shared_ptr<TargetSource> prepare_target_source(const converted_source::Source &nextn,c::Context &,
      const c::StorageOwner &owner,c::Queue &,bool cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      ,const c::cuda::MemoryResource *
#endif
      ) {
    if(!nextn.target_contract)throw std::runtime_error("converted distinct target source metadata was not prepared");
    auto source=std::make_shared<TargetSource>();source->parameters=nextn.parameters;source->cuda=cuda;source->profile=nextn.profile;
    auto selected=std::make_shared<converted_source::Experts>(*nextn.target_contract,kMoe);
    source->experts.source=selected;
    source->before_upload=converted_frontier(selected,nextn.expert_directory,nextn.frontier_file,nextn.wait_for_experts);
    source->cpu_supply=std::make_unique<converted_source::Supply>(take(converted_source::Supply::create(owner,*selected),"converted distinct77 selected packed pool"));return source;
  }
''' +t[last:]
 first=t.index('struct ConvertedRuntime final')
 last=t.index('template<class Runtime=OfficialRuntime>',first)
 chunk=t[first:last]
 chunk=replace(chunk,'  static Initial build_initial() {','  static Initial build_initial(const converted_source::Source &source) {')
 t=t[:first]+chunk+t[last:]
 first=t.index('template<class Runtime=OfficialRuntime>')
 last=t.index('  std::shared_ptr<typename Runtime::TargetSource> target_source;',first)
 old=t[first:last]
 new=old.replace('    ) {','    ,const ConvertedFixture *packed_fixture=nullptr) {',1)
 before='''  auto source=Runtime::prepare_source(context,owner,queue,cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      ,device
#endif
      );
'''
 after='''  auto source=[&] {
    if constexpr(Runtime::kPacked)return Runtime::prepare_source(context,owner,queue,cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
        ,device
#endif
        ,packed_fixture);
    else {
      if(packed_fixture)throw std::runtime_error("a converted fixture cannot replace an official source");
      return Runtime::prepare_source(context,owner,queue,cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
          ,device
#endif
          );
    }
  }();
'''
 new=replace(new,before,after);t=t[:first]+new+t[last:]
 t=replace(t,'    auto initializer=Runtime::build_initial();','''    auto initializer=[&] {
      if constexpr(Runtime::kPacked)return Runtime::build_initial(*source);
      else return Runtime::build_initial();
    }();''')
 old='''      ::testing::Test::RecordProperty("artifact_identity","B09 unsloth/GLM-5.3-GGUF@346b3591c7f28d1a23716f97a065ecf12ec14771 UD-Q4_K_XL");'''
 new='''      const auto &artifact=source->parameters.source->identity();
      ::testing::Test::RecordProperty("artifact_identity",std::string(artifact.repository)+"@"+std::string(artifact.revision)+" "+std::string(artifact.variant));
      ::testing::Test::RecordProperty("artifact_repository",std::string(artifact.repository));
      ::testing::Test::RecordProperty("artifact_revision",std::string(artifact.revision));
      ::testing::Test::RecordProperty("artifact_variant",std::string(artifact.variant));
      ::testing::Test::RecordProperty("artifact_first_file",std::string(artifact.file));
      ::testing::Test::RecordProperty("expert_source_plan_sha256",source->experts.source->source_contract().plan_sha256);
      ::testing::Test::RecordProperty("static_source_roles",std::to_string(source->parameters.source->size()));
      std::size_t static_bytes=0;
      for(std::size_t i=0;i<source->parameters.source->size();++i)
        add_bound(static_bytes,source->parameters.source->spec(source->parameters.source->name(i)).bytes);
      ::testing::Test::RecordProperty("static_source_bytes",std::to_string(static_bytes));'''
 t=replace(t,old,new)
 old='''TEST(GlmProMtpStateConsumer,CudaConvertedB09TargetAndNextNFullVocabularyVerifier)'''
 first=t.index(old);last=t.index('\n#endif',first)
 t=t[:last]+'''
TEST(GlmProMtpStateConsumer,CudaConvertedB10TargetAndNextNFullVocabularyVerifier) {
  const auto &fixture=converted_b10_fixture();
  auto context=take(g::cuda::create_context(),"B10 CUDA Context");
  auto device=std::make_shared<c::cuda::MemoryResource>(take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"B10 actual device"));
  const auto owner=take(c::StorageOwner::adopt(context,SharedCudaDevice{device}),"B10 actual shared owner");
  run<ConvertedRuntime>(context,owner,true,true,device.get(),&fixture);
}
''' +t[last:]
 first=t.index('TEST(GlmProMtpStateConsumer,CpuConvertedB09TargetAndNextNFullVocabularyVerifier)');last=t.index('\n#endif',first)
 t=t[:last]+'''
TEST(GlmProMtpStateConsumer,CpuConvertedB10TargetAndNextNFullVocabularyVerifier) {
  const auto &fixture=converted_b10_fixture();
  auto context=take(g::cpu::create_context(),"B10 CPU Context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"B10 actual CPU owner");
  run<ConvertedRuntime>(context,owner,false,true
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      ,nullptr
#endif
      ,&fixture);
}
''' +t[last:]
 afters={HEADER:h,TU:t};items=[];patches=[]
 for name,text in afters.items():
  p=P/'next-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(source_bytes(originals[name],text))
  old=originals[name].decode();new=p.read_bytes().decode()
  patches.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
  items.append(dict(path=name,before=identity(P/'before'/name),after=identity(p)))
 patch=P/'source.patch';patch.write_bytes(''.join(patches).encode())
 info=dict(status='offline thin B10 fixture proposal; not applied/built/native',patch=identity(patch),files=items,
  source_identity='Each explicit B09/B10 fixture independently authenticates/caches its actual directory/identity/manifest. Bound native roles retain their own Data and actual StorageOwner.',
  runtime='One unchanged ConvertedRuntime execution/K1/StateHead/reference path; cold fixture parameter only.',
  b09='Original profile pointer, actual default47/6 schemas, role names, arithmetic and operations preserved. Only metadata/source-cache preparation is explicit.',
  b10='Actual generated47/6 schemas + pins + Q8_0 profile; no official/B09 payload substitution. Missing actual generated header throws before Context/source creation.',
  cases=['GlmProMtpStateConsumer.CpuConvertedB10TargetAndNextNFullVocabularyVerifier','GlmProMtpStateConsumer.CudaConvertedB10TargetAndNextNFullVocabularyVerifier'],
  environment=['HYLE_GLM_GGUF_B10_DIR','HYLE_GLM_GGUF_B10_EXPERT_DIR','HYLE_GLM_GGUF_FRONTIER_FILE','HYLE_GLM_GGUF_WAIT_FOR_EXPERTS'],
  required_header='B10/generated/glm_gguf_b10_artifacts.h from actual complete acquisition via generate_artifacts.py',
  graph_changes='None to B09 arithmetic or nodes. Every converted cold Graph now obtains the actual profile from its bound Source, including initialization/catchup/target/head.',
  properties='Actual artifact identity/file/variant/count/bytes from bound Data, expert source plan from actual attached Contract; no artifact-name guess.',
  builds=0,native_runs=0,http_requests=0,canonical_edits=0)
 (P/'ready.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(dict(patch=identity(patch),ready=identity(P/'ready.json'),files=items)))

if __name__=='__main__':main()
