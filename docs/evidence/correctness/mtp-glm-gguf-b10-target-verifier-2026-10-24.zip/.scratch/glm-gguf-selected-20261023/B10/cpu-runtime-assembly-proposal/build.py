"""Repair only the hand-assembled mixed CPU module's missing target ISA flags."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import subprocess
import sys
import time

R = Path(__file__).resolve().parents[4]
S = Path(__file__).resolve().parent
OLD = R / '.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/mixed-native-preparation/native-plan.json'
OLD_SHA = '90bf7b729f098f81f698730c8851a7384f8f7eab4e0671c1773c2bf1d218d38d'
FLAGS = ['/DGGML_AVX', '/DGGML_AVX2', '/DGGML_FMA', '/DGGML_F16C', '/DGGML_BMI2', '/D__BMI2__', '/arch:AVX2']


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def check(record):
    actual = identity(record['path'])
    if actual['sha256'] != record['sha256'] or actual['bytes'] != record['bytes']:
        raise ValueError('Frozen input changed: ' + record['path'])
    return actual


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def argv(command):
    return [x.strip('"') for x in shlex.split(command, posix=False)] if isinstance(command, str) else list(command)


def prepare(attempt):
    if identity(OLD)['sha256'] != OLD_SHA:
        raise ValueError('Original mixed plan changed')
    old = json.loads(OLD.read_text())
    out = S.parent / f'cpu-native-avx2-corrected{attempt}'
    jobs, replacements = [], {}
    retained = list(old['retained_cpu']) + [old['hadamard']]
    if len(retained) != 15:
        raise ValueError('Expected the exact fourteen CPU objects plus same-family Hadamard')
    for ordinal, item in enumerate(retained):
        source, old_object = check(item['source']), check(item['object'])
        command = argv(item['command'])
        if any('AVX2' in x.upper() for x in command):
            raise ValueError('Unexpected already-AVX2 retained object')
        command = [x for x in command if not x.lower().startswith(('/fo', '/fd'))]
        tag = f'{ordinal:02d}-' + Path(source['path']).name.replace('.', '-')
        obj, deps = out / (tag + '.obj'), out / (tag + '-deps.json')
        command += FLAGS + ['/I' + str(R / 'include'), '/sourceDependencies', str(deps),
                            '/Fo' + str(obj), '/Fd' + str(out / (tag + '.pdb'))]
        jobs.append(dict(name=tag, source=source, old_object=old_object, command=command,
                         object=str(obj), dependencies=str(deps)))
        replacements[str(Path(old_object['path'])).lower()] = str(obj)

    reused = []
    for item in old['jobs'][:2]:
        if not all(flag in item['command'] for flag in FLAGS):
            raise ValueError('Owning ops/export were not compiled with target AVX2 flags')
        reused.append(dict(name=item['name'], source=check(item['source']),
                           object=identity(item['object']), command=item['command'],
                           dependencies=identity(item['dependencies'])))
    for item in old['owning_headers']:
        check(item)
    base = check(old['base_library'])
    link = []
    for value in old['jobs'][-1]['command']:
        key = str(Path(value)).lower()
        if key in replacements:
            value = replacements[key]
        elif value.upper().startswith('/OUT:'):
            value = '/OUT:' + str(out / 'hyle_ggml_cpu_gdn_scale_v3.dll')
        elif value.upper().startswith('/IMPLIB:'):
            value = '/IMPLIB:' + str(out / 'corrected-module.lib')
        elif value.upper().startswith('/MAP:'):
            value = '/MAP:' + str(out / 'corrected-module.map')
        link.append(value)
    if any(str(Path(x)).lower() in replacements for x in link):
        raise ValueError('Old baseline CPU object remains in corrected link')
    if len([x for x in link if x.lower().endswith('.obj')]) != 17:
        raise ValueError('Corrected module must contain fifteen new objects and two owning objects')
    plan = dict(status='Prepared commands; no compilation implied', entry=identity(__file__),
                original_plan=identity(OLD), output_directory=str(out), flags=FLAGS,
                canonical_target=[identity(R / 'src/compute_ggml_runtime/cpu_program.cmake'),
                                  identity(R / 'cmake/HyleIsa.cmake')],
                jobs=jobs, reused_owning_objects=reused, base_library=base,
                link_command=link, maximum_parallel_compiles=2,
                compile_TUs=15, SDK_builds=0, NVCC_builds=0, HTTP=0,
                scope='Same mixed source/ABI; correct all missing AVX2 target flags, no math/reference/product edit.')
    save(S / f'plan{attempt}.json', plan)
    cmd = '@echo off\r\ncall "C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\VC\\Auxiliary\\Build\\vcvars64.bat"\r\nif errorlevel 1 exit /b %errorlevel%\r\n'
    cmd += subprocess.list2cmdline([sys.executable, str(Path(__file__).resolve()), 'build', '--attempt', str(attempt)]) + '\r\nexit /b %errorlevel%\r\n'
    (S / f'build{attempt}.cmd').write_bytes(cmd.encode('utf-8'))
    return plan


def build(attempt):
    plan = json.loads((S / f'plan{attempt}.json').read_text())
    check(plan['entry'])
    for job in plan['jobs']:
        check(job['source']); check(job['old_object'])
    for job in plan['reused_owning_objects']:
        check(job['source']); check(job['object']); check(job['dependencies'])
    check(plan['base_library'])
    out = Path(plan['output_directory'])
    out.mkdir()  # New immutable attempt; never overwrite previous outputs.

    def compile_one(job):
        log = out / (job['name'] + '-stdout.log')
        start = time.time()
        with log.open('wb') as stream:
            process = subprocess.Popen(job['command'], cwd=R, stdout=stream, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            result = process.wait()
        record = dict(job, pid=process.pid, exit=result, started=start, finished=time.time(), log=identity(log))
        if result == 0:
            record.update(actual_object=identity(job['object']), actual_dependencies=identity(job['dependencies']))
        check(job['source'])
        save(out / (job['name'] + '-record.json'), record)
        print(json.dumps(dict(job=job['name'], exit=result, seconds=record['finished'] - start)), flush=True)
        return record

    records = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(compile_one, job) for job in plan['jobs']]):
            records.append(future.result())
    if any(x['exit'] != 0 for x in records):
        save(out / 'result.json', dict(passed=False, compile_records=records, linked=False))
        return 1
    log = out / 'link-stdout.log'
    start = time.time()
    with log.open('wb') as stream:
        process = subprocess.Popen(plan['link_command'], cwd=R, stdout=stream, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        result = process.wait()
    link = dict(command=plan['link_command'], pid=process.pid, exit=result,
                started=start, finished=time.time(), log=identity(log))
    if result == 0:
        link.update(module=identity(out / 'hyle_ggml_cpu_gdn_scale_v3.dll'),
                    map=identity(out / 'corrected-module.map'))
    save(out / 'result.json', dict(passed=result == 0, plan=identity(S / f'plan{attempt}.json'),
                                  compile_records=records, reused=plan['reused_owning_objects'], link=link,
                                  model_runs=0, HTTP=0, SDK_builds=0, NVCC_builds=0))
    print(json.dumps(dict(link_exit=result, output=str(out))), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'build'))
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    if args.attempt < 1:
        raise ValueError('Positive fresh attempt required')
    if args.action == 'prepare':
        result = prepare(args.attempt)
        print(json.dumps(dict(plan=str(S / f'plan{args.attempt}.json'), compile_TUs=len(result['jobs']))))
    else:
        raise SystemExit(build(args.attempt))
