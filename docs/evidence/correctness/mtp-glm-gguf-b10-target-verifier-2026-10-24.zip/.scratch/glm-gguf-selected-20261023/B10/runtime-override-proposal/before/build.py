"""B10 one-Pro-TU overlay on the current parity closure; root executes only.

Original B10 pins/compile/link utilities remain unchanged. No run, download,
provider rebuild, SDK build, model controller or executor is added here.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ENTRY = Path(__file__).resolve()
A = ENTRY.parents[1]
R = next(p for p in ENTRY.parents if (p / 'AGENTS.md').is_file())
HOST = A / 'native-integration/build.py'
HOST_SHA = '96f154b81677aeeccf2cfb499818e5b0ab3bb24ff6ef8740cc1207e152a4b2d2'
CURRENT = R / '.scratch/mtp-packed-head-20261024/parity-current-integration/build.py'
CURRENT_SHA = '0fc11f36aa9e669ebf3d21876ed4c10fbd863c0ee43ef0c575c07ada96c6cacc'


def load(name, path, expected):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError('Frozen B10/current utility changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def configured():
    c = load('_b10_original_compile_link', HOST, HOST_SHA)
    current = load('_b10_actual_parity_closure', CURRENT, CURRENT_SHA)
    c.BASE = c.BASE_IMAGE = CURRENT.parent / 'current-link1'
    c.closure = lambda: current.closure(consumer_replaced=True)
    c.native_inputs = current.base.native_inputs
    if c.SOURCE != R / 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc':
        raise ValueError('B10 must compile its Pro consumer, not the Flash consumer')
    return c


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'compile', 'link'))
    parser.add_argument('--compile-attempt', type=int, default=2)
    parser.add_argument('--link-attempt', type=int, default=2)
    args = parser.parse_args()
    if min(args.compile_attempt, args.link_attempt) <= 0:
        raise ValueError('Positive unused attempts required')
    c = configured()
    header, proof, facts = c.pins()  # Actual47 completion is mandatory, even for this plan.
    if args.action == 'plan':
        print(json.dumps(dict(prepared_only=True, entry=c.identity(ENTRY), utility=c.identity(HOST),
            current_helper=c.identity(CURRENT), source=c.identity(c.SOURCE), recipe=c.identity(c.RECIPE),
            actual_pins=c.identity(header), actual_pin_receipt=c.identity(proof), actual_static=facts,
            base=str(c.BASE), native_manifest=c.identity(c.S / 'native-inputs.json'),
            consumer_TUs=1, product_TUs=0, SDK_builds=0, NVCC_builds=0, HTTP=0, native_runs=0,
            run_prepared=False)))
        return
    if args.action == 'compile':
        c.compile_one(args.compile_attempt)
        path = c.S / f'compile{args.compile_attempt}/glm-pro/identity.json'
        record = c.check_record(path)
        record.update(current_entry=c.identity(ENTRY), current_closure_helper=c.identity(CURRENT),
            source_scope='Actual B10 own Pro consumer/static47; current parity closure replaces only the retired Flash test object.')
        c.save(path, record)
    else:
        c.link(args.link_attempt, args.compile_attempt)
        out = c.S / f'tests-link{args.link_attempt}'
        plan = c.read(out / 'link-plan.json')
        plan.update(current_entry=c.identity(ENTRY), current_closure_helper=c.identity(CURRENT),
            source_scope='Actual B10 own Pro consumer; original Flash consumer removed, no B10 execution is implied.')
        c.save(out / 'link-plan.json', plan)
        ready = c.read(out / 'ready.json')
        ready.update(link_plan=c.identity(out / 'link-plan.json'), artifact='B10',
            scope='Actual B10 static47 and Pro TU on current parity closure; linked only.')
        c.save(out / 'ready.json', ready)


if __name__ == '__main__':
    main()
