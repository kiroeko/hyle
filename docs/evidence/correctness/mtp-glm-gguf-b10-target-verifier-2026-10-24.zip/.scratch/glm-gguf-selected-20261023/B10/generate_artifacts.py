"""Generate B10 actual pins/specs only after complete static47 acquisition.

Uses B09's frozen receipt/chunk/request validator with the actual B10 acquire
module. No HTTP or body rehash; absent/incomplete payloads cannot produce pins.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
BASE = R/'.scratch/glm-gguf-selected-20261023/B09/generate_artifacts.py'
BASE_SHA = 'c3269d20c925976748f685fcbc290f569c2e7e36eaa5b99a9d8f3e9539608583'
ACQUIRE_SHA = '0425e10c230289cf1ed10c1c57eb4c64fb9242fe3238157d07db2c0e18fc14cb'


def acquisition():
    path = S/'acquire.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == ACQUIRE_SHA, 'Frozen B10 acquire wrapper changed'
    spec = importlib.util.spec_from_file_location('_b10_actual_acquisition', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.configured()


def validate(directory):
    assert hashlib.sha256(BASE.read_bytes()).hexdigest() == BASE_SHA, 'Frozen common pin validator changed'
    spec = importlib.util.spec_from_file_location('_b10_existing_pin_validator', BASE)
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    validator.S, validator.R, validator.acquisition = S, R, acquisition
    return validator.validate(directory)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=S/'original-static')
    parser.add_argument('--output', type=Path, default=S/'generated/glm_gguf_b10_artifacts.h')
    args = parser.parse_args()
    directory = args.directory.resolve()
    a, record, manifest, expert = validate(directory)
    static = a.read(S/'static-plan.json')
    values = dict(kRepository=a.REPO, kRevision=a.REV, kVariant=a.VARIANT,
        kFirstFile=static['shards'][0]['file'], kStaticPlanSha256=a.identity(S/'static-plan.json')['sha256'],
        kExpertSourcePlanSha256=a.identity(S/'expert-source-plan.json')['sha256'],
        kStaticAcquisitionSha256=a.identity(directory/'acquisition.json')['sha256'],
        kStaticManifestSha256=a.identity(directory/'manifest.json')['sha256'])
    lines = ['#pragma once', '#include <array>', '#include <string_view>',
        '#include "original_named_role_source.h"', '#include "glm_gguf_named_parameters.h"',
        '// Actual B10 Q8_0 files and source descriptors; expert payload pins are per requested ID.',
        'namespace glm_gguf_b10_artifacts {']
    lines += ['inline constexpr std::string_view '+key+'='+json.dumps(value)+';' for key, value in values.items()]
    lines += ['inline constexpr std::uint64_t kStaticBytes=2566508544ULL;',
        'inline const std::array<original_named_role_source::PinnedFile,47> kStaticPins47{{']
    lines += ['    {'+json.dumps(row['file'])+','+json.dumps(row['sha256'])+'},' for row in manifest['roles']]
    lines += ['}};', 'inline const auto &kStaticPins=kStaticPins47;']
    for name, rows in (('kStaticSpecs47', static['roles']), ('kExpertSpecs6', expert['roles'])):
        lines += [f'inline constexpr std::array<glm_gguf_named_parameters::Spec,{len(rows)}> {name}{{{{']
        for row in rows:
            dims = row['gguf_dimensions']+[0]*(3-len(row['gguf_dimensions']))
            lines += ['    glm_gguf_named_parameters::Spec{'+json.dumps(row['name'])+','+str(row['dtype_code'])+',{' +
                ','.join(map(str, dims))+'},'+str(len(row['gguf_dimensions']))+','+str(row['bytes'])+'ULL},']
        lines += ['}};']
    lines += ['} // namespace glm_gguf_b10_artifacts', '']
    output = args.output.resolve()
    assert output.is_relative_to(R), 'Generated source must stay in the workspace'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text('\n'.join(lines), encoding='utf-8', newline='\n')
    proof = dict(complete=True, repository=a.REPO, revision=a.REV, variant=a.VARIANT,
        original_roles=a.COUNT, source_bytes=a.BODY, directory=directory.relative_to(R).as_posix(),
        source_plan=a.identity(S/'static-plan.json'), expert_source_plan=a.identity(S/'expert-source-plan.json'),
        acquisition=a.identity(directory/'acquisition.json'), manifest=a.identity(directory/'manifest.json'),
        source_headers=[s['header'] for s in expert['shards']], generated_header=a.identity(output),
        generator=a.identity(Path(__file__)), acquisition_script=a.identity(S/'acquire.py'),
        common_validator=a.identity(BASE), body_rehashed=False, network_requests=0,
        expert_payload_scope='Only actual requested draft/target stage0 global IDs get catalog112B+roles.bin.')
    a.save(output.with_suffix('.json'), proof)
    print(json.dumps(proof), flush=True)


if __name__ == '__main__':
    main()
