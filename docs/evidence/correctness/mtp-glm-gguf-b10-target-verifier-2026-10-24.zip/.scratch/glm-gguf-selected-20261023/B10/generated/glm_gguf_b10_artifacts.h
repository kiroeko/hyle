#pragma once
#include <array>
#include <string_view>
#include "original_named_role_source.h"
#include "glm_gguf_named_parameters.h"
// Actual B10 Q8_0 files and source descriptors; expert payload pins are per requested ID.
namespace glm_gguf_b10_artifacts {
inline constexpr std::string_view kRepository="unsloth/GLM-5.3-GGUF";
inline constexpr std::string_view kRevision="346b3591c7f28d1a23716f97a065ecf12ec14771";
inline constexpr std::string_view kVariant="Q8_0";
inline constexpr std::string_view kFirstFile="Q8_0/GLM-5.3-Q8_0-00001-of-00017.gguf";
inline constexpr std::string_view kStaticPlanSha256="3f1dce5e8c439c9330fb0261fb9d344680cadb875e7823be2f904cfdb9c300df";
inline constexpr std::string_view kExpertSourcePlanSha256="47c4a13876ab3f04c8d537cd6f72d95aaeb1febbd2c8f60582d66b1a90257cf5";
inline constexpr std::string_view kStaticAcquisitionSha256="7cb03c6db9d3983787f02777774eea070a1eafcc089437fddbf15c30581eb67d";
inline constexpr std::string_view kStaticManifestSha256="b3af3fc55151e4d2ca212dbff4f3c011b6d16c7d758085565c435e6058e4a458";
inline constexpr std::uint64_t kStaticBytes=2566508544ULL;
inline const std::array<original_named_role_source::PinnedFile,47> kStaticPins47{{
    {"output.weight.bin","ad411388a9b89d5481de4fbb8c62602bf7cc7bf439632a349e788781715dcf84"},
    {"token_embd.weight.bin","bf3324349244d42ddf91012b333f7163461a303dfe98c3a2995c9d34b354ead9"},
    {"blk.77.indexer.k_norm.bias.bin","8fd6848338805d83a94359cb8d45f91ecd5236885bedd704716575c4385257fa"},
    {"blk.77.indexer.k_norm.weight.bin","7fb50640dcdc306c7595012f4d32b5e2d38c4f9b61bfe131253416d5e3666d9d"},
    {"blk.77.indexer.proj.weight.bin","f7e32f20dc4ece6f1acc05a7dcdd4f32da4117e0942d1418495b0f0df484bbc8"},
    {"blk.77.indexer.attn_k.weight.bin","390e00ef5c94fa854fbc59b0d769fbfe6662bf0e3a021fc757348e48d85d1fce"},
    {"blk.77.indexer.attn_q_b.weight.bin","b883cb90a89d467390ffe529457c9c4c593ea3cb5601ab3f4f5d759ee6c9aef6"},
    {"blk.77.attn_norm.weight.bin","9c7b43d8caaaa43ef371db5e960c3d91fe831fc505cc6aaaf6610c564aa8889f"},
    {"blk.77.exp_probs_b.bias.bin","bf96e8aeb9a603280b39e35e522811e07451966b05f21f335b769552e587d351"},
    {"blk.77.ffn_gate_inp.weight.bin","45cc532fe1651dfdef91543f54d0ebcbab74fa7007e48d20ab9d7bfb731b1818"},
    {"blk.77.ffn_down_shexp.weight.bin","fec7c3406c1ec704133ffd5a553a947164c4b6d6698e6109412226f8fedc09b0"},
    {"blk.77.ffn_gate_shexp.weight.bin","24d26c664f0e678a247dcade098024131e538c8ab500b3e04e1a9333785d2c01"},
    {"blk.77.ffn_up_shexp.weight.bin","d453e487066f11e3dc90c4a5b6535a3dbe71da9d4952771b0f6a505250f0a373"},
    {"blk.77.ffn_norm.weight.bin","5a41130630213223fae599baa3656ab18ad51b955a35b1e053d73a7e83b8feb3"},
    {"blk.77.attn_kv_a_norm.weight.bin","385e04bde2bf99cdf40300b9b0fe2b7a8537428313792c0d1ed2c43349efebf9"},
    {"blk.77.attn_kv_a_mqa.weight.bin","f1f361b3f5ada27844c2b9de90ba45c5be06c103a1d230b77605cdf4ab203e24"},
    {"blk.77.attn_k_b.weight.bin","1d6609c52ec97e2879a31e2849d77ac5c4f8103708562d22da57889910876415"},
    {"blk.77.attn_v_b.weight.bin","41426af46e95d7c505c78518cfd3c211e6c1e1334067615ab96a948a51e3019b"},
    {"blk.77.attn_output.weight.bin","29cc7948f239fee5128fef34512615396e24ab4829a20203ec5e67a86bf304be"},
    {"blk.77.attn_q_a_norm.weight.bin","32ac15253d2d5c947f048b8c4f5fa16d982547728fd243d581593f7c4edc77f2"},
    {"blk.77.attn_q_a.weight.bin","4845ed45e9d2f661d15b91a42dc23985f44b0c77cfa69e4d0750cdd0dea76709"},
    {"blk.77.attn_q_b.weight.bin","44f2492a2361e3788baec332555a8785ba825bc3136fc4dc34070d04aaae395b"},
    {"blk.78.nextn.eh_proj.weight.bin","1c6d31a788bf0d11f7b3f550c4d52525c9f35534b785a2364d661d2346901673"},
    {"blk.78.nextn.enorm.weight.bin","3ffe08e248ff7728fa80508955b6d06f08df15547eb5a393ff0b8f0acc82e094"},
    {"blk.78.nextn.hnorm.weight.bin","04739e49fc29ff84609204306dc01c1fcd86a88b5a327a85f6b4579f3ddb2f44"},
    {"blk.78.attn_norm.weight.bin","917ba53f9e10445e0ef854daffe4c7d7ad81fdee6842134238061478ea4b86f7"},
    {"blk.78.exp_probs_b.bias.bin","ef9c892ebbf350e5e120c4f252e07ae6ec18e11c7e0e9d25cb8a213241483795"},
    {"blk.78.ffn_gate_inp.weight.bin","cb451a3bd6feb855051875887bba58286437f18f305692707075a67b3a6de387"},
    {"blk.78.ffn_down_shexp.weight.bin","2419bb8af4f9b7e8e66859d38fd8d380c04f18de6f9d8fa85f2bce1de4f2aa0a"},
    {"blk.78.ffn_gate_shexp.weight.bin","9dc1fcf9917df80007beb056b662f218958d7346857392d154de3e23fbc36b75"},
    {"blk.78.ffn_up_shexp.weight.bin","dc83c19aefcb1f8786d00b46aaafbb3c1d7a86ef54dc1208d57d53f0f7f13819"},
    {"blk.78.ffn_norm.weight.bin","f34dd1a27eb420fcf7212b575c47500674fa4406e9e83b095e65df04c507218d"},
    {"blk.78.indexer.k_norm.bias.bin","a7f237d78b20533897a9b578fbb59f01e89f875df8ab61c36e97c377fbfeb9a3"},
    {"blk.78.indexer.k_norm.weight.bin","d00ef9d3eb0f69c4c11db75728b14ee5c52ffdc1868f547ba64432402f03d853"},
    {"blk.78.indexer.proj.weight.bin","9e0896a3d0f688125257bf4689a2327039d2ca8c37ba3fdd4ad6185f6471ca10"},
    {"blk.78.indexer.attn_k.weight.bin","a00540f544f42d72730a439bb9e554a5f70f86d38de043a9abbb63acbcd1276e"},
    {"blk.78.indexer.attn_q_b.weight.bin","d8561a38fc86eef8b07f167e7b7c4b2dd3e8d84f310bc40922e0e245ad912dda"},
    {"blk.78.attn_kv_a_norm.weight.bin","e21b7631c8bd4629fcb6cc7c40a3b56b6c0724ee0123ddaf69e4806406b1228e"},
    {"blk.78.attn_kv_a_mqa.weight.bin","b1cf2790f08f36ee2e83638e9f2e01130e326267020e40d460f1dda9b4c4a33c"},
    {"blk.78.attn_k_b.weight.bin","e9817c53975fe1f8abea76ee0b880b197f85573f642fe4f2674b11a04e081b75"},
    {"blk.78.attn_v_b.weight.bin","1217cebb94b3cc6b88192c28666e5cbac762fa47af4fb09757e8c0d93620b613"},
    {"blk.78.attn_output.weight.bin","6fa790511a40e8cc1df88d779e0b8abca5782392e465b8327af12f87755f5a99"},
    {"blk.78.attn_q_a_norm.weight.bin","8f5c308c2870728d8302923fe72c89a9e04f16e1039be6451695b361aabf41e7"},
    {"blk.78.attn_q_a.weight.bin","9469cfcedc6c35af74adb34a8e9710a04629b3d6091f92c0f7c339f88f0f542c"},
    {"blk.78.attn_q_b.weight.bin","5efd1b7a612a81ae505ad526d40ab2f4eac4ae725315fff1cbfa124411fa36af"},
    {"blk.78.nextn.shared_head_norm.weight.bin","3911a7fc3b257acb8df6784075eccfd6f1c9a7894cc0daebc6ed48ecf4d696c4"},
    {"output_norm.weight.bin","9d4827759803436c0b369a326f0f97406a1446d58c0420514b1fa50091c19a6f"},
}};
inline const auto &kStaticPins=kStaticPins47;
inline constexpr std::array<glm_gguf_named_parameters::Spec,47> kStaticSpecs47{{
    glm_gguf_named_parameters::Spec{"output.weight",8,{6144,154880,0},2,1011056640ULL},
    glm_gguf_named_parameters::Spec{"token_embd.weight",8,{6144,154880,0},2,1011056640ULL},
    glm_gguf_named_parameters::Spec{"blk.77.indexer.k_norm.bias",0,{128,0,0},1,512ULL},
    glm_gguf_named_parameters::Spec{"blk.77.indexer.k_norm.weight",0,{128,0,0},1,512ULL},
    glm_gguf_named_parameters::Spec{"blk.77.indexer.proj.weight",8,{6144,32,0},2,208896ULL},
    glm_gguf_named_parameters::Spec{"blk.77.indexer.attn_k.weight",8,{6144,128,0},2,835584ULL},
    glm_gguf_named_parameters::Spec{"blk.77.indexer.attn_q_b.weight",8,{2048,4096,0},2,8912896ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_norm.weight",0,{6144,0,0},1,24576ULL},
    glm_gguf_named_parameters::Spec{"blk.77.exp_probs_b.bias",0,{256,0,0},1,1024ULL},
    glm_gguf_named_parameters::Spec{"blk.77.ffn_gate_inp.weight",0,{6144,256,0},2,6291456ULL},
    glm_gguf_named_parameters::Spec{"blk.77.ffn_down_shexp.weight",8,{2048,6144,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.77.ffn_gate_shexp.weight",8,{6144,2048,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.77.ffn_up_shexp.weight",8,{6144,2048,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.77.ffn_norm.weight",0,{6144,0,0},1,24576ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_kv_a_norm.weight",0,{512,0,0},1,2048ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_kv_a_mqa.weight",8,{6144,576,0},2,3760128ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_k_b.weight",8,{192,512,64},3,6684672ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_v_b.weight",8,{512,256,64},3,8912896ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_output.weight",8,{16384,6144,0},2,106954752ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_q_a_norm.weight",0,{2048,0,0},1,8192ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_q_a.weight",8,{6144,2048,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.77.attn_q_b.weight",8,{2048,16384,0},2,35651584ULL},
    glm_gguf_named_parameters::Spec{"blk.78.nextn.eh_proj.weight",8,{12288,6144,0},2,80216064ULL},
    glm_gguf_named_parameters::Spec{"blk.78.nextn.enorm.weight",0,{6144,0,0},1,24576ULL},
    glm_gguf_named_parameters::Spec{"blk.78.nextn.hnorm.weight",0,{6144,0,0},1,24576ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_norm.weight",0,{6144,0,0},1,24576ULL},
    glm_gguf_named_parameters::Spec{"blk.78.exp_probs_b.bias",0,{256,0,0},1,1024ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_gate_inp.weight",0,{6144,256,0},2,6291456ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_down_shexp.weight",8,{2048,6144,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_gate_shexp.weight",8,{6144,2048,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_up_shexp.weight",8,{6144,2048,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_norm.weight",0,{6144,0,0},1,24576ULL},
    glm_gguf_named_parameters::Spec{"blk.78.indexer.k_norm.bias",0,{128,0,0},1,512ULL},
    glm_gguf_named_parameters::Spec{"blk.78.indexer.k_norm.weight",0,{128,0,0},1,512ULL},
    glm_gguf_named_parameters::Spec{"blk.78.indexer.proj.weight",0,{6144,32,0},2,786432ULL},
    glm_gguf_named_parameters::Spec{"blk.78.indexer.attn_k.weight",8,{6144,128,0},2,835584ULL},
    glm_gguf_named_parameters::Spec{"blk.78.indexer.attn_q_b.weight",8,{2048,4096,0},2,8912896ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_kv_a_norm.weight",0,{512,0,0},1,2048ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_kv_a_mqa.weight",8,{6144,576,0},2,3760128ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_k_b.weight",8,{192,512,64},3,6684672ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_v_b.weight",8,{512,256,64},3,8912896ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_output.weight",8,{16384,6144,0},2,106954752ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_q_a_norm.weight",0,{2048,0,0},1,8192ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_q_a.weight",8,{6144,2048,0},2,13369344ULL},
    glm_gguf_named_parameters::Spec{"blk.78.attn_q_b.weight",8,{2048,16384,0},2,35651584ULL},
    glm_gguf_named_parameters::Spec{"blk.78.nextn.shared_head_norm.weight",0,{6144,0,0},1,24576ULL},
    glm_gguf_named_parameters::Spec{"output_norm.weight",0,{6144,0,0},1,24576ULL},
}};
inline constexpr std::array<glm_gguf_named_parameters::Spec,6> kExpertSpecs6{{
    glm_gguf_named_parameters::Spec{"blk.77.ffn_down_exps.weight",8,{2048,6144,256},3,3422552064ULL},
    glm_gguf_named_parameters::Spec{"blk.77.ffn_gate_exps.weight",8,{6144,2048,256},3,3422552064ULL},
    glm_gguf_named_parameters::Spec{"blk.77.ffn_up_exps.weight",8,{6144,2048,256},3,3422552064ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_down_exps.weight",8,{2048,6144,256},3,3422552064ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_gate_exps.weight",8,{6144,2048,256},3,3422552064ULL},
    glm_gguf_named_parameters::Spec{"blk.78.ffn_up_exps.weight",8,{6144,2048,256},3,3422552064ULL},
}};
} // namespace glm_gguf_b10_artifacts
