"""Existing three direct GDN checks against the corrected CPU module, no HTTP."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = next(p for p in S.parents if (p / 'AGENTS.md').is_file())
spec = importlib.util.spec_from_file_location('_corrected_cpu_gdn_execute', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
q = importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
source = R / '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/focused-cpu-link1/gdn-scale-checks.exe'
module = S / 'hyle_ggml_cpu_gdn_scale_v3.dll'
assert identity(module)['sha256'] == 'fcb2b57d8aad1453c8dde3468986d4f0120edcd71ef3e6edfd86870c6c1914fa'
target = S / source.name
assert not target.exists()
os.link(source, target)
out = S / 'checks-gdn'
runtime = json.loads((R / '.scratch/glm-gguf-selected-20261023/B10/native-integration/tests-link3/runtime-environment.json').read_text(encoding='utf-8'))
env = os.environ.copy(); env['PATH'] = str(S) + os.pathsep + runtime['PATH']
process = q.execute([str(target), '--gtest_filter=GdnOutputScale.*', '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'results.xml')], env, out / 'run', timeout=180)
assert process['exit'] == 0 and not process['timed_out'], process
tree = ET.parse(out / 'results.xml').getroot()
assert int(tree.get('tests')) == 3 and all(int(tree.get(k, '0')) == 0 for k in ('failures', 'errors', 'disabled'))
assert not list(tree.iter('skipped')) and not list(tree.iter('failure'))
q.save(out / 'summary.json', dict(passed=True, tests=3, failures=0, skips=0, process=process, image=identity(target), image_origin=identity(source), module=identity(module), HTTP=0, throughput_evidence=False, memory_evidence=False))
print('PASSED corrected native AVX2 CPU GDN:3', flush=True)
