"""B10 actual Q8_0 static47 / selected three-leg caches, using B09 acquisition.

Import, --plan-only and --write-batch-plan perform no HTTP. Root executes each
explicit batch through the existing exclusive hf-mirror.net budget opener.
Only B10 metadata differs; resume, exact206/ETag/hash, locks, bounded workers,
catalog112B and terminal-future publication use the frozen existing routines.
"""
import hashlib
import importlib.util
import math
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
BASE = R/'.scratch/glm-gguf-selected-20261023/B09/acquire.py'
BASE_SHA = '6c79213014eebd58436e50ce44dc821408431838851ee5c8407d1a36d87761fb'
PINS = {
    'roles-schema.json': '843a4393f566fb152f90df1e4fa926551a5f09eb583d1742486a9234dece0a66',
    'roles-plan.json': 'a091e489ffe900e906cb575b53bc100a37da61d2e1bfad59d6bdee1987b0205a',
    'static-plan.json': '3f1dce5e8c439c9330fb0261fb9d344680cadb875e7823be2f904cfdb9c300df',
    'summary.json': 'da47e05ffab64727be95d1964b110da641ac656c32475dee0c45cccf7a6049fc',
}


def configured():
    assert hashlib.sha256(BASE.read_bytes()).hexdigest() == BASE_SHA, 'Frozen B09 acquisition changed'
    spec = importlib.util.spec_from_file_location('_b10_existing_acquisition', BASE)
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    common.S, common.R = S, R
    common.__file__, common.__doc__ = __file__, __doc__
    common.VARIANT, common.COUNT, common.BODY, common.DOMAIN = 'Q8_0', 47, 2566508544, 256
    common.SECTION = {'draft': (78, 40108032), 'target': (77, 40108032)}
    common.HELPERS = dict(common.HELPERS, acquisition_base=(BASE.relative_to(R).as_posix(), BASE_SHA))

    def checked():
        for name, expected in PINS.items():
            assert common.identity(S/name)['sha256'] == expected, 'Actual B10 metadata changed: '+name
        proof, static, roles, schema = [common.read(S/name) for name in
            ('summary.json', 'static-plan.json', 'roles-plan.json', 'roles-schema.json')]
        assert proof['complete'] and proof['metadata_only'] and proof['tensor_payload_bytes'] == 0
        assert proof['actual_header_bytes'] == proof['new_requested_bytes'] == 9446976
        assert proof['static_plan'] == common.identity(S/'static-plan.json')
        assert proof['roles_plan'] == common.identity(S/'roles-plan.json')
        assert static['source_schema'] == roles['source_schema'] == common.identity(S/'roles-schema.json')
        assert schema['id'] == 'B10' and schema['audit_key'] == 'glm53_q8_0'
        assert schema['physical_role_count'] == roles['original_roles'] == len(roles['roles']) == 53
        assert schema['static_roles'] == static['original_roles'] == len(static['roles']) == common.COUNT
        assert schema['static_bytes'] == static['source_bytes'] == sum(r['bytes'] for r in static['roles']) == common.BODY
        assert static['roles'] == [r for r in roles['roles'] if not r['selected_source']]
        assert roles['full_expert_banks_acquire'] is False and len({r['name'] for r in roles['roles']}) == 53
        shards, tables = {}, {}
        for plan in (static, roles):
            assert (plan['repository'], plan['revision'], plan['variant']) == (common.REPO, common.REV, common.VARIANT)
            assert plan['complete_absolute_ranges'] and plan['http_identity_authenticated'] and plan['metadata_only']
            assert plan['whole_shards_downloaded'] is False and plan['shards'] == proof['headers']
        assert [s['shard'] for s in proof['headers']] == [1, 16, 17]
        for source in proof['headers']:
            assert source['complete'] and source['schema_validated'] and source['http_status'] == 206
            assert (source['repository'], source['revision']) == (common.REPO, common.REV)
            assert source['file'] == f"Q8_0/GLM-5.3-Q8_0-{source['shard']:05d}-of-00017.gguf"
            assert source['url'] == f"https://huggingface.co/{common.REPO}/resolve/{common.REV}/{source['file']}"
            assert re.fullmatch('"[0-9a-f]{64}"', source['etag'])
            for key in ('header', 'physical_table', 'acquired_receipt'):
                assert common.identity(R/source[key]['path']) == source[key]
            table = common.read(R/source['physical_table']['path'])['tensors']
            assert len(table) == source['actual_tensor_count']
            tables[source['shard']] = {r['name']: r for r in table}
            assert len(tables[source['shard']]) == len(table)
            shards[source['shard']] = source
        for row in roles['roles']:
            source = shards[row['source_shard']]
            original = tables[row['source_shard']][row['name']]
            dtype, block, stored = common.TYPES[row['dtype_code']]
            assert row['dtype_code'] in (0, 8) and row['dtype_code'] == original['dtype_code']
            assert row['dtype'] == original['dtype'] == dtype
            assert row['gguf_dimensions'] == original['shape'] and all(type(n) is int and n > 0 for n in original['shape'])
            assert original['shape'][0] % block == 0
            assert row['bytes'] == original['bytes'] == math.prod(original['shape'])//block*stored
            first = source['data_base']+original['offset']
            assert row['data_relative_half_open'] == [original['offset'], original['offset']+row['bytes']]
            assert row['absolute_inclusive'] == [first, first+row['bytes']-1]
            assert first+row['bytes'] <= source['whole_file_bytes'] and row['source_file'] == source['file']
            assert row['filename'] == row['name']+'.bin' and Path(row['filename']).name == row['filename']
            if row['selected_source']:
                assert row['dtype_code'] == 8 and len(original['shape']) == 3 and original['shape'][2] == common.DOMAIN
                assert row['expert_bytes'] == 13369344 and row['bytes'] == row['expert_bytes']*common.DOMAIN
        banks = [r for r in roles['roles'] if r['selected_source']]
        assert len(banks) == 6 and schema['expert_bytes_per_id'] == {'layer77': 40108032, 'layer78': 40108032}
        for key, (path, expected) in common.HELPERS.items():
            assert common.identity(R/path)['sha256'] == expected, 'Frozen acquisition helper changed: '+key
        expert = dict(repository=common.REPO, revision=common.REV, variant=common.VARIANT,
            source_format='GGUF_ORIGINAL_Q8_0', original_roles=6, expert_domain=common.DOMAIN,
            runtime_slots=8, stage=0, full_expert_banks_acquire=False, whole_bank_sha256_required=False,
            source_roles_plan=common.identity(S/'roles-plan.json'), source_schema=roles['source_schema'],
            shards=roles['shards'], roles=banks, leg_order=list(common.LEGS),
            sections={name: dict(layer=layer, per_id_payload_bytes=size) for name, (layer, size) in common.SECTION.items()},
            typed_catalog=dict(magic='HYDSPT01', version=1, roles=3, bytes=112),
            scope='B10 original Q8_0 bank metadata defines requested per-ID slices only; no whole-bank fetch/hash.')
        common.retain(S/'expert-source-plan.json', expert)
        return static, expert, shards

    common.checked = checked
    selected_plan = common.per_id_plan
    def per_id_plan(expert, section, global_id, directory):
        result = selected_plan(expert, section, global_id, directory)
        result['source_format'] = 'GGUF_ORIGINAL_Q8_0'
        return result
    common.per_id_plan = per_id_plan
    return common


if __name__ == '__main__':
    configured().main()
