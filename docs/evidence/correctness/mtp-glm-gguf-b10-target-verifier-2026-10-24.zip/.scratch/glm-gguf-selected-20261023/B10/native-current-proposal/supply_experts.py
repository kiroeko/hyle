"""One actual B10 frontier -> the existing bounded acquire.py/run_batch path."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent
R=next(p for p in S.parents if (p/'AGENTS.md').is_file())
ACQUIRE=A/'acquire.py'
ACQUIRE_SHA='0425e10c230289cf1ed10c1c57eb4c64fb9242fe3238157d07db2c0e18fc14cb'


def configured():
    if hashlib.sha256(ACQUIRE.read_bytes()).hexdigest()!=ACQUIRE_SHA:
        raise ValueError('Frozen actual B10 acquisition adapter changed')
    spec=importlib.util.spec_from_file_location('_b10_current_actual_acquisition',ACQUIRE)
    adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
    a=adapter.configured();static,expert,_=a.checked()
    if (a.DOMAIN,expert['expert_domain'],len(static['roles']),static['source_bytes'])!=(256,256,47,2566508544):
        raise ValueError('Actual B10 static/domain contract differs')
    if set(expert['sections'])!={'draft','target'} or expert['typed_catalog']['bytes']!=112:
        raise ValueError('Actual B10 source sections/catalog differ')
    return a,expert


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--frontier-file',type=Path,required=True)
    parser.add_argument('--plan-only',action='store_true');args=parser.parse_args()
    raw=args.frontier_file.read_bytes()
    if not 0<len(raw)<=65536:raise ValueError('B10 frontier exceeds bounded metadata')
    request=json.loads(raw);a,expert=configured();domain=expert['expert_domain']
    for key in ('missing_ids','global_ids'):
        values=request[key]
        if not isinstance(values,list) or not 1<=len(values)<=8 or values!=sorted(set(values)) or any(type(n)is not int or not 0<=n<domain for n in values):
            raise ValueError('B10 requires actual sorted unique1..8 IDs')
    section,ids=request['section'],request['missing_ids']
    if section not in expert['sections'] or type(request['stage'])is not int or request['stage']!=0 or not set(ids)<=set(request['global_ids']):
        raise ValueError('B10 actual section/stage/IDs differ')
    if args.plan_only:
        print(json.dumps(dict(section=section,stage=0,global_ids=ids,roles=3*len(ids),typed_catalog_bytes_per_id=112,
            maximum_body_bytes=expert['sections'][section]['per_id_payload_bytes']*len(ids),
            source_plan=a.identity(A/'expert-source-plan.json'),network_requests=0)));return 0
    label=section+'-'+ '-'.join(map(str,ids));attempt=1
    while (A/'frontier-plans'/f'{label}-attempt{attempt}.json').exists() or (A/'batches'/f'{label}-attempt{attempt}').exists():attempt+=1
    plan=A/'frontier-plans'/f'{label}-attempt{attempt}.json'
    command=[sys.executable,str(ACQUIRE),'experts','--section',section,'--ids',*map(str,ids),
        '--attempt',str(attempt),'--write-batch-plan',str(plan)]
    subprocess.run(command,cwd=R,check=True)
    frozen=a.read(plan)
    if frozen['script_sha256']!=ACQUIRE_SHA or hashlib.sha256(ACQUIRE.read_bytes()).hexdigest()!=ACQUIRE_SHA:
        raise ValueError('B10 actual body adapter changed after plan preparation')
    return subprocess.run([sys.executable,str(R/'.scratch/mtp-download-budget-20261023/run_batch.py'),str(plan)],cwd=R).returncode


if __name__=='__main__':sys.exit(main())
