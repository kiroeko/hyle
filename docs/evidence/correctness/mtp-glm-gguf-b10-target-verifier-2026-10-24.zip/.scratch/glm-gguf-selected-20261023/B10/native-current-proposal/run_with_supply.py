"""B10 configuration of the existing DSpark Windows OwnedJob driver."""
from pathlib import Path
import hashlib,importlib.util,sys
sys.dont_write_bytecode=True
from supply_experts import configured
S=Path(__file__).resolve().parent;A=S.parent
R=next(p for p in S.parents if (p/'AGENTS.md').is_file())
DRIVER=R/'.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'
DRIVER_SHA='d3e0749a5b565717582ff33f9f02251faae5309c71b693abfd3a6e8b880be50a'


def main():
    if hashlib.sha256(DRIVER.read_bytes()).hexdigest()!=DRIVER_SHA:raise ValueError('Existing owned driver changed')
    _,expert=configured()
    spec=importlib.util.spec_from_file_location('_b10_current_existing_owned_driver',DRIVER)
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    driver.S,driver.R=A,R;driver.DOMAIN=expert['expert_domain'];driver.SECTIONS=tuple(expert['sections'])
    driver.FETCH_SCRIPT=S/'supply_experts.py'
    driver.WAIT_ENV='HYLE_GLM_GGUF_WAIT_FOR_EXPERTS'
    driver.FRONTIER_ENV='HYLE_GLM_GGUF_FRONTIER_FILE'
    return driver.main()


if __name__=='__main__':sys.exit(main())
