"""Publish only two completed B10 Pro finite runs; never fetch/build/run."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib.util,json,sys,zipfile
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;N=A/'native-integration'
R=next(p for p in S.parents if (p/'AGENTS.md').is_file());D=R/'docs/evidence/correctness'
NAME='mtp-glm-gguf-b10-target-verifier-2026-10-24'
CONTRACT=('unsloth/GLM-5.3-GGUF','346b3591c7f28d1a23716f97a065ecf12ec14771','Q8_0')
HOST=N/'build.py';HOST_SHA='96f154b81677aeeccf2cfb499818e5b0ab3bb24ff6ef8740cc1207e152a4b2d2'
ARCHIVE_TOOL=R/'.scratch/glm-quark-selected-20261024/Q30/publish.py'
ARCHIVE_SHA='aff6d102813826e91729249d0ff6cea1ec6fe45c030abbeb99980f0ff0a2cda5'
RUNTIME_HELPER=A.parent/'runtime_override.py'
RUNTIME_SHA='46414bb5743db1a63c1ac17a631849a5c5688b21a44b366ad49c61503e40568d'


def load(name,path,expected):
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise ValueError('Frozen utility changed: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def completed_run(h,backend,attempt,ready,archive):
    folder=N/f'checks{attempt}-{backend}';summary=h.read(folder/'summary.json');process=h.read(folder/'run/process.json')
    driver=h.read(folder/'frontier.driver.json');plan=h.read(folder/'plan.json')
    if summary.get('passed')is not True or summary['process']!=process or process['exit']!=0 or process.get('timed_out')is not False:
        raise ValueError('Selected B10 run is not an actual terminal pass')
    if driver.get('exit')!=0 or driver.get('error') or driver['native'].get('exit')!=0 or driver['native'].get('stopped_by_driver')is not False:
        raise ValueError('Selected B10 owned native process failed/stopped')
    if driver.get('job_cleanup',{}).get('remaining_descendants')!=0 or any(f.get('exit')!=0 or f.get('stopped_by_driver',False) for f in driver['fetches']):
        raise ValueError('Selected B10 native/supply descendants did not finish successfully')
    expected='GlmProMtpStateConsumer.'+backend.title()+'ConvertedB10TargetAndNextNFullVocabularyVerifier'
    tree=ET.parse(folder/'results.xml').getroot();cases=list(tree.iter('testcase'))
    if len(cases)!=1 or any(int(tree.get(k,'0')) for k in ('failures','errors','disabled')) or list(tree.iter('skipped')) or list(tree.iter('failure')):
        raise ValueError('Exactly one actual passing unskipped B10 case is required per backend')
    case=cases[0];p={x.get('name'):x.get('value') for x in case.iter('property')}
    if case.get('classname')+'.'+case.get('name')!=expected or case.get('status')!='run' or case.get('result')!='completed':
        raise ValueError('Actual B10 case differs')
    if summary['case']!=expected or (summary['tests'],summary['failures'],summary['skips'])!=(1,0,0) or summary['properties']!=p:
        raise ValueError('Actual B10 summary/XML facts differ')
    wanted=dict(artifact_repository=CONTRACT[0],artifact_revision=CONTRACT[1],artifact_variant=CONTRACT[2],
        static_source_roles='47',static_source_bytes='2566508544',
        expert_source_plan_sha256=h.identity(A/'expert-source-plan.json')['sha256'],
        target_first_full_reference_values='309760',first_full_nextn_head_reference_values='154880')
    if any(p.get(k)!=v for k,v in wanted.items()):raise ValueError('B10 own source/full-vocabulary properties differ')
    graphs=int(p['actual_submissions'])
    if graphs<=0 or summary['actual_graph_submissions']!=graphs or int(p['peak_state_backing_bytes'])>int(p['state_budget_bytes']):
        raise ValueError('Actual B10 graph/state facts differ')
    for key in ('actual_pending_embedding_feedback_checks','accepted_zero_draft_checkpoints','accepted_one_draft_checkpoints',
        'accepted_target_conditioned_repairs','actual_accepted_kv_repair_submissions','controlled_matching_trials','controlled_rejection_trials'):
        if int(p[key])<=0:raise ValueError('Actual B10 behavior check missing: '+key)
    if int(p['natural_k1_trials'])!=1 or int(p['natural_k1_accepted_drafts'])not in (0,1):raise ValueError('Keep natural K1 and controlled trials separate')
    for record in (summary,plan):
        if record['image']!=ready['image'] or record['consumer_record']!=ready['consumer_record']:raise ValueError('Run/linked B10 image or consumer differs')
    command=driver['native']['command']
    if h.resolve(command[0])!=h.resolve(ready['image']['path']) or '--gtest_filter='+expected not in command or '--gtest_throw_on_failure=1' not in command:
        raise ValueError('Actual owned B10 command differs')
    for key in ('entry','owned_entry','supply_entry'):h.require(plan[key]);archive.add(h.resolve(plan[key]['path']))
    archive.metadata_tree(folder)
    return dict(backend=backend.upper(),case=expected,tests=1,failures=0,skips=0,graph_submissions=graphs,properties=p,
        summary=h.identity(folder/'summary.json'),XML=h.identity(folder/'results.xml'),driver=h.identity(folder/'frontier.driver.json'),
        process=h.identity(folder/'run/process.json'),image=ready['image'],
        evaluation=dict(passed=True,source='Actual terminal native/process/OwnedJob/XML and own packed-source contract validation.',original_summary_passed=True)),driver


def selected_experts(h,a,expert,drivers,archive):
    cached={};frontiers=[];source_sha=h.identity(A/'expert-source-plan.json')['sha256']
    for driver in drivers:
        for fetch in driver['fetches']:
            request=fetch['request'];section=request['section']
            if section not in expert['sections'] or type(request['stage'])is not int or request['stage']!=0:
                raise ValueError('Actual B10 expert section/stage differs')
            for key in ('global_ids','missing_ids'):
                ids=request[key]
                if not isinstance(ids,list) or not 1<=len(ids)<=8 or ids!=sorted(set(ids)) or any(type(n)is not int or not 0<=n<256 for n in ids):
                    raise ValueError('Actual B10 expert IDs differ')
            if not set(request['missing_ids'])<=set(request['global_ids']):raise ValueError('Missing expert IDs are not the actual selected subset')
            frontiers.append(dict(request=request,exit=fetch['exit']))
    for path in sorted((A/'original-experts').glob('*/stage0/expert*/ready.json')):
        directory=path.parent;ready=h.read(path);plan=h.read(directory/'plan.json');receipt=h.read(directory/'acquisition.json')
        section=ready['section'];ids=ready['global_ids']
        if tuple(ready[k] for k in ('repository','revision','variant'))!=CONTRACT or ready.get('complete')is not True or section not in expert['sections'] or ready['stage']!=0 or len(ids)!=1 or not 0<=ids[0]<256:
            raise ValueError('B10 immutable per-ID source identity differs')
        if directory.name!=f'expert{ids[0]:03d}' or directory.parent.parent.name!=section or ready['source_plan_sha256']!=source_sha:
            raise ValueError('B10 immutable per-ID path/source pin differs')
        for key in ('plan','acquisition'):h.require(ready[key],directory/(key+'.json'))
        h.require(plan['source_plan'],A/'expert-source-plan.json')
        if (plan['section'],plan['stage'],plan['global_ids'])!=(section,0,ids) or tuple(plan[k] for k in ('repository','revision','variant'))!=CONTRACT:
            raise ValueError('B10 actual per-ID plan differs')
        if receipt['section']!=section or receipt['stage']!=0 or receipt['global_ids']!=ids or ready['bundle']!=receipt['bundle']:
            raise ValueError('B10 acquisition/ready ID or bytes differ')
        a.check_catalog(receipt,plan,directory)  # Existing B09 exact 112B typed catalog/plane/extent validator.
        if plan['whole_shards_downloaded']is not False or receipt['whole_shards_downloaded']is not False or receipt['unrequested_bytes']!=0 or ready['typed_catalog']['sha256']!=a.identity(directory/'catalog.bin')['sha256']:
            raise ValueError('B10 bounded acquisition or ready catalog pin differs')
        if plan['bundle_bytes']!=expert['sections'][section]['per_id_payload_bytes'] or len(plan['roles'])!=3:
            raise ValueError('B10 original three-leg extent differs')
        layer=expert['sections'][section]['layer']
        for role,leg in zip(plan['roles'],('gate','up','down'),strict=True):
            bank=next(r for r in expert['roles'] if r['name']==f'blk.{layer}.ffn_{leg}_exps.weight')
            first=bank['absolute_inclusive'][0]+ids[0]*bank['expert_bytes']
            if (role['name'],role['leg'],role['global_id'],role['dtype_code'],role['shape'],role['bytes'],role['absolute_inclusive'])!=(bank['name'],leg,ids[0],bank['dtype_code'],bank['gguf_dimensions'][:2],bank['expert_bytes'],[first,first+bank['expert_bytes']-1]):
                raise ValueError('B10 selected expert is not its own original bank slice')
        archive.metadata_tree(directory);archive.add(directory/'catalog.bin')
        cached[(section,ids[0])]=dict(section=section,global_id=ids[0],bytes=receipt['bundle_bytes'],ready=h.identity(path),
            acquisition=h.identity(directory/'acquisition.json'),plan=h.identity(directory/'plan.json'),bundle=receipt['bundle'])
    if any((f['request']['section'],n) not in cached for f in frontiers for n in f['request']['missing_ids']):
        raise ValueError('A successful B10 frontier lacks its actual per-ID receipt')
    return dict(cached_sets=list(cached.values()),cached_payload_bytes=sum(v['bytes'] for v in cached.values()),actual_missing_frontiers=frontiers,
        accounting='Cache includes earlier completed requests. Actual per-run properties are preserved verbatim; no full-bank or active-union count is invented.',body_rehashed=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--cpu-run',type=int,required=True);parser.add_argument('--cuda-run',type=int,required=True)
    parser.add_argument('--compile-attempt',type=int,default=2);parser.add_argument('--link-attempt',type=int,default=2)
    parser.add_argument('--source-root',type=Path,action='append',default=[]);args=parser.parse_args()
    if min(args.cpu_run,args.cuda_run,args.compile_attempt,args.link_attempt)<=0:raise ValueError('Positive actual attempts required')
    h=load('_b10_existing_pin_metadata',HOST,HOST_SHA);tools=load('_b10_existing_archive',ARCHIVE_TOOL,ARCHIVE_SHA);tools.S=A
    archive=tools.Archive([p.resolve() for p in args.source_root]);archive.add(Path(__file__));archive.add(HOST);archive.add(ARCHIVE_TOOL)
    header,proof_path,static=h.pins();proof=h.read(proof_path)
    generator=h.module('_b10_existing_static_validator',A/'generate_artifacts.py');a,receipt,manifest,expert=generator.validate(A/'original-static')
    if tuple(proof[k] for k in ('repository','revision','variant'))!=CONTRACT:raise ValueError('B10 static identity differs')
    if (expert['expert_domain'],expert['runtime_slots'])!=(256,8):raise ValueError('B10 own expert geometry differs')
    for key in ('source_plan','expert_source_plan','acquisition','manifest','generated_header','generator','acquisition_script','common_validator'):
        h.require(proof[key]);archive.add(h.resolve(proof[key]['path']))
    archive.add(proof_path);archive.metadata_tree(A/'headers')
    image_dir=N/f'tests-link{args.link_attempt}';ready=h.read(image_dir/'ready.json')
    for key in ('link_plan','runtime_environment','consumer_record'):h.require(ready[key]);archive.add(h.resolve(ready[key]['path']))
    if h.resolve(ready['image']['path']).stat().st_size!=ready['image']['bytes']:raise ValueError('B10 linked image extent differs')
    link=h.read(image_dir/'link-plan.json');linked=h.read(image_dir/'link.result.json')
    if linked['exit']!=0 or linked['command']!=link['command'] or h.resolve(ready['consumer_record']['path'])!=(N/f'compile{args.compile_attempt}/glm-pro/identity.json').resolve():
        raise ValueError('B10 actual link/consumer attempt differs')
    compiled=h.read(h.resolve(ready['consumer_record']['path']))
    for key in ('actual_pins','actual_pin_receipt','current_closure_helper'):
        h.require(compiled[key]);archive.add(h.resolve(compiled[key]['path']))
    entry=compiled['current_entry'];snapshot=A/'runtime-override-proposal/before/build.py'
    current=h.identity(h.resolve(entry['path']))
    if any(current[k]!=entry[k] for k in ('bytes','sha256')):
        old=h.identity(snapshot)
        if any(old[k]!=entry[k] for k in ('bytes','sha256')):raise ValueError('Exact compile-time thin entry snapshot differs')
        archive.add(snapshot);compile_entry_source=dict(recorded=entry,archived_copy=old,current_source_claimed=False)
    else:archive.add(h.resolve(entry['path']));compile_entry_source=dict(recorded=entry,current_source_claimed=True)
    h.require(link['current_entry']);archive.add(h.resolve(link['current_entry']['path']))
    if h.resolve(compiled['actual_pins']['path'])!=header.resolve() or h.resolve(compiled['actual_pin_receipt']['path'])!=proof_path.resolve():
        raise ValueError('B10 compiled pins are not this own source manifest')
    for info in (compiled['source'],*compiled['dependencies']):archive.source(info,h.resolve(ready['consumer_record']['path']))
    archive.metadata_tree(h.resolve(ready['consumer_record']['path']).parent);archive.metadata_tree(image_dir)
    for info in link['retained_current_records']:h.require(info);archive.add(h.resolve(info['path']))
    h.require(link['retained_native_inputs']);archive.add(h.resolve(link['retained_native_inputs']['path']))
    native=load('_b10_actual_runtime_proof',RUNTIME_HELPER,RUNTIME_SHA)
    runtime_proof=native.verify(image_dir/'runtime-environment.json');archive.add(RUNTIME_HELPER)
    for key in ('result','plan'):archive.add(h.resolve(runtime_proof[key]['path']))
    native_plan=h.read(h.resolve(runtime_proof['plan']['path']));h.require(native_plan['entry']);archive.add(h.resolve(native_plan['entry']['path']))
    archive.metadata_tree(h.resolve(runtime_proof['result']['path']).parent)
    executions=[];drivers=[]
    for backend,attempt in (('cpu',args.cpu_run),('cuda',args.cuda_run)):
        execution,driver=completed_run(h,backend,attempt,ready,archive);executions.append(execution);drivers.append(driver)
    experts=selected_experts(h,a,expert,drivers,archive)
    history=[]
    for folder in sorted(N.glob('checks*-*')):
        archive.metadata_tree(folder);summary=folder/'summary.json'
        if summary.is_file():history.append(dict(summary=h.identity(summary),passed=h.read(summary).get('passed'),
            selected=any(x['summary']==h.identity(summary) for x in executions)))
    diagnostic=A/'q8-diagnostic-proposal';rca=h.read(diagnostic/'rca.json')
    for name in ('rca.json','recheck_capture.py','source.patch','build-result.json'):archive.add(diagnostic/name)
    capture=N/'capture-cpu2/failure-0'
    small={'input.f32':2048,'weight-row.q8_0':544,'actual-y.f32':4,'independent-scalar.q8_0':544,'independent-avx.q8_0':544}
    for info in rca['raw_capture']:
        h.require(info);path=h.resolve(info['path'])
        if path.parent!=capture.resolve():raise ValueError('Unexpected diagnostic capture path')
        if path.name in small:
            if path.stat().st_size!=small[path.name]:raise ValueError('Unexpected diagnostic capture extent')
            archive.files[path.relative_to(R).as_posix()]=path  # Five explicit tiny raw fixtures, never a weight bank.
        else:archive.add(path)
    for directory in (A/'batches',A/'frontier-plans'):archive.metadata_tree(directory)
    for path in A.glob('*.json'):archive.add(path)
    for path in A.glob('*.py'):archive.add(path)
    for path in S.glob('*.py'):archive.add(path)
    common_driver=R/'.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'
    if h.identity(common_driver)['sha256']!='d3e0749a5b565717582ff33f9f02251faae5309c71b693abfd3a6e8b880be50a':raise ValueError('Actual owned driver changed')
    archive.add(common_driver);reference=D/'mtp-glm-gguf-b09-target-verifier-2026-10-24.json';archive.add(reference)
    shared=[]
    for name in ('mtp-cpu-native-family-2026-10-24','mtp-gdn-output-scale-2026-10-24','mtp-batched-f32-bfloat-linear-2026-10-24','mtp-packed-mmvq-tail-integration-2026-10-24','mtp-gguf-binding-gaps-2026-10-24'):
        path=D/(name+'.json');archive.add(path);shared.append(h.identity(path))
    if sum(p.stat().st_size for p in archive.files.values())>67108864 or any(p.stat().st_size>16777216 for p in archive.files.values()):
        raise ValueError('Archive must remain a small finite source/metadata subset')
    destination=D/(NAME+'.json');output=D/(NAME+'.zip')
    if destination.exists() or output.exists():raise ValueError('Do not overwrite published evidence')
    record=dict(created_at=datetime.now(timezone.utc).isoformat(),identity=dict(id='B10',repository=CONTRACT[0],revision=CONTRACT[1],variant=CONTRACT[2]),
        status='Completed finite own target77 + NextN78 Pro CPU/CUDA full-vocabulary K1 execution',
        validation=dict(cases=2,failures=0,skips=0,graph_submissions=sum(x['graph_submissions'] for x in executions),executions=executions,
            scope='Actual native test cases. Per-execution evaluation separately preserves any original wrapper observation failure.'),
        original_static=dict(static,bytes=static['source_bytes']),actual_pins=h.identity(proof_path),selected_experts=experts,attempt_history=history,
        state='Own Pro 13 resources + Epoch24: ten plain NextN resources and distinct target main/cursor/F32tap. Actual component_schema and state counts remain in XML properties.',
        reference_finite_proof=dict(identity=h.identity(reference),scope='Prior B09 runtime/behavior reference only; no graph or byte counts borrowed.'),
        build=dict(consumer_record=ready['consumer_record'],link_plan=ready['link_plan'],runtime=ready['runtime_environment'],image=ready['image'],
            retained_host_records=len(link['retained_current_records']),fresh_consumer_TUs=1,fresh_product_TUs=0,SDK_builds=0,NVCC_builds=0,
            compiled_source_manifest=list(archive.sources.values()),shared_proofs=shared,compile_entry_source=compile_entry_source,runtime_correction=runtime_proof),
        limits=['Upstream layer76 input/residual, shared-index upstream74 IDs and finite initial histories are fixtures; this is not a full trained target engine or task-quality result.',
            'One natural K1 trial and separate controlled match/rejection trials do not measure natural acceptance rate.',
            'State/capacity properties are logical bounds. No TPS, full-model, measured physical memory or all-platform claim.'],
        whole_original_model=False,throughput_evidence=False,memory_evidence=False,weight_bodies_rehashed=False,scope_or_progress_updated=False)
    record['corrections']=[dict(kind='Validation runtime assembly',RCA=h.identity(diagnostic/'rca.json'),
        original_failures=['checks1-cpu native3','checks2-cpu native3'],reclassified_as_passing=False,
        correction='Complete correct AVX2 worker staged from its actual15-TU compile/link result; oracle and tolerances unchanged.',
        actual_runtime=runtime_proof)]
    # Public output begins only after both actual passes and all read-only checks.
    with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as target:
        for entry,path in sorted(archive.files.items()):target.write(path,entry)
        target.writestr('compiled-source-manifest.json',json.dumps(list(archive.sources.values()),indent=2)+'\n')
    record.update(archive=h.identity(output),archived_files=len(archive.files)+1)
    destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(evidence=h.identity(destination),archive=h.identity(output),graphs=record['validation']['graph_submissions'])))


if __name__=='__main__':main()
