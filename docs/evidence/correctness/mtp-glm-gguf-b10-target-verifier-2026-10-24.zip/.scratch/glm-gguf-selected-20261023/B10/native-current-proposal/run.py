"""Run one B10 case on its current linked image; root schedules execution."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;N=A/'native-integration'
R=next(p for p in S.parents if (p/'AGENTS.md').is_file())
HOST=N/'build.py';HOST_SHA='96f154b81677aeeccf2cfb499818e5b0ab3bb24ff6ef8740cc1207e152a4b2d2'
CONTRACT=dict(repository='unsloth/GLM-5.3-GGUF',revision='346b3591c7f28d1a23716f97a065ecf12ec14771',variant='Q8_0')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--backend',choices=('cpu','cuda'),required=True)
    parser.add_argument('--link-attempt',type=int,default=2);parser.add_argument('--run-attempt',type=int,default=1)
    parser.add_argument('--timeout',type=int,default=14400);parser.add_argument('--plan-only',action='store_true');args=parser.parse_args()
    if min(args.link_attempt,args.run_attempt,args.timeout)<=0:raise ValueError('Positive unused attempts/timeout required')
    if hashlib.sha256(HOST.read_bytes()).hexdigest()!=HOST_SHA:raise ValueError('Frozen B10 identity/pin utilities changed')
    spec=importlib.util.spec_from_file_location('_b10_current_run_metadata',HOST)
    h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
    h.pins();image_dir=N/f'tests-link{args.link_attempt}';ready=h.read(image_dir/'ready.json')
    for key in ('image','link_plan','runtime_environment','consumer_record'):h.require(ready[key])
    h.check_record(h.resolve(ready['consumer_record']['path']))
    runtime=h.read(image_dir/'runtime-environment.json')
    for row in runtime['staged_dlls']:h.require(row)
    out=N/f'checks{args.run_attempt}-{args.backend}'
    case='GlmProMtpStateConsumer.'+args.backend.title()+'ConvertedB10TargetAndNextNFullVocabularyVerifier'
    command=[sys.executable,str(S/'run_with_supply.py'),'--image',ready['image']['path'],
        '--frontier-file',str(out/'frontier.json'),'--','--gtest_filter='+case,'--gtest_throw_on_failure=1',
        '--gtest_output=xml:'+str(out/'results.xml')]
    env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_GLM_')}
    env.update(PATH=runtime['PATH'],HYLE_GLM_GGUF_B10_DIR=str(A/'original-static'),
        HYLE_GLM_GGUF_B10_EXPERT_DIR=str(A/'original-experts'),OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
    plan=dict(command=command,image=ready['image'],consumer_record=ready['consumer_record'],entry=h.identity(Path(__file__)),
        owned_entry=h.identity(S/'run_with_supply.py'),supply_entry=h.identity(S/'supply_experts.py'),source_contract=CONTRACT,
        static_roles=47,static_bytes=2566508544,case=case)
    if args.plan_only:
        print(json.dumps(dict(plan,prepared_only=True,environment={k:v for k,v in env.items() if k.startswith('HYLE_GLM_')},HTTP=0,native_runs=0)));return 0
    out.mkdir(exist_ok=False);h.save(out/'plan.json',plan)
    q=h.module('_b10_current_owned_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process=q.execute(command,env,out/'run',timeout=args.timeout)
    result=dict(process=process,passed=False,image=ready['image'],consumer_record=ready['consumer_record'],throughput_evidence=False,memory_evidence=False)
    try:
        if process['exit'] or process['timed_out']:raise RuntimeError('B10 owned native/supply process failed')
        driver=h.read(out/'frontier.driver.json')
        if driver.get('exit')!=0 or driver.get('error') or driver['native']['exit'] or driver['native']['stopped_by_driver'] or driver['job_cleanup']['remaining_descendants']!=0:
            raise ValueError('B10 owned native tree did not retire successfully')
        if any(row['exit'] or row.get('stopped_by_driver',False) for row in driver['fetches']):raise ValueError('B10 actual expert supply failed')
        if not (R/'.scratch/mtp-download-budget-20261023/PAUSED').is_file():raise ValueError('Budget pause must be restored')
        tree=ET.parse(out/'results.xml').getroot();cases=list(tree.iter('testcase'))
        if len(cases)!=1 or any(int(tree.get(k,'0')) for k in ('failures','errors','disabled')) or list(tree.iter('skipped')) or list(tree.iter('failure')):
            raise ValueError('Exactly one actual unskipped B10 pass is required')
        item=cases[0]
        if item.get('classname')+'.'+item.get('name')!=case or item.get('status')!='run' or item.get('result')!='completed':raise ValueError('B10 actual selected case differs')
        properties={x.get('name'):x.get('value') for x in item.iter('property')}
        expected=dict(artifact_repository=CONTRACT['repository'],artifact_revision=CONTRACT['revision'],artifact_variant=CONTRACT['variant'],
            static_source_roles='47',static_source_bytes='2566508544',
            expert_source_plan_sha256=h.identity(A/'expert-source-plan.json')['sha256'])
        if any(properties.get(k)!=v for k,v in expected.items()) or int(properties['actual_submissions'])<=0:raise ValueError('B10 actual source identity/graph facts differ')
        h.check_record(h.resolve(ready['consumer_record']['path']))
        result.update(passed=True,case=case,tests=1,failures=0,skips=0,properties=properties,
            actual_graph_submissions=int(properties['actual_submissions']),driver=h.identity(out/'frontier.driver.json'))
    except Exception as error:result['error']=dict(type=type(error).__name__,message=str(error))
    h.save(out/'summary.json',result)
    if not result['passed']:raise SystemExit(process['exit'] or 1)
    print('PASSED actual B10',args.backend,flush=True)


if __name__=='__main__':main()
