from pathlib import Path
import os,subprocess,json,time,sys
route=sys.argv[1];assert route in ('apple','vulkan')
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';out=base/f'g01-native-ragged-{route}';out.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
manifest=json.loads((base/'g01-native-ragged-input-manifest.json').read_text());record=out/'result.json';records=json.loads(record.read_text())['stages'] if record.exists() else []
if route=='vulkan':build=base/'a-vulkan/selected-graph/static-sdk-build'
else:build=base/'a-apple/selected-graph/static-sdk-build'
assert build.is_dir(),'inspect and reuse the actual Apple CPU/native route build tree before running'
hook=out/'project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
 add_subdirectory(/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-native-ragged-gtest EXCLUDE_FROM_ALL)
 function(g01_native_ragged)
  add_executable(g01_native_ragged "'''+str(source/f'tests/compute_route_{route}/native_ragged_test.cc')+'''")
  target_compile_features(g01_native_ragged PRIVATE cxx_std_23)
  target_compile_options(g01_native_ragged PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(g01_native_ragged PRIVATE hyle::compute GTest::gtest_main)
  hyle_stage_runtime(g01_native_ragged)
  if(HYLE_COMPUTE_VULKAN_ENABLED)
   target_sources(g01_native_ragged PRIVATE "'''+str(source/'tests/compute_route_vulkan/native_ragged_cost_test.cc')+'''")
  endif()
 endfunction()
 cmake_language(DEFER CALL g01_native_ragged)
endif()
'''
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
def run(stage,args):
 attempt=1+sum(x['stage']==stage for x in records);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 record.write_text(json.dumps({'phase':'AUDITED native ragged not candidate','canonical_commit':manifest['candidate'],'route':route,'hardware':'actual Mac16,12','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2400));print(f.read(2400).decode(errors='replace'))
  raise SystemExit(r.returncode)
if next((x for x in reversed(records) if x['stage']=='configure'),{}).get('exit_code')!=0:
 run('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook),'-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES'])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_native_ragged','--parallel','4'])
run('run',[str(build/'bin/g01_native_ragged')])
