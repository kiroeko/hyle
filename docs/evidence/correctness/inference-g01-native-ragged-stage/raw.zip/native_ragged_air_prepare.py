from pathlib import Path
old=Path('.scratch/inference-gaps/g01/air_sync.py').read_text()
# Use only the disposable validation copy, never the immutable P1 git sources.
begin=old.index("candidate='3d92")
end=old.index("manifest=",begin)
old=old[:begin]+"candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()\n"+old[end:]
old=old.replace("'phase':'CANDIDATE VP'","'phase':'AUDITED native ragged draft, not candidate'")
old=old.replace("'baseline':'e11fa9ee1'","'baseline':'12dfe9f83'")
old=old.replace('air-input-manifest.json','native-ragged-air-input-manifest.json')
old=old.replace('g01-input-manifest.json','g01-native-ragged-input-manifest.json')
old=old.replace('air-changed-inputs.tar','native-ragged-air-changed-inputs.tar')
old=old.replace('g01-changed-inputs.tar','g01-native-ragged-changed-inputs.tar')
old=old.replace('air-sync-result.json','native-ragged-air-sync-result.json')
exec(compile(old,__file__,'exec'))
