from pathlib import Path
import subprocess,time,json,sys
out=Path.cwd()/'.scratch/inference-gaps/g01';route=sys.argv[1];assert route in ('apple','vulkan')
job=json.loads((out/'cpu-ragged-p1-job-1.json').read_text())
if job['state']!='TERMINAL':raise SystemExit('CPU formal P1 still active; do not start a second heavy run')
assert job['exit_code'] is not None
script=out/'native_ragged_air_checks.py';remote='/Users/kiro/hyle-scratch/compute-unified/native_ragged_air_checks.py'
subprocess.run(['scp',str(script),'kiro@172.22.10.198:'+remote],check=True)
identity=subprocess.check_output(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','uname -m; sw_vers; sysctl -n hw.model; sysctl -n hw.ncpu; sysctl -n hw.memsize; xcrun clang --version | head -n 1'],text=True)
assert 'Mac16,12' in identity
attempt=1+len(list(out.glob(f'native-ragged-air-{route}-*.log')));log=out/f'native-ragged-air-{route}-{attempt}.log';start=time.monotonic()
args=['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3','kiro@172.22.10.198','/usr/bin/python3 '+remote+' '+route]
with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
row={'route':route,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'identity':identity,'log':str(log)}
(out/f'native-ragged-air-{route}-{attempt}.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2200));print(f.read(2200).decode(errors='replace'))
raise SystemExit(r.returncode)
