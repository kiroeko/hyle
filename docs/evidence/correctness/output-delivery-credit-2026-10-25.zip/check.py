from pathlib import Path
import hashlib
import importlib.util
import json

root = Path.cwd()
work = root / '.scratch/inference-output-delivery-20261025'
run = work / 'host2'
run.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('retained_host_build', root / '.scratch/engine-product-20261024/cpu-build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
recipe = build.read(root / '.scratch/inference-incremental-turns-20261025/host1/compile/command.json')['command']
env = build.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': recipe[0], 'CMAKE_CXX_COMPILER': recipe[0], 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
command = []
for index, arg in enumerate(recipe):
    if index and recipe[index - 1] == '/sourceDependencies':
        command.append(str(run / 'dependencies.json'))
    elif arg.startswith('/Fo'):
        command.append('/Fo' + str(run / 'checks.obj'))
    elif arg.startswith('/Fe'):
        command.append('/Fe' + str(run / 'checks.exe'))
    elif arg.endswith('inference_request_progress_test.cc'):
        command.append(str(root / 'tests/tools/inference_output_delivery_test.cc'))
    else:
        command.append(arg)
paths = ['engine/inference/output_delivery.h', 'engine/inference/request_progress.h', 'engine/inference/sampling_cursor.h', 'tests/tools/inference_output_delivery_test.cc', 'tests/CMakeLists.txt']
def pins():
    return {path: {'bytes': (root/path).stat().st_size, 'sha256': hashlib.sha256((root/path).read_bytes()).hexdigest()} for path in paths}
before = pins()
(work / 'source-pins.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf-8')
build.execute(command, env, run / 'compile', 60)
build.execute([str(run / 'checks.exe')], env, run / 'run', 30)
assert before == pins()
print((run / 'run/stdout.log').read_text())
