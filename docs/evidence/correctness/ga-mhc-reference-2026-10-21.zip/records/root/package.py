from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];R=P.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(d):
 p=resolve(d['path']);assert p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+chr(10),encoding='utf8')
config=read(P/'root/final-results.json');cases=[];receipts=[]
def collect(arm,p):
 for x in ET.parse(p).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name')
  cases.append(dict(backend=arm,name=name,neighbor=False,
    properties={i.get('name'):i.get('value') for i in x.findall('./properties/property')}))
for arm in ('cpu','cuda','vulkan'):
 p=resolve(config[arm]);d=read(p)
 assert d['passed'] and d['cases']==1 and not d['skipped'] and not d['failed']
 for k in ('image','link_plan','xml'):check(d[k])
 for row in read(resolve(d['link_plan']['path']))['inputs']:check(row)
 for row in read(p.parent/'runtime-environment.json').get('private_modules',[]):
  check(row['source']);check(row['destination']);assert row['hardlink'] and row['source']['sha256']==row['destination']['sha256']
 collect(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
ap=resolve(config['apple']);a=read(ap);assert a['tests']==1 and a['failed']==a['skipped']==0
check(a['source_freeze'])
for row in a['artifacts'].values():check(row)
assert a['run']['exit']==0 and read(resolve(a['artifacts']['link.result.json']['path']))['exit']==0
collect('apple',resolve(a['artifacts']['tests.xml']['path']))
assert len(cases)==4 and not any(x['neighbor'] for x in cases)
assert all(x['properties']['successful_submissions']=='8' and x['properties']['private_generations']=='2' for x in cases)
assert all(int(x['properties']['maximum_bf16_ulp'])<=1 for x in cases)
for x in cases:
 for key in ('transposed_comb_counterfactual_words','early_bf16_pre_counterfactual_words','omitted_post_bf16_head_counterfactual_words'):
  assert int(x['properties'][key])>0
assert sum(int(x['properties']['successful_submissions']) for x in cases)==32
catalog=read(R/'docs/implementation/model-quantizations.json');assert len(catalog['artifacts'])==33
assert all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
sources=['src/compute_provider_ggml/ggml_cpu_provider.cc',
 'src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_vulkan/region.cc',
 'src/compute_provider_ggml_metal/native_program.cc',
 'src/compute/resource_leases.cc','src/compute_state/state_versions.cc',
 'src/graph/resources.cc','src/graph/executable.cc',
 'include/hyle/compute/state_versions.h','include/hyle/compute/model_ops.h','include/hyle/compute/operation.h',
 'include/hyle/compute/resource_leases.h','include/hyle/graph/result.h','include/hyle/graph/executable.h',
 'tests/compute_models/ga_mhc_fixture.h','tests/compute_models/ga_mhc_reference_fixture.h',
 'tests/compute_models/ga_indexer_state_fixture.h','tests/compute_models/nvfp4_reference_fixture.h',
 'docs/developer/current-work.md','docs/user/graph.md',
 'docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
sources += [f'tests/graph_route_{arm}/{name}' for arm in ('cpu','cuda','vulkan','apple') for name in ('ga_mhc_test.cc','CMakeLists.txt')]
entries={'source/'+s:R/s for s in sources}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.md','.mm','.ps1','.cmake','.in','.d','.cu','.cuh','.metal','.comp'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
entries['provenance/deepseek-v4-ga-2026-10-19.zip']=R/'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'
archive=R/'docs/evidence/correctness/ga-mhc-reference-2026-10-21.zip'
# Entries are project-relative, deterministic, unique and never escape the ZIP.
from pathlib import PurePosixPath
for name,p in entries.items():
 assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and p.is_file(),name
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='four_backend_formal_GA_typed_HC4_pre_post_head_passed',
 scope='Fixed formal GA mHC typed roles: B2/S3 prefill and B2/S1 decode,HC4,D128,two generations each. Original BF16 residual stream and independent real BF16 branch boundary; synthetic F32 parameters. Not a whole attention/expert/model or checkpoint-payload run.',
 mathematics='Widen BF16 state to F32; compute F32 linear before multiplying rsqrt(mean(square(raw state))+1e-6). Pre=sigmoid(mixes*scale0+base)+eps,post=2*sigmoid(mixes*scale1+base). Comb uses initial row softmax+eps, first column normalization and19 row/column pairs; comb[source,destination]. F32 collapse narrowsBF16; independent BF16 branch and residual expand inF32 thenBF16. hc_head projects/normalizes that BF16 post result, F32 sigmoid+eps collapse thenBF16.',
 oracle='Independent scalar source formula and storage bit-rounding helpers, no product mHC operator. Fixed non-symmetric finite synthetic inputs/parameters and sparse cross-stream projection weights selected before backend runs. F32 abs2e-6+rel2e-6; BF16 at most1ULP. All four final runs reportBF16 ULP0; maximum_f32_error is formatted to six decimals and is not a bitwise-zero claim. Payload counterfactuals distinguish wrong comb direction, premature BF16 Pre and omission of Post BF16 before head.',
 journey='Two geometries,two original generations each: preGraph -> original residual/collapsed/post/comb and host geometry in one StateVersion -> post/headGraph. Next pre binds actual BF16 post GraphOutput.storage_lease without host payload reconstruction. First generation publishes F32 audit boundaries,second keeps intermediates private;8submissions/backend.',
 ownership='Original F32 parameter bytes borrowed with caller lifetime when StorageOwner absent, otherwise original owner+ready lease pair. All parameter ReadLeases retained through derived artifacts/results. Dense metadata reshape precedes final material BF16 Cast, preserving independent output lease export. Four cold original Invocations/geometry protect retained fixed native backing. Old GraphOutputs block reset,retain old bytes after program/state/pool closure,and final independent head ReadLease is read after GraphOutputs reset.',
 resources='Finite caller arena reserves every published output from all four programs at256-byte alignment:41472B forS3 and15360B forS1. StateStore retains its original2MiB limit and charges whole original backing, not just subview bytes. Native private storage remains provider-owned/unknown; no total private-memory or zero-copy claim.',
 fixes=config['fixes'],build=config['build'],
 regression=dict(total=4,new_cases=4,neighbors=0,failed=0,skipped=0,successful_Graph_submissions=32,
  windows=receipts,apple=ident(ap),cases=cases),
 limitations=['Finite source-bound HC composition with projected BF16 branch and synthetic F32 parameters; no formal checkpoint tensor payload, complete attention/FFN/expert/model, quality or whole-artifact execution claim.',
  'No product changes or new operator/executor. Only focused wrapper CXX/link/run; no SDK/NVCC/shader rebuild. Full canonical configure/install and Linux not run.',
  'No capture, throughput, universal F32 bitwise-equivalence or total backend-private-memory claim.',
  'Three fixture-contract failures are retained: invalid optional constant ownership pair, private View independent-lease export, and whole-arena StateStore capacity. They are not product numerical failures.',
  'Capability7/8,delivery0/3 remain incomplete; remaining three finite role actions are in review/remaining-role-actions.json. All33 artifact_execution_verified flags remainfalse.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],sources=len(sources),cases=4)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
