"""Freeze actual one-wrapper Apple mHC result; inventory only, no deletion."""
from pathlib import Path
import hashlib,json,runpy,shutil,xml.etree.ElementTree as ET
ROOT=Path.cwd();A=ROOT/".scratch/architecture-refactor-2026-10-18";P=A/"ga-mhc-2026-10-21/apple"
OUT=P/"mac/final";RESULTS=OUT/"results"
def read(p):return json.loads(p.read_text())
def save(p,value):p.write_text(json.dumps(value,indent=2)+"\n")
def identity(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
runpy.run_path(str(P/"audit_dependencies.py"))
audit=read(P/"actual-dependencies-canonical-audit.json");assert audit["drift_count"]==0
compiles=read(RESULTS/"compile-summary.json")["compiles"];assert len(compiles)==1
unique={r["current"]["path"]:r["current"]for c in audit["compiles"]for r in c["canonical"]}
ssh = runpy.run_path(str(A / "batch-query-extent/delegated/apple/validate.py"))["ssh"]
remote = read(OUT / "plan.json")["remote"]
inventory = ssh('''from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['root']);assert r.is_absolute() and r.exists() and not r.is_symlink()
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
images=[];objects=[];dsym=[]
for q in sorted(r.rglob('*')):
 if q.is_symlink():continue
 if q.is_dir():
  if q.suffix=='.dSYM':dsym.append(str(q))
  continue
 if q.suffix=='.o':objects.append(ident(q))
 elif q.suffix=='.map':images.append(ident(q))
 else:
  with q.open('rb')as f:magic=f.read(4)
  if magic in [bytes.fromhex(x)for x in ('cffaedfe','feedfacf','cafebabe','bebafeca')]:images.append(ident(q))
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
active=[s for s in ps.splitlines()if str(r)in s and 'python3 -c'not in s and '/usr/bin/ssh'not in s]
lsof=subprocess.run(['lsof','--',*[x['path']for x in images]],capture_output=True,text=True)
print(json.dumps(dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=images,retained_objects=objects,dsym=dsym,active_image_processes=active,lsof_stdout=lsof.stdout,lsof_stderr=lsof.stderr,lsof_exit=lsof.returncode,deleted=False)))
''', dict(root=remote))
assert not inventory["active_image_processes"] and not inventory["lsof_stdout"]
save(P / "cleanup-readonly-inventory.json", inventory)

for rel,row in unique.items():
    assert identity(ROOT/rel)==row
    dest=P/"source"/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/rel,dest)
registration="tests/graph_route_apple/CMakeLists.txt"
dest=P/"source"/registration;dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(ROOT/registration,dest)
reviewed=["src/compute_provider_ggml_metal/native_program.cc",
          "src/compute_route_apple/apple_operations.cc",
          "src/compute_route_apple/apple_tensor.cc",
          "src/compute_route_apple/apple_mature_reduction.cc"]
source_freeze=dict(status="actual_one_CXX_source_and_every_actual_canonical_dependency_equal_final_Windows_bytes",
    sources=sorted(unique.values(),key=lambda r:r["path"]),
    registration=identity(ROOT/registration),compiled_translation_units=[c["source"]for c in compiles],
    cached_product_source_review=[identity(ROOT/rel)for rel in reviewed],
    canonical_dependency_audit=identity(P/"actual-dependencies-canonical-audit.json"),
    actual_dependency_references=audit["actual_dependency_references"],
    unique_canonical_files=audit["unique_canonical_files"],actual_whole_dependencies_drift=0,
    source_snapshot="source/",SDK_source_copied=False,product_changes=0,
    source_review=identity(P/"leaf-source-review.json"),
    prior_output_view_fixture=identity(P/"prior-output-view-fixture/preservation.json"),
    prior_state_arena_fixture=identity(P/"prior-state-arena-fixture/preservation.json"),
    final_output_materialization="The original BF16 Cast follows metadata reshape; no Copy or additional material buffer.",
    final_output_arena="Cold sum of every published output required_bytes rounded to 256 bytes across four original programs; StateStore limit remains 2MiB.",
    first_constant_pairing_failure="mac/attempt1-runtime-red/results/tests.xml")
save(P/"source-freeze.json",source_freeze)
cases=[dict(name=t.attrib["classname"]+"."+t.attrib["name"],
    properties={v.attrib["name"]:v.attrib["value"]for v in t.findall("./properties/property")})
    for t in ET.parse(RESULTS/"tests.xml").iter("testcase")]
assert len(cases)==1 and cases[0]["properties"]["successful_submissions"]=="8"
validation=read(RESULTS/"validation.json")
assert validation["tests"]==1 and validation["exit"]==0 and not validation["failed"] and not validation["skipped"]
final=dict(status="actual_Mac16_12_Metal_pass",source_freeze=identity(P/"source-freeze.json"),
    hardware=identity(OUT/"hardware.json"),tests=1,new_cases=1,original_neighbors=0,failed=0,skipped=0,
    cases=cases,successful_submissions=8,expected_failure_submissions=0,CXX_jobs=1,
    Apple_product_CXX_jobs=0,common_product_CXX_jobs=0,test_CXX_jobs=1,SDK_jobs=0,product_changes=0,
    compiles=[dict(source=c["source"],exit=c["exit"],object=c["object_identity"],
        dependency_count=len(c["dependencies"]),source_drifts=c["source_drifts"])for c in compiles],
    actual_whole_dependencies_drift=0,actual_dependency_references=audit["actual_dependency_references"],
    unique_canonical_files=audit["unique_canonical_files"],run=read(RESULTS/"run.result.json"),
    image=validation["image"],
    artifacts={n:identity(RESULTS/n)for n in ("compile-summary.json","link-inputs.json","link.command.json","link.result.json","run.command.json","run.result.json","tests.xml","validation.json")},
    attempts_preserved=["attempt1: current-source strict compile passed; runtime failed before numerical submissions because empty StorageOwner was paired with nonempty constant ReadLease",
        "attempt2: actual Apple 1/1 green after root corrected paired fields for original caller-lifetime kBorrow; preserved under prior-output-view-fixture.",
        "attempt3: actual cd631 Apple 1/1 green with final material Cast after metadata reshape; preserved under prior-state-arena-fixture.",
        "attempt4/final: caller-output arena reserves the finite published-output byte sum with 256-byte alignment; original StateStore 2MiB limit remains unchanged. Apple original parameter ReadLeases outlive all GraphOutputs. No product, oracle, tolerance, Copy or additional material buffer change."],
    numeric_evidence=dict(maximum_bf16_ulp=0,maximum_f32_error_display="0.000000",
        maximum_f32_error_display_is_six_decimal_rounding_not_bitwise_zero=True,
        declared_F32_absolute_tolerance=2e-6,declared_F32_relative_tolerance=2e-6,
        declared_BF16_maximum_ulp=1,oracle_or_tolerance_relaxed=False,
        counterfactual_words=dict(transposed_comb=2143,early_bf16_pre=591,omitted_post_bf16_head=251)),
    scope="Formal GA HC4 typed composition on B2/S3 and S1/D128, two original generations each; audit and private graphs; actual BF16 post storage lease feedback and atomic original residual/post/comb StateVersion. Attention/expert branch is an explicit BF16 boundary; no whole model or throughput claim.",
    cleanup_inventory=identity(P/"cleanup-readonly-inventory.json"),no_deletion_performed=True)
save(P/"final-validation.json",final)
for q in (P/"source-freeze.json",P/"final-validation.json",P/"actual-dependencies-canonical-audit.json",P/"cleanup-readonly-inventory.json"):
    print(json.dumps(identity(q)))

