"""Record the bounded F32 mHC source map; no execution or product modification."""
from pathlib import Path
import importlib.util
import hashlib
import zipfile
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
spec=importlib.util.spec_from_file_location('mhc_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
archive=R/'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'
with zipfile.ZipFile(archive) as z:
    members=[]
    for name in ['flash-0731/inference-model.py','flash-0731/inference-kernel.py',
                 'pro-0813/current/inference/model.py','pro-0813/current/inference/kernel.py']:
        payload=z.read(name)
        members.append(dict(member=name,bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest()))
vendor=R/'.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e'
sources=[R/'include/hyle/compute/model_ops.h',R/'src/compute_provider_ggml/ggml_cpu_provider.cc',
         R/'src/compute_provider_ggml_cuda/tensor_program.cc',R/'src/compute_provider_ggml_vulkan/region.cc',
         vendor/'src/ggml.c',vendor/'src/ggml-cpu/ops.cpp',vendor/'src/ggml-cuda/dsv4-hc.cu',
         *[vendor/f'src/ggml-vulkan/vulkan-shaders/dsv4_hc_{leaf}.comp' for leaf in ['comb','pre','post']]]
c.save(S/'leaf-source-review.json',dict(
    status='bounded_source_mapping_no_new_product_gap_found_runtime_pending',
    source_archive=b.identity(archive),source_members=members,
    references=dict(official_model='model.py680-716',official_split='kernel.py372-438',
        public='model_ops.h1167-1279',cpu='ggml_cpu_provider.cc1120-1134 and cached ops.cpp11141-11423',
        cuda='tensor_program.cc975-989 and cached dsv4-hc.cu',
        vulkan='provider region.cc1224-1235 and cached dsv4_hc_{comb,pre,post}.comp'),
    formulas=[
      'Flatten BF16/F32 source streams [B,S,4,D] to F32 [T,4D], T=B*S. Compute f=rsqrt(mean(x*x)+norm_eps). Preserve MatMul(x,hc_fn.T) first, then multiply its F32 result by f.',
      'pre=Sigmoid(mixes[:4]*scale[0]+base[:4])+hc_eps; post=2*Sigmoid(mixes[4:8]*scale[1]+base[4:8]).',
      'comb logits use mixes[8:24]*scale[2]+base[8:24] shaped [T,source,destination]. Softmax last/destination axis, add epsilon, normalize source columns, then 19 row/column normalization pairs for iterations20.',
      'HyperConnectionPre sums source streams: y[t,d]=sum_source(pre[t,source]*residual[t,source,d]); explicit CastBF16 preserves the official branch boundary.',
      'HyperConnectionPost emits destination streams: y[t,destination,d]=branch[t,d]*post[t,destination]+sum_source(residual[t,source,d]*comb[t,source,destination]); explicit final CastBF16.',
      'Head uses separate [4,4D] F32 linear, the same scalar RMS factor and Sigmoid+epsilon pre gate, then HyperConnectionPre; it does not reuse the post factor2.'
    ],
    orientation_proof='Native ggml ne reverses public dimensions. comb[idst*nb0+isrc*nb1+token*nb2] is public comb[token,source,destination]. CPU, CUDA and Vulkan Post use exactly this source-to-destination orientation.',
    shapes=dict(combine=['F32[T,24]','F32[3]','F32[24]','-> F32[T,4,4]'],
        pre=['F32[T,4,D]','F32[T,4]','-> F32[T,D]'],
        post=['F32[T,D]','F32[T,4,D]','F32[T,4]','F32[T,4,4]','-> F32[T,4,D]']),
    layout='Public mHC leaves require dense F32. Ordinary gate arithmetic creates dense outputs; flattened B*S and last-axis linear shapes use existing MatMul/Reduce/Unary/Sigmoid/View/Copy leaves. No generic dtype or stride promise is added.',
    numerical_scope='Mathematical/axis equivalence only. Native CPU/CUDA Combine use reciprocal multiply where producer divides; Vulkan Post uses FMA and reductions differ. This is not a bitwise claim about PyTorch/TileLang or arbitrary nonfinite inputs; shared independent oracle must retain declared numerical tolerances and typed storage boundaries.',
    bounded_future_test='B2/S3 and B2/S1, hc4,D128. Pre/audited and closed Post/head ordinary graphs; exact branch BF16 Cast and original storage lease lifetimes. No complete attention/FFN/model claim.',
    sources=[b.identity(path) for path in sources],
    products_modified=0,compiles=0,GPU_runs=0))
print(b.identity(S/'leaf-source-review.json'))

if __name__=='__main__': pass
