"""Freeze the focused wrapper builds and, when present, parent execution receipts."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
spec=importlib.util.spec_from_file_location('mhc_build',S/'build.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c,R=h.b,h.c,h.R
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--validation',default='')
    parser.add_argument('--attempt',default='attempt2')
    parser.add_argument('--link-dir',default='link2')
    parser.add_argument('--snapshot-dir',default='source-final')
    args=parser.parse_args()
    if args.attempt=='attempt4':
        cpu_ready=c.read(S/'ready-for-root-run-cpu.json')
        gpu_ready=c.read(S/'ready-for-root-run-cuda-vulkan.json')
        assert cpu_ready['shared']==gpu_ready['shared']
        by_arm={x['arm']:x for x in [*cpu_ready['arms'],*gpu_ready['arms']]}
        assert set(by_arm)==set(h.ARMS)
        assert all(b.same(x) for x in cpu_ready['shared'])
        for arm in h.ARMS:
            row=by_arm[arm]
            assert b.same(row['image']) and b.same(row['link_plan'])
            assert c.key(row['link_plan']['path'])==c.key(P/arm/'checks'/args.link_dir/'link-plan.json')
        c.save(S/'ready-for-root-run.json',dict(status='current_three_wrapper_closures_linked_parent_execution_separate',
            arms=[by_arm[a] for a in h.ARMS],shared=cpu_ready['shared'],test_CXX=3,product_CXX=0,
            SDK_builds=0,NVCC_compiles=0,agent_CPU_runs=0,agent_GPU_runs=0))
    revisions=S/'revisions/first-compile-before-borrow-fix'
    revisions.mkdir(parents=True,exist_ok=True)
    for name in ['source-freeze.json','source-dependency-audit.json','build-report.json']:
        old=S/name;target=revisions/name
        if old.exists() and not target.exists(): target.write_bytes(old.read_bytes())
    files=['tests/compute_models/ga_mhc_fixture.h','tests/compute_models/ga_mhc_reference_fixture.h',
           *[f'tests/graph_route_{arm}/{name}' for arm in h.ARMS for name in ['ga_mhc_test.cc','CMakeLists.txt']]]
    sources=[]
    for name in files:
        src=R/name;dst=S/args.snapshot_dir/name
        dst.parent.mkdir(parents=True,exist_ok=True)
        raw=src.read_bytes()
        if dst.exists(): assert dst.read_bytes()==raw
        else: dst.write_bytes(raw)
        sources.append(dict(source=b.identity(src),snapshot=b.identity(dst)))
    records=[];deps={}
    for arm in h.ARMS:
        path=P/arm/'checks'/args.attempt/'identity.json';record=c.read(path)
        assert b.same(record['source']) and b.same(record['object'])
        assert all(b.same(x) for x in record['dependencies'])
        for x in record['dependencies']: deps[c.key(x['path'])]=x
        records.append(dict(arm=arm,identity=b.identity(path),source=record['source'],object=record['object'],
                            dependency_entries=len(record['dependencies'])))
    retained=[]
    for path in [h.PREVIOUS/'common/checks/root-resources1/identity.json',
                 h.PREVIOUS/'common/checks/attempt1/cuda-tensor/identity.json',
                 h.PREVIOUS/'vulkan/checks/rowpitch-fix1/identity.json']:
        data=c.read(path)
        assert b.same(data['source']) and b.same(data['object'])
        retained.append(dict(identity=b.identity(path),source=data['source'],object=data['object']))
    c.save(S/'source-freeze.json',dict(status='eight_test_registration_sources_frozen_no_product_edits',
        sources=sources,retained_current_products=retained,product_CXX=0,SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
    c.save(S/'source-dependency-audit.json',dict(status='three_new_test_owners_all_dependency_entries_match',
        owners=records,dependency_entries=sum(x['dependency_entries'] for x in records),
        unique_dependencies=len(deps),drift=0,dependencies=list(deps.values()),
        prior_product_scope='Retain exact prior final-link1 products. No public/custom schema change; drop the old ratio4 test TU, do not claim every reused product was rebuilt.'))
    compiles=[b.identity(path) for arm in h.ARMS for path in sorted((P/arm/'checks').glob('*/compile.result.json'))]
    links=[b.identity(path) for arm in h.ARMS for path in sorted((P/arm/'checks').glob('*/link.result.json'))]
    results=[c.read(x['path']) for x in [*compiles,*links]]
    assert all(x.get('exit_code',x.get('exit'))==0 for x in results)
    report=dict(status='three_current_strict_wrappers_and_focused_links_passed',test_CXX=len(compiles),successful_test_CXX=len(compiles),
        current_wrapper_CXX=3,product_CXX=0,links=len(links),successful_links=len(links),compiles=compiles,link_results=links,
        first_runtime_rejection='CPU first1 rejected ConstantBinding kBorrow with empty StorageOwner plus nonempty attached ReadLease. This was test resource setup before numeric execution; final shared fixture keeps both attachment fields empty for ownerless borrow and externally retains original parameter leases through all GraphOutputs.',
        private_final_view_rejection='CPU final1 correctly rejected storage_lease from kInvocation private-workspace final View. This is the existing independent-storage contract, not a product bug. The final fixture moves the original final BF16 Cast after metadata reshape, making the published material result independently ownable; head adds one metadata View and node count is not claimed unchanged. No new payload copy or material buffer is introduced.',
        state_backing_budget_rejection='CPU final2 correctly charged an exported caller ReadLease for its whole original 2MiB LeasePool arena, plus input backing and metadata, exceeding the StateStore 2MiB bound. The final fixture retains that bound and computes one bounded original caller arena from all four programs actual output bytes with256 alignment; no product accounting or mathematical tolerance was relaxed.',
        final_attempt=args.attempt,final_link_dir=args.link_dir,
        ready=b.identity(S/'ready-for-root-run.json'),source_freeze=b.identity(S/'source-freeze.json'),
        source_dependency_audit=b.identity(S/'source-dependency-audit.json'),SDK_builds=0,NVCC_compiles=0,
        agent_CPU_runs=0,agent_GPU_runs=0)
    if args.validation:
        receipts=[];modules=[]
        for arm in h.ARMS:
            path=P/arm/'validation'/args.validation/'receipt.json'
            result=c.read(path)
            assert result['passed'] and result['cases']==1 and not result['failed'] and not result['skipped']
            assert all(b.same(result[name]) for name in ['image','link_plan','xml'])
            receipts.append(dict(arm=arm,receipt=b.identity(path),image=result['image'],link_plan=result['link_plan'],
                xml=result['xml'],cases=1,failed=0,skipped=0,executor='parent /root'))
            env_path=path.parent/'runtime-environment.json';env=c.read(env_path)
            for module in env.get('private_modules',[]):
                assert b.same(module['source']) and b.same(module['destination'])
                assert os.path.samefile(module['source']['path'],module['destination']['path'])
                modules.append(dict(record=b.identity(env_path),**module))
        c.save(S/'private-module-staging-proof.json',dict(records=modules,
            scope='Parent exact cached private AVX2 module hardlink; application-directory loading, no loader change or SDK copy. Source retained.',
            agent_runtime=0))
        report.update(status='parent_actual_three_distinct_mhc_tests_passed',validation=receipts,
            distinct_tests=3,failed=0,skipped=0,submissions_per_arm=8,
            scope='B2/S3 and B2/S1 hc4,D128 finite F32 mHC plus original BF16 branch/residual/head storage and state lifetimes; no full attention/FFN/model, original checkpoint payload, throughput or capture claim.',
            private_module_staging=b.identity(S/'private-module-staging-proof.json'))
        report['first_runtime_receipt']=b.identity(P/'cpu/validation/first1/receipt.json')
        report['private_final_view_receipt']=b.identity(P/'cpu/validation/final1/receipt.json')
        report['state_backing_budget_receipt']=b.identity(P/'cpu/validation/final2/receipt.json')
    c.save(S/'build-report.json',report)
    print('Dependencies',sum(x['dependency_entries'] for x in records),len(deps),'unique,0drift')
    print(b.identity(S/'source-freeze.json'))
    print(b.identity(S/'build-report.json'))
if __name__=='__main__':main()
