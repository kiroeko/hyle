"""Compile three focused GA mHC wrappers; reuse the exact current ratio4 product closures."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import re
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
A = P.parent
R = A.parents[1]
PREVIOUS = A / 'ga-ratio4-producer-2026-10-21'
spec = importlib.util.spec_from_file_location('mhc_host_helpers', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
ARMS = ['cpu','cuda','vulkan']

def compile_one(arm, attempt, frozen):
    recipe_path = PREVIOUS / arm / 'checks/attempt3/identity.json'
    recipe = c.read(recipe_path)
    source = R / f'tests/graph_route_{arm}/ga_mhc_test.cc'
    out = P / arm / 'checks' / attempt
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), out
    command = b.host_command(recipe['command'], source, 'ga-mhc-test', out)
    source_identity = b.identity(source)
    c.save(out / 'compile-plan.json', dict(command=command, source=source_identity,
        frozen_shared=frozen, recipe=b.identity(recipe_path), replaced_test=recipe['object'],
        product_compiles=0, SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / 'ga-mhc-test-deps.json')['Data']
    deps = [b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    assert all(b.same(x) for x in [source_identity,*frozen,*deps])
    record = dict(command=command,source=source_identity,frozen_shared=frozen,
        recipe=b.identity(recipe_path),replaced_test=recipe['object'],
        object=b.identity(out/'ga-mhc-test.obj'),dependencies=deps,
        source_dependencies=b.identity(out/'ga-mhc-test-deps.json'))
    c.save(out/'identity.json',record)
    print('COMPILED',arm,flush=True)
    return arm,record

def link_one(arm,record,folder):
    base_path = PREVIOUS / arm / 'checks/final-link1/link-plan.json'
    base = c.read(base_path)
    assert all(b.same(x) for x in base['inputs'])
    old=c.key(record['replaced_test']['path'])
    assert sum(c.key(x['path'])==old for x in base['inputs'])==1
    inputs=[record['object'] if c.key(x['path'])==old else x for x in base['inputs']]
    required=[PREVIOUS/'common/checks/root-resources1/graph-resources.obj']
    if arm=='cuda': required.append(PREVIOUS/'common/checks/attempt1/cuda-tensor/cuda-tensor.obj')
    if arm=='vulkan': required.append(PREVIOUS/'vulkan/checks/rowpitch-fix1/vulkan-provider-region.obj')
    assert all(sum(c.key(x['path'])==c.key(path) for x in inputs)==1 for path in required)
    assert not any(c.key(x['path'])==old for x in inputs)
    assert all(b.same(x) for x in [record['source'],record['object'],*record['frozen_shared'],*inputs])
    command=[record['object']['path'] if c.key(x)==old else x for x in base['command']
             if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out=P/arm/'checks'/folder
    out.mkdir(parents=True,exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists(),out
    image=out/(arm+'.exe')
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    paths=[x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
    assert list(map(c.key,paths))==[c.key(x['path']) for x in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),
        replaced_test=record['replaced_test'],new_test=record['object'],
        retained_current_owners=[b.identity(x) for x in required],
        prior_actual_source_audit=b.identity(PREVIOUS/'windows/actual-source-dependency-audit.json'),
        weak_inline_scope='No custom schema/ABI changes; discard the old ratio4 test TU and retain the already current scoped product closure.',
        product_compiles=0,SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out)
    c.save(out/'image.json',b.identity(image))
    tests=re.findall(r'TEST\(\s*(\w+)\s*,\s*(\w+)\s*\)',Path(record['source']['path']).read_text())
    return dict(arm=arm,image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),
        runtime_environment=b.identity(out/'runtime-environment.json'),
        filter=':'.join(a+'.'+n for a,n in tests))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixture-sha',required=True)
    parser.add_argument('--oracle-sha',required=True)
    parser.add_argument('--attempt',default='attempt1')
    parser.add_argument('--link-dir',default='link1')
    parser.add_argument('--arm',choices=ARMS,action='append')
    args=parser.parse_args()
    shared=[b.identity(R/'tests/compute_models'/name) for name in ['ga_mhc_fixture.h','ga_mhc_reference_fixture.h']]
    assert [x['sha256'] for x in shared]==[args.fixture_sha,args.oracle_sha]
    arms=args.arm or ARMS
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records=dict(pool.map(lambda arm:compile_one(arm,args.attempt,shared),arms))
    assert all(b.same(x) for x in shared)
    ready=[link_one(arm,records[arm],args.link_dir) for arm in arms]
    ready_path=S/('ready-for-root-run'+('' if arms==ARMS else '-'+ '-'.join(arms))+'.json')
    c.save(ready_path,dict(status='focused_wrappers_compiled_linked_not_executed',
        arms=ready,shared=shared,test_CXX=len(arms),product_CXX=0,SDK_builds=0,NVCC_compiles=0,
        agent_CPU_runs=0,agent_GPU_runs=0))
    print(b.identity(ready_path))

if __name__=='__main__': main()
