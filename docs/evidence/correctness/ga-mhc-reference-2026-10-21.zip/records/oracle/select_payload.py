# Bounded synthetic-payload planning before any backend result, not product validation.
import plan_payload as p,json
from pathlib import Path
best=None;observations=[]
for seed in range(32):
 all_e=[]
 for S in [3,1]:
  generations=[];previous=None
  for phase in [0,1]:
   d=p.data(S,phase)
   d['x']=[p.R((89+(r*31+h*67+(k%17)*13+((k%17)//7)*11+phase*43+seed*17)%173)/128.) for r in range(2*S) for h in range(4) for k in range(128)]
   d['branch']=[p.R(((r*23+(k%17)*19+phase*47+17+seed*13)%97-38)/256.) for r in range(2*S) for k in range(128)]
   e=p.reference(d,previous);previous=e['expanded'];generations.append(e)
  all_e+=generations
 score=min(p.margin(e[k]) for e in all_e for k in ['collapsed','raw'])
 score=min(score,min(p.margin(e['h']['raw']) for e in all_e))
 witnesses=all(e['witness']['transposed_comb_words']>0 and e['witness']['early_bfloat_pre_words']>0 and e['witness']['omitted_post_boundary_head_words']>0 for e in all_e)
 observations.append(dict(seed=seed,minimum_midpoint_distance_ulp=score,all_counterfactuals_nonzero=witnesses))
 if witnesses and (best is None or score>best['minimum_midpoint_distance_ulp']):best=observations[-1]
out=dict(scope='32 bounded host-only synthetic payload choices before backend execution; fixed 17-value feature pattern',selected=best,choices=observations)
Path(__file__).with_name('payload-selection.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(best))
