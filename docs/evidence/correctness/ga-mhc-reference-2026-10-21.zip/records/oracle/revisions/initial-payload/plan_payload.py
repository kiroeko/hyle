# Independent host-only scalar payload planning; no Hyle operators or backend calls.
import json,struct,math,hashlib
from pathlib import Path
F=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def bf(x):
 b=bits(x);return ((b+0x7fff+((b>>16)&1))>>16)&65535
def wide(b):return struct.unpack('<f',struct.pack('<I',b<<16))[0]
R=lambda x:wide(bf(x))
add=lambda a,b:F(a+b)
mul=lambda a,b:F(a*b)
div=lambda a,b:F(a/b)
sig=lambda x:div(1.,add(1.,F(math.exp(-x))))
def data(S,phase):
 rows=2*S
 x=[R((89+(r*31+h*67+d*13+(d//7)*11+(phase%7)*43)%173)/128.) for r in range(rows) for h in range(4) for d in range(128)]
 branch=[R(((r*23+d*19+(phase%7)*47+17)%97-38)/256.) for r in range(rows) for d in range(128)]
 fn=[[0.]*512 for _ in range(24)];hf=[[0.]*512 for _ in range(4)]
 for o in range(24):
  for t in range(12):fn[o][(o*29+t*71+t*t*7)%512]=((o*19+t*23+5)%61-29)/1024.
 for o in range(4):
  for t in range(12):hf[o][(o*43+t*59+t*t*3+17)%512]=((o*31+t*17+7)%67-31)/1024.
 return dict(S=S,x=x,branch=branch,fn=fn,hf=hf,base=[((o*37+11)%101-49)/128. for o in range(24)],scale=[1.173828125,-.919921875,1.083984375],hs=1.04296875,hb=[-.31298828125,.17626953125,.42724609375,-.10888671875])
def project(x,w,rows):
 factors=[];linear=[];mix=[]
 for r in range(rows):
  v=x[r*512:(r+1)*512];s=0.
  for a in v:s=add(s,mul(a,a))
  f=F(1/math.sqrt(add(div(s,512.),F(1e-6))));factors.append(f)
  for weight in w:
   dot=0.
   for a,b in zip(v,weight):dot=add(dot,mul(a,b))
   linear.append(dot);mix.append(mul(dot,f))
 return factors,linear,mix
def sink(logits):
 a=[];eps=F(1e-6)
 for src in range(4):
  row=logits[src*4:src*4+4];m=max(row);v=[F(math.exp(add(x,-m))) for x in row];s=0.
  for x in v:s=add(s,x)
  a += [add(div(x,s),eps) for x in v]
 def col():
  for dst in range(4):
   s=0.
   for src in range(4):s=add(s,a[src*4+dst])
   s=add(s,eps)
   for src in range(4):a[src*4+dst]=div(a[src*4+dst],s)
 col()
 for _ in range(19):
  for src in range(4):
   s=0.
   for dst in range(4):s=add(s,a[src*4+dst])
   s=add(s,eps)
   for dst in range(4):a[src*4+dst]=div(a[src*4+dst],s)
  col()
 return a
def head(d,x):
 f,l,m=project(x,d['hf'],2*d['S']);pre=[];raw=[]
 for r in range(2*d['S']):
  p=[add(sig(add(mul(m[r*4+h],d['hs']),d['hb'][h])),F(1e-6)) for h in range(4)];pre+=p
  for k in range(128):
   s=0.
   for h in range(4):s=add(s,mul(p[h],x[r*512+h*128+k]))
   raw.append(s)
 return dict(f=f,l=l,m=m,p=pre,raw=raw,out=list(map(R,raw)))
def reference(d,x=None):
 x=d['x'] if x is None else x;rows=2*d['S'];f,l,m=project(x,d['fn'],rows);pre=[];post=[];comb=[];collapsed=[];raw=[];early=[];wrong=[]
 for r in range(rows):
  p=[add(sig(add(mul(m[r*24+h],d['scale'][0]),d['base'][h])),F(1e-6)) for h in range(4)]
  po=[mul(2.,sig(add(mul(m[r*24+4+h],d['scale'][1]),d['base'][4+h]))) for h in range(4)]
  c=sink([add(mul(m[r*24+8+k],d['scale'][2]),d['base'][8+k]) for k in range(16)]);pre+=p;post+=po;comb+=c
  cr=[];er=[]
  for k in range(128):
   s=0.;e=0.
   for h in range(4):s=add(s,mul(p[h],x[r*512+h*128+k]));e=R(add(e,R(mul(R(p[h]),x[r*512+h*128+k]))))
   cr.append(s);er.append(e)
  collapsed+=cr;early+=er
  for dst in range(4):
   for k in range(128):
    s=0.;w=0.
    for src in range(4):s=add(s,mul(c[src*4+dst],x[r*512+src*128+k]));w=add(w,mul(c[dst*4+src],x[r*512+src*128+k]))
    term=mul(po[dst],d['branch'][r*128+k]);raw.append(add(term,s));wrong.append(add(term,w))
 expanded=list(map(R,raw));h=head(d,expanded);oh=head(d,raw)
 return dict(expanded=expanded,collapsed=collapsed,raw=raw,h=h,pre=pre,post=post,comb=comb,f=f,l=l,m=m,witness=dict(transposed_comb_words=sum(bf(a)!=bf(b) for a,b in zip(raw,wrong)),transposed_comb_maximum_error=max(abs(a-b) for a,b in zip(raw,wrong)),early_bfloat_pre_words=sum(bf(a)!=bf(b) for a,b in zip(collapsed,early)),omitted_post_boundary_head_words=sum(bf(a)!=bf(b) for a,b in zip(h['raw'],oh['raw']))))
def margin(v):
 ans=1.
 for x in v:
  b=bits(x);lo=b>>16;frac=(b&65535)/65536.;ans=min(ans,abs(frac-.5))
 return ans
def main():
 results=[]
 for S in [3,1]:
  d=data(S,0);e0=reference(d);d1=data(S,1);e1=reference(d1,e0['expanded'])
  assert d['fn']==d1['fn'] and d['hf']==d1['hf']
  for generation,e in enumerate([e0,e1]):
   assert all(e['witness'][k]>0 for k in ['transposed_comb_words','early_bfloat_pre_words','omitted_post_boundary_head_words'])
   vals=e['collapsed']+e['raw']+e['h']['raw'];assert all(math.isfinite(x) and x>0 for x in vals)
   results.append(dict(tokens=S,generation=generation,witness=e['witness'],finite_positive_endpoints=True,raw_range=[min(vals),max(vals)],bf16_midpoint_distance_ulps=dict(collapsed=margin(e['collapsed']),post=margin(e['raw']),head=margin(e['h']['raw'])),comb_row_sum_range=[min(sum(e['comb'][i:i+4]) for i in range(0,len(e['comb']),4)),max(sum(e['comb'][i:i+4]) for i in range(0,len(e['comb']),4))]))
 header=Path('tests/compute_models/ga_mhc_reference_fixture.h')
 out=dict(kind='independent scalar payload plan, not backend/product validation',source_header=str(header),source_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),geometries=results,tolerances=dict(float32_absolute=2e-6,float32_relative=2e-6,bfloat16_maximum_adjacent_ulp=1),notes=['Parameter matrices fixed across generations; only dynamic stream and independent branch change.','Generation1 oracle uses generation0 expected BF16 expanded stream, never actual backend payload.','Small midpoint distance can occur among thousands of words; one-ULP BF16 envelope is fixed, not adjusted after results.','Sparse F32 cross-stream projection weights are synthetic formula tests, not formal checkpoint payload.'])
 target=Path(__file__).with_name('payload-plan.json');target.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
