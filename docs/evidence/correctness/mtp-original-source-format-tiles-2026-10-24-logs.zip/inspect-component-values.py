from pathlib import Path
import hashlib,json,math,struct
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def bf16(x):
 b=struct.unpack('<I',struct.pack('<f',x))[0];b=(b+0x7fff+((b>>16)&1))>>16;return struct.unpack('<f',struct.pack('<I',(b&65535)<<16))[0]
def e4(c):
 x=c&127;e=x>>3;v=math.nan if x==127 else math.ldexp(x&7,-9)if e==0 else math.ldexp(1+(x&7)/8,e-7)
 return -v if c&128 else v
def sf(b,t):
 if t=='BF16':return [struct.unpack('<f',struct.pack('<I',x<<16))[0]for x in struct.unpack('<'+'H'*(len(b)//2),b)]
 if t=='F32':return list(struct.unpack('<'+'f'*(len(b)//4),b))
 return [math.ldexp(1,x-127)if x!=255 else math.nan for x in b]
out=[];plan=read(S/'source-component-plan.json');acq=read(S/'source-component-results.json');assert acq['complete']
for c in plan['components']:
 data={r['kind']:(R/r['output']).read_bytes()for r in c['ranges']};proof=next(x for x in acq['results']if x['id']==c['id'])
 for x in proof['ranges']:
  b=data[x['kind']];assert len(b)==x['file']['bytes']and hashlib.sha256(b).hexdigest()==x['file']['sha256']
 sr=next(r for r in c['ranges']if r['kind']=='scales');scales=sf(data['scales'],sr['original']['dtype']);k=c['full_reduction_K'];n=c['selected_N']
 values=[];witness=[]
 if c['codec'].startswith('fp8'):
  for row in range(n):
   for col in range(k):
    q=e4(data['codes'][row*k+col]);s=scales[col//128];x=f32(q*s);values.append(x)
    if math.isfinite(x)and bf16(x)!=x:witness.append(dict(row=row,k=col,code=data['codes'][row*k+col],scale=s,F32=x,BF16=bf16(x)))
 result=dict(id=c['id'],catalog_index=c['catalog_index'],source_dtype=sr['original']['dtype'],original_codes_bytes=len(data['codes']),original_scales_bytes=len(data['scales']),scale_count=len(scales),
  nonfinite_scales=sum(not math.isfinite(s)for s in scales),nonpositive_scales=sum(not s>0 for s in scales),
  positive_non_power2_scales=sum(s>0 and math.isfinite(s)and math.frexp(s)[0]!=.5 for s in scales),minimum_scale=min(scales),maximum_scale=max(scales),
  negative_signed_carrier_bytes=sum(b>=128 for b in data['codes'])if sr['original']['dtype']=='F8_E8M0'and c['codec'].startswith('fp4')else None,
  E4_reserved_values=sum((b&127)==127 for b in data['codes'])if c['codec'].startswith('fp8')else None,
  weight_product_BF16_rounding_witnesses=len(witness),first_product_witness=witness[0]if witness else None,
  actual_weight_execution_verified=False)
 out.append(result)
(S/'source-component-value-facts.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(out,indent=2))
