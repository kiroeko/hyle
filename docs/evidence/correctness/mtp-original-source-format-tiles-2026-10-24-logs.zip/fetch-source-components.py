"""Acquire only the fixed original codec/math tiles; check performs no HTTP."""
from pathlib import Path
import argparse,importlib.util,inspect,json,math,re,sys,urllib.request
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];SCRIPT=Path(__file__).resolve().relative_to(ROOT).as_posix()
PLAN=HERE/'source-component-plan.json';BUDGET=ROOT/'.scratch/mtp-download-budget-20261023/budget.py'
spec=importlib.util.spec_from_file_location('component_exact_transport',HERE/'fetch-small-headers.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.SCRIPT=SCRIPT
def identity(p):
 raw=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(raw),sha256=h.digest(raw))
def check():
 p=h.parse_json(PLAN.read_bytes())
 if len(p['components'])!=8 or p['maximum_HTTP_requests']!=16 or p['total_new_tensor_payload_bytes']!=89704:raise ValueError('Explicit component batch bounds changed')
 if p['full_models_or_expert_libraries']or p['tensor_body_limit_per_request']!=h.HEADER_LIMIT:raise ValueError('Only bounded source tiles permitted')
 for item in p['helpers']:
  if identity(ROOT/item['path'])!=item:raise ValueError('Reviewed transport changed')
 total=0;paths=set()
 for c in p['components']:
  if not re.fullmatch('[0-9a-f]{40}',c['revision'])or c['selected_N']!=3:raise ValueError('Pinned source/tile geometry required')
  source=c['source'];row=dict(repository=c['repository'],revision=c['revision'],file=source['file'],uri=c['uri'])
  if row['uri']!=f'https://hf-mirror.net/{row["repository"]}/resolve/{row["revision"]}/{row["file"]}':raise ValueError('Fixed mirror source changed')
  folder=HERE/(f'cat{c["catalog_index"]:02d}'if c['catalog_index']==6 else f'indexes/cat{c["catalog_index"]:02d}')
  actual_source=h.crosscheck_tree_identity(row,(folder/'expanded-api.json').read_bytes(),(folder/'tree-api.json').read_bytes())
  if actual_source!=source:raise ValueError('Independent original API/tree source changed')
  for key in ['header','header_acquisition']:
   if identity(ROOT/c[key]['path'])!=c[key]:raise ValueError('Original schema/acquisition changed')
  raw=(ROOT/c['header']['path']).read_bytes();schema=h.parse_header(raw,source['size'])['all_physical_tensors'];a=h.parse_json((ROOT/c['header_acquisition']['path']).read_bytes())
  if a['source']!=source or a['header_sha256']!=h.digest(raw):raise ValueError('Original header proof changed')
  if len(c['ranges'])!=2 or {r['kind']for r in c['ranges']}!={'codes','scales'}:raise ValueError('Only exact principal/scale pair allowed')
  for r in c['ranges']:
   x=schema[r['name']]
   if x!=r['original']or len(x['shape'])!=2:raise ValueError('Physical source role changed')
   width=h.DTYPE_BYTES[x['dtype']];rows=r['selection']['axis0_count'];cols=x['shape'][1]
   if r['selection']!=dict(axis0_first=0,axis0_count=rows,axis1_full=True)or not 0<rows<=3 or r['selected_shape']!=[rows,cols]:raise ValueError('Only fixed first-row/fullK source selection allowed')
   if math.prod(x['shape'])*width!=x['data_offsets'][1]-x['data_offsets'][0]or r['bytes']!=rows*cols*width:raise ValueError('Source physical byte geometry differs')
   first=8+len(raw)+x['data_offsets'][0]
   if r['absolute_inclusive']!=[first,first+r['bytes']-1]or not 0<r['bytes']<=h.HEADER_LIMIT:raise ValueError('Source range is not exact tile')
   expected=HERE/'components'/c['id']/(r['kind']+'.bin');output=(ROOT/r['output']).resolve()
   if output!=expected or output in paths:raise ValueError('Component output must be unique and inside fixed workspace')
   paths.add(output);total+=r['bytes']
 if total!=89704:raise ValueError('Exact total bound differs')
 return p
def acquire(budget,c,owner):
 folder=HERE/'components'/c['id'];folder.mkdir(parents=True,exist_ok=True)
 row=dict(repository=c['repository'],revision=c['revision'],uri=c['uri']);fetch=h.Fetch(budget,row,timeout=30,receipt_dir=folder);results=[]
 for r in c['ranges']:
  if not owner.is_file():raise RuntimeError('Root acquisition ended; no further HTTP')
  budget.require_enabled();output=ROOT/r['output'];receipt=output.with_suffix('.acquisition.json')
  if receipt.exists():
   old=h.parse_json(receipt.read_bytes());raw=output.read_bytes()
   if old['source']!=c['source']or old['range']!=r['absolute_inclusive']or len(raw)!=r['bytes']or old['sha256']!=h.digest(raw):raise ValueError('Retained complete component source changed')
  else:
   if output.exists():raise ValueError('Unreceipted existing component file; inspect before acquisition')
   raw,response=fetch.get(*r['absolute_inclusive'],source=c['source'])
   output.write_bytes(raw);old=dict(source=c['source'],role=r['name'],original=r['original'],selection=r['selection'],range=r['absolute_inclusive'],bytes=len(raw),sha256=h.digest(raw),response=response)
   h.save(receipt,old)
  results.append(dict(kind=r['kind'],file=identity(output),acquisition=identity(receipt)))
 result=dict(id=c['id'],catalog_index=c['catalog_index'],repository=c['repository'],revision=c['revision'],source=c['source'],reader=c['reader'],ranges=results,original_tensor_bytes=sum(r['bytes']for r in c['ranges']),numeric_test_executed=False,scope=c['not_claimed'])
 h.save(folder/'acquisition.json',result);return result
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',nargs='?',default='check',choices=['check','fetch']);p.add_argument('--owner-marker');a=p.parse_args();plan=check()
 if a.action=='check':print(json.dumps(dict(state='offline_original_component_plan_valid',components=8,requests=16,bytes=89704,HTTP=0)));return
 if a.owner_marker!=plan['required_owner_marker']:p.error('Exact existing root-held marker required')
 owner=BUDGET.parent/a.owner_marker
 if not owner.is_file()or(BUDGET.parent/'PAUSED').exists():raise RuntimeError('Root does not hold enabled acquisition; no HTTP opened')
 fn=urllib.request.urlopen
 if not inspect.isfunction(fn)or Path(fn.__code__.co_filename).resolve()!=BUDGET.resolve()or inspect.getclosurevars(fn).nonlocals.get('script')!=SCRIPT:raise RuntimeError('Only existing budget.py run may execute HTTP')
 budget=h.module();results=[]
 for c in plan['components']:
  results.append(acquire(budget,c,owner));h.save(HERE/'source-component-results.json',dict(results=results,planned=8,complete=len(results)==8))
 print(json.dumps(dict(components=len(results),original_tensor_bytes=sum(r['original_tensor_bytes']for r in results),numeric_test_executed=False)))
if __name__=='__main__':main()
