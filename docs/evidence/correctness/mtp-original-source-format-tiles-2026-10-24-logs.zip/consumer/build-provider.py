from pathlib import Path
import importlib.util,json,os,sys,shutil
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parents[2]
spec=importlib.util.spec_from_file_location('source_component_build',O/'check.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q);b=q.b
def compile_one(name,source,template,native):
 old=b.read(R/template);flags=[];skip=False
 for arg in old['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd'))or arg.lower().endswith('.cc'):continue
  flags.append(arg)
 folder=O/name;folder.mkdir(exist_ok=True);obj=folder/(name+'.obj');src=R/source;frozen=b.identity(src)
 command=[*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(src),'/Fo'+str(obj),'/Fd'+str(folder/(name+'.pdb'))]
 q.execute(command,native.env,name,180)
 if b.identity(src)!=frozen:raise RuntimeError('Source changed during compile')
 deps=b.read(folder/'dependencies.json')['Data'];b.save(folder/'identity.json',dict(command=command,source=frozen,object=b.identity(obj),dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
 return obj
def main():
 cc=b.read(R/'.scratch/dense-linear-f32-20261024/test-ggml/identity.json')['command'][0]
 native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
 previous=O/'before-domain-fix';previous.mkdir(exist_ok=True)
 for path in [O/'run/stdout.log',O/'run/stderr.log',O/'tests.json',O/'run/process.json']:
  target=previous/path.name
  if not target.exists():shutil.copyfile(path,target)
 product=compile_one('fp4-provider','src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc','.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/records/compute_provider_cuda--deepseek_grouped_fp4_provider/identity.json',native)
 tests=compile_one('test-provider','tests/compute_provider_cuda/cuda_provider_test.cc','.scratch/dense-linear-f32-20261024/test-ggml/identity.json',native)
 source=b.read(O/'compile/identity.json');b.require(source['source']);b.require(source['object'])
 command=[]
 for arg in b.read(O/'link-plan.json')['command']:
  if Path(arg).name=='compute_provider_cuda--deepseek_grouped_fp4_provider.obj':arg=str(product)
  if Path(arg).name=='test-provider.obj':continue
  command.append(arg)
 command.append(str(tests));b.save(O/'link-plan.json',dict(command=command,fresh_TUs=3,SDK_builds=0,HTTP=0,reused_kernel=True));q.execute(command,native.env,'link',120)
 ready=b.read(O/'ready.json');ready['image']=b.identity(Path(ready['image']['path']));b.save(O/'ready.json',ready)
 print('PASS provider/test incrementally built; existing kernel and consumer reused',flush=True)
if __name__=='__main__':main()
