#include <gtest/gtest.h>
#include "tests/compute_models/ct_packed_graph_fixture.h"
#include "tests/compute_models/nvfp4_reference_fixture.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/weight_import.h"
#include "hyle/graph/cpu.h"
#include "hyle/graph/cuda.h"
#include <filesystem>
#include <fstream>
#include <iostream>

namespace {
namespace f=ct_packed_graph_test;
namespace s=nvfp4_reference_test;
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
using Type=c::DataType;
std::filesystem::path source_root;
enum class Scale { kBFloat16,kFloat32,kE8M0 };
enum class Kind { kFloat8,kInferact,kDeepSeekFloat4 };
struct Source { const char*name; std::int64_t k; Scale scale; Kind kind; };
constexpr std::array cases{
 Source{"q27-fp8-bf16-sf",5120,Scale::kBFloat16,Kind::kFloat8},
 Source{"q24-fp8-bf16-sf",2048,Scale::kBFloat16,Kind::kFloat8},
 Source{"inferact-f32-sf",2048,Scale::kFloat32,Kind::kInferact},
 Source{"deepseek-25-fp4-e8-sf",7168,Scale::kE8M0,Kind::kDeepSeekFloat4},
 Source{"deepseek-25-fp8-e8-sf",7168,Scale::kE8M0,Kind::kFloat8},
 Source{"deepseek-26-fp4-e8-sf",4096,Scale::kE8M0,Kind::kDeepSeekFloat4},
 Source{"deepseek-26-fp8-e8-sf",4096,Scale::kE8M0,Kind::kFloat8},
 Source{"dspark-fp8-f32-sf",4096,Scale::kFloat32,Kind::kFloat8}};
constexpr std::int64_t n=3,tokens=3,slots=2;
std::vector<std::byte> load(const std::filesystem::path&p,std::size_t size) {
 std::ifstream in(p,std::ios::binary|std::ios::ate);
 if(!in||in.tellg()!=static_cast<std::streamoff>(size))throw std::runtime_error("Wrong-size original source: "+p.string());
 std::vector<std::byte>b(size);in.seekg(0);
 if(!in.read(reinterpret_cast<char*>(b.data()),static_cast<std::streamsize>(size)))throw std::runtime_error("Original source read failed");
 return b;
}
unsigned little(std::span<const std::byte>b,std::size_t at,unsigned count) {
 unsigned x=0;for(unsigned i=0;i<count;++i)x|=std::to_integer<unsigned>(b[at+i])<<(8*i);return x;
}
float e8(unsigned x) {return x==255?std::numeric_limits<float>::quiet_NaN():std::ldexp(1.F,int(x)-127);}
float e2(unsigned x) {
 constexpr std::array<float,8>a{0.F,.5F,1.F,1.5F,2.F,3.F,4.F,6.F};
 return std::copysign(a[x&7],x&8?-1.F:1.F);
}
struct Data {
 Source source;std::vector<std::byte> codes,raw_scales,canonical;std::vector<float> scales;
 std::vector<std::uint8_t> imported_e8;std::array<std::int64_t,3> positions{0,129,0};
 std::size_t product_round_witnesses=0;
 c::TensorDesc weight_description;
 explicit Data(Source src):source(src) {
  const bool fp8=src.kind==Kind::kFloat8;const auto count=static_cast<std::size_t>(fp8?src.k/128:n*(src.k/32));
  codes=load(source_root/src.name/"codes.bin",static_cast<std::size_t>(n*src.k/(fp8?1:2)));
  raw_scales=load(source_root/src.name/"scales.bin",count*(src.scale==Scale::kFloat32?4:src.scale==Scale::kBFloat16?2:1));
  for(std::size_t i=0;i<count;++i) {
   const float v=src.scale==Scale::kFloat32?std::bit_cast<float>(little(raw_scales,i*4,4)):
    src.scale==Scale::kBFloat16?s::wide(static_cast<std::uint16_t>(little(raw_scales,i*2,2))):e8(little(raw_scales,i,1));
   if(!(v>0)||!std::isfinite(v))throw std::runtime_error("Unexpected original scale domain");scales.push_back(v);
  }
  positions[2]=src.k-1;
  if(fp8) {
   bool found=false;
   for(std::int64_t r=0;r<n;++r)for(std::int64_t k=0;k<src.k;++k) {
    const float v=s::multiply(s::e4m3(static_cast<std::uint8_t>(little(codes,static_cast<std::size_t>(r*src.k+k),1))),scales[static_cast<std::size_t>(k/128)]);
    if(!std::isfinite(v))throw std::runtime_error("Original E4 weight not finite");
    if(s::rounded_bf16(v)!=v) {++product_round_witnesses;if(!found){positions[0]=k;found=true;}}
   }
   weight_description=f::take(c::float8_weight_description(src.k,n,c::Float8ScaleMode::kFloat32Block128),"FP8 canonical desc");
   auto code_buffer=f::take(m::Buffer::create(m::system_resource(),codes.size(),64),"source E4");
   auto scale_buffer=f::take(m::Buffer::create(m::system_resource(),scales.size()*4,64),"explicit F32 SF");
   auto result=f::take(m::Buffer::create(m::system_resource(),f::take(weight_description.required_bytes(),"FP8 bytes"),64),"canonical FP8");
   f::check(code_buffer.view().write(codes),"source code write");
   f::check(scale_buffer.view().write(std::as_bytes(std::span(scales))),"exact scale numeric widening");
   f::check(c::import_float8_block128_weight(
    f::take(c::ConstTensorView::create(f::dense(Type::kFloat8E4M3FN,{n,src.k}),code_buffer.view()),"source E4 tensor"),
    f::take(c::ConstTensorView::create(f::dense(Type::kFloat32,{1,src.k/128}),scale_buffer.view()),"source SF tensor"),
    f::take(c::TensorView::create(weight_description,result.view()),"canonical FP8 tensor")),"cold FP8 import");
   canonical.resize(result.size());f::check(result.view().read(canonical),"read canonical bytes");
   auto expected=codes;const auto sf=std::as_bytes(std::span(scales));expected.insert(expected.end(),sf.begin(),sf.end());
   if(canonical!=expected)throw std::runtime_error("Original codes or exact F32 scale bits changed during import");
  }else if(src.kind==Kind::kInferact) {
   auto input=f::take(m::Buffer::create(m::system_resource(),raw_scales.size(),64),"original F32 scales");
   auto output=f::take(m::Buffer::create(m::system_resource(),scales.size(),64),"E8 numeric import");
   f::check(input.view().write(raw_scales),"original SF bytes");
   f::check(c::encode_e8m0_scales(
    f::take(c::ConstTensorView::create(f::dense(Type::kFloat32,{n,src.k/32}),input.view()),"original F32SF"),
    f::take(c::TensorView::create(f::dense(Type::kUInt8,{n,src.k/32}),output.view()),"E8SF")),"fixed-reader numeric F32->E8 import");
   imported_e8.resize(scales.size());f::check(output.view().read(std::as_writable_bytes(std::span(imported_e8))),"read imported SF");
   for(std::size_t i=0;i<scales.size();++i) {
    int exponent=0;const float mantissa=std::frexp(scales[i],&exponent);
    // All selected source SF happen to be powers of two. Threshold-domain
    // RNE proof remains in the existing independent generic import tests.
    if(mantissa!=.5F||imported_e8[i]!=exponent+126)throw std::runtime_error("Original power-two scale numeric import differs");
   }
  }else {
   weight_description=f::take(c::float4_grouped_weight_description(1,n,src.k),"FP4 canonical desc");
   canonical=codes;const auto sf=std::as_bytes(std::span(scales));canonical.insert(canonical.end(),sf.begin(),sf.end());
   if(canonical.size()!=f::take(weight_description.required_bytes(),"FP4 bytes"))throw std::runtime_error("FP4 carrier extent differs");
  }
 }
 unsigned code(std::int64_t row,std::int64_t k)const {
  const auto b=little(codes,static_cast<std::size_t>(row*(source.k/2)+k/2),1);return (b>>((k%2)*4))&15;
 }
};
struct SystemResource {m::MemoryResourceRef ref()noexcept{return m::system_resource();}};
struct Cpu {
 static c::Context context(){return f::take(g::cpu::create_context(),"CPU context");}
 static c::StorageOwner owner(const c::Context&ctx){return f::take(c::StorageOwner::adopt(ctx,SystemResource{}),"CPU owner");}
 static hyle::Result<g::CompiledGraph> compile(const g::Graph&graph,const c::Context&ctx,const c::StorageOwner&,g::CompileOptions o){return g::cpu::compile(graph,ctx,o);}
 static hyle::Status prepare(g::Invocation&slot,c::Queue&q,bool){const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&q}};return slot.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow});}
};
struct Cuda {
 static c::Context context(){return f::take(g::cuda::create_context(),"CUDA context");}
 static c::StorageOwner owner(const c::Context&ctx){return f::take(c::StorageOwner::adopt(ctx,f::take(c::cuda::MemoryResource::create(ctx,c::cuda::MemoryKind::kDevice),"CUDA resource")),"CUDA owner");}
 static hyle::Result<g::CompiledGraph> compile(const g::Graph&graph,const c::Context&ctx,const c::StorageOwner&owner,g::CompileOptions o){return g::cuda::compile(graph,ctx,owner,o);}
 static hyle::Status prepare(g::Invocation&slot,c::Queue&q,bool){return g::cuda::prepare_replay(slot,q,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow});}
};
struct Quantized {float code,scale;};
Quantized activation(float value) {
 const float maximum=(std::max)(std::fabs(value),1.e-4F);
 const float raw=s::multiply(maximum,s::f32(1./448.));int e=0;const float mantissa=std::frexp(raw,&e);
 const float scale=std::ldexp(1.F,mantissa==.5F?e-1:e);
 const float normalized=s::f32(double(value)/scale);
 const float code=std::copysign(s::e4m3(s::encode_scale(std::fabs(normalized))),value);
 return {code,scale};
}
template<class Backend>void verify(Source source) {
 SCOPED_TRACE(source.name);const Data d(source);auto context=Backend::context();auto owner=Backend::owner(context);auto queue=f::take(context.create_queue(),"queue");
 const bool fp8=source.kind==Kind::kFloat8;
 for(const auto type:{Type::kFloat32,Type::kBFloat16}) {
  if(!fp8&&type==Type::kFloat32)continue;
  SCOPED_TRACE(static_cast<int>(type));auto builder=f::take(g::GraphBuilder::create(),"builder");
  const bool encoded_activation=fp8&&type==Type::kFloat32;
  const auto ad=encoded_activation?f::take(c::float8_activation_description(tokens,source.k,c::Float8ScaleMode::kFloat32Block128),"explicit encoded A"):
   fp8?f::dense(type,{tokens,source.k}):f::dense(type,{tokens,1,source.k});
  const auto a=f::take(builder.input(ad),"activation port");
  std::vector<c::ReadLease> constants;std::vector<g::ConstantBinding> bindings;
  auto weight=[&](const c::TensorDesc&desc,std::span<const std::byte>bytes) {
   auto value=f::take(builder.constant(desc),"original constant");constants.push_back(f::upload(owner,bytes));
   bindings.push_back({value,f::take(constants.back().tensor(desc),"ready original tensor"),g::ConstantPolicy::kBorrow,owner,constants.back()});return value;
  };
  g::ValueId y,id;std::vector<c::ReadLease> runtime;
  if(fp8) {
   auto w=weight(d.weight_description,d.canonical);
   y=encoded_activation?f::take(builder.add(c::MatMul{.accumulation_type=Type::kFloat32},a,w),"encoded A/F32 projection boundary"):
    f::take(builder.add(c::model_ops::float8_block_linear(c::model_ops::Float8ScalePolicy::kPowerOfTwo,1.e-4F),a,w),"BF16 dynamic FP8 profile");
  }else {
   const auto ids_desc=f::dense(Type::kInt32,{tokens,slots});id=f::take(builder.input(ids_desc),"explicit checked IDs");
   if(source.kind==Kind::kInferact) {
    auto w=weight(f::dense(Type::kUInt8,{1,n,source.k/2}),d.codes);
    auto sf=weight(f::dense(Type::kUInt8,{1,n,source.k/32}),std::as_bytes(std::span(d.imported_e8)));
    y=f::take(builder.add(c::model_ops::grouped_mxfp4_linear(c::model_ops::Mxfp4ActivationMode::kBFloat16),a,w,sf,id),"fixed-reader W4A16");
   }else {
    auto w=weight(d.weight_description,d.canonical);
    y=f::take(builder.add(c::model_ops::grouped_float4_linear(),w,a,id),"source dynamic-FP8/FP4 profile");
   }
  }
  f::check(builder.publish(y),"publish");auto graph=f::take(std::move(builder).finish(),"graph");
  const auto yd=f::take(graph.value_description(y),"output desc");
  auto program=f::take(Backend::compile(graph,context,owner,{.constants=bindings}),"source component compile");auto slot=f::invocation(program.executable);
  constexpr std::array<float,3> amplitudes{448.F,1.0078125F,-224.F};
  std::vector<double> input(static_cast<std::size_t>(tokens*source.k),0);
  for(std::int64_t t=0;t<tokens;++t)input[static_cast<std::size_t>(t*source.k+d.positions[static_cast<std::size_t>(t)])]=amplitudes[static_cast<std::size_t>(t)];
  auto activation_bytes=f::floating(type,input);
  if(encoded_activation) {
   // This is an explicit already-quantized input boundary, on both backends.
   // CUDA's dynamic Power2 implementation is qualified for BF16, not F32.
   // Its actual dynamic BF16 journey is independently exercised below.
   activation_bytes.assign(static_cast<std::size_t>(tokens*source.k),std::byte{});
   std::vector<float> sf(static_cast<std::size_t>(tokens*(source.k/128)),activation(0).scale);
   for(std::int64_t t=0;t<tokens;++t) {
    const auto av=amplitudes[static_cast<std::size_t>(t)];const auto q=activation(av);
    const auto code=static_cast<unsigned>(s::encode_scale(std::fabs(q.code)))|(std::signbit(q.code)?128U:0U);
    activation_bytes[static_cast<std::size_t>(t*source.k+d.positions[static_cast<std::size_t>(t)])]=std::byte(code);
    sf[static_cast<std::size_t>(t*(source.k/128)+d.positions[static_cast<std::size_t>(t)]/128)]=q.scale;
   }
   const auto scale_bytes=std::as_bytes(std::span(sf));activation_bytes.insert(activation_bytes.end(),scale_bytes.begin(),scale_bytes.end());
  }
  runtime.push_back(f::upload(owner,activation_bytes));f::check(slot.bind(a,ad,runtime.back()),"bind A");
  if(!fp8) {
   const std::vector<std::int32_t> ids(static_cast<std::size_t>(tokens*slots),0);runtime.push_back(f::upload(owner,std::as_bytes(std::span(ids))));
   f::check(slot.bind(id,f::dense(Type::kInt32,{tokens,slots}),runtime.back()),"bind duplicate expert0 IDs");
  }
  auto pool=f::take(c::LeasePool::create(owner.ref(),f::take(yd.required_bytes(),"output bytes"),{.max_blocks=1,.backing_alignment=256}),"output pool");
  f::check(slot.bind(y,yd,f::take(pool.allocate(f::take(yd.required_bytes(),"output bytes"),256),"output writer")),"bind output");
  f::submit<Backend>(slot,queue,false);const auto actual=f::read(f::output(slot,y));
  ASSERT_EQ(actual.size(),static_cast<std::size_t>(tokens*n*(fp8?1:slots)));
  std::size_t round_output_witnesses=0,activation_output_witnesses=0;
  for(std::int64_t t=0;t<tokens;++t)for(std::int64_t s0=0;s0<(fp8?1:slots);++s0)for(std::int64_t row=0;row<n;++row) {
   const auto pos=d.positions[static_cast<std::size_t>(t)];const float av=amplitudes[static_cast<std::size_t>(t)];const auto aq=activation(av);float expected=0,alternate=0;
   if(fp8) {
    const float w=s::e4m3(static_cast<std::uint8_t>(little(d.codes,static_cast<std::size_t>(row*source.k+pos),1)));const float sf=d.scales[static_cast<std::size_t>(pos/128)];
    expected=s::multiply(s::multiply(s::multiply(aq.code,w),aq.scale),sf);
    alternate=s::multiply(s::multiply(aq.code,aq.scale),s::rounded_bf16(s::multiply(w,sf)));
   }else if(source.kind==Kind::kInferact) {
    const auto sf=d.imported_e8[static_cast<std::size_t>(row*(source.k/32)+pos/32)];
    const float w=s::rounded_bf16(s::multiply(e2(d.code(row,pos)),s::rounded_bf16(e8(sf))));
    expected=s::multiply(av,w);alternate=s::multiply(s::multiply(aq.code,aq.scale),w);
   }else {
    const float w=e2(d.code(row,pos)),sf=d.scales[static_cast<std::size_t>(row*(source.k/32)+pos/32)];
    expected=s::multiply(s::multiply(s::multiply(aq.code,w),aq.scale),sf);
    alternate=s::multiply(av,s::multiply(w,sf));
   }
   if(type==Type::kBFloat16){expected=s::rounded_bf16(expected);alternate=s::rounded_bf16(alternate);}
   const auto index=static_cast<std::size_t>((t*(fp8?1:slots)+s0)*n+row);
   EXPECT_EQ(actual[index],expected)<<source.name<<" row="<<row<<" token="<<t;
   if(expected!=alternate){if(fp8)++round_output_witnesses;else++activation_output_witnesses;}
  }
  if(fp8&&source.scale==Scale::kBFloat16&&type==Type::kFloat32) {
   EXPECT_GT(d.product_round_witnesses,0U);EXPECT_GT(round_output_witnesses,0U);
  }
  if(!fp8)EXPECT_GT(activation_output_witnesses,0U);
  std::cout<<"SOURCE "<<source.name<<" type="<<static_cast<int>(type)<<" encoded_A_boundary="<<encoded_activation<<" original_codes="<<d.codes.size()<<" original_scales="<<d.raw_scales.size()<<" checked_outputs="<<actual.size()<<" weight_product_round_witnesses="<<d.product_round_witnesses<<" F32_vs_BF16_weight_output_witnesses="<<round_output_witnesses<<" wrong_activation_output_witnesses="<<activation_output_witnesses<<'\n';
 }
}
TEST(OriginalSourceFormatComponents,Cpu){for(auto c0:cases)verify<Cpu>(c0);}
TEST(OriginalSourceFormatComponents,Cuda){for(auto c0:cases)verify<Cuda>(c0);}
}
int main(int argc,char**argv) {
 if(argc<2){std::cerr<<"Original component root required\n";return 2;}
 source_root=argv[1];--argc;for(int i=1;i<argc;++i)argv[i]=argv[i+1];::testing::InitGoogleTest(&argc,argv);return RUN_ALL_TESTS();
}
