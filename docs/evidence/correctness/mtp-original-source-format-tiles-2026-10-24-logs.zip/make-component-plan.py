"""Offline exact source slices for actual codec/math checks, not model banks."""
from pathlib import Path
import hashlib,json,math
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def identity(p):
 raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def facts(i):return read(S/(f'cat{i:02d}'if i==6 else f'indexes/cat{i:02d}')/'mtp-schema-facts.json')
components=[]
def add(i,key,principal,scale,codec,reader,expectation):
 f=facts(i)
 if i==6:
  roles={v['name']:dict(v,file='mtp.safetensors')for x in f['logical_mapping']for v in x['physical']}
  proofs={f['source']['file']:dict(source=f['source'],header_bytes=f['header_bytes'],header_sha256=f['header_sha256'],header=S/'cat06/header.json',acquisition=S/'cat06/acquisition.json')}
 else:
  roles=f['roles'];proofs={x['source']['file']:dict(x,header=R/x['acquisition']['path'].replace('/acquisition.json','/header.json'),acquisition=R/x['acquisition']['path'])for x in f['headers']}
 w,sf=roles[principal],roles[scale]
 if w['file']!=sf['file']:raise ValueError('This bounded tile expects its source pair in one original file')
 proof=proofs[w['file']];source=proof['source'];header=read(proof['header'])
 ranges=[]
 for role,kind,rows in [(principal,'codes',3),(scale,'scales',1 if codec.startswith('fp8')else 3)]:
  physical=roles[role];dtype=physical['dtype'];shape=physical['shape']
  assert len(shape)==2 and 0<rows<=shape[0]
  bytewidth={'BF16':2,'F32':4,'F8_E4M3':1,'F8_E8M0':1,'U8':1,'I8':1}[dtype]
  nbytes=rows*shape[1]*bytewidth
  assert math.prod(shape)*bytewidth==physical['data_offsets'][1]-physical['data_offsets'][0]
  assert header[role]=={k:physical[k]for k in ['dtype','shape','data_offsets']}
  first=8+proof['header_bytes']+physical['data_offsets'][0]
  ranges.append(dict(name=role,kind=kind,original=dict(dtype=dtype,shape=shape,data_offsets=physical['data_offsets']),
   selection=dict(axis0_first=0,axis0_count=rows,axis1_full=True),selected_shape=[rows,shape[1]],absolute_inclusive=[first,first+nbytes-1],bytes=nbytes,
   output=f'.scratch/mtp-metadata-offline-20261024/components/{key}/{kind}.bin'))
 components.append(dict(id=key,catalog_index=i,repository=f['repository'],revision=f['revision'],
  uri=f'https://hf-mirror.net/{f["repository"]}/resolve/{f["revision"]}/{source["file"]}',source=source,
  header=identity(proof['header']),header_acquisition=identity(proof['acquisition']),codec=codec,reader=reader,
  full_reduction_K=(w['shape'][1]*2 if codec.startswith('fp4')else w['shape'][1]),selected_N=3,ranges=ranges,
  expected_check=expectation,not_claimed='Complete original role, expert bank, trained routing/state, full model, quality or speed. Expert0 is an explicitly selected public-op component, not a claimed model router decision.'))
add(6,'q27-fp8-bf16-sf','mtp.layers.0.self_attn.k_proj.weight','mtp.layers.0.self_attn.k_proj.weight_scale_inv','fp8-bf16-block128',
 'Original BF16 scale numerically widens exactly to F32 before canonical import. Weight-product/activation/output rounding still require the source reader contract; compare F32 product versus BF16-before-F32 as independent different oracles.',
 'Check all15360 original E4 code operands across40 original BF16 blocks, preserve BF16 SF bits, count non-BF16 product witnesses before choosing the actual source arithmetic. If source tile has none, report no witness rather than claim equivalence.')
add(15,'q24-fp8-bf16-sf','mtp.layers.0.mlp.experts.0.down_proj.weight','mtp.layers.0.mlp.experts.0.down_proj.weight_scale_inv','fp8-bf16-block128',
 'Same scale storage capability as cat6, but this source is a Qwen MoE expert with independent fixed identity/values. Do not substitute cat6 weights or infer activation policy from FP8 filename.',
 'Original3-row fullK2048 expert projection and BF16 macroblock SF; independent source-round oracles and explicit chosen activation profile. No entire expert or actual routed-token claim.')
add(19,'inferact-f32-sf','mtp.layers.0.mlp.experts.0.down_proj.weight','mtp.layers.0.mlp.experts.0.down_proj.weight_scale','fp4-f32-group32',
 'docs/evidence/research/inferact-micro32-contract-2026-10-21.json: fixed vLLM7b569ec reader cold F32SF->E8M0 GRS-RNE, then Mxfp4Linear(kBFloat16). Original publisher/OAS equivalence not established.',
 'Inspect192 real positive finite F32 scales; verify numeric E8RNE not raw bytes/ceil/directF32 multiply, original adjacent nibbles and BF16 operand rounding, actual CPU/CUDA projection of3 fullK2048 rows.')
for i in [25,26]:
 add(i,f'deepseek-{i}-fp4-e8-sf','mtp.0.ffn.experts.0.w1.weight','mtp.0.ffn.experts.0.w1.scale','fp4-i8-e8-group32',
  'Exact source inference/model.py114-143 and kernel.py442-535: I8 holds adjacent packed FP4 bytes; A->dynamicE4 group128, F32 group32 dot*actSF*weightSF, finalBF16. Existing GroupedFloat4Linear; not Mxfp4Linear W4A4/W4A16.',
  'Preserve signed carrier raw bits; losslessly widen original E8M0 SF to canonicalF32, no BF16 W expansion. Explicit IDs/duplicate selected slots plus source-specific FP8-activation oracle. SF0/255 and IEEE results remain observable.')
 add(i,f'deepseek-{i}-fp8-e8-sf','mtp.0.attn.wkv.weight','mtp.0.attn.wkv.scale','fp8-e8-block128',
  'Fixed same-revision linear/act_quant/fp8_gemm; source UE8M0 macroblock128 scales widen losslessly, explicit power2 activation scale profile from resolved reader. Existing import_float8_block128_weight/Float8BlockLinear.',
  'Three fullK original E4 rows, entire needed macroblock scale row, original E8 bytes and F32 decoded SF. Test no pre-BF16 product rounding, two activation rows, real CPU/CUDA output and independent reference.')
add(27,'dspark-fp8-f32-sf','mtp.0.attn.wkv.weight','mtp.0.attn.wkv.scale','fp8-f32-block128',
 'Exact fixed DSpark reader scale_dtype/scale_fmt are explicit; original F32SF bits preserved, never re-encode to E8M0. Existing raw-F32 canonical FP8 import and activation profile.',
 'Three original fullK4096 rows and32 F32 macroblock SF; inspect non-power2 values, compare unchangedSF to erroneous E8 rounding without claiming non-power2 exists before reading.')
p=dict(kind='necessary-original-source-format-component-tiles',required_owner_marker='PAUSED.q35-gguf-payload-held',
 HTTP_execution='Only root via existing budget.py run; script never changes pause; HTTPS hf-mirror.net only including redirects; no fallback; no automatic retries.',
 components=components,total_new_tensor_payload_bytes=sum(x['bytes']for c in components for x in c['ranges']),maximum_HTTP_requests=sum(len(c['ranges'])for c in components),
 tensor_body_limit_per_request=4*1024*1024,full_models_or_expert_libraries=0,
 helpers=[identity(S/'fetch-small-headers.py'),identity(R/'.scratch/mtp-download-budget-20261023/budget.py')],
 evidence_limits='Role-level original source identities and exact206/strongETag protect slices; each local slice SHA will be recorded after acquisition, not a whole-file LFS hash claim.')
(S/'source-component-plan.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(components=len(components),requests=p['maximum_HTTP_requests'],bytes=p['total_new_tensor_payload_bytes'],items=[(x['id'],sum(r['bytes']for r in x['ranges']))for x in components])))
