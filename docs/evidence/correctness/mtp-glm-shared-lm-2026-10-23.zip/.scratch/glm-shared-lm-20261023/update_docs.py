"""Update current facts only after this batch's six final checks pass."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parents[2]
S = Path(__file__).resolve().parent
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
runs = [read(S / f'checks{i}/summary.json') for i in (2,3,4)]
assert sum(r['tests'] for r in runs) == 6
assert all(r['process']['exit'] == 0 and not r['process']['timed_out'] and
           not any(r[k] for k in ('failures','errors','disabled','skips')) for r in runs)
cases = [case for run in runs for case in run['cases']]
assert sum(int(case['properties']['actual_submissions']) for case in cases) == 160

p = R / 'docs/developer/current-work.md'
t = p.read_text(encoding='utf-8-sig')
def change(old,new):
    global t
    assert t.count(old) == 1, old
    t = t.replace(old,new)

change('GLM官方14原角色已进入完整NextN输入／query／indexer及接受后追赶，CPU／CUDA通过；默认ue8m0缓存和原生成路径保留。',
       'GLM官方17原角色已进入完整NextN输入／query／indexer及共享全词表embedding／head／norm，真实预测ID反馈和接受后追赶CPU／CUDA通过；默认ue8m0缓存和原生成路径保留。')
change('剩余原角色、GLM共享LM、真实target taps及已确认量化供给继续按精确制品身份接入',
       '剩余原角色、真实target taps、Pro实际几何及已确认量化供给继续按精确制品身份接入')
change('Q27／Q24单次完整量化head、GLM Flash原14参数及DSpark全部81份sidecar原角色已有列明检查。当前下一批是GLM Flash共享LM：原embedding／head／shared-head norm三角色及真实全词表ID反馈；随后继续其余原角色、真实target taps、Pro实际几何与已确认适用量化组合。',
       'Q27／Q24单次完整量化head、GLM Flash原17参数与全词表预测反馈、DSpark全部81份sidecar原角色已有列明检查。下一步继续GLM等其余原角色、真实target taps、Pro实际几何与已确认适用量化组合。')
start=t.index('**最近已验证进展**：'); end=t.index('已取得的实际边界：',start)
t=t[:start]+'''**最近已验证进展**：[GLM共享LM接线](../evidence/correctness/mtp-glm-shared-lm-2026-10-23.json)新增原BF16 embedding／独立head／shared-head norm三角色，完整V154880投影的真实Top1 ID进入pending及下轮embedding。17原角色共2,625,935,360B；三份新增bank只各准备一次，共2,537,562,112B，无整份F32词表权重副本。CPU／CUDA新旅程各28次Graph，旧14原角色及生成参数两端各26次，共6项最终检查、160次Graph，无失败／跳过。首轮每端154880个分数用独立原字节F64参考核对，每端20次全词表greedy、pending与embedding反馈通过；接受0／1／2、显式target bonus、epoch seed、skip及journal／direct catchup保留。

首次CUDA检查命中测试原128MiB状态backing预算；现按14个实际输出池、独立初态及元数据上界推导，版本等限额及产品计费未改，原失败和源码保留。本轮仍以实际生成F32 residual／FFN为共享norm输入边界，target hidden、其余MLA／MoE未换成完整原模型；没有新TPS或物理内存／显存峰值数据，页末AV对比保持原样。

前批[DSpark原专家](../evidence/correctness/mtp-dspark-original-experts-2026-10-23.json)已完成全部81份sidecar＋2份正式BF16词表角色，共83份；CPU／CUDA实际256域路由、有界MXFP4专家供给、完整draft与接受状态检查保留。两CUDA槽的设备和pinned声明容量各802,162,688B，CPU两代池同容量；非物理峰值。target captures／verifier、Pro实际几何与其它已确认量化仍在剩项中。

'''+t[end:]
change('target hidden／embedding、其余MLA／MoE／head仍生成；原45层模型、共享LM、Pro几何和自然接受率未完成，逻辑codec不代签vendor页ABI。',
       '[共享LM三原角色](../evidence/correctness/mtp-glm-shared-lm-2026-10-23.json)已补原全V embedding／head／norm与真实ID反馈，norm输出显式BF16并精确扩宽为后继hidden。target hidden、其余MLA／MoE仍生成；原45层模型、Pro几何和自然接受率未完成，逻辑codec不代签vendor页ABI。')
change('原GLM14角色、DSpark83角色已接，下一步GLM共享LM、其余角色／真实target taps／Pro几何与已确认量化组合，最后完整性能对照',
       '原GLM17角色与共享LM反馈、DSpark83角色已接，下一步其余角色／真实target taps／Pro几何与已确认量化组合，最后完整性能对照')
tail=t[t.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest()==read(S/'baseline/before.json')['protected_performance_tail_sha256']
p.write_text(t,encoding='utf-8',newline='\n')

p=R/'docs/implementation/model-operators.md'; t=p.read_text(encoding='utf-8-sig')
change('其余MLA／MoE／head、embedding／target边界仍生成，原45层、共享LM与Pro几何未完成',
       '[共享LM三原角色](../evidence/correctness/mtp-glm-shared-lm-2026-10-23.json)现补全V154880 BF16 embedding／独立head／sharednorm，实际Top1进入pending并反馈下轮；共17原角色。其余MLA／MoE与target边界仍生成，原45层及Pro几何未完成')
needle='前述34资源与DSpark组合保留[编码状态证据]'
assert t.count(needle)==1
t=t.replace(needle,'共享LM新增原角色2,537,562,112B，各bank向同owner只准备一次，配合原14角色共2,625,935,360B；原norm gamma精确扩宽，实际生成F32 combined→RMS eps1e-5→BF16store→单次全V head，后继hidden保存其精确扩宽。CPU／CUDA各28次完整状态Graph与真实ID反馈通过；本批不声称其余原BF16 decoder已复现。'+needle)
p.write_text(t,encoding='utf-8',newline='\n')
print('UPDATED current-work and model-operators; protected AV tail unchanged')
