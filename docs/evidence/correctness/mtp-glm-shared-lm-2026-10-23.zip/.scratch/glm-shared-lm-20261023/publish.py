"""Publish finite GLM original shared-LM/state checks, excluding weight bodies."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def identity(p):
    p = Path(p)
    with p.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),
                bytes=p.stat().st_size, sha256=digest)

def verify(row):
    actual = identity(R / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--new-runs', type=int, nargs='+', required=True)
p.add_argument('--regression-runs', type=int, nargs='+', required=True)
p.add_argument('--link-attempt', type=int, required=True)
p.add_argument('--freeze', default='source')
args = p.parse_args()
indices = [*args.new_runs, *args.regression_runs]
runs = [read(S / f'checks{i}/summary.json') for i in indices]
image = read(S / f'tests-link{args.link_attempt}/ready.json')['image']
verify(image)
for run in runs:
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert not any(run[k] for k in ('failures', 'errors', 'disabled', 'skips'))
    assert run['image'] == image
cases = [case for run in runs for case in run['cases']]
assert len(cases) == len({(c['attributes']['classname'],c['attributes']['name']) for c in cases})
new_cases = [case for run in runs[:len(args.new_runs)] for case in run['cases']]
assert len(new_cases) == 2
for case in new_cases:
    assert case['properties']['original_roles'] == '17'
    assert case['properties']['shared_lm_full_f64_scores_checked'] == '154880'
    assert case['properties']['shared_lm_bank_capacity_bytes'] == '2537562112'
    if case['attributes']['name'].startswith('Cuda'):
        assert case['properties']['shared_lm_head_provider'] == 'cublasLt'
acquisition = read(S / 'original-lm/acquisition.json')
assert acquisition['complete'] and acquisition['original_roles'] == 3
assert acquisition['role_payload_bytes'] == acquisition['successful_request_body_bytes'] == 2537562112
for role in acquisition['roles']:
    assert role['complete']
    verify(role['payload'])
freeze_path = S / args.freeze / 'freeze.json'
freeze = read(freeze_path)
for row in [*freeze['source'], *freeze['dependencies']]:
    verify(row)
link_path = S / f'tests-link{args.link_attempt}/link-plan.json'
link = read(link_path)
for row in link['inputs']:
    verify(row)
for row in link['compiled_records']:
    verify(row)
    if Path(row['path']).is_relative_to(S):
        compiled = read(row['path'])
        for item in (compiled['source'], compiled['object'], *compiled['dependencies']):
            verify(item)
text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == read(S / 'baseline/before.json')['protected_performance_tail_sha256']
protected = read(S / 'baseline/before.json')['protected_qwen_image']
verify(protected.get('image', protected))
sources = [R / rel for rel in ('tests/compute_models/glm_shared_vocabulary.h',
    'tests/compute_models/glm_shared_vocabulary_reference.h',
    'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'docs/developer/current-work.md', 'docs/implementation/model-operators.md')]
metadata = [R / rel for rel in (
    '.scratch/dspark-original-experts-20261023/review/glm-shared-lm-next.json',
    '.scratch/dspark-natural-journey-20261022/original-glm-input/header.json',
    '.scratch/dspark-natural-journey-20261022/original-glm-input/acquisition.json',
    '.scratch/glm-mtp-carry-20261022/original-glm-q-a/header.json',
    '.scratch/glm-mtp-carry-20261022/original-glm-q-a/acquisition.json',
    '.scratch/glm-encoded-state-20261023/review/fixed-source/models/deepseek_nextn.py')]
assert all(path.is_file() for path in metadata)
files = set(sources + metadata)
files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in
             ('.h','.cc','.py','.json','.txt','.log','.xml','.ps1','.diff'))
files.discard(S / 'publication.json')
archive = D / 'mtp-glm-shared-lm-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
    for path in sorted(files):
        zipped.write(path, path.relative_to(R).as_posix())
record = dict(date='2026-10-23', stage='BN', goal_complete=False,
    conclusion='Original GLM-5.3-Flash embedding, independent LM head and NextN shared-head norm feed the existing original14-role NextN/state consumer; actual full-vocabulary predictions feed subsequent draft embeddings.',
    artifact=dict(repository=acquisition['repository'],revision=acquisition['revision'],
        original_roles=17, additional_original_roles=3, additional_original_payload_bytes=2537562112,
        acquisition=acquisition, original_weight_bodies_archived=False),
    implementation=dict(
        shared_storage='Three readonly original BF16 ready banks are bound once to the same nominated StorageOwner. Recipes retain shared owners/leases; no per-Recipe bank replication and no complete F32 vocabulary copy.',
        math='Original BF16 embedding Gather enters the original NextN prefix. The actual generated F32 decoder residual+FFN boundary feeds original norm gamma/eps1e-5, explicit BF16 norm output store, fullV BF16 LM projection/F32 scores and stable TopK1.',
        state='Actual greedy IDs publish as pending and enter following embedding Gather. Explicit target bonus/correction remains consumer policy. Existing full state, accepted prefixes, seed provenance, journal/direct catchup and immutable old results stay shared.',
        scope='Original shared roles are checked at the declared F32 generated-decoder boundary; this does not certify the remaining original BF16/FP8 decoder, target/verifier or natural acceptance.'),
    validation=dict(tests=len(cases),failures=0,errors=0,skips=0,
        model_graph_submissions=sum(int(case['properties']['actual_submissions']) for case in cases),
        new_model_graph_submissions=sum(int(case['properties']['actual_submissions']) for case in new_cases),
        full_f64_head_scores_checked=sum(int(case['properties']['shared_lm_full_f64_scores_checked']) for case in new_cases),
        actual_prediction_to_pending_checks=sum(int(case['properties']['shared_lm_prediction_to_pending_checks']) for case in new_cases),
        new_cases=new_cases, related_cases=[case for run in runs[len(args.new_runs):] for case in run['cases']],
        results=[identity(S / f'checks{i}/summary.json') for i in indices],
        source_freeze=identity(freeze_path), linked_inputs=identity(link_path),
        compiled_host_translation_units=1, host_compile_attempts=len(list(S.glob('compile*/*/identity.json'))),
        prior_attempts=[read(S / 'checks1/summary.json')],
        prior_attempt_scope='The first CUDA image passed original prefix/indexer, full vocabulary scores and actual ID feedback, then hit the test fixture default128MiB StateStore backing budget. The final fixture derives its own budget from real retained output-pool backing; product admission/accounting and numerical gates remain unchanged.',
        SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
    limitations=['Finite Windows CPU/CUDA model journey, not all systems/shapes/codecs.',
        'Target hidden/taps/verifier and remaining MLA/MoE are still explicit generated boundaries.',
        'No original full45-layer target, Pro6144 geometry, full quantization coverage, natural acceptance or complete quality claim.',
        'Declared shared-bank capacities are not measured physical CPU/GPU peak memory.',
        'No new throughput/loading/memory benchmark; latest AV comparison remains unchanged.',
        'MTP and the broader goal remain incomplete.'],
    remaining='Remaining original roles, real target taps, actual Pro geometry and confirmed applicable quantization combinations; final related regressions and complete ordinary/MTP performance comparison before images.',
    final_image=image, sources=[identity(path) for path in sources],
    source_metadata=[identity(path) for path in metadata],
    performance_tail_sha256=tail_hash, archive=identity(archive),archive_items=len(files))
destination = D / 'mtp-glm-shared-lm-2026-10-23.json'
assert not destination.exists()
destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
publication=dict(evidence=identity(destination),archive=identity(archive))
(S / 'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(**publication,tests=len(cases),graphs=record['validation']['model_graph_submissions'])))
