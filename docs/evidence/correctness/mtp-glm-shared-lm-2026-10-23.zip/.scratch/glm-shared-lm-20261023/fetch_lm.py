"""Acquire only three pinned GLM Flash BF16 shared-LM roles; bounded resumable IO."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import time
import urllib.error
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
CHUNK, IO = 128 * 1024 * 1024, 1024 * 1024

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

plan_path = R / '.scratch/dspark-original-experts-20261023/review/glm-shared-lm-next.json'
plan = read(plan_path)['flash']
receipts = [read(R / '.scratch/dspark-natural-journey-20261022/original-glm-input/acquisition.json'),
            read(R / '.scratch/glm-mtp-carry-20261022/original-glm-q-a/acquisition.json')]
headers = []
for evidence in plan['range_evidence']:
    raw = (R / evidence['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == evidence['sha256']
    assert len(raw) == evidence['header_bytes']
    headers.append(json.loads(raw))

out = S / 'original-lm'
out.mkdir(exist_ok=True)
receipt = out / 'acquisition.json'
roles = []
for i, role in enumerate(plan['roles']):
    shard_index = 0 if i < 2 else 1
    old, evidence = receipts[shard_index], plan['range_evidence'][shard_index]
    assert old['repository'] == plan['repository'] and old['revision'] == plan['revision']
    exact = headers[shard_index][role['name']]
    assert exact['dtype'] == role['dtype'] and exact['shape'] == role['shape']
    assert exact['data_offsets'] == role['data_relative_half_open']
    assert role['bytes'] == exact['data_offsets'][1] - exact['data_offsets'][0]
    first = evidence['data_base'] + exact['data_offsets'][0]
    assert role['absolute_inclusive'] == [first, first + role['bytes'] - 1]
    etag = old['requests'][0]['etag']
    assert all(row['etag'] == etag for row in old['requests'] if row.get('complete'))
    filename = ('head.bf16', 'embedding.bf16', 'norm.bf16')[i]
    roles.append(dict(**role, url=old['url'], etag=etag,
        whole_file_bytes=evidence['shard_file_bytes'], complete=False, chunks=[],
        payload=dict(path=(out / filename).relative_to(R).as_posix(), bytes=role['bytes'], sha256=None)))
identity = dict(repository=plan['repository'], revision=plan['revision'],
                source_plan=plan_path.relative_to(R).as_posix(), expected_role_payload_bytes=2537562112)
if receipt.exists():
    record = read(receipt)
    assert all(record[k] == v for k, v in identity.items())
    for prior, wanted in zip(record['roles'], roles, strict=True):
        assert all(prior[k] == wanted[k] for k in wanted if k not in ('complete', 'chunks', 'payload'))
        assert prior['payload']['path'] == wanted['payload']['path']
else:
    assert not any((R / row['payload']['path']).exists() for row in roles)
    record = dict(**identity, complete=False, original_roles=3, whole_shard_downloaded=False,
                  chunk_bytes=CHUNK, stream_buffer_bytes=IO, requests=[], roles=roles)

def save():
    temporary = receipt.with_suffix('.json.next')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, receipt)

save()
for row in record['roles']:
    path = R / row['payload']['path']
    offset = 0
    if path.exists():
        with path.open('rb') as stream:
            for part in row['chunks']:
                assert part['offset'] == offset and part['bytes'] <= CHUNK
                digest, remaining = hashlib.sha256(), part['bytes']
                while remaining:
                    data = stream.read(min(IO, remaining))
                    assert data, 'Truncated authenticated prefix'
                    digest.update(data)
                    remaining -= len(data)
                assert digest.hexdigest() == part['sha256']
                offset += part['bytes']
        assert offset <= path.stat().st_size <= min(row['bytes'], offset + CHUNK)
    else:
        assert not row['chunks'] and not row['complete']
    if row['complete']:
        assert offset == path.stat().st_size == row['bytes']
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['payload']['sha256']
        print('REUSED', path.name, row['bytes'], flush=True)
        continue
    while offset < row['bytes']:
        size = min(CHUNK, row['bytes'] - offset)
        first = row['absolute_inclusive'][0] + offset
        last = first + size - 1
        attempt = dict(role=row['name'], first=first, last=last, requested_bytes=size,
                       complete=False, started_utc=now())
        record['requests'].append(attempt)
        save()
        print('REQUEST', path.name, offset, size, flush=True)
        request = urllib.request.Request(row['url'], headers={
            'Range': f'bytes={first}-{last}', 'If-Range': row['etag'],
            'Accept-Encoding': 'identity', 'User-Agent': 'hyle-original-role-consumer/1'})
        try:
            for retry in range(5):
                try:
                    response = urllib.request.urlopen(request, timeout=60)
                    break
                except (urllib.error.URLError, TimeoutError, OSError) as error:
                    attempt.setdefault('transport_errors', []).append(dict(
                        error_type=type(error).__name__, error=str(error), utc=now()))
                    save()
                    if retry == 4:
                        raise
                    time.sleep(2)
            with response:
                expected_range = f'bytes {first}-{last}/{row["whole_file_bytes"]}'
                assert response.status == 206
                assert response.headers.get('Content-Range') == expected_range
                assert response.headers.get('ETag') == row['etag']
                assert response.headers.get('Content-Length') in (None, str(size))
                assert response.headers.get('Content-Encoding') in (None, 'identity')
                digest = hashlib.sha256()
                with path.open('r+b' if path.exists() else 'x+b') as stream:
                    stream.seek(offset)
                    remaining = size
                    while remaining:
                        data = response.read(min(IO, remaining))
                        assert data, 'Early EOF'
                        digest.update(data)
                        stream.write(data)
                        remaining -= len(data)
                    assert not response.read(1), 'Overlong range'
                    stream.flush()
                    os.fsync(stream.fileno())
            assert path.stat().st_size == offset + size
            part = dict(offset=offset, bytes=size, sha256=digest.hexdigest(),
                        absolute_range_inclusive=[first, last])
            row['chunks'].append(part)
            attempt.update(complete=True, http_status=206, bytes=size,
                           content_range=expected_range, etag=row['etag'],
                           sha256=part['sha256'], finished_utc=now())
            offset += size
            save()
            print('VERIFIED', path.name, offset, '/', row['bytes'], flush=True)
        except Exception as error:
            attempt.update(error_type=type(error).__name__, error=str(error), finished_utc=now())
            save()
            raise
    with path.open('rb') as stream:
        row['payload']['sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
    row['complete'] = True
    save()
    print('ACQUIRED', path.name, row['payload']['sha256'], flush=True)
record.update(complete=True, role_payload_bytes=sum(r['payload']['bytes'] for r in record['roles']),
    successful_request_body_bytes=sum(r['bytes'] for r in record['requests'] if r['complete']), finished_utc=now())
assert record['role_payload_bytes'] == record['successful_request_body_bytes'] == 2537562112
save()
print('COMPLETE', record['role_payload_bytes'], flush=True)
