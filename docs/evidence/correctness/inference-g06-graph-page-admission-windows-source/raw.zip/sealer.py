from pathlib import Path
import datetime,hashlib,json,re,subprocess,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';folder=base/'final-windows-source-2';out=root/'evidence/correctness/inference-g06-graph-page-admission-windows-source'
assert not out.exists();r=json.loads((folder/'result.json').read_text());assert r['state']=='TERMINAL_PASS'
product='669121418669b31f6849c74f64362aaf8d6eb919'
assert not subprocess.check_output(['git','diff','--name-only',product,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
assert all(s['exit_code']==0 for s in r['stages'])
tests={};names=set()
for row in r['stages']:
 if row['stage'].startswith(('hyle_','g04_')):
  text=Path(row['log']).read_text();passed=re.search(r'\[  PASSED  \] (\d+) tests\.',text)
  assert passed and '[  FAILED  ]' not in text and '[  SKIPPED ]' not in text
  tests[row['stage']]=int(passed[1]);names.add(Path(row['command'][0]).name)
assert sum(tests.values())==428
artifacts=[]
for p in sorted((Path(r['build'])/'bin').iterdir()):
 if p.is_file() and (p.name in names or p.suffix.lower()=='.dll'):
  artifacts.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in artifacts)
out.mkdir(parents=True)
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(folder.iterdir()):
  if p.is_file():z.write(p,p.name)
 z.write(Path(__file__),'sealer.py')
receipt={'state':'PASS_FINITE_WINDOWS_CPU_CORE_GRAPH_SOURCE_ONLY','product_candidate':product,'source_snapshot':r['candidate'],
 'record':'docs/implementation/tasks/compute/inference-g06-metadata-decode.md','identity':r['identity'],'tests':tests,
 'stages':r['stages'],'outer_elapsed_seconds':r['outer_elapsed_seconds'],'artifact_rechecks':artifacts,
 'qualification':['Actual Windows MSVC original Graph51 (including nine LeaseSubmission tests), Graph executable285, graph_batch6, compute_batch60 and encoded common26 all PASS428, no failures or skips.',
 'New256-block64-episode exact-page census checks shared backing, overlapping ordinary/page groups, reorder/shrink/rebind and zero warm metadata allocation. Original partial-admission rollback, closed sources, unknown observation, both native prefixes and exhaustive cold allocation failures pass.',
 'Both Graph permission owners share one cold-reserved graph-private set. Original public bindings/page range order, F1 checks and native prefix retirement remain; Graph source only changed from0a29. Same cached CPU tree, max4 workers, no CUDA/P1.'],
 'limits':['Source only, not independent headers/relocated static/shared/sanitizers/P1/full G06 acceptance','Native private/driver costs UNKNOWN and G04/G05 unresolved performance remain'],
 'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'state':receipt['state'],'passed':sum(tests.values()),'artifact_count':len(artifacts)},ensure_ascii=False))
