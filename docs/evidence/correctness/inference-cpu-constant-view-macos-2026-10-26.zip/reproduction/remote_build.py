import concurrent.futures, hashlib, json, os, pathlib, subprocess, sys, time

W=pathlib.Path(__file__).resolve().parent
plan=json.loads((W/'plan.json').read_text())
print('BUILD_PID',os.getpid(),'PRODUCT_TUS',5,'CONSUMER_TUS',1,flush=True)
(W/'objects').mkdir(exist_ok=True)
(W/'records').mkdir(exist_ok=True)

def run(tag,command,timeout=120):
    D=W/'records'/tag.replace('/','--');D.mkdir(exist_ok=True)
    (D/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    start=time.monotonic()
    with (D/'stdout.log').open('wb') as out,(D/'stderr.log').open('wb') as err:
        p=subprocess.Popen(command,stdout=out,stderr=err)
        print('START',tag,'PID',p.pid,flush=True)
        timed_out=False
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True;p.kill();code=p.wait()
    result={'tag':tag,'pid':p.pid,'exit_code':code,'timed_out':timed_out,'seconds':time.monotonic()-start}
    (D/'process.json').write_text(json.dumps(result,indent=2)+'\n')
    print('END',json.dumps(result),flush=True)
    return result

results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    pending=[pool.submit(run,j['tag'],j['command']) for j in plan['jobs']]
    for item in pending:results.append(item.result())
if any(r['exit_code'] for r in results):
    (W/'summary.json').write_text(json.dumps({'status':'COMPILE_FAILED','compile':results},indent=2)+'\n');sys.exit(1)
link=run('link',plan['link'])
summary={'status':'READY' if link['exit_code']==0 else 'LINK_FAILED','compile':results,'link':link}
if link['exit_code']==0:
    q=W/'consumer';b=q.read_bytes();summary['image']={'path':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
deps=[]
for j in plan['jobs']:
    q=pathlib.Path(j['output']+'.d')
    if not q.is_file():continue
    rows=[]
    for s in q.read_text().replace('\\\n',' ').split():
        p=pathlib.Path(s)
        if p.is_file():
            b=p.read_bytes();rows.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    deps.append({'tag':j['tag'],'dependencies':rows})
(W/'actual-dependencies.json').write_text(json.dumps(deps,indent=2)+'\n')
(W/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
sys.exit(link['exit_code'])
