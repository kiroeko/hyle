import hashlib, json, pathlib, zipfile, zlib

R=pathlib.Path.cwd()
W=pathlib.Path(__file__).resolve().parent
OUT=R/'docs/evidence/correctness'
BASE='inference-cpu-constant-view-macos-2026-10-26'

def pin(p):
    b=p.read_bytes()
    return {'path':p.relative_to(R).as_posix(),'bytes':len(b),
            'sha256':hashlib.sha256(b).hexdigest()}

build=json.loads((W/'actual/summary.json').read_text())
run=json.loads((W/'actual/records/run1/process.json').read_text())
sync=json.loads((W/'sync-receipt.json').read_text())
runtime=json.loads((W/'actual/runtime.json').read_text())
sources=json.loads((W/'source-pins.json').read_text())
deps=json.loads((W/'actual/actual-self-dependencies.json').read_text())
for row in sources:
    if row['synchronized']:
        p=W/'source'/row['relative']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
assert all(x['exit_code']==0 for x in build['compile'])
assert build['link']['exit_code']==0 and run['exit_code']==0
dependency_diff=[]
for row in deps:
    p=W/'source/consumer.cc' if row['relative']=='consumer.cc' else R/row['relative']
    if p.exists() and hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()!=row['sha256_lf']:
        dependency_diff.append(row['relative'])
assert not dependency_diff

artifacts=json.loads((W/'remote-artifacts.json').read_text())
summary={
 'status':'PASS_FINITE_MACOS_CPU_NATIVE_GRAPH_VALIDATION',
 'date':'2026-10-26',
 'machine':{'host':'MacBook Air Mac16,12','cpu':'Apple M4','logical_cpus':10,
            'memory_bytes':17179869184,'os':'macOS 27.0.1 (26A434)',
            'toolchain':runtime['clang'].splitlines()[0],'architecture':'arm64',
            'workspace':'/Users/kiro/hyle-scratch/compute-unified',
            'checkout':'Retained source snapshots; no Git HEAD/clean state claimed'},
 'scope':{
  'current_products':['src/compute_ggml_runtime/cpu_execution.cc',
    'src/compute_provider_ggml/ggml_cpu_provider.cc','src/graph_route_cpu/ggml_region.cc',
    'src/compute/resource_budget.cc','src/compute/resource_leases.cc'],
  'consumer':'One standalone own-main CPU consumer; no GoogleTest/shim/new test framework',
  'native_threads':4,'executor':'existing default caller executor',
  'compile':'5 products + 1 thin TU, clang++ C++23 O3 arm64, original native macros, -Werror',
  'synchronization':{'files':sync['synchronized_source_files'],
    'source_bytes':sync['source_bytes'],'archive_bytes':sync['archive_bytes'],
    'archive_sha256':sync['archive_sha256']},
  'frozen_dependencies':'Retained pure-CPU Graph executable/archive, base SDK, native ggml ffa4e8b80930029a35991f94e7c8a93cd67730ab with recorded Hyle patches, and ATen/Accelerate. Not an entirely current macOS build.',
  'SDK_native_model_builds':0,'HTTP_downloads':0,'performance_samples':0},
 'results':{
  'compile':build['compile'],'link':build['link'],'run':run,'image':build['image'],
  'submissions':7,
  'constant_View_bridge':{'regions':1,'steps':2,'slots':2,'submissions':2,
    'packed_constant_count':0,'packed_constant_bytes':0,'members':['Neg','MatMul'],
    'Graph_metadata_View_retained':True},
  'published_View_fence':{'regions':0,'steps':3,'slots':2,'submissions':2,
    'published_alias_description_resource_handle_offset_unchanged':True},
  'control_View_fence':{'regions':0,'steps':3,'slots':2,'submissions':2},
  'per_node_BF16_store':{'regions':1,'nodes':2,'submissions':1,
    'operations':'BF16(BF16(a+b)-a)','actual_bits':['0000','3c00'],
    'omitted_intermediate_store_would_give':['3b80','3b80']},
  'old_results_and_constant_weights_unchanged':True,
  'actual_self_dependency_files':len(deps),'current_LF_dependency_mismatches':dependency_diff,
  'first_failures':'None: first strict build, link and sole run all passed'},
 'limitations':[
  'Two Invocation slots were submitted sequentially, not concurrently; no new reentrancy/Context-close/cancellation test.',
  'Current resource_budget/resource_leases were compiled and linked; this consumer does not newly certify every quota/rollback/deallocation scenario.',
  'Frozen Graph has older capture-seed invalidation and rejected-search diagnostics; no entirely current Graph/native/SDK or full-platform certification.',
  'No model, original model payload, model quality, throughput, Apple GPU/Metal, CUDA or full macOS suite was run.',
  'No SDK/native rebuild, download, complete source-tree copy, or cleanup was performed. Remote artifacts remain for root-managed cleanup.'],
 'provenance':{'actual_source_pins':pin(W/'source-pins.json'),
    'actual_plan':pin(W/'actual/plan.json'),'actual_dependencies':pin(W/'actual/actual-dependencies.json'),
    'runtime':pin(W/'actual/runtime.json'),'consumer':pin(W/'source/consumer.cc'),
    'region_product_patch':pin(W.parent/'product.patch'),
    'region_product_pins':pin(W.parent/'product-pins.json')},
 'remote_artifacts':{'manifest':pin(W/'remote-artifacts.json'),
    'files':len(artifacts),'bytes':sum(x['bytes'] for x in artifacts),
    'binary_files':len([x for x in artifacts if x['kind']=='binary']),
    'binary_bytes':sum(x['bytes'] for x in artifacts if x['kind']=='binary'),
    'deleted':False}}
(W/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n')

members={}
for p in sorted((W/'source').rglob('*')):
    if p.is_file():members['source/'+p.relative_to(W/'source').as_posix()]=p
for p in sorted((W/'actual').rglob('*')):
    if p.is_file():members['actual/'+p.relative_to(W/'actual').as_posix()]=p
for name in ['prepare.py','remote_build.py','run-remote.py','collect-remote.py',
             'closure-list.json','cache-plan.json','source-pins.json','plan.json',
             'sync-receipt.json','collect-receipt.json','remote-artifacts.json',
             'final-summary.json','publish.py']:
    members['reproduction/'+name]=W/name
for name in ['product.patch','product-pins.json','independent-review-sampling.json']:
    p=W.parent/name
    if p.exists():members['region-candidate/'+name]=p
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/(BASE+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(members.items()):
        assert p.suffix.lower() not in ['.o','.obj','.exe','.dll','.dylib','.a','.lib']
        z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    crc_manifest=[{'name':x.filename,'bytes':x.file_size,'crc32':f'{x.CRC:08x}'} for x in z.infolist()]
raw=archive.read_bytes()
summary['archive']={'file':archive.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
    'crc32':f'{zlib.crc32(raw):08x}','members':len(crc_manifest),'all_member_CRCs_verified':True,
    'contents':'Only changed source/headers, consumer, actual commands/dependencies/pins/runtime/raw, frozen cache metadata, and reproduction scripts. No binaries/SDK/model.'}
report=OUT/(BASE+'.json');report.write_text(json.dumps(summary,indent=2)+'\n')
(W/'archive-members.json').write_text(json.dumps(crc_manifest,indent=2)+'\n')
print(json.dumps({'report':pin(report),'archive':summary['archive']},indent=2))
