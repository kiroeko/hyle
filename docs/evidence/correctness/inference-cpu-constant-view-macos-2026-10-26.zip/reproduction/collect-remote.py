
import pathlib,json,hashlib,subprocess,io,tarfile,base64,platform
W=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/cpu-region-views-20261026/attempt1')
P=W.parents[1]/'qwen-pure-cpu-functional-20261024/attempt1'
def ident(q):
 b=q.read_bytes();return {'path':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
runtime={'machine':platform.machine(),'os':platform.mac_ver()[0],'image':ident(W/'consumer'),'dynamic_libraries':subprocess.run(['otool','-L',str(W/'consumer')],capture_output=True,text=True).stdout,'clang':subprocess.run(['/usr/bin/clang++','--version'],capture_output=True,text=True).stdout,'frozen_plan':ident(P/'plan.json'),'frozen_ready':ident(P/'ready.json'),'frozen_native_dependencies':ident(P/'native-dependencies.json'),'frozen_native_overlays':ident(P/'native-overlays.json')}
(W/'runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
deps=json.loads((W/'actual-dependencies.json').read_text());selfrows={}
for unit in deps:
 for row in unit['dependencies']:
  s=row['path']
  if '/source/' in s:
   rel=s.rsplit('/source/',1)[1]
   if rel.startswith(('include/','src/')) or rel=='consumer.cc':
    b=pathlib.Path(s).read_bytes();selfrows[s]={'relative':rel,'path':s,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sha256_lf':hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest()}
(W/'actual-self-dependencies.json').write_text(json.dumps(list(selfrows.values()),indent=2)+'\n')
files=[p for p in (W/'records').rglob('*') if p.is_file()]
files += [W/p for p in ['summary.json','actual-dependencies.json','actual-self-dependencies.json','runtime.json','source-pins.json','plan.json']]
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
 for p in files:tar.add(p,arcname=p.relative_to(W).as_posix())
print(base64.b64encode(buf.getvalue()).decode())
