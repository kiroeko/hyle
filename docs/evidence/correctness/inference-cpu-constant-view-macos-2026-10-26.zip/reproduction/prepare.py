import base64, hashlib, io, json, pathlib, subprocess, tarfile

W = pathlib.Path(__file__).resolve().parent
R = pathlib.Path.cwd()
REMOTE = '/Users/kiro/hyle-scratch/compute-unified'
DEST = REMOTE + '/cpu-region-views-20261026/attempt1'
PRODUCTS = ['src/compute_ggml_runtime/cpu_execution.cc',
            'src/compute_provider_ggml/ggml_cpu_provider.cc',
            'src/graph_route_cpu/ggml_region.cc',
            'src/compute/resource_budget.cc', 'src/compute/resource_leases.cc']

def ssh(script):
    command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
               'kiro@172.22.10.198', 'python3', '-']
    p = subprocess.run(command, input=script, text=True, capture_output=True, timeout=25)
    if p.returncode:
        raise RuntimeError(p.stderr or p.stdout)
    return p.stdout

rows = json.loads((W/'closure-list.json').read_text())
query = r'''
import pathlib,json,hashlib
R=pathlib.Path(ROOT);P=R/'qwen-pure-cpu-functional-20261024/attempt1';K=R/'qwen-k1-functional-20261024/attempt1'
roots=[P/'source',K/'source',R/'source-c8874688',R/'source']
files=[]
for rel in RELS:
 q=next((r/rel for r in roots if (r/rel).is_file()),None)
 files.append({'relative':rel,'path':str(q) if q else None,'sha256_lf':hashlib.sha256(q.read_bytes().replace(b'\r\n',b'\n')).hexdigest() if q else None})
p=json.loads((P/'plan.json').read_text());k=json.loads((K/'plan.json').read_text())
jobs=[]
for tag in PRODUCTS:
 source=p if tag not in ['src/compute/resource_budget.cc','src/compute/resource_leases.cc'] else k
 jobs.append(next(j for j in source['jobs'] if j['tag']==tag))
print(json.dumps({'files':files,'jobs':jobs,'link':p['link']}))
'''.replace('ROOT', repr(REMOTE)).replace('RELS',repr([r['relative'] for r in rows])).replace('PRODUCTS',repr(PRODUCTS))
cache = json.loads(ssh(query))
(W/'cache-plan.json').write_text(json.dumps(cache,indent=2)+'\n')
old = {x['relative']:x for x in cache['files']}
files = {}
pins = []
for row in rows:
    rel=row['relative'];p=pathlib.Path(row['local']);b=p.read_bytes()
    changed=rel in PRODUCTS or rel=='consumer.cc' or hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest()!=old[rel]['sha256_lf']
    if changed: files['source/'+rel]=b
    pins.append({'relative':rel,'local':str(p),'bytes':len(b),
                 'sha256':hashlib.sha256(b).hexdigest(),'synchronized':changed,'cache':old[rel]})

overlay = ['-I'+DEST+'/source/include']+['-I'+DEST+'/source/src/'+x for x in
    ['compute','compute_ggml_runtime','compute_provider_ggml','graph_route_cpu']]
jobs=[]
maps={}
for job in cache['jobs']:
    rel=job['tag']; argv=job.get('command',job.get('argv'))
    out=DEST+'/objects/'+rel.replace('/','--')+'.o'
    src=DEST+'/source/'+rel
    new=[];i=0
    while i<len(argv):
        a=argv[i]
        if a in ['-o','-MF']:
            new += [a,out if a=='-o' else out+'.d'];i+=2;continue
        if a.endswith('/'+rel):a=src
        new.append(a);i+=1
    new[1:1]=overlay
    if '-Werror' not in new:new.insert(1,'-Werror')
    jobs.append({'tag':rel,'command':new,'output':out})
    maps[job.get('output',job.get('object'))]=out
template=jobs[2]['command']
consumer=[DEST+'/source/consumer.cc' if a==DEST+'/source/'+PRODUCTS[2] else
          DEST+'/objects/consumer.o.d' if a==jobs[2]['output']+'.d' else
          DEST+'/objects/consumer.o' if a==jobs[2]['output'] else a for a in template]
jobs.append({'tag':'consumer','command':consumer,'output':DEST+'/objects/consumer.o'})
link=[maps.get(a,a) for a in cache['link'] if not a.endswith('/objects/model.o')]
link.insert(6,DEST+'/objects/consumer.o')
for i,a in enumerate(link):
    if a=='-o':link[i+1]=DEST+'/consumer'
    if a.startswith('-Wl,-map,'):link[i]='-Wl,-map,'+DEST+'/image.map'
plan={'remote':DEST,'jobs':jobs,'link':link,'object_map':maps,
      'frozen':'Retained pure CPU Graph, native ggml/ATen/base SDK; five nominated products current.'}
files['plan.json']=(json.dumps(plan,indent=2)+'\n').encode()
files['source-pins.json']=(json.dumps(pins,indent=2)+'\n').encode()
files['build.py']=(W/'remote_build.py').read_bytes()
(W/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as tar:
    for rel,b in sorted(files.items()):
        item=tarfile.TarInfo(rel);item.size=len(b);tar.addfile(item,io.BytesIO(b))
payload=buf.getvalue()
upload=r'''
import base64,io,pathlib,tarfile,json
root=pathlib.Path(DEST)
if root.exists():raise RuntimeError('refuse to overwrite existing attempt directory')
root.mkdir(parents=True)
with tarfile.open(fileobj=io.BytesIO(base64.b64decode(PAYLOAD)),mode='r:gz') as tar:
 for entry in tar.getmembers():
  target=(root/entry.name).resolve()
  if not target.is_relative_to(root.resolve()) or not entry.isfile():raise RuntimeError('invalid member')
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(tar.extractfile(entry).read())
print(json.dumps({'remote':str(root),'members':len(list(root.rglob('*')))}))
'''.replace('DEST',repr(DEST)).replace('PAYLOAD',repr(base64.b64encode(payload).decode()))
receipt={'synchronized_source_files':len([x for x in files if x.startswith('source/')]),
         'source_bytes':sum(len(b) for x,b in files.items() if x.startswith('source/')),
         'archive_bytes':len(payload),'archive_sha256':hashlib.sha256(payload).hexdigest(),
         'remote_receipt':json.loads(ssh(upload))}
(W/'sync-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
