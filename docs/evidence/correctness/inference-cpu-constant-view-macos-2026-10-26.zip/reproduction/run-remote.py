
import json,pathlib,subprocess,time,hashlib,os
W=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/cpu-region-views-20261026/attempt1')
D=W/'records'/'run1';D.mkdir()
command=[str(W/'consumer')]
(D/'command.json').write_text(json.dumps(command,indent=2)+'\n')
start=time.monotonic()
with (D/'stdout.log').open('wb') as out,(D/'stderr.log').open('wb') as err:
 p=subprocess.Popen(command,stdout=out,stderr=err)
 print('RUN_PID',p.pid,flush=True)
 timed_out=False
 try:code=p.wait(timeout=120)
 except subprocess.TimeoutExpired:timed_out=True;p.kill();code=p.wait()
result={'pid':p.pid,'exit_code':code,'timed_out':timed_out,'seconds':time.monotonic()-start}
(D/'process.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
print('STDOUT', (D/'stdout.log').read_text())
print('STDERR', (D/'stderr.log').read_text())
raise SystemExit(code)
