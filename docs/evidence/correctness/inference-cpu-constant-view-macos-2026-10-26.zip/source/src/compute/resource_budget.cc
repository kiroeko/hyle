#include "hyle/compute/resource_budget.h"
#include "hyle/compute/detail/resource_budget_access.h"

#include <atomic>
#include <memory>
#include <mutex>
#include <utility>

#include "hyle/core/assert.h"
#include "hyle/util/ref_counted.h"

namespace hyle::compute {
namespace detail {
struct ResourceBudgetRow final {
  ResourceBudgetRow(ResourceBudgetState *parent, ResourceBudgetLimit limit,
                    mem::AllocatorRef allocator) noexcept
      : owner(parent), resource(limit.resource), properties(limit.resource.properties()),
        quota(allocator, limit.max_bytes) {}
  ResourceBudgetState *owner;
  mem::MemoryResourceRef resource;
  mem::MemoryProperties properties;
  mem::QuotaAllocator quota;
  std::array<std::atomic<std::size_t>, kResourceBudgetCategoryCount> categories{};
  bool shared = false;
};

struct ResourceBudgetState final : util::RefCounted<ResourceBudgetState> {
  explicit ResourceBudgetState(ResourceBudgetOptions options) noexcept
      : allocator(options.allocator), opaque(options.allocator),
        allow_unattributed(options.allow_unattributed) {}
  mem::AllocatorRef allocator;
  mem::QuotaAllocator opaque;
  std::optional<mem::QuotaAllocator> shared_quota;
  mem::QuotaAllocator::Reservation control_charge;
  ResourceBudgetRow *rows = nullptr;
  ResourceBudgetRow *metadata = nullptr;
  std::size_t count = 0, allocation_bytes = 0, unassigned_control = 0;
  std::size_t shared_control_bytes = 0;
  std::atomic<std::size_t> unknown{0};
  std::mutex backing_mutex;
  SharedBackingRecord *backings = nullptr; // Non-owning; tokens own each record.
  bool allow_unattributed;
  ResourceBudgetRow *find(mem::MemoryResourceRef resource) const noexcept {
    for (std::size_t i = 0; i < count; ++i)
      if (rows[i].resource == resource) return rows + i;
    return nullptr;
  }
  bool acquire_shared(const ResourceBudgetRow &row, std::size_t bytes) noexcept {
    return !row.shared || shared_quota->try_acquire_bytes(bytes);
  }
  void release_shared(const ResourceBudgetRow &row, std::size_t bytes) noexcept {
    if (row.shared) shared_quota->release_bytes(bytes);
  }
  void destroy() noexcept {
    HYLE_FATAL_ASSERT(backings == nullptr);
    const auto backing = allocator;
    const auto bytes = allocation_bytes;
    if (metadata != nullptr)
      metadata->categories[0].fetch_sub(control_charge.size(), std::memory_order_relaxed);
    if (shared_control_bytes) shared_quota->release_bytes(shared_control_bytes);
    control_charge.reset();
    for (std::size_t i = 0; i < count; ++i) std::destroy_at(rows + i);
    std::destroy_at(this);
    backing.deallocate(this, bytes, alignof(ResourceBudgetState));
  }
};
static_assert(alignof(ResourceBudgetState) >= alignof(ResourceBudgetRow));
static_assert(sizeof(ResourceBudgetState) % alignof(ResourceBudgetRow) == 0);

struct SharedBackingRecord final {
  SharedBackingRecord(ResourceBudgetState *owner, mem::MemoryResourceRef selected,
                      BackingIdentity original, std::size_t size, mem::AllocatorRef storage,
                      ResourceBudget::Reservation reservation) noexcept
      : scope(owner), resource(selected), allocation(original), bytes(size),
        allocator(storage), charge(std::move(reservation)) {}
  ResourceBudgetState *scope;
  mem::MemoryResourceRef resource;
  BackingIdentity allocation;
  std::size_t bytes, holders = 1, retiring = 0;
  SharedBackingRecord *previous = nullptr, *next = nullptr;
  mem::AllocatorRef allocator;
  ResourceBudget::Reservation charge;
};

namespace {
// Caller holds the lookup lock. An unlinked retirement record is invisible to
// a later allocation reusing the original canonical identity.
void unlink_record(SharedBackingRecord *record) noexcept {
  if (record->previous) record->previous->next = record->next;
  else record->scope->backings = record->next;
  if (record->next) record->next->previous = record->previous;
  record->previous = record->next = nullptr;
}
void destroy_record(SharedBackingRecord *record) noexcept {
  const auto allocator = record->allocator;
  std::destroy_at(record);
  allocator.deallocate(record, sizeof(SharedBackingRecord), alignof(SharedBackingRecord));
}
} // namespace

SharedBackingReservation::SharedBackingReservation(const SharedBackingReservation &other) noexcept
    : record_(other.record_) {
  if (record_) {
    std::lock_guard lock(record_->scope->backing_mutex);
    HYLE_FATAL_ASSERT(record_->holders != 0 && record_->holders != SIZE_MAX);
    ++record_->holders;
  }
}
SharedBackingReservation &SharedBackingReservation::operator=(
    const SharedBackingReservation &other) noexcept {
  if (this != &other) { SharedBackingReservation copy(other); *this = std::move(copy); }
  return *this;
}
SharedBackingReservation::SharedBackingReservation(SharedBackingReservation &&other) noexcept
    : record_(std::exchange(other.record_, nullptr)) {}
SharedBackingReservation &SharedBackingReservation::operator=(
    SharedBackingReservation &&other) noexcept {
  if (this != &other) { reset(); record_ = std::exchange(other.record_, nullptr); }
  return *this;
}
SharedBackingReservation::~SharedBackingReservation() { reset(); }
bool SharedBackingReservation::same_scope(const ResourceBudget &budget) const noexcept {
  return record_ && ResourceBudgetAccess::same_scope(record_->charge, budget);
}
void SharedBackingReservation::reset() noexcept {
  auto *record = std::exchange(record_, nullptr);
  if (!record) return;
  {
    std::lock_guard lock(record->scope->backing_mutex);
    HYLE_FATAL_ASSERT(record->holders != 0);
    if (--record->holders != 0) return;
    unlink_record(record);
    if (record->retiring != 0) return;
  }
  // Unlink under the lookup lock, then release outside it. The metadata
  // allocation retains the scope after charge destruction until deallocation.
  destroy_record(record);
}
RetiringBackingReservation::RetiringBackingReservation(RetiringBackingReservation &&other) noexcept
    : record_(std::exchange(other.record_, nullptr)) {}
RetiringBackingReservation &RetiringBackingReservation::operator=(RetiringBackingReservation &&other) noexcept {
  if (this != &other) { reset(); record_ = std::exchange(other.record_, nullptr); }
  return *this;
}
RetiringBackingReservation::~RetiringBackingReservation() { reset(); }
void RetiringBackingReservation::reset() noexcept {
  auto *record = std::exchange(record_, nullptr);
  if (!record) return;
  {
    std::lock_guard lock(record->scope->backing_mutex);
    HYLE_FATAL_ASSERT(record->retiring != 0);
    if (--record->retiring != 0 || record->holders != 0) return;
  }
  destroy_record(record);
}
namespace {
Result<SharedBackingRecord *> reserve_backing_record(
    const ResourceBudget &budget, ResourceBudgetState *scope,
    mem::MemoryResourceRef nominated, BackingIdentity original_allocation,
    std::size_t bytes, ResourceBudget::Reservation *existing) noexcept {
  if (!scope || !nominated.valid() || !original_allocation.authority ||
      !original_allocation.value || bytes == 0 || bytes == SIZE_MAX)
    return std::unexpected(Status::InvalidArgument("shared backing requires a known nonempty allocation"));
  if (!scope->find(nominated))
    return std::unexpected(Status::InvalidArgument("resource is absent from budget"));
  std::unique_lock lock(scope->backing_mutex);
  for (auto *record = scope->backings; record; record = record->next) {
    if (record->resource != nominated ||
        record->allocation.authority != original_allocation.authority ||
        record->allocation.value != original_allocation.value) continue;
    if (record->bytes != bytes)
      return std::unexpected(Status::InvalidArgument("shared backing byte extent changed"));
    HYLE_FATAL_ASSERT(record->holders != SIZE_MAX);
    ++record->holders;
    lock.unlock();
    if (existing) existing->reset();
    return record;
  }
  HYLE_ASSIGN_OR_RETURN(auto allocator, budget.metadata_allocator());
  ResourceBudget::Reservation charge;
  if (!existing) {
    HYLE_ASSIGN_OR_RETURN(charge,
        budget.reserve(nominated, bytes, ResourceBudgetCategory::kExternal));
  }
  auto *memory = allocator.allocate(sizeof(SharedBackingRecord), alignof(SharedBackingRecord));
  if (!memory) {
    lock.unlock();
    return std::unexpected(Status::ResourceExhausted("shared backing reservation metadata"));
  }
  auto *record = std::construct_at(static_cast<SharedBackingRecord *>(memory), scope,
      nominated, original_allocation, bytes, allocator,
      existing ? std::move(*existing) : std::move(charge));
  record->next = scope->backings;
  if (record->next) record->next->previous = record;
  scope->backings = record;
  return record;
}
} // namespace
} // namespace detail
detail::RetiringBackingReservation detail::ResourceBudgetAccess::retire_backing(
    SharedBackingReservation &existing) noexcept {
  auto *record = std::exchange(existing.record_, nullptr);
  if (!record) return {};
  {
    std::lock_guard lock(record->scope->backing_mutex);
    HYLE_FATAL_ASSERT(record->holders != 0 && record->retiring != SIZE_MAX);
    ++record->retiring;
    if (--record->holders == 0) detail::unlink_record(record);
  }
  return RetiringBackingReservation(record);
}
mem::AllocatorRef detail::ResourceBudgetAccess::backing_allocator(
    const ResourceBudget &budget) noexcept {
  return budget.state_ ? original_allocator(budget.state_->allocator) : mem::AllocatorRef{};
}
mem::AllocatorRef detail::ResourceBudgetAccess::backing_allocator(
    const ResourceBudget::Reservation &reservation) noexcept {
  return reservation.state_ ? original_allocator(reservation.state_->allocator) : mem::AllocatorRef{};
}
bool detail::ResourceBudgetAccess::same_scope(const ResourceBudget::Reservation &reservation,
                                             const ResourceBudget &budget) noexcept {
  return reservation.state_ && reservation.state_ == budget.state_;
}
Result<detail::SharedBackingReservation> detail::ResourceBudgetAccess::reserve_backing(
    const ResourceBudget &budget, mem::MemoryResourceRef nominated,
    BackingIdentity original_allocation, std::size_t bytes) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto *record, detail::reserve_backing_record(
      budget, budget.state_, nominated, original_allocation, bytes, nullptr));
  return SharedBackingReservation(record);
}
Result<detail::SharedBackingReservation> detail::ResourceBudgetAccess::adopt_backing(
    const ResourceBudget &budget, mem::MemoryResourceRef nominated,
    BackingIdentity original_allocation, std::size_t bytes,
    ResourceBudget::Reservation &existing) noexcept {
  if (!same_scope(existing, budget) || existing.unknown_ || existing.row_ == SIZE_MAX ||
      (existing.category_ != ResourceBudgetCategory::kExternal &&
       existing.category_ != ResourceBudgetCategory::kMetadata) ||
      existing.state_->rows[existing.row_].resource != nominated || existing.charge_.size() != bytes)
    return std::unexpected(Status::InvalidArgument("existing backing reservation does not match"));
  HYLE_ASSIGN_OR_RETURN(auto *record, detail::reserve_backing_record(
      budget, budget.state_, nominated, original_allocation, bytes, &existing));
  return SharedBackingReservation(record);
}
namespace {
void *allocate(void *opaque, std::size_t bytes, std::size_t alignment) noexcept {
  auto &row = *static_cast<detail::ResourceBudgetRow *>(opaque);
  if (!row.owner->acquire_shared(row, bytes)) return nullptr;
  auto *p = row.quota.get().allocate(bytes, alignment);
  if (p != nullptr) {
    row.categories[0].fetch_add(bytes, std::memory_order_relaxed);
    row.owner->incref();
  } else row.owner->release_shared(row, bytes);
  return p;
}
void deallocate(void *opaque, void *p, std::size_t bytes,
                std::size_t alignment) noexcept {
  if (p == nullptr) return;
  auto &row = *static_cast<detail::ResourceBudgetRow *>(opaque);
  auto *owner = row.owner;
  row.quota.get().deallocate(p, bytes, alignment);
  row.categories[0].fetch_sub(bytes, std::memory_order_relaxed);
  owner->release_shared(row, bytes);
  owner->decref();
}
void *reallocate(void *opaque, void *p, std::size_t old_bytes,
                 std::size_t bytes, std::size_t alignment) noexcept {
  if (p == nullptr) return allocate(opaque, bytes, alignment);
  auto &row = *static_cast<detail::ResourceBudgetRow *>(opaque);
  auto *owner = row.owner;
  const auto growth = bytes > old_bytes ? bytes - old_bytes : 0;
  if (growth && !owner->acquire_shared(row, growth)) return nullptr;
  auto *result = row.quota.get().reallocate(p, old_bytes, bytes, alignment);
  if (result != nullptr || bytes == 0) {
    if (bytes >= old_bytes)
      row.categories[0].fetch_add(bytes - old_bytes, std::memory_order_relaxed);
    else
      row.categories[0].fetch_sub(old_bytes - bytes, std::memory_order_relaxed);
    if (bytes < old_bytes) owner->release_shared(row, old_bytes - bytes);
  } else if (growth) owner->release_shared(row, growth);
  if (bytes == 0) owner->decref();
  return result;
}
} // namespace

mem::AllocatorRef detail::ResourceBudgetAccess::original_allocator(mem::AllocatorRef selected) noexcept {
  // These callbacks alone prove the private ResourceBudgetRow state type.
  // Every actual allocation through them retains its own scope until free.
  // No inference is made about any third-party allocator decorator.
  while (selected.valid() && selected.alloc_fn() == allocate &&
         selected.free_fn() == deallocate && selected.realloc_fn() == reallocate) {
    const auto *row = static_cast<const detail::ResourceBudgetRow *>(selected.state());
    HYLE_FATAL_ASSERT(row && row->owner);
    selected = row->owner->allocator;
  }
  return selected;
}

ResourceBudget::Reservation::Reservation(detail::ResourceBudgetState *state,
    mem::QuotaAllocator::Reservation charge, bool unknown, std::size_t row,
    ResourceBudgetCategory category) noexcept
    : state_(state), charge_(std::move(charge)), unknown_(unknown), row_(row),
      category_(category) {
  state_->incref();
  if (unknown_) state_->unknown.fetch_add(1, std::memory_order_relaxed);
  if (row_ != SIZE_MAX)
    state_->rows[row_].categories[static_cast<std::size_t>(category_)].fetch_add(
        charge_.size(), std::memory_order_relaxed);
}
ResourceBudget::Reservation::Reservation(Reservation &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)), charge_(std::move(other.charge_)),
      unknown_(other.unknown_), row_(other.row_), category_(other.category_) {}
ResourceBudget::Reservation &ResourceBudget::Reservation::operator=(Reservation &&other) noexcept {
  if (this != &other) {
    reset(); state_ = std::exchange(other.state_, nullptr);
    charge_ = std::move(other.charge_); unknown_ = other.unknown_;
    row_ = other.row_; category_ = other.category_;
  }
  return *this;
}
ResourceBudget::Reservation::~Reservation() { reset(); }
void ResourceBudget::Reservation::reset() noexcept {
  auto *owner = std::exchange(state_, nullptr);
  if (owner == nullptr) return;
  if (row_ != SIZE_MAX)
    owner->rows[row_].categories[static_cast<std::size_t>(category_)].fetch_sub(
        charge_.size(), std::memory_order_relaxed);
  if (row_ != SIZE_MAX) owner->release_shared(owner->rows[row_], charge_.size());
  charge_.reset();
  if (unknown_) owner->unknown.fetch_sub(1, std::memory_order_relaxed);
  owner->decref();
}
ResourceBudget::ResourceBudget(const ResourceBudget &other) noexcept : state_(other.state_) {
  if (state_ != nullptr) state_->incref();
}
ResourceBudget &ResourceBudget::operator=(const ResourceBudget &other) noexcept {
  if (this != &other) {
    if (other.state_ != nullptr) other.state_->incref();
    if (state_ != nullptr) state_->decref();
    state_ = other.state_;
  }
  return *this;
}
ResourceBudget::ResourceBudget(ResourceBudget &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)) {}
ResourceBudget &ResourceBudget::operator=(ResourceBudget &&other) noexcept {
  if (this != &other) {
    if (state_ != nullptr) state_->decref();
    state_ = std::exchange(other.state_, nullptr);
  }
  return *this;
}
ResourceBudget::~ResourceBudget() { if (state_ != nullptr) state_->decref(); }
Result<ResourceBudget> ResourceBudget::create(ResourceBudgetOptions options) noexcept {
  return create_impl(options, {}, std::nullopt);
}
Result<ResourceBudget> ResourceBudget::create(ResourceBudgetOptions options,
    std::span<const mem::MemoryResourceRef> nominated_resources,
    std::size_t max_shared_bytes) noexcept {
  if (nominated_resources.empty())
    return std::unexpected(Status::InvalidArgument("shared resource budget requires nominated resources"));
  return create_impl(options, nominated_resources, max_shared_bytes);
}
Result<ResourceBudget> ResourceBudget::create_impl(ResourceBudgetOptions options,
    std::span<const mem::MemoryResourceRef> nominated_resources,
    std::optional<std::size_t> max_shared_bytes) noexcept {
  if (!options.allocator.valid() || options.limits.empty() ||
      !options.metadata_resource.valid() ||
      !options.metadata_resource.properties().has(mem::MemoryProperty::kHostAccessible))
    return std::unexpected(Status::InvalidArgument("invalid resource budget"));
  for (std::size_t i = 0; i < options.limits.size(); ++i) {
    if (!options.limits[i].resource.valid())
      return std::unexpected(Status::InvalidArgument("invalid budget resource"));
    for (std::size_t j = 0; j < i; ++j)
      if (options.limits[i].resource == options.limits[j].resource)
        return std::unexpected(Status::InvalidArgument("duplicate budget resource"));
  }
  bool shared_metadata = false;
  for (std::size_t i = 0; i < nominated_resources.size(); ++i) {
    const auto resource = nominated_resources[i];
    bool found = false;
    for (const auto limit : options.limits) found = found || limit.resource == resource;
    if (!resource.valid() || !found)
      return std::unexpected(Status::InvalidArgument("shared resource is absent from budget"));
    for (std::size_t j = 0; j < i; ++j)
      if (resource == nominated_resources[j])
        return std::unexpected(Status::InvalidArgument("duplicate shared budget resource"));
    shared_metadata = shared_metadata || resource == options.metadata_resource;
  }
  if (options.limits.size() > (SIZE_MAX - sizeof(detail::ResourceBudgetState)) /
                                 sizeof(detail::ResourceBudgetRow))
    return std::unexpected(Status::ResourceExhausted("resource budget size overflows"));
  const auto bytes = sizeof(detail::ResourceBudgetState) +
                     options.limits.size() * sizeof(detail::ResourceBudgetRow);
  // This scope is not published yet. Account its nominated CPU control before
  // even allocating the State that will own the aggregate quota.
  if (shared_metadata && bytes > *max_shared_bytes)
    return std::unexpected(Status::ResourceExhausted("shared budget cannot hold control state"));
  auto *memory = options.allocator.allocate(bytes, alignof(detail::ResourceBudgetState));
  if (memory == nullptr)
    return std::unexpected(Status::ResourceExhausted("resource budget metadata"));
  auto *state = std::construct_at(static_cast<detail::ResourceBudgetState *>(memory), options);
  if (max_shared_bytes) state->shared_quota.emplace(options.allocator, *max_shared_bytes);
  state->allocation_bytes = bytes;
  state->rows = reinterpret_cast<detail::ResourceBudgetRow *>(state + 1);
  for (auto limit : options.limits) {
    std::construct_at(state->rows + state->count, state, limit, options.allocator);
    for (const auto resource : nominated_resources)
      if (resource == limit.resource) state->rows[state->count].shared = true;
    ++state->count;
  }
  state->metadata = state->find(options.metadata_resource);
  if (state->metadata == nullptr) {
    state->decref();
    return std::unexpected(Status::InvalidArgument("metadata resource is absent from budget"));
  }
  auto control = state->metadata->quota.try_reserve_bytes(bytes);
  if (!control) {
    state->decref();
    return std::unexpected(Status::ResourceExhausted("resource budget cannot hold control state"));
  }
  if (state->metadata->shared) {
    if (!state->acquire_shared(*state->metadata, bytes)) {
      control->reset();
      state->decref();
      return std::unexpected(Status::ResourceExhausted("shared budget cannot admit control state"));
    }
    state->shared_control_bytes = bytes;
  }
  state->control_charge = std::move(*control);
  state->metadata->categories[0].fetch_add(bytes, std::memory_order_relaxed);
  return ResourceBudget(state);
}
std::optional<SharedRequestedBytesUsage> ResourceBudget::shared_usage() const noexcept {
  if (!state_ || !state_->shared_quota) return std::nullopt;
  const auto &quota = *state_->shared_quota;
  return SharedRequestedBytesUsage{quota.used(), quota.peak(), quota.limit()};
}
std::size_t ResourceBudget::resource_count() const noexcept { return state_ ? state_->count : 0; }
Result<mem::MemoryResourceRef> ResourceBudget::resource(std::size_t index) const noexcept {
  if (!state_ || index >= state_->count)
    return std::unexpected(Status::OutOfRange("resource budget index"));
  return state_->rows[index].resource;
}
Result<ResourceBudgetUsage> ResourceBudget::usage(mem::MemoryResourceRef resource) const noexcept {
  auto *row = state_ ? state_->find(resource) : nullptr;
  if (row == nullptr)
    return std::unexpected(Status::InvalidArgument("resource is absent from budget"));
  ResourceBudgetUsage result{row->properties, row->quota.used(), row->quota.peak(), row->quota.limit()};
  for (std::size_t i = 0; i < result.live_by_category.size(); ++i)
    result.live_by_category[i] = row->categories[i].load(std::memory_order_relaxed);
  return result;
}
UnattributedStorageUsage ResourceBudget::unattributed_usage() const noexcept {
  return state_ ? UnattributedStorageUsage{state_->opaque.used(),
      state_->unknown.load(std::memory_order_relaxed), state_->unassigned_control}
      : UnattributedStorageUsage{};
}
bool ResourceBudget::allows_unattributed() const noexcept {
  return state_ && state_->allow_unattributed;
}
Result<ResourceBudget::Reservation> ResourceBudget::reserve(
    mem::MemoryResourceRef resource, std::size_t bytes,
    ResourceBudgetCategory category) const noexcept {
  auto *row = state_ ? state_->find(resource) : nullptr;
  if (row == nullptr || static_cast<std::size_t>(category) >= kResourceBudgetCategoryCount)
    return std::unexpected(Status::InvalidArgument("resource is absent from budget"));
  auto charge = row->quota.try_reserve_bytes(bytes);
  if (!charge)
    return std::unexpected(Status::ResourceExhausted("shared resource budget is exhausted"));
  if (!state_->acquire_shared(*row, bytes))
    return std::unexpected(Status::ResourceExhausted("shared nominated-resource total is exhausted"));
  return Reservation(state_, std::move(*charge), false,
      static_cast<std::size_t>(row - state_->rows), category);
}
Result<ResourceBudget::Reservation> ResourceBudget::reserve_unattributed(
    std::optional<std::size_t> bytes) const noexcept {
  if (bytes && *bytes == 0) return Reservation{};
  if (!state_ || !state_->allow_unattributed)
    return std::unexpected(Status::ResourceExhausted("private storage has no budget domain"));
  auto charge = state_->opaque.try_reserve_bytes(bytes.value_or(0));
  if (!charge)
    return std::unexpected(Status::ResourceExhausted("private storage sum overflows"));
  return Reservation(state_, std::move(*charge), !bytes, SIZE_MAX,
                     ResourceBudgetCategory::kExternal);
}
Result<mem::AllocatorRef> ResourceBudget::metadata_allocator() const noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("invalid resource budget"));
  return mem::AllocatorRef{allocate, deallocate, reallocate, state_->metadata};
}
} // namespace hyle::compute
