#include <array>
#include <bit>
#include <cstdint>
#include <cstdio>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/cpu.h"
#include "hyle/graph/result.h"
#include "hyle/mem/buffer.h"

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace {
void require(bool ok, const char *where) {
  if (!ok) throw std::runtime_error(where);
}
void check(hyle::Status status, const char *where) {
  if (!status.ok()) throw std::runtime_error(std::string(where) + ": " +
      std::string(status.message()));
}
template<class T> T take(hyle::Result<T> value, const char *where) {
  if (!value) check(std::move(value).error(), where);
  return std::move(*value);
}
std::uint16_t bits(int n) {
  return static_cast<std::uint16_t>(
      std::bit_cast<std::uint32_t>(static_cast<float>(n)) >> 16);
}
m::Buffer buffer(const c::TensorDesc &d) {
  return take(m::Buffer::create(m::system_resource(), d.required_bytes().value(),
      256), "buffer");
}
void view_case(c::Context &context, int mode) {
  const auto ad = c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t,2>{1,4}).value();
  const auto wd = c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t,2>{3,4}).value();
  const auto yd = c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t,2>{1,3}).value();
  const std::array<int,12> weights{1,2,3,4,0,-1,1,2,-2,3,-4,1};
  std::array<std::uint16_t,12> wb{};
  for (std::size_t i=0;i<wb.size();++i) wb[i]=bits(weights[i]);
  auto a=buffer(ad), w=buffer(wd);
  std::array y{buffer(yd),buffer(yd)};
  check(w.view().write(std::as_bytes(std::span(wb))), "write W");
  auto ready=take(c::ReadLease::adopt(std::move(w)), "adopt W");
  const auto original=take(ready.tensor(wd), "W tensor");
  auto b=g::GraphBuilder::create().value();
  const auto input=b.input(ad).value(), weight=b.constant(wd).value();
  const auto first=b.add_node(c::Operation(c::Unary{c::UnaryKind::kNeg}),
      std::array{input}).value();
  constexpr std::array<std::int32_t,2> axes{1,0};
  const auto view=b.add_node(c::Operation(c::View::permute(axes).value()),
      std::array{weight}).value();
  if (mode==2) check(b.depends_on(view,first), "control dependency");
  const auto viewed=b.result(view).value();
  const auto last=b.add_node(c::Operation(c::MatMul{}),
      std::array{b.result(first).value(),viewed}).value();
  const auto output=b.result(last).value();
  check(b.publish(output), "publish output");
  if (mode==1) check(b.publish(viewed), "publish alias");
  auto graph=std::move(b).finish().value();
  const std::array constants{g::ConstantBinding{weight,original,
      g::ConstantPolicy::kBorrow,{},ready}};
  const std::array storage{g::StorageDomain{.resource=m::system_resource()}};
  const std::array targets{g::ExecutionTarget{
      .source=g::ExecutionSource::acquire(context).value(),
      .default_storage=g::StorageDomainId{0}}};
  const std::array lanes{g::ExecutionLane{.target=g::ExecutionTargetId{0}}};
  auto compiled=take(g::compile(graph,
      {.storage_domains=storage,.targets=targets,.lanes=lanes},
      {.constants=constants}), "compile View case");
  require(compiled.report.region_count()==(mode==0?1U:0U), "View region fence");
  require(compiled.report.step_count()==(mode==0?2U:3U), "View step count");
  require(compiled.report.packed_constant_count()==0 &&
      compiled.report.packed_constant_bytes()==0, "unexpected W packing");
  std::size_t views=0;
  for(std::size_t i=0;i<compiled.report.step_count();++i) {
    const auto s=compiled.report.step(i).value();
    if(s.kind==g::CompileStepKind::kView) ++views;
    if(s.kind==g::CompileStepKind::kProviderRegion) {
      require(s.provider.id==c::ggml_cpu::kProviderId, "not ggml native region");
      require(s.node_count==2, "native region member count");
      require(compiled.report.step_node(i,0).value()==first &&
          compiled.report.step_node(i,1).value()==last, "native region members");
    }
  }
  require(views==1, "metadata View must remain a Graph step");
  std::array runs{compiled.executable.create_invocation().value(),
                 compiled.executable.create_invocation().value()};
  auto queue=context.create_queue().value();
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
  std::array<std::uint16_t,3> previous{};
  for(std::size_t phase=0;phase<runs.size();++phase) {
    std::array<int,4> source{};
    std::array<std::uint16_t,4> ab{};
    for(std::size_t k=0;k<ab.size();++k) {
      source[k]=(k%2==0?1:-1)*static_cast<int>(k+1)+static_cast<int>(phase);
      ab[k]=bits(source[k]);
    }
    check(a.view().write(std::as_bytes(std::span(ab))), "write A");
    auto &run=runs[phase];
    check(run.bind(input,c::ConstTensorView::create(ad,a.view()).value()), "bind A");
    check(run.bind(output,c::TensorView::create(yd,y[phase].view()).value()), "bind Y");
    check(run.prepare_replay(queues), "prepare View case");
    auto done=take(run.submit(queue), "submit View case");
    check(done.wait(), "wait View case");
    std::array<std::uint16_t,3> actual{};
    check(y[phase].view().read(std::as_writable_bytes(std::span(actual))), "read Y");
    for(std::size_t n=0;n<actual.size();++n) {
      int expected=0;
      for(std::size_t k=0;k<source.size();++k) expected-=source[k]*weights[n*4+k];
      require(actual[n]==bits(expected), "View numerical result");
    }
    if(phase==0) previous=actual;
    else {
      std::array<std::uint16_t,3> old{};
      check(y[0].view().read(std::as_writable_bytes(std::span(old))), "read old Y");
      require(old==previous, "old slot output changed");
    }
    std::array<std::uint16_t,12> unchanged{};
    check(original.storage().read(std::as_writable_bytes(std::span(unchanged))), "read W");
    require(unchanged==wb, "original W changed");
    if(mode==1) {
      const auto alias=run.result(viewed).value().tensor().value();
      require(alias.description()==graph.value_description(viewed).value(), "alias desc");
      require(alias.storage().resource()==original.storage().resource() &&
          alias.storage().native_handle()==original.storage().native_handle() &&
          alias.storage().offset()==original.storage().offset(), "published alias identity");
    }
  }
  std::printf("view mode=%d regions=%zu steps=%zu slots=2 submissions=2 packed_bytes=0 PASS\n",
      mode,compiled.report.region_count(),compiled.report.step_count());
}
void store_case(c::Context &context) {
  const auto d=c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t,2>{1,2}).value();
  auto builder=g::GraphBuilder::create().value();
  const auto a=builder.input(d).value(), b=builder.input(d).value();
  const auto sum=builder.add(c::Binary{c::BinaryKind::kAdd},a,b).value();
  const auto out=builder.add(c::Binary{c::BinaryKind::kSubtract},sum,a).value();
  check(builder.publish(out), "publish store witness");
  auto graph=std::move(builder).finish().value();
  auto compiled=take(g::compile(graph,context), "compile store witness");
  require(compiled.report.region_count()==1 && compiled.report.step_count()==1,
      "store witness must be one native region");
  const auto step=compiled.report.step(0).value();
  require(step.provider.id==c::ggml_cpu::kProviderId && step.node_count==2,
      "store witness native nodes");
  constexpr std::array<std::uint16_t,2> av{0x3f80,0x3f81}, bv{0x3b80,0x3b80};
  constexpr std::array<std::uint16_t,2> expected{0,0x3c00};
  auto ab=buffer(d),bb=buffer(d),yb=buffer(d);
  check(ab.view().write(std::as_bytes(std::span(av))), "store A");
  check(bb.view().write(std::as_bytes(std::span(bv))), "store B");
  auto run=compiled.executable.create_invocation().value();
  check(run.bind(a,c::ConstTensorView::create(d,ab.view()).value()), "bind store A");
  check(run.bind(b,c::ConstTensorView::create(d,bb.view()).value()), "bind store B");
  check(run.bind(out,c::TensorView::create(d,yb.view()).value()), "bind store Y");
  auto queue=context.create_queue().value();
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
  check(run.prepare_replay(queues), "prepare store witness");
  auto done=take(run.submit(queue), "submit store witness");
  check(done.wait(), "wait store witness");
  std::array<std::uint16_t,2> actual{};
  check(yb.view().read(std::as_writable_bytes(std::span(actual))), "read store witness");
  require(actual==expected, "per-node BF16 rounding changed");
  std::printf("bf16_store bits=[%04x,%04x] regions=1 nodes=2 PASS\n",actual[0],actual[1]);
}
}
int main() {
  try {
    auto context=take(g::cpu::create_context({.native_threads=4}), "native4 Context");
    for(int mode=0;mode<3;++mode) view_case(context,mode);
    store_case(context);
    std::puts("native_threads=4 two_slots=checked total_submissions=7 PASS");
    return 0;
  } catch(const std::exception &e) {
    std::fprintf(stderr,"FAIL: %s\n",e.what());
    return 1;
  }
}
