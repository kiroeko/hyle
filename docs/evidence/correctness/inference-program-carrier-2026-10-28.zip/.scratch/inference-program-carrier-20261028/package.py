"""Offline bounded carrier evidence; never builds, runs or deletes artifacts."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
F = W / 'refinement'
BASE = R / '.scratch/inference-mtp-e4-20261028/validation'
DEST = R / 'docs/evidence/correctness/inference-program-carrier-2026-10-28'
ARMS = ('carrier-cpu', 'carrier-cuda', 'logits-cpu', 'logits-cuda', 'e4-cpu', 'preflight-cpu')

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def exact(row):
    now = pin(row['path'])
    assert (now['bytes'], now['sha256']) == (row['bytes'], row['sha256']), row['path']
def process(path, expected=0):
    value = read(path)
    assert value['exit'] == expected and not value['timed_out'], value
    return value

def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    frozen = read(F / 'source-freeze.json')
    for row in frozen['snapshots']:
        exact(row['original']); exact(row['snapshot'])
    ready = read(F / 'ready-tiny.json'); exact(ready['inputs'])
    rows = read(ready['inputs']['path']); old = read(BASE / 'ready-tiny.json')
    old_rows = read(old['inputs']['path']); assert len(rows) == len(old_rows) == 228
    assert [row for row in rows if row != ready['compiled']['object']] == [row for row in old_rows if row != old['compiled']['object']]
    weights = read(F / 'plan.json')['weights_retained']
    assert weights == old['weights'] and weights['object'] in rows
    exact(weights['source'])
    expected = read(F / 'expected-sources.json')
    failed = process(W / 'logs/tiny/process.json', 2); assert failed['pid'] == 20616
    compiled = process(F / 'logs/tiny/process.json'); assert compiled['pid'] == 37572
    linked = process(F / 'link/tiny/process.json'); assert linked['pid'] == 59940
    runs = []
    for arm in ARMS:
        out = F / 'runs' / arm; report = read(out / 'report.json'); proc = process(out / 'process.json')
        assert read(out / 'summary.json')['status'] == 'PASS' and report['status'] == 'PASS'
        facts = {}
        if arm.startswith('carrier'):
            assert (report['models'], report['native_submissions'], report['carriers']) == (0, 2, 2)
            for field in ('cold_failure_atomic', 'independent_fixed_bindings', 'real_completion_retirement',
                          'GraphOutput_pin_preserved', 'closed_handle_not_reused', 'teardown_handoff_irreversible'):
                assert report[field] is True
            facts = dict(models=0, native_submissions=2, pending_observed=report['pending_observed'],
                atomic_initialization=True, independent_original_invocations=True,
                original_scope_retirement=True, GraphOutput_pin_preserved=True, irreversible_teardown=True)
        elif arm.startswith('logits'):
            checks = report['state_checks']; assert len(checks) == 10
            assert all(c['payloads_byte_equal'] and c['differences'] == [] and c['boundary_equal'] for c in checks)
            assert report['finite_math_branches'] == 2 and report['final_versions'] == 0
            facts = dict(models=1, initialized_state_checks=10, all_payloads_byte_equal=True,
                differences=0, original_finite_Graph_math_branches=2, final_versions=0)
        elif arm == 'e4-cpu':
            assert (report['complete_byte_equal_checks'], report['exact_cache_backing_bytes'], report['final_versions']) == (11, 314119, 0)
            assert report['controlled_B2_accepted_prefixes'] == [1, 2] and report['controlled_B2_RNG_unchanged'] is True
            facts = dict(models=1, initialized_state_byte_equal_checks=11,
                target='E4M3FN', draft='BF16', exact_cache_backing_bytes=314119,
                controlled_B2_accepted_prefixes=[1, 2], RNG_unchanged=True, final_versions=0)
        else:
            assert report['preflight_submissions'] == 0 and report['typed_invalid_argument'] is True
            assert report['original_key'] is True and report['same_key_peer_continued'] is True
            assert report['complete_state_unchanged'] is True and report['final_versions'] == 0
            facts = dict(models=1, typed_original_key_rejection=True, rejected_native_submissions=0,
                complete_state_and_ledger_unchanged=True, same_key_peer_continued=True, final_versions=0)
        runs.append(dict(arm=arm, pid=proc['pid'], exit=proc['exit'], seconds=proc['seconds'], facts=facts))
    candidates = []
    protected = {str(Path(row['path']).resolve()).casefold() for row in rows}
    for path in (BASE / 'bin/tiny.exe', BASE / 'bin/tiny.exp', BASE / 'bin/tiny.lib', BASE / 'compile/tiny/unit.obj'):
        assert path.is_file() and str(path).casefold() not in protected
        candidates.append(dict(path=str(path), bytes=path.stat().st_size, exists=True, referenced_by_current_228=False))
    cleanup = dict(status='CANDIDATES_ONLY_NO_DELETE', files=candidates, count=4,
        bytes=sum(c['bytes'] for c in candidates), protected_ready=pin(F / 'ready-tiny.json'),
        protected_inputs=pin(F / 'inputs-tiny.json'),
        preserve='Current weights/SDK/Tiny and all source, command, dependency, log, ready and evidence receipts.')
    (W / 'cleanup-candidates.json').write_bytes(encoded(cleanup))
    old_sampling = R / '.scratch/inference-mtp-sampling-20261028/refinement-v4/source/tests/tools/qwen_mtp_sampling_case.h'
    old_case = W / 'source-final/tests/tools/inference_program_carrier_case.h'
    changes = []
    for before, after, label in ((old_sampling, F / 'source/tests/tools/qwen_mtp_sampling_case.h', 'qwen_mtp_sampling_case.h'),
                                 (old_case, F / 'source/tests/tools/inference_program_carrier_case.h', 'inference_program_carrier_case.h')):
        changes.extend(difflib.unified_diff(before.read_text().splitlines(True), after.read_text().splitlines(True),
            fromfile='failed/' + label, tofile='corrected/' + label))
    (W / 'test-refinement.diff').write_text(''.join(changes), encoding='utf-8')
    prior = pin(R / 'docs/evidence/correctness/inference-mtp-e4-2026-10-28.json')
    evidence = dict(status='PASS_BOUNDED_ORIGINAL_PROGRAM_CARRIER',
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), base='d4c2af9069d21b5dd1f137f0ea9f65096af39d08',
        implementation=['One nonmoving embedded carrier shares original Invocation, selected queue bindings and original scope-retention plumbing across NextN, recursive prefix decision and sampling frontier.',
            'Fixed bindings publish a local candidate only after complete success. Actual close/drain retirement remains separate from transaction recovery and reusable reset; teardown handoff is permanent.',
            'NextN retains its original Step transaction recovery; Source publication, model mathematics, sampling policies and Session acceptance retain their existing owners. Phase shares the static submit-retention algorithm.'],
        counts=dict(actual_CXX=2,successful_CXX=1,failed_CXX=1,actual_links=1,successful_links=1,
            actual_consumer_processes=6,successful_consumer_processes=6,zero_Model_carrier_processes=2,
            Model_processes=4,Model_instances=4,SDK_CXX=0,NVCC=0,downloads=0),
        build=dict(failed_CXX=failed,successful_CXX=compiled,link=linked,current_image=ready['image'],
            link_inputs=228,replaced_objects=1,retained_object_or_library_inputs=227,weights_object=weights['object']),
        failure=dict(kind='Test API adaptation errors, no link or inference in the failed attempt',pid=20616,
            details=['qwen_mtp_sampling_case.h still accessed removed PrefixSamplingProgram.run.',
                'The new carrier case called an unavailable GraphBuilder::add(Operation,array) overload.'],
            correction='Use carrier.initialized() and original typed public add(Binary,first,second); product sources unchanged between attempts.',
            original_sources_and_logs_preserved=True),
        runs=runs,source_pins=expected,
        ownership_review='Static review caught the advisory close-busy Unavailable masking a subsequent native drain Status; the final shared helper ignores only that original nonnative busy hint. No injected native-fault runtime test was added.',
        dependency_boundary='Canonical include-main TU only was rebuilt. Actual MSVC dependency receipts and before/after project pins are retained; weights source/types and public SDK/backend layouts were unchanged. The other 227 object/library identities are reused, without claiming a full retained-header ABI audit.',
        source_freeze=pin(F / 'source-freeze.json'),actual_dependencies=pin(F / 'compile/tiny/dependencies.json'),
        reference=prior,
        limits=['Finite CPU/CUDA checks only; no other-platform, throughput, model-quality, native-fault or MTP cross-episode overlap claim.',
            'The zero-Model carrier cases each execute two original native Add submissions. Pending was observed on both actual runs, but no gate forces every pending branch.',
            'MTP logits repeats ten byte-exact initialized-state checks per backend; E4 CPU repeats eleven. The inherited finite GDN numerical oracle was retained; actual reported payload differences were zero.',
            'Phase still owns cold carrier initialization and its fields; the shared algorithm is not a new executor, Completion owner or transaction protocol.',
            'The E4 regression uses original Commands replay. Recorded process seconds are provenance, not performance measurements.'],
        reproduction=dict(build=(F / 'build.py').relative_to(R).as_posix(),run=(F / 'run.py').relative_to(R).as_posix(),
            commands=['build.py prepare', 'build.py freeze', 'build.py compile', 'build.py link',
                'run.py run carrier-cpu|carrier-cuda|logits-cpu|logits-cuda|e4-cpu|preflight-cpu'],
            policy='Root executed explicit single-use actions; no successful process was rerun. Archived pins require the matching checkout and retained external dependencies.'),
        cleanup_candidates=cleanup,raw_manifest='manifest.json')
    members = {}; allowed = {'.py', '.json', '.h', '.cc', '.diff', '.log', '.xml'}
    def add(path, name=None):
        path = Path(path); assert path.is_file() and path.suffix.lower() in allowed
        name = name or path.relative_to(R).as_posix()
        assert name not in members, name
        members[name] = path.read_bytes()
    for root in (W, F, W / 'product'):
        for path in sorted(root.iterdir()):
            if path.is_file() and path.suffix.lower() in allowed: add(path)
    for root in (W / 'product/source', W / 'source/tests', W / 'source-final/tests', W / 'logs', W / 'compile',
                 F / 'source/tests', F / 'logs', F / 'compile', F / 'link', F / 'runs'):
        for path in sorted(root.rglob('*')):
            if path.is_file() and path.suffix.lower() in allowed: add(path)
    add(old_sampling, 'references/failed-qwen_mtp_sampling_case.h')
    for path in (R / prior['path'], BASE / 'ready-tiny.json', BASE / 'inputs-tiny.json',
                 R / '.scratch/inference-mtp-sampling-20261028/refinement-v4/build.py',
                 R / '.scratch/inference-indexed-store-20261028/build.py',
                 R / '.scratch/inference-mtp-logits-20261028/refinement/run.py', BASE / 'run.py'):
        add(path)
    members['evidence-core.json'] = encoded(evidence)
    members['manifest.json'] = encoded(dict(files=[dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        for name,raw in sorted(members.items())],excluded=['EXE/OBJ/EXP/LIB/PDB/DLL','SDK/model payload','whole SDK/header trees','unrelated docs/license']))
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,raw in sorted(members.items()): archive.writestr(name,raw)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None
        for row in json.loads(archive.read('manifest.json'))['files']:
            raw=archive.read(row['path'])
            assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    evidence['archive']=dict(**pin(DEST.with_suffix('.zip')),files=len(members),CRC_and_member_SHA256_verified=True)
    DEST.with_suffix('.json').write_bytes(encoded(evidence))
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')),archive=evidence['archive'],
        counts=evidence['counts'],cleanup_count=cleanup['count'],cleanup_bytes=cleanup['bytes']),indent=2))

if __name__ == '__main__': main()
