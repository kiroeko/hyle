"""One original Tiny CXX/link. Every action is explicit; no automatic retry."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
BASE = R / '.scratch/inference-mtp-e4-20261028/validation'
spec = importlib.util.spec_from_file_location('carrier_retained_build',
    R / '.scratch/inference-mtp-sampling-20261028/refinement-v4/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.W, b.R, b.BASE, b.t.W = W, R, BASE, W
t = b.t


def prepare():
    b.prepare()
    plan, runtime = t.read(W / 'plan.json'), t.read(W / 'runtime-plan.json')
    runtime.update(consumer='program-carrier and original finite regressions',
        method='Same-file original CPU DLL hardlink; no SDK/payload copy',
        CPU_processes=4, CUDA_processes=2,
        models_per_process={'carrier-cpu': 0, 'carrier-cuda': 0,
            'logits-cpu': 1, 'logits-cuda': 1, 'e4-cpu': 1, 'preflight-cpu': 1})
    for field in ('sampling_models_per_process', 'model_order', 'fixture'):
        runtime.pop(field, None)
    (W / 'runtime-plan.json').write_text(__import__('json').dumps(runtime, indent=2) + '\n', encoding='utf-8')
    ready = t.read(BASE / 'ready-tiny.json')
    weights = ready['weights']
    assert t.key(weights['source']['path']) == t.key(R / 'engine/models/qwen35/weights.cc')
    for field in ('source',): t.exact(weights[field])
    assert t.pin(R / 'engine/models/qwen35/weights.h')['sha256'] == 'fbf450cd942cce0874016efb7d2cf27920961dc8fba1eeadf1c3ec5b09a3afac'
    plan.update(runtime=t.pin(W / 'runtime-plan.json'), CPU_processes=4, CUDA_processes=2,
        planned_processes=6, planned_models=4, weights_retained=weights,
        compatibility='Only the include-main consumer is replaced. New carrier is engine-private; weights.h, PreparedWeightSource, public SDK layouts and backend ABI are unchanged. Retain the original weights OBJ and other 227 link inputs. No blanket proof for unavailable dependency metadata is claimed.')
    (W / 'plan.json').write_text(__import__('json').dumps(plan, indent=2) + '\n', encoding='utf-8')
    print('PREPARED ONLY: 1 Tiny CXX, 1 link, 228 inputs, 6 finite processes')


def freeze():
    plan = b.prepared(); expected = t.read(W / 'expected-sources.json')
    required = {'engine/models/qwen35/main.cc', 'engine/inference/program_carrier.h',
        'tests/tools/qwen_host_image_test.cc', 'tests/tools/inference_program_carrier_case.h'}
    assert required <= set(expected)
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    project = [t.pin(path) for path in b.project_paths(plan, expected)]
    t.save(W / 'project-dependencies.json', project)
    snapshots = []
    for relative in expected:
        original, snapshot = R / relative, W / 'source' / relative
        if snapshot.exists() and snapshot.read_bytes() != original.read_bytes():
            snapshot = W / 'source-final' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        if snapshot.exists(): assert snapshot.read_bytes() == original.read_bytes()
        else:
            with snapshot.open('xb') as stream: stream.write(original.read_bytes())
        snapshots.append(dict(original=t.pin(original), snapshot=t.pin(snapshot)))
    t.save(W / 'source-freeze.json', dict(expected=t.pin(W / 'expected-sources.json'),
        helper=t.pin(W / 'build.py'), snapshots=snapshots,
        project_dependencies=t.pin(W / 'project-dependencies.json'),
        note='Canonical source compilation; only changed project sources are copied as evidence. No SDK or model copy.'))
    print('SOURCE FROZEN ONLY')


def validate():
    plan = b.prepared(); frozen = t.read(W / 'source-freeze.json')
    for field in ('expected', 'helper', 'project_dependencies'): t.exact(frozen[field])
    for row in frozen['snapshots']:
        t.exact(row['original']); t.exact(row['snapshot'])
    return plan, frozen


b.validate = validate
if __name__ == '__main__':
    {'prepare': prepare, 'freeze': freeze, 'compile': b.compile_one, 'link': b.link}[sys.argv[1]]()
