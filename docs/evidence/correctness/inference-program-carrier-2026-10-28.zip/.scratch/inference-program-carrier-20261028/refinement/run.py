"""Six single-use functional processes. Parser repair never reruns a process."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('program_carrier_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
E4 = R / '.scratch/inference-mtp-e4-20261028/fixture'
LOGITS_PARSER = R / '.scratch/inference-mtp-logits-20261028/refinement/run.py'
E4_PARSER = R / '.scratch/inference-mtp-e4-20261028/validation/run.py'
ARMS = {'carrier-cpu': ('cpu', '--program-carrier', None),
    'carrier-cuda': ('cuda', '--program-carrier', None),
    'logits-cpu': ('cpu', '--mtp-logits', PLAIN),
    'logits-cuda': ('cuda', '--mtp-logits', PLAIN),
    'e4-cpu': ('cpu', '--mtp-e4', E4),
    'preflight-cpu': ('cpu', '--logits-preflight', PLAIN)}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


def prepare():
    b.b.prepared()
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', parser=t.pin(W / 'run.py'),
        plain_fixture=t.pin(PLAIN / 'weights.tsv'), e4_fixture=t.pin(E4 / 'weights.tsv'),
        logits_parser=t.pin(LOGITS_PARSER), e4_parser=t.pin(E4_PARSER),
        order=list(ARMS), arms={arm: dict(backend=backend, flag=flag,
            fixture=str(fixture) if fixture else None, output=str(W / 'runs' / arm))
            for arm, (backend, flag, fixture) in ARMS.items()},
        actual_processes_planned=6, model_processes_planned=4,
        carrier_processes_have_no_Model_or_fixture=True,
        policy='Root executes each arm once; first failure stops. Existing stdout can only be parsed offline, never overwritten or rerun automatically.'))
    print('RUN PLAN ONLY: carrier CPU/CUDA, logits CPU/CUDA, E4 CPU, preflight CPU')


def carrier_report(reports, backend):
    assert len(reports) == 1
    report = reports[0]
    assert (report['status'], report['case'], report['backend']) == ('PASS', 'program-carrier', backend)
    assert (report['models'], report['native_submissions'], report['carriers']) == (0, 2, 2)
    for field in ('cold_failure_atomic', 'independent_fixed_bindings', 'real_completion_retirement',
                  'GraphOutput_pin_preserved', 'closed_handle_not_reused', 'teardown_handoff_irreversible'):
        assert report[field] is True, field
    assert type(report['pending_observed']) is bool
    return report


def parse(arm):
    backend, flag, _ = ARMS[arm]; out = W / 'runs' / arm
    process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if flag == '--program-carrier': report = carrier_report(reports, backend)
    elif flag == '--mtp-e4': report = module(E4_PARSER, 'carrier_e4_parser').e4_report(reports, backend)
    else:
        original = module(LOGITS_PARSER, 'carrier_logits_parser')
        report = original.modifiers_report(reports, backend) if flag == '--mtp-logits' else original.preflight_report(reports)
    t.save(out / 'report.json', report)
    t.save(out / 'summary.json', dict(status='PASS', arm=arm, backend=backend,
        process=process, report=t.pin(out / 'report.json'),
        source_freeze=t.pin(W / 'source-freeze.json'), performance_claim=False))
    print('PASS', arm, 'PID', process['pid'])


def run(arm):
    backend, flag, fixture = ARMS[arm]
    b.validate(); plan = t.read(W / 'run-plan.json')
    for field in ('parser', 'plain_fixture', 'e4_fixture', 'logits_parser', 'e4_parser'): t.exact(plan[field])
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image']); t.exact(ready['inputs'])
    native = t.read(W / 'runtime-plan.json')['native']; t.exact(native)
    original, alias = Path(native['path']), W / 'bin' / Path(native['path']).name
    if not alias.exists(): os.link(original, alias)
    assert os.path.samefile(original, alias)
    out = W / 'runs' / arm
    assert not out.exists(), 'Already attempted: parse existing output instead of rerunning'
    args = [ready['image']['path'], '--' + backend]
    if fixture: args.append(str(fixture))
    args.append(flag)
    process = t.execute(args, out, 300)
    t.save(out / 'as-run.json', dict(ready=t.pin(W / 'ready-tiny.json'), image=ready['image'],
        inputs=ready['inputs'], source_freeze=ready['source_freeze'], run_plan=t.pin(W / 'run-plan.json'),
        environment=t.pin(W / 'environment.json'), runtime_source=native,
        runtime_alias=str(alias), same_file=True, process=process))
    parse(arm)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
