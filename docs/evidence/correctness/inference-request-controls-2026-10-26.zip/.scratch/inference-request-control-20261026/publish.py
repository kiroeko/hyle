"""One compact explicit publication from existing results; no builds or runs."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-request-driver-20261026'
FIXED = R/'.scratch/inference-working-state-20261026/consumer-cases'
C = W/'consumer-cases'
DEST = R/'docs/evidence/correctness/inference-request-controls-2026-10-26'
BASELINE = 'a6afaafd4'
SOURCES = ('include/hyle/compute/paged_arena.h', 'src/compute_batch/paged_arena.cc',
    'tests/compute_batch/paged_arena_test.cc', 'tests/compute_batch/row_cache_paged_test.cc',
    'engine/inference/request_loop.h', 'engine/inference/request_window.h',
    'engine/inference/request_progress.h', 'engine/inference/retirement_observation.h',
    'engine/models/qwen35/main.cc', 'tests/tools/qwen_request_control_case.h',
    'tests/tools/inference_request_loop_test.cc', 'tests/tools/qwen_request_lifecycle_test.cc', 'tests/CMakeLists.txt')


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def encode(v): return (json.dumps(v, indent=2, ensure_ascii=False)+'\n').encode('utf8')
def pin(p):
    p = Path(p); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    assert sys.argv[1:] == ['publish']
    files = {}
    def add(p):
        p = Path(p)
        assert p.is_file() and p.is_relative_to(R), str(p)
        assert p.suffix.lower() in {'.h', '.cc', '.py', '.json', '.log', '.txt', '.ids', '.schedule', '.tsv'}
        assert p.stat().st_size < 2_000_000, str(p)
        files[p.relative_to(R).as_posix()] = p
    def stage(base):
        for f in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(base/f)
    def run(base, stdout='stdout.log'):
        for f in ('process.json', stdout, 'stderr.log'): add(base/f)
    for f in SOURCES: add(R/f)
    for f in ('publish.py', 'arena.py', 'build.py', 'cpu.py', 'cpu2.py', 'host.py', 'build-summary.json',
              'request-control-consumer.cc', 'request-control-consumer2.cc', 'cpu2-adaptation.json',
              'run-check.py', 'run-models.py', 'plan.json', 'ready.json', 'runtime.json',
              'reused-report-abi.json', 'link-inputs-before.json', 'source-freeze.json'): add(W/f)
    stage(W/'compile'); stage(W/'link')
    for target in ('cpu', 'cpu2', 'host'):
        for f in ('plan.json', 'ready.json', 'source-freeze.json'): add(W/target/f)
        stage(W/target/'compile'); stage(W/target/'link'); run(W/target/'run1')
    for target in ('cpu', 'cpu2'):
        for f in ('runtime.json', 'reused-report-abi.json'): add(W/target/f)
    add(W/'cpu2/link-inputs-before.json')
    for f in ('plan.json', 'ready.json', 'runtime.json', 'source-freeze.json', 'link-inputs.json'): add(W/'arena'/f)
    for name in ('implementation', 'paged-test', 'row-test', 'link'): stage(W/'arena'/name)
    run(W/'arena/run1')
    for f in ('prepare.py', 'compare.py', 'manifest.json', 'comparisons.json', 'tracehashes.json', 'process-summary.json'): add(C/f)
    for mode in ('ordinary-candidate', 'mtp-k1-candidate'):
        run(C/'runs'/mode, 'stdout.json')
        run(B/'consumer-cases/runs'/mode, 'stdout.json')
    for f in ('alice.initial.ids', 'alice.suffix.ids', 'alice.schedule', 'bob.initial.ids', 'bob.suffix.ids',
              'bob.schedule', 'empty.ids', 'sessions.tsv', 'input-v2-correction.json'): add(FIXED/f)
    add(B/'ready.json'); add(B/'runtime.json')
    model = read(C/'comparisons.json')
    cpu2 = read(W/'cpu2/ready.json')
    summary = dict(status='BOUNDED_REQUEST_CONTROLS_AND_PAGE_EXPORT_RESULTS', baseline_commit=BASELINE,
        publication_head=subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=R, check=True, capture_output=True, text=True).stdout.strip(),
        sources=[pin(R/f) for f in SOURCES],
        builds=dict(first_six_TUs=read(W/'build-summary.json'), seventh_TU=cpu2,
            adaptation=read(W/'cpu2-adaptation.json'), compiled_TUs_total=7,
            scope='One arena, two existing page tests, host, CUDA Model, CPU wrapper; only the CPU wrapper is compiled again after its test preparation-order fix. Shared arena compiled once, no archive rewrite or other SDK/native/provider/report/weight build.'),
        page_exports=dict(process=read(W/'arena/run1/process.json'), passed_tests=37,
            scope='Existing PagedArena and RowCachePaged GTests; cold linear export of selected initialized page prefixes. A cropped original sublease is a copy source, not automatic compatibility with arena.read.',
            limits='Host tests establish typed page/lease contracts; no GPU physical pending-copy execution or complete host-image swap is established.'),
        request_owner=dict(process=read(W/'host/run1/process.json'), passed_contract_groups=6,
            result=(W/'host/run1/stdout.log').read_text(encoding='utf8'),
            scope='Host identity, cancellation, delivery-credit/ACK and retirement-owner contracts; explicit test retirement facts do not prove native device completion.'),
        tiny_CPU=dict(first_attempt=read(W/'cpu/run1/process.json'), final_process=read(W/'cpu2/run1/process.json'),
            result=read(W/'cpu2/run1/stdout.log'),
            scope='Actual tiny untrained A/H64 ordinary Model: cancel A after real submission, keep B original candidate, withhold A ledger/history publication, retain final output/key until ACK, do not block a peer on another unACKed request, release four keys with three cancellations, final live versions zero.',
            limits=['The first process failed before actual evaluate because the test prepared a width1 carrier before all width plans. Only case preparation order changed; CPU2 records the successful rerun.',
                'Finite owner/publication checks do not prove complete target/draft byte equivalence, GPU physical pending-copy behavior or trained-model quality.']),
        original_Qwen35_2B=dict(processes=read(C/'process-summary.json'), comparisons=model,
            tracehashes=pin(C/'tracehashes.json'),
            scope='Original BF16 V2 cached 335 roles, ordinary/K1, two sessions x three turns: two new CUDA candidates versus reused observed RequestLoop controls; 55 explicit clock/rate fields excluded, 78 ordinary and 68 K1 trace files equal.',
            existing_recompute_fact=model['important_existing_fact']),
        preserved_failure=dict(receipt=pin(W/'cpu/run1/process.json'), stderr=pin(W/'cpu/run1/stderr.log'),
            case_source_pin_before=next(row for row in read(W/'cpu/source-freeze.json')
                if row['path'].replace('\\', '/').endswith('tests/tools/qwen_request_control_case.h')),
            correction=pin(W/'cpu2-adaptation.json')),
        not_implemented=['Complete byte-preserving session HostImage swap', 'Native indexed GDN path',
            'Eliminating existing KV reframe/export work', 'Execution overlap'],
        limits=['No new throughput/speedup, full model-quality, cross-platform or GPU physical-pending claim.',
            'The archived canonical CPU case is the corrected CPU2 source. CPU1 dependency pins and its failure are preserved; no already-passing arena/host/CUDA test was rerun after this two-line case fix.',
            'The lifecycle --request-control route is source-wired; its separate canonical executable was not built/run here. The real case was compiled through the private CPU wrapper.',
            'Decision traces do not establish complete KV/GDN/conv/hidden byte equality or checkpoint-alias immutability.',
            'Only explicit small sources, recipes, process/output logs and input/hash metadata are archived. No EXE/OBJ/PDB/DLL/LIB/SDK/model-weight/fulltrace payload or dependency-directory walk.'])
    manifest = [pin(p)|{'entry':name} for name,p in files.items()]
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    DEST.parent.mkdir(parents=True, exist_ok=True)
    patch = subprocess.run(['git', 'diff', BASELINE, '--', *SOURCES], cwd=R, check=True, capture_output=True).stdout
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name,p in files.items(): out.write(p, name)
        out.writestr('manifest.json', encode(manifest)); out.writestr('changed-sources.txt', patch)
    summary['archive'] = pin(DEST.with_suffix('.zip'))
    assert summary['archive']['bytes'] < 2_000_000
    with DEST.with_suffix('.json').open('xb') as out: out.write(encode(summary))
    print(json.dumps(dict(summary=pin(DEST.with_suffix('.json')), archive=summary['archive'], files=len(files))))


if __name__ == '__main__': main()
