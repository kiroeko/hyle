"""Offline, exact comparison against two retained observed controls.

python -B compare.py write | check
No model/build/process/download; no timing rank, tolerance or seed search.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import sys

D = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest)


def exact(record):
    assert pin(record['path']) == record, record['path']


def non_time(value, removed, path='$'):
    if isinstance(value, list):
        return [non_time(item, removed, f'{path}[{i}]') for i, item in enumerate(value)]
    if not isinstance(value, dict):
        return value
    result = {}
    for key, item in value.items():
        if key == 'seconds' or key.endswith('_seconds') or key.endswith('tokens_per_second'):
            removed.append(path + '.' + key)
        else:
            result[key] = non_time(item, removed, path + '.' + key)
    return result


def differences(a, b, path='$'):
    if type(a) is not type(b):
        return [dict(path=path, baseline=a, candidate=b, reason='JSON type')]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                result.append(dict(path=path + '.' + key, baseline_present=key in a, candidate_present=key in b))
            else:
                result.extend(differences(a[key], b[key], path + '.' + key))
        return result
    if isinstance(a, list):
        result = [] if len(a) == len(b) else [dict(path=path, baseline_length=len(a), candidate_length=len(b))]
        for i, (x, y) in enumerate(zip(a, b)):
            result.extend(differences(x, y, f'{path}[{i}]'))
        return result
    return [] if a == b else [dict(path=path, baseline=a, candidate=b)]


def inventory(folder):
    folder = Path(folder)
    return {path.relative_to(folder).as_posix(): pin(path)
            for path in sorted(folder.rglob('*')) if path.is_file()}


def coverage(raw):
    assert raw['session_count'] == 2 and raw['turn_count'] == 6
    assert raw['restore_count'] == raw['idle_evictions'] == raw['pending_flushed_tokens'] == 4
    assert raw['generated_tokens'] == 18 and raw['max_sessions'] == raw['active_sequences'] == 1
    rows, details = [], []
    for session in raw['sessions']:
        result = session['result']
        assert len(result['turns']) == 3 and len(result['generated_ids']) == 9
        assert result['visible_tokens'] == 25 and session['restore_count'] == 2
        assert [turn['new_user_tokens'] for turn in result['turns']] == [15, 0, 2]
        assert [turn['pending_flushed'] for turn in result['turns']] == [0, 1, 1]
        rows.extend(record for record in session['ledger'] if record['generation'])
        details.append(dict(session_id=session['session_id'], generated_ids=result['generated_ids'],
            turn_count=3, visible_tokens=result['visible_tokens'], restore_count=session['restore_count'],
            sampling_stream=result['sampling_stream'], sampling_draw_cursor=result['sampling_draw_cursor'],
            draft_frontier=result.get('draft_frontier'), draft_lag=result.get('draft_lag'),
            ledger_records=len(session['ledger']), decision_changes=result.get('decision_changes', [])))
    double = [row for row in rows if row['verified_rows'] == 2]
    selected = Counter(row['accepted'] for row in double)
    return dict(sessions=details, turns=6, outputs=18, restores=raw['restore_count'],
        idle_evictions=raw['idle_evictions'], pending_flushed=raw['pending_flushed_tokens'],
        generation_ledger_records=len(rows), double_token_verifications=len(double),
        selected_prefix_rows={str(key): value for key, value in sorted(selected.items())},
        accepted_proposal_rounds=sum(row['consumed_drafts'] > 0 for row in double),
        rejected_proposal_rounds=sum(row['consumed_drafts'] == 0 for row in double),
        draft_rounds=raw.get('draft_rounds', 0), consumed_drafts=raw.get('consumed_drafts', 0),
        normalized_lag_rows=raw.get('normalized_lag_rows', 0),
        recomputed_decision_changes=raw['recomputed_decision_changes'])


def compare():
    manifest = read(D / 'manifest.json')
    for field in ['source_manifest', 'input_source']:
        exact(manifest[field])
    for record in manifest['fixed_files']:
        exact(record)
    for field in ['reference_comparisons', 'reference_trace_inventory', 'original_V1_rejection']:
        exact(manifest['comparison'][field])
    ready_path = manifest['candidate']['ready_path']
    ready = read(ready_path)
    for field in ['image', 'runtime', 'source', 'source_freeze', 'actual_dependencies']:
        exact(ready[field])
    assert ready['image']['path'] == manifest['candidate']['path']
    assert ready['runtime']['path'] == manifest['candidate']['runtime_path']
    assert ready['baseline'] == manifest['baseline']
    references = read(manifest['comparison']['reference_comparisons']['path'])
    old_traces = read(manifest['comparison']['reference_trace_inventory']['path'])
    cases = {case['id']: case for case in manifest['cases']}
    pairs, trace_pairs, processes = [], [], []
    for mode in ['ordinary', 'mtp-k1']:
        control, candidate = cases[mode + '-baseline'], cases[mode + '-candidate']
        reports = []
        for case in [control, candidate]:
            process = read(case['process_record'])
            assert process['exit'] == 0 and not process['timeout']
            assert process['command'] == case['argv']
            assert process['input_source'] == manifest['input_source']
            if case is control:
                assert process['image'] == manifest['baseline']
                for field in ['process', 'stdout', 'stderr']:
                    exact(control['observed'][field])
                assert process['pid'] == control['observed']['pid']
            else:
                assert process['image'] == ready['image']
            lines = Path(case['stdout']).read_text(encoding='utf-8').strip().splitlines()
            assert len(lines) == 1, 'Complete original one-object stdout required'
            reports.append(json.loads(lines[0]))
            processes.append(dict(id=case['id'], reused_observed_control=(case is control),
                pid=process['pid'], exit=process['exit'], timeout=False, seconds=process['seconds'],
                process=pin(case['process_record']), stdout=pin(case['stdout']),
                stderr=pin(case['stderr']), image=process['image']))
        removed_a, removed_b = [], []
        a = non_time(reports[0], removed_a)
        b = non_time(reports[1], removed_b)
        assert removed_a == control['observed']['ignored_time_rate_paths'] and len(removed_a) == 55
        diff = differences(a, b)
        if removed_a != removed_b:
            diff.append(dict(path='$time_rate_path_presence', baseline=removed_a, candidate=removed_b))
        normalized_hash = hashlib.sha256(canonical(a)).hexdigest()
        reference = next(pair for pair in references['pairs'] if pair['mode'] == mode)
        assert normalized_hash == control['observed']['non_time_report_sha256'] == reference['normalized_baseline_report_sha256']
        x, y = inventory(control['trace']), inventory(candidate['trace'])
        trace_diff = [name for name in sorted(set(x) | set(y)) if name not in x or name not in y or
            (x[name]['bytes'], x[name]['sha256']) != (y[name]['bytes'], y[name]['sha256'])]
        rows = [[name, x[name]['bytes'], x[name]['sha256']] for name in x]
        inventory_hash = hashlib.sha256(canonical(rows)).hexdigest()
        original_trace = next(pair for pair in old_traces['pairs'] if pair['mode'] == mode)
        assert inventory_hash == control['observed']['trace_inventory_sha256'] == original_trace['inventory_sha256']
        assert len(x) == control['observed']['trace_file_count'] == {'ordinary': 78, 'mtp-k1': 68}[mode]
        facts_a, facts_b = coverage(reports[0]), coverage(reports[1])
        if mode == 'mtp-k1':
            assert facts_a['accepted_proposal_rounds'] == 4 and facts_a['rejected_proposal_rounds'] == 2
            assert facts_a['double_token_verifications'] == 6 and facts_a['recomputed_decision_changes'] == 3
        trace_pairs.append(dict(mode=mode, all_file_inventories_equal=not trace_diff,
            baseline_root=control['trace'], candidate_root=candidate['trace'],
            inventory_columns=['relative_path', 'bytes', 'sha256_baseline'], inventory=rows,
            inventory_sha256=inventory_hash, differences=trace_diff))
        pairs.append(dict(mode=mode, status='PASS' if not diff and not trace_diff else 'FAIL',
            all_non_time_JSON_equal=not diff, normalized_baseline_report_sha256=normalized_hash,
            ignored_time_rate_paths=removed_a, ignored_resource_or_path_fields=[],
            non_time_differences=diff, trace_file_count=len(x),
            trace_bytes_per_arm=sum(row['bytes'] for row in x.values()), trace_differences=trace_diff,
            coverage_equal=facts_a == facts_b, baseline_coverage=facts_a, candidate_coverage=facts_b))
    report = dict(status='PASS' if all(pair['status'] == 'PASS' for pair in pairs) else 'FAIL',
        method='Exact complete recursive JSON type/value/presence excluding only enumerated clocks/rates; no resource/path exclusions. Independently hash every trace file in both arms.',
        manifest=pin(D / 'manifest.json'), analyzer=pin(__file__), ready=pin(ready_path), pairs=pairs,
        important_existing_fact=manifest['comparison']['existing_MTP_decision_changes'], limits=manifest['limits'])
    hashes = dict(status='PASS' if all(pair['all_file_inventories_equal'] for pair in trace_pairs) else 'FAIL',
        pairs=trace_pairs, payload_policy='Only shared hash/length inventory; no full hidden/logits buffers packaged.')
    summary = dict(status='TWO_REUSED_CONTROLS_PLUS_TWO_CANDIDATES_OBSERVED_EXIT0', processes=processes,
        new_model_processes=2, reused_observed_model_processes=2, additional_analyzer_model_runs=0,
        original_V1_rejection=manifest['comparison']['original_V1_rejection'])
    return {'comparisons.json': report, 'tracehashes.json': hashes, 'process-summary.json': summary}


if __name__ == '__main__':
    assert sys.argv[1:] in [['write'], ['check']], __doc__
    output = compare()
    for name, value in output.items():
        if sys.argv[1:] == ['write']:
            with (D / name).open('x', encoding='utf-8', newline='\n') as stream:
                json.dump(value, stream, ensure_ascii=False, separators=(',', ':'))
                stream.write('\n')
        else:
            assert read(D / name) == value, name
    print(json.dumps(dict(status=output['comparisons.json']['status'], files=[pin(D / name) for name in output]), indent=2))
