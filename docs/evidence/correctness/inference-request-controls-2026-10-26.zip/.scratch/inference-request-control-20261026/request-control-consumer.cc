#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_request_control_case.h"
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("usage: request-control-consumer INPUTS");return qwen_request_control_case::run(argv[1]);}catch(const std::exception&e){std::cerr<<"request_control_consumer_failure="<<e.what()<<"\n";return 1;}}
