"""Explicit request-driver host contract build; never runs the test.

After root source freeze: host.py plan tests/tools/TEST.cc; host.py build.
No source is created or compiled by default. Reuses existing hyle_error only;
its COFF undefineds are CRT/C++ runtime plus the Kernel32 message conversions.
"""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('request_driver_build', W/'build.py')
product = importlib.util.module_from_spec(spec)
spec.loader.exec_module(product)
b = product.b
H = W/'host'
RECIPE = R/'.scratch/inference-request-driver-20261026/host/compile/command.json'


def plan(source):
    assert not (H/'plan.json').exists(), 'Preserve each source-frozen attempt'
    source = (R/source).resolve()
    assert source.is_file() and source.is_relative_to(R/'tests/tools')
    frozen = b.quoted_project_closure([source])
    b.save(H/'source-freeze.json', frozen)
    command = b.compile_command(RECIPE, source, H/'compile')
    linker = str(Path(command[0]).with_name('link.exe'))
    error = next(x for x in b.read(product.B/'link-inputs.json')
                 if b.key(x['path']).endswith('\\hyle_error.lib'))
    b.exact(error)
    b.save(H/'plan.json', dict(status='HOST_CONTRACT_FROZEN_NOT_BUILT_OR_RUN',
        source=b.pin(source), recipe=b.pin(RECIPE), source_freeze=b.pin(H/'source-freeze.json'),
        reused_libraries=[error], system_libraries=['kernel32.lib'],
        library_boundary='Existing hyle_error COFF inspection: only CRT/C++/Kernel32 undefineds; no Hyle platform/mem or SDK dependency.',
        command=command, link_command=[linker, '/NOLOGO', '/INCREMENTAL:NO', '/OPT:REF', '/OPT:ICF',
            str(H/'compile/unit.obj'), error['path'], 'kernel32.lib', '/OUT:'+str(H/'link/request-control-test.exe')],
        scope='One host request-owner contract TU; retained hyle_error plus CRT/Kernel32, no library/native/SDK build or consumer run.'))
    print('REQUEST_CONTROL_HOST_PLAN', json.dumps(b.pin(H/'plan.json')), flush=True)


def build():
    assert not (H/'compile').exists() and not (H/'ready.json').exists()
    unit = b.read(H/'plan.json')
    for field in ('source', 'recipe', 'source_freeze'): b.exact(unit[field])
    for row in unit['reused_libraries']: b.exact(row)
    frozen = b.read(unit['source_freeze']['path'])
    for row in frozen: b.exact(row)
    h = b.helper()
    compiler = unit['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(unit['command'], env, H/'compile', timeout=60)
    dep = b.read(H/'compile/dependencies.json')['Data']
    actual = [b.pin(x) for x in dict.fromkeys([dep['Source'], *dep['Includes']])]
    by_key = {b.key(x['path']): x for x in frozen}
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
            assert b.key(path) in by_key and row['sha256'] == by_key[b.key(path)]['sha256'], str(path)
    for row in frozen: b.exact(row)
    b.save(H/'actual-dependencies.json', actual)
    linked = h.execute(unit['link_command'], env, H/'link', timeout=60)
    b.save(H/'ready.json', dict(status='REQUEST_CONTROL_HOST_BUILT_NOT_RUN',
        image=b.pin(H/'link/request-control-test.exe'), source=unit['source'],
        source_freeze=unit['source_freeze'], actual_dependencies=b.pin(H/'actual-dependencies.json'),
        plan=b.pin(H/'plan.json'), compile=compiled, link=linked,
        reused_libraries=unit['reused_libraries'], system_libraries=unit['system_libraries'],
        compiled_TUs=1, Model_GPU_SDK_builds=0, consumer_runs=0, scope=unit['scope']))
    print('REQUEST_CONTROL_HOST_READY', json.dumps(b.pin(H/'ready.json')), flush=True)


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == 'plan': plan(Path(sys.argv[2]))
    elif sys.argv[1:] == ['build']: build()
    else: print('Prepared only. After root source freeze: python -B '+str(__file__)+' plan tests/tools/TEST.cc | build')
