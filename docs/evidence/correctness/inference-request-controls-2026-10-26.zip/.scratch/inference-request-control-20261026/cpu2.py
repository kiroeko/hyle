"""Explicit tiny actual-Model CPU wrapper build after root SOURCE_FROZEN.

python -B cpu.py plan tests/tools/CASE.h case_namespace
python -B cpu.py build
No default plan/build/run. One TU replaces the old E4 wrapper, whose former
separate entry object was already removed by the successful retained recipe.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
C = W/'cpu2'
B = R/'.scratch/inference-request-driver-20261026/cpu'
FIXTURE = R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
spec = importlib.util.spec_from_file_location('request_driver_build', W/'build.py')
product = importlib.util.module_from_spec(spec)
spec.loader.exec_module(product)
b = product.b


def plan(case, namespace):
    assert not (C/'plan.json').exists(), 'Preserve each source-frozen attempt'
    ready = b.read(B/'ready.json')
    b.exact(ready['image']); b.exact(ready['runtime']); b.exact(ready['link_inputs'])
    inputs = b.read(ready['link_inputs']['path'])
    old = ready['object']  # Deleted old Model wrapper object, not a retained input.
    assert len(inputs) == 221 and sum(b.key(x['path']) == b.key(old['path']) for x in inputs) == 1
    for row in inputs:
        if b.key(row['path']) != b.key(old['path']): b.exact(row)
    shared = product.shared_arena(inputs)
    report = b.read(B.parent/'reused-report-abi.json')
    count = product.check_report(report)
    assert any(x == report['report'] for x in inputs)
    b.save(C/'reused-report-abi.json', report | dict(checked_current_dependencies=count))
    case = (R/case).resolve()
    assert case.is_file() and case.is_relative_to(R/'tests/tools')
    assert namespace.replace('_', '').isalnum() and not namespace[0].isdigit()
    source = W/'request-control-consumer2.cc'
    text = '#include "engine/models/qwen35/main.cc"\n#include "'+case.relative_to(R).as_posix()+'"\n'
    text += 'int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("usage: request-control-consumer INPUTS");return '+namespace+'::run(argv[1]);}catch(const std::exception&e){std::cerr<<"request_control_consumer_failure="<<e.what()<<"\\n";return 1;}}\n'
    if source.exists(): assert source.read_text(encoding='utf8') == text
    else: source.write_text(text, encoding='utf8')
    seeds = [R/'engine/models/qwen35/main.cc', case]
    frozen = b.quoted_project_closure(seeds)
    b.save(C/'source-freeze.json', frozen)
    command = b.compile_command(B/'compile/command.json', source, C/'compile')
    for flag in ('/DHYLE_COMPUTE_CPU=1', '/DHYLE_COMPUTE_GGML_CPU=1', '/DHYLE_COMPUTE_ONEDNN=1'):
        assert flag in command
    b.save(C/'link-inputs-before.json', inputs)
    b.save(C/'plan.json', dict(status='CPU_REQUEST_CONTROL_SOURCE_FROZEN_NOT_BUILT_OR_RUN',
        source=b.pin(source), source_freeze=b.pin(C/'source-freeze.json'),
        baseline_ready=b.pin(B/'ready.json'), baseline_image=ready['image'], runtime=ready['runtime'],
        recipe=b.pin(B/'compile/command.json'), link_recipe=b.pin(B/'link/command.json'), command=command,
        inputs=b.pin(C/'link-inputs-before.json'), replaced_object=old,
        reused_report_abi=b.pin(C/'reused-report-abi.json'), image_path=str(C/'link/request-control-consumer.exe'),
        fixture_manifest=b.pin(FIXTURE/'weights.tsv'),
        run=[str(C/'link/request-control-consumer.exe'), str(FIXTURE)],
        compiled_TUs=1, unchanged_inputs=219, shared_arena=shared,
        limits=['One actual canonical Model plus request-control case included through a private wrapper; preserved CPU macros and original closure.',
                'The retained CPU closure has 221 total inputs: one replaced Model wrapper, one shared replacement arena and 219 unchanged inputs. No separate driver main is reintroduced.',
                'Existing cached untrained A/H64/FFN128/V64 fixture; not a trained-model quality or performance comparison.',
                'Build/link only; separately compiled canonical arena is shared, with no additional SDK, native/provider, report or weight compilation/copy and no consumer execution.']))
    print('CPU_REQUEST_CONTROL_PLAN', json.dumps(b.pin(C/'plan.json')), flush=True)


def build():
    assert not (C/'compile').exists() and not (C/'ready.json').exists()
    unit = b.read(C/'plan.json')
    for field in ('source', 'source_freeze', 'baseline_ready', 'baseline_image', 'runtime', 'recipe',
                  'link_recipe', 'inputs', 'reused_report_abi', 'fixture_manifest'):
        b.exact(unit[field])
    product.check_report(b.read(unit['reused_report_abi']['path']))
    b.exact(unit['shared_arena']['ready']); b.exact(unit['shared_arena']['object'])
    frozen = b.read(unit['source_freeze']['path'])
    for row in frozen: b.exact(row)
    inputs = b.read(unit['inputs']['path'])
    for row in inputs:
        if b.key(row['path']) != b.key(unit['replaced_object']['path']): b.exact(row)
    h = b.helper()
    compiler = unit['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(unit['command'], env, C/'compile', timeout=120)
    dep = b.read(C/'compile/dependencies.json')['Data']
    actual = [b.pin(x) for x in dict.fromkeys([dep['Source'], *dep['Includes']])]
    by_key = {b.key(x['path']): x for x in [*frozen, unit['source']]}
    for row in actual:
        path = Path(row['path'])
        if (path.is_relative_to(R) and not path.is_relative_to(R/'.scratch')) or b.key(path) == b.key(unit['source']['path']):
            assert b.key(path) in by_key and row['sha256'] == by_key[b.key(path)]['sha256'], str(path)
    for row in frozen: b.exact(row)
    b.save(C/'actual-dependencies.json', actual)
    obj = b.pin(C/'compile/unit.obj')
    command, replaced, arena_replaced = [], 0, 0
    for arg in b.read(unit['link_recipe']['path'])['command']:
        if b.key(arg) == b.key(unit['replaced_object']['path']): arg = obj['path']; replaced += 1
        elif b.key(arg) == b.key(unit['shared_arena']['replaces']['path']): arg = unit['shared_arena']['object']['path']; arena_replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+unit['image_path']
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(C/'link/request-control-consumer.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(C/'link/request-control-consumer.lib')
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    assert replaced == arena_replaced == 1
    linked = h.execute(command, env, C/'link', timeout=120)
    final = [obj if b.key(x['path']) == b.key(unit['replaced_object']['path']) else unit['shared_arena']['object'] if b.key(x['path']) == b.key(unit['shared_arena']['replaces']['path']) else x for x in inputs]
    for row in final: b.exact(row)
    b.save(C/'link-inputs.json', final)
    runtime = b.read(unit['runtime']['path'])
    b.exact(runtime['native'])
    alias = C/'link'/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = b.pin(alias)
    b.save(C/'runtime.json', runtime)
    b.save(C/'ready.json', dict(status='CPU_REQUEST_CONTROL_BUILT_NOT_RUN',
        image=b.pin(unit['image_path']), runtime=b.pin(C/'runtime.json'), link_inputs=b.pin(C/'link-inputs.json'),
        source=unit['source'], source_freeze=unit['source_freeze'], actual_dependencies=b.pin(C/'actual-dependencies.json'),
        plan=b.pin(C/'plan.json'), baseline=unit['baseline_image'], object=obj, compile=compiled, link=linked,
        run=unit['run'], fixture_manifest=unit['fixture_manifest'],
        compiled_TUs=1, unchanged_inputs=219, shared_arena=unit['shared_arena'], additional_SDK_native_provider_report_builds=0, consumer_runs=0,
        limits=unit['limits']))
    print('CPU_REQUEST_CONTROL_READY', json.dumps(b.pin(C/'ready.json')), flush=True)


if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == 'plan': plan(Path(sys.argv[2]), sys.argv[3])
    elif sys.argv[1:] == ['build']: build()
    else: print('Prepared only. After root SOURCE_FROZEN: python -B '+str(__file__)+' plan tests/tools/CASE.h case_namespace | build')
