from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

work = Path(__file__).resolve().parent
root = work.parents[1]
kind = sys.argv[1]
assert kind in ('arena', 'host', 'cpu', 'cpu2')
ready = json.loads((work / kind / 'ready.json').read_text())
image = ready['image']
assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
command = [image['path']]
env = os.environ.copy()
if 'runtime' in ready:
    runtime = json.loads(Path(ready['runtime']['path']).read_text())
    env.update(runtime.get('configured_flags', {}))
    env['PATH'] = str(Path(image['path']).parent) + ';' + runtime['PATH']
if kind == 'arena':
    command.append('--gtest_filter=PagedArena.*:RowCachePaged.*')
elif kind in ('cpu', 'cpu2'):
    command.append(str(root / '.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'))
env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
folder = work / kind / 'run1'
folder.mkdir()
start = time.perf_counter()
with (folder / 'stdout.log').open('xb') as out, (folder / 'stderr.log').open('xb') as err:
    child = subprocess.Popen(command, cwd=root, env=env, stdout=out, stderr=err,
                             creationflags=subprocess.CREATE_NO_WINDOW)
    print(kind, 'native_pid', child.pid, flush=True)
    timeout = False
    try:
        code = child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        timeout = True
        child.kill()
        code = child.wait(timeout=10)
result = dict(pid=child.pid, exit=code, timeout=timeout, seconds=time.perf_counter() - start,
              command=command, image=image)
(folder / 'process.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
print((folder / 'stdout.log').read_text())
print((folder / 'stderr.log').read_text())
assert code == 0 and not timeout, 'Preserve the actual first failure'
