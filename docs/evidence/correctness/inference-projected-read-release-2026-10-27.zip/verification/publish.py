"""Publish the bounded projected-read release checks, including rejected test assumptions."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import zipfile
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R/'docs/evidence/correctness'
NAME = 'inference-projected-read-release-2026-10-27'
SOURCES = ['src/graph/resources.cc','include/hyle/graph/detail/region_access.h',
           'tests/graph/region_provider_test.cc','tests/graph/invocation_unbind_test.cc']

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def pin(path):
    data = path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

summary = read(W/'summary.json')
ready = read(W/'ready3.json')
assert summary['status']=='ELEVEN_TARGETED_GRAPH_TESTS_PASS'
assert summary['process']['exit']==0 and len(summary['tests'])==11
assert read(W/'compile/test/process.json')['exit']==2
assert read(W/'run1/process.json')['exit']==1
frozen = {x['path'].casefold(): x for x in read(W/'source-freeze3.json')}
sources = [pin(R/name) for name in SOURCES]
for item in sources:
    assert item['sha256']==frozen[item['path'].casefold()]['sha256']
    assert (R/Path(item['path'])).read_bytes()==(W/'source-attempt3'/Path(item['path']).relative_to(R)).read_bytes()
entries = [(R/name,'source-final/'+name) for name in SOURCES]
entries += [(W/'source-attempt1'/name,'source-attempt1/'+name) for name in SOURCES[:3]]
entries += [(W/'source-attempt2'/name,'source-attempt2/'+name) for name in SOURCES]
files = ['build.py','retry.py','publish.py','fix-traces.py','fix-observation-expectation.py',
         'plan.json','plan2.json','plan3.json','canonical-recipes.json','canonical-recipes2.json',
         'canonical-recipes3.json','source-freeze.json','source-freeze2.json','source-freeze3.json',
         'ready2.json','ready3.json','runtime2.json','runtime3.json','link2-inputs.json','link3-inputs.json',
         'results.xml','results2.xml','summary.json']
for folder in ['compile/resources','compile/test','compile2/test','compile2/unbind','compile3/test']:
    files += [folder+'/'+name for name in ['command.json','process.json','stdout.log','stderr.log']]
    for name in ['dependencies.json','actual-dependencies.json']:
        if (W/folder/name).exists():
            files.append(folder+'/'+name)
for folder in ['link2','link3','run1','run2']:
    files += [folder+'/'+name for name in ['command.json','process.json','stdout.log','stderr.log']]
entries += [(W/name,'verification/'+name) for name in files]
assert len(set(dest for _,dest in entries))==len(entries)
for source,_ in entries:
    assert source.is_file(),str(source)
manifest = [dict(archive_path=dest,**pin(source)) for source,dest in entries]
DEST.mkdir(parents=True,exist_ok=True)
archive,receipt = DEST/(NAME+'.zip'),DEST/(NAME+'.json')
assert not archive.exists() and not receipt.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for source,dest in entries:
        output.write(source,dest)
    output.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for item in manifest:
        assert hashlib.sha256(check.read(item['archive_path'])).hexdigest()==item['sha256']
result = dict(status='ELEVEN_TARGETED_GRAPH_TESTS_PASS',recorded_at=datetime.now().astimezone().isoformat(),
    task='Withdraw one ready projected input after actual retirement without resetting other Graph bindings.',
    API='detail::RegionAccess::release_read_projection(Invocation&,ValueId) noexcept',
    changes=[
        'The new narrow entry and original caller unbind share the existing native input closure, complete native validation and reverse binding-release sequence.',
        'Withdraw only the nominated ready projected input and its anonymous page guards; reject pending inputs, foreign values, unrelated configuration/caller ports, and repeated withdrawal.',
        'Clear all concrete transparent aliases of that input and mark the external alias index dirty. Other fixed bindings and resource payload/source owners remain installed.',
        'Use the original outcome plus preparation gate. Actually retired failed/closed invocations can release their original ready guards without reopening execution or source admission.',
        'Keep a recording only with the exact selected reader permission-change proof and actual backend stable-binding identity; otherwise invalidate before dropping guards. General inspected ReadProjection has no invented preservation proof.'
    ],
    final_sources=sources,
    verification=dict(tests=summary['tests'],process=summary['process'],unique_TUs=3,
        compiled_sources=['src/graph/resources.cc','tests/graph/region_provider_test.cc','tests/graph/invocation_unbind_test.cc'],
        actual_compile_attempts=5,actual_link_attempts=2,test_processes=2,
        first_resources_object_reused=True,final_unbind_object_reused=True,
        cached_link_input_count=138,compiler='MSVC 14.50 x64 /O2 /W4 /WX',
        final_ready=pin(W/'ready3.json'),final_summary=pin(W/'summary.json')),
    retained_failures=[
        dict(stage='First region test compilation',process=read(W/'compile/test/process.json'),
            cause='Two SCOPED_TRACE macros on the same source line expanded to the same generated variable name.',
            correction='Split the macros onto separate lines. Reuse the passing resources object; no product change.'),
        dict(stage='First 11-test execution',process=read(W/'run1/process.json'),passed=9,failed=2,
            cause='Two new test paths incorrectly expected a completed wait to retain the Completion observation while the wrapper remained alive. The original successful wait already retires that use; an independent live GraphOutput still blocks withdrawal.',
            correction='Correct only these test expectations to the original Completion contract. Recompile only region_provider_test.cc, reuse resources and unbind objects, and run the same 11 tests once. No product gate was weakened.')
    ],
    scope=[
        'Four new ready-read release contracts, four original neighboring projection contracts, and three original InvocationUnbind contracts in one final Windows host GTest process.',
        'Real original Graph/LeasePool/Invocation/Queue/Completion and prepared test artifact paths; asynchronous/capture behavior uses the existing original mock backend, not a new executor.',
        'The checks cover guard-to-writer recovery, unrelated bindings, pending/wrong/double rejection, live GraphOutput and running gates, actual terminal failed/closed cleanup, transparent aliases, and both recording qualifications.'
    ],
    not_claimed=[
        'No model inference, native GPU/Apple/Vulkan execution, real device failure injection, SDK/native rebuild, network download, full Graph suite or performance conclusion.',
        'The first observed failures were test implementation/expectation errors; they do not demonstrate a product Completion-retirement defect.',
        'This batch provides an internal resource-release capability. The future indexed-state kernels and engine integration are separate work.'
    ],archive=pin(archive),archive_entries=len(manifest)+1)
receipt.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(receipt=pin(receipt),archive=pin(archive),sources=sources),indent=2))
