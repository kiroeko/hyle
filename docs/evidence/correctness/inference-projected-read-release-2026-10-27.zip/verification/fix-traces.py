from pathlib import Path
R = Path(__file__).resolve().parents[2]
path = R/'tests/graph/region_provider_test.cc'
data = path.read_bytes()
old = b'    SCOPED_TRACE(qualifiers.first); SCOPED_TRACE(qualifiers.second);'
new = b'    SCOPED_TRACE(qualifiers.first);\r\n    SCOPED_TRACE(qualifiers.second);'
assert data.count(old) == 1
assert b'\r\n' in data
path.write_bytes(data.replace(old,new))
print('Split same-line ScopedTrace macros; original failed source already retained.')
