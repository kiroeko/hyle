"""Two incremental Graph TUs and nine selected host contracts; reuse the fused-writer closure."""
from pathlib import Path
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R/'.scratch/inference-fused-writer-20261026'
BASE = OLD/'empty-rejection-final'
spec = importlib.util.spec_from_file_location('fused_writer', OLD/'build.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
d.W = W
b, m = d.b, d.m
FILTER = ('GraphRouteBoundary.ProjectedReadRelease*:'
          'GraphRouteBoundary.ProjectedWrite*:GraphRouteBoundary.ProjectedRegion*:'
          'GraphRouteBoundary.ProjectedInput*:'
          'GraphRegions.OwnedNativeInputsKeepFirstCoveringPermissionAcrossRetryAndRebind')
EXPECTED = d.EXPECTED | {
    'ProjectedReadReleaseKeepsOtherBindingsAndRejectsPending',
    'ProjectedReadReleaseClearsTransparentAliasViews',
    'ProjectedReadReleaseRequiresActualRetirementAndRecoversTerminalSlots',
    'ProjectedReadReleasePreservesOnlyDoublyQualifiedRecordings',
    'OwnedNativeInputsKeepFirstCoveringPermissionAcrossRetryAndRebind',
}
SOURCES = ['src/graph/resources.cc', 'include/hyle/graph/detail/region_access.h',
           'tests/graph/region_provider_test.cc']
PINS = ['2b656725d339f395bfad97800a1101f8dc0040a2fc5819848067c3a2dc8f4314',
        '0e76e728941927c6fc49ff02d2b49cd790ce3125d8fd9f5da79ad9f94ea88018',
        '5ac2b9905f1b726f3193a48ff71d72bb322053ab6a4306c1c7cd35d0b4f731c1']

def plan():
    assert not (W/'plan.json').exists()
    ready = b.read(BASE/'ready.json')
    inputs = b.read(ready['inputs']['path'])
    assert len(inputs) == 137
    for row in inputs:
        b.exact(row)
    recipe = BASE/'compile/test/command.json'
    units = []
    for name, source, before in [
        ('resources', SOURCES[0], OLD/'compile/resources/unit.obj'),
        ('test', SOURCES[2], BASE/'compile/test/unit.obj')]:
        assert sum(b.key(row['path']) == b.key(before) for row in inputs) == 1
        command = m.command(recipe, R/source, W/'compile'/name)
        units.append(dict(name=name, source=b.pin(R/source), recipe=b.pin(recipe),
                          before=b.pin(before), command=command))
    for name, digest in zip(SOURCES, PINS):
        assert b.pin(R/name)['sha256'] == digest, name
        dest = W/'source-attempt1'/name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((R/name).read_bytes())
    canonical = W/'canonical-recipes.json'
    b.save(canonical, dict(command=[x for unit in units for x in unit['command']]))
    b.save(W/'source-freeze.json', m.c.closure([u['source']['path'] for u in units], [canonical]))
    b.save(W/'plan.json', dict(status='FROZEN_NOT_BUILT', units=units,
        source_freeze=b.pin(W/'source-freeze.json'),
        baseline=dict(ready=b.pin(BASE/'ready.json'), command=b.pin(BASE/'link/command.json'),
                      inputs=ready['inputs'], runtime=ready['runtime']),
        final_sources=[b.pin(R/name) for name in SOURCES],
        compiled_TUs=2, reused_inputs=135, images=1,
        filter=FILTER, expected_tests=sorted(EXPECTED),
        scope='Eight targeted projected-write/read Graph host tests plus one existing actual native input lease/retry/rebinding contract. The extra test does not directly call Invocation::unbind; no third TU is compiled.',
        model_runs=0, SDK_native_builds=0, HTTP=0))
    print('PLAN READY', flush=True)

def build():
    d.build()
    ready = b.read(W/'ready.json')
    runtime = b.read(ready['runtime']['path'])
    b.exact(runtime['native'])
    alias = Path(ready['image']['path']).parent/Path(runtime['native']['path']).name
    assert not alias.exists()
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = b.pin(alias)
    assert runtime['native_hardlink']['sha256'] == runtime['native']['sha256']
    b.save(W/'runtime-ready.json', runtime)

def run():
    p, ready = b.read(W/'plan.json'), b.read(W/'ready.json')
    b.exact(ready['image'])
    h, env = d.environment(p)
    env['PATH'] = b.read(W/'runtime-ready.json')['PATH']
    xml = W/'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter='+FILTER, '--gtest_output=xml:'+str(xml)], env, W/'run1', timeout=90)
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    assert {x.attrib['name'] for x in cases} == EXPECTED
    assert all(x.attrib['status'] == 'run' and not list(x) for x in cases)
    b.save(W/'summary.json', dict(status='NINE_TARGETED_GRAPH_TESTS_PASS',
        process=process, ready=b.pin(W/'ready.json'), results=b.pin(xml),
        tests=[x.attrib for x in cases], compiled_TUs=2,
        runtime=b.pin(W/'runtime-ready.json'), scope=p['scope'],
        model_runs=0, SDK_native_builds=0, HTTP=0))
    print('NINE TESTS PASS', flush=True)

if __name__ == '__main__':
    {'plan': plan, 'build': build, 'run': run}[sys.argv[1]]()
