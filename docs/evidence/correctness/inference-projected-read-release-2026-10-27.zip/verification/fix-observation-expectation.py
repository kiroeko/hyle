from pathlib import Path
R = Path(__file__).resolve().parents[2]
path = R/'tests/graph/region_provider_test.cc'
data = path.read_bytes().replace(b'\r\n', b'\n')
old = b'''  EXPECT_TRUE(Access::release_read_projection(run, bank).IsUnavailable());
  completion = {};
  ASSERT_TRUE(Access::release_read_projection(run, bank).ok());
'''
new = b'''  // wait() already retires the Completion's original use. Its wrapper can
  // stay alive; only the independent GraphOutput above delayed withdrawal.
  ASSERT_TRUE(Access::release_read_projection(run, bank).ok());
  completion = {};
'''
assert data.count(old) == 1
data = data.replace(old,new)
old = b'''    EXPECT_EQ(terminal.IsInternal(), failed);
    EXPECT_TRUE(Access::release_read_projection(run, logical.input).IsUnavailable());
    completion = {};
'''
new = b'''    EXPECT_EQ(terminal.IsInternal(), failed);
    completion = {};
'''
assert data.count(old) == 1
path.write_bytes(data.replace(old,new).replace(b'\n', b'\r\n'))
print('Align assertions with original Completion wait retirement contract; product unchanged.')
