"""Reuse the passing resources object; compile corrected region test and original unbind test."""
from pathlib import Path
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('read_release', W/'build.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
b, m, R = d.b, d.m, d.R
FILTER = ('GraphRouteBoundary.ProjectedReadRelease*:'
    'GraphRouteBoundary.ProjectedWrite*:GraphRouteBoundary.ProjectedRegion*:'
    'GraphRouteBoundary.ProjectedInput*:'
    'InvocationUnbind.OwnedPortsReleaseTheirActualPoolsAndKeepOtherBindings:'
    'InvocationUnbind.InvalidTailLeavesEarlierPortsAndPreparationUnchanged:'
    'InvocationUnbind.CompletionAndResultRetirementGatesRemainRequired')
EXPECTED = d.EXPECTED - {'OwnedNativeInputsKeepFirstCoveringPermissionAcrossRetryAndRebind'} | {
    'OwnedPortsReleaseTheirActualPoolsAndKeepOtherBindings',
    'InvalidTailLeavesEarlierPortsAndPreparationUnchanged',
    'CompletionAndResultRetirementGatesRemainRequired'}

def plan():
    assert not (W/'plan2.json').exists()
    previous = b.read(W/'plan.json')
    core = previous['units'][0]
    b.exact(core['source'])
    assert b.read(W/'compile/resources/process.json')['exit'] == 0
    for row in b.read(W/'compile/resources/actual-dependencies.json'):
        b.exact(row)
    units = []
    recipe = d.BASE/'compile/test/command.json'
    for name, source in [('test','tests/graph/region_provider_test.cc'),
                         ('unbind','tests/graph/invocation_unbind_test.cc')]:
        units.append(dict(name=name, source=b.pin(R/source), recipe=b.pin(recipe),
            command=m.command(recipe, R/source, W/'compile2'/name)))
    b.save(W/'canonical-recipes2.json', dict(command=[x for unit in units for x in unit['command']]))
    b.save(W/'source-freeze2.json', m.c.closure([str(R/'src/graph/resources.cc'),
        *[u['source']['path'] for u in units]], [W/'canonical-recipes2.json']))
    for name in [*d.SOURCES, 'tests/graph/invocation_unbind_test.cc']:
        dest = W/'source-attempt2'/name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((R/name).read_bytes())
    b.save(W/'plan2.json', dict(status='CORRECTED_TEST_AND_ACTUAL_UNBIND_SCOPE', units=units,
        source_freeze=b.pin(W/'source-freeze2.json'),
        baseline=previous['baseline'], old_units=previous['units'],
        reused_resources=dict(source=core['source'], object=b.pin(W/'compile/resources/unit.obj')),
        previous_plan=b.pin(W/'plan.json'), actual_new_compiles=2,
        actual_new_images=1, unique_changed_TUs=3,
        filter=FILTER, expected_tests=sorted(EXPECTED),
        correction='Split two SCOPED_TRACE macros that expanded to duplicate same-line names. Product code unchanged; reuse successful resources compile. Root expands finite scope to three existing InvocationUnbind tests in one additional TU, replacing the indirect native-input neighbor.'))
    print('PLAN2 READY', flush=True)

def plan3():
    assert not (W/'plan3.json').exists()
    p = b.read(W/'plan2.json')
    old = b.read(W/'ready2.json')
    for row in b.read(old['inputs']['path']):
        b.exact(row)
    for unit in p['units']:
        if unit['name'] == 'test':
            unit['source'] = b.pin(R/'tests/graph/region_provider_test.cc')
            unit['command'] = [arg.replace(str(W/'compile2/test'), str(W/'compile3/test')) for arg in unit['command']]
    b.save(W/'canonical-recipes3.json', dict(command=[x for unit in p['units'] for x in unit['command']]))
    b.save(W/'source-freeze3.json', m.c.closure([str(R/'src/graph/resources.cc'),
        *[u['source']['path'] for u in p['units']]], [W/'canonical-recipes3.json']))
    p.update(source_freeze=b.pin(W/'source-freeze3.json'), previous_plan=b.pin(W/'plan2.json'),
        correction='Tests now follow the original successful Completion observation contract: wait retires its use even while the wrapper remains; independent GraphOutput still blocks release. Product unchanged. Recompile only region test; reuse passing resources and InvocationUnbind objects.',
        actual_new_compiles=1)
    for name in [*d.SOURCES, 'tests/graph/invocation_unbind_test.cc']:
        dest = W/'source-attempt3'/name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((R/name).read_bytes())
    b.save(W/'plan3.json', p)
    print('PLAN3 READY',flush=True)

def build(third=False):
    p = b.read(W/('plan3.json' if third else 'plan2.json'))
    assert not (W/('compile3' if third else 'compile2')).exists()
    for row in b.read(p['source_freeze']['path']):
        b.exact(row)
    h, env = d.d.environment(p)
    objects, results = {}, []
    for unit in p['units']:
        reused = third and unit['name'] == 'unbind'
        out = W/('compile3' if third and unit['name']=='test' else 'compile2')/unit['name']
        if reused:
            process = b.read(out/'process.json')
            assert process['exit'] == 0
            assert b.read(out/'command.json')['command'] == unit['command']
            for row in b.read(out/'actual-dependencies.json'):
                b.exact(row)
        else:
            process = h.execute(unit['command'], env, out, timeout=180)
        dep = b.read(out/'dependencies.json')['Data']
        actual = [b.pin(q) for q in dict.fromkeys([dep['Source'], *dep['Includes']])]
        if not reused:
            b.save(out/'actual-dependencies.json', actual)
        own = {b.key(x['path']): x for x in b.read(p['source_freeze']['path'])}
        for row in actual:
            q = Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert row['sha256'] == own[b.key(q)]['sha256'], str(q)
        obj = b.pin(out/'unit.obj')
        objects[unit['name']] = obj
        results.append(dict(name=unit['name'], source=unit['source'], process=process, object=obj, reused_compile=reused))
        for row in b.read(p['source_freeze']['path']):
            b.exact(row)
    replace = {b.key(p['old_units'][0]['before']['path']): p['reused_resources']['object'],
               b.key(p['old_units'][1]['before']['path']): objects['test']}
    image = W/('link3' if third else 'link2')/'projected-read-release-test.exe'
    args, changed = [], 0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in replace:
            arg = replace[b.key(arg)]['path']; changed += 1
        elif arg.upper().startswith('/OUT:'):
            arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):
            arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed == 2
    args.append(objects['unbind']['path'])
    linked = h.execute(args, env, image.parent, timeout=120)
    inputs = [replace.get(b.key(x['path']),x) for x in b.read(p['baseline']['inputs']['path'])] + [objects['unbind']]
    assert len(inputs) == 138
    for row in inputs:
        b.exact(row)
    input_path = W/('link3-inputs.json' if third else 'link2-inputs.json')
    b.save(input_path, inputs)
    runtime = b.read(p['baseline']['runtime']['path'])
    b.exact(runtime['native'])
    alias = image.parent/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'],alias)
    runtime['native_hardlink'] = b.pin(alias)
    assert runtime['native_hardlink']['sha256'] == runtime['native']['sha256']
    runtime_path = W/('runtime3.json' if third else 'runtime2.json')
    b.save(runtime_path, runtime)
    b.save(W/('ready3.json' if third else 'ready2.json'),dict(status='BUILT_NOT_RUN', image=b.pin(image),
        compiled=results, reused_resources=p['reused_resources'], link=linked,
        inputs=b.pin(input_path), runtime=b.pin(runtime_path), plan=b.pin(W/('plan3.json' if third else 'plan2.json'))))
    print('READY3' if third else 'READY2',flush=True)

def run(third=False):
    p, ready = b.read(W/('plan3.json' if third else 'plan2.json')), b.read(W/('ready3.json' if third else 'ready2.json'))
    b.exact(ready['image'])
    h, env = d.d.environment(p)
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    xml = W/('results2.xml' if third else 'results.xml')
    process = h.execute([ready['image']['path'],'--gtest_color=no',
        '--gtest_filter='+FILTER,'--gtest_output=xml:'+str(xml)],env,W/('run2' if third else 'run1'),timeout=90)
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    assert {x.attrib['name'] for x in cases} == EXPECTED
    assert len(cases) == 11 and all(x.attrib['status']=='run' and not list(x) for x in cases)
    b.save(W/'summary.json',dict(status='ELEVEN_TARGETED_GRAPH_TESTS_PASS',
        process=process, tests=[x.attrib for x in cases], ready=b.pin(W/('ready3.json' if third else 'ready2.json')),
        results=b.pin(xml), unique_TUs=3, actual_compile_attempts=5 if third else 4,
        actual_link_attempts=2 if third else 1, test_processes=2 if third else 1,
        first_compile_failure=b.pin(W/'compile/test/process.json'),
        scope='Eight projection and three actual original InvocationUnbind host contracts. No model/native/SDK/full-suite/performance/network action.'))
    print('ELEVEN TESTS PASS',flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'plan3': plan3()
    elif sys.argv[1] == 'build3': build(third=True)
    elif sys.argv[1] == 'run2': run(third=True)
    else: {'plan':plan,'build':build,'run':run}[sys.argv[1]]()
