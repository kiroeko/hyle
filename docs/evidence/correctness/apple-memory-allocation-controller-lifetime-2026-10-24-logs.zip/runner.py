from pathlib import Path
import hashlib,json,subprocess,tarfile,time,shlex
O=Path("/Users/kiro/hyle-scratch/compute-unified/apple-memory-lifetime-20261024/attempt1")
with tarfile.open(O/'source.tar.gz')as t:
 for m in t.getmembers():
  p=Path(m.name)
  if not m.isfile()or p.is_absolute()or '..'in p.parts:raise RuntimeError('invalid source member')
 t.extractall(O)
p=json.loads((O/'plan.json').read_text())
def ident(path):
 path=Path(path);return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def execute(tag,cmd):
 folder=O/tag;folder.mkdir(exist_ok=True);(folder/'command.json').write_text(json.dumps(dict(command=cmd),indent=2));t=time.monotonic()
 with(folder/'stdout.log').open('w')as a,(folder/'stderr.log').open('w')as b:r=subprocess.run(cmd,stdout=a,stderr=b,cwd=O,timeout=180)
 (folder/'process.json').write_text(json.dumps(dict(exit=r.returncode,seconds=time.monotonic()-t),indent=2));print(tag,'exit',r.returncode,flush=True)
 if r.returncode:print((folder/'stderr.log').read_text()[-6000:]);print((folder/'stdout.log').read_text()[-3000:]);raise RuntimeError(tag)
for item in p['sources']:
 path=O/'source'/item['path'];assert ident(path)['sha256']==item['sha256']
for item in p['cached_objects']:
 assert ident(item['path'])==item,item['path']
for tag in ('memory','test'):execute('compile-'+tag,p['commands'][tag])
def relative(path):
 for marker,prefix in(('/include/hyle/','include/hyle/'),('/src/compute_route_apple/','src/compute_route_apple/'),('/src/compute/','src/compute/'),('/tests/compute_route_apple/','tests/compute_route_apple/')):
  if marker in str(path):return prefix+str(path).split(marker,1)[1]
 return None
facts=[];drifts=[]
for tag in ('memory','test'):
 text=(O/(tag+'.d')).read_text().replace(chr(92)+chr(10),' ');deps=shlex.split(text.split(':',1)[1])
 for path in deps:
  rel=relative(path)
  if not rel:continue
  record=ident(path);facts.append(dict(tag=tag,relative=rel,**record));expected=p['catalog'].get(rel)
  if rel.startswith('tests/'):expected=next(x['sha256']for x in p['sources']if x['path']==rel)
  if record['sha256']!=expected:drifts.append(record|dict(relative=rel,expected=expected))
(O/'actual-dependencies.json').write_text(json.dumps(dict(dependencies=facts,drifts=drifts),indent=2));assert not drifts,drifts
execute('link',p['commands']['link']);(O/'ready.json').write_text(json.dumps(dict(image=ident(O/'memory-lifetime'),objects=[ident(O/'memory.o'),ident(O/'test.o')],native_builds=0,SDK_builds=0,HTTP=0),indent=2))
execute('run',[str(O/'memory-lifetime'),'--gtest_filter=AppleMemoryLifetime.*','--gtest_output=json:'+str(O/'tests.json')]);print((O/'run/stdout.log').read_text())
