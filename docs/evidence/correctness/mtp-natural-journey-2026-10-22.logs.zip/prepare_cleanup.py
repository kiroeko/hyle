from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
entries = []
for attempt in (1, 2, 3):
    for path in sorted((S / f'tests-link{attempt}').glob('mtp-checks.*')):
        if path.suffix not in ('.exe', '.map'): continue
        raw = path.read_bytes()
        entries.append(dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
assert len(entries) == 6
plan = dict(keep=str(S / 'tests-link4'), entries=entries, bytes=sum(p['bytes'] for p in entries))
(S / 'cleanup-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
script = r'''$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/dspark-natural-journey-20261022').Path
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$prefix = $taskRoot.TrimEnd('\') + '\'
$keep = [System.IO.Path]::GetFullPath($plan.keep)
$targets = @($plan.entries)
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $targets) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if (-not $target.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside task root: $target" }
    if ((Split-Path -Parent $target) -eq $keep) { throw "Current image protected: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe', '.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
if (-not (Test-Path -LiteralPath (Join-Path $keep 'mtp-checks.exe') -PathType Leaf)) { throw 'Final image missing' }
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = $targets
    Bytes = $plan.bytes
    CurrentImageRetained = (Test-Path -LiteralPath (Join-Path $keep 'mtp-checks.exe'))
    CurrentMapRetained = (Test-Path -LiteralPath (Join-Path $keep 'mtp-checks.map'))
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object Bytes, CurrentImageRetained, CurrentMapRetained
'''
(R / 'test.ps1').write_text(script, encoding='utf-8')
print(json.dumps(plan, indent=2))
