from pathlib import Path
import hashlib,json,difflib,re
stage=Path('.scratch/dspark-natural-journey-20261022/state')
paths=['tests/compute_state/deepseek_sparse_prefix_fixture.h','tests/compute_state/dspark_accepted_prefix_fixture.h','tests/compute_state/dspark_prefix_consumer_test.cc']
files=[];patch=[]
for name in paths:
 p=Path(name);data=p.read_bytes();dest=stage/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 before=stage/'before'/name
 files.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest()})
 patch.extend(difflib.unified_diff(before.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
(stage/'changes.diff').write_text(''.join(patch))
# This is a finite arithmetic/source check only; no C++ consumer is executed.
for ratio,chunk,start,visible in [(4,4,2047,511),(128,64,2302,17)]:
 pos=start;fill=pos%chunk;total=0;seen=visible
 for rows in [2,1,6,0,1]:
  end=pos+rows
  seen+=end//ratio-pos//ratio
  fill=(fill+rows)%chunk;total+=rows;pos=end
  assert pos==start+total and fill==pos%chunk
  assert seen==visible+(pos//ratio-start//ratio)
head=Path(paths[1]).read_text();test=Path(paths[2]).read_text()
assert 'Result<c::StateVersion> finalize(' not in head
assert 'state.finalize(' not in test
assert 'state.advance(reference.back(), next.target, next.caught, 1,' in test
assert 'std::uint32_t target_frontier, draft_frontier' in head
report={'status':'source frozen; no build or native execution',
 'confirmed_issue':'Old finalize recomputed cursor/frontiers from initial mode.base_position, so using per-round accepted rows on a later head could rewind state metadata. Removed that method rather than preserving an ambiguous compatibility mode.',
 'interfaces':{'boundary':'CompleteState::boundary(const StateVersion&) -> Result<Boundary>',
 'advance':'CompleteState::advance(from,targetPrefix,catchup[3rings+carry],consumed_rows,pending) -> Result<StateVersion>',
 'token_features':'token_features(mode,count,first_position): Fragment with one I32[count] input; outputs in mode.tokens() order',
 'reference':'token_feature_reference(mode,span<const int32_t> ids,first_position): same-order vector<byte arrays>'},
 'semantics':{'frontier':'next unconsumed target position; fully caught-up state has target_frontier == draft_frontier == cursor.position',
 'carry':'verified main_x at frontier-1',
 'pending':'published next input token at frontier; new value comes from actual target scores or explicit external policy',
 'proposal':'main_position=frontier-1; draft positions=frontier..frontier+4',
 'acceptance':'k=1..6 consumed target inputs [pending,d1..d(k-1)]; matching proposal count k-1; k0 abort returns unchanged version',
 'catchup':'start at old frontier; only verified target main_x rows update3rings; preserve actual proposal main-KV ring outputs as catchup base; proposal-local dk never published',
 'advance':'relative to actual StateVersion; updates target visible/fill, both frontiers, total accepted-input count and pending before one StateDraft.finalize; retains original StateHead compare/publish contract'},
 'guards':['read actual schema-qualified metadata lease','fully-caught-up boundary proof','consumed rows0..6','positive pending for commit','uint32 frontier/total count overflow','compressed-cache capacity'],
 'old_prefix_tests':'All former finalize calls now use advance. Base->prefix passes k; sequential references and one-row continuation pass1. Original target math/oracles remain unchanged.',
 'finite_feature_adapter':'I32 actual ID -> exact F32 scale2^-18 -> finite dyadic per-column affine -> BF16 boundary. Compression positions use actual absolute positions. Untrained projected target boundary, not checkpoint embedding/full target.',
 'limits':['No C++ build/test execution by this agent','No full target decoder or trained original main_proj claim','BF16 finite affine map can collapse nearby IDs; it is an explicit synthetic projection, not token embedding fidelity','No new public MTP API/executor/owner or shadow persistent tensor state'],
 'source_only_arithmetic_check':'Two ratio modes across relative rows[2,1,6,0,1] preserve absolute cursor/visible/fill equations; not an actual C++ runtime test',
 'files':files}
(stage/'report.json').write_text(json.dumps(report,indent=2)+'\n')
freeze={'status':'frozen-source-only-no-build','files':files,'report_sha256':hashlib.sha256((stage/'report.json').read_bytes()).hexdigest(),'diff_sha256':hashlib.sha256((stage/'changes.diff').read_bytes()).hexdigest()}
(stage/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(freeze,indent=2))
