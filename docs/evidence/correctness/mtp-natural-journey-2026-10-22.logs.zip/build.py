"""Incremental host consumers on the matched AW CPU/CUDA closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AW = R / '.scratch/dspark-mtp-integration-20261022'
spec = importlib.util.spec_from_file_location('ax_cached', AW / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = AW / 'tests-link9'
RECIPE = R / '.scratch/qwen-capture-reuse-20261022/compile1/cuda-test/identity.json'
SOURCES = {
    'glm': R / 'tests/graph_route_cuda/glm_original_mtp_input_test.cc',
    'journey': R / 'tests/graph_route_cuda/dspark_journey_consumer_test.cc',
    'complete': R / 'tests/graph_route_cuda/dspark_complete_consumer_test.cc',
    'prefix': R / 'tests/compute_state/dspark_prefix_consumer_test.cc',
    'cast': R / 'src/compute_provider_native/cast.cc',
    'cast-test': R / 'tests/compute_provider_native/cast_test.cc',
}


def compile_one(tag, attempt):
    h.RECIPES[tag] = (R / '.scratch/architecture-refactor-2026-10-18/static-fp8-reference/common-cpu/checks/attempt1/cast-identity.json') if tag == 'cast' else RECIPE
    h.SOURCES[tag] = SOURCES[tag]
    h.compile_one(tag, attempt)


def latest(tag):
    paths = sorted(S.glob(f'compile*/{tag}/identity.json'),
                   key=lambda path: int(path.parents[1].name[7:]))
    assert paths, tag
    return paths[-1], c.read(paths[-1])


def link(tags, attempt):
    base = c.read(BASE / 'link-plan.json')
    # Retain the matched product/native closure, not the earlier test objects.
    remove = set()
    for identity in base['compiled_records']:
        record = c.read(identity['path'])
        if '/tests/' in record['source']['path'].replace('\\', '/'):
            remove.add(c.key(record['object']['path']))
    if 'cast' in tags:
        remove.add(c.key(R / '.scratch/architecture-refactor-2026-10-18/static-fp8-reference/common-cpu/checks/attempt1/cast.obj'))
    inputs = [item for item in base['inputs'] if c.key(item['path']) not in remove]
    command = [item for item in base['command'] if c.key(item) not in remove and
               not item.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    records, extra = [], []
    for tag in tags:
        path, record = latest(tag)
        assert all(b.identity(item['path']) == item for item in
                   [record['source'], record['object'], *record['dependencies']])
        extra.append(record['object'])
        records.append(b.identity(path))
    inputs = extra + inputs
    command[1:1] = [item['path'] for item in extra]
    assert all(b.identity(item['path']) == item for item in inputs)
    folder = S / f'tests-link{attempt}'
    folder.mkdir()
    (folder / 'tmp').mkdir()
    image = folder / 'mtp-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(folder / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=records, base=b.identity(BASE / 'link-plan.json'),
        SDK_builds=0, NVCC_builds=0, shader_builds=0))
    env, _ = b.environment(command, [item['path'] for item in inputs], folder)
    c.execute('link', command, env, folder)
    runtime = c.read(BASE / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        os.link(item['path'], folder / Path(item['path']).name)
    runtime['staged_dlls'] = [b.identity(path) for path in folder.glob('*.dll')]
    c.save(folder / 'runtime-environment.json', runtime)
    c.save(folder / 'ready.json', dict(image=b.identity(image)))
    print('LINKED', image, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('actions', nargs='+', choices=[*SOURCES, 'link'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--tags', nargs='+', choices=SOURCES, default=['glm'])
    args = parser.parse_args()
    for action in args.actions:
        if action == 'link': link(args.tags, args.attempt)
        else: compile_one(action, args.attempt)
