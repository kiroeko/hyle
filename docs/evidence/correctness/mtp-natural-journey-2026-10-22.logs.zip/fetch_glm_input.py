"""Fetch one pinned GLM NextN input component, never a whole model shard."""
from pathlib import Path
import hashlib
import json
import re
import struct
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
facts = json.loads((R / '.scratch/qwen-mtp-next-20261022/review/next-payload-inputs.json').read_text(encoding='utf-8'))['alternate_exact_input_projection']
repository = 'zai-org/GLM-5.3-Flash'
url = f"https://huggingface.co/{repository}/resolve/{facts['revision']}/{facts['shard']}"
folder = S / 'original-glm-input'
folder.mkdir(exist_ok=False)
receipt = dict(repository=repository, revision=facts['revision'], shard=facts['shard'],
               url=url, requests=[], roles=[], complete=False, whole_shard_allowed=False)


def save():
    (folder / 'acquisition.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


def fetch(first, last, destination):
    count = last - first + 1
    record = dict(first=first, last=last, bytes=count, complete=False)
    receipt['requests'].append(record)
    save()
    request = urllib.request.Request(url, headers={
        'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity',
        'User-Agent': 'hyle-pinned-original-input/1'})
    with urllib.request.urlopen(request, timeout=45) as response:
        content_range = response.headers.get('Content-Range', '')
        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', content_range)
        assert response.status == 206 and match and \
            (int(match[1]), int(match[2])) == (first, last), \
            'Refuse non-exact range/whole-shard response before reading body'
        total = int(match[3])
        if 'shard_bytes' in receipt:
            assert receipt['shard_bytes'] == total
        receipt['shard_bytes'] = total
        length = response.headers.get('Content-Length')
        assert length is None or int(length) == count
        record.update(http_status=response.status, content_range=content_range,
                      etag=response.headers.get('ETag'))
        remaining, digest = count, hashlib.sha256()
        with destination.open('xb') as output:
            while remaining:
                chunk = response.read(min(1 << 20, remaining))
                assert chunk, 'Truncated role range'
                output.write(chunk)
                digest.update(chunk)
                remaining -= len(chunk)
            assert not response.read(1), 'Response exceeds exact range'
    record.update(complete=True, path=str(destination), sha256=digest.hexdigest())
    save()
    return record


fetch(0, 7, folder / 'header-length.bin')
length = struct.unpack('<Q', (folder / 'header-length.bin').read_bytes())[0]
assert 2 <= length <= 8 << 20, 'Refuse unexpected huge header'
fetch(8, 7 + length, folder / 'header.json')
header = json.loads((folder / 'header.json').read_bytes())
receipt['data_start'] = 8 + length
for role in facts['roles']:
    actual = header[role['name']]
    assert actual['dtype'] == role['dtype'] and actual['shape'] == role['shape']
    assert actual['data_offsets'] == role['data_relative_offsets']
    first, end = actual['data_offsets']
    assert end - first == role['bytes']
    path = folder / (role['name'].rsplit('.', 2)[-2] + '.weight.bf16')
    record = fetch(receipt['data_start'] + first, receipt['data_start'] + end - 1, path)
    receipt['roles'].append(dict(name=role['name'], dtype=actual['dtype'], shape=actual['shape'],
        relative_offsets=actual['data_offsets'], payload=dict(path=str(path), bytes=role['bytes'], sha256=record['sha256'])))
    save()
    print(role['name'], record['sha256'], flush=True)
receipt['complete'] = True
save()
