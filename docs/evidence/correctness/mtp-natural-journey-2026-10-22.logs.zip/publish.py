"""Keep the finite implementation, exact inputs and actual outcomes; run nothing."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = R / 'docs/evidence/correctness/mtp-natural-journey-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

assert not OUT.exists() and not ZIP.exists()
final = read(S / 'checks4/summary.json')
assert final['process']['exit'] == 0 and not final['process']['timed_out']
assert final['tests'] == 13
assert not any(final[key] for key in ('failures','errors','disabled','skips'))
assert identity(final['image']['path'])['sha256'] == final['image']['sha256']
stdout = (S / 'checks4/stdout.log').read_text(encoding='utf-8')
rounds = [dict(ratio=int(a), round=int(b), matched_proposals=int(c), accepted_inputs=int(d),
               next_frontier=int(e), pending=int(f)) for a,b,c,d,e,f in re.findall(
    r'actual journey ratio(\d+) round(\d+) matched_proposals=(\d+) accepted_inputs=(\d+) next_frontier=(\d+) pending=(\d+)', stdout)]
assert len(rounds) == 4 and {(row['ratio'], row['round']) for row in rounds} == {(4,0),(4,1),(128,0),(128,1)}
files = [
    'src/compute_provider_native/cast.cc', 'include/hyle/compute/operation.h',
    'tests/compute_provider_native/cast_test.cc',
    'tests/graph_route_cuda/glm_original_mtp_input_test.cc',
    'tests/graph_route_cuda/dspark_journey_consumer_test.cc',
    'tests/graph_route_cuda/dspark_complete_consumer_test.cc',
    'tests/graph_route_cuda/dspark_cuda_consumer_fixture.h',
    'tests/graph_route_cuda/dspark_head_checks.h',
    'tests/graph_route_cuda/CMakeLists.txt',
    'tests/compute_models/original_role_input.h',
    'tests/compute_models/dspark_original_roles.h',
    'tests/compute_models/dspark_complete_graph_fixture.h',
    'tests/compute_state/deepseek_sparse_prefix_fixture.h',
    'tests/compute_state/dspark_accepted_prefix_fixture.h',
    'tests/compute_state/dspark_prefix_consumer_test.cc',
    'docs/user/compute.md', 'docs/developer/current-work.md',
    'docs/implementation/model-operators.md',
]
for name in files:
    target = S / 'source-current' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((R / name).read_bytes())
(S / 'cleanup-script.ps1').write_bytes((R / 'test.ps1').read_bytes())
report = dict(
    date='2026-10-22', status='FINITE_ORIGINAL_INPUT_AND_NATURAL_PROJECTED_JOURNEY_PASS', goal_complete=False,
    changes=[identity(R / name) for name in files], final_checks=final,
    original_glm_input=read(S / 'original-glm-input/acquisition.json'),
    prior_original_dspark_roles='docs/evidence/correctness/dspark-mtp-composition-2026-10-22.json',
    glm_scope='Three original layer45 BF16 roles: RMSNorm E/H, embedding-first concat and EH projection. One compiled CUDA graph, three submissions, independent local numerical oracles and old result leases. No original attention/MoE/head/full-model claim.',
    natural_journey=dict(rounds=rounds, proposal_cold_parameter_graphs=1, actual_full_shape_proposal_submissions=4,
        proposal='Flash H4096/heads64/D512, three stages, five proposals and full V129280; generated stage/LM/embedding bank, original W1/W2/confidence from previous fixed AW acquisition.',
        transfer='Original CopyBatchProgram/Invocation: CUDA to pinned then System for the CPU target, and reverse for published carry and main rings; real Completion and bounded pools.',
        target='Actual proposal I32 IDs feed ordinary token-feature Graph, then existing full compression/index/raw target component. Projected ports and finite untrained target/head/bridge; not original43layer target.',
        state='Natural greedy comparison consumes pending plus matching proposals. Relative advance starts committed metadata; proposal carry is T-1 and drafts begin at T. Complete target resources, three persistent main rings, carry and 28B metadata publish atomically. Second round reads actual StateHead. Independent single-row continuation and old full snapshots checked.',
        acceptance_limit='Measured natural outcomes apply to this untrained finite fixture only. Separate retained prefix cases cover accepted input counts0..6; no model acceptance-rate claim.'),
    native_cast=dict(direction='CPU Native I32 to F32 only, round-to-nearest ties-to-even, independent of ambient rounding mode',
        reason='The ordinary Graph exposed a real missing carrier: schema admitted this plain Cast, but all CPU candidates rejected it. Freeze only this safe direction and reuse original linear/scalar executor; other integer directions remain unsupported.',
        checks='Actual dense and odd byte strides, token IDs, positive/negative midpoint and int32 endpoints, repeated Invocation, alias rejection and unsupported reverse direction. Existing cast cases retained.'),
    artifact_binding_review=identity(S / 'review/remaining-artifact-bindings.json'),
    failures=[dict(folder='checks1', outcome='GLM test setup omitted owned ResourceOptions, fixed in the consumer only.'),
              dict(folder='checks3', outcome='Four pass; natural journey rejected at ordinary CPU I32 to F32 Cast. Product carrier and limited numerical contract fixed before final run.')],
    cleanup=read(S / 'cleanup-result.json'),
    performance='No new TPS or memory window. AV remains the current four-arm performance comparison.',
    remaining=['Selected original DSpark stage/LM role bindings and applicable complete-state compositions; the unexecuted full43layer target is a coverage limit, not an automatic requirement to build another production engine.',
               'Current Q27 embedded MTP, Q24 primary codec and GLM original FP8/quantized-role bindings; old sidecar or alternate codec consumers do not sign these.',
               'Other applicable actual artifact/state combinations and relevant platform checks. No new public executor, MTP loader or per-model production engine is implied.'],
    limitations=['Windows CPU/CUDA only for these new components; prior Qwen cross-platform evidence retains its own scope.',
                 'No whole-original-model or task-quality claim from finite generated stage/target parameters.',
                 'Numerical oracle gates unchanged; no forced provider route or host teacher token substitution.'],
    SDK_builds=0, NVCC_builds=0, shader_builds=0,
)
save(S / 'report-before-archive.json', report)
selected = [p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in
            {'.json','.py','.cc','.cpp','.h','.cuh','.md','.diff','.log','.xml','.txt','.ps1'} and
            '__pycache__' not in p.parts and 'tmp' not in p.parts]
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(selected): archive.write(path, path.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive: assert archive.testzip() is None
report['sources_commands_results_and_cleanup'] = identity(ZIP)
report['large_original_payloads_in_archive'] = False
save(OUT, report)
receipt = dict(result=identity(OUT), logs=identity(ZIP), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
