"""Run only the selected finite consumers; no TPS/memory benchmark."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location(
    'ax_run', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
parser = argparse.ArgumentParser()
parser.add_argument('--link-attempt', type=int, default=1)
parser.add_argument('--run-attempt', type=int, default=1)
parser.add_argument('--filter', default='*')
parser.add_argument('--expected-tests', required=True, type=int)
args = parser.parse_args()
folder = S / f'tests-link{args.link_attempt}'
image = h.read(folder / 'ready.json')['image']
assert h.ident(image['path']) == image
env = os.environ.copy()
env['PATH'] = h.read(folder / 'runtime-environment.json')['PATH']
env['HYLE_GLM_MTP_INPUT_DIR'] = str(S / 'original-glm-input')
env['HYLE_DSPARK_MARKOV_DIR'] = str(R / '.scratch/dspark-mtp-integration-20261022/original-markov')
env['HYLE_DSPARK_CONFIDENCE_BF16'] = str(R / '.scratch/qwen-mtp-next-20261022/original-confidence/conf_proj.weight.bf16')
out = S / f'checks{args.run_attempt}'
xml = out / 'results.xml'
command = [image['path'], '--gtest_filter=' + args.filter, '--gtest_output=xml:' + str(xml)]
print('START finite MTP components', flush=True)
process = h.execute(command, env, out, timeout=1200)
result = dict(process=process, image=image, throughput_evidence=False,
              whole_original_model=False)
if xml.is_file():
    root = ET.parse(xml).getroot()
    result.update(tests=int(root.attrib['tests']), failures=int(root.attrib['failures']),
        errors=int(root.attrib['errors']), disabled=int(root.attrib['disabled']),
        skips=sum(case.find('skipped') is not None for case in root.iter('testcase')),
        cases=[dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value']
              for p in case.iter('property')}) for case in root.iter('testcase')])
h.save(out / 'summary.json', result)
assert process['exit'] == 0 and not process['timed_out'], process
assert result.get('tests') == args.expected_tests, result
assert not any(result[key] for key in ['failures', 'errors', 'disabled', 'skips']), result
print('PASS finite consumers', result['tests'], flush=True)
