"""Acquire only seven pinned adjacent GLM NextN indexer tensor payloads."""
from pathlib import Path
import datetime
import hashlib
import json
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
PLAN = R / '.scratch/large-gguf-head-20261023/review/next-original-suppliers.json'
plan = json.loads(PLAN.read_text(encoding='utf-8'))['glm_flash']
header_path = R / plan['metadata']['actual_cached_header']['path']
header_bytes = header_path.read_bytes()
assert hashlib.sha256(header_bytes).hexdigest() == plan['metadata']['actual_cached_header']['sha256']
header = json.loads(header_bytes)
source = plan['identity']
group = plan['single_contiguous_payload']
first, last = group['range_inclusive']
assert last - first + 1 == group['bytes'] == 14943744
data_base = len(header_bytes) + 8
assert data_base == plan['metadata']['data_base']
expected = first
for role in plan['roles']:
    actual = header[role['name']]
    assert actual == dict(dtype=role['dtype'], shape=role['shape'], data_offsets=role['data_offsets'])
    begin, end = (data_base + value for value in actual['data_offsets'])
    assert begin == expected and [begin, end - 1] == role['absolute_range_inclusive']
    expected = end
assert expected == last + 1

out = S / 'original-indexer'
out.mkdir(exist_ok=True)
receipt = out / 'acquisition.json'
record = dict(repository=source['repository'], revision=source['revision'], file=source['file'],
    url=source['url'], file_bytes=source['file_bytes'], etag=source['etag'],
    data_base=data_base, source_header=dict(path=str(header_path.relative_to(R)),
        bytes=len(header_bytes), sha256=hashlib.sha256(header_bytes).hexdigest()),
    first=first, last=last, bytes=group['bytes'], complete=False, attempts=[], roles=[])
if receipt.exists():
    previous = json.loads(receipt.read_text(encoding='utf-8'))
    for key in ('repository', 'revision', 'file', 'etag', 'first', 'last', 'source_header'):
        assert previous[key] == record[key], key
    if previous['complete']:
        assert len(previous['roles']) == 7
        for role in previous['roles']:
            p = R / role['payload']['path']
            body = p.read_bytes()
            assert len(body) == role['payload']['bytes']
            assert hashlib.sha256(body).hexdigest() == role['payload']['sha256']
        print('REUSED authenticated original indexer payloads')
        raise SystemExit(0)
    record['attempts'] = previous['attempts']


def save():
    receipt.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


save()
request = urllib.request.Request(source['url'], headers={
    'Range': f'bytes={first}-{last}', 'If-Range': source['etag'],
    'Accept-Encoding': 'identity', 'User-Agent': 'hyle-pinned-original-role/1'})
observation = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), complete=False)
record['attempts'].append(observation)
save()
try:
    with urllib.request.urlopen(request, timeout=45) as response:
        assert response.status == 206, response.status
        assert response.headers.get('Content-Range') == group['content_range']
        assert response.headers.get('ETag') == source['etag']
        assert response.headers.get('Content-Length') in (None, str(group['bytes']))
        body = response.read(group['bytes'] + 1)
        assert len(body) == group['bytes'], len(body)
        observation.update(http_status=response.status,
            content_range=response.headers['Content-Range'], etag=response.headers['ETag'],
            content_length=response.headers.get('Content-Length'), complete=True)
except Exception as error:
    observation.update(error_type=type(error).__name__, error=str(error),
        finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    raise

for role in plan['roles']:
    begin, end = role['group_slice_offsets_half_open']
    payload = memoryview(body)[begin:end]
    name = role['name'].split('.indexer.', 1)[1] + '.bf16'
    path = out / name
    if path.exists():
        assert path.read_bytes() == payload
    else:
        with path.open('xb') as stream:
            stream.write(payload)
    record['roles'].append(dict(name=role['name'], dtype=role['dtype'], shape=role['shape'],
        data_relative_offsets=role['data_offsets'], first=role['absolute_range_inclusive'][0],
        last=role['absolute_range_inclusive'][1], payload=dict(path=str(path.relative_to(R)),
            bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())))
observation['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record.update(complete=True, group_sha256=hashlib.sha256(body).hexdigest(),
              downloaded_payload_bytes=len(body), whole_shard_downloaded=False)
save()
print(json.dumps(dict(roles=len(record['roles']), downloaded_payload_bytes=len(body),
    group_sha256=record['group_sha256'], payloads=[x['payload'] for x in record['roles']]), ensure_ascii=False))
