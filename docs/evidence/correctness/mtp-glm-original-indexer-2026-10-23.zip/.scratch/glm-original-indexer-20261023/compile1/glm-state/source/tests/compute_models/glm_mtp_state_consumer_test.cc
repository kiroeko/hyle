#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <functional>
#include <memory>
#include <limits>
#include <numeric>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "hyle/compute/resource_leases.h"
#include "hyle/compute/state_versions.h"
#include "hyle/compute/storage_owner.h"
#if defined(HYLE_TEST_GLM_STATE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#endif
#if defined(HYLE_TEST_GLM_STATE_CPU)
#include "hyle/graph/cpu.h"
#endif
#include "d5_glm_remaining_fragments.h"
#include "glm_mtp_target_component.h"
#include "glm_official_index_cache.h"
#include "glm_mtp_target43_component.h"
#include "glm_original_mtp_roles.h"
#include "glm_original_indexer_roles.h"
#include "glm_original_indexer_reference.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace glm = d5_glm_remaining_fragments;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace codec = glm_official_index_cache;
namespace original_prefix = glm_original_mtp_roles;
namespace original_index = glm_original_indexer_roles;
namespace index_reference = glm_original_indexer_reference;
using Bytes = std::vector<std::byte>;
using Value = sem::ValueId;
using Reference = std::function<std::vector<float>(std::span<const float>)>;
constexpr auto kModel = glm::kCases[4];
constexpr std::int64_t kHidden = 4096, kQueryRank = 1536, kLatent = 512;
constexpr std::int64_t kIndexDepth = 128, kIndexHeads = 32, kRing = 6;
constexpr std::int64_t kCapacity = 2060, kPoolCapacity = kCapacity / 4;
constexpr std::int32_t kBasePosition = 2055;
constexpr std::int64_t kIds = 2051, kSelected = 2048;
constexpr std::int64_t kJournalRows = 2;
static_assert(kIndexDepth == codec::kDepth && kIndexHeads == codec::kHeads);

// Generated GGUF/F32 projections and target boundaries with the fixed06992
// default UE8M0 index-cache/query arithmetic. Both raw key/score rings store
// BF16. Completed K4 pools persist only E4 codes and F32 power-of-two scales;
// pooling, normalized Hadamard and quantization use explicit BF16 boundaries.
// Projection diagnostics remain separate: these generated GGUF/Q8/F32 roles
// do not claim equality to original BF16 checkpoint projection operands.
// Whole NextN EH/MLA/MoE/hidden and all indexer state publish through one Head.
// Same-iteration reuse skips the ENTIRE indexer, retaining both encoded banks,
// BF16 raw rings and indexer cursors while MLA/hidden advance independently.
// The accepted nx journal supports exact catchup; normal draft-extend hands
// its actual last-accepted hidden/full IDs to next decode step0 without a new
// query. The target44 test adds KDA/conv/mHC state to that same atomic draft.
// This logical codec is not vendor page/footer ABI or a full original model.
// The separate original-supplier mode injects the fourteen pinned official HF
// layer45 input/query/indexer roles into the same complete state journey. Its
// declared target-hidden/embedding inputs are explicitly rounded to BF16;
// MLA/MoE/head and the finite initial history remain generated boundaries.
template<class T> T take(hyle::Result<T> result, const char *where) {
  if (!result) throw std::runtime_error(std::string(where) + ": " + std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status, const char *where) {
  if (!status.ok()) throw std::runtime_error(std::string(where) + ": " + std::string(status.message()));
}
c::ReadLease upload(const c::StorageOwner &owner, std::span<const std::byte> values) {
  auto buffer = take(m::Buffer::create(owner.ref(), values.size(), 256), "initial/parameter backing");
  check(buffer.view().write(values), "explicit initial/parameter bytes");
  return take(owner.adopt_buffer(std::move(buffer)), "qualified readonly initial value");
}
Bytes read(const c::ReadLease &lease) {
  Bytes result(lease.size());
  check(take(lease.view(), "readonly actual state").read(result), "actual state read"); return result;
}
template<class T> std::vector<T> typed(const c::ReadLease &lease) {
  if (lease.size() % sizeof(T)) throw std::runtime_error("state scalar extent");
  std::vector<T> result(lease.size() / sizeof(T));
  check(take(lease.view(), "actual typed state view").read(std::as_writable_bytes(std::span(result))), "typed state read");
  return result;
}
enum Entry : std::size_t {
  kCache, kRawKey, kRawGate, kPool, kPoolScales, kHiddenState, kQueryState, kPending,
  kMlaCursor, kIndexCursor, kPoolCount, kRingOffset, kTailValid, kTailStart,
  kSelection, kJournal, kLagCount, kEpoch, kEntries
};
constexpr std::size_t kResources = kEpoch;
std::array<c::TensorDesc, kResources> descriptions() {
  const auto scalar = sem::dense({1}, c::DataType::kInt32);
  return {sem::dense({kCapacity, kLatent}), sem::dense({kRing, kIndexDepth}, c::DataType::kBFloat16),
      sem::dense({kRing, kIndexDepth}, c::DataType::kBFloat16),
      sem::dense({kPoolCapacity, kIndexDepth}, c::DataType::kFloat8E4M3FN), sem::dense({kPoolCapacity, 1}),
      sem::dense({1, kHidden}), sem::dense({1, kQueryRank}), scalar, scalar,
      scalar, scalar, scalar, scalar, scalar, sem::dense({kIds}, c::DataType::kInt32),
      sem::dense({kJournalRows, kHidden}), scalar};
}
inline constexpr std::array<Entry, 13> kSparseEntries{kCache, kRawKey, kRawGate, kPool, kPoolScales,
    kQueryState, kMlaCursor, kIndexCursor, kPoolCount, kRingOffset, kTailValid, kTailStart, kSelection};
struct SparseState13 final {
  std::array<Value, kSparseEntries.size()> values;
  SparseState13() = delete;
  SparseState13(sem::Fragment &f, std::array<Value, kSparseEntries.size()> actual) : values(actual) {
    const auto desc = descriptions();
    for (std::size_t i = 0; i < values.size(); ++i) {
      if (values[i].ordinal() >= f.descriptions.size() || f.description(values[i]) != desc[kSparseEntries[i]])
        throw std::runtime_error("sparse attention requires all13 actual, correctly typed state values");
      for (std::size_t j = 0; j < i; ++j)
        if (values[i].ordinal() == values[j].ordinal()) throw std::runtime_error("independent sparse state slots share a graph identity");
    }
  }
  Value operator[](Entry entry) const {
    const auto found = std::find(kSparseEntries.begin(), kSparseEntries.end(), entry);
    if (found == kSparseEntries.end()) throw std::runtime_error("entry is not a sparse-attention state port");
    return values[std::size_t(found - kSparseEntries.begin())];
  }
};
SparseState13 sparse_state(sem::Fragment &f, const std::array<Value, kResources> &state) {
  return SparseState13(f, {state[kCache], state[kRawKey], state[kRawGate], state[kPool], state[kPoolScales],
      state[kQueryState], state[kMlaCursor], state[kIndexCursor], state[kPoolCount], state[kRingOffset],
      state[kTailValid], state[kTailStart], state[kSelection]});
}
struct SkipJournal final { Value rows, count; };
std::vector<float> embedding_values(std::int32_t token) {
  auto values = d5_gguf_test::activation(kHidden, 11 + 14 * token);
  for (auto &value : values) value = std::abs(value) + 0.5F;
  return values;
}
Value increment(sem::Fragment &f, Value old, std::int32_t delta = 1) {
  const auto amount = f.constant(sem::dense({1}, c::DataType::kInt32), sem::bytes(std::vector{delta}));
  const auto joined = f.one(c::Operation(c::Concat{.axis = 0}), {old, amount});
  const auto prefix = f.one(c::Operation(c::Scan{.axis = 0}), {joined});
  const auto last = f.constant(sem::dense({1}, c::DataType::kInt32), sem::bytes(std::vector<std::int32_t>{1}));
  return f.one(c::Operation(c::Gather{}), {prefix, last});
}
Value advance_ring(sem::Fragment &f, Value old, std::int32_t size) {
  std::vector<std::int32_t> values(std::size_t(size), 0);
  for (std::int32_t i = 0; i < size; ++i) values[std::size_t(i)] = (i + 1) % size;
  const auto table = f.constant(sem::dense({size}, c::DataType::kInt32), sem::bytes(values));
  return f.one(c::Operation(c::Gather{}), {table, old});
}
struct OriginalNextn final {
  original_prefix::Data prefix;
  original_index::Data indexer;
  std::array<original_index::ReadonlyRole, static_cast<std::size_t>(original_prefix::Parameter::kCount)> prefix_roles;
  original_index::Roles indexer_roles;
};
std::shared_ptr<const OriginalNextn> original_nextn(const std::filesystem::path &input,
    const std::filesystem::path &query, const std::filesystem::path &indexer,
    const c::StorageOwner &owner) {
  auto result = std::make_shared<OriginalNextn>();
  result->prefix = original_prefix::Data::load(input, query);
  result->indexer = original_index::Data::load(indexer);
  for (std::size_t i = 0; i < result->prefix_roles.size(); ++i) {
    const auto role = static_cast<original_prefix::Parameter>(i);
    result->prefix_roles[i] = {"original GLM NextN input/query", original_prefix::description(role), owner,
        upload(owner, original_prefix::payload(result->prefix, role))};
  }
  result->indexer_roles = original_index::bind(result->indexer, owner);
  return result;
}
struct External final { std::size_t constant; original_index::ReadonlyRole role; };
struct CodecPorts final { std::size_t codes = 0, scales = 0, rotated = 0, transformed = 0, input = 0; };
struct Recipe final {
  sem::Fragment fragment;
  std::shared_ptr<const OriginalNextn> original;
  std::vector<External> external;
  std::array<std::size_t, 7> original_prefix_ports{};
  std::size_t original_hidden = 0, original_embedding = 0, wk_accum = 0, wk_stored = 0;
  std::size_t index_query_accum = 0, index_query_stored = 0;
  std::array<std::size_t, kResources> state_ports;
  bool fresh = false;
  bool draft_extend = false;
  bool catchup = false, direct_catchup = false, cuda = false;
  std::int32_t position = kBasePosition, selected_tail = 0;
  glm::InputReference input_reference;
  Reference query_reference, absorbed_query_reference, latent_reference, key_reference, gate_reference;
  Reference index_query_reference, score_weight_reference, output_reference;
  glm::moe::MoeReference moe_reference;
  std::vector<float> input_scale, query_scale, ffn_scale, head_scale;
  std::size_t embedding, eh, nx, query, latent, attention, output, residual, ffn_input, ffn_output;
  std::size_t key = 0, raw_key = 0, gate = 0, raw_gate = 0, gate_projection = 0;
  std::size_t compressed = 0, index_query = 0, score_weight = 0, scores = 0;
  CodecPorts pool_codec, query_codec;
  std::array<std::size_t, glm_mtp_target43_component::Ports::count> target43_ports{};
  glm_mtp_target43_component::Reference target43_reference;
};
std::size_t expose(Recipe &r, Value value, bool copy = false) {
  if (copy) value = r.fragment.one(c::Operation(c::Copy{}), {value});
  const auto port = r.fragment.outputs.size(); r.fragment.outputs.push_back(value); return port;
}
Value external(Recipe &r, const original_index::ReadonlyRole &role) {
  const auto slot = r.fragment.constants.size();
  const auto value = r.fragment.constant(role.description, {});
  r.external.push_back({slot, role}); return value;
}
Value change(Recipe &r, Entry entry, Value value, bool copy = false) {
  r.state_ports[entry] = expose(r, value, copy); return value;
}
CodecPorts expose_codec(Recipe &r, const codec::Quantized &q) {
  return {expose(r, q.codes), expose(r, q.scale), expose(r, q.rotated),
      expose(r, q.transformed), expose(r, q.input, true)};
}
struct EncodedPool final { Value codes, scales; };
// The same ordinary indexer-history equations serve a fresh query and an
// explicit accepted-feature catchup. A skip recipe never calls this function.
EncodedPool append_history(Recipe &r, const SparseState13 &state,
                     Value nx, Value next_index_cursor, int role_offset = 0) {
  auto &f = r.fragment;
  Value key, raw_key, raw_gate;
  if (r.original) {
    if (role_offset != 0) throw std::runtime_error("original layer45 indexer cannot supply another layer");
    const auto rounded_nx = codec::cast(f, nx, c::DataType::kBFloat16);
    const auto &roles = r.original->indexer_roles;
    const auto wk = f.one(c::model_ops::bfloat_linear_f32(), {rounded_nx, external(r, roles[original_index::kKey])});
    r.wk_accum = expose(r, wk);
    const auto stored_wk = codec::cast(f, wk, c::DataType::kBFloat16); r.wk_stored = expose(r, stored_wk);
    key = f.one(c::Operation(c::LayerNorm{.epsilon = 1.0e-6F}),
        {codec::cast(f, stored_wk, c::DataType::kFloat32), external(r, roles[original_index::kNorm]),
         external(r, roles[original_index::kBias])});
    r.key = expose(r, key);
    raw_key = codec::cast(f, key, c::DataType::kBFloat16); r.raw_key = expose(r, raw_key);
    const auto gate_projection = f.one(c::model_ops::bfloat_linear_f32(),
        {rounded_nx, external(r, roles[original_index::kGate])});
    r.gate_projection = expose(r, gate_projection);
    raw_gate = codec::cast(f, gate_projection, c::DataType::kBFloat16); r.raw_gate = expose(r, raw_gate);
    r.gate = expose(r, codec::cast(f, raw_gate, c::DataType::kFloat32));
  } else {
  auto wk = glm::projection(f, nx, kIndexDepth, kHidden, 241 + role_offset, false);
  auto scale = sem::oracle::scale(kIndexDepth);
  std::vector<float> bias(kIndexDepth);
  for (std::int64_t d = 0; d < kIndexDepth; ++d) bias[std::size_t(d)] = float(d % 7 - 3) / 32.0F;
  const auto sw = f.constant(sem::dense({kIndexDepth}), sem::bytes(scale));
  const auto bw = f.constant(sem::dense({kIndexDepth}), sem::bytes(bias));
  key = f.one(c::Operation(c::LayerNorm{.epsilon = 1.0e-6F}), {wk.output, sw, bw});
  r.key = expose(r, key);
  raw_key = codec::cast(f, key, c::DataType::kBFloat16); r.raw_key = expose(r, raw_key);
  r.key_reference = [wk = std::move(wk), scale, bias](auto x) { return glm::layer_norm(wk.reference(x), scale, bias); };
  auto wg = glm::linear::projection(f, nx, kIndexDepth, kHidden, glm::linear::Storage::kQ8_0, 257 + role_offset);
  r.gate_projection = expose(r, wg.output);
  raw_gate = codec::cast(f, wg.output, c::DataType::kBFloat16); r.raw_gate = expose(r, raw_gate);
  const auto gate = codec::cast(f, raw_gate, c::DataType::kFloat32); r.gate = expose(r, gate);
  r.gate_reference = [wg = std::move(wg)](auto x) { return wg.reference(x); };
  }
  const auto keys = change(r, kRawKey, f.one(c::Operation(c::Scatter{}), {state[kRawKey], state[kRingOffset], raw_key}));
  const auto gates = change(r, kRawGate, f.one(c::Operation(c::Scatter{}), {state[kRawGate], state[kRingOffset], raw_gate}));
  EncodedPool pool{state[kPool], state[kPoolScales]};
  if (r.position % 4 == 3) {
    std::vector<std::int32_t> ring_rows(4);
    for (std::int32_t t = 0; t < 4; ++t) ring_rows[std::size_t(t)] = (r.position - 3 + t) % std::int32_t(kRing);
    const auto four = f.constant(sem::dense({1, 4}, c::DataType::kInt32), sem::bytes(ring_rows));
    const auto grouped_key = codec::cast(f, f.one(c::Operation(c::Gather{}), {keys, four}), c::DataType::kFloat32);
    const auto grouped_gate = codec::cast(f, f.one(c::Operation(c::Gather{}), {gates, four}), c::DataType::kFloat32);
    std::vector<float> ape(4 * kIndexDepth);
    for (std::size_t i = 0; i < ape.size(); ++i) ape[i] = float(int(i * 7 % 19) - 9) / 16.0F;
    const auto positional = r.original ? external(r, r.original->indexer_roles[original_index::kApe]) :
        f.constant(sem::dense({1, 4, kIndexDepth}), sem::bytes(ape));
    const auto logits = glm::binary(f, c::BinaryKind::kAdd, grouped_gate, positional);
    const auto rows = f.one(c::Operation(c::Copy{}), {glm::permute(f, logits, {0, 2, 1})});
    auto probability = f.one(c::Operation(c::Softmax{}), {glm::reshape(f, rows, {kIndexDepth, 4})});
    probability = f.one(c::Operation(c::Copy{}), {glm::permute(f, glm::reshape(f, probability, {1, kIndexDepth, 4}), {0, 2, 1})});
    const auto pooled = glm::reduce(f, glm::binary(f, c::BinaryKind::kMultiply, probability, grouped_key), 1);
    r.compressed = expose(r, pooled);
    const auto encoded = codec::quantize(f, codec::bfloat_boundary(f, pooled), 1);
    r.pool_codec = expose_codec(r, encoded);
    pool.codes = change(r, kPool, f.one(c::Operation(c::Scatter{}), {state[kPool], state[kPoolCount], encoded.codes}));
    pool.scales = change(r, kPoolScales, f.one(c::Operation(c::Scatter{}), {state[kPoolScales], state[kPoolCount], encoded.scale}));
    change(r, kPoolCount, increment(f, state[kPoolCount]));
    change(r, kTailStart, increment(f, state[kTailStart], 4));
  }
  change(r, kIndexCursor, next_index_cursor, true);
  change(r, kRingOffset, advance_ring(f, state[kRingOffset], kRing));
  change(r, kTailValid, advance_ring(f, state[kTailValid], 4));
  return pool;
}
// Pure shared Graph construction. nx and all13 state ports belong to this
// layer. Fixture role_offset affects immutable projection roles only; normal
// NextN always uses0. Target43 has no EH/pending/plain residual or skip journal.
Value append_sparse_attention(Recipe &r, const SparseState13 &state, Value nx,
                               int role_offset = 0, const SkipJournal *journal = nullptr,
                               const Value *original_qr = nullptr) {
  if (!r.fresh && !journal) throw std::runtime_error("indexer skip requires its actual NextN journal");
  auto &f = r.fragment;
  const auto publish = [&](Value value, bool copy = false) { return expose(r, value, copy); };
  const auto changed = [&](Entry entry, Value value, bool copy = false) { return change(r, entry, value, copy); };
  Value qr;
  if (r.original) {
    if (role_offset != 0 || !original_qr) throw std::runtime_error("original NextN query requires its same-Graph prefix");
    qr = changed(kQueryState, codec::cast(f, *original_qr, c::DataType::kFloat32));
  } else {
  auto qa = glm::projection(f, nx, kQueryRank, kHidden, 197 + role_offset, false);
  r.query_scale = sem::oracle::scale(kQueryRank);
  auto query_scale = r.query_scale;
  qr = changed(kQueryState, glm::norm(f, qa.output, query_scale));
  r.query_reference = [qa = std::move(qa), scale = r.query_scale](auto x) {
    return sem::oracle::rms_norm_rows(qa.reference(x), scale, kQueryRank, glm::kNormEpsilon);
  };
  }
  auto qb = glm::projection(f, qr, glm::kHeads * 256, kQueryRank, 199 + role_offset, false);
  const auto query_nope = glm::kimi::slice_heads(f, qb.output, glm::kHeads, 256, 0, 256);
  auto kb = glm::head_projection(f, query_nope, kLatent, 256, 223 + role_offset);
  const auto query = glm::reshape(f, kb.output, {1, 1, glm::kHeads, kLatent});
  r.query = publish(query, true);
  r.absorbed_query_reference = [qb = std::move(qb), kb = std::move(kb)](auto x) {
    return kb.reference(qb.reference(x));
  };
  auto kva = glm::projection(f, nx, kLatent, kHidden, 211 + role_offset, false);
  auto latent_scale = sem::oracle::scale(kLatent);
  const auto latent = glm::norm(f, kva.output, latent_scale); r.latent = publish(latent);
  r.latent_reference = [kva = std::move(kva), scale = latent_scale](auto x) {
    return sem::oracle::rms_norm_rows(kva.reference(x), scale, kLatent, glm::kNormEpsilon);
  };
  const auto cache = changed(kCache, f.one(c::Operation(c::Scatter{}), {state[kCache], state[kMlaCursor], latent}));
  const auto cursor = changed(kMlaCursor, increment(f, state[kMlaCursor]));
  Value selected = state[kSelection];
  if (r.fresh) {
    const auto pool = append_history(r, state, nx, cursor, role_offset);
    Value iq, weights;
    if (r.original) {
      const auto &roles = r.original->indexer_roles;
      const auto wq = f.one(c::model_ops::bfloat_linear_f32(),
          {codec::cast(f, qr, c::DataType::kBFloat16), external(r, roles[original_index::kQuery])});
      r.index_query_accum = publish(wq);
      const auto stored = codec::cast(f, wq, c::DataType::kBFloat16); r.index_query_stored = publish(stored);
      iq = glm::reshape(f, codec::cast(f, stored, c::DataType::kFloat32), {kIndexHeads, kIndexDepth});
      r.index_query = publish(iq, true);
      weights = f.one(c::Operation(c::MatMul{}),
          {nx, glm::permute(f, external(r, roles[original_index::kWeights]), {1, 0})});
      r.score_weight = publish(weights);
    } else {
    auto wq = glm::projection(f, qr, kIndexHeads * kIndexDepth, kQueryRank, 239 + role_offset, false);
    iq = glm::reshape(f, wq.output, {kIndexHeads, kIndexDepth});
    r.index_query = publish(iq, true);
    r.index_query_reference = [wq = std::move(wq)](auto x) { return wq.reference(x); };
    auto ws = glm::linear::projection(f, nx, kIndexHeads, kHidden, glm::linear::Storage::kF32, 251 + role_offset);
    weights = ws.output; r.score_weight = publish(weights);
    r.score_weight_reference = [ws = std::move(ws)](auto x) { return ws.reference(x); };
    }
    const auto encoded_query = codec::quantize(f, codec::bfloat_boundary(f, iq), kIndexHeads);
    r.query_codec = expose_codec(r, encoded_query);
    const auto pool_count = (r.position + 1) / 4;
    const auto scores = codec::score_encoded(f, pool.codes, pool.scales, encoded_query, weights, pool_count);
    r.scores = publish(scores, true);
    const auto top = f.append(c::Operation(c::TopK{.count = 512}), {scores}, 2);
    std::vector<std::int32_t> expanded(std::size_t(pool_count * 4));
    std::iota(expanded.begin(), expanded.end(), 0);
    const auto table = f.constant(sem::dense({pool_count, 4}, c::DataType::kInt32), sem::bytes(expanded));
    const auto pool_ids = glm::reshape(f, f.one(c::Operation(c::Gather{}), {table, top[1]}), {2048});
    Value tail;
    if (r.selected_tail) {
      tail = f.one(c::Operation(c::Copy{}), {state[kTailStart]});
      for (std::int32_t i = 1; i < r.selected_tail; ++i)
        tail = f.one(c::Operation(c::Concat{.axis = 0}), {tail, increment(f, state[kTailStart], i)});
    }
    if (r.selected_tail < 3) {
      const auto padding = f.constant(sem::dense({3 - r.selected_tail}, c::DataType::kInt32),
          sem::bytes(std::vector<std::int32_t>(std::size_t(3 - r.selected_tail), -1)));
      tail = r.selected_tail ? f.one(c::Operation(c::Concat{.axis = 0}), {tail, padding}) : padding;
    }
    selected = f.one(c::Operation(c::Concat{.axis = 0}), {pool_ids, tail});
    changed(kSelection, selected);
  } else {
    // No wq/wk/wg/pooling/TopK exists in this graph. The actual same-epoch IDs
    // from the StateVersion are the checked Gather's producer permission.
    selected = changed(kSelection, selected, true);
    changed(kJournal, f.one(c::Operation(c::Scatter{}), {journal->rows, journal->count, nx}));
    changed(kLagCount, increment(f, journal->count));
  }
  const auto selected_count = kSelected + r.selected_tail;
  const auto valid = glm::reshape(f, glm::core::rows(f, glm::reshape(f, selected, {kIds, 1}), 0, selected_count), {selected_count});
  const auto chosen = f.one(c::Operation(c::Gather{}), {cache, valid});
  const auto attention = f.one(c::Operation(c::ScaledDotProductAttention{.scale = 1.0F / 16.0F,
      .causal = true, .accumulation_type = c::DataType::kFloat32}),
      {query, glm::reshape(f, chosen, {1, selected_count, 1, kLatent}), glm::reshape(f, chosen, {1, selected_count, 1, kLatent})});
  r.attention = publish(attention);
  auto vb = glm::head_projection(f, glm::reshape(f, attention, {1, glm::kHeads, kLatent}), glm::kValue, kLatent, 227 + role_offset);
  auto out = glm::projection(f, glm::reshape(f, vb.output, {1, glm::kHeads * glm::kValue}),
      kHidden, glm::kHeads * glm::kValue, 229 + role_offset, false);
  const auto projected = out.output; r.output = publish(projected);
  r.output_reference = [vb = std::move(vb), out = std::move(out)](auto x) { return out.reference(vb.reference(x)); };
  return projected;
}

namespace target43 = glm_mtp_target43_component;
constexpr int kTarget43RoleOffset = 1021;
Recipe build_target43(std::int32_t position) {
  Recipe r; r.fresh = true; r.position = position; r.selected_tail = (position + 1) % 4;
  r.state_ports.fill(std::numeric_limits<std::size_t>::max());
  auto &f = r.fragment; f.profile = kModel.profile; f.region = 0x474c4d5441523433ULL; f.quantized = true;
  const auto residual = f.input(sem::dense({1, target43::kStreams, kHidden}));
  const auto desc = descriptions();
  std::array<Value, kSparseEntries.size()> actual;
  for (std::size_t i = 0; i < actual.size(); ++i) actual[i] = f.input(desc[kSparseEntries[i]]);
  const SparseState13 state(f, actual);
  auto boundary = target43::prepare(f, residual);
  r.nx = expose(r, boundary.input);
  const auto projected = append_sparse_attention(r, state, boundary.input, kTarget43RoleOffset);
  auto tail = target43::finish(f, std::move(boundary), projected);
  r.target43_reference = std::move(tail.evaluate);
  for (std::size_t i = 0; i < tail.values.size(); ++i) {
    const auto found = std::find_if(f.outputs.begin(), f.outputs.end(),
        [&](Value value) { return value.ordinal() == tail.values[i].ordinal(); });
    r.target43_ports[i] = found == f.outputs.end() ? expose(r, tail.values[i])
        : std::size_t(found - f.outputs.begin());
  }
  return r;
}

Recipe build(bool fresh, std::int32_t position = kBasePosition, std::int32_t carried_tail = 0,
             std::shared_ptr<const OriginalNextn> original = {}) {
  Recipe r;
  r.fresh = fresh;
  r.original = std::move(original);
  r.position = position;
  r.selected_tail = fresh ? (position + 1) % 4 : carried_tail;
  r.state_ports.fill(std::numeric_limits<std::size_t>::max());
  auto &f = r.fragment;
  f.profile = r.original ? &glm::core::profiles::glm53_flash_official : kModel.profile;
  f.region = fresh ? 0x474c4d5354465245ULL : 0x474c4d5354534b50ULL;
  f.quantized = true;
  const auto desc = descriptions();
  std::array<Value, kResources> state;
  for (std::size_t i = 0; i < state.size(); ++i) state[i] = f.input(desc[i]);
  const auto next_pending = f.input(sem::dense({1}, c::DataType::kInt32));
  const auto publish = [&](Value value, bool copy = false) {
    return expose(r, value, copy);
  };
  const auto changed = [&](Entry entry, Value value, bool copy = false) {
    return change(r, entry, value, copy);
  };
  std::vector<float> embeddings;
  for (std::int32_t token = 0; token < 8; ++token) {
    const auto values = embedding_values(token); embeddings.insert(embeddings.end(), values.begin(), values.end());
  }
  const auto token_bank = f.constant(sem::dense({8, kHidden}), sem::bytes(embeddings));
  const auto embedding = f.one(c::Operation(c::Gather{}), {token_bank, state[kPending]});
  r.embedding = publish(embedding);
  Value eh, nx, qr;
  if (r.original) {
    const auto hidden_bf16 = codec::cast(f, state[kHiddenState], c::DataType::kBFloat16);
    const auto embedding_bf16 = codec::cast(f, embedding, c::DataType::kBFloat16);
    r.original_hidden = publish(hidden_bf16); r.original_embedding = publish(embedding_bf16);
    const auto prefix = original_prefix::append_with_constants(f, hidden_bf16, embedding_bf16,
        [&](original_prefix::Parameter parameter) { return external(r, r.original->prefix_roles[static_cast<std::size_t>(parameter)]); });
    const auto ports = prefix.values();
    for (std::size_t i = 0; i < ports.size(); ++i) r.original_prefix_ports[i] = publish(ports[i], true);
    eh = codec::cast(f, prefix.eh, c::DataType::kFloat32);
    nx = codec::cast(f, prefix.nx, c::DataType::kFloat32);
    qr = prefix.qr;
  } else {
    const auto input = glm::attach(f, glm::mtp_input(kModel, &r.input_reference, false),
        {state[kHiddenState], embedding});
    eh = input[3];
    r.input_scale = sem::oracle::scale(kHidden);
    auto input_scale = r.input_scale;
    nx = glm::norm(f, eh, input_scale);
  }
  r.eh = publish(eh); r.nx = publish(nx);
  changed(kPending, next_pending, true);
  const SkipJournal journal{state[kJournal], state[kLagCount]};
  const auto attention_output = append_sparse_attention(r, sparse_state(f, state), nx, 0, &journal,
      r.original ? &qr : nullptr);
  const auto residual = glm::binary(f, c::BinaryKind::kAdd, eh, attention_output); r.residual = publish(residual);
  r.ffn_scale = sem::oracle::scale(kHidden); auto ffn_scale = r.ffn_scale;
  const auto ffn_input = glm::norm(f, residual, ffn_scale); r.ffn_input = publish(ffn_input);
  auto moe = glm::moe::moe_chain(glm::moe::cases::kCases[11], false, false, &r.moe_reference, 0.5F);
  const auto ff = glm::attach(f, std::move(moe), {ffn_input});
  r.ffn_output = publish(ff[5]);
  const auto combined = glm::binary(f, c::BinaryKind::kAdd, residual, glm::reshape(f, ff[5], {1, kHidden}));
  r.head_scale = sem::oracle::scale(kHidden); std::reverse(r.head_scale.begin(), r.head_scale.end());
  auto head_scale = r.head_scale;
  changed(kHiddenState, glm::norm(f, combined, head_scale));
  return r;
}

Recipe build_catchup(bool direct_reference = false, std::int32_t position = 2055,
                     std::shared_ptr<const OriginalNextn> original = {}) {
  Recipe r;
  r.catchup = true; r.direct_catchup = direct_reference; r.position = position;
  r.original = std::move(original);
  r.state_ports.fill(std::numeric_limits<std::size_t>::max());
  auto &f = r.fragment;
  f.profile = r.original ? &glm::core::profiles::glm53_flash_official : kModel.profile;
  f.region = direct_reference ? 0x474c4d4341544449ULL : 0x474c4d4341544a4fULL;
  f.quantized = true;
  const auto desc = descriptions();
  std::array<Value, kResources> state;
  for (std::size_t i = 0; i < state.size(); ++i) state[i] = f.input(desc[i]);
  Value nx;
  if (direct_reference) {
    // A separately executed accepted token supplies this actual producer
    // lease directly, independently of the journal gather in the real path.
    nx = f.input(sem::dense({1, kHidden}));
    r.nx = expose(r, nx, true);
  } else {
    const auto first = f.constant(sem::dense({1}, c::DataType::kInt32), sem::bytes(std::vector<std::int32_t>{0}));
    nx = f.one(c::Operation(c::Gather{}), {state[kJournal], first});
    r.nx = expose(r, nx);
  }
  (void)append_history(r, sparse_state(f, state), nx, increment(f, state[kIndexCursor]));
  change(r, kLagCount, increment(f, state[kLagCount], -1));
  // Catchup publishes no seed and executes no MLA, NextN, or sampling work.
  // Old I32 IDs retain old epoch provenance until a real fresh query runs.
  for (const auto &node : f.nodes)
    if (node.operation.get_if<c::TopK>() || node.operation.get_if<c::ScaledDotProductAttention>())
      throw std::runtime_error("catchup recipe accidentally executes selection or MLA");
  return r;
}

// The old finite starting boundary contains513 generated completed pools.
// Encode them once through the actual public Graph; do not import host-oracle
// codes/scales as if a real quantizer had produced this state.
Recipe initial_pool_recipe() {
  Recipe r; r.state_ports.fill(std::numeric_limits<std::size_t>::max());
  auto &f = r.fragment; f.profile = kModel.profile; f.region = 0x474c4d494e495451ULL;
  const auto pools = kBasePosition / 4;
  const auto source = f.input(sem::dense({pools, kIndexDepth}));
  const auto encoded = codec::quantize(f, codec::bfloat_boundary(f, source), pools);
  const auto old_codes = f.constant(sem::dense({kPoolCapacity, kIndexDepth}, c::DataType::kFloat8E4M3FN),
      sem::bytes(std::vector<std::uint8_t>(std::size_t(kPoolCapacity * kIndexDepth), 0x7f)));
  const auto old_scales = f.constant(sem::dense({kPoolCapacity, 1}),
      sem::bytes(std::vector<float>(std::size_t(kPoolCapacity), std::numeric_limits<float>::quiet_NaN())));
  std::vector<std::int32_t> rows(std::size_t(pools), 0); std::iota(rows.begin(), rows.end(), 0);
  const auto indices = f.constant(sem::dense({pools}, c::DataType::kInt32), sem::bytes(rows));
  f.outputs = {f.one(c::Operation(c::Scatter{}), {old_codes, indices, encoded.codes}),
      f.one(c::Operation(c::Scatter{}), {old_scales, indices, encoded.scale})};
  r.pool_codec = expose_codec(r, encoded);
  return r;
}

struct Program final {
  Recipe recipe;
  sem::GraphCase logical;
  std::vector<c::ReadLease> parameters;
  std::vector<std::size_t> parameter_slots;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool outputs;
  static Program create(Recipe recipe, c::Context &context, const c::StorageOwner &owner, bool cuda,
                        std::uint32_t max_generations = 5) {
    if (!max_generations) throw std::runtime_error("output generations must be positive");
    Program p; p.recipe = std::move(recipe); p.recipe.cuda = cuda; p.logical = sem::make_graph(p.recipe.fragment);
    std::vector<g::ConstantBinding> constants;
    for (std::size_t i = 0; i < p.logical.constants.size(); ++i) {
      const auto supplied = std::find_if(p.recipe.external.begin(), p.recipe.external.end(),
          [&](const External &value) { return value.constant == i; });
      if (supplied != p.recipe.external.end()) {
        if (supplied->role.description != p.recipe.fragment.description(p.recipe.fragment.constants[i]))
          throw std::runtime_error("original GLM constant descriptor changed");
        constants.push_back(take(supplied->role.binding(p.logical.constants[i]), "shared original GLM constant owner"));
      } else {
        p.parameters.push_back(upload(owner, p.recipe.fragment.constant_bytes[i])); p.parameter_slots.push_back(i);
        constants.push_back({p.logical.constants[i], take(p.parameters.back().tensor(
            p.recipe.fragment.description(p.recipe.fragment.constants[i])), "typed NextN constant")});
      }
    }
    const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*p.recipe.fragment.profile), "actual GLM component profile"),
        p.recipe.draft_extend ? c::WorkloadPhase::kPrefill : c::WorkloadPhase::kDecode,
        {0x48594c454d4f444cULL, p.recipe.fragment.region, 1}};
    const g::CompileOptions options{.constants = constants, .workload = workload};
    const auto compile = [&]() -> hyle::Result<g::CompiledGraph> {
#if defined(HYLE_TEST_GLM_STATE_CPU)
      if (!cuda) return g::cpu::compile(p.logical.graph, context, options);
#endif
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      if (cuda) return g::cuda::compile(p.logical.graph, context, owner, options);
#endif
      throw std::runtime_error("GLM state consumer backend not enabled");
    };
    p.compiled = take(compile(), "ordinary connected NextN Graph");
    p.invocation = take(p.compiled.executable.create_invocation({.resources = g::ResourceOptions{}}), "ordinary NextN Invocation");
    std::size_t footprint = 0;
    for (std::size_t i = 0; i < p.logical.outputs.size(); ++i) {
      if (take(p.compiled.executable.output_ownership(i), "NextN output ownership") != g::OutputOwnership::kCaller)
        throw std::runtime_error("NextN consumer requires caller-owned result storage");
      const auto extent = take(p.recipe.fragment.description(p.recipe.fragment.outputs[i]).required_bytes(), "NextN output extent");
      footprint += (extent + 255u) / 256u * 256u;
    }
    p.outputs = take(c::LeasePool::create(owner.ref(), footprint * max_generations,
        {.max_blocks = std::uint32_t(p.logical.outputs.size() * max_generations), .backing_alignment = 256}), "bounded ordinary Graph output generations");
    return p;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue, std::span<const c::ReadLease> inputs) {
    if (inputs.size() != logical.inputs.size()) throw std::runtime_error("complete NextN input count");
    for (std::size_t i = 0; i < inputs.size(); ++i)
      check(invocation.bind(logical.inputs[i], recipe.fragment.description(recipe.fragment.inputs[i]), inputs[i]), "bind actual NextN state lease");
    for (std::size_t i = 0; i < logical.outputs.size(); ++i) {
      const auto &desc = recipe.fragment.description(recipe.fragment.outputs[i]);
      check(invocation.bind(logical.outputs[i], desc, take(outputs.allocate(take(desc.required_bytes(), "NextN result bytes")), "fresh NextN result writer")), "bind NextN result");
    }
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
    check(invocation.prepare_replay(queues, {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}), "prepare connected NextN invocation");
    { auto done = take(invocation.submit(queues), "strict NextN submit"); check(done.wait(), "complete NextN retirement"); }
    std::vector<c::ReadLease> result;
    for (auto output : logical.outputs) result.push_back(take(take(invocation.result(output), "actual NextN output").storage_lease(), "independent NextN output lease"));
    check(invocation.reset(), "withdraw NextN result permissions");
    if (invocation.submit(queues)) throw std::runtime_error("reset NextN invocation retained stale replay");
    return result;
  }
};

codec::Encoded observe_codec(std::span<const float> source, std::int64_t rows,
                              std::span<const c::ReadLease> output, const CodecPorts &ports) {
  const auto input = typed<float>(output[ports.input]);
  const auto transformed = typed<float>(output[ports.transformed]);
  const auto rounded = typed<float>(output[ports.rotated]);
  if (source.size() != std::size_t(rows * kIndexDepth) || input.size() != source.size() ||
      transformed.size() != source.size() || rounded.size() != source.size())
    throw std::runtime_error("whole NextN codec diagnostic extent");
  constexpr double u = 0x1p-24, gamma129 = 129 * u / (1 - 129 * u);
  const double normalization = 1.0 / std::sqrt(double(kIndexDepth));
  std::size_t bad_input = 0, bad_math = 0, bad_bfloat = 0;
  double max_ratio = 0;
  for (std::int64_t row = 0; row < rows; ++row) {
    double sumabs = 0;
    for (std::int64_t d = 0; d < kIndexDepth; ++d) {
      const auto i = std::size_t(row * kIndexDepth + d);
      const float wanted = codec::wide(codec::bfloat(source[i]));
      if (std::bit_cast<std::uint32_t>(input[i]) != std::bit_cast<std::uint32_t>(wanted)) ++bad_input;
      sumabs += std::abs(double(wanted));
    }
    const double bound = gamma129 * sumabs * normalization;
    for (std::int64_t d = 0; d < kIndexDepth; ++d) {
      double sum = 0;
      for (std::int64_t k = 0; k < kIndexDepth; ++k)
        sum += (std::popcount(unsigned(d & k)) & 1 ? -1.0 : 1.0) *
            codec::wide(codec::bfloat(source[std::size_t(row * kIndexDepth + k)]));
      const auto i = std::size_t(row * kIndexDepth + d);
      const double difference = std::abs(double(transformed[i]) - sum * normalization);
      if (!std::isfinite(transformed[i]) || difference > bound) ++bad_math;
      max_ratio = std::max(max_ratio, bound ? difference / bound : difference);
      if (std::bit_cast<std::uint32_t>(rounded[i]) !=
          std::bit_cast<std::uint32_t>(codec::wide(codec::bfloat(transformed[i])))) ++bad_bfloat;
    }
  }
  EXPECT_EQ(bad_input, 0u) << "exact explicit BF16 boundary before Hadamard";
  EXPECT_EQ(bad_math, 0u) << "independent F64 Sylvester Hadamard, max/gamma129=" << max_ratio;
  EXPECT_EQ(bad_bfloat, 0u) << "BF16 RNE of actual, independently checked transform";
  const auto expected = codec::encode_rotated(rounded, rows);
  EXPECT_EQ(typed<std::uint8_t>(output[ports.codes]), expected.codes);
  const auto scales = typed<float>(output[ports.scales]);
  EXPECT_EQ(scales.size(), expected.scales.size());
  for (std::size_t i = 0; i < std::min(scales.size(), expected.scales.size()); ++i)
    EXPECT_EQ(std::bit_cast<std::uint32_t>(scales[i]), std::bit_cast<std::uint32_t>(expected.scales[i]));
  return expected;
}

struct SparseSnapshot final {
  std::array<c::ReadLease, kSparseEntries.size()> values;
  const c::ReadLease &operator[](Entry entry) const {
    const auto found = std::find(kSparseEntries.begin(), kSparseEntries.end(), entry);
    if (found == kSparseEntries.end()) throw std::runtime_error("entry is not a sparse snapshot member");
    return values[std::size_t(found - kSparseEntries.begin())];
  }
};
struct SparseAccess final {
  c::ReadLease member(const SparseSnapshot &v, Entry entry) const { return v[entry]; }
  std::int32_t scalar(const SparseSnapshot &v, Entry entry) const { return typed<std::int32_t>(v[entry]).at(0); }
};
SparseSnapshot initial_sparse(const c::StorageOwner &owner, Program &initializer,
                              c::Queue &queue, std::int32_t position) {
  std::array<Bytes, kResources> values;
  std::vector<float> cache(kCapacity * kLatent, std::numeric_limits<float>::quiet_NaN());
  for (std::int64_t t = 0; t < position; ++t) for (std::int64_t d = 0; d < kLatent; ++d)
    cache[std::size_t(t * kLatent + d)] = 0.25F + float(t % 97) / 64.0F + float(d % 11) / 128.0F;
  values[kCache] = sem::bytes(cache);
  std::vector<float> raw(kRing * kIndexDepth), gates(raw.size());
  for (std::int32_t p = position - std::int32_t(kRing); p < position; ++p)
    for (std::int64_t d = 0; d < kIndexDepth; ++d) {
    raw[std::size_t((p % kRing) * kIndexDepth + d)] = float((p * 3 + d * 7) % 97 - 48) / 32.0F;
      gates[std::size_t((p % kRing) * kIndexDepth + d)] = float((p * 7 + d * 11) % 29 - 14) / 8.0F;
    }
  std::vector<std::uint16_t> raw_bfloat(raw.size()), gate_bfloat(gates.size());
  for (std::size_t i = 0; i < raw.size(); ++i) { raw_bfloat[i] = codec::bfloat(raw[i]); gate_bfloat[i] = codec::bfloat(gates[i]); }
  values[kRawKey] = sem::bytes(raw_bfloat); values[kRawGate] = sem::bytes(gate_bfloat);
  if (position / 4 != kBasePosition / 4) throw std::runtime_error("initial encoded pool preparation extent");
  std::vector<float> pools(std::size_t(position / 4 * kIndexDepth));
  for (std::int64_t p = 0; p < position / 4; ++p) for (std::int64_t d = 0; d < kIndexDepth; ++d)
    pools[std::size_t(p * kIndexDepth + d)] = (0.125F + float(p) / 64.0F) * (0.5F + float(d % 11) / 32.0F);
  const std::array initial_input{upload(owner, sem::bytes(pools))};
  const auto encoded = initializer.execute(queue, initial_input);
  const auto expected = observe_codec(pools, position / 4, encoded, initializer.recipe.pool_codec);
  const auto actual_codes = typed<std::uint8_t>(encoded[0]);
  const auto actual_scales = typed<float>(encoded[1]);
  EXPECT_TRUE(std::equal(expected.codes.begin(), expected.codes.end(), actual_codes.begin()));
  EXPECT_TRUE(std::equal(expected.scales.begin(), expected.scales.end(), actual_scales.begin()));
  for (std::size_t row = std::size_t(position / 4); row < std::size_t(kPoolCapacity); ++row) {
    EXPECT_TRUE(std::isnan(actual_scales[row]));
    for (std::size_t d = 0; d < std::size_t(kIndexDepth); ++d) EXPECT_EQ(actual_codes[row * std::size_t(kIndexDepth) + d], 0x7f);
  }
  values[kQueryState] = sem::bytes(std::vector<float>(kQueryRank, 0));
  const std::array<Entry, 6> counters{kMlaCursor, kIndexCursor, kPoolCount, kRingOffset, kTailValid, kTailStart};
  const std::array<std::int32_t, 6> scalars{position, position, position / 4,
      position % std::int32_t(kRing), position % 4, position - position % 4};
  for (std::size_t i = 0; i < counters.size(); ++i) values[counters[i]] = sem::bytes(std::vector{scalars[i]});
  values[kSelection] = sem::bytes(std::vector<std::int32_t>(kIds, -1));
  SparseSnapshot result;
  for (std::size_t i = 0; i < kSparseEntries.size(); ++i) {
    const auto entry = kSparseEntries[i];
    result.values[i] = entry == kPool ? encoded[0] : entry == kPoolScales ? encoded[1] : upload(owner, values[entry]);
  }
  return result;
}

struct Epoch final { std::uint64_t epoch, producer_position, reuse_count; };
static_assert(sizeof(Epoch) == 24);
struct State final {
  c::StateSchema schema;
  c::StateStore store;
  std::vector<c::StateEntryId> entries;
  std::uint64_t epoch = 7;
  bool enabled = true;
  static State create(const c::StorageOwner &owner,
                      std::span<const c::StateEntrySpec> extra_specs = {},
                      std::size_t max_backing_bytes = 128u << 20) {
    const auto desc = descriptions(); std::vector<c::StateEntrySpec> specs(kEntries);
    for (std::size_t i = 0; i < kResources; ++i) specs[i] = {.description = desc[i], .resource = owner.ref()};
    specs[kEpoch] = {.kind = c::StateEntryKind::kHostMetadata, .metadata_bytes = sizeof(Epoch)};
    specs.insert(specs.end(), extra_specs.begin(), extra_specs.end());
    State result; result.schema = take(c::StateSchema::create(specs), "complete component schema");
    result.store = take(c::StateStore::create(result.schema, {.max_versions = 16, .max_drafts = 2,
        .max_retained_blocks = 256, .max_backing_bytes = max_backing_bytes}), "bounded complete component state store");
    for (std::size_t i = 0; i < specs.size(); ++i) result.entries.push_back(take(result.schema.entry(i), "complete schema entry"));
    return result;
  }
  c::ReadLease member(const c::StateVersion &v, std::size_t i) const { return take(v.member(entries[i]), "actual complete state member"); }
  std::int32_t scalar(const c::StateVersion &v, Entry entry) const { return typed<std::int32_t>(member(v, entry)).at(0); }
  Epoch facts(const c::StateVersion &v) const {
    const auto bytes = read(member(v, kEpoch)); Epoch result{}; std::memcpy(&result, bytes.data(), sizeof(result)); return result;
  }
  bool qualifies(const c::StateVersion &v) const { return enabled && v.valid() && facts(v).epoch == epoch; }
  c::StateVersion initial(const c::StorageOwner &owner, Program &initializer, c::Queue &queue,
                         std::int32_t position = kBasePosition,
                         std::span<const c::StateMember> extra_members = {},
                         const c::ReadLease &seed_hidden = {}) {
    if (entries.size() != kEntries + extra_members.size())
      throw std::runtime_error("initial complete component extra member count");
    const auto sparse = initial_sparse(owner, initializer, queue, position);
    std::array<Bytes, kResources> values;
    values[kHiddenState] = sem::bytes(embedding_values(0));
    values[kPending] = sem::bytes(std::vector<std::int32_t>{1});
    values[kJournal] = sem::bytes(std::vector<float>(kJournalRows * kHidden, std::numeric_limits<float>::quiet_NaN()));
    values[kLagCount] = sem::bytes(std::vector<std::int32_t>{0});
    std::vector<c::StateMember> members(entries.size());
    for (std::size_t i = 0; i < kResources; ++i) {
      const auto found = std::find(kSparseEntries.begin(), kSparseEntries.end(), Entry(i));
      members[i] = {entries[i], found != kSparseEntries.end() ? sparse[Entry(i)] :
          i == kHiddenState && seed_hidden.valid() ? seed_hidden : upload(owner, values[i])};
    }
    const Epoch metadata{0, 0, 0}; members[kEpoch] = {entries[kEpoch], {}, std::as_bytes(std::span(&metadata, 1))};
    std::copy(extra_members.begin(), extra_members.end(), members.begin() + kEntries);
    return take(store.import(members), "initial declared component checkpoint");
  }
  c::StateVersion stage(const c::StateVersion &from, const Recipe &recipe, std::span<const c::ReadLease> outputs,
                        std::span<const c::StateMember> extra_members = {}) {
    auto draft = take(store.begin(from), "whole component draft");
    for (std::size_t i = 0; i < kResources; ++i)
      if (recipe.state_ports[i] != std::numeric_limits<std::size_t>::max())
        check(draft.replace(entries[i], outputs[recipe.state_ports[i]]), "stage actual component output");
    for (const auto &member : extra_members)
      check(draft.replace(member.entry, member.resource), "stage actual target component output in same draft");
    auto metadata = facts(from);
    if (recipe.fresh) metadata = {epoch, std::uint64_t(scalar(from, kMlaCursor)), 0};
    else if (!recipe.catchup) ++metadata.reuse_count;
    check(draft.replace_metadata(entries[kEpoch], std::as_bytes(std::span(&metadata, 1))), "explicit component iteration policy");
    return take(draft.finalize(), "finalize all component state");
  }
};
using Image = std::vector<Bytes>;
Image image(const State &s, const c::StateVersion &v) {
  Image result(s.entries.size()); for (std::size_t i = 0; i < s.entries.size(); ++i) result[i] = read(s.member(v, i)); return result;
}
void same_storage(const c::ReadLease &a, const c::ReadLease &b) {
  const auto av = take(a.view(), "first actual storage identity"), bv = take(b.view(), "second actual storage identity");
  EXPECT_EQ(av.resource(), bv.resource()); EXPECT_EQ(av.native_handle(), bv.native_handle());
  EXPECT_EQ(av.offset(), bv.offset()); EXPECT_EQ(av.size(), bv.size()); EXPECT_EQ(a.generation(), b.generation());
}
void quantified(const Recipe &recipe, std::span<const float> actual, std::span<const float> expected) {
  sem::expect_output(recipe.fragment, actual, expected);
}
template<class StateView, class Version>
void exact_scatter(const StateView &s, const Version &from, const Version &next,
                   Entry bank, std::size_t row, std::size_t width, const c::ReadLease &update,
                   std::size_t element_bytes = sizeof(float)) {
  auto expected = read(s.member(from, bank)); const auto actual_update = read(update);
  ASSERT_EQ(actual_update.size(), width * element_bytes);
  std::copy(actual_update.begin(), actual_update.end(), expected.begin() + row * width * element_bytes);
  EXPECT_EQ(read(s.member(next, bank)), expected) << "only the actual native-produced row may change";
}
template<class StateView, class Version>
void observe_history(const StateView &s, const Version &from, const Version &next,
                     const Recipe &r, std::span<const c::ReadLease> output,
                     std::span<const float> nx) {
  const auto fp = [&](std::size_t port) { return typed<float>(output[port]); };
  const auto key = fp(r.key), gate_projection = fp(r.gate_projection), gate = fp(r.gate);
  if (r.original) {
    const auto &source = r.original->indexer;
    const auto wk = fp(r.wk_accum);
    EXPECT_TRUE(index_reference::expect_accum(wk, index_reference::linear(nx, source.key, kIndexDepth), "original wk BF16 operands -> F32"));
    const auto rounded_wk = typed<std::uint16_t>(output[r.wk_stored]);
    EXPECT_TRUE(index_reference::expect_bfloat_store(rounded_wk, wk, "original wk BF16 store"));
    sem::oracle::expect_close(key, index_reference::layer_norm(original_index::widen(rounded_wk), source.norm, source.bias), 8e-5F, 4e-5F);
    EXPECT_TRUE(index_reference::expect_accum(gate_projection,
        index_reference::linear(nx, source.gate, kIndexDepth), "original compression gate BF16 operands -> F32"));
  } else {
    quantified(r, key, r.key_reference(nx)); quantified(r, gate_projection, r.gate_reference(nx));
  }
  const auto raw_key = typed<std::uint16_t>(output[r.raw_key]), raw_gate = typed<std::uint16_t>(output[r.raw_gate]);
  ASSERT_EQ(raw_key.size(), key.size()); ASSERT_EQ(raw_gate.size(), gate_projection.size());
  for (std::size_t i = 0; i < key.size(); ++i) {
    EXPECT_EQ(raw_key[i], codec::bfloat(key[i]));
    EXPECT_EQ(raw_gate[i], codec::bfloat(gate_projection[i]));
    EXPECT_EQ(std::bit_cast<std::uint32_t>(gate[i]), std::bit_cast<std::uint32_t>(codec::wide(raw_gate[i])));
  }
  exact_scatter(s, from, next, kRawKey, std::size_t(s.scalar(from, kRingOffset)), kIndexDepth, output[r.raw_key], sizeof(std::uint16_t));
  exact_scatter(s, from, next, kRawGate, std::size_t(s.scalar(from, kRingOffset)), kIndexDepth, output[r.raw_gate], sizeof(std::uint16_t));
  if (r.position % 4 == 3) {
    const auto raw = typed<std::uint16_t>(s.member(next, kRawKey)), gates = typed<std::uint16_t>(s.member(next, kRawGate));
    std::vector<float> pooled(kIndexDepth);
    if (r.original) {
      std::array<std::int32_t, 4> ring_rows{};
      for (std::size_t t = 0; t < ring_rows.size(); ++t)
        ring_rows[t] = (r.position - 3 + std::int32_t(t)) % std::int32_t(kRing);
      pooled = index_reference::pool_reference(raw, gates, r.original->indexer.ape, ring_rows);
    } else {
    for (std::size_t d = 0; d < kIndexDepth; ++d) {
      std::array<double, 4> logits;
      for (std::size_t t = 0; t < 4; ++t) {
        const auto slot = std::size_t((r.position - 3 + std::int32_t(t)) % std::int32_t(kRing));
        logits[t] = codec::wide(gates[slot * kIndexDepth + d]) + double(int((t * kIndexDepth + d) * 7 % 19) - 9) / 16.0;
      }
      const auto maximum = *std::max_element(logits.begin(), logits.end()); double total = 0, result = 0;
      for (auto &value : logits) total += value = std::exp(value - maximum);
      for (std::size_t t = 0; t < 4; ++t) {
        const auto slot = std::size_t((r.position - 3 + std::int32_t(t)) % std::int32_t(kRing));
        result += logits[t] / total * codec::wide(raw[slot * kIndexDepth + d]);
      }
      pooled[d] = float(result);
    }
    }
    sem::oracle::expect_close(fp(r.compressed), pooled, 8e-5F, 4e-5F);
    (void)observe_codec(fp(r.compressed), 1, output, r.pool_codec);
    exact_scatter(s, from, next, kPool, std::size_t(r.position / 4), kIndexDepth, output[r.pool_codec.codes], sizeof(std::uint8_t));
    exact_scatter(s, from, next, kPoolScales, std::size_t(r.position / 4), 1, output[r.pool_codec.scales]);
  } else {
    for (const auto entry : {kPool, kPoolScales, kPoolCount, kTailStart}) same_storage(s.member(next, entry), s.member(from, entry));
  }
  EXPECT_EQ(s.scalar(next, kIndexCursor), r.position + 1);
  EXPECT_EQ(s.scalar(next, kPoolCount), (r.position + 1) / 4);
  EXPECT_EQ(s.scalar(next, kRingOffset), (r.position + 1) % std::int32_t(kRing));
  EXPECT_EQ(s.scalar(next, kTailValid), (r.position + 1) % 4);
  EXPECT_EQ(s.scalar(next, kTailStart), (r.position + 1) / 4 * 4);
}
template<class StateView, class Version>
void observe_attention(const StateView &s, const Version &from, const Version &next,
             const Recipe &r, std::span<const c::ReadLease> output,
             std::span<const float> nx, std::int32_t producer_position) {
  const auto fp = [&](std::size_t port) { return typed<float>(output[port]); };
  const auto qr = typed<float>(s.member(next, kQueryState));
  if (r.original) {
    EXPECT_EQ(qr, original_index::widen(typed<std::uint16_t>(output[r.original_prefix_ports[6]])));
  } else quantified(r, qr, r.query_reference(nx));
  quantified(r, fp(r.latent), r.latent_reference(nx));
  exact_scatter(s, from, next, kCache, std::size_t(s.scalar(from, kMlaCursor)), kLatent, output[r.latent]);
  EXPECT_EQ(s.scalar(next, kMlaCursor), s.scalar(from, kMlaCursor) + 1);
  const auto ids = typed<std::int32_t>(s.member(next, kSelection));
  ASSERT_EQ(ids.size(), std::size_t(kIds));
  for (std::int32_t i = 0; i < 3; ++i)
    EXPECT_EQ(ids[std::size_t(kSelected + i)], i < r.selected_tail ? producer_position + 1 - r.selected_tail + i : -1);
  if (r.fresh) {
    observe_history(s, from, next, r, output, nx);
    if (r.original) {
      const auto wq = fp(r.index_query_accum);
      EXPECT_TRUE(index_reference::expect_accum(wq,
          index_reference::linear(qr, r.original->indexer.query, kIndexHeads * kIndexDepth), "original wq_b BF16 operands -> F32"));
      const auto rounded = typed<std::uint16_t>(output[r.index_query_stored]);
      EXPECT_TRUE(index_reference::expect_bfloat_store(rounded, wq, "original wq_b BF16 store"));
      EXPECT_EQ(fp(r.index_query), original_index::widen(rounded));
      EXPECT_TRUE(index_reference::expect_accum(fp(r.score_weight),
          index_reference::linear(nx, r.original->indexer.weights, kIndexHeads), "original widened-F32 weights_proj"));
    } else {
      quantified(r, fp(r.index_query), r.index_query_reference(qr));
      sem::oracle::expect_close(fp(r.score_weight), r.score_weight_reference(nx), 8e-5F, 4e-5F);
    }
    const auto iq = fp(r.index_query), weights = fp(r.score_weight);
    const auto query_encoded = observe_codec(iq, kIndexHeads, output, r.query_codec);
    const auto codes = typed<std::uint8_t>(s.member(next, kPool));
    const auto scales = typed<float>(s.member(next, kPoolScales));
    const auto pool_count = std::size_t((r.position + 1) / 4);
    const auto expected_scores = codec::score_reference(codes, scales, query_encoded, weights, std::int64_t(pool_count));
    const auto scores = fp(r.scores); sem::oracle::expect_close(scores, expected_scores, 8e-5F, 4e-5F);
    std::vector<bool> picked(pool_count, false); float smallest = std::numeric_limits<float>::infinity();
    for (std::size_t t = 0; t < 512; ++t) {
      const auto pool_id = ids[t * 4] / 4;
      ASSERT_GE(pool_id, 0); ASSERT_LT(std::size_t(pool_id), pool_count); EXPECT_FALSE(picked[std::size_t(pool_id)]);
      picked[std::size_t(pool_id)] = true; smallest = std::min(smallest, scores[std::size_t(pool_id)]);
      for (std::size_t j = 0; j < 4; ++j) EXPECT_EQ(ids[t * 4 + j], pool_id * 4 + std::int32_t(j));
    }
    for (std::size_t p = 0; p < picked.size(); ++p) if (!picked[p]) EXPECT_GE(smallest, scores[p]);
  } else {
    for (const auto entry : {kRawKey, kRawGate, kPool, kPoolScales, kIndexCursor, kPoolCount, kRingOffset, kTailValid, kTailStart})
      same_storage(s.member(next, entry), s.member(from, entry));
    EXPECT_EQ(read(s.member(next, kSelection)), read(s.member(from, kSelection)));
    exact_scatter(s, from, next, kJournal, std::size_t(s.scalar(from, kLagCount)), kHidden, output[r.nx]);
    EXPECT_EQ(s.scalar(next, kLagCount), s.scalar(from, kLagCount) + 1);
  }
  const auto query = fp(r.query), cache = typed<float>(s.member(next, kCache));
  quantified(r, query, r.absorbed_query_reference(qr));
  std::vector<float> selected(std::size_t(kSelected + r.selected_tail));
  for (std::size_t i = 0; i < selected.size(); ++i) selected[i] = float(ids[i]);
  const auto attention = fp(r.attention);
  sem::oracle::expect_close(attention, glm::attention_reference(query, cache, selected, kSelected + r.selected_tail, kLatent), 8e-5F, 4e-5F);
  const auto projected = fp(r.output); quantified(r, projected, r.output_reference(attention));
}

void observe(const State &s, const c::StateVersion &from, const c::StateVersion &next,
             const Recipe &r, std::span<const c::ReadLease> output,
             const c::ReadLease &hidden_input = {}) {
  const auto fp = [&](std::size_t port) { return typed<float>(output[port]); };
  const auto hidden = typed<float>(hidden_input.valid() ? hidden_input : s.member(from, kHiddenState));
  const auto embedding = fp(r.embedding), eh = fp(r.eh), nx = fp(r.nx);
  EXPECT_EQ(embedding, embedding_values(s.scalar(from, kPending)));
  if (r.original) {
    const auto actual_hidden = typed<std::uint16_t>(output[r.original_hidden]);
    const auto actual_embedding = typed<std::uint16_t>(output[r.original_embedding]);
    EXPECT_TRUE(index_reference::expect_bfloat_store(actual_hidden, hidden, "declared original-prefix target-hidden boundary"));
    EXPECT_TRUE(index_reference::expect_bfloat_store(actual_embedding, embedding, "declared original-prefix embedding boundary"));
    std::array<std::vector<std::uint16_t>, 7> actual;
    for (std::size_t i = 0; i < actual.size(); ++i) actual[i] = typed<std::uint16_t>(output[r.original_prefix_ports[i]]);
    EXPECT_TRUE(original_prefix::observe_prefix(r.original->prefix, actual_hidden, actual_embedding, actual,
        r.cuda));
    EXPECT_EQ(eh, original_index::widen(actual[3])); EXPECT_EQ(nx, original_index::widen(actual[4]));
  } else {
    quantified(r, eh, r.input_reference(hidden, embedding)[3]);
    sem::oracle::expect_close(nx, sem::oracle::rms_norm_rows(eh, r.input_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);
  }
  const auto producer_position = r.fresh ? r.position : std::int32_t(s.facts(from).producer_position);
  observe_attention(s, from, next, r, output, nx, producer_position);
  const auto projected = fp(r.output);
  if (r.fresh) {
    same_storage(s.member(next, kJournal), s.member(from, kJournal));
    same_storage(s.member(next, kLagCount), s.member(from, kLagCount));
  }
  auto residual = eh; for (std::size_t i = 0; i < residual.size(); ++i) residual[i] += projected[i];
  sem::oracle::expect_close(fp(r.residual), residual, 8e-5F, 4e-5F);
  const auto ffn_input = fp(r.ffn_input), ffn_output = fp(r.ffn_output);
  sem::oracle::expect_close(ffn_input, sem::oracle::rms_norm_rows(fp(r.residual), r.ffn_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);
  quantified(r, ffn_output, r.moe_reference(ffn_input)[5]);
  const auto actual_residual = fp(r.residual);
  for (std::size_t i = 0; i < residual.size(); ++i) residual[i] = actual_residual[i] + ffn_output[i];
  sem::oracle::expect_close(typed<float>(s.member(next, kHiddenState)),
      sem::oracle::rms_norm_rows(residual, r.head_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);
}

c::StateVersion execute(State &s, Program &p, c::Queue &queue, const c::StorageOwner &owner,
                        const c::StateVersion &from, std::int32_t pending,
                        c::ReadLease *retained_nx = nullptr,
                        std::span<const c::StateMember> extra_members = {},
                        const c::ReadLease &hidden_input = {}) {
  if (p.recipe.catchup) throw std::runtime_error("catchup requires its explicit between-iteration consumer");
  if (!s.enabled || (!p.recipe.fresh && !s.qualifies(from)))
    throw std::runtime_error("consumer refused index carry outside its iteration before prepare");
  const auto position = p.recipe.position;
  if (p.recipe.fresh && (s.scalar(from, kMlaCursor) != position ||
      s.scalar(from, kIndexCursor) != position || s.scalar(from, kPoolCount) != position / 4 ||
      s.scalar(from, kRingOffset) != position % std::int32_t(kRing) || s.scalar(from, kTailValid) != position % 4 ||
      s.scalar(from, kTailStart) != position - position % 4 || s.scalar(from, kLagCount) != 0))
    throw std::runtime_error("fresh finite preparation does not match actual pool/cursor state");
  if (!p.recipe.fresh && ((s.facts(from).producer_position + 1) % 4 != std::uint64_t(p.recipe.selected_tail) ||
      s.scalar(from, kLagCount) < 0 || s.scalar(from, kLagCount) >= kJournalRows))
    throw std::runtime_error("skip carry shape or accepted-feature journal exceeds its prepared domain");
  std::vector<c::ReadLease> arguments;
  for (std::size_t i = 0; i < kResources; ++i) arguments.push_back(s.member(from, i));
  if (hidden_input.valid()) arguments[kHiddenState] = hidden_input;
  arguments.push_back(upload(owner, sem::bytes(std::vector{pending})));
  const auto before = image(s, from);
  auto outputs = p.execute(queue, arguments);
  if (retained_nx) *retained_nx = outputs[p.recipe.nx];
  auto next = s.stage(from, p.recipe, outputs, extra_members);
  observe(s, from, next, p.recipe, outputs, hidden_input);
  EXPECT_EQ(image(s, from), before);
  EXPECT_EQ(s.scalar(next, kPending), pending);
  for (std::size_t i = 0; i < kResources; ++i)
    if (p.recipe.state_ports[i] != std::numeric_limits<std::size_t>::max())
      same_storage(s.member(next, i), outputs[p.recipe.state_ports[i]]);
  return next;
}

c::StateVersion catch_up(State &s, Program &p, c::Queue &queue,
                         const c::StateHead &accepted_head, const c::ReadLease &direct_nx = {}) {
  // Acceptance is the consumer's explicit head publication, not an arbitrary
  // readable speculative version nominated just because its lag count fits.
  const auto from = take(accepted_head.current(), "nominated accepted catchup head");
  if (!p.recipe.catchup || s.enabled || s.facts(from).epoch != s.epoch)
    throw std::runtime_error("catchup requires the sealed accepted epoch before a new iteration");
  const auto position = p.recipe.position;
  if (s.scalar(from, kLagCount) != 1 || s.scalar(from, kMlaCursor) != position + 1 ||
      s.scalar(from, kIndexCursor) != position || s.scalar(from, kPoolCount) != position / 4 ||
      s.scalar(from, kRingOffset) != position % std::int32_t(kRing) || s.scalar(from, kTailValid) != position % 4 ||
      s.scalar(from, kTailStart) != position - position % 4)
    throw std::runtime_error("accepted catchup journal does not match the finite producer domain");
  if (p.recipe.direct_catchup != direct_nx.valid())
    throw std::runtime_error("independent direct catchup requires its actual producer lease");
  std::vector<c::ReadLease> arguments;
  for (std::size_t i = 0; i < kResources; ++i) arguments.push_back(s.member(from, i));
  if (p.recipe.direct_catchup) arguments.push_back(direct_nx);
  const auto before = image(s, from);
  auto outputs = p.execute(queue, arguments);
  auto next = s.stage(from, p.recipe, outputs);
  const auto actual_nx = typed<float>(outputs[p.recipe.nx]);
  const auto journal = typed<float>(s.member(from, kJournal));
  EXPECT_TRUE(std::equal(actual_nx.begin(), actual_nx.end(), journal.begin()));
  if (direct_nx.valid()) EXPECT_EQ(actual_nx, typed<float>(direct_nx));
  observe_history(s, from, next, p.recipe, outputs, actual_nx);
  EXPECT_EQ(s.scalar(next, kLagCount), 0);
  EXPECT_EQ(read(s.member(next, kEpoch)), read(s.member(from, kEpoch))) << "catchup does not publish a new seed";
  for (std::size_t i = 0; i < kResources; ++i) {
    if (p.recipe.state_ports[i] == std::numeric_limits<std::size_t>::max())
      same_storage(s.member(next, i), s.member(from, i));
    else same_storage(s.member(next, i), outputs[p.recipe.state_ports[i]]);
  }
  EXPECT_EQ(image(s, from), before);
  return next;
}

// Engine policy can correct a rejected draft's next token. Even this small
// publication comes from an ordinary actual Graph output; no observed result
// is converted into a host-created replacement lease.
sem::Fragment pending_policy() {
  sem::Fragment f{.profile = kModel.profile, .region = 0x474c4d50454e44ULL};
  const auto input = f.input(sem::dense({1}, c::DataType::kInt32));
  f.outputs = {f.one(c::Operation(c::Copy{}), {input})}; return f;
}

// The actual draft-extend producer already wrote its epoch, position, full
// I32 selection and normalized hidden in one StateVersion. Selection of the
// last accepted row transfers those SAME leases to the decode loop; it does
// not manufacture a new seed by relabelling an old selection or hidden.
c::StateVersion activate_extend_seed(State &s, const c::StateHead &accepted_head,
                                    const c::StateVersion &producer,
                                    std::int32_t selected_position) {
  const auto accepted = take(accepted_head.current(), "last accepted draft-extend seed");
  const auto facts = s.facts(accepted), source = s.facts(producer);
  if (s.enabled || selected_position < 0 || facts.epoch != s.epoch || source.epoch != s.epoch ||
      facts.producer_position != std::uint64_t(selected_position) ||
      source.producer_position != facts.producer_position ||
      facts.reuse_count != 0 || source.reuse_count != 0 ||
      s.scalar(accepted, kMlaCursor) != selected_position + 1 ||
      s.scalar(accepted, kIndexCursor) != selected_position + 1 ||
      s.scalar(accepted, kLagCount) != 0)
    throw std::runtime_error("draft-extend seed is not the actual fresh last-accepted frontier of this epoch");
  for (std::size_t entry = 0; entry < kResources; ++entry) {
    if (entry == kPending) continue; // A target-policy bonus token may differ.
    const auto a = s.member(accepted, entry), b = s.member(producer, entry);
    const auto av = take(a.view(), "accepted seed member"), bv = take(b.view(), "actual seed producer member");
    if (av.resource() != bv.resource() || av.native_handle() != bv.native_handle() ||
        av.offset() != bv.offset() || av.size() != bv.size() || a.generation() != b.generation())
      throw std::runtime_error("accepted draft-extend seed spliced a different producer resource");
  }
  s.enabled = true;
  return accepted;
}

void run_seed_handoff(c::Context &context, const c::StorageOwner &owner, bool cuda,
                      std::shared_ptr<const OriginalNextn> original = {}) {
  // Fixed06992 eagle_worker_v2:293-302,936-990,1094-1103,1152-1153:
  // the seed producer is NextN draft-extend at the last ACCEPTED row, not
  // target43 and not draft-decode step0. These are bounded sequential M1
  // draft-extend rows, not a claim of a batched vendor extend kernel.
  const auto extend_recipe = [original](std::int32_t position) {
    auto r = build(true, position, 0, original); r.draft_extend = true;
    r.fragment.region = 0x474c4d455854454eULL;
    return r;
  };
  auto row_a = Program::create(extend_recipe(2054), context, owner, cuda);
  auto row_b = Program::create(extend_recipe(2055), context, owner, cuda);
  auto partial_next = Program::create(extend_recipe(2056), context, owner, cuda);
  auto full_next = Program::create(extend_recipe(2057), context, owner, cuda);
  auto tail3 = Program::create(build(false, 0, 3, original), context, owner, cuda);
  auto tail0 = Program::create(build(false, 0, 0, original), context, owner, cuda);
  auto tail1 = Program::create(build(false, 0, 1, original), context, owner, cuda);
  auto tail2 = Program::create(build(false, 0, 2, original), context, owner, cuda);
  auto partial_catchup = Program::create(build_catchup(false, 2055, original), context, owner, cuda);
  auto full_catchup = Program::create(build_catchup(false, 2056, original), context, owner, cuda);
  auto partial_direct = Program::create(build_catchup(true, 2055, original), context, owner, cuda);
  auto full_direct = Program::create(build_catchup(true, 2056, original), context, owner, cuda);
  Recipe policy_recipe; policy_recipe.fragment = pending_policy();
  auto policy = Program::create(std::move(policy_recipe), context, owner, cuda);
  auto queue = take(context.create_queue(), "draft-extend seed handoff queue");
  auto initializer = Program::create(initial_pool_recipe(), context, owner, cuda, 2);
  // Draft-extend consumes target hidden for EACH input position. Keep that
  // generated target-boundary input explicit instead of substituting the
  // preceding row's NextN output: h_(2053+row) pairs with x_(2054+row).
  // The actual target-tap chain is covered by
  // the separate TargetPrefix case; no full target model is claimed here.
  std::array<c::ReadLease, 4> target_hidden;
  for (std::size_t row = 0; row < target_hidden.size(); ++row)
    target_hidden[row] = upload(owner, sem::bytes(d5_gguf_test::activation(kHidden, 317 + int(row) * 14)));
  std::size_t submissions = 0;
  for (const int accepted_rows : {1, 2}) {
    // Count accepted extend rows, including the target-policy bonus row as
    // num_accept_tokens does; select_index=count-1, not correct-draft count.
    SCOPED_TRACE(accepted_rows);
    auto state = State::create(owner);
    {
      const auto base = state.initial(owner, initializer, queue, 2054); ++submissions;
      const auto base_bytes = image(state, base);
      auto head = take(c::StateHead::create(state.store, base), "single draft-extend/decode accepted head");
      const auto a = execute(state, row_a, queue, owner, base, 2, nullptr, {}, target_hidden[0]); ++submissions;
      const auto b = execute(state, row_b, queue, owner, a, 3, nullptr, {}, target_hidden[1]); ++submissions;
      const auto a_bytes = image(state, a), b_bytes = image(state, b);
      const auto &producer = accepted_rows == 1 ? a : b;
      const auto seed_position = 2053 + accepted_rows;
      c::StateVersion selected = producer;
      if (accepted_rows == 1) {
        // Row B was outside the accepted prefix. Target policy supplies its
        // bonus token3, preserving A's actual hidden, IDs and all history.
        const std::array inputs{upload(owner, sem::bytes(std::vector<std::int32_t>{3}))};
        auto output = policy.execute(queue, inputs); ++submissions;
        auto draft = take(state.store.begin(a), "last accepted extend row plus target bonus");
        check(draft.replace(state.entries[kPending], output[0]), "actual bonus-token policy output");
        selected = take(draft.finalize(), "one accepted extend row and its actual seed");
      }
      check(head.publish(base.identity(), selected), "select only the last accepted extend row as one version");
      EXPECT_FALSE(head.publish(base.identity(), b).ok());
      state.enabled = false;
      EXPECT_THROW((void)activate_extend_seed(state, head, producer, seed_position + 1), std::runtime_error);
      EXPECT_FALSE(state.enabled);
      const auto selected_bytes = image(state, selected);
      const auto seed = activate_extend_seed(state, head, producer, seed_position);
      EXPECT_EQ(image(state, seed), selected_bytes); // handoff changed no epoch or resource
      same_storage(state.member(seed, kSelection), state.member(producer, kSelection));
      same_storage(state.member(seed, kHiddenState), state.member(producer, kHiddenState));

      // Decode step0 consumes the extend seed immediately: no fresh indexer
      // submission, key/gate/pool update or dynamic extra tail is permitted.
      auto &decode = accepted_rows == 1 ? tail3 : tail0;
      const auto step0 = execute(state, decode, queue, owner, seed, 4); ++submissions;
      EXPECT_EQ(state.facts(step0).producer_position, std::uint64_t(seed_position));
      EXPECT_EQ(state.facts(step0).reuse_count, 1u);
      check(head.publish(selected.identity(), step0), "accept actual seed-reusing decode prefix");
      const auto step0_bytes = image(state, step0);
      state.enabled = false;
      EXPECT_THROW((void)activate_extend_seed(state, head, producer, seed_position), std::runtime_error);
      auto &journal = accepted_rows == 1 ? partial_catchup : full_catchup;
      const auto caught = catch_up(state, journal, queue, head); ++submissions;
      check(head.publish(step0.identity(), caught), "publish only accepted skip-feature history");
      const auto caught_bytes = image(state, caught);
      // Skip publishes an actual Copy of the seed IDs. Catchup retains that
      // accepted step0 lease; it must not revert to the earlier seed backing.
      same_storage(state.member(caught, kSelection), state.member(step0, kSelection));
      EXPECT_EQ(read(state.member(caught, kSelection)), read(state.member(seed, kSelection)));
      same_storage(state.member(caught, kHiddenState), state.member(step0, kHiddenState));

      // A new epoch needs an ACTUAL new draft-extend execution. No copying
      // epoch7 metadata onto an old selection can qualify it for epoch8.
      state.epoch = 8;
      EXPECT_THROW((void)activate_extend_seed(state, head, producer, seed_position), std::runtime_error);
      EXPECT_THROW((void)execute(state, decode, queue, owner, seed, 5), std::runtime_error);
      state.enabled = true;
      auto &next_extend = accepted_rows == 1 ? partial_next : full_next;
      const auto next_producer = execute(state, next_extend, queue, owner, caught, 5, nullptr, {},
          target_hidden[std::size_t(accepted_rows + 1)]); ++submissions;
      check(head.publish(caught.identity(), next_producer), "publish actual next-epoch extend seed");
      state.enabled = false;
      const auto next_seed = activate_extend_seed(state, head, next_producer, seed_position + 2);
      EXPECT_EQ(state.facts(next_seed).epoch, 8u);
      EXPECT_NE(read(state.member(next_seed, kSelection)), read(state.member(seed, kSelection)));
      auto &next_decode = accepted_rows == 1 ? tail1 : tail2;
      const auto next_step0 = execute(state, next_decode, queue, owner, next_seed, 6); ++submissions;
      check(head.publish(next_producer.identity(), next_step0), "publish next epoch's seed-reusing step0");
      const auto final_bytes = image(state, next_step0);

      // Independent accepted-only execution starts from BASE. In prefix1 it
      // never executes B; its actual skip nx feeds the direct history writer
      // instead of the journal Gather. No speculative bytes are rebound.
      state.epoch = 7; state.enabled = true;
      const auto reference_a = execute(state, row_a, queue, owner, base,
          accepted_rows == 1 ? 3 : 2, nullptr, {}, target_hidden[0]); ++submissions;
      c::StateVersion reference_producer = reference_a;
      if (accepted_rows == 2) {
        reference_producer = execute(state, row_b, queue, owner, reference_a, 3, nullptr, {}, target_hidden[1]); ++submissions;
      }
      EXPECT_EQ(image(state, reference_producer), selected_bytes);
      check(head.publish(next_step0.identity(), reference_producer), "nominate independently executed accepted extend prefix");
      state.enabled = false;
      const auto reference_seed = activate_extend_seed(state, head, reference_producer, seed_position);
      c::ReadLease independent_nx;
      const auto reference_step0 = execute(state, decode, queue, owner, reference_seed, 4, &independent_nx); ++submissions;
      check(head.publish(reference_producer.identity(), reference_step0), "publish independent accepted skip");
      EXPECT_EQ(image(state, reference_step0), step0_bytes);
      state.enabled = false;
      auto &direct = accepted_rows == 1 ? partial_direct : full_direct;
      const auto reference_caught = catch_up(state, direct, queue, head, independent_nx); ++submissions;
      check(head.publish(reference_step0.identity(), reference_caught), "publish independent direct accepted history");
      EXPECT_EQ(image(state, reference_caught), caught_bytes);
      state.epoch = 8; state.enabled = true;
      const auto reference_next = execute(state, next_extend, queue, owner, reference_caught, 5, nullptr, {},
          target_hidden[std::size_t(accepted_rows + 1)]); ++submissions;
      check(head.publish(reference_caught.identity(), reference_next), "publish independently produced new seed");
      state.enabled = false;
      const auto reference_next_seed = activate_extend_seed(state, head, reference_next, seed_position + 2);
      const auto reference_final = execute(state, next_decode, queue, owner, reference_next_seed, 6); ++submissions;
      check(head.publish(reference_next.identity(), reference_final), "publish independently continued seed step0");
      EXPECT_EQ(image(state, reference_final), final_bytes);
      EXPECT_EQ(image(state, base), base_bytes); EXPECT_EQ(image(state, a), a_bytes); EXPECT_EQ(image(state, b), b_bytes);
      EXPECT_EQ(image(state, selected), selected_bytes); EXPECT_EQ(image(state, step0), step0_bytes);
      EXPECT_EQ(image(state, caught), caught_bytes); EXPECT_FALSE(state.member(producer, kHiddenState).try_write());
      state.enabled = false;
    }
    check(state.store.collect(), "retire bounded seed producer and decode branches");
    EXPECT_EQ(state.store.stats().versions, 0u); EXPECT_EQ(state.store.stats().drafts, 0u);
  }
  for (const auto *program : {&initializer, &row_a, &row_b, &partial_next, &full_next, &tail3, &tail0, &tail1, &tail2,
       &partial_catchup, &full_catchup, &partial_direct, &full_direct, &policy}) {
    EXPECT_EQ(program->outputs.stats().live_blocks, 0u); EXPECT_EQ(program->outputs.stats().active_uses, 0u);
    for (std::size_t i = 0; i < program->parameters.size(); ++i)
      EXPECT_EQ(read(program->parameters[i]), program->recipe.fragment.constant_bytes[program->parameter_slots[i]]);
  }
  EXPECT_EQ(submissions, 26u);
  ::testing::Test::RecordProperty("initialization_submissions", 2);
  ::testing::Test::RecordProperty("logical_index_state_bytes", std::to_string(kPoolCapacity * (kIndexDepth + 4) + kRing * kIndexDepth * 4));
  ::testing::Test::RecordProperty("actual_submissions", int(submissions));
  ::testing::Test::RecordProperty("draft_extend_submissions", 11);
  ::testing::Test::RecordProperty("skip_submissions", 8);
  ::testing::Test::RecordProperty("catchup_submissions", 4);
  ::testing::Test::RecordProperty("policy_submissions", 1);
  ::testing::Test::RecordProperty("backend", cuda ? "ordinary CUDA Graph" : "ordinary CPU Graph");
  ::testing::Test::RecordProperty("journey", "draft-extend A2054/B2055->last accepted row1/2 actual hidden+full2051IDs->step0 immediately skips entire indexer->accepted nx catchup->actual epoch8 extend->step0 skip; independent accepted-only base execution/direct nx reference");
  if (original) {
    for (std::size_t i = 0; i < original->prefix_roles.size(); ++i) {
      auto reader = original->prefix_roles[i].lease; EXPECT_FALSE(reader.try_write());
      const auto expected = original_prefix::payload(original->prefix, static_cast<original_prefix::Parameter>(i));
      EXPECT_EQ(read(reader), Bytes(expected.begin(), expected.end()));
    }
    for (std::size_t i = 0; i < original->indexer_roles.size(); ++i) {
      auto reader = original->indexer_roles[i].lease; EXPECT_FALSE(reader.try_write());
      EXPECT_EQ(read(reader), original_index::payload(original->indexer, static_cast<original_index::Parameter>(i)));
    }
    ::testing::Test::RecordProperty("original_roles", 14);
    ::testing::Test::RecordProperty("original_role_bytes", 88373248);
    ::testing::Test::RecordProperty("original_runtime_bank_bytes", 88636928);
    ::testing::Test::RecordProperty("scope", "official HF GLM-5.3-Flash eb9eb208 layer45 original7 input/query+original7 indexer in the existing complete sequential M1 NextN seed/catchup journey; explicit generated target-hidden/embedding and MLA/MoE/head remainder; no primaryGGUF tensor equality,full target,original shared LM,natural acceptance,vendorpage ABI or throughput claim");
  } else ::testing::Test::RecordProperty("scope", "generated selected Flash primary GGUF/F32 sequential M1 draft-extend seed protocol; generated per-position target-hidden boundary; default UE8M0 logical cache/query and BF16 raw rings; no target43 MLA/indexer composition,batched vendor extend kernel,full target,original weights,vendorpage ABI,natural acceptance or throughput claim");
}

void run(c::Context &context, const c::StorageOwner &owner, bool cuda) {
  auto fresh = Program::create(build(true), context, owner, cuda);
  auto skip = Program::create(build(false), context, owner, cuda);
  Recipe policy_recipe; policy_recipe.fragment = pending_policy();
  auto policy = Program::create(std::move(policy_recipe), context, owner, cuda);
  auto queue = take(context.create_queue(), "complete component queue");
  auto initializer = Program::create(initial_pool_recipe(), context, owner, cuda, 2);
  auto state = State::create(owner);
  std::size_t native_submissions = 0;
  {
    const auto base = state.initial(owner, initializer, queue); ++native_submissions;
    const auto base_bytes = image(state, base);
    auto head = take(c::StateHead::create(state.store, base), "whole component shared head");
    const auto first = execute(state, fresh, queue, owner, base, 2); ++native_submissions;
    const auto first_bytes = image(state, first);
    const auto rejected_tail = execute(state, skip, queue, owner, first, 4); ++native_submissions;
    const auto rejected_bytes = image(state, rejected_tail);
    EXPECT_EQ(state.scalar(rejected_tail, kMlaCursor), kBasePosition + 2);
    EXPECT_EQ(state.scalar(rejected_tail, kIndexCursor), kBasePosition + 1);
    EXPECT_EQ(state.facts(rejected_tail).reuse_count, 1u);
    // An explicit target policy chooses token3 instead of the draft's token2.
    const std::array correction_input{upload(owner, sem::bytes(std::vector<std::int32_t>{3}))};
    auto correction = policy.execute(queue, correction_input); ++native_submissions;
    auto accepted_draft = take(state.store.begin(first), "accepted prefix plus explicit policy token");
    check(accepted_draft.replace(state.entries[kPending], correction[0]), "actual corrected pending output");
    const auto accepted = take(accepted_draft.finalize(), "complete accepted prefix1");
    check(head.publish(base.identity(), accepted), "atomically publish complete prefix1");
    EXPECT_FALSE(head.publish(base.identity(), rejected_tail).ok()) << "stale prefix2 must not replace the accepted head";
    EXPECT_EQ(image(state, take(head.current(), "actual accepted head")), image(state, accepted));
    // No part of token2's MLA append enters the accepted/draft continuation.
    EXPECT_EQ(image(state, first), first_bytes);
    const auto accepted_cache = read(state.member(accepted, kCache));
    const auto rejected_cache = read(state.member(rejected_tail, kCache));
    EXPECT_FALSE(std::equal(accepted_cache.begin() + (kBasePosition + 1) * kLatent * 4,
        accepted_cache.begin() + (kBasePosition + 2) * kLatent * 4,
        rejected_cache.begin() + (kBasePosition + 1) * kLatent * 4));
    const auto continued = execute(state, skip, queue, owner, take(head.current(), "continue actual accepted head"), 5); ++native_submissions;
    check(head.publish(accepted.identity(), continued), "publish prefix1 continuation as a whole");
    // Independent recomputation starts from the retained BASE leases, with
    // target-correct token3 already chosen. No first-run result is rebound.
    const auto independent_first = execute(state, fresh, queue, owner, base, 3); ++native_submissions;
    EXPECT_EQ(image(state, accepted), image(state, independent_first));
    const auto independent_next = execute(state, skip, queue, owner, independent_first, 5); ++native_submissions;
    EXPECT_EQ(image(state, continued), image(state, independent_next));
    EXPECT_NE(read(state.member(continued, kCache)), read(state.member(rejected_tail, kCache)));
    // Prefix2 is valid only when explicitly accepted on its own base branch.
    auto all = take(c::StateHead::create(state.store, base), "independent full-prefix branch");
    check(all.publish(base.identity(), rejected_tail), "explicitly accept prefix2 on its own branch");
    const auto branch = execute(state, skip, queue, owner, take(all.current(), "retained prefix2 branch"), 6); ++native_submissions;
    check(all.publish(rejected_tail.identity(), branch), "publish old branch continuation");
    EXPECT_EQ(state.scalar(branch, kMlaCursor), kBasePosition + 3);
    EXPECT_EQ(state.scalar(branch, kIndexCursor), kBasePosition + 1);
    EXPECT_EQ(image(state, rejected_tail), rejected_bytes);
    EXPECT_EQ(image(state, base), base_bytes);
    // A cancelled multi-member transaction after staging one actual resource
    // cannot expose it or the invalid pending extent through the shared head.
    const auto before_cancel = image(state, take(head.current(), "head before failed candidate"));
    auto cancelled = take(state.store.begin(continued), "failed whole-state candidate");
    check(cancelled.replace(state.entries[kHiddenState], state.member(first, kHiddenState)), "stage candidate hidden only");
    EXPECT_FALSE(cancelled.replace(state.entries[kPending], state.member(first, kHiddenState)).ok());
    check(cancelled.cancel(), "discard incomplete candidate");
    EXPECT_EQ(image(state, take(head.current(), "head after cancellation")), before_cancel);
    state.enabled = false;
    EXPECT_FALSE(state.qualifies(continued)); EXPECT_FALSE(state.qualifies(rejected_tail));
    EXPECT_THROW((void)execute(state, skip, queue, owner, continued, 6), std::runtime_error);
    EXPECT_EQ(image(state, first), first_bytes); EXPECT_EQ(image(state, base), base_bytes);
    EXPECT_FALSE(state.member(first, kCache).try_write());
  }
  check(state.store.collect(), "retire all complete component versions");
  EXPECT_EQ(state.store.stats().versions, 0u); EXPECT_EQ(state.store.stats().drafts, 0u);
  for (const auto *program : {&initializer, &fresh, &skip, &policy}) {
    EXPECT_EQ(program->outputs.stats().live_blocks, 0u); EXPECT_EQ(program->outputs.stats().active_uses, 0u);
    for (std::size_t i = 0; i < program->parameters.size(); ++i)
      EXPECT_EQ(read(program->parameters[i]), program->recipe.fragment.constant_bytes[program->parameter_slots[i]]);
  }
  EXPECT_EQ(native_submissions, 8u);
  ::testing::Test::RecordProperty("initialization_submissions", 1);
  ::testing::Test::RecordProperty("logical_index_state_bytes", std::to_string(kPoolCapacity * (kIndexDepth + 4) + kRing * kIndexDepth * 4));
  ::testing::Test::RecordProperty("actual_submissions", int(native_submissions));
  ::testing::Test::RecordProperty("backend", cuda ? "ordinary CUDA Graph" : "ordinary CPU Graph");
  ::testing::Test::RecordProperty("component_schema", "17 native resources plus explicit iteration policy; BF16 raw key/score rings,E4 pools/F32 scales,complete NextN/indexer state and bounded nx journal/lag count");
  ::testing::Test::RecordProperty("scope", "generated primary GGUF/F32 single complete NextN component; fresh K4 closepool->actual I32 sparse MLA/MoE; same-epoch entire-indexer skip; default UE8M0 logical cache/query and BF16 raw rings; no original checkpoint/full target/KDA/mHC/vendorpage ABI/natural acceptance");
  ::testing::Test::RecordProperty("prefixes", "0 retained;1 corrected-pending atomic publish and independent base recomputation;2 independent branch; rejected tail/cancel/stale publish/old readonly ownership");
  ::testing::Test::RecordProperty("uncovered", "this case is single-epoch; cross-epoch catchup is covered by the separate AcceptedJournal cases; target KDA/conv/mHC,original projection weights,vendorpage ABI and vocabulary/natural acceptance remain separate");
}

void run_catchup(c::Context &context, const c::StorageOwner &owner, bool cuda) {
  // One two-input proposal crosses a real K4 boundary: A at2054 produces a
  // three-token unpooled tail, B at2055 skips the entire indexer. Prefix1
  // rejects B; prefix2 must catch up exactly its accepted nx row before the
  // next iteration. These are two required branches, not a shape matrix.
  auto first_plan = Program::create(build(true, 2054), context, owner, cuda);
  auto partial_plan = Program::create(build(true, 2055), context, owner, cuda);
  auto full_plan = Program::create(build(true, 2056), context, owner, cuda);
  auto skip = Program::create(build(false, 0, 3), context, owner, cuda);
  auto journal = Program::create(build_catchup(), context, owner, cuda);
  auto direct = Program::create(build_catchup(true), context, owner, cuda);
  Recipe policy_recipe; policy_recipe.fragment = pending_policy();
  auto policy = Program::create(std::move(policy_recipe), context, owner, cuda);
  auto queue = take(context.create_queue(), "accepted journal consumer queue");
  auto initializer = Program::create(initial_pool_recipe(), context, owner, cuda, 2);
  std::size_t submissions = 0;
  for (const int accepted_rows : {1, 2}) {
    SCOPED_TRACE(accepted_rows);
    auto state = State::create(owner);
    {
      const auto base = state.initial(owner, initializer, queue, 2054); ++submissions;
      const auto base_bytes = image(state, base);
      auto head = take(c::StateHead::create(state.store, base), "accepted-journal whole-state head");
      const auto first = execute(state, first_plan, queue, owner, base, 2); ++submissions;
      const auto first_bytes = image(state, first);
      const auto second = execute(state, skip, queue, owner, first, 4); ++submissions;
      const auto second_bytes = image(state, second);
      EXPECT_EQ(state.scalar(first, kMlaCursor), 2055); EXPECT_EQ(state.scalar(first, kIndexCursor), 2055);
      EXPECT_EQ(state.scalar(first, kTailValid), 3); EXPECT_EQ(state.scalar(first, kLagCount), 0);
      EXPECT_EQ(state.scalar(second, kMlaCursor), 2056); EXPECT_EQ(state.scalar(second, kIndexCursor), 2055);
      EXPECT_EQ(state.scalar(second, kLagCount), 1);
      c::StateVersion accepted = second;
      if (accepted_rows == 1) {
        // B's input token2 is rejected; a real ordinary policy Copy chooses
        // token3. No B feature/journal/cursor is spliced into prefix1.
        const std::array policy_input{upload(owner, sem::bytes(std::vector<std::int32_t>{3}))};
        auto output = policy.execute(queue, policy_input); ++submissions;
        auto candidate = take(state.store.begin(first), "prefix1 pending correction");
        check(candidate.replace(state.entries[kPending], output[0]), "actual target-policy token permission");
        accepted = take(candidate.finalize(), "complete prefix1 with target policy");
        EXPECT_EQ(state.scalar(accepted, kLagCount), 0);
        same_storage(state.member(accepted, kJournal), state.member(base, kJournal));
      }
      check(head.publish(base.identity(), accepted), "publish only the chosen complete accepted prefix");
      EXPECT_FALSE(head.publish(base.identity(), second).ok());
      const auto accepted_bytes = image(state, accepted);
      auto cancelled = take(state.store.begin(accepted), "failed journal splice");
      check(cancelled.replace(state.entries[kJournal], state.member(second, kJournal)), "stage a speculative journal permission");
      EXPECT_FALSE(cancelled.replace(state.entries[kLagCount], state.member(second, kJournal)).ok());
      check(cancelled.cancel(), "cancel incomplete journal transaction");
      EXPECT_EQ(image(state, take(head.current(), "head after rejected journal splice")), accepted_bytes);

      state.enabled = false; // source finally: old IDs cease to qualify.
      EXPECT_FALSE(state.qualifies(first)); EXPECT_FALSE(state.qualifies(second));
      EXPECT_THROW((void)execute(state, skip, queue, owner, accepted, 5), std::runtime_error);
      c::StateVersion caught = accepted;
      if (accepted_rows == 2) {
        caught = catch_up(state, journal, queue, head); ++submissions;
        check(head.publish(accepted.identity(), caught), "publish index catchup with its actual counters");
        EXPECT_EQ(state.scalar(caught, kIndexCursor), 2056);
        EXPECT_EQ(state.scalar(caught, kMlaCursor), 2056);
        EXPECT_EQ(state.scalar(caught, kLagCount), 0);
        EXPECT_EQ(state.scalar(caught, kPoolCount), 514); EXPECT_EQ(state.scalar(caught, kTailValid), 0);
        same_storage(state.member(caught, kCache), state.member(accepted, kCache));
        same_storage(state.member(caught, kHiddenState), state.member(accepted, kHiddenState));
        same_storage(state.member(caught, kSelection), state.member(accepted, kSelection));
      } else {
        // Rejected B cannot make a valid catchup input. This refuses before
        // any preparation or native submission, even though B remains readable.
        EXPECT_THROW((void)catch_up(state, journal, queue, head), std::runtime_error);
      }
      const auto caught_bytes = image(state, caught);
      state.epoch = 8; state.enabled = true;
      auto &next_plan = accepted_rows == 1 ? partial_plan : full_plan;
      const auto next = execute(state, next_plan, queue, owner, take(head.current(), "caught-up next-iteration head"), 5); ++submissions;
      check(head.publish(caught.identity(), next), "publish actual epoch8 fresh seed and NextN state");
      EXPECT_EQ(state.facts(next).epoch, 8u);
      EXPECT_EQ(state.facts(next).producer_position, std::uint64_t(2054 + accepted_rows));
      EXPECT_TRUE(state.qualifies(next)); EXPECT_FALSE(state.qualifies(first)); EXPECT_FALSE(state.qualifies(accepted));
      EXPECT_NE(read(state.member(next, kSelection)), read(state.member(first, kSelection))) << "fresh generated IDs must replace the old tail seed";
      EXPECT_THROW((void)execute(state, skip, queue, owner, accepted, 5), std::runtime_error);

      // Independent accepted-sequence execution starts from BASE. The full
      // branch retains its actual independent B nx result and feeds that
      // lease directly into the ordinary history writer, avoiding the real
      // journal Gather path. Math is separately checked at every boundary.
      state.epoch = 7; state.enabled = true;
      const auto reference_first = execute(state, first_plan, queue, owner, base, accepted_rows == 1 ? 3 : 2); ++submissions;
      c::StateVersion reference_caught = reference_first;
      c::ReadLease independent_nx;
      if (accepted_rows == 2) {
        const auto reference_second = execute(state, skip, queue, owner, reference_first, 4, &independent_nx); ++submissions;
        state.enabled = false;
        auto reference_head = take(c::StateHead::create(state.store, reference_second), "independent accepted prefix2 head");
        reference_caught = catch_up(state, direct, queue, reference_head, independent_nx); ++submissions;
      }
      EXPECT_EQ(image(state, reference_caught), caught_bytes);
      state.epoch = 8; state.enabled = true;
      const auto reference_next = execute(state, next_plan, queue, owner, reference_caught, 5); ++submissions;
      EXPECT_EQ(image(state, next), image(state, reference_next));
      EXPECT_EQ(image(state, base), base_bytes); EXPECT_EQ(image(state, first), first_bytes);
      EXPECT_EQ(image(state, second), second_bytes); EXPECT_EQ(image(state, accepted), accepted_bytes);
      EXPECT_EQ(image(state, caught), caught_bytes);
      EXPECT_FALSE(state.member(second, kJournal).try_write());
      state.enabled = false;
      EXPECT_FALSE(state.qualifies(next)); EXPECT_FALSE(state.qualifies(first));
    }
    check(state.store.collect(), "retire accepted journal branch states");
    EXPECT_EQ(state.store.stats().versions, 0u); EXPECT_EQ(state.store.stats().drafts, 0u);
  }
  for (const auto *program : {&initializer, &first_plan, &partial_plan, &full_plan, &skip, &journal, &direct, &policy}) {
    EXPECT_EQ(program->outputs.stats().live_blocks, 0u); EXPECT_EQ(program->outputs.stats().active_uses, 0u);
    for (std::size_t i = 0; i < program->parameters.size(); ++i)
      EXPECT_EQ(read(program->parameters[i]), program->recipe.fragment.constant_bytes[program->parameter_slots[i]]);
  }
  EXPECT_EQ(submissions, 16u);
  ::testing::Test::RecordProperty("initialization_submissions", 2);
  ::testing::Test::RecordProperty("logical_index_state_bytes", std::to_string(kPoolCapacity * (kIndexDepth + 4) + kRing * kIndexDepth * 4));
  ::testing::Test::RecordProperty("actual_submissions", int(submissions));
  ::testing::Test::RecordProperty("fresh_submissions", 8);
  ::testing::Test::RecordProperty("skip_submissions", 3);
  ::testing::Test::RecordProperty("catchup_submissions", 2);
  ::testing::Test::RecordProperty("policy_submissions", 1);
  ::testing::Test::RecordProperty("backend", cuda ? "ordinary CUDA Graph" : "ordinary CPU Graph");
  ::testing::Test::RecordProperty("journal", "actual nx[2,4096] with I32 valid lag count; selected StateVersion determines accepted input; no eager indexer during skip");
  ::testing::Test::RecordProperty("journey", "base2054 tail2; accept1 rejects B and fresh2055 closes pool; accept2 catches actual accepted B2055 then fresh2056 appends tail1; independent actual nx direct-input reference");
  ::testing::Test::RecordProperty("scope", "generated selected GGUF/F32 NextN cross-epoch accepted-feature catchup and fresh seed; default UE8M0 logical cache/query and BF16 raw rings; no target KDA/conv/mHC,original projection weights,vendorpage ABI or natural acceptance claim");
}

namespace target = glm_mtp_target_component;
enum TargetEntry : std::size_t {
  kTargetHistory = kEntries, kTargetState, kTargetTap, kTargetCursor
};
constexpr std::size_t kTarget43Begin = kTargetCursor + 1;
struct Target43Result final {
  std::vector<c::ReadLease> outputs;
  SparseSnapshot state;
  c::ReadLease mhc;
};
SparseSnapshot target43_snapshot(const State &state, const c::StateVersion &version) {
  SparseSnapshot result;
  for (std::size_t i = 0; i < kSparseEntries.size(); ++i) result.values[i] = state.member(version, kTarget43Begin + i);
  return result;
}
Target43Result execute_target43(Program &program, c::Queue &queue,
                               const SparseSnapshot &before, const c::ReadLease &residual) {
  const SparseAccess access;
  const auto position = program.recipe.position;
  if (!program.recipe.fresh || access.scalar(before, kMlaCursor) != position ||
      access.scalar(before, kIndexCursor) != position || access.scalar(before, kPoolCount) != position / 4 ||
      access.scalar(before, kRingOffset) != position % std::int32_t(kRing) ||
      access.scalar(before, kTailValid) != position % 4 || access.scalar(before, kTailStart) != position - position % 4)
    throw std::runtime_error("target43 actual cache frontier does not match its prepared attention domain");
  std::vector<c::ReadLease> input{residual}; input.insert(input.end(), before.values.begin(), before.values.end());
  Target43Result result; result.outputs = program.execute(queue, input); result.state = before;
  for (std::size_t i = 0; i < kSparseEntries.size(); ++i) {
    const auto port = program.recipe.state_ports[kSparseEntries[i]];
    if (port != std::numeric_limits<std::size_t>::max()) result.state.values[i] = result.outputs[port];
  }
  const auto nx = typed<float>(result.outputs[program.recipe.nx]);
  observe_attention(access, before, result.state, program.recipe, result.outputs, nx, position);
  // The actual MLA projection was independently checked above. Use its actual
  // bounded result to check the next mHC/FFN boundary, never to create input.
  const auto expected = program.recipe.target43_reference(typed<float>(residual), typed<float>(result.outputs[program.recipe.output]));
  for (std::size_t i = 0; i < target43::Ports::count; ++i) {
    SCOPED_TRACE(target43::kPortNames[i]);
    sem::expect_output(program.recipe.fragment, typed<float>(result.outputs[program.recipe.target43_ports[i]]), expected[i]);
  }
  result.mhc = result.outputs[program.recipe.target43_ports[target43::Ports::mhc]];
  return result;
}

std::vector<float> target_residual_values(std::int32_t token) {
  // Generated preceding-layer input for THIS token. Each stream is distinct;
  // no previous token's mHC output or observed result is recreated here.
  std::vector<float> values;
  for (std::int32_t stream = 0; stream < target::kStreams; ++stream) {
    auto row = d5_gguf_test::activation(kHidden, 73 + 14 * token + 19 * stream);
    for (auto &value : row) value += float(stream) / 32.0F;
    values.insert(values.end(), row.begin(), row.end());
  }
  return values;
}

void run_target(c::Context &context, const c::StorageOwner &owner, bool cuda) {
  auto component = target::build();
  const auto ports = component.ports;
  auto target_reference = std::move(component.evaluate);
  Recipe target_recipe; target_recipe.state_ports.fill(std::numeric_limits<std::size_t>::max());
  target_recipe.fragment = std::move(component.fragment); // one native constant bank
  const auto cursor = target_recipe.fragment.input(sem::dense({1}, c::DataType::kInt32));
  const auto cursor_port = expose(target_recipe, increment(target_recipe.fragment, cursor));
  // Ten bounded result generations retain the actual base/partial/full and
  // independent branches. The default remains five for existing consumers.
  auto target_plan = Program::create(std::move(target_recipe), context, owner, cuda, 10);
  auto first_plan = Program::create(build(true, 2054), context, owner, cuda);
  auto partial_plan = Program::create(build(true, 2055), context, owner, cuda);
  auto full_plan = Program::create(build(true, 2056), context, owner, cuda);
  auto skip = Program::create(build(false, 0, 3), context, owner, cuda);
  auto journal = Program::create(build_catchup(), context, owner, cuda);
  auto direct = Program::create(build_catchup(true), context, owner, cuda);
  Recipe policy_recipe; policy_recipe.fragment = pending_policy();
  auto policy = Program::create(std::move(policy_recipe), context, owner, cuda);
  auto queue = take(context.create_queue(), "combined target/NextN queue");
  auto initializer = Program::create(initial_pool_recipe(), context, owner, cuda, 2);
  std::size_t submissions = 0, target_submissions = 0, peak_backing = 0;
  const auto target_run = [&](std::span<const c::ReadLease> inputs) {
    const auto expected = target_reference(typed<float>(inputs[0]),
        typed<float>(inputs[1]), typed<float>(inputs[2]));
    auto output = target_plan.execute(queue, inputs); ++submissions; ++target_submissions;
    for (std::size_t port = 0; port < target::Ports::count; ++port) {
      SCOPED_TRACE(target::kPortNames[port]);
      sem::expect_output(target_plan.recipe.fragment, typed<float>(output[port]), expected[port]);
    }
    EXPECT_EQ(typed<std::int32_t>(output[cursor_port]).at(0), typed<std::int32_t>(inputs[3]).at(0) + 1);
    return output;
  };
  std::vector<c::ReadLease> warmup;
  {
    std::vector<float> history(3 * target::kChannels), matrix(target::kHeads * target::kDepth * target::kDepth);
    for (std::size_t i = 0; i < history.size(); ++i) history[i] = float(std::sin(double(i) * 0.013) * 0.01);
    for (std::size_t i = 0; i < matrix.size(); ++i) matrix[i] = float(std::sin(double(i) * 0.007) * 0.0005);
    const std::array inputs{upload(owner, sem::bytes(target_residual_values(0))),
        upload(owner, sem::bytes(history)), upload(owner, sem::bytes(matrix)),
        upload(owner, sem::bytes(std::vector<std::int32_t>{2053}))};
    warmup = target_run(inputs); // actual previous-token target tap, not a host seed
  }
  const std::array extra_specs{
      c::StateEntrySpec{.description = target_plan.recipe.fragment.description(target_plan.recipe.fragment.outputs[ports.history]), .resource = owner.ref()},
      c::StateEntrySpec{.description = target_plan.recipe.fragment.description(target_plan.recipe.fragment.outputs[ports.state]), .resource = owner.ref()},
      c::StateEntrySpec{.description = target_plan.recipe.fragment.description(target_plan.recipe.fragment.outputs[ports.tap]), .resource = owner.ref()},
      c::StateEntrySpec{.description = sem::dense({1}, c::DataType::kInt32), .resource = owner.ref()}};
  constexpr std::size_t state_budget = 512u << 20;
  for (const int accepted_rows : {1, 2}) {
    SCOPED_TRACE(accepted_rows);
    // The larger fixed budget accounts actual root backing capacities retained
    // by both KDA/history and NextN branches. It does not disable accounting.
    auto state = State::create(owner, extra_specs, state_budget);
    {
      const auto target_members = [&](std::span<const c::ReadLease> output) {
        return std::array{c::StateMember{state.entries[kTargetHistory], output[ports.history]},
            c::StateMember{state.entries[kTargetState], output[ports.state]},
            c::StateMember{state.entries[kTargetTap], output[ports.tap]},
            c::StateMember{state.entries[kTargetCursor], output[cursor_port]}};
      };
      const auto initial_target = target_members(warmup);
      const auto base = state.initial(owner, initializer, queue, 2054, initial_target, warmup[ports.tap]); ++submissions;
      same_storage(state.member(base, kHiddenState), state.member(base, kTargetTap));
      const auto base_bytes = image(state, base);
      auto head = take(c::StateHead::create(state.store, base), "single combined target/NextN head");
      const auto combined = [&](Program &plan, const c::StateVersion &from,
                                std::int32_t pending, bool target_seed,
                                c::ReadLease *retained_nx = nullptr) {
        if (!state.enabled || (!plan.recipe.fresh && !state.qualifies(from)))
          throw std::runtime_error("combined consumer refused stale epoch before target preparation");
        if (typed<std::int32_t>(state.member(from, kTargetCursor)).at(0) != state.scalar(from, kMlaCursor))
          throw std::runtime_error("target/NextN accepted token frontiers differ");
        if (target_seed && !plan.recipe.fresh)
          throw std::runtime_error("target seed is only bound at a fresh NextN iteration");
        const auto before = image(state, from);
        const std::array target_inputs{upload(owner, sem::bytes(target_residual_values(state.scalar(from, kPending)))),
            state.member(from, kTargetHistory), state.member(from, kTargetState), state.member(from, kTargetCursor)};
        auto produced = target_run(target_inputs);
        const auto members = target_members(produced);
        const auto seed = target_seed ? state.member(from, kTargetTap) : c::ReadLease{};
        // Target verifies the current pending token, while NextN receives the
        // PREVIOUS target tap (fresh) or actual draft hidden (same-epoch skip).
        // Both sets of results enter exactly one StateDraft/finalize below.
        auto next = execute(state, plan, queue, owner, from, pending, retained_nx, members, seed); ++submissions;
        for (const auto &member : members)
          same_storage(take(next.member(member.entry), "combined actual target output"), member.resource);
        EXPECT_EQ(typed<std::int32_t>(state.member(next, kTargetCursor)).at(0), state.scalar(next, kMlaCursor));
        EXPECT_EQ(image(state, from), before);
        peak_backing = std::max(peak_backing, state.store.stats().backing_bytes);
        EXPECT_LE(state.store.stats().backing_bytes, state_budget);
        return next;
      };
      const auto first = combined(first_plan, base, 2, true);
      const auto first_bytes = image(state, first);
      const auto second = combined(skip, first, 4, false);
      const auto second_bytes = image(state, second);
      EXPECT_NE(read(state.member(first, kTargetState)), read(state.member(second, kTargetState)));
      c::StateVersion accepted = second;
      if (accepted_rows == 1) {
        const std::array input{upload(owner, sem::bytes(std::vector<std::int32_t>{3}))};
        auto output = policy.execute(queue, input); ++submissions;
        auto draft = take(state.store.begin(first), "combined prefix1 target-policy correction");
        check(draft.replace(state.entries[kPending], output[0]), "correct only actual pending token");
        accepted = take(draft.finalize(), "one complete target/draft accepted prefix1");
        for (std::size_t entry = kTargetHistory; entry <= kTargetCursor; ++entry)
          same_storage(state.member(accepted, entry), state.member(first, entry));
      }
      check(head.publish(base.identity(), accepted), "atomically accept target/draft same prefix");
      EXPECT_FALSE(head.publish(base.identity(), second).ok());
      const auto accepted_bytes = image(state, accepted);
      auto cancelled = take(state.store.begin(accepted), "incomplete combined target splice");
      check(cancelled.replace(state.entries[kTargetTap], state.member(second, kTargetTap)), "stage target-only speculative member");
      EXPECT_FALSE(cancelled.replace(state.entries[kTargetHistory], state.member(first, kPending)).ok());
      check(cancelled.cancel(), "cancel incomplete combined transaction");
      EXPECT_EQ(image(state, take(head.current(), "combined head after cancellation")), accepted_bytes);
      state.enabled = false;
      EXPECT_THROW((void)execute(state, skip, queue, owner, accepted, 5), std::runtime_error);
      c::StateVersion caught = accepted;
      if (accepted_rows == 2) {
        caught = catch_up(state, journal, queue, head); ++submissions;
        check(head.publish(accepted.identity(), caught), "publish accepted catchup within combined state");
      } else EXPECT_THROW((void)catch_up(state, journal, queue, head), std::runtime_error);
      for (std::size_t entry = kTargetHistory; entry <= kTargetCursor; ++entry)
        same_storage(state.member(caught, entry), state.member(accepted, entry));
      const auto caught_bytes = image(state, caught);
      EXPECT_NE(read(state.member(caught, kHiddenState)), read(state.member(caught, kTargetTap)))
          << "fresh reseed must bind the target producer rather than retained draft hidden";
      state.epoch = 8; state.enabled = true;
      auto &next_plan = accepted_rows == 1 ? partial_plan : full_plan;
      const auto next = combined(next_plan, take(head.current(), "accepted target tap for epoch8"), 5, true);
      check(head.publish(caught.identity(), next), "single publication of epoch8 target and fresh NextN seed");
      EXPECT_EQ(state.facts(next).epoch, 8u);
      EXPECT_NE(read(state.member(next, kSelection)), read(state.member(first, kSelection)));
      EXPECT_FALSE(state.qualifies(accepted));

      // Recompute from BASE without rebinding any candidate result. Reuse the
      // SAME head for nominating this independent accepted checkpoint; no
      // separate target head/store or target-only publication exists.
      state.epoch = 7; state.enabled = true;
      const auto reference_first = combined(first_plan, base, accepted_rows == 1 ? 3 : 2, true);
      c::StateVersion reference_caught = reference_first;
      if (accepted_rows == 2) {
        c::ReadLease independent_nx;
        const auto reference_second = combined(skip, reference_first, 4, false, &independent_nx);
        check(head.publish(next.identity(), reference_second), "nominate independently recomputed accepted prefix2");
        state.enabled = false;
        reference_caught = catch_up(state, direct, queue, head, independent_nx); ++submissions;
        check(head.publish(reference_second.identity(), reference_caught), "publish independent direct catchup");
      } else check(head.publish(next.identity(), reference_caught), "nominate independently recomputed accepted prefix1");
      EXPECT_EQ(image(state, reference_caught), caught_bytes);
      state.epoch = 8; state.enabled = true;
      const auto reference_next = combined(next_plan, take(head.current(), "independent accepted target tap"), 5, true);
      check(head.publish(reference_caught.identity(), reference_next), "publish independently continued whole state");
      EXPECT_EQ(image(state, next), image(state, reference_next));
      EXPECT_EQ(image(state, base), base_bytes); EXPECT_EQ(image(state, first), first_bytes);
      EXPECT_EQ(image(state, second), second_bytes); EXPECT_EQ(image(state, accepted), accepted_bytes);
      EXPECT_EQ(image(state, caught), caught_bytes);
      EXPECT_FALSE(state.member(second, kTargetTap).try_write());
      EXPECT_FALSE(state.member(second, kTargetState).try_write());
      state.enabled = false;
      EXPECT_FALSE(state.qualifies(next)); EXPECT_FALSE(state.qualifies(first));
    }
    check(state.store.collect(), "retire combined target/draft prefix versions");
    EXPECT_EQ(state.store.stats().versions, 0u); EXPECT_EQ(state.store.stats().drafts, 0u);
  }
  warmup.clear();
  for (const auto *program : {&initializer, &target_plan, &first_plan, &partial_plan, &full_plan, &skip, &journal, &direct, &policy}) {
    EXPECT_EQ(program->outputs.stats().live_blocks, 0u); EXPECT_EQ(program->outputs.stats().active_uses, 0u);
    for (std::size_t i = 0; i < program->parameters.size(); ++i)
      EXPECT_EQ(read(program->parameters[i]), program->recipe.fragment.constant_bytes[program->parameter_slots[i]]);
  }
  EXPECT_EQ(submissions, 28u); EXPECT_EQ(target_submissions, 12u);
  ::testing::Test::RecordProperty("initialization_submissions", 2);
  ::testing::Test::RecordProperty("logical_index_state_bytes", std::to_string(kPoolCapacity * (kIndexDepth + 4) + kRing * kIndexDepth * 4));
  ::testing::Test::RecordProperty("actual_submissions", int(submissions));
  ::testing::Test::RecordProperty("target_submissions", int(target_submissions));
  ::testing::Test::RecordProperty("state_budget_bytes", std::to_string(state_budget));
  ::testing::Test::RecordProperty("peak_state_backing_bytes", std::to_string(peak_backing));
  ::testing::Test::RecordProperty("target_output_generations", 10);
  ::testing::Test::RecordProperty("backend", cuda ? "ordinary CUDA Graph" : "ordinary CPU Graph");
  ::testing::Test::RecordProperty("component_schema", "17 NextN/indexer resources plus epoch metadata and4 target resources: raw QKV history,KDA matrix,finalnorm tap,I32 cursor; one StateStore/Head/Draft");
  ::testing::Test::RecordProperty("journey", "actual target warmup->A/B verify pending->accept1/2->accepted journal catchup->epoch8 real target-tap reseed; independent base recomputation/direct nx catchup; rejected tail,stale CAS,cancellation,old readonly leases");
  ::testing::Test::RecordProperty("scope", "generated primary GGUF/F32 layer44 KDA/conv/two mHC branches/sparse FFN/finalnorm target tap composed with complete NextN; upper-layer4H remains generated; default UE8M0 logical cache/query codec; no vendorpage ABI,full45-layer original model,natural acceptance or throughput claim");
}
void run_target43(c::Context &context, const c::StorageOwner &owner, bool cuda) {
  auto component = target::build();
  const auto ports = component.ports;
  auto target_reference = std::move(component.evaluate);
  Recipe target_recipe; target_recipe.state_ports.fill(std::numeric_limits<std::size_t>::max());
  target_recipe.fragment = std::move(component.fragment); // one native constant bank
  const auto cursor = target_recipe.fragment.input(sem::dense({1}, c::DataType::kInt32));
  const auto cursor_port = expose(target_recipe, increment(target_recipe.fragment, cursor));
  // Ten bounded result generations retain the actual base/partial/full and
  // independent branches. The default remains five for existing consumers.
  auto target_plan = Program::create(std::move(target_recipe), context, owner, cuda, 10);
  auto first_plan = Program::create(build(true, 2054), context, owner, cuda);
  auto partial_plan = Program::create(build(true, 2055), context, owner, cuda);
  auto full_plan = Program::create(build(true, 2056), context, owner, cuda);
  auto skip = Program::create(build(false, 0, 3), context, owner, cuda);
  auto journal = Program::create(build_catchup(), context, owner, cuda);
  auto direct = Program::create(build_catchup(true), context, owner, cuda);
  Recipe policy_recipe; policy_recipe.fragment = pending_policy();
  auto policy = Program::create(std::move(policy_recipe), context, owner, cuda);
  auto queue = take(context.create_queue(), "joint target43/target44/NextN queue");
  auto warm43_plan = Program::create(build_target43(2053), context, owner, cuda, 1);
  auto token43_a = Program::create(build_target43(2054), context, owner, cuda);
  auto token43_b = Program::create(build_target43(2055), context, owner, cuda);
  auto token43_c = Program::create(build_target43(2056), context, owner, cuda);
  const auto choose43 = [&](std::int32_t position) -> Program & {
    if (position == 2054) return token43_a;
    if (position == 2055) return token43_b;
    if (position == 2056) return token43_c;
    throw std::runtime_error("target43 token frontier is outside the finite prepared domain");
  };
  auto initializer = Program::create(initial_pool_recipe(), context, owner, cuda, 3);
  std::size_t submissions = 0, target_submissions = 0, target43_submissions = 0, peak_backing = 0;
  const auto target_run = [&](std::span<const c::ReadLease> inputs) {
    const auto expected = target_reference(typed<float>(inputs[0]),
        typed<float>(inputs[1]), typed<float>(inputs[2]));
    auto output = target_plan.execute(queue, inputs); ++submissions; ++target_submissions;
    for (std::size_t port = 0; port < target::Ports::count; ++port) {
      SCOPED_TRACE(target::kPortNames[port]);
      sem::expect_output(target_plan.recipe.fragment, typed<float>(output[port]), expected[port]);
    }
    EXPECT_EQ(typed<std::int32_t>(output[cursor_port]).at(0), typed<std::int32_t>(inputs[3]).at(0) + 1);
    return output;
  };
  auto initial43 = initial_sparse(owner, initializer, queue, 2053); ++submissions;
  auto warm43 = execute_target43(warm43_plan, queue, initial43,
      upload(owner, sem::bytes(target_residual_values(0)))); ++submissions; ++target43_submissions;
  std::vector<c::ReadLease> warmup;
  {
    std::vector<float> history(3 * target::kChannels), matrix(target::kHeads * target::kDepth * target::kDepth);
    for (std::size_t i = 0; i < history.size(); ++i) history[i] = float(std::sin(double(i) * 0.013) * 0.01);
    for (std::size_t i = 0; i < matrix.size(); ++i) matrix[i] = float(std::sin(double(i) * 0.007) * 0.0005);
    const std::array inputs{warm43.mhc,
        upload(owner, sem::bytes(history)), upload(owner, sem::bytes(matrix)),
        upload(owner, sem::bytes(std::vector<std::int32_t>{2053}))};
    warmup = target_run(inputs); // actual previous-token target tap, not a host seed
  }
  std::vector<c::StateEntrySpec> extra_specs{
      c::StateEntrySpec{.description = target_plan.recipe.fragment.description(target_plan.recipe.fragment.outputs[ports.history]), .resource = owner.ref()},
      c::StateEntrySpec{.description = target_plan.recipe.fragment.description(target_plan.recipe.fragment.outputs[ports.state]), .resource = owner.ref()},
      c::StateEntrySpec{.description = target_plan.recipe.fragment.description(target_plan.recipe.fragment.outputs[ports.tap]), .resource = owner.ref()},
      c::StateEntrySpec{.description = sem::dense({1}, c::DataType::kInt32), .resource = owner.ref()}};
  const auto sparse_desc = descriptions();
  for (const auto entry : kSparseEntries) extra_specs.push_back({.description = sparse_desc[entry], .resource = owner.ref()});
  constexpr std::size_t state_budget = 512u << 20;
  for (const int accepted_rows : {1, 2}) {
    SCOPED_TRACE(accepted_rows);
    // The larger fixed budget accounts actual root backing capacities retained
    // by both KDA/history and NextN branches. It does not disable accounting.
    auto state = State::create(owner, extra_specs, state_budget);
    {
      const auto target_members = [&](std::span<const c::ReadLease> output, const SparseSnapshot &sparse) {
        std::vector<c::StateMember> members{{state.entries[kTargetHistory], output[ports.history]},
            {state.entries[kTargetState], output[ports.state]}, {state.entries[kTargetTap], output[ports.tap]},
            {state.entries[kTargetCursor], output[cursor_port]}};
        for (std::size_t i = 0; i < kSparseEntries.size(); ++i)
          members.push_back({state.entries[kTarget43Begin + i], sparse.values[i]});
        return members;
      };
      const auto initial_target = target_members(warmup, warm43.state);
      const auto base = state.initial(owner, initializer, queue, 2054, initial_target, warmup[ports.tap]); ++submissions;
      same_storage(state.member(base, kHiddenState), state.member(base, kTargetTap));
      const auto base_bytes = image(state, base);
      auto head = take(c::StateHead::create(state.store, base), "single combined target/NextN head");
      const auto combined = [&](Program &plan, const c::StateVersion &from,
                                std::int32_t pending, bool target_seed,
                                c::ReadLease *retained_nx = nullptr) {
        if (!state.enabled || (!plan.recipe.fresh && !state.qualifies(from)))
          throw std::runtime_error("combined consumer refused stale epoch before target preparation");
        if (typed<std::int32_t>(state.member(from, kTargetCursor)).at(0) != state.scalar(from, kMlaCursor))
          throw std::runtime_error("target/NextN accepted token frontiers differ");
        if (target_seed && !plan.recipe.fresh)
          throw std::runtime_error("target seed is only bound at a fresh NextN iteration");
        const auto before = image(state, from);
        auto produced43 = execute_target43(choose43(state.scalar(from, kMlaCursor)), queue,
            target43_snapshot(state, from), upload(owner, sem::bytes(target_residual_values(state.scalar(from, kPending)))));
        ++submissions; ++target43_submissions;
        const std::array target_inputs{produced43.mhc, state.member(from, kTargetHistory),
            state.member(from, kTargetState), state.member(from, kTargetCursor)};
        auto produced = target_run(target_inputs);
        const auto members = target_members(produced, produced43.state);
        const auto seed = target_seed ? state.member(from, kTargetTap) : c::ReadLease{};
        // Target verifies the current pending token, while NextN receives the
        // PREVIOUS target tap (fresh) or actual draft hidden (same-epoch skip).
        // Both sets of results enter exactly one StateDraft/finalize below.
        auto next = execute(state, plan, queue, owner, from, pending, retained_nx, members, seed); ++submissions;
        for (const auto &member : members)
          same_storage(take(next.member(member.entry), "combined actual target output"), member.resource);
        EXPECT_EQ(typed<std::int32_t>(state.member(next, kTargetCursor)).at(0), state.scalar(next, kMlaCursor));
        const auto target43_state = target43_snapshot(state, next);
        EXPECT_EQ(SparseAccess{}.scalar(target43_state, kMlaCursor), state.scalar(next, kMlaCursor));
        EXPECT_EQ(SparseAccess{}.scalar(target43_state, kIndexCursor), state.scalar(next, kMlaCursor));
        for (std::size_t i = 0; i < kSparseEntries.size(); ++i) {
          same_storage(target43_state.values[i], produced43.state.values[i]);
          const auto a = take(target43_state.values[i].view(), "actual target43 member");
          const auto b = take(state.member(next, kSparseEntries[i]).view(), "actual NextN member");
          EXPECT_FALSE(a.resource() == b.resource() && a.native_handle() == b.native_handle() && a.offset() == b.offset());
        }
        EXPECT_EQ(image(state, from), before);
        peak_backing = std::max(peak_backing, state.store.stats().backing_bytes);
        EXPECT_LE(state.store.stats().backing_bytes, state_budget);
        return next;
      };
      const auto first = combined(first_plan, base, 2, true);
      const auto first_bytes = image(state, first);
      const auto second = combined(skip, first, 4, false);
      const auto second_bytes = image(state, second);
      const auto second43 = target43_snapshot(state, second);
      EXPECT_NE(read(second43[kSelection]), read(state.member(second, kSelection)))
          << "target43 closes pool independently; NextN skip keeps its own full prior seed";
      EXPECT_EQ(SparseAccess{}.scalar(second43, kPoolCount), 514);
      EXPECT_EQ(state.scalar(second, kPoolCount), 513);
      EXPECT_NE(read(state.member(first, kTargetState)), read(state.member(second, kTargetState)));
      c::StateVersion accepted = second;
      if (accepted_rows == 1) {
        const std::array input{upload(owner, sem::bytes(std::vector<std::int32_t>{3}))};
        auto output = policy.execute(queue, input); ++submissions;
        auto draft = take(state.store.begin(first), "combined prefix1 target-policy correction");
        check(draft.replace(state.entries[kPending], output[0]), "correct only actual pending token");
        accepted = take(draft.finalize(), "one complete target/draft accepted prefix1");
        for (std::size_t entry = kTargetHistory; entry < kTarget43Begin + kSparseEntries.size(); ++entry)
          same_storage(state.member(accepted, entry), state.member(first, entry));
      }
      check(head.publish(base.identity(), accepted), "atomically accept target/draft same prefix");
      EXPECT_FALSE(head.publish(base.identity(), second).ok());
      const auto accepted_bytes = image(state, accepted);
      auto cancelled = take(state.store.begin(accepted), "incomplete combined target splice");
      check(cancelled.replace(state.entries[kTargetTap], state.member(second, kTargetTap)), "stage target-only speculative member");
      EXPECT_FALSE(cancelled.replace(state.entries[kTargetHistory], state.member(first, kPending)).ok());
      check(cancelled.cancel(), "cancel incomplete combined transaction");
      EXPECT_EQ(image(state, take(head.current(), "combined head after cancellation")), accepted_bytes);
      state.enabled = false;
      EXPECT_THROW((void)execute(state, skip, queue, owner, accepted, 5), std::runtime_error);
      c::StateVersion caught = accepted;
      if (accepted_rows == 2) {
        caught = catch_up(state, journal, queue, head); ++submissions;
        check(head.publish(accepted.identity(), caught), "publish accepted catchup within combined state");
      } else EXPECT_THROW((void)catch_up(state, journal, queue, head), std::runtime_error);
      for (std::size_t entry = kTargetHistory; entry < kTarget43Begin + kSparseEntries.size(); ++entry)
        same_storage(state.member(caught, entry), state.member(accepted, entry));
      const auto caught_bytes = image(state, caught);
      EXPECT_NE(read(state.member(caught, kHiddenState)), read(state.member(caught, kTargetTap)))
          << "fresh reseed must bind the target producer rather than retained draft hidden";
      state.epoch = 8; state.enabled = true;
      auto &next_plan = accepted_rows == 1 ? partial_plan : full_plan;
      const auto next = combined(next_plan, take(head.current(), "accepted target tap for epoch8"), 5, true);
      check(head.publish(caught.identity(), next), "single publication of epoch8 target and fresh NextN seed");
      EXPECT_EQ(state.facts(next).epoch, 8u);
      EXPECT_NE(read(state.member(next, kSelection)), read(state.member(first, kSelection)));
      EXPECT_FALSE(state.qualifies(accepted));

      // Recompute from BASE without rebinding any candidate result. Reuse the
      // SAME head for nominating this independent accepted checkpoint; no
      // separate target head/store or target-only publication exists.
      state.epoch = 7; state.enabled = true;
      const auto reference_first = combined(first_plan, base, accepted_rows == 1 ? 3 : 2, true);
      c::StateVersion reference_caught = reference_first;
      if (accepted_rows == 2) {
        c::ReadLease independent_nx;
        const auto reference_second = combined(skip, reference_first, 4, false, &independent_nx);
        check(head.publish(next.identity(), reference_second), "nominate independently recomputed accepted prefix2");
        state.enabled = false;
        reference_caught = catch_up(state, direct, queue, head, independent_nx); ++submissions;
        check(head.publish(reference_second.identity(), reference_caught), "publish independent direct catchup");
      } else check(head.publish(next.identity(), reference_caught), "nominate independently recomputed accepted prefix1");
      EXPECT_EQ(image(state, reference_caught), caught_bytes);
      state.epoch = 8; state.enabled = true;
      const auto reference_next = combined(next_plan, take(head.current(), "independent accepted target tap"), 5, true);
      check(head.publish(reference_caught.identity(), reference_next), "publish independently continued whole state");
      EXPECT_EQ(image(state, next), image(state, reference_next));
      EXPECT_EQ(image(state, base), base_bytes); EXPECT_EQ(image(state, first), first_bytes);
      EXPECT_EQ(image(state, second), second_bytes); EXPECT_EQ(image(state, accepted), accepted_bytes);
      EXPECT_EQ(image(state, caught), caught_bytes);
      EXPECT_FALSE(state.member(second, kTargetTap).try_write());
      EXPECT_FALSE(state.member(second, kTargetState).try_write());
      state.enabled = false;
      EXPECT_FALSE(state.qualifies(next)); EXPECT_FALSE(state.qualifies(first));
    }
    check(state.store.collect(), "retire combined target/draft prefix versions");
    EXPECT_EQ(state.store.stats().versions, 0u); EXPECT_EQ(state.store.stats().drafts, 0u);
  }
  warmup.clear(); warm43 = {}; initial43 = {};
  for (const auto *program : {&warm43_plan, &token43_a, &token43_b, &token43_c, &initializer, &target_plan, &first_plan, &partial_plan, &full_plan, &skip, &journal, &direct, &policy}) {
    EXPECT_EQ(program->outputs.stats().live_blocks, 0u); EXPECT_EQ(program->outputs.stats().active_uses, 0u);
    for (std::size_t i = 0; i < program->parameters.size(); ++i)
      EXPECT_EQ(read(program->parameters[i]), program->recipe.fragment.constant_bytes[program->parameter_slots[i]]);
  }
  EXPECT_EQ(submissions, 41u); EXPECT_EQ(target_submissions, 12u); EXPECT_EQ(target43_submissions, 12u);
  ::testing::Test::RecordProperty("initialization_submissions", 3);
  ::testing::Test::RecordProperty("logical_index_state_bytes", std::to_string(kPoolCapacity * (kIndexDepth + 4) + kRing * kIndexDepth * 4));
  ::testing::Test::RecordProperty("actual_submissions", int(submissions));
  ::testing::Test::RecordProperty("target_submissions", int(target_submissions));
  ::testing::Test::RecordProperty("target43_submissions", int(target43_submissions));
  ::testing::Test::RecordProperty("state_budget_bytes", std::to_string(state_budget));
  ::testing::Test::RecordProperty("peak_state_backing_bytes", std::to_string(peak_backing));
  ::testing::Test::RecordProperty("target_output_generations", 10);
  ::testing::Test::RecordProperty("backend", cuda ? "ordinary CUDA Graph" : "ordinary CPU Graph");
  ::testing::Test::RecordProperty("component_schema", "34 resources plus epoch metadata:17 NextN,13 independent target43 MLA/indexer,4 target44 KDA/conv/tap/cursor; one StateStore/Head/Draft");
  ::testing::Test::RecordProperty("journey", "actual target43 UE8M0 MLA/indexer->43 mHC/FFN->actual43mhc lease->44 KDA/conv/mHC/finalnorm->NextN; accept1/2 crosses pool close; NextN accepted journal catches up; epoch8 direct target-tap reseed; independent base replay; rejected/stale/cancel/old leases");
  ::testing::Test::RecordProperty("scope", "generated primary GGUF/F32 layer42 four-stream input; actual13-state target43 attention at distinct immutable projection roles,34-resource joint43/44/NextN continuation; BF16 rings and default UE8M0 logical codec; no original checkpoint/full45-layer target,vendorpage ABI,natural acceptance or throughput claim");
}
std::string original_directory(const char *name) {
#if defined(_WIN32)
  char *value = nullptr; std::size_t size = 0;
  if (_dupenv_s(&value, &size, name)) throw std::runtime_error("cannot read original GLM role directory");
  const std::unique_ptr<char, decltype(&std::free)> owner(value, &std::free);
  return value ? value : "";
#else
  const auto *value = std::getenv(name); return value ? value : "";
#endif
}
void run_original_indexer(c::Context &context, const c::StorageOwner &owner, bool cuda) {
  const auto input = original_directory("HYLE_GLM_MTP_INPUT_DIR");
  const auto query = original_directory("HYLE_GLM_MTP_QUERY_DIR");
  const auto indexer = original_directory("HYLE_GLM_MTP_INDEXER_DIR");
  if (input.empty() || query.empty() || indexer.empty()) {
    GTEST_SKIP() << "Set HYLE_GLM_MTP_INPUT_DIR, HYLE_GLM_MTP_QUERY_DIR and HYLE_GLM_MTP_INDEXER_DIR to authenticated layer45 roles";
  }
  run_seed_handoff(context, owner, cuda, original_nextn(input, query, indexer, owner));
}

#if defined(HYLE_TEST_GLM_STATE_CUDA)
TEST(GlmMtpStateConsumer, CudaOriginalIndexerPublishesCatchesUpAndReseeds) {
  auto context = take(g::cuda::create_context(), "ordinary original-indexer CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "original-indexer CUDA memory")), "original-indexer storage owner");
  run_original_indexer(context, owner, true);
}
TEST(GlmMtpStateConsumer, CudaTarget43MlaFlowsThroughTarget44AndNextN) {
  auto context = take(g::cuda::create_context(), "ordinary CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "ordinary CUDA memory")), "retained CUDA allocation domain");
  run_target43(context, owner, true);
}
TEST(GlmMtpStateConsumer, CudaWholeNextNPrefixPublishesAndContinuesWithoutRejectedTail) {
  auto context = take(g::cuda::create_context(), "ordinary CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "ordinary CUDA memory")), "retained CUDA allocation domain");
  run(context, owner, true);
}
TEST(GlmMtpStateConsumer, CudaAcceptedJournalCatchesUpAndReseedsNextIteration) {
  auto context = take(g::cuda::create_context(), "ordinary CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "ordinary CUDA memory")), "retained CUDA allocation domain");
  run_catchup(context, owner, true);
}
TEST(GlmMtpStateConsumer, CudaTargetPrefixAndNextNPublishAndReseedTogether) {
  auto context = take(g::cuda::create_context(), "ordinary CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "ordinary CUDA memory")), "retained CUDA allocation domain");
  run_target(context, owner, true);
}
TEST(GlmMtpStateConsumer, CudaDraftExtendLastAcceptedSeedSkipsDecodeStepZero) {
  auto context = take(g::cuda::create_context(), "ordinary CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "ordinary CUDA memory")), "retained CUDA allocation domain");
  run_seed_handoff(context, owner, true);
}
#endif
#if defined(HYLE_TEST_GLM_STATE_CPU)
struct SystemResource final { m::MemoryResourceRef ref() noexcept { return m::system_resource(); } };
TEST(GlmMtpStateConsumer, CpuOriginalIndexerPublishesCatchesUpAndReseeds) {
  auto context = take(g::cpu::create_context(), "ordinary original-indexer CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "original-indexer storage owner");
  run_original_indexer(context, owner, false);
}
TEST(GlmMtpStateConsumer, CpuTarget43MlaFlowsThroughTarget44AndNextN) {
  auto context = take(g::cpu::create_context(), "ordinary CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "retained CPU allocation domain");
  run_target43(context, owner, false);
}
TEST(GlmMtpStateConsumer, CpuWholeNextNPrefixPublishesAndContinuesWithoutRejectedTail) {
  auto context = take(g::cpu::create_context(), "ordinary CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "retained CPU allocation domain");
  run(context, owner, false);
}
TEST(GlmMtpStateConsumer, CpuAcceptedJournalCatchesUpAndReseedsNextIteration) {
  auto context = take(g::cpu::create_context(), "ordinary CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "retained CPU allocation domain");
  run_catchup(context, owner, false);
}
TEST(GlmMtpStateConsumer, CpuTargetPrefixAndNextNPublishAndReseedTogether) {
  auto context = take(g::cpu::create_context(), "ordinary CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "retained CPU allocation domain");
  run_target(context, owner, false);
}
TEST(GlmMtpStateConsumer, CpuDraftExtendLastAcceptedSeedSkipsDecodeStepZero) {
  auto context = take(g::cpu::create_context(), "ordinary CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "retained CPU allocation domain");
  run_seed_handoff(context, owner, false);
}
#endif
} // namespace
