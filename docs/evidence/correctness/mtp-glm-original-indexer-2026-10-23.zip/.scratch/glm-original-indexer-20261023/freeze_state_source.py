from pathlib import Path
import difflib, hashlib, json, re, shutil

root=Path('.scratch/glm-original-indexer-20261023')
out=root/'state-source'
sources=[Path('tests/compute_models/glm_mtp_state_consumer_test.cc'),Path('tests/compute_models/glm_original_indexer_roles.h')]
def identity(path):
    body=path.read_bytes()
    return {'path':path.as_posix(),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
files=[]
for source in sources:
    dest=out/'frozen'/source
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,dest)
    entry=identity(source)
    before=out/'before'/source
    previous=before.read_text(encoding='utf-8-sig').splitlines(keepends=True) if before.exists() else []
    current=source.read_text(encoding='utf-8-sig').splitlines(keepends=True)
    (out/(source.name+'.diff')).write_text(''.join(difflib.unified_diff(previous,current,fromfile=before.as_posix(),tofile=source.as_posix())),encoding='utf-8')
    if before.exists():entry['before']=identity(before)
    files.append(entry)

receipt_path=root/'original-indexer/acquisition.json'
receipt=json.loads(receipt_path.read_text(encoding='utf-8-sig'))
supplier=sources[1].read_text(encoding='utf-8')
role_checks=[]
for role in receipt['roles']:
    payload=Path(role['payload']['path'])
    actual=identity(payload)
    if actual['sha256']!=role['payload']['sha256'] or actual['bytes']!=role['payload']['bytes']:
        raise RuntimeError('payload identity mismatch: '+str(payload))
    if actual['sha256'] not in supplier:raise RuntimeError('missing hard source pin: '+str(payload))
    role_checks.append({'name':role['name'],**actual,'hard_pin_present':True})
manifest={
    'source_only':True,'native_build_run_ssh_download':False,
    'scope':'Pinned original7prefix+original7indexer in the existing complete NextN draft-extend seed/catchup state journey; two additional CPU/CUDA cases, no new executor',
    'files':files,
    'shared_dependencies':[identity(Path('tests/compute_models/glm_original_mtp_roles.h')),identity(Path('tests/compute_models/glm_original_indexer_reference.h'))],
    'receipt':identity(receipt_path),'original_indexer_payload_checks':role_checks,
    'source_role_count':14,'source_role_bytes':88373248,'runtime_bank_count':13,'runtime_bank_bytes':88636928,
    'tests':['GlmMtpStateConsumer.CpuOriginalIndexerPublishesCatchesUpAndReseeds','GlmMtpStateConsumer.CudaOriginalIndexerPublishesCatchesUpAndReseeds'],
    'environment':['HYLE_GLM_MTP_INPUT_DIR','HYLE_GLM_MTP_QUERY_DIR','HYLE_GLM_MTP_INDEXER_DIR'],
    'expected_submissions_per_backend':{'total':26,'initialization':2,'draft_extend':11,'skip':8,'catchup':4,'policy':1},
    'status':'Frozen for root-owned incremental compile and native checks; this manifest is not an execution result.'
}
(out/'freeze.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identity(out/'freeze.json')))
