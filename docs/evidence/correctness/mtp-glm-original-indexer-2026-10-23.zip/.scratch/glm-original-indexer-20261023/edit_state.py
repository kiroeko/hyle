from pathlib import Path

p=Path('tests/compute_models/glm_mtp_state_consumer_test.cc')
s=p.read_text(encoding='utf-8')
def replace(old,new,count=1):
    global s
    actual=s.count(old)
    if actual!=count: raise RuntimeError(f'replacement count {actual} != {count}: {old[:110]}')
    s=s.replace(old,new)
def replace_seed(old,new):
    global s
    begin=s.index('void run_seed_handoff(')
    end=s.index('\nvoid run(c::Context',begin)
    block=s[begin:end]
    if block.count(old)!=1: raise RuntimeError('seed replacement: '+old)
    s=s[:begin]+block.replace(old,new)+s[end:]

replace('#include <functional>','#include <functional>\n#include <memory>')
replace('#include "glm_mtp_target43_component.h"','#include "glm_mtp_target43_component.h"\n#include "glm_original_mtp_roles.h"\n#include "glm_original_indexer_roles.h"\n#include "glm_original_indexer_reference.h"')
replace('namespace codec = glm_official_index_cache;','namespace codec = glm_official_index_cache;\nnamespace original_prefix = glm_original_mtp_roles;\nnamespace original_index = glm_original_indexer_roles;\nnamespace index_reference = glm_original_indexer_reference;')
replace('struct CodecPorts final {', '''struct OriginalNextn final {
  original_prefix::Data prefix;
  original_index::Data indexer;
  std::array<original_index::ReadonlyRole, original_prefix::kCount> prefix_roles;
  original_index::Roles indexer_roles;
};
std::shared_ptr<const OriginalNextn> original_nextn(const std::filesystem::path &input,
    const std::filesystem::path &query, const std::filesystem::path &indexer,
    const c::StorageOwner &owner) {
  auto result = std::make_shared<OriginalNextn>();
  result->prefix = original_prefix::Data::load(input, query);
  result->indexer = original_index::Data::load(indexer);
  for (std::size_t i = 0; i < result->prefix_roles.size(); ++i) {
    const auto role = static_cast<original_prefix::Parameter>(i);
    result->prefix_roles[i] = {"original GLM NextN input/query", original_prefix::description(role), owner,
        upload(owner, original_prefix::payload(result->prefix, role))};
  }
  result->indexer_roles = original_index::bind(result->indexer, owner);
  return result;
}
struct External final { std::size_t constant; original_index::ReadonlyRole role; };
struct CodecPorts final {''')
replace('  sem::Fragment fragment;\n  std::array<std::size_t, kResources> state_ports;', '''  sem::Fragment fragment;
  std::shared_ptr<const OriginalNextn> original;
  std::vector<External> external;
  std::array<std::size_t, 7> original_prefix_ports{};
  std::size_t original_hidden = 0, original_embedding = 0, wk_accum = 0, wk_stored = 0;
  std::size_t index_query_accum = 0, index_query_stored = 0;
  std::array<std::size_t, kResources> state_ports;''')
replace('Value change(Recipe &r, Entry entry, Value value, bool copy = false) {', '''Value external(Recipe &r, const original_index::ReadonlyRole &role) {
  const auto slot = r.fragment.constants.size();
  const auto value = r.fragment.constant(role.description, {});
  r.external.push_back({slot, role}); return value;
}
Value change(Recipe &r, Entry entry, Value value, bool copy = false) {''')
replace('''  auto wk = glm::projection(f, nx, kIndexDepth, kHidden, 241 + role_offset, false);
  auto scale = sem::oracle::scale(kIndexDepth);''','''  Value key, raw_key, raw_gate;
  if (r.original) {
    if (role_offset != 0) throw std::runtime_error("original layer45 indexer cannot supply another layer");
    const auto rounded_nx = codec::cast(f, nx, c::DataType::kBFloat16);
    const auto &roles = r.original->indexer_roles;
    const auto wk = f.one(c::model_ops::bfloat_linear_f32(), {rounded_nx, external(r, roles[original_index::kKey])});
    r.wk_accum = expose(r, wk);
    const auto stored_wk = codec::cast(f, wk, c::DataType::kBFloat16); r.wk_stored = expose(r, stored_wk);
    key = f.one(c::Operation(c::LayerNorm{.epsilon = 1.0e-6F}),
        {codec::cast(f, stored_wk, c::DataType::kFloat32), external(r, roles[original_index::kNorm]),
         external(r, roles[original_index::kBias])});
    r.key = expose(r, key);
    raw_key = codec::cast(f, key, c::DataType::kBFloat16); r.raw_key = expose(r, raw_key);
    const auto gate_projection = f.one(c::model_ops::bfloat_linear_f32(),
        {rounded_nx, external(r, roles[original_index::kGate])});
    r.gate_projection = expose(r, gate_projection);
    raw_gate = codec::cast(f, gate_projection, c::DataType::kBFloat16); r.raw_gate = expose(r, raw_gate);
    r.gate = expose(r, codec::cast(f, raw_gate, c::DataType::kFloat32));
  } else {
  auto wk = glm::projection(f, nx, kIndexDepth, kHidden, 241 + role_offset, false);
  auto scale = sem::oracle::scale(kIndexDepth);''')
replace('  const auto key = f.one(c::Operation(c::LayerNorm{.epsilon = 1.0e-6F}), {wk.output, sw, bw});','  key = f.one(c::Operation(c::LayerNorm{.epsilon = 1.0e-6F}), {wk.output, sw, bw});')
replace('  const auto raw_key = codec::cast(f, key, c::DataType::kBFloat16); r.raw_key = expose(r, raw_key);','  raw_key = codec::cast(f, key, c::DataType::kBFloat16); r.raw_key = expose(r, raw_key);')
replace('  const auto raw_gate = codec::cast(f, wg.output, c::DataType::kBFloat16); r.raw_gate = expose(r, raw_gate);','  raw_gate = codec::cast(f, wg.output, c::DataType::kBFloat16); r.raw_gate = expose(r, raw_gate);')
replace('  r.gate_reference = [wg = std::move(wg)](auto x) { return wg.reference(x); };','  r.gate_reference = [wg = std::move(wg)](auto x) { return wg.reference(x); };\n  }')
replace('''    const auto positional = f.constant(sem::dense({1, 4, kIndexDepth}), sem::bytes(ape));''','''    const auto positional = r.original ? external(r, r.original->indexer_roles[original_index::kApe]) :
        f.constant(sem::dense({1, 4, kIndexDepth}), sem::bytes(ape));''')
replace('''                               int role_offset = 0, const SkipJournal *journal = nullptr) {''','''                               int role_offset = 0, const SkipJournal *journal = nullptr,
                               const Value *original_qr = nullptr) {''')
replace('''  auto qa = glm::projection(f, nx, kQueryRank, kHidden, 197 + role_offset, false);''','''  Value qr;
  if (r.original) {
    if (role_offset != 0 || !original_qr) throw std::runtime_error("original NextN query requires its same-Graph prefix");
    qr = changed(kQueryState, codec::cast(f, *original_qr, c::DataType::kFloat32));
  } else {
  auto qa = glm::projection(f, nx, kQueryRank, kHidden, 197 + role_offset, false);''')
replace('  const auto qr = changed(kQueryState, glm::norm(f, qa.output, query_scale));','  qr = changed(kQueryState, glm::norm(f, qa.output, query_scale));')
replace('''    return sem::oracle::rms_norm_rows(qa.reference(x), scale, kQueryRank, glm::kNormEpsilon);
  };''','''    return sem::oracle::rms_norm_rows(qa.reference(x), scale, kQueryRank, glm::kNormEpsilon);
  };
  }''')
replace('''    auto wq = glm::projection(f, qr, kIndexHeads * kIndexDepth, kQueryRank, 239 + role_offset, false);
    const auto iq = glm::reshape(f, wq.output, {kIndexHeads, kIndexDepth});''','''    Value index_query, weights;
    if (r.original) {
      const auto &roles = r.original->indexer_roles;
      const auto wq = f.one(c::model_ops::bfloat_linear_f32(),
          {codec::cast(f, qr, c::DataType::kBFloat16), external(r, roles[original_index::kQuery])});
      r.index_query_accum = publish(wq);
      const auto stored = codec::cast(f, wq, c::DataType::kBFloat16); r.index_query_stored = publish(stored);
      index_query = codec::cast(f, stored, c::DataType::kFloat32);
      weights = f.one(c::Operation(c::MatMul{}),
          {nx, glm::permute(f, external(r, roles[original_index::kWeights]), {1, 0})});
      r.score_weight = publish(weights);
    } else {
    auto wq = glm::projection(f, qr, kIndexHeads * kIndexDepth, kQueryRank, 239 + role_offset, false);
    index_query = wq.output;
    r.index_query_reference = [wq = std::move(wq)](auto x) { return wq.reference(x); };
    auto ws = glm::linear::projection(f, nx, kIndexHeads, kHidden, glm::linear::Storage::kF32, 251 + role_offset);
    weights = ws.output; r.score_weight = publish(weights);
    r.score_weight_reference = [ws = std::move(ws)](auto x) { return ws.reference(x); };
    }
    const auto iq = glm::reshape(f, index_query, {kIndexHeads, kIndexDepth});''')
replace('''    r.index_query_reference = [wq = std::move(wq)](auto x) { return wq.reference(x); };
    auto ws = glm::linear::projection(f, nx, kIndexHeads, kHidden, glm::linear::Storage::kF32, 251 + role_offset);
    const auto weights = ws.output; r.score_weight = publish(weights);
    r.score_weight_reference = [ws = std::move(ws)](auto x) { return ws.reference(x); };
''','')
replace('Recipe build(bool fresh, std::int32_t position = kBasePosition, std::int32_t carried_tail = 0) {','''Recipe build(bool fresh, std::int32_t position = kBasePosition, std::int32_t carried_tail = 0,
             std::shared_ptr<const OriginalNextn> original = {}) {''')
replace('''  r.fresh = fresh;
  r.position = position;''','''  r.fresh = fresh;
  r.original = std::move(original);
  r.position = position;''')
replace('''  f.profile = kModel.profile; f.region = fresh ? 0x474c4d5354465245ULL : 0x474c4d5354534b50ULL;''','''  f.profile = r.original ? &glm::core::profiles::glm53_flash_official : kModel.profile;
  f.region = fresh ? 0x474c4d5354465245ULL : 0x474c4d5354534b50ULL;''')
replace('''  const auto input = glm::attach(f, glm::mtp_input(kModel, &r.input_reference, false),
      {state[kHiddenState], embedding});
  const auto eh = input[3]; r.eh = publish(eh);
  r.input_scale = sem::oracle::scale(kHidden);
  auto input_scale = r.input_scale;
  const auto nx = glm::norm(f, eh, input_scale); r.nx = publish(nx);''','''  Value eh, nx, qr;
  if (r.original) {
    const auto hidden_bf16 = codec::cast(f, state[kHiddenState], c::DataType::kBFloat16);
    const auto embedding_bf16 = codec::cast(f, embedding, c::DataType::kBFloat16);
    r.original_hidden = publish(hidden_bf16); r.original_embedding = publish(embedding_bf16);
    const auto prefix = original_prefix::append_with_constants(f, hidden_bf16, embedding_bf16,
        [&](original_prefix::Parameter parameter) { return external(r, r.original->prefix_roles[parameter]); });
    const auto ports = prefix.values();
    for (std::size_t i = 0; i < ports.size(); ++i) r.original_prefix_ports[i] = publish(ports[i], true);
    eh = codec::cast(f, prefix.eh, c::DataType::kFloat32);
    nx = codec::cast(f, prefix.nx, c::DataType::kFloat32);
    qr = prefix.qr;
  } else {
    const auto input = glm::attach(f, glm::mtp_input(kModel, &r.input_reference, false),
        {state[kHiddenState], embedding});
    eh = input[3];
    r.input_scale = sem::oracle::scale(kHidden);
    auto input_scale = r.input_scale;
    nx = glm::norm(f, eh, input_scale);
  }
  r.eh = publish(eh); r.nx = publish(nx);''')
replace('''  const auto attention_output = append_sparse_attention(r, sparse_state(f, state), nx, 0, &journal);''','''  const auto attention_output = append_sparse_attention(r, sparse_state(f, state), nx, 0, &journal,
      r.original ? &qr : nullptr);''')
replace('Recipe build_catchup(bool direct_reference = false, std::int32_t position = 2055) {','''Recipe build_catchup(bool direct_reference = false, std::int32_t position = 2055,
                     std::shared_ptr<const OriginalNextn> original = {}) {''')
replace('''  r.catchup = true; r.direct_catchup = direct_reference; r.position = position;''','''  r.catchup = true; r.direct_catchup = direct_reference; r.position = position;
  r.original = std::move(original);''')
replace('''  f.profile = kModel.profile; f.region = direct_reference ? 0x474c4d4341544449ULL : 0x474c4d4341544a4fULL;''','''  f.profile = r.original ? &glm::core::profiles::glm53_flash_official : kModel.profile;
  f.region = direct_reference ? 0x474c4d4341544449ULL : 0x474c4d4341544a4fULL;''')
replace('''  std::vector<c::ReadLease> parameters;
  g::CompiledGraph compiled;''','''  std::vector<c::ReadLease> parameters;
  std::vector<std::size_t> parameter_slots;
  g::CompiledGraph compiled;''')
replace('''      p.parameters.push_back(upload(owner, p.recipe.fragment.constant_bytes[i]));
      constants.push_back({p.logical.constants[i], take(p.parameters.back().tensor(
          p.recipe.fragment.description(p.recipe.fragment.constants[i])), "typed NextN constant")});''','''      const auto supplied = std::find_if(p.recipe.external.begin(), p.recipe.external.end(),
          [&](const External &value) { return value.constant == i; });
      if (supplied != p.recipe.external.end()) {
        if (supplied->role.description != p.recipe.fragment.description(p.recipe.fragment.constants[i]))
          throw std::runtime_error("original GLM constant descriptor changed");
        constants.push_back(take(supplied->role.binding(p.logical.constants[i]), "shared original GLM constant owner"));
      } else {
        p.parameters.push_back(upload(owner, p.recipe.fragment.constant_bytes[i])); p.parameter_slots.push_back(i);
        constants.push_back({p.logical.constants[i], take(p.parameters.back().tensor(
            p.recipe.fragment.description(p.recipe.fragment.constants[i])), "typed NextN constant")});
      }''')
replace('const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*kModel.profile), "primary GGUF profile"),','const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*p.recipe.fragment.profile), "actual GLM component profile"),')
replace('program->recipe.fragment.constant_bytes[i]','program->recipe.fragment.constant_bytes[program->parameter_slots[i]]',5)
replace('''  quantified(r, key, r.key_reference(nx)); quantified(r, gate_projection, r.gate_reference(nx));''','''  if (r.original) {
    const auto &source = r.original->indexer;
    const auto wk = fp(r.wk_accum);
    EXPECT_TRUE(index_reference::expect_accum(wk, index_reference::linear(nx, source.key, kIndexDepth), "original wk BF16 operands -> F32"));
    const auto rounded_wk = typed<std::uint16_t>(output[r.wk_stored]);
    EXPECT_TRUE(index_reference::expect_bfloat_store(rounded_wk, wk, "original wk BF16 store"));
    sem::oracle::expect_close(key, index_reference::layer_norm(original_index::widen(rounded_wk), source.norm, source.bias), 8e-5F, 4e-5F);
    EXPECT_TRUE(index_reference::expect_accum(gate_projection,
        index_reference::linear(nx, source.gate, kIndexDepth), "original compression gate BF16 operands -> F32"));
  } else {
    quantified(r, key, r.key_reference(nx)); quantified(r, gate_projection, r.gate_reference(nx));
  }''')
replace('''    std::vector<float> pooled(kIndexDepth);
    for (std::size_t d = 0; d < kIndexDepth; ++d) {''','''    std::vector<float> pooled(kIndexDepth);
    if (r.original) {
      std::array<std::int32_t, 4> ring_rows{};
      for (std::size_t t = 0; t < ring_rows.size(); ++t)
        ring_rows[t] = (r.position - 3 + std::int32_t(t)) % std::int32_t(kRing);
      pooled = index_reference::pool_reference(raw, gates, r.original->indexer.ape, ring_rows);
    } else {
    for (std::size_t d = 0; d < kIndexDepth; ++d) {''')
replace('''      pooled[d] = float(result);
    }
    sem::oracle::expect_close(fp(r.compressed), pooled, 8e-5F, 4e-5F);''','''      pooled[d] = float(result);
    }
    }
    sem::oracle::expect_close(fp(r.compressed), pooled, 8e-5F, 4e-5F);''')
replace('''  quantified(r, qr, r.query_reference(nx));''','''  if (r.original) {
    EXPECT_EQ(qr, original_index::widen(typed<std::uint16_t>(output[r.original_prefix_ports[6]])));
  } else quantified(r, qr, r.query_reference(nx));''')
replace('''    quantified(r, fp(r.index_query), r.index_query_reference(qr));
    sem::oracle::expect_close(fp(r.score_weight), r.score_weight_reference(nx), 8e-5F, 4e-5F);''','''    if (r.original) {
      const auto wq = fp(r.index_query_accum);
      EXPECT_TRUE(index_reference::expect_accum(wq,
          index_reference::linear(qr, r.original->indexer.query, kIndexHeads * kIndexDepth), "original wq_b BF16 operands -> F32"));
      const auto rounded = typed<std::uint16_t>(output[r.index_query_stored]);
      EXPECT_TRUE(index_reference::expect_bfloat_store(rounded, wq, "original wq_b BF16 store"));
      EXPECT_EQ(fp(r.index_query), original_index::widen(rounded));
      EXPECT_TRUE(index_reference::expect_accum(fp(r.score_weight),
          index_reference::linear(nx, r.original->indexer.weights, kIndexHeads), "original widened-F32 weights_proj"));
    } else {
      quantified(r, fp(r.index_query), r.index_query_reference(qr));
      sem::oracle::expect_close(fp(r.score_weight), r.score_weight_reference(nx), 8e-5F, 4e-5F);
    }''')
replace('''  quantified(r, eh, r.input_reference(hidden, embedding)[3]);
  sem::oracle::expect_close(nx, sem::oracle::rms_norm_rows(eh, r.input_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);''','''  if (r.original) {
    const auto actual_hidden = typed<std::uint16_t>(output[r.original_hidden]);
    const auto actual_embedding = typed<std::uint16_t>(output[r.original_embedding]);
    EXPECT_TRUE(index_reference::expect_bfloat_store(actual_hidden, hidden, "declared original-prefix target-hidden boundary"));
    EXPECT_TRUE(index_reference::expect_bfloat_store(actual_embedding, embedding, "declared original-prefix embedding boundary"));
    std::array<std::vector<std::uint16_t>, 7> actual;
    for (std::size_t i = 0; i < actual.size(); ++i) actual[i] = typed<std::uint16_t>(output[r.original_prefix_ports[i]]);
    EXPECT_TRUE(original_prefix::observe_prefix(r.original->prefix, actual_hidden, actual_embedding, actual,
        output[r.original_hidden].resource().device().kind == c::DeviceKind::kCuda));
    EXPECT_EQ(eh, original_index::widen(actual[3])); EXPECT_EQ(nx, original_index::widen(actual[4]));
  } else {
    quantified(r, eh, r.input_reference(hidden, embedding)[3]);
    sem::oracle::expect_close(nx, sem::oracle::rms_norm_rows(eh, r.input_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);
  }''')
replace('void run_seed_handoff(c::Context &context, const c::StorageOwner &owner, bool cuda) {','''void run_seed_handoff(c::Context &context, const c::StorageOwner &owner, bool cuda,
                      std::shared_ptr<const OriginalNextn> original = {}) {''')
replace('''  const auto extend_recipe = [](std::int32_t position) {
    auto r = build(true, position);''','''  const auto extend_recipe = [original](std::int32_t position) {
    auto r = build(true, position, 0, original);''')
for tail in [3,0,1,2]: replace_seed(f'Program::create(build(false, 0, {tail}), context, owner, cuda)',f'Program::create(build(false, 0, {tail}, original), context, owner, cuda)')
for direct,pos in [('false',2055),('false',2056),('true',2055),('true',2056)]:
    replace_seed(f'Program::create(build_catchup({direct}, {pos}), context, owner, cuda)',f'Program::create(build_catchup({direct}, {pos}, original), context, owner, cuda)')
replace('''  ::testing::Test::RecordProperty("scope", "generated selected Flash primary GGUF/F32 sequential M1 draft-extend seed protocol; generated per-position target-hidden boundary; default UE8M0 logical cache/query and BF16 raw rings; no target43 MLA/indexer composition,batched vendor extend kernel,full target,original weights,vendorpage ABI,natural acceptance or throughput claim");''','''  if (original) {
    for (const auto &role : original->prefix_roles) { auto reader = role.lease; EXPECT_FALSE(reader.try_write()); }
    for (const auto &role : original->indexer_roles) { auto reader = role.lease; EXPECT_FALSE(reader.try_write()); }
    ::testing::Test::RecordProperty("original_roles", 14);
    ::testing::Test::RecordProperty("original_role_bytes", 88373248);
    ::testing::Test::RecordProperty("scope", "official HF GLM-5.3-Flash eb9eb208 layer45 original7 input/query+original7 indexer in the existing complete sequential M1 NextN seed/catchup journey; explicit generated target-hidden/embedding and MLA/MoE/head remainder; no primaryGGUF tensor equality,full target,original shared LM,natural acceptance,vendorpage ABI or throughput claim");
  } else ::testing::Test::RecordProperty("scope", "generated selected Flash primary GGUF/F32 sequential M1 draft-extend seed protocol; generated per-position target-hidden boundary; default UE8M0 logical cache/query and BF16 raw rings; no target43 MLA/indexer composition,batched vendor extend kernel,full target,original weights,vendorpage ABI,natural acceptance or throughput claim");''')
# Mark backend directly in Recipe; do not guess it through an unrelated lease API.
replace('''  bool catchup = false, direct_catchup = false;''','''  bool catchup = false, direct_catchup = false, cuda = false;''')
replace('''    Program p; p.recipe = std::move(recipe); p.logical = sem::make_graph(p.recipe.fragment);''','''    Program p; p.recipe = std::move(recipe); p.recipe.cuda = cuda; p.logical = sem::make_graph(p.recipe.fragment);''')
replace('output[r.original_hidden].resource().device().kind == c::DeviceKind::kCuda','r.cuda')
# Two actual backend cases reuse the same existing Program and State journey.
anchor='#if defined(HYLE_TEST_GLM_STATE_CUDA)\nTEST(GlmMtpStateConsumer, CudaTarget43MlaFlowsThroughTarget44AndNextN) {'
replacement='''void run_original_indexer(c::Context &context, const c::StorageOwner &owner, bool cuda) {
  const auto input = original_prefix::directory("HYLE_GLM_MTP_INPUT_DIR");
  const auto query = original_prefix::directory("HYLE_GLM_MTP_QUERY_DIR");
  const auto indexer = original_prefix::directory("HYLE_GLM_MTP_INDEXER_DIR");
  if (input.empty() || query.empty() || indexer.empty()) {
    GTEST_SKIP() << "Set HYLE_GLM_MTP_INPUT_DIR, HYLE_GLM_MTP_QUERY_DIR and HYLE_GLM_MTP_INDEXER_DIR to authenticated layer45 roles";
  }
  run_seed_handoff(context, owner, cuda, original_nextn(input, query, indexer, owner));
}

#if defined(HYLE_TEST_GLM_STATE_CUDA)
TEST(GlmMtpStateConsumer, CudaOriginalIndexerPublishesCatchesUpAndReseeds) {
  auto context = take(g::cuda::create_context(), "ordinary original-indexer CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "original-indexer CUDA memory")), "original-indexer storage owner");
  run_original_indexer(context, owner, true);
}
TEST(GlmMtpStateConsumer, CudaTarget43MlaFlowsThroughTarget44AndNextN) {'''
replace(anchor,replacement)
replace('''struct SystemResource final { m::MemoryResourceRef ref() noexcept { return m::system_resource(); } };
TEST(GlmMtpStateConsumer, CpuTarget43MlaFlowsThroughTarget44AndNextN) {''','''struct SystemResource final { m::MemoryResourceRef ref() noexcept { return m::system_resource(); } };
TEST(GlmMtpStateConsumer, CpuOriginalIndexerPublishesCatchesUpAndReseeds) {
  auto context = take(g::cpu::create_context(), "ordinary original-indexer CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "original-indexer storage owner");
  run_original_indexer(context, owner, false);
}
TEST(GlmMtpStateConsumer, CpuTarget43MlaFlowsThroughTarget44AndNextN) {''')
p.write_text(s,encoding='utf-8',newline='\n')
print('wrote',p,len(s.encode()))
