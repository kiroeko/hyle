"""Publish BI actual original-parameter GLM Graph/state observations."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    return dict(path=str(path.relative_to(R)), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


runs = [read(S / f'checks{i}/summary.json') for i in (1, 2)]
cases = []
for i, (run, count) in enumerate(zip(runs, (2, 6)), 1):
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert run['tests'] == count
    assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
    tree = ET.parse(S / f'checks{i}/results.xml').getroot()
    assert int(tree.attrib['tests']) == count
    for case in tree.iter('testcase'):
        assert case.attrib['result'] == 'completed'
        assert case.find('failure') is None and case.find('skipped') is None
    cases.extend(run['cases'])
assert len(cases) == len({(c['attributes']['classname'], c['attributes']['name']) for c in cases}) == 8
graphs = sum(int(c['properties']['actual_submissions']) for c in cases)
assert graphs == 204
new_cases = runs[0]['cases']
for case in new_cases:
    p = case['properties']
    assert p['original_roles'] == '14' and p['original_role_bytes'] == '88373248'
    assert p['original_runtime_bank_bytes'] == '88636928'
    assert p['actual_submissions'] == '26'
    assert [int(p[k]) for k in ('initialization_submissions', 'draft_extend_submissions',
        'skip_submissions', 'catchup_submissions', 'policy_submissions')] == [2, 11, 8, 4, 1]

sources = [R / p for p in (
    'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'tests/compute_models/glm_original_mtp_chain_test.cc',
    'tests/compute_models/glm_original_mtp_roles.h',
    'tests/compute_models/glm_original_indexer_roles.h',
    'tests/compute_models/glm_original_indexer_reference.h',
    'docs/developer/current-work.md', 'docs/implementation/model-operators.md')]
for tag in ('glm-state', 'glm-chain'):
    record = read(S / f'compile1/{tag}/identity.json')
    for field in (record['source'], record['object'], *record['dependencies']):
        dependency = Path(field['path'])
        assert dependency.stat().st_size == field['bytes'], field['path']
        assert hashlib.sha256(dependency.read_bytes()).hexdigest() == field['sha256'], field['path']
image = read(S / 'tests-link1/ready.json')['image']
assert identity(Path(image['path']))['sha256'] == image['sha256']

payloads = read(S / 'original-indexer/acquisition.json')
assert payloads['complete'] and payloads['downloaded_payload_bytes'] == 14943744
assert len(payloads['roles']) == 7
for row in payloads['roles']:
    assert identity(R / row['payload']['path']) == row['payload']
tail = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
tail = tail[tail.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == read(S / 'start.json')['performance_tail_utf8_sha256']

source_metadata = [R / p for p in (
    '.scratch/dspark-natural-journey-20261022/original-glm-input/acquisition.json',
    '.scratch/dspark-natural-journey-20261022/original-glm-input/header.json',
    '.scratch/glm-mtp-carry-20261022/original-glm-q-a/acquisition.json',
    '.scratch/glm-mtp-carry-20261022/original-glm-q-a/header.json',
    '.scratch/glm-mtp-carry-20261022/original-glm-q-a/inputnorm-acquisition.json',
    '.scratch/glm-mtp-carry-20261022/original-glm-q-a/qnorm-acquisition.json',
    '.scratch/large-gguf-head-20261023/review/next-original-suppliers.json',
    '.scratch/large-gguf-head-20261023/review/fixed-source/layernorm.py',
    '.scratch/glm-encoded-state-20261023/review/fixed-source/layers/attention/dsa/dsa_indexer_kpool.py')]
paths = set(sources + source_metadata)
paths.update(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in (
    '.h', '.cc', '.cu', '.py', '.json', '.txt', '.diff', '.log', '.xml', '.ps1'))
paths.discard(S / 'publication.json')
archive = D / 'mtp-glm-original-indexer-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for path in sorted(paths):
        z.write(path, path.relative_to(R).as_posix())

record = dict(date='2026-10-23', stage='BI', goal_complete=False,
    conclusion='Original officialFlash input/query and all seven dense indexer roles now run in the same existing complete NextN accepted-state journey, including accepted-only catchup and same-epoch skip.',
    artifact=dict(repository='zai-org/GLM-5.3-Flash', revision='eb9eb208eb0d988989d07a6a12d0fdeb5f52574a',
        original_checkpoint_roles=14, original_payload_bytes=88373248,
        runtime_banks=13, runtime_bank_bytes=88636928,
        byte_scope='Payload and post-load descriptor extents, not physical process/VRAM peak. q_a codes/scales form one packed carrier; selected original BF16 indexer parameters widen exactly to F32 according to the fixed reader.',
        new_payload_bytes=14943744, reused_input_query_bytes=73429504,
        acquisition=payloads, original_payloads_archived=False),
    implementation=dict(
        prefix='Extract previous seven-role authentication/canonical import, pure Fragment input/query builder and original F64/BF16 checks to one shared test helper. Old component tests retain9 Graph submits each and original math/gates. The complete NextN reuses this same builder inside its existing Graph.',
        bank_lifetime='Upload13 runtime banks once per backend through existing StorageOwner/ReadLease. All fresh/journal/directcatchup graphs bind the same immutable roles rather than copying weight payload into every Recipe. Final exact stored bytes/readonly permissions retained.',
        precision='Actual BF16 EH/inputnorm/q_a/qnorm feeds exact widened F32 nx/qr where the existing state/MLA contract needs it. Original BF16 wk,wq_b,compressgate use F32 accumulations then explicit BF16 stores; WK store precedes F32 LayerNorm with exact loaded norm/bias, followed by a BF16 raw-key store. weights_proj and APE widen once at load and preserve their F32 math. q_a explicitly retains Divide/floor1e-10; UE8M0 cache/query retains PowerOfTwo/floor1e-4.',
        state='Same17 native NextN/indexer resources plus epoch metadata, ordinary StateStore/Head/Draft. Accepted1/2 determines actual seed; step0 skips the entire indexer, preserves its state and journals actual accepted nx; journal/directcatchup use the same original roles before epoch8 fresh seed. target43 offset roles remain distinct and are never populated by layer45 original coefficients.',
        product='No new public API, provider, executor, dispatcher or product compatibility path. Existing public operations/resource/state mechanisms are reused.'),
    validation=dict(unique_tests=8, failures=0, errors=0, skips=0,
        model_graph_submissions=graphs, new_original_model_graph_submissions=52,
        related_regression_graph_submissions=152,
        cases=cases,
        related_regressions='Old generated seed journey52 Graphs, generated target43->44->NextN34-resource composition82 Graphs, original input/query chain18 Graphs. These are separate scopes; original14 roles were tested in the17-resource NextN journey, not relabeled as an original full target43/44 model.',
        numerical='Independent original-prefix checks unchanged. New dense indexer references start from actual checked BF16 inputs and original BF16 coefficients, use compensated F64 dots with explicit F64 oracle and F32 gammaK error bounds, prove finite/exact products and normal quantum/overflow conditions. Every actual F32->BF16 store checked bitwise. Local LayerNorm starts from actual roundedWK; pooling reads actual BF16 rings and originalAPE. No empirical tolerance widening.',
        numerical_observations=read(S / 'numerical-observations.json'),
        commands_and_results=[identity(S / f'checks{i}/summary.json') for i in (1,2)],
        compiled_host_translation_units=2, SDK_builds=0, native_CPU_builds=0,
        NVCC_builds=0, shaders=0, first_native_run_failures=0),
    source_reviews=[identity(S / p) for p in (
        'prefix-source/freeze.json', 'state-source/freeze.json', 'reference-source/freeze.json',
        'review/glm-prefix-extraction-independent.json', 'review/glm-indexer-reference-independent.json',
        'review/glm-original-indexer-state-independent.json', 'review/glm-original-nextn-state-independent.json')],
    source_metadata=[identity(p) for p in source_metadata],
    limitations=['WindowsCPU/CUDA only; no new Linux/Apple/Vulkan model run.',
        'Target hidden/embedding and remaining MLA/MoE/head coefficients generated; no full45-layer checkpoint, original sharedLM, Progeometry or natural acceptance/generation quality claim.',
        'Official HF mixed original/generated consumer identity is explicit; not primaryGGUF tensor equality or all quantization implementations.',
        'Logical UE8M0 codes/scales/rings are tested, not vendor physical page/footer ABI.',
        'Source role totals and bank descriptor bytes are not physical memory/VRAM peaks. No new loading, TPS or full four-arm benchmark; AV performance table retained.',
        'Full MTP and broader architecture/performance/image goal remain incomplete.'],
    next='DSpark original13norm/sink+21HC roles9827740B, then remaining actual-role/sharedLM/targettap/Pro/confirmedquant work. Three original routerbiases require actual selected experts resident; never filter original IDs to fit the generated smallbank. Necessary final ordinary/MTP performance comparison remains before image chain.',
    final_image=image, sources=[identity(p) for p in sources],
    performance_tail_sha256=tail_hash,
    cleanup='One current executable/map and two host objects/recipes retained for replay and later incremental linking; no superseded BI image, whole shard or SDK copy was produced. No deletion required.',
    archive=identity(archive), archive_items=len(paths))
out = D / 'mtp-glm-original-indexer-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(out), archive=identity(archive)),
    ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(out), archive=identity(archive), tests=8, graphs=graphs), ensure_ascii=False))
