"""Increment only ready-frame owner and actual tests against retained closures."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
E=R/'.scratch/paged-exclusive-20261021';F=R/'.scratch/paged-host-prepare-20261021';P=R/'.scratch/shared-execution-20261021'
spec=importlib.util.spec_from_file_location('retained_build',E/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
def compile_owner(tag,attempt):
    h.S=S
    if tag in ('arena-tests','row-tests'):
        path=S/'recipes'/(tag+'.json');path.parent.mkdir(parents=True,exist_ok=True)
        old=c.read(S/'reframe-tests/retained-recipe.json')['historical_compile']['command']
        c.save(path,dict(command=old,scope='Compiler recipe only; no historical product libraries used.'))
        h.RECIPES[tag]=('tests/compute_batch/'+('paged_arena_test.cc'if tag=='arena-tests'else'row_cache_paged_test.cc'),path)
    return h.compile_owner(tag,attempt)
def link(mode,attempt,core_attempt,owner_attempt):
    unit=mode in ('arena-tests','row-tests')
    prior_path=P/'qwen-ready-attempt2.json' if unit else F/f'{mode}-ready-attempt1.json'
    prior=c.read(prior_path);base=c.read(prior['link_plan']['path'])
    owner={'cpu':'cpu-test','cuda':'cuda-test','arena-tests':'arena-tests','row-tests':'row-tests'}[mode]
    old_owner=P/'compile2/main/main.obj' if unit else E/f'compile1/{owner}/{owner}.obj'
    record_paths=[S/f'compile{core_attempt}/arena/identity.json',S/f'compile{owner_attempt}/{owner}/identity.json']
    records=[c.read(p)for p in record_paths]
    assert all(h.same(row)for rec in records for row in [rec['source'],rec['object'],*rec['dependencies']])
    assert all(h.same(row)for row in base['inputs'])
    replacements={c.key(E/'compile1/arena/arena.obj'):records[0]['object'],c.key(old_owner):records[1]['object']}
    assert all(sum(c.key(row['path'])==key for row in base['inputs'])==1 for key in replacements)
    extra=[b.identity(R/'.scratch/build-compute-v2-dev/lib'/name)for name in ('gtest_main.lib','gtest.lib')]if unit else[]
    inputs=[replacements.get(c.key(row['path']),row)for row in base['inputs']]+extra
    assert len({c.key(row['path'])for row in inputs})==len(inputs)
    out=S/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/(mode+'.exe')
    command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command += [x['path']for x in extra]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(prior['link_plan']['path']),
        replaced_inputs=[dict(before=row,after=replacements[c.key(row['path'])])for row in base['inputs']if c.key(row['path'])in replacements],
        added_inputs=extra,compiled_records=[b.identity(p)for p in record_paths],NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[row['path']for row in inputs],out);c.execute('link',command,env,out)
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):os.link(dll,out/dll.name)
    runtime=c.read(prior['runtime_environment']['path']);runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
    if mode=='cpu'and 'CPU_native_overlay'in runtime:runtime['CPU_native_overlay']['destination']=b.identity(out/'hyle_ggml_cpu_append_hyca.dll')
    c.save(out/'runtime-environment.json',runtime)
    c.save(S/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=records[1]['source'],fresh_sources=[r['source']for r in records],
        link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),NVCC=0,SDK_builds=0))
    print('READY',mode,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('arena','arena-tests','row-tests','cpu-test','cuda-test','cpu','cuda'))
    p.add_argument('--attempt',type=int,default=1);p.add_argument('--core-attempt',type=int,default=1);p.add_argument('--owner-attempt',type=int,default=1);p.add_argument('--link',action='store_true');a=p.parse_args()
    if a.link:link(a.mode,a.attempt,a.core_attempt,a.owner_attempt)
    else:compile_owner(a.mode,a.attempt)
