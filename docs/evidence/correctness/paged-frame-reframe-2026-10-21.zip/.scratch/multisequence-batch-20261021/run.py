"""Root-only serial permission/math checks. This driver never times inference."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
S=Path(__file__).resolve().parent;R=S.parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p).resolve();data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
p=argparse.ArgumentParser();p.add_argument('mode',choices=('arena-tests','row-tests','cpu','cuda'));p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
ready_path=S/f'{a.mode}-ready-attempt{a.attempt}.json';ready=read(ready_path)
assert identity(ready['image']['path'])==ready['image'];assert identity(ready['runtime_environment']['path'])==ready['runtime_environment']
out=S/f'{a.mode}-run{a.attempt}';out.mkdir(exist_ok=False)
command=[ready['image']['path']]
if a.mode=='arena-tests':command+=['--gtest_filter=PagedArena.*','--gtest_output=xml:'+str(out/'gtest.xml')]
if a.mode=='row-tests':command+=['--gtest_output=xml:'+str(out/'gtest.xml')]
env=os.environ.copy();env['PATH']=read(ready['runtime_environment']['path'])['PATH']
record=dict(command=command,image=ready['image'],ready=identity(ready_path),cwd=str(R),started_unix_ns=time.time_ns(),throughput_evidence=False,profiler=False)
save(out/'command.json',record)
process=None
with (out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
    try:
        process=subprocess.Popen(command,cwd=R,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW);record['pid']=process.pid
        try:record['exit']=process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['timeout']=True;process.kill();record['exit']=process.wait()
    finally:
        if process is not None and process.poll()is None:process.kill();process.wait()
        record['finished_unix_ns']=time.time_ns();save(out/'result.json',record)
print((out/'stdout.log').read_text(encoding='utf-8-sig'))
if record['exit']!=0:print((out/'stderr.log').read_text(encoding='utf-8-sig'))
assert record['exit']==0 and not record.get('timeout'),out
