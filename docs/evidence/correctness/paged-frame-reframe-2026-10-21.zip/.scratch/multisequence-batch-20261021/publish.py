"""Publish only the completed typed reframe module; no build, run or deletion."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, xml.etree.ElementTree as ET, zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
STEM = 'paged-frame-reframe-2026-10-21'
SMALL = {'.h', '.cc', '.cpp', '.diff', '.json', '.log', '.xml', '.py', '.ps1'}
MODULES = {
    'include/hyle/compute/paged_arena.h': '24d54cdae3a2c46f28126fffbfce06fc28ee6acb44c677324ce4f8fbaf67d458',
    'src/compute_batch/paged_arena.cc': '95fa8b24e1727d9902778ee34a0a7d3f31d7d8aec053be3c5f10e1ee0b4f0bc6',
    'tests/compute_batch/paged_arena_test.cc': '64d5f589ba19230cb910edea44bf0ecb3e729e214b26c6bbea946209f1ea32e4',
    'tests/compute_batch/row_cache_paged_test.cc': '3d124b600984bfc7adda0ee93d1f7f94e8ac3cf5f87f4d2e16dcce4c59b59fb0',
    'tests/graph_batch/paged_append_graph_test.cc': 'd7a39e0c9ace64ca0b16341751aeab4ab475ffb557e882ca95dadb541b646093',
    'tests/graph_batch/paged_append_cuda_consumer.cc': '0932744da45c4412c26a74c6f6b37661cb158756f7bcb167d4fdecdcd10e8f30',
}
DOCS = {
    'docs/user/batch-attention.md': '829d8f715561ddff22d28b3a7cab88239c7b2eca14414fe6a90f66b1ff238a5e',
    'docs/architecture/compute-design.md': '80770e6e1f6f3904977a4fa1e917de06425b8fbf3a5bd519080bf4bc75ed0a28',
}
RUNS = [('arena-tests', 2, 27), ('row-tests', 1, 7), ('cpu', 2, 11), ('cuda', 2, 8)]
OWNERS = {'arena', 'arena-tests', 'row-tests', 'cpu-test', 'cuda-test'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def verify(record):
    assert identity(record['path']) == record, 'Identity drift: ' + record['path']


def terminal(path):
    value = read(path)
    assert value['exit'] == 0 and not value.get('timeout'), path
    return value


def main():
    report_path = R / 'docs/evidence/correctness' / (STEM + '.json')
    archive = report_path.with_suffix('.zip')
    receipt = S / 'published.json'
    assert not any(p.exists() for p in (report_path, archive, receipt)), 'Publication already exists; never overwrite it'
    sources, docs = [], []
    for mapping, output in ((MODULES, sources), (DOCS, docs)):
        for relative, digest in mapping.items():
            record = identity(R / relative)
            assert record['sha256'] == digest, 'Frozen module/doc changed: ' + relative
            output.append(record)
    final_review = S / 'review/final-runtime-review.json'
    review = read(final_review)
    assert review['core']['sha256'] == MODULES['src/compute_batch/paged_arena.cc']
    assert review['public_header']['sha256'] == MODULES['include/hyle/compute/paged_arena.h']
    results, records = {}, {}
    for mode, attempt, count in RUNS:
        ready_path = S / f'{mode}-ready-attempt{attempt}.json'
        ready = read(ready_path)
        folder = S / f'{mode}-run{attempt}'
        process = terminal(folder / 'result.json')
        verify(process['ready'])
        assert process['image'] == ready['image'] and not process['throughput_evidence'] and not process['profiler']
        # run.py hashed the actual image immediately before launch. The exact
        # image is also in cleanup-plan; do not rehash large inherited inputs.
        verify(ready['link_plan'])
        verify(ready['runtime_environment'])
        plan = read(ready['link_plan']['path'])
        assert len(plan['replaced_inputs']) == 2 and plan['NVCC'] == plan['SDK_builds'] == 0
        assert any(Path(x['after']['path']).name == 'arena.obj' for x in plan['replaced_inputs'])
        for record in plan['compiled_records']:
            verify(record)
            records[record['path']] = record
        text = (folder / 'stdout.log').read_text(encoding='utf-8-sig')
        if mode in ('arena-tests', 'row-tests'):
            xml = ET.parse(folder / 'gtest.xml').getroot()
            cases = xml.findall('.//testcase')
            assert int(xml.attrib['tests']) == count and xml.attrib['failures'] == xml.attrib['errors'] == '0'
            assert len(cases) == count and all(x.attrib['status'] == 'run' and x.attrib['result'] == 'completed' and not x.findall('failure') for x in cases)
            observed = dict(gtest_cases=count, failures=0, xml=identity(folder / 'gtest.xml'))
        else:
            assert len([line for line in text.splitlines() if line.endswith(' PASS')]) == count
            observed = dict(success_journey_statements=count)
        results[mode] = dict(result=identity(folder / 'result.json'), ready=identity(ready_path), image=ready['image'], observed=observed,
            stdout=identity(folder / 'stdout.log'), stderr=identity(folder / 'stderr.log'), link_plan=ready['link_plan'])
    assert len(records) == 5
    for record in records.values():
        compiled = read(record['path'])
        assert compiled['source']['sha256'] == MODULES[Path(compiled['source']['path']).relative_to(R).as_posix()]
        verify(compiled['source']); verify(compiled['object'])
        assert all(flag in compiled['command'] for flag in ('/W4', '/WX'))
        terminal(Path(record['path']).parent / 'compile.result.json')
    first_failure = S / 'compile1/cpu-test/compile.result.json'
    assert read(first_failure)['exit'] == 2
    assert 'C4456' in (first_failure.parent / 'compile.stdout.log').read_text()
    cleanup_path = S / 'cleanup-plan.json'
    cleanup = read(cleanup_path)
    assert cleanup['status'] == 'PLAN ONLY; nothing deleted' and len(cleanup['targets']) == 28
    assert cleanup['counts'] == dict(exe=7, map=7, lib=7, exp=7)
    for item in cleanup['targets']:
        assert Path(item['path']).resolve().is_relative_to(S) and Path(item['path']).suffix.lower() in ('.exe', '.map', '.lib', '.exp')
    for result in results.values():
        assert result['image'] in cleanup['targets'], 'Missing exact image cleanup identity'

    paths = {}
    for path in S.rglob('*'):
        relative = path.relative_to(S)
        if not path.is_file() or path.suffix.lower() not in SMALL or path.name == 'published.json':
            continue
        # Subsequent full-Qwen work is deliberately outside this module batch.
        if any(part.lower() in ('tmp', '__pycache__', 'main', 'session', 'probe') or
               any(word in part.lower() for word in ('qwen', 'session_', 'retirement_probe', 'main.')) for part in relative.parts):
            continue
        paths[path.relative_to(R).as_posix()] = path
    for relative in (*MODULES, *DOCS):
        paths[relative] = R / relative
    inventory = [dict(archive_path=name, **identity(path)) for name, path in sorted(paths.items())]
    assert all(Path(x['archive_path']).suffix.lower() in SMALL or x['archive_path'] in DOCS for x in inventory)
    payload = dict(scope='Completed typed ready-frame reframe module only; source/before/diffs, exact commands/identities, raw results/logs/XML and fixed docs.',
        files=inventory, exclusions='No exe,obj,lib,exp,dll,map,payload,model/SDK bytes; no changing Qwen main/session/probe source.',
        incomplete='Full Qwen multi-sequence B2 is not implemented or validated by this module evidence. No performance or other-native-backend claim.')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for name, path in sorted(paths.items()):
            output.write(path, name)
        output.writestr('archive-inventory.json', json.dumps(payload, indent=2))
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        assert all(hashlib.sha256(check.read(x['archive_path'])).hexdigest() == x['sha256'] for x in inventory)
    builds = []
    for path in sorted(S.glob('compile[123]/*/compile.result.json')):
        if path.parent.name in OWNERS:
            builds.append(dict(result=identity(path), exit=read(path)['exit']))
    report = dict(date='2026-10-21', created_utc=datetime.now(timezone.utc).isoformat(),
        status='Typed attention/MLA and row-cache ready-frame composition/projection implemented; finite Windows CPU/CUDA module checks passed.',
        sources=sources, docs=docs, archive=identity(archive), archive_file_count=len(inventory), correctness=results,
        final_independent_review=identity(final_review), compiled_records=list(records.values()), host_compile_attempts=builds,
        retained_first_warning_failure=identity(first_failure), cleanup_plan=identity(cleanup_path),
        reproduction=dict(commands='Archived compile.command/result, sourceDependencies/identity, link-plan/result/runtime-environment and run command/result records are authoritative.',
            cache='Reuse their exact fixed compiler/gtest/native DLL/SDK/object cache paths. The archive does not duplicate SDKs or retained object closures. B/build.py and B/run.py are preserved; their existing helper imports and all referenced caches must remain available.',
            inherited_inputs='Exact recorded input hashes retained in link-plan files; not rehashed or copied into this module archive.',
            final_runs='arena-tests-run2, row-tests-run1, cpu-run2, cuda-run2; initial source/compile failure and revision1 records remain unchanged.'),
        limits=['27 attention arena and7row gtest cases; CPU11/CUDA8 are success journey statements, not additional formal gtest-case counts.',
            'Reframe grants no new page authority: target prefix is bounded by supplied immutable source layout and original guards; output retains only selected pages. Row and attention public types remain distinct.',
            'Full Qwen B2 batching, its recurrent/conv state/positions/publication, serving scheduling, throughput and other native backends remain unimplemented or unvalidated here.',
            'This script only publishes bounded evidence. It does not run a consumer, rebuild, query devices, alter source/docs content or delete any file. Existing published outputs are never overwritten.'])
    for path, value in ((report_path, report), (receipt, dict(manifest=str(report_path), archive=str(archive), files=len(inventory)))):
        with path.open('x', encoding='utf-8') as stream:
            json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps(dict(manifest=identity(report_path), archive=identity(archive), files=len(inventory)), indent=2))


if __name__ == '__main__':
    main()
