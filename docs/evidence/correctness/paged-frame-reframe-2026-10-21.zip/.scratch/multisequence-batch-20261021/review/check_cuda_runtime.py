"""Read-only core1 CUDA/runtime/source proof. Never builds or starts a model."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
S=Path(__file__).resolve().parent.parent;R=S.parents[1];O=S/'review';P=O/'cuda-source-proof/core1'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p).resolve();h=hashlib.sha256()
    with p.open('rb') as f:
        for data in iter(lambda:f.read(8<<20),b''):h.update(data)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(row):
    assert identity(row['path'])==row, row['path']
    return row
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
expected={'paged_arena.cc':'e10685442b677b6585a9aa8052f56d855975279e73131ad405b161f22dbd5b02',
 'paged_arena.h':'dd3d8033e41d72b04773b9198a878a2e3e073dae6da7695f7a32bfac2c9587ef',
 'paged_append_cuda_consumer.cc':'0932744da45c4412c26a74c6f6b37661cb158756f7bcb167d4fdecdcd10e8f30'}
for name,sha in expected.items():assert identity(P/name)['sha256']==sha
ready_path=S/'cuda-ready-attempt1.json';ready=read(ready_path);receipt_path=S/'cuda-run1/result.json';receipt=read(receipt_path)
assert receipt['exit']==0 and not receipt.get('timeout') and not receipt['throughput_evidence'] and not receipt['profiler']
assert receipt['image']==ready['image'] and receipt['ready']==identity(ready_path)
assert receipt['command']==[ready['image']['path']] and receipt['finished_unix_ns']>=receipt['started_unix_ns']
verify(ready['image']);verify(ready['link_plan']);verify(ready['runtime_environment'])
plan=read(ready['link_plan']['path']);verify(plan['base']);base=read(plan['base']['path'])
assert len(plan['inputs'])==len(base['inputs'])==194 and not plan['added_inputs']
changes=[dict(ordinal=i,before=b,current=x) for i,(b,x) in enumerate(zip(base['inputs'],plan['inputs'])) if b!=x]
assert len(changes)==2 and len(plan['replaced_inputs'])==2
# Verify the actual retained input bytes, not just the JSON names or old source paths.
for row in plan['inputs']:verify(row)
compiled=[]
for record in plan['compiled_records']:
    verify(record);value=read(record['path']);verify(value['object'])
    name=Path(value['source']['path']).name
    assert value['source']['sha256']==expected[name] and sum(x==value['object'] for x in plan['inputs'])==1
    snapshot=Path(record['path']).parent/'source'/Path(value['source']['path']).relative_to(R)
    assert identity(snapshot)['sha256']==expected[name]
    header=next(x for x in value['dependencies'] if Path(x['path']).name=='paged_arena.h')
    assert header['sha256']==expected['paged_arena.h']
    assert all(x in value['command'] for x in ['/W4','/WX','/O2','/MD','/DHYLE_STATIC'])
    if name.endswith('consumer.cc'):assert '/DHYLE_APPEND_STANDALONE=1' in value['command']
    command_path=Path(record['path']).parent/'compile.command.json';result_path=command_path.with_name('compile.result.json')
    result=read(result_path);assert result['exit']==0 and result['terminal']
    compiled.append(dict(identity=record,source_at_compile=value['source'],object=value['object'],
        source_snapshot=identity(snapshot),actual_header_dependency=header,compile_command=identity(command_path),compile_receipt=identity(result_path)))
assert {x['object']['sha256'] for x in compiled}=={x['current']['sha256'] for x in changes}
link_receipt=Path(ready['image']['path']).parent/'link.result.json';assert read(link_receipt)['exit']==0 and read(link_receipt)['terminal']
map_path=Path(ready['image']['path']).with_suffix('.map')
symbols=[line.strip() for line in map_path.read_text(encoding='utf-8-sig',errors='replace').splitlines()
    if re.match(r'\s*[0-9A-Fa-f]+:[0-9A-Fa-f]+\s+\?reframe@PagedArena@',line)]
assert len(symbols)==1 and symbols[0].endswith('arena.obj')
stdout=(S/'cuda-run1/stdout.log').read_text(encoding='utf-8-sig');lines=stdout.splitlines()
assert len(lines)==8 and all(line.endswith(' PASS') for line in lines)
assert lines[-1]=='CUDA two-request compose -> same Graph append/causal attention -> typed request projection PASS'
source=(P/'paged_append_cuda_consumer.cc').read_text(encoding='utf-8')
assert 'profile < 5' in source and 'all(4)' in source and 'expected_means{.3125f, .4f, .5625f, .7f}' in source
assert 'next_keys = {}; next_values = {}; returned_keys = {}; returned_values = {};' in source
# CPU API receipts are independently bound to this same core1 object/header.
api={}
arena_object=next(x['object'] for x in compiled if Path(x['source_at_compile']['path']).name=='paged_arena.cc')
for mode in ('cpu','arena-tests'):
    rp=S/f'{mode}-ready-attempt1.json';value=read(rp);result=S/f'{mode}-run1/result.json';d=read(result)
    assert d['exit']==0 and d['ready']==identity(rp) and d['image']==value['image']
    cp=read(value['link_plan']['path']);assert sum(x==arena_object for x in cp['inputs'])==1
    assert any(x==plan['compiled_records'][0] for x in cp['compiled_records'])
    api[mode]=dict(ready=identity(rp),image=value['image'],result=identity(result),stdout=identity(S/f'{mode}-run1/stdout.log'),
        link_plan=identity(value['link_plan']['path']),same_core1_arena_object=arena_object)
xml_path=S/'arena-tests-run1/gtest.xml';xml=ET.parse(xml_path).getroot();cases=list(xml.iter('testcase'))
assert len(cases)==27 and not list(xml.iter('failure')) and not list(xml.iter('error')) and not list(xml.iter('skipped'))
reframe_names=[x.attrib['name'] for x in cases if x.attrib['name'].startswith('Reframe')]
assert len(reframe_names)==6 and all(x.attrib.get('status')=='run' and x.attrib.get('result')=='completed' for x in cases)
api['arena-tests'].update(xml=identity(xml_path),tests=27,failures=0,skips=0,new_reframe_cases=reframe_names,
    filter_scope='PagedArena.* only; does not include the separate PagedAdmission suite.')
proof=dict(scope='Exact core1 e106 / dd3 and fixture093 actual CUDA result. RowCache/common_impl revision2 is excluded.',
    sources=[identity(P/name) for name in expected],product_first_freeze=identity(P/'product-source-freeze-first.json'),
    fixture_first_freeze=identity(S/'cuda-fixture/source-freeze.json'),compiled_records=compiled,
    closure=dict(plan=identity(ready['link_plan']['path']),base=plan['base'],input_count=194,unchanged_inputs=192,
        replaced_inputs=changes,all194_input_payload_SHA_checked=True,input_bytes=sum(x['bytes'] for x in plan['inputs']),
        unique_reframe_public_symbol=symbols[0],map=identity(map_path),link_receipt=identity(link_receipt),NVCC=0,SDK_builds=0),
    observed_canonical_now=[dict(identity=identity(R/rel),matches_executed_core1=identity(R/rel)['sha256']==expected[Path(rel).name])
        for rel in ['src/compute_batch/paged_arena.cc','include/hyle/compute/paged_arena.h','tests/graph_batch/paged_append_cuda_consumer.cc']],
    boundary='Canonical source may already advance torevision2. Only the copied/source-at-compile core1 snapshots and old selected object support this runtime claim.')
proof_path=O/'cuda-source-proof.json';save(proof_path,proof)
review=dict(status='PASS for the actual core1 plain BF16 CUDA fixture and receipt-bound CPU API metadata; no concrete blocker found.',
    source_proof=identity(proof_path),checker=identity(__file__),cuda=dict(ready=identity(ready_path),image=ready['image'],result=identity(receipt_path),
        stdout=identity(S/'cuda-run1/stdout.log'),stderr=identity(S/'cuda-run1/stderr.log'),exit=0,
        standalone_profiles=5,PASS_messages=8,messages=lines),cpu_API_metadata=api,
    existing_independent_API_review=identity(O/'reframe-runtime-review.json'),
    source_contract=[
        dict(anchors='fixture core1:39-140,216-227',finding='One reused journey multi-domain: old sharedfullpage0 and independentpartial1/4; compose original single-request frames to2requests; next0,2,3 and0,5,6; fourBF16 query rows. Exact expected means5/16,2/5,9/16,7/10 distinguish batch mixing and causal omission. Source checks every returned BF16 word without tolerance.'),
        dict(anchors='fixture core1:150-192,228-270',finding='Original producer Copy/logicalView, two typed append effect nodes, exact direct dependencies and one wholeGraph submit remain. wait/result observers retire before take; stale submit still rejects. ready has5unique pages; projections each3pages, aggregate frames/append owners are dropped before projected guards must still block reacquisition.'),
        dict(anchors='fixture core1:271-284,788-829',finding='Both original single-request source layouts stay unchanged; old3 physical value pages including NaN unused tails are read back byte-for-byte unchanged. Existing four profiles and missingDAG/capture/mapping/exclusive checks still run before newprofile4.')],
    limitations=[
        'Reviewer ran no CXX/link/GPU/model. This report independently checked existing raw logs, source/object snapshots,194 actual linked input hashes, exact map owner and CPU/API receipts.',
        '8PASS log messages are not8GTest cases. The executable is standalone with5profiles; existing metadata profiles contain multiple episodes. Only the newprofile has the stated one Graph submit.',
        'GPU scope is plain BF16 R2/Q2/Hq2/Hkv1/D64/page2. No actual completeQwen B2/T1, throughput, mixedprefill/decode or other-native backend result is claimed.',
        'CPU27 PagedArena tests and six newtyped reframe cases cover only their actual filter; CPU Graph append is separately receipt-bound. These facts do not turn unexecuted RowCache overload/revision2 into a pass.',
        'No raw CUDA output tensor artifact was persisted by this standalone fixture; strict source assertions and terminalPASS establish the stated check, not a separate reviewer tensor-file comparison.',
        'Nonvirtual declaration addition in core1 leaves handle/descriptor/vtable layouts unchanged; this does not waive future revision2 source/ABI review or fresh owner/runtime validation.'
    ],activity=dict(builds=0,links=0,GPU_runs=0,product_edits=0))
target=O/'cuda-runtime-review.json';save(target,review)
print(json.dumps(dict(review=identity(target),source_proof=identity(proof_path),input_count=194,unchanged=192,passed_profiles=5,PASS_messages=8)))
