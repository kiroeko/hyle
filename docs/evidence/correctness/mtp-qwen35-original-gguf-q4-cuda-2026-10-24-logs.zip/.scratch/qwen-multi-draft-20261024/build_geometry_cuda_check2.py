from pathlib import Path
import json,os,subprocess,sys,time,hashlib,shutil
R=Path.cwd();W=Path(__file__).resolve().parent;E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check'
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
sys.stdout.reconfigure(encoding='utf8',errors='replace');folder=W/'geometry-cuda-check2';folder.mkdir(exist_ok=True)
source=folder/'source';local=source/'engine/models/qwen35';local.mkdir(parents=True,exist_ok=True)
files=[]
for p in (R/'engine/models/qwen35').iterdir():
 if p.suffix in ('.h','.cc'):
  out=local/p.name;shutil.copyfile(p,out);files.append(dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
(source/'probe.cc').write_text('#include \"engine/models/qwen35/main.cc\"\nint main(int argc,char **argv){return qwen35::run(argc,argv); }\n')
(folder/'sources.json').write_text(json.dumps(files,indent=2)+'\n')
recipe=json.loads((E/'model-cuda/identity.json').read_text())['command'];command=[];skip=False
for arg in recipe:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 if arg.startswith(('/Fo','/Fd')):continue
 if arg.endswith('main.cc'):arg=str(source/'probe.cc')
 command.append(arg)
command+=['/DHYLE_COMPUTE_CPU=1']
command+=['/Fo'+str(folder/'test.obj'),'/Fd'+str(folder/'test.pdb')]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
link=[arg for arg in json.loads((E/'link-cuda-dense.json').read_text())['command'] if not arg.endswith(('qwen.obj','entry.obj')) and not arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
link=[str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj') if arg.endswith('graph--executable.obj') else arg for arg in link]
link+=[str(folder/'test.obj'),'/OUT:'+str(folder/'recursive-probe.exe')]
shared=[p for p in link if p.lower().endswith(('.obj','.lib')) and p!=str(folder/'test.obj') and Path(p).is_absolute()];missing=[p for p in shared if not Path(p).is_file()];assert not missing,missing
(folder/'shared-object-dependencies.json').write_text(json.dumps(shared,indent=2)+'\n')
ready=json.loads((E/'ready-cuda.json').read_text());native=Path(ready['native_runtime']['path']);target=folder/native.name
if not target.exists():os.link(native,target)
assert hashlib.sha256(target.read_bytes()).hexdigest()==ready['native_runtime']['sha256']
runtime=dict(env,PATH=str(folder)+os.pathsep+ready['PATH'])
for label,args in [('compile',command),('link',link)]:
 (folder/(label+'-command.json')).write_text(json.dumps(args,indent=2)+'\n');print('START',label,flush=True);start=time.time()
 with (folder/(label+'.log')).open('wb') as f:p=subprocess.run(args,cwd=R,env=runtime,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 (folder/(label+'-process.json')).write_text(json.dumps(dict(exit=p.returncode,seconds=time.time()-start),indent=2)+'\n')
 print('END',label,p.returncode,(folder/(label+'.log')).read_text(encoding='utf8',errors='replace')[-3000:],flush=True)
 if p.returncode:sys.exit(p.returncode)
(folder/'identity.json').write_text(json.dumps(dict(image_sha256=hashlib.sha256((folder/'recursive-probe.exe').read_bytes()).hexdigest(),fresh_TUs=1,downloads=0,SDK_builds=0),indent=2)+'\n')
print('READY hybrid executable; no GPU model run',flush=True)
