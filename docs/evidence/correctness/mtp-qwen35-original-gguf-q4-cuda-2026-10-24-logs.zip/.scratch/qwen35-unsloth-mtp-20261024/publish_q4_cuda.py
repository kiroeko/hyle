from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent;I=S/'complete-v2/Q4';B=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2';E=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_text())
def identity(p):
 raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
source=read(I/'input.json');cpu=E/'mtp-qwen35-original-gguf-q4-cpu-2026-10-24.json';cpu_proof=read(cpu);assert cpu_proof['source_id']==source['source_id']
failure=I/'cuda-ordinary-checked-embedding';assert read(failure/'process.json')['exit']==3221226505
assert 'HYLE fatal: live() == 0'in(failure/'stderr.log').read_text()
fix=read(failure/'retirement-fix-source-diff.json');assert fix['other_app_sources_unchanged']
cases=[];files={}
def add(p,name=None):assert p.is_file(),p;files[name or p.relative_to(R).as_posix()]=p
for name in ['ordinary','k1','k4-random']:
 folder=I/('cuda-'+name+'-resource-order');result=read(folder/'functional-result.json');assert result['status']=='PASS'and result['process']['exit']==0
 report=result['report'];assert report['score_policy']=='gguf_encoded_weight_projection_f32_logits'
 host=next(x for x in cpu_proof['cases']if x['name']=='cpu-'+name);assert report['generated_ids']==host['generated_ids']
 cases.append(dict(name='cuda-'+name,exit=0,generated_ids=report['generated_ids'],generated_tokens=report['generated_tokens'],mtp=report['mtp'],sampling=report['sampling'],
  original_host_weight_bytes=report['original_host_weight_bytes'],original_device_weight_bytes=report['original_device_weight_bytes'],
  score_dtype=report['score_dtype'],score_policy=report['score_policy'],cache_peak_requested_bytes=report['cache_peak_requested_bytes'],cache_requested_byte_limit=report['cache_requested_byte_limit'],
  actual_target_rows=report['actual_target_rows'],actual_draft_rows=report['actual_draft_rows'],prefix_decision_graph_calls=report['prefix_decision_graph_calls'],
  sampling_draw_cursor=report.get('sampling_draw_cursor',0),CPU_short_case_generated_ids_equal=True,case_result=identity(folder/'functional-result.json')))
 for p in folder.iterdir():
  if p.is_file():add(p)
for p in failure.iterdir():
 if p.is_file():add(p)
for p in [S/'run_q4_cuda.py',R/'.scratch/qwen-multi-draft-20261024/build_geometry_cuda_check2.py',Path(__file__),I/'input.json',I/'weights.tsv',I/'prompt.ids']:
 add(p)
for p in (B/'source').rglob('*'):
 if p.is_file():add(p)
for name in ['sources.json','identity.json','compile-command.json','compile-process.json','compile.log','link-command.json','link-process.json','link.log','shared-object-dependencies.json']:add(B/name)
stem='mtp-qwen35-original-gguf-q4-cuda-2026-10-24';archive=E/(stem+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(files.items()):z.write(p,name)
proof=dict(date='2026-10-24',status='PASS finite original complete-model CUDA paths after resource-order correction',
 scope='Original complete335-role Qwen3.5-2B Unsloth MTP GGUF Q4 CUDA ordinary/K1/K4random; no task-quality, throughput comparison or complete hardware-memory certification.',
 source=source['original_gguf_source'],source_id=source['source_id'],original_roles=335,original_payload_bytes=1373938944,shared_embedding_head_codec='Q6_K',
 prompt_tokens=154,capacity=256,cache_byte_limit=268435456,representation='Original encoded role ranges resident on CUDA; no whole-model floating bank conversion.',
 CPU_evidence=identity(cpu),cases=cases,
 first_failure=dict(case='ordinary',process=read(failure/'process.json'),last_completed_trace='generation_decode_end',diagnostic='HYLE fatal: live() == 0 at src/compute_backend_cuda/cuda_memory.cc:351',
  meaning='All four requested next-token trace steps finished, but the normal Model destructor destroyed its CUDA allocation resource before still-live weight/pool buffers. No final JSON or functional PASS was signed.',
  source_archive=identity(failure/'initial-source-freeze.zip'),resource_assertion_preserved=True),
 exact_fix=dict(source_diff=fix,
  changes=['Remove ColdResources::retire premature retirement_backend.reset().','Always move the original execution Backend into ColdResources::retirement_backend during Model destruction.'],
  lifetime='ColdResources declares the original Backend first so its destructor runs last, after compiled programs, retained payloads, weights and pools. The normal path now preserves the same ordering needed by genuine unresolved retirement.',
  source_scope='Only these two lines changed between first failing CUDA consumer and the three successful runs; other frozen app source hashes matched. No numeric, embedding or sampling change was made during this regression.',
  resource_guard='The CUDA live-allocation assertion remains unchanged. Unknown native retirement/fault cases belong to the separately recorded focused lifecycle tests.'),
 score_precision=dict(policy='gguf_encoded_weight_projection_f32_logits',
  meaning='Recipe scores explicitly casts BF16 A to F32 and invokes the existing encoded GGUF MatMul into F32 logits. This tag does not promise dense native F32 accumulation; a selected encoded implementation may have its own quantized dot contract.',
  CPU_archive_note='The already frozen CPU evidence retains its older report label. It was not rewritten; this supplemental CUDA snapshot includes the source-derived report correction.'),
 validation=dict(successful_cases=3,failed_initial_cases=1,SDK_builds=0,new_HTTP=0,shared_closure=identity(B/'shared-object-dependencies.json'),
  build='One consumer TU per source attempt, reusing the existing CUDA public runtime/Graph/provider objects. No full SDK rebuild.',image=identity(B/'recursive-probe.exe'),
  limits=['P154, C256, short4/4/6-output functional runs only. Matching these CPU IDs does not establish all-shape numerical identity or task quality.',
   'Finite256MiB limits cover the reported cache resource domain. Cache requested bytes and Graph workspace reports are not measured total physical VRAM peaks.',
   'CPU and CUDA paths have different resource-domain accounting; the cache numbers are not an apples-to-apples hardware-memory comparison.',
   'Only commands replay was used. No capture/performance claim is made.',
   'The archive includes frozen consumer source, commands, first failure, exact fix and all successful reports, but no weights, object files, SDK or executable.']),
 reproduction=dict(build='python .scratch/qwen-multi-draft-20261024/build_geometry_cuda_check2.py',run='python .scratch/qwen35-unsloth-mtp-20261024/run_q4_cuda.py --tag <new-local-result-tag> ordinary k1 k4-random'),
 archive=identity(archive),archived_files=len(files))
path=E/(stem+'.json');path.write_text(json.dumps(proof,indent=2,allow_nan=False)+'\n',encoding='utf8');print(json.dumps(dict(report=identity(path),archive=identity(archive))))
