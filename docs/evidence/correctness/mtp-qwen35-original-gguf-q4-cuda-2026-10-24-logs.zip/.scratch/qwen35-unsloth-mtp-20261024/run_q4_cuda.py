"""Three bounded original Q4 complete-engine functional journeys; no HTTP."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,time
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent;B=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2';I=S/'complete-v2/Q4'
def read(p):return json.loads(p.read_text())
def identity(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while raw:=f.read(1<<20):h.update(raw)
 return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=h.hexdigest())
def run(name,tag):
 cases={'ordinary':['--steps','4','--mtp','off'],'k1':['--steps','4','--mtp','on'],'k4-random':['--steps','6','--mtp','on','--mtp-max-drafts','4','--sampling','random','--top-k','8','--top-p','.9','--seed','123']}
 folder=I/('cuda-'+name+'-'+tag);folder.mkdir(exist_ok=True)
 if (folder/'process.json').exists():raise RuntimeError('Preserve the first result; choose an explicit new case name to retry')
 image=B/'recursive-probe.exe';manifest=identity(I/'weights.tsv');prompt=identity(I/'prompt.ids');original=read(I/'input.json')
 assert original['original_gguf_source']['full_file_sha256_verified']and original['physical_roles']==335
 command=[str(image),'--inputs',str(I),'--capacity','256','--cache-bytes','268435456','--prefix-cache','off','--replay','commands',*cases[name]]
 ready=read(S/'engine-check/ready-cuda.json');env=dict(os.environ,PATH=str(B)+os.pathsep+ready['PATH']);(folder/'tmp').mkdir(exist_ok=True);env.update(TEMP=str(folder/'tmp'),TMP=str(folder/'tmp'))
 metadata=dict(command=command,image=identity(image),source_snapshot=identity(B/'sources.json'),manifest=manifest,prompt=prompt,scope='Bounded complete original335-role Q4 engine functional execution; no performance comparison or task-quality certification.',SDK_builds=0,HTTP=0,started=time.time())
 (folder/'command.json').write_text(json.dumps(metadata,indent=2)+'\n');print('START',name,flush=True);started=time.time()
 with (folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
  process=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 outcome=dict(exit=process.returncode,seconds=time.time()-started);(folder/'process.json').write_text(json.dumps(outcome,indent=2)+'\n');print('END',name,outcome,flush=True)
 if process.returncode:print((folder/'stderr.log').read_text(errors='replace')[-3000:]);raise RuntimeError('Original functional failure retained; do not extend matrix')
 records=[json.loads(line)for line in (folder/'stdout.log').read_text().splitlines()if line.startswith('{')];assert records
 result=records[-1]
 assert result['source_id']==original['source_id']and result['backend']=='cuda'and result['score_policy']=='gguf_encoded_weight_projection_f32_logits'
 assert result['generated_tokens']==(6 if name=='k4-random' else 4)and result['text_tensors']==320
 assert result['cache_requested_byte_limit']==268435456 and result['cache_live_requested_bytes']<=268435456 and result['cache_peak_requested_bytes']<=268435456
 assert result['mtp']==(name!='ordinary')
 if name!='ordinary':assert result['mtp_tensors']==15
 if name=='k4-random':assert result['mtp_max_drafts']==4 and result['prefix_decision_graph_calls']>=1 and result['sampling_draw_cursor']>0
 (folder/'functional-result.json').write_text(json.dumps(dict(status='PASS',command=metadata,process=outcome,report=result),indent=2)+'\n')
 print(json.dumps(dict(case=name,status='PASS',source_id=result['source_id'],score_policy=result['score_policy'],generated_ids=result['generated_ids'],cache_peak_requested_bytes=result['cache_peak_requested_bytes'],actual_target_rows=result.get('actual_target_rows'),actual_draft_rows=result.get('actual_draft_rows'))),flush=True)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--tag',default='checked-embedding');parser.add_argument('cases',nargs='*',choices=['ordinary','k1','k4-random']);args=parser.parse_args()
 if not re.fullmatch('[A-Za-z0-9_-]{1,64}',args.tag):raise ValueError('Use a short local result tag')
 for name in args.cases or ['ordinary','k1','k4-random']:run(name,args.tag)
