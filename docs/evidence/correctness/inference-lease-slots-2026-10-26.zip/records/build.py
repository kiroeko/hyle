"""Explicit plan/build/run of two frozen Compute TUs and one original GTest image."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;R=W.parents[1]
F=R/'.scratch/inference-paged-frame-20261026'
spec=importlib.util.spec_from_file_location('cached_frame',F/'build.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
m,b=f.m,f.b
SPECS=[('core','src/compute/resource_leases.cc',R/'.scratch/inference-storage-freeze-20261026/compile/core/command.json'),
 ('test','tests/compute/resource_leases_test.cc',R/'.scratch/lease-budget-deallocation-order-20261025/implementation/attempt1/lease-tests/command.json')]
OLD=[R/'.scratch/inference-storage-freeze-20261026/compile/core/unit.obj',F/'compile2/test/unit.obj']
def plan():
    assert not (W/'plan.json').exists()
    ready=b.read(F/'ready2.json');inputs=b.read(ready['inputs']['path'])
    assert len(inputs)==137
    for row in inputs:b.exact(row)
    for old in OLD:assert sum(b.key(x['path'])==b.key(old) for x in inputs)==1,str(old)
    units=[dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),command=m.command(recipe,R/source,W/'compile'/name)) for name,source,recipe in SPECS]
    for unit in units:
        assert '/DHYLE_COMPUTE_CPU=1' in unit['command']
        assert '/W4' in unit['command'] and '/WX' in unit['command'] and '/O2' in unit['command']
    freeze=m.c.closure([u['source']['path'] for u in units],[recipe for _,_,recipe in SPECS]);b.save(W/'source-freeze.json',freeze)
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(W/'source-freeze.json'),
      baseline=dict(command=b.pin(F/'link2/command.json'),inputs=ready['inputs'],runtime=ready['runtime'],ready=b.pin(F/'ready2.json')),
      replacements=[dict(unit=name,before=b.pin(old)) for name,old in zip(('core','test'),OLD)],
      compiled_TUs=2,images=1,reused_inputs=135,SDK_native_Model_builds=0,
      scope='Complete resource_leases_test.cc GTest TU, original CPU compilation contract and existing gtest_main/gtest. All unrelated cached Compute/provider dependencies unchanged.'))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['units'][0]['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def plan2():
    p=b.read(W/'plan.json');assert not (W/'plan2.json').exists()
    for row in b.read(p['source_freeze']['path']):b.exact(row)
    unit=p['units'][1];old=unit['command'];args=[]
    for arg in old:
        if arg.startswith('/I') and b.key(R/'.scratch') in b.key(arg):continue
        arg=arg.replace(str(W/'compile/test'),str(W/'compile2/test'))
        args.append(arg)
    assert len(args)==len(old)-1
    unit['command']=args
    p.update(previous_plan=b.pin(W/'plan.json'),status='RECIPE_HEADER_SHADOW_CORRECTED',
      correction='Remove one legacy project /I shadow from test recipe; preserve original failed test and reuse successful current core. No product changes or repeated core compile.')
    b.save(W/'plan2.json',p);print('PLAN2',json.dumps(b.pin(W/'plan2.json')),flush=True)
def plan3():
    p=b.read(W/'plan2.json');assert not (W/'plan3.json').exists()
    b.exact(p['units'][0]['source'])
    u=p['units'][1];u['source']=b.pin(R/'tests/compute/resource_leases_test.cc')
    u['command']=[a.replace(str(W/'compile2/test'),str(W/'compile3/test')) for a in u['command']]
    frozen=m.c.closure([x['source']['path'] for x in p['units']],[Path(x['recipe']['path']) for x in p['units']])
    b.save(W/'source3-freeze.json',frozen)
    p.update(source_freeze=b.pin(W/'source3-freeze.json'),previous_plan=b.pin(W/'plan2.json'),
      status='TEST_DIAGNOSTIC_RETRY_ONLY',correction='Root adds fallible-result diagnostics only to the failing lifetime test. Reuse successful current core; compile only test into compile3, link3/run2 retain first artifacts.')
    b.save(W/'plan3.json',p);print('PLAN3',json.dumps(b.pin(W/'plan3.json')),flush=True)
def plan4():
    p=b.read(W/'plan3.json');assert not (W/'plan4.json').exists()
    b.exact(p['units'][0]['source'])
    u=p['units'][1];u['source']=b.pin(R/'tests/compute/resource_leases_test.cc')
    assert u['source']['sha256']=='da692c8be07fff6e49a2f5cdcb1edd6e1d474e111ea992eeb7486f4d5d11780c'
    u['command']=[a.replace(str(W/'compile3/test'),str(W/'compile4/test')) for a in u['command']]
    frozen=m.c.closure([x['source']['path'] for x in p['units']],[Path(x['recipe']['path']) for x in p['units']])
    b.save(W/'source4-freeze.json',frozen)
    p.update(source_freeze=b.pin(W/'source4-freeze.json'),previous_plan=b.pin(W/'plan3.json'),
      status='TEST_BUDGET_CORRECTION_ONLY',correction='Root corrects test budget from 4096 to 65536 bytes to include original pool metadata, keeping explicit Result assertions. Product/core unchanged; compile only test into compile4, preserve all earlier logs/images.')
    b.save(W/'plan4.json',p);print('PLAN4',json.dumps(b.pin(W/'plan4.json')),flush=True)
def build(second=False,third=False,fourth=False):
    p=b.read(W/('plan4.json' if fourth else 'plan3.json' if third else 'plan2.json' if second else 'plan.json'))
    assert not (W/('ready4.json' if fourth else 'ready3.json' if third else 'ready2.json' if second else 'ready.json')).exists()
    if not second and not third and not fourth:assert not (W/'compile').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for row in frozen:b.exact(row)
    for row in b.read(p['baseline']['inputs']['path']):b.exact(row)
    h,env=environment(p);objects={};results=[]
    for u in p['units']:
        out=W/('compile4' if fourth and u['name']=='test' else 'compile3' if third and u['name']=='test' else 'compile2' if second and u['name']=='test' else 'compile')/u['name']
        reused=(second or third or fourth) and u['name']=='core'
        if reused:
            process=b.read(out/'process.json');assert process['exit']==0
            assert b.read(out/'command.json')['command']==u['command']
            for row in b.read(out/'actual-dependencies.json'):b.exact(row)
        else:process=h.execute(u['command'],env,out,timeout=180)
        deps=b.read(out/'dependencies.json')['Data'];actual=[b.pin(q) for q in dict.fromkeys([deps['Source'],*deps['Includes']])]
        for row in actual:
            q=Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert own[b.key(q)]['sha256']==row['sha256'],str(q)
        if not reused:b.save(out/'actual-dependencies.json',actual)
        objects[u['name']]=b.pin(out/'unit.obj')
        results.append(dict(name=u['name'],source=u['source'],object=objects[u['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json'),reused_compile=reused))
        for row in frozen:b.exact(row)
    replace={b.key(x['before']['path']):objects[x['unit']]['path'] for x in p['replacements']}
    link_folder=W/('link4' if fourth else 'link3' if third else 'link');image=link_folder/'lease-slots-test.exe';args=[];changed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in replace:arg=replace[b.key(arg)];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert changed==2
    process=h.execute(args,env,link_folder,timeout=90)
    inputs=[b.pin(replace.get(b.key(x['path']),x['path'])) for x in b.read(p['baseline']['inputs']['path'])]
    input_path=W/('link4-inputs.json' if fourth else 'link3-inputs.json' if third else 'link-inputs.json');runtime_path=W/('runtime4.json' if fourth else 'runtime3.json' if third else 'runtime.json')
    b.save(input_path,inputs);runtime=b.read(p['baseline']['runtime']['path']);b.save(runtime_path,runtime)
    output=W/('ready4.json' if fourth else 'ready3.json' if third else 'ready2.json' if second else 'ready.json')
    b.save(output,dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=process,inputs=b.pin(input_path),runtime=b.pin(runtime_path),plan=b.pin(W/('plan4.json' if fourth else 'plan3.json' if third else 'plan2.json' if second else 'plan.json')),SDK_native_Model_builds=0))
    print('READY',json.dumps(b.pin(output)),flush=True)
def run(third=False,fourth=False):
    p=b.read(W/'plan.json');ready_path=W/('ready4.json' if fourth else 'ready3.json' if third else 'ready2.json' if (W/'ready2.json').exists() else 'ready.json');ready=b.read(ready_path);b.exact(ready['image']);h,env=environment(p)
    env['PATH']=b.read(ready['runtime']['path'])['PATH'];out=W/('run3' if fourth else 'run2' if third else 'run1');xml=W/('results3.xml' if fourth else 'results2.xml' if third else 'results.xml')
    result=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_output=xml:'+str(xml)],env,out,timeout=90)
    summary=W/('summary3.json' if fourth else 'summary2.json' if third else 'summary.json')
    b.save(summary,dict(status='COMPLETE_RESOURCE_LEASES_TU_PASS',process=result,ready=b.pin(ready_path),results=b.pin(xml),compiled_TUs=2,model_runs=0,SDK_builds=0,HTTP=0,scope=p['scope']))
    print('SUMMARY',json.dumps(b.pin(summary)),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['plan2']:plan2()
    elif sys.argv[1:]==['build2']:build(True)
    elif sys.argv[1:]==['plan3']:plan3()
    elif sys.argv[1:]==['build3']:build(third=True)
    elif sys.argv[1:]==['run2']:run(third=True)
    elif sys.argv[1:]==['plan4']:plan4()
    elif sys.argv[1:]==['build4']:build(fourth=True)
    elif sys.argv[1:]==['run3']:run(fourth=True)
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
