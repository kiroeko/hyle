"""Publish only this completed finite Compute run; no build or execution."""
from pathlib import Path
import hashlib,json,sys,xml.etree.ElementTree as ET,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def publish():
    dest=R/'docs/evidence/correctness/inference-lease-slots-2026-10-26.json';archive=dest.with_suffix('.zip')
    assert not dest.exists() and not archive.exists()
    sources=['include/hyle/compute/lease_slots.h','include/hyle/compute/resource_leases.h',
      'include/hyle/compute/detail/lease_access.h','src/compute/resource_leases.cc','tests/compute/resource_leases_test.cc']
    ready=read(W/'ready4.json');assert sha((R/sources[-1]).read_bytes())=='da692c8be07fff6e49a2f5cdcb1edd6e1d474e111ea992eeb7486f4d5d11780c'
    payload={'source/'+n:(R/n).read_bytes() for n in sources}
    records=['build.py','publish.py','plan.json','plan2.json','plan3.json','plan4.json',
      'source-freeze.json','source3-freeze.json','source4-freeze.json','ready2.json','ready3.json','ready4.json',
      'link-inputs.json','link3-inputs.json','link4-inputs.json','runtime.json','runtime3.json','runtime4.json',
      'results.xml','results2.xml','results3.xml','summary.json','summary2.json','summary3.json']
    for folder in ['compile/core','compile/test','compile2/test','compile3/test','compile4/test','link','link3','link4','run1','run2','run3']:
        records += [folder+'/'+n for n in ('command.json','process.json','running.json','stdout.log','stderr.log')]
        if folder.startswith('compile'):
            records += [folder+'/dependencies.json']
            if folder!='compile/test':records += [folder+'/actual-dependencies.json']
    for n in records:payload['records/'+n]=(W/n).read_bytes()
    # The retained stale header documents the first recipe-only compile error.
    stale=R/'.scratch/lease-budget-deallocation-order-20261025/implementation/source/include/hyle/compute/detail/lease_access.h'
    payload['historical-shadow/lease_access.h']=stale.read_bytes()
    for row in read(W/'source4-freeze.json'):
        path=Path(row['path']);assert path.stat().st_size==row['bytes'] and sha(path.read_bytes())==row['sha256'],str(path)
    process_stages=[]
    for folder in ['compile/core','compile/test','compile2/test','compile3/test','compile4/test','link','link3','link4','run1','run2','run3']:
        process_stages.append(dict(stage=folder,**read(W/folder/'process.json')))
    runs=[]
    for name,xml in [('run1','results.xml'),('run2','results2.xml'),('run3','results3.xml')]:
        tree=ET.parse(W/xml).getroot();tests=int(tree.attrib['tests']);failures=int(tree.attrib['failures'])
        runs.append(dict(stage=name,process=read(W/name/'process.json'),tests=tests,passed=tests-failures,failures=failures,
          failed=[dict(name=x.attrib['classname']+'.'+x.attrib['name'],messages=[f.text for f in x.findall('failure')]) for x in tree.iter('testcase') if x.find('failure') is not None]))
    assert [(x['tests'],x['failures'],x['process']['exit']) for x in runs]==[(25,1,1),(25,1,1),(25,0,0)]
    files=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(payload.items())]
    assert not any(Path(n).suffix.lower() in ('.obj','.exe','.pdb','.lib','.dll','.bin') for n in payload)
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for n,raw in sorted(payload.items()):z.writestr(n,raw)
    with zipfile.ZipFile(archive) as z:
        assert z.namelist()==[x['path'] for x in files]
        for row in files:
            raw=z.read(row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
    assert archive.stat().st_size<2_000_000
    data=dict(schema=1,date='2026-10-26',status='COMPLETE_RESOURCE_LEASES_TU_PASS',
      scope='Finite Windows CPU Compute validation of LeaseSlotLayout and all existing tests in resource_leases_test.cc. No engine/backend/platform/performance matrix.',
      current_sources=[dict(path=n,bytes=(R/n).stat().st_size,sha256=sha((R/n).read_bytes())) for n in sources],
      canonical_target='hyle_compute_test: resource_leases_test.cc only, using original GoogleTest main',
      compile_contract='Original pure CPU /O2 /Ob2 /MD /W4 /WX /DHYLE_STATIC recipe; canonical project headers precede cached dependencies after correction.',
      current_image=ready['image'],successful_distinct_TUs=2,compile_processes=5,successful_compile_processes=4,link_processes=3,test_processes=3,
      process_stages=process_stages,runs=runs,
      corrections=[dict(kind='Recipe only',failure='First test compile used historical project /I shadow and could not find LeaseAccess::slot_capacity.',change='Remove that one /I; keep original failure and use canonical header. Core compiled once and reused in all subsequent attempts.'),
        dict(kind='Test diagnostics only',failure='First test run had one Bad expected access exception.',change='Root replaces unchecked fallible accesses in the one failing test with explicit Result assertions, without changing budget or product.'),
        dict(kind='Test budget only',failure='Second test run identifies LeasePool::create rejection: shared resource budget is exhausted.',change='Root changes that test budget from 4096 to 65536 bytes to include backing plus original pool metadata, retaining diagnostics. Final 25/25 pass.')],
      reuse=dict(baseline='inference-paged-frame-20261026/link2: prior 41-test PASS closure',retained_input_count=135,total_input_count=137,
        replacements=['Direct resource_leases.cc object','Direct prior GTest test-TU object'],archive_rewrites=0,ignored_duplicate_symbols=0,
        boundary='All other Compute/provider/GoogleTest/vendor dependencies reused without recompilation. This run exercises only the selected CPU test TU, not those backend paths.'),
      SDK_builds=0,Model_builds=0,model_runs=0,HTTP=0,performance_claim=False,
      source_history='Original and diagnostic test versions are identified by plan/source-freeze pins and raw outputs; final five canonical sources are snapshotted. Historical shadow header is included solely to document the recipe failure.',
      archive=dict(path=archive.relative_to(R).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),file_count=len(files),files=files))
    dest.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(summary=dict(path=str(dest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes())),archive=data['archive']|{'files':'manifest verified'},final_tests=25,final_failures=0),ensure_ascii=False,indent=2))
if __name__=='__main__':
    if sys.argv[1:]==['publish']:publish()
    else:print(__doc__)
