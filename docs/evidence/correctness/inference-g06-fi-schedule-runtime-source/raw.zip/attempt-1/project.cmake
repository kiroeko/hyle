include(/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce19_cuda_compile.cmake)
if(PROJECT_NAME STREQUAL "hyle")
  function(g06_fi_source_consumers)
    foreach(pair IN ITEMS
        "public|public_batch_cuda_consumer.cc"
        "hybrid|public_hybrid_batch_consumer.cc"
        "pending|pending_paged_receiver_cuda_consumer.cc"
        "plain_risks|pending_paged_receiver_cuda_risks.cc"
        "encoded_risks|pending_paged_receiver_cuda_risks.cc")
      string(REPLACE "|" ";" parts "${pair}")
      list(GET parts 0 name)
      list(GET parts 1 source)
      set(target hyle_g06_fi_${name})
      add_executable(${target} "${PROJECT_SOURCE_DIR}/tests/compute_batch/${source}")
      target_compile_features(${target} PRIVATE cxx_std_23)
      target_compile_options(${target} PRIVATE -Wall -Wextra -Werror)
      target_link_libraries(${target} PRIVATE hyle_graph_route_cpu_cuda hyle::graph hyle::compute CUDA::cudart)
      if(name STREQUAL "encoded_risks")
        target_compile_definitions(${target} PRIVATE HYLE_ENCODED_PAGE_RISK=1)
      endif()
    endforeach()
  endfunction()
  cmake_language(DEFER CALL g06_fi_source_consumers)
endif()
