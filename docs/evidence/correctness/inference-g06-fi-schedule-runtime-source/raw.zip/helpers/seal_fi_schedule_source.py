from pathlib import Path
import datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g06'
candidate='4fb74d07c220156bff8aa830a20c4eda08d0b266'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
attempts=[]
for n in range(1,6):
    folder=base/('fi-schedule-source-'+str(n))
    row=json.loads((folder/'result.json').read_text())
    assert row['state'].startswith('TERMINAL_'),row['state']
    attempts.append(row)
final=attempts[-1]
assert final['candidate']==candidate and final['state']=='TERMINAL_ORDINARY_PASS_RISKS_PENDING'
assert all(s['exit_code']==0 for s in final['stages'])
assert final['native_cuda_edges']==[] and final['deferred_risks']['targets']==['hyle_g06_fi_plain_risks','hyle_g06_fi_encoded_risks']
manifest=json.loads((base/'fi-schedule-source-5/input-manifest.json').read_text())
for row in manifest:
    assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
before={i['path']:i['sha256'] for i in json.loads((base/'fi-schedule-source-2/input-manifest.json').read_text())}
after={i['path']:i['sha256'] for i in manifest}
native_paths=['src/compute_provider_flashinfer/native_batch.h','src/compute_provider_flashinfer/native_batch.cu',
              'src/compute_provider_flashinfer/flashinfer_provider.cc','src/compute_provider_flashinfer/native_cache.cu',
              'third_party/flashinfer_cache/patches.json']
assert all(before[p]==after[p] for p in native_paths)
assert len(attempts[1]['native_cuda_edges'])==2
xml=ET.parse(base/'fi-schedule-source-5/provider.xml').getroot()
cases=list(xml.iter('testcase'))
assert len(cases)==19 and not list(xml.iter('failure')) and not list(xml.iter('skipped'))
recheck=json.loads((base/'fi-schedule-source-5/artifact-recheck.json').read_text())
assert recheck['state']=='PASS_CURRENT_ARTIFACT_IDENTITY'
common='src/compute_batch/batch_execution.cc'
original=subprocess.check_output(['git','show','81aed8f30c71f382811dc690a992c51efccc3cfc:'+common])
assert original.replace(b'\r\n',b'\n')==(root/common).read_bytes().replace(b'\r\n',b'\n')
destination=root/'evidence/correctness/inference-g06-fi-schedule-runtime-source'
assert not destination.exists()
destination.mkdir()
bundle=destination/'raw.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as archive:
    for n in range(1,6):
        folder=base/('fi-schedule-source-'+str(n))
        for p in sorted(folder.iterdir()):
            if p.is_file():archive.write(p,'attempt-'+str(n)+'/'+p.name)
    for name in ['fi-active-intake.json','fi_schedule_project.cmake','fi_schedule_wsl.py','launch_fi_schedule.py','seal_fi_schedule_source.py']:
        archive.write(base/name,'helpers/'+name)
    archive.write(root/'.scratch/inference-gaps/g04-g05/ce28_shipping_native_reuse_wsl.py','helpers/original_shipping_native_reuse.py')
    archive.write(base/'fi-schedule-final-product-plan.json','selector/pre-increment-plan.json')
receipt=dict(kind='G06_D6_FLASHINFER_SCHEDULE_ORDINARY_SOURCE',product_candidate=candidate,
    verdict='PASS_ORDINARY_SOURCE_ONLY_INSTRUMENTED_RISKS_PENDING',owners=['compute_provider_flashinfer'],owner_state='AUDITED',
    card='docs/implementation/tasks/compute/inference-g06-metadata-decode.md',
    scope='Original native schedule equivalence and checked empty owning-input execution; original mathematical domain. No capture/P1/sanitizer/header/relocated-SDK or complete G06 verdict.',
    identity=final['identity'],source_manifest='raw.zip:attempt-5/input-manifest.json',
    native_source_reuse=dict(from_attempt=2,explanation='Attempt2 overall FAIL retained; its two required FI native CUDA objects completed and linked. All five listed native/product inputs match final candidate exactly; final attempts compile zero native CUDA translation units.',
        inputs=[dict(path=p,sha256=after[p]) for p in native_paths]),
    unchanged_common=dict(path=common,baseline='81aed8f30c71f382811dc690a992c51efccc3cfc',
        decision='Redundant cold-mirror fallback removed after complete MetadataHeader segment check; common source restored to original product bytes modulo Git line endings.'),
    tests=dict(provider=dict(count=19,failures=0,skipped=0,cases=[t.attrib for t in cases]),
        runtime=dict(configurations=32,episodes_each=64,storage=['ragged','paged'],kv=['plain','FP8 with independent K/V scales'],
            types=['F16','BF16'],geometry=['single/multi Q1','mixed17+1','D64/128/256','D64/Dv128','causal/window/noncausal'],
            proof=['Independent uniform attention oracle from nonconstant physical V, actual FP8-byte decode and three sampled value coordinates; inactive last-row poison.',
                'Original128-row scheduling boundary, growth/shrink, packed offsets/page ID reorder/shared pages, Q0 requests and Q topology changes.',
                'No next injected control allocation on reuse, stable float/int workspace/grid, actual metadata bytes/waits, independent other-slot old result and original old-output rejection.']),
        empty='Zero requests and all-Q0 through original complete owning Q/K/V API, paged/ragged, original checked Completion; original nonempty PagedArena projection contract explicitly rejects empty guards.',
        consumers=[s for s in final['stages'] if s['stage'].startswith('hyle_g06_')]),
    cost=dict(private_facts='One u32 cached original chunk fact; native metadata allocation follows original sizeof/allocator accounting, with padding not assumed zero.',
        cold='Read four bytes from original planner host shadow, no D2H. Original nonempty native planning and accepted H2D prefix unchanged.',
        warm='O(requests) equivalence at actual original chunk/CTA/window, then original F2 active metadata delta; skip query/plan/integer H2D iff schedule equivalent. No retile/tuning or claim of optimal native schedule.',
        empty='Native query/plan/run bypassed or no_op at zero Q; common explicit immediate-completion wait may still be charged.',
        native_private_driver='UNKNOWN; no opaque zero-allocation/hard-budget claim.'),
    artifacts=recheck,artifact_manifest='raw.zip:attempt-5/artifacts.json',
    build_limits=dict(ninja=2,nvcc_pool=1,nvcc_split_compile=3,unrelated_cuda_objects_reused=146,proof=final['native_reuse']),
    attempts=[dict(attempt=i+1,candidate=r['candidate'],state=r['state'],outer_elapsed_seconds=r['outer_elapsed_seconds'],stages=r['stages']) for i,r in enumerate(attempts)],
    failures_retained=['Attempt1 setup guard caught146 unrelated native CUDA rebuilds before compilation.',
        'Attempt2 existing public consumer missing-initializer/unused-variable warnings fixed1049fbe6f; original instrumented risk hooks absent from shipping backend produced link failures, retained.',
        'Attempt3 empty fixture unchecked expected threw; attempt4 diagnosed original PagedArena nonempty contract. Fixture corrected to original owning-input API; original failures remain FAIL.'],
    remaining=['Actual capture/replay and Direct/Graph/hybrid lifecycle qualification remain mandatory full G06 work.',
        'Original plain/FP8 CUDA backend observation risks and applicable static provider fault injection remain mandatory in final instrumented risk batch.',
        'Final G06 ASan/UBSan/TSan, independent public headers, relocated static/shared SDK and applicable fixed-candidate performance remain unrun.',
        'G04/G05 original CUDA prefill noninferiority UNRESOLVED and exact cost attribution UNKNOWN retained; no unchanged P1 rerun or new speed claim. Full goal accepted count remains3/10.'],
    elapsed='Stage/outer timings overlap; all five attempts retained. Complete investigation/editorial/sealing elapsed UNKNOWN, not zero.',
    bundle=dict(path='raw.zip',sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),bytes=bundle.stat().st_size),
    timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(destination/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(verdict=receipt['verdict'],candidate=candidate,provider_tests=19,runtime_configurations=32,episodes=2048,consumer_binaries=3,raw_bytes=bundle.stat().st_size)))
