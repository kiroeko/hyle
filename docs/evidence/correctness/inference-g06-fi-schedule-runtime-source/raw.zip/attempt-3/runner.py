from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile

root=Path('/mnt/c/public/project-hyle/hyle')
base=root/'.scratch/inference-gaps/g06'
source=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
archive,candidate,attempt=sys.argv[1:4]
out=base/('fi-schedule-source-'+attempt);out.mkdir(exist_ok=False)
started=time.monotonic()
r=dict(state='SETUP',candidate=candidate,attempt=attempt,source=str(source),build=str(build),pid=os.getpid(),
       max_jobs=2,nvcc_pool=1,nvcc_split_compile=3,stages=[],
       scope='G06 D6 source correctness/P0 schedule reuse and checked empty batch; no capture, sanitizer, SDK or P1 verdict')
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
def save():
    r['outer_elapsed_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,command):
    stamp=time.monotonic();log=out/(stage+'.log')
    with log.open('w') as f:
        p=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT)
        r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True)
        code=p.wait()
    r['stages'].append(dict(stage=stage,command=command,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)))
    r.pop('child_pid',None);save()
    if code:
        r['state']='TERMINAL_FAIL';save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
try:
    assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==candidate
    # Parent launch sealed the clean immutable candidate; avoid a second NTFS Git scan.
    r['canonical_clean_guard']='Windows launch sealed exact HEAD/clean tree and original source archive; current HEAD checked again'
    registry=json.loads((root/'docs/implementation/module-status.json').read_text())
    assert all(next(m for m in registry['modules'] if m['module']==name)['state']=='AUDITED' for name in ['compute_provider_flashinfer','compute_batch'])
    assert source.is_dir() and not (source/'.git').exists() and build.is_dir()
    r['identity']={k:subprocess.check_output(cmd,env=env,text=True).strip() for k,cmd in [
        ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
        ('gpu',['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader'])]}
    with zipfile.ZipFile(archive) as z:
        inputs=json.loads(z.read('source-manifest.json'));(out/'input-manifest.json').write_text(json.dumps(inputs,indent=2)+'\n')
        changed=[]
        for item in inputs:
            rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
            data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
            p=source/rel
            if not p.exists() or p.read_bytes()!=data:
                p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
    r['changed_source_paths']=changed
    (out/'runner.py').write_bytes(Path(__file__).read_bytes())
    (out/'project.cmake').write_bytes((base/'fi_schedule_project.cmake').read_bytes())
    if '--reuse-configure' in sys.argv[4:]:
        prior=json.loads((base/'fi-schedule-source-1/result.json').read_text())
        assert prior['state']=='TERMINAL_SETUP_FAIL'
        assert any(s['stage']=='configure' and s['exit_code']==0 for s in prior['stages'])
        original_inputs=json.loads((base/'fi-schedule-source-1/input-manifest.json').read_text())
        before={i['path']:i['sha256'] for i in original_inputs};after={i['path']:i['sha256'] for i in inputs}
        delta=sorted(p for p in before.keys()|after.keys() if before.get(p)!=after.get(p))
        assert set(delta)<=set(['tests/compute_batch/public_batch_cuda_consumer.cc','tests/compute_batch/public_hybrid_batch_consumer.cc']),delta
        r['reused_configuration_source_delta']=[dict(path=p,before=before.get(p),after=after.get(p)) for p in delta]
        cache=(build/'CMakeCache.txt').read_text()
        assert 'HYLE_BUILD_TESTS:BOOL=ON' in cache and str(base/'fi_schedule_project.cmake') in cache
        r['configuration_reused_from']='fi-schedule-source-1; original failure/cost retained'
    else:
        run('configure',['cmake','-S',str(source),'-B',str(build),'-DHYLE_INSTALL=OFF','-DHYLE_BUILD_TESTS=ON',
            '-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF',
            '-DCMAKE_PROJECT_INCLUDE='+str(base/'fi_schedule_project.cmake')])
    run('prepare-manifest',['ninja','-C',str(build),'build.ninja'])
    consumers=['public','hybrid','pending','plain_risks','encoded_risks']
    if '--ordinary-only' in sys.argv[4:]:
        consumers=['public','hybrid','pending']
        r['deferred_risks']={'targets':['hyle_g06_fi_plain_risks','hyle_g06_fi_encoded_risks'],
            'reason':'Original test hooks are stripped from shipping backend; attempt2 link failure retained. Must run original instrumented risk gate at full G06 final API/algorithm freeze; ordinary subset cannot sign these risks PASS.'}
    targets=['hyle_compute_provider_flashinfer_test']+['hyle_g06_fi_'+s for s in consumers]
    r['targets']=targets
    preview=out/'preview.ninja'
    reuse=next((a.split('=',1)[1] for a in sys.argv[4:] if a.startswith('--reuse-native=')),None)
    if reuse:
        folder=root/'.scratch/inference-gaps/g04-g05'/('ce28-shared-native-reuse-'+reuse)
        proof=json.loads((folder/'result.json').read_text());assert proof['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
        assert hashlib.sha256((build/'build.ninja').read_bytes()).hexdigest()==proof['original_manifest_sha256']
        manifest=folder/'reuse.ninja';assert hashlib.sha256(manifest.read_bytes()).hexdigest()==proof['reuse_manifest_sha256']
        preview.write_bytes(manifest.read_bytes());r['native_reuse']=proof
        (out/'native-reuse-proof.json').write_bytes((folder/'result.json').read_bytes())
        (out/'native-mapped-edges.json').write_bytes((folder/'mapped-edges.json').read_bytes())
        (out/'native-object-check.log').write_bytes((folder/'object-check.log').read_bytes())
    else:preview.write_bytes((build/'build.ninja').read_bytes())
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
    (out/'dry-run.log').write_text(dry)
    assert 'Re-running CMake' not in dry
    cuda=[line for line in dry.splitlines() if 'Building CUDA object' in line]
    r['native_cuda_edges']=cuda;save()
    assert len(cuda)<=2 and all('compute_provider_flashinfer' in line for line in cuda),cuda
    assert not any('ggml-cuda' in line for line in cuda)
    rules=(build/'build.ninja').read_text()
    assert '--split-compile=3' in rules and 'pool = ce19_cuda_compile' in rules
    run('build',['ninja','-C',str(build),'-f',str(preview),'-j','2','-k','0',*targets])
    for target in targets:
        path=build/'bin'/target
        command=[str(path)]
        if target=='hyle_compute_provider_flashinfer_test':command+=['--gtest_output=xml:'+str(out/'provider.xml')]
        run(target,command)
    artifacts=[]
    for p in sorted(build.rglob('*')):
        if p.is_file() and ((p.suffix in ('.so','.a') and p.name.startswith('libhyle')) or p.name in targets):
            artifacts.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
    (out/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    assert all(hashlib.sha256((source/i['path']).read_bytes()).hexdigest()==i['sha256'] for i in inputs)
    r['state']='TERMINAL_ORDINARY_PASS_RISKS_PENDING' if r.get('deferred_risks') else 'TERMINAL_PASS';save();print(r['state'],flush=True)
except BaseException as e:
    if r['state']!='TERMINAL_FAIL':r.update(state='TERMINAL_SETUP_FAIL',error=repr(e));save()
    raise
