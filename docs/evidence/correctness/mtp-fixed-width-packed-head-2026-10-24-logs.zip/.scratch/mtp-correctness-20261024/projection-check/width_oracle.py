"""Fixed original A T1/T3/T5: inherit exact old proof only for identical values."""
from pathlib import Path
import hashlib,importlib.util,json,math,struct
O=Path(__file__).resolve().parent;R=O.parents[2]
OLD=R/'.scratch/qwen-mtp-quality-20261022'
def identity(p):
 raw=p.read_bytes();return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def main():
 proof_path=OLD/'review/prefix-existing-numeric-contract.verified.json';proof=json.loads(proof_path.read_text())
 spec=importlib.util.spec_from_file_location('retained_exact_contract',OLD/'review/prefix_existing_numeric_contract.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 folder=O/'cuda/width-vectors';observation=json.loads((folder/'observation.json').read_text());a=(folder/'fixed-A.bf16').read_bytes()
 assert a==(OLD/'prefix1/vectors/T1/normalized.bf16').read_bytes() and hashlib.sha256(a).hexdigest()==proof['normalized_row0_sha256']
 with Path(observation['source_file']).open('rb')as file:file.seek(observation['source_offset']);weights=file.read(observation['source_bytes'])
 assert len(weights)==25165824 and hashlib.sha256(weights).hexdigest()==proof['source_weight_ranges']['qkv_range_sha256']
 assert proof['shapes']['T1']['existing_regression_failure_count']==0 and proof['shapes']['T1']['f32_bound_cell_incompatibility_count']==0
 original=[x[0]for x in struct.iter_unpack('<H',(OLD/'prefix1/vectors/T1/qkv.bf16').read_bytes()[:12288])]
 values={t:[x[0]for x in struct.iter_unpack('<H',(folder/f'T{t}-row0.bf16').read_bytes())]for t in(1,3,5)}
 assert all(len(v)==6144 and all(math.isfinite(m.value(x))for x in v)for v in values.values())
 a_bits=[x[0]for x in struct.iter_unpack('<H',a)];a_dyadic=list(map(m.dyadic,a_bits));av=list(map(m.value,a_bits))
 changed=sorted({c for vs in values.values()for c,v in enumerate(vs)if v!=original[c]});checks=[];failed=[]
 for channel in changed:
  wb=[x[0]for x in struct.iter_unpack('<H',weights[channel*4096:(channel+1)*4096])]
  exact,sumabs,_=m.exact_sums(a_dyadic,list(map(m.dyadic,wb)));dot=math.fsum(x*m.value(y)for x,y in zip(av,wb));bound=m.GAMMA*sumabs
  for width in(1,3,5):
   actual=values[width][channel];low,high,closed=m.rounding_cell(actual)
   compatible=not(exact+bound<low or exact-bound>high)and(closed or not(exact+bound==low or exact-bound==high))
   error=abs(m.value(actual)-dot);tolerance=.008*abs(dot)+.0001
   row=dict(width=width,channel=channel,actual_bits=f'0x{actual:04x}',actual=m.value(actual),FP64_dot=dot,absolute_error=error,unchanged_existing_tolerance=tolerance,ratio=error/tolerance,f32_necessary_cell_compatible=compatible)
   checks.append(row)
   if error>tolerance or not compatible:failed.append(row)
 result=dict(status='PASS'if not failed else'FAIL',scope='Current ordinary BF16 QKV projection only, one identical original A row at T1/T3/T5; no MTP graph, recurrence, task or performance claim.',
  observation=observation,reused_all6144_proof=identity(proof_path),unchanged_existing_contract=proof['existing_regression_contract']['formula'],
  necessary_F32_bound_note='Conditional ideal F32 summation plus final BF16 rounding compatibility, not a vendor reduction-algorithm proof.',
  same_original_input=True,same_original_weight=True,old_T1_equal_channels={f'T{w}':sum(x==y for x,y in zip(v,original))for w,v in values.items()},
  cross_width_different_channels={f'T1_T{w}':sum(x!=y for x,y in zip(values[1],values[w]))for w in(3,5)},
  independently_recomputed_channels=changed,checks=checks,failures=failed,outputs=[identity(folder/f'T{w}-row0.bf16')for w in(1,3,5)],
  routes={f'T{w}':(folder/f'T{w}-route.tsv').read_text()for w in(1,3,5)},script=identity(Path(__file__)),HTTP=0,full_model_runs=0)
 out=O/'width-numeric-result.json';out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({k:result[k]for k in('status','old_T1_equal_channels','cross_width_different_channels','independently_recomputed_channels','failures')}));assert not failed
if __name__=='__main__':main()
