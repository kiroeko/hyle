from pathlib import Path
import importlib.util,json,os,sys
O=Path(__file__).resolve().parent;R=O.parents[2]
spec=importlib.util.spec_from_file_location('finite_prefix_build',O.parent/'state-check/check.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);b=a.b
def build(backend):
 W=R/('.scratch/qwen-multi-draft-20261024/geometry-'+backend+'-check'+('2'if backend=='cpu'else'1'));folder=O/backend
 old=b.read(W/'compile-command.json');native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':old[0],'CMAKE_CXX_COMPILER':old[0],'CMAKE_GENERATOR':'Ninja'},backends=());flags=[];skip=False
 for x in old:
  if skip:skip=False;continue
  if x=='/sourceDependencies':skip=True;continue
  if x.startswith(('/Fo','/Fd'))or x.lower().endswith('.cc'):continue
  flags.append(x)
 source=R/'tests/tools/qwen_mtp_projection_width_probe.cc';obj=folder/'test.obj';snapshot=[b.identity(x)for x in [source,R/'engine/models/qwen35/main.cc',*sorted((R/'engine/models/qwen35').glob('*.h'))]]
 a.execute([*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(folder/'test.pdb')],native.env,folder/'compile',180)
 for x in snapshot:
  b.require(x);original=Path(x['path']);saved=folder/'sources'/original.relative_to(R);saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(original.read_bytes())
 command=[]
 for x in b.read(W/'link-command.json'):
  if x.startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))or Path(x).resolve()==(W/'test.obj').resolve():continue
  if Path(x).name=='graph--executable.obj':x=str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj')
  command.append(x)
 image=folder/'projection.exe';command +=[str(obj),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 a.execute(command,native.env,folder/'link',120);ready=b.read(R/('.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-'+backend+'.json'))
 runtime=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll';staged=folder/runtime.name
 if not staged.exists():os.link(runtime,staged)
 if b.identity(staged)['sha256']!='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f':raise ValueError('Wrong CPU runtime')
 b.save(folder/'ready.json',dict(image=b.identity(image),PATH=str(folder)+os.pathsep+ready['PATH'],sources=snapshot,SDK_builds=0,HTTP=0))
def run(backend,head=False):
 folder=O/backend;ready=b.read(folder/'ready.json');b.require(ready['image']);inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original';fixed=R/'.scratch/qwen-mtp-quality-20261022/prefix1/vectors/T1/normalized.bf16'
 name='head-run'if head else'width-run'
 if head:
  stage=R/'.scratch/mtp-metadata-offline-20261024';plan=b.read(stage/'cat7-head-plan.json');acq=b.read(stage/'cat7-head-results.json');assert acq['complete']and len(acq['results'])==1
  for r in plan['components'][0]['ranges']:
   original=next(x['file']for x in acq['results'][0]['ranges']if x['kind']==r['kind']);actual=b.identity(R/r['output']);assert all(original[k]==actual[k]for k in ['bytes','sha256'])
  b.save(folder/'head-preflight.json',dict(plan=b.identity(stage/'cat7-head-plan.json'),acquisition=b.identity(stage/'cat7-head-results.json'),HTTP=0))
  command=[ready['image']['path'],'--packed-head',str(stage/'components/q27-nvfp4-original-head'),str(folder/'head-vectors')]
 else:command=[ready['image']['path'],str(inputs),str(fixed),str(folder/'width-vectors')]
 a.execute(command,dict(os.environ,PATH=ready['PATH']),folder/name,60);print((folder/name/'stdout.log').read_text())
if __name__=='__main__':
 action,backend=sys.argv[1:3]
 if action=='build':build(backend)
 if action=='run-width':run(backend)
 if action=='run-head':run(backend,True)
