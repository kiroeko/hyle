"""Independent original ModelOpt sparse-input NVFP4 head oracle; no product codec."""
from pathlib import Path
import hashlib,json,math,struct,sys

O=Path(__file__).resolve().parent;R=O.parents[2]
C=R/'.scratch/mtp-metadata-offline-20261024/components/q27-nvfp4-original-head'
def identity(p):
 raw=p.read_bytes();return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def bf16(x):
 b=bits(x);return struct.unpack('<f',struct.pack('<I',((b+0x7fff+((b>>16)&1))>>16)<<16))[0]
def e4(c):
 m=c&127
 if m==127:raise ValueError('Original scale is NaN')
 v=math.ldexp(float(m&7),-9)if m<8 else math.ldexp(1.+float(m&7)/8,(m>>3)-7)
 return -v if c&128 else v
E2=(0.,.5,1.,1.5,2.,3.,4.,6.,0.,-.5,-1.,-1.5,-2.,-3.,-4.,-6.)
def nearest(value,table):return min(range(len(table)),key=lambda i:(abs(value-table[i]),i&1,i))
def activation(a,maximum,global_scale):
 normalized=min(f32(maximum/f32(6.*global_scale)),448.)
 scale=f32(e4(nearest(normalized,[e4(i)for i in range(127)]))*global_scale)
 if not scale>=1.e-5:scale=1.
 magnitude=f32(abs(a)/scale)
 restored=f32(E2[nearest(min(magnitude,6.),E2[:8])]*scale)
 return bf16(restored if a>=0 else-restored)
def calculate():
 w=(C/'codes.bin').read_bytes();sf=(C/'scales.bin').read_bytes();ig,wg=struct.unpack('<ff',(C/'globals.bin').read_bytes())
 assert len(w)==7680 and len(sf)==960 and ig>0 and wg>0
 out=[];no_final=[];no_activation=[];witness=[]
 for row,(lane,a)in enumerate(((0,1.25),(33,6.5))):
  quant_a=activation(a,abs(a),ig)
  for n in range(3):
   code=(w[n*2560+lane//2]>>(4*(lane%2)))&15
   weight=bf16(f32(E2[code]*f32(e4(sf[n*320+lane//16])*wg)))
   dot=f32(quant_a*weight);expected=bf16(dot);out.append(expected)
   no_final.append(dot);no_activation.append(bf16(f32(a*weight)))
   witness.append(dict(row=row,column=n,lane=lane,original_A=a,QDQ_A=quant_a,code=code,original_scale=sf[n*320+lane//16],BF16_weight=weight,F32_dot=dot,logit=expected))
 return out,dict(input_global=ig,weight_global=wg,witnesses=witness,
  no_final_BF16_round_changed=sum(bits(a)!=bits(b)for a,b in zip(out,no_final)),
  no_activation_QDQ_changed=sum(bits(a)!=bits(b)for a,b in zip(out,no_activation)))
def main():
 expected,facts=calculate();backends={}
 for backend in sys.argv[1:]or['cpu','cuda']:
  path=O/backend/'head-vectors/logits.f32';actual=list(struct.unpack('<6f',path.read_bytes()));assert list(map(bits,actual))==list(map(bits,expected)),(backend,actual,expected)
  obs=json.loads((path.parent/'observation.json').read_text());assert obs['score_policy']=='nvfp4_qdq_bf16_projection_f32_logits'
  assert obs['packed_projection_nodes']==1 and obs['dense_f32_projection_nodes']==0 and not obs['whole_floating_head_bank'] and obs['missing_input_scale_rejected']
  backends[backend]=dict(status='PASS',output=identity(path),actual=actual,checked_exact_values=6,observation=obs)
 result=dict(status='PASS',original_inputs=[identity(C/f)for f in ['codes.bin','scales.bin','globals.bin']],
  scope='Actual first three physical head rows/full K5120, two sparse BF16 input rows; no full vocabulary, full target or performance claim.',
  arithmetic='Original group16 A QDQ to BF16, scale-first original E2M1/E4M3 W decode to BF16, F32 one-term dot, final BF16 projection and explicit F32 widening.',
  independent_oracle=identity(Path(__file__)),expected=expected,source_math=facts,backends=backends,HTTP=0,SDK_builds=0)
 path=O/'head-numeric-result.json';path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(status=result['status'],backends=list(backends),expected=expected,**facts)))
if __name__=='__main__':main()
