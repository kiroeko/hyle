from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent;O=S/'projection-check';E=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_text())
def identity(p):
 raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
head=read(O/'head-numeric-result.json');width=read(O/'width-numeric-result.json')
assert head['status']==width['status']=='PASS'and set(head['backends'])=={'cpu','cuda'}
assert width['independently_recomputed_channels']==[2507,2899,2918,3090,4012,4744,5376,5642]
assert head['source_math']['no_final_BF16_round_changed']==6 and head['source_math']['no_activation_QDQ_changed']==6
files={}
def add(p,name=None):
 assert p.is_file(),p
 files[name or p.relative_to(R).as_posix()]=p
for p in [O/'check.py',O/'head_oracle.py',O/'width_oracle.py',O/'head-numeric-result.json',O/'width-numeric-result.json',Path(__file__)]:add(p)
compiled=[]
for backend in ['cpu','cuda']:
 folder=O/backend;ready=read(folder/'ready.json');assert read(folder/'head-run/process.json')['exit']==0
 compiled.append(dict(backend=backend,image=ready['image'],sources=ready['sources'],compile=identity(folder/'compile/command.json'),link=identity(folder/'link/command.json'),head_run=read(folder/'head-run/process.json'),SDK_rebuilt=False))
 for phase in ['compile','link','head-run']:
  for name in ['command.json','process.json','stdout.log','stderr.log']:add(folder/phase/name)
 for p in (folder/'head-vectors').iterdir():add(p)
 add(folder/'head-preflight.json')
 # The app-local sources were frozen immediately after compile and checked
 # against pre-compile identities. Keep one identical source set, not binaries.
 for entry in ready['sources']:
  original=Path(entry['path']);frozen=folder/'sources'/original.relative_to(R)
  actual=identity(frozen);assert actual['bytes']==entry['bytes']and actual['sha256']==entry['sha256']
  key='compiled-source/'+original.relative_to(R).as_posix()
  if key in files:assert files[key].read_bytes()==frozen.read_bytes()
  else:add(frozen,key)
for p in (O/'cuda/width-vectors').iterdir():add(p)
for name in ['command.json','process.json','stdout.log','stderr.log']:add(O/'cuda/width-run'/name)
add(O/'cpu/initial-fixture-failure.json')
M=R/'.scratch/mtp-metadata-offline-20261024';plan=read(M/'cat7-head-plan.json');acq=read(M/'cat7-head-results.json');assert acq['complete']
for p in [M/'cat7-head-plan.json',M/'cat7-head-results.json',M/'fetch-cat7-head.py',R/plan['components'][0]['header']['path'],R/plan['components'][0]['header_acquisition']['path']]:add(p)
for p in (M/'components/q27-nvfp4-original-head').glob('*.json'):add(p)
OLD=R/'.scratch/qwen-mtp-quality-20261022'
for name in ['prefix_existing_numeric_contract.py','prefix-existing-numeric-contract.verified.json']:add(OLD/'review'/name)
for name in ['normalized.bf16','qkv.bf16']:add(OLD/'prefix1/vectors/T1'/name)
stem='mtp-fixed-width-packed-head-2026-10-24';archive=E/(stem+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(files.items()):z.write(p,name)
result=dict(kind='Bounded numerical-width and newly connected original packed target-head correctness',date='2026-10-24',status='PASS',
 packed_target_head=dict(source_repository=acq['results'][0]['repository'],revision=acq['results'][0]['revision'],hf='https://huggingface.co/'+acq['results'][0]['repository']+'/tree/'+acq['results'][0]['revision'],
  original_source=acq['results'][0]['source'],original_ranges=[dict(kind=r['kind'],inclusive=r['absolute_inclusive'],bytes=r['bytes'])for r in plan['components'][0]['ranges']],
  body_bytes=8648,acquisition=identity(M/'cat7-head-results.json'),validation=head,product_fix='Recipe::scores selects the original typed NVFP4 projection, retaining its BF16 QDQ/operand/output boundaries, then widens its BF16 result to the F32 logits buffer. It does not relabel that as DenseLinearF32. The six engine reports derive score policy from the actual loaded head; prefix reuse remains Model/math-local.',
  prior_contract='docs/evidence/correctness/nvfp4-reference-linear-2026-10-20.json',source_reader='docs/evidence/research/nvfp4-channel-global-contract-2026-10-20.json'),
 fixed_original_A_projection=dict(validation=width,summary='T1 equals the previously proved6144-channel output. T3 andT5 each differ at exactly the same8channels. Only those8channels were recomputed with FP64 fsum and exact dyadic F32-bound/BF16-cell analysis; all pass unchanged prior criteria. Remaining identical channel values inherit the original all6144 proof.',
  contract='Preserves supplied finite verifier conditionals; no cross-width bit equality or identical-seed text requirement.',
  old_evidence='docs/evidence/correctness/qwen-mtp-quality-prefix-2026-10-22.json',
  state_and_sampling_evidence=['docs/evidence/correctness/qwen35-mtp-prefix-state-values-2026-10-24.json','docs/evidence/correctness/qwen-mtp-multirow-sampling-2026-10-24.json']),
 build=compiled,fixture_correction=read(O/'cpu/initial-fixture-failure.json'),
 operations=dict(new_inference_graph_calls=5,head_CPU_graphs=1,head_CUDA_graphs=1,fixed_A_CUDA_graphs=3,new_HTTP_requests_by_this_checker=0,new_tensor_body_bytes_by_this_checker=0,SDK_builds=0,whole_model_runs=0),
 limitations=['The source head test selects the actual first3vocabulary rows with fullK5120; it does not run the complete NVIDIA27B target, full248320vocabulary or trained NextN.',
 'No Graph physical BF16/F32[3,5120] weight bank is present. Workspace values are declared Graph report values, not measured native peak or a universal full-model memory bound.',
 'The fixed-A test uses the current ordinary Recipe projection as a terminal tiny graph. It does not add diagnostic ports to the default full-model hot graph, establish a vendor reduction tree, or test model intelligence.',
 'State-value same-width/suffix/lag1 and multirow p/q wiring are signed only by the separately linked actual evidence; this test does not replace them.',
 'The initial focused head fixture omitted its independent Recipe last_row shape binding and correctly failed. It was fixed using the normal finite-exact child API, without changing product math or relaxing Graph checks.',
 'No model weights, SDK, object files or executables are embedded in the evidence archive. Original bytes are identified by fixed revision, exactRange, strongETag and slice hashes.'],
 reproduction=dict(build_cpu='python .scratch/mtp-correctness-20261024/projection-check/check.py build cpu',build_cuda='python .scratch/mtp-correctness-20261024/projection-check/check.py build cuda',head='python .scratch/mtp-correctness-20261024/projection-check/check.py run-head <cpu|cuda>',width='python .scratch/mtp-correctness-20261024/projection-check/check.py run-width cuda',oracles=['python .scratch/mtp-correctness-20261024/projection-check/head_oracle.py cpu cuda','python .scratch/mtp-correctness-20261024/projection-check/width_oracle.py']),
 archive=identity(archive),archived_files=len(files))
path=E/(stem+'.json');path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
print(json.dumps(dict(report=identity(path),archive=identity(archive),files=len(files))))
