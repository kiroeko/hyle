"""Explicit tiny packed-head association source. Default check never opens HTTP."""
from pathlib import Path
import argparse,importlib.util,inspect,json,math,sys,urllib.request
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];SCRIPT=Path(__file__).resolve().relative_to(R).as_posix();BUDGET=R/'.scratch/mtp-download-budget-20261023/budget.py'
spec=importlib.util.spec_from_file_location('head_original_transport',S/'fetch-source-components.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);h=old.h;h.SCRIPT=SCRIPT
def check():
 p=h.parse_json((S/'cat7-head-plan.json').read_bytes())
 if len(p['components'])!=1 or p['maximum_HTTP_requests']!=3 or p['total_new_tensor_payload_bytes']!=8648 or p['full_models_or_expert_libraries']:raise ValueError('Exact head bounds changed')
 for x in p['helpers']:
  if old.identity(R/x['path'])!=x:raise ValueError('Reviewed exact transport changed')
 c=p['components'][0];source=c['source'];folder=S/'indexes/cat07'
 if c['catalog_index']!=7 or c['repository']!='nvidia/Qwen3.8-27B-NVFP4' or c['id']!='q27-nvfp4-original-head' or c['full_reduction_K']!=5120 or c['selected_N']!=3:raise ValueError('Exact original head selection changed')
 row=dict(repository=c['repository'],revision=c['revision'],file=source['file'],uri=c['uri'])
 if c['uri']!=f'https://hf-mirror.net/{c["repository"]}/resolve/{c["revision"]}/{source["file"]}'or h.crosscheck_tree_identity(row,(folder/'expanded-api.json').read_bytes(),(folder/'tree-api.json').read_bytes())!=source:raise ValueError('Independent original source changed')
 for key in ['header','header_acquisition']:
  if old.identity(R/c[key]['path'])!=c[key]:raise ValueError('Original header proof changed')
 raw=(R/c['header']['path']).read_bytes();schema=h.parse_header(raw,source['size'])['all_physical_tensors'];acq=h.parse_json((R/c['header_acquisition']['path']).read_bytes())
 if acq['source']!=source or acq['header_sha256']!=h.digest(raw):raise ValueError('Original header acquisition mismatch')
 if len(c['ranges'])!=3 or {x['kind']for x in c['ranges']}!={'codes','scales','globals'}:raise ValueError('Exactly three bounded original ranges required')
 total=0
 for x in c['ranges']:
  if (R/x['output']).resolve()!=(S/'components'/c['id']/(x['kind']+'.bin')).resolve():raise ValueError('Fixed output changed')
  if x['kind']=='globals':
   if len(x['logical_roles'])!=2 or x['bytes']!=8 or x['absolute_inclusive']!=[8+len(raw),15+len(raw)]:raise ValueError('Original two-scalar span changed')
   if x['original']!=dict(physical_roles={r['name']:schema[r['name']]for r in x['logical_roles']})or x['selection']!=dict(complete_physical_roles=[r['name']for r in x['logical_roles']]):raise ValueError('Merged span must retain its two distinct physical roles')
   for i,role in enumerate(x['logical_roles']):
    if role['original']!=schema[role['name']]or schema[role['name']]!={'dtype':'F32','shape':[],'data_offsets':[4*i,4*i+4]}or role['selected_byte_offset']!=4*i:raise ValueError('Original scalar association changed')
  else:
   original=schema[x['name']];width=original['shape'][1];first=8+len(raw)+original['data_offsets'][0]
   if x['original']!=original or x['bytes']!=3*width or x['absolute_inclusive']!=[first,first+3*width-1] or x['selection']!=dict(axis0_first=0,axis0_count=3,axis1_full=True)or x['selected_shape']!=[3,width]:raise ValueError('Original first3-row/fullK range changed')
  total+=x['bytes']
 if total!=8648:raise ValueError('Exact payload byte bound changed')
 return p
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',nargs='?',choices=['check','fetch'],default='check');parser.add_argument('--owner-marker');args=parser.parse_args();plan=check()
 if args.action=='check':print(json.dumps(dict(state='offline_packed_head_plan_valid',bytes=8648,requests=3,HTTP=0)));return
 if args.owner_marker!=plan['required_owner_marker']:parser.error('Exact active root owner marker required')
 owner=BUDGET.parent/args.owner_marker
 if not owner.is_file()or(BUDGET.parent/'PAUSED').exists():raise RuntimeError('Root does not hold enabled acquisition; zero HTTP')
 fn=urllib.request.urlopen
 if not inspect.isfunction(fn)or Path(fn.__code__.co_filename).resolve()!=BUDGET.resolve()or inspect.getclosurevars(fn).nonlocals.get('script')!=SCRIPT:raise RuntimeError('Only budget.py run may open HTTP')
 result=old.acquire(h.module(),plan['components'][0],owner);h.save(S/'cat7-head-results.json',dict(complete=True,results=[result],original_tensor_bytes=8648));print(json.dumps(dict(complete=True,bytes=8648)))
if __name__=='__main__':main()
