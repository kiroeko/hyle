from pathlib import Path
import copy
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
NAME = 'docs/implementation/model-quantizations.json'
EVIDENCE = 'docs/evidence/correctness/mlx-head-payload-reference-2026-10-21.json'
before = (S/'before'/NAME).read_bytes()
assert (ROOT/NAME).read_bytes() == before
old = json.loads(before)
data = copy.deepcopy(old)
c = data['artifacts'][31]['provider_coverage']
c['mapping_status'] = (
    'Stored affine4 g64 U32/BF16 triples and both packed weight orientations are implemented. '
    'The 156 attention head-bank triples are 78 embed_q plus 78 unembed_out, each indexed by64 attention heads rather than MoE experts. '
    'The original layer0 embed_q and unembed_out six tensors (8257536 bytes) were obtained from the fixed first shard and '
    'consumed directly, including signed BF16 scales/biases and unchanged U32 codes. '
    'Decode B2/L1 and prefill B1/L3 ordinary Graphs now check both actual role shapes, separate attention-result boundaries, '
    'head restoration, actual output strides and two-slot/two-generation lifetimes in the passed backend windows. '
    'This is a layer0 role reference, not execution of all78 layers/156 triples, whole MLA/model or native low-type MLX bitwise qualification.'
)
c['role_domains'][0]['observed'] = c['mapping_status']
c['role_domains'][0]['followup_evidence'] = EVIDENCE
remaining = [
    'The fixed layer0 embed_q/unembed_out payload consumer is executed in the recorded backend windows. It does not qualify all78 layers/156 head-bank triples or require running33 complete models to establish the primitive capability.',
    'Whole MLA/attention composition, surrounding query/latent production, cache/indexer behavior and final o_proj are outside these independent projection-boundary Graphs.',
    'Original exporter identity and native same-low-type MLX QMM bitwise equivalence remain unqualified; the oracle is the declared Hyle F32 affine decode/dot with final BF16 output.',
    'No whole-artifact or Linux execution, quality, throughput or peak-memory acceptance. GLM32 original F16-metadata mixed-type role/working-set qualification is separate.'
]
c['artifact_unaligned_or_unverified'] = copy.deepcopy(remaining)
c['missing_capabilities'] = copy.deepcopy(remaining)
c['role_domains'][0]['unresolved'] = copy.deepcopy(remaining)
c['head_payload_role_reference'] = {
    'observed_on': '2026-10-21',
    'evidence': EVIDENCE,
    'repository': 'mlx-community/GLM-5.3-4bit',
    'revision': '81ad9b73c6188f808737dbb52458f082d249dcbe',
    'shard': 'model-00001-of-00091.safetensors',
    'tensor_payload_bytes_read': 8257536,
    'original_tensors': 'model.layers.0.self_attn.{embed_q,unembed_out}.{weight,scales,biases}; six bounded HTTP206 ranges, no whole shard',
    'physical_contract': 'embed_q U32[64,512,24], BF16 SF/bias[64,512,3]; unembed_out U32[64,256,64], BF16 SF/bias[64,256,8]. Affine4/g64 original bytes are neither repacked nor narrowed; negative stored scales remain signed.',
    'decode': 'B2/L1 BF16 query[...,64,256] -> first192 slice + the same small explicit Copy -> transpose-weight embed_q. Independent BF16 attention-result boundary[...,64,512] -> transpose-weight unembed_out -> [2,1,16384]; embed output is not presented as attention.',
    'prefill': 'B1/L3 BF16 shared latent -> [3,1,512], used by AsStored embed_q and transpose-weight unembed_out -> metadata restoration to [1,64,3,192/256]. Readback follows each actual output TensorDesc byte_strides, not an assumed physical transpose.',
    'numerical_and_resource_reference': 'One-hot signed dyadic A including .75, independent serialized-bit affine/BF16 oracle, both original banks, two slots/two generations and retained outputs after other-slot updates and invocation destruction. Earlier BF16 decoded-W rounding differs at17702 logical output values. Each passed backend runs eight successful submissions; CUDA requires and actually uses capture.',
    'backend_status': 'See this batch followup for the passed/pending windows; this field does not claim every backend passed.',
    'artifact_execution_verified': False
}
prior = c.get('precise_role_consumer_reference', {})
if 'head_bank_source_review' in prior:
    prior['head_bank_source_review'] = prior['head_bank_source_review'].replace(
        'Original exporter-version identity and artifact payload remain unqualified.',
        'Original exporter-version identity remains unqualified; later selected layer0 real payload execution is recorded in head_payload_role_reference, not in that earlier evidence.')
data['followup_reviews'].append({
    'observed_on': '2026-10-21',
    'evidence': EVIDENCE,
    'artifact_indices': [31],
    'scope': 'Original fixed layer0 embed_q and unembed_out six tensors,8257536B, consumed unchanged by decode B2/L1 and prefill B1/L3 ordinary Graphs. Independent attention-result input, signed BF16 metadata, both packed orientations, actual output strides and retained-slot/constant lifetimes are checked.',
    'partial_backend_snapshot': True,
    'backend_validation': {
        'CPU': {'status': 'passed', 'cases': 1, 'skipped': 0},
        'CUDA': {'status': 'passed', 'cases': 1, 'skipped': 0, 'capture': 'RequireCapture with actual captured route'},
        'Vulkan': {'status': 'passed', 'cases': 1, 'skipped': 0},
        'Apple': {'status': 'pending', 'reason': 'Actual strided readonly native output export issue under correction/retest; no final successful window claimed by this snapshot'}
    },
    'successful_submissions_per_passed_backend': 8,
    'premature_bf16_weight_rounding_differences_per_passed_backend': 17702,
    'limits': 'Only the two selected layer0 role boundaries; no full78-layer/156-bank claim, whole MLA/model, native MLX low-type bitwise equivalence, GLM32 mixed-type role, Linux, quality, throughput or peak-memory acceptance. All33 artifact_execution_verified remain false.'
})

assert [i for i, (a, b) in enumerate(zip(old['artifacts'], data['artifacts'])) if a != b] == [31]
left = copy.deepcopy(old['artifacts'][31]); right = copy.deepcopy(data['artifacts'][31])
left.pop('provider_coverage'); right.pop('provider_coverage'); assert left == right
previous = old['artifacts'][31]['provider_coverage']
for key in ('metadata_sources', 'required_format_domain', 'fixed_source_role_binding',
            'reachable_entry_points', 'primitive_validation', 'weight_orientation_reference'):
    assert previous.get(key) == c.get(key), key
assert old['followup_reviews'] == data['followup_reviews'][:-1]
for key in old:
    if key not in ('artifacts', 'followup_reviews'):
        assert old[key] == data[key]
assert len(data['artifacts']) == 33
assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in data['artifacts'])
after = (json.dumps(data, ensure_ascii=False, indent=2)+'\n').replace('\n', '\r\n').encode('utf-8')
(ROOT/NAME).write_bytes(after)
p = S/'after'/NAME
p.parent.mkdir(parents=True, exist_ok=True)
p.write_bytes(after)
(S/'implementation.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),
    after.decode().splitlines(True), fromfile='before/'+NAME, tofile='after/'+NAME)), encoding='utf-8', newline='')
identity = {'path': NAME, 'bytes': len(after), 'sha256': hashlib.sha256(after).hexdigest()}
validation = {'status': 'catalog31_only_partial_backend_snapshot_applied',
    'changed_artifact_indices': [31], 'changed_artifact_fields': 'provider_coverage only',
    'prior_metadata_role_facts_reachable_and_primitive_history_unchanged': True,
    'prior_followups_unchanged': True, 'followup_review_count': len(data['followup_reviews']),
    'all33_artifact_execution_verified_false': True,
    'CRLF_preserved': after.count(b'\r\n') == after.count(b'\n'),
    'no_build_GPU_or_other_docs_product_fixture_changes': True, 'source': identity}
(S/'validation.json').write_text(json.dumps(validation, indent=2)+'\n', encoding='utf-8')
(S/'source-freeze.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')
print(json.dumps(validation, indent=2))
