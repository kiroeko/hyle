from pathlib import Path
import json,hashlib,base64,re,runpy
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';P=A/'mlx-head-payload-2026-10-21/apple';O=P/'mac';O.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
OLD=A/'mlx-weight-orientation-2026-10-21/apple/mac/remote';oldplan=read(OLD/'plan.json');oldroot=oldplan['remote'];remote=oldroot.replace('/mlx-weight-orientation-2026-10-21/apple','/mlx-head-payload-2026-10-21/apple');payload=remote.rsplit('/',1)[0]+'/payload'
sources=['src/compute_route_apple/apple_memory.mm','src/graph_route_apple/native_region.cc','tests/graph_route_apple/native_region_test.cc','tests/graph_route_apple/mlx_head_payload_test.cc']
plan=dict(oldplan,remote=remote,image='mlx-head-payload',filter='AppleMlxHeadPayload.*:AppleNativeRegion.ReadonlyNativeOutputsRejectMutableMemAndBlitAccess',compile=[],link=read(OLD/'results/link.command.json')['argv'],inputs=read(OLD/'results/link-inputs.json'),run_environment=dict(HYLE_MLX_HEAD_PAYLOAD_DIR=payload))
for source in sources:
 if source=='src/compute_route_apple/apple_memory.mm':recipe=read(A/'expert-working-set-2026-10-21/apple/mac/remote/results/src--compute_route_apple--apple_memory.mm-compile.command.json')['argv']
 elif source=='src/graph_route_apple/native_region.cc':recipe=read(A/'ct-packed-grouped-space/apple/mac/remote/results/src--graph_route_apple--native_region.cc-compile.command.json')['argv']
 else:recipe=read(OLD/'results/tests--graph_route_apple--mlx_orientation_test.cc-compile.command.json')['argv']
 tag=source.replace('/','--');short=source.rsplit('.',1)[0].replace('/','--');matches=[x for x in plan['link']if x.endswith('/'+tag+'.o')or x.endswith('/'+short+'.o')];assert len(matches)<=1 and(matches or source.startswith('tests/')),(source,matches)
 plan['compile'].append(dict(source=source,recipe=recipe,old_object=matches[0]if matches else ''))
plan['include_roots']=list(dict.fromkeys([*oldplan['include_roots'],*[oldroot+'/'+x for x in oldplan['include_roots']if not x.startswith('/')],oldroot+'/tests/compute_models']))
previous={x['path']:x for x in read(OLD/'source-manifest.json')}
search=[ROOT,ROOT/'include',*[x for x in(ROOT/'src').iterdir()if x.is_dir()],*[x for x in(ROOT/'third_party').iterdir()if x.is_dir()]];seen=set();include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M)
def visit(p):
 p=p.resolve()
 if p in seen or not p.is_relative_to(ROOT)or not p.is_file():return
 if p.suffix not in ['.h','.hpp','.hh','.cc','.mm','.inc','.inl','.cuh']:return
 seen.add(p)
 for name in include.findall(p.read_text(encoding='utf-8',errors='replace')):
  target=next((b/name for b in[p.parent,*search]if(b/name).is_file()),None)
  if target:visit(target)
for source in sources:visit(ROOT/source)
files=[];reuse=[]
for p in sorted(seen):
 b=p.read_bytes();key=p.relative_to(ROOT).as_posix();row=dict(path=key,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if key in previous and row['sha256']==previous[key]['sha256']:reuse.append(dict(row,remote_path=oldroot+'/'+key))
 else:files.append(dict(row,data=base64.b64encode(b).decode()))
save(O/'source-manifest.json',[{k:v for k,v in x.items()if k!='data'}for x in files]);save(O/'reused-source-manifest.json',reuse);save(O/'plan.json',plan)
script=(A/'mlx-weight-orientation-2026-10-21/apple/build_mac.py').read_text().replace('p = subprocess.run(command, cwd=R, capture_output=True, text=True)', 'env = dict(__import__("os").environ)\n    if tag == "run":\n        env.update(plan.get("run_environment", {}))\n        record["environment"] = plan.get("run_environment", {})\n        save(tag + ".command.json", record)\n    p = subprocess.run(command, cwd=R, capture_output=True, text=True, env=env)').encode();(P/'build_mac.py').write_bytes(script)
script=script.decode().replace('\"--gtest_filter=\" + plan[\"filter\"]', '\"--gtest_filter=\" + next((x.split(\"=\",1)[1] for x in sys.argv if x.startswith(\"--filter=\")), plan[\"filter\"])').encode();(P/'build_mac.py').write_bytes(script)
code=r"""from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p['plan']['remote']);r.mkdir(parents=True,exist_ok=True);assert not r.is_symlink()
for x in p['reuse']:
 q=Path(x['remote_path']);b=q.read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'],str(q)
for x in p['files']:
 b=base64.b64decode(x['data']);assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'];q=r/x['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/'source-manifest.json').write_text(json.dumps([{k:v for k,v in x.items()if k!='data'}for x in p['files']],indent=2)+'\n');(r/'reused-source-manifest.json').write_text(json.dumps(p['reuse'],indent=2)+'\n');(r/'plan.json').write_text(json.dumps(p['plan'],indent=2)+'\n');(r/'build_mac.py').write_bytes(base64.b64decode(p['script']))
for x in p['plan']['inputs']:
 q=Path(x['path']);b=q.read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'],str(q)
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'space':['df','-h',str(r)]}.items()};assert h['model']=='Mac16,12';(r/'hardware.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(remote=str(r),delta_files=len(p['files']),delta_bytes=sum(x['bytes']for x in p['files']),reuse_files=len(p['reuse']),hardware=h)))
"""
__import__('ast').parse(code);__import__('ast').parse(script.decode())
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];result=ssh(code,dict(plan=plan,files=files,reuse=reuse,script=base64.b64encode(script).decode()));save(O/'sync.result.json',result);print(json.dumps(result,indent=2))
