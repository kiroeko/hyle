#include "../compute_models/mlx_head_payload_fixture.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/graph/apple.h"

TEST(AppleMlxHeadPayload, PackedLayer0RolesKeepOriginalBytesAndHeadOrder) {
  namespace f = mlx_head_payload_test;
  namespace a = hyle::compute::apple;
  auto context = a::Context::create().value();
  ::testing::Test::RecordProperty("device", context.environment()->device_name);
  auto memory = a::MemoryResource::create(context).value();
  const std::array domains{f::g::StorageDomain{memory.ref()}};
  const std::array targets{f::g::ExecutionTarget{
      f::g::apple::execution_source(context).value(), f::g::StorageDomainId{0}}};
  f::run(memory.ref(), std::span<const f::g::QueueBinding>{},
      [&](const f::g::Graph &graph, f::g::CompileOptions options) {
        return f::g::compile(graph, {domains, targets}, options);
      },
      [](f::m::BufferView destination, std::span<const std::byte> source) {
        return destination.write(source);
      },
      [](f::m::ConstBufferView source, std::span<std::byte> destination) {
        return source.read(destination);
      },
      [](f::g::Invocation &invocation,
         std::span<const f::g::QueueBinding> bindings) {
        return invocation.prepare_replay(bindings);
      });
}
