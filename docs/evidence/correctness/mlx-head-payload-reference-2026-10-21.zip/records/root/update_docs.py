from pathlib import Path
import json
Q=Path(__file__).resolve().parents[1];R=Q.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
for arm,attempt in [('cpu','final2'),('cuda','final1'),('vulkan','final1')]:
 d=read(Q/arm/'validation'/attempt/'receipt.json');assert d['passed'] and d['cases']==1 and not d['failed'] and not d['skipped']
apple=read(Q/'apple/final-validation.json');assert apple['failed']==apple['skipped']==0
def replace(path,changes):
 p=R/path;s=p.read_text(encoding='utf-8')
 for a,b in changes:
  assert s.count(a)==1,(path,a);s=s.replace(a,b)
 p.write_text(s,encoding='utf-8')
replace('docs/developer/current-work.md',[
 ('MLX affine非转置packed乘法已补四端，同head-bank的decode／prefill与寿命回归通过；继续精确角色导入与剩余资源／状态旅程',
  'GLM首层两组原始head权重已四端消费，Apple补齐原生非连续只读结果导出；下一项核普通E4成对生产／页读取旅程'),
 ('**当前下一动作**：继续第8包的精确角色导入复核，并衔接交付3的GA非CUDA状态／资源旅程；不把通用算子通过写成整制品执行。',
  '**当前下一动作**：沿现CacheEncode、成对pending／ready与页reader，补普通E4缓存的真实生产者旅程；随后核交付3的正式GA非CUDA indexer／状态链，不扩大为33整模型验收。'),
 ('未导入156个原head payload、未签原生低dtype全域等价、整模型或吞吐。',
  '后续已按固定首shard偏移取到GLM31首层embed_q／unembed_out六个原tensor，合计7.875MiB；\n'
  '[真实权重消费者](../evidence/correctness/mlx-head-payload-reference-2026-10-21.json)核decode独立attention边界、prefill共享latent、head恢复与双槽旧结果。\n'
  'Apple由此暴露并修复原生非连续结果的只读byte投影，保实际stride、完整span、借用／拥有权限及退休；不增加Copy。\n'
  '实际原BF16 scale允许负数；提前将解码W舍入BF16会使17702个输出不同，四端仍保原F32合同。\n'
  '只签首层两角色；其余77层、整MLA／模型、原生低dtype全域等价与吞吐仍未签。'),
 ('H64/N512/K192同bank两方向的有限数值／资源旅程已四端执行；实际publisher payload导入与完整角色组合仍须分别核定。',
  'H64/N512/K192同bank两方向及首层原payload的独立unembed_out角色已四端执行；其它层、GLM32与完整角色组合仍须分别核定。')])
replace('docs/user/compute.md',[
 ('这是现有F32 affine解码／点积合同的有限回归，未签上游原生低精度kernel全域逐位等价或具体GLM制品。',
  '这是现有F32 affine解码／点积合同的有限回归。另有[GLM首层原payload双head角色](../evidence/correctness/mlx-head-payload-reference-2026-10-21.json)的四端消费、头序与结果寿命检查；未签上游原生低精度kernel全域逐位等价或整制品。'),
 ('readonly adopt 永久只读。原 native buffer/array/tensor 的受控导入见各路线的 memory 头。',
  'readonly adopt 永久只读。原 native buffer/array/tensor 的受控导入见各路线的 memory 头。\n'
  'Apple的`import_readonly`与原生Graph结果支持plain非连续只读视图：要求ready、shape／dtype／有效stride与完整地址span相符，保留原Array和结果寿命，不复制payload。\n'
  '借用输入的视图保持借用权限，已有拥有者的视图沿原lease范围导出；编码carrier仍要求原精确dense布局。')])
replace('docs/implementation/model-operators.md',[
 ('六份制品的完整header集合现已核对，实际资源导入、producer舍入和完整执行仍须分别验证；',
  '六份制品的完整header集合现已核对；GLM31首层两组head原tensor已[四端消费](../evidence/correctness/mlx-head-payload-reference-2026-10-21.json)，保BF16 metadata、独立attention边界和head顺序。\n'
  '其它角色／层的资源导入、producer舍入和完整执行仍须分别验证；')])
print('Updated actual layer0 role boundary, Apple readonly view contract and next paired-E4 resource action.')
