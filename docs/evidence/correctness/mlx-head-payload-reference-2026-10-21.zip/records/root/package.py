from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
Q=Path(__file__).resolve().parents[1];R=Q.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(d):
 p=resolve(d['path']);assert p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cases=[];receipts=[]
def collect(backend,path):
 for x in ET.parse(path).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name')
  cases.append(dict(backend=backend,name=name,actual_payload=name.endswith('.PackedLayer0RolesKeepOriginalBytesAndHeadOrder'),
   properties={p.get('name'):p.get('value') for p in x.findall('./properties/property')}))
for arm,attempt in [('cpu','final2'),('cuda','final1'),('vulkan','final1')]:
 p=Q/arm/'validation'/attempt/'receipt.json';d=read(p);assert d['passed'] and d['cases']==1 and not d['failed'] and not d['skipped']
 for k in ('image','xml','link_plan'):check(d[k])
 for row in read(resolve(d['link_plan']['path']))['inputs']:check(row)
 collect(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
apple_path=Q/'apple/final-validation.json';apple=read(apple_path);assert apple['failed']==apple['skipped']==0
check(apple['gtest']);collect('apple',resolve(apple['gtest']['path']))
models=[c for c in cases if c['actual_payload']];assert len(models)==4
assert sum(int(x['properties']['successful_submissions']) for x in models)==32
assert all(int(x['properties']['premature_bf16_weight_rounding_differences'])==17702 for x in models)
payload=read(Q/'payload/manifest.json');assert payload['payload_bytes']==8257536
for row in payload['tensors']:check(dict(path=str(Q/'payload'/row['filename']),bytes=row['bytes'],sha256=row['sha256']))
catalog=read(R/'docs/implementation/model-quantizations.json');assert len(catalog['artifacts'])==33 and all(a['provider_coverage']['artifact_execution_verified'] is False for a in catalog['artifacts'])
sources=[
 'include/hyle/compute/model_ops.h','include/hyle/compute/apple_memory.h',
 'src/compute_ops/operation.cc','src/compute_route_apple/apple_memory.mm',
 'src/compute_route_apple/apple_copy_internal.h','src/graph_route_apple/native_region.cc',
 'tests/compute_models/mlx_head_payload_fixture.h','tests/compute_models/nvfp4_reference_fixture.h',
 'tests/graph_route_apple/native_region_test.cc',
 'docs/user/compute.md','docs/developer/current-work.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
sources += [f'tests/graph_route_{a}/{n}' for a in ('cpu','cuda','vulkan','apple') for n in ('mlx_head_payload_test.cc','CMakeLists.txt')]
for a in ('cpu','cuda','vulkan','apple'):assert 'mlx_head_payload_test.cc' in (R/f'tests/graph_route_{a}/CMakeLists.txt').read_text(encoding='utf-8')
assert all((R/s).is_file() for s in sources)
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cpp','.c','.md','.mm','.ps1'}
for p in Q.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(Q).as_posix()]=p
for p in sorted((Q/'payload').glob('*.bin')):entries['payload/'+p.name]=p
prior=Q.parent/'fixed-role-binding-2026-10-21/mlx/31'
for rel in ('headers/model-00001-of-00091.safetensors.header.json','headers/model-00001-of-00091.safetensors.receipt.json','model.safetensors.index.json'):
 p=prior/rel;entries['source-provenance/'+rel]=p
archive=R/'docs/evidence/correctness/mlx-head-payload-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='actual_layer0_compressed_head_roles_four_backend_passed',
 scope='Fixed mlx-community/GLM-5.3-4bit revision81ad9b73c6188f808737dbb52458f082d249dcbe, layer0 embed_q and unembed_out only. Six source tensors are original U32 packed4/group64 W plus signed BF16 scales/biases, no repack or float weight bank. All64 heads preserve source order.',
 acquisition=dict(manifest=ident(Q/'payload/manifest.json'),bytes=8257536,MiB=7.875,
  method='Six exact HTTP206 ranges validated against original complete safetensors header/index, exact Content-Range/object length4928572714 and same immutable ETag. Body bounded to each tensor bytes+1. No full4.93GB shard.',
  payload_base=18218,negative_scales=ident(Q/'root/payload-observation.json'),
  reproducibility='Archive payload/ contains the six original .bin files. Extract those and set HYLE_MLX_HEAD_PAYLOAD_DIR to that directory before the optional *MlxHeadPayload.* tests; missing env skips, set env with missing/wrong-size files fails. Test does not download. Root receipts validate allsix SHA immediately before each actual run; Apple upload/run receipts bind same six bytes.'),
 execution=dict(decode='B2/L1/H64 original query[B,1,H,256] excludes PE64, one ordinary small Copy, embed_q default transpose. Independent supplied attention-result boundary[B,H,1,512] goes to unembed_out default transpose and restores[B,1,16384]. Embed is not wired to unembed as fake attention.',
  prefill='B1/L3 original shared latent[1,1,3,512] reshaped[T,1,512] feeds embed_q AsStored and independent unembed_out default transpose, with metadata permute to[B,H,L,192/256]. Result comparisons follow actual output byte strides; no physical output-transpose Copy.',
  lifetime='Each of2ordinary Graphs executes2slots*2content generations. Materialized source constants, Graph and Executable released before submit; invocation and compiled owners released while old results still readable. Original resources/leases/Completion only; CUDA requires and asserts captured replay.',
  arithmetic='Independent single-bit little-endian code reader, raw signed BF16 SF/bias, F32 multiply then add, sparse one-hot signed activation including .75, F32 dot/+0 and final BF16 RNE. No production decoder oracle and no relaxed tolerance.',
  counterfactual='Prematurely casting decoded W to BF16 changes17702 expected output values per backend across the same8submits; allfour actual backends match the original declared F32 reference bytewise.'),
 regression=dict(total=len(cases),actual_payload_cases=4,additional_Apple_boundary_cases=len(cases)-4,failed=0,skipped=0,
  successful_payload_Graph_submissions=32,windows=receipts,apple=ident(apple_path),cases=cases),
 product_fix='Apple existing native readonly export now admits exact plain strided views without payload Copy. It validates ready/shape/dtype/effective stride and checked complete physical address span, including gaps and offset; original backing bounds, borrowed versus owned permission, exact lease block identity and permanent readonly access remain. Encoded carriers stay exactly dense. Native-only RegionValue remains available where byte projection cannot match; actual storage/alias failures propagate.',
 build_and_failures=dict(Windows='Only thin wrappers and one relevant shared infer owner refreshed; SDK/NVCC/offline modules not rebuilt. Initial shared C2664 was int64 initializer-list versus graph::Dimension API, mechanically corrected. First CPU runtime used an old ops.obj allowing only dense reshape; current operation.cc already supports stride-chunk reshape. Fresh one shared owner replaces CPU/Vulkan only; CUDA current owner unchanged. Equivalent fixture query Copy ordering is not recorded as a product bug fix.',
  Apple='Initial same shared compile error and actual no-memory-view projection runtime preserved. Only current relevant memory/native-region owners and test wrappers refreshed for real readonly-view fix; no SDK rebuild.',
  Windows_owner_audit=ident(Q/'windows/operation-owner-refresh.json')),
 remaining_required='Continue ordinary E4 paired-pending producer/resource journey on CPU/Apple/Vulkan, with existing CUDA E4 path distinguished, then GA non-CUDA indexer/state/role consumers. Capability7/8 and all3delivery packages remain open.',
 limitations=['Only layer0 two head roles and existing Hyle F32-affine numerical contract. Not all78layers/156banks, complete attention/MLA/model, original exporter identity, native low-type MLX tile equivalence, GLM32, Linux, quality, throughput or peak-memory acceptance.',
 'All33 artifact_execution_verified flags remainfalse. Actual source tensors and role consumers are stronger than synthetic geometry; they do not mean a whole artifact ran.',
 'Current relevant actual link owners are identified, not a claim that every unrelated cached object or installation consumer was rebuilt from current worktree. Final current-source/install/Linux closure remains delivery1.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],sources=len(sources),cases=len(cases),payload_cases=4)
save(Q/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
