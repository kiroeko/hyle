from pathlib import Path
import json,xml.etree.ElementTree as ET
Q=Path(__file__).resolve().parents[1];R=Q.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
apple=read(Q/'apple/final-validation.json');assert apple['failed']==apple['skipped']==0
xp=Path(apple['gtest']['path']);xp=xp if xp.is_absolute() else R/xp
cases=ET.parse(xp).findall('.//testcase');assert len(cases)==3 and all(x.find('failure') is None and x.find('skipped') is None for x in cases)
p=R/'docs/implementation/model-quantizations.json';d=read(p)
f=next(x for x in d['followup_reviews'] if x['evidence']=='docs/evidence/correctness/mlx-head-payload-reference-2026-10-21.json')
assert f['partial_backend_snapshot'];f['partial_backend_snapshot']=False
f['backend_validation']['Apple']=dict(status='passed',cases=3,skipped=0,scope='One actual-payload case with8submits; one original gap/borrowed/owned view permission case with2submits; one existing mutable/blit readonly rejection neighbor')
f.update(distinct_cases=6,actual_payload_cases=4,additional_Apple_boundary_cases=2,successful_payload_Graph_submissions=32)
assert len(d['artifacts'])==33 and all(x['provider_coverage']['artifact_execution_verified'] is False for x in d['artifacts'])
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Final4backend source-payload plus2Apple boundary cases; all33 whole-artifact flags remainfalse.')
