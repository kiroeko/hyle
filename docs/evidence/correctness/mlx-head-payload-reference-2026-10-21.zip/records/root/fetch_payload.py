from pathlib import Path
import concurrent.futures,hashlib,json,re,urllib.request,urllib.parse
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
prior=P.parent/'fixed-role-binding-2026-10-21/mlx/31'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
header_path=prior/'headers/model-00001-of-00091.safetensors.header.json'
header=read(header_path);source=read(header_path.with_name('model-00001-of-00091.safetensors.receipt.json'))
assert sha(header_path.read_bytes())==source['header']['sha256']
index=read(prior/'model.safetensors.index.json')['weight_map']
base=8+header_path.stat().st_size;assert base==18218
folder=P/'payload';folder.mkdir(parents=True,exist_ok=True)
roles=[]
for role in ('embed_q','unembed_out'):
 for part in ('weight','scales','biases'):
  key=f'model.layers.0.self_attn.{role}.{part}';meta=header[key]
  assert index[key]=='model-00001-of-00091.safetensors'
  start,end=meta['data_offsets'];size=end-start
  count=1
  for dim in meta['shape']:count*=dim
  assert count*(4 if part=='weight' else 2)==size
  roles.append(dict(key=key,role=role,part=part,filename=f'{role}.{part}.bin',metadata=meta,start=base+start,end=base+end-1,bytes=size))
assert sum(x['bytes'] for x in roles)==8257536
def fetch(row):
 path=folder/row['filename'];receipt=path.with_suffix('.receipt.json')
 if receipt.exists():
  d=read(receipt);assert path.stat().st_size==row['bytes'] and sha(path.read_bytes())==d['sha256'];return d
 assert not path.exists()
 url=source['fixed_url']+f'?download=true&hyle_head_payload_range={row["start"]}-{row["end"]}'
 request=urllib.request.Request(url,headers={'Range':f'bytes={row["start"]}-{row["end"]}','Accept-Encoding':'identity','User-Agent':'Hyle-bounded-head-role-consumer'})
 with urllib.request.urlopen(request,timeout=45) as response:
  cr=response.headers.get('Content-Range','');match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',cr)
  assert response.status==206 and match and tuple(map(int,match.groups()))==(row['start'],row['end'],4928572714),(response.status,cr)
  length=response.headers.get('Content-Length')
  assert length is None or int(length)==row['bytes'],length
  etag=response.headers.get('ETag');assert etag==source['header']['etag'],etag
  data=response.read(row['bytes']+1);assert len(data)==row['bytes'],len(data)
  d=dict(**row,url=url,status=response.status,content_range=cr,etag=etag,final_host=urllib.parse.urlparse(response.url).hostname,sha256=sha(data))
 path.write_bytes(data);save(receipt,d);print(f'{row["filename"]} {len(data)} bytes sha256={d["sha256"]}',flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(fetch,row) for row in roles];results=[];errors=[]
 for i,future in enumerate(futures):
  try:results.append(future.result())
  except Exception as error:errors.append(dict(filename=roles[i]['filename'],error=repr(error)))
 if errors:
  save(P/'root/fetch-errors.json',errors);raise RuntimeError(errors)
save(folder/'manifest.json',dict(repository=source['repository'],revision=source['revision'],fixed_url=source['fixed_url'],
 source_header=dict(path=str(header_path.relative_to(R)),bytes=header_path.stat().st_size,sha256=sha(header_path.read_bytes())),
 payload_base=base,object_size=4928572714,payload_bytes=sum(x['bytes'] for x in results),tensors=results,
 scope='Actual layer0 embed_q and unembed_out compressed weight/scales/biases only. Not whole shard or artifact.'))
print('READY',folder/'manifest.json',flush=True)
