"""Refresh the actual stale CPU/Vulkan infer owner, retaining current CUDA infer."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('payload_wrapper_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R, Q, A = h.b, h.c, h.R, h.Q, h.A

history_path = A / 'native-ready-pages/schema/commands.json'
history = c.read(history_path)
old = next(x for x in reversed(history) if x.get('tag') == 'ops-compile'
    and any(y.get('sha256') == '29bab9acb8c74967d2cc5ceeeff14d7affa46ac9297cb444e41811b95becc45e'
        for y in x.get('objects', [])))
old_object = next(x for x in old['objects'] if Path(x['path']).name == 'ops.obj')
assert b.same(old_object)
source = R / 'src/compute_ops/operation.cc'
out = Q / 'common/checks/operation-refresh'
out.mkdir(parents=True, exist_ok=True)
(out / 'tmp').mkdir(exist_ok=True)
command = b.host_command(old['command'], source, 'operation', out)
frozen = b.identity(source)
assert not (out / 'compile.result.json').exists()
c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
    old_source=old['before'][0], old_object=old_object, recipe=b.identity(history_path),
    scope='Only compute_ops/operation.cc infer owner; runtime compute/operation.cc untouched'))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
deps = c.read(out / 'operation-deps.json')['Data']
record = dict(command=command, source=frozen, object=b.identity(out / 'operation.obj'),
    old_source=old['before'][0], replaces=old_object, recipe=b.identity(history_path),
    source_dependencies=b.identity(out / 'operation-deps.json'),
    dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
assert b.same(frozen)
c.save(out / 'identity.json', record)

arms = []
for arm in ['cpu', 'vulkan']:
    basepath = Q / arm / 'checks/link2/link-plan.json'
    base = c.read(basepath)
    oldkey = c.key(old_object['path'])
    assert sum(c.key(x['path']) == oldkey for x in base['inputs']) == 1
    assert all(b.same(x) for x in base['inputs'])
    inputs = [record['object'] if c.key(x['path']) == oldkey else x for x in base['inputs']]
    command = [record['object']['path'] if c.key(x) == oldkey else x
        for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    d = Q / arm / 'checks/link3'
    d.mkdir(parents=True, exist_ok=True)
    (d / 'tmp').mkdir(exist_ok=True)
    image = d / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
        '/IMPLIB:' + str(image.with_suffix('.lib'))]
    actual_paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert [c.key(x) for x in actual_paths] == [c.key(x['path']) for x in inputs]
    c.save(d / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(basepath),
        replaced_infer_owner=old_object, new_infer_owner=record['object'],
        wrapper_unchanged_from=b.identity(Q / arm / 'checks/attempt3/test-identity.json'),
        SDK_builds=0, GPU_runs=0, source_changes=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], d)
    c.save(d / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime,
        HYLE_MLX_HEAD_PAYLOAD_DIR=str(Q / 'payload')))
    c.execute('link', command, env, d)
    c.save(d / 'image.json', b.identity(image))
    lines = [line for line in image.with_suffix('.map').read_text(errors='replace').splitlines()
        if ('?infer_reshape@' in line or '?infer_view@' in line) and ' f ' in line]
    assert lines and all('operation.obj' in line and 'ops.obj' not in line for line in lines)
    arms.append(dict(arm=arm, image=b.identity(image), link_plan=b.identity(d / 'link-plan.json'),
        runtime_environment=b.identity(d / 'runtime-environment.json'), current_infer_map_lines=lines))

cuda_identity_path = A / 'strided-reshape/operation-identity.json'
cuda_identity = c.read(cuda_identity_path)
assert cuda_identity['source'] == frozen and b.same(cuda_identity['object'])
cuda_plan = c.read(Q / 'cuda/checks/link2/link-plan.json')
assert sum(c.key(x['path']) == c.key(cuda_identity['object']['path']) for x in cuda_plan['inputs']) == 1
cuda_map = Q / 'cuda/checks/link2/cuda.map'
cuda_lines = [line for line in cuda_map.read_text(errors='replace').splitlines()
    if ('?infer_reshape@' in line or '?infer_view@' in line) and ' f ' in line]
arms.insert(1, dict(arm='cuda', image=c.read(Q / 'cuda/checks/link2/image.json'),
    link_plan=b.identity(Q / 'cuda/checks/link2/link-plan.json'),
    runtime_environment=b.identity(Q / 'cuda/checks/link2/runtime-environment.json'),
    unchanged_current_infer_identity=b.identity(cuda_identity_path), current_infer_map_lines=cuda_lines))
c.save(S / 'operation-owner-refresh.json', dict(status='current_source_infer_linked',
    source=frozen, old_cpu_vulkan_source=old['before'][0], old_cpu_vulkan_object=old_object,
    fresh_CXX=1, new_links=2, SDK_builds=0, GPU_runs=0, product_source_edits=0,
    fresh_identity=b.identity(out / 'identity.json'), arms=arms,
    exclusion='src/compute/operation.cc is a distinct runtime owner and was not replaced'))
c.save(S / 'ready-for-root-run.json', dict(status='current_infer_compiled_linked_not_executed_by_agent',
    CXX_attempts=10, CXX_success=7, CXX_failed_fixture_type=3, links_success=8,
    NVCC_compiles=0, SDK_builds=0, GPU_runs=0, CPU_test_runs=0, arms=arms,
    operation_owner_audit=b.identity(S / 'operation-owner-refresh.json'),
    shared_fixture=b.identity(R / 'tests/compute_models/mlx_head_payload_fixture.h'),
    payload_directory=str(Q / 'payload'), payload_manifest=b.identity(Q / 'payload/manifest.json')))
print(S / 'ready-for-root-run.json')
