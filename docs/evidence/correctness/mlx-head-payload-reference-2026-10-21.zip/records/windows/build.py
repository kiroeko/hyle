"""Compile three thin wrappers and replace only their prior orientation test objects."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
Q = S.parent
A = Q.parent
R = A.parents[1]
P = A / 'mlx-weight-orientation-2026-10-21'
spec = importlib.util.spec_from_file_location('mlx_payload_build', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
RECIPES = {
    'cpu': P / 'cpu/checks/test3/test-identity.json',
    'cuda': P / 'cuda/checks/test1/test-identity.json',
    'vulkan': P / 'vulkan/checks/test2/orientation-test-identity.json',
}


def compile_one(arm, attempt):
    recipe = RECIPES[arm]
    old = c.read(recipe)
    source = R / f'tests/graph_route_{arm}/mlx_head_payload_test.cc'
    out = Q / arm / 'checks' / attempt
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'wrapper.result.json').exists()
    command = b.host_command(old['command'], source, 'payload-test', out)
    frozen = b.identity(source)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
        recipe=b.identity(recipe), replaces=old['object'],
        source_fixture=b.identity(R / 'tests/compute_models/mlx_head_payload_fixture.h'),
        scope='One test owner only; existing product/SDK objects unchanged'))
    env, _ = b.environment(command, [], out)
    c.execute('wrapper', command, env, out)
    deps = c.read(out / 'payload-test-deps.json')['Data']
    record = dict(command=command, source=frozen, object=b.identity(out / 'payload-test.obj'),
        recipe=b.identity(recipe), replaces=old['object'],
        source_dependencies=b.identity(out / 'payload-test-deps.json'),
        dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
    assert b.same(frozen)
    assert all(b.same(x) for x in record['dependencies'])
    c.save(out / 'test-identity.json', record)
    print('COMPILED', arm, flush=True)
    return arm, record


def link_one(arm, record, directory):
    basepath = P / arm / 'checks/link2/link-plan.json'
    base = c.read(basepath)
    oldkey = c.key(record['replaces']['path'])
    assert sum(c.key(x['path']) == oldkey for x in base['inputs']) == 1
    assert all(b.same(x) for x in base['inputs'])
    inputs = [record['object'] if c.key(x['path']) == oldkey else x for x in base['inputs']]
    assert len({c.key(x['path']) for x in inputs}) == len(inputs)
    command = [record['object']['path'] if c.key(x) == oldkey else x
        for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = Q / arm / 'checks' / directory
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
        '/IMPLIB:' + str(image.with_suffix('.lib'))]
    actual_paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert [c.key(x) for x in actual_paths] == [c.key(x['path']) for x in inputs]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(basepath),
        replaced_test_object=record['replaces'], new_test_object=record['object'],
        retained_input_count=len(inputs)-1, product_compiles=0, SDK_builds=0,
        GPU_runs=0, selection='Replace only the old orientation test owner; retain all current product objects'))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime,
        HYLE_MLX_HEAD_PAYLOAD_DIR=str(Q / 'payload')))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    print('LINKED', arm, flush=True)
    return dict(arm=arm, image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        test_identity=b.identity(Path(record['object']['path']).parent / 'test-identity.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--attempt', default='attempt1')
    parser.add_argument('--link-dir', default='link1')
    args = parser.parse_args()
    assert (R / 'tests/compute_models/mlx_head_payload_fixture.h').is_file()
    arms = list(RECIPES)
    if args.compile:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            records = dict(pool.map(lambda arm: compile_one(arm, args.attempt), arms))
    else:
        records = {arm: c.read(Q / arm / 'checks' / args.attempt / 'test-identity.json') for arm in arms}
    if args.link:
        # Keep links sequential to avoid unnecessary memory pressure.
        rows = [link_one(arm, records[arm], args.link_dir) for arm in arms]
        results = [c.read(path) for arm in arms for path in (Q / arm / 'checks').glob('attempt*/wrapper.result.json')]
        c.save(S / 'ready-for-root-run.json', dict(status='compiled_and_linked_not_executed',
            CXX_attempts=len(results), CXX_compiles=3, NVCC_compiles=0, SDK_builds=0, product_compiles=0, links=3,
            GPU_runs=0, CPU_test_runs=0, arms=rows,
            filter='{Cpu,Cuda,Vulkan}MlxHeadPayload.PackedLayer0RolesKeepOriginalBytesAndHeadOrder',
            payload_manifest=b.identity(Q / 'payload/manifest.json'),
            payload_directory=str(Q / 'payload'),
            assertions='CUDA kRequireCapture and kCaptured; missing env skips, root must set env'))


if __name__ == '__main__':
    main()
