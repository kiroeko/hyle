"""Exactly one authorized Q8 prepare or CPU case per new record directory."""
from pathlib import Path
import argparse,datetime,json,subprocess,sys,time
R=Path(__file__).resolve().parents[2]
B=Path(__file__).resolve().parent/'extension2/steps'
a=argparse.ArgumentParser();a.add_argument('step',choices=['prepare','cpu-ordinary','cpu-k4-random']);step=a.parse_args().step
folder=B/step;folder.mkdir(parents=True,exist_ok=False)
command=[sys.executable,'-B',str(R/'.scratch/qwen35-unsloth-mtp-20261024/run-original-ready.py'),'Q8','prepare']if step=='prepare'else[sys.executable,'-B',str(R/'.scratch/qwen-multi-draft-20261024/current-runtime-ready.py'),'Q8','run','--case',step]
with(folder/'command.json').open('x')as f:json.dump(dict(command=command,cwd=str(R),HTTP=0,SDK_builds=0,automatic_retry=False),f,indent=2)
started=time.time()
with(folder/'stdout.log').open('xb')as out,(folder/'stderr.log').open('xb')as err:
 process=subprocess.run(command,cwd=R,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
with(folder/'process.json').open('x')as f:json.dump(dict(exit=process.returncode,started_utc=datetime.datetime.fromtimestamp(started,datetime.timezone.utc).isoformat(),seconds=time.time()-started),f,indent=2)
print(json.dumps(dict(step=step,exit=process.returncode,records=str(folder))),flush=True)
print((folder/'stdout.log').read_text(encoding='utf-8-sig'),end='')
if process.returncode:print((folder/'stderr.log').read_text(encoding='utf-8-sig'),file=sys.stderr)
raise SystemExit(process.returncode)
