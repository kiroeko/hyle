"""Archive only finite Q8 CPU commands, original metadata, frozen source and results."""
from pathlib import Path
import hashlib,json,zipfile,datetime
R=Path(__file__).resolve().parents[2]
B=Path(__file__).resolve().parent
S=R/'.scratch/qwen35-unsloth-mtp-20261024/Qwen3.5-2B-UD-Q8_K_XL'
I=R/'.scratch/qwen35-unsloth-mtp-20261024/complete-v2/Q8'
C=R/'.scratch/qwen-pure-cpu-deployment-20261024/current1'
P=R/'.scratch/qwen-multi-draft-20261024/current-runtime-plans/Q8.json'
D=R/'docs/evidence/correctness/mtp-qwen35-q8-original-pure-cpu-complete-input-2026-10-24.json'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
last=load(B/'extension2/wait-window.json')
observations=[json.loads(x)for x in(B/'extension2/wait-observations.jsonl').read_text().splitlines()]
ready=observations[-1]
assert ready['roles_complete']and ready['full_original_LFS_verified']and ready['receipt_complete']
with(B/'extension2/final-readiness.json').open('x')as f:json.dump(dict(status='ready_before_extension2_deadline',window=last,last_observation=ready,models_started_by_observer=0,HTTP=0),f,indent=2)
roles=load(S/'payload-role-files.json');plan=load(P);runtime=load(C/'current-image.json');pe=load(C/'pe-dependencies.json')
cases=[]
for name in ['cpu-ordinary','cpu-k4-random']:
 folder=I/'current-runtime-runs'/name
 report=[json.loads(x)for x in(folder/'stdout.log').read_text().splitlines()if x.startswith('{')][-1]
 process=load(folder/'process.json');result=load(folder/'functional-result.json')
 assert process['exit']==0 and result['native_exit']==0 and result['image']==runtime['runtime']['image']
 assert report['backend']=='cpu'and report['original_device_weight_bytes']==0
 assert report['cache_peak_requested_bytes']<=268435456
 cases.append(dict(case=name,status='PASS',process=process,functional_result=result,committed_target_rows=report['committed_target_rows'],sampling_draw_cursor=report['sampling_draw_cursor'],draft_frontier=report.get('draft_frontier'),draft_lag=report.get('draft_lag'),consumed_drafts=report['consumed_drafts'],known_workspace_domains=report['workspace_domains'],workspace_limit_scope=report['workspace_limit_scope'],execution_shared_requested_byte_limit=report['execution_shared_requested_byte_limit'],native_execution_private_bytes_unknown=report['native_execution_private_bytes_unknown'],actual_report=ident(folder/'stdout.log')))
proof=dict(status='PASS',date='2026-10-24',scope='Complete original Qwen3.5-2B UD-Q8_K_XL input, current frozen pure CPU engine, one ordinary greedy and one K4 random MTP journey.',source=roles['source'],original_role_count=len(roles['roles']),original_payload_bytes=2882151680,prepared=ident(I/'input.json'),manifest=ident(I/'weights.tsv'),runtime=runtime['runtime'],pure_cpu_dependency_audit=dict(record=ident(C/'pe-dependencies.json'),status=pe['status'],CUDA=pe['CUDA'],TorchCUDA=pe['TorchCUDA'],cuBLAS=pe['cuBLAS'],CUDA_fatbin_sections=pe['CUDA_fatbin_sections']),retained_cpu_closure_evidence=ident(R/'docs/evidence/correctness/mtp-qwen35-pure-cpu-deployment-2026-10-24.json'),geometry=dict(prompt_tokens=154,context_capacity=256,cache_requested_byte_limit=268435456,ordinary_maximum_outputs=4,mtp_maximum_outputs=6,mtp_maximum_drafts=4,random_top_k=8,random_top_p=0.9,random_seed=123),wait_segments=[dict(name='initial30minutes',window=load(B/'wait-window.json'),result=load(B/'final-readiness.json')['status']),dict(name='explicit_extension1',window=load(B/'extension1/wait-window.json'),result=load(B/'extension1/final-readiness.json')['status']),dict(name='explicit_extension2',window=last,result='ready',ready_utc=ready['utc'])],prepare=dict(process=load(B/'extension2/steps/prepare/process.json'),roles=335,original_weight_bytes=2882151680,HTTP=0),cases=cases,additional_HTTP_by_this_task=0,additional_SDK_builds_by_this_task=0,model_runs=2,automatic_model_retry=False,performance_claim=False,limitations=['Two finite functional journeys do not establish full task quality, speed, long-context or multi-session performance.','The current application image reuses the previously audited pure CPU object closure; this is not a fresh full top-level install build.','The cache requested-byte cap and known per-invocation workspace cap are distinct; shared execution accounting is unlimited and native execution private bytes remain unknown.','Original data were acquired by the root-controlled bounded downloader; this consumer task only observed local metadata, prepared role references and ran the two authorized CPU cases.','GPU cases are published separately by the root agent.'])
files=[]
def add(p):
 if p.is_file()and p not in files:files.append(p)
for folder in [B,B/'extension1',B/'extension2',B/'extension2/steps/prepare',B/'extension2/steps/cpu-ordinary',B/'extension2/steps/cpu-k4-random']:
 for p in sorted(folder.iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.jsonl','.log']:add(p)
for name in ['payload-role-files.json','payload-acquisition.json']:add(S/name)
for name in ['input.json','weights.tsv','prompt.ids']:add(I/name)
for case in ['cpu-ordinary','cpu-k4-random']:
 for name in ['command.json','process.json','stdout.log','stderr.log','functional-result.json']:add(I/'current-runtime-runs'/case/name)
for name in ['current-image.json','pe-dependencies.json','closure-audit.json','retained-link-inputs.json','sources.json','compile-command.json','compile-process.json','link-command.json','link-process.json','runtime-environment.json','report-count-offline-checks.json']:add(C/name)
for p in sorted((C/'source').rglob('*')):
 if p.is_file()and p.suffix in ['.h','.cc']:add(p)
for p in [P,R/'.scratch/qwen-multi-draft-20261024/current-runtime-ready.py',R/'.scratch/qwen35-unsloth-mtp-20261024/run-original-ready.py',R/'.scratch/qwen35-unsloth-mtp-20261024/run-ready-v2.py',R/plan['report_inventory']['path'],R/'docs/evidence/correctness/mtp-qwen35-pure-cpu-deployment-2026-10-24.json']:add(p)
proof['files']=[ident(p)for p in files]
archive=D.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 z.writestr('result.json',json.dumps(proof,indent=2,allow_nan=False)+'\n')
 for p in files:
  assert p.stat().st_size<4000000
  z.write(p,p.relative_to(R).as_posix())
proof['archive']=ident(archive)
with D.open('x')as f:json.dump(proof,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(dict(evidence=str(D),archive=proof['archive'],cases=[dict(name=x['case'],status=x['status'],ids=x['functional_result']['generated_ids'],draw_cursor=x['sampling_draw_cursor'])for x in cases],files=len(files))))
