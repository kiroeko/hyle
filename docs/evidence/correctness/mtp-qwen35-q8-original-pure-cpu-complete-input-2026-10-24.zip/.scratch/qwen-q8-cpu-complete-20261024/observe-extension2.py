"""Explicit parent-authorized additional15-minute local metadata observation."""
from pathlib import Path
import datetime,json,time
R=Path(__file__).resolve().parents[2]
S=Path(__file__).resolve().parent/'extension2';S.mkdir(exist_ok=False)
B=R/'.scratch/qwen35-unsloth-mtp-20261024/Qwen3.5-2B-UD-Q8_K_XL'
start=time.time();deadline=datetime.datetime.fromisoformat(json.loads((Path(__file__).resolve().parent/'extension1/wait-window.json').read_text())['deadline_utc']).timestamp()+900
with(S/'wait-window.json').open('x')as f:
 json.dump(dict(started_utc=datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),deadline_utc=datetime.datetime.fromtimestamp(deadline,datetime.timezone.utc).isoformat(),parent_authorized_additional_seconds=900,interval_seconds=45,HTTP=0,models_started=0,builds=0),f,indent=2)
while True:
 now=time.time();row=dict(utc=datetime.datetime.fromtimestamp(now,datetime.timezone.utc).isoformat(),role_files_published=(B/'payload-role-files.json').is_file(),payload_file_bytes=(B/'payload.bin').stat().st_size,expected_payload_bytes=2882151680)
 try:
  receipt=json.loads((B/'payload-acquisition.json').read_text())
  row.update(receipt_complete=receipt.get('complete'),verified_block_count=len(receipt.get('blocks',[])),verified_block_bytes=sum(x['bytes']for x in receipt.get('blocks',[])))
 except json.JSONDecodeError:row['receipt_replacing']=True
 if row['role_files_published']:
  try:
   source=json.loads((B/'payload-role-files.json').read_text())
   row.update(roles_complete=source.get('complete'),physical_roles=len(source.get('roles',[])),full_original_LFS_verified=source.get('source',{}).get('full_file_sha256_verified'))
  except json.JSONDecodeError:row['role_files_replacing']=True
 with(S/'wait-observations.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
 if row.get('roles_complete')is True and row.get('full_original_LFS_verified')is True and row.get('receipt_complete')is True:
  print('READY_LOCAL_METADATA',flush=True);break
 if now>=deadline:
  print('NOT_READY_WITHIN_AUTHORIZED_ADDITIONAL_15_MINUTES_NO_MODEL_STARTED',flush=True);raise SystemExit(2)
 time.sleep(min(45,deadline-now))
