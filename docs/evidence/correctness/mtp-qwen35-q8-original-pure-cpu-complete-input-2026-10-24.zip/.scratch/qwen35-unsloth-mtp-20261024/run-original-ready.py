"""Explicit Q8/CT ready cases using retained pure-CPU or CUDA images.

Plan/check are offline. Preparation uses the existing explicit V2 preparer.
Every run names exactly one route/case, preserves its first failure, and never
downloads, builds, retries, or automatically expands to a test matrix.
"""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=B.parents[1];sys.path.insert(0,str(R))
PROFILES={
 'Q8':dict(inventory=B/'Qwen3.5-2B-UD-Q8_K_XL/typed-role-inventory.json',source=B/'Qwen3.5-2B-UD-Q8_K_XL/payload-role-files.json'),
 'CT':dict(inventory=R/'.scratch/mtp-metadata-offline-20261024/cat00/text-mtp-payload-plan.json',source=R/'.scratch/mtp-metadata-offline-20261024/cat00/full-text-payload/payload-role-files.json')}
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf8')
def identity(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def pin(x):
 if identity(R/x['path'])!=x:raise ValueError('Pinned runtime or input changed: '+x['path'])
def plan_path(profile):return B/'original-run-plans'/(profile+'.json')
def make_plan(profile):
 target=plan_path(profile)
 if target.exists():raise ValueError('Frozen ready plan already exists; do not overwrite')
 inventory=load(PROFILES[profile]['inventory']);rows=inventory['roles']
 if profile=='Q8':
  original=inventory['source'];mtp=lambda row:row['logical_name'].startswith('mtp.');expected_roles=335
 else:
  original=dict(inventory['source'],repository=inventory['repository'],revision=inventory['revision']);mtp=lambda row:row['name'].startswith('mtp.');expected_roles=649
 total=sum(row['bytes']for row in rows);text=sum(row['bytes']for row in rows if not mtp(row));assert len(rows)==expected_roles
 assert(total,text)==((2882151680,2817490176)if profile=='Q8'else(1838357584,1792067552))
 cpu=R/'.scratch/qwen-pure-cpu-deployment-20261024';cuda=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2';cuda_env=B/'engine-check/ready-cuda.json';native=load(cuda_env)['native_runtime'];cuda_native=cuda/Path(native['path']).name
 if identity(cuda_native)['sha256']!=native['sha256']:raise ValueError('Retained CUDA image native CPU companion changed')
 runtime={
  'cpu':dict(image=identity(cpu/'build/bin/hyle.exe'),environment=identity(cpu/'runtime-environment.json'),native=identity(cpu/'build/bin/hyle_ggml_cpu_pure_ffa4_current.dll'),source=identity(cpu/'source-identities.json')),
  'cuda':dict(image=identity(cuda/'recursive-probe.exe'),environment=identity(cuda_env),native=identity(cuda_native),source=identity(cuda/'sources.json'))}
 cases=[];input_dir=B/'complete-v2'/profile
 for backend in ['cpu','cuda']:
  for mode in ['ordinary','k1','k4-random']:
   command=[str(R/runtime[backend]['image']['path']),'--inputs',str(input_dir),'--capacity','256','--steps','6'if mode=='k4-random'else'4','--cache-bytes','268435456','--prefix-cache','off','--replay','commands','--mtp','off'if mode=='ordinary'else'on']
   if mode=='k4-random':command+=['--mtp-max-drafts','4','--sampling','random','--top-k','8','--top-p','.9','--seed','123']
   cases.append(dict(name=backend+'-'+mode,backend=backend,mtp=mode!='ordinary',random=mode=='k4-random',maximum_outputs=6 if mode=='k4-random'else 4,selected_original_bytes=text if mode=='ordinary'else total,command=command))
 prompt=B/'geometry-v2-check/original/prompt.ids';assert len(prompt.read_text().split())==154
 plan=dict(profile=profile,runner=identity(Path(__file__).resolve()),inventory=identity(PROFILES[profile]['inventory']),source=original,acquired_roles_path=PROFILES[profile]['source'].relative_to(R).as_posix(),physical_roles=expected_roles,full_original_bytes=total,text_original_bytes=text,
  runtime=runtime,cases=cases,prompt=identity(prompt),P=154,C=256,cache_limit_bytes=268435456,timeout_seconds=600,
  prepare_command=[sys.executable,str(B/'run-ready-v2.py'),profile,'prepare'],explicit_preparer=identity(B/'run-ready-v2.py'),
  source_qualification='Q8 requires acquired original full GGUF LFS certification; CT verifies649 selected text/MTP roles only and excludes vision, so its original whole-file LFS is an identity rather than a computed digest.',
  scope='Single explicitly selected bounded original-weight functional case, not latest-source certification, model task quality, throughput or required Cartesian matrix.',automatic_retry=False,HTTP=0,SDK_builds=0)
 save(target,plan);print(json.dumps(dict(profile=profile,plan=identity(target),physical_roles=expected_roles,all_bytes=total,text_bytes=text,cases=[c['name']for c in cases],models_started=0)))
def checked_plan(profile):
 plan=load(plan_path(profile));pin(plan['runner']);pin(plan['inventory']);pin(plan['prompt']);pin(plan['explicit_preparer'])
 for runtime in plan['runtime'].values():
  for x in runtime.values():pin(x)
 return plan
def acquisition_ready(plan):
 path=R/plan['acquired_roles_path']
 if not path.exists():return False
 original=load(path);rows=original['roles'];inventory=load(R/plan['inventory']['path'])
 if not original.get('complete')or len(rows)!=plan['physical_roles']or sum(r['bytes']for r in rows)!=plan['full_original_bytes']:raise ValueError('Acquired original role inventory/extent is incomplete')
 if plan['profile']=='Q8':
  source=original['source'];key='physical_name';expected={r[key]:r for r in inventory['roles']}
  if not source.get('full_file_sha256_verified'):raise ValueError('Q8 original full-file LFS was not verified')
 else:
  source=dict(original['source'],repository=original['repository'],revision=original['revision']);key='name';expected={r[key]:r for r in inventory['roles']}
 for field in ['file','size','lfs_sha256','repository','revision']:
  if source[field]!=plan['source'][field]:raise ValueError('Acquired source identity changed: '+field)
 if len({r[key]for r in rows})!=len(expected)or{r[key]for r in rows}!=set(expected):raise ValueError('Missing, duplicate, extra or wrong-source physical roles')
 for row in rows:
  exp=expected[row[key]]
  if row['bytes']!=exp['bytes']or len(row.get('sha256',''))!=64:raise ValueError('Original physical role byte extent/hash differs')
  if plan['profile']=='Q8':
   if row['original_offset']!=exp['absolute_inclusive'][0]:raise ValueError('Q8 original physical extent differs')
  elif(row['dtype'],row['shape'],row['absolute_inclusive'])!=(exp['dtype'],exp['shape'],exp['absolute_inclusive']):raise ValueError('CT original codec/geometry/range differs')
 return True
def prepared_ready(plan):
 if not acquisition_ready(plan):return False
 folder=B/'complete-v2'/plan['profile']
 if any(not(folder/name).is_file()for name in ['weights.tsv','input.json','prompt.ids']):return False
 receipt=load(folder/'input.json')
 if receipt['source_record']!=identity(R/plan['acquired_roles_path'])or receipt['source_repository']!=plan['source']['repository']or receipt['source_revision']!=plan['source']['revision']:raise ValueError('Prepared source is not bound to this authenticated original')
 if(receipt['physical_roles'],receipt['selected_weight_bytes'],receipt['text_weight_bytes'])!=(plan['physical_roles'],plan['full_original_bytes'],plan['text_original_bytes']):raise ValueError('Prepared physical byte inventory differs')
 if(folder/'prompt.ids').read_bytes()!=(R/plan['prompt']['path']).read_bytes():raise ValueError('Prepared P154 prompt IDs changed')
 return True
def run_case(plan,name):
 if not prepared_ready(plan):raise RuntimeError('Authenticated original roles + explicit V2 prepare are required; no model started')
 case=next(c for c in plan['cases']if c['name']==name);runtime=plan['runtime'][case['backend']];image=R/runtime['image']['path'];folder=B/'complete-v2'/plan['profile']/('retained-'+name)
 folder.mkdir(exist_ok=False);tmp=folder/'tmp';tmp.mkdir();record=load(R/runtime['environment']['path']);env=dict(os.environ,PATH=(str(image.parent)+os.pathsep if case['backend']=='cuda'else'')+record['PATH'],TEMP=str(tmp),TMP=str(tmp))
 save(folder/'command.json',dict(command=case['command'],plan=identity(plan_path(plan['profile'])),image=runtime['image'],manifest=identity(B/'complete-v2'/plan['profile']/'weights.tsv'),HTTP=0,SDK_builds=0,performance_claim=False));started=time.time()
 with(folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
  try:process=subprocess.run(case['command'],cwd=R,env=env,stdout=out,stderr=err,timeout=plan['timeout_seconds'],creationflags=subprocess.CREATE_NO_WINDOW)
  except subprocess.TimeoutExpired:save(folder/'process.json',dict(timeout=True,seconds=time.time()-started));raise
 save(folder/'process.json',dict(exit=process.returncode,seconds=time.time()-started))
 if process.returncode:raise RuntimeError('Native failure retained; no automatic retry or fallback')
 reports=[json.loads(x)for x in(folder/'stdout.log').read_text(encoding='utf8').splitlines()if x.startswith('{')];report=reports[-1];prepared=load(B/'complete-v2'/plan['profile']/'input.json')
 if report['source_id']!=prepared['source_id']or report['backend']!=case['backend']or report['mtp']!=case['mtp']:raise ValueError('Actual native source/route/mode differs')
 if report['sampling']!=('random'if case['random']else'greedy')or(case['random']and report['mtp_max_drafts']!=4):raise ValueError('Actual sampling policy differs')
 if report['cache_requested_byte_limit']!=268435456 or report['cache_peak_requested_bytes']>268435456:raise ValueError('Actual finite cache budget differs')
 host=report['original_host_weight_bytes'];device=report['original_device_weight_bytes']
 if host+device!=case['selected_original_bytes']or(case['backend']=='cpu'and device!=0)or(case['backend']=='cuda'and host!=0):raise ValueError('Original selected role byte placement differs')
 ids=report['generated_ids']
 if not 0<len(ids)<=case['maximum_outputs']or len(ids)!=report['generated_tokens']or any(not 0<=i<248320 for i in ids):raise ValueError('Native output count/domain differs')
 result=dict(profile=plan['profile'],case=name,native_exit=0,source_id=report['source_id'],generated_ids=ids,score_policy=report['score_policy'],host_weight_bytes=host,device_weight_bytes=device,cache_peak_requested_bytes=report['cache_peak_requested_bytes'],performance_claim=False,HTTP=0,SDK_builds=0)
 save(folder/'functional-result.json',result);print(json.dumps(result))
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('profile',choices=PROFILES);a.add_argument('action',choices=['plan','check','prepare',*[backend+'-'+mode for backend in ['cpu','cuda']for mode in ['ordinary','k1','k4-random']]]);args=a.parse_args()
 if args.action=='plan':make_plan(args.profile);return
 plan=checked_plan(args.profile)
 if args.action=='check':print(json.dumps(dict(profile=args.profile,acquired=acquisition_ready(plan),prepared=prepared_ready(plan),available_cases=[c['name']for c in plan['cases']],models_started=0,HTTP=0)));return
 if args.action=='prepare':
  if not acquisition_ready(plan):raise RuntimeError('Authenticated complete original roles not published; no prepare or model started')
  subprocess.run(plan['prepare_command'],cwd=R,check=True);return
 run_case(plan,args.action)
if __name__=='__main__':main()
