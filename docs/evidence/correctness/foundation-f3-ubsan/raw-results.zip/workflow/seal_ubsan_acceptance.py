from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'; raw = scratch / 'wsl-sanitizer-logs/ubsan'
job = json.loads((raw / 'job.json').read_text()); assert job['verdict'] == 'PASS_WSL_F3_UBSAN_ONLY'
for row in job['stages']:
    assert row['state'] == 'terminal' and row['exit_code'] == 0
    assert hashlib.sha256((raw / row['log']).read_bytes()).hexdigest() == row['sha256']
flags = json.loads((raw / 'subject-compile-flags.json').read_text())
assert len(flags) == 4 and all('-fsanitize=undefined' in row and '-fno-sanitize-recover=all' in row for row in flags.values())
tests = ET.parse(raw / 'files.xml').getroot()
assert tests.attrib['tests'] == '12' and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
assert 'runtime error:' not in (raw / 'files.log').read_text()
out = repo / 'evidence/correctness/foundation-f3-ubsan'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for path in sorted(raw.iterdir()):
        if path.is_file(): packed.writestr(path.name, path.read_bytes())
    for name in ['run_wsl_gates.py', 'seal_ubsan_acceptance.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
inputs = []
for name in ['src/compute_stream/file_stream.cc', 'src/compute_stream/stream_sources.cc', 'src/compute_route_cpu/file_stream.cc',
             'src/compute/batch_transfer.cc', 'include/hyle/compute/detail/file_stream_copy.h', 'tests/compute_stream/file_stream_test.cc']:
    data = subprocess.check_output(['git', 'show', job['candidate'] + ':' + name])
    inputs.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest()})
receipt = {'schema_version': 1, 'product_commit': 'f3d931c47777f7fbfd35dedf1f5e0734fa28ef6c', 'fixture_commit': job['candidate'],
    'scope': 'WSL actual non-recovering UBSan F3 common/CPU controller and twelve original file risks only',
    'identity': job['identity'], 'parallel': job['parallel'], 'test_parallel': 1,
    'tests_passed': 12, 'subject_compile_flags': flags, 'source_inputs': inputs,
    'runtime_errors': 0, 'positive_partial_write': 'Actual original POSIX file size limit: written=80/copied=96/ready=0, exact original prefix retained.',
    'allocator': 'Actual injected F3 metadata balanced and native active uses zero after own-work retirement.',
    'diagnostic_policy': 'WERROR=OFF only in GCC instrumented local verification, warnings preserved, non-recovering UBSan and full risk scope remain enabled; GCC official instrumentation recommendation.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_WSL_F3_UBSAN_TWELVE_RISKS_ONLY',
    'limits': 'No driver-private physical residency, TCP correctness, installed delivery or final F3 closure verdict.',
    'unproven': ['TSan', 'WSL native CUDA F3 delta', 'Installed static/shared/new headers/absence/relocation', 'Final P0/red team/closure']}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('UBSan twelve actual tests and exact non-recovering subject flags verified.')
