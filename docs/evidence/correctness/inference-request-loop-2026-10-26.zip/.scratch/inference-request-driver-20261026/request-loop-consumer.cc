#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_request_loop_case.h"
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("usage: request-loop-consumer INPUTS");return qwen_request_loop_case::run(argv[1]);}catch(const std::exception&e){std::cerr<<"request_loop_consumer_failure="<<e.what()<<"\n";return 1;}}
