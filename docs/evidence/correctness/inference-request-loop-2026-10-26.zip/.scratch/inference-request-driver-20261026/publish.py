"""Explicit compact text evidence; publication waits for root's final E4 result.

plan/publish never builds, runs consumers/analyzers, downloads or walks directories.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile
import zlib

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-working-state-20261026'
C = W/'consumer-cases'
DEST = R/'docs/evidence/correctness/inference-request-loop-2026-10-26'
BASELINE = '8e488136f'
SOURCES = ('engine/inference/request_loop.h', 'engine/inference/request_window.h',
    'engine/inference/request_progress.h', 'engine/inference/retirement_observation.h',
    'engine/models/qwen35/main.cc', 'tests/tools/qwen_request_lifecycle_test.cc',
    'tests/tools/qwen_request_loop_case.h', 'tests/tools/inference_request_loop_test.cc', 'tests/CMakeLists.txt')
MODES = ('ordinary-candidate', 'mtp-k1-candidate')
E4_IDS = ('d1011.ids', 'd1415.ids', 'd34.ids', 'd78.ids', 'd8.ids', 'i12.ids', 'i15.ids',
    'p1112.ids', 'p12.ids', 'p121314.ids', 'p1289.ids', 'p12910.ids', 'p13.ids',
    'p345.ids', 'p5.ids', 'p56.ids', 'p67.ids', 'p91011.ids')


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def encode(v): return (json.dumps(v, indent=2, ensure_ascii=False)+'\n').encode('utf8')
def pin(p):
    p = Path(p); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def collect():
    files = {}
    def add(p):
        p = Path(p)
        assert p.is_file() and p.is_relative_to(R), str(p)
        assert p.suffix.lower() in {'.h', '.cc', '.py', '.json', '.log', '.txt', '.ids', '.schedule', '.tsv'}
        assert p.stat().st_size < 2_000_000, str(p)
        files[p.relative_to(R).as_posix()] = p
    def stage(base, name):
        for f in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(base/name/f)
    def run(base, stdout='stdout.log'):
        for f in ('process.json', stdout, 'stderr.log'): add(base/f)
    for f in SOURCES: add(R/f)
    for f in ('publish.py', 'build.py', 'cpu.py', 'host.py', 'request-loop-consumer.cc',
              'build-summary.json', 'run-check.py', 'run-models.py', 'run-e4.py', 'migrate-main.py',
              'plan.json', 'ready.json', 'runtime.json', 'reused-report-abi.json'): add(W/f)
    stage(W, 'compile'); stage(W, 'link')
    for target in ('cpu', 'host'):
        for f in ('plan.json', 'ready.json'): add(W/target/f)
        stage(W/target, 'compile'); stage(W/target, 'link'); run(W/target/'run1')
    add(W/'cpu/runtime.json'); add(W/'cpu/reused-report-abi.json')
    for f in ('prepare.py', 'compare.py', 'manifest.json', 'comparisons.json', 'tracehashes.json', 'process-summary.json'): add(C/f)
    for name in MODES:
        run(C/'runs'/name, 'stdout.json')
        run(B/'consumer-cases/runs2'/name, 'stdout.json')
    for f in ('alice.initial.ids', 'alice.suffix.ids', 'alice.schedule', 'bob.initial.ids',
              'bob.suffix.ids', 'bob.schedule', 'empty.ids', 'sessions.tsv', 'input-v2-correction.json'):
        add(B/'consumer-cases'/f)
    add(B/'cuda/ready.json'); add(B/'cuda/runtime.json'); add(B/'host-image-design.json')
    # Final E4 natural output paths are set from root's actual retained files.
    for suffix in ('process.json', 'stdout.json', 'stderr.log', 'comparison.json', 'comparison.facts.json',
                   'comparison.stdout.log', 'comparison.stderr.log'):
        add(W/'e4-cli'/('natural.'+suffix))
    for suffix in ('process.json', 'stdout.json', 'stderr.log'): add(B/'e4-cli'/('natural.'+suffix))
    original = R/'.scratch/inference-common-core-20261026/consumer-cases'
    add(original/'commands-cuda.json'); add(original/'compare.py')
    for f in ('sessions.tsv', 'A.schedule', 'B.schedule', 'C.schedule', 'D.schedule'): add(original/'natural'/f)
    for f in E4_IDS: add(original/'inputs'/f)
    model = read(C/'comparisons.json')
    builds = read(W/'build-summary.json')
    assert pin(read(W/'ready.json')['source']['path']) == read(W/'ready.json')['source']
    summary = dict(status='BOUNDED_REQUEST_LOOP_CORRECTNESS_RESULTS', baseline_commit=BASELINE,
        publication_head=subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=R, check=True, capture_output=True, text=True).stdout.strip(),
        sources=[pin(R/f) for f in SOURCES], builds=builds,
        common_core='RequestLoop owns bounded request identities/FIFO/turn scheduling and observed retirement. Qwen GenerationRequestAdapter owns model admission/rebuild/publication/native retirement; ordinary and MTP share this request owner.',
        host=dict(process=read(W/'host/run1/process.json'), result=(W/'host/run1/stdout.log').read_text(encoding='utf8'),
            passed_contract_groups=6, scope='Host owner contracts with explicit retirement/error test inputs, not proof of native-device completion or physical capacity release.'),
        tiny_CPU=dict(process=read(W/'cpu/run1/process.json'), result=read(W/'cpu/run1/stdout.log'),
            scope='Actual tiny untrained A/H64 Model and the same GenerationRequestAdapter: open-input pause/wake, two idle evictions/restores and finite mid-turn resume.',
            limits=['generation_boundary comparison covers its declared scalar fields and sampling cursor, not all target/draft KV, recurrent, hidden or checkpoint-alias bytes.',
                    'Final zero live versions is actual finite accounting, not a claim of process VRAM release or trained-model quality.']),
        original_Qwen35_2B=dict(processes=read(C/'process-summary.json'), comparisons=model,
            tracehashes=pin(C/'tracehashes.json'), scope='Cached original BF16 V2 335 roles, ordinary/K1, two sessions x three turns; two new candidates versus two reused observed WorkingState controls, no control rerun.',
            existing_recompute_fact=model['important_existing_fact']),
        tiny_CUDA_E4=dict(comparison=read(W/'e4-cli/natural.comparison.json'),
            scope='One existing natural generated-E4 schedule: four sessions, seven turns, mixed T and real R1/R2/R3 batching plus same-wave prefix isolation; reused WorkingState output, 85 explicit clock fields excluded, no teacher rerun.'),
        future_host_image_design=dict(receipt=pin(B/'host-image-design.json'), status='DESIGN_ONLY_NOT_IMPLEMENTED',
            scope='Complete byte-preserving host image/swap remains future work; current ledger replay restore is not this implementation.'),
        failures='No new build or consumer failure was observed in this batch. Historical V1 input rejection and MTP replay decision differences remain in the explicit retained references.',
        not_implemented=['Complete session host-image swap', 'Native indexed GDN path',
            'Eliminating existing KV reframe/export work', 'Execution overlap'],
        limits=['No speedup, performance ranking, cross-platform or broader model-quality conclusion.',
            'qwen_request_lifecycle_test.cc migration is source-only here; its individual lifecycle CLI modes were not separately built/run. The new real tiny case is compiled through the one CPU wrapper TU.',
            'Decision-level traces do not prove complete target/draft KV, GDN/conv, hidden payload or old-checkpoint alias immutability.',
            'Only explicit small sources/commands/logs/JSON/schedule/token text is archived; no EXE/OBJ/PDB/DLL/LIB/SDK/weight/fulltrace payload or dependency-directory walk.'])
    return files, summary


def main():
    assert sys.argv[1:] in (['plan'], ['publish'])
    files, summary = collect()
    manifest = [pin(p)|{'entry':name} for name,p in files.items()]
    estimate = sum(len(zlib.compress(p.read_bytes(), 9))+len(name.encode())*2+100 for name,p in files.items())+20000
    if sys.argv[1:] == ['plan']:
        result = dict(files=len(files), raw_bytes=sum(p.stat().st_size for p in files.values()), estimated_zip_bytes=estimate, manifest=manifest)
        (W/'publication-plan.json').write_bytes(encode(result))
        print(json.dumps({k:result[k] for k in ('files', 'raw_bytes', 'estimated_zip_bytes')})); return
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    DEST.parent.mkdir(parents=True, exist_ok=True)
    patch = subprocess.run(['git', 'diff', BASELINE, '--', *SOURCES], cwd=R, check=True, capture_output=True).stdout
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name,p in files.items(): out.write(p, name)
        out.writestr('manifest.json', encode(manifest)); out.writestr('changed-sources.txt', patch)
    summary['archive'] = pin(DEST.with_suffix('.zip'))
    with DEST.with_suffix('.json').open('xb') as out: out.write(encode(summary))
    print(json.dumps(dict(summary=pin(DEST.with_suffix('.json')), archive=summary['archive'], files=len(files))))


if __name__ == '__main__': main()
