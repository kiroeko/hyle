from pathlib import Path

root = Path(__file__).resolve().parents[2]
path = root / 'engine/models/qwen35/main.cc'
text = path.read_bytes().decode('utf-8')
assert '\r\n' not in text
text = text.replace('#include "../../inference/request_window.h"\n',
                    '#include "../../inference/request_window.h"\n#include "../../inference/request_loop.h"\n', 1)
anchor = 'void print_generation_rebuild(const GenerationRestoreStats &stats, bool draft_cache) {'
assert text.count(anchor) == 1
adapter = '''// Model-specific state and execution only. RequestLoop owns FIFO, idle
// selection and turn/key transitions; no native work is owned by this adapter.
template<class ExecuteWave>
struct GenerationRequestAdapter final {
  Model &model;
  cache::PrefixCache *prefix;
  std::span<GenerationRequest> requests;
  bool trace_states;
  std::vector<std::size_t> *evictions;
  ExecuteWave &execute;

  inference::RequestProgress &progress(inference::RequestKey key) const noexcept {
    return requests[key.slot].progress;
  }
  bool resident(inference::RequestKey key) const noexcept {
    return bool(requests[key.slot].session);
  }
  void admission_preflight(inference::RequestKey key) const {
    auto &request = requests[key.slot];
    preflight_generation_sampling(model, request);
    request.admission_start = Clock::now();
  }
  void admit(inference::RequestKey key, std::span<const inference::RequestKey>) const {
    auto &request = requests[key.slot];
    if (!request.session)
      restore_generation_session(model, request, prefix, trace_states, requests);
    if (request.progress.turn_index && !request.session)
      throw std::runtime_error("later generation turn requires its rebuilt complete head");
    if (!request.progress.turn_started()) {
      request.prompt = request.progress.begin_turn(*request.warm_inputs[request.progress.turn_index],
          request.progress.turn_index ? std::optional<std::int32_t>(request.session->head->next_id) : std::nullopt);
      request.turn_observations[request.progress.turn_index].output_begin = request.progress.turn_output_begin;
    }
  }
  void execute_wave(std::span<const inference::RequestKey> active) const { execute(active); }
  void publish_turn(inference::RequestKey key) const {
    publish_generation_completed(model, requests[key.slot], prefix);
  }
  inference::RetirementObservation retire(inference::RequestKey key, inference::RequestRetirement reason) const {
    auto &request = requests[key.slot];
    if (!request.session) return {true, {}};
    const auto retired = retire_generation_request(request);
    if (retired.retired) {
      request.session.reset();
      if (reason == inference::RequestRetirement::kEvicted) {
        ++request.idle_evictions;
        if (evictions) evictions->push_back(key.slot);
      }
    }
    return retired;
  }
};

'''
text = text.replace(anchor, adapter + anchor, 1)
old_prepare = '''  inference::RequestWindow window;
  window.prepare(requests.size(), model.cache_plan.resident_sessions);
  for (std::size_t index = 0; index < requests.size(); ++index)
    requests[index].request_key = window.enqueue(index);
'''
new_prepare = '''  inference::RequestLoop request_loop;
  request_loop.prepare(requests.size(), model.cache_plan.resident_sessions);
  for (std::size_t index = 0; index < requests.size(); ++index)
    requests[index].request_key = request_loop.enqueue(index);
'''
assert text.count(old_prepare) == 1
text = text.replace(old_prepare, new_prepare, 1)
begin = text.index('  while (completed != requests.size()) {')
wave_begin = text.index('    // Resolve every lookup/admission in this wave', begin)
wave_end = text.index('    for (std::size_t at = 0; at < window.active().size();) {', wave_begin)
loop_end = text.index('  const auto post_endpoint_seconds = ', wave_end)
wave = text[wave_begin:wave_end]
replacement = '  const auto execute_wave = [&](std::span<const inference::RequestKey> active) {\n' + wave + '''  };
  GenerationRequestAdapter adapter{model, prefix.get(), std::span(requests), trace_states, &evictions, execute_wave};
  while (completed != requests.size()) {
    const auto pumped = request_loop.pump_once(adapter);
    completed = cache::add(completed, pumped.completed);
    admitted = cache::add(admitted, pumped.admitted);
    if (pumped.waiting_retirement)
      throw std::runtime_error("generation request still retains an in-flight episode");
    if (!pumped.executed && completed != requests.size())
      throw std::runtime_error("generation admission has no runnable resident request");
  }
'''
text = text[:begin] + replacement + text[loop_end:]
path.write_bytes(text.encode('utf-8'))
print('Migrated actual natural ordinary/MTP request loop; retained model wave body byte-for-byte.')
