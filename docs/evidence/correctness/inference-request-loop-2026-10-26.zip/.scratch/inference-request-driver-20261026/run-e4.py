"""One actual natural E4 CUDA schedule; reuse the observed WorkingState control."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

work = Path(__file__).resolve().parent
root = work.parents[1]
old = root / '.scratch/inference-working-state-20261026'
source = root / '.scratch/inference-common-core-20261026/consumer-cases'
folder = work / 'e4-cli'
folder.mkdir()
ready = json.loads((work / 'ready.json').read_text())
runtime = json.loads(Path(ready['runtime']['path']).read_text())
image = ready['image']
assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
original = json.loads((source / 'commands-cuda.json').read_text())['natural']['candidate']
command = [image['path'], *original['argv'][1:]]
env = os.environ.copy()
env.update(runtime.get('configured_flags', {}))
env.update(PATH=str(Path(image['path']).parent) + ';' + runtime['PATH'],
           HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
start = time.perf_counter()
with (folder / 'natural.stdout.json').open('xb') as out, (folder / 'natural.stderr.log').open('xb') as err:
    child = subprocess.Popen(command, cwd=root, env=env, stdout=out, stderr=err,
                             creationflags=subprocess.CREATE_NO_WINDOW)
    print('natural native_pid', child.pid, flush=True)
    timeout = False
    try:
        code = child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        timeout = True
        child.kill()
        code = child.wait(timeout=10)
control = old / 'e4-cli/natural.stdout.json'
result = dict(pid=child.pid, exit=code, timeout=timeout, seconds=time.perf_counter() - start,
              command=command, baseline_stdout=str(control), baseline_commit='8e488136f', image=image)
(folder / 'natural.process.json').write_text(json.dumps(result, indent=2) + '\n')
assert code == 0 and not timeout, 'Preserve the actual failure'
compare = [os.sys.executable, '-B', str(source / 'compare.py'), 'natural', str(control),
           str(folder / 'natural.stdout.json'), '--backend', 'cuda', '--out', str(folder / 'natural.comparison.json')]
checked = subprocess.run(compare, cwd=root, capture_output=True, text=True)
(folder / 'natural.comparison.stdout.log').write_text(checked.stdout)
(folder / 'natural.comparison.stderr.log').write_text(checked.stderr)
print(json.dumps(result))
print(checked.stdout)
assert checked.returncode == 0, 'Preserve the actual comparison failure; no model retry'
