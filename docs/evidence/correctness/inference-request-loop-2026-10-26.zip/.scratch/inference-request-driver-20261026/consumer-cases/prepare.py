"""Prepare two candidate-only consumers against retained, observed controls.

No build, model, server, download or subprocess. Old controls and payloads are
referenced in place. Run once before the candidate is built; ready.json is the
authority for its eventual image hash, checked again by offline compare.py.
"""
from pathlib import Path
import copy
import hashlib
import json

D = Path(__file__).resolve().parent
W = D.parent
R = W.parents[1]
OLD = R / '.scratch/inference-working-state-20261026/consumer-cases'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest)


old = read(OLD / 'manifest2.json')
previous = read(OLD / 'comparisons.json')
traces = read(OLD / 'tracehashes.json')
cases, baseline_observed = [], []
for mode in ['ordinary', 'mtp-k1']:
    original = next(case for case in old['cases'] if case['id'] == mode + '-candidate')
    control = copy.deepcopy(original)
    control.update(id=mode + '-baseline', arm='baseline', execution='REUSE_EXISTING_OBSERVED_PROCESS_ONLY')
    process = read(control['process_record'])
    assert process['exit'] == 0 and not process['timeout']
    assert process['image']['sha256'] == '8eca64f2e961735fd90def860121962ae903e29b2206ebe2fac9b61c9d02cdcb'
    assert process['command'] == control['argv']
    facts = next(pair for pair in previous['pairs'] if pair['mode'] == mode)
    trace = next(pair for pair in traces['pairs'] if pair['mode'] == mode)
    control['observed'] = dict(pid=process['pid'], process=pin(control['process_record']),
        stdout=pin(control['stdout']), stderr=pin(control['stderr']),
        non_time_report_sha256=facts['normalized_report_sha256'],
        trace_inventory_sha256=trace['inventory_sha256'], trace_file_count=facts['trace_file_count'])
    baseline_observed.append(control['observed'])
    candidate = copy.deepcopy(original)
    output = D / 'runs' / (mode + '-candidate')
    candidate['image'] = dict(path=str(W / 'link/hyle.exe'), hash_authority=str(W / 'ready.json'))
    candidate['ready'] = dict(path=str(W / 'ready.json'), status='PENDING_BUILD_ROOT_VALIDATES_BEFORE_LAUNCH')
    candidate['runtime'] = dict(path=str(W / 'runtime.json'), hash_authority=str(W / 'ready.json'))
    candidate['argv'][0] = candidate['image']['path']
    candidate['argv'][candidate['argv'].index('--trace') + 1] = str(output / 'trace')
    candidate.update(stdout=str(output / 'stdout.json'), stderr=str(output / 'stderr.log'),
        process_record=str(output / 'process.json'), trace=str(output / 'trace'),
        execution='ROOT_MAY_LAUNCH_ONCE_AFTER_SUCCESSFUL_FROZEN_BUILD')
    candidate['environment']['PATH_prepend'] = str(W / 'link')
    candidate['environment']['runtime_PATH_from'] = str(W / 'runtime.json')
    # Only executable and fresh trace/output paths change. Inputs, seed,
    # schedules, options and the source V2 model identity remain byte-exact.
    assert candidate['argv'][1:-1] == original['argv'][1:-1]
    cases += [control, candidate]

manifest = dict(status='PREPARED_TWO_CANDIDATE_PROCESSES_NOT_RUN',
    purpose='RequestLoop + GenerationRequestAdapter migration; fixed mathematical and sampling work.',
    native_process_limit=2, reused_observed_baseline_processes=2,
    model_runs_by_this_agent=0, downloads=0, source_manifest=pin(OLD / 'manifest2.json'),
    baseline=old['candidate'], baseline_observed=baseline_observed,
    candidate=dict(path=str(W / 'link/hyle.exe'), ready_path=str(W / 'ready.json'),
        runtime_path=str(W / 'runtime.json'), image_pin_pending=True),
    input_source=old['input_source'], current_input_facts=old['current_input_facts'],
    physical_roles=old['physical_roles'], checkpoint=old['checkpoint'],
    fixed_files=old['fixed_files'],
    comparison=dict(complete_JSON='Exact recursive type/value/presence after ONLY seconds/*_seconds/*tokens_per_second removal; each removed path must also agree. No resource/path exclusions.',
        traces='Both actual full inventories independently hashed: expect 78 ordinary + 68 K1 files, all relative paths/bytes/SHA256 equal. No copied payload.',
        reference_comparisons=pin(OLD / 'comparisons.json'),
        reference_trace_inventory=pin(OLD / 'tracehashes.json'),
        original_V1_rejection=pin(OLD / 'input-v2-correction.json'),
        existing_MTP_decision_changes='Retain the three alice replay historical-vs-fresh changes exactly: episode1 3584->2997 twice; episode4 3269->9637 once. They are not hidden/excluded or required to become zero.'),
    cases=cases,
    execution_contract='Root alone launches the two candidate cases, sequentially, maximum90s each after validating ready/image/runtime closure. No baseline reruns, extra models, seed search or downloads.',
    limits=['No performance ranking or ordinary-to-MTP equality.',
        'Decision-level traces do not prove complete target/draft KV, GDN/conv, carry/prior bytes or old-checkpoint alias immutability.',
        'Same 2 sessions x3 turns,4 restores/evictions/pending flushes,18 outputs. K1 control covers6 double verifications with4 accepted drafts and2 rejected proposals; report any candidate mismatch without adding runs.'])
D.mkdir(parents=True, exist_ok=True)
with (D / 'manifest.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(manifest, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(pin(D / 'manifest.json')))
