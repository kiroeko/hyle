"""Prepared incremental recipe; root calls plan only after SOURCE_FROZEN.

python -B build.py plan
python -B build.py build
No default build, source/SDK copy, model or consumer execution.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-working-state-20261026/cuda'
P = R/'.scratch/inference-review-fixes-20261026'
BASELINE_COMMIT = '8e488136f'
spec = importlib.util.spec_from_file_location('retained_review_recipe', P/'build-before-final.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def check_report(record):
    b.exact(record['report'])
    b.exact(record['report_dependency_record'])
    rows = [row for row in b.read(record['report_dependency_record']['path'])
            if Path(row['path']).is_relative_to(R) and not Path(row['path']).is_relative_to(R/'.scratch')]
    for row in rows: b.exact(row)
    b.exact(record['execution_observation'])
    return len(rows)


def plan():
    assert not (W/'plan.json').exists(), 'Preserve each source-frozen attempt'
    ready = b.read(B/'ready.json')
    b.exact(ready['image']); b.exact(ready['runtime']); b.exact(ready['link_inputs'])
    inputs = b.read(ready['link_inputs']['path'])
    old = ready['object']  # Deleted by the recorded cleanup; replacement key only.
    assert len(inputs) == 222 and sum(b.key(x['path']) == b.key(old['path']) for x in inputs) == 1
    for row in inputs:
        if b.key(row['path']) != b.key(old['path']): b.exact(row)
    report_record = B.parent/'reused-report-abi.json'
    report = b.read(report_record)
    count = check_report(report)
    assert any(x == report['report'] for x in inputs)
    source = R/'engine/models/qwen35/main.cc'
    frozen = b.quoted_project_closure([source])
    b.save(W/'source-freeze.json', frozen)
    b.save(W/'reused-report-abi.json', dict(**report, checked_current_dependencies=count,
        note_current='Only Model TU changes; retained report object and all recorded project ABI dependencies match.'))
    b.save(W/'link-inputs-before.json', inputs)
    b.save(W/'plan.json', dict(status='SOURCE_FROZEN_NOT_BUILT_OR_RUN', baseline_commit=BASELINE_COMMIT,
        baseline_ready=b.pin(B/'ready.json'), baseline_image=ready['image'], runtime=ready['runtime'],
        source=b.pin(source), source_freeze=b.pin(W/'source-freeze.json'),
        recipe=b.pin(B/'compile/command.json'), link_recipe=b.pin(B/'link/command.json'),
        command=b.compile_command(B/'compile/command.json', source, W/'compile'),
        inputs=b.pin(W/'link-inputs-before.json'), replaced_object=old,
        cleanup_record=b.pin(B.parent/'cleanup-result.json'),
        reused_report_abi=b.pin(W/'reused-report-abi.json'), image_path=str(W/'link/hyle.exe'),
        unchanged_inputs=221, compiled_TUs=1,
        limits=['One canonical CUDA Model TU against the retained WorkingState closure; no SDK/native/Graph/provider/report rebuild.',
                'Deleted old Model object is used only to replace its link argument; it is not a dependency to restore.',
                'Build/link does not execute a host, Model or inference consumer; no numerical or performance claim.']))
    print('REQUEST_DRIVER_PLAN', json.dumps(b.pin(W/'plan.json')), flush=True)


def build():
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    unit = b.read(W/'plan.json')
    for field in ('baseline_ready', 'baseline_image', 'runtime', 'source', 'source_freeze', 'recipe',
                  'link_recipe', 'inputs', 'cleanup_record', 'reused_report_abi'):
        b.exact(unit[field])
    check_report(b.read(unit['reused_report_abi']['path']))
    frozen = b.read(unit['source_freeze']['path'])
    for row in frozen: b.exact(row)
    inputs = b.read(unit['inputs']['path'])
    for row in inputs:
        if b.key(row['path']) != b.key(unit['replaced_object']['path']): b.exact(row)
    h = b.helper()
    compiler = unit['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(unit['command'], env, W/'compile', timeout=120)
    dep = b.read(W/'compile/dependencies.json')['Data']
    actual = [b.pin(x) for x in dict.fromkeys([dep['Source'], *dep['Includes']])]
    by_key = {b.key(row['path']): row for row in frozen}
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
            assert b.key(path) in by_key and row['sha256'] == by_key[b.key(path)]['sha256'], str(path)
    for row in frozen: b.exact(row)
    b.save(W/'actual-dependencies.json', actual)
    obj = b.pin(W/'compile/unit.obj')
    command, replaced = [], 0
    for arg in b.read(unit['link_recipe']['path'])['command']:
        if b.key(arg) == b.key(unit['replaced_object']['path']): arg = obj['path']; replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+unit['image_path']
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(W/'link/hyle.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(W/'link/hyle.lib')
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    assert replaced == 1
    linked = h.execute(command, env, W/'link', timeout=120)
    final = [obj if b.key(x['path']) == b.key(unit['replaced_object']['path']) else x for x in inputs]
    for row in final: b.exact(row)
    b.save(W/'link-inputs.json', final)
    runtime = b.read(unit['runtime']['path'])
    b.exact(runtime['native'])
    alias = W/'link'/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = b.pin(alias)
    b.save(W/'runtime.json', runtime)
    b.save(W/'ready.json', dict(status='REQUEST_DRIVER_CUDA_BUILT_NOT_RUN',
        image=b.pin(unit['image_path']), runtime=b.pin(W/'runtime.json'), link_inputs=b.pin(W/'link-inputs.json'),
        source=unit['source'], source_freeze=unit['source_freeze'], actual_dependencies=b.pin(W/'actual-dependencies.json'),
        plan=b.pin(W/'plan.json'), baseline=unit['baseline_image'], object=obj, compile=compiled, link=linked,
        compiled_TUs=1, unchanged_inputs=221, SDK_native_provider_report_builds=0, model_runs=0,
        consumer_runs=0, limits=unit['limits']))
    print('REQUEST_DRIVER_READY', json.dumps(b.pin(W/'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    else: print('Prepared only. After root SOURCE_FROZEN: python -B '+str(__file__)+' plan | build')
