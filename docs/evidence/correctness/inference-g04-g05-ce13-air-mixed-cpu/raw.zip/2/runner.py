from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile,xml.etree.ElementTree as ET

BASE=Path('/Users/kiro/hyle-scratch/compute-unified');OUT=BASE/'ce13-air-cpu-mixed'
attempt=sys.argv[1];RUN=OUT/attempt;RUN.mkdir(exist_ok=False)
SOURCE=BASE/'source-c8874688';BUILD=BASE/'a-cpu-vulkan/selected-graph/static-sdk-build'
proof=json.loads((OUT/'reuse-inputs.json').read_text())
identity={k:subprocess.check_output(v,text=True).strip() for k,v in (
 ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version']))}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64' and '21.0.0' in identity['compiler']
cache=(BUILD/'CMakeCache.txt').read_text()
assert all(x in cache for x in ('HYLE_STATIC:BOOL=ON','HYLE_SANITIZER:STRING=off','CMAKE_BUILD_TYPE:STRING=Release','HYLE_COMPUTE_ROUTES:STRING=cpu;vulkan'))
assert next(s.split('=',1)[1] for s in cache.splitlines() if s.startswith('CMAKE_OSX_DEPLOYMENT_TARGET:'))=='14.4'
archive=BUILD/'bin/libggml-vulkan.a'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archive_sha256']
old_derived=Path(next(s.split('=',1)[1] for s in cache.splitlines() if s.startswith('ggml_SOURCE_DIR:STATIC=')))
for name,sha in proof['derived'].items():assert hashlib.sha256((old_derived/name).read_bytes()).hexdigest()==sha
members=subprocess.check_output(['ar','-t',str(archive)],text=True).splitlines()
assert len([s for s in members if not s.startswith('__.SYMDEF')])==152
with zipfile.ZipFile(OUT/f'source-{attempt}.zip') as package:
 inputs=json.loads(package.read('source-manifest.json'))
 for item in inputs:
  relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
  raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
  destination=SOURCE/relative
  if not destination.exists() or destination.read_bytes()!=raw:
   destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw)
for name,sha in proof['canonical'].items():assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==sha
record={'state':'RUNNING','identity':identity,'inputs':inputs,'reuse':proof,'archive_members':members,
 'scope':'CE12/CE13 actual mixed456 CPU public math/page/ragged/Direct/Graph only. No new GPU, full shipping SDK or P1 verdict.',
 'stages':[],'cumulative_seconds':0,'max_jobs':4}
def save():(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();(RUN/'runner.py').write_bytes(Path(__file__).read_bytes())
hook=RUN/'project.cmake';target='ce13_air_mixed_cpu'
hook.write_text('''if(PROJECT_NAME STREQUAL "hyle")
 set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
 add_subdirectory("/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6" ce13-mixed-gtest EXCLUDE_FROM_ALL)
 function(ce13_mixed_cpu)
  find_package(SPIRV-Headers CONFIG REQUIRED)
  add_library(ce13_reused_vulkan STATIC IMPORTED GLOBAL)
  set_property(TARGET ce13_reused_vulkan PROPERTY IMPORTED_LOCATION "@ARCHIVE@")
  foreach(property IN ITEMS INTERFACE_LINK_LIBRARIES INTERFACE_INCLUDE_DIRECTORIES INTERFACE_COMPILE_DEFINITIONS)
   get_target_property(original ggml-vulkan ${property})
   if(NOT original MATCHES "-NOTFOUND$")
    set_property(TARGET ce13_reused_vulkan PROPERTY ${property} "${original}")
   endif()
  endforeach()
  foreach(property IN ITEMS LINK_LIBRARIES INTERFACE_LINK_LIBRARIES)
   get_target_property(original ggml ${property})
   if(NOT original MATCHES "-NOTFOUND$")
    string(REPLACE "ggml-vulkan" "ce13_reused_vulkan" updated "${original}")
    set_property(TARGET ggml PROPERTY ${property} "${updated}")
    file(APPEND "@RUN@/reused-link-seam.txt" "ggml ${property}: ${original} -> ${updated}\\n")
   endif()
  endforeach()
  add_executable(@TARGET@ "@SOURCE@/tests/compute_provider_ggml/native_paged_test.cc" "@SOURCE@/tests/compute_provider_ggml/native_ragged_test.cc" "@SOURCE@/tests/compute_batch/encoded_page_common_consumer.cc")
  target_compile_features(@TARGET@ PRIVATE cxx_std_23)
  target_compile_options(@TARGET@ PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(@TARGET@ PRIVATE hyle_compute_route_cpu hyle_compute_batch hyle_graph_route_cpu hyle_graph_batch GTest::gtest_main)
  hyle_stage_runtime(@TARGET@)
 endfunction()
 cmake_language(DEFER CALL ce13_mixed_cpu)
endif()
'''.replace('@ARCHIVE@',str(archive)).replace('@RUN@',str(RUN)).replace('@SOURCE@',str(SOURCE)).replace('@TARGET@',target))
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
active=None
def failed(kind,error,traceback):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if active and active.poll() is None else 'TERMINAL_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed
def run(stage,args):
 global active
 log=RUN/f'{stage}.log';start=time.monotonic()
 with log.open('w') as stream:
  active=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':active.pid}));print(stage,active.pid,flush=True);code=active.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)});save()
 print(stage,code,elapsed,flush=True)
 if code:
  record.update(state='TERMINAL_FAIL');save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
run('configure',['/opt/homebrew/bin/cmake','-S',str(SOURCE),'-B',str(BUILD),'-DCMAKE_PROJECT_INCLUDE='+str(hook),'-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu;vulkan','-DHYLE_STATIC=ON','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF'])
cache=(BUILD/'CMakeCache.txt').read_text();derived=Path(next(s.split('=',1)[1] for s in cache.splitlines() if s.startswith('ggml_SOURCE_DIR:STATIC=')))
for name,sha in proof['derived'].items():assert hashlib.sha256((derived/name).read_bytes()).hexdigest()==sha,('reused native dependency changed',name)
assert hashlib.sha256((derived/'src/ggml-cpu/ops.cpp').read_bytes()).hexdigest()==proof['new_mixed_cpu_ops_sha256']
record['actual_derived']=str(derived);record['actual_cpu_ops_sha256']=proof['new_mixed_cpu_ops_sha256'];save()
manifest=RUN/'exact-build.ninja';manifest.write_bytes((BUILD/'build.ninja').read_bytes())
dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-f',str(manifest),'-n',target],env=env,text=True);(RUN/'dry-run.txt').write_text(dry)
assert 'Re-running CMake' not in dry and 'vulkan-shaders-gen' not in dry and 'ggml-vulkan.dir' not in dry,'unexpected native GPU work; inspect before compiling'
run('compile',['/opt/homebrew/bin/cmake','--build',str(BUILD),'--target',target,'--parallel','4'])
commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-t','compdb'],env=env,text=True))
selected=[r for r in commands if r['file'].endswith(('/native_batch.cc','/ggml_cpu_provider.cc','/ggml-cpu/ops.cpp'))]
assert selected and all('HYLE_TESTING' not in r['command'] and '-fsanitize=' not in r['command'] for r in selected)
(RUN/'actual-compile-commands.json').write_text(json.dumps(selected,indent=2)+'\n')
paths=[p/target for p in (BUILD/'bin',BUILD) if (p/target).is_file()];assert len(paths)==1
record['binary']={'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest()};save()
run('tests',[str(paths[0]),'--gtest_output=xml:'+str(RUN/'tests.xml')])
xml=ET.parse(RUN/'tests.xml').getroot()
assert int(xml.attrib['tests'])==22 and all(int(xml.attrib.get(k,0))==0 for k in ('failures','errors','disabled'))
record['tests']=22
assert hashlib.sha256(paths[0].read_bytes()).hexdigest()==record['binary']['sha256']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archive_sha256']
record.update(state='TERMINAL_PASS');save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
