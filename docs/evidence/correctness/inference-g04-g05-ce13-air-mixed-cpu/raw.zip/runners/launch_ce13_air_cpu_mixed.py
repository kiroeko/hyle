from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=sys.argv[1]
dependency=json.loads((BASE/'ce13-validation-job-3.json').read_text(encoding='utf-8'))
assert dependency['state']=='TERMINAL_PASS'
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha for name,sha in dependency['inputs'].items())
assert (ROOT/'evidence/correctness/inference-g04-g05-ce13-cpu-validation/receipt.json').is_file()
OUT=BASE/'ce13-air-cpu-mixed';OUT.mkdir(exist_ok=True)
record_path=BASE/f'ce13-air-cpu-mixed-job-{attempt}.json';assert not record_path.exists()
record={'state':'PREPARING','pid':os.getpid(),'attempt':attempt,'stages':[],
 'max_compile_jobs':4,'heavy_serial':True,'dependency':'ce13-validation-job-3.json',
 'product_commit':'42a4c7cdcc0822a7b162efe575909622a906de1d',
 'canonical_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
def save():record_path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()
archive=OUT/f'source-{attempt}.zip';assert not archive.exists()
paths=subprocess.check_output(['git','ls-files','--cached'],text=True).splitlines();inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for name in paths:
  if name.startswith(('evidence/','.scratch/','.git','docs/')):continue
  path=ROOT/name
  if not path.is_file():continue
  raw=path.read_bytes();inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()});package.writestr(name,raw)
 package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
record['source_archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();save()
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/ce13-air-cpu-mixed'
active=None
def run(stage,args):
 global active
 start=time.monotonic();log=OUT/f'{stage}-{attempt}.log'
 with log.open('wb') as stream:
  active=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',stage=stage,child_pid=active.pid,log=str(log));save()
  print(stage,active.pid,flush=True);code=active.wait()
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)});save()
 return code
try:
 assert run('mkdir',['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote])==0
 assert run('copy-source',['scp',str(archive),str(BASE/'ce13_air_cpu_mixed.py'),host+':'+remote+'/'])==0
 assert run('copy-proof',['scp',str(BASE/'ce13-air-mixed-reuse-inputs.json'),host+':'+remote+'/reuse-inputs.json'])==0
 code=run('remote-worker',['ssh','-o','BatchMode=yes',host,'python3',remote+'/ce13_air_cpu_mixed.py',attempt])
 fetch=run('fetch',['scp','-r',host+':'+remote+'/'+attempt,str(OUT)])
 result=OUT/attempt/'result.json'
 remote_state=json.loads(result.read_text(encoding='utf-8'))['state'] if result.is_file() else None
 record['remote_state']=remote_state;record['worker_exit_code']=code;record['fetch_exit_code']=fetch
 if remote_state=='TERMINAL_PASS' and code==0 and fetch==0:record['state']='TERMINAL_PASS'
 elif remote_state=='TERMINAL_FAIL':record['state']='TERMINAL_FAIL'
 else:record['state']='OBSERVER_ERROR_REMOTE_STATE_UNCONFIRMED'
 save();print(json.dumps({k:v for k,v in record.items() if k!='stages'}),flush=True)
 raise SystemExit(0 if record['state']=='TERMINAL_PASS' else 1)
except Exception as error:
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if active and active.poll() is None else 'LAUNCH_FAILURE_NO_NEW_WORKER',error=repr(error));save();raise
