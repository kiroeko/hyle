from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'ce13-air-cpu-mixed'
ordinary=json.loads((BASE/'ce13-validation-job-3.json').read_text(encoding='utf-8'))
job=json.loads((BASE/'ce13-air-cpu-mixed-job-3.json').read_text(encoding='utf-8'))
assert job['state']=='TERMINAL_PASS'
r=json.loads((OUT/'3/result.json').read_text(encoding='utf-8'));assert r['state']=='TERMINAL_PASS'
inputs={row['path']:row['sha256'] for row in r['inputs']}
assert all(inputs[name]==sha==hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name,sha in ordinary['inputs'].items())
xml=ET.parse(OUT/'3/tests.xml').getroot()
assert int(xml.attrib['tests'])==22 and all(int(xml.attrib.get(k,0))==0 for k in ('failures','errors','disabled'))
assert r['actual_cpu_ops_sha256']=='afd767b646b754106589ac83876935fcf56baaaf68e194438ba8e18f0f159def'
dry=(OUT/'3/dry-run.txt').read_text(encoding='utf-8')
assert all(term not in dry for term in ('vulkan-shaders-gen','ggml-vulkan.dir','Re-running CMake'))
attempts=[json.loads((OUT/str(i)/'result.json').read_text(encoding='utf-8')) for i in (1,2,3)]
assert [item['state'] for item in attempts]==['TERMINAL_FAIL','TERMINAL_FAIL','TERMINAL_PASS']
dest=ROOT/'evidence/correctness/inference-g04-g05-ce13-air-mixed-cpu';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for path in OUT.rglob('*'):
  if path.is_file() and path.suffix not in ('.a','.zip'):package.write(path,path.relative_to(OUT).as_posix())
 for path in BASE.glob('ce13-air-cpu-mixed-job-*.json'):package.write(path,path.name)
 for name in ('ce13_air_cpu_mixed.py','launch_ce13_air_cpu_mixed.py','seal_ce13_air_cpu_mixed.py','ce13-air-mixed-reuse-inputs.json'):
  package.write(BASE/name,'runners/'+name)
receipt={'kind':'G04_G05_CE13_ACTUAL_AIR_MIXED456_CPU_FINITE_QUALIFICATION',
 'verdict':'PASS_FINITE_CPU_SOURCE','product_candidate':'42a4c7cdcc0822a7b162efe575909622a906de1d',
 'canonical_snapshot':job['canonical_head'],'identity':r['identity'],'inputs':inputs,
 'tests':22,'binary':r['binary'],'actual_cpu_ops_sha256':r['actual_cpu_ops_sha256'],
 'reused_archive':r['reuse'],'archive_real_object_count':152,
 'attempts':[{'attempt':i,'state':item['state'],'stages':item['stages'],'error':item.get('error')} for i,item in enumerate(attempts,1)],
 'cumulative_measured_stage_seconds':sum(item['cumulative_seconds'] for item in attempts),
 'verification_seam':'One-way canonical snapshot; test-only imported identical native archive copy outside generated outputs. Product build files unchanged.',
 'limits':['Actual mixed456 CPU math/page/ragged/Direct/Graph only; no new GPU/full mixed SDK/P1 verdict',
 'Original configuration visibility FAIL and dry-plan rejection before compiling retained',
 'Archive copy matches authenticated producer bytes; historical external system dependency bytes not all rehashed',
 'CPU-only ordinary gates sealed separately; CE12 qualified P1 FAIL remains immutable'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('inputs','attempts','reused_archive')},ensure_ascii=False))
