"""Package six completed finite cases offline; never execute/retry native work."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
A = W.parent
R = Path('C:/public/project-hyle/hyle')
DEST = R / 'docs/evidence/correctness/inference-prepared-program-family-2026-10-28'
CASES = ('logits-cpu', 'logits-cuda', 'sampling-cpu', 'sampling-cuda', 'packed-cpu', 'packed-cuda')


def read(path): return json.loads(Path(path).read_bytes())
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def terminal(process):
    assert process['exit'] == 0 and process['state'] == 'TERMINAL' and process['timed_out'] is False, process


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Preserve completed evidence'
    plan = read(W / 'final-build-plan.json'); frozen = read(W / 'final-source-freeze.json')
    run_plan = read(W / 'run-plan.json'); ready = read(W / 'ready-tiny.json')
    assert plan['counts'] == dict(CXX=1, links=1, inputs=228, retained_SDK_weights=227, SDK_CXX=0, NVCC=0, downloads=0)
    assert set(run_plan['arms']) == set(CASES) and run_plan['native_processes'] == 6 and run_plan['automatic_retries'] == 0
    for row in (frozen['helper'], frozen['expected'], frozen['dependencies'], run_plan['script'], run_plan['fixture'], run_plan['runtime']): exact(row)
    for row in run_plan['parsers'].values(): exact(row)
    compiled = read(W / 'compile/tiny/compiled.json')
    cxx = read(W / 'logs/tiny/process.json'); link = read(W / 'links/tiny/process.json')
    terminal(cxx); terminal(link)
    assert compiled == ready['compiled'] and compiled['process'] == cxx and ready['process'] == link
    for key in ('command', 'dependencies', 'actual_dependencies'): exact(compiled[key])
    for key in ('inputs', 'recipe', 'runtime', 'source_freeze'): exact(ready[key])
    base = read(plan['inputs']['path']); actual = read(ready['inputs']['path'])
    assert len(base) == len(actual) == 228
    assert [(a, b) for a, b in zip(base, actual) if a != b] == [(plan['original_object'], compiled['object'])]
    archive = {}
    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert name not in archive and path.suffix.lower() not in ('.obj', '.exe', '.dll', '.lib', '.pdb', '.bf16', '.f32', '.bin', '.safetensors', '.gguf')
        archive[name] = path.read_bytes()
    for name in ('build.py', 'run.py', 'package.py', 'run-plan.json', 'final-build-plan.json', 'final-source-freeze.json',
                 'expected-sources.json', 'frozen-project-dependencies.json', 'retained-input-stats.json', 'runtime.json',
                 'inputs-tiny.json', 'ready-tiny.json', 'recipes/tiny.json', 'link-recipes/tiny.json',
                 'compile/tiny/compiled.json', 'compile/tiny/dependencies.json', 'compile/tiny/actual-dependencies.json'):
        add(W / name)
    archive['identity/base-link-inputs.json'] = encoded(base)
    archive['identity/fixture.json'] = encoded(dict(manifest=run_plan['fixture'], fixture_payload_included=False,
        scope=run_plan['scope']))
    for key in ('logs', 'links'):
        for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(W / key / 'tiny' / name)
    sources = []
    for row in frozen['snapshots']:
        exact(row['original']); exact(row['snapshot'])
        relative = Path(row['original']['path']).relative_to(R).as_posix()
        add(row['snapshot']['path'], 'source/' + relative)
        sources.append(dict(path=relative, identity=row['original'], compiled_through_Tiny=True))
    add(A / 'changes.patch', 'source/changes.patch')
    add(A / 'final-source-freeze.json', 'source/product-freeze.json')
    # The existing output-facts contract is the only directly required new
    # header dependency included as body; remaining includes retain SHA lists.
    output_header = R / 'engine/inference/prepared_output.h'
    add(output_header, 'source/engine/inference/prepared_output.h')
    prefix = R / 'tests/tools/qwen_mtp_prefix_value_probe.cc'
    prefix_lines = [(n, line.strip()) for n, line in enumerate(prefix.read_text(encoding='utf-8-sig').splitlines(), 1)
                    if 'family->programs.size()' in line or 'family->programs.child(variant).compiled.report' in line]
    assert len(prefix_lines) == 2
    add(prefix, 'source/tests/tools/qwen_mtp_prefix_value_probe.cc')
    cases = []
    for name in CASES:
        directory = W / 'runs' / name
        summary = read(directory / 'summary.json'); process = read(directory / 'process.json')
        command = read(directory / 'command.json'); as_run = read(directory / 'as-run.json')
        terminal(process)
        assert summary['status'] == 'PASS' and summary['name'] == name and summary['process'] == process == as_run['process']
        assert summary['quality_claim'] is False and summary['performance_claim'] is False
        exact(summary['report']); exact(summary['source_freeze']); exact(as_run['ready']); exact(as_run['fixture'])
        arm = run_plan['arms'][name]
        assert command['command'] == [ready['image']['path'], '--' + arm['backend'],
            str(Path(run_plan['fixture']['path']).parent), arm['flag']]
        report = read(summary['report']['path'])
        if name.startswith('packed'):
            assert report['gdn_state_absolute_budget'] == 0.000003
            assert 0 < summary['maximum_GDN_absolute_difference'] <= report['gdn_state_absolute_budget']
        else:
            assert summary['maximum_GDN_absolute_difference'] == 0
            assert summary['payloads_byte_equal_checks'] == summary['state_checks']
        cases.append(dict(name=name, backend=summary['backend'], process=process, report=summary['report'],
            state_checks=summary['state_checks'], byte_equal_state_checks=summary['payloads_byte_equal_checks'],
            maximum_GDN_absolute_difference=summary['maximum_GDN_absolute_difference']))
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'as-run.json', 'report.json', 'summary.json'):
            add(directory / filename)
    assert sum(c['state_checks'] for c in cases) == 68 and sum(c['byte_equal_state_checks'] for c in cases) == 54
    assert len({(c['process']['pid'], c['process']['started']) for c in cases}) == 6
    for name, row in run_plan['parsers'].items(): add(row['path'], 'helpers/original-' + name + '-parser.py')
    add(plan['original_driver']['path'], 'helpers/original-windows-driver.py')
    manifest = encoded(dict(members=[dict(name=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(archive.items())],
                            self_hash='External JSON archive.manifest_sha256'))
    archive['MANIFEST.json'] = manifest
    outzip, outjson = DEST.with_suffix('.zip'), DEST.with_suffix('.json')
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(archive.items()): z.writestr(name, raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, raw in archive.items(): assert sha(z.read(name)) == sha(raw), name
    result = dict(schema='hyle.correctness.prepared-program-family.v1', date='2026-10-28',
        status='PASS_SIX_FINITE_PREPARED_PROGRAM_FAMILY_CONSUMERS',
        scope='Existing synthetic Tiny CPU/CUDA logits, stochastic sampling and MTP packed-prefill consumers on current shared ON SDK.',
        change='Share cold finite-exact executable/report selection and prepared output facts in PreparedProgramFamily across ordinary/NextN/prefix/frontier preparation.',
        counts=dict(CXX=1, links=1, native_processes=6, CPU=3, CUDA=3, SDK_CXX=0, NVCC=0, downloads=0, native_retries=0),
        build=dict(compile=cxx, link=link, image=ready['image'], compiled=compiled, inputs=ready['inputs'],
            input_count=228, retained_SDK_weights=227, changed_object=compiled['object'], runtime=ready['runtime']),
        cases=cases, numerical=dict(state_checks=68, payload_byte_equal_checks=54, non_byte_equal_checks=14,
            original_packed_GDN_absolute_budget=0.000003,
            maximum_GDN_absolute_difference=max(c['maximum_GDN_absolute_difference'] for c in cases),
            explanation='Logits/sampling54 checks are full-payload byte-equal. Packed-prefill14 checks retain only newly computed F32 GDN differences within the original3e-6 budget, maximum9.31323e-10. Do not call all68 byte-equal.',
            new_tolerance=False, trained_model_quality_claim=False),
        sources=sources, product_patch=pin(A / 'changes.patch'),
        prefix_probe=dict(source=pin(prefix), mechanically_adjusted_lines=prefix_lines, compiled=False, native_executed=False,
            scope='Two direct family-inspection adapters only; static source preservation, no execution coverage claim.'),
        architecture_limits=['Finite-exact parent Graph handles remain retained in each PreparedProgramFamily, including one-child auxiliary programs. Selection/output metadata are shared; this is not a new native executor, Invocation, pool or resource retirement mechanism.',
            'Model-specific shape/admission/eviction and state_graph specializations remain in Model. This slice does not complete extraction of the whole execution engine.',
            'Existing ProgramCarrier/ProgramIo/Queue/completion/ownership and retirement contracts are reused; this finite evidence does not prove every unrun backend or feature combination.'],
        fixture=dict(manifest=run_plan['fixture'], scope=run_plan['scope'], payload_in_archive=False),
        validation_limits=['Synthetic untrained GA/H64/V64/C16 fixture; no trained-model language quality or full-model numerical claim.',
            'No performance window or speedup measured in this slice. Existing timing records are not reused as samples.',
            'Prefix-value probe two-line adapter was not compiled or run. No broad platform matrix or entire-architecture completion claim.',
            'Archives contain necessary source/diff, dependency identities, actual recipes and six raw process reports; no SDK, executable, object, model or tensor body.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', all_member_SHA256='PASS'))
    with outjson.open('xb') as stream: stream.write(encoded(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', all_member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as stream: stream.write(encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
