"""Six existing finite consumers. Root runs explicitly; parser repair is offline only."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
b=module('prepared_family_build',W/'build.py');t=b.t;R=b.R
FIXTURE=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
PARSERS={'logits':R/'.scratch/inference-mtp-logits-20261028/refinement/run.py',
         'sampling':R/'.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py',
         'packed':R/'.scratch/inference-execution-preparation-20261028/parse.py'}
ARMS={'logits-cpu':('cpu','logits','--mtp-logits'),'logits-cuda':('cuda','logits','--mtp-logits'),
      'sampling-cpu':('cpu','sampling','--mtp-sampling'),'sampling-cuda':('cuda','sampling','--mtp-sampling'),
      'packed-cpu':('cpu','packed','--mtp-packed-prefill'),'packed-cuda':('cuda','packed','--mtp-packed-prefill')}


def prepare():
    b.plan()
    t.save(W/'run-plan.json',dict(status='PLANNED_NOT_RUN',script=t.pin(__file__),fixture=t.pin(FIXTURE/'weights.tsv'),
        parsers={name:t.pin(path) for name,path in PARSERS.items()},runtime=t.pin(W/'runtime.json'),
        arms={name:dict(backend=backend,parser=kind,flag=flag,output=str(W/'runs'/name)) for name,(backend,kind,flag) in ARMS.items()},
        order=list(ARMS),native_processes=6,CPU=3,CUDA=3,automatic_retries=0,
        scope='Original cached synthetic GA/H64/V64/C16 fixture, unchanged finite math/state contracts. One shared new Tiny image, no extra SDK/weights/NVCC build, download, performance or platform matrix.'))
    print('RUN PLAN ONLY6: logits/sampling/MTP-packed CPU/CUDA')


def parse(name):
    backend,kind,_=ARMS[name];out=W/'runs'/name;process=t.read(out/'process.json')
    assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out'],process
    reports=[json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    parser=module('retained_prepared_family_'+kind,PARSERS[kind])
    if kind=='logits':
        actual=parser.modifiers_report(reports,backend);checks=actual['state_checks']
    elif kind=='sampling':
        actual=parser.sampler_reports(reports,backend);checks=actual['manual']['state_checks']
    else:
        assert len(reports)==1
        actual=reports[0];parser.check_report(actual,backend,'mtp-packed')
        checks=parser.state_rows(actual,'mtp-packed')
    t.save(out/'report.json',actual)
    t.save(out/'summary.json',dict(status='PASS',name=name,backend=backend,process=process,report=t.pin(out/'report.json'),
        state_checks=len(checks),payloads_byte_equal_checks=sum(row['payloads_byte_equal'] for row in checks),
        maximum_GDN_absolute_difference=max((delta['maximum_absolute'] for row in checks for delta in row['differences']),default=0),
        source_freeze=t.pin(W/'final-source-freeze.json'),quality_claim=False,performance_claim=False))
    print('PASS',name,'PID',process['pid'],'state checks',len(checks))


def run(name):
    backend,_,flag=ARMS[name];b.validate();plan=t.read(W/'run-plan.json')
    for key in ('script','fixture','runtime'):t.exact(plan[key])
    for row in plan['parsers'].values():t.exact(row)
    ready=t.read(W/'ready-tiny.json');t.exact(ready['image']);t.exact(ready['inputs'])
    runtime=t.read(ready['runtime']['path']);native=runtime['native']
    assert(W/'bin'/Path(native['path']).name).samefile(native['path'])
    out=W/'runs'/name;assert not out.exists(),'Preserve attempt; successful processes can only be parsed offline'
    process=t.execute([ready['image']['path'],'--'+backend,str(FIXTURE),flag],out,300)
    t.save(out/'as-run.json',dict(ready=t.pin(W/'ready-tiny.json'),inputs=ready['inputs'],fixture=plan['fixture'],
        source_freeze=ready['source_freeze'],runtime=ready['runtime'],run_plan=t.pin(W/'run-plan.json'),process=process))
    parse(name)


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='run':run(sys.argv[2])
    elif action in ('parse','parse-only'):parse(sys.argv[2])
    else:raise ValueError(action)
