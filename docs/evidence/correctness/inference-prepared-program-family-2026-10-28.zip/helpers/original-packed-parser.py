"""Offline parse of seven existing preparation cases; never execute/retry."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
PREVIOUS = W.parent / 'inference-execution-episode-20261028/parse.py'
spec = importlib.util.spec_from_file_location('previous_finite_episode_parser', PREVIOUS)
previous = importlib.util.module_from_spec(spec); spec.loader.exec_module(previous)
CASES = {
    'ragged-cpu': ('cpu', 'ragged', '--ragged-prefill'),
    'ragged-cuda': ('cuda', 'ragged', '--ragged-prefill'),
    'mtp-packed-cpu': ('cpu', 'mtp-packed', '--mtp-packed-prefill'),
    'mtp-packed-cuda': ('cuda', 'mtp-packed', '--mtp-packed-prefill'),
    'batch-state-cpu': ('cpu', 'batch-state', '--mtp-batch-state'),
    'batch-state-cuda': ('cuda', 'batch-state', '--mtp-batch-state'),
    'submission-relay-cuda': ('cuda', 'submission-relay', '--relay'),
}


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def state_rows(report, kind):
    if kind == 'ragged':
        return [row for batch in report['batches'] for row in batch['members']] + [report['peer_decode']]
    if kind == 'mtp-packed':
        return [step['state'] for step in report['steps']]
    return []


def check_report(report, backend, kind):
    if kind in ['batch-state', 'submission-relay']:
        return previous.check_report(report, backend, kind)
    assert report['backend'] == backend and report['status'] == 'PASS'
    assert report['synthetic_untrained'] is True and report['performance_claim'] is False
    assert report['final_versions'] == report['final_images'] == report['final_native_episodes'] == 0
    assert report['old_checkpoints_byte_unchanged'] is True and report['rng_and_epochs_equal'] is True
    assert report['numerically_equivalent'] is True and report['gdn_state_absolute_budget'] == 0.000003
    previous.finite(report)
    if kind == 'ragged':
        assert report['mode'] == 'ragged_prefill' and report['cold_rows_per_member'] == 8 and report['width'] == 2
        assert (report['actual_prefill_rows'], report['physical_prefill_rows'], report['committed_prefill_rows']) == (22, 64, 21)
        assert report['cancelled_prefill_rows'] == report['peer_decode_rows'] == 1
        assert len(report['batches']) == 4 and all(len(batch['members']) == 2 for batch in report['batches'])
        assert report['batches'][0]['state_only'] is True
        assert report['batches'][-1]['member_cancelled'] is True and report['batches'][-1]['retirement_deferred'] is True
    else:
        assert kind == 'mtp-packed' and report['mode'] == 'mtp_packed_prefill'
        assert report['target_capacity'] == 4 and report['lag1_draft_capacity'] == 5
        assert len(report['steps']) == 7 and report['controlled_verify_width'] == 3
        assert report['controlled_accepted_rows'] == report['discarded_target_rows'] == 2
        assert report['final_length'] == report['final_frontier'] == 16 and report['final_rng_draws'] == 5
        assert report['natural_acceptance_claim'] is False
    rows = state_rows(report, kind)
    assert report['payloads_byte_equal'] == all(row['payloads_byte_equal'] for row in rows)
    for row in rows:
        assert row['boundary_equal'] is True and row['numerically_equivalent'] is True
        assert row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for difference in row['differences']:
            # Existing HostPayloadRole::kGdnState is 3. Only newly computed F32
            # GDN uses the original independent component-oracle absolute bound.
            assert difference['role'] == 3 and difference['nonfinite_differences'] == 0
            assert 0 <= difference['maximum_absolute'] <= report['gdn_state_absolute_budget']


def main():
    cases = []; comparisons = []
    for name, (backend, kind, option) in CASES.items():
        directory = W / 'runs' / name
        process = read(directory / 'process.json'); command = read(directory / 'command.json')
        assert process['exit'] == 0 and process['state'] == 'TERMINAL' and not process['timed_out'], name
        assert '--' + backend in command['command'] and option in command['command'], name
        reports = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert len(reports) == 1, (name, len(reports))
        check_report(reports[0], backend, kind); comparisons.extend(state_rows(reports[0], kind))
        cases.append(dict(name=name, status='PASS', process=process, command=command,
                          report=reports[0], evidence=[pin(directory / f) for f in ['command.json', 'process.json', 'stdout.log', 'stderr.log']]))
    assert len({row['process']['pid'] for row in cases}) == 7 and len(comparisons) == 32
    result = dict(status='PASS_SEVEN_FINITE_PREPARATION_CASES', native_processes=7, native_retries=0,
        state_comparisons=len(comparisons), byte_exact_state_comparisons=sum(row['payloads_byte_equal'] for row in comparisons),
        maximum_gdn_absolute_difference=max((item['maximum_absolute'] for row in comparisons for item in row['differences']), default=0),
        original_gdn_absolute_budget=0.000003,
        note='Only newly computed F32 GDN differences use the unchanged component-oracle bound; all other payloads, old snapshots, boundaries and RNG remain exact. No performance, quality, full matrix or unknown-retirement claim.',
        parser=pin(Path(__file__)), reused_parser=pin(PREVIOUS), cases=cases)
    (W / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['status', 'native_processes', 'state_comparisons', 'byte_exact_state_comparisons', 'maximum_gdn_absolute_difference']}))


if __name__ == '__main__':
    main()
