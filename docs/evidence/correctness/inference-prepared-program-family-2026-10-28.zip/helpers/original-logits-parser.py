"""Four explicit single-use functional processes; no build or automatic retry."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('mtp_logits_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
ARMS = {'mods-cpu': ('cpu', '--mtp-logits'), 'mods-cuda': ('cuda', '--mtp-logits'),
        'sampler-cpu': ('cpu', '--mtp-sampling'), 'preflight-cpu': ('cpu', '--logits-preflight')}
SAMPLER_PARSER = R / '.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py'


def prepare():
    b.b.prepared()  # The existing preparation is inspected, never repeated.
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', fixture_manifest=t.pin(FIXTURE / 'weights.tsv'),
        arms={name: dict(backend=backend, flag=flag, output=str(W / 'runs' / name))
              for name, (backend, flag) in ARMS.items()}, order=list(ARMS),
        CPU_processes=3, CUDA_processes=1, actual_processes_planned=4,
        models_per_process={'mods-cpu': 1, 'mods-cuda': 1, 'sampler-cpu': 2, 'preflight-cpu': 1},
        modifiers_models_are_not_overlapped=True, source_fixture='Existing cached GA/H64/V64/C16; no new payload/download',
        retained_sampler_parser=t.pin(SAMPLER_PARSER), parser=t.pin(W / 'run.py'),
        no_extra_build=True, no_SDK_copy=True, no_download=True))
    print('RUN PLAN PREPARED ONLY: mods CPU/CUDA, sampler CPU, preflight CPU; 4 processes')


def modifiers_report(reports, backend):
    assert len(reports) == 1, len(reports)
    report = reports[0]
    assert report['status'] == 'PASS' and report['case'] == 'mtp-logits-modifiers' and report['backend'] == backend
    for field in ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
                  'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage',
                  'prefix_frontier_numeric_failure', 'new_prefix_policy_payload', 'strict_modifier_replay_rejected',
                  'historical_StateOnly_rebuild', 'known_key_metadata_zero_native', 'same_key_retry', 'synthetic_untrained'):
        assert report[field] is True, field
    assert (report['models'], report['configurations'], report['finite_math_branches'],
            report['numeric_q_failures'], report['final_versions']) == (1, 2, 2, 2, 0)
    assert report['quality_claim'] is False and report['performance_claim'] is False
    checks = report['state_checks']
    assert len(checks) == 10, len(checks)
    assert all(x['boundary_equal'] and x['numerically_equivalent'] for x in checks)
    # GDN has the inherited finite 3e-6 oracle; every other initialized payload
    # role is exact. Preserve actual byte equality separately from that policy.
    for check in checks:
        for part in check['differences']:
            assert part['role'] == 3 and part['maximum_absolute'] <= 3e-6 and part['nonfinite_differences'] == 0, part
    return report


def preflight_report(reports):
    assert len(reports) == 1
    report = reports[0]
    assert report['status'] == 'PASS' and report['case'] == 'logits-preflight' and report['backend'] == 'cpu'
    for field in ('typed_invalid_argument', 'original_key', 'complete_state_unchanged',
                  'all_ledger_records_unchanged', 'old_checkpoints_unchanged', 'same_key_peer_continued'):
        assert report[field] is True, field
    assert (report['requests'], report['valid_prefill_submissions'], report['preflight_submissions'],
            report['peer_decode_submissions'], report['batch_position'], report['key_slot'], report['final_versions']) == (2, 1, 0, 1, 0, 1, 0)
    assert report['allfalse_numeric_retested'] is False and report['quality_claim'] is False and report['performance_claim'] is False
    return report


def parse(arm):
    backend, flag = ARMS[arm]; out = W / 'runs' / arm
    process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    if flag == '--mtp-logits':
        actual = modifiers_report(reports, backend)
    elif flag == '--logits-preflight':
        actual = preflight_report(reports)
    else:
        spec = importlib.util.spec_from_file_location('retained_sampling_parser', SAMPLER_PARSER)
        old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
        actual = old.sampler_reports(reports, backend)  # Parser only; never old image/ready/run.
    t.save(out / 'report.json', actual)
    t.save(out / 'summary.json', dict(status='PASS', arm=arm, backend=backend, process=process,
        report=t.pin(out / 'report.json'), source_freeze=t.pin(W / 'source-freeze.json'),
        quality_claim=False, performance_claim=False))
    print('PASS', arm, 'PID', process['pid'])


def run(arm):
    backend, flag = ARMS[arm]
    b.validate(); plan = t.read(W / 'run-plan.json')
    for field in ('fixture_manifest', 'retained_sampler_parser', 'parser'): t.exact(plan[field])
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image']); t.exact(ready['inputs'])
    runtime = t.read(W / 'runtime-plan.json'); t.exact(runtime['native'])
    original = Path(runtime['native']['path']); alias = W / 'bin' / original.name
    if not alias.exists(): os.link(original, alias)
    assert os.path.samefile(original, alias), 'Keep the existing CPU DLL as a same-file hardlink'
    if not (W / 'runtime-actual.json').exists():
        t.save(W / 'runtime-actual.json', dict(source=runtime['native'], alias=str(alias), same_file=True))
    out = W / 'runs' / arm
    assert not out.exists(), 'Process output exists; parse offline instead of rerunning'
    process = t.execute([ready['image']['path'], '--' + backend, str(FIXTURE), flag], out, 300)
    t.save(out / 'as-run.json', dict(ready=t.pin(W / 'ready-tiny.json'), image=ready['image'], inputs=ready['inputs'],
        source_freeze=ready['source_freeze'], fixture=plan['fixture_manifest'], parser=plan['parser'],
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime-actual.json'), process=process))
    parse(arm)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
