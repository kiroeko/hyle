"""Actual bounded GNU14 CXX/link/run, no SDK rebuild or device execution."""
import concurrent.futures, hashlib, json, os, pathlib, re, shlex, subprocess, sys, threading, time

ROOT = pathlib.Path('/root/hyle-scratch/compute-unified/linux-ct-packed-linear')
LOCAL = pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/ct-packed-linear-cpu/linux')
LOCK = threading.Lock()
def read(p): return json.loads(p.read_text())
def identity(p):
    p=pathlib.Path(p)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
def save(n,x):
    data=json.dumps(x,indent=2)+'\n'
    for base in [ROOT,LOCAL]:
        p=base/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
def invoke(tag,command,env=None):
    start=time.monotonic();out=ROOT/'logs'/f'{tag}.stdout.log';err=ROOT/'logs'/f'{tag}.stderr.log'
    with out.open('wb') as o,err.open('wb') as e:
        q=subprocess.run(command,cwd=ROOT,stdout=o,stderr=e,env=env)
    r={'tag':tag,'command':command,'exit_code':q.returncode,'seconds':time.monotonic()-start,
       'stdout':identity(out),'stderr':identity(err)}
    for p in [out,err]:(LOCAL/'logs'/p.name).write_bytes(p.read_bytes())
    return r

def compile_all():
    plan=read(ROOT/'compile-plan.json')['entries']
    results=read(ROOT/'compile-results.json') if (ROOT/'compile-results.json').exists() else []
    good={r['source'] for r in results if r['exit_code']==0}
    if len(sys.argv)>2:good.discard(sys.argv[2])
    def one(pair):
        index,row=pair;source=ROOT/'source'/row['source'];before=identity(source)
        attempt=1+sum(r['source']==row['source'] for r in results)
        r=invoke(f'cxx-{index:02d}-attempt{attempt}-{pathlib.PurePosixPath(row["source"]).name}',row['command'])
        r.update(source=row['source'],kind=row['kind'],source_before=before,source_after=identity(source))
        if r['exit_code']==0:
            r['object']=identity(row['object']);dep=pathlib.Path(row['object']+'.d');r['depfile']=identity(dep)
            tokens=shlex.split(dep.read_text().replace('\\\n',' ').split(':',1)[1])
            r['project_dependencies']=[identity(p) for p in sorted(set(tokens)) if p.startswith(str(ROOT/'source')+'/')]
            r['other_dependencies']=[identity(p) for p in sorted(set(tokens)) if not p.startswith(str(ROOT/'source')+'/')]
            (LOCAL/'deps'/dep.name).write_bytes(dep.read_bytes())
        with LOCK:
            results.append(r);save('compile-results.json',results)
            print('CXX',index,r['exit_code'],row['source'],round(r['seconds'],2),flush=True)
            if r['exit_code']: print(pathlib.Path(r['stderr']['path']).read_text()[-10000:],flush=True)
        return r['exit_code']
    for n in ['logs','deps']:(LOCAL/n).mkdir(exist_ok=True)
    for kind in ['product','test']:
        pending=[(i,r) for i,r in enumerate(plan) if r['source'] not in good and r['kind']==kind]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            exits=list(pool.map(one,pending))
        if any(exits): raise SystemExit(1)

def link():
    results=read(ROOT/'compile-results.json');latest={r['source']:r for r in results if r['exit_code']==0}
    plan=read(ROOT/'compile-plan.json')['entries'];assert all(r['source'] in latest for r in plan)
    reuse=read(ROOT/'reuse-plan.json')
    retained=[]
    for r in reuse['retained']:
        got=identity(r['path'])
        if 'sha256' in r:assert got['sha256']==r['sha256'] and got['bytes']==r['bytes'],r
        retained.append(got)
    current=[latest[r['source']]['object'] for r in plan]
    for r in current:assert identity(r['path'])==r
    libraries=[]
    for r in reuse['libraries']+reuse['runtime']:
        got=identity(r['path']);assert got==r,(got,r);libraries.append(got)
    runtime=[r['path'] for r in reuse['runtime']]
    dirs=list(dict.fromkeys(str(pathlib.PurePosixPath(p).parent) for p in runtime))
    dirs.append('/root/hyle-scratch/compute-unified/linux-current-graph/native/avx2')
    cmd=['/usr/bin/g++-14','-O3','-DNDEBUG','-pthread','-Wl,--disable-new-dtags',
         '-Wl,-rpath,'+':'.join(dirs),*[r['path'] for r in current+retained],
         '-Wl,--start-group',*[r['path'] for r in libraries if r['path'].endswith('.a')],
         '-Wl,--end-group',*runtime,'-ldl','-lm',
         '-Wl,-Map,'+str(ROOT/'ct-cpu.map'),'-o',str(ROOT/'ct-cpu')]
    save('link-plan.json',{'command':cmd,'new_objects':current,'retained_objects':retained,'libraries':libraries})
    attempt=1
    while (ROOT/'logs'/f'link-{attempt:02d}.stdout.log').exists():attempt+=1
    r=invoke(f'link-{attempt:02d}',cmd);save('link-result.json',r)
    print('LINK',r['exit_code'],round(r['seconds'],2),flush=True)
    if r['exit_code']:
        print(pathlib.Path(r['stderr']['path']).read_text()[-12000:],flush=True);raise SystemExit(r['exit_code'])
    maptext=(ROOT/'ct-cpu.map').read_text();(LOCAL/'ct-cpu.map').write_text(maptext)
    members=sorted(set(re.findall(r'(\S+\.a)\(([^\n)]+)\)',maptext)))
    bad=[r for r in members if '/libhyle_' in r[0] and not (r[0].endswith('/libhyle_simd.a') or r[0].endswith('/libhyle_container.a') and 'container_bitset' in r[1])]
    assert not bad,bad
    save('image.json',{'image':identity(ROOT/'ct-cpu'),'map':identity(ROOT/'ct-cpu.map'),
                       'archive_members':members,'old_hyle_host_members':bad})

def run():
    image=read(ROOT/'image.json')['image'];assert identity(image['path'])==image
    filt=('NativeCtPackedLinear.*:CpuCtPackedLinear.*:'
          'CpuDefaultContext.MatureDefaultsHavePolicyWithoutModelOrHardwareProfile:'
          'CpuDefaultContext.OneGgmlInstanceServesOrdinaryAndFusedGraphRoutes:'
          'CpuDefaultContext.MatMulNeverFallsBackToLowerAccumulationPrecision:'
          'CpuDefaultContext.StableActivationDefaultUsesOriginalAtenProgram')
    reuse=read(ROOT/'reuse-plan.json');env=os.environ.copy()
    dirs=list(dict.fromkeys(str(pathlib.PurePosixPath(r['path']).parent) for r in reuse['runtime']))
    dirs.append('/root/hyle-scratch/compute-unified/linux-current-graph/native/avx2')
    env['LD_LIBRARY_PATH']=':'.join(dirs)+':'+env.get('LD_LIBRARY_PATH','')
    cmd=[image['path'],'--gtest_filter='+filt,'--gtest_output=xml:'+str(ROOT/'tests.xml')]
    attempt=1
    while (ROOT/'logs'/f'run-{attempt:02d}.stdout.log').exists():attempt+=1
    r=invoke(f'run-{attempt:02d}',cmd,env);save('run-result.json',r)
    if (ROOT/'tests.xml').exists():(LOCAL/'tests.xml').write_bytes((ROOT/'tests.xml').read_bytes())
    print('RUN',r['exit_code'],flush=True)
    print(pathlib.Path(r['stdout']['path']).read_text()[-12000:],flush=True)
    if r['exit_code']:print(pathlib.Path(r['stderr']['path']).read_text()[-6000:],flush=True)
    raise SystemExit(r['exit_code'])

if sys.argv[1]=='compile':compile_all()
elif sys.argv[1]=='link':link()
elif sys.argv[1]=='run':run()
