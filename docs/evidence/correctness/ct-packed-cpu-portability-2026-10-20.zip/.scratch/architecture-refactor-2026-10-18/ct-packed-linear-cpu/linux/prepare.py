"""One-way bounded current-source overlay; reuse real GNU14 CPU caches."""
import difflib, hashlib, json, pathlib, re, shlex, subprocess

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parents[3]
A = REPO / '.scratch/architecture-refactor-2026-10-18'
REMOTE = '/root/hyle-scratch/compute-unified/linux-ct-packed-linear'
OLD = '/root/hyle-scratch/compute-unified/linux-current-graph'
LAYOUT = '/root/hyle-scratch/compute-unified/linux-layout-current'

def read(p): return json.loads(p.read_text(encoding='utf-8'))
def save(n, x): (HERE/n).write_text(json.dumps(x, indent=2)+'\n', encoding='utf-8')
def ident(p):
    return {'path':str(p), 'bytes':p.stat().st_size, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}

inv = read(A/'linux-layout-current-review/wsl-cache-inventory.json')
by = {r['source']:r for r in inv['dependencies']}
base = read(A/'linux-layout-current-review/validation/link-plan.json')
prefixes = ('src/compute_provider_native/', 'src/compute_provider_onednn/',
            'src/compute_route_cpu/', 'src/graph_provider_onednn/', 'src/graph_route_cpu/')
extra = [r for r in inv['dependencies'] if r['source'].startswith(prefixes)]
refresh = [
 'src/compute_provider_native/ct_packed.cc',
 'src/compute_provider_native/native_provider.cc',
 'src/compute_provider_native/nvfp4.cc',
 'src/compute_provider_native/cast.cc',
 'src/compute_provider_native/aten_cpu_provider.cc',
 'src/compute_provider_native/torch_cpu_program.cc',
 'src/compute_route_cpu/cpu_context.cc',
 'src/graph_route_cpu/cpu_context.cc',
 'src/graph_route_cpu/compile.cc',
 'src/graph_route_cpu/ct_packed_linear_region.cc',
 'src/graph_route_cpu/ggml_region.cc',
 'src/compute_provider_onednn/onednn_provider.cc',
 'src/graph_provider_onednn/onednn_region_provider.cc',
 'src/compute_ops/weight_decode.cc',
]
tests = ['tests/compute_provider_native/ct_packed_test.cc',
         'tests/graph_route_cpu/ct_packed_linear_test.cc',
         'tests/compute_route_cpu/context_test.cc']
reuse = [r for r in extra if r['source'] not in refresh]
oldsrc = A/'linux-current-graph/current-source'
oldplan = (oldsrc/'src/compute_provider_native/native_plan.h').read_text()
newplan = (REPO/'src/compute_provider_native/native_plan.h').read_text()
pdiff = ''.join(difflib.unified_diff(oldplan.splitlines(True),newplan.splitlines(True)))
(HERE/'native-plan.diff').write_text(pdiff, encoding='utf-8')
assert oldplan.split('Status prepare_nvfp4')[0] if 'Status prepare_nvfp4' in oldplan else True
assert newplan.replace('Status prepare_nvfp4(Operation operation, std::span<const TensorDesc> inputs,\n'
                      '                      std::span<const TensorDesc> outputs,\n'
                      '                      NativePlan &plan) noexcept;\n'
                      'Status prepare_ct_packed(Operation operation, std::span<const TensorDesc> inputs,\n'
                      '                         std::span<const TensorDesc> outputs,\n'
                      '                         NativePlan &plan) noexcept;\n','') == oldplan

def mapped(token):
    for prefix in [OLD+'/source', LAYOUT+'/source', '/mnt/c/public/project-hyle/hyle']:
        if token.startswith(prefix): return REMOTE+'/source'+token[len(prefix):]
    return token

entries = []
new_like = {'src/compute_provider_native/ct_packed.cc':'src/compute_provider_native/native_provider.cc',
            'src/compute_provider_native/nvfp4.cc':'src/compute_provider_native/native_provider.cc',
            'src/graph_route_cpu/ct_packed_linear_region.cc':'src/graph_route_cpu/ggml_region.cc'}
for rel in refresh:
    recipe = by[new_like.get(rel, rel)]
    command = [mapped(t) for t in recipe['command']]
    obj = REMOTE+'/objects/'+rel.replace('/','--')+'.o'
    command[command.index('-c')+1] = REMOTE+'/source/'+rel
    command[command.index('-o')+1] = obj
    command[command.index('-MF')+1] = obj+'.d'
    entries.append({'source':rel,'kind':'product','command':command,'object':obj,
                    'recipe_source':recipe['source'],'recorded_command':recipe['command']})

flags = by['src/graph_route_cpu/cpu_context.cc']['command'][1:]
flags = flags[:flags.index('-MMD')]
flags = [mapped(t) for t in flags if t not in ['-fPIC','-fvisibility=hidden','-fvisibility-inlines-hidden']
         and not (t.startswith('-DHYLE_') and t.endswith('_BUILD'))]
gtest = '/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
for rel in tests:
    defs = ['-DHYLE_TEST_GRAPH_ROUTE_CPU=1','-DHYLE_TEST_TORCH_CPU=1','-DHYLE_TEST_GGML_CPU=1'] if rel != tests[0] else []
    obj = REMOTE+'/objects/'+rel.replace('/','--')+'.o'
    command = ['/usr/bin/g++-14',*flags,*defs,'-isystem',gtest,'-MMD','-MF',obj+'.d',
               '-c',REMOTE+'/source/'+rel,'-o',obj]
    entries.append({'source':rel,'kind':'test','command':command,'object':obj,
                    'provenance':'Current hyle_add_test/C++23 strict warnings and actual graph_route_cpu GNU14 recipe; Graph macro only for Graph/context test.'})

# Freeze the literal project include closure of only current refreshed owners.
roots = [REPO/'include', REPO]
for e in entries:
    for j,t in enumerate(e['command'][:-1]):
        if t == '-I' and e['command'][j+1].startswith(REMOTE+'/source'):
            roots.append(REPO/e['command'][j+1][len(REMOTE+'/source/'):])
roots = list(dict.fromkeys(roots))
paths = set(refresh+tests+['src/graph/ct_packed_region.h','src/graph/mapped_native_region.h',
                         'cmake/HyleWarnings.cmake','tests/graph_route_cpu/CMakeLists.txt',
                         'tests/compute_provider_native/CMakeLists.txt','tests/compute_route_cpu/CMakeLists.txt'])
pending = list(paths)
while pending:
    rel = pending.pop(); p = REPO/rel
    for inc in re.findall(r'^\s*#\s*include\s*[<"]([^">]+)[">]',p.read_text(encoding='utf-8'),re.M):
        for root in [p.parent,*roots]:
            q = (root/inc).resolve()
            if q.is_file() and q.is_relative_to(REPO):
                r = q.relative_to(REPO).as_posix()
                if r not in paths: paths.add(r);pending.append(r)
                break
manifest = []
for rel in sorted(paths):
    q = HERE/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True)
    data = (REPO/rel).read_bytes()
    if q.exists(): assert q.read_bytes()==data,rel
    else: q.write_bytes(data)
    manifest.append({'relative':rel,**ident(q),'canonical':ident(REPO/rel)})
save('source-manifest.json',manifest)
save('compile-plan.json',{'entries':entries,'parallel':2})

retained = [r for r in base['new_objects']+base['retained_objects']+base['retained_native_objects']
            if not pathlib.PurePosixPath(r['path']).name.startswith('tests--')
            and not pathlib.PurePosixPath(r['path']).name.startswith('src--compute_ops--weight_decode')]
for r in reuse: retained.append({'path':r['object'],'source':r['source']})
extra_old = A/'linux-current-graph/link-plan.json'
old = read(extra_old)
libraries = base['libraries']+[r for r in old['retained_libraries'] if r['path'].endswith('/libdnnl.a')]
runtime = old['runtime'][:3]
save('reuse-plan.json',{'retained':retained,'libraries':libraries,'runtime':runtime,
                      'extra_current_source_equal':[{**r,'source_sha256':ident(REPO/r['source'])['sha256']} for r in reuse],
                      'abi_proof':'NativePlan exact old bytes after removing only two function declarations; provider factory owners refreshed for contract17/Region30; unchanged default_policy copies live original vtable.',
                      'base_plan':ident(A/'linux-layout-current-review/validation/link-plan.json')})
save('owner-inventory.json',{'remote':REMOTE,'sdk_reused':True,'products':refresh,'tests':tests,
                           'retained_extra_owners':[r['source'] for r in reuse],
                           'no_sdk_no_nvcc_no_gpu':True})

remote = r'''
import hashlib,json,pathlib,shutil,sys
x=json.load(sys.stdin);src=pathlib.Path(x['source']);root=pathlib.Path(x['remote']);root.mkdir(parents=True,exist_ok=True)
for r in x['files']:
 p=src/'source'/r['relative'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==r['sha256']
 q=root/'source'/r['relative'];q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert q.read_bytes()==data,str(q)
 else:q.write_bytes(data)
for n in ['compile-plan.json','reuse-plan.json','source-manifest.json','owner-inventory.json','native-plan.diff']:
 shutil.copyfile(src/n,root/n)
for n in ['objects','logs']:(root/n).mkdir(exist_ok=True)
print(json.dumps({'synced':len(x['files']),'bytes':sum(r['bytes'] for r in x['files']),'remote':str(root)}))
'''
payload = {'source':'/mnt/c/public/project-hyle/hyle/'+HERE.relative_to(REPO).as_posix(),
           'remote':REMOTE,'files':manifest}
q=subprocess.run(['wsl','-d','Ubuntu-24.04','--','python3','-c',remote],input=json.dumps(payload),capture_output=True,text=True,encoding='utf-8')
save('sync-result.json',{'command':['wsl','-d','Ubuntu-24.04','--','python3','-c',remote],
                         'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
print(q.stdout,q.stderr);raise SystemExit(q.returncode)
