#include "native_plan.h"
#include "numeric.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <span>
#include <utility>

#include "hyle/compute/model_ops.h"
#include "hyle/mem/resource.h"
#include "hyle/simd/ops.h"

namespace hyle::compute::native::internal {
namespace {
constexpr std::size_t kGroup = 16;
// The pinned non-fast ModelOpt table deliberately maps code8 to positive zero.
constexpr std::array<float, 16> kValues{
    0.F, .5F, 1.F, 1.5F, 2.F, 3.F, 4.F, 6.F,
    0.F, -.5F, -1.F, -1.5F, -2.F, -3.F, -4.F, -6.F};

float nearest_e2m1(float magnitude) noexcept {
  if (magnitude <= .25F) return 0.F;
  if (magnitude < .75F) return .5F;
  if (magnitude <= 1.25F) return 1.F;
  if (magnitude < 1.75F) return 1.5F;
  if (magnitude <= 2.5F) return 2.F;
  if (magnitude < 3.5F) return 3.F;
  return magnitude <= 5.F ? 4.F : 6.F;
}

bool bounded(const void *pointer, std::size_t bytes) noexcept {
  return pointer && bytes <= UINTPTR_MAX - reinterpret_cast<std::uintptr_t>(pointer);
}
bool overlaps(const void *a, std::size_t na, const void *b,
               std::size_t nb) noexcept {
  const auto x = reinterpret_cast<std::uintptr_t>(a);
  const auto y = reinterpret_cast<std::uintptr_t>(b);
  return x < y + nb && y < x + na;
}

struct Mappings final {
  std::array<mem::HostMapping, 5> input;
  mem::HostMapping scratch, output;
  bool wrote = false;

  Status finish(Status status, mem::BufferView destination) noexcept {
    if (wrote && !destination.resource().properties().has(
                     mem::MemoryProperty::kHostDeviceCoherent))
      preserve_first_error(status, output.flush());
    preserve_first_error(status, output.close());
    preserve_first_error(status, scratch.close());
    for (auto &mapping : input)
      preserve_first_error(status, mapping.close());
    return status;
  }
};

struct QuantizeEpisode final {
  const simd::bfloat16_t *input;
  simd::bfloat16_t *quantized;
  float global;
  std::atomic<bool> invalid{false};
};

void quantize_groups(void *state, std::size_t, std::size_t begin,
                     std::size_t end) noexcept {
  auto &episode = *static_cast<QuantizeEpisode *>(state);
  std::array<float, kGroup> values{};
  for (auto group = begin; group < end; ++group) {
    simd::convert(episode.input + group * kGroup, values.data(), kGroup);
    float maximum = 0.F;
    bool finite = true;
    for (const auto value : values) {
      finite &= std::isfinite(value);
      maximum = (std::max)(maximum, std::abs(value));
    }
    if (!finite) {
      episode.invalid.store(true, std::memory_order_relaxed);
      continue;
    }
    // Keep each source F32 operation and the original tiny-scale guard.
    const float denominator = 6.F * episode.global;
    const float normalized = (std::min)(maximum / denominator, 448.F);
    const float block = simd::f8e4m3_to_f32(simd::f32_to_f8e4m3(normalized));
    const float scaled = block * episode.global;
    const float scale = scaled >= 1.e-5F ? scaled : 1.F;
    for (std::size_t lane = 0; lane < kGroup; ++lane) {
      const float magnitude = nearest_e2m1(std::abs(values[lane]) / scale);
      const float restored = magnitude * scale;
      // The original comparison maps input -0 to +0; negative tiny values
      // which quantize to zero retain their negative sign.
      episode.quantized[group * kGroup + lane] = simd::f32_to_bf16(
          values[lane] >= 0.F ? restored : -restored);
    }
  }
}

struct DotEpisode final {
  const NativePlan *plan;
  const simd::bfloat16_t *activation;
  const std::uint8_t *weights;
  const simd::float8_e4m3_t *scales;
  float global;
  simd::bfloat16_t *output;
};

void dot_rows(void *state, std::size_t, std::size_t begin,
               std::size_t end) noexcept {
  const auto &episode = *static_cast<const DotEpisode *>(state);
  const auto n = episode.plan->parameters[1];
  const auto k = episode.plan->parameters[2];
  const auto groups = k / kGroup;
  std::array<simd::bfloat16_t, kGroup> decoded{};
  for (auto index = begin; index < end; ++index) {
    const auto row = index / n, column = index % n;
    const auto *activation = episode.activation + row * k;
    const auto *weights = episode.weights + column * (k / 2);
    const auto *scales = episode.scales + column * groups;
    float sum = 0.F;
    for (std::size_t group = 0; group < groups; ++group) {
      const float scale = simd::f8e4m3_to_f32(scales[group]) * episode.global;
      for (std::size_t lane = 0; lane < kGroup; ++lane) {
        const auto packed = weights[group * (kGroup / 2) + lane / 2];
        const auto code = (packed >> (4 * (lane % 2))) & 15U;
        // Do not fold either zero code or move the scale after the dot:
        // even valid finite source scales may overflow this F32 product.
        decoded[lane] = simd::f32_to_bf16(kValues[code] * scale);
      }
      sum += simd::dot(activation + group * kGroup, decoded.data(), kGroup);
    }
    episode.output[index] = simd::f32_to_bf16(sum);
  }
}

detail::EnqueueResult submit_nvfp4(const NativePlan &plan,
    std::span<const ConstTensorView> inputs,
    std::span<const TensorView> outputs, mem::BufferView workspace) noexcept {
  if (inputs.size() != 5 || outputs.size() != 1)
    return completed(Status::Internal("native NVFP4 binding count differs"));
  Mappings maps;
  const auto finish = [&](Status status) {
    return completed(maps.finish(std::move(status), outputs[0].storage()));
  };
  for (std::size_t i = 0; i < inputs.size(); ++i) {
    const auto storage = inputs[i].storage();
    if (!storage.resource().properties().has(
            mem::MemoryProperty::kHostDeviceCoherent)) {
      auto status = storage.invalidate();
      if (!status.ok()) return finish(std::move(status));
    }
    auto mapped = storage.map_host();
    if (!mapped) return finish(std::move(mapped).error());
    maps.input[i] = std::move(*mapped);
    if (!aligned_for_storage(maps.input[i].bytes().data(),
                              inputs[i].description().required_alignment()))
      return finish(Status::FailedPrecondition("native NVFP4 input mapping alignment differs"));
  }
  const float weight_global = numeric::load<float>(maps.input[3].bytes().data());
  const float input_global = numeric::load<float>(maps.input[4].bytes().data());
  if (!std::isfinite(weight_global) || !(weight_global > 0.F) ||
      !std::isfinite(input_global) || !(input_global > 0.F))
    return finish(Status::InvalidArgument("NVFP4 globals must be positive finite F32"));
  const auto *scales = reinterpret_cast<const simd::float8_e4m3_t *>(
      maps.input[2].bytes().data());
  const auto scale_count = plan.parameters[1] * (plan.parameters[2] / kGroup);
  for (std::size_t i = 0; i < scale_count; ++i) {
    const float scale = simd::f8e4m3_to_f32(scales[i]);
    if (!std::isfinite(scale) || scale < 0.F)
      return finish(Status::InvalidArgument("NVFP4 block scales must be nonnegative finite E4M3"));
  }
  auto scratch = workspace.map_host(mem::HostAccess::kWrite);
  if (!scratch) return finish(std::move(scratch).error());
  maps.scratch = std::move(*scratch);
  auto bytes = maps.scratch.writable_bytes();
  if (!bytes || bytes->size() < plan.workspace.size ||
      !aligned_for_storage(bytes->data(), alignof(simd::bfloat16_t)))
    return finish(Status::FailedPrecondition("native NVFP4 workspace mapping differs"));
  auto mapped = outputs[0].storage().map_host(mem::HostAccess::kWrite);
  if (!mapped) return finish(std::move(mapped).error());
  maps.output = std::move(*mapped);
  auto output = maps.output.writable_bytes();
  const auto output_bytes = *outputs[0].description().required_bytes();
  if (!output || output->size() < output_bytes ||
      !aligned_for_storage(output->data(), alignof(simd::bfloat16_t)))
    return finish(Status::FailedPrecondition("native NVFP4 output mapping differs"));
  if (!bounded(output->data(), output_bytes) ||
      !bounded(bytes->data(), plan.workspace.size) ||
      overlaps(output->data(), output_bytes, bytes->data(), plan.workspace.size))
    return finish(Status::InvalidArgument("native NVFP4 output/workspace overlaps"));
  for (const auto &input : maps.input) {
    const auto data = input.bytes();
    if (!bounded(data.data(), data.size()) ||
        overlaps(data.data(), data.size(), output->data(), output_bytes) ||
        overlaps(data.data(), data.size(), bytes->data(), plan.workspace.size))
      return finish(Status::InvalidArgument("native NVFP4 input/output/workspace overlaps"));
  }
  auto *activation = reinterpret_cast<simd::bfloat16_t *>(bytes->data());
  QuantizeEpisode quantize{
      reinterpret_cast<const simd::bfloat16_t *>(maps.input[0].bytes().data()),
      activation, input_global};
  parallel_for_ranges(plan, plan.parameters[0] * (plan.parameters[2] / kGroup),
                       &quantize_groups, &quantize);
  if (quantize.invalid.load(std::memory_order_relaxed))
    return finish(Status::InvalidArgument("NVFP4 requires finite BF16 activation"));
  DotEpisode episode{&plan, activation,
      reinterpret_cast<const std::uint8_t *>(maps.input[1].bytes().data()),
      scales, weight_global, reinterpret_cast<simd::bfloat16_t *>(output->data())};
  maps.wrote = true;
  parallel_for_ranges(plan, *outputs[0].description().element_count(), &dot_rows, &episode);
  return finish(Status::Ok());
}
} // namespace

Status prepare_nvfp4(Operation operation, std::span<const TensorDesc> inputs,
                      std::span<const TensorDesc> outputs,
                      NativePlan &plan) noexcept {
  const auto nvfp4 = operation.custom_as<model_ops::Nvfp4Linear>();
  if (!nvfp4) return Status::Unimplemented("operation is not NVFP4 reference linear");
  std::array<TensorDesc, 1> inferred;
  HYLE_RETURN_IF_ERROR(nvfp4->infer_output_descriptions(inputs, inferred));
  if (outputs.size() != 1 || outputs[0] != inferred[0])
    return Status::InvalidArgument("native NVFP4 output description differs");
  HYLE_ASSIGN_OR_RETURN(const auto bytes, inputs[0].required_bytes());
  plan.parameters = {static_cast<std::size_t>(inputs[0].dimensions()[0]),
      static_cast<std::size_t>(inputs[1].dimensions()[0]),
      static_cast<std::size_t>(inputs[0].dimensions()[1])};
  plan.workspace = {.size = bytes, .alignment = alignof(simd::bfloat16_t)};
  plan.workspace_submit_route = &submit_nvfp4;
  return Status::Ok();
}
} // namespace hyle::compute::native::internal
