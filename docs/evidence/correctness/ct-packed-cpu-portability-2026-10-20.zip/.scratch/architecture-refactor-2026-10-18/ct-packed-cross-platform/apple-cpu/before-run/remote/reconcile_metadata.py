from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;O=R/'results';V=R/'revisions/metadata-false-positive';V.mkdir(parents=True,exist_ok=True)
plan=json.loads((R/'plan.json').read_text());records=[]
for job in plan['compile']:
 p=O/(job['source'].replace('/','--')+'-identity.json');shutil.copyfile(p,V/p.name);r=json.loads(p.read_text());assert r['exit']==0
 obj=Path(r['object']);assert hashlib.sha256(obj.read_bytes()).hexdigest()==r['object_identity']['sha256'];assert not r['source_drifts']
 r['foreign_project_includes']=[d for d in r['dependencies']if not Path(d['path']).is_relative_to(R)and('/include/hyle/'in d['path']or'/src/compute'in d['path']or'/src/graph'in d['path'])];assert not r['foreign_project_includes']
 p.write_text(json.dumps(r,indent=2)+'\n');records.append(r)
(O/'compile-summary.json').write_text(json.dumps(dict(passed=True,compiles=records,SDK=False,Metal=False,metadata_correction='Initial8compiler exits0; then false positive classified hyle dependency cache path GTest as foreign canonical headers; only exact /include/hyle/ now canonical; no recompilation'),indent=2)+'\n')
(O/'metadata-correction.json').write_text(json.dumps(dict(product_compiler_failures=0,original_builder_exit=1,cause='Overbroad /hyle/ substring misclassified original GTest dependency cache; exact /include/hyle/ and private source prefixes now checked',object_bytes_unchanged=True,extra_CXX=0),indent=2)+'\n')
print('reconciled8samecompiledobjects;0extraCXX')
