from pathlib import Path
import hashlib,json,shlex,subprocess,time,shutil,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent;O=R/'after-cold-pattern/results';O.mkdir(parents=True,exist_ok=True);(R/'after-cold-pattern/objects').mkdir(exist_ok=True)
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,x):(O/name).write_text(json.dumps(x,indent=2)+'\n')
def execute(tag,cmd):
 row=dict(argv=cmd,started=time.time());save(tag+'.command.json',row);r=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/(tag+'.stdout.log')).write_text(r.stdout);(O/(tag+'.stderr.log')).write_text(r.stderr);row.update(exit=r.returncode,seconds=time.time()-row['started']);save(tag+'.result.json',row);print(tag,r.returncode,round(row['seconds'],2),flush=True);return row
before=json.loads((R/'results/src--graph_route_cpu--ct_packed_linear_region.cc-identity.json').read_text());cmd=before['argv'].copy();old=cmd[cmd.index('-o')+1];obj=R/'after-cold-pattern/objects/ct-region.o';dep=Path(str(obj)+'.d');cmd[cmd.index('-o')+1]=str(obj);cmd[cmd.index('-MF')+1]=str(dep)
row=execute('ct-region-compile',cmd)
if row['exit']:raise SystemExit(2)
deps=[identity(p)for p in dict.fromkeys(shlex.split(dep.read_text().split(': ',1)[1].replace('\\\n',' ')))];save('ct-region-identity.json',dict(row,source=identity(R/'src/graph_route_cpu/ct_packed_linear_region.cc'),header=identity(R/'src/graph/ct_packed_region.h'),object=identity(obj),dependencies=deps,previous_object=before['object_identity']))
link=json.loads((R/'results/link.json').read_text())['argv'];assert link.count(old)==1;link[link.index(old)]=str(obj);image=R/'after-cold-pattern/cpu-ct-tests';link[link.index('-o')+1]=str(image);link=[('-Wl,-map,'+str(image)+'.map')if a.startswith('-Wl,-map,')else a for a in link];save('link-inputs.json',[identity(a)for a in link if Path(a).is_file()and Path(a).suffix in ['.o','.a','.dylib']]);row=execute('link',link);save('link.json',row)
if row['exit']:raise SystemExit(3)
row=execute('run',[str(image),'--gtest_filter=NativeCtPackedLinear.*:CpuCtPackedLinear.*','--gtest_output=xml:'+str(O/'tests.xml')]);cases=E.parse(O/'tests.xml').findall('.//testcase');failed=[x.attrib for x in cases if x.findall('failure')];skipped=[x.attrib for x in cases if x.findall('skipped')];save('validation.json',dict(image=identity(image),exit=row['exit'],tests=len(cases),failed=failed,skipped=skipped,names=[x.get('classname')+'.'+x.get('name')for x in cases],product_CXX=1,tests_CXX=0,SDK=False,Metal=False));print('FINAL_MAC_CPU_CT',len(cases),'fail',len(failed),'skip',len(skipped),flush=True);raise SystemExit(row['exit']if row['exit']else int(len(cases)!=8 or bool(failed)or bool(skipped)))
