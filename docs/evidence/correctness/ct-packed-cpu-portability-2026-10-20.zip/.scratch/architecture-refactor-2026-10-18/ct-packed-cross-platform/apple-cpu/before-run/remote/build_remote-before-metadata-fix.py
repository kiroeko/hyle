from pathlib import Path
import concurrent.futures,hashlib,json,shlex,subprocess,time,sys,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True);(R/'objects').mkdir(exist_ok=True)
plan=json.loads((R/'plan.json').read_text());manifest=json.loads((R/'source-manifest.json').read_text());expected={x['path']:x for x in manifest}
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,x):(O/name).write_text(json.dumps(x,indent=2)+'\n')
def execute(tag,command):
 record=dict(argv=command,started=time.time());save(tag+'.command.json',record);p=subprocess.run(command,cwd=R,capture_output=True,text=True);(O/(tag+'.stdout.log')).write_text(p.stdout);(O/(tag+'.stderr.log')).write_text(p.stderr);record.update(exit=p.returncode,seconds=time.time()-record['started']);save(tag+'.result.json',record);print(tag,p.returncode,round(record['seconds'],2),flush=True);return record
for row in manifest:assert identity(R/row['path'])['sha256']==row['sha256'],row['path']
if '--compile'in sys.argv:
 save('hardware.json',dict(uname=subprocess.check_output(['uname','-a'],text=True),model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),memory=subprocess.check_output(['sysctl','-n','hw.memsize'],text=True).strip(),os=subprocess.check_output(['sw_vers'],text=True),clang=subprocess.check_output(['clang++','--version'],text=True)))
 for row in plan['inputs']:assert identity(row['path'])==row,row['path']
 save('baseline-input-identities.json',plan['inputs'])
 parents={str((R/x['path']).parent)for x in manifest if x['path'].endswith(('.h','.hpp','.hh','.inc','.inl'))and not x['path'].startswith('include/')}
 first=['-I'+str(R/'include'),'-I'+str(R),*['-I'+p for p in sorted(parents)]]
 def compile_one(row):
  rel=row['source'];tag=rel.replace('/','--');obj=R/'objects'/(tag+'.o');dep=Path(str(obj)+'.d');cmd=row['recipe'].copy()
  for flag in ['-MF','-MT','-MQ']:
   while flag in cmd:
    i=cmd.index(flag);del cmd[i:i+2]
  cmd=[x for x in cmd if x not in ['-MD','-MMD']];cmd[cmd.index('-c')+1]=str(R/rel);cmd[cmd.index('-o')+1]=str(obj);cmd[1:1]=first;cmd+=['-MD','-MF',str(dep)]
  if '-Werror'not in cmd:cmd.insert(1,'-Werror')
  result=execute(tag+'-compile',cmd);record=dict(result,source=identity(R/rel),old_object=row['old_object'],object=str(obj),dependency=str(dep),recipe_source=row['recipe_source'],new_test_recipe=row['new_test_recipe'])
  if result['exit']:save(tag+'-identity.json',record);return record
  deps=[identity(p)for p in dict.fromkeys(shlex.split(dep.read_text().split(': ',1)[1].replace('\\\n',' ')))];drift=[];foreign_project=[]
  for d in deps:
   p=Path(d['path'])
   if p.is_relative_to(R):
    relative=p.relative_to(R).as_posix()
    if relative in expected and expected[relative]['sha256']!=d['sha256']:drift.append(d)
   elif '/hyle/'in d['path']or '/src/compute'in d['path']or '/src/graph'in d['path']:foreign_project.append(d)
  record.update(object_identity=identity(obj),dependencies=deps,source_drifts=drift,foreign_project_includes=foreign_project);save(tag+'-identity.json',record);assert not drift and not foreign_project,(rel,drift,foreign_project);return record
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:records=list(pool.map(compile_one,plan['compile']))
 save('compile-summary.json',dict(compiles=records,passed=all(x['exit']==0 for x in records),SDK=False,Metal=False));raise SystemExit(int(any(x['exit']for x in records)))
records=json.loads((O/'compile-summary.json').read_text())['compiles'];assert all(x['exit']==0 for x in records);cmd=plan['link'].copy()
for row in records:
 if row['old_object']:
  assert cmd.count(row['old_object'])==1;cmd[cmd.index(row['old_object'])]=row['object']
 else:cmd.insert(1,row['object'])
image=R/'cpu-ct-tests';cmd[cmd.index('-o')+1]=str(image);cmd=[('-Wl,-map,'+str(image)+'.map')if a.startswith('-Wl,-map,')else a for a in cmd];save('link-inputs.json',[identity(a)for a in cmd if Path(a).is_file()and Path(a).suffix in ['.o','.a','.dylib']]);result=execute('link',cmd);save('link.json',result)
if result['exit']:raise SystemExit(2)
result=execute('run',[str(image),'--gtest_filter='+plan['run_filter'],'--gtest_output=xml:'+str(O/'tests.xml')]);cases=E.parse(O/'tests.xml').findall('.//testcase');failed=[x.attrib for x in cases if x.findall('failure')];skipped=[x.attrib for x in cases if x.findall('skipped')];save('validation.json',dict(image=identity(image),exit=result['exit'],tests=len(cases),failed=failed,skipped=skipped,names=[x.get('classname')+'.'+x.get('name')for x in cases],expected=plan['expected_test_count'],source_manifest=identity(R/'source-manifest.json')));print('MAC_CPU_CT',len(cases),'failed',len(failed),'skip',len(skipped),flush=True);raise SystemExit(result['exit']if result['exit']else int(len(cases)!=plan['expected_test_count']or bool(failed)or bool(skipped)))
