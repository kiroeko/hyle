from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def identity(p):return dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def tests(p):
    root=ET.parse(p).getroot();cases=root.findall('.//testcase')
    assert not root.findall('.//failure') and not root.findall('.//error') and not root.findall('.//skipped')
    return dict(tests=len(cases),failures=0,skipped=0,xml=identity(p),names=[dict(suite=x.get('classname'),name=x.get('name'))for x in cases])
W=A/'ct-packed-pattern-shared/portable-closure'
L=A/'ct-packed-linear-cpu/linux'
M=A/'ct-packed-cross-platform/apple-cpu'
linux=read(L/'final-validation.json');mac=read(M/'final-validation.json')
assert linux['actual_totals']['distinct_tests']==12
assert mac['validation']['final']['tests']==8
report=dict(
    scope='CPU CT packed ordinary Graph and Direct portability on frozen Windows/Linux/macOS sources; shared discovery extraction; no complete model or Apple/Vulkan packed GPU claim in this report',
    final=dict(windows_cpu=tests(W/'cpu/tests.xml'),windows_cuda_neighbors=tests(W/'cuda/tests.xml'),
               linux_cpu=linux,macos_cpu=mac),
    source_boundaries=[
        'Linux final uses its frozen eight-brace Graph fixture. Later native-resource upload overloads are outside that run.',
        'Mac CPU final uses its exact source capsule with CtPackedPattern extraction before the same-valued policy constant moved to the common base.',
        'Windows final recompiles the two CT region owners and two wrappers against the current shared policy and resource-upload fixture.',
        'No numerical executor or NativePlan layout changed in the shared-pattern/policy extraction.'],
    fixes=[
        'One exact CT pattern/control/reader proof is now available without a ComputeProvider template instance for native lowerers.',
        'Eight explicit braces make shared gtest conditional assertions compile under strict GNU warnings.',
        'Native-only Graph tests can use their actual resource without fabricating a Compute Context; original CPU/CUDA owner-retaining overloads remain.'],
    validation=dict(windows_cxx=4,windows_links=2,windows_processes=2,windows_sdk_or_nvcc=0,
                    linux=linux['actual_totals'],macos=mac['actual_totals'] if 'actual_totals'in mac else mac.get('process_totals',{})),
    limits=[
        'No Linux/macOS CPU throughput window or full-suite claim.',
        'Earlier Windows CPU M1/M128 performance and default rank remain in ct-packed-cpu-policy-2026-10-20.json; not repeated or pooled here.',
        'No artifact payload, importer, full model, native tensor-core/FFN/expert or universal precision-equivalence acceptance.',
        'Apple/Vulkan packed GPU implementation and shared shader host oracle are validated separately.'])
assert report['final']['windows_cpu']['tests']==10 and report['final']['windows_cuda_neighbors']['tests']==8
extensions={'.json','.xml','.log','.py','.cc','.h','.diff','.zip','.gz'}
roots=[W,L,M]
files={Path(__file__).resolve()}
for folder in roots:
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix in extensions and p.stat().st_size<3*1024*1024:
            files.add(p.resolve())
for name in ['src/graph/ct_packed_region.h','src/graph/mapped_native_region.h',
    'src/compute_packed_shared/ct_packed_linear.h','src/compute_provider_native/ct_packed.cc',
    'src/compute_provider_native/native_provider.cc','src/compute_provider_native/native_plan.h',
    'src/compute_route_cpu/cpu_context.cc','src/compute_route_cpu/default_policy.h',
    'src/graph_route_cpu/cpu_context.cc','src/graph_route_cpu/ct_packed_linear_region.cc',
    'src/graph_route_cpu/ct_packed_linear_region.h','tests/compute_models/ct_packed_graph_fixture.h',
    'tests/compute_models/ct_packed_linear_fixture.h','tests/compute_provider_native/half_test_support.h',
    'tests/graph_route_cpu/ct_packed_linear_test.cc','tests/graph_route_cuda/ct_packed_linear_test.cc',
    'tests/compute_provider_native/ct_packed_test.cc']:
    files.add((R/name).resolve())
manifest=[identity(p)for p in sorted(files)]
(S/'payload-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files.add(S/'payload-manifest.json')
destination=R/'docs/evidence/correctness/ct-packed-cpu-portability-2026-10-20.zip'
assert not destination.exists(),destination
with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
    for p in sorted(files):archive.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(destination)as archive:
    assert archive.testzip()is None
    for row in manifest:
        data=archive.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
report['archive']=identity(destination)
report['archived_files']=len(files)
report['payload_manifest']=identity(S/'payload-manifest.json')
output=destination.with_suffix('.json');output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(report=identity(output),archive=identity(destination)),ensure_ascii=False))
