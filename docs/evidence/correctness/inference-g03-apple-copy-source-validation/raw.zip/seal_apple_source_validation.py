from pathlib import Path
import hashlib,json,subprocess,zipfile,shutil

root=Path(__file__).resolve().parents[3]
work=root/'.scratch/inference-gaps/g03/apple-source-stage'
dest=root/'evidence/correctness/inference-g03-apple-copy-source-validation'
assert not dest.exists()
code=r'''
from pathlib import Path
import hashlib,json,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g03-apple-source-stage'
groups=[f'g03-apple-source-host-apple-{m}' for m in ['asan','ubsan','tsan']]+[f'g03-apple-source-apple-{m}-sdk' for m in ['static','shared']]
summary=[]
candidate='dab23ba92256cad21f2e83af6141eb8ad51264c5'
canonical=base/'source-c8874688'
with zipfile.ZipFile(out/'validation-raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for group in groups:
  d=base/group;job=json.loads((d/'job.json').read_bytes());receipt=json.loads((d/'result.json').read_bytes())
  assert job['state']=='TERMINAL' and job['exit_code']==0
  assert receipt['candidate']==candidate and all(r['exit_code']==0 for r in receipt['stages'])
  assert receipt['identity']['model']=='Mac16,12' and receipt['identity']['arch']=='arm64'
  for item in receipt.get('inputs',[]):
   assert hashlib.sha256((canonical/item['path']).read_bytes()).hexdigest()==item['sha256']
  if 'sdk' in group:
   for item in json.loads((d/'consumer-inputs.json').read_bytes()):
    data=(d/'consumer-source'/item['path']).read_bytes()
    assert data==(canonical/item['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==item['sha256']
    archive.write(d/'consumer-source'/item['path'],group+'/consumer-source/'+item['path'])
   h=d/'relocated/include/hyle/compute/apple_memory.h'
   assert h.read_bytes()==(canonical/'include/hyle/compute/apple_memory.h').read_bytes()
   archive.write(d/'consumer-source/CMakeLists.txt',group+'/consumer-source/CMakeLists.txt')
  for p in d.iterdir():
   if p.is_file() and p.suffix in ['.json','.log']:archive.write(p,group+'/'+p.name)
  summary.append({'group':group,'candidate':candidate,'identity':receipt['identity'],
     'terminal_exit':0,'stages':receipt['stages'],'cumulative_seconds':receipt['cumulative_seconds']})
 for name in ['apple_source_san_air.py','apple_source_sdk_air.py']:
  archive.write(out/name,name)
 for name in ['g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h',
              'g02-refcount-fence-probe/tsan-headers/util/ref_counted.h',
              'g01-metal-callback-tsan-probe/tsan-metal-cpp/Metal/MTLCommandBuffer.hpp']:
  p=base/name
  if p.is_file():archive.write(p,'explicit-models/'+name)
(out/'validation-summary.json').write_text(json.dumps({'candidate':candidate,'groups':summary,
 'cumulative_seconds':sum(r['cumulative_seconds'] for r in summary)},indent=2)+'\n')
print(json.dumps({'groups':len(summary),'cumulative_seconds':sum(r['cumulative_seconds'] for r in summary)}))
'''
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-apple-source-stage'
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,'python3 -'],input=code.encode(),check=True)
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',f'{host}:{remote}/validation-raw.zip',f'{host}:{remote}/validation-summary.json',str(work)],check=True)
dest.mkdir(parents=True)
shutil.copyfile(work/'validation-summary.json',dest/'receipt.json')
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 archive.write(work/'validation-raw.zip','air-validation-raw.zip')
 archive.write(work/'input-2.zip','canonical-input-2.zip')
 for name in ['run_apple_source_san.py','run_apple_source_sdk.py','seal_apple_source_validation.py']:
  archive.write(work.parent/name,name)
shutil.copyfile(work.parent/'apple-source-validation-plan.json',dest/'validation-plan.json')
(dest/'README.md').write_text('''# G03 Apple readonly source 候选宿主与三交付验证

固定 candidate dab23ba92256cad21f2e83af6141eb8ad51264c5；2026-10-14。
[五组 actual 记录](receipt.json)、[raw/编译命令/输入/脚本/显式模型](raw.zip)与
[变更影响计划](validation-plan.json)。全部实际 terminal0，身份 MacBook Air Mac16,12
arm64/macOS27.0.1；没有 Windows Apple binary journey。原 source 交付证据见
[对应阶段](../inference-g03-apple-copy-source-stage/README.md)。

ASan、UBSan、TSan 各实际运行来源64（固定program/两slots、精确bits、旧owner、partial
subview、容量/foreign/spoof/mutable拒绝、注入allocator绑定/准备零新增），F16/BF16
ready producer→dirty页→原attention各64步，以及五个原actual native copy lifecycle风险。
编译命令明确查 changed apple_memory.mm / apple_copy_program.cc / apple_copy_recording.mm
与真实消费者的对应 -fsanitize。ASan detect_leaks=0，未宣称 LSan/shader/driver/private
MLX pool 资格。TSan 复用已独立反证的 final-counter acquire 与同 Metal command-buffer
completion 模型；原模型字节保于 raw，非 suppression，产品/util/cache 不变。

relocated static/shared 使用同一 canonical 公共consumer字节：source64/native128仅
hyle::compute，原 CPU→Apple页→CPU joint768仅 hyle::graph；每包四独立 strict headers，
真实输出与权限全部PASS。产品SDK build只选对应公共闭包/四jobs，安装后重定位；独立
consumer compile commands 不含源码树 include，原 apple_memory 安装头逐字节匹配。
原 source/direct graph/copy8/copy风险已经通过，不重复闭合数学 P1。

selector selected docs/closure/configure/Apple header/直接 graph_route_cpu_apple/compute与
graph delivery，由上述真实 source、独立头、direct joint 和两种SDK覆盖；保141个跳过
理由。公共头只增加合同注释，原 symbol/layout/依赖图不变，但仍实际验证全部相关交付。
docs/closure 的当前 verdict 由 terminal 的机械检查给出，不由本 raw 的测试结果代签。

红队重读：只有原 ImportedArrayStorage 可进入家族资格；伪造 domain/host与普通异资源
不进入。actual resource owner/range仍保，原 copy_span/recording 原 device/alias核验未
删；写端严格 identity未变；bind failure不改现有binding；不增公开字段/Completion/queue。
这关闭 ready来源固定slot缺口，整步 import native费用/ready host waits保留；完整pending
page到attention、整个G03/goal仍未完成。
''',encoding='utf-8')
print('Sealed five actual validation groups',dest)
