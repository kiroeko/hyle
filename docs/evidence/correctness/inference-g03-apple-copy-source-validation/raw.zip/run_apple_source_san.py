from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[3]
work=root/'.scratch/inference-gaps/g03/apple-source-stage'
script=work/'apple_source_san_air.py'
text=(work.parent/'native_dirty_san_air.py').read_text()
text=text.replace("candidate='b42832de3ddda21bdc3e98ad4cc87e73622cbba4'", "candidate='dab23ba92256cad21f2e83af6141eb8ad51264c5'")
text=text.replace("out=base/f'g03-dirty-page-{route}-{mode}'", "out=base/f'g03-apple-source-host-{route}-{mode}'")
text=text.replace('g03-native-dirty-risk-stage/input-9.zip','g03-apple-source-stage/input-2.zip')
old="targets=[('g03_dirty_public','tests/compute_batch/dirty_page_native_consumer.cc'),('g03_dirty_risks','tests/compute_batch/dirty_page_'+route+'_risks.cc'),('g03_dirty_cpu','tests/compute_batch/dirty_page_public_consumer.cc')]"
new="targets=[('g03_apple_source64','tests/compute_batch/native_producer_copy_shape_probe.cc'),('g03_apple_producer128','tests/compute_batch/dirty_page_native_consumer.cc'),('g03_apple_source_risks','tests/compute_batch/dirty_page_apple_risks.cc')]"
assert old in text
text=text.replace(old,new)
text=text.replace("    if f'add_executable({target} ' not in body:", "    product='hyle::graph' if 'risks' in target else 'hyle::compute'\n    if f'add_executable({target} ' not in body:")
text=text.replace('target_link_libraries({target} PRIVATE hyle::graph)', 'target_link_libraries({target} PRIVATE {product})')
text=text.replace("if route=='apple' and target=='g03_dirty_public':body+=f'target_compile_definitions({target} PRIVATE HYLE_DIRTY_PAGE_APPLE=1)\\n'", "if target=='g03_apple_producer128':body+=f'target_compile_definitions({target} PRIVATE HYLE_DIRTY_PAGE_APPLE=1 HYLE_DIRTY_PAGE_NATIVE_PRODUCER=1)\\n'")
text=text.replace("names=['src/compute/batch_transfer.cc'", "names=['src/compute_route_apple/apple_memory.mm','src/compute_route_apple/apple_copy_recording.mm','src/compute/batch_transfer.cc'")
text=text.replace('actual G03 dirty page/CPU public/native math and copy lifecycle host instrumentation', 'actual G03 Apple readonly source64, native ready producer->page->attention128 and copy lifecycle host instrumentation')
script.write_text(text)
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-apple-source-stage'
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',str(script),f'{host}:{remote}/'],check=True)
for mode in ['asan','ubsan','tsan']:
    subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,f'python3 {remote}/{script.name} apple {mode}'],check=True)
print('All three Apple source host sanitizers actually terminal 0',flush=True)
