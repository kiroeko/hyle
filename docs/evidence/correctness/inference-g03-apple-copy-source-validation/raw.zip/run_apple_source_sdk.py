from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[3]
work=root/'.scratch/inference-gaps/g03/apple-source-stage'
script=work/'apple_source_sdk_air.py'
text=(work.parent/'native_dirty_sdk_air.py').read_text()
text=text.replace("candidate='b42832de3ddda21bdc3e98ad4cc87e73622cbba4'", "candidate='dab23ba92256cad21f2e83af6141eb8ad51264c5'")
text=text.replace("out=base/f'g03-dirty-page-{route}-{mode}-sdk'", "out=base/f'g03-apple-source-{route}-{mode}-sdk'")
text=text.replace("'hyle_compute','hyle_compute_batch',f'hyle_compute_route_{route}'", "'hyle_compute','hyle_compute_batch','hyle_graph',f'hyle_compute_route_{route}'")
text=text.replace("files=['tests/compute_batch/dirty_page_native_consumer.cc','tests/compute_batch/dirty_page_public_consumer.cc']", "files=['tests/compute_batch/dirty_page_native_consumer.cc','tests/compute_batch/native_producer_copy_shape_probe.cc','tests/graph_batch/native_paged_joint_consumer.cc']")
text=text.replace('target_compile_definitions(native PRIVATE HYLE_DIRTY_PAGE_APPLE=1)', 'target_compile_definitions(native PRIVATE HYLE_DIRTY_PAGE_APPLE=1 HYLE_DIRTY_PAGE_NATIVE_PRODUCER=1)')
text=text.replace('find_package(Hyle CONFIG REQUIRED COMPONENTS compute)', 'find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)')
text=text.replace('add_executable(cpu tests/compute_batch/dirty_page_public_consumer.cc)', 'add_executable(source64 tests/compute_batch/native_producer_copy_shape_probe.cc)\nadd_executable(joint tests/graph_batch/native_paged_joint_consumer.cc)\ntarget_compile_definitions(joint PRIVATE HYLE_JOINT_PAGE_APPLE=1)\ntarget_compile_features(joint PRIVATE cxx_std_23)\ntarget_compile_options(joint PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(joint PRIVATE hyle::graph)')
text=text.replace('foreach(t native cpu headers)', 'foreach(t native source64 headers)')
text=text.replace('hyle_stage_runtime(cpu)', 'hyle_stage_runtime(source64)\nhyle_stage_runtime(joint)')
text=text.replace("'native','cpu','headers'", "'native','source64','joint','headers'")
text=text.replace("run('native',[str(build/'native')]);run('cpu',[str(build/'cpu')])", "run('native',[str(build/'native')]);run('source64',[str(build/'source64')]);run('joint',[str(build/'joint')])")
text=text.replace('relocated public hyle::compute only, CPU64 dirty numerical/permission proof and native64 GQA mixed prefill/decode growth F16/BF16/F16, four public headers; no internal products/hooks or oracle substitution', 'relocated public hyle::compute source64 and native ready producer->page->attention128; direct hyle::graph joint768 and four headers; unchanged canonical consumers, no private hooks')
script.write_text(text)
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-apple-source-stage'
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',str(script),f'{host}:{remote}/'],check=True)
for mode in ['static','shared']:
    subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,f'python3 {remote}/{script.name} apple {mode}'],check=True)
print('Both Apple source relocated SDKs actually terminal 0',flush=True)
