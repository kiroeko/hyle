from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('shared',R/'.scratch/inference-multimodel-observation-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.W=W;b.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key

def prepare():
    base_path=R/'.scratch/inference-paged-layout-20261029/model-link-base.json';base=read(base_path)
    for item in base['retained']:exact(item)
    exact(base['runtime']);exact(base['sdk_engine_dependencies'])
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']:exact(item)
    old_object=read(base['previous_consumer']['path'])['object']['path']
    folder=W/'compile/consumer';folder.mkdir(parents=True,exist_ok=True)
    source=W/'consumer.cc';args=[]
    for index,arg in enumerate(base['compile']):
        if index and base['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
        elif key(arg)==key(base['consumer_source']['path']):arg=str(source)
        args.append(arg)
    link=[]
    for arg in base['link']:
        if key(arg)==key(old_object):arg=str(folder/'unit.obj')
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/consumer').with_suffix(suffix));break
        link.append(arg)
    assert sum(key(a)==key(source) for a in args)==1
    assert sum(key(a)==key(folder/'unit.obj') for a in link)==1
    (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    original=read(R/'.scratch/inference-cold-shape-plan-20261028/validation/runs/sampling-budget-cpu/command.json')['command'][-1]
    assert (Path(original)/'weights.tsv').is_file()
    save(W/'plan.json',dict(base=pin(base_path),worktree_base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        units=dict(consumer=dict(source=str(source),compile=args,link=link)),retained=base['retained'],runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'],fixture=original))
    print('Prepared bounded original sampling-budget consumer; reused227 SDK inputs, no downloads.')

action=sys.argv[1]
if action=='prepare':prepare()
elif action=='add-host':
    p=read(W/'plan.json');recipe=p['units']['consumer'];source=W/'host_image_consumer.cc';folder=W/'compile/host-image'
    folder.mkdir(parents=True,exist_ok=True);args=[]
    for index,arg in enumerate(recipe['compile']):
        if index and recipe['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
        elif key(arg)==key(recipe['source']):arg=str(source)
        args.append(arg)
    original=W/'compile/consumer/unit.obj';link=[]
    for arg in recipe['link']:
        if key(arg)==key(original):arg=str(folder/'unit.obj')
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/host-image').with_suffix(suffix));break
        link.append(arg)
    p['units']['host-image']=dict(source=str(source),compile=args,link=link);save(W/'plan.json',p)
    print('Prepared one additional bounded joint HostImage consumer, original SDK inputs unchanged.')
elif action in ['compile','link']:
    if action=='compile':
        folder=W/'compile'/sys.argv[2]/(sys.argv[3] if len(sys.argv)>3 else 'attempt1');folder.mkdir(parents=True,exist_ok=True)
        relative_test='tests/tools/qwen_host_image_request_case.h' if sys.argv[2]=='host-image' else 'tests/tools/qwen_sampling_budget_case.h'
        for relative in ['engine/models/qwen35/main.cc',relative_test]:
            shutil.copyfile(R/relative,folder/Path(relative).name)
    b.main()
elif action=='run':
    attempt=sys.argv[2];unit=sys.argv[3] if len(sys.argv)>3 else 'consumer';p=read(W/'plan.json');b.receipt(unit)
    image=read(W/('ready-'+unit+'.json'));exact(image)
    folder=W/'runs'/attempt;save(folder/'image.json',image)
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    b.b.execute([image['path'],p['fixture']],folder,300)
    result=read(folder/'stdout.log');assert result['status']=='PASS';save(folder/'report.json',result)
    print('PASS',attempt)
else:raise ValueError(action)
