from pathlib import Path
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('shared',R/'.scratch/inference-multimodel-observation-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.W=W;b.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
E=R/'docs/evidence/correctness/inference-request-recovery-2026-10-29.json'
SOURCES=['engine/models/qwen35/main.cc','tests/tools/qwen_sampling_budget_case.h',
    'tests/tools/qwen_host_image_request_case.h','tests/tools/qwen_request_lifecycle_test.cc','tests/CMakeLists.txt']

def prepare():
    p=read(W/'plan.json')
    for unit in p['units']:b.receipt(unit)
    for item in p['retained']:exact(item)
    exact(p['runtime']);exact(p['sdk'])
    for unit in read(p['sdk']['path'])['engine_consumers']:
        for item in unit['source_identities']:exact(item)
    for attempt in ['fixed','host-image']:
        process=read(W/'runs'/attempt/'process.json');assert process['state']=='TERMINAL' and process['exit']==0
        assert read(W/'runs'/attempt/'report.json')['status']=='PASS'
    for attempt,error in [('baseline','target row capacity differs from its declared packing'),
        ('rectangular-fallback','sampling draw cursor is exhausted')]:
        process=read(W/'runs'/attempt/'process.json')
        assert process['state']=='TERMINAL' and process['exit']==1 and (W/'runs'/attempt/'stderr.log').read_text().rstrip().endswith(error)
    save(W/'source-freeze.json',dict(base_commit=p['worktree_base_commit'],sources=[pin(R/s) for s in SOURCES]))
    unit=p['units']['consumer']
    save(W/'model-link-base.json',dict(schema='hyle.request-recovery.current-link-base.v1',base=p['base'],
        compile=unit['compile'],link=unit['link'],consumer_source=pin(unit['source']),previous_consumer=pin(W/'compile/consumer/receipt.json'),
        retained=p['retained'],runtime=p['runtime'],sdk_engine_dependencies=p['sdk'],source_freeze=pin(W/'source-freeze.json')))
    save(W/'reuse.json',dict(model_link_base=pin(W/'model-link-base.json'),
        consumers={name:dict(**unit,receipt=pin(W/'compile'/name/'receipt.json')) for name,unit in p['units'].items()},
        note='Both bounded CPU consumer objects use the current original Model source. Previous Qwen all-case/ordinary objects have a stale main identity; original227 SDK inputs remain reusable.'))
    old=R/'.scratch/inference-paged-layout-20261029/compile';roots=[W/'bin',old/'qwen',old/'ordinary']
    targets=[f for f in (W/'bin').iterdir() if f.is_file()]+[old/n/'unit.obj' for n in ['qwen','ordinary']]
    assert not {key(f) for f in targets}&{key(item['path']) for item in p['retained']}
    save(W/'cleanup-plan.json',dict(allowed_roots=[str(f.resolve()) for f in roots],targets=[pin(f) for f in targets]))
    print('PASS both current finite CPU journeys; preserved two genuine product failures, prepared SDK reuse/cleanup.')

def archive():
    p=read(W/'plan.json');freeze=read(W/'source-freeze.json')
    for item in freeze['sources']:exact(item)
    attempts=[('consumer','baseline'),('consumer','rectangular-fallback'),('consumer','fixed'),('host-image','attempt1')]
    builds=[dict(unit=n,attempt=a,compile=read(W/'compile'/n/a/'process.json'),link=read(W/'link'/n/a/'process.json'),
        object=read(W/'compile'/n/a/'receipt.json')['object']) for n,a in attempts]
    cases={a:dict(process=read(W/'runs'/a/'process.json'),
        report=read(W/'runs'/a/'report.json') if (W/'runs'/a/'report.json').is_file() else None,
        last_stderr_line=(W/'runs'/a/'stderr.log').read_text().rstrip().splitlines()[-1]) for a in ['baseline','rectangular-fallback','fixed','host-image']}
    result=dict(schema='hyle.correctness.request-recovery.v1',date='2026-10-29',status='PASS_WITH_PRESERVED_PRODUCT_FAILURES',
        base_commit=p['worktree_base_commit'],sources=freeze['sources'],
        changes=['No prepared packed prefill capacity selects original rectangular evaluation; original shape/row/capacity guards still apply.',
            'Ordinary sampling preflight excludes one already sampled, unobserved full-hit frontier only when original input/imported ledger/cursor/live head facts match. Future output draws and invalid Session checks remain strict.',
            'A real same-wave peer argument error retains its key; A recovers the original result at the last legal draw and delivers/acknowledges once, without a second frontier Graph.',
            'A natural N1 request-loop journey combines partial prefix, StateOnly chunks, automatic HostImage eviction/recovery and output credit/acknowledgement with original resource retirement.'],
        counts=dict(CXX_attempts=len(builds),links=len(builds),current_consumer_TUs=2,retained_SDK_inputs=227,
            SDK_CXX=0,NVCC=0,full_builds=0,downloads=0,native_processes=len(cases),current_passed_processes=2,preserved_product_failures=2),
        builds=builds,cases=cases,cleanup=read(W/'cleanup-result.json'),
        boundaries=['CPU finite A/H64/FFN128/V64 fixture; original real Model/Graph/RequestLoop/Arena, not a complete trained-model quality or throughput window.',
            'Sampling-budget regression covers a resident unobserved full-hit head; it does not claim that same frontier was evicted/restored in the same journey.',
            'Separate joint HostImage journey covers its reported bounded StateOnly/partial-prefix/credit behavior, not a Cartesian product of model/backend/configuration cases.',
            'No device-fault injection, GPU timing, latest llama.cpp comparison or performance claim. Earlier paged-layout CPU/CUDA evidence belongs to its own source revision.'],
        archive=E.with_suffix('.zip').name)
    save(E,result)
    with zipfile.ZipFile(E.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.write(E,E.name)
        for relative in SOURCES:
            z.write(R/relative,'current/'+relative)
            old=subprocess.run(['git','show',p['worktree_base_commit']+':'+relative],cwd=R,capture_output=True)
            if old.returncode==0:z.writestr('parent/'+relative,old.stdout)
        for relative in ['build.py','record.py','consumer.cc','host_image_consumer.cc','plan.json','source-freeze.json','model-link-base.json','reuse.json','cleanup-plan.json','cleanup-result.json']:
            z.write(W/relative,relative)
        for section in ['compile','link','runs']:
            for f in sorted((W/section).rglob('*')):
                if f.is_file() and f.name in ['receipt.json','process.json','stdout.log','stderr.log','command.json','image.json','report.json','consumer.cc','main.cc','qwen_sampling_budget_case.h','qwen_host_image_request_case.h']:
                    z.write(f,str(f.relative_to(W)))
        z.write(R/'test.ps1','cleanup.ps1')
        for relative in ['.scratch/inference-multimodel-observation-20261029/build.py','.scratch/inference-program-identity-20261029/build.py']:
            z.write(R/relative,'support/'+Path(relative).parent.name+'/build.py')
        z.write(Path(p['sdk']['path']),'support/sdk-engine-dependencies.json')
    print('PASS evidence',E.name,E.with_suffix('.zip').stat().st_size,'bytes archive')

if sys.argv[1]=='prepare':prepare()
elif sys.argv[1]=='archive':archive()
else:raise ValueError(sys.argv[1])
