from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT/'.scratch/inference-gaps/g04-g05/common-storage'
OUT.mkdir(parents=True, exist_ok=True)
PARENT = Path('C:/h7/inference-g01-native-vulkan/parent/CMakeLists.txt')
BUILD = Path('C:/h7/inference-g01-native-vulkan/build')
TARGET = 'g04_g05_cache_storage_tests'
parent = PARENT.read_text(encoding='utf-8')
if f'add_executable({TARGET} ' not in parent:
    parent += f'''\nadd_executable({TARGET} "C:/public/project-hyle/hyle/tests/compute_ops/low_precision_test.cc")
target_compile_features({TARGET} PRIVATE cxx_std_23)
target_compile_options({TARGET} PRIVATE /W4 /WX /wd4324 /utf-8)
target_link_libraries({TARGET} PRIVATE hyle_compute_ops GTest::gtest_main)
hyle_stage_runtime({TARGET})
'''
    PARENT.write_text(parent, encoding='utf-8', newline='\n')
env_out = subprocess.run(['cmd', '/d', '/c', str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],
                         capture_output=True, check=True, encoding='utf-8', errors='replace')
env = os.environ.copy()
for line in env_out.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key] = value
paths = ['include/hyle/compute/low_precision.h', 'include/hyle/compute/model_ops.h',
         'src/compute_ops/low_precision.cc', 'tests/compute_ops/low_precision_test.cc']
receipt = {'kind': 'G04_G05_COMMON_STORAGE_STAGE', 'state': 'RUNNING',
           'audit_revision': '532fd6731', 'native_math_qualification': 'UNPROVEN',
           'pid': os.getpid(), 'build_tree': str(BUILD), 'max_jobs': 4,
           'scope': 'compute_ops actual shared factor and original low_precision tests; no GPU execution/native build/full model',
           'inputs': {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},
           'stages': [], 'cumulative_seconds': 0}
def save():
    (OUT/'result.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8', newline='\n')
save()
commands = [('configure', ['cmake', '-S', str(PARENT.parent), '-B', str(BUILD)]),
            ('compile', ['cmake', '--build', str(BUILD), '--target', TARGET, '--parallel', '4']),
            ('tests', [str(BUILD/(TARGET+'.exe')), '--gtest_output=xml:'+str(OUT/'tests.xml')])]
for stage, command in commands:
    log = OUT/(stage+'-1.log')
    begin = time.monotonic()
    with log.open('wb') as stream:
        run = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    elapsed = time.monotonic()-begin
    receipt['stages'].append({'stage': stage, 'command': command, 'exit_code': run.returncode,
                              'elapsed_seconds': elapsed, 'log': str(log)})
    receipt['cumulative_seconds'] += elapsed
    save()
    print(f'{stage}: exit={run.returncode}, elapsed={elapsed:.3f}s', flush=True)
    if run.returncode:
        receipt['state'] = 'TERMINAL_FAIL'
        save()
        raise SystemExit(run.returncode)
receipt['state'] = 'TERMINAL_PASS'
save()
