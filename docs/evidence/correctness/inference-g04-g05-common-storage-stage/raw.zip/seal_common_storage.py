from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT/'.scratch/inference-gaps/g04-g05/common-storage'
DEST = ROOT/'evidence/correctness/inference-g04-g05-common-storage-stage'
result = json.loads((SOURCE/'result.json').read_text(encoding='utf-8'))
assert result['state'] == 'TERMINAL_PASS'
assert all(s['exit_code'] == 0 for s in result['stages'])
for path, sha in result['inputs'].items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest() == sha, path
xml = ET.parse(SOURCE/'tests.xml').getroot()
assert xml.attrib['failures'] == '0' and xml.attrib['errors'] == '0'
result['test_count'] = int(xml.attrib['tests'])
result['coverage'] = [
    'Q8_0 last depth block axis and NHD physical row/page strides',
    'exact Q8 U8 carrier and independent depth64/128/256 description sizes',
    'FP8 code bytes independent of positive immutable scale value',
    'invalid scale/forged block/logical type/extent/overflow refusal',
    'dirty encoder operation output descriptions for F16/BF16/F32 and empty input',
    'eight original low precision descriptor tests unchanged',
]
result['limits'] = [
    'Only common CacheStorage/descriptions/CacheEncode inference implemented in this stage.',
    'No native encoding, attention math, F2 append journey, new BatchCapacity, SDK or P1 qualified.',
    'All nine owners remain AUDITED; CE01 only partial, CE02-CE07 remain UNPROVEN.',
    'Broad public-header selector consumers will be validated once the shared implementation batch is fixed, not claimed passed by these tests.',
]
artifacts = ['C:/h7/inference-g01-native-vulkan/build/hyle/src/compute_ops/hyle_compute_ops.dll',
             'C:/h7/inference-g01-native-vulkan/build/g04_g05_cache_storage_tests.exe']
result['artifacts'] = [{'path': p, 'sha256': hashlib.sha256(Path(p).read_bytes()).hexdigest()}
                       for p in artifacts]
result['live_jobs'] = []
DEST.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST/'raw.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in SOURCE.iterdir():
        if path.is_file():
            archive.write(path, path.name)
    archive.write(ROOT/'.scratch/inference-gaps/g04-g05/run_common_storage.py', 'run_common_storage.py')
    archive.write(ROOT/'.scratch/inference-gaps/g04-g05/seal_common_storage.py', 'seal_common_storage.py')
result['raw_sha256'] = hashlib.sha256((DEST/'raw.zip').read_bytes()).hexdigest()
(DEST/'result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8', newline='\n')
(DEST/'validation-plan.json').write_bytes((ROOT/'.scratch/inference-gaps/g04-g05/ce01-plan.json').read_bytes())
print(f"sealed {result['test_count']} tests, {result['cumulative_seconds']:.3f}s; native math UNPROVEN")
