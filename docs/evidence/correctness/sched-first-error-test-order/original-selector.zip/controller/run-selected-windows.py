"""Existing change-impact selector, immutable R6 snapshot, serial low-parallel execution."""
import argparse
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--plan-only', action='store_true')
args = parser.parse_args()
repo = Path('C:/hyle-scratch/r6-vulkan-20260917/candidate-8e45b104')
task = Path('C:/hyle-scratch/r6-vulkan-20260917/selected-final-windows')
scratch_base = Path('C:/hv6')
cache = task / 'receipts'
context = Path('C:/hyle-scratch/r6-vulkan-20260917/selected-w1-v2/context.json')
candidate = '3894b72e3b4fbbda9457e2c31730e48bd0d43c49'
ctypes.windll.kernel32.SetErrorMode(0x8003)
ctypes.windll.kernel32.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
assert ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.c_void_p(-1), 0x14)
assert ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(-1), 0x20)
os.environ.update(HYLE_DEP_SOURCE_CACHE='C:/public/project-hyle/.deps', CMAKE_BUILD_PARALLEL_LEVEL='2',
    CMAKE_GENERATOR='Ninja', CTEST_PARALLEL_LEVEL='1', CTEST_INTERACTIVE_DEBUG_MODE='0',
    VK_LOADER_LAYERS_DISABLE='~implicit~')
os.environ.pop('CMAKE_GENERATOR_PLATFORM', None)
os.environ.pop('CMAKE_GENERATOR_TOOLSET', None)
task.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('hyle_selector', repo / 'scripts/validation-select.py')
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
plan = selector.make_plan(repo, 'a767bdc4', candidate, context=context, cache=cache)
selector.write_json(task / 'plan.json', selector.public_report(plan))
assert plan['verdict'] != 'BLOCKED', plan.get('product_authorization')
print('Selected:', [g['id'] for g in plan['gates'] if g['status'] == 'SELECTED'], flush=True)
if args.plan_only:
    raise SystemExit(0)
assert not (task / 'result.json').exists(), 'Inspect the existing attempt before resuming'
identity = selector.environment_identity(context, native=True)
scratch = scratch_base / selector.digest({'tree': plan['candidate_tree'], 'context': identity})[:20]
build = scratch / ('build-' + selector.digest({'tree': plan['candidate_tree'], 'context': identity,
                                              'factors': plan['selected_factors']})[:20])
for gate in plan['gates']:
    for command in gate['commands']:
        for argument in command:
            if argument.startswith('-DHYLE_SMOKE_ROOT='):
                target = Path(argument.split('=', 1)[1].replace('{scratch}', str(scratch))).resolve()
                target.relative_to(scratch_base.resolve())
                assert target != scratch_base.resolve()
build_bin = build / 'bin'
build_bin.mkdir(parents=True, exist_ok=True)
dlls = [Path('C:/Windows/System32') / name for name in (
    'msvcp140.dll', 'msvcp140_atomic_wait.dll', 'vcruntime140.dll', 'vcruntime140_1.dll', 'vulkan-1.dll')]
dlls += [Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64') / name
         for name in ('cudart64_13.dll', 'cublasLt64_13.dll')]
for dll in dlls:
    shutil.copyfile(dll, build_bin / dll.name)
selector.write_json(task / 'paths.json', {'candidate': candidate, 'scratch': str(scratch),
    'build': str(build), 'context': str(context), 'DLLs': [str(p) for p in dlls]})
selector.execute(repo, plan, cache, scratch_base, context=context)
selector.write_json(task / 'result.json', selector.public_report(plan))
print('Verdict:', plan['verdict'], flush=True)
sys.exit(0 if plan['verdict'] == 'PASS' else 2)
