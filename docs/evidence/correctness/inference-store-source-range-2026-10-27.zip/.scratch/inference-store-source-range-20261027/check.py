from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-generic-output-source-20261027'
spec = importlib.util.spec_from_file_location('range_previous', B / 'check.py')
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
m, h, exact = prior.m, prior.h, prior.exact
prior.W = W; prior.B = B; m.W = W
CASES = m.read(W / 'source-freeze.json')['proposed_validation']['tests']


def freeze():
    assert not (W / 'plan.json').exists()
    frozen = m.read(W / 'source-freeze.json')
    cli, component = m.read(B / 'cli-link-inputs.json'), m.read(B / 'component-link-inputs.json')
    assert len(cli) == 224 and len(component) == 241
    for row in {m.key(x['path']): x for x in cli + component}.values(): exact(row)
    ci, ti = m.index(cli), m.index(component)
    def lookup(index, relative):
        suffix = '\\' + relative.replace('/', '\\').lower()
        found = [v for k, v in index.items() if k.endswith(suffix)]
        assert len(found) == 1, (relative, len(found))
        return found[0]
    resource = lookup(ci, 'src/graph/resources.cc')
    assert resource['object'] == lookup(ti, 'src/graph/resources.cc')['object']
    test = lookup(ti, 'tests/graph/output_source_cuda_test.cc')
    owned = []
    for row in frozen['sources']:
        source, snapshot = R / row['path'], Path(row['snapshot'])
        a, b = m.pin(source), m.pin(snapshot)
        assert a['sha256'] == b['sha256'] == row['sha256'] and a['bytes'] == b['bytes'] == row['bytes']
        owned.append(dict(original=a, snapshot=b))
    header = 'include/hyle/graph/detail/store_source.h'
    before = subprocess.run(['git', 'show', frozen['base_commit'] + ':' + header],
                            cwd=R, capture_output=True, check=True).stdout
    actual_old_header = next(x for x in m.read(B / 'compile/resources/actual-dependencies.json')
                             if m.key(x['path']) == m.key(R / header))
    assert hashlib.sha256(before).hexdigest() == actual_old_header['sha256']
    old = before.decode(); current = (R / header).read_text()
    # Exact token-preserving extension, not a blanket changed-header waiver.
    extension = '''struct StoreDestinationRange final {
  std::size_t first = 0, count = 0;
};'''
    overload = '''HYLE_GRAPH_API static Result<StoreSource> prepare(Invocation &, NodeId store,
      const compute::StorageOwner &, StoreDestinationRange, ResourceOptions) noexcept;'''
    assert current.count(extension) == current.count(overload) == 1
    assert prior.tokens(current.replace(extension, '').replace(overload, '')) == prior.tokens(old)
    assert prior.tokens(current.split('private:')[1]) == prior.tokens(old.split('private:')[1])
    baseline_header = W / 'source/store_source-before.h'; baseline_header.write_bytes(before)
    pre, units = {}, []
    for name, relative, record in [('resources', 'src/graph/resources.cc', resource),
                                   ('output-test', 'tests/graph/output_source_cuda_test.cc', test)]:
        source = R / relative; snapshot = W / 'source' / relative; out = W / 'compile' / name
        recipe = B / 'logs' / name / 'command.json'; template = m.read(recipe)['command']
        command = []
        for i, arg in enumerate(template):
            if i and template[i - 1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(snapshot)
            command.append(arg)
        assert m.build_contract(command) == m.build_contract(template)
        for path in [record['data']['Source'], *record['data']['Includes'], source, snapshot]:
            pre[m.key(path)] = m.pin(path)
        m.save(W / 'recipes' / (name + '.json'), dict(command=command, template=m.pin(recipe)))
        units.append(dict(name=name, source=m.pin(snapshot), original_source=m.pin(source),
                          original=record, recipe=m.pin(recipe), command=command, object=str(out / 'unit.obj')))
    for row in owned: pre[m.key(row['original']['path'])] = row['original']
    (W / 'bin').mkdir(exist_ok=True)
    cpu = m.read(B / 'runtime.json')['original_native_cpu']; exact(cpu)
    alias = W / 'bin' / Path(cpu['path']).name
    if not alias.exists(): os.link(cpu['path'], alias)
    env = prior.environment()
    m.save(W / 'environment.json', {k: env.get(k, '') for k in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    m.save(W / 'runtime.json', dict(baseline=m.pin(B / 'runtime.json'), original_native_cpu=cpu,
                                   alias=m.pin(alias), PATH=env['PATH']))
    m.save(W / 'precompile-dependencies.json', list(pre.values()))
    m.save(W / 'plan.json', dict(status='FROZEN_NOT_BUILT', sources=owned, units=units,
        source_freeze=m.pin(W / 'source-freeze.json'),
        baselines={kind: dict(ready=m.pin(B / ('ready-' + kind + '.json')),
                             inputs=m.pin(B / (kind + '-link-inputs.json')),
                             recipe=m.pin(B / ('link-' + kind) / 'command.json'))
                   for kind in ('cli', 'component')},
        dependencies=m.pin(W / 'precompile-dependencies.json'), runtime=m.pin(W / 'runtime.json'), tests=CASES,
        header_reuse_exception=dict(before=m.pin(baseline_header), after=m.pin(R / header),
            old_tokens_unchanged_after_removing_only_two_additions=True,
            additions=['StoreDestinationRange type', 'one new static prepare overload without a default ResourceOptions'],
            unchanged='All original declarations, defaults, inline definitions and private pointer field; StoreSource object layout unchanged.',
            boundary='Only resources.cc-private State grows; it is recompiled. No general changed-header/ABI waiver.'),
        counts=dict(CXX=2, links=2, cli_inputs=224, component_inputs=241, unique_tests=4, SDK=0, NVCC=0, model=0),
        scope='Fixed continuous original Store destinations; original complete transaction proof; real bounded I32 guard; no R2 compact IDs or model/MTP continuation claim.'))
    print('FROZEN 2 CXX / 2 links / 4 unique cases; GPU not run', flush=True)


def run():
    ready = m.read(W / 'ready-component.json'); exact(ready['image'])
    for row in m.read(ready['inputs']['path']): exact(row)
    process = h.execute([ready['image']['path'], '--gtest_color=no', '--gtest_fail_fast',
        '--gtest_filter=' + ':'.join(CASES), '--gtest_output=xml:' + str(W / 'run/results.xml')],
        prior.environment(), W / 'run', timeout=180)
    cases = ET.parse(W / 'run/results.xml').getroot().findall('./testsuite/testcase')
    assert sorted(x.attrib['classname'] + '.' + x.attrib['name'] for x in cases) == sorted(CASES)
    assert all(x.find(tag) is None for x in cases for tag in ('failure', 'error', 'skipped'))
    m.save(W / 'summary.json', dict(status='PASS', process=process, tests=CASES,
        xml=m.pin(W / 'run/results.xml'), cli=m.pin(W / 'ready-cli.json'), component=m.pin(W / 'ready-component.json'),
        counts=dict(CXX=2, links=2, GPU_test_processes=1, passed=4, model_processes=0, SDK=0, NVCC=0, downloads=0),
        scope='Finite continuous range and old whole-source contracts only; no complete model/MTP pipeline or throughput claim.'))
    print('PASS 4/4, 0 skip', flush=True)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'freeze': freeze()
        elif action == 'compile': prior.compile_unit(sys.argv[2])
        elif action == 'link': prior.link(sys.argv[2])
        elif action == 'run': run()
        else: raise ValueError(action)
    except BaseException:
        (W / ('failure-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc())
        raise
