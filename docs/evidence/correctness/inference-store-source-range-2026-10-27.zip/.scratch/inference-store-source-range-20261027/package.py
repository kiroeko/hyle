"""Package the finite W12 window, preserving initial failure and both images."""
from pathlib import Path
import hashlib, json, zipfile
import xml.etree.ElementTree as ET
W = Path(__file__).resolve().parent; R = W.parents[1]
DEST = R / 'docs/evidence/correctness'
STEM = 'inference-store-source-range-2026-10-27'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path).resolve(); digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''): digest.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    assert pin(row['path']) == row, ('changed', row['path'])


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def main():
    result = read(W / 'summary2.json'); first = read(W / 'first-run-diagnosis.json')
    plan, plan2 = read(W / 'plan.json'), read(W / 'plan2.json')
    assert result['status'] == 'PASS' and result['process']['exit'] == 0
    tests = ET.parse(W / 'run2/results.xml').getroot().findall('./testsuite/testcase')
    assert sorted(x.attrib['classname'] + '.' + x.attrib['name'] for x in tests) == sorted(result['tests'])
    assert len(tests) == 6 and all(x.find(t) is None for x in tests for t in ('failure', 'error', 'skipped'))
    old_tests = ET.parse(W / 'run/results.xml').getroot().findall('./testsuite/testcase')
    assert len(old_tests) == 4 and sum(x.find('failure') is not None for x in old_tests) == 1
    assert sum(x.find('skipped') is not None for x in old_tests) == 1
    assert read(W / 'run/process.json')['exit'] == 1
    # Initial product path now has the fixed bytes. Verify the actual preserved
    # historical snapshot instead of pretending that the current file is old.
    for source in plan['sources']: exact(source['snapshot'])
    for row in read(W / 'source-freeze2.json')['unchanged']:
        assert pin(R / row['path'])['sha256'] == row['sha256']
    exact(plan2['source']); exact(plan2['snapshot']); exact(plan2['reused_test'])
    builds = [read(W / 'compile' / name / 'compiled.json') for name in ('resources', 'output-test', 'resources2')]
    for build in builds:
        assert build['process']['exit'] == 0
        for key in ('source', 'object', 'command', 'compiler_dependencies', 'actual_dependencies'): exact(build[key])
    ready = {name: read(W / ('ready-' + name + '.json')) for name in ('cli', 'component', 'cli2', 'component2')}
    for name, item in ready.items():
        assert item['link']['exit'] == 0
        for key in ('image', 'inputs', 'recipe', 'runtime', 'plan'): exact(item[key])
        assert len(read(item['inputs']['path'])) == (224 if name.startswith('cli') else 241)

    # Only local necessary source/receipt/log trees, never an SDK or binary walk.
    files = {p for p in W.iterdir() if p.is_file() and p.suffix in ('.py', '.json', '.log')
             and p.name != 'package-result.json'}
    for folder in ('source', 'source2', 'recipes', 'logs', 'run', 'run2',
                   'link-cli', 'link-component', 'link-cli2', 'link-component2'):
        files.update(p for p in (W / folder).rglob('*') if p.is_file())
    for name in ('resources', 'output-test', 'resources2'):
        files.update(W / 'compile' / name / f for f in ('compiled.json', 'dependencies.json', 'actual-dependencies.json'))
    B = R / '.scratch/inference-generic-output-source-20261027'
    files.add(B / 'check.py')
    for baseline in plan['baselines'].values():
        files.update(Path(baseline[key]['path']) for key in ('ready', 'inputs', 'recipe'))
    forbidden = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.gguf', '.pt', '.spv'}
    members = []
    for path in sorted(files):
        assert path.is_file() and path.suffix.lower() not in forbidden and path.resolve().is_relative_to(R)
        data = path.read_bytes()
        members.append(dict(member=path.relative_to(R).as_posix(), bytes=len(data), sha256=sha(data)))
    manifest = dict(schema=1, members=members)
    DEST.mkdir(parents=True, exist_ok=True); archive = DEST / (STEM + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for member in members: out.write(R / member['member'], member['member'])
        out.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        assert set(check.namelist()) == {x['member'] for x in members} | {'manifest.json'}
        for member in members:
            data = check.read(member['member'])
            assert len(data) == member['bytes'] and sha(data) == member['sha256']
        assert json.loads(check.read('manifest.json')) == manifest
    output = DEST / (STEM + '.json')
    receipt = dict(schema=1, status='PASS_AFTER_RECORDED_FAILURE', date='2026-10-27',
        subject='Fixed continuous original Store destination Source and pending capture retention',
        sources=[plan2['source'], *[pin(R / row['path']) for row in read(W / 'source-freeze2.json')['unchanged']]],
        implementation=[
            'prepare range {first,count} fixes a nonempty consecutive original destination interval; original whole overload and old methods remain.',
            'capture first validates the complete original M-writer transaction; only selected full-writer tickets are sealed, using the real bounded I32 IDs subview without upload or copy.',
            'destination_count is view count; publish uses original ordinals and rejects unselected or mismatched returned writers.',
            'Pending consumers with any retained capture commands/rebuild storage/variants require original complete reuse-only qualification. A tuple miss returns Unavailable; no record, Commands fallback or artifact destruction.',
            'Without retained artifacts, original Prepared nonblocking Commands remain available. All-ready retains original PreferCapture behavior.'],
        validation=dict(final_process=result['process'], final_tests=result['tests'], final_passed=6, final_skipped=0,
            actual_checks=[
                'Whole and {1,1} views capture one original submitted generation; real pending Gather reads only the selected row.',
                'Genuine ready RequireCapture followed by exact guard withdrawal and same-generation writer reuse; final pending preparation reuses existing capture with zero recording while A remains gated.',
                'Original ordinal publication, failed producer complete Status and actual retirement, count/root/generation/range ready rejection, preserved old snapshots and padding.',
                'Original whole-source pair plus F32/I32 prepared consumer regressions.'],
            cumulative=result['cumulative_counts'],
            builds=[dict(process=x['process'], object=x['object'], source=x['source']) for x in builds],
            images={name: dict(image=item['image'], link=item['link'], inputs=item['inputs'],
                    scope=('linked; not run' if name.startswith('cli') else
                           'initial 2pass/1fail/1skip' if name == 'component' else 'final 6pass')) for name, item in ready.items()},
            header_reuse_exception=plan['header_reuse_exception']),
        recorded_failure=dict(process=first['process'], result=first['actual_result'],
            observation='Prepared consumer initially chose Commands; A gate watchdog released after 10s and existing capture was not reused.',
            static_cause='Commands preparation reset captured artifacts; CUDA capture status destruction calls cudaFree. The blocking-call attribution is static ownership/timing inference, not direct debugger proof.',
            correction='Local pending Source route selection preserves artifacts and enforces existing reuse-only proof; unchanged test object and assertions then passed.',
            not_run_initially=first['not_run']),
        harness_failure=dict(stage='check2.py parser before CXX', error="one extra ')' corrected", evidence='check2-attempt1.py and failure2-freeze-parse.json retained'),
        boundaries=['No nonconsecutive R2 selection/compact IDs, accepted-prefix device selection, complete MTP successor or full engine pipeline validation.',
                    'No model, performance, SDK/NVCC rebuild, download, multi-platform or new fault-injection run.',
                    'Two CLI images only linked. Component evidence does not claim throughput or universal asynchronous driver cleanup.'],
        evidence=dict(archive=pin(archive), members=len(members) + 1, all_member_bytes_and_sha_read_back=True,
                      omitted='EXE/OBJ/PDB/DLL/LIB/EXP, SDK, shader binaries and model payloads'))
    save(output, receipt)
    result = dict(receipt=pin(output), archive=pin(archive), members=len(members) + 1)
    save(W / 'package-result.json', result); print(json.dumps(result, indent=2))


if __name__ == '__main__': main()
