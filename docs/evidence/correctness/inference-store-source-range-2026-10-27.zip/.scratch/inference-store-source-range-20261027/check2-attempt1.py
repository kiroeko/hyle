from pathlib import Path
import importlib.util, json, os, sys, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('range_first_attempt', W / 'check.py')
first = importlib.util.module_from_spec(spec); spec.loader.exec_module(first)
m, h, exact = first.m, first.h, first.exact
CASES = m.read(W / 'source-freeze2.json')['planned_tests']


def environment():
    env = first.prior.environment(); env['PATH'] = str(W / 'bin2') + ';' + env['PATH']
    return env


def freeze():
    assert not (W / 'plan2.json').exists()
    frozen = m.read(W / 'source-freeze2.json')
    record = frozen['resources']; assert m.pin(record['path'])['sha256'] == record['sha256']
    snapshot = m.pin(record['snapshot']); assert snapshot['sha256'] == record['sha256']
    for row in frozen['unchanged']: assert m.pin(R / row['path'])['sha256'] == row['sha256']
    exact(frozen['test_object_reuse'])
    old = m.read(W / 'plan.json'); template = m.read(W / 'logs/resources/command.json')['command']
    out = W / 'compile/resources2'; command = []
    for i, arg in enumerate(template):
        if i and template[i - 1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
        elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = snapshot['path']
        command.append(arg)
    assert m.build_contract(command) == m.build_contract(template)
    original = next(u for u in old['units'] if u['name'] == 'resources')
    data = m.read(W / 'compile/resources/dependencies.json')['Data']
    deps = [m.pin(x) for x in dict.fromkeys([*data['Includes'], snapshot['path'], record['path']])]
    m.save(W / 'precompile-dependencies2.json', deps)
    baselines = {}
    for kind in ('cli', 'component'):
        ready = m.read(W / ('ready-' + kind + '.json'))
        exact(ready['image']); exact(ready['inputs']); exact(ready['recipe'])
        baselines[kind] = ready
    (W / 'bin2').mkdir(exist_ok=True)
    m.save(W / 'recipes/resources2.json', dict(command=command))
    m.save(W / 'plan2.json', dict(status='FROZEN_NOT_BUILT', source=m.pin(record['path']), snapshot=snapshot,
        dependencies=m.pin(W / 'precompile-dependencies2.json'), command=command,
        old_object=m.read(W / 'compile/resources/compiled.json')['object'],
        reused_test=frozen['test_object_reuse'], baselines=baselines, tests=CASES,
        scope=frozen['scope'], source_freeze=m.pin(W / 'source-freeze2.json')))
    print('FROZEN resources2 only, 2 links, original test OBJ; GPU not run', flush=True)


def compile_unit():
    plan = m.read(W / 'plan2.json'); exact(plan['source']); exact(plan['snapshot'])
    for row in m.read(plan['dependencies']['path']): exact(row)
    out = W / 'compile/resources2'; out.mkdir(parents=True, exist_ok=False)
    process = h.execute(plan['command'], environment(), W / 'logs/resources2', timeout=240)
    data = m.read(out / 'dependencies.json')['Data']
    assert m.key(data['Source']) == m.key(plan['snapshot']['path'])
    deps = [m.pin(x) for x in dict.fromkeys([data['Source'], *data['Includes']])]
    before = {m.key(x['path']): x for x in m.read(plan['dependencies']['path'])}
    for row in deps: assert row == before[m.key(row['path'])]
    exact(plan['source']); exact(plan['snapshot']); exact(plan['reused_test'])
    m.save(out / 'actual-dependencies.json', deps)
    m.save(out / 'compiled.json', dict(source=plan['snapshot'], original_source=plan['source'],
        object=m.pin(out / 'unit.obj'), process=process,
        command=m.pin(W / 'logs/resources2/command.json'),
        compiler_dependencies=m.pin(out / 'dependencies.json'), actual_dependencies=m.pin(out / 'actual-dependencies.json')))
    print('COMPILED resources2', flush=True)


def link(kind):
    plan = m.read(W / 'plan2.json'); compiled = m.read(W / 'compile/resources2/compiled.json')
    exact(compiled['object']); exact(plan['source']); exact(plan['reused_test'])
    for row in m.read(compiled['actual_dependencies']['path']): exact(row)
    base = plan['baselines'][kind]; old_inputs = m.read(base['inputs']['path'])
    inputs = [compiled['object'] if m.key(x['path']) == m.key(plan['old_object']['path']) else x for x in old_inputs]
    assert len(inputs) == (224 if kind == 'cli' else 241)
    assert sum(m.key(x['path']) == m.key(compiled['object']['path']) for x in inputs) == 1
    for row in inputs: exact(row)
    image = W / 'bin2' / ('hyle.exe' if kind == 'cli' else 'store-source-range-test.exe')
    argv = m.link_command(m.read(base['recipe']['path'])['command'],
        {m.key(plan['old_object']['path']): compiled['object']['path']}, [], image)
    m.save(W / (kind + '-link-inputs2.json'), inputs)
    process = h.execute(argv, environment(), W / ('link-' + kind + '2'), timeout=180)
    m.save(W / ('ready-' + kind + '2.json'), dict(image=m.pin(image), link=process,
        inputs=m.pin(W / (kind + '-link-inputs2.json')), recipe=m.pin(W / ('link-' + kind + '2/command.json')),
        runtime=m.pin(W / 'runtime.json'), plan=m.pin(W / 'plan2.json')))
    print('LINKED ' + kind + ' ' + m.pin(image)['sha256'], flush=True)


def run():
    ready = m.read(W / 'ready-component2.json'); exact(ready['image'])
    for row in m.read(ready['inputs']['path']): exact(row)
    process = h.execute([ready['image']['path'], '--gtest_color=no', '--gtest_fail_fast',
        '--gtest_filter=' + ':'.join(CASES), '--gtest_output=xml:' + str(W / 'run2/results.xml')],
        environment(), W / 'run2', timeout=180)
    tests = ET.parse(W / 'run2/results.xml').getroot().findall('./testsuite/testcase')
    assert sorted(x.attrib['classname'] + '.' + x.attrib['name'] for x in tests) == sorted(CASES)
    assert all(x.find(tag) is None for x in tests for tag in ('failure', 'error', 'skipped'))
    m.save(W / 'summary2.json', dict(status='PASS', process=process, tests=CASES,
        xml=m.pin(W / 'run2/results.xml'), cli=m.pin(W / 'ready-cli2.json'), component=m.pin(W / 'ready-component2.json'),
        final_attempt_counts=dict(CXX=1, links=2, GPU_test_processes=1, passed=6),
        cumulative_counts=dict(CXX=3, links=4, GPU_test_processes=2, SDK=0, NVCC=0, model=0),
        original_failure='run PID27220 exit1 preserved: whole2 PASS, new range1 FAIL, new range1 skipped.',
        scope='Finite continuous range plus original native prepared/whole Source regressions. No R2 compact IDs, full MTP/device pipeline, model or performance run.')))
    print('PASS 6/6, 0 skip', flush=True)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'freeze': freeze()
        elif action == 'compile': compile_unit()
        elif action == 'link': link(sys.argv[2])
        elif action == 'run': run()
        else: raise ValueError(action)
    except BaseException:
        (W / ('failure2-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc())
        raise
