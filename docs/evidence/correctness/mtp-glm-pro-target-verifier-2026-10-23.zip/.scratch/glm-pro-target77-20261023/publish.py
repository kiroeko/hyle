"""Publish only actual four-case original Pro77/78 evidence after root validation.

Usage: python .scratch/glm-pro-target77-20261023/publish.py --link N --run N
No build, network, weight-body hash pass, or product/document update is performed.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import struct
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/glm-pro-nextn-20261023'
D = R / 'docs/evidence/correctness'
REPOSITORY = 'zai-org/GLM-5.3'
REVISION = 'aca966e4e02791568aa6a4ced368624b3d897f42'
OLD = 'OriginalNextNFullVocabularyPublishesAndCatchesUp'
NEW = 'OriginalTarget77AndNextNFullVocabularyVerifier'
MOE_ROLES, MOE_BYTES = 1544, 9706940416
TEXT = {'.h', '.hh', '.hpp', '.c', '.cc', '.cpp', '.py', '.json', '.txt',
        '.log', '.xml', '.ps1', '.diff', '.rsp', '.cmd', '.md'}
ANCHOR = dict(path='docs/evidence/correctness/mtp-dspark-target-verifier-2026-10-23.json',
              bytes=79406, sha256='a175d76b116890529659e462495d8b23a3647f24c4d25c2657fb7d4272e2ac30')
PRIOR = dict(path='docs/evidence/correctness/mtp-glm-pro-nextn-2026-10-23.json',
             bytes=236252, sha256='e2d357ab828b39afecd6d24d5e04c8672fba2b32a5c8bf01d7404c57cde0a16a')
verified = {}
archive_files = set()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def identity(path):
    path = resolve(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path),
                bytes=path.stat().st_size, sha256=digest)


def verify(row):
    path = resolve(row['path'])
    if path not in verified:
        verified[path] = identity(path)
    assert (verified[path]['bytes'], verified[path]['sha256']) == (row['bytes'], row['sha256']), str(path)
    return path


def add(path):
    path = resolve(path)
    assert path.is_relative_to(R) and path.is_file(), str(path)
    assert path.stat().st_size < 10_000_000, str(path)
    assert path.suffix.lower() in TEXT or path.name == 'catalog.bin', str(path)
    archive_files.add(path)
    return path


def integer(props, key):
    value = int(props[key])
    assert value >= 0, (key, value)
    return value


def successful(path):
    record = read(path)
    assert record['exit'] == 0 and record.get('terminal', True)
    assert not record.get('timed_out', False)
    add(path)
    return record


def protection():
    anchor = read(add(verify(ANCHOR)))
    image = anchor['protected_qwen_image']
    expected = image.get('image', image)
    actual = identity(expected['path'])
    assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256'])
    text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    tail = text[text.index('## 最新完整性能对比'):]
    digest = hashlib.sha256(tail.encode()).hexdigest()
    assert digest == anchor['latest_full_performance_unchanged']
    return dict(performance_tail_sha256=digest, qwen_image=image, anchor=ANCHOR)


def plan_headers(plan):
    if 'header_receipt' in plan:
        add(verify(plan['header_receipt']))
    for number, shard in enumerate(plan['shards']):
        raw = add(verify(shard['header'])).read_bytes()
        assert shard['data_base'] == len(raw) + 8
        header = json.loads(raw)
        for row in plan['roles']:
            if row['source_shard'] != number:
                continue
            actual = header[row['name']]
            assert actual['dtype'] == row['dtype'] and actual['shape'] == row['shape']
            assert actual['data_offsets'] == row['data_relative_half_open']
            first, end = actual['data_offsets']
            assert end - first == row['bytes']
            assert row['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
            assert row['absolute_inclusive'][1] < shard['whole_file_bytes']


def acquisition(folder, static_count, static_bytes, supplier, layer):
    """Authenticate metadata/pins and stat bodies; never open a weight body."""
    static_plan_path, moe_plan_path = folder / 'static-plan.json', folder / 'roles-plan.json'
    static_path, moe_path = folder / 'original-static/acquisition.json', folder / 'original-moe/acquisition.json'
    plans = [read(add(path)) for path in (static_plan_path, moe_plan_path)]
    receipts = [read(add(path)) for path in (static_path, moe_path)]
    for plan, receipt, count, size in zip(plans, receipts, (static_count, MOE_ROLES), (static_bytes, MOE_BYTES)):
        assert plan['repository'] == receipt['repository'] == REPOSITORY
        assert plan['revision'] == receipt['revision'] == REVISION
        assert plan['original_roles'] == receipt['original_roles'] == count
        assert receipt['complete'] is True and receipt['role_payload_bytes'] == size
        assert receipt['successful_request_body_bytes'] == size
        assert not receipt.get('whole_shard_downloaded', receipt.get('whole_shards_downloaded', False))
        assert len(plan['roles']) == count and sum(row['bytes'] for row in plan['roles']) == size
        assert receipt['source_plan_sha256'] == identity(receipt['source_plan'])['sha256']
        plan_headers(plan)
    source = add(supplier).read_text(encoding='utf-8-sig')
    pins = {name: (file, pin) for name, file, pin in
            re.findall(r'Spec\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([0-9a-f]{64})"', source)}
    static, moe = receipts
    planned_static = {row['name']: row for row in plans[0]['roles']}
    assert len(static['roles']) == static_count and len(planned_static) == static_count
    vocab = []
    for row in static['roles']:
        expected = planned_static[row['name']]
        for key in ('filename', 'dtype', 'shape', 'bytes', 'source_shard', 'data_relative_half_open', 'absolute_inclusive'):
            assert row[key] == expected[key], (row['name'], key)
        assert row['complete'] is True and row['payload']['bytes'] == row['bytes']
        assert resolve(row['payload']['path']).stat().st_size == row['bytes']
        assert re.fullmatch('[0-9a-f]{64}', row['payload']['sha256'])
        if row['name'] in pins:
            assert pins[row['name']] == (row['filename'], row['payload']['sha256'])
        else:
            assert layer == 78 and row['name'] in ('model.embed_tokens.weight', 'lm_head.weight', 'model.layers.78.shared_head.norm.weight')
            vocab.append(row)
    assert len(pins) == (static_count if layer == 77 else static_count - 3)
    if layer == 78:
        block = re.search(r'kVocabularyPins\{.*?\};', source, re.S).group()
        actual = re.findall(r'"([0-9a-f]{64})"', block)
        by_name = {row['name']: row['payload']['sha256'] for row in vocab}
        assert actual == [by_name[name] for name in ('model.embed_tokens.weight', 'lm_head.weight', 'model.layers.78.shared_head.norm.weight')]
    assert moe['bundle']['bytes'] == MOE_BYTES
    assert resolve(moe['bundle']['path']).stat().st_size == MOE_BYTES
    catalog_path, typed_path = add(verify(moe['catalog'])), add(verify(moe['typed_catalog']))
    catalog, typed = read(catalog_path), typed_path.read_bytes()
    pin = re.search(r'kMoeIndexSha256\s*=\s*"([0-9a-f]{64})"', source).group(1)
    assert pin == moe['typed_catalog']['sha256']
    assert catalog['repository'] == REPOSITORY and catalog['revision'] == REVISION
    assert catalog['original_roles'] == MOE_ROLES and len(catalog['roles']) == MOE_ROLES
    assert catalog['bundle']['bytes'] == MOE_BYTES and catalog['bundle']['sha256'] == moe['bundle']['sha256']
    magic, version, count, size, reserved, digest = struct.unpack('<8sIIQQ32s', typed[:64])
    assert (magic, version, count, size, reserved) == (b'HYGLMM01', 1, MOE_ROLES, MOE_BYTES, 0)
    assert len(typed) == 64 + 16 * MOE_ROLES and digest.hex() == moe['bundle']['sha256']
    for ordinal, (expected, row) in enumerate(zip(plans[1]['roles'], catalog['roles'])):
        assert row['ordinal'] == expected['ordinal'] == ordinal
        for key in ('name', 'dtype', 'shape', 'bytes', 'source_shard', 'data_relative_half_open', 'absolute_inclusive', 'bundle_offset'):
            assert row[key] == expected[key], (ordinal, key)
        assert row['name'].startswith(f'model.layers.{layer}.')
        assert re.fullmatch('[0-9a-f]{64}', row['sha256'])
        assert struct.unpack_from('<QQ', typed, 64 + 16 * ordinal) == (row['bundle_offset'], row['bytes'])
    assert plans[1]['unrequested_bytes'] == 0 and sum(group['bytes'] for group in plans[1]['groups']) == MOE_BYTES
    finalization = moe.get('metadata_finalization', {})
    for key in ('original_process', 'original_stdout'):
        if key in finalization:
            add(verify(finalization[key]))
    return dict(layer=layer, static_receipt=identity(static_path), moe_receipt=identity(moe_path),
                static_roles=static_count, static_bytes=static_bytes, moe_roles=MOE_ROLES, moe_bytes=MOE_BYTES,
                typed_catalog=identity(typed_path), body_sha256=moe['bundle']['sha256'],
                original_roles=static_count + MOE_ROLES, original_bytes=static_bytes + MOE_BYTES,
                vocabulary=[dict(name=row['name'], payload=row['payload']) for row in vocab],
                weight_bodies_rehashed=False, weight_bodies_archived=False)


def compiled_image(attempt):
    folder = S / f'tests-link{attempt}'
    for name in ('ready.json', 'link-plan.json', 'runtime-environment.json'):
        add(folder / name)
    successful(folder / 'link.result.json')
    image = read(folder / 'ready.json')['image']
    verify(image)
    link, runtime = read(folder / 'link-plan.json'), read(folder / 'runtime-environment.json')
    assert all(link[key] == 0 for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
    inputs = {verify(row) for row in link['inputs']}
    records, host, sources = [], [], set()
    for row in link['compiled_records']:
        path = add(verify(row))
        record = read(path)
        assert verify(record['object']) in inputs
        records.append(identity(path))
        if not path.is_relative_to(S):
            continue
        assert path.parent.name == 'glm-pro' and record['source']['path'].endswith('glm_pro_mtp_state_consumer_test.cc')
        number = int(path.parent.parent.name.removeprefix('compile'))
        assert number >= 2, 'Final filled target77 pins require compile2 or later'
        latest = max(S.glob('compile*/glm-pro/identity.json'), key=lambda p: int(p.parent.parent.name[7:]))
        assert path == latest.resolve(), 'Linked host record must be the latest compiled actual source'
        successful(path.with_name('compile.result.json'))
        for item in (record['source'], *record['dependencies']):
            actual = verify(item)
            if actual.is_relative_to(R):
                sources.add(add(actual))
        host.append(dict(record=identity(path), source=record['source'], object=record['object']))
    assert len(host) == 1
    required = {'glm_pro_target_roles.h', 'glm_pro_target_fragment.h', 'glm_pro_target_reference.h',
                'glm_pro_original_roles.h', 'glm_pro_mtp_fragment.h', 'glm_pro_mtp_reference.h',
                'glm_pro_mtp_state_consumer_test.cc', 'model_graph_run.h'}
    assert required <= {path.name for path in sources}
    for row in runtime['staged_dlls']:
        verify(row)
    return dict(image=image, link_plan=identity(folder / 'link-plan.json'),
                runtime=identity(folder / 'runtime-environment.json'), compiled_records=records,
                host=host, sources=[identity(path) for path in sorted(sources)])


def cases(folder, image):
    summary = read(add(folder / 'summary.json'))
    assert summary['image'] == image
    assert summary['process']['exit'] == 0 and not summary['process']['timed_out']
    assert summary['tests'] == len(summary['cases']) == 4
    assert not any(summary[key] for key in ('failures', 'errors', 'disabled', 'skips'))
    assert all(summary.get(key) is False for key in ('throughput_evidence', 'physical_memory_evidence', 'whole_original_model'))
    expected = {f'{backend}{suffix}' for backend in ('Cpu', 'Cuda') for suffix in (OLD, NEW)}
    assert {case['attributes']['name'] for case in summary['cases']} == expected
    graph_counts = {}
    for case in summary['cases']:
        attributes, props = case['attributes'], case['properties']
        name = attributes['name']
        assert attributes['classname'] == 'GlmProMtpStateConsumer'
        assert attributes.get('status') == 'run' and attributes.get('result') == 'completed'
        exact = dict(full_original_nextn_roles=1571, full_original_nextn_source_bytes=13838963840,
                     first_full_nextn_head_reference_values=154880, target_first_full_reference_values=309760,
                     resident_expert_domain=256, resident_expert_capacity=8, natural_k1_trials=1,
                     controlled_matching_trials=1, controlled_rejection_trials=1,
                     target_verifier_submissions=3 if name.endswith(NEW) else 1)
        if name.endswith(NEW):
            exact.update(original_target_roles=1559, original_target_source_bytes=9872042432,
                         first_full_target_projection_reference_values=74304,
                         original_target_expert_domain=256, original_target_resident_capacity=8, target_cache_members=3)
        for key, value in exact.items():
            assert integer(props, key) == value, (name, key, props.get(key))
        positive = ('actual_submissions', 'actual_nextn_steps', 'actual_pending_embedding_feedback_checks',
                    'actual_index_catchup_steps', 'actual_skip_steps', 'accepted_zero_draft_checkpoints',
                    'accepted_one_draft_checkpoints', 'cancelled_unpublished_drafts', 'rejected_stale_publishes')
        assert all(integer(props, key) > 0 for key in positive)
        assert integer(props, 'natural_k1_accepted_drafts') in (0, 1)
        assert integer(props, 'natural_k1_proposal') < 154880
        assert integer(props, 'actual_nextn_steps') == integer(props, 'actual_pending_embedding_feedback_checks')
        assert integer(props, 'accepted_zero_draft_checkpoints') + integer(props, 'accepted_one_draft_checkpoints') == 3
        assert integer(props, 'actual_index_catchup_steps') == integer(props, 'accepted_one_draft_checkpoints')
        assert integer(props, 'peak_state_backing_bytes') <= integer(props, 'state_budget_bytes')
        assert sum(integer(props, key) for key in ('state_pool_backing_bound', 'state_initial_backing_bound', 'state_metadata_backing_bound')) == integer(props, 'state_budget_bytes')
        unions = [int(value) for value in props['actual_resident_union_sizes'].split(',')]
        assert len(unions) == integer(props, 'actual_nextn_steps') and all(0 < value <= 8 for value in unions)
        if name.endswith(NEW):
            assert integer(props, 'actual_target_calls') == integer(props, 'original_target_checked_calls') > 0
            assert integer(props, 'actual_target_submissions') == 2 * integer(props, 'actual_target_calls')
            assert integer(props, 'actual_target_policy_submissions') > 0
            assert integer(props, 'accepted_target_conditioned_repairs') == integer(props, 'accepted_one_draft_checkpoints')
            assert integer(props, 'actual_accepted_kv_repair_submissions') == 2 * integer(props, 'accepted_target_conditioned_repairs')
        if name.startswith('Cuda'):
            assert props['head_provider'] == 'cublasLt'
        graph_counts[name] = integer(props, 'actual_submissions')
    return summary, graph_counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--link', type=int, required=True)
    parser.add_argument('--run', type=int, required=True)
    args = parser.parse_args()
    assert args.link > 0 and args.run > 0
    protected = protection()
    prior = add(verify(PRIOR))
    linked = compiled_image(args.link)
    summary, graphs = cases(S / f'checks{args.run}', linked['image'])
    target = acquisition(S, 15, 165102016, R / 'tests/compute_models/glm_pro_target_roles.h', 77)
    draft = acquisition(P, 27, 4132023424, R / 'tests/compute_models/glm_pro_original_roles.h', 78)
    assert target['typed_catalog']['sha256'] != draft['typed_catalog']['sha256']
    processes_path = add(S / 'acquisition-processes.json')
    processes = read(processes_path)
    failed = [item for item in processes['attempts'] if item.get('terminal') and item.get('exit_code') not in (None, 0)]
    assert any(item['session_id'] == 67609 and item['exit_code'] == 1 for item in failed)
    # Retain every small command/result and the genuine failed acquisition
    # metadata. No source freeze tree, weight bodies, objects, SDK or images.
    for path in S.rglob('*'):
        if path.is_file() and path.suffix.lower() in TEXT and path.name != 'publication.json':
            add(path)
    destination = D / 'mtp-glm-pro-target-verifier-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists()
    assert protection() == protected
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(archive_files):
            zipped.write(path, path.relative_to(R).as_posix())
    record = dict(date='2026-10-23', stage='CA-GLM-target77', goal_complete=False,
        conclusion='Actual Windows CPU/CUDA original target77 to original NextN78/full-V verifier passed; the original78-only CPU/CUDA consumers also passed on the same linked image.',
        artifact=dict(repository=REPOSITORY, revision=REVISION,
                      hf=f'https://huggingface.co/{REPOSITORY}/tree/{REVISION}', target=target, nextn=draft,
                      hidden=6144, vocabulary=154880, upstream_shared_index_layer=74,
                      target_layer=77, nextn_layer=78, extra_weight_hash_pass=False),
        implementation=dict(
            target='Distinct original77 MLA and256-domain Top8/no-clip MoE plus independent model.norm. Shared-index77 consumes explicit upstream74 Top2048; no learned77 indexer is invented or borrowed from78. Actual residual rawsum enters RMS and returns a separate BF16 residual.',
            vocabulary='One original untied154880 BF16 embedding/head bank is shared with78. Real current/proposal77 normalized taps enter one ordinary R2 full-V projection with stable TopK; actual I32 row output lease supplies pending and subsequent original embedding lookup.',
            state='Original77 main576/cursor/normalizedtap joins existing11 draft resources and Epoch metadata in the same StateStore/StateHead. Accept0 retains after-current; accept1 recomputes accepted proposal78 KV/journal from actual current77 tap and keeps actual after-proposal target state before atomic publication and accepted lag catchup. Old readers, cancellation, stale publish and budget gates remain.',
            numerics='Independent original-byte/actual-predecessor local FP8 and BF16 certificates; first full target projections/BMM74304 and target head309760 values, later fixed/selected rows, all stores/norms/attention/routing/state seams. No empirical gate widening or extra native-reference executor.',
            preparation='Both original77 and78 use their own global-grid KV_b decode before compact BF16 key/value split. Strong maps/leases preserve canonical source bytes; no persistent full-F32 weight shadow. Existing ordinary two-phase execution and bounded expert supplies are reused.',
            build='One related host TU is incrementally compiled with final actual pins; existing native/product/runtime caches are linked unchanged. No SDK/CPUworker/NVCC/shader rebuild and no new public operation/executor.'),
        validation=dict(tests=4, failures=0, errors=0, skips=0,
                        graph_submissions=sum(graphs.values()), graph_submissions_by_case=graphs,
                        summary=identity(S / f'checks{args.run}/summary.json'), cases=summary['cases'],
                        process=summary['process'], linked=linked, host_translation_units=1,
                        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0),
        acquisition_processes=dict(metadata=identity(processes_path), failed_attempts_retained=failed,
                                   failures_are_not_relabelled_success=True),
        limitations=['Upstream74 Top2048 IDs, layer76 hidden/residual adapter and finite initial history are explicit synthetic fixture boundaries; this is not a complete78-layer prompt-to-output target engine.',
                     'Natural one-fixture K1 and controlled Top1/Top2 match/reject trials are separate; they do not establish natural acceptance rate or task quality.',
                     'Explicit preparedBF16BMM/non-fused index paths are not a claim of vendor fusion-bit identity.',
                     'No new loading/TPS comparison or measured physical memory/VRAM peak. The protected AV comparison/Q35 image are unchanged; the overall MTP goal is not declared complete.'],
        protection=protected, reused_nextn_evidence=identity(prior), archive=identity(archive), archive_items=len(archive_files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert protection() == protected
    print(json.dumps(dict(**publication, tests=4, graphs=record['validation']['graph_submissions'])))


if __name__ == '__main__':
    main()
