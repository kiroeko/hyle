"""Root-only GLM Pro77 acquisition: three disjoint exact-range workers, existing verified chunks reused."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import datetime
import hashlib
import json
import os
import struct
import threading
import time
import urllib.error
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
CHUNK, IO, WORKERS = 128 * 1024 * 1024, 1024 * 1024, 3
COUNT, BODY_BYTES = 1544, 9706940416
LOCK = threading.RLock()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def small_identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    plan_path = S / 'roles-plan.json'
    plan = read(plan_path)
    assert plan['original_roles'] == COUNT and plan['bundle_bytes'] == BODY_BYTES
    assert not plan['whole_shards_downloaded']
    for shard_index, shard in enumerate(plan['shards']):
        raw = (R / shard['header']['path']).read_bytes()
        assert len(raw) == shard['header']['bytes'] and hashlib.sha256(raw).hexdigest() == shard['header']['sha256']
        header = json.loads(raw)
        for row in plan['roles']:
            if row['source_shard'] != shard_index:
                continue
            actual = header[row['name']]
            assert actual['dtype'] == row['dtype'] and actual['shape'] == row['shape']
            assert actual['data_offsets'] == row['data_relative_half_open']
            first = shard['data_base'] + actual['data_offsets'][0]
            assert row['absolute_inclusive'] == [first, first + row['bytes'] - 1]
    out = S / 'original-moe'
    out.mkdir(exist_ok=True)
    bundle, receipt = out / 'roles.bin', out / 'acquisition.json'
    identity = dict(repository=plan['repository'], revision=plan['revision'], original_roles=COUNT,
                    source_plan=plan_path.relative_to(R).as_posix(), source_plan_sha256=small_identity(plan_path)['sha256'],
                    bundle_bytes=BODY_BYTES, whole_shards_downloaded=False, unrequested_bytes=0)
    if receipt.exists():
        record = read(receipt)
        assert all(record[key] == value for key, value in identity.items())
    else:
        assert not bundle.exists()
        record = dict(**identity, complete=False, chunk_bytes=CHUNK, stream_buffer_bytes=IO, workers=WORKERS,
                      requests=[], chunks=[], groups=plan['groups'], shards=plan['shards'], errors=[])
        # Only one allocation; concurrent handles later write disjoint verified intervals.
        with bundle.open('xb') as stream:
            stream.truncate(BODY_BYTES)
    if bundle.stat().st_size != BODY_BYTES:
        assert not record['complete'] and bundle.stat().st_size <= BODY_BYTES
        with bundle.open('r+b') as stream:
            stream.truncate(BODY_BYTES)
    record.setdefault('errors', [])

    def save_locked():
        temporary = receipt.with_suffix('.json.next')
        with temporary.open('w', encoding='utf-8', newline='\n') as stream:
            json.dump(record, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, receipt)

    # Every job is a deterministic exact source interval. Receipt chunks may
    # complete out of order; a missing interval is never treated as data.
    jobs, known = [], {}
    for group in plan['groups']:
        for offset in range(group['bundle_offset'], group['bundle_offset']+group['bytes'], CHUNK):
            size=min(CHUNK,group['bundle_offset']+group['bytes']-offset)
            job=dict(group=group,offset=offset,bytes=size)
            assert offset not in known
            known[offset]=job
            jobs.append(job)
    verified=set()
    with bundle.open('rb') as stream:
        for part in record['chunks']:
            job=known[part['offset']];group=job['group']
            assert part['offset'] not in verified and part['bytes']==job['bytes'] and part['group']==group['index']
            first=group['first']+part['offset']-group['bundle_offset']
            assert part['absolute_inclusive']==[first,first+part['bytes']-1]
            stream.seek(part['offset']);remaining=part['bytes'];digest=hashlib.sha256()
            while remaining:
                raw=stream.read(min(IO,remaining));assert raw
                digest.update(raw);remaining-=len(raw)
            assert digest.hexdigest()==part['sha256']
            verified.add(part['offset'])
    pending=[job for job in jobs if job['offset'] not in verified]
    if record['complete']:
        assert not pending
        assert small_identity(out / 'catalog.bin') == record['typed_catalog']
        print('REUSED complete authenticated bundle intervals', BODY_BYTES, flush=True)
        return
    with LOCK:
        save_locked()

    def acquire_group(job):
        group = job['group']
        offset = job['offset']
        end = offset + job['bytes']
        shard = plan['shards'][group['source_shard']]
        while offset < end:
            size = min(CHUNK, end - offset)
            first = group['first'] + offset - group['bundle_offset']
            last = first + size - 1
            attempt = dict(group=group['index'], offset=offset, first=first, last=last,
                           requested_bytes=size, complete=False, started_utc=now())
            with LOCK:
                record['requests'].append(attempt)
                save_locked()
            print('REQUEST', group['index'], offset, size, flush=True)
            request = urllib.request.Request(shard['url'], headers={
                'Range': f'bytes={first}-{last}', 'If-Range': shard['etag'],
                'Accept-Encoding': 'identity', 'User-Agent': 'hyle-formal-dspark-tail/1'})
            try:
                for retry in range(5):
                    try:
                        response = urllib.request.urlopen(request, timeout=60)
                        break
                    except (urllib.error.URLError, TimeoutError, OSError) as error:
                        with LOCK:
                            attempt.setdefault('transport_errors', []).append(dict(type=type(error).__name__, error=str(error), utc=now()))
                            save_locked()
                        if retry == 4:
                            raise
                        time.sleep(2)
                with response:
                    expected = f'bytes {first}-{last}/{shard["whole_file_bytes"]}'
                    assert response.status == 206 and response.headers.get('Content-Range') == expected
                    assert response.headers.get('ETag') == shard['etag']
                    assert response.headers.get('Content-Encoding') in (None, 'identity')
                    assert response.headers.get('Content-Length') in (None, str(size))
                    digest = hashlib.sha256()
                    with bundle.open('r+b') as stream:
                        stream.seek(offset)
                        remaining = size
                        while remaining:
                            data = response.read(min(IO, remaining))
                            assert data, 'Early EOF'
                            stream.write(data)
                            digest.update(data)
                            remaining -= len(data)
                        assert not response.read(1), 'Overlong range body'
                        stream.flush()
                        os.fsync(stream.fileno())
                part = dict(offset=offset, bytes=size, sha256=digest.hexdigest(), group=group['index'],
                            absolute_inclusive=[first, last])
                with LOCK:
                    record['chunks'].append(part)
                    attempt.update(complete=True, http_status=206, content_range=expected,
                                   etag=shard['etag'], bytes=size, sha256=part['sha256'], finished_utc=now())
                    save_locked()
                offset += size
                print('VERIFIED', group['index'], offset - group['bundle_offset'], '/', group['bytes'], flush=True)
            except Exception as error:
                with LOCK:
                    attempt.update(error_type=type(error).__name__, error=str(error), finished_utc=now())
                    save_locked()
                raise
        return group['index'], offset

    failures = []
    with ThreadPoolExecutor(max_workers=WORKERS) as workers:
        futures = [workers.submit(acquire_group, job) for job in pending]
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as error:
                failures.append(error)
    if failures:
        with LOCK:
            record['errors'].extend(dict(type=type(error).__name__, error=str(error), utc=now()) for error in failures)
            save_locked()
        raise failures[0]
    assert len(record['chunks']) == len(jobs)
    assert {part['offset'] for part in record['chunks']} == set(known)
    assert bundle.stat().st_size == BODY_BYTES
    # One bounded final pass computes whole-bundle and every original-role SHA.
    # There is no second10GB copy or per-role file materialization.
    roles = [dict(row) for row in plan['roles']]
    digest, cursor = hashlib.sha256(), 0
    with bundle.open('rb') as stream:
        for row in sorted(roles, key=lambda row: row['bundle_offset']):
            assert row['bundle_offset'] == cursor
            remaining, role_digest = row['bytes'], hashlib.sha256()
            while remaining:
                data = stream.read(min(IO, remaining))
                assert data
                digest.update(data)
                role_digest.update(data)
                remaining -= len(data)
            row['sha256'] = role_digest.hexdigest()
            cursor += row['bytes']
        assert not stream.read(1)
    assert cursor == BODY_BYTES
    bundle_sha = digest.hexdigest()
    catalog = dict(repository=plan['repository'], revision=plan['revision'], original_roles=COUNT,
                   bundle=dict(file='roles.bin', bytes=BODY_BYTES, sha256=bundle_sha),
                   typed_order='router,bias,shared gate/up/down code/SF; expert0..255 each gate/up/down code/SF', roles=roles)
    catalog_path = out / 'catalog.json'
    catalog_path.write_text(json.dumps(catalog, indent=2)+'\n', encoding='utf-8')
    header = struct.pack('<8sIIQQ32s', b'HYGLMM01', 1, COUNT, BODY_BYTES, 0, bytes.fromhex(bundle_sha))
    index = header + b''.join(struct.pack('<QQ', row['bundle_offset'], row['bytes']) for row in roles)
    assert len(index) == 64 + COUNT * 16
    (out / 'catalog.bin').write_bytes(index)
    with LOCK:
        record.update(complete=True, role_payload_bytes=BODY_BYTES,
                      successful_request_body_bytes=sum(row['bytes'] for row in record['requests'] if row['complete']),
                      bundle=dict(path=bundle.relative_to(R).as_posix(), bytes=BODY_BYTES, sha256=bundle_sha),
                      catalog=small_identity(catalog_path), typed_catalog=small_identity(out / 'catalog.bin'),
                      finished_utc=now())
        assert record['successful_request_body_bytes'] == BODY_BYTES
        assert sum(row['bytes'] for row in record['chunks']) == BODY_BYTES
        save_locked()
    print('COMPLETE', COUNT, BODY_BYTES, record['typed_catalog']['sha256'], flush=True)


if __name__ == '__main__':
    main()
