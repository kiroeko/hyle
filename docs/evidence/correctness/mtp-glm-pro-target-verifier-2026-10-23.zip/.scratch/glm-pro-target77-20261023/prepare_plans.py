"""Prepare exact original Pro target77/finalnorm and MoE ranges from cached headers.

Metadata only: no requests, payload reads, build or inference. Run after root's
three strict missing-header acquisitions have completed. Offsets are never inferred from
the Flash checkpoint or a guessed safetensors header length.
"""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
REPOSITORY = 'zai-org/GLM-5.3'
REVISION = 'aca966e4e02791568aa6a4ced368624b3d897f42'
PREFIX = 'model.layers.77.'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    raw = path.read_bytes()  # Only bounded stage metadata/header files.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    cached = read(S / 'cached-roles.json')
    summary_path = S / 'headers/summary.json'
    receipt = read(summary_path)
    assert cached['repository'] == receipt['repository'] == REPOSITORY
    assert cached['revision'] == receipt['revision'] == REVISION
    assert receipt['complete'] and not receipt['whole_shards_downloaded']
    expected = [f'model-{number:05d}-of-00141.safetensors' for number in (134, 135, 136, 141)]
    cached136 = read(R / '.scratch/glm-pro-nextn-20261023/headers/model-00136-of-00141/receipt.json')
    sources = sorted(receipt['shards'] + [cached136], key=lambda row: row['file'])
    assert [row['file'] for row in sources] == expected
    shards, headers = [], []
    for source in sources:
        assert source['complete'] and source['repository'] == REPOSITORY and source['revision'] == REVISION
        assert identity(R / source['header']['path']) == source['header']
        assert identity(R / source['length_prefix']['path']) == source['length_prefix']
        raw = (R / source['header']['path']).read_bytes()
        assert source['data_base'] == 8 + len(raw)
        shards.append({key: source[key] for key in ('file', 'url', 'etag', 'whole_file_bytes', 'data_base', 'header')})
        headers.append(json.loads(raw))
    shard_ids = {row['file']: slot for slot, row in enumerate(shards)}
    audit = {row['name']: row for row in cached['roles']}
    assert len(audit) == 1559

    def role(name):
        previous = audit[name]
        slot = shard_ids[previous['shard']]
        exact = headers[slot][name]
        for key in ('dtype', 'shape', 'data_offsets'):
            assert exact[key] == previous[key], (name, key)
        first, end = exact['data_offsets']
        base = shards[slot]['data_base']
        assert 0 <= first < end <= shards[slot]['whole_file_bytes'] - base
        return dict(name=name, dtype=exact['dtype'], shape=exact['shape'], bytes=end-first,
                    source_shard=slot, data_relative_half_open=[first, end],
                    absolute_inclusive=[base+first, base+end-1])

    static_names = [
        ('input_layernorm.weight', 'input_layernorm.weight.bf16', 'input'),
        ('post_attention_layernorm.weight', 'post_attention_layernorm.weight.bf16', 'postnorm'),
        ('self_attn.kv_a_layernorm.weight', 'kv_a_layernorm.weight.bf16', 'MLA'),
        ('self_attn.kv_a_proj_with_mqa.weight', 'kv_a.weight.e4m3', 'MLA'),
        ('self_attn.kv_a_proj_with_mqa.weight_scale_inv', 'kv_a.weight_scale.f32', 'MLA'),
        ('self_attn.kv_b_proj.weight', 'kv_b.weight.e4m3', 'MLA'),
        ('self_attn.kv_b_proj.weight_scale_inv', 'kv_b.weight_scale.f32', 'MLA'),
        ('self_attn.o_proj.weight', 'o.weight.e4m3', 'MLA'),
        ('self_attn.o_proj.weight_scale_inv', 'o.weight_scale.f32', 'MLA'),
        ('self_attn.q_a_layernorm.weight', 'q_a_layernorm.weight.bf16', 'query'),
        ('self_attn.q_a_proj.weight', 'q_a.weight.e4m3', 'query'),
        ('self_attn.q_a_proj.weight_scale_inv', 'q_a.weight_scale.f32', 'query'),
        ('self_attn.q_b_proj.weight', 'q_b.weight.e4m3', 'MLA'),
        ('self_attn.q_b_proj.weight_scale_inv', 'q_b.weight_scale.f32', 'MLA'),
    ]
    static = []
    for suffix, filename, component in static_names:
        row = role(PREFIX + suffix)
        row.update(filename=filename, component=component, ordinal=len(static))
        static.append(row)
    row = role('model.norm.weight')
    row.update(filename='target_norm.weight.bf16',component='target-finalnorm',ordinal=len(static))
    static.append(row)
    assert len(static) == 15 and sum(row['bytes'] for row in static) == 165102016
    moe_names = [PREFIX + 'mlp.gate.weight', PREFIX + 'mlp.gate.e_score_correction_bias']
    for name in ('gate', 'up', 'down'):
        for suffix in ('weight', 'weight_scale_inv'):
            moe_names.append(PREFIX + f'mlp.shared_experts.{name}_proj.{suffix}')
    for expert in range(256):
        for name in ('gate', 'up', 'down'):
            for suffix in ('weight', 'weight_scale_inv'):
                moe_names.append(PREFIX + f'mlp.experts.{expert}.{name}_proj.{suffix}')
    moe = [dict(role(name), ordinal=ordinal) for ordinal, name in enumerate(moe_names)]
    assert len(moe) == 1544 and sum(row['bytes'] for row in moe) == 9706940416
    assert moe[0]['dtype'] == 'BF16' and moe[0]['shape'] == [256, 6144]
    assert moe[1]['dtype'] == 'F32' and moe[1]['shape'] == [256]
    groups = []
    for slot in range(len(shards)):
        selected = sorted((row for row in moe if row['source_shard'] == slot), key=lambda row: row['absolute_inclusive'][0])
        for row in selected:
            first, last = row['absolute_inclusive']
            if groups and groups[-1]['source_shard'] == slot and groups[-1]['last'] + 1 == first:
                group = groups[-1]
                group['last'] = last
                group['bytes'] += row['bytes']
                group['roles'].append(row['ordinal'])
            else:
                groups.append(dict(source_shard=slot, first=first, last=last, bytes=row['bytes'], roles=[row['ordinal']]))
    offset = 0
    for number, group in enumerate(groups):
        group.update(index=number, bundle_offset=offset)
        assert group['last'] - group['first'] + 1 == group['bytes']
        for ordinal in group['roles']:
            row = moe[ordinal]
            row['bundle_offset'] = offset + row['absolute_inclusive'][0] - group['first']
        offset += group['bytes']
    assert offset == 9706940416
    all_names = {row['name'] for row in static + moe}
    assert len(all_names) == 1559 and set(audit) == all_names
    assert sum(row['bytes'] for row in static + moe) == 9872042432
    provenance = dict(repository=REPOSITORY, revision=REVISION, layer=77,
                      header_receipt=identity(summary_path), cached_audit_extract=identity(S / 'cached-roles.json'))
    save(S / 'static-plan.json', dict(**provenance, original_roles=15,
        expected_role_payload_bytes=165102016, shards=shards, roles=static,
        output_directory='original-static', whole_shards_downloaded=False))
    save(S / 'roles-plan.json', dict(**provenance, original_roles=1544, bundle_bytes=offset,
        shards=shards, roles=moe, groups=groups, output_directory='original-moe',
        typed_order='router,bias,shared gate/up/down code/SF; expert0..255 each gate/up/down code/SF',
        whole_shards_downloaded=False, unrequested_bytes=0))
    save(S / 'plan-summary.json', dict(**provenance,full_roles=1559,full_bytes=9872042432,
        static_roles=15,static_bytes=165102016,moe_roles=1544,moe_bytes=offset,
        expert_roles=1536,expert_bytes=9666035712,one_selected_expert_bytes=37757952,
        plans=[identity(S/'static-plan.json'),identity(S/'roles-plan.json')],
        scope='Original target77 shared-index MLA/MoE plus distinct model.norm. Hidden/residual from layer76 and Top2048 from layer74 are explicit upstream boundaries. Original layer78 vocabulary and NextN roles are reused, never substituted for77.'))
    print(json.dumps(dict(static_roles=15,static_bytes=165102016,moe_roles=1544,moe_bytes=offset,total_roles=1559,total_bytes=9872042432)))

if __name__ == '__main__':
    main()
