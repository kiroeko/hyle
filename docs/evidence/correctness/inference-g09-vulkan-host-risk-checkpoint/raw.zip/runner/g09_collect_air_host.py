from pathlib import Path
import hashlib,json,sys,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');route=sys.argv[1]
assert route in ['apple','vulkan']
cases=[]
archive=base/f'g09-{route}-host-checkpoint.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
    for mode in ['asan','ubsan','tsan']:
        out=base/f'g09-{route}-host-{mode}-1'
        r=json.loads((out/'result.json').read_text())
        assert r['state'] in ['HOST_FACET_PASS','FAIL_WITH_ALL_TARGETS_OBSERVED']
        for a in r['binaries']:assert hashlib.sha256(Path(a['path']).read_bytes()).hexdigest()==a['sha256']
        tests=[]
        for name in ['g09_common','g09_executable']:
            t=json.loads((out/(name+'.json')).read_text())
            assert t['failures']==0 and t['disabled']==0
            tests.append({'target':name,**{k:t[k] for k in ['tests','failures','disabled']}})
        cases.append({'mode':mode,'result':r,'gtest_execution_totals':tests})
        for p in sorted(out.iterdir()):
            if p.is_file():z.write(p,mode+'/'+p.name)
        parent=Path(r['build']).parent/'parent/CMakeLists.txt'
        z.write(parent,mode+'/candidate-parent.cmake')
        if mode=='tsan':
            for i,m in enumerate(r['models']):
                p=Path(m['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==m['sha256']
                z.write(p,mode+'/existing-models/'+str(i)+'-'+p.name)
    z.write(base/'g09-host-risk-inputs/inputs.json','inputs/source-inputs.json')
    z.write(base/'g09-host-risk-inputs/g09_air_host_risk.py','runner/g09_air_host_risk.py')
    z.writestr('cases.json',json.dumps(cases,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'states':[c['result']['state'] for c in cases]}))
