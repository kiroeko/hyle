from pathlib import Path
import json,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');route=sys.argv[1]
assert route=='vulkan'
script=base/'g09-host-risk-inputs/g09_air_host_risk.py'
out=base/'g09-vulkan-host-matrix-1.json';assert not out.exists()
r={'state':'RUNNING','route':route,'stages':[],'serial':True};started=time.monotonic()
for mode in ['asan','ubsan','tsan']:
    assert not (base/f'g09-{route}-host-{mode}-1').exists()
    code=subprocess.call([sys.executable,str(script),route,mode])
    p=base/f'g09-{route}-host-{mode}-1/result.json'
    result=json.loads(p.read_text()) if p.is_file() else {}
    r['stages'].append({'mode':mode,'exit_code':code,'state':result.get('state')})
    r['elapsed_seconds']=time.monotonic()-started;out.write_text(json.dumps(r,indent=2)+'\n')
    if code:break
r['state']='HOST_MATRIX_PASS' if len(r['stages'])==3 and all(s['state']=='HOST_FACET_PASS' for s in r['stages']) else 'HOST_MATRIX_REQUIRES_FINITE_REVIEW'
r['elapsed_seconds']=time.monotonic()-started;out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
