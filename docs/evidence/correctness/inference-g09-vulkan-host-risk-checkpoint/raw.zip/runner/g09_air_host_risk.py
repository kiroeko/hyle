from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');route,mode=sys.argv[1:3]
assert route in ['apple','vulkan'] and mode in ['asan','ubsan','tsan']
source=base/'source-c8874688';parent=base/f'foundation-f5-native-host-{route}-{mode}/parent';build=parent.parent/'build'
out=base/f'g09-{route}-host-{mode}-1';out.mkdir(exist_ok=False)
manifest=json.loads((base/'g09-host-risk-inputs/inputs.json').read_text())
env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),
         OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',
         UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0',HYLE_VULKAN_VALIDATION='0')
os.nice(10)
r={'state':'SETUP','route':route,'mode':mode,'stages':[],'source':str(source),'source_tree':manifest['tree'],'canonical_head':manifest['head'],
   'pid':os.getpid(),'max_jobs':4,'nice':os.nice(0),'build':str(build),
   'scope':'Changed Graph/common and CPU/native owner host sanitizer facets, original direct Graph contracts, two-slot/65-step joint math/cancel consumer and original G06 pending native joint receiver. No shader/driver/private pool/leak/SDK/P1 certificate.',
   'retained_limits':'Original G06/G08 refcount-fence TSan model; Apple original Metal external-completion model. No new model or broad suppression.'}
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args,timeout=1800,required=True):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(route,mode,stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(a) for a in args],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if p.poll() is None:r.setdefault('time_extensions',[]).append({'stage':stage,'seconds':timeout,'pid':p.pid});save();continue
                code=p.returncode;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        print((out/(stage+'.log')).read_text(errors='replace')[-14000:],flush=True)
        if required:r['state']='FAIL';save();raise SystemExit(code)
    return code
r['identity']={k:subprocess.check_output(v,text=True,env=env).strip() for k,v in {'model':['sysctl','-n','hw.model'],'chip':['sysctl','-n','machdep.cpu.brand_string'],
    'system':['sw_vers'],'compiler':['xcrun','clang++','--version'],'metal':['xcrun','-sdk','macosx','metal','--version']}.items()}
assert r['identity']['model']=='Mac16,12'
cache=(build/'CMakeCache.txt').read_text();assert f'HYLE_SANITIZER:STRING={mode}' in cache and 'HYLE_STATIC:BOOL=ON' in cache
assert 'HYLE_COMPUTE_ROUTES:STRING=cpu;'+route in cache
with zipfile.ZipFile(base/'g09-host-risk-inputs/source.zip') as z:
    changed=[]
    for item in manifest['files']:
        relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
        p=source/relative;assert p.resolve().is_relative_to(source.resolve())
        data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        if not p.is_file() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
    r['synced_paths']=changed
cmake=parent/'CMakeLists.txt';text=cmake.read_text();assert 'add_executable(g09_common' not in text
(out/'original-parent.cmake').write_text(text)
models=[]
if mode=='tsan':
    ref=base/'g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h'
    body=ref.read_text().replace('#include <sanitizer/tsan_interface.h>\n','').replace('    __tsan_acquire(const_cast<std::atomic<std::uint32_t>*>(&value_));\n','')
    body=body.replace('  void acquire_before_destroy() const noexcept {','  static void acquire_before_destroy() noexcept {').replace('      refcount_.acquire_before_destroy();','      decltype(refcount_)::acquire_before_destroy();')
    assert body==(source/'include/hyle/util/ref_counted.h').read_text()
    assert hashlib.sha256(ref.read_bytes()).hexdigest()=='2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
    models.append(ref.parents[2]);r['models']=[{'path':str(ref),'sha256':hashlib.sha256(ref.read_bytes()).hexdigest()}]
    if route=='apple':
        dirs=re.findall(r'target_include_directories\(g08_host_joint BEFORE PRIVATE "([^"]+)"\)',text)
        metal_root=next(Path(p) for p in dirs if 'metal-tsan-' in p);metal=metal_root/'Metal/MTLCommandBuffer.hpp'
        assert hashlib.sha256(metal.read_bytes()).hexdigest()=='4a58c6e564e3a7efcdf5c7709eeee99ec7b7c40594e2ada5ec5c91012171d504'
        product=metal_root.parent/metal_root.name.replace('metal-tsan-','metal-product-');assert product.is_dir()
        for p in product.rglob('*'):
            if p.is_file():
                rel=p.relative_to(product);assert rel.as_posix()=='Metal/MTLCommandBuffer.hpp' or (metal_root/rel).read_bytes()==p.read_bytes()
        models.append(metal_root);r['models'].append({'path':str(metal),'sha256':hashlib.sha256(metal.read_bytes()).hexdigest(),'unchanged_product_tree':str(product)})
targets=[]
for name,files,includes in [
    ('g09_common',['graph_test.cc','lease_submission_test.cc','native_variants_test.cc','effect_preflight_test.cc','joint_pipeline_test.cc'],'src/graph'),
    ('g09_executable',['executable_test.cc','custom_kernel_test.cc','region_provider_test.cc'],'src/compute'),
    ('g09_contracts',[f'cpu_{route}_contracts.cc'],None),('g09_pipeline',['native_joint_pipeline.cc'],None)]:
    text+='\nadd_executable('+name+'\n'+''.join('  "'+str(source/'tests/graph'/file)+'"\n' for file in files)+')\n'
    text+='target_link_libraries('+name+' PRIVATE hyle::graph GTest::gtest_main)\n'
    if includes:text+='target_include_directories('+name+' PRIVATE "'+str(source/includes)+'")\n'
    if name=='g09_pipeline' and route=='apple':text+='target_compile_definitions('+name+' PRIVATE HYLE_G09_APPLE=1)\n'
    targets.append(name)
text+='add_executable(g09_pending "'+str(source/'tests/compute_batch/pending_paged_receiver_native_consumer.cc')+'")\n'
text+='target_link_libraries(g09_pending PRIVATE hyle::graph hyle::compute)\ntarget_compile_definitions(g09_pending PRIVATE HYLE_PENDING_NATIVE_JOINT_GRAPH=1)\n'
if route=='apple':text+='target_compile_definitions(g09_pending PRIVATE HYLE_PENDING_RECEIVER_APPLE=1)\n'
targets.append('g09_pending')
for target in targets:
    text+='target_compile_features('+target+' PRIVATE cxx_std_23)\nhyle_apply_sanitizer('+target+')\nhyle_stage_runtime('+target+')\n'
    for path in models:text+='target_include_directories('+target+' BEFORE PRIVATE "'+str(path)+'")\n'
cmake.write_text(text)
ninja='/opt/homebrew/bin/ninja'
run('configure',['/opt/homebrew/bin/cmake','-S',parent,'-B',build])
commands=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb'],env=env,text=True))
flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
selected=[c for c in commands if c['file'].endswith(('/src/graph/executable.cc',f'/src/graph_route_cpu_{route}/compile.cc',f'/src/graph_route_cpu_{route}/invocation.cc'))]
assert len(selected)==3 and all(flag in c['command'] for c in selected)
(out/'instrumented-inputs.json').write_text(json.dumps(selected,indent=2)+'\n')
run('manifest',[ninja,'-C',build,'build.ninja'])
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
if route=='vulkan':
    sys.path.insert(0,str(base/'g06-final-host-air'));from reuse_current_vulkan_generated import apply
    r['generated_shader_reuse']=apply(build,preview,out,'g09-'+mode+'-1')
dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
(out/'dry-run.log').write_text(dry);r['dry_run_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<180 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry and 'Generate vulkan shaders' not in dry,dry
run('build',[ninja,'-C',build,'-f',preview,'-j','4',*targets])
failures=[]
for target in targets:
    binary=build/target;args=[str(binary)]
    if target in ['g09_common','g09_executable']:args+=['--gtest_output=json:'+str(out/(target+'.json'))]
    if run(target,args,600,False):failures.append(target)
    r.setdefault('binaries',[]).append({'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
for item in manifest['files']:assert hashlib.sha256((source/item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['failures']=failures;r['state']='HOST_FACET_PASS' if not failures else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save();print(json.dumps({'route':route,'mode':mode,'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
