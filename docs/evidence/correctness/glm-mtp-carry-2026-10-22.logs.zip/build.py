"""Incrementally compile the GLM carry consumer on the matched AZ closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AZ = R / '.scratch/qwen24-original-mtp-20261022'
spec = importlib.util.spec_from_file_location('glm_cached', AZ / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = AZ / 'tests-link1'
SOURCE = R / 'tests/compute_models/glm_mtp_index_carry_test.cc'

def compile_one(attempt):
    old = c.read(AZ / 'compile1/q24-kv/identity.json')
    old['command'] = [x for x in old['command'] if not x.startswith('/DHYLE_TEST_Q24_')]
    old['command'] += ['/DHYLE_TEST_GLM_CARRY_CPU=1', '/DHYLE_TEST_GLM_CARRY_CUDA=1']
    recipe = S / 'recipes/glm-carry.json'
    recipe.parent.mkdir(parents=True, exist_ok=True)
    c.save(recipe, old)
    h.RECIPES['glm-carry'], h.SOURCES['glm-carry'] = recipe, SOURCE
    h.compile_one('glm-carry', attempt)

def link(attempt):
    records = sorted(S.glob('compile*/glm-carry/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    assert records
    record_path = records[-1]
    record = c.read(record_path)
    assert all(b.identity(x['path']) == x for x in [record['source'], record['object'], *record['dependencies']])
    base = c.read(BASE / 'link-plan.json')
    remove = set()
    for item in base['compiled_records']:
        rec = c.read(item['path'])
        if '/tests/' in rec['source']['path'].replace('\\', '/'):
            remove.add(c.key(rec['object']['path']))
    inputs = [record['object']] + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command.insert(1, record['object']['path'])
    folder = S / f'tests-link{attempt}'
    folder.mkdir()
    (folder / 'tmp').mkdir()
    image = folder / 'glm-carry-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(folder / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(record_path)], base=b.identity(BASE / 'link-plan.json'),
        SDK_builds=0, NVCC_builds=0, shader_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], folder)
    c.execute('link', command, env, folder)
    runtime = c.read(BASE / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        os.link(item['path'], folder / Path(item['path']).name)
    runtime['staged_dlls'] = [b.identity(path) for path in folder.glob('*.dll')]
    c.save(folder / 'runtime-environment.json', runtime)
    c.save(folder / 'ready.json', dict(image=b.identity(image)))
    print('LINKED', image, flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('actions', nargs='+', choices=['compile', 'link'])
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    for action in args.actions:
        compile_one(args.attempt) if action == 'compile' else link(args.attempt)
