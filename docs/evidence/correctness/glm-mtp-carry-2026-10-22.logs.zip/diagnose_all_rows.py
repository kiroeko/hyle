"""Offline dense original-role diagnosis of the already captured failure."""
from pathlib import Path
import importlib.util
import json
import numpy as np

S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('independent_qa', S / 'original-chain-source/diagnose_qa.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
D = S / 'diagnostics2'
nx = np.fromfile(D / 'cuda-generation-0-nx.bf16', dtype='<u2').astype('<u4')
x = (nx << 16).view('<f4')
actual = (np.fromfile(D / 'cuda-generation-0-qa.bf16', dtype='<u2').astype('<u4') << 16).view('<f4')
codes, scales = h.quantize(x.tolist(), 'divide')
table = np.asarray([h.e4(c) if c & 127 != 127 else np.nan for c in range(256)], dtype=np.float64)
encoded = np.fromfile(S / 'original-glm-q-a/q_a.weight.e4m3', dtype='u1').reshape(1536, 32, 128)
wcodes = table[encoded]
wscale = np.fromfile(S / 'original-glm-q-a/q_a.weight_scale.f32', dtype='<f4').reshape(12, 32)
expanded_scale = np.repeat(wscale, 128, axis=0)
activation = table[codes].reshape(32, 128)
dot = (wcodes * activation[None, :, :]).sum(axis=2).astype(np.float32)
scaled = dot * np.asarray(scales, dtype=np.float32)[None, :]
acc = np.zeros(1536, dtype=np.float32)
for group in range(32):
    # Original multiplier values are all powers of two; the product is exact
    # at these finite magnitudes, so fused/unfused F32 adds have equal bits.
    acc += scaled[:, group] * expanded_scale[:, group]
words = acc.view('<u4').copy()
words += np.uint32(0x7fff) + ((words >> np.uint32(16)) & np.uint32(1))
expected = ((words >> 16).astype('<u4') << 16).view('<f4')
delta = actual.astype(np.float64) - expected.astype(np.float64)
gate = 0.008 * np.abs(expected.astype(np.float64)) + 0.0001
weight = (wcodes * expanded_scale[:, :, None]).reshape(1536, 4096)
numerator = weight.T @ delta
norm = np.sqrt((weight * weight).sum(axis=0))
cosine = numerator / np.maximum(norm * np.linalg.norm(delta), 1e-300)
columns = np.argsort(np.abs(cosine))[-5:][::-1]
report = dict(scope='Offline existing1536-row failure; no new native execution or gate change',
    nonidentical_bf16=int(np.count_nonzero(delta)), failed_existing_gate=int(np.count_nonzero(np.abs(delta) > gate)),
    max_absolute_error=float(np.max(np.abs(delta))), RMSE=float(np.sqrt(np.mean(delta * delta))),
    actual_peak=float(np.max(np.abs(actual))), reference_peak=float(np.max(np.abs(expected))),
    worst_rows=[dict(row=int(r), actual=float(actual[r]), expected=float(expected[r]),
        error=float(delta[r]), gate=float(gate[r])) for r in np.argsort(np.abs(delta))[-8:][::-1]],
    single_activation_column_hypotheses=[dict(column=int(c), cosine=float(cosine[c]),
        input=float(x[c]), expected_code=int(codes[c]),
        least_squares_code_delta=float(numerator[c] / max(norm[c] ** 2, 1e-300) / scales[c // 128]))
        for c in columns])
(D / 'all-rows-offline.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
