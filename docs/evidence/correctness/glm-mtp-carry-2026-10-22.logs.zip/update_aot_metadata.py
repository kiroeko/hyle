"""Align shipped GEMM compilation facts with the installed precise images."""
from pathlib import Path
import copy
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
T = R / 'third_party/sglang_activation/fp8'
generated = json.loads((S / 'maintainer-regeneration/compilation.json').read_text(encoding='utf-8'))
candidate = json.loads((S / 'bf16-tile-candidate2/compilation.json').read_text(encoding='utf-8'))
new = {x['label']: x for x in generated['kernels'] if not x.get('preserved')}
assert len(new) == 2
for job in candidate['kernels']:
    assert job['sha256'] == new[job['label']]['sha256']
before = S / 'repair-metadata/before'
before.mkdir(parents=True, exist_ok=False)
for name in ['compilation.json', 'dynamic-compilation.json']:
    path = T / name
    (before / name).write_bytes(path.read_bytes())
    report = json.loads(path.read_text(encoding='utf-8'))
    for job in report['kernels']:
        if job['label'] not in new:
            continue
        actual = new[job['label']]
        assert all(job[key] == actual[key] for key in ('signature', 'constexprs', 'options'))
        metadata = copy.deepcopy(actual['metadata'])
        metadata['target'] = dict(backend='cuda', arch=89, warp_size=32)
        job['metadata'] = metadata
        job['cubin_sha256'] = actual['sha256']
        job.pop('seconds', None)
    report['matmul_adaptation'] = generated['adaptation']
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print('Aligned two GEMM records; quantizer records unchanged.')
