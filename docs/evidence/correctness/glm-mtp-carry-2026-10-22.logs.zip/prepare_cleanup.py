"""Plan exact retired native test images; keep source, objects, inputs and DLLs."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
keep = S / 'chain-link4/glm-original-chain-checks.exe'
summary = json.loads((S / 'chain-checks4/summary.json').read_text(encoding='utf-8'))
assert summary['tests'] == 7 and summary['failures'] == 0
assert hashlib.sha256(keep.read_bytes()).hexdigest() == summary['image']['sha256']
parents = [R / '.scratch/qwen24-original-mtp-20261022/tests-link1', S / 'tests-link1',
           S / 'chain-link1', S / 'chain-link2', S / 'chain-link3']
entries = []
for parent in parents:
    assert parent.is_relative_to(R / '.scratch') and parent != keep.parent
    for path in sorted(parent.iterdir()):
        if path.suffix not in ('.exe', '.map'):
            continue
        raw = path.read_bytes()
        entries.append(dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
assert len(entries) == 10
plan = dict(keep=str(keep), allowed_parents=[str(p) for p in parents], entries=entries,
    bytes=sum(e['bytes'] for e in entries),
    retained='Current final chain+5-neighbor image/map, all sources/frozen objects/link inputs/link plans/DLLs/original roles, and actual AV Qwen benchmark image/map remain.')
(S / 'cleanup-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
script = r'''$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/glm-mtp-carry-20261022').Path
$scratchRoot = (Resolve-Path -LiteralPath '.scratch').Path
$scratchPrefix = $scratchRoot.TrimEnd('\') + '\'
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$keep = [System.IO.Path]::GetFullPath($plan.keep)
$allowed = @($plan.allowed_parents | ForEach-Object { [System.IO.Path]::GetFullPath($_) })
foreach ($parent in $allowed) {
    if (-not $parent.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace scratch: $parent" }
    if ($parent -eq (Split-Path -Parent $keep)) { throw 'Current image directory is protected' }
}
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $plan.entries) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if ((Split-Path -Parent $target) -notin $allowed) { throw "Outside exact old image directories: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe','.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
if (-not (Test-Path -LiteralPath $keep -PathType Leaf)) { throw 'Final image missing' }
foreach ($entry in $plan.entries) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = @($plan.entries)
    Bytes = $plan.bytes
    CurrentImageRetained = (Test-Path -LiteralPath $keep)
    CurrentMapRetained = (Test-Path -LiteralPath ([System.IO.Path]::ChangeExtension($keep,'.map')))
    PriorReproductionInputsRetained = $plan.retained
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object Bytes, CurrentImageRetained, CurrentMapRetained
'''
(R / 'test.ps1').write_text(script, encoding='utf-8', newline='\r\n')
print(json.dumps(dict(files=len(entries), bytes=plan['bytes'], parents=plan['allowed_parents']), indent=2))
