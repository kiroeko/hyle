#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <initializer_list>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "hyle/compute/model_ops.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/storage_owner.h"
#include "hyle/compute/weight_import.h"
#if defined(HYLE_TEST_GLM_ORIGINAL_CHAIN_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#endif
#if defined(HYLE_TEST_GLM_ORIGINAL_CHAIN_CPU)
#include "hyle/graph/cpu.h"
#endif
#include "d5_glm_remaining_fragments.h"
#include "original_role_input.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace glm = d5_glm_remaining_fragments;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace original = original_role_input;
using Bytes = std::vector<std::byte>;
constexpr std::int64_t kHidden = 4096, kJoined = 8192, kQuery = 1536;
constexpr std::int64_t kIndexHeads = 32, kIndexDepth = 128, kIndexWidth = 4096;
constexpr float kEpsilon = 1.0e-5F;
constexpr auto kEhSha = "17af8402a6b674a462f2847612b2477e76c0de7dfc5ff9fba50ead1e5c88d649";
constexpr auto kEnSha = "187f2b4efe991b8c69a1a0365ded195b7fd463d50a7facd0d7196402a66dcc54";
constexpr auto kHnSha = "3fbc01762fea938ae24e94ece075b03dd5cb44cbe218884712b35d865b820501";
constexpr auto kQaSha = "615e317d19a83114b756e4634599ebba333c95241f3e775c77cc1633802d8be6";
constexpr auto kScaleSha = "c93393c24ed2c12f5458fbf88a257df91e22f586acc58436b861465c56f4d3fb";
constexpr auto kInputNormSha = "34ebd6b797e89011997e3f8fa674e4d0b9bc322d88bee17a91fe0a5421263e0c";
constexpr auto kQueryNormSha = "33fec4645dc799a2a96b870b48012fcd096e66c2003c528881d98cd397afa96a";

// Original GLM-5.3-Flash layer45, zai-org@eb9eb208eb0d988989d07a6a12d0fdeb5f52574a.
// Seven original roles: enorm/hnorm/EH/input_layernorm/q_a E4/F32 scale/qnorm.
// Source order is NextN norm(E,H)->EH->decoder input RMS->q_a->q_a RMS.
// SGLang@06992c92ad4494fe9f9636e75be3e35040512447: deepseek_nextn.py,
// glm5_next.py and attention/mla/forward_mla.py. The q_a output is BF16;
// dynamic activation groups are128, Divide, floor1e-10, F32 accumulation.
// Divide is this consumer's existing explicit contract. Fixed SGLang has
// other CUDA/Triton quantization branches with different F32 reciprocal
// boundaries; this test makes no cross-kernel bitwise-equivalence claim.
// weight_scale_inv is the stored POSITIVE MULTIPLIER, never inverted by name.
// A second ordinary Graph consumes the ACTUAL qnorm ReadLease at the existing
// indexer wq_b boundary. Its BF16 sparse fixture weight (seed239) is generated.
// This is a connected input/query component, not a complete indexer, decoder,
// cache/accepted-prefix state, target hidden provenance or natural acceptance.
template<class T> T take(hyle::Result<T> result, std::string_view where) {
  if (!result) throw std::runtime_error(std::string(where) + ": " + std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status, std::string_view where) {
  if (!status.ok()) throw std::runtime_error(std::string(where) + ": " + std::string(status.message()));
}
std::string directory(const char *name) {
#if defined(_WIN32)
  char *value = nullptr; std::size_t size = 0;
  if (_dupenv_s(&value, &size, name)) throw std::runtime_error("cannot read original GLM role directory");
  const std::unique_ptr<char, decltype(&std::free)> owner(value, &std::free);
  return value ? value : "";
#else
  const auto value = std::getenv(name); return value ? value : "";
#endif
}
template<class T> Bytes bytes(std::span<const T> values) {
  const auto raw = std::as_bytes(values); return {raw.begin(), raw.end()};
}
c::TensorDesc dense(std::initializer_list<std::int64_t> dimensions,
                    c::DataType type = c::DataType::kBFloat16) {
  return take(c::TensorDesc::dense(type, {dimensions.begin(), dimensions.size()}), "typed original description");
}
c::ReadLease upload(const c::StorageOwner &owner, std::span<const std::byte> values) {
  auto buffer = take(m::Buffer::create(owner.ref(), values.size(), 256), "actual original backing");
  check(buffer.view().write(values), "actual immutable input upload");
  return take(owner.adopt_buffer(std::move(buffer)), "qualified original input lease");
}
Bytes read(const c::ReadLease &lease) {
  Bytes result(lease.size());
  check(take(lease.view(), "actual readonly result").read(result), "actual retained result bytes");
  return result;
}
std::vector<std::uint16_t> bfloat_values(const Bytes &values) {
  if (values.size() % 2) throw std::runtime_error("BF16 output extent");
  std::vector<std::uint16_t> result(values.size() / 2);
  std::memcpy(result.data(), values.data(), values.size()); return result;
}
std::uint16_t bf16(float value) {
  auto bits = std::bit_cast<std::uint32_t>(value);
  bits += 0x7fffu + ((bits >> 16u) & 1u);
  return static_cast<std::uint16_t>(bits >> 16u);
}
// Every named F32 stage remains a rounding boundary in the independent oracle.
float f32(double value) { volatile float rounded = static_cast<float>(value); return rounded; }
float multiply(float a, float b) { return f32(double(a) * double(b)); }

struct Roles final {
  std::vector<std::uint16_t> eh, enorm, hnorm, input_norm, query_norm;
  Bytes qa, canonical;
  std::vector<float> scales;
  static Roles load(const std::filesystem::path &input, const std::filesystem::path &query) {
    Roles result;
    result.eh = original::read_bfloat(input / "eh_proj.weight.bf16", kHidden * kJoined, kEhSha);
    result.enorm = original::read_bfloat(input / "enorm.weight.bf16", kHidden, kEnSha);
    result.hnorm = original::read_bfloat(input / "hnorm.weight.bf16", kHidden, kHnSha);
    result.input_norm = original::read_bfloat(query / "input_layernorm.weight.bf16", kHidden, kInputNormSha);
    result.query_norm = original::read_bfloat(query / "q_a_layernorm.weight.bf16", kQuery, kQueryNormSha);
    result.qa = original::read_bytes(query / "q_a.weight.e4m3", kQuery * kHidden, kQaSha);
    result.scales = original::read_float(query / "q_a.weight_scale.f32", (kQuery / 128) * (kHidden / 128), kScaleSha);
    for (auto value : result.scales)
      if (!(value > 0)) throw std::runtime_error("original q_a requires positive finite stored multiplier");
    for (auto value : result.qa)
      if ((std::to_integer<unsigned>(value) & 0x7fu) == 0x7fu)
        throw std::runtime_error("original q_a has nonfinite E4 code");

    const auto code_desc = dense({kQuery, kHidden}, c::DataType::kFloat8E4M3FN);
    const auto scale_desc = dense({kQuery / 128, kHidden / 128}, c::DataType::kFloat32);
    const auto carrier_desc = take(c::float8_weight_description(kHidden, kQuery,
        c::Float8ScaleMode::kFloat32Block128), "original block128 carrier");
    auto codes = take(m::Buffer::create(m::system_resource(), result.qa.size(), 64), "cold original E4 storage");
    auto scales = take(m::Buffer::create(m::system_resource(), result.scales.size() * 4, 64), "cold original scale storage");
    auto carrier = take(m::Buffer::create(m::system_resource(), take(carrier_desc.required_bytes(), "carrier bytes"), 64), "cold canonical storage");
    check(codes.view().write(result.qa), "unchanged original E4 bytes");
    check(scales.view().write(std::as_bytes(std::span(result.scales))), "unchanged original F32 multiplier bits");
    check(c::import_float8_block128_weight(
        take(c::ConstTensorView::create(code_desc, codes.view()), "source E4 tensor"),
        take(c::ConstTensorView::create(scale_desc, scales.view()), "source F32 scale tensor"),
        take(c::TensorView::create(carrier_desc, carrier.view()), "destination canonical tensor")), "cold original block128 import");
    result.canonical.resize(carrier.size());
    check(carrier.view().read(result.canonical), "read cold imported carrier");
    auto independent = result.qa;
    const auto scale_bytes = bytes<float>(result.scales);
    independent.insert(independent.end(), scale_bytes.begin(), scale_bytes.end());
    if (result.canonical != independent) throw std::runtime_error("original importer changed codes or scale order/bits");
    return result;
  }
};

sem::Fragment input_query(const Roles &roles) {
  sem::Fragment f{.profile = &glm::core::profiles::glm53_flash_official, .region = 0x474c4d51414348ULL};
  const auto row = dense({1, kHidden});
  const auto hidden = f.input(row), embedding = f.input(row);
  const auto ew = f.constant(dense({kHidden}), bytes<std::uint16_t>(roles.enorm));
  const auto hw = f.constant(dense({kHidden}), bytes<std::uint16_t>(roles.hnorm));
  const auto ehw = f.constant(dense({kHidden, kJoined}), bytes<std::uint16_t>(roles.eh));
  const auto iw = f.constant(dense({kHidden}), bytes<std::uint16_t>(roles.input_norm));
  const auto qw = f.constant(take(c::float8_weight_description(kHidden, kQuery,
      c::Float8ScaleMode::kFloat32Block128), "original q_a packed type"), roles.canonical);
  const auto qnw = f.constant(dense({kQuery}), bytes<std::uint16_t>(roles.query_norm));
  const auto hn = f.one(c::Operation(c::RmsNorm{.epsilon = kEpsilon}), {hidden, hw});
  const auto en = f.one(c::Operation(c::RmsNorm{.epsilon = kEpsilon}), {embedding, ew});
  const auto joined = f.one(c::Operation(c::Concat{.axis = 1}), {en, hn});
  const auto transposed = glm::permute(f, ehw, {1, 0});
  const auto eh = f.one(c::Operation(c::MatMul{.accumulation_type = c::DataType::kFloat32}), {joined, transposed});
  const auto nx = f.one(c::Operation(c::RmsNorm{.epsilon = kEpsilon}), {eh, iw});
  const auto qa = f.one(c::model_ops::float8_block_linear(
      c::model_ops::Float8ScalePolicy::kDivide, 1.0e-10F), {nx, qw});
  const auto qr = f.one(c::Operation(c::RmsNorm{.epsilon = kEpsilon}), {qa, qnw});
  f.outputs = {hn, en, joined, eh, nx, qa, qr};
  return f;
}
sem::Fragment indexer_query() {
  sem::Fragment f{.profile = &glm::core::profiles::glm53_flash_official, .region = 0x474c4d575142ULL};
  const auto qr = f.input(dense({1, kQuery}));
  // Reuse the existing Flash indexer wq_b recipe, dtype and seed at full shape.
  // Sparse generated parameters are explicit, not mislabeled original weights.
  const auto projected = glm::linear::projection(f, qr, kIndexWidth, kQuery,
      glm::linear::Storage::kBFloat16, 239);
  // The existing recipe exposes its F32 accumulator. Restore the declared
  // BF16 wq_b store before its [T,heads,depth] query reshape.
  const auto stored = f.one(c::Operation(c::Cast{.output_type = c::DataType::kBFloat16}), {projected.output});
  const auto query = glm::reshape(f, stored, {1, kIndexHeads, kIndexDepth});
  f.outputs = {f.one(c::Operation(c::Copy{}), {query})};
  return f;
}

// Small test-only holder for two ordinary consumers. No new product executor,
// global cache, provider forcing or host reconstruction of an upstream result.
struct Program final {
  sem::Fragment fragment;
  sem::GraphCase logical;
  std::vector<c::ReadLease> parameters;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool outputs;
  static Program create(sem::Fragment fragment, c::Context &context,
                        const c::StorageOwner &owner, bool cuda) {
    Program result;
    result.fragment = std::move(fragment);
    result.logical = sem::make_graph(result.fragment);
    std::vector<g::ConstantBinding> constants;
    for (std::size_t i = 0; i < result.fragment.constants.size(); ++i) {
      result.parameters.push_back(upload(owner, result.fragment.constant_bytes[i]));
      constants.push_back({result.logical.constants[i], take(result.parameters.back().tensor(
          result.fragment.description(result.fragment.constants[i])), "typed original parameter")});
    }
    const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(
        *result.fragment.profile), "fixed official GLM artifact profile"), c::WorkloadPhase::kDecode,
        {0x48594c454d4f444cULL, result.fragment.region, 1}};
    const g::CompileOptions options{.constants = constants, .workload = workload};
    const auto compile = [&]() -> hyle::Result<g::CompiledGraph> {
#if defined(HYLE_TEST_GLM_ORIGINAL_CHAIN_CPU)
      if (!cuda) return g::cpu::compile(result.logical.graph, context, options);
#endif
#if defined(HYLE_TEST_GLM_ORIGINAL_CHAIN_CUDA)
      if (cuda) return g::cuda::compile(result.logical.graph, context, owner, options);
#endif
      throw std::runtime_error("original GLM chain backend not enabled");
    };
    result.compiled = take(compile(), "ordinary original GLM component compile");
    result.invocation = take(result.compiled.executable.create_invocation(
        {.resources = g::ResourceOptions{}}), "ordinary reusable Invocation");
    std::size_t footprint = 0;
    for (std::size_t i = 0; i < result.fragment.outputs.size(); ++i) {
      if (take(result.compiled.executable.output_ownership(i), "original component ownership") != g::OutputOwnership::kCaller)
        throw std::runtime_error("original chain requires existing caller-owned outputs");
      const auto extent = take(result.fragment.description(result.fragment.outputs[i]).required_bytes(), "output extent");
      footprint += (extent + 255u) / 256u * 256u;
    }
    result.outputs = take(c::LeasePool::create(owner.ref(), 2 * footprint,
        {.max_blocks = std::uint32_t(2 * result.fragment.outputs.size()), .backing_alignment = 256}), "bounded two output generations");
    return result;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue, std::span<const c::ReadLease> inputs) {
    if (inputs.size() != fragment.inputs.size()) throw std::runtime_error("original component input count");
    for (std::size_t i = 0; i < inputs.size(); ++i)
      check(invocation.bind(logical.inputs[i], fragment.description(fragment.inputs[i]), inputs[i]), "bind actual original input lease");
    for (std::size_t i = 0; i < fragment.outputs.size(); ++i) {
      const auto &desc = fragment.description(fragment.outputs[i]);
      check(invocation.bind(logical.outputs[i], desc, take(outputs.allocate(
          take(desc.required_bytes(), "actual output bytes")), "new bounded output writer")), "bind caller output writer");
    }
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
    check(invocation.prepare_replay(queues, {.mode = g::ReplayMode::kCommands,
        .host_wait = g::HostWaitPolicy::kAllow}), "prepare actual complete component");
    { auto done = take(invocation.submit(queues), "strict original component submit"); check(done.wait(), "actual component Completion"); }
    std::vector<c::ReadLease> result;
    for (const auto output : logical.outputs) {
      auto completed = take(invocation.result(output), "actual completed output");
      result.push_back(take(completed.storage_lease(), "independently retained actual permission"));
    }
    check(invocation.reset(), "withdraw completed invocation permissions");
    if (invocation.submit(queues)) throw std::runtime_error("reset original chain retained stale preparation");
    return result;
  }
};

std::vector<std::uint16_t> input(unsigned generation, bool embedding) {
  std::vector<std::uint16_t> result(kHidden);
  if (generation == 2) return result;
  for (std::size_t i = 0; i < result.size(); ++i) {
    const int value = int((i * (embedding ? 37u : 19u) + (embedding ? 11u : 3u) + generation * 23u) % 97u) - 48;
    result[i] = bf16(float(value) / (embedding ? 64.0F : 32.0F));
  }
  return result;
}
struct Dot final { double sum = 0, correction = 0; };
void add(Dot &dot, double value) {
  const auto next = dot.sum + value;
  dot.correction += std::abs(dot.sum) >= std::abs(value)
      ? (dot.sum - next) + value : (value - next) + dot.sum;
  dot.sum = next;
}
std::vector<float> norm_reference(std::span<const std::uint16_t> values,
                                std::span<const std::uint16_t> weights) {
  Dot squares;
  for (auto value : values) { const double x = original::widen(value); add(squares, x * x); }
  const double factor = 1.0 / std::sqrt((squares.sum + squares.correction) / double(values.size()) + kEpsilon);
  std::vector<float> result(values.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    result[i] = original::widen(bf16(float(double(original::widen(values[i])) * factor * double(original::widen(weights[i])))));
  return result;
}
std::vector<float> eh_reference(std::span<const std::uint16_t> joined, const Roles &roles) {
  std::vector<float> result(kHidden);
  for (std::int64_t row = 0; row < kHidden; ++row) {
    Dot dot;
    for (std::int64_t col = 0; col < kJoined; ++col)
      add(dot, double(original::widen(joined[std::size_t(col)])) * original::widen(roles.eh[std::size_t(row * kJoined + col)]));
    result[std::size_t(row)] = original::widen(bf16(float(dot.sum + dot.correction)));
  }
  return result;
}
// Independent E4 code enumeration, with saturated nearest-even conversion.
float e4(std::uint8_t code) {
  const unsigned magnitude = code & 0x7fu, exponent = magnitude >> 3u, fraction = magnitude & 7u;
  const float value = exponent == 0 ? std::ldexp(float(fraction), -9)
      : std::ldexp(1.0F + float(fraction) / 8.0F, int(exponent) - 7);
  return (code & 0x80u) ? -value : value;
}
float rounded_e4(float value) {
  const double magnitude = std::min(std::abs(double(value)), 448.0);
  unsigned best = 0; double distance = magnitude;
  for (unsigned code = 1; code <= 0x7e; ++code) {
    const auto delta = std::abs(magnitude - double(e4(std::uint8_t(code))));
    if (delta < distance || (delta == distance && (code & 1u) == 0)) { best = code; distance = delta; }
  }
  return std::copysign(e4(std::uint8_t(best)), value);
}
std::vector<float> qa_reference(std::span<const std::uint16_t> values, const Roles &roles, bool cuda) {
  constexpr std::size_t groups = kHidden / 128;
  std::array<float, groups> activation_scale{};
  std::vector<float> codes(values.size());
  for (std::size_t group = 0; group < groups; ++group) {
    float maximum = 1.0e-10F;
    for (std::size_t col = 0; col < 128; ++col)
      maximum = std::max(maximum, std::abs(original::widen(values[group * 128 + col])));
    activation_scale[group] = f32(double(maximum) / 448.0);
    for (std::size_t col = 0; col < 128; ++col)
      codes[group * 128 + col] = rounded_e4(f32(double(original::widen(values[group * 128 + col])) / activation_scale[group]));
  }
  std::vector<float> result(kQuery);
  for (std::size_t row = 0; row < std::size_t(kQuery); ++row) {
    float accumulated = 0;
    for (std::size_t group = 0; group < groups; ++group) {
      Dot dot;
      for (std::size_t col = 0; col < 128; ++col) {
        const auto k = group * 128 + col;
        add(dot, double(codes[k]) * e4(std::to_integer<std::uint8_t>(roles.qa[row * kHidden + k])));
      }
      const auto scaled = multiply(f32(dot.sum + dot.correction), activation_scale[group]);
      const auto weight_scale = roles.scales[(row / 128) * groups + group];
      // Native CPU ATen has distinct mul/add boundaries; CUDA uses an FMA.
      // This is selected by the declared backend before examining any result.
      accumulated = cuda ? std::fma(scaled, weight_scale, accumulated)
          : f32(double(accumulated) + multiply(scaled, weight_scale));
    }
    result[row] = original::widen(bf16(accumulated));
  }
  return result;
}
bool close_bfloat(std::span<const std::uint16_t> actual,
                  std::span<const float> expected, std::string_view role) {
  if (actual.size() != expected.size()) { ADD_FAILURE() << role << " extent"; return false; }
  double maximum = 0;
  for (std::size_t i = 0; i < actual.size(); ++i) {
    const double value = original::widen(actual[i]);
    const double error = std::abs(value - expected[i]); maximum = std::max(maximum, error);
    // Unchanged original BF16 cuBLAS gate used by the predecessor input test.
    // Dense original q_a has cancellation; this does not inherit a sparse
    // two-term fixture's exact-code-domain one-ULP assumption.
    const double tolerance = 0.008 * std::abs(double(expected[i])) + 0.0001;
    if (!std::isfinite(value) || error > tolerance) {
      ADD_FAILURE() << role << '[' << i << "] actual=" << value << " independent=" << expected[i]
                    << " tolerance=" << tolerance;
      return false;
    }
  }
  std::printf("GLM_ORIGINAL_CHAIN boundary=%.*s count=%zu max_abs=%.9g\n", int(role.size()), role.data(), actual.size(), maximum);
  return true;
}

void run(const Roles &roles, c::Context &context, const c::StorageOwner &owner, bool cuda) {
  auto queue = take(context.create_queue(), "ordinary original-chain queue");
  auto first = Program::create(input_query(roles), context, owner, cuda);
  auto next = Program::create(indexer_query(), context, owner, cuda);
  std::vector<c::ReadLease> oldest, old_query;
  std::vector<Bytes> oldest_bytes;
  Bytes old_query_bytes;
  bool distinct_order = false, changed_query = false;
  for (unsigned generation = 0; generation < 3; ++generation) {
    SCOPED_TRACE(generation);
    const auto hidden = input(generation, false), embedding = input(generation, true);
    const std::array inputs{upload(owner, bytes<std::uint16_t>(hidden)), upload(owner, bytes<std::uint16_t>(embedding))};
    auto current = first.execute(queue, inputs);
    // No host reconstruction/copy: the exact result storage permission is
    // the next Graph's input, even after the producer Invocation reset.
    const std::array actual_query_input{current[6]};
    auto query = next.execute(queue, actual_query_input);
    std::array<std::vector<std::uint16_t>, 7> actual;
    std::vector<Bytes> raw;
    for (std::size_t i = 0; i < current.size(); ++i) { raw.push_back(read(current[i])); actual[i] = bfloat_values(raw.back()); }
    const auto query_raw = read(query[0]);
    const auto query_values = bfloat_values(query_raw);
    ASSERT_TRUE(close_bfloat(actual[0], norm_reference(hidden, roles.hnorm), "hnorm"));
    ASSERT_TRUE(close_bfloat(actual[1], norm_reference(embedding, roles.enorm), "enorm"));
    auto joined_bytes = raw[1]; joined_bytes.insert(joined_bytes.end(), raw[0].begin(), raw[0].end());
    EXPECT_EQ(raw[2], joined_bytes) << "embedding-before-hidden original EH order";
    distinct_order |= raw[0] != raw[1];
    ASSERT_TRUE(close_bfloat(actual[3], eh_reference(actual[2], roles), "original_EH"));
    ASSERT_TRUE(close_bfloat(actual[4], norm_reference(actual[3], roles.input_norm), "original_decoder_input_norm"));
    ASSERT_TRUE(close_bfloat(actual[5], qa_reference(actual[4], roles, cuda), "original_dynamic128_q_a"));
    ASSERT_TRUE(close_bfloat(actual[6], norm_reference(actual[5], roles.query_norm), "original_q_a_norm"));
    std::vector<float> expected_query(kIndexWidth);
    for (std::size_t row = 0; row < expected_query.size(); ++row) {
      const auto col = (17u * row + 239u) % std::size_t(kQuery);
      const auto coefficient = original::widen(bf16(0.5F + float((row + 239u) % 13u) / 32.0F));
      expected_query[row] = original::widen(bf16(multiply(original::widen(actual[6][col]), coefficient)));
    }
    ASSERT_TRUE(close_bfloat(query_values, expected_query, "actual_lease_indexer_wq_b"));
    if (generation == 2) {
      for (const auto &values : actual) for (auto value : values) EXPECT_EQ(original::widen(value), 0.0F);
      for (auto value : query_values) EXPECT_EQ(original::widen(value), 0.0F);
    }
    if (generation == 0) {
      oldest = std::move(current); old_query = std::move(query);
      oldest_bytes = raw; old_query_bytes = query_raw;
    } else {
      changed_query |= query_raw != old_query_bytes;
      for (std::size_t i = 0; i < oldest.size(); ++i) EXPECT_EQ(read(oldest[i]), oldest_bytes[i]);
      EXPECT_EQ(read(old_query[0]), old_query_bytes);
    }
  }
  EXPECT_TRUE(distinct_order); EXPECT_TRUE(changed_query);
  for (std::size_t i = 0; i < oldest.size(); ++i) EXPECT_EQ(read(oldest[i]), oldest_bytes[i]);
  EXPECT_EQ(read(old_query[0]), old_query_bytes);
  oldest.clear(); old_query.clear();
  EXPECT_EQ(first.outputs.stats().live_blocks, 0u); EXPECT_EQ(first.outputs.stats().active_uses, 0u);
  EXPECT_EQ(next.outputs.stats().live_blocks, 0u); EXPECT_EQ(next.outputs.stats().active_uses, 0u);
  for (const auto *program : {&first, &next})
    for (std::size_t i = 0; i < program->parameters.size(); ++i)
      EXPECT_EQ(read(program->parameters[i]), program->fragment.constant_bytes[i]) << "immutable original/generated parameter changed";
  ::testing::Test::RecordProperty("scope", "original layer45 NextN input->inputnorm->dynamic128 q_a->qnorm; actual qnorm lease->generated BF16 indexer wq_b; no full-model/indexer/cache/natural-acceptance claim");
  ::testing::Test::RecordProperty("backend", cuda ? "ordinary CUDA Graph" : "ordinary CPU Graph");
  ::testing::Test::RecordProperty("actual_submissions", 6);
  ::testing::Test::RecordProperty("original_role_count", 7);
  ::testing::Test::RecordProperty("original_role_bytes", 73429504);
  ::testing::Test::RecordProperty("q_a_sha256", kQaSha);
  ::testing::Test::RecordProperty("q_a_scale_sha256", kScaleSha);
  ::testing::Test::RecordProperty("input_norm_sha256", kInputNormSha);
  ::testing::Test::RecordProperty("q_a_norm_sha256", kQueryNormSha);
  ::testing::Test::RecordProperty("producer_output_pool", "two generations;14 blocks;110592 bytes");
  ::testing::Test::RecordProperty("successor_output_pool", "two generations;2 blocks;16384 bytes");
}

class GlmOriginalMtpChain : public ::testing::Test {
protected:
  static inline std::unique_ptr<const Roles> roles;
  static void SetUpTestSuite() {
    const auto input = directory("HYLE_GLM_MTP_INPUT_DIR"), query = directory("HYLE_GLM_MTP_QUERY_DIR");
    if (!input.empty() && !query.empty()) roles = std::make_unique<const Roles>(Roles::load(input, query));
  }
  static void TearDownTestSuite() { roles.reset(); }
  void SetUp() override {
    if (!roles) GTEST_SKIP() << "Set HYLE_GLM_MTP_INPUT_DIR and HYLE_GLM_MTP_QUERY_DIR to the authenticated seven original layer45 roles";
  }
};
#if defined(HYLE_TEST_GLM_ORIGINAL_CHAIN_CUDA)
TEST_F(GlmOriginalMtpChain, CudaOriginalInputFeedsFp8QueryAndActualIndexerLease) {
  auto context = take(g::cuda::create_context(), "ordinary CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "actual CUDA device resource")), "original CUDA allocation owner");
  run(*roles, context, owner, true);
}
#endif
#if defined(HYLE_TEST_GLM_ORIGINAL_CHAIN_CPU)
struct SystemResource final { m::MemoryResourceRef ref() noexcept { return m::system_resource(); } };
TEST_F(GlmOriginalMtpChain, CpuOriginalInputFeedsFp8QueryAndActualIndexerLease) {
  auto context = take(g::cpu::create_context(), "ordinary CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "original system allocation owner");
  run(*roles, context, owner, false);
}
#endif
} // namespace
