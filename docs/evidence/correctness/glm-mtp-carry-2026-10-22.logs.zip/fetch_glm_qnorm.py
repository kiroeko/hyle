"""Fetch the real 3KB query-rank norm from the already authenticated shard."""
from pathlib import Path
import hashlib
import json
import urllib.request

S = Path(__file__).resolve().parent / 'original-glm-q-a'
source = json.loads((S / 'acquisition.json').read_text(encoding='utf-8'))
header = json.loads((S / 'header.json').read_bytes())
name = 'model.language_model.layers.45.self_attn.q_a_layernorm.weight'
role = header[name]
assert role == dict(dtype='BF16', shape=[1536], data_offsets=[52134448, 52137520])
first, end = [source['data_start'] + x for x in role['data_offsets']]
assert end - first == 3072
record = dict(repository=source['repository'], revision=source['revision'], file=source['file'],
    url=source['url'], role=name, dtype='BF16', shape=[1536],
    data_relative_offsets=role['data_offsets'], first=first, last=end - 1, complete=False)
receipt = S / 'qnorm-acquisition.json'
assert not receipt.exists()

def save():
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')

save()
request = urllib.request.Request(source['url'], headers={'Range': f'bytes={first}-{end - 1}',
    'Accept-Encoding': 'identity', 'User-Agent': 'hyle-pinned-original-role/1'})
with urllib.request.urlopen(request, timeout=45) as response:
    assert response.status == 206
    assert response.headers.get('Content-Range') == f"bytes {first}-{end - 1}/{source['file_bytes']}"
    assert response.headers.get('ETag') == source['etag']
    assert response.headers.get('Content-Length') in (None, '3072')
    body = response.read(3073)
    assert len(body) == 3072
path = S / 'q_a_layernorm.weight.bf16'
with path.open('xb') as output:
    output.write(body)
record.update(complete=True, http_status=206, content_range=response.headers['Content-Range'],
    etag=source['etag'], payload=dict(path=str(path), bytes=3072, sha256=hashlib.sha256(body).hexdigest()))
save()
print(json.dumps(record['payload'], indent=2))
