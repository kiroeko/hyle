"""Offline diagnostic only; actual BF16 nx/qa files come from the failing Graph.

No inference, allocation policy or threshold is changed. Requires no packages.
Run with --nx FILE --actual FILE --roles ORIGINAL_Q_A_DIR --output JSON.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import struct


def f32(x):
    return struct.unpack('<f', struct.pack('<f', x))[0]


def bf16(x):
    word = struct.unpack('<I', struct.pack('<f', f32(x)))[0]
    word += 0x7fff + ((word >> 16) & 1)
    return word >> 16


def wide(word):
    return struct.unpack('<f', struct.pack('<I', word << 16))[0]


def e4(code):
    magnitude = code & 127
    exponent, fraction = magnitude >> 3, magnitude & 7
    value = math.ldexp(fraction, -9) if exponent == 0 else math.ldexp(1 + fraction / 8, exponent - 7)
    return -value if code & 128 else value


E4 = [e4(code) for code in range(127)]


def nearest(x):
    # Tie chooses the even low code bit, independently of CUDA/SIMD codecs.
    magnitude = min(abs(x), 448)
    best = min(range(127), key=lambda code: (abs(magnitude - E4[code]), code & 1))
    return best | (128 if math.copysign(1, x) < 0 else 0)


def load_bfloat(path):
    raw = path.read_bytes()
    return list(struct.unpack('<' + 'H' * (len(raw) // 2), raw)), hashlib.sha256(raw).hexdigest()


def quantize(values, policy):
    codes, scales = [], []
    for start in range(0, len(values), 128):
        block = values[start:start + 128]
        maximum = max(f32(1e-10), max(map(abs, block)))
        scale = f32(maximum / 448) if policy == 'divide' else f32(maximum * f32(1 / 448))
        scales.append(scale)
        if policy == 'divide':
            normalized = [f32(value / scale) for value in block]
        elif policy == 'multiply-reciprocal-scale':
            reciprocal = f32(1 / scale)
            normalized = [f32(value * reciprocal) for value in block]
        else:
            reciprocal = f32(448 / maximum)
            normalized = [f32(value * reciprocal) for value in block]
        codes += list(map(nearest, normalized))
    return codes, scales


def project(row, activation, scales, weights, weight_scales):
    ordered, fused = 0.0, 0.0
    blocks = []
    exact_total = []
    for group in range(32):
        begin = group * 128
        # Products of two finite E4 codes are exact in F64. fsum is independent
        # of native parallel F32 reduction. Report every contributing block.
        terms = [e4(activation[begin + col]) * e4(weights[row * 4096 + begin + col]) for col in range(128)]
        dot = f32(math.fsum(terms))
        left = f32(dot * scales[group])
        sw = weight_scales[(row // 128) * 32 + group]
        product = f32(left * sw)
        ordered = f32(ordered + product)
        fused = f32(left * sw + fused)
        exact_total.append(math.fsum(terms) * scales[group] * sw)
        blocks.append({'group': group, 'code_dot': dot, 'sum_abs_code_products': math.fsum(map(abs, terms)),
                       'activation_scale': scales[group], 'weight_scale': sw, 'scaled': left,
                       'ordered_acc': ordered, 'fused_double_emulation_acc': fused})
    return {'cpu_mul_add': ordered, 'cpu_bf16': bf16(ordered),
            'cuda_fused_double_emulation': fused, 'cuda_bf16': bf16(fused),
            'unrounded_quantized_sum': math.fsum(exact_total), 'blocks': blocks}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--nx', required=True, type=Path)
    parser.add_argument('--actual', required=True, type=Path)
    parser.add_argument('--roles', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--rows', default='25')
    args = parser.parse_args()
    nx_words, nx_sha = load_bfloat(args.nx)
    actual, actual_sha = load_bfloat(args.actual)
    assert len(nx_words) == 4096 and len(actual) == 1536
    weights = (args.roles / 'q_a.weight.e4m3').read_bytes()
    scale_raw = (args.roles / 'q_a.weight_scale.f32').read_bytes()
    assert hashlib.sha256(weights).hexdigest() == '615e317d19a83114b756e4634599ebba333c95241f3e775c77cc1633802d8be6'
    assert hashlib.sha256(scale_raw).hexdigest() == 'c93393c24ed2c12f5458fbf88a257df91e22f586acc58436b861465c56f4d3fb'
    weight_scales = struct.unpack('<384f', scale_raw)
    values = list(map(wide, nx_words))
    reference_codes = quantize(values, 'divide')[0]
    result = {'scope': 'offline actual nx->q_a diagnostic; no threshold change or runtime substitution',
              'nx_sha256': nx_sha, 'actual_sha256': actual_sha, 'policies': {}}
    for policy in ('divide', 'multiply-reciprocal-scale', 'multiply-reciprocal-maximum'):
        activation, scales = quantize(values, policy)
        changed = [{'column': index, 'input': values[index], 'divide_code': reference_codes[index], 'code': code}
                   for index, code in enumerate(activation) if code != reference_codes[index]]
        rows = {}
        for row in map(int, args.rows.split(',')):
            value = project(row, activation, scales, weights, weight_scales)
            value.update({'actual_bf16': actual[row], 'actual': wide(actual[row]),
                          'cpu_expected': wide(value['cpu_bf16']), 'cuda_expected': wide(value['cuda_bf16'])})
            rows[row] = value
        result['policies'][policy] = {'activation_code_changes_from_divide': changed, 'rows': rows}
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
