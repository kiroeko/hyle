"""Offline SM89 candidate: exact E4->BF16 tiles, unchanged F32 scale boundary."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
T = R / 'third_party/sglang_activation/fp8'
os.environ['TRITON_CACHE_DIR'] = str(R / '.scratch/tools/d5-triton/cache')
os.environ['TRITON_DUMP_DIR'] = str(R / '.scratch/tools/d5-triton/dump')
sys.path.insert(0, str(R / '.scratch/tools/d5-triton/unpacked'))
import triton
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource

assert triton.__version__ == '3.8.0'
original = T / 'original_kernels.py'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == json.loads((T / 'source.json').read_text())['module_sha256']
old = 'accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]'
new = 'accumulator += tl.dot(a.to(tl.bfloat16), b.to(tl.bfloat16)) * a_s[:, None] * b_s[None, :]'
source = raw.decode('utf-8')
assert source.count(old) == 1
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', type=int, default=2)
args = parser.parse_args()
out = S / f'bf16-tile-candidate{args.attempt}'
out.mkdir(exist_ok=False)
adapted = out / 'kernels.py'
adapted.write_text(source.replace(old, new), encoding='utf-8', newline='\n')
spec = importlib.util.spec_from_file_location('glm_bf16_tile_candidate', adapted)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
jobs = json.loads((T / 'compilation.json').read_text())['kernels']
jobs += json.loads((T / 'dynamic-compilation.json').read_text())['kernels']
selected = [j for j in jobs if j['label'] in ('matmul', 'matmul_bf16')]
assert len(selected) == 2
report = dict(source_sha256=hashlib.sha256(raw).hexdigest(),
    candidate_sha256=hashlib.sha256(adapted.read_bytes()).hexdigest(),
    adaptation='Only exact E4->BF16 register-tile casts before dot; FP8 storage, activation codes/scales, K128 dot, scale multiply and F32 accumulation/store unchanged.',
    compiler='Triton3.8.0 cuda:89:32', SDK_builds=0, NVCC_builds=0, kernels=[])
for job in selected:
    compiled = triton.compile(ASTSource(fn=module._w8a8_block_fp8_matmul,
        signature=job['signature'], constexprs=job['constexprs']),
        target=GPUTarget('cuda', 89, 32), options=job['options'])
    blob, ptx = compiled.asm['cubin'], compiled.asm['ptx']
    assert '.f32.bf16.bf16.f32' in ptx and '.f32.e4m3.e4m3.f32' not in ptx
    label = job['label']
    (out / (label + '.cubin')).write_bytes(blob)
    (out / (label + '.ptx')).write_text(ptx, encoding='utf-8', newline='\n')
    report['kernels'].append(dict(label=label, sha256=hashlib.sha256(blob).hexdigest(),
        bytes=len(blob), metadata=compiled.metadata._asdict(), options=job['options'],
        signature=job['signature'], constexprs=job['constexprs']))
    (out / 'compilation.json').write_text(json.dumps(report, indent=2, default=str) + '\n', encoding='utf-8')
    print(label, report['kernels'][-1]['sha256'], flush=True)
