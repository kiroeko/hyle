"""Install only the two validated FP8-storage/BF16-tile AOT images."""
from pathlib import Path
import hashlib
import json
import re

S = Path(__file__).resolve().parent
R = S.parents[1]
T = R / 'third_party/sglang_activation/fp8'
C = S / 'bf16-tile-candidate2'
records = json.loads((C / 'compilation.json').read_text(encoding='utf-8'))
meta = {j['label']: j for j in records['kernels']}
before = S / 'repair-headers/before'
before.mkdir(parents=True, exist_ok=False)
names = ['sglang_fp8_sm89.h', 'sglang_fp8_dynamic_sm89.h']
for name in names:
    (before / name).write_bytes((T / name).read_bytes())
old = (T / names[1]).read_text(encoding='utf-8')
match = re.search(r'(alignas\(16\) inline constexpr unsigned char kSglangFp8QuantizeBf16Pow2\[\] = \{[^}]*\};)', old, re.S)
assert match
unchanged_pow2 = match[1]
pow2_bytes = bytes(int(x, 16) for x in re.findall(r'0x([0-9a-fA-F]{2})', unchanged_pow2))

def array(label, symbol, shared_symbol):
    job = meta[label]
    raw = (C / (label + '.cubin')).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == job['sha256']
    assert job['metadata']['shared'] == 16384
    lines = ['// SHA256 cubin: ' + job['sha256'],
             'alignas(16) inline constexpr unsigned char ' + symbol + '[] = {']
    lines += ['  ' + ','.join('0x%02x' % x for x in raw[i:i + 32]) + ',' for i in range(0, len(raw), 32)]
    lines += ['};', 'inline constexpr unsigned ' + shared_symbol + ' = ' + str(job['metadata']['shared']) + ';']
    return '\n'.join(lines)

prefix = ['// Generated from SGLang 06992c92 with exact E4-to-BF16 tiles for F32 accumulation.',
          '// FP8 storage/quantization/scales unchanged; see source.json and rebuild.py.',
          '#pragma once', 'namespace hyle::compute::cuda_native::fp8 {']
suffix = '} // namespace hyle::compute::cuda_native::fp8\n'
(T / names[0]).write_text('\n'.join(prefix) + '\n' + array('matmul', 'kSglangFp8Sm89',
    'kSglangFp8Sm89SharedBytes') + '\n' + suffix, encoding='utf-8', newline='\n')
(T / names[1]).write_text('\n'.join(prefix) + '\n' + array('matmul_bf16', 'kSglangFp8MatmulBf16',
    'kSglangFp8MatmulBf16SharedBytes') + '\n// Original power-of-two quantizer retained byte-for-byte.\n' +
    '// SHA256 cubin: ' + hashlib.sha256(pow2_bytes).hexdigest() + '\n' + unchanged_pow2 + '\n' + suffix,
    encoding='utf-8', newline='\n')
receipt = dict(kernels=records['kernels'], ordinary_cuda_quantizer_changed=False,
    power_of_two_quantizer=dict(bytes=len(pow2_bytes), sha256=hashlib.sha256(pow2_bytes).hexdigest(), unchanged=True),
    changes=[dict(path=(T / name).relative_to(R).as_posix(),
        sha256=hashlib.sha256((T / name).read_bytes()).hexdigest()) for name in names])
(S / 'repair-headers/installation.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt['changes'], indent=2))
