"""Preserve actual GLM carry and original input/query-chain results."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = R / 'docs/evidence/correctness/glm-mtp-carry-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def passed(path, expected):
    result = read(path)
    assert result['tests'] == expected and result['process']['exit'] == 0 and not result['process']['timed_out']
    assert not any(result[k] for k in ('failures', 'errors', 'disabled', 'skips'))
    if Path(result['image']['path']).exists():
        assert identity(result['image']['path'])['sha256'] == result['image']['sha256']
    else:
        removed = read(S / 'cleanup-result.json')['Removed']
        assert any(x['path'] == result['image']['path'] and x['sha256'] == result['image']['sha256'] for x in removed)
    return result

assert not OUT.exists() and not ZIP.exists()
carry = passed(S / 'checks1/summary.json', 2)
chain_runs = sorted(S.glob('chain-checks*/summary.json'), key=lambda p: int(p.parent.name[12:]))
assert chain_runs
chain = passed(chain_runs[-1], 7)
assert all(c['properties']['actual_submissions'] == '7' for c in carry['cases'])
pair = read(S / 'original-glm-q-a/acquisition.json')
qnorm = read(S / 'original-glm-q-a/qnorm-acquisition.json')
inputnorm = read(S / 'original-glm-q-a/inputnorm-acquisition.json')
input_roles = read(R / '.scratch/dspark-natural-journey-20261022/original-glm-input/acquisition.json')
assert all(x['complete'] for x in (pair, qnorm, inputnorm, input_roles))
roles = [*(r['payload'] for r in pair['roles']), qnorm['payload'], inputnorm['payload'],
         *(r['payload'] for r in input_roles['roles'])]
assert len(roles) == 7 and sum(x['bytes'] for x in roles) == 73_429_504
for role in roles:
    assert identity(role['path'])['sha256'] == role['sha256']
files = [
    'tests/compute_models/glm_mtp_index_carry_test.cc',
    'tests/compute_models/glm_original_mtp_chain_test.cc',
    'tests/compute_models/original_role_input.h',
    'tests/graph_route_cuda/fp8_shared_prologue_test.cc',
    'src/compute_provider_cuda/fp8_provider.cc',
    'third_party/sglang_activation/fp8/original_kernels.py',
    'third_party/sglang_activation/fp8/rebuild.py',
    'third_party/sglang_activation/fp8/source.json',
    'third_party/sglang_activation/fp8/compilation.json',
    'third_party/sglang_activation/fp8/dynamic-compilation.json',
    'third_party/sglang_activation/fp8/sglang_fp8_sm89.h',
    'third_party/sglang_activation/fp8/sglang_fp8_dynamic_sm89.h',
    'tests/graph_route_cpu/CMakeLists.txt',
    'tests/graph_route_cuda/CMakeLists.txt',
    'docs/developer/current-work.md',
    'docs/implementation/model-operators.md',
]
for name in files:
    path = S / 'source-current' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((R / name).read_bytes())
report = dict(date='2026-10-22', status='GLM_ACTUAL_INDEX_CARRY_AND_ORIGINAL_INPUT_QUERY_CHAIN_PASS',
    goal_complete=False, changes=[identity(R / n) for n in files],
    carry_checks=carry, original_chain_checks=chain,
    actual_carry_graph_submissions=14,
    actual_original_chain_graph_submissions=12,
    actual_new_consumer_cases=4, existing_shared_FP8_neighbor_cases=5,
    carry=dict(
        scope='Generated GLM Flash single-layer indexer -> actual I32 ReadLease -> skip Gather/SDPA -> atomic StateHead.',
        state='IDs, actual next index-key and gate, epoch/provenance. Four-member complete carry boundary only, not complete model state.',
        reuse='Each backend actually executes3 original indexer Graphs and4 skip Graphs. Skip contains no indexer/TopK/projection; host reads are oracle only, not rebuilt execution inputs.',
        epoch='Default begin clears even a real seed; explicit keep with a real seed qualifies it for the new epoch; keep without seed clears. Normal/exception RAII finally disables reuse. Old snapshots stay readonly/readable, but cannot nominate a live head in another epoch.',
        limits='Query and512-wide attention cache for skip are still generated external inputs. Retained key/gate are not fed to a subsequent indexer update; no target/MLA/pool-tail/accepted-prefix completeness claim.',
        resources='Finite output pools and StateStore; observed versions/drafts/live output blocks/active uses return to0.'),
    original_parameters=dict(input_roles=input_roles, query_pair=pair, qnorm=qnorm, inputnorm=inputnorm,
        role_count=7, bytes=73_429_504,
        acquisition='Only exact HTTP206 role ranges plus bounded authenticated headers. Query pair6,292,992B and both norms11,264B newly acquired. Prior67,125,248B input roles reused; no full weight shard downloaded.'),
    original_chain=dict(
        scope='Original NextN BF16 input norms/EH -> decoder input RMSNorm -> original E4 q_a with raw original F32 scale -> original query RMSNorm -> actual output lease consumed by existing generated BF16 indexer wq_b projection.',
        precision='BF16 norm/activation boundaries; original scale bits retained, not inverted because the field is named weight_scale_inv. Explicit existing dynamic block128 Divide/floor1e-10, F32 accumulation/BF16 output contract.',
        reader_limit='Fixed-source SGLang has multiple activation scale/quantization arithmetic paths; this chosen Divide contract is not a claim of byte equality with its current CUDA JIT or every native reader.',
        limits='Generated wq_b remains labelled. Neither this query chain nor the separate carry test is a complete original GLM attention/MoE/head/target or natural MTP acceptance journey.'),
    source_audit=read(S / 'review/glm-source-audit.json'),
    CUDA_FP8_repair=dict(
        failure='Original complete CPU input/query component passed. Original CUDA gen0 q_a row25 was -0.0020904541015625 vs independent -0.0022125244140625, beyond unchanged0.008*abs(ref)+0.0001 gate; all preceding original norm/EH/inputnorm boundaries matched.',
        discrimination='Actual4096 CUDA E4 codes and32 F32 scale bits equal independent oracle. Direct original F32 GEMM rounds to the entire actual BF16 Graph output.3 same-shape one-hot-scale launches extract32 raw row25 K128 dots;20 exceed the predeclared IEEE F32 gamma127*sumabs diagnostic bound, with no E4 subnormals. Exact F32 mul/FMA composition from all32 actual dots reproduces the full GEMM row25 bit-for-bit.',
        original_probe=identity(S / 'diagnostics2/native-quant-probe1/result.json'),
        raw_dot_probe=identity(S / 'diagnostics2/native-quant-probe2/result.json'),
        composition=read(S / 'diagnostics2/raw-dot-composition.json'),
        source_repair_review=read(S / 'review/fp8-dot-precision-repair-review.json'),
        candidate_probe=identity(S / 'diagnostics2/native-quant-probe3-bf16-tile/result.json'),
        repair='Keep original FP8 storage, activation quantizer/code/scale bits and K128 scale/order/output boundaries. Exact finite E4->BF16 register-tile casts before the same F32 dot avoid this observed SM89 E4-MMA loss. Candidate32 dots all lie within the existing diagnostic bound, and row25 equals the independent F32 reference.',
        shipped='Both existing GEMM AOT images regenerated. Shared memory16384B is emitted with each image and used by the existing Provider instead of24576B literal. No new provider, public option, executor, dense weight expansion or resident BF16 shadow bank.',
        identity='Maintainer --gemm-only regeneration produces exactly the two installed candidate cubin SHAs; vendor original module unchanged, adaptation explicitly recorded, ordinary/pow2 quantizer images unchanged.',
        metadata=identity(S / 'maintainer-regeneration/compilation.json'),
        source_gate_or_tolerance_changed=False,
        limits='Finite SM89 single/block128 routes only; grouped FP8 has a different AOT and is not certified by this fix. No inference TPS or physical memory performance claim.'),
    validation=dict(SDK_builds=0, NVCC_builds=0, shader_builds=0,
        regenerated_GEMM_AOT_images=2,
        method='Related host test TUs and one host FP8-provider TU incrementally compiled/linked on existing matched CPU/CUDA closure; cached Triton3.8 offline regeneration of two small GEMMs. No SDK/full-tree/platform matrix.',
        throughput_evidence=False, memory_evidence=False),
    cleanup=read(S / 'cleanup-result.json'),
    limits=['Windows CPU/CUDA only for this batch; no new Apple/Vulkan/Linux run.',
            'No new TPS or physical CPU/GPU memory measurement; AV remains latest full four-arm table.',
            'GLM complete target/draft MLA/index/pool-tail/position and accepted-prefix state composition remains; other applicable original model roles/codecs remain.'],
    next='Compose actual GLM target/draft continuation state and applicable original role/codec bindings with existing Graph/State mechanisms; finish DSpark original stage/LM/target hidden provenance separately.')
save(S / 'report-before-archive.json', report)
extensions = {'.json', '.py', '.cc', '.h', '.md', '.diff', '.log', '.xml', '.txt', '.ps1'}
selected = [p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in extensions
            and '__pycache__' not in p.parts]
selected += [p for p in (S / 'diagnostics2').rglob('*') if p.is_file() and
             p.suffix.lower() in {'.bf16', '.f32', '.e4m3', '.bin'} and p.stat().st_size <= 65536]
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(selected):
        archive.write(path, path.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
report['sources_commands_and_results'] = identity(ZIP)
report['large_original_payloads_archived'] = False
save(OUT, report)
receipt = dict(result=identity(OUT), logs=identity(ZIP), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
