"""Compile only the original GLM input-to-query-chain consumer."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location('chain_cached', S / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = S / 'tests-link1'
SOURCE = R / 'tests/compute_models/glm_original_mtp_chain_test.cc'
PROVIDER_RECIPE = R / '.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/cuda/windows/checks/attempt1/fp8-provider/identity.json'

def compile_one(attempt):
    old = c.read(S / 'compile1/glm-carry/identity.json')
    old['command'] = [x for x in old['command'] if not x.startswith('/DHYLE_TEST_GLM_CARRY_')]
    old['command'] += ['/DHYLE_TEST_GLM_ORIGINAL_CHAIN_CPU=1', '/DHYLE_TEST_GLM_ORIGINAL_CHAIN_CUDA=1']
    recipe = S / 'recipes/glm-original-chain.json'
    c.save(recipe, old)
    h.RECIPES['glm-original-chain'], h.SOURCES['glm-original-chain'] = recipe, SOURCE
    h.compile_one('glm-original-chain', attempt)

def compile_provider(attempt):
    h.RECIPES['fp8-provider'] = PROVIDER_RECIPE
    h.SOURCES['fp8-provider'] = R / 'src/compute_provider_cuda/fp8_provider.cc'
    h.compile_one('fp8-provider', attempt)

def compile_neighbor(attempt):
    old = c.read(S / 'compile1/glm-carry/identity.json')
    old['command'] = [x for x in old['command'] if not x.startswith('/DHYLE_TEST_GLM_CARRY_')]
    recipe = S / 'recipes/fp8-shared-neighbor.json'
    c.save(recipe, old)
    h.RECIPES['fp8-shared-neighbor'] = recipe
    h.SOURCES['fp8-shared-neighbor'] = R / 'tests/graph_route_cuda/fp8_shared_prologue_test.cc'
    h.compile_one('fp8-shared-neighbor', attempt)

def link(attempt):
    records = sorted(S.glob('compile*/glm-original-chain/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    assert records
    record_path = records[-1]
    record = c.read(record_path)
    assert all(b.identity(x['path']) == x for x in [record['source'], record['object'], *record['dependencies']])
    base = c.read(BASE / 'link-plan.json')
    remove = set()
    for item in base['compiled_records']:
        rec = c.read(item['path'])
        if '/tests/' in rec['source']['path'].replace('\\', '/'):
            remove.add(c.key(rec['object']['path']))
    added = [record['object']]
    compiled_records = [b.identity(record_path)]
    providers = sorted(S.glob('compile*/fp8-provider/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    if providers:
        provider_path = providers[-1]
        provider = c.read(provider_path)
        assert all(b.identity(x['path']) == x for x in [provider['source'], provider['object'], *provider['dependencies']])
        remove.add(c.key(c.read(PROVIDER_RECIPE)['object']['path']))
        added.append(provider['object'])
        compiled_records.append(b.identity(provider_path))
    neighbors = sorted(S.glob('compile*/fp8-shared-neighbor/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    if neighbors:
        neighbor_path = neighbors[-1]
        neighbor = c.read(neighbor_path)
        assert all(b.identity(x['path']) == x for x in [neighbor['source'], neighbor['object'], *neighbor['dependencies']])
        added.append(neighbor['object'])
        compiled_records.append(b.identity(neighbor_path))
    inputs = added + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [x['path'] for x in added]
    folder = S / f'chain-link{attempt}'
    folder.mkdir()
    (folder / 'tmp').mkdir()
    image = folder / 'glm-original-chain-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(folder / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=compiled_records, base=b.identity(BASE / 'link-plan.json'),
        SDK_builds=0, NVCC_builds=0, shader_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], folder)
    c.execute('link', command, env, folder)
    runtime = c.read(BASE / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        os.link(item['path'], folder / Path(item['path']).name)
    runtime['staged_dlls'] = [b.identity(path) for path in folder.glob('*.dll')]
    c.save(folder / 'runtime-environment.json', runtime)
    c.save(folder / 'ready.json', dict(image=b.identity(image)))
    print('LINKED', image, flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('actions', nargs='+', choices=['compile', 'compile-provider', 'compile-neighbor', 'link'])
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    for action in args.actions:
        if action == 'compile': compile_one(args.attempt)
        elif action == 'compile-provider': compile_provider(args.attempt)
        elif action == 'compile-neighbor': compile_neighbor(args.attempt)
        else: link(args.attempt)
