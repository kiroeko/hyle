"""Acquire the pinned small GLM Flash NextN E4/scale pair by exact ranges."""
from pathlib import Path
import hashlib
import json
import re
import struct
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
review = json.loads((R / '.scratch/qwen24-original-mtp-20261022/review/remaining-mtp.json').read_text(encoding='utf-8'))
facts = next(x for x in review['GLM_original_FP8_detail']['small_original_pairs_ready_for_binding']
             if x['name'] == 'glm53_flash_official_full_nextn_q_a_E4_original_scale')
repo, revision = facts['identity']['repository'], facts['identity']['revision']
folder = S / 'original-glm-q-a'
folder.mkdir(exist_ok=False)
url = f"https://huggingface.co/{repo}/resolve/{revision}/{facts['file']}"
receipt = dict(repository=repo, revision=revision, file=facts['file'], url=url,
               requests=[], roles=[], complete=False, whole_shard_allowed=False)

def save():
    (folder / 'acquisition.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

def fetch(first, last, name):
    count = last - first + 1
    record = dict(first=first, last=last, bytes=count, complete=False)
    receipt['requests'].append(record)
    save()
    request = urllib.request.Request(url, headers={'Range': f'bytes={first}-{last}',
        'Accept-Encoding': 'identity', 'User-Agent': 'hyle-pinned-original-role/1'})
    with urllib.request.urlopen(request, timeout=45) as response:
        raw_range = response.headers.get('Content-Range', '')
        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', raw_range)
        assert response.status == 206 and match and (int(match[1]), int(match[2])) == (first, last), \
            'Refuse non-exact/whole-shard body before reading'
        assert response.headers.get('Content-Length') in (None, str(count))
        total = int(match[3])
        etag = response.headers.get('ETag')
        assert etag
        if 'file_bytes' in receipt:
            assert (receipt['file_bytes'], receipt['etag']) == (total, etag)
        receipt.update(file_bytes=total, etag=etag)
        record.update(http_status=206, content_range=raw_range, etag=etag)
        path = folder / name
        digest, remaining = hashlib.sha256(), count
        with path.open('xb') as output:
            while remaining:
                chunk = response.read(min(1 << 20, remaining))
                assert chunk, 'Truncated range'
                output.write(chunk)
                digest.update(chunk)
                remaining -= len(chunk)
            assert not response.read(1), 'Excess range'
    record.update(complete=True, payload=dict(path=str(path), bytes=count, sha256=digest.hexdigest()))
    save()
    return record['payload']

fetch(0, 7, 'header-length.bin')
length = struct.unpack('<Q', (folder / 'header-length.bin').read_bytes())[0]
assert 2 <= length <= 8 << 20
fetch(8, 7 + length, 'header.json')
header = json.loads((folder / 'header.json').read_bytes())
receipt['data_start'] = 8 + length
for role, name in zip(facts['roles'], ['q_a.weight.e4m3', 'q_a.weight_scale.f32']):
    actual = header[role['name']]
    assert actual['dtype'] == role['codec'] and actual['shape'] == role['shape']
    assert actual['data_offsets'] == role['relative_offsets']
    first, end = actual['data_offsets']
    assert end - first == role['bytes']
    payload = fetch(receipt['data_start'] + first, receipt['data_start'] + end - 1, name)
    receipt['roles'].append(dict(name=role['name'], dtype=actual['dtype'], shape=actual['shape'],
        data_relative_offsets=[first, end], payload=payload))
    save()
    print(role['name'], payload['sha256'], flush=True)
receipt['complete'] = True
save()
