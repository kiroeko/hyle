"""Acquire the original decoder input norm from the retained first-shard facts."""
from pathlib import Path
import hashlib
import json
import urllib.request

T = Path(__file__).resolve().parent
R = T.parents[1]
S = T / 'original-glm-q-a'
AX = R / '.scratch/dspark-natural-journey-20261022/original-glm-input'
source = json.loads((AX / 'acquisition.json').read_text(encoding='utf-8'))
header = json.loads((AX / 'header.json').read_bytes())
name = 'model.language_model.layers.45.input_layernorm.weight'
role = header[name]
assert role == dict(dtype='BF16', shape=[4096], data_offsets=[2605352960, 2605361152])
first, end = [source['data_start'] + x for x in role['data_offsets']]
assert end - first == 8192
etag = next(x['etag'] for x in source['requests'] if x['complete'])
record = dict(repository=source['repository'], revision=source['revision'], file=source['shard'],
    url=source['url'], role=name, dtype='BF16', shape=[4096],
    data_relative_offsets=role['data_offsets'], first=first, last=end - 1, complete=False)
receipt = S / 'inputnorm-acquisition.json'
assert not receipt.exists()

def save():
    receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')

save()
request = urllib.request.Request(source['url'], headers={'Range': f'bytes={first}-{end - 1}',
    'Accept-Encoding': 'identity', 'User-Agent': 'hyle-pinned-original-role/1'})
with urllib.request.urlopen(request, timeout=45) as response:
    assert response.status == 206
    assert response.headers.get('Content-Range') == f"bytes {first}-{end - 1}/{source['shard_bytes']}"
    assert response.headers.get('ETag') == etag
    assert response.headers.get('Content-Length') in (None, '8192')
    body = response.read(8193)
    assert len(body) == 8192
path = S / 'input_layernorm.weight.bf16'
with path.open('xb') as output:
    output.write(body)
record.update(complete=True, http_status=206, content_range=response.headers['Content-Range'],
    etag=etag, payload=dict(path=str(path), bytes=8192, sha256=hashlib.sha256(body).hexdigest()))
save()
print(json.dumps(record['payload'], indent=2))
