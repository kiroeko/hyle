"""Root-run diagnostic for the exact existing CUDA FP8 quantizer; no compilation.

Default: compare generation0 actual BF16 nx -> 4096 E4 codes +32 F32 scales.
Optional --gemm also launches the existing F32-output GEMM at this one shape.
--block-dots isolates row25's32 code-domain dots in three same-shape launches.
All output stays under this round's scratch directory. This is not a provider,
fallback, benchmark, threshold change or replacement for the failing test.
"""
import argparse
import ctypes as ct
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import time

sys.dont_write_bytecode = True
ROUND = Path(__file__).resolve().parents[1]
ROOT = ROUND.parents[1]
QUANT_SHA = '8f871453172b0e979ea2631df64af251a1f936d6cf7101f1bfae6b8f714a8b66'
GEMM_SHA = '24b0e9051883dcd3467ba56fd7aceb803f1d6fc4db9545faeae48cd3403f8cda'
WEIGHT_SHA = '615e317d19a83114b756e4634599ebba333c95241f3e775c77cc1633802d8be6'
SCALE_SHA = 'c93393c24ed2c12f5458fbf88a257df91e22f586acc58436b861465c56f4d3fb'
FP8 = ROOT / 'third_party/sglang_activation/fp8'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}


def inside_round(path):
    path = path.resolve()
    if not path.is_relative_to(ROUND):
        raise ValueError('Probe input/output must stay inside this round: ' + str(path))
    return path


def header_array(path, name, expected):
    text = path.read_text(encoding='utf-8')
    match = re.search(r'unsigned char\s+' + re.escape(name) + r'\[\]\s*=\s*\{([^}]*)\};', text, re.S)
    if not match:
        raise ValueError('Missing exact cubin array ' + name)
    raw = bytes(int(value, 16) for value in re.findall(r'0x([0-9a-fA-F]{2})', match[1]))
    if digest(raw) != expected:
        raise ValueError('Exact existing cubin SHA differs: ' + name)
    return raw, text


class Driver:
    def __init__(self):
        self.dll = ct.WinDLL('nvcuda.dll') if os.name == 'nt' else ct.CDLL('libcuda.so.1')
        self.functions = {}
        self.bind('cuInit', [ct.c_uint])
        self.bind('cuDeviceGet', [ct.POINTER(ct.c_int), ct.c_int])
        self.bind('cuDeviceGetName', [ct.c_void_p, ct.c_int, ct.c_int])
        self.bind('cuCtxGetCurrent', [ct.POINTER(ct.c_void_p)])
        self.bind('cuCtxSetCurrent', [ct.c_void_p])
        self.bind('cuDevicePrimaryCtxRetain', [ct.POINTER(ct.c_void_p), ct.c_int])
        self.bind('primary_release', [ct.c_int], ('cuDevicePrimaryCtxRelease_v2', 'cuDevicePrimaryCtxRelease'))
        self.bind('cuStreamCreate', [ct.POINTER(ct.c_void_p), ct.c_uint])
        self.bind('cuStreamSynchronize', [ct.c_void_p])
        self.bind('stream_destroy', [ct.c_void_p], ('cuStreamDestroy_v2', 'cuStreamDestroy'))
        self.bind('mem_alloc', [ct.POINTER(ct.c_uint64), ct.c_size_t], ('cuMemAlloc_v2',))
        self.bind('mem_free', [ct.c_uint64], ('cuMemFree_v2',))
        self.bind('htod', [ct.c_uint64, ct.c_void_p, ct.c_size_t], ('cuMemcpyHtoD_v2',))
        self.bind('dtoh', [ct.c_void_p, ct.c_uint64, ct.c_size_t], ('cuMemcpyDtoH_v2',))
        self.bind('cuModuleLoadData', [ct.POINTER(ct.c_void_p), ct.c_void_p])
        self.bind('cuModuleGetFunction', [ct.POINTER(ct.c_void_p), ct.c_void_p, ct.c_char_p])
        self.bind('cuModuleUnload', [ct.c_void_p])
        self.bind('cuLaunchKernel', [ct.c_void_p] + [ct.c_uint] * 7 + [ct.c_void_p,
                  ct.POINTER(ct.c_void_p), ct.POINTER(ct.c_void_p)])
        self.bind('cuGetErrorName', [ct.c_int, ct.POINTER(ct.c_char_p)])
        self.bind('cuGetErrorString', [ct.c_int, ct.POINTER(ct.c_char_p)])
        if hasattr(self.dll, 'cuFuncLoad'):
            self.bind('cuFuncLoad', [ct.c_void_p])

    def bind(self, name, args, exports=None):
        for export in exports or (name,):
            if hasattr(self.dll, export):
                fn = getattr(self.dll, export)
                fn.argtypes, fn.restype = args, ct.c_int
                self.functions[name] = fn
                return
        raise RuntimeError('Missing CUDA driver export: ' + name)

    def call(self, name, *args):
        code = self.functions[name](*args)
        if code:
            label, detail = ct.c_char_p(), ct.c_char_p()
            self.functions['cuGetErrorName'](code, ct.byref(label))
            self.functions['cuGetErrorString'](code, ct.byref(detail))
            raise RuntimeError(f'{name}: {code} {label.value!r} {detail.value!r}')

    def launch(self, function, grid, block, shared, stream, arguments):
        # kernelParams contains pointers to the actual ABI argument storage.
        params = (ct.c_void_p * len(arguments))(*(ct.addressof(value) for value in arguments))
        self.call('cuLaunchKernel', function, grid, 1, 1, block, 1, 1,
                  shared, stream, params, None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--nx', type=Path, default=ROUND / 'diagnostics2/cuda-generation-0-nx.bf16')
    parser.add_argument('--actual', type=Path, default=ROUND / 'diagnostics2/cuda-generation-0-qa.bf16')
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--gemm', action='store_true', help='Also one existing F32 GEMM, same M1/N1536/K4096')
    parser.add_argument('--block-dots', action='store_true',
                        help='Three same-shape GEMMs isolate32 K128 raw code dots for original row25')
    args = parser.parse_args()
    default_output = ROUND / ('diagnostics2/native-quant-probe2' if args.block_dots
                             else 'diagnostics2/native-quant-probe1')
    nx_path, out = inside_round(args.nx), inside_round(args.output_dir or default_output)
    actual_path = inside_round(args.actual)
    nx = nx_path.read_bytes()
    if len(nx) != 8192:
        raise ValueError('Expected exactly BF16[1,4096] actual normalized input')
    if args.gemm and len(actual_path.read_bytes()) != 3072:
        raise ValueError('Expected exactly BF16[1,1536] actual q_a output')
    out.mkdir(exist_ok=False)
    result = {'scope': 'single actual generation0 quantizer/code-scale discriminator',
              'source': identity(Path(__file__)), 'input': identity(nx_path),
              'throughput_evidence': False, 'memory_evidence': False,
              'sdk_builds': 0, 'native_compilations': 0, 'threshold_changes': 0,
              'started_unix': time.time(), 'success': False, 'cleanup_errors': []}
    receipt = out / 'result.json'

    def save():
        receipt.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')

    # This module's quantize/nearest enumerate the independent source-agent
    # RNE oracle. Import performs no native call and no product inference.
    oracle_path = ROUND / 'original-chain-source/diagnose_qa.py'
    spec = importlib.util.spec_from_file_location('glm_independent_qa_diagnostic', oracle_path)
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    result['independent_oracle'] = identity(oracle_path)
    words = struct.unpack('<4096H', nx)
    reference_codes, reference_scales = oracle.quantize(list(map(oracle.wide, words)), 'divide')
    reference_codes = bytes(reference_codes)
    reference_scale_bytes = struct.pack('<32f', *reference_scales)
    (out / 'independent-codes.e4m3').write_bytes(reference_codes)
    (out / 'independent-scales.f32').write_bytes(reference_scale_bytes)
    save()

    driver = None
    device, previous, primary, stream = ct.c_int(), ct.c_void_p(), ct.c_void_p(), ct.c_void_p()
    retained = False
    allocations, modules, cubin_buffers = [], [], []
    failure = None

    def allocate(size, raw=None):
        pointer = ct.c_uint64()
        driver.call('mem_alloc', ct.byref(pointer), size)
        allocations.append(pointer)
        if raw is not None:
            if len(raw) != size:
                raise ValueError('Native diagnostic allocation extent differs')
            storage = ct.create_string_buffer(raw)
            driver.call('htod', pointer, ct.cast(storage, ct.c_void_p), size)
        return pointer.value

    def download(pointer, size):
        target = ct.create_string_buffer(size)
        driver.call('dtoh', ct.cast(target, ct.c_void_p), pointer, size)
        return target.raw

    def load_kernel(raw, symbol):
        storage = ct.create_string_buffer(raw)
        cubin_buffers.append(storage)
        module, function = ct.c_void_p(), ct.c_void_p()
        driver.call('cuModuleLoadData', ct.byref(module), ct.cast(storage, ct.c_void_p))
        modules.append(module)
        driver.call('cuModuleGetFunction', ct.byref(function), module, symbol.encode('ascii'))
        if 'cuFuncLoad' in driver.functions:
            driver.call('cuFuncLoad', function)
        return function

    def gemm_arguments(activation, weight, destination, weight_code_bytes):
        # Identical M1/N1536/K4096 and original20-argument ABI for every probe.
        arguments = [ct.c_uint64(value) for value in
                     (activation, weight, destination, activation + 4096, weight + weight_code_bytes)]
        arguments += [ct.c_int(value) for value in
                      (1, 1536, 4096, 4096, 1, 1, 4096, 1536, 1, 32, 1, 1, 32)]
        arguments += [ct.c_uint64(0), ct.c_uint64(0)]
        return arguments

    try:
        raw, header = header_array(FP8 / 'sglang_fp8_quantize_cuda_sm89.h', 'kSglangFp8QuantizeCuda', QUANT_SHA)
        symbol_match = re.search(r'char\s+kSglangFp8QuantizeBf16Name\[\]\s*=\s*"([^"]+)"', header)
        if not symbol_match:
            raise ValueError('Missing exact Divide/BF16 symbol')
        symbol = symbol_match[1]
        driver = Driver()
        driver.call('cuInit', 0)
        driver.call('cuCtxGetCurrent', ct.byref(previous))
        driver.call('cuDeviceGet', ct.byref(device), 0)
        name = ct.create_string_buffer(256)
        driver.call('cuDeviceGetName', name, len(name), device)
        result['device'] = {'ordinal': 0, 'name': name.value.decode('utf-8', 'replace')}
        driver.call('cuDevicePrimaryCtxRetain', ct.byref(primary), device)
        retained = True
        driver.call('cuCtxSetCurrent', primary)
        driver.call('cuStreamCreate', ct.byref(stream), 0)
        function = load_kernel(raw, symbol)
        source = allocate(len(nx), nx)
        encoded = allocate(4096 + 32 * 4)
        # Exact original11-argument CUDA ABI; 32 groups,16 groups/block.
        quant_args = [ct.c_uint64(source), ct.c_uint64(encoded), ct.c_uint64(encoded + 4096),
                      ct.c_int(128), ct.c_int(32), ct.c_int(16), ct.c_float(1e-10),
                      ct.c_float(-448), ct.c_float(448), ct.c_int(0), ct.c_int(0)]
        driver.launch(function, 2, 256, 0, stream, quant_args)
        driver.call('cuStreamSynchronize', stream)
        actual_encoded = download(encoded, 4096 + 32 * 4)
        codes, scale_bytes = actual_encoded[:4096], actual_encoded[4096:]
        (out / 'cuda-codes.e4m3').write_bytes(codes)
        (out / 'cuda-scales.f32').write_bytes(scale_bytes)
        actual_scales = struct.unpack('<32f', scale_bytes)
        code_mismatches = [{'column': index, 'group': index // 128,
                            'input_bf16': words[index], 'input': oracle.wide(words[index]),
                            'actual_code': got, 'independent_code': reference_codes[index]}
                           for index, got in enumerate(codes) if got != reference_codes[index]]
        scale_mismatches = [{'group': index, 'actual': actual_scales[index],
                             'independent': reference_scales[index],
                             'actual_bits': scale_bytes[index * 4:index * 4 + 4].hex(),
                             'independent_bits': reference_scale_bytes[index * 4:index * 4 + 4].hex()}
                            for index in range(32)
                            if scale_bytes[index * 4:index * 4 + 4] != reference_scale_bytes[index * 4:index * 4 + 4]]
        result['quantizer'] = {'cubin_sha256': QUANT_SHA, 'symbol': symbol,
            'launch': {'grid': [2, 1, 1], 'block': [256, 1, 1], 'shared_bytes': 0, 'arguments': 11},
            'code_count': len(codes), 'scale_count': len(actual_scales),
            'code_mismatches': code_mismatches, 'scale_mismatches': scale_mismatches,
            'code_bytes_equal': codes == reference_codes,
            'scale_bits_equal': scale_bytes == reference_scale_bytes,
            'actual_scale_values': list(actual_scales),
            'actual_codes_sha256': digest(codes), 'actual_scales_sha256': digest(scale_bytes)}
        save()

        if args.gemm or args.block_dots:
            weights = (ROUND / 'original-glm-q-a/q_a.weight.e4m3').read_bytes()
            weight_scale_bytes = (ROUND / 'original-glm-q-a/q_a.weight_scale.f32').read_bytes()
            if len(weights) != 1536 * 4096 or digest(weights) != WEIGHT_SHA:
                raise ValueError('Original q_a code identity differs')
            if len(weight_scale_bytes) != 384 * 4 or digest(weight_scale_bytes) != SCALE_SHA:
                raise ValueError('Original q_a scale identity differs')
            gemm_blob, _ = header_array(FP8 / 'sglang_fp8_sm89.h', 'kSglangFp8Sm89', GEMM_SHA)
            gemm = load_kernel(gemm_blob, '_w8a8_block_fp8_matmul')

        if args.gemm:
            weight = allocate(len(weights) + len(weight_scale_bytes), weights + weight_scale_bytes)
            destination = allocate(1536 * 4)
            # Five pointers, thirteen i32 values and two zero-sized scratch
            # pointers: exact original Triton3.8 ABI in fp8_provider.cc.
            arguments = gemm_arguments(encoded, weight, destination, len(weights))
            driver.launch(gemm, 12, 128, 24576, stream, arguments)
            driver.call('cuStreamSynchronize', stream)
            output = download(destination, 1536 * 4)
            (out / 'cuda-gemm-f32.bin').write_bytes(output)
            output_values = struct.unpack('<1536f', output)
            actual_bf16 = struct.unpack('<1536H', actual_path.read_bytes())
            rounded = [oracle.bf16(value) for value in output_values]
            mismatches = [{'row': index, 'f32': output_values[index],
                           'f32_rounded_bf16': rounded[index], 'actual_bf16': actual_bf16[index],
                           'actual': oracle.wide(actual_bf16[index])}
                          for index in range(1536) if rounded[index] != actual_bf16[index]]
            independent_row = oracle.project(25, codes, actual_scales, weights,
                                            struct.unpack('<384f', weight_scale_bytes))
            result['gemm'] = {'cubin_sha256': GEMM_SHA,
                'scope': 'one F32-output existing GEMM at actual M1/N1536/K4096; not a shape matrix',
                'launch': {'grid': [12, 1, 1], 'block': [128, 1, 1], 'shared_bytes': 24576, 'arguments': 20},
                'f32_output_sha256': digest(output), 'actual_bf16': identity(actual_path),
                'rounded_f32_matches_actual_bf16': not mismatches, 'mismatches': mismatches,
                'row25': {'native_f32': output_values[25], 'rounded_bf16': rounded[25],
                          'actual_bf16': actual_bf16[25], 'actual': oracle.wide(actual_bf16[25]),
                          'independent_from_native_codes_scales': independent_row}}

        if args.block_dots:
            # Diagnostic parameters only: zero/one scale selectors isolate an
            # existing kernel's raw code-domain dot. They do not replace a model
            # weight, relax a public operation contract or change a product gate.
            # A keeps the actual4096 E4 codes, with all32 activation scales1.
            # Every B row repeats original row25; tile t (128 output rows) uses
            # a one-hot K-group scale.12 tiles/launch expose32 groups in3 calls.
            row_codes = weights[25 * 4096:26 * 4096]
            repeated_codes = row_codes * 1536
            unit_activation = codes + struct.pack('<32f', *([1.0] * 32))
            unit_a = allocate(len(unit_activation), unit_activation)
            selected_b = allocate(len(repeated_codes) + 384 * 4,
                                  repeated_codes + bytes(384 * 4))
            selected_c = allocate(1536 * 4)
            # Predeclared F32 sequential-dot forward-error reference. E4
            # products are exactly representable in F32 and have no F32
            # subnormal/overflow risk; the128-add gamma127 bound is therefore
            # a useful discriminator. It is not a newly approved product gate.
            unit_roundoff = 2.0 ** -24
            gamma127 = 127 * unit_roundoff / (1 - 127 * unit_roundoff)
            block_result = {'scope': 'raw row25 K128 code dots;3 launches;one unchanged M1/N1536/K4096 shape',
                'cubin_sha256': GEMM_SHA, 'diagnostic_only_scale_selectors': True,
                'original_weight_sha256': WEIGHT_SHA, 'source_row': 25,
                'unit_roundoff': unit_roundoff, 'gamma127': gamma127,
                'bound_definition': 'gamma127 * exact_sum(abs(code_a*code_b)); predeclared, not fitted to actual error',
                'not_a_product_accuracy_gate': True,
                'f32_subnormal_products_possible': False,
                'e4_nonzero_product_minimum_possible': 2.0 ** -18,
                'tile_size': 128, 'tiles_per_launch': 12, 'launches': [], 'groups': []}
            result['block_dots'] = block_result
            for launch_index in range(3):
                selector = [0.0] * 384
                selected_groups = []
                for tile in range(12):
                    group = launch_index * 12 + tile
                    if group < 32:
                        selector[tile * 32 + group] = 1.0
                        selected_groups.append(group)
                selector_bytes = struct.pack('<384f', *selector)
                selector_buffer = ct.create_string_buffer(selector_bytes)
                driver.call('htod', selected_b + len(repeated_codes),
                            ct.cast(selector_buffer, ct.c_void_p), len(selector_bytes))
                driver.launch(gemm, 12, 128, 24576, stream,
                              gemm_arguments(unit_a, selected_b, selected_c, len(repeated_codes)))
                driver.call('cuStreamSynchronize', stream)
                raw_dots = download(selected_c, 1536 * 4)
                payload = out / f'cuda-block-dots-launch{launch_index}.f32'
                payload.write_bytes(raw_dots)
                block_result['launches'].append({'index': launch_index, 'groups': selected_groups,
                    'grid': [12, 1, 1], 'block': [128, 1, 1], 'shared_bytes': 24576,
                    'arguments': 20, 'output': identity(payload)})
                outputs = struct.unpack('<1536f', raw_dots)
                for tile, group in enumerate(selected_groups):
                    a_codes = codes[group * 128:(group + 1) * 128]
                    b_codes = row_codes[group * 128:(group + 1) * 128]
                    a_values = [oracle.e4(value) for value in a_codes]
                    b_values = [oracle.e4(value) for value in b_codes]
                    terms = [a * b for a, b in zip(a_values, b_values)]
                    exact = math.fsum(terms)
                    sumabs = math.fsum(map(abs, terms))
                    bound = gamma127 * sumabs
                    actual = outputs[tile * 128]
                    tile_bytes = raw_dots[tile * 128 * 4:(tile + 1) * 128 * 4]
                    patterns = sorted({tile_bytes[index:index + 4].hex()
                                       for index in range(0, len(tile_bytes), 4)})
                    serial = 0.0
                    for value in terms:
                        serial = oracle.f32(serial + value)
                    reverse_serial = 0.0
                    for value in reversed(terms):
                        reverse_serial = oracle.f32(reverse_serial + value)
                    sub_a = [0 < (value & 127) < 8 for value in a_codes]
                    sub_b = [0 < (value & 127) < 8 for value in b_codes]
                    # Explicit counterfactuals aid diagnosis; matching one is
                    # not evidence that flushing is legal or should be enabled.
                    flush_a = math.fsum(0.0 if sub_a[index] else term
                                       for index, term in enumerate(terms))
                    flush_b = math.fsum(0.0 if sub_b[index] else term
                                       for index, term in enumerate(terms))
                    flush_both = math.fsum(0.0 if sub_a[index] or sub_b[index] else term
                                          for index, term in enumerate(terms))
                    block_result['groups'].append({'group': group, 'launch': launch_index, 'tile': tile,
                        'actual': actual, 'actual_f32_bits': struct.pack('<f', actual).hex(),
                        'all128_repeated_rows_bit_identical': len(patterns) == 1,
                        'tile_f32_bit_patterns': patterns,
                        'exact_code_dot': exact, 'exact_rounded_f32': oracle.f32(exact),
                        'signed_error_from_exact': actual - exact, 'absolute_error': abs(actual - exact),
                        'sum_abs_code_products': sumabs, 'gamma127_abs_bound': bound,
                        'error_within_gamma127_bound': math.isfinite(actual) and abs(actual - exact) <= bound,
                        'scalar_f32_left_to_right': serial, 'scalar_f32_right_to_left': reverse_serial,
                        'e4_subnormal_a_count': sum(sub_a), 'e4_subnormal_b_count': sum(sub_b),
                        'counterfactual_flush_e4_a_f32': oracle.f32(flush_a),
                        'counterfactual_flush_e4_b_f32': oracle.f32(flush_b),
                        'counterfactual_flush_e4_both_f32': oracle.f32(flush_both)})
                save()
            block_result['group_count'] = len(block_result['groups'])
            block_result['all_tiles_bit_identical'] = all(item['all128_repeated_rows_bit_identical']
                                                         for item in block_result['groups'])
            block_result['groups_outside_gamma127_bound'] = [item['group'] for item in block_result['groups']
                                                            if not item['error_within_gamma127_bound']]
            block_result['groups_with_nonzero_dot_error'] = [item['group'] for item in block_result['groups']
                                                            if item['absolute_error'] != 0]
            block_result['interpretation'] = ('Diagnostic observations only. Do not infer an instruction implementation, '
                'legal accuracy or a product threshold change merely from a matching counterfactual or bound.')
        result['success'] = not code_mismatches and not scale_mismatches
    except BaseException as exc:
        failure = exc
        result['error'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        if driver is not None:
            def cleanup(name, *values):
                try:
                    driver.call(name, *values)
                except BaseException as exc:
                    result['cleanup_errors'].append({'operation': name, 'message': str(exc)})
            if retained:
                cleanup('cuCtxSetCurrent', primary)
            if stream.value:
                cleanup('cuStreamSynchronize', stream)
            for pointer in reversed(allocations):
                cleanup('mem_free', pointer)
            for module in reversed(modules):
                cleanup('cuModuleUnload', module)
            if stream.value:
                cleanup('stream_destroy', stream)
            if retained:
                cleanup('cuCtxSetCurrent', previous)
                cleanup('primary_release', device)
        result['finished_unix'] = time.time()
        if result['cleanup_errors']:
            result['success'] = False
        save()
    print(json.dumps({'receipt': str(receipt), 'success': result['success'],
                      'code_mismatches': len(result.get('quantizer', {}).get('code_mismatches', [])),
                      'scale_mismatches': len(result.get('quantizer', {}).get('scale_mismatches', [])),
                      'cleanup_errors': result['cleanup_errors']}), flush=True)
    if failure is not None:
        raise failure
    if not result['success']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
