"""Offline exact dyadic F32 multiply/FMA composition; never calls CUDA."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import struct

S = Path(__file__).resolve().parents[1]
D = S / 'diagnostics2'


def round_f32(value):
    """Round an exact Fraction directly to binary32 RN-even, no F64 stage."""
    if not value:
        return 0.0
    sign = value < 0
    value = abs(value)
    n, d = value.numerator, value.denominator
    exponent = n.bit_length() - d.bit_length()
    if value < Fraction(2) ** exponent:
        exponent -= 1
    unit = Fraction(2) ** max(exponent - 23, -149)
    scaled = value / unit
    q, r = divmod(scaled.numerator, scaled.denominator)
    q += 2 * r > scaled.denominator or (2 * r == scaled.denominator and q % 2)
    if exponent < -126:
        bits = q
    else:
        if q == 1 << 24:
            q >>= 1
            exponent += 1
        if exponent > 127:
            bits = 0x7f800000
        else:
            bits = ((exponent + 127) << 23) | (q - (1 << 23))
    bits |= int(sign) << 31
    return struct.unpack('<f', struct.pack('<I', bits))[0]


def exact(value):
    return Fraction.from_float(value)


def bits(value):
    return struct.pack('<f', value).hex()


raw = json.loads((D / 'native-quant-probe2/result.json').read_text(encoding='utf-8'))
full = json.loads((D / 'native-quant-probe1/result.json').read_text(encoding='utf-8'))
scales = raw['quantizer']['actual_scale_values']
weight_bytes = (S / 'original-glm-q-a/q_a.weight_scale.f32').read_bytes()
assert hashlib.sha256(weight_bytes).hexdigest() == 'c93393c24ed2c12f5458fbf88a257df91e22f586acc58436b861465c56f4d3fb'
weights = struct.unpack('<384f', weight_bytes)
groups = sorted(raw['block_dots']['groups'], key=lambda value: value['group'])
assert [group['group'] for group in groups] == list(range(32))
accumulator = 0.0
stages = []
for group in groups:
    index = group['group']
    scaled = round_f32(exact(group['actual']) * exact(scales[index]))
    accumulator = round_f32(exact(scaled) * exact(weights[index]) + exact(accumulator))
    stages.append({'group': index, 'native_raw_dot': group['actual'],
                   'activation_scale': scales[index], 'weight_scale': weights[index],
                   'rounded_f32_scaled_dot': scaled, 'exactly_rounded_fma_accumulator': accumulator})
target = full['gemm']['row25']['native_f32']
result = {'scope': 'offline exact composition of32 actual selector raw dots with unchanged original scales',
    'method': 'exact Fraction arithmetic, direct F32 RN-even after dot*activation_scale and after fused scaled_dot*weight_scale+accumulator',
    'native_raw_dots_source': str(D / 'native-quant-probe2/result.json'),
    'native_complete_gemm_source': str(D / 'native-quant-probe1/result.json'),
    'reconstructed': accumulator, 'reconstructed_f32_bits': bits(accumulator),
    'complete_native_f32': target, 'complete_native_f32_bits': bits(target),
    'bit_identical': bits(accumulator) == bits(target),
    'stages': stages, 'native_calls': 0, 'threshold_changes': 0}
output = D / 'raw-dot-composition.json'
output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in ('reconstructed', 'complete_native_f32', 'bit_identical')}))
