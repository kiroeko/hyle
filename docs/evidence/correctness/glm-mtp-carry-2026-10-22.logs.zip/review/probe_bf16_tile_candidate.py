"""Use the existing failure probe with the one candidate F32 GEMM image."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parents[1]
path = S / 'review/native_quant_probe.py'
spec = importlib.util.spec_from_file_location('candidate_native_probe', path)
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
candidate = S / 'bf16-tile-candidate2'
metadata = json.loads((candidate / 'compilation.json').read_text(encoding='utf-8'))
kernel = next(x for x in metadata['kernels'] if x['label'] == 'matmul')
assert kernel['metadata']['shared'] <= 24576
read_header = p.header_array

def image(path, name, expected):
    if name != 'kSglangFp8Sm89':
        return read_header(path, name, expected)
    blob = (candidate / 'matmul.cubin').read_bytes()
    assert p.digest(blob) == expected == kernel['sha256']
    return blob, ''

p.header_array = image
p.GEMM_SHA = kernel['sha256']
out = S / 'diagnostics2/native-quant-probe3-bf16-tile'
sys.argv = [str(path), '--gemm', '--block-dots', '--output-dir', str(out)]
p.main()
report_path = out / 'result.json'
report = json.loads(report_path.read_text(encoding='utf-8'))
report['candidate_wrapper'] = p.identity(Path(__file__))
report['candidate_compilation'] = p.identity(candidate / 'compilation.json')
report['candidate_note'] = 'Candidate F32 GEMM only, ordinary quantizer unchanged. Existing probe launch24576B is above required16384B. No production module/route changed by this diagnostic.'
report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(outside_gamma127=report['block_dots']['groups_outside_gamma127_bound'],
    raw_dot_nonzero_errors=report['block_dots']['groups_with_nonzero_dot_error'],
    candidate_row25=report['gemm'].get('row25')), indent=2))
