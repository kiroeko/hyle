#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/cuda_fp4.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void fp4_quant_kernel__kernel(float* __restrict__ S, const bfloat16_t* __restrict__ X, bfloat16_t* __restrict__ Y, int M);
extern "C" __global__ void __launch_bounds__(128, 1) fp4_quant_kernel__kernel(float* __restrict__ S, const bfloat16_t* __restrict__ X, bfloat16_t* __restrict__ Y, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* x_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* y_shared = ((void*)((char*)buf_dyn_shmem + 0));
  bfloat16_t x_local[8];
  float amax_local[1];
  float s_local[1];
  bfloat16_t y_local[8];
  tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)x_shared)[(((int)threadIdx.x) * 8)])), (&(X[((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)8))])), ((((((int)blockIdx.x) * 32) + (((int)threadIdx.x) >> 2)) < M) && (((((int)blockIdx.x) * 32) + (((int)threadIdx.x) >> 2)) < M)));
  tl::cp_async_commit();
  tl::cp_async_wait<0>();
  __syncthreads();
  *(uint4*)(x_local + 0) = *(uint4*)(((bfloat16_t*)x_shared) + (((int)threadIdx.x) * 8));
  amax_local[0] = 0x0p+0f/*0.000000e+00*/;
  #pragma unroll
  for (int rv = 0; rv < 8; ++rv) {
    amax_local[0] = max(amax_local[0], max(((float)x_local[rv]), (0x0p+0f/*0.000000e+00*/ - ((float)x_local[rv]))));
  }
  amax_local[0] = tl::AllReduce<tl::MaxOp, 4, 1, 0, tl::NamedBarrier<128>>::run(amax_local[0]);
  amax_local[0] = max(amax_local[0], 0x1.8p-124f/*7.052966e-38*/);
  float v_ = amax_local[0] * 0x1.5555555555555p-3f/*1.666667e-01*/;
  float v__1 = amax_local[0] * 0x1.5555555555555p-3f/*1.666667e-01*/;
  int condval;
  if ((((*(uint *)(&(v__1))) & (uint)8388607) != (uint)0)) {
    condval = 1;
  } else {
    condval = 0;
  }
  int v__2 = (((int)(((((*(uint *)(&(v_))) >> (uint)23) & (uint)255) - (uint)127) + ((uint)condval))) + 127) << 23;
  s_local[0] = (*(float *)(&(v__2)));
  #pragma unroll
  for (int i = 0; i < 2; ++i) {
    float broadcast_var = -0x1.8p+2f/*-6.000000e+00*/;
    float broadcast_var_1 = 0x1.8p+2f/*6.000000e+00*/;
    uint2 __1;
    float4 __2;
      float4 __3;
      fp4_e2_4_t __4;
      float4 __5;
        float4 __6;
          float4 __7;
            float4 __8;
            uint2 v__3 = *(uint2*)(x_local + (i * 4));
            ((float2*)(&__8))[0] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__3))[0]);
            ((float2*)(&__8))[1] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__3))[1]);
            float4 v__4 = make_float4(s_local[0], s_local[0], s_local[0], s_local[0]);
            __7.x = (__8.x/v__4.x);
            __7.y = (__8.y/v__4.y);
            __7.z = (__8.z/v__4.z);
            __7.w = (__8.w/v__4.w);
          float4 v__5 = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
          __6.x = max(__7.x, v__5.x);
          __6.y = max(__7.y, v__5.y);
          __6.z = max(__7.z, v__5.z);
          __6.w = max(__7.w, v__5.w);
        float4 v__6 = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
        __5.x = min(__6.x, v__6.x);
        __5.y = min(__6.y, v__6.y);
        __5.z = min(__6.z, v__6.z);
        __5.w = min(__6.w, v__6.w);
      (reinterpret_cast<uint8_t*>(&__4))[0] = __tl_cvt_float2_to_fp4x2(((float2*)(&__5))[0]);
      (reinterpret_cast<uint8_t*>(&__4))[1] = __tl_cvt_float2_to_fp4x2(((float2*)(&__5))[1]);
      ((float2*)(&__3))[0] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&__4))[0]);
      ((float2*)(&__3))[1] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&__4))[1]);
      float4 v__7 = make_float4(s_local[0], s_local[0], s_local[0], s_local[0]);
      __2.x = (__3.x*v__7.x);
      __2.y = (__3.y*v__7.y);
      __2.z = (__3.z*v__7.z);
      __2.w = (__3.w*v__7.w);
    (reinterpret_cast<__nv_bfloat162*>(&__1))[0] = __float22bfloat162_rn(((float2*)(&__2))[0]);
    (reinterpret_cast<__nv_bfloat162*>(&__1))[1] = __float22bfloat162_rn(((float2*)(&__2))[1]);
    *(uint2*)(y_local + (i * 4)) = __1;
  }
  if ((((int)threadIdx.x) % 4) == 0) {
    if (((((int)blockIdx.x) * 32) + (((int)threadIdx.x) >> 2)) < M) {
      S[((((int64_t)((int)blockIdx.x)) * (int64_t)32) + (((int64_t)((int)threadIdx.x)) >> (int64_t)2))] = s_local[0];
    }
  }
  *(uint4*)(((bfloat16_t*)y_shared) + (((int)threadIdx.x) * 8)) = *(uint4*)(y_local + 0);
  if (((((int)blockIdx.x) * 32) + (((int)threadIdx.x) >> 2)) < M) {
    *(uint4*)(Y + ((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)8))) = *(uint4*)(((bfloat16_t*)y_shared) + (((int)threadIdx.x) * 8));
  }
}

