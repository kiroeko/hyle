#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/cuda_fp8.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void act_quant_kernel__kernel(float* __restrict__ S, const bfloat16_t* __restrict__ X, fp8_e4_t* __restrict__ Y, int M);
extern "C" __global__ void __launch_bounds__(128, 1) act_quant_kernel__kernel(float* __restrict__ S, const bfloat16_t* __restrict__ X, fp8_e4_t* __restrict__ Y, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* x_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* y_shared = ((void*)((char*)buf_dyn_shmem + 0));
  bfloat16_t x_local[32];
  float amax_local[2];
  float s_local[2];
  fp8_e4_t y_local[32];
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    bfloat16_t broadcast_var = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    uint4 condval;
    if (((((((int)blockIdx.x) * 32) + (i * 8)) + (((int)threadIdx.x) >> 4)) < M)) {
      condval = *(uint4*)(X + (((((int64_t)((int)blockIdx.x)) * (int64_t)4096) + (((int64_t)i) * (int64_t)1024)) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    } else {
      condval = make_uint4(__pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var));
    }
    *(uint4*)(((bfloat16_t*)x_shared) + ((i * 1024) + (((int)threadIdx.x) * 8))) = condval;
  }
  __syncthreads();
  #pragma unroll
  for (int i_1 = 0; i_1 < 4; ++i_1) {
    *(uint4*)(x_local + (i_1 * 8)) = *(uint4*)(((bfloat16_t*)x_shared) + ((((i_1 >> 1) * 2048) + (((int)threadIdx.x) * 16)) + ((i_1 & 1) * 8)));
  }
  #pragma unroll
  for (int i_2 = 0; i_2 < 2; ++i_2) {
    amax_local[i_2] = 0x0p+0f/*0.000000e+00*/;
    #pragma unroll
    for (int rv = 0; rv < 16; ++rv) {
      amax_local[i_2] = max(amax_local[i_2], max(((float)x_local[((i_2 * 16) + rv)]), (0x0p+0f/*0.000000e+00*/ - ((float)x_local[((i_2 * 16) + rv)]))));
    }
    amax_local[i_2] = tl::AllReduce<tl::MaxOp, 8, 1, 0, tl::NamedBarrier<128>>::run(amax_local[i_2]);
  }
  #pragma unroll
  for (int i_3 = 0; i_3 < 2; ++i_3) {
    amax_local[i_3] = max(amax_local[i_3], 0x1.a36e2eb1c432dp-14f/*1.000000e-04*/);
    float v_ = amax_local[i_3] * 0x1.2492492492492p-9f/*2.232143e-03*/;
    int condval_1;
    if ((((*(uint *)(&(v_))) & (uint)8388607) != (uint)0)) {
      condval_1 = 1;
    } else {
      condval_1 = 0;
    }
    int v__1 = (((int)(((((*(uint *)(&(v_))) >> (uint)23) & (uint)255) - (uint)127) + ((uint)condval_1))) + 127) << 23;
    s_local[i_3] = (*(float *)(&(v__1)));
  }
  #pragma unroll
  for (int i_4 = 0; i_4 < 8; ++i_4) {
    float broadcast_var_1 = -0x1.cp+8f/*-4.480000e+02*/;
    float broadcast_var_2 = 0x1.cp+8f/*4.480000e+02*/;
    fp8_e4_4_t __1;
    float4 __2;
      float4 __3;
        float4 __4;
          float4 __5;
          uint2 v__2 = *(uint2*)(x_local + (i_4 * 4));
          ((float2*)(&__5))[0] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__2))[0]);
          ((float2*)(&__5))[1] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__2))[1]);
          float4 v__3 = make_float4(s_local[(i_4 >> 2)], s_local[(i_4 >> 2)], s_local[(i_4 >> 2)], s_local[(i_4 >> 2)]);
          __4.x = (__5.x/v__3.x);
          __4.y = (__5.y/v__3.y);
          __4.z = (__5.z/v__3.z);
          __4.w = (__5.w/v__3.w);
        float4 v__4 = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
        __3.x = max(__4.x, v__4.x);
        __3.y = max(__4.y, v__4.y);
        __3.z = max(__4.z, v__4.z);
        __3.w = max(__4.w, v__4.w);
      float4 v__5 = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
      __2.x = min(__3.x, v__5.x);
      __2.y = min(__3.y, v__5.y);
      __2.z = min(__3.z, v__5.z);
      __2.w = min(__3.w, v__5.w);
    (reinterpret_cast<__nv_fp8x2_storage_t*>(&__1))[0] = __nv_cvt_float2_to_fp8x2(((float2*)(&__2))[0], __NV_SATFINITE, __NV_E4M3);
    (reinterpret_cast<__nv_fp8x2_storage_t*>(&__1))[1] = __nv_cvt_float2_to_fp8x2(((float2*)(&__2))[1], __NV_SATFINITE, __NV_E4M3);
    *(fp8_e4_4_t*)(y_local + (i_4 * 4)) = __1;
  }
  if ((((int)threadIdx.x) % 8) == 0) {
    #pragma unroll
    for (int i_5 = 0; i_5 < 2; ++i_5) {
      if ((((((int)blockIdx.x) * 32) + (i_5 * 16)) + (((int)threadIdx.x) >> 3)) < M) {
        S[(((((int64_t)((int)blockIdx.x)) * (int64_t)32) + (((int64_t)i_5) * (int64_t)16)) + (((int64_t)((int)threadIdx.x)) >> (int64_t)3))] = s_local[i_5];
      }
    }
  }
  __syncthreads();
  #pragma unroll
  for (int i_6 = 0; i_6 < 2; ++i_6) {
    *(fp8_e4_16_t*)(((fp8_e4_t*)y_shared) + ((i_6 * 2048) + (((int)threadIdx.x) * 16))) = *(fp8_e4_16_t*)(y_local + (i_6 * 16));
  }
  #pragma unroll
  for (int i_7 = 0; i_7 < 2; ++i_7) {
    if ((((((int)blockIdx.x) * 32) + (i_7 * 16)) + (((int)threadIdx.x) >> 3)) < M) {
      *(fp8_e4_16_t*)(Y + (((((int64_t)((int)blockIdx.x)) * (int64_t)4096) + (((int64_t)i_7) * (int64_t)2048)) + (((int64_t)((int)threadIdx.x)) * (int64_t)16))) = *(fp8_e4_16_t*)(((fp8_e4_t*)y_shared) + ((i_7 * 2048) + (((int)threadIdx.x) * 16)));
    }
  }
}

