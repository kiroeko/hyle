module {
  func.func @trig(%input: tensor<?xf32>) -> (tensor<?xf32>, tensor<?xf32>) {
    %zero = arith.constant 0 : index
    %count = tensor.dim %input, %zero : tensor<?xf32>
    %empty = tensor.empty(%count) : tensor<?xf32>
    %sine = linalg.generic {
      indexing_maps = [affine_map<(i) -> (i)>, affine_map<(i) -> (i)>],
      iterator_types = ["parallel"]
    } ins(%input : tensor<?xf32>) outs(%empty : tensor<?xf32>) {
    ^bb0(%x: f32, %unused: f32):
      %v = math.sin %x : f32
      linalg.yield %v : f32
    } -> tensor<?xf32>
    %cosine = linalg.generic {
      indexing_maps = [affine_map<(i) -> (i)>, affine_map<(i) -> (i)>],
      iterator_types = ["parallel"]
    } ins(%input : tensor<?xf32>) outs(%empty : tensor<?xf32>) {
    ^bb0(%x: f32, %unused: f32):
      %v = math.cos %x : f32
      linalg.yield %v : f32
    } -> tensor<?xf32>
    return %sine, %cosine : tensor<?xf32>, tensor<?xf32>
  }
}
