#include <mlx/mlx.h>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>
namespace mx=mlx::core;
float bfloat(float x) {auto b=std::bit_cast<uint32_t>(x);b+=0x7fff+((b>>16)&1);return std::bit_cast<float>(b&0xffff0000);}
float decode(unsigned code) {auto v=code&127;float x=v<8?std::ldexp(float(v),-9):std::ldexp(1.0f+float(v%8)/8,int(v/8)-7);return code&128?-x:x;}
unsigned nearest(float x) {unsigned best=0;double distance=INFINITY;for(unsigned i=0;i<127;++i){double d=std::abs(double(std::abs(x))-decode(i));if(d<distance||(d==distance&&(i&1)==0)){best=i;distance=d;}}return best|(std::signbit(x)?128:0);}
int main(){
  mx::set_default_device(mx::Device::gpu);
  auto program=mx::compile([](const std::vector<mx::array>& in){
    auto rounded=mx::astype(in[0],mx::bfloat16);
    auto x=mx::reshape(mx::astype(rounded,mx::float32),{1,32,128});
    auto s=mx::divide(mx::maximum(mx::max(mx::abs(x),-1,true),mx::array(1e-10f)),mx::array(448.0f));
    auto norm=mx::divide(x,s);
    auto q=mx::to_fp8(norm);
    return std::vector{mx::reshape(q,{4096}),mx::reshape(s,{32}),mx::reshape(norm,{4096})};
  });
  for(int seed:{3,17,31,45}){
    std::vector<float> x(4096),scales(32);std::vector<unsigned> expected(4096);
    double square=0;
    for(int i=0;i<4096;++i){x[i]=float(std::cos(double(i+31*seed)*.017)*.0625+double((i+seed)%7)*.002-.006);square+=double(x[i])*x[i];}
    double inv=1/std::sqrt(square/4096+double(1e-5f));
    for(int i=0;i<4096;++i)x[i]=float(double(x[i])*inv*double(.875f+float((i*13+5)%29)/128));
    auto result=program({mx::array(x.data(),{1,4096},mx::float32)});mx::eval(result);
    for(auto& v:x)v=bfloat(v);
    unsigned wrong=0,scale_wrong=0;
    for(int g=0;g<32;++g){float m=1e-10f;for(int j=0;j<128;++j)m=std::max(m,std::abs(x[g*128+j]));scales[g]=m/448.0f;
      if(scales[g]!=result[1].data<float>()[g])++scale_wrong;
      for(int j=0;j<128;++j){int i=g*128+j;expected[i]=nearest(x[i]/scales[g]);auto got=result[0].data<uint8_t>()[i];
        if(got!=expected[i]){if(wrong<10)std::cout<<std::setprecision(12)<<"seed="<<seed<<" col="<<i<<" x="<<x[i]<<" expected_scale="<<scales[g]<<" mlx_scale="<<result[1].data<float>()[g]<<" expected_normal="<<x[i]/scales[g]<<" mlx_normal="<<result[2].data<float>()[i]<<" expected_code="<<expected[i]<<" got="<<unsigned(got)<<'\n';++wrong;}
      }
    }
    std::cout<<"seed="<<seed<<" codes_wrong="<<wrong<<" scales_wrong="<<scale_wrong<<'\n';
    const int row=1388;float expected_result=0,combined_result=0;
    struct Term{int block;float dot;};std::vector<Term> terms;
    for(int term=0;term<2;++term){int col=(row*17+197+term*(4096/2+13))%4096;float coefficient[]={.5f,1.f,1.5f,2.f};terms.push_back({col/128,decode(expected[col])*coefficient[(row+197+term)%4]});}
    std::sort(terms.begin(),terms.end(),[](auto a,auto b){return a.block<b.block;});
    for(auto term:terms){float sw=float(17+(row/128*3+term.block+197)%11)/1024;expected_result=std::fma(float(term.dot*scales[term.block]),sw,expected_result);combined_result+=term.dot*(scales[term.block]*sw);}
    std::cout<<std::setprecision(12)<<"seed="<<seed<<" row1388_source="<<expected_result<<" combined="<<combined_result<<" bf_source="<<bfloat(expected_result)<<" bf_combined="<<bfloat(combined_result)<<'\n';
  }
}
