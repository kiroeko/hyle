from pathlib import Path
import subprocess

out = Path('.scratch/validation/d5-sglang-fp8-aot')
with (out / 'compile.log').open('wb') as log:
    result = subprocess.run(['wsl.exe', '-e', 'python3',
        '/mnt/c/public/project-hyle/hyle/.scratch/d5-triton-compile.py'], stdout=log,
        stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
print((out / 'compile.log').read_text(encoding='utf-8', errors='replace')[-3000:])
raise SystemExit(result.returncode)
