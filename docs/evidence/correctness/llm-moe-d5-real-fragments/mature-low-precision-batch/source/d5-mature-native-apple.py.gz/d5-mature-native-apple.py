from pathlib import Path
import ctypes,hashlib,json,subprocess,sys,tarfile,time
sys.stdout.reconfigure(encoding='utf-8');ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
root=Path(__file__).resolve().parents[1];out=root/'.scratch/validation/d5-mature-native-q1'
archive=out/'apple-input.tar.gz'
names=['oracle.h','apple.mm','ds4.metal','all_finite_bf16.bin','ordinary.bin','tiny_and_scale.bin']
with tarfile.open(archive,'w:gz') as tar:
 for name in names:tar.add(out/name,arcname=name)
host='kiro@172.22.10.198';remote='hyle-scratch/d5-mature-native-q1'
commands=[('sync',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,
                  'mkdir -p '+remote+' && tar -xzf - -C '+remote]),
          ('run',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,
             'cd '+remote+' && /usr/bin/clang++ -std=c++20 -O2 -ffp-contract=off -fobjc-arc -framework Foundation -framework Metal apple.mm -o apple && ./apple'])]
steps=[]
for name,cmd in commands:
 start=time.monotonic()
 r=subprocess.run(cmd,input=archive.read_bytes() if name=='sync' else None,capture_output=True,
                  creationflags=subprocess.CREATE_NO_WINDOW,timeout=240)
 (out/('apple-'+name+'.log')).write_bytes(r.stdout+r.stderr)
 steps.append({'name':name,'argv':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start})
 print(name,r.returncode,(r.stdout+r.stderr).decode('utf-8',errors='replace')[-7000:],flush=True)
 if r.returncode:break
(out/'apple-receipt.json').write_bytes((json.dumps({'steps':steps,'inputs':{name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in names}},indent=2)+'\n').encode())
raise SystemExit(r.returncode)
