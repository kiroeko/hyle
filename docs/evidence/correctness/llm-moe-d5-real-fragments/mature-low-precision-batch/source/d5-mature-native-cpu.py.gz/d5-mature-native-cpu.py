from pathlib import Path
import ctypes,hashlib,json,subprocess,sys,time
sys.stdout.reconfigure(encoding='utf-8')
ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
root=Path(__file__).resolve().parents[1];out=root/'.scratch/validation/d5-mature-native-q1'
batch=out/'build.cmd'
batch.write_text('@echo off\ncall "C:/Program Files/Microsoft Visual Studio/18/Enterprise/Common7/Tools/VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64 >nul\nif errorlevel 1 exit /b %errorlevel%\nset VSLANG=1033\ncl /nologo /std:c++20 /O2 /fp:strict /EHsc /MT /I"C:/Program Files/Python312/Lib/site-packages/torch/include" cpu.cc /Fe:cpu.exe\nexit /b %errorlevel%\n',encoding='utf-8')
steps=[]
for name,cmd in [('build',['cmd.exe','/d','/c',str(batch)]),('run',[str(out/'cpu.exe')])]:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,timeout=180)
 steps.append({'name':name,'argv':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start})
 print(name,r.returncode,(out/(name+'.log')).read_text(encoding='utf-8',errors='replace')[-6000:],flush=True)
 if r.returncode:break
(out/'cpu-receipt.json').write_bytes((json.dumps({'steps':steps,'numeric_verdict':'see run.log per-candidate counters','files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.suffix in ('.h','.cc','.inc','.exe','.bin')}},indent=2)+'\n').encode())
raise SystemExit(r.returncode)
