from pathlib import Path
import hashlib,json,subprocess,ctypes,sys
sys.stdout.reconfigure(encoding='utf-8')
ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
root=Path(__file__).resolve().parents[1]
out=root/'.scratch/validation/d5-mature-native-q1'
out.mkdir(parents=True,exist_ok=True)
peer=Path('C:/public/project-hyle/ds4');rev='9139e2ae58a41503968a500f36f75895c1ba63fc'
def blob(path):return subprocess.check_output(['git','-C',str(peer),'show',rev+':'+path],creationflags=subprocess.CREATE_NO_WINDOW)
sources=[]
def extract(path,start,end,name,prefix=''):
 data=blob(path);text=data.decode();a=text.index(start);b=text.index(end,a)
 fragment=text[a:b];(out/name).write_bytes((prefix+fragment).encode())
 sources.append({'path':path,'revision':rev,'sha256':hashlib.sha256(data).hexdigest(),
                 'extracted_sha256':hashlib.sha256(fragment.encode()).hexdigest(),
                 'from_line':text[:a].count('\n')+1,'to_line':text[:b].count('\n')})
extract('ds4.c','static float dsv4_e4m3fn_value_cpu','/* Quantize a float activation into Q8_K',
        'ds4_cpu.inc','#include <cstdint>\n#include <cmath>\n#include <stdexcept>\nstatic void ds4_die(const char* s){throw std::runtime_error(s);}\n')
extract('metal/dsv4_kv.metal','constant float dsv4_e4m3fn_exp_scale','// Decode-side KV finalizer',
        'ds4.metal','#include <metal_stdlib>\nusing namespace metal;\n')
torch=Path('C:/Program Files/Python312/Lib/site-packages/torch')
for p in ('include/c10/util/Float8_e4m3fn.h','include/c10/util/Float8_e4m3fn-inl.h','version.py'):
 data=(torch/p).read_bytes();sources.append({'path':'torch/'+p,'sha256':hashlib.sha256(data).hexdigest()})
(out/'sources.json').write_bytes((json.dumps(sources,indent=2)+'\n').encode())
print(out)
