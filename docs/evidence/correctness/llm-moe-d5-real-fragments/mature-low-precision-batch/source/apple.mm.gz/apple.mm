#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include "oracle.h"
struct Fp8Args{int64_t ne00,ne01,ne02,ne03;uint64_t nb00,nb01,nb02,nb03,nb0,nb1,nb2,nb3;int n_rot;};
struct Fp4Args{uint32_t n_rows,head_dim;uint64_t row_stride;};
int main(){@autoreleasepool{
 id<MTLDevice> device=MTLCreateSystemDefaultDevice();if(!device)throw std::runtime_error("no Metal device");
 std::printf("device=%s os=%s\n",device.name.UTF8String,NSProcessInfo.processInfo.operatingSystemVersionString.UTF8String);
 NSError* error=nil;NSString* source=[NSString stringWithContentsOfFile:@"ds4.metal" encoding:NSUTF8StringEncoding error:&error];if(!source)throw std::runtime_error(error.localizedDescription.UTF8String);
 id<MTLCommandQueue> queue=[device newCommandQueue];
 for(bool safe:{false,true}){
  MTLCompileOptions* options=[MTLCompileOptions new];
  if(safe){if(@available(macOS 15.0,*)){options.mathMode=MTLMathModeSafe;}else{throw std::runtime_error("safe mode needs macOS15");}}
  id<MTLLibrary> library=[device newLibraryWithSource:source options:options error:&error];if(!library)throw std::runtime_error(error.localizedDescription.UTF8String);
  for(bool fp4:{false,true}){
   NSString* function=fp4?@"kernel_dsv4_indexer_hadamard_fp4_f32":@"kernel_dsv4_fp8_kv_quantize_f32";
   id<MTLComputePipelineState> pipeline=[device newComputePipelineStateWithFunction:[library newFunctionWithName:function] error:&error];if(!pipeline)throw std::runtime_error(error.localizedDescription.UTF8String);
   for(const char* domain:{"all_finite_bf16","ordinary","tiny_and_scale"}){
    if(fp4&&std::string(domain)=="all_finite_bf16")continue; // Hadamard can overflow these finite inputs.
    auto input=oracle::read((std::string(domain)+".bin").c_str());const size_t bytes=input.size()*sizeof(float),rows=input.size()/128;
    id<MTLBuffer> src=[device newBufferWithBytes:input.data() length:bytes options:MTLResourceStorageModeShared];
    id<MTLBuffer> dst=fp4?src:[device newBufferWithLength:bytes options:MTLResourceStorageModeShared];
    id<MTLCommandBuffer> command=[queue commandBuffer];id<MTLComputeCommandEncoder> encoder=[command computeCommandEncoder];
    [encoder setComputePipelineState:pipeline];
    if(fp4){Fp4Args args{uint32_t(rows),128,128*4};[encoder setBytes:&args length:sizeof(args) atIndex:0];[encoder setBuffer:src offset:0 atIndex:1];}
    else{Fp8Args args{128,int64_t(rows),1,1,4,128*4,uint64_t(bytes),uint64_t(bytes),4,128*4,uint64_t(bytes),uint64_t(bytes),0};[encoder setBytes:&args length:sizeof(args) atIndex:0];[encoder setBuffer:src offset:0 atIndex:1];[encoder setBuffer:dst offset:0 atIndex:2];}
    [encoder setThreadgroupMemoryLength:sizeof(float)*(fp4?256:64) atIndex:0];
    [encoder dispatchThreadgroups:MTLSizeMake(rows,1,1) threadsPerThreadgroup:MTLSizeMake(fp4?128:64,1,1)];[encoder endEncoding];[command commit];[command waitUntilCompleted];
    if(command.status!=MTLCommandBufferStatusCompleted)throw std::runtime_error(command.error.localizedDescription.UTF8String);
    auto data=static_cast<const float*>(dst.contents);std::vector<float> output(data,data+input.size());
    const std::string name=std::string("ds4_metal_")+(safe?"safe_":"default_")+(fp4?"fp4":"fp8");
    auto expected=oracle::roundtrip(fp4?oracle::hadamard(input,false):input,fp4,fp4?32:64);oracle::compare(name.c_str(),domain,output,expected);
    if(fp4){auto model=oracle::roundtrip(oracle::hadamard(input,true),true,32);oracle::compare((name+"_model_bf16").c_str(),domain,output,model);}
   }
  }
 }
 return 0;
}}
