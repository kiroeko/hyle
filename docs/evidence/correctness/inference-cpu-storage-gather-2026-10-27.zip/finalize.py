"""Offline receipts only: preserve the completed native runs, allow GTest RecordProperty."""
from pathlib import Path
import importlib.util,json,xml.etree.ElementTree as ET,zipfile,hashlib
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('cpu_storage_receipt',W/'build.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,R=c.b,c.R;p=b.read(W/'plan.json');ready=b.read(W/'ready.json');groups=[]
for name,filter,count in p['groups']:
    xml=W/('results-'+name+'.xml');tree=ET.parse(xml).getroot();cases=tree.findall('./testsuite/testcase')
    process=b.read(W/('run-'+name)/'process.json');assert process['exit']==0
    assert int(tree.attrib['tests'])==count and int(tree.attrib['failures'])==0 and len(cases)==count
    assert all(x.attrib.get('status')=='run' and x.attrib.get('result')=='completed' and all(y.tag=='properties' for y in x) for x in cases)
    groups.append(dict(name=name,process=process,tests=[dict(**x.attrib,properties={v.attrib['name']:v.attrib['value'] for v in x.findall('./properties/property')}) for x in cases],results=b.pin(xml)))
b.save(W/'summary.json',dict(status='ELEVEN_CPU_STORAGE_TESTS_PASS',tests=11,failures=0,skipped=0,groups=groups,
    ready=b.pin(W/'ready.json'),CXX_TUs=5,CXX_attempts=6,link_attempts=1,images=1,native_processes=2,
    corrections=['Initial slots test had an ambiguous conditional expression between Status and ResultError; fixed only two test return expressions. Three successful product objects reused.',
    'Both native GTest processes passed. The first Python summary assertion incorrectly rejected the legacy test RecordProperty XML child. Corrected offline without rerunning any process.'],
    unrun=p['unrun']))
files=['build.py','build-attempt1.py','resume.py','finalize.py','plan.json','plan2.json','source-freeze.json','source2-freeze.json',
       'recipe-default_rules.json','recipe-indexing.json','partial-compile.json','partial-compile2.json','ready.json','link-inputs.json','runtime.json',
       'partial-results.json','summary.json','results-storage.xml','results-legacy.xml']
files += ['source/'+x for x in c.FROZEN]
files += ['source2/tests/graph/slots_execution_test.cc']
for stage in ['compile/default_rules','compile/indexing','compile/native_provider','compile/slots-test','compile2/slots-test','compile2/rules-test']:
    files += [stage+'/'+x for x in ['command.json','process.json','stdout.log','stderr.log','dependencies.json'] if (W/stage/x).is_file()]
    if (W/stage/'actual-canonical-dependencies.json').is_file():files += [stage+'/actual-canonical-dependencies.json']
for stage in ['link','run-storage','run-legacy']:
    files += [stage+'/'+x for x in ['command.json','process.json','stdout.log','stderr.log']]
assert len(files)==len(set(files)) and all((W/x).is_file() for x in files)
members=[dict(path=x,bytes=(W/x).stat().st_size,sha256=hashlib.sha256((W/x).read_bytes()).hexdigest()) for x in files]
archive=W/'records.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name in files:z.write(W/name,name)
with zipfile.ZipFile(archive) as z:
    assert z.namelist()==files
    for row in members:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
b.save(W/'receipt.json',dict(status='BOUNDED_CPU_STORAGE_GATHER_PASS',summary=b.pin(W/'summary.json'),records=b.pin(archive),members=members,
    current_source=[b.pin(R/x) for x in c.FROZEN],
    native_contract='Ordinary default factories choose original native selected-byte Gather for plain strided storage or F16/BF16. Rank-two axis-zero contiguous inner rows use exact native row-pitch memcpy after validating every current ID. Dense F32/I32 and encoded defaults unchanged; no model/hardware/Store gate.',
    baseline=dict(public_evidence='docs/evidence/correctness/inference-native-slot-store-2026-10-27.json',**p['baseline']),common_reuse=p['common_reuse'],
    limitations=['Existing hardware-qualified kWins remain; this run reports qualified_default_environment=0 and does not requalify them.',
    'Tests request native_threads=2 to exercise the natural rule outside the old one-thread gate; this is not a multithread performance claim.',p['unrun']],
    excluded='No EXE/OBJ/PDB/vendor source/SDK/header tree/models/full old closure copied into this archive.'))
print(json.dumps(dict(summary=b.pin(W/'summary.json'),receipt=b.pin(W/'receipt.json'),archive=b.pin(archive),members=len(members))),flush=True)
