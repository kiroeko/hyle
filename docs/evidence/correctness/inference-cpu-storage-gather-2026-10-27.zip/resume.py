"""Keep the three successful product objects; retry only the test syntax and the unstarted rules TU."""
from pathlib import Path
import importlib.util,json,os
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('cpu_storage_build',W/'build.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,m,R=c.b,c.m,c.R
sha='18b55e15e2226217fd2286ce82bbf1cd28898f7048220db6705de5246de43814'
assert b.pin(R/'tests/graph/slots_execution_test.cc')['sha256']==sha
p=b.read(W/'plan.json');results=b.read(W/'partial-compile.json');assert len(results)==3
for x in results:b.exact(x['object'])
assert not (W/'compile2').exists();units=[]
for u in p['units'][3:]:
    u=dict(u);u['source']=b.pin(u['source']['path']);u['command']=m.command(Path(u['recipe']['path']),Path(u['source']['path']),W/'compile2'/u['name'])
    u['command'][1:1]=['/I'+str(R/'include'),'/I'+str(R),'/I'+str(R/'src/compute_provider_native')];units.append(u)
snapshot=W/'source2/tests/graph/slots_execution_test.cc';snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes((R/'tests/graph/slots_execution_test.cc').read_bytes())
b.save(W/'source2-freeze.json',[b.pin(R/x) for x in c.FROZEN])
b.save(W/'plan2.json',dict(original=b.pin(W/'plan.json'),units=units,reused=results,source_freeze=b.pin(W/'source2-freeze.json'),
  correction='Two test return ternaries mixed Status and ResultError; explicit if returns keep semantics. No product source/object changed; original failed test source, command and output retained.'))
h,env=c.env_for(p)
for u in units:
    out=W/'compile2'/u['name'];process=h.execute(u['command'],env,out,timeout=180)
    deps=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']]) if Path(x).is_relative_to(R) and not Path(x).is_relative_to(R/'.scratch')]
    b.save(out/'actual-canonical-dependencies.json',actual)
    results.append(dict(name=u['name'],source=u['source'],object=b.pin(out/'unit.obj'),process=process,actual_dependencies=b.pin(out/'actual-canonical-dependencies.json')))
    b.save(W/'partial-compile2.json',results);print('COMPILED',u['name'],process,flush=True)
replacements={b.key(p['common_reuse']['before']['path']):p['common_reuse']['current']['object']}
for u,result in zip(p['units'],results):
    if u['before']:replacements[b.key(u['before']['path'])]=result['object']
args=[];changed=0;image=W/'bin/cpu-storage-gather-test.exe';image.parent.mkdir(exist_ok=True)
for arg in b.read(p['baseline']['command']['path'])['command']:
    if b.key(arg) in replacements:arg=replacements[b.key(arg)]['path'];changed+=1
    elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
    elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
    elif arg.upper().startswith('/MAP:'):continue
    args.append(arg)
assert changed==5,changed
extra=results[-1]['object'];args.append(extra['path']);linked=h.execute(args,env,W/'link',timeout=120)
b.save(W/'link-inputs.json',[replacements.get(b.key(x['path']),x) for x in b.read(p['baseline']['inputs']['path'])]+[extra])
rt=b.read(p['baseline']['runtime']['path']);native=rt['native_cpu'];b.exact(native)
alias=image.parent/Path(native['path']).name;os.link(native['path'],alias);rt['native_cpu_hardlink']=b.pin(alias);rt['PATH']=str(image.parent)+';'+rt['PATH'];b.save(W/'runtime.json',rt)
b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=linked,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan2.json'),original_plan=b.pin(W/'plan.json'),CXX_TUs=5,CXX_attempts=6,images=1))
print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
