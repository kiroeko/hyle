"""Five incremental CPU CXX TUs; one image, ten storage tests and one legacy rule group."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;R=W.parents[1]
P=R/'.scratch/inference-slot-source-fallback-20261027/build.py'
spec=importlib.util.spec_from_file_location('existing_cpu_recipe',P)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
B=R/'.scratch/inference-native-slot-store-20261027/windows-shared/attempt2'
H=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation'
FROZEN={
'src/compute_provider_native/default_rules.h':'d5c49742bbf49377917f77aa6226a09b89eac13cff015ed5bf0052f2a160d114',
'src/compute_provider_native/default_rules.cc':'83ec2aeaf97a762b7401fc420149c65b0f384ad004a56ec6f562471ccf82c001',
'src/compute_provider_native/native_provider.cc':'a464589ef1dd4c1a31926bc899f12ba7373e512946492ce10ca410dc63316749',
'src/compute_provider_native/indexing.cc':'e725a5415319856917b9bb1fa3441c9267c6dcddbc0b10cb252d88ab9742aa3c',
'tests/graph/slots_execution_test.cc':'0ca199b4b47bb04e36499bd346a7b51b4434ff89643100ca27fb445667377b2e',
'tests/compute_route_cpu/current_rules_test.cc':'dd23e899476ddb4872a7846a9e81edb8e1f0da80a676510326b3693be59e51e7'}
def freeze_check():
    for path,sha in FROZEN.items():assert b.pin(R/path)['sha256']==sha,path
def plan():
    assert not (W/'plan.json').exists();freeze_check()
    ready=b.read(B/'ready.json');inputs=b.read(ready['inputs']['path']);assert len(inputs)==226
    jobs=b.read(H/'host-commands.json')['jobs'];units=[]
    for name in ('default_rules','indexing'):
        job=next(x for x in jobs if x['name']=='compute_provider_native--'+name)
        recipe=W/('recipe-'+name+'.json');b.save(recipe,dict(command=job['command'],original=b.pin(H/'host-commands.json')))
        units.append(dict(name=name,source=b.pin(R/('src/compute_provider_native/'+name+'.cc')),
          recipe=b.pin(recipe),before=next(x for x in inputs if x['path']==str(H/'host1'/('compute_provider_native--'+name+'.obj')))))
    native=R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_native--native_provider_cc'
    units.append(dict(name='native_provider',source=b.pin(R/'src/compute_provider_native/native_provider.cc'),
      recipe=b.pin(native/'command.json'),before=next(x for x in inputs if x['path']==str(native/'unit.obj'))))
    previous=next(x for x in inputs if 'compile3\\cpu-test\\unit.obj' in x['path'])
    recipe=R/'.scratch/inference-slot-source-fallback-20261027/compile3/cpu-test/command.json'
    for name,source in [('slots-test','tests/graph/slots_execution_test.cc'),('rules-test','tests/compute_route_cpu/current_rules_test.cc')]:
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),before=previous if name=='slots-test' else None))
    for unit in units:
        unit['command']=m.command(Path(unit['recipe']['path']),Path(unit['source']['path']),W/'compile'/unit['name'])
        # Canonical public/privates precede historical verification shadows.
        unit['command'][1:1]=['/I'+str(R/'include'),'/I'+str(R),'/I'+str(R/'src/compute_provider_native')]
    vk=R/'.scratch/inference-native-slot-store-20261027/windows-vulkan'
    common=next(x for x in b.read(vk/'ready.json')['compiled'] if x['name']=='common')
    assert common['source']['sha256']==b.pin(R/'src/graph/slots_region.cc')['sha256']
    before=ready['compiled'][0]['object'];assert sum(x['path']==before['path'] for x in inputs)==1
    b.exact(common['object'])
    frozen=[]
    for path in FROZEN:
        pin=b.pin(R/path);target=W/'source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/path).read_bytes());frozen.append(pin)
    b.save(W/'source-freeze.json',frozen)
    b.save(W/'plan.json',dict(units=units,baseline=dict(ready=b.pin(B/'ready.json'),inputs=ready['inputs'],runtime=ready['runtime'],command=b.pin(B/'link/command.json')),
      common_reuse=dict(before=before,current=common,ready=b.pin(vk/'ready.json')),
      source_freeze=b.pin(W/'source-freeze.json'),CXX_TUs=5,images=1,
      boundary='Default rules add only a private function declaration. NativePlan/provider/Graph/public layouts unchanged. Reuse original native/SDK/third-party and exact current common StoreBinding object; original other object source snapshots are referenced, not claimed rebuilt from current source.',
      groups=[['storage','GraphSlotsExecution.*:CpuStorageGather.*',10],['legacy','CpuCurrentRules.ExactQualifiedRequestsAndNearbyMissesUseOrdinaryFactories',1]],
      unrun='No other CpuCurrentRules groups, model, CUDA/Vulkan execution, performance, SDK build or download.'))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def env_for(p):
    h=b.helper();cl=p['units'][0]['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def build():
    p=b.read(W/'plan.json');assert not (W/'compile').exists();freeze_check()
    h,env=env_for(p);results=[];replacements={b.key(p['common_reuse']['before']['path']):p['common_reuse']['current']['object']}
    for unit in p['units']:
        out=W/'compile'/unit['name'];process=h.execute(unit['command'],env,out,timeout=180)
        deps=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']]) if Path(x).is_relative_to(R) and not Path(x).is_relative_to(R/'.scratch')]
        b.save(out/'actual-canonical-dependencies.json',actual)
        obj=b.pin(out/'unit.obj');results.append(dict(name=unit['name'],source=unit['source'],object=obj,process=process,actual_dependencies=b.pin(out/'actual-canonical-dependencies.json')))
        if unit['before']:replacements[b.key(unit['before']['path'])]=obj
        b.save(W/'partial-compile.json',results);freeze_check();print('COMPILED',unit['name'],process,flush=True)
    args=[];changed=0;image=W/'bin/cpu-storage-gather-test.exe';image.parent.mkdir(exist_ok=True)
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in replacements:arg=replacements[b.key(arg)]['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert changed==5,changed
    extra=results[-1]['object'];args.append(extra['path'])
    linked=h.execute(args,env,W/'link',timeout=120)
    inputs=[replacements.get(b.key(x['path']),x) for x in b.read(p['baseline']['inputs']['path'])]+[extra];b.save(W/'link-inputs.json',inputs)
    rt=b.read(p['baseline']['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias);rt['native_cpu_hardlink']=b.pin(alias);rt['PATH']=str(image.parent)+';'+rt['PATH'];b.save(W/'runtime.json',rt)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=linked,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json')))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run():
    p=b.read(W/'plan.json');r=b.read(W/'ready.json');b.exact(r['image']);h,env=env_for(p);env['PATH']=b.read(r['runtime']['path'])['PATH'];groups=[]
    for name,filter,count in p['groups']:
        xml=W/('results-'+name+'.xml')
        process=h.execute([r['image']['path'],'--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(xml)],env,W/('run-'+name),timeout=90)
        tree=ET.parse(xml).getroot();cases=tree.findall('./testsuite/testcase')
        assert int(tree.attrib['tests'])==count and int(tree.attrib['failures'])==0 and len(cases)==count
        assert all(x.attrib.get('status')=='run' and not list(x) for x in cases)
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)));b.save(W/'partial-results.json',groups);print('PASSED',name,count,flush=True)
    b.save(W/'summary.json',dict(status='ELEVEN_CPU_STORAGE_TESTS_PASS',tests=11,failures=0,groups=groups,ready=b.pin(W/'ready.json'),CXX_TUs=5,images=1,unrun=p['unrun']))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
