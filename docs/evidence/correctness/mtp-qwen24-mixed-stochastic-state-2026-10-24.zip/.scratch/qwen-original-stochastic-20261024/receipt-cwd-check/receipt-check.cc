#include <algorithm>
#include <charconv>
#include <cstdint>
#include <filesystem>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include "hyle/mem/mapping.h"
namespace m=hyle::mem;
template<class T> T take(hyle::Result<T> result,std::string_view where) {
  if(!result)throw std::runtime_error(std::string(where)+": "+std::string(result.error().message()));
  return std::move(*result);
}
namespace bfloat {
inline bool pinned(std::string_view sha) {
  return sha.size()==64&&std::ranges::all_of(sha,[](char ch) {
    return (ch>='0'&&ch<='9')||(ch>='a'&&ch<='f');
  });
}
}
std::string bfloat_receipt_text(const std::filesystem::path &path) {
  auto mapped=take(m::FileMapping::open(path.string().c_str()),"map original original expert receipt");
  if(!mapped.size()||mapped.size()>1024*1024)throw std::runtime_error("original expert receipt exceeds finite metadata bound");
  const auto raw=take(mapped.bytes(),"original original expert receipt bytes");
  return {reinterpret_cast<const char*>(raw.data()),raw.size()};
}
std::string_view bfloat_receipt_field(std::string_view text,std::string_view key) {
  const auto quoted='"'+std::string(key)+'"';auto first=text.find(quoted);
  if(first==std::string_view::npos||text.find(quoted,first+quoted.size())!=std::string_view::npos||
      (first=text.find(':',first+quoted.size()))==std::string_view::npos||
      (first=text.find_first_not_of(" \r\n\t",first+1))==std::string_view::npos)
    throw std::runtime_error("original expert receipt lacks a unique required field: "+std::string(key));
  return text.substr(first);
}
std::string bfloat_receipt_string(std::string_view text,std::string_view key) {
  const auto field=bfloat_receipt_field(text,key);
  const auto end=field.find('"',1);
  if(field.front()!='"'||end==std::string_view::npos||field.substr(1,end-1).find('\\')!=std::string_view::npos)
    throw std::runtime_error("original expert receipt has an invalid fixed string field");
  return std::string(field.substr(1,end-1));
}
template<class Contract> std::optional<std::string> original_ready_pin(const std::filesystem::path &path,
    const Contract &contract,std::string_view section,std::int32_t global) {
  const auto text=bfloat_receipt_text(path/"ready.json");
  const auto complete=bfloat_receipt_field(text,"complete");
  if(complete.starts_with("false")&&complete.size()>=6&&std::string_view(" ,}\r\n\t").find(complete[5])!=std::string_view::npos)return std::nullopt;
  if(!complete.starts_with("true")||complete.size()<5||std::string_view(" ,}\r\n\t").find(complete[4])==std::string_view::npos)
    throw std::runtime_error("original expert ready receipt has an invalid completion field");
  // The receipt's directory records acquisition history, not source identity.
  // Read the actual selected path; the source plan, requested global ID and
  // immutable catalogue/plane hashes authenticate a relocated cache as well.
  if(bfloat_receipt_string(text,"section")!=section||
      bfloat_receipt_string(text,"source_plan_sha256")!=contract.source_plan_sha256)
    throw std::runtime_error("original expert ready receipt belongs to a different source/section");
  const auto globals=bfloat_receipt_field(text,"globals");const auto end=globals.find(']');
  if(globals.front()!='['||end==std::string_view::npos)throw std::runtime_error("original expert ready globals are absent");
  const auto first=globals.find_first_not_of(" \r\n\t",1),last=globals.find_last_not_of(" \r\n\t",end-1);
  if(first==std::string_view::npos||first>=end||last<first)throw std::runtime_error("original expert ready needs exactly one original global ID");
  const auto number=globals.substr(first,last-first+1);std::int32_t recorded=-1;
  const auto parsed=std::from_chars(number.data(),number.data()+number.size(),recorded);
  if(parsed.ec!=std::errc{}||parsed.ptr!=number.data()+number.size()||recorded!=global)
    throw std::runtime_error("original expert ready global ID differs from the actual requested source");
  const auto catalogue=bfloat_receipt_field(text,"catalog");const auto close=catalogue.find('}');
  if(catalogue.front()!='{'||close==std::string_view::npos)throw std::runtime_error("original expert ready catalogue is absent");
  const auto object=catalogue.substr(0,close+1);const auto pin=bfloat_receipt_string(object,"sha256");
  if(bfloat_receipt_string(object,"file")!="catalog.tsv"||!bfloat::pinned(pin))
    throw std::runtime_error("original expert ready requires its actual immutable catalogue pin");
  return pin;
}
struct Contract {std::string source_plan_sha256;};
int main(int argc,char **argv) {
  if(argc!=5)return 90;
  const std::filesystem::path path=argv[1];const Contract contract{argv[2]};
  const auto expected=std::string(argv[3]);const auto id=std::stoi(argv[4]);
  auto value=original_ready_pin(path,contract,"target91",id);
  if(!value||*value!=expected)throw std::runtime_error("actual original receipt catalogue SHA differs");
  unsigned rejected=0;
  const auto reject=[&](const Contract &c,std::string_view section,int global) {
    try{(void)original_ready_pin(path,c,section,global);}catch(const std::runtime_error &){++rejected;return;}
    throw std::runtime_error("wrong source/section/global accepted");
  };
  reject(Contract{std::string(64,'0')},"target91",id);
  reject(contract,"nextn92",id);reject(contract,"target91",id+1);
  bool legacy_same=false;
  try{legacy_same=std::filesystem::equivalent(std::filesystem::path(bfloat_receipt_string(bfloat_receipt_text(path/"ready.json"),"directory")),path);}catch(const std::filesystem::filesystem_error&){}
  std::cout<<"{\"catalog_sha256\":\""<<*value<<"\",\"negative_checks\":"<<rejected
    <<",\"historical_directory_resolves_here\":"<<(legacy_same?"true":"false")<<"}\n";
  return rejected==3?0:91;
}
