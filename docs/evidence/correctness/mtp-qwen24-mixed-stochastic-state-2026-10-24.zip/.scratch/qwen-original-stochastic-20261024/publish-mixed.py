from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
runs=[];records=[]
for folder in sorted(S.glob('mixed-run[0-9]*')):
 if not folder.is_dir() or not (folder/'process.json').exists():continue
 row=dict(folder=str(folder.relative_to(R)),process=read(folder/'process.json'))
 if (folder/'results.xml').exists():
  tree=ET.parse(folder/'results.xml').getroot();case=next(tree.iter('testcase'))
  row.update(result=tree.attrib,properties={p.attrib['name']:p.attrib['value'] for p in case.iter('property')},failure=[p.attrib for p in case.iter('failure')])
 row['actual_transitions']=[line for line in (folder/'stdout.log').read_text(errors='replace').splitlines() if 'QWEN RANDOM K1 ' in line or 'actual expert frontier' in line]
 runs.append(row);records.extend(p for p in folder.glob('*') if p.is_file() and p.suffix in ('.json','.log','.xml'))
 records.append(S/(folder.name+'-inputs.json'))
for sub in ('compile2','link2','cpu-syntax4'):
 records.extend(p for p in (S/sub).glob('*') if p.is_file() and p.suffix in ('.json','.log'))
records.extend(p for p in (S/'source2').rglob('*') if p.is_file())
for filename in ('source2-records.json','cpu-syntax4-source.json','ready2.json','mixed-frontier.json','mixed-expert-plan.json','mixed-expert-frontier-plan.json','build.py','publish-mixed.py'):
 if (S/filename).exists():records.append(S/filename)
for filename in ('mixed-nextn-expert-plan.json','mixed-nextn-307-expert-plan.json','check-receipt.py'):
 if (S/filename).exists():records.append(S/filename)
receipt=S/'receipt-cwd-check'
if receipt.exists():
 records.extend(p for p in receipt.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.cc','.patch'))
 ready=R/'.scratch/qwen-bfloat-selected-20261023/B05/original-experts/target91/ready.json'
 if ready.exists():records.append(ready)
for section,ids in [('target91',[77,124,193,228,272,357]),('nextn',[90,139,230,296,307])]:
 for selected in ids:
  folder=R/f'.scratch/qwen-bfloat-selected-20261023/B05/original-experts/{section}/expert{selected:03d}'
  if not (folder/'ready.json').exists() or not read(folder/'ready.json').get('complete'):continue
  records.extend(folder/name for name in ('ready.json','catalog.tsv','plan.json','acquisition.json') if (folder/name).exists())
out=R/'docs/evidence/correctness/mtp-qwen24-mixed-stochastic-state-2026-10-24';archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(records)):z.write(p,p.relative_to(R))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
passed=any(run['process']['exit']==0 and run.get('result',{}).get('failures')=='0' for run in runs)
summary=dict(date='2026-10-24',status='PASS finite mixed stochastic component' if passed else 'INCOMPLETE: actual original expert source frontier, no complete mixed stochastic publication result',
 result_not_inferred_from_single_domain=True,
 implementation=['Derive each full-output domain from existing resident split full_outputs{phase,port} and the actual native child output_on_host. No model-name/domain guessing or new provider routing.',
 'Prepare q input contract from actual draft logits; p/q decision contract from actual target logits and actual q/proposal outputs. Keys remain original GPU allocations; original Graph inserts transfers.',
 'Ordinary next-target head borrows the same authenticated CPU head and derives its input domain from the actual target tap. A separate static sampler is prepared only if its real input domain differs from q, never selected by hot provider lookup.',
 'The old greedy and new stochastic mixed cases share the same existing B05 setup/owners/suppliers. Same complete twelve-resource state plus optional shared Cursor metadata uses the existing expected-base Head.'],
 observed_domain_contracts=runs[-1].get('properties',{}),runs=runs,image=read(S/'ready2.json')['image'],
 last_explicit_missing_frontier_before_completion=read(S/'mixed-frontier.json'),
 required_source_frontier_satisfied=passed,
 initial_missing_source_plan=read(S/'mixed-expert-frontier-plan.json'),
 necessary_source_plans=[read(S/name) for name in ('mixed-expert-frontier-plan.json','mixed-nextn-expert-plan.json','mixed-nextn-307-expert-plan.json') if (S/name).exists()],
 receipt_portability=read(receipt/'result.json') if (receipt/'result.json').exists() else None,
 verification=dict(CUDA_consumer_compile=read(S/'compile2/process.json'),CPU_only_strict_syntax=read(S/'cpu-syntax4/process.json'),consumer_HTTP_requests=0,consumer_HTTP_bytes=0,new_SDK_or_provider_TUs=0,source_acquisition='External root-controlled exact range batches; the target91 six-ID batch is recorded by its actual ready receipt, not counted as zero downloaded source.'),
 limitations=['The first actual mixed attempt completed the cold domain contracts and real q sampling, then reached six unavailable original target91 experts while processing its sampled proposal. WAIT0 failed explicitly. This is not a successful acceptance/RNG/continuation result.',
 'The second attempt used all six newly supplied target91 experts, then reached four unavailable original NextN experts [90,139,230,296] during actual continuation. It failed explicitly, without a complete second Head result. The exact12-plane plan is402,653,184 bytes.',
 'The third attempt used the four newly supplied NextN experts and progressed through target episode3, then reported exactly one more unavailable NextN expert307. Its exact3-plane plan is100,663,296 bytes. Actual p/q acceptance and complete continuation are not inferred from expert episode counts.',
 'The fourth attempt used the exact one-ID NextN307 source addition and completed the actual mixed stochastic publication and pending continuation: sampled proposal331 rejected to residual23, then actual target/NextN consumption of23 produced279, with cursor4. Earlier WAIT0 frontiers remain historical failures; no full expert bank was fetched.' if passed else 'Full mixed stochastic publication must be rerun with precisely required cached source ranges. Future frontier IDs must come from real execution; no full-bank prefetch is allowed.',
 'The image2 source is frozen. The later receipt-only patch removes historical-directory path equivalence from source identity; actual FileMapping repo/build cwd checks plus three identity negatives per cwd passed, but that pure metadata patch is not part of image2.',
 'Previous-layer inputs/history are explicit fixtures. No complete-model quality, all-backend/identity coverage, throughput, measured VRAM or physical-total-memory claim.'],
 inherited_evidence=['docs/evidence/correctness/mtp-qwen24-original-stochastic-state-2026-10-24.json','docs/evidence/correctness/mtp-qwen24-bfloat-target-verifier-2026-10-23.json'],archive=identity(archive),archive_records=len(set(records)))
out.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(out.with_suffix('.json'));print(identity(archive))
