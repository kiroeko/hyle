from pathlib import Path
import importlib.util, json, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]
spec=importlib.util.spec_from_file_location('build',S/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
m=b.m
T=S/'receipt-cwd-check';T.mkdir(exist_ok=True)
source=R/'tests/compute_models/qwen_mtp_state_consumer_test.cc'
text=source.read_text(encoding='utf-8')
start=text.index('std::string bfloat_receipt_text(')
end=text.index('\ntemplate<class Source,class ExpertSet>',start)
fragment=text[start:end]
pinned_source=R/'tests/compute_models/qwen_bfloat_original_roles.h'
pinned=pinned_source.read_text(encoding='utf-8')
first=pinned.index('inline bool pinned(');last=pinned.index('\nclass Data',first)
cpp=r'''#include <algorithm>
#include <charconv>
#include <cstdint>
#include <filesystem>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include "hyle/mem/mapping.h"
namespace m=hyle::mem;
template<class T> T take(hyle::Result<T> result,std::string_view where) {
  if(!result)throw std::runtime_error(std::string(where)+": "+std::string(result.error().message()));
  return std::move(*result);
}
namespace bfloat {
'''+pinned[first:last]+'\n}\n'+fragment+r'''
struct Contract {std::string source_plan_sha256;};
int main(int argc,char **argv) {
  if(argc!=5)return 90;
  const std::filesystem::path path=argv[1];const Contract contract{argv[2]};
  const auto expected=std::string(argv[3]);const auto id=std::stoi(argv[4]);
  auto value=original_ready_pin(path,contract,"target91",id);
  if(!value||*value!=expected)throw std::runtime_error("actual original receipt catalogue SHA differs");
  unsigned rejected=0;
  const auto reject=[&](const Contract &c,std::string_view section,int global) {
    try{(void)original_ready_pin(path,c,section,global);}catch(const std::runtime_error &){++rejected;return;}
    throw std::runtime_error("wrong source/section/global accepted");
  };
  reject(Contract{std::string(64,'0')},"target91",id);
  reject(contract,"nextn92",id);reject(contract,"target91",id+1);
  bool legacy_same=false;
  try{legacy_same=std::filesystem::equivalent(std::filesystem::path(bfloat_receipt_string(bfloat_receipt_text(path/"ready.json"),"directory")),path);}catch(const std::filesystem::filesystem_error&){}
  std::cout<<"{\"catalog_sha256\":\""<<*value<<"\",\"negative_checks\":"<<rejected
    <<",\"historical_directory_resolves_here\":"<<(legacy_same?"true":"false")<<"}\n";
  return rejected==3?0:91;
}
'''
(T/'receipt-check.cc').write_text(cpp,encoding='utf-8')
m.save(T/'extraction.json',dict(product_source=m.ident(source),helper_source=m.ident(pinned_source),extracted=m.ident(T/'receipt-check.cc'),fragment=fragment,pinned=pinned[first:last]))
base=m.read(S/'compile2/command.json')['command'];compiler=base[0]
env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
command=[compiler,'/nologo','/c','/std:c++latest','/EHsc','/utf-8','/MD','/O2','/DNDEBUG','/DHYLE_STATIC','/W4','/WX','/permissive-','/I'+str(R/'include'),str(T/'receipt-check.cc'),'/Fo'+str(T/'check.obj')]
if not (T/'compile/process.json').exists():m.b.execute(command,env,T/'compile',timeout=60)
lib=R/'.scratch/build-compute-v2-dev/bin'
command=[str(Path(compiler).with_name('link.exe')),'/nologo','/OUT:'+str(T/'check.exe'),str(T/'check.obj')]+[str(lib/x) for x in ['hyle_mem_vm.lib','hyle_mem.lib','hyle_error.lib','hyle_platform.lib','hyle_platform_fs.lib','hyle_platform_thread.lib','mimalloc_static.lib']]+['kernel32.lib','user32.lib','psapi.lib','advapi32.lib','bcrypt.lib']
if not (T/'check.exe').exists():m.b.execute(command,env,T/('link2' if (T/'link').exists() else 'link'),timeout=60)
path=R/'.scratch/qwen-bfloat-selected-20261023/B05/original-experts/target91/expert077'
ready=m.read(path/'ready.json');command=[str(T/'check.exe'),str(path),ready['source_plan_sha256'],ready['catalog']['sha256'],'77']
records=[]
for name,cwd in [('repo',R),('build',T/'build')]:
 cwd.mkdir(exist_ok=True);folder=T/('run-'+name);folder.mkdir()
 import subprocess,time
 before=m.ident(path/'ready.json');started=time.time()
 process=subprocess.run(command,cwd=cwd,env=env,capture_output=True,text=True,timeout=15)
 (folder/'stdout.log').write_text(process.stdout,encoding='utf-8');(folder/'stderr.log').write_text(process.stderr,encoding='utf-8')
 record=dict(command=command,cwd=str(cwd),exit_code=process.returncode,elapsed_seconds=time.time()-started,actual_receipt=before,stdout=process.stdout,stderr=process.stderr)
 m.save(folder/'process.json',record);records.append(record)
 if process.returncode:raise RuntimeError(f'{name} receipt check failed')
m.save(T/'result.json',dict(status='PASS',actual_FileMapping=True,product_extraction=True,body_bytes=0,new_SDK_TUs=0,checks_per_cwd=4,records=records))
print('PASS actual receipt from repo/build cwd, three identity negative checks each',flush=True)
