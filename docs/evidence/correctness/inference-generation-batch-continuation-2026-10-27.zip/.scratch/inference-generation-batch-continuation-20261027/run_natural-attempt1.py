from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('batch_relay_natural_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
m, h = b.m, b.h
ignored = {'cache_shared_backing_bytes', 'cache_live_requested_bytes', 'cache_peak_requested_bytes',
           'cache_requested_byte_limit', 'cache_metadata_requested_bytes', 'cache_retained_output_backing_bytes'}
def facts(v):
    if isinstance(v, list): return [facts(x) for x in v]
    if isinstance(v, dict): return {k: facts(x) for k, x in v.items() if k not in ignored and
                                 not any(q in k for q in ['seconds', 'per_second', 'capture', 'replay', 'trace_name'])}
    return v
def main():
    name = sys.argv[1]
    fixture = R / ('.scratch/inference-paged-frame-20261026/tiny-recursive-input' if name == 'tiny' else
                   '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')
    case = W / (name + '-case'); case.mkdir(exist_ok=True)
    (case / 'prompt.ids').write_bytes(b'1 2 3\n' if name == 'tiny' else (fixture / 'prompt.ids').read_bytes())
    (case / 'turn.schedule').write_text('prompt prompt.ids\ngenerate 14\n', encoding='utf-8')
    (case / 'sessions.tsv').write_text('A turn.schedule\nB turn.schedule\n', encoding='utf-8')
    image = m.read(W / 'ready-cli1.json')['image']; b.exact(image)
    rows, oracle = [], None
    for mode in ['off', 'auto']:
        out = W / 'natural' / (name + '-' + mode)
        command = [image['path'], '--inputs', str(fixture), '--backend', 'cuda', '--mtp', 'off',
                   '--session-schedules', str(case / 'sessions.tsv'), '--capacity', '16' if name == 'tiny' else '256',
                   '--max-sessions', '2', '--active-sequences', '2', '--prefix-cache', 'off', '--sampling', 'greedy',
                   '--decode-overlap', mode]
        process = h.execute(command, b.environment(), out, timeout=240)
        report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig')); m.save(out / 'report.json', report)
        selected = [facts(x['result']) for x in report['sessions']]
        if oracle is None: oracle = selected
        assert selected == oracle, (name, mode, 'complete non-time session facts changed')
        assert report['generated_tokens'] == 28 and report['live_committed_versions'] == 0
        if mode == 'auto': assert report['overlap_successor_publications'] > 0 and report['overlap_successor_refusals'] == 0
        row = dict(mode=mode, process=process, report=m.pin(out / 'report.json'),
                   publications=report['overlap_successor_publications'], discards=report['overlap_successor_discards'],
                   actual_graph_calls=report['actual_graph_calls'], actual_target_rows=report['actual_target_rows'],
                   graph_participations=report['graph_participations'])
        rows.append(row); m.save(W / ('natural-' + name + '-partial.json'), rows)
        print('PASS ' + name + '-' + mode + ' ' + json.dumps(row), flush=True)
    m.save(W / ('natural-' + name + '-summary.json'), dict(status='PASS', image=image, runs=rows,
           complete_non_time_session_facts_equal=True, performance_claim=False,
           scope='Natural ordinary CUDA R2 request owner,14 outputs/member; six named cache fields and time/replay keys excluded as original R1 screen'))
if __name__ == '__main__': main()
