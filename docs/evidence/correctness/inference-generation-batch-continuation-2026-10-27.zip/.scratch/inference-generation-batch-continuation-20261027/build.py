from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-mtp-ahead-20261027'
spec = importlib.util.spec_from_file_location('batch_continuation_reuse', B / 'build.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
m, h, exact = previous.m, previous.h, previous.exact
m.W = W


def environment():
    env = dict(os.environ)
    env.update(m.read(B / 'environment.json'))
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    for key in ['HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE']:
        env[key] = '1'
    return env


def freeze_model():
    assert not (W / 'source-freeze-model1.json').exists()
    plan = m.read(W / 'build-plan.json')
    for field in ['CLI_ready', 'CLI_inputs']:
        exact(plan['baseline'][field])
    for row in m.read(plan['baseline']['CLI_inputs']['path']):
        exact(row)
    old = m.read(B / 'compile/model1/compiled.json')
    source = m.pin(R / 'engine/models/qwen35/main.cc')
    assert (source['bytes'], source['sha256']) == (
        544472, 'e0067b13c7d60ba5bcdb5ca236898bbf12b61b4d96b4411d8b8cd23b40177cb2')
    snapshot = W / 'source/model1/main.cc'
    snapshot.parent.mkdir(parents=True, exist_ok=False)
    snapshot.write_bytes(Path(source['path']).read_bytes())
    before = []
    for row in m.read(old['actual_dependencies']['path']):
        if m.key(row['path']) != m.key(old['source']['path']):
            exact(row)
            before.append(row)
    before.extend([source, m.pin(snapshot)])
    m.save(W / 'model1-precompile-dependencies.json', before)
    template = m.read(B / 'logs/model1/command.json')['command']
    out = W / 'compile/model1'
    command = []
    for index, arg in enumerate(template):
        if index and template[index - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        elif m.key(arg) == m.key(old['source']['path']):
            arg = str(snapshot)
        command.append(arg)
    command.insert(1, '/I' + str(R / 'engine/models/qwen35'))
    assert m.build_contract(command) == m.build_contract(template)
    weights_manifest = m.read(B / 'build-plan.json')['baseline']['weights_actual_dependencies']
    exact(weights_manifest)
    for row in m.read(weights_manifest['path']):
        exact(row)
    m.save(W / 'source-freeze-model1.json', dict(
        status='FROZEN_NOT_COMPILED', original_source=source, source=m.pin(snapshot),
        original_object=old['object'], baseline_inputs=plan['baseline']['CLI_inputs'],
        previous_actual_dependencies=old['actual_dependencies'],
        dependencies=m.pin(W / 'model1-precompile-dependencies.json'),
        recipe=m.pin(B / 'logs/model1/command.json'), command=command,
        boundary='Only frozen main snapshot compiled. Original qwen35 include directory resolves local headers. '
                 'Every previous actual Include and weights dependency is unchanged; no probe freeze.'))
    print('FROZEN ' + source['sha256'], flush=True)


def model():
    frozen = m.read(W / 'source-freeze-model1.json')
    for field in ['source', 'original_source', 'dependencies', 'recipe']:
        exact(frozen[field])
    before = {m.key(row['path']): row for row in m.read(frozen['dependencies']['path'])}
    out = W / 'compile/model1'
    out.mkdir(parents=True, exist_ok=False)
    process = h.execute(frozen['command'], environment(), W / 'logs/model1', timeout=240)
    data = m.read(out / 'dependencies.json')['Data']
    assert m.key(data['Source']) == m.key(frozen['source']['path'])
    dependencies = [m.pin(path) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    for row in dependencies:
        prior = before.get(m.key(row['path']))
        if prior:
            exact(prior)
        else:
            assert not Path(row['path']).resolve().is_relative_to(R), ('unfrozen local header', row['path'])
    exact(frozen['source'])
    exact(frozen['original_source'])
    m.save(out / 'actual-dependencies.json', dependencies)
    compiled = dict(original_source=frozen['original_source'], source=frozen['source'],
                    object=m.pin(out / 'unit.obj'), process=process,
                    command=m.pin(W / 'logs/model1/command.json'),
                    compiler_dependencies=m.pin(out / 'dependencies.json'),
                    actual_dependencies=m.pin(out / 'actual-dependencies.json'))
    m.save(out / 'compiled.json', compiled)
    print('MODEL_CXX_PASS ' + compiled['object']['sha256'], flush=True)


def link_cli():
    frozen = m.read(W / 'source-freeze-model1.json')
    compiled = m.read(W / 'compile/model1/compiled.json')
    for field in ['source', 'original_source', 'object', 'actual_dependencies']:
        exact(compiled[field])
    for row in m.read(compiled['actual_dependencies']['path']):
        exact(row)
    inputs = m.read(frozen['baseline_inputs']['path'])
    assert len(inputs) == 224 and sum(row == frozen['original_object'] for row in inputs) == 1
    inputs = [compiled['object'] if row == frozen['original_object'] else row for row in inputs]
    for row in inputs:
        exact(row)
    (W / 'bin').mkdir(exist_ok=True)
    runtime = m.read(B / 'runtime.json')
    exact(runtime['original_native_cpu'])
    alias = W / 'bin' / Path(runtime['original_native_cpu']['path']).name
    if not alias.exists():
        os.link(runtime['original_native_cpu']['path'], alias)
    env = environment()
    m.save(W / 'environment.json', {key: env.get(key, '') for key in ['PATH', 'INCLUDE', 'LIB', 'LIBPATH']})
    m.save(W / 'runtime.json', dict(original=m.pin(B / 'runtime.json'),
                                   original_native_cpu=runtime['original_native_cpu'],
                                   alias=m.pin(alias), PATH=env['PATH']))
    image = W / 'bin/hyle.exe'
    command = m.link_command(m.read(B / 'link-cli1/command.json')['command'],
                            {m.key(frozen['original_object']['path']): compiled['object']['path']}, [], image)
    m.save(W / 'cli-link-inputs.json', inputs)
    process = h.execute(command, env, W / 'link-cli1', timeout=180)
    for row in inputs:
        exact(row)
    ready = dict(status='CLI_LINKED_NOT_RUN_PROBE_NOT_FROZEN', compiled=compiled,
                 image=m.pin(image), link=process, inputs=m.pin(W / 'cli-link-inputs.json'),
                 runtime=m.pin(W / 'runtime.json'), freeze=m.pin(W / 'source-freeze-model1.json'),
                 counts=dict(CXX=1, links=1, model_processes=0, probe_processes=0, SDK=0, NVCC=0, downloads=0))
    m.save(W / 'ready-cli1.json', ready)
    print(json.dumps(ready, indent=2), flush=True)


PROBES = {
    'probe1': ('tests/tools/qwen_generation_batch_relay_probe.cc', 23820,
               '55b8c41a9c32c40f4a25fab157fdb8211b461a202b2e024c8a4ee9fbadf813dc',
               'qwen-generation-batch-relay-probe'),
    'r1-probe1': ('tests/tools/qwen_generation_relay_probe.cc', 20627,
                  '2d14ce183b1408f40faba4583f16a7e8d699aed28a2e1c144caf84bd820b5380',
                  'qwen-generation-relay-r1-probe')
}


def freeze_probe(name):
    assert name in PROBES and not (W / ('source-freeze-' + name + '.json')).exists()
    relative, size, digest, _ = PROBES[name]
    original = m.pin(R / relative)
    assert (original['bytes'], original['sha256']) == (size, digest)
    helper = m.pin(R / 'tests/tools/qwen_generation_state_case.h')
    assert (helper['bytes'], helper['sha256']) == (
        2796, '01e4ee3fb95022ab96add345d82b4c32b556281d226d195a146d0bb642d270d7')
    model = m.read(W / 'source-freeze-model1.json')
    exact(model['source'])
    exact(model['original_source'])
    root = W / 'source' / name
    sources = []
    for source, target in [
        (original, root / relative),
        (helper, root / 'tests/tools/qwen_generation_state_case.h'),
        (model['source'], root / 'engine/models/qwen35/main.cc')
    ]:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(Path(source['path']).read_bytes())
        sources.append(dict(original=source, snapshot=m.pin(target)))
    before = {}
    for path in [W / 'compile/model1/actual-dependencies.json',
                 B / 'compile/probe1/actual-dependencies.json']:
        for row in m.read(path):
            if Path(row['path']).suffix.lower() == '.h':
                exact(row)
                before[m.key(row['path'])] = row
    for row in sources:
        before[m.key(row['snapshot']['path'])] = row['snapshot']
    m.save(W / (name + '-precompile-dependencies.json'), list(before.values()))
    template = m.read(B / 'logs/probe1/command.json')['command']
    out = W / 'compile' / name
    command = []
    for index, arg in enumerate(template):
        if index and template[index - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        elif arg.lower().endswith('.cc'):
            arg = sources[0]['snapshot']['path']
        command.append(arg)
    command[1:1] = ['/I' + str(R / 'engine/models/qwen35'), '/I' + str(R / 'tests/tools')]
    assert m.build_contract(command) == m.build_contract(template)
    m.save(W / ('source-freeze-' + name + '.json'), dict(
        name=name, sources=sources, command=command,
        dependencies=m.pin(W / (name + '-precompile-dependencies.json')),
        scope='Frozen probe/helper/main relative tree; previous Model and probe actual Includes pre-pinned, including slots_region.h.'))
    print('FROZEN ' + name + ' ' + digest, flush=True)


def compile_probe(name):
    frozen = m.read(W / ('source-freeze-' + name + '.json'))
    for row in frozen['sources']:
        exact(row['original'])
        exact(row['snapshot'])
    out = W / 'compile' / name
    out.mkdir(parents=True, exist_ok=False)
    before = {m.key(row['path']): row for row in m.read(frozen['dependencies']['path'])}
    process = h.execute(frozen['command'], environment(), W / 'logs' / name, timeout=240)
    data = m.read(out / 'dependencies.json')['Data']
    assert m.key(data['Source']) == m.key(frozen['sources'][0]['snapshot']['path'])
    assert m.key(frozen['sources'][2]['snapshot']['path']) in {m.key(x) for x in data['Includes']}
    dependencies = [m.pin(path) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    for row in dependencies:
        prior = before.get(m.key(row['path']))
        if prior:
            exact(prior)
        else:
            assert not Path(row['path']).resolve().is_relative_to(R), ('unfrozen local probe header', row['path'])
    for row in frozen['sources']:
        exact(row['original'])
        exact(row['snapshot'])
    m.save(out / 'actual-dependencies.json', dependencies)
    compiled = dict(name=name, sources=frozen['sources'], object=m.pin(out / 'unit.obj'),
                    process=process, command=m.pin(W / 'logs' / name / 'command.json'),
                    compiler_dependencies=m.pin(out / 'dependencies.json'),
                    actual_dependencies=m.pin(out / 'actual-dependencies.json'))
    m.save(out / 'compiled.json', compiled)
    print('PROBE_CXX_PASS ' + name + ' ' + compiled['object']['sha256'], flush=True)


def link_probe(name):
    compiled = m.read(W / 'compile' / name / 'compiled.json')
    for row in compiled['sources']:
        exact(row['original'])
        exact(row['snapshot'])
    exact(compiled['object'])
    for row in m.read(compiled['actual_dependencies']['path']):
        exact(row)
    baseline = m.read(B / 'ready-probe1.json')
    original = baseline['compiled']['object']
    rows = m.read(baseline['inputs']['path'])
    assert len(rows) == 223 and sum(row == original for row in rows) == 1
    rows = [compiled['object'] if row == original else row for row in rows]
    for row in rows:
        exact(row)
    image = W / 'bin' / (PROBES[name][3] + '.exe')
    command = m.link_command(m.read(B / 'link-probe1/command.json')['command'],
                            {m.key(original['path']): compiled['object']['path']}, [], image)
    manifest = W / (name + '-link-inputs.json')
    m.save(manifest, rows)
    process = h.execute(command, environment(), W / ('link-' + name), timeout=180)
    for row in rows:
        exact(row)
    ready = dict(status='LINKED_NOT_RUN', compiled=compiled, image=m.pin(image), link=process,
                 inputs=m.pin(manifest), runtime=m.pin(W / 'runtime.json'),
                 freeze=m.pin(W / ('source-freeze-' + name + '.json')))
    m.save(W / ('ready-' + name + '.json'), ready)
    print('READY ' + name + ' ' + str(image) + ' ' + ready['image']['sha256'], flush=True)


def run_probe(name, fixture_name):
    assert fixture_name in ['tiny', 'real']
    ready = m.read(W / ('ready-' + name + '.json'))
    exact(ready['image'])
    exact(ready['inputs'])
    for row in m.read(ready['inputs']['path']):
        exact(row)
    fixture = R / ('.scratch/inference-paged-frame-20261026/tiny-recursive-input'
                   if fixture_name == 'tiny' else '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')
    out = W / 'probe-runs' / (name + '-' + fixture_name)
    assert not out.exists(), 'No automatic rerun of an attempted process'
    command = [ready['image']['path'], '--cuda', str(fixture)]
    process = h.execute(command, environment(), out, timeout=240)
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    m.save(out / 'report.json', report)
    assert report['status'] == 'PASS' and report['backend'] == 'cuda'
    if name == 'probe1':
        assert report['requests'] == 2 and report['serial_and_relay_arms'] == 6
        assert report['complete_initialized_state_equal'] and report['ledger_and_rng_equal']
        assert report['actual_batch_keys_checked'] and report['real_member_credit1_blocks_b']
        assert report['accepted_b_whole_discard'] and report['survivor_r1_continues']
        assert report['final_versions'] == 0 and len(report['relay']) == 3
    else:
        assert report['request_loop'] and report['credit1'] and report['credit2'] and report['pause_resume']
        assert report['after_submit_cancel'] and report['complete_state_equal'] and report['final_live_versions'] == 0
    assert not report['model_eos_run'] and not report['performance_claim']
    result = dict(status='PASS', name=name, fixture=fixture_name, process=process,
                  image=ready['image'], report=m.pin(out / 'report.json'),
                  ready=m.pin(W / ('ready-' + name + '.json')))
    m.save(out / 'summary.json', result)
    summaries = [m.read(path) for path in sorted((W / 'probe-runs').glob('*/summary.json'))]
    m.save(W / 'probe-run-summary.json', dict(
        status='PASS' if len(summaries) == 4 else 'PARTIAL_PASS', successful_processes=len(summaries),
        results=summaries, boundary='Finite CUDA R2 and original R1 RequestLoop consumers; no performance/EOS/native-fault claim'))
    print('PROBE_PASS ' + name + '-' + fixture_name + ' process=' + str(process['pid']), flush=True)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action in ['freeze-probe', 'compile-probe', 'link-probe']:
            {'freeze-probe': freeze_probe, 'compile-probe': compile_probe, 'link-probe': link_probe}[action](sys.argv[2])
        elif action == 'run-probe':
            run_probe(sys.argv[2], sys.argv[3])
        else:
            {'freeze-model': freeze_model, 'model': model, 'link-cli': link_cli}[action]()
    except BaseException:
        (W / ('failure-' + sys.argv[1] + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
