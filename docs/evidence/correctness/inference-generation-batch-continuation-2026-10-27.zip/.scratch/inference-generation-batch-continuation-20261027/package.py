from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-generation-batch-continuation-2026-10-27.json'
ZIP = OUT.with_suffix('.zip')
cache = {}

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    path = Path(path).resolve(); key = str(path).casefold()
    if key not in cache:
        data = path.read_bytes()
        cache[key] = dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return dict(cache[key])

def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), (row, actual)
    return actual

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

def compact(value, depth=0):
    if depth >= 2 or not isinstance(value, (dict,list)):
        return json.dumps(value, ensure_ascii=False, separators=(',',':'))
    if isinstance(value,dict):
        if not value:return '{}'
        return '{\n'+',\n'.join('  '*(depth+1)+json.dumps(k,ensure_ascii=False)+': '+compact(v,depth+1)
            for k,v in value.items())+'\n'+'  '*depth+'}'
    if not value:return '[]'
    return '[\n'+',\n'.join('  '*(depth+1)+compact(v,depth+1) for v in value)+'\n'+'  '*depth+']'

AHEAD = {'cpu_ahead_prepared','cpu_ahead_hits','cpu_ahead_discarded'}
CACHE = {'cache_shared_backing_bytes','cache_live_requested_bytes','cache_peak_requested_bytes',
    'cache_requested_byte_limit','cache_metadata_requested_bytes','cache_retained_output_backing_bytes'}
def facts(value, ignored):
    if isinstance(value,list):return [facts(x,ignored) for x in value]
    if isinstance(value,dict):return {k:facts(v,ignored) for k,v in value.items() if k not in ignored and
        not any(x in k for x in ['seconds','per_second','capture','replay','trace_name'])}
    return value

def changes(a,b,prefix=''):
    if isinstance(a,dict) and isinstance(b,dict):
        result=[]
        for k in sorted(set(a)|set(b)):result.extend(changes(a.get(k),b.get(k),prefix+'.'+k))
        return result
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return [x for n,(left,right) in enumerate(zip(a,b)) for x in changes(left,right,prefix+f'[{n}]')]
    return [] if a==b else [dict(path=prefix,off=a,auto=b)]

probe_summary=read(W/'probe-run-summary.json')
assert probe_summary['status']=='PASS' and probe_summary['successful_processes']==4
assert {(x['name'],x['fixture']) for x in probe_summary['results']}=={
    ('probe1','tiny'),('probe1','real'),('r1-probe1','tiny'),('r1-probe1','real')}
ready_paths=[W/'ready-cli1.json',*[Path(x['ready']['path']) for x in probe_summary['results']]]
ready_paths=list(dict.fromkeys(ready_paths))
ready_records=[]
for path in ready_paths:
    data=read(path); exact(data['image']); exact(data['inputs']); exact(data['runtime']); exact(data['freeze'])
    assert data['link']['exit']==0
    compiled=data['compiled']; assert compiled['process']['exit']==0
    for name in ['object','command','compiler_dependencies','actual_dependencies']:exact(compiled[name])
    if 'sources' in compiled:
        for row in compiled['sources']:exact(row['original']);exact(row['snapshot'])
    else:exact(compiled['original_source']);exact(compiled['source'])
    deps=read(compiled['actual_dependencies']['path'])
    for row in deps:exact(row)
    inputs=read(data['inputs']['path'])
    assert len(inputs)==(224 if path.name=='ready-cli1.json' else 223)
    for row in inputs:exact(row)
    command=read(W/('link-cli1' if path.name=='ready-cli1.json' else 'link-'+compiled['name'])/'command.json')['command']
    output_args=[x for x in command if x.upper().startswith(('/OUT:','/PDB:','/IMPLIB:'))]
    for arg in output_args:assert Path(arg.split(':',1)[1]).resolve().is_relative_to(W)
    ready_records.append(dict(ready=pin(path),image=data['image'],compiled=compiled,link=data['link'],
        inputs=data['inputs'],input_count=len(inputs),dependency_count=len(deps),
        all_actual_dependency_bytes_match=True,all_link_outputs_within_current_scratch=True))
assert len(ready_records)==3

# Read only the eight completed CLI processes. No imported runner is executed.
natural=[]; initial_mismatch=[]
for fixture in ['tiny','real']:
    summary=read(W/('natural-'+fixture+'-summary.json'))
    assert summary['status']=='PASS'; exact(summary['image'])
    reports=[]
    for row in summary['runs']:
        assert row['process']['exit']==0;exact(row['report'])
        path=Path(row['report']['path']);report=read(path)
        assert read(path.parent/'stdout.log')==report and read(path.parent/'process.json')==row['process']
        assert report['generated_tokens']==28 and report['live_committed_versions']==0
        assert report['actual_graph_calls']==14 and report['graph_participations']==28
        assert report['actual_target_rows']==(32 if fixture=='tiny' else 334)
        if row['mode']=='auto':
            assert report['overlap_successor_submissions']==report['overlap_successor_publications']==3
            assert report['overlap_successor_discards']==report['overlap_successor_refusals']==0
        reports.append(report)
    selected=[[x['result'] for x in report['sessions']] for report in reports]
    initial_diff=changes(facts(selected[0],CACHE),facts(selected[1],CACHE))
    assert initial_diff and all(x['path'].rsplit('.',1)[-1] in AHEAD for x in initial_diff)
    assert facts(selected[0],CACHE|AHEAD)==facts(selected[1],CACHE|AHEAD)
    initial_mismatch.append(dict(fixture=fixture,differences=initial_diff,
        initial_predicate=pin(W/'run_natural-attempt1.py'),corrected_predicate=pin(W/'run_natural.py'),
        explanation='Initial tiny comparison included CPU-ahead diagnostic counters; both native processes already exited0. Corrected parser reused those completed command/process/stdout records without rerunning. Real pair used corrected parser.'))
    natural.append(dict(fixture=fixture,summary=pin(W/('natural-'+fixture+'-summary.json')),
        image=summary['image'],runs=summary['runs'],complete_original_session_facts_equal_after_named_exclusions=True))
regression=read(W/'cli-summary.json'); assert regression['status']=='PASS' and len(regression['results'])==4
for row in regression['results']:
    assert row['process']['exit']==0
    exact(row['report']);exact(row['original']);report=read(row['report']['path'])
    assert read(Path(row['report']['path']).parent/'stdout.log')==report
    assert facts(report,AHEAD)==facts(read(row['original']['path']),AHEAD)
    assert report['generated_tokens']==16 and report['live_committed_versions']==0

probes=[]
for row in probe_summary['results']:
    assert row['status']=='PASS' and row['process']['exit']==0
    for name in ['image','report','ready']:exact(row[name])
    report=read(row['report']['path']);directory=Path(row['report']['path']).parent
    assert read(directory/'stdout.log')==report and read(directory/'process.json')==row['process']
    assert report['status']=='PASS' and report['backend']=='cuda' and not report['performance_claim'] and not report['model_eos_run']
    if row['name']=='probe1':
        assert report['serial_and_relay_arms']==6 and report['requests']==2 and report['state_slots']==6
        assert report['complete_initialized_state_equal'] and report['ledger_and_rng_equal'] and report['actual_batch_keys_checked']
        assert report['real_member_credit1_blocks_b'] and report['accepted_b_whole_discard'] and report['survivor_r1_continues']
        assert report['final_versions']==0 and len(report['relay'])==3
        counts=[]
        for arm in report['relay']:
            assert arm['actual_batches']==len(arm['batch_facts'])
            published=sum(sum(m['disposition']==1 for m in batch['members']) for batch in arm['batch_facts'])
            assert published==arm['published_members']
            assert arm['successor_publications']+arm['successor_discards']==arm['successor_submissions']
            assert arm['successor_refusals']==0
            counts.append({k:v for k,v in arm.items() if k!='batch_facts'})
        assert counts[0]['successor_submissions']==counts[0]['successor_publications']==2
        assert counts[1]['successor_submissions']==0
        assert counts[2]['successor_submissions']==counts[2]['successor_discards']==1 and counts[2]['successor_publications']==0
        assert counts[2]['survivor_r1']==5 and counts[2]['published_members']==22
        selected={k:v for k,v in report.items() if k!='relay'};selected['relay_counts']=counts
    else:
        assert report['serial_and_relay_arms']==(8 if row['fixture']=='tiny' else 10)
        assert report['complete_state_equal'] and report['final_live_versions']==0
        assert report['after_submit_cancel'] and report['credit1'] and report['credit2'] and report['pause_resume']
        if row['fixture']=='real':assert report['late_extra_stop_run'] and report['continuations'][-1]['successor_discards']==1
        else:assert not report['late_extra_stop_run'] and report['late_extra_stop_missing_unique_token']
        selected=report
    probes.append(dict(name=row['name'],fixture=row['fixture'],process=row['process'],image=row['image'],report=row['report'],facts=selected))

sources=[pin(R/name) for name in ['engine/models/qwen35/main.cc','tests/tools/qwen_generation_batch_relay_probe.cc',
    'tests/tools/qwen_generation_relay_probe.cc','tests/tools/qwen_generation_state_case.h']]
assert sources[0]['sha256']=='e0067b13c7d60ba5bcdb5ca236898bbf12b61b4d96b4411d8b8cd23b40177cb2'
assert sources[1]['sha256']=='55b8c41a9c32c40f4a25fab157fdb8211b461a202b2e024c8a4ee9fbadf813dc'
audit=dict(status='PASS',mode='Offline validation/archive only; no build or model process',
    actual_model_processes=12,counts=dict(natural_R2=4,CLI_regressions=4,probes=4,CXX=3,links=3),
    compiled=ready_records,actual_sources=sources,initial_comparison_observation=initial_mismatch,
    natural=natural,regression=regression,probes=probes,
    exclusions=['uncompiled continuation-helper.cc','full-window performance plans/runs','SDK','model payload','all native/build binaries'],
    build_status_note='ready*.json status/counts describe their historical build stage; subsequent original process/report records establish actual execution. No old receipt is rewritten.')
save(W/'package-verification.json',audit)

# Explicitly bounded collection: sibling full32 data is a separate experiment.
allowed={'.json','.log','.xml','.py','.ps1','.cc','.h','.txt','.ids','.tsv','.schedule','.patch','.diff'}
members={}
for path in sorted(W.rglob('*')):
    if not path.is_file() or path.suffix.lower() not in allowed:continue
    rel=path.relative_to(W)
    if rel.parts[0] in ['bin','full-window','__pycache__']:continue
    if rel.parts[0].startswith(('full-window','prepare-full-window')):continue
    if path.name in ['continuation-helper.cc','running.json','package-result.json']:continue
    if path.name.endswith('-partial.json'):continue
    members[path.relative_to(R).as_posix()]=path.read_bytes()
for row in regression['results']:
    path=Path(row['original']['path']);members[path.relative_to(R).as_posix()]=path.read_bytes()
manifest=dict(format='sha256+bytes for every member except this manifest',
    members=[dict(path=k,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(members.items())],
    exclusions=audit['exclusions'],scope='12 original correctness processes only; no full32 timing or memory process')
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
ZIP.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    assert not any(x.endswith(('continuation-helper.cc','.exe','.obj','.dll','.pdb','.lib','.exp')) for x in z.namelist())
    for row in manifest['members']:
        data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
archive=pin(ZIP);archive.update(member_count=len(members),uncompressed_bytes=sum(map(len,members.values())),all_members_read_back_and_verified=True)
receipt=dict(schema='hyle.inference-generation-batch-continuation.v1',date='2026-10-27',status='PASS',
    base_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    scope='Original ordinary CUDA R2 same-order continuation and bounded RequestLoop policies; complete Model/SubmissionSource/ledger reuse, no second executor.',
    changes=['Cold-bounded ordered RequestKey/turn cohort; exact complete Source boundary matching; R1 adapter retained.',
        'Same-width/same-order A/B preparation and publication; each original child emits one GenerationBatchFacts for its actual members.',
        'Every member needs real credit/quota/capacity for B. Partial A publication retires all accepted B, preserves successful A, clears only unpublished records and leaves survivors runnable.',
        'Original R1 state oracle extracted unchanged into a shared header; its entry and journeys retained.'],
    actual_sources=sources,
    build=dict(CXX=3,links=3,SDK=0,NVCC=0,downloads=0,
        images=[dict(ready=x['ready'],image=x['image'],compiler=x['compiled']['process'],link=x['link'],input_count=x['input_count'],dependencies=x['compiled']['actual_dependencies']) for x in ready_records],
        note='CLI224 inputs; each combined probe223 inputs with main included and no duplicate Model object. Actual commands/deps/source snapshots are archived. All OUT/PDB/IMPLIB are local to this scratch.'),
    validation=dict(actual_model_processes=12,natural_R2_processes=4,regression_processes=4,probe_processes=4,
        natural_R2=natural,regressions=regression['results'],probes=probes),
    initial_comparison=dict(classification='Observer/oracle diagnostic mismatch, not a product/native execution failure',
        original='Initial tiny off/auto processes both exited0; old predicate incorrectly included CPU-ahead diagnostic counters. Prepared/hits differed12 versus0 per session.',
        correction='Only the three named CPU-ahead counters were additionally excluded; completed reports/commands/processes reused, no additional native run. Old script and exact derived differing paths retained.',
        natural_exclusions=dict(cache=sorted(CACHE),diagnostics=sorted(AHEAD),recursive_key_substrings=['seconds','per_second','capture','replay','trace_name']),
        regression_exclusions='Entire CLI report comparison excludes only the same three ahead counters plus original time/replay-key substrings; no six cache fields dropped.'),
    probe_oracles=['R2 uses actual prompt length P3/P154; second Session swaps two different existing prompt IDs at the same width to produce distinct payloads.',
        'Normal serial/auto: fourteen outputs/member, exact initialized KV/GDN/conv state and epoch at matching same-width committed prefixes; complete non-time ledger/RNG and original keys checked.',
        'Credit: six actual imported warm preparations first, then retain just one real A ACK to supply credits1/2; original helper gets actual credits and must not submit B.',
        'Cancel: normal-auto first accepted-B prefix defines the serial control point. Original AfterSubmit cancellation occurs after A in serial and after accepted B in auto; survivor has the same R2 partial-A then R1 geometry.',
        'Logical ledger quota differs legitimately for same-quantum B versus a later serial wave; compare normalizes only quota after every actual facts callback proves record.quota/call.quota against original remaining-output/delivery credit.',
        'Each callback copies actual key/scalars, verifies authoritative record requests/member_index/rows and one observation per commit; native-submit counts equal actual batches. No borrowed member span retained.',
        'Full payload reads occur only after original wave retirement. Weak Source lifetimes expire; final Model versions/carriers/owner keys are empty.'],
    observed_counts=dict(natural_each=dict(outputs=28,physical_graphs=14,participations=28,auto_B_submitted_published=3,refusals=0,discards=0),
        natural_target_rows=dict(tiny=32,real=334),
        each_R2_probe_auto=dict(normal_B_submitted_published=2,credit_B=0,cancel_B_submitted=1,cancel_B_published=0,cancel_B_discarded=1,survivor_R1_batches=5),
        original_R1=dict(tiny_arms=8,real_arms=10,late_extra_stop_only_real=True)),
    limitations=['No throughput/speedup claim; root full32 timing/memory window is separate and deliberately excluded from this archive.',
        'Ordinary greedy shared-Queue CUDA only; R1/R2 finite consumers are not arbitrary dynamic cohorts, MTP device continuation, stochastic relay or a server proof.',
        'No actual natural model EOS, unknown capture-tuple refusal, native fault/unknown-retirement injection, Apple/Vulkan execution or multi-Queue qualification in this batch.',
        'R1 tiny has no unique late-stop token, so that specific arm is explicitly unrun; real R1 does cover accepted-B late extra-stop discard.',
        'No synthetic pending host gate in these full Model consumers; successful functional relay is not a measured GPU/CPU overlap percentage.'],
    archive=archive,archive_relative_link=ZIP.name)
text=compact(receipt)+'\n';assert len(text.splitlines())<=200
OUT.write_text(text,encoding='utf-8')
result=dict(status='PASS',outputs=[pin(OUT),pin(ZIP)],members=len(members),uncompressed_bytes=sum(map(len,members.values())),
    public_JSON_lines=len(text.splitlines()),actual_model_processes=12)
save(W/'package-result.json',result)
print(json.dumps(result,indent=2))
