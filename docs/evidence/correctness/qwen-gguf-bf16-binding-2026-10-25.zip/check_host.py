"""Run the two existing host input suites using the frozen current candidate."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
spec = importlib.util.spec_from_file_location('roles_recipe', ROOT / '.scratch/inference-assembly-placement-20261025/check_roles.py')
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
assert recipe.ROOT == ROOT
recipe.WORK = WORK

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('action', choices=('metadata', 'python'))
args = parser.parse_args()
pins = json.loads((WORK / 'product-pins.json').read_text())['files']
for item in pins:
    assert recipe.identity(ROOT / item['path'])['sha256'] == item['after']['sha256']
if args.action == 'metadata':
    names = {'engine/models/qwen35/prepared_gguf_roles.h', 'tests/tools/qwen_prepared_roles_test.cc'}
    recipe.save(WORK / 'source-pins.json', {'files': [
        {'path': item['path'], 'after_sha256': item['after']['sha256']}
        for item in pins if item['path'] in names]})
    sys.argv = [__file__, 'metadata1']
    recipe.main()
else:
    attempt = WORK / 'python1'
    assert not attempt.exists()
    tree = attempt / 'source'
    records = []
    for rel in ('tests/tooling/qwen_gguf_roles_test.py', 'engine/models/qwen35/gguf_roles.py',
                'engine/models/qwen35/gguf_header.py', 'engine/models/qwen35/geometry.py'):
        target = tree / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT / rel).read_bytes())
        records.append({'relative': rel, 'original': recipe.identity(ROOT / rel), 'frozen': recipe.identity(target)})
    recipe.save(attempt / 'frozen-source.json', records)
    temporary = attempt / 'temporary'
    temporary.mkdir()
    env = dict(os.environ, TMP=str(temporary), TEMP=str(temporary),
        PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    command = [sys.executable, '-B', str(tree / 'tests/tooling/qwen_gguf_roles_test.py'), '-v']
    code = recipe.execute(command, env, attempt / 'run', 30)
    recipe.save(attempt / 'summary.json', {'status': 'PASS' if code == 0 else 'FAIL',
        'scope': 'Existing host-only GGUF input unit suite including complete type40 metadata and rejection boundaries',
        'process': json.loads((attempt / 'run/process.json').read_text()),
        'source_records': records, 'GPU': False, 'HTTP': 0})
    if code:
        raise RuntimeError('GGUF host input suite failed; raw retained')
