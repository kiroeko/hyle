from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[3]
batch = Path(__file__).resolve().parent
output = batch / 'root-integration.json'
assert not output.exists(), 'Integration already recorded'

def read(path):
    return json.loads(path.read_bytes())

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

before = read(batch / 'before-pins.json')
after = read(batch / 'after-pins.json')
assert [v['path'] for v in before] == [v['path'] for v in after]
assert len(after) == 2
for old, new in zip(before, after):
    assert pin(root / old['path']) == {k: old[k] for k in ('bytes', 'sha256')}
    assert pin(batch / 'source' / new['path']) == {k: new[k] for k in ('bytes', 'sha256')}
for row in read(batch / 'unchanged-attempt1-execution-pins.json'):
    assert pin(root / row['path']) == {k: row[k] for k in ('bytes', 'sha256')}

attempt = batch / 'attempt1'
for name in ('tests', 'link', 'run'):
    result = read(attempt / name / 'process.json')
    assert result['exit'] == 0 and not result['timeout']
xml = ET.parse(attempt / 'results.xml').getroot()
assert int(xml.attrib['tests']) == 2
assert all(int(xml.attrib[k]) == 0 for k in ('failures', 'errors', 'disabled'))
expected = {
    'TransientFailureCanReleaseFirstFeeWithoutInvalidatingOriginalResult',
    'RejectedSecondScopePreservesFirstChargeAndResultForRetry',
}
assert {v.attrib['name'] for v in xml.iter('testcase')} == expected
assert not list(xml.iter('skipped'))

for row in after:
    (root / row['path']).write_bytes((batch / 'source' / row['path']).read_bytes())
    assert pin(root / row['path']) == {k: row[k] for k in ('bytes', 'sha256')}
output.write_bytes((json.dumps({
    'status': 'INTEGRATED_AFTER_TWO_PASSING_CASES',
    'before': before, 'after': after,
    'unchanged_execution': read(batch / 'unchanged-attempt1-execution-pins.json'),
    'actual_cases': sorted(expected), 'xml': pin(attempt / 'results.xml'),
    'extra_build_or_runtime': False,
}, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print('Integrated corrected comments and the transient-owner test; no new build or run.')
