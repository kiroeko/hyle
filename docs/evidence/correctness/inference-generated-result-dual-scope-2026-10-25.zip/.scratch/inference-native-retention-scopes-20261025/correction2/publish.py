"""Preserve attempt1 verbatim and publish the reviewed export-owner contract."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile

R=Path.cwd();C=Path(__file__).resolve().parent;D=C.parent
PUBLIC=R/'docs/evidence/correctness/inference-generated-result-dual-scope-2026-10-25.json'
ZIP=PUBLIC.with_suffix('.zip');H=C/'history'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def pin(path):
    data=path.read_bytes();return dict(path=path.relative_to(R).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')

# The superseded public files are immutable evidence of the review finding.
if not H.exists():
    H.mkdir()
    assert pin(PUBLIC)['sha256']=='d05c018468ba1cd5621989bc88d6d66827970013eb29abc393387eb5c66e2170'
    assert pin(ZIP)['sha256']=='4121d9c5463ed304225dd8cdc4e3f2f4bd9a41afeff6c0f33da4440c2dedceb3'
    shutil.copy2(PUBLIC,H/'attempt1-public.json');shutil.copy2(ZIP,H/'attempt1-public.zip')
assert pin(H/'attempt1-public.json')['sha256']=='d05c018468ba1cd5621989bc88d6d66827970013eb29abc393387eb5c66e2170'
assert pin(H/'attempt1-public.zip')['sha256']=='4121d9c5463ed304225dd8cdc4e3f2f4bd9a41afeff6c0f33da4440c2dedceb3'
with zipfile.ZipFile(H/'attempt1-public.zip') as z:assert z.testzip() is None

result=ET.parse(C/'attempt1/results.xml').getroot()
assert int(result.attrib['tests'])==2 and int(result.attrib['failures'])==int(result.attrib.get('errors',0))==0
old=read(D/'after-pins.json');new={v['path']:v for v in read(C/'after-pins.json')}
final=[new.get(v['path'],v) for v in old]
before=read(D/'before-pins.json');patch=''
for row,prior in zip(final,before):
    assert row['path']==prior['path']
    name=row['path'];actual=C/'source'/name if name in new else D/'source'/name
    assert pin(actual)['sha256']==row['sha256']
    assert pin(R/name)['sha256']==row['sha256'],'canonical differs from root-integrated checked sources'
    patch+=''.join(difflib.unified_diff((D/'before'/name).read_text().splitlines(keepends=True),
        actual.read_text().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
save(C/'final-source-pins.json',final);save(C/'final-before-pins.json',before)
(C/'final-source.patch').write_text(patch,encoding='utf8')

actual=dict(test_compile=read(C/'attempt1/tests/process.json'),link=read(C/'attempt1/link/process.json'),
    run=read(C/'attempt1/run/process.json'),xml=pin(C/'attempt1/results.xml'),ready=read(C/'attempt1/ready.json'),
    tests=2,failures=0,new_cases=1,persistent_owner_control=1,
    results=[dict(suite=s.attrib['name'],name=t.attrib['name']) for s in result for t in s])
summary=dict(status='PASS_CORRECTED_EXPORT_OWNER_CONTRACT_CANONICAL_SOURCE_INTEGRATED',
    scope='Four product paths plus one existing Graph layer test TU; correction changes only result.h comments and that existing test TU',
    final_sources=final,final_before_sources=before,final_patch=pin(C/'final-source.patch'),
    correction_delta=dict(before=read(C/'before-pins.json'),after=read(C/'after-pins.json'),patch=pin(C/'source.patch')),
    unchanged_execution=read(C/'unchanged-attempt1-execution-pins.json'),
    corrected_contract=dict(
        successful='Both scopes succeed on the one returned export ReadLease/Domain. Its retained owners/subviews hold both fees and its actual backing owner until they retire.',
        failure='The original GraphOutput/result and permissions remain intact. A first fee follows normal export-owner lifetime; no atomic counter rollback or persistence beyond that lifetime is promised.',
        persistent='Apple cached exports and the persistent host fixture can keep the first fee after second-scope rejection.',
        transient='Vulkan fresh export_storage/ReadLease::adopt domains can die on rejected second scope and normally return the first fee while the uncharged native slot remains readable.',
        independent_uncharged='Prior independent uncharged exports/native slot ownership are not retroactively charged by later admission.',
        cap='Completed-result retention admission, not preallocation reservation for Provider-private storage or a physical-device memory cap.'),
    correction_reason='Attempt1 universally generalized persistent-owner fee lifetime. Independent source review found the current fresh-wrapper Vulkan counterexample; the API comments were narrowed instead of adding a slot cache or new owner mechanism.',
    independent_review=pin(D/'independent-review.md'),
    native_source_anchors=[
        dict(path='src/graph_route_vulkan/native_region.cc',function='lease',lines='454-486'),
        dict(path='src/graph_route_vulkan/native_paged_region.cc',function='lease',lines='569-584'),
        dict(path='src/graph_route_vulkan/native_ragged_region.cc',function='lease',lines='205-219'),
        dict(path='src/compute_route_vulkan/vulkan_memory.cc',function='MemoryAccess::export_storage',lines='488-520'),
        dict(path='src/graph_route_apple/native_region.cc',function='lease',lines='452-456')],
    actual_correction=actual,
    measured_journey=['Fresh host export tokens retain the same original Root; compiled region_output_resource and original Graph source validation are used.',
        'Second-scope rejection destroys its temporary Domain and returns its first32B fee; earlier uncharged export plus original result remain readable.',
        'Explicit credit release permits dual success, two scopes each retain32B on the escaped charged Domain.',
        'Another failed temporary sibling cannot clear an earlier successful reader\'s shared canonical charge.',
        'After Graph/slot destruction uncharged and charged readers retain the original Root; after uncharged reader release the charged reader retains both fees; last charged reader release frees Root and both fees.'],
    initial_validation=dict(actual=read(D/'summary.json')['actual'],main='CPU strict only, final corrected recipe exit0/7.109s',
        shadow_failures=read(D/'summary.json')['first_failures'],
        qualification='Initial six passing cases include persistent-owner behavior. Their raw results remain valid; their universal fee-persistence interpretation is superseded.'),
    attempt1_history=dict(json=pin(H/'attempt1-public.json'),archive=pin(H/'attempt1-public.zip'),
        archive_nested_verbatim=True,old_sources_pins_raw_unchanged=True),
    integration=dict(initial=pin(D/'root-integration.json'),correction=pin(C/'root-integration.json'),
        actual=read(C/'root-integration.json'),extra_build_or_runtime=False),
    limits=['Actual host Graph generated-result fixture; no Apple/Vulkan/CUDA native hardware run or Model execution in this batch.',
        'Model only CPU /W4 /WX /Zs in attempt1. Resources/prepared_output/Model execution code is byte-for-byte unchanged in correction2; no new main check.',
        'Initial one Graph TU plus one existing test TU, initial six runtime cases; correction one test TU only plus exactly two cases. No full target/SDK/vendor build or platform matrix.',
        'No Source authorization, alias, readiness, permission or retirement gate relaxed; no new slot cache/executor/registry.',
        'No throughput, quality or physical-memory-cap claim.'],GPU=0,HTTP=0,SDK_full_build=0)
save(C/'summary.json',summary)

cleanup=[pin(p) for folder in [D/'attempt1/tests',D/'attempt1/link'] for p in sorted(folder.iterdir())
    if p.suffix.lower() in ('.obj','.exe','.lib','.exp')]
save(C/'rebuildable-cleanup-candidates.json',dict(status='LIST_ONLY_NOT_REMOVED',files=cleanup,
    logical_bytes=sum(v['bytes'] for v in cleanup),
    preserve=['correction2/attempt1/tests/unit.obj','correction2/attempt1/link/*','attempt1/resources/unit.obj',
              '.scratch/inference-cache-shared-source-20261025/attempt1/{budget,leases,arena}/unit.obj'],
    note='Only superseded attempt1 test object and image/link products. Root test.ps1 exact preview/Apply; no deletion here.'))

files={H/'attempt1-public.json',H/'attempt1-public.zip',D/'independent-review.md',
    D/'root-integration.json',D/'root-integrate.py',D/'after-pins.json',D/'before-pins.json'}
for name in ['before-pins.json','after-pins.json','source.patch','plan.md','freeze.py','check.py','summary.json',
    'unchanged-attempt1-execution-pins.json','final-source-pins.json','final-before-pins.json','final-source.patch',
    'root-integrate.py','root-integration.json','rebuildable-cleanup-candidates.json','publish.py']:
    files.add(C/name)
for row in read(C/'before-pins.json'):
    files.add(C/'before'/row['path']);files.add(C/'source'/row['path'])
for path in (C/'attempt1').rglob('*'):
    if path.is_file() and path.name in ('command.json','process.json','stdout.log','stderr.log',
        'repository-inputs.json','source-pins.json','ready.json','link-inputs.json','results.xml'):
        files.add(path)
members=[pin(p) for p in sorted(files)];save(C/'archive-members.json',members);files.add(C/'archive-members.json')
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(files):
        assert path.suffix.lower() not in ('.exe','.obj','.lib','.exp','.dll','.bin','.pdb')
        z.write(path,path.relative_to(R).as_posix())
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    for row in members:
        data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary['archive']=dict(**pin(ZIP),members=len(files),logical_bytes=sum(p.stat().st_size for p in files),
    CRC=True,member_sha256=True,attempt1_archive_preserved_verbatim=True,no_binaries=True)
summary['cleanup']=read(C/'rebuildable-cleanup-candidates.json')
save(PUBLIC,summary)
print(json.dumps(dict(public=pin(PUBLIC),archive=summary['archive'],
    final_sources=final,cleanup_files=len(cleanup),cleanup_bytes=sum(v['bytes'] for v in cleanup)),indent=2))
