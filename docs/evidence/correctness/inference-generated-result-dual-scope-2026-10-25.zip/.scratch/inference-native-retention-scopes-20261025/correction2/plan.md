# Narrow the existing export-owner contract, not the native owner model

Attempt1's five checked sources/pins/raw and public archive remain unchanged.
This delta changes only result.h comments and the existing host test TU.
The Graph resources/helper/Model execution code remains byte-for-byte attempt1.

The old general statement that an initially successful fee always remains
until the slot's original native backing retires was too strong. Vulkan's
native_region.cc::lease creates export_storage + ReadLease::adopt afresh; paged
and ragged routes do the same. On second-scope rejection this temporary Domain
can die and correctly return its first fee, while the uncharged native slot
still owns its data. Apple and the persistent host fixture retain a Domain and
therefore can keep that fee. Neither behavior implies a future-provider or
physical-memory cap; no successful uncharged dual-scope lease is returned.

The corrected API guarantees result/permission preservation and normal charge
lifetime through the actual charged export owner/Domain and its retained uses.
Independent prior uncharged exports/slot owners are not retroactively charged.
Failure does not promise atomic counter rollback or persistence past that
actual export owner. No Vulkan slot cache, new owner, resource rule or gate.

One additional opt-in branch in the existing DeferredRun fixture uses a host
resource whose slot token and each fresh export token retain the same original
Root(Buffer sys). Its real map address proves canonical host identity. The
compiled region_output_resource is the same nominated resource; existing Graph
source validation remains in force. Only this test's immutable generation is
frozen after success, guarding both later bind and submit. Default/persistent
fixture modes remain unchanged. No new executor, alternate math, or fake data.

The one new journey verifies transient second rejection naturally returns the
first fee, original result plus earlier uncharged export remain readable, then
explicit credit release permits a successful dual-scope export. A later failed
charged sibling does not remove the successful reader's same-scope fee. After
Graph/slot destruction, the escaped charged Domain keeps both32B fees/root data;
the final reader release drops both fees and the original root. Inputs/scopes
remain original row8/two Neg and1MiB admission scopes, not threshold-search.

Freeze before/after/patch, then refresh only this original test TU and link its
existing closure, retaining attempt1 resources OBJ and original3core OBJs.
Run exactly2 cases:
- GraphResultRetentionScopes.TransientFailureCanReleaseFirstFeeWithoutInvalidatingOriginalResult
- GraphResultRetentionScopes.RejectedSecondScopePreservesFirstChargeAndResultForRetry
No main/Zs, no Graph/core rebuild, no original6 rerun, GPU/SDK/network=0.
All failures/raw are retained; existing attempt1 proof will be qualified in a
later explicit correction, not overwritten to hide its original statements.
