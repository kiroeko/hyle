from pathlib import Path
import hashlib,difflib,json
R=Path.cwd();C=Path(__file__).resolve().parent;D=C.parent
before=json.loads((C/'before-pins.json').read_text());after=[];patch=''
for row in before:
    name=row['path'];old=C/'before'/name;new=C/'source'/name
    assert hashlib.sha256(old.read_bytes()).hexdigest()==row['sha256']
    data=new.read_bytes();after.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    patch+=''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),
        new.read_text().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
unchanged=[]
for row in json.loads((D/'after-pins.json').read_text()):
    if row['path'] in [r['path'] for r in before]:continue
    assert hashlib.sha256((D/'source'/row['path']).read_bytes()).hexdigest()==row['sha256']
    assert (R/row['path']).read_bytes()==(D/'source'/row['path']).read_bytes()
    unchanged.append(row)
(C/'after-pins.json').write_text(json.dumps(after,indent=2)+'\n')
(C/'unchanged-attempt1-execution-pins.json').write_text(json.dumps(unchanged,indent=2)+'\n')
(C/'source.patch').write_text(patch)
print(json.dumps(dict(paths=len(after),patch_bytes=len(patch.encode()),unchanged_execution_paths=len(unchanged),compiled=False,run=False),indent=2))
