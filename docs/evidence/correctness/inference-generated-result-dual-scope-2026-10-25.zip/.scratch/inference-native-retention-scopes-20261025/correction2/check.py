"""One original host test TU, previous resources/core objects, only two cases."""
from pathlib import Path
import importlib.util
import os,sys
sys.dont_write_bytecode=True
R=Path.cwd();C=Path(__file__).resolve().parent;D=C.parent
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
O=C/'attempt1';O.mkdir(exist_ok=False)
old=b.args(D/'attempt1/tests/command.json');flags=[];skip=False
for word in old[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    n=word.lower().replace('\\','/')
    if n.startswith(('/fo','/fd')) or n.endswith(('.cc','.cpp')):continue
    flags.append(word)
frozen=b.read(C/'after-pins.json')
for row in frozen:assert b.pin(C/'source'/row['path'])['sha256']==row['sha256']
b.save(O/'source-pins.json',frozen)
env=b.environment(old[0]);folder=O/'tests'
b.execute([old[0],'/I'+str(C/'source/include'),*flags,str(C/'source/tests/graph/region_provider_test.cc'),
    '/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(folder/'unit.obj')],folder,env,120)
deps=b.read(folder/'dependencies.json')['Data']
b.save(folder/'repository-inputs.json',[b.pin(p) for p in
    [Path(deps['Source']),*(Path(v) for v in deps['Includes'])] if p.is_relative_to(R)])
for row in frozen:assert b.pin(C/'source'/row['path'])['sha256']==row['sha256']
oldlink=b.args(D/'attempt1/link/command.json');args=[];removed=[]
for word in oldlink[1:]:
    n=word.lower().replace('\\','/')
    if n.endswith('/inference-native-retention-scopes-20261025/attempt1/tests/unit.obj'):removed.append(word);continue
    if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
    args.append(word)
assert len(removed)==1,removed
b.save(O/'link-inputs.json',dict(original=b.pin(D/'attempt1/link/command.json'),removed=removed,
    replacement=b.pin(folder/'unit.obj'),resources=b.pin(D/'attempt1/resources/unit.obj')))
b.execute([oldlink[0],*args,str(folder/'unit.obj'),'/OPT:REF','/OUT:'+str(O/'link/checks.exe'),
    '/IMPLIB:'+str(O/'link/checks.lib')],O/'link',env,120)
native=R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,O/'link'/native.name)
runtime=b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')
runenv=os.environ.copy();runenv['PATH']=str(O/'link')+';'+runtime['PATH']
tests=['GraphResultRetentionScopes.TransientFailureCanReleaseFirstFeeWithoutInvalidatingOriginalResult',
       'GraphResultRetentionScopes.RejectedSecondScopePreservesFirstChargeAndResultForRetry']
b.save(O/'ready.json',dict(image=b.pin(O/'link/checks.exe'),native=b.pin(native),source=frozen,
    fresh_test_TUs=1,resources_reused=b.pin(D/'attempt1/resources/unit.obj'),filter=tests,expected_tests=2,
    main_check=False,GPU=0,HTTP=0,SDK_build=0))
b.execute([str(O/'link/checks.exe'),'--gtest_filter='+':'.join(tests),
    '--gtest_output=xml:'+str(O/'results.xml')],O/'run',runenv,60)
