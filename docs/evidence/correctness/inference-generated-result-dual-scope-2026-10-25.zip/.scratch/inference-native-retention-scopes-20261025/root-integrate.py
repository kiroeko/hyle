from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
root = base.parents[1]
read = lambda path: json.loads(path.read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
summary = read(base / 'summary.json')
assert summary['status'] == 'PASS_PRIVATE_GRAPH_RETENTION_CLOSURE_CANONICAL_INTEGRATION_PENDING'
actual = summary['actual']
assert actual['tests'] == 6 and actual['failures'] == actual['skipped'] == 0
for name in ('run', 'resources_compile', 'test_compile', 'link', 'main_strict'):
    assert actual[name]['exit'] == 0 and not actual[name]['timeout'], name
xml = root / actual['xml']['path']
assert sha(xml.read_bytes()) == actual['xml']['sha256']
checked = ET.parse(xml).getroot()
assert int(checked.attrib['tests']) == 6 and int(checked.attrib['failures']) == 0
before = {item['path']: item for item in read(base / 'before-pins.json')}
after = read(base / 'after-pins.json')
assert len(before) == len(after) == 5
changes = []
for item in after:
    name = item['path']
    target = (root / name).resolve()
    assert target.is_relative_to(root) and not target.is_symlink()
    original = target.read_bytes()
    assert len(original) == before[name]['bytes'] and sha(original) == before[name]['sha256'], name
    source = (base / 'source' / name).read_bytes()
    assert len(source) == item['bytes'] and sha(source) == item['sha256'], name
    ending = b'\r\n' if b'\r\n' in original else b'\n'
    output = source.replace(b'\r\n', b'\n').replace(b'\n', ending)
    changes.append((target, output, dict(path=name, before_sha256=sha(original),
        after_sha256=sha(output), checked_private_raw_sha256=sha(source),
        bytes=len(output), normalized_checked_source_equal=True)))
for target, output, _ in changes:
    target.write_bytes(output)
result = dict(status='INTEGRATED_REVIEWED_GENERATED_RESULT_DUAL_SCOPE',
    files=[item for _, _, item in changes],
    root_review='One original output export and admitted nominated resource; two flat scopes using existing identity deduplication; first charge survives additional rejection through actual retirement; old result/permissions intact; unchanged no-scope math and control flow.',
    actual_checks='One Graph resources TU, one existing region-provider test TU, six filtered host cases, corrected main CPU strict syntax only.',
    limitations='No new native GPU/platform inference or TPS. Completed-result retention is not reservation of future private provider storage or physical VRAM cap.',
    extra_build_or_run=False)
(base / 'root-integration.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=result['status'], paths=len(changes), GPU_runs=0)))
