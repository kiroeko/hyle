# Independent narrow review: native result retention scopes

Read-only source review of `source.patch` / `summary.json` and the actual original export implementations. No build, test, GPU or HTTP.

## Concrete contract issue to resolve before universal claim

`source/src/graph/resources.cc:1383–1396,1448–1456` applies both fees to one local exported ReadLease. If the second scope rejects, that local reader is destroyed by the error return. A fee survives only while this exact domain or another holder of its shared charge remains alive.

The new `result.h:39–45` promise that every first successful fee persists until the actual original backing retires is not true for all current providers. Vulkan `src/graph_route_vulkan/native_region.cc:454–486` creates a fresh `export_storage` wrapper and `ReadLease::adopt` domain on every call; paged `:569–584` and ragged `:205–219` do likewise. `compute_route_vulkan/vulkan_memory.cc:488–520` makes an AllocationToken holding a shared native Buffer; the native slot still holds that Buffer independently. With no earlier retained exported reader, first fee succeeds, second fails, temporary lease/domain dies and the first fee is released, while the original GraphOutput/native backing remains readable/live. Native backing canonical identity permits dedup but does not itself pin a charge without a retained domain.

Apple caches `slot.exported` (`graph_route_apple/native_region.cc:407–456`), as does the new opted-in test's `run.output_owner`. The six passing cases therefore prove persistent-export-owner behavior, not the fresh-wrapper Vulkan case.

Minimal correction depends on intended contract: retain the original exported lease in its actual result/slot owner across failed admission if first-fee persistence is required; or explicitly describe no *manual* rollback while keeping existing export-domain lifetime, and narrow the universal persistence sentence/evidence. Do not add an ownership table merely to satisfy wording, nor call the current Vulkan behavior proved persistent.

## Remaining finite checks

- Both fees use the same existing `output_storage` selection and unchanged nominated resource. Existing source authorization, exact range matching, generated producer lookup and final subview remain unchanged; one native lease export per call, not two exports.
- Empty/same/additional-only paths retain existing skip/dedup. With no scope the new lambda immediately returns success, with no extra export, backing or materialization.
- Model's four temporary-output call-site edits add only `allocation_budget` inside unchanged conditions; state retention adds local+allocation. Draft q/NF4 paths and state/RNG publication authority remain unchanged. CPU strict compilation is correctly distinguished from model/native hardware runtime in the summary.
- Default `deferred_owned_output=false` leaves the old reusable fixture backing path unchanged. The new callback returns Unimplemented in that mode. The only product pointer-presence check is `src/graph/plan_state.h:207` at output-lease invocation; it is not a cold capability/region qualification test. Opted-in owner is immutable and therefore blocks rewriting the exported original generation.

No other concrete issue found in this finite scope. No product/proof/board edits performed.

## Resolved semantic direction (source review only)

Root selected completed-result retention semantics, not admission for a Provider's pre-existing private allocation. Under that definition the fresh-wrapper counterexample is legitimate automatic lifetime cleanup, not a successful-admission budget bypass: no reader/snapshot escapes the rejected second gate; pending work is not being admitted or excused. The documentation/test must distinguish this from a persistent exported owner rather than adding a provider slot-cache merely to force a fee to remain.

A successful pair reaches `return lease.subview(offset, bytes)` only after both constraints succeed. The returned reader and its subviews keep that same Domain; its retained records hold both scopes, and the Domain's Buffer/AllocationToken retains the actual native Buffer and resource controller. Domain teardown releases the export wrapper before these fees. Another failed temporary export cannot remove a shared record's charge while an earlier successful reader still holds it. Original nominated-resource authorization/range validation and old-reader protection remain unchanged.

Thus no concrete successful-retention budget bypass found for the revised semantics. The minimal additional fixture should prove that an independent transient export wrapper may die/return its newly attached first fee on second-gate failure, while the original result remains readable, and a later successful dual reader keeps both fees. The existing persistent-owner fixture remains valuable and should keep asserting its fee survives. Exact public wording should say existing export-owner lifetime and no promised two-scope count-rollback atomicity; it must not promise all Provider-private backing lifetimes are charged.
