#!/usr/bin/env bash
set -euo pipefail
r2_root=/root/hyle-validation/r2-q4-20260916
r2_source="$r2_root/source-210044ce"
r2_build="$r2_root/ubsan-210044ce"
cd "$r2_source"
scripts/hyle-unix.sh cmake -S "$r2_source" -B "$r2_build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_DEV_FACTORS=compute_ops -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_WERROR=ON -DHYLE_SANITIZER=ubsan -DCMAKE_CXX_FLAGS= -DCMAKE_EXE_LINKER_FLAGS= -DCMAKE_SHARED_LINKER_FLAGS= > "$r2_root/logs-210044ce/ubsan-native-configure.log" 2>&1
scripts/hyle-unix.sh cmake --build "$r2_build" --parallel 2 --target hyle_compute_ops_tests > "$r2_root/logs-210044ce/ubsan-native-build.log" 2>&1
ctest --test-dir "$r2_build" --output-on-failure --no-tests=error -L '^compute_ops$' > "$r2_root/logs-210044ce/ubsan-native-tests.log" 2>&1
printf 'PASS Linux Q4 UBSan through HYLE_SANITIZER=ubsan\n'
