#!/usr/bin/env bash
set -euo pipefail
export PATH=/Users/kiro/hyle-verify-tools/bin:/opt/homebrew/bin:$PATH
r2_root=/Users/kiro/hyle-validation/r2-q4-20260916
r2_source="$r2_root/source-210044ce"
cd "$r2_source"
scripts/hyle-unix.sh cmake -S "$r2_root/q4-consumer" -B "$r2_root/q4-source" -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 -DHYLE_SOURCE_DIR="$r2_source" > "$r2_root/logs-210044ce/q4-source-floor-configure.log" 2>&1
scripts/hyle-unix.sh cmake --build "$r2_root/q4-source" --parallel 2 > "$r2_root/logs-210044ce/q4-source-floor-build.log" 2>&1
"$r2_root/q4-source/q4_consumer" > "$r2_root/logs-210044ce/q4-source-floor-run.log" 2>&1
printf 'PASS macOS Q4 source consumer with declared deployment floor\n'
