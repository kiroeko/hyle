#!/usr/bin/env bash
set -euo pipefail
r2_root=$1
r2_platform=$2
case "$r2_root" in
 /root/hyle-validation/r2-q4-20260916|/Users/kiro/hyle-validation/r2-q4-20260916) ;;
 *) printf 'Unexpected verification root: %s\n' "$r2_root" >&2; exit 2 ;;
esac
export PATH=/Users/kiro/hyle-verify-tools/bin:/opt/homebrew/bin:$PATH
r2_source="$r2_root/source-50753347"
cd "$r2_source"
mkdir -p "$r2_root/logs"
r2_log_run() {
 r2_name=$1; shift
 printf 'START %s / %s\n' "$r2_platform" "$r2_name"
 if "$@" >"$r2_root/logs/$r2_name.log" 2>&1; then
  printf 'PASS %s / %s\n' "$r2_platform" "$r2_name"
 else
  r2_status=$?
  tail -n 40 "$r2_root/logs/$r2_name.log"
  exit "$r2_status"
 fi
}
scripts/hyle-unix.sh --print-toolchain
uname -a
r2_build="$r2_root/factors"
r2_log_run configure scripts/hyle-unix.sh cmake -S "$r2_source" -B "$r2_build" -G Ninja \
 -DCMAKE_BUILD_TYPE=Release -DHYLE_DEV_FACTORS=compute_ops,graph -DHYLE_BUILD_TESTS=ON \
 -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_TEST_INSTRUMENTATION=OFF \
 -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_WERROR=ON
r2_log_run build scripts/hyle-unix.sh cmake --build "$r2_build" --parallel 2 \
 --target hyle_compute_ops_tests hyle_graph_tests
r2_log_run tests ctest --test-dir "$r2_build" --output-on-failure --no-tests=error \
 -L '^(compute_ops|graph)$'
# Windows selected gates sign three-delivery packaging; Unix signs the card's schema, Graph and custom/resource consumption.
r2_log_run q4-source-configure scripts/hyle-unix.sh cmake -S "$r2_root/q4-consumer" \
 -B "$r2_root/q4-source" -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_SOURCE_DIR="$r2_source"
r2_log_run q4-source-build scripts/hyle-unix.sh cmake --build "$r2_root/q4-source" --parallel 2
r2_log_run q4-source-run "$r2_root/q4-source/q4_consumer"
if [ "$r2_platform" = linux ]; then
 r2_ubsan="$r2_root/ubsan"
 r2_log_run ubsan-configure scripts/hyle-unix.sh cmake -S "$r2_source" -B "$r2_ubsan" \
  -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_DEV_FACTORS=compute_ops -DHYLE_BUILD_TESTS=ON \
  -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_WERROR=ON \
  '-DCMAKE_CXX_FLAGS=-fsanitize=undefined -fno-sanitize-recover=all' \
  -DCMAKE_EXE_LINKER_FLAGS=-fsanitize=undefined -DCMAKE_SHARED_LINKER_FLAGS=-fsanitize=undefined
 r2_log_run ubsan-build scripts/hyle-unix.sh cmake --build "$r2_ubsan" --parallel 2 --target hyle_compute_ops_tests
 r2_log_run ubsan-tests ctest --test-dir "$r2_ubsan" --output-on-failure --no-tests=error -L '^compute_ops$'
fi
printf 'PASS all declared %s Q4 checks\n' "$r2_platform"
