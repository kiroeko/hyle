#pragma once

#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "qwen_original_mtp_roles.h"
#include "hyle/mem/mapping.h"

// Remaining original roles of MAIN Q27 UD-Q4_K_M, not its separate draft
// sidecar. Existing EH/enorm/hnorm are borrowed from the authenticated q27
// supplier. These14 mappings retain original GGUF bytes, and each immutable
// ready bank is uploaded once for all ordinary Graphs that use this model.
namespace qwen27_original_nextn_roles {
namespace original = qwen_original_mtp_roles;
namespace input = original_role_input;
namespace c = hyle::compute;
namespace m = hyle::mem;
inline constexpr std::int64_t kHidden = 5120, kVocabulary = 248320;
inline constexpr std::int64_t kHeads = 24, kKvHeads = 4, kDepth = 256, kIntermediate = 17408;
inline constexpr float kEpsilon = 1.0e-6F;
inline constexpr std::size_t kOriginalBytes = 2066065408;
inline constexpr auto &kIdentity = original::q27::kIdentity;
enum class Role : std::size_t {
  kKey, kKeyNorm, kAttentionNorm, kOutput, kQuery, kQueryNorm, kValue,
  kFfnDown, kFfnGate, kFfnUp, kHeadNorm, kPostNorm, kEmbedding, kHead, kCount
};
inline constexpr std::size_t kRoles = static_cast<std::size_t>(Role::kCount);
struct Spec final {
  std::string_view name, file, sha256;
  std::optional<c::GgufQuantizedType> codec;
  ggml_type native;
  std::int64_t k, n; // k0 is an original plain F32[n] norm.
  std::size_t bytes;
};
// Pins are filled only from root's completed fixed-range acquisition receipt.
// An empty pin rejects loading, never permits an unverified parameter file.
inline constexpr std::array<Spec, kRoles> kSpecs{
    Spec{"blk.64.attn_k.weight", "attn_k.weight.q8_0", "eb6d2cd6907d1026a760cabf9047b7775a2f6b2f58f19d4b2b5d1ab018e5fc56", c::GgufQuantizedType::kQ8_0, GGML_TYPE_Q8_0, 5120, 1024, 5570560},
    Spec{"blk.64.attn_k_norm.weight", "attn_k_norm.weight.f32", "13e8086a61052d510f01a7984b2ac7c5012337887e80594331ddef3a6a0f05c7", std::nullopt, GGML_TYPE_F32, 0, 256, 1024},
    Spec{"blk.64.attn_norm.weight", "attn_norm.weight.f32", "afb539011550a9d32f6cfb14db69b9aaed81e63fbd732124e020ae9903e0f275", std::nullopt, GGML_TYPE_F32, 0, 5120, 20480},
    Spec{"blk.64.attn_output.weight", "attn_output.weight.q6_k", "c3b17401794e74c1962846f897fb673f82f212f61d7f06337815a20bfeac1d42", c::GgufQuantizedType::kQ6K, GGML_TYPE_Q6_K, 6144, 5120, 25804800},
    Spec{"blk.64.attn_q.weight", "attn_q.weight.q6_k", "ebec153220a43ff360e3fcc4670f4ab6a21ee24cbfa4a54ad9dad7e671be8f10", c::GgufQuantizedType::kQ6K, GGML_TYPE_Q6_K, 5120, 12288, 51609600},
    Spec{"blk.64.attn_q_norm.weight", "attn_q_norm.weight.f32", "4a7f959094211b3dade3324736bb75e25c61a9197e025102646e7f74bd094a48", std::nullopt, GGML_TYPE_F32, 0, 256, 1024},
    Spec{"blk.64.attn_v.weight", "attn_v.weight.q8_0", "d55480291068e8ecce5c3253c52725f1733784cee7b0115ebfd4d1dd7bb9c108", c::GgufQuantizedType::kQ8_0, GGML_TYPE_Q8_0, 5120, 1024, 5570560},
    Spec{"blk.64.ffn_down.weight", "ffn_down.weight.q6_k", "a485f5e9ef13510f6d120425054dd1fceb1fcf9908ea14425b072734897bfcd7", c::GgufQuantizedType::kQ6K, GGML_TYPE_Q6_K, 17408, 5120, 73113600},
    Spec{"blk.64.ffn_gate.weight", "ffn_gate.weight.q6_k", "5d5eb6f849bb6b737f100cec801e57642e15299978534fe8cbbccdc342092536", c::GgufQuantizedType::kQ6K, GGML_TYPE_Q6_K, 5120, 17408, 73113600},
    Spec{"blk.64.ffn_up.weight", "ffn_up.weight.q6_k", "65b581fbed26058c4e002e317f8b295344e46ab0ec8519a10533e1f11e7801c7", c::GgufQuantizedType::kQ6K, GGML_TYPE_Q6_K, 5120, 17408, 73113600},
    Spec{"blk.64.nextn.shared_head_norm.weight", "shared_head_norm.weight.f32", "afdf2c4845dcce4470aeaf40e1726690b606eb642c5a4145a0e3f2598b0734d0", std::nullopt, GGML_TYPE_F32, 0, 5120, 20480},
    Spec{"blk.64.post_attention_norm.weight", "post_attention_norm.weight.f32", "fcfcdbdb492b9a1c31ca44997a188982a68e0741df67f36080c0562da6b7c6dd", std::nullopt, GGML_TYPE_F32, 0, 5120, 20480},
    Spec{"token_embd.weight", "embedding.weight.q4_k", "4265c91fb90a57e4f8fb93a433540ea9827668e0a476378bc6c0d16e4f4a7834", c::GgufQuantizedType::kQ4K, GGML_TYPE_Q4_K, 5120, 248320, 715161600},
    Spec{"output.weight", "head.weight.q6_k", "2155d6e1f7c5549077438c4760e6e150945dd5e406484b29162dff7b03d05da0", c::GgufQuantizedType::kQ6K, GGML_TYPE_Q6_K, 5120, 248320, 1042944000}
};
inline std::size_t index(Role role) {
  const auto result = static_cast<std::size_t>(role);
  if (result >= kRoles) throw std::runtime_error("unknown original Q27 NextN role");
  return result;
}
inline const Spec &spec(Role role) { return kSpecs[index(role)]; }
inline c::TensorDesc description(Role role) {
  const auto &s = spec(role);
  if (!s.codec)
    return original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,
        std::array{s.n}), "original Q27 F32 norm description");
  auto result = original::detail::take(c::gguf_weight_description(*s.codec,
      c::DataType::kFloat32, s.k, s.n), "original Q27 packed matrix description");
  // Gather addresses the same physical original[N,K] row bank. No repacking,
  // duplicate upload, element cast or weight expansion is needed for it.
  if (role == Role::kEmbedding)
    result = original::detail::take(result.transposed(), "original Q27 embedding orientation");
  return result;
}

class Data final {
 public:
  static Data load(const std::filesystem::path &directory) {
    for (const auto &s : kSpecs)
      if (s.sha256.size() != 64) throw std::runtime_error("original Q27 NextN input is not pinned");
    Data result;
    for (std::size_t slot = 0; slot < kRoles; ++slot) {
      const auto role = static_cast<Role>(slot);
      const auto &s = kSpecs[slot];
      if (original::detail::take(description(role).required_bytes(), "original Q27 typed extent") != s.bytes)
        throw std::runtime_error("original Q27 codec/geometry extent differs");
      const auto path = directory / std::string(s.file);
      auto mapped = original::detail::take(m::FileMapping::open(path.string().c_str()), "map original Q27 NextN role");
      if (mapped.size() != s.bytes) throw std::runtime_error("original Q27 role extent differs: " + path.string());
      const auto raw = original::detail::take(mapped.bytes(), "original Q27 mapped input");
      // The common original input SHA traverses64-byte mapped blocks and a
      // bounded tail; it does not allocate a1GB padded copy of the LM head.
      if (input::sha256(raw) != s.sha256) throw std::runtime_error("original Q27 SHA256 differs: " + path.string());
      result.mappings_[slot] = std::move(mapped);
      if (!s.codec) {
        auto &values = result.norms_[slot];
        values.resize(std::size_t(s.n));
        for (std::size_t i = 0; i < values.size(); ++i) {
          std::uint32_t bits = 0;
          for (std::size_t byte = 0; byte < 4; ++byte)
            bits |= std::to_integer<std::uint32_t>(raw[i * 4 + byte]) << (8 * byte);
          values[i] = std::bit_cast<float>(bits);
          if (!std::isfinite(values[i])) throw std::runtime_error("original Q27 norm is nonfinite");
        }
      }
    }
    return result;
  }
  std::span<const std::byte> bytes(Role role) const {
    return original::detail::take(mappings_[index(role)].bytes(), "original Q27 mapped role bytes");
  }
  m::ConstBufferView view(Role role) const {
    return original::detail::take(mappings_[index(role)].view(), "original Q27 readonly mapped view");
  }
  std::span<const float> norm(Role role) const {
    if (spec(role).codec) throw std::runtime_error("original Q27 requested matrix as norm");
    return norms_[index(role)];
  }
 private:
  // Returned views/spans borrow Data. Roles and every reference closure keep
  // its shared owner alive through all consumers; mappings are never writable.
  std::array<m::FileMapping, kRoles> mappings_;
  std::array<std::vector<float>, kRoles> norms_;
};
struct Roles final {
  std::shared_ptr<const Data> source;
  std::array<original::ReadonlyRole, kRoles> roles;
  const original::ReadonlyRole &at(Role role) const { return roles[index(role)]; }
};
inline Roles bind(std::shared_ptr<const Data> source, const c::StorageOwner &owner) {
  if (!source || !owner) throw std::runtime_error("original Q27 NextN needs original data and its actual storage owner");
  Roles result;
  result.source = std::move(source);
  for (std::size_t slot = 0; slot < kRoles; ++slot) {
    const auto role = static_cast<Role>(slot);
    result.roles[slot] = original::detail::bind(kSpecs[slot].name, description(role),
        owner, result.source->bytes(role), &kIdentity);
  }
  return result;
}
} // namespace qwen27_original_nextn_roles
