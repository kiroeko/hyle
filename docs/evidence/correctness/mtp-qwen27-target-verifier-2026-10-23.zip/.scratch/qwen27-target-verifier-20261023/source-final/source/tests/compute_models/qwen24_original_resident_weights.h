#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>

#include "qwen24_original_nextn_roles.h"
#include "hyle/compute/resource_leases.h"
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
#include "hyle/compute/cuda_weights.h"
#endif

// Finite test-engine supply for the actual Q24 Top10 union. All original512
// IDs remain logical; only their explicit mapped compressed rows enter E10.
// No quantization, F32 expert shadow or routing calculation happens here.
namespace qwen24_original_resident_weights {
namespace original = qwen24_original_nextn_roles;
namespace c = hyle::compute;
namespace m = hyle::mem;
using hyle::Result;
using hyle::Status;
inline constexpr std::size_t kCapacity = original::kResidentCapacity;
inline constexpr std::size_t kExpertBytes = original::kExpertBytes;
inline constexpr std::size_t kBankBytes = kCapacity * kExpertBytes;
inline constexpr std::size_t kMapBytes = original::kExpertDomain * sizeof(std::int32_t);
inline constexpr std::size_t kLogicalBytes = 3 * kBankBytes + kMapBytes;
inline constexpr std::size_t kSlotBytes = (kLogicalBytes + 255) & ~std::size_t{255};
inline constexpr std::array<std::uint64_t, 4> kBankIds{10, 20, 30, 40};
inline constexpr std::array<original::Leg, 3> kLegs{
    original::Leg::kGate, original::Leg::kUp, original::Leg::kDown};
static_assert(kBankBytes == 94371840 && kLogicalBytes == 283117568 && kSlotBytes == kLogicalBytes);

inline Result<c::TensorDesc> map_description() {
  return c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{original::kExpertDomain});
}
inline Status validate(const original::Selection &selected) {
  if (selected.globals.empty() || selected.globals.size() > kCapacity)
    return Status::InvalidArgument("Q24 resident union must contain1..10 original IDs");
  std::array<std::int32_t, original::kExpertDomain> expected;
  expected.fill(-1);
  std::int32_t previous = -1;
  for (std::size_t local = 0; local < selected.globals.size(); ++local) {
    const auto global = selected.globals[local];
    if (global < 0 || global >= original::kExpertDomain || global <= previous)
      return Status::InvalidArgument("Q24 resident IDs must be sorted, unique and within0..511");
    expected[std::size_t(global)] = std::int32_t(local);
    previous = global;
  }
  if (selected.map != expected) return Status::InvalidArgument("Q24 resident map differs from the exact original union");
  return Status::Ok();
}
inline std::int32_t original_at(const original::Selection &selected, std::size_t local) {
  // Full initialization includes unused capacity. Repeated valid source rows
  // in that tail get no map entry and cannot change a real global expert ID.
  return local < selected.globals.size() ? selected.globals[local] : selected.globals.front();
}
struct CpuBatch final {
  c::StorageOwner owner;
  std::array<c::ReadLease, 4> banks;
};
class CpuSupply final {
 public:
  static Result<CpuSupply> create(const c::StorageOwner &owner) {
    if (!owner) return std::unexpected(Status::InvalidArgument("Q24 CPU supply needs its actual storage owner"));
    CpuSupply result; result.owner_ = owner;
    HYLE_ASSIGN_OR_RETURN(result.pool_, c::LeasePool::create(owner.ref(), 2 * kSlotBytes,
        {.max_blocks = 8, .backing_alignment = 256}));
    return result;
  }
  Result<CpuBatch> upload(const original::Selection &selected, const original::Data &source) {
    HYLE_RETURN_IF_ERROR(validate(selected));
    CpuBatch result{.owner = owner_};
    std::array<c::WriteLease, 4> writers;
    for (std::size_t leg = 0; leg < kLegs.size(); ++leg) {
      HYLE_ASSIGN_OR_RETURN(writers[leg], pool_.allocate(kBankBytes));
      HYLE_ASSIGN_OR_RETURN(auto destination, writers[leg].view());
      for (std::size_t local = 0; local < kCapacity; ++local) {
        HYLE_ASSIGN_OR_RETURN(auto slice, destination.subview(local * kExpertBytes, kExpertBytes));
        HYLE_RETURN_IF_ERROR(slice.write(source.expert_bytes(kLegs[leg], original_at(selected, local))));
      }
    }
    HYLE_ASSIGN_OR_RETURN(writers[3], pool_.allocate(kMapBytes));
    HYLE_ASSIGN_OR_RETURN(auto map, writers[3].view());
    HYLE_RETURN_IF_ERROR(map.write(std::as_bytes(std::span(selected.map))));
    for (std::size_t bank = 0; bank < writers.size(); ++bank) {
      HYLE_ASSIGN_OR_RETURN(result.banks[bank], writers[bank].publish());
    }
    return result;
  }
  c::LeasePoolStats stats() const noexcept { return pool_.stats(); }
 private:
  c::StorageOwner owner_;
  c::LeasePool pool_;
};

#if defined(HYLE_TEST_QWEN_STATE_CUDA)
class CudaSupply final {
 public:
  static Result<CudaSupply> create(const c::Context &context, const c::StorageOwner &owner,
      const c::cuda::MemoryResource &device) {
    if (!owner || owner.ref() != device.ref() || device.kind() != c::cuda::MemoryKind::kDevice)
      return std::unexpected(Status::InvalidArgument("Q24 CUDA supply needs the compiled device resource and real owner"));
    CudaSupply result; result.state_ = std::make_unique<State>();
    result.state_->device_owner = owner;
    HYLE_ASSIGN_OR_RETURN(result.state_->host, c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
    std::array<c::cuda::WeightSpec, 4> catalog;
    for (std::size_t leg = 0; leg < kLegs.size(); ++leg)
      catalog[leg] = {kBankIds[leg], original::resident_description(kLegs[leg])};
    HYLE_ASSIGN_OR_RETURN(auto map, map_description());
    catalog[3] = {kBankIds[3], map};
    HYLE_ASSIGN_OR_RETURN(result.state_->slots, c::cuda::WeightSlots::create(context,
        result.state_->host, device, catalog, kSlotBytes, {.max_fragments = 31}));
    HYLE_ASSIGN_OR_RETURN(result.state_->map, m::Buffer::create(m::system_resource(), kMapBytes, 256));
    return result;
  }
  Result<c::cuda::WeightBatch> upload(std::size_t slot, const original::Selection &selected,
      const original::Data &source, c::Queue &queue) {
    HYLE_RETURN_IF_ERROR(validate(selected));
    if (!state_) return std::unexpected(Status::FailedPrecondition("empty Q24 CUDA supply"));
    HYLE_RETURN_IF_ERROR(state_->map.view().write(std::as_bytes(std::span(selected.map))));
    HYLE_ASSIGN_OR_RETURN(auto encoded, c::TensorDesc::dense(c::DataType::kUInt8,
        std::array<std::int64_t, 1>{std::int64_t(kExpertBytes)}));
    std::array<c::WeightSlice, 31> slices;
    std::size_t count = 0;
    for (std::size_t leg = 0; leg < kLegs.size(); ++leg)
      for (std::size_t local = 0; local < kCapacity; ++local) {
        HYLE_ASSIGN_OR_RETURN(auto tensor, c::ConstTensorView::create(encoded,
            source.expert_view(kLegs[leg], original_at(selected, local))));
        slices[count++] = {kBankIds[leg], tensor, local * kExpertBytes};
      }
    HYLE_ASSIGN_OR_RETURN(auto map, map_description());
    HYLE_ASSIGN_OR_RETURN(auto tensor, c::ConstTensorView::create(map, state_->map.view()));
    slices[count++] = {kBankIds[3], tensor, 0};
    // Synchronous staging finishes borrowing the mapped originals/map before
    // returning. The immutable batch retains the real pending upload; caller
    // keeps this Supply through all readers and ordinary Invocation resets.
    return state_->slots.upload_slices(slot, std::span(slices).first(count), queue);
  }
  Result<c::WeightUploadReport> report(std::size_t slot) const {
    if (!state_) return std::unexpected(Status::FailedPrecondition("empty Q24 CUDA supply"));
    return state_->slots.report(slot);
  }
  Status close() { return state_ ? state_->slots.close() : Status::Ok(); }
 private:
  struct State final {
    // Stable heap address protects borrowed resource identity across moves.
    // close drains uploads before pinned storage or the deviceowner goes away.
    c::StorageOwner device_owner;
    c::cuda::MemoryResource host;
    c::cuda::WeightSlots slots;
    m::Buffer map;
    ~State() { slots.close().IgnoreError(); }
  };
  std::unique_ptr<State> state_;
};
#endif
} // namespace qwen24_original_resident_weights
