#pragma once

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <stdexcept>

#include "d5_moe_semantic_fragments.h"
#include "hyle/compute/low_precision.h"

// Pure original MAIN Q24 GGUF MoE math. The caller supplies immutable original
// parameters and ordinary compact expert inputs; no loading or execution here.
namespace qwen24_original_moe_fragment {
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace core=d5_moe_semantic_fragments;
namespace c=hyle::compute;
using Value=sem::ValueId;
inline constexpr std::int64_t kHidden=8192,kIntermediate=2048,kExperts=512,kSlots=10;
struct Parameters final {
  Value router,shared_gate;
  std::array<Value,3> shared,banks; // gate,up,down
  Value map;
};
struct Boundary final {
  Value input,ids,weights;
  std::array<Value,3> banks;
  Value map;
};
struct ProjectionPorts final {
  Value gate,up,activation,down;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&gate,&up,&activation,&down})visitor(*value);
  }
};
struct Ports final {
  Value input,logits,probabilities,ids,selected_scores,sum,denominator,weights,local_ids,map;
  ProjectionPorts routed,shared;
  Value weighted,routed_sum,shared_gate_raw,shared_gate_sigmoid,shared_gated,merged;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&input,&logits,&probabilities,&ids,&selected_scores,&sum,&denominator,&weights,&local_ids,&map})visitor(*value);
    routed.visit_values(visitor);shared.visit_values(visitor);
    for(auto *value:{&weighted,&routed_sum,&shared_gate_raw,&shared_gate_sigmoid,&shared_gated,&merged})visitor(*value);
  }
};
struct Result final {Value output;Ports ports;Boundary boundary;};
inline Value sum(sem::Fragment &f,Value input,std::int32_t axis) {
  return f.one(c::Operation(c::Reduce{.kind=c::ReductionKind::kSum,
      .axes=c::Axes::from(std::array{axis}).value(),.keep_dimensions=true,
      .accumulation_type=c::DataType::kFloat32}),{input});
}
inline Result append(sem::Fragment &f,Value input,const Parameters &parameters) {
  if(f.description(input)!=sem::dense({1,kHidden})||
      f.description(parameters.router)!=sem::dense({kExperts,kHidden}).transposed().value()||
      f.description(parameters.shared_gate)!=sem::dense({1,kHidden}).transposed().value()||
      f.description(parameters.map)!=sem::dense({kExperts},c::DataType::kInt32))
    throw std::runtime_error("original Q24 MoE needs the full original F32 router and shared gate");
  for(std::size_t leg=0;leg<3;++leg) {
    const auto n=leg==2?kHidden:kIntermediate,k=leg==2?kIntermediate:kHidden;
    const auto codec=leg==2?c::GgufQuantizedType::kQ6K:c::GgufQuantizedType::kQ5K;
    if(f.description(parameters.banks[leg])!=c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ4K,c::DataType::kFloat32,kSlots,n,k).value()||
        f.description(parameters.shared[leg])!=c::gguf_weight_description(codec,c::DataType::kFloat32,k,n).value())
      throw std::runtime_error("original Q24 MoE requires canonical original Q4_K experts and Q5/Q6 shared banks");
    if(std::none_of(f.inputs.begin(),f.inputs.end(),[&](Value value){return value.ordinal()==parameters.banks[leg].ordinal();}))
      throw std::runtime_error("compact Q24 experts must be ordinary runtime inputs");
  }
  if(std::none_of(f.inputs.begin(),f.inputs.end(),[&](Value value){return value.ordinal()==parameters.map.ordinal();}))
    throw std::runtime_error("Q24 resident mapping must be an ordinary runtime input");
  Ports ports;ports.input=input;ports.map=parameters.map;
  ports.logits=f.one(c::Operation(c::MatMul{}),{input,parameters.router});
  ports.probabilities=f.one(c::Operation(c::Softmax{}),{ports.logits});
  const auto top=f.append(c::Operation(c::TopK{.count=std::size_t(kSlots),.stable=true}),{ports.probabilities},2);
  ports.ids=top[1];ports.selected_scores=top[0];
  ports.sum=sum(f,ports.selected_scores,-1);
  // Exact fixed llama.cpp norm_w contract. No DeepSeek bias/epsilon/scale.
  ports.denominator=core::binary(f,c::BinaryKind::kMaximum,ports.sum,core::filled(f,sem::dense({1,1}),0x1p-14F));
  ports.weights=core::binary(f,c::BinaryKind::kDivide,ports.selected_scores,ports.denominator);
  const Boundary boundary{input,ports.ids,ports.weights,parameters.banks,parameters.map};
  ports.local_ids=f.one(c::Operation(c::Gather{}),{parameters.map,ports.ids});
  const auto grouped=[&](Value actual,std::size_t leg) {
    return f.one(c::model_ops::grouped_matmul(),{parameters.banks[leg],actual,ports.local_ids});
  };
  const auto slots=core::reshape(f,input,{1,1,kHidden});
  ports.routed.gate=grouped(slots,0);ports.routed.up=grouped(slots,1);
  ports.routed.activation=f.one(c::Operation(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate}),{ports.routed.gate,ports.routed.up});
  ports.routed.down=grouped(ports.routed.activation,2);
  // Qwen is not the Llama4 input-weighting branch: multiply actual down
  // outputs, then reduce selected slots, preserving F32 GGUF boundaries.
  ports.weighted=core::binary(f,c::BinaryKind::kMultiply,ports.routed.down,core::reshape(f,ports.weights,{1,kSlots,1}));
  ports.routed_sum=core::reshape(f,sum(f,ports.weighted,1),{1,kHidden});
  ports.shared.gate=f.one(c::Operation(c::MatMul{}),{input,parameters.shared[0]});
  ports.shared.up=f.one(c::Operation(c::MatMul{}),{input,parameters.shared[1]});
  ports.shared.activation=f.one(c::Operation(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate}),{ports.shared.gate,ports.shared.up});
  ports.shared.down=f.one(c::Operation(c::MatMul{}),{ports.shared.activation,parameters.shared[2]});
  ports.shared_gate_raw=f.one(c::Operation(c::MatMul{}),{input,parameters.shared_gate});
  ports.shared_gate_sigmoid=core::unary(f,c::UnaryKind::kSigmoid,ports.shared_gate_raw);
  ports.shared_gated=core::binary(f,c::BinaryKind::kMultiply,ports.shared.down,ports.shared_gate_sigmoid);
  ports.merged=core::binary(f,c::BinaryKind::kAdd,ports.routed_sum,ports.shared_gated);
  return {ports.merged,ports,boundary};
}
} // namespace qwen24_original_moe_fragment
