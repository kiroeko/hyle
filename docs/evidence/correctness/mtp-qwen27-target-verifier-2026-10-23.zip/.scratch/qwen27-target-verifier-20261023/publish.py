"""Publish actual finite BX Q27 target63/NextN K1 checks; root invokes only."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
TEXT = {'.h','.hh','.hpp','.cc','.cpp','.c','.py','.json','.txt','.log','.xml','.ps1','.diff','.rsp','.cmd','.md'}
OLD = {f'{b}{m}OriginalNextNAndVocabularyPublishesAndContinues' for b in ('Cpu','Cuda') for m in ('Q27','Q24')}
NEW = {f'{b}Q27OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix' for b in ('Cpu','Cuda')}
_seen = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R/path).resolve()


def identity(path):
    path = resolve(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path), bytes=path.stat().st_size, sha256=digest)


def verify(row):
    path = resolve(row['path'])
    if path not in _seen:
        _seen[path] = identity(path)
    assert (_seen[path]['bytes'],_seen[path]['sha256']) == (row['bytes'],row['sha256']), row['path']
    return path


def integer(props,key):
    value=int(props[key]);assert value>=0,(key,value)
    return value


def protect(before):
    verify(before['protected_qwen_image'])
    text=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    digest=hashlib.sha256(text[text.index('## 最新完整性能对比'):].encode()).hexdigest()
    assert digest==before['protected_performance_tail_sha256']
    return digest


def contracts(run, projection_values):
    assert run['process']['exit']==0 and not run['process']['timed_out']
    assert run['tests']==len(run['cases'])==6
    assert not any(run[k] for k in ('failures','errors','disabled','skips'))
    assert run['throughput_evidence'] is False and run['physical_memory_evidence'] is False and run['whole_original_model'] is False
    assert {c['attributes']['name'] for c in run['cases']}==OLD|NEW
    counts={}
    for case in run['cases']:
        a,p=case['attributes'],case['properties'];name=a['name']
        assert a['classname']=='QwenMtpStateConsumer' and a['status']=='run' and a['result']=='completed'
        counts[name]=integer(p,'actual_submissions');assert counts[name]>0
        provider='ggml-cuda' if name.startswith('Cuda') else 'ggml-cpu'
        if name in OLD:
            for key,value in dict(packed_head_m2_rows=2,packed_head_m2_matmuls=1,packed_head_m2_full_reference_values=496640,
                packed_head_m2_pending_feedback_rows=2,packed_head_m2_submissions=2,complete_draft_resources=6,original_native_reference_submissions=0).items():
                assert p[key]==str(value),(name,key,p.get(key))
            assert p['packed_head_m2_provider']==provider
        else:
            for key,value in dict(complete_target_draft_resources=12,original_target_roles=12,original_target_source_bytes=282318848,
                first_full_target_projection_values=projection_values,first_full_target_verifier_values=496640,
                first_full_nextn_head_values=248320,natural_k1_trials=1,controlled_matching_trials=1,controlled_rejection_trials=1).items():
                assert p[key]==str(value),(name,key,p.get(key))
            accepted0,accepted1=integer(p,'accepted_zero_drafts'),integer(p,'accepted_one_draft')
            repairs=integer(p,'accepted_target_conditioned_repairs')
            assert accepted0>0 and accepted1>0 and accepted0+accepted1==3 and repairs==accepted1
            natural=integer(p,'natural_accepted_drafts');assert natural in (0,1) and accepted1==1+natural
            assert integer(p,'natural_proposal')<248320
            assert integer(p,'target_verifier_submissions')==3
            assert integer(p,'actual_pending_embedding_feedback_checks')==integer(p,'nextn_submissions')
            assert counts[name]==sum(integer(p,k) for k in ('target_submissions','nextn_submissions','target_verifier_submissions'))
            assert integer(p,'peak_state_backing_bytes')<=integer(p,'state_budget_bytes')
            for role in ('attn_q.weight','attn_k.weight','attn_v.weight','attn_output.weight','ffn_gate.weight','ffn_up.weight','ffn_down.weight'):
                assert p['target_provider_blk.63.'+role]==provider
    return counts


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--link-attempt',type=int,default=2)
    parser.add_argument('--run',type=int,default=1)
    parser.add_argument('--freeze',default='source-final')
    args=parser.parse_args();assert args.link_attempt>0 and args.run>0 and Path(args.freeze).name==args.freeze
    before=read(S/'before.json')
    for row in before['previous_publication'].values(): verify(row)
    protected=protect(before)
    plan_path,receipt_path=S/'roles-plan.json',S/'original-target63/acquisition.json'
    plan,receipt=read(plan_path),read(receipt_path)
    assert receipt['complete'] and receipt['original_roles']==len(receipt['roles'])==len(plan['roles'])==12
    assert receipt['source_plan_sha256']==identity(plan_path)['sha256']
    assert receipt['role_payload_bytes']==receipt['successful_request_body_bytes']==plan['new_payload_bytes']==282318848
    assert not receipt['whole_shard_downloaded']
    assert (receipt['repository'],receipt['revision'])==(plan['repository'],plan['revision'])
    for row,wanted in zip(receipt['roles'],plan['roles'],strict=True):
        for key in ('name','file','dtype','dtype_code','gguf_shape_K_N','bytes','data_relative_half_open','absolute_inclusive'):
            assert row[key]==wanted[key]
        assert row['complete'] and row['payload']['bytes']==row['bytes']
        assert resolve(row['payload']['path']).stat().st_size==row['bytes'] and len(row['payload']['sha256'])==64
    projection_values=sum(row['gguf_shape_K_N'][1] for row in plan['roles'] if row['dtype']!='F32')
    freeze_path=S/args.freeze/'freeze.json';freeze=read(freeze_path)
    frozen={verify(row):row for row in freeze['source']}
    for row in freeze['source']:
        assert identity(row['snapshot'])['sha256']==row['sha256']
    verify(read(S/'pins.json')['after'])
    linkdir=S/f'tests-link{args.link_attempt}'
    image=read(linkdir/'ready.json')['image'];image_path=verify(image)
    link,runtime=read(linkdir/'link-plan.json'),read(linkdir/'runtime-environment.json')
    assert read(linkdir/'link.result.json')['exit']==0
    assert all(link[k]==0 for k in ('SDK_builds','native_CPU_builds','NVCC_builds','shaders'))
    host_path=verify(freeze['actual_host_compile']);host=read(host_path)
    assert host_path.is_relative_to(S) and verify(host['source']) in frozen
    assert read(host_path.with_name('compile.result.json'))['exit']==0
    assert any(resolve(row['path'])==host_path for row in link['compiled_records'])
    assert host['object'] in link['inputs']
    for row in (*link['inputs'],*runtime['staged_dlls']):
        assert resolve(row['path']).stat().st_size==row['bytes'] and len(row['sha256'])==64
    summary_path=S/f'checks{args.run}/summary.json';run=read(summary_path)
    assert run['image']==image and resolve(run['process']['command'][0])==image_path
    counts=contracts(run,projection_values)
    docs=[R/'docs/developer/current-work.md',R/'docs/implementation/model-operators.md',R/'docs/architecture/compute-design.md']
    files=set(frozen)|set(docs)|{verify(before['previous_publication']['evidence'])}
    files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in TEXT)
    files.discard(S/'publication.json')
    for path in files:
        assert path.resolve().is_relative_to(R) and path.suffix.lower() in TEXT and path.stat().st_size<10_000_000,path
    destination=D/'mtp-qwen27-target-verifier-2026-10-23.json';archive=destination.with_suffix('.zip')
    assert D.is_dir() and not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
        for path in sorted(files):zipped.write(path,path.relative_to(R).as_posix())
    record=dict(date='2026-10-23',stage='BX',goal_complete=False,
        conclusion='The listed original Q27 target63/globalnorm and NextN64 K1 finite consumers passed; actual fullV correction/bonus and repaired accepted prefixes use immutable Graph leases. Four related original Qwen consumers also passed.',
        artifact=dict(repository=plan['repository'],revision=plan['revision'],variant=plan['variant'],new_target_roles=12,new_target_bytes=282318848,
            plan=identity(plan_path),acquisition=identity(receipt_path),existing_original_NextN_and_vocabulary='Reuses previously acquired Q27 NextN64 roles and untied original Q4_K embedding/Q6_K fullVhead; no duplicate acquisition.',payloads_archived=False,extra_payload_hash_pass=False),
        implementation=dict(target='Original target63 Q/O/gateQ5_K, K/down/upQ6_K and VQ8_0; actual head-interleaved Q/G, learned F32 RMS/no+1, partialHalfSplitRoPE64/theta10M, finite KV/GQA/sigmoid gate, dense SwiGLU and distinct global output_norm. Shared pure attention extraction preserves existing NextN math.',
            verifier='Actual target taps after consume(current) and consume(proposal) form one F32M2 MatMul over the existing complete248320-row packed head. Actual I32 row IDs provide correction/bonus. Independent Top1/Top2 result leases control finite match/reject scenarios without host ID upload.',
            acceptance='Accept0 chooses after-current first checkpoint. This runner uses eager target-conditioned repair on accept1: rebuild proposal NextN KV/hidden from first checkpoint plus actual target-current tap, retain second target six members, stage actual row1 pending, then publish all12 resources once. Explicit-lag protocols remain valid with their complete lag state; merely replacing hidden does not repair speculative KV.',
            state='Existing Program/ordinary Graph/Invocation and StateStore/Head are reused. Next continuation seeds from actual accepted normalized target tap. Full KV/cursors/positions, actual pending, target raw/tap, readonly old results, cancellation/stale publication and whole-pool resource budgets are checked.',
            reference='Original-byte Q5/Q6/Q8 activation-codec certificates begin at actual predecessors; local F32/norm/RoPE/GQA/gated gates and exact KV/tail checks retain existing tolerances. First seven target projections and full M2 verifier rows are checked completely; no native reference batches or expanded F32 weight banks.'),
        validation=dict(tests=run['tests'],failures=run['failures'],errors=run['errors'],skips=run['skips'],graph_submissions=sum(counts.values()),graph_submissions_by_case=counts,
            actual_native_summary=identity(summary_path),image=image,process=run['process'],cases=run['cases'],source_freeze=identity(freeze_path),host_translation_units=1,
            host_compile_record=identity(host_path),host_compile_attempts=len(list(S.glob('compile*/qwen-state/plan.json'))),link_identity_cache=identity(linkdir/'link-plan.json'),runtime_identity_cache=identity(linkdir/'runtime-environment.json'),
            cache_scope='Current repository sources/dependencies and executable identity are authenticated. Reused native binaries retain recorded cache hashes with current extents, without another SDK body hash sweep.',SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
        limitations=['Layer62 inputs and finite initial target/draft histories remain explicit fixtures. This executes the original trained final target block and NextN, not the whole64-layer prompt-to-output model or task quality.',
            'One finite natural trial and controlled match/reject cases do not establish real workload acceptance rate. No TPS/loading speedup or physical RAM/VRAM peak is measured.',
            'The listed Windows CPU/CUDA cases do not sign all systems/codecs/shapes. Q24 actual target/verifier and other confirmed MTP work remain; broader goal is incomplete. Protected AV/Q35 performance identity remains unchanged.'],
        remaining='Complete remaining confirmed target/verifier/artifact wiring and necessary checks, then full ordinary/MTP performance comparison.',
        reused_publication=before['previous_publication'],source_review=identity(S/'review/runner-and-reference-independent.json'),
        protected_performance_tail_sha256=protected,protected_qwen_image=before['protected_qwen_image'],
        sources=[identity(path) for path in sorted(frozen)+docs],archive=identity(archive),archive_items=len(files))
    destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    publication=dict(evidence=identity(destination),archive=identity(archive))
    (S/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
    assert protect(before)==protected
    print(json.dumps(dict(**publication,tests=run['tests'],graphs=record['validation']['graph_submissions'])))


if __name__=='__main__':main()
