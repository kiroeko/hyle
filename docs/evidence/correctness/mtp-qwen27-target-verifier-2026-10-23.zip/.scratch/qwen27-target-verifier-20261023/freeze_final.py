"""Freeze actual BX/current cached host source identities; no native or payload IO.

Root runs only after the final qwen-state host compile has completed. Existing
BW cached provider dependencies are retained; current BX host dependencies
replace their previous source identities where actually recompiled.
"""
from pathlib import Path
import argparse
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
BASE = R / '.scratch/mtp-packed-head-m2-20261023/source-final/freeze.json'


def read(path):
    return Path(path).read_text(encoding='utf-8-sig')


def data(path):
    return json.loads(read(path))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def identity(path):
    path = resolve(path)
    assert path.stat().st_size < 10_000_000, path
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size, sha256=digest)


def verify(row):
    actual = identity(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
    return actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--output', default='source-final')
    args = parser.parse_args()
    assert args.compile_attempt > 0 and Path(args.output).name == args.output
    folder = S / f'compile{args.compile_attempt}/qwen-state'
    compiled_path = folder / 'identity.json'
    result = data(folder / 'compile.result.json')
    assert result['exit'] == 0 and result.get('terminal', True)
    assert not result.get('timed_out', False)
    compiled = data(compiled_path)
    assert resolve(compiled['source']['path']) == R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc'
    actual = {}
    for row in data(BASE)['source']:
        actual[resolve(row['path'])] = row
    for row in (compiled['source'], *compiled['dependencies']):
        path = resolve(row['path'])
        if any(path.is_relative_to(R / prefix) for prefix in ('src', 'include', 'tests')):
            actual[path] = row
    required = {R / 'tests/compute_models' / name for name in
                ('qwen27_original_target_roles.h', 'qwen_full_attention_fragment.h',
                 'qwen_mtp_state_consumer.h', 'qwen_mtp_state_consumer_test.cc')}
    assert required <= actual.keys()
    for row in data(S / 'attention-source/freeze.json')['files']:
        assert resolve(row['path']) in actual
        verify(row)
    pins = data(S / 'pins.json')
    assert pins['roles'] == 12 and pins['bytes'] == 282318848
    verify(pins['after'])
    entries = []
    # Validate the complete union before creating any snapshot.
    for path, row in sorted(actual.items()):
        current = verify(row)
        assert path.is_relative_to(R)
        entries.append(current)
    output = S / args.output
    assert not output.exists()
    output.mkdir()
    for row in entries:
        target = output / 'source' / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(resolve(row['path']).read_bytes())
        row['snapshot'] = target.relative_to(R).as_posix()
    record = dict(stage='BX', source=entries, base_source_freeze=identity(BASE),
        actual_host_compile=identity(compiled_path), target_pins=identity(S / 'pins.json'),
        scope='Current repository source inputs for the recompiled BX host and unchanged cached BW provider inputs. Original model payloads, external SDK sources and native binary bodies are excluded.',
        native_run=False, original_payload_bodies_read=False)
    (output / 'freeze.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print('Frozen BX', len(entries), 'actual source inputs; no payload/native work')


if __name__ == '__main__':
    main()
