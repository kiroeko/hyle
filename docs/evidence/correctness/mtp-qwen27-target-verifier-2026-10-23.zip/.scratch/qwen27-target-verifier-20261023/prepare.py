from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size, sha256=digest)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


assert not (S / 'before.json').exists()
source = []
for name in ('tests/compute_models/qwen_mtp_state_consumer.h',
             'tests/compute_models/qwen_mtp_state_consumer_test.cc'):
    path = R / name
    snapshot = S / 'before' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    source.append(dict(**identity(path), snapshot=snapshot.relative_to(R).as_posix()))
previous = json.loads((R / '.scratch/mtp-packed-head-m2-20261023/publication.json').read_text())
text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
save(S / 'before.json', dict(stage='BX', utc=datetime.now(timezone.utc).isoformat(),
    previous_goal_turn_classification='progress: BW provider-owned cold packed small-batch capability and original Q27/Q24 M2 passed7cases38Graphs; source/evidence/current-work published.',
    source=source, previous_publication=previous,
    protected_performance_tail_sha256=hashlib.sha256(tail.encode()).hexdigest(),
    protected_qwen_image=identity(R / '.scratch/qwen-mtp-next-20261022/hyle-link4/qwen.exe')))
save(S / 'progress.json', dict(stage='BX', stage_complete=False, goal_complete=False,
    state='Connecting original Q27 target63, independent target norm and shared fullV K1 verifier through the existing ordinary Graph/state lifecycle.',
    new_TPS=False, native_checks_run=False,
    original_target_roles=12, original_target_bytes=282318848,
    scope='Actual Q27 last-target block, existing original complete NextN and shared packed vocabulary; layer62 inputs and initial history are explicit external boundaries.',
    next='Acquire only missing12 original target roles, share pure attention construction, execute target/draft/fullV verifier and publish complete accepted continuation.'))
print('Prepared BX actual current-source baseline; prior goal turn classified as progress')
