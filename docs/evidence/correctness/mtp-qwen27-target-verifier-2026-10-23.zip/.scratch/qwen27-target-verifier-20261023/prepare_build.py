from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[1]
source = (R / '.scratch/q24-original-nextn-20261023/build.py').read_text(encoding='utf-8-sig')
source = source.replace('Incremental original Q24 NextN/full512 Top10 consumer and related Qwen state regressions.',
    'Incremental original Q27 target/NextN K1 verifier and affected Qwen consumers.')
source = source.replace("BH = R / '.scratch/mtp-next-original-20261023'", "BH = R / '.scratch/mtp-packed-head-m2-20261023'")
source = source.replace("R / '.scratch/mtp-next-original-20261023/compile1/qwen-state/identity.json'",
    "R / '.scratch/mtp-packed-head-m2-20261023/compile1/qwen-state/identity.json'")
source = source.replace('qwen24-original-nextn-checks.exe', 'qwen27-target-verifier-checks.exe')
source = source.replace("str(S / 'original-q24-nextn')", "str(R / '.scratch/q24-original-nextn-20261023/original-q24-nextn')")
marker = "    env['HYLE_QWEN27_MTP_INPUT_DIR'] ="
assert source.count(marker) == 1
source = source.replace(marker,
    "    env['HYLE_QWEN27_TARGET_DIR'] = str(S / 'original-target63')\n" + marker)
source = source.replace("print('LINKED original Q24 and related Qwen state consumers'",
    "print('LINKED original Q27 target/NextN and related consumers'")
source = source.replace("print('PASS original Q24 and related Qwen state consumers'",
    "print('PASS original Q27 target/NextN K1 and related consumers'")
(S / 'build.py').write_text(source, encoding='utf-8', newline='\n')
print('Prepared one-host-TU build against the actual BW native/provider cache; no SDK rebuild')
