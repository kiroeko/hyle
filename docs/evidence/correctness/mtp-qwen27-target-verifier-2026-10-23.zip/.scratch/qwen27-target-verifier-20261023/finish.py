"""Verify actual BX publication; broader MTP goal remains incomplete."""
from datetime import datetime,timezone
from pathlib import Path
import json
import sys
import zipfile
sys.dont_write_bytecode=True
import publish as p
publication=p.read(p.S/'publication.json')
for row in publication.values():p.verify(row)
evidence=p.read(p.verify(publication['evidence']));v=evidence['validation']
assert evidence['stage']=='BX' and evidence['goal_complete'] is False and v['tests']==6
assert not any(v[k] for k in ('failures','errors','skips','SDK_builds','native_CPU_builds','NVCC_builds','shaders'))
run=p.read(p.verify(v['actual_native_summary']));assert run['image']==v['image'] and run['cases']==v['cases']
p.verify(run['image']);assert p.resolve(run['process']['command'][0])==p.resolve(run['image']['path'])
plan=p.read(p.verify(evidence['artifact']['plan']))
projection_values=sum(row['gguf_shape_K_N'][1] for row in plan['roles'] if row['dtype']!='F32')
counts=p.contracts(run,projection_values);assert counts==v['graph_submissions_by_case'] and sum(counts.values())==v['graph_submissions']
assert evidence['artifact']['new_target_roles']==12 and evidence['artifact']['new_target_bytes']==282318848
assert evidence['artifact']['payloads_archived'] is False and evidence['artifact']['extra_payload_hash_pass'] is False
with zipfile.ZipFile(p.verify(publication['archive'])) as archive:
    assert archive.testzip() is None and len(archive.namelist())==evidence['archive_items']
    assert all(Path(i.filename).suffix.lower() in p.TEXT and i.file_size<10_000_000 for i in archive.infolist())
p.protect(p.read(p.S/'before.json'))
progress=dict(utc=datetime.now(timezone.utc).isoformat(),stage='BX',stage_complete=True,goal_complete=False,
    state='The listed original Q27 target63/NextN K1 corrected-prefix consumers and four related original Qwen regressions passed; actual evidence published.',
    tests=6,graph_submissions=v['graph_submissions'],actual_graph_submissions_by_case=counts,failures=0,skips=0,native_checks_run=True,
    publication=publication,new_TPS=False,physical_memory_peak=False,protected_AV_tail_unchanged=True,protected_Q35_image_unchanged=True,
    scope='Original final target63/globalnorm, NextN64 and existing fullV banks; actual target taps/fullM2 verifier and eager accepted-proposal repair before12-member publication. Layer62 input and initial histories remain fixtures, not a whole64-layer model/quality or workload acceptance-rate result.',
    next='Continue confirmed Q24/other target-verifier/artifact gaps and necessary checks, then final ordinary/MTP performance comparison.')
(p.S/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PUBLISHED BX',v['tests'],'cases',v['graph_submissions'],'Graphs; broader MTP remains incomplete')
