"""Incremental original Q27 target/NextN K1 verifier and affected Qwen consumers."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BH = R / '.scratch/mtp-packed-head-m2-20261023'
spec = importlib.util.spec_from_file_location('bl_cached', BH / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = BH / 'tests-link1'
RECIPES = {
    'qwen-state': R / '.scratch/mtp-packed-head-m2-20261023/compile1/qwen-state/identity.json',
}
SOURCES = {
    'qwen-state': R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc',
}


def host(tag, attempt):
    h.RECIPES[tag] = RECIPES[tag]
    h.SOURCES[tag] = SOURCES[tag]
    h.compile_one(tag, attempt)


def latest(tag):
    paths = sorted(S.glob(f'compile*/{tag}/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    assert paths, tag
    path = paths[-1]
    record = c.read(path)
    assert all(b.identity(x['path']) == x for x in (record['source'], record['object'], *record['dependencies']))
    return path, record


def link(attempt, tags):
    base_path = BASE / 'link-plan.json'
    base = c.read(base_path)
    remove, records = set(), []
    for row in base['compiled_records']:
        rec = c.read(row['path'])
        if '/tests/' in rec['source']['path'].replace('\\', '/'):
            remove.add(c.key(rec['object']['path']))
        else:
            records.append(row)
    added = [latest(tag) for tag in tags]
    inputs = [rec['object'] for _, rec in added] + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [rec['object']['path'] for _, rec in added]
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'qwen27-target-verifier-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(p) for p, _ in added] + records,
        base=b.identity(base_path), SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image)))
    print('LINKED original Q27 target/NextN and related consumers', flush=True)


def run(link_attempt, attempt, test_filter, expected):
    spec_run = importlib.util.spec_from_file_location('bi_run', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    q = importlib.util.module_from_spec(spec_run)
    spec_run.loader.exec_module(q)
    folder = S / f'tests-link{link_attempt}'
    image = c.read(folder / 'ready.json')['image']
    assert b.identity(image['path']) == image
    env = os.environ.copy()
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    env['HYLE_QWEN27_ORIGINAL_TARGET_DIR'] = str(S / 'original-target63')
    env['HYLE_QWEN27_MTP_INPUT_DIR'] = str(R / '.scratch/qwen-original-mtp-20261022/original-q27')
    env['HYLE_QWEN24_MTP_KV_DIR'] = str(R / '.scratch/qwen24-original-mtp-20261022/original-q24')
    env['HYLE_QWEN27_ORIGINAL_NEXTN_DIR'] = str(R / '.scratch/mtp-next-original-20261023/original-q27-nextn')
    env['HYLE_QWEN24_ORIGINAL_NEXTN_DIR'] = str(R / '.scratch/q24-original-nextn-20261023/original-q24-nextn')
    env['HYLE_DSPARK_TARGET_ROLES_DIR'] = str(R / '.scratch/glm-mtp-catchup-20261022/original-dspark-target')
    env['HYLE_DSPARK_HISTORY_ROLES_DIR'] = str(R / '.scratch/glm-mtp-seed-cache-20261022/original-dspark-history')
    env['HYLE_DSPARK_MARKOV_DIR'] = str(R / '.scratch/dspark-mtp-integration-20261022/original-markov')
    env['HYLE_DSPARK_CONFIDENCE_BF16'] = str(R / '.scratch/qwen-mtp-next-20261022/original-confidence/conf_proj.weight.bf16')
    env['HYLE_DSPARK_SHARED_VOCAB_DIR'] = str(R / '.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary')
    env['HYLE_DSPARK_PARAMETER_ROLES_DIR'] = str(R / '.scratch/dspark-original-hc-20261023/original-parameters')
    env['HYLE_DSPARK_SHARED_FFN_DIR'] = str(R / '.scratch/dspark-original-shared-20261023/original-shared')
    env['HYLE_DSPARK_ATTENTION_ROLES_DIR'] = str(R / '.scratch/dspark-original-attention-20261023/original-attention')
    env['HYLE_DSPARK_EXPERT_ROLES_DIR'] = str(R / '.scratch/dspark-original-experts-20261023/original-experts')
    temporary = S / 'runtime-tmp'
    temporary.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temporary)
    out = S / f'checks{attempt}'
    xml = out / 'results.xml'
    process = q.execute([image['path'], '--gtest_filter=' + test_filter, '--gtest_output=xml:' + str(xml)],
        env, out, timeout=900)
    result = dict(process=process, image=image, throughput_evidence=False,
                  physical_memory_evidence=False, whole_original_model=False)
    if xml.is_file():
        tree = ET.parse(xml).getroot()
        result.update(tests=int(tree.attrib['tests']), failures=int(tree.attrib['failures']),
            errors=int(tree.attrib['errors']), disabled=int(tree.attrib['disabled']),
            skips=sum(case.find('skipped') is not None for case in tree.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']:p.attrib['value']
                for p in case.iter('property')}) for case in tree.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == expected and not any(result[k] for k in ('failures','errors','disabled','skips')), result
    print('PASS original Q27 target/NextN K1 and related consumers', expected, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('actions', nargs='+', choices=[*SOURCES, 'link', 'run'])
    p.add_argument('--attempt', type=int, default=1)
    p.add_argument('--link-attempt', type=int, default=1)
    p.add_argument('--only', nargs='+', choices=list(SOURCES), default=list(SOURCES))
    p.add_argument('--filter', default='*')
    p.add_argument('--expected-tests', type=int, default=1)
    args = p.parse_args()
    for action in args.actions:
        if action == 'link': link(args.attempt, args.only)
        elif action == 'run': run(args.link_attempt, args.attempt, args.filter, args.expected_tests)
        else: host(action, args.attempt)
