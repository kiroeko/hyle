#pragma once

#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <stdexcept>
#include <vector>

#include "d5_moe_semantic_fragments.h"

// Pure Qwen full-attention math shared by target and NextN consumers. The
// caller owns immutable parameter Values, actual KV state and execution.
// Codecs come from those actual tensor descriptions, never a model switch.
namespace qwen_full_attention_fragment {
namespace c=hyle::compute;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace core=d5_moe_semantic_fragments;
using Value=sem::ValueId;
struct Geometry final {
  std::int64_t hidden,heads,kv_heads,depth,rotary;
  float epsilon=1.0e-6F;
  float scale=0.0F; // Metadata zero means the ordinary 1/sqrt(head depth).
};
inline void require_geometry(const Geometry &geometry) {
  constexpr auto limit=std::numeric_limits<std::int64_t>::max();
  if(geometry.hidden<=0||geometry.heads<=0||geometry.kv_heads<=0||geometry.depth<=0||
      geometry.heads%geometry.kv_heads||geometry.heads>limit/geometry.depth/2||
      geometry.kv_heads>limit/geometry.depth||geometry.rotary<=0||
      geometry.rotary>geometry.depth||geometry.rotary%2||
      !std::isfinite(geometry.epsilon)||geometry.epsilon<=0||
      !std::isfinite(geometry.scale)||geometry.scale<0)
    throw std::runtime_error("invalid Qwen full-attention geometry");
}
inline void require(sem::Fragment &fragment,Value value,const c::TensorDesc &description) {
  if(value.ordinal()>=fragment.descriptions.size()||fragment.description(value)!=description)
    throw std::runtime_error("Qwen full-attention actual operand description differs");
}
inline Value slice(sem::Fragment &fragment,Value input,std::int32_t axis,
                   std::int64_t first,std::int64_t count) {
  return fragment.one(c::Operation(c::View::slice(axis,first,count).value()),{input});
}
inline std::vector<float> text_frequencies(std::int64_t rotary,float theta) {
  if(rotary<=0||rotary%2||!std::isfinite(theta)||theta<=0)
    throw std::runtime_error("invalid Qwen text rotary metadata");
  std::vector<float> result(std::size_t(rotary/2));
  for(std::size_t pair=0;pair<result.size();++pair)
    result[pair]=1.F/std::pow(theta,float(pair)/float(rotary/2));
  return result;
}
struct Projected final {Value query,gate,key,value;};
inline Projected append_qkv(sem::Fragment &fragment,Value qg,Value key,Value value,
    Value query_scale,Value key_scale,Value position,Value frequency,const Geometry &geometry) {
  require_geometry(geometry);
  require(fragment,qg,sem::dense({1,2*geometry.heads*geometry.depth}));
  require(fragment,key,sem::dense({1,geometry.kv_heads*geometry.depth}));
  require(fragment,value,sem::dense({1,geometry.kv_heads*geometry.depth}));
  require(fragment,query_scale,sem::dense({geometry.depth}));
  require(fragment,key_scale,sem::dense({geometry.depth}));
  require(fragment,position,sem::dense({1},c::DataType::kInt32));
  require(fragment,frequency,sem::dense({geometry.rotary/2}));
  const auto qg_heads=core::reshape(fragment,qg,{1,1,geometry.heads,2*geometry.depth});
  const auto query=fragment.one(c::Operation(c::RmsNorm{.epsilon=geometry.epsilon}),
      {slice(fragment,qg_heads,3,0,geometry.depth),query_scale});
  const auto current_key=fragment.one(c::Operation(c::RmsNorm{.epsilon=geometry.epsilon}),
      {core::reshape(fragment,key,{1,1,geometry.kv_heads,geometry.depth}),key_scale});
  const c::Operation rope(c::RoPE{.rotary_dimensions=std::size_t(geometry.rotary),
      .sequence_axis=1,.layout=c::RopeLayout::kHalfSplit});
  return {fragment.one(rope,{query,position,frequency}),
      slice(fragment,qg_heads,3,geometry.depth,geometry.depth),
      fragment.one(rope,{current_key,position,frequency}),
      core::reshape(fragment,value,{1,1,geometry.kv_heads,geometry.depth})};
}
struct Cache final {Value key,value;};
inline std::int64_t cache_capacity(sem::Fragment &fragment,const Cache &cache,const Geometry &geometry) {
  require_geometry(geometry);
  if(cache.key.ordinal()>=fragment.descriptions.size())throw std::runtime_error("Qwen KV cache value is outside this Fragment");
  const auto &description=fragment.description(cache.key);
  if(description.rank()!=3||description.dimensions()[0]<=0)
    throw std::runtime_error("Qwen full-attention needs a positive finite KV cache");
  const auto capacity=description.dimensions()[0];
  const auto expected=sem::dense({capacity,geometry.kv_heads,geometry.depth});
  require(fragment,cache.key,expected);require(fragment,cache.value,expected);
  return capacity;
}
inline Cache append_update(sem::Fragment &fragment,const Projected &projected,
    const Cache &old,Value cursor,const Geometry &geometry) {
  (void)cache_capacity(fragment,old,geometry);
  require(fragment,cursor,sem::dense({1},c::DataType::kInt32));
  return {fragment.one(c::Operation(c::Scatter{}),{old.key,cursor,
              core::reshape(fragment,projected.key,{1,geometry.kv_heads,geometry.depth})}),
      fragment.one(c::Operation(c::Scatter{}),{old.value,cursor,
              core::reshape(fragment,projected.value,{1,geometry.kv_heads,geometry.depth})})};
}
struct History final {Value keys,values,mask;};
inline History append_finite_history(sem::Fragment &fragment,const Cache &cache,
    Value cursor,const Geometry &geometry) {
  const auto capacity=cache_capacity(fragment,cache,geometry);
  require(fragment,cursor,sem::dense({1},c::DataType::kInt32));
  // This small finite-window policy belongs to these test consumers. It is
  // not a production cache allocator. Absolute position remains independent.
  constexpr auto limit=std::int64_t{(std::numeric_limits<std::int32_t>::max()-1024)/sizeof(float)};
  if(capacity>limit/capacity)throw std::runtime_error("finite Qwen history metadata is too large");
  std::vector<std::int32_t> mapping(std::size_t(capacity*capacity));
  std::vector<float> masks(mapping.size());
  for(std::int64_t index=0;index<capacity;++index)for(std::int64_t row=0;row<capacity;++row) {
    const auto offset=std::size_t(index*capacity+row);
    mapping[offset]=std::int32_t(row<=index?row:0);
    masks[offset]=row<=index?0.F:-std::numeric_limits<float>::infinity();
  }
  const auto row_table=fragment.constant(sem::dense({capacity,capacity},c::DataType::kInt32),sem::bytes(mapping));
  const auto mask_table=fragment.constant(sem::dense({capacity,capacity}),sem::bytes(masks));
  const auto rows=fragment.one(c::Operation(c::Gather{}),{row_table,cursor});
  const auto mask=core::reshape(fragment,fragment.one(c::Operation(c::Gather{}),{mask_table,cursor}),{1,1,1,capacity});
  // First gather only valid real rows. Repeating row0 for masked padding
  // prevents a poisoned unwritten KV tail from entering attention operands.
  return {fragment.one(c::Operation(c::Gather{}),{cache.key,rows}),
      fragment.one(c::Operation(c::Gather{}),{cache.value,rows}),mask};
}
inline Value append_attention(sem::Fragment &fragment,const Projected &projected,
    Value keys,Value values,const Geometry &geometry,std::optional<Value> additive_mask={}) {
  require_geometry(geometry);
  const float scale=geometry.scale==0?1.F/std::sqrt(float(geometry.depth)):geometry.scale;
  const c::Operation attention(c::ScaledDotProductAttention{
      .layout=c::AttentionLayout::kBatchSequenceHeadDepth,
      .mask=additive_mask?c::MaskKind::kAdditive:c::MaskKind::kNone,
      .scale=scale,.causal=!additive_mask,.accumulation_type=c::DataType::kFloat32});
  const auto context=additive_mask?fragment.one(attention,{projected.query,keys,values,*additive_mask}):
      fragment.one(attention,{projected.query,keys,values});
  return core::binary(fragment,c::BinaryKind::kMultiply,context,
      core::unary(fragment,c::UnaryKind::kSigmoid,projected.gate));
}

struct TargetParameters final {
  Value input_norm,query,key,value,query_norm,key_norm,output;
  Value post_norm,ffn_gate,ffn_up,ffn_down,target_norm;
};
struct TargetPorts final {
  Value input,nx,qg,key,value,query,gate,rotated_key,attended,oproj,residual;
  Value ffn_input,ffn_gate,ffn_up,ffn_activation,ffn_down,post_ffn,tap;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *port:{&input,&nx,&qg,&key,&value,&query,&gate,&rotated_key,&attended,&oproj,&residual,
        &ffn_input,&ffn_gate,&ffn_up,&ffn_activation,&ffn_down,&post_ffn,&tap})visitor(*port);
  }
};
struct TargetResult final {
  Value key,value,raw_post_ffn,normalized_tap;
  TargetPorts ports;
};
inline TargetResult append_target(sem::Fragment &fragment,Value input,Value old_key,Value old_value,
    Value cursor,Value position,Value frequency,const TargetParameters &parameters,const Geometry &geometry) {
  require_geometry(geometry);require(fragment,input,sem::dense({1,geometry.hidden}));
  const auto norm=[&](Value actual,Value gamma,std::int64_t width) {
    require(fragment,gamma,sem::dense({width}));
    return fragment.one(c::Operation(c::RmsNorm{.epsilon=geometry.epsilon}),{actual,gamma});
  };
  const auto linear=[&](Value actual,Value weight) {
    // Public inference checks actual logical dimensions and storage codec.
    // No packed-format or target-model whitelist belongs in this builder.
    return fragment.one(c::Operation(c::MatMul{.accumulation_type=c::DataType::kFloat32}),{actual,weight});
  };
  TargetResult result;auto &ports=result.ports;ports.input=input;
  ports.nx=norm(input,parameters.input_norm,geometry.hidden);
  ports.qg=linear(ports.nx,parameters.query);ports.key=linear(ports.nx,parameters.key);ports.value=linear(ports.nx,parameters.value);
  const auto projected=append_qkv(fragment,ports.qg,ports.key,ports.value,parameters.query_norm,
      parameters.key_norm,position,frequency,geometry);
  ports.query=projected.query;ports.gate=projected.gate;ports.rotated_key=projected.key;
  const auto cache=append_update(fragment,projected,{old_key,old_value},cursor,geometry);
  result.key=cache.key;result.value=cache.value;
  const auto history=append_finite_history(fragment,cache,cursor,geometry);
  ports.attended=append_attention(fragment,projected,history.keys,history.values,geometry,history.mask);
  ports.oproj=linear(core::reshape(fragment,ports.attended,{1,geometry.heads*geometry.depth}),parameters.output);
  require(fragment,ports.oproj,sem::dense({1,geometry.hidden}));
  ports.residual=core::binary(fragment,c::BinaryKind::kAdd,input,ports.oproj);
  ports.ffn_input=norm(ports.residual,parameters.post_norm,geometry.hidden);
  ports.ffn_gate=linear(ports.ffn_input,parameters.ffn_gate);ports.ffn_up=linear(ports.ffn_input,parameters.ffn_up);
  ports.ffn_activation=fragment.one(c::Operation(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate}),{ports.ffn_gate,ports.ffn_up});
  ports.ffn_down=linear(ports.ffn_activation,parameters.ffn_down);
  require(fragment,ports.ffn_down,sem::dense({1,geometry.hidden}));
  ports.post_ffn=core::binary(fragment,c::BinaryKind::kAdd,ports.residual,ports.ffn_down);
  // Actual Qwen target graph publishes t_h_nextn AFTER global output_norm and
  // before output cropping. NextN applies its own distinct hnorm to this tap.
  ports.tap=norm(ports.post_ffn,parameters.target_norm,geometry.hidden);
  result.raw_post_ffn=ports.post_ffn;result.normalized_tap=ports.tap;return result;
}
} // namespace qwen_full_attention_fragment
