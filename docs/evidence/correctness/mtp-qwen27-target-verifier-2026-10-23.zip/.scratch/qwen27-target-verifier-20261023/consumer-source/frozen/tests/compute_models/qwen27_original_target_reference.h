#pragma once

#include <gtest/gtest.h>

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

#include "qwen27_original_target_roles.h"
#include "qwen24_original_nextn_reference.h"
#include "qwen_full_attention_fragment.h"
#include "cpu_c5_qwen_attention.h"

// Local original-byte equations. Every projection/nonlinearity begins with
// the actual observed predecessor; an ideal dot never crosses another packed
// projection or a norm. No execution, expanded weight bank or new tolerance.
namespace qwen27_original_target_reference {
namespace roles=qwen27_original_target_roles;
namespace model=qwen_full_attention_fragment;
namespace packed=qwen24_original_nextn_reference;
namespace numeric=d5_qwen35_gguf_fragment;
namespace sem=d5_qwen38_24t_semantic_fragments;
using ActivationCodec=packed::ActivationCodec;

inline void expect_bits(std::span<const float> actual,std::span<const float> expected,const char *label) {
  ASSERT_EQ(actual.size(),expected.size())<<label;
  for(std::size_t index=0;index<actual.size();++index)
    EXPECT_EQ(std::bit_cast<std::uint32_t>(actual[index]),std::bit_cast<std::uint32_t>(expected[index]))<<label<<'['<<index<<']';
}

// actual(Value) returns that Graph value's observed F32 vector. The caller
// supplies the existing finite-history GQA oracle, not another native route.
template<class ReadValue,class AttentionReference>
void observe(const roles::Data &data,const model::TargetResult &result,ReadValue &&actual,
    std::span<const float> old_key,std::span<const float> old_value,
    std::int32_t cursor,std::int32_t position,ActivationCodec codec,bool full,
    AttentionReference &&attention_reference,std::size_t &full_projection_values) {
  const auto &ports=result.ports;
  ASSERT_GE(cursor,0);ASSERT_GE(position,0);
  ASSERT_EQ(old_key.size(),old_value.size());ASSERT_EQ(old_key.size()%1024,0u);
  ASSERT_LT(std::size_t(cursor),old_key.size()/1024);
  const auto projection=[&](roles::Role role,std::span<const float> output,std::span<const float> input) {
    const auto &spec=roles::spec(role);
    const auto passed=packed::expect_projection(output,data.bytes(role),std::size_t(spec.n),std::size_t(spec.k),
        spec.native,input,codec,std::string(spec.name).c_str(),full);
    if(passed&&full)full_projection_values+=output.size();return passed;
  };
  const auto input=actual(ports.input),normalized=actual(ports.nx);
  numeric::expect_close(normalized,sem::oracle::rms_norm_rows(input,data.norm(roles::Role::kAttentionNorm),roles::kHidden,roles::kEpsilon),3e-5F,2e-5F);
  const auto qg=actual(ports.qg),key=actual(ports.key),value=actual(ports.value);
  ASSERT_TRUE(projection(roles::Role::kQuery,qg,normalized));
  ASSERT_TRUE(projection(roles::Role::kKey,key,normalized));
  ASSERT_TRUE(projection(roles::Role::kValue,value,normalized));
  ASSERT_EQ(qg.size(),std::size_t(2*roles::kHeads*roles::kDepth));
  std::vector<float> query(std::size_t(roles::kHeads*roles::kDepth)),gate(query.size());
  for(std::int64_t head=0;head<roles::kHeads;++head)for(std::int64_t column=0;column<roles::kDepth;++column) {
    const auto target=std::size_t(head*roles::kDepth+column),source=std::size_t(head*2*roles::kDepth+column);
    query[target]=qg[source];gate[target]=qg[source+std::size_t(roles::kDepth)];
  }
  expect_bits(actual(ports.gate),gate,"target actual query gate split");
  query=sem::oracle::rms_norm_rows(query,data.norm(roles::Role::kQueryNorm),roles::kDepth,roles::kEpsilon);
  numeric::expect_close(actual(ports.query),cpu_c5_qwen_attention::rotate(query,position),8e-5F,4e-5F);
  const auto normalized_key=sem::oracle::rms_norm_rows(key,data.norm(roles::Role::kKeyNorm),roles::kDepth,roles::kEpsilon);
  numeric::expect_close(actual(ports.rotated_key),cpu_c5_qwen_attention::rotate(normalized_key,position),8e-5F,4e-5F);
  auto expected_key=std::vector<float>(old_key.begin(),old_key.end());
  auto expected_value=std::vector<float>(old_value.begin(),old_value.end());
  const auto fresh_key=actual(ports.rotated_key);
  ASSERT_EQ(fresh_key.size(),1024u);ASSERT_EQ(value.size(),1024u);
  std::copy(fresh_key.begin(),fresh_key.end(),expected_key.begin()+std::ptrdiff_t(std::size_t(cursor)*1024));
  std::copy(value.begin(),value.end(),expected_value.begin()+std::ptrdiff_t(std::size_t(cursor)*1024));
  const auto next_key=actual(result.key),next_value=actual(result.value);
  expect_bits(next_key,expected_key,"target complete K prefix and poisoned future");
  expect_bits(next_value,expected_value,"target complete V prefix and poisoned future");
  const auto attended=actual(ports.attended);
  numeric::expect_close(attended,attention_reference(actual(ports.query),next_key,next_value,gate,cursor+1),8e-5F,4e-5F);
  const auto output=actual(ports.oproj);ASSERT_TRUE(projection(roles::Role::kOutput,output,attended));
  auto residual=input;ASSERT_EQ(output.size(),residual.size());
  for(std::size_t index=0;index<residual.size();++index)residual[index]+=output[index];
  numeric::expect_close(actual(ports.residual),residual,1e-6F,1e-6F);
  const auto ffn_input=actual(ports.ffn_input);
  numeric::expect_close(ffn_input,sem::oracle::rms_norm_rows(actual(ports.residual),data.norm(roles::Role::kPostNorm),roles::kHidden,roles::kEpsilon),3e-5F,2e-5F);
  const auto ffn_gate=actual(ports.ffn_gate),ffn_up=actual(ports.ffn_up),activation=actual(ports.ffn_activation);
  ASSERT_TRUE(projection(roles::Role::kFfnGate,ffn_gate,ffn_input));ASSERT_TRUE(projection(roles::Role::kFfnUp,ffn_up,ffn_input));
  std::vector<float> gated(ffn_gate.size());ASSERT_EQ(ffn_gate.size(),ffn_up.size());
  for(std::size_t index=0;index<gated.size();++index)
    gated[index]=float(double(ffn_gate[index])/(1+std::exp(-double(ffn_gate[index])))*ffn_up[index]);
  numeric::expect_close(activation,gated,8e-5F,4e-5F);
  const auto down=actual(ports.ffn_down);ASSERT_TRUE(projection(roles::Role::kFfnDown,down,activation));
  auto post=actual(ports.residual);ASSERT_EQ(post.size(),down.size());
  for(std::size_t index=0;index<post.size();++index)post[index]+=down[index];
  numeric::expect_close(actual(ports.post_ffn),post,1e-6F,1e-6F);
  expect_bits(actual(result.raw_post_ffn),actual(ports.post_ffn),"target raw post-FFN tap");
  // qwen35.cpp210-213: target h_nextn is AFTER global output_norm. This
  // independent gamma is not NextN64.shared_head_norm or NextN64.hnorm.
  numeric::expect_close(actual(ports.tap),sem::oracle::rms_norm_rows(actual(ports.post_ffn),
      data.norm(roles::Role::kTargetNorm),roles::kHidden,roles::kEpsilon),3e-5F,2e-5F);
  expect_bits(actual(result.normalized_tap),actual(ports.tap),"target normalized h_nextn tap");
}
} // namespace qwen27_original_target_reference
