import copy
import difflib
import hashlib
import json
from pathlib import Path

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
TARGET = ROOT / 'docs/implementation/model-quantizations.json'
CORRECTNESS = 'docs/evidence/correctness/quark-mxfp4-reference-2026-10-20.json'
RESEARCH = 'docs/evidence/research/quark-mxfp4-contract-2026-10-20.json'
EXPECTED = {
    16: 'amd/Qwen3.8-2.4T-A95B-Quark-MXFP4',
    23: 'amd/Kimi-K3-Quark-MXFP4-AttnFP8',
    30: 'amd/GLM-5.3-Flash-Quark-MXFP4',
}


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


before_raw = TARGET.read_bytes()
before_path = STAGE / 'before/model-quantizations.json'
before_path.parent.mkdir(parents=True, exist_ok=True)
assert not before_path.exists(), 'Retain the existing before snapshot; do not rerun this mutation'
before_path.write_bytes(before_raw)
before = json.loads(before_raw)
after = copy.deepcopy(before)

primitive_contract = {
    'descriptors': ['model_ops::Mxfp4Linear', 'model_ops::GroupedMxfp4Linear'],
    'factories': ['model_ops::mxfp4_linear()', 'model_ops::grouped_mxfp4_linear()'],
    'dense_ports': 'BF16 A[M,K], U8 W[N,K/2], U8 E8M0 SF[N,K/32] -> BF16[M,N]; positive dimensions and whole groups32',
    'grouped_ports': 'BF16 A[T,1-or-S,K], U8 W[E,N,K/2], U8 SF[E,N,K/32], I32 IDs[T,S] -> BF16[T,S,N]; genuine zero-slot-stride A with contiguous K and aligned nonoverlapping token rows also supported; other ports dense',
    'numerics': 'Portable BF16 group32 even-scale A QDQ: r=(absmax_BF16_bits+0x20)&0x7f80, zero selects exponent-127, finite-to-Inf carry selects127, otherwise unbiased exponent minus2 clamped[-127,127]. BF16 division, saturated nearest-even E2M1 preserving sign, BF16 reconstruction. W=BF16(E2M1(code)*2^(SF-127)), code8=-0. BF16 operands precede backend F32 reduction and BF16 output.',
    'checked_domain': 'All source A finite, including subnormal and signed zero; accessed SF0..254 accepted (SF0=2^-127), SF255 fails Completion. Grouped validates all IDs before selected expert addressing and checks only selected expert scales. Legal finite-input arithmetic overflow retains IEEE Inf/NaN; failed output unusable, no all-output rollback promised.',
    'sharing': 'Shared A1 or genuine zero-slot-stride A quantizes once per token; independent slots quantize once each, retaining duplicate IDs and output slots. No implicit input globals or activation expansion.',
    'scope': 'Software numerical primitive, with bounded packed W decoding; not hardware native MXFP4 GEMM or all-domain equality to optional Triton/upstream undefined extreme behavior',
}

backends = [
    {
        'provider': 'CPU native',
        'operation': 'Mxfp4Linear / GroupedMxfp4Linear through original prepared operation and Graph routes',
        'execution': 'Existing NativePlan mapping, parallel traversal and Completion; group32 W stack tile, BF16 activation QDQ workspace and F32 dot. No full decoded N*K or E*N*K floating bank.',
        'explicit_storage': 'Caller activation workspace2*quant_rows*K bytes; quant_rows=M for dense, T for shared grouped A and T*S for independent slots; original packed bank remains a dense input span',
        'qualification': 'Windows CPU12 package cases passed with0skip, including new primitive cases and existing ModelOpt/Local neighbors; no current Linux CPU execution claimed by this package',
        'code': ['src/compute_provider_native/nvfp4.cc', 'src/compute_provider_native/native_provider.cc'],
        'evidence': CORRECTNESS,
    },
    {
        'provider': 'CUDA native',
        'operation': 'Mxfp4Linear / GroupedMxfp4Linear through existing CUDA prepared runtime and Graph routes',
        'execution': 'Cold-resolved quantize/dot kernels, checked status/ID ordering and original stream/Completion; original U8 banks consumed in bounded groups without complete floating W expansion',
        'explicit_storage': 'Caller BF16 activation workspace2*quant_rows*K bytes; shared A quantizes T rows, independent slots T*S; original packed bank remains a dense input span',
        'qualification': 'CUDA8 package cases passed with0skip, including new Graph RequireCapture numerical/lifetime/domain cases and existing ModelOpt/Local neighbors; no native MX instruction or model-throughput claim',
        'code': ['src/compute_provider_cuda/nvfp4_provider.cc', 'src/compute_provider_cuda/nvfp4_kernel.cu', 'src/compute_provider_cuda/cuda_provider.cc'],
        'evidence': CORRECTNESS,
    },
    {
        'provider': 'Apple native Metal/MLX',
        'operation': 'Mxfp4Linear / GroupedMxfp4Linear through existing native Program/Invocation',
        'execution': 'Shared private FP4 family with strict scalar numerical helpers, original packed bytes and bounded W group consumption; complete ID dependency before expert addresses; shared activation intermediate has T rows',
        'resource_boundary': 'Explicit BF16 activation and validation/status arrays; native MLX/private allocation totals remain opaque. No full decoded weight bank; input bank still uses existing dense binding and buffer limits.',
        'qualification': 'Apple M4 Graph9 package cases passed with0skip, including new dense/grouped/runtime cases and retained ModelOpt/Local neighbors; no Mac CPU, hardware MX GEMM or throughput inference',
        'code': ['src/compute_route_apple/apple_nvfp4.cc', 'src/compute_route_apple/apple_mature_float.cc', 'src/compute_route_apple/apple_operations.cc'],
        'evidence': CORRECTNESS,
    },
    {
        'provider': 'Vulkan native',
        'operation': 'Mxfp4Linear / GroupedMxfp4Linear through existing native Program/Invocation',
        'execution': 'Group32 variant in existing checked dispatch phases, original Queue/fence/status ownership, strict scalar math and bounded original packed W consumption; shared activation intermediate has T rows',
        'resource_boundary': 'Explicit BF16 activation/status workspace plus ordinary Program resources; no full floating weight bank. Existing dense input binding, byte origins and device buffer-range limits remain.',
        'qualification': 'Vulkan8 package cases passed with0skip, including new dense/grouped/runtime cases and retained ModelOpt/Local neighbors; no hardware MX GEMM or whole-artifact inference',
        'code': ['src/compute_route_vulkan/vulkan_nvfp4.cc', 'src/compute_route_vulkan/shaders/nvfp4.comp', 'src/compute_route_vulkan/vulkan_operations.cc'],
        'evidence': CORRECTNESS,
    },
]

common_pending = (
    'Per-expert artifact tensors/catalog slots still need a resident working-set/bank-binding bridge: the grouped primitive currently accepts dense W[E,N,K/2]/SF[E,N,K/32] spans. Bounded decode removes floating expansion but does not solve whole-bank residency or backend single-buffer limits.'
)
for index, repository in EXPECTED.items():
    row = after['artifacts'][index]
    assert row['repository'] == repository
    coverage = row['provider_coverage']
    coverage['review'] = 'pinned_artifact_contract_and_four_backend_software_reference_regressions'
    coverage['review_scope'] = (
        'Fixed-revision metadata/header/producer research plus bounded BF16 MXFP4 primitive regressions on Windows CPU, CUDA, Apple M4 and Vulkan; '
        'synthetic original-format banks and independent scalar oracle, not publisher numeric payload/importer, complete role binding, quality or whole artifact execution'
    )
    coverage['artifact_execution_verified'] = False
    coverage['mapping_status'] = (
        'Original U8/E8M0 layout and portable BF16 group32 even-scale dense/grouped software primitives are implemented and executed on four backends; '
        'exact selected artifact role binding, separately encoded FP8/preserved roles and complete artifact execution remain unverified.'
    )
    coverage['reachable_entry_points'] = copy.deepcopy(backends)
    coverage['software_primitive_contract'] = copy.deepcopy(primitive_contract)
    coverage['operator_regression_evidence'] = CORRECTNESS
    coverage['operator_regression_scope'] = {
        'Windows_CPU': 12, 'CUDA': 8, 'Apple_M4': 9, 'Vulkan': 8, 'total': 37, 'skipped': 0,
        'counting': 'Package cases include new MXFP4 primitive regressions and retained ModelOpt/Local neighbors; not37 artifacts or models',
        'source_payload': 'Synthetic original-layout inputs; no publisher numeric weight payload',
    }
    coverage['fusion_coverage'] = (
        'Explicit typed dense/grouped software lowering connects A QDQ to bounded packed dot in the existing execution family. '
        'This primitive coverage does not establish model-level automatic fusion, full FFN fusion, hardware MX GEMM or separate FP8 side-branch equivalence.'
    )
    coverage['code'] = list(dict.fromkeys([
        'include/hyle/compute/model_ops.h', 'src/compute_ops/weight_decode.cc',
        *[path for entry in backends for path in entry['code']],
    ]))

c = after['artifacts'][16]['provider_coverage']
c['artifact_unaligned_or_unverified'] = [
    'Portable BF16 Mxfp4Linear/GroupedMxfp4Linear primitives now execute on four backends; exact publisher numeric codes/scales, calibrated distributions and per-role bindings were not executed',
    common_pending,
    'The two sampled expert-only headers do not establish excluded attention/shared/head FP8 or BF16 contracts; these branches need independent tensor, quantizer and output-boundary alignment',
    'MLX U32 weight-only MXFP4, ceil-scale BlockQuantizationRoundtrip and FP4-weight/FP8-activation GroupedFloat4Linear remain different semantics; the new primitive does not borrow their artifact coverage',
    'All213-shard import/model execution, native MX GEMM, quality and throughput remain unverified',
]
c['missing_capabilities'] = [
    'Per-expert catalog/resident-working-set bridge to bind separate original banks under backend buffer limits without dense whole-bank residency',
    'Exact Q24 Quark selected-role/import binding and separate excluded-base FP8 contract alignment',
]
for role in c['role_domains']:
    if role['role'] == 'activations':
        role['unresolved'] = 'The explicit portable BF16 quantizer now executes on four backends; exact publisher/deployment binding and optional Triton behavior are separate from this reference contract'

c = after['artifacts'][23]['provider_coverage']
c['artifact_unaligned_or_unverified'] = [
    'Portable group32 even-scale BF16 dynamic A4 dense/shared/grouped primitives execute on four backends using original U8 banks; full Kimi role binding and producer deployment equivalence remain unverified',
    common_pending,
    'Attention per-channel E4M3 axis0/axis1 math is separate from this MXFP4 primitive and block128 FP8; exact activation layout/quantizer/output binding remains to align',
    'Excluded BF16 outer routing projections remain distinct from the896 packed expert banks; sampled layers are not the full96-shard census',
    'Publisher self.emulate=True and reference regressions do not establish hardware MX GEMM, whole artifact execution, quality or throughput',
]
c['missing_capabilities'] = [
    'Per-expert catalog/resident-working-set bridge for896 independent expert banks without whole-bank dense residency',
    'Exact Kimi artifact dense/shared/expert role binding and separate attention FP8 per-channel axis0/axis1 contract alignment',
]

c = after['artifacts'][30]['provider_coverage']
c['artifact_unaligned_or_unverified'] = [
    'Fixed full config and selected headers resolve the former API-only uncertainty; portable MXFP4 dense/grouped software primitives now execute on four backends, while publisher payload/import bindings remain unverified',
    common_pending,
    'The924 FP8 override roles (871 MTP layer45+53 main) are separate from the MXFP4 primitive and not all-layer FP8; activation math and exact role/output binding still require independent alignment',
    'Whole62-shard import, all preserved BF16 roles, native hardware MX GEMM, quality and throughput remain unverified',
]
c['missing_capabilities'] = [
    'Per-expert catalog/resident-working-set bridge for separate original MXFP4 banks under backend buffer limits',
    'Exact GLM mixed MXFP4/FP8-block128/BF16 role/import binding and independent FP8 override contract alignment',
]

assert len(after['artifacts']) == 33
assert all(row['provider_coverage']['artifact_execution_verified'] is False for row in after['artifacts'])
changed = [i for i, (a, b) in enumerate(zip(before['artifacts'], after['artifacts'])) if a != b]
assert changed == [16, 23, 30]
for key in before.keys() - {'artifacts'}:
    assert before[key] == after[key]
for index in EXPECTED:
    old = before['artifacts'][index]
    new = after['artifacts'][index]
    assert {k: v for k, v in old.items() if k != 'provider_coverage'} == {k: v for k, v in new.items() if k != 'provider_coverage'}
    for key in ('metadata_sources', 'contract_research_evidence', 'pinned_producer', 'header_observations', 'required_format_domain'):
        assert old['provider_coverage'][key] == new['provider_coverage'][key], (index, key)
    assert len(new['provider_coverage']['reachable_entry_points']) == 4
assert (ROOT / RESEARCH).is_file()
research_before = identity(ROOT / RESEARCH)
after_raw = (json.dumps(after, ensure_ascii=False, indent=2) + '\n').replace('\n', '\r\n').encode('utf-8')
assert TARGET.read_bytes() == before_raw, 'Concurrent catalog edit; do not overwrite'
TARGET.write_bytes(after_raw)
after_path = STAGE / 'after/model-quantizations.json'
after_path.parent.mkdir(parents=True, exist_ok=True)
after_path.write_bytes(after_raw)
diff = ''.join(difflib.unified_diff(
    before_raw.decode('utf-8').splitlines(keepends=True), after_raw.decode('utf-8').splitlines(keepends=True),
    fromfile='before/model-quantizations.json', tofile='after/model-quantizations.json', n=3,
))
(STAGE / 'model-quantizations.diff').write_text(diff, encoding='utf-8', newline='')
assert identity(ROOT / RESEARCH) == research_before
validation = {
    'status': 'Provider coverage updated; exact artifact execution remains unverified',
    'changed_zero_based_rows': changed,
    'only_provider_coverage_changed': True,
    'all_metadata_sources_and_historical_research_unchanged': True,
    'other30_artifacts_and_root_fields_unchanged': True,
    'artifact_execution_verified_false_count': 33,
    'reachable_backend_entries_per_changed_row': 4,
    'reported_package_regressions': {'Windows_CPU': 12, 'CUDA': 8, 'Apple_M4': 9, 'Vulkan': 8, 'total': 37, 'skip': 0},
    'tests_or_builds_run_by_this_catalog_task': 0,
    'new_correctness_evidence': CORRECTNESS,
    'correctness_file_present_at_catalog_edit': (ROOT / CORRECTNESS).is_file(),
    'correctness_publisher': 'root; path fixed by task',
    'research': {'path': RESEARCH, **research_before},
    'before': identity(before_path), 'after': identity(after_path), 'diff': identity(STAGE / 'model-quantizations.diff'),
}
(STAGE / 'validation.json').write_bytes(encoded(validation))
print(json.dumps(validation, ensure_ascii=False, indent=2))
