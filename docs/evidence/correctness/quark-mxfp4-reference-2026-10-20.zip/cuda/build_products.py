"""Refresh exactly two CUDA host owners and one kernel TU; never run GPU."""
from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
A=S.parents[1]
ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('mxfp4_cuda_build_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
spec=importlib.util.spec_from_file_location('mxfp4_native_recipe',A/'grouped-nvfp4/cuda/build_products.py')
n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
out=S/'checks/attempt1';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
prior=A/'ct-local-nvfp4-reference/cuda/checks/attempt1/plan.json'
old_plan=c.read(prior)
rows=[]
for old in old_plan['owners']:
    tag=old['tag'];source=Path(old['source']['path'])
    command=n.native_command(old['command'],tag,out) if source.suffix=='.cu' else b.host_command(old['command'],source,tag,out)
    assert not any('use_fast_math' in arg or 'ftz=true' in arg for arg in command)
    rows.append(dict(source=b.identity(source),tag=tag,recipe=b.identity(prior),
                     command=command,object=str(out/(tag+'.obj'))))
frozen=[b.identity(ROOT/p) for p in [
    'include/hyle/compute/model_ops.h','src/compute_provider_cuda/nvfp4_kernel.h',
    'src/compute_provider_cuda/packed_rows.cuh','src/compute_provider_cuda/nvfp4_provider.h']]
c.save(out/'plan.json',dict(owners=rows,frozen=frozen,scope='2 CXX +1 NVCC; no CPU common owner/SDK/link/GPU'))
env,runtime=b.environment(next(row['command'] for row in rows if row['tag']=='nvfp4-provider'),[],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
def compile_one(row):
    tag=row['tag'];job=out/'commands'/tag;job.mkdir(parents=True)
    result=c.execute(tag+'-compile',row['command'],env,job)
    if Path(row['source']['path']).suffix=='.cu':
        dep=out/(tag+'.d');paths=n.native_dependencies(dep)
    else:
        dep=out/(tag+'-deps.json');data=c.read(dep)['Data'];paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
    record=dict(row,result=result,object=b.identity(row['object']),source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in paths])
    assert b.same(row['source']) and all(b.same(x) for x in frozen)
    c.save(out/(tag+'-identity.json'),record)
    print('COMPILED',tag,flush=True)
    return record
records=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
        try:records.append(future.result())
        except Exception as exc:errors.append(str(exc))
c.save(out/'objects-ready.json',dict(owners=records,errors=errors))
c.save(out/'summary.json',dict(passed=not errors,errors=errors,CXX_successes=sum(Path(x['source']['path']).suffix=='.cc' for x in records),NVCC_successes=sum(Path(x['source']['path']).suffix=='.cu' for x in records),SDK=0,links=0,GPU=0))
if errors:raise RuntimeError('; '.join(errors))
print('CUDA_MXFP4_OWNERS_READY',len(records),flush=True)
