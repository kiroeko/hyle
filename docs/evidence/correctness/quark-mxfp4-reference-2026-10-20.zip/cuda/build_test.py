"""Compile one current MXFP4 graph wrapper with strict host flags; no GPU."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
A=S.parents[1]
ROOT=A.parents[1]
out=S/'checks/test';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
spec=importlib.util.spec_from_file_location('mxfp4_cuda_test_build',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
recipe=A/'ct-local-nvfp4-reference/cuda/checks/test/local-test-identity.json'
source=ROOT/'tests/graph_route_cuda/mxfp4_reference_test.cc'
frozen=[b.identity(ROOT/p) for p in ['include/hyle/compute/model_ops.h','tests/compute_models/mxfp4_reference_fixture.h']]
command=b.host_command(c.read(recipe)['command'],source,'mxfp4-test',out)
assert '/W4' in command and '/WX' in command
env,runtime=b.environment(command,[],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.save(out/'plan.json',dict(source=b.identity(source),recipe=b.identity(recipe),command=command,frozen=frozen,SDK=0,GPU=0))
c.execute('mxfp4-test-compile',command,env,out)
dep=out/'mxfp4-test-deps.json';data=c.read(dep)['Data'];paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
assert all(b.same(x) for x in frozen)
c.save(out/'mxfp4-test-identity.json',dict(source=b.identity(source),object=b.identity(out/'mxfp4-test.obj'),recipe=b.identity(recipe),command=command,source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in paths]))
print('CUDA_MXFP4_TEST_READY',flush=True)
