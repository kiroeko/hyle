"""Reuse the actual Local FP4 CUDA closure with affected owners; no GPU."""
from pathlib import Path
import argparse
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
A=S.parents[1]
ROOT=A.parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cpu-receipt',type=Path,action='append',required=True)
args=parser.parse_args()
assert len(args.cpu_receipt)==3,'exactly the three root-owned common CPU receipts are required'
spec=importlib.util.spec_from_file_location('mxfp4_cuda_link_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
base_path=A/'ct-local-nvfp4-reference/cuda/tests/link-plan.json'
base=c.read(base_path)
meta=h.metadata({'cuda':base})
out=S/'tests'
receipt_paths=[S/'checks/attempt1'/f'{tag}-identity.json' for tag in ['cuda-provider','nvfp4-provider','nvfp4-kernel']]
receipt_paths+=args.cpu_receipt
records=[c.read(p) for p in receipt_paths]
replacement={};mapped=[];not_linked=[]
for receipt_path,row in zip(receipt_paths,records):
    assert b.same(row['source']) and b.same(row['object']),str(receipt_path)
    matches=[old for old in base['inputs'] if c.key(old['path']) in meta and
             c.key(meta[c.key(old['path'])]['source_path'])==c.key(row['source']['path'])]
    if not matches and Path(row['source']['path']).name=='native_provider.cc':
        assert not any('hyle_compute_provider_native' in old['path'].lower() for old in base['inputs'])
        not_linked.append(dict(source=row['source'],object=row['object'],receipt=b.identity(receipt_path),
            reason='No explicit owner object or native-provider library is linked in the actual CUDA base closure'))
        continue
    assert len(matches)==1,(row['source'],len(matches))
    old=matches[0]
    assert b.same(old),'actual cached input drift'
    replacement[c.key(old['path'])]=row['object']['path']
    mapped.append(dict(old=old,new=row['object'],source=row['source'],receipt=b.identity(receipt_path)))
assert len(replacement)==5 and len(not_linked)==1
test_receipt=S/'checks/test/mxfp4-test-identity.json'
test=c.read(test_receipt)
assert b.same(test['source']) and b.same(test['object'])
command=[]
for arg in base['command']:
    value=replacement.get(c.key(arg),arg)
    for flag,suffix in [('/OUT:','.exe'),('/MAP:','.map'),('/IMPLIB:','.lib'),('/PDB:','.pdb'),('/ILK:','.ilk')]:
        if arg.upper().startswith(flag):value=flag+str(out/('mxfp4'+suffix))
    command.append(value)
command.insert(1,test['object']['path'])
inputs=[replacement.get(c.key(x['path']),x['path']) for x in base['inputs']]+[test['object']['path']]
assert len(inputs)==len(set(c.key(path) for path in inputs))
identities=[b.identity(p) for p in inputs]
out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
env,runtime=b.environment(command,inputs,out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.save(out/'link-plan.json',dict(command=command,inputs=identities,base=b.identity(base_path),
    mapped_current_owners=mapped,not_linked_receipts=not_linked,additional_test_receipt=b.identity(test_receipt),
    scope='Actual cached Local NVFP4 closure; exactly 3 CUDA +2 root common CPU owners refreshed, one new wrapper; native_provider.cc is absent from this closure. Old ModelOpt/Local test inputs retained. No SDK rebuild or GPU process.'))
c.execute('mxfp4-link',command,env,out)
assert all(b.same(x) for x in identities)
c.save(out/'image.json',b.identity(out/'mxfp4.exe'))
print('CUDA_MXFP4_LINK_READY',len(identities),'inputs',flush=True)
