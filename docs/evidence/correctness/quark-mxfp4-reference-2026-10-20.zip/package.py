"""Archive current source, commands and bounded numerical/lifetime results."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

S=Path(__file__).resolve().parent;ROOT=S.parents[2]
DEST=ROOT/'docs/evidence/correctness/quark-mxfp4-reference-2026-10-20'
def load(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def sha(value):return hashlib.sha256(value).hexdigest()
def identity(path):
    path=Path(path);data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=sha(data))

final_xml={
    'Windows CPU':'common-cpu/checks/attempt2/tests.xml',
    'Windows CUDA RTX4070':'cuda/validation/final1/tests.xml',
    'Windows Vulkan RTX4070':'vulkan/validation/final1/tests.xml',
    'macOS Apple M4':'apple/mac/remote/results/tests.xml'}
expected=[12,8,8,9];results=[]
for (backend,relative),count in zip(final_xml.items(),expected):
    path=S/relative;cases=ET.parse(path).findall('.//testcase')
    assert len(cases)==count and not any(case.find('failure') is not None or case.find('skipped') is not None for case in cases)
    results.append(dict(backend=backend,passed=count,failed=0,skipped=0,xml=relative,
        identity=identity(path),names=[case.get('classname')+'.'+case.get('name') for case in cases]))

sources=['include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc',
    'src/compute_provider_native/nvfp4.cc','src/compute_provider_native/native_provider.cc',
    'src/compute_provider_native/native_plan.h','src/compute_provider_native/numeric.h',
    'src/compute_provider_cuda/nvfp4_provider.h','src/compute_provider_cuda/nvfp4_provider.cc',
    'src/compute_provider_cuda/nvfp4_kernel.h','src/compute_provider_cuda/nvfp4_kernel.cu',
    'src/compute_provider_cuda/packed_rows.cuh','src/compute_provider_cuda/cuda_provider.cc',
    'src/compute_route_vulkan/vulkan_nvfp4.cc','src/compute_route_vulkan/vulkan_operations.cc',
    'src/compute_route_vulkan/shaders/nvfp4.comp','src/compute_route_vulkan/build_shaders.py',
    'src/compute_route_apple/apple_nvfp4.h','src/compute_route_apple/apple_nvfp4.cc',
    'src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc',
    'tests/compute_models/mxfp4_reference_fixture.h',
    'tests/compute_models/nvfp4_reference_fixture.h','tests/compute_models/local_nvfp4_reference_fixture.h',
    'tests/graph_route_apple/nvfp4_reference_test.cc']
for backend in ['cpu','cuda','vulkan','apple']:
    sources.extend(['tests/graph_route_'+backend+'/mxfp4_reference_test.cc',
        'tests/graph_route_'+backend+'/CMakeLists.txt'])
frozen=[identity(ROOT/name) for name in sources]
(S/'root/final-source-freeze.json').write_bytes(encoded(dict(files=frozen,scope='Current product/fixture and the source of the refreshed Apple Cast neighbor')))
report=dict(status='PASS: bounded portable BF16 MXFP4 dense and selected-grouped reference on four backends',
    public_operations=['model_ops::Mxfp4Linear','model_ops::GroupedMxfp4Linear'],
    source_definition='docs/evidence/research/quark-mxfp4-contract-2026-10-20.json',
    contract=dict(dense='BF16 A[M,K], original U8 W[N,K/2], U8 E8M0 SF[N,K/32] -> BF16[M,N]',
        grouped='BF16 A[T,1-or-S,K], U8 W[E,N,K/2], U8 SF[E,N,K/32], checked I32 IDs[T,S] -> BF16[T,S,N]',
        activation='Group32 even scale from BF16 absmax; explicit roundedzero exponent-127 and Infcarry127; BF16 divide -> signed saturating nearest-even E2M1 -> BF16 reconstruction.',
        weight='Adjacent evenK low/oddK high nibble; original E8M0 code0..254 means2^(code-127). BF16 decoded operands precede backend F32 dot and BF16 output.',
        invalid='Nonfinite source A or selected SF255 fail Completion. Every ID is validated before selected expert addressing. Legal finite-source overflow remains IEEE; failed results are unusable.',
        not_assumed='Original default HIP and optional Triton full-domain bit equivalence, SDK bug compatibility or native hardware MXFP4 GEMM'),
    resources=dict(shared_A='A1 or actual zero-slot-stride: one QDQ row per token; CPU/CUDA caller workspace2*T*K bytes.',
        independent_A='A[T,S,K]: CPU/CUDA caller workspace2*T*S*K bytes.',
        weights='Directly read only selected original compressed W/SF tiles; no floating E*N*K bank.',
        native_costs='Apple/Vulkan also own check/status/QDQ native storage; this is not a peak-memory benchmark.',
        pending_bridge='Checkpoint per-expert tensors still need the delivery3 catalog/WeightSlots/global-local-ID working-set bridge. This operator takes one dense W/SF carrier.'),
    architecture='Existing per-backend FP4 preparation/traversal, Program/Invocation, capture, status and Completion lifetime. No extra Graph executor, fake global input arrays or public CMake switch. The four ModelOpt/Local public numerical contracts remain separate.',
    results=results,total_final_passed=sum(expected),final_failed=0,final_skipped=0,
    witnesses=['Actual updates through stable original A/W/SF/ID buffers; denseK2048 and grouped/shared/zeroS/tokenpadding/E17',
        'Two independent slots, retained old results, submit protection, dropped graph/constants/executable and post-Invocation result lifetime',
        'Per backend:16 new lifetime submissions plus30 successful runtime-domain submissions and10 expected failed Completions with fresh-slot recovery',
        'Subnormal A0x0030/0x0040 with SF254 gives BF16 one; original scale0 gives nonzero BF16 result0x0140',
        'NaN/Inf source rejection, selected scale255, invalid final IDs, unread NaN token padding and unselected SF255',
        'CPU actual quantized signedzero, shared-vs-independent workspace size and every input/workspace alias rejected before write',
        'Original four Vulkan FP4 shader variants recompiled byte-identically; original ModelOpt/Local numerical and lifetime neighbors pass'],
    retained_failures=[
        'First CPU direct test setup wrote a short payload to an oversized full view; fixed the upload to its exact subview.11 of12 passed initially; only test TU was refreshed, then12 of12 passed.',
        'Apple first MX dense Metal signature used an invalid0D dummy scalar. Final MX signatures remove global arrays entirely.',
        'Apple cold signature macro initially hid a legacy grouped metadata identifier; replaced by cold body expansion and reran all9.',
        'Apple retained old NVFP4 Cast test object was stale; refreshed the existing current canonical test source.',
        'Root GPU helper initially guessed a Vulkan image receipt filename; corrected to ready-to-run.json before any Vulkan GPU process.'],
    review_members=['root/independent-native-review.json','vulkan/independent-cuda-review.json',
        'cuda/implementation-receipt.json','vulkan/compiled-identities.json','apple/final-validation.json'],
    limits=['No selected artifact weight payload or whole-model execution/quality was verified.',
        'No Linux, installed-consumer, giant complete expert bank or hardware-native FP4 GEMM claim.',
        'No loading/prefill/decode throughput, peak memory or energy measurement in this package.',
        'Current BF16 Qwen consumer does not use this weight format; this is capability coverage, not a claimed Qwen speedup.'],
    progress=dict(capability_packages_complete=5,capability_packages_total=8,delivery_packages_complete=0,delivery_packages_total=3,
        next='CT channel/token QDQ Apple/Vulkan wiring'))

entries={}
allowed={'.py','.json','.cc','.h','.cu','.comp','.log','.xml','.d','.diff','.txt','.spv'}
for path in sorted(S.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path.name in ['package-receipt.json','cleanup-plan.json'] or path.suffix.lower() not in allowed:
        continue
    entries[path.relative_to(S).as_posix()]=path.read_bytes()
for relative,row in zip(sources,frozen):
    data=(ROOT/relative).read_bytes();assert sha(data)==row['sha256']
    entries['current-source/'+relative]=data
entries['report-core.json']=encoded(report)
entries['inventory.json']=encoded(dict(members=[dict(member=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(entries.items())],scope='All members except this inventory; no executables, objects, maps or SDK archives'))
DEST.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(entries.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        archive.writestr(name,data)
with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))
    for name,data in entries.items():assert archive.read(name)==data
report['archive']=dict(identity=identity(DEST.with_suffix('.zip')),members=len(entries),current_sources=len(frozen))
DEST.with_suffix('.json').write_bytes(encoded(report))
receipt=dict(report=identity(DEST.with_suffix('.json')),archive=report['archive'],all_final_cases=37,failed=0,skipped=0)
(S/'package-receipt.json').write_bytes(encoded(receipt));print(json.dumps(receipt,indent=2))
