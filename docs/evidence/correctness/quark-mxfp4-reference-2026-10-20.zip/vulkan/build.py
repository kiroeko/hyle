from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
import threading
import time

ROOT = Path.cwd()
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
STAGE = A / 'quark-mxfp4-reference/vulkan'
BASE = A / 'ct-local-nvfp4-reference/vulkan/checks'
CHECKS, SHADERS = STAGE / 'checks', STAGE / 'shaders'
CHECKS.mkdir(exist_ok=True)
SHADERS.mkdir(exist_ok=True)
PHASE = sys.argv[1]
records, lock = [], threading.Lock()
env = os.environ.copy()
setup = subprocess.run(['cmd', '/d', '/c', str(A / 'bf16-nan-cast-contract/compiler-env.bat')],
                       capture_output=True, text=True, check=True)
for line in setup.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def run(label, command):
    started = time.time()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                            text=True, encoding='utf8', errors='replace')
    (CHECKS / (label + '.stdout.log')).write_text(result.stdout, encoding='utf8')
    (CHECKS / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    with lock:
        records.append(dict(label=label, command=command, exit_code=result.returncode,
                            seconds=time.time() - started))
        save(CHECKS / ('commands-' + PHASE + '.json'), records)
    print(label, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(label + ': ' + (result.stdout + result.stderr)[-8000:])


def recipe_for(obj):
    for path in Path(obj).parent.glob('*identity.json'):
        data = load(path)
        if str(Path(data.get('object', {}).get('path', ''))).lower() == str(Path(obj)).lower():
            return path
    raise AssertionError(obj)


def command_for(recipe, source, tag):
    command, skip = [], False
    for arg in load(recipe)['command']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        command.append(arg)
    command.insert(1, '-I' + str(SHADERS))
    command += ['/W4', '/WX', '/sourceDependencies', str(CHECKS / (tag + '-deps.json')),
                str(source), '/Fo' + str(CHECKS / (tag + '.obj')),
                '/Fd' + str(CHECKS / (tag + '.pdb'))]
    return command


if PHASE == 'plan':
    linked = load(BASE / 'link-plan.json')
    objects = {Path(row['path']).name: row for row in linked['inputs']}
    items = [('vulkan_nvfp4', ROOT / 'src/compute_route_vulkan/vulkan_nvfp4.cc'),
             ('vulkan_operations', ROOT / 'src/compute_route_vulkan/vulkan_operations.cc'),
             ('vulkan_shaders', SHADERS / 'vulkan_shaders.cc')]
    compiles = []
    for tag, source in items:
        old = objects[tag + '.obj']
        assert identity(old['path']) == old
        recipe = recipe_for(old['path'])
        compiles.append(dict(tag=tag, source=str(source), object=str(CHECKS / (tag + '.obj')),
            command=command_for(recipe, source, tag), previous_object=old, recipe=identity(recipe)))
    save(CHECKS / 'product-plan.json', dict(baseline=identity(BASE / 'link-plan.json'),
        compile=compiles, scope='3 actual product CXX,2 new GLSL plus4 original FP4 variant byte checks; no SDK/GPU.'))
    print('planned', len(compiles))
elif PHASE == 'shaders':
    old = {row['name']: Path(row['artifact']['path'])
           for row in load(BASE / 'shader-artifacts.json')['artifacts']}
    assert len(old) == 19
    text = (ROOT / 'src/compute_shader_shared/nvfp4_f32.h').read_text()
    numerical = text.split('R"HYLE_SHADER(', 1)[1].split(')HYLE_SHADER"', 1)[0]
    source = (ROOT / 'src/compute_route_vulkan/shaders/nvfp4.comp').read_text()
    generated = SHADERS / 'nvfp4.generated.comp'
    generated.write_bytes(source.replace('// HYLE_NVFP4_F32_SOURCE', numerical).encode())
    changed = {'nvfp4': {}, 'nvfp4_grouped': {'HYLE_NVFP4_GROUPED': '1'},
        'nvfp4_local': {'HYLE_NVFP4_LOCAL': '1'},
        'nvfp4_grouped_local': {'HYLE_NVFP4_GROUPED': '1', 'HYLE_NVFP4_LOCAL': '1'},
        'mxfp4': {'HYLE_MXFP4': '1'},
        'mxfp4_grouped': {'HYLE_NVFP4_GROUPED': '1', 'HYLE_MXFP4': '1'}}
    old_proof = []
    for name, defines in changed.items():
        command = ['C:/public/tools/glslang/glslangValidator.exe', '-V', '--target-env',
                   'vulkan1.2', '--preamble-text',
                   '#extension GL_GOOGLE_include_directive : require\n',
                   '-I' + str(ROOT / 'third_party/ggml_vulkan_shaders/shaders'), '-S', 'comp']
        command += ['-D' + key + '=' + value for key, value in defines.items()]
        command += ['-o', str(SHADERS / (name + '.spv')), str(generated)]
        run(name + '-shader', command)
        if name in old:
            assert (SHADERS / (name + '.spv')).read_bytes() == old[name].read_bytes(), name
            old_proof.append(dict(name=name, previous=identity(old[name]),
                rebuilt=identity(SHADERS / (name + '.spv')), byte_equal=True))
    header = ['#pragma once', '#include <cstdint>', '#include <span>',
              'namespace hyle::compute::vulkan::detail::shaders {']
    cpp = ['#include "vulkan_shaders.h"',
           'namespace hyle::compute::vulkan::detail::shaders {']
    artifacts = []
    for name in [*old, 'mxfp4', 'mxfp4_grouped']:
        path = old[name] if name in old else SHADERS / (name + '.spv')
        raw = path.read_bytes()
        assert len(raw) % 4 == 0
        words = struct.unpack('<' + 'I' * (len(raw) // 4), raw)
        assert words[0] == 0x07230203 and words[1] <= 0x00010500
        at = 5
        while at < len(words):
            size, opcode = words[at] >> 16, words[at] & 65535
            assert size and at + size <= len(words)
            if opcode == 17:
                assert size == 2 and words[at + 1] == 1
            at += size
        header.append('std::span<const std::uint32_t> ' + name + '() noexcept;')
        cpp.append('namespace { constexpr std::uint32_t ' + name + '_words[] = {')
        for offset in range(0, len(words), 8):
            cpp.append('  ' + ', '.join(f'0x{x:08x}u' for x in words[offset:offset + 8]) + ',')
        cpp += ['}; }', 'std::span<const std::uint32_t> ' + name + '() noexcept { return ' + name + '_words; }']
        artifacts.append(dict(name=name, artifact=identity(path), reused=name in old))
    header.append('} // namespace hyle::compute::vulkan::detail::shaders')
    cpp.append('} // namespace hyle::compute::vulkan::detail::shaders')
    (SHADERS / 'vulkan_shaders.h').write_bytes(('\n'.join(header) + '\n').encode())
    (SHADERS / 'vulkan_shaders.cc').write_bytes(('\n'.join(cpp) + '\n').encode())
    save(CHECKS / 'shader-artifacts.json', dict(artifacts=artifacts, new=2, reused=19,
        old_FP4_byte_equal=old_proof, shared_math=identity(ROOT / 'src/compute_shader_shared/nvfp4_f32.h')))
elif PHASE == 'product':
    def compile_one(item):
        tag = item['tag']
        run(tag + '-compile', item['command'])
        data = load(CHECKS / (tag + '-deps.json'))['Data']
        paths = dict.fromkeys([data['Source'], *data['Includes']])
        record = dict(command=item['command'], source=identity(item['source']),
            object=identity(item['object']), recipe=item['recipe'],
            dependencies=[identity(path) for path in paths])
        save(CHECKS / (tag + '-identity.json'), record)
        return dict(tag=tag, receipt=identity(CHECKS / (tag + '-identity.json')))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        completed = list(pool.map(compile_one, load(CHECKS / 'product-plan.json')['compile']))
    save(CHECKS / 'product-build-receipt.json', dict(CXX=3, failures=0, GLSL=6,
        SDK=0, GPU=0, receipts=completed))
elif PHASE == 'test':
    recipe = BASE / 'local-test-identity.json'
    source = ROOT / 'tests/graph_route_vulkan/mxfp4_reference_test.cc'
    command = command_for(recipe, source, 'mxfp4-test')
    run('local-test-compile', command)
    data = load(CHECKS / 'mxfp4-test-deps.json')['Data']
    paths = dict.fromkeys([data['Source'], *data['Includes']])
    save(CHECKS / 'mxfp4-test-identity.json', dict(command=command,
        source=identity(source), object=identity(CHECKS / 'mxfp4-test.obj'),
        recipe=identity(recipe), dependencies=[identity(path) for path in paths]))
elif PHASE == 'link':
    linked = load(BASE / 'link-plan.json')
    replacements = {str(Path(row['previous_object']['path'])).lower(): row['object']
                    for row in load(CHECKS / 'product-plan.json')['compile']}
    shared_root = Path(sys.argv[2]) if len(sys.argv) > 2 else A / 'quark-mxfp4-reference/common-cpu'
    shared_sources = {str(ROOT / source).lower() for source in (
        'src/compute_ops/weight_decode.cc', 'src/compute_provider_native/native_provider.cc',
        'src/compute_provider_native/nvfp4.cc')}
    shared = {}
    for path in shared_root.rglob('*identity.json'):
        data = load(path)
        source = str(Path(data.get('source', {}).get('path', ''))).lower()
        if source in shared_sources:
            assert source not in shared, source
            assert identity(data['source']['path']) == data['source']
            assert identity(data['object']['path']) == data['object']
            shared[source] = dict(receipt=identity(path), source=data['source'], object=data['object'])
    assert set(shared) == shared_sources, shared.keys()
    ABI = []
    defines = lambda command: sorted({arg[2:] for arg in command if arg.startswith(('/D', '-D'))})
    crt = lambda command: sorted(arg.lower() for arg in command if arg.lower() in ('/md', '/mt', '/mdd', '/mtd'))
    # Use the actual baseline owner receipt, not an old object's basename.
    baseline_inputs = {str(Path(row['path'])).lower(): row for row in linked['inputs']}
    for overlay in linked['shared_CPU_overlay']:
        source = str(Path(overlay['source']['path'])).lower()
        assert source in shared_sources, source
        old = overlay['object']
        assert baseline_inputs[str(Path(old['path'])).lower()] == old
        recipe = load(recipe_for(old['path']))
        assert str(Path(recipe['source']['path'])).lower() == source
        if source in shared:
            fresh = load(shared[source]['receipt']['path'])
            assert defines(recipe['command']) == defines(fresh['command']), source
            assert crt(recipe['command']) == crt(fresh['command']), source
            assert str(Path(recipe['command'][0])).lower() == str(Path(fresh['command'][0])).lower(), source
            ABI.append(dict(source=source, defines_equal=True, runtime_equal=True, toolchain_equal=True))
            replacements[str(Path(old['path'])).lower()] = shared[source]['object']['path']
    assert len(replacements) == 6, replacements
    command, seen = [], set()
    for arg in linked['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:')):
            continue
        key = str(Path(arg)).lower()
        if key in replacements:
            seen.add(key)
            command.append(replacements[key])
        else:
            command.append(arg)
    assert seen == set(replacements)
    command.insert(1, str(CHECKS / 'mxfp4-test.obj'))
    command += ['/OUT:' + str(CHECKS / 'mxfp4-reference-test.exe'),
                '/MAP:' + str(CHECKS / 'mxfp4-reference-test.map'),
                '/IMPLIB:' + str(CHECKS / 'mxfp4-reference-test.lib')]
    temporary = STAGE / 'tmp'
    temporary.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temporary)
    run('link', command)
    save(CHECKS / 'link-plan.json', dict(command=command,
        inputs=[identity(arg) for arg in command[1:] if Path(arg).is_file()],
        baseline=identity(BASE / 'link-plan.json'), shared_CPU_overlay=list(shared.values()),
        shared_CPU_ABI_checks=ABI,
        executable=identity(CHECKS / 'mxfp4-reference-test.exe')))
else:
    raise ValueError(PHASE)
