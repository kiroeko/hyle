"""Refresh only the direct-test setup fix; reuse all successful product objects."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;Q=S.parent;A=Q.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('mx_cpu_fix',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
base=Q/'common-cpu/checks/attempt1';out=Q/'common-cpu/checks/attempt2';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
before=c.read(base/'test-identity.json');source=ROOT/'tests/graph_route_cpu/mxfp4_reference_test.cc'
command=b.host_command(before['command'],source,'test',out)
env,_=b.environment(command,[],out);compiled=c.execute('test-compile',command,env,out)
dep=out/'test-deps.json';data=c.read(dep)['Data'];obj=b.identity(out/'test.obj')
c.save(out/'test-identity.json',dict(source=b.identity(source),object=obj,command=command,result=compiled,
    recipe=b.identity(base/'test-identity.json'),source_dependencies=b.identity(dep),
    dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]))
plan=c.read(base/'link-plan.json');inputs=[obj if c.key(row['path'])==c.key(before['object']['path']) else row for row in plan['inputs']]
assert all(b.same(row) for row in inputs)
image=out/'cpu.exe';command=[obj['path'] if c.key(arg)==c.key(before['object']['path']) else arg for arg in plan['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base/'link-plan.json'),
    replacements=[dict(before=before['object'],after=obj)],product_recompiled=False))
env,_=b.environment(command,[row['path'] for row in inputs],out);linked=c.execute('link',command,env,out)
image_identity=b.identity(image);c.save(out/'image.json',image_identity)
filter='CpuMxfp4Reference*.*:CpuLocalNvfp4Reference*.*:CpuNvfp4ReferenceGraph.*:CpuGroupedNvfp4ReferenceGraph.*:NativeNvfp4.*'
run=c.execute('tests',[str(image),'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
c.save(out/'receipt.json',dict(image=image_identity,compile_result=compiled,link_result=linked,CPU_result=run,
    scope='one corrected test TU, one link, one CPU process; three successful product owners reused',
    changed_test_setup='Upload payload to its exact subview inside oversized alias-test buffer; no numerical oracle/product change'))
print('CPU corrected direct setup and neighbors passed')
