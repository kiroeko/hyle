# Generated lifetime scaffold from the existing independent lease helpers.
# Product quantizers are never called by the scalar oracle.
