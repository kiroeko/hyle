"""Root-only sequential Windows GPU validation of current linked FP4 images."""
from pathlib import Path
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;Q=S.parent;A=Q.parent
spec=importlib.util.spec_from_file_location('mx_gpu_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];assert arm in ['cuda','vulkan']
if arm=='cuda':
    plan_path=Q/'cuda/tests/link-plan.json';image_path=Q/'cuda/tests/image.json'
    filter='CudaMxfp4ReferenceGraph.*:CudaLocalNvfp4ReferenceGraph.*:CudaNvfp4ReferenceGraph.*:CudaGroupedNvfp4ReferenceGraph.*'
else:
    plan_path=Q/'vulkan/checks/link-plan.json';image_path=Q/'vulkan/ready-to-run.json'
    filter='VulkanMxfp4ReferenceGraph.*:VulkanLocalNvfp4ReferenceGraph.*:VulkanNvfp4ReferenceGraph.*:VulkanGroupedNvfp4ReferenceGraph.*'
out=Q/arm/'validation/final1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'tests.result.json').exists(), 'Do not overwrite an actual GPU attempt'
plan=c.read(plan_path);image=c.read(image_path)
if arm=='vulkan': image=image['image']
assert b.same(image) and all(b.same(row) for row in plan['inputs'])
env,runtime=b.environment(plan['command'],[row['path'] for row in plan['inputs']],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
command=[image['path'],'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')]
try:
    c.execute('tests',command,env,out)
finally:
    if (out/'tests.xml').exists():
        cases=ET.parse(out/'tests.xml').findall('.//testcase')
        failed=[case.attrib for case in cases if case.find('failure') is not None]
        skipped=[case.attrib for case in cases if case.find('skipped') is not None]
        receipt=dict(passed=not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,
            image=image,link_plan=b.identity(plan_path),xml=b.identity(out/'tests.xml'),
            names=[case.get('classname')+'.'+case.get('name') for case in cases],
            properties=[dict(case=case.get('classname')+'.'+case.get('name'),
                properties=[p.attrib for p in case.findall('./properties/property')]) for case in cases],
            actual_GPU_processes=1,scope='New MX math/lifetime tests plus existing ModelOpt/Local neighbors; not a benchmark/model run')
        c.save(out/'receipt.json',receipt);print(json.dumps(receipt,indent=2))
