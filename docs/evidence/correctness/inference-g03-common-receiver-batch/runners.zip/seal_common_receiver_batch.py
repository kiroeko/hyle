from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path.cwd();task=root/'.scratch/inference-gaps/g03';out=root/'evidence/correctness/inference-g03-common-receiver-batch';out.mkdir(exist_ok=True)
cuda=json.loads((task/'common-receiver-cuda/result.json').read_bytes());latest={r['stage']:r for r in cuda['stages']}
for stage,count,marker in [('actual-64-step-native',2,'common CUDA pending receiver PASS:64'),('actual-source-risks',5,'PASS')]:
 row=latest[stage];assert row['exit_code']==0
 assert (task/'common-receiver-cuda'/Path(row['log']).name).read_text().count(marker)==count
 for item in row['inputs']:
  if item['path'].startswith(('include/','src/')) or item['path'].endswith('cuda64_consumer.cc') or stage=='actual-source-risks':assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256']
sdk=json.loads((task/'common-receiver-cuda-sdk/result.json').read_bytes());slast={(r['mode'],r['stage']):r for r in sdk['stages']}
for mode in ['static','shared']:
 row=slast[mode,'public64'];assert row['exit_code']==0
 assert (task/'common-receiver-cuda-sdk'/Path(row['log']).name).read_text().count('common CUDA pending receiver PASS:64')==2
 assert not (task/'common-receiver-cuda-sdk'/f'{mode}-kernel-build-required.json').exists()
with zipfile.ZipFile(task/'common-receiver-air/raw.zip') as z:
 air=json.loads(z.read('result.json'));last={(r['mode'],r['stage']):r for r in air['stages']}
 for mode in ['asan','ubsan','tsan']:
  r=last[mode,'g03_common_receiver_risks'];assert r['exit_code']==0 and z.read(Path(r['log']).name).decode().count('PASS')==9
 for item in air['inputs']:assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256']
shutil.copyfile(task/'common-receiver-air/raw.zip',out/'air-raw.zip')
windows=json.loads((task/'common-receiver-windows/result.json').read_bytes());row=next(r for r in reversed(windows['stages']) if r['stage']=='receiver-risks');assert row['exit_code']==0 and Path(row['log']).read_text().count('PASS')==9
for folder in ['common-receiver-cuda','common-receiver-cuda-sdk','common-receiver-windows']:
 with zipfile.ZipFile(out/(folder+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
  for p in (task/folder).iterdir():
   if p.is_file():z.write(p,p.name)
summary=dict(baseline='b3b8cb48ac6246f88d0020c239ab8f43793d6945',product_changed=False,
 passed=['CUDA source and relocated static/shared: F16/BF16 GQA8/2 D256, two requests/two original slots,64 growing cross-page steps with Q1/17, independent double oracle, original control and page recovery',
 'Actual CUDA five risks: known retired source refusal, unknown before acceptance preserved until real final error, error after native suffix acceptance refuses successful output/reuse, pending owner/aggregate abandonment preserves then retires original slots/metadata/guards, actual original CPU queue rejects live CUDA prefix without host wait',
 'CPU nine boundaries including actual ResourceBudget exhaustion preserving original controller/charges and aggregate/owner abandonment freeing original native slot; Windows and three actual Air host sanitizer configurations'],
 receipts='CUDA shipping SDK backend command has no HYLE_TESTING; same public64 has only relocated product headers. No new nvcc/kernel compilation. Current host ASan detect_leaks=0; original exact ref-count TSan model retained.',
 failure_notes=['Original CUDA risk termination159.825s, two resource-lifetime fatal exits and initial wrong known-error assertion retained in cumulative logs. Fixture now keeps both original metadata allocators/resources alive through explicit actual retirement and captures native events by observe, not dependency identity lookup.',
 'An original CUDA event query error while still pending returns public Unavailable with an OK prefix terminal hint. The old assertion treated this as known terminal failure; final tests distinguish unknown-before-acceptance from actually retired known failure. No product contract/API weakened or product fix needed.',
 'Earlier uncommitted fixture hashes and logs are retained; full historical fixture source bytes were not archived. This limitation is not represented as historical byte reproducibility.'],
 seconds=dict(cuda_cumulative=cuda['cumulative_seconds'],sdk=sdk['cumulative_seconds'],air_cumulative=air['cumulative_seconds'],windows_cumulative=windows['cumulative_seconds']),
 remaining='Full original Graph pending composition, native late producer backing, seven-route complete main and independent reduction journeys, original G01/G02 unresolved gates and G04-G10. Whole G03 and modules remain AUDITED.',
 execution_preference='User 2026-10-14: implement a finite batch, validate it together, then fix specific failures; no per-helper construction-card or verification churn.')
(out/'validation-result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
names=['tests/compute_batch/pending_paged_receiver_cpu_risks.cc','tests/compute_batch/pending_paged_receiver_cuda64_consumer.cc','tests/compute_batch/pending_paged_receiver_cuda_risks.cc','src/compute_batch/batch_execution.cc','include/hyle/compute/batch_execution.h']
(out/'current-inputs.json').write_text(json.dumps([dict(path=n,sha256=hashlib.sha256((root/n).read_bytes()).hexdigest()) for n in names],indent=2)+'\n',newline='\n')
with zipfile.ZipFile(out/'runners.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['write_cuda_receiver64.py','write_cuda_receiver_risks.py','common_receiver_cuda.py','common_receiver_cuda_sdk.py','common_receiver_air.py','run_common_receiver_air.py','common_receiver_windows.py','seal_common_receiver_batch.py']:z.write(task/name,name)
card=root/'docs/implementation/tasks/compute/inference-g03-pending-page-consumption.md'
with card.open('a',encoding='utf-8',newline='\n') as f:f.write('''
\n## BC04 CPU/CUDA 批量验证检查点（2026-10-14）

[本批记录](../../../../evidence/correctness/inference-g03-common-receiver-batch/validation-result.json)
证明 CUDA source/static/shared 的原 GQA8/2 D256、F16/BF16、双请求/双slot/64步完整
数值旅程；五项 actual CUDA 来源/未知/错误/放弃及原 CPU queue 拒绝边界；CPU 九项
风险（新增预算拒绝与放弃原槽回收），Windows 与三宿主 sanitizer 均通过。无产品改动，
无 nvcc/new kernel；原 source4/CPU64/SDK、两 native64 和已证明原数学门继续复用。

原159.825s诊断终止、两个 fixture lifetime fatal、错误的“未知=已知失败”判据及全部
累计保留。最终按原public Unavailable/actual retirement合同分别验 known 与unknown；
未知错误最终合并并拒绝成功 output，不改产品或放宽错误合同。CUDA shipping backend
未编入 HYLE_TESTING；source 风险只借既有观测 hook，不代签 GPU sanitizer。

模块仍 AUDITED，不签整项 G03。下一批集中处理原 Graph pending 消费与 native late
output 的剩余有限接缝，再批量验证七路线与正交 reduction；对应 owner 先完成范围/
API/寿命/成本审计，保原 G02 未决门。按用户要求一批实现、批量检查、针对失败修复，
不再按单 helper 切施工卡或重复已证明门。原十项 goal、失败/UNKNOWN和粗估20%保留。
''')
p=root/'docs/implementation/module-status.json';d=json.loads(p.read_bytes());r=next(r for r in d['modules'] if r['module']=='compute_batch');assert r['state']=='AUDITED'
r['summary']='G03 receiver batch verified, still AUDITED. Prior native Apple/Vulkan retained; common CPU64/F16/BF16 +nine boundaries/three hostsan +two SDKs; CUDA source/static/shared64 +five actual source/unknown/late-error/abandon/CPU-queue boundaries PASS. No new product/kernel change. Original Graph/late producer backing/full seven-route and independent reduction acceptance remain.'
p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode('utf-8'))
print(json.dumps(summary['seconds']))
