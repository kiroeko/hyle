from pathlib import Path
root=Path.cwd();s=(root/'tests/compute_batch/pending_paged_receiver_cuda_consumer.cc').read_text()
s='#define HYLE_TESTING 1\n#include "../../src/compute_backend_cuda/cuda_internal.h"\n#include <hyle/compute/detail/copy_stream_access.h>\n#include <hyle/compute/detail/queue_sequence.h>\n#include <hyle/mem/quota_allocator.h>\n#include <algorithm>\n#include <thread>\n#include <vector>\n'+s
start=s.index('  if(host_receiver){');end=s.index('  HYLE_ASSIGN_OR_RETURN(auto program,',start)
s=s[:start]+s[end:]
s=s.replace('  HYLE_ASSIGN_OR_RETURN(auto cpu,c::cpu::create_context({.native_threads=2}));\n','')
s=s.replace('  struct Drain final {Gate&gate;c::Context&context;~Drain(){gate.release();context.drain().IgnoreError();}}drain{gate,context};',
    '  hyle::mem::QuotaAllocator metadata(hyle::mem::system_allocator()),source_metadata(hyle::mem::system_allocator());\n  const auto status=[&]()->Status {')
s=s.replace('c::CopyBatchProgram::prepare(context,specs)', 'c::CopyBatchProgram::prepare(context,specs,{.allocator=source_metadata.get()})')
s=s.replace('  HYLE_ASSIGN_OR_RETURN(auto producer,n::submit(queue,',
    '  struct ReleaseGate final {Gate&gate;~ReleaseGate(){gate.release();}}release_gate{gate};\n  HYLE_ASSIGN_OR_RETURN(auto producer,n::submit(queue,')
s=s.replace('.max_int_workspace_bytes=64u<<10,.max_invocations=1,.scale=.125F}));','.max_int_workspace_bytes=64u<<10,.max_invocations=1,.scale=.125F,.allocator=metadata.get()}));\n  const auto program_metadata=metadata.used();')
s=s.replace('Status run(bool host_receiver){','''enum class Mode { known_source_error,unknown_before_acceptance,late_source_error,abandon,cpu_foreign_queue };
thread_local bool recording=false,fail_source=false;
thread_local std::vector<cudaEvent_t> source_events;
bool is_source(cudaEvent_t event){return std::find(source_events.begin(),source_events.end(),event)!=source_events.end();}
cudaError_t query(cudaEvent_t event)noexcept{
  if(recording && !is_source(event))source_events.push_back(event);
  if(fail_source && is_source(event)){fail_source=false;return cudaErrorMemoryAllocation;}
  return cudaEventQuery(event);
}
cudaError_t synchronize(cudaEvent_t event)noexcept{
  if(fail_source && is_source(event)){fail_source=false;return cudaErrorMemoryAllocation;}
  return cudaEventSynchronize(event);
}
Status run(Mode mode){''')
needle='  HYLE_ASSIGN_OR_RETURN(auto submitted,receiver.submit(query,k,v,std::move(update)));'
s=s.replace(needle,'''  source_events.clear();recording=true;fail_source=false;
  const auto previous=n::detail::set_completion_observation_hooks({&::query,&synchronize});
  struct Reset final {n::detail::CompletionObservationHooks previous;~Reset(){n::detail::set_completion_observation_hooks(previous);}}reset{previous};
  const auto observed=update.observe();
  auto prefix=c::detail::CopyStreamAccess::dependency(update);recording=false;
  HYLE_RETURN_IF_ERROR(require(observed.IsUnavailable() && prefix.has_value() && prefix->pending() && !source_events.empty(),"risk did not capture actual original source event"));
  if(mode==Mode::cpu_foreign_queue){
    HYLE_ASSIGN_OR_RETURN(auto cpu,c::Context::create(c::cpu::device()));
    HYLE_ASSIGN_OR_RETURN(auto cpu_queue,cpu.create_queue());
    HYLE_ASSIGN_OR_RETURN(auto sequence,c::detail::QueueSequence::begin(cpu_queue));
    const auto rejected=sequence.enqueue_resolved_wait(*prefix);
    HYLE_RETURN_IF_ERROR(require(!rejected.accepted && rejected.status.IsUnimplemented() && update.valid() &&
        guards.active_batches()==1 && !gate.released,"CPU queue imported actual pending CUDA prefix or hid a host wait"));
    sequence.record(rejected);auto finished=sequence.finish();
    HYLE_RETURN_IF_ERROR(require(!finished && finished.error().IsUnimplemented(),"rejected CPU prefix fabricated a completion"));
    gate.release();HYLE_RETURN_IF_ERROR(update.wait());
    std::fprintf(stderr,"original CPU QueueSequence rejects real pending CUDA prefix without host wait/accepted prefix/control loss PASS\\n");return Status::Ok();
  }
  if(mode==Mode::known_source_error || mode==Mode::unknown_before_acceptance){
    fail_source=true;HYLE_RETURN_IF_ERROR(require(update.observe().IsUnavailable() && !fail_source && guards.active_batches()==1,"known source observation fabricated retirement"));
    auto failed_prefix=c::detail::CopyStreamAccess::dependency(update);
    HYLE_RETURN_IF_ERROR(require(failed_prefix.has_value() && failed_prefix->terminal_hint && failed_prefix->terminal_hint->ok(),"unknown observation fabricated public source terminal before retirement"));
  }
  if(mode==Mode::known_source_error){
    gate.release();HYLE_RETURN_IF_ERROR(require(update.wait().IsResourceExhausted(),"known source lost actual terminal error"));
    auto rejected=receiver.submit(query,k,v,std::move(update));
    HYLE_RETURN_IF_ERROR(require(!rejected && update.valid() && !receiver.output(),"common CUDA receiver accepted known failed source or lost original Update"));
    HYLE_RETURN_IF_ERROR(require(!update.take_mutable({1}),"failed source fabricated successful writer"));
    std::fprintf(stderr,"common CUDA receiver known-source failure preserves controls and actual retirement PASS\\n");return Status::Ok();
  }
'''+needle)
needle='  gate.release();HYLE_RETURN_IF_ERROR(submitted.wait());HYLE_ASSIGN_OR_RETURN(auto output,receiver.output());'
s=s.replace(needle,'''  if(mode==Mode::abandon){
    submitted={};receiver={};
    HYLE_RETURN_IF_ERROR(require(guards.active_batches()==1 && !c::BatchInvocation::create(program,queue),"abandoned common receiver released native work/slot before retirement"));
    gate.release();HYLE_RETURN_IF_ERROR(context.drain());
    const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(5);
    while(metadata.used()!=program_metadata && std::chrono::steady_clock::now()<deadline)std::this_thread::sleep_for(std::chrono::milliseconds(1));
    HYLE_RETURN_IF_ERROR(require(metadata.used()==program_metadata && guards.active_batches()==0,"abandoned common receiver did not retire original owner metadata/guards"));
    HYLE_ASSIGN_OR_RETURN(auto next,c::BatchInvocation::create(program,queue));HYLE_RETURN_IF_ERROR(next.drain());
    std::fprintf(stderr,"common CUDA receiver pending aggregate/owner abandon retains then retires original slot/metadata/guards PASS\\n");return Status::Ok();
  }
  fail_source=mode==Mode::late_source_error;gate.release();const auto terminal=submitted.wait();
  HYLE_RETURN_IF_ERROR(require(!fail_source && terminal.IsResourceExhausted() && !receiver.output(),"source failure was hidden by successful original native suffix"));
  HYLE_ASSIGN_OR_RETURN(update,receiver.take_update());
  HYLE_RETURN_IF_ERROR(require(!update.take_mutable({1}) && receiver.prepare_batch(layout).IsFailedPrecondition(),"late failed source/epoch fabricated ready output or reuse"));
  std::fprintf(stderr,"common CUDA receiver source risk=%u unknown/late source failure merges original terminal and refuses output/reuse PASS\\n",unsigned(mode));return Status::Ok();
''')
# The success-only recovery tail is not part of the three risk episodes.
start=s.index('  std::array<std::uint16_t,128> actual{};');end=s.index('\n}\n}\nint main()',start);s=s[:start]+s[end:]
start=s.index('int main()');s=s[:start]+'''int main(){bool failed=false;for(auto mode:{Mode::known_source_error,Mode::unknown_before_acceptance,Mode::late_source_error,Mode::abandon,Mode::cpu_foreign_queue}){const auto status=run(mode);if(!status.ok()){
  std::fprintf(stderr,"CUDA receiver risk=%u: %.*s\\n",unsigned(mode),int(status.message().size()),status.message().data());failed=true;
}}return failed?1:0;}
'''
s=s.replace('&::query','&query_event').replace('cudaError_t query(cudaEvent_t event)','cudaError_t query_event(cudaEvent_t event)')
index=s.rfind('\n}\n}\nint main()');assert index!=-1
s=s[:index]+'''
  }();
  if(!status.ok())std::fprintf(stderr,"risk observed before cleanup: %.*s\\n",int(status.message().size()),status.message().data());
  gate.release();context.drain().IgnoreError();
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(5);
  while((metadata.used() || source_metadata.used()) && std::chrono::steady_clock::now()<deadline)std::this_thread::sleep_for(std::chrono::milliseconds(1));
  HYLE_RETURN_IF_ERROR(require(metadata.used()==0 && source_metadata.used()==0,"risk teardown did not retire original metadata"));
  return status;
'''+s[index:]
(root/'tests/compute_batch/pending_paged_receiver_cuda_risks.cc').write_text(s,newline='\n')
