from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
root=Path.cwd();out=root/'.scratch/inference-gaps/g03/common-receiver-air';out.mkdir(exist_ok=True)
names=['include/hyle/compute/batch_execution.h','src/compute_batch/batch_execution.cc','tests/compute_batch/pending_paged_receiver_cpu_consumer.cc','tests/compute_batch/pending_paged_receiver_cpu_risks.cc','tests/compute_batch/allocation_fault_fixture.h']
attempt=1
while (out/f'input-{attempt}.zip').exists():attempt+=1
archive=out/f'input-{attempt}.zip';inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in names:
  data=(root/name).read_bytes();inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()));z.writestr(name,data)
 z.writestr('input-manifest.json',json.dumps(inputs,indent=2)+'\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-common-receiver';options=['-o','BatchMode=yes','-o','ConnectTimeout=12']
subprocess.run(['ssh',*options,host,'mkdir -p '+remote],check=True)
subprocess.run(['scp',*options,str(archive),str(root/'.scratch/inference-gaps/g03/common_receiver_air.py'),host+':'+remote+'/'],check=True)
code=subprocess.run(['ssh',*options,host,f'python3 {remote}/common_receiver_air.py {archive.name}'+(' --risks-only' if '--risks-only' in sys.argv else '')]).returncode
subprocess.run(['scp',*options,host+':'+remote+'/result.json',str(out)],check=True)
if code==0:subprocess.run(['scp',*options,host+':'+remote+'/raw.zip',str(out)],check=True)
raise SystemExit(code)
