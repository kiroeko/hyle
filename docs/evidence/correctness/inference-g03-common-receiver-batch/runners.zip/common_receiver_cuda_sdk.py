from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path('/root/hyle-scratch/compute-unified');canonical=Path('/mnt/c/public/project-hyle/hyle');source=base/'source-7a7b4c3b';out=canonical/'.scratch/inference-gaps/g03/common-receiver-cuda-sdk';out.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
names=['include/hyle/compute/batch_execution.h','src/compute_batch/batch_execution.cc','tests/compute_batch/pending_paged_receiver_cuda64_consumer.cc']
inputs=[dict(path=n,sha256=hashlib.sha256((canonical/n).read_bytes()).hexdigest()) for n in names]
assert all((canonical/n).read_bytes()==(source/n).read_bytes() for n in names)
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
def run(mode,stage,args):
 attempt=1+sum(r['mode']==mode and r['stage']==stage for r in rows);log=out/f'{mode}-{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT);(out/'job.json').write_text(json.dumps(dict(state='RUNNING',pid=p.pid,mode=mode,stage=stage,log=str(log))))
  print('RUN',mode,stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(mode=mode,stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,inputs=inputs,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n');(out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)))
 print(mode,stage,code,flush=True)
 if code:print(log.read_text(errors='replace')[-4500:],flush=True);raise SystemExit(code)
for mode in ['static','shared']:
 producer=base/f'l-cpu-cuda/selected-graph/{mode}-sdk-build';work=base/f'g03-common-receiver-cuda-{mode}-sdk';work.mkdir(exist_ok=True);staging=work/'staging';prefix=work/'relocated';parent=work/'consumer';parent.mkdir(exist_ok=True);build=work/'build'
 run(mode,'producer-configure',['cmake','-S',str(source),'-B',str(producer)])
 snapshot=producer/'g03-common-receiver-sdk-preflight.ninja';original=(producer/'build.ninja').read_bytes();snapshot.write_bytes(original)
 targets=['hyle_compute_batch','hyle_compute_provider_flashinfer','hyle_compute_route_cpu']
 dry=subprocess.run(['ninja','-C',str(producer),'-f',str(snapshot),'-n',*targets],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (out/f'{mode}-dry-run.log').write_text(dry.stdout);assert dry.returncode==0 and 'Re-running CMake' not in dry.stdout
 if '.cu.o' in dry.stdout or 'nvcc' in dry.stdout:
  (out/f'{mode}-kernel-build-required.json').write_text(json.dumps(dict(verdict='UNPROVEN_NO_BUILD',kernel_lines=[l for l in dry.stdout.splitlines() if '.cu.o' in l or 'nvcc' in l])))
  print('UNPROVEN',mode,'prohibited kernel rebuild; continue other profile',flush=True);continue
 commands=json.loads(subprocess.check_output(['ninja','-C',str(producer),'-t','compdb'],env=env,text=True))
 backend=[r for r in commands if r['file'].endswith('src/compute_backend_cuda/cuda_backend.cc')];assert len(backend)==1 and 'HYLE_TESTING' not in backend[0]['command']
 (out/f'{mode}-shipping-backend-command.json').write_text(json.dumps(backend,indent=2)+'\n')
 run(mode,'producer-build',['cmake','--build',str(producer),'--target',*targets,'--parallel','4'])
 assert not prefix.exists(),'do not overwrite prior relocated delivery'
 run(mode,'install',['cmake','--install',str(producer),'--prefix',str(staging)]);staging.rename(prefix)
 assert (prefix/'include/hyle/compute/batch_execution.h').read_bytes()==(canonical/'include/hyle/compute/batch_execution.h').read_bytes()
 (parent/'main.cc').write_bytes((canonical/'tests/compute_batch/pending_paged_receiver_cuda64_consumer.cc').read_bytes())
 (parent/'header.cc').write_text('#include <hyle/compute/batch_execution.h>\n')
 (parent/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(common_cuda_receiver_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(receiver main.cc)
add_library(headers OBJECT header.cc)
foreach(t receiver headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${t} PRIVATE hyle::compute)
endforeach()
hyle_stage_runtime(receiver)
''')
 run(mode,'configure',['cmake','-S',str(parent),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 run(mode,'consumer-build',['cmake','--build',str(build),'--target','receiver','headers','--parallel','4'])
 commands=json.loads((build/'compile_commands.json').read_text());assert len(commands)==2 and all(str(source) not in r['command'] and str(prefix/'include') in r['command'] for r in commands)
 (out/f'{mode}-compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n');run(mode,'public64',[str(build/'receiver')])
 receipts=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in (prefix/'lib').glob('libhyle_compute*') if p.is_file() and (p.name.startswith('libhyle_compute_batch') or p.name.startswith('libhyle_compute_backend_cuda') or p.name.startswith('libhyle_compute_provider_flashinfer'))]
 (out/f'{mode}-artifact-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
(out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=0)));print('SDK BATCH TERMINAL; inspect per-profile verdicts',flush=True)
