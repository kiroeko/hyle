from pathlib import Path
import difflib
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
O = R / 'docs/evidence/correctness'
NAME = 'inference-graph-assembly-2026-10-24'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf8')

regression = read(D / 'regression/proof-summary.json')
assert regression['state'] == 'passed'
source = read(D / 'source-checks.json')
assert all(c['pass'] for c in source['checks'])
main = R / 'engine/models/qwen35/main.cc'
assert pin(main)['sha256'] == source['main_sha256']
syntax = read(D / 'probe-syntax/process.json')
assert syntax['exit'] == 0 and not syntax['timeout']
probe = Path('tests/tools/qwen_mtp_projection_width_probe.cc')
patch = ''.join(difflib.unified_diff(
    (D / 'before' / probe).read_text().splitlines(True),
    (R / probe).read_text().splitlines(True),
    fromfile='before/' + probe.as_posix(), tofile='after/' + probe.as_posix()))
(D / 'probe.patch').write_text(patch, encoding='utf8')
after = [pin(main), pin(R / probe)]
save(D / 'integration-after-pins.json', after)
archive = O / (NAME + '.zip')
assert not archive.exists()
allowed = {'.cc', '.h', '.py', '.md', '.json', '.jsonl', '.log', '.patch', '.txt', '.ps1', '.ids'}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    with zipfile.ZipFile(D / 'regression/proof.zip') as original:
        for item in original.infolist():
            assert not item.is_dir()
            out.writestr('regression/' + item.filename, original.read(item))
    for folder in ['before', 'probe-syntax']:
        for p in sorted((D / folder).rglob('*')):
            if p.is_file() and p.suffix in allowed:
                out.write(p, 'additional/' + p.relative_to(D).as_posix())
    for name in ['source-checks.json', 'after-pins.json', 'changes.patch',
                 'graph_observation.h', 'integration-review.md', 'probe.patch',
                 'probe-before-pin.json', 'integration-after-pins.json',
                 'next-observation-boundary.md', 'publish.py']:
        out.write(D / name, 'additional/' + name)
    for p in [main, R / probe]:
        out.write(p, 'canonical/' + p.relative_to(R).as_posix())

report = dict(
    state='passed', date='2026-10-24',
    scope='Cold graph assembly versus model equations within the global ordinary/MTP, multi-session and multi-request architecture.',
    changes=[
        'Recipe borrows concrete GraphAssembly instead of Backend and no longer owns allocation resources, CPU region state, constant leases or placement/options vectors.',
        'Assembly retains original Borrow/StorageOwner/ReadLease rules and literal lifetimes for all four preparation entries.',
        'CPU FFN scope is selected outside model equations; the attention residual Add stays before that scope.',
        'Two external projection probe callers migrated directly without compatibility aliases.'
    ],
    source_review=dict(assertions=len(source['checks']), evidence=pin(D / 'source-checks.json'),
                       integration=pin(D / 'integration-review.md')),
    actual_consumer_regression=regression,
    external_probe_syntax=dict(state='passed', compiler_flags='/O2 /W4 /WX /Zs', process=syntax),
    canonical_sources=after,
    limitations=[
        'Finite Windows CPU/Vulkan fixture and existing request regression only; no full trained-model, task-quality, all-platform or throughput claim.',
        'Cold graph observation is private instrumentation and is absent from product source.',
        'Cross-family generation/state adapters, reporting separation and worklist convergence remain unfinished.',
        'Architecture documentation specifies serialized Model/Session control; current finite FIFO schedules do not provide online queue backpressure or latency guarantees.'
    ],
    SDK_builds=0, downloads_bytes=0, HTTP_requests=0,
    archive=pin(archive),
    cleanup='Remove this batch private check images/objects via root test.ps1 after publication; retain commands, source, results, cached inputs and corrected production closure.'
)
save(O / (NAME + '.json'), report)
print(json.dumps(dict(report=pin(O / (NAME + '.json')), archive=pin(archive))))
