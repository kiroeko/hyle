# 下一小片：无模型依赖的执行观察事实与 CLI formatter

只读当前 main（GraphAssembly 后）；无产品编辑、构建、模型或网络操作。

## 已有真实共用点
- main.cc:84–99 的 StepObservation/PreparationObservation 只有 host 值、Graph ReplayRoute/NodeId 与 Compute BatchPlanReport，无 Qwen geometry/state/codec。
- Model::finish_selected_evaluations :4118–4145 在完整 head/ledger 提交后填 StepObservation；自然 Text/MTP 共用此处。
- 固定 replay 的 SessionRun observations :5960、prepare/finish :6385–6394、末尾输出 :6476–6482 已复用同一类型及同一 formatter。
- print_step_observation :101 和 print_preparation_observation :117 也不读 Model，只固定写 cerr；这是能立即抽取的真实依赖边界。
- 可删 main 的这两个类型和两个格式化函数，直接使用 inference 的事实类型、CLI reporting 的函数；无旧名兼容别名。

## 一个具体可执行切片
- 新 engine/inference/execution_observation.h 原样存这两个记录；保原字段/default/reserve 行为，不另建指标表或事件注册器。
- 新 engine/reporting/execution_report.h/.cc 声明/实现 write_step_observation(ostream&,const StepObservation&) 与 write_preparation_observation(ostream&,const StepObservation&,const PreparationObservation&)。
- 两函数输出字节/precision-save-restore 语义原样，只把 cerr 变显式流；格式化不写状态、不调 Graph、不碰 ledger_observed。
- main 的 2 处 step writer 与 1 处 preparation writer 传 cerr；Model 当前 fallback writer 仍在原提交后/trace前的同一位置调用，先不改变失败时输出次序。
- mtp_session_probe.cc:258/484/751 的直接类型引用一起迁；其它 probes 可通过 Model 形参自然使用，不加模型限定 alias。
- CMake 把真实 reporting .cc 加入 hyle_engine；需要直接 include main 的诊断目标也链接该小对象，不能靠 include .cc/.inc 凑符号。
- 此步使新模型/独立 Graph 消费者可直接上报相同执行事实；普通/MTP/固定输入不再依赖 Qwen 类型来消费执行进度。
- 刻意不同时把所有 JSON writer/请求控制搬文件；以上对象不拥有 runtime/queue/tensor/lease，不新增热 heap、转换或 kernel。

## 提交、观察和 trace 的不可混淆边界
- :4090–4110 先完成 expected-base 检查和无抛 head 交换，再置 record.committed/推进 committed_count；保持为模型事务唯一权威。
- :4118 先写 endpoint/step_seconds，再做 preparation report/trace；异常不表示没有提交。
- observe_generation_commits :4602 以 ledger_observed 顺序消费已提交事实；:5087 catch 会补观察，不能移 cursor 到 reporter 或从 stdout 成功反推提交。
- 它仍重建 MtpRoundResult、更新 draft/repair 统计并判断模型 EOS；不要整函数迁进 engine/inference，或新增 entry→event 第二份账本。
- 原 rounds/generated 的 reserve 容量与 observed++ 时点保留；这里不承诺可恢复的任意 ostream 故障或外部 exactly-once 网络投递。
- 固定 replay :6404–6457 用显式 phase/call 和已知 token tape 更新 summaries/generated/saved_pending；没有自然 ledger，不能为统一观察偷偷造 MTP ledger。
- 未来将 fallback writer 移出 Model 时，需要先把 postcommit 观察完整捕获到调用方，再按提交见证补一次观察；不能先搬打印，再让 trace 失败漏事件。
- 原 tensor/state trace :4146–4186 读真实 generated_logits/hidden/probe_views/Session head；捕获仍留原完成边界，不能延后借裸 TensorView 给 CLI。

## entry/report 仍应保留的内容
- CLI grammar/参数、JSON 字段、用户 ID 命名、路径/文件 IO、step 文本格式属于入口/reporting。
- Model 的实际资源/权重数量/未知 native-private 开销查询仍从原 owner/CompileReport 得到；writer 只读结果，不维护另一份容量或源身份。
- print_generation_request/rebuild :5131/:5145 和自然汇总 :5531 后可下一批借原 RequestProgress/host observations 拆出，但目前仍直接读 GenerationRequest/Model，不应原样宣称通用。
- 固定 replay 的 Wave/BatchObservation 与自然请求 BatchObservation 的时间口径和 restore 语义不同；可共用底层执行事实，不强并为同一调度算法。

## 文档核对与有限复用
- docs/architecture/inference-design.md 已明确普通/MTP/多轮/多会话/多请求整体范围、N/R/真实 batch、三层缓存、提交后观察和固定 tape 差异。
- 同文明确平台原生 FIFO/Queue、精度和 StateHead/Snapshot 不必同形；未把多后端编入等同全部组合支持，当前边界清楚。
- 可补一句“执行观察事实可共用，CLI formatter 与权威提交/模型 trace 捕获分离”；不需要重写全局设计或新增架构模块清单。
- 验收只复用本批 Text N2R2/MTP 与固定 replay 的原日志，逐字比两 formatter 输出；晚 IO 幂等测试保持 ledger_observed/IDs/游标不变。
