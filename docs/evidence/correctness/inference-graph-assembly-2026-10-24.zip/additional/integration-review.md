# GraphAssembly integration review

Scope: cold Qwen graph assembly versus model equations, on top of the global
ordinary/MTP and multi-request architecture. This batch does not finish the
cross-model controller or move model-specific tensors into a universal container.

- `Recipe` now borrows a concrete `GraphAssembly`. It no longer owns Backend,
  allocation resource, CPU-region state, placement vectors or constant leases.
  Equations, projection/codec binding calls and symbolic dimensions remain there.
- `GraphAssembly` retains the actual constant views, StorageOwner and ReadLease
  policy. Borrow remains Borrow; process-system retained leases remain legal.
  No stricter resource admission, provider choice or numerical precision was added.
- Primary storage 0 and optional CPU storage 1 use the existing Backend domain
  table. `resource_for(1)` selects the same host endpoint as the original CPU FFN
  helper. This private assembly does not introduce another endpoint registry.
- The attention residual Add is constructed before entering the CPU FFN scope,
  matching C++ argument evaluation before the original ffn call. The FFN's own
  residual remains within its selected scope. RAII restores location on failure.
- Literal creation preserves datatype and value conversion. Family literals move
  into the definition before compilation, as before; draft/prefix/frontier move
  after compilation. The Backend still outlives the prepared graphs and literals.
- Five operation/View placement points, four compile-option sites and four
  literal-owner moves migrated in place. The runtime from `sample_prefix` onward
  is unchanged; there is no per-token allocation, conversion or routing addition.
- The two external Recipe users in `qwen_mtp_projection_width_probe.cc` were
  migrated directly, without compatibility aliases. Strict CPU syntax checking
  passed. Its original large projection data was not rerun for this caller change.

The accompanying source assertions are source evidence only. Actual graph/options
and consumer equivalence are reported separately by the finite regression.
Whole-model quality, other backends and throughput are outside this batch's claim.
