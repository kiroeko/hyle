"""Two finite consumers, old mixed reference then current shared request cases."""
from pathlib import Path
import difflib,importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
PREVIOUS=R/'.scratch/inference-request-boundaries-20261024/regression'
BASE=R/'.scratch/mtp-request-unification-20261024/regression'
FIXTURE=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
OLD='old3';CURRENT='current3'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def require(ok,message):
    if not ok:raise ValueError(message)
def put(path,text):
    with path.open('x',encoding='utf8',newline='\n')as out:out.write(text)
def instrument(text):
    prefix='''#include "graph_observation.h"
namespace private_observer {
inline std::ostream* stream=nullptr;
template<class Backend,class Graph,class Constants,class Options,class Packed>
auto compile(Backend& backend,std::string_view label,const Graph& graph,const Constants& constants,Options options,const Packed& packed){
  if(stream)graph_observation::write(*stream,label,graph,options,packed);
  return backend.compile(graph,constants,options);
}
}
'''
    require(text.count('namespace qwen35 {')==1,'Model namespace entry changed')
    text=text.replace('namespace qwen35 {',prefix+'\nnamespace qwen35 {')
    needle='execution.compile(';parts=[];start=0
    for label in['family','draft','prefix','frontier']:
        at=text.find(needle,start);require(at>=0,'Missing original compile site '+label)
        end=at+len(needle);depth=1
        while depth:
            char=text[end];depth+=int(char=='(')-int(char==')');end+=1
        arguments=text[at+len(needle):end-1]
        parts.append(text[start:at]+'private_observer::compile(execution, "'+label+'", '+arguments+', r.packed_projection_nodes)')
        start=end
    require(needle not in text[start:],'Unexpected extra original compile site')
    return ''.join(parts)+text[start:]
def prepare():
    require(b.pin(PREVIOUS/'summary.json')['sha256']=='8ee89bc7c7e1f0841de3ebd106c24245c93a560e13291900d520a149bf912ab2','Previous actual reports changed')
    require(b.pin(PREVIOUS/'source/engine/models/qwen35/main.cc')['sha256']=='b06483f165e4ce51680187c20082e1ef687a30999591412d02d27c592923aa62','Wrong b064 baseline')
    reference=D/'reference';reference.mkdir(parents=True,exist_ok=False)
    b.save(reference/'reports.json',b.read(PREVIOUS/'summary.json')['reports'])
    for name in['summary.json','proof-summary.json','source-pins.json']:
        shutil.copyfile(PREVIOUS/name,reference/('previous-'+name))
    shutil.copyfile(BASE/'current4/link/command.json',reference/'link-command.json')
    shutil.copyfile(BASE/'current4/link/pins.json',reference/'link-pins.json')
    probe=(PREVIOUS/'probe.cc').read_text(encoding='utf8')
    require(probe.count('int main(')==1,'Unexpected consumer entry count')
    pos=probe.index('int main(')
    probe=probe[:pos]+(D/'mixed.inc').read_text()+ '\n'+probe[pos:]
    probe=probe.replace('#include "engine/models/qwen35/main.cc"','#include "engine/models/qwen35/main.cc"\n#include "hyle/compute/detail/paged_arena_access.h"')
    before='    text(argv[1],out);\n    greedy_recovery_and_late_io(argv[1],out);\n    mtp(argv[1]);fixed_cli(argv[1],out/"fixed");return 0;'
    require(probe.count(before)==1,'Unexpected previous actual sequence')
    probe=probe.replace(before,'    mixed(argv[1],out/"mixed");\n#ifndef PRIVATE_BASELINE_ONLY\n'+before.replace('return 0;','')+'\n#endif\n    return 0;')
    put(D/'probe.cc',probe)
    b.save(D/'baseline-pins.json',dict(previous=b.pin(PREVIOUS/'summary.json'),reports=b.pin(reference/'reports.json'),fixture=[b.pin(p)for p in FIXTURE.glob('*')if p.is_file()],closure=dict(route=b.pin(BASE/'native-program-fixed/archive/route.lib'),native_region=b.pin(BASE/'native-region-fixed2/compile/unit.obj')),scope='Old b064 ONLY new CPUFFN1+Vulkan mixed math/state/cold reference; current same mixed plus prior actual natural/greedy/MTP/fixed cases.',SDK_builds=0,HTTP=0))
    freeze('old')
def freeze(mode):
    dest=D/mode/'source';dest.mkdir(parents=True,exist_ok=False);original=PREVIOUS/'source'if mode=='old'else R;records=[]
    expected='b06483f165e4ce51680187c20082e1ef687a30999591412d02d27c592923aa62'if mode=='old'else'f5da4b87bbf51ebc8382db0424d85b07b247237add248470e63360a2972a7117'
    main=original/'engine/models/qwen35/main.cc';require(b.pin(main)['sha256']==expected,'Model source not final freeze '+mode)
    paths=[main,*(original/'engine/models/qwen35').glob('*.h'),*(original/'engine/inference').glob('*.h')]
    for p in paths:
        out=dest/p.relative_to(original);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());records.append(dict(original=b.pin(p),frozen=b.pin(out)))
    observed=dest/'engine/models/qwen35/main.cc';before=observed.read_text();after=instrument(before);observed.write_text(after,encoding='utf8',newline='\n')
    put(D/mode/'observation-only.patch',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='frozen original main',tofile='private cold observed main')))
    helper=R/'.scratch/inference-graph-assembly-20261024/graph_observation.h';require(b.pin(helper)['sha256']=='64ac76db02bf8535641307a3cebdab8f55ad41aa7726fadee1fa657d4a03ba77','Cold helper final source changed')
    shutil.copyfile(helper,dest/'graph_observation.h');shutil.copyfile(D/'probe.cc',dest/'probe.cc')
    b.save(D/mode/'source-pins.json',dict(original_records=records,actual=[b.pin(p)for p in dest.rglob('*')if p.is_file()],instrumentation='Four actual compile calls wrapped only to serialize the exact graph/options/packed chains; graph and options passed unchanged.',baseline_only=mode=='old'))
def revise():
    helper=R/'.scratch/inference-graph-assembly-20261024/graph_observation.h'
    require(b.pin(helper)['sha256']=='d1b733d2ac7b12cc67052307f7118c3df045f9704c2ae823322b116e81834cfd','Descriptor Status correction is not yet stable')
    before='q::GenerationLedger ledger(3,3);const std::array p2{std::size_t{2}},ordinary_chunks{std::size_t{2},std::size_t{1}},t3{std::size_t{3}};'
    after='q::GenerationLedger ledger(3,3);const std::array p2{std::size_t{2}};const std::array ordinary_chunks{std::size_t{2},std::size_t{1}};const std::array t3{std::size_t{3}};'
    probe=(D/'probe.cc').read_text();require(probe.count(before)==1,'Private array correction target changed');probe=probe.replace(before,after)
    for original,name in[('old','old2'),('current','current2')]:
        target=D/name/'source';shutil.copytree(D/original/'source',target)
        target.joinpath('probe.cc').write_text(probe,encoding='utf8',newline='\n');shutil.copyfile(helper,target/'graph_observation.h')
        changes={}
        for relative in['probe.cc','graph_observation.h']:
            left=(D/original/'source'/relative).read_text();right=(target/relative).read_text();changes[relative]=''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='retained original/'+relative,tofile='private correction/'+relative))
        b.save(D/name/'source-pins.json',dict(actual=[b.pin(p)for p in target.rglob('*')if p.is_file()],parent=b.pin(D/original/'source-pins.json'),private_fixture_instrument_corrections=changes,canonical_product_changes=0))
def revise_plan():
    for original,name in[('old2',OLD),('current2',CURRENT)]:
        target=D/name/'source';shutil.copytree(D/original/'source',target)
        before=(target/'probe.cc').read_text();after=before.replace('plan_replay_uses(3,2,1,','plan_replay_uses(3,1,2,').replace('plan_replay_uses(1,2,1,','plan_replay_uses(1,1,2,')
        require(after!=before,'Actual replay-use parameter correction missing')
        target.joinpath('probe.cc').write_text(after,encoding='utf8',newline='\n')
        b.save(D/name/'source-pins.json',dict(actual=[b.pin(p)for p in target.rglob('*')if p.is_file()],parent=b.pin(D/original/'source-pins.json'),private_fixture_correction='plan_replay_uses(tokens,requests,count) now uses real R1/count2, not missing R2/count1',changes=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True))),canonical_product_changes=0))
def build(mode):
    root=D/mode;target=root/'source';folder=root/'compile';original=b.args(PREVIOUS/'compile/command.json');command=[original[0],'/I'+str(target)];skip=False
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        if lower.startswith('/i')and '/.scratch/'in lower and lower.endswith('/source'):continue
        command.append(word)
    if mode.startswith('old'):command.append('/DPRIVATE_BASELINE_ONLY=1')
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(target/'probe.cc'),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.environment(command[0]);b.execute(command,folder,env,180)
    link_existing(mode)
def link_existing(mode):
    root=D/mode;target=root/'source';folder=root/'compile';require(b.read(folder/'process.json')['exit']==0,'Cannot link failed compilation')
    env=b.environment(b.args(folder/'command.json')[0])
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    leaks=[str(p)for p in deps if p.is_relative_to(R/'engine')or(p.is_relative_to(R/'.scratch')and not p.is_relative_to(target))]
    require(not leaks,'Frozen engine/private headers leaked: '+repr(leaks))
    pins=[b.pin(p)for p in deps if p.is_relative_to(R)];b.save(folder/'self-header-pins.json',pins)
    prior={p['path'].lower():p for p in b.read(PREVIOUS/'compile/self-header-pins.json')if Path(p['path']).is_relative_to(R/'include')}
    # The new complete-state witness reads paged arenas through the original
    # already-executed GA regression's exact four detail-header inputs.
    supplement_path=R/'.scratch/mtp-state-ports-20261024/gdn-regression/gdn2/current/compile/self-header-pins.json'
    supplement={p['path'].lower():p for p in b.read(supplement_path)if Path(p['path']).name in['paged_arena_access.h','copy_stream_access.h','copy_ranges.h','std_allocator.h']}
    extras=[p for p in pins if Path(p['path']).is_relative_to(R/'include')and p['path'].lower()not in prior]
    require(all(p['path'].lower()in supplement and all(p[k]==supplement[p['path'].lower()][k]for k in['bytes','sha256'])for p in extras),'New complete-state witness header is not the actual prior GA input')
    b.save(folder/'additional-state-witness-headers.json',dict(prior_actual_GA_inputs=b.pin(supplement_path),additional=extras,scope='Only headers newly included for immutable logical page state readback; no changed prior public ABI header.'))
    prior.update(supplement)
    require(all(p['path'].lower()in prior and all(p[k]==prior[p['path'].lower()][k]for k in['bytes','sha256'])for p in pins if Path(p['path']).is_relative_to(R/'include')),'Public ABI inputs changed; inspect existing corrected closure')
    previous=b.args(D/'reference/link-command.json');old=str(BASE/'current3/compile/unit.obj');require(previous.count(old)==1,'Previous cleaned app entry is not uniquely recorded')
    out=root/'link';link=[str(folder/'unit.obj')if word==old else word for word in previous if not word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')];b.execute(link,out,env,120)
    for path in(BASE/'current4/link').glob('*.dll'):os.link(path,out/path.name)
    b.save(out/'pins.json',dict(image=b.pin(out/'probe.exe'),object=b.pin(folder/'unit.obj'),baseline_link=b.pin(D/'reference/link-command.json'),native=[b.pin(p)for p in out.glob('*.dll')],SDK_builds=0))
def run(mode):
    root=D/mode;env=b.environment(b.args(root/'compile/command.json')[0]);env.update({k:v for k,v in b.read(b.VK/'runtime.json').items()if isinstance(v,str)})
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');env['PATH']=str(root/'link')+';'+env['PATH']
    for row in b.read(D/'baseline-pins.json')['fixture']:
        now=b.pin(Path(row['path']));require(all(now[k]==row[k]for k in['bytes','sha256']),'Pinned cached A fixture changed')
    b.execute([str(root/'link/probe.exe'),str(FIXTURE/'weights.tsv'),str(root/'output')],root/'run',env,90)
    reports=[json.loads(line)for line in(root/'run/stdout.log').read_text().splitlines()if line.startswith('{')];b.save(root/'reports.json',reports)
    if mode==CURRENT:audit()
def audit():
    old=b.read(D/OLD/'reports.json');current=b.read(D/CURRENT/'reports.json');prior=b.read(D/'reference/reports.json')
    require(len(old)==2 and[current[i].get('private_facts')for i in range(2)]==['mixed-ordinary','mixed-MTP'],'Mixed old/new report boundaries differ')
    require(old==current[:2],'Actual mixed committed ledger/numerical/RNG/resource facts differ')
    differences=[];ignored=[];additions=[]
    def compare(before,after,path):
        if isinstance(before,dict):
            if not isinstance(after,dict):differences.append(path+':type');return
            additions.extend(path+'.'+k for k in after.keys()-before.keys())
            for key,value in before.items():
                child=path+'.'+key
                if key=='seconds'or key.endswith('_seconds')or'tokens_per_second'in key:ignored.append(child);continue
                if key not in after:differences.append(child+':missing');continue
                compare(value,after[key],child)
        elif isinstance(before,list):
            if not isinstance(after,list)or len(before)!=len(after):differences.append(path+':length/type');return
            for i,(left,right)in enumerate(zip(before,after)):compare(left,right,path+'['+str(i)+']')
        elif before!=after:differences.append(path+':'+repr(before)+' -> '+repr(after))
    compare(prior,current[2:],'prior_actual_reports')
    records=[]
    for p in sorted((D/OLD/'output/mixed').rglob('*')):
        if not p.is_file()or p.suffix in['.tsv']:continue
        counterpart=D/CURRENT/'output/mixed'/p.relative_to(D/OLD/'output/mixed');require(counterpart.is_file(),'Mixed state/graph record disappeared')
        equal=p.read_bytes()==counterpart.read_bytes();records.append(dict(relative=p.relative_to(D/OLD/'output/mixed').as_posix(),old=b.pin(p),current=b.pin(counterpart),equal=equal))
        if not equal:differences.append('mixed.'+str(p.relative_to(D/OLD/'output/mixed'))+':bytes')
    graphs=[json.loads(line)for line in(D/CURRENT/'output/mixed/cold-graphs.jsonl').read_text().splitlines()]
    labels=[r['label']for r in graphs if r.get('record')=='graph'];require(set(labels)=={'family','draft','prefix','frontier'},'Not all four actual cold preparation entries observed: '+repr(labels))
    result=dict(state='passed'if not differences else'failed_comparison',scope='Old b064 only new CPUFFN1+Vulkan finite ordinary P2/T1/T1 and stochastic MTP P2/K2/K2; current same mixed plus previous actual natural Text4x2/greedy recovery+lateIO/MTP K2R2/fixed replay.',differences=differences,added_report_fields=additions,ignored_timing_fields=ignored,actual_mixed_reports=old,state_and_cold_records=records,cold_labels=labels,prior_actual_reports_equal=not differences,reports=current,final_comparison_consumers=2,compile_attempts=4,actual_processes=3,actual_successful_processes=2,retained_private_compile_failures=1,retained_private_plan_runtime_failures=1,full_models=0,SDK_builds=0,HTTP=0,quality_claim=False,performance_claim=False)
    b.save(D/'summary.json',result);require(not differences,'Finite actual numerical/state/cold/report mismatch: '+repr(differences[:8]));print(json.dumps(dict(state='passed',summary=b.pin(D/'summary.json'))),flush=True)
if __name__=='__main__':
    task=sys.argv[1]
    if task=='prepare':prepare()
    elif task=='revise':revise()
    elif task=='revise_plan':revise_plan()
    elif task=='freeze_current':freeze('current')
    elif task=='audit':audit()
    else:
        action,mode=task.split('_');{'build':build,'link':link_existing,'run':run}[action](mode)
