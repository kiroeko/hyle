// Finite existing A fixture. Ordinary uses real Text roles and no NextN resources.
#include "engine/models/qwen35/main.cc"
#include "hyle/compute/detail/paged_arena_access.h"

namespace q=qwen35;
using Schedule=hyle::inference::GenerationSessionSchedule;
void require(bool yes,const char* message){if(!yes)throw std::runtime_error(message);}
q::ModelGeometry geometry(){
  q::ModelGeometry s;s.hidden=64;s.intermediate=128;s.vocabulary=64;
  s.query_heads=s.kv_heads=1;s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=s.gdn_value_heads=1;s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4;s.context_limit=16;s.rope_theta=10000;s.epsilon=1.e-6F;
  s.tied_head=true;s.layers="A";s.mtp_layers=1;s.validate();return s;
}
std::vector<q::cache::TokenPlanRef> plans(const std::vector<Schedule>& schedules){
  std::vector<q::cache::TokenPlanRef> result;
  for(const auto& schedule:schedules){
    result.push_back(q::cache::token_plan(schedule.turns.front().prompt,16));
  }
  return result;
}
void retired(const q::Model& model){
  require(!model.active_step&&!model.carrier_borrowed&&model.snapshot_versions.live==0,
    "natural request run retained an admitted state or execution carrier");
}
void mtp(const std::filesystem::path& manifest){
  const auto shape=geometry();const auto plan=q::cache::plan(shape,16,2,3,
    q::recurrent_bytes(q::state_schema_for(shape,16),shape),2,3,true,true);
  q::Model model(manifest,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
    {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
  model.configure_draft_policy({.max_drafts=2});
  const std::vector<Schedule> schedules{{"m0",{{{1,2},4}}},{"m1",{{{1,2},4}}}};
  const auto input=plans(schedules);const auto start=q::Clock::now();
  require(q::run_generation_sessions<q::GenerationMode::kMtp>(model,schedules,{},false,start,start,true,input)==0,"current natural MTP run failed");
  retired(model);require(model.draft_program_graph_calls>0&&model.prefix_decision_graph_calls>0,"natural K2 proposal/acceptance graph was not executed");
  std::cout<<"{\"private_facts\":\"MTP\",\"retired\":true,\"K2_requested\":true,\"draft_calls\":"<<model.draft_program_graph_calls
    <<",\"prefix_decision_calls\":"<<model.prefix_decision_graph_calls<<",\"full_model\":false,\"HTTP\":0}\n";
}
std::filesystem::path text_manifest(const std::filesystem::path& original,const std::filesystem::path& folder){
  const auto inventory=q::prepared::parameter_inventory(false,geometry());std::set<std::string> required;
  for(const auto& [name,unused]:inventory){(void)unused;required.insert(name);}
  std::ifstream source(original);require(bool(source),"existing cached manifest is absent");
  const auto path=folder/"text-weights.tsv";std::ofstream target(path);require(bool(target),"cannot create finite Text-only role manifest");
  std::string line;for(int i=0;i<3;++i){require(bool(std::getline(source,line)),"cached role preamble missing");target<<line<<'\n';}
  std::size_t found=0;
  while(std::getline(source,line)){std::istringstream fields(line);std::string name;fields>>name;if(required.erase(name)){target<<line<<'\n';++found;}}
  require(source.eof()&&required.empty()&&found==inventory.size()&&bool(target),"Text manifest did not select exactly all original Text roles");return path;
}
void text(const std::filesystem::path& manifest,const std::filesystem::path& folder){
  const auto shape=geometry();const auto selected=text_manifest(manifest,folder);
  const auto plan=q::cache::plan(shape,16,2,5,q::recurrent_bytes(q::state_schema_for(shape,16),shape),2,1,false,true);
  q::Model model(selected,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
    {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
  // Users2/3 reuse the original user0 complete first-turn input: two prompt
  // tokens plus the two consumed generated IDs, exactly or with one suffix.
  // The real report must independently demonstrate both distinct hit modes.
  const std::vector<Schedule> schedules{{"u0",{{{1,2},3},{{3},2}}},
    {"u1",{{{1,2},3},{{3},2}}},{"u2",{{{1,2,36,8},3},{{3},2}}},
    {"u3",{{{1,2,36,8,5},3},{{3},2}}}};
  const auto input=plans(schedules);const auto start=q::Clock::now();
  require(q::run_generation_sessions<q::GenerationMode::kText>(model,schedules,{},false,start,start,true,input)==0,"natural Text run failed");
  retired(model);require(!model.cache_plan.draft_cache&&model.cache_plan.candidate_boundaries==1&&model.physical_mtp_roles==0,
    "ordinary natural request loaded draft roles or used a draft cache plan");
  require(model.draft_programs.empty()&&model.prefix_sampling_programs.empty()&&model.draft_inventory.keys.empty()&&model.draft_inventory.values.empty()&&
    model.draft_program_graph_calls==0&&model.prefix_decision_graph_calls==0,"ordinary natural request prepared or executed NextN state/programs");
  for(const auto& [key,family]:model.families){(void)key;require(family->role==q::GraphRole::kText,"ordinary finite family used an MTP role");}
  for(const auto& [name,value]:model.weights){(void)value;require(!name.starts_with("mtp."),"ordinary source bank contains an MTP weight");}
  std::cout<<"{\"private_facts\":\"Text\",\"retired\":true,\"mtp_weights\":0,\"draft_cache\":false,\"draft_programs\":0,\"draft_arenas\":0,\"all_roles_text\":true,\"full_model\":false,\"HTTP\":0}\n";
}
void greedy_recovery_and_late_io(const std::filesystem::path& manifest,const std::filesystem::path& folder){
  const auto shape=geometry();const auto plan=q::cache::plan(shape,16,2,2,
    q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,2,true,false);
  q::Model model(manifest,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
    {.enabled=false,.policy={},.seed=0},0,{.primary=hyle::inference::BackendKind::kVulkan});
  const std::array p2{std::size_t{2}};model.prepare_family(p2,false,1,q::GraphRole::kMtpPrefill);model.plan_replay_uses(2,1,1,q::GraphRole::kMtpPrefill);
  const auto blocked=folder/"trace-is-an-existing-file";{std::ofstream file(blocked);file<<"intentional postcommit diagnostic failure\n";require(bool(file),"cannot prepare trace failure fixture");}
  auto owner=std::make_shared<std::vector<std::int32_t>>(std::initializer_list<std::int32_t>{1,2});
  q::GenerationRequest request("late-io",*owner,blocked,1);request.warm_inputs.push_back(owner);
  request.ledger=std::make_unique<q::GenerationLedger>(2,2);
  std::array calls{q::prepare_generation_call(model,request,1,nullptr,{})};
  bool failed=false;
  try{q::execute_generation_calls(model,calls,false);}catch(const std::exception& error){failed=true;std::cerr<<"expected_late_diagnostic_failure="<<error.what()<<'\n';}
  require(failed&&request.ledger->committed_count==1&&request.ledger_observed==1&&request.progress.generated.size()==1&&request.session&&request.session->length()==2,
    "late IO failure did not expose the exactly once committed head/output");
  const auto generated=request.progress.generated;auto old=request.session->head;const auto fresh=old->next_id;const auto cursor=old->sampling;const auto identity=old->state_identity();
  q::observe_generation_commits(request);q::observe_generation_commits(request);
  require(request.progress.generated==generated&&request.ledger_observed==1&&request.session->head==old,"reobserving a committed diagnostic failure duplicated output or state");
  const auto historical=(fresh+1)%64;require(historical!=fresh,"greedy recovery control does not discriminate historical pending");
  model.restore_pending_boundary(*request.session,cursor,historical);
  require(request.session->head->state_identity()==identity&&request.session->head->next_id==historical&&request.session->head->sampling==cursor&&
    old->next_id==fresh&&old->sampling==cursor&&request.session->length()==old->length,
    "greedy historical boundary restore ignored pending, changed state identity, cursor or original Snapshot");
  model.validate_mtp_snapshot(*request.session->head);
  {
    const auto input=q::cache::token_plan(*owner,16);auto history=std::make_shared<q::cache::ReplayHistory>(16);history->append(input,0,2,historical);
    q::cache::PrefixCache prefix(2);prefix.publish(input,request.session->head,{history,1,2});
    q::GenerationRequest full("fullhit-late-io",*owner,blocked,1);full.warm_inputs.push_back(owner);full.input=input;
    full.ledger=std::make_unique<q::GenerationLedger>(2,2);
    std::array hit_calls{q::prepare_generation_call(model,full,1,&prefix,{})};require(hit_calls[0].full_hit&&full.session->head->next_id==fresh,
      "greedy new full-hit request inherited another request historical pending instead of canonical fresh Top1");
    bool hit_failed=false;
    try{q::execute_generation_calls(model,hit_calls,false,&prefix);}catch(const std::exception& error){hit_failed=true;std::cerr<<"expected_fullhit_late_diagnostic_failure="<<error.what()<<'\n';}
    require(hit_failed&&full.progress.prefilled&&full.progress.turn_done&&full.progress.generated==std::vector<std::int32_t>{fresh}&&full.ledger->committed_count==1,
      "cached full-hit postcommit diagnostic failure lost or duplicated committed host output");
    q::execute_generation_calls(model,hit_calls,false,&prefix);q::execute_generation_calls(model,hit_calls,false,&prefix);
    require(full.progress.generated==std::vector<std::int32_t>{fresh}&&full.ledger->committed_count==1&&full.ledger->records[0].after.next_id==fresh&&
      full.session->head->sampling==cursor&&full.session->head->state_identity()==identity&&request.session->head->next_id==historical&&
      old->next_id==fresh&&old->sampling==cursor&&model.frontier_sampling_graph_calls==0,
      "repeating a completed full-hit call duplicated output, ledger or a sampling event");
    hit_calls={};q::retire_generation_request(full);
  }
  std::cout<<"{\"private_facts\":\"greedy-recovery-and-late-io\",\"late_diagnostic_failure_observed\":true,\"committed_records\":1,\"observed_outputs\":1,\"observer_repetitions\":2,\"duplicate_outputs\":0,\"fresh_top1\":"<<fresh
    <<",\"historical_pending\":"<<historical<<",\"same_state_identity\":true,\"cursor_unchanged\":true,\"old_snapshot_unchanged\":true,\"fullhit_late_diagnostic_failure_observed\":true,\"fullhit_repeat_calls\":2,\"fullhit_duplicate_outputs\":0,\"natural_generation_claim\":false}\n";
  calls={};old.reset();q::retire_generation_request(request);retired(model);
}
void fixed_cli(const std::filesystem::path& original,const std::filesystem::path& folder){
  std::filesystem::create_directories(folder);
  const auto selected=text_manifest(original,folder);std::filesystem::copy_file(selected,folder/"weights.tsv");
  const auto write=[&](const char* name,const char* text){std::ofstream file(folder/name);file<<text;require(bool(file),"cannot write finite fixed replay input");};
  write("prompt1.ids","1 2\n");write("decode1.ids","3\n");write("prompt2.ids","4\n");write("decode2.ids","5\n");
  write("schedule.txt","prompt prompt1.ids\ndecode decode1.ids\nprompt prompt2.ids\ndecode decode2.ids\n");
  write("sessions.txt","f0 schedule.txt\nf1 schedule.txt\n");
  std::vector<std::string> words{"private-fixed-replay","--inputs",folder.string(),"--backend","vulkan","--mtp","off", "--capacity","16",
    "--max-sessions","2","--active-sequences","2","--cache-bytes","16777216","--prefix-cache","auto","--replay","commands","--session-schedules",(folder/"sessions.txt").string()};
  std::vector<char*> arguments;for(auto& word:words)arguments.push_back(word.data());
  std::cout<<"{\"private_fixed_begin\":true}\n";
  require(q::run(static_cast<int>(arguments.size()),arguments.data())==0,"actual fixed CLI replay failed");
  std::cout<<"{\"private_facts\":\"fixed\",\"status\":\"passed\",\"scope\":\"wiring_and_resource_only\",\"fixed_inputs\":[1,2,3,4,5],\"natural_quota_reinterpretation\":false}\n";
}
// Actual single-session CPU FFN1 + Vulkan math/state control, same old/current.
using Bytes=std::vector<std::byte>;
Bytes lease_bytes(q::Model& model,const q::c::ReadLease& lease){
  if(!lease.valid())return{};Bytes bytes(lease.size());q::check(model.execution.read(q::take(lease.view()),bytes));return bytes;
}
Bytes logical_rows(q::Model& model,const q::c::PagedArena& arena,const q::c::PagedArenaRead& frame,std::size_t rows,std::size_t row_bytes){
  const auto layout=frame.layout().host();const auto pages=(rows+15)/16;
  require(frame.valid()&&layout.page_indices.size()==pages&&frame.page_count()==pages,"logical state page footprint differs");
  Bytes bytes(rows*row_bytes);std::size_t at=0;const auto guards=q::c::detail::PagedArenaAccess::pages(frame);
  for(std::size_t i=0;i<pages;++i){
    const q::c::ReadLease* selected=nullptr;
    for(const auto& guard:guards)if(q::take(q::c::detail::PagedArenaAccess::page(arena,guard))==static_cast<std::uint32_t>(layout.page_indices[i]))selected=&guard;
    require(selected!=nullptr,"state page lost original read guard");const auto count=(std::min)(16*row_bytes,bytes.size()-at);
    q::check(model.execution.read(q::take(q::take(selected->view()).subview(0,count)),std::span(bytes).subspan(at,count)));at+=count;
  }return bytes;
}
using Image=std::map<std::string,Bytes>;
Image image(q::Model& model,const q::cache::Snapshot& head){
  Image result;require(head.state.size()==1&&!model.geometry.is_gdn(0),"mixed control must use the exact original A fixture");
  require(head.keys.size()==1&&head.values.size()==1,"mixed A state bank count differs");
  result.emplace("target.key.bf16",logical_rows(model,model.page_inventory.keys[0],head.keys[0],head.length,static_cast<std::size_t>(model.geometry.key_row_bytes())));
  result.emplace("target.value.bf16",logical_rows(model,model.page_inventory.values[0],head.values[0],head.length,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  if(head.carry_hidden)result.emplace("carry.bf16",lease_bytes(model,head.carry_hidden));
  if(head.prior_hidden)result.emplace("prior.bf16",lease_bytes(model,head.prior_hidden));
  if(head.draft){
    result.emplace("draft.key.bf16",logical_rows(model,model.draft_inventory.keys[0],head.draft->key,head.draft->frontier,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("draft.value.bf16",logical_rows(model,model.draft_inventory.values[0],head.draft->value,head.draft->frontier,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  std::ostringstream meta;meta<<"length="<<head.length<<" next="<<head.next_id<<" seed="<<head.sampling.seed<<" stream="<<head.sampling.stream<<" draw="<<head.sampling.draw;
  if(head.draft)meta<<" frontier="<<head.draft->frontier<<" lag="<<head.draft->lag<<" catchup="<<head.draft->catchup_token;
  const auto text=meta.str();result.emplace("metadata.txt",Bytes(reinterpret_cast<const std::byte*>(text.data()),reinterpret_cast<const std::byte*>(text.data()+text.size())));return result;
}
void dump(const std::filesystem::path& folder,const Image& data){
  std::filesystem::create_directories(folder);
  for(const auto& [name,bytes]:data){std::ofstream out(folder/name,std::ios::binary);out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));require(bool(out),"cannot record finite state bytes");}
}
template<class Values>void numbers(std::ostream& out,const Values& values){out<<'[';bool comma=false;for(const auto value:values){out<<(comma?",":"")<<value;comma=true;}out<<']';}
void boundary(std::ostream& out,const q::GenerationBoundary& value){
  out<<'['<<value.length<<','<<value.frontier<<','<<value.lag<<','<<value.next_id<<','<<value.catchup_token<<','<<value.sampling.seed<<','<<value.sampling.stream<<','<<value.sampling.draw<<']';
}
void ledger_report(std::ostream& out,const q::GenerationLedger& ledger){
  out<<'[';
  for(std::size_t i=0;i<ledger.committed_count;++i){const auto& r=ledger.records[i];out<<(i?",":"")<<"{\"role\":"<<static_cast<int>(r.role)<<",\"generation\":"<<r.generation<<",\"committed\":"<<r.committed<<",\"user_output\":"<<r.user_output<<",\"imported\":"<<r.imported
      <<",\"pending_input\":"<<r.pending_input<<",\"quota\":"<<r.quota<<",\"turn\":"<<r.turn<<",\"accepted\":"<<r.accepted<<",\"draft_rows\":"<<r.draft_rows<<",\"draft_limit\":"<<r.draft_limit<<",\"verified_rows\":"<<r.verified_rows<<",\"consumed_drafts\":"<<r.consumed_drafts
      <<",\"auxiliary_graph_calls\":"<<r.auxiliary_graph_calls<<",\"draft\":"<<r.draft<<",\"target_first\":"<<r.target_first<<",\"target_second\":"<<r.target_second<<",\"agreed\":"<<r.agreed<<",\"accepted_draft\":"<<r.accepted_draft<<",\"stopped\":"<<r.stopped
      <<",\"requests\":"<<r.requests<<",\"member_index\":"<<r.member_index<<",\"emitted_count\":"<<r.emitted_count<<",\"before\":";boundary(out,r.before);out<<",\"after\":";boundary(out,r.after);
    out<<",\"committed_ids\":";numbers(out,r.committed_ids());out<<",\"emitted\":";numbers(out,r.emitted);out<<",\"accepted_inputs\":";numbers(out,r.accepted_inputs);out<<",\"verification_inputs\":";numbers(out,r.verification_inputs);out<<'}';
  }out<<']';
}
void mixed_weight_contract(q::Model& model){
  const auto host=q::take(model.execution.resource_for(q::g::StorageDomainId{1}));
  require(model.cpu_ffn_layers==1&&host!=model.execution.device()&&q::take(model.execution.resource_for(q::g::StorageDomainId{0}))==model.execution.device(),"mixed actual CPU/native resource domains differ");
  std::size_t host_count=0,host_bytes=0,device_bytes=0;
  for(auto& [name,tensor]:model.weights){const bool selected=q::cpu_ffn_weight(name,1);const auto view=tensor.read();
    require(view.storage().resource()==(selected?host:model.execution.device()),"original weight has a replica or wrong allocation domain");
    const auto bytes=q::take(tensor.description.required_bytes());if(selected){++host_count;host_bytes+=bytes;}else device_bytes+=bytes;
  }
  require(host_count==4&&host_bytes==model.host_weight_bytes&&device_bytes==model.device_weight_bytes&&host_bytes+device_bytes==model.canonical_weight_bytes,"original weight bytes do not equal the sole canonical host/native allocations");
}
void retire_session(std::shared_ptr<q::Session>& session){q::check(session->stop());q::check(session->drain());require(q::take(session->try_retire()),"mixed session did not actually retire");session.reset();}
void mixed(const std::filesystem::path& original,const std::filesystem::path& folder){
  std::filesystem::create_directories(folder);const auto shape=geometry();const std::array<std::int32_t,2> prompt{1,2};
  std::ofstream cold(folder/"cold-graphs.jsonl");require(bool(cold),"cannot record actual cold Graph descriptors");private_observer::stream=&cold;
  for(const bool mtp_mode:{false,true}){
    const auto out=folder/(mtp_mode?"mtp":"ordinary");std::filesystem::create_directories(out);
    const auto manifest=mtp_mode?original:text_manifest(original,out);
    const auto plan=q::cache::plan(shape,16,4,3,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,mtp_mode?3:1,mtp_mode,true);
    q::Model model(manifest,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
      {.enabled=true,.policy={1.F,8,.9F},.seed=123},1,{.primary=hyle::inference::BackendKind::kVulkan});
    if(mtp_mode)model.configure_draft_policy({.max_drafts=2});
    q::GenerationLedger ledger(3,3);const std::array p2{std::size_t{2}},ordinary_chunks{std::size_t{2},std::size_t{1}},t3{std::size_t{3}};
    const auto role=mtp_mode?q::GraphRole::kMtpPrefill:q::GraphRole::kText;
    if(mtp_mode)model.prepare_family(p2,false,1,role);else model.prepare_family(ordinary_chunks);
    model.plan_replay_uses(2,1,1,role);
    if(mtp_mode){model.prepare_family(t3,false,1,q::GraphRole::kVerify);model.plan_replay_uses(3,2,1,q::GraphRole::kVerify);model.prepare_recursive_round_programs();}
    else model.plan_replay_uses(1,2,1,q::GraphRole::kText);
    auto session=model.create_session(p2,{},role);q::prepare_generation_record(ledger,*session,role,prompt,false,0,0);
    model.prepare_evaluation(*session,prompt,nullptr,role);model.submit_evaluation(*session);
    (void)model.finish_evaluation(*session,"mixed-P2",{},false,nullptr,nullptr,nullptr,nullptr,{},&ledger);
    require(session->length()==2&&session->head->sampling.draw==1,"mixed prefill boundary/RNG differs");
    auto base=session->head;const auto saved=image(model,*base);dump(out/"prefill",saved);
    for(std::size_t round=0;round<2;++round){
      const auto before=session->length();const std::array pending{session->head->next_id};
      if(mtp_mode){
        std::vector<q::c::ReadLease> qrows;const auto proposals=model.propose_recursive(*session,2,{},&qrows);
        require(proposals.size()==3&&qrows.size()==2,"mixed actual K2 proposal distributions missing");
        q::prepare_generation_record(ledger,*session,q::GraphRole::kVerify,pending,true,3,0,{},2);
        model.prepare_evaluation(*session,proposals,nullptr,q::GraphRole::kVerify);model.submit_evaluation(*session);
        const std::array selections{q::MtpGenerationSelection{session,pending[0],3,qrows,2}};
        const std::array outputs{q::EvaluationOutput{.session=session,.name="mixed-verify",.trace_states=false,.generation_ledger=&ledger}};
        std::array<q::MtpRoundResult,1> results;model.finish_recursive_mtp(selections,{},outputs,results);
        require(results[0].proposal_count==2&&results[0].verified_rows==3&&results[0].processed_target>0&&session->length()==before+results[0].processed_target,"mixed verifier did not publish an actual bounded accepted prefix");
        require(session->head->sampling.draw==1+5*(round+1),"mixed real stochastic prefix RNG address progression differs");
      }else{
        q::prepare_generation_record(ledger,*session,q::GraphRole::kText,pending,true,1,0);
        model.prepare_evaluation(*session,pending);model.submit_evaluation(*session);
        (void)model.finish_evaluation(*session,"mixed-T1",{},false,nullptr,nullptr,nullptr,nullptr,{},&ledger);
        require(session->length()==before+1&&session->head->sampling.draw==round+2&&!session->head->draft,"mixed ordinary continuation state/RNG differs");
      }
      model.validate_mtp_snapshot(*session->head);require(saved==image(model,*base),"mixed old complete Snapshot changed after continuation");dump(out/("round"+std::to_string(round)),image(model,*session->head));
    }
    mixed_weight_contract(model);require(ledger.committed_count==3&&model.cache_usage().peak_bytes<=16*1024*1024,"mixed ledger/budget incomplete");
    require(mtp_mode?(model.draft_program_graph_calls>0&&model.prefix_decision_graph_calls==2):(!model.physical_mtp_roles&&model.draft_programs.empty()),"mixed ordinary/MTP selected wrong physical/program scope");
    std::cout<<"{\"private_facts\":\"mixed-"<<(mtp_mode?"MTP":"ordinary")<<"\",\"cpu_ffn_layers\":1,\"original_host_weight_bytes\":"<<model.host_weight_bytes<<",\"original_device_weight_bytes\":"<<model.device_weight_bytes<<",\"canonical_weight_bytes\":"<<model.canonical_weight_bytes<<",\"duplicated_original_weight_bytes\":0,\"draft_graph_calls\":"<<model.draft_program_graph_calls<<",\"prefix_graph_calls\":"<<model.prefix_decision_graph_calls<<",\"old_snapshots_unchanged\":true,\"ledger\":";ledger_report(std::cout,ledger);std::cout<<"}\n";
    base.reset();retire_session(session);retired(model);
  }
  private_observer::stream=nullptr;require(bool(cold),"cold Graph descriptor output failed");
}

int main(int argc,char** argv){
  try{
    require(argc==3,"natural-requests EXISTING_MANIFEST PRIVATE_OUTPUT");const std::filesystem::path out=argv[2];std::filesystem::create_directories(out);
    mixed(argv[1],out/"mixed");
#ifndef PRIVATE_BASELINE_ONLY
    text(argv[1],out);
    greedy_recovery_and_late_io(argv[1],out);
    mtp(argv[1]);fixed_cli(argv[1],out/"fixed");
#endif
    return 0;
  }catch(const std::exception& error){std::cerr<<"natural request regression: "<<error.what()<<'\n';return 1;}
}
