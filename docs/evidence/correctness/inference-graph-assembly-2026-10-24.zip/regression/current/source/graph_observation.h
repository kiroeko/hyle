#pragma once
// Private, cold-only equivalence witness. Include after the frozen consumer's
// ordinary public Hyle headers; never install or call from a product hot path.
// Graph-local generations and process pointers are deliberately not persisted.
// This is limited to the real small Qwen fixture, not an all-operator serializer.

#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <optional>
#include <ostream>
#include <span>
#include <stdexcept>
#include <string_view>
#include <utility>
#include <vector>

#include "hyle/compute/batch_ops.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/sampling_ops.h"
#include "hyle/graph/batch.h"
#include "hyle/graph/executable.h"

namespace graph_observation {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;

template<class R> auto get(R result) {
  if (!result) throw std::runtime_error("cold graph observation query failed");
  return *std::move(result);
}
template<class T> constexpr auto number(T value) { return static_cast<std::uint64_t>(value); }
inline auto bits(float value) { return std::bit_cast<std::uint32_t>(value); }
inline void text(std::ostream &out, std::string_view value) {
  out << '"';
  for (const unsigned char ch : value) {
    if (ch == '"' || ch == '\\') out << '\\' << char(ch);
    else if (ch < 32) throw std::runtime_error("control character in cold observation label");
    else out << char(ch);
  }
  out << '"';
}
template<class Range> void integers(std::ostream &out, const Range &values) {
  out << '['; bool first = true;
  for (auto value : values) { if (!std::exchange(first, false)) out << ','; out << +value; }
  out << ']';
}
inline void value(std::ostream &out, g::ValueId id) {
  out << '[' << (id.valid() ? 1 : 0) << ',' << number(id.kind()) << ',' << id.ordinal() << ']';
}
inline void dimension(std::ostream &out, g::Dimension d) {
  out << '[' << (d.is_fixed() ? 0 : 1) << ',';
  if (d.is_fixed()) out << d.fixed_value(); else out << d.symbol().ordinal();
  out << ']';
}
inline void format(std::ostream &out, c::StorageFormat f) {
  out << '[' << number(f.kind()) << ',' << f.id().namespace_id << ',' << f.id().format_id
      << ',' << f.elements_per_block() << ',' << f.bytes_per_block() << ',' << f.required_alignment() << ']';
}
inline void description(std::ostream &out, const c::TensorDesc &d) {
  out << "{\"dtype\":" << number(d.data_type()) << ",\"dims\":"; integers(out, d.dimensions());
  out << ",\"strides\":"; integers(out, d.byte_strides());
  out << ",\"format\":"; format(out, d.storage_format());
  out << ",\"block_axis\":"; if (d.block_axis()) out << *d.block_axis(); else out << "null";
  out << ",\"bytes\":" << get(d.required_bytes()) << ",\"alignment\":" << d.required_alignment() << '}';
}
inline void spec(std::ostream &out, const g::TensorSpec &s) {
  out << "{\"kind\":" << number(s.kind()) << ",\"dtype\":" << number(s.data_type()) << ",\"dims\":[";
  bool first = true; for (auto d : s.dimensions()) { if (!std::exchange(first, false)) out << ','; dimension(out, d); }
  out << "],\"format\":"; format(out, s.storage_format());
  if (auto concrete = s.concrete_description()) { out << ",\"concrete\":"; description(out, *concrete); }
  out << '}';
}
inline void view(std::ostream &out, const g::ViewSpec &v) {
  out << "[" << number(v.kind()) << ',' << v.axis() << ','; dimension(out, v.start());
  out << ','; dimension(out, v.count()); out << ',' << v.step() << ",[";
  bool first = true; for (auto d : v.dimensions()) { if (!std::exchange(first, false)) out << ','; dimension(out, d); }
  out << "],"; integers(out, v.permutation()); out << ']';
}
inline void capacity(std::ostream &out, const c::BatchCapacity &x) {
  out << '[' << number(x.storage) << ',' << number(x.query_type) << ',' << number(x.output_type)
      << ',' << number(x.key_storage.data_type()) << ',' << bits(x.key_storage.scale()) << ',';
  format(out, x.key_storage.format());
  out << ',' << number(x.value_storage.data_type()) << ',' << bits(x.value_storage.scale()) << ',';
  format(out, x.value_storage.format());
  out << ',' << x.max_requests << ',' << x.max_query_rows << ',' << x.max_kv_rows << ',' << x.max_pages
      << ',' << x.max_page_refs << ',' << x.query_heads << ',' << x.kv_heads << ',' << x.qk_head_dim
      << ',' << x.value_head_dim << ',' << x.page_size << ']';
}
inline void optional_scale(std::ostream &out, std::optional<float> x) {
  if (x) out << bits(*x); else out << "null";
}

// Explicit field values only: never hash a C++ object's padding, function
// pointers, custom vtable or an owning BatchSchema's process-local pointer.
inline bool parameters(std::ostream &out, const c::Operation &op) {
  if (const auto *x = op.get_if<c::View>()) {
    out << '[' << number(x->kind()) << ',' << x->axis() << ',' << x->start() << ',' << x->count() << ',' << x->step() << ',';
    integers(out, x->shape().dimensions()); out << ','; integers(out, x->permutation()); out << ']'; return true;
  }
  if (op.get_if<c::Copy>() || op.get_if<c::Select>()) { out << "[]"; return true; }
  if (const auto *x = op.get_if<c::Fill>()) { out << '[' << number(x->output_type) << ',' << number(x->value.data_type()) << ',' << x->value.bits() << ','; integers(out, x->output_shape.dimensions()); out << ']'; return true; }
  if (const auto *x = op.get_if<c::Cast>()) { out << '[' << number(x->output_type) << ']'; return true; }
  if (const auto *x = op.get_if<c::Unary>()) { out << '[' << number(x->kind) << ']'; return true; }
  if (const auto *x = op.get_if<c::Binary>()) { out << '[' << number(x->kind) << ']'; return true; }
  if (const auto *x = op.get_if<c::Reduce>()) { out << '[' << number(x->kind) << ',' << x->axes.is_all() << ','; integers(out, x->axes.values()); out << ',' << x->keep_dimensions << ',' << number(x->accumulation_type) << ']'; return true; }
  if (const auto *x = op.get_if<c::Scan>()) { out << '[' << x->axis << ',' << x->exclusive << ']'; return true; }
  if (const auto *x = op.get_if<c::RmsNorm>()) { out << '[' << bits(x->epsilon) << ',' << number(x->accumulation_type) << ']'; return true; }
  if (const auto *x = op.get_if<c::LayerNorm>()) { out << '[' << bits(x->epsilon) << ',' << number(x->accumulation_type) << ']'; return true; }
  if (const auto *x = op.get_if<c::MatMul>()) { out << '[' << number(x->accumulation_type) << ']'; return true; }
  if (const auto *x = op.get_if<c::GatedActivation>()) { out << '[' << number(x->activation) << ',' << number(x->inputs) << ']'; return true; }
  if (const auto *x = op.get_if<c::Gather>()) { out << '[' << x->axis << ',' << number(x->bounds) << ']'; return true; }
  if (const auto *x = op.get_if<c::Scatter>()) { out << '[' << x->axis << ',' << number(x->kind) << ',' << number(x->bounds) << ']'; return true; }
  if (const auto *x = op.get_if<c::Concat>()) { out << '[' << x->axis << ']'; return true; }
  if (const auto *x = op.get_if<c::RoPE>()) { out << '[' << x->rotary_dimensions << ',' << x->sequence_axis << ',' << number(x->layout) << ']'; return true; }
  if (const auto *x = op.get_if<c::Softmax>()) { out << '[' << x->axis << ',' << bits(x->scale) << ',' << number(x->kind) << ',' << number(x->mask) << ',' << number(x->accumulation_type) << ']'; return true; }
  if (const auto *x = op.get_if<c::TopK>()) { out << '[' << x->count << ',' << x->axis << ',' << x->largest << ',' << x->sorted << ',' << x->stable << ']'; return true; }
  if (const auto *x = op.get_if<c::GatedDeltaNet>()) { out << '[' << x->snapshot_count << ','; optional_scale(out, x->output_scale); out << ']'; return true; }
  if (auto x = op.custom_as<c::model_ops::RecurrentGatedDeltaNet>()) { out << '[' << x->snapshot_count << ','; optional_scale(out, x->output_scale); out << ']'; return true; }
  if (auto x = op.custom_as<c::PagedAttention>()) { out << '['; capacity(out, x->capacity); out << ',' << bits(x->scale) << ',' << x->causal << ',' << x->window_left << ',' << x->allow_bf16_partials << ']'; return true; }
  if (auto x = op.custom_as<g::batch::PagedAppend>()) { out << '['; capacity(out, x->schema.capacity()); out << ',' << number(x->schema.mla_layout()) << ',' << number(x->role) << ']'; return true; }
  if (auto x = op.custom_as<c::sampling_ops::Categorical>()) { out << '[' << x->return_log_probability << ']'; return true; }
  if (auto x = op.custom_as<c::sampling_ops::RandomBits>()) { out << '[' << x->word_count << ']'; return true; }
  if (op.custom_as<c::model_ops::CausalConv1d>() || op.custom_as<c::model_ops::DenseLinearF32>() || op.custom_as<c::model_ops::Nvfp4Linear>()) { out << "[]"; return true; }
  if (auto x = op.custom_as<c::model_ops::ArtifactWeightDecode>()) { out << '[' << number(x->format) << ',' << x->group_size << ',' << number(x->output_type) << ']'; return true; }
  if (auto x = op.custom_as<c::model_ops::Float8BlockLinear>()) { out << '[' << number(x->scale_policy) << ',' << bits(x->absmax_floor) << ']'; return true; }
  if (auto x = op.custom_as<c::model_ops::LocalNvfp4Linear>()) { out << '[' << number(x->rounding) << ']'; return true; }
  out << "null"; return false; // Explicit boundary; caller must not claim typed equality.
}

// Whole tiny-fixture bytes, streamed in 64KiB bounded scratch. FNV-1a64 is an
// equivalence checksum, not an acquisition/security hash. Source SHA pins stay
// in the enclosing regression evidence. No model-sized readback is permitted.
inline std::uint64_t payload_hash(m::ConstBufferView storage, std::size_t bytes) {
  std::array<std::byte, 65536> scratch{};
  std::uint64_t hash = 14695981039346656037ULL;
  for (std::size_t offset = 0; offset < bytes;) {
    const auto count = (std::min)(scratch.size(), bytes - offset);
    auto part = get(storage.subview(offset, count));
    const auto status = part.read(std::span(scratch).first(count));
    if (!status) throw std::runtime_error("cold fixture constant read failed");
    for (std::size_t i = 0; i < count; ++i) { hash ^= std::to_integer<std::uint8_t>(scratch[i]); hash *= 1099511628211ULL; }
    offset += count;
  }
  return hash;
}

template<class PackedRange>
void write(std::ostream &out, std::string_view label, const g::Graph &graph,
           const g::CompileOptions &options, const PackedRange &packed,
           std::size_t maximum_constant_bytes = 8 * 1024 * 1024) {
  out << "{\"record\":\"graph\",\"label\":"; text(out, label);
  out << ",\"nodes\":" << graph.node_count() << ",\"values\":" << graph.value_count()
      << ",\"inputs\":" << graph.input_count() << ",\"constants\":" << graph.constant_count()
      << ",\"outputs\":" << graph.output_count() << ",\"shape_policy\":" << number(options.shape_policy)
      << ",\"max_operations\":" << options.max_operation_proposals << ",\"max_placements\":" << options.max_placement_attempts
      << ",\"region_selection\":" << number(options.region_selection) << ",\"workspace_reuse\":" << number(options.workspace_reuse) << "}\n";
  for (std::size_t i = 0; i < graph.dimension_count(); ++i) {
    const auto id = get(graph.dimension_id(i)); const auto b = get(graph.dimension_bounds(id));
    out << "{\"record\":\"dimension\",\"id\":" << id.ordinal() << ",\"independent\":" << get(graph.dimension_is_independent(id))
        << ",\"bounds\":[" << b.minimum << ',' << b.maximum << ',' << b.multiple_of << "]}\n";
  }
  const auto shapes = [&](std::string_view kind, auto shape, std::size_t index) {
    out << "{\"record\":"; text(out, kind); out << ",\"index\":" << index << ",\"bindings\":[";
    bool first = true; for (const auto &b : shape) { if (!std::exchange(first, false)) out << ','; out << '[' << b.dimension.ordinal() << ',' << b.value << ']'; }
    out << "]}\n";
  };
  shapes("shape", options.shape, 0);
  for (std::size_t i = 0; i < options.exact_variants.size(); ++i) shapes("exact_variant", options.exact_variants[i].shape, i);
  const auto port = [&](std::string_view kind, std::size_t index, g::ValueId id) {
    out << "{\"record\":"; text(out, kind); out << ",\"index\":" << index << ",\"value\":"; value(out, id);
    out << ",\"spec\":"; spec(out, get(graph.value_spec(id))); out << "}\n";
  };
  for (std::size_t i = 0; i < graph.input_count(); ++i) port("input", i, get(graph.input_id(i)));
  for (std::size_t i = 0; i < graph.constant_count(); ++i) port("constant_spec", i, get(graph.constant_id(i)));
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    const auto id = get(graph.node_id(i)); out << "{\"record\":\"node\",\"id\":" << id.ordinal() << ",\"kind\":" << number(get(graph.operation_kind(id)));
    if (auto op = graph.operation(id)) {
      out << ",\"op\":"; text(out, c::operation_name(*op));
      if (const auto custom = op->custom_id()) out << ",\"custom_id\":[" << custom->namespace_id << ',' << custom->operation_id << ']';
      const auto traits = c::operation_traits(*op);
      out << ",\"traits\":[" << traits.inputs.minimum << ',' << traits.inputs.maximum << ',' << +traits.outputs << ',' << number(traits.alias)
          << ',' << number(traits.effect) << ',' << number(traits.precision) << ',' << number(traits.accumulation_type) << ',' << traits.materializes << ',' << +traits.resource_count << ']';
      out << ",\"parameters\":";
      if (!parameters(out, *op)) throw std::runtime_error("fixture operation parameters not covered; retain explicit source-level proof");
    } else { out << ",\"view\":"; view(out, get(graph.view_spec(id))); }
    out << ",\"inputs\":[";
    for (std::size_t j = 0; j < get(graph.node_input_count(id)); ++j) { if (j) out << ','; value(out, get(graph.node_input(id, j))); }
    out << "],\"depends\":[";
    for (std::size_t j = 0; j < get(graph.node_dependency_count(id)); ++j) { if (j) out << ','; out << get(graph.node_dependency(id, j)).ordinal(); }
    out << "],\"resources\":[";
    for (std::size_t j = 0; j < get(graph.node_resource_count(id)); ++j) { if (j) out << ','; out << get(graph.node_resource(id, j)).ordinal(); }
    out << "],\"results\":[";
    for (std::size_t j = 0; j < get(graph.node_output_count(id)); ++j) {
      if (j) out << ','; const auto result = get(graph.result(id, j)); out << "{\"value\":"; value(out, result);
      out << ",\"spec\":"; spec(out, get(graph.value_spec(result))); out << '}';
    }
    out << "]}\n";
  }
  for (std::size_t i = 0; i < graph.output_count(); ++i) port("output", i, get(graph.output_id(i)));
  std::vector<m::MemoryResourceRef> resources;
  std::vector<m::MemoryDomainId> domains;
  std::vector<std::pair<m::MemoryResourceRef, void *>> allocations;
  std::size_t constant_bytes = 0;
  for (const auto &binding : options.constants) {
    const auto storage = binding.tensor.storage(); const auto resource = storage.resource();
    auto ri = std::find(resources.begin(), resources.end(), resource);
    if (ri == resources.end()) { resources.push_back(resource); ri = resources.end() - 1; }
    const auto properties = resource.properties();
    auto di = std::find(domains.begin(), domains.end(), properties.domain);
    if (di == domains.end()) { domains.push_back(properties.domain); di = domains.end() - 1; }
    const auto token = std::pair{resource, storage.native_handle()};
    auto ai = std::find(allocations.begin(), allocations.end(), token);
    if (ai == allocations.end()) { allocations.push_back(token); ai = allocations.end() - 1; }
    const auto bytes = get(binding.tensor.description().required_bytes());
    if (bytes > maximum_constant_bytes - constant_bytes) throw std::runtime_error("fixture constant observation exceeds its explicit cold byte cap");
    constant_bytes += bytes;
    out << "{\"record\":\"constant_binding\",\"value\":"; value(out, binding.value);
    out << ",\"resource\":" << (ri - resources.begin()) << ",\"resource_name\":"; text(out, resource.name());
    out << ",\"domain\":" << (di - domains.begin()) << ",\"flags\":" << number(properties.flags)
        << ",\"min_alignment\":" << properties.minimum_alignment << ",\"max_allocation\":" << properties.maximum_allocation
        << ",\"allocation\":" << (ai - allocations.begin()) << ",\"offset\":" << storage.offset() << ",\"extent\":" << storage.size()
        << ",\"policy\":" << number(binding.policy) << ",\"owner\":" << bool(binding.owner) << ",\"lease\":" << bool(binding.lease)
        << ",\"bytes\":" << bytes << ",\"fnv1a64\":" << payload_hash(storage, bytes) << ",\"description\":";
    description(out, binding.tensor.description()); out << "}\n";
  }
  for (const auto &p : options.node_placements) out << "{\"record\":\"placement\",\"node\":" << p.node.ordinal() << ",\"target\":" << p.target.ordinal() << ",\"strength\":" << number(p.strength) << "}\n";
  for (const auto &p : options.external_resources) { out << "{\"record\":\"external\",\"value\":"; value(out, p.value); out << ",\"storage\":" << p.storage.ordinal() << "}\n"; }
  for (const auto &p : packed) { out << "{\"record\":\"packed_chain\",\"nodes\":["; bool first = true; for (auto id : p.chain) { if (!std::exchange(first, false)) out << ','; out << (id.valid() ? std::int64_t(id.ordinal()) : -1); } out << "]}\n"; }
  // These are not used by the current four fixture entry points. Refuse to
  // silently equate omitted optional contracts if a later fixture adds them.
  if (!options.value_placements.empty() || !options.node_providers.empty() || !options.effect_bindings.empty() ||
      !options.allowed_providers.empty() || !options.denied_providers.empty())
    throw std::runtime_error("additional compile constraints require an explicit cold observation update");
  out << "{\"record\":\"end_graph\",\"label\":"; text(out, label); out << ",\"constant_bytes\":" << constant_bytes << "}\n";
  if (!out) throw std::runtime_error("cannot write cold graph observation");
}
} // namespace graph_observation
