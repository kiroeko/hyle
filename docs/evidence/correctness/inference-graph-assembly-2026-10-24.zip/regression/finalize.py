from pathlib import Path
import collections,importlib.util,json,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('check',D/'check.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);b=p.b
def process(mode,step):return b.read(D/mode/step/'process.json')
def finalize():
    result=b.read(D/'summary.json');p.require(result['state']=='passed','Cannot publish failed comparison')
    left=(D/p.OLD/'output/mixed/cold-graphs.jsonl').read_bytes();right=(D/p.CURRENT/'output/mixed/cold-graphs.jsonl').read_bytes()
    rows=[json.loads(line)for line in left.decode().splitlines()];new=[json.loads(line)for line in right.decode().splitlines()]
    p.require(left==right and rows==new,'Cold Graph descriptors are not exactly equal')
    counts=collections.Counter(row['record']for row in rows);labels=collections.Counter(row['label']for row in rows if row['record']=='graph')
    states=[row for row in result['state_and_cold_records']if row['relative'].endswith('.bf16')]
    metadata=[row for row in result['state_and_cold_records']if row['relative'].endswith('/metadata.txt')]
    p.require(len(states)==24 and len(metadata)==6 and all(row['equal']for row in states+metadata),'Full mixed-state witness incomplete')
    nonzero={row['relative']:any(Path(row['old']['path']).read_bytes())for row in states}
    p.require(all(nonzero.values()),'Mixed complete-state comparison contains degenerate zero arrays')
    witnesses=[]
    for scope in['ordinary','mtp']:
        for state in['target.key.bf16','target.value.bf16']:
            base=D/p.OLD/'output/mixed'/scope/'prefill'/state
            for stage in['round0','round1']:
                after=D/p.OLD/'output/mixed'/scope/stage/state
                # State changes must be more than merely a longer tail extent.
                common=min(base.stat().st_size,after.stat().st_size)
                witnesses.append(dict(mode=scope,state=state,stage=stage,original_prefix_preserved=base.read_bytes()==after.read_bytes()[:common],total_bytes_changed=base.read_bytes()!=after.read_bytes()))
    compilation={mode:process(mode,'compile')for mode in['old','old2',p.OLD,p.CURRENT]}
    runs={mode:process(mode,'run')for mode in['old2',p.OLD,p.CURRENT]}
    proof=dict(state='passed',scope=result['scope'],source_identity=dict(old_main_sha256='b06483f165e4ce51680187c20082e1ef687a30999591412d02d27c592923aa62',current_main_sha256='f5da4b87bbf51ebc8382db0424d85b07b247237add248470e63360a2972a7117',private_instrumentation='Only four cold compile calls wrapped; original graph/options/constants/packed range passed unchanged. All engine source/header dependencies frozen; no canonical/private foreign header leaks.'),math_and_request_equivalence=dict(mixed_complete_ledgers_RNG_resource_facts_equal=True,previous_actual_natural_Text_MTP_greedy_fixed_non_timing_reports_equal=True,differences=result['differences'],added_report_fields=result['added_report_fields'],excluded_fields='Only keys seconds, *_seconds and *tokens_per_second*. No process identity field actually needed exclusion.'),state_equivalence=dict(binary_arrays=24,boundary_metadata_files=6,all_bytes_equal=True,all_binary_arrays_nonzero=all(nonzero.values()),witnesses=witnesses,scope='Every complete logical target KV row, ordinary/MTP carry, available prior hidden, complete draft KV/frontier/lag/catchup and sampling metadata after prefill and both continuation rounds. Old Snapshot is retained and re-read unchanged in each actual process.'),cold_equivalence=dict(actual_graphs=12,entries=dict(labels),record_counts=dict(counts),serialized_lines=len(rows),all_rows_exact_equal=rows==new,all_file_bytes_equal=left==right,graph_sha256=b.pin(D/p.OLD/'output/mixed/cold-graphs.jsonl')['sha256'],facts='Every public node/op/explicit typed parameters/input/output/spec/edge/dependency/resource; dimension bounds and exact variants; original constant payload bytes+FNV/resource/domain/allocation alias/offset/extent/owner; Required node placements/external contracts/packed chains. Dynamic graph generation and pointer identities normalized to ordinals.',boundary='Not a serializer for inaccessible internal symbolic-expression formulas; source refactor review remains separate. Only these actual four small preparation entries, no all-model/backend matrix.'),mixed_actual=result['actual_mixed_reports'],previous_actual_reports=b.pin(D/'reference/reports.json'),fixture=b.read(D/'baseline-pins.json')['fixture'],closure=b.read(D/'baseline-pins.json')['closure'],compilation=compilation,actual_runs=runs,first_failures=[dict(path='old/compile',kind='Private instrumentation/fixture compile',cause='Descriptor used !Status, and two std::array extents declared in one deduction statement. Minimal private corrections only, frozen failed source retained.'),dict(path='old2/run',kind='Private replay plan',cause='plan_replay_uses(tokens,requests,count) was called as tokens/count/requests for two-use shapes; actual R2 family was correctly rejected before inference. Only arguments fixed to intended R1/count2; N4/R1/C16/cache16MiB/backend/math unchanged.'),dict(path='audit-first-timing-fields.json',kind='Offline comparison',cause='Fixed reports additionally use seconds, beyond *_seconds. Saved all16 explicit time-only mismatches; added exact seconds exclusion without rerunning.'),dict(path='old2/compile/additional-state-witness-headers.json',kind='Link precheck',cause='Prior natural probe lacked four public detail headers for complete-state page reads; their exact SHAs matched the earlier actual GA state proof. No existing public header changed; compilation reused, no SDK/core rebuild.')],boundaries=dict(MTP_acceptance='These two tiny mixed K2 rounds actually rejected both proposals and consumed one target token each; no claim to new accepted-prefix/lag1 coverage from this case.',quality_claim=False,performance_claim=False,full_models=0,HTTP=0,SDK_builds=0,final_successful_comparison_consumers=2,actual_compile_attempts=4,actual_processes=3,successful_processes=2),source_pins=[b.pin(D/name/'source-pins.json')for name in['old','current','old2','current2',p.OLD,p.CURRENT]],summary=b.pin(D/'summary.json'))
    proof['boundaries'].update(fixture_layers='A only',GDN=False,nonempty_carry_hidden_arrays_actually_compared=6,nonempty_prior_hidden=False,lag1_prefix_exercised=False,frozen_not_compiled_or_run=['current/source: pre-private-fix source','current2/source: before replay-use parameter correction'])
    cleanup=[]
    for path in D.rglob('*'):
        if path.is_file()and path.suffix.lower()in{'.obj','.exe','.pdb','.ilk','.exp','.lib','.dll','.pch'}:
            absolute=path.resolve();p.require(absolute.is_relative_to(D),'Cleanup candidate escaped this regression');cleanup.append(dict(path=str(absolute),bytes=path.stat().st_size))
    b.save(D/'cleanup-candidates.json',dict(scope='Rebuildable binaries under this private regression ONLY. Cached native closure and original runtime are outside this path and excluded. DLL paths are private hardlinks, not original cache locations.',workspace=str(D),files=cleanup,count=len(cleanup),logical_bytes=sum(x['bytes']for x in cleanup),deletion_performed=False))
    b.save(D/'proof-summary.json',proof)
    selected=[];extensions={'.cc','.h','.py','.json','.jsonl','.log','.diff','.patch','.md','.txt','.ids'}
    for path in D.rglob('*'):
        if not path.is_file()or path.name in['proof-pins.json']:continue
        relative=path.relative_to(D)
        state=path.suffix=='.bf16'and 'output'in relative.parts and'mixed'in relative.parts
        if path.suffix not in extensions and not state:continue
        if path.suffix=='.json'and path.name=='live.json':continue
        selected.append(path)
    with zipfile.ZipFile(D/'proof.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for path in sorted(selected):z.write(path,path.relative_to(D).as_posix())
    with zipfile.ZipFile(D/'proof.zip')as z:
        p.require(not any(Path(name).suffix in{'.obj','.exe','.pdb','.dll','.lib','.bin','.tsv'}for name in z.namelist()),'Proof archive contains rebuildable binary/weights')
    b.save(D/'proof-pins.json',dict(summary=b.pin(D/'summary.json'),proof_summary=b.pin(D/'proof-summary.json'),archive=b.pin(D/'proof.zip'),entries=len(selected),SDK_builds=0,HTTP=0))
    print(json.dumps(b.read(D/'proof-pins.json')),flush=True)
if __name__=='__main__':finalize()
