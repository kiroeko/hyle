from pathlib import Path
import hashlib,json,subprocess,sys,xml.etree.ElementTree as ET,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';mode,attempt=sys.argv[1:3];run=base/'cuda-host-san'/(mode+'-'+attempt)
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_PASS' and all(s['exit_code']==0 for s in r['stages'])
candidate='0143102aebcbc29600a77ce2950136462fba2a36'
with zipfile.ZipFile(base/'cuda-host-san'/('source-'+mode+'-'+attempt+'.zip')) as package:
 manifest=json.loads(package.read('source-manifest.json'));assert manifest==r['inputs']
 for name in ('third_party/flashinfer_cache/patches.json','third_party/flashinfer_cache/NOTICE.md','cmake/HyleDependencyLock.json'):
  content=package.read(name)
  assert hashlib.sha256(content).hexdigest()==next(item['sha256'] for item in manifest if item['path']==name)
  assert content.replace(b'\r\n',b'\n')==subprocess.check_output(['git','show',candidate+':'+name]).replace(b'\r\n',b'\n')
x=ET.parse(run/'tests.xml').getroot();assert int(x.attrib['tests'])==16 and x.attrib['failures']==x.attrib['errors']=='0'
assert not any(c.find('skipped') is not None or c.attrib.get('status')=='notrun' for c in x.findall('.//testcase'))
assert (run/'five-risk-modes.log').read_text().count('PASS')==5
for item in r['binaries'].values():assert subprocess.check_output(['wsl','-e','sha256sum',item['path']],text=True).split()[0]==item['sha256']
commands=json.loads((run/'instrumented-inputs.json').read_text())
for name in ('native_attention.cu','native_batch.cu','native_cache.cu','native_cache_encoder.cu'):
 assert any(row['file'].endswith('/'+name) for row in commands)
dest=root/('evidence/correctness/inference-g04-g05-cuda-ce25-host-'+mode);dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(run.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(run).as_posix())
 for name in ('ce19_cuda_host_san.py','launch_ce19_host_san.py','seal_ce25_host_facet.py'):z.write(base/name,'runners/'+name)
 with zipfile.ZipFile(base/'cuda-host-san'/('source-'+mode+'-'+attempt+'.zip')) as archive:z.writestr('source-manifest.json',archive.read('source-manifest.json'))
receipt=dict(kind='G04_G05_CUDA_CE25_HOST_SANITIZER_FACET',mode=mode,verdict='PASS_HOST_FACET_ONLY',product_candidate='0143102aebcbc29600a77ce2950136462fba2a36',
 tests=16,skips=0,source_risk_modes=5,stages=r['stages'],measured_seconds=r['cumulative_seconds'],identity=r['identity'],environment=r['environment'],
 native_dependency_reused=r['reused_ggml_cuda'],binaries=r['binaries'],previous_f5_scope=r['previous_f5_sanitizer_scope'],limits=r['limits'],
 raw_zip_sha256=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(dest),seconds=r['cumulative_seconds'],tests=16,risks=5)))
