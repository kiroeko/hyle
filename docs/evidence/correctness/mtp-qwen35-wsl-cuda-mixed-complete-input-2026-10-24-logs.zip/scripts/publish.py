"""Publish the two completed WSL journeys without binaries or weight payloads."""
from pathlib import Path
import hashlib, importlib.util, json, zipfile
spec=importlib.util.spec_from_file_location('host',Path(__file__).with_name('build-host.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
R,B,CPU=h.R,h.B,h.CPU
def main():
 name='mtp-qwen35-wsl-cuda-mixed-complete-input-2026-10-24'
 destination=R/'docs/evidence/correctness';target=destination/(name+'.json');archive=destination/(name+'-logs.zip')
 if target.exists() or archive.exists():raise RuntimeError('Published proof already exists')
 cases=[]
 for case in ['ordinary','mtp_k1_random_ffn2']:
  row=h.load(B/'runs'/case/'functional-result.json')
  if row['process']['exit']!=0:raise ValueError('Unfinished or failed native entry')
  report=row['report'];summary={k:v for k,v in report.items()if not any(word in k for word in ['seconds','per_second','elapsed'])}
  cases.append(dict(case=case,process=row['process'],functional_report=summary,raw_stdout=h.identity(B/'runs'/case/'stdout.log'),raw_stderr=h.identity(B/'runs'/case/'stderr.log')))
 text=(B/'image.map').read_text();selection=text.split('Discarded input sections',1)[0]
 selected=B/'selected-archive-members.txt';selected.write_text(selection)
 native=h.load(B/'native/native-ready.json')
 if any('libggml-cuda.a('+member+')'in selection for member in native['replacement_members']):raise ValueError('Obsolete GGML native ABI member extracted')
 source_records=[]
 # Preserve only product source/header dependencies of the actual refreshed
 # objects. No old SDK, binary, raw model or complete build tree is archived.
 for folder in ['host','kernels','extra']:
  for dep in (B/folder).rglob('unit.d'):
   words=dep.read_text().replace('\\\n',' ').split()
   for word in words[1:]:
    p=Path(word)
    try:relative=p.resolve().relative_to(R)
    except(ValueError,OSError):continue
    if relative.parts[0]not in ['include','src']or not p.is_file():continue
    source_records.append(p.resolve())
 source_records=sorted(set(source_records))
 records=[]
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  def add(path,label):
   z.write(path,label);records.append(dict(archive_path=label,**h.identity(path)))
  for path in sorted(Path(__file__).parent.glob('*.py')):add(path,'scripts/'+path.name)
  for path in sorted(B.glob('*.json')):
   if path.name!='host-partial-ready.json':add(path,'records/'+path.name)
  add(selected,'records/selected-archive-members.txt')
  for path in sorted((B/'runs').rglob('*')):
   if path.is_file()and path.suffix in ['.json','.log']:add(path,'runs/'+path.relative_to(B/'runs').as_posix())
  for folder in ['host','kernels','extra','app']:
   for path in sorted((B/folder).rglob('*')):
    if not path.is_file():continue
    if path.suffix in ['.json','.log','.d']:
     add(path,'build/'+path.relative_to(B).as_posix())
    elif folder=='app'and 'source'in path.relative_to(B).parts and path.suffix in ['.h','.cc']:
     add(path,'build/'+path.relative_to(B).as_posix())
  for path in sorted((B/'native').rglob('*')):
   if path.is_file()and path.suffix in ['.json','.log','.py']:
    add(path,'build/'+path.relative_to(B).as_posix())
  add(CPU/'input-remap.json','input/input-remap.json')
  add(CPU/'inputs/weights.tsv','input/weights.tsv')
  add(CPU/'inputs/prompt.ids','input/prompt.ids')
  for path in source_records:add(path,'product/'+path.relative_to(R).as_posix())
 result=dict(kind='Two actual current-source WSL Linux CUDA/mixed Qwen3.5-2B original BF16 functional journeys',date='2026-10-24',status='PASS',environment=h.load(B/'environment.json'),source=dict(source_id=cases[0]['functional_report']['source_id'],original_manifest=h.identity(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'),linux_manifest=h.identity(CPU/'inputs/weights.tsv'),role_count=335,text_roles=320,text_bytes=3763655360,all_bytes=3885311680,weight_path='/mnt/c/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors',input_remap=h.load(CPU/'input-remap.json'),weight_copies=0),build=h.load(B/'engine-ready.json'),cases=cases,actual_fixes=[dict(kind='Product strict-GCC portability',source='src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc',before='native::Program gemm;',after='native::Program gemm{};',qualification='Makes the existing aggregate omitted-member value initialization explicit; no arithmetic or route-domain change.'),dict(kind='Private deployment recipe correction',detail='Restore current CMake SYSTEM attribute for third-party native GGML src; compile the missing current CUDA file-stream facade; remove three fully replaced Hyle provider archives, avoiding accidental extraction of old CUDA collectives solely for a weak stdlib template symbol. All first failure logs are retained.')],native_ABI=dict(replacement_members=native['replacement_members'],fusion_abi=native['fusion_abi'],obsolete_replacement_members_extracted=False,map_identity=h.identity(B/'image.map'),archive_selection_identity=h.identity(selected)),HTTP=0,SDK_builds=0,models_started=2,performance_claim=False,limits=['Only P154/C256/+4 N1R1 ordinary pure-CUDA and random K1 with CPUFFN2 were run. No additional publisher/mode matrix.','Original BF16 text/MTP roles are complete, but source identity and path remap are reused from the prior authenticated preparation; no model was re-downloaded or copied.','Current affected application, CUDA adapters and native ABI are refreshed over retained third-party libraries and common objects; this is not full current-SDK certification.','Mixed report retains native_execution_private_bytes_unknown=true; finite cache and known per-invocation workspace bounds do not claim a physical RAM/VRAM cap.','This is an execution/state/RNG/placement deployment check, not a throughput comparison or model task-quality assessment.'],archive=h.identity(archive),archive_records=records)
 h.save(target,result)
 print(json.dumps(dict(proof=h.identity(target),archive=h.identity(archive),archived_files=len(records),models_started=2,HTTP=0,SDK_builds=0)),flush=True)
if __name__=='__main__':main()
