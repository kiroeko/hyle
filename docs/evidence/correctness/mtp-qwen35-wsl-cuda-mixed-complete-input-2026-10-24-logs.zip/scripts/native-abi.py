"""Check the actual refreshed nvcc ABI, without linking a model or CUDA kernel."""
import hashlib
import json
import pathlib
import subprocess

R = pathlib.Path('/root/hyle-scratch/compute-unified/qwen-v2-cuda-functional-20261024/native')
plan = json.loads((R / 'compile-plan.json').read_text())
recipe = next(p for p in plan if p['relative'].endswith('/ggml-cuda.cu'))
source = R / 'abi-check.cu'
source.write_text('''#include "common.cuh"
static_assert(sizeof(ggml_cuda_mm_fusion_args_host) == 56);
static_assert(sizeof(ggml_cuda_mm_fusion_args_device) == 56);
static_assert(offsetof(ggml_cuda_mm_fusion_args_host, glu_alpha) == 48);
static_assert(offsetof(ggml_cuda_mm_fusion_args_device, glu_alpha) == 48);
''')
command = [str(source) if arg == str(R / 'source' / recipe['relative']) else
           str(R / 'abi-check.o') if arg == recipe['object'] else arg
           for arg in recipe['command']]
(R / 'abi-command.json').write_text(json.dumps(command, indent=2) + '\n')
with (R / 'abi.stdout.log').open('wb') as out, (R / 'abi.stderr.log').open('wb') as err:
    result = subprocess.run(command, cwd=R, stdout=out, stderr=err)
record = {'returncode': result.returncode,
          'host_bytes': 56, 'device_bytes': 56, 'glu_alpha_offset': 48,
          'old_archive_bytes': 48, 'object_is_link_input': False}
(R / 'abi-result.json').write_text(json.dumps(record, indent=2) + '\n')
if result.returncode:
    raise SystemExit(result.returncode)
ready = json.loads((R / 'native-ready.json').read_text())
ready['fusion_abi']['actual_nvcc_static_asserts'] = str(R / 'abi-result.json')
(R / 'native-ready.json').write_text(json.dumps(ready, indent=2) + '\n')
print(json.dumps(record))
