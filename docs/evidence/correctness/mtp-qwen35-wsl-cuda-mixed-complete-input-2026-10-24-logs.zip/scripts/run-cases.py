"""Exactly two bounded original BF16 WSL entries; no retry or performance study."""
from pathlib import Path
import argparse, importlib.util, json, os, shlex, subprocess, time
spec=importlib.util.spec_from_file_location('host',Path(__file__).with_name('build-host.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
R,B,CPU=h.R,h.B,h.CPU
def make_cases():
 inputs=CPU/'inputs';lines=(inputs/'weights.tsv').read_text().splitlines()
 roles=[shlex.split(line)for line in lines[3:]if line.strip()]
 assert len(roles)==335 and len((inputs/'prompt.ids').read_text().split())==154
 total=sum(int(row[-1])for row in roles)
 text=sum(int(row[-1])for row in roles if not row[0].startswith('mtp.'))
 host=sum(int(row[-1])for row in roles if row[0].startswith(('model.language_model.layers.0.','model.language_model.layers.1.'))and('.mlp.'in row[0]or row[0].endswith('.post_attention_layernorm.weight')))
 assert(total,text)==(3885311680,3763655360)
 image=B/'hyle-linux-cuda';common=[str(image),'--inputs',str(inputs),'--capacity','256','--steps','4','--cache-bytes','268435456','--prefix-cache','off','--replay','commands']
 return dict(ordinary=dict(command=common+['--mtp','off','--cpu-ffn-layers','0'],mtp=False,sampling='greedy',expected_loaded_bytes=text,expected_host_weight_bytes=0),mtp_k1_random_ffn2=dict(command=common+['--mtp','on','--sampling','random','--cpu-ffn-layers','2','--mtp-max-drafts','1','--temperature','1','--top-k','40','--top-p','0.9','--seed','424242'],mtp=True,sampling='random',expected_loaded_bytes=total,expected_host_weight_bytes=host))
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('case',choices=['plan','ordinary','mtp_k1_random_ffn2']);args=parser.parse_args()
 cases=make_cases()
 if args.case=='plan':
  h.save(B/'run-plan.json',dict(cases=cases,input_manifest=h.identity(CPU/'inputs/weights.tsv'),prompt=h.identity(CPU/'inputs/prompt.ids'),cache_limit_bytes=268435456,timeout_seconds=240,HTTP=0,SDK_builds=0,models_started=0,weight_copies=0,performance_claim=False));print(json.dumps(cases,indent=2));return
 ready=h.load(B/'engine-ready.json')
 if h.identity(Path(ready['image']['path']))!=ready['image']:raise ValueError('Prepared image changed')
 case=cases[args.case];folder=B/'runs'/args.case;folder.mkdir(parents=True,exist_ok=False)
 native_env=h.load(h.OLD/'run-environment.json')
 environment=dict(os.environ)
 if isinstance(native_env,dict):environment.update({k:v for k,v in native_env.items()if isinstance(v,str)})
 environment['LD_LIBRARY_PATH']=str(CPU)+':'+str(B)+':'+environment.get('LD_LIBRARY_PATH','')
 environment['HF_HUB_OFFLINE']='1';environment['TRANSFORMERS_OFFLINE']='1'
 h.save(folder/'command.json',dict(command=case['command'],cwd=str(B),timeout_seconds=240,image=ready['image'],input_manifest=h.identity(CPU/'inputs/weights.tsv'),prompt=h.identity(CPU/'inputs/prompt.ids'),environment={k:environment[k]for k in ['LD_LIBRARY_PATH','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE']},HTTP=0,SDK_builds=0,weight_copies=0,performance_claim=False))
 started=time.monotonic()
 with(folder/'stdout.log').open('w')as out,(folder/'stderr.log').open('w')as err:
  try:process=subprocess.run(case['command'],cwd=B,env=environment,stdout=out,stderr=err,timeout=240)
  except subprocess.TimeoutExpired:
   h.save(folder/'process.json',dict(timeout=True,seconds=time.monotonic()-started));raise
 result=dict(exit=process.returncode,seconds=time.monotonic()-started);h.save(folder/'process.json',result)
 if process.returncode:raise RuntimeError('Native failure retained; no retry/fallback')
 reports=[json.loads(line)for line in(folder/'stdout.log').read_text().splitlines()if line.startswith('{')]
 report=reports[-1];source=(CPU/'inputs/weights.tsv').read_text().splitlines()[1]
 if(report['backend'],report['source_id'],report['mtp'],report['sampling'])!=('cuda',source,case['mtp'],case['sampling']):raise ValueError('Native source/route/sampling differs')
 if report['original_host_weight_bytes']!=case['expected_host_weight_bytes']or report['original_host_weight_bytes']+report['original_device_weight_bytes']!=case['expected_loaded_bytes']:raise ValueError('Actual role-byte placement differs')
 if report['cache_requested_byte_limit']!=268435456 or report['cache_peak_requested_bytes']>268435456:raise ValueError('Finite cache budget differs')
 if len(report['generated_ids'])!=4 or report['generated_tokens']!=4 or any(not 0<=i<248320 for i in report['generated_ids']):raise ValueError('Output count/domain differs')
 if case['mtp']:
  if report['cpu_ffn_layers']!=2 or report['mtp_max_drafts']!=1 or report['sampling_draw_cursor']<=0 or report['draft_rounds']<=0:raise ValueError('Mixed K1/RNG path was not executed')
 else:
  if report['sampling_draw_cursor']!=0 or report['cpu_ffn_layers']!=0:raise ValueError('Ordinary greedy route differs')
 h.save(folder/'functional-result.json',dict(case=args.case,process=result,report=report,HTTP=0,SDK_builds=0,weight_copies=0,performance_claim=False))
 print(json.dumps(dict(case=args.case,exit=0,generated_ids=report['generated_ids'],host=report['original_host_weight_bytes'],device=report['original_device_weight_bytes'],draw=report['sampling_draw_cursor'],draft_rounds=report['draft_rounds'],cache_peak=report['cache_peak_requested_bytes'],performance_claim=False)),flush=True)
if __name__=='__main__':main()
