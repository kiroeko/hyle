"""Refresh only changed GGML native CUDA owners from authenticated local inputs.

Run inside WSL. No downloader, CMake configure, SDK copy, or model access.
"""
from __future__ import annotations

import concurrent.futures
import hashlib
import importlib.util
import json
import pathlib
import re
import shlex
import subprocess
import sys
import time

PRODUCT = pathlib.Path('/mnt/c/public/project-hyle/hyle')
BASE = pathlib.Path('/root/hyle-scratch/compute-unified')
ROOT = BASE / 'qwen-v2-cuda-functional-20261024/native'
PRISTINE = pathlib.Path('/root/.cache/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
BUILD = BASE / 'l-cuda/selected-graph/source-build'
OLD = BUILD / 'hyle/src/compute_ggml_runtime/source-f99368c68335266b'
SOURCE = ROOT / 'source'
UNITS = (
    'ggml-cuda.cu', 'diagmask.cu', 'binbcast.cu', 'unary.cu',
    'mmvf.cu', 'norm.cu', 'mmvq.cu', 'gated_delta_net.cu',
    'ssm-conv.cu', 'convert.cu', 'getrows.cu', 'mmid.cu', 'mmq.cu',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


class MemoryManifest:
    def write_text(self, text, **kwargs):
        self.text = text

    def read_text(self, **kwargs):
        return self.text


def helper(name):
    spec = importlib.util.spec_from_file_location(name, PRODUCT / 'src/compute_ggml_runtime' / f'{name}.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepare():
    ROOT.mkdir(parents=True, exist_ok=True)
    mixed, combined = MemoryManifest(), MemoryManifest()
    helper('prepare_mixed_cpu_manifest').derive(
        PRISTINE, PRODUCT / 'third_party/ggml_runtime/patches.json',
        PRODUCT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    helper('prepare_cuda_iq1_manifest').derive(
        PRISTINE, mixed, PRODUCT / 'third_party/ggml_cuda_runtime/patches.json',
        PRODUCT / 'third_party/ggml_cuda_runtime/iq1-patches.json', combined)
    manifest = json.loads(combined.text)
    save(ROOT / 'current-manifest.json', manifest)
    patched = {}
    for entry in manifest['files']:
        name = entry['path']
        original = (PRISTINE / name).read_bytes().replace(b'\r\n', b'\n')
        if sha(original) != entry['before_sha256']:
            raise ValueError(f'pristine identity mismatch: {name}')
        data = original
        for edit in entry['edits']:
            before, after = edit['before'].encode(), edit['after'].encode()
            if data.count(before) != 1:
                raise ValueError(f'nonunique patch context: {name}')
            data = data.replace(before, after, 1)
        if sha(data) != entry['after_sha256']:
            raise ValueError(f'patched identity mismatch: {name}')
        patched[name] = data

    def contents(name):
        return patched.get(name) if name in patched else (PRISTINE / name).read_bytes()

    # Public include surface plus transitive local includes of the selected owners.
    pending = {f'src/ggml-cuda/{name}' for name in UNITS}
    pending.update(str(p.relative_to(PRISTINE)) for p in (PRISTINE / 'include').glob('*.h'))
    chosen = {}
    external_headers = set()
    include_roots = ('src/ggml-cuda', 'src', 'include')
    while pending:
        name = pending.pop()
        if name in chosen:
            continue
        data = contents(name)
        chosen[name] = data
        for quoted in re.findall(rb'^\s*#\s*include\s*"([^"\n]+)"', data, re.MULTILINE):
            token = quoted.decode()
            candidates = [pathlib.PurePosixPath(name).parent / token]
            candidates.extend(pathlib.PurePosixPath(root) / token for root in include_roots)
            resolved = None
            for candidate in candidates:
                path = (PRISTINE / candidate).resolve()
                if path.is_file() and path.is_relative_to(PRISTINE):
                    resolved = path.relative_to(PRISTINE).as_posix()
                    break
            if resolved:
                pending.add(resolved)
            else:
                # Native bridge and scale contract stay in the authoritative product.
                external_headers.add(token)
    identities = []
    for name, data in sorted(chosen.items()):
        target = SOURCE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and target.read_bytes() != data:
            raise ValueError(f'existing refresh source was changed: {name}')
        if not target.exists():
            target.write_bytes(data)
        identities.append({'relative': name, 'bytes': len(data), 'sha256': sha(data)})
    # Stable core ABI is checked against the original native object closure.
    core = ('include/ggml.h', 'src/ggml.c', 'src/ggml-common.h', 'src/ggml-quants.c')
    for name in core:
        if contents(name).replace(b'\r\n', b'\n') != (OLD / name).read_bytes().replace(b'\r\n', b'\n'):
            raise ValueError(f'cannot reuse old core ABI: {name}')
    save(ROOT / 'source-identities.json', {
        'pristine': str(PRISTINE), 'upstream_revision': manifest['upstream_revision'],
        'source': str(SOURCE), 'selected': identities,
        'external_headers': sorted(external_headers),
        'core_abi_unchanged': list(core),
        'fusion_abi': {'old_host_and_device_bytes': 48, 'current_host_and_device_bytes': 56,
                       'owners_refreshed_together': ['ggml-cuda.cu', 'mmvf.cu', 'mmvq.cu']},
    })
    recipes = json.loads((BUILD / 'compile_commands.json').read_text())
    plan = []
    for name in UNITS:
        relative = f'src/ggml-cuda/{name}'
        matches = [r for r in recipes if r['file'] == str(OLD / relative)]
        recipe_owner = name
        if not matches and name == 'unary.cu':
            # This older compile database omits the sibling precise OBJECT
            # target. Its current CMake contract inherits ggml-cuda's options
            # and definitions, with only global fast math removed.
            matches = [r for r in recipes if r['file'] == str(OLD / 'src/ggml-cuda/ggml-cuda.cu')]
            recipe_owner = 'ggml-cuda.cu'
        if len(matches) != 1:
            raise ValueError(f'expected one original recipe: {name}, got {len(matches)}')
        recipe = matches[0]
        args = shlex.split(recipe['command'])
        result = []
        skip = False
        for arg in args:
            if skip:
                skip = False
                continue
            if arg == '-o':
                skip = True
                continue
            if name == 'unary.cu' and arg in ('-use_fast_math', '--use_fast_math'):
                continue
            arg = arg.replace(str(OLD), str(SOURCE))
            if recipe_owner != name and arg == str(SOURCE / 'src/ggml-cuda' / recipe_owner):
                arg = str(SOURCE / relative)
            if arg.startswith('-I') and '/src/compute_provider_ggml_cuda' in arg:
                arg = '-I' + str(PRODUCT / 'src/compute_provider_ggml_cuda')
            result.append(arg)
        for root in (PRODUCT / 'include', PRODUCT / 'src/compute_provider_ggml_cuda',
                     PRODUCT / 'src/compute_ggml_runtime'):
            result.insert(1, '-I' + str(root))
        output = ROOT / 'objects' / f'{name}.o'
        result.extend(('-o', str(output)))
        plan.append({'relative': relative, 'command': result, 'directory': str(ROOT),
                     'object': str(output), 'old_archive_member': name + '.o',
                     'original_recipe_owner': recipe_owner,
                     'precise': name == 'unary.cu'})
    save(ROOT / 'compile-plan.json', plan)
    print(json.dumps({'source_ready': str(SOURCE), 'files': len(chosen),
                      'cuda_units': len(plan), 'unresolved_local_includes': sorted(external_headers)}), flush=True)
    return plan


def compile_one(item):
    output = pathlib.Path(item['object'])
    output.parent.mkdir(parents=True, exist_ok=True)
    stem = output.name
    started = time.monotonic()
    with (ROOT / f'{stem}.stdout.log').open('wb') as stdout, (ROOT / f'{stem}.stderr.log').open('wb') as stderr:
        process = subprocess.run(item['command'], cwd=item['directory'], stdout=stdout, stderr=stderr)
    record = {'relative': item['relative'], 'object': str(output),
              'returncode': process.returncode, 'seconds': time.monotonic() - started,
              'precise': item['precise'], 'old_archive_member': item['old_archive_member']}
    if process.returncode == 0:
        record.update(bytes=output.stat().st_size, sha256=sha(output.read_bytes()))
    save(ROOT / f'{stem}.result.json', record)
    print(json.dumps(record), flush=True)
    return record


def main():
    plan = prepare()
    if '--prepare-only' in sys.argv:
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as workers:
        results = list(workers.map(compile_one, plan))
    save(ROOT / 'results.json', results)
    failed = [r for r in results if r['returncode']]
    if failed:
        raise SystemExit(f'{len(failed)} native owner compiles failed; inspect exact stderr logs')
    archives = list((BUILD / 'hyle/src/compute_ggml_runtime/vendor').rglob('libggml-cuda.a'))
    if len(archives) != 1:
        raise ValueError(f'expected one retained CUDA archive, found {len(archives)}')
    archive = archives[0]
    members = subprocess.check_output(['ar', 't', str(archive)], text=True).splitlines()
    for item in plan:
        if members.count(item['old_archive_member']) != 1:
            raise ValueError(f'old archive replacement is not unique: {item["old_archive_member"]}')
    ready = {'source': str(SOURCE), 'old_cuda_archive': str(archive),
             'old_cuda_archive_bytes': archive.stat().st_size,
             'old_cuda_archive_sha256': sha(archive.read_bytes()),
             'objects': {i['relative']: i['object'] for i in plan},
             'replacement_members': [i['old_archive_member'] for i in plan],
             'link_rule': 'Place every explicit fresh object before the retained CUDA archive; '
                          'do not use --whole-archive. Verify the link map extracts none of replacement_members.',
             'fusion_abi': {'old_bytes': 48, 'current_bytes': 56,
                            'explicit_owners': ['ggml-cuda.cu.o', 'mmvf.cu.o', 'mmvq.cu.o']},
             'throughput_evidence': False, 'model_executed': False,
             'sdk_rebuilt': False, 'http_requests': 0}
    save(ROOT / 'native-ready.json', ready)
    print(json.dumps({'native_ready': str(ROOT / 'native-ready.json')}), flush=True)


if __name__ == '__main__':
    main()
