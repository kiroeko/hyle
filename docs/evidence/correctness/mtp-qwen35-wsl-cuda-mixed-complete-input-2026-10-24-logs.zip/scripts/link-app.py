"""Link current necessary Hyle/GGML overlays ahead of retained archives."""
from pathlib import Path
import importlib.util, json, subprocess, time
spec=importlib.util.spec_from_file_location('host',Path(__file__).with_name('build-host.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
R,B,CPU,OLD=h.R,h.B,h.CPU,h.OLD
def main():
 host=h.load(B/'host-ready.json');kernel=h.load(B/'kernel-ready.json');native=h.load(B/'native/native-ready.json');app=h.load(B/'app-ready.json')
 io=h.load(CPU/'io-ready.json');baseline=h.load(CPU/'native-baseline/identity.json')
 objects=[app['record']['object']['path']]
 objects += [x['object']['path']for x in host['borrowed_common']+host['fresh']+kernel['fresh']+kernel['borrowed']+io]
 extra=h.load(B/'extra-ready.json')['records']
 objects += [x['object']['path']for x in extra]
 objects += list(native['objects'].values())
 objects += [str(OLD/'native/ggml-alloc.c.o'),baseline['object']['path']]
 objects=list(dict.fromkeys(objects))
 for x in host['borrowed_common']+host['fresh']+kernel['fresh']+kernel['borrowed']+io:
  if h.identity(Path(x['object']['path']))!=x['object']:raise ValueError('Linked object identity changed')
 original=h.load(OLD/'link-plan.json')['command'];command=[];i=0
 while i<len(original):
  x=original[i]
  if x.endswith('.o'):i+=1;continue
  if Path(x).name in ['libhyle_compute_provider_cuda.a','libhyle_compute_provider_flashinfer.a','libhyle_compute_provider_ggml_cuda.a']:
   # These complete Hyle modules are already supplied as current/verified
   # explicit objects. Retaining the old archive could extract an obsolete
   # member solely for an incidental weak libstdc++ template symbol.
   i+=1;continue
  if x=='-o':command+=['-o',str(B/'hyle-linux-cuda')];i+=2;continue
  if x.startswith('-Wl,-Map,'):i+=1;continue
  command.append(x);i+=1
 command=[command[0],*objects,*command[1:],'-Wl,-rpath,'+str(CPU)+':'+str(B),'-Wl,-Map,'+str(B/'image.map')]
 if (B/'link-process.json').exists() and h.load(B/'link-process.json').get('exit'):
  for name in ['link-plan.json','link-process.json','link.stdout.log','link.stderr.log','image.map']:
   destination=B/('first-failure-'+name)
   if (B/name).exists() and not destination.exists():destination.write_bytes((B/name).read_bytes())
 h.save(B/'link-plan.json',dict(command=command,objects=[h.identity(Path(p))for p in objects],original_recipe=h.identity(OLD/'link-plan.json'),native_replacement_members=native['replacement_members'],SDK_builds=0,HTTP=0))
 started=time.monotonic()
 with(B/'link.stdout.log').open('w')as out,(B/'link.stderr.log').open('w')as err:process=subprocess.run(command,cwd=R,stdout=out,stderr=err)
 result=dict(exit=process.returncode,seconds=time.monotonic()-started);h.save(B/'link-process.json',result)
 if process.returncode:raise RuntimeError('Current overlay link failed; original stderr retained')
 text=(B/'image.map').read_text();unexpected=[]
 for member in native['replacement_members']:
  # The exact archive(member) form appears only for members actually extracted.
  if ('libggml-cuda.a('+member+')')in text:unexpected.append(member)
 if unexpected:raise ValueError('Old replaced native ABI members were extracted: '+str(unexpected))
 h.save(B/'engine-ready.json',dict(image=h.identity(B/'hyle-linux-cuda'),app=app['record']['object'],native_replaced_members_not_extracted=True,current_CUDA_objects=len(host['fresh']),common_objects_borrowed=len(host['borrowed_common']),fresh_Hyle_kernel_objects=len(kernel['fresh']),unchanged_Hyle_kernel_objects=len(kernel['borrowed']),fresh_ggml_CUDA_objects=len(native['objects']),CPU_baseline=baseline,SDK_builds=0,HTTP=0,models_started=0,qualification='Current affected source/ABI overlays with retained immutable SDK dependencies; only the explicitly executed two model journeys are validated.'))
 print(json.dumps(dict(engine_ready=True,image=h.identity(B/'hyle-linux-cuda'),link=result)),flush=True)
if __name__=='__main__':main()
