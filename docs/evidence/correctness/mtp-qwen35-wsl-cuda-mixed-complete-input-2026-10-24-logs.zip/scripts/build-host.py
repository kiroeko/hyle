"""WSL-only current CUDA host overlay; retained dependencies are read-only."""
from pathlib import Path
import argparse, concurrent.futures, hashlib, json, subprocess, time

R=Path('/mnt/c/public/project-hyle/hyle')
BASE=Path('/root/hyle-scratch/compute-unified')
OLD=BASE/'linux-current-graph'
CPU=BASE/'qwen-v2-cpu-functional-20261024'
B=BASE/'qwen-v2-cuda-functional-20261024'
NATIVE=B/'native/source'
OLD_NATIVE=BASE/'l-cuda/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-f99368c68335266b'
MODULES=['compute_backend_cuda','compute_provider_cuda','compute_provider_cublas','compute_provider_flashinfer','compute_provider_ggml_cuda','compute_provider_torch_cuda','compute_route_cuda','graph_provider_ggml_cuda','graph_route_cuda','graph_route_cpu_cuda']
def load(p):return json.loads(p.read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def rewrite(text):return text.replace(str(OLD/'source'),str(R)).replace(str(OLD_NATIVE),str(NATIVE))
def strip_io(cmd):
 out=[];i=0
 while i<len(cmd):
  if cmd[i] in ['-c','-o','-MF','-MT']:i+=2;continue
  if cmd[i] in ['-MMD','-MD','-MP']:i+=1;continue
  out.append(rewrite(cmd[i]));i+=1
 return out
def host_plan():
 original=load(OLD/'compile-plan.json')['entries'];by_source={x['source']:x for x in original}
 general=original[0]['command'];entries=[]
 for module in MODULES:
  for source in sorted((R/'src'/module).glob('*.cc')):
   rel=source.relative_to(R).as_posix();previous=by_source.get(rel)
   if previous is None:previous=next((x for x in original if x['module']==module),None)
   command=strip_io(previous['command'] if previous else general)
   command=[x for x in command if not x.startswith('-DHYLE_GGML_CUDA_PROVIDER_VERSION=')]
   if module=='compute_provider_ggml_cuda':
    # Truthful overlay qualification, not the old cached f993 implementation.
    digest=hashlib.sha256((R/'third_party/ggml_cuda_runtime/patches.json').read_bytes()).hexdigest()[:16]
    command.append('-DHYLE_GGML_CUDA_PROVIDER_VERSION="456172ec+canonical-cuda-'+digest+'-partial-sdk-overlay"')
    # The current module CMake marks native private GGML headers SYSTEM.
    # Restore that property omitted by the historic hand-written recipe.
    command+=['-isystem',str(NATIVE/'src')]
   directory=B/'host'/rel.replace('/','--');obj=directory/'unit.o'
   command=[command[0],'-I'+str(R/'include'),'-I'+str(R/'src'/module),'-I'+str(R/'src/compute'),'-I'+str(R/'src/compute_backend_cuda'),'-I'+str(R/'src/compute_ggml_runtime'),*command[1:],'-MMD','-MF',str(directory/'unit.d'),'-c',str(source),'-o',str(obj)]
   entries.append(dict(source=identity(source),object=str(obj),command=command))
 common=load(CPU/'host-ready.json')
 borrowed=[dict(source=x['source'],object=x['object'])for kind in ['fresh','borrowed']for x in common[kind]]
 for x in borrowed:
  if identity(Path(x['source']['path']))!=x['source']:raise ValueError('CPU host source changed: '+x['source']['path'])
 plan=dict(fresh=entries,borrowed_common=borrowed,parent_cpu_ready=identity(CPU/'host-ready.json'),parent_cuda_recipe=identity(OLD/'compile-plan.json'),source=identity(Path(__file__)),HTTP=0,SDK_builds=0,models_started=0)
 path=B/'host-plan.json'
 if path.exists() and not (B/'host-plan-initial.json').exists():save(B/'host-plan-initial.json',load(path))
 save(path,plan)
 print(json.dumps(dict(fresh_host_TUs=len(entries),borrowed_common_TUs=len(borrowed),plan=str(B/'host-plan.json'))),flush=True)
 return plan
def compile_one(entry):
 directory=Path(entry['object']).parent;directory.mkdir(parents=True,exist_ok=True)
 if (directory/'identity.json').exists():
  record=load(directory/'identity.json')
  if record.get('process',{}).get('exit')==0 and record['source']==entry['source'] and record['command']==entry['command'] and identity(Path(entry['object']))==record['object']:return record
 if (directory/'process.json').exists() and load(directory/'process.json').get('exit'):
  for name in ['command.json','process.json','stdout.log','stderr.log']:
   witness=directory/('first-failure-'+name)
   if (directory/name).exists() and not witness.exists():witness.write_bytes((directory/name).read_bytes())
 save(directory/'command.json',entry['command']);started=time.monotonic()
 with(directory/'stdout.log').open('w')as out,(directory/'stderr.log').open('w')as err:
  process=subprocess.run(entry['command'],cwd=R,stdout=out,stderr=err)
 result=dict(exit=process.returncode,seconds=time.monotonic()-started);save(directory/'process.json',result)
 if process.returncode:raise RuntimeError('Host compile failed: '+entry['source']['path']+'; '+str(directory/'stderr.log'))
 if identity(Path(entry['source']['path']))!=entry['source']:raise RuntimeError('Source changed while compiling')
 record=dict(source=entry['source'],object=identity(Path(entry['object'])),command=entry['command'],process=result);save(directory/'identity.json',record)
 print(json.dumps(dict(compiled=entry['source']['path'],seconds=result['seconds'])),flush=True)
 return record
def main():
 a=argparse.ArgumentParser();a.add_argument('action',choices=['plan','build']);args=a.parse_args()
 plan=host_plan()
 if args.action=='build':
  with concurrent.futures.ThreadPoolExecutor(max_workers=2)as workers:
   records=list(workers.map(compile_one,plan['fresh']))
  save(B/'host-ready.json',dict(fresh=records,borrowed_common=plan['borrowed_common'],HTTP=0,SDK_builds=0))
  print(json.dumps(dict(host_ready=True,fresh_TUs=len(records))),flush=True)
if __name__=='__main__':main()
