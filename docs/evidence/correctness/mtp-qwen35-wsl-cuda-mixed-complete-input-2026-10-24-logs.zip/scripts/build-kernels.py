"""Refresh Hyle CUDA adapters; reuse unchanged authenticated FlashInfer units."""
import importlib.util
from pathlib import Path
import concurrent.futures, hashlib, json, os
spec=importlib.util.spec_from_file_location('host',Path(__file__).with_name('build-host.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
R,B,OLD=h.R,h.B,h.OLD

def plan():
 old=h.load(OLD/'hyle-cuda/compile-plan.json')['entries']
 by_source={e['source']:e for e in old}
 old_flash=OLD/'flashinfer-current'
 flash=B/'flashinfer-current'
 manifest=h.load(R/'third_party/flashinfer_cache/patches.json')
 edits={}
 for item in manifest['files']:
  if hashlib.sha256((old_flash/item['path']).read_bytes()).hexdigest()==item['after_sha256']:continue
  raw=Path('/root/.cache/hyle/dependencies/v1/sources/flashinfer-69ff11fc4954-dda66e35e348')/item['path']
  data=raw.read_bytes().replace(b'\r\n',b'\n')
  if hashlib.sha256(data).hexdigest()!=item['before_sha256']:raise ValueError('Raw FlashInfer identity differs')
  for edit in item['edits']:
   before,after=edit['before'].encode(),edit['after'].encode()
   if data.count(before)!=1:raise ValueError('FlashInfer patch is not unique')
   data=data.replace(before,after,1)
  if hashlib.sha256(data).hexdigest()!=item['after_sha256']:raise ValueError('Current FlashInfer result differs')
  edits[item['path']]=data
 # Read-only hardlinks to the existing header tree plus the one changed MLA
 # header. This is neither a duplicate SDK nor a cache mutation.
 for source in (old_flash/'include').rglob('*'):
  if not source.is_file():continue
  relative=source.relative_to(old_flash);destination=flash/relative
  destination.parent.mkdir(parents=True,exist_ok=True)
  data=edits.get(relative.as_posix())
  if data is None:
   if not destination.exists():os.link(source,destination)
   elif destination.read_bytes()!=source.read_bytes():raise ValueError('Borrowed header changed')
  elif not destination.exists():destination.write_bytes(data)
  elif destination.read_bytes()!=data:raise ValueError('Current header changed')
 # Batch/cache native ABI is unchanged and recorded in the earlier complete
 # source/header census. Reuse those exact verified units; do not regenerate
 # all FlashInfer template instantiations for this bounded 2B entry check.
 historical={x['relative']:x for x in h.load(OLD/'hyle-cuda/source-identities.json')}
 retain=[]
 for name in ['native_batch.cu','native_cache.cu','native_cache_encoder.cu','native_highdim.cu']:
  relative='src/compute_provider_flashinfer/'+name
  old_source=historical[relative]
  if h.identity(R/relative)['sha256']!=old_source['sha256']:
   raise ValueError('Retained FlashInfer source changed: '+relative)
  retain.append(dict(source=h.identity(R/relative),object=h.identity(Path(by_source[relative]['object']))))
 for relative in ['src/compute_provider_flashinfer/native_batch.h','src/compute_provider_flashinfer/native_attention.h']:
  if relative in historical and h.identity(R/relative)['sha256']!=historical[relative]['sha256']:
   raise ValueError('Retained FlashInfer private ABI changed: '+relative)
 sources=list(sorted((R/'src/compute_provider_cuda').glob('*.cu')))
 sources+=list(sorted((R/'src/compute_backend_cuda').glob('*.cu')))
 sources += [R/'src/compute_provider_flashinfer/native_attention.cu',R/'src/compute_provider_flashinfer/native_mla.cu',R/'src/compute_provider_ggml_cuda/index_guard.cu',R/'src/compute_provider_torch_cuda/mlx_packed_kernel.cu']
 entries=[]
 for source in sources:
  relative=source.relative_to(R).as_posix();module=source.parent.name
  previous=by_source.get(relative)
  if previous is None:previous=by_source['src/compute_provider_flashinfer/native_batch.cu'if module=='compute_provider_flashinfer'else'src/compute_provider_cuda/sampling_kernel.cu']
  command=[x.replace(str(old_flash),str(flash))for x in h.strip_io(previous['command'])]
  directory=B/'kernels'/relative.replace('/','--');obj=directory/'unit.o'
  includes=[R/'include',R/'src'/module,R/'src/compute_backend_cuda',R/'src/compute_provider_cuda',R/'src/compute',R/'third_party/sglang_activation',R/'third_party/deepseek_fp8',R/'third_party/deepseek_quantization',R/'third_party/mlx_cuda_quant']
  command=[command[0],*['-I'+str(p)for p in includes],*command[1:],'-MMD','-MF',str(directory/'unit.d'),'-c',str(source),'-o',str(obj)]
  entries.append(dict(source=h.identity(source),object=str(obj),command=command))
 record=dict(fresh=entries,borrowed=retain,flashinfer_canonical_manifest=h.identity(R/'third_party/flashinfer_cache/patches.json'),HTTP=0,SDK_builds=0,models_started=0)
 h.save(B/'kernel-plan.json',record)
 print(json.dumps(dict(fresh_kernel_TUs=len(entries),verified_borrowed_kernel_TUs=len(retain))),flush=True)
 return record
def main():
 p=plan()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as workers:
  records=list(workers.map(h.compile_one,p['fresh']))
 h.save(B/'kernel-ready.json',dict(fresh=records,borrowed=p['borrowed'],HTTP=0,SDK_builds=0))
 print(json.dumps(dict(kernel_ready=True,fresh_TUs=len(records))),flush=True)
if __name__=='__main__':main()
