"""One frozen current Qwen application TU for the two WSL functional cases."""
from pathlib import Path
import importlib.util, json, shutil
spec=importlib.util.spec_from_file_location('host',Path(__file__).with_name('build-host.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
R,B,CPU=h.R,h.B,h.CPU
def main():
 root=B/'app/source'
 if root.exists():raise RuntimeError('App freeze already exists; preserve its first compile result')
 sources=[]
 for folder in ['engine/models/qwen35','engine/inference']:
  for source in sorted((R/folder).iterdir()):
   if source.suffix not in ['.h','.cc']:continue
   dest=root/source.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
   sources.append(dict(original=h.identity(source),frozen=h.identity(dest)))
 entry=root/'probe.cc';entry.write_text('#include "engine/models/qwen35/main.cc"\nint main(int argc, char **argv) { return qwen35::run(argc, argv); }\n')
 command=h.strip_io(h.load(CPU/'model-ready.json')['command'])
 # Replace old frozen/portable app include roots; all product/public and
 # third-party include roots remain those of the validated cached recipe.
 command=[x for x in command if 'portable-source'not in x and 'geometry-cpu-check2/source'not in x]
 command=[command[0],'-I'+str(root),'-I'+str(root/'engine/models/qwen35'),'-DHYLE_COMPUTE_CUDA=1','-DHYLE_COMPUTE_GGML_CUDA=1','-DHYLE_COMPUTE_FLASHINFER=1',*command[1:],'-MMD','-MF',str(B/'app/unit.d'),'-c',str(entry),'-o',str(B/'app/unit.o')]
 h.save(B/'app/sources.json',sources)
 record=h.compile_one(dict(source=h.identity(entry),object=str(B/'app/unit.o'),command=command))
 for source in sources:
  if h.identity(Path(source['original']['path']))!=source['original']:raise RuntimeError('Product app changed during compile')
 h.save(B/'app-ready.json',dict(record=record,sources=sources,HTTP=0,SDK_builds=0,models_started=0))
 print(json.dumps(dict(app_ready=True,object=record['object'])),flush=True)
if __name__=='__main__':main()
