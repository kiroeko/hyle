"""Current CUDA file-stream facade absent from the historical Graph consumer."""
from pathlib import Path
import importlib.util, json
spec=importlib.util.spec_from_file_location('host',Path(__file__).with_name('build-host.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def main():
 source=h.R/'src/compute_stream_cuda/file_stream.cc';directory=h.B/'extra/cuda-file-stream';obj=directory/'unit.o'
 template=next(e for e in h.load(h.B/'host-plan.json')['fresh']if e['source']['path'].endswith('/compute_route_cuda/cuda_context.cc'))
 command=h.strip_io(template['command'])
 command += ['-DHYLE_IO_HAS_COROUTINE_TRANSPORT=1','-MMD','-MF',str(directory/'unit.d'),'-c',str(source),'-o',str(obj)]
 record=h.compile_one(dict(source=h.identity(source),object=str(obj),command=command))
 h.save(h.B/'extra-ready.json',dict(records=[record],SDK_builds=0,HTTP=0))
if __name__=='__main__':main()
