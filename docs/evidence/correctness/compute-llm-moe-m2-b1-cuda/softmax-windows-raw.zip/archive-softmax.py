import hashlib
import json
from pathlib import Path
import re
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"C:\public\project-hyle\hyle")
WORK = ROOT / ".scratch/validation/m2-b1-cuda"
OUT = ROOT / "evidence/correctness/compute-llm-moe-m2-b1-cuda"
BUILD = Path(r"C:\hv\m2b1-cuda")


def read(path):
    try:
        return path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        return path.read_text(encoding="gb18030")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


assert "100% tests passed out of 8" in read(WORK / "softmax-test-c1.log")
cases = list(map(int, re.findall(r"\[  PASSED  \] (\d+) tests\.", read(WORK / "softmax-ctest-c1.log"))))
assert cases == [7, 22, 13, 5], cases
loc = read(WORK / "softmax-loc.log")
assert re.search(r"module implementation \(compute-graph-all\)\s+55,510\s+241", loc)
assert "self-check: PASS" in loc
plan = json.loads(read(WORK / "softmax-final-plan.json"))
paths = git("diff", "--name-only", "e44226dc", "--", "src", "tests", "include").splitlines()
assert paths and len(paths) == 9, paths
raw = sorted(p for p in WORK.glob("softmax-*") if p.is_file())
raw += [WORK / "archive-softmax.py", WORK / "development.ps1"]
archive_path = OUT / "softmax-windows-raw.zip"
with ZipFile(archive_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in raw:
        archive.write(path, path.name)
    archive.write(BUILD / "CMakeCache.txt", "CMakeCache.txt")


def checked(name, expected):
    path = WORK / name
    if not path.exists():
        return "UNRUN"
    return "PASS" if expected in read(path) else "INCONCLUSIVE; inspect raw log"


receipt = {
    "kind": "M2-B1 CUDA second development batch; incomplete B1 card and no complete model coverage",
    "baseline": git("rev-parse", "62d1654c"),
    "audited_checkpoint": git("rev-parse", "e44226dc"),
    "candidate": "WORKTREE; exact changed product/test hashes below; not immutable P1 candidate",
    "selector_candidate_tree": plan["candidate_tree"],
    "machine": "Windows x64; RTX4070 SM89; MSVC19.50.35728; CUDA Toolkit13.3.73; Ninja Release shared",
    "settings": {"cuda_architectures": "89-real", "cpu": False, "cuda": True, "werror": True,
                 "sanitizer": "off", "parallel_build": 2, "parallel_test": 1,
                 "dlls_next_to_executables": True, "error_mode": "0x8003", "uac_or_power_changes": False},
    "ggml_revision": "456172ec733a135778adcd32d00e576a58232e45",
    "binding": json.loads(read(OUT / "source-audit.json"))["second_binding"],
    "windows_development": {"verdict": "PASS", "ctest_targets": 8, "header_targets": 4,
                            "gtest_executions": sum(cases), "ordinary_direct": cases[0],
                            "ordinary_graph": cases[1], "compute_provider": cases[2],
                            "graph_provider": cases[3], "softmax_provider_parameter_cases": 78},
    "preserved_failures": [
        {"log": "softmax-build.log", "cause": "New test header omitted algorithm include for ranges::fill", "correction": "Added explicit standard include; softmax-build-c1.log"},
        {"log": "softmax-test.log", "ctest_log": "softmax-ctest.log",
         "cause": "One old TopK consumer required bitwise float equality between now-different ordinary ggml and prepared capture Softmax",
         "correction": "Each path checked against the same existing FP64 oracle and unchanged 4e-6 relative plus 2e-7 absolute tolerance; indices stay exact, original capture/lifetime gates remain",
         "root_cause_corrections": 1, "final_log": "softmax-test-c1.log"},
    ],
    "selector": {"selection_verdict": plan["verdict"],
                 "selected_ids": [gate["id"] for gate in plan["selected_gates"]],
                 "skipped_count": len(plan["skipped_gates"]),
                 "skipped_reasons": "Full plan in raw archive",
                 "scope": "Windows affected factors/headers and configure only; full card acceptance remains incomplete"},
    "governance": {"docs": checked("softmax-docs.log", "documentation contract passed"),
                   "closure": checked("softmax-closure.log", "module closure contract passed"),
                   "registry_changed": False},
    "unrun_applicable_acceptance": ["WSL new-code native CUDA", "Air/Mini CUDA-OFF", "new-code host sanitizers",
                                    "complete B1 source/static/shared journeys", "full 21-row independent candidate review", "immutable-candidate P1"],
    "remaining": json.loads(read(OUT / "source-audit.json"))["remaining"],
    "complete_requirement_cells": 0, "performance_samples": 0, "new_math_kernels": 0, "frozen_hyle_math_changes": 0,
    "source_design_budget_minutes": {"used": 72, "remaining": 48, "total": 120},
    "loc": {"implementation_lines": 55510, "files": 241, "tests_and_vendors_excluded": True},
    "build_directory": {"path": str(BUILD), "bytes": sum(p.stat().st_size for p in BUILD.rglob("*") if p.is_file()),
                        "retained_reason": "Same single current CUDA development build; no new build tree"},
    "archive": {"path": archive_path.name, "sha256": sha(archive_path), "bytes": archive_path.stat().st_size, "files": len(raw) + 1},
    "source_hashes": [{"path": path, "sha256": sha(ROOT / path)} for path in paths],
}
(OUT / "softmax-windows.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"ctest": 8, "gtest": sum(cases), "implementation_loc": 55510, "governance": receipt["governance"], "archive_bytes": archive_path.stat().st_size}))
