param([ValidateSet('Build','Run')][string]$Action = 'Build')
$ErrorActionPreference = 'Stop'
$probeBuild = 'C:\hv\m2b1-gather-probe'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleGatherProbeErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[void][HyleGatherProbeErrorMode]::SetErrorMode(0x8003)
if (-not (Test-Path -LiteralPath $probeBuild)) {
    New-Item -ItemType Directory -Path $probeBuild | Out-Null
    Set-Content -LiteralPath (Join-Path $probeBuild '.hyle-owner') -Value 'M2-B1 CUDA-I original Gather probe; /root; disposable after archive' -Encoding utf8
}
if ((Get-Content -LiteralPath (Join-Path $probeBuild '.hyle-owner') -Raw).Trim() -ne 'M2-B1 CUDA-I original Gather probe; /root; disposable after archive') { throw 'Unexpected probe build owner.' }
if ($Action -eq 'Build') {
    & cmd.exe /d /c 'C:\public\project-hyle\hyle\.scratch\validation\m2-b1-cuda\gather-probe-build.cmd'
} else {
    foreach ($runtimeDll in Get-ChildItem -LiteralPath 'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\x64' -Filter 'cudart64*.dll' -File) {
        Copy-Item -LiteralPath $runtimeDll.FullName -Destination (Join-Path $probeBuild $runtimeDll.Name) -Force
    }
    & (Join-Path $probeBuild 'probe.exe')
}
exit $LASTEXITCODE
