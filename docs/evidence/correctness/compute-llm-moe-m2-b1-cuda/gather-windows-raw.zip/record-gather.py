import json
from pathlib import Path

root = Path(r"C:\public\project-hyle\hyle")
registry_path = root / "docs/implementation/module-status.json"
registry = json.loads(registry_path.read_text(encoding="utf-8"))
entries = next(v for v in registry.values() if isinstance(v, list) and v and isinstance(v[0], dict) and "module" in v[0])
for entry in entries:
    if entry["module"] in {"compute_provider_cuda", "compute_route_cuda"}:
        assert entry["state"] == "AUDITED"
        entry["summary"] = "M2-B1 CUDA-I AUDITED：原版CCCL Scan/TopK/Gather已接普通Direct/Graph；Windows10/10 CTest、105次GoogleTest执行通过，Gather全storage/checked失败与双slot已验。共享源码预算110/120；完整跨平台/三交付/P1及21行仍未完成，新覆盖0，自研冻结。"
registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
audit_path = root / "evidence/correctness/compute-llm-moe-m2-b1-cuda/source-audit.json"
audit = json.loads(audit_path.read_text(encoding="utf-8"))
audit["source_design_budget_minutes"] = {"used": 110, "remaining": 10, "total": 120}
audit["remaining"][2] = "dynamic Scatter; CCCL Scan/TopK/Gather Windows development passed but full applicable acceptance remains"
audit["fourth_binding"] = {
    "audited_checkpoint": "4a2b4b32178dd72f5f2262fe689d5bb2e4dc0f47",
    "owner": ["compute_provider_cuda"],
    "operation": "Original Thrust Gather with CUB Min/Max checked I32/I64 indices; plain 1/2/4/8-byte storage preserved",
    "domain": "CUDA13.3 toolkit/runtime, CCCL3.3.4, SM89; public rank/axis/byte strides; dense output; output/indices<=INT32_MAX, storage spans<=PTRDIFF_MAX; no output alias",
    "projection": "Only scalar index/type/axis/byte-address projection; no custom gather loop/kernel",
    "resources": "Caller per-slot checked workspace; 16-byte validation summary/host wait; unchecked no workspace; native stream/Completion; empty output no payload read",
    "execution_evidence": "gather-windows.json",
    "card_verdict": "INCONCLUSIVE; Windows development pass does not close full B1 or cross-platform/delivery/performance gates",
}
audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print("Recorded Gather Windows checkpoint; owners remain AUDITED; source/design 110/120")
