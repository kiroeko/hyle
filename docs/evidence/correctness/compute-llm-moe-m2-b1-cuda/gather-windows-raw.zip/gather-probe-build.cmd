@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\nvcc.exe" -std=c++20 -arch=sm_89 --expt-relaxed-constexpr -Xcompiler=/Zc:preprocessor,/utf-8,/EHsc,/MD -o "C:\hv\m2b1-gather-probe\probe.exe" "C:\public\project-hyle\hyle\.scratch\validation\m2-b1-cuda\gather-probe.cu"
exit /b %errorlevel%
