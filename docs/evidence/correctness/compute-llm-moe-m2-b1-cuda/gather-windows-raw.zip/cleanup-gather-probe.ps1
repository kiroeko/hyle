$ErrorActionPreference = 'Stop'
$probeTarget = (Resolve-Path -LiteralPath 'C:\hv\m2b1-gather-probe').Path
if ($probeTarget -ne 'C:\hv\m2b1-gather-probe') { throw 'Unexpected resolved probe directory' }
if ((Get-Item -LiteralPath $probeTarget).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Probe directory is a link' }
$probeOwner = Get-Content -LiteralPath (Join-Path $probeTarget '.hyle-owner') -Raw
if ($probeOwner.Trim() -ne 'M2-B1 CUDA-I original Gather probe; /root; disposable after archive') { throw 'Probe owner differs' }
$evidenceRoot = 'C:\public\project-hyle\hyle\evidence\correctness\compute-llm-moe-m2-b1-cuda'
$receipt = Get-Content -LiteralPath (Join-Path $evidenceRoot 'gather-qualification.json') -Raw | ConvertFrom-Json
$archivePath = Join-Path $evidenceRoot 'gather-qualification-raw.zip'
if ((Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash -ne $receipt.archive.sha256) { throw 'Archived evidence hash differs' }
$probeFiles = @(Get-ChildItem -LiteralPath $probeTarget -Recurse -Force)
if ($probeFiles | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }) { throw 'Probe contains a link' }
$probeBytes = ($probeFiles | Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
Remove-Item -LiteralPath $probeTarget -Recurse -Force
Write-Output "Removed owned archived probe directory: $probeTarget; bytes=$probeBytes"
