#include <cub/device/device_reduce.cuh>
#include <thrust/gather.h>
#include <thrust/iterator/counting_iterator.h>
#include <thrust/iterator/transform_iterator.h>
#include <thrust/system/cuda/execution_policy.h>
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include <limits>

static bool check(cudaError_t status) {
  if (status == cudaSuccess) return true;
  std::fprintf(stderr, "CUDA error: %s\n", cudaGetErrorString(status));
  return false;
}
template <class T> struct Read {
  const char *pointer; std::size_t stride;
  __device__ T operator()(std::size_t logical) const {
    T value; memcpy(&value, pointer + logical * stride, sizeof(T)); return value;
  }
};
template <class I> struct Index {
  Read<I> read;
  __device__ std::int64_t operator()(std::size_t logical) const { return read(logical); }
};
template <class I> struct Map {
  Read<I> read;
  __device__ std::size_t operator()(std::size_t logical) const {
    return (logical / 12 * 4 + read(logical / 3 % 4)) * 3 + logical % 3;
  }
};
template <class T, class I> bool run() {
  constexpr std::size_t count = 24;
  const auto source_stride = sizeof(T) + 1, index_stride = sizeof(I) + 1;
  std::vector<T> values(count);
  std::vector<char> source(count * source_stride), indices(4 * index_stride);
  for (std::size_t i = 0; i < count; ++i) {
    values[i] = static_cast<T>((std::uint64_t{0xfaceabcdfffff000} + i * 7));
    std::memcpy(source.data() + i * source_stride, &values[i], sizeof(T));
  }
  void *source_device = nullptr, *index_device = nullptr, *output_device = nullptr, *bounds_device = nullptr, *temporary = nullptr;
  cudaStream_t stream;
  if (!check(cudaStreamCreate(&stream)) || !check(cudaMalloc(&source_device, source.size())) ||
      !check(cudaMalloc(&index_device, indices.size())) || !check(cudaMalloc(&output_device, count * sizeof(T))) ||
      !check(cudaMalloc(&bounds_device, 16))) return false;
  auto values_iterator = thrust::make_transform_iterator(thrust::counting_iterator<std::size_t>(0), Read<T>{static_cast<const char *>(source_device), source_stride});
  auto index_iterator = thrust::make_transform_iterator(thrust::counting_iterator<std::size_t>(0), Index<I>{{static_cast<const char *>(index_device), index_stride}});
  auto mapping = thrust::make_transform_iterator(thrust::counting_iterator<std::size_t>(0), Map<I>{{static_cast<const char *>(index_device), index_stride}});
  std::size_t min_bytes = 0, max_bytes = 0;
  if (!check(cub::DeviceReduce::Min(nullptr, min_bytes, index_iterator, static_cast<std::int64_t *>(bounds_device), 4)) ||
      !check(cub::DeviceReduce::Max(nullptr, max_bytes, index_iterator, static_cast<std::int64_t *>(bounds_device) + 1, 4))) return false;
  const auto bytes = min_bytes > max_bytes ? min_bytes : max_bytes;
  if (!check(cudaMalloc(&temporary, bytes))) return false;
  bool good = true;
  for (int mode = 0; mode < 5; ++mode) {
    const I selected[4]{3, 1, 1, mode == 0 ? I{0} : mode == 1 ? I{-1} : mode == 2 ? I{4} : mode == 3 ? std::numeric_limits<I>::max() : I{2}};
    for (std::size_t j = 0; j < 4; ++j) std::memcpy(indices.data() + j * index_stride, &selected[j], sizeof(I));
    good &= check(cudaMemcpyAsync(source_device, source.data(), source.size(), cudaMemcpyHostToDevice, stream));
    good &= check(cudaMemcpyAsync(index_device, indices.data(), indices.size(), cudaMemcpyHostToDevice, stream));
    good &= check(cudaMemsetAsync(output_device, 0xa5, count * sizeof(T), stream));
    auto usable = bytes;
    good &= check(cub::DeviceReduce::Min(temporary, usable, index_iterator, static_cast<std::int64_t *>(bounds_device), 4, stream));
    usable = bytes;
    good &= check(cub::DeviceReduce::Max(temporary, usable, index_iterator, static_cast<std::int64_t *>(bounds_device) + 1, 4, stream));
    std::int64_t bounds[2];
    good &= check(cudaMemcpyAsync(bounds, bounds_device, sizeof(bounds), cudaMemcpyDeviceToHost, stream));
    good &= check(cudaStreamSynchronize(stream));
    const bool valid = bounds[0] >= 0 && bounds[1] < 4;
    good &= valid == (mode == 0 || mode == 4);
    if (valid)
      thrust::gather(thrust::cuda::par_nosync.on(stream), mapping, mapping + count, values_iterator, static_cast<T *>(output_device));
    std::vector<T> actual(count);
    good &= check(cudaMemcpyAsync(actual.data(), output_device, count * sizeof(T), cudaMemcpyDeviceToHost, stream));
    good &= check(cudaStreamSynchronize(stream));
    if (valid) {
      for (std::size_t outer = 0; outer < 2; ++outer)
        for (std::size_t index = 0; index < 4; ++index)
          for (std::size_t inner = 0; inner < 3; ++inner)
            good &= actual[(outer * 4 + index) * 3 + inner] == values[(outer * 4 + selected[index]) * 3 + inner];
    } else {
      const auto *raw = reinterpret_cast<const unsigned char *>(actual.data());
      for (std::size_t i = 0; i < count * sizeof(T); ++i) good &= raw[i] == 0xa5;
    }
  }
  check(cudaFree(temporary)); check(cudaFree(bounds_device)); check(cudaFree(output_device)); check(cudaFree(index_device)); check(cudaFree(source_device)); check(cudaStreamDestroy(stream));
  std::printf("original_gather storage=%zu index=%zu cases=5 %s\n", sizeof(T), sizeof(I), good ? "PASS" : "FAIL");
  return good;
}
int main() {
  bool good = true;
  good &= run<std::uint8_t, std::int32_t>(); good &= run<std::uint16_t, std::int32_t>();
  good &= run<std::uint32_t, std::int32_t>(); good &= run<std::uint64_t, std::int32_t>();
  good &= run<std::uint8_t, std::int64_t>(); good &= run<std::uint16_t, std::int64_t>();
  good &= run<std::uint32_t, std::int64_t>(); good &= run<std::uint64_t, std::int64_t>();
  return good ? 0 : 1;
}
