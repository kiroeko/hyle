import hashlib
import json
from pathlib import Path
import re
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"C:\public\project-hyle\hyle")
WORK = ROOT / ".scratch/validation/m2-b1-cuda"
OUT = ROOT / "evidence/correctness/compute-llm-moe-m2-b1-cuda"
BUILD = Path(r"C:\hv\m2b1-cuda")

def read(path):
    try:
        return path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        return path.read_text(encoding="gb18030")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()

assert "100% tests passed out of 10" in read(WORK / "gather-test.log")
counts = list(map(int, re.findall(r"\[  PASSED  \] (\d+) tests\.", read(WORK / "gather-ctest.log"))))
assert counts == [53, 8, 26, 13, 5], counts
assert "56,374" in read(WORK / "gather-loc.log")
assert "self-check: PASS" in read(WORK / "gather-loc.log")
assert "Removed owned archived probe directory:" in read(WORK / "gather-cleanup.log")
assert not Path(r"C:\hv\m2b1-gather-probe").exists()
paths = set(git("diff", "--name-only", "4a2b4b32", "--", "src", "include", "tests").splitlines())
paths.add("tests/compute_provider_cuda/gather_collectives_test.cc")
product_paths = sorted(p for p in paths if p.startswith(("src/", "include/")))
assert product_paths == ["include/hyle/compute/providers/cuda.h", "src/compute_provider_cuda/collectives.cu",
                         "src/compute_provider_cuda/collectives.h", "src/compute_provider_cuda/collectives_provider.cc"], product_paths
assert "__global__" not in read(ROOT / "src/compute_provider_cuda/collectives.cu")
qualification = json.loads(read(OUT / "gather-qualification.json"))
assert sha(OUT / qualification["archive"]["path"]) == qualification["archive"]["sha256"]
plan = json.loads(read(WORK / "gather-plan.json"))
audit = json.loads(read(OUT / "source-audit.json"))
assert audit["source_design_budget_minutes"] == {"used": 110, "remaining": 10, "total": 120}

raw = sorted(p for p in WORK.glob("gather-*") if p.is_file())
raw += [WORK / name for name in ["collectives-development.ps1", "archive-gather.py", "cleanup-gather-probe.ps1", "record-gather.py"]]
archive_path = OUT / "gather-windows-raw.zip"
with ZipFile(archive_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in raw:
        archive.write(path, path.name)
    archive.write(BUILD / "CMakeCache.txt", "CMakeCache.txt")

def gate(name, expected):
    path = WORK / name
    if not path.exists():
        return "UNRUN"
    return "PASS" if expected in read(path) else "INCONCLUSIVE; inspect raw log"

receipt = {
    "kind": "M2-B1 CUDA-I I5 Gather Windows product development checkpoint; not a terminal/full-domain verdict",
    "baseline": git("rev-parse", "9d65d637"),
    "scope_checkpoint": git("rev-parse", "fa65e0dc"),
    "audited_checkpoint": git("rev-parse", "4a2b4b32"),
    "candidate": "WORKTREE; exact product/test hashes below; not immutable P1 candidate",
    "selector_candidate_tree": plan["candidate_tree"],
    "machine": "Windows RTX4070 SM89; MSVC19.50.35728; CUDA13.3.73 / CCCL3.3.4; Ninja Release shared",
    "settings": {"cuda_architectures": "89-real", "werror": True, "cpu": False, "cuda": True,
                 "build_parallel": 2, "test_parallel": 1, "sanitizer": "off", "dlls_adjacent": True,
                 "error_mode": "0x8003", "uac_or_power_changes": False},
    "binding": audit["fourth_binding"],
    "windows_development": {"verdict": "PASS", "ctest_targets": 10, "header_targets": 5,
                            "gtest_executions": sum(counts), "cccl_and_existing_cuda_provider": 53,
                            "ordinary_direct": 8, "ordinary_graph": 26, "ggml_compute": 13, "ggml_graph": 5},
    "coverage": [
        "15 plain storage types x I32/I64 indices x axis0/1/-1 x dense/odd source stride x dense/odd index stride = 360 cases; bits checked against independent host oracle",
        "rank8, rank6/scalar index, zero source/index stride; arbitrary aligned base with odd byte strides",
        "checked negative, axis-width, I64 max/min reject with whole output unchanged; failed slot retires and fresh slot recovers",
        "workspace missing/short and source-output/index-output alias reject; unchecked no workspace or adapter host wait; empty outer/indices do not read invalid payload; host resource declined",
        "ordinary Direct automatically binds CCCL; Graph TopK->Gather uses default options with two queues/slots, changing inputs and retained old results; Graph failure/fresh-slot recovery",
        "shared CCCL metadata OOM and completion-owner regression retained; no native GPU OOM injection claim; frozen capture paths explicitly require prepared execution",
    ],
    "failures": [],
    "validation_notes": "Both product builds and the first full I5 targeted test run passed. Existing tests migrated to CCCL identity/workspace and explicit prepared-only capture semantics before running; no numeric tolerance changes.",
    "p0": [
        "Checked path: two original GPU reductions over indices, 16-byte control summary/host wait, then original Gather over output elements; all costs included",
        "Workspace holds two I64 summary values and original SDK temporary space; unchecked skips validation/workspace",
        "Only scalar storage/index/address projection; same native stream and Completion; no own global kernel, runtime, queue, thread or retained tensor copy",
    ],
    "selector": {"selection_verdict": plan["verdict"],
                 "selected_ids": [x["id"] for x in plan["selected_gates"]],
                 "skipped_count": len(plan["skipped_gates"]),
                 "skipped_reasons": "Full plan in raw archive",
                 "aggregate_execution": "INCONCLUSIVE; selected delivery gates unrun; five declared native/header suites executed by bounded development driver"},
    "maintenance": {"docs": gate("gather-docs.log", "documentation contract passed"),
                    "closure": gate("gather-closure.log", "module closure contract passed"),
                    "previous_registry_ref": git("rev-parse", "4a2b4b32"),
                    "loc_self_check": "PASS"},
    "remaining_unrun": ["WSL native GPU", "Air/Mini CUDA-OFF", "host sanitizers", "source/static/shared relocated consumer", "final immutable candidate review", "immutable-candidate P1"],
    "all_21_b1_rows": "INCONCLUSIVE; unbound exact domains and unrun applicable gates remain",
    "new_complete_requirement_cells": 0,
    "frozen_math_changed_paths": [],
    "performance_samples": 0,
    "source_design_budget_minutes": {"used": 110, "remaining": 10, "total": 120},
    "loc": {"compute_graph_implementation": 56374, "files": 244, "excludes": "tests/vendor", "raw": "gather-loc.log"},
    "cleanup": {"directory": r"C:\hv\m2b1-gather-probe", "removed_bytes": 1461941,
                "proof": "gather-cleanup.log; original qualification archive hash verified before exact owned directory removal",
                "build_reuse": "existing CPU/CUDA development trees; no new duplicate build tree"},
    "product_and_test_sha256": {path: sha(ROOT / path) for path in sorted(paths)},
    "artifact_sha256": {name: sha(BUILD / "bin" / name) for name in ["hyle_compute_provider_cuda.dll", "hyle_compute_route_cuda.dll", "hyle_compute_provider_cuda_test.exe", "hyle_compute_route_cuda_test.exe", "hyle_graph_route_cuda_test.exe"]},
    "archive": {"path": archive_path.name, "sha256": sha(archive_path), "bytes": archive_path.stat().st_size},
}
(OUT / "gather-windows.json").write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"windows": "PASS", "tests": counts, "archive_bytes": archive_path.stat().st_size,
                  "maintenance": receipt["maintenance"], "card": "INCONCLUSIVE"}))
