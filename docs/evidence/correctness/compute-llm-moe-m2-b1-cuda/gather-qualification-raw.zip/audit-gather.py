import hashlib, json, subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root = Path(r'C:\public\project-hyle\hyle')
work = root / '.scratch/validation/m2-b1-cuda'
out = root / 'evidence/correctness/compute-llm-moe-m2-b1-cuda'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
lines = (work / 'gather-probe-run.log').read_text(encoding='utf-8-sig').splitlines()
assert len(lines) == 8 and all(x.endswith('cases=5 PASS') for x in lines), lines
archive = out / 'gather-qualification-raw.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(work.glob('gather-probe*')): z.write(p, p.name)
    z.write(work / 'audit-gather.py', 'audit-gather.py')
sdk = Path(r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\include\cccl')
receipt = {
    'kind': 'Original CCCL/Thrust Gather qualification, not HYLE product acceptance',
    'scope_checkpoint': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'machine': 'Windows RTX4070 SM89; MSVC19.50.35728; CUDA13.3.73 / CCCL3.3.4',
    'algorithm': 'Original DeviceReduce Min/Max of logical I32/I64 indices, two host validation scalars, thrust::gather with par_nosync on native stream; source/index iterators only project byte strides and axes',
    'verdict': 'PASS', 'cases': 40,
    'coverage': ['1/2/4/8-byte source bit patterns', 'I32/I64 indices', 'odd source/index byte strides', 'middle-axis with two outer and three inner values', 'repeated indices', 'negative, axis-width and maximum-signed index rejection leaves whole output sentinel unchanged', 'changed valid indices after failed cases'],
    'limits': ['Not ordinary HYLE entry/Graph/resource acceptance', 'No CUDA self-written math inspection or performance comparison', 'No WSL/SDK/sanitizer/P1'],
    'sdk_source_sha256': {p: sha(sdk/p) for p in ['thrust/gather.h','thrust/system/cuda/detail/gather.h','thrust/system/cuda/detail/transform.h','cub/device/device_reduce.cuh']},
    'executable_sha256': sha(Path(r'C:\hv\m2b1-gather-probe\probe.exe')),
    'archive': {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size},
    'shared_source_design_budget_minutes': {'used':108,'remaining':12,'total':120},
    'new_complete_requirement_cells':0, 'performance_samples':0,
}
(out/'gather-qualification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'docs/implementation/module-status.json'
d=json.loads(p.read_text(encoding='utf-8-sig'))
m=next(m for m in d['modules'] if m['module']=='compute_provider_cuda')
assert m['state']=='AUDITED'
m['summary']='M2-B1 CUDA-I AUDITED：原版CCCL Scan/TopK已获Windows开发证据；I5原版Thrust Gather在40组原版资格通过后冻结有限接法，checked I32/I64与全storage位宽、普通入口和资源验证，父卡共享120分钟预算，旧自研冻结。'
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'qualification':'PASS','cases':40,'archive_bytes':archive.stat().st_size}))
