import hashlib
import json
from pathlib import Path
import re
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(r"C:\public\project-hyle\hyle")
WORK = ROOT / ".scratch/validation/m2-b1-cuda"
OUT = ROOT / "evidence/correctness/compute-llm-moe-m2-b1-cuda"
BUILD = Path(r"C:\hv\m2b1-cuda")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    try:
        return path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        return path.read_text(encoding="gb18030")


plan = json.loads(read(WORK / "final-plan.json"))
test_log = read(WORK / "test-c2.log")
ctest_log = read(WORK / "ctest-final.log")
assert "100% tests passed out of 8" in test_log
case_counts = [int(count) for count in re.findall(r"\[  PASSED  \] (\d+) tests\.", ctest_log)]
assert case_counts == [6, 21, 11, 4], case_counts
loc = read(WORK / "loc.log")
assert re.search(r"module implementation \(compute-graph-all\)\s+55,462\s+241", loc)
assert "self-check: PASS" in loc

paths = git(
    "ls-files", "include/hyle/compute/providers/ggml_cuda.h",
    "include/hyle/graph/providers/ggml_cuda.h", "src/compute_provider_ggml_cuda",
    "src/graph_provider_ggml_cuda", "tests/compute_provider_ggml_cuda",
    "tests/graph_provider_ggml_cuda", "tests/compute_route_cuda", "tests/graph_route_cuda",
).splitlines()
source_hashes = [{"path": p, "sha256": sha(ROOT / p)} for p in paths]

archive_path = OUT / "development-windows-raw.zip"
log_paths = sorted(p for p in WORK.iterdir() if p.suffix in {".log", ".json", ".ps1", ".py"})
with ZipFile(archive_path, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for path in log_paths:
        archive.write(path, path.name)
    archive.write(BUILD / "CMakeCache.txt", "CMakeCache.txt")
    archive.write(BUILD / ".hyle-owner", "build-owner.txt")

def governance_verdict(name, expected):
    path = WORK / name
    if not path.exists():
        return "UNRUN"
    value = read(path)
    return "PASS" if expected in value else "INCONCLUSIVE; inspect raw log"

receipt = {
    "kind": "M2-B1 CUDA development checkpoint; not complete card, immutable P1 candidate or model coverage",
    "baseline": git("rev-parse", "c9744a45"),
    "scoped_checkpoint": git("rev-parse", "be44efa5"),
    "audited_checkpoint": git("rev-parse", "4d46d4d0"),
    "slice_audited_checkpoint": git("rev-parse", "3911a3c1"),
    "candidate": "WORKTREE; exact product/test hashes below",
    "selector_candidate_tree": plan["candidate_tree"],
    "machine": "Windows x64; RTX4070 SM89; MSVC 19.50.35728.0; CUDA Toolkit 13.3.73; Ninja Release shared",
    "ggml_revision": "456172ec733a135778adcd32d00e576a58232e45",
    "settings": {
        "cpu": False, "cuda": True, "onednn": False, "apple": False, "vulkan": False,
        "cuda_architectures": "89-real", "werror": True, "parallel_build": 2,
        "parallel_test": 1, "sanitizer": "off", "dlls_next_to_executables": True,
        "error_mode": "0x8003", "uac_or_power_changes": False,
    },
    "selected_development_targets": {
        "verdict": "PASS", "ctest_targets": 8, "self_contained_headers": 4,
        "ordinary_direct_cases": 6, "ordinary_graph_cases": 21,
        "compute_provider_cases": 11, "graph_provider_cases": 4,
        "gtest_executions": 42,
        "note": "Includes unchanged fallback/capture regressions; those are not new mature coverage",
    },
    "first_binding": json.loads(read(OUT / "source-audit.json"))["first_binding"],
    "preserved_failures_and_corrections": [
        {
            "logs": ["build.log", "build-c1.log"],
            "cause": "Tried optional unknown on Graph artifact copy_bytes, whose existing type is size_t",
            "correction": "Keep artifact 0 for known extra adapter boundary copies; proposal native internal copy/repack remains unknown and guides explain this distinction",
        },
        {
            "logs": ["test.log", "ctest-initial.log"],
            "cause": "New mature default is managed; nine old external-capture consumers did not declare existing prepared-only compile requirement, and Direct provider assertions named old defaults",
            "correction": "Use existing ProviderReplayPolicy::kRequirePrepared only for actual capture graph; keep RequireCapture, failure/lifetime checks and unrestricted ordinary default tests",
        },
        {
            "logs": ["test-c1.log", "ctest-capture-c1.log", "build-c2.log", "build-c3.log", "test-c2.log", "ctest-final.log"],
            "cause": "Real typed Direct Copy/Concat slices rejected by inherited 256-byte boundary requirement, plus remaining old provider ID assertions",
            "correction": "Pre-audited element alignment for Copy/Cast/Concat, max across all readers/writers of each boundary value; math remains 256; final all eight CTests pass",
            "root_cause_corrections": 1,
        },
    ],
    "selector": {
        "plan": "final-plan.json in raw archive", "selection_verdict": plan["verdict"],
        "selected_gates": plan["selected_gates"], "skipped_gate_count": len(plan["skipped_gates"]),
        "execution_aggregate": "INCONCLUSIVE",
        "pending_selected": ["delivery:compute", "delivery:graph"],
        "note": "Affected Windows development factors and headers passed; full delivery deferred to stable complete B1 candidate. Every skipped reason retained in raw plan.",
    },
    "governance": {
        "docs": governance_verdict("docs.log", "documentation contract passed"),
        "closure": governance_verdict("closure.log", "module closure contract passed"),
        "registry_changed_in_this_product_checkpoint": False,
    },
    "remaining": json.loads(read(OUT / "source-audit.json"))["remaining"],
    "unrun_applicable_acceptance": [
        "WSL native CUDA on this new code", "Air/Mini CUDA-OFF selected gates",
        "host sanitizers for new code", "Windows/WSL source/static/shared relocated consumer journeys",
        "complete 21-row requirements and final independent candidate review", "immutable-candidate P1",
    ],
    "complete_requirement_cells": 0,
    "source_design_budget_minutes": {"used": 56, "remaining": 64, "total": 120},
    "performance_samples": 0,
    "new_math_kernels": 0,
    "frozen_hyle_math_changes": 0,
    "loc": {"implementation_lines": 55462, "files": 241, "tests_and_vendors_excluded": True},
    "build_directory": {
        "path": str(BUILD), "bytes": sum(p.stat().st_size for p in BUILD.rglob("*") if p.is_file()),
        "retained_reason": "Single active CUDA development build; reused for remaining M2-B1 integration. CPU current build separately retained. No cloned build trees.",
    },
    "archive": {"path": archive_path.name, "sha256": sha(archive_path), "files": len(log_paths) + 2, "bytes": archive_path.stat().st_size},
    "source_hashes": source_hashes,
}
(OUT / "development-windows.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"ctest": 8, "gtest": 42, "loc": 55462, "archive_bytes": archive_path.stat().st_size, "governance": receipt["governance"]}))
