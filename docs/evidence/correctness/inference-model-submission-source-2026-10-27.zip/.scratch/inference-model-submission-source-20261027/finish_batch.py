from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,h=c.b,c.h
EXPECTED={
 'src/compute_provider_cuda/collectives.cu':'f8427169ace72307c11dc22a534e26e5ea0eed64187ae655208b8d6aa51ca309',
 'tests/graph_route_cuda/topk_test.cc':'c7e7022edebdde8d46025042d7a91158d759c3cc4c5bc6b7f0589b4c87201c09',
 'tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc':'f97ffb9053dfb200d77a5cd9c52ba8334559e774ac36c4b5572495a74e1ce468'}

def build(resume=False):
    ready=b.read(W/'ready-v5.json')
    snapshots=[]
    paths=[Path(x['source']['path']) for x in ready['compiled']]
    paths += [c.R/x for x in EXPECTED]
    paths += [c.R/x for x in ['include/hyle/graph/detail/output_source.h','include/hyle/graph/detail/submission_source.h','tests/CMakeLists.txt','tests/graph_provider_ggml_cuda/CMakeLists.txt']]
    for source in dict.fromkeys(paths):
        pin=b.pin(source)
        key=source.relative_to(c.R).as_posix()
        if key in EXPECTED:assert pin['sha256']==EXPECTED[key]
        target=W/'source-final'/source.relative_to(c.R)
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
        snapshots.append(pin)
    b.save(W/'source-freeze-final.json',snapshots)
    def check():
        for pin in snapshots:b.exact(pin)
    recipes=[
      ('mixed_final',W/'recipes/mixed_ready.json',W/'compile/mixed_ready',c.R/'tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc'),
      ('topk_test',c.R/'.scratch/qwen-topone-prepared-20261022/compile1/graph-test/compile.command.json',c.R/'.scratch/qwen-topone-prepared-20261022/compile1/graph-test',c.R/'tests/graph_route_cuda/topk_test.cc'),
      ('topk_kernel',c.R/'.scratch/qwen-batch-profile-20261022/compile3/native/compile.command.json',c.R/'.scratch/qwen-batch-profile-20261022/compile3/native',c.R/'src/compute_provider_cuda/collectives.cu')]
    compiled=b.read(W/'compiled-final-additions.json') if resume else []
    for name,path,prior,source in recipes:
        if any(x['name']==name for x in compiled):
            record=next(x for x in compiled if x['name']==name)
            b.exact(record['source']);b.exact(record['object']);continue
        check();out=W/'compile'/name;out.mkdir(parents=True,exist_ok=resume)
        command=b.read(path)['command']
        command=[x.replace(str(prior),str(out)) for x in command]
        if name=='topk_test':
            command=[x.replace('graph-test.obj','unit.obj').replace('graph-test.pdb','unit.pdb').replace('graph-test-deps.json','dependencies.json') for x in command]
        if name=='topk_kernel':
            command=[x.replace('native.obj','unit.obj').replace('native.d','unit.d') for x in command]
        env=c.environment('cli')
        if name=='topk_kernel':
            host=b.read(W/'compile/model/command.json')['command'][0]
            # The inference runtime PATH has grown past cmd.exe's 8191-char
            # environment limit. NVCC's host commands need only this toolchain.
            env['PATH']=';'.join([str(Path(host).parent),str(Path(command[0]).parent),
                'C:\\Windows\\System32','C:\\Windows','C:\\Windows\\System32\\Wbem'])
            b.save(out/'compile-environment.json',{key:env[key] for key in ['PATH','INCLUDE','LIB']})
        process=h.execute(command,env,W/'logs'/(name+('-retry2' if resume else '')),timeout=180)
        check()
        if name!='topk_kernel':
            raw=b.read(out/'dependencies.json')['Data']
            b.save(out/'actual-dependencies.json',[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])])
        compiled.append(dict(name=name,source=b.pin(source),object=b.pin(out/'unit.obj'),process=process))
        b.save(W/'compiled-final-additions.json',compiled)
    objects={x['name']:x['object'] for x in compiled}
    old_kernel=c.R/'.scratch/qwen-batch-profile-20261022/compile3/native/native.obj'
    artifacts=[]
    for name,version in [('test','v5'),('cli','v2'),('probe','v4')]:
        check();inputs=[];replacements={b.key(old_kernel):objects['topk_kernel']['path']}
        if name=='test':replacements[b.key(W/'compile/mixed-v3/unit.obj')]=objects['mixed_final']['path']
        for row in b.read(W/(name+'-link-inputs-'+version+'.json')):
            if b.key(row['path']) in replacements:row=b.pin(replacements[b.key(row['path'])])
            b.exact(row);inputs.append(row)
        if name=='test':inputs.append(objects['topk_test'])
        assert len(inputs)==dict(test=239,cli=224,probe=223)[name]
        b.save(W/(name+'-link-inputs-final.json'),inputs)
        command=b.read(W/('link-'+name+'-'+version) / 'command.json')['command']
        command=[replacements.get(b.key(x),x) for x in command]
        if name=='test':command.append(objects['topk_test']['path'])
        process=h.execute(command,c.environment('cli'),W/('link-'+name+'-final'),timeout=120)
        image=Path(next(x[5:] for x in command if x.upper().startswith('/OUT:')))
        artifacts.append(dict(name=name,image=b.pin(image),process=process,inputs=b.pin(W/(name+'-link-inputs-final.json'))))
        b.save(W/'linked-final.json',artifacts)
    ready['compiled']=[x for x in ready['compiled'] if x['name']!='mixed_ready']+compiled
    ready['artifacts']=artifacts
    ready['sources']=b.pin(W/'source-freeze-final.json')
    b.save(W/'ready-final.json',ready)
    print('READY FINAL 2 CXX / 1 NVCC / 3 LINKS',flush=True)

def run():
    ready=b.read(W/'ready-final.json')
    for pin in b.read(ready['sources']['path']):b.exact(pin)
    for artifact in ready['artifacts']:b.exact(artifact['image'])
    filters=['GgmlCudaMixedReadySource.RealTokenStoreAndKvWarmHybridThenReusePending',
      'CudaDefaultGraph.SingleRowTopOneCapturePreservesNaNsSignedZeroAndTies',
      'CudaDefaultGraph.WideTopOnePreparedCaptureKeepsInvocationWorkspaceIsolated',
      'CudaDefaultGraph.OtherTopKProgramsKeepManagedReplayContract']
    out=W/'run-final-components'
    command=[str(W/'bin/submission-source-test.exe'),'--gtest_color=no','--gtest_filter='+':'.join(filters),'--gtest_output=xml:'+str(out/'results.xml')]
    process=h.execute(command,c.environment('test'),out,timeout=90)
    cases=ET.parse(out/'results.xml').getroot().findall('./testsuite/testcase')
    assert len(cases)==4 and {x.attrib['classname']+'.'+x.attrib['name'] for x in cases}==set(filters)
    assert all(x.attrib.get('status')=='run' and not x.findall('failure') and not x.findall('skipped') for x in cases)
    b.save(out/'summary.json',dict(status='PASS',process=process,tests=[x.attrib for x in cases]))
    print('PASS final four components; prior 43 not repeated',flush=True)

if sys.argv[1]=='build':build()
elif sys.argv[1]=='resume-kernel':build(True)
elif sys.argv[1]=='run':run()
else:raise ValueError(sys.argv[1])
