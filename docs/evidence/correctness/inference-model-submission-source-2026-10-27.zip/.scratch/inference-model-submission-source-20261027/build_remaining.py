from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-metadata-queue-20261027/check.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,h=p.b,p.h
env=p.old.environment('cli')
owned=['src/graph/resources.cc','include/hyle/graph/detail/submission_source.h',
 'include/hyle/graph/detail/output_source.h','engine/models/qwen35/main.cc',
 'tests/graph/output_source_cuda_test.cc','tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc',
 'tests/tools/qwen_submission_source_probe.cc','tests/CMakeLists.txt',
 'tests/graph_provider_ggml_cuda/CMakeLists.txt']
frozen=[b.pin(R/x) for x in owned]
for row in frozen:
 target=W/'source'/Path(row['path']).relative_to(R)
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(row['path']).read_bytes())
b.save(W/'source-freeze.json',frozen)
def check():
 for row in frozen:b.exact(row)
compiled=b.read(W/'model-compiled.json')
for name in ['resources','output_source','mixed_ready']:
 recipe=b.read(W/'recipes'/(name+'.json'));command=recipe['command']
 source=Path(next(x for x in command if x.lower().endswith('.cc')))
 check();process=h.execute(command,env,W/'logs'/name,timeout=180);check()
 out=W/'compile'/name
 deps=b.read(out/'dependencies.json')['Data']
 assert b.key(deps['Source'])==b.key(source)
 b.save(out/'actual-dependencies.json',[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])])
 compiled.append(dict(name=name,source=b.pin(source),object=b.pin(out/'unit.obj'),process=process))
 b.save(W/'compiled-partial.json',compiled)
artifacts=[]
for name,count in [('test',238),('cli',224),('probe',223)]:
 check();inputs=[]
 for row in b.read(W/(name+'-inputs-prepared.json')):
  if row.get('status')=='PIN_AFTER_SUCCESSFUL_COMPILE':row=b.pin(row['path'])
  b.exact(row);inputs.append(row)
 assert len(inputs)==count
 b.save(W/(name+'-link-inputs.json'),inputs)
 command=b.read(W/('link-'+name+'-prepared.json'))['command']
 image=Path(next(x[5:] for x in command if x.upper().startswith('/OUT:')))
 image.parent.mkdir(parents=True,exist_ok=True)
 process=h.execute(command,env,W/('link-'+name),timeout=120);check()
 artifacts.append(dict(name=name,image=b.pin(image),process=process,inputs=b.pin(W/(name+'-link-inputs.json'))))
 b.save(W/'linked-partial.json',artifacts)
runtime=b.read(R/'.scratch/inference-metadata-queue-20261027/runtime.json')
alias=W/'bin'/Path(runtime['native_cpu']['path']).name
b.exact(runtime['native_cpu'])
os.link(runtime['native_cpu']['path'],alias)
runtime['PATH']=str(W/'bin')+';'+runtime['PATH']
runtime['test_PATH']=str(W/'bin')+';'+runtime['test_PATH']
runtime['native_cpu_hardlink']=b.pin(alias)
b.save(W/'runtime.json',runtime)
b.save(W/'ready.json',dict(compiled=compiled,artifacts=artifacts,sources=b.pin(W/'source-freeze.json'),runtime=b.pin(W/'runtime.json')))
print('READY 5 CXX / 3 LINKS; no SDK/NVCC/download',flush=True)
