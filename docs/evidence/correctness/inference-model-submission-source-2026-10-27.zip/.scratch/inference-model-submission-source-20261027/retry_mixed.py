from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,h=c.b,c.h
attempt=sys.argv[1]
ready=b.read(W/'ready-append.json')
source=b.pin(c.R/'tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc')
b.save(W/('mixed-source-'+attempt+'.json'),source)
(W/('mixed-source-'+attempt+'.cc')).write_bytes(Path(source['path']).read_bytes())
out=W/'compile'/('mixed-'+attempt);out.mkdir(parents=True,exist_ok=False)
command=b.read(W/'recipes/mixed_ready.json')['command']
command=[x.replace(str(W/'compile/mixed_ready'),str(out)) for x in command]
process=h.execute(command,c.environment('test'),W/'logs'/('mixed-'+attempt),timeout=180)
b.exact(source)
raw=b.read(out/'dependencies.json')['Data']
b.save(out/'actual-dependencies.json',[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])])
compiled=dict(name='mixed_final',source=source,object=b.pin(out/'unit.obj'),process=process)
inputs=[]
append=next(x for x in ready['compiled'] if x['name']=='paged_append')
replace={b.key(W/'compile/mixed_final/unit.obj'):compiled['object']['path'],
 b.key(c.R/'.scratch/inference-metadata-queue-20261027/compile/04-paged_append/unit.obj'):append['object']['path']}
for row in b.read(W/'test-link-inputs-final.json'):
    if b.key(row['path']) in replace:row=b.pin(replace[b.key(row['path'])])
    b.exact(row);inputs.append(row)
b.save(W/('test-link-inputs-'+attempt+'.json'),inputs)
command=b.read(W/'link-test-final/command.json')['command']
command=[replace.get(b.key(x),x) for x in command]
process=h.execute(command,c.environment('test'),W/('link-test-'+attempt),timeout=120)
image=W/'bin/submission-source-test.exe'
ready['compiled']=[compiled if x['name']=='mixed_final' else x for x in ready['compiled']]
ready['artifacts']=[dict(name='test',image=b.pin(image),process=process,inputs=b.pin(W/('test-link-inputs-'+attempt+'.json'))) if x['name']=='test' else x for x in ready['artifacts']]
b.save(W/('ready-'+attempt+'.json'),ready)
target=W/('run-mixed-'+attempt)
command=[str(image),'--gtest_color=no','--gtest_filter=GgmlCudaMixedReadySource.RealTokenStoreAndKvWarmHybridThenReusePending','--gtest_output=xml:'+str(target/'results.xml')]
process=h.execute(command,c.environment('test'),target,timeout=60)
cases=ET.parse(target/'results.xml').getroot().findall('./testsuite/testcase')
assert len(cases)==1 and cases[0].attrib['status']=='run' and not cases[0].findall('failure') and not cases[0].findall('skipped')
b.save(target/'summary.json',dict(status='PASS',process=process,tests=[x.attrib for x in cases]))
print('PASS mixed final source',flush=True)
