from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b=c.b
ready=b.read(W/sys.argv[1])
for artifact in ready['artifacts']:
    b.exact(artifact['image']);b.exact(artifact['inputs'])
owned=['engine/models/qwen35/main.cc','src/graph/resources.cc','src/graph/executable.cc',
 'src/graph_batch/paged_append.cc','src/compute_provider_cuda/collectives.cu',
 'include/hyle/graph/detail/submission_source.h','include/hyle/graph/detail/output_source.h',
 'include/hyle/graph/detail/replay_access.h','tests/CMakeLists.txt',
 'tests/tools/qwen_submission_source_probe.cc','tests/graph/output_source_cuda_test.cc',
 'tests/graph_provider_ggml_cuda/CMakeLists.txt','tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc',
 'tests/graph_route_cuda/topk_test.cc']
sources=[]
for name in owned:
    source=c.R/name;pin=b.pin(source);sources.append(pin)
    target=W/'source-delivery'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
b.save(W/'source-delivery.json',sources)
builds=[]
for process in sorted(W.rglob('process.json')):
    command_file=process.parent/'command.json'
    if not command_file.exists():continue
    command=b.read(command_file)['command']
    tool=Path(command[0]).name.lower()
    if tool not in ('cl.exe','nvcc.exe','link.exe'):continue
    builds.append(dict(stage=process.parent.relative_to(W).as_posix(),tool=tool,**b.read(process)))
old=ET.parse(W/'run-test/results.xml').getroot().findall('./testsuite/testcase')
passed=[x.attrib['classname']+'.'+x.attrib['name'] for x in old if not x.findall('failure') and x.attrib.get('status')=='run']
assert len(passed)==43
test_runs=[]
for relative,count in [('run-topk-final/results.xml',3),(sys.argv[2]+'/results.xml',int(sys.argv[3]))]:
    cases=ET.parse(W/relative).getroot().findall('./testsuite/testcase')
    assert len(cases)==count and all(x.attrib.get('status')=='run' and not x.findall('failure') and not x.findall('skipped') for x in cases)
    names=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases]
    test_runs.append(dict(record=relative,passed=names));passed.extend(names)
unique=sorted(set(passed))
assert len(unique)==47
reports={name:b.read(W/('run-probe-'+name+'-append/report.json')) for name in ['tiny','real']}
assert all(x['status']=='PASS' for x in reports.values())
summary=dict(date='2026-10-27',status='PASS_FINITE_SCOPE',
 baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c.R,text=True).strip(),
 scope='One original complete ordinary CUDA producer exports token, every Store and every target KV bank, then finishes through exact original Source publication. Real ready mixed token/View/Store/KV can record Hybrid and reuse while pending. This is not a continuous model successor pipeline or a throughput result.',
 changes=['Source cancellation forwards to the sole original Completion without altering its verdict or proving retirement.',
  'Ready mixed bundles install actual published guards, clip inherited resource ranges and avoid duplicate resource read admission.',
  'All nonempty TopK1 shapes use the existing cold materialized tile/finish kernels and caller workspace; NaN/tie/original bits unchanged.',
  'Shared PagedAppend records its actual written-projection cache key, and writer-only binding clears that key.',
  'Exact full-span prepared View proof admits only unchanged physical tuples; other aliases still require real preparation.'],
 checks=dict(unique_gtest_cases=len(unique),cases=unique,original_43_record='run-test/results.xml',
  final_targeted_runs=test_runs,full_model_producers=reports,
  initial_cpu_cuda_regressions=b.read(W/'cli-summary.json'),affected_cuda_regressions=b.read(W/'cuda-regression-summary.json')),
 build_attempts=builds,
 failures_retained=['Initial 44-case process: 43 pass; mixed fixture empty old query was invalid.',
  'Mixed fixture next lacked prepare_resources, then incorrectly expected genuine ready submission to reject; originals retained.',
  'Mixed pending case exposed the unsupported View alias reuse; original native cleanup fatal and later original exception diagnosis are retained.',
  'Tiny and real complete producer initially rejected actual managed TopK1 gap. Read-only diagnostics identified the original step.',
  'After real TopK fix, complete producer rejected shared append with unregistered mutable authority; missing actual projection key was repaired.',
  'Two NVCC attempts stopped before host compilation because the inference runtime PATH exceeded cmd.exe length; compact compiler PATH then succeeded.',
  'Initial build helper directory reuse and one irrelevant-image hash check stopped before tool/model execution; scripts were corrected.'],
 limitations=['Actual execution_slot_count remains one. Three physical carriers with two candidate depths, expected-base/ledger publication and incoming bundle lifetime are not yet connected.',
  'Complete producer probe is ordinary greedy CUDA K1. It does not cover sampling, model successor submission, MTP pending accepted subsets, cancellation device faults or multimodal.',
  'Only finite affected GTests were rerun after each repair; 47 unique passes are across identified images, not one final full-suite process.',
  'New diagnostic target/source are registered in CMake; manual matching compile/link recipes were executed, no CMake reconfigure or SDK build claimed.',
  'No new prefill/decode TPS or memory comparison. Existing full performance table remains authoritative.'],
 downloaded_bytes=0,sources=sources,artifacts=ready['artifacts'])
b.save(W/'delivery-summary.json',summary)
target=c.R/'docs/evidence/correctness/inference-model-submission-source-2026-10-27'
target.parent.mkdir(parents=True,exist_ok=True)
extensions={'.json','.log','.xml','.py','.cc','.h','.d'}
with zipfile.ZipFile(target.with_suffix('.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for file in sorted(W.rglob('*')):
        if file.is_file() and file.suffix.lower() in extensions:
            archive.write(file,file.relative_to(c.R).as_posix())
summary['archive']=b.pin(target.with_suffix('.zip'))
b.save(target.with_suffix('.json'),summary)
print(json.dumps(dict(record=str(target.with_suffix('.json')),zip=b.pin(target.with_suffix('.zip')),build_attempts=len(builds),unique_gtest_cases=len(unique)),indent=2))
