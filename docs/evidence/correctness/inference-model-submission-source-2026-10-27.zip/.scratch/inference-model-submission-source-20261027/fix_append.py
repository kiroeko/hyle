from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,h=c.b,c.h
ready=b.read(W/'ready-final.json')
source=b.pin(c.R/'src/graph_batch/paged_append.cc')
assert source['sha256']=='b233209617f3131855a3bd346e0a35c573a5ea505bad223540d4903c2d8c06cc'
snapshot=W/'source-final/src/graph_batch/paged_append.cc'
snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(Path(source['path']).read_bytes())
out=W/'compile/append-fix';out.mkdir(parents=True,exist_ok=False)
prior=c.R/'.scratch/inference-metadata-queue-20261027/compile/04-paged_append'
command=b.read(c.R/'.scratch/inference-metadata-queue-20261027/recipes/04-paged_append.json')['command']
command=[x.replace(str(prior),str(out)) for x in command]
process=h.execute(command,c.environment('cli'),W/'logs/append-fix',timeout=180)
b.exact(source)
raw=b.read(out/'dependencies.json')['Data']
b.save(out/'actual-dependencies.json',[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])])
compiled=dict(name='paged_append',source=source,object=b.pin(out/'unit.obj'),process=process)
ready['compiled'].append(compiled)
for name in ['cli','probe']:
    inputs=[]
    for row in b.read(W/(name+'-link-inputs-final.json')):
        if b.key(row['path'])==b.key(prior/'unit.obj'):row=compiled['object']
        b.exact(row);inputs.append(row)
    b.save(W/(name+'-link-inputs-append.json'),inputs)
    command=b.read(W/('link-'+name+'-final/command.json'))['command']
    command=[compiled['object']['path'] if b.key(x)==b.key(prior/'unit.obj') else x for x in command]
    process=h.execute(command,c.environment('cli'),W/('link-'+name+'-append'),timeout=120)
    image=W/'bin'/('hyle.exe' if name=='cli' else 'qwen-submission-source-probe.exe')
    artifact=dict(name=name,image=b.pin(image),process=process,inputs=b.pin(W/(name+'-link-inputs-append.json')))
    ready['artifacts']=[artifact if x['name']==name else x for x in ready['artifacts']]
b.save(W/'ready-append.json',ready)
print('APPEND FIX BUILT 1 CXX / 2 MODEL LINKS; component image unchanged',flush=True)
