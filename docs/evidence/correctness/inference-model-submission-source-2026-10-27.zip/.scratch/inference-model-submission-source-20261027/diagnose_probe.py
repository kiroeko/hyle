from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,h=c.b,c.h
ready=b.read(W/'ready-v3.json')
source=b.pin(c.R/'tests/tools/qwen_submission_source_probe.cc')
assert source['sha256']=='06a3ac659e45149cb9abb0dce2fb135e4ee55ca9482dc3e7cce5e5b266a5295b'
out=W/'compile/probe-v2';out.mkdir(parents=True,exist_ok=False)
command=b.read(W/'compile/probe/command.json')['command']
command=[x.replace(str(W/'compile/probe'),str(out)) for x in command]
process=h.execute(command,c.environment('cli'),W/'logs/probe-v2',timeout=180)
b.exact(source)
raw=b.read(out/'dependencies.json')['Data']
b.save(out/'actual-dependencies.json',[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])])
compiled=dict(name='probe',source=source,object=b.pin(out/'unit.obj'),process=process)
inputs=[]
for row in b.read(W/'probe-link-inputs-v2.json'):
    if b.key(row['path'])==b.key(W/'compile/probe/unit.obj'):row=compiled['object']
    b.exact(row);inputs.append(row)
b.save(W/'probe-link-inputs-v4.json',inputs)
command=b.read(W/'link-probe-v2/command.json')['command']
command=[str(out/'unit.obj') if b.key(x)==b.key(W/'compile/probe/unit.obj') else x for x in command]
process=h.execute(command,c.environment('cli'),W/'link-probe-v4',timeout=120)
image=W/'bin/qwen-submission-source-probe.exe'
ready['compiled']=[compiled if x['name']=='probe' else x for x in ready['compiled']]
ready['artifacts']=[dict(name='probe',image=b.pin(image),process=process,inputs=b.pin(W/'probe-link-inputs-v4.json')) if x['name']=='probe' else x for x in ready['artifacts']]
b.save(W/'ready-v4.json',ready)
row=b.read(W/'probe-plan.json')['runs'][0]
b.exact(row['manifest'])
h.execute(row['command'],c.environment('cli'),W/'run-probe-tiny-v2',timeout=180)
