from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-metadata-queue-20261027/check.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,h=p.b,p.h
env=p.old.environment('cli')
pins=[]
for name in ['model','probe']:
    out=W/'compile'/name
    recipe=b.read(out/'command.json')
    command=recipe['command']
    source=Path(next(x for x in command if x.lower().endswith('.cc')))
    before=b.pin(source)
    assert not (out/'process.json').exists()
    process=h.execute(command,env,W/'logs'/name,timeout=180)
    b.exact(before)
    deps=b.read(out/'dependencies.json')['Data']
    assert b.key(deps['Source'])==b.key(source)
    actual=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
    b.save(out/'actual-dependencies.json',actual)
    pins.append(dict(name=name,source=before,object=b.pin(out/'unit.obj'),process=process))
    b.save(W/'model-compiled.json',pins)
print('MODEL AND PROBE COMPILED',flush=True)
