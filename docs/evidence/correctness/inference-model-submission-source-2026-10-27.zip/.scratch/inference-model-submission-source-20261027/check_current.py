from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('previous_check', R / '.scratch/inference-metadata-queue-20261027/check.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
b, h = p.b, p.h

def environment(kind):
    result = p.old.environment(kind)
    runtime = b.read(W / 'runtime.json')
    result['PATH'] = runtime['test_PATH' if kind == 'test' else 'PATH']
    result['HF_HUB_OFFLINE'] = result['TRANSFORMERS_OFFLINE'] = '1'
    return result

def build_fix():
    previous = b.read(W / 'ready.json')
    b.save(W / 'ready-before-narrow-fix.json', previous)
    for row in b.read(W / 'source-freeze.json'):
        if b.key(row['path']) != b.key(R / 'src/graph/resources.cc'):
            b.exact(row)
    source = b.pin(R / 'src/graph/resources.cc')
    assert source['sha256'] == '3118b36e13469306bba120b495a70bf8e664171dcc45612b3cfbaae033e39c7a'
    target = W / 'source-v2/src/graph/resources.cc'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(Path(source['path']).read_bytes())
    out = W / 'compile/resources-v2'
    out.mkdir(parents=True, exist_ok=False)
    command = b.read(W / 'recipes/resources.json')['command']
    command = [x.replace(str(W / 'compile/resources'), str(out)) for x in command]
    process = h.execute(command, environment('cli'), W / 'logs/resources-v2', timeout=180)
    b.exact(source)
    deps = b.read(out / 'dependencies.json')['Data']
    b.save(out / 'actual-dependencies.json', [b.pin(x) for x in dict.fromkeys([deps['Source'], *deps['Includes']])])
    compiled = dict(name='resources', source=source, object=b.pin(out / 'unit.obj'), process=process)
    b.save(W / 'compiled-narrow-fix.json', compiled)
    artifacts = []
    for name in ['test', 'cli', 'probe']:
        inputs = []
        for row in b.read(W / (name + '-link-inputs.json')):
            if b.key(row['path']) == b.key(W / 'compile/resources/unit.obj'):
                row = compiled['object']
            b.exact(row)
            inputs.append(row)
        b.save(W / (name + '-link-inputs-v2.json'), inputs)
        command = b.read(W / ('link-' + name + '-prepared.json'))['command']
        command = [str(out / 'unit.obj') if b.key(x) == b.key(W / 'compile/resources/unit.obj') else x for x in command]
        process = h.execute(command, environment('cli'), W / ('link-' + name + '-v2'), timeout=120)
        image = Path(next(x[5:] for x in command if x.upper().startswith('/OUT:')))
        artifacts.append(dict(name=name, image=b.pin(image), process=process, inputs=b.pin(W / (name + '-link-inputs-v2.json'))))
    b.save(W / 'ready-v2.json', dict(compiled=[compiled if x['name'] == 'resources' else x for x in previous['compiled']],
        artifacts=artifacts, previous=b.pin(W / 'ready-before-narrow-fix.json'), source_fix=source,
        scope='Only resources.cc recompiled for narrow review fixes; all three previous unrun images replaced.'))
    print('READY V2: 1 additional CXX and 3 relinks; no SDK/NVCC/download', flush=True)

def frozen(kind=None):
    ready = b.read(W / ('ready-append.json' if (W / 'ready-append.json').exists() else 'ready-final.json' if (W / 'ready-final.json').exists() else 'ready-v3.json' if (W / 'ready-v3.json').exists() else 'ready-v2.json'))
    for unit in ready['compiled']:
        if kind == 'cli' and unit['name'] in ('probe', 'output_source', 'mixed_ready', 'mixed_final', 'topk_test'):
            continue
        if kind == 'probe' and unit['name'] in ('output_source', 'mixed_ready', 'mixed_final', 'topk_test'):
            continue
        b.exact(unit['source'])
        b.exact(unit['object'])
    for artifact in ready['artifacts']:
        if kind is not None and artifact['name'] != kind:
            continue
        b.exact(artifact['image'])
        b.exact(artifact['inputs'])
    return ready

def test():
    frozen()
    plan = b.read(W / 'run-test-plan.json')
    process = h.execute(plan['command'], environment('test'), W / 'run-test', timeout=plan['timeout_seconds'])
    cases = ET.parse(W / 'run-test/results.xml').getroot().findall('./testsuite/testcase')
    assert len(cases) == len(plan['expected_tests']) == 44
    assert {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases} == set(plan['expected_tests'])
    assert all(x.attrib.get('status') == 'run' and not x.findall('failure') and not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(W / 'test-summary.json', dict(status='PASS', process=process, tests=[x.attrib for x in cases]))
    print('PASS 44 exact cases, no skip', flush=True)

def probe(which):
    frozen('probe')
    index = {'tiny': 0, 'real': 1}[which]
    row = b.read(W / 'probe-plan.json')['runs'][index]
    b.exact(row['manifest'])
    out = W / ('run-probe-' + which + ('-' + sys.argv[3] if len(sys.argv) > 3 else ''))
    process = h.execute(row['command'], environment('cli'), out, timeout=180)
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    for name, value in row['expect'].items():
        assert report[name] == value, (name, report[name], value)
    assert report['source_store_views'] > 0 and report['source_kv_views'] > 0
    assert report['complete_state_bytes_compared'] > 0 and len(report['ids']) == 4
    b.save(out / 'report.json', report)
    b.save(out / 'summary.json', dict(status='PASS', process=process, report=report, manifest=row['manifest']))
    print(json.dumps(report), flush=True)

def cli():
    frozen('cli')
    results = []
    for row in b.read(R / '.scratch/inference-metadata-queue-20261027/run-plan.json')['cli']:
        command = row['command'][:]
        command[0] = str(W / 'bin/hyle.exe')
        out = W / 'runs' / row['name']
        process = h.execute(command, environment('cli'), out, timeout=row['timeout_seconds'])
        report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
        baseline = b.read(R / '.scratch/inference-metadata-queue-20261027/runs' / row['name'] / 'report.json')
        for key in ['backend', 'mtp', 'session_count', 'admitted_requests', 'retired_requests', 'live_committed_versions', 'generated_tokens', 'requested_output_tokens']:
            assert report[key] == baseline[key], (row['name'], key)
        actual = [(x['session_id'], x['result']['generated_ids']) for x in report['sessions']]
        expected = [(x['session_id'], x['result']['generated_ids']) for x in baseline['sessions']]
        assert actual == expected
        assert report['generated_tokens'] == report['requested_output_tokens'] == 16
        assert report['active_sequences'] == 2 and len(report['sessions']) == 2
        assert any(batch['requests'] == 2 and len(batch['session_ids']) == 2 for batch in report['batches'])
        b.save(out / 'report.json', report)
        results.append(dict(name=row['name'], process=process, ids=actual, report=b.pin(out / 'report.json')))
        b.save(W / 'cli-summary-partial.json', results)
    b.save(W / 'cli-summary.json', dict(status='PASS', runs=results, scope='Tiny CPU/CUDA ordinary/MTP B2 regression, no performance claim.'))
    print('PASS four formal tiny B2 journeys', flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'build-fix': build_fix()
    elif sys.argv[1] == 'test': test()
    elif sys.argv[1] == 'probe': probe(sys.argv[2])
    elif sys.argv[1] == 'cli': cli()
    else: raise ValueError(sys.argv[1])
