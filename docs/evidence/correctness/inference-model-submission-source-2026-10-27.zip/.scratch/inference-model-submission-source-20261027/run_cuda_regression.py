from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,h=c.b,c.h
c.frozen('cli')
results=[]
for row in b.read(c.R/'.scratch/inference-metadata-queue-20261027/run-plan.json')['cli']:
    if not row['name'].startswith('cuda-'):continue
    command=row['command'][:];command[0]=str(W/'bin/hyle.exe')
    out=W/'runs-final'/row['name']
    process=h.execute(command,c.environment('cli'),out,timeout=row['timeout_seconds'])
    report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
    baseline=b.read(c.R/'.scratch/inference-metadata-queue-20261027/runs'/row['name']/'report.json')
    for key in ['backend','mtp','session_count','admitted_requests','retired_requests','live_committed_versions','generated_tokens','requested_output_tokens','active_sequences']:
        assert report[key]==baseline[key],(row['name'],key)
    actual=[(x['session_id'],x['result']['generated_ids']) for x in report['sessions']]
    expected=[(x['session_id'],x['result']['generated_ids']) for x in baseline['sessions']]
    assert actual==expected and report['generated_tokens']==16
    b.save(out/'report.json',report)
    results.append(dict(name=row['name'],process=process,ids=actual,report=b.pin(out/'report.json')))
    b.save(W/'cuda-regression-partial.json',results)
b.save(W/'cuda-regression-summary.json',dict(status='PASS',runs=results,scope='Only affected CUDA ordinary/MTP B2 repeated after TopK1 kernel and append fact fixes; CPU prior PASS reused, no throughput claim.'))
print('PASS affected CUDA ordinary/MTP B2; previous CPU runs not repeated',flush=True)
