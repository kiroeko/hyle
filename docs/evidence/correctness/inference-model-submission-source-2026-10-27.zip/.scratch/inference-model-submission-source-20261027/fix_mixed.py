from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,h=c.b,c.h
ready=b.read(W/'ready-v4.json')
source=b.pin(c.R/'tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc')
assert source['sha256']=='889950a4b4313344cc5247856fed2af6b2bbaa04d963a08dc2d36323c5a888d8'
out=W/'compile/mixed-v3';out.mkdir(parents=True,exist_ok=False)
command=b.read(W/'recipes/mixed_ready.json')['command']
command=[x.replace(str(W/'compile/mixed_ready'),str(out)) for x in command]
process=h.execute(command,c.environment('test'),W/'logs/mixed-v3',timeout=180)
b.exact(source)
raw=b.read(out/'dependencies.json')['Data']
b.save(out/'actual-dependencies.json',[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])])
compiled=dict(name='mixed_ready',source=source,object=b.pin(out/'unit.obj'),process=process)
inputs=[]
for row in b.read(W/'test-link-inputs-v3.json'):
    if b.key(row['path'])==b.key(W/'compile/mixed-v2/unit.obj'):row=compiled['object']
    b.exact(row);inputs.append(row)
b.save(W/'test-link-inputs-v5.json',inputs)
command=b.read(W/'link-test-v3/command.json')['command']
command=[str(out/'unit.obj') if b.key(x)==b.key(W/'compile/mixed-v2/unit.obj') else x for x in command]
process=h.execute(command,c.environment('test'),W/'link-test-v5',timeout=120)
image=W/'bin/submission-source-test.exe'
ready['compiled']=[compiled if x['name']=='mixed_ready' else x for x in ready['compiled']]
ready['artifacts']=[dict(name='test',image=b.pin(image),process=process,inputs=b.pin(W/'test-link-inputs-v5.json')) if x['name']=='test' else x for x in ready['artifacts']]
ready['scope']='Only mixed fixture rebuilt with prepare_resources before owned bindings. Previous 43 PASS retained; rerun only failed new case.'
b.save(W/'ready-v5.json',ready)
target=W/'run-mixed-v3'
command=[str(image),'--gtest_color=no','--gtest_filter=GgmlCudaMixedReadySource.RealTokenStoreAndKvWarmHybridThenReusePending','--gtest_output=xml:'+str(target/'results.xml')]
process=h.execute(command,c.environment('test'),target,timeout=60)
cases=ET.parse(target/'results.xml').getroot().findall('./testsuite/testcase')
assert len(cases)==1 and cases[0].attrib['status']=='run' and not cases[0].findall('failure') and not cases[0].findall('skipped')
b.save(target/'summary.json',dict(status='PASS',process=process,tests=[x.attrib for x in cases]))
print('PASS corrected single mixed case; prior 43 not repeated',flush=True)
