from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('current',W/'check_current.py')
c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
b,h=c.b,c.h
def build():
    ready=b.read(W/'ready-diag.json')
    pins=[b.pin(c.R/x) for x in ['src/graph/executable.cc','include/hyle/graph/detail/replay_access.h','tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc']]
    assert [x['sha256'] for x in pins]==['72de32c2dbe566e92af8ba0b6e2e99689751e98623c66841e88e352c981bcb43','aacde3f73b2f38738251c0d4608db3be2dcbba696020e2a5ec65fb977f6e9f5c','c27c1f04fe9819530c97c1dba75f029aad34f626527aa8f4808dbcda1382ff01']
    for pin in pins:
        source=Path(pin['path']);target=W/'source-delivery'/source.relative_to(c.R)
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
    b.save(W/'alias-source-freeze.json',pins)
    recipes=[('executable',c.R/'.scratch/inference-hybrid-append-20261027/compile/executable/command.json',c.R/'.scratch/inference-hybrid-append-20261027/compile/executable',pins[0]),
      ('mixed_alias',W/'recipes/mixed_ready.json',W/'compile/mixed_ready',pins[2])]
    compiled=[]
    for name,recipe,prior,source in recipes:
        out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
        command=[x.replace(str(prior),str(out)) for x in b.read(recipe)['command']]
        process=h.execute(command,c.environment('cli'),W/'logs'/name,timeout=180)
        for pin in pins:b.exact(pin)
        raw=b.read(out/'dependencies.json')['Data']
        b.save(out/'actual-dependencies.json',[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])])
        compiled.append(dict(name=name,source=source,object=b.pin(out/'unit.obj'),process=process))
        b.save(W/'alias-compiled.json',compiled)
    replacements={b.key(c.R/'.scratch/inference-hybrid-append-20261027/compile/executable/unit.obj'):compiled[0]['object']['path'],b.key(W/'compile/mixed-diag/unit.obj'):compiled[1]['object']['path']}
    artifacts=[]
    for name,prior in [('test','diag'),('cli','append'),('probe','append')]:
        inputs=[]
        for row in b.read(W/(name+'-link-inputs-'+prior+'.json')):
            if b.key(row['path']) in replacements:row=b.pin(replacements[b.key(row['path'])])
            b.exact(row);inputs.append(row)
        assert len(inputs)==dict(test=239,cli=224,probe=223)[name]
        b.save(W/(name+'-link-inputs-delivery.json'),inputs)
        command=b.read(W/('link-'+name+'-'+prior+'/command.json'))['command']
        command=[replacements.get(b.key(x),x) for x in command]
        process=h.execute(command,c.environment('cli'),W/('link-'+name+'-delivery'),timeout=120)
        image=Path(next(x[5:] for x in command if x.upper().startswith('/OUT:')))
        artifacts.append(dict(name=name,image=b.pin(image),process=process,inputs=b.pin(W/(name+'-link-inputs-delivery.json'))))
    ready['compiled']=[x for x in ready['compiled'] if x['name']!='mixed_final']+compiled
    ready['artifacts']=artifacts
    b.save(W/'ready-delivery.json',ready)
    print('DELIVERY BUILT 2 affected CXX / 3 LINKS',flush=True)

def run():
    ready=b.read(W/'ready-delivery.json')
    for pin in b.read(W/'alias-source-freeze.json'):b.exact(pin)
    for artifact in ready['artifacts']:b.exact(artifact['image'])
    filters=['GgmlCudaMixedReadySource.RealTokenStoreAndKvWarmHybridThenReusePending',
      'GraphOutputSourceCuda.PendingI32ReusesRealNativeRegionCaptureWithoutRecording',
      'GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges',
      'GraphOutputSourceCuda.PendingI32UsesOriginalQueueAndLeasesForCheckedGather']
    target=W/'run-alias-final'
    command=[str(W/'bin/submission-source-test.exe'),'--gtest_color=no','--gtest_filter='+':'.join(filters),'--gtest_output=xml:'+str(target/'results.xml')]
    process=h.execute(command,c.environment('test'),target,timeout=90)
    cases=ET.parse(target/'results.xml').getroot().findall('./testsuite/testcase')
    assert len(cases)==4 and {x.attrib['classname']+'.'+x.attrib['name'] for x in cases}==set(filters)
    assert all(x.attrib.get('status')=='run' and not x.findall('failure') and not x.findall('skipped') for x in cases)
    b.save(target/'summary.json',dict(status='PASS',process=process,tests=[x.attrib for x in cases]))
    print('PASS new mixed View/token/Store/KV ready-to-pending and 3 affected reuse regressions',flush=True)
if sys.argv[1]=='build':build()
elif sys.argv[1]=='run':run()
else:raise ValueError(sys.argv[1])
