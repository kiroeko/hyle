"""Record the completed narrow regression and prepare the permanent test patch."""
import difflib,hashlib,json,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[2]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')

# Exact dependencies emitted by the one NVCC command. SDK paths are referenced,
# not copied. Preserve identities of the finite existing Hyle/native subset.
dep=(S/'native1/mmvq.d').read_text().split(' : ',1)[1]
paths=[]
for line in dep.splitlines():
    token=line.strip()
    if token.endswith('\\'):token=token[:-1].rstrip()
    token=token.replace('\\ ',' ')
    if not token:continue
    p=Path(token).resolve();assert p.is_file(),token
    if p not in paths:paths.append(p)
local=[identity(p) for p in paths if p.is_relative_to(R)]
external=[str(p) for p in paths if not p.is_relative_to(R)]
save(S/'native1/dependencies.json',dict(depfile=identity(S/'native1/mmvq.d'),local=local,
    toolchain_paths_only=external,scope='Actual emitted dependencies; no SDK headers or libraries copied.'))
native=read(S/'native1/identity.json')
for k in ('source','object','retired_object'):
    assert identity(native[k]['path'])==native[k]
save(S/'native1/link-input.json',dict(object=native['object'],record=identity(S/'native1/identity.json'),
    dependencies=identity(S/'native1/dependencies.json'),replace_exactly=native['retired_object'],
    ABI_change=False,required_product_host_refresh_for_parent_parity_change=['src/compute_provider_ggml_cuda/tensor_program.cc'],
    provider_refresh_required=False))

# A new small test in the existing CUDA provider suite; canonical stays untouched.
cmake='tests/compute_provider_ggml_cuda/CMakeLists.txt'
test='tests/compute_provider_ggml_cuda/packed_matmul_tail_test.cc'
old=(R/cmake).read_bytes();text=old.decode()
assert text.count('packed_matmul_bounds_test.cc')==1
new=text.replace('packed_matmul_bounds_test.cc','packed_matmul_bounds_test.cc packed_matmul_tail_test.cc').encode()
out=S/'next-source'/cmake;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(new)
patch=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+cmake,tofile='b/'+cmake))
body=(S/'next-source'/test).read_text()
assert not (R/test).exists()
patch+=''.join(difflib.unified_diff([],body.splitlines(True),fromfile='/dev/null',tofile='b/'+test))
(S/'test.patch').write_text(patch,encoding='utf-8',newline='\n')
save(S/'test-ready.json',dict(status='proposal_only_not_applied',patch=identity(S/'test.patch'),
    cmake_before=identity(R/cmake),cmake_after=identity(out),test=identity(S/'next-source'/test),
    scope='Three generated legal Q8 public MatMul numeric regressions, not an allocation-boundary instrumentation test.'))

root=ET.parse(S/'checks1/results.xml').getroot()
assert int(root.get('tests'))==3 and not list(root.iter('skipped'))
assert all(int(root.get(k,'0'))==0 for k in ('failures','errors','disabled'))
assert {c.get('name') for c in root.iter('testcase')}=={'Q8K512N1M1','Q8K512N3M1','Q8K512N3M2'}
for p in ['native1/run/process.json','test1/run/process.json','tests-link1/link/process.json','checks1/run/process.json']:
    d=read(S/p);assert d['exit']==0 and not d['timed_out']
link=read(S/'tests-link1/link-plan.json')
assert native['retired_object']['path'].lower() in link['replacements']
assert native['object']['path'] in link['command'] and native['retired_object']['path'] not in link['command']
maps=S/'tests-link1/mmvq-tail-checks.map'
lines=[x for x in maps.read_text(errors='strict').splitlines() if 'ggml_cuda_mul_mat_vec_q' in x or 'ggml_cuda_should_use_mmvq' in x]
assert lines and all('mmvq.obj' in x for x in lines)
(S/'link-map-excerpt.txt').write_text('\n'.join(lines)+'\n')
proof=dict(schema='hyle.correctness.packed-mmvq-tail.v1',date='2026-10-24',status='passed',
    summary='Source-derived tail read fix plus three generated small Q8 public MatMul numeric regressions on RTX4070.',
    source_defect='Small-K M1 and ordinary M2 row tiles read nonexistent packed rows before their existing output-store guard. K%512 does not reserve N-tail rows. Indexed multi-token pair kernel has the same missing read guard.',
    fix='Three uniform row guards cover ordinary and fused-gate dots, Spark prefetch and fused-gate prefetch, and indexed main/gate pair dots. Selectors, launch geometry, AQ/W decoding, valid-row arithmetic, barriers and stores are unchanged.',
    actual_tests=dict(tests=3,failures=0,skips=0,shapes=['Q8_0 K512 N1 M1','Q8_0 K512 N3 M1','Q8_0 K512 N3 M2'],
        reference='Original F16 scale1 and int8 code(column+1), F32 A+/-127 yields AQ8_1 scale1/code+/-127 and exact output +/-65024*(column+1).',
        original_weight_bytes=[544,1632],XML=identity(S/'checks1/results.xml'),process=identity(S/'checks1/run/process.json')),
    hardware={'device':'NVIDIA GeForce RTX4070','compute_capability':'8.9','source':'checks1/run/stderr.log'},
    build=dict(native_TUs=1,test_TUs=1,product_host_TUs=0,SDK_builds=0,SDK_copies=0,HTTP_requests=0,
        native=native,actual_dependencies=identity(S/'native1/dependencies.json'),
        current_link_base=link['base'],link_plan=identity(S/'tests-link1/link-plan.json'),
        image=read(S/'tests-link1/ready.json')['image']),
    future_link_input=read(S/'native1/link-input.json'),permanent_test_proposal=read(S/'test-ready.json'),
    link_map=dict(full=identity(maps),excerpt=identity(S/'link-map-excerpt.txt')),
    limits=['Numeric tests are not a memcheck/guard-page proof; no instrumented before-failure/after-pass was run.',
            'No original model/MTP quality, throughput or peak-memory conclusion.',
            'Host parity-removal proposal is separate and was not applied by this task. After root applies it only tensor_program.cc needs its host refresh; this same new native object remains usable.'],
    retained_preflight_failures=[dict(kind='script_library_classification',reason='Initial link preparation treated bare Windows SDK library names as absolute files. It stopped before launching the linker. Final command preserves normal LIB lookup and succeeds; no C++ or native arithmetic change.')])
files=[]
for rel in ['prepare.py','source.patch','native.diff','ready.json','sources-applied.json',
            'build_native.py','build_test.py','finish.py','test.patch','test-ready.json',
            'link-map-excerpt.txt','generated/src/ggml-cuda/mmvq.cu',
            'next-source/'+test,'before/third_party/ggml_cuda_runtime/patches.json',
            'next-source/third_party/ggml_cuda_runtime/patches.json',
            'before/cmake/HyleDependencyLock.json','next-source/cmake/HyleDependencyLock.json']:
    p=S/rel
    if p.is_file():files.append((p,rel))
for base in ['native1','test1','tests-link1','checks1']:
    for p in (S/base).rglob('*'):
        if p.is_file() and p.suffix in ('.json','.log','.xml','.d'):
            files.append((p,p.relative_to(S).as_posix()))
files.append((Path(native['retired_object']['path']).with_name('mmvq-identity.json'),'original-compiled-mmvq-record.json'))
files.append((Path(native['retired_object']['path']).with_name('mmvq-compile.result.json'),'original-compiled-mmvq-process.json'))
files.append((Path(read(S/'native1/plan.json')['before_source']['path']),'original-compiled-mmvq.cu'))
files.append((R/'third_party/ggml_cuda_runtime/LICENSE','ggml-LICENSE'))
assert len({arc for _,arc in files})==len(files)
dest=R/'docs/evidence/correctness';name='mtp-packed-mmvq-tail-read-2026-10-24'
archive=dest/(name+'.zip');output=dest/(name+'.json');assert not archive.exists() and not output.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,arc in files:
        assert p.suffix not in ('.obj','.exe','.dll','.lib','.pdb')
        assert not p.read_bytes().startswith((b'MZ',b'!<arch>'))
        z.write(p,arc)
assert archive.stat().st_size<3*1024*1024
proof['archive']=identity(archive);proof['archive']['path']=archive.relative_to(R).as_posix()
proof['archive_files']=len(files);save(output,proof)
save(S/'actual-regression.json',dict(proof=identity(output),archive=identity(archive),
    native_link_input=read(S/'native1/link-input.json'),test_patch=identity(S/'test.patch')))
print(json.dumps(read(S/'actual-regression.json'),indent=2))
