"""Compile the one reviewed native TU with its exact current-image recipe."""
import hashlib,importlib.util,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[2]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    p=Path(path);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
old_path=R/'.scratch/architecture-refactor-2026-10-18/cuda-fusion-precision/checks/20261019T111328/mmvq-identity.json'
old=read(old_path);source=S/'generated/src/ggml-cuda/mmvq.cu'
assert identity(old['source']['path'])==old['source']
assert identity(old['object']['path'])==old['object']
assert old['source']['sha256']=='0ddc6e55fd041d001f103a1486e5de64cdb4d9fcf7b6b31c76bbd456f6b40e91'
assert identity(source)['sha256']=='1c2a40e1c9867acef58da2b00d98a747487e80b6659ceacac3b93a3ddee2fe3e'
out=S/'native1';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
old_out=str(Path(old['object']['path']).parent)
command=[x.replace(old_out,str(out)) for x in old['command']]
command[command.index('-c')+1]=str(source)
command[command.index('-o')+1]=str(out/'mmvq.obj')
command[command.index('-MT')+1]=str(out/'mmvq.obj')
command[command.index('-MF')+1]=str(out/'mmvq.d')
(out/'plan.json').write_text(json.dumps(dict(command=command,recipe=identity(old_path),
    before_source=old['source'],old_object=old['object'],source=identity(source),
    overlay='Only the generated mmvq.cu; private headers and tools remain the exact old native family. No SDK copy or other native TU.'),indent=2)+'\n')
h=module('tail_native_host_env',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=module('tail_native_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
host=read(R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/recipe-preparation/native-commands.json')['jobs'][0]['command']
env,_=h.b.environment(host,[],out)
env['PATH']=str(Path(command[0]).parent)+os.pathsep+env['PATH']
env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
result=q.execute(command,env,out/'run',timeout=1800)
if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
assert identity(source)['sha256']=='1c2a40e1c9867acef58da2b00d98a747487e80b6659ceacac3b93a3ddee2fe3e'
(out/'identity.json').write_text(json.dumps(dict(command=command,source=identity(source),object=identity(out/'mmvq.obj'),
    dependencies_file=identity(out/'mmvq.d'),recipe=identity(old_path),retired_object=old['object'],
    process=identity(out/'run/process.json')),indent=2)+'\n')
print('COMPILED one native MMVQ TU',flush=True)
