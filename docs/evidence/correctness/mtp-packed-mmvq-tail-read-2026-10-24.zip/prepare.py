"""Prepare only owning manifest/lock edits and the derived single native TU."""
import difflib
import hashlib
import json
from pathlib import Path

S=Path(__file__).resolve().parent
R=S.parents[2]
MP='third_party/ggml_cuda_runtime/patches.json'
LP='cmake/HyleDependencyLock.json'
RAW=R/'.scratch/validation/cpu-final-f1/mixed-iq1/source/src/ggml-cuda/mmvq.cu'

def sha(data):return hashlib.sha256(data).hexdigest()
def json_bytes(value,original):
    data=(json.dumps(value,indent=2)+'\n').encode()
    return data.replace(b'\n',b'\r\n') if b'\r\n' in original else data
def identity(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=sha(raw))
def load(path):return json.loads(Path(path).read_text())
def compose(source, changes):
    for e in changes:
        assert source.count(e['before'])==1,e['before']
        source=source.replace(e['before'],e['after'],1)
    return source

before_manifest=(R/MP).read_bytes();manifest=json.loads(before_manifest)
entry=next(x for x in manifest['files'] if x['path']=='src/ggml-cuda/mmvq.cu')
raw=RAW.read_bytes().replace(b'\r\n',b'\n')
assert sha(raw)==entry['before_sha256']=='d4c70f68ab79d463fd6fd52cac66a62e915858397ba4b2b7f658a7fbf13121f3'
primary_before=compose(raw.decode(),entry['edits'])
assert sha(primary_before.encode())==entry['after_sha256']
iq=next(x for x in load(R/'third_party/ggml_cuda_runtime/iq1-patches.json')['files']
        if x['path']=='src/ggml-cuda/mmvq.cu')
composed_before=compose(primary_before,iq['edits'])
review=R/'.scratch/mtp-packed-head-20261024/review/native-current/mmvq.cu'
assert identity(review)['sha256']=='f70386a878ee66f22dbda67358941ad89b41dec354786ec09627a41b4c5f08a8'
assert composed_before==review.read_bytes().replace(b'\r\n',b'\n').decode()

edits=[]
for old,guard in [
    ('                for (int i = 0; i < rows_per_cuda_block; ++i) {\n'
     '                    const size_t off = (size_t)(kbx_offset + i*stride_row_x + kbx_pf) * ggml_cuda_type_traits<type>::bs;',
     '                for (int i = 0; i < rows_per_cuda_block; ++i) {\n'
     '                    if constexpr (rows_per_cuda_block > 1) {\n'
     '                        if (uint32_t(row0 + i) >= nrows_x) continue;\n'
     '                    }\n'
     '                    const size_t off = (size_t)(kbx_offset + i*stride_row_x + kbx_pf) * ggml_cuda_type_traits<type>::bs;'),
    ('            for (int i = 0; i < rows_per_cuda_block; ++i) {\n'
     '                tmp[j][i] += vec_dot_q_cuda(',
     '            for (int i = 0; i < rows_per_cuda_block; ++i) {\n'
     '                if constexpr (rows_per_cuda_block > 1) {\n'
     '                    if (uint32_t(row0 + i) >= nrows_x) continue;\n'
     '                }\n'
     '                tmp[j][i] += vec_dot_q_cuda('),
    ('        for (int i = 0; i < c_rows_per_block; ++i) {\n'
     '            tmp[i] += vec_dot_q_cuda(vx, &y[kby], kbx_offset + i*stride_row_x + kbx, kqs);',
     '        for (int i = 0; i < c_rows_per_block; ++i) {\n'
     '            if constexpr (c_rows_per_block > 1) {\n'
     '                if (uint32_t(row0 + i) >= nrows_x) continue;\n'
     '            }\n'
     '            tmp[i] += vec_dot_q_cuda(vx, &y[kby], kbx_offset + i*stride_row_x + kbx, kqs);')]:
    edits.append(dict(before=old,after=guard))
primary_after=compose(primary_before,edits)
composed_after=compose(primary_after,iq['edits'])
assert compose(composed_before,edits)==composed_after
# Removing just the added guards exactly recovers all old launch/math code.
undo=composed_after
for e in edits:
    assert undo.count(e['after'])==1
    undo=undo.replace(e['after'],e['before'],1)
assert undo==composed_before
entry['edits'].extend(edits)
entry['after_sha256']=sha(primary_after.encode())
after_manifest=json_bytes(manifest,before_manifest)
lock_before=(R/LP).read_bytes();lock=json.loads(lock_before)
dep=next(x for x in lock['dependencies'] if x['name']=='ggml_cuda_runtime_patches')
root=R/dep['vendored']['path']
def tree(replacement=None):
    rows=[]
    for p in sorted(root.rglob('*'),key=lambda p:p.relative_to(root).as_posix()):
        if not p.is_file():continue
        data=after_manifest if replacement and p==R/MP else p.read_bytes()
        data=data.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
        rows.append(p.relative_to(root).as_posix()+'|'+sha(data)+'\n')
    return sha(''.join(rows).encode())
assert tree()==dep['vendored']['tree_sha256']
dep['version']='hyle-ggml-cuda-resource-iq1-inference-v35'
dep['vendored']['tree_sha256']=tree(True)
lock_after=json_bytes(lock,lock_before)
changed={MP:(before_manifest,after_manifest),LP:(lock_before,lock_after)}
patch=[];facts=[]
for rel,(old,new) in changed.items():
    for folder,raw_bytes in [('before',old),('next-source',new)]:
        p=S/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw_bytes)
    facts.append(dict(path=rel,before_bytes=len(old),before_sha256=sha(old),after_bytes=len(new),after_sha256=sha(new)))
    patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),
                                     fromfile='a/'+rel,tofile='b/'+rel))
(S/'source.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
out=S/'generated/src/ggml-cuda/mmvq.cu';out.parent.mkdir(parents=True,exist_ok=True)
out.write_bytes(composed_after.encode())
(S/'native.diff').write_text(''.join(difflib.unified_diff(composed_before.splitlines(keepends=True),
    composed_after.splitlines(keepends=True),fromfile='a/src/ggml-cuda/mmvq.cu',tofile='b/src/ggml-cuda/mmvq.cu')),encoding='utf-8')
ready=dict(status='proposal_only_not_applied_or_compiled',changed=facts,
    patch=identity(S/'source.patch'),native_diff=identity(S/'native.diff'),
    raw=identity(RAW),review_source=identity(review),derived_before_normalized_sha256=sha(composed_before.encode()),derived_after=identity(out),
    native_tus_to_refresh=['src/ggml-cuda/mmvq.cu'],public_ABI_change=False,
    valid_row_math='Selector/launch/quantization/dot/reductions/stores unchanged. Three inserted compile-time-elidable row guards skip only nonexistent row prefetch, main/gate dot or indexed main/gate dot. Guard condition is uniform across the CTA/warp; shared reductions/barriers still execute.',
    data_case=dict(type='Q8_0',K=512,N=1,M=1,table='GENERIC/Ada',warps=4,rpb=4,
                   encoded_row_bytes=544,declared_source_bytes=544,unguarded_read_extent=2176,
                   alloc_padding_bytes=0),
    ordinary_M2='rpb2 for M2..8; odd N has the identical main/gate dot overread before the existing store guard. Generic old MatMul can bypass the relaxed-bank qualification. Same first-kernel guard fixes it.',
    indexed_M2='Dedicated MMID multi-token kernel has c_rows_per_block2 and unguarded tail vecdot/gate. Third guard fixes its odd N tail without changing IDs or slot layout.',
    suggested_focused_validation=[
        'Generated legal Q8_0 K512 N1 and N3 at M1; N3 at M2. Original F16 scales1 and int8 codes(row+1), F32 A +/-127 give exact outputs +/-65024*(row+1). Test actual public MatMul path without N%4 rejection.',
        'If indexed/fusion coverage is available, one E2/N3/M2 MMID selecting final expert and one M1/N3 fused gate use the same bounded bytes; no model weights needed.',
        'For direct evidence of invalid reads, use exact requested CUDA allocation under compute-sanitizer memcheck or a page-end unbacked guard. Plain numeric before/after alone is insufficient because discarded out-of-range row results can leave valid outputs unchanged. Do not describe an allocation-slack pass as memory-safety proof.'
    ],not_run=['C++/NVCC compilation','native execution','HTTP'],canonical_edited=False)
(S/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
print(json.dumps(dict(patch=ready['patch'],native=ready['derived_after'],changed_files=len(facts)),indent=2))
