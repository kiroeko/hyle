"""One focused test TU and one exact native-object replacement of current-link1."""
import argparse,hashlib,importlib.util,json,os,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[2]
BASE=R/'.scratch/mtp-packed-head-20261024/current-integration/current-link1'
SOURCE=S/'next-source/tests/compute_provider_ggml_cuda/packed_matmul_tail_test.cc'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(path):
    p=Path(path);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def verify(x):assert identity(x['path'])==x,x['path']
def save(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
h=module('tail_host_build_env',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=module('tail_host_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
p=argparse.ArgumentParser();p.add_argument('action',choices=['compile','link','run']);a=p.parse_args()
if a.action=='compile':
    recipe=R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/compile1/cuda-test/identity.json'
    old=read(recipe);out=S/'test1';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    command=[]
    for arg in old['command']:
        if arg.startswith('/DHYLE_GDN_SCALE_'):continue
        if arg==old['source']['path']:arg=str(SOURCE)
        elif arg.startswith('/Fo'):arg='/Fo'+str(out/'tail-test.obj')
        elif arg.startswith('/Fd'):arg='/Fd'+str(out/'tail-test.pdb')
        command.append(arg)
    command[command.index('/sourceDependencies')+1]=str(out/'source-deps.json')
    save(out/'plan.json',dict(command=command,source=identity(SOURCE),recipe=identity(recipe)))
    env,_=h.b.environment(command,[],out);env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
    result=q.execute(command,env,out/'run',timeout=1800)
    if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
    deps=read(out/'source-deps.json')['Data']
    dependencies=[identity(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
    save(out/'identity.json',dict(command=command,source=identity(SOURCE),object=identity(out/'tail-test.obj'),
        dependencies=dependencies,recipe=identity(recipe)))
    print('COMPILED one public tail regression TU',flush=True)
elif a.action=='link':
    old=read(BASE/'link-plan.json');native=read(S/'native1/identity.json');test=read(S/'test1/identity.json')
    for info in [native['source'],native['object'],test['source'],test['object'],*test['dependencies']]:verify(info)
    consumer=read(old['consumer_record']['path'])
    replacements={native['retired_object']['path'].lower():native['object']['path'],
                  consumer['object']['path'].lower():test['object']['path']}
    counts=dict.fromkeys(replacements,0);command=[]
    for arg in old['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
        if arg.lower() in replacements:
            counts[arg.lower()]+=1;arg=replacements[arg.lower()]
        command.append(arg)
    assert list(counts.values())==[1,1]
    retained=[];system_libraries=[]
    for arg in command:
        if arg.lower().endswith(('.obj','.lib')):
            if Path(arg).is_absolute():
                assert Path(arg).is_file(),arg
                retained.append(identity(arg))
            else:system_libraries.append(arg)
    out=S/'tests-link1';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    image=out/'mmvq-tail-checks.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    if not any(x.upper().startswith('/SUBSYSTEM:') for x in command):command+=['/SUBSYSTEM:CONSOLE']
    save(out/'link-plan.json',dict(command=command,base=identity(BASE/'link-plan.json'),
        replacements=replacements,retained_inputs=retained,system_libraries=system_libraries,native_record=identity(S/'native1/identity.json'),
        test_record=identity(S/'test1/identity.json'),SDK_copies=0,SDK_builds=0,
        native_TUs=1,product_host_TUs=0,test_TUs=1))
    env,_=h.b.environment(command,[],out);env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
    result=q.execute(command,env,out/'link',timeout=1800)
    if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
    runtime=read(BASE/'runtime-environment.json')
    for info in runtime['staged_dlls']:
        verify(info);dll=Path(info['path']);os.link(dll,out/dll.name)
    runtime['PATH']=str(out)+os.pathsep+runtime['PATH']
    runtime['staged_dlls']=[identity(x) for x in out.glob('*.dll')]
    runtime['previous']=identity(BASE/'runtime-environment.json')
    save(out/'runtime-environment.json',runtime)
    save(out/'ready.json',dict(image=identity(image),link_plan=identity(out/'link-plan.json'),runtime=identity(out/'runtime-environment.json')))
    print('LINKED current native MMVQ single-object replacement; old Flash consumer absent',flush=True)
else:
    image=S/'tests-link1';ready=read(image/'ready.json')
    for x in ready.values():verify(x)
    runtime=read(image/'runtime-environment.json')
    for x in runtime['staged_dlls']:verify(x)
    out=S/'checks1';out.mkdir(exist_ok=False)
    env=os.environ.copy();env['PATH']=runtime['PATH']
    command=[ready['image']['path'],'--gtest_filter=GgmlCudaPackedTail.*','--gtest_output=xml:'+str(out/'results.xml')]
    save(out/'plan.json',dict(command=command,image=ready['image'],runtime=ready['runtime'],
        scope='Three generated small-Q8 public MatMul numeric regressions only, not a memory-access instrumentation proof.'))
    result=q.execute(command,env,out/'run',timeout=180)
    root=ET.parse(out/'results.xml').getroot() if (out/'results.xml').exists() else None
    cases=list(root.iter('testcase')) if root is not None else []
    passed=result['exit']==0 and not result['timed_out'] and len(cases)==3 and not any(
        c.find('failure') is not None or c.find('skipped') is not None for c in cases)
    save(out/'summary.json',dict(passed=passed,process=result,cases=len(cases),
        xml=identity(out/'results.xml') if root is not None else None,
        image=ready['image'],numeric_reference='F16scale1, Q8code(column+1), AQ8_1 scale1/codes+/-127: exact +/-65024*(column+1)',
        shapes=['K512 N1 M1','K512 N3 M1','K512 N3 M2'],original_model=False,
        memcheck=False,SDK_copies=0,SDK_builds=0,native_TUs=1,test_TUs=1))
    if not passed:raise SystemExit(result['exit'] or 1)
    print('PASSED three generated Q8 small-tail public MatMul cases',flush=True)
