"""One current consumer for the retained failure-only product correction."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_original_terminal_build', W.parent / 'refinement/build.py')
wrapper = importlib.util.module_from_spec(spec); spec.loader.exec_module(wrapper)
b = wrapper.b
b.W = W; b.__file__ = __file__; b.t.W = W
if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': b.prepare()
    elif action == 'freeze': b.freeze()
    elif action == 'compile': b.compile_unit('tiny')
    elif action == 'parse-compile': b.parse_compile('tiny')
    elif action == 'link': b.link_unit('tiny')
    elif action == 'preflight': b.validate()
    else: raise ValueError(action)
