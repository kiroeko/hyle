"""Only the two relevant original modifier journeys after withdrawing the candidate."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value
r = module('retained_original_terminal_runner', W.parent / 'validation/run.py')
build = module('retained_failure_build', W / 'build.py')
r.W = W; r.__file__ = __file__; r.b = build.b; r.t = build.b.t
r.ARMS = {k: r.ARMS[k] for k in ('mods-cpu', 'mods-cuda')}
def prepare():
    r.b.plan()
    r.t.save(W / 'test-source-pins.json', {s: r.t.pin(r.R / s) for s in r.SOURCES})
    r.t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', helper=r.t.pin(__file__),
        fixture=r.t.pin(r.FIXTURE / 'weights.tsv'), runtime=r.t.pin(W / 'runtime.json'),
        test_source_pins=r.t.pin(W / 'test-source-pins.json'),
        parsers={k: r.t.pin(v) for k, v in r.PARSERS.items()},
        arms={k: dict(backend=v[0], parser=v[1], flag=v[2]) for k, v in r.ARMS.items()},
        native_processes=2, CPU=1, CUDA=1, automatic_retries=0,
        scope='Original private-prefix modifier journeys plus the new post-target failure regression. Candidate graph merge withdrawn.'))
if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': r.run(sys.argv[2])
    elif action in ('parse', 'parse-only'): r.parse(sys.argv[2])
    else: raise ValueError(action)
