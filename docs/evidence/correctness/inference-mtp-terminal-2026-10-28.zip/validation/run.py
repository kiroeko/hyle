"""Six existing finite consumers; explicit single-use runs and offline parsing."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


wrapper = module('mtp_terminal_build', W / 'build.py')
b = wrapper.b
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
PARSERS = {
    'sampling': R / '.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py',
    'modifiers': R / '.scratch/inference-mtp-logits-20261028/refinement/run.py',
}
ARMS = {
    'sampler-cpu': ('cpu', 'sampling', '--mtp-sampling'),
    'sampler-cuda': ('cuda', 'sampling', '--mtp-sampling'),
    'mods-cpu': ('cpu', 'modifiers', '--mtp-logits'),
    'mods-cuda': ('cuda', 'modifiers', '--mtp-logits'),
    'stop-cpu': ('cpu', 'stop', '--mtp-stop'),
    'stop-cuda': ('cuda', 'stop', '--mtp-stop'),
}
SOURCES = (
    'tests/tools/qwen_mtp_sampling_case.h',
    'tests/tools/qwen_mtp_logits_case.h',
    'tests/tools/qwen_history_control_case.h',
    'tests/tools/qwen_history_replay_case.h',
    'tests/tools/qwen_request_lifecycle_test.cc',
    'tests/tools/qwen_request_ledger_case.h',
    'tests/tools/qwen_sampling_budget_case.h',
    'tests/tools/qwen_sampling_policy_case.h',
)


def prepare():
    b.plan()
    t.save(W / 'test-source-pins.json', dict(status='SOURCE_IDENTITIES_ONLY',
        sources={path: t.pin(R / path) for path in SOURCES},
        scope='Eight adapted test sources; listing does not claim every standalone ordinary consumer was compiled or run.'))
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', helper=t.pin(__file__),
        fixture=t.pin(FIXTURE / 'weights.tsv'),
        parsers={name: t.pin(path) for name, path in PARSERS.items()},
        test_source_pins=t.pin(W / 'test-source-pins.json'), runtime=t.pin(W / 'runtime.json'),
        arms={name: dict(backend=backend, parser=kind, flag=flag, output=str(W / 'runs' / name))
              for name, (backend, kind, flag) in ARMS.items()},
        order=list(ARMS), native_processes=6, CPU=3, CUDA=3, automatic_retries=0,
        scope='Existing synthetic GA/H64/V64/C16 sampling/modifier/stop consumers. Original oracles plus one post-target invalid-terminal contract in modifiers. No performance or trained-quality claim.'))
    print('PLANNED ONLY: sampler/modifiers/stop CPU+CUDA, six native processes; source identities8')


def stop_report(reports, backend):
    # Original stop_report; only its backend argument replaces the CPU literal.
    assert len(reports) == 1
    report = reports[0]
    assert report['status'] == 'PASS' and report['case'] == 'mtp-stop-policy' and report['backend'] == backend
    for field in ('actual_B2', 'accepted_extra_stop_pending', 'native_rejected_draft_stop', 'fused_K1_stop',
                  'actual_bonus_stop', 'new_request_prefix_policy', 'same_key_rebuild_policy',
                  'old_checkpoints_byte_unchanged', 'full_state_numerically_equivalent',
                  'controlled_target_matching_candidate', 'rebuild_sampling_wrapper'):
        assert report[field] is True, field
    assert report['final_versions'] == 0 and report['greedy_rng_draws'] == 0
    assert report['real_model_EOS_checked'] is False and report['ignoreEOS_host_only'] is True
    assert len(report['state_checks']) == 5
    assert all(x['boundary_equal'] and x['numerically_equivalent'] for x in report['state_checks'])
    return report


def parse(name):
    backend, kind, flag = ARMS[name]
    out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out'], process
    as_run = t.read(out / 'as-run.json')
    assert process == as_run['process']
    assert t.read(out / 'command.json')['command'] == [as_run['image']['path'], '--' + backend, str(FIXTURE), flag]
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    if kind == 'sampling':
        parser = module('mtp_terminal_retained_sampling_parser', PARSERS[kind])
        actual = parser.sampler_reports(reports, backend)
        checks = actual['manual']['state_checks']
    elif kind == 'modifiers':
        parser = module('mtp_terminal_retained_modifiers_parser', PARSERS[kind])
        actual = parser.modifiers_report(reports, backend)
        for field in ('target_terminal_numeric_failure', 'target_terminal_retired_without_publish',
                      'target_terminal_resources_returned'):
            assert actual[field] is True, field
        checks = actual['state_checks']
    else:
        actual = stop_report(reports, backend)
        checks = actual['state_checks']
    t.save(out / 'report.json', actual)
    t.save(out / 'summary.json', dict(status='PASS', name=name, backend=backend, process=process,
        report=t.pin(out / 'report.json'), state_checks=len(checks),
        payloads_byte_equal_checks=sum(row['payloads_byte_equal'] for row in checks),
        maximum_GDN_absolute_difference=max((delta['maximum_absolute'] for row in checks
                                            for delta in row['differences']), default=0),
        source_freeze=t.pin(W / 'final-source-freeze.json'),
        quality_claim=False, performance_claim=False))
    print('PASS', name, 'PID', process['pid'], 'state checks', len(checks))


def run(name):
    backend, _, flag = ARMS[name]
    b.validate()
    plan = t.read(W / 'run-plan.json')
    for field in ('helper', 'fixture', 'runtime', 'test_source_pins'):
        t.exact(plan[field])
    for pin in plan['parsers'].values():
        t.exact(pin)
    ready = t.read(W / 'ready-tiny.json')
    t.exact(ready['image'])
    t.exact(ready['inputs'])
    native = t.read(ready['runtime']['path'])['native']
    assert (W / 'bin' / Path(native['path']).name).samefile(native['path'])
    out = W / 'runs' / name
    assert not out.exists(), 'Preserve first attempt; repair parsing offline instead of rerunning successful native work'
    process = t.execute([ready['image']['path'], '--' + backend, str(FIXTURE), flag], out, 300)
    t.save(out / 'as-run.json', dict(ready=t.pin(W / 'ready-tiny.json'), image=ready['image'], inputs=ready['inputs'],
        fixture=plan['fixture'], source_freeze=ready['source_freeze'], runtime=ready['runtime'],
        run_plan=t.pin(W / 'run-plan.json'), process=process))
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action in ('parse', 'parse-only'): parse(sys.argv[2])
    else: raise ValueError(action)
