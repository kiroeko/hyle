"""Reuse the existing one-consumer driver; root owns CXX, link and native runs."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path('C:/public/project-hyle/hyle')
OLD = R / '.scratch/inference-prepared-program-family-20261028/validation/build.py'
spec = importlib.util.spec_from_file_location('original_prepared_family_build', OLD)
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.W = W; b.__file__ = __file__; b.t.W = W
b.SNAPSHOTS = ('engine/models/qwen35/main.cc', 'engine/inference/sampling_graph.h',
    'tests/tools/qwen_mtp_sampling_case.h', 'tests/tools/qwen_mtp_logits_case.h',
    'tests/tools/qwen_mtp_stop_case.h', 'tests/tools/qwen_history_replay_case.h',
    'tests/tools/qwen_history_control_case.h', 'tests/tools/qwen_host_image_test.cc')

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': b.prepare()
    elif action == 'freeze': b.freeze()
    elif action == 'preflight': b.validate()
    elif action == 'compile': b.compile_unit('tiny')
    elif action == 'parse-compile': b.parse_compile('tiny')
    elif action == 'link': b.link_unit('tiny')
    else: raise ValueError(action)
