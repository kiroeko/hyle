"""Root-only two-file amendment; never transfers project source/SDK or starts a build."""
from pathlib import Path
import base64
import hashlib
import importlib.util
import json
import shlex
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path('C:/public/project-hyle/hyle')


def pin(path):
    path = Path(path); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def transport():
    path = R / '.scratch/inference-native-state-only-20261028/apple/build.py'
    s = importlib.util.spec_from_file_location('mtp_terminal_original_safe_transport', path)
    value = importlib.util.module_from_spec(s); s.loader.exec_module(value); return value


REMOTE = r'''import base64,hashlib,json,pathlib,sys
p=json.load(sys.stdin);w=pathlib.Path(p['remote'])
if str(w)!='/Users/kiro/hyle-scratch/compute-unified/inference-mtp-terminal-20261028/apple':raise RuntimeError('wrong target')
if not w.is_dir() or (w/'compile').exists() or (w/'runs').exists() or (w/'ready.json').exists():raise RuntimeError('expected pre-compile helper-only amendment')
def identity(path):
 data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
before={};after={};backups={}
for name in ('driver.py','source-freeze.json'):
 row=p['before'][name];actual=identity(w/name)
 if (actual['bytes'],actual['sha256'])!=(row['bytes'],row['sha256']):raise RuntimeError('original remote identity differs: '+name)
 before[name]=actual
 data=base64.b64decode(p['files'][name]);expected=p['after'][name]
 if (len(data),hashlib.sha256(data).hexdigest())!=(expected['bytes'],expected['sha256']):raise RuntimeError('new payload differs: '+name)
old=json.loads((w/'source-freeze.json').read_text());new=json.loads(base64.b64decode(p['files']['source-freeze.json']))
expected=dict(old);expected['remote_driver']=new['remote_driver']
if expected!=new:raise RuntimeError('source freeze differs beyond remote_driver identity')
if old['sources']!=new['sources'] or old['helper']!=new['helper']:raise RuntimeError('product source/helper identity drift')
for name,backup in (('driver.py','driver-attempt1.py'),('source-freeze.json','source-freeze-attempt1.json')):
 path=w/backup
 with path.open('xb') as out:out.write((w/name).read_bytes())
 backups[name]=identity(path)
for name in ('driver.py','source-freeze.json'):
 path=w/name;data=base64.b64decode(p['files'][name]);temporary=w/(name+'.v2-new')
 with temporary.open('xb') as out:out.write(data)
 temporary.replace(path);after[name]=identity(path)
result=dict(status='HELPER_TWO_FILE_AMENDMENT_APPLIED',before=before,after=after,backups=backups,
 unchanged_source_files=len(old['sources']),changed_source_fields=['remote_driver'],
 compile_started=False,native_started=False,SDK_transferred=False)
with (w/'driver-v2-sync-receipt.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps(result))
'''


def sync():
    amendment = json.loads((W / 'driver-v2-amendment.json').read_text())
    for row in [*amendment['before_backups'].values(), *amendment['after'].values(), amendment['original_archive']]: exact(row)
    payload = dict(remote=amendment['remote'], before=amendment['before'], after=amendment['after'],
        files={name: base64.b64encode((W / name).read_bytes()).decode('ascii') for name in ('driver.py', 'source-freeze.json')})
    m = transport(); m.call(m.SSH + ['python3 -c ' + shlex.quote(REMOTE)], W / 'sync-driver-v2b', json.dumps(payload).encode())
    result = json.loads((W / 'sync-driver-v2b/stdout.log').read_text().strip().splitlines()[-1])
    assert result['status'] == 'HELPER_TWO_FILE_AMENDMENT_APPLIED'
    with (W / 'driver-v2-applied.json').open('x') as out: json.dump(result, out, indent=2); out.write('\n')
    print('Only driver/source-freeze amended; initial archive/source/preflight failure retained')


def preflight():
    amendment = json.loads((W / 'driver-v2-amendment.json').read_text()); m = transport()
    argv = ['python3', amendment['remote'] + '/driver.py', 'preflight', 'v2']
    m.call(m.SSH + [shlex.join(argv)], W / 'invocations/preflight-v3')


if __name__ == '__main__':
    if sys.argv[1] == 'sync': sync()
    elif sys.argv[1] == 'preflight-v2': preflight()
    else: raise ValueError('sync or preflight-v2')
