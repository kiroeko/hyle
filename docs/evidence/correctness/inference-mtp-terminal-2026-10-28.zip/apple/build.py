"""Local metadata/freeze, then explicit root-only actions via the existing Apple transport."""
from pathlib import Path
import importlib.util
import json
import re
import sys
import tarfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path('C:/public/project-hyle/hyle')
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-mtp-terminal-20261028/apple'
FIXED = R / '.scratch/inference-apple-history-compile-20261028/fixed'


def module(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    v = importlib.util.module_from_spec(s); s.loader.exec_module(v); return v


p = module('mtp_terminal_original_apple_transport', R / '.scratch/inference-native-program-io-20261028/apple/build.py')
t = p.t


def prepare():
    assert not (W / 'plan.json').exists()
    ready = t.read(FIXED / 'readback/ready.json'); rows = t.read(FIXED / 'readback/inputs.json'); assert len(rows) == 120
    original = t.read(R / '.scratch/inference-native-program-io-20261028/apple/refinement1/plan.json')
    tiny = original['units'][0]; assert tiny['name'] == 'tiny'
    units = []
    recipes = [('tiny', 'tests/tools/qwen_host_image_test.cc', tiny['command'], tiny['object'],
        str(R / '.scratch/inference-native-program-io-20261028/apple/refinement1/plan.json'))]
    for name in ('resources', 'slots-region'):
        recipe_path = R / '.scratch/inference-native-state-only-20261028/apple/recipes' / (name + '.json')
        recipe = t.read(recipe_path)
        recipes.append((name, recipe['source'], recipe['command'], recipe['object'], str(recipe_path)))
    for name, source, previous, old_object, origin in recipes:
        command = list(previous)
        command[1:1] = ['-I' + REMOTE + '/source/include', '-I' + REMOTE + '/source', '-I' + REMOTE + '/source/engine',
            '-iquote', REMOTE + '/source/src/graph', '-iquote', REMOTE + '/source/src/compute']
        command[command.index('-c') + 1] = REMOTE + '/source/' + source
        command[command.index('-o') + 1] = REMOTE + '/compile/' + name + '/unit.o'
        command[command.index('-MF') + 1] = REMOTE + '/compile/' + name + '/dependencies.d'
        assert '-O3' in command and '-std=c++23' in command and '-DHYLE_STATIC' in command
        assert command[command.index('-arch') + 1] == 'arm64'
        old, = [row for row in rows if row['path'] == old_object]
        units.append(dict(name=name, source=source, command=command, old_object=old,
            object=REMOTE + '/compile/' + name + '/unit.o', recipe_origin=origin))
    fixed = t.read(FIXED / 'plan.json'); mapping = {unit['old_object']['path']: unit['object'] for unit in units}
    link = []
    for at, arg in enumerate(fixed['link_command']):
        if at and fixed['link_command'][at - 1] == '-o': arg = REMOTE + '/bin/tiny'
        elif arg.startswith('-Wl,-map,'): arg = '-Wl,-map,' + REMOTE + '/link/image.map'
        else: arg = mapping.get(arg, arg)
        link.append(arg)
    assert sum(arg.endswith(('.o', '.a', '.dylib')) for arg in link) == 120
    assert all(link.count(unit['object']) == 1 for unit in units)
    t.save(W / 'plan.json', dict(status='PREPARED_UNFROZEN', remote=REMOTE, units=units, old_inputs=rows,
        link_command=link, baseline_ready=t.pin(FIXED / 'readback/ready.json'), baseline_inputs=t.pin(FIXED / 'readback/inputs.json'),
        remote_baseline_ready='/Users/kiro/hyle-scratch/compute-unified/inference-apple-history-compile-20261028/fixed/ready.json',
        original_recorder='/Users/kiro/hyle-scratch/compute-unified/inference-apple-history-compile-20261028/fixed/driver.py',
        original_transport=t.pin(R / '.scratch/inference-native-program-io-20261028/apple/build.py'),
        retained_MLX_archive=ready['archive']['isolated'], runtime=fixed['runtime'], fixture=fixed['fixture'],
        counts=dict(CXX=3, links=1, inputs=120, retained=117, native=1, MLX_CXX=0, downloads=0),
        scope='Current canonical Tiny and two Graph bulk-take TUs; exact fixed MLX archive retained. One original --mtp-logits only. Separate explicit freeze; no old engine source compiled.'))
    print('PREPARED UNFROZEN Apple3CXX/1link/120inputs; MLX unchanged, no transport/model')


def freeze():
    plan = t.read(W / 'plan.json'); assert not (W / 'source-freeze.json').exists()
    roots = [R, R / 'include', R / 'engine', R / 'src/graph', R / 'src/compute', R / 'src/compute_batch', R / 'src/graph_batch']
    pending = [R / unit['source'] for unit in plan['units']]; seen = {}
    while pending:
        path = pending.pop().resolve(); relative = path.relative_to(R).as_posix()
        if relative in seen: continue
        assert relative.startswith(('engine/', 'tests/', 'include/', 'src/')), relative
        seen[relative] = t.pin(path)
        for quote, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((candidate.resolve() for root in ([path.parent] if quote == '"' else []) + roots
                if (candidate := root / name).is_file()), None)
            if found is not None and found.is_relative_to(R): pending.append(found)
    sources = []
    for relative, row in seen.items():
        target = W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as out: out.write((R / relative).read_bytes())
        sources.append(dict(path=relative, bytes=row['bytes'], sha256=row['sha256']))
    t.save(W / 'source-freeze.json', dict(status='FROZEN_NOT_SYNCED', plan=t.pin(W / 'plan.json'),
        sources=sources, remote_driver=t.pin(W / 'driver.py'), helper=t.pin(__file__),
        source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources),
        scope='Reachable current source/header slice only, no SDK libraries, fixture or compiler payload. Actual Clang includes are checked after compilation.'))
    archive = W / 'thin-sync.tar.gz'
    with tarfile.open(archive, 'x:gz') as tar:
        for name in ('plan.json', 'source-freeze.json', 'driver.py'): tar.add(W / name, arcname=name)
        for row in sources: tar.add(W / 'source' / row['path'], arcname='source/' + row['path'])
    t.save(W / 'prepared.json', dict(archive=t.pin(archive), remote=REMOTE, source_freeze=t.pin(W / 'source-freeze.json'),
        source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources)))
    print('FROZEN current thin source', len(sources), 'files; no SSH/compiler')


def parse(label):
    out = W / ('readback-' + label) / 'records/runs/mods'; process = t.read(out / 'process.json')
    assert process['exit'] == 0 and process['timeout'] is False
    as_run = t.read(out / 'as-run.json'); assert as_run['process'] == process
    plan = t.read(W / 'plan.json')
    assert t.read(out / 'command.json')['command'] == [as_run['image']['path'], '--apple', plan['fixture'], '--mtp-logits']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    original = R / '.scratch/inference-mtp-logits-20261028/refinement/run.py'
    oracle = module('mtp_terminal_original_apple_modifiers_parser', original)
    report = oracle.modifiers_report(reports, 'apple')
    for field in ('target_terminal_numeric_failure', 'target_terminal_retired_without_publish', 'target_terminal_resources_returned'):
        assert report[field] is True, field
    t.save(out / 'report.json', report)
    t.save(W / ('analysis-' + label + '.json'), dict(status='PASS', backend='apple', process=process,
        original_parser=t.pin(original), report=t.pin(out / 'report.json'), state_checks=len(report['state_checks']),
        source_freeze=t.pin(W / 'source-freeze.json'), performance_claim=False, quality_claim=False))
    print('PASS original Apple modifiers+three terminal gates; no native rerun')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'parse': parse(sys.argv[2])
    else:
        p.W = W; p.REMOTE = REMOTE
        if action == 'sync': p.sync()
        elif action == 'fetch': p.fetch(sys.argv[2])
        elif action in ('preflight', 'link', 'run'): p.invoke(action)
        elif action == 'compile': p.invoke('compile', sys.argv[2])
        elif action == 'parse-compile': p.invoke('parse-compile', sys.argv[2])
        else: raise ValueError(action)
