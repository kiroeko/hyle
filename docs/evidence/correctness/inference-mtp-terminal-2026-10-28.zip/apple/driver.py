"""Root-invoked remote recorder: three explicit CXX, one link and one original modifier run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())


def read(path): return json.loads(Path(path).read_text())
def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')


def pin(path):
    path = Path(path); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def exact(row):
    actual = pin(row['path'])
    if any(actual[key] != row[key] for key in ('bytes', 'sha256')): raise ValueError('pin mismatch: ' + row['path'])
    return actual


def stat_matches(row):
    actual = Path(row['path']).stat()
    if actual.st_size != row['bytes'] or ('mtime_ns' in row and actual.st_mtime_ns != row['mtime_ns']):
        raise ValueError('retained file stat mismatch: ' + row['path'])


def execute(argv, directory, cwd=None, timeout=240, env_overrides=None):
    # Same process/command receipt schema as the original fixed recorder;
    # importing that file also executes its unguarded CLI, so keep only these
    # side-effect-free recording functions here.
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'command.json', dict(command=argv, cwd=str(cwd or W),
        timeout_seconds=timeout, environment_overrides=env_overrides or {}))
    tick = time.perf_counter(); started = datetime.now(timezone.utc).isoformat()
    env = os.environ.copy(); env.update(env_overrides or {})
    with (directory / 'stdout.log').open('wb') as stdout, (directory / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=cwd or W, env=env, stdout=stdout, stderr=stderr)
        save(directory / 'running.json', dict(pid=process.pid, started_utc=started))
        timed_out = False
        try: process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True; process.kill(); process.wait()
    result = dict(pid=process.pid, exit=process.returncode, timeout=timed_out,
        started_utc=started, ended_utc=datetime.now(timezone.utc).isoformat(), seconds=time.perf_counter() - tick)
    save(directory / 'process.json', result); print(json.dumps(result), flush=True)
    return result


def require_success(process):
    if process['exit'] != 0 or process['timeout']: raise RuntimeError('actual command failed; preserve this attempt')


def verify():
    frozen = read(W / 'source-freeze.json')
    for row in frozen['sources']:
        actual = pin(W / 'source' / row['path'])
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
    assert pin(__file__)['sha256'] == frozen['remote_driver']['sha256']
    return frozen


def preflight():
    verify()
    baseline = exact(dict(P['baseline_ready'], path=P['remote_baseline_ready']))
    old_ready = read(P['remote_baseline_ready']); exact(old_ready['inputs'])
    assert read(old_ready['inputs']['path']) == P['old_inputs']
    removed = {unit['old_object']['path'] for unit in P['units']}
    stats = []
    for row in P['old_inputs']:
        if row['path'] in removed: continue
        stat_matches(row)
        if 'sha256' in row: exact(row)
        path = Path(row['path']); st = path.stat()
        stats.append(dict(path=str(path), bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    assert len(stats) == 117; exact(P['retained_MLX_archive'])
    save(W / 'preflight.json', dict(status='PASS', baseline=baseline, retained_stats=stats,
        fixed_MLX=P['retained_MLX_archive'], retained=117, source_freeze=pin(W / 'source-freeze.json')))
    print('PREFLIGHT117 current cached inputs; no SDK copy')


def parse_compile(name):
    frozen = verify(); unit = next(x for x in P['units'] if x['name'] == name); out = W / 'compile' / name
    process = read(out / 'logs/process.json'); require_success(process)
    assert read(out / 'logs/command.json')['command'] == unit['command']
    actual = []; source_root = (W / 'source').resolve(); declared = {row['path']: row for row in frozen['sources']}
    text = (out / 'dependencies.d').read_text().replace('\\\n', '')
    for value in dict.fromkeys(shlex.split(text.split(':', 1)[1])):
        path = Path(value); path = (path if path.is_absolute() else W / path).resolve(strict=True)
        if path.is_relative_to(source_root):
            row = pin(path); expected = declared[path.relative_to(source_root).as_posix()]
            assert (row['bytes'], row['sha256']) == (expected['bytes'], expected['sha256'])
        else:
            # Current project headers must not silently resolve into an old
            # cached source root when the declared thin closure contains them.
            for marker in ('/include/', '/engine/', '/tests/tools/', '/src/graph/'):
                text_path = str(path)
                if marker in text_path:
                    logical = marker.strip('/') + '/' + text_path.split(marker, 1)[1]
                    assert logical not in declared, ('Old physical project header selected', logical, str(path))
            st = path.stat(); row = dict(path=str(path), bytes=st.st_size, mtime_ns=st.st_mtime_ns)
        actual.append(row)
    save(out / 'actual-dependencies.json', actual)
    save(out / 'compiled.json', dict(source=next(x for x in frozen['sources'] if x['path'] == unit['source']),
        object=pin(unit['object']), process=process, command=pin(out / 'logs/command.json'),
        dependencies=pin(out / 'dependencies.d'), actual_dependencies=pin(out / 'actual-dependencies.json')))
    print('CXX metadata PASS', name)


def compile_one(name):
    verify(); assert (W / 'preflight.json').is_file()
    unit = next(x for x in P['units'] if x['name'] == name); out = W / 'compile' / name
    out.mkdir(parents=True, exist_ok=False)
    process = execute(unit['command'], out / 'logs', cwd=W, timeout=300)
    require_success(process); parse_compile(name)


def link():
    verify(); preflight = read(W / 'preflight.json')
    for row in preflight['retained_stats']: stat_matches(row)
    replacements = {}
    for unit in P['units']:
        compiled = read(W / 'compile' / unit['name'] / 'compiled.json'); require_success(compiled['process']); exact(compiled['object'])
        replacements[unit['old_object']['path']] = compiled['object']
    rows = [replacements.get(row['path'], row) for row in P['old_inputs']]
    assert len(rows) == 120 and sum(x != y for x, y in zip(rows, P['old_inputs'])) == 3
    assert all(P['link_command'].count(row['path']) == 1 for row in rows)
    (W / 'bin').mkdir(exist_ok=True)
    process = execute(P['link_command'], W / 'link/logs', cwd=W, timeout=240); require_success(process)
    save(W / 'inputs.json', rows)
    save(W / 'ready.json', dict(image=pin(W / 'bin/tiny'), inputs=pin(W / 'inputs.json'), process=process,
        recipe=pin(W / 'link/logs/command.json'), source_freeze=pin(W / 'source-freeze.json'), runtime=P['runtime']))
    print('LINK120 PASS; fixed MLX unchanged')


def run():
    verify(); ready = read(W / 'ready.json'); exact(ready['image']); exact(ready['inputs'])
    out = W / 'runs/mods'; assert not out.exists(), 'Keep the first native result; parsing is a separate action'
    process = execute([ready['image']['path'], '--apple', P['fixture'], '--mtp-logits'], out,
        cwd=W, timeout=300, env_overrides=P['runtime'])
    save(out / 'as-run.json', dict(image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'],
        runtime_overrides=P['runtime'], process=process))
    require_success(process)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'preflight': preflight()
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'parse-compile': parse_compile(sys.argv[2])
    elif action == 'link': link()
    elif action == 'run': run()
    else: raise ValueError(action)
