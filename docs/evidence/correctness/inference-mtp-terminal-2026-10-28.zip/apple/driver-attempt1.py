"""Root-invoked remote recorder: three explicit CXX, one link and one original modifier run."""
from pathlib import Path
import importlib.util
import json
import os
import shlex
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())
s = importlib.util.spec_from_file_location('mtp_terminal_existing_apple_recorder', P['original_recorder'])
b = importlib.util.module_from_spec(s); s.loader.exec_module(b)


def read(path): return json.loads(Path(path).read_text())
def save(path, value): b.save(path, value)
def exact(pin): return b.exact(pin)
def verify():
    frozen = read(W / 'source-freeze.json')
    for row in frozen['sources']:
        actual = b.pin(W / 'source' / row['path'])
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
    assert b.pin(__file__)['sha256'] == frozen['remote_driver']['sha256']
    return frozen


def preflight():
    verify()
    baseline = exact(dict(P['baseline_ready'], path=P['remote_baseline_ready']))
    old_ready = read(P['remote_baseline_ready']); exact(old_ready['inputs'])
    assert read(old_ready['inputs']['path']) == P['old_inputs']
    removed = {unit['old_object']['path'] for unit in P['units']}
    stats = []
    for row in P['old_inputs']:
        if row['path'] in removed: continue
        b.stat_matches(row)
        if 'sha256' in row: exact(row)
        path = Path(row['path']); st = path.stat()
        stats.append(dict(path=str(path), bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    assert len(stats) == 117; exact(P['retained_MLX_archive'])
    save(W / 'preflight.json', dict(status='PASS', baseline=baseline, retained_stats=stats,
        fixed_MLX=P['retained_MLX_archive'], retained=117, source_freeze=b.pin(W / 'source-freeze.json')))
    print('PREFLIGHT117 current cached inputs; no SDK copy')


def parse_compile(name):
    frozen = verify(); unit = next(x for x in P['units'] if x['name'] == name); out = W / 'compile' / name
    process = read(out / 'logs/process.json'); b.require_success(process)
    assert read(out / 'logs/command.json')['command'] == unit['command']
    actual = []; source_root = (W / 'source').resolve(); declared = {row['path']: row for row in frozen['sources']}
    text = (out / 'dependencies.d').read_text().replace('\\\n', '')
    for value in dict.fromkeys(shlex.split(text.split(':', 1)[1])):
        path = Path(value); path = (path if path.is_absolute() else W / path).resolve(strict=True)
        if path.is_relative_to(source_root):
            row = b.pin(path); expected = declared[path.relative_to(source_root).as_posix()]
            assert (row['bytes'], row['sha256']) == (expected['bytes'], expected['sha256'])
        else:
            # Current project headers must not silently resolve into an old
            # cached source root when the declared thin closure contains them.
            for marker in ('/include/', '/engine/', '/tests/tools/', '/src/graph/'):
                text_path = str(path)
                if marker in text_path:
                    logical = marker.strip('/') + '/' + text_path.split(marker, 1)[1]
                    assert logical not in declared, ('Old physical project header selected', logical, str(path))
            st = path.stat(); row = dict(path=str(path), bytes=st.st_size, mtime_ns=st.st_mtime_ns)
        actual.append(row)
    save(out / 'actual-dependencies.json', actual)
    save(out / 'compiled.json', dict(source=next(x for x in frozen['sources'] if x['path'] == unit['source']),
        object=b.pin(unit['object']), process=process, command=b.pin(out / 'logs/command.json'),
        dependencies=b.pin(out / 'dependencies.d'), actual_dependencies=b.pin(out / 'actual-dependencies.json')))
    print('CXX metadata PASS', name)


def compile_one(name):
    verify(); assert (W / 'preflight.json').is_file()
    unit = next(x for x in P['units'] if x['name'] == name); out = W / 'compile' / name
    out.mkdir(parents=True, exist_ok=False)
    process = b.execute(unit['command'], out / 'logs', cwd=W, timeout=300)
    b.require_success(process); parse_compile(name)


def link():
    verify(); preflight = read(W / 'preflight.json')
    for row in preflight['retained_stats']: b.stat_matches(row)
    replacements = {}
    for unit in P['units']:
        compiled = read(W / 'compile' / unit['name'] / 'compiled.json'); b.require_success(compiled['process']); exact(compiled['object'])
        replacements[unit['old_object']['path']] = compiled['object']
    rows = [replacements.get(row['path'], row) for row in P['old_inputs']]
    assert len(rows) == 120 and sum(x != y for x, y in zip(rows, P['old_inputs'])) == 3
    assert all(P['link_command'].count(row['path']) == 1 for row in rows)
    (W / 'bin').mkdir(exist_ok=True)
    process = b.execute(P['link_command'], W / 'link/logs', cwd=W, timeout=240); b.require_success(process)
    save(W / 'inputs.json', rows)
    save(W / 'ready.json', dict(image=b.pin(W / 'bin/tiny'), inputs=b.pin(W / 'inputs.json'), process=process,
        recipe=b.pin(W / 'link/logs/command.json'), source_freeze=b.pin(W / 'source-freeze.json'), runtime=P['runtime']))
    print('LINK120 PASS; fixed MLX unchanged')


def run():
    verify(); ready = read(W / 'ready.json'); exact(ready['image']); exact(ready['inputs'])
    out = W / 'runs/mods'; assert not out.exists(), 'Keep the first native result; parsing is a separate action'
    process = b.execute([ready['image']['path'], '--apple', P['fixture'], '--mtp-logits'], out,
        cwd=W, timeout=300, env_overrides=P['runtime'])
    save(out / 'as-run.json', dict(image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'],
        runtime_overrides=P['runtime'], process=process))
    b.require_success(process)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'preflight': preflight()
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'parse-compile': parse_compile(sys.argv[2])
    elif action == 'link': link()
    elif action == 'run': run()
    else: raise ValueError(action)
