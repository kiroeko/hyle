"""Offline only. Require final Apple readback/strict analysis; never run native."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile

W = Path(__file__).resolve().parent
R = Path('C:/public/project-hyle/hyle')
PRODUCT = R / '.scratch/inference-verify-terminal-20261028/product'
DEST = R / 'docs/evidence/correctness/inference-mtp-terminal-2026-10-28'
FINAL = ('sampler-cpu', 'sampler-cuda', 'mods-cpu', 'mods-cuda', 'stop-cpu', 'stop-cuda')
MAIN = '27cd19c1e87b457007cc7ae4bbd4a90fae1a4e7df570f93c733b6c0cbcbf1080'
OLD_MAIN = '8c007ecbc7a5172226bcfc56a27f5c0acf3ea0e2dc199aa3bc4753f9a8d0c764'
TEST = '7a9f10c75b6de0d0d9e1e9dd36c9a47d2291853f35c1e2c12e4b847de4ff9d71'
RETAINED_MAIN = '1809c54dd73ae708b6583429e052fe18ca60e21ae2ba0b62ada33f8d90d903f9'
RETAINED_TEST = 'abba26c2499e4e2c0c04590427a89e907a681d0635ba2fbaedef8c1f50be0b21'


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def success(process):
    assert process['exit'] == 0 and not process.get('timed_out') and not process.get('timeout'), process
def check_payloads(report):
    rows = report['manual']['state_checks'] if 'manual' in report else report['state_checks']
    assert rows and all(row['payloads_byte_equal'] is True and row['differences'] == [] for row in rows)
    return len(rows)
def mods(report, backend):
    assert report['status'] == 'PASS' and report['backend'] == backend and report['case'] == 'mtp-logits-modifiers'
    assert report['finite_math_branches'] == 2 and report['numeric_q_failures'] == 2
    for key in ('already_normalized_q_not_reprocessed', 'target_terminal_numeric_failure',
                'target_terminal_retired_without_publish', 'target_terminal_resources_returned', 'same_key_retry'):
        assert report[key] is True, key
    assert report['final_versions'] == 0 and report['quality_claim'] is False and report['performance_claim'] is False
    assert check_payloads(report) == 10


def main(label):
    assert re.fullmatch(r'[A-Za-z0-9_.-]+', label), 'Provide one explicit Apple readback label'
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Preserve completed evidence'
    archive = {}
    def add(path, name=None):
        path = Path(path)
        name = name or path.relative_to(W).as_posix()
        assert name not in archive and path.is_file(), (name, str(path))
        assert path.suffix.lower() not in ('.exe', '.obj', '.o', '.a', '.lib', '.dll', '.dylib', '.pdb', '.exp',
            '.map', '.bin', '.bf16', '.f16', '.f32', '.safetensors', '.gguf', '.metallib', '.gz', '.zip')
        archive[name] = path.read_bytes()
    def metadata_tree(directory, prefix):
        directory = Path(directory); assert directory.is_dir(), directory
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.log', '.d') and path.name != 'running.json':
                add(path, prefix + '/' + path.relative_to(directory).as_posix())
    def win_build(stage, count):
        root = W / stage; ready = read(root / 'ready-tiny.json'); frozen = read(root / 'final-source-freeze.json')
        cxx = read(root / 'logs/tiny/process.json'); link = read(root / 'links/tiny/process.json')
        success(cxx); success(link)
        assert ready['compiled']['process'] == cxx and ready['process'] == link
        for key in ('inputs', 'recipe', 'runtime', 'source_freeze'): exact(ready[key])
        assert len(read(ready['inputs']['path'])) == count
        for key in ('helper', 'expected', 'dependencies'): exact(frozen[key])
        for key in ('command', 'dependencies', 'actual_dependencies'): exact(ready['compiled'][key])
        for name in ('build.py', 'run.py', 'final-build-plan.json', 'final-source-freeze.json', 'expected-sources.json',
                     'frozen-project-dependencies.json', 'retained-input-stats.json', 'runtime.json', 'ready-tiny.json',
                     'inputs-tiny.json', 'run-plan.json', 'recipes/tiny.json', 'link-recipes/tiny.json'):
            add(root / name)
        for name in ('logs/tiny', 'links/tiny', 'compile/tiny'): metadata_tree(root / name, stage + '/' + name)
        sources = []
        for row in frozen['snapshots']:
            exact(row['snapshot'])
            assert (row['original']['bytes'], row['original']['sha256']) == (row['snapshot']['bytes'], row['snapshot']['sha256'])
            relative = Path(row['original']['path']).relative_to(R).as_posix()
            if stage in ('validation', 'refinement', 'retained'):
                add(row['snapshot']['path'], stage + '/source/' + relative)
            sources.append(dict(path=relative, identity=row['snapshot']))
        return dict(stage=stage, CXX=cxx, link=link, image=ready['image'], inputs=ready['inputs'], input_count=count,
            compiled=ready['compiled'], source_freeze=ready['source_freeze'], sources=sources), ready
    def win_case(stage, name, expected):
        directory = W / stage / 'runs' / name
        process = read(directory / 'process.json'); success(process)
        summary = read(directory / 'summary.json'); assert summary['status'] == 'PASS' and summary['process'] == process
        exact(summary['report']); report = read(summary['report']['path'])
        assert summary['state_checks'] == summary['payloads_byte_equal_checks'] == check_payloads(report) == expected
        assert summary['maximum_GDN_absolute_difference'] == 0
        if name.startswith('mods'): mods(report, summary['backend'])
        if name.startswith('sampler'):
            assert report['final']['completed_q_released'] is True and report['final']['actual_B2_simultaneous_q'] == 4
            assert report['final']['natural_recursive_cold_plan'] is True
        if name.startswith('stop'):
            assert report['rebuild_sampling_wrapper'] is True and report['old_checkpoints_byte_unchanged'] is True
        metadata_tree(directory, stage + '/runs/' + name)
        return dict(name=name, backend=summary['backend'], process=process, state_checks=expected,
            payload_byte_equal_checks=expected, maximum_GDN_absolute_difference=0, report=summary['report'])

    initial_build, initial_ready = win_build('validation', 228)
    final_build, final_ready = win_build('refinement', 228)
    vk_build, vk_ready = win_build('vulkan', 169)
    assert next(r['identity']['sha256'] for r in initial_build['sources'] if r['path'] == 'engine/models/qwen35/main.cc') == OLD_MAIN
    assert next(r['identity']['sha256'] for r in final_build['sources'] if r['path'] == 'engine/models/qwen35/main.cc') == MAIN
    assert next(r['identity']['sha256'] for r in final_build['sources'] if r['path'] == 'tests/tools/qwen_mtp_logits_case.h') == TEST
    final_sources = {r['path']: r['identity']['sha256'] for r in final_build['sources']}
    vk_sources = {r['path']: r['identity']['sha256'] for r in vk_build['sources']}
    assert all(vk_sources[path] == final_sources[path] for path in vk_sources.keys() & final_sources.keys())
    for path in ('engine/models/qwen35/main.cc', 'engine/inference/sampling_graph.h',
                 'tests/tools/qwen_mtp_logits_case.h', 'tests/tools/qwen_host_image_test.cc'):
        assert vk_sources[path] == final_sources[path], path
    # Cached Graph objects were reused on Vulkan, not compiled again here.
    for row in vk_ready['cached_graph_replacements']:
        exact(row['receipt']); add(row['receipt']['path'], 'vulkan/cached-Graph/' + row['name'] + '-compiled.json')
    first_passes = [win_case('validation', n, 17) for n in ('sampler-cpu', 'sampler-cuda')]
    failed = W / 'validation/runs/mods-cpu'; failed_process = read(failed / 'process.json')
    assert failed_process['exit'] == 1 and not failed_process.get('timed_out')
    assert 'modifier failure changed an original ledger record' in (failed / 'stderr.log').read_text(encoding='utf-8-sig')
    metadata_tree(failed, 'validation/runs/mods-cpu')
    windows = [win_case('refinement', name, 17 if name.startswith('sampler') else 10 if name.startswith('mods') else 5) for name in FINAL]
    assert sum(row['state_checks'] for row in windows) == 64
    vulkan = win_case('vulkan', 'mods-vulkan', 10)

    apple = W / 'apple'; records = apple / ('readback-' + label) / 'records'
    assert records.is_dir(), 'Final Apple readback is mandatory; no optional success path'
    analysis = read(apple / ('analysis-' + label + '.json'))
    assert analysis['status'] == 'PASS' and analysis['backend'] == 'apple' and analysis['state_checks'] == 10
    exact(analysis['report']); exact(analysis['source_freeze'])
    report = read(analysis['report']['path']); mods(report, 'apple')
    apple_run = records / 'runs/mods'; apple_process = read(apple_run / 'process.json'); success(apple_process)
    assert apple_process == analysis['process'] == read(apple_run / 'as-run.json')['process']
    ready = read(records / 'ready.json'); success(ready['process'])
    assert len(read(records / 'inputs.json')) == 120
    assert pin(records / 'source-freeze.json')['sha256'] == pin(apple / 'source-freeze.json')['sha256']
    apple_frozen = read(apple / 'source-freeze.json'); declared = {row['path']: row for row in apple_frozen['sources']}
    assert declared['engine/models/qwen35/main.cc']['sha256'] == MAIN
    assert declared['tests/tools/qwen_mtp_logits_case.h']['sha256'] == TEST
    apple_compiles = []
    for unit in ('tiny', 'resources', 'slots-region'):
        compiled = read(records / 'compile' / unit / 'compiled.json'); success(compiled['process'])
        assert compiled['process'] == read(records / 'compile' / unit / 'logs/process.json')
        apple_compiles.append(dict(unit=unit, **compiled))
    metadata_tree(records, 'apple/readback-' + label + '/records')
    add(apple / ('analysis-' + label + '.json'))
    for name in ('build.py', 'driver.py', 'driver-attempt1.py', 'sync_driver_v2.py',
                 'driver-v2-amendment.json', 'driver-v2-applied.json', 'plan.json', 'source-freeze.json',
                 'source-freeze-attempt1.json', 'prepared.json'): add(apple / name)
    # The initial Apple import/dispatch error launched no compiler or inference.
    preflight = read(apple / 'invocations/preflight/process.json')
    assert preflight['exit'] != 0
    metadata_tree(apple / 'invocations', 'apple/invocations')
    sync_failure = read(apple / 'sync-driver-v2/process.json')
    assert sync_failure['exit'] != 0
    sync_success = read(apple / 'sync-driver-v2b/process.json'); success(sync_success)
    success(read(apple / 'invocations/preflight-v3/process.json'))
    for name in ('sync-driver-v2', 'sync-driver-v2b'): metadata_tree(apple / name, 'apple/' + name)
    for relative in ('src/graph/resources.cc', 'src/graph/slots_region.cc', 'include/hyle/graph/slots.h',
                     'include/hyle/graph/detail/region_access.h'):
        path = apple / 'source' / relative; actual = pin(path); claim = declared[relative]
        assert (actual['bytes'], actual['sha256']) == (claim['bytes'], claim['sha256'])
        add(path, 'apple/source/' + relative)
    apple_case = dict(name='mods-apple', backend='apple', process=apple_process, state_checks=10,
        payload_byte_equal_checks=10, maximum_GDN_absolute_difference=0, report=analysis['report'])
    for name in ('source-freeze.json', 'retired-ledger-source-freeze.json', 'changes.patch',
                 'retired-ledger-rollback.patch', 'main-before.cc', 'main-attempt1.cc'):
        add(PRODUCT / name, 'product/' + name)
    add(W / 'terminal-test-oracle-amendment.json'); add(W / 'backend-plan.json'); add(W / 'changes.patch'); add(__file__)
    run_plan = read(W / 'refinement/run-plan.json'); exact(run_plan['fixture'])
    for name, row in run_plan['parsers'].items(): exact(row); add(row['path'], 'helpers/original-' + name + '-parser.py')
    # Original Windows process recorder is small; no SDK/header tree copy.
    original_driver = read(W / 'refinement/final-build-plan.json')['original_driver']
    exact(original_driver); add(original_driver['path'], 'helpers/original-windows-recorder.py')

    final_cases = windows + [vulkan, apple_case]
    assert sum(row['state_checks'] for row in final_cases) == 84
    all_processes = first_passes + [dict(name='mods-cpu-first-failure', process=failed_process)] + final_cases
    assert len(all_processes) == 11
    retained_build, retained_ready = win_build('retained', 228)
    retained_sources = {r['path']: r['identity']['sha256'] for r in retained_build['sources']}
    assert retained_sources['engine/models/qwen35/main.cc'] == RETAINED_MAIN
    assert retained_sources['tests/tools/qwen_mtp_logits_case.h'] == RETAINED_TEST
    retained_cases = [win_case('retained', name, 10) for name in ('mods-cpu', 'mods-cuda')]
    assert sum(row['state_checks'] for row in retained_cases) == 20
    assert {row['process']['pid'] for row in retained_cases} == {52420, 47504}
    add(W / 'retained-changes.patch')
    add(W / 'retained/test-source-pins.json')
    manifest = encoded(dict(members=[dict(name=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(archive.items())]))
    archive['MANIFEST.json'] = manifest
    outzip, outjson = DEST.with_suffix('.zip'), DEST.with_suffix('.json')
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(archive.items()): z.writestr(name, raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, raw in archive.items(): assert sha(z.read(name)) == sha(raw), name
    result = dict(schema='hyle.correctness.mtp-verify-terminal.v1', date='2026-10-28',
        status='CANDIDATE_FINITE_CORRECTNESS_PASS_NOT_ADOPTED',
        product_adoption='NOT_ADOPTED: the separate eight-process window established no net speedup and the candidate increased cold preparation/plan workspace. Retain only the independent retired-ledger failure fix and its regression.',
        change='Candidate embeds original processed speculative-prefix/greedy-modifier terminal graph in finite target Verify; retains original normalized q leases and accepted-prefix/retirement/publication contract.',
        candidate_main_sha256=MAIN, original_attempt_main_sha256=OLD_MAIN, candidate_modifiers_test_sha256=TEST,
        counts=dict(CXX=7, CXX_success=7, links=5, link_success=5, native_processes=13, native_success=12, native_failure=1,
            NVCC=0, downloads=0, third_party_rebuilds=0),
        candidate_counts=dict(CXX=6, CXX_success=6, links=4, link_success=4, native_processes=11, native_success=10, native_failure=1,
            final_native_processes=8, final_payload_byte_equal_checks=84, Windows_final_checks=64, Vulkan_final_checks=10, Apple_final_checks=10,
            Apple_SDK_CXX=2, NVCC=0, downloads=0, third_party_rebuilds=0),
        builds=[initial_build, final_build, vk_build, dict(stage='apple', CXX=apple_compiles, link=ready['process'], image=ready['image'], input_count=120,
            source_freeze=pin(apple / 'source-freeze.json'), retained_inputs=117, retained_MLX=read(apple / 'plan.json')['retained_MLX_archive'])],
        original_processes=first_passes + [dict(name='mods-cpu', process=failed_process, exit=1,
            reason='Submitted target valid0 retired/candidate rollback left the prepared uncommitted ledger record. Complete committed head/RNG were not published; original stderr retained.')],
        final_cases=final_cases,
        retained_product=dict(status='PASS_FINITE_CPU_CUDA_FAILURE_FIX_REGRESSION',
            main_sha256=RETAINED_MAIN, modifiers_test_sha256=RETAINED_TEST,
            change='Restore original separate prefix sampler. Keep only the failure-path ledger withdrawal after actual retirement, with the new post-target failure regression.',
            patch=pin(W / 'retained-changes.patch'), build=retained_build, cases=retained_cases,
            counts=dict(CXX=1, CXX_success=1, links=1, link_success=1, native_processes=2, native_success=2,
                payload_byte_equal_checks=20),
            scope='These two actual retained-product images/checks are distinct from the candidate84 checks; Vulkan/Apple were not rerun after restoring the separate sampler.'),
        refinements=dict(product='Only after original actual retirement and no private_pending, discard the exact original still-uncommitted ledger slot; preserve all committed/later slots and original error.',
            test_oracle='New post-target failure oracle checks every committed record, canonical cleared current slot and unchanged cold capacity. It no longer requires unrelated spare capacity contents to remain identical. Original draft-q failures and strict payload checks unchanged.',
            Apple_preflight=dict(process=preflight, compiler_processes=0, model_processes=0, reason='Helper import dispatched automatically; metadata-only failure, preserved with original helper/freeze.'),
            Apple_driver_sync=dict(failed_process=sync_failure, successful_process=sync_success, compiler_processes=0,
                model_processes=0, reason='First v2 sync payload had a Python syntax error and changed no remote files. Raw-string repair synced successfully; preflight-v3 and all three actual compiles then passed.')),
        predicates=dict(CPU_CUDA='Compiled Bool, exact0/1', Apple_Vulkan='Compiled F32, exact0/1 through original PreparedReadback'),
        invariants=['Original normalized q inputs are not processed/normalized again; all target conditional rows join validity before publication.',
            'Actual m proposals retain proposal2i/accept2i+1/shared-final2m and committed RNG advance2m+1; m0 has one final and no q/accept ports.',
            'Original EOS/quota/accepted pending boundary, repair, old checkpoints, same-key retry and atomic Session/ledger publication remain under original owner/retirement.'],
        fixture=dict(Windows_manifest=run_plan['fixture'], Apple_cached_fixture=read(apple / 'plan.json')['fixture'], payload_in_archive=False),
        limits=['Synthetic untrained Tiny fixture. No trained quality, statistical performance, full-model or complete platform matrix claim.',
            'Final84 checks span separate Windows CPU/CUDA, Vulkan and Apple images; initial34 passing sampler checks are retained history and not added to final84.',
            'The retained product has a separate CPU/CUDA20-check regression. Candidate84 results do not attest that the retained product was rerun on Vulkan/Apple.',
            'Original state comparison policy retains GDN3e-6; these actual84 payload comparisons were byte-equal, maximum GDN difference0. No tolerance widened.',
            'Stop model-EOS remains untested and ignoreEOS is host-only. Actual target-controlled candidate is not a natural NextN acceptance-rate/quality measurement.',
            'Separate CLI1CXX/1link and eight-process performance window are not counted or pooled here; their evidence is separate.',
            'No binaries, SDK trees, model/tensor payloads or performance timings used as TPS are archived.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', all_member_SHA256='PASS'))
    with outjson.open('xb') as stream: stream.write(encoded(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', all_member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as stream: stream.write(encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apple-label', required=True, help='Mandatory successful readback-LABEL and analysis-LABEL.json')
    main(parser.parse_args().apple_label)
