"""Rebuild only the current Tiny after the observed native rollback failure."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path('C:/public/project-hyle/hyle')
spec = importlib.util.spec_from_file_location('mtp_terminal_retained_build', W.parent / 'validation/build.py')
wrapper = importlib.util.module_from_spec(spec); spec.loader.exec_module(wrapper)
b = wrapper.b
b.W = W; b.__file__ = __file__; b.t.W = W

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': b.prepare()
    elif action == 'freeze': b.freeze()
    elif action == 'preflight': b.validate()
    elif action == 'compile': b.compile_unit('tiny')
    elif action == 'parse-compile': b.parse_compile('tiny')
    elif action == 'link': b.link_unit('tiny')
    else: raise ValueError(action)
