"""Retain the six original consumers and parsers after a real source fix."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value
r = module('mtp_terminal_original_finite_runs', W.parent / 'validation/run.py')
build = module('mtp_terminal_fixed_build', W / 'build.py')
r.W = W; r.__file__ = __file__; r.b = build.b; r.t = build.b.t

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': r.prepare()
    elif action == 'run': r.run(sys.argv[2])
    elif action in ('parse', 'parse-only'): r.parse(sys.argv[2])
    else: raise ValueError(action)
