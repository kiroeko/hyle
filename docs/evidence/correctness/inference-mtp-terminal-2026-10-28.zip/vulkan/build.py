"""One current Tiny; reuse the repaired Vulkan program and current generic Graph OBJs."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path('C:/public/project-hyle/hyle')
OLD = R / '.scratch/inference-native-program-io-20261028/vulkan-current'
spec = importlib.util.spec_from_file_location('mtp_vulkan_original_family_build',
    R / '.scratch/inference-prepared-program-family-20261028/validation/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.W = W; b.__file__ = __file__; b.t.W = W
t = b.t
b.SNAPSHOTS = ('engine/models/qwen35/main.cc', 'engine/models/qwen35/generation_ledger.h',
    'engine/inference/sampling_graph.h', 'tests/tools/qwen_host_image_test.cc',
    'tests/tools/qwen_mtp_sampling_case.h', 'tests/tools/qwen_mtp_logits_case.h',
    'tests/tools/qwen_history_control_case.h', 'tests/tools/qwen_history_replay_case.h')


def prepare():
    assert not (W / 'final-build-plan.json').exists()
    ready = t.read(OLD / 'ready.json'); t.exact(ready['inputs'])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 169
    tiny = next(x for x in ready['retained_consumers'] if x['source']['path'].endswith('qwen_host_image_test.cc'))
    original = t.command(tiny['command']['path']); command = []
    for at, arg in enumerate(original):
        if t.key(arg) == t.key(tiny['source']['path']): arg = str(R / 'tests/tools/qwen_host_image_test.cc')
        elif at and original[at - 1].lower() == '/sourcedependencies': arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        command.append(arg)
    assert '/DHYLE_COMPUTE_VULKAN=1' in command and '/DHYLE_COMPUTE_CPU=1' in command
    assert not any('HYLE_COMPUTE_CUDA' in a or 'HYLE_COMPUTE_APPLE' in a for a in command)
    t.save(W / 'recipes/tiny.json', dict(command=command, timeout_seconds=300))
    replacements = []
    for name in ('resources', 'slots-region'):
        old = next(x for x in rows if 'inference-indexed-store-20261028' in x['path'] and
            ('compile\\' + name + '\\unit.obj') in x['path'])
        receipt = R / '.scratch/inference-store-cohort-20261028/compile' / name / 'compiled.json'
        current = t.read(receipt); t.exact(current['object']); t.exact(current['source'])
        assert current['process']['exit'] == 0 and not current['process']['timed_out']
        for pin in t.read(current['actual_dependencies']['path']):
            if t.project(pin['path']): t.exact(pin)
        replacements.append(dict(name=name, original=old, replacement=current['object'], receipt=t.pin(receipt)))
    mapping = {t.key(x['original']['path']): x['replacement']['path'] for x in replacements}
    mapping[t.key(tiny['object']['path'])] = str(W / 'compile/tiny/unit.obj')
    link = []
    for arg in t.command(OLD / 'recipe-link.json'):
        arg = mapping.get(t.key(arg), arg)
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    assert all(sum(t.key(a) == t.key(p) for a in link) == 1 for p in mapping.values())
    t.save(W / 'link-recipes/tiny.json', dict(command=link, timeout_seconds=240))
    stats = []
    for row in rows:
        if t.key(row['path']) in mapping: continue
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    assert len(stats) == 166
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(OLD / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    runtime = t.read(ready['runtime']['path']); runtime['PATH'] = env['PATH']; t.save(W / 'runtime.json', runtime)
    t.save(W / 'final-build-plan.json', dict(baseline=t.pin(OLD / 'ready.json'), inputs=ready['inputs'],
        original_object=tiny['object'], source_dependencies=tiny['dependencies'], sources=b.SOURCES,
        original_driver=t.pin(R / '.scratch/inference-indexed-store-20261028/build.py'),
        compile_template=tiny['command'], environment=t.pin(W / 'environment.json'),
        retained_stats=t.pin(W / 'retained-input-stats.json'), runtime=t.pin(W / 'runtime.json'),
        recipes={'tiny': t.pin(W / 'recipes/tiny.json')}, links={'tiny': t.pin(W / 'link-recipes/tiny.json')},
        cached_graph_replacements=replacements, current_vulkan_program=ready['compiled'][0],
        counts=dict(CXX=1, links=1, inputs=169, retained=166, cached_Graph_replacements=2, SDK_CXX=0, native=1, downloads=0),
        scope='Canonical current Tiny; only three roster entries change. The repaired Vulkan program and existing fixture remain unchanged. Freeze is a separate root action.'))
    print('PREPARED UNFROZEN: Vulkan Tiny1CXX/1link, Graph2 cached, 169inputs, no model run')


def link():
    plan, _ = b.validate(); compiled = t.read(W / 'compile/tiny/compiled.json'); t.exact(compiled['object'])
    mapping = {t.key(plan['original_object']['path']): compiled['object']}
    for row in plan['cached_graph_replacements']:
        t.exact(row['receipt']); t.exact(row['replacement']); mapping[t.key(row['original']['path'])] = row['replacement']
    rows = [mapping.get(t.key(row['path']), row) for row in t.read(plan['inputs']['path'])]
    assert len(rows) == 169 and sum(a != z for a, z in zip(rows, t.read(plan['inputs']['path']))) == 3
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns'])
    (W / 'bin').mkdir(exist_ok=True); native = t.read(plan['runtime']['path'])['native']; alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path']); t.save(W / 'inputs-tiny.json', rows)
    process = t.execute(t.command(plan['links']['tiny']['path']), W / 'links/tiny', 240)
    t.save(W / 'ready-tiny.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=t.pin(W / 'inputs-tiny.json'),
        compiled=compiled, cached_graph_replacements=plan['cached_graph_replacements'], process=process,
        recipe=t.pin(W / 'links/tiny/command.json'), runtime=plan['runtime'], source_freeze=t.pin(W / 'final-source-freeze.json')))
    print('LINK PASS Vulkan169')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': b.freeze()
    elif action == 'preflight': b.validate()
    elif action == 'compile': b.compile_unit('tiny')
    elif action == 'parse-compile': b.parse_compile('tiny')
    elif action == 'link': link()
    else: raise ValueError(action)
