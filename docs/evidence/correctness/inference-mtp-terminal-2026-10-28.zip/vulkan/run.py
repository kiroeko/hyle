"""One original Vulkan modifier process; parser repair remains offline."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
def module(name, path):
    s = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
current = module('mtp_terminal_vulkan_build', W / 'build.py')
f = module('mtp_terminal_original_six_runner', W.parent / 'validation/run.py')
b, t, R = current.b, current.t, current.R
f.W = W; f.b = b; f.t = t; t.W = W
f.ARMS = {'mods-vulkan': ('vulkan', 'modifiers', '--mtp-logits')}


def prepare():
    b.plan()
    t.save(W / 'test-source-pins.json', {path: t.pin(R / path) for path in current.b.SNAPSHOTS})
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', helper=t.pin(__file__),
        original_runner=t.pin(W.parent / 'validation/run.py'), fixture=t.pin(f.FIXTURE / 'weights.tsv'),
        runtime=t.pin(W / 'runtime.json'), test_source_pins=t.pin(W / 'test-source-pins.json'),
        parsers={name: t.pin(path) for name, path in f.PARSERS.items()},
        arms={'mods-vulkan': dict(backend='vulkan', flag='--mtp-logits')}, order=['mods-vulkan'], native_processes=1,
        automatic_retries=0, quality_claim=False, performance_claim=False))
    print('Vulkan one original modifier run planned only')


def run():
    b.validate(); plan = t.read(W / 'run-plan.json')
    for key in ('helper', 'fixture', 'runtime', 'test_source_pins', 'original_runner'): t.exact(plan[key])
    for pin in plan['parsers'].values(): t.exact(pin)
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image']); t.exact(ready['inputs'])
    native = t.read(ready['runtime']['path'])['native']
    assert (W / 'bin' / Path(native['path']).name).samefile(native['path'])
    out = W / 'runs/mods-vulkan'; assert not out.exists(), 'Preserve the first native attempt; parse separately'
    process = t.execute([ready['image']['path'], '--vulkan', str(f.FIXTURE), '--mtp-logits'], out, 300)
    t.save(out / 'as-run.json', dict(ready=t.pin(W / 'ready-tiny.json'), image=ready['image'], inputs=ready['inputs'],
        fixture=plan['fixture'], source_freeze=ready['source_freeze'], runtime=ready['runtime'],
        run_plan=t.pin(W / 'run-plan.json'), process=process))
    print('Native recorded; explicit parse-only is the next offline action')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run()
    elif action in ('parse', 'parse-only'): f.parse('mods-vulkan')
    else: raise ValueError(action)
