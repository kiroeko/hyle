#include <hyle/graph/vulkan.h>
#include <gtest/gtest.h>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <span>
#include <vector>

namespace {
namespace c=hyle::compute;
namespace v=c::vulkan;
namespace g=hyle::graph;
namespace gv=g::vulkan;
c::TensorDesc dense(c::DataType type,std::initializer_list<std::int64_t> shape) {
  return c::TensorDesc::dense(type,{shape.begin(),shape.size()}).value();
}
std::vector<float> read(const v::Context &context,const v::Tensor &tensor) {
  std::vector<float> values(tensor.description().required_bytes().value()/sizeof(float));
  EXPECT_TRUE(context.download(tensor,std::as_writable_bytes(std::span(values))).ok());
  return values;
}
hyle::Result<g::Graph> phase_graph(const c::TensorDesc &data,const c::TensorDesc &positions,const c::TensorDesc &frequencies) {
  HYLE_ASSIGN_OR_RETURN(auto b,g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto x,b.input(data));
  HYLE_ASSIGN_OR_RETURN(auto p,b.input(positions));
  HYLE_ASSIGN_OR_RETURN(auto f,b.input(frequencies));
  HYLE_ASSIGN_OR_RETURN(auto y,b.add(c::RoPE{.rotary_dimensions=64,.sequence_axis=1,.layout=c::RopeLayout::kInterleaved},x,p,f));
  HYLE_RETURN_IF_ERROR(b.publish(y));
  return std::move(b).finish();
}
TEST(Ce16PublicConsumer, DirectAndGraphPhaseAgainstComputedF32IndependentF64Oracle) {
  auto context=v::Context::create();ASSERT_TRUE(context)<<context.error().message();
  const std::array<std::int32_t,18> positions{-1048576,-131071,-65536,-2303,-2055,-127,-1,0,1,127,2052,2055,2303,65536,131071,262144,1048575,1048576};
  const auto desc=dense(c::DataType::kFloat32,{1,std::int64_t(positions.size()),3,64});
  const auto pd=dense(c::DataType::kInt32,{std::int64_t(positions.size())});
  const auto fd=dense(c::DataType::kFloat32,{32});
  std::array<float,32> frequencies{};
  for(std::size_t i=0;i<frequencies.size();++i)frequencies[i]=float(std::pow(10000.0,-double(i)/32));
  frequencies[1]=float(std::acos(-1.0)/1024);frequencies[2]=-.75F;frequencies[3]=0;frequencies[4]=-1;
  auto p=context->upload(pd,std::as_bytes(std::span(positions)));ASSERT_TRUE(p)<<p.error().message();
  auto f=context->upload(fd,std::as_bytes(std::span(frequencies)));ASSERT_TRUE(f)<<f.error().message();
  auto direct=v::prepare(*context,c::RoPE{.rotary_dimensions=64,.sequence_axis=1,.layout=c::RopeLayout::kInterleaved},desc,pd,fd);ASSERT_TRUE(direct)<<direct.error().message();
  auto graph=phase_graph(desc,pd,fd);ASSERT_TRUE(graph)<<graph.error().message();
  auto compiled=gv::compile(*context,*graph,{});ASSERT_TRUE(compiled)<<compiled.error().message();
  std::vector<v::Tensor> retained;std::vector<std::vector<float>> saved;
  for(int replay=0;replay<2;++replay) {
    auto ds=direct->create_invocation();ASSERT_TRUE(ds)<<ds.error().message();
    auto gs=compiled->create_invocation();ASSERT_TRUE(gs)<<gs.error().message();
    std::vector<float> host(positions.size()*3*64);
    for(std::size_t i=0;i<host.size();++i)host[i]=float(int((i+std::size_t(replay)*7)%23)-11)/16;
    auto x=context->upload(desc,std::as_bytes(std::span(host)));ASSERT_TRUE(x)<<x.error().message();
    const std::array inputs{*x,*p,*f};ASSERT_TRUE(ds->bind(inputs).ok());ASSERT_TRUE(gs->bind(inputs).ok());
    auto dw=ds->submit();ASSERT_TRUE(dw)<<dw.error().message();auto dr=dw->wait();ASSERT_TRUE(dr)<<dr.error().message();
    auto gw=gs->submit();ASSERT_TRUE(gw)<<gw.error().message();auto gr=gw->wait();ASSERT_TRUE(gr)<<gr.error().message();
    for(const auto &tensor:{dr->get()->tensors()[0],gr->get()->tensors()[0]}) {
      auto actual=read(*context,tensor);ASSERT_EQ(actual.size(),host.size());
      for(std::size_t row=0;row<positions.size();++row)for(std::size_t head=0;head<3;++head)for(std::size_t pair=0;pair<32;++pair) {
        const float phase=float(positions[row])*frequencies[pair];const auto offset=(row*3+head)*64+pair*2;
        const double a=host[offset],b=host[offset+1],cs=std::cos(double(phase)),sn=std::sin(double(phase));
        EXPECT_NEAR(actual[offset],a*cs-b*sn,4e-6);EXPECT_NEAR(actual[offset+1],a*sn+b*cs,4e-6);
      }
      retained.push_back(tensor);saved.push_back(std::move(actual));
    }
  }
  ASSERT_TRUE(context->close().ok());
  for(std::size_t i=0;i<retained.size();++i)EXPECT_EQ(read(*context,retained[i]),saved[i]);
}
TEST(Ce16PublicConsumer, PublishedDenseAliasesReplayAndRetainResults) {
  auto context=v::Context::create();ASSERT_TRUE(context)<<context.error().message();
  const auto desc=dense(c::DataType::kFloat32,{2,4});
  auto b=g::GraphBuilder::create();ASSERT_TRUE(b);auto x=b->input(desc);ASSERT_TRUE(x);
  auto negative=b->add(c::Unary{c::UnaryKind::kNeg},*x);ASSERT_TRUE(negative);
  const auto flat=c::View::reshape(c::TensorShape::create(std::array<std::int64_t,1>{8}).value()).value();
  const auto row=c::View::reshape(c::TensorShape::create(std::array<std::int64_t,2>{1,8}).value()).value();
  auto y=b->add(flat,*negative);ASSERT_TRUE(y);auto z=b->add(row,*negative);ASSERT_TRUE(z);
  ASSERT_TRUE(b->publish(*negative).ok());ASSERT_TRUE(b->publish(*y).ok());ASSERT_TRUE(b->publish(*z).ok());
  auto graph=std::move(*b).finish();ASSERT_TRUE(graph);auto program=gv::compile(*context,*graph,{});ASSERT_TRUE(program)<<program.error().message();
  auto first=program->create_invocation();auto second=program->create_invocation();ASSERT_TRUE(first&&second);
  std::vector<v::Tensor> retained;std::vector<std::vector<float>> saved;
  for(int replay=0;replay<4;++replay) {
    std::array<float,8> host{};for(std::size_t i=0;i<host.size();++i)host[i]=float(i)+.5F+float(replay*16);
    auto input=context->upload(desc,std::as_bytes(std::span(host)));ASSERT_TRUE(input);
    auto &slot=replay==0?*first:*second;ASSERT_TRUE(slot.bind(*input).ok());auto work=slot.submit();ASSERT_TRUE(work);auto result=work->wait();ASSERT_TRUE(result)<<result.error().message();
    const auto outputs=result->get()->tensors();ASSERT_EQ(outputs.size(),3U);
    for(const auto &tensor:outputs) {
      auto actual=read(*context,tensor);ASSERT_EQ(actual.size(),host.size());for(std::size_t i=0;i<actual.size();++i)EXPECT_EQ(actual[i],-host[i]);
      if(replay==0){retained.push_back(tensor);saved.push_back(std::move(actual));}
    }
    EXPECT_EQ(read(*context,*input),std::vector<float>(host.begin(),host.end()));
  }
  ASSERT_TRUE(context->close().ok());
  for(std::size_t i=0;i<retained.size();++i)EXPECT_EQ(read(*context,retained[i]),saved[i]);
}
}
