from pathlib import Path
import hashlib,json,subprocess,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified/g02-ce16-air')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results={}
for mode in ('source','static','shared'):
 folder=base/mode;r=json.loads((folder/'result.json').read_text());assert r['state']=='TERMINAL_FINITE_PASS';results[mode]=r
 artifact_paths=[]
 if mode!='source':artifact_paths=[p for p in (folder/'relocated').rglob('*') if p.is_file()]
 else:
  build=Path(json.loads((base/'snapshot.json').read_text())['trees'][mode]['build'])
  artifact_paths=[p for p in (build/'hyle').rglob('*') if p.is_file() and (p.name.startswith('libhyle') or p.name.startswith('libggml')) and p.suffix in ('.a','.dylib')]
 (folder/'shipping-artifacts.json').write_text(json.dumps([{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(artifact_paths)],indent=2)+'\n')
 binary=Path(r['stages'][-2 if mode=='source' else -1]['command'][0])
 (folder/'otool-linked-libraries.log').write_text(subprocess.check_output(['otool','-L',str(binary)],text=True))
with zipfile.ZipFile(base/'source.zip') as z:(base/'source-manifest.json').write_bytes(z.read('source-manifest.json'))
count=0
with zipfile.ZipFile(base/'qualification-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ('snapshot.json','source-manifest.json','consumer.cc','ce16_air_snapshot.py','ce16_air_verify.py','collect_ce16_air.py'):
  z.write(base/name,name);count+=1
 for mode in ('source','static','shared'):
  folder=base/mode
  for p in sorted(folder.iterdir()):
   if p.is_file() and p.suffix in ('.json','.log','.xml','.py','.ninja','.cmake'):
    z.write(p,p.relative_to(base).as_posix());count+=1
  consumer=folder/'consumer'
  if consumer.is_dir():
   for p in consumer.iterdir():
    if p.is_file():z.write(p,p.relative_to(base).as_posix());count+=1
receipt={'kind':'CE15_CE16_ACTUAL_AIR_THREE_DELIVERIES','verdict':'PASS_FINITE_SOURCE_STATIC_SHARED','results':results,'raw_entries':count,'raw_zip_sha256':sha(base/'qualification-raw.zip'),'source_snapshot':json.loads((base/'snapshot.json').read_text()),'scope':'PublicDirect+Graph18-position independentF64phase4e-6/two replays and publisheddensealias4replays/oldresults/close in all3deliveries; source additionally private independentportalias +metadata3 failure/move/cleanup. No P1/wholeG02 automatic verdict.','failure_history':'First source build post-generation SHA check caught obsolete reused unary object before tests. Actual elapsed in attempt1record, thenonly changedgeneratedunary CXX rebound, allother provenobjects retained. No firstattempt testsPASS claimed; all logs/proofs/time archived.'}
(base/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('qualification collected',count,sha(base/'qualification-raw.zip'))
