from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,xml.etree.ElementTree as ET

mode=sys.argv[1];assert mode in ('source','static','shared')
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g02-ce16-air';folder=out/mode;source=base/'source-c8874688'
snapshot=json.loads((out/'snapshot.json').read_text());build=Path(snapshot['trees'][mode]['build']);assert not (folder/'result.json').exists()
identity={k:subprocess.check_output(a,text=True).strip() for k,a in [('model',['/usr/sbin/sysctl','-n','hw.model']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]}
assert identity==snapshot['identity'] and identity['model']=='Mac16,12'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
cmake='/opt/homebrew/bin/cmake';ninja='/opt/homebrew/bin/ninja'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'state':'SETUP','mode':mode,'identity':identity,'canonical_head':snapshot['canonical_head'],'product_candidate':'2b60d9a34be12fda9a9e3fdc26f7a61b495c3be7','stages':[],'scope':'Finite CE15/16 actual Air public phase+alias journeys in source/static/shared. Source additionally actual private alias regression and metadata failure/move/cleanup. No original851, P1 or wholeG02 verdict.','max_jobs':4}
def save():(folder/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();(folder/'runner.py').write_bytes(Path(__file__).read_bytes())
def run(stage,args):
 t=time.monotonic()
 with (folder/(stage+'.log')).open('w') as stream:
  child=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT);record.update(state='RUNNING',stage=stage,pid=child.pid);save();print(mode,stage,child.pid,flush=True);code=child.wait()
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-t});save()
 if code:record['state']='TERMINAL_FAIL';save();print((folder/(stage+'.log')).read_text(errors='replace')[-4000:],flush=True);raise SystemExit(code)
def xml_pass(p,count):
 t=ET.parse(p).getroot();assert t.attrib['tests']==str(count) and t.attrib['failures']=='0' and t.attrib['errors']=='0' and not t.findall('.//skipped')
def blocks(text):
 lines=text.splitlines(keepends=True);i=0;rows=[]
 while i<len(lines):
  if lines[i].startswith('build '):
   start=i;i+=1
   while i<len(lines) and (not lines[i].strip() or lines[i].startswith((' ','\t'))):i+=1
   rows.append((start,i,''.join(lines[start:i])))
  else:i+=1
 return lines,rows
if mode=='source':
 parent=build.parent/'source-parent';p=parent/'CMakeLists.txt';text=p.read_text();assert 'add_executable(ce16_public ' not in text
 text+=f'''
if(NOT TARGET GTest::gtest_main)
 add_subdirectory("/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6" ce16_gtest EXCLUDE_FROM_ALL)
endif()
add_executable(ce16_public "{out}/consumer.cc")
target_compile_features(ce16_public PRIVATE cxx_std_23)
target_compile_options(ce16_public PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_link_libraries(ce16_public PRIVATE hyle::graph GTest::gtest_main)
hyle_stage_runtime(ce16_public)
add_executable(ce16_provider "{source}/tests/compute_provider_ggml_vulkan/region_test.cc" "{source}/tests/compute_provider_ggml_vulkan/metadata_test.cc")
target_compile_features(ce16_provider PRIVATE cxx_std_23)
target_compile_options(ce16_provider PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_include_directories(ce16_provider PRIVATE "{source}/src/compute_provider_ggml_vulkan")
target_link_libraries(ce16_provider PRIVATE hyle_compute_provider_ggml_vulkan ggml Vulkan-Headers hyle_compute_ggml_runtime hyle_compute_ops hyle_mem hyle_error hyle_platform GTest::gtest_main)
hyle_stage_runtime(ce16_provider)
'''
 p.write_text(text);(folder/'source-parent.cmake').write_text(text)
 run('configure',[cmake,'-S',str(parent),'-B',str(build),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 targets=['ce16_public','ce16_provider']
else:
 run('configure',[cmake,'-S',str(source),'-B',str(build),'-UCMAKE_PROJECT_INCLUDE','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TESTING=OFF','-DHYLE_INSTALL=ON','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 targets=['hyle_compute','hyle_compute_batch','hyle_graph','hyle_graph_batch','hyle_graph_route_cpu_vulkan','hyle_compute_route_vulkan','hyle_graph_route_vulkan']
text=(build/'build.ninja').read_text();text,n=re.subn(r'^build [^\n]*: RERUN_CMAKE[^\n]*\n(?:[ \t][^\n]*\n|\n)*','',text,flags=re.M);assert n==1
(folder/'normal-frozen-build.ninja').write_text(text)
old=json.loads((folder/'before-native-objects.json').read_text());by_name={str(Path(r['output']).relative_to(build)):r for r in old};lines,rows=blocks(text);reuse=[];post={};replacements={};not_reused=[]
def normalize(s):return re.sub(r'source-[0-9a-f]{16}','NATIVE_SOURCE',s)
for start,end,block in rows:
 first=block.splitlines()[0]
 if not re.search(r': (?:CXX|C)_COMPILER',first) or 'compute_ggml_runtime' not in first:continue
 name=first.split(': ',1)[0][6:];prior=by_name.get(name)
 if not prior or not prior['proven_old_inputs'] or normalize(prior['block'])!=normalize(block):not_reused.append({'output':name,'reason':'No exact old compiler/dependency proof'});continue
 old_tags=re.findall(r'source-[0-9a-f]{16}',prior['block']);new_tags=re.findall(r'source-[0-9a-f]{16}',block)
 if old_tags and (len(set(old_tags))!=1 or len(set(new_tags))!=1):not_reused.append({'output':name,'reason':'Multiple native source identities'});continue
 mapping=(old_tags[0],new_tags[0]) if old_tags else None
 current_inputs=[];valid=True
 for dep in prior['inputs']:
  p=Path(dep['path'].replace(mapping[0],mapping[1])) if mapping else Path(dep['path'])
  if not p.is_file() or sha(p)!=dep['sha256']:valid=False;break
  current_inputs.append({'path':str(p),'sha256':dep['sha256']})
 if not valid:not_reused.append({'output':name,'reason':'Actual dependency changed'});continue
 p=Path(prior['output']);assert sha(p)==prior['sha256']
 replacements[start]=(end,f'build {name}: phony\n\n');reuse.append({'output':str(p),'sha256':prior['sha256'],'inputs':current_inputs})
 for dep in current_inputs:
  p=Path(dep['path'])
  if p.is_relative_to(build) and 'ggml-vulkan' in str(p):post[str(p)]=dep['sha256']
for start,(end,replacement) in sorted(replacements.items(),reverse=True):lines[start:end]=[replacement]
manifest=folder/'reuse-build.ninja';manifest.write_text(''.join(lines));proof={'reused':reuse,'not_reused':not_reused,'post_build_inputs':post,'normal_manifest_sha256':sha(folder/'normal-frozen-build.ninja'),'reused_manifest_sha256':sha(manifest)}
(folder/'native-reuse.json').write_text(json.dumps(proof,indent=2)+'\n')
run('dry-plan',[ninja,'-C',str(build),'-f',str(manifest),'-n',*targets]);plan=(folder/'dry-plan.log').read_text();assert 'Building CUDA object' not in plan
run('build',[ninja,'-C',str(build),'-f',str(manifest),'-j','4','-k','0',*targets])
for row in reuse:assert sha(Path(row['output']))==row['sha256']
for path,digest in post.items():assert sha(Path(path))==digest,'Generated dependency changed; rebuild affected native object before qualification: '+path
record['native_objects_reused_unchanged']=len(reuse);record['post_build_inputs_checked']=len(post);save()
if mode=='source':
 binary=build/'ce16_public';run('public-tests',[str(binary),'--gtest_output=xml:'+str(folder/'public.xml')]);xml_pass(folder/'public.xml',2)
 run('provider-risk',[str(build/'ce16_provider'),'--gtest_filter=GgmlVulkanRegion.PublishedReshapesBindIndependentInputAndOutputStorage:GgmlVulkanMetadata.*','--gtest_output=xml:'+str(folder/'provider.xml')]);xml_pass(folder/'provider.xml',4)
else:
 staging=folder/'staging';prefix=folder/'relocated';run('install',[cmake,'--install',str(build),'--prefix',str(staging)]);staging.rename(prefix)
 consumer=folder/'consumer';consumer.mkdir();(consumer/'consumer.cc').write_bytes((out/'consumer.cc').read_bytes())
 (consumer/'CMakeLists.txt').write_text(f'''cmake_minimum_required(VERSION 3.25)
project(ce16_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory("/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6" gtest EXCLUDE_FROM_ALL)
add_executable(consumer consumer.cc)
target_compile_features(consumer PRIVATE cxx_std_23)
target_compile_options(consumer PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_link_libraries(consumer PRIVATE hyle::graph GTest::gtest_main)
hyle_stage_runtime(consumer)
''')
 cb=folder/'consumer-build';run('consumer-configure',[cmake,'-S',str(consumer),'-B',str(cb),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']);run('consumer-build',[cmake,'--build',str(cb),'--target','consumer','--parallel','4'])
 commands=json.loads((cb/'compile_commands.json').read_text());actual=[r for r in commands if r['file']==str(consumer/'consumer.cc')];assert len(actual)==1 and str(source) not in actual[0]['command'] and str(build) not in actual[0]['command'] and str(prefix/'include') in actual[0]['command'];(folder/'consumer-command.json').write_text(json.dumps(actual,indent=2)+'\n')
 binary=cb/'consumer';run('public-tests',[str(binary),'--gtest_output=xml:'+str(folder/'public.xml')]);xml_pass(folder/'public.xml',2)
 record['prefix']=str(prefix)
record.update(state='TERMINAL_FINITE_PASS',public_consumer_sha256=sha(out/'consumer.cc'),binary_sha256=sha(binary));save();print(mode,'FINITE_PASS',flush=True)
