from pathlib import Path
import hashlib,json,os,re,subprocess,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g02-ce16-air';source=base/'source-c8874688'
assert out.is_dir() and not (out/'snapshot.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
identity={k:subprocess.check_output(args,text=True).strip() for k,args in [('model',['/usr/sbin/sysctl','-n','hw.model']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]}
assert identity['model']=='Mac16,12'
env=os.environ.copy();env['PATH']='/opt/homebrew/bin:'+env['PATH']
def blocks(s):
 lines=s.splitlines(keepends=True);result={};i=0
 while i<len(lines):
  if lines[i].startswith('build '):
   start=i;i+=1
   while i<len(lines) and (not lines[i].strip() or lines[i].startswith((' ','\t'))):i+=1
   block=''.join(lines[start:i])
   if re.search(r': (?:CXX|C)_COMPILER',lines[start]) and 'compute_ggml_runtime' in lines[start]:result[lines[start].split(': ',1)[0][6:]]=block
  else:i+=1
 return result
record={'state':'PREPARE_ONLY_NO_CONFIGURE_BUILD_OR_GPU','identity':identity,'source':str(source),'trees':{}}
for mode in ('source','static','shared'):
 build=base/'a-cpu-vulkan/selected-graph'/('source-build' if mode=='source' else mode+'-sdk-build');folder=out/mode;folder.mkdir(exist_ok=False)
 text=(build/'build.ninja').read_text();(folder/'before-build.ninja').write_text(text)
 raw=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','deps'],env=env,text=True);(folder/'before-dependencies.log').write_text(raw)
 deps={};key=None
 for line in raw.splitlines():
  if line and not line.startswith(' '):key=line.split(': #deps ',1)[0];deps[key]=[]
  elif line.startswith('    ') and key:deps[key].append(line.strip())
 rows=[]
 for name,block in blocks(text).items():
  p=build/name
  if not p.is_file():continue
  paths=deps.get(name,[]);inputs=[];valid=bool(paths)
  for rawpath in paths:
   f=Path(rawpath);f=f if f.is_absolute() else build/f
   if not f.is_file() or f.stat().st_mtime_ns>p.stat().st_mtime_ns:valid=False;break
   inputs.append({'path':str(f),'sha256':sha(f)})
  rows.append({'output':str(p),'sha256':sha(p),'block':block,'proven_old_inputs':valid,'inputs':inputs})
 (folder/'before-native-objects.json').write_text(json.dumps(rows,indent=2)+'\n')
 record['trees'][mode]={'build':str(build),'old_native_objects':len(rows),'objects_with_proven_dependencies':sum(x['proven_old_inputs'] for x in rows),'snapshot_sha256':sha(folder/'before-native-objects.json')}
 print('snapshotted',mode,record['trees'][mode],flush=True)
with zipfile.ZipFile(out/'source.zip') as z:
 manifest=json.loads(z.read('source-manifest.json'));written=0
 for row in manifest['files']:
  p=Path(row['path']);assert not p.is_absolute() and '..' not in p.parts
  raw=z.read(row['path']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];destination=source/p
  if not destination.is_file() or destination.read_bytes()!=raw:destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw);written+=1
record.update(canonical_head=manifest['head'],manifest_files=len(manifest['files']),files_updated=written,source_archive_sha256=sha(out/'source.zip'),public_consumer_sha256=sha(out/'consumer.cc'))
(out/'snapshot.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
