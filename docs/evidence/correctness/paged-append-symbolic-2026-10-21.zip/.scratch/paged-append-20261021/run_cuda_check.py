"""Root's single real CUDA permission journey; no timing evidence."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
P = Path(__file__).resolve().parent
R = P.parents[1]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p, data): p.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
ready = read(P / 'cuda-ready-for-root.json')
image = ready['image']
assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
out = P / 'cuda-run1'
out.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env['PATH'] = read(Path(ready['runtime_environment']['path']))['PATH']
record = dict(command=[image['path']], cwd=str(R), image=image, source=ready['source'],
              throughput_evidence=False, hardware_scope='Actual shared CUDA Context created by consumer',
              started_unix_ns=time.time_ns())
save(out / 'command.json', record)
process = None
with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
    try:
        process = subprocess.Popen(record['command'], cwd=R, env=env, stdout=so, stderr=se,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = process.pid
        try: record['exit'] = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['timeout'] = True
            process.kill()
            record['exit'] = process.wait()
    finally:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        record['finished_unix_ns'] = time.time_ns()
        save(out / 'result.json', record)
print((out / 'stdout.log').read_text(encoding='utf-8', errors='replace'))
print((out / 'stderr.log').read_text(encoding='utf-8', errors='replace'))
assert record.get('exit') == 0 and not record.get('timeout'), 'CUDA consumer failed; raw logs preserved'
