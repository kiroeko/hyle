"""Single real-model regression after linking the changed common Graph core."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
R = P.parents[1]
S = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
spec = importlib.util.spec_from_file_location('isolation', S / 'run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
plan = m.read(S / 'inputs/plan.json')
baseline = R / '.scratch/multi-session-20261021/attempt2/baseline'
out = P / 'final-qwen-run1'
observed = h.run(out, P / 'final-qwen-ready.json', [
    '--session-schedules', plan['manifests']['4']['manifest']['path'],
    '--max-sessions', '2', '--active-sequences', '2', '--cache-bytes', str(4 * 42_221_568)])
summary = dict(passed=False, throughput_evidence=False, runner=m.identity(__file__),
               helper=m.identity(S / 'run.py'), ready=m.identity(P / 'final-qwen-ready.json'),
               sessions={}, scope='Common-core integration; Qwen retains existing dense Scatter/Ragged math, not paged/prefix inference.')
m.save(out / 'summary.json', summary)
assert observed['execution'] == 'turn_round_robin_serial'
assert observed['session_count'] == 4 and observed['generated_tokens'] == 36
assert observed['processed_tokens'] == 239 and observed['active_sequences'] == 2
assert observed['cache_retained_sessions'] == 2
assert observed['cache_state_bytes_per_session'] == 42_221_568
assert observed['cache_live_requested_bytes'] == observed['cache_peak_requested_bytes'] == 84_443_136
assert observed['evicted_session_ids'] == ['bob', 'alice', 'carol', 'dave', 'alice', 'bob']
assert sum(s['restored_calls'] for s in observed['sessions']) == 18
assert sum(s['restored_tokens'] for s in observed['sessions']) == 185
for session in observed['sessions']:
    sid = session['session_id']
    h.check_session(session, plan['cases'][sid])
    prior = m.read(baseline / sid / 'observation.json')
    assert session['generated_ids'] == prior['generated_ids']
    assert session['cache_hits'] == 0 and session['cache_misses'] == 2
    pairs = h.check_vectors(baseline / sid / 'trace', out / 'trace' / session['trace_subdirectory'],
                           plan['cases'][sid]['calls'])
    summary['sessions'][sid] = dict(vectors=pairs, passed=all(p['byte_equal'] for p in pairs),
                                  restored_calls=session['restored_calls'], restored_tokens=session['restored_tokens'])
summary['vector_count'] = sum(len(s['vectors']) for s in summary['sessions'].values())
summary['passed'] = summary['vector_count'] == 72 and all(s['passed'] for s in summary['sessions'].values())
summary['observed_evictions'] = observed['evicted_session_ids']
summary['cache_peak_requested_bytes'] = observed['cache_peak_requested_bytes']
m.save(out / 'summary.json', summary)
assert summary['passed'], 'Final linked core changed decision bytes; raw payloads retained'
print('Final common core: four sessions, count-bound retirement/rebuild, 72 decision vectors byte-identical.', flush=True)
