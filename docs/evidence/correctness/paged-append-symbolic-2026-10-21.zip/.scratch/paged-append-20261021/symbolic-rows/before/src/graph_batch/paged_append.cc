#include "paged_append.h"
#include "hyle/compute/detail/paged_arena_access.h"
#include "hyle/compute/transfer.h"
#include "hyle/mem/std_allocator.h"
#include <algorithm>
#include <array>
#include <utility>
#include <vector>

namespace hyle::graph::batch {
namespace c=compute;namespace cd=c::detail;namespace gd=graph::detail;
namespace {
Result<c::TensorDesc> row_description(const PagedAppend&op)noexcept{
  if(!op.schema.valid() || op.schema.capacity().storage!=c::BatchStorage::kPaged ||
      op.role==c::BatchCacheRole::kRow || !op.rows || op.rows>op.schema.capacity().max_query_rows ||
      ((op.schema.mla_layout()!=c::MlaCacheLayout::kNone)!=(op.role==c::BatchCacheRole::kMla)))
    return std::unexpected(Status::InvalidArgument("paged append needs its paged schema/role/active rows"));
  const auto cap=op.schema.capacity();const auto storage=op.role==c::BatchCacheRole::kValue?cap.value_storage:cap.key_storage;
  if(storage.data_type()!=c::DataType::kFloat16 && storage.data_type()!=c::DataType::kBFloat16)
    return std::unexpected(Status::Unimplemented("paged append currently copies plain F16/BF16 rows"));
  return c::TensorDesc::dense(storage.data_type(),std::array<std::int64_t,3>{op.rows,cap.kv_heads,
      op.role==c::BatchCacheRole::kValue?cap.value_head_dim:cap.qk_head_dim});
}
std::uint32_t history(c::HostBatchLayout h,std::uint32_t request,std::uint32_t page_size)noexcept{
  const auto pages=std::uint32_t(h.kv_indptr[request+1]-h.kv_indptr[request]);
  return pages?(pages-1)*page_size+std::uint32_t(h.last_page_lengths[request]):0;
}
}
Status PagedAppend::infer_output_descriptions(std::span<const c::TensorDesc>inputs,std::span<c::TensorDesc>outputs)const noexcept{
  HYLE_ASSIGN_OR_RETURN(auto expected,row_description(*this));
  if(inputs.size()!=1 || inputs[0]!=expected || !outputs.empty())return Status::InvalidArgument("paged append needs exact packed new rows and no tensor output");
  return Status::Ok();
}
Result<PagedAppend> paged_append(c::BatchSchema schema,c::BatchCacheRole role,std::uint32_t rows)noexcept{
  PagedAppend result{std::move(schema),role,rows};HYLE_ASSIGN_OR_RETURN(auto expected,row_description(result));(void)expected;return result;
}
namespace detail {
struct PagedAppendData final {
  struct Range final {std::size_t writer=0,destination=0,source=0,bytes=0;bool prefix=false;};
  explicit PagedAppendData(mem::AllocatorRef a):allocator(a),writers(mem::StdAllocator<c::PagedPageWriter>(a)),
      ranges(mem::StdAllocator<Range>(a)),ready_pages(mem::StdAllocator<c::ReadLease>(a)),
      final_pages(mem::StdAllocator<std::uint32_t>(a)),required(mem::StdAllocator<std::uint32_t>(a)),
      writer_ptrs(mem::StdAllocator<const c::WriteLease*>(a)),targets(mem::StdAllocator<mem::BufferView>(a)){}
  void destroy()noexcept{const auto a=allocator;a.destroy(this);}
  mem::AllocatorRef allocator;c::PagedArena arena;c::BatchLayoutVersion layout;c::PagedArenaRead previous,result;
  PagedAppend descriptor;c::TensorDesc rows;std::size_t row_bytes=0;
  std::vector<c::PagedPageWriter,mem::StdAllocator<c::PagedPageWriter>>writers;
  std::vector<Range,mem::StdAllocator<Range>>ranges;
  std::vector<c::ReadLease,mem::StdAllocator<c::ReadLease>>ready_pages;
  std::vector<std::uint32_t,mem::StdAllocator<std::uint32_t>>final_pages,required;
  std::vector<const c::WriteLease*,mem::StdAllocator<const c::WriteLease*>>writer_ptrs;
  std::vector<mem::BufferView,mem::StdAllocator<mem::BufferView>>targets;
  bool successful=false;
};
}
PagedAppendPages::PagedAppendPages(PagedAppendPages&&other)noexcept:data_(std::exchange(other.data_,nullptr)){}
PagedAppendPages&PagedAppendPages::operator=(PagedAppendPages&&other)noexcept{if(this!=&other){PagedAppendPages next(std::move(other));std::swap(data_,next.data_);}return *this;}
PagedAppendPages::~PagedAppendPages(){if(data_)data_->destroy();}
c::BatchLayoutVersion PagedAppendPages::layout()const noexcept{return data_?data_->layout:c::BatchLayoutVersion{};}
std::size_t PagedAppendPages::page_count()const noexcept{return data_?data_->writers.size():0;}
Result<c::PagedPageWriter&> PagedAppendPages::page(std::size_t index)noexcept{
  if(!data_ || index>=data_->writers.size())return std::unexpected(Status::OutOfRange("paged append dirty page index"));return data_->writers[index];
}
Result<PagedAppendPages> PagedAppendPages::create(c::PagedArena arena,c::BatchLayoutVersion next,
    c::PagedArenaRead previous,std::span<c::PagedPageWriter>dirty,PagedAppendOptions options)noexcept{
  if(!arena.valid() || !next.valid() || !previous.valid() || !cd::PagedArenaAccess::owns(arena,previous) ||
      !cd::PagedArenaAccess::schema(arena).owns(next) || dirty.empty() || !options.allocator.valid())
    return std::unexpected(Status::InvalidArgument("paged append requires original arena, old frame, next layout and dirty pages"));
  auto allocator=options.allocator;if(options.resource_budget.valid()){HYLE_ASSIGN_OR_RETURN(allocator,options.resource_budget.metadata_allocator());}
  auto*p=allocator.construct<detail::PagedAppendData>(allocator);if(!p)return std::unexpected(Status::ResourceExhausted("paged append owner metadata"));
  PagedAppendPages result(p);p->arena=std::move(arena);p->layout=std::move(next);p->previous=std::move(previous);
  HYLE_ASSIGN_OR_RETURN(p->descriptor,paged_append(p->layout.schema(),cd::PagedArenaAccess::role(p->arena),p->layout.facts().query_rows));
  HYLE_ASSIGN_OR_RETURN(p->rows,row_description(p->descriptor));HYLE_ASSIGN_OR_RETURN(auto row_bytes,p->rows.required_bytes());p->row_bytes=row_bytes/p->descriptor.rows;
  const auto cap=p->layout.schema().capacity();const auto old=p->previous.layout();
  if(!p->layout.schema().owns(old) || old.facts().requests!=p->layout.facts().requests)
    return std::unexpected(Status::InvalidArgument("paged append old/new request domains differ"));
  try{
    p->writers.reserve(dirty.size());p->writer_ptrs.reserve(dirty.size());p->required.resize(dirty.size());p->targets.reserve(dirty.size());
    p->ranges.reserve(std::size_t(p->descriptor.rows)+dirty.size());p->final_pages.reserve(p->layout.facts().page_refs);
    p->ready_pages.reserve(p->layout.facts().page_refs);
    std::vector<cd::ArenaPageWrite,mem::StdAllocator<cd::ArenaPageWrite>>facts{mem::StdAllocator<cd::ArenaPageWrite>(allocator)};facts.reserve(dirty.size());
    for(std::size_t i=0;i<dirty.size();++i){HYLE_ASSIGN_OR_RETURN(auto fact,cd::PagedArenaAccess::writer(p->arena,dirty[i]));
      if(std::any_of(facts.begin(),facts.end(),[&](const auto&other){return fact.page==other.page || fact.root==other.root;}))
        return std::unexpected(Status::InvalidArgument("paged append repeats a dirty original page"));facts.push_back(fact);}
    const auto old_pages=cd::PagedArenaAccess::pages(p->previous);const auto before=old.host(),after=p->layout.host();
    const auto writer_index=[&](std::uint32_t page)->std::size_t{const auto found=std::find_if(facts.begin(),facts.end(),[&](const auto&fact){return fact.page==page;});return std::size_t(found-facts.begin());};
    const auto old_page=[&](std::uint32_t page)->Result<c::ReadLease>{for(const auto&lease:old_pages){HYLE_ASSIGN_OR_RETURN(auto id,cd::PagedArenaAccess::page(p->arena,lease));if(id==page)return lease;}return std::unexpected(Status::InvalidArgument("paged append prefix page is absent"));};
    for(std::uint32_t request=0;request<p->layout.facts().requests;++request){
      const auto previous_rows=history(before,request,cap.page_size),next_rows=history(after,request,cap.page_size);
      const auto rows=std::uint32_t(after.query_indptr[request+1]-after.query_indptr[request]);
      if(std::uint64_t(previous_rows)+rows!=next_rows)return std::unexpected(Status::InvalidArgument("paged append must extend each request by its packed query rows"));
      const auto pages=std::uint32_t(after.kv_indptr[request+1]-after.kv_indptr[request]);
      for(std::uint32_t logical=0;logical<pages;++logical){
        const auto physical=std::uint32_t(after.page_indices[std::size_t(after.kv_indptr[request])+logical]);
        if(std::find(p->final_pages.begin(),p->final_pages.end(),physical)==p->final_pages.end())p->final_pages.push_back(physical);
        const auto begin=logical*cap.page_size,end=std::min(next_rows,begin+cap.page_size);
        const auto inherited=previous_rows>begin?std::min(previous_rows-begin,cap.page_size):0;
        const auto index=writer_index(physical);
        if(end>previous_rows && end>begin && rows){
          if(index==facts.size())return std::unexpected(Status::InvalidArgument("paged append has no writer for new rows"));
          if(p->required[index])return std::unexpected(Status::InvalidArgument("paged append dirty page is shared across requests"));
          p->required[index]=end-begin;
          if(inherited){
            const auto source_page=std::uint32_t(before.page_indices[std::size_t(before.kv_indptr[request])+logical]);
            if(source_page==physical)return std::unexpected(Status::InvalidArgument("retained prefix must use a distinct dirty COW page"));
            HYLE_ASSIGN_OR_RETURN(auto source,old_page(source_page));
            std::size_t ordinal=0;for(;ordinal<old_pages.size();++ordinal){HYLE_ASSIGN_OR_RETURN(auto source_id,cd::PagedArenaAccess::page(p->arena,old_pages[ordinal]));if(source_id==source_page)break;}
            (void)source;p->ranges.push_back({index,0,ordinal,std::size_t(inherited)*p->row_bytes,true});
          }
          const auto new_begin=std::max(begin,previous_rows);
          p->ranges.push_back({index,std::size_t(new_begin-begin)*p->row_bytes,
            std::size_t(std::uint32_t(after.query_indptr[request])+new_begin-previous_rows)*p->row_bytes,
            std::size_t(end-new_begin)*p->row_bytes,false});
        }else{
          if(index!=facts.size())return std::unexpected(Status::InvalidArgument("paged append dirty page has no appended rows"));
          const auto source_page=std::uint32_t(before.page_indices[std::size_t(before.kv_indptr[request])+logical]);
          if(source_page!=physical)return std::unexpected(Status::InvalidArgument("paged append changed an untouched prefix page"));
          HYLE_ASSIGN_OR_RETURN(auto source,old_page(source_page));(void)source;
        }
      }
    }
    for(std::size_t i=0;i<dirty.size();++i){if(!p->required[i])return std::unexpected(Status::InvalidArgument("paged append contains an unused writer"));
      if(facts[i].initialized_rows)return std::unexpected(Status::InvalidArgument("paged append dirty targets must be fresh uninitialized original pages"));}
    // Last fallible validation/allocation precedes consuming caller writers.
    for(const auto&fact:facts)p->targets.push_back(fact.storage);
    for(auto&writer:dirty)p->writers.push_back(std::move(writer));
    for(auto&writer:p->writers)p->writer_ptrs.push_back(&writer.lease());
  }catch(...){return std::unexpected(Status::ResourceExhausted("paged append fixed metadata"));}
  return result;
}
Result<c::PagedArenaRead> PagedAppendPages::ready()noexcept{
  if(!data_ || !data_->successful)return std::unexpected(Status::FailedPrecondition("paged append requires a successful retired whole Graph"));
  auto&p=*data_;if(p.result.valid())return p.result;
  for(std::size_t i=0;i<p.writers.size();++i){if(!p.writers[i].lease().valid())continue;
    HYLE_ASSIGN_OR_RETURN(auto ready,p.writers[i].publish(p.required[i]));p.ready_pages.push_back(std::move(ready));}
  const auto old=cd::PagedArenaAccess::pages(p.previous);
  for(const auto&lease:old){HYLE_ASSIGN_OR_RETURN(auto id,cd::PagedArenaAccess::page(p.arena,lease));
    if(std::find(p.final_pages.begin(),p.final_pages.end(),id)==p.final_pages.end())continue;
    const bool present=std::any_of(p.ready_pages.begin(),p.ready_pages.end(),[&](const auto&ready){auto other=cd::PagedArenaAccess::page(p.arena,ready);return other && *other==id;});
    if(!present)p.ready_pages.push_back(lease);
  }
  HYLE_ASSIGN_OR_RETURN(p.result,p.arena.read(p.layout,p.ready_pages));return p.result;
}
namespace detail {
namespace {
constexpr c::ProviderRuntimeProperties queue_runtime{.mode=c::ProviderRuntimeMode::kSharedQueue,
  .workspace_owner=c::ProviderWorkspaceOwner::kCaller,.replay_class=c::ProviderReplayClass::kPrepared,
  .blocks_host=false,.uses_private_threads=false,.supports_concurrent_invocations=true,.capture_compatible=false};
c::ProviderRuntimeProperties runtime(const AppendAdapter&adapter)noexcept{
  auto result=queue_runtime;
  // The CPU Queue performs its copies synchronously on the submitting thread.
  // Device-Queue copies enqueue into that same original ordered sequence.
  result.blocks_host=adapter.device_class==c::DeviceClass::kCpu;
  return result;
}
struct Prepared final {PagedAppend descriptor;mem::MemoryResourceRef resource;NodeId node;};
struct Slot final {PagedAppendPages pages;ValueId cache;};
const ProviderRegionPreparedVTable table{
 .destroy_prepared=[](void*p,mem::AllocatorRef a)noexcept{a.destroy(static_cast<Prepared*>(p));},
 .alias_support=[](void*,std::size_t,std::size_t)noexcept{return c::AliasSupport{};},
 .create_invocation=[](void*,mem::AllocatorRef a,mem::BufferView,void**out)noexcept->Status{*out=a.construct<Slot>();return *out?Status::Ok():Status::ResourceExhausted("paged append slot");},
 .destroy_invocation=[](void*p,mem::AllocatorRef a)noexcept{a.destroy(static_cast<Slot*>(p));},
 .shared_submit=[](void*,void*opaque,cd::QueueSequence&sequence,std::span<const c::ConstTensorView>inputs,std::span<const c::TensorView>outputs)noexcept->cd::EnqueueResult{
   auto&slot=*static_cast<Slot*>(opaque);auto*p=PagedAppendAccess::data(slot.pages);
   if(!p || inputs.size()!=1 || !outputs.empty() || inputs[0].description()!=p->rows)
     return cd::EnqueueResult::rejected(Status::FailedPrecondition("paged append original transaction is not bound"));
   bool accepted=false;const auto old=cd::PagedArenaAccess::pages(p->previous);
   for(const auto&range:p->ranges){auto target=p->targets[range.writer].subview(range.destination,range.bytes);if(!target)return {accepted,target.error()};
     Result<mem::ConstBufferView> source=range.prefix?old[range.source].view():inputs[0].storage().subview(range.source,range.bytes);
     if(!source)return {accepted,source.error()};if(range.prefix)source=source->subview(0,range.bytes);if(!source)return {accepted,source.error()};
     auto command=cd::TransferAccess::enqueue_copy(sequence,*target,*source);accepted|=command.accepted;
     if(!command.status.ok())return {accepted,std::move(command.status)};
   }return {accepted,Status::Ok()};
 },
 .seal_bindings=[](void*,void*opaque)noexcept->Status{return static_cast<Slot*>(opaque)->pages.valid()?Status::Ok():Status::FailedPrecondition("paged append has no owned original pages");}};
Status propose(void*,const RegionDiscoveryRequest&r,mem::AllocatorRef,RegionProposalWriter&w)noexcept{
  for(std::size_t i=0;i<r.graph.node_count();++i){if(!r.allowed_nodes.empty() && !r.allowed_nodes[i])continue;
    HYLE_ASSIGN_OR_RETURN(auto node,r.graph.node_id(i));
    HYLE_ASSIGN_OR_RETURN(auto kind,r.graph.operation_kind(node));
    if(kind!=c::OperationKind::kCustom)continue;
    HYLE_ASSIGN_OR_RETURN(auto operation,r.graph.operation(node));
    if(!operation.custom_as<PagedAppend>())continue;const std::array nodes{node};
    HYLE_ASSIGN_OR_RETURN(auto added,w.try_add({.nodes=nodes,.route=1,.replay_class=c::ProviderReplayClass::kPrepared,
        .implementation=c::ProviderImplementationId{0x5041474544415050ULL}}));if(!added)break;
  }return Status::Ok();
}
Status resources(void*opaque,const RegionCompileRequest&r,mem::AllocatorRef,std::span<RegionInputRequirement>inputs,
    std::span<RegionOutputRequirement>outputs,RegionResourceProposal*out)noexcept{
  if(!r.graph || r.nodes.size()!=1 || inputs.size()!=1 || !outputs.empty() || !r.has_unknown_effects)
    return Status::Unimplemented("paged append needs its original external-write singleton");
  HYLE_ASSIGN_OR_RETURN(auto op,r.graph->operation(r.nodes[0]));const auto append=op.custom_as<PagedAppend>();
  if(!append)return Status::Unimplemented("not paged append");HYLE_ASSIGN_OR_RETURN(auto rows,row_description(*append));(void)rows;
  const auto&a=*static_cast<AppendAdapter*>(opaque);
  inputs[0].resource.required_properties=a.device_class==c::DeviceClass::kCpu?mem::MemoryProperty::kHostAccessible:mem::MemoryProperty::kDeviceAccessible;
  inputs[0].resource.minimum_alignment=1;
  *out={.runtime=runtime(a),.preserves_effects=true};return Status::Ok();
}
c::ProviderPrepareOutcome compile(void*opaque,const RegionCompileRequest&r,mem::AllocatorRef a,ProviderRegionPrepared*out)noexcept{
  *out={};if(!r.graph || r.nodes.size()!=1 || r.input_resources.size()!=1 || !r.outputs.empty() || !r.has_unknown_effects)
    return c::ProviderPrepareOutcome::unsupported(Status::Unimplemented("paged append boundary differs"));
  auto operation=r.graph->operation(r.nodes[0]);if(!operation)return c::ProviderPrepareOutcome::error(operation.error());
  const auto append=operation->custom_as<PagedAppend>();if(!append)return c::ProviderPrepareOutcome::unsupported(Status::Unimplemented("not paged append"));
  const auto&adapter=*static_cast<AppendAdapter*>(opaque);
  if(r.input_resources[0]!=adapter.resource)return c::ProviderPrepareOutcome::unsupported(Status::Unimplemented("paged append needs rows in its original Queue resource"));
  auto*p=a.construct<Prepared>();if(!p)return c::ProviderPrepareOutcome::error(Status::ResourceExhausted("paged append prepared metadata"));
  p->descriptor=*append;p->resource=adapter.resource;p->node=r.nodes[0];
  *out={.vtable=&table,.state=p,.properties={.workspace={0,1},.persistent_bytes=sizeof(Prepared),.dispatch_count=1,
      .runtime=runtime(adapter),.preserves_effects=true,.invocation_private_bytes=std::nullopt}};
  return c::ProviderPrepareOutcome::prepared();
}
const RegionProviderVTable provider_table{&propose,&resources,&compile};
struct Find final {NodeId node;Slot*slot=nullptr;Prepared*prepared=nullptr;gd::ProjectedWriter proof;};
Status find(void*opaque,const gd::RegionAccessView&view)noexcept{
  auto&f=*static_cast<Find*>(opaque);if(view.prepared_vtable!=&table || view.node_ordinals.size()!=1 || static_cast<const Prepared*>(view.prepared)->node!=f.node)return Status::Ok();
  if(f.slot)return Status::InvalidArgument("duplicate selected paged append");
  f.slot=static_cast<Slot*>(view.invocation);f.prepared=static_cast<Prepared*>(view.prepared);f.proof={f.node,view.step,&table,view.prepared};return Status::Ok();
}
}
const RegionProviderVTable*PagedAppendAccess::provider()noexcept{return &provider_table;}
Result<AppendFacts>PagedAppendAccess::facts(const PagedAppendPages&pages)noexcept{
  if(!pages.data_)return std::unexpected(Status::InvalidArgument("paged append pages are empty"));
  HYLE_ASSIGN_OR_RETURN(auto capacity,cd::PagedArenaAccess::tensor(pages.data_->arena));
  return AppendFacts{pages.data_->layout,pages.data_->descriptor.role,capacity};
}
Status PagedAppendAccess::bind(Invocation&invocation,const Graph&graph,NodeId node,ValueId cache,PagedAppendPages&&pages,
    std::span<const gd::ProjectedReader>readers,ResourceOptions options)noexcept{
  Find f{node};HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,&find,&f));
  if(!f.slot || !pages.data_ || f.slot->pages.valid())return Status::FailedPrecondition("paged append needs its selected idle slot and untaken transaction");
  auto&p=*pages.data_;const auto&op=f.prepared->descriptor;
  if(!op.schema.owns(p.layout) || op.role!=p.descriptor.role || op.rows!=p.descriptor.rows || p.successful)
    return Status::InvalidArgument("paged append transaction differs from its selected operation");
  HYLE_ASSIGN_OR_RETURN(auto capacity,cd::PagedArenaAccess::tensor(p.arena));
  if(capacity.storage().resource()!=f.prepared->resource)return Status::InvalidArgument("paged append arena belongs to another selected Queue resource");
  for(const auto&writer:p.writers){HYLE_ASSIGN_OR_RETURN(auto fact,cd::PagedArenaAccess::writer(p.arena,writer));(void)fact;}
  HYLE_RETURN_IF_ERROR(gd::RegionAccess::bind_written_projection(invocation,graph,cache,capacity,
      cd::PagedArenaAccess::pages(p.previous),p.writer_ptrs,f.proof,readers,options));
  f.slot->cache=cache;f.slot->pages=std::move(pages);return Status::Ok();
}
Result<PagedAppendPages>PagedAppendAccess::take(Invocation&invocation,NodeId node)noexcept{
  Find f{node};HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit_retired(invocation,&find,&f));
  if(!f.slot || !f.slot->pages.valid())return std::unexpected(Status::InvalidArgument("paged append has no retained transaction"));
  const bool successful=gd::RegionAccess::successful_outcome(invocation);
  // Taking one resource revokes replay/output readiness for the whole Graph.
  // Latch the same actual successful terminal for all its original append
  // transactions before the first release; this does not publish any page.
  if(successful)HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit_retired(invocation,
      [](void*,const gd::RegionAccessView&view)noexcept->Status{
        if(view.prepared_vtable==&table){auto&pages=static_cast<Slot*>(view.invocation)->pages;
          if(auto*p=PagedAppendAccess::data(pages))p->successful=true;}return Status::Ok();
      },nullptr));
  HYLE_RETURN_IF_ERROR(gd::RegionAccess::release_written_projection(invocation,f.slot->cache));
  auto result=std::move(f.slot->pages);f.slot->cache={};return result;
}
Status PagedAppendAccess::reset(Invocation&invocation)noexcept{
  return gd::RegionAccess::visit(invocation,[](void*,const gd::RegionAccessView&view)noexcept->Status{
    if(view.prepared_vtable==&table && static_cast<Slot*>(view.invocation)->pages.valid())
      return Status::FailedPrecondition("take original paged append pages before resetting the Graph");return Status::Ok();
  },nullptr);
}
} // namespace detail
} // namespace hyle::graph::batch
