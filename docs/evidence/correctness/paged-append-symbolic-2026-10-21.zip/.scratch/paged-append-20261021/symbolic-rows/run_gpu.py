"""Root serial GPU checks; retained unchanged numerical checker and baseline."""
from pathlib import Path
P = Path(__file__).resolve().parent.parent
for template, ready, output in (
    ('run_cuda_check.py', 'cuda-ready-for-root.json', 'cuda-run1'),
    ('qwen_core_check.py', 'final-qwen-ready.json', 'final-qwen-run1'),
):
    mode = 'cuda' if template == 'run_cuda_check.py' else 'qwen'
    source = (P / template).read_text(encoding='utf-8')
    source = source.replace("P / '" + ready + "'", "P / 'symbolic-rows/" + mode + "-ready.json'")
    source = source.replace("P / '" + output + "'", "P / 'symbolic-rows/" + mode + "-run1'")
    scope = {'__file__': str(P / template), '__name__': '__main__'}
    exec(compile(source, str(P / template), 'exec'), scope)
