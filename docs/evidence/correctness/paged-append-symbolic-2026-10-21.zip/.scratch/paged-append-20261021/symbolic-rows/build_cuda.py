"""One changed CUDA consumer host TU; no NVCC/native rebuild or GPU run."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
R = P.parents[2]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('existing', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = P / 'cuda-host1'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
recipe_path = P.parent / 'checks/attempt9/graph_batch--paged_append_cuda_consumer/identity.json'
source = R / 'tests/graph_batch/paged_append_cuda_consumer.cc'
frozen = b.identity(source)
command = b.host_command(c.read(recipe_path)['command'], source, 'cuda-test', out)
c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe_path), CXX=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
deps = c.read(out / 'cuda-test-deps.json')['Data']
record = dict(source=frozen, object=b.identity(out / 'cuda-test.obj'), command=command,
    dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
c.save(out / 'identity.json', record)
print('CUDA host fixture compiled; zero native/SDK rebuilds.', flush=True)
