from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;R=P.parents[1]
W=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec=importlib.util.spec_from_file_location('rows_retained_helpers',W/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
ready=c.read(P/'viewspec-cpu-ready.json');basepath=Path(ready['link_plan']['path']);base=c.read(basepath)
assert h.same(ready['link_plan']) and all(h.same(x) for x in base['inputs'])
fresh=c.read(S/'compile.json')['records'];replacements={}
for x in fresh:
 assert h.same(x['source']) and h.same(x['object']) and all(h.same(d) for d in x['dependencies'])
 tag=Path(x['object']['path']).stem;old=[v for v in base['inputs'] if Path(v['path']).stem==tag];assert len(old)==1,(tag,old)
 replacements[c.key(old[0]['path'])]=x['object']
out=S/'cpu-link1';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
inputs=[replacements.get(c.key(x['path']),x) for x in base['inputs']]
image=out/'cpu.exe'
command=[replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replacements=list(replacements.values()),fresh_sources=[x['source'] for x in fresh],CXX=0,links=1,NVCC=0,SDK_builds=0))
env,_=b.environment(command,[x['path'] for x in inputs],out);c.execute('link',command,env,out)
oldstage=basepath.parent
for dll in oldstage.glob('*.dll'):os.link(dll,out/dll.name)
runtime=c.read(Path(ready['runtime_environment']['path']));runtime['staged_dlls']=[b.identity(d) for d in out.glob('*.dll')];runtime['previous_environment']=ready['runtime_environment'];runtime['PATH']=env['PATH']
if 'CPU_native_overlay' in runtime:runtime['CPU_native_overlay']['destination']=b.identity(out/'hyle_ggml_cpu_append_hyca.dll')
c.save(out/'runtime-environment.json',runtime)
c.save(S/'cpu-ready.json',dict(image=b.identity(image),source=next(x['source'] for x in fresh if Path(x['source']['path']).name=='paged_append_graph_test.cc'),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),sources=[x['source'] for x in fresh],GPU_runs=0,SDK_builds=0))
print('READY',image,flush=True)
