from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
R=P.parents[1]
W=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec=importlib.util.spec_from_file_location('rows_retained_helpers',W/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
jobs=(('src/graph_batch/paged_append.cc','graph_batch--paged_append'),('tests/graph_batch/paged_append_graph_test.cc','graph_batch--paged_append_graph_test'))
def one(job):
 source,tag=job;source=R/source;recipe=P/'checks/attempt9'/tag/'identity.json'
 original=c.read(recipe);out=S/'checks/attempt2'/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
 command=b.host_command(original['command'],source,tag,out);frozen=b.identity(source)
 c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe),CXX=1,NVCC=0,SDK_builds=0))
 env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
 deps=c.read(out/(tag+'-deps.json'))['Data']
 record=dict(source=frozen,object=b.identity(out/(tag+'.obj')),command=command,dependencies=[b.identity(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])])
 assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
 c.save(out/'identity.json',record);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: records=list(pool.map(one,jobs))
c.save(S/'compile-final.json',dict(records=records,CXX=2,NVCC=0,SDK_builds=0,GPU_runs=0))
print('COMPILED 2 related host TUs',flush=True)
