"""Publish the finite-shape append delta; parent window remains immutable."""
from pathlib import Path
import hashlib
import json
import zipfile
S = Path(__file__).resolve().parent
P = S.parent
R = P.parents[1]
E = R / 'docs/evidence/correctness'
name = 'paged-append-symbolic-2026-10-21'
artifact, bundle = E / (name + '.json'), E / (name + '.zip')
assert not artifact.exists() and not bundle.exists()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def same(row): return identity(row['path']) == row
freeze = read(S / 'source-freeze.json')
assert freeze['product_frozen'] and all(same(x) for x in freeze['sources'])
report = read(S / 'report.json')
results = {}
for mode, ready_name, run in (('cpu', 'cpu-ready.json', 'cpu-run2'),
                             ('cuda', 'cuda-ready.json', 'cuda-run1'),
                             ('qwen', 'qwen-ready.json', 'qwen-run1')):
    ready = read(S / ready_name)
    assert same(ready['image']) and same(ready['source'])
    plan = read(ready['link_plan']['path'])
    assert all(same(x) for x in plan['inputs'])
    actual = read(S / run / 'result.json')
    assert actual['exit'] == 0 and not actual.get('timeout') and actual['image'] == ready['image']
    results[mode] = dict(ready=ready, run=actual, stdout=identity(S / run / 'stdout.log'), stderr=identity(S / run / 'stderr.log'))
summary = read(S / 'qwen-run1/summary.json')
assert summary['passed'] and summary['vector_count'] == 72
assert all(p['byte_equal'] for row in summary['sessions'].values() for p in row['vectors'])
files = {path for path in S.rglob('*') if path.is_file() and path.suffix in {'.json', '.py', '.cc', '.h', '.diff', '.log', '.txt'}}
for row in freeze['sources']: files.add(Path(row['path']))
for path in (P / 'run_cuda_check.py', P / 'qwen_core_check.py'):
    files.add(path)
with zipfile.ZipFile(bundle, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(files): archive.write(path, path.relative_to(R).as_posix())
record = dict(date='2026-10-21', throughput_evidence=False,
    parent_evidence=identity(E / 'paged-append-graph-2026-10-21.json'),
    scope='One typed paged-append descriptor per semantic schema/role, with concrete row count derived independently for each selected exact finite Graph child. No per-shape graph rebuilding or compatibility overload.',
    source_freeze=freeze, implementation_review=report,
    build=dict(host_CXX=6, CPU_links=2, CUDA_links=2, NVCC=0, SDK_builds=0,
        explanation='Three related host TUs, then only append/test refreshed for invalid-enum admission. One CUDA fixture host TU. All existing native dependencies and other product objects reused.'),
    results=results, qwen_regression=summary,
    coverage=['A single original symbolic source DAG and one finite compile create T1/T2; both actual CPU paths run upstream Copy, append/COW and causal attention with unchanged .3125/.4 oracle.',
        'Prepared records exact concrete input description; binding another child layout rejects without consuming original pages. Unknown role0xff rejects in factory.',
        'Existing CPU F16/BF16, old snapshot, missing dependency and accepted-failure explicit recovery remain passing.',
        'Actual shared CUDA BF16 existing append/COW journey passes with new descriptor; this fixture is concrete T2, not a CUDA multi-T proof.',
        'Current common-core Qwen four-session count-bound regression retains original dense math, six evictions/18 restore calls/185 tokens, and72 byte-identical endpoint vectors.'],
    limits=['This resolves the fixed-row descriptor limitation in parent evidence; full Qwen paged/prefix integration remains pending.',
        'Other parent limits remain: shared CPU/CUDA plain F16/BF16, fresh/COW, explicit abort recovery, singleton/direct-edge proof, no append capture or exclusive tail transaction.',
        'No performance comparison, physical memory-peak claim, multi-T CUDA proof, native Apple/Vulkan append, full MTP or image inference completion.'],
    bundle=identity(bundle), bundle_files=len(files), binary_tensor_payloads_archived=False,
    reproduction='Delta source/header, before copies, exact commands/objects/dependency identities, actual runtime receipts and endpoint hashes retained. Parent archive supplies unchanged core/source/inputs; existing dependencies and model required. No weights, SDKs, exes, objects, maps or duplicate endpoint payloads.')
artifact.write_text(json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
print(identity(artifact))
print(identity(bundle), len(files), 'members')
