"""Integrate final symbolic append objects into retained CUDA consumers."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
R = P.parents[1]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('existing', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
freeze = c.read(S / 'source-freeze.json')
assert freeze['product_frozen'] and all(h.same(x) for x in freeze['sources'])
cpu_ready = c.read(S / 'cpu-ready.json')
cpu_plan = c.read(cpu_ready['link_plan']['path'])
fresh = {}
for stem in ('graph_batch--batch', 'graph_batch--paged_append'):
    row = [x for x in cpu_plan['inputs'] if Path(x['path']).stem == stem]
    assert len(row) == 1 and h.same(row[0])
    fresh[stem] = row[0]
test = c.read(S / 'cuda-host1/identity.json')
assert h.same(test['source']) and h.same(test['object']) and all(h.same(x) for x in test['dependencies'])
for mode in ('cuda', 'qwen'):
    base_folder = P / ('viewspec-' + mode + '1')
    base = c.read(base_folder / 'link-plan.json')
    assert all(h.same(x) for x in base['inputs'])
    replacements = {}
    for stem, new in fresh.items():
        old = [x for x in base['inputs'] if Path(x['path']).stem == stem]
        assert len(old) == 1
        replacements[c.key(old[0]['path'])] = new
    if mode == 'cuda':
        old = [x for x in base['inputs'] if Path(x['path']).stem == 'graph_batch--paged_append_cuda_consumer']
        assert len(old) == 1
        replacements[c.key(old[0]['path'])] = test['object']
    out = S / (mode + '-link1')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / (mode + '.exe')
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(base_folder / 'link-plan.json'), changed_inputs=list(replacements.values()),
        CXX=0, links=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    for dll in base_folder.glob('*.dll'): os.link(dll, out / dll.name)
    runtime = c.read(base_folder / 'runtime-environment.json')
    runtime['PATH'] = env['PATH']
    runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
    runtime['scope'] = 'Shared CUDA only; CPU numerical proof is separate explicit ABI2/HYCA closure.'
    c.save(out / 'runtime-environment.json', runtime)
    source = test['source'] if mode == 'cuda' else c.read(P / 'viewspec-qwen-ready.json')['source']
    assert h.same(source)
    c.save(S / (mode + '-ready.json'), dict(image=b.identity(image), source=source,
        link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
        frozen_sources=freeze['sources'], changed_inputs=list(replacements.values()), CXX=0, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    print('SYMBOLIC_READY', mode, image, flush=True)
