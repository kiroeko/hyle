#include <cuda.h>
#include <cuda_runtime_api.h>
#include <cstdio>
#include <cstdlib>
#include <dlfcn.h>

int main(int argc, char **argv) {
  std::setvbuf(stdout, nullptr, _IONBF, 0);
  CUdevice device = 0;
  CUcontext context = nullptr;
  const auto init = cuInit(0);
  std::printf("cuInit=%d\n", int(init));
  if (init != CUDA_SUCCESS) return 1;
  const auto selected = cuDeviceGet(&device, 0);
  std::printf("cuDeviceGet=%d\n", int(selected));
  if (selected != CUDA_SUCCESS) return 1;
  const auto retained = cuDevicePrimaryCtxRetain(&context, device);
  std::printf("cuDevicePrimaryCtxRetain=%d\n", int(retained));
  if (retained != CUDA_SUCCESS) return 1;
  const auto current = cuCtxSetCurrent(context);
  std::printf("cuCtxSetCurrent=%d\n", int(current));
  if (current != CUDA_SUCCESS) { cuDevicePrimaryCtxRelease(device); return 1; }
  const unsigned queries = argc > 1 ? unsigned(std::strtoul(argv[1], nullptr, 10)) : 4u;
  void *curand = argc > 2 ? dlopen(argv[2], RTLD_NOW | RTLD_LOCAL) : nullptr;
  if (argc > 2 && !curand) return 1;
  for (unsigned i = 0; i < queries; ++i) {
    void *library = dlopen("libnvidia-ml.so.1", RTLD_NOW | RTLD_LOCAL);
    if (!library) return 1;
    auto initialize = reinterpret_cast<int (*)()>(dlsym(library, "nvmlInit_v2"));
    auto query = reinterpret_cast<int (*)(char *, unsigned)>(dlsym(library, "nvmlSystemGetDriverVersion"));
    auto shutdown = reinterpret_cast<int (*)()>(dlsym(library, "nvmlShutdown"));
    if (!initialize || !query || !shutdown) return 1;
    const int initialized = initialize();
    char version[80]{};
    const int queried = initialized == 0 ? query(version, sizeof(version)) : -1;
    const int finished = initialized == 0 ? shutdown() : -1;
    const int unloaded = dlclose(library);
    std::printf("NVML %u init=%d query=%d shutdown=%d dlclose=%d\n", i, initialized, queried, finished, unloaded);
    if (initialized || queried || finished || unloaded) return 1;
  }
  void *buffer = nullptr;
  const auto allocated = cudaMalloc(&buffer, 8192);
  std::printf("cudaMalloc=%d %s\n", int(allocated), cudaGetErrorString(allocated));
  if (allocated == cudaSuccess) {
    const auto freed = cudaFree(buffer);
    std::printf("cudaFree=%d\n", int(freed));
    const auto waited = cudaDeviceSynchronize();
    std::printf("cudaDeviceSynchronize=%d\n", int(waited));
  }
  if (cuCtxSetCurrent(nullptr) != CUDA_SUCCESS ||
      cuDevicePrimaryCtxRelease(device) != CUDA_SUCCESS) return 1;
  if (curand && dlclose(curand) != 0) return 1;
  std::puts("No HYLE: native CUDA initialize/allocate/free/release complete");
  return allocated == cudaSuccess ? 0 : 1;
}
