from pathlib import Path
import importlib.util
import json
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-pending-store-source-20261027'
spec = importlib.util.spec_from_file_location('cached_recipe', OLD / 'build.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b, h = q.b, q.h

SPECS = [
    ('resources', 'src/graph/resources.cc', OLD / 'compile/resources/command.json',
     OLD / 'compile/resources/unit.obj'),
    ('executable', 'src/graph/executable.cc',
     R / '.scratch/inference-submission-source-20261027/compile/executable/command.json',
     R / '.scratch/inference-submission-source-20261027/compile/executable/unit.obj'),
    ('leases', 'src/compute/resource_leases.cc', OLD / 'compile/leases/command.json',
     OLD / 'compile/leases/unit.obj'),
    ('graph-test', 'tests/graph/output_source_cuda_test.cc', OLD / 'compile/graph-test/command.json',
     OLD / 'compile/graph-test/unit.obj'),
    ('lease-test', 'tests/compute/resource_leases_test.cc',
     R / '.scratch/inference-captured-submission-20261027/compile/lease-test/command.json',
     R / '.scratch/inference-captured-submission-20261027/compile/lease-test/unit.obj'),
]
EXTRA = ['src/graph/plan_state.h', 'include/hyle/graph/detail/replay_access.h',
         'include/hyle/compute/detail/lease_access.h']


def environment(command):
    cl = command[0]
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': cl, 'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = b.read(OLD / 'runtime.json')['PATH']
    return env


def freeze():
    assert not (W / 'plan.json').exists()
    inputs = b.read(OLD / 'link-inputs.json')
    units = []
    for name, source, template, old in SPECS:
        assert sum(b.key(x['path']) == b.key(old) for x in inputs) == 1, name
        out = W / 'compile' / name
        argv = b.read(template)['command']
        command = []
        for i, arg in enumerate(argv):
            if i and argv[i - 1].lower() == '/sourcedependencies':
                arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith('.cc'):
                arg = str(R / source)
            command.append(arg)
        units.append(dict(name=name, source=b.pin(R / source), old=b.pin(old), command=command))
    sources = [b.pin(R / path) for path in [*(s[1] for s in SPECS), *EXTRA]]
    for row in sources:
        dest = W / 'source' / Path(row['path']).relative_to(R)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(Path(row['path']).read_bytes())
    selection = b.read(W / 'selection.json')['tests']
    assert selection and len(set(selection)) == len(selection)
    b.save(W / 'plan.json', dict(units=units, sources=sources, tests=selection,
        baseline=b.pin(OLD / 'link-inputs.json'), input_count=len(inputs),
        scope='Actual single-Queue Hybrid capture reuse and controlled exact append epoch handoff; no full-model overlap or performance claim.'))
    print('FROZEN', len(units), 'CXX,', len(selection), 'tests', flush=True)


def check(plan):
    for row in plan['sources']:
        b.exact(row)


def build():
    plan = b.read(W / 'plan.json')
    check(plan)
    env = environment(plan['units'][0]['command'])
    inputs = b.read(OLD / 'link-inputs.json')
    for row in inputs:
        b.exact(row)
    replacements, compiled = {}, []
    for unit in plan['units']:
        out = W / 'compile' / unit['name']
        assert not out.exists()
        process = h.execute(unit['command'], env, out, timeout=180)
        check(plan)
        obj = b.pin(out / 'unit.obj')
        replacements[b.key(unit['old']['path'])] = obj
        compiled.append(dict(name=unit['name'], object=obj, process=process))
        b.save(W / 'compiled.json', compiled)
    linked_inputs = [replacements.get(b.key(x['path']), x) for x in inputs]
    b.save(W / 'link-inputs.json', linked_inputs)
    image = W / 'bin/hybrid-append-test.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    command = []
    for arg in b.read(OLD / 'link/command.json')['command']:
        if b.key(arg) in replacements:
            arg = replacements[b.key(arg)]['path']
        elif arg.lower().startswith('/out:'):
            arg = '/OUT:' + str(image)
        elif arg.lower().startswith('/pdb:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.lower().startswith('/implib:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    link = h.execute(command, env, W / 'link', timeout=120)
    b.save(W / 'ready.json', dict(image=b.pin(image), compiled=compiled, link=link,
        inputs=b.pin(W / 'link-inputs.json'), plan=b.pin(W / 'plan.json'),
        runtime=b.pin(OLD / 'runtime.json')))
    print('READY', flush=True)


def run():
    plan, ready = b.read(W / 'plan.json'), b.read(W / 'ready.json')
    check(plan)
    b.exact(ready['image'])
    xml = W / 'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter=' + ':'.join(plan['tests']), '--gtest_output=xml:' + str(xml)],
        environment(plan['units'][0]['command']), W / 'run', timeout=90)
    root = ET.parse(xml).getroot()
    cases = root.findall('./testsuite/testcase')
    actual = {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases}
    ok = actual == set(plan['tests']) and all(x.attrib.get('status') == 'run' and
        not x.findall('failure') and not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(W / 'summary.json', dict(status='PASS' if ok else 'FAIL', process=process,
        tests=[x.attrib for x in cases], image=ready['image'], sources=plan['sources']))
    assert ok
    print('PASS', len(cases), flush=True)


if __name__ == '__main__':
    try:
        {'freeze': freeze, 'build': build, 'run': run}[sys.argv[1]]()
    except Exception:
        b.save(W / (sys.argv[1] + '-failure.json'), dict(error=traceback.format_exc()))
        raise
