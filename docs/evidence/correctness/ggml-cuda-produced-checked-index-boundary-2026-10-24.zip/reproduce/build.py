from pathlib import Path
import importlib.util, json, os, sys
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
S = Path(__file__).resolve().parent
A = sys.argv[2] if len(sys.argv) > 2 else 'attempt3'
spec = importlib.util.spec_from_file_location('checked_boundary_build_helpers', R/'.scratch/q27-cold-search-20261024/diagnose.py')
d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)

def build():
    out = S/A; out.mkdir(exist_ok=False); (out/'tmp').mkdir()
    source = R/'tests/graph_provider_ggml_cuda/checked_index_boundary_test.cc'
    command = d.read(R/'.scratch/qwen-multi-draft-20261024/recursive-check5/compile-command.json')
    command.insert(1, '/DHYLE_COMPUTE_GGML_CUDA=1')
    replaced = 0
    for i, arg in enumerate(command):
        if arg.endswith('probe.cc'):
            command[i] = str(source); replaced += 1
        elif arg.startswith('/Fo'): command[i] = '/Fo'+str(out/'test.obj')
        elif arg.startswith('/Fd'): command[i] = '/Fd'+str(out/'test.pdb')
    assert replaced == 1
    env, _ = d.h.b.environment(command, [], out)
    d.save(out/'source.json', d.ident(source))
    result = d.q.execute(command, env, out/'compile', timeout=240)
    if result['exit']: raise RuntimeError(result)
    link = d.read(R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/link-command.json')
    swaps = {
        str(R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/test.obj'): str(out/'test.obj'),
        str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj'): str(R/'.scratch/q27-cold-search-20261024/fixed1/graph/graph.obj'),
        str(R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/graph_provider_ggml_cuda--ggml_cuda_region.obj'): str(R/'.scratch/q27-cold-search-20261024/fixed1/region/region.obj')}
    for old, fresh in swaps.items():
        assert link.count(old) == 1, old
        link[link.index(old)] = fresh
    for i,arg in enumerate(link):
        if arg.startswith('/OUT:'): link[i] = '/OUT:'+str(out/'checks.exe')
    link.extend(str(R/'.scratch/build-compute-v2-dev/lib'/lib) for lib in ('gtest_main.lib','gtest.lib'))
    result = d.q.execute(link, env, out/'link', timeout=240)
    if result['exit']: raise RuntimeError(result)
    original = R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/hyle_ggml_cpu_gdn_scale_v3.dll'
    os.link(original, out/original.name)
    runtime = d.read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')
    d.save(out/'ready.json', dict(image=d.ident(out/'checks.exe'), source=d.ident(source),
        fresh_test_TUs=1, reused_product_fixes=[d.ident(Path(p)) for p in list(swaps.values())[1:]],
        HTTP=0, SDK_builds=0, models=0, runtime_PATH=str(out)+os.pathsep+runtime['PATH']))
    print('COMPILED_AND_LINKED', out/'ready.json', flush=True)

def run():
    ready = d.read(S/A/'ready.json')
    env = dict(os.environ, PATH=ready['runtime_PATH'])
    result = d.q.execute([ready['image']['path'], '--gtest_filter=GgmlCudaGraph.ProducedCheckedIndicesKeepTheirNativeValidationBoundary',
        '--gtest_output=xml:'+str(S/A/'run/results.xml')], env, S/A/'run', timeout=120)
    print(json.dumps(result), flush=True)

def resume_link():
    out = S/A
    (out/'tmp').mkdir(exist_ok=False)
    link = d.read(out/'link/command.json')['command']
    env,_ = d.h.b.environment(link, [], out)
    result = d.q.execute(link, env, out/'link2', timeout=240)
    if result['exit']: raise RuntimeError('link2 exit '+str(result['exit']))
    original = R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/hyle_ggml_cpu_gdn_scale_v3.dll'
    os.link(original, out/original.name)
    runtime = d.read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')
    source = R/'tests/graph_provider_ggml_cuda/checked_index_boundary_test.cc'
    d.save(out/'ready.json', dict(image=d.ident(out/'checks.exe'), source=d.ident(source),
        fresh_test_TUs=1, reused_product_fixes=[d.ident(R/'.scratch/q27-cold-search-20261024/fixed1'/p) for p in ('graph/graph.obj','region/region.obj')],
        HTTP=0, SDK_builds=0, models=0, runtime_PATH=str(out)+os.pathsep+runtime['PATH']))
    print('COMPILED_AND_LINKED', out/'ready.json', flush=True)

def old_control():
    out = S/A
    command_file = out/'link2/command.json'
    if not command_file.exists(): command_file = out/'link/command.json'
    link = d.read(command_file)['command']
    fixed = str(R/'.scratch/q27-cold-search-20261024/fixed1/region/region.obj')
    original = str(R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/graph_provider_ggml_cuda--ggml_cuda_region.obj')
    assert link.count(fixed) == 1
    link[link.index(fixed)] = original
    for i,arg in enumerate(link):
        if arg.startswith('/OUT:'): link[i] = '/OUT:'+str(out/'old-control.exe')
    env,_ = d.h.b.environment(link, [], out)
    result = d.q.execute(link, env, out/'link-old-control', timeout=240)
    if result['exit']: raise RuntimeError('old-control link exit '+str(result['exit']))
    d.save(out/'old-control.json', dict(image=d.ident(out/'old-control.exe'),
        source=d.read(out/'source.json'),same_test_object=d.ident(out/'test.obj'),
        original_region=d.ident(Path(original)), changed_only_region=True, HTTP=0, SDK_builds=0, model_runs=0))
    print('OLD_CONTROL_LINKED', out/'old-control.json', flush=True)

def run_old():
    ready = d.read(S/A/'ready.json')
    env = dict(os.environ, PATH=ready['runtime_PATH'])
    image = d.read(S/A/'old-control.json')['image']['path']
    result = d.q.execute([image, '--gtest_filter=GgmlCudaGraph.ProducedCheckedIndicesKeepTheirNativeValidationBoundary',
        '--gtest_output=xml:'+str(S/A/'run-old-control/results.xml')], env, S/A/'run-old-control', timeout=120)
    print(json.dumps(result), flush=True)

if __name__ == '__main__': {'build':build, 'run':run, 'resume-link':resume_link,
    'old-control':old_control, 'run-old':run_old}[sys.argv[1]]()
