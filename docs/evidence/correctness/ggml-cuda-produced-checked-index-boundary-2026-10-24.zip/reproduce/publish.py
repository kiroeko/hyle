from pathlib import Path
import hashlib, json, sys, zipfile
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
R=Path(__file__).resolve().parents[2]; S=Path(__file__).resolve().parent
E=R/'docs/evidence/correctness'; stem='ggml-cuda-produced-checked-index-boundary-2026-10-24'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p);raw=p.read_bytes()
    try:name=p.relative_to(R).as_posix()
    except ValueError:name=str(p)
    return dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
source=R/'tests/graph_provider_ggml_cuda/checked_index_boundary_test.cc'
assert identity(source)['sha256']==read(S/'attempt5/source.json')['sha256']
old=read(S/'attempt5/run-old-control/process.json'); fixed=read(S/'attempt5/run/process.json')
assert old['exit']==1 and fixed['exit']==0 and not old['timed_out'] and not fixed['timed_out']
message=(S/'attempt5/run-old-control/stdout.log').read_text(encoding='utf8')
assert 'dynamic indices require a checked boundary' in message and 'resource search state budget is exhausted' in message
xml=ET.parse(S/'attempt5/run/results.xml').getroot()
assert int(xml.attrib['tests'])==1 and int(xml.attrib['failures'])==0
cases=xml.findall('.//testcase');assert len(cases)==1
region_new=R/'.scratch/q27-cold-search-20261024/fixed1/region/region.obj'
region_old=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/graph_provider_ggml_cuda--ggml_cuda_region.obj'
new_link=read(S/'attempt5/link/command.json')['command'];old_link=read(S/'attempt5/link-old-control/command.json')['command']
normalize=lambda args:[str(region_new) if a==str(region_old) else a for a in args if not a.startswith('/OUT:')]
assert normalize(new_link)==normalize(old_link)
proof=dict(kind='GGML CUDA produced checked-index boundary regression',date='2026-10-24',result='PASS fixed; original region reproduces the expected cold-search failure',
    scope='One actual small original-encoding Graph on RTX4070; no model source, model quality, performance or full MTP goal certification.',
    graph=dict(nodes=3,flow='Concat(dynamic I32[1], dynamic I32[1]) -> checked Gather(Q8_0 logical F32[4,32]) -> Neg',
        original_encoding='4 exact Q8_0 blocks, binary16 scale0.25 and signed codes0..127; independent decoded F32 oracle',
        published_outputs=['checked Gather F32[2,32]','Neg F32[2,32]'],
        storage_domains=['CUDA device','same-device host-visible managed'],max_route_search_states=32,
        successful_compile_assertions=['route_search_limit_reached == false','route_search_states <32','placement_attempts <=3']),
    cause=dict(original='A region swallowed Concat, so the checked reader index was no longer a recipe input; native prepare rejected the invariant boundary repeatedly over unrelated physical resource choices.',
        source='src/graph_provider_ggml_cuda/ggml_cuda_region.cc ordinary qualify only queried per-node native::supports before this fix.',
        fix='Require GroupedMatMul or checked Gather/GatherElements indices to belong to request.inputs during resource qualification; retain native guard, actual checked bounds and ordinary leaf fallback.',
        terminal_diagnostic='Graph budget termination also retains the last genuine candidate rejection; no budget limit was raised.'),
    contract=dict(checked_output='All64 checked Gather caller-output values remain1337 on invalid produced ID4 for four rows; no partial indexed output write.',
        graph_result='OutOfRange Completion; both Invocation::output ports reject access, and this failed slot rejects another submit.',
        downstream='An independent later Neg caller buffer has no whole-Graph rollback promise. Its bytes are unusable after failure; no extra synchronization or whole-Graph transactional copy was added.',
        references=['docs/user/compute.md:205','docs/user/graph.md:135','docs/user/compute.md:135','include/hyle/graph/executable.h:992'],
        wording_change='graph.md now says this Gather output instead of the whole output'),
    success=dict(checked_values=64,negative_values=64,comparison='exact independently decoded values',valid_indices=[3,1],
        invalid_indices=[3,4],invalid_checked_output_canary_values=64,failed_slot_reuse='FailedPrecondition'),
    comparison=dict(same_test_object=identity(S/'attempt5/test.obj'),changed_only_region_object=True,
        original_region=identity(region_old),fixed_region=identity(region_new),original_process=old,fixed_process=fixed,
        original_image=read(S/'attempt5/old-control.json')['image'],fixed_image=read(S/'attempt5/ready.json')['image']),
    retained_failures=[
        dict(attempt=1,kind='build recipe',result='Compile failed because the reused consumer recipe omitted HYLE_COMPUTE_GGML_CUDA; no runtime.'),
        dict(attempt=2,kind='build recipe',result='Strict test compile passed; first link lacked the explicit temporary directory; link2 passed. This superseded test version was never executed.'),
        dict(attempt=3,kind='test fixture',result='Both old/fixed runtime attempts failed at discovery: plain F32 Gather table is outside this GGML CUDA domain. Replaced with real Q8_0 encoding.'),
        dict(attempt=4,kind='overstrong test assertion',result='Old region reproduced the boundary/search failure. Fixed compiled and computed valid values, and invalid Completion failed, but the assertion incorrectly required an independent Neg buffer to roll back. Public operation/Graph contracts were checked before correcting the test to protect the actual Gather output and reject failed Graph results.')],
    sources=[identity(source),identity(R/'tests/graph_provider_ggml_cuda/CMakeLists.txt'),identity(R/'docs/user/graph.md'),
        identity(R/'.scratch/q27-cold-search-20261024/fixed1/region/ggml_cuda_region.cc')],
    work=dict(final_successful_test_translation_units=1,total_test_compile_attempts=5,successful_test_compiles=4,
        total_tiny_runtime_attempts=6,final_control_and_fixed_runs=2,product_source_recompiled_here=0,SDK_builds=0,NVCC_builds=0,HTTP=0,model_runs=0))
archive=E/(stem+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.write(source,'source/'+source.name)
    for p in [Path(__file__),S/'build.py']:
        z.write(p,'reproduce/'+p.name)
    frozen=R/'.scratch/q27-cold-search-20261024/fixed1/region/ggml_cuda_region.cc'
    z.write(frozen,'source/fixed-ggml_cuda_region.cc')
    for attempt in range(1,6):
        base=S/f'attempt{attempt}'
        for p in base.rglob('*'):
            if p.suffix in ('.json','.log','.xml'):
                if p.name=='ready.json':
                    value=read(p);value.pop('runtime_PATH',None)
                    z.writestr(p.relative_to(S).as_posix(),json.dumps(value,indent=2)+'\n')
                else:z.write(p,p.relative_to(S).as_posix())
    z.writestr('proof.json',json.dumps(proof,indent=2)+'\n')
proof['archive']=identity(archive)
target=E/(stem+'.json');assert not target.exists();target.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(proof=identity(target),archive=proof['archive'])),flush=True)
