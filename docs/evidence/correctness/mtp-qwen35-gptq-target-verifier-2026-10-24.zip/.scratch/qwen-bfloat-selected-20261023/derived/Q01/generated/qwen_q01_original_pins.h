#pragma once
#include <array>
#include <algorithm>
#include <span>
#include <vector>
#include "qwen_bfloat_original_roles.h"
#include "qwen_gptq_projection_fragment.h"

// Actual acquisition pins; the shared Data/Bound and K1 controller are reused.
// Original GPTQ quartets remain packed; compile reports must prove all7 contractions.
namespace qwen_bfloat_original_artifacts::q01 {
namespace roles=qwen_bfloat_original_roles;
inline constexpr qwen_original_mtp_roles::Identity kIdentity{"Vishva007/Qwen3.5-2B-W4A16-AutoRound-GPTQ","8ec79a3b08636bc68fd40d69df80e97ff1263995","GPTQ-v1-int4-group32","model.safetensors+model_extra_tensors.safetensors"};
inline constexpr qwen_full_attention_fragment::Geometry kGeometry{2048,8,2,256,64,1.e-6F,0.F,hyle::compute::DataType::kBFloat16};
inline constexpr std::int64_t kIntermediate=6144,kVocabulary=248320;
inline constexpr float kRopeTheta=10'000'000.F;
inline constexpr std::uint64_t kOriginalBytes=1169172480ULL;
inline constexpr std::string_view kPlanSha256="b793c1071c2d62a05bacba58228c7a820dc9c1ad2cce0d436e9687d0b5524755",kReceiptSha256="f59aba7a4aa6d819345590e3fc06ad9305ecfc1b6bd7e8cf5e9dbfebde414c97",kManifestSha256="8e769399627fbb5a1ad5fb5394f99a22aacbbc52a0936ad1d4f4bcef5eb105f5";
inline constexpr std::string_view kTargetLayer="model.language_model.layers.23",kTargetNorm="model.language_model.norm.weight";
inline constexpr roles::VocabularyNames kVocabularyNames{"model.language_model.embed_tokens.weight","model.language_model.embed_tokens.weight"};
// Both identities name this exact publisher artifact; no unpinned official base revision is inferred.
inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{
    .model_publisher="Vishva007",.model_repository=kIdentity.repository,.model_family="qwen3.5",
    .model_name="Qwen3.5-2B-W4A16-AutoRound-GPTQ",.model_revision=kIdentity.revision,
    .configuration_digest="29fcf453d36204797fbe15f5769f76014bae1041acda000ca1753a10eb21a56d",
    .artifact_repository=kIdentity.repository,.artifact_revision=kIdentity.revision,.variant=kIdentity.variant,
    .manifest_digest="eb79667127442035f1ab9ba644e163f3e4acde6d0c9bf8b793ceeeb9834afed9",.format_family="safetensors"};
static_assert(kProfile.complete());
inline constexpr roles::DenseNormConventions kNormConventions{
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne};
inline constexpr std::array<roles::PinnedFile,16> kNextnFiles{{
    {"mtp.pre_fc_norm_hidden.weight.bf16","cde85c36a07008e762cc65a25a3e778d0aecd3df643dd579f764d5ed134aff2a"},
    {"mtp.pre_fc_norm_embedding.weight.bf16","74b00671922e5f220913a5ce2ba95c3a1b37c772aa033bf34ffc469865246534"},
    {"mtp.fc.weight.bf16","04a296fcc7c41188d9551afc386a38ae75b2ade3ccefe0a75d85f7472f04b60c"},
    {"mtp.layers.0.input_layernorm.weight.bf16","01af4181b176c9f1f0c9d99f3881161ab1c63c6e666255ab808cf293d1611525"},
    {"mtp.layers.0.self_attn.q_proj.weight.bf16","7b45fe45a43ea32ce66fd5357e29ee122f7ccadbc724663d9c63c8e5f0a25ce4"},
    {"mtp.layers.0.self_attn.k_proj.weight.bf16","ebe58f1ab9fda4a8368ed9e95ad1fdfc1c60d4c55ad3c562cba8792c5d88feeb"},
    {"mtp.layers.0.self_attn.v_proj.weight.bf16","5ecec5c2354fa5fecf20ab5da3b9dfdf040fc9484ec28f2db5908c7c76db0e6c"},
    {"mtp.layers.0.self_attn.o_proj.weight.bf16","5fa2b6fc75e80099387274afe6468069f643b015a7336877fcb85ad7d3038d18"},
    {"mtp.layers.0.self_attn.q_norm.weight.bf16","2f54ef9aae55165775c5974b7cf0a329f1df5050cb18fc8e13699272dbeb3dbf"},
    {"mtp.layers.0.self_attn.k_norm.weight.bf16","9f5ddb8c876889339b54277ac29d454432ada6db7ae514999fe5408a4fc8bf63"},
    {"mtp.layers.0.post_attention_layernorm.weight.bf16","19f28dcd9ecf86ce8e15d148522f8eb2107869786b7ebc760fbc2c5a9a01552d"},
    {"mtp.layers.0.mlp.gate_proj.weight.bf16","8ecbb1330b7e5e7b8e5a84dffdac6ac3c8ff535661ab6d51eedd526ab3ae34a7"},
    {"mtp.layers.0.mlp.up_proj.weight.bf16","4f19bbf4ccc04b3919e674fbd7d58b042ebbcb24b66a0a3b6990fee716dd66fc"},
    {"mtp.layers.0.mlp.down_proj.weight.bf16","4c67381e935cd66110fe2c5a297757d68462bfce6b0fbb499e985d374a43d43a"},
    {"mtp.norm.weight.bf16","50a5dcfd925e824ca6abd9c3b5f4cd9a5222c65256ed8d4bf08a6eadfe64259f"},
    {"model.language_model.embed_tokens.weight.bf16","b222b11204158144e369ae8fca02cab9cb63b0a8cde1dd59dd4d0c60690824ed"},
}};
struct Pin final {std::string_view name,file,sha256,dtype;std::array<std::int64_t,2> shape;std::size_t rank;std::uint64_t bytes;};
inline constexpr std::array<Pin,49> kPins{{
    {"model.language_model.layers.23.mlp.down_proj.g_idx","model.language_model.layers.23.mlp.down_proj.g_idx.i32","c00f8327f6f7f3fdc0335ae2e2fe76e8ba331c3ab858cf7c4c46800eacbe6604","I32",{6144,0},1,24576ULL},
    {"model.language_model.layers.23.mlp.down_proj.qweight","model.language_model.layers.23.mlp.down_proj.qweight.i32","a68fd305791b5e38fe3c8ce7604e1936e60d2f8e2ea43620ef00d67d5fb25a3b","I32",{768,2048},2,6291456ULL},
    {"model.language_model.layers.23.mlp.down_proj.qzeros","model.language_model.layers.23.mlp.down_proj.qzeros.i32","4c9d024567d90d0503c3febcc7cc1ea2c533ebd95c78c2632eedadb98eea83fb","I32",{192,256},2,196608ULL},
    {"model.language_model.layers.23.mlp.gate_proj.g_idx","model.language_model.layers.23.mlp.gate_proj.g_idx.i32","64124b1e51858f3b5da49543dff0ff2131f54bd62b0cd92c564eaadbae20efd2","I32",{2048,0},1,8192ULL},
    {"model.language_model.layers.23.mlp.gate_proj.qweight","model.language_model.layers.23.mlp.gate_proj.qweight.i32","c7b057213bc865dcb6fd2a7646d49fdf0c0aa746e1445f0f50695d76116c5363","I32",{256,6144},2,6291456ULL},
    {"model.language_model.layers.23.mlp.gate_proj.qzeros","model.language_model.layers.23.mlp.gate_proj.qzeros.i32","4c9d024567d90d0503c3febcc7cc1ea2c533ebd95c78c2632eedadb98eea83fb","I32",{64,768},2,196608ULL},
    {"model.language_model.layers.23.mlp.up_proj.g_idx","model.language_model.layers.23.mlp.up_proj.g_idx.i32","64124b1e51858f3b5da49543dff0ff2131f54bd62b0cd92c564eaadbae20efd2","I32",{2048,0},1,8192ULL},
    {"model.language_model.layers.23.mlp.up_proj.qweight","model.language_model.layers.23.mlp.up_proj.qweight.i32","6899ca9f965d195e41754b081f7dc8574331d52b1aa50eef4997d3227da18299","I32",{256,6144},2,6291456ULL},
    {"model.language_model.layers.23.mlp.up_proj.qzeros","model.language_model.layers.23.mlp.up_proj.qzeros.i32","4c9d024567d90d0503c3febcc7cc1ea2c533ebd95c78c2632eedadb98eea83fb","I32",{64,768},2,196608ULL},
    {"model.language_model.layers.23.self_attn.k_proj.g_idx","model.language_model.layers.23.self_attn.k_proj.g_idx.i32","64124b1e51858f3b5da49543dff0ff2131f54bd62b0cd92c564eaadbae20efd2","I32",{2048,0},1,8192ULL},
    {"model.language_model.layers.23.self_attn.k_proj.qweight","model.language_model.layers.23.self_attn.k_proj.qweight.i32","55154d54fd2991e8379c2d686bf8be2c1cb0afa0489149c98ca9e93d5ef53e3c","I32",{256,512},2,524288ULL},
    {"model.language_model.layers.23.self_attn.k_proj.qzeros","model.language_model.layers.23.self_attn.k_proj.qzeros.i32","8c540a131b4526744050794d94678bd00c08d6fc05da07f8e6551c556d5152cb","I32",{64,64},2,16384ULL},
    {"model.language_model.layers.23.self_attn.o_proj.g_idx","model.language_model.layers.23.self_attn.o_proj.g_idx.i32","64124b1e51858f3b5da49543dff0ff2131f54bd62b0cd92c564eaadbae20efd2","I32",{2048,0},1,8192ULL},
    {"model.language_model.layers.23.self_attn.o_proj.qweight","model.language_model.layers.23.self_attn.o_proj.qweight.i32","a332d6aaf69cea617faae96be09958ee933f44ad343aa5983cbc9223a8b168ea","I32",{256,2048},2,2097152ULL},
    {"model.language_model.layers.23.self_attn.o_proj.qzeros","model.language_model.layers.23.self_attn.o_proj.qzeros.i32","5cee0d614476b023b4fd196e4bf54433544d74b7348f8dbc2285a5d71ed1caf6","I32",{64,256},2,65536ULL},
    {"model.language_model.layers.23.self_attn.q_proj.g_idx","model.language_model.layers.23.self_attn.q_proj.g_idx.i32","64124b1e51858f3b5da49543dff0ff2131f54bd62b0cd92c564eaadbae20efd2","I32",{2048,0},1,8192ULL},
    {"model.language_model.layers.23.self_attn.q_proj.qweight","model.language_model.layers.23.self_attn.q_proj.qweight.i32","869b1f16b14bfa1049b144cbe0711ea9484ff7f1b5373128cc0b2241bfd81035","I32",{256,4096},2,4194304ULL},
    {"model.language_model.layers.23.self_attn.q_proj.qzeros","model.language_model.layers.23.self_attn.q_proj.qzeros.i32","e0a7735e0f5166eb66ad9d88317850b3415a0abdf39b7576912ccd8e1be00781","I32",{64,512},2,131072ULL},
    {"model.language_model.layers.23.self_attn.v_proj.g_idx","model.language_model.layers.23.self_attn.v_proj.g_idx.i32","64124b1e51858f3b5da49543dff0ff2131f54bd62b0cd92c564eaadbae20efd2","I32",{2048,0},1,8192ULL},
    {"model.language_model.layers.23.self_attn.v_proj.qweight","model.language_model.layers.23.self_attn.v_proj.qweight.i32","e6014cda69cf03ad5b7d8c3e1b2593db862837b4d9602accc7a3f06f92337790","I32",{256,512},2,524288ULL},
    {"model.language_model.layers.23.self_attn.v_proj.qzeros","model.language_model.layers.23.self_attn.v_proj.qzeros.i32","8c540a131b4526744050794d94678bd00c08d6fc05da07f8e6551c556d5152cb","I32",{64,64},2,16384ULL},
    {"model.language_model.embed_tokens.weight","model.language_model.embed_tokens.weight.bf16","b222b11204158144e369ae8fca02cab9cb63b0a8cde1dd59dd4d0c60690824ed","BF16",{248320,2048},2,1017118720ULL},
    {"model.language_model.layers.23.input_layernorm.weight","model.language_model.layers.23.input_layernorm.weight.bf16","fdc9d0c7b47d967d646d3b4bd8e5f5606ef46839f5b21e68b63c40b10b0ad824","BF16",{2048,0},1,4096ULL},
    {"model.language_model.layers.23.post_attention_layernorm.weight","model.language_model.layers.23.post_attention_layernorm.weight.bf16","72a235413e983f39082d677cce90f28b18516b2aa3f5de96a92d59707598d4c0","BF16",{2048,0},1,4096ULL},
    {"model.language_model.layers.23.self_attn.k_norm.weight","model.language_model.layers.23.self_attn.k_norm.weight.bf16","2a4412bc2388b7d4b7aca3a0b221cec7da8ca0f9fa56f031a5ea731e8103812a","BF16",{256,0},1,512ULL},
    {"model.language_model.layers.23.self_attn.q_norm.weight","model.language_model.layers.23.self_attn.q_norm.weight.bf16","a365f9f976d7b19e6476c69ccad2fd0fb5c98f2594c18f9c709c2946b595b9f0","BF16",{256,0},1,512ULL},
    {"model.language_model.norm.weight","model.language_model.norm.weight.bf16","0df050ad8e61ea06a06b50c0eb0ae6975d97fb5712dfb0dec2d0b154c0676dd5","BF16",{2048,0},1,4096ULL},
    {"model.language_model.layers.23.mlp.down_proj.scales","model.language_model.layers.23.mlp.down_proj.scales.f16","b8635aaed8d024868b146bf34460979cd29d73e433315ee5f39cc9adef9892de","F16",{192,2048},2,786432ULL},
    {"model.language_model.layers.23.mlp.gate_proj.scales","model.language_model.layers.23.mlp.gate_proj.scales.f16","9af81f87281c6f248eeb5c52cf9b8fd9e87179882388090114bd824e787504c5","F16",{64,6144},2,786432ULL},
    {"model.language_model.layers.23.mlp.up_proj.scales","model.language_model.layers.23.mlp.up_proj.scales.f16","11a2ee093aec20c5a6273ea854e7de1009ab69d8b568eca6be1b339214c5bee2","F16",{64,6144},2,786432ULL},
    {"model.language_model.layers.23.self_attn.k_proj.scales","model.language_model.layers.23.self_attn.k_proj.scales.f16","6d577999cd14aa05c43ec0b669e48c5b101b13379139d2d0fe4d483216565ddd","F16",{64,512},2,65536ULL},
    {"model.language_model.layers.23.self_attn.o_proj.scales","model.language_model.layers.23.self_attn.o_proj.scales.f16","f44d9daed3f526c4e8046c00525c216b0f1e02dd5e0db776435a870a9ad8c120","F16",{64,2048},2,262144ULL},
    {"model.language_model.layers.23.self_attn.q_proj.scales","model.language_model.layers.23.self_attn.q_proj.scales.f16","b9dfa367e1b5a97b5933991e1f3e4a8b050028d36bf53f3b6e312fa643adf1d3","F16",{64,4096},2,524288ULL},
    {"model.language_model.layers.23.self_attn.v_proj.scales","model.language_model.layers.23.self_attn.v_proj.scales.f16","f1600060cd95f7a4a1fbce91856bd7c539fdc936693a75d6bf9816b7f3d13781","F16",{64,512},2,65536ULL},
    {"mtp.fc.weight","mtp.fc.weight.bf16","04a296fcc7c41188d9551afc386a38ae75b2ade3ccefe0a75d85f7472f04b60c","BF16",{2048,4096},2,16777216ULL},
    {"mtp.layers.0.input_layernorm.weight","mtp.layers.0.input_layernorm.weight.bf16","01af4181b176c9f1f0c9d99f3881161ab1c63c6e666255ab808cf293d1611525","BF16",{2048,0},1,4096ULL},
    {"mtp.layers.0.mlp.down_proj.weight","mtp.layers.0.mlp.down_proj.weight.bf16","4c67381e935cd66110fe2c5a297757d68462bfce6b0fbb499e985d374a43d43a","BF16",{2048,6144},2,25165824ULL},
    {"mtp.layers.0.mlp.gate_proj.weight","mtp.layers.0.mlp.gate_proj.weight.bf16","8ecbb1330b7e5e7b8e5a84dffdac6ac3c8ff535661ab6d51eedd526ab3ae34a7","BF16",{6144,2048},2,25165824ULL},
    {"mtp.layers.0.mlp.up_proj.weight","mtp.layers.0.mlp.up_proj.weight.bf16","4f19bbf4ccc04b3919e674fbd7d58b042ebbcb24b66a0a3b6990fee716dd66fc","BF16",{6144,2048},2,25165824ULL},
    {"mtp.layers.0.post_attention_layernorm.weight","mtp.layers.0.post_attention_layernorm.weight.bf16","19f28dcd9ecf86ce8e15d148522f8eb2107869786b7ebc760fbc2c5a9a01552d","BF16",{2048,0},1,4096ULL},
    {"mtp.layers.0.self_attn.k_norm.weight","mtp.layers.0.self_attn.k_norm.weight.bf16","9f5ddb8c876889339b54277ac29d454432ada6db7ae514999fe5408a4fc8bf63","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.k_proj.weight","mtp.layers.0.self_attn.k_proj.weight.bf16","ebe58f1ab9fda4a8368ed9e95ad1fdfc1c60d4c55ad3c562cba8792c5d88feeb","BF16",{512,2048},2,2097152ULL},
    {"mtp.layers.0.self_attn.o_proj.weight","mtp.layers.0.self_attn.o_proj.weight.bf16","5fa2b6fc75e80099387274afe6468069f643b015a7336877fcb85ad7d3038d18","BF16",{2048,2048},2,8388608ULL},
    {"mtp.layers.0.self_attn.q_norm.weight","mtp.layers.0.self_attn.q_norm.weight.bf16","2f54ef9aae55165775c5974b7cf0a329f1df5050cb18fc8e13699272dbeb3dbf","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.q_proj.weight","mtp.layers.0.self_attn.q_proj.weight.bf16","7b45fe45a43ea32ce66fd5357e29ee122f7ccadbc724663d9c63c8e5f0a25ce4","BF16",{4096,2048},2,16777216ULL},
    {"mtp.layers.0.self_attn.v_proj.weight","mtp.layers.0.self_attn.v_proj.weight.bf16","5ecec5c2354fa5fecf20ab5da3b9dfdf040fc9484ec28f2db5908c7c76db0e6c","BF16",{512,2048},2,2097152ULL},
    {"mtp.norm.weight","mtp.norm.weight.bf16","50a5dcfd925e824ca6abd9c3b5f4cd9a5222c65256ed8d4bf08a6eadfe64259f","BF16",{2048,0},1,4096ULL},
    {"mtp.pre_fc_norm_embedding.weight","mtp.pre_fc_norm_embedding.weight.bf16","74b00671922e5f220913a5ce2ba95c3a1b37c772aa033bf34ffc469865246534","BF16",{2048,0},1,4096ULL},
    {"mtp.pre_fc_norm_hidden.weight","mtp.pre_fc_norm_hidden.weight.bf16","cde85c36a07008e762cc65a25a3e778d0aecd3df643dd579f764d5ed134aff2a","BF16",{2048,0},1,4096ULL},
}};
inline const Pin &pin(std::string_view name) {
  const auto found=std::find_if(kPins.begin(),kPins.end(),[&](const auto &x){return x.name==name;});
  if(found==kPins.end())throw std::runtime_error("Q01 role absent from actual authenticated header");return *found;
}
inline std::array<qwen_gptq_projection_fragment::Names,7> target_projection_names() {
  return {{
    {"model.language_model.layers.23.self_attn.q_proj.qweight","model.language_model.layers.23.self_attn.q_proj.qzeros","model.language_model.layers.23.self_attn.q_proj.scales","model.language_model.layers.23.self_attn.q_proj.g_idx",32},
    {"model.language_model.layers.23.self_attn.k_proj.qweight","model.language_model.layers.23.self_attn.k_proj.qzeros","model.language_model.layers.23.self_attn.k_proj.scales","model.language_model.layers.23.self_attn.k_proj.g_idx",32},
    {"model.language_model.layers.23.self_attn.v_proj.qweight","model.language_model.layers.23.self_attn.v_proj.qzeros","model.language_model.layers.23.self_attn.v_proj.scales","model.language_model.layers.23.self_attn.v_proj.g_idx",32},
    {"model.language_model.layers.23.self_attn.o_proj.qweight","model.language_model.layers.23.self_attn.o_proj.qzeros","model.language_model.layers.23.self_attn.o_proj.scales","model.language_model.layers.23.self_attn.o_proj.g_idx",32},
    {"model.language_model.layers.23.mlp.gate_proj.qweight","model.language_model.layers.23.mlp.gate_proj.qzeros","model.language_model.layers.23.mlp.gate_proj.scales","model.language_model.layers.23.mlp.gate_proj.g_idx",32},
    {"model.language_model.layers.23.mlp.up_proj.qweight","model.language_model.layers.23.mlp.up_proj.qzeros","model.language_model.layers.23.mlp.up_proj.scales","model.language_model.layers.23.mlp.up_proj.g_idx",32},
    {"model.language_model.layers.23.mlp.down_proj.qweight","model.language_model.layers.23.mlp.down_proj.qzeros","model.language_model.layers.23.mlp.down_proj.scales","model.language_model.layers.23.mlp.down_proj.g_idx",32},
  }};
}
inline std::vector<roles::Spec> specs() {
  auto result=roles::dense_specs(kGeometry,kIntermediate,kVocabulary,kNextnFiles,kVocabularyNames);result.reserve(kPins.size());
  const auto names=target_projection_names();
  constexpr std::array<std::int64_t,7> outputs{4096,512,512,2048,6144,6144,2048},widths{2048,2048,2048,2048,2048,2048,6144};
  for(std::size_t slot=0;slot<names.size();++slot) {
    const auto &p=names[slot];const std::array ids{p.qweight,p.qzeros,p.scales,p.group_index};std::array<roles::PinnedFile,4> files;
    for(std::size_t n=0;n<4;++n){const auto &x=pin(ids[n]);files[n]={x.file,x.sha256};}
    const auto quartet=roles::gptq_projection_specs(outputs[slot],widths[slot],p.group_size,ids,files);
    result.insert(result.end(),quartet.begin(),quartet.end());
  }
  {const auto &x=pin("model.language_model.layers.23.input_layernorm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({2048},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.23.self_attn.q_norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({256},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.23.self_attn.k_norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({256},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.23.post_attention_layernorm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({2048},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({2048},hyle::compute::DataType::kBFloat16)});}
  if(result.size()!=kPins.size())throw std::runtime_error("original GPTQ source requires its unique physical roles");std::uint64_t bytes=0;
  for(std::size_t slot=0;slot<result.size();++slot) {
    const auto &s=result[slot];const auto &p=pin(s.name);const auto &d=s.description;
    const auto type=d.data_type()==hyle::compute::DataType::kBFloat16?"BF16":d.data_type()==hyle::compute::DataType::kFloat16?"F16":d.data_type()==hyle::compute::DataType::kInt32?"I32":"unsupported";
    if(s.file!=p.file||s.sha256!=p.sha256||p.dtype!=type||d.rank()!=p.rank||
        !std::equal(d.dimensions().begin(),d.dimensions().end(),p.shape.begin())||
        qwen_original_mtp_roles::detail::take(d.required_bytes(),"Q01 actual role extent")!=p.bytes)
      throw std::runtime_error("Q01 typed role differs from actual name/dtype/shape/bytes/SHA");
    for(std::size_t previous=0;previous<slot;++previous)if(result[previous].name==s.name)throw std::runtime_error("Q01 physical role cannot be duplicated");
    bytes+=p.bytes;
  }
  if(bytes!=kOriginalBytes)throw std::runtime_error("Q01 original source total differs");return result;
}
} // namespace qwen_bfloat_original_artifacts::q01
