"""Emit Q01 actual49-role Specs only after completed authenticated acquisition.

Reads small metadata and file sizes, not whole payloads. No header/cases may be
generated from metadata-only ranges or fabricated/default role hashes.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
spec = importlib.util.spec_from_file_location('q01_authenticated_metadata', S / 'fetch_roles.py')
fetch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fetch)
PREFIX = 'model.language_model.layers.23'
PROJECTIONS = [('self_attn.q_proj', 4096, 2048), ('self_attn.k_proj', 512, 2048),
    ('self_attn.v_proj', 512, 2048), ('self_attn.o_proj', 2048, 2048), ('mlp.gate_proj', 6144, 2048),
    ('mlp.up_proj', 6144, 2048), ('mlp.down_proj', 2048, 6144)]
NEXTN = ['mtp.pre_fc_norm_hidden.weight', 'mtp.pre_fc_norm_embedding.weight', 'mtp.fc.weight',
    'mtp.layers.0.input_layernorm.weight', 'mtp.layers.0.self_attn.q_proj.weight',
    'mtp.layers.0.self_attn.k_proj.weight', 'mtp.layers.0.self_attn.v_proj.weight', 'mtp.layers.0.self_attn.o_proj.weight',
    'mtp.layers.0.self_attn.q_norm.weight', 'mtp.layers.0.self_attn.k_norm.weight',
    'mtp.layers.0.post_attention_layernorm.weight', 'mtp.layers.0.mlp.gate_proj.weight',
    'mtp.layers.0.mlp.up_proj.weight', 'mtp.layers.0.mlp.down_proj.weight', 'mtp.norm.weight',
    'model.language_model.embed_tokens.weight']
NORMS = [PREFIX + x for x in ('.input_layernorm.weight', '.self_attn.q_norm.weight',
    '.self_attn.k_norm.weight', '.post_attention_layernorm.weight')] + ['model.language_model.norm.weight']


def layout(plan):
    # Actual differences:23/63, H2048/5120, group32/64, tied16/untied17.
    g=plan['geometry'];h,d,heads,kv,i=g['hidden'],g['depth'],g['heads'],g['kv_heads'],g['intermediate']
    assert h>0 and d>0 and heads>0 and kv>0 and i>0 and g['group']>0
    prefix='model.language_model.layers.'+str(g['target_layer'])
    projections=[('self_attn.q_proj',2*heads*d,h),('self_attn.k_proj',kv*d,h),('self_attn.v_proj',kv*d,h),
        ('self_attn.o_proj',h,heads*d),('mlp.gate_proj',i,h),('mlp.up_proj',i,h),('mlp.down_proj',h,i)]
    names=NEXTN[:15]+[plan['vocabulary']['embedding']]
    if plan['vocabulary']['head']!=plan['vocabulary']['embedding']:names.append(plan['vocabulary']['head'])
    norms=[prefix+x for x in ('.input_layernorm.weight','.self_attn.q_norm.weight','.self_attn.k_norm.weight',
        '.post_attention_layernorm.weight')]+['model.language_model.norm.weight']
    return prefix,projections,names,norms


def pinned(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def projection_schema(plan,weight_format):
    prefix,projections,_,_=layout(plan);group=plan['geometry']['group']
    result=[]
    for suffix,n,k in projections:
        if weight_format=='gptq-v1-int4':
            fields=[('qweight','I32',[k//8,n]),('qzeros','I32',[k//group,n//8]),
                ('scales','F16',[k//group,n]),('g_idx','I32',[k])]
        elif weight_format=='ct-asymmetric4':
            fields=[('weight_packed','I32',[n,k//8]),('weight_zero_point','I32',[(n+7)//8,k//group]),
                ('weight_scale','BF16',[n,k//group]),('weight_shape','I64',[2])]
        else:raise ValueError('Unknown explicit original artifact weight format')
        result.extend((prefix+'.'+suffix+'.'+name,dtype,shape) for name,dtype,shape in fields)
    return result


def checked_metadata(source=fetch,weight_format='gptq-v1-int4'):
    plan_path, plan = source.checked_plan()
    prefix,projections,nextn,norms=layout(plan)
    out = source.S / 'original-roles'
    rp, mp = out / 'acquisition.json', out / 'manifest.json'
    receipt, manifest = source.read(rp), source.read(mp)
    for x in (receipt, manifest):
        assert x.get('complete') is True, 'Actual complete original acquisition required; no pins generated'
        assert (x['repository'], x['revision'], x['original_roles']) == (source.REPO, source.REV, source.COUNT)
        assert len(x['roles']) == source.COUNT
    assert receipt['source_plan_sha256'] == source.PLAN_SHA and receipt['whole_shard_downloaded'] is False
    assert receipt['expected_role_payload_bytes'] == receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == source.BODY
    assert manifest['source_bytes'] == source.BODY and manifest['source_plan'] == source.identity(plan_path)
    assert manifest['source_receipt'] == source.identity(rp) and manifest['vocabulary'] == plan['vocabulary']
    rows = {x['name']: x for x in manifest['roles']}
    acquired = {x['name']: x for x in receipt['roles']}
    assert len(rows) == len(acquired) == source.COUNT and set(rows) == set(acquired) == {x['name'] for x in plan['roles']}
    assert len({x['file'] for x in rows.values()}) == source.COUNT
    for wanted in plan['roles']:
        name = wanted['name']
        row, actual = rows[name], acquired[name]
        assert actual['complete'] and pinned(actual['payload']['sha256'])
        for key in ('name', 'section', 'dtype', 'shape', 'bytes', 'source_file', 'absolute_inclusive'):
            assert row[key] == actual[key] == wanted[key], (name, key)
        assert row['file'] == actual['filename'] == wanted['filename'] and Path(row['file']).name == row['file']
        assert row['sha256'] == actual['payload']['sha256'] and pinned(row['sha256'])
        assert actual['payload']['bytes'] == row['bytes']
        path = out / row['file']
        assert path.resolve() == (R / actual['payload']['path']).resolve() and path.stat().st_size == row['bytes']
        offset = 0
        for chunk in actual['chunks']:
            assert chunk['offset'] == offset and 0 < chunk['bytes'] <= source.CHUNK and pinned(chunk['sha256'])
            first = wanted['absolute_inclusive'][0] + offset
            assert chunk['absolute_range_inclusive'] == [first, first + chunk['bytes'] - 1]
            offset += chunk['bytes']
        assert offset == row['bytes']
    assert set(nextn).issubset(rows) and len(nextn) in (16,17)
    for name,dtype,shape in projection_schema(plan,weight_format):
        row=rows[name]
        assert (row['dtype'],row['shape'])==(dtype,shape)
    if weight_format=='ct-asymmetric4':
        for suffix,n,k in projections:
            row=rows[prefix+'.'+suffix+'.weight_shape']
            raw=(out/row['file']).read_bytes()  # Only seven 16-byte metadata roles, not weight bodies.
            assert len(raw)==16 and hashlib.sha256(raw).hexdigest()==row['sha256']
            assert [int.from_bytes(raw[i:i+8],'little',signed=True) for i in (0,8)]==[n,k], 'Original CT weight_shape payload must match N/K'
    return plan, rows


def header(plan, rows, receipt_sha, manifest_sha, source=fetch, tag='q01', family='qwen3.5',
        model_name='Qwen3.5-2B-W4A16-AutoRound-GPTQ',
        config_sha='29fcf453d36204797fbe15f5769f76014bae1041acda000ca1753a10eb21a56d',
        header_sha='eb79667127442035f1ab9ba644e163f3e4acde6d0c9bf8b793ceeeb9834afed9',
        weight_format='gptq-v1-int4',publisher='Vishva007'):
    prefix,projections,nextn,norms=layout(plan);g=plan['geometry'];group=g['group']
    if weight_format=='gptq-v1-int4':
        projection_ns='qwen_gptq_projection_fragment';variant=f'GPTQ-v1-int4-group{group}'
        fields=('qweight','qzeros','scales','g_idx');spec_function='gptq_projection_specs'
        source_comment='// Original GPTQ quartets remain packed; compile reports must prove all7 contractions.'
    elif weight_format=='ct-asymmetric4':
        projection_ns='qwen_ct_asymmetric_projection_fragment';variant=f'compressed-tensors-asymmetric4-group{group}'
        fields=('weight_packed','weight_zero_point','weight_scale','weight_shape');spec_function='ct_asymmetric_projection_specs'
        source_comment='// Original CT triples remain packed; seven I64 shapes are authenticated metadata, not decode inputs.'
    else:raise ValueError('Unknown explicit original artifact weight format')
    q = json.dumps
    lines = ['#pragma once', '#include <array>', '#include <algorithm>', '#include <span>', '#include <vector>',
        '#include "qwen_bfloat_original_roles.h"', '#include "'+projection_ns+'.h"', '',
        '// Actual acquisition pins; the shared Data/Bound and K1 controller are reused.',
        source_comment,
        f'namespace qwen_bfloat_original_artifacts::{tag} {{', 'namespace roles=qwen_bfloat_original_roles;',
        f'inline constexpr qwen_original_mtp_roles::Identity kIdentity{{{q(source.REPO)},{q(source.REV)},{q(variant)},{q("+".join(x["file"] for x in plan["shards"]))}}};',
        f'inline constexpr qwen_full_attention_fragment::Geometry kGeometry{{{g["hidden"]},{g["heads"]},{g["kv_heads"]},{g["depth"]},{g["rotary"]},1.e-6F,0.F,hyle::compute::DataType::kBFloat16}};',
        f'inline constexpr std::int64_t kIntermediate={g["intermediate"]},kVocabulary={g["vocabulary"]};',
        "inline constexpr float kRopeTheta=10'000'000.F;", f'inline constexpr std::uint64_t kOriginalBytes={source.BODY}ULL;',
        f'inline constexpr std::string_view kPlanSha256={q(source.PLAN_SHA)},kReceiptSha256={q(receipt_sha)},kManifestSha256={q(manifest_sha)};',
        f'inline constexpr std::string_view kTargetLayer={q(prefix)},kTargetNorm="model.language_model.norm.weight";',
        f'inline constexpr roles::VocabularyNames kVocabularyNames{{{q(plan["vocabulary"]["embedding"])},{q(plan["vocabulary"]["head"])}}};',
        '// Both identities name this exact publisher artifact; no unpinned official base revision is inferred.',
        'inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{',
        f'    .model_publisher={q(publisher)},.model_repository=kIdentity.repository,.model_family={q(family)},',
        f'    .model_name={q(model_name)},.model_revision=kIdentity.revision,',
        f'    .configuration_digest={q(config_sha)},',
        '    .artifact_repository=kIdentity.repository,.artifact_revision=kIdentity.revision,.variant=kIdentity.variant,',
        f'    .manifest_digest={q(header_sha)},.format_family="safetensors"}};',
        'static_assert(kProfile.complete());',
        'inline constexpr roles::DenseNormConventions kNormConventions{',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne};',
        f'inline constexpr std::array<roles::PinnedFile,{len(nextn)}> kNextnFiles{{{{']
    for name in nextn:
        x = rows[name]
        lines.append(f'    {{{q(x["file"])},{q(x["sha256"])}}},')
    lines += ['}};', 'struct Pin final {std::string_view name,file,sha256,dtype;std::array<std::int64_t,2> shape;std::size_t rank;std::uint64_t bytes;};',
        f'inline constexpr std::array<Pin,{source.COUNT}> kPins{{{{']
    for x in plan['roles']:
        x = rows[x['name']]
        shape = x['shape'] + [0] * (2 - len(x['shape']))
        lines.append(f'    {{{q(x["name"])},{q(x["file"])},{q(x["sha256"])},{q(x["dtype"])},{{{shape[0]},{shape[1]}}},{len(x["shape"])},{x["bytes"]}ULL}},')
    lines += ['}};', 'inline const Pin &pin(std::string_view name) {',
        '  const auto found=std::find_if(kPins.begin(),kPins.end(),[&](const auto &x){return x.name==name;});',
        '  if(found==kPins.end())throw std::runtime_error("Q01 role absent from actual authenticated header");return *found;', '}',
        'inline std::array<'+projection_ns+'::Names,7> target_projection_names() {',
        '  return {{']
    for suffix, _, _ in projections:
        lines.append('    {' + ','.join(q(prefix + '.' + suffix + '.' + x) for x in fields) + f',{group}}},')
    lines += ['  }};', '}', 'inline std::vector<roles::Spec> specs() {',
        '  auto result=roles::dense_specs(kGeometry,kIntermediate,kVocabulary,kNextnFiles,kVocabularyNames);result.reserve(kPins.size());',
        '  const auto names=target_projection_names();',
        '  constexpr std::array<std::int64_t,7> outputs{' + ','.join(str(n) for _,n,_ in projections) + '},widths{' + ','.join(str(k) for _,_,k in projections) + '};',
        '  for(std::size_t slot=0;slot<names.size();++slot) {',
        '    const auto &p=names[slot];const std::array ids{'+('p.qweight,p.qzeros,p.scales,p.group_index' if weight_format=='gptq-v1-int4' else 'p.codes,p.zeros,p.scales,p.shape')+'};std::array<roles::PinnedFile,4> files;',
        '    for(std::size_t n=0;n<4;++n){const auto &x=pin(ids[n]);files[n]={x.file,x.sha256};}',
        '    const auto quartet=roles::'+spec_function+'(outputs[slot],widths[slot],p.group_size,ids,files);',
        '    result.insert(result.end(),quartet.begin(),quartet.end());', '  }']
    for name in norms:
        width = g['depth'] if name.endswith(('q_norm.weight', 'k_norm.weight')) else g['hidden']
        lines += [f'  {{const auto &x=pin({q(name)});result.push_back({{x.name,x.file,x.sha256,roles::sem::dense({{{width}}},hyle::compute::DataType::kBFloat16)}});}}']
    lines += ['  if(result.size()!=kPins.size())throw std::runtime_error("original GPTQ source requires its unique physical roles");std::uint64_t bytes=0;',
        '  for(std::size_t slot=0;slot<result.size();++slot) {',
        '    const auto &s=result[slot];const auto &p=pin(s.name);const auto &d=s.description;',
        '    const auto type=d.data_type()==hyle::compute::DataType::kBFloat16?"BF16":d.data_type()==hyle::compute::DataType::kFloat16?"F16":d.data_type()==hyle::compute::DataType::kInt32?"I32":'+('d.data_type()==hyle::compute::DataType::kInt64?"I64":' if weight_format=='ct-asymmetric4' else '')+'"unsupported";',
        '    if(s.file!=p.file||s.sha256!=p.sha256||p.dtype!=type||d.rank()!=p.rank||',
        '        !std::equal(d.dimensions().begin(),d.dimensions().end(),p.shape.begin())||',
        '        qwen_original_mtp_roles::detail::take(d.required_bytes(),"Q01 actual role extent")!=p.bytes)',
        '      throw std::runtime_error("Q01 typed role differs from actual name/dtype/shape/bytes/SHA");',
        '    for(std::size_t previous=0;previous<slot;++previous)if(result[previous].name==s.name)throw std::runtime_error("Q01 physical role cannot be duplicated");',
        '    bytes+=p.bytes;', '  }',
        '  if(bytes!=kOriginalBytes)throw std::runtime_error("Q01 original source total differs");return result;', '}',
        '} // namespace qwen_bfloat_original_artifacts::q01', '']
    if weight_format=='ct-asymmetric4':
        lines=[line.replace('original GPTQ source','original CT source') for line in lines]
        at=next(i for i,line in enumerate(lines) if line.startswith('} // namespace'))
        validation=['inline void validate_shapes(const roles::Data &source) {']
        for suffix,n,k in projections:
            validation.append('  roles::require_ct_shape(source.bytes('+q(prefix+'.'+suffix+'.weight_shape')+'),'+str(n)+','+str(k)+');')
        validation+=['}']
        lines[at:at]=validation
    return '\n'.join(lines).replace('Q01',tag.upper()).replace('::q01','::'+tag)


def main_for(source=fetch,tag='q01',**profile):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=source.S / ('generated/qwen_'+tag+'_original_pins.h'))
    args = parser.parse_args()
    plan, rows = checked_metadata(source,profile.get('weight_format','gptq-v1-int4'))  # All hard checks precede any emitted header.
    rp, mp = source.identity(source.S / 'original-roles/acquisition.json'), source.identity(source.S / 'original-roles/manifest.json')
    text = header(plan, rows, rp['sha256'], mp['sha256'],source=source,tag=tag,**profile)
    path = args.output.resolve()
    assert path.is_relative_to(source.R) and path.suffix == '.h'
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_text(encoding='utf-8-sig') == text, 'Refuse to replace different actual pins'
    else:
        path.write_text(text, encoding='utf-8')
    metadata=dict(header=source.identity(path), source_plan=source.identity(source.PLAN_FILE),
        source_receipt=rp, manifest=mp, original_roles=source.COUNT, original_bytes=source.BODY, body_rehashed=False,
        artifact_executed=False, packed_contractions_required=7)
    if profile.get('weight_format','gptq-v1-int4')=='ct-asymmetric4':
        metadata.update(packed_recipe_nodes=3,shape_metadata_roles=7)
    path.with_suffix('.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(header=source.identity(path), pins=source.identity(path.with_suffix('.json')))))


def main():
    main_for()


if __name__ == '__main__':
    main()
