from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile
S=Path(__file__).resolve().parent;R=S.parents[4];A=S.parent
D=R/'docs/evidence/correctness';NAME='mtp-qwen35-gptq-target-verifier-2026-10-24'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
executions=[]
for backend,folder in (('CPU',S/'checks1'),('CUDA',S/'checks2')):
    summary=read(folder/'summary.json');process=read(folder/'process.json');p=summary['properties']
    assert process['exit']==0 and not process['timed_out']
    for key,value in dict(actual_submissions=23,original_role_count=49,original_role_bytes=1169172480,
        complete_target_draft_resources=12,target_packed_contractions=7,target_packed_recipe_nodes=4,
        target_dense_weight_materializations=0,target_verifier_rows=2,target_verifier_full_vocabulary=248320).items():
        assert int(p[key])==value,key
    executions.append(dict(backend=backend,case=summary['case'],tests=1,failures=0,skips=0,graphs=23,
        summary=ident(folder/'summary.json'),properties=p))
paths=set()
for sub in ('compile1','tests-link1','checks1','checks2'):
    for path in (S/sub).rglob('*'):
        if path.is_file() and path.suffix in ('.json','.log','.xml','.cc'):paths.add(path)
for path in S.glob('*.py'):paths.add(path)
for path in A.glob('*.py'):paths.add(path)
for path in A.glob('*.json'):paths.add(path)
for path in (A/'generated').glob('*'):paths.add(path)
for name in ('acquisition.json','manifest.json'):paths.add(A/'original-roles'/name)
for path in (A/'prefetch1/selected49-net').rglob('*'):
    if path.is_file() and path.suffix in ('.json','.log'):paths.add(path)
compiled=read(S/'compile1/qwen-state/identity.json')
for item in [compiled['source'],*compiled['dependencies']]:
    path=Path(item['path']).resolve()
    if path.is_relative_to(R) and path.parts[len(R.parts)] in ('tests','include','src'):
        assert ident(path)['sha256']==item['sha256'];paths.add(path)
archive=D/(NAME+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(paths):z.write(p,p.relative_to(R).as_posix())
record=dict(created_at=datetime.now(timezone.utc).isoformat(),identity=dict(id='Q01',
    repository='Vishva007/Qwen3.5-2B-W4A16-AutoRound-GPTQ',revision='8ec79a3b08636bc68fd40d69df80e97ff1263995',variant='GPTQ-v1-int4-group32'),
    scope='Actual original GPTQ target23, BF16 NextN24 and own original tied BF16 full vocabulary in existing K1/12-resource controller',
    original_roles=49,original_bytes=1169172480,executions=executions,
    target_precision='Original Q/Z/F16 scales/I32 g_idx; GPTQ-v1 zero nibble+1, F16 product then BF16 W, BF16 A/F32 dot/BF16 result.',
    packed_execution='All seven four-node DecodeF16/CastBF16/View/MatMul recipes contract before Invocation; dense weight materializations0.',
    source_plan=ident(A/'roles-plan.json'),acquisition=ident(A/'original-roles/acquisition.json'),
    manifest=ident(A/'original-roles/manifest.json'),actual_pins=ident(A/'generated/qwen_q01_original_pins.json'),
    build=dict(host_translation_units=1,SDK_builds=0,NVCC_builds=0,
        compiled=ident(S/'compile1/qwen-state/identity.json'),link=ident(S/'tests-link1/link-plan.json'),
        note='Fresh current-header Qwen TU, current batched-BF16 CPU/CUDA/cuBLAS host objects; unused Pro consumer removed. No legacy comment-equivalence proof.'),
    transport=dict(endpoint='https://hf-mirror.net',cross_origin_redirects='rejected before send',
        requested_unique_body_bytes=1169172480,reserved_request_bytes=1169172480,HF_reserved_bytes=0,
        receipt=ident(A/'prefetch1/selected49-net/summary.json'),reservations_are_exact_wire_bytes=False),
    limits=['Layer22 upstream inputs and finite initial histories remain fixtures, not full trained trunk or model task quality.',
        'One natural accepted0 trial and separate match/rejection controls are not an acceptance-rate measurement.',
        'No TPS, load speed, physical CPU/GPU memory peak, Linux/macOS or all-device inference claim.'],
    archive=ident(archive),archived_files=len(paths),whole_original_model=False,throughput_evidence=False,memory_evidence=False)
output=D/(NAME+'.json');assert not output.exists();output.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=ident(output),archive=ident(archive),graphs=46)))
