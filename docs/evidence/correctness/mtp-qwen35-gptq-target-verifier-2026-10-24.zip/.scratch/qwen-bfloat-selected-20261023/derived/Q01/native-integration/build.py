"""Root-only Q01 actual49-role adapter using the Q03/GQ one-TU lifecycle.

This file only configures the explicit Q01 source and authenticates its real
pins. It does not duplicate compilation/link/process code. No action on import;
missing or partial data rejects compile/link/run before compiler/image launch.
No SDK/NVCC/worker build, acquisition, whole-W decode or implicit CPU fallback.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
Q01 = S.parent
ENTRY_SCRIPT = Path(__file__).resolve()
R = S.parents[4]
LIFECYCLE = Q01.parent / 'Q03/native-integration/build.py'
LIFECYCLE_SHA = '5f87169da5eea4e89d2c8add51e2f4135e2f135070d340b0f19ee02981f70c16'
HEADER = Q01 / 'generated/qwen_q01_original_pins.h'
MACRO = '/DHYLE_TEST_QWEN_Q01_ARTIFACTS_HEADER='
REPOSITORY = 'Vishva007/Qwen3.5-2B-W4A16-AutoRound-GPTQ'
REVISION = '8ec79a3b08636bc68fd40d69df80e97ff1263995'
ORIGINAL_ROLES, ORIGINAL_BYTES = 49, 1169172480
ARTIFACT_TAG = 'Q01'
ENVIRONMENT = 'HYLE_QWEN_Q01_ORIGINAL_DIR'
SPEC_FUNCTION = 'gptq_projection_specs('
REQUIRED_NODES, SHAPE_METADATA_ROLES = 4, 0
EXPECTED_VOCABULARY = dict(embedding='model.language_model.embed_tokens.weight',
    head='model.language_model.embed_tokens.weight', unique_banks=1)
FORBIDDEN = tuple('/DHYLE_TEST_QWEN_'+tag+'_ARTIFACTS_HEADER=' for tag in ('Q03','B04','Q09','Q10'))
RUN_SOURCE = 'Q01 actual GPTQ-v1 target23 plus BF16 NextN24 and one tied original vocabulary'
RUN_SCOPE = ('Actual selected49 original Q01 roles; seven native packed DecodeF16/CastBF16/View/MatMul contractions; '
    'same K1/12-member Head/accepted-prefix repair; upstream target22 input/history fixture; no whole-model quality or TPS claim')
SUFFIX = 'Q01OriginalGptqTargetAndBFloatNextNFullVocabularyVerifierPublishesRepairedPrefix'
CASES = {key: 'QwenMtpStateConsumer.' + backend + SUFFIX
         for key, backend in (('cpu', 'Cpu'), ('cuda', 'Cuda'))}


def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()  # Only explicit small metadata/script inputs.
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def generator():
    return load(ARTIFACT_TAG.lower()+'_real_pin_metadata_for_native_adapter', Q01 / 'generate_pins.py')


def artifacts(header):
    header = Path(header).resolve()
    assert header == HEADER and header.is_file(), 'Actual generated '+ARTIFACT_TAG+' header is required'
    gen = generator()
    plan, rows = gen.checked_metadata()  # Actual original files, sizes, complete receipts and physical schema.
    assert (plan['repository'], plan['revision'], len(rows), plan['source_bytes']) == (
        REPOSITORY, REVISION, ORIGINAL_ROLES, ORIGINAL_BYTES)
    assert plan['vocabulary'] == EXPECTED_VOCABULARY
    receipt = gen.fetch.identity(Q01 / 'original-roles/acquisition.json')
    manifest = gen.fetch.identity(Q01 / 'original-roles/manifest.json')
    expected = gen.header(plan, rows, receipt['sha256'], manifest['sha256'])
    assert header.read_text(encoding='utf-8-sig') == expected
    pins_path = header.with_suffix('.json')
    pins = read(pins_path)
    assert (pins['original_roles'], pins['original_bytes'], pins['packed_contractions_required']) == (
        ORIGINAL_ROLES, ORIGINAL_BYTES, 7)
    assert pins['source_receipt'] == receipt and pins['manifest'] == manifest
    assert pins['source_plan'] == gen.fetch.identity(gen.fetch.PLAN_FILE)
    assert pins['header'] == gen.fetch.identity(header)
    assert pins['body_rehashed'] is False and pins['artifact_executed'] is False
    assert 'namespace qwen_bfloat_original_artifacts::'+ARTIFACT_TAG.lower() in expected
    assert SPEC_FUNCTION in expected and 'target_projection_names()' in expected
    if SHAPE_METADATA_ROLES:
        assert REQUIRED_NODES == 3 and pins['packed_recipe_nodes'] == 3
        assert pins['shape_metadata_roles'] == SHAPE_METADATA_ROLES == 7 and 'validate_shapes(' in expected
    else:
        assert REQUIRED_NODES == 4
    paths = [header, pins_path, gen.fetch.PLAN_FILE, Q01 / 'roles-plan.json',
        Q01 / 'original-roles/acquisition.json', Q01 / 'original-roles/manifest.json',
        Q01 / 'generate_pins.py', Q01 / 'fetch_roles.py', Q01 / 'source/config.json']
    # Record the small fixed headers/index/receipt actually checked by the pin
    # generator; do not hash payloads or substitute S01/Q03 artifact metadata.
    paths += [R / entry.get('extracted', entry.get('cached'))['path']
              for entry in plan['source_entries']]
    if hasattr(gen, 'TEMPLATE'):
        paths.append(Path(gen.TEMPLATE))
    if hasattr(gen, 'shared') and hasattr(gen.shared, 'fetch'):
        paths.append(Path(gen.shared.fetch.__file__))
    # Q10's authenticated transport plan is its actual metadata-completed
    # plan, not the older source plan which intentionally lacked an ETag.
    completed = plan.get('completed_http_identity')
    if completed:
        for witness in completed.values():
            path = R / witness['path']
            assert gen.fetch.identity(path) == witness
            paths.append(path)
        transport = read(R / completed['receipt']['path'])
        if 'prefix' in transport:
            path = R / transport['prefix']['path']
            assert gen.fetch.identity(path) == transport['prefix']
            paths.append(path)
    return [identity(path) for path in dict.fromkeys(paths)]


def configured_lifecycle():
    assert identity(LIFECYCLE)['sha256'] == LIFECYCLE_SHA
    job = load('q01_existing_q03_native_lifecycle', LIFECYCLE)
    job.S, job.SCRIPT, job.ARTIFACT_DIR = S, ENTRY_SCRIPT, Q01
    job.ARTIFACT_TAG = ARTIFACT_TAG
    job.ORIGINAL_ROLES, job.ORIGINAL_BYTES = ORIGINAL_ROLES, ORIGINAL_BYTES
    job.HEADER, job.MACRO, job.CASES = HEADER, MACRO, CASES
    job.FORBIDDEN = FORBIDDEN
    job.ENVIRONMENT = ENVIRONMENT
    job.RUN_SOURCE, job.RUN_SCOPE = RUN_SOURCE, RUN_SCOPE
    job.generator, job.artifacts = generator, artifacts
    original_adapter = job.adapter

    def adapter():
        return dict(original_adapter(), lifecycle=identity(LIFECYCLE),
            repository=REPOSITORY, revision=REVISION, selected_original_bytes=ORIGINAL_BYTES,
            Q03_macro=False, required_packed_contractions=7, required_packed_recipe_nodes=REQUIRED_NODES,
            shape_metadata_roles=SHAPE_METADATA_ROLES, vocabulary=EXPECTED_VOCABULARY,
            entry=identity(ENTRY_SCRIPT), shared_adapter=identity(__file__))
    job.adapter = adapter
    return job


if __name__ == '__main__':
    lifecycle = configured_lifecycle()
    lifecycle.__doc__ = __doc__
    lifecycle.main()
