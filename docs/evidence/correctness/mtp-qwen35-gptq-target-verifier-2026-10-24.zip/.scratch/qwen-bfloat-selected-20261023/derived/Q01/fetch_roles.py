"""Root-only Q01 selected49-role acquisition, using the existing QB transport.

Definitions/imports do no HTTP. Main is explicit; new ranges<=8MiB, certified
legacy chunks<=128MiB, IO1MiB,3role workers. Original two-file identity/ranges
and unchanged BF16/I32/F16 payloads are mandatory; no whole-shard fetch.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
REPO, REV = 'Vishva007/Qwen3.5-2B-W4A16-AutoRound-GPTQ', '8ec79a3b08636bc68fd40d69df80e97ff1263995'
PLAN_SHA = 'b793c1071c2d62a05bacba58228c7a820dc9c1ad2cce0d436e9687d0b5524755'
Q03 = S.parent / 'Q03/fetch_roles.py'
Q03_SHA = '782217f632d88f913a5cf873f13db771c705b1e85d2e83e918997e71a7e8b03b'
COUNT, BODY = 49, 1169172480
PLAN_FILE = S / 'roles-plan.json'
FILE_DESCRIPTION = 'model.safetensors+model_extra_tensors.safetensors'
VARIANT = 'GPTQ-v1-int4-group32'
CHUNK, REQUEST_CHUNK, IO, WORKERS = 128 * 1024 * 1024, 8 * 1024 * 1024, 1024 * 1024, 3


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()  # Small metadata only, never a role body.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked_plan():
    path = PLAN_FILE
    assert identity(path)['sha256'] == PLAN_SHA
    plan = read(path)
    assert (plan['repository'], plan['revision'], plan['original_roles'], plan['source_bytes']) == (REPO, REV, COUNT, BODY)
    assert plan['metadata_only'] and plan['complete_absolute_ranges'] and plan['tensor_payload_bytes'] == 0
    assert plan['geometry'] == dict(hidden=2048, heads=8, kv_heads=2, depth=256, rotary=64,
        intermediate=6144, vocabulary=248320, target_layer=23, target_type='full_attention', group=32)
    assert identity(S / 'source/config.json')['sha256'] == '29fcf453d36204797fbe15f5769f76014bae1041acda000ca1753a10eb21a56d'
    assert len(plan['roles']) == len({x['name'] for x in plan['roles']}) == len({x['filename'] for x in plan['roles']}) == COUNT
    assert plan['vocabulary']['embedding'] == plan['vocabulary']['head'] and plan['vocabulary']['unique_banks'] == 1
    for source in plan['source_entries']:
        item = source.get('extracted', source.get('cached'))
        assert identity(R / item['path']) == item
    assert len(plan['shards']) == 2
    headers = []
    for shard in plan['shards']:
        assert identity(R / shard['header']['path']) == shard['header']
        raw = (R / shard['header']['path']).read_bytes()
        header = json.loads(raw)
        assert shard['data_base'] == len(raw) + 8
        assert shard['data_base'] + max(v['data_offsets'][1] for k, v in header.items() if k != '__metadata__') == shard['whole_file_bytes']
        assert shard['url'] == f'https://huggingface.co/{REPO}/resolve/{REV}/' + shard['file']
        assert shard['etag'].startswith('"') and shard['etag'].endswith('"')
        headers.append(header)
    total = 0
    for row in plan['roles']:
        shard = plan['shards'][row['source_shard']]
        actual = headers[row['source_shard']][row['name']]
        assert Path(row['filename']).name == row['filename']
        assert row['source_file'] == shard['file'] and row['dtype'] == actual['dtype'] and row['shape'] == actual['shape']
        assert row['data_relative_half_open'] == actual['data_offsets']
        first, end = actual['data_offsets']
        assert row['bytes'] == end - first == math.prod(row['shape']) * {'BF16': 2, 'F16': 2, 'I32': 4}[row['dtype']] > 0
        assert row['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
        assert row['absolute_inclusive'][1] < shard['whole_file_bytes']
        total += row['bytes']
    assert total == BODY and 'lm_head.weight' not in headers[0]
    return path, plan


def shared_downloader():
    assert identity(Q03)['sha256'] == Q03_SHA
    spec = importlib.util.spec_from_file_location('q01_existing_q03_transport_adapter', Q03)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # Only definitions; its guarded main is not called.
    assert (module.CHUNK, module.REQUEST_CHUNK, module.IO, module.WORKERS) == (CHUNK, REQUEST_CHUNK, IO, WORKERS)
    return module.shared_downloader()  # Existing pinned QB +8MiB opt-in adapter.


def manifest(out, record, plan):
    roles = [dict(name=x['name'], file=x['filename'], sha256=x['payload']['sha256'], dtype=x['dtype'],
        shape=x['shape'], bytes=x['bytes'], section=x['section'], source_file=x['source_file'],
        absolute_inclusive=x['absolute_inclusive']) for x in record['roles']]
    result = dict(repository=REPO, revision=REV, variant=VARIANT, file=FILE_DESCRIPTION,
        directory=out.relative_to(R).as_posix(), original_roles=COUNT, source_bytes=BODY, roles=roles, complete=True,
        source_plan=identity(PLAN_FILE), source_receipt=identity(out / 'acquisition.json'),
        vocabulary=plan['vocabulary'], artifact_executed=False,
        scope='Unchanged selected ranges only. Actual explicit BF16 vocabulary; original target GPTQ Q/Z/F16 SF/g_idx remain packed. ETag is object identity, not an asserted whole-file content SHA.')
    (out / 'manifest.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    plan_path, plan = checked_plan()
    shared = shared_downloader()
    out = S / 'original-roles'
    if args.plan_only:
        print(json.dumps(dict(repository=REPO, revision=REV, roles=COUNT, body_bytes=BODY, source_plan=identity(plan_path),
            output_directory=out.relative_to(R).as_posix(), new_request_bytes=REQUEST_CHUNK,
            certified_chunk_limit_bytes=CHUNK, stream_buffer_bytes=IO, workers=WORKERS, network_requests=0)))
        return
    out.mkdir(exist_ok=True)
    with shared.single_writer(out / '.fetch.lock'):
        receipt = out / 'acquisition.json'
        roles = []
        for x in plan['roles']:
            shard = plan['shards'][x['source_shard']]
            roles.append(dict(x, url=shard['url'], etag=shard['etag'], whole_file_bytes=shard['whole_file_bytes'],
                complete=False, chunks=[], payload=dict(path=(out / x['filename']).relative_to(R).as_posix(), bytes=x['bytes'], sha256=None)))
        expected = dict(repository=REPO, revision=REV, file=FILE_DESCRIPTION,
            source_plan=plan_path.relative_to(R).as_posix(), source_plan_sha256=PLAN_SHA,
            expected_role_payload_bytes=BODY, downloader=identity(shared.HELPER), wrapper=identity(Path(shared.__file__)))
        if receipt.exists():
            record = read(receipt)
            assert all(record[k] == v for k, v in expected.items())
            for actual, wanted in zip(record['roles'], roles, strict=True):
                assert all(actual[k] == v for k, v in wanted.items() if k not in ('complete', 'chunks', 'payload'))
                assert actual['payload']['path'] == wanted['payload']['path'] and actual['payload']['bytes'] == wanted['payload']['bytes']
        else:
            assert not any((R / x['payload']['path']).exists() for x in roles), 'Unrecorded bytes are not an authenticated prefix'
            record = dict(expected, complete=False, original_roles=COUNT, whole_shard_downloaded=False, requests=[], roles=roles)
        functions = shared.downloader(record, receipt)
        with functions['LOCK']:
            record.update(complete=False, chunk_bytes=CHUNK, request_chunk_bytes=REQUEST_CHUNK,
                authenticated_chunk_limit_bytes=CHUNK, stream_buffer_bytes=IO, parallel_role_workers=WORKERS)
            functions['save']()
        errors = []
        with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='q01-role') as executor:
            for future in as_completed([executor.submit(functions['acquire_role'], x) for x in record['roles']]):
                try:
                    future.result()
                except Exception as error:
                    errors.append(error)
        if errors:
            with functions['LOCK']:
                record['complete'] = False
                functions['save']()
            raise errors[0]
        with functions['LOCK']:
            assert all(x['complete'] and x['payload']['sha256'] for x in record['roles'])
            payload_bytes = sum(x['payload']['bytes'] for x in record['roles'])
            request_bytes = sum(x['bytes'] for x in record['requests'] if x['complete'])
            assert payload_bytes == request_bytes == BODY
            record.update(complete=True, role_payload_bytes=payload_bytes, successful_request_body_bytes=request_bytes,
                finished_utc=functions['now']())
            functions['save']()
        manifest(out, record, plan)
        print(json.dumps(dict(complete=True, roles=COUNT, role_payload_bytes=BODY,
            receipt=identity(receipt), manifest=identity(out / 'manifest.json'))))


if __name__ == '__main__':
    main()
