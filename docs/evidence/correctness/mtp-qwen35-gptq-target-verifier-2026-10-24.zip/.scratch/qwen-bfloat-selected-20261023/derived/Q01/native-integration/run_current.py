"""Q01 real-pinned host TU and current reconciled provider closure only."""
from pathlib import Path
import argparse,importlib.util,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[4]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=module('q01_current_build',R/'.scratch/native-paged-effects-20261022/build_windows.py');b,c=h.b,h.c
q=module('q01_current_run',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
BASE=R/'.scratch/glm-gguf-selected-20261023/B09/native-integration/tests-link2'
LINK=S/'tests-link1'
def check_record(path):
    rec=c.read(path)
    assert all(b.identity(x['path'])==x for x in (rec['source'],rec['object'],*rec['dependencies']))
    return rec
def compile_one():
    pins=S.parent/'generated/qwen_q01_original_pins.h';proof=c.read(pins.with_suffix('.json'))
    assert proof['original_roles']==49 and proof['original_bytes']==1169172480
    assert b.identity(pins)['sha256']==proof['header']['sha256']
    previous=R/'.scratch/qwen-gguf-selected-20261023/Q14/native-integration/compile1/qwen-state/identity.json'
    recipe=c.read(previous)
    recipe['command']=[arg for arg in recipe['command'] if 'ARTIFACTS_HEADER=' not in arg]
    recipe['command'].insert(1,'/DHYLE_TEST_QWEN_Q01_ARTIFACTS_HEADER="'+pins.as_posix()+'"')
    recipe.update(prepared_only=True,actual_pins=b.identity(pins),pin_receipt=b.identity(pins.with_suffix('.json')))
    path=S/'prepared-recipe.json';assert not path.exists();c.save(path,recipe)
    h.S=S;h.RECIPES={'qwen-state':path};h.SOURCES={'qwen-state':R/'tests/compute_models/qwen_mtp_state_consumer_test.cc'}
    h.compile_one('qwen-state',1)
def link():
    base=c.read(BASE/'link-plan.json');newpath=S/'compile1/qwen-state/identity.json';new=check_record(newpath)
    old=c.read(base['consumer_record']['path'])
    for item in base['retained_current_providers']:
        assert b.identity(item['path'])==item;check_record(item['path'])
    LINK.mkdir(exist_ok=False);(LINK/'tmp').mkdir();image=LINK/'q01-checks.exe'
    command=[];replaced=0
    for arg in base['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
        if arg.lower()==old['object']['path'].lower():arg=new['object']['path'];replaced+=1
        command.append(arg)
    assert replaced==1
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(LINK/'link-plan.json',dict(command=command,base=b.identity(BASE/'link-plan.json'),consumer_record=b.identity(newpath),
        removed_unused_consumer=old['object'],retained_current_providers=base['retained_current_providers'],
        retained_product_records=base['retained_product_records'],SDK_builds=0,NVCC_builds=0))
    env,_=b.environment(command,[],LINK);c.execute('link',command,env,LINK)
    runtime=c.read(BASE/'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path'])==dll;os.link(dll['path'],LINK/Path(dll['path']).name)
    runtime['PATH']=runtime['PATH'].replace(str(BASE),str(LINK));runtime['previous']=b.identity(BASE/'runtime-environment.json')
    runtime['staged_dlls']=[b.identity(p) for p in LINK.glob('*.dll')]
    c.save(LINK/'runtime-environment.json',runtime)
    c.save(LINK/'ready.json',dict(image=b.identity(image),link_plan=b.identity(LINK/'link-plan.json'),runtime_environment=b.identity(LINK/'runtime-environment.json')))
    print('LINKED actual Q01',flush=True)
def run(backend):
    ready=c.read(LINK/'ready.json');assert b.identity(ready['image']['path'])==ready['image']
    check_record(c.read(LINK/'link-plan.json')['consumer_record']['path'])
    env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_QWEN')}
    env['PATH']=c.read(LINK/'runtime-environment.json')['PATH'];env['HYLE_QWEN_Q01_ORIGINAL_DIR']=str(S.parent/'original-roles')
    case='QwenMtpStateConsumer.'+backend.title()+'Q01OriginalGptqTargetAndBFloatNextNFullVocabularyVerifierPublishesRepairedPrefix'
    out=S/('checks1' if backend=='cpu' else 'checks2')
    print('START',case,flush=True)
    result=q.execute([ready['image']['path'],'--gtest_filter='+case,'--gtest_output=xml:'+str(out/'results.xml')],env,out,timeout=1800)
    print('END',backend,result['exit'],flush=True)
    if result['exit']:raise SystemExit(result['exit'])
    tree=ET.parse(out/'results.xml').getroot()
    assert int(tree.attrib['tests'])==1 and all(int(tree.attrib.get(k,0))==0 for k in ('failures','disabled','errors'))
    assert not tree.findall('.//skipped')
    props={p.attrib['name']:p.attrib['value'] for p in tree.findall('.//testcase/properties/property')}
    c.save(out/'summary.json',dict(case=case,image=ready['image'],properties=props,process=b.identity(out/'process.json'),
        xml=b.identity(out/'results.xml'),throughput_evidence=False,memory_evidence=False))
    print(props,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('compile','link','cpu','cuda'));a=p.parse_args()
    if a.action=='compile':compile_one()
    elif a.action=='link':link()
    else:run(a.action)
