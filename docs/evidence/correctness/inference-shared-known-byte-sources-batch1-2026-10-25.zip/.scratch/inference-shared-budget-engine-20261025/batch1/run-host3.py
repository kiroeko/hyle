from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-shared-budget-engine-20261025/batch1'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
native=R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,D/'host1/link'/native.name)
env=os.environ.copy();env['PATH']=b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
b.save(D/'host1/runtime3.json',{'PATH':env['PATH'],'native':b.pin(native),'method':'hardlink in executable directory for LOAD_LIBRARY_SEARCH_DEFAULT_DIRS; no copy/build'})
b.execute([str(D/'host1/link/host.exe'),str(D/'host1')],D/'host1/run3',env,60)
