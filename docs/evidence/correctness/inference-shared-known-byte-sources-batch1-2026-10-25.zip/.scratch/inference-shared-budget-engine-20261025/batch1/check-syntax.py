from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path.cwd(); D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('helper',R/'.scratch/mtp-extraction-regression-20261024/check.py'); b=importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
a=b.args(R/'.scratch/inference-request-sampling-20261025/syntax7-final-cpu-cuda/command.json')
a=[str(D/'source/engine/models/qwen35/main.cc') if x.lower().endswith('main.cc') else x for x in a]
# Record the actual current public-header dependencies while parsing this one private TU.
a.insert(1,'/I'+str(R/'.scratch/lease-budget-deallocation-order-20261025/implementation/source/include'))
a+=['/sourceDependencies',str(D/'syntax4-freeze/dependencies.json')]
b.execute(a,D/'syntax4-freeze',b.environment(a[0]),90)

