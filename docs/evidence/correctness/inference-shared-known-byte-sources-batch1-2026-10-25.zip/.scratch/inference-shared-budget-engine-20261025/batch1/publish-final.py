"""Freeze the finite private engine Batch1 checks; no build/run/acquisition."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import zipfile
R=Path.cwd(); D=Path(__file__).resolve().parent
PUBLIC=R/'docs/evidence/correctness'
STEM='inference-shared-known-byte-sources-batch1-2026-10-25'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(data): return hashlib.sha256(data).hexdigest()
def pin(p): return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
def save(p,value): p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')

changed=['engine/inference/readback.h','engine/models/qwen35/fp8_weight_import.h','engine/models/qwen35/main.cc']
patch=''
for name in changed:
    old=(D/'before'/name).read_text().splitlines(keepends=True)
    new=(D/'source'/name).read_text().splitlines(keepends=True)
    patch+=''.join(difflib.unified_diff(old,new,fromfile='a/'+name,tofile='b/'+name))
(D/'final-source.patch').write_text(patch,encoding='utf8')
for item in read(D/'after-pins.json'):
    assert pin(R/item['path'])['sha256']==item['sha256']
for mode in ('host-final1','cuda-final1'):
    for part in ('compile','link','run'):
        assert read(D/mode/part/'process.json')['exit']==0
    for item in read(D/mode/'source-pins.json')['private_sources']:
        assert sha(Path(item['path']).read_bytes())==item['sha256']
cuda=read(D/'cuda-final1/run/stdout.log')
assert cuda['status']=='PASS' and cuda['B_ids']==[33,2,5]
log=(D/'cuda-final1/run/stderr.log').read_text()
stages=[dict(stage=m[0],live=int(m[1]),peak=int(m[2]),limit=int(m[3])) for m in re.findall(
    r'shared_budget_stage=(\w+) live=(\d+) peak=(\d+) limit=(\d+)',log)]
assert stages[-1]['stage']=='all_retired' and stages[-1]['live']==1184
assert max(s['peak'] for s in stages)<=134217728
small=re.search(r'shared_budget_small_peak=(\d+) limit=(\d+)',log)
core=R/'docs/evidence/correctness/compute-lease-retirement-quota-and-readonly-freeze-2026-10-25.json'
summary=dict(status='PASS_PRIVATE_BATCH1_FINAL_GENERIC_FREEZE',canonical_engine_modified=False,
    private_sources=[pin(D/'source'/p) for p in changed],patch=pin(D/'final-source.patch'),
    host=dict(process=read(D/'host-final1/run/process.json'),stdout=(D/'host-final1/run/stdout.log').read_text(),
              build=read(D/'host-final1/ready.json')),
    cuda=dict(process=read(D/'cuda-final1/run/process.json'),actual=cuda,stages=stages,
              small_scope=dict(peak=int(small[1]),limit=int(small[2])),build=read(D/'cuda-final1/ready.json')),
    core_proof=pin(core),core_objects_replaced=['resource_budget.cc','resource_leases.cc'],
    first_failures=[
      dict(attempt='syntax1',kind='consumer API compile error: const caller view conversion',passed=False),
      dict(attempt='syntax2',kind='consumer API compile error: nonexistent BufferView::as_const',passed=False),
      dict(attempt='host1/run and run2',kind='native CPU DLL discovery; LOAD_LIBRARY_SEARCH_DEFAULT_DIRS requires executable-directory DLL, PATH-only did not fix it',passed=False),
      dict(attempt='cuda1/run',kind='consumer compared post-load live bytes with post-prepare bytes; fixed only comparison snapshot timing before A destruction',passed=False)],
    previous_results='Checkpoint1 host1/run3 and cuda2/run passed with old lease core; retained separately and not substituted for final generic-freeze results.',
    GPU_released=True,SDK_full_build=0,HTTP=0,model_payload_copies=0,
    limits=[
      'Batch1 is a private engine source candidate, not canonical engine integration or a complete shared-Model memory cap.',
      'Original per-Model cache budget/max_cache_bytes are preserved separately; cache original backing allocations are not yet consistently gated by the aggregate source scope.',
      'Scope covers explicitly managed original BF16 weights, actual IO staging, Graph import dedup and caller storage. Opaque provider/native-private storage, original file mappings and ordinary STL containers remain excluded.',
      'FP8 canonical and temporary extents/NF4 typed operands are source-wired; this Batch1 proof does not claim new quantized runtime validation.',
      'CUDA fixture uses generated H64/V64/FFN128 A-only weights: 13 Text roles/98944B each, P2/C16/N1R1 per Model. No trained artifact quality or performance claim.',
      'Physical GPU completion at A teardown is unknown; the checked boundary is logical in-flight work, original retirement and B continuation.',
      'Current Backend endpoints use system metadata allocators. An externally supplied custom Budget allocator remains borrowed under its original lifetime contract; a Budget handle is not an owning allocator token.'
    ])
save(D/'final-summary.json',summary)
files=set()
files.update(p for p in (D/'source').rglob('*') if p.is_file())
files.update(D/'before'/name for name in changed)
for name in ('before-pins.json','after-pins.json','source.patch','generic-freeze.patch','final-source.patch',
             'summary.json','final-summary.json','host.cc','consumer.cc','dual-model-case.h',
             'before-dual-model-case.h','check-final.py','check-host.py','check-cuda.py','check-syntax.py',
             'run-host2.py','run-host3.py','root-source-review.md','publish-final.py'):
    files.add(D/name)
for name in ('host-final1','cuda-final1','syntax1','syntax2','syntax3','syntax4-freeze','host1','cuda1','cuda2','checkpoint1'):
    files.update(p for p in (D/name).rglob('*') if p.is_file()
                 and p.suffix in ('.json','.log','.h','.cc','.tsv'))
assert not any(p.suffix in ('.obj','.exe','.dll','.lib','.pdb','.bin') for p in files)
manifest=[pin(p) for p in sorted(files)]
manifest_data=(json.dumps(manifest,indent=2)+'\n').encode()
archive=PUBLIC/(STEM+'.zip'); target=PUBLIC/(STEM+'.json')
assert not archive.exists() and not target.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files): z.write(p,p.relative_to(R).as_posix())
    z.writestr('archive-manifest.json',manifest_data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        data=z.read(item['path']); assert len(data)==item['bytes'] and sha(data)==item['sha256']
proof={**summary,'scope':'Finite source-allocation shared-scope engine Batch1; generic readonly freeze and two refreshed core objects.',
       'archive':{**pin(archive),'members':len(manifest)+1,'crc_verified':True,'member_hashes_verified':True,
                  'logical_bytes':sum(i['bytes'] for i in manifest)+len(manifest_data),'contains_binaries_or_model_payload':False}}
save(target,proof)
save(D/'publication-final.json',dict(json=pin(target),archive=pin(archive),crc_verified=True,member_hashes_verified=True))
print(json.dumps(read(D/'publication-final.json'),indent=2))
