from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent
root = base.parents[2]
summary = json.loads((base / 'final-summary.json').read_text('utf-8-sig'))
assert summary['status'] == 'PASS_PRIVATE_BATCH1_FINAL_GENERIC_FREEZE'
assert summary['host']['process']['exit'] == summary['cuda']['process']['exit'] == 0
assert summary['cuda']['actual']['status'] == 'PASS' and summary['GPU_released']
before = {item['path']: item for item in json.loads((base / 'before-pins.json').read_text('utf-8-sig'))}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def lf(data):
    return data.replace(b'\r\n', b'\n')

changes = []
for item in summary['private_sources']:
    source = root / item['path']
    name = source.relative_to(base / 'source').as_posix()
    target = root / name
    original = target.read_bytes()
    pin = before[name]
    assert len(original) == pin['bytes'] and digest(original) == pin['sha256'], name
    selected = source.read_bytes()
    assert len(selected) == item['bytes'] and digest(selected) == item['sha256'], name
    ending = b'\r\n' if b'\r\n' in original else b'\n'
    output = lf(selected).replace(b'\n', ending)
    changes.append((target, output, dict(path=name,
        before_sha256=digest(original), after_sha256=digest(output), bytes=len(output),
        actual_checked_private_raw_sha256=digest(selected),
        same_normalized_source_as_final_host_and_CUDA_consumer=True)))
assert len(changes) == 3
for target, output, _ in changes:
    target.write_bytes(output)
result = dict(status='EXACT_REVIEWED_BATCH1_ENGINE_INTEGRATION',
              files=[item for _, _, item in changes],
              root_review='Pool-first weight/IO/caller admission; no raw reservation transfer gap; explicit payload replacement; original Backend/ColdResources retirement; platform-independent readonly freeze.',
              additional_build_or_model_run=False,
              tested='One final host consumer and one final dual-Model CUDA consumer using both refreshed foundation objects; original checkpoint results remain separate.',
              remaining='Local cache limit and aggregate cache-source admission still require composition. Original mappings, ordinary STL and opaque provider allocations remain excluded; no physical VRAM or throughput claim.')
(base / 'root-integration.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=result['status'], files=3, checked_source_equal=True), indent=2))
