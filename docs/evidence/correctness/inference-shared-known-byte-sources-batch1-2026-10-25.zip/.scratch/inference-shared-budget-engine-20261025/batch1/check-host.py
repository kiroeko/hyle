from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
out=D/(sys.argv[1] if len(sys.argv)>1 else 'host1');out.mkdir(exist_ok=False)
a=b.args(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/compile-command.json');flags=[];skip=False
for f in a[1:]:
 if skip:skip=False;continue
 if f=='/sourceDependencies':skip=True;continue
 if f.lower().startswith(('/fo','/fd')) or f.lower().endswith(('.cc','.cpp')):continue
 flags.append(f)
env=b.environment(a[0])
b.execute([a[0],*flags,'/Gy',str(D/'host.cc'),'/sourceDependencies',str(out/'compile/dependencies.json'),'/Fo'+str(out/'host.obj')],out/'compile',env,120)
old=b.args(R/'.scratch/inference-request-sampling-20261025/host3/link/command.json');args=[];removed=[]
for f in old[1:]:
 n=f.lower().replace('\\','/')
 if n.endswith(('/cpu-budget-fix1/budget/budget.obj','/host3/host.obj')):removed.append(f);continue
 if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
 args.append(f)
assert len(removed)==2,removed
core=R/'.scratch/inference-shared-requested-budget-20261025/attempt1/core/unit.obj'
b.execute([old[0],*args,str(core),str(out/'host.obj'),'/OPT:REF','/OUT:'+str(out/'link/host.exe'),'/IMPLIB:'+str(out/'link/host.lib')],out/'link',env,120)
env=os.environ.copy();env['PATH']=b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
b.execute([str(out/'link/host.exe'),str(out)],out/'run',env,60)
b.save(out/'summary.json',dict(status='PASS',scope='actual CPU source loader/IO/pool-first import/caller-owner; no Model/GPU/artifact quality',image=b.pin(out/'link/host.exe'),foundation_core=b.pin(core)))
