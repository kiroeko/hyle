"""Final generic-freeze engine consumers, refreshed budget + lease core only."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
R = Path.cwd()
D = Path(__file__).resolve().parent
C = R / '.scratch/lease-budget-deallocation-order-20261025/implementation'
spec = importlib.util.spec_from_file_location('b', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
MODE = sys.argv[1]
OUT = D / ('host-final1' if MODE == 'host' else 'cuda-final1')

def dependencies(folder):
    document = b.read(folder / 'dependencies.json')
    actual = document['Data']
    files = [Path(actual['Source']), *(Path(p) for p in actual['Includes'])]
    b.save(folder / 'repository-inputs.json', [b.pin(p) for p in files if p.is_relative_to(R)])

def compile_link():
    OUT.mkdir(exist_ok=False)
    host = MODE == 'host'
    base = R / '.scratch/inference-request-sampling-20261025' / ('host3' if host else 'cuda1')
    compile_file = R / '.scratch/qwen-pure-cpu-deployment-20261024/current1/compile-command.json' if host else base / 'compile/command.json'
    original = b.args(compile_file)
    flags = []
    skip = False
    for flag in original[1:]:
        if skip:
            skip = False
            continue
        if flag == '/sourceDependencies':
            skip = True
            continue
        if flag.lower().startswith(('/fo', '/fd')) or flag.lower().endswith(('.cc', '.cpp')):
            continue
        flags.append(flag)
    env = b.environment(original[0])
    frozen = [b.pin(p) for p in [D/'source/engine/models/qwen35/main.cc',
        D/'source/engine/inference/readback.h', D/'source/engine/models/qwen35/fp8_weight_import.h',
        D/('host.cc' if host else 'consumer.cc'), *([] if host else [D/'dual-model-case.h'])]]
    core = [C/'attempt1/budget/unit.obj', C/'attempt1/leases/unit.obj']
    b.save(OUT / 'source-pins.json', dict(private_sources=frozen,
        core_objects=[b.pin(p) for p in core], core_source=b.read(C/'after-pins.json'),
        canonical_integration=b.read(C/'root-integration.json')))
    b.execute([original[0], *flags, '/Gy', str(D/('host.cc' if host else 'consumer.cc')),
        '/sourceDependencies',str(OUT/'compile/dependencies.json'),
        '/Fo'+str(OUT/'compile/unit.obj')], OUT/'compile', env, 120)
    dependencies(OUT/'compile')
    assert frozen == [b.pin(Path(p['path'])) for p in frozen]
    old = b.args(base/'link/command.json')
    args = []
    removed = []
    expected = ['/cpu-budget-fix1/budget/budget.obj', '/cpu-budget-fix1/leases/leases.obj',
                '/host3/host.obj' if host else '/inference-request-sampling-20261025/cuda1/compile/unit.obj']
    for flag in old[1:]:
        normalized = flag.lower().replace('\\','/')
        if any(normalized.endswith(end) for end in expected):
            removed.append(flag)
            continue
        if normalized.startswith(('/out:', '/pdb:', '/map:', '/implib:')):
            continue
        args.append(flag)
    assert len(removed) == 3, removed
    b.save(OUT/'link-inputs.json', dict(original=b.pin(base/'link/command.json'), removed=removed,
        replacements=[b.pin(p) for p in core], consumer_object=b.pin(OUT/'compile/unit.obj')))
    b.execute([old[0],*args,*map(str,core),str(OUT/'compile/unit.obj'),'/OPT:REF',
        '/OUT:'+str(OUT/'link/consumer.exe'),'/IMPLIB:'+str(OUT/'link/consumer.lib')], OUT/'link',env,120)
    native = R / ('.scratch/qwen-pure-cpu-deployment-20261024/current1/bin/hyle_ggml_cpu_pure_ffa4_current.dll' if host
        else '.scratch/inference-system-review-20261025/schedule-inputs/link/hyle_ggml_cpu_gdn_scale_v3.dll')
    os.link(native,OUT/'link'/native.name)
    b.save(OUT/'ready.json',dict(image=b.pin(OUT/'link/consumer.exe'),native=b.pin(native),
        core_objects=[b.pin(p) for p in core], refreshed_consumer_TUs=1, SDK_build=0,HTTP=0,GPU_run=False))

def run():
    host = MODE == 'host'
    env = os.environ.copy()
    runtime = R / ('.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json' if host else '.scratch/mtp-performance-convergence-20261025/baseline/runtime.json')
    env.update({k:v for k,v in b.read(runtime).items() if isinstance(v,str)})
    env['PATH'] = str(OUT/'link')+';'+env['PATH']
    b.save(OUT/'runtime.json',dict(PATH=env['PATH'],original=b.pin(runtime)))
    if host:
        args=[str(OUT/'link/consumer.exe'),str(OUT)]
    else:
        (OUT/'output').mkdir(exist_ok=False)
        args=[str(OUT/'link/consumer.exe'),str(R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv'),str(OUT/'output')]
    b.execute(args,OUT/'run',env,60 if host else 180)

assert MODE in ('host','cuda')
compile_link()
run()
