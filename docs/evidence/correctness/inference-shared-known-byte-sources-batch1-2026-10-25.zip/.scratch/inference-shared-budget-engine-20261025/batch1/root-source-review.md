# Batch 1 source review

2026-10-25, root; read-only review of the three private product deltas, not a
build/runtime or complete-budget verdict.

- The explicit Backend-move overload keeps original endpoint addresses and the
  Model-to-ColdResources retirement handoff. No duplicate Backend or registry.
- An empty optional budget retains the existing raw allocation path. The
  explicit shared scope uses existing LeasePool admission before backing
  allocation; ordinary loader ready results retain original domains. Graph
  constants import original read leases, without a raw charge reset/adopt gap.
- Tensor replacement drops ready/writer/pool/buffer together. Existing lease
  domain ownership covers escaped readers; there is no separately moved raw
  Reservation that could release before its old Buffer.
- FP8 uses actual canonical and temporary F32-scale extents; NF4 retains six
  original typed inputs. NF4 validation is metadata plus original offset
  readback, not an omitted hidden graph allocation.
- Actual Graph/phase/literal owners retain the caller pools through the same
  original retirement chain. Source file drain guards are unchanged.
- The per-Model cache Budget remains independent, with its finite primary-row
  limit and cache-only usage checks. This batch does not close combined cache
  admission. Original mappings, ordinary STL metadata and opaque/native-private
  allocations are not covered by the new caller-scope promise.

No blocking source issue found in this slice. A strict interface check and a
finite probe of actual pool-first imports/replacement/IO are still required;
source inspection is not a substitute for those outcomes.
