from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-shared-budget-engine-20261025/batch1'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
env=os.environ.copy();env['PATH']=str(R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link')+';'+b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
b.save(D/'host1/runtime2.json',{'PATH':env['PATH'],'scope':'Existing host3 CPU program expects gdn DLL; this is not a pure CPU deployment proof; no GPU use.'})
b.execute([str(D/'host1/link/host.exe'),str(D/'host1')],D/'host1/run2',env,60)
