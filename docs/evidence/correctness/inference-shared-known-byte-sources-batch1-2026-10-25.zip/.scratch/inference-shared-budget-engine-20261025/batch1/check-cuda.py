from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent;out=D/(sys.argv[2] if len(sys.argv)>2 else 'cuda1')
sp=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
base=R/'.scratch/inference-request-sampling-20261025/cuda1'
def build():
 out.mkdir(exist_ok=False)
 a=b.args(base/'compile/command.json');flags=[];skip=False
 for f in a[1:]:
  if skip:skip=False;continue
  if f=='/sourceDependencies':skip=True;continue
  if f.lower().startswith(('/fo','/fd')) or f.lower().endswith(('.cc','.cpp')):continue
  flags.append(f)
 env=b.environment(a[0]);before=b.pin(D/'source/engine/models/qwen35/main.cc')
 b.execute([a[0],*flags,str(D/'consumer.cc'),'/sourceDependencies',str(out/'compile/dependencies.json'),'/Fo'+str(out/'compile/unit.obj')],out/'compile',env,120)
 assert before==b.pin(D/'source/engine/models/qwen35/main.cc')
 old=b.args(base/'link/command.json');args=[];removed=[]
 for f in old[1:]:
  n=f.lower().replace('\\','/')
  if n.endswith(('/cpu-budget-fix1/budget/budget.obj','/inference-request-sampling-20261025/cuda1/compile/unit.obj')):removed.append(f);continue
  if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
  args.append(f)
 assert len(removed)==2,removed
 core=R/'.scratch/inference-shared-requested-budget-20261025/attempt1/core/unit.obj'
 b.execute([old[0],*args,str(core),str(out/'compile/unit.obj'),'/OUT:'+str(out/'link/consumer.exe'),'/IMPLIB:'+str(out/'link/consumer.lib')],out/'link',env,120)
 native=R/'.scratch/inference-system-review-20261025/schedule-inputs/link/hyle_ggml_cpu_gdn_scale_v3.dll'
 os.link(native,out/'link'/native.name)
 b.save(out/'ready.json',dict(image=b.pin(out/'link/consumer.exe'),source=before,native=b.pin(native),foundation_core=b.pin(core),SDK_build=0,HTTP=0,GPU_run=False))
def run():
 (out/'output').mkdir(exist_ok=False)
 env=os.environ.copy();env.update({k:v for k,v in b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json').items() if isinstance(v,str)})
 env['PATH']=str(out/'link')+';'+env['PATH']
 b.save(out/'runtime.json',{'PATH':env['PATH']})
 b.execute([str(out/'link/consumer.exe'),str(R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv'),str(out/'output')],out/'run',env,180)
if __name__=='__main__':globals()[sys.argv[1]]()
