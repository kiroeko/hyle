#include "source/engine/models/qwen35/main.cc"
#include <cstdio>

namespace q=qwen35;
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
namespace i=hyle::inference;
void require(bool ok,const char *message){if(!ok)throw std::runtime_error(message);}
q::ModelGeometry geometry(){
  q::ModelGeometry v;
  v.hidden=64;v.intermediate=128;v.vocabulary=64;v.query_heads=v.kv_heads=1;
  v.key_depth=v.value_depth=64;v.rotary=16;v.gdn_key_heads=v.gdn_value_heads=1;
  v.gdn_key_depth=v.gdn_value_depth=16;v.conv_kernel=4;v.context_limit=64;
  v.rope_theta=10000;v.epsilon=1e-6F;v.layers="A";v.validate();return v;
}
c::ResourceBudget budget_for(std::span<const m::MemoryResourceRef> resources,std::size_t cap){
  std::vector<c::ResourceBudgetLimit> limits;
  std::vector<m::MemoryResourceRef> rows;
  for(auto r:resources)if(std::ranges::find(rows,r)==rows.end()){rows.push_back(r);limits.push_back({r});}
  return q::take(c::ResourceBudget::create({.limits=limits,.allow_unattributed=true},rows,cap));
}
std::size_t external(const c::ResourceBudget &budget,m::MemoryResourceRef r){
  return q::take(budget.usage(r)).live_by_category[static_cast<std::size_t>(c::ResourceBudgetCategory::kExternal)];
}
q::prepared::Roles roles(const std::filesystem::path &path){
  q::prepared::Roles result;result.geometry=geometry();result.identity="host-generated-single-role";
  result.selected.push_back({"model.norm.weight","BF16",{64},path,0,128});result.bytes=128;return result;
}
int main(int argc,char **argv){try{
  require(argc==2,"host output directory required");const std::filesystem::path output=argv[1];
  auto a=q::take(i::Backend::create({.primary=i::BackendKind::kCpu}));
  auto b=q::take(i::Backend::create({.primary=i::BackendKind::kCpu}));
  auto scope=budget_for(std::array{a.device(),a.staging(),b.device(),b.staging(),m::system_resource()},128u<<20);
  const auto baseline=scope.shared_usage()->live_bytes;
  std::ofstream file(output/"single-role.bin",std::ios::binary);
  const std::array<std::uint16_t,64> payload{};file.write(reinterpret_cast<const char*>(payload.data()),sizeof(payload));file.close();
  require(bool(file),"generated role write failed");
  auto source=roles(output/"single-role.bin");
  std::map<std::string,q::LoadedWeight> aw,bw;std::vector<c::LeasePool> ap,bp;
  const auto al=q::load_selected_weight_roles(source,a,aw,ap,0,scope);
  const auto bl=q::load_selected_weight_roles(source,b,bw,bp,0,scope);
  require(al.bytes==128&&bl.bytes==128&&aw.size()==1&&bw.size()==1,"actual loader inventory differs");
  require(al.stream.staging_bytes&&bl.stream.staging_bytes,"actual IO staging was not prepared");
  const auto loaded=scope.shared_usage()->live_bytes;
  require(loaded>baseline+256,"IO/metadata not visible in the shared scope");
  auto alias=aw.begin()->second.tensor.ready;
  const auto imported=external(scope,a.device());
  q::check(c::detail::LeaseAccess::retain_budget(alias,a.device(),scope));
  require(external(scope,a.device())==imported,"source/import payload was charged twice");
  std::array<std::byte,128> observed{};q::check(q::take(alias.view()).read(observed));
  aw.clear();ap.clear();alias.reset();
  require(scope.shared_usage()->live_bytes<loaded,"retired loader A did not release its source allocations");
  std::array<std::byte,128> observed_b{};q::check(q::take(bw.begin()->second.tensor.ready.view()).read(observed_b));
  require(observed_b==observed,"retiring A changed B source backing");
  {
    auto small=budget_for(std::array{a.device(),a.staging(),m::system_resource()},1u<<20);
    std::map<std::string,q::LoadedWeight> weights;std::vector<c::LeasePool> pools;bool failed=false;
    try{(void)q::load_selected_weight_roles(source,a,weights,pools,0,small);}catch(const std::runtime_error&){failed=true;}
    require(failed&&weights.empty()&&pools.empty(),"small IO admission did not reject before role allocation");
    std::printf("small_io_rejected_before_weights=1 peak=%zu limit=%zu\n",small.shared_usage()->peak_bytes,small.shared_usage()->limit_bytes);
  }
  {
    const auto before=external(scope,m::system_resource());
    q::Tensor value(m::system_resource(),q::dense(q::Type::kFloat32,{16}),true,scope);value.zero();value.freeze(a);
    auto old=value.ready;require(external(scope,m::system_resource())==before+64,"initial Tensor source charge differs");
    value=q::Tensor(m::system_resource(),q::dense(q::Type::kFloat32,{24}),true,scope);
    require(external(scope,m::system_resource())==before+64+96,"replacement released an escaped original backing charge");
    auto uses=q::take(c::LeaseUsePool::create({.max_batches=1,.max_resources_per_batch=1}));
    auto use=q::take(uses.begin());q::check(use.read(old));auto retired=c::Completion::completed();q::check(use.attach(retired));
    old.reset();retired={};
    require(external(scope,m::system_resource())==before+96,"old Tensor source did not retire exactly once");
  }
  {
    auto builder=q::take(g::GraphBuilder::create());const auto desc=q::dense(q::Type::kFloat32,{4});
    const auto x=q::take(builder.input(desc)),y=q::take(builder.add(c::Unary{c::UnaryKind::kNeg},x));q::check(builder.publish(y));
    auto graph=q::take(std::move(builder).finish());auto compiled=q::take(a.compile(graph,{}, {.resource_budget=scope}));
    q::Tensor input(a.device(),desc,true,scope);const std::array<float,4> values{1,2,3,4};input.write<float>(values);input.freeze(a);
    auto readback=q::take(i::PreparedReadback::prepare(compiled,y,a,scope));require(readback.facts.caller_owned(),"CPU output was not the expected original caller route");
    auto run=q::take(compiled.executable.create_invocation());q::check(run.prepare_resources({.resource_budget=scope}));
    const auto before=external(scope,a.device());q::check(run.bind(x,desc,input.ready));q::check(readback.bind(run));
    auto selected=q::take(i::prepare_queue_bindings(a.queue_bindings(),compiled.report));const auto queues=i::queue_span(selected);
    q::check(run.prepare_replay(queues,{.mode=g::ReplayMode::kCommands}));
    require(external(scope,a.device())==before,"actual Graph binding double-charged the original input/caller backing");
    auto done=q::take(run.submit(queues));q::check(done.wait());std::array<float,4> result{};q::check(readback.read(a,run,std::as_writable_bytes(std::span(result))));
    for(std::size_t n=0;n<result.size();++n)require(result[n]==-values[n],"budgeted caller readback changed exact CPU output");
    done={};q::check(run.close());q::check(a.drain_retired(run));
    readback=q::take(i::PreparedReadback::prepare(compiled,y,a,scope));
  }
  bw.clear();bp.clear();require(scope.shared_usage()->live_bytes==baseline,"source owner/IO/caller allocations leaked their shared charges");
  std::printf("PASS actual two CPU endpoints, pool-first loader+IO, import dedup, small IO rejection, escaped Tensor replacement/readmission, exact Graph caller readback; no Model/weights artifact/GPU\n");
  return 0;
}catch(const std::exception &error){std::fprintf(stderr,"FAIL %s\n",error.what());return 1;}}
