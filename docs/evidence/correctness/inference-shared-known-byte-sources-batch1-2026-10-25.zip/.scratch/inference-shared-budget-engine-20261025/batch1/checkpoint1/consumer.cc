#include "source/engine/models/qwen35/main.cc"
#include "dual-model-case.h"
int main(int argc,char **argv){try{
  if(argc!=3)throw std::runtime_error("cached generated fixture and output directory required");
  const std::filesystem::path input=argv[1],folder=argv[2];
  const auto geometry=qwen35::read_weight_geometry(input);
  const auto inventory=qwen35::prepared::parameter_inventory(false,geometry);std::set<std::string> required;
  for(const auto &[name,spec]:inventory){(void)spec;required.insert(name);}
  std::ifstream source(input);if(!source)throw std::runtime_error("cached fixture missing");
  const auto output=folder/"text-weights.tsv";std::ofstream target(output);
  std::string line;for(int at=0;at<3;++at){if(!std::getline(source,line))throw std::runtime_error("short fixture preamble");target<<line<<'\n';}
  while(std::getline(source,line)){std::istringstream fields(line);std::string name;fields>>name;if(required.erase(name))target<<line<<'\n';}
  if(!source.eof()||!required.empty()||!target)throw std::runtime_error("incomplete Text-only generated fixture");target.close();
  return qwen_dual_model_case::run(output);
}catch(const std::exception &error){std::cerr<<error.what()<<'\n';return 1;}}
