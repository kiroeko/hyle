"""Append exact canonical integration evidence; preserve all checked raw inputs."""
from pathlib import Path
import hashlib,json,os,zipfile
R=Path.cwd();D=Path(__file__).resolve().parent
P=R/'docs/evidence/correctness/inference-shared-known-byte-sources-batch1-2026-10-25.json'
Z=P.with_suffix('.zip')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(data):return hashlib.sha256(data).hexdigest()
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=digest(p.read_bytes()))
proof=read(P);assert proof['archive']['sha256']==digest(Z.read_bytes())
receipt=read(D/'root-integration.json')
for row in receipt['files']:
    assert row['same_normalized_source_as_final_host_and_CUDA_consumer']
    assert digest((R/row['path']).read_bytes())==row['after_sha256']
with zipfile.ZipFile(Z) as z:
    assert z.testzip() is None
    entries={info.filename:z.read(info.filename) for info in z.infolist() if info.filename!='archive-manifest.json'}
for name in ('integrate-reviewed.py','root-integration.json','record-integration.py'):
    p=D/name;entries[p.relative_to(R).as_posix()]=p.read_bytes()
manifest=[dict(path=name,bytes=len(data),sha256=digest(data)) for name,data in sorted(entries.items())]
manifest_data=(json.dumps(manifest,indent=2)+'\n').encode()
temporary=D/'integrated-proof.zip'
assert not temporary.exists()
with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
    z.writestr('archive-manifest.json',manifest_data)
with zipfile.ZipFile(temporary) as z:
    assert z.testzip() is None
    for row in manifest:
        data=z.read(row['path']);assert len(data)==row['bytes'] and digest(data)==row['sha256']
os.replace(temporary,Z)
proof['status']='PASS_BATCH1_CANONICAL_SOURCE_INTEGRATED'
proof['canonical_engine_modified']=True
proof['integration']=dict(record=pin(D/'root-integration.json'),status=receipt['status'],
    additional_build_or_model_run=False,normalized_checked_source_equal=True,
    note='Exact checked source integrated by root, preserving original line endings; runtime facts remain the finite private final host/CUDA consumers.')
proof['limits'][0]='Batch1 source is canonically integrated; this finite slice is not a complete shared-Model memory cap.'
proof['archive']={**pin(Z),'members':len(manifest)+1,'crc_verified':True,'member_hashes_verified':True,
    'logical_bytes':sum(i['bytes'] for i in manifest)+len(manifest_data),'contains_binaries_or_model_payload':False}
P.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
result=dict(json=pin(P),archive=pin(Z),members=len(manifest)+1,crc_verified=True,member_hashes_verified=True)
(D/'publication-integrated.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
