"""Original seven journeys and the existing GraphSlotsExecution group; root runs."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cohort_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
t=b.t
PREVIOUS=b.BASE/'run.py'
spec=importlib.util.spec_from_file_location('previous_preparation_runs',PREVIOUS)
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
CASES=dict(previous.CASES)
CASES.update({'logits-cpu':('tiny',['--cpu',str(previous.FIXTURE),'--mtp-logits']),
    'logits-cuda':('tiny',['--cuda',str(previous.FIXTURE),'--mtp-logits'])})
CASES['slots-graph']=('slots-test',['--gtest_filter=GraphSlotsExecution.*',
    '--gtest_output=xml:'+str(W/'runs/slots-graph/report.xml')])


def prepare():
    b.validate();ready={n:t.read(W/f'ready-{n}.json') for n in b.CONSUMERS}
    for name,row in ready.items():
        t.exact(row['image']);t.exact(row['inputs'])
        assert set(row['compiled'])=={'resources','slots-region',name}
    t.save(W/'run-plan.json',dict(script=t.pin(__file__),parser=t.pin(W/'parse.py'),
        reused_runs=t.pin(PREVIOUS),reused_parser=t.pin(b.BASE/'parse.py'),
        reused_logits_parser=t.pin(b.R/'.scratch/inference-execution-episode-20261028/parse.py'),
        fixture=t.pin(previous.FIXTURE/'weights.tsv'),runtime=t.pin(W/'runtime.json'),
        cases={name:dict(consumer=unit,ready=t.pin(W/f'ready-{unit}.json'),
            command=[ready[unit]['image']['path'],*args]) for name,(unit,args) in CASES.items()},
        native_processes=10,automatic_retries=0,
        scope='The original seven preparation journeys plus the existing CPU/CUDA MTP-logits journeys, and the existing GraphSlotsExecution.* group including the new cohort-take test. compiled is a map of the two replaced SDK TUs and each consumer. No performance or new test matrix.'))
    print('RUN PLAN READY10; no native process started')


def parse_case(name):
    spec=importlib.util.spec_from_file_location('cohort_parser',W/'parse.py')
    parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
    parser.parse_case(name)
    print('OFFLINE PASS',name)


def run(name):
    b.validate();plan=t.read(W/'run-plan.json')
    for key in ('script','parser','reused_runs','reused_parser','reused_logits_parser','fixture','runtime'):t.exact(plan[key])
    row=plan['cases'][name];t.exact(row['ready']);ready=t.read(row['ready']['path']);t.exact(ready['image'])
    out=W/'runs'/name;assert not out.exists(),'Never rerun or overwrite any native attempt'
    t.execute(row['command'],out,300);parse_case(name)


if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='run':run(sys.argv[2])
    elif sys.argv[1]=='parse':parse_case(sys.argv[2])
    else:raise ValueError(sys.argv[1])
