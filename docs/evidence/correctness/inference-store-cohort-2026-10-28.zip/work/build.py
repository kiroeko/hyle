"""Five explicit incremental CXX actions, three links; root owns native work."""
from pathlib import Path
import importlib.util
import re
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-execution-preparation-20261028'
SDK = R / '.scratch/inference-indexed-store-20261028'
spec = importlib.util.spec_from_file_location('original_cohort_driver', SDK / 'build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W
SOURCES = {'resources':'src/graph/resources.cc', 'slots-region':'src/graph/slots_region.cc',
    'slots-test':'tests/graph/slots_execution_test.cc', 'tiny':'tests/tools/qwen_host_image_test.cc',
    'submission-source':'tests/tools/qwen_submission_source_probe.cc'}
CONSUMERS = ('slots-test','tiny','submission-source')
AUTHORED = [*SOURCES.values(), 'include/hyle/graph/slots.h',
    'include/hyle/graph/detail/region_access.h', 'engine/inference/slot_transactions.h',
    'engine/inference/program_io.h', 'engine/models/qwen35/main.cc',
    'tests/tools/qwen_generation_state_case.h']


def prepare():
    ready = t.read(BASE/'ready-tiny.json'); t.exact(ready['inputs'])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 228
    old = {'consumer':ready['compiled']['object']}; units = {}
    for name,source in SOURCES.items():
        prior = t.read(SDK/f'compile/{name}/compiled.json') if name in ('resources','slots-region') else ready['compiled']
        if name in ('resources','slots-region'):
            old[name] = prior['object']; assert prior['object'] in rows
        before = t.command(prior['command']['path'])
        prior_source = t.read(prior['dependencies']['path'])['Data']['Source']
        args = []
        for i,arg in enumerate(before):
            if t.key(arg) == t.key(prior_source): arg = str(R/source)
            elif i and before[i-1].lower() == '/sourcedependencies': arg = str(W/f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo'+str(W/f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd'+str(W/f'compile/{name}/unit.pdb')
            else: arg = arg.replace(str(SDK/'source'),str(R))
            args.append(arg)
        assert '/MD' in args and '/O2' in args and '/WX' in args
        assert not any(str(SDK/'source').casefold() in a.casefold() for a in args)
        t.save(W/f'recipes/{name}.json',dict(command=args,timeout_seconds=300))
        units[name] = dict(source=source, original_command=prior['command'],
            original_dependencies=prior['dependencies'], recipe=t.pin(W/f'recipes/{name}.json'))
    assert old['consumer'] in rows
    gtest = [t.pin(R/f'.scratch/build-compute-v2-dev/lib/{n}.lib') for n in ('gtest_main','gtest')]
    for name in CONSUMERS:
        mapping = {t.key(old[n]['path']):str(W/f'compile/{n}/unit.obj') for n in ('resources','slots-region')}
        mapping[t.key(old['consumer']['path'])] = str(W/f'compile/{name}/unit.obj')
        args = []
        for arg in t.command(ready['recipe']['path']):
            arg = mapping.get(t.key(arg),arg)
            for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
                if arg.upper().startswith(prefix): arg = prefix+str((W/'bin'/name).with_suffix(suffix)); break
            args.append(arg)
        if name == 'slots-test': args.extend(p['path'] for p in gtest)
        assert all(sum(t.key(a)==t.key(v) for a in args)==1 for v in mapping.values())
        t.save(W/f'link-recipes/{name}.json',dict(command=args,timeout_seconds=240))
    excluded = {t.key(p['path']) for p in old.values()}
    stats = []
    for row in [r for r in rows if t.key(r['path']) not in excluded]+gtest:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'],bytes=st.st_size,mtime_ns=st.st_mtime_ns,retained_sha256=row['sha256']))
    t.save(W/'retained-input-stats.json',stats)
    env = t.read(BASE/'environment.json'); env['PATH'] = str(W/'bin')+';'+env['PATH']
    t.save(W/'environment.json',env)
    t.save(W/'runtime.json',dict(PATH=env['PATH'],native=t.read(BASE/'runtime.json')['native']))
    t.save(W/'expected-sources.json',{s:t.pin(R/s)['sha256'] for s in AUTHORED})
    t.save(W/'final-build-plan.json',dict(baseline=t.pin(BASE/'ready-tiny.json'),inputs=ready['inputs'],
        original_objects=old, units=units, gtest=gtest, original_driver=t.pin(SDK/'build.py'),
        environment=t.pin(W/'environment.json'),runtime=t.pin(W/'runtime.json'),
        retained_stats=t.pin(W/'retained-input-stats.json'),expected=t.pin(W/'expected-sources.json'),
        links={n:t.pin(W/f'link-recipes/{n}.json') for n in CONSUMERS},
        counts=dict(CXX=5,SDK_CXX=2,consumer_CXX=3,links=3,NVCC=0,downloads=0,
            ordinary_inputs=228,graph_test_inputs=230,ordinary_retained_inputs=225),
        scope='Only resources/slots_region are replaced in the original SDK closure. Three existing consumers; gtest uses the same closure plus its two retained framework libraries. No CLI, SDK clone or native execution implied.'))
    print('PREPARED 5CXX/3links, retained228 closure; no compiler/native process')


def plan():
    value = t.read(W/'final-build-plan.json')
    for key in ('baseline','inputs','original_driver','environment','runtime','retained_stats','expected'): t.exact(value[key])
    for row in value['units'].values():
        for key in ('original_command','original_dependencies','recipe'): t.exact(row[key])
    for row in value['links'].values(): t.exact(row)
    return value


def freeze():
    value = plan(); expected = t.read(value['expected']['path'])
    for relative,sha in expected.items(): assert t.pin(R/relative)['sha256'] == sha,relative
    paths = {}; roots = [R/'include',R,R/'tests/graph',R/'src/graph']; pending = [R/s for s in expected]
    for unit in value['units'].values():
        for p in t.dep_paths(unit['original_dependencies']['path']):
            p = t.canonical(p)
            if t.project(p): paths[t.key(p)] = p
        roots.extend(Path(a[2:]) for a in t.command(unit['recipe']['path']) if a.lower().startswith('/i'))
    seen = set()
    while pending:
        p = pending.pop().resolve()
        if t.key(p) in seen: continue
        seen.add(t.key(p)); paths[t.key(p)] = p
        for kind,name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]',p.read_text(encoding='utf-8-sig'),re.M):
            q = next((v.resolve() for root in ([p.parent] if kind=='"' else [])+roots if (v:=root/name).is_file()),None)
            if q is not None and t.project(q): pending.append(q)
    t.save(W/'frozen-project-dependencies.json',[t.pin(p) for p in paths.values()])
    snapshots = []
    for relative in expected:
        target = W/'source'/relative; target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out: out.write((R/relative).read_bytes())
        snapshots.append(dict(original=t.pin(R/relative),snapshot=t.pin(target)))
    t.save(W/'final-source-freeze.json',dict(helper=t.pin(__file__),dependencies=t.pin(W/'frozen-project-dependencies.json'),snapshots=snapshots))
    print('SOURCE FROZEN',len(paths),'project dependencies; no native process')


def validate():
    value = plan(); frozen = t.read(W/'final-source-freeze.json')
    t.exact(frozen['helper']);t.exact(frozen['dependencies'])
    for row in t.read(frozen['dependencies']['path']):t.exact(row)
    for row in frozen['snapshots']:t.exact(row['original']);t.exact(row['snapshot'])
    return value,frozen


def parse_compile(name):
    value,frozen = validate(); out = W/'compile'/name; process = t.read(W/f'logs/{name}/process.json')
    assert process['exit']==0 and not process['timed_out']
    allowed = {t.key(p['path']):p for p in t.read(frozen['dependencies']['path'])}; actual = []
    for p in dict.fromkeys(t.dep_paths(out/'dependencies.json')):
        if t.project(p):
            assert t.key(p) in allowed,('Metadata error after successful CXX; repair parser only, never recompile',str(p))
            t.exact(allowed[t.key(p)])
        actual.append(t.pin(p))
    t.save(out/'actual-dependencies.json',actual)
    t.save(out/'compiled.json',dict(source=t.pin(R/SOURCES[name]),object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/f'logs/{name}/command.json'),dependencies=t.pin(out/'dependencies.json'),actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('CXX metadata PASS',name)


def compile_unit(name):
    value,_ = validate(); assert name in SOURCES
    (W/'compile'/name).mkdir(parents=True,exist_ok=False)
    t.execute(t.command(value['units'][name]['recipe']['path']),W/'logs'/name,300);parse_compile(name)


def link_unit(name):
    value,_ = validate(); assert name in CONSUMERS
    compiled = {n:t.read(W/f'compile/{n}/compiled.json') for n in ('resources','slots-region',name)}
    for row in compiled.values(): t.exact(row['object'])
    for row in t.read(value['retained_stats']['path']):
        st = Path(row['path']).stat(); assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    original = t.read(value['inputs']['path'])
    replacements = {t.key(value['original_objects'][n]['path']):compiled[n]['object'] for n in ('resources','slots-region')}
    replacements[t.key(value['original_objects']['consumer']['path'])] = compiled[name]['object']
    rows = [replacements.get(t.key(row['path']),row) for row in original]
    assert len(rows)==228 and sum(a!=b for a,b in zip(rows,original))==3
    if name=='slots-test': rows += value['gtest']
    t.save(W/f'inputs-{name}.json',rows)
    (W/'bin').mkdir(exist_ok=True); native=t.read(value['runtime']['path'])['native']; alias=W/'bin'/Path(native['path']).name
    if not alias.exists():alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    process=t.execute(t.command(value['links'][name]['path']),W/'links'/name,240)
    t.save(W/f'ready-{name}.json',dict(image=t.pin(W/f'bin/{name}.exe'),inputs=t.pin(W/f'inputs-{name}.json'),
        compiled=compiled,process=process,recipe=t.pin(W/f'links/{name}/command.json'),runtime=value['runtime'],source_freeze=t.pin(W/'final-source-freeze.json')))
    print('LINK PASS',name)


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='preflight':validate()
    elif action=='compile':compile_unit(sys.argv[2])
    elif action=='parse-compile':parse_compile(sys.argv[2])
    elif action=='link':link_unit(sys.argv[2])
    else:raise ValueError(action)
