"""Pure offline checks, reusing the seven journeys' original strict observer."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
PREVIOUS=W.parent/'inference-execution-preparation-20261028/parse.py'
spec=importlib.util.spec_from_file_location('previous_seven_preparation_observer',PREVIOUS)
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
CASES=dict(previous.CASES)
CASES.update({name:previous.previous.CASES[name] for name in ('logits-cpu','logits-cuda')})


def read(path):return json.loads(path.read_bytes())
def pin(path):
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def parse_case(name):
    directory=W/'runs'/name
    process=read(directory/'process.json');command=read(directory/'command.json')
    assert process['exit']==0 and process['state']=='TERMINAL' and not process['timed_out'],name
    files=['command.json','process.json','stdout.log','stderr.log']
    if name=='slots-graph':
        assert '--gtest_filter=GraphSlotsExecution.*' in command['command']
        source=W/'source/tests/graph/slots_execution_test.cc'
        expected=set(re.findall(r'TEST\s*\(\s*GraphSlotsExecution\s*,\s*(\w+)\s*\)',source.read_text(encoding='utf-8')))
        assert 'CohortTakeRejectsWithoutMovingAndReturnsRetiredOriginalOwners' in expected
        root=ET.parse(directory/'report.xml').getroot()
        rows=root.findall('testsuite/testcase')
        assert len(rows)==len(expected) and {row.attrib['name'] for row in rows}==expected
        assert root.attrib['failures']==root.attrib['errors']=='0'
        for row in rows:
            assert row.attrib['classname']=='GraphSlotsExecution' and row.attrib['status']=='run'
            assert not row.findall('failure') and not row.findall('skipped')
            assert row.attrib.get('result','completed')=='completed'
        report=dict(status='PASS',gtest_filter='GraphSlotsExecution.*',actual_tests=len(rows),
            tests=sorted(expected),new_cohort_test=True,failures=0,skipped=0)
        files.append('report.xml')
    else:
        backend,kind,option=CASES[name]
        assert '--'+backend in command['command'] and option in command['command'],name
        reports=[json.loads(line) for line in (directory/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert len(reports)==1,(name,len(reports))
        report=reports[0]
        if kind=='logits':previous.previous.check_report(report,backend,kind)
        else:previous.check_report(report,backend,kind)
    return dict(name=name,status='PASS',process=process,command=command,report=report,
        evidence=[pin(directory/f) for f in files])


def main():
    cases=[parse_case(n) for n in [*CASES,'slots-graph']]
    assert len({row['process']['pid'] for row in cases})==10
    comparisons=[]
    for row in cases[:-1]:comparisons.extend(previous.state_rows(row['report'],CASES[row['name']][1]))
    assert len(comparisons)==32
    logits_checks=sum(len(row['report'].get('state_checks',[])) for row in cases if row['name'] in ('logits-cpu','logits-cuda'))
    assert logits_checks==20
    result=dict(status='PASS_STORE_COHORT_AND_NINE_FINITE_PREPARATION_CASES',native_processes=10,native_retries=0,
        graph_tests=cases[-1]['report']['actual_tests'],state_comparisons=len(comparisons),
        logits_byte_exact_state_checks=logits_checks,
        byte_exact_state_comparisons=sum(row['payloads_byte_equal'] for row in comparisons),
        maximum_gdn_absolute_difference=max((item['maximum_absolute'] for row in comparisons for item in row['differences']),default=0),
        original_gdn_absolute_budget=0.000003,
        note='Only newly computed F32 GDN differences use the unchanged component-oracle bound; all other payloads, old snapshots, boundaries and RNG remain exact. Graph count comes from actual XML and must equal this frozen source group. No performance, quality, full matrix or unknown-retirement claim.',
        parser=pin(Path(__file__)),reused_parser=pin(PREVIOUS),reused_logits_parser=pin(previous.PREVIOUS),cases=cases)
    (W/'analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['status','native_processes','graph_tests','state_comparisons','byte_exact_state_comparisons','maximum_gdn_absolute_difference']}))


if __name__=='__main__':main()
