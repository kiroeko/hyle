"""Package this completed functional slice offline; execute only after timing ends."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parent.parent
DEST=R/'docs/evidence/correctness/inference-store-cohort-2026-10-28'
UNITS=('resources','slots-region','slots-test','tiny','submission-source')
CONSUMERS=('slots-test','tiny','submission-source')


def read(path):return json.loads(Path(path).read_bytes())
def digest(data):return hashlib.sha256(data).hexdigest()
def body(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
def pin(path):
    path=Path(path);data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=digest(data))
def exact(path,expected):
    value=pin(path)
    assert(value['bytes'],value['sha256'])==(expected['bytes'],expected['sha256']),str(path)


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(),'Preserve previous package'
    spec=importlib.util.spec_from_file_location('strict_cohort_parser',W/'parse.py')
    parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
    analysis=read(W/'analysis.json')
    assert analysis['status']=='PASS_STORE_COHORT_AND_NINE_FINITE_PREPARATION_CASES'
    assert analysis['native_processes']==10 and analysis['graph_tests']==11
    assert analysis['state_comparisons']==32 and analysis['byte_exact_state_comparisons']==2
    assert analysis['logits_byte_exact_state_checks']==20 and analysis['original_gdn_absolute_budget']==3e-6
    assert analysis['maximum_gdn_absolute_difference']<=3e-6
    members={}

    def add(path,name=None):
        path=Path(path);name=name or 'work/'+path.relative_to(W).as_posix()
        assert name not in members and not name.lower().endswith(('.exe','.obj','.dll','.lib','.pdb','.bin','.safetensors','.gguf'))
        members[name]=path.read_bytes()

    for name in ['build.py','run.py','parse.py','evidence.py','analysis.json','run-plan.json',
        'final-build-plan.json','final-source-freeze.json','frozen-project-dependencies.json',
        'expected-sources.json','retained-input-stats.json','runtime.json','product.patch','base-commit.txt']:
        add(W/name)
    # Keep this slice's diff supplied by root, not a reconstructed or guessed
    # pre-change source tree. The actual tested after-snapshots are independent.
    assert members['work/product.patch'].strip()
    for key,label in [('reused_parser','preparation'),('reused_logits_parser','episode-logits')]:
        row=analysis[key];exact(row['path'],row);add(row['path'],f'helpers/reused-{label}-parser.py')
    freeze=read(W/'final-source-freeze.json');exact(W/'build.py',freeze['helper'])
    sources=[]
    for row in freeze['snapshots']:
        exact(row['original']['path'],row['original']);exact(row['snapshot']['path'],row['snapshot'])
        relative=Path(row['original']['path']).relative_to(R).as_posix()
        add(row['snapshot']['path'],'source/after/'+relative)
        sources.append(dict(file=relative,identity=row['original']))
    # Only metadata identities, never SDK/compiler/model/object payloads.
    plan=read(W/'final-build-plan.json');base=read(plan['inputs']['path'])
    assert len(base)==228 and plan['counts']['CXX']==5 and plan['counts']['SDK_CXX']==2
    assert plan['counts']['links']==3 and plan['counts']['NVCC']==0
    members['identity/base-link-inputs.json']=body(base)
    for category,names in [('logs',UNITS),('links',CONSUMERS)]:
        assert sorted(path.parent.name for path in (W/category).glob('*/process.json'))==sorted(names)
    compilations=[];compiled={};dependencies={}
    for name in UNITS:
        value=read(W/f'compile/{name}/compiled.json');process=read(W/f'logs/{name}/process.json')
        assert value['process']==process and process['exit']==0 and not process['timed_out']
        compiled[name]=value;compilations.append(dict(name=name,compilation=value))
        for f in [f'recipes/{name}.json',f'compile/{name}/compiled.json',f'compile/{name}/dependencies.json']:
            add(W/f)
        for f in ['command.json','process.json','stdout.log','stderr.log']:add(W/'logs'/name/f)
        for row in read(W/f'compile/{name}/actual-dependencies.json'):
            key=row['path'].replace('\\','/').casefold()
            if key in dependencies:assert dependencies[key]==row
            else:dependencies[key]=row
    members['identity/actual-dependency-identities.json']=body(list(dependencies.values()))
    assert len({row['compilation']['process']['pid'] for row in compilations})==5
    closures=[]
    for name in CONSUMERS:
        ready=read(W/f'ready-{name}.json');link=read(W/f'links/{name}/process.json')
        assert ready['process']==link and link['exit']==0 and not link['timed_out']
        assert ready['compiled']=={n:compiled[n] for n in ('resources','slots-region',name)}
        replacements={row['path']:compiled[n]['object'] for n,row in plan['original_objects'].items() if n!='consumer'}
        replacements[plan['original_objects']['consumer']['path']]=compiled[name]['object']
        expected=[replacements.get(row['path'],row) for row in base]
        assert sum(a!=b for a,b in zip(expected,base))==3
        if name=='slots-test':expected+=plan['gtest']
        assert read(ready['inputs']['path'])==expected and len(expected)==(230 if name=='slots-test' else 228)
        exact(ready['inputs']['path'],ready['inputs'])
        closures.append(dict(name=name,image=ready['image'],link=link,inputs=ready['inputs'],
            object_count=len(expected),replaced_sdk_objects=2,replaced_consumer_objects=1))
        for f in [f'link-recipes/{name}.json',f'ready-{name}.json',f'inputs-{name}.json']:add(W/f)
        for f in ['command.json','process.json','stdout.log','stderr.log']:add(W/'links'/name/f)
    run_plan=read(W/'run-plan.json');names=[*parser.CASES,'slots-graph']
    assert set(run_plan['cases'])==set(names) and len(names)==10
    assert sorted(path.parent.name for path in (W/'runs').glob('*/process.json'))==sorted(names)
    native=[]
    for saved in analysis['cases']:
        name=saved['name'];row=parser.parse_case(name)
        assert row==saved and row['command']['command']==run_plan['cases'][name]['command']
        native.append(dict(name=name,process=row['process'],
            kind='GraphSlotsExecution' if name=='slots-graph' else parser.CASES[name][1]))
        for file in row['evidence']:add(file['path'])
    assert len(native)==len({row['process']['pid'] for row in native})==10
    host_cost=None
    # Optional old-profile analysis is provenance only. No SQLite capture or
    # profile execution belongs to these new functional consumer counts.
    reference=W/'host-cost-reference.json'
    if reference.exists():
        host_cost=read(reference);add(reference)
        for row in host_cost.get('files',[]):
            exact(row['path'],row);add(row['path'],'research/'+Path(row['path']).name)
    else:
        old_profile=W.parent/'inference-current-host-profile-20261028'
        files=[old_profile/'mtp-host-cost.py',old_profile/'mtp-host-cost.json',
            R/'docs/evidence/performance/inference-current-host-profile-2026-10-28.json']
        if all(path.is_file() for path in files):
            host_cost=dict(files=[pin(path) for path in files],
                scope='Offline attribution of the older retained four-profile window; candidate location and upper bound only, never current throughput gain attribution. SQLite and the previous ZIP are not copied.')
            for path in files:add(path,'research/'+path.name)
    summary=dict(schema='hyle.store-cohort.finite-correctness.v1',status=analysis['status'],
        scope='Original Store-cohort recovery and ordinary/NextN ProgramIo cold installation. Existing Graph permission, Source ownership, numerical and retirement contracts remain authoritative.',
        claims=dict(performance_improvement=False,complete_inference_core=False,complete_Model_extraction=False,
            native_unknown_retirement_tested=False,all_withdrawal_work_linear=False),
        actual_counts=dict(CXX=5,SDK_CXX=2,consumer_CXX=3,links=3,native_processes=10,GraphSlotsExecution_tests=11,NVCC=0,downloads=0),
        excluded_CLI=dict(CXX=1,links=1,reason='Separate CLI build and 16-process performance experiment; not counted or archived as this functional slice.'),
        state_comparisons=dict(total=32,byte_exact=2,bounded_new_f32_gdn=30,
            maximum_absolute_difference=analysis['maximum_gdn_absolute_difference'],unchanged_absolute_budget=3e-6,
            nonfinite_differences_allowed=False,other_payloads='byte_exact',old_snapshots='byte_exact',boundaries_and_RNG='exact'),
        logits_state_checks=dict(total=20,byte_exact=20,from_cases=['logits-cpu','logits-cuda']),
        preserved_contracts=[
            'The existing per-bank has_* ownership and structural checks remain; bulk withdrawal reduces repeated closure/withdrawal work, not all work to strict linear complexity.',
            'Rejected cohort take moves no original transaction; original single take and partially returned cohort recovery remain supported.',
            'Imported read permissions remain owned by their original Source; Store recovery grants no replacement ready-source authority.',
            'Ordinary PhaseIo owns one original ProgramIo inventory; each of four readbacks has one PreparedReadback owner, with its original caller pool only when the prepared ownership requires one.',
            'Fixed mutable outputs borrow the original TensorView; registration preserves the previous mixed fixed/readback installation order, including valid/accept before next_id before draft_id.',
            'ProgramCarrier still atomically publishes its original Graph Invocation only after cold installation succeeds; no new runtime, owner or hot withdrawal protocol was added.'],
        patch_base_commit=(W/'base-commit.txt').read_text(encoding='utf-8-sig').strip(),
        source_identities=sources,compilations=compilations,link_closures=closures,native_cases=native,
        original_driver_identity=plan['original_driver'],host_cost_reference=host_cost,
        prior_evidence_reference='docs/evidence/correctness/inference-execution-preparation-2026-10-28.json',
        limits=['Finite CPU/CUDA consumers and the selected existing Graph CPU group; no natural model quality, throughput or full platform matrix conclusion.',
            'The 32 state comparisons are not all byte-identical: only newly computed F32 GDN uses the unchanged original numerical budget. The separate logits journeys add 20 byte-exact checks.',
            'Illegal-index, cancellation, Source, exact metadata and original native-retirement gates were not relaxed; unknown-native-retirement faults were not newly injected.',
            'MTP host-cost analysis, if attached, derives from the retained older profile and is not a new performance measurement of this change.',
            'SDK, model weights, binaries, SQLite traces, CLI artifacts and previous archives are excluded; source, actual recipes, process receipts and raw functional reports are retained.'])
    members['summary.json']=body(summary)
    manifest=[dict(name=name,bytes=len(data),sha256=digest(data)) for name,data in sorted(members.items())]
    members['manifest.json']=body(dict(members=manifest,excludes_itself=True))
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(members.items()):archive.writestr(name,data)
    archive=pin(DEST.with_suffix('.zip'));archive['members']=len(members);summary['archive']=archive
    with DEST.with_suffix('.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(dict(status=summary['status'],archive=archive,actual_counts=summary['actual_counts'])))


if __name__=='__main__':main()
