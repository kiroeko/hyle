"""Offline mutually exclusive call-wall attribution of the existing four traces."""
from pathlib import Path
from collections import defaultdict
import json
import sqlite3
import statistics
W=Path(__file__).resolve().parent

def read(p):return json.loads(Path(p).read_bytes())
def union(xs):
    out=[]
    for a,b in sorted(xs):
        if b<=a:continue
        if out and a<=out[-1][1]:out[-1][1]=max(out[-1][1],b)
        else:out.append([a,b])
    return out
def intersection(xs,ys):
    xs=union(xs);ys=union(ys);out=[];i=j=0
    while i<len(xs) and j<len(ys):
        a=max(xs[i][0],ys[j][0]);b=min(xs[i][1],ys[j][1])
        if a<b:out.append([a,b])
        if xs[i][1]<ys[j][1]:i+=1
        else:j+=1
    return out
def minus(xs,ys):
    out=[];ys=union(ys)
    for a,b in union(xs):
        cursor=a
        for c,d in ys:
            if d<=cursor:continue
            if c>=b:break
            if c>cursor:out.append([cursor,min(c,b)])
            cursor=max(cursor,d)
            if cursor>=b:break
        if cursor<b:out.append([cursor,b])
    return out
def measure(xs):return sum(b-a for a,b in union(xs))

def load(name):
    f=W/'runs'/name;c=sqlite3.connect((f/'trace.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row
    roots=read(f/'roots.json');ss=dict(c.execute('SELECT id,value FROM StringIds'))
    tids={x[0] for x in c.execute('SELECT DISTINCT globalTid FROM NVTX_EVENTS WHERE uint64Value>0')};assert len(tids)==1
    tid=next(iter(tids));pid=tid&~((1<<24)-1)
    tables={x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")};apis=[]
    for kind in ('RUNTIME','DRIVER'):
        table='CUPTI_ACTIVITY_KIND_'+kind
        if table in tables:
            apis.extend(dict(x,api=ss[x['nameId']]) for x in c.execute('SELECT * FROM '+table+' WHERE globalTid=?',(tid,)))
    gpu=[]
    for kind in ('KERNEL','MEMCPY','MEMSET'):
        gpu.extend((x[0],x[1]) for x in c.execute('SELECT start,end FROM CUPTI_ACTIVITY_KIND_'+kind+' WHERE globalPid=?',(pid,)))
    c.close();return roots,apis,union(gpu)

def group(name,roots,apis,gpu):
    scope=union([(r['start_ns'],r['end_ns']) for r in roots]+[(p['start_ns'],p['end_ns']) for r in roots for p in r['phases']])
    sets=defaultdict(list)
    for r in roots:
        for p in r['phases']:sets[p['label']].append((p['start_ns'],p['end_ns']))
    if name in ('mtp-hyle','r1-auto'):
        buckets=dict(replay=union(sets['hyle/prepare_replay']),prepare_excluding_replay=minus(sets['hyle/prepare'],sets['hyle/prepare_replay']),
            submit=union(sets['hyle/submit']),wait=union(sets['hyle/completion_wait']),postwait=union(sets['hyle/postwait_publish']),
            finish_excluding_wait_postwait=minus(sets['hyle/wait_publish'],sets['hyle/completion_wait']+sets['hyle/postwait_publish']))
    else:
        buckets=dict(prepare=union([x for k,v in sets.items() if k.startswith('peer/prepare') for x in v]),
            submit=union(sets['peer/llama_decode']),wait=union(sets['peer/synchronize']))
    covered=union([x for v in buckets.values() for x in v]);assert measure(covered)==sum(measure(v) for v in buckets.values())
    buckets['other_root_wall']=minus(scope,covered)
    assert sum(measure(v) for v in buckets.values())==measure(scope)
    all_api=union((x['start'],x['end']) for x in apis)
    out={}
    for label,intervals in buckets.items():
        wall=measure(intervals);api=measure(intersection(intervals,all_api));busy=measure(intersection(intervals,gpu))
        groups=defaultdict(list)
        for x in apis:
            clipped=intersection(intervals,[(x['start'],x['end'])])
            if clipped:groups[x['api']].extend(clipped)
        top=sorted((dict(api=k,wall_union_ms=measure(v)/1e6,overlapping_calls=len(v)) for k,v in groups.items()),key=lambda x:-x['wall_union_ms'])[:8]
        out[label]=dict(wall_ms=wall/1e6,CUDA_API_union_ms=api/1e6,outside_CUDA_API_wall_ms=(wall-api)/1e6,
            physical_GPU_overlap_ms=busy/1e6,physical_GPU_idle_ms=(wall-busy)/1e6,top_APIs=top)
    return dict(root_sequences=[r['seq'] for r in roots],roots=len(roots),mutually_exclusive_scope_union_ms=measure(scope)/1e6,
        CUDA_API_union_ms=measure(intersection(scope,all_api))/1e6,non_API_wall_ms=measure(minus(scope,all_api))/1e6,
        buckets=out,recording_API_counts=dict(sum((__import__('collections').Counter(r['recording_API_counts']) for r in roots),__import__('collections').Counter())))

def main():
    result={}
    for name in ('mtp-hyle','mtp-peer','r1-auto','r1-peer'):
        roots,apis,gpu=load(name)
        decode=[r for r in roots if r['seq']!=1] if name=='r1-auto' else [r for r in roots if '_decode ' in r['label']] if name.endswith('peer') else [r for r in roots if r['seq']>1]
        capture=[r for r in decode if r['recording_API_counts']];steady=[r for r in decode if not r['recording_API_counts']]
        result[name]=dict(prefill=group(name,[r for r in roots if r not in decode],apis,gpu),
            recording_decode=group(name,capture,apis,gpu),nonrecording_decode=group(name,steady,apis,gpu))
        if name=='mtp-hyle':
            for role in (3,4):result[name]['nonrecording_role'+str(role)]=group(name,[r for r in steady if r['meta']['role']==role],apis,gpu)
    output=dict(status='OFFLINE_EXISTING_TRACE_HOST_CALL_WALL_PARTITION',arms=result,
        limits=['Buckets are disjoint and sum to their actual root+labelled-prepare union; no root sum or nested parent addition.',
            'CUDA runtime/driver intervals on the NVTX/main thread are unioned, including nested API ranges. Outside-API wall is not CPU self-time: it includes descheduling, libraries and profiler overhead.',
            'CUDA API wall can overlap GPU execution and can block for GPU/driver work. wait and GraphLaunch wall are not pure Model CPU cost.',
            'Physical GPU is all traced-process activity intersected with each bucket; its idle complement is not CPU busy. Peer post-call sample/hidden/trim gaps are outside its native-call roots.',
            'Recorded and unrecorded cohorts differ in role/actual row counts; totals do not establish code gains or one-to-one MTP work. No new native execution.'])
    (W/'mtp-host-cost.json').write_bytes((json.dumps(output,indent=2)+'\n').encode())
    for name,groups in result.items():
        for label,g in groups.items():
            print(name,label,g['roots'],'roots',round(g['mutually_exclusive_scope_union_ms'],3),'ms')
            for b,v in g['buckets'].items():print(' ',b,*[round(v[k],6) for k in ('wall_ms','CUDA_API_union_ms','outside_CUDA_API_wall_ms','physical_GPU_idle_ms')])

if __name__=='__main__':main()
