import json
from pathlib import Path
text=Path('/mnt/c/public/project-hyle/hyle/.scratch/run-cpu-final-f1-mixed-linux-remote.py').read_text()
prior=json.loads(Path('/root/hyle-scratch/active-cpu-z/cpu-final-mixed-result/receipt.json').read_text())
assert len(prior)==7 and all(x['returncode']==0 for x in prior[3:])
exec(compile(text.split("run('identity'")[0],'canonical-mixed-linux-prefix','exec'))
records=prior
exec(compile(text[text.index('common='):text.index("run('configure'")],'canonical-mixed-linux-options','exec'))
exec(compile(text[text.index("for shape in ('shared','static'):"):],'canonical-mixed-linux-delivery','exec'))
