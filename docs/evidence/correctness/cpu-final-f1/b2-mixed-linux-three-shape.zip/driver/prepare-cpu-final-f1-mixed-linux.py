import ctypes,hashlib,json,subprocess
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(32771)
flags=dict(creationflags=subprocess.CREATE_NO_WINDOW)
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f1/mixed-linux';out.mkdir(parents=True,exist_ok=True)
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
archive=out/'source.tar'
subprocess.run(['git','archive','--format=tar','-o',str(archive),candidate],**flags,check=True)
identity={'candidate':candidate,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'remote_root':'/root/hyle-scratch/active-cpu-z','scope':'Linux mixed old-core CPU loader delta; reuse owned producer, no new GPU P1 or algorithm'}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(identity,flush=True)
