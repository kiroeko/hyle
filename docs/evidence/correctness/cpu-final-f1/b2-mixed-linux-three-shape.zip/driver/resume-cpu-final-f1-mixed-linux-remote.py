import json,shutil
from pathlib import Path
root=Path('/root/hyle-scratch/active-cpu-z')
out=root/'cpu-final-mixed-result'
old=json.loads((out/'receipt.json').read_text())
initial=root/'cpu-final-mixed-initial-failure';initial.mkdir(exist_ok=True)
for p in out.iterdir():
    if p.is_file():shutil.copyfile(p,initial/p.name)
text=Path('/mnt/c/public/project-hyle/hyle/.scratch/run-cpu-final-f1-mixed-linux-remote.py').read_text()
prefix=text.split("run('identity'")[0]
exec(compile(prefix,'canonical-mixed-linux-driver','exec'))
records=old
tail=text[text.index("run('build'"):]
tail=tail.replace("'hyle_compute_ggml_runtime_tests','--parallel'","'hyle_compute_ggml_runtime_tests','hyle_compute_provider_ggml_cuda_tests','--parallel'",1)
gpu="run('gpu-original-and-rejection',[build/'bin/hyle_compute_provider_ggml_cuda_test','--gtest_filter=GgmlCudaTensor.CpuFormatPortDoesNotQualifyGpuMatrices:GgmlCudaTensor.NativeQ4KMatMulImportsGgufBytesAndReplays:GgmlCudaTensor.BfloatRouterMatMulRetainsNativeF32Score:GgmlCudaTensor.UnsupportedNumericDomainsDeclineBeforeNativeExecution','--gtest_output=xml:'+str(out/'gpu.xml')])\n"
tail=tail.replace("for shape in ('shared','static'):",gpu+"for shape in ('shared','static'):",1)
exec(compile(tail,'canonical-mixed-linux-continuation','exec'))
