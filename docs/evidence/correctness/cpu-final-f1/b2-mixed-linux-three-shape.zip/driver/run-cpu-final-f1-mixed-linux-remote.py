import hashlib,json,os,shutil,subprocess,tarfile,time
from pathlib import Path
canonical=Path('/mnt/c/public/project-hyle/hyle')
input_dir=canonical/'.scratch/validation/cpu-final-f1/mixed-linux'
identity=json.loads((input_dir/'identity.json').read_text());candidate=identity['candidate']
root=Path('/root/hyle-scratch/active-cpu-z').resolve();source=(root/'source').resolve();build=root/'build';out=root/'cpu-final-mixed-result';out.mkdir(exist_ok=True)
assert str(root)==identity['remote_root'] and source.parent==root and source.is_dir()
archive=input_dir/'source.tar';assert hashlib.sha256(archive.read_bytes()).hexdigest()==identity['archive_sha256']
# Replace the disposable validation source from the complete immutable Windows
# archive. Preserve identical file timestamps so owned dependency binaries reuse.
with tarfile.open(archive) as bundle:
    allowed=set()
    for member in bundle.getmembers():
        if member.isdir():continue
        target=(source/member.name).resolve();assert target.is_relative_to(source)
        assert member.isfile(), 'Unexpected symlink in canonical source archive'
        allowed.add(target)
        data=bundle.extractfile(member).read()
        if not target.exists() or target.read_bytes()!=data:
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        target.chmod(member.mode)
    for target in source.rglob('*'):
        if target.is_file() and target.resolve() not in allowed:
            assert target.resolve().is_relative_to(source)
            target.unlink()
consumer=root/'cpu-final-mixed-consumer';consumer.mkdir(exist_ok=True)
for name in ('CMakeLists.txt','main.cc'):
    shutil.copyfile(canonical/'.scratch/validation/cpu-final-f3/delivery-final/consumer'/name,consumer/name)
env=dict(os.environ,CC='gcc-14',CXX='g++-14',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env.pop('LD_LIBRARY_PATH',None)
env['HYLE_D5_QWEN35_FIXTURE']=str(root/'cpu-final-qwen-fixture/fixture')
records=[]
def run(name,args):
    start=time.monotonic();log=out/(str(len(records)+1)+'-'+name+'.log')
    with log.open('wb') as stream:r=subprocess.run(list(map(str,args)),env=env,stdout=stream,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=list(map(str,args)),candidate=candidate,returncode=r.returncode,seconds=round(time.monotonic()-start,3),log=log.name))
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
    if r.returncode:print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(r.returncode)
overlay=root/'cpu-final-mixed-overlay.cmake'
overlay.write_text('function(f1_mixed_consumer)\nadd_executable(f1_mixed_40 "'+str(consumer/'main.cc')+'")\ntarget_compile_features(f1_mixed_40 PRIVATE cxx_std_23)\ntarget_link_libraries(f1_mixed_40 PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(f1_mixed_40)\nendfunction()\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\ncmake_language(DEFER CALL f1_mixed_consumer)\nendif()\n')
run('identity',['sh','-c','uname -m; gcc-14 --version; cmake --version; /usr/local/cuda-13.3/bin/nvcc --version; nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader'])
common=['-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPONENTS=compute,graph','-U','HYLE_DEV_FACTORS','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=ON','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=AUTO','-DHYLE_COMPUTE_TORCH_CPU=AUTO','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DHYLE_DEP_SOURCE_CACHE=/root/.cache/hyle/dependencies/v1','-DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=89-real','-DCMAKE_PROJECT_INCLUDE='+str(overlay)]
run('configure',['cmake','-S',source,'-B',build,*common,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_STATIC=OFF'])
run('build',['cmake','--build',build,'--target','f1_mixed_40','hyle_compute_ggml_runtime_tests','--parallel','2'])
run('source-cpu-40',[build/'bin/f1_mixed_40'])
run('original-cpu-program-isa-resources',[build/'bin/hyle_compute_ggml_runtime_test','--gtest_filter=GgmlCpuExecution.*','--gtest_output=xml:'+str(out/'runtime.xml')])
for shape in ('shared','static'):
    prefix=root/('cpu-final-mixed-'+shape+'-staging');relocated=root/('cpu-final-mixed-'+shape+'-relocated');cb=root/('cpu-final-mixed-'+shape+'-installed')
    assert not prefix.exists() and not relocated.exists(), 'Refuse to replace an existing SDK'
    run(shape+'-configure',['cmake','-S',source,'-B',build,*common,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+str(prefix)])
    run(shape+'-build',['cmake','--build',build,'--parallel','2'])
    run(shape+'-source-40',[build/'bin/f1_mixed_40'])
    run(shape+'-install',['cmake','--install',build])
    assert prefix.resolve().parent==root and relocated.resolve().parent==root
    prefix.rename(relocated)
    run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-consumer-build',['cmake','--build',cb,'--parallel','2'])
    run(shape+'-consumer-40',[cb/'cpu_final_delivery'])
    run(shape+'-loader',['ldd',cb/'cpu_final_delivery'])
    if shape=='shared':run('shared-export',['python3',source/'scripts/check-shared-export-hygiene.py','--root',relocated])
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
