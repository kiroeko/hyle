import ctypes,subprocess
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(32771)
import sys
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
flags=dict(creationflags=subprocess.CREATE_NO_WINDOW)
out=Path('.scratch/validation/cpu-final-f1/mixed-linux')
copy="from pathlib import Path;import shutil;shutil.copyfile('/mnt/c/public/project-hyle/hyle/.scratch/run-cpu-final-f1-mixed-linux-remote.py','/root/hyle-scratch/active-cpu-z/run-cpu-final-f1-mixed-linux.py')"
subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',copy],**flags,check=True)
with (out/'driver.log').open('wb') as log:r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','/root/hyle-scratch/active-cpu-z/run-cpu-final-f1-mixed-linux.py'],stdout=log,stderr=subprocess.STDOUT,**flags)
print('Linux mixed batch exit',r.returncode,flush=True)
print((out/'driver.log').read_text(errors='replace')[-6000:],flush=True)
r.check_returncode()
