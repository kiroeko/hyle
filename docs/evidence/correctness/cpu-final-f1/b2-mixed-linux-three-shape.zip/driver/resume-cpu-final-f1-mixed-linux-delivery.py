import ctypes,subprocess,sys
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(32771)
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
flags=dict(creationflags=subprocess.CREATE_NO_WINDOW)
out=Path('.scratch/validation/cpu-final-f1/mixed-linux')
copy="import shutil;shutil.copyfile('/mnt/c/public/project-hyle/hyle/.scratch/resume-cpu-final-f1-mixed-linux-delivery-remote.py','/root/hyle-scratch/active-cpu-z/resume-cpu-final-f1-mixed-linux-delivery.py')"
subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',copy],**flags,check=True)
with (out/'delivery-driver.log').open('wb') as log:r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','/root/hyle-scratch/active-cpu-z/resume-cpu-final-f1-mixed-linux-delivery.py'],stdout=log,stderr=subprocess.STDOUT,**flags)
print('Linux delivery batch exit',r.returncode,flush=True)
print((out/'delivery-driver.log').read_text(encoding='utf-8',errors='replace')[-6500:],flush=True)
r.check_returncode()
