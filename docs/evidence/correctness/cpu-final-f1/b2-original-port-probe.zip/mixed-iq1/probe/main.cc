#include "ggml.h"
#include "ggml-cpu.h"
#include "ggml-impl.h"
#include <cstdio>
#include <cstring>
#include <vector>
#include <cmath>
int main() {
 ggml_cpu_init();
 std::printf("tensor=%zu plan=%zu f32=%d f16=%d bf16=%d iq1s=%d iq1m=%d count=%d\n",sizeof(ggml_tensor),sizeof(ggml_cplan),GGML_TYPE_F32,GGML_TYPE_F16,GGML_TYPE_BF16,GGML_TYPE_IQ1_S,GGML_TYPE_IQ1_M,GGML_TYPE_COUNT);
 for (auto type : {GGML_TYPE_IQ1_XS,GGML_TYPE_IQ1_XXS,GGML_TYPE_IQ1_XXXS}) {
  auto *ctx=ggml_init({8*1024*1024,nullptr,false}); if(!ctx)return 1;
  auto *weight=ggml_new_tensor_2d(ctx,type,256,4);
  auto *activation=ggml_new_tensor_2d(ctx,GGML_TYPE_F32,256,2);
  const auto row=ggml_row_size(type,256);
  std::memset(weight->data,0,ggml_nbytes(weight));
  for(int r=0;r<4;++r){auto *bytes=static_cast<unsigned char*>(weight->data)+r*row;for(std::size_t i=2;i<row;++i)bytes[i]=static_cast<unsigned char>((i*7+r*13)%256);const unsigned short scale=static_cast<unsigned short>(0x3c00+r*0x100);std::memcpy(bytes,&scale,2);}
  auto *input=static_cast<float*>(activation->data);
  for(int i=0;i<512;++i)input[i]=float(i%7-3)/8;
  auto *output=ggml_mul_mat(ctx,weight,activation);
  auto *ids=ggml_new_tensor_1d(ctx,GGML_TYPE_I32,2);static_cast<int*>(ids->data)[0]=3;static_cast<int*>(ids->data)[1]=1;
  auto *gathered=ggml_get_rows(ctx,weight,ids);
  auto *graph=ggml_new_graph(ctx);ggml_build_forward_expand(graph,output);ggml_build_forward_expand(graph,gathered);
  if(ggml_graph_compute_with_ctx(ctx,graph,1)!=GGML_STATUS_SUCCESS)return 2;
  const auto *traits=ggml_get_type_traits(type);const auto *cpu=ggml_get_type_traits_cpu(type);
  std::vector<float> decoded(256);traits->to_float(weight->data,decoded.data(),256);
  std::vector<char> encoded(ggml_row_size(cpu->vec_dot_type,256));
  for(int r=0;r<2;++r){
   const auto *encoder=ggml_get_type_traits_cpu(cpu->vec_dot_type);
   encoder->from_float(input+r*256,encoded.data(),256);
   for(int n=0;n<4;++n){float expected=0;cpu->vec_dot(256,&expected,0,static_cast<char*>(weight->data)+n*row,0,encoded.data(),0,1);if(std::abs(static_cast<float*>(output->data)[r*4+n]-expected)>1e-5f)return 3;}
  }
  for(int r=0;r<2;++r){traits->to_float(static_cast<char*>(weight->data)+(r?1:3)*row,decoded.data(),256);for(int i=0;i<256;++i)if(static_cast<float*>(gathered->data)[r*256+i]!=decoded[i])return 4;}
  std::printf("type=%d row_bytes=%zu MatMul=PASS Gather=PASS output0=%.9g\n",int(type),row,double(static_cast<float*>(output->data)[0]));
  ggml_free(ctx);
 }
}
