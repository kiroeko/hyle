#include "ggml.h"
#include "ggml-cpu.h"
#include <cstdio>
int main() { std::printf("tensor=%zu plan=%zu f32=%d f16=%d bf16=%d iq1s=%d iq1m=%d count=%d\n",sizeof(ggml_tensor),sizeof(ggml_cplan),GGML_TYPE_F32,GGML_TYPE_F16,GGML_TYPE_BF16,GGML_TYPE_IQ1_S,GGML_TYPE_IQ1_M,GGML_TYPE_COUNT); }
