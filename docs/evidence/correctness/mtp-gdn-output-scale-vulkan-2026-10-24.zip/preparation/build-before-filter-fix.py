"""Current direct Vulkan GDN focus; cached SDK/shaders, one native owning TU."""
from pathlib import Path
import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
SDK = R / '.scratch/bench-api-runtime/vulkan/build'
NATIVE = SDK / 'native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e'
FLAT = R / '.scratch/mtp-packed-head-20261024/orin-proposal/mmq-query-proposal/current_closure.py'
FLAT_SHA = '3749aa7a5767faad27653b133aad83994a13126db2b4cd17ea4452780f4a973d'
ROUTE_RECIPE = R / '.scratch/vulkan-bf16-linear-20261022/compile1/route-region/identity.json'
SHADER_RECORD = R / '.scratch/architecture-refactor-2026-10-18/quark-fp8-side-2026-10-21/windows/checks/attempt2/vulkan-shaders/identity.json'
IREE_RECORD = R / '.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/vulkan/windows/checks/attempt1/embedded/identity.json'
TEST = R / 'tests/compute_provider_native/gdn_output_scale_test.cc'
TEST_FILTER = 'VulkanGdnOutputScale.*'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


h = module('_gdn_vulkan_cached_host_tools', R / '.scratch/native-paged-effects-20261022/build_windows.py')
b, c = h.b, h.c
q = module('_gdn_vulkan_process', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
identity, read, save = b.identity, c.read, c.save


def require(row):
    if identity(row['path']) != row:
        raise ValueError('Changed actual input: ' + row['path'])


def argv(command):
    count = ctypes.c_int()
    f = ctypes.windll.shell32.CommandLineToArgvW
    f.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    f.restype = ctypes.POINTER(ctypes.c_wchar_p)
    data = f(command, ctypes.byref(count))
    if not data:
        raise OSError('CommandLineToArgvW')
    try:
        return [data[i] for i in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree(data)


def prepare():
    if (S / 'plan.json').exists():
        raise ValueError('Preserve prepared plan')
    require(dict(path=str(FLAT), bytes=FLAT.stat().st_size, sha256=FLAT_SHA))
    flat = module('_gdn_vulkan_current_public_objects', FLAT)
    plan, ready, runtime, consumer, records = flat.closure()
    public = []
    for path in records:
        rec = read(path)
        if Path(rec['source']['path']).parent.name in ('compute', 'compute_ops', 'compute_batch'):
            public.append(identity(path))
    if len(public) != 35:
        raise ValueError('Expected current provider-neutral Compute21+ops6+batch8')
    retained = []
    names = {'gtest_main.lib', 'gtest.lib', 'hyle_container.lib', 'hyle_mem.lib',
        'mimalloc_static.lib', 'hyle_platform.lib', 'hyle_error.lib',
        'hyle_platform_thread.lib', 'hyle_time.lib', 'hyle_simd.lib',
        'hyle_sched.lib', 'hyle_mem_vm.lib', 'hyle_platform_fs.lib'}
    for row in plan['retained_inputs']:
        if Path(row['path']).name in names:
            require(row)
            retained.append(row)
    if {Path(row['path']).name for row in retained} != names:
        raise ValueError('Exact current common/core library set')
    db = read(SDK / 'compile_commands.json')
    def recipe(source):
        found = [row for row in db if Path(row['file']).resolve() == source.resolve()]
        if len(found) != 1:
            raise ValueError('Expected one cached owning recipe: ' + str(source))
        return found[0]
    route = read(ROUTE_RECIPE)['command']
    jobs = []
    # Derive all handwritten module owners from the current CMake source list.
    import re
    cmake = (R / 'src/compute_route_vulkan/CMakeLists.txt').read_text()
    names_route = re.findall(r'\bvulkan_[a-z_0-9]+\.cc\b', cmake)
    names_route = list(dict.fromkeys(x for x in names_route if x != 'vulkan_shaders.cc'))
    if len(names_route) != 33:
        raise ValueError('Current Vulkan route handwritten owners changed')
    for filename in names_route:
        jobs.append(dict(tag='route--' + Path(filename).stem, group='route',
            source=str(R / 'src/compute_route_vulkan' / filename), command=route,
            recipe=identity(ROUTE_RECIPE)))
    for group, folder, filenames in [
        ('ggml', 'compute_provider_ggml_vulkan', ['native_device.cc', 'native_graph.cc', 'region.cc']),
        ('iree', 'compute_provider_iree_vulkan', ['native_device.cc', 'native_program.cc']),
        ('ggml', 'compute_ggml_runtime', ['metadata_arena.cc'])]:
        for filename in filenames:
            source = R / 'src' / folder / filename
            rec = recipe(source)
            jobs.append(dict(tag=folder + '--' + source.stem, group=group,
                source=str(source), command=argv(rec['command']), cached_recipe=rec))
    jobs.append(dict(tag='test', group='test', source=str(TEST), command=route,
        recipe=identity(ROUTE_RECIPE)))
    original = NATIVE / 'src/ggml-vulkan/ggml-vulkan.cpp'
    before = identity(original)
    if before['sha256'] != 'af7dea1e1c981877a9ca0f1ce955844c35a11593a0ec88b3addf263a8f4e261a':
        raise ValueError('Unexpected cached owning native source')
    manifest_path = R / 'third_party/ggml_vulkan_runtime/patches.json'
    manifest = read(manifest_path)
    edits = next(row for row in manifest['files'] if row['path'] == 'src/ggml-vulkan/ggml-vulkan.cpp')['edits']
    edits = [row for row in edits if any(key in row['after'] for key in
        ('gated_delta_scale.h', 'gdn_output_scale(', 'kGdnOutputScalePresenceSlot'))]
    if len(edits) != 3:
        raise ValueError('Expected exactly three output-scale owning edits')
    raw = original.read_text(encoding='utf-8')
    for row in edits:
        if raw.count(row['before']) != 1 or raw.count(row['after']) != 0:
            raise ValueError('Native owning anchored edit mismatch')
        raw = raw.replace(row['before'], row['after'], 1)
    overlay = S / 'native-source/ggml-vulkan.cpp'
    overlay.parent.mkdir(parents=True)
    overlay.write_text(raw, encoding='utf-8', newline='\n')
    rec = recipe(original)
    jobs.append(dict(tag='native', group='native', source=str(overlay),
        command=argv(rec['command']), cached_recipe=rec, original=before,
        manifest=identity(manifest_path), edits=edits))
    generated = []
    for group, path in [('route', SHADER_RECORD), ('iree', IREE_RECORD)]:
        rec = read(path)
        # Generated array/program objects contain no Operation/provider ABI.
        for row in [rec['source'], rec['object']]:
            require(row)
        generated.append(dict(group=group, record=identity(path),
            source=rec['source'], object=rec['object']))
    vendor = SDK / 'native/hyle'
    libraries = [vendor / 'src/compute_ggml_runtime/vendor/src/ggml.lib',
        vendor / 'src/compute_ggml_runtime/vendor/src/ggml-vulkan/ggml-vulkan.lib',
        vendor / 'src/compute_ggml_runtime/vendor/src/ggml-base.lib',
        vendor / '_deps/iv/build/runtime/src/iree/runtime/iree_runtime_unified.lib',
        vendor / '_deps/iv/build/build_tools/third_party/flatcc/flatcc_parsing.lib']
    header = identity(NATIVE / 'include/ggml.h')
    if header['sha256'] != '9ac7ee3d3a957e5f7b21b104d3e3dc50b1b106f808f9d6735ead950450bfeec6':
        raise ValueError('Keep the independent Vulkan GGML family')
    save(S / 'plan.json', dict(entry=identity(Path(__file__)), jobs=jobs,
        current_public_records=public, current_flat=identity(FLAT), flat_ready=ready,
        retained_common_libraries=retained, native_libraries=[identity(p) for p in libraries],
        generated=generated, ggml_header=header, current_header=identity(R / 'src/compute_ggml_runtime/gated_delta_scale.h'),
        host_TUs=40, native_TUs=1, SDK=0, shaders=0, NVCC=0,
        case_filter=TEST_FILTER, expected_cases=2, model_data=0, HTTP=0,
        boundaries='Direct Vulkan only; no Graph/CPU/CUDA providers or second GGML family.'))
    print('PREPARED 40 host +1 native; cached shaders/programs; SDK0', flush=True)


def command_for(job, out):
    command, skip = [], False
    for arg in job['command']:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
        elif arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        else:
            command.append({'-MD': '/MD', '-O2': '/O2'}.get(arg, arg))
    if job['group'] != 'native':
        if '/WX' not in command:
            command.append('/WX')
        command.insert(1, '/I' + str(Path(read(SHADER_RECORD)['source']['path']).parent))
        command.insert(1, '/I' + str(Path(read(IREE_RECORD)['source']['path']).parent))
    else:
        command.insert(1, '/I' + str(NATIVE / 'src/ggml-vulkan'))
        command.insert(1, '/I' + str(R / 'src/compute_ggml_runtime'))
    if job['tag'] == 'test':
        command.insert(1, '/DHYLE_GDN_SCALE_VULKAN=1')
        command.insert(1, '/I' + str(R / '.scratch/build-compute-v2-dev/_deps/googletest-src/googletest/include'))
    tag = job['tag']
    command += ['/sourceDependencies', str(out / 'source-deps.json'), job['source'],
        '/Fo' + str(out / (tag + '.obj')), '/Fd' + str(out / (tag + '.pdb'))]
    return command


def compile_jobs(attempt, select):
    plan = read(S / 'plan.json')
    jobs = [row for row in plan['jobs'] if select == 'all' or row['group'] == select or row['tag'] == select]
    if not jobs:
        raise ValueError('Unknown selected owning job')
    for job in jobs:
        out = S / f'compile{attempt}' / job['tag']
        if (out / 'identity.json').exists():
            print('RETAINED ' + job['tag'], flush=True)
            continue
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        source = identity(job['source'])
        snapshot = out / 'source' / Path(job['source']).name
        snapshot.parent.mkdir()
        snapshot.write_bytes(Path(job['source']).read_bytes())
        command = command_for(job, out)
        save(out / 'plan.json', dict(job=job, source=source, command=command,
            SDK=0, NVCC=0, shaders=0))
        env, _ = b.environment(command, [], out)
        env.update(TEMP=str(out / 'tmp'), TMP=str(out / 'tmp'))
        print('COMPILING ' + job['tag'], flush=True)
        process = q.execute(command, env, out / 'run', timeout=1800)
        if process['exit'] != 0 or process['timed_out']:
            print((out / 'run/stdout.log').read_text(errors='replace'), flush=True)
            print((out / 'run/stderr.log').read_text(errors='replace'), flush=True)
            raise SystemExit(process['exit'] or 1)
        require(source)
        deps = read(out / 'source-deps.json')['Data']
        dependencies = [identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
        save(out / 'identity.json', dict(source=source, object=identity(out / (job['tag'] + '.obj')),
            command=command, dependencies=dependencies, process=identity(out / 'run/process.json'),
            source_snapshot=identity(snapshot), recipe=identity(out / 'plan.json')))
        print('COMPILED ' + job['tag'], flush=True)


def link(attempt, compile_attempt):
    plan = read(S / 'plan.json')
    groups = {'public': [], 'route': [], 'ggml': [], 'iree': []}
    actual_records = []
    for row in plan['current_public_records']:
        require(row)
        rec = read(row['path'])
        for item in [rec['source'], rec['object'], *rec['dependencies']]:
            require(item)
        groups['public'].append(rec['object']['path'])
    native, test = None, None
    for job in plan['jobs']:
        path = S / f'compile{compile_attempt}' / job['tag'] / 'identity.json'
        rec = read(path)
        for item in [rec['source'], rec['object'], *rec['dependencies']]:
            require(item)
        actual_records.append(identity(path))
        if job['group'] == 'native':
            native = rec['object']['path']
        elif job['group'] == 'test':
            test = rec['object']['path']
        else:
            groups[job['group']].append(rec['object']['path'])
    for row in plan['generated']:
        require(row['record']); require(row['source']); require(row['object'])
        groups[row['group']].append(row['object']['path'])
    out = S / f'link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    compiler = Path(plan['jobs'][0]['command'][0])
    archives = []
    for group, objects in groups.items():
        target = out / (group + '.lib')
        command = [str(compiler.with_name('lib.exe')), '/nologo', '/OUT:' + str(target), *objects]
        save(out / (group + '-archive-plan.json'), dict(command=command, objects=[identity(p) for p in objects]))
        env, _ = b.environment(command, [], out)
        process = q.execute(command, env, out / (group + '-archive'), timeout=600)
        if process['exit'] != 0 or process['timed_out']:
            raise SystemExit(process['exit'] or 1)
        archives.append(identity(target))
    rows = [*archives, *plan['native_libraries'], *plan['retained_common_libraries']]
    for row in rows:
        require(row)
    image = out / 'gdn-vulkan.exe'
    command = [str(compiler.with_name('link.exe')), test, native,
        '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT',
        *[row['path'] for row in rows], 'Synchronization.lib', 'bcrypt.lib', 'PowrProf.lib',
        'ws2_32.lib', 'mswsock.lib', 'kernel32.lib', 'user32.lib', 'gdi32.lib', 'winspool.lib',
        'shell32.lib', 'ole32.lib', 'oleaut32.lib', 'uuid.lib', 'comdlg32.lib', 'advapi32.lib',
        '/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
        '/IMPLIB:' + str(image.with_suffix('.lib'))]
    save(out / 'link-plan.json', dict(command=command, compiled_records=actual_records,
        current_public_records=plan['current_public_records'], libraries=rows,
        native_owning_object=identity(native), test_object=identity(test),
        generated=plan['generated'], ggml_header=plan['ggml_header'],
        host_TUs=40, native_TUs=1, SDK=0, NVCC=0, shaders=0))
    env, _ = b.environment(command, [row['path'] for row in rows], out)
    process = q.execute(command, env, out / 'run', timeout=1800)
    if process['exit'] != 0 or process['timed_out']:
        print((out / 'run/stdout.log').read_text(errors='replace'), flush=True)
        raise SystemExit(process['exit'] or 1)
    save(out / 'runtime-environment.json', dict(PATH=env['PATH'], staged_dlls=[],
        native='Static Vulkan9ac7 family only; system Vulkan loader, no CPU/CUDA worker'))
    save(out / 'ready.json', dict(image=identity(image), link_plan=identity(out / 'link-plan.json'),
        link_result=identity(out / 'run/process.json'), runtime=identity(out / 'runtime-environment.json'),
        filter=TEST_FILTER, expected_cases=2, native_executed=False))
    print('LINKED ' + str(image), flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['prepare', 'compile', 'link'])
    p.add_argument('--attempt', type=int, default=1)
    p.add_argument('--compile-attempt', type=int, default=1)
    p.add_argument('--select', default='all')
    args = p.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'compile':
        compile_jobs(args.attempt, args.select)
    else:
        link(args.attempt, args.compile_attempt)
