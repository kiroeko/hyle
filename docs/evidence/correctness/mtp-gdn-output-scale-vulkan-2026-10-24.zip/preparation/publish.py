"""Publish the completed, bounded direct Vulkan GDN check, without binaries."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p, value): Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

plan = read(S / 'plan.json')
ready = read(S / 'link1/ready.json')
summary = read(S / 'checks1/summary.json')
assert summary['passed'] and (summary['cases'], summary['failures'], summary['skips']) == (2, 0, 0)
assert summary['process']['exit'] == 0 and not summary['process']['timed_out']
link = read(S / 'link1/link-plan.json')
process = read(S / 'link1/run/process.json')
assert process['exit'] == 0 and not process['timed_out'] and process['command'] == link['command']
records = [read(x['path']) for x in link['compiled_records']]
assert len(records) == 41
assert all(read(x['process']['path'])['exit'] == 0 for x in records)
native = next(x for x in records if Path(x['source']['path']).parent == S / 'native-source')
map_lines = (S / 'link1/gdn-vulkan.map').read_text(errors='replace').splitlines()
terms = ['ggml_hyle_vulkan_gdn_output_scale_contract', 'ggml_backend_cpu_init',
    'ggml_hyle_cpu_gdn_output_scale_contract', 'ggml_hyle_cuda_gdn_output_scale_contract', 'ggml-vulkan.cpp.obj']
anchors = {term: [line for line in map_lines if term in line] for term in terms}
assert len(anchors[terms[0]]) == 1 and 'native.obj' in anchors[terms[0]][0]
assert all(not anchors[term] for term in terms[1:])
assert not any(any(term in arg.lower() for term in ['ggml-cpu.lib', 'ggml-cuda.lib', 'onednn', 'torch_cpu.lib']) for arg in link['command'])
save(S / 'link-family-facts.json', dict(actual_map=identity(S / 'link1/gdn-vulkan.map'), anchors=anchors,
    native_header=plan['ggml_header'], native_libraries=plan['native_libraries'],
    current_public_records=plan['current_public_records'], retained_common_libraries=plan['retained_common_libraries'],
    no_second_ggml_family=True, no_graph_or_cpu_cuda_providers=True))

target = R / 'docs/evidence/correctness/mtp-gdn-output-scale-vulkan-2026-10-24.json'
archive = target.with_suffix('.zip')
assert not target.exists() and not archive.exists()
files = {}
def add(path, name=None):
    path = Path(path).resolve()
    if name is None: name = 'preparation/' + path.relative_to(S).as_posix()
    assert name not in files or files[name] == path
    files[name] = path
for name in ['build.py', 'build-before-filter-fix.py', 'build-after-filter-before-pathcase.py',
             'preparation-filter-correction.json', 'run.py', 'publish.py', 'plan.json', 'link-family-facts.json']:
    add(S / name)
for folder in ['compile1', 'checks1']:
    for p in sorted((S / folder).rglob('*')):
        if p.is_file() and p.suffix.lower() in ('.json', '.cc', '.cpp', '.h', '.log', '.xml'):
            add(p)
for p in sorted((S / 'link1').glob('*.json')): add(p)
for p in sorted((S / 'link1').rglob('process.json')): add(p)
for p in sorted((S / 'link1').rglob('*.log')): add(p)
for row in plan['generated']:
    add(row['record']['path'], 'reused-generated/' + row['group'] + '-record.json')
for row in plan['current_public_records']:
    path = Path(row['path'])
    add(path, 'current-public-records/' + path.parent.name + '.json')
for filename in ['ready.json', 'host-records.json', 'native-records.json']:
    p = Path(plan['flat_ready']['link_plan']['path']).parent / filename
    add(p, 'current-flat/' + filename)
for name in ['include/hyle/compute/operation.h', 'include/hyle/compute/model_ops.h',
    'src/compute_ops/operation.cc', 'src/compute_ggml_runtime/gated_delta_scale.h',
    'src/compute_route_vulkan/CMakeLists.txt', 'src/compute_provider_ggml_vulkan/CMakeLists.txt',
    'src/compute_provider_iree_vulkan/CMakeLists.txt', 'third_party/ggml_vulkan_runtime/patches.json']:
    add(R / name, 'current-source/' + name)
add(S / 'native-source/ggml-vulkan.cpp')
manifest = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        z.writestr(name, data)
        manifest.append(dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        data = z.read(row['name'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
proof = dict(date='2026-10-24', scope='Direct Windows Vulkan focused GDN output_scale boundary; no model identity or Graph expansion.',
    validation=summary, build=dict(host_translation_units=40, native_translation_units=1,
        reused_current_provider_neutral_objects=35, SDK_builds=0, shader_builds=0, NVCC=0,
        actual_compile_records=link['compiled_records'], actual_link_result=ready['link_result'],
        actual_link_plan=ready['link_plan'], image=ready['image']),
    native=dict(upstream_revision='456172ec733a135778adcd32d00e576a58232e45',
        original=plan['jobs'][-1]['original'], after=native['source'],
        manifest=plan['jobs'][-1]['manifest'], edits=plan['jobs'][-1]['edits'],
        header=plan['ggml_header'], family_audit=read(S / 'link-family-facts.json')),
    covered=['Empty scale preserves the native 1/sqrt(D) default; explicit 1 produces raw final S*q.',
        'Scalar-gate GDN, vector-gate KDA and recurrent raw-gates all produce correct F32 cancellation outputs and two state snapshots.',
        'Original input state is preserved after each invocation.',
        'Public inference accepts finite 0/-0/-2/1 and rejects +/-infinity/NaN without publishing valid outputs.'],
    boundaries=['Existing two canonical focused cases only, D128 and two token rows; no model or quantized artifact check.',
        'Finite 0/-0/-2 acceptance is an inference check; GPU numerical cases use empty and explicit 1.',
        'No Graph bridge, concurrency, throughput, memory peak, or full model quality claim.',
        'Cached shaders and IREE embedded programs reused unchanged; no SDK or third-party shader/binary contents archived.',
        'Selected Vulkan device name is not emitted by the existing canonical cases; no additional device matrix was run.'],
    preparation_corrections=read(S / 'preparation-filter-correction.json'),
    archive=identity(archive), archive_entries=len(manifest)+1, network_bytes=0, automatic_downloads=False)
save(target, proof)
save(S / 'publication.json', dict(proof=identity(target), archive=identity(archive), cases=2,
    failures=0, skips=0, archive_entries=len(manifest)+1, scope_changed=False))
print(json.dumps(read(S / 'publication.json'), ensure_ascii=False))
