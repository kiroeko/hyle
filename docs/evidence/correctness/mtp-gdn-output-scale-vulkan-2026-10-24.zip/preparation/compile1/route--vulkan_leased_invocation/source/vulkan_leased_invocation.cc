#include "hyle/compute/vulkan_memory.h"
#include "hyle/compute/detail/vulkan_batch_access.h"

#include <memory>
#include <new>
#include <utility>
#include <vector>

#include "hyle/compute/detail/native_lease_inputs.h"
#include "hyle/mem/std_allocator.h"

namespace hyle::compute::vulkan {
namespace detail {
Result<OwnedResult<Results>> PagedBatchAccess::submit(Invocation&invocation,LeaseUseBatch uses)noexcept{
  return invocation.submit_guarded(std::move(uses));
}
Status PagedBatchAccess::wait_native(Invocation&invocation)noexcept{return invocation.wait_native();}
struct LeasedInvocationState final {
  explicit LeasedInvocationState(mem::AllocatorRef selected)
      : allocator(selected), inputs(selected) {}
  mem::AllocatorRef allocator;
  compute::detail::NativeLeaseInputs inputs;
  Invocation invocation;
  const MemoryResource *memory = nullptr;
  LeaseImportOptions options;
};
void destroy_leased(LeasedInvocationState *state) noexcept {
  if (!state) return;
  const auto allocator = state->allocator;
  std::destroy_at(state);
  allocator.deallocate(state, sizeof(LeasedInvocationState), alignof(LeasedInvocationState));
}
}
LeasedInvocation::LeasedInvocation(LeasedInvocation &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)) {}
LeasedInvocation &LeasedInvocation::operator=(LeasedInvocation &&other) noexcept {
  if (this != &other) {
    if (state_) { close().IgnoreError(); detail::destroy_leased(state_); }
    state_ = std::exchange(other.state_, nullptr);
  }
  return *this;
}
LeasedInvocation::~LeasedInvocation() {
  if (state_) { close().IgnoreError(); detail::destroy_leased(state_); }
}
Result<LeasedInvocation> LeasedInvocation::create(const Program &program, const MemoryResource &memory,
    LeaseImportOptions options, InvocationAllocation allocation) noexcept {
  if (!program.valid() || !memory.valid() || !options.allocator.valid())
    return std::unexpected(Status::InvalidArgument("invalid vulkan leased invocation"));
  auto allocator = options.allocator;
  if (options.resource_budget.valid()) {
    HYLE_ASSIGN_OR_RETURN(allocator, options.resource_budget.metadata_allocator());
  }
  HYLE_ASSIGN_OR_RETURN(auto native, program.create_invocation(allocator, allocation));
  auto *storage = allocator.allocate(sizeof(detail::LeasedInvocationState), alignof(detail::LeasedInvocationState));
  if (!storage) return std::unexpected(Status::ResourceExhausted("vulkan leased state metadata"));
  auto *state = std::construct_at(static_cast<detail::LeasedInvocationState *>(storage), allocator);
  LeasedInvocation result(state);
  HYLE_RETURN_IF_ERROR(state->inputs.prepare(program.input_descriptions().size(), options));
  state->invocation = std::move(native);
  state->memory = &memory;
  state->options = options;
  return result;
}
bool LeasedInvocation::in_flight() const noexcept {
  return state_ && state_->inputs.active();
}
Status LeasedInvocation::bind(std::span<const LeasedInput> inputs) noexcept {
  if (!state_ || state_->inputs.closed())
    return Status::FailedPrecondition("vulkan leased invocation is empty/closed");
  if (in_flight()) return Status::Unavailable("vulkan leased invocation has native work");
  if (inputs.size() != state_->inputs.size())
    return Status::InvalidArgument("vulkan leased input count differs");
  try {
    std::vector<Tensor, mem::StdAllocator<Tensor>> views{
        mem::StdAllocator<Tensor>(state_->allocator)};
    views.reserve(inputs.size());
    for (const auto &input : inputs) {
      HYLE_ASSIGN_OR_RETURN(auto view,
          state_->memory->binding(input.source, input.description, state_->options));
      views.push_back(std::move(view));
    }
    HYLE_RETURN_IF_ERROR(state_->invocation.bind(std::span<const Tensor>(views)));
    for (std::size_t index = 0; index < inputs.size(); ++index)
      state_->inputs.retain(index, inputs[index].source);
    return Status::Ok();
  } catch (...) { return Status::ResourceExhausted("vulkan leased binding metadata"); }
}
Result<OwnedResult<Results>> LeasedInvocation::submit() noexcept {
  if (!state_ || state_->inputs.closed())
    return std::unexpected(Status::FailedPrecondition("vulkan leased invocation is empty/closed"));
  HYLE_ASSIGN_OR_RETURN(auto batch, state_->inputs.admit());
  return state_->invocation.submit_guarded(std::move(batch));
}
Status LeasedInvocation::close() noexcept {
  return state_ ? state_->inputs.close() : Status::Ok();
}
Status LeasedInvocation::drain() noexcept {
  if (!state_) return Status::Ok();
  close().IgnoreError();
  const auto terminal = state_->invocation.wait_native();
  if (!terminal.ok() && state_->inputs.active()) return terminal;
  HYLE_RETURN_IF_ERROR(state_->inputs.drain());
  return terminal;
}
} // namespace hyle::compute::vulkan
