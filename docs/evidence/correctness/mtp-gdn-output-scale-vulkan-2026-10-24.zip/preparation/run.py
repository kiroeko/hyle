"""Run only the two existing direct Vulkan GDN focused cases; no acquisition."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_gdn_vulkan_actual_build', S / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
ready = b.read(S / 'link1/ready.json')
for key in ('image', 'link_plan', 'link_result', 'runtime'):
    b.require(ready[key])
out = S / 'checks1'
out.mkdir(exist_ok=False)
runtime = b.read(ready['runtime']['path'])
command = [ready['image']['path'], '--gtest_filter=' + ready['filter'],
    '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'results.xml')]
env = dict(os.environ, PATH=runtime['PATH'])
env.pop('HYLE_VULKAN_VALIDATION', None)
b.save(out / 'plan.json', dict(entry=b.identity(Path(__file__)), command=command,
    image=ready['image'], ready=b.identity(S / 'link1/ready.json'),
    ggml_header=b.read(S / 'plan.json')['ggml_header'],
    environment={'PATH': env['PATH'], 'HYLE_VULKAN_VALIDATION': None},
    expected_cases=2, model_data=0, HTTP=0, automatic_downloads=False))
process = b.q.execute(command, env, out / 'run', timeout=600)
xml = ET.parse(out / 'results.xml').getroot() if (out / 'results.xml').is_file() else None
cases = [] if xml is None else xml.findall('.//testcase')
failures = sum(len(x.findall('failure')) for x in cases)
skips = sum(len(x.findall('skipped')) for x in cases)
passed = process['exit'] == 0 and not process['timed_out'] and len(cases) == 2 and failures == 0 and skips == 0
b.save(out / 'summary.json', dict(passed=passed, process=process, command=command,
    cases=len(cases), failures=failures, skips=skips,
    case_names=[x.attrib['classname'] + '.' + x.attrib['name'] for x in cases],
    xml=b.identity(out / 'results.xml') if xml is not None else None,
    independent_native_family='ggml.h 9ac7ee3d; no CPU/CUDA or second GGML',
    throughput_evidence=False, HTTP=0, model_data=0))
print(json.dumps(b.read(out / 'summary.json'), ensure_ascii=False), flush=True)
raise SystemExit(0 if passed else 1)
