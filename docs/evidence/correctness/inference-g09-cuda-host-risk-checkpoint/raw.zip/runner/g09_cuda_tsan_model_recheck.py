from pathlib import Path
import hashlib

root=Path('/mnt/c/public/project-hyle/hyle')
script=root/'.scratch/inference-gaps/g09_cuda_host_risk.py'
data=script.read_bytes()
assert hashlib.sha256(data).hexdigest()=='b4834e99e74ae442e77ca03b1b8f8c7f0a22105b57703e5aa3d7570b387128a4'
text=data.decode().replace("out=scratch/('g09-cuda-host-'+mode+'-1')", "out=scratch/('g09-cuda-host-'+mode+'-refcount-model-1')")
needle="text=text.replace(' endfunction()',extra+' endfunction()');hook=out/'targets.cmake';hook.write_text(text)"
assert text.count(needle)==1
addition='''
assert mode=='tsan'
model_root=scratch/'g09-tsan-refcount-model'
model=model_root/'hyle/util/ref_counted.h'
assert hashlib.sha256(model.read_bytes()).hexdigest()=='2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
body=model.read_text().replace('#include <sanitizer/tsan_interface.h>\\n','').replace('    __tsan_acquire(const_cast<std::atomic<std::uint32_t>*>(&value_));\\n','')
body=body.replace('  void acquire_before_destroy() const noexcept {','  static void acquire_before_destroy() noexcept {').replace('      refcount_.acquire_before_destroy();','      decltype(refcount_)::acquire_before_destroy();')
assert body==(source/'include/hyle/util/ref_counted.h').read_text()
r['refcount_fence_model']={'path':str(model),'sha256':hashlib.sha256(model.read_bytes()).hexdigest(),'kind':'Byte-identical pre-existing G02/G06/G08 validation-only final-acquire-fence observation. No new suppression. Exact compute runtime, common Graph and CPU-CUDA owners plus seven fixtures; other original dependencies retain their previous instrumentation boundary.'}
extra+='''+repr('''
 foreach(target IN ITEMS hyle_compute hyle_graph hyle_graph_route_cpu_cuda)
  target_include_directories("${target}" BEFORE PRIVATE "@MODEL@")
 endforeach()
''')+'''.replace('@MODEL@',str(model_root)).replace('@SOURCE@',str(source))
for target in targets:extra+='  target_include_directories('+target+' BEFORE PRIVATE "'+str(model_root)+'")\\n'
'''
text=text.replace(needle,addition+'\n'+needle)
needle="(out/'instrumented-inputs.json').write_text(json.dumps(selected,indent=2)+'\\n')"
assert text.count(needle)==1
text=text.replace(needle,needle+'''
modeled=[c for c in commands if str(model_root) in c['command']]
assert all(not c['file'].endswith('.cu') for c in modeled)
assert all(str(model_root) in c['command'] for c in selected)
assert any(c['file'].endswith('/src/compute/result.cc') and str(model_root) in c['command'] for c in commands)
(out/'model-covered-compile-inputs.json').write_text(json.dumps(modeled,indent=2)+'\\n')
''')
if len(__import__('sys').argv)>2 and __import__('sys').argv[2]=='resume':
    text=text.replace('out.mkdir(exist_ok=False)','assert out.is_dir()')
    marker='started=time.monotonic()'
    assert text.count(marker)==1
    text=text.replace(marker,'''\nprior=json.loads((out/'result.json').read_text())
assert prior['dry_run_edges']>=280 and not any(s['stage']=='build' for s in prior['stages'])
for name in ['targets.cmake','dry-run.log','result.json']:
    (out/('initial-global-model-preflight-'+name)).write_bytes((out/name).read_bytes())
r=prior
r.setdefault('retained_failures',[]).append({'stage':'first-model-preflight','planned_edges':prior['dry_run_edges'],'verdict':'Broad include placement was refused before any build. Finite correction limits the existing model to the exact compute runtime, Graph and CPU-CUDA owner TUs and fixtures. Original time and dry plan retained.'})
started=time.monotonic()-prior['elapsed_seconds']
''')
exec(compile(text,str(script)+'[existing-final-acquire-model]','exec'))
