from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps';mode=sys.argv[1]
assert mode in ['asan','ubsan','tsan']
base=Path('/root/hyle-scratch/compute-unified');source=base/'source-7a7b4c3b'
old=base/('foundation-f5-native-host-cuda-'+mode);build=old/'build'
out=scratch/('g09-cuda-host-'+mode+'-1');out.mkdir(exist_ok=False)
cache=(build/'CMakeCache.txt').read_text();assert 'HYLE_SANITIZER:STRING='+mode in cache
manifest=json.loads((scratch/'g09-risk-source-352/inputs.json').read_text())
os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
env=dict(os.environ,PATH='/usr/local/cuda-13.3/bin:'+os.environ.get('PATH',''),LD_LIBRARY_PATH='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib',
         OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',ASAN_OPTIONS='halt_on_error=1:protect_shadow_gap=0:detect_leaks=0',
         UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0')
r={'state':'SETUP','mode':mode,'stages':[],'source':str(source),'source_tree':manifest['tree'],'canonical_head':manifest['head'],'pid':os.getpid(),
   'max_jobs':2,'logical_cpus':sorted(os.sched_getaffinity(0)),'nice':os.nice(0),'nvcc_pool':1,'nvcc_split_compile':3,
   'scope':'G09 changed common/CPU-CUDA host instrumentation, original Graph direct consumers, real native-retirement fault seam, original two-slot joint pipeline and affected G06 batch/pending graph consumers. No device shader/driver/private allocator/leak certificate or SDK/P1 aggregate.',
   'retained_limits':'Same original G06/G08 host sanitizer profile and qualified native CUDA archive, including original external runtime/refcount-fence TSan boundaries; no new broad suppression.'}
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args,timeout=1800,required=True):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(mode,stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(a) for a in args],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if p.poll() is None:
                    r.setdefault('time_extensions',[]).append({'stage':stage,'seconds':timeout,'pid':p.pid});save();continue
                code=p.returncode;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        print((out/(stage+'.log')).read_text(errors='replace')[-14000:],flush=True)
        if required:r['state']='FAIL';save();raise SystemExit(code)
    return code
with zipfile.ZipFile(scratch/'g09-risk-source-352/source.zip') as z:
    changed=[]
    for item in manifest['files']:
        rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
        p=source/rel;assert p.resolve().is_relative_to(source.resolve())
        data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        if not p.is_file() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
    r['synced_paths']=changed
prior=scratch/('g08-cuda-host-'+mode+'-1/targets.cmake');text=prior.read_text()
assert text.count(' endfunction()')==1
(out/'original-g08-targets.cmake').write_text(text)
extra='\n  # Finite G09 changed-owner host risk/direct consumers.\n'
targets=[]
for name,files,include in [
    ('g09_common',['graph_test.cc','lease_submission_test.cc','native_variants_test.cc','effect_preflight_test.cc','joint_pipeline_test.cc'],'src/graph'),
    ('g09_executable',['executable_test.cc','custom_kernel_test.cc','region_provider_test.cc','cuda_graph_test.cc'],'src/compute'),
    ('g09_retirement',['aggregate_native_retirement_test.cc'],'src/graph'),
    ('g09_contracts',['cpu_cuda_contracts.cc'],None),('g09_pipeline',['cpu_cuda_pipeline.cc'],None)]:
    extra+='  add_executable('+name+'\n'+''.join('    "'+str(source/'tests/graph'/file)+'"\n' for file in files)+')\n'
    extra+='  target_link_libraries('+name+' PRIVATE hyle_graph_route_cpu_cuda hyle_compute_backend_cuda GTest::gtest_main)\n'
    if include:extra+='  target_include_directories('+name+' PRIVATE "'+str(source/include)+'")\n'
    targets.append(name)
for name,file in [('g09_g06_hybrid','public_hybrid_batch_consumer.cc'),('g09_g06_pending','pending_paged_receiver_cuda_consumer.cc')]:
    extra+='  add_executable('+name+' "'+str(source/'tests/compute_batch'/file)+'")\n'
    extra+='  target_link_libraries('+name+' PRIVATE hyle_graph_batch hyle_graph_route_cpu_cuda hyle_compute_state CUDA::cudart)\n'
    targets.append(name)
extra+='  set_source_files_properties("'+str(source/'src/graph/executable.cc')+'" DIRECTORY "'+str(source/'src/graph')+'" PROPERTIES COMPILE_DEFINITIONS HYLE_TESTING=1)\n'
extra+='  target_compile_definitions(g09_retirement PRIVATE HYLE_TESTING=1)\n'
for target in targets:
    extra+='  target_compile_features('+target+' PRIVATE cxx_std_23)\n  hyle_apply_sanitizer('+target+')\n  hyle_stage_runtime('+target+')\n'
text=text.replace(' endfunction()',extra+' endfunction()');hook=out/'targets.cmake';hook.write_text(text)
proof=json.loads((scratch/'g04-g05/cuda-host-san/ggml-cuda-reuse-proof.json').read_text())['modes'][mode]
assert hashlib.sha256(Path(proof['archive']).read_bytes()).hexdigest()==proof['archive_sha256']
imported=Path(re.search(r'IMPORTED_LOCATION "([^"]+)"',text).group(1));assert hashlib.sha256(imported.read_bytes()).hexdigest()==proof['archive_sha256']
for path,digest in proof['canonical_dependencies']:assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
r['native_reuse']={'archive':str(imported),'sha256':proof['archive_sha256'],'original_proof':str(scratch/'g04-g05/cuda-host-san/ggml-cuda-reuse-proof.json')}
configure=old/'parent' if mode=='asan' else source
run('configure',['cmake','-S',configure,'-B',build,'-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES','-DCMAKE_PROJECT_INCLUDE='+str(hook),'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF'])
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],env=env,text=True))
instrument='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
selected=[c for c in commands if c['file'].endswith(('/src/graph/executable.cc','/src/graph_route_cpu_cuda/invocation.cc','/tests/graph/aggregate_native_retirement_test.cc'))]
assert len(selected)==3 and all(instrument in c['command'] for c in selected)
assert all('HYLE_TESTING=1' in c['command'] for c in selected if not c['file'].endswith('/invocation.cc'))
(out/'instrumented-inputs.json').write_text(json.dumps(selected,indent=2)+'\n')
run('manifest',['ninja','-C',build,'build.ninja'])
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
(out/'dry-run.log').write_text(dry);r['dry_run_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<180 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry,dry
run('build',['ninja','-C',build,'-f',preview,'-j','2',*targets])
failures=[]
for target in targets:
    candidates=[build/p/target for p in [Path('.'),Path('bin'),Path('hyle'),Path('hyle/bin')]]
    binary=next(p for p in candidates if p.is_file());prefix=['setarch','x86_64','-R'] if mode=='tsan' else []
    args=prefix+[str(binary)]
    if target in ['g09_common','g09_executable','g09_retirement']:args+=['--gtest_output=json:'+str(out/(target+'.json'))]
    if run(target,args,600,False):failures.append(target)
    r.setdefault('binaries',[]).append({'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
for item in manifest['files']:assert hashlib.sha256((source/item['path']).read_bytes()).hexdigest()==item['sha256'],item
assert hashlib.sha256(imported.read_bytes()).hexdigest()==proof['archive_sha256']
r['failures']=failures;r['state']='HOST_FACET_PASS' if not failures else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save();print(json.dumps({'mode':mode,'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
