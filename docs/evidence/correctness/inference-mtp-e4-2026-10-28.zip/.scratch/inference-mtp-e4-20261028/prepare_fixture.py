"""Local metadata-only GA/MTP fixture; no payload creation, native work or network."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import shlex
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
E4 = R / '.scratch/inference-e4-model-20261025/fixture-preparation/ct-e4-aa'
SCALARS = R / '.scratch/inference-cache-precision-20261025/scalar-binding-plan/attempt1/complete.json'
OUT = W / 'fixture'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))
def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def manifest_roles(path):
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        fields = shlex.split(line)
        if not fields or not fields[0].startswith(('model.', 'mtp.')): continue
        rank = int(fields[2])
        rows.append(dict(name=fields[0], dtype=fields[1], shape=list(map(int, fields[3:3+rank])),
            path=fields[3+rank], offset=int(fields[4+rank]), bytes=int(fields[5+rank])))
    return rows

def main():
    OUT.mkdir(exist_ok=False)
    roles = manifest_roles(BASE / 'weights.tsv')
    assert len(roles) == 42 and sum(x['name'].startswith('mtp.') for x in roles) == 15
    config = json.loads((E4 / 'config.json').read_text())
    config['text_config']['layer_types'] = ['linear_attention', 'full_attention']
    config['text_config']['mtp_num_hidden_layers'] = 1
    projection = 'model.language_model.layers.1.mlp.down_proj'
    borrowed_projection = 'model.language_model.layers.0.mlp.down_proj'
    e4_roles = {x['name']: x for x in manifest_roles(E4 / 'weights.tsv')}
    for suffix in ('.weight', '.weight_scale'):
        row = dict(e4_roles[borrowed_projection + suffix]); row['name'] = projection + suffix
        roles = [x for x in roles if x['name'] != row['name']]; roles.append(row)
    scalar_receipt = json.loads(SCALARS.read_text())
    scalar_path = R / scalar_receipt['payload']['path']
    assert pin(scalar_path)['sha256'] == scalar_receipt['payload']['sha256']
    calibration = []
    for side in ('k', 'v'):
        source = next(x for x in scalar_receipt['roles'] if x['attention_slot'] == 0 and x['side'] == side)
        name = 'model.language_model.layers.1.self_attn.' + side + '_scale'
        roles.append(dict(name=name, dtype='BF16', shape=[1], path=scalar_path.as_posix(),
            offset=source['destination_offset'], bytes=2))
        calibration.append(dict(generated_role=name, source_role=source['name'],
            repository=scalar_receipt['repository'], revision=scalar_receipt['revision'],
            source_sha256=source['source_sha256'], original_bf16_bits=source['original_bf16_bits'],
            value_f32_bits=source['value_f32_bits'], offset=source['destination_offset'], bytes=2))
    payloads = {row['path']: Path(row['path']).read_bytes() for row in roles}
    for row in roles:
        raw = payloads[row['path']][row['offset']:row['offset']+row['bytes']]
        assert len(raw) == row['bytes']; row['sha256'] = sha(raw)
    assert len(payloads) == 3 and len(roles) == 45
    provenance = dict(kind='GENERATED_UNTRAINED_GA_MTP_TARGET_E4_DRAFT_PLAIN',
        base_manifest=pin(BASE / 'weights.tsv'), e4_manifest=pin(E4 / 'weights.tsv'),
        scalar_receipt=pin(SCALARS), calibration_bindings=calibration,
        projection='Borrow the existing finite CT channel/token down projection codes and BF16 channel scales; all other target and all 15 MTP roles retain original GA cached ranges.',
        target_storage='E4M3FN, original target K/V calibration only', draft_storage='plain source BF16 activation; no invented NextN calibration',
        payloads=[pin(Path(path)) for path in sorted(payloads)],
        payload_bytes_created=0, payload_bytes_copied=0, HTTP=0, quality_claim=False)
    revision = hashlib.sha1(json.dumps(provenance, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    original = dict(complete=True, repository='hyle/generated-untrained-GA-MTP-CT-target-E4', revision=revision,
        roles=sorted(roles, key=lambda row: row['name']))
    save(OUT / 'roles-source.json', original); save(OUT / 'config.json', config)
    sys.path.insert(0, str(R / 'engine/models/qwen35'))
    spec = importlib.util.spec_from_file_location('mtp_e4_preparer', R / 'engine/models/qwen35/prepare.py')
    preparer = importlib.util.module_from_spec(spec); spec.loader.exec_module(preparer)
    lines, receipt = preparer.prepare_role_files(OUT / 'roles-source.json', True, config, preparer.CT_MIXED_READER, 'e4m3fn')
    assert receipt['geometry']['layers'] == 'GA' and receipt['geometry']['mtp_layers'] == 1
    assert receipt['ct_channel_token_groups'] == 1 and receipt['ct_local_nvfp4_groups'] == 0
    assert receipt['metadata_tensor_count'] == 45 and receipt['physical_roles'] == 43
    assert receipt['cache_calibration']['bytes'] == 4 and len(receipt['cache_calibration']['original_roles']) == 2
    assert receipt['mtp_weight_bytes'] > 0 and preparer.FLOAT8_CACHE_POLICY_LINE in lines
    with (OUT / 'weights.tsv').open('x', encoding='utf-8') as stream: stream.write('\n'.join(lines) + '\n')
    with (OUT / 'prompt.ids').open('x', encoding='utf-8') as stream: stream.write('1 2 3\n')
    save(OUT / 'preparation-receipt.json', receipt); save(OUT / 'provenance.json', provenance)
    summary = dict(status='ACTUAL_PREPARER_METADATA_PASS_NO_NATIVE',
        manifest=pin(OUT / 'weights.tsv'), receipt=pin(OUT / 'preparation-receipt.json'),
        source=pin(OUT / 'roles-source.json'), config=pin(OUT / 'config.json'), provenance=pin(OUT / 'provenance.json'),
        geometry=receipt['geometry'], target_calibration_roles=2, selected_weight_roles=43, mtp_weight_roles=15,
        target_row_bytes=dict(key=64,value=64), draft_row_bytes=dict(key=128,value=128),
        row_byte_basis='Metadata geometry and E4/BF16 widths; C++ actual cache_carrier_description remains the runtime proof, not executed here.',
        borrowed_payloads=provenance['payloads'], payload_bytes_created=0, payload_bytes_copied=0,
        CXX=0, links=0, native_submissions=0, GPU=0, downloads=0,
        preparer=pin(R / 'engine/models/qwen35/prepare.py'), generator=pin(Path(__file__)))
    save(W / 'fixture-freeze.json', summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == '__main__': main()
