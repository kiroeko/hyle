"""Offline bounded E4-target/plain-draft evidence. Never builds or runs."""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile
W=Path(__file__).resolve().parent
R=W.parents[1]
V=W/'validation';H=V/'host-refinement'
DEST=R/'docs/evidence/correctness/inference-mtp-e4-2026-10-28'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def encoded(d):return(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def exact(row):
    now=pin(row['path']);assert(now['bytes'],now['sha256'])==(row['bytes'],row['sha256']),row['path']
def process(p,exit=0):
    d=read(p);assert d['exit']==exit and not d['timed_out'];return d

def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    sources=read(V/'freeze-tiny.json')['snapshots']
    for d in sources:
        exact(d['snapshot'])
        if not d['original']['path'].endswith('qwen_prefix_cache_test.cc'):exact(d['original'])
    fixed=read(H/'source-freeze.json');exact(fixed['source']);exact(fixed['snapshot'])
    cxx=[dict(unit=n,**process(V/f'logs/{n}/process.json')) for n in ('weights','tiny','host','roles')]
    cxx.append(dict(unit='host-corrected',**process(H/'logs/host/process.json')))
    links=[dict(image=n,**process(V/f'link/{n}/process.json')) for n in ('tiny','host')]
    links += [dict(image='roles',embedded_in_CXX=True,**process(V/'logs/roles/process.json')),dict(image='host-corrected',**process(H/'link/host/process.json'))]
    first=process(V/'runs/host/process.json',1);assert first['pid']==44220
    last=process(H/'run/process.json');assert last['pid']==47320 and read(H/'run/summary.json')['status']=='PASS'
    runs=[]
    for backend in ('cpu','cuda'):
        out=V/f'runs/e4-{backend}';d=read(out/'report.json');p=process(out/'process.json')
        assert d['status']=='PASS' and d['backend']==backend and d['case']=='mtp-e4-cache'
        assert(d['complete_byte_equal_checks'],d['exact_cache_backing_bytes'],d['final_versions'])==(11,314119,0)
        assert d['controlled_B2_accepted_prefixes']==[1,2] and d['controlled_B2_RNG_unchanged'] is True
        for flag in ('K1_K2','StateOnly_no_draw','partial_HostImage','original_request_key','B2_actual_verify','B2_whole_episode_cancel','survivor_R1_continue','old_checkpoints_unchanged'):
            assert d[flag] is True
        runs.append(dict(backend=backend,process=p,complete_initialized_state_byte_equal_checks=11,cache_backing_bytes=314119,
            target=dict(dtype='E4M3FN',row_bytes=64,calibration_roles=2),draft=dict(dtype='BF16',row_bytes=128),final_versions=0))
    regressions=[]
    for arm in ('sampler-cpu','preflight-cpu','roles'):
        out=V/'runs'/arm;d=read(out/'report.json');p=process(out/'process.json')
        assert read(out/'summary.json')['status']=='PASS'
        if arm=='sampler-cpu':
            assert len(d['manual']['state_checks'])==17 and all(x['payloads_byte_equal'] and x['differences']==[] for x in d['manual']['state_checks'])
            assert d['manual']['actual_B2_simultaneous_q']==4 and d['manual']['completed_q_released'] is True
            facts=dict(byte_equal_state_checks=17,sequential_models=2,natural_R=1,natural_policy_groups=3)
        elif arm=='preflight-cpu':
            assert d['preflight_submissions']==0 and d['original_key'] is True and d['same_key_peer_continued'] is True
            facts=dict(ordinary_plain_source=True,draft_source_facts_zero=True,typed_metadata_no_submit=True,same_key_peer_continues=True)
        else:assert d['checks']==13938;facts=dict(checks=13938,external_actual_E4_manifest=True)
        regressions.append(dict(arm=arm,process=p,facts=facts))
    ready=read(V/'ready-tiny.json');fixed_ready=read(H/'ready-host.json')
    inputs=read(ready['inputs']['path']);fixed_inputs=read(fixed_ready['inputs']['path']);assert len(inputs)==228 and len(fixed_inputs)==237
    weights=ready['weights']['object'];assert sum(x['path'].casefold()==weights['path'].casefold() for x in inputs)==1
    assert any(x==weights for x in fixed_inputs)
    protected={x['path'].casefold() for x in inputs+fixed_inputs}
    candidates=[]
    for p in (V/'bin/host.exe',V/'bin/host.exp',V/'bin/host.lib',V/'compile/host/unit.obj'):
        assert p.is_file() and str(p).casefold() not in protected
        candidates.append(dict(path=str(p),bytes=p.stat().st_size))
    cleanup=dict(operation='CANDIDATES_ONLY_NO_DELETE',files=candidates,count=len(candidates),bytes=sum(x['bytes'] for x in candidates),
        excluded_from_current_228_and_corrected_237_inputs=True,protected_ready=[pin(V/'ready-tiny.json'),pin(H/'ready-host.json')],
        preserve='All sources, recipes, logs, failed/successful ready receipts, evidence, successful weights and final Tiny/host; retained sampler-v4 is untouched.')
    (W/'cleanup-candidates.json').write_bytes(encoded(cleanup))
    python=dict(basis='Root actual tool receipt, not a new execution by this script',command='python -B tests/tooling/qwen_hf_roles_test.py OriginalHfRolesTest.test_ct_channel_local_and_bf16_cache_omission_are_separate_contracts',
        tool_chunk='e50d24',exit=0,reported_test_seconds=.026,test_count=1,result='OK',raw_file_unavailable=True)
    (W/'python-targeted-receipt.json').write_bytes(encoded(python))
    members={};allowed={'.py','.json','.cc','.h','.diff','.log','.xml','.tsv','.ids'}
    def add(p,name=None):
        p=Path(p);assert p.is_file() and p.suffix.lower() in allowed
        name=name or p.relative_to(R).as_posix();assert name not in members;members[name]=p.read_bytes()
    for root in (W,W/'product-main',V,H):
        if root.exists():
            for p in sorted(root.iterdir()):
                if p.is_file() and p.suffix.lower() in allowed:add(p)
    for root in (W/'fixture',V/'source',H/'source',V/'compile',V/'logs',V/'link',V/'runs',H/'compile',H/'logs',H/'link',H/'run'):
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.suffix.lower() in allowed:add(p)
    refs=[]
    reference=R/'docs/evidence/correctness/inference-mtp-logits-2026-10-28.json';refs.append(pin(reference));add(reference,'references/mtp-logits-baseline.json')
    for p,name in ((R/'.scratch/inference-mtp-logits-20261028/refinement/ready-tiny.json','baseline-ready-tiny.json'),(R/'.scratch/inference-mtp-stop-policy-20261028/ready-host.json','baseline-ready-host.json'),(R/'.scratch/inference-indexed-store-20261028/build.py','base-tools.py'),(R/'.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py','sampler-parser.py'),(R/'.scratch/inference-mtp-logits-20261028/refinement/run.py','preflight-parser.py')):add(p,'references/'+name)
    evidence=dict(status='PASS_BOUNDED_TARGET_E4_WITH_PLAIN_MTP_CACHE',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base='01bafa448',
        implementation=['PreparedWeightSource carries independent actual target/draft row extents. Source preparation derives target from its calibrated carrier and draft from plain source activation, zero without MTP.',
            'Cache Plan and actual arenas account for target and draft banks independently, including every bank sentinel; checked arithmetic and original resource budget remain.',
            'Original authenticated target calibration and CT policy are retained; MTP is no longer categorically rejected. No NextN calibration, quantization, kernel, executor or ownership mechanism is invented.'],
        counts=dict(actual_CXX=5,successful_CXX=5,actual_links=4,successful_links=4,roles_link_embedded_in_CXX=1,
            recorded_test_and_model_processes=7,successful=6,retained_host_failure=1,model_processes=4,sequential_Model_instances=5,
            separately_root_reported_Python_test_processes=1,SDK_CXX=0,NVCC=0,downloads=0),
        builds=dict(CXX=cxx,links=links,current_Tiny_inputs=228,current_host_inputs=237,
            current_Tiny_image=ready['image'],corrected_host_image=fixed_ready['image'],weights_object=weights),
        E4_runs=runs,regressions=regressions,host=dict(first_failure=first,corrected_pass=last,
            test='QwenSessionState.BatchCapacityPreservesSingleAndBoundsAllCandidates',
            cause='Test expected 158515251 incorrectly used twelve A layers; this Qwen fixture has twenty-four total layers and six A layers.',
            correction='171491379-(1081345-540673)*2*6 = 165003315, plus explanatory comment; no product change.',
            dependency_proof=pin(H/'reuse-proof.json'),failure_logs_retained=True,no_successful_model_rerun=True),
        Python_targeted=python,source_freezes=dict(owned=pin(W/'product-source-freeze.json'),main=pin(W/'product-main/source-freeze.json'),
            initial_changed_sources=pin(V/'expected-sources.json'),corrected_host=pin(H/'source-freeze.json')),
        source_boundary='The initial 29-file planned pin set is broader than actual compilation includes. Actual MSVC dependency receipts prove prefix test constant/comment changes are absent from Tiny, weights and roles; only host was rebuilt.',
        fixture=dict(manifest=pin(W/'fixture/weights.tsv'),provenance=pin(W/'fixture/provenance.json'),receipt=pin(W/'fixture/preparation-receipt.json'),
            geometry='Untrained GA/H64/D64/V64/C16 + all fifteen original cached BF16 MTP weight roles',metadata_roles=45,weight_roles=43,target_calibration_roles=2,
            existing_payloads_referenced=3,payload_bytes_created=0,payload_bytes_copied=0,
            scale_scope='Report available=4 refers to the old AA fixture calibration bindings; the full borrowed 64-byte scalar pool contains thirty-two target roles, and this GA fixture selects exactly two. No mtp.* calibration exists or is used.'),
        exercised=['R1 real K1 and recursive K2 repeated controls, exact initialized target/draft/GDN/conv/hidden state and retained checkpoints.',
            'Q1 StateOnly chunks, no output/RNG draw before EmitNext, partial HostImage restore under the original request key, then recursive continuation.',
            'B2 original submitted K3 verifier with controlled accepted prefixes [1,2], real repair and unchanged RNG, compared against a same-geometry full-state control.',
            'Another actual B2 submission is wholly aborted after one member stops; both prior heads remain unchanged and the survivor continues as R1.'],
        limits=['CPU/CUDA finite synthetic consumer only; no quality, random acceptance-rate, throughput, native fault or other-platform claim.',
            'The new E4 consumer uses Commands replay. This does not establish captured E4+MTP replay or device continuation.',
            'All eleven initialized-state comparisons per backend are byte-exact; no cross-backend bit-identity claim.',
            'Draft remains plain BF16. No all-E4 draft cache or original NextN calibration support is claimed.',
            'Old ordinary E4 entry was not scheduled. Ordinary non-E4 target-only new source facts are covered by logits-preflight CPU; older ordinary E4 evidence is historical.',
            'Recorded durations are provenance, not performance results. Inventory/version checks do not imply a complete native allocator live-zero proof.',
            'No whole-SDK ABI/header audit: engine-private changed consumers and actual local dependencies were refreshed; unchanged external SDK/runtime objects are reused.'],
        references=refs,reproduction=dict(build_helper=(V/'build.py').relative_to(R).as_posix(),run_helper=(V/'run.py').relative_to(R).as_posix(),
            host_correction_helper=(H/'build.py').relative_to(R).as_posix(),policy='Explicit single-use actions, preserve failure; parser repair is offline and never reruns successful consumers.'),
        cleanup_candidates=cleanup,raw_manifest='manifest.json')
    members['evidence-core.json']=encoded(evidence)
    members['manifest.json']=encoded(dict(files=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(members.items())],
        excluded=['EXE/OBJ/EXP/PDB/DLL/LIB','model/binary payload','SDK/header/source tree copies','unrelated dirty docs/license']))
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(members.items()):z.writestr(n,b)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as z:
        assert z.testzip() is None
        for row in json.loads(z.read('manifest.json'))['files']:
            raw=z.read(row['path']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    evidence['archive']=dict(**pin(DEST.with_suffix('.zip')),files=len(members),CRC_and_member_SHA256_verified=True)
    DEST.with_suffix('.json').write_bytes(encoded(evidence))
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')),archive=evidence['archive'],counts=evidence['counts'],cleanup=dict(count=cleanup['count'],bytes=cleanup['bytes'])),indent=2))

if __name__=='__main__':main()
