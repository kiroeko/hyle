"""Four finite canonical CXX recipes; root explicitly freezes/builds/runs."""
from pathlib import Path
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
BASE = R / '.scratch/inference-mtp-logits-20261028/refinement'
HOST = R / '.scratch/inference-mtp-stop-policy-20261028'
WEIGHTS = R / '.scratch/inference-relay-carriers-20261027/attempt2/compile/weights'
ROLES = R / '.scratch/inference-cache-precision-20261025/role-policy/host1/qwen_prepared_roles_test'
spec = importlib.util.spec_from_file_location('bounded_tools', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W
SOURCES = dict(tiny='tests/tools/qwen_host_image_test.cc',weights='engine/models/qwen35/weights.cc',
    host='tests/tools/qwen_prefix_cache_test.cc',roles='tests/tools/qwen_prepared_roles_test.cc')

def adapt_compile(args, name, old_source):
    out = W / 'compile' / name; changed = 0; result = []
    for at,arg in enumerate(args):
        if t.key(arg) == t.key(old_source): arg = str(R / SOURCES[name]); changed += 1
        elif at and args[at-1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
        elif name == 'roles' and arg.lower().startswith('/fe:'): arg = '/Fe:' + str(W / 'bin/roles.exe')
        result.append(arg)
    assert changed == 1 and '/MD' in result and '/O2' in result
    assert any(t.key(x) == t.key(R / SOURCES[name]) for x in result)
    return result

def prepare():
    tiny,host = t.read(BASE/'ready-tiny.json'),t.read(HOST/'ready-host.json')
    units = {}; baselines = {}
    for name,ready,root,count in [('tiny',tiny,BASE,228),('host',host,HOST,237)]:
        t.exact(ready['inputs']); rows = t.read(ready['inputs']['path']); assert len(rows)==count
        actual = t.read(ready['compiled']['dependencies']['path'])['Data']
        assert t.key(actual['Source']) == t.key(R / SOURCES[name])
        recipe = dict(command=adapt_compile(t.command(ready['compiled']['command']['path']),name,actual['Source']),timeout_seconds=300)
        t.save(W/f'recipe-{name}.json',recipe)
        units[name] = dict(source=str(R/SOURCES[name]),recipe=t.pin(W/f'recipe-{name}.json'),
            old_object=ready['compiled']['object'],old_dependencies=ready['compiled']['dependencies'],kind='CXX')
        baselines[name] = dict(ready=t.pin(root/f'ready-{name}.json'),inputs=ready['inputs'],recipe=ready['recipe'],count=count)
    dep=WEIGHTS/'dependencies.json'; old=t.read(dep)['Data']['Source']; assert t.key(old)==t.key(R/SOURCES['weights'])
    t.save(W/'recipe-weights.json',dict(command=adapt_compile(t.command(WEIGHTS/'command.json'),'weights',old),timeout_seconds=300))
    units['weights']=dict(source=str(R/SOURCES['weights']),recipe=t.pin(W/'recipe-weights.json'),
        old_object=next(x for x in t.read(tiny['inputs']['path']) if t.key(x['path'])==t.key(WEIGHTS/'unit.obj')),
        old_dependencies=t.pin(dep),kind='CXX')
    args=t.command(ROLES/'compile/command.json'); old=next(x for x in args if x.lower().endswith('qwen_prepared_roles_test.cc'))
    t.save(W/'recipe-roles.json',dict(command=adapt_compile(args,'roles',old),timeout_seconds=180))
    units['roles']=dict(source=str(R/SOURCES['roles']),recipe=t.pin(W/'recipe-roles.json'),
        old_dependencies=t.pin(ROLES/'sourceDependencies.json'),kind='CXX_WITH_EMBEDDED_LINK')
    for name in ('tiny','host'):
        oldweights=units['weights']['old_object']['path']; oldtest=units[name]['old_object']['path']; swaps={t.key(oldtest):str(W/f'compile/{name}/unit.obj')}
        rows=t.read(baselines[name]['inputs']['path']); n=sum(t.key(x['path'])==t.key(oldweights) for x in rows)
        assert n==1 if name=='tiny' else n<=1
        if n: swaps[t.key(oldweights)]=str(W/'compile/weights/unit.obj')
        args=[]
        for arg in t.command(baselines[name]['recipe']['path']):
            arg=swaps.get(t.key(arg),arg)
            for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')]:
                if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
            args.append(arg)
        t.save(W/f'link-{name}.json',dict(command=args,timeout_seconds=240))
        baselines[name].update(swaps=swaps,weights_replacements=n,link=t.pin(W/f'link-{name}.json'))
    rows={t.key(x['path']):x for base in baselines.values() for x in t.read(base['inputs']['path'])}
    t.save(W/'retained-input-stats.json',[dict(path=x['path'],bytes=Path(x['path']).stat().st_size,mtime_ns=Path(x['path']).stat().st_mtime_ns) for x in rows.values()])
    env=t.read(BASE/'environment.json');env['PATH']=str(W/'bin')+';'+env['PATH'];t.save(W/'environment.json',env)
    t.save(W/'runtime-plan.json',dict(native=t.read(BASE/'runtime-plan.json')['native'],method='Same-file original CPU DLL hardlink; no SDK/payload copies',
        planned_models=['mtp-e4 CPU','mtp-e4 CUDA','original non-E4 sampler CPU','ordinary E4 CPU'],host_filter='QwenSessionState.BatchCapacityPreservesSingleAndBoundsAllCandidates',
        roles_arguments=[str(W/'roles-fixtures'),str(W.parent/'fixture/weights.tsv')]))
    t.save(W/'plan.json',dict(status='PREPARED_NOT_SOURCE_FROZEN',units=units,baselines=baselines,
        environment=t.pin(W/'environment.json'),retained_stats=t.pin(W/'retained-input-stats.json'),
        counts=dict(planned_CXX=4,planned_links=3,embedded_roles_link=1,SDK_CXX=0,NVCC=0,downloads=0),
        compatibility='PreparedWeightSource and Cache Plan are engine-private layout changes: replace Tiny+weights; prefix host is recompiled. No public SDK layout change or blanket retained header proof is claimed.',
        actions=['freeze UNIT','compile weights|tiny|host|roles','link tiny|host'],roles_link='compile roles invokes the original cl driver embedded link once'))
    print('PREPARED ONLY: Tiny228 replaces Tiny+weights; host237 replaces prefix and weights when present; roles cl includes link')

def prepared():
    plan=t.read(W/'plan.json');t.exact(plan['environment']);t.exact(plan['retained_stats'])
    for unit in plan['units'].values():t.exact(unit['recipe']);t.exact(unit['old_dependencies'])
    for base in plan['baselines'].values():
        for key in ('ready','inputs','recipe','link'):t.exact(base[key])
    return plan

def project_paths(unit,expected):
    roots=[]
    for arg in t.command(unit['recipe']['path']):
        if arg.lower().startswith('/i'):roots.append(Path(arg[2:]))
        elif arg.lower().startswith('/external:i'):roots.append(Path(arg[11:]))
    paths={t.key(t.canonical(p)):t.canonical(p) for p in t.dep_paths(unit['old_dependencies']['path']) if t.project(t.canonical(p))}
    pending=[R/SOURCES[name] for name in SOURCES if t.key(R/SOURCES[name])==t.key(unit['source'])]+[R/x for x in expected]
    seen=set()
    while pending:
        p=pending.pop().resolve()
        if t.key(p) in seen:continue
        seen.add(t.key(p));paths[t.key(p)]=p
        for name in re.findall(r'^\s*#\s*include\s*"([^"\r\n]+)"',p.read_text(encoding='utf-8-sig'),re.M):
            q=next((q.resolve() for root in [p.parent,*roots] if (q:=root/name).is_file()),None)
            if q and t.project(q):pending.append(q)
    return list(paths.values())

def freeze(name):
    plan=prepared();expected=t.read(W/'expected-sources.json')
    assert SOURCES[name] in expected
    for file,sha in expected.items():assert t.pin(R/file)['sha256']==sha,file
    deps=[t.pin(p) for p in project_paths(plan['units'][name],expected)]
    snapshots=[]
    for file in expected:
        src=R/file;out=W/'source'/file;out.parent.mkdir(parents=True,exist_ok=True)
        if out.exists():assert out.read_bytes()==src.read_bytes()
        else:
            with out.open('xb') as f:f.write(src.read_bytes())
        snapshots.append(dict(original=t.pin(src),snapshot=t.pin(out)))
    t.save(W/f'freeze-{name}.json',dict(expected=t.pin(W/'expected-sources.json'),helper=t.pin(W/'build.py'),dependencies=deps,snapshots=snapshots))
    print('FROZEN ONLY',name)

def validate(name):
    plan=prepared();frozen=t.read(W/f'freeze-{name}.json');t.exact(frozen['expected']);t.exact(frozen['helper'])
    for row in frozen['dependencies']:t.exact(row)
    for row in frozen['snapshots']:t.exact(row['snapshot'])
    return plan,frozen

def compile_one(name):
    plan,frozen=validate(name);out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False);(W/'bin').mkdir(exist_ok=True)
    process=t.execute(t.command(plan['units'][name]['recipe']['path']),W/'logs'/name,300)
    validate(name);allowed={t.key(x['path']):x for x in frozen['dependencies']};actual=[]
    for path in dict.fromkeys(t.dep_paths(out/'dependencies.json')):
        if t.project(path):assert t.key(path) in allowed,str(path);t.exact(allowed[t.key(path)]);actual.append(t.pin(path))
    t.save(out/'actual-project-dependencies.json',actual)
    compiled=dict(source=t.pin(R/SOURCES[name]),object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/'logs'/name/'command.json'),dependencies=t.pin(out/'dependencies.json'),freeze=t.pin(W/f'freeze-{name}.json'))
    t.save(out/'compiled.json',compiled)
    if name=='roles':t.save(W/'ready-roles.json',dict(image=t.pin(W/'bin/roles.exe'),compiled=compiled,process=process,
        embedded_link=True,plan=t.pin(W/'plan.json')))
    print('CXX PASS',name,'with embedded link' if name=='roles' else '')

def link(name):
    assert name in ('tiny','host');plan,_=validate(name);base=plan['baselines'][name]
    for row in t.read(plan['retained_stats']['path']):
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns']),row['path']
    compiled={n:t.read(W/f'compile/{n}/compiled.json') for n in [name,'weights'] if n==name or base['weights_replacements']}
    for n,c in compiled.items():validate(n);t.exact(c['object'])
    swaps={t.key(plan['units'][n]['old_object']['path']):c['object'] for n,c in compiled.items()}
    rows=[swaps.get(t.key(x['path']),x) for x in t.read(base['inputs']['path'])];assert len(rows)==base['count']
    assert not(W/'bin'/f'{name}.exe').exists();t.save(W/f'inputs-{name}.json',rows)
    process=t.execute(t.command(base['link']['path']),W/'link'/name,240)
    t.save(W/f'ready-{name}.json',dict(image=t.pin(W/'bin'/f'{name}.exe'),inputs=t.pin(W/f'inputs-{name}.json'),
        recipe=t.pin(W/'link'/name/'command.json'),compiled=compiled[name],weights=compiled.get('weights'),process=process,
        plan=t.pin(W/'plan.json'),source_freeze=t.pin(W/f'freeze-{name}.json')))
    print('LINK PASS',name)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze(sys.argv[2])
    elif action=='compile':compile_one(sys.argv[2])
    elif action=='link':link(sys.argv[2])
    else:raise ValueError(action)
