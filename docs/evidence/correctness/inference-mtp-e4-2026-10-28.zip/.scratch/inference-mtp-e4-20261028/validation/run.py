"""Finite single-use runs; root controls execution. Parser repair is offline."""
from pathlib import Path
import importlib.util
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('e4_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
t,R=b.t,b.R
FIXTURE=W.parent/'fixture'
PLAIN=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
SAMPLER=R/'.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py'
PREFLIGHT=R/'.scratch/inference-mtp-logits-20261028/refinement/run.py'
FILTER='QwenSessionState.BatchCapacityPreservesSingleAndBoundsAllCandidates'

def prepare():
    b.prepared()
    t.save(W/'run-plan.json',dict(status='PLANNED_NOT_RUN',parser=t.pin(W/'run.py'),fixture=t.pin(FIXTURE/'weights.tsv'),
        plain_fixture=t.pin(PLAIN/'weights.tsv'),sampler_parser=t.pin(SAMPLER),preflight_parser=t.pin(PREFLIGHT),
        arms=['host','roles','e4-cpu','e4-cuda','sampler-cpu','preflight-cpu'],actual_processes_planned=6,actual_model_processes_planned=4,
        models=dict(e4_cpu=1,e4_cuda=1,sampler_cpu=2,preflight_cpu=1),host_filter=FILTER,
        optional_ordinary_e4='No existing frozen driver entry; not scheduled, no extra TU or implicit run.',
        python_targeted='Root already executed tests/tooling/qwen_hf_roles_test.py OriginalHfRolesTest.test_ct_channel_local_and_bf16_cache_omission_are_separate_contracts: Ran 1 / OK; do not repeat.',
        policy='First failure stops; never rerun a successful process to repair a parser. parse ARM reads existing logs only.'))
    print('RUN PLAN ONLY: host+roles, E4 CPU/CUDA, original sampler CPU, ordinary preflight CPU')

def e4_report(values,backend):
    assert len(values)==1
    d=values[0];assert d['status']=='PASS' and d['case']=='mtp-e4-cache' and d['backend']==backend
    assert(d['models'],d['original_calibration_roles_used'],d['original_calibration_roles_available'],d['target_row_bytes'],d['draft_row_bytes'],d['complete_byte_equal_checks'],d['final_versions'])==(1,2,4,64,128,11,0)
    assert d['target_storage']=='E4M3FN' and d['draft_storage']=='BF16' and d['exact_cache_backing_bytes']>0
    assert d['controlled_B2_accepted_prefixes']==[1,2]
    for field in ['K1_K2','StateOnly_no_draw','partial_HostImage','original_request_key','B2_actual_verify','controlled_B2_RNG_unchanged','B2_whole_episode_cancel','survivor_R1_continue','old_checkpoints_unchanged','synthetic_untrained']:
        assert d[field] is True,field
    assert d['quality_claim'] is False and d['performance_claim'] is False
    return d

def parse(arm):
    out=W/'runs'/arm;process=t.read(out/'process.json');assert process['exit']==0 and not process['timed_out'],process
    if arm=='host':
        xml=ET.parse(out/'report.xml').getroot();cases=list(xml.iter('testcase'))
        assert len(cases)==1 and cases[0].get('name')=='BatchCapacityPreservesSingleAndBoundsAllCandidates'
        assert not list(xml.iter('failure')) and not list(xml.iter('error')) and not list(xml.iter('skipped'))
        report=dict(status='PASS',case=FILTER,testcases=1)
    else:
        text=(out/'stdout.log').read_text(encoding='utf-8-sig')
        if arm=='roles':
            match=re.search(r'^PASS (\d+) checks:',text,re.M);assert match and int(match.group(1))>0
            report=dict(status='PASS',checks=int(match.group(1)),external_actual_E4_manifest=True)
        else:
            values=[json.loads(line) for line in text.splitlines() if line.startswith('{')]
            if arm.startswith('e4-'):report=e4_report(values,arm.split('-')[1])
            elif arm=='preflight-cpu':
                spec=importlib.util.spec_from_file_location('original_preflight_parser',PREFLIGHT);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
                report=m.preflight_report(values)
            else:
                spec=importlib.util.spec_from_file_location('original_sampler_parser',SAMPLER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
                report=m.sampler_reports(values,'cpu')
    t.save(out/'report.json',report);t.save(out/'summary.json',dict(status='PASS',arm=arm,process=process,report=t.pin(out/'report.json')))
    print('PASS',arm,'PID',process['pid'])

def run(arm):
    assert arm in ('host','roles','e4-cpu','e4-cuda','sampler-cpu','preflight-cpu');plan=t.read(W/'run-plan.json')
    for field in ('parser','fixture','plain_fixture','sampler_parser','preflight_parser'):t.exact(plan[field])
    name=arm if arm in ('host','roles') else 'tiny';b.validate(name)
    ready=t.read(W/f'ready-{name}.json');t.exact(ready['image'])
    if 'inputs' in ready:t.exact(ready['inputs'])
    native=t.read(W/'runtime-plan.json')['native'];t.exact(native);src=Path(native['path']);alias=W/'bin'/src.name
    if not alias.exists():os.link(src,alias)
    assert os.path.samefile(src,alias)
    out=W/'runs'/arm;assert not out.exists(),'Already run; repair parser with parse ARM instead'
    args=[ready['image']['path']]
    if arm=='host':args += ['--gtest_filter='+FILTER,'--gtest_output=xml:'+str(out/'report.xml')]
    elif arm=='roles':args += [str(W/'roles-fixtures'),str(FIXTURE/'weights.tsv')]
    else:args += ['--'+('cuda' if arm=='e4-cuda' else 'cpu'),str(PLAIN if arm in ('sampler-cpu','preflight-cpu') else FIXTURE),'--mtp-sampling' if arm=='sampler-cpu' else '--logits-preflight' if arm=='preflight-cpu' else '--mtp-e4']
    process=t.execute(args,out,300)
    t.save(out/'as-run.json',dict(ready=t.pin(W/f'ready-{name}.json'),image=ready['image'],inputs=ready.get('inputs'),
        plan=t.pin(W/'run-plan.json'),environment=t.pin(W/'environment.json'),runtime_source=native,runtime_alias=str(alias),same_file=True,process=process))
    parse(arm)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='run':run(sys.argv[2])
    elif action=='parse':parse(sys.argv[2])
    else:raise ValueError(action)
