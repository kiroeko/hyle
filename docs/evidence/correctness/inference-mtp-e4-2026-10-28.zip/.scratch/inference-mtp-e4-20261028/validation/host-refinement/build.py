"""Host-only constant correction; reuses successful weights and all other inputs."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[3]
BASE=W.parent
SOURCE=R/'tests/tools/qwen_prefix_cache_test.cc'
spec=importlib.util.spec_from_file_location('parent_recipes',BASE/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=W;b.t.W=W;t=b.t
FILTER='QwenSessionState.BatchCapacityPreservesSingleAndBoundsAllCandidates'

def prepare():
    old=t.read(BASE/'ready-host.json');t.exact(old['inputs']);rows=t.read(old['inputs']['path']);assert len(rows)==237
    assert sum(t.key(x['path'])==t.key(old['compiled']['object']['path']) for x in rows)==1
    assert sum(t.key(x['path'])==t.key(old['weights']['object']['path']) for x in rows)==1
    t.save(W/'recipe.json',dict(command=b.adapt_compile(t.command(old['compiled']['command']['path']),'host',SOURCE),timeout_seconds=180))
    args=[]
    for arg in t.command(old['recipe']['path']):
        if t.key(arg)==t.key(old['compiled']['object']['path']):arg=str(W/'compile/host/unit.obj')
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/host').with_suffix(suffix));break
        args.append(arg)
    t.save(W/'link-recipe.json',dict(command=args,timeout_seconds=240))
    env=t.read(BASE/'environment.json');env['PATH']=str(W/'bin')+';'+env['PATH'];t.save(W/'environment.json',env)
    t.save(W/'input-stats.json',[dict(path=x['path'],bytes=Path(x['path']).stat().st_size,mtime_ns=Path(x['path']).stat().st_mtime_ns) for x in rows])
    t.save(W/'plan.json',dict(status='PREPARED_NOT_FROZEN',baseline=t.pin(BASE/'ready-host.json'),inputs=old['inputs'],
        old_object=old['compiled']['object'],weights_reused=old['weights']['object'],old_dependencies=old['compiled']['dependencies'],
        recipe=t.pin(W/'recipe.json'),link=t.pin(W/'link-recipe.json'),environment=t.pin(W/'environment.json'),
        stats=t.pin(W/'input-stats.json'),first_host_failure=t.pin(BASE/'runs/host/process.json'),
        first_source=t.pin(BASE/'source/tests/tools/qwen_prefix_cache_test.cc'),
        correction='158515251 -> 165003315: Qwen fixture has six A layers, not twelve. 171491379-(1081345-540673)*2*6.',
        counts=dict(CXX=1,links=1,host_processes=1,Tiny_CXX=0,weights_CXX=0,SDK_CXX=0,NVCC=0)))
    print('HOST REFINEMENT PREPARED ONLY; do not freeze until the root corrects the canonical literal')

def prepared():
    p=t.read(W/'plan.json')
    for k in ('baseline','inputs','recipe','link','environment','stats','first_host_failure','first_source'):t.exact(p[k])
    return p

def freeze():
    p=prepared();before=Path(p['first_source']['path']).read_bytes();after=SOURCE.read_bytes()
    comment=b'      // Six target attention layers save 6*2*540672 bytes; NextN does not.'
    without_comment=b''.join(line for line in after.splitlines(keepends=True) if line.rstrip(b'\r\n')!=comment)
    assert before.count(b'158515251')==1 and without_comment==before.replace(b'158515251',b'165003315'),'Only the approved expected constant and six-layer explanation may differ'
    unit=dict(source=str(SOURCE),recipe=p['recipe'],old_dependencies=p['old_dependencies'])
    deps=[t.pin(q) for q in b.project_paths(unit,{'tests/tools/qwen_prefix_cache_test.cc':t.pin(SOURCE)['sha256']})]
    target=W/'source/qwen_prefix_cache_test.cc';target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(after)
    t.save(W/'source-freeze.json',dict(source=t.pin(SOURCE),snapshot=t.pin(target),dependencies=deps,helper=t.pin(W/'build.py')))
    print('HOST SOURCE FROZEN ONLY')

def validate():
    p=prepared();f=t.read(W/'source-freeze.json');t.exact(f['source']);t.exact(f['snapshot']);t.exact(f['helper'])
    for row in f['dependencies']:t.exact(row)
    return p,f

def compile_one():
    p,f=validate();out=W/'compile/host';out.mkdir(parents=True,exist_ok=False);(W/'bin').mkdir(exist_ok=True)
    process=t.execute(t.command(p['recipe']['path']),W/'logs/host',180);validate()
    allowed={t.key(x['path']):x for x in f['dependencies']};actual=[]
    for q in dict.fromkeys(t.dep_paths(out/'dependencies.json')):
        if t.project(q):assert t.key(q) in allowed;actual.append(t.pin(q))
    t.save(out/'actual-project-dependencies.json',actual)
    t.save(out/'compiled.json',dict(source=t.pin(SOURCE),object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/'logs/host/command.json'),dependencies=t.pin(out/'dependencies.json')))
    print('HOST CXX PASS')

def link():
    p,_=validate();c=t.read(W/'compile/host/compiled.json');t.exact(c['object'])
    for row in t.read(p['stats']['path']):
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    rows=[c['object'] if t.key(x['path'])==t.key(p['old_object']['path']) else x for x in t.read(p['inputs']['path'])]
    assert len(rows)==237;t.save(W/'inputs-host.json',rows)
    process=t.execute(t.command(p['link']['path']),W/'link/host',240)
    t.save(W/'ready-host.json',dict(image=t.pin(W/'bin/host.exe'),inputs=t.pin(W/'inputs-host.json'),
        compiled=c,weights=p['weights_reused'],recipe=t.pin(W/'link/host/command.json'),process=process,
        source_freeze=t.pin(W/'source-freeze.json'),plan=t.pin(W/'plan.json')))
    print('HOST LINK PASS')

def run():
    validate();ready=t.read(W/'ready-host.json');t.exact(ready['image']);t.exact(ready['inputs'])
    native=t.read(BASE/'runtime-plan.json')['native'];t.exact(native);src=Path(native['path']);alias=W/'bin'/src.name
    if not alias.exists():os.link(src,alias)
    assert os.path.samefile(src,alias)
    out=W/'run';process=t.execute([ready['image']['path'],'--gtest_filter='+FILTER,'--gtest_output=xml:'+str(out/'report.xml')],out,180)
    xml=ET.parse(out/'report.xml').getroot();cases=list(xml.iter('testcase'))
    assert len(cases)==1 and not list(xml.iter('failure')) and not list(xml.iter('error')) and not list(xml.iter('skipped'))
    t.save(out/'summary.json',dict(status='PASS',case=FILTER,process=process,ready=t.pin(W/'ready-host.json')))
    print('HOST PASS',process['pid'])

if __name__=='__main__':{'prepare':prepare,'freeze':freeze,'compile':compile_one,'link':link,'run':run}[sys.argv[1]]()
