"""Root-owned execution of one already-built relocated installed consumer."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

R = Path('/mnt/c/public/project-hyle/hyle')
B = R / '.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-build-2026-10-21'
remote = Path('/root/hyle-scratch/active-cpu-z/delivery1-linux-current-build-2026-10-21')
sample = sys.argv[1]
assert sample in ['cpp', 'cpu_cuda']
suffix = '2' if sample == 'cpp' else ''
image_row = json.loads((B / ('consumer-' + sample + suffix + '-image.json')).read_text())
image = Path(image_row['path'])
assert image.is_file() and hashlib.sha256(image.read_bytes()).hexdigest() == image_row['sha256']
relocation = json.loads((B / 'relocation.json').read_text())
assert not Path(relocation['original_prefix']).exists() and Path(relocation['relocated_prefix']).is_dir()
name = 'consumer-run-' + sample
assert not (B / (name + '.result.json')).exists(), 'Preserve actual first execution'
record = dict(command=[str(image)], cwd=str(image.parent), started=time.time(),
              execution_owner='root', image=image_row, relocated_prefix=relocation['relocated_prefix'])
(B / (name + '.command.json')).write_text(json.dumps(record, indent=2))
with (B / (name + '.stdout.log')).open('w') as out, (B / (name + '.stderr.log')).open('w') as err:
    child = subprocess.Popen(record['command'], cwd=image.parent, stdout=out, stderr=err)
    record['pid'] = child.pid
    (B / (name + '.live.json')).write_text(json.dumps(record, indent=2))
    try:
        code = child.wait(timeout=180)
        record['timeout'] = False
    except subprocess.TimeoutExpired:
        child.kill()
        code = child.wait()
        record['timeout'] = True
record.update(exit_code=code, seconds=time.time()-record['started'], terminal=True)
(B / (name + '.result.json')).write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
raise SystemExit(code if code >= 0 else 1)
