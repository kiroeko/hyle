from pathlib import Path
import subprocess,json,time,sys,hashlib,shutil
R=Path('/mnt/c/public/project-hyle/hyle');S=R/'.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-build-2026-10-21';old=R/'.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21'
work=Path('/root/hyle-scratch/active-cpu-z');build=work/'build';phase=sys.argv[1]
if phase=='configure':
 command=json.loads((old/'configure.command.json').read_text())['command']
 command=['-DHYLE_COMPONENTS=compute;graph;graph_progress' if x=='-DHYLE_COMPONENTS=graph;graph_progress' else x for x in command]
 before=work/'delivery1-linux-current-build-2026-10-21/before-compute-product';before.mkdir(parents=True,exist_ok=False)
 for rel in ['CMakeCache.txt','build.ninja','HylePackageIndex.cmake']:
  shutil.copy2(build/rel,before/rel)
elif phase in ['build','build2']:command=['cmake','--build',str(build),'--parallel','2']
elif phase=='install':command=['cmake','--install',str(build)]
else:raise SystemExit('Unknown phase')
assert not (S/(phase+'.result.json')).exists(),'Preserve first result'
started=time.time();record=dict(command=command,cwd=str(work),started=started,phase=phase,gpu_compute_runs=0)
(S/(phase+'.command.json')).write_text(json.dumps(record,indent=2))
with (S/(phase+'.stdout.log')).open('w') as out,(S/(phase+'.stderr.log')).open('w') as err:
 child=subprocess.Popen(command,cwd=work,stdout=out,stderr=err)
 record['pid']=child.pid;(S/(phase+'.live.json')).write_text(json.dumps(record,indent=2))
 code=child.wait()
record.update(exit_code=code,seconds=time.time()-started)
(S/(phase+'.result.json')).write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
