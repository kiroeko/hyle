from pathlib import Path
from collections import Counter
import json
import re

B = Path(__file__).resolve().parent
phases=[]
for phase in ['build','build2']:
    text=(B/(phase+'.stdout.log')).read_text(encoding='utf-8')
    jobs=[m.group(1) for m in re.finditer(r'^\[\d+/\d+\] (.+)$',text,re.M)]
    phases.append(dict(phase=phase, reported_rows=len(jobs), payload_jobs=[x for x in jobs if not x.startswith('Re-checking')]))
unique=list(dict.fromkeys(x for phase in phases for x in phase['payload_jobs']))
counts=Counter()
for row in unique:
    if 'hyle_ggml_cpu_avx2' in row:
        group='original_AVX2_CPU_program'
    elif '/vendor/' in row or re.search(r'bin/libggml(?:-base|-cpu|-cuda)?\.a$',row):
        group='ggml_vendor'
    elif 'mimalloc_static' in row:
        group='mimalloc'
    else:
        group='Hyle'
    operation=row.split(' object ')[0] if ' object ' in row else row.split(' library ')[0]
    if row.startswith('Linking CXX shared module'):
        operation='Linking CXX shared module'
    counts[group,operation]+=1
assert len(unique)==477
assert counts['ggml_vendor','Building CUDA']==145
assert sum(v for k,v in counts.items())==477
record=dict(unique_payload_jobs=len(unique), payload_command_attempts=sum(len(x['payload_jobs']) for x in phases),
    first_failed_payload_commands=1, first_failure='GCC missing-field-initializers in original constant-recipe owner; only explicit empty member initializers added.',
    phases=phases, counts=[dict(family=k[0],operation=k[1],count=v) for k,v in counts.items()],
    scope_note='The earlier 146-unit GGML-family estimate comprises 145 vendor CUDA TUs plus the Hyle runtime bfloat-cast CUDA helper. The 4 oneDNN-facing CXX wrappers belong to Hyle; the original oneDNN SDK binary was reused.',
    GPU_runs=0)
(B/'actual-build-jobs.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k not in ['phases']},indent=2))
