"""Read-only current installed closure, relocation and native runtime readiness."""
from pathlib import Path
import hashlib
import json
import subprocess

R = Path('/mnt/c/public/project-hyle/hyle')
B = R / '.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-build-2026-10-21'
work = Path('/root/hyle-scratch/active-cpu-z')
build = work / 'build'
remote = work / 'delivery1-linux-current-build-2026-10-21'
relocation = json.loads((B / 'relocation.json').read_text())
prefix = Path(relocation['relocated_prefix'])
assert prefix.is_dir() and not Path(relocation['original_prefix']).exists()


def save(name, data):
    (B / name).write_text(json.dumps(data, indent=2) + '\n')


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4*1024*1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


headers, generated = [], []
for path in sorted((prefix / 'include/hyle').rglob('*')):
    if not path.is_file():
        continue
    original = R / path.relative_to(prefix)
    row = identity(path)
    if original.is_file():
        row['matches_current_source'] = row['sha256'] == identity(original)['sha256']
        assert row['matches_current_source'], str(path)
        headers.append(row)
    else:
        generated.append(row)
assert any(row['path'].endswith('/state_clone.h') for row in headers)
assert any(row['path'].endswith('/state_versions.h') for row in headers)
assert (prefix / 'lib/libhyle_compute_state.a').is_file()
exports = prefix / 'lib/cmake/Hyle'
must = ['HyleTargets-product_compute.cmake', 'HyleTargets-product_graph.cmake',
        'HyleTargets-product_graph_progress.cmake', 'HyleTargets-factor_compute_state.cmake']
export_rows = [identity(exports / name) for name in must]
samples = []
for sample, folder in [('cpp', 'consumer-cpp2'), ('cpu_cuda', 'consumer-cpu_cuda')]:
    directory = remote / folder
    exe = directory / ('hyle_package_graph_cpp' if sample == 'cpp' else 'hyle_cpu_cuda_sample')
    result = subprocess.run(['ldd', str(exe)], text=True, capture_output=True)
    assert result.returncode == 0 and 'not found' not in result.stdout + result.stderr
    (B / ('consumer-' + sample + '-ldd.stdout.log')).write_text(result.stdout)
    (B / ('consumer-' + sample + '-ldd.stderr.log')).write_text(result.stderr)
    commands = subprocess.run(['ninja', '-t', 'commands'], cwd=directory, text=True, capture_output=True, check=True).stdout
    assert str(prefix / 'include') in commands
    assert relocation['original_prefix'] not in commands
    assert str(work / 'source/include') not in commands
    assert str(build / 'bin') not in commands
    (B / ('consumer-' + sample + '-actual-commands.log')).write_text(commands)
    modules = [identity(path) for path in directory.glob('libhyle_ggml_cpu_avx2_*.so')]
    assert modules, 'Original CPU program must be staged by canonical hyle_stage_runtime'
    for row in modules:
        source_module = prefix / 'lib' / Path(row['path']).name
        assert identity(source_module)['sha256'] == row['sha256']
    samples.append(dict(sample=sample, image=identity(exe), ldd_exit=0, no_missing_libraries=True,
        original_prefix_references_in_commands=0, producer_include_or_bin_leaks=0,
        staged_original_CPU_modules=modules, executed_by_this_audit=False))
snapshot = remote / 'build-postinstall.snapshot.ninja'
assert not snapshot.exists(), 'Preserve prior audit'
snapshot.write_bytes((build / 'build.ninja').read_bytes())
dry = subprocess.run(['ninja', '-f', str(snapshot), '-n', 'all'], cwd=build, text=True, capture_output=True)
(B / 'post-build-dryrun.stdout.log').write_text(dry.stdout)
(B / 'post-build-dryrun.stderr.log').write_text(dry.stderr)
assert dry.returncode == 0 and 'no work to do' in dry.stdout
save('installed-readiness.json', dict(status='current_relocated_samples_configured_and_built_not_executed_by_agent',
    products='compute;graph;graph_progress', routes='cpu;cuda', prefix=str(prefix),
    original_prefix_exists=False, SDK_instances_created=1, SDK_copies=0,
    current_canonical_installed_headers=len(headers), generated_headers=generated,
    header_inventory=headers, public_exports=export_rows,
    StateCore_archive=identity(prefix / 'lib/libhyle_compute_state.a'), consumers=samples,
    post_build_dryrun=dict(command=['ninja','-f',str(snapshot),'-n','all'], exit=0,
        snapshot=identity(snapshot), payload_build_jobs=0),
    external_dependencies='Original pinned cached CPU/Torch-CUDA binary SDKs and installed native Linux CUDA 13.3 Toolkit; no new SDK download.',
    GPU_runs=0))
print('Current installed headers:', len(headers), '; ready original samples:', len(samples))
