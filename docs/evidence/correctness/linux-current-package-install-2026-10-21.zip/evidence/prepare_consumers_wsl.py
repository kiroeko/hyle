"""Prepare the two original installed-package consumers, without running them."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

R = Path('/mnt/c/public/project-hyle/hyle')
S = R / '.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-build-2026-10-21'
work = Path('/root/hyle-scratch/active-cpu-z')
source = work / 'source'
remote = work / 'delivery1-linux-current-build-2026-10-21'
installed = work / 'delivery1-linux-current-2026-10-21/static-sdk-installed'
relocated = remote / 'static-sdk-relocated'


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def run(tag, command):
    assert not (S / (tag + '.result.json')).exists(), 'Preserve first result'
    record = dict(command=command, cwd=str(remote), started=time.time(), GPU_runs=0)
    save(S / (tag + '.command.json'), record)
    remote.mkdir(parents=True, exist_ok=True)
    with (S / (tag + '.stdout.log')).open('w') as out, (S / (tag + '.stderr.log')).open('w') as err:
        child = subprocess.Popen(command, cwd=remote, stdout=out, stderr=err)
        record['pid'] = child.pid
        save(S / (tag + '.live.json'), record)
        code = child.wait()
    record.update(exit_code=code, seconds=time.time() - record['started'])
    save(S / (tag + '.result.json'), record)
    print(json.dumps(record, indent=2), flush=True)
    if code:
        raise SystemExit(code)


phase = sys.argv[1]
attempt_suffix = sys.argv[2] if len(sys.argv) > 2 else ''
if phase == 'source-audit':
    # Exact current sample sources, including every local header they can select
    # and their shared compute workload. No source or SDK overlay is needed here.
    files = [*sorted((R / 'samples/package/graph/cpp').glob('*')),
             *sorted((R / 'samples/package/graph/cpu_cuda').glob('*')),
             R / 'samples/package/compute/cpp/workload.h']
    rows = []
    for path in files:
        if not path.is_file():
            continue
        target = source / path.relative_to(R)
        original = identity(path)
        assert target.is_file() and identity(target)['sha256'] == original['sha256'], str(target)
        rows.append(dict(source=original, validation_copy=identity(target)))
    save(S / 'consumer-source-audit.json', dict(files=rows, count=len(rows), drift=0,
        product_source_writes=0, GPU_runs=0))
    print('Sample sources match:', len(rows), flush=True)
elif phase == 'relocate':
    assert json.loads((S / 'install.result.json').read_text())['exit_code'] == 0
    assert installed.is_dir() and not installed.is_symlink() and not relocated.exists()
    # A same-filesystem rename proves the original prefix is unavailable, while
    # retaining one SDK instance. Nothing is removed or duplicated.
    before = dict(device=installed.stat().st_dev, inode=installed.stat().st_ino)
    files = [dict(path=str(p.relative_to(installed)), bytes=p.stat().st_size)
             for p in installed.rglob('*') if p.is_file()]
    installed.rename(relocated)
    assert not installed.exists() and before == dict(device=relocated.stat().st_dev, inode=relocated.stat().st_ino)
    must = ['include/hyle/compute/state_clone.h', 'include/hyle/compute/state_versions.h',
            'lib/libhyle_compute_state.a', 'lib/cmake/Hyle/HyleConfig.cmake']
    checks = [identity(relocated / p) for p in must]
    for name in must[:2]:
        assert identity(relocated / name)['sha256'] == identity(R / name)['sha256']
    save(S / 'relocation.json', dict(original_prefix=str(installed), relocated_prefix=str(relocated),
        directory_identity=before, original_prefix_exists=False, file_count=len(files),
        files=files, required_current_compute_exports=checks, SDK_copies=0, GPU_runs=0))
    print('Relocated single SDK instance:', relocated, flush=True)
elif phase.startswith('configure-'):
    sample = phase.removeprefix('configure-')
    assert sample in ['cpp', 'cpu_cuda'] and relocated.is_dir() and not installed.exists()
    cache = (work / 'build/CMakeCache.txt').read_text()
    cxx = next(line.split('=', 1)[1] for line in cache.splitlines() if line.startswith('CMAKE_CXX_COMPILER:'))
    cuda_root = next(line.split('=', 1)[1] for line in cache.splitlines() if line.startswith('CUDAToolkit_ROOT:'))
    run('consumer-' + phase + attempt_suffix, ['cmake', '-S', str(source / 'samples/package/graph' / sample),
        '-B', str(remote / ('consumer-' + sample + attempt_suffix)), '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
        '-DCMAKE_CXX_COMPILER=' + cxx, '-DCMAKE_PREFIX_PATH=' + str(relocated),
        '-DCUDAToolkit_ROOT=' + cuda_root,
        '-DHyle_DIR=' + str(relocated / 'lib/cmake/Hyle')])
elif phase.startswith('build-'):
    sample = phase.removeprefix('build-')
    assert sample in ['cpp', 'cpu_cuda']
    run('consumer-' + phase + attempt_suffix, ['cmake', '--build', str(remote / ('consumer-' + sample + attempt_suffix)), '--parallel', '2'])
    exe = remote / ('consumer-' + sample + attempt_suffix) / ('hyle_package_graph_cpp' if sample == 'cpp' else 'hyle_cpu_cuda_sample')
    save(S / ('consumer-' + sample + attempt_suffix + '-image.json'), identity(exe))
else:
    raise SystemExit('Unknown phase')
