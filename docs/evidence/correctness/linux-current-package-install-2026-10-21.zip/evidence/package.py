"""Publish this current Linux build/install and two actual relocated consumers."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

B=Path(__file__).resolve().parent
A=B.parent
R=A.parents[1]
D=A/'delivery1-linux-current-2026-10-21'
PUBLIC=R/'docs/evidence/correctness'
NAME='linux-current-package-install-2026-10-21'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def data_json(value):
    return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode('utf-8')


def identity(path):
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish',action='store_true')
    args=parser.parse_args()
    for name in ['configure','build2','install','consumer-configure-cpp2','consumer-configure-cpu_cuda',
                 'consumer-build-cpp2','consumer-build-cpu_cuda','consumer-run-cpp','consumer-run-cpu_cuda']:
        assert read(B/(name+'.result.json'))['exit_code']==0,name
    assert read(B/'build.result.json')['exit_code']==1
    assert read(B/'consumer-configure-cpp.result.json')['exit_code']==1
    source_audit=read(B/'current-selected-source-audit.json')
    assert source_audit['drift']==[] and len(source_audit['out_of_route_changes'])==3
    ready=read(B/'installed-readiness.json')
    assert ready['current_canonical_installed_headers']==232
    assert ready['post_build_dryrun']['payload_build_jobs']==0
    jobs=read(B/'actual-build-jobs.json')
    assert jobs['unique_payload_jobs']==477 and jobs['payload_command_attempts']==478
    members={}

    def add(path,name=None):
        assert path.is_file(),path
        if name is None:name='evidence/'+path.relative_to(B).as_posix()
        assert name not in members
        assert path.suffix.lower() not in ['.a','.so','.o','.exe','.obj','.dll','.lib','.zip','.map']
        members[name]=path.read_bytes()

    # Keep one compact current-source inventory, not full dependency trees or
    # any archived SDK/source-copy payload. Before-overlay backups stay remote.
    for path in sorted(B.iterdir()):
        if path.is_file() and path.suffix in ['.json','.log','.py','.diff'] and path.name not in ['publication-plan.json','publication-verification.json']:
            if not path.name.endswith('.live.json'):
                add(path)
    for path in sorted((B/'installed-exports').iterdir()):
        add(path)
    for path in sorted((B/'revisions').rglob('*')):
        if path.is_file() and path.suffix in ['.py','.json','.cc']:
            add(path)
    current=['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
        'src/compute_state/CMakeLists.txt','src/compute_state/state_versions.cc','src/compute_state/state_internal.h',
        'include/hyle/compute/state_clone.h','include/hyle/compute/state_versions.h',
        'include/hyle/compute/detail/state_clone_access.h','cmake/HyleRuntimeStaging.cmake']
    for folder in ['samples/package/graph/cpp','samples/package/graph/cpu_cuda']:
        current.extend(p.relative_to(R).as_posix() for p in (R/folder).iterdir() if p.is_file())
    current.append('samples/package/compute/cpp/workload.h')
    sources=[]
    for name in current:
        add(R/name,'source/current/'+name)
        sources.append(dict(relative=name,**{k:v for k,v in identity(R/name).items() if k!='path'}))
    prep_path=PUBLIC/'linux-current-package-preparation-2026-10-21.json'
    prep_archive=PUBLIC/'linux-current-package-preparation-2026-10-21.zip'
    prep_ref=dict(report=identity(prep_path),archive=identity(prep_archive),
        scope='Historical configure/dryrun and current CMake/lock fixes; its 0-build/0-GPU statements remain historical facts.')
    # The complete prior manifest is referenced, not copied into every package.
    prior=['configure.command.json','native-source-cache-comparison.json','compute-state-followup-sync.json']
    for name in prior:
        add(D/name,'preparation-reference/'+name)
    results={name:read(B/('consumer-run-'+name+'.result.json')) for name in ['cpp','cpu_cuda']}
    assert all(not row['timeout'] for row in results.values())
    assert 'two real math slots' in (B/'consumer-run-cpu_cuda.stdout.log').read_text(encoding='utf-8')
    report=dict(schema='hyle.linux-current-package-install.v1',date='2026-10-21',
        scope='One current static Compute + Graph + GraphProgress installation for CPU/CUDA, using the original relocated package samples.',
        result='Current Linux installation column passed; this does not mark the overall delivery-1 cross-system scope complete.',
        public_configuration=dict(components=['compute','graph','graph_progress'],routes=['cpu','cuda'],
            HYLE_STATIC=True,HYLE_INSTALL=True,tests=False,build_parallel=2,
            compiler='GNU 14.2',CUDA_Toolkit='13.3.73',NVCC_host='GNU 13.3',CUDA_architecture='89-real'),
        actual_build=dict(unique_payload_jobs=477,payload_command_attempts=478,failed_initial_compile_commands=1,
            family_counts=jobs['counts'],count_note=jobs['scope_note'],
            source_caches_reused=True,binary_Torch_and_oneDNN_SDKs_reused=True,
            no_new_dependency_download=True,no_duplicate_SDK_tree=True,
            report='evidence/actual-build-jobs.json'),
        product_fix=dict(owner='src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
            change='Explicit empty initializers for the original constant-recipe input_bindings/workspace members.',
            mathematical_change=False,public_ABI_change=False,warnings_relaxed=False,
            before_sha256='4e228a12652452600efd406b8b6cca38fc2deb4863f55379ae852b4bc230bef3',
            after_sha256='c87325fc25cc21cf228f5518ed25c8d7dc29985fe7f5d24473880757ef96b484'),
        installation=dict(products=['compute','graph','graph_progress'],current_canonical_public_headers=232,
            StateCore='state_versions.cc was compiled; current StateWriter/Clone headers and compute_state archive/export are installed. These two graph samples are not StateClone runtime tests.',
            relocated_before_find_package=True,original_prefix_absent=True,SDK_instances=1,SDK_copies=0,
            prefix=ready['prefix'],external_dependencies=ready['external_dependencies'],
            Linux_runtime='Existing hyle_stage_runtime BUILD_RPATH uses the relocated lib and original pinned binary-SDK library directories. No per-application SDK copy.',
            source_scope='All current CPU/CUDA selected files match; three concurrent Apple-only updates are recorded out of route.',
            actual_dependency_check='Both sample ldd results have no missing libraries; compile/link commands have no original-prefix or producer include/bin leakage.'),
        actual_validation=dict(execution_owner='root',GPU_consumer_processes=2,exit_codes=[0,0],timeouts=0,
            samples=[dict(path='samples/package/graph/cpp',meaning='Independent CPU and pure CUDA graph checks selected by the exported route macros.',
                result='evidence/consumer-run-cpp.result.json',stdout='Empty stdout, exit 0; no invented printed PASS count.'),
                dict(path='samples/package/graph/cpu_cuda',meaning='Explicit CPU normalization/casts and CUDA FFN/FP16 fragments; two math slots, native DMA, lease and replay checks.',
                result='evidence/consumer-run-cpu_cuda.result.json',stdout='Two actual PASS lines.')],
            performance_claim=False),
        preserved_failures=[dict(path='evidence/build.stdout.log',classification='Product portability compile error: GCC missing-field-initializers; fixed without changing mathematics or layout.'),
            dict(path='evidence/consumer-configure-cpp.stderr.log',classification='External WSL Finder selected Windows nvcc.exe from PATH; a fresh small consumer configuration explicitly selected the already-installed Linux CUDAToolkit_ROOT. Original failed directory was retained.'),
            dict(path='evidence/consumer-preparation-first-error.json',classification='Harness cache type parsing assumption before CMake; corrected to accept the actual UNINITIALIZED compiler entry.'),
            dict(path='evidence/installed-audit-harness-correction.json',classification='Read-only audit initially assumed Windows-style DLL staging on Linux; corrected to the existing RPATH contract, without rebuilding or re-running consumers.')],
        remaining_scope=['Overall delivery-1 still waits for the separate current Mac installed-producer verification.',
            'This packet does not claim a full model, performance, every route/component combination or StateClone execution on Linux.',
            'Applications still own deployment of external SDK libraries; this proves Hyle SDK relocation before configuration, not a standalone copied executable.'],
        prior_preparation=prep_ref,source_count=len(sources),sources=sources,
        archive=NAME+'.zip',archived_binaries=False,cleanup_executed=False,
        retained_remote='Current producer build cache, relocated SDK, consumer objects/executables and validation results are retained for the next relevant checks.')
    members['report.json']=data_json(report)
    inventory=[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(members.items())]
    members['manifest.json']=data_json(dict(members=inventory,integrity='SHA-256 for every listed member; manifest excludes itself.'))
    (B/'publication-plan.json').write_bytes(data_json(dict(report=report,members=len(members),uncompressed_bytes=sum(map(len,members.values())))))
    if not args.publish:
        print(json.dumps(dict(members=len(members),source_count=len(sources),uncompressed_bytes=sum(map(len,members.values()))),indent=2))
        return
    out_json,out_zip=PUBLIC/(NAME+'.json'),PUBLIC/(NAME+'.zip')
    assert not out_json.exists() and not out_zip.exists(),'Preserve existing public evidence'
    out_json.write_bytes(members['report.json'])
    with zipfile.ZipFile(out_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(members.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            archive.writestr(info,data)
    with zipfile.ZipFile(out_zip) as archive:
        assert archive.testzip() is None and set(archive.namelist())==set(members)
        for name,data in members.items():assert archive.read(name)==data
        assert archive.read('report.json')==out_json.read_bytes()
    verification=dict(report=identity(out_json),archive=identity(out_zip),members=len(members),source_count=len(sources),
        CRC='all_members_pass',member_SHA256='all_match',packaging_builds=0,packaging_GPU_runs=0,deletes=0)
    (B/'publication-verification.json').write_bytes(data_json(verification))
    print(json.dumps(verification,indent=2))


if __name__=='__main__':main()
