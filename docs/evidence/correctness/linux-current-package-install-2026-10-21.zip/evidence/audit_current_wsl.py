from pathlib import Path
import hashlib
import json

R = Path('/mnt/c/public/project-hyle/hyle')
A = R / '.scratch/architecture-refactor-2026-10-18'
D = A / 'delivery1-linux-current-2026-10-21'
B = A / 'delivery1-linux-current-build-2026-10-21'
source = Path('/root/hyle-scratch/active-cpu-z/source')
plan = json.loads((D / 'sync-plan.json').read_text())
names = {row['relative'] for row in plan['files']}
names.update(row['path'] for row in json.loads((D / 'compute-state-followup-sync.json').read_text())['files'])
rows = []
for name in sorted(names):
    data = (R / name).read_bytes()
    target = source / name
    rows.append(dict(relative=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
        matches=target.is_file() and target.read_bytes() == data))
out_of_route_names = {'include/hyle/graph/apple.h', 'src/compute_route_apple/apple_tensor.h',
                      'src/graph_route_apple/apple_lowering_internal.h'}
out_of_route = [row for row in rows if not row['matches'] and row['relative'] in out_of_route_names]
drift = [row for row in rows if not row['matches'] and row['relative'] not in out_of_route_names]
extra = [str(p.relative_to(source)) for p in (source / 'include/hyle').rglob('*')
         if p.is_file() and not (R / p.relative_to(source)).is_file()]
record = dict(source_truth=str(R), destination=str(source), selected_files=len(rows),
    selected_bytes=sum(row['bytes'] for row in rows), drift=drift,
    out_of_route_changes=out_of_route, routes='cpu;cuda', products='compute;graph;graph_progress',
    boundary='Apple-only concurrent source updates are recorded, not synchronized or claimed current by this CPU/CUDA installation closure.',
    extra_validation_public_headers=extra, files=rows, reverse_sync=False)
(B / 'current-selected-source-audit.json').write_text(json.dumps(record, indent=2))
assert not drift and not extra
print('Current CPU/CUDA source differences:', len(drift), '; explicit Apple-only differences:', len(out_of_route))
