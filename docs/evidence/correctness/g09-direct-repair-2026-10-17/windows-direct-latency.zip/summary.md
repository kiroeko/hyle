# Windows direct G09 comparison

All four original numerical oracles passed in every clean child process. Values below are milliseconds; each triple shows process repetitions 0, 1, 2. No samples are dropped.

| Shape | Final-run baseline medians | Pre-monitor candidate medians | Final monitor candidate medians | Final/base pooled median |
|---|---|---|---|---|
| independent-cpu-first | 9.068 / 8.565 / 8.312 | 4.945 / 4.912 / 5.545 | 5.025 / 4.803 / 5.095 | 0.5836 (-41.64%) |
| independent-gpu-first | 8.621 / 8.470 / 8.499 | 4.802 / 4.853 / 5.750 | 5.001 / 4.931 / 5.054 | 0.5854 (-41.46%) |
| two-microbatches | 15.084 / 15.214 / 14.465 | 12.381 / 11.911 / 11.662 | 11.593 / 12.228 / 12.515 | 0.8145 (-18.55%) |
| serial-holdout | 11.385 / 11.561 / 11.586 | 8.295 / 8.152 / 8.382 | 8.579 / 8.453 / 8.382 | 0.7342 (-26.58%) |

Every per-process cold/create, first replay, full oracle, p90/p99, close/destruction and child lifetime is retained in summary.json and the original child JSON.

The windows-results directory is explicitly CONTAMINATED and is not used here. CV-monitor timing overlaps the pre-monitor distributions; no isolated additional median benefit is claimed.
