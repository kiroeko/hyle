"""Direct timings of the original G09 private facade; no qualification system."""
from pathlib import Path
import argparse
import ctypes as C
import hashlib
import json
import math
import os
import platform
import statistics
import subprocess
import sys
import time

SHAPES = ['independent-cpu-first', 'independent-gpu-first', 'two-microbatches', 'serial-holdout']
ERROR = C.POINTER(C.c_char)
CREATE = C.CFUNCTYPE(C.c_void_p, C.c_uint32, ERROR, C.c_size_t)
REPLAY = C.CFUNCTYPE(C.c_int, C.c_void_p, C.c_uint32, ERROR, C.c_size_t)
DESTROY = C.CFUNCTYPE(C.c_int, C.c_void_p, ERROR, C.c_size_t)

class Facts(C.Structure):
    _fields_ = [(name, C.c_uint64) for name in ['elements', 'slots', 'cold_fragments',
                'planned_copy_count', 'planned_copy_bytes', 'cpu_target', 'gpu_target']]

FACTS = C.CFUNCTYPE(C.c_int, C.c_void_p, C.POINTER(Facts), ERROR, C.c_size_t)

class Api(C.Structure):
    _fields_ = [('abi_version', C.c_uint64), ('struct_bytes', C.c_uint64),
                ('image_tag', C.c_char_p), ('create', CREATE), ('replay', REPLAY),
                ('facts', FACTS), ('destroy', DESTROY)]

def stats(values):
    ordered = sorted(values)
    return {'n': len(values), 'median_ns': statistics.median(values),
            'p90_ns': ordered[math.ceil(.90 * len(ordered)) - 1],
            'p99_ns': ordered[math.ceil(.99 * len(ordered)) - 1],
            'min_ns': ordered[0], 'max_ns': ordered[-1]}

def save(path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

def measure(args):
    image = args.image.resolve(strict=True)
    directories = []
    if os.name == 'nt':
        directories.append(os.add_dll_directory(str(image.parent)))
    report = {'mode': 'DIRECT_USER_JOURNEY_LATENCY', 'label': args.label,
              'image': str(image), 'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
              'host': platform.platform(), 'python': sys.version, 'shapes': [],
              'timing_boundary': 'Python ctypes call through original private C table; includes FFI overhead; native replay drains and releases every result before return',
              'warm_math': 'Original scalar check every slot; independent full 4M oracle before and after timed samples',
              'warmup_replays': args.warmup, 'iterations': args.iterations,
              'process_exit_vendor_cleanup': 'Included only in parent process_elapsed_ns, not warm samples'}
    begin = time.perf_counter_ns()
    library = C.CDLL(str(image))
    report['image_load_ns'] = time.perf_counter_ns() - begin
    getter = library.hyle_g09_facade_v1
    getter.restype = C.POINTER(Api)
    api = getter().contents
    if api.abi_version != 1 or api.struct_bytes != C.sizeof(Api):
        raise RuntimeError('Private facade ABI mismatch')
    report['image_tag'] = api.image_tag.decode()
    for shape, name in enumerate(SHAPES):
        error = C.create_string_buffer(2048)
        row = {'shape': shape, 'name': name, 'warm_ns': []}
        report['shapes'].append(row)
        state = None
        try:
            begin = time.perf_counter_ns()
            state = api.create(shape, error, len(error))
            row['cold_create_ns'] = time.perf_counter_ns() - begin
            if not state:
                raise RuntimeError(error.value.decode(errors='replace'))
            facts = Facts()
            if api.facts(state, C.byref(facts), error, len(error)):
                raise RuntimeError(error.value.decode(errors='replace'))
            row['facts'] = {field: getattr(facts, field) for field, _ in Facts._fields_}
            if facts.elements != 4194304 or facts.slots != (2 if shape == 2 else 1) or facts.cpu_target != 1 or facts.gpu_target != 0:
                raise RuntimeError('Original workload elements/slots/CPU+GPU targets changed')

            def replay(full=False):
                begin = time.perf_counter_ns()
                code = api.replay(state, int(full), error, len(error))
                elapsed = time.perf_counter_ns() - begin
                if code:
                    raise RuntimeError(error.value.decode(errors='replace'))
                return elapsed

            row['first_replay_ns'] = replay()
            row['full_oracle_before_ns'] = replay(True)
            for _ in range(args.warmup):
                replay()
            for _ in range(args.iterations):
                row['warm_ns'].append(replay())
            row['full_oracle_after_ns'] = replay(True)
            row['warm'] = stats(row['warm_ns'])
            row['oracle'] = 'PASS_ALL_ELEMENTS_ALL_SLOTS_BEFORE_AND_AFTER'
        except BaseException as failure:
            row['error'] = repr(failure)
            report['error'] = repr(failure)
            raise
        finally:
            if state:
                begin = time.perf_counter_ns()
                code = api.destroy(state, error, len(error))
                row['close_destroy_ns'] = time.perf_counter_ns() - begin
                if code:
                    row['destroy_error'] = error.value.decode(errors='replace')
                    report['error'] = row['destroy_error']
            save(args.output, report)
        if 'error' in report:
            raise RuntimeError(report['error'])
    report['result'] = 'COMPLETED_WITH_NUMERICAL_CHECKS'
    save(args.output, report)
    for row in report['shapes']:
        print(f"{args.label} {row['name']}: cold={row['cold_create_ns']/1e6:.3f} ms first={row['first_replay_ns']/1e6:.3f} ms warm median={row['warm']['median_ns']/1e6:.3f} p90={row['warm']['p90_ns']/1e6:.3f} p99={row['warm']['p99_ns']/1e6:.3f} ms oracle=PASS", flush=True)

def compare(args):
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    report = {'mode': 'ORDINARY_REPEATED_LATENCY_COMPARISON', 'runs': [],
              'baseline': str(args.baseline.resolve()), 'candidate': str(args.candidate.resolve()),
              'all_shapes_and_samples_retained': True, 'ratios': []}
    for repeat in range(args.repeats):
        for label in (['baseline', 'candidate'] if repeat % 2 == 0 else ['candidate', 'baseline']):
            image = getattr(args, label)
            result_path = out / f'{repeat}-{label}.json'
            command = [sys.executable, str(Path(__file__).resolve()), 'measure', '--image', str(image.resolve()),
                       '--label', label, '--warmup', str(args.warmup), '--iterations', str(args.iterations), '--output', str(result_path)]
            begin = time.perf_counter_ns()
            run = subprocess.run(command, capture_output=True)
            elapsed = time.perf_counter_ns() - begin
            (out / f'{repeat}-{label}.log').write_bytes(run.stdout + run.stderr)
            report['runs'].append({'repeat': repeat, 'label': label, 'argv': command,
                                   'exit_code': run.returncode, 'process_elapsed_ns': elapsed,
                                   'result': str(result_path)})
            save(out / 'comparison.json', report)
            print(run.stdout.decode(errors='replace'), end='', flush=True)
            if run.returncode:
                raise RuntimeError(f'{label} failed; see {out / f"{repeat}-{label}.log"}')
    for shape, name in enumerate(SHAPES):
        samples = {}
        for label in ['baseline', 'candidate']:
            rows = [json.loads(Path(run['result']).read_text())['shapes'][shape]
                    for run in report['runs'] if run['label'] == label]
            samples[label] = stats([value for row in rows for value in row['warm_ns']])
        ratio = samples['candidate']['median_ns'] / samples['baseline']['median_ns']
        report['ratios'].append({'shape': name, **samples, 'candidate_over_baseline': ratio})
        print(f'{name}: candidate/base warm median={ratio:.4f} ({(ratio-1)*100:+.2f}%)', flush=True)
    report['result'] = 'COMPLETED_WITH_NUMERICAL_CHECKS_NO_QUALIFICATION_CLAIM'
    save(out / 'comparison.json', report)

parser = argparse.ArgumentParser(description=__doc__)
commands = parser.add_subparsers(dest='mode', required=True)
for mode in ['measure', 'compare']:
    p = commands.add_parser(mode)
    p.add_argument('--warmup', type=int, default=8)
    p.add_argument('--iterations', type=int, default=31)
    p.add_argument('--output', type=Path, required=True)
    if mode == 'measure':
        p.add_argument('--image', type=Path, required=True)
        p.add_argument('--label', required=True)
    else:
        p.add_argument('--baseline', type=Path, required=True)
        p.add_argument('--candidate', type=Path, required=True)
        p.add_argument('--repeats', type=int, default=3)
args = parser.parse_args()
if args.iterations < 1 or args.warmup < 0 or (args.mode == 'compare' and args.repeats < 1):
    parser.error('iterations/repeats must be positive and warmup nonnegative')
(measure if args.mode == 'measure' else compare)(args)
