# Direct G09 user-journey latency

This consumer reuses the original private facade and all four original shapes:
4,194,304 F32 values, CPU Abs, GPU Neg and CPU Add, including both graph insertion
orders, the two-slot submit-both-before-wait journey, and the serial holdout.
Every replay retains the original prepare/bind, native completion, owning result,
checked scalar observation, lease destruction and Scheduler drain. Full independent
oracles read every element of every slot before and after the warm samples.

There is no qualification/selector/closure dependency. Samples are ordinary wall
times, with Python ctypes overhead included. No sample or shape is discarded.
Each SDK runs in its own child process, avoiding cross-SDK loader/global-runtime
mixing. Three child-process repetitions alternate baseline/candidate order.

Separate reported costs are image load, cold State creation, first native replay,
eight warmups, 31 warm calls, full numerical checks and close/destruction. The
parent also records full child lifetime including interpreter startup and final
process cleanup. Private runtime caches are not claimed reclaimed by State close.

## Windows

The retained natural baseline is 9e2f25c469634a6f723e76eaf1aa2db5973bca9a:

- Static SDK: `C:/h7/g08-sdk/vulkan-static-1/relocated`
- Existing facade: `C:/h7/g09-p1/vulkan-baseline/bin/g09_vulkan_baseline_1.dll`

`build_windows.py` imports the existing MSVC environment, incrementally builds
`C:/h7/w-vulkan/selected-graph/static-sdk-build` with `--parallel 2`, installs the
current SDK into `C:/h7/g09-direct-sdk/current`, verifies its three-argument
BlockingPool API in both header and archive symbols, then builds one facade TU
plus the tiny runtime-staging executable in `C:/h7/g09-direct-facade/current`.
The candidate is explicitly compiled with `G09_VULKAN_POOL_API=1`; the old
352441 candidate facade is never used as the new candidate.

```powershell
python .scratch/g09-direct-latency/build_windows.py
```

After those artifacts exist, repeat only the direct comparison with a fresh
output directory:

```powershell
python .scratch/g09-direct-latency/latency.py compare --baseline C:/h7/g09-p1/vulkan-baseline/bin/g09_vulkan_baseline_1.dll --candidate C:/h7/g09-direct-facade/current/bin/g09_native_trial.dll --output .scratch/g09-direct-latency/windows-repeat
```

## Air, after the current Metal work is finished

The retained baseline facade is
`/Users/kiro/hyle-scratch/compute-unified/g09-p1/apple-baseline/bin/libg09_apple_baseline_1.dylib`.
The old static SDK is under
`/Users/kiro/hyle-scratch/compute-unified/g08-sdk/apple-static-1/relocated`.
These are retained historical metadata paths; this preparation did not execute
or rebuild anything on Air.

Copy this directory to Air, then bind an actually updated static SDK explicitly:

```sh
cmake -S g09-direct-latency -B g09-direct-apple -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH=/actual/new/static/sdk -DG09_ROUTE=apple -DG09_IMAGE_TAG=current-wake-fix
cmake --build g09-direct-apple --target g09_native_trial --parallel 2
python3 g09-direct-latency/latency.py compare --baseline /Users/kiro/hyle-scratch/compute-unified/g09-p1/apple-baseline/bin/libg09_apple_baseline_1.dylib --candidate g09-direct-apple/bin/libg09_native_trial.dylib --output apple-direct-results
```

The output contains every raw latency, cold/first-use/teardown costs, native shape
facts, numerical verdict, actual image path/SHA and child exit status. Reported
candidate/base ratios describe these repetitions; they do not imply statistical
qualification or generalize beyond the four stated user journeys.
