from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
env = {key.upper(): value for key, value in os.environ.items()}
raw = subprocess.check_output(['cmd', '/d', '/c', str(root / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], text=True)
env.update((key.upper(), value) for key, value in
           (line.split('=', 1) for line in raw.splitlines() if '=' in line and not line.startswith('=')))
env['VSLANG'] = '1033'
sdk_build = Path('C:/h7/w-vulkan/selected-graph/static-sdk-build')
sdk = Path('C:/h7/g09-direct-sdk/current')
facade_build = Path('C:/h7/g09-direct-facade/current')
report = {'source': str(root), 'sdk_build': str(sdk_build), 'installed_sdk': str(sdk),
          'facade_build': str(facade_build), 'stages': [], 'source_hashes': {},
          'baseline_untouched': 'C:/h7/g08-sdk/vulkan-static-1/relocated', 'parallel': 2}
if '--resume-facade' in sys.argv:
    report = json.loads((out / 'windows-build.json').read_text())
for name in ([] if '--resume-facade' in sys.argv else ['include/hyle/graph/cpu_vulkan.h', 'src/graph_route_cpu_vulkan/invocation.cc',
             'src/compute_route_vulkan/context.cc', 'src/graph_route_cpu_apple/invocation.cc']):
    path = root / name
    if path.exists():
        report['source_hashes'][name] = hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (out / 'windows-build.json').write_text(json.dumps(report, indent=2) + '\n')

def run(stage, argv):
    report['active_stage'] = stage
    save()
    print(stage, ' '.join(map(str, argv)), flush=True)
    begin = time.perf_counter()
    with (out / (stage + '.log')).open('wb') as log:
        process = subprocess.Popen([str(value) for value in argv], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['active_pid'] = process.pid
        save()
        code = process.wait()
    report.pop('active_pid', None)
    report['stages'].append({'name': stage, 'argv': list(map(str, argv)), 'exit_code': code, 'seconds': time.perf_counter() - begin})
    save()
    if code:
        print((out / (stage + '.log')).read_text(errors='replace')[-12000:], flush=True)
        raise RuntimeError(stage + ' failed')
    print(stage, 'completed', report['stages'][-1]['seconds'], flush=True)

if '--resume-facade' not in sys.argv:
    run('configure-sdk', ['cmake', '-S', root, '-B', sdk_build,
        '-DHYLE_COMPONENTS=compute;graph', '-DHYLE_COMPUTE_ROUTES=cpu;vulkan',
        '-DHYLE_STATIC=ON', '-DHYLE_INSTALL=ON', '-DHYLE_BUILD_TESTS=OFF',
        '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_TEST_INSTRUMENTATION=OFF', '-DHYLE_SANITIZER=off', '-UCMAKE_PROJECT_INCLUDE'])
    run('build-sdk', ['cmake', '--build', sdk_build, '--parallel', '2'])
    run('install-sdk', ['cmake', '--install', sdk_build, '--prefix', sdk])
header = (sdk / 'include/hyle/graph/cpu_vulkan.h').read_text()
assert 'sched::BlockingPool' in header
owner_lib = sdk / 'lib/hyle_graph_route_cpu_vulkan.lib'
dumpbin = Path(env['VCTOOLSINSTALLDIR']) / 'bin/Hostx64/x64/dumpbin.exe'
symbols = subprocess.check_output([str(dumpbin), '/nologo', '/symbols', str(owner_lib)], env=env, text=True, errors='replace')
matches = [line for line in symbols.splitlines() if 'create_invocation@Executable' in line and 'BlockingPool' in line]
assert matches, 'Installed owner archive lacks new three-argument BlockingPool API'
report['installed_pool_api_symbols'] = matches
report['installed_owner_lib_sha256'] = hashlib.sha256(owner_lib.read_bytes()).hexdigest()
save()
run('configure-facade', ['cmake', '-S', out, '-B', facade_build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
    '-DCMAKE_PREFIX_PATH=' + str(sdk), '-DG09_ROUTE=vulkan', '-DG09_IMAGE_TAG=current-wake-fix-pool-api',
    '-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1',
    '-DHYLE_COMPUTE_TORCH_CPU_ROOT=C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch'])
run('build-facade', ['cmake', '--build', facade_build, '--target', 'g09_native_trial', '--parallel', '2'])
image = facade_build / 'bin/g09_native_trial.dll'
report['candidate_image'] = {'path': str(image), 'sha256': hashlib.sha256(image.read_bytes()).hexdigest()}
save()
run('latency', [sys.executable, out / 'latency.py', 'compare',
    '--baseline', 'C:/h7/g09-p1/vulkan-baseline/bin/g09_vulkan_baseline_1.dll',
    '--candidate', image, '--repeats', '3', '--warmup', '8', '--iterations', '31',
    '--output', out / 'windows-results'])
report.pop('active_stage', None)
report['result'] = 'BUILT_CURRENT_POOL_API_AND_MEASURED_BOTH_SDKS'
save()
