from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
env = {key.upper(): value for key, value in os.environ.items()}
raw = subprocess.check_output(['cmd', '/d', '/c', str(root / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], text=True)
env.update((key.upper(), value) for key, value in (line.split('=', 1) for line in raw.splitlines() if '=' in line and not line.startswith('=')))
sdk_build = Path('C:/h7/w-vulkan/selected-graph/static-sdk-build')
sdk = Path('C:/h7/g09-direct-sdk/current')
facade = Path('C:/h7/g09-direct-facade/current')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
source = root / 'src/graph_route_cpu_vulkan/invocation.cc'
assert sha(source) == 'd074251950760ac16607e5c675fb0f5b6d6196855a00e8e7b332db7c1319f110'
backup = Path('C:/h7/g09-direct-facade/pre-monitor/bin')
assert not backup.exists()
shutil.copytree(facade / 'bin', backup)
report = {'phase': 'FINAL_CV_MONITOR', 'product_commit': '1dbfce9a0',
          'owner_source_sha256': sha(source), 'installed_sdk': str(sdk), 'stages': [],
          'pre_monitor': {'source_sha256': 'f848db8f9a45c9f2f450c000c573ed9b25241924f81268a8cb66dd9f52979d07',
                          'image': str(backup / 'g09_native_trial.dll'), 'image_sha256': sha(backup / 'g09_native_trial.dll'),
                          'comparison': str(out / 'windows-pre-monitor-clean/comparison.json')}}

def save():
    (out / 'windows-final-build.json').write_text(json.dumps(report, indent=2) + '\n')

def run(stage, command):
    print(stage, flush=True)
    begin = time.perf_counter()
    with (out / (stage + '.log')).open('wb') as log:
        process = subprocess.Popen(list(map(str, command)), cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        report.update(active_stage=stage, active_pid=process.pid)
        save()
        code = process.wait()
    report.pop('active_pid', None)
    report['stages'].append({'name': stage, 'argv': list(map(str, command)), 'exit_code': code, 'seconds': time.perf_counter() - begin})
    save()
    if code:
        print((out / (stage + '.log')).read_text(errors='replace')[-10000:], flush=True)
        raise RuntimeError(stage + ' failed')
    print(stage, 'completed', report['stages'][-1]['seconds'], flush=True)

run('final-route-build', ['cmake', '--build', sdk_build, '--target', 'hyle_graph_route_cpu_vulkan', '--parallel', '2'])
run('final-install', ['cmake', '--install', sdk_build, '--prefix', sdk])
report['owner_archive_sha256'] = sha(sdk / 'lib/hyle_graph_route_cpu_vulkan.lib')
obj = sdk_build / 'src/graph_route_cpu_vulkan/CMakeFiles/hyle_graph_route_cpu_vulkan.dir/invocation.cc.obj'
report['owner_object'] = {'sha256': sha(obj), 'mtime_ns': obj.stat().st_mtime_ns}
assert sha(source) == report['owner_source_sha256']
run('final-facade-link', ['cmake', '--build', facade, '--target', 'g09_native_trial', '--parallel', '2'])
report['candidate_image'] = {'path': str(facade / 'bin/g09_native_trial.dll'), 'sha256': sha(facade / 'bin/g09_native_trial.dll')}
assert report['candidate_image']['sha256'] != report['pre_monitor']['image_sha256']
save()
run('final-latency', [sys.executable, out / 'latency.py', 'compare',
    '--baseline', 'C:/h7/g09-p1/vulkan-baseline/bin/g09_vulkan_baseline_1.dll',
    '--candidate', facade / 'bin/g09_native_trial.dll', '--output', out / 'windows-monitor-final'])
report.pop('active_stage', None)
report['result'] = 'FINAL_MONITOR_BUILT_AND_MEASURED_WITH_FULL_NUMERICAL_CHECKS'
save()
