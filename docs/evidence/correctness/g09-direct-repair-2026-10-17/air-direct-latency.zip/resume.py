from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time,zipfile
D=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0')
S=Path('/Users/kiro/hyle-scratch/compute-unified/source-c8874688')
BASE=Path('/Users/kiro/hyle-scratch/compute-unified')
SOURCE=BASE/'a-cpu-apple/selected-graph/source-build'
P=SOURCE.parent/'source-parent'
TOOLS=D/'latency'
D.mkdir(parents=True,exist_ok=True)
os.nice(10)
E=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
E['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+E.get('PATH','')
for key in list(E):
    if key.startswith(('MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION','DYLD_PRINT_LIBRARIES')):E.pop(key)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
R={'candidate':'1dbfce9a025b9ba10e357d33863d0c646baf16bb','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():(D/'result.json').write_text(json.dumps(R,indent=2)+'\n')
def run(label,args,layers=False,timeout=1800):
    log=D/(label+'.log');start=time.monotonic();extra={'MTL_DEBUG_LAYER':'1','MTL_SHADER_VALIDATION':'1','DYLD_PRINT_LIBRARIES':'1'} if layers else {}
    print('START '+label,flush=True)
    with log.open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=S,env=dict(E,**extra),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    text=log.read_text(errors='replace');loaded=re.findall(r'^dyld\[[^]]+\]:[^\n]* (/[^\n]+)',text,re.M)
    item={'label':label,'command':list(map(str,args)),'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':H(log),'actual_api_validation':'Metal API Validation Enabled' in text,'actual_gpu_validation':'Metal GPU Validation Enabled' in text,'loaded_mlx':[{'path':n,'sha256':H(n)} for n in sorted(set(loaded)) if Path(n).name=='libmlx.dylib'],'error_markers':[x for x in ['Shader Validation Error','failed assertion','Validation Error'] if x in text]}
    R['commands'].append(item);save();print('DONE '+label+' exit='+str(p.returncode)+' seconds='+str(round(item['seconds'],3)),flush=True);print('\n'.join(text.splitlines()[-7:]),flush=True)
    if p.returncode:raise RuntimeError(label+' failed; see '+str(log))

archive=D/'source.zip';R['source_archive_sha256']=H(archive)
with zipfile.ZipFile(archive) as z:
    updated=[]
    for name in z.namelist():
        if name.endswith('/'):continue
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:raise ValueError(name)
        p=S/rel;data=z.read(name)
        if not p.is_file() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);updated.append(name)
R['updated_source_files']=updated;save()
names=['contracts','pipeline','encoded','native_unit'];parent=P/'CMakeLists.txt';text=parent.read_text();marker='# BEGIN G09_AIR_FINAL_1DB_MONITOR'
if marker not in text:
    text+='\n'+marker+'\n'
    for name in names:text+='set_target_properties(g09_wake_v4_'+name+' PROPERTIES RUNTIME_OUTPUT_DIRECTORY "'+str(D/'bin')+'")\n'
    text+='# END G09_AIR_FINAL_1DB_MONITOR\n';parent.write_text(text)
run('monitor-configure',['/opt/homebrew/bin/cmake','-S',P,'-B',SOURCE,'-DHYLE_COMPUTE_ROUTES=cpu;apple','-UCMAKE_PROJECT_INCLUDE'])
run('monitor-build',['/opt/homebrew/bin/cmake','--build',SOURCE,'--parallel','2','--target',*['g09_wake_v4_'+n for n in names]])
for name in names:
    args=[D/'bin'/('g09_wake_v4_'+name)]
    if name=='encoded':args+=['--gtest_filter=EncodedNativePages.*','--gtest_output=json:'+str(D/'encoded4.json')]
    if name=='native_unit':args+=['--gtest_filter=AppleCompletionNotification.*','--gtest_output=json:'+str(D/'completion4.json')]
    run('monitor-'+name+'-api-gpu',args,True,300)

for route in ['apple','vulkan']:
    b=BASE/('a-cpu-'+route)/'selected-graph/static-sdk-build';sdk=D/(route+'-sdk');facade=D/(route+'-facade')
    run(route+'-configure-sdk',['/opt/homebrew/bin/cmake','-S',S,'-B',b,'-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu;'+route,'-DHYLE_STATIC=ON','-DHYLE_INSTALL=ON','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_SANITIZER=off','-UCMAKE_PROJECT_INCLUDE'])
    run(route+'-build-sdk',['/opt/homebrew/bin/cmake','--build',b,'--parallel','2'])
    run(route+'-install-sdk',['/opt/homebrew/bin/cmake','--install',b,'--prefix',sdk])
    run(route+'-configure-facade',['/opt/homebrew/bin/cmake','-S',TOOLS,'-B',facade,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk),'-DG09_ROUTE='+route,'-DG09_IMAGE_TAG=current-monitor-1dbfce9a0'])
    run(route+'-build-facade',['/opt/homebrew/bin/cmake','--build',facade,'--target','g09_native_trial','--parallel','2'])
    image=facade/'bin/libg09_native_trial.dylib';baseline=BASE/('g09-p1/'+route+'-baseline/bin/libg09_'+route+'_baseline_1.dylib')
    R.setdefault('images',{})[route]={'candidate':{'path':str(image),'sha256':H(image)},'baseline':{'path':str(baseline),'sha256':H(baseline)}};save()
    run(route+'-latency',['/usr/bin/python3',TOOLS/'latency.py','compare','--baseline',baseline,'--candidate',image,'--repeats','3','--warmup','8','--iterations','31','--output',D/(route+'-results')])
R['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('FINAL_MONITOR_AND_BOTH_ROUTE_LATENCY_FINISHED',flush=True)
