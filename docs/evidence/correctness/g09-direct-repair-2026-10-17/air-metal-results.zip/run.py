from pathlib import Path
import datetime, hashlib, json, os, platform, re, subprocess, sys, time, zipfile

D=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017')
S=Path('/Users/kiro/hyle-scratch/compute-unified/source-c8874688')
B=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
P=B.parent/'source-parent'
D.mkdir(parents=True,exist_ok=True)
os.nice(10)
E=dict(os.environ)
E['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+E.get('PATH','')
E.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
for key in list(E):
    if key=='MTL_DEBUG_LAYER' or key.startswith('MTL_SHADER_VALIDATION') or key=='DYLD_PRINT_LIBRARIES':E.pop(key)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
R={'candidate':'08e02b27c742d3c024673143c9bae85e2006b003','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save(): (D/'result.json').write_text(json.dumps(R,indent=2)+'\n')
def run(label,args,extra=None,timeout=1200):
    log=D/(label+'.log');started=time.monotonic()
    print('START '+label,flush=True)
    with log.open('wb') as f:
        p=subprocess.run(list(map(str,args)),env=dict(E,**(extra or {})),cwd=S,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    text=log.read_text(errors='replace')
    item={'label':label,'command':list(map(str,args)),'exit_code':p.returncode,'seconds':time.monotonic()-started,'log':str(log),'log_sha256':H(log)}
    loaded=re.findall(r'^dyld\[[^]]+\]:[^\n]* (/[^\n]+)',text,re.M)
    item['loaded_mlx']=[{'path':name,'sha256':H(name)} for name in sorted(set(loaded)) if Path(name).name=='libmlx.dylib']
    item['actual_api_validation']='Metal API Validation Enabled' in text
    item['actual_gpu_validation']='Metal GPU Validation Enabled' in text
    R['commands'].append(item);save()
    print('DONE '+label+' exit='+str(p.returncode)+' seconds='+str(round(item['seconds'],3)),flush=True)
    print('\n'.join(text.splitlines()[-8:]),flush=True)
    return p.returncode,text

R['machine']={'model':subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),'os':subprocess.check_output(['sw_vers'],text=True),'clang':subprocess.check_output(['xcrun','clang++','--version'],text=True),'platform':platform.platform()}
save();print(json.dumps(R['machine']),flush=True)
updated=[]
with zipfile.ZipFile(D/'source.zip') as z:
    R['archive_sha256']=H(D/'source.zip')
    for name in z.namelist():
        if name.endswith('/'):continue
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:raise ValueError(name)
        p=S/rel;data=z.read(name)
        if not p.is_file() or p.read_bytes()!=data:
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);updated.append(name)
R['updated_source_files']=updated;save()
parent=P/'CMakeLists.txt';text=parent.read_text()
marker='# BEGIN G09_AIR_DIRECT_20261017'
if marker not in text:
    (D/'parent-before.cmake').write_text(text)
    addition='\n'+marker+'\n'
    addition+='set_target_properties(g09_wake_v4_pending PROPERTIES RUNTIME_OUTPUT_DIRECTORY "'+str(D/'bin')+'")\n'
    addition+='add_executable(g09_air_cache_direct "'+str(S/'tests/compute_route_apple/native_cache_test.cc')+'")\n'
    addition+='target_compile_features(g09_air_cache_direct PRIVATE cxx_std_23)\n'
    addition+='target_link_libraries(g09_air_cache_direct PRIVATE hyle::compute GTest::gtest_main)\n'
    addition+='set_target_properties(g09_air_cache_direct PROPERTIES RUNTIME_OUTPUT_DIRECTORY "'+str(D/'bin')+'")\n'
    addition+='hyle_stage_runtime(g09_air_cache_direct)\n# END G09_AIR_DIRECT_20261017\n'
    parent.write_text(text+addition)
code,_=run('configure',['/opt/homebrew/bin/cmake','-S',P,'-B',B,'-DHYLE_COMPUTE_ROUTES=cpu;apple','-UCMAKE_PROJECT_INCLUDE','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
if code:sys.exit(code)
code,_=run('build',['/opt/homebrew/bin/cmake','--build',B,'--parallel','2','--target','g09_wake_v4_pending','g09_air_cache_direct'],timeout=1800)
if code:sys.exit(code)
layers={'MTL_DEBUG_LAYER':'1','MTL_SHADER_VALIDATION':'1','DYLD_PRINT_LIBRARIES':'1'}
run('pending-api-gpu',[D/'bin/g09_wake_v4_pending'],layers,timeout=300)
names=['Q8PagedRaggedWindowsAndIndependentValueDepth','FullNoncausalAllowsMoreQueriesThanKeys','PlainWindowAndIndependentValueDepth','OriginalPlainCoupledUnboundedPaths','MainDepthsAndLongPrefill','SmallSoftmaxWeightsKeepLargeValueContributions','SubnormalQueryKeepsLargeKeyScores']
selection=':'.join('AppleCache.'+name for name in names)
code,_=run('cache7-api-gpu',[D/'bin/g09_air_cache_direct','--gtest_filter='+selection,'--gtest_output=json:'+str(D/'cache7.json')],layers,timeout=300)
if (D/'cache7.json').is_file():R['cache7_report']=json.loads((D/'cache7.json').read_text())
R['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'finished':True,'commands':R['commands'],'cache7_report':R.get('cache7_report')}),flush=True)
