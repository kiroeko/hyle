from pathlib import Path
import hashlib,json,os,re,subprocess,time
D=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017')
S=Path('/Users/kiro/hyle-scratch/compute-unified/source-c8874688')
B=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
P=B.parent/'source-parent'
os.nice(10)
E=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
E['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+E.get('PATH','')
for key in list(E):
    if key=='MTL_DEBUG_LAYER' or key.startswith('MTL_SHADER_VALIDATION') or key=='DYLD_PRINT_LIBRARIES':E.pop(key)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
R={'candidate':'08e02b27c742d3c024673143c9bae85e2006b003','commands':[]}
def run(label,args,layers=False):
    log=D/(label+'.log');start=time.monotonic();extra={'MTL_DEBUG_LAYER':'1','MTL_SHADER_VALIDATION':'1','DYLD_PRINT_LIBRARIES':'1'} if layers else {}
    print('START '+label,flush=True)
    with log.open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=S,env=dict(E,**extra),stdout=f,stderr=subprocess.STDOUT,timeout=300)
    text=log.read_text(errors='replace');loaded=re.findall(r'^dyld\[[^]]+\]:[^\n]* (/[^\n]+)',text,re.M)
    item={'label':label,'command':list(map(str,args)),'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':H(log),'actual_api_validation':'Metal API Validation Enabled' in text,'actual_gpu_validation':'Metal GPU Validation Enabled' in text,'loaded_mlx':[{'path':name,'sha256':H(name)} for name in sorted(set(loaded)) if Path(name).name=='libmlx.dylib'],'error_markers':[x for x in ['Shader Validation Error','failed assertion','Validation Error'] if x in text]}
    R['commands'].append(item);(D/'consumers-result.json').write_text(json.dumps(R,indent=2)+'\n')
    print('DONE '+label+' exit='+str(p.returncode)+' seconds='+str(round(item['seconds'],3)),flush=True);print('\n'.join(text.splitlines()[-6:]),flush=True)
    return p.returncode
names=['contracts','pipeline','encoded','paged_joint','sampling','public_effect','symmetry','native_unit']
parent=P/'CMakeLists.txt';text=parent.read_text();marker='# BEGIN G09_AIR_DIRECT_REMAINING_CONSUMERS'
if marker not in text:
    text+='\n'+marker+'\n'
    for name in names:text+='set_target_properties(g09_wake_v4_'+name+' PROPERTIES RUNTIME_OUTPUT_DIRECTORY "'+str(D/'bin')+'")\n'
    text+='# END G09_AIR_DIRECT_REMAINING_CONSUMERS\n';parent.write_text(text)
if run('consumers-configure',['/opt/homebrew/bin/cmake','-S',P,'-B',B,'-DHYLE_COMPUTE_ROUTES=cpu;apple','-UCMAKE_PROJECT_INCLUDE']):raise SystemExit(1)
if run('consumers-build',['/opt/homebrew/bin/cmake','--build',B,'--parallel','2','--target',*['g09_wake_v4_'+name for name in names]]):raise SystemExit(1)
for name in names:
    args=[D/'bin'/('g09_wake_v4_'+name)]
    if name=='encoded':args+=['--gtest_filter=EncodedNativePages.*','--gtest_output=json:'+str(D/'encoded4.json')]
    if name=='native_unit':args+=['--gtest_filter=AppleCompletionNotification.*','--gtest_output=json:'+str(D/'completion4.json')]
    run('consumer-'+name+'-api-gpu',args,True)
for name in ['encoded4','completion4']:
    p=D/(name+'.json')
    if p.is_file():R[name]=json.loads(p.read_text())
(D/'consumers-result.json').write_text(json.dumps(R,indent=2)+'\n')
print('ALL_REMAINING_CONSUMERS_FINISHED',flush=True)
