#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/providers/native.h"
#include "hyle/mem/buffer.h"
#include "hyle/simd/dtype.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <limits>
#include <thread>
#include "hyle/platform/cpu.h"
#include "hyle/graph/cpu.h"
#include "hyle/compute/providers/onednn.h"
#include <span>
#include <string>
#include <vector>

namespace {
namespace c = hyle::compute;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> r) {
  if (!r) {
    std::fprintf(stderr, "ERROR %.*s\n", int(r.error().message().size()),
                 r.error().message().data());
    std::exit(2);
  }
  return std::move(*r);
}
void require(hyle::Status s) {
  if (!s.ok()) {
    std::fprintf(stderr, "ERROR %.*s\n", int(s.message().size()),
                 s.message().data());
    std::exit(2);
  }
}
c::TensorDesc dense(c::DataType t, std::initializer_list<std::int64_t> dims) {
  return take(c::TensorDesc::dense(t, {dims.begin(), dims.size()}));
}
enum class Kind {
  Unary,
  Binary,
  Reduce,
  Norm,
  Gate,
  MatMul,
  Rope,
  Softmax,
  Attention,
  Gather,
  Scatter,
  Concat,
  Cast,
  Copy,
  Fill,
  Select
};
struct Case {
  std::string id;
  Kind kind;
  c::DataType type;
  int variant = 0;
  int rows = 1;
  c::DataType other = c::DataType::kFloat32;
};
const std::array floats{c::DataType::kFloat32, c::DataType::kFloat16,
                        c::DataType::kBFloat16};
const std::array storage{c::DataType::kFloat32, c::DataType::kFloat16,
                         c::DataType::kBFloat16, c::DataType::kFloat8E4M3FN,
                         c::DataType::kFloat8E5M2};
std::vector<Case> catalog() {
  std::vector<Case> result;
  const auto add = [&](Kind kind, c::DataType type, int variant,
                       const std::string &name) {
    for (int rows : {1, 32})
      result.push_back({name + "-t" + std::to_string(int(type)) + "-r" +
                         std::to_string(rows) + "-o6", kind, type, variant, rows});
  };
  for (auto type : storage) add(Kind::Copy, type, 0, "copy");
  for (auto type : floats) add(Kind::Norm, type, 0, "norm-0");
  add(Kind::Attention, c::DataType::kFloat32, 0, "equal-head-sdpa");
  add(Kind::Copy, c::DataType::kFloat32, 1, "copy-strided");
  add(Kind::Norm, c::DataType::kBFloat16, 2, "rms-model-eps6");
  add(Kind::Attention, c::DataType::kFloat32, 1, "causal-sdpa-d256");
  return result;
}
template <class T> void store(std::byte *p, T v) {
  std::memcpy(p, &v, sizeof(v));
}
template <class T> T load(const std::byte *p) {
  T v;
  std::memcpy(&v, p, sizeof(v));
  return v;
}
void encode(std::byte *p, c::DataType type, float x) {
  switch (type) {
  case c::DataType::kFloat32:
    store(p, x);
    break;
  case c::DataType::kFloat16:
    store(p, hyle::simd::f32_to_f16(x));
    break;
  case c::DataType::kBFloat16:
    store(p, hyle::simd::f32_to_bf16(x));
    break;
  case c::DataType::kFloat8E4M3FN:
    store(p, hyle::simd::f32_to_f8e4m3(x));
    break;
  case c::DataType::kFloat8E5M2:
    store(p, hyle::simd::f32_to_f8e5m2(x));
    break;
  default:
    std::abort();
  }
}
double decode(const std::byte *p, c::DataType type) {
  switch (type) {
  case c::DataType::kFloat32:
    return load<float>(p);
  case c::DataType::kFloat16:
    return hyle::simd::f16_to_f32(load<hyle::simd::float16_t>(p));
  case c::DataType::kBFloat16:
    return hyle::simd::bf16_to_f32(load<hyle::simd::bfloat16_t>(p));
  case c::DataType::kFloat8E4M3FN:
    return hyle::simd::f8e4m3_to_f32(load<hyle::simd::float8_e4m3_t>(p));
  case c::DataType::kFloat8E5M2:
    return hyle::simd::f8e5m2_to_f32(load<hyle::simd::float8_e5m2_t>(p));
  default:
    std::abort();
  }
}
struct Data {
  Case spec;
  c::Operation op;
  std::vector<c::TensorDesc> desc;
  c::TensorDesc output;
  std::vector<m::Buffer> buffers;
  m::Buffer result;
  std::vector<c::ConstTensorView> inputs;
  std::array<c::TensorView, 1> outputs;
  explicit Data(Case s) : spec(std::move(s)) {
    const auto t = spec.type;
    const auto r = std::int64_t(spec.rows);
    constexpr std::int64_t h = 2048;
    auto d = dense(t, {r, h});
    switch (spec.kind) {
    case Kind::Unary:
      op = c::Operation(c::Unary{c::UnaryKind(spec.variant)});
      desc = {d};
      break;
    case Kind::Binary:
      op = c::Operation(c::Binary{c::BinaryKind(spec.variant)});
      desc = {d, d};
      break;
    case Kind::Reduce:
      op = c::Operation(
          c::Reduce{.kind = c::ReductionKind(spec.variant),
                    .axes = take(c::Axes::from(std::array<std::int32_t, 1>{1})),
                    .accumulation_type = c::DataType::kFloat32});
      desc = {d};
      break;
    case Kind::Norm:
      op = c::Operation(c::RmsNorm{.epsilon = spec.variant == 2 ? 1.0e-6F : 1.0e-5F});
      desc = {d, dense(t, {h})};
      break;
    case Kind::Gate:
      op = c::Operation(c::GatedActivation{
          .activation = c::GatedActivationKind::kSilu,
          .inputs = spec.variant ? c::GatedInputKind::kPackedHalves
                                 : c::GatedInputKind::kSeparate});
      desc =
          spec.variant ? std::vector{dense(t, {r, 2 * h})} : std::vector{d, d};
      break;
    case Kind::MatMul: {
      op = c::Operation(c::MatMul{});
      desc = {dense(t, {r, 1024}),
              spec.variant ? take(dense(t, {1024, 1024}).transposed())
                           : dense(t, {1024, 1024})};
      break;
    }
    case Kind::Rope:
      op = c::Operation(c::RoPE{.rotary_dimensions = 64, .sequence_axis = 1});
      desc = {dense(t, {1, r, 8, 256}), dense(c::DataType::kInt32, {r}),
              dense(c::DataType::kFloat32, {32})};
      break;
    case Kind::Softmax: {
      const bool boolean = spec.variant >= 2;
      op = c::Operation(c::Softmax{
          .kind = (spec.variant % 2) ? c::SoftmaxKind::kLogSoftmax
                                     : c::SoftmaxKind::kSoftmax,
          .mask = boolean ? c::MaskKind::kBoolean : c::MaskKind::kNone});
      desc = {d};
      if (boolean)
        desc.push_back(dense(c::DataType::kBool, {r, h}));
      break;
    }
    case Kind::Attention: {
      op = c::Operation(c::ScaledDotProductAttention{
          .scale = spec.variant ? .0625F : .125F,
          .causal = spec.variant != 0});
      const std::int64_t heads = spec.variant ? 8 : 4;
      const std::int64_t depth = spec.variant ? 256 : 64;
      desc = {dense(t, {1, r, heads, depth}), dense(t, {1, 128, heads, depth}),
              dense(t, {1, 128, heads, depth})};
      break;
    }
    case Kind::Gather:
      op = c::Operation(c::Gather{});
      desc = {dense(t, {64, h}), dense(spec.other, {r})};
      break;
    case Kind::Scatter:
      op = c::Operation(c::Scatter{.kind = spec.variant
                                               ? c::ScatterKind::kAdd
                                               : c::ScatterKind::kAssign});
      desc = {dense(t, {64, h}), dense(spec.other, {r}), d};
      break;
    case Kind::Concat:
      op = c::Operation(c::Concat{.axis = 1});
      desc = {d, d};
      break;
    case Kind::Cast:
      op = c::Operation(c::Cast{spec.other});
      desc = {d};
      break;
    case Kind::Copy:
      op = c::Operation(c::Copy{});
      desc = {spec.variant ? take(c::TensorDesc::strided_bytes(
          t, std::array{r, h}, std::array<std::int64_t, 2>{h * 8, 8})) : d};
      break;
    case Kind::Fill: {
      std::uint64_t bits = 0;
      std::array<std::byte, 8> raw{};
      encode(raw.data(), t, 1.25F);
      std::memcpy(&bits, raw.data(), c::data_type_size(t));
      op = c::Operation(c::Fill{.output_shape = take(c::TensorShape::create(
                                    std::array<std::int64_t, 2>{r, h})),
                                .output_type = t,
                                .value = c::ScalarValue::from_bits(t, bits)});
      break;
    }
    case Kind::Select:
      op = c::Operation(c::Select{});
      desc = {dense(c::DataType::kBool, {r, h}), d, d};
      break;
    }
    output = take(c::infer_single_output(op, desc));
    for (std::size_t input = 0; input < desc.size(); ++input) {
      const auto &dd = desc[input];
      auto b = take(m::Buffer::create(m::system_resource(),
                                      take(dd.required_bytes()), 64));
      std::vector<std::byte> bytes(b.size());
      const auto width = c::data_type_size(dd.data_type());
      for (std::size_t i = 0; i < b.size() / width; ++i) {
        auto *p = bytes.data() + i * width;
        const auto type = dd.data_type();
        if (type == c::DataType::kBool) {
          *p = i % 7 == 0 ? std::byte{0} : std::byte{1};
          continue;
        }
        if (type == c::DataType::kInt32) {
          store(p, static_cast<std::int32_t>(i % 64));
          continue;
        }
        if (type == c::DataType::kInt64) {
          store(p, static_cast<std::int64_t>(i % 64));
          continue;
        }
        float value = .5F + float((i + input * 11) % 29) / 64.F;
        if (spec.kind == Kind::MatMul)
          value = float(int((i + input * 7) % 23) - 11) / 64.F;
        if (spec.kind == Kind::Rope && input == 2)
          value = std::pow(10000000.F, -float(i) / 32.F);
        encode(p, type, value);
      }
      require(b.view().write(bytes));
      buffers.push_back(std::move(b));
    }
    result = take(m::Buffer::create(m::system_resource(),
                                    take(output.required_bytes()), 64));
    for (std::size_t i = 0; i < desc.size(); ++i)
      inputs.push_back(
          take(c::ConstTensorView::create(desc[i], buffers[i].view())));
    outputs[0] = take(c::TensorView::create(output, result.view()));
  }
  std::vector<std::byte> read() const {
    std::vector<std::byte> bytes(result.size());
    require(result.view().read(bytes));
    return bytes;
  }
};
bool exact(Kind k) {
  return k == Kind::Copy || k == Kind::Cast || k == Kind::Fill ||
         k == Kind::Concat || k == Kind::Select || k == Kind::Gather ||
         k == Kind::Scatter;
}
bool equal(Data &d, const std::vector<std::byte> &a,
           const std::vector<std::byte> &b) {
  if (exact(d.spec.kind))
    return a == b;
  const auto type = d.output.data_type();
  const auto width = c::data_type_size(type);
  for (std::size_t i = 0; i < a.size(); i += width) {
    const double x = decode(a.data() + i, type), y = decode(b.data() + i, type);
    if (std::isnan(y)) {
      if (!std::isnan(x))
        return false;
      continue;
    }
    if (std::isinf(y)) {
      if (x != y)
        return false;
      continue;
    }
    double relative = type == c::DataType::kBFloat16  ? .008
                      : type == c::DataType::kFloat16 ? .001
                                                      : 3e-6;
    double absolute = type == c::DataType::kFloat32
                          ? 4 * double(std::numeric_limits<float>::denorm_min())
                          : 1e-8;
    if (d.spec.kind == Kind::Norm)
      absolute = 2e-5;
    if (d.spec.kind == Kind::MatMul) {
      absolute = 2e-5;
      relative = 3e-5;
    }
    if (d.spec.kind == Kind::Attention || d.spec.kind == Kind::Rope)
      absolute = 8e-5;
    if (std::abs(x - y) > absolute + relative * std::abs(y)) {
      std::fprintf(stderr,
                   "NUMERIC_DIFFERENCE %s i=%zu native=%.17g mature=%.17g\n",
                   d.spec.id.c_str(), i / width, x, y);
      return false;
    }
  }
  return true;
}
constexpr std::array wins{
  std::string_view("copy-t6-r1-o6"),
  std::string_view("copy-t6-r32-o6"),
  std::string_view("copy-t4-r1-o6"),
  std::string_view("copy-t4-r32-o6"),
  std::string_view("copy-t5-r1-o6"),
  std::string_view("copy-t5-r32-o6"),
  std::string_view("copy-t2-r1-o6"),
  std::string_view("copy-t2-r32-o6"),
  std::string_view("copy-t3-r1-o6"),
  std::string_view("copy-t3-r32-o6"),
  std::string_view("norm-0-t6-r1-o6"),
  std::string_view("norm-0-t4-r1-o6"),
  std::string_view("norm-0-t4-r32-o6"),
  std::string_view("norm-0-t5-r1-o6"),
  std::string_view("norm-0-t5-r32-o6"),
  std::string_view("rms-model-eps6-t5-r1-o6"),
  std::string_view("rms-model-eps6-t5-r32-o6"),
};
namespace g = hyle::graph;
void check(bool ok, const char* message, const std::string& id = {}) {
  if (!ok) { std::fprintf(stderr, "FAIL %s %s\n", message, id.c_str()); std::exit(9); }
}
bool qualified_machine() {
#if defined(_WIN32) && defined(NDEBUG) && defined(_MSC_FULL_VER) && _MSC_FULL_VER == 195035728
  const auto& id=hyle::platform::cpu_identity();
  return std::string_view(id.vendor.data())=="GenuineIntel" && id.family==6 &&
    id.model==183 && id.stepping==1 && std::string_view(id.brand.data())=="13th Gen Intel(R) Core(TM) i9-13900K";
#else
  return false;
#endif
}
template<class T> bool member(const T& values,const std::string& id) {
  return std::find(values.begin(),values.end(),std::string_view(id))!=values.end();
}
c::Context mature_context() {
  // The serial-only Native preference must not apply to this context. This is
  // a numerical control, never a cross-thread performance comparison.
  return take(c::cpu::create_context({.native_threads=2}));
}
struct Run {
  c::Queue queue; c::PreparedOperation program; m::Buffer scratch;
  c::OperationInvocation invocation;
  Run(c::Context& context, Data& d) : queue(take(context.create_queue())),
    program(take(c::prepare(context,d.op,d.desc,std::span(&d.output,1),m::system_resource()))) {
    const auto w=program.workspace_requirement();
    if(program.runtime_properties().workspace_owner==c::ProviderWorkspaceOwner::kCaller && w.size)
      scratch=take(m::Buffer::create(m::system_resource(),w.size,w.alignment));
    invocation=take(program.create_invocation(scratch.view()));
  }
  std::vector<std::byte> execute(Data& d) {
    require(take(invocation.submit(queue,d.inputs,d.outputs)).wait()); return d.read();
  }
};
void change(Data& d) {
  for(std::size_t j=0;j<d.desc.size();++j){
    const auto t=d.desc[j].data_type();
    if(t==c::DataType::kBool || t==c::DataType::kInt32 || t==c::DataType::kInt64 ||
       (d.spec.kind==Kind::Rope && j==2)) continue;
    std::vector<std::byte> bytes(d.buffers[j].size());require(d.buffers[j].view().read(bytes));
    const auto width=c::data_type_size(t);
    for(std::size_t i=0;i<bytes.size();i+=width)
      encode(bytes.data()+i,t,float(decode(bytes.data()+i,t))+.125F);
    require(d.buffers[j].view().write(bytes));
  }
}
template<class Op> void mismatch(c::Context& context, Op op, std::vector<c::TensorDesc> ds,
              const char* label) {
  const auto operation=c::Operation(op);
  const auto output=take(c::infer_single_output(operation,ds));
  auto p=take(c::prepare(context,operation,ds,std::span(&output,1),m::system_resource()));
  check(p.provider().id!=c::native::kProviderId,label);
}
void lifetime() {
  auto context=take(c::cpu::create_context({.native_threads=1}));
  auto gc=take(g::cpu::create_context({.native_threads=1}));
  Case spec{"parallel-lifetime",Kind::Unary,c::DataType::kFloat32,0,1};
  Data first(spec),second(spec);change(second);
  Run a(context,first),b(context,second);
  auto builder=take(g::GraphBuilder::create());auto input=take(builder.input(first.desc[0]));
  auto result=take(builder.add(c::Unary{c::UnaryKind::kAbs},input));require(builder.publish(result));
  auto logical=take(std::move(builder).finish());auto compiled=take(g::compile(logical,gc));
  auto ga=take(gc.create_queue()),gb=take(gc.create_queue());
  auto ia=take(compiled.executable.create_invocation()),ib=take(compiled.executable.create_invocation());
  require(ia.bind(input,first.inputs[0]));require(ia.bind(result,first.outputs[0]));
  require(ib.bind(input,second.inputs[0]));require(ib.bind(result,second.outputs[0]));
  const std::array la{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&ga}};
  const std::array lb{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&gb}};
  require(ia.prepare_replay(la));require(ib.prepare_replay(lb));
  std::thread x([&]{a.execute(first);require(take(ia.submit(ga)).wait());});
  std::thread y([&]{b.execute(second);require(take(ib.submit(gb)).wait());});x.join();y.join();
  std::vector<std::byte> expected_a(first.buffers[0].size()),expected_b(second.buffers[0].size());
  require(first.buffers[0].view().read(expected_a));require(second.buffers[0].view().read(expected_b));
  check(first.read()==expected_a && second.read()==expected_b,"independent concurrent invocation");
  require(context.close());require(gc.close());
  check(!a.invocation.submit(a.queue,first.inputs,first.outputs),"Direct close rejection");
  check(!ia.submit(ga),"Graph close rejection");
  std::puts("PASS independent Direct/Graph concurrent slots and close rejection");
}
} // namespace
int main() {
  const auto& identity=hyle::platform::cpu_identity();
  std::printf("IDENTITY %s %s family=%u model=%u stepping=%u qualified=%d\n",
    identity.vendor.data(),identity.brand.data(),identity.family,identity.model,identity.stepping,int(qualified_machine()));
  std::array<const hyle::platform::CpuIdentity*,8> ids{};
  std::array<std::thread,8> readers;
  for(std::size_t i=0;i<ids.size();++i)readers[i]=std::thread([&,i]{ids[i]=&hyle::platform::cpu_identity();});
  for(auto& t:readers)t.join();for(auto* p:ids)check(p==&identity,"cached identity concurrency");
  auto context=take(c::cpu::create_context({.native_threads=1}));
  auto mature=mature_context();
  auto expert=take(c::Context::create(c::cpu::device(),c::native::provider()));
  auto gc=take(g::cpu::create_context({.native_threads=1}));
  auto gq=take(gc.create_queue());
  unsigned total=0,native_wins=0,loss_rejections=0,regions=0;
  for(const auto& s:catalog()) {
    
    Data d(s); Run ordinary(context,d),control(mature,d);
    check(control.program.provider().id!=c::native::kProviderId,"mature numerical control",s.id);
    const bool expected_native=qualified_machine()&&member(wins,s.id);
    check((ordinary.program.provider().id==c::native::kProviderId)==expected_native,"default binding",s.id);
    check(!expected_native || ordinary.program.route_policy().valid(),"qualified policy",s.id);
    native_wins+=expected_native;
    if(s.kind==Kind::Copy && s.variant==1) {
      auto rejected=c::prepare(expert,d.op,d.desc,std::span(&d.output,1),m::system_resource());
      check(!rejected && rejected.error().IsUnimplemented(),"Native exact strided decline",s.id);
      ++loss_rejections;
    }
    auto builder=take(g::GraphBuilder::create());std::vector<g::ValueId> inputs;
    for(const auto& desc:d.desc)inputs.push_back(take(builder.input(desc)));
    auto node=take(builder.add_node(d.op,inputs));auto value=take(builder.result(node));
    auto final=take(builder.add(c::Copy{},value));require(builder.publish(final));
    auto logical=take(std::move(builder).finish());auto compiled=take(g::compile(logical,gc));
    auto invocation=take(compiled.executable.create_invocation());
    for(std::size_t i=0;i<inputs.size();++i)require(invocation.bind(inputs[i],d.inputs[i]));
    require(invocation.bind(final,d.outputs[0]));
    const std::array lanes{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&gq}};
    require(invocation.prepare_replay(lanes));
    unsigned mature_regions=0;
    for(std::size_t i=0;i<compiled.report.step_count();++i){
      const auto step=take(compiled.report.step(i));
      if(step.kind==g::CompileStepKind::kProviderRegion && step.node_count>=2){
        check(step.provider.id!=c::native::kProviderId,"mature region retained",s.id);
        ++mature_regions;
      }
    }
    regions+=mature_regions;
    for(int replay=0;replay<2;++replay){
      if(replay)change(d);
      auto reference=control.execute(d),actual=ordinary.execute(d);
      check(equal(d,actual,reference),"ordinary numerical replay",s.id);
      require(take(invocation.submit(gq)).wait());
      check(equal(d,d.read(),reference),"graph numerical replay",s.id);
    }
    std::printf("CASE %s direct=%.*s mature_region=%u replay=2\n",s.id.c_str(),
      int(ordinary.program.provider().name.size()),ordinary.program.provider().name.data(),mature_regions);
    ++total;
  }
  const auto f=c::DataType::kFloat32;const auto data=dense(f,{1,2048}),weight=dense(f,{2048});
  mismatch(context,c::RmsNorm{.epsilon=1e-6F},{data,weight},"epsilon fallback");
  mismatch(context,c::LayerNorm{}, {data,weight,weight},"extra bias fallback");
  mismatch(context,c::Binary{c::BinaryKind::kAdd},{data,dense(f,{1,1})},"broadcast fallback");
  mismatch(context,c::Softmax{.axis=0},{data},"axis fallback");
  mismatch(context,c::Softmax{.scale=.5F},{data},"scale fallback");
  mismatch(context,c::Softmax{.mask=c::MaskKind::kBoolean},{data,dense(c::DataType::kBool,{1,1})},"mask geometry fallback");
  mismatch(context,c::Unary{c::UnaryKind::kAbs},{dense(f,{1,1024})},"unmeasured shape fallback");
  auto shape=take(c::TensorShape::create(std::array<std::int64_t,2>{32,2048}));
  mismatch(context,c::Fill{.output_shape=shape,.output_type=f,.value=c::ScalarValue(0.F)}, {},"unmeasured fill fallback");
  auto threaded=take(c::cpu::create_context({.native_threads=2}));
  mismatch(threaded,c::Unary{c::UnaryKind::kAbs},{data},"thread contract fallback");
  require(context.close());require(mature.close());require(expert.close());require(gc.close());require(threaded.close());
  check(total==24,"current three-op ledger");
  check(native_wins==(qualified_machine()?17U:0U),"win count");
  check(loss_rejections==(2U),"loss count");
  check(regions>0,"actual mature regions");
  lifetime();
  std::printf("PASS cases=%u native=%u cold_rejected=%u mature_regions=%u mismatch=9 changed_replay=2\n",total,native_wins,loss_rejections,regions);
  return 0;
}
