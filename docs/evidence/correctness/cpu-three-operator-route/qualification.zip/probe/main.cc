#include <algorithm>
#include <cstdio>
#include <limits>
#include <vector>
#include "cpu_program.h"

int main() {
  auto selected = hyle::compute::ggml_runtime::select_cpu_program();
  if (!selected) return 1;
  const auto *cpu = *selected;
  cpu->initialize();
  for (int sample = 0; sample < 6; ++sample) {
    auto *ctx = ggml_init({16 * 1024 * 1024, nullptr, false});
    auto *q = ggml_new_tensor_4d(ctx, GGML_TYPE_F32, 64, 1, 1, 1);
    auto *k = ggml_new_tensor_4d(ctx, GGML_TYPE_F32, 64, 2, 1, 1);
    auto *v = ggml_new_tensor_4d(ctx, GGML_TYPE_F32, 64, 2, 1, 1);
    std::fill_n(static_cast<float *>(q->data), 64, .5F);
    std::fill_n(static_cast<float *>(k->data), 128, .25F);
    std::fill_n(static_cast<float *>(v->data), 128, 1.F);
    if (sample == 1) static_cast<float *>(q->data)[0] = std::numeric_limits<float>::quiet_NaN();
    if (sample == 2 || sample == 3)
      std::fill_n(static_cast<float *>(k->data), 128,
                  sample == 2 ? -std::numeric_limits<float>::infinity() : std::numeric_limits<float>::infinity());
    if (sample == 4) {
      std::fill_n(static_cast<float *>(q->data), 64, std::numeric_limits<float>::max());
      std::fill_n(static_cast<float *>(k->data), 128, -std::numeric_limits<float>::max());
    }
    if (sample == 5) static_cast<float *>(q->data)[0] = std::numeric_limits<float>::infinity();
    auto *out = ggml_flash_attn_ext(ctx, q, k, v, nullptr, sample == 5 ? 0.F : .125F, 0.F, 0.F);
    if (!ggml_prec_set_acc(out, GGML_PREC_F32)) return 2;
    auto *graph = ggml_new_graph(ctx);
    ggml_build_forward_expand(graph, out);
    auto plan = cpu->plan(graph, 1, nullptr);
    std::vector<std::uint8_t> scratch(plan.work_size);
    plan.work_data = scratch.data();
    const auto status = cpu->compute(graph, &plan);
    std::printf("sample=%d status=%d output=%.9g\n", sample, int(status), static_cast<float *>(out->data)[0]);
    ggml_free(ctx);
  }
}
