import ctypes
from pathlib import Path
import subprocess

ctypes.windll.kernel32.SetErrorMode(0x8003)
base = Path('C:/hv/selected/dd6ba9eea2aa2417e511/build-605ef2324f17e5ef3df1')
logs = Path('.scratch/validation/m1-vulkan-admission')
(logs/'iree-ordinary-initial-LastTest.log').write_bytes((base/'Testing/Temporary/LastTest.log').read_bytes())
log = logs/'iree-ordinary-debug.log'
assert not log.exists()
argv = [r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\Llvm\x64\bin\lldb.exe', '-b',
        '-o', 'run', '-o', 'thread backtrace all', '-o', 'register read', '-o', 'disassemble --frame',
        '-o', 'quit', '--', str(base/'bin/hyle_graph_route_vulkan_test.exe'),
        '--gtest_filter=VulkanGraph.OriginalFloat8RegionContinuesIntoGgmlAndNativeCopy', '--gtest_catch_exceptions=0']
with log.open('wb') as output:
    result = subprocess.run(argv, stdout=output, stderr=subprocess.STDOUT, timeout=45)
print(log.read_text(errors='replace')[-23000:])
raise SystemExit(result.returncode)
