from pathlib import Path
import hashlib,json,tarfile
task=Path('/Users/kiro/hyle-m1v-product')
prefix='iree-ordinary-air-final'
record=json.loads((task/(prefix+'.json')).read_text())
archive=task/(prefix+'.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==record['archive_sha256']
for item in record['files']:
    path=task/'source'/item['path']
    assert path.resolve().is_relative_to((task/'source').resolve()) and not path.is_symlink()
    if item['before'] is None: assert not path.exists(),item['path']
    else: assert hashlib.sha256(path.read_bytes()).hexdigest()==item['before'],item['path']
with tarfile.open(archive) as stream:
    for item in record['files']:
        data=stream.extractfile(item['path']).read()
        assert hashlib.sha256(data).hexdigest()==item['after']
        path=task/'source'/item['path']
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
(task/(prefix+'-applied.json')).write_text(json.dumps(record,indent=2))
print('verified forward candidate',record['candidate'],flush=True)
