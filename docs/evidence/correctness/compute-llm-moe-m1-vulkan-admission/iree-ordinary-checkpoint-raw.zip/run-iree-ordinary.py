import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
label=sys.argv[1]
assert label.replace('-','').isalnum()
root=Path.cwd()
logs=root/'.scratch/validation/m1-vulkan-admission'
build=Path('C:/hv/selected/dd6ba9eea2aa2417e511/build-605ef2324f17e5ef3df1')
receipt=logs/('iree-'+label+'.json')
assert not receipt.exists()
patch=subprocess.check_output(['git','diff','HEAD','--binary'])
record={'label':label,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'diff_sha256':hashlib.sha256(patch).hexdigest(),'status':'RUNNING','commands':[]}
def save(): receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
commands=[]
if '--configure' in sys.argv:
    commands.append(('configure',['cmake','-S',str(root),'-B',str(build)]))
commands += [('build',['cmake','--build',str(build),'--parallel','2','--target','hyle_compute_provider_iree_vulkan_tests','hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests','hyle_compute_ops_tests','hyle_compute_provider_ggml_vulkan_tests']),
    ('tests',['ctest','--test-dir',str(build),'-L','^(compute_provider_iree_vulkan|compute_provider_ggml_vulkan|compute_route_vulkan|graph_route_vulkan|compute_ops)$','--output-on-failure','--no-tests=error','--timeout','30' if '--diagnostic' in sys.argv else '180'])]
save()
for name,argv in commands:
    log=logs/('iree-'+label+'-'+name+'.log')
    assert not log.exists()
    assert hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'])).hexdigest()==record['diff_sha256']
    print('RUN',name,flush=True)
    start=time.time()
    with log.open('wb') as out: result=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT,timeout=1200)
    record['commands'].append({'label':name,'argv':argv,'exit_code':result.returncode,'elapsed_seconds':time.time()-start,
        'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    save()
    if result.returncode:
        record['status']='FAIL';save()
        print(log.read_text(errors='replace')[-7000:],flush=True)
        raise SystemExit(result.returncode)
record['status']='PASS';save()
print('PASS',label,flush=True)
