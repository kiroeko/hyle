import hashlib,json
from pathlib import Path

def sha(data): return hashlib.sha256(data).hexdigest()
vendor=Path('third_party/iree_vulkan_runtime')
path='runtime/src/iree/async/platform/iocp/proactor.c'
original=(Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')/path).read_bytes().replace(b'\r\n',b'\n')
old='''    // Invoke the operation's callback and release to pool.
    iree_async_proactor_complete_operation(&wait_op->base, status,
                                           IREE_ASYNC_COMPLETION_FLAG_NONE);
    ++drained_count;

    // Clear tracker reference and free.
    wait_op->base.next = NULL;
    iree_allocator_free(tracker->allocator, tracker);'''
new='''    // Final callback owns the operation and may free/reuse it immediately.
    // Drop its tracker reference before returning that storage to the caller.
    wait_op->base.next = NULL;
    iree_async_proactor_complete_operation(&wait_op->base, status,
                                           IREE_ASYNC_COMPLETION_FLAG_NONE);
    ++drained_count;

    iree_allocator_free(tracker->allocator, tracker);'''
assert original.count(old.encode())==1
patched=original.replace(old.encode(),new.encode())
manifest=json.loads((vendor/'patches.json').read_text())
assert path not in [x['path'] for x in manifest['files']]
entry={'path':path,'before_sha256':sha(original),'after_sha256':sha(patched),'edits':[{'before':old,'after':new}]}
manifest['files'].append(entry)
(vendor/'patches.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
notice=vendor/'NOTICE.md'
text=notice.read_text().replace('The POSIX semaphore completion path clears its operation tracker reference',
                              'The POSIX and Windows IOCP semaphore completion paths clear their operation tracker reference')
notice.write_bytes(text.encode())
ledger=Path('cmake/HyleDependencyLock.json')
lock=json.loads(ledger.read_text())
item=next(x for x in lock['dependencies'] if x['name']=='iree_vulkan_runtime_patches')
tree=sha(''.join(f'{p.relative_to(vendor).as_posix()}|{sha(p.read_bytes().replace(bytes([13,10]),bytes([10])))}\n' for p in sorted(vendor.rglob('*')) if p.is_file()).encode())
content=ledger.read_text().replace(item['vendored']['tree_sha256'],tree)
old_notice=next(x['sha256'] for x in item['license']['files'] if x['path'].endswith('NOTICE.md'))
content=content.replace(old_notice,sha(notice.read_bytes()))
ledger.write_bytes(content.encode())
Path('.scratch/validation/m1-vulkan-admission/iree-iocp-lifetime-fix.json').write_text(json.dumps(entry,indent=2)+'\n')
print({k:v for k,v in entry.items() if k!='edits'})
