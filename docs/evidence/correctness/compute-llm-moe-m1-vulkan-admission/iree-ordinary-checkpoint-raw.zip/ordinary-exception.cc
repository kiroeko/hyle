#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <cstdint>

namespace {
void show_address(void *address) {
  MEMORY_BASIC_INFORMATION region{};
  if (!VirtualQuery(address, &region, sizeof(region))) return;
  char path[MAX_PATH]{};
  GetModuleFileNameA(static_cast<HMODULE>(region.AllocationBase), path, MAX_PATH);
  std::fprintf(stderr, "%s + 0x%llx\n", path,
               static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(address) -
                                                reinterpret_cast<std::uintptr_t>(region.AllocationBase)));
}
LONG WINAPI report(EXCEPTION_POINTERS *exception) {
  if (exception->ExceptionRecord->ExceptionCode != EXCEPTION_ACCESS_VIOLATION)
    return EXCEPTION_CONTINUE_SEARCH;
  std::fprintf(stderr, "M1-V diagnostic access violation %llu at 0x%llx\n",
               static_cast<unsigned long long>(exception->ExceptionRecord->ExceptionInformation[0]),
               static_cast<unsigned long long>(exception->ExceptionRecord->ExceptionInformation[1]));
  show_address(exception->ExceptionRecord->ExceptionAddress);
  void *frames[32]{};
  const auto count=CaptureStackBackTrace(0,32,frames,nullptr);
  for (unsigned short i=0;i<count;++i) show_address(frames[i]);
  std::fflush(stderr);
  return EXCEPTION_CONTINUE_SEARCH;
}
struct Install { Install() { AddVectoredExceptionHandler(1,report); } } install;
}
