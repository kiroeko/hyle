import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root=Path('C:/hv/checked-scan-c1');logs=Path('.scratch/validation/m1-vulkan-admission')
manifest=json.loads((root/'manifest.json').read_text());names={'manifest.json','checked.mlir','sync.vmfb','async.vmfb','run.py','compile.json'}
for case in manifest['cases']:names.update((case['input'],case['expected']))
archive=Path('C:/hv/checked-scan-c1-forward.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
    for name in sorted(names):tar.add(root/name,arcname=name)
record={'kind':'Canonical Windows checked-scan candidate, original ops only','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(names)}}
(logs/'checked-scan-forward.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
host='kiro@172.22.10.198';base='/Users/kiro/hyle-m1v-qvk'
subprocess.run(['scp',str(archive),host+':'+base+'/checked-scan-c1.tar.gz'],check=True,timeout=120)
command="test \"$(cat /Users/kiro/hyle-m1v-qvk/owner.txt)\" = 'M1-V Q-VK disposable forward verification' && mkdir /Users/kiro/hyle-m1v-qvk/checked-scan-c1 && tar -xzf /Users/kiro/hyle-m1v-qvk/checked-scan-c1.tar.gz -C /Users/kiro/hyle-m1v-qvk/checked-scan-c1 && /usr/bin/python3 /Users/kiro/hyle-m1v-qvk/checked-scan-c1/run.py"
log=logs/'air-checked-scan-launch.log';assert not log.exists()
with log.open('wb') as stream:result=subprocess.run(['ssh','-o','BatchMode=yes',host,command],stdout=stream,stderr=subprocess.STDOUT,timeout=600)
print('Air checked scan exit',result.returncode,flush=True);print(log.read_text(errors='replace')[-6000:],flush=True)
raise SystemExit(result.returncode)
