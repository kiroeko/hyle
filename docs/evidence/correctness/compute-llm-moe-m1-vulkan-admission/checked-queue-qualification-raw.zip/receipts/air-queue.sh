#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-qvk
test "$(cat "$task/owner.txt")" = 'M1-V Q-VK disposable forward verification'
test ! -L "$task"
test ! -e "$task/queue-source"
test ! -e "$task/queue-interop"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
cp -R "$task/source-runtime" "$task/queue-source"
tar -xzf "$task/queue-forward.tar.gz" -C "$task"
mkdir "$task/queue-logs"
cmake -S "$task/queue-interop" -B "$task/queue-build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 -DQVK_IREE_SOURCE="$task/queue-source" > "$task/queue-logs/configure.log" 2>&1
cmake --build "$task/queue-build" --parallel 2 --target qvk_static_consumer qvk_shared_consumer > "$task/queue-logs/build.log" 2>&1
for kind in static shared; do
  "$task/queue-build/qvk_${kind}_consumer" "$task/queue-interop/combined-async.vmfb" > "$task/queue-logs/$kind.log" 2>&1
  cat "$task/queue-logs/$kind.log"
done
tar -czf "$task/queue-results.tar.gz" -C "$task" queue-logs queue-interop queue-patch-final.json checked-scan-c1
