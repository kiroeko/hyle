from pathlib import Path
import hashlib
import json
import shutil

base = Path('C:/hv')
assert (base/'m1v-owner.txt').read_text().strip() == r'M1-V qualification only; canonical product: C:\public\project-hyle\hyle'
original = base/'source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f'
source = base/'queue-source'
assert source.parent == base and not source.is_symlink()
# First source copy hit an irrelevant broken documentation symlink on Windows.
# Runtime/build inputs in this newly task-owned copy are overwritten from the
# same immutable source; shared original sources remain untouched.
shutil.copytree(original, source, dirs_exist_ok=True,
                ignore=lambda path, names: {'docs'} if Path(path)==original else set())
folder = source/'runtime/src/iree/hal/drivers/vulkan'
changes = []

def edit(name, replacements):
    path = folder/name
    before = path.read_bytes()
    value = before.decode().replace('\r\n', '\n')
    for old, new, count in replacements:
        assert value.count(old) == count, (name, old[:90], value.count(old))
        value = value.replace(old, new)
    path.write_bytes(value.encode())
    changes.append({'path': str(path.relative_to(source)).replace('\\','/'),
                    'original_sha256': hashlib.sha256(before).hexdigest(),
                    'patched_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})

fields = '''  // Optional external owner serializing host access to the borrowed queue.
  // The callback must execute action synchronously; user_data outlives device.
  iree_hal_vulkan_external_queue_call_fn_t external_queue_call;
  void* external_queue_user_data;
'''
edit('api.h', [('// Externally-created VkDevice contract supplied to iree_hal_vulkan_wrap_device.', '''// Resource-only qualification extension. No compiler/kernel changes.
typedef iree_status_t (*iree_hal_vulkan_external_queue_action_fn_t)(void* data);
typedef iree_status_t (*iree_hal_vulkan_external_queue_call_fn_t)(
    void* user_data, VkQueue queue,
    iree_hal_vulkan_external_queue_action_fn_t action, void* action_data);

// Externally-created VkDevice contract supplied to iree_hal_vulkan_wrap_device.''', 1),
    ('} iree_hal_vulkan_external_device_params_t;', fields+'} iree_hal_vulkan_external_device_params_t;', 1)])
edit('queue.h', [('  iree_slim_mutex_t* queue_handle_mutex;\n', '  iree_slim_mutex_t* queue_handle_mutex;\n\n'+fields, 2)])
edit('logical_device.c', [
    ('struct iree_hal_vulkan_logical_device_t {\n', 'struct iree_hal_vulkan_logical_device_t {\n'+fields+'\n', 1),
    ('      .proactor = device->proactor,', '      .external_queue_call = device->external_queue_call,\n      .external_queue_user_data = device->external_queue_user_data,\n      .proactor = device->proactor,', 1),
    ('    device->logical_device = logical_device;\n', '    device->logical_device = logical_device;\n    device->external_queue_call = external_device_params->external_queue_call;\n    device->external_queue_user_data = external_device_params->external_queue_user_data;\n', 1)])
helper = '''// Borrowed queue access goes through the native owner's existing host lock.
typedef struct iree_hal_vulkan_external_queue_submission_t {
  iree_hal_vulkan_queue_t* queue;
  const VkSubmitInfo2* submit;
  const VkBindSparseInfo* sparse;
} iree_hal_vulkan_external_queue_submission_t;

static iree_status_t iree_hal_vulkan_external_queue_submit(void* data) {
  iree_hal_vulkan_external_queue_submission_t* call = data;
  iree_hal_vulkan_queue_t* queue = call->queue;
  if (call->sparse) {
    return iree_vkQueueBindSparse(IREE_VULKAN_DEVICE(&queue->syms),
                                 queue->queue, 1, call->sparse, VK_NULL_HANDLE);
  }
  return iree_vkQueueSubmit2(IREE_VULKAN_DEVICE(&queue->syms), queue->queue,
                             1, call->submit, VK_NULL_HANDLE);
}

static iree_status_t iree_hal_vulkan_external_queue_call(
    iree_hal_vulkan_queue_t* queue, const VkSubmitInfo2* submit,
    const VkBindSparseInfo* sparse) {
  iree_hal_vulkan_external_queue_submission_t call = {queue, submit, sparse};
  if (queue->external_queue_call) {
    return queue->external_queue_call(queue->external_queue_user_data,
        queue->queue, iree_hal_vulkan_external_queue_submit, &call);
  }
  return iree_hal_vulkan_external_queue_submit(&call);
}

'''
queue_text = (folder/'queue.c').read_text()
anchor = 'static iree_status_t iree_hal_vulkan_queue_submit_sparse_bind_under_lock('
edit('queue.c', [
    (anchor, helper+anchor, 1),
    ('iree_vkQueueBindSparse(IREE_VULKAN_DEVICE(&queue->syms), queue->queue,\n                               /*bindInfoCount=*/1, &bind_info, VK_NULL_HANDLE)', 'iree_hal_vulkan_external_queue_call(queue, NULL, &bind_info)', 1),
    ('iree_vkQueueSubmit2(IREE_VULKAN_DEVICE(&queue->syms), queue->queue, 1,\n                              &submit_info, VK_NULL_HANDLE)', 'iree_hal_vulkan_external_queue_call(queue, &submit_info, NULL)', 1),
    ('  out_queue->queue_handle_mutex = params->queue_handle_mutex;\n', '  out_queue->queue_handle_mutex = params->queue_handle_mutex;\n  out_queue->external_queue_call = params->external_queue_call;\n  out_queue->external_queue_user_data = params->external_queue_user_data;\n', 1)])
(base/'queue-patch.json').write_bytes((json.dumps({'kind':'private resource-only qualification overlay; no HYLE product','changes':changes},indent=2)+'\n').encode())

root=base/'queue-interop'
assert not root.exists()
shutil.copytree(base/'interop',root)
text=(root/'interop.cc').read_text()
text=text.replace('#include "iree/async/util/proactor_pool.h"', '#include "iree/async/util/proactor_pool.h"\n#include "iree/async/operations/semaphore.h"')
text=text.replace('#include <iterator>', '#include <iterator>\n#include <mutex>\n#include <condition_variable>\n#include <chrono>\n#include <atomic>')
text=text.replace('struct Native {', 'struct Native {\n  std::mutex queue_mutex;\n  std::atomic<unsigned> external_calls{0};')
text=text.replace('check(vkQueueSubmit(queue,1,&submit,fence));', '{std::lock_guard lock(queue_mutex);check(vkQueueSubmit(queue,1,&submit,fence));}')
text=text.replace('    external.compute_queue_set={native.family,1};', '''    external.compute_queue_set={native.family,1};
    external.external_queue_user_data=&native;
    external.external_queue_call=[](void* data,VkQueue queue,
        iree_hal_vulkan_external_queue_action_fn_t action,void* action_data)->iree_status_t {
      auto &n=*static_cast<Native*>(data);
      if(queue!=n.queue)return iree_make_status(IREE_STATUS_INVALID_ARGUMENT,"unexpected native queue");
      std::lock_guard lock(n.queue_mutex);
      ++n.external_calls;
      return action(action_data);
    };''')
insert='''struct AsyncCopy {
  Native &native;
  VkCommandPool pool{};
  VkCommandBuffer command{};
  explicit AsyncCopy(Native &n):native(n) {
    VkCommandPoolCreateInfo p{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    p.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;p.queueFamilyIndex=n.family;
    check(vkCreateCommandPool(n.device,&p,nullptr,&pool));
    VkCommandBufferAllocateInfo a{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    a.commandPool=pool;a.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;a.commandBufferCount=1;
    check(vkAllocateCommandBuffers(n.device,&a,&command));
  }
  void submit(BufferSpan src,BufferSpan dst,size_t bytes) {
    check(vkResetCommandBuffer(command,0));
    VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    check(vkBeginCommandBuffer(command,&begin));
    VkMemoryBarrier barrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
    barrier.srcAccessMask=VK_ACCESS_MEMORY_WRITE_BIT;barrier.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT|VK_ACCESS_TRANSFER_WRITE_BIT;
    vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,1,&barrier,0,nullptr,0,nullptr);
    VkBufferCopy c{src.offset,dst.offset,bytes};vkCmdCopyBuffer(command,src.handle,dst.handle,1,&c);
    barrier.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;barrier.dstAccessMask=VK_ACCESS_MEMORY_READ_BIT;
    vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,0,1,&barrier,0,nullptr,0,nullptr);
    check(vkEndCommandBuffer(command));
    VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};submit.commandBufferCount=1;submit.pCommandBuffers=&command;
    std::lock_guard lock(native.queue_mutex);check(vkQueueSubmit(native.queue,1,&submit,VK_NULL_HANDLE));
  }
  ~AsyncCopy(){vkDestroyCommandPool(native.device,pool,nullptr);}
};

// The original runtime's proactor resumes fragment boundaries without a HYLE
// poll loop, additional thread, kernel dispatcher, or a GPU wait in submit.
struct Chain {
  Native &native;iree_hal_device_t *device;iree_async_proactor_t *proactor;
  Call second;AsyncCopy copy;View destination;iree_hal_buffer_view_t *initial;
  Submission *first;std::unique_ptr<Submission> next;
  std::array<iree_async_semaphore_wait_operation_t,2> waits{};
  std::array<iree_async_semaphore_t*,2> semaphores{};
  std::array<uint64_t,2> values{1,1};
  std::mutex mutex;std::condition_variable changed;bool finished=false,failed=false;
  bool copied=false;View result;
  Chain(Native &n,iree_hal_device_t *d,iree_async_proactor_t *p,
        iree_vm_context_t *c,Submission &s,View dst,iree_hal_buffer_view_t *init)
      :native(n),device(d),proactor(p),second(c),copy(n),destination(std::move(dst)),initial(init),first(&s) {}
  void finish(bool error) {
    std::lock_guard lock(mutex);failed=error;finished=true;changed.notify_all();
  }
  void arm(size_t phase,iree_hal_fence_t *fence) {
    auto list=iree_hal_fence_semaphore_list(fence);
    require(list.count==1,"single completion expected");
    semaphores[phase]=reinterpret_cast<iree_async_semaphore_t*>(list.semaphores[0]);
    values[phase]=list.payload_values[0];
    auto &op=waits[phase];op.base.type=IREE_ASYNC_OPERATION_TYPE_SEMAPHORE_WAIT;
    op.base.user_data=this;op.semaphores=&semaphores[phase];op.values=&values[phase];op.count=1;
    op.mode=IREE_ASYNC_WAIT_MODE_ALL;
    op.base.completion_fn=[](void* data,iree_async_operation_t *op,iree_status_t status,iree_async_completion_flags_t) {
      auto &self=*static_cast<Chain*>(data);
      if(!iree_status_is_ok(status)){iree_status_free(status);self.finish(true);return;}
      try {
        if(op==&self.waits[0].base) {
          View produced(iree_vm_list_get_buffer_view_retain(self.first->call.outputs,0));
          self.copy.submit(native_span(iree_hal_buffer_view_buffer(produced.get())),native_span(iree_hal_buffer_view_buffer(self.destination.get())),34*4);
          self.copied=true;
          self.next=std::make_unique<Submission>(self.device,self.second,self.destination.get(),self.initial);
          self.arm(1,self.next->done.get());
          check(iree_hal_fence_signal(self.next->ready.get()));
        } else {
          self.result.reset(iree_vm_list_get_buffer_view_retain(self.second.outputs,0));
          self.finish(false);
        }
      } catch(const std::exception &e){std::fprintf(stderr,"continuation failed: %s\\n",e.what());self.finish(true);}
    };
    check(iree_async_proactor_submit_one(proactor,&op.base));
  }
  void wait(bool expected_failure=false) {
    std::unique_lock lock(mutex);
    require(changed.wait_for(lock,std::chrono::seconds(10),[this]{return finished;}),"automatic continuation made no progress");
    require(failed==expected_failure,"unexpected continuation status");
  }
};

'''
text=text.replace('int main(int argc,char **argv) try {', insert+'int main(int argc,char **argv) try {')
chain_test='''    {
      iree_async_proactor_t *proactor=nullptr;check(iree_async_proactor_pool_get(pool.get(),0,&proactor));
      std::array<View,2> inputs,initial;
      std::array<std::unique_ptr<Call>,2> calls;
      for(size_t i=0;i<2;++i){
        inputs[i]=input(native,device.get(),upload,kInputs[i].data(),34,{2,17});
        initial[i]=input(native,device.get(),upload,kInitial[i].data(),2,{2});
        calls[i]=std::make_unique<Call>(contexts[i].get());
      }
      for(size_t repeat=0;repeat<3;++repeat){
        std::array<View,2> destinations;
        for(size_t i=0;i<2;++i)destinations[i]=input(native,device.get(),upload,kInputs[i].data(),34,{2,17});
        std::array<std::unique_ptr<Submission>,2> first;
        std::array<std::unique_ptr<Chain>,2> chains;
        for(size_t i=0;i<2;++i){
          first[i]=std::make_unique<Submission>(device.get(),*calls[i],inputs[i].get(),initial[i].get());
          chains[i]=std::make_unique<Chain>(native,device.get(),proactor,contexts[i].get(),*first[i],std::move(destinations[i]),initial[i].get());
          chains[i]->arm(0,first[i]->done.get());
        }
        check(iree_hal_fence_signal(first[1]->ready.get()));check(iree_hal_fence_signal(first[0]->ready.get()));
        // Only wait for the final chain state; no caller-driven progress/poll.
        for(auto &chain:chains)chain->wait();
        for(size_t i=0;i<2;++i){
          std::array<int32_t,34> expected{};
          for(size_t row=0;row<2;++row){int32_t acc=kInitial[i][row];for(size_t col=0;col<17;++col){expected[row*17+col]=acc;acc+=kExpected[i][row*17+col];}}
          compare(native,readback,chains[i]->result.get(),expected.data(),34);
          compare(native,readback,inputs[i].get(),kInputs[i].data(),34);
          require(chains[i]->copied,"native continuation did not execute");
        }
      }
      auto destination=input(native,device.get(),upload,kInputs[0].data(),34,{2,17});
      Submission failed(device.get(),*calls[0],inputs[0].get(),initial[0].get());
      Chain chain(native,device.get(),proactor,contexts[0].get(),failed,std::move(destination),initial[0].get());
      chain.arm(0,failed.done.get());
      iree_hal_fence_fail(failed.ready.get(),iree_make_status(IREE_STATUS_ABORTED,"intentional mixed-boundary failure"));
      chain.wait(true);require(!chain.copied,"dependent native work ran after failure");
      require(native.external_calls.load()>0,"queue owner hook was not used");
      std::printf("PASS original proactor: IREE -> native GPU copy -> IREE, two pending chains repeat3; failed dependency skips suffix; shared native queue hook calls=%u\\n",native.external_calls.load());
    }
'''
text=text.replace('    contexts={};compare(',chain_test+'    contexts={};compare(')
(root/'interop.cc').write_bytes(text.encode())
print(json.dumps({'overlay_files':len(changes),'source':str(source),'consumer':str(root)}))
