from pathlib import Path
import hashlib
import json
import tarfile
import zipfile

logs=Path('.scratch/validation/m1-vulkan-admission')
dest=Path('evidence/correctness/compute-llm-moe-m1-vulkan-admission')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
windows=read(Path('C:/hv/checked-scan-c1/result.json'))
with tarfile.open(logs/'air-queue-results.tar.gz') as tar:
    air=json.load(tar.extractfile('checked-scan-c1/result.json'))
    air_logs={kind:tar.extractfile('queue-logs/'+kind+'.log').read().decode() for kind in ('static','shared')}
assert windows['status']==air['status']=='PASS'
assert len(windows['cases'])==len(air['cases'])==12
win_queue=read(logs/'queue-windows-resource-c1.json')
assert win_queue['status']==read(logs/'air-queue-forward.json')['status']=='PASS'
assert all('PASS original proactor:' in value for value in air_logs.values())
archive=dest/'checked-queue-qualification-raw.zip';assert not archive.exists()
manifest=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    def add(p,name):
        out.write(p,name);manifest.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
    for p in sorted(logs.iterdir()):
        if p.is_file() and any(x in p.name for x in ('checked','queue')) and p.suffix in ('.py','.ps1','.sh','.json','.log','.c','.h'):
            add(p,'receipts/'+p.name)
    add(logs/'air-queue-results.tar.gz','air-queue-results.tar.gz')
    for name in ('checked-scan','checked-scan-c1','queue-interop'):
        for p in sorted(Path('C:/hv',name).iterdir()):
            if p.is_file():add(p,name+'/'+p.name)
    final=read(Path('C:/hv/queue-patch-final.json'))
    for change in final['changes']:
        add(Path('C:/hv/queue-source',change['path']),'resource-overlay/'+change['path'])
    add(Path('C:/hv/queue-patch.json'),'resource-overlay/initial-manifest.json')
    add(Path('C:/hv/queue-patch-final.json'),'resource-overlay/final-manifest.json')
    out.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
record={
 'kind':'M1-V assigned numerical and external-queue continuation qualification; ordinary product acceptance still pending',
 'product_head':'2e4d8ecb37c3e2baf3cdae55b20691f381258838',
 'qualification':'PASS for checked I32 semantics and original asynchronous external-queue composition on Windows RTX4070 and Air/MoltenVK',
 'product_admission':'INCONCLUSIVE', 'new_full_coverage_cells':0,
 'pins':{'iree':'6ef606b6fa3e12bd2c12d36a07463069eb71185f','ggml':'456172ec733a135778adcd32d00e576a58232e45'},
 'checked_scan':{
   'windows':windows,'air':air,'oracle':'Independent int64 prefix sums; exact output in valid cases, overflow flag in invalid cases',
   'cases':['valid boundary rows','positive overflow then cancellation','negative overflow then cancellation','exclusive final-total-only overflow','one element min/max','3 by 513 normal'],
   'implementation':'Original i64 scan plus original conversion/comparison/reduction; no custom scan or shader',
   'first_failure':'Original exclusive scan accumulator excludes the last input. Case 7 returned no error for [INT32_MAX,1].',
   'correction':'One correction: original linalg.reduce adds the final total check; no tolerance relaxation',
   'private_workspace':'Truncated data stays private until the wrapper validates the flag; public output must remain unwritten on overflow',
   'required_native_feature':'shaderInt64 must be actually enabled, not only supported',
 },
 'shared_queue':{
   'windows_cpp_static_shared':'PASS', 'air_cpp_static_shared':'PASS on one compute queue',
   'sequence':'Original IREE scan -> native GPU boundary copy -> original IREE scan, two simultaneously pending chains, repeat3; caller only waits for final state',
   'failure':'A failed accepted ready dependency reaches asynchronous completion and skips dependent native work',
   'progress':'Original iree_async_semaphore_wait_operation_t on the original runtime proactor pool; no extra HYLE thread or polling loop',
   'host_access':'Four-file private resource-only overlay wraps original QueueSubmit2/BindSparse in a synchronous external owner callback, retaining original internal mutex; default call unchanged',
   'hook_calls_per_consumer':48,
   'owner_and_cost':'One original completion thread for the queue plus original proactor runner; VM and transient allocations/encodings remain provider-owned; boundary copies and notifications are real costs',
   'limits':'Uses a qualification native queue owner, not yet the product ggml NativeDevice; actual HYLE/ggml/IREE feature bridge, ordinary graph and accepted-prefix teardown remain product gates',
 },
 'failed_attempts_preserved':[
   'Windows source copy hit an unrelated broken documentation symlink; runtime copy excludes docs',
   'Resource overlay API initially omitted opaque VkQueue declaration; one declaration correction',
   'A generated launch filename replacement also changed the build path; corrected path, original failed receipt retained',
   'Resource overlay fields initially preceded required offset-zero HAL resource header, causing access violation; one layout correction',
 ],
 'remaining':['Register, scope and audit independent IREE factor plus named public low-precision descriptors','Actual product native feature/host-lock/lifetime seam and ordinary Direct/Graph','Checked Scan failure without output writes and FP8/MXFP4 ordinary MatMul','Declared Windows/Air product source/static/shared relocation, applicable host instrumentation/OFF gates and P0'],
 'budget':{'start_utc':'2026-09-20 08:02:33 UTC','deadline_utc':'2026-09-20 12:02:33 UTC','reset':False},
 'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},
 'loc':{'implementation_lines':51953,'files':222,'excluded':['tests','bench','third_party']},
}
(dest/'checked-queue-qualification.json').write_bytes((json.dumps(record,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps({'archive_bytes':archive.stat().st_size,'files':len(manifest),'qualification':'PASS','product':'INCONCLUSIVE'}))
