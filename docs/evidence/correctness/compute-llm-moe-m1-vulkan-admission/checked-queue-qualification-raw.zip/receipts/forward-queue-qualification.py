from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import time

base=Path('C:/hv');logs=Path('.scratch/validation/m1-vulkan-admission')
pin='6ef606b6fa3e12bd2c12d36a07463069eb71185f'
source=base/'queue-source';original=base/('source/iree-'+pin)
relative=Path('runtime/src/iree/hal/drivers/vulkan')
changes=[]
for name in ('api.h','logical_device.c','queue.h','queue.c'):
    p=relative/name
    changes.append({'path':p.as_posix(),'original_sha256':hashlib.sha256((original/p).read_bytes()).hexdigest(),
                    'patched_sha256':hashlib.sha256((source/p).read_bytes()).hexdigest()})
(base/'queue-patch-final.json').write_bytes((json.dumps({'kind':'qualified resource-only overlay, mathematics unchanged','pin':pin,'changes':changes},indent=2)+'\n').encode())
script='''#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-qvk
test "$(cat "$task/owner.txt")" = 'M1-V Q-VK disposable forward verification'
test ! -L "$task"
test ! -e "$task/queue-source"
test ! -e "$task/queue-interop"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
cp -R "$task/source-runtime" "$task/queue-source"
tar -xzf "$task/queue-forward.tar.gz" -C "$task"
mkdir "$task/queue-logs"
cmake -S "$task/queue-interop" -B "$task/queue-build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 -DQVK_IREE_SOURCE="$task/queue-source" > "$task/queue-logs/configure.log" 2>&1
cmake --build "$task/queue-build" --parallel 2 --target qvk_static_consumer qvk_shared_consumer > "$task/queue-logs/build.log" 2>&1
for kind in static shared; do
  "$task/queue-build/qvk_${kind}_consumer" "$task/queue-interop/combined-async.vmfb" > "$task/queue-logs/$kind.log" 2>&1
  cat "$task/queue-logs/$kind.log"
done
tar -czf "$task/queue-results.tar.gz" -C "$task" queue-logs queue-interop queue-patch-final.json checked-scan-c1
'''
(logs/'air-queue.sh').write_bytes(script.encode())
archive=base/'queue-forward.tar.gz';assert not archive.exists()
manifest={}
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
    def add(p,name):
        tar.add(p,arcname=name);manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
    for change in changes:add(source/change['path'],'queue-source/'+change['path'])
    for p in sorted((base/'queue-interop').iterdir()):
        if p.is_file():add(p,'queue-interop/'+p.name)
    add(base/'queue-patch-final.json','queue-patch-final.json')
record={'kind':'Windows canonical private resource overlay and async qualification forward copy','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest,'commands':[]}
receipt=logs/'air-queue-forward.json';assert not receipt.exists()
def run(label,args,limit):
    start=time.time();path=logs/('air-queue-'+label+'.log');assert not path.exists()
    with path.open('wb') as out:result=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,timeout=limit)
    record['commands'].append({'label':label,'argv':args,'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    record['status']='RUNNING' if result.returncode==0 else 'FAIL'
    receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
    print(label,result.returncode,flush=True)
    if result.returncode:
        print(path.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(result.returncode)
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-m1v-qvk'
run('transfer',['scp',str(archive),host+':'+remote+'/queue-forward.tar.gz'],120)
run('script',['scp',str(logs/'air-queue.sh'),host+':'+remote+'/air-queue.sh'],120)
run('run',['ssh','-o','BatchMode=yes',host,'bash '+remote+'/air-queue.sh'],600)
run('collect',['scp',host+':'+remote+'/queue-results.tar.gz',str(logs/'air-queue-results.tar.gz')],120)
record['status']='PASS';receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
print((logs/'air-queue-run.log').read_text(errors='replace'),flush=True)
