from pathlib import Path
import hashlib
import json
logs=Path('.scratch/validation/m1-vulkan-admission')
p=Path('C:/hv/queue-source/runtime/src/iree/hal/drivers/vulkan/logical_device.c')
before=p.read_bytes();(logs/'queue-logical-device-before-resource-fix.c').write_bytes(before)
t=before.decode();start=t.index('struct iree_hal_vulkan_logical_device_t {\n')+len('struct iree_hal_vulkan_logical_device_t {\n')
end=t.index('  // HAL resource header.',start)
fields=t[start:end];assert 'external_queue_call' in fields
t=t[:start]+t[end:]
anchor='  iree_hal_resource_t resource;\n';assert t.count(anchor)==1
t=t.replace(anchor,anchor+'\n'+fields,1);p.write_bytes(t.encode())
(logs/'queue-resource-header-fix.json').write_bytes((json.dumps({'root_cause':'Qualification overlay inserted fields ahead of the required offset-zero HAL resource header; move them after header','correction':1,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n').encode())
consumer=Path('C:/hv/queue-interop/interop.cc')
consumer.write_bytes(consumer.read_text().replace('  require(argc==2,','  std::setvbuf(stdout,nullptr,_IONBF,0);\n  require(argc==2,').encode())
text=(logs/'queue-windows-c1b.py').read_text().replace('queue-windows-c1b.json','queue-windows-resource-c1.json').replace("logs/('queue-win-c1b-'", "logs/('queue-win-resource-c1-'")
(logs/'queue-windows-resource-c1.py').write_bytes(text.encode())
(logs/'queue-windows-resource-c1.ps1').write_bytes((logs/'queue-windows.ps1').read_text().replace('queue-windows.py','queue-windows-resource-c1.py').encode())
