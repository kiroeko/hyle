from pathlib import Path
logs=Path('.scratch/validation/m1-vulkan-admission')
text=(logs/'queue-windows-c1.py').read_text()
text=text.replace("build=Path('C:/hv/queue-win-c1-build')","build=Path('C:/hv/queue-win-build')")
text=text.replace('queue-windows-c1.json','queue-windows-c1b.json')
text=text.replace("logs/('queue-win-c1-'", "logs/('queue-win-c1b-'")
(logs/'queue-windows-c1b.py').write_bytes(text.encode())
(logs/'queue-windows-c1b.ps1').write_bytes((logs/'queue-windows.ps1').read_text().replace('queue-windows.py','queue-windows-c1b.py').encode())
