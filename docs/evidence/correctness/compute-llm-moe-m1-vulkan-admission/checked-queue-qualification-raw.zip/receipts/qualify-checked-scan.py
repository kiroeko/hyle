import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import time
import numpy as np

ctypes.windll.kernel32.SetErrorMode(0x8003)
root=Path('C:/hv/checked-scan');root.mkdir(exist_ok=False)
recipe='''func.func @scan_MODE(%input: tensor<?x?xi32>) -> (tensor<?x?xi32>, tensor<i32>) {
  %c0 = arith.constant 0 : index
  %c1 = arith.constant 1 : index
  %rows = tensor.dim %input, %c0 : tensor<?x?xi32>
  %width = tensor.dim %input, %c1 : tensor<?x?xi32>
  %zero = arith.constant 0 : i32
  %zero64 = arith.constant 0 : i64
  %minimum = arith.constant -2147483648 : i64
  %maximum = arith.constant 2147483647 : i64
  %wide_empty = tensor.empty(%rows, %width) : tensor<?x?xi64>
  %wide = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%input : tensor<?x?xi32>) outs(%wide_empty : tensor<?x?xi64>) {
    ^bb0(%value: i32, %unused: i64):
      %converted = arith.extsi %value : i32 to i64
      linalg.yield %converted : i64
  } -> tensor<?x?xi64>
  %carry_empty = tensor.empty(%rows) : tensor<?xi64>
  %initial = linalg.fill ins(%zero64 : i64) outs(%carry_empty : tensor<?xi64>) -> tensor<?xi64>
  %result:2 = iree_linalg_ext.scan dimension(1) inclusive(INCLUSIVE)
      ins(%wide : tensor<?x?xi64>) outs(%wide_empty, %initial : tensor<?x?xi64>, tensor<?xi64>) {
    ^bb0(%left: i64, %right: i64):
      %sum = arith.addi %left, %right : i64
      iree_linalg_ext.yield %sum : i64
  } -> tensor<?x?xi64>, tensor<?xi64>
  %flags_empty = tensor.empty(%rows, %width) : tensor<?x?xi32>
  %flags = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%result#0 : tensor<?x?xi64>) outs(%flags_empty : tensor<?x?xi32>) {
    ^bb0(%value: i64, %unused: i32):
      %low = arith.cmpi slt, %value, %minimum : i64
      %high = arith.cmpi sgt, %value, %maximum : i64
      %invalid = arith.ori %low, %high : i1
      %flag = arith.extui %invalid : i1 to i32
      linalg.yield %flag : i32
  } -> tensor<?x?xi32>
  %carry_flags_empty = tensor.empty(%rows) : tensor<?xi32>
  %carry_flags = linalg.generic {indexing_maps = [affine_map<(d0)->(d0)>, affine_map<(d0)->(d0)>], iterator_types = ["parallel"]}
      ins(%result#1 : tensor<?xi64>) outs(%carry_flags_empty : tensor<?xi32>) {
    ^bb0(%value: i64, %unused: i32):
      %low = arith.cmpi slt, %value, %minimum : i64
      %high = arith.cmpi sgt, %value, %maximum : i64
      %invalid = arith.ori %low, %high : i1
      %flag = arith.extui %invalid : i1 to i32
      linalg.yield %flag : i32
  } -> tensor<?xi32>
  %scalar_empty = tensor.empty() : tensor<i32>
  %scalar_zero = linalg.fill ins(%zero : i32) outs(%scalar_empty : tensor<i32>) -> tensor<i32>
  %prefix_status = linalg.reduce ins(%flags : tensor<?x?xi32>) outs(%scalar_zero : tensor<i32>) dimensions = [0,1]
      (%value: i32, %acc: i32) {
        %combined = arith.ori %value, %acc : i32
        linalg.yield %combined : i32
      }
  %status = linalg.reduce ins(%carry_flags : tensor<?xi32>) outs(%prefix_status : tensor<i32>) dimensions = [0]
      (%value: i32, %acc: i32) {
        %combined = arith.ori %value, %acc : i32
        linalg.yield %combined : i32
      }
  %output = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%result#0 : tensor<?x?xi64>) outs(%flags_empty : tensor<?x?xi32>) {
    ^bb0(%value: i64, %unused: i32):
      %converted = arith.trunci %value : i64 to i32
      linalg.yield %converted : i32
  } -> tensor<?x?xi32>
  return %output, %status : tensor<?x?xi32>, tensor<i32>
}
'''
(root/'checked.mlir').write_bytes(('module {\n'+''.join(recipe.replace('MODE',mode).replace('INCLUSIVE',str(mode=='inclusive').lower()) for mode in ('inclusive','exclusive'))+'}\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=root/'compile.json';record={'kind':'Public checked Scan qualification via original wide scan, standard conversion/comparison/reduction; no custom math kernel','status':'RUNNING','recipe_sha256':sha(root/'checked.mlir'),'commands':[]}
def save():receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
for abi in ('sync','async'):
    args=['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-compile.exe',str(root/'checked.mlir'),'--iree-hal-target-device=vulkan','--iree-vulkan-target=vp_android_baseline_2022','--iree-vulkan-dispatch-abi=descriptors','--iree-vulkan-target-features=spirv:v1.3,cap:Shader,cap:Int64']
    if abi=='async':args+=['--iree-execution-model=async-external']
    args+=['-o',str(root/(abi+'.vmfb'))];log=root/(abi+'-compile.log');start=time.time()
    with log.open('wb') as stream:result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    passed=result.returncode==0 and 'error:' not in log.read_text(errors='replace').lower()
    record['commands'].append({'argv':args,'exit_code':result.returncode,'valid':passed,'elapsed_seconds':time.time()-start,'log_sha256':sha(log)});save()
    if not passed:record['status']='FAIL';save();print(log.read_text(errors='replace')[-7000:]);raise SystemExit(1)
    record[abi+'_vmfb_sha256']=sha(root/(abi+'.vmfb'))
record['status']='PASS';save()
arrays=[np.array([[2147483647,0,-2147483647,-2147483648,2147483647],[-5,-2,1,4,-4]],dtype=np.int32),np.array([[2147483647,1,-1,0,0]],dtype=np.int32),np.array([[-2147483648,-1,1,0,0]],dtype=np.int32),np.array([[2147483647,1]],dtype=np.int32),np.array([[-2147483648],[2147483647]],dtype=np.int32),((np.arange(3*513,dtype=np.int32)*3)%11-5).reshape(3,513)]
cases=[]
for index,values in enumerate(arrays):
    p=root/f'input-{index}.npy';np.save(p,values);wide=np.cumsum(values,axis=1,dtype=np.int64)
    failed=int(np.any(wide<-2147483648) or np.any(wide>2147483647))
    for mode in ('inclusive','exclusive'):
        expected=wide.astype(np.int32) if mode=='inclusive' else np.concatenate((np.zeros((values.shape[0],1),dtype=np.int64),wide[:,:-1]),axis=1).astype(np.int32)
        out=root/f'{mode}-{index}-expected.npy';np.save(out,expected)
        cases.append({'name':'scan_'+mode,'input':p.name,'input_sha256':sha(p),'expected':out.name,'expected_sha256':sha(out),'error_flag':failed,'compare_values':not failed})
(root/'manifest.json').write_bytes((json.dumps({'cases':cases,'artifacts':{abi:sha(root/(abi+'.vmfb')) for abi in ('sync','async')}},indent=2)+'\n').encode())
print('Checked scan compile PASS; twelve cases prepared',flush=True)
