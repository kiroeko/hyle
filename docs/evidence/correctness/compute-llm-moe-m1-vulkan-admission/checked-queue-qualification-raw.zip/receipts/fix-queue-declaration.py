from pathlib import Path
import hashlib
import json
logs=Path('.scratch/validation/m1-vulkan-admission')
path=Path('C:/hv/queue-source/runtime/src/iree/hal/drivers/vulkan/api.h')
before=path.read_bytes();(logs/'queue-api-before-c1.h').write_bytes(before)
text=before.decode();assert text.count('VK_DEFINE_HANDLE(VkDevice);')==1
path.write_bytes(text.replace('VK_DEFINE_HANDLE(VkDevice);','VK_DEFINE_HANDLE(VkDevice);\nVK_DEFINE_HANDLE(VkQueue);').encode())
record={'root_cause':'Minimal public Vulkan declarations did not include VkQueue; add opaque declaration, no math/dispatch change',
        'correction':1,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(path.read_bytes()).hexdigest()}
(logs/'queue-declaration-c1.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
text=(logs/'queue-windows.py').read_text().replace('queue-windows.json','queue-windows-c1.json').replace('queue-win-','queue-win-c1-')
text=text.replace("run('configure',['cmake','-S',str(root),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DQVK_IREE_SOURCE=C:/hv/queue-source'])\n",'')
(logs/'queue-windows-c1.py').write_bytes(text.encode())
(logs/'queue-windows-c1.ps1').write_bytes((logs/'queue-windows.ps1').read_text().replace('queue-windows.py','queue-windows-c1.py').encode())
