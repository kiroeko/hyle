from pathlib import Path
logs=Path('.scratch/validation/m1-vulkan-admission')
text=(logs/'interop-windows-inflight.py').read_text()
text=text.replace("C:/hv/interop'", "C:/hv/queue-interop'").replace("C:/hv/interop-win-build'", "C:/hv/queue-win-build'")
text=text.replace('interop-windows-inflight.json','queue-windows.json').replace('interop-win-inflight-','queue-win-')
text=text.replace('Q-VK native C runtime C++ source/static/shared qualification; no HYLE provider registered',
                  'Q-VK resource-only queue hook and original asynchronous progress qualification; not HYLE delivery')
text=text.replace("run('build',", "run('configure',['cmake','-S',str(root),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DQVK_IREE_SOURCE=C:/hv/queue-source'])\nrun('build',",1)
text=text.replace("record['configure_reused_artifact']='unchanged original CMake source/context; python3 command alias only'",
                  "record['resource_overlay']=__import__('json').loads(Path('C:/hv/queue-patch.json').read_text())")
text=text.replace('Windows original C runtime external resource qualification PASS','Windows queue hook and original continuation qualification PASS')
py=logs/'queue-windows.py';assert not py.exists();py.write_bytes(text.encode())
ps=logs/'queue-windows.ps1';assert not ps.exists()
ps.write_bytes((logs/'interop-windows.ps1').read_text().replace('interop-windows.py','queue-windows.py').encode())
