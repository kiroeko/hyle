from pathlib import Path
source=Path('.scratch/validation/m1-vulkan-admission/qualify-checked-scan.py').read_text()
source=source.replace("root=Path('C:/hv/checked-scan')", "root=Path('C:/hv/checked-scan-c1')")
needle="(root/'checked.mlir').write_bytes(('module {\\n'+''.join(recipe.replace('MODE',mode).replace('INCLUSIVE',str(mode=='inclusive').lower()) for mode in ('inclusive','exclusive'))+'}\\n').encode())"
assert needle in source
replacement='''functions=[]
for mode in ('inclusive','exclusive'):
    function=recipe.replace('MODE',mode).replace('INCLUSIVE',str(mode=='inclusive').lower())
    if mode=='exclusive':
        total="""  %final_total = linalg.reduce ins(%wide : tensor<?x?xi64>) outs(%initial : tensor<?xi64>) dimensions = [1]
      (%value: i64, %acc: i64) {
        %sum = arith.addi %value, %acc : i64
        linalg.yield %sum : i64
      }
"""
        function=function.replace('  %carry_flags_empty =',total+'  %carry_flags_empty =')
        function=function.replace('ins(%result#1 : tensor<?xi64>)','ins(%final_total : tensor<?xi64>)')
    functions.append(function)
(root/'checked.mlir').write_bytes(('module {\\n'+''.join(functions)+'}\\n').encode())'''
source=source.replace(needle,replacement)
dest=Path('.scratch/validation/m1-vulkan-admission/qualify-checked-scan-c1.py');assert not dest.exists();dest.write_bytes(source.encode())
runner=Path('.scratch/validation/m1-vulkan-admission/run-checked-scan.py').read_text().replace('checked-scan','checked-scan-c1')
Path('.scratch/validation/m1-vulkan-admission/run-checked-scan-c1.py').write_bytes(runner.encode())
