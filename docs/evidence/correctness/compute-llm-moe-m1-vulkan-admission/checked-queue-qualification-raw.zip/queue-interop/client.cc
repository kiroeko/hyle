int qvk_execute(int, char**);
int main(int argc,char**argv){return qvk_execute(argc,argv);}
