import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

root=Path(__file__).resolve().parent;windows=sys.platform=='win32'
if windows:
    import ctypes
    ctypes.windll.kernel32.SetErrorMode(0x8003)
    assert root==Path('C:/hv/checked-scan-c1')
    runtime=Path('C:/hv/tools-win/iree/_runtime_libs/iree-run-module.exe');device='vulkan://GPU-e73765606f5dec196ee43dd3a2c81ef8'
else:
    assert root==Path('/Users/kiro/hyle-m1v-qvk/checked-scan-c1')
    assert (root.parent/'owner.txt').read_text().strip()=='M1-V Q-VK disposable forward verification'
    runtime=root.parent/'runtime-build/tools/iree-run-module';device='vulkan'
    os.environ['VK_DRIVER_FILES']='/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json'
    os.environ['DYLD_LIBRARY_PATH']='/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def values(p):
    data=p.read_bytes();assert data[:6]==b'\x93NUMPY';width=2 if data[6]==1 else 4
    length=int.from_bytes(data[8:8+width],'little');header=ast.literal_eval(data[8+width:8+width+length].decode().strip());assert not header['fortran_order'] and header['descr']=='<i4'
    return header['shape'],tuple(v[0] for v in struct.iter_unpack('<i',data[8+width+length:]))
manifest=json.loads((root/'manifest.json').read_text());assert sha(root/'sync.vmfb')==manifest['artifacts']['sync']
record={'status':'RUNNING','runtime_sha256':sha(runtime),'module_sha256':manifest['artifacts']['sync'],'cases':[]}
receipt=root/'result.json';assert not receipt.exists()
def save():receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
for index,case in enumerate(manifest['cases']):
    assert sha(root/case['input'])==case['input_sha256'];assert sha(root/case['expected'])==case['expected_sha256']
    output=root/f'actual-{index}.npy';flag=root/f'flag-{index}.npy';log=root/f'run-{index}.log'
    assert not output.exists() and not log.exists()
    args=[str(runtime),'--device='+device,'--module='+str(root/'sync.vmfb'),'--function='+case['name'],'--input=@'+str(root/case['input']),'--output=@'+str(output),'--output=@'+str(flag)]
    start=time.time()
    with log.open('wb') as stream:result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
    passed=False
    if result.returncode==0:
        passed=values(flag)==((),(case['error_flag'],)) and (not case['compare_values'] or values(output)==values(root/case['expected']))
    record['cases'].append({'index':index,'function':case['name'],'argv':args,'exit_code':result.returncode,'pass':passed,'expected_error':case['error_flag'],'log_sha256':sha(log),'elapsed_seconds':time.time()-start});save()
    print(index,case['name'],'expected_error',case['error_flag'],'PASS' if passed else 'FAIL',flush=True)
    if not passed:
        record['status']='FAIL';save();print(log.read_text(errors='replace')[-6000:]);raise SystemExit(1)
record['status']='PASS';save();print('Checked I32 prefix/final-total qualification PASS',flush=True)
