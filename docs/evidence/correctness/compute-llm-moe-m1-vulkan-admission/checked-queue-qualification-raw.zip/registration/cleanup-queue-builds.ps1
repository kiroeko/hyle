$ErrorActionPreference = 'Stop'
$m1vOwnedRoot = (Resolve-Path -LiteralPath 'C:\hv').Path
if ($m1vOwnedRoot -cne 'C:\hv' -or
    ((Get-Item -LiteralPath $m1vOwnedRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) -or
    (Get-Content -LiteralPath 'C:\hv\m1v-owner.txt' -Raw).Trim() -cne 'M1-V qualification only; canonical product: C:\public\project-hyle\hyle') {
  throw 'M1-V scratch owner mismatch'
}
$m1vArchive = 'C:\public\project-hyle\hyle\evidence\correctness\compute-llm-moe-m1-vulkan-admission\checked-queue-qualification-raw.zip'
$m1vReceipt = Get-Content -LiteralPath 'C:\public\project-hyle\hyle\evidence\correctness\compute-llm-moe-m1-vulkan-admission\checked-queue-qualification.json' -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $m1vArchive -Algorithm SHA256).Hash.ToLowerInvariant() -cne $m1vReceipt.archive.sha256) { throw 'qualification archive not verified' }
$m1vRemoved = @()
foreach ($m1vName in @('queue-source', 'queue-win-build')) {
  $m1vTarget = Join-Path $m1vOwnedRoot $m1vName
  $m1vResolved = (Resolve-Path -LiteralPath $m1vTarget).Path
  if ($m1vResolved -cne $m1vTarget -or -not $m1vResolved.StartsWith('C:\hv\', [StringComparison]::OrdinalIgnoreCase) -or
      ((Get-Item -LiteralPath $m1vResolved).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'unsafe cleanup path' }
  $m1vBytes = (Get-ChildItem -LiteralPath $m1vResolved -Recurse -File -Force | Measure-Object Length -Sum).Sum
  Write-Output "Removing archived qualification build: $m1vResolved ($m1vBytes bytes)"
  Remove-Item -LiteralPath $m1vResolved -Recurse -Force
  $m1vRemoved += [pscustomobject]@{ path = $m1vResolved; bytes = $m1vBytes; removed = -not (Test-Path -LiteralPath $m1vResolved) }
}
$m1vJson = ConvertTo-Json -InputObject $m1vRemoved -Depth 4
[IO.File]::WriteAllText('C:\public\project-hyle\hyle\.scratch\validation\m1-vulkan-admission\queue-build-cleanup-windows.json', $m1vJson + "`n", [Text.UTF8Encoding]::new($false))
