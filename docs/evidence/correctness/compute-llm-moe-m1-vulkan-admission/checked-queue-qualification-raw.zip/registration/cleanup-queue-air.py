from pathlib import Path
import hashlib
import json
import subprocess

logs=Path('.scratch/validation/m1-vulkan-admission')
archive=logs/'air-queue-results.tar.gz'
assert archive.is_file()
assert json.loads((logs/'air-queue-forward.json').read_text())['status']=='PASS'
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
remote='''from pathlib import Path
import hashlib,json,shutil
base=Path('/Users/kiro/hyle-m1v-qvk')
assert base.resolve()==base and not base.is_symlink()
assert (base/'owner.txt').read_text().strip()=='M1-V Q-VK disposable forward verification'
assert hashlib.sha256((base/'queue-results.tar.gz').read_bytes()).hexdigest()==DIGEST
results=[]
for name in ('queue-source','queue-build'):
    path=base/name
    assert path.resolve()==path and path.parent==base and not path.is_symlink()
    size=sum(p.stat().st_size for p in path.rglob('*') if not p.is_symlink() and p.is_file())
    shutil.rmtree(path)
    results.append({'path':str(path),'bytes':size,'removed':not path.exists()})
print(json.dumps(results,indent=2))
'''.replace('DIGEST',repr(digest))
result=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -'],input=remote.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
(logs/'queue-build-cleanup-air.json').write_bytes(result.stdout)
(logs/'queue-build-cleanup-air.log').write_bytes(result.stderr)
print(result.stdout.decode(),end='');print(result.stderr.decode(),end='')
raise SystemExit(result.returncode)
