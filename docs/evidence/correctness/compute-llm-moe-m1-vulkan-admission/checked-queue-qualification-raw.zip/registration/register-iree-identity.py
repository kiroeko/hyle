from pathlib import Path
import json
p=Path('docs/implementation/module-status.json')
data=json.loads(p.read_text(encoding='utf-8'))
assert not any(x['module']=='compute_provider_iree_vulkan' for x in data['modules'])
for m in data['modules']:
    if m['module'] in ('compute_route_vulkan','graph_route_vulkan','compute_provider_ggml_vulkan'):
        assert m['state']=='AUDITED'
        m['summary']='M1-V AUDITED：原版ggml recurrent普通Direct/Graph已实现；checked Scan/FP8、MXFP4与单队列异步续执行资格通过。IREE先登记自身owner；普通混合接入与产品三交付未完成，自研冻结，覆盖0。'
data['modules'].append({'module':'compute_provider_iree_vulkan','state':'QUEUED','summary':'M1-V 条件资格已通过，登记独立IREE Vulkan runtime/制品/资源owner身份；尚无产品target、普通入口或依赖，先SCOPED/AUDITED。'})
p.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
p=Path('docs/implementation/tasks/compute/llm-moe-provider-integration-ledger.md')
t=p.read_text(encoding='utf-8')
t=t.replace('普通入口、checked-overflow、混合单队列同步和产品三交付尚未通过；沿用原四小时调查预算，不计覆盖。','后续[限定资格](../../../../evidence/correctness/compute-llm-moe-m1-vulkan-admission/checked-queue-qualification.json)已补齐两台机器的 checked-overflow 和共享单队列自动续执行；IREE 独立身份登记 QUEUED。普通 HYLE 混合入口及产品三交付仍待验收，不计覆盖，原调查预算不重置。')
t=t.replace('三 owner 按[接入卡](llm-moe-m1-vulkan-admission.md) AUDITED：先实施原版 recurrent；Q-VK 组合资格后才决定新增 IREE factor','三 owner 按[接入卡](llm-moe-m1-vulkan-admission.md) AUDITED；原版 recurrent已接；Q-VK分工资格通过，独立IREE身份QUEUED，普通混合接入待自身审计')
p.write_bytes(t.encode())
