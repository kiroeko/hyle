import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path.cwd()
logs = root / '.scratch/validation/m1-vulkan-admission'
build = Path('C:/hv/selected/dd6ba9eea2aa2417e511/build-605ef2324f17e5ef3df1')
candidate = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
receipt = logs / 'mxfp4-windows.json'
assert not receipt.exists()
record = {'kind':'M1-V ordinary MXFP4 product slice and common format tests; remaining M1 gates pending',
          'candidate':candidate,'baseline':'8b3c5c30','status':'RUNNING','commands':[],
          'build_reuse':'Existing canonical-source CMake tree reconfigured; no old test verdict reused',
          'selection_scope':'Preserve full selector plan; execute declared slice factors now. Broad closure/delivery gates await final M1 candidate.'}
def save(): receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
def run(label, argv):
    path = logs / ('mxfp4-win-'+label+'.log')
    assert not path.exists()
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == candidate
    assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
    print('RUN',label,flush=True)
    started=time.time()
    with path.open('wb') as output:
        result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,timeout=1200)
    record['commands'].append({'label':label,'argv':argv,'exit_code':result.returncode,
        'elapsed_seconds':time.time()-started,'log':str(path),
        'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    save()
    if result.returncode:
        record['status']='FAIL';save()
        print(path.read_text(errors='replace')[-12000:],flush=True)
        raise SystemExit(result.returncode)
save()
run('plan',[sys.executable,'scripts/validation-select.py','plan','--base','8b3c5c30',
    '--candidate',candidate,'--context','.scratch/validation/windows-msvc-context.json',
    '--output',str(logs/'mxfp4-candidate-plan.json')])
run('configure',['cmake','-S',str(root),'-B',str(build),
    '-DHYLE_DEV_FACTORS=compute_ops,compute_provider_ggml_vulkan,compute_route_vulkan,graph_route_vulkan'])
run('build',['cmake','--build',str(build),'--parallel','2','--target',
    'hyle_compute_ops_tests','hyle_compute_provider_ggml_vulkan_tests',
    'hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests'])
run('tests',['ctest','--test-dir',str(build),'-L',
    '^(compute_ops|compute_provider_ggml_vulkan|compute_route_vulkan|graph_route_vulkan)$',
    '--output-on-failure','--no-tests=error','--timeout','240'])
record['status']='PASS';save()
print('Windows ordinary MXFP4 product slice PASS',flush=True)
