import hashlib
import json
from pathlib import Path
import subprocess

task = Path('/Users/kiro/hyle-m1v-product')
source = task / 'source'
manifest = json.loads((task / 'mxfp4-forward.json').read_text())
archive = task / 'mxfp4-forward.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['archive_sha256']
assert not (task / 'mxfp4-applied.json').exists()
for relative, hashes in manifest['files'].items():
    path = source / relative
    assert path.resolve().is_relative_to(source) and not path.is_symlink()
    if hashes['before'] is None:
        assert not path.exists(), relative
    else:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == hashes['before'], relative
subprocess.run(['tar','-xzf',str(archive),'-C',str(source)],check=True)
for relative, hashes in manifest['files'].items():
    assert hashlib.sha256((source / relative).read_bytes()).hexdigest() == hashes['after'], relative
(task / 'mxfp4-applied.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Forward-only source identity verified:',manifest['candidate'],flush=True)
