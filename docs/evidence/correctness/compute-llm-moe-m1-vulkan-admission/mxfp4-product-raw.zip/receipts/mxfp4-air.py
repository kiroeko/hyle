import hashlib
import json
from pathlib import Path
import subprocess
import time

logs=Path('.scratch/validation/m1-vulkan-admission')
base='db770b6fc1e46aa8d8aa86c1102d50acf26eb49f'
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
files={}
for row in subprocess.check_output(['git','diff','--name-status',base,candidate],text=True).splitlines():
    kind,path=row.split('\t')
    assert kind in ('A','M'), row
    before=hashlib.sha256(subprocess.check_output(['git','show',base+':'+path])).hexdigest() if kind=='M' else None
    after=hashlib.sha256(subprocess.check_output(['git','show',candidate+':'+path])).hexdigest()
    files[path]={'before':before,'after':after}
archive=Path('C:/hv/mxfp4-forward.tar.gz')
assert not archive.exists()
subprocess.run(['git','archive','--format=tar.gz','--output='+str(archive),candidate,*files],check=True)
manifest={'baseline':base,'candidate':candidate,'files':files,
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
manifest_path=logs/'mxfp4-air-forward.json'
manifest_path.write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
host='kiro@172.22.10.198'
remote=host+':/Users/kiro/hyle-m1v-product/'
for path,name in [(archive,'mxfp4-forward.tar.gz'),(manifest_path,'mxfp4-forward.json'),
                  (logs/'mxfp4-air-apply.py','mxfp4-apply.py'),(logs/'mxfp4-air.sh','mxfp4-run.sh')]:
    subprocess.run(['scp',str(path),remote+name],check=True,timeout=120)
path=logs/'mxfp4-air-launch.log'
assert not path.exists()
start=time.time()
with path.open('wb') as output:
    result=subprocess.run(['ssh','-o','BatchMode=yes',host,'bash /Users/kiro/hyle-m1v-product/mxfp4-run.sh'],
                          stdout=output,stderr=subprocess.STDOUT,timeout=1800)
record={'candidate':candidate,'status':'PASS' if result.returncode==0 else 'FAIL',
        'exit_code':result.returncode,'elapsed_seconds':time.time()-start,
        'launch_log_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'scope':'Air ordinary MXFP4/format slice, four factors/headers; remaining M1 gates pending'}
(logs/'mxfp4-air-result.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(path.read_text(errors='replace')[-11000:],flush=True)
raise SystemExit(result.returncode)
