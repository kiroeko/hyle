#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
#map7 = affine_map<(d0, d1, d2) -> (d0, d1, d2)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg49: tensor<2x17xi32>, %arg50: tensor<2xi32>):
    %111 = "tensor.empty"() : () -> tensor<2x17xi32>
    %112:2 = "iree_linalg_ext.scan"(%arg49, %111, %arg50) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg51: i32, %arg52: i32):
      %113 = "arith.addi"(%arg51, %arg52) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%113) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%112#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg45: tensor<2x17xi32>, %arg46: tensor<2xi32>):
    %108 = "tensor.empty"() : () -> tensor<2x17xi32>
    %109:2 = "iree_linalg_ext.scan"(%arg45, %108, %arg46) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg47: i32, %arg48: i32):
      %110 = "arith.addi"(%arg47, %arg48) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%110) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%109#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x1xf32>, tensor<1x1xf32>) -> tensor<2x128xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg30: tensor<2x128xi8>, %arg31: tensor<128x128xi8>, %arg32: tensor<2x1xf32>, %arg33: tensor<1x1xf32>):
    %92 = "flow.tensor.bitcast"(%arg30) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %93 = "flow.tensor.bitcast"(%arg31) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %94 = "tensor.empty"() : () -> tensor<2x128xf32>
    %95 = "tensor.empty"() : () -> tensor<128x128xf32>
    %96 = "linalg.generic"(%92, %arg32, %94) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg42: f8E4M3FN, %arg43: f32, %arg44: f32):
      %106 = "arith.extf"(%arg42) : (f8E4M3FN) -> f32
      %107 = "arith.mulf"(%106, %arg43) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%107) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x1xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %97 = "linalg.generic"(%93, %arg33, %95) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg39: f8E4M3FN, %arg40: f32, %arg41: f32):
      %104 = "arith.extf"(%arg39) : (f8E4M3FN) -> f32
      %105 = "arith.mulf"(%104, %arg40) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%105) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<1x1xf32>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %98 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %99 = "tensor.empty"() : () -> tensor<2x128xf32>
    %100 = "linalg.fill"(%98, %99) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg37: f32, %arg38: f32):
      "linalg.yield"(%arg37) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %101 = "linalg.matmul"(%96, %97, %100) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg34: f32, %arg35: f32, %arg36: f32):
      %102 = "arith.mulf"(%arg34, %arg35) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %103 = "arith.addf"(%arg36, %102) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%103) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%101) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x4xi8>, tensor<128x4xi8>) -> tensor<2x128xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg15: tensor<2x128xi8>, %arg16: tensor<128x128xi8>, %arg17: tensor<2x4xi8>, %arg18: tensor<128x4xi8>):
    %56 = "flow.tensor.bitcast"(%arg15) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %57 = "flow.tensor.bitcast"(%arg16) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %58 = "flow.tensor.bitcast"(%arg17) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x4xi8>) -> tensor<2x4xf8E8M0FNU>
    %59 = "flow.tensor.bitcast"(%arg18) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x4xi8>) -> tensor<128x4xf8E8M0FNU>
    %60 = "tensor.empty"() : () -> tensor<2x128xf32>
    %61 = "tensor.empty"() : () -> tensor<128x128xf32>
    %62 = "linalg.generic"(%56, %58, %60) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f8E8M0FNU, %arg29: f32):
      %81 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %82 = "arith.bitcast"(%arg28) : (f8E8M0FNU) -> i8
      %83 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %84 = "arith.extui"(%82) : (i8) -> i32
      %85 = "arith.shli"(%84, %83) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %86 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %87 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %88 = "arith.cmpi"(%82, %86) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %89 = "arith.select"(%88, %87, %85) : (i1, i32, i32) -> i32
      %90 = "arith.bitcast"(%89) : (i32) -> f32
      %91 = "arith.mulf"(%81, %90) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%91) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x4xf8E8M0FNU>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %63 = "linalg.generic"(%57, %59, %61) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f8E8M0FNU, %arg26: f32):
      %70 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %71 = "arith.bitcast"(%arg25) : (f8E8M0FNU) -> i8
      %72 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %73 = "arith.extui"(%71) : (i8) -> i32
      %74 = "arith.shli"(%73, %72) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %75 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %76 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %77 = "arith.cmpi"(%71, %75) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %78 = "arith.select"(%77, %76, %74) : (i1, i32, i32) -> i32
      %79 = "arith.bitcast"(%78) : (i32) -> f32
      %80 = "arith.mulf"(%70, %79) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%80) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<128x4xf8E8M0FNU>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %64 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %65 = "tensor.empty"() : () -> tensor<2x128xf32>
    %66 = "linalg.fill"(%64, %65) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %67 = "linalg.matmul"(%62, %63, %66) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %68 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %69 = "arith.addf"(%arg21, %68) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%69) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%67) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xf16>, tensor<16x64xi8>, tensor<16x4xi8>) -> tensor<2x16xf16>, sym_name = "fp4_ue8_matmul"}> ({
  ^bb0(%arg0: tensor<2x128xf16>, %arg1: tensor<16x64xi8>, %arg2: tensor<16x4xi8>):
    %0 = "tensor.expand_shape"(%arg1) <{reassociation = [[0], [1, 2]], static_output_shape = array<i64: 16, 4, 16>}> : (tensor<16x64xi8>) -> tensor<16x4x16xi8>
    %1 = "flow.tensor.bitcast"(%0) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<16x4x16xi8>) -> tensor<16x4x32xi4>
    %2 = "flow.tensor.bitcast"(%arg2) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<16x4xi8>) -> tensor<16x4xf8E8M0FNU>
    %3 = "tensor.empty"() : () -> tensor<16x4x32xf32>
    %4 = "linalg.generic"(%1, %2, %3) <{indexing_maps = [#map7, #map5, #map7], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: i4, %arg13: f8E8M0FNU, %arg14: f32):
      %18 = "arith.bitcast"(%arg12) : (i4) -> f4E2M1FN
      %19 = "arith.bitcast"(%18) : (f4E2M1FN) -> i4
      %20 = "arith.constant"() <{value = 0 : i4}> : () -> i4
      %21 = "arith.constant"() <{value = 1 : i4}> : () -> i4
      %22 = "arith.constant"() <{value = 2 : i4}> : () -> i4
      %23 = "arith.constant"() <{value = 4 : i4}> : () -> i4
      %24 = "arith.constant"() <{value = 7 : i4}> : () -> i4
      %25 = "arith.andi"(%19, %24) : (i4, i4) -> i4
      %26 = "arith.constant"() <{value = 20 : i32}> : () -> i32
      %27 = "arith.shli"(%25, %22) <{overflowFlags = #arith.overflow<none>}> : (i4, i4) -> i4
      %28 = "arith.cmpi"(%25, %21) <{predicate = 0 : i64}> : (i4, i4) -> i1
      %29 = "arith.select"(%28, %20, %27) : (i1, i4, i4) -> i4
      %30 = "arith.extui"(%29) : (i4) -> i32
      %31 = "arith.shli"(%30, %26) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %32 = "arith.constant"() <{value = 0 : i32}> : () -> i32
      %33 = "arith.constant"() <{value = 1073741824 : i32}> : () -> i32
      %34 = "arith.constant"() <{value = 1056964608 : i32}> : () -> i32
      %35 = "arith.cmpi"(%25, %23) <{predicate = 9 : i64}> : (i4, i4) -> i1
      %36 = "arith.select"(%35, %33, %34) : (i1, i32, i32) -> i32
      %37 = "arith.cmpi"(%25, %20) <{predicate = 0 : i64}> : (i4, i4) -> i1
      %38 = "arith.select"(%37, %32, %36) : (i1, i32, i32) -> i32
      %39 = "arith.constant"() <{value = -2147483648 : i32}> : () -> i32
      %40 = "arith.constant"() <{value = -8 : i4}> : () -> i4
      %41 = "arith.cmpi"(%19, %40) <{predicate = 9 : i64}> : (i4, i4) -> i1
      %42 = "arith.select"(%41, %39, %32) : (i1, i32, i32) -> i32
      %43 = "arith.addi"(%31, %38) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %44 = "arith.addi"(%43, %42) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %45 = "arith.bitcast"(%44) : (i32) -> f32
      %46 = "arith.bitcast"(%arg13) : (f8E8M0FNU) -> i8
      %47 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %48 = "arith.extui"(%46) : (i8) -> i32
      %49 = "arith.shli"(%48, %47) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %50 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %51 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %52 = "arith.cmpi"(%46, %50) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %53 = "arith.select"(%52, %51, %49) : (i1, i32, i32) -> i32
      %54 = "arith.bitcast"(%53) : (i32) -> f32
      %55 = "arith.mulf"(%45, %54) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%55) : (f32) -> ()
    }) : (tensor<16x4x32xi4>, tensor<16x4xf8E8M0FNU>, tensor<16x4x32xf32>) -> tensor<16x4x32xf32>
    %5 = "tensor.collapse_shape"(%4) <{reassociation = [[0], [1, 2]]}> : (tensor<16x4x32xf32>) -> tensor<16x128xf32>
    %6 = "tensor.empty"() : () -> tensor<2x128xf32>
    %7 = "linalg.generic"(%arg0, %6) <{indexing_maps = [#map, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg10: f16, %arg11: f32):
      %17 = "arith.extf"(%arg10) : (f16) -> f32
      "linalg.yield"(%17) : (f32) -> ()
    }) : (tensor<2x128xf16>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %8 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %9 = "tensor.empty"() : () -> tensor<2x16xf32>
    %10 = "linalg.fill"(%8, %9) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg8: f32, %arg9: f32):
      "linalg.yield"(%arg8) : (f32) -> ()
    }) : (f32, tensor<2x16xf32>) -> tensor<2x16xf32>
    %11 = "linalg.matmul"(%7, %5, %10) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg5: f32, %arg6: f32, %arg7: f32):
      %15 = "arith.mulf"(%arg5, %arg6) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %16 = "arith.addf"(%arg7, %15) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%16) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<16x128xf32>, tensor<2x16xf32>) -> tensor<2x16xf32>
    %12 = "tensor.empty"() : () -> tensor<2x16xf16>
    %13 = "linalg.generic"(%11, %12) <{indexing_maps = [#map, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg3: f32, %arg4: f16):
      %14 = "arith.truncf"(%arg3) : (f32) -> f16
      "linalg.yield"(%14) : (f16) -> ()
    }) : (tensor<2x16xf32>, tensor<2x16xf16>) -> tensor<2x16xf16>
    "func.return"(%13) : (tensor<2x16xf16>) -> ()
  }) : () -> ()
}) : () -> ()

