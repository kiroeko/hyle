#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
#map7 = affine_map<(d0, d1, d2) -> (d0, d1, d2)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg49: tensor<2x17xi32>, %arg50: tensor<2xi32>):
    %63 = "tensor.empty"() : () -> tensor<2x17xi32>
    %64:2 = "iree_linalg_ext.scan"(%arg49, %63, %arg50) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg51: i32, %arg52: i32):
      %65 = "arith.addi"(%arg51, %arg52) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%65) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%64#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg45: tensor<2x17xi32>, %arg46: tensor<2xi32>):
    %60 = "tensor.empty"() : () -> tensor<2x17xi32>
    %61:2 = "iree_linalg_ext.scan"(%arg45, %60, %arg46) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg47: i32, %arg48: i32):
      %62 = "arith.addi"(%arg47, %arg48) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%62) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%61#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x1xf32>, tensor<1x1xf32>) -> tensor<2x128xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg30: tensor<2x128xi8>, %arg31: tensor<128x128xi8>, %arg32: tensor<2x1xf32>, %arg33: tensor<1x1xf32>):
    %42 = "flow.tensor.bitcast"(%arg30) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %43 = "flow.tensor.bitcast"(%arg31) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %44 = "tensor.cast"(%arg32) : (tensor<2x1xf32>) -> tensor<2x1xf32>
    %45 = "tensor.cast"(%arg33) : (tensor<1x1xf32>) -> tensor<1x1xf32>
    %46 = "tensor.empty"() : () -> tensor<2x128xf32>
    %47 = "tensor.empty"() : () -> tensor<128x128xf32>
    %48 = "linalg.generic"(%42, %44, %46) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg42: f8E4M3FN, %arg43: f32, %arg44: f32):
      %58 = "arith.extf"(%arg42) : (f8E4M3FN) -> f32
      %59 = "arith.mulf"(%58, %arg43) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%59) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x1xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %49 = "linalg.generic"(%43, %45, %47) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg39: f8E4M3FN, %arg40: f32, %arg41: f32):
      %56 = "arith.extf"(%arg39) : (f8E4M3FN) -> f32
      %57 = "arith.mulf"(%56, %arg40) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%57) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<1x1xf32>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %50 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %51 = "tensor.empty"() : () -> tensor<2x128xf32>
    %52 = "linalg.fill"(%50, %51) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg37: f32, %arg38: f32):
      "linalg.yield"(%arg37) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %53 = "linalg.matmul"(%48, %49, %52) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg34: f32, %arg35: f32, %arg36: f32):
      %54 = "arith.mulf"(%arg34, %arg35) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %55 = "arith.addf"(%arg36, %54) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%55) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%53) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x4xi8>, tensor<128x4xi8>) -> tensor<2x128xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg15: tensor<2x128xi8>, %arg16: tensor<128x128xi8>, %arg17: tensor<2x4xi8>, %arg18: tensor<128x4xi8>):
    %22 = "flow.tensor.bitcast"(%arg15) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %23 = "flow.tensor.bitcast"(%arg16) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %24 = "flow.tensor.bitcast"(%arg17) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x4xi8>) -> tensor<2x4xf8E8M0FNU>
    %25 = "flow.tensor.bitcast"(%arg18) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x4xi8>) -> tensor<128x4xf8E8M0FNU>
    %26 = "tensor.empty"() : () -> tensor<2x128xf32>
    %27 = "tensor.empty"() : () -> tensor<128x128xf32>
    %28 = "linalg.generic"(%22, %24, %26) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f8E8M0FNU, %arg29: f32):
      %39 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %40 = "arith.extf"(%arg28) : (f8E8M0FNU) -> f32
      %41 = "arith.mulf"(%39, %40) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%41) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x4xf8E8M0FNU>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %29 = "linalg.generic"(%23, %25, %27) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f8E8M0FNU, %arg26: f32):
      %36 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %37 = "arith.extf"(%arg25) : (f8E8M0FNU) -> f32
      %38 = "arith.mulf"(%36, %37) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%38) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<128x4xf8E8M0FNU>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %30 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %31 = "tensor.empty"() : () -> tensor<2x128xf32>
    %32 = "linalg.fill"(%30, %31) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %33 = "linalg.matmul"(%28, %29, %32) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %34 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %35 = "arith.addf"(%arg21, %34) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%35) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%33) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xf16>, tensor<16x64xi8>, tensor<16x4xi8>) -> tensor<2x16xf16>, sym_name = "fp4_ue8_matmul"}> ({
  ^bb0(%arg0: tensor<2x128xf16>, %arg1: tensor<16x64xi8>, %arg2: tensor<16x4xi8>):
    %0 = "tensor.expand_shape"(%arg1) <{reassociation = [[0], [1, 2]], static_output_shape = array<i64: 16, 4, 16>}> : (tensor<16x64xi8>) -> tensor<16x4x16xi8>
    %1 = "flow.tensor.bitcast"(%0) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<16x4x16xi8>) -> tensor<16x4x32xi4>
    %2 = "flow.tensor.bitcast"(%arg2) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<16x4xi8>) -> tensor<16x4xf8E8M0FNU>
    %3 = "tensor.empty"() : () -> tensor<16x4x32xf32>
    %4 = "linalg.generic"(%1, %2, %3) <{indexing_maps = [#map7, #map5, #map7], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: i4, %arg13: f8E8M0FNU, %arg14: f32):
      %18 = "arith.bitcast"(%arg12) : (i4) -> f4E2M1FN
      %19 = "arith.extf"(%18) : (f4E2M1FN) -> f32
      %20 = "arith.extf"(%arg13) : (f8E8M0FNU) -> f32
      %21 = "arith.mulf"(%19, %20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%21) : (f32) -> ()
    }) : (tensor<16x4x32xi4>, tensor<16x4xf8E8M0FNU>, tensor<16x4x32xf32>) -> tensor<16x4x32xf32>
    %5 = "tensor.collapse_shape"(%4) <{reassociation = [[0], [1, 2]]}> : (tensor<16x4x32xf32>) -> tensor<16x128xf32>
    %6 = "tensor.empty"() : () -> tensor<2x128xf32>
    %7 = "linalg.generic"(%arg0, %6) <{indexing_maps = [#map, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg10: f16, %arg11: f32):
      %17 = "arith.extf"(%arg10) : (f16) -> f32
      "linalg.yield"(%17) : (f32) -> ()
    }) : (tensor<2x128xf16>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %8 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %9 = "tensor.empty"() : () -> tensor<2x16xf32>
    %10 = "linalg.fill"(%8, %9) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg8: f32, %arg9: f32):
      "linalg.yield"(%arg8) : (f32) -> ()
    }) : (f32, tensor<2x16xf32>) -> tensor<2x16xf32>
    %11 = "linalg.matmul"(%7, %5, %10) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg5: f32, %arg6: f32, %arg7: f32):
      %15 = "arith.mulf"(%arg5, %arg6) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %16 = "arith.addf"(%arg7, %15) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%16) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<16x128xf32>, tensor<2x16xf32>) -> tensor<2x16xf32>
    %12 = "tensor.empty"() : () -> tensor<2x16xf16>
    %13 = "linalg.generic"(%11, %12) <{indexing_maps = [#map, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg3: f32, %arg4: f16):
      %14 = "arith.truncf"(%arg3) : (f32) -> f16
      "linalg.yield"(%14) : (f16) -> ()
    }) : (tensor<2x16xf32>, tensor<2x16xf16>) -> tensor<2x16xf16>
    "func.return"(%13) : (tensor<2x16xf16>) -> ()
  }) : () -> ()
}) : () -> ()

