#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
#map7 = affine_map<(d0, d1, d2) -> (d0, d1, d2)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg49: tensor<2x17xi32>, %arg50: tensor<2xi32>):
    %85 = "tensor.empty"() : () -> tensor<2x17xi32>
    %86:2 = "iree_linalg_ext.scan"(%arg49, %85, %arg50) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg51: i32, %arg52: i32):
      %87 = "arith.addi"(%arg51, %arg52) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%87) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%86#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg45: tensor<2x17xi32>, %arg46: tensor<2xi32>):
    %82 = "tensor.empty"() : () -> tensor<2x17xi32>
    %83:2 = "iree_linalg_ext.scan"(%arg45, %82, %arg46) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg47: i32, %arg48: i32):
      %84 = "arith.addi"(%arg47, %arg48) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%84) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%83#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x1xf32>, tensor<1x1xf32>) -> tensor<2x128xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg30: tensor<2x128xi8>, %arg31: tensor<128x128xi8>, %arg32: tensor<2x1xf32>, %arg33: tensor<1x1xf32>):
    %66 = "flow.tensor.bitcast"(%arg30) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %67 = "flow.tensor.bitcast"(%arg31) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %68 = "tensor.empty"() : () -> tensor<2x128xf32>
    %69 = "tensor.empty"() : () -> tensor<128x128xf32>
    %70 = "linalg.generic"(%66, %arg32, %68) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg42: f8E4M3FN, %arg43: f32, %arg44: f32):
      %80 = "arith.extf"(%arg42) : (f8E4M3FN) -> f32
      %81 = "arith.mulf"(%80, %arg43) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%81) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x1xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %71 = "linalg.generic"(%67, %arg33, %69) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg39: f8E4M3FN, %arg40: f32, %arg41: f32):
      %78 = "arith.extf"(%arg39) : (f8E4M3FN) -> f32
      %79 = "arith.mulf"(%78, %arg40) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%79) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<1x1xf32>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %72 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %73 = "tensor.empty"() : () -> tensor<2x128xf32>
    %74 = "linalg.fill"(%72, %73) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg37: f32, %arg38: f32):
      "linalg.yield"(%arg37) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %75 = "linalg.matmul"(%70, %71, %74) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg34: f32, %arg35: f32, %arg36: f32):
      %76 = "arith.mulf"(%arg34, %arg35) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %77 = "arith.addf"(%arg36, %76) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%77) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%75) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x4xi8>, tensor<128x4xi8>) -> tensor<2x128xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg15: tensor<2x128xi8>, %arg16: tensor<128x128xi8>, %arg17: tensor<2x4xi8>, %arg18: tensor<128x4xi8>):
    %30 = "flow.tensor.bitcast"(%arg15) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %31 = "flow.tensor.bitcast"(%arg16) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %32 = "flow.tensor.bitcast"(%arg17) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x4xi8>) -> tensor<2x4xf8E8M0FNU>
    %33 = "flow.tensor.bitcast"(%arg18) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x4xi8>) -> tensor<128x4xf8E8M0FNU>
    %34 = "tensor.empty"() : () -> tensor<2x128xf32>
    %35 = "tensor.empty"() : () -> tensor<128x128xf32>
    %36 = "linalg.generic"(%30, %32, %34) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f8E8M0FNU, %arg29: f32):
      %55 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %56 = "arith.bitcast"(%arg28) : (f8E8M0FNU) -> i8
      %57 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %58 = "arith.extui"(%56) : (i8) -> i32
      %59 = "arith.shli"(%58, %57) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %60 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %61 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %62 = "arith.cmpi"(%56, %60) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %63 = "arith.select"(%62, %61, %59) : (i1, i32, i32) -> i32
      %64 = "arith.bitcast"(%63) : (i32) -> f32
      %65 = "arith.mulf"(%55, %64) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%65) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x4xf8E8M0FNU>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %37 = "linalg.generic"(%31, %33, %35) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f8E8M0FNU, %arg26: f32):
      %44 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %45 = "arith.bitcast"(%arg25) : (f8E8M0FNU) -> i8
      %46 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %47 = "arith.extui"(%45) : (i8) -> i32
      %48 = "arith.shli"(%47, %46) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %49 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %50 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %51 = "arith.cmpi"(%45, %49) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %52 = "arith.select"(%51, %50, %48) : (i1, i32, i32) -> i32
      %53 = "arith.bitcast"(%52) : (i32) -> f32
      %54 = "arith.mulf"(%44, %53) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%54) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<128x4xf8E8M0FNU>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %38 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %39 = "tensor.empty"() : () -> tensor<2x128xf32>
    %40 = "linalg.fill"(%38, %39) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %41 = "linalg.matmul"(%36, %37, %40) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %42 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %43 = "arith.addf"(%arg21, %42) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%43) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%41) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xf16>, tensor<16x64xi8>, tensor<16x4xi8>) -> tensor<2x16xf16>, sym_name = "fp4_ue8_matmul"}> ({
  ^bb0(%arg0: tensor<2x128xf16>, %arg1: tensor<16x64xi8>, %arg2: tensor<16x4xi8>):
    %0 = "tensor.expand_shape"(%arg1) <{reassociation = [[0], [1, 2]], static_output_shape = array<i64: 16, 4, 16>}> : (tensor<16x64xi8>) -> tensor<16x4x16xi8>
    %1 = "flow.tensor.bitcast"(%0) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<16x4x16xi8>) -> tensor<16x4x32xi4>
    %2 = "flow.tensor.bitcast"(%arg2) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<16x4xi8>) -> tensor<16x4xf8E8M0FNU>
    %3 = "tensor.empty"() : () -> tensor<16x4x32xf32>
    %4 = "linalg.generic"(%1, %2, %3) <{indexing_maps = [#map7, #map5, #map7], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: i4, %arg13: f8E8M0FNU, %arg14: f32):
      %18 = "arith.bitcast"(%arg12) : (i4) -> f4E2M1FN
      %19 = "arith.extf"(%18) : (f4E2M1FN) -> f32
      %20 = "arith.bitcast"(%arg13) : (f8E8M0FNU) -> i8
      %21 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %22 = "arith.extui"(%20) : (i8) -> i32
      %23 = "arith.shli"(%22, %21) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %24 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %25 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %26 = "arith.cmpi"(%20, %24) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %27 = "arith.select"(%26, %25, %23) : (i1, i32, i32) -> i32
      %28 = "arith.bitcast"(%27) : (i32) -> f32
      %29 = "arith.mulf"(%19, %28) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%29) : (f32) -> ()
    }) : (tensor<16x4x32xi4>, tensor<16x4xf8E8M0FNU>, tensor<16x4x32xf32>) -> tensor<16x4x32xf32>
    %5 = "tensor.collapse_shape"(%4) <{reassociation = [[0], [1, 2]]}> : (tensor<16x4x32xf32>) -> tensor<16x128xf32>
    %6 = "tensor.empty"() : () -> tensor<2x128xf32>
    %7 = "linalg.generic"(%arg0, %6) <{indexing_maps = [#map, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg10: f16, %arg11: f32):
      %17 = "arith.extf"(%arg10) : (f16) -> f32
      "linalg.yield"(%17) : (f32) -> ()
    }) : (tensor<2x128xf16>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %8 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %9 = "tensor.empty"() : () -> tensor<2x16xf32>
    %10 = "linalg.fill"(%8, %9) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg8: f32, %arg9: f32):
      "linalg.yield"(%arg8) : (f32) -> ()
    }) : (f32, tensor<2x16xf32>) -> tensor<2x16xf32>
    %11 = "linalg.matmul"(%7, %5, %10) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg5: f32, %arg6: f32, %arg7: f32):
      %15 = "arith.mulf"(%arg5, %arg6) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %16 = "arith.addf"(%arg7, %15) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%16) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<16x128xf32>, tensor<2x16xf32>) -> tensor<2x16xf32>
    %12 = "tensor.empty"() : () -> tensor<2x16xf16>
    %13 = "linalg.generic"(%11, %12) <{indexing_maps = [#map, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg3: f32, %arg4: f16):
      %14 = "arith.truncf"(%arg3) : (f32) -> f16
      "linalg.yield"(%14) : (f16) -> ()
    }) : (tensor<2x16xf32>, tensor<2x16xf16>) -> tensor<2x16xf16>
    "func.return"(%13) : (tensor<2x16xf16>) -> ()
  }) : () -> ()
}) : () -> ()

