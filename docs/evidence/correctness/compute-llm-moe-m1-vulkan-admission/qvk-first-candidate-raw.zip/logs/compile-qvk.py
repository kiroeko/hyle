import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
logs = Path('.scratch/validation/m1-vulkan-admission')
attempt = int(sys.argv[1])
argv = ['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-compile.exe',
        'C:/hv/qvk/bundle.mlir', '--iree-hal-target-device=vulkan',
        '--iree-vulkan-target=vp_android_baseline_2022',
        '--iree-vulkan-dispatch-abi=descriptors', '-o', 'C:/hv/qvk/bundle.vmfb']
if attempt >= 4:
    argv.append('--iree-vulkan-target-features=spirv:v1.3,cap:Shader,cap:Float16,cap:StorageBuffer16BitAccess,ext:SPV_KHR_16bit_storage')
if attempt == 6:
    argv.append('--iree-preprocessing-pass-pipeline=builtin.module(arith-expand{include-f8e8m0=true})')
    old = Path('C:/hv/qvk/bundle.vmfb')
    archived = Path('C:/hv/qvk/bundle-attempt5.vmfb')
    if not archived.exists():
        archived.write_bytes(old.read_bytes())
if attempt >= 7:
    argv[1] = 'C:/hv/qvk/bundle-llvm23.mlir'
if attempt >= 8:
    argv[1] = 'C:/hv/qvk/bundle-llvm23-f4.mlir'
if attempt >= 9:
    argv.append('--iree-preprocessing-pass-pipeline=builtin.module(iree-codegen-emulate-narrow-type)')
path = logs / f'bundle-compile-{attempt}.log'
assert not path.exists()
started = time.time()
with path.open('wb') as output:
    result = subprocess.run(argv, stdout=output, stderr=subprocess.STDOUT, timeout=240)
diagnostics = path.read_text(errors='replace')
qualified = result.returncode == 0 and 'error:' not in diagnostics.lower() and 'ERROR:' not in diagnostics
record = {'argv': argv, 'exit_code': result.returncode, 'qualified_compile':qualified,'elapsed_seconds': time.time()-started,
          'input_sha256': hashlib.sha256(Path(argv[1]).read_bytes()).hexdigest(),
          'recipe_sha256': hashlib.sha256(Path('C:/hv/qvk/bundle.mlir').read_bytes()).hexdigest()}
if qualified:
    record['output_sha256'] = hashlib.sha256(Path('C:/hv/qvk/bundle.vmfb').read_bytes()).hexdigest()
(logs / f'bundle-compile-{attempt}.json').write_bytes((json.dumps(record, indent=2)+'\n').encode())
print(json.dumps(record))
print(path.read_text(errors='replace')[:4500])
raise SystemExit(0 if qualified else 1)
