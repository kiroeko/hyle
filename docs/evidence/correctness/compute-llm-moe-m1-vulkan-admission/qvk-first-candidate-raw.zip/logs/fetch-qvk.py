import datetime
import hashlib
import json
from pathlib import Path
import tarfile
import urllib.request
import zipfile

logs = Path('.scratch/validation/m1-vulkan-admission')
pin = '6ef606b6fa3e12bd2c12d36a07463069eb71185f'
budget = json.loads((logs / 'budget.json').read_text())
deadline = datetime.datetime.fromisoformat(budget['deadline_utc'].replace('Z', '+00:00'))
root = Path('C:/hv')
marker = root / 'm1v-owner.txt'
expected = 'M1-V qualification only; canonical product: C:\\public\\project-hyle\\hyle\n'
if root.exists():
    assert marker.is_file() and marker.read_text() == expected, 'Existing short root is not this task'
else:
    root.mkdir()
    marker.write_text(expected)
download = root / 'downloads'
download.mkdir(exist_ok=True)
release = json.loads((logs / 'releases.json').read_text())[0]
assert release['target_commitish'] == pin
assets = [a for a in release['assets'] if
          a['name'].endswith('cp312-abi3-win_amd64.whl') or
          (a['name'].startswith('iree_base_runtime-') and a['name'].endswith('cp312-abi3-macosx_13_0_universal2.whl'))]
assert len(assets) == 3
items = [{'name': a['name'], 'url': a['browser_download_url'], 'sha256': a['digest'].removeprefix('sha256:')} for a in assets]
items.append({'name': 'iree-' + pin + '.tar.gz', 'url': 'https://codeload.github.com/iree-org/iree/tar.gz/' + pin})
records = []
for item in items:
    assert datetime.datetime.now(datetime.timezone.utc) < deadline
    target = download / item['name']
    assert target.parent.resolve() == download.resolve()
    if not target.exists():
        temporary = target.with_name(target.name + '.partial')
        print('DOWNLOAD', item['name'], flush=True)
        request = urllib.request.Request(item['url'], headers={'User-Agent': 'HYLE-QVK-source-qualification'})
        with urllib.request.urlopen(request, timeout=40) as incoming, temporary.open('wb') as outgoing:
            while chunk := incoming.read(1024 * 1024):
                assert datetime.datetime.now(datetime.timezone.utc) < deadline
                outgoing.write(chunk)
        temporary.replace(target)
    actual = hashlib.sha256(target.read_bytes()).hexdigest()
    assert 'sha256' not in item or actual == item['sha256'], item['name']
    records.append({**item, 'sha256': actual, 'bytes': target.stat().st_size, 'path': str(target)})
    (logs / 'downloads.json').write_bytes((json.dumps(records, indent=2) + '\n').encode())
    print('VERIFIED', item['name'], target.stat().st_size, flush=True)
    if target.suffix == '.whl':
        destination = root / ('tools-mac' if 'macosx' in target.name else 'tools-win')
        destination.mkdir(exist_ok=True)
        with zipfile.ZipFile(target) as archive:
            assert archive.testzip() is None
            for name in archive.namelist():
                assert (destination / name).resolve().is_relative_to(destination.resolve())
            archive.extractall(destination)
    else:
        destination = root / 'source'
        destination.mkdir(exist_ok=True)
        with tarfile.open(target) as archive:
            archive.extractall(destination, filter='data')
print('READY', str(root), flush=True)
