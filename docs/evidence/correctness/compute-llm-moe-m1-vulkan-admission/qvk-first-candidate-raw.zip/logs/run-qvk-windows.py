import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

ctypes.windll.kernel32.SetErrorMode(0x8003)
logs = Path('.scratch/validation/m1-vulkan-admission')
directory = Path('C:/hv/qvk')
manifest = json.loads((directory/'manifest.json').read_text())
original = json.loads((logs/'bundle-manifest.json.attempt1').read_text())
assert manifest['cases'] == original['cases']
attempt = int(sys.argv[1]) if len(sys.argv) > 1 else 5
suffix = '' if attempt == 5 else '-c'+str(attempt)
compile_record = json.loads((logs/f'bundle-compile-{attempt}.json').read_text())
assert compile_record['exit_code'] == 0
assert hashlib.sha256((directory/'bundle.vmfb').read_bytes()).hexdigest() == compile_record['output_sha256']
exe = 'C:/hv/tools-win/iree/_runtime_libs/iree-run-module.exe'
record = {'kind':'Q-VK Windows numeric qualification only', 'product_coverage_cells':0,
          'module_sha256':compile_record['output_sha256'], 'cases':[], 'status':'RUNNING'}
def save():
    (logs/('windows-numeric'+suffix+'.json')).write_bytes((json.dumps(record,indent=2,allow_nan=False)+'\n').encode())
assert not (logs/('windows-numeric'+suffix+'.json')).exists()
save()
for case in manifest['cases']:
    label = case['name']+'-'+str(case['variant'])
    output = directory/(label+suffix+'-actual.npy')
    assert not output.exists(), label
    argv = [exe,'--device=vulkan://GPU-e73765606f5dec196ee43dd3a2c81ef8','--module='+str(directory/'bundle.vmfb'),'--function='+case['name']]
    for input in case['inputs']:
        path = directory/input['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == input['sha256']
        argv.append('--input=@'+str(path))
    argv.append('--output=@'+str(output))
    log = logs/('windows-'+label+suffix+'.log')
    assert not log.exists()
    with log.open('wb') as stream:
        result = subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
    item = {'label':label,'argv':argv,'exit_code':result.returncode,'log':log.name}
    record['cases'].append(item)
    if result.returncode == 0:
        expected_path = directory/case['expected']
        assert hashlib.sha256(expected_path.read_bytes()).hexdigest() == case['expected_sha256']
        expected,actual = np.load(expected_path),np.load(output)
        item['shape'] = list(actual.shape)
        item['dtype'] = str(actual.dtype)
        error = float(np.max(np.abs(actual.astype(np.float64)-expected.astype(np.float64))))
        item['max_absolute_error'] = error if np.isfinite(error) else None
        item['nan_count'] = int(np.count_nonzero(np.isnan(actual)))
        item['infinite_count'] = int(np.count_nonzero(np.isinf(actual)))
        item['pass'] = actual.shape == expected.shape and actual.dtype == expected.dtype and np.array_equal(actual,expected)
        item['actual_sha256'] = hashlib.sha256(output.read_bytes()).hexdigest()
    else:
        item['pass'] = False
    save()
    print(label, item['pass'], item.get('max_absolute_error'), flush=True)
    if not item['pass']:
        record['status'] = 'FAIL'
        save()
        print(log.read_text(errors='replace')[-3000:],flush=True)
        raise SystemExit(1)
record['status'] = 'PASS'
save()
