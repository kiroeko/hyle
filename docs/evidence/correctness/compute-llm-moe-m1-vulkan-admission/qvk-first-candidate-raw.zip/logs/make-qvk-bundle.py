"""Q-VK standard-op composition. No HYLE mathematical implementation.

IREE 6ef606b6 sources: tests/e2e/linalg_ext_ops/scan.mlir,
tests/e2e/linalg/fp4_f32_conversion.mlir, and matmul/generate_code_mx.py.
Only tensor shapes, public parameters and standard-op composition are adapted.
"""
import hashlib
import json
from pathlib import Path
import numpy as np

logs = Path('.scratch/validation/m1-vulkan-admission')
directory = Path('C:/hv/qvk')
directory.mkdir(exist_ok=True)
functions = []
for name, inclusive in [('scan_inclusive', 'true'), ('scan_exclusive', 'false')]:
    functions.append(f'''func.func @{name}(%input: tensor<2x17xi32>, %initial: tensor<2xi32>) -> tensor<2x17xi32> {{
  %empty = tensor.empty() : tensor<2x17xi32>
  %result:2 = iree_linalg_ext.scan dimension(1) inclusive({inclusive})
      ins(%input : tensor<2x17xi32>) outs(%empty, %initial : tensor<2x17xi32>, tensor<2xi32>) {{
    ^bb0(%left: i32, %right: i32):
      %sum = arith.addi %left, %right : i32
      iree_linalg_ext.yield %sum : i32
  }} -> tensor<2x17xi32>, tensor<2xi32>
  return %result#0 : tensor<2x17xi32>
}}
''')

for name, scale_type, group in [('fp8_f32_scale', 'f32', 128), ('fp8_ue8_scale', 'f8E8M0FNU', 32)]:
    scale_storage = 'f32' if scale_type == 'f32' else 'i8'
    lhs_scale_shape = f'2x{128 // group}'
    rhs_scale_shape = '1x1' if scale_type == 'f32' else '128x4'
    rhs_scale_map = '(d0 floordiv 128, d1 floordiv 128)' if scale_type == 'f32' else '(d0, d1 floordiv 32)'
    scale_import = ''
    if scale_type != 'f32':
        scale_import = f'''  %ls = flow.tensor.bitcast %lhs_scale : tensor<{lhs_scale_shape}xi8> -> tensor<{lhs_scale_shape}x{scale_type}>
  %rs = flow.tensor.bitcast %rhs_scale : tensor<{rhs_scale_shape}xi8> -> tensor<{rhs_scale_shape}x{scale_type}>
'''
    else:
        scale_import = '  %ls = tensor.cast %lhs_scale : tensor<2x1xf32> to tensor<2x1xf32>\n  %rs = tensor.cast %rhs_scale : tensor<1x1xf32> to tensor<1x1xf32>\n'
    if scale_type == 'f32':
        scalar = '''      %wide = arith.extf %value : f8E4M3FN to f32
      %scaled = arith.mulf %wide, %scale : f32'''
    else:
        scalar = '''      %wide = arith.extf %value : f8E4M3FN to f32
      %factor = arith.extf %scale : f8E8M0FNU to f32
      %scaled = arith.mulf %wide, %factor : f32'''
    functions.append(f'''func.func @{name}(%lhs: tensor<2x128xi8>, %rhs: tensor<128x128xi8>, %lhs_scale: tensor<{lhs_scale_shape}x{scale_storage}>, %rhs_scale: tensor<{rhs_scale_shape}x{scale_storage}>) -> tensor<2x128xf32> {{
  %l = flow.tensor.bitcast %lhs : tensor<2x128xi8> -> tensor<2x128xf8E4M3FN>
  %r = flow.tensor.bitcast %rhs : tensor<128x128xi8> -> tensor<128x128xf8E4M3FN>
{scale_import}  %le = tensor.empty() : tensor<2x128xf32>
  %re = tensor.empty() : tensor<128x128xf32>
  %lw = linalg.generic {{indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1 floordiv {group})>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}}
      ins(%l, %ls : tensor<2x128xf8E4M3FN>, tensor<{lhs_scale_shape}x{scale_type}>) outs(%le : tensor<2x128xf32>) {{
    ^bb0(%value: f8E4M3FN, %scale: {scale_type}, %unused: f32):
{scalar}
      linalg.yield %scaled : f32
  }} -> tensor<2x128xf32>
  %rw = linalg.generic {{indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->{rhs_scale_map}>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}}
      ins(%r, %rs : tensor<128x128xf8E4M3FN>, tensor<{rhs_scale_shape}x{scale_type}>) outs(%re : tensor<128x128xf32>) {{
    ^bb0(%value: f8E4M3FN, %scale: {scale_type}, %unused: f32):
{scalar}
      linalg.yield %scaled : f32
  }} -> tensor<128x128xf32>
  %zero = arith.constant 0.0 : f32
  %empty = tensor.empty() : tensor<2x128xf32>
  %init = linalg.fill ins(%zero : f32) outs(%empty : tensor<2x128xf32>) -> tensor<2x128xf32>
  %result = linalg.matmul indexing_maps = [affine_map<(d0,d1,d2)->(d0,d2)>,affine_map<(d0,d1,d2)->(d1,d2)>,affine_map<(d0,d1,d2)->(d0,d1)>] ins(%lw, %rw : tensor<2x128xf32>, tensor<128x128xf32>) outs(%init : tensor<2x128xf32>) -> tensor<2x128xf32>
  return %result : tensor<2x128xf32>
}}
''')

functions.append('''func.func @fp4_ue8_matmul(%lhs: tensor<2x128xf16>, %rhs: tensor<16x64xi8>, %scale: tensor<16x4xi8>) -> tensor<2x16xf16> {
  %rbytes = tensor.expand_shape %rhs [[0], [1,2]] output_shape [16,4,16] : tensor<16x64xi8> into tensor<16x4x16xi8>
  %r = flow.tensor.bitcast %rbytes : tensor<16x4x16xi8> -> tensor<16x4x32xi4>
  %s = flow.tensor.bitcast %scale : tensor<16x4xi8> -> tensor<16x4xf8E8M0FNU>
  %re = tensor.empty() : tensor<16x4x32xf32>
  %rw3 = linalg.generic {indexing_maps = [affine_map<(d0,d1,d2)->(d0,d1,d2)>, affine_map<(d0,d1,d2)->(d0,d1)>, affine_map<(d0,d1,d2)->(d0,d1,d2)>], iterator_types = ["parallel","parallel","parallel"]}
      ins(%r, %s : tensor<16x4x32xi4>, tensor<16x4xf8E8M0FNU>) outs(%re : tensor<16x4x32xf32>) {
    ^bb0(%bits: i4, %factor: f8E8M0FNU, %unused: f32):
      %value = arith.bitcast %bits : i4 to f4E2M1FN
      %wide = arith.extf %value : f4E2M1FN to f32
      %scale32 = arith.extf %factor : f8E8M0FNU to f32
      %scaled = arith.mulf %wide, %scale32 : f32
      linalg.yield %scaled : f32
  } -> tensor<16x4x32xf32>
  %rw = tensor.collapse_shape %rw3 [[0],[1,2]] : tensor<16x4x32xf32> into tensor<16x128xf32>
  %le = tensor.empty() : tensor<2x128xf32>
  %lw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>,affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%lhs : tensor<2x128xf16>) outs(%le : tensor<2x128xf32>) {
    ^bb0(%value: f16, %unused: f32):
      %wide = arith.extf %value : f16 to f32
      linalg.yield %wide : f32
  } -> tensor<2x128xf32>
  %zero = arith.constant 0.0 : f32
  %empty = tensor.empty() : tensor<2x16xf32>
  %init = linalg.fill ins(%zero : f32) outs(%empty : tensor<2x16xf32>) -> tensor<2x16xf32>
  %wide_result = linalg.matmul indexing_maps = [affine_map<(d0,d1,d2)->(d0,d2)>,affine_map<(d0,d1,d2)->(d1,d2)>,affine_map<(d0,d1,d2)->(d0,d1)>] ins(%lw, %rw : tensor<2x128xf32>, tensor<16x128xf32>) outs(%init : tensor<2x16xf32>) -> tensor<2x16xf32>
  %out = tensor.empty() : tensor<2x16xf16>
  %result = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>,affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%wide_result : tensor<2x16xf32>) outs(%out : tensor<2x16xf16>) {
    ^bb0(%value: f32, %unused: f16):
      %narrow = arith.truncf %value : f32 to f16
      linalg.yield %narrow : f16
  } -> tensor<2x16xf16>
  return %result : tensor<2x16xf16>
}
''')
module = ('module {\n' + '\n'.join(functions) + '}\n').encode()
(directory / 'bundle.mlir').write_bytes(module)
(logs / 'bundle.mlir').write_bytes(module)
cases = []
def add_case(name, inputs, expected, variant):
    files = []
    for index, value in enumerate(inputs):
        path = directory / f'{name}-{variant}-input{index}.npy'
        np.save(path, value)
        files.append({'file':path.name, 'bytes':value.nbytes, 'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    path = directory / f'{name}-{variant}-expected.npy'
    np.save(path, expected)
    cases.append({'name':name, 'variant':variant, 'inputs':files, 'expected':path.name,
                  'expected_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                  'atol':0, 'rtol':0})

# Exact binary rational values keep this admission oracle independent from
# provider codecs and avoid attributing quantization error to arithmetic.
f8_bits = np.array([0,0x30,0x38,0x40,0x48,0xb8,0xc0], dtype=np.uint8)
f8_values = np.array([0,.5,1,2,4,-1,-2], dtype=np.float32)
f4_values = np.array([0,.5,1,1.5,2,3,4,6,0,-.5,-1,-1.5,-2,-3,-4,-6], dtype=np.float32)
for variant in range(2):
    scan = ((np.arange(34).reshape(2,17)*3+variant)%11-5).astype(np.int32)
    initial = np.array([3,-7], dtype=np.int32)
    # Upstream inclusive scan starts with the first input; exclusive uses init.
    inclusive = np.cumsum(scan, axis=1, dtype=np.int32)
    exclusive = np.concatenate([initial[:,None], initial[:,None] + inclusive[:,:-1]], axis=1)
    add_case('scan_inclusive', [scan, initial], inclusive, variant)
    add_case('scan_exclusive', [scan, initial], exclusive, variant)
    ai = ((np.arange(256)*3+variant)%7).reshape(2,128)
    wi = ((np.arange(16384)*5+variant)%7).reshape(128,128)
    ab, wb = f8_bits[ai].view(np.int8), f8_bits[wi].view(np.int8)
    als = np.array([[.5],[2]], dtype=np.float32)
    wls = np.array([[.25]], dtype=np.float32)
    expected = (f8_values[ai].astype(np.float64)*als) @ (f8_values[wi].astype(np.float64)*wls).T
    add_case('fp8_f32_scale', [ab,wb,als,wls], expected.astype(np.float32), variant)
    ase = ((np.arange(8).reshape(2,4)+variant)%5+125).astype(np.uint8)
    wse = ((np.arange(512).reshape(128,4)+variant)%5+125).astype(np.uint8)
    av = f8_values[ai].astype(np.float64)*np.repeat(np.exp2(ase.astype(np.int32)-127),32,axis=1)
    wv = f8_values[wi].astype(np.float64)*np.repeat(np.exp2(wse.astype(np.int32)-127),32,axis=1)
    add_case('fp8_ue8_scale', [ab,wb,ase.view(np.int8),wse.view(np.int8)], (av@wv.T).astype(np.float32), variant)
    codes = ((np.arange(2048)*3+variant)%16).reshape(16,128).astype(np.uint8)
    packed = (codes[:,::2] | (codes[:,1::2]<<4)).view(np.int8)
    scales = ((np.arange(64).reshape(16,4)+variant)%5+125).astype(np.uint8)
    activation = (((np.arange(256)*7+variant)%17-8)/8).reshape(2,128).astype(np.float16)
    weight = f4_values[codes].astype(np.float64)*np.repeat(np.exp2(scales.astype(np.int32)-127),32,axis=1)
    add_case('fp4_ue8_matmul', [activation,packed,scales.view(np.int8)], (activation.astype(np.float64)@weight.T).astype(np.float16), variant)
manifest = {'scope':'Q-VK candidate qualification only; no product coverage', 'pin':'6ef606b6fa3e12bd2c12d36a07463069eb71185f',
            'module_sha256':hashlib.sha256(module).hexdigest(),'cases':cases,
            'numerical_scope':'exact binary rational values; no NaN/rounding/full model coverage claim',
            'sources':['tests/e2e/linalg_ext_ops/scan.mlir','tests/e2e/linalg/fp4_f32_conversion.mlir','tests/e2e/matmul/generate_code_mx.py']}
(directory/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
(logs/'bundle-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(len(cases), 'cases; standard ops only; expected values frozen before compile/run')
