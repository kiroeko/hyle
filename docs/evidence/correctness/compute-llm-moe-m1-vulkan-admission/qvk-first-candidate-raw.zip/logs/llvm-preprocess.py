import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ctypes.windll.kernel32.SetErrorMode(0x8003)
logs=Path('.scratch/validation/m1-vulkan-admission')
root=Path('C:/hv/llvm23')
assert Path('C:/hv/m1v-owner.txt').read_text().startswith('M1-V qualification only;')
resume = '--resume-z3' in sys.argv
if not resume:
    assert not root.exists()
    root.mkdir()
records=json.loads((logs/'llvm-preprocess-commands.json').read_text()) if resume else []
def run(label,argv,timeout=60):
    path=logs/(label+'.log');assert not path.exists()
    result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
    path.write_bytes(result.stdout)
    records.append({'label':label,'argv':argv,'exit_code':result.returncode,'log':path.name})
    (logs/'llvm-preprocess-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,result.returncode,flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-3000:]);raise SystemExit(result.returncode)
    return result.stdout
if not resume:
    for name in ['libllvm23','libmlir-23','mlir-23-tools']:
        run('extract-'+name,['wsl','-e','dpkg-deb','-x','/mnt/c/hv/downloads/'+name+'.deb','/mnt/c/hv/llvm23'])
else:
    packages=list(Path('C:/hv/downloads').glob('libz3-4_*.deb'))
    assert len(packages)==1
    package=packages[0]
    (logs/'z3-download.json').write_text(json.dumps({'file':package.name,'sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'bytes':package.stat().st_size,'origin':'Ubuntu noble/universe via configured authenticated apt package index'},indent=2)+'\n')
    run('extract-z3',['wsl','-e','dpkg-deb','-x','/mnt/c/hv/downloads/'+package.name,'/mnt/c/hv/llvm23'])
tool=['wsl','-e','env','LD_LIBRARY_PATH=/mnt/c/hv/llvm23/usr/lib/x86_64-linux-gnu:/mnt/c/hv/llvm23/usr/lib/llvm-23/lib',
      '/mnt/c/hv/llvm23/usr/lib/llvm-23/bin/mlir-opt']
print(run('mlir-opt-version'+('-z3' if resume else ''),tool+['--version']).decode(),flush=True)
run('iree-print-generic',['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-opt.exe',
                        'C:/hv/qvk/bundle.mlir','--mlir-print-op-generic','-o','C:/hv/qvk/bundle-generic.mlir'])
run('llvm-ue8-expand',tool+['/mnt/c/hv/qvk/bundle-generic.mlir','--allow-unregistered-dialect',
                           '--pass-pipeline=builtin.module(arith-expand{include-f8e8m0=true})',
                           '--mlir-print-op-generic','-o','/mnt/c/hv/qvk/bundle-llvm23.mlir'])
for path in ['bundle.mlir','bundle-generic.mlir','bundle-llvm23.mlir']:
    data=Path('C:/hv/qvk',path).read_bytes()
    print(path,hashlib.sha256(data).hexdigest(),flush=True)
