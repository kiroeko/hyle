module {
func.func @scan_inclusive(%input: tensor<2x17xi32>, %initial: tensor<2xi32>) -> tensor<2x17xi32> {
  %empty = tensor.empty() : tensor<2x17xi32>
  %result:2 = iree_linalg_ext.scan dimension(1) inclusive(true)
      ins(%input : tensor<2x17xi32>) outs(%empty, %initial : tensor<2x17xi32>, tensor<2xi32>) {
    ^bb0(%left: i32, %right: i32):
      %sum = arith.addi %left, %right : i32
      iree_linalg_ext.yield %sum : i32
  } -> tensor<2x17xi32>, tensor<2xi32>
  return %result#0 : tensor<2x17xi32>
}

func.func @scan_exclusive(%input: tensor<2x17xi32>, %initial: tensor<2xi32>) -> tensor<2x17xi32> {
  %empty = tensor.empty() : tensor<2x17xi32>
  %result:2 = iree_linalg_ext.scan dimension(1) inclusive(false)
      ins(%input : tensor<2x17xi32>) outs(%empty, %initial : tensor<2x17xi32>, tensor<2xi32>) {
    ^bb0(%left: i32, %right: i32):
      %sum = arith.addi %left, %right : i32
      iree_linalg_ext.yield %sum : i32
  } -> tensor<2x17xi32>, tensor<2xi32>
  return %result#0 : tensor<2x17xi32>
}

func.func @fp8_f32_scale(%lhs: tensor<2x128xi8>, %rhs: tensor<128x128xi8>, %lhs_scale: tensor<2x1xf32>, %rhs_scale: tensor<1x1xf32>) -> tensor<2x128xf32> {
  %l = flow.tensor.bitcast %lhs : tensor<2x128xi8> -> tensor<2x128xf8E4M3FN>
  %r = flow.tensor.bitcast %rhs : tensor<128x128xi8> -> tensor<128x128xf8E4M3FN>
  %ls = tensor.cast %lhs_scale : tensor<2x1xf32> to tensor<2x1xf32>
  %rs = tensor.cast %rhs_scale : tensor<1x1xf32> to tensor<1x1xf32>
  %le = tensor.empty() : tensor<2x128xf32>
  %re = tensor.empty() : tensor<128x128xf32>
  %lw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1 floordiv 128)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%l, %ls : tensor<2x128xf8E4M3FN>, tensor<2x1xf32>) outs(%le : tensor<2x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f32, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %scaled = arith.mulf %wide, %scale : f32
      linalg.yield %scaled : f32
  } -> tensor<2x128xf32>
  %rw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0 floordiv 128, d1 floordiv 128)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%r, %rs : tensor<128x128xf8E4M3FN>, tensor<1x1xf32>) outs(%re : tensor<128x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f32, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %scaled = arith.mulf %wide, %scale : f32
      linalg.yield %scaled : f32
  } -> tensor<128x128xf32>
  %zero = arith.constant 0.0 : f32
  %empty = tensor.empty() : tensor<2x128xf32>
  %init = linalg.fill ins(%zero : f32) outs(%empty : tensor<2x128xf32>) -> tensor<2x128xf32>
  %result = linalg.matmul indexing_maps = [affine_map<(d0,d1,d2)->(d0,d2)>,affine_map<(d0,d1,d2)->(d1,d2)>,affine_map<(d0,d1,d2)->(d0,d1)>] ins(%lw, %rw : tensor<2x128xf32>, tensor<128x128xf32>) outs(%init : tensor<2x128xf32>) -> tensor<2x128xf32>
  return %result : tensor<2x128xf32>
}

func.func @fp8_ue8_scale(%lhs: tensor<2x128xi8>, %rhs: tensor<128x128xi8>, %lhs_scale: tensor<2x4xi8>, %rhs_scale: tensor<128x4xi8>) -> tensor<2x128xf32> {
  %l = flow.tensor.bitcast %lhs : tensor<2x128xi8> -> tensor<2x128xf8E4M3FN>
  %r = flow.tensor.bitcast %rhs : tensor<128x128xi8> -> tensor<128x128xf8E4M3FN>
  %ls = flow.tensor.bitcast %lhs_scale : tensor<2x4xi8> -> tensor<2x4xf8E8M0FNU>
  %rs = flow.tensor.bitcast %rhs_scale : tensor<128x4xi8> -> tensor<128x4xf8E8M0FNU>
  %le = tensor.empty() : tensor<2x128xf32>
  %re = tensor.empty() : tensor<128x128xf32>
  %lw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1 floordiv 32)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%l, %ls : tensor<2x128xf8E4M3FN>, tensor<2x4xf8E8M0FNU>) outs(%le : tensor<2x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f8E8M0FNU, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %factor = arith.extf %scale : f8E8M0FNU to f32
      %scaled = arith.mulf %wide, %factor : f32
      linalg.yield %scaled : f32
  } -> tensor<2x128xf32>
  %rw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0, d1 floordiv 32)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%r, %rs : tensor<128x128xf8E4M3FN>, tensor<128x4xf8E8M0FNU>) outs(%re : tensor<128x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f8E8M0FNU, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %factor = arith.extf %scale : f8E8M0FNU to f32
      %scaled = arith.mulf %wide, %factor : f32
      linalg.yield %scaled : f32
  } -> tensor<128x128xf32>
  %zero = arith.constant 0.0 : f32
  %empty = tensor.empty() : tensor<2x128xf32>
  %init = linalg.fill ins(%zero : f32) outs(%empty : tensor<2x128xf32>) -> tensor<2x128xf32>
  %result = linalg.matmul indexing_maps = [affine_map<(d0,d1,d2)->(d0,d2)>,affine_map<(d0,d1,d2)->(d1,d2)>,affine_map<(d0,d1,d2)->(d0,d1)>] ins(%lw, %rw : tensor<2x128xf32>, tensor<128x128xf32>) outs(%init : tensor<2x128xf32>) -> tensor<2x128xf32>
  return %result : tensor<2x128xf32>
}

func.func @fp4_ue8_matmul(%lhs: tensor<2x128xf16>, %rhs: tensor<16x64xi8>, %scale: tensor<16x4xi8>) -> tensor<2x16xf16> {
  %rbytes = tensor.expand_shape %rhs [[0], [1,2]] output_shape [16,4,16] : tensor<16x64xi8> into tensor<16x4x16xi8>
  %r = flow.tensor.bitcast %rbytes : tensor<16x4x16xi8> -> tensor<16x4x32xi4>
  %s = flow.tensor.bitcast %scale : tensor<16x4xi8> -> tensor<16x4xf8E8M0FNU>
  %re = tensor.empty() : tensor<16x4x32xf32>
  %rw3 = linalg.generic {indexing_maps = [affine_map<(d0,d1,d2)->(d0,d1,d2)>, affine_map<(d0,d1,d2)->(d0,d1)>, affine_map<(d0,d1,d2)->(d0,d1,d2)>], iterator_types = ["parallel","parallel","parallel"]}
      ins(%r, %s : tensor<16x4x32xi4>, tensor<16x4xf8E8M0FNU>) outs(%re : tensor<16x4x32xf32>) {
    ^bb0(%bits: i4, %factor: f8E8M0FNU, %unused: f32):
      %value = arith.bitcast %bits : i4 to f4E2M1FN
      %wide = arith.extf %value : f4E2M1FN to f32
      %scale32 = arith.extf %factor : f8E8M0FNU to f32
      %scaled = arith.mulf %wide, %scale32 : f32
      linalg.yield %scaled : f32
  } -> tensor<16x4x32xf32>
  %rw = tensor.collapse_shape %rw3 [[0],[1,2]] : tensor<16x4x32xf32> into tensor<16x128xf32>
  %le = tensor.empty() : tensor<2x128xf32>
  %lw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>,affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%lhs : tensor<2x128xf16>) outs(%le : tensor<2x128xf32>) {
    ^bb0(%value: f16, %unused: f32):
      %wide = arith.extf %value : f16 to f32
      linalg.yield %wide : f32
  } -> tensor<2x128xf32>
  %zero = arith.constant 0.0 : f32
  %empty = tensor.empty() : tensor<2x16xf32>
  %init = linalg.fill ins(%zero : f32) outs(%empty : tensor<2x16xf32>) -> tensor<2x16xf32>
  %wide_result = linalg.matmul indexing_maps = [affine_map<(d0,d1,d2)->(d0,d2)>,affine_map<(d0,d1,d2)->(d1,d2)>,affine_map<(d0,d1,d2)->(d0,d1)>] ins(%lw, %rw : tensor<2x128xf32>, tensor<16x128xf32>) outs(%init : tensor<2x16xf32>) -> tensor<2x16xf32>
  %out = tensor.empty() : tensor<2x16xf16>
  %result = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>,affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%wide_result : tensor<2x16xf32>) outs(%out : tensor<2x16xf16>) {
    ^bb0(%value: f32, %unused: f16):
      %narrow = arith.truncf %value : f32 to f16
      linalg.yield %narrow : f16
  } -> tensor<2x16xf16>
  return %result : tensor<2x16xf16>
}
}
