import concurrent.futures
import hashlib
import json
from pathlib import Path
import urllib.request

root = Path('.scratch/validation/m1-vulkan-admission/alternatives')
root.mkdir(exist_ok=True)
providers = [('ncnn','Tencent/ncnn','70e7bfd6081b912a6521c73f436f9727eb335ce1'),
             ('mnn','alibaba/MNN','397f85331fee0221df9ffe364f7be2df349f420b')]
def fetch(entry):
    name, repo, pin = entry
    directory = root/name
    directory.mkdir(exist_ok=True)
    url = f'https://api.github.com/repos/{repo}/git/trees/{pin}?recursive=1'
    tree = json.load(urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'HYLE-M1-V'}),timeout=40))
    assert not tree.get('truncated')
    (directory/'tree.json').write_text(json.dumps(tree,indent=2)+'\n')
    paths = [x['path'] for x in tree['tree'] if x['type']=='blob']
    if name=='ncnn':
        selected = [x for x in paths if x in ['src/layer/vulkan/gemm_vulkan.cpp','src/layer/vulkan/innerproduct_vulkan.cpp','src/layer/vulkan/cast_vulkan.cpp','src/layer/gemm.cpp','src/mat.h'] or ('src/layer/vulkan/shader/' in x and any(s in x.lower() for s in ['dequant','fp8','fp4','quantize','gemm_int8']))]
    else:
        selected = [x for x in paths if x in ['schema/default/Type.fbs','schema/default/Tensor.fbs','source/backend/vulkan/buffer/execution/VulkanMatMul.cpp','source/backend/vulkan/buffer/execution/VulkanDequantize.cpp'] or ('vulkan/' in x.lower() and any(s in x.lower() for s in ['fp8','fp4','quantize','quantmatmul','gemmint8']))]
    assert len(selected)<=30, len(selected)
    receipts=[]
    for path in selected:
        url=f'https://raw.githubusercontent.com/{repo}/{pin}/{path}'
        with urllib.request.urlopen(url,timeout=30) as response: data=response.read()
        dest=directory/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        receipts.append({'path':path,'url':url,'sha256':hashlib.sha256(data).hexdigest()})
    (directory/'sources.json').write_text(json.dumps({'pin':pin,'files':receipts,'filename_candidates':[x for x in paths if any(s in x.lower() for s in ['fp8','fp4','ue8','e4m3','e2m1','e8m0'])]},indent=2)+'\n')
    return name,len(receipts),[x['path'] for x in receipts]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(fetch,providers): print(json.dumps(result),flush=True)
