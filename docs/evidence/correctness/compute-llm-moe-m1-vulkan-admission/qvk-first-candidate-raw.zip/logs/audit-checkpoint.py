import datetime
import hashlib
import json
from pathlib import Path
import zipfile

root=Path('.scratch/validation/m1-vulkan-admission')
evidence=Path('evidence/correctness/compute-llm-moe-m1-vulkan-admission')
evidence.mkdir(exist_ok=True)
first=json.loads((root/'windows-numeric.json').read_text())
corrected=json.loads((root/'windows-numeric-c7.json').read_text())
record={
    'scope':'Q-VK first IREE packed-FP4 candidate; qualification only, no product coverage',
    'baseline':'0a565baed111c415f993b5680f4b7bc349a75ba6',
    'iree_pin':'6ef606b6fa3e12bd2c12d36a07463069eb71185f',
    'budget':json.loads((root/'budget.json').read_text()),
    'checkpoint_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'product_coverage_cells':0,
    'candidate_verdict':'REJECTED_PACKED_FP4_PATH',
    'aggregate_gate':'INCONCLUSIVE',
    'windows_first':{'passed_cases':3,'failed_case':'fp8_ue8_scale-0','nan_count':230},
    'windows_upstream_llvm_prepass':{'passed_cases':4,'failed_case':'fp4_ue8_matmul-0',
        'max_absolute_error':corrected['cases'][-1]['max_absolute_error'],
        'module_sha256':corrected['module_sha256']},
    'corrections':[
        'Old named MatMul syntax replaced by the locked upstream indexing_maps form; attempt2 accidentally repeated unchanged IR after a failed fixture edit and is retained.',
        'Original scaling_extf failed after type conversion; equivalent standard ExtF+MulF composition was used, with unchanged inputs/oracle. Explicit F16 storage features were declared.',
        'Packed-F4 typed-vector legalization failed; integer i4 storage plus scalar bitcast compiled but did not qualify numerically.',
        'UE8 generic emulation assumes a sign bit. IREE does not register arith-expand; attempt6 returned zero despite an error and was not run. Original LLVM23 arith-expand fixed the observed UE8 cases in attempt7.',
        'Packed-F4 numeric failure: original LLVM F4 expansion and then original IREE narrow-type preprocessing both fail vector<2xi8> to vector<4xi4> legalization. Two corrections consumed; this path stops.'
    ],
    'unrun_applicable':['remaining five cases after attempt7 stopped','Air/MoltenVK','external native resources','C runtime and three-delivery qualification'],
    'next_bounded_action':'Qualify the original ggml Vulkan MXFP4 path for the same logical packed-F4/UE8 values, and IREE only for scan/FP8. The combined candidate remains UNPROVEN under the original four-hour deadline. No self-written decoder, compiler math patch, or weakened tolerance.',
    'fallback_source_findings':{
        'ncnn':'Inspected locked Vulkan cast creates FP32<->FP16 pipelines; GEMM INT8 shader consumes signed integer codes and float descales. These interfaces do not qualify E4M3/E2M1 with UE8.',
        'mnn':'Inspected locked Vulkan MatMul selects F32/F16 storage; its Tensor schema has no E4M3/E2M1/UE8 enum. No qualifying replacement has been demonstrated; not a claim about every MNN backend.',
        'ggml':'Locked original Vulkan includes MXFP4 kernels; an actual native numeric test is still required. This is an existing mature implementation, not a new HYLE algorithm.'
    }
}
archive=evidence/'qvk-first-candidate-raw.zip'
assert not archive.exists()
omit={'scoped-plan.json','source-tree.json','releases.json','llvm-release.json','compiler-exports.log','compiler-help.log','opt-help.log','llvm23-packages.gz'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.name not in omit and path.name!='tree.json':
            z.write(path,'logs/'+path.relative_to(root).as_posix())
    for path in sorted(Path('C:/hv/qvk').iterdir()):
        if path.is_file() and path.name!='bundle.vmfb':
            z.write(path,'qvk/'+path.name)
record['raw_archive']={'file':archive.name,'bytes':archive.stat().st_size,
                       'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(evidence/'qvk-first-candidate.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')

registry_path=Path('docs/implementation/module-status.json')
registry=json.loads(registry_path.read_text(encoding='utf-8'))
owners={'compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan'}
def visit(value):
    if isinstance(value,dict):
        if value.get('module') in owners:
            assert value['state']=='SCOPED'
            value['state']='AUDITED'
            value['summary']='M1-V AUDITED：有限FIX只授权原版ggml GatedDeltaNet普通Direct/Graph、多输出/资源与三交付；IREE packed-FP4失格保留，scan/FP8+原版ggml MXFP4组合资格仍待验证；自研冻结，覆盖0。'
        for item in value.values(): visit(item)
    elif isinstance(value,list):
        for item in value: visit(item)
visit(registry)
registry_path.write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'archive':record['raw_archive'],'checkpoint':record['checkpoint_utc']},ensure_ascii=False))
