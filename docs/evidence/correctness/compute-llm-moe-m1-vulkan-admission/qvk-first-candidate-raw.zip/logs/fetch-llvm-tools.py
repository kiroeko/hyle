import gzip
import hashlib
import json
from pathlib import Path
import urllib.request

root=Path('C:/hv/downloads')
logs=Path('.scratch/validation/m1-vulkan-admission')
url='https://apt.llvm.org/noble/dists/llvm-toolchain-noble-23/main/binary-amd64/Packages.gz'
raw=urllib.request.urlopen(url,timeout=40).read()
(logs/'llvm23-packages.gz').write_bytes(raw)
records=[]
for block in gzip.decompress(raw).decode().split('\n\n'):
    fields={}
    for line in block.splitlines():
        if line and not line.startswith(' ') and ': ' in line:
            k,v=line.split(': ',1); fields[k]=v
    if fields.get('Package') not in ['mlir-23-tools','libllvm23']: continue
    target=root/(fields['Package']+'.deb')
    assert not target.exists()
    assert int(fields['Size']) < 100_000_000
    source='https://apt.llvm.org/noble/'+fields['Filename']
    with urllib.request.urlopen(source,timeout=60) as response, target.open('wb') as stream:
        while chunk:=response.read(1024*1024): stream.write(chunk)
    digest=hashlib.sha256(target.read_bytes()).hexdigest()
    assert digest==fields['SHA256'] and target.stat().st_size==int(fields['Size'])
    records.append({'package':fields['Package'],'version':fields['Version'],'source':source,
                    'sha256':digest,'bytes':target.stat().st_size,'depends':fields.get('Depends')})
    print(json.dumps(records[-1]),flush=True)
assert len(records)==2
(logs/'llvm-tools-downloads.json').write_text(json.dumps(records,indent=2)+'\n')
