import difflib
import hashlib
import json
from pathlib import Path

root = Path.cwd()
vendor = root / 'third_party/iree_vulkan_runtime'
original = Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')
path = vendor / 'patches.json'
manifest = json.loads(path.read_text(encoding='utf-8'))

def one(data, before, after):
    assert data.count(before) == 1, (before, data.count(before))
    return data.replace(before, after, 1)

for patch in manifest['files']:
    name = patch['path']
    if name not in [f'runtime/src/iree/hal/drivers/vulkan/{n}' for n in
                    ['api.h', 'logical_device.c', 'queue.h', 'queue.c']]:
        continue
    before = (original / name).read_text(encoding='utf-8')
    data = before
    for edit in patch['edits']:
        data = one(data, edit['before'], edit['after'])
    if name.endswith('api.h'):
        data = one(data, 'stops this borrowed single-lane wrapper.',
                   'stops every lane of this borrowed wrapper.')
    elif name.endswith('logical_device.c'):
        data = one(data, '  iree_hal_vulkan_memory_owner_t memory_owner;\n',
                   '  iree_hal_vulkan_memory_owner_t memory_owner;\n  iree_atomic_int32_t external_stop_remaining;\n')
        data = one(data, '''  if (device->queues.lane_count != 1) {
    return iree_make_status(IREE_STATUS_INVALID_ARGUMENT,
                            "external retirement requires one native lane");
  }
  return iree_hal_vulkan_queue_request_stop(&device->queues.lanes[0], retired);''',
'''  iree_atomic_store(&device->external_stop_remaining,
                    (int32_t)device->queues.lane_count, iree_memory_order_release);
  iree_status_t status = iree_ok_status();
  for (iree_host_size_t i = 0; i < device->queues.lane_count; ++i) {
    iree_status_t next = iree_hal_vulkan_queue_request_stop(
        &device->queues.lanes[i], retired, &device->external_stop_remaining);
    if (iree_status_is_ok(status)) status = next;
    else iree_status_free(next);
  }
  return status;''')
    elif name.endswith('queue.h'):
        data = one(data, '  iree_hal_semaphore_t* external_retired;\n',
                   '  iree_hal_semaphore_t* external_retired;\n  iree_atomic_int32_t* external_stop_remaining;\n')
        data = one(data, '    iree_hal_vulkan_queue_t* queue, iree_hal_semaphore_t* retired);',
                   '    iree_hal_vulkan_queue_t* queue, iree_hal_semaphore_t* retired,\n    iree_atomic_int32_t* remaining);')
    else:
        data = one(data, '    iree_status_ignore(iree_hal_semaphore_signal(retired, 1, NULL));',
                   '''    if (iree_atomic_fetch_sub(queue->external_stop_remaining, 1,
                              iree_memory_order_acq_rel) == 1) {
      iree_status_ignore(iree_hal_semaphore_signal(retired, 1, NULL));
    }''')
        data = one(data, '    iree_hal_vulkan_queue_t* queue, iree_hal_semaphore_t* retired) {',
                   '    iree_hal_vulkan_queue_t* queue, iree_hal_semaphore_t* retired,\n    iree_atomic_int32_t* remaining) {')
        data = one(data, '    queue->external_retired = retired;\n',
                   '    queue->external_retired = retired;\n    queue->external_stop_remaining = remaining;\n')
        data = one(data, '  if (exited) return iree_hal_semaphore_signal(retired, 1, NULL);',
                   '''  if (exited) {
    if (iree_atomic_fetch_sub(remaining, 1, iree_memory_order_acq_rel) == 1)
      return iree_hal_semaphore_signal(retired, 1, NULL);
    return iree_ok_status();
  }''')
    old, new = before.splitlines(keepends=True), data.splitlines(keepends=True)
    edits = []
    for group in difflib.SequenceMatcher(a=old, b=new, autojunk=False).get_grouped_opcodes(24):
        a0, a1 = group[0][1], group[-1][2]
        b0, b1 = group[0][3], group[-1][4]
        edits.append({'before': ''.join(old[a0:a1]), 'after': ''.join(new[b0:b1])})
    check = before
    for edit in edits:
        check = one(check, edit['before'], edit['after'])
    assert check == data
    patch['edits'] = edits
    patch['after_sha256'] = hashlib.sha256(data.encode()).hexdigest()
path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
notice = vendor / 'NOTICE.md'
notice.write_bytes(notice.read_bytes().replace(b'The single-lane external wrapper', b'The external wrapper (including distinct logical lanes on one native queue)'))
lock = root / 'cmake/HyleDependencyLock.json'
data = lock.read_text(encoding='utf-8')
entry = next(d for d in json.loads(data)['dependencies'] if d['name'] == 'iree_vulkan_runtime_patches')
for license in entry['license']['files']:
    data = data.replace(license['sha256'], hashlib.sha256((root / license['path']).read_bytes().replace(b'\r\n', b'\n')).hexdigest())
tree = ''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
lock.write_bytes(data.replace(entry['vendored']['tree_sha256'], hashlib.sha256(tree.encode()).hexdigest()).encode())
