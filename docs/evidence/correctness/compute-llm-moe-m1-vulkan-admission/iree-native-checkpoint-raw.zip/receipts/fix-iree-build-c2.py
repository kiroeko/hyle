import hashlib
import json
from pathlib import Path

root=Path.cwd()
vendor=root/'third_party/iree_vulkan_runtime'
path=vendor/'patches.json'
data=json.loads(path.read_text())
patch=next(p for p in data['files'] if p['path']=='runtime/src/iree/vm/bytecode/isa/CMakeLists.txt')
original=Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')/patch['path']
before=original.read_bytes().replace(b'\r\n',b'\n').decode()
start=before.index('iree_genrule(')
end=before.index('iree_cc_library(',start)
# Upstream genrule splits on spaces after native-path conversion; it cannot
# encode this interpreter path. Use CMake's argument-list API for the two
# existing code generators, preserving exact script/schema/output semantics.
commands='''set(_isa_generator "${PROJECT_SOURCE_DIR}/build_tools/scripts/generate_vm_isa.py")
add_custom_command(OUTPUT op_table.h
  COMMAND "${Python3_EXECUTABLE}" "${_isa_generator}"
    --schema "${CMAKE_CURRENT_SOURCE_DIR}/isa.json" --op-table op_table.h
  DEPENDS "${_isa_generator}" isa.json VERBATIM)
add_custom_target(op_table_gen DEPENDS op_table.h)
add_custom_command(OUTPUT encoding_table.c encoding_table.h
  COMMAND "${Python3_EXECUTABLE}" "${_isa_generator}"
    --schema "${CMAKE_CURRENT_SOURCE_DIR}/isa.json"
    --encoding-table-header encoding_table.h --encoding-table-source encoding_table.c
  DEPENDS "${_isa_generator}" isa.json VERBATIM)
add_custom_target(encoding_table_gen DEPENDS encoding_table.c encoding_table.h)

'''
after=before[:start]+commands+before[end:]
patch['edits']=[{'before':before,'after':after}]
patch['after_sha256']=hashlib.sha256(after.encode()).hexdigest()
path.write_bytes((json.dumps(data,indent=2)+'\n').encode())
ledger=root/'cmake/HyleDependencyLock.json'
text=ledger.read_text()
entry=next(d for d in json.loads(text)['dependencies'] if d['name']=='iree_vulkan_runtime_patches')
manifest=''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
text=text.replace(entry['vendored']['tree_sha256'],hashlib.sha256(manifest.encode()).hexdigest())
ledger.write_bytes(text.encode())
runner=root/'.scratch/validation/m1-vulkan-admission/iree-windows.py'
run=runner.read_text().replace('iree-product-development.json','iree-product-development-c2.json').replace("'iree-dev-'","'iree-dev-c2-'")
runner.with_name('iree-windows-c2.py').write_bytes(run.encode())
runner.with_name('iree-windows-c2.ps1').write_bytes(runner.with_suffix('.ps1').read_bytes().replace(b'iree-windows.py',b'iree-windows-c2.py'))
