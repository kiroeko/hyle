import hashlib
import json
from pathlib import Path
task = Path('/Users/kiro/hyle-m1v-product')
path = task / 'source' / 'src/compute_provider_iree_vulkan/CMakeLists.txt'
assert hashlib.sha256(path.read_bytes()).hexdigest() == '0683bd8131ca2bfe1006b538c14b2316db8546a6b3d349cd14aab4810f398139'
data = (task / 'iree-native-air-c2.cmake').read_bytes()
assert hashlib.sha256(data).hexdigest() == 'b1f39f80ba3fb0e4513a1282dba2cb45cce10098089522275a241abbae676571'
path.write_bytes(data)
(task / 'iree-native-c2-applied.json').write_text(json.dumps({'base': 'd5549268545c7f1a91bcd7953bf2574a030645dc', 'candidate': '7267aa0c6e0492928d3d132c34b0f02adfeffd99', 'file': 'src/compute_provider_iree_vulkan/CMakeLists.txt', 'before': '0683bd8131ca2bfe1006b538c14b2316db8546a6b3d349cd14aab4810f398139', 'after': 'b1f39f80ba3fb0e4513a1282dba2cb45cce10098089522275a241abbae676571'}, indent=2))
