from pathlib import Path
import hashlib,json,tarfile
task=Path('/Users/kiro/hyle-m1v-product')
record={'base': '778aa484d98b0ae992af31cfac14bc8000a60ae2', 'candidate': 'dee6ad642fc0952d0c47a46daa36330db8291e82', 'files': [{'path': 'cmake/HyleDependencyLock.json', 'before': '8816854a5a9c097c499a6bfa3b39ee614698c303f7664500d1b8ab43b1e6b5c7', 'after': '219854e90a56787771f0e4ea83c65f325aa7556fe3cfc09fb27cbd9c9ba042f1'}, {'path': 'docs/implementation/tasks/compute/llm-moe-m1-vulkan-iree-product.md', 'before': 'a4dcd83658e2406531e713b3f786bc03911f17eca27d25b9cc5189a1d877f2d4', 'after': '7f705f94061216c65a0b6eb359cdc1b2a31817c4362267cd902854e084b1470c'}, {'path': 'third_party/iree_vulkan_runtime/NOTICE.md', 'before': '140e1559e931065ba3b712a4b8ef48f56778e78fe7eb00ea952ec2b16da82249', 'after': '0c0f68b316132cd31218b91f38eaa6da13ef5e2542dc1dd0ce7ef267e064734e'}, {'path': 'third_party/iree_vulkan_runtime/patches.json', 'before': '933cbcb6ac5464632d1ffd8e3dbd7907eb3a14491e1987cf24d40f38464ddcd1', 'after': 'e20b2c87225390a204382be5beb0e93a628c1cdb992ce403c75320d9d870e0a4'}], 'archive_sha256': 'd3bfa3b9e15ddd6692395b519defd1ed2865fb54eed4275e641dd3a529b83171'}
archive=task/'iree-native-posix-c1-forward.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==record['archive_sha256']
for item in record['files']:
 path=task/'source'/item['path']
 assert path.is_file() and not path.is_symlink()
 assert hashlib.sha256(path.read_bytes()).hexdigest()==item['before'],item['path']
with tarfile.open(archive) as tar:
 for item in record['files']:
  data=tar.extractfile(item['path']).read()
  assert hashlib.sha256(data).hexdigest()==item['after']
  (task/'source'/item['path']).write_bytes(data)
(task/'iree-native-posix-c1-applied.json').write_text(json.dumps(record,indent=2))
