import hashlib
import json
from pathlib import Path

root = Path.cwd()
vendor = root / 'third_party/iree_vulkan_runtime'
path = vendor / 'programs/fp8-legalized.mlir'
before = path.read_bytes().replace(b'\r\n', b'\n')
after = before.rstrip(b'\n') + b'\n'
assert before == after + b'\n'
path.write_bytes(after)
record = vendor / 'programs/compilation.json'
data = json.loads(record.read_text(encoding='utf-8'))
assert data['fp8_legalized_sha256'] == hashlib.sha256(before).hexdigest()
data['vendored_fp8_legalized_sha256'] = hashlib.sha256(after).hexdigest()
data['vendored_fp8_legalized_normalization'] = 'Only the final empty line was removed; original compiler-input hash above and qualified VMFB bytes are preserved.'
record.write_bytes((json.dumps(data, indent=2) + '\n').encode())
lock = root / 'cmake/HyleDependencyLock.json'
data = lock.read_text(encoding='utf-8')
entry = next(d for d in json.loads(data)['dependencies'] if d['name'] == 'iree_vulkan_runtime_patches')
tree = ''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
lock.write_bytes(data.replace(entry['vendored']['tree_sha256'], hashlib.sha256(tree.encode()).hexdigest()).encode())
