import hashlib
import json
from pathlib import Path

root = Path.cwd()
vendor = root / 'third_party/iree_vulkan_runtime'
path = vendor / 'patches.json'
manifest = json.loads(path.read_text(encoding='utf-8'))
patch = next(p for p in manifest['files'] if p['path'].endswith('/queue.c'))
data = (Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f') / patch['path']).read_text(encoding='utf-8')
count = 0
for edit in patch['edits']:
    count += edit['after'].count('iree_hal_semaphore_signal(retired, 1)')
    edit['after'] = edit['after'].replace('iree_hal_semaphore_signal(retired, 1)', 'iree_hal_semaphore_signal(retired, 1, NULL)')
    assert data.count(edit['before']) == 1
    data = data.replace(edit['before'], edit['after'], 1)
assert count == 2
patch['after_sha256'] = hashlib.sha256(data.encode()).hexdigest()
path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
lock = root / 'cmake/HyleDependencyLock.json'
data = lock.read_text(encoding='utf-8')
entry = next(d for d in json.loads(data)['dependencies'] if d['name'] == 'iree_vulkan_runtime_patches')
tree = ''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
lock.write_bytes(data.replace(entry['vendored']['tree_sha256'], hashlib.sha256(tree.encode()).hexdigest()).encode())
