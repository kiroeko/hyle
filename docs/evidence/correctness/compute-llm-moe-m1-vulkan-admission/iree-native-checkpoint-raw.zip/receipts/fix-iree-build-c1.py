import hashlib
import json
from pathlib import Path

root=Path.cwd()
vendor=root/'third_party/iree_vulkan_runtime'
path=vendor/'patches.json'
data=json.loads(path.read_text())
patch=next(p for p in data['files'] if p['path']=='runtime/src/iree/vm/bytecode/isa/CMakeLists.txt')
original=Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')/patch['path']
before=original.read_bytes().replace(b'\r\n',b'\n')
# Upstream's genrule CMD is a shell string; quotes must survive CMake parsing.
after=before.replace(b'python3 ',b'\\"${Python3_EXECUTABLE}\\" ')
patch['edits']=[{'before':before.decode(),'after':after.decode()}]
patch['after_sha256']=hashlib.sha256(after).hexdigest()
path.write_bytes((json.dumps(data,indent=2)+'\n').encode())

# Preserve the qualified compiler command chain, including original LLVM's
# E8M0 legalization. This is build provenance, never a runtime dependency.
programs=vendor/'programs'
processed=Path('C:/hv/qvk/parameterized-c2-llvm23.mlir').read_bytes().replace(b'\r\n',b'\n')
(programs/'fp8-legalized.mlir').write_bytes(processed)
record={'checked_scan':json.loads(Path('C:/hv/checked-scan-c1/compile.json').read_text()),
        'fp8':json.loads((root/'.scratch/validation/m1-vulkan-admission/parameterized-c2-compile.json').read_text()),
        'fp8_legalized_sha256':hashlib.sha256(processed).hexdigest(),
        'note':'Original qualification command paths document tool identity; install consumers only use embedded bytecode.'}
(programs/'compilation.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())

ledger=root/'cmake/HyleDependencyLock.json'
text=ledger.read_text()
entry=next(d for d in json.loads(text)['dependencies'] if d['name']=='iree_vulkan_runtime_patches')
manifest=''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
text=text.replace(entry['vendored']['tree_sha256'],hashlib.sha256(manifest.encode()).hexdigest())
ledger.write_bytes(text.encode())

runner=root/'.scratch/validation/m1-vulkan-admission/iree-windows.py'
run=runner.read_text().replace('iree-product-development.json','iree-product-development-c1.json').replace("'iree-dev-'","'iree-dev-c1-'")
(runner.with_name('iree-windows-c1.py')).write_bytes(run.encode())
launcher=runner.with_suffix('.ps1')
launcher.with_name('iree-windows-c1.ps1').write_bytes(launcher.read_bytes().replace(b'iree-windows.py',b'iree-windows-c1.py'))
