from pathlib import Path
import json,subprocess,time,hashlib
log=Path('.scratch\\validation\\m1-vulkan-admission\\iree-native-posix-c1-launch.log')
assert not log.exists()
start=time.time()
with log.open('wb') as output:
 result=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','bash /Users/kiro/hyle-m1v-product/iree-native-posix-c1.sh'],stdout=output,stderr=subprocess.STDOUT,timeout=900)
record={'candidate':'dee6ad642fc0952d0c47a46daa36330db8291e82','exit_code':result.returncode,'seconds':time.time()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
Path('.scratch\\validation\\m1-vulkan-admission\\iree-native-posix-c1-result.json').write_text(json.dumps(record,indent=2))
print(log.read_text(errors='replace')[-18000:])
raise SystemExit(result.returncode)
