#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-product
test "$(cat "$task/owner.txt")" = 'M1-V product db770b6fc1e46aa8d8aa86c1102d50acf26eb49f'
test ! -L "$task"
test ! -e "$task/iree-host-asan"
mkdir "$task/iree-host-asan-logs"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1
cmake -S "$task/source" -B "$task/iree-host-asan" -G Ninja   -DCMAKE_BUILD_TYPE=RelWithDebInfo -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON   -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON   -DHYLE_DEV_FACTORS=compute_provider_iree_vulkan   -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF   -DHYLE_COMPUTE_VULKAN=ON -DHYLE_COMPUTE_ONEDNN=OFF   -DHYLE_SANITIZER=asan -DIREE_ENABLE_ASAN=ON   -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 > "$task/iree-host-asan-logs/configure.log" 2>&1
cmake --build "$task/iree-host-asan" --parallel 2 --target hyle_compute_provider_iree_vulkan_tests   > "$task/iree-host-asan-logs/build.log" 2>&1
ctest --test-dir "$task/iree-host-asan" -L '^compute_provider_iree_vulkan$'   --output-on-failure --no-tests=error --timeout 180 > "$task/iree-host-asan-logs/tests.log" 2>&1
cat "$task/iree-host-asan-logs/tests.log"
