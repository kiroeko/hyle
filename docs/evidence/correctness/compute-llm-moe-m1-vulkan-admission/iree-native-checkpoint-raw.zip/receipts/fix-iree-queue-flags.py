import difflib
import hashlib
import json
from pathlib import Path

root=Path.cwd()
vendor=root/'third_party/iree_vulkan_runtime'
original=Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')
file=vendor/'patches.json'
manifest=json.loads(file.read_text())
def one(data,before,after):
    assert data.count(before)==1, (before,data.count(before))
    return data.replace(before,after,1)
for path in ['runtime/src/iree/hal/drivers/vulkan/api.h','runtime/src/iree/hal/drivers/vulkan/logical_device.c']:
    patch=next(p for p in manifest['files'] if p['path']==path)
    before=(original/path).read_text()
    data=before
    for edit in patch['edits']: data=one(data,edit['before'],edit['after'])
    data=one(data,'  iree_hal_vulkan_memory_owner_t memory_owner;\n',
             '  iree_hal_vulkan_memory_owner_t memory_owner;\n'
             '  // Flags used when the external owner created these queue handles.\n'
             '  VkDeviceQueueCreateFlags queue_create_flags;\n')
    if path.endswith('logical_device.c'):
        data=one(data,'    device->memory_owner = external_device_params->memory_owner;\n',
                 '    device->memory_owner = external_device_params->memory_owner;\n'
                 '    device->queue_create_flags = external_device_params->queue_create_flags;\n')
        data=one(data,'      .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_INFO_2,\n',
                 '      .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_INFO_2,\n'
                 '      .flags = device->queue_create_flags,\n')
    old,new=before.splitlines(keepends=True),data.splitlines(keepends=True)
    edits=[]
    for group in difflib.SequenceMatcher(a=old,b=new,autojunk=False).get_grouped_opcodes(32):
        a0,a1=group[0][1],group[-1][2];b0,b1=group[0][3],group[-1][4]
        edits.append({'before':''.join(old[a0:a1]),'after':''.join(new[b0:b1])})
    check=before
    for edit in edits: check=one(check,edit['before'],edit['after'])
    assert check==data
    patch['edits']=edits
    patch['after_sha256']=hashlib.sha256(data.encode()).hexdigest()
file.write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
notice=vendor/'NOTICE.md'
notice.write_bytes(notice.read_bytes()+b'\nExternal queue lookup preserves the actual VkDeviceQueueCreateFlags supplied\nby its owner, including internally synchronized queues. This changes resource\nwrapping only; the original scheduling and math remain unchanged.\n')
ledger=root/'cmake/HyleDependencyLock.json'
text=ledger.read_text()
entry=next(d for d in json.loads(text)['dependencies'] if d['name']=='iree_vulkan_runtime_patches')
for license in entry['license']['files']:
    text=text.replace(license['sha256'],hashlib.sha256((root/license['path']).read_bytes().replace(b'\r\n',b'\n')).hexdigest())
tree=''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
text=text.replace(entry['vendored']['tree_sha256'],hashlib.sha256(tree.encode()).hexdigest())
ledger.write_bytes(text.encode())
