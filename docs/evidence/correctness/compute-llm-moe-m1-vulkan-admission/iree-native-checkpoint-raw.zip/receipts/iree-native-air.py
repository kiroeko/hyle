import hashlib
import json
from pathlib import Path
import subprocess
import time

logs = Path('.scratch/validation/m1-vulkan-admission')
base = 'd5cd5568c179d0f9bbff1cd528b306f3a9bde558'
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
files = {}
for row in subprocess.check_output(['git', 'diff', '--name-status', base, candidate], text=True).splitlines():
    kind, path = row.split('\t')
    assert kind in ('A', 'M'), row
    files[path] = {
        'before': hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + path])).hexdigest() if kind == 'M' else None,
        'after': hashlib.sha256(subprocess.check_output(['git', 'show', candidate + ':' + path])).hexdigest()}
archive = Path('C:/hv/iree-native-forward.tar.gz')
if archive.exists():
    previous = json.loads((logs / 'iree-native-forward.json').read_text())
    assert previous['candidate'] == candidate and previous['files'] == files
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == previous['archive_sha256']
else:
    subprocess.run(['git', 'archive', '--format=tar.gz', '--output=' + str(archive), candidate, *files], check=True)
manifest = {'baseline': base, 'candidate': candidate, 'files': files,
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
manifest_path = logs / 'iree-native-forward.json'
manifest_path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
host = 'kiro@172.22.10.198'
remote = host + ':/Users/kiro/hyle-m1v-product/'
transfers = [(archive, archive.name), (manifest_path, manifest_path.name),
             (logs / 'iree-native-air-apply.py', 'iree-native-air-apply.py'),
             (logs / 'iree-native-air.sh', 'iree-native-air.sh'),
             (logs / 'iree-native-air-seed.cmake', 'iree-native-air-seed.cmake')]
lock = json.loads(Path('cmake/HyleDependencyLock.json').read_text(encoding='utf-8'))
for name, prefix in [('iree_runtime', 'iree'), ('iree_flatcc', 'flatcc'), ('iree_vulkan_headers', 'vulkan_headers')]:
    dependency = next(d for d in lock['dependencies'] if d['name'] == name)
    commit = dependency['revision']
    source = Path('C:/hv/downloads') / f'{prefix}-{commit}.tar.gz'
    transfers.append((source, source.name))
for source, name in transfers:
    subprocess.run(['scp', str(source), remote + name], check=True, timeout=120)
path = logs / 'iree-native-air-launch.log'
assert not path.exists()
start = time.time()
with path.open('wb') as output:
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', host,
                             'bash /Users/kiro/hyle-m1v-product/iree-native-air.sh'],
                            stdout=output, stderr=subprocess.STDOUT, timeout=1800)
record = {'candidate': candidate, 'exit_code': result.returncode,
          'status': 'PASS' if result.returncode == 0 else 'FAIL',
          'elapsed_seconds': time.time() - start,
          'scope': 'Air static original IREE private native adapter; ordinary route/delivery gates remain pending',
          'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(logs / 'iree-native-air-result.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(path.read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
raise SystemExit(result.returncode)
