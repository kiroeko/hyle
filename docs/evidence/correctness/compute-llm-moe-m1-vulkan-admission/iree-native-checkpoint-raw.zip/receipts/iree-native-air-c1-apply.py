import hashlib
import json
from pathlib import Path
task = Path('/Users/kiro/hyle-m1v-product')
path = task / 'source' / 'src/compute_provider_iree_vulkan/CMakeLists.txt'
assert hashlib.sha256(path.read_bytes()).hexdigest() == '8a4bfc208a718b9892a3e67ad7d90d667ad67c8592834ef2bae761a4c7aa2817'
data = (task / 'iree-native-air-c1.cmake').read_bytes()
assert hashlib.sha256(data).hexdigest() == '0683bd8131ca2bfe1006b538c14b2316db8546a6b3d349cd14aab4810f398139'
path.write_bytes(data)
(task / 'iree-native-c1-applied.json').write_text(json.dumps({'base': 'aa26de0f2ef0457638fbe89349ee9476bb613375', 'candidate': 'd5549268545c7f1a91bcd7953bf2574a030645dc', 'file': 'src/compute_provider_iree_vulkan/CMakeLists.txt', 'before': '8a4bfc208a718b9892a3e67ad7d90d667ad67c8592834ef2bae761a4c7aa2817', 'after': '0683bd8131ca2bfe1006b538c14b2316db8546a6b3d349cd14aab4810f398139'}, indent=2))
