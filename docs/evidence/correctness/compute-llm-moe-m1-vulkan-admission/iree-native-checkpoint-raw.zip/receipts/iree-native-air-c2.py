import hashlib
import json
from pathlib import Path
import subprocess
import time

logs = Path('.scratch/validation/m1-vulkan-admission')
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
base = 'd5549268545c7f1a91bcd7953bf2574a030645dc'
relative = 'src/compute_provider_iree_vulkan/CMakeLists.txt'
assert subprocess.check_output(['git', 'diff', '--name-only', base, candidate], text=True).splitlines() == [relative]
data = subprocess.check_output(['git', 'show', candidate + ':' + relative])
before = hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + relative])).hexdigest()
after = hashlib.sha256(data).hexdigest()
forward = logs / 'iree-native-air-c2.cmake'
forward.write_bytes(data)
host = 'kiro@172.22.10.198'
remote = '/Users/kiro/hyle-m1v-product'
subprocess.run(['scp', str(forward), host + ':' + remote + '/iree-native-air-c2.cmake'], check=True)
apply = logs / 'iree-native-air-c2-apply.py'
apply.write_text(f'''import hashlib
import json
from pathlib import Path
task = Path({remote!r})
path = task / 'source' / {relative!r}
assert hashlib.sha256(path.read_bytes()).hexdigest() == {before!r}
data = (task / 'iree-native-air-c2.cmake').read_bytes()
assert hashlib.sha256(data).hexdigest() == {after!r}
path.write_bytes(data)
(task / 'iree-native-c2-applied.json').write_text(json.dumps({{'base': {base!r}, 'candidate': {candidate!r}, 'file': {relative!r}, 'before': {before!r}, 'after': {after!r}}}, indent=2))
''', encoding='utf-8')
subprocess.run(['scp', str(apply), host + ':' + remote + '/iree-native-air-c2-apply.py'], check=True)
script = (logs / 'iree-native-air.sh').read_text(encoding='utf-8')
script = script.replace('iree-native-air-apply.py', 'iree-native-air-c2-apply.py').replace('iree-native-logs', 'iree-native-c2-logs')
script = '\n'.join(line for line in script.splitlines() if not line.startswith('cmake -P ')) + '\n'
runner = logs / 'iree-native-air-c2.sh'
runner.write_bytes(script.encode())
subprocess.run(['scp', str(runner), host + ':' + remote + '/iree-native-air-c2.sh'], check=True)
log = logs / 'iree-native-air-c2-launch.log'
assert not log.exists()
start = time.time()
with log.open('wb') as output:
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', host, 'bash ' + remote + '/iree-native-air-c2.sh'],
                            stdout=output, stderr=subprocess.STDOUT, timeout=1800)
record = {'base': base, 'candidate': candidate, 'exit_code': result.returncode,
          'status': 'PASS' if result.returncode == 0 else 'FAIL', 'elapsed_seconds': time.time()-start,
          'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
(logs / 'iree-native-air-c2-result.json').write_bytes((json.dumps(record, indent=2)+'\n').encode())
print(log.read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
raise SystemExit(result.returncode)
