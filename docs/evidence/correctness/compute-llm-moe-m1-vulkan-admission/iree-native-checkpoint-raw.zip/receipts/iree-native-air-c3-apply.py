import hashlib
import json
from pathlib import Path
task = Path('/Users/kiro/hyle-m1v-product')
path = task / 'source' / 'tests/compute_provider_iree_vulkan/native_test.cc'
assert hashlib.sha256(path.read_bytes()).hexdigest() == '1d1037dd25dfbbe6f490f38bf987b1b3312a5d5d23a89124166e0a4635a43a8d'
data = (task / 'iree-native-air-c3.cmake').read_bytes()
assert hashlib.sha256(data).hexdigest() == 'f9eef9f304aa6564b48d041b8eac467a9ff8334ae6138e0bf017c5fb7045adbb'
path.write_bytes(data)
(task / 'iree-native-c3-applied.json').write_text(json.dumps({'base': '7267aa0c6e0492928d3d132c34b0f02adfeffd99', 'candidate': '778aa484d98b0ae992af31cfac14bc8000a60ae2', 'file': 'tests/compute_provider_iree_vulkan/native_test.cc', 'before': '1d1037dd25dfbbe6f490f38bf987b1b3312a5d5d23a89124166e0a4635a43a8d', 'after': 'f9eef9f304aa6564b48d041b8eac467a9ff8334ae6138e0bf017c5fb7045adbb'}, indent=2))
