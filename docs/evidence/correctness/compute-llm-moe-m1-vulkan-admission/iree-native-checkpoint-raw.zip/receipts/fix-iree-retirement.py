import difflib
import hashlib
import json
from pathlib import Path

root = Path.cwd()
vendor = root / 'third_party/iree_vulkan_runtime'
original = Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')
path = vendor / 'patches.json'
manifest = json.loads(path.read_text())

def one(data, before, after):
    assert data.count(before) == 1, (before[:120], data.count(before))
    return data.replace(before, after, 1)

for patch in manifest['files']:
    name = patch['path']
    if name not in [f'runtime/src/iree/hal/drivers/vulkan/{n}'
                    for n in ['api.h', 'logical_device.c', 'queue.h', 'queue.c']]:
        continue
    before = (original / name).read_text(encoding='utf-8')
    data = before
    for edit in patch['edits']:
        data = one(data, edit['before'], edit['after'])
    if name.endswith('api.h'):
        marker = '#ifdef __cplusplus\n}  // extern "C"\n#endif'
        data = one(data, marker, '''// HYLE resource seam: permanently stops this borrowed single-lane wrapper.
// Signals |retired| at value 1 only after the original completion thread has
// cancelled deferred work and drained accepted native submissions.
IREE_API_EXPORT iree_status_t iree_hal_vulkan_device_request_stop(
    iree_hal_device_t* device, iree_hal_semaphore_t* retired);

''' + marker)
    elif name.endswith('logical_device.c'):
        marker = 'static void iree_hal_vulkan_logical_device_destroy(\n'
        data = one(data, marker, '''IREE_API_EXPORT iree_status_t iree_hal_vulkan_device_request_stop(
    iree_hal_device_t* base_device, iree_hal_semaphore_t* retired) {
  iree_hal_vulkan_logical_device_t* device =
      iree_hal_vulkan_logical_device_cast(base_device);
  if (device->queues.lane_count != 1) {
    return iree_make_status(IREE_STATUS_INVALID_ARGUMENT,
                            "external retirement requires one native lane");
  }
  return iree_hal_vulkan_queue_request_stop(&device->queues.lanes[0], retired);
}

''' + marker)
    elif name.endswith('queue.h'):
        marker = '  // Queue-owned completion thread waiting on epoch_semaphore.\n'
        data = one(data, marker, '''  // Optional external retirement signal, protected by submission_mutex.
  iree_hal_semaphore_t* external_retired;
  bool completion_thread_exited;

''' + marker)
        marker = 'void iree_hal_vulkan_queue_retire_frontier(iree_hal_vulkan_queue_t* queue);'
        data = one(data, marker, '''iree_status_t iree_hal_vulkan_queue_request_stop(
    iree_hal_vulkan_queue_t* queue, iree_hal_semaphore_t* retired);

''' + marker)
    else:
        marker = '  return 0;\n}\n\niree_status_t iree_hal_vulkan_queue_initialize('
        data = one(data, marker, '''  // Publish quiescence after the original stop/drain loop, not after a
  // barrier that could overtake a deferred submission. Keep callback work
  // outside the queue lock.
  iree_slim_mutex_lock(&queue->submission_mutex);
  queue->completion_thread_exited = true;
  iree_hal_semaphore_t* retired = queue->external_retired;
  queue->external_retired = NULL;
  iree_slim_mutex_unlock(&queue->submission_mutex);
  if (retired) {
    iree_status_ignore(iree_hal_semaphore_signal(retired, 1));
    iree_hal_semaphore_release(retired);
  }
  return 0;
}

iree_status_t iree_hal_vulkan_queue_initialize(''')
        marker = 'void iree_hal_vulkan_queue_retire_frontier(iree_hal_vulkan_queue_t* queue) {'
        data = one(data, marker, '''iree_status_t iree_hal_vulkan_queue_request_stop(
    iree_hal_vulkan_queue_t* queue, iree_hal_semaphore_t* retired) {
  iree_slim_mutex_lock(&queue->submission_mutex);
  if (queue->external_retired) {
    iree_slim_mutex_unlock(&queue->submission_mutex);
    return iree_make_status(IREE_STATUS_FAILED_PRECONDITION,
                            "external retirement already requested");
  }
  bool exited = queue->completion_thread_exited;
  if (!exited) {
    iree_hal_semaphore_retain(retired);
    queue->external_retired = retired;
  }
  iree_atomic_store(&queue->stop_requested, 1, iree_memory_order_release);
  iree_slim_mutex_unlock(&queue->submission_mutex);
  if (exited) return iree_hal_semaphore_signal(retired, 1);
  return iree_hal_vulkan_queue_signal_wakeup(queue);
}

''' + marker)
    old, new = before.splitlines(keepends=True), data.splitlines(keepends=True)
    edits = []
    for group in difflib.SequenceMatcher(a=old, b=new, autojunk=False).get_grouped_opcodes(24):
        a0, a1 = group[0][1], group[-1][2]
        b0, b1 = group[0][3], group[-1][4]
        edits.append({'before': ''.join(old[a0:a1]), 'after': ''.join(new[b0:b1])})
    check = before
    for edit in edits:
        check = one(check, edit['before'], edit['after'])
    assert check == data
    patch['edits'] = edits
    patch['after_sha256'] = hashlib.sha256(data.encode()).hexdigest()
path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
notice = vendor / 'NOTICE.md'
notice.write_bytes(notice.read_bytes() + b'\nThe single-lane external wrapper exposes original stop/drain completion through\na retained HAL semaphore. No new worker, scheduler or math is introduced.\n')
lock = root / 'cmake/HyleDependencyLock.json'
data = lock.read_text()
entry = next(d for d in json.loads(data)['dependencies'] if d['name'] == 'iree_vulkan_runtime_patches')
for license in entry['license']['files']:
    data = data.replace(license['sha256'], hashlib.sha256((root / license['path']).read_bytes().replace(b'\r\n', b'\n')).hexdigest())
tree = ''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
data = data.replace(entry['vendored']['tree_sha256'], hashlib.sha256(tree.encode()).hexdigest())
lock.write_bytes(data.encode())
