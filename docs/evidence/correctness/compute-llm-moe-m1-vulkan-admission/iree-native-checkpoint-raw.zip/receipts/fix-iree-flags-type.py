import hashlib
import json
from pathlib import Path

root=Path.cwd()
vendor=root/'third_party/iree_vulkan_runtime'
path=vendor/'patches.json'
manifest=json.loads(path.read_text())
patch=next(p for p in manifest['files'] if p['path']=='runtime/src/iree/hal/drivers/vulkan/api.h')
original=Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')/patch['path']
data=original.read_bytes().replace(b'\r\n',b'\n')
for edit in patch['edits']:
    edit['after']=edit['after'].replace('VkDeviceQueueCreateFlags queue_create_flags;', 'uint32_t queue_create_flags;')
    before,after=edit['before'].encode(),edit['after'].encode()
    assert data.count(before)==1
    data=data.replace(before,after,1)
patch['after_sha256']=hashlib.sha256(data).hexdigest()
path.write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
ledger=root/'cmake/HyleDependencyLock.json'
text=ledger.read_text()
entry=next(d for d in json.loads(text)['dependencies'] if d['name']=='iree_vulkan_runtime_patches')
tree=''.join(f'{p.relative_to(vendor).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n' for p in sorted(vendor.rglob('*')) if p.is_file())
text=text.replace(entry['vendored']['tree_sha256'],hashlib.sha256(tree.encode()).hexdigest())
ledger.write_bytes(text.encode())
