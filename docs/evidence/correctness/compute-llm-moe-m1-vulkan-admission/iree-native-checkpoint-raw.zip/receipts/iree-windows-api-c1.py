import ctypes
import json
from pathlib import Path
import subprocess
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path.cwd()
logs = root / '.scratch/validation/m1-vulkan-admission'
build = Path('C:/hv/selected/dd6ba9eea2aa2417e511/build-605ef2324f17e5ef3df1')
receipt = logs / 'iree-product-api-c1.json'
record = {'kind':'M1-V original IREE product adapter development; ordinary route/final gates pending',
          'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'status':'RUNNING','commands':[]}
def save(): receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
def run(label, argv):
    path=logs/('iree-api-c1-'+label+'.log')
    assert not path.exists()
    print('RUN',label,flush=True)
    start=time.time()
    with path.open('wb') as output:
        result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,timeout=1200)
    record['commands'].append({'label':label,'argv':argv,'exit_code':result.returncode,
        'elapsed_seconds':time.time()-start,'log':str(path)})
    save()
    if result.returncode:
        record['status']='FAIL';save()
        print(path.read_text(errors='replace')[-10000:],flush=True)
        raise SystemExit(result.returncode)
save()
run('configure',['cmake','-S',str(root),'-B',str(build),
    '-DHYLE_DEV_FACTORS=compute_ops,compute_provider_ggml_vulkan,compute_provider_iree_vulkan,compute_route_vulkan,graph_route_vulkan'])
run('build',['cmake','--build',str(build),'--parallel','2','--target','hyle_compute_provider_iree_vulkan_tests'])
run('tests',['ctest','--test-dir',str(build),'-L','^compute_provider_iree_vulkan$',
    '--output-on-failure','--no-tests=error','--timeout','180'])
record['status']='PASS';save()
print('IREE product native adapter tests PASS; ordinary route gates remain pending',flush=True)
