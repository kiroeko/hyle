#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg34: tensor<2x17xi32>, %arg35: tensor<2xi32>):
    %55 = "tensor.empty"() : () -> tensor<2x17xi32>
    %56:2 = "iree_linalg_ext.scan"(%arg34, %55, %arg35) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg36: i32, %arg37: i32):
      %57 = "arith.addi"(%arg36, %arg37) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%57) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%56#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg30: tensor<2x17xi32>, %arg31: tensor<2xi32>):
    %52 = "tensor.empty"() : () -> tensor<2x17xi32>
    %53:2 = "iree_linalg_ext.scan"(%arg30, %52, %arg31) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg32: i32, %arg33: i32):
      %54 = "arith.addi"(%arg32, %arg33) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%54) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%53#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x1xf32>, tensor<1x1xf32>) -> tensor<2x128xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg15: tensor<2x128xi8>, %arg16: tensor<128x128xi8>, %arg17: tensor<2x1xf32>, %arg18: tensor<1x1xf32>):
    %36 = "flow.tensor.bitcast"(%arg15) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %37 = "flow.tensor.bitcast"(%arg16) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %38 = "tensor.empty"() : () -> tensor<2x128xf32>
    %39 = "tensor.empty"() : () -> tensor<128x128xf32>
    %40 = "linalg.generic"(%36, %arg17, %38) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f32, %arg29: f32):
      %50 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %51 = "arith.mulf"(%50, %arg28) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%51) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x1xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %41 = "linalg.generic"(%37, %arg18, %39) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f32, %arg26: f32):
      %48 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %49 = "arith.mulf"(%48, %arg25) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%49) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<1x1xf32>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %42 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %43 = "tensor.empty"() : () -> tensor<2x128xf32>
    %44 = "linalg.fill"(%42, %43) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %45 = "linalg.matmul"(%40, %41, %44) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %46 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %47 = "arith.addf"(%arg21, %46) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%47) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%45) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x4xi8>, tensor<128x4xi8>) -> tensor<2x128xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg0: tensor<2x128xi8>, %arg1: tensor<128x128xi8>, %arg2: tensor<2x4xi8>, %arg3: tensor<128x4xi8>):
    %0 = "flow.tensor.bitcast"(%arg0) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %1 = "flow.tensor.bitcast"(%arg1) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %2 = "flow.tensor.bitcast"(%arg2) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x4xi8>) -> tensor<2x4xf8E8M0FNU>
    %3 = "flow.tensor.bitcast"(%arg3) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x4xi8>) -> tensor<128x4xf8E8M0FNU>
    %4 = "tensor.empty"() : () -> tensor<2x128xf32>
    %5 = "tensor.empty"() : () -> tensor<128x128xf32>
    %6 = "linalg.generic"(%0, %2, %4) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: f8E4M3FN, %arg13: f8E8M0FNU, %arg14: f32):
      %25 = "arith.extf"(%arg12) : (f8E4M3FN) -> f32
      %26 = "arith.bitcast"(%arg13) : (f8E8M0FNU) -> i8
      %27 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %28 = "arith.extui"(%26) : (i8) -> i32
      %29 = "arith.shli"(%28, %27) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %30 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %31 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %32 = "arith.cmpi"(%26, %30) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %33 = "arith.select"(%32, %31, %29) : (i1, i32, i32) -> i32
      %34 = "arith.bitcast"(%33) : (i32) -> f32
      %35 = "arith.mulf"(%25, %34) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%35) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x4xf8E8M0FNU>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %7 = "linalg.generic"(%1, %3, %5) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg9: f8E4M3FN, %arg10: f8E8M0FNU, %arg11: f32):
      %14 = "arith.extf"(%arg9) : (f8E4M3FN) -> f32
      %15 = "arith.bitcast"(%arg10) : (f8E8M0FNU) -> i8
      %16 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %17 = "arith.extui"(%15) : (i8) -> i32
      %18 = "arith.shli"(%17, %16) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %19 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %20 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %21 = "arith.cmpi"(%15, %19) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %22 = "arith.select"(%21, %20, %18) : (i1, i32, i32) -> i32
      %23 = "arith.bitcast"(%22) : (i32) -> f32
      %24 = "arith.mulf"(%14, %23) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%24) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<128x4xf8E8M0FNU>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %8 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %9 = "tensor.empty"() : () -> tensor<2x128xf32>
    %10 = "linalg.fill"(%8, %9) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg7: f32, %arg8: f32):
      "linalg.yield"(%arg7) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %11 = "linalg.matmul"(%6, %7, %10) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg4: f32, %arg5: f32, %arg6: f32):
      %12 = "arith.mulf"(%arg4, %arg5) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %13 = "arith.addf"(%arg6, %12) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%13) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%11) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
}) : () -> ()

