#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg34: tensor<2x17xi32>, %arg35: tensor<2xi32>):
    %41 = "tensor.empty"() : () -> tensor<2x17xi32>
    %42:2 = "iree_linalg_ext.scan"(%arg34, %41, %arg35) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg36: i32, %arg37: i32):
      %43 = "arith.addi"(%arg36, %arg37) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%43) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%42#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x17xi32>, tensor<2xi32>) -> tensor<2x17xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg30: tensor<2x17xi32>, %arg31: tensor<2xi32>):
    %38 = "tensor.empty"() : () -> tensor<2x17xi32>
    %39:2 = "iree_linalg_ext.scan"(%arg30, %38, %arg31) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg32: i32, %arg33: i32):
      %40 = "arith.addi"(%arg32, %arg33) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%40) : (i32) -> ()
    }) : (tensor<2x17xi32>, tensor<2x17xi32>, tensor<2xi32>) -> (tensor<2x17xi32>, tensor<2xi32>)
    "func.return"(%39#0) : (tensor<2x17xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x1xf32>, tensor<1x1xf32>) -> tensor<2x128xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg15: tensor<2x128xi8>, %arg16: tensor<128x128xi8>, %arg17: tensor<2x1xf32>, %arg18: tensor<1x1xf32>):
    %20 = "flow.tensor.bitcast"(%arg15) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %21 = "flow.tensor.bitcast"(%arg16) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %22 = "tensor.cast"(%arg17) : (tensor<2x1xf32>) -> tensor<2x1xf32>
    %23 = "tensor.cast"(%arg18) : (tensor<1x1xf32>) -> tensor<1x1xf32>
    %24 = "tensor.empty"() : () -> tensor<2x128xf32>
    %25 = "tensor.empty"() : () -> tensor<128x128xf32>
    %26 = "linalg.generic"(%20, %22, %24) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f32, %arg29: f32):
      %36 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %37 = "arith.mulf"(%36, %arg28) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%37) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x1xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %27 = "linalg.generic"(%21, %23, %25) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f32, %arg26: f32):
      %34 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %35 = "arith.mulf"(%34, %arg25) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%35) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<1x1xf32>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %28 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %29 = "tensor.empty"() : () -> tensor<2x128xf32>
    %30 = "linalg.fill"(%28, %29) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %31 = "linalg.matmul"(%26, %27, %30) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %32 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %33 = "arith.addf"(%arg21, %32) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%33) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%31) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<2x128xi8>, tensor<128x128xi8>, tensor<2x4xi8>, tensor<128x4xi8>) -> tensor<2x128xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg0: tensor<2x128xi8>, %arg1: tensor<128x128xi8>, %arg2: tensor<2x4xi8>, %arg3: tensor<128x4xi8>):
    %0 = "flow.tensor.bitcast"(%arg0) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x128xi8>) -> tensor<2x128xf8E4M3FN>
    %1 = "flow.tensor.bitcast"(%arg1) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x128xi8>) -> tensor<128x128xf8E4M3FN>
    %2 = "flow.tensor.bitcast"(%arg2) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<2x4xi8>) -> tensor<2x4xf8E8M0FNU>
    %3 = "flow.tensor.bitcast"(%arg3) <{operandSegmentSizes = array<i32: 1, 0, 0>}> : (tensor<128x4xi8>) -> tensor<128x4xf8E8M0FNU>
    %4 = "tensor.empty"() : () -> tensor<2x128xf32>
    %5 = "tensor.empty"() : () -> tensor<128x128xf32>
    %6 = "linalg.generic"(%0, %2, %4) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: f8E4M3FN, %arg13: f8E8M0FNU, %arg14: f32):
      %17 = "arith.extf"(%arg12) : (f8E4M3FN) -> f32
      %18 = "arith.extf"(%arg13) : (f8E8M0FNU) -> f32
      %19 = "arith.mulf"(%17, %18) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%19) : (f32) -> ()
    }) : (tensor<2x128xf8E4M3FN>, tensor<2x4xf8E8M0FNU>, tensor<2x128xf32>) -> tensor<2x128xf32>
    %7 = "linalg.generic"(%1, %3, %5) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg9: f8E4M3FN, %arg10: f8E8M0FNU, %arg11: f32):
      %14 = "arith.extf"(%arg9) : (f8E4M3FN) -> f32
      %15 = "arith.extf"(%arg10) : (f8E8M0FNU) -> f32
      %16 = "arith.mulf"(%14, %15) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%16) : (f32) -> ()
    }) : (tensor<128x128xf8E4M3FN>, tensor<128x4xf8E8M0FNU>, tensor<128x128xf32>) -> tensor<128x128xf32>
    %8 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %9 = "tensor.empty"() : () -> tensor<2x128xf32>
    %10 = "linalg.fill"(%8, %9) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg7: f32, %arg8: f32):
      "linalg.yield"(%arg7) : (f32) -> ()
    }) : (f32, tensor<2x128xf32>) -> tensor<2x128xf32>
    %11 = "linalg.matmul"(%6, %7, %10) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg4: f32, %arg5: f32, %arg6: f32):
      %12 = "arith.mulf"(%arg4, %arg5) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %13 = "arith.addf"(%arg6, %12) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%13) : (f32) -> ()
    }) : (tensor<2x128xf32>, tensor<128x128xf32>, tensor<2x128xf32>) -> tensor<2x128xf32>
    "func.return"(%11) : (tensor<2x128xf32>) -> ()
  }) : () -> ()
}) : () -> ()

