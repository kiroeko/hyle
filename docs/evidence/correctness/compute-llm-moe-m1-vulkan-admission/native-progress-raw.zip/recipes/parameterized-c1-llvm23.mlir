#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<?x?xi32>, tensor<?xi32>) -> tensor<?x?xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg34: tensor<?x?xi32>, %arg35: tensor<?xi32>):
    %75 = "arith.constant"() <{value = 0 : index}> : () -> index
    %76 = "arith.constant"() <{value = 1 : index}> : () -> index
    %77 = "tensor.dim"(%arg34, %75) : (tensor<?x?xi32>, index) -> index
    %78 = "tensor.dim"(%arg34, %76) : (tensor<?x?xi32>, index) -> index
    %79 = "tensor.empty"(%77, %78) : (index, index) -> tensor<?x?xi32>
    %80:2 = "iree_linalg_ext.scan"(%arg34, %79, %arg35) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg36: i32, %arg37: i32):
      %81 = "arith.addi"(%arg36, %arg37) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%81) : (i32) -> ()
    }) : (tensor<?x?xi32>, tensor<?x?xi32>, tensor<?xi32>) -> (tensor<?x?xi32>, tensor<?xi32>)
    "func.return"(%80#0) : (tensor<?x?xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi32>, tensor<?xi32>) -> tensor<?x?xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg30: tensor<?x?xi32>, %arg31: tensor<?xi32>):
    %68 = "arith.constant"() <{value = 0 : index}> : () -> index
    %69 = "arith.constant"() <{value = 1 : index}> : () -> index
    %70 = "tensor.dim"(%arg30, %68) : (tensor<?x?xi32>, index) -> index
    %71 = "tensor.dim"(%arg30, %69) : (tensor<?x?xi32>, index) -> index
    %72 = "tensor.empty"(%70, %71) : (index, index) -> tensor<?x?xi32>
    %73:2 = "iree_linalg_ext.scan"(%arg30, %72, %arg31) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg32: i32, %arg33: i32):
      %74 = "arith.addi"(%arg32, %arg33) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%74) : (i32) -> ()
    }) : (tensor<?x?xi32>, tensor<?x?xi32>, tensor<?xi32>) -> (tensor<?x?xi32>, tensor<?xi32>)
    "func.return"(%73#0) : (tensor<?x?xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg15: tensor<?x?xi8>, %arg16: tensor<?x?xi8>, %arg17: tensor<?x?xf32>, %arg18: tensor<?x?xf32>):
    %45 = "arith.constant"() <{value = 0 : index}> : () -> index
    %46 = "arith.constant"() <{value = 1 : index}> : () -> index
    %47 = "tensor.dim"(%arg15, %45) : (tensor<?x?xi8>, index) -> index
    %48 = "tensor.dim"(%arg15, %46) : (tensor<?x?xi8>, index) -> index
    %49 = "tensor.dim"(%arg16, %45) : (tensor<?x?xi8>, index) -> index
    %50 = "flow.tensor.bitcast"(%arg15, %47, %48, %47, %48) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %51 = "flow.tensor.bitcast"(%arg16, %49, %48, %49, %48) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %52 = "tensor.empty"(%47, %48) : (index, index) -> tensor<?x?xf32>
    %53 = "tensor.empty"(%49, %48) : (index, index) -> tensor<?x?xf32>
    %54 = "linalg.generic"(%50, %arg17, %52) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f32, %arg29: f32):
      %66 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %67 = "arith.mulf"(%66, %arg28) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%67) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %55 = "linalg.generic"(%51, %arg18, %53) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f32, %arg26: f32):
      %64 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %65 = "arith.mulf"(%64, %arg25) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%65) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %56 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %57 = "tensor.empty"(%47, %49) : (index, index) -> tensor<?x?xf32>
    %58 = "linalg.fill"(%56, %57) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<?x?xf32>) -> tensor<?x?xf32>
    %59 = "util.optimization_barrier"(%54) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %60 = "util.optimization_barrier"(%55) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %61 = "linalg.matmul"(%59, %60, %58) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %62 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %63 = "arith.addf"(%arg21, %62) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%63) : (f32) -> ()
    }) : (tensor<?x?xf32>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    "func.return"(%61) : (tensor<?x?xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xi8>) -> tensor<?x?xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg0: tensor<?x?xi8>, %arg1: tensor<?x?xi8>, %arg2: tensor<?x?xi8>, %arg3: tensor<?x?xi8>):
    %0 = "arith.constant"() <{value = 0 : index}> : () -> index
    %1 = "arith.constant"() <{value = 1 : index}> : () -> index
    %2 = "tensor.dim"(%arg0, %0) : (tensor<?x?xi8>, index) -> index
    %3 = "tensor.dim"(%arg0, %1) : (tensor<?x?xi8>, index) -> index
    %4 = "tensor.dim"(%arg1, %0) : (tensor<?x?xi8>, index) -> index
    %5 = "tensor.dim"(%arg2, %1) : (tensor<?x?xi8>, index) -> index
    %6 = "tensor.dim"(%arg3, %1) : (tensor<?x?xi8>, index) -> index
    %7 = "flow.tensor.bitcast"(%arg0, %2, %3, %2, %3) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %8 = "flow.tensor.bitcast"(%arg1, %4, %3, %4, %3) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %9 = "flow.tensor.bitcast"(%arg2, %2, %5, %2, %5) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E8M0FNU>
    %10 = "flow.tensor.bitcast"(%arg3, %4, %6, %4, %6) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E8M0FNU>
    %11 = "tensor.empty"(%2, %3) : (index, index) -> tensor<?x?xf32>
    %12 = "tensor.empty"(%4, %3) : (index, index) -> tensor<?x?xf32>
    %13 = "linalg.generic"(%7, %9, %11) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: f8E4M3FN, %arg13: f8E8M0FNU, %arg14: f32):
      %34 = "arith.extf"(%arg12) : (f8E4M3FN) -> f32
      %35 = "arith.bitcast"(%arg13) : (f8E8M0FNU) -> i8
      %36 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %37 = "arith.extui"(%35) : (i8) -> i32
      %38 = "arith.shli"(%37, %36) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %39 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %40 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %41 = "arith.cmpi"(%35, %39) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %42 = "arith.select"(%41, %40, %38) : (i1, i32, i32) -> i32
      %43 = "arith.bitcast"(%42) : (i32) -> f32
      %44 = "arith.mulf"(%34, %43) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%44) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf8E8M0FNU>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %14 = "linalg.generic"(%8, %10, %12) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg9: f8E4M3FN, %arg10: f8E8M0FNU, %arg11: f32):
      %23 = "arith.extf"(%arg9) : (f8E4M3FN) -> f32
      %24 = "arith.bitcast"(%arg10) : (f8E8M0FNU) -> i8
      %25 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %26 = "arith.extui"(%24) : (i8) -> i32
      %27 = "arith.shli"(%26, %25) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %28 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %29 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %30 = "arith.cmpi"(%24, %28) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %31 = "arith.select"(%30, %29, %27) : (i1, i32, i32) -> i32
      %32 = "arith.bitcast"(%31) : (i32) -> f32
      %33 = "arith.mulf"(%23, %32) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%33) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf8E8M0FNU>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %15 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %16 = "tensor.empty"(%2, %4) : (index, index) -> tensor<?x?xf32>
    %17 = "linalg.fill"(%15, %16) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg7: f32, %arg8: f32):
      "linalg.yield"(%arg7) : (f32) -> ()
    }) : (f32, tensor<?x?xf32>) -> tensor<?x?xf32>
    %18 = "util.optimization_barrier"(%13) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %19 = "util.optimization_barrier"(%14) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %20 = "linalg.matmul"(%18, %19, %17) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg4: f32, %arg5: f32, %arg6: f32):
      %21 = "arith.mulf"(%arg4, %arg5) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %22 = "arith.addf"(%arg6, %21) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%22) : (f32) -> ()
    }) : (tensor<?x?xf32>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    "func.return"(%20) : (tensor<?x?xf32>) -> ()
  }) : () -> ()
}) : () -> ()

