#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<?x?xi32>, tensor<?xi32>) -> tensor<?x?xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg34: tensor<?x?xi32>, %arg35: tensor<?xi32>):
    %71 = "arith.constant"() <{value = 0 : index}> : () -> index
    %72 = "arith.constant"() <{value = 1 : index}> : () -> index
    %73 = "tensor.dim"(%arg34, %71) : (tensor<?x?xi32>, index) -> index
    %74 = "tensor.dim"(%arg34, %72) : (tensor<?x?xi32>, index) -> index
    %75 = "tensor.empty"(%73, %74) : (index, index) -> tensor<?x?xi32>
    %76:2 = "iree_linalg_ext.scan"(%arg34, %75, %arg35) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg36: i32, %arg37: i32):
      %77 = "arith.addi"(%arg36, %arg37) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%77) : (i32) -> ()
    }) : (tensor<?x?xi32>, tensor<?x?xi32>, tensor<?xi32>) -> (tensor<?x?xi32>, tensor<?xi32>)
    "func.return"(%76#0) : (tensor<?x?xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi32>, tensor<?xi32>) -> tensor<?x?xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg30: tensor<?x?xi32>, %arg31: tensor<?xi32>):
    %64 = "arith.constant"() <{value = 0 : index}> : () -> index
    %65 = "arith.constant"() <{value = 1 : index}> : () -> index
    %66 = "tensor.dim"(%arg30, %64) : (tensor<?x?xi32>, index) -> index
    %67 = "tensor.dim"(%arg30, %65) : (tensor<?x?xi32>, index) -> index
    %68 = "tensor.empty"(%66, %67) : (index, index) -> tensor<?x?xi32>
    %69:2 = "iree_linalg_ext.scan"(%arg30, %68, %arg31) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg32: i32, %arg33: i32):
      %70 = "arith.addi"(%arg32, %arg33) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%70) : (i32) -> ()
    }) : (tensor<?x?xi32>, tensor<?x?xi32>, tensor<?xi32>) -> (tensor<?x?xi32>, tensor<?xi32>)
    "func.return"(%69#0) : (tensor<?x?xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg15: tensor<?x?xi8>, %arg16: tensor<?x?xi8>, %arg17: tensor<?x?xf32>, %arg18: tensor<?x?xf32>):
    %43 = "arith.constant"() <{value = 0 : index}> : () -> index
    %44 = "arith.constant"() <{value = 1 : index}> : () -> index
    %45 = "tensor.dim"(%arg15, %43) : (tensor<?x?xi8>, index) -> index
    %46 = "tensor.dim"(%arg15, %44) : (tensor<?x?xi8>, index) -> index
    %47 = "tensor.dim"(%arg16, %43) : (tensor<?x?xi8>, index) -> index
    %48 = "flow.tensor.bitcast"(%arg15, %45, %46, %45, %46) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %49 = "flow.tensor.bitcast"(%arg16, %47, %46, %47, %46) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %50 = "tensor.empty"(%45, %46) : (index, index) -> tensor<?x?xf32>
    %51 = "tensor.empty"(%47, %46) : (index, index) -> tensor<?x?xf32>
    %52 = "linalg.generic"(%48, %arg17, %50) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f32, %arg29: f32):
      %62 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %63 = "arith.mulf"(%62, %arg28) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%63) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %53 = "linalg.generic"(%49, %arg18, %51) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f32, %arg26: f32):
      %60 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %61 = "arith.mulf"(%60, %arg25) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%61) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %54 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %55 = "tensor.empty"(%45, %47) : (index, index) -> tensor<?x?xf32>
    %56 = "linalg.fill"(%54, %55) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<?x?xf32>) -> tensor<?x?xf32>
    %57 = "linalg.matmul"(%52, %53, %56) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %58 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %59 = "arith.addf"(%arg21, %58) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%59) : (f32) -> ()
    }) : (tensor<?x?xf32>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    "func.return"(%57) : (tensor<?x?xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xi8>) -> tensor<?x?xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg0: tensor<?x?xi8>, %arg1: tensor<?x?xi8>, %arg2: tensor<?x?xi8>, %arg3: tensor<?x?xi8>):
    %0 = "arith.constant"() <{value = 0 : index}> : () -> index
    %1 = "arith.constant"() <{value = 1 : index}> : () -> index
    %2 = "tensor.dim"(%arg0, %0) : (tensor<?x?xi8>, index) -> index
    %3 = "tensor.dim"(%arg0, %1) : (tensor<?x?xi8>, index) -> index
    %4 = "tensor.dim"(%arg1, %0) : (tensor<?x?xi8>, index) -> index
    %5 = "tensor.dim"(%arg2, %1) : (tensor<?x?xi8>, index) -> index
    %6 = "tensor.dim"(%arg3, %1) : (tensor<?x?xi8>, index) -> index
    %7 = "flow.tensor.bitcast"(%arg0, %2, %3, %2, %3) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %8 = "flow.tensor.bitcast"(%arg1, %4, %3, %4, %3) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %9 = "flow.tensor.bitcast"(%arg2, %2, %5, %2, %5) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E8M0FNU>
    %10 = "flow.tensor.bitcast"(%arg3, %4, %6, %4, %6) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E8M0FNU>
    %11 = "tensor.empty"(%2, %3) : (index, index) -> tensor<?x?xf32>
    %12 = "tensor.empty"(%4, %3) : (index, index) -> tensor<?x?xf32>
    %13 = "linalg.generic"(%7, %9, %11) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: f8E4M3FN, %arg13: f8E8M0FNU, %arg14: f32):
      %32 = "arith.extf"(%arg12) : (f8E4M3FN) -> f32
      %33 = "arith.bitcast"(%arg13) : (f8E8M0FNU) -> i8
      %34 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %35 = "arith.extui"(%33) : (i8) -> i32
      %36 = "arith.shli"(%35, %34) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %37 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %38 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %39 = "arith.cmpi"(%33, %37) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %40 = "arith.select"(%39, %38, %36) : (i1, i32, i32) -> i32
      %41 = "arith.bitcast"(%40) : (i32) -> f32
      %42 = "arith.mulf"(%32, %41) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%42) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf8E8M0FNU>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %14 = "linalg.generic"(%8, %10, %12) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg9: f8E4M3FN, %arg10: f8E8M0FNU, %arg11: f32):
      %21 = "arith.extf"(%arg9) : (f8E4M3FN) -> f32
      %22 = "arith.bitcast"(%arg10) : (f8E8M0FNU) -> i8
      %23 = "arith.constant"() <{value = 23 : i32}> : () -> i32
      %24 = "arith.extui"(%22) : (i8) -> i32
      %25 = "arith.shli"(%24, %23) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      %26 = "arith.constant"() <{value = -1 : i8}> : () -> i8
      %27 = "arith.constant"() <{value = -1 : i32}> : () -> i32
      %28 = "arith.cmpi"(%22, %26) <{predicate = 0 : i64}> : (i8, i8) -> i1
      %29 = "arith.select"(%28, %27, %25) : (i1, i32, i32) -> i32
      %30 = "arith.bitcast"(%29) : (i32) -> f32
      %31 = "arith.mulf"(%21, %30) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%31) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf8E8M0FNU>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %15 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %16 = "tensor.empty"(%2, %4) : (index, index) -> tensor<?x?xf32>
    %17 = "linalg.fill"(%15, %16) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg7: f32, %arg8: f32):
      "linalg.yield"(%arg7) : (f32) -> ()
    }) : (f32, tensor<?x?xf32>) -> tensor<?x?xf32>
    %18 = "linalg.matmul"(%13, %14, %17) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg4: f32, %arg5: f32, %arg6: f32):
      %19 = "arith.mulf"(%arg4, %arg5) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %20 = "arith.addf"(%arg6, %19) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%20) : (f32) -> ()
    }) : (tensor<?x?xf32>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    "func.return"(%18) : (tensor<?x?xf32>) -> ()
  }) : () -> ()
}) : () -> ()

