module {
func.func @scan_inclusive(%input: tensor<2x17xi32>, %initial: tensor<2xi32>) -> tensor<2x17xi32> {
  %empty = tensor.empty() : tensor<2x17xi32>
  %result:2 = iree_linalg_ext.scan dimension(1) inclusive(true)
      ins(%input : tensor<2x17xi32>) outs(%empty, %initial : tensor<2x17xi32>, tensor<2xi32>) {
    ^bb0(%left: i32, %right: i32):
      %sum = arith.addi %left, %right : i32
      iree_linalg_ext.yield %sum : i32
  } -> tensor<2x17xi32>, tensor<2xi32>
  return %result#0 : tensor<2x17xi32>
}

func.func @scan_exclusive(%input: tensor<2x17xi32>, %initial: tensor<2xi32>) -> tensor<2x17xi32> {
  %empty = tensor.empty() : tensor<2x17xi32>
  %result:2 = iree_linalg_ext.scan dimension(1) inclusive(false)
      ins(%input : tensor<2x17xi32>) outs(%empty, %initial : tensor<2x17xi32>, tensor<2xi32>) {
    ^bb0(%left: i32, %right: i32):
      %sum = arith.addi %left, %right : i32
      iree_linalg_ext.yield %sum : i32
  } -> tensor<2x17xi32>, tensor<2xi32>
  return %result#0 : tensor<2x17xi32>
}

func.func @fp8_f32_scale(%lhs: tensor<2x128xi8>, %rhs: tensor<128x128xi8>, %lhs_scale: tensor<2x1xf32>, %rhs_scale: tensor<1x1xf32>) -> tensor<2x128xf32> {
  %l = flow.tensor.bitcast %lhs : tensor<2x128xi8> -> tensor<2x128xf8E4M3FN>
  %r = flow.tensor.bitcast %rhs : tensor<128x128xi8> -> tensor<128x128xf8E4M3FN>
  %ls = tensor.cast %lhs_scale : tensor<2x1xf32> to tensor<2x1xf32>
  %rs = tensor.cast %rhs_scale : tensor<1x1xf32> to tensor<1x1xf32>
  %le = tensor.empty() : tensor<2x128xf32>
  %re = tensor.empty() : tensor<128x128xf32>
  %lw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1 floordiv 128)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%l, %ls : tensor<2x128xf8E4M3FN>, tensor<2x1xf32>) outs(%le : tensor<2x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f32, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %scaled = arith.mulf %wide, %scale : f32
      linalg.yield %scaled : f32
  } -> tensor<2x128xf32>
  %rw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0 floordiv 128, d1 floordiv 128)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%r, %rs : tensor<128x128xf8E4M3FN>, tensor<1x1xf32>) outs(%re : tensor<128x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f32, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %scaled = arith.mulf %wide, %scale : f32
      linalg.yield %scaled : f32
  } -> tensor<128x128xf32>
  %zero = arith.constant 0.0 : f32
  %empty = tensor.empty() : tensor<2x128xf32>
  %init = linalg.fill ins(%zero : f32) outs(%empty : tensor<2x128xf32>) -> tensor<2x128xf32>
  %result = linalg.matmul indexing_maps = [affine_map<(d0,d1,d2)->(d0,d2)>,affine_map<(d0,d1,d2)->(d1,d2)>,affine_map<(d0,d1,d2)->(d0,d1)>] ins(%lw, %rw : tensor<2x128xf32>, tensor<128x128xf32>) outs(%init : tensor<2x128xf32>) -> tensor<2x128xf32>
  return %result : tensor<2x128xf32>
}

func.func @fp8_ue8_scale(%lhs: tensor<2x128xi8>, %rhs: tensor<128x128xi8>, %lhs_scale: tensor<2x4xi8>, %rhs_scale: tensor<128x4xi8>) -> tensor<2x128xf32> {
  %l = flow.tensor.bitcast %lhs : tensor<2x128xi8> -> tensor<2x128xf8E4M3FN>
  %r = flow.tensor.bitcast %rhs : tensor<128x128xi8> -> tensor<128x128xf8E4M3FN>
  %ls = flow.tensor.bitcast %lhs_scale : tensor<2x4xi8> -> tensor<2x4xf8E8M0FNU>
  %rs = flow.tensor.bitcast %rhs_scale : tensor<128x4xi8> -> tensor<128x4xf8E8M0FNU>
  %le = tensor.empty() : tensor<2x128xf32>
  %re = tensor.empty() : tensor<128x128xf32>
  %lw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0,d1 floordiv 32)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%l, %ls : tensor<2x128xf8E4M3FN>, tensor<2x4xf8E8M0FNU>) outs(%le : tensor<2x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f8E8M0FNU, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %factor = arith.extf %scale : f8E8M0FNU to f32
      %scaled = arith.mulf %wide, %factor : f32
      linalg.yield %scaled : f32
  } -> tensor<2x128xf32>
  %rw = linalg.generic {indexing_maps = [affine_map<(d0,d1)->(d0,d1)>, affine_map<(d0,d1)->(d0, d1 floordiv 32)>, affine_map<(d0,d1)->(d0,d1)>], iterator_types = ["parallel","parallel"]}
      ins(%r, %rs : tensor<128x128xf8E4M3FN>, tensor<128x4xf8E8M0FNU>) outs(%re : tensor<128x128xf32>) {
    ^bb0(%value: f8E4M3FN, %scale: f8E8M0FNU, %unused: f32):
      %wide = arith.extf %value : f8E4M3FN to f32
      %factor = arith.extf %scale : f8E8M0FNU to f32
      %scaled = arith.mulf %wide, %factor : f32
      linalg.yield %scaled : f32
  } -> tensor<128x128xf32>
  %zero = arith.constant 0.0 : f32
  %empty = tensor.empty() : tensor<2x128xf32>
  %init = linalg.fill ins(%zero : f32) outs(%empty : tensor<2x128xf32>) -> tensor<2x128xf32>
  %result = linalg.matmul indexing_maps = [affine_map<(d0,d1,d2)->(d0,d2)>,affine_map<(d0,d1,d2)->(d1,d2)>,affine_map<(d0,d1,d2)->(d0,d1)>] ins(%lw, %rw : tensor<2x128xf32>, tensor<128x128xf32>) outs(%init : tensor<2x128xf32>) -> tensor<2x128xf32>
  return %result : tensor<2x128xf32>
}

}
