#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d0, d1 floordiv 128)>
#map2 = affine_map<(d0, d1) -> (d0 floordiv 128, d1 floordiv 128)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map4 = affine_map<(d0, d1, d2) -> (d1, d2)>
#map5 = affine_map<(d0, d1, d2) -> (d0, d1)>
#map6 = affine_map<(d0, d1) -> (d0, d1 floordiv 32)>
"builtin.module"() ({
  "func.func"() <{function_type = (tensor<?x?xi32>, tensor<?xi32>) -> tensor<?x?xi32>, sym_name = "scan_inclusive"}> ({
  ^bb0(%arg34: tensor<?x?xi32>, %arg35: tensor<?xi32>):
    %61 = "arith.constant"() <{value = 0 : index}> : () -> index
    %62 = "arith.constant"() <{value = 1 : index}> : () -> index
    %63 = "tensor.dim"(%arg34, %61) : (tensor<?x?xi32>, index) -> index
    %64 = "tensor.dim"(%arg34, %62) : (tensor<?x?xi32>, index) -> index
    %65 = "tensor.empty"(%63, %64) : (index, index) -> tensor<?x?xi32>
    %66:2 = "iree_linalg_ext.scan"(%arg34, %65, %arg35) <{dimension = 1 : i64, inclusive = true}> ({
    ^bb0(%arg36: i32, %arg37: i32):
      %67 = "arith.addi"(%arg36, %arg37) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%67) : (i32) -> ()
    }) : (tensor<?x?xi32>, tensor<?x?xi32>, tensor<?xi32>) -> (tensor<?x?xi32>, tensor<?xi32>)
    "func.return"(%66#0) : (tensor<?x?xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi32>, tensor<?xi32>) -> tensor<?x?xi32>, sym_name = "scan_exclusive"}> ({
  ^bb0(%arg30: tensor<?x?xi32>, %arg31: tensor<?xi32>):
    %54 = "arith.constant"() <{value = 0 : index}> : () -> index
    %55 = "arith.constant"() <{value = 1 : index}> : () -> index
    %56 = "tensor.dim"(%arg30, %54) : (tensor<?x?xi32>, index) -> index
    %57 = "tensor.dim"(%arg30, %55) : (tensor<?x?xi32>, index) -> index
    %58 = "tensor.empty"(%56, %57) : (index, index) -> tensor<?x?xi32>
    %59:2 = "iree_linalg_ext.scan"(%arg30, %58, %arg31) <{dimension = 1 : i64, inclusive = false}> ({
    ^bb0(%arg32: i32, %arg33: i32):
      %60 = "arith.addi"(%arg32, %arg33) <{overflowFlags = #arith.overflow<none>}> : (i32, i32) -> i32
      "iree_linalg_ext.yield"(%60) : (i32) -> ()
    }) : (tensor<?x?xi32>, tensor<?x?xi32>, tensor<?xi32>) -> (tensor<?x?xi32>, tensor<?xi32>)
    "func.return"(%59#0) : (tensor<?x?xi32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>, sym_name = "fp8_f32_scale"}> ({
  ^bb0(%arg15: tensor<?x?xi8>, %arg16: tensor<?x?xi8>, %arg17: tensor<?x?xf32>, %arg18: tensor<?x?xf32>):
    %29 = "arith.constant"() <{value = 0 : index}> : () -> index
    %30 = "arith.constant"() <{value = 1 : index}> : () -> index
    %31 = "tensor.dim"(%arg15, %29) : (tensor<?x?xi8>, index) -> index
    %32 = "tensor.dim"(%arg15, %30) : (tensor<?x?xi8>, index) -> index
    %33 = "tensor.dim"(%arg16, %29) : (tensor<?x?xi8>, index) -> index
    %34 = "flow.tensor.bitcast"(%arg15, %31, %32, %31, %32) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %35 = "flow.tensor.bitcast"(%arg16, %33, %32, %33, %32) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %36 = "tensor.cast"(%arg17) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %37 = "tensor.cast"(%arg18) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %38 = "tensor.empty"(%31, %32) : (index, index) -> tensor<?x?xf32>
    %39 = "tensor.empty"(%33, %32) : (index, index) -> tensor<?x?xf32>
    %40 = "linalg.generic"(%34, %36, %38) <{indexing_maps = [#map, #map1, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg27: f8E4M3FN, %arg28: f32, %arg29: f32):
      %52 = "arith.extf"(%arg27) : (f8E4M3FN) -> f32
      %53 = "arith.mulf"(%52, %arg28) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%53) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %41 = "linalg.generic"(%35, %37, %39) <{indexing_maps = [#map, #map2, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg24: f8E4M3FN, %arg25: f32, %arg26: f32):
      %50 = "arith.extf"(%arg24) : (f8E4M3FN) -> f32
      %51 = "arith.mulf"(%50, %arg25) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%51) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %42 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %43 = "tensor.empty"(%31, %33) : (index, index) -> tensor<?x?xf32>
    %44 = "linalg.fill"(%42, %43) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg22: f32, %arg23: f32):
      "linalg.yield"(%arg22) : (f32) -> ()
    }) : (f32, tensor<?x?xf32>) -> tensor<?x?xf32>
    %45 = "util.optimization_barrier"(%40) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %46 = "util.optimization_barrier"(%41) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %47 = "linalg.matmul"(%45, %46, %44) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg19: f32, %arg20: f32, %arg21: f32):
      %48 = "arith.mulf"(%arg19, %arg20) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %49 = "arith.addf"(%arg21, %48) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%49) : (f32) -> ()
    }) : (tensor<?x?xf32>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    "func.return"(%47) : (tensor<?x?xf32>) -> ()
  }) : () -> ()
  "func.func"() <{function_type = (tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xi8>, tensor<?x?xi8>) -> tensor<?x?xf32>, sym_name = "fp8_ue8_scale"}> ({
  ^bb0(%arg0: tensor<?x?xi8>, %arg1: tensor<?x?xi8>, %arg2: tensor<?x?xi8>, %arg3: tensor<?x?xi8>):
    %0 = "arith.constant"() <{value = 0 : index}> : () -> index
    %1 = "arith.constant"() <{value = 1 : index}> : () -> index
    %2 = "tensor.dim"(%arg0, %0) : (tensor<?x?xi8>, index) -> index
    %3 = "tensor.dim"(%arg0, %1) : (tensor<?x?xi8>, index) -> index
    %4 = "tensor.dim"(%arg1, %0) : (tensor<?x?xi8>, index) -> index
    %5 = "tensor.dim"(%arg2, %1) : (tensor<?x?xi8>, index) -> index
    %6 = "tensor.dim"(%arg3, %1) : (tensor<?x?xi8>, index) -> index
    %7 = "flow.tensor.bitcast"(%arg0, %2, %3, %2, %3) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %8 = "flow.tensor.bitcast"(%arg1, %4, %3, %4, %3) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E4M3FN>
    %9 = "flow.tensor.bitcast"(%arg2, %2, %5, %2, %5) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E8M0FNU>
    %10 = "flow.tensor.bitcast"(%arg3, %4, %6, %4, %6) <{operandSegmentSizes = array<i32: 1, 2, 2>}> : (tensor<?x?xi8>, index, index, index, index) -> tensor<?x?xf8E8M0FNU>
    %11 = "tensor.empty"(%2, %3) : (index, index) -> tensor<?x?xf32>
    %12 = "tensor.empty"(%4, %3) : (index, index) -> tensor<?x?xf32>
    %13 = "linalg.generic"(%7, %9, %11) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg12: f8E4M3FN, %arg13: f8E8M0FNU, %arg14: f32):
      %26 = "arith.extf"(%arg12) : (f8E4M3FN) -> f32
      %27 = "arith.extf"(%arg13) : (f8E8M0FNU) -> f32
      %28 = "arith.mulf"(%26, %27) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%28) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf8E8M0FNU>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %14 = "linalg.generic"(%8, %10, %12) <{indexing_maps = [#map, #map6, #map], iterator_types = [#linalg.iterator_type<parallel>, #linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg9: f8E4M3FN, %arg10: f8E8M0FNU, %arg11: f32):
      %23 = "arith.extf"(%arg9) : (f8E4M3FN) -> f32
      %24 = "arith.extf"(%arg10) : (f8E8M0FNU) -> f32
      %25 = "arith.mulf"(%23, %24) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%25) : (f32) -> ()
    }) : (tensor<?x?xf8E4M3FN>, tensor<?x?xf8E8M0FNU>, tensor<?x?xf32>) -> tensor<?x?xf32>
    %15 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %16 = "tensor.empty"(%2, %4) : (index, index) -> tensor<?x?xf32>
    %17 = "linalg.fill"(%15, %16) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg7: f32, %arg8: f32):
      "linalg.yield"(%arg7) : (f32) -> ()
    }) : (f32, tensor<?x?xf32>) -> tensor<?x?xf32>
    %18 = "util.optimization_barrier"(%13) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %19 = "util.optimization_barrier"(%14) : (tensor<?x?xf32>) -> tensor<?x?xf32>
    %20 = "linalg.matmul"(%18, %19, %17) <{indexing_maps = [#map3, #map4, #map5], operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg4: f32, %arg5: f32, %arg6: f32):
      %21 = "arith.mulf"(%arg4, %arg5) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %22 = "arith.addf"(%arg6, %21) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%22) : (f32) -> ()
    }) : (tensor<?x?xf32>, tensor<?x?xf32>, tensor<?x?xf32>) -> tensor<?x?xf32>
    "func.return"(%20) : (tensor<?x?xf32>) -> ()
  }) : () -> ()
}) : () -> ()

