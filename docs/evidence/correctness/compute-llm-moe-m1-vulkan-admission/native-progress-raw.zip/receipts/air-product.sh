#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-product
test "$(cat "$task/owner.txt")" = 'M1-V product db770b6fc1e46aa8d8aa86c1102d50acf26eb49f'
test ! -L "$task"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
mkdir "$task/source" "$task/logs"
tar -xzf "$task/product.tar.gz" -C "$task/source"
cmake -S "$task/source" -B "$task/native" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON \
  -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON \
  -DHYLE_DEV_FACTORS=compute_provider_ggml_vulkan,compute_route_vulkan,graph_route_vulkan \
  -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF \
  -DHYLE_COMPUTE_VULKAN=ON -DHYLE_COMPUTE_ONEDNN=OFF \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 > "$task/logs/configure.log" 2>&1
cmake --build "$task/native" --parallel 2 --target hyle_compute_provider_ggml_vulkan_tests \
  hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests > "$task/logs/build.log" 2>&1
ctest --test-dir "$task/native" -L '^(compute_provider_ggml_vulkan|compute_route_vulkan|graph_route_vulkan)$' \
  --output-on-failure --no-tests=error --timeout 240 > "$task/logs/tests.log" 2>&1
cat "$task/logs/tests.log"
