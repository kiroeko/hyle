$ErrorActionPreference = 'Stop'
$m1vRoot = 'C:\public\project-hyle\hyle'
$m1vLogs = Join-Path $m1vRoot '.scratch\validation\m1-vulkan-admission'
$m1vScratch = 'C:\hv\selected'
if (-not (Test-Path -LiteralPath 'C:\hv\m1v-owner.txt') -or
    ((Get-Item -LiteralPath 'C:\hv').Attributes -band [IO.FileAttributes]::ReparsePoint)) {
  throw 'M1-V scratch ownership mismatch'
}
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:MAX_JOBS = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1vSelectorErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1vSelectorErrorMode]::SetErrorMode(0x8003)
# Import the existing selected VS environment without creating an extra build.
$m1vVswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$m1vInstallation = & $m1vVswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if ($LASTEXITCODE -ne 0 -or -not $m1vInstallation) { throw 'MSVC installation unavailable' }
$m1vVsDevCmd = Join-Path $m1vInstallation 'Common7\Tools\VsDevCmd.bat'
$m1vEnvironmentCommand = 'call "' + $m1vVsDevCmd + '" -arch=x64 >nul && set'
$m1vEnvironmentLines = & $env:ComSpec /d /s /c $m1vEnvironmentCommand
if ($LASTEXITCODE -ne 0) { throw 'MSVC environment import failed' }
foreach ($line in $m1vEnvironmentLines) {
  $separator = $line.IndexOf('=')
  if ($separator -le 0) { continue }
  $name = $line.Substring(0, $separator)
  $value = $line.Substring($separator + 1)
  if ($name -ieq 'Path') {
    if ($value -like "*$m1vInstallation\VC\Tools\MSVC\*") {
      Set-Item -Path 'Env:Path' -Value $value
    }
  } else {
    Set-Item -Path "Env:$name" -Value $value
  }
}
$env:Path = 'C:\public\tools\glslang;C:\public\tools\hyle-vulkan\1.4.357.0\Bin;' + $env:Path
& python -X utf8 .scratch/validation/m1-vulkan-admission/interop-windows-inflight.py
exit $LASTEXITCODE
