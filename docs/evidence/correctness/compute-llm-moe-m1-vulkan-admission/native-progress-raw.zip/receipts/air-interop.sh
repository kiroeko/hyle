#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-qvk
test "$(cat "$task/owner.txt")" = 'M1-V Q-VK disposable forward verification'
test ! -L "$task"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
mkdir "$task/interop" "$task/interop-logs"
tar -xzf "$task/interop.tar.gz" -C "$task/interop"
cmake -S "$task/interop" -B "$task/interop-build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 \
  -DQVK_IREE_SOURCE="$task/source-runtime" \
  > "$task/interop-logs/configure.log" 2>&1
cmake --build "$task/interop-build" --parallel 2 --target qvk_static_consumer qvk_shared_consumer \
  > "$task/interop-logs/build.log" 2>&1
for kind in static shared; do
  "$task/interop-build/qvk_${kind}_consumer" "$task/interop/combined-async.vmfb" \
    > "$task/interop-logs/$kind.log" 2>&1
  cat "$task/interop-logs/$kind.log"
done
