import hashlib
import json
from pathlib import Path
import shutil
import numpy as np

source=Path('C:/hv/qvk');root=Path('C:/hv/parameterized');root.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((source/'manifest.json').read_text())
cases=[case for case in original['cases'] if case['name']!='fp4_ue8_matmul']
for case in cases:
    for item in case['inputs']:
        assert sha(source/item['file'])==item['sha256'];shutil.copy2(source/item['file'],root/item['file'])
    assert sha(source/case['expected'])==case['expected_sha256'];shutil.copy2(source/case['expected'],root/case['expected'])
def add(name,variant,inputs,expected,basis):
    prefix=f'{name}-{variant}';case={'name':name,'variant':variant,'inputs':[],'oracle_basis':basis,'atol':0,'rtol':0}
    for index,array in enumerate(inputs):
        path=root/f'{prefix}-input{index}.npy';np.save(path,array)
        case['inputs'].append({'file':path.name,'bytes':array.nbytes,'sha256':sha(path)})
    path=root/f'{prefix}-expected.npy';np.save(path,expected)
    case.update(expected=path.name,expected_sha256=sha(path));cases.append(case)
for name in ('scan_inclusive','scan_exclusive'):
    for variant,(batch,width) in enumerate(((1,1),(3,33)),start=2):
        values=((np.arange(batch*width,dtype=np.int32)*3+variant)%11-5).reshape(batch,width)
        initial=(np.arange(batch,dtype=np.int32)*-10+3)
        expected=np.cumsum(values,axis=1,dtype=np.int64).astype(np.int32)
        if name=='scan_exclusive':expected=np.concatenate((np.zeros((batch,1),dtype=np.int32),expected[:,:-1]),axis=1)+initial[:,None]
        add(name,variant,[values,initial],expected,'Independent NumPy int64 cumulative sum; inclusive ignores initial, exclusive includes explicit initial; no overflow')
for name in ('fp8_f32_scale','fp8_ue8_scale'):
    base=next(case for case in cases if case['name']==name and case['variant']==0)
    arrays=[np.load(source/item['file']) for item in base['inputs']];expected=np.load(source/base['expected'])
    add(name,2,[arrays[0][:1].copy(),arrays[1].copy(),arrays[2][:1].copy(),arrays[3].copy()],expected[:1].copy(),'Exact row selection from frozen independent logical-value oracle')
    expanded=[np.tile(arrays[0],(2,2))[:3].copy(),np.tile(arrays[1],(2,2)),np.tile(arrays[2],(2,2))[:3].copy(),np.tile(arrays[3],(2,2))]
    result=np.tile(expected,(2,2))[:3]*np.float32(2)
    add(name,3,expanded,result,'Frozen oracle tiled to M3,N256,K256; two identical K blocks sum exactly for these representable values')
for abi in ('sync','async'):shutil.copy2(source/('parameterized-c2-'+abi+'.vmfb'),root/(abi+'.vmfb'))
record={'kind':'Q-VK fixed cases preserved plus shape variation; no coverage credit','cases':cases,'artifacts':{abi:sha(root/(abi+'.vmfb')) for abi in ('sync','async')}}
(root/'manifest.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(len(cases),'cases prepared',flush=True)
