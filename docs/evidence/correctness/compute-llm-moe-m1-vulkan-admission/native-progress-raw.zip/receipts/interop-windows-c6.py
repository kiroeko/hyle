import ctypes
import hashlib
import json
import os
import sys
from pathlib import Path
import shutil
import subprocess
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root=Path('C:/hv/interop');build=Path('C:/hv/interop-win-build')
logs=Path('.scratch/validation/m1-vulkan-admission')
shim=Path('C:/hv/native-tools');shim.mkdir(exist_ok=True)
(shim/'python3.cmd').write_bytes(('@\"'+sys.executable+'\" %*\r\n').replace('\\\"','\"').encode())
os.environ['PATH']=str(shim)+';'+os.environ['PATH']
record={'kind':'Q-VK native C runtime C++ source/static/shared qualification; no HYLE provider registered',
        'iree_pin':'6ef606b6fa3e12bd2c12d36a07463069eb71185f','status':'RUNNING','commands':[]}
receipt=logs/'interop-windows-c6.json';assert not receipt.exists()
def save():receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
def run(label,argv):
    path=logs/('interop-win-c6-'+label+'.log');assert not path.exists()
    print('RUN',label,flush=True);start=time.time()
    with path.open('wb') as output:result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,timeout=900)
    record['commands'].append({'label':label,'argv':argv,'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'log':str(path),'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest()});save()
    if result.returncode:
        record['status']='FAIL';save();print(path.read_text(errors='replace')[-9000:],flush=True);raise SystemExit(result.returncode)
record['input_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()}
save()
record['configure_reused_artifact']='unchanged original CMake source/context; python3 command alias only'
run('build',['cmake','--build',str(build),'--parallel','2','--target','qvk_static_consumer','qvk_shared_consumer'])
dependencies=[Path('C:/Windows/System32/vulkan-1.dll')]
redist=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
crt=sorted(redist.glob('*/x64/Microsoft.VC*.CRT'))[-1]
dependencies.extend(crt.glob('*.dll'))
record['adjacent_runtime_dlls']=[]
for path in dependencies:
    shutil.copy2(path,build/path.name)
    record['adjacent_runtime_dlls'].append({'source':str(path),'name':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
save()
for kind in ('static','shared'):
    run(kind+'-consumer',[str(build/('qvk_'+kind+'_consumer.exe')),str(root/'combined-async.vmfb')])
record['status']='PASS';save()
print('Windows original C runtime external resource qualification PASS',flush=True)
