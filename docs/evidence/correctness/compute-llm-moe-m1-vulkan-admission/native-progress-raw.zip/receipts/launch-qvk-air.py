import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

logs=Path('.scratch/validation/m1-vulkan-admission')
directory=Path('C:/hv/qvk')
archive=Path('C:/hv/qvk-air.tar.gz')
assert not archive.exists()
manifest=json.loads((directory/'manifest.json').read_text())
exe=Path('C:/hv/tools-mac/iree/_runtime_libs/iree-run-module')
identity={'iree_pin':'6ef606b6fa3e12bd2c12d36a07463069eb71185f',
          'runtime_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),
          'module_sha256':hashlib.sha256((directory/'combined-iree.vmfb').read_bytes()).hexdigest()}
def add_bytes(tar,name,data):
    entry=tarfile.TarInfo(name);entry.size=len(data);tar.addfile(entry,io.BytesIO(data))
with tarfile.open(archive,'w:gz') as tar:
    tar.add(exe,arcname='iree-run-module')
    tar.add(directory/'combined-iree.vmfb',arcname='combined-iree.vmfb')
    tar.add(directory/'manifest.json',arcname='manifest.json')
    tar.add(logs/'run-qvk-air.py',arcname='run.py')
    add_bytes(tar,'identity.json',(json.dumps(identity,indent=2)+'\n').encode())
    add_bytes(tar,'owner.txt',b'M1-V Q-VK disposable forward verification\n')
    files=set()
    for case in manifest['cases']:
        files.add(case['expected'])
        files.update(item['file'] for item in case['inputs'])
    for name in sorted(files):tar.add(directory/name,arcname=name)
record={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'identity':identity}
(logs/'air-forward-identity.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
host='kiro@172.22.10.198'
command='test ! -e /Users/kiro/hyle-m1v-qvk && mkdir /Users/kiro/hyle-m1v-qvk'
subprocess.run(['ssh','-o','BatchMode=yes',host,command],check=True,timeout=30)
subprocess.run(['scp',str(archive),host+':/Users/kiro/hyle-m1v-qvk/bundle.tar.gz'],check=True,timeout=120)
command='cd /Users/kiro/hyle-m1v-qvk && tar -xzf bundle.tar.gz && /usr/bin/python3 run.py'
log=logs/'air-qualification-launch.log'
with log.open('wb') as stream:
    result=subprocess.run(['ssh','-o','BatchMode=yes',host,command],stdout=stream,stderr=subprocess.STDOUT,timeout=1200)
print(log.read_text(errors='replace')[-9000:],flush=True)
subprocess.run(['ssh','-o','BatchMode=yes',host,'cd /Users/kiro/hyle-m1v-qvk && tar -czf results.tar.gz air-result.json *.log *-actual.npy'],check=True,timeout=30)
subprocess.run(['scp',host+':/Users/kiro/hyle-m1v-qvk/results.tar.gz',str(logs/'air-qvk-results.tar.gz')],check=True,timeout=60)
raise SystemExit(result.returncode)
