import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import numpy as np

ctypes.windll.kernel32.SetErrorMode(0x8003)
logs=Path('.scratch/validation/m1-vulkan-admission')
root=Path('C:/hv/interop');root.mkdir(exist_ok=False)
(root/'interop.cc').write_bytes((logs/'iree-interop.cc').read_bytes())
data=Path('C:/hv/qvk')
fixture=['#include <array>','#include <cstdint>']
for field,file,count in [('Inputs','input0',34),('Initial','input1',2),('Expected','expected',34)]:
    values=[np.load(data/f'scan_exclusive-{variant}-{file}.npy').flatten().tolist() for variant in range(2)]
    fixture.append(f'constexpr std::array<std::array<int32_t,{count}>,2> k{field}{{{{')
    fixture.extend('{'+','.join(map(str,row))+'},' for row in values)
    fixture.append('}};')
(root/'scan-fixture.h').write_bytes(('\n'.join(fixture)+'\n').encode())
(root/'client.cc').write_bytes(b'int qvk_execute(int, char**);\nint main(int argc,char**argv){return qvk_execute(argc,argv);}\n')
cmake='''cmake_minimum_required(VERSION 3.25)
project(m1v_native_qualification LANGUAGES C CXX)
set(IREE_BUILD_COMPILER OFF CACHE BOOL "" FORCE)
set(IREE_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(IREE_BUILD_BENCHMARKS OFF CACHE BOOL "" FORCE)
set(IREE_BUILD_SAMPLES OFF CACHE BOOL "" FORCE)
set(IREE_BUILD_PYTHON_BINDINGS OFF CACHE BOOL "" FORCE)
set(IREE_BUILD_BINDINGS_TFLITE OFF CACHE BOOL "" FORCE)
set(IREE_BUILD_BINDINGS_TFLITE_JAVA OFF CACHE BOOL "" FORCE)
set(IREE_HAL_DRIVER_DEFAULTS OFF CACHE BOOL "" FORCE)
set(IREE_HAL_DRIVER_VULKAN ON CACHE BOOL "" FORCE)
set(IREE_ENABLE_CPUINFO OFF CACHE BOOL "" FORCE)
add_subdirectory("${QVK_IREE_SOURCE}" original-iree EXCLUDE_FROM_ALL)
find_package(Vulkan REQUIRED)
foreach(kind IN ITEMS STATIC SHARED)
  string(TOLOWER "${kind}" suffix)
  add_library(qvk_${suffix} ${kind} interop.cc)
  target_compile_features(qvk_${suffix} PRIVATE cxx_std_20)
  target_compile_definitions(qvk_${suffix} PRIVATE main=qvk_execute)
  target_link_libraries(qvk_${suffix} PRIVATE iree::runtime::unified iree::hal::drivers::vulkan Vulkan::Vulkan)
  set_target_properties(qvk_${suffix} PROPERTIES WINDOWS_EXPORT_ALL_SYMBOLS ON POSITION_INDEPENDENT_CODE ON)
  add_executable(qvk_${suffix}_consumer client.cc)
  target_link_libraries(qvk_${suffix}_consumer PRIVATE qvk_${suffix})
endforeach()
'''
(root/'CMakeLists.txt').write_bytes(cmake.encode())
argv=['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-compile.exe',str(data/'combined-llvm23.mlir'),
      '--iree-hal-target-device=vulkan','--iree-vulkan-target=vp_android_baseline_2022',
      '--iree-vulkan-dispatch-abi=descriptors','--iree-execution-model=async-external',
      '--iree-vulkan-target-features=spirv:v1.3,cap:Shader,cap:Float16,cap:StorageBuffer16BitAccess,ext:SPV_KHR_16bit_storage',
      '-o',str(root/'combined-async.vmfb')]
log=logs/'interop-async-compile.log'
assert not log.exists()
with log.open('wb') as stream:result=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
passed=result.returncode==0 and 'error:' not in log.read_text(errors='replace').lower()
record={'argv':argv,'exit_code':result.returncode,'qualified_compile':passed,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()}}
(logs/'interop-inputs.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print('async external artifact',passed,flush=True)
if not passed:print(log.read_text(errors='replace')[-5000:])
raise SystemExit(0 if passed else 1)
