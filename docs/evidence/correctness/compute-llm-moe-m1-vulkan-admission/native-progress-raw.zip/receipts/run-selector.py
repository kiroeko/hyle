import ctypes
import json
from pathlib import Path
import subprocess
import sys

ctypes.windll.kernel32.SetErrorMode(0x8003)
logs=Path('.scratch/validation/m1-vulkan-admission')
argv=[sys.executable,'scripts/validation-select.py','run',
      '--base','3dd189e13da96fa83d50335821f0d163037592d5',
      '--candidate','b836d1382519a66515582ea09d95d896c5240ec1',
      '--context','.scratch/validation/windows-msvc-context.json',
      '--scratch','C:/hv/selected','--cache',str(logs/'selected-receipts'),
      '--output',str(logs/'selected-windows-result.json')]
assert not (logs/'selected-windows-run-2.log').exists()
print('Running the original selected gates; log: selected-windows-run-2.log',flush=True)
with (logs/'selected-windows-run-2.log').open('wb') as output:
    result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT)
(logs/'selected-launch.json').write_bytes((json.dumps({'argv':argv,'exit_code':result.returncode},indent=2)+'\n').encode())
print('Selected validation exit:',result.returncode,flush=True)
raise SystemExit(result.returncode)
