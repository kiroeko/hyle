from pathlib import Path
logs=Path('.scratch/validation/m1-vulkan-admission')
p=Path('C:/hv/interop/interop.cc');(logs/'iree-interop-c3-failed.cc').write_bytes(p.read_bytes())
s=p.read_text()
s=s.replace('#include "iree/modules/hal/types.h"','#include "iree/modules/hal/types.h"\n#include "iree/modules/hal/module.h"\n#include "iree/hal/device_group.h"\n#include "iree/async/frontier_tracker.h"\n#include "iree/vm/bytecode/module.h"')
s=s.replace('#include <vector>','#include <vector>\n#include <fstream>\n#include <iterator>')
s=s.replace('using Session=Owner<iree_runtime_session_t,iree_runtime_session_release>;','using VmContext=Owner<iree_vm_context_t,iree_vm_context_release>;')
s=s.replace('struct Call {iree_runtime_call_t value{};~Call(){iree_runtime_call_deinitialize(&value);}};', '''struct Call {
  iree_vm_context_t *context;iree_vm_function_t function{};
  iree_vm_list_t *inputs=nullptr,*outputs=nullptr;
  explicit Call(iree_vm_context_t *c):context(c){
    check(iree_vm_context_resolve_function(c,iree_make_cstring_view("module.scan_exclusive"),&function));
    check(iree_vm_list_create(iree_vm_make_undefined_type_def(),4,iree_allocator_system(),&inputs));
    check(iree_vm_list_create(iree_vm_make_undefined_type_def(),1,iree_allocator_system(),&outputs));
  }
  void reset(){check(iree_vm_list_resize(inputs,0));check(iree_vm_list_resize(outputs,0));}
  void push(iree_hal_buffer_view_t *view){auto ref=iree_hal_buffer_view_retain_ref(view);check(iree_vm_list_push_ref_move(inputs,&ref));}
  void invoke(){check(iree_vm_invoke(context,function,IREE_VM_INVOCATION_FLAG_NONE,nullptr,inputs,outputs,iree_allocator_system()));}
  ~Call(){iree_vm_list_release(inputs);iree_vm_list_release(outputs);}
};''')
start=s.index('    std::array<Session,2> sessions;')
end=s.index('    View retained;',start)
s=s[:start]+'''    // A device has one frontier/device group. Share that original owner while
    // keeping VM execution state separate for each invocation.
    iree_async_frontier_tracker_t *tracker_raw=nullptr;
    check(iree_async_frontier_tracker_create(iree_async_frontier_tracker_options_default(),iree_allocator_system(),&tracker_raw));
    Owner<iree_async_frontier_tracker_t,iree_async_frontier_tracker_release> tracker(tracker_raw);
    iree_hal_device_group_t *group_raw=nullptr;check(iree_hal_device_group_create_from_device(device.get(),tracker.get(),iree_allocator_system(),&group_raw));
    Owner<iree_hal_device_group_t,iree_hal_device_group_release> group(group_raw);
    auto *vm=iree_runtime_instance_vm_instance(instance.get());
    iree_vm_module_t *hal_raw=nullptr;
    check(iree_hal_module_create(vm,iree_hal_module_device_policy_default(),group.get(),IREE_HAL_MODULE_FLAG_NONE,iree_hal_module_debug_sink_stdio(stderr),iree_allocator_system(),&hal_raw));
    Owner<iree_vm_module_t,iree_vm_module_release> hal(hal_raw);
    std::ifstream module_file(argv[1],std::ios::binary);
    std::vector<char> bytes((std::istreambuf_iterator<char>(module_file)),std::istreambuf_iterator<char>());
    require(!bytes.empty(),"empty offline artifact");iree_vm_module_t *bytecode_raw=nullptr;
    check(iree_vm_bytecode_module_create(vm,IREE_VM_BYTECODE_MODULE_FLAG_NONE,iree_make_const_byte_span(bytes.data(),bytes.size()),iree_allocator_null(),iree_allocator_system(),&bytecode_raw));
    Owner<iree_vm_module_t,iree_vm_module_release> bytecode(bytecode_raw);
    std::array<VmContext,2> contexts;
    for(auto &context:contexts){
      std::array<iree_vm_module_t *,2> modules{hal.get(),bytecode.get()};iree_vm_context_t *c=nullptr;
      check(iree_vm_context_create_with_modules(vm,IREE_VM_CONTEXT_FLAG_NONE,modules.size(),modules.data(),iree_allocator_system(),&c));context.reset(c);
    }
''' + s[end:]
s=s.replace('Call call;check(iree_runtime_call_initialize_by_name(sessions[variant].get(),iree_make_cstring_view("module.scan_exclusive"),&call.value));','Call call(contexts[variant].get());')
s=s.replace('iree_runtime_call_reset(&call.value);','call.reset();')
s=s.replace('check(iree_runtime_call_inputs_push_back_buffer_view(&call.value,values.get()));check(iree_runtime_call_inputs_push_back_buffer_view(&call.value,initial.get()));','call.push(values.get());call.push(initial.get());')
s=s.replace('call.value.inputs','call.inputs').replace('check(iree_runtime_call_invoke(&call.value,0));','call.invoke();')
s=s.replace('iree_hal_buffer_view_t *output_raw=nullptr;check(iree_runtime_call_outputs_pop_front_buffer_view(&call.value,&output_raw));View output(output_raw);','View output(iree_vm_list_get_buffer_view_retain(call.outputs,0));require(bool(output),"missing output view");')
s=s.replace('sessions={};','contexts={};').replace('two sessions','two isolated VM contexts').replace('outlives sessions','outlives VM contexts')
p.write_bytes(s.encode());(logs/'iree-interop.cc').write_bytes(s.encode())
p=logs/'interop-windows-c3.py';s=p.read_text().replace('interop-windows-c3.json','interop-windows-c4.json').replace("'interop-win-c3-'+label","'interop-win-c4-'+label")
(logs/'interop-windows-c4.py').write_bytes(s.encode())
p=logs/'selected-windows.ps1';(logs/'interop-windows-c4.ps1').write_bytes(p.read_text().replace('run-selector.py','interop-windows-c4.py').encode())
