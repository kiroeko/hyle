import ctypes
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root=Path('C:/hv/qvk');logs=Path('.scratch/validation/m1-vulkan-admission')
mode=sys.argv[1]
if mode=='prepare':
    original=(root/'combined-iree.mlir').read_text()
    parts=re.split(r'(?=func.func @)',original)
    functions=[]
    for function in parts[1:]:
        name=re.search(r'@([a-z0-9_]+)',function).group(1)
        prefix='  %c0 = arith.constant 0 : index\n  %c1 = arith.constant 1 : index\n'
        if name.startswith('scan_'):
            prefix+='  %b = tensor.dim %input, %c0 : tensor<?x?xi32>\n  %n = tensor.dim %input, %c1 : tensor<?x?xi32>\n'
            function=function.replace('tensor<2x17xi32>','tensor<?x?xi32>').replace('tensor<2xi32>','tensor<?xi32>')
            function=function.replace('tensor.empty()', 'tensor.empty(%b, %n)')
        else:
            prefix+='  %m = tensor.dim %lhs, %c0 : tensor<?x?xi8>\n  %k = tensor.dim %lhs, %c1 : tensor<?x?xi8>\n  %n = tensor.dim %rhs, %c0 : tensor<?x?xi8>\n'
            for dims in ('2x128','128x128','2x1','1x1','2x4','128x4'):
                function=function.replace('tensor<'+dims+'x', 'tensor<?x?x')
            function=function.replace('%le = tensor.empty()', '%le = tensor.empty(%m, %k)')
            function=function.replace('%re = tensor.empty()', '%re = tensor.empty(%n, %k)')
            function=function.replace('%empty = tensor.empty()', '%empty = tensor.empty(%m, %n)')
            for value,dims in [('lhs','%m, %k'),('rhs','%n, %k')]:
                needle=r'(flow.tensor.bitcast %'+value+r' : tensor<[^>]+>)( -> tensor<[^>]+>)'
                function,count=re.subn(needle,lambda match:match[1]+'{'+dims+'}'+match[2]+'{'+dims+'}',function)
                assert count==1
            if name=='fp8_ue8_scale':
                prefix+='  %lg = tensor.dim %lhs_scale, %c1 : tensor<?x?xi8>\n  %rg = tensor.dim %rhs_scale, %c1 : tensor<?x?xi8>\n'
                for value,dims in [('lhs_scale','%m, %lg'),('rhs_scale','%n, %rg')]:
                    needle=r'(flow.tensor.bitcast %'+value+r' : tensor<[^>]+>)( -> tensor<[^>]+>)'
                    function,count=re.subn(needle,lambda match:match[1]+'{'+dims+'}'+match[2]+'{'+dims+'}',function)
                    assert count==1
        function=function.replace(' {\n',' {\n'+prefix,1)
        functions.append(function)
    dest=root/'parameterized-c1.mlir';assert not dest.exists()
    dest.write_bytes((parts[0]+''.join(functions)).encode())
    print('Parameterized shapes only; same original scan/standard conversions/MatMul operations')
    raise SystemExit(0)

record={'kind':'Q-VK original operation composition, parameterized-c1 offline artifact', 'status':'RUNNING','commands':[]}
receipt=logs/'parameterized-c1-compile.json';assert not receipt.exists()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save():receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
def run(label,argv):
    path=logs/('parameterized-c1-'+label+'.log');assert not path.exists();print('RUN',label,flush=True);start=time.time()
    with path.open('wb') as stream:result=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    passed=result.returncode==0 and 'error:' not in path.read_text(errors='replace').lower()
    record['commands'].append({'argv':argv,'exit_code':result.returncode,'valid':passed,'elapsed_seconds':time.time()-start,'log_sha256':sha(path)})
    save()
    if not passed:
        record['status']='FAIL';save();print(path.read_text(errors='replace')[-6000:]);raise SystemExit(1)
record['recipe_sha256']=sha(root/'parameterized-c1.mlir');save()
run('generic',['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-opt.exe',str(root/'parameterized-c1.mlir'),'--mlir-print-op-generic','-o',str(root/'parameterized-c1-generic.mlir')])
run('ue8',['wsl','-e','env','LD_LIBRARY_PATH=/mnt/c/hv/llvm23/usr/lib/x86_64-linux-gnu:/mnt/c/hv/llvm23/usr/lib/llvm-23/lib','/mnt/c/hv/llvm23/usr/lib/llvm-23/bin/mlir-opt','/mnt/c/hv/qvk/parameterized-c1-generic.mlir','--allow-unregistered-dialect','--pass-pipeline=builtin.module(arith-expand{include-f8e8m0=true})','--mlir-print-op-generic','-o','/mnt/c/hv/qvk/parameterized-c1-llvm23.mlir'])
for abi in ('sync','async'):
    args=['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-compile.exe',str(root/'parameterized-c1-llvm23.mlir'),'--iree-hal-target-device=vulkan','--iree-vulkan-target=vp_android_baseline_2022','--iree-vulkan-dispatch-abi=descriptors','--iree-vulkan-target-features=spirv:v1.3,cap:Shader,cap:Float16,cap:StorageBuffer16BitAccess,ext:SPV_KHR_16bit_storage']
    if abi=='async':args+=['--iree-execution-model=async-external']
    args+=['-o',str(root/('parameterized-c1-'+abi+'.vmfb'))]
    run('compile-'+abi,args);record[abi+'_vmfb_sha256']=sha(root/('parameterized-c1-'+abi+'.vmfb'));save()
record['status']='PASS';save();print('Parameterized artifact compile PASS',flush=True)
