"""One combined-provider qualification: original IREE scan/FP8 + ggml MXFP4.

This tool selects IREE's assigned four functions, without changing their bytes
or any of the ten frozen input/oracle cases. MXFP4 is checked by the native test.
"""
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import numpy as np

ctypes.windll.kernel32.SetErrorMode(0x8003)
logs=Path('.scratch/validation/m1-vulkan-admission')
directory=Path('C:/hv/qvk')
mode=sys.argv[1]
manifest=json.loads((directory/'manifest.json').read_text())
assert manifest['cases']==json.loads((logs/'bundle-manifest.json.attempt1').read_text())['cases']
receipt=logs/('combined-'+mode+'.json')
assert not receipt.exists()
record={'kind':'combined Q-VK; native qualification only','product_coverage_cells':0,
        'iree_assigned':['scan_inclusive','scan_exclusive','fp8_f32_scale','fp8_ue8_scale'],
        'ggml_assigned':['fp4_ue8_matmul'],'status':'RUNNING','commands':[],'cases':[]}
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(): receipt.write_bytes((json.dumps(record,indent=2,allow_nan=False)+'\n').encode())
def run(label,argv):
    path=logs/('combined-'+label+'.log')
    assert not path.exists()
    print('RUN',label,flush=True)
    start=time.time()
    with path.open('wb') as output:
        result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,timeout=240)
    qualified=result.returncode==0 and 'error:' not in path.read_text(errors='replace').lower()
    record['commands'].append({'label':label,'argv':argv,'exit_code':result.returncode,
                               'qualified_command':qualified,'elapsed_seconds':time.time()-start,
                               'log':str(path),'log_sha256':sha(path)})
    save()
    if not qualified:
        record['status']='FAIL';save()
        print(path.read_text(errors='replace')[-6000:],flush=True)
        raise SystemExit(1)
save()
if mode=='compile':
    original=(directory/'bundle.mlir').read_text()
    assert sha(directory/'bundle.mlir')==manifest['module_sha256']
    assigned=original.split('func.func @fp4_ue8_matmul',1)[0]+'}\n'
    source=directory/'combined-iree.mlir'
    assert not source.exists()
    source.write_bytes(assigned.encode())
    record['original_recipe_sha256']=sha(directory/'bundle.mlir')
    record['assigned_recipe_sha256']=sha(source)
    run('iree-generic',['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-opt.exe',str(source),
        '--mlir-print-op-generic','-o',str(directory/'combined-generic.mlir')])
    run('llvm-ue8',['wsl','-e','env',
        'LD_LIBRARY_PATH=/mnt/c/hv/llvm23/usr/lib/x86_64-linux-gnu:/mnt/c/hv/llvm23/usr/lib/llvm-23/lib',
        '/mnt/c/hv/llvm23/usr/lib/llvm-23/bin/mlir-opt','/mnt/c/hv/qvk/combined-generic.mlir',
        '--allow-unregistered-dialect','--pass-pipeline=builtin.module(arith-expand{include-f8e8m0=true})',
        '--mlir-print-op-generic','-o','/mnt/c/hv/qvk/combined-llvm23.mlir'])
    run('iree-compile',['C:/hv/tools-win/iree/compiler/_mlir_libs/iree-compile.exe',
        str(directory/'combined-llvm23.mlir'),'--iree-hal-target-device=vulkan',
        '--iree-vulkan-target=vp_android_baseline_2022','--iree-vulkan-dispatch-abi=descriptors',
        '--iree-vulkan-target-features=spirv:v1.3,cap:Shader,cap:Float16,cap:StorageBuffer16BitAccess,ext:SPV_KHR_16bit_storage',
        '-o',str(directory/'combined-iree.vmfb')])
    record['module_sha256']=sha(directory/'combined-iree.vmfb')
elif mode=='windows':
    compile_record=json.loads((logs/'combined-compile.json').read_text())
    assert compile_record['status']=='PASS'
    record['module_sha256']=sha(directory/'combined-iree.vmfb')
    assert record['module_sha256']==compile_record['module_sha256']
    for case in manifest['cases']:
        if case['name'] not in record['iree_assigned']: continue
        label=case['name']+'-'+str(case['variant'])
        output=directory/('combined-'+label+'-actual.npy')
        assert not output.exists()
        argv=['C:/hv/tools-win/iree/_runtime_libs/iree-run-module.exe',
              '--device=vulkan://GPU-e73765606f5dec196ee43dd3a2c81ef8',
              '--module='+str(directory/'combined-iree.vmfb'),'--function='+case['name']]
        for item in case['inputs']:
            assert sha(directory/item['file'])==item['sha256']
            argv.append('--input=@'+str(directory/item['file']))
        argv.append('--output=@'+str(output))
        run('windows-'+label,argv)
        assert sha(directory/case['expected'])==case['expected_sha256']
        expected,actual=np.load(directory/case['expected']),np.load(output)
        passed=actual.shape==expected.shape and actual.dtype==expected.dtype and np.array_equal(actual,expected)
        error=float(np.max(np.abs(actual.astype(np.float64)-expected.astype(np.float64))))
        record['cases'].append({'label':label,'pass':passed,'shape':list(actual.shape),
            'dtype':str(actual.dtype),'max_absolute_error':error if np.isfinite(error) else None,
            'actual_sha256':sha(output),'expected_sha256':case['expected_sha256']})
        save()
        print(label,passed,flush=True)
        if not passed:
            record['status']='FAIL';save();raise SystemExit(1)
else:
    raise RuntimeError('unknown mode')
record['status']='PASS';save()
print(mode,'PASS for IREE assigned portion only; combined native-resource/Air/SDK gates pending',flush=True)
