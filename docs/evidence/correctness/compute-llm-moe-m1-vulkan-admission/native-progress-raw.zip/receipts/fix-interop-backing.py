from pathlib import Path

root = Path('C:/hv/interop')
logs = Path('.scratch/validation/m1-vulkan-admission')
path = root / 'interop.cc'
old = path.read_text()
(logs / 'iree-interop-c4-failed.cc').write_bytes(path.read_bytes())
text = old.replace('#include "iree/hal/drivers/vulkan/api.h"', '#include "iree/hal/drivers/vulkan/api.h"\n#include "iree/hal/drivers/vulkan/buffer.h"')
needle = 'View input(Native &native'
helper = '''struct BufferSpan {VkBuffer handle{};iree_device_size_t offset{};};
BufferSpan native_span(iree_hal_buffer_t *buffer) {
  iree_hal_buffer_t *backing=nullptr;
  check(iree_hal_vulkan_buffer_resolve_backing(buffer,&backing));
  BufferSpan span;VkDeviceMemory memory{};
  check(iree_hal_vulkan_buffer_handle(backing,&memory,&span.handle));
  check(iree_hal_vulkan_buffer_resolve_backing_offset(buffer,backing,0,&span.offset));
  return span;
}
'''
assert text.count(needle) == 1
text = text.replace(needle, helper + needle)
text = text.replace('VkDeviceMemory memory{};VkBuffer handle{};check(iree_hal_vulkan_allocated_buffer_handle(iree_hal_buffer_allocated_buffer(raw),&memory,&handle));', 'auto span=native_span(raw);')
text = text.replace('native.copy(upload.buffer,0,handle,iree_hal_buffer_byte_offset(raw),count*sizeof(int32_t));', 'native.copy(upload.buffer,0,span.handle,span.offset,count*sizeof(int32_t));')
text = text.replace('VkDeviceMemory memory{};VkBuffer handle{};check(iree_hal_vulkan_allocated_buffer_handle(iree_hal_buffer_allocated_buffer(buffer),&memory,&handle));', 'auto span=native_span(buffer);')
text = text.replace('native.copy(handle,iree_hal_buffer_byte_offset(buffer),readback.buffer,0,count*4);', 'native.copy(span.handle,span.offset,readback.buffer,0,count*4);')
assert text != old and 'iree_hal_vulkan_allocated_buffer_handle' not in text
path.write_bytes(text.encode())
(logs / 'iree-interop.cc').write_bytes(text.encode())
for extension in ('py', 'ps1'):
    source = logs / ('interop-windows-c4.' + extension)
    dest = logs / ('interop-windows-c5.' + extension)
    assert not dest.exists()
    dest.write_bytes(source.read_text().replace('c4', 'c5').encode())
