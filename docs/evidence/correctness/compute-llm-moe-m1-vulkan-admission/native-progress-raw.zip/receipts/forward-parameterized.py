import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root=Path('C:/hv/parameterized');logs=Path('.scratch/validation/m1-vulkan-admission')
manifest=json.loads((root/'manifest.json').read_text());names={'manifest.json','sync.vmfb','async.vmfb','run.py'}
for case in manifest['cases']:
    names.add(case['expected']);names.update(item['file'] for item in case['inputs'])
archive=Path('C:/hv/parameterized-forward.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
    for name in sorted(names):tar.add(root/name,arcname=name)
identity={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(names)}}
(logs/'parameterized-forward.json').write_bytes((json.dumps(identity,indent=2)+'\n').encode())
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-m1v-qvk'
subprocess.run(['scp',str(archive),host+':'+remote+'/parameterized.tar.gz'],check=True,timeout=120)
command="test \"$(cat /Users/kiro/hyle-m1v-qvk/owner.txt)\" = 'M1-V Q-VK disposable forward verification' && mkdir /Users/kiro/hyle-m1v-qvk/parameterized && tar -xzf /Users/kiro/hyle-m1v-qvk/parameterized.tar.gz -C /Users/kiro/hyle-m1v-qvk/parameterized && /usr/bin/python3 /Users/kiro/hyle-m1v-qvk/parameterized/run.py"
log=logs/'air-parameterized-launch.log';assert not log.exists()
with log.open('wb') as stream:
    result=subprocess.run(['ssh','-o','BatchMode=yes',host,command],stdout=stream,stderr=subprocess.STDOUT,timeout=600)
print('Air parameterized exit',result.returncode,flush=True);print(log.read_text(errors='replace')[-6000:],flush=True)
raise SystemExit(result.returncode)
