import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import zipfile

logs=Path('.scratch/validation/m1-vulkan-admission')
dest=Path('evidence/correctness/compute-llm-moe-m1-vulkan-admission')
archive=dest/'native-progress-raw.zip';assert not archive.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
windows=read(Path('C:/hv/parameterized/result.json'))
with tarfile.open(logs/'air-native-parameterized-complete-results.tar.gz') as tar:
    air=json.load(tar.extractfile('parameterized/result.json'))
assert windows['status']==air['status']=='PASS'
assert len(windows['cases'])==len(air['cases'])==16
assert read(logs/'selected-continuation-c2.json')['status']=='PASS'
manifest=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    def add(p,name):
        output.write(p,name);manifest.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
    for p in sorted(logs.iterdir()):
        if p.is_file() and (p.suffix in ('.json','.log','.py','.ps1','.sh','.cc','.h') or p.name in ('air-qvk-native-results.tar.gz','air-product-results.tar.gz','air-native-parameterized-complete-results.tar.gz')):
            add(p,'receipts/'+p.name)
    for dirname in ('interop','parameterized'):
        for p in sorted(Path('C:/hv',dirname).iterdir()):
            if p.is_file():add(p,dirname+'/'+p.name)
    for p in sorted(Path('C:/hv/qvk').iterdir()):
        if p.is_file() and (p.name.startswith('combined-') or p.name.startswith('parameterized')) and p.suffix in ('.mlir','.vmfb'):
            add(p,'recipes/'+p.name)
    output.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
shutil.copy2(logs/'current-compute-graph-loc.json',dest/'native-progress-loc.json')
record={
 'kind':'M1-V progress; native qualification and product recurrent slice, not closure',
 'product_candidate':'db770b6fc1e46aa8d8aa86c1102d50acf26eb49f',
 'product_coverage_cells':0,
 'overall_admission':'INCONCLUSIVE: ordinary IREE integration and declared product acceptance pending',
 'pins':{'iree':'6ef606b6fa3e12bd2c12d36a07463069eb71185f','ggml':'456172ec733a135778adcd32d00e576a58232e45'},
 'passed':{
   'windows_selected_recurrent_slice':'Original selector FAIL retained; fixture-only corrections and the original selected commands PASS on immutable db770b6f',
   'air_recurrent_slice':'Six factor/header CTest gates PASS on forward copy of db770b6f',
   'original_ggml_mxfp4':'Both frozen variants, repeat3, immutable imported inputs and independent oracle PASS on RTX4070 and Air; native qualification only',
   'iree_fixed_numeric':'Original eight assigned IREE cases PASS on RTX4070 and Air; original packed-FP4 rejection remains unchanged',
   'parameterized_numeric':{'windows':windows['cases'],'air':air['cases'],'tolerance':'exact equality; original eight frozen cases preserved; eight shape cases added'},
   'cpp_static_shared_native':'Both machines PASS: external VkDevice/queue, bounded GPU copy, async ready/done, two simultaneously pending isolated VM contexts repeat3, accepted dependency failure propagation, unchanged inputs, retained outputs after VM-context release, external device survives runtime release',
 },
 'cost_and_limits':[
   'Parameterized FP8 uses original conversion/scaling/MatMul with explicit dispatch boundaries and shape ties after two bounded compiler corrections; workspace includes F32 activation and one F32 weight matrix for the region; compressed inputs stay resident',
   'Only original runtime sources/submodules used; Windows needs original C-header compatibility scope and standard preprocessor; compiler/Python absent at C++ execution',
   'Original direct-session construction for the same device failed queue frontier assignment; one original HAL device group/module plus separate VM contexts is verified',
   'Original public dense-buffer helper does not resolve transient outputs; pinned original Vulkan buffer backing/offset helpers are used privately',
   'Air offers one compute queue. External raw queue commands in the qualification run only after all IREE completions; concurrent mixed HYLE/ggml/IREE submissions require a shared host-synchronization adapter before product admission',
   'Native integer fixtures do not prove the public checked-overflow Scan contract; including exclusive final total remains a required ordinary-entry acceptance item',
   'No P1, SOTA verdict, self-written operator change, or new complete coverage cell',
 ],
 'remaining':['Register/audit the qualified native-provider boundary and finite resource glue before product edits','Ordinary Direct/Graph integration and strict public semantics','Actual same-device mixed-provider synchronization/accepted-prefix lifecycle','Windows/Air source/static/shared relocated product consumers, applicable host instrumentation/OFF gates and final P0 review'],
 'budget':{'start_utc':'2026-09-20 08:02:33 UTC','source_qualification_deadline_utc':'2026-09-20 12:02:33 UTC','reset':False},
 'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},
 'loc':{'implementation_lines':51953,'files':222,'excludes':['tests','bench','third_party'],'record':'native-progress-loc.json'}
}
(dest/'native-progress.json').write_bytes((json.dumps(record,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(manifest),'status':record['overall_admission']}))
