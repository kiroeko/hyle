#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-qvk
test "$(cat "$task/owner.txt")" = 'M1-V Q-VK disposable forward verification'
test ! -L "$task"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2
mkdir "$task/source-runtime"
tar -xzf "$task/runtime-source.tar.gz" -C "$task/source-runtime"
cmake -S "$task/source-runtime" -B "$task/runtime-build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=/usr/bin/clang \
  -DCMAKE_CXX_COMPILER=/usr/bin/clang++ -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 \
  -DIREE_BUILD_COMPILER=OFF -DIREE_BUILD_TESTS=OFF -DIREE_BUILD_BENCHMARKS=OFF \
  -DIREE_BUILD_SAMPLES=OFF -DIREE_BUILD_PYTHON_BINDINGS=OFF \
  -DIREE_BUILD_BINDINGS_TFLITE=OFF -DIREE_BUILD_BINDINGS_TFLITE_JAVA=OFF \
  -DIREE_HAL_DRIVER_DEFAULTS=OFF -DIREE_HAL_DRIVER_VULKAN=ON \
  -DIREE_ENABLE_CPUINFO=OFF -DIREE_ENABLE_LTO=OFF \
  > "$task/runtime-configure.log" 2>&1
cmake --build "$task/runtime-build" --target iree-run-module --parallel 2 \
  > "$task/runtime-build.log" 2>&1
/usr/bin/python3 "$task/run-native.py"
