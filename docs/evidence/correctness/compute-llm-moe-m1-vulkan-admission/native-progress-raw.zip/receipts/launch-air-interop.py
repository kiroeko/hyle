import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

logs=Path('.scratch/validation/m1-vulkan-admission')
root=Path('C:/hv/interop');archive=Path('C:/hv/interop-forward.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
    tar.add(root,arcname='.')
identity={'kind':'Windows canonical Q-VK native C++ qualification forward copy',
          'iree_pin':'6ef606b6fa3e12bd2c12d36a07463069eb71185f',
          'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()}}
(logs/'air-interop-forward.json').write_bytes((json.dumps(identity,indent=2)+'\n').encode())
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-m1v-qvk/'
for path,name in [(archive,'interop.tar.gz'),(logs/'air-interop.sh','interop.sh')]:
    subprocess.run(['scp',str(path),host+':'+remote+name],check=True,timeout=120)
log=logs/'air-interop-launch.log';assert not log.exists();start=time.time()
with log.open('wb') as stream:
    result=subprocess.run(['ssh','-o','BatchMode=yes',host,'bash '+remote+'interop.sh'],stdout=stream,stderr=subprocess.STDOUT,timeout=1200)
record={'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(logs/'air-interop-result.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print('Air native interop exit',result.returncode,flush=True)
print(log.read_text(errors='replace')[-6000:],flush=True)
raise SystemExit(result.returncode)
