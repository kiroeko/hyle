from pathlib import Path
root=Path('C:/hv/interop');logs=Path('.scratch/validation/m1-vulkan-admission')
p=root/'interop.cc';source=p.read_text()
(logs/'iree-interop-c6-passed.cc').write_bytes(p.read_bytes())
helper='''struct Submission {
  Call &call;Fence ready,done;
  Submission(iree_hal_device_t *device,Call &c,iree_hal_buffer_view_t *values,iree_hal_buffer_view_t *initial):call(c) {
    call.reset();call.push(values);call.push(initial);
    for(auto *fence:{&ready,&done}){
      iree_hal_semaphore_t *raw=nullptr;
      check(iree_hal_semaphore_create(device,IREE_HAL_QUEUE_AFFINITY_ANY,0,IREE_HAL_SEMAPHORE_FLAG_NONE,&raw));
      Owner<iree_hal_semaphore_t,iree_hal_semaphore_release> semaphore(raw);
      iree_hal_fence_t *f=nullptr;check(iree_hal_fence_create_at(raw,1,iree_allocator_system(),&f));fence->reset(f);
      auto ref=iree_hal_fence_retain_ref(f);check(iree_vm_list_push_ref_move(call.inputs,&ref));
    }
    call.invoke();
    auto status=iree_hal_fence_query(done.get());bool pending=iree_status_is_deferred(status);iree_status_free(status);
    require(pending,"completion signaled before external dependency");
  }
  View finish(){
    check(iree_hal_fence_wait(done.get(),iree_make_timeout_ms(10000),IREE_ASYNC_WAIT_FLAG_NONE));
    View output(iree_vm_list_get_buffer_view_retain(call.outputs,0));require(bool(output),"missing async output");return output;
  }
};
'''
assert 'struct BufferSpan' in source
source=source.replace('struct BufferSpan',helper+'struct BufferSpan',1)
needle='    contexts={};compare(native,readback,retained.get(),kExpected[0].data(),34);retained.reset();'
addition='''    {
      // All host transfers finish before either request is pending on the queue.
      std::array<View,2> values,initial;
      std::array<std::unique_ptr<Call>,2> calls;
      for(size_t i=0;i<2;++i){
        values[i]=input(native,device.get(),upload,kInputs[i].data(),34,{2,17});
        initial[i]=input(native,device.get(),upload,kInitial[i].data(),2,{2});
        calls[i]=std::make_unique<Call>(contexts[i].get());
      }
      for(size_t repeat=0;repeat<3;++repeat){
        std::array<std::unique_ptr<Submission>,2> pending;
        for(size_t i=0;i<2;++i)pending[i]=std::make_unique<Submission>(device.get(),*calls[i],values[i].get(),initial[i].get());
        check(iree_hal_fence_signal(pending[1]->ready.get()));
        check(iree_hal_fence_signal(pending[0]->ready.get()));
        std::array<View,2> outputs;
        for(size_t i=0;i<2;++i)outputs[i]=pending[i]->finish();
        // Both completions observed before the external owner touches VkQueue.
        for(size_t i=0;i<2;++i)compare(native,readback,outputs[i].get(),kExpected[i].data(),34);
        compare(native,readback,retained.get(),kExpected[0].data(),34);
      }
      Submission failed(device.get(),*calls[0],values[0].get(),initial[0].get());
      iree_hal_fence_fail(failed.ready.get(),iree_make_status(IREE_STATUS_ABORTED,"intentional qualification dependency failure"));
      auto status=iree_hal_fence_wait(failed.done.get(),iree_make_timeout_ms(10000),IREE_ASYNC_WAIT_FLAG_NONE);
      bool rejected=!iree_status_is_ok(status)&&!iree_status_is_deadline_exceeded(status);iree_status_free(status);
      require(rejected,"accepted dependency failure did not propagate to completion");
      std::puts("PASS two simultaneously pending requests repeat3; accepted dependency failure reaches completion");
    }
'''
assert source.count(needle)==1
source=source.replace(needle,addition+needle)
p.write_bytes(source.encode());(logs/'iree-interop.cc').write_bytes(source.encode())
for ext in ('py','ps1'):
    dest=logs/('interop-windows-inflight.'+ext);assert not dest.exists()
    dest.write_bytes((logs/('interop-windows-c6.'+ext)).read_text().replace('c6','inflight').encode())
