import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

logs=Path('.scratch/validation/m1-vulkan-admission')
archive=Path('C:/hv/iree-runtime-source.tar.gz')
assert not archive.exists()
source=Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:tar.add(source,arcname='.')
record={'iree_pin':source.name[5:],'submodules':json.loads((logs/'runtime-source-qualification.json').read_text()),
        'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
(logs/'runtime-source-forward.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
original=(logs/'run-qvk-air.py').read_text()
native=original.replace("assert sha(root/'iree-run-module')==identity['runtime_sha256']", "identity['runtime_origin']='built original pinned C runtime, Vulkan explicitly ON'\nidentity['runtime_sha256']=sha(root/'runtime-build/tools/iree-run-module')")
native=native.replace("(root/'iree-run-module').chmod(0o755)", "")
native=native.replace("'air-result.json'", "'air-result-native.json'")
native=native.replace("label=case['name']", "label='native-'+case['name']")
native=native.replace("str(root/'iree-run-module')", "str(root/'runtime-build/tools/iree-run-module')")
(logs/'run-qvk-air-native.py').write_bytes(native.encode())
host='kiro@172.22.10.198'
for path,name in [(archive,'runtime-source.tar.gz'),(logs/'run-qvk-air-native.py','run-native.py'),(logs/'build-air-iree.sh','build-runtime.sh')]:
    subprocess.run(['scp',str(path),host+':/Users/kiro/hyle-m1v-qvk/'+name],check=True,timeout=120)
log=logs/'air-runtime-launch.log'
with log.open('wb') as stream:
    result=subprocess.run(['ssh','-o','BatchMode=yes',host,'bash /Users/kiro/hyle-m1v-qvk/build-runtime.sh'],stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
print('Air original C runtime build/qualification exit',result.returncode,flush=True)
print(log.read_text(errors='replace')[-7000:],flush=True)
raise SystemExit(result.returncode)
