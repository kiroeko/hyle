import ast
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import time

root=Path(__file__).resolve().parent
assert root==Path('/Users/kiro/hyle-m1v-qvk') and not root.is_symlink()
assert (root/'owner.txt').read_text().strip()=='M1-V Q-VK disposable forward verification'
os.chdir(root)
env=os.environ.copy()
env['VK_DRIVER_FILES']='/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json'
env['DYLD_LIBRARY_PATH']='/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
manifest=json.loads((root/'manifest.json').read_text())
identity=json.loads((root/'identity.json').read_text())
identity['runtime_origin']='built original pinned C runtime, Vulkan explicitly ON'
identity['runtime_sha256']=sha(root/'runtime-build/tools/iree-run-module')
assert sha(root/'combined-iree.vmfb')==identity['module_sha256']

record={'kind':'Air Q-VK IREE assigned portion; not HYLE product coverage','product_coverage_cells':0,
        'identity':identity,'status':'RUNNING','cases':[]}
def save(): (root/'air-result-native.json').write_text(json.dumps(record,indent=2)+'\n')
def npy(path):
    data=path.read_bytes()
    assert data[:6]==b'\x93NUMPY'
    width=2 if data[6]==1 else 4
    length=int.from_bytes(data[8:8+width],'little')
    header=ast.literal_eval(data[8+width:8+width+length].decode().strip())
    assert not header['fortran_order']
    dtype=header['descr']
    formats={'<i4':'i','<f4':'f','<f2':'e'}
    payload=data[8+width+length:]
    values=tuple(v[0] for v in struct.iter_unpack('<'+formats[dtype],payload))
    return header['shape'],dtype,values
for command in [['/usr/bin/sw_vers'],['/usr/sbin/sysctl','-n','hw.model'],
                ['/usr/bin/otool','-L',str(root/'runtime-build/tools/iree-run-module')]]:
    result=subprocess.run(command,capture_output=True,text=True)
    record.setdefault('machine',[]).append({'argv':command,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
save()
for case in manifest['cases']:
    if case['name']=='fp4_ue8_matmul': continue
    label='native-'+case['name']+'-'+str(case['variant'])
    output=root/(label+'-actual.npy')
    assert not output.exists()
    command=[str(root/'runtime-build/tools/iree-run-module'),'--device=vulkan','--module='+str(root/'combined-iree.vmfb'),
             '--function='+case['name']]
    for item in case['inputs']:
        assert sha(root/item['file'])==item['sha256']
        command.append('--input=@'+str(root/item['file']))
    command.append('--output=@'+str(output))
    log=root/(label+'.log')
    assert not log.exists()
    start=time.time()
    with log.open('wb') as stream:
        result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
    item={'label':label,'argv':command,'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'log_sha256':sha(log),'pass':False}
    if result.returncode==0:
        assert sha(root/case['expected'])==case['expected_sha256']
        expected,actual=npy(root/case['expected']),npy(output)
        item.update({'pass':expected==actual and all(math.isfinite(v) for v in actual[2]),
                     'actual_sha256':sha(output),'expected_sha256':case['expected_sha256'],
                     'shape':actual[0],'dtype':actual[1]})
    record['cases'].append(item);save()
    print(label,item['pass'],flush=True)
    if not item['pass']:
        record['status']='FAIL';save()
        print(log.read_text(errors='replace')[-5000:],flush=True)
        raise SystemExit(1)
record['status']='PASS';save()
print('Air assigned IREE numerical cases PASS; combined ggml/native-resource/SDK gates pending',flush=True)
