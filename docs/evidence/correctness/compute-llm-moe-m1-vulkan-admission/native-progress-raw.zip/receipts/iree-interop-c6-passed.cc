// M1-V bounded qualification, not HYLE product or mathematical implementation.
// Original IREE C API owns computation; the host only owns/copies Vulkan buffers.
#include <vulkan/vulkan.h>
#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable:4576) // Private original C-header compound literals.
#endif
#include "iree/runtime/api.h"
#include "iree/modules/hal/types.h"
#include "iree/modules/hal/module.h"
#include "iree/hal/device_group.h"
#include "iree/async/frontier_tracker.h"
#include "iree/vm/bytecode/module.h"
#include "iree/hal/drivers/vulkan/api.h"
#include "iree/hal/drivers/vulkan/buffer.h"
#include "iree/async/util/proactor_pool.h"
#if defined(_MSC_VER)
#pragma warning(pop)
#endif
#include "scan-fixture.h"
#include <algorithm>
#include <array>
#include <cstdio>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <vector>
#include <fstream>
#include <iterator>

void check(iree_status_t status) {
  if (!iree_status_is_ok(status)) {
    iree_status_fprint(stderr,status);iree_status_free(status);
    throw std::runtime_error("original IREE C API qualification failed");
  }
}
void check(VkResult status) {
  if(status!=VK_SUCCESS) throw std::runtime_error("external Vulkan operation failed: "+std::to_string(status));
}
void require(bool condition,const char *message) {if(!condition) throw std::runtime_error(message);}
template<class T, auto Release> struct Drop {void operator()(T *p) const {if(p) Release(p);}};
template<class T, auto Release> using Owner=std::unique_ptr<T,Drop<T,Release>>;
using View=Owner<iree_hal_buffer_view_t,iree_hal_buffer_view_release>;
using Fence=Owner<iree_hal_fence_t,iree_hal_fence_release>;
using VmContext=Owner<iree_vm_context_t,iree_vm_context_release>;

struct Native {
  VkInstance instance{};VkPhysicalDevice physical{};VkDevice device{};VkQueue queue{};
  uint32_t family{};VkCommandPool pool{};VkCommandBuffer command{};VkFence fence{};
  Native() {
    uint32_t n=0;check(vkEnumerateInstanceExtensionProperties(nullptr,&n,nullptr));
    std::vector<VkExtensionProperties> extensions(n);
    check(vkEnumerateInstanceExtensionProperties(nullptr,&n,extensions.data()));
    bool portable=std::any_of(extensions.begin(),extensions.end(),[](const auto &e){return std::strcmp(e.extensionName,"VK_KHR_portability_enumeration")==0;});
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};app.apiVersion=VK_API_VERSION_1_3;
    VkInstanceCreateInfo info{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};info.pApplicationInfo=&app;
    const char *portability="VK_KHR_portability_enumeration";
    if(portable){info.flags=VK_INSTANCE_CREATE_ENUMERATE_PORTABILITY_BIT_KHR;info.enabledExtensionCount=1;info.ppEnabledExtensionNames=&portability;}
    check(vkCreateInstance(&info,nullptr,&instance));
    check(vkEnumeratePhysicalDevices(instance,&n,nullptr));require(n>0,"no physical Vulkan device");
    std::vector<VkPhysicalDevice> devices(n);check(vkEnumeratePhysicalDevices(instance,&n,devices.data()));
    physical=devices[0];
    for(auto d:devices){VkPhysicalDeviceProperties p{};vkGetPhysicalDeviceProperties(d,&p);if(p.deviceType==VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU){physical=d;break;}}
    VkPhysicalDeviceProperties properties{};vkGetPhysicalDeviceProperties(physical,&properties);
    require(properties.deviceType!=VK_PHYSICAL_DEVICE_TYPE_CPU,"CPU device prohibited");
    vkGetPhysicalDeviceQueueFamilyProperties(physical,&n,nullptr);
    std::vector<VkQueueFamilyProperties> queues(n);vkGetPhysicalDeviceQueueFamilyProperties(physical,&n,queues.data());
    family=UINT32_MAX;
    for(uint32_t i=0;i<n;++i) if(queues[i].queueFlags&VK_QUEUE_COMPUTE_BIT){family=i;break;}
    require(family!=UINT32_MAX,"no compute queue");
    std::printf("device=%s api=%u driver=%u queue_family=%u queue_count=%u\n",properties.deviceName,properties.apiVersion,properties.driverVersion,family,queues[family].queueCount);
    VkPhysicalDeviceVulkan13Features f13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};
    VkPhysicalDeviceVulkan12Features f12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};f12.pNext=&f13;
    VkPhysicalDeviceVulkan11Features f11{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES};f11.pNext=&f12;
    VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};features.pNext=&f11;
    vkGetPhysicalDeviceFeatures2(physical,&features);
    require(f12.timelineSemaphore&&f12.scalarBlockLayout&&f13.synchronization2&&f12.shaderFloat16&&f11.storageBuffer16BitAccess,"missing IREE baseline or declared F16 features");
    // Enable the declared baseline and the artifact F16 target capabilities.
    f11={VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES};f11.pNext=&f12;f11.storageBuffer16BitAccess=VK_TRUE;
    f12={VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};f12.pNext=&f13;f12.timelineSemaphore=VK_TRUE;f12.scalarBlockLayout=VK_TRUE;f12.shaderFloat16=VK_TRUE;
    f13={VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};f13.synchronization2=VK_TRUE;
    features.features={};
    check(vkEnumerateDeviceExtensionProperties(physical,nullptr,&n,nullptr));extensions.resize(n);
    check(vkEnumerateDeviceExtensionProperties(physical,nullptr,&n,extensions.data()));
    portable=std::any_of(extensions.begin(),extensions.end(),[](const auto &e){return std::strcmp(e.extensionName,"VK_KHR_portability_subset")==0;});
    const char *subset="VK_KHR_portability_subset";
    float priority=1.0f;VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};qi.queueFamilyIndex=family;qi.queueCount=1;qi.pQueuePriorities=&priority;
    VkDeviceCreateInfo di{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};di.pNext=&features;di.queueCreateInfoCount=1;di.pQueueCreateInfos=&qi;
    if(portable){di.enabledExtensionCount=1;di.ppEnabledExtensionNames=&subset;}
    check(vkCreateDevice(physical,&di,nullptr,&device));vkGetDeviceQueue(device,family,0,&queue);
    VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pi.queueFamilyIndex=family;pi.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    check(vkCreateCommandPool(device,&pi,nullptr,&pool));
    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};ai.commandPool=pool;ai.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;ai.commandBufferCount=1;
    check(vkAllocateCommandBuffers(device,&ai,&command));
    VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};check(vkCreateFence(device,&fi,nullptr,&fence));
  }
  void copy(VkBuffer src,VkDeviceSize src_offset,VkBuffer dst,VkDeviceSize dst_offset,VkDeviceSize bytes) {
    check(vkResetFences(device,1,&fence));check(vkResetCommandBuffer(command,0));
    VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};check(vkBeginCommandBuffer(command,&begin));
    VkMemoryBarrier before{VK_STRUCTURE_TYPE_MEMORY_BARRIER};before.srcAccessMask=VK_ACCESS_MEMORY_WRITE_BIT;before.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT|VK_ACCESS_TRANSFER_WRITE_BIT;
    vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,1,&before,0,nullptr,0,nullptr);
    VkBufferCopy region{src_offset,dst_offset,bytes};vkCmdCopyBuffer(command,src,dst,1,&region);
    VkMemoryBarrier after{VK_STRUCTURE_TYPE_MEMORY_BARRIER};after.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;after.dstAccessMask=VK_ACCESS_MEMORY_READ_BIT;
    vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,0,1,&after,0,nullptr,0,nullptr);
    check(vkEndCommandBuffer(command));VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};submit.commandBufferCount=1;submit.pCommandBuffers=&command;
    check(vkQueueSubmit(queue,1,&submit,fence));check(vkWaitForFences(device,1,&fence,VK_TRUE,10'000'000'000ull));
  }
  ~Native(){if(device){vkDeviceWaitIdle(device);vkDestroyFence(device,fence,nullptr);vkDestroyCommandPool(device,pool,nullptr);vkDestroyDevice(device,nullptr);}if(instance)vkDestroyInstance(instance,nullptr);}
};
struct HostBuffer {
  Native &native;VkBuffer buffer{};VkDeviceMemory memory{};void *mapped{};
  HostBuffer(Native &n,VkDeviceSize size):native(n){
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};bi.size=size;bi.usage=VK_BUFFER_USAGE_TRANSFER_SRC_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    check(vkCreateBuffer(n.device,&bi,nullptr,&buffer));VkMemoryRequirements requirements{};vkGetBufferMemoryRequirements(n.device,buffer,&requirements);
    VkPhysicalDeviceMemoryProperties properties{};vkGetPhysicalDeviceMemoryProperties(n.physical,&properties);
    uint32_t type=UINT32_MAX;for(uint32_t i=0;i<properties.memoryTypeCount;++i)if((requirements.memoryTypeBits&(1u<<i))&&(properties.memoryTypes[i].propertyFlags&(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT))==(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)){type=i;break;}
    require(type!=UINT32_MAX,"no coherent host buffer");VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};ai.allocationSize=requirements.size;ai.memoryTypeIndex=type;
    check(vkAllocateMemory(n.device,&ai,nullptr,&memory));check(vkBindBufferMemory(n.device,buffer,memory,0));check(vkMapMemory(n.device,memory,0,size,0,&mapped));
  }
  ~HostBuffer(){if(mapped)vkUnmapMemory(native.device,memory);vkDestroyBuffer(native.device,buffer,nullptr);vkFreeMemory(native.device,memory,nullptr);}
};
struct Call {
  iree_vm_context_t *context;iree_vm_function_t function{};
  iree_vm_list_t *inputs=nullptr,*outputs=nullptr;
  explicit Call(iree_vm_context_t *c):context(c){
    check(iree_vm_context_resolve_function(c,iree_make_cstring_view("module.scan_exclusive"),&function));
    check(iree_vm_list_create(iree_vm_make_undefined_type_def(),4,iree_allocator_system(),&inputs));
    check(iree_vm_list_create(iree_vm_make_undefined_type_def(),1,iree_allocator_system(),&outputs));
  }
  void reset(){check(iree_vm_list_resize(inputs,0));check(iree_vm_list_resize(outputs,0));}
  void push(iree_hal_buffer_view_t *view){auto ref=iree_hal_buffer_view_retain_ref(view);check(iree_vm_list_push_ref_move(inputs,&ref));}
  void invoke(){check(iree_vm_invoke(context,function,IREE_VM_INVOCATION_FLAG_NONE,nullptr,inputs,outputs,iree_allocator_system()));}
  ~Call(){iree_vm_list_release(inputs);iree_vm_list_release(outputs);}
};
struct BufferSpan {VkBuffer handle{};iree_device_size_t offset{};};
BufferSpan native_span(iree_hal_buffer_t *buffer) {
  iree_hal_buffer_t *backing=nullptr;
  check(iree_hal_vulkan_buffer_resolve_backing(buffer,&backing));
  BufferSpan span;VkDeviceMemory memory{};
  check(iree_hal_vulkan_buffer_handle(backing,&memory,&span.handle));
  check(iree_hal_vulkan_buffer_resolve_backing_offset(buffer,backing,0,&span.offset));
  return span;
}
View input(Native &native,iree_hal_device_t *device,HostBuffer &upload,const int32_t *data,size_t count,const std::vector<iree_hal_dim_t> &shape) {
  iree_hal_buffer_params_t params{};params.type=IREE_HAL_MEMORY_TYPE_DEVICE_LOCAL;params.access=IREE_HAL_MEMORY_ACCESS_ALL;params.usage=IREE_HAL_BUFFER_USAGE_DEFAULT;
  iree_hal_buffer_t *raw=nullptr;check(iree_hal_allocator_allocate_buffer(iree_hal_device_allocator(device),params,count*sizeof(int32_t),&raw));
  Owner<iree_hal_buffer_t,iree_hal_buffer_release> buffer(raw);
  auto span=native_span(raw);
  std::memcpy(upload.mapped,data,count*sizeof(int32_t));native.copy(upload.buffer,0,span.handle,span.offset,count*sizeof(int32_t));
  iree_hal_buffer_view_t *view=nullptr;check(iree_hal_buffer_view_create(raw,shape.size(),shape.data(),IREE_HAL_ELEMENT_TYPE_SINT_32,IREE_HAL_ENCODING_TYPE_DENSE_ROW_MAJOR,iree_allocator_system(),&view));
  return View(view);
}
void compare(Native &native,HostBuffer &readback,iree_hal_buffer_view_t *view,const int32_t *expected,size_t count) {
  auto *buffer=iree_hal_buffer_view_buffer(view);require(iree_hal_buffer_byte_length(buffer)>=count*4,"short output");
  auto span=native_span(buffer);
  native.copy(span.handle,span.offset,readback.buffer,0,count*4);
  require(std::memcmp(readback.mapped,expected,count*4)==0,"scan values differ from frozen independent oracle");
}
int main(int argc,char **argv) try {
  require(argc==2,"expected offline module path");Native native;HostBuffer upload(native,256),readback(native,256);
  {
    iree_async_proactor_pool_t *pool_raw=nullptr;check(iree_async_proactor_pool_create(1,nullptr,iree_async_proactor_pool_options_default(),iree_allocator_system(),&pool_raw));
    Owner<iree_async_proactor_pool_t,iree_async_proactor_pool_release> pool(pool_raw);
    iree_hal_vulkan_syms_t *syms_raw=nullptr;check(iree_hal_vulkan_syms_create(reinterpret_cast<void *>(vkGetInstanceProcAddr),iree_allocator_system(),&syms_raw));
    Owner<iree_hal_vulkan_syms_t,iree_hal_vulkan_syms_release> syms(syms_raw);
    iree_hal_vulkan_device_options_t options{};iree_hal_vulkan_device_options_initialize(&options);options.dispatch_abis=IREE_HAL_VULKAN_DISPATCH_ABI_DESCRIPTOR;
    auto params=iree_hal_device_create_params_default();params.proactor_pool=pool.get();
    iree_hal_vulkan_external_device_params_t external{};external.enabled_features=IREE_HAL_VULKAN_FEATURE_REQUIRED_BASELINE|IREE_HAL_VULKAN_FEATURE_ENABLE_SHADER_FLOAT16|IREE_HAL_VULKAN_FEATURE_ENABLE_STORAGE_BUFFER_16BIT_ACCESS;
    external.compute_queue_set={native.family,1};
#if defined(__APPLE__)
    external.enabled_extensions=IREE_HAL_VULKAN_DEVICE_EXTENSION_KHR_PORTABILITY_SUBSET;
#endif
    iree_hal_device_t *raw=nullptr;
    auto invalid=external;invalid.enabled_features=0;
    auto rejected=iree_hal_vulkan_wrap_device(iree_make_cstring_view("vulkan"),&options,&params,syms.get(),native.instance,native.physical,native.device,&invalid,iree_allocator_system(),&raw);
    require(!iree_status_is_ok(rejected)&&!raw,"missing enabled baseline was accepted");iree_status_free(rejected);
    check(iree_hal_vulkan_wrap_device(iree_make_cstring_view("vulkan"),&options,&params,syms.get(),native.instance,native.physical,native.device,&external,iree_allocator_system(),&raw));
    Owner<iree_hal_device_t,iree_hal_device_release> device(raw);
    iree_runtime_instance_options_t instance_options{};iree_runtime_instance_options_initialize(&instance_options);
    iree_runtime_instance_t *instance_raw=nullptr;check(iree_runtime_instance_create(&instance_options,iree_allocator_system(),&instance_raw));
    Owner<iree_runtime_instance_t,iree_runtime_instance_release> instance(instance_raw);
    // A device has one frontier/device group. Share that original owner while
    // keeping VM execution state separate for each invocation.
    iree_async_frontier_tracker_t *tracker_raw=nullptr;
    check(iree_async_frontier_tracker_create(iree_async_frontier_tracker_options_default(),iree_allocator_system(),&tracker_raw));
    Owner<iree_async_frontier_tracker_t,iree_async_frontier_tracker_release> tracker(tracker_raw);
    iree_hal_device_group_t *group_raw=nullptr;check(iree_hal_device_group_create_from_device(device.get(),tracker.get(),iree_allocator_system(),&group_raw));
    Owner<iree_hal_device_group_t,iree_hal_device_group_release> group(group_raw);
    auto *vm=iree_runtime_instance_vm_instance(instance.get());
    iree_vm_module_t *hal_raw=nullptr;
    check(iree_hal_module_create(vm,iree_hal_module_device_policy_default(),group.get(),IREE_HAL_MODULE_FLAG_NONE,iree_hal_module_debug_sink_stdio(stderr),iree_allocator_system(),&hal_raw));
    Owner<iree_vm_module_t,iree_vm_module_release> hal(hal_raw);
    std::ifstream module_file(argv[1],std::ios::binary);
    std::vector<char> bytes((std::istreambuf_iterator<char>(module_file)),std::istreambuf_iterator<char>());
    require(!bytes.empty(),"empty offline artifact");iree_vm_module_t *bytecode_raw=nullptr;
    check(iree_vm_bytecode_module_create(vm,IREE_VM_BYTECODE_MODULE_FLAG_NONE,iree_make_const_byte_span(bytes.data(),bytes.size()),iree_allocator_null(),iree_allocator_system(),&bytecode_raw));
    Owner<iree_vm_module_t,iree_vm_module_release> bytecode(bytecode_raw);
    std::array<VmContext,2> contexts;
    for(auto &context:contexts){
      std::array<iree_vm_module_t *,2> modules{hal.get(),bytecode.get()};iree_vm_context_t *c=nullptr;
      check(iree_vm_context_create_with_modules(vm,IREE_VM_CONTEXT_FLAG_NONE,modules.size(),modules.data(),iree_allocator_system(),&c));context.reset(c);
    }
    View retained;
    for(size_t variant=0;variant<2;++variant){
      auto values=input(native,device.get(),upload,kInputs[variant].data(),34,{2,17});
      auto initial=input(native,device.get(),upload,kInitial[variant].data(),2,{2});
      Call call(contexts[variant].get());
      for(int repeat=0;repeat<3;++repeat){
        call.reset();
        call.push(values.get());call.push(initial.get());
        iree_hal_semaphore_t *ready_raw=nullptr,*done_raw=nullptr;
        check(iree_hal_semaphore_create(device.get(),IREE_HAL_QUEUE_AFFINITY_ANY,0,IREE_HAL_SEMAPHORE_FLAG_NONE,&ready_raw));
        check(iree_hal_semaphore_create(device.get(),IREE_HAL_QUEUE_AFFINITY_ANY,0,IREE_HAL_SEMAPHORE_FLAG_NONE,&done_raw));
        Owner<iree_hal_semaphore_t,iree_hal_semaphore_release> ready_sem(ready_raw),done_sem(done_raw);
        iree_hal_fence_t *ready_raw_fence=nullptr,*done_raw_fence=nullptr;
        check(iree_hal_fence_create_at(ready_raw,1,iree_allocator_system(),&ready_raw_fence));check(iree_hal_fence_create_at(done_raw,1,iree_allocator_system(),&done_raw_fence));
        Fence ready(ready_raw_fence),done(done_raw_fence);
        auto ready_ref=iree_hal_fence_retain_ref(ready.get()),done_ref=iree_hal_fence_retain_ref(done.get());
        check(iree_vm_list_push_ref_move(call.inputs,&ready_ref));check(iree_vm_list_push_ref_move(call.inputs,&done_ref));
        call.invoke();
        auto pending=iree_hal_fence_query(done.get());bool was_pending=iree_status_is_deferred(pending);iree_status_free(pending);check(iree_hal_fence_signal(ready.get()));
        View output(iree_vm_list_get_buffer_view_retain(call.outputs,0));require(bool(output),"missing output view");
        check(iree_hal_fence_wait(done.get(),iree_make_timeout_ms(10000),IREE_ASYNC_WAIT_FLAG_NONE));require(was_pending,"async call did not return before external ready signal");
        compare(native,readback,output.get(),kExpected[variant].data(),34);
        compare(native,readback,values.get(),kInputs[variant].data(),34);
        compare(native,readback,initial.get(),kInitial[variant].data(),2);
        if(retained)compare(native,readback,retained.get(),kExpected[0].data(),34);
        if(variant==0&&repeat==0)retained=std::move(output);
      }
    }
    contexts={};compare(native,readback,retained.get(),kExpected[0].data(),34);retained.reset();
    std::puts("PASS external device/queue; bounded native GPU copies; async ready/completion; two isolated VM contexts; repeat3; inputs unchanged; retained result outlives VM contexts; missing feature rejected");
  }
  check(vkDeviceWaitIdle(native.device));
  std::puts("PASS original runtime released without destroying external Vulkan owner; no Python/compiler at execution");
  return 0;
} catch(const std::exception &e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
