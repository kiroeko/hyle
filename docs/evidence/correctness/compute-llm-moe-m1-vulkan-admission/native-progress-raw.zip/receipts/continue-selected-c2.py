import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
logs = Path('.scratch/validation/m1-vulkan-admission')
old = 'b836d1382519a66515582ea09d95d896c5240ec1'
candidate = 'db770b6fc1e46aa8d8aa86c1102d50acf26eb49f'
base = '3dd189e13da96fa83d50335821f0d163037592d5'
build = Path('C:/hv/selected/dd6ba9eea2aa2417e511/build-605ef2324f17e5ef3df1')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == candidate
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
changed = subprocess.check_output(['git','diff','--name-only',old,candidate],text=True).splitlines()
assert changed == ['tests/compute_provider_ggml_vulkan/mxfp4_qualification_test.cc'], changed
assert subprocess.check_output(['git','diff',old,candidate,'--','src','include','cmake','third_party','CMakeLists.txt']) == b''
record = {'kind':'original selected commands, incremental fixture correction; not a forged selector cache receipt',
          'candidate':candidate,'original_candidate':old,'baseline':base,
          'fixture_only_changes':changed,'unchanged_product_and_build_inputs':True,
          'prior_selector_verdict':'FAIL: repeated qualification input reused by gallocr; correction retains external native input owners',
          'build':str(build),'status':'RUNNING','commands':[]}
receipt=logs/'selected-continuation-c2.json'
assert not receipt.exists()
def save():
    receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
def run(label,argv):
    assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
    path=logs/(label+'.log')
    assert not path.exists()
    print('RUN',label,flush=True)
    start=time.time()
    with path.open('wb') as output:
        result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT)
    item={'label':label,'argv':argv,'exit_code':result.returncode,
          'elapsed_seconds':time.time()-start,'log':str(path),
          'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    record['commands'].append(item)
    save()
    if result.returncode:
        record['status']='FAIL';save()
        print(path.read_text(errors='replace')[-9000:],flush=True)
        raise SystemExit(result.returncode)
save()
plan=logs/'selected-corrected-plan-c2.json'
run('continued-c2-plan',[sys.executable,'scripts/validation-select.py','plan','--base',base,
                     '--candidate',candidate,'--context','.scratch/validation/windows-msvc-context.json',
                     '--output',str(plan)])
selection=json.loads(plan.read_text())
for gate in selection['selected_gates']:
    if gate['id']=='configure':
        # Same canonical source path, product/CMake inputs and compiler environment.
        # Reconfigure via the original command against existing products; no receipt reuse.
        record['configure_artifact']={'unchanged_cmake_inputs':True,'original_log':'continued-configure-0.log','sha256':hashlib.sha256((logs/'continued-configure-0.log').read_bytes()).hexdigest()}
        save()
        continue
    for index,command in enumerate(gate['commands']):
        argv=[str(arg).replace('{python}',sys.executable).replace('{build}',str(build)) for arg in command]
        # The plan embeds toolchain only during run. Match the original verified configure exactly.
        if gate['id']=='configure':
            context=json.loads(Path('.scratch/validation/windows-msvc-context.json').read_text())['toolchain']
            argv += ['-DCMAKE_CXX_COMPILER='+context['compiler_path']]
            argv += ['-D'+key+'='+value for key,value in context['flags'].items()]
        run('continued-c2-'+gate['id'].replace(':','-')+'-'+str(index),argv)
record['status']='PASS';save()
print('All original selected commands passed for corrected fixture candidate.',flush=True)
