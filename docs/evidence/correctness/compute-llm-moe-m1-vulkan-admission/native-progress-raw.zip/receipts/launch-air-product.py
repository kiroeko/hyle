import hashlib
import json
from pathlib import Path
import subprocess

logs=Path('.scratch/validation/m1-vulkan-admission')
archive=Path('C:/hv/product-db770b6f.tar.gz')
identity={'candidate':'db770b6fc1e46aa8d8aa86c1102d50acf26eb49f','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
(logs/'air-product-forward.json').write_bytes((json.dumps(identity,indent=2)+'\n').encode())
host='kiro@172.22.10.198'
command="test ! -e /Users/kiro/hyle-m1v-product && mkdir /Users/kiro/hyle-m1v-product && printf '%s\\n' 'M1-V product db770b6fc1e46aa8d8aa86c1102d50acf26eb49f' > /Users/kiro/hyle-m1v-product/owner.txt"
subprocess.run(['ssh','-o','BatchMode=yes',host,command],check=True,timeout=30)
for path,name in [(archive,'product.tar.gz'),(logs/'air-product.sh','run.sh')]:
    subprocess.run(['scp',str(path),host+':/Users/kiro/hyle-m1v-product/'+name],check=True,timeout=120)
log=logs/'air-product-launch.log'
with log.open('wb') as stream:
    result=subprocess.run(['ssh','-o','BatchMode=yes',host,'bash /Users/kiro/hyle-m1v-product/run.sh'],stdout=stream,stderr=subprocess.STDOUT,timeout=2400)
print('Air product factor bundle exit',result.returncode,flush=True)
print(log.read_text(errors='replace')[-7000:],flush=True)
raise SystemExit(result.returncode)
