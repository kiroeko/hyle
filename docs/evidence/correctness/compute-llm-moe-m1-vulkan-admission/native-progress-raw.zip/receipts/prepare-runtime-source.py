import hashlib
import json
from pathlib import Path
import tarfile
import urllib.request

root = Path('C:/hv/source/iree-6ef606b6fa3e12bd2c12d36a07463069eb71185f')
logs = Path('.scratch/validation/m1-vulkan-admission')
items = [
    ('flatcc','dvidelabs/flatcc','9362cd00f0007d8cbee7bff86e90fb4b6b227ff3'),
    ('vulkan_headers','KhronosGroup/Vulkan-Headers','df60f0316899460eeaaefa06d2dd7e4e300c1604'),
]
receipt=logs/'runtime-source-qualification.json'
assert not receipt.exists()
records=[]
for name,repo,pin in items:
    url=f'https://codeload.github.com/{repo}/tar.gz/{pin}'
    archive=Path('C:/hv/downloads')/(name+'-'+pin+'.tar.gz')
    target=root/'third_party'/name
    assert target.is_relative_to(Path('C:/hv/source'))
    assert not target.is_symlink() and (not target.exists() or not any(target.iterdir()))
    if not archive.exists():
        with urllib.request.urlopen(url,timeout=90) as source,archive.open('wb') as output:
            while chunk:=source.read(1024*1024): output.write(chunk)
    with tarfile.open(archive) as tar:
        members=tar.getmembers()
        for member in members:
            name_parts=Path(member.name).parts
            if len(name_parts)<2: continue
            member.name='/'.join(name_parts[1:])
            tar.extract(member,target,filter='data')
    records.append({'name':name,'pin':pin,'url':url,'bytes':archive.stat().st_size,
                    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source':str(target)})
    print(name,'prepared original pinned source',flush=True)
receipt.write_bytes((json.dumps(records,indent=2)+'\n').encode())
