import ast
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
windows=sys.platform=='win32'
if windows:
    import ctypes
    ctypes.windll.kernel32.SetErrorMode(0x8003)
    assert root==Path('C:/hv/parameterized')
    runtime=Path('C:/hv/tools-win/iree/_runtime_libs/iree-run-module.exe')
    interop=Path('C:/hv/interop-win-build');device='vulkan://GPU-e73765606f5dec196ee43dd3a2c81ef8'
else:
    assert root==Path('/Users/kiro/hyle-m1v-qvk/parameterized')
    assert (root.parent/'owner.txt').read_text().strip()=='M1-V Q-VK disposable forward verification'
    runtime=root.parent/'runtime-build/tools/iree-run-module';interop=root.parent/'interop-build';device='vulkan'
    os.environ['VK_DRIVER_FILES']='/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json'
    os.environ['DYLD_LIBRARY_PATH']='/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'manifest.json').read_text())
for abi in ('sync','async'):assert sha(root/(abi+'.vmfb'))==manifest['artifacts'][abi]
receipt=root/'result.json';assert not receipt.exists()
record={'status':'RUNNING','runtime_sha256':sha(runtime),'manifest_sha256':sha(root/'manifest.json'),'commands':[],'cases':[]}
def save():receipt.write_bytes((json.dumps(record,indent=2)+'\n').encode())
def run(label,argv):
    log=root/(label+'.log');assert not log.exists();start=time.time()
    with log.open('wb') as stream:result=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
    record['commands'].append({'label':label,'argv':argv,'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'log_sha256':sha(log)});save()
    if result.returncode:
        record['status']='FAIL';save();print(log.read_text(errors='replace')[-5000:]);raise SystemExit(result.returncode)
def npy(path):
    data=path.read_bytes();assert data[:6]==b'\x93NUMPY';width=2 if data[6]==1 else 4
    length=int.from_bytes(data[8:8+width],'little');header=ast.literal_eval(data[8+width:8+width+length].decode().strip());assert not header['fortran_order']
    dtype=header['descr'];formats={'<i4':'i','<f4':'f','<f2':'e'}
    return header['shape'],dtype,tuple(v[0] for v in struct.iter_unpack('<'+formats[dtype],data[8+width+length:]))
for kind in ('static','shared'):
    exe=interop/('qvk_'+kind+'_consumer'+('.exe' if windows else ''))
    record[kind+'_exe_sha256']=sha(exe)
    run('native-'+kind,[str(exe),str(root/'async.vmfb')])
    print('native-'+kind,'PASS',flush=True)
for case in manifest['cases']:
    label=case['name']+'-'+str(case['variant']);output=root/(label+'-actual.npy');assert not output.exists()
    command=[str(runtime),'--device='+device,'--module='+str(root/'sync.vmfb'),'--function='+case['name']]
    for item in case['inputs']:
        assert sha(root/item['file'])==item['sha256'];command+=['--input=@'+str(root/item['file'])]
    command+=['--output=@'+str(output)];run(label,command)
    assert sha(root/case['expected'])==case['expected_sha256']
    expected,actual=npy(root/case['expected']),npy(output)
    passed=expected==actual and all(math.isfinite(v) for v in actual[2])
    record['cases'].append({'label':label,'pass':passed,'actual_sha256':sha(output),'shape':actual[0],'dtype':actual[1]});save();print(label,passed,flush=True)
    if not passed:record['status']='FAIL';save();raise SystemExit(1)
record['status']='PASS';save();print('Parameterized numeric/native qualification PASS',flush=True)
