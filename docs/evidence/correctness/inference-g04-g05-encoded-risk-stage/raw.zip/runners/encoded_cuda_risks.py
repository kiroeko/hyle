from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
ROOT=Path('/mnt/c/public/project-hyle/hyle')
SOURCE=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
BUILD=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
OUT=ROOT/'.scratch/inference-gaps/g04-g05/risk'
archive,attempt=sys.argv[1:];RUN=OUT/f'cuda-{attempt}';RUN.mkdir(exist_ok=False)
assert SOURCE.is_dir() and not (SOURCE/'.git').exists()
with zipfile.ZipFile(archive) as package:
    inputs=json.loads(package.read('source-manifest.json'))
    for item in inputs:
        path=Path(item['path']);assert not path.is_absolute() and '..' not in path.parts
        raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
        file=SOURCE/path
        if not file.exists() or file.read_bytes()!=raw:
            file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
hook=OUT/'cuda-risk-project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 function(g04_cuda_risks)
  add_executable(g04_encoded_cuda_risks "@SOURCE@/tests/compute_batch/pending_paged_receiver_cuda_risks.cc")
  target_compile_features(g04_encoded_cuda_risks PRIVATE cxx_std_23)
  target_compile_options(g04_encoded_cuda_risks PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_compile_definitions(g04_encoded_cuda_risks PRIVATE HYLE_ENCODED_PAGE_RISK=1)
  target_link_libraries(g04_encoded_cuda_risks PRIVATE hyle::compute)
  hyle_stage_runtime(g04_encoded_cuda_risks)
  set_source_files_properties("@SOURCE@/src/compute_backend_cuda/cuda_backend.cc" DIRECTORY "@SOURCE@/src/compute_backend_cuda" PROPERTIES COMPILE_DEFINITIONS HYLE_TESTING=1)
 endfunction()
 cmake_language(DEFER CALL g04_cuda_risks)
endif()
'''.replace('@SOURCE@',str(SOURCE))
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
identity={key:subprocess.check_output(command,text=True).strip() for key,command in [
    ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
    ('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu','--format=csv,noheader'])]}
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
record={'state':'RUNNING','inputs':inputs,'identity':identity,'max_jobs':4,'stages':[],'cumulative_seconds':0,
        'scope':'Actual RTX4070 FP8 Kscale.5/Vscale2 D64/128 window16 original pending receiver five source/unknown/abandon/foreign-queue risk modes. Existing observation hooks enabled in one backend host TU only; no shipping SDK/GPU sanitizer/P1 claim.'}
commands=[('configure',['cmake','-S',str(SOURCE),'-B',str(BUILD),'-DCMAKE_PROJECT_INCLUDE='+str(hook)]),
          ('compile',['cmake','--build',str(BUILD),'--target','g04_encoded_cuda_risks','--parallel','4']),
          ('five-risk-modes',[str(BUILD/'bin/g04_encoded_cuda_risks')])]
for stage,command in commands:
    if stage=='compile':
        dry=subprocess.check_output(['ninja','-C',str(BUILD),'-n','g04_encoded_cuda_risks'],env=env,text=True)
        (RUN/'dry-run.txt').write_text(dry)
        if '.cu.o' in dry or 'nvcc' in dry:
            record['state']='TERMINAL_FAIL';record['failure']='Unplanned CUDA kernel rebuild refused before execution'
            (RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
            raise SystemExit(1)
    start=time.monotonic();log=RUN/f'{stage}.log'
    with log.open('w') as stream:
        process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid}))
        print('cuda',stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start
    record['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    record['cumulative_seconds']+=elapsed;record['state']='TERMINAL_FAIL' if code else 'RUNNING'
    (RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    print('cuda',stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
rows=json.loads(subprocess.check_output(['ninja','-C',str(BUILD),'-t','compdb'],text=True))
backend=[r for r in rows if r['file'].endswith('/src/compute_backend_cuda/cuda_backend.cc')]
assert len(backend)==1 and '-DHYLE_TESTING=1' in backend[0]['command']
(RUN/'observation-hook-host-tu.json').write_text(json.dumps(backend,indent=2)+'\n')
record['state']='TERMINAL_PASS';(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
