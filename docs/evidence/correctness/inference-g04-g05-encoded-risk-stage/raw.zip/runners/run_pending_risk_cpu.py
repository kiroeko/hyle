from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/f'.scratch/inference-gaps/g04-g05/risk/cpu-{sys.argv[1]}'
OUT.mkdir(parents=True,exist_ok=False)
BUILD=ROOT/'.scratch/build-compute-v2-dev'
HOOK=ROOT/'.scratch/inference-gaps/g02/native-page-node/project.cmake'
source=ROOT/'tests/compute_batch/pending_paged_receiver_cpu_risks.cc'
body=HOOK.read_text()
targets=['g04_encoded_pending_risks','g04_plain_pending_control']
if targets[0] not in body:
    addition='\nif(PROJECT_NAME STREQUAL "hyle")\n function(g04_pending_risks)\n'
    for target in targets:
        addition+=f'  add_executable({target} "{source.as_posix()}")\n'
        addition+=f'  target_compile_features({target} PRIVATE cxx_std_23)\n'
        addition+=f'  target_compile_options({target} PRIVATE /W4 /WX /wd4324 /utf-8)\n'
        addition+=f'  target_link_libraries({target} PRIVATE hyle::compute)\n'
        addition+=f'  hyle_stage_runtime({target})\n'
    addition+=f'  target_compile_definitions({targets[0]} PRIVATE HYLE_ENCODED_PAGE_RISK=1)\n'
    addition+=' endfunction()\n cmake_language(DEFER CALL g04_pending_risks)\nendif()\n'
    HOOK.write_text(body+addition,encoding='utf-8',newline='\n')
setup=subprocess.check_output(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf-8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in paths if (ROOT/name).is_file() and not name.startswith(('evidence/','.scratch/','.git'))}
record={'state':'RUNNING','max_jobs':4,'inputs':inputs,'identity':{'host':env.get('COMPUTERNAME'),'compiler':env.get('VCTOOLSVERSION')},
        'scope':'Actual CPU Q8 D64/128 window16 pending receiver nine risk modes; same original plain fixture control; no GPU/SDK/P1 claim','stages':[],'cumulative_seconds':0}
commands=[('configure',['cmake','-S',str(ROOT),'-B',str(BUILD)]),
          ('compile',['cmake','--build',str(BUILD),'--target',*targets,'--parallel','4']),
          *[(target,[str(BUILD/'bin'/f'{target}.exe')]) for target in targets]]
for stage,command in commands:
    start=time.monotonic();log=OUT/f'{stage}.log'
    with log.open('wb') as stream:
        process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (OUT/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid}))
        print(stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start
    record['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    record['cumulative_seconds']+=elapsed
    record['state']='TERMINAL_FAIL' if code else 'RUNNING'
    (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    print(stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (OUT/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
record['state']='TERMINAL_PASS'
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(OUT/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
