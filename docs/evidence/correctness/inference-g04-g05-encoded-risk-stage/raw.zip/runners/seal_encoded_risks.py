from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.scratch/inference-gaps/g04-g05'
RUN=BASE/'risk'
OUT=ROOT/'evidence/correctness/inference-g04-g05-encoded-risk-stage'
records=[]
def add(label,path,archive=None):
    data=json.loads(path.read_text())
    assert data['state'].startswith('TERMINAL_'),label
    records.append((label,path,data,archive))
add('windows-cpu-1',RUN/'cpu-1/result.json')
add('windows-encoder-9',BASE/'common-encoded/cpu-9/result.json')
windows_xml=ET.parse(BASE/'common-encoded/cpu-9/tests.xml').getroot()
assert windows_xml.attrib['tests']=='7' and windows_xml.attrib['failures']=='0'
for route,attempts in [('apple',(1,2)),('vulkan',(1,))]:
    for n in attempts:add(f'air-{route}-{n}',RUN/route/f'result-{n}.json',RUN/route/f'source-{n}.zip')
for mode,attempts in [('asan',(1,2)),('tsan',(1,2)),('ubsan',(1,))]:
    for n in attempts:
        folder=RUN/f'host-{mode}-{n}'
        add(f'host-{mode}-{n}',folder/'result.json',RUN/f'source-host-{mode}-{n}.zip')
        if (folder/'tests.xml').exists():
            xml=ET.parse(folder/'tests.xml').getroot()
            assert xml.attrib['tests']=='10' and xml.attrib['failures']=='0'
        else:assert mode=='tsan' and n==1 and 'unexpected memory mapping' in (folder/'tests.log').read_text()
for n in (1,):add(f'cuda-{n}',RUN/f'cuda-{n}/result.json',RUN/f'source-cuda-{n}.zip')
assert all(r['state']=='TERMINAL_PASS' for label,_,r,_ in records if label not in ('air-apple-1','host-tsan-1'))
assert next(record for label,_,record,_ in records if label=='air-apple-1')['state']=='TERMINAL_FAIL'
names=['tests/compute_batch/native_paged_risk_fixture.h','tests/compute_batch/pending_paged_receiver_cpu_risks.cc',
       'tests/compute_batch/pending_paged_receiver_cuda_risks.cc','tests/compute_provider_ggml/native_paged_test.cc']
sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names}
for label,_,record,archive in records:
    inputs=record['inputs'];inputs=inputs if isinstance(inputs,dict) else {i['path']:i['sha256'] for i in inputs}
    relevant=[names[3]] if label=='windows-encoder-9' else [names[1]] if label.startswith('windows') else [names[0]] if label.startswith('air') else [names[2]] if label.startswith('cuda') else [names[1],names[3]]
    if label in ('air-apple-1','host-asan-1'):continue
    for name in relevant:assert inputs[name]==sha[name],(label,name)
for label,_,_,_ in records:
    if label.startswith('host'):
        assert (RUN/label/'instrumented-inputs.json').is_file()
assert (RUN/'cuda-1/observation-hook-host-tu.json').is_file()
OUT.mkdir(parents=True,exist_ok=False)
result={
 'kind':'G04_G05_ENCODED_PAGE_FINITE_NATIVE_AND_CPU_HOST_RISKS',
 'verdict':'PASS_FINITE_ACTUAL_NATIVE_RISK_MODES_AND_CPU_HOST_SANITIZERS',
 'product_base':'304f7a600; this stage changes test fixtures only; eleven product owners remain AUDITED',
 'input_sha256':sha,
 'qualified':[
   'Actual Windows CPU-only Q8 D64/128 window16: all nine original pending receiver risk modes PASS; original plain fixture nine modes also PASS; seven public encoder tests including real concurrent Q8/FP8 lanes PASS',
   'Actual Air Apple Q8 D64/128 window16: six original native modes PASS, including queued metadata failure, cancel, abandon and actual page/query retirement; all52cold controller allocation failures and old-generation reuse after rejected cold prepare',
   'Actual Air Vulkan Q8 D64/128 window16: six original native modes PASS, including preaccept rejection, accepted actual wait error, unknown poll with retained guards and actual fence retirement; all55cold allocation failures',
   'Actual Air both routes: exact metadata backing limit, empty output and old result exclusion, foreign resource and swapped different-byte K/V rejection; separate original slot after a native bind failure; original plain domain-check control PASS',
   'Actual WSL CPU-only ASan with detect_leaks1, UBSan with float-cast-overflow, and TSan: each10public encoder/encoded F2/Graph tests plus nine Q8 receiver risk modes PASS',
   'Two real CPU threads/queues using independent original invocations of one prepared Q8/FP8 artifact: isolated lane0 NaN failure, original failed invocation rejection and fresh recovery; both lanes independently check their complete bytes',
   'Actual RTX4070 CUDA FP8 Kscale.5/Vscale2 D64/128 window16: five original receiver source/unknown/late failure/abandon/foreign CPU queue modes PASS, retaining actual producer and original native slot through retirement'],
 'history':'Original Air Apple attempt1 FAIL retained: fixture wrongly reused a controller after native bind failure. Fix uses a separate original slot. ASan1 normal execution PASS predates test-only exception-safe start gate; final ASan2 and TSan/UBSan bind the repaired gate. TSan1 exits66 before main with unexpected memory mapping; TSan2 uses original validated per-process setarch x86_64 -R, no global kernel changes. Original native hooks and product error contracts unchanged.',
 'instrumentation':'Actual compile commands bind sanitizer flags to ggml-quants, HYLE CPU encoder, both public positive consumer TUs and pending receiver fixture. CUDA source-only private observation hooks are enabled only in the original backend host TU, not shipping SDK; original numeric UBSan negative control remains separately sealed.',
 'not_proven':['New-domain Apple/Vulkan/CUDA full host sanitizer matrix','GPU shader/driver sanitizer','Native private pool byte bounds','New-domain installed static/shared and independent header qualification','Immutable candidate P1 or complete G04/G05'],
 'runs':[dict(label=label,**{k:v for k,v in record.items() if k!='inputs'}) for label,_,record,_ in records],
 'cumulative_seconds':sum(record['cumulative_seconds'] for _,_,record,_ in records)}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
extra=['tests/compute_batch/native_paged_apple_risks.cc','tests/compute_batch/native_paged_vulkan_risks.cc',
       'tests/compute_batch/native_apple_failure_fixture.h','tests/compute_batch/native_vulkan_failure_fixture.h',
       'tests/compute_batch/allocation_fault_fixture.h','tests/compute_batch/encoded_page_common_consumer.cc']
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as raw:
    for label,path,record,archive in records:
        if label.startswith('air'):
            n=label.rsplit('-',1)[1];files=path.parent.glob(f'*-{n}.*')
        else:files=path.parent.glob('*')
        for file in sorted(files):
            if file.is_file() and file.suffix!='.zip':raw.write(file,f'{label}/{file.name}')
        if archive:
            with zipfile.ZipFile(archive) as package:
                for name in [*names,*extra,'source-manifest.json']:
                    raw.writestr(f'inputs/{label}/{name}',package.read(name))
    for name in names:raw.write(ROOT/name,'inputs/current/'+name)
    for name in ['seal_encoded_risks.py','run_pending_risk_cpu.py','pending_risk_air.py','launch_pending_risk_air.py',
                 'encoded_host_risks.py','launch_encoded_host_risks.py','encoded_cuda_risks.py','launch_encoded_cuda_risks.py','run_common_encoded_cpu.py']:
        raw.write(BASE/name,'runners/'+name)
    for file in sorted(RUN.glob('*.cmake')):raw.write(file,'runners/'+file.name)
print(json.dumps({'runs':len(records),'cumulative_seconds':result['cumulative_seconds'],'raw_bytes':(OUT/'raw.zip').stat().st_size}))
