from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
route,attempt=sys.argv[1:]
assert route in ('apple','vulkan')
BASE=Path('/Users/kiro/hyle-scratch/compute-unified')
SOURCE=BASE/'source-c8874688'
PARENT=BASE/f'a-cpu-{route}/selected-graph/source-parent'
BUILD=PARENT.parent/'source-build'
OUT=BASE/f'g04-g05-{route}-risks';OUT.mkdir(exist_ok=True)
result_file=OUT/f'result-{attempt}.json';assert not result_file.exists()
identity={name:subprocess.check_output(args,text=True).strip() for name,args in [
    ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
    ('compiler',['/Library/Developer/CommandLineTools/usr/bin/clang++','--version']),('memory',['/usr/sbin/sysctl','-n','hw.memsize'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
assert SOURCE.is_dir() and not (SOURCE/'.git').exists()
with zipfile.ZipFile(OUT/f'source-{attempt}.zip') as package:
    inputs=json.loads(package.read('source-manifest.json'))
    for item in inputs:
        relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
        raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
        file=SOURCE/relative
        if not file.exists() or file.read_bytes()!=raw:
            file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
targets=['g04_encoded_native_risks','g04_plain_native_control']
cmake=PARENT/'CMakeLists.txt';body=cmake.read_text()
if f'add_executable({targets[0]} ' not in body:
    for target in targets:
        body+=f'\nadd_executable({target} "{SOURCE}/tests/compute_batch/native_paged_{route}_risks.cc")\n'
        body+=f'target_compile_features({target} PRIVATE cxx_std_23)\n'
        body+=f'target_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\n'
        body+=f'target_link_libraries({target} PRIVATE hyle::graph)\nhyle_stage_runtime({target})\n'
    body+=f'target_compile_definitions({targets[0]} PRIVATE HYLE_ENCODED_PAGE_RISK=1)\n'
    cmake.write_text(body)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
result={'state':'RUNNING','max_jobs':4,'inputs':inputs,'identity':identity,'stages':[],'cumulative_seconds':0,
        'scope':'Actual Air Q8 D64/128 window16 native metadata/OOM/cancel/unknown/retirement six modes using original injected native boundary; plain domain-check control; no SDK/san/P1 claim'}
commands=[('configure',['/opt/homebrew/bin/cmake','-S',str(PARENT),'-B',str(BUILD)]),
          ('compile',['/opt/homebrew/bin/cmake','--build',str(BUILD),'--target',*targets,'--parallel','4']),
          ('encoded-six-modes',[str(BUILD/targets[0])]),
          ('plain-domain-control',[str(BUILD/targets[1]),'5'])]
for stage,command in commands:
    start=time.monotonic();log=OUT/f'{stage}-{attempt}.log'
    with log.open('w') as stream:
        process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
        (OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid}))
        print(route,stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start
    result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    result['cumulative_seconds']+=elapsed;result['state']='TERMINAL_FAIL' if code else 'RUNNING'
    result_file.write_text(json.dumps(result,indent=2)+'\n')
    print(route,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
result['state']='TERMINAL_PASS';result_file.write_text(json.dumps(result,indent=2)+'\n')
(OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
