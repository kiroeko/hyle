from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[3]
route,attempt=sys.argv[1:];assert route in ('apple','vulkan')
OUT=ROOT/f'.scratch/inference-gaps/g04-g05/risk/{route}';OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/f'source-{attempt}.zip';assert not archive.exists()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
    for name in sorted(set(paths)):
        if name.startswith(('evidence/','.scratch/','.git')):continue
        file=ROOT/name
        if not file.is_file():continue
        raw=file.read_bytes();inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()});package.writestr(name,raw)
    package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
host='kiro@172.22.10.198';remote=f'/Users/kiro/hyle-scratch/compute-unified/g04-g05-{route}-risks'
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp',str(archive),str(OUT.parents[1]/'pending_risk_air.py'),host+':'+remote+'/'],check=True)
code=subprocess.run(['ssh','-o','BatchMode=yes',host,'python3',remote+'/pending_risk_air.py',route,attempt]).returncode
subprocess.run(['scp',host+':'+remote+f'/result-{attempt}.json',host+':'+remote+f'/job-{attempt}.json',str(OUT)],check=True)
subprocess.run(['scp',host+':'+remote+f'/*-{attempt}.log',str(OUT)],check=True)
raise SystemExit(code)
