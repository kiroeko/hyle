from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g06';out=base/'common-source-4'
r=json.loads((out/'result.json').read_text(encoding='utf-8'));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert r['state']=='TERMINAL_PASS' and r['candidate']==head
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert all(x['exit_code']==0 for x in r['stages'])
tests=[]
for target,expected in zip(r['targets'],[56,6,24]):
 p=out/(target+'.xml');x=E.parse(p).getroot()
 assert int(x.get('tests'))==expected and all(int(x.get(k,'0'))==0 for k in ['failures','errors','disabled'])
 assert not x.findall('.//skipped')
 names=[t.get('classname')+'.'+t.get('name') for t in x.findall('.//testcase')]
 tests.append(dict(target=target,tests=expected,failures=0,errors=0,disabled=0,skipped=0,testcases=names,xml_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert any('TwoNativeAttentionNodesShareUploadBeforePreparation' in n for t in tests for n in t['testcases'])
assert any('DeltaMetadataMirrorMatchesIndependentFullWireAcrossGrowShrinkAndEmpty' in n for t in tests for n in t['testcases'])
prior=[]
for number in [1,2,3]:
 d=json.loads((base/f'common-source-{number}/result.json').read_text());assert d['state']=='TERMINAL_SETUP_FAIL'
 prior.append(dict(attempt=number,result=d))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[]
for name in subprocess.check_output(['git','diff','--name-only','f989f331c',head],text=True).splitlines():
 p=root/name
 if p.is_file():inputs.append(dict(path=name,sha256=sha(p)))
artifacts=[]
for name in ['hyle_compute_batch.dll','hyle_graph_batch.dll','hyle_compute_provider_ggml.dll','hyle_simd.dll',*[t+'.exe' for t in r['targets']]]:
 p=Path(r['build'])/'bin'/name;assert p.is_file();artifacts.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
dest=root/'evidence/correctness/inference-g06-common-source-windows-attempt-4';dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for number in [1,2,3,4]:
  folder=base/f'common-source-{number}'
  for p in sorted(folder.iterdir()):
   if p.is_file():z.write(p,f'common-source-{number}/'+p.name)
 for name in ['run_common_source.py','seal_common_source4.py']:
  z.write(base/name,'helpers/'+name)
 for item in inputs:z.write(root/item['path'],'source/'+item['path'])
record=dict(kind='G06_COMMON_FOUNDATION_M1_M2_S1_L1_WINDOWS_SOURCE',verdict='PASS_SOURCE_COMMON_CPU_ONLY',candidate=head,
 owner_states={'compute_batch':'AUDITED','graph_batch':'AUDITED'},identity=r['identity'],tests=tests,total_tests=86,
 source_inputs=inputs,artifacts=artifacts,execution=r,prior_setup_failures=prior,raw_zip_sha256=sha(dest/'raw.zip'),
 proven=['Active-sized immutable snapshots, concurrent cached fixed-capacity exports, independent full blob zero-padding oracle, export OOM retry and old reader lifetime.',
 'Actual original CPU attention with generation-only delta and identical-version zero upload/waits; 64-step independent complete wire oracle covers empty, growth, shrink, repeated/shared pages, reorder and inactive zeroing.',
 'Two dependent actual CPU attention nodes share one metadata upload before planning; reversed caller NodeLayout order, local plan/workspace behavior, actual numeric output, same-version zero-upload and new generation delta assertions.',
 'Original CPU F16/BF16 encoded producer/F2/Direct/Graph/joint fragments, native paged/ragged oracle/budget/failure consumers passed the complete24-test set.'],
 limits=['This is finite source/correctness evidence; not G06 aggregate acceptance or an engineering throughput/capture claim.',
 'ASan/UBSan/TSan, relocated static/shared and header/direct native qualifications remain pending on the final applicable candidate.',
 'G06-D four-route runtime/topology/decode, native metadata banks and pending/native/Graph admission costs remain required; no unchanged CUDA P1 or vendor retry authorized.',
 'Source4 outer time overlaps its stage times. Prior setup1 recorded configure122.938s/manifest0.187s; prior setup2 observer overlaps its commit+launch; setup3 recorded manifest and lower bound. Missing observation gaps remain UNKNOWN, never zero.',
 'Actual targeted build includes required stale CPU dependency edges (including regenerated SIMD) from the existing cache; no CUDA compilation/global build/P1/model/server occurred.'])
(dest/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=record['verdict'],tests=86,build_seconds=next(x['elapsed_seconds'] for x in r['stages'] if x['stage']=='build'),outer_seconds_overlaps=r['outer_elapsed_seconds'],receipt=str(dest/'receipt.json'))))
