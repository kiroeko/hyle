from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time

root=Path.cwd();base=root/'.scratch/inference-gaps/g06';out=base/('common-source-'+sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
started=time.monotonic();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True),'Canonical candidate must be clean'
assert head==sys.argv[2]
registry=json.loads((root/'docs/implementation/module-status.json').read_text(encoding='utf-8'))
assert all(next(x for x in registry['modules'] if x['module']==name)['state']=='AUDITED' for name in ['compute_batch','graph_batch'])
setup=subprocess.run(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.stdout.splitlines() if '=' in line and not line.startswith('=')))
build=root/'.scratch/build-compute-v2-dev';hook=root/'.scratch/inference-gaps/g02/native-page-node/project.cmake'
r=dict(state='SETUP',pid=os.getpid(),candidate=head,build=str(build),max_jobs=4,stages=[],
       identity=dict(host=env.get('COMPUTERNAME'),compiler=env.get('VCTOOLSVERSION'),route='CPU/Windows'),
       scope='G06 common M1/M2/S1/L1 source factors and actual native CPU/Graph consumers only; no CUDA/native-Air/SDK/sanitizer/P1 verdict')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():
 r['outer_elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
def run(stage,command):
 stamp=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as stream:
  p=subprocess.Popen(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=command,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=log.as_posix()));save()
 if code:r.update(state='TERMINAL_FAIL');r.pop('child_pid',None);save();raise SystemExit(code)
if '--reuse-configure' not in sys.argv:
 run('configure',['cmake','-S',str(root),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook),'-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF'])
 run('prepare-manifest',['ninja','-C',str(build),'build.ninja'])
else:
 previous=json.loads((base/'common-source-1/result.json').read_text());assert previous['state']=='TERMINAL_SETUP_FAIL'
 r['reused_configuration']={'from':'common-source-1','candidate':previous['candidate'],'stages':previous['stages'],'old_failure_retained':True}
 cache=(build/'CMakeCache.txt').read_text(encoding='utf-8');assert 'HYLE_BUILD_TESTS:BOOL=ON' in cache and 'HYLE_COMPUTE_ROUTES:STRING=cpu' in cache
ninja=(build/'build.ninja').read_text(encoding='utf-8');targets=[]
for module in ['compute_batch','graph_batch']:
 target='hyle_'+module+'_test';assert re.search(r'^build '+target+r': phony bin',ninja,re.M),target
 targets.append(target)
targets+=['g04_g05_encoded_common_pages'];r['targets']=targets
dry=subprocess.check_output(['ninja','-C',str(build),'-n',*targets],env=env,text=True);(out/'dry-run.log').write_text(dry,encoding='utf-8')
assert 'Building CUDA object' not in dry and 'ggml-cuda' not in dry,'Unrelated CUDA rebuild rejected'
assert 'Re-running CMake' not in dry,'Reused configuration must be fresh'
r['build_edges']=len(dry.splitlines());save()
run('build',['cmake','--build',str(build),'--target',*targets,'--parallel','4','--','-k','0'])
for target in targets:
 run(target,[str(build/'bin'/(target+'.exe')),'--gtest_output=xml:'+str(out/(target+'.xml'))])
r.update(state='TERMINAL_PASS');r.pop('child_pid',None);save();print('TERMINAL_PASS',flush=True)
