from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
scratch = (R/'.scratch').resolve()
targets = [R/'.scratch/inference-causal-conv-20261026/cli/link/hyle.exe',
    R/'.scratch/inference-causal-conv-20261026/case/link/host-image-consumer.exe',
    R/'.scratch/inference-host-image-lag1-20261026/link/host-image-lagged-consumer.exe',
    W/'test/link/storage-freeze-test.exe']
keep = [W/'cli/link/hyle.exe',W/'case/link/host-image-lagged-consumer.exe',
    R/'.scratch/inference-host-image-20261026/cpu3/link/host-image-consumer.exe',
    R/'.scratch/inference-host-image-lag1-20261026/compile/unit.obj']
assert all(path.is_file() for path in keep)
records = []
for path in targets:
    path = path.resolve()
    assert path.is_file() and path.is_relative_to(scratch) and path not in keep
    with path.open('rb') as stream: sha = hashlib.file_digest(stream,'sha256').hexdigest()
    records.append(dict(path=str(path),bytes=path.stat().st_size,sha256=sha))
report = dict(root=str(scratch),targets=records,keep=[str(path) for path in keep],
    total_logical_bytes=sum(row['bytes'] for row in records))
(W/'cleanup-targets.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(files=len(records),bytes=report['total_logical_bytes'])))
