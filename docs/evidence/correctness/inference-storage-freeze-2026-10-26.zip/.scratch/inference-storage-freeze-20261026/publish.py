from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R/'docs/evidence/correctness'
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def pin(path):
    path = Path(path)
    with path.open('rb') as stream: sha = hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,sha256=sha)
sources = [R/path for path in ('include/hyle/compute/storage_owner.h',
    'include/hyle/compute/detail/lease_access.h','src/compute/resource_leases.cc',
    'engine/models/qwen35/weights.cc','tests/graph/constant_artifact_cache_test.cc')]
build = read(W/'ready.json')
test = read(W/'test/run1/process.json')
case = read(W/'case/run1/process.json')
result = read(W/'case/run1/summary.json')
xml = ET.parse(W/'test/run1/result.xml').getroot()
assert xml.attrib['tests'] == '8' and xml.attrib['failures'] == '0' and xml.attrib['disabled'] == '0'
assert test['exit'] == case['exit'] == 0 and not test['timeout'] and not case['timeout']
records = [W/path for path in ('build.py','run.py','publish.py','plan.json','ready.json','source-freeze.json',
    'prepare-cleanup.py','cleanup-targets.json','cleanup-result.json')]
for folder in ('compile/core','compile/weights','compile/test','cli/link','case/link','test/link','test/run1','case/run1'):
    records.extend(path for path in (W/folder).iterdir() if path.suffix in ('.json','.log','.xml'))
records.extend(W/path for path in ('cli/ready.json','case/ready.json','test/ready.json','case/runtime.json'))
archive = D/'inference-storage-freeze-2026-10-26.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(set(sources+records)):
        output.write(path,path.relative_to(R).as_posix())
report = dict(date='2026-10-26',status='BOUNDED_STORAGE_OWNER_AND_CUDA_CONSUMER_PASSED',
    baseline_commit='c5f1b0047',sources=[pin(path) for path in sources],archive=pin(archive),
    changes=['Public StorageOwner::freeze consumes the original full LeasePool/WriteLease only on success, zero payload copy.',
        'Preflight exact resource, original pool/writer, absent attached owners and actual metadata allocator behind budgets; allocate owner before original freeze.',
        'Original readonly domain retains real resource/Context and allocator through escaped readers, native uses and final metadata deallocation.',
        'Qwen weight loading calls the public method, removing its direct LeaseAccess dependency.'],
    build=dict(record=pin(W/'ready.json'),product_TUs=2,test_TUs=1,first_compile_and_link_attempts_passed=True,
        Model_native_report_SDK_recompiles=0,archive_rewrites=0,
        images={name:row['image'] for name,row in build['artifacts'].items()},
        scope='Replace exact core resource_leases and macro-consistent CUDA weights direct OBJ inputs; reuse current Model consumer and native provider closure. CLI linked only.'),
    tests=dict(process=pin(W/'test/run1/process.json'),xml=pin(W/'test/run1/result.xml'),passed=8,failed=0,skipped=0,
        new_contracts=['Zero payload allocation/copy; same handle/generation; final readonly alias retains actual resource.',
            'Custom ResourceBudget actual allocator survives resource and final domain metadata deallocation.',
            'Foreign resource, foreign allocator and pre-existing lifetime owner reject without consuming pool/writer or changing initialized bytes.']),
    consumer=dict(process=pin(W/'case/run1/process.json'),fixture=case['fixture_manifest'],result=result,
        scope='Current new weights/public freeze plus original CUDA Model executes ordinary and MTP sequential complete HostImage checks; original cached Qwen3.5-2B weights, no downloads.'),
    cleanup=dict(record=pin(W/'cleanup-result.json'),files=4,logical_bytes=563525632,
        scope='Superseded three CUDA images and completed GTest image removed. Current CLI/canonical case, all reusable objects, CPU image, native/model caches and logs retained.'),
    limitations=['New integration consumer is CUDA lag0; lag1 evidence is the preceding separate batch.',
        'No new complete task-quality, throughput, memory-peak, Apple/Vulkan or native pending/fault-injection claim.',
        'Existing typed Apple/Vulkan no-StorageOwner loading path retains original LeasePool::freeze behavior.',
        'Build artifact records depend on retained local cache; archive excludes binaries, SDKs and weights.'])
(D/'inference-storage-freeze-2026-10-26.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(evidence=pin(D/'inference-storage-freeze-2026-10-26.json'),archive=pin(archive))))
