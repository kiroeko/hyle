"""Bounded StorageOwner tests and one original CUDA HostImage consumer."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

W = Path(__file__).resolve().parent
R = W.parents[1]
mode = sys.argv[1]
assert mode in ('test','original')
if mode == 'original':
    assert json.loads((W/'test/run1/process.json').read_text())['exit'] == 0
folder = W/('test' if mode == 'test' else 'case')
ready_path = folder/'ready.json'
ready = json.loads(ready_path.read_text())
runtime = json.loads(Path(ready['runtime']['path']).read_text())
def pin(path):
    path = Path(path)
    with path.open('rb') as stream: sha = hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=sha)
for field in ('image','runtime'):
    assert pin(ready[field]['path']) == ready[field]
out = folder/'run1'
assert not out.exists(), 'Preserve each real attempt'
out.mkdir()
command = [ready['image']['path']]
fixture = None
if mode == 'test':
    command += ['--gtest_filter=StorageOwner.*','--gtest_output=xml:'+str(out/'result.xml')]
else:
    fixture = R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    command += ['--cuda',str(fixture)]
env = os.environ.copy()
env.update(runtime.get('configured_flags',{}))
env.update(PATH=str(folder/'link')+';'+runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
record = dict(command=command,cwd=str(R),ready=pin(ready_path),image=ready['image'],runtime=ready['runtime'],
    fixture_manifest=pin(fixture/'weights.tsv') if fixture else None,timeout_seconds=120)
(out/'command.json').write_text(json.dumps(record,indent=2)+'\n')
start = time.perf_counter()
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(command,cwd=R,env=env,stdout=stdout,stderr=stderr,
        creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'running.json').write_text(json.dumps(dict(pid=child.pid,command=command),indent=2)+'\n')
    print('STORAGE_FREEZE_NATIVE_PID',child.pid,mode,flush=True)
    timeout = False
    try: code = child.wait(timeout=120)
    except subprocess.TimeoutExpired:
        timeout = True; child.kill(); code = child.wait(timeout=10)
record.update(pid=child.pid,exit=code,timeout=timeout,seconds=time.perf_counter()-start,performance_claim=False)
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
assert code == 0 and not timeout, 'Preserve actual failure'
if mode == 'original':
    result = json.loads((out/'stdout.log').read_text(encoding='utf8'))
    assert result['status'] == 'PASS'
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
