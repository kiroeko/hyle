"""Three frozen TUs, exact two-OBJ replacements, no native executions.

Usage: plan, then build. Default does nothing. No archive/SDK/Model build.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
C = R/'.scratch/inference-causal-conv-20261026'
L = R/'.scratch/inference-host-image-lag1-20261026'
S = R/'.scratch/inference-cache-shared-source-20261025/attempt1/leases'
E = R/'.scratch/inference-current-closure-20261026/engine/weights'
T = R/'.scratch/lease-budget-deallocation-order-20261025/implementation/attempt1/owner-tests'
spec = importlib.util.spec_from_file_location('causal_helpers', C/'build.py')
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
b = c.b
JOBS = [('core', R/'src/compute/resource_leases.cc', S/'command.json'),
        ('weights', R/'engine/models/qwen35/weights.cc', E/'command.json'),
        ('test', R/'tests/graph/constant_artifact_cache_test.cc', T/'command.json')]


def compile_command(source, recipe, folder):
    old = b.read(recipe)['command']; result = []
    original_source = next(arg for arg in old if arg.lower().endswith('.cc'))
    for arg in old:
        if arg.startswith('/I') and str(R/'.scratch').casefold() in arg.casefold(): continue
        if arg == original_source: arg = str(source)
        elif arg == old[old.index('/sourceDependencies')+1]: arg = str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd'+str(folder/'unit.pdb')
        result.append(arg)
    if not any(arg.lower().startswith('/fd') for arg in result): result.append('/Fd'+str(folder/'unit.pdb'))
    for flag in ('/c', '/O2', '/Ob2', '/MD', '/W4', '/WX'): assert flag in result
    return result


def plan():
    assert not (W/'plan.json').exists(), 'Preserve each attempt'
    units = [dict(name=name, source=b.pin(source), recipe=b.pin(recipe),
        command=compile_command(source, recipe, W/'compile'/name)) for name, source, recipe in JOBS]
    frozen = c.closure([source for _, source, _ in JOBS], [recipe for _, _, recipe in JOBS])
    b.save(W/'source-freeze.json', frozen)
    baselines = {}
    for name, folder in [('cli', C/'cli'), ('case', L)]:
        ready = b.read(folder/'ready.json')
        for field in ('image', 'runtime', 'link_inputs'): b.exact(ready[field])
        inputs = b.read(ready['link_inputs']['path'])
        for row in inputs: b.exact(row)
        for old in (S/'unit.obj', E/'unit.obj'):
            assert sum(b.key(row['path']) == b.key(old) for row in inputs) == 1
        model = b.read(C/'plan.json')['baselines']['cli']['object'] if name == 'cli' else ready['object']
        b.exact(model)
        assert sum(b.key(row['path']) == b.key(model['path']) for row in inputs) == 1
        b.save(W/(name+'-inputs-before.json'), inputs)
        baselines[name] = dict(ready=b.pin(folder/'ready.json'), image=ready['image'], runtime=ready['runtime'],
            inputs=b.pin(W/(name+'-inputs-before.json')), link_recipe=b.pin(folder/'link/command.json'), object=model)
    cli_inputs = b.read(baselines['cli']['inputs']['path'])
    assert any('compute_backend_cpu--cpu_backend' in row['path'] for row in cli_inputs)
    gtest = [row for row in cli_inputs if Path(row['path']).name.lower() in ('gtest_main.lib', 'gtest.lib')]
    assert len(gtest) == 2
    b.save(W/'plan.json', dict(status='FROZEN_NOT_BUILT_OR_RUN', baseline_commit='c5f1b0047', units=units,
        source_freeze=b.pin(W/'source-freeze.json'), baselines=baselines,
        replacements=[dict(old=b.pin(S/'unit.obj'), unit='core'), dict(old=b.pin(E/'unit.obj'), unit='weights')],
        adaptation='Core/test keep original pure-CPU CXX flags; remove historical project /I shadow and compile canonical sources. Weights retain exact CUDA engine flags. Test includes no engine Backend variant. No CPU weights closure substitution.',
        test_dependencies=dict(gtest_libraries=gtest, CPU_backend='Existing direct CPU-backend/core objects already in the current CUDA CLI closure'),
        compiled_TUs=3, archive_rewrites=0, Model_native_report_SDK_builds=0))
    print('STORAGE_PLAN', json.dumps(b.pin(W/'plan.json')), flush=True)


def build():
    p = b.read(W/'plan.json')
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    b.exact(p['source_freeze']); frozen = b.read(p['source_freeze']['path'])
    for row in frozen: b.exact(row)
    for baseline in p['baselines'].values():
        for field in ('ready', 'image', 'runtime', 'inputs', 'link_recipe', 'object'): b.exact(baseline[field])
        for row in b.read(baseline['inputs']['path']): b.exact(row)
    h = b.helper(); compiler = p['units'][0]['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    objects, results = {}, []
    expected = {b.key(row['path']): row for row in frozen}
    for unit in p['units']:
        b.exact(unit['source']); b.exact(unit['recipe'])
        folder = W/'compile'/unit['name']; process = h.execute(unit['command'], env, folder, timeout=180)
        dep = b.read(folder/'dependencies.json')['Data']
        actual = [b.pin(path) for path in dict.fromkeys([dep['Source'], *dep['Includes']])]
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
                assert b.key(path) in expected and row['sha256'] == expected[b.key(path)]['sha256'], str(path)
        b.save(folder/'actual-dependencies.json', actual)
        objects[unit['name']] = b.pin(folder/'unit.obj')
        results.append(dict(name=unit['name'], source=unit['source'], object=objects[unit['name']],
            compile=process, actual_dependencies=b.pin(folder/'actual-dependencies.json')))
        for row in frozen: b.exact(row)
    artifacts = {}
    for name in ('cli', 'case', 'test'):
        baseline = p['baselines']['cli' if name == 'test' else name]
        inputs = b.read(baseline['inputs']['path']); removed = []
        if name == 'test':
            removed = [baseline['object'], next(row for row in inputs if b.key(row['path']).endswith('engine\\entry\\unit.obj'))]
        replacement = {b.key(row['old']['path']): objects[row['unit']] for row in p['replacements']}
        image = W/name/'link'/('hyle.exe' if name == 'cli' else 'host-image-lagged-consumer.exe' if name == 'case' else 'storage-freeze-test.exe')
        command, replaced, removed_count = [], 0, 0
        for arg in b.read(baseline['link_recipe']['path'])['command']:
            if any(b.key(arg) == b.key(row['path']) for row in removed): removed_count += 1; continue
            if b.key(arg) in replacement: arg = replacement[b.key(arg)]['path']; replaced += 1
            elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            elif arg.upper().startswith('/MAP:'): continue
            command.append(arg)
        assert replaced == 2 and removed_count == len(removed)
        if name == 'test': command.append(objects['test']['path'])
        linked = h.execute(command, env, image.parent, timeout=120)
        final = [replacement.get(b.key(row['path']), row) for row in inputs if row not in removed]
        if name == 'test': final.append(objects['test'])
        b.save(W/name/'link-inputs.json', final)
        runtime = b.read(baseline['runtime']['path']); b.exact(runtime['native'])
        alias = image.parent/Path(runtime['native']['path']).name
        os.link(runtime['native']['path'], alias); runtime['native_hardlink'] = b.pin(alias)
        b.save(W/name/'runtime.json', runtime)
        artifact = dict(status='LINKED_NOT_RUN', image=b.pin(image), runtime=b.pin(W/name/'runtime.json'),
            link_inputs=b.pin(W/name/'link-inputs.json'), baseline=baseline['image'], link=linked,
            Model_native_report_SDK_builds=0, archive_rewrites=0)
        b.save(W/name/'ready.json', artifact); artifacts[name] = artifact
    b.save(W/'ready.json', dict(status='BUILT_NOT_RUN', plan=b.pin(W/'plan.json'),
        source_freeze=p['source_freeze'], compiled=results, artifacts=artifacts, compiled_TUs=3,
        archive_rewrites=0, native_consumers=0))
    print('STORAGE_READY', json.dumps(b.pin(W/'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    else: print(__doc__)
