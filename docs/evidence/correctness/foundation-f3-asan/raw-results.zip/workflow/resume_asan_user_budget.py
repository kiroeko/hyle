from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import time

root = Path('/root/hyle-scratch/compute-unified/foundation-f3-asan-c36c40bed-native-cache')
record = json.loads((root / 'job.json').read_text())
assert all(row['state'] == 'terminal' for row in record['stages'])
assert record['stages'][-1]['name'] == 'build' and record['stages'][-1]['verdict'] == 'TIMEOUT'
assert 'user_budget_supplement' not in record
source = Path(record['source']); build = Path(record['build'])
assert record['candidate'] in (source / 'SOURCE-MANIFEST.txt').read_text()
available = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
assert available >= 4 * 1024**3
parallel = 4 if available >= 12 * 1024**3 else 2 if available >= 8 * 1024**3 else 1
record['user_budget_supplement'] = {
    'authorization': '2026-10-12 user accepted one additional 1800 seconds, retaining original TIMEOUT; subsequently approved memory-aware library parallel build instead of uniform build1.',
    'seconds': 1800, 'parallel': parallel, 'test_parallel': 1,
    'same_source_and_build': True, 'original_timeout_retained': True,
    'available_bytes': available}
record.pop('verdict', None)
(root / 'job.json').write_text(json.dumps(record, indent=2))
env = os.environ.copy(); env['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
env['ASAN_OPTIONS'] = 'halt_on_error=1:detect_leaks=1'
deadline = time.monotonic() + 1800
for name, command, limit in [
    ('build-user-budget-j4', ['/usr/bin/cmake', '--build', str(build), '--target', 'hyle_compute_stream_test', '--parallel', str(parallel)], 1680),
    ('files-user-budget-j4', [str(build / 'bin/hyle_compute_stream_test'), '--gtest_filter=FileStream.*', '--gtest_output=xml:' + str(root / 'files-user-budget-j4.xml')], 120),
]:
    assert not (root / (name + '.log')).exists()
    available = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
    assert available >= 4 * 1024**3
    remaining = min(limit, deadline - time.monotonic()); assert remaining > 0
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'available_bytes': available,
               'timeout_seconds': remaining, 'log': log.name}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait()
            row.update(state='terminal', verdict='TIMEOUT', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
            (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
    if name.startswith('build'):
        ninja = (build / 'build.ninja').read_text().splitlines()
        subjects = ['src/compute_stream/CMakeFiles/hyle_compute_stream.dir/file_stream.cc.o',
                    'src/compute_route_cpu/CMakeFiles/hyle_compute_route_cpu.dir/file_stream.cc.o',
                    'src/compute/CMakeFiles/hyle_compute.dir/batch_transfer.cc.o',
                    'tests/compute_stream/CMakeFiles/hyle_compute_stream_test.dir/file_stream_test.cc.o']
        flags = {}
        for subject in subjects:
            for index, line in enumerate(ninja):
                if line.startswith('build ' + subject + ':'):
                    flags[subject] = next(row.strip() for row in ninja[index + 1:index + 8] if row.strip().startswith('FLAGS ='))
                    break
        assert len(flags) == 4 and all('-fsanitize=address' in row for row in flags.values())
        (root / 'subject-compile-flags.json').write_text(json.dumps(flags, indent=2))
record['verdict'] = 'PASS_WSL_F3_ASAN_ONLY_WITH_ORIGINAL_TIMEOUT_RETAINED_AND_EXPLICIT_USER_BUDGET'
(root / 'job.json').write_text(json.dumps(record, indent=2))
