from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'; raw = scratch / 'wsl-sanitizer-logs'
folder = raw / 'asan'; job = json.loads((folder / 'job.json').read_text())
assert job['verdict'].startswith('PASS_WSL_F3_ASAN_ONLY')
assert job['user_budget_supplement']['completed_before_original_deadline'] is True
assert job['user_budget_supplement']['parallel'] == 4
assert job['diagnostic_policy_recovery']['budget_reset'] is False
for name in ['configure-diagnostic-policy', 'build-diagnostic-policy-j4', 'files-diagnostic-policy-j4']:
    stage = next(row for row in job['stages'] if row['name'] == name)
    assert stage['state'] == 'terminal' and stage['exit_code'] == 0
    assert hashlib.sha256((folder / stage['log']).read_bytes()).hexdigest() == stage['sha256']
assert any(row['verdict'] == 'TIMEOUT' and row['name'] == 'build' for row in job['stages'])
assert any(row['verdict'] == 'FAIL' and row['name'] == 'build-user-budget-j4' for row in job['stages'])
flags = json.loads((folder / 'subject-compile-flags.json').read_text())
assert len(flags) == 4 and all('-fsanitize=address' in row and '-O3' in row for row in flags.values())
tests = ET.parse(folder / 'files-diagnostic-policy-j4.xml').getroot()
assert tests.attrib['tests'] == '12' and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
log = (folder / 'files-diagnostic-policy-j4.log').read_text()
assert 'OriginalFileSizeLimitPreservesPositiveShortWritePrefixAndNoGroupReady' in log
assert 'ERROR: AddressSanitizer' not in log and 'LeakSanitizer' not in log
out = repo / 'evidence/correctness/foundation-f3-asan'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for path in sorted(raw.rglob('*')):
        if path.is_file(): packed.writestr(path.relative_to(raw).as_posix(), path.read_bytes())
    for name in ['run_wsl_gates.py', 'resume_asan_user_budget.py', 'resume_asan_diagnostic_policy.py', 'seal_asan_acceptance.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
inputs = []
for name in ['src/compute_stream/file_stream.cc', 'src/compute_stream/stream_sources.cc', 'src/compute_route_cpu/file_stream.cc',
             'src/compute/batch_transfer.cc', 'include/hyle/compute/detail/file_stream_copy.h', 'tests/compute_stream/file_stream_test.cc']:
    data = subprocess.check_output(['git', 'show', job['candidate'] + ':' + name])
    inputs.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest()})
receipt = {'schema_version': 1, 'product_commit': 'f3d931c47777f7fbfd35dedf1f5e0734fa28ef6c', 'fixture_commit': job['candidate'],
    'scope': 'WSL actual ASan F3 common/CPU controller and file risk acceptance only', 'identity': job['identity'],
    'tests_passed': 12, 'subject_compile_flags': flags, 'source_inputs': inputs,
    'positive_partial_write': 'Original POSIX process file-size limit: written=80, copied=96, ready=0, encoded prefix exactly preserved; original limits/signal restored before diagnostics.',
    'cross_thread': 'Real exported ReadLease/ReadyGroup drop from another thread, no early record reuse, actual final release/join frees finite record.',
    'allocator': 'Injected F3 metadata balanced and original active native uses zero after own-work retirement in the actual tests.',
    'initial_failures': ['Mutually exclusive factor/product selection configure FAIL.', 'Windows-mounted dependency cache configure TIMEOUT300.',
        'Original build1 TIMEOUT1800 in unchanged SIMD dependency; no tests run.', 'User-approved j4 resume strict Werror build FAILED on existing TCP GCC14 maybe-uninitialized sanitizer diagnostic.'],
    'diagnostic_policy': job['diagnostic_policy_recovery'], 'user_budget_supplement': job['user_budget_supplement'],
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_WSL_F3_ASAN_TWELVE_RISKS_WITH_ORIGINAL_FAILURES_AND_USER_BUDGET_RETAINED',
    'limits': 'Warnings remain visible; no TCP correctness verdict or driver-private physical memory zero claim. Full original F3 test risk scope and ASan remain enabled.',
    'unproven': ['UBSan/TSan', 'WSL native CUDA F3 delta', 'Installed static/shared/new headers/absence/relocation', 'Final P0/red team/closure']}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('ASan twelve actual tests, four exact instrumented subjects, positive short write and original failures verified.')
