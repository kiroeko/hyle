from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import time

root = Path('/root/hyle-scratch/compute-unified/foundation-f3-asan-c36c40bed-native-cache')
record = json.loads((root / 'job.json').read_text())
assert record['stages'][-1]['name'] == 'build-user-budget-j4' and record['stages'][-1]['exit_code'] == 1
assert 'user_budget_supplement' in record and 'diagnostic_policy_recovery' not in record
log = root / 'build-user-budget-j4.log'
assert '[-Werror=maybe-uninitialized]' in log.read_text() and '/src/io_core/tcp.cc' in log.read_text()
birth = int(subprocess.check_output(['stat', '-c', '%W', str(log)], text=True).strip()); assert birth > 0
deadline = birth + 1800
remaining = deadline - time.time(); assert remaining > 120
record['diagnostic_policy_recovery'] = {
    'reference': 'https://gcc.gnu.org/onlinedocs/gcc-14.1.0/gcc/Instrumentation-Options.html',
    'basis': 'GCC recommends against combining sanitizers and Werror due to increased false positive maybe-uninitialized diagnostics. Normal HYLE local default WERROR=OFF; retain warnings and original strict failure.',
    'change': 'Existing public HYLE_WERROR option OFF for this instrumented validation tree; no -Wno-* suppression, source or runtime sanitizer change.',
    'scope': 'No verdict about TCP correctness; complete original F3 FileStream risk set remains required.',
    'original_supplement_start_epoch': birth, 'original_supplement_deadline_epoch': deadline,
    'remaining_seconds_at_resume': remaining, 'budget_reset': False}
(root / 'job.json').write_text(json.dumps(record, indent=2))
source = Path(record['source']); build = Path(record['build']); parallel = record['user_budget_supplement']['parallel']
env = os.environ.copy(); env['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'; env['ASAN_OPTIONS'] = 'halt_on_error=1:detect_leaks=1'
for name, command, cap in [
    ('configure-diagnostic-policy', ['/usr/bin/cmake', '-S', str(source), '-B', str(build), '-DHYLE_WERROR=OFF'], 300),
    ('build-diagnostic-policy-j4', ['/usr/bin/cmake', '--build', str(build), '--target', 'hyle_compute_stream_test', '--parallel', str(parallel)], 1680),
    ('files-diagnostic-policy-j4', [str(build / 'bin/hyle_compute_stream_test'), '--gtest_filter=FileStream.*', '--gtest_output=xml:' + str(root / 'files-diagnostic-policy-j4.xml')], 120),
]:
    free = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024; assert free >= 4 * 1024**3
    seconds = min(cap, deadline - time.time() - (120 if not name.startswith('files') else 0)); assert seconds > 0
    output = root / (name + '.log'); assert not output.exists()
    with output.open('w') as stream:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'available_bytes': free, 'log': output.name,
               'timeout_seconds': seconds, 'budget_deadline_epoch': deadline}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait(); row.update(state='terminal', verdict='TIMEOUT')
            (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(output.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
    if name.startswith('build'):
        ninja = (build / 'build.ninja').read_text().splitlines()
        subjects = ['src/compute_stream/CMakeFiles/hyle_compute_stream.dir/file_stream.cc.o',
                    'src/compute_route_cpu/CMakeFiles/hyle_compute_route_cpu.dir/file_stream.cc.o',
                    'src/compute/CMakeFiles/hyle_compute.dir/batch_transfer.cc.o',
                    'tests/compute_stream/CMakeFiles/hyle_compute_stream_test.dir/file_stream_test.cc.o']
        flags = {}
        for subject in subjects:
            for index, line in enumerate(ninja):
                if line.startswith('build ' + subject + ':'):
                    flags[subject] = next(row.strip() for row in ninja[index + 1:index + 8] if row.strip().startswith('FLAGS ='))
                    break
        assert len(flags) == 4 and all('-fsanitize=address' in row for row in flags.values())
        (root / 'subject-compile-flags.json').write_text(json.dumps(flags, indent=2))
record['verdict'] = 'PASS_WSL_F3_ASAN_ONLY_WITH_WARNINGS_RETAINED_AND_ORIGINAL_FAILURES_USER_BUDGET_RETAINED'
record['user_budget_supplement']['completed_before_original_deadline'] = time.time() <= deadline
(root / 'job.json').write_text(json.dumps(record, indent=2))
