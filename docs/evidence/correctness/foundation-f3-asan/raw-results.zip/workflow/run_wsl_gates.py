from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

mode, candidate = sys.argv[1:3]
attempt = sys.argv[3] if len(sys.argv) > 3 else ''
assert mode in ['cuda', 'math', 'asan', 'ubsan', 'tsan'] and len(candidate) == 40
initial_available = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
assert initial_available >= 4 * 1024**3
parallel = 4 if initial_available >= 12 * 1024**3 else 2 if initial_available >= 8 * 1024**3 else 1
base = Path('/root/hyle-scratch/compute-unified')
root = base / ('foundation-f3-' + mode + '-' + candidate[:9] + ('-' + attempt if attempt else '')); assert not root.exists(); root.mkdir()
env = os.environ.copy()
env['PATH'] = '/usr/local/cuda-13.3/bin:/usr/lib/wsl/lib:/usr/bin:/bin:/usr/sbin:/sbin'
env.update(CUDA_HOME='/usr/local/cuda-13.3', CUDA_PATH='/usr/local/cuda-13.3', CUDAToolkit_ROOT='/usr/local/cuda-13.3',
           CUDACXX='/usr/local/cuda-13.3/bin/nvcc',
           ASAN_OPTIONS='halt_on_error=1:detect_leaks=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1', TSAN_OPTIONS='halt_on_error=1')
identity = {key: subprocess.check_output(command, text=True, env=env).strip() for key, command in [
    ('os', ['uname', '-a']), ('compiler', ['/usr/bin/g++-14', '--version']), ('cmake', ['/usr/bin/cmake', '--version']),
    ('cuda', ['/usr/local/cuda-13.3/bin/nvcc', '--version']),
    ('gpu', ['/usr/lib/wsl/lib/nvidia-smi', '--query-gpu=name,uuid,driver_version', '--format=csv,noheader'])]}
if mode == 'cuda':
    source = Path('/home/kiro/hyle-f1/native-fault/source-3034fc595abf'); build = source.parent / 'build-3034fc595abf'
    target = 'hyle_compute_route_cuda_file_stream_test'
    commands = [('configure', ['/usr/bin/cmake', '-S', str(source), '-B', str(build), '-DHYLE_COMPONENTS=compute', '-DHYLE_COMPUTE_ROUTES=cuda', '-DHYLE_BUILD_TESTS=ON', '-DHYLE_INSTALL=OFF'], 300),
                ('build', ['/usr/bin/cmake', '--build', str(build), '--target', target, '--parallel', str(parallel)], 1800),
                ('files', [str(build / 'bin' / target), '--gtest_filter=CudaFileStream.*', '--gtest_output=xml:' + str(root / 'files.xml')], 120)]
elif mode == 'math':
    source = base / 'source-7a7b4c3b'; parent = base / 'l-cpu-cuda/selected-graph/source-parent'; build = parent.parent / 'source-build'
    file = parent / 'CMakeLists.txt'; text = file.read_text(); original = text
    for target, name in [('hyle_f3_file_streaming', 'main.cc'), ('hyle_f3_qwen_file_streaming', 'qwen_main.cc')]:
        if target not in text:
            text += '\nadd_executable(' + target + ' "' + str(source / 'samples/package/graph/file_streaming' / name) + '")\n'
            text += 'target_link_libraries(' + target + ' PRIVATE hyle::graph)\nhyle_stage_runtime(' + target + ')\n'
    if text != original: file.write_text(text)
    commands = [('configure', ['/usr/bin/cmake', '-S', str(parent), '-B', str(build)], 300),
                ('build', ['/usr/bin/cmake', '--build', str(build), '--target', 'hyle_f3_file_streaming', 'hyle_f3_qwen_file_streaming', '--parallel', str(parallel)], 1800),
                ('math', [str(build / 'hyle_f3_file_streaming'), str(base / 'foundation-f3-gguf-input/gguf-ranges.tsv')], 180),
                ('qwen', [str(build / 'hyle_f3_qwen_file_streaming'), str(base / 'foundation-f3-qwen-input/ranges.tsv')], 180)]
else:
    source = Path('/home/kiro/hyle-f1/sanitizers/source-03242e7723cb'); build = source.parent / (mode + '-03242e7723cb')
    commands = [('configure', ['/usr/bin/cmake', '-S', str(source), '-B', str(build), '-DHYLE_DEV_FACTORS=compute_route_cpu;compute_stream', '-UHYLE_COMPUTE_ROUTES',
                '-DHYLE_DEP_SOURCE_CACHE=/root/.cache/hyle/dependencies/v1',
                '-DHYLE_BUILD_TESTS=ON', '-DHYLE_INSTALL=OFF', '-DHYLE_WERROR=OFF', '-DHYLE_SANITIZER=' + mode], 300),
                ('build', ['/usr/bin/cmake', '--build', str(build), '--target', 'hyle_compute_stream_test', '--parallel', str(parallel)], 1800),
                ('files', [str(build / 'bin/hyle_compute_stream_test'), '--gtest_filter=FileStream.*', '--gtest_output=xml:' + str(root / 'files.xml')], 120)]
assert candidate in (source / 'SOURCE-MANIFEST.txt').read_text()
record = {'candidate': candidate, 'source': str(source), 'build': str(build), 'mode': mode,
          'scope': 'F3 selected WSL ' + mode + ' qualification only; no unrelated correctness/catalogue/P1 gates',
          'identity': identity, 'parallel': parallel, 'test_parallel': 1, 'stages': []}
for name, command, timeout in commands:
    available = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
    assert available >= 4 * 1024**3, available
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'available_bytes': available, 'log': log.name}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(process.pid, signal.SIGKILL); process.wait(); row.update(state='terminal', verdict='TIMEOUT')
            (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
    if name == 'build' and mode in ['asan', 'ubsan', 'tsan']:
        flag = '-fsanitize=' + {'asan': 'address', 'ubsan': 'undefined', 'tsan': 'thread'}[mode]
        ninja = (build / 'build.ninja').read_text().splitlines()
        subjects = ['src/compute_stream/CMakeFiles/hyle_compute_stream.dir/file_stream.cc.o',
                    'src/compute_route_cpu/CMakeFiles/hyle_compute_route_cpu.dir/file_stream.cc.o',
                    'src/compute/CMakeFiles/hyle_compute.dir/batch_transfer.cc.o',
                    'tests/compute_stream/CMakeFiles/hyle_compute_stream_test.dir/file_stream_test.cc.o']
        observed = {}
        for subject in subjects:
            for index, line in enumerate(ninja):
                if line.startswith('build ' + subject + ':'):
                    observed[subject] = next(value.strip() for value in ninja[index + 1:index + 8] if value.strip().startswith('FLAGS ='))
                    break
        assert len(observed) == len(subjects) and all(flag in value for value in observed.values())
        (root / 'subject-compile-flags.json').write_text(json.dumps(observed, indent=2))
        matching = [line for line in ninja if flag in line]
        assert matching; (root / 'sanitizer-flags.log').write_text('\n'.join(matching) + '\n')
        record['sanitizer_flags_sha256'] = hashlib.sha256((root / 'sanitizer-flags.log').read_bytes()).hexdigest()
        (root / 'job.json').write_text(json.dumps(record, indent=2))
record['verdict'] = 'PASS_WSL_F3_' + mode.upper() + '_ONLY'
(root / 'job.json').write_text(json.dumps(record, indent=2)); print(str(root), flush=True)
