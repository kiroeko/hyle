"""Definition-based finite NVFP4 codec math; no native/backend execution."""
from fractions import Fraction
from pathlib import Path
import json
import math
import struct

S=Path(__file__).resolve().parent
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def f16(x):return struct.unpack('<e',struct.pack('<e',x))[0]
def bits(x):return struct.pack('<f',x).hex()
def full_scale(code):
    if code in (0,127):return Fraction(0)
    exponent,mantissa=divmod(code,8)
    return Fraction(mantissa,512) if exponent==0 else Fraction(8+mantissa,8)*Fraction(2)**(exponent-7)

double_codes=(0,1,2,3,4,6,8,12,0,-1,-2,-3,-4,-6,-8,-12)
failures=[];half_failures=[];negative_zeros=[];nonzero=[]
for scale in range(128):
    for code,integer in enumerate(double_codes):
        exact=Fraction(integer,2)*full_scale(scale)
        # The sign of a zero multiplication follows the native integer LUT:
        # code8 is integer zero; negative nonzero codes times scale0 are -0.
        want=math.copysign(float(exact),-1 if exact==0 and integer<0 else 1) if exact==0 else float(exact)
        decoded=f32(float(integer)*float(full_scale(scale)/2))
        if bits(decoded)!=bits(want):failures.append([scale,code,bits(decoded),bits(want)])
        if bits(f16(decoded))!=bits(decoded):half_failures.append([scale,code,decoded])
        if decoded!=0:nonzero.append(abs(decoded))
        elif math.copysign(1,decoded)<0:negative_zeros.append([scale,code])

activation=f32(1+2**-12)
weight=f32(1.0) # full scale0x38 (1) times actual E2M1 code2 (1)
result=dict(kind='pure_cpu_definition_math_only',scale_domain='0..127; bit7 clear',
    examined_pairs=128*16,definition_mismatches=failures,F16_decode_mismatches=half_failures,
    all_decoded_weights_exactly_F16=not half_failures,
    minimum_nonzero_weight=min(nonzero),maximum_absolute_weight=max(nonzero),
    negative_zero_pairs=negative_zeros,code8_weight_with_scale0x38_bits=bits(f32(0.0)),
    activation_narrowing_witness=dict(scale_byte=0x38,nibble=2,weight=weight,
        A=activation,A_bits=bits(activation),float_output=f32(activation*weight),
        float_output_bits=bits(f32(activation*weight)),half_A=f16(activation),
        half_A_output=f32(f16(activation)*weight),difference=activation-f16(activation)),
    no_product_changes=True,no_build=True,no_GPU=True)
assert not failures and not half_failures and len(negative_zeros)==14
(S/'codec-probe.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
