"""Keep this batch's reproducible text evidence, excluding rebuilt binaries."""
from pathlib import Path
import hashlib
import json
import zipfile

stage = Path(__file__).resolve().parent
root = stage.parents[2]
destination = root / "docs/evidence/correctness/apple-gguf-nvfp4-2026-10-20.zip"
if destination.exists():
    raise RuntimeError("Preserve the existing archive; do not silently replace evidence")
suffixes = {".json", ".py", ".diff", ".log", ".cc", ".cpp", ".m", ".h",
            ".metal", ".md", ".cmake", ".txt", ".ps1"}
paths = [p for p in stage.rglob("*")
         if p.is_file() and not p.is_symlink()
         and (p.suffix in suffixes or p.name in {"LICENSE", "COPYING"})
         and "__pycache__" not in p.parts]
manifest = []
destination.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(destination, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(paths):
        data = path.read_bytes()
        relative = path.relative_to(stage).as_posix()
        archive.writestr(relative, data)
        manifest.append({"path": relative, "bytes": len(data),
                         "sha256": hashlib.sha256(data).hexdigest()})
    archive.writestr("payload-manifest.json", json.dumps(manifest, indent=2) + "\n")
# Validate the stored compressed payload once, including its actual hashes.
with zipfile.ZipFile(destination) as archive:
    bad = archive.testzip()
    if bad:
        raise RuntimeError(f"Archive CRC failure: {bad}")
    for item in manifest:
        data = archive.read(item["path"])
        if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise RuntimeError(f"Archive identity failure: {item['path']}")
result = {"path": destination.relative_to(root).as_posix(),
          "bytes": destination.stat().st_size,
          "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
          "payload_files": len(manifest), "CRC_and_payload_hashes_verified": True,
          "SDK_or_binary_payloads": False}
(stage / "archive-receipt.json").write_text(
    json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result))
