"""Reuse the frozen F32/Q8 shared-activation consumer with current owners."""
import hashlib,json,pathlib,subprocess,time
S=pathlib.Path(__file__).resolve().parent;P=json.loads((S/'incremental-plan.json').read_text());O=S/'legacy-control';O.mkdir(exist_ok=True)
def ident(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def run(tag,argv):
 t=time.time()
 with (O/(tag+'.stdout.log')).open('w') as so,(O/(tag+'.stderr.log')).open('w') as se:
  p=subprocess.Popen(argv,stdout=so,stderr=se,cwd=S);r=dict(argv=argv,pid=p.pid,started=t,exit=p.wait(),elapsed=time.time()-t)
 save(tag+'.command.json',r);print(tag,r['exit'],flush=True);return r
old=json.loads((pathlib.Path(P['previous'])/'checks-output-span/link.command.json').read_text())['argv']
oldtest=next(x for x in old if x.endswith('.o') and ('test.o' in x or 'test-' in x))
cmd=json.loads((S/'checks-shader-fix/link.command.json').read_text())['argv']
image=O/'shared-activation-control'
for i,x in enumerate(cmd):
 if x.endswith('/nvfp4-test.o'):cmd[i]=oldtest
 elif x.startswith('-Wl,-map,'):cmd[i]='-Wl,-map,'+str(image)+'.map'
cmd[cmd.index('-o')+1]=str(image)
r=run('link',cmd)
if r['exit']:raise SystemExit(r['exit'])
lib=O/'mlx.metallib'
if not lib.exists():lib.symlink_to(S/'checks-shader-fix/mlx.metallib')
r=run('tests',[str(image)])
save('summary.json',dict(passed=r['exit']==0,exit=r['exit'],image=ident(image),reused_test_object=ident(oldtest),math='existing bounded dyadic F32 and Q8 shared/repeated-ID regressions, not general old F32 half-operand precision equivalence',sdk_rebuilt=False))
raise SystemExit(r['exit'])
