import hashlib,json,pathlib
S=pathlib.Path(__file__).resolve().parent;R=S.parents[2];V=S/'validation'
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,x):(S/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
freeze=json.loads((S/'native-source-freeze.json').read_text());checks=[]
for row in freeze['native_files']:
 p=V/'native-checks-shader-fix'/row['path'];actual=ident(p)
 assert actual['sha256']==row['after_sha256'],row['path']
 checks.append(dict(path=row['path'],actual_materialized_source=actual,matched=True))
for row in freeze['product']:
 assert ident(R/row['path'])['sha256']==row['after']['sha256'],row['path']
final=json.loads((V/'checks-final-fixture/summary.json').read_text());assert final['passed'] and final['domains']==13
control=json.loads((V/'legacy-control/summary.json').read_text());assert control['passed']
log=(V/'checks-final-fixture/tests.stdout.log').read_text()
assert log.count('PASS Direct ')==6 and log.count('PASS Graph ')==6 and log.count('PASS common Graph:')==1
tree=[];folder=R/'third_party/ggml_runtime'
for p in sorted(folder.rglob('*'),key=lambda p:p.relative_to(folder).as_posix()):
 if p.is_file():
  b=p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
  tree.append(p.relative_to(folder).as_posix()+'|'+hashlib.sha256(b).hexdigest()+'\n')
save('lock-proposal.json',dict(entry='ggml_runtime_patches',origin_unchanged=True,vendor_tree_sha256=hashlib.sha256(''.join(tree).encode()).hexdigest(),files=[ident(folder/'metal-patches.json'),ident(folder/'NOTICE.md')],central_lock_modified_by_this_agent=False))
save('source-identity-check.json',dict(passed=True,source_freeze=ident(S/'native-source-freeze.json'),actual_native_checks=checks,public_consumer=final['consumer_source'],no_shared_byvalue_layout_changed=True))
failures=[
 ('checks','compile closure','Missing mixed CPU IQ1 header layer; device.cpp existing IQ1 enum undeclared','Use actual prepare_mixed_cpu_manifest -> Metal -> Metal IQ1 composition; no mathematical change'),
 ('checks-mixed','link closure','147 old native-Graph-only owner closure lacks common Apple ExecutionSource module','Compile seven existing graph_route_apple owners, original module configuration'),
 ('checks-final','link closure','Common Apple ExecutionSource introduces actual graph_batch dependency absent from old closure','Compile all six existing graph_batch target owners as a module; no implementation changes'),
 ('checks-closure','first Metal JIT','NV-only constant-if branch still type-checked under legacy BF16 specialization; implicit F32->bfloat assignment rejected','Explicit (S1) cast: identity for NV float, old legacy branch remains false; only MM embed refreshed'),
 ('checks-shader-fix preparation attempt','runner metadata','Inherited native-objects receipt missing in fully-reused intermediate output','Persist inherited native receipt and resume actual checks-final owners; no compile or GPU occurred in this failed attempt'),
 ('checks-shader-fix','common Graph fixture','Twelve native domains passed; common Graph owned bindings lacked ResourceOptions','Test author specified existing factory.resources; only consumer TU/image refreshed, no math/implementation/tolerance change')]
save('failure-ledger.json',dict(failures=[dict(stage=s,kind=k,exit=1,reason=r,resolution=x) for s,k,r,x in failures],failed_not_reported_as_passed=True))
save('summary.json',dict(passed=True,scope='Apple original GGUF NVFP4 packed MatMul/GroupedMatMul/checked GetRows primitive wiring',
 hardware=dict(model='Mac16,12',gpu='Apple M4',details=str(V/'inventory.json')),native_domains=12,common_graph_journeys=1,legacy_control_domains=16,
 final=final,legacy_control=control,native_source_freeze=ident(S/'native-source-freeze.json'),native_application=ident(S/'native-application.json'),source_check=ident(S/'source-identity-check.json'),
 validation_directory=str(V),test_logs=str(V/'checks-final-fixture/tests.stdout.log'),test_command=str(V/'checks-final-fixture/tests.command.json'),
 module_closure=dict(baseline_host_objects=147,final_host_objects=160,fresh_unique_hyle_host_owners=14,new_original_graph_module_owners=13,consumer_tu=1,native_unique_owners=6,native_changed_source_files=9,shared_sdk_rebuilt=False),
 numerical=dict(codec='all legal128scale bytes x16nibbles; exact selected-row bits including signed zero',matrix='independent F64 forward bound plus exact source F32 onehot 1+2^-20 witness',source_activation_precision='F32, no half narrowing in new NV MM/MMID',weight_expansion='original tile only; no full-bank expansion'),
 limitations=['No selected real-model artifact payload or whole-model inference executed; artifact_execution_verified remains false','MacBook Air Apple M4 only; Metal4/M5 SIMD specialization source-qualified but not hardware-executed','No throughput, profiling or full-platform claim','Old F32/Q8 controls are bounded dyadic regressions, not proof of general old half-operand MM equivalence','Cold resource/OOM handling source-reviewed; no exhaustive allocation fault injection'],
 failures=str(S/'failure-ledger.json'),cleanup_inventory=str(V/'generated-artifacts.json'),mac_gpu_released=True))
print(json.dumps(dict(summary=ident(S/'summary.json'),source_check=ident(S/'source-identity-check.json'),lock_proposal=json.loads((S/'lock-proposal.json').read_text())),indent=2))
