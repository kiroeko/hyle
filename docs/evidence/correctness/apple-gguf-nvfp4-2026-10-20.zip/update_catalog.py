"""Update only the verified GGUF artifact's coverage; retain whole-model limits."""
import json
from pathlib import Path

stage = Path(__file__).resolve().parent
root = stage.parents[2]
path = root / "docs/implementation/model-quantizations.json"
text = path.read_text(encoding="utf-8")
repository = "cdiamond/Qwen3.8-27B-iMatrix-NVFP4-MTP-GGUF"
start = text.index('"repository": "' + repository + '"')
start = text.index('"provider_coverage":', start)
start = text.index("{", start)
coverage, length = json.JSONDecoder().raw_decode(text[start:])
assert coverage["artifact_execution_verified"] is False
coverage["review_scope"] = "All866 main GGUF tensor headers and protected roles verified; independent synthetic public operators run on Windows CPU/CUDA/Vulkan and Apple Air. Apple also exercises ordinary common Graph. No selected27B payload/importer/full-model execution."
coverage["mapping_status"] = "Distinct GGUF NVFP4 block64/36 mapped through existing CPU/CUDA/Vulkan/Apple MatMul, GroupedMatMul and selected-row paths; Apple retains F32 activation/accumulation/output and original packed bytes."
coverage["reachable_entry_points"].append({
    "provider": "ggml Metal",
    "descriptor": "Existing gguf_weight_description/gguf_grouped_weight_description(kNvfp4,...) and ordinary MatMul/GroupedMatMul/Gather",
    "exact_requirements": "Original block64/36, complete K blocks, F32 activation/output, actual prepared strides/span and checked IDs; native pipeline thread/SIMD/shared-memory qualification remains device-specific.",
    "execution": "Original packed MV/MM/MVID/MMID and selected-row decode, no whole-bank floating expansion; verified on Air Mac16,12 only, not all Apple devices."
})
coverage["artifact_unaligned_or_unverified"].remove(
    "Metal NVFP4 kernel is absent; mapping alone is not implementation.")
coverage["missing_capabilities"].remove("Metal GGUF NVFP4 compute/selected-row kernels")
regression = coverage["operator_regression"]
regression.pop("apple_direct_graph_prepare_rejection")
regression.update(
    apple_direct=True, apple_native_graph=True, apple_ordinary_common_graph=True,
    apple_report="docs/evidence/correctness/apple-gguf-nvfp4-2026-10-20.json")
coverage["code"].append("third_party/ggml_runtime/metal-patches.json")
lines = json.dumps(coverage, ensure_ascii=False, indent=2).splitlines()
replacement = lines[0] + chr(10) + chr(10).join("      " + line for line in lines[1:])
updated = text[:start] + replacement + text[start + length:]
catalog = json.loads(updated)
artifact = next(a for a in catalog["artifacts"] if a["repository"] == repository)
assert artifact["provider_coverage"]["artifact_execution_verified"] is False
path.write_text(updated, encoding="utf-8", newline=chr(10))
print("Updated GGUF Apple operators; whole artifact execution remains unverified")
