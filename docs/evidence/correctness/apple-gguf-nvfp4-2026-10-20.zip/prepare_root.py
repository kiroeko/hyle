"""Snapshot only the current task's root-owned documents and dependency lock."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


receipt = S / 'root-before.json'
assert not receipt.exists(), 'Preserve the original baseline'
rows = []
for rel in ['cmake/HyleDependencyLock.json', 'docs/user/compute.md',
            'docs/user/apple-compute.md', 'docs/implementation/model-operators.md',
            'docs/implementation/model-quantizations.json', 'docs/developer/current-work.md']:
    path = ROOT / rel
    snapshot = S / 'root-before' / rel
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    rows.append(dict(source=str(path), snapshot=str(snapshot), identity=identity(path)))
receipt.write_text(json.dumps(dict(files=rows, scope='Apple GGUF NVFP4 native packed implementation'),
    indent=2) + '\n', encoding='utf-8')
(S / 'goal-turn.json').write_text(json.dumps(dict(status='active',
    previous_goal_turn='progress',
    reason='Completed shared-activation fixes across four backends, actual focused regressions and one full CUDA model check; archived evidence and reclaimed1.11GiB.',
    next_work='Implement actual Apple GGUF NVFP4 packed projection/expert/selected-row paths, preserving source precision and actual native resource limits.'),
    indent=2) + '\n', encoding='utf-8')
print('APPLE_NVFP4_ROOT_BASELINE', len(rows), 'files')
