import argparse,difflib,hashlib,importlib.util,json,pathlib,shutil
S=pathlib.Path(__file__).resolve().parent;ROOT=S.parents[2]
PIN=pathlib.Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
P=argparse.ArgumentParser();P.add_argument('--apply',action='store_true');A=P.parse_args()
def sha(d):return hashlib.sha256(d).hexdigest()
def ident(p):
 d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=sha(d))
def load(p):return json.loads(p.read_text(encoding='utf8'))
def norm(p):return p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n').decode()
def apply(text,edits):
 for e in edits:
  assert text.count(e['before'])==1,e['before'][:100]
  text=text.replace(e['before'],e['after'],1)
 return text
def unique_edits(before,after):
 a=before.splitlines(True);b=after.splitlines(True);sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
 edits=[];current=before
 # Each grouped change includes sufficient unchanged context and is applied
 # against the preceding result, avoiding whole-file replacement records.
 for group in sm.get_grouped_opcodes(3):
  i,j=group[0][1],group[-1][2];k,l=group[0][3],group[-1][4]
  old=''.join(a[i:j]);new=''.join(b[k:l]);extra=3
  while current.count(old)!=1:
   extra+=3;i=max(0,group[0][1]-extra);j=min(len(a),group[-1][2]+extra)
   k=max(0,group[0][3]-extra);l=min(len(b),group[-1][4]+extra)
   old=''.join(a[i:j]);new=''.join(b[k:l])
   assert extra<len(a)+3
  edits.append(dict(before=old,after=new));current=current.replace(old,new,1)
 assert current==after
 return edits
paths=['third_party/ggml_runtime/patches.json','third_party/ggml_runtime/metal-patches.json','third_party/ggml_metal_iq1/patches.json']
for rel in paths+['third_party/ggml_runtime/NOTICE.md','third_party/ggml_cpu_runtime/patches.json']:
 p=S/'package-before'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():shutil.copyfile(ROOT/rel,p)
manifest=load(S/'package-before'/paths[1]);rows={r['path']:r for r in manifest['files']}
delta=load(S/'native-draft-freeze.json')['files']
for row in delta:
 rel=row['path'];after=norm(S/'native-source'/rel)
 if row['before_sha256'] is None:
  assert not (PIN/rel).exists() and rel not in rows
  manifest['files'].append(dict(path=rel,before_sha256=None,after_sha256=sha(after.encode()),content=after));continue
 before=norm(S/'native-before'/rel);assert sha(before.encode())==row['before_sha256']
 edits=unique_edits(before,after)
 if rel not in rows:
  pin=norm(PIN/rel)
  r=dict(path=rel,before_sha256=sha(pin.encode()),after_sha256=None,edits=[]);manifest['files'].append(r);rows[rel]=r
 r=rows[rel];r['edits']+=edits;r['after_sha256']=sha(apply(norm(PIN/rel),r['edits']).encode())
dest=S/'package-source'/paths[1];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8',newline='\n')
notice=norm(S/'package-before/third_party/ggml_runtime/NOTICE.md')
notice+='''
GGUF NVFP4 keeps its original 64-value/36-byte encoding and four UE4M3 scale
groups. A private decoder is included only by the existing mul_mv, mul_mm and
quantize Metal kinds. Existing MV/MVID, tiled SIMD MM/MMID and selected-row
carriers read packed blocks directly; the NV matrix specialization retains F32
activation, dequantized tile, accumulation and output, including on Metal 4.
Its 12 KiB shared tile and actual pipeline thread limits are checked during
the original NativeProgram cold preparation. Existing non-NV numerical
specializations and compact duplicate-ID mapping are retained. No whole-bank
F32 expansion, new executor or installed C API is introduced.
'''
p=S/'package-source/third_party/ggml_runtime/NOTICE.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(notice,encoding='utf8',newline='\n')
# Exercise the actual composer, including its locked new-file content path.
spec=importlib.util.spec_from_file_location('composer',ROOT/'src/compute_ggml_runtime/prepare_metal_iq1_manifest.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
combined=S/'combined-manifest.json'
mixed_spec=importlib.util.spec_from_file_location('mixed',ROOT/'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py');mixed=importlib.util.module_from_spec(mixed_spec);mixed_spec.loader.exec_module(mixed)
mixed_path=S/'mixed-cpu-manifest.json'
mixed.derive(PIN,S/'package-before'/paths[0],S/'package-before/third_party/ggml_cpu_runtime/patches.json',mixed_path)
mod.compose(PIN,[mixed_path,S/'package-source'/paths[1],S/'package-before'/paths[2]],combined)
for row in load(combined)['files']:
 result=row['content'] if 'content' in row else apply(norm(PIN/row['path']),row['edits'])
 assert sha(result.encode())==row['after_sha256']
 candidate=S/'native-source'/row['path']
 if candidate.exists():assert norm(candidate)==result,row['path']
product=['third_party/ggml_runtime/metal-patches.json','third_party/ggml_runtime/NOTICE.md','src/compute_provider_ggml_metal/native_program.cc']
sources=[S/'package-source'/product[0],S/'package-source'/product[1],S/'source'/product[2]]
if A.apply:
 for rel,source in zip(product,sources):
  old=S/('before' if rel.startswith('src/') else 'package-before')/rel
  previous=load(S/'native-application.json') if (S/'native-application.json').exists() else None
  allowed=next((x['sha256'] for x in previous['files'] if pathlib.Path(x['path']).resolve()==(ROOT/rel).resolve()),None) if previous else None
  assert (ROOT/rel).read_bytes()==old.read_bytes() or ident(ROOT/rel)['sha256']==allowed,rel
  shutil.copyfile(source,ROOT/rel)
freeze=dict(status='applied' if A.apply else 'ready not applied',native_files=delta,product=[dict(path=rel,before=ident(S/('before' if rel.startswith('src/') else 'package-before')/rel),after=ident(p)) for rel,p in zip(product,sources)],combined_manifest=ident(combined),shared_abi_changed=False)
(S/'native-source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n',encoding='utf8')
if A.apply:(S/'native-application.json').write_text(json.dumps(dict(applied=True,files=[ident(ROOT/r) for r in product],freeze=ident(S/'native-source-freeze.json')),indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(applied=A.apply,freeze=ident(S/'native-source-freeze.json'),native_changed=len(delta)),indent=2))
