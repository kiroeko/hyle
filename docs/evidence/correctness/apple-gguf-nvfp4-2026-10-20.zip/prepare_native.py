"""Generate the narrowly scoped NVFP4 native draft from the frozen full replay."""
import difflib, hashlib, json, pathlib, re
STAGE=pathlib.Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
BEFORE=STAGE/'native-before'; OUT=STAGE/'native-source'
def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def read(p): return (BEFORE/p).read_text(encoding='utf8')
def write(p,s):
 p=OUT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a[:100],s.count(a),n)
 return s.replace(a,b)
base='src/ggml-metal/'
header='''#pragma once

// Original GGUF NVFP4: 64 values, four UE4M3 scales, 32 nibble bytes.
// Construct exact F32 values using integer bits. This also preserves signed
// zero under Metal fast math: code 8 is +0, negative nonzero codes use -0
// when their scale is zero. Do not substitute an HF/MLX FP4 scale codec.
inline float hyle_nvfp4_value(uchar scale, uchar code) {
    constexpr ushort magnitudes[8] = {0, 1, 2, 3, 4, 6, 8, 12};
    const uint sign = code > 8 ? 0x80000000u : 0u;
    const uint magnitude = magnitudes[code & 7];
    if (scale == 0 || scale == 0x7f || magnitude == 0) {
        return as_type<float>(sign);
    }
    const int exponent = (scale >> 3) & 15;
    const uint product = magnitude * (exponent == 0 ? scale & 7 : 8 + (scale & 7));
    if (product == 0) return as_type<float>(sign);
    const int top = 31 - clz(product);
    const int power = exponent == 0 ? -10 : exponent - 11;
    return as_type<float>(sign | (uint(power + top + 127) << 23) |
                          ((product << (23 - top)) & 0x7fffffu));
}

template<typename T4x4>
inline void dequantize_nvfp4(device const block_nvfp4 * block, short il,
                             thread T4x4 & values) {
    const uchar scale = block->d[il];
    for (short i = 0; i < 16; ++i) {
        const uchar q = block->qs[8*il + (i & 7)];
        values[i/4][i%4] = hyle_nvfp4_value(scale, (q >> (i >= 8 ? 4 : 0)) & 15);
    }
}

inline void dequantize_nvfp4_t4(device const block_nvfp4 * block, short il,
                                thread float4 & values) {
    const short group = il / 4;
    const short chunk = il % 4;
    for (short i = 0; i < 4; ++i) {
        const uchar q = block->qs[8*group + 4*(chunk & 1) + i];
        values[i] = hyle_nvfp4_value(block->d[group], (q >> (chunk >= 2 ? 4 : 0)) & 15);
    }
}
'''
write(base+'kernels/dequantize_nvfp4.h',header)

# Reuse the existing float4 dot/reduction carrier, parameterizing only its
# actual argument type and activation vector alignment. Existing callers stay
# on float4, NVFP4 uses packed_float4 for legal four-byte row/token pitches.
mv=read(base+'kernels/mul_mv.metal')
mv=replace(mv,'#include "dequantize.h"','#include "dequantize.h"\n#include "dequantize_nvfp4.h"')
begin=mv.index('// mat-vec kernel processing in chunks of float4\n')
end=mv.index('// mat-vec kernel processing in chunks of float4x4',begin)
part=mv[begin:end]
part=replace(part,'thread float4 &) >','thread float4 &), typename args_t, typename y4_t >')
part=replace(part,'constant ggml_metal_kargs_mul_mv_ext & args','args_t args')
part=part.replace('device const float4 *','device const y4_t *')
part=replace(part,'dot(lx[ch], y4[ir1][ch*nxpsg])','dot(lx[ch], float4(y4[ir1][ch*nxpsg]))')
mv=mv[:begin]+part+mv[end:]
mv=replace(mv,'kernel_mul_mv_ext_q4_f32_impl<r1ptg, q_t, epb/4, deq_t4>','kernel_mul_mv_ext_q4_f32_impl<r1ptg, q_t, epb/4, deq_t4, constant ggml_metal_kargs_mul_mv_ext &, float4>')
nv_mv='''
template<short nr0, typename args_t>
void kernel_mul_mv_nvfp4_f32_impl(
        args_t args, device const char * src0, device const char * src1,
        device char * dst, threadgroup char * shmem,
        uint3 tgpig, ushort tiisg, ushort sgitg) {
    (void) shmem;
    kernel_mul_mv_ext_q4_f32_impl<1, block_nvfp4, 16, dequantize_nvfp4_t4,
        args_t, packed_float4>(args, src0, src1, dst, tgpig, tiisg, sgitg);
}

kernel void kernel_mul_mv_nvfp4_f32(
        constant ggml_metal_kargs_mul_mv & args,
        device const char * src0, device const char * src1, device char * dst,
        threadgroup char * shmem [[threadgroup(0)]],
        uint3 tgpig [[threadgroup_position_in_grid]],
        ushort tiisg [[thread_index_in_simdgroup]],
        ushort sgitg [[simdgroup_index_in_threadgroup]]) {
    kernel_mul_mv_nvfp4_f32_impl<8, constant ggml_metal_kargs_mul_mv &>(
        args, src0, src1, dst, shmem, tgpig, tiisg, sgitg);
}
'''
pos=mv.index('// mat-vec kernel processing in chunks of float4x4')
mv=mv[:pos]+nv_mv+'\n'+mv[pos:]
# The original indexed dispatcher supplies exact expert/token/slot offsets.
line=next(x for x in mv.splitlines() if 'host_name("kernel_mul_mv_id_q8_0_f32")' in x)
nvline=re.sub(r'kernel_mul_mv_id_q8_0_f32','kernel_mul_mv_id_nvfp4_f32',line)
nvline=nvline.replace('kernel_mul_mv_q8_0_f32_impl<N_R0_Q8_0>', 'kernel_mul_mv_nvfp4_f32_impl<8>')
mv=replace(mv,line,line+'\n'+nvline)
write(base+'kernels/mul_mv.metal',mv)

mm=read(base+'kernels/mul_mm.metal')
mm=replace(mm,'#include "dequantize.h"','#include "dequantize.h"\n#include "dequantize_nvfp4.h"')
template_args='S0, S0_4x4, S0_8x8, S1, S1_2x4, S1_8x8, block_q, nl, dequantize_func, T0, T0_4x4, T1, T1_2x4'
nv_args='float, float4x4, simdgroup_float8x8, float, float2x4, simdgroup_float8x8, block_nvfp4, 4, dequantize_nvfp4, float, float4x4, float, float2x4'
def parse_function(text,name,start=0):
 p=text.index('kernel void '+name+'(',start);t=text.rfind('template<',start,p)
 o=text.index('{',p);depth=1;i=o+1
 while depth:
  depth += (text[i]=='{')-(text[i]=='}');i+=1
 return t,o,i,text[t:o],text[o+1:i-1]
def selected(body,tensor):
 result=[];stack=[];active=True
 for line in body.splitlines(keepends=True):
  st=line.strip()
  if st in ('#ifdef GGML_METAL_HAS_TENSOR','#ifndef GGML_METAL_HAS_TENSOR'):
   stack.append((active,tensor if st.startswith('#ifdef') else not tensor));active=active and stack[-1][1]
  elif st=='#else' and stack:
   outer,cond=stack[-1];stack[-1]=(outer,not cond);active=outer and not cond
  elif st=='#endif' and stack:
   active=stack.pop()[0]
  elif active:result.append(line)
 assert not stack
 return ''.join(result)
def safe_simd_body(body):
 # Both existing half layouts still yield 4096; NV float A occupies 8192.
 body=replace(body,'shmem + 4096','shmem + sizeof(S0)*64*32')
 # NV source F32 must not narrow or assume the matrix/vector alignment of
 # float2x4: eight scalar loads fill the exact same shared tile cells.
 line='*(threadgroup S1_2x4 *)(sb + 64*ib + 8*ly) = (S1_2x4)(*((device T1_2x4 *) y));'
 rep='''if (is_same<block_q, block_nvfp4>::value) {
                for (short i = 0; i < 8; ++i) sb[64*ib + 8*ly + i] = (S1)y[i];
            } else {
                '''+line+'''
            }'''
 body=replace(body,line,rep)
 # Partial N rows may start on four-byte rather than float4 alignment.
 body=body.replace('device float4 * D4 = (device float4 *) D;',
                   'device packed_float4 * D4 = (device packed_float4 *) D;')
 # This is just an exact four-scalar store; it changes no arithmetic for any
 # old instantiation and removes an unnecessary alignment precondition.
 return body
else_pos=mm.index('\n#else\n')
t,o,end,sig,body=parse_function(mm,'kernel_mul_mm',else_pos)
body=safe_simd_body(body)
helper=re.sub(r'\[\[.*?\]\]', '', sig.replace('kernel void kernel_mul_mm(', 'void hyle_mul_mm_simdgroup_impl('))+'{'+body+'}\n'
wrapper=sig+'{\n    hyle_mul_mm_simdgroup_impl<'+template_args+'>(args, src0, src1, dst, shmem, tgpig, tiitg, sgitg);\n}'
mm=mm[:t]+wrapper+mm[end:]
pos=mm.index('#ifdef GGML_METAL_HAS_TENSOR')
mm=mm[:pos]+helper+'\n'+mm[pos:]
# Independent entry selects this same SIMD core even on Metal4 devices. Old
# tensor-enabled entries retain their original implementation and precision.
nv_wrapper=sig.replace('kernel void kernel_mul_mm(', 'kernel void hyle_kernel_mul_mm_simdgroup(')+'{\n    hyle_mul_mm_simdgroup_impl<'+template_args+'>(args, src0, src1, dst, shmem, tgpig, tiitg, sgitg);\n}\n'
pos=mm.index('template<short ne20>')
mm=mm[:pos]+nv_wrapper+'\n'+mm[pos:]
t,o,end,sig,body=parse_function(mm,'kernel_mul_mm_id')
simd=safe_simd_body(selected(body,False));tensor=selected(body,True)
helper=re.sub(r'\[\[.*?\]\]', '', sig.replace('kernel void kernel_mul_mm_id(', 'void hyle_mul_mm_id_simdgroup_impl('))+'{'+simd+'}\n'
wrapper=sig+'{\n#ifdef GGML_METAL_HAS_TENSOR\n'+tensor+'\n#else\n    hyle_mul_mm_id_simdgroup_impl<'+template_args+'>(args, src0, src1, htpe, hids, dst, shmem, tgpig, tiitg, tiisg, sgitg);\n#endif\n}'
nv_wrapper=sig.replace('kernel void kernel_mul_mm_id(', 'kernel void hyle_kernel_mul_mm_id_simdgroup(')+'{\n    hyle_mul_mm_id_simdgroup_impl<'+template_args+'>(args, src0, src1, htpe, hids, dst, shmem, tgpig, tiitg, tiisg, sgitg);\n}\n'
mm=mm[:t]+helper+'\n'+wrapper+'\n'+nv_wrapper+mm[end:]
mm+='\ntemplate [[host_name("kernel_mul_mm_nvfp4_f32")]] kernel mul_mm_t hyle_kernel_mul_mm_simdgroup<'+nv_args+'>;\n'
# mul_mm_id_t is the original kernel signature typedef.
id_type=re.search(r'typedef decltype\(kernel_mul_mm_id<.*?\) (\w+);',mm).group(1)
mm+='template [[host_name("kernel_mul_mm_id_nvfp4_f32")]] kernel '+id_type+' hyle_kernel_mul_mm_id_simdgroup<'+nv_args+'>;\n'
write(base+'kernels/mul_mm.metal',mm)

q=read(base+'kernels/quantize.metal')
q=replace(q,'#include "dequantize.h"','#include "dequantize.h"\n#include "dequantize_nvfp4.h"')
line=next(x for x in q.splitlines() if 'host_name("kernel_get_rows_mxfp4")' in x)
q=replace(q,line,line+'\ntemplate [[host_name("kernel_get_rows_nvfp4")]] kernel get_rows_q_t kernel_get_rows_q<block_nvfp4, 4, dequantize_nvfp4>;')
write(base+'kernels/quantize.metal',q)

dev=read(base+'ggml-metal-device.cpp')
dev=replace(dev,'const bool has_tensor = ggml_metal_device_get_props(ggml_metal_library_get_device(lib))->has_tensor;',
 '''// NVFP4 preserves F32 operands in the shared SIMD tile on every device.
    const bool has_tensor = tsrc0 != GGML_TYPE_NVFP4 &&
        ggml_metal_device_get_props(ggml_metal_library_get_device(lib))->has_tensor;''')
dev=replace(dev,'res.smem = bc_out ? 8192 : (4096 + 2048);','res.smem = tsrc0 == GGML_TYPE_NVFP4 ? 12288 : (bc_out ? 8192 : (4096 + 2048));')
dev=replace(dev,'res.smem = 8192;','res.smem = tsrc0 == GGML_TYPE_NVFP4 ? 12288 : 8192;')
# The two ordinary/indexed MV tuning switches have identical Q8 entries.
anchor='''        case GGML_TYPE_Q8_0:
            {
                nsg = N_SG_Q8_0;'''
dev=replace(dev,anchor,'''        case GGML_TYPE_NVFP4:
            {
                nsg = 4;
                nr0 = 8;
            } break;
'''+anchor,2)
# All other formats retain their previous (unused) nxpsg function constant.
dev=replace(dev,'ggml_metal_cv_set_int16(cv, nsg,            FC_MUL_MV + 0);\n        ggml_metal_cv_set_int16(cv, (int16_t) ne12,',
 '''ggml_metal_cv_set_int16(cv, nsg,            FC_MUL_MV + 0);
        if (tsrc0 == GGML_TYPE_NVFP4) ggml_metal_cv_set_int16(cv, 4, FC_MUL_MV + 1);
        ggml_metal_cv_set_int16(cv, (int16_t) ne12,''')
dev=replace(dev,'ggml_metal_cv_set_int16(cv, nsg, FC_MUL_MV + 0);\n        ggml_metal_cv_set_int16(cv, 1,',
 '''ggml_metal_cv_set_int16(cv, nsg, FC_MUL_MV + 0);
        if (tsrc0 == GGML_TYPE_NVFP4) ggml_metal_cv_set_int16(cv, 4, FC_MUL_MV + 1);
        ggml_metal_cv_set_int16(cv, 1,''')
write(base+'ggml-metal-device.cpp',dev)

device_h=read(base+'ggml-metal-device.h')
anchor='int ggml_metal_pipeline_max_theads_per_threadgroup(struct ggml_metal_pipeline_with_params pipeline);'
device_h=replace(device_h,anchor,anchor+'''
bool ggml_metal_pipeline_supports_launch(struct ggml_metal_pipeline_with_params pipeline,
        size_t threads, size_t shared_limit, bool require_simd32);''')
write(base+'ggml-metal-device.h',device_h)
dev=read(base+'ggml-metal-device.m')
anchor='''int ggml_metal_pipeline_max_theads_per_threadgroup(struct ggml_metal_pipeline_with_params pipeline) {
    return pipeline.pipeline->obj.maxTotalThreadsPerThreadgroup;
}'''
dev=replace(dev,anchor,anchor+'''

bool ggml_metal_pipeline_supports_launch(struct ggml_metal_pipeline_with_params pipeline,
        size_t threads, size_t shared_limit, bool require_simd32) {
    if (!pipeline.pipeline || !pipeline.pipeline->obj || threads == 0) return false;
    id<MTLComputePipelineState> pso = pipeline.pipeline->obj;
    return threads <= pso.maxTotalThreadsPerThreadgroup &&
        (!require_simd32 || pso.threadExecutionWidth == 32) &&
        pso.staticThreadgroupMemoryLength <= shared_limit &&
        pipeline.smem <= shared_limit - pso.staticThreadgroupMemoryLength;
}''')
dev=replace(dev,'bool has_simdgroup_reduction,\n        const struct ggml_tensor * op,','ggml_metal_device_t dev,\n        const struct ggml_tensor * op,')
dev=replace(dev,'''    if (!has_simdgroup_reduction ||
        op->src[0]->type == GGML_TYPE_NVFP4 ||''','''    if (!dev->props.has_simdgroup_reduction ||''')
anchor='''    if (op->src[1]->type != GGML_TYPE_F16) {'''
guard='''    if (op->src[0]->type == GGML_TYPE_NVFP4) {
        const struct ggml_tensor * w = op->src[0];
        const struct ggml_tensor * a = op->src[1];
        if (a->type != GGML_TYPE_F32 || op->type != GGML_TYPE_F32 ||
            w->ne[0] <= 0 || w->ne[0] % ggml_blck_size(GGML_TYPE_NVFP4) != 0 ||
            w->nb[0] != ggml_type_size(GGML_TYPE_NVFP4) || a->nb[0] != sizeof(float) ||
            !ggml_is_contiguous(op) ||
            dev->mtl_device.maxThreadsPerThreadgroup.width < 128 ||
            (mm_path && (!dev->props.has_simdgroup_mm ||
                        dev->props.max_theadgroup_memory_size < 12288))) return false;
        for (int d = 0; d < GGML_MAX_DIMS; ++d) {
            if (w->ne[d] <= 0 || a->ne[d] <= 0 || op->ne[d] <= 0 ||
                w->ne[d] > INT32_MAX || a->ne[d] > INT32_MAX ||
                op->ne[d] > INT32_MAX || a->nb[d] % sizeof(float)) return false;
        }
        // Existing ordinary MV/MM function constants are signed sixteen-bit.
        if (op->op == GGML_OP_MUL_MAT &&
            (a->ne[2] > INT16_MAX || a->ne[3] > INT16_MAX ||
             a->ne[2]/w->ne[2] > INT16_MAX || a->ne[3]/w->ne[3] > INT16_MAX)) return false;
        return true;
    }

'''
dev=replace(dev,anchor,guard+anchor)
dev=replace(dev,'ggml_metal_supports_mul_mat_op(\n                    has_simdgroup_reduction,','ggml_metal_supports_mul_mat_op(\n                    dev,',2)
dev=replace(dev,'''            return op->src[0]->type != GGML_TYPE_NVFP4 &&
                   op->src[0]->type != GGML_TYPE_TQ1_0;''','''            if (op->src[0]->type == GGML_TYPE_NVFP4) {
                return op->src[1]->type == GGML_TYPE_I32 && op->type == GGML_TYPE_F32 &&
                    op->src[0]->ne[0] > 0 && op->src[0]->ne[0] % ggml_blck_size(GGML_TYPE_NVFP4) == 0 &&
                    op->src[0]->nb[0] == ggml_type_size(GGML_TYPE_NVFP4);
            }
            return op->src[0]->type != GGML_TYPE_TQ1_0;''')
write(base+'ggml-metal-device.m',dev)

cm=read(base+'CMakeLists.txt')
cm=replace(cm,'set(METALLIB_KERNEL_SOURCES','set(METALLIB_KERNELS_NVFP4 "${CMAKE_CURRENT_SOURCE_DIR}/kernels/dequantize_nvfp4.h")\n\nset(METALLIB_KERNEL_SOURCES')
anchor='''        if(_has_quantize)
            list(APPEND HEADERS_FOR_SRC ${METALLIB_KERNELS_QUANTIZE})
        endif()'''
cm=replace(cm,anchor,anchor+'''
        file(STRINGS ${SRC} _has_nvfp4 REGEX "#include \\"dequantize_nvfp4\\\\.h\\"")
        set(NVFP4_DEPENDENCY "")
        if(_has_nvfp4)
            list(APPEND HEADERS_FOR_SRC ${METALLIB_KERNELS_NVFP4})
            set(NVFP4_DEPENDENCY ${METALLIB_KERNELS_NVFP4})
        endif()''')
cm=replace(cm,'-e "/\\#pragma once/d"','-e "/\\#include \\"dequantize_nvfp4.h\\"/d" -e "/\\#pragma once/d"')
cm=replace(cm,'kernels/${kind}.metal\n            COMMENT','kernels/${kind}.metal ${NVFP4_DEPENDENCY}\n            COMMENT')
anchor='''    configure_file(kernels/dequantize.h ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/kernels/dequantize.h COPYONLY)'''
cm=replace(cm,anchor,anchor+'\n    configure_file(kernels/dequantize_nvfp4.h ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}/kernels/dequantize_nvfp4.h COPYONLY)')
cm=replace(cm,'        list(APPEND AIR_FILES ${AIR})\n        add_custom_command(','''        list(APPEND AIR_FILES ${AIR})
        set(NVFP4_DEPENDENCY "")
        if(name STREQUAL "mul_mv" OR name STREQUAL "mul_mm" OR name STREQUAL "quantize")
            set(NVFP4_DEPENDENCY ${METALLIB_KERNELS_NVFP4})
        endif()
        add_custom_command(''')
cm=replace(cm,'DEPENDS ${src} kernels/common.h kernels/dequantize.h kernels/quantize.h ${METALLIB_COMMON} ggml-metal-impl.h','DEPENDS ${src} kernels/common.h kernels/dequantize.h kernels/quantize.h ${METALLIB_COMMON} ggml-metal-impl.h ${NVFP4_DEPENDENCY}')
cm=replace(cm,'DEPENDS kernels/mul_mm.metal kernels/common.h kernels/dequantize.h ${METALLIB_COMMON} ggml-metal-impl.h','DEPENDS kernels/mul_mm.metal kernels/common.h kernels/dequantize.h ${METALLIB_COMMON} ggml-metal-impl.h ${METALLIB_KERNELS_NVFP4}')
write(base+'CMakeLists.txt',cm)

# Actual pipeline preparation remains within the original per-program library.
cpp=read(base+'ggml-metal.cpp')
cpp=replace(cpp,'#include "ggml-metal-ops.h"','#include "ggml-metal-ops.h"\n#include "ggml-metal-common.h"')
cpp=replace(cpp,'#include <mutex>','#include <algorithm>\n#include <mutex>\n#include <new>')
pos=cpp.index('// backend registry')
cpp=cpp[:pos]+'''// Cold specialization of the exact packed NVFP4 operation, no payload access.
static bool ggml_hyle_metal_prepare_packed_op(ggml_backend_t backend, const ggml_tensor * op, bool * unsupported) {
    if (op->op != GGML_OP_MUL_MAT && op->op != GGML_OP_MUL_MAT_ID &&
        op->op != GGML_OP_GET_ROWS) return true;
    if (!op->src[0] || op->src[0]->type != GGML_TYPE_NVFP4) return true;
    auto dev = (ggml_metal_device_t) backend->device->context;
    auto lib = ggml_metal_device_get_library(dev);
    if (!lib) return false;
    if (!ggml_metal_device_supports_op(dev, op)) { *unsupported = true; return false; }
    const auto * props = ggml_metal_device_get_props(dev);
    ggml_metal_pipeline_with_params p{};
    size_t threads = 0;
    if (op->op == GGML_OP_GET_ROWS) {
        p = ggml_metal_library_get_pipeline_get_rows(lib, GGML_TYPE_NVFP4);
        if (p.allocation_failed) throw std::bad_alloc();
        if (!p.pipeline) return false;
        threads = std::min<int64_t>(op->src[0]->ne[0]/16,
                                  ggml_metal_pipeline_max_theads_per_threadgroup(p));
    } else if (op->op == GGML_OP_MUL_MAT) {
        if (ggml_metal_op_mul_mat_use_mm(op, props->has_simdgroup_mm)) {
            p = ggml_metal_library_get_pipeline_mul_mm(lib, op);
        } else {
            p = ggml_metal_library_get_pipeline_mul_mv(lib, op);
        }
        threads = 32*p.nsg;
    } else if (op->op == GGML_OP_MUL_MAT_ID) {
        if (ggml_metal_op_mul_mat_id_use_mm(op, props->has_simdgroup_mm)) {
            auto map = ggml_metal_library_get_pipeline_mul_mm_id_map0(lib, op->src[0]->ne[2], op->src[2]->ne[0]);
            if (map.allocation_failed) throw std::bad_alloc();
            if (!map.pipeline) return false;
            if (!ggml_metal_pipeline_supports_launch(map, op->src[0]->ne[2],
                    props->max_theadgroup_memory_size, false)) { *unsupported = true; return false; }
            p = ggml_metal_library_get_pipeline_mul_mm_id(lib, op);
            threads = 128;
        } else {
            p = ggml_metal_library_get_pipeline_mul_mv_id(lib, op);
            threads = 32*p.nsg;
        }
    } else return false;
    if (p.allocation_failed) throw std::bad_alloc();
    if (!p.pipeline) return false;
    *unsupported = !ggml_metal_pipeline_supports_launch(p, threads,
        props->max_theadgroup_memory_size, op->op != GGML_OP_GET_ROWS);
    return !*unsupported;
}

extern "C" bool ggml_hyle_metal_prepare_graph(ggml_backend_t backend, ggml_cgraph * graph, bool * unsupported) {
    *unsupported = false;
    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {
        if (!ggml_hyle_metal_prepare_packed_op(backend, ggml_graph_node(graph, i), unsupported)) return false;
    }
    return true;
}

'''+cpp[pos:]
write(base+'ggml-metal.cpp',cpp)

product='src/compute_provider_ggml_metal/native_program.cc'
old=(ROOT/product).read_text(encoding='utf8')
dest=STAGE/'before'/product;dest.parent.mkdir(parents=True,exist_ok=True)
if not dest.exists():dest.write_text(old,encoding='utf8',newline='\n')
old=dest.read_text(encoding='utf8')
line=next(x for x in old.splitlines() if 'bool ggml_hyle_metal_prepare_gdn' in x)
new=replace(old,line,line+'\nbool ggml_hyle_metal_prepare_graph(ggml_backend_t, ggml_cgraph *, bool *);')
anchor='    return std::unique_ptr<NativeProgram>(new NativeProgram(std::move(state)));'
new=replace(new,anchor,"""    bool unsupported_pipeline = false;
    if (!ggml_hyle_metal_prepare_graph(state->backend, state->graph, &unsupported_pipeline))
      return std::unexpected(unsupported_pipeline
          ? Status::Unimplemented("ggml Metal packed pipeline device resources unsupported")
          : Status::Unavailable("ggml Metal packed pipeline preparation failed"));
"""+anchor)
dest=STAGE/'source'/product;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(new,encoding='utf8',newline='\n')

changed=[];diff=[]
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OUT).as_posix();after=p.read_text(encoding='utf8');bp=BEFORE/rel
 before=bp.read_text(encoding='utf8') if bp.exists() else ''
 if after==before:continue
 changed.append(dict(path=rel,before_sha256=sha(before) if bp.exists() else None,after_sha256=sha(after),bytes=len(after.encode())))
 diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
(STAGE/'native-changes.diff').write_text(''.join(diff),encoding='utf8',newline='\n')
(STAGE/'native-draft-freeze.json').write_text(json.dumps(dict(files=changed,status='draft not applied or compiled'),indent=2)+'\n',encoding='utf8')
print(json.dumps(changed,indent=2))
