"""Freeze the actual bounded run and publish its sources, without another build."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

stage = Path(__file__).resolve().parent
root = stage.parents[2]


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def ident(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + chr(10),
                    encoding="utf-8", newline=chr(10))


summary = load(stage / "summary.json")
final = summary["final"]
actual_command = load(stage / "validation/checks-final-fixture/tests.command.json")
actual_log = (stage / "validation/checks-final-fixture/tests.stdout.log").read_text()
assert summary["passed"] and final["passed"] and final["exit"] == actual_command["exit"] == 0
assert summary["native_domains"] == 12 and final["domains"] == 13
assert "PASS 12 native Direct/Graph domains and one ordinary shared Graph journey" in actual_log
assert actual_command["argv"] == [final["image"]["path"]]
assert summary["legacy_control"]["passed"] and summary["legacy_control"]["exit"] == 0
assert "PASS 16 public grouped shared-activation domains" in (
    stage / "validation/legacy-control/tests.stdout.log").read_text()
assert ident(root / "tests/compute_route_apple/gguf_nvfp4_test.cc")["sha256"] == final["consumer_source"]["sha256"]
assert ident(stage / "native-source-freeze.json")["sha256"] == final["native_source_freeze"]["sha256"]
assert ident(stage / "tests-source-freeze.json")["sha256"] == final["tests_source_freeze"]["sha256"]
freeze = load(stage / "native-source-freeze.json")
for item in freeze["product"]:
    assert ident(root / item["path"])["sha256"] == item["after"]["sha256"]

root_files = [item["source"] for item in load(stage / "root-before.json")["files"]]
root_files += [str(root / item["path"]) for item in freeze["product"]]
root_files += [str(root / "tests/compute_route_apple/gguf_nvfp4_test.cc"),
               str(root / "tests/compute_route_apple/CMakeLists.txt")]
sources = []
for source in dict.fromkeys(root_files):
    path = Path(source)
    relative = path.relative_to(root)
    snapshot = stage / "root-source" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, snapshot)
    sources.append(dict(path=relative.as_posix(), bytes=path.stat().st_size,
                        sha256=ident(path)["sha256"]))
save(stage / "root-final-check.json", dict(
    passed=True, sources=sources,
    dependency_audit=dict(command=["cmake", "-P", "cmake/HyleDependencyVersions.cmake"],
                          exit=0, origin="Actual final exec result; not rerun for logging"),
    scoped_diff_check=dict(exit=0, origin="Actual scoped git diff --check result"),
    deleted_obsolete_test=load(stage / "old-rejection-removal.json"),
    tooling=load(stage / "root-tooling-check.json")))
save(stage / "goal-turn.json", dict(
    status="active", previous_goal_turn="no_progress",
    previous_reason="The preceding user-status reply inspected current state without changing product state.",
    current_goal_turn="progress",
    current_reason="Implemented original Apple GGUF NVFP4 packed paths and cold resources, fixed real shader/build issues, verified13 native/common Graph domains plus16 legacy controls, updated bounded coverage and removed obsolete rejection source.",
    next_work="Implement exact CT packed linear through the original provider's private Graph region; preserve scale-dtype rounding, conversion history and source ownership. Broad architecture/coverage/performance goal remains active."))
report = dict(
    passed=True, recorded_utc=datetime.now(timezone.utc).isoformat(),
    scope="This Apple original GGUF NVFP4 batch only; not completion of the architecture goal.",
    changes=[
        "Original block64/36 packed MV/MM/MVID/MMID and checked selected-row decoding; no whole-bank floating expansion.",
        "Preserved F32 activation, typed12KiB F32 matrix tiles, F32 accumulation/output and actual source pitches.",
        "Backend-local cold PSO selection checks actual threads, SIMD width and static+dynamic shared memory; preserves OOM/resource failure classification.",
        "Private decoder dependencies cover embedded, ordinary AIR and tensor AIR builds; no public operation, ABI or common executor added.",
        "Exact patch materialization can create a new private header with pinned content and absent-source checks.",
        "Positive test replaces the obsolete prepare-rejection test; support documents and the artifact coverage table retain full-model limitations."],
    hardware=summary["hardware"], results=dict(
        native_domains=12, ordinary_common_graph_journeys=1, legacy_F32_Q8_control_domains=16,
        actual_exit=0, command=actual_command, final_image=final["image"],
        consumer_source=final["consumer_source"], native_freeze=final["native_source_freeze"],
        tests_freeze=final["tests_source_freeze"]),
    numerical=summary["numerical"], module_closure=summary["module_closure"],
    failure_history=load(stage / "failure-ledger.json")["failures"],
    limitations=summary["limitations"],
    root_checks="root-final-check.json in the evidence archive",
    source_identity_check="source-identity-check.json in the evidence archive",
    full_goal_status="active",
    next_gap_research="docs/evidence/research/ct-packed-graph-seam-2026-10-20.json")
save(stage / "public-report-base.json", report)
print(json.dumps(dict(passed=True, frozen_root_files=len(sources),
                      domains=13, legacy_control_domains=16)))
