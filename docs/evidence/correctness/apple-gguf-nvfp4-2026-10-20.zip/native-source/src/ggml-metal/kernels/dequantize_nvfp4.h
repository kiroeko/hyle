#pragma once

// Original GGUF NVFP4: 64 values, four UE4M3 scales, 32 nibble bytes.
// Construct exact F32 values using integer bits. This also preserves signed
// zero under Metal fast math: code 8 is +0, negative nonzero codes use -0
// when their scale is zero. Do not substitute an HF/MLX FP4 scale codec.
inline float hyle_nvfp4_value(uchar scale, uchar code) {
    constexpr ushort magnitudes[8] = {0, 1, 2, 3, 4, 6, 8, 12};
    const uint sign = code > 8 ? 0x80000000u : 0u;
    const uint magnitude = magnitudes[code & 7];
    if (scale == 0 || scale == 0x7f || magnitude == 0) {
        return as_type<float>(sign);
    }
    const int exponent = (scale >> 3) & 15;
    const uint product = magnitude * (exponent == 0 ? scale & 7 : 8 + (scale & 7));
    if (product == 0) return as_type<float>(sign);
    const int top = 31 - clz(product);
    const int power = exponent == 0 ? -10 : exponent - 11;
    return as_type<float>(sign | (uint(power + top + 127) << 23) |
                          ((product << (23 - top)) & 0x7fffffu));
}

template<typename T4x4>
inline void dequantize_nvfp4(device const block_nvfp4 * block, short il,
                             thread T4x4 & values) {
    const uchar scale = block->d[il];
    for (short i = 0; i < 16; ++i) {
        const uchar q = block->qs[8*il + (i & 7)];
        values[i/4][i%4] = hyle_nvfp4_value(scale, (q >> (i >= 8 ? 4 : 0)) & 15);
    }
}

inline void dequantize_nvfp4_t4(device const block_nvfp4 * block, short il,
                                thread float4 & values) {
    const short group = il / 4;
    const short chunk = il % 4;
    for (short i = 0; i < 4; ++i) {
        const uchar q = block->qs[8*group + 4*(chunk & 1) + i];
        values[i] = hyle_nvfp4_value(block->d[group], (q >> (chunk >= 2 ? 4 : 0)) & 15);
    }
}
