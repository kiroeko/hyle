$ErrorActionPreference = 'Stop'
$repoRoot = [IO.Path]::GetFullPath($PSScriptRoot)
if ($repoRoot -ne 'C:\public\project-hyle\hyle') { throw 'Run only the root test.ps1 copy.' }
$stageRoot = Join-Path $repoRoot '.scratch\architecture-refactor-2026-10-18\apple-nvfp4'
$receipt = Get-Content -LiteralPath (Join-Path $stageRoot 'archive-receipt.json') -Raw | ConvertFrom-Json
$archive = Join-Path $repoRoot $receipt.path
if (-not $receipt.CRC_and_payload_hashes_verified -or
    (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.sha256) {
    throw 'Final evidence archive has not been verified.'
}
$planPath = Join-Path $stageRoot 'cleanup-plan-final.json'
$plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
foreach ($item in $plan.windows.candidates) {
    $resolved = [IO.Path]::GetFullPath($item.path)
    if (-not $resolved.StartsWith($stageRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw "Windows cleanup target escaped this batch: $resolved"
    }
    $file = Get-Item -LiteralPath $resolved
    if (($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        $file.Length -ne $item.bytes -or
        (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) {
        throw "Windows cleanup identity changed: $resolved"
    }
}
$helper = @'
from pathlib import Path
import hashlib
import json
base = Path("/Users/kiro/hyle-scratch/compute-unified/apple-nvfp4-20261020").resolve(strict=True)
plan = json.loads((base / "cleanup-plan-final.json").read_text())
candidates = plan["mac"]["candidates"]
retained = plan["mac"]["retained"]
paths = []
def check(item):
    p = Path(item["path"])
    resolved = p.resolve(strict=True)
    if p.is_symlink() or resolved != p or base not in resolved.parents or not p.is_file():
        raise RuntimeError(f"Invalid exact batch file: {p}")
    data = p.read_bytes()
    if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
        raise RuntimeError(f"File identity changed: {p}")
    return p
for item in candidates:
    paths.append(check(item))
for item in retained:
    if check(item) in paths:
        raise RuntimeError("A retained file is also scheduled for deletion")
for p in paths:
    p.unlink()
if not all(Path(item["path"]).is_file() for item in retained):
    raise RuntimeError("A retained file disappeared")
result = dict(passed=True, files=len(paths), bytes=sum(x["bytes"] for x in candidates),
              targets=[str(p) for p in paths], retained_files=len(retained))
(base / "cleanup-generated-result.json").write_text(json.dumps(result, indent=2) + chr(10))
print(json.dumps(dict(passed=True, files=result["files"], bytes=result["bytes"])))
'@
$helperPath = Join-Path $stageRoot 'cleanup_generated.py'
[IO.File]::WriteAllText($helperPath, $helper, [Text.UTF8Encoding]::new($false))
& scp $helperPath $planPath 'kiro@172.22.10.198:/Users/kiro/hyle-scratch/compute-unified/apple-nvfp4-20261020/'
if ($LASTEXITCODE -ne 0) { throw 'Cannot upload exact cleanup plan/helper.' }
& ssh 'kiro@172.22.10.198' "python3 '/Users/kiro/hyle-scratch/compute-unified/apple-nvfp4-20261020/cleanup_generated.py'"
if ($LASTEXITCODE -ne 0) { throw 'Remote cleanup failed; inspect its output before continuing.' }
& scp 'kiro@172.22.10.198:/Users/kiro/hyle-scratch/compute-unified/apple-nvfp4-20261020/cleanup-generated-result.json' (Join-Path $stageRoot 'cleanup-generated-result.json')
if ($LASTEXITCODE -ne 0) { throw 'Cannot collect actual cleanup result.' }
foreach ($item in $plan.windows.candidates) {
    Remove-Item -LiteralPath $item.path -Force
}
$result = [ordered]@{
    passed = $true
    mac_files = $plan.mac.count
    mac_bytes = $plan.mac.bytes
    windows_files = $plan.windows.count
    windows_bytes = $plan.windows.bytes
    total_bytes = $plan.total_bytes
    retained = $plan.preserve
}
[IO.File]::WriteAllText((Join-Path $stageRoot 'cleanup-result.json'),
    ($result | ConvertTo-Json -Depth 4) + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
Write-Host "Reclaimed $($plan.total_bytes) bytes; final image, objects and source retained."
