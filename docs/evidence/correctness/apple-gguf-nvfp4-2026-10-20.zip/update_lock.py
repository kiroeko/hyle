"""Update only the current common GGML patch tree and its notice identity."""
import hashlib
import json
from pathlib import Path
import re

stage = Path(__file__).resolve().parent
root = stage.parents[2]
lock_path = root / "cmake/HyleDependencyLock.json"
vendor = root / "third_party/ggml_runtime"


def normalized_digest(path):
    data = path.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    return hashlib.sha256(data).hexdigest()


rows = []
for path in sorted(vendor.rglob("*"), key=lambda p: p.relative_to(vendor).as_posix()):
    if path.is_symlink():
        raise RuntimeError(f"Unexpected vendored symlink: {path}")
    if path.is_file():
        rows.append((path.relative_to(vendor).as_posix(), normalized_digest(path)))
tree_hash = hashlib.sha256("".join(f"{p}|{h}\n" for p, h in rows).encode()).hexdigest()
notice_hash = normalized_digest(vendor / "NOTICE.md")
text = lock_path.read_text(encoding="utf-8")
parsed = json.loads(text)
record = next(r for r in parsed["dependencies"] if r["name"] == "ggml_runtime_patches")
old_tree = record["vendored"]["tree_sha256"]
old_notice = next(r["sha256"] for r in record["license"]["files"]
                  if r["path"] == "third_party/ggml_runtime/NOTICE.md")
start = text.index('"name": "ggml_runtime_patches"')
end_match = re.search(r'\n    \},\n    \{', text[start:])
if not end_match:
    raise RuntimeError("Common runtime lock record boundary missing")
end = start + end_match.end()
block = text[start:end]
for old, new in ((old_tree, tree_hash), (old_notice, notice_hash)):
    if block.count(old) != 1:
        raise RuntimeError("Expected one exact current identity in common runtime lock")
    block = block.replace(old, new, 1)
updated = text[:start] + block + text[end:]
json.loads(updated)
lock_path.write_text(updated, encoding="utf-8", newline="\n")
result = {"status": "updated", "old_tree": old_tree, "tree_sha256": tree_hash,
          "old_notice": old_notice, "notice_sha256": notice_hash,
          "files": [{"path": p, "sha256": h} for p, h in rows],
          "lock_sha256": hashlib.sha256(lock_path.read_bytes()).hexdigest()}
(stage / "dependency-lock-update.json").write_text(
    json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({k: v for k, v in result.items() if k != "files"}))
