"""Air-only bounded native/host refresh; keeps shared SDK archives untouched."""
import argparse,hashlib,json,pathlib,shlex,subprocess,time
S=pathlib.Path(__file__).resolve().parent;P=json.loads((S/'incremental-plan.json').read_text())
A=argparse.ArgumentParser();A.add_argument('--out',default='checks');A.add_argument('--resume-native');A.add_argument('--resume-host');A.add_argument('--reuse-test');args=A.parse_args()
O=S/args.out;O.mkdir(exist_ok=True)
G=pathlib.Path(P['ggml_cache']);N=S/('native-'+args.out);PREV=pathlib.Path(P['previous'])
def ident(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def run(tag,argv,cwd=None):
 t=time.time()
 with (O/(tag+'.stdout.log')).open('w') as so,(O/(tag+'.stderr.log')).open('w') as se:
  p=subprocess.Popen(argv,stdout=so,stderr=se,cwd=cwd or S);r=dict(argv=argv,pid=p.pid,started=t,exit=p.wait(),elapsed=time.time()-t)
 save(tag+'.command.json',r);print(tag,r['exit'],round(r['elapsed'],3),flush=True)
 if r['exit']:raise SystemExit(r['exit'])
 return r
T=S/'tooling-current';tool=T/'src/compute_ggml_runtime'
run('mixed-cpu',['python3',str(tool/'prepare_mixed_cpu_manifest.py'),'--source',str(S/'pin-subset'),'--resource-manifest',str(T/'third_party/ggml_runtime/patches.json'),'--cpu-manifest',str(T/'third_party/ggml_cpu_runtime/patches.json'),'--output',str(S/'mixed-cpu-manifest.json')])
run('compose',['python3',str(tool/'prepare_metal_iq1_manifest.py'),'--source',str(S/'pin-subset'),'--manifest',str(S/'mixed-cpu-manifest.json'),'--manifest',str(T/'third_party/ggml_runtime/metal-patches.json'),'--manifest',str(T/'third_party/ggml_metal_iq1/patches.json'),'--output',str(S/'combined-manifest.json')])
run('materialize',['python3',str(tool/'prepare_source.py'),'--source',str(S/'pin-subset'),'--manifest',str(S/'combined-manifest.json'),'--output',str(N)])
native=[];commands=(S/'original-metal-commands.txt').read_text().splitlines()
previous=json.loads((S/args.resume_native/'native-objects.json').read_text()) if args.resume_native else {}
for name in ['ggml-metal.cpp','ggml-metal-device.cpp','ggml-metal-device.m']:
 if name in previous and previous[name]['source']['sha256']==ident(N/'src/ggml-metal'/name)['sha256']:
  x=previous[name];assert ident(x['object']['path'])==x['object'];native.append(x['object']['path']);continue
 cmd=next(shlex.split(x) for x in commands if ' -c ' in x and str(G/'src/ggml-metal'/name) in x)
 cmd=[x.replace(str(G),str(N)) for x in cmd]
 target=O/(name+'.o');cmd[cmd.index('-o')+1]=str(target)
 for opt in ['-MF','-MT']:
  if opt in cmd:cmd[cmd.index(opt)+1]=str(target)+('.d' if opt=='-MF' else '')
 cmd.insert(1,'-I'+str(N/'src/ggml-metal'))
 run('compile-'+name,cmd);previous[name]=dict(object=ident(target),source=ident(N/'src/ggml-metal'/name));save('native-objects.json',previous);native.append(str(target))
for kind in ['mul_mv','mul_mm','quantize']:
 name='embed-'+kind
 src=N/'src/ggml-metal/kernels'/(kind+'.metal');text=src.read_text()
 headers=[N/'src/ggml-metal/kernels/common.h']
 for h in ['dequantize.h','quantize.h','dequantize_nvfp4.h']:
  if '#include "'+h+'"' in text:headers.append(N/'src/ggml-metal/kernels'/h)
 text=''.join(p.read_text() for p in headers)+text
 text='\n'.join(x for x in text.splitlines() if not any('#include "'+h+'"' in x for h in ['common.h','dequantize.h','quantize.h','dequantize_nvfp4.h']) and '#pragma once' not in x)+'\n'
 text=text.replace('__embed_ggml-common.h__',(N/'src/ggml-common.h').read_text())
 text=text.replace('#include "ggml-metal-impl.h"',(N/'src/ggml-metal/ggml-metal-impl.h').read_text())
 if name in previous and previous[name]['source']['sha256']==hashlib.sha256(text.encode()).hexdigest():
  x=previous[name];assert ident(x['object']['path'])==x['object'];native.append(x['object']['path']);continue
 embed=O/('ggml-metal-embed-'+kind+'.metal');embed.write_text(text)
 asm=O/('ggml-metal-embed-'+kind+'.s');asm.write_text('.section __DATA,__ggml_metallib\n.globl _ggml_metallib_'+kind+'_start\n_ggml_metallib_'+kind+'_start:\n.incbin "'+str(embed)+'"\n.globl _ggml_metallib_'+kind+'_end\n_ggml_metallib_'+kind+'_end:\n')
 target=O/(asm.name+'.o');run('compile-'+name,['/usr/bin/clang','-arch','arm64','-c',str(asm),'-o',str(target)])
 previous[name]=dict(object=ident(target),source=ident(embed),headers=[ident(p) for p in headers]);save('native-objects.json',previous);native.append(str(target))
save('native-objects.json',previous)
records=P['base_records'].copy()
resume=json.loads((S/args.resume_host/'complete-object-closure.json').read_text()) if args.resume_host else {}
for rel in P['fresh']:
 if rel in resume and ident(S/'current'/rel)['sha256']==resume[rel]['source']['sha256'] and resume[rel]['object']!=records.get(rel,{}).get('object'):
  records[rel]=resume[rel];continue
 if rel in records:row=records[rel];cmd=row['argv'][:];prefixes=P['old_prefixes']
 else:
  row=P['extra_commands'][rel];cmd=shlex.split(row['command']);prefixes=P['old_prefixes']+[row['file'][:-len(rel)-1]]
 for i,x in enumerate(cmd):
  for prefix in prefixes:x=x.replace(prefix.rstrip('/'),str(S/'current'))
  cmd[i]=x
 source=S/'current'/rel;target=O/(rel.replace('/','--')+'.o');cmd[cmd.index('-c')+1]=str(source);cmd[cmd.index('-o')+1]=str(target)
 for opt in ['-MF','-MT']:
  if opt in cmd:cmd[cmd.index(opt)+1]=str(target)+('.d' if opt=='-MF' else '')
 run('compile-'+rel.replace('/','--'),cmd);records[rel]=dict(argv=cmd,object=ident(target),source=ident(source))
for row in records.values():assert ident(row['object']['path'])==row['object']
save('complete-object-closure.json',records)
archive=O/'libcurrent-hyle.a';run('archive',['/usr/bin/ar','qc',str(archive)]+[r['object']['path'] for r in records.values()]);run('ranlib',['/usr/bin/ranlib',str(archive)])
source=S/'current'/P['test_source'];target=O/'nvfp4-test.o';cmd=P['test_compile'][:]
for i,x in enumerate(cmd):
 for prefix in P['old_prefixes']:x=x.replace(prefix.rstrip('/'),str(S/'current'))
 cmd[i]=x
cmd[cmd.index('-c')+1]=str(source);cmd[cmd.index('-o')+1]=str(target);cmd[cmd.index('-MF')+1]=str(target)+'.d'
if args.reuse_test:
 target=S/args.reuse_test/'nvfp4-test.o';save('test-reused.json',dict(object=ident(target),source=ident(source),previous_command=ident(S/args.reuse_test/'test-compile.command.json')))
else:run('test-compile',cmd)
image=O/'nvfp4-tests';cmd=P['link'][:]
for i,x in enumerate(cmd):
 if x.endswith('/admission-test.o'):cmd[i]=str(target)
 elif x.endswith('/libcurrent-hyle.a'):cmd[i]=str(archive)
 elif x.startswith('-Wl,-map,'):cmd[i]='-Wl,-map,'+str(image)+'.map'
cmd[cmd.index('-o')+1]=str(image)
# Keep the actual already-tested MMID operations host patch. All six affected
# native owners precede the existing SDK archive, whose old members stay idle.
native.append(str(PREV/'native-check/ggml-metal-ops.cpp.o'))
idx=next(i for i,x in enumerate(cmd) if x.endswith('/libggml-metal.a'));cmd[idx:idx]=native
run('link',cmd)
metallib=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib')
link=O/'mlx.metallib'
if not link.exists():link.symlink_to(metallib)
save('build-summary.json',dict(passed=True,image=ident(image),host_fresh=len(P['fresh'])+1,native_fresh=6,host_reused=len(records)-len(P['fresh']),native_objects=[ident(p) for p in native],sdk_rebuilt=False))
r=run('tests',[str(image)])
save('summary.json',dict(passed=r['exit']==0,exit=r['exit'],image=ident(image),native_fresh=6,host_fresh=len(P['fresh'])+1,actual_test_log=str(O/'tests.stdout.log'),source_freeze=ident(S/'native-source-freeze.json'),tests_source_freeze=ident(S/'tests-source-freeze.json')))
