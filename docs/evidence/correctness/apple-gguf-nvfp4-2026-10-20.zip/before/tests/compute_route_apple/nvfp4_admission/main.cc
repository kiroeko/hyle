#include <hyle/compute/apple.h>
#include <hyle/compute/low_precision.h>
#include <hyle/graph/apple.h>

#include <array>
#include <cstdio>
#include <cstdint>
#include <initializer_list>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace c = hyle::compute;
namespace a = c::apple;
namespace g = hyle::graph;

template <class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
c::TensorDesc dense(c::DataType type, std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type, {shape.begin(), shape.size()}));
}

void expect_native_decline(hyle::Result<a::Program> result, const char *label) {
  if (result) throw std::runtime_error(std::string(label) + " unexpectedly prepared");
  if (!result.error().IsUnimplemented() ||
      result.error().message() != "ggml Metal model capability unavailable")
    throw std::runtime_error(std::string(label) + " did not reach native capability decline: " +
                             std::string(result.error().message()));
  std::printf("PASS %s: native Metal capability unavailable\n", label);
}

void check_operation(a::Context &context, c::Operation operation,
                     std::span<const c::TensorDesc> descriptions,
                     const char *direct_label, const char *graph_label) {
  // A legal public descriptor reaches the real backend capability check.
  // No examples, payload arrays, invocation, bindings or submission are made.
  std::array<c::TensorDesc, 1> outputs;
  check(c::infer_output_descriptions(operation, descriptions, outputs));
  std::vector<a::InputSpec> specs;
  for (const auto &description : descriptions)
    specs.push_back(take(a::input_spec(description)));
  expect_native_decline(context.prepare(operation, specs), direct_label);

  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> inputs;
  for (const auto &description : descriptions)
    inputs.push_back(take(builder.input(description)));
  const auto node = take(builder.add_node(operation, inputs));
  check(builder.publish(take(builder.result(node, 0))));
  auto graph = take(std::move(builder).finish());
  expect_native_decline(g::apple::compile(context, graph), graph_label);
}

int main() {
  try {
    auto context = take(a::Context::create());
    const auto weight = take(c::gguf_weight_description(
        c::GgufQuantizedType::kNvfp4, c::DataType::kFloat32, 64, 8));
    const std::array matmul_inputs{dense(c::DataType::kFloat32, {1, 64}), weight};
    check_operation(context, c::Operation(c::MatMul{}), matmul_inputs,
                    "Direct NVFP4 MatMul", "Graph NVFP4 MatMul");
    const std::array gather_inputs{take(weight.transposed()),
                                  dense(c::DataType::kInt32, {2})};
    check_operation(context, c::Operation(c::Gather{}), gather_inputs,
                    "Direct NVFP4 Gather", "Graph NVFP4 Gather");
    check(context.close());
    std::puts("PASS four descriptor-only NVFP4 declines; no payload or execution");
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "FAIL %s\n", error.what());
    return 1;
  }
}
