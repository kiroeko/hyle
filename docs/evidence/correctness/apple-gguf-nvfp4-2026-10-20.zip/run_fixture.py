"""Only refresh the corrected consumer TU and its image."""
import hashlib,json,pathlib,subprocess,time
S=pathlib.Path(__file__).resolve().parent;O=S/'checks-final-fixture';O.mkdir(exist_ok=True)
def ident(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def run(tag,argv):
 t=time.time()
 with (O/(tag+'.stdout.log')).open('w') as so,(O/(tag+'.stderr.log')).open('w') as se:
  p=subprocess.Popen(argv,stdout=so,stderr=se,cwd=S);r=dict(argv=argv,pid=p.pid,started=t,exit=p.wait(),elapsed=time.time()-t)
 save(tag+'.command.json',r);print(tag,r['exit'],flush=True)
 if r['exit']:raise SystemExit(r['exit'])
 return r
source=S/'current/tests/compute_route_apple/gguf_nvfp4_test.cc';snapshot=O/'compiled-gguf_nvfp4_test.cc';snapshot.write_bytes(source.read_bytes())
target=O/'nvfp4-test.o';cmd=json.loads((S/'checks-mixed/test-compile.command.json').read_text())['argv']
cmd[cmd.index('-c')+1]=str(source);cmd[cmd.index('-o')+1]=str(target);cmd[cmd.index('-MF')+1]=str(target)+'.d'
run('test-compile',cmd)
image=O/'nvfp4-tests';cmd=json.loads((S/'checks-shader-fix/link.command.json').read_text())['argv']
for i,x in enumerate(cmd):
 if x.endswith('/nvfp4-test.o'):cmd[i]=str(target)
 elif x.startswith('-Wl,-map,'):cmd[i]='-Wl,-map,'+str(image)+'.map'
cmd[cmd.index('-o')+1]=str(image);run('link',cmd)
lib=O/'mlx.metallib'
if not lib.exists():lib.symlink_to(S/'checks-shader-fix/mlx.metallib')
save('build-summary.json',dict(passed=True,image=ident(image),compiled_source=ident(snapshot),source=ident(source),object=ident(target),fresh_host=1,fresh_native=0,baseline_link=ident(S/'checks-shader-fix/link.command.json')))
r=run('tests',[str(image)])
text=(O/'tests.stdout.log').read_text();count=sum(x.startswith('PASS Direct ') or x.startswith('PASS Graph ') or x.startswith('PASS common ') for x in text.splitlines())
save('summary.json',dict(passed=r['exit']==0,exit=r['exit'],image=ident(image),consumer_source=ident(snapshot),tests_source_freeze=ident(S/'tests-source-freeze.json'),native_source_freeze=ident(S/'native-source-freeze.json'),domains=count,actual_tests_command=ident(O/'tests.command.json'),legacy_control=json.loads((S/'legacy-control/summary.json').read_text())))
