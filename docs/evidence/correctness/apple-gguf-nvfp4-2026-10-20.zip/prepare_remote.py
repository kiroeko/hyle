import hashlib,json,pathlib,posixpath,re,shlex,subprocess,tarfile
S=pathlib.Path(__file__).resolve().parent;ROOT=S.parents[2]
PIN=pathlib.Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
REMOTE='/Users/kiro/hyle-scratch/compute-unified/apple-nvfp4-20261020'
PREVIOUS='/Users/kiro/hyle-scratch/compute-unified/grouped-shared-activation-20261020/apple'
G='/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-0bae7e9e90b384d8'
def save(name,x):(S/name).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
code=r'''import pathlib,json,hashlib,shlex
P=pathlib.Path(PREVIOUS);G=pathlib.Path(GGML)
records=json.loads((P/'checks-output-span/complete-object-closure.json').read_text())
def ident(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
deps={};headers={}
cc=json.loads(pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/compile_commands.json').read_text())
extras={}
extra_paths=['src/graph_route_apple/'+name for name in ['execution_source.cc','native_region.cc','native_paged_region.cc','native_ragged_region.cc','native_paged_pending.cc','apple_batch.cc','weight_binding.cc']]
extra_paths += ['src/graph_batch/'+name for name in ['batch.cc','materialized_invocation.cc','native_paged_node.cc','native_batch_regions.cc','native_pending_regions.cc','row_cache_node.cc']]
for rel in extra_paths:
 row=next((r for r in cc if r['file'].endswith('/'+rel)),None)
 if row is None:
  original=records['src/graph_route_apple/apple_lowering.cc'];argv=original['argv'][:];oldfile=argv[argv.index('-c')+1];newfile=oldfile[:-len('src/graph_route_apple/apple_lowering.cc')]+rel;argv[argv.index('-c')+1]=newfile
  if rel.startswith('src/graph_batch/'):
   argv += ['-DHYLE_GRAPH_BATCH_BUILD'];argv=[x.replace('/src/graph_route_apple','/src/graph_batch') if x.startswith('-I') else x for x in argv]
  row=dict(file=newfile,command=shlex.join(argv),derived_from_same_module_owner=original)
 extras[rel]=row
for rel,row in records.items():
 p=pathlib.Path(row['object']['path']+'.d');items=[]
 if p.exists():
  for x in shlex.split(p.read_text().replace('\\\n',' ').split(':',1)[1]):
   if '/current/' in x:
    k=x.split('/current/',1)[1];r=ident(x);r['relative']=k;items.append(r)
 deps[rel]=items
for source in ['ggml-metal.cpp','ggml-metal-device.cpp','ggml-metal-device.m']:
 cmd=next(shlex.split(x) for x in (P/'raw-before-retry/original-metal-commands.txt').read_text().splitlines() if ' -c ' in x and str(G/'src/ggml-metal'/source) in x)
 d=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')/cmd[cmd.index('-MF')+1]
 if d.exists():
  for x in shlex.split(d.read_text().replace('\\\n',' ').split(':',1)[1]):
   if x.startswith(str(G)+'/') and pathlib.Path(x).suffix in ('.h','.hpp'):
    headers[pathlib.Path(x).relative_to(G).as_posix()]=ident(x)
print(json.dumps(dict(records=records,dependencies=deps,native_headers=headers,extra_commands=extras)))
'''.replace('PREVIOUS',repr(PREVIOUS)).replace('GGML',repr(G))
r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','python3','-'],input=code,text=True,capture_output=True)
(S/'owner-inventory.stdout.log').write_text(r.stdout,encoding='utf8');(S/'owner-inventory.stderr.log').write_text(r.stderr,encoding='utf8');assert r.returncode==0,r.stderr
inv=json.loads(r.stdout);save('owner-inventory.json',inv)
fresh={};needed=set()
for rel,row in inv['records'].items():
 reasons=[]
 for d in inv['dependencies'][rel]:
  p=ROOT/posixpath.normpath(d['relative'])
  if p.is_file() and ident(p)['sha256']!=d['sha256']:reasons.append(d['relative'])
 if (ROOT/rel).is_file() and ident(ROOT/rel)['sha256']!=row['source']['sha256']:reasons.append(rel)
 if reasons:
  fresh[rel]=sorted(set(reasons));needed.add(rel);needed.update(posixpath.normpath(d['relative']) for d in inv['dependencies'][rel])
for rel,row in inv['extra_commands'].items():
 fresh[rel]=['original common Graph ExecutionSource owner absent from old native-Graph test closure'];needed.add(rel)
# Reuse the actual prior host/test include closure (small local headers only).
old=json.loads((ROOT/'.scratch/architecture-refactor-2026-10-18/grouped-shared-activation/apple/incremental-plan.json').read_text())
needed.update(x['path'] for x in old['sources'] if (ROOT/x['path']).exists())
test='tests/compute_route_apple/gguf_nvfp4_test.cc';needed.add(test)
queue=list(needed)
while queue:
 rel=queue.pop();p=ROOT/rel
 if p.suffix not in ('.cc','.h','.inc'):continue
 for name in re.findall(r'#\s*include\s*[<"]([^>"]+)[>"]',p.read_text(encoding='utf8')):
  for cand in [p.parent/name,ROOT/'include'/name,ROOT/name]:
   if cand.is_file() and cand.resolve().is_relative_to(ROOT):
    key=cand.resolve().relative_to(ROOT).as_posix()
    if key not in needed:needed.add(key);queue.append(key)
    break
for rel in sorted(needed):
 p=S/'current'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/rel).read_bytes())
native_needed=set(inv['native_headers'])
# Metal embed generation uses only these original common includes, not an SDK
# or source-tree copy. All other patch sources are exact 22-manifest inputs.
native_needed.update(['src/ggml-common.h','src/ggml-metal/ggml-metal-impl.h'])
native_needed.update('src/ggml-metal/kernels/'+n for n in ['common.h','dequantize.h','quantize.h'])
m=json.loads((S/'combined-manifest.json').read_text())
native_needed.update(x['path'] for x in m['files'] if 'content' not in x)
queue=[S/'native-source/src/ggml-metal'/x for x in ['ggml-metal.cpp','ggml-metal-device.cpp','ggml-metal-device.m']]
seen=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 for name in re.findall(r'#\s*(?:include|import)\s*"([^"]+)"',p.read_text(encoding='utf8')):
  rel_parent=(p.relative_to(S/'native-source').parent if p.is_relative_to(S/'native-source') else p.relative_to(PIN).parent)
  for q in [PIN/rel_parent/name,PIN/'src'/name,PIN/'include'/name,PIN/'src/ggml-metal'/name]:
   if q.is_file():
    rel=q.resolve().relative_to(PIN.resolve()).as_posix();native_needed.add(rel);queue.append(q);break
for rel in native_needed:
 p=S/'pin-subset'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((PIN/rel).read_bytes())
plan=dict(remote=REMOTE,previous=PREVIOUS,ggml_cache=G,base_records=inv['records'],fresh=fresh,extra_commands=inv['extra_commands'],
 sources=[dict(relative=x,**ident(S/'current'/x)) for x in sorted(needed)],native_headers=inv['native_headers'],
 old_prefixes=old['old_prefixes']+[PREVIOUS+'/current'],test_compile=old['test_compile'],link=old['link'],test_source=test,shared_sdk_rebuilt=False)
save('incremental-plan.json',plan)
for rel in ['src/compute_ggml_runtime/prepare_source.py','src/compute_ggml_runtime/prepare_metal_iq1_manifest.py','src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py','third_party/ggml_runtime/patches.json','third_party/ggml_runtime/metal-patches.json','third_party/ggml_metal_iq1/patches.json','third_party/ggml_cpu_runtime/patches.json']:
 p=S/'tooling-current'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/rel).read_bytes())
with tarfile.open(S/'source-package.tar.gz','w:gz') as a:
 for folder in ['current','pin-subset','tooling-current']:
  for p in (S/folder).rglob('*'):
   if p.is_file():a.add(p,arcname=p.relative_to(S).as_posix())
 for name in ['incremental-plan.json','native-source-freeze.json','native-application.json','tests-source-freeze.json','original-metal-commands.txt']:
  a.add(S/name,arcname=name)
print(json.dumps(dict(fresh=fresh,host_files=len(needed),native_selective_files=len(native_needed),package=ident(S/'source-package.tar.gz')),indent=2))
