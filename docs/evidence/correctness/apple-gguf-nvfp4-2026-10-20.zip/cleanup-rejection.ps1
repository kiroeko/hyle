$ErrorActionPreference = 'Stop'
$repoRoot = [IO.Path]::GetFullPath($PSScriptRoot)
if ($repoRoot -ne 'C:\public\project-hyle\hyle') {
    throw "Unexpected Hyle workspace: $repoRoot"
}
$stageRoot = Join-Path $repoRoot '.scratch\architecture-refactor-2026-10-18\apple-nvfp4'
$verified = Get-Content -LiteralPath (Join-Path $stageRoot 'validation\checks-final-fixture\summary.json') -Raw | ConvertFrom-Json
if (-not $verified.passed -or $verified.exit -ne 0 -or $verified.domains -ne 13) {
    throw 'The replacement positive Apple NVFP4 run has not passed.'
}
$relative = 'tests\compute_route_apple\nvfp4_admission\main.cc'
$target = [IO.Path]::GetFullPath((Join-Path $repoRoot $relative))
$snapshot = [IO.Path]::GetFullPath((Join-Path (Join-Path $stageRoot 'before') $relative))
if (-not $target.StartsWith($repoRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw "Cleanup target escaped workspace: $target"
}
$expected = '85451035C3E37E824D6FBDCC28FD3FE53337FDD7D38C637EA0CFC88C013CC43C'
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash -ne $expected -or
    (Get-FileHash -Algorithm SHA256 -LiteralPath $snapshot).Hash -ne $expected) {
    throw 'The obsolete rejection test or its archived source changed.'
}
$bytes = (Get-Item -LiteralPath $target).Length
Write-Host "Remove obsolete rejection source: $target ($bytes bytes); original retained at $snapshot"
Remove-Item -LiteralPath $target -Force
$receipt = [ordered]@{
    deleted_file = $target
    bytes = $bytes
    original_snapshot = $snapshot
    original_sha256 = $expected.ToLowerInvariant()
    replacement_run = 'validation/checks-final-fixture/summary.json'
}
[IO.File]::WriteAllText((Join-Path $stageRoot 'old-rejection-removal.json'),
    ($receipt | ConvertTo-Json -Depth 4) + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
