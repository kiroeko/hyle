import hashlib,json,pathlib,tarfile
S=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/apple-nvfp4-20261020')
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
checks=['checks','checks-mixed','checks-final','checks-closure','checks-shader-fix','checks-final-fixture','legacy-control']
payload=[]
for name in checks:
 for p in (S/name).rglob('*'):
  if p.is_file() and not p.is_symlink() and (p.suffix in ('.json','.log','.d','.cc','.metal','.s')):payload.append(p)
# Actual final private header/source closure. Other staged/pin trees are not
# recursively collected; the local exact manifests already reproduce them.
for name in ['native-checks-shader-fix','native-checks-final','native-materialized-full']:
 for p in (S/name).rglob('*'):
  if p.is_file() and (p.suffix in ('.h','.cpp','.m','.metal') or p.name=='CMakeLists.txt'):payload.append(p)
for n in ['inventory.json','run_incremental.py','run_fixture.py','run_control.py','native-source-freeze.json','tests-source-freeze.json','native-application.json','incremental-plan.json','combined-manifest.json','mixed-cpu-manifest.json']:
 payload.append(S/n)
inventory=[];cleanup=[]
for p in S.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 if p.suffix in ('.o','.a','.map','.gz') or p.name in ('nvfp4-tests','shared-activation-control'):
  row=ident(p);inventory.append(row)
  keep=(p.suffix=='.o' or p==S/'checks-final-fixture/nvfp4-tests' or p==S/'checks-shader-fix/libcurrent-hyle.a')
  if not keep:cleanup.append(row)
(S/'generated-artifacts.json').write_text(json.dumps(dict(artifacts=inventory,cleanup_candidates=cleanup,cleanup_bytes=sum(x['bytes'] for x in cleanup),retained='all objects, final NV image and final current-hyle archive; no files removed'),indent=2)+'\n')
payload.append(S/'generated-artifacts.json')
with tarfile.open(S/'proofs.tar.gz','w:gz') as a:
 for p in sorted(set(payload)):a.add(p,arcname=p.relative_to(S).as_posix(),recursive=False)
receipt=dict(files=len(set(payload)),archive=ident(S/'proofs.tar.gz'),cleanup_files=len(cleanup),cleanup_bytes=sum(x['bytes'] for x in cleanup))
(S/'proof-collection.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
