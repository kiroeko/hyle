"""Finite architecture regression receipts; no performance experiment."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
                if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def prepare():
    p = read(W / 'plan.json')
    reports = {name: read(W / 'runs' / name / 'attempt1/report.json') for name in p['cases']}
    baseline = reports['baseline']
    assert baseline['status'] == 'EXPECTED_OLD_HELPER_BIND_REJECTION'
    assert baseline['wrong_domain_rejections'] == 2 and baseline['native_submissions'] == 0
    assert reports['backend']['tests'] == 12 and reports['backend']['failures'] == reports['backend']['skipped'] == 0
    comparisons = []
    for name in ('single-auto', 'recursive', 'threshold', 'restore', 'natural', 'ordinary',
                 'batch', 'carrier_cpu', 'carrier_cuda', 'packet_cpu', 'packet_cuda'):
        anchor = b.OLD / 'runs' / name / 'attempt1/report.json'
        equal = stable(read(anchor)) == stable(reports[name])
        comparisons.append(dict(case=name, anchor=pin(anchor), complete_non_timing_equal=equal))
        assert equal, name
    consumers = {}
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    assert len(p['retained']) == 227
    for item in p['retained']:
        exact(item)
    assert not p['sdk_dependency_audit']['matches']
    save(W / 'analysis.json', dict(status='PASS_FINITE_READBACK_DOMAIN_CHECKS',
        gtests=12, finite_consumer_processes=12, failures=0, skipped=0,
        baseline=pin(W / 'runs/baseline/attempt1/report.json'),
        cases={name: pin(W / 'runs' / name / 'attempt1/report.json') for name in reports},
        complete_non_timing_comparisons=comparisons,
        successful_CXX_TUs=5, current_consumers=4, original_header_probe=1,
        corrected_compile_failure='First cli/natural/ordinary attempt failed at the same two arrow-style predicates calls still passing Backend; both calls corrected, attempt2 compiled. No SDK or numerical failure.',
        retained_SDK_engine_objects=227, SDK_CXX=0, NVCC=0, downloads=0,
        SDK_dependency_records=len(p['sdk_dependency_audit']['inspected']),
        unavailable_dependency_records=len(p['sdk_dependency_audit']['unavailable']),
        performance_experiments=0, performance_claim=False,
        limits=[
            'Full shared execution architecture remains incomplete; this fixes one actual resource-domain dependency.',
            'Only property mismatch and owner mismatch negatives checked here, not two different equal-property resources. Original Graph binding remains exact resource authority.',
            'Original Vulkan Bool/F32 SourceAlias tests mechanically migrated but not built or run with this CPU+CUDA SDK.',
            'No new Apple/Vulkan execution, full GLM/DeepSeek/Kimi run, throughput, peer profile, memory measurement or fault injection.',
            'Compiled reports retain domain properties, not original resource identity; caller must supply this program original domain table.'
        ]))
    base = read(p['base']['path'])
    current = {name: item for name, item in consumers.items() if name != 'baseline'}
    base.update(schema='hyle.readback-domains.current-link-base.v1', base=p['base'],
        current_consumers=current, previous_consumer=current['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'],
        link=[current['cli']['object']['path'] if key(arg) == key(p['original_consumer']) else arg
              for arg in p['original_link']])
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
        targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    (W / 'product.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'engine', 'tests'], cwd=R))
    print('PASS12 tests,12 finite consumers;11 complete non-timing reports unchanged; cleanup files', len(targets))


def finish():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R / 'test.ps1', W / 'cleanup.ps1')
    changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'engine', 'tests'], cwd=R, text=True).splitlines()
    out = R / 'docs/evidence/correctness/inference-readback-domains-2026-10-30.json'
    save(out, dict(schema='hyle.correctness.readback-domains.v1', date='2026-10-30',
        status='ACTUAL_PROGRAM_DOMAINS_AND_RESOURCE_DISPATCH_FINITE_CHECKED', base_commit=p['base_commit'],
        contract=dict(
            preparation='Caller-owned readback takes the actual compiled program StorageDomain span; cold ordinal, properties and optional owner consistency checked. Graph retains exact resource binding authority.',
            noncaller='SourceAlias/Invocation/Executable outputs need no caller domain lookup or caller pool; original result owners retained for synchronous read.',
            runtime='Readback dispatches through actual original output resource view; Backend::read was only a passthrough. No new upload, allocation, executor, permission or retirement path.',
            baseline='Exact original HEAD readback header compiled separately. Real reversed CPU0/CUDA1 graph rejected both old helper bindings with original Graph resource mismatch, before submission.'),
        sources=[pin(R / x) for x in changed], diff=pin(W / 'product.diff'),
        results=a, current_link_base=pin(W / 'model-link-base.json'),
        cleanup=dict(script=pin(R / 'test.ps1'), archived_script=pin(W / 'cleanup.ps1'),
                     manifest=pin(W / 'cleanup-targets.json'), result=cleanup),
        evidence_archive=out.with_suffix('.zip').name))
    with zipfile.ZipFile(out.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or any(x in ('bin', '__pycache__', 'ordinary-input') for x in path.relative_to(W).parts):
                continue
            if path.suffix.lower() in ('.json', '.py', '.ps1', '.cc', '.h', '.diff', '.log', '.xml'):
                z.write(path, path.relative_to(W).as_posix())
    with zipfile.ZipFile(out.with_suffix('.zip')) as z:
        assert z.testzip() is None
    print('Evidence written; archive checked', pin(out.with_suffix('.zip'))['bytes'])


if __name__ == '__main__':
    {'prepare': prepare, 'finish': finish}[sys.argv[1]]()
