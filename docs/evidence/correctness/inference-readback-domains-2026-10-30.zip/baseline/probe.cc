#include "readback.h"
#include "../../../engine/inference/graph_bindings.h"
#include "hyle/graph/cuda.h"
#include <array>
#include <iostream>
#include <stdexcept>
#include <string>

namespace i=hyle::inference;
namespace c=hyle::compute;
namespace g=hyle::graph;
template<class T> T take(hyle::Result<T> result) {
  if(!result)throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if(!status.ok())throw std::runtime_error(std::string(status.message()));
}
int main() {
  try {
    auto backend=take(i::Backend::create({.primary=i::BackendKind::kCuda,.cpu_assist=true}));
    std::array<g::StorageDomain,2> domains;
    for(const auto &domain:backend.storage_domains()) {
      if(domain.resource==backend.host_device())domains[0]=domain;
      if(domain.resource==backend.device())domains[1]=domain;
    }
    const std::array targets{
        g::ExecutionTarget{take(g::ExecutionSource::acquire(*take(backend.common_context()))),g::StorageDomainId{1}},
        g::ExecutionTarget{take(g::ExecutionSource::acquire(*take(backend.cpu_context()))),g::StorageDomainId{0}}};
    const std::array lanes{g::ExecutionLane{g::ExecutionTargetId{0}},g::ExecutionLane{g::ExecutionTargetId{1}}};
    const g::CompileEnvironment environment{.storage_domains=domains,.targets=targets,.lanes=lanes};
    const auto description=take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{17}));
    auto builder=take(g::GraphBuilder::create());
    const auto cpu_input=take(builder.input(description)),gpu_input=take(builder.input(description));
    const auto cpu_output=take(builder.add(c::Unary{c::UnaryKind::kNeg},cpu_input));
    const auto gpu_output=take(builder.add(c::Unary{c::UnaryKind::kNeg},gpu_input));
    check(builder.publish(cpu_output));check(builder.publish(gpu_output));
    auto logical=take(std::move(builder).finish());
    i::GraphBindings bindings(domains);
    for(const auto value:{cpu_input,cpu_output})check(bindings.external(value,g::StorageDomainId{0}));
    for(const auto value:{gpu_input,gpu_output})check(bindings.external(value,g::StorageDomainId{1}));
    check(bindings.node(take(logical.producer(cpu_output)),{g::ExecutionTargetId{1},g::StorageDomainId{0}}));
    check(bindings.node(take(logical.producer(gpu_output)),{g::ExecutionTargetId{0},g::StorageDomainId{1}}));
    auto compiled=take(g::batch::compile(logical,environment,bindings.options({.region_selection=g::RegionSelectionPolicy::kDisabled})));
    unsigned rejected=0;
    for(const auto value:{cpu_output,gpu_output}) {
      // Exact HEAD header, not a reconstructed helper or the corrected API.
      auto output=take(i::PreparedReadback::prepare(compiled,value,backend));
      auto run=take(compiled.executable.create_invocation());
      const auto result=output.bind(run);
      if(!result.IsInvalidArgument()||result.message()!="tensor binding does not match its compiled memory resource")
        throw std::runtime_error("old helper did not reproduce the actual compiled-resource rejection");
      ++rejected;
    }
    std::cout<<"{\"status\":\"EXPECTED_OLD_HELPER_BIND_REJECTION\",\"wrong_domain_rejections\":"<<rejected
             <<",\"native_submissions\":0}\n";
    return 0;
  } catch(const std::exception &error) {std::cerr<<error.what()<<'\n';return 1;}
}
