"""Current readback consumers with source-identical cached SDK; no benchmark."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
OLD=R/'.scratch/inference-stage-resources-20261030'
spec=importlib.util.spec_from_file_location('stage',OLD/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=b.s.W=b.s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key


def prepare():
    base=read(OLD/'model-link-base.json');prior=read(OLD/'plan.json')
    sdk=read(base['sdk_engine_dependencies']['path'])
    changed={key(R/x) for x in subprocess.check_output(['git','diff','--name-only','--','engine'],cwd=R,text=True).splitlines()}
    records={key(x['object']):x for x in sdk['inspected']}
    records.update({key(x['object']):x for x in sdk['engine_consumers'] if 'dependencies' in x})
    inspected=[];unavailable=[];matches=[]
    for item in base['retained']:
        exact(item)
        adjacent=Path(item['path']).parent/'dependencies.json'
        row=records.get(key(item['path']))
        path=adjacent if adjacent.is_file() and 'Data' in read(adjacent) else Path(row['dependencies']['path']) if row else None
        if path is None:unavailable.append(item['path']);continue
        data=read(path)['Data'];inspected.append(dict(object=item['path'],dependencies=pin(path)))
        if any(key(x) in changed for x in [data['Source'],*data['Includes']]):matches.append(item['path'])
    assert not matches,matches
    consumers={}
    for name in ('cli','natural','ordinary','readback-test'):
        unit=prior['consumers'][name]
        consumers[name]=dict(unit,compile=b.s.relocated(unit['compile'],name))
    for name,source in [('baseline',W/'baseline/probe.cc')]:
        args=b.s.relocated(consumers['cli']['compile'],name,source)
        if name=='baseline':args.insert(1,'/I'+str(R/'engine/inference'))
        consumers[name]=dict(source=str(source),compile=args)
    (W/'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    ordinary=W/'ordinary-input';ordinary.mkdir(exist_ok=True)
    for file in ('weights.tsv','prompt.ids'):shutil.copyfile(OLD/'ordinary-input'/file,ordinary/file)
    cases={name:prior['cases'][name] for name in ('single-auto','recursive','threshold','restore','natural','batch','group',
        'carrier_cpu','carrier_cuda','packet_cpu','packet_cuda')}
    cases['ordinary']=dict(unit='ordinary',args=['--cuda-continuous',str(ordinary)])
    cases['backend']=dict(unit='readback-test',filter='QwenBackendCpuCuda.*',tests=12)
    cases['baseline']=dict(unit='baseline',args=[])
    save(W/'plan.json',dict(base=pin(OLD/'model-link-base.json'),base_commit='0b359292a',
        retained=base['retained'],runtime=base['runtime'],original_link=base['link'],
        original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        sdk_engine_dependencies=base['sdk_engine_dependencies'],consumers=consumers,units={},
        cases=cases,environments=prior['environments'],
        sdk_dependency_audit=dict(inspected=inspected,unavailable=unavailable,matches=matches),
        SDK_CXX_compiles=0,NVCC_compiles=0,downloads=0))
    print('Prepared5 consumer/baseline TUs;227 SDK objects retained; no SDK/NVCC/download.')


def compile_group(attempt,names):
    errors=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs={pool.submit(b.s.compile_one,name,attempt):name for name in names}
        for job in as_completed(jobs):
            try:job.result()
            except BaseException as error:errors.append(dict(unit=jobs[job],error=str(error)))
    save(W/('compile-'+attempt+'-'+names[0]+'.json'),dict(names=names,errors=errors,max_concurrency=2))
    assert not errors,errors


def link(name,attempt):
    p=read(W/'plan.json');receipt=read(W/'compile'/name/'receipt.json');exact(receipt['object'])
    args=[]
    for arg in p['original_link']:
        if key(arg)==key(p['original_consumer']):arg=receipt['object']['path']
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
        args.append(arg)
    if name=='readback-test':
        args.extend(str(R/'.scratch/build-compute-v2-dev/lib'/x) for x in ('gtest_main.lib','gtest.lib'))
    b.s.b.execute(args,W/'link'/name/attempt,240)
    save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))


def run(name,attempt):
    p=read(W/'plan.json');case=p['cases'][name];folder=W/'runs'/name/attempt
    image=read(W/('ready-'+case['unit']+'.json'));exact(image);save(folder/'image.json',image)
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    if 'filter' in case:
        b.s.b.execute([image['path'],'--gtest_color=no','--gtest_fail_fast','--gtest_filter='+case['filter'],
            '--gtest_output=xml:'+str(folder/'results.xml')],folder,300)
        result=ET.parse(folder/'results.xml').getroot()
        assert result.get('tests')==str(case['tests']) and result.get('failures')=='0' and result.get('errors','0')=='0' and not result.findall('.//skipped')
        report=dict(status='PASS',tests=case['tests'],failures=0,skipped=0,
            cases=[dict(name=x.get('classname')+'.'+x.get('name'),seconds=x.get('time')) for x in result.findall('.//testcase')])
    else:
        b.s.b.execute([image['path'],*case['args']],folder,300)
        report=read(folder/'stdout.log')
        if name=='baseline':assert report['status']=='EXPECTED_OLD_HELPER_BIND_REJECTION' and report['wrong_domain_rejections']==2
        elif case['unit']=='cli':assert report['live_committed_versions']==0
        else:assert report['status']=='PASS'
    save(folder/'report.json',report);print('PASS',name,flush=True)


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':b.s.compile_one(*sys.argv[2:])
    elif action=='compile-group':compile_group(sys.argv[2],sys.argv[3:])
    elif action=='link-selected':
        for name in sys.argv[3:]:link(name,sys.argv[2])
    elif action=='run-selected':
        for name in sys.argv[3:]:run(name,sys.argv[2])
    else:raise ValueError(action)
