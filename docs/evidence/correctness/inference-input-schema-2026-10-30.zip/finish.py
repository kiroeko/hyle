"""Small delivery index, original receipts retained; no rebuild or download."""
from pathlib import Path
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    assert a['status'] == 'PASS_FINITE_INPUT_SCHEMA_AND_ORIGINAL_CONSUMERS'
    base = read(p['base']['path'])
    for item in p['retained']:
        exact(item)
    consumers = {}
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    base.update(schema='hyle.input-schema.current-link-base.v1', base=p['base'], current_consumers=consumers,
        previous_consumer=consumers['cli']['receipt'], consumer_source=pin(p['consumers']['cli']['source']),
        compile=p['consumers']['cli']['compile'])
    base['link'] = [consumers['cli']['object']['path'] if key(arg) == key(p['original_consumer'])
                    else arg for arg in p['original_link']]
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
        targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    (W / 'product.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'engine', 'tests'], cwd=R))
    print('Retained11 current consumer objects and227 SDK inputs; exact flat image targets:', len(targets))


def finish():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'engine', 'tests'], cwd=R, text=True).splitlines()
    value = dict(schema='hyle.correctness.program-input-schema.v1', date='2026-10-30',
        status='EXACT_COLD_INPUT_FACTS_IMPLEMENTED_AND_FINITE_CHECKED', base_commit=p['base_commit'],
        contract=dict(cold='Original selected concrete CompiledGraph report, unique external_input root by full ValueId; preserve dtype/encoding/shape/strides, including unused inputs. Cross-domain replicas/aliases are not guessed as roots.',
            raw_lease='ProgramIo::bind(run,handle,ReadLease) uses its cold input description; original Graph checks actual resource, span and read owner.',
            typed='Explicit actual TensorDesc and ConstTensorView overloads still pass actual metadata to Graph; they never substitute expected cold metadata.',
            inventory='Existing cold ProgramIo input vector holds InputFacts instead of ValueId; ColdProgram removes its parallel vector of Port descriptions.',
            models='Qwen hidden/Q/frontier and GLM/DeepSeek/Kimi component inputs use the same facts; recipe descriptors are checked during cold construction.',
            authority='Original CompiledGraph/Invocation, leases/pools, Source/Store/Append, Status and actual retirement unchanged. No owner, executor, dynamic callback or hot allocation added.'),
        implementation=dict(sources=[pin(R / x) for x in changed], diff=pin(W / 'product.diff'),
            SDK_CXX_compiles=0, retained_SDK_engine_objects=227, consumer_CXX_TUs=11,
            NVCC_compiles=0, downloads=0, current_link_base=pin(W / 'model-link-base.json')),
        checks=dict(analysis=pin(W / 'analysis.json'), gtests=20, failures=0, skipped=0,
            finite_consumer_processes=12, cases=a['cases'], original_non_timing_comparisons=a['comparisons'],
            schema='Cold unused strided input and exact-child facts; non-input and foreign same-ordinal ID return NotFound without consuming capacity; actual typed/explicit stride rejection preserves later original output.',
            recipe='Same24 bytes with wrong input shape is rejected during cold assembly before changing the original Invocation or pool.',
            components='Actual cached GLM/DeepSeek/Kimi original parameters and state checks, including Kimi real Source lifecycle; no synthetic replacement of original native execution.',
            Qwen='Natural40 outputs, ordinary16 arms, NextN checked failure/retry, K2, threshold and two-request restore retain complete old non-time reports. Existing grouped recursive failure/recovery also passes its original state/retirement checks; no old-report equality claim for that case.'),
        SDK_dependency_audit=dict(inspected=len(a['sdk_dependency_audit']['inspected']),
            unavailable=len(a['sdk_dependency_audit']['unavailable']), program_io_matches=[],
            detail=pin(W / 'analysis.json'), limits=a['sdk_dependency_audit']['limits']),
        performance_claim=False, limits=a['limits'],
        cleanup=dict(script=pin(R / 'test.ps1'), manifest=pin(W / 'cleanup-targets.json'), result=cleanup),
        evidence_archive='inference-input-schema-2026-10-30.zip')
    out = R / 'docs/evidence/correctness/inference-input-schema-2026-10-30.json'
    save(out, value)
    with zipfile.ZipFile(out.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or any(x in ('bin', '__pycache__', 'ordinary-input') for x in path.relative_to(W).parts):
                continue
            if path.suffix.lower() in ('.json', '.py', '.cc', '.diff', '.log', '.xml'):
                z.write(path, path.relative_to(W).as_posix())
    with zipfile.ZipFile(out.with_suffix('.zip')) as z:
        assert z.testzip() is None
    print('Evidence saved and archive integrity checked:', pin(out), pin(out.with_suffix('.zip')))


if __name__ == '__main__':
    {'prepare': prepare, 'finish': finish}[sys.argv[1]]()
