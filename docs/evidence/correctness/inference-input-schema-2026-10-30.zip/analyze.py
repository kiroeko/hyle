"""Keep all old non-timing consumer facts and independently inspect final receipts."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
                if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def main():
    p = read(W / 'plan.json')
    reports = {name: read(W / 'runs' / name / 'attempt1/report.json') for name in p['cases']}
    comparisons = []
    for name in ('single-auto', 'recursive', 'threshold', 'restore', 'natural', 'ordinary', 'batch'):
        anchor = b.OLD / 'runs' / name / 'attempt1/report.json'
        assert stable(read(anchor)) == stable(reports[name]), name
        comparisons.append(dict(case=name, anchor=pin(anchor), complete_non_timing_equal=True))
    for name in ('packet_cpu', 'packet_cuda'):
        anchor = R / '.scratch/inference-mtp-device-packet-20261029/refinement/runs' / name.replace('_', '-') / 'report.json'
        assert stable(read(anchor)) == stable(reports[name]), name
        comparisons.append(dict(case=name, anchor=pin(anchor), complete_non_timing_equal=True))
    for name in ('carrier_cpu', 'carrier_cuda'):
        report = reports[name]
        assert report['native_submissions'] == 2
        assert all(report[k] for k in ('unused_input_cold_registered', 'full_input_description_preserved',
            'foreign_input_identity_rejected', 'actual_stride_rejected_original_permission_preserved'))
    assert sum(report.get('tests', 0) for report in reports.values()) == 20
    for case, report in reports.items():
        if 'tests' in report:
            assert report['status'] == 'PASS' and report['failures'] == 0 and report['skipped'] == 0
    receipts = []
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        receipts.append(dict(name=name, receipt=pin(path), object=receipt['object']))
    sdk = read(p['sdk_engine_dependencies']['path'])
    rows = {key(row['object']): row for row in sdk['inspected']}
    rows.update({key(row['object']): row for row in sdk['engine_consumers'] if 'dependencies' in row})
    inspected, unavailable, matches = [], [], []
    wanted = key(R / 'engine/inference/program_io.h')
    for item in p['retained']:
        exact(item)
        adjacent = Path(item['path']).parent / 'dependencies.json'
        row = rows.get(key(item['path']))
        if adjacent.is_file() and 'Data' in read(adjacent):
            path = adjacent
        elif row is not None:
            path = Path(row['dependencies']['path'])
        else:
            unavailable.append(item['path'])
            continue
        d = read(path)['Data']
        inspected.append(dict(object=item['path'], receipt=pin(path)))
        if any(key(x) == wanted for x in [d['Source'], *d['Includes']]):
            matches.append(item['path'])
    assert not matches
    value = dict(status='PASS_FINITE_INPUT_SCHEMA_AND_ORIGINAL_CONSUMERS',
        comparisons=comparisons, gtests=20, finite_consumer_processes=12,
        cases={name: pin(W / 'runs' / name / 'attempt1/report.json') for name in reports},
        current_consumer_receipts=receipts,
        sdk_dependency_audit=dict(retained=227, inspected=inspected, unavailable=unavailable,
            program_io_matches=matches, limits='Missing dependency records are not invented. Current src/include have no engine dependency; two engine SDK objects retain source-identical inputs without ProgramIo.'),
        performance_claim=False,
        limits=['This is cold input schema and real component wiring, not complete model-independent stage assembly.',
                'Finite CPU/CUDA checks; no new Apple/Vulkan runtime or whole large-model run.',
                'No peer/full performance or memory window, no SDK/NVCC rebuild and no downloads.'])
    save(W / 'analysis.json', value)
    print(value['status'], 'gtests20; finite processes12;SDK matches0; dependency records',
          len(inspected), 'unavailable', len(unavailable), flush=True)


if __name__ == '__main__':
    main()
