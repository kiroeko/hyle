"""Current model IO consumers, retaining the current SDK and original cached fixtures."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import os
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-draft-accounting-20261030'
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-source-binding-20261030/build.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
s.W = s.b.W = W
read, save, pin, exact, key = s.read, s.save, s.pin, s.exact, s.key


def prepare():
    assert not (W / 'plan.json').exists()
    base = read(OLD / 'model-link-base.json')
    prior = read(OLD / 'plan.json')
    models = read(R / '.scratch/inference-program-io-consumers-20261030/plan.json')
    kimi = read(R / '.scratch/inference-kimi-source-lifecycle-20261030/plan.json')
    for item in base['retained']:
        exact(item)
    consumers = {}
    for name in ('cli', 'natural', 'ordinary'):
        previous = prior['consumers'][name]
        consumers[name] = dict(source=previous['source'],
            compile=s.relocated(previous['compile'], name), kind='consumer')
    # Keep historical wrappers immutable; the current one additionally exposes
    # the real no-model carrier and MTP packet cases through this same TU.
    source = W / 'model.cc'
    content = Path(consumers['natural']['source']).read_text(encoding='utf-8')
    content = content.replace('#include "qwen_publication_retirement_case.h"',
        '#include "inference_program_carrier_case.h"\n#include "inference_mtp_packet_case.h"\n#include "qwen_publication_retirement_case.h"')
    marker = '    if (name == "natural") return qwen_mtp_natural_relay_case::run(argv[3], kind);'
    assert content.count(marker) == 1
    content = content.replace(marker, marker + '\n    if (name == "carrier") return inference_program_carrier_case::run(kind);\n    if (name == "packet") return inference_mtp_packet_case::run(kind);')
    source.write_text(content, encoding='utf-8')
    consumers['natural'].update(source=str(source), compile=s.relocated(consumers['natural']['compile'], 'natural', source))
    names = ('runner', 'ds', 'ds-original', 'ds-early', 'glm', 'glm-early', 'glm-flash', 'kimi')
    for name in names:
        unit = models['units'][name]
        consumers[name] = dict(source=unit['source'], compile=s.relocated(unit['compile'], name), kind='gtest')
    # Use the current Source-enabled Kimi recipe as well as the current SDK.
    consumers['kimi']['compile'] = s.relocated(kimi['units']['kimi']['compile'], 'kimi')
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    ordinary = W / 'ordinary-input'
    ordinary.mkdir(exist_ok=True)
    for name in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(OLD / 'ordinary-input' / name, ordinary / name)
    cases = {name: dict(unit='cli', args=prior['cases'][name][1:])
             for name in ('single-auto', 'recursive', 'threshold', 'restore')}
    cases.update(natural=dict(unit='natural', args=prior['cases']['natural'][1:]),
        batch=dict(unit='natural', args=prior['cases']['batch'][1:]),
        group=dict(unit='natural', args=['group', 'cuda', prior['cases']['batch'][-1]]),
        carrier_cpu=dict(unit='natural', args=['carrier', 'cpu', prior['cases']['batch'][-1]]),
        carrier_cuda=dict(unit='natural', args=['carrier', 'cuda', prior['cases']['batch'][-1]]),
        packet_cpu=dict(unit='natural', args=['packet', 'cpu', prior['cases']['batch'][-1]]),
        packet_cuda=dict(unit='natural', args=['packet', 'cuda', prior['cases']['batch'][-1]]),
        ordinary=dict(unit='ordinary', args=['--cuda-continuous', str(ordinary)]))
    for name in ('runner-cpu', 'ds-pro-cpu', 'ds-flash-cpu', 'ds-early-cuda', 'glm-cuda', 'glm-early-cuda', 'glm-flash-cuda'):
        cases[name] = models['cases'][name]
    cases['kimi-cuda'] = {**kimi['cases']['kimi-cuda'], 'env': 'kimi'}
    environments = models['environments']
    environments['kimi'] = kimi['environment']
    save(W / 'plan.json', dict(base=pin(OLD / 'model-link-base.json'), base_commit='61bb37a51',
        units={}, consumers=consumers, retained=base['retained'], candidate_retained=base['retained'],
        runtime=base['runtime'], original_link=base['link'],
        original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        old_cli=base['current_consumers']['cli']['object'], cases=cases, environments=environments,
        sdk_engine_dependencies=base['sdk_engine_dependencies'], sdk_compiles=0, nvcc_compiles=0,
        downloads=0, scope='Cold exact input schema; original Graph metadata/owner checks and native retirement remain authoritative.'))
    print('Prepared11 current consumer TUs,227 retained SDK objects; no SDK/NVCC/download.', flush=True)


def compile_group(attempt, names):
    errors = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs = {pool.submit(s.compile_one, name, attempt): name for name in names}
        for future in as_completed(jobs):
            try:
                future.result()
            except BaseException as error:
                errors.append(dict(unit=jobs[future], error=str(error)))
    save(W / ('compile-group-' + attempt + '-' + names[0] + '.json'), dict(names=names, max_concurrency=2, errors=errors))
    assert not errors, errors


def link(name, attempt):
    p = read(W / 'plan.json')
    members = ['ds', 'ds-original'] if name == 'ds' else [name]
    objects = [read(W / 'compile' / member / 'receipt.json')['object'] for member in members]
    for item in [*p['retained'], *objects]:
        exact(item)
    args = []
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']):
            args.extend(x['path'] for x in objects)
            continue
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                break
        args.append(arg)
    if p['consumers'][name]['kind'] == 'gtest':
        args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / x) for x in ('gtest_main.lib', 'gtest.lib'))
    s.b.execute(args, W / 'link' / name / attempt, 240)
    save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))


def run(name, attempt):
    p = read(W / 'plan.json')
    case = p['cases'][name]
    image = read(W / ('ready-' + case['unit'] + '.json'))
    exact(image)
    folder = W / 'runs' / name / attempt
    os.environ.update(p['environments'].get(case.get('env'), {}))
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
        HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS='0', HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS='0', HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS='0',
        HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0', HYLE_GLM_MLX_WAIT_FOR_EXPERTS='0', HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS='0',
        HYLE_DSPARK_PRO_FRONTIER_FILE=str(folder/'missing-pro.json'), HYLE_DSPARK_FLASH_FRONTIER_FILE=str(folder/'missing-flash.json'),
        HYLE_DSPARK_BFLOAT_FRONTIER_FILE=str(folder/'missing-bfloat.json'))
    save(folder / 'image.json', image)
    if 'filter' in case:
        s.b.execute([image['path'], '--gtest_color=no', '--gtest_fail_fast', '--gtest_filter=' + case['filter'],
            '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors', '0') == '0'
        assert not result.findall('.//skipped')
        report = dict(status='PASS', tests=case['tests'], failures=0, skipped=0,
            cases=[dict(name=t.get('classname') + '.' + t.get('name'), seconds=t.get('time')) for t in result.findall('.//testcase')])
    else:
        s.b.execute([image['path'], *case['args']], folder, 300)
        report = read(folder / 'stdout.log')
        if case['unit'] == 'cli':
            assert report['live_committed_versions'] == 0
            assert report['generated_tokens'] == (32 if name == 'restore' else 64)
        else:
            assert report['status'] == 'PASS'
    save(folder / 'report.json', report)
    print('PASS', name, flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
    elif action == 'compile':
        s.compile_one(*sys.argv[2:])
    elif action == 'compile-group':
        compile_group(sys.argv[2], sys.argv[3:])
    elif action == 'link':
        link(*sys.argv[2:])
    elif action == 'link-selected':
        for name in sys.argv[3:]:
            link(name, sys.argv[2])
    elif action == 'run':
        run(*sys.argv[2:])
    elif action == 'run-selected':
        for name in sys.argv[3:]:
            run(name, sys.argv[2])
    else:
        raise ValueError(action)
