"""Offline finite correctness evidence; never builds or runs a consumer."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
F = W/'refinement2'
DEST = R/'docs/evidence/correctness/inference-varlen-verify-2026-10-29'
spec = importlib.util.spec_from_file_location('varlen_package_reader',W/'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
CASES = {'varlen-cpu': 'cpu','varlen-cuda': 'cuda','mixed-cuda': 'cuda','ragged-cpu': 'cpu'}


def encode(value): return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def sha(body): return hashlib.sha256(body).hexdigest()
def terminal(process, exit=0):
    assert process['state'] == 'TERMINAL' and process['exit'] == exit and not process['timed_out'],process


def main():
    outjson,outzip = DEST.with_suffix('.json'),DEST.with_suffix('.zip')
    assert not outjson.exists() and not outzip.exists(),'Preserve any existing evidence'
    plan,frozen,compiled,ready = map(t.read,(F/'plan.json',F/'source-freeze.json',F/'compile/tiny/compiled.json',F/'ready-tiny.json'))
    pins = {t.key(row['path']):row for row in frozen}
    dependencies = {t.key(row['path']):row for row in compiled['project_dependencies']}
    assert len(frozen) == len(dependencies) == 222 and pins == dependencies
    cxx,link = t.read(F/'logs/compile-tiny/process.json'),t.read(F/'logs/link-tiny/process.json')
    terminal(cxx); terminal(link)
    assert compiled['process'] == cxx and ready['compiled'] == compiled and ready['process'] == link
    assert t.read(F/'logs/compile-tiny/command.json')['command'] == plan['compile']
    assert t.read(F/'logs/link-tiny/command.json')['command'] == plan['link']
    assert len(plan['retained']) == 227 and ready['inputs'] == plan['retained']+[compiled['object']]
    assert len(ready['inputs']) == len({t.key(row['path']) for row in ready['inputs']}) == 228
    t.exact(ready['source_freeze']); t.exact(plan['fixture']); t.exact(plan['prompt'])
    archive,events,attempts,cases,states = {},[],[],[],[]

    def add(path,name=None):
        path = Path(path); name = name or 'validation/'+path.relative_to(W).as_posix()
        assert name not in archive and path.name.casefold() != 'environment.json'
        assert path.suffix.lower() not in ('.exe','.obj','.dll','.lib','.pdb','.bin','.bf16','.f32','.gguf','.safetensors')
        archive[name] = path.read_bytes()

    def logs(folder):
        for filename in ('command.json','process.json','running.json','stdout.log','stderr.log'):
            path = folder/filename
            if path.exists(): add(path)
        events.append(dict(record=folder.relative_to(W).as_posix(),process=t.read(folder/'process.json')))

    for relative in ('package.py','build.py','refine.py','refine2.py'): add(W/relative)
    for stage,exit in (('',2),('refinement',2),('refinement2',0)):
        directory = W/stage; stage_plan = t.read(directory/'plan.json')
        process = t.read(directory/'logs/compile-tiny/process.json'); terminal(process,exit)
        assert t.read(directory/'logs/compile-tiny/command.json')['command'] == stage_plan['compile']
        add(directory/'plan.json'); add(directory/'source-freeze.json'); logs(directory/'logs/compile-tiny')
        if exit:
            assert not (directory/'ready-tiny.json').exists() and not (directory/'logs/link-tiny').exists() and not (directory/'runs').exists()
        attempts.append(dict(stage=stage or 'initial',process=process,linked=exit == 0,model_run=exit == 0,
            source_freeze=t.pin(directory/'source-freeze.json'),
            failed_main_body_included=False if exit else None))
        dependency_file = directory/'compile/tiny/dependencies.json'
        if dependency_file.exists(): add(dependency_file)
    for relative in ('compile/tiny/compiled.json','ready-tiny.json'): add(F/relative)
    logs(F/'logs/link-tiny')
    for row in frozen:
        t.exact(row)
        add(row['path'],'source/'+Path(row['path']).relative_to(R).as_posix())
    for row in plan['helpers']:
        t.exact(row)
        if t.key(row['path']) != t.key(W/'build.py'):
            add(row['path'],'helpers/'+Path(row['path']).relative_to(R).as_posix())
    t.exact(plan['base']); add(plan['base']['path'],'inherited/model-link-base.json')
    sdk_evidence = R/'docs/evidence/correctness/inference-packed-gdn-prefixes-2026-10-29.json'
    inherited_evidence = t.pin(sdk_evidence)
    for name,backend in CASES.items():
        directory = F/'runs'/name; process = t.read(directory/'process.json'); terminal(process)
        report = t.read(directory/'report.json')
        raw = [json.loads(line) for line in (directory/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert report['status'] == 'PASS' and report['backend'] == backend and report['performance_claim'] is False
        assert report['synthetic_untrained'] is True and report['final_versions'] == 0
        if name.startswith('varlen-'):
            host = t.read(directory/'host-report.json'); assert raw == [host,report]
            assert host['case'] == 'packed-prefix-rows' and host['status'] == 'PASS' and host['models'] == 0
            assert report['mode'] == 'mtp_varlen_verify' and report['length_orders'] == [[1,3],[3,1],[1,3]]
            assert report['controlled_accepted'] == [[1,2],[3,1]]
            assert (report['target_submissions'],report['bounded_target_submissions']) == (11,3)
            assert report['natural_processed_target'] == [1,3] and report['natural_processed_draft'] == [2,4]
            assert report['natural_rng_draws'] == [1,5] and report['natural_proposal_rows'] == [0,2]
            for field in ('old_checkpoints_unchanged','accepted_prefixes_1_2_3','fixed_carrier_reused',
                          'engine_unequal_lengths_one_submission','original_q_identity_and_release','natural_R1_results_equal'):
                assert report[field] is True,field
            assert report['full_request_history_import_coverage'] is False and report['quality_claim'] is False
            rows = report['state_checks']; assert len(rows) == 6
            add(directory/'host-report.json')
        elif name == 'mixed-cuda':
            assert raw == [report] and report['mode'] == 'mtp_mixed_lag'
            assert (report['target_submissions'],report['mixed_target_submissions']) == (13,2)
            rows = report['state_checks']; assert len(rows) == 6
        else:
            assert raw == [report] and report['mode'] == 'mtp_ragged_prefill' and len(report['batches']) == 7
            rows = [member['state'] for batch in report['batches'] for member in batch['members']]; assert len(rows) == 14
        b.b.check_states(report,rows); states.extend(rows)
        facts = {key:value for key,value in report.items() if not isinstance(value,(dict,list))}
        facts['state_comparisons'] = len(rows)
        if name.startswith('varlen-'):
            for key in ('natural_processed_target','natural_processed_draft','natural_rng_draws'): facts[key] = report[key]
        cases.append(dict(name=name,process=process,facts=facts,report=t.pin(directory/'report.json')))
        logs(directory); add(directory/'report.json')
    assert len(states) == 32 and len({(case['process']['pid'],case['process']['started']) for case in cases}) == 4
    for filename,row in (('weights.tsv',plan['fixture']),('prompt.ids',plan['prompt'])):
        add(row['path'],'fixture/'+filename)
    archive['fixture/identity.json'] = encode(dict(manifest=plan['fixture'],prompt=plan['prompt'],payloads_included=False))
    manifest = encode([dict(name=name,bytes=len(body),sha256=sha(body)) for name,body in sorted(archive.items())])
    archive['MANIFEST.json'] = manifest
    outzip.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(outzip,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,body in sorted(archive.items()): z.writestr(name,body)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name,body in archive.items(): assert sha(z.read(name)) == sha(body),name
    exact = sum(row['payloads_byte_equal'] for row in states)
    differences = [part for row in states for part in row['differences']]
    result = dict(schema='hyle.correctness.varlen-verify.v1',date='2026-10-29',status='PASS_FOUR_FINITE_CASES',
        change='Bounded physical Verify3 uses actual per-member Li1/Li3, explicit legal prefix state and original sampled-q/RNG/retirement contracts.',
        counts=dict(CXX_attempts=3,successful_CXX=1,failed_CXX=2,successful_links=1,finite_native_processes=4,
                    SDK_CXX=0,NVCC=0,downloads=0,inherited_SDK_inputs=227,final_consumer_inputs=228,actual_project_source_dependencies=222),
        build=dict(attempts=attempts,successful_link=link,source=compiled['source'],image=ready['image'],
                   final_main=pins[t.key(R/'engine/models/qwen35/main.cc')],source_freeze=t.pin(F/'source-freeze.json'),
                   inherited_SDK_evidence=inherited_evidence),
        checks=dict(complete_state_comparisons=len(states),payload_byte_exact=exact,
                    comparisons_with_GDN_rounding=len(states)-exact,GDN_absolute_budget=3e-6,
                    maximum_observed_GDN_absolute_difference=max((part['maximum_absolute'] for part in differences),default=0)),
        cases=cases,recorded_processes=events,
        limits=['Four finite CPU/CUDA synthetic GA C16 processes; complete reports/raw diagnostics and host selector checks are in the archive.',
                'GDN state alone admits the existing absolute 3e-6 budget; other complete state payloads/boundaries and retained snapshots remain exact. This is not an all-byte-exact claim.',
                'Initial and refinement compiler failures are preserved, never linked or run. Their main source bodies were not saved; their frozen identities and original diagnostics remain. Final successful 222 project sources are included verbatim.',
                'Final Tiny is compiled once successfully against 227 inherited current SDK inputs; the earlier SDK build is referenced, not counted or recopied here.',
                'No trained quality, complete RequestLoop/history import, device-accept successor, cross-platform or performance conclusion. No environment values, SDK binaries, weights or tensor payloads are archived.'],
        archive=dict(**t.pin(outzip),members=len(archive),manifest_sha256=sha(manifest),CRC='PASS',member_SHA256='PASS'))
    with outjson.open('xb') as out: out.write(encode(result))
    assert t.read(outjson)['checks']['complete_state_comparisons'] == 32
    receipt = dict(JSON=t.pin(outjson),ZIP=t.pin(outzip),members=len(archive),CRC='PASS',member_SHA256='PASS')
    t.save(W/'package-readback.json',receipt); print(json.dumps(receipt,ensure_ascii=False))


if __name__ == '__main__': main()
