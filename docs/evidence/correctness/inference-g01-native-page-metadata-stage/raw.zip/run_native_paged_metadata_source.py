from pathlib import Path
import json, subprocess, time, os, psutil

root = Path.cwd()
folder = root / '.scratch/inference-gaps/g01/native-paged'
folder.mkdir(parents=True, exist_ok=True)
folder.mkdir(exist_ok=True)
build = root / '.scratch/build-compute-v2-dev'
record = folder / 'metadata-source-result.json'
rows = json.loads(record.read_text(encoding='utf-8'))['stages'] if record.exists() else []
print('NP01 bounded source metadata gate; native math not yet implemented', flush=True)
hook = folder / 'metadata-project.cmake'
body = '''if(PROJECT_NAME STREQUAL "hyle")
 if(NOT TARGET GTest::gtest_main)
  set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
  add_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-native-paged-gtest EXCLUDE_FROM_ALL)
 endif()
 function(g01_native_metadata_source)
  add_executable(g01_native_metadata_tests "''' + (root / 'tests/compute_batch/native_paged_metadata_test.cc').as_posix() + '''")
  target_compile_features(g01_native_metadata_tests PRIVATE cxx_std_23)
  target_compile_options(g01_native_metadata_tests PRIVATE /W4 /WX /wd4324 /utf-8)
  target_link_libraries(g01_native_metadata_tests PRIVATE hyle::compute GTest::gtest_main)
  hyle_stage_runtime(g01_native_metadata_tests)
 endfunction()
 cmake_language(DEFER CALL g01_native_metadata_source)
endif()
'''
hook.write_text(body, encoding='utf-8')
env = os.environ.copy()
for line in subprocess.check_output(['cmd', '/d', '/c', str(root / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key] = value

def run(stage, args):
    number = 1 + sum(row['stage'] == stage for row in rows)
    log = folder / f'metadata-source-{stage}-{number}.log'
    start = time.monotonic()
    with log.open('w', encoding='utf-8') as output:
        result = subprocess.run(args, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = {'stage': stage, 'command': args, 'exit_code': result.returncode,
           'elapsed_seconds': time.monotonic() - start, 'log': str(log)}
    rows.append(row)
    record.write_text(json.dumps({'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                                 'phase': 'AUDITED NP01 compact metadata draft', 'stages': rows}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(row), flush=True)
    if result.returncode:
        with log.open('rb') as data:
            data.seek(max(0, log.stat().st_size - 3200))
            print(data.read().decode('utf-8', errors='replace'), flush=True)
        raise SystemExit(result.returncode)

run('configure', ['cmake', '-S', str(root), '-B', str(build), '-DCMAKE_PROJECT_INCLUDE=' + str(hook)])
run('build', ['cmake', '--build', str(build), '--target', 'g01_native_metadata_tests', '--parallel', '4'])
run('run', [str(build / 'bin/g01_native_metadata_tests.exe')])
