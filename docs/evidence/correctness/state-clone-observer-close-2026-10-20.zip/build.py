"""Refresh the actual three CPU header owners in old/new header configurations."""
import concurrent.futures
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('observer_build_helpers', A/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'checks'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
inventory = c.read(S/'cpu-owner-inventory.json')
base = c.read(inventory['base_path'])
assert {Path(row['owner']['source_path']).name for row in inventory['owners']} == {
    'state_versions.cc', 'state_versions_test.cc', 'state_clone_test.cc'}
frozen = []
freeze = c.read(S/'source-freeze.json')
for row in freeze['files']:
    frozen += [row['before'], row['current'], row['frozen']]
frozen += freeze['unchanged_owner_context']
rows = []
for arm in ('before', 'after'):
    for row in inventory['owners']:
        source = Path(row['owner']['source_path'])
        tag = arm+'-'+source.stem
        command = b.host_command(row['owner']['command'], source, tag, out)
        if arm == 'before':
            command.insert(1, '/I'+str(S/'before/include'))
        rows.append(dict(arm=arm, tag=tag, source=b.identity(source), command=command,
            object=str(out/(tag+'.obj')), old_object=row['old_object']))
plan = dict(compile=rows, frozen=frozen, links={}, base=inventory['base_path'],
    actual_header_owners=3, host_TUs=6, native_TUs=0, SDK_rebuild=False)
c.save(out/'plan.json', plan)
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))

def check():
    for row in frozen:
        assert b.same(row), row['path']

def compile_one(row):
    check()
    prior_path = out/(row['tag']+'-identity.json')
    if prior_path.exists():
        prior = c.read(prior_path)
        if prior['command']==row['command'] and b.same(prior['object']) and all(b.same(dep) for dep in prior['dependencies']):
            print('REUSE', row['tag'], flush=True)
            return row['tag'], prior
    c.execute(row['tag']+'-compile', row['command'], env, out)
    check()
    dep = c.read(out/(row['tag']+'-deps.json'))['Data']
    actual_header = S/'before/include/hyle/compute/state_clone.h' if row['arm']=='before' else S.parents[2]/'include/hyle/compute/state_clone.h'
    assert c.key(actual_header) in {c.key(p) for p in dep['Includes']}
    receipt = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
        dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])])
    c.save(out/(row['tag']+'-identity.json'), receipt)
    return row['tag'], receipt

for row in base['inputs']:
    assert b.same(row), row['path']
finished, errors = {}, []
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in concurrent.futures.as_completed([pool.submit(compile_one, row) for row in rows]):
        try:
            tag, result = future.result()
            finished[tag] = result
        except Exception as error:
            errors.append(repr(error))
c.save(out/'compile-summary.json', dict(passed=not errors, errors=errors))
assert not errors, errors
for arm in ('before', 'after'):
    replacements = {c.key(row['old_object']['path']): finished[row['tag']]['object'] for row in rows if row['arm']==arm}
    lookup = {c.key(row['path']): row for row in base['inputs']}
    lookup.update({c.key(row['path']): row for row in replacements.values()})
    command = [replacements.get(c.key(arg), {}).get('path', arg) for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = out/(arm+'.exe')
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs = [lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
    assert len(inputs)==len({c.key(row['path']) for row in inputs})
    for row in inputs:
        assert b.same(row), row['path']
    check()
    c.execute(arm+'-link', command, env, out)
    link = dict(command=command, inputs=inputs)
    c.save(out/(arm+'-link-plan.json'), link)
    c.save(out/(arm+'-image.json'), b.identity(image))
    plan['links'][arm] = dict(**link, image=str(image))
c.save(out/'plan.json', plan)
c.save(out/'summary.json', dict(passed=True, host_TUs=6, native_TUs=0, SDK_rebuild=False,
    actual_header_owners=3, before_header_selected_in_all3_actual_dependency_files=True))
print('STATE_OBSERVER_BUILT', flush=True)
