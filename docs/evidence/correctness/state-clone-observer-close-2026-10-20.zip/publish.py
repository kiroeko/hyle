"""Archive the actual observer-close before/after witness without build payloads."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def identity(path):
    path = Path(path).resolve()
    payload = path.read_bytes()
    return {"path": str(path), "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest()}

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

freeze = read(S / "source-freeze.json")
for row in freeze["files"]:
    current = identity(ROOT / row["relative"])
    frozen = identity(Path(row["frozen"]["path"]))
    assert current["sha256"] == row["current"]["sha256"] == frozen["sha256"]
    assert identity(Path(row["before"]["path"]))["sha256"] == row["before"]["sha256"]

# Preserve the other two actual compiler owners alongside the changed header
# and test. The StateWriter extent fix remains in this current source closure.
context = []
for row in freeze["unchanged_owner_context"]:
    source = Path(row["path"])
    assert identity(source)["sha256"] == row["sha256"]
    target = S / "source" / "context" / source.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    context.append({"source": identity(source), "snapshot": identity(target)})
save(S / "archive-context.json", context)

build = read(S / "checks/summary.json")
plan = read(S / "checks/plan.json")
tests = read(S / "tests/summary.json")
assert build["passed"] and build["actual_header_owners"] == 3
assert build["host_TUs"] == 6 and build["native_TUs"] == 0 and not build["SDK_rebuild"]
assert len(plan["compile"]) == 6
assert tests["passed"] and tests["arms"]["before"]["expected_red"]
assert tests["arms"]["before"]["cases"] == 1
assert tests["arms"]["after"]["cases"] == 33
assert tests["arms"]["after"]["skipped"] == 0
assert read(S / "tests/before/tests.result.json")["exit"] == 1
assert read(S / "tests/after/tests.result.json")["exit"] == 0

# Inspect original compiler dependency receipts, not merely a selected include
# flag. Every actual owner in the red arm must select the exact old header.
header_witnesses = []
for row in plan["compile"]:
    tag, arm = row["tag"], row["arm"]
    expected = (S / "before/include/hyle/compute/state_clone.h" if arm == "before"
                else ROOT / "include/hyle/compute/state_clone.h").resolve()
    deps_path = S / "checks" / (tag + "-deps.json")
    receipt_path = S / "checks" / (tag + "-identity.json")
    deps = read(deps_path)["Data"]["Includes"]
    actual = [Path(p).resolve() for p in deps if Path(p).name.lower() == "state_clone.h"]
    assert len(actual) == 1 and str(actual[0]).casefold() == str(expected).casefold()
    receipt = read(receipt_path)
    retained = [r for r in receipt["dependencies"]
                if Path(r["path"]).name.lower() == "state_clone.h"]
    assert len(retained) == 1 and retained[0]["sha256"] == identity(expected)["sha256"]
    header_witnesses.append({"arm": arm, "owner": row["source"],
                             "selected_header": retained[0],
                             "compiler_dependencies": identity(deps_path),
                             "object_receipt": identity(receipt_path)})
save(S / "actual-header-witnesses.json", header_witnesses)

failed = read(S / "checks/initial-compile-failure/compile-summary.json")
assert not failed["passed"] and len(failed["errors"]) == 2
assert (S / "first-test-compile-failure/source-freeze.json").is_file()
for arm in ("before", "after"):
    log = S / "checks/initial-compile-failure" / (arm + "-state_clone_test-compile.stdout.log")
    assert "C2445" in log.read_text(encoding="utf-8", errors="replace")

archive_path = ROOT / "docs/evidence/correctness/state-clone-observer-close-2026-10-20.zip"
assert not archive_path.exists(), "Do not overwrite an already sealed archive"
allowed = {".py", ".h", ".cc", ".json", ".log", ".xml", ".diff", ".ps1"}
files = sorted(p for p in S.rglob("*") if p.is_file()
               and p.suffix.lower() in allowed
               and not any(part.lower() == "tmp" or part.lower().startswith("cleanup")
                           for part in p.relative_to(S).parts))
rows = []
with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        row = identity(path)
        row["member"] = path.relative_to(S).as_posix()
        rows.append(row)
        archive.writestr(row["member"], path.read_bytes())
    archive.writestr("payload-sha256.json", json.dumps(rows, indent=2))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in rows:
        payload = archive.read(row["member"])
        assert len(payload) == row["bytes"]
        assert hashlib.sha256(payload).hexdigest() == row["sha256"]

body = {
    "date": "2026-10-20",
    "scope": "One TypedStateCopy explicit-observer exclusion defect in common StateClone cancellation/close/retirement.",
    "defect": "CloneTicket::wait pins a slot under the StateStore monitor then waits outside that monitor. Old cancel/close could concurrently inspect/cancel/close the same original thread-compatible F2 handles; collect inspected them before checking observers.",
    "fix": "Keep logical abandoned/disabled/closed changes under the existing monitor, reject native access while an observer is present, and clean up after it leaves. Existing wait_lock still serializes explicit waits. No hidden close wait, deferred-action queue, new API, production hook or alternate executor.",
    "actual_witness": {
        "before": "Freshly compiled old header plus new transparent actual-CPU-copy regression exits1 as expected; both cancel and close branches record4 forbidden accesses. The wrapper withholds those accesses to avoid native UB.",
        "after": "The fixed header passes33 StateVersions/StateClone cases with zero skips. Gate notification proves actual observer pinning; close/cancel return before release; join, retirement, cold rearm, copied16-byte contents and retained old state are checked.",
        "build": build,
        "header_witnesses": header_witnesses,
        "initial_failure": "Two first test-TU attempts failed MSVC C2445 due Status/ErrorProxy conditional-expression ambiguity; the exact failed test/freeze/diff and compiler logs are retained. Only that conditional changed to explicit if/else; four successful owner objects were reused and two test TUs recompiled.",
    },
    "freeze": freeze,
    "independent_source_review": read(S / "independent-source-review.json"),
    "test_design": read(S / "test-design.json"),
    "actual_tests": tests,
    "next_candidate": {
        "status": "source_review_only_not_reproduced_or_fixed",
        "record": "next-slot-episode-review.json in the archive",
        "issue": "Retained old failed Ticket/Draft may still target a reused native route-slot episode after actual retirement and explicit cold rearm. Audit old wait as well as cancellation/destruction separately.",
    },
    "archive": identity(archive_path),
    "payloads": rows,
    "archive_verified": {"CRC": True, "all_payload_SHA256": True},
    "limits": [
        "Actual Windows CPU source/header before-after only; no CUDA/Vulkan/Apple native run, model run, GPU profiling or throughput experiment for this batch.",
        "Original CPU payload copy is synchronous; the deterministic test-only boundary blocks the explicit host observation, not pending GPU work.",
        "Idle-slot observer start/rearm guards are source-reviewed and are not directly produced by the current public CPU regression.",
        "Current CPU/CUDA/Vulkan in_flight reads atomic pending; the actual current defect concerns concurrent mutable Completion/native control observation. Consistent observer-first native access also preserves the generic thread-compatible contract.",
        "This closes one concrete race; neither all State lifetime behavior nor the broad inference-architecture goal is declared complete.",
        "No binary/object/library/map payloads and no cleanup receipts/scripts are archived. No files were deleted by publishing."
    ],
}
save(archive_path.with_suffix(".json"), body)
print(json.dumps({"archive": identity(archive_path), "payloads": len(rows),
                  "CRC": True, "all_payload_SHA256": True}, indent=2))
