"""Deterministic forbidden-access red, then the complete State CPU neighbors."""
import importlib.util
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('observer_test_helpers', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'tests'
out.mkdir(exist_ok=False)
results = {}
for arm, filters in [('before', 'StateClone.ExplicitObserverExcludesNativeCancellationCollectionAndClose'),
                     ('after', 'StateVersions.*:StateClone.*')]:
    destination = out/arm
    destination.mkdir()
    (destination/'tmp').mkdir()
    image = c.read(S/'checks'/(arm+'-image.json'))
    assert b.same(image)
    link = c.read(S/'checks'/(arm+'-link-plan.json'))
    env, runtime = b.environment(link['command'], [row['path'] for row in link['inputs']], destination)
    c.save(destination/'inputs.json', dict(image=image, filters=filters, runtime=runtime))
    try:
        c.execute('tests', [image['path'], '--gtest_filter='+filters,
            '--gtest_output=xml:'+str(destination/'results.xml')], env, destination)
    except RuntimeError:
        assert arm=='before' and c.read(destination/'tests.result.json')['exit']==1
    cases = ET.parse(destination/'results.xml').findall('.//testcase')
    failures = [dict(name=row.attrib['classname']+'.'+row.attrib['name'], details=[f.text for f in row.findall('failure')])
        for row in cases if row.find('failure') is not None]
    skipped = sum(row.find('skipped') is not None for row in cases)
    expected = 1 if arm=='before' else sum(len(re.findall(r'TEST\(\s*'+suite+r'\s*,', (S.parents[2]/path).read_text(encoding='utf-8')))
        for suite, path in [('StateVersions', 'tests/compute_state/state_versions_test.cc'), ('StateClone', 'tests/compute_state/state_clone_test.cc')])
    passed = len(cases)==expected and skipped==0 and (len(failures)==1 if arm=='before' else not failures)
    result = dict(passed=passed, expected_red=arm=='before', cases=len(cases), expected_cases=expected,
        skipped=skipped, failures=failures, actual=[row.attrib['classname']+'.'+row.attrib['name'] for row in cases])
    c.save(destination/'summary.json', result)
    assert passed, result
    results[arm] = result
c.save(out/'summary.json', dict(passed=True, arms=results, GPU_run=False, model_run=False,
    limits='Actual CPU copy with a deterministic test-only observation boundary; original header red and fixed header33 related cases. Not a claim of all native/cross-platform journey coverage.'))
print('STATE_OBSERVER_RED_GREEN', results['after']['cases'], flush=True)
