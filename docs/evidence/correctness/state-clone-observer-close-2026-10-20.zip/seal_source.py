from pathlib import Path
import difflib
import hashlib
import json
import shutil

root = Path(__file__).resolve().parents[3]
stage = Path(__file__).resolve().parent
paths = [
    "include/hyle/compute/state_clone.h",
    "tests/compute_state/state_clone_test.cc",
]

def identity(path):
    payload = path.read_bytes()
    return {"path": str(path), "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest()}

rows = []
diffs = []
for relative in paths:
    before = stage / "before" / relative
    current = root / relative
    frozen = stage / "source" / relative
    frozen.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(current, frozen)
    rows.append({"relative": relative, "before": identity(before),
                 "current": identity(current), "frozen": identity(frozen)})
    diffs.extend(difflib.unified_diff(
        before.read_text(encoding="utf-8").splitlines(keepends=True),
        current.read_text(encoding="utf-8").splitlines(keepends=True),
        fromfile="a/" + relative, tofile="b/" + relative))
(stage / "product-changes.diff").write_text("".join(diffs), encoding="utf-8")

design = {
    "test": "StateClone.ExplicitObserverExcludesNativeCancellationCollectionAndClose",
    "status": "source_only_not_compiled_or_run_by_agent",
    "real_execution": "Original CPU CopyBatchProgram/CopyBatchInvocation/CopyBatchSubmission perform every copy, binding, output publication, completion and retirement.",
    "boundary": "Transparent test forwarding wrapper gates only Submission::wait. Its entered notification happens after CloneTicket::take has incremented slot.observers under the StateStore monitor.",
    "determinism": "The test thread waits for that original route wait callback, then runs cancel/close, collect, report, rearm and attempted slot reuse before releasing the callback. No thread-start flag, timeout, poll count or native data race is the failure oracle.",
    "old_header_failure": "The wrapper records and withholds any overlapping native handle access. The old cancel path reads Submission::valid and calls request_cancel; close also calls Invocation::close; collect/rearm call Invocation::in_flight before checking observers. forbidden_accesses must remain zero.",
    "branches": [
        "StateDraft::cancel while its distinct CloneTicket is in wait: candidate remains cancelled; slot cannot be reused; after wait exits, drop old controls, collect, explicitly cold rearm and copy/publish another 16-byte state with old state retained.",
        "StateStore::close while CloneTicket is in wait: close returns Unavailable before gate release, closes admission, preserves existing base; after wait exits no writer is returned, controls drop, collect retires and drain succeeds.",
    ],
    "limits": [
        "CPU payload copy itself is synchronous and has already run; the gate deterministically exercises the public explicit-observer lifetime, not native GPU pending duration.",
        "Wrapper guards avoid executing undefined concurrent native Completion access in the expected-red arm.",
        "No production test hook, new public API, native executor or alternate copy implementation.",
        "No CUDA/Vulkan/Apple claim from this CPU source-only handoff.",
        "Existing failure controls are dropped before cold rearm; stale route-slot generation handling is a separate reported candidate, not part of this change.",
    ],
}
(stage / "test-design.json").write_text(json.dumps(design, indent=2) + "\n", encoding="utf-8")
freeze = {
    "status": "source_frozen_not_compiled_or_tested_by_agent",
    "scope": "One TypedStateCopy observer exclusion fix; no other product source edits.",
    "files": rows,
    "diff": identity(stage / "product-changes.diff"),
    "test_design": identity(stage / "test-design.json"),
    "unchanged_owner_context": [identity(root / p) for p in [
        "src/compute_state/state_versions.cc", "tests/compute_state/state_versions_test.cc"]],
    "entry_point_review": {
        "start": "Observer check precedes live/disabled and every native bind/prepare/submit.",
        "take_cleanup_report": "Existing observer check already precedes native handle inspection; preserved.",
        "cancel": "Records abandoned/disabled first, then returns Unavailable for an observer before Submission::valid/request_cancel.",
        "collect": "Observer check precedes Invocation::in_flight and cleanup.",
        "close": "Permanently closes route admission; observed slot records logical cancellation and never touches original Invocation::close or waits for it.",
        "rearm": "Observer check precedes replacing a disabled original Invocation. No deferred-action queue or added native flags.",
        "wait_drain": "Original explicit waits retain their existing wait_lock and observer admission; no new store-lock wait.",
    },
}
(stage / "source-freeze.json").write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"source_freeze": identity(stage / "source-freeze.json"),
                  "files": [row["current"] for row in rows]}, indent=2))
