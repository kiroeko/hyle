$ErrorActionPreference = 'Stop'
$r2Repo = 'C:\public\project-hyle\hyle'
$r2Scratch = 'C:\hyle-scratch\r2-q4-20260916'
Set-Location -LiteralPath $r2Repo
$r2Vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$r2Vs = & $r2Vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $r2Vs) { throw 'MSVC installation missing' }
$r2Dev = Join-Path $r2Vs 'Common7\Tools\VsDevCmd.bat'
$r2Command = 'call "' + $r2Dev + '" -arch=x64 >nul && set'
$r2Environment = & $env:ComSpec /d /s /c $r2Command
if ($LASTEXITCODE -ne 0) { throw 'MSVC initialization failed' }
foreach ($r2Line in $r2Environment) {
    $r2Split = $r2Line.IndexOf('=')
    if ($r2Split -le 0) { continue }
    $r2Name = $r2Line.Substring(0, $r2Split)
    $r2Value = $r2Line.Substring($r2Split + 1)
    if ($r2Name -ieq 'Path' -and $r2Value -notlike "*$r2Vs\VC\Tools\MSVC\*") { continue }
    [Environment]::SetEnvironmentVariable($r2Name, $r2Value, 'Process')
}

$env:HYLE_BENCH_VENDOR_DIR = 'C:/public/project-hyle'
python -X utf8 scripts/hyle-perf.py qualify-platform --contract bench/contracts/graph-cpu-route-p1-v1.json --machine W1-WIN --peer hyle-native-mlp=C:/hyle-scratch/r3-cpu-20260916/candidate-d9712e68 --peer onednn-direct-gated-mlp=C:/hyle-scratch/onednn-71094df45190 --source C:/hyle-scratch/r3-cpu-20260916/candidate-d9712e68 --build C:/hyle-scratch/r3-cpu-20260916/p1-graph-correction-build --output C:/hyle-scratch/r3-cpu-20260916/p1-graph-correction *> C:/hyle-scratch/r3-cpu-20260916/p1-graph-correction-run.log
Get-Content C:/hyle-scratch/r3-cpu-20260916/p1-graph-correction-run.log -Tail 40
exit $LASTEXITCODE
