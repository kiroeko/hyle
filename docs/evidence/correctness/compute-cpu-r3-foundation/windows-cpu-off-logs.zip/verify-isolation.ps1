. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$r3Root = 'C:/hyle-scratch/r3-cpu-20260916'
$r3Source = "$r3Root/candidate-d9712e68"
$r3Build = "$r3Root/isolation-source"
function Invoke-R3([string]$Name, [scriptblock]$Action) {
  & $Action *> "$r3Root/$Name.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$r3Root/$Name.log" -Tail 45; exit $LASTEXITCODE }
}
Invoke-R3 isolation-configure { cmake -S "$r3Root/isolation-consumer" -B $r3Build -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DHYLE_COMPUTE_ONEDNN=AUTO -DCMAKE_DISABLE_FIND_PACKAGE_CUDAToolkit=TRUE "-DHYLE_SOURCE_DIR=$r3Source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3Source" }
Invoke-R3 isolation-build { cmake --build $r3Build --parallel 2 }
Invoke-R3 isolation-source-test { ctest --test-dir $r3Build --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 }
$r3Sdk = "$r3Root/isolation-sdk"
Invoke-R3 isolation-install { cmake --install $r3Build --prefix $r3Sdk }
$r3Exports = Get-Content "$r3Sdk/lib/cmake/Hyle/HyleTargets.cmake" -Raw
foreach ($r3Header in @('compute/cpu.h','graph/cpu.h','compute/backends/cpu.h','compute/providers/native.h','compute/providers/onednn.h','graph/providers/onednn.h')) {
  if (Test-Path -LiteralPath "$r3Sdk/include/hyle/$r3Header") { throw "CPU OFF header leaked: $r3Header" }
}
foreach ($r3Factor in @('compute_route_cpu','graph_route_cpu','compute_backend_cpu','compute_provider_native','compute_provider_onednn','graph_provider_onednn')) {
  if ($r3Exports.Contains("_factor_$r3Factor")) { throw "CPU OFF export leaked: $r3Factor" }
}
'CPU OFF new route headers and all CPU implementation exports absent' | Set-Content "$r3Root/isolation-exports.log"
Invoke-R3 isolation-consumer-configure { cmake -S "$r3Root/isolation-consumer" -B "$r3Root/isolation-installed-consumer" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$r3Sdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3Source" }
Invoke-R3 isolation-consumer-build { cmake --build "$r3Root/isolation-installed-consumer" --parallel 2 }
Invoke-R3 isolation-consumer-test { ctest --test-dir "$r3Root/isolation-installed-consumer" --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 }
cmake -S "$r3Root/isolation-consumer" -B "$r3Root/isolation-contradiction" -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DHYLE_COMPUTE_ONEDNN=ON "-DHYLE_SOURCE_DIR=$r3Source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3Source" *> "$r3Root/isolation-contradiction.log"
if ($LASTEXITCODE -eq 0) { throw 'Contradictory oneDNN ON was accepted' }
if (-not (Select-String -Path "$r3Root/isolation-contradiction.log" -SimpleMatch 'HYLE_COMPUTE_ONEDNN=ON requires HYLE_COMPUTE_CPU=ON')) { throw 'Unexpected contradiction diagnostic' }
Get-Content "$r3Root/isolation-source-test.log" -Tail 6
Get-Content "$r3Root/isolation-consumer-test.log" -Tail 6
Get-Content "$r3Root/isolation-exports.log"
'CPU OFF / oneDNN ON rejected with required diagnostic'
exit 0
