from pathlib import Path
import itertools,json,os,re,statistics,subprocess,sys,hashlib
sys.path.insert(0,'C:/public/project-hyle/hyle/scripts')
from hyle_perf.runner import _apply_sampling_policy
from hyle_perf import sampling_mutex,load_registry,get_machine_profile,probe_machine
from hyle_perf.nanobench import parse_nanobench
root=Path(__file__).resolve().parent
exe=root/'parallel-aa-diagnostic.exe'
raw=root/'raw'
raw.mkdir(exist_ok=False)
results=[]
profile=get_machine_profile(load_registry(),'W1-WIN')
conditions=[('low-latency',2),('low-latency',4)]
with sampling_mutex(profile) as lease:
    host=probe_machine(paths=[('diagnostic',root)])
    (root/'host-probe.json').write_text(json.dumps(host,indent=2)+'\n',encoding='utf-8')
    selected=[row for row in host['scheduler']['cpu_sets'] if row['logical_processor_index'] in (0,2,4)]
    assert len(selected)==3 and all(row['efficiency_class']==host['scheduler']['maximum_efficiency_class'] for row in selected)
    for block,(peer_first,allocation_first) in enumerate(itertools.product((False,True),repeat=2)):
        for idle,caller in conditions[block:]+conditions[:block]:
            env={k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_'))}
            mask=hex((1<<caller)|(1<<0)|(1<<2))
            env.update({'HYLE_BENCH_AA_ROUTE':'selected','HYLE_BENCH_DIAGNOSTIC_IDLE':idle,
                'HYLE_PERF_CALLER_CPU':str(caller),'HYLE_PERF_WORKER_CPUS':'0,2',
                'HYLE_PERF_SAMPLING_TOPOLOGY':'diagnostic-caller-placement',
                'HYLE_PERF_PARENT_MASK':mask,'HYLE_PERF_PRIORITY':'above-normal',
                'MKL_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1','OMP_NUM_THREADS':'1',
                'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'})
            if peer_first:env['HYLE_BENCH_RIVAL_FIRST']='1'
            if allocation_first:env['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'
            name=f'{len(results)+1:02}-{idle}-caller{caller}-order{int(peer_first)}-allocation{int(allocation_first)}'
            with _apply_sampling_policy({'affinity_mask':mask}):
                run=subprocess.run([str(exe)],cwd=root,env=env,capture_output=True,text=True,
                    encoding='utf-8',errors='replace',timeout=120,creationflags=0x8000)
            output=run.stdout+run.stderr
            (raw/(name+'.log')).write_text(output,encoding='utf-8')
            if run.returncode:raise RuntimeError(f'{name}: exit {run.returncode}; stop without retry')
            expected=[f'idle={idle}',f'caller_cpu={caller}','worker_cpus=0,2','affinity_ok=1',
                      'aa_route=selected',f'parent_mask={mask}']
            if any(x not in output for x in expected):raise RuntimeError(f'{name}: missing telemetry')
            rows=parse_nanobench(output)
            data=[]
            for (title,label),row in rows.items():
                peer_prefix={'graph oneDNN MLP abstraction ':'direct fused oneDNN region ',
                             'graph oneDNN MLP region benefit ':'direct sequential oneDNN operations ',
                             'graph CPU default versus Native ':'HYLE Graph explicit Native '}
                if not label.startswith('HYLE Graph oneDNN region '):continue
                prefix=next(p for p in peer_prefix if title.startswith(p))
                peer_name=peer_prefix[prefix]+title[len(prefix):]
                peer=rows[(title,peer_name)]
                data.append({'title':title,'candidate_ns':1e9/row.operations_per_second,
                             'peer_ns':1e9/peer.operations_per_second,
                             'ratio':row.operations_per_second/peer.operations_per_second})
            rounds=[]
            for match in re.finditer(r'# HYLE_DIAGNOSTIC_ROUND title="([^"\n]+)" name="([^"\n]+)" round=(\d+) ns=([^ ]+) iters=([^\n]+)',output):
                rounds.append({'title':match[1],'name':match[2],'round':int(match[3]),'ns':float(match[4]),'iterations':float(match[5])})
            result={'name':name,'idle':idle,'caller_cpu':caller,'peer_first':peer_first,
                    'peer_allocation_first':allocation_first,'rows':data,'rounds':rounds}
            results.append(result)
            (root/'results.json').write_text(json.dumps({'qualification':'DIAGNOSTIC',
                'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'runs':results},indent=2)+'\n',encoding='utf-8')
            print(name,'completed',flush=True)
    print('DIAGNOSTIC ONLY: completed frozen 8-process budget; no product verdict')
