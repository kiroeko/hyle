#!/usr/bin/env bash
set -euo pipefail
r3_root=/root/hyle-validation/r3-cpu-20260916
r3_source="$r3_root/source-79e96ceb"
r3_logs="$r3_root/logs-d9712e68"
cd "$r3_source"
for kind in asan ubsan tsan; do
  r3_build="$r3_root/source-shared"
  mkdir -p "$r3_logs/$kind"
  bash scripts/hyle-unix.sh cmake -S "$r3_root/consumer" -B "$r3_build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DHYLE_WERROR=ON \
    "-DHYLE_SOURCE_DIR=$r3_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3_source" \
    -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_COMPUTE_ONEDNN=AUTO \
    -DHYLE_COMPUTE_CUDA=OFF -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF \
    -DHYLE_INSTALL=OFF "-DHYLE_SANITIZER=$kind" \
    >"$r3_logs/$kind/configure.log" 2>&1 || {
      tail -n 50 "$r3_logs/$kind/configure.log"; exit 1;
    }
  cmake --build "$r3_build" --parallel 2 --target hyle_compute_route_cpu_test \
    hyle_graph_route_cpu_test hyle_graph_route_cpu_cpu_executor_test \
    >"$r3_logs/$kind/build.log" 2>&1 || {
      tail -n 55 "$r3_logs/$kind/build.log"; exit 1;
    }
  command=(ctest --test-dir "$r3_build" --output-on-failure --no-tests=error
    -R '^hyle_(compute_route_cpu_test|graph_route_cpu_test|graph_route_cpu_cpu_executor_test)$')
  if [ "$kind" = tsan ]; then
    command=(setarch "$(uname -m)" -R "${command[@]}")
  fi
  "${command[@]}" >"$r3_logs/$kind/tests.log" 2>&1 || {
    tail -n 65 "$r3_logs/$kind/tests.log"; exit 1;
  }
  cp "$r3_build/CMakeCache.txt" "$r3_logs/$kind/CMakeCache.txt"
  cp "$r3_build/Testing/Temporary/LastTest.log" "$r3_logs/$kind/last-test.log"
  tail -n 12 "$r3_logs/$kind/tests.log"
done
