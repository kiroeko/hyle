"""Exact layer43 plans from one new header plus the existing layer44 header53."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    cached = read(S / 'cached-roles.json')
    requested = read(S / 'headers/summary.json')
    assert requested['complete'] and not requested['whole_shards_downloaded'] and len(requested['shards']) == 1
    reused_path = R / '.scratch/glm-original-target44-20261023/headers/model-00053-of-00062/receipt.json'
    receipts = [requested['shards'][0], read(reused_path)]
    assert [row['file'] for row in receipts] == ['model-00052-of-00062.safetensors', 'model-00053-of-00062.safetensors']
    shards, headers = [], []
    for source in receipts:
        assert source['complete'] and source['repository'] == cached['repository']
        assert source['revision'] == cached['revision']
        assert identity(R / source['header']['path']) == source['header']
        assert identity(R / source['length_prefix']['path']) == source['length_prefix']
        raw = (R / source['header']['path']).read_bytes()
        assert source['data_base'] == 8 + len(raw)
        shards.append({key: source[key] for key in ('file', 'url', 'etag', 'whole_file_bytes', 'data_base', 'header')})
        headers.append(json.loads(raw))
    shard_ids = {row['file']: i for i, row in enumerate(shards)}
    audit = {row['name']: row for row in cached['roles']}

    def role(name):
        previous = audit[name]
        shard_index = shard_ids[previous['shard']]
        exact = headers[shard_index][name]
        for key in ('dtype', 'shape', 'data_offsets'):
            assert exact[key] == previous[key], (name, key)
        first, end = exact['data_offsets']
        base = shards[shard_index]['data_base']
        return dict(name=name, dtype=exact['dtype'], shape=exact['shape'], bytes=end-first,
                    source_shard=shard_index, data_relative_half_open=[first, end],
                    absolute_inclusive=[base+first, base+end-1])

    # The immutable catalog geometry/order is the same as BP, but every byte
    # range and future body/catalog pin belongs to the distinct original43.
    bp = read(R / '.scratch/glm-original-moe-20261023/roles-plan.json')
    moe = []
    for ordinal, previous in enumerate(bp['roles']):
        row = role(previous['name'].replace('.layers.45.', '.layers.43.'))
        assert row['dtype'] == previous['dtype'] and row['shape'] == previous['shape']
        assert row['bytes'] == previous['bytes'] and previous['ordinal'] == ordinal
        row['ordinal'] = ordinal
        moe.append(row)
    assert len(moe) == 1736 and sum(row['bytes'] for row in moe) == 7277059200
    groups = []
    for index in (0, 1):
        for row in sorted((row for row in moe if row['source_shard'] == index), key=lambda row: row['absolute_inclusive'][0]):
            first, last = row['absolute_inclusive']
            if groups and groups[-1]['source_shard'] == index and groups[-1]['last'] + 1 == first:
                group = groups[-1]
                group['last'] = last; group['bytes'] += row['bytes']; group['roles'].append(row['ordinal'])
            else:
                groups.append(dict(source_shard=index, first=first, last=last, bytes=row['bytes'], roles=[row['ordinal']]))
    offset = 0
    for index, group in enumerate(groups):
        group.update(index=index, bundle_offset=offset)
        assert group['last'] - group['first'] + 1 == group['bytes']
        for ordinal in group['roles']:
            row = moe[ordinal]
            row['bundle_offset'] = offset + row['absolute_inclusive'][0] - group['first']
        offset += group['bytes']
    assert offset == 7277059200
    provenance = dict(repository=cached['repository'], revision=cached['revision'],
                      header_receipt=identity(S / 'headers/summary.json'), reused_header53_receipt=identity(reused_path),
                      cached_audit_extract=identity(S / 'cached-roles.json'))
    save(S / 'roles-plan.json', dict(**provenance, original_roles=1736, bundle_bytes=offset,
         shards=shards, roles=moe, groups=groups, layer=43, output_directory='original-moe',
         typed_order='router,bias,shared gate/up/down code/SF; expert0..287 each gate/up/down code/SF',
         whole_shards_downloaded=False, unrequested_bytes=0))

    prefix = 'model.language_model.layers.43.'
    static = []
    own = [('hc_attn_base', 'hc_attn_base.f32'), ('hc_attn_fn', 'hc_attn_fn.bf16'),
           ('hc_attn_scale', 'hc_attn_scale.f32'), ('hc_ffn_base', 'hc_ffn_base.f32'),
           ('hc_ffn_fn', 'hc_ffn_fn.bf16'), ('hc_ffn_scale', 'hc_ffn_scale.f32'),
           ('input_layernorm.weight', 'input_layernorm.weight.bf16'),
           ('self_attn.q_a_proj.weight', 'q_a.weight.e4m3'),
           ('self_attn.q_a_proj.weight_scale_inv', 'q_a.weight_scale.f32'),
           ('self_attn.q_a_layernorm.weight', 'q_a_layernorm.weight.bf16')]
    for suffix, filename in own:
        row = role(prefix + suffix)
        row.update(filename=filename, component='HC/inputnorm/q_a/q_aNorm')
        static.append(row)
    assert len(static) == 10 and sum(row['bytes'] for row in static) == 7877336
    attention = read(R / '.scratch/glm-original-attention-20261023/roles-plan.json')
    for previous in attention['roles']:
        row = role(previous['name'].replace('.layers.45.', '.layers.43.'))
        row.update(filename=previous['filename'], component='Original attention9 reused typed loader with explicit43 pins')
        static.append(row)
    assert len(static) == 19 and sum(row['bytes'] for row in static[10:]) == 127958528
    indexer_names = ('index_kpool_compress_ape', 'index_kpool_compress_gate', 'k_norm.bias',
                     'k_norm.weight', 'weights_proj.weight', 'wk.weight', 'wq_b.weight')
    for suffix in indexer_names:
        row = role(prefix + 'self_attn.indexer.' + suffix)
        row.update(filename=suffix + '.bf16', component='Original indexer7 reused typed loader with explicit43 pins')
        static.append(row)
    assert len(static) == 26 and sum(row['bytes'] for row in static[19:]) == 14943744
    assert sum(row['bytes'] for row in static) == 150779608
    assert len({row['name'] for row in static+moe}) == 1762
    assert {row['name'] for row in static+moe} == audit.keys()
    assert len({row['filename'] for row in static}) == 26
    for ordinal, row in enumerate(static):
        row['ordinal'] = ordinal
    save(S / 'static-plan.json', dict(**provenance, layer=43, original_roles=26,
         expected_role_payload_bytes=150779608, shards=shards, roles=static,
         output_directory='original-target43', whole_shards_downloaded=False))
    save(S / 'plan-summary.json', dict(**provenance, layer43_roles=1762, layer43_bytes=7427838808,
         moe_roles=1736, moe_bytes=7277059200, static_roles=26, static_bytes=150779608,
         static_groups=dict(hc_input_qa=dict(roles=10,bytes=7877336),attention=dict(roles=9,bytes=127958528),indexer=dict(roles=7,bytes=14943744)),
         source_shards=shards, moe_range_groups=len(groups),
         plans=[identity(S / 'roles-plan.json'), identity(S / 'static-plan.json')],
         no_download_by_metadata_agent=True, no_native=True,
         reuse='Reuse raw header53 in its BT location, existing loader/math/state infrastructure and shared fullV banks. Original43 payloads/pins remain distinct from44/45. No final model.norm belongs to43; its output is BF16 four-stream mHC for44.',
         pending='Actual root response/payload/catalog SHA must authenticate bodies; metadata/header identities alone are not payload receipts.'))
    print(json.dumps(dict(roles=1762, bytes=7427838808, moe_roles=1736, moe_groups=len(groups), static_roles=26, static_bytes=150779608)))


if __name__ == '__main__':
    main()
