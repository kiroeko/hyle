"""Verify published BU evidence and record only its actual completed scope."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def verify(row):
    path = Path(row['path'])
    path = path if path.is_absolute() else R / path
    assert path.stat().st_size == row['bytes']
    with path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']
    return path


publication = read(S / 'publication.json')
for item in publication.values():
    verify(item)
evidence = read(R / publication['evidence']['path'])
assert evidence['stage'] == 'BU' and evidence['goal_complete'] is False
validation = evidence['validation']
runs = [read(verify(row)) for row in validation['results']]
assert sum(run['tests'] for run in runs) == validation['tests'] == 4
assert all(run['process']['exit'] == 0 and not run['process']['timed_out'] for run in runs)
assert not any(run[key] for run in runs for key in ('failures', 'errors', 'disabled', 'skips'))
assert sum(int(case['properties']['actual_submissions']) for run in runs for case in run['cases']) == validation['graph_submissions']
assert all(receipt['complete'] for receipt in evidence['artifact']['acquisitions'])
with zipfile.ZipFile(R / publication['archive']['path']) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        path = Path(name)
        assert path.suffix.lower() not in {'.exe', '.obj', '.lib', '.dll', '.bf16', '.f32', '.e4m3'}
        if path.suffix.lower() == '.bin':
            assert path.name == 'catalog.bin' and archive.getinfo(name).file_size == 27840
before = read(S / 'before.json')
protected = before['protected_qwen_image']
verify(protected.get('image', protected))
text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest() == before['protected_performance_tail_sha256']
progress = dict(utc=datetime.now(timezone.utc).isoformat(), stage='BU', stage_complete=True, goal_complete=False,
    previous_goal_turn_classification='no progress: prior status-only turn; current BU resumes and completes concrete original43 integration.',
    state='Distinct original43 HC/MLA/indexer/MoE now composes with original44/NextN/fullV K1; the listed focused native cases passed and durable evidence was published.',
    native_checks_run=True, tests=4, graph_submissions=validation['graph_submissions'], failures=0, skips=0,
    native_process_status='all included summary processes completed_exit0_not_timed_out',
    acquisition_state='both exact-range receipts complete', original_target43_roles=1762,
    original_target43_bytes=7427838808, publication=publication, new_TPS=False,
    physical_memory_peak=False, protected_AV_tail_unchanged=True,
    scope='Original43/44/NextN local continuation and actual fullV K1 decisions. Layer42 and finite initial prefix/history remain synthetic; no complete trained target, full-model task quality or natural acceptance-rate result.',
    next='Remaining confirmed artifact/verifier adapters including actual Pro geometry, necessary regressions and complete ordinary/MTP performance comparison before image projection. Goal remains incomplete.')
(S / 'progress.json').write_text(json.dumps(progress, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PUBLISHED BU', 4, 'cases', validation['graph_submissions'], 'Graphs; full MTP remains incomplete')
