"""Snapshot exact BU source inputs after authentic original43 pin fill."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
pins = json.loads((S / 'pins.json').read_text(encoding='utf-8'))
prior = json.loads((R / '.scratch/glm-original-target44-20261023/source-final/freeze.json').read_text(encoding='utf-8'))
names = [row['path'] for row in prior['source']]
names += ['tests/compute_models/' + name for name in (
    'glm_hyper_connection_fragment.h', 'glm_hyper_connection_reference.h',
    'glm_original_target43_roles.h', 'glm_original_target43_fragment.h',
    'glm_original_target43_reference.h')]
out = S / 'source-final'
out.mkdir(exist_ok=False)
sources = []
for name in dict.fromkeys(names):
    raw = (R / name).read_bytes()
    snapshot = out / 'frozen' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(raw)
    sources.append(dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), snapshot=snapshot.relative_to(R).as_posix()))
assert next(row for row in sources if row['path'] == pins['after']['path'])['sha256'] == pins['after']['sha256']
record = dict(stage='BU', scope='Exact source inputs after actual static26 and distinct MoE43 catalogue pins. No execution result implied.', source=sources)
(out / 'freeze.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print('FROZEN', len(sources), 'source inputs', flush=True)
