"""Make the shared sparse math consume its actual layer-owned parameters."""
from pathlib import Path

S=Path(__file__).resolve().parent
R=S.parents[1]
path=R/'tests/compute_models/glm_mtp_state_consumer_test.cc'
raw=path.read_bytes();text=raw.decode('utf-8').replace('\r\n','\n')
def once(old,new):
    global text
    assert text.count(old)==1,(old[:100],text.count(old))
    text=text.replace(old,new,1)

once('  original_attention::Data source;','  std::shared_ptr<const original_attention::Data> source;')
start=text.index('struct OriginalNextn final {');end=text.index('std::shared_ptr<const OriginalNextn> original_nextn',start)
block=text[start:end]
block=block.replace('  original_index::Data indexer;\n','').replace('  original_index::Roles indexer_roles;\n','')
block=block.replace('  std::shared_ptr<OriginalAttention> attention;','  std::shared_ptr<OriginalSparseLayer> sparse;')
layer='''struct OriginalSparseLayer final {
  std::shared_ptr<const original_index::Data> indexer;
  original_index::Roles indexer_roles;
  std::shared_ptr<OriginalAttention> attention;
};
'''
text=text[:start]+layer+block+text[end:]
once('  result->attention = std::move(attention);','  result->sparse=std::make_shared<OriginalSparseLayer>();\n  result->sparse->attention = std::move(attention);')
once('if(result->moe&&!result->attention)','if(result->moe&&!result->sparse->attention)')
once('if(result->attention&&!result->vocabulary)','if(result->sparse->attention&&!result->vocabulary)')
once('  result->indexer = original_index::Data::load(indexer);','  result->sparse->indexer=std::make_shared<const original_index::Data>(original_index::Data::load(indexer));')
once('  result->indexer_roles = original_index::bind(result->indexer, owner);','  result->sparse->indexer_roles = original_index::bind(*result->sparse->indexer, owner);')
once('  std::shared_ptr<const OriginalNextn> original;','  std::shared_ptr<const OriginalNextn> original;\n  std::shared_ptr<OriginalSparseLayer> sparse;\n  std::size_t sparse_hidden=std::numeric_limits<std::size_t>::max(),sparse_query=std::numeric_limits<std::size_t>::max();\n  bool attention_postnorm=false;')
text=text.replace('recipe.original->attention','recipe.sparse->attention')
text=text.replace('r.original->attention','r.sparse->attention')
text=text.replace('r.original->indexer_roles','r.sparse->indexer_roles')
text=text.replace('r.original->indexer.','r.sparse->indexer->')
text=text.replace('r.original->indexer;','*r.sparse->indexer;')
text=text.replace('original->attention','original->sparse->attention')
text=text.replace('original->indexer_roles','original->sparse->indexer_roles')
text=text.replace('original_index::payload(original->indexer,','original_index::payload(*original->sparse->indexer,')
once('bool has_original_attention(const Recipe &r) {return r.original&&bool(r.sparse->attention);}',
     'bool has_original_attention(const Recipe &r) {return r.sparse&&bool(r.sparse->attention);}')
assert text.count('  r.original = std::move(original);')==2
text=text.replace('  r.original = std::move(original);','  r.original = std::move(original);\n  if(r.original)r.sparse=r.original->sparse;')
once('    for (std::size_t i = 0; i < ports.size(); ++i) r.original_prefix_ports[i] = publish(ports[i], true);',
     '    for (std::size_t i = 0; i < ports.size(); ++i) r.original_prefix_ports[i] = publish(ports[i], true);\n    r.sparse_hidden=r.original_prefix_ports[4];r.sparse_query=r.original_prefix_ports[6];')
once('    r.attention_ports.postnorm_raw=publish(raw,true);','    r.attention_postnorm=true;\n    r.attention_ports.postnorm_raw=publish(raw,true);')

# Only layer-local sparse construction/observations lose the NextN identity.
for first,last in [('EncodedPool append_history','namespace target43 ='),
                   ('void observe_history','void observe_original_moe')]:
    begin=text.index(first);finish=text.index(last,begin)
    part=text[begin:finish].replace('if (r.original)', 'if (r.sparse)').replace('r.original ? external', 'r.sparse ? external')
    part=part.replace('if (role_offset != 0 || !original_qr)', 'if (!original_qr)')
    part=part.replace('original NextN query requires its same-Graph prefix', 'original sparse query requires its same-Graph layer producer')
    part=part.replace('r.original_prefix_ports[6]', 'r.sparse_query').replace('r.original_prefix_ports[4]', 'r.sparse_hidden')
    text=text[:begin]+part+text[finish:]
text=text.replace('const auto &data=r.sparse->attention->source;', 'const auto &data=*r.sparse->attention->source;')
text=text.replace('const auto &data=observed.source;', 'const auto &data=*observed.source;')
text=text.replace('r.sparse->attention->source.norm(', 'r.sparse->attention->source->norm(')
path.write_text(text,encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
print('REWIRED layer-local sparse parameter and observation sources; no execution claim')
