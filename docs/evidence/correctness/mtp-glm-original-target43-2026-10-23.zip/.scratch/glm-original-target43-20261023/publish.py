"""Publish completed BU original-target43 checks; never archive weight bodies.

Prepared before actual results. Root writes the final source freeze and runs
the selected new/related cases before invoking this script.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
NEW = 'OriginalTarget43And44AndNextNFullVocabularyVerifier'
RELATED = 'OriginalTarget44AndNextNFullVocabularyVerifier'
REPOSITORY = 'zai-org/GLM-5.3-Flash'
REVISION = 'eb9eb208eb0d988989d07a6a12d0fdeb5f52574a'
TEXT = {'.h', '.hh', '.hpp', '.c', '.cc', '.cpp', '.py', '.mjs', '.json',
        '.txt', '.log', '.xml', '.ps1', '.diff', '.rsp', '.cmd', '.md'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def identity(path):
    path = resolve(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path),
                bytes=path.stat().st_size, sha256=digest)


verified = {}


def verify(row):
    path = resolve(row['path'])
    if path not in verified:
        verified[path] = identity(path)
    actual = verified[path]
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']
    return path


def integer(properties, key):
    value = int(properties[key])
    assert value >= 0, (key, value)
    return value


def protect(before):
    protected = before['protected_qwen_image']
    protected = protected.get('image', protected)
    actual = identity(protected['path'])
    assert actual['bytes'] == protected['bytes'] and actual['sha256'] == protected['sha256']
    text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    tail = text[text.index('## 最新完整性能对比'):]
    digest = hashlib.sha256(tail.encode()).hexdigest()
    assert digest == before['protected_performance_tail_sha256']
    return digest


def acquisitions():
    """Validate small records/catalogs and extents, without another7GB hash."""
    plans = [read(S / 'static-plan.json'), read(S / 'roles-plan.json')]
    receipts = [read(S / 'original-target43/acquisition.json'), read(S / 'original-moe/acquisition.json')]
    for plan, receipt, count, size in zip(plans, receipts, (26, 1736), (150779608, 7277059200)):
        assert plan['repository'] == receipt['repository'] == REPOSITORY
        assert plan['revision'] == receipt['revision'] == REVISION
        assert plan['original_roles'] == receipt['original_roles'] == count
        assert receipt['complete'] and receipt['role_payload_bytes'] == size
        assert receipt['successful_request_body_bytes'] == size
        assert receipt['source_plan_sha256'] == identity(receipt['source_plan'])['sha256']
        assert not receipt.get('whole_shard_downloaded', receipt.get('whole_shards_downloaded', False))
        assert sum(row['bytes'] for row in plan['roles']) == size
        assert len(plan['roles']) == count
        for shard in plan['shards']:
            verify(shard['header'])
            raw = resolve(shard['header']['path']).read_bytes()
            assert shard['data_base'] == len(raw) + 8
            header = json.loads(raw)
            for row in plan['roles']:
                if plan['shards'][row['source_shard']] != shard:
                    continue
                exact = header[row['name']]
                assert exact['dtype'] == row['dtype'] and exact['shape'] == row['shape']
                assert exact['data_offsets'] == row['data_relative_half_open']
                first, end = exact['data_offsets']
                assert row['bytes'] == end - first
                assert row['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
    static, moe = receipts
    planned = {row['name']: row for row in plans[0]['roles']}
    assert len(static['roles']) == 26
    for row in static['roles']:
        expected = planned[row['name']]
        for key in ('filename', 'dtype', 'shape', 'bytes', 'data_relative_half_open', 'absolute_inclusive'):
            assert row[key] == expected[key], (row['name'], key)
        assert row['complete'] and row['payload']['bytes'] == row['bytes']
        assert resolve(row['payload']['path']).stat().st_size == row['bytes']
        assert len(row['payload']['sha256']) == 64
    assert moe['bundle']['bytes'] == 7277059200 and resolve(moe['bundle']['path']).stat().st_size == 7277059200
    assert len(moe['bundle']['sha256']) == 64
    catalog_path, typed_path = verify(moe['catalog']), verify(moe['typed_catalog'])
    catalog = read(catalog_path)
    assert catalog['repository'] == REPOSITORY and catalog['revision'] == REVISION
    assert catalog['original_roles'] == 1736 and len(catalog['roles']) == 1736
    assert catalog['bundle']['bytes'] == moe['bundle']['bytes']
    assert catalog['bundle']['sha256'] == moe['bundle']['sha256']
    index = typed_path.read_bytes()
    assert len(index) == 64 + 1736 * 16
    magic, version, count, size, reserved, digest = struct.unpack('<8sIIQQ32s', index[:64])
    assert (magic, version, count, size, reserved) == (b'HYGLMM01', 1, 1736, 7277059200, 0)
    assert digest.hex() == moe['bundle']['sha256']
    for ordinal, (planned_row, row) in enumerate(zip(plans[1]['roles'], catalog['roles'])):
        assert planned_row['ordinal'] == row['ordinal'] == ordinal
        for key in ('name', 'dtype', 'shape', 'bytes', 'source_shard', 'data_relative_half_open', 'absolute_inclusive', 'bundle_offset'):
            assert row[key] == planned_row[key], (ordinal, key)
        assert len(row['sha256']) == 64
        assert struct.unpack_from('<QQ', index, 64 + ordinal * 16) == (row['bundle_offset'], row['bytes'])
    assert len({row['name'] for plan in plans for row in plan['roles']}) == 1762
    assert sum(receipt['role_payload_bytes'] for receipt in receipts) == 7427838808
    assert sum(group['bytes'] for group in plans[1]['groups']) == 7277059200
    assert plans[1]['unrequested_bytes'] == 0
    # The actual passing native suppliers authenticate these original bodies
    # against their compiled pins. Publishing deliberately reuses that work.
    return receipts, typed_path, sorted({resolve(shard['header']['path']) for plan in plans for shard in plan['shards']})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=int, nargs='+', required=True)
    parser.add_argument('--link-attempt', type=int, required=True)
    parser.add_argument('--freeze', default='source-final')
    args = parser.parse_args()
    assert args.link_attempt > 0 and all(index > 0 for index in args.runs)
    assert len(set(args.runs)) == len(args.runs)
    summaries = [S / f'checks{index}/summary.json' for index in args.runs]
    runs = [read(path) for path in summaries]
    image = read(S / f'tests-link{args.link_attempt}/ready.json')['image']
    verify(image)
    for run in runs:
        assert run['image'] == image and run['process']['exit'] == 0 and not run['process']['timed_out']
        assert run['tests'] == len(run['cases'])
        assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
        assert run.get('throughput_evidence') is False and run.get('physical_memory_evidence') is False
        assert run.get('whole_original_model') is False
        for case in run['cases']:
            assert case['attributes'].get('status') == 'run' and case['attributes'].get('result') == 'completed'
    cases = [case for run in runs for case in run['cases']]
    new = [case for case in cases if case['attributes']['name'].endswith(NEW)]
    related = [case for case in cases if case['attributes']['name'].endswith(RELATED)]
    assert len(cases) == 4 and len(new) == len(related) == 2
    for pair, suffix in ((new, NEW), (related, RELATED)):
        assert {case['attributes']['name'] for case in pair} == {f'Cpu{suffix}', f'Cuda{suffix}'}
    for case in cases:
        props = case['properties']
        for key, expected in dict(full_original_nextn_roles='1762', full_original_nextn_source_bytes='10030953088',
            target_full_vocabulary='154880', target_first_full_reference_values='309760',
            target_verifier_submissions='3', natural_k1_trials='1', controlled_matching_trials='1', controlled_rejection_trials='1',
            original_target44_roles='1760', original_target44_source_bytes='7554137944',
            original_target44_expert_domain='288', original_target44_resident_experts='8').items():
            assert props[key] == expected, (case['attributes']['name'], key, props.get(key))
        assert integer(props, 'natural_k1_accepted_drafts') in (0, 1)
        assert integer(props, 'natural_k1_proposal') < 154880
        assert integer(props, 'accepted_zero_draft_checkpoints') > 0 and integer(props, 'accepted_one_draft_checkpoints') > 0
        assert integer(props, 'actual_pending_embedding_feedback_checks') > 0
        assert integer(props, 'peak_state_backing_bytes') <= integer(props, 'state_budget_bytes')
        assert integer(props, 'original_target44_observed_calls') == integer(props, 'target_submissions') > 0
        if case['attributes']['name'].startswith('Cuda'):
            assert props['target_verifier_head_provider'] == 'cublasLt'
    for case in new:
        props = case['properties']
        assert props['original_target43_roles'] == '1762' and props['original_target43_source_bytes'] == '7427838808'
        assert props['original_target43_expert_domain'] == '288' and props['original_target43_resident_experts'] == '8'
        assert integer(props, 'original_target43_observed_calls') == integer(props, 'target43_submissions') > 0
    for case in related:
        assert 'original_target43_roles' not in case['properties']
    new_graphs = sum(integer(case['properties'], 'actual_submissions') for case in new)
    related_graphs = sum(integer(case['properties'], 'actual_submissions') for case in related)
    assert new_graphs > 0 and related_graphs > 0
    # Both original MLA cold preparations and every actual ordinary Program
    # counter are already included by the native test. Never guess this sum.
    graphs = new_graphs + related_graphs

    freeze_path = S / args.freeze / 'freeze.json'
    freeze = read(freeze_path)
    frozen = {}
    for key in ('source', 'dependencies', 'fixed_dependencies', 'files'):
        for row in freeze.get(key, []):
            path = verify(row)
            assert path not in frozen or frozen[path]['sha256'] == row['sha256']
            frozen[path] = row
    required = {'glm_mtp_state_consumer_test.cc', 'glm_original_target43_fragment.h',
        'glm_original_target43_roles.h', 'glm_original_target43_reference.h',
        'glm_hyper_connection_fragment.h', 'glm_hyper_connection_reference.h',
        'glm_original_target44_fragment.h', 'glm_original_target44_reference.h'}
    assert required <= {path.name for path in frozen}
    link_path = S / f'tests-link{args.link_attempt}/link-plan.json'
    runtime_path = link_path.with_name('runtime-environment.json')
    link, runtime = read(link_path), read(runtime_path)
    assert all(link[key] == 0 for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
    for row in link['inputs']:
        verify(row)
    compiled_records = []
    for row in link['compiled_records']:
        path = verify(row)
        if path.is_relative_to(S):
            compiled = read(path)
            for item in (compiled['source'], compiled['object'], *compiled['dependencies']):
                verify(item)
            assert resolve(compiled['source']['path']) in frozen
            compiled_records.append(path)
    assert len(compiled_records) == 1
    for row in runtime['staged_dlls']:
        verify(row)
    receipts, catalog_metadata, raw_headers = acquisitions()
    for plan_path in (S / 'roles-plan.json', S / 'static-plan.json'):
        verify(read(plan_path)['reused_header53_receipt'])
    before = read(S / 'before.json')
    tail_hash = protect(before)
    sources = sorted(frozen)
    docs = [R / 'docs/developer/current-work.md', R / 'docs/implementation/model-operators.md']
    provenance = [R / 'docs/evidence/correctness/mtp-glm-original-target44-2026-10-23.json']
    for row in before['prior_publication'].values():
        verify(row)
    files = set(sources + docs + provenance + compiled_records + raw_headers + [catalog_metadata])
    files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in TEXT)
    files.discard(S / 'publication.json')
    for path in files:
        assert path.resolve().is_relative_to(R) and (path.suffix.lower() in TEXT or path == catalog_metadata), path
        assert path.stat().st_size < 10_000_000, path
    destination = D / 'mtp-glm-original-target43-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert D.is_dir() and not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(files):
            zipped.write(path, path.relative_to(R).as_posix())
    record = dict(date='2026-10-23', stage='BU', goal_complete=False,
        conclusion='Distinct original target43 HC/MLA/indexer/MoE now feeds original target44 and the original full-vocabulary K1 verifier/NextN complete-state journey on the listed CPU/CUDA cases.',
        artifact=dict(repository=REPOSITORY, revision=REVISION, original_target43_roles=1762,
            original_target43_source_bytes=7427838808, static_roles=26, static_bytes=150779608,
            moe_roles=1736, moe_bytes=7277059200,
            reused_original_target44_roles=1760, reused_original_target44_source_bytes=7554137944,
            reused_original_nextn_roles=1762, reused_original_nextn_source_bytes=10030953088,
            vocabulary=154880, hidden=4096, verifier_rows=2,
            acquisitions=receipts, weight_bodies_archived=False, extra_weight_hash_pass=False),
        implementation=dict(
            parameters='Original43 owns distinct HC6/inputnorm/q_a/q_aNorm10, MLA9(including postnorm), indexer7 and original288-domain MoE1736. The shared typed suppliers use explicit43 pins; their default45 identities and mathematics remain unchanged. Raw header53 is reused in its existing cache, with no duplicate shard body.',
            hc='The common graph and independent-reference HC helpers preserve the previously passed44 torch/unfused math and numerical gates. ActualBF16 four-stream residual -> rawF32dot/inverseRMS1e-5 -> HC/Sinkhorn1e-6 -> collapseBF16 -> learnedRMS -> BF16; post expansion returnsBF16. No TileLang fused-norm bit-equivalence claim.',
            sparse_attention='ActualHC-normalizedBF16 -> original q_a dynamicE4Divide/floor1e-10 -> BF16 -> actual q_aNorm; original same-geometry NoPEMLA and original7indexer use the layer-owned sparse views. Original O BF16 goes directly into HCpost; no NextN EH, duplicate residual/postnorm or synthetic projection is inserted.',
            ffn='FFNHC starts at actual attention-post four streams, original postnorm belongs after its collapse. Original43 MoE uses its own full288-domain top8 and boundedE8 code/scale/map supply. The final HCpost forwards fourBF16streams/exactF32carrier to44;43 has no final contraction/modelnorm.',
            reuse='Original44 KDA/HC/MoE/finalnorm and complete original45 NextN share the existing ordinary Graph/Program machinery, Context/resources and fullV154880 readonly head. Model-local common math replaces copied HC code; there is no new public operator or executor.',
            state='Existing joint34 resources plus Epoch remain one StateDraft/expected-base StateHead. Current43->44 actual leases produce target taps; K1 selects after-current first or after-proposal second and directly retains actual I32pending lease. Accepted seed, skip, journal/catchup and old-result ownership remain.',
            reference='Only new43 HC/q_a/q_aNorm local observers are added. Existing original-byte MLA/indexer/MoE/fullV observers are reused at actual predecessors. CommonHC extraction preserves original44 checks; no ideal activation crosses BF16, no wider tolerance and no extra native reference batches.',
            controls='One natural finite fixture per backend stays separate from one controlled match and one controlled reject, each with a recomputed actual second checkpoint. These controls do not constitute a natural acceptance-rate result.'),
        validation=dict(tests=4, failures=0, errors=0, skips=0, graph_submissions=graphs,
            new_graph_submissions=new_graphs, related_graph_submissions=related_graphs,
            new_cases=new, related_cases=related, results=[identity(path) for path in summaries],
            source_freeze=identity(freeze_path), linked_inputs=identity(link_path), runtime_cache=identity(runtime_path),
            compiled_records=[identity(path) for path in compiled_records], host_translation_units=1,
            host_compile_attempts=len(list(S.glob('compile*/*/plan.json'))),
            SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0),
        limitations=['Finite Windows CPU/CUDA Flash integration, not all inputs/systems/quantizations or Pro execution.',
            'Layer42 per-token four-stream input and finite initial prefix/history are explicit synthetic external boundaries; this is not the complete trained target engine or prompt-to-output task-quality proof.',
            'Local numerical/state checks and one natural fixture do not establish full-model quality or natural acceptance rates.',
            'HC follows the official torch/unfused branch; no universal equivalence to TileLang fused-norm rounding is asserted.',
            'No new loading/TPS or measured physical memory/VRAM peak. Protected AV comparison and Qwen executable are unchanged.',
            'MTP,image projection and the broader goal remain incomplete.'],
        remaining='Other confirmed applicable original target/artifact adapters including actual Pro geometry, necessary related regressions and complete ordinary/MTP performance comparison before image projection.',
        final_image=image, sources=[identity(path) for path in sources + docs],
        plans=[identity(S / 'roles-plan.json'), identity(S / 'static-plan.json')],
        raw_headers=[identity(path) for path in raw_headers], reused_provenance=[identity(path) for path in provenance],
        performance_tail_sha256=tail_hash, protected_qwen_image=before['protected_qwen_image'],
        archive=identity(archive), archive_items=len(files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert protect(before) == tail_hash
    print(json.dumps(dict(**publication, tests=4, graphs=graphs)))


if __name__ == '__main__':
    main()
