"""Acquire exact GLM layer43 MoE ranges once into one resumable compact bundle."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import struct
import time
import urllib.error
import urllib.request

S=Path(__file__).resolve().parent
R=S.parents[1]
CHUNK,IO=128*1024*1024,1024*1024
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha_file(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
plan_path=S/'roles-plan.json';plan=read(plan_path)
assert plan['original_roles']==1736 and plan['bundle_bytes']==7277059200
for shard in plan['shards']:
    raw=(R/shard['header']['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==shard['header']['sha256']
    header=json.loads(raw)
    for row in plan['roles']:
        if plan['shards'][row['source_shard']]!=shard:continue
        exact=header[row['name']]
        assert exact['dtype']==row['dtype'] and exact['shape']==row['shape']
        assert exact['data_offsets']==row['data_relative_half_open']
        first=shard['data_base']+exact['data_offsets'][0]
        assert row['absolute_inclusive']==[first,first+row['bytes']-1]
out=S/'original-moe';out.mkdir(exist_ok=True)
bundle=out/'roles.bin';receipt=out/'acquisition.json'
identity=dict(repository=plan['repository'],revision=plan['revision'],original_roles=1736,
    source_plan=plan_path.relative_to(R).as_posix(),source_plan_sha256=sha_file(plan_path),
    bundle_bytes=7277059200,whole_shards_downloaded=False,unrequested_bytes=0)
if receipt.exists():
    record=read(receipt)
    assert all(record[k]==v for k,v in identity.items())
else:
    assert not bundle.exists()
    record=dict(**identity,complete=False,chunk_bytes=CHUNK,stream_buffer_bytes=IO,
                requests=[],chunks=[],groups=plan['groups'],shards=plan['shards'])
def save():
    temporary=receipt.with_suffix('.json.next')
    with temporary.open('w',encoding='utf-8',newline='\n') as stream:
        json.dump(record,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,receipt)
offset=0
if bundle.exists():
    with bundle.open('rb') as stream:
        for part in record['chunks']:
            assert part['offset']==offset and 0<part['bytes']<=CHUNK
            remaining=part['bytes'];digest=hashlib.sha256()
            while remaining:
                data=stream.read(min(IO,remaining));assert data,'Truncated verified bundle prefix'
                digest.update(data);remaining-=len(data)
            assert digest.hexdigest()==part['sha256'],'Bundle prefix differs from receipt'
            offset+=part['bytes']
    assert offset<=bundle.stat().st_size<=min(plan['bundle_bytes'],offset+CHUNK)
else:assert not record['chunks'] and not record['complete']
if record['complete']:
    assert offset==bundle.stat().st_size==plan['bundle_bytes']
    assert sha_file(bundle)==record['bundle']['sha256']
    assert sha_file(out/'catalog.bin')==record['typed_catalog']['sha256']
    print('REUSED complete original MoE bundle',offset,flush=True)
    raise SystemExit(0)
save()
for group in plan['groups']:
    end=group['bundle_offset']+group['bytes']
    if offset>=end:continue
    assert group['bundle_offset']<=offset<end
    shard=plan['shards'][group['source_shard']]
    while offset<end:
        size=min(CHUNK,end-offset)
        first=group['first']+offset-group['bundle_offset'];last=first+size-1
        attempt=dict(group=group['index'],offset=offset,first=first,last=last,
                     requested_bytes=size,complete=False,started_utc=now())
        record['requests'].append(attempt);save()
        print('REQUEST',group['index'],offset,size,'/',plan['bundle_bytes'],flush=True)
        request=urllib.request.Request(shard['url'],headers={'Range':f'bytes={first}-{last}',
            'If-Range':shard['etag'],'Accept-Encoding':'identity','User-Agent':'hyle-original-role-consumer/1'})
        try:
            for retry in range(5):
                try:
                    response=urllib.request.urlopen(request,timeout=60);break
                except (urllib.error.URLError,TimeoutError,OSError) as error:
                    attempt.setdefault('transport_errors',[]).append(dict(type=type(error).__name__,error=str(error),utc=now()))
                    save()
                    if retry==4:raise
                    time.sleep(2)
            with response:
                expected=f'bytes {first}-{last}/{shard["whole_file_bytes"]}'
                assert response.status==206 and response.headers.get('Content-Range')==expected
                assert response.headers.get('ETag')==shard['etag']
                assert response.headers.get('Content-Length') in (None,str(size))
                assert response.headers.get('Content-Encoding') in (None,'identity')
                digest=hashlib.sha256()
                with bundle.open('r+b' if bundle.exists() else 'x+b') as stream:
                    stream.seek(offset);remaining=size
                    while remaining:
                        data=response.read(min(IO,remaining));assert data,'Early EOF'
                        digest.update(data);stream.write(data);remaining-=len(data)
                    assert not response.read(1),'Overlong range body'
                    stream.flush();os.fsync(stream.fileno())
            assert bundle.stat().st_size==offset+size
            part=dict(offset=offset,bytes=size,sha256=digest.hexdigest(),group=group['index'],
                      absolute_inclusive=[first,last])
            record['chunks'].append(part)
            attempt.update(complete=True,http_status=206,content_range=expected,etag=shard['etag'],
                           bytes=size,sha256=part['sha256'],finished_utc=now())
            offset+=size;save();print('VERIFIED',offset,'/',plan['bundle_bytes'],flush=True)
        except Exception as error:
            attempt.update(error_type=type(error).__name__,error=str(error),finished_utc=now());save();raise
assert offset==bundle.stat().st_size==plan['bundle_bytes']
print('HASH bundle and1736 original roles',flush=True)
bundle_sha=sha_file(bundle)
roles=[]
with bundle.open('rb') as stream:
    for row in plan['roles']:
        stream.seek(row['bundle_offset']);remaining=row['bytes'];digest=hashlib.sha256()
        while remaining:
            data=stream.read(min(IO,remaining));assert data
            digest.update(data);remaining-=len(data)
        roles.append(dict(**row,sha256=digest.hexdigest()))
catalog=dict(repository=plan['repository'],revision=plan['revision'],original_roles=1736,
    bundle=dict(file='roles.bin',bytes=offset,sha256=bundle_sha),roles=roles,
    typed_order='router,bias,shared gate/up/down code/SF; expert0..287 each gate/up/down code/SF')
(out/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
header=struct.pack('<8sIIQQ32s',b'HYGLMM01',1,1736,offset,0,bytes.fromhex(bundle_sha))
assert len(header)==64
index=header+b''.join(struct.pack('<QQ',row['bundle_offset'],row['bytes']) for row in roles)
assert len(index)==27840
(out/'catalog.bin').write_bytes(index)
record.update(complete=True,role_payload_bytes=offset,
    successful_request_body_bytes=sum(row['bytes'] for row in record['requests'] if row['complete']),
    bundle=dict(path=bundle.relative_to(R).as_posix(),bytes=offset,sha256=bundle_sha),
    catalog=dict(path=(out/'catalog.json').relative_to(R).as_posix(),bytes=(out/'catalog.json').stat().st_size,sha256=sha_file(out/'catalog.json')),
    typed_catalog=dict(path=(out/'catalog.bin').relative_to(R).as_posix(),bytes=len(index),sha256=hashlib.sha256(index).hexdigest()),finished_utc=now())
assert record['successful_request_body_bytes']==offset
save();print(json.dumps(dict(roles=1736,bundle=record['bundle'],typed_catalog=record['typed_catalog'])),flush=True)
