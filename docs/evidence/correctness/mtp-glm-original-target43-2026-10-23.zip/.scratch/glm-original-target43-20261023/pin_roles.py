"""Pin actual layer43 payloads after both authenticated acquisitions complete."""
from pathlib import Path
import hashlib
import json
import re

S = Path(__file__).resolve().parent
R = S.parents[1]
static = json.loads((S / 'original-target43/acquisition.json').read_text(encoding='utf-8'))
moe = json.loads((S / 'original-moe/acquisition.json').read_text(encoding='utf-8'))
assert static['complete'] and static['original_roles'] == 26
assert static['role_payload_bytes'] == static['successful_request_body_bytes'] == 150779608
assert moe['complete'] and moe['original_roles'] == 1736
assert moe['role_payload_bytes'] == moe['successful_request_body_bytes'] == 7277059200
rows = {row['filename']: row for row in static['roles']}
assert len(rows) == 26
for row in rows.values():
    assert row['complete'] and len(row['payload']['sha256']) == 64
    assert (R / row['payload']['path']).stat().st_size == row['bytes']
    assert row['name'].startswith('model.language_model.layers.43.')
header = R / 'tests/compute_models/glm_original_target43_roles.h'
payload = header.read_bytes()
text = payload.decode('utf-8')
before = dict(path=header.relative_to(R).as_posix(), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())
used = set()
own = re.findall(r'Spec\{"([^"]+)", "([^"]+)", ""', text)
assert len(own) == 10
for name, filename in own:
    row = rows[filename]
    assert row['name'] == name
    old = f'Spec{{"{name}", "{filename}", ""'
    assert text.count(old) == 1
    text = text.replace(old, f'Spec{{"{name}", "{filename}", "{row["payload"]["sha256"]}"', 1)
    used.add(filename)
attention_header = (R / 'tests/compute_models/glm_original_attention_roles.h').read_text(encoding='utf-8')
attention_files = re.findall(r'RawSpec\{"[^"]+", "([^"]+)"', attention_header)
assert len(attention_files) == 9
index_files = ['index_kpool_compress_ape.bf16', 'index_kpool_compress_gate.bf16',
               'k_norm.bias.bf16', 'k_norm.weight.bf16', 'weights_proj.weight.bf16',
               'wk.weight.bf16', 'wq_b.weight.bf16']
for type_name, name, filenames in [('attention', 'kAttentionSha256', attention_files),
                                    ('indexer', 'kIndexerSha256', index_files)]:
    marker = f'inline constexpr {type_name}::Pins {name}'
    pattern = re.escape(marker) + r'\{[^;]*\};'
    assert len(re.findall(pattern, text)) == 1
    pins = ',\n    '.join('"' + rows[filename]['payload']['sha256'] + '"' for filename in filenames)
    text = re.sub(pattern, marker + '{\n    ' + pins + '};', text, count=1)
    assert not used.intersection(filenames)
    used.update(filenames)
assert used == set(rows)
catalog = moe['typed_catalog']
assert hashlib.sha256((R / catalog['path']).read_bytes()).hexdigest() == catalog['sha256']
assert text.count('kMoeIndexSha256 = "";') == 1
text = text.replace('kMoeIndexSha256 = "";', f'kMoeIndexSha256 = "{catalog["sha256"]}";', 1)
text = text.replace('// Actual acquisition fills all pins. Empty pins fail before any role is mapped;',
                    '// Exact acquisition pins identify all original43 bodies; incomplete pins fail;')
header.write_bytes(text.encode('utf-8'))
final = header.read_bytes()
record = dict(before=before, after=dict(path=before['path'], bytes=len(final), sha256=hashlib.sha256(final).hexdigest()),
              original_static_pins=[dict(name=row['name'], payload=row['payload']) for row in rows.values()],
              original_moe_catalog_pin=catalog,
              scope='Actual distinct original43 pins only. Shared45 defaults and all math preserved. No body rehash for publication.')
(S / 'pins.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print('PINNED original43 static26 plus its distinct MoE catalogue', flush=True)
