"""Update two current MTP summaries from the published BU four-case evidence.

Prepared source only. Run after publish.py has authenticated and published the
actual results; this script neither builds nor runs inference or benchmarks.
"""
from pathlib import Path
import argparse
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
NEW = 'OriginalTarget43And44AndNextNFullVocabularyVerifier'
RELATED = 'OriginalTarget44AndNextNFullVocabularyVerifier'
EVIDENCE = 'mtp-glm-original-target43-2026-10-23.json'
LINK = f'../evidence/correctness/{EVIDENCE}'
BT_LINK = '../evidence/correctness/mtp-glm-original-target44-2026-10-23.json'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def once(text, old, new):
    count = text.count(old)
    assert count == 1, (old[:120], count)
    return text.replace(old, new, 1)


def replace_section(text, start, end, replacement):
    assert text.count(start) == text.count(end) == 1, (start, end)
    first = text.index(start)
    last = text.index(end, first)
    return text[:first] + replacement + text[last:]


def native_counts(publication):
    row = publication['evidence']
    path = resolve(row['path'])
    assert path == (R / 'docs/evidence/correctness' / EVIDENCE).resolve()
    assert path.stat().st_size == row['bytes'] < 10_000_000
    raw = path.read_bytes()  # Published JSON only; never weight bodies.
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    record = json.loads(raw)
    assert record['stage'] == 'BU' and record['goal_complete'] is False
    artifact = record['artifact']
    assert artifact['repository'] == 'zai-org/GLM-5.3-Flash'
    assert artifact['revision'] == 'eb9eb208eb0d988989d07a6a12d0fdeb5f52574a'
    assert artifact['original_target43_roles'] == 1762
    assert artifact['reused_original_target44_roles'] == 1760
    assert artifact['reused_original_nextn_roles'] == 1762
    assert artifact['vocabulary'] == 154880 and artifact['verifier_rows'] == 2
    validation = record['validation']
    assert validation['tests'] == 4
    assert not any(validation[key] for key in ('failures', 'errors', 'skips'))
    new, related = validation['new_cases'], validation['related_cases']
    for cases, suffix in ((new, NEW), (related, RELATED)):
        assert len(cases) == 2
        assert {case['attributes']['name'] for case in cases} == {f'Cpu{suffix}', f'Cuda{suffix}'}
        for case in cases:
            attrs = case['attributes']
            assert attrs['status'] == 'run' and attrs['result'] == 'completed'
            assert int(case['properties']['actual_submissions']) > 0
    new_graphs = sum(int(case['properties']['actual_submissions']) for case in new)
    related_graphs = sum(int(case['properties']['actual_submissions']) for case in related)
    graphs = new_graphs + related_graphs
    assert new_graphs == validation['new_graph_submissions']
    assert related_graphs == validation['related_graph_submissions']
    assert graphs == validation['graph_submissions']
    per_backend = {
        ('CPU' if case['attributes']['name'].startswith('Cpu') else 'CUDA'):
        int(case['properties']['actual_submissions']) for case in new
    }
    assert set(per_backend) == {'CPU', 'CUDA'}
    return record, new_graphs, related_graphs, graphs, per_backend


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publication', default=str(S / 'publication.json'))
    args = parser.parse_args()
    record, new_graphs, related_graphs, graphs, per_backend = native_counts(read(resolve(args.publication)))
    before = read(S / 'before.json')
    current_path = R / 'docs/developer/current-work.md'
    operators_path = R / 'docs/implementation/model-operators.md'
    current = current_path.read_text(encoding='utf-8-sig')
    operators = operators_path.read_text(encoding='utf-8-sig')
    marker = '## 最新完整性能对比'
    assert current.count(marker) == 1
    tail = current[current.index(marker):]
    tail_sha256 = hashlib.sha256(tail.encode('utf-8')).hexdigest()
    assert tail_sha256 == before['protected_performance_tail_sha256']
    assert tail_sha256 == record['performance_tail_sha256']

    counts = (
        f'CPU／CUDA新两项分别{per_backend["CPU"]}／{per_backend["CUDA"]}次Graph，合计{new_graphs}次；'
        f'原44验证链两项回归{related_graphs}次，共4项、{graphs}次，0失败／0跳过。'
    )
    current = once(current,
        'target44已接独立原参数；target43仍生成。DSpark',
        'target43／44已接各自独立原参数，沿真实全V pending和同Head续算。DSpark')
    current = once(current,
        'GLM已接原target44的HC／KDA／MoE及独立model.norm，沿同一原全词表verifier和34资源＋epoch接受流程；下一步替换target43生成参数，并接其它适用模型的producer／verifier、Pro实际几何与确认量化。',
        'GLM原43→44→NextN层尾已用各层独立原参数，沿原全词表verifier和34资源＋Epoch接受流程续算；下一步接其它适用模型的producer／verifier、Pro实际几何与已确认量化。')
    latest = (
        f'**最近已验证进展：** [GLM原43→44→NextN与K1续算]({LINK})已将第43层的HC、MLA／indexer和原288域MoE接入既有原44、原45与共享全V154880双行验证。各层使用独立原参数，真实BF16四流、末归一化tap和I32 pending租约沿同一34资源＋Epoch、StateDraft／StateHead接受并续算。共同HC构图／数值参考、层参数视图、一次冷KV准备及有界Top8专家供给复用现有Program／Invocation；EH仍只属于NextN。\n\n'
        + counts
        + '原字节局部参考、接受0／1、取消／旧结果、已接受journal追赶、epoch8 fresh seed→skip0均继续检查。layer42输入与有限初始历史仍是显式fixture；这不是完整训练模型的任务质量或真实任务接受率结论，也没有新TPS／物理显存峰。角色数不作为MTP完成比例。\n\n'
        f'前批[原target44]({BT_LINK})、[原全词表验证](../evidence/correctness/mtp-glm-target-verifier-2026-10-23.json)、[Q27原17角色](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)、[Q24原22角色](../evidence/correctness/mtp-q24-original-nextn-2026-10-23.json)及[DSpark原83角色](../evidence/correctness/mtp-dspark-original-experts-2026-10-23.json)的有效实现与证据保留。其它适用producer／verifier、Pro和已确认量化继续按实际身份接入，最后做普通／MTP完整性能对照；页末AV性能表不变。\n\n'
    )
    current = replace_section(current, '**最近已验证进展：**', '已取得的实际边界：', latest)
    current = once(current,
        f'[原target44]({BT_LINK})的1760角色及明确BF16／F32边界已进入同一全词表K1状态流程；target43参数、layer42输入和初始历史仍生成。原target43、Pro几何、其它量化及真实任务自然接受率未完成，',
        f'[原43→44→NextN]({LINK})已以各层独立原HC／attention／MoE参数连接原全词表K1、实际pending及同Head续算；layer42输入与有限初始历史仍是fixture。其它适用producer／verifier、Pro实际几何、已确认量化及真实任务自然接受率未完成，')
    current = once(current,
        'GLM原target44、原全词表verifier及完整K1状态已接；下一步原target43、其它适用producer／verifier、Pro几何与确认量化，',
        'GLM原43／44层尾、原全词表verifier及完整K1状态已接；下一步其它适用producer／verifier、Pro实际几何与已确认量化，')
    assert current[current.index(marker):] == tail
    assert 'target43仍生成' not in current and '下一步原target43' not in current

    operators = once(operators,
        f'[原target44的1760角色]({BT_LINK})已进入同一34资源＋epoch和K1流程；target43参数及初始历史仍生成，原target43、Pro几何和其它确认量化未完成',
        f'[原43→44→NextN]({LINK})已使用各层独立原参数、原全V154880验证和真实I32 pending，同一34资源＋Epoch接受／续算；layer42输入与有限初始历史仍是fixture，其它适用producer／verifier、Pro实际几何和已确认量化未完成')
    old_start = 'CPU／CUDA新旅程各49次Graph，'
    old_end = '\n\n## 正式版 DeepSeek：角色、存储与数值边界'
    latest_operators = (
        f'[原43→44→NextN的K1续算]({LINK})已接第43层独立HC、q_a／query norm、MLA／indexer和原288域MoE，向原44的KDA／conv／MoE及model.norm传递真实BF16四流，随后由原全V154880双行head验证并直接保留实际I32 pending租约。共同HC构图与数值参考保持既有torch／unfused顺序；层参数视图、只读owner、一次冷KV准备、有界专家供给及普通两阶段Graph共用，EH只在NextN外层。\n\n'
        + counts
        + '完整34资源＋Epoch按接受0／1同Head发布，已接受journal追赶、fresh seed→skip0、旧结果只读及取消继续检查。'
        f'前批[原target44]({BT_LINK})、[原全词表验证](../evidence/correctness/mtp-glm-target-verifier-2026-10-23.json)及[完整原NextN](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)保留历史依据。layer42输入与有限初始历史仍是fixture，不代签完整原模型、任务质量、真实任务自然接受率、TPS或物理显存峰。下一步是其它适用producer／verifier、Pro实际几何、已确认量化和最终普通／MTP性能对照。'
    )
    operators = replace_section(operators, old_start, old_end, latest_operators)
    operators = once(operators,
        '当前34资源组合及生成参数／原模型边界见[上方状态表](#续算状态与多会话接入)和[本轮证据](../evidence/correctness/mtp-encoded-state-2026-10-23.json)。',
        f'当前原43／44层尾与NextN的34资源＋Epoch组合及上游fixture边界见[上方状态表](#续算状态与多会话接入)和[本轮证据]({LINK})。')
    assert 'target43参数及初始历史仍生成' not in operators

    # All exact-count substitutions and AV-tail checks finish before either
    # document is written. No third document, evidence or source is modified.
    current_path.write_text(current, encoding='utf-8')
    operators_path.write_text(operators, encoding='utf-8')
    print(json.dumps(dict(updated=['docs/developer/current-work.md', 'docs/implementation/model-operators.md'],
        tests=4, new_graphs=new_graphs, related_graphs=related_graphs, graphs=graphs,
        protected_performance_tail_sha256=tail_sha256), ensure_ascii=False))


if __name__ == '__main__':
    main()
