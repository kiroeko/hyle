"""Prepare original43 integration with the existing original44/45 closure."""
from pathlib import Path
from datetime import datetime, timezone
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
BT = R / '.scratch/glm-original-target44-20261023'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path, data): path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
before = read(BT / 'before.json')
save(S / 'before.json', dict(utc=datetime.now(timezone.utc).isoformat(),
    previous_goal_turn_classification='progress: BT distinct original44 roles, source/runtime separation and four native cases266Graphs published.',
    prior_publication=read(BT / 'publication.json'), source=read(BT / 'source-final/freeze.json')['source'],
    protected_performance_tail_sha256=before['protected_performance_tail_sha256'],
    protected_qwen_image=before['protected_qwen_image']))
build = (BT / 'build.py').read_text(encoding='utf-8')
build = build.replace('Incremental original GLM target44 and shared K1 complete-state consumers.',
                      'Incremental original GLM target43/44/NextN complete K1 consumers.')
build = build.replace("BASE = R / '.scratch/glm-target-verifier-20261023/tests-link1'",
                      "BASE = R / '.scratch/glm-original-target44-20261023/tests-link1'")
build = build.replace("R / '.scratch/glm-target-verifier-20261023/compile1/glm-state/identity.json'",
                      "R / '.scratch/glm-original-target44-20261023/compile1/glm-state/identity.json'")
build = build.replace('glm-original-target44-checks.exe', 'glm-original-target43-checks.exe')
build = build.replace("    env['HYLE_GLM_MTP_TARGET44_DIR'] = str(S / 'original-target44')",
    "    env['HYLE_GLM_MTP_TARGET43_DIR'] = str(S / 'original-target43')\n    env['HYLE_GLM_MTP_TARGET43_MOE_DIR'] = str(S / 'original-moe')\n    env['HYLE_GLM_MTP_TARGET44_DIR'] = str(R / '.scratch/glm-original-target44-20261023/original-target44')")
build = build.replace("env['HYLE_GLM_MTP_TARGET44_MOE_DIR'] = str(S / 'original-moe')",
                      "env['HYLE_GLM_MTP_TARGET44_MOE_DIR'] = str(R / '.scratch/glm-original-target44-20261023/original-moe')")
(S / 'build.py').write_text(build, encoding='utf-8')
moe = (BT / 'fetch_moe.py').read_text(encoding='utf-8').replace('layer44 MoE', 'layer43 MoE')
(S / 'fetch_moe.py').write_text(moe, encoding='utf-8')
static = (BT / 'fetch_static.py').read_text(encoding='utf-8')
static = static.replace('24 pinned GLM Flash original target44 static roles', '26 pinned GLM Flash original target43 static roles')
static = static.replace('original-target44', 'original-target43').replace('277078744', '150779608').replace('original_roles=24', 'original_roles=26')
(S / 'fetch_static.py').write_text(static, encoding='utf-8')
save(S / 'progress.json', dict(stage='BU', goal_complete=False, native_checks_run=False,
    previous_goal_turn_classification='progress: BT original44 plus K1 full-state checks passed and published.',
    state='Original43 source, layer-owned parameter views and exact acquisition implementation underway.',
    scope='Original43 HC/MLA/indexer/MoE plus existing original44/45/full-V K1 with one34-resource plus Epoch StateHead. Layer42 and finite initial prefix remain explicit boundaries.',
    new_TPS=False, next='Fetch distinct43 roles; reuse layer-local sparse math without EH identity, integrate and run focused original43/44/45 and direct regression cases.'))
print('PREPARED BU: cached one-TU build and existing bounded acquisition protocols')
