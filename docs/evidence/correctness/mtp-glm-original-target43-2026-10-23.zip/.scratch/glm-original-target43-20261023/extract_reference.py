"""Mechanical private HC-reference extraction; no native code is executed."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
old_path = R / 'tests/compute_models/glm_original_target44_reference.h'
common_path = R / 'tests/compute_models/glm_hyper_connection_reference.h'
before = S / 'reference-source/before/tests/compute_models/glm_original_target44_reference.h'
assert not before.exists() and not common_path.exists()
raw = old_path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '3aa452a4f1aee26ce1e4a2324e65ff5bf60491bc91d97ec623a3cb46e1de62f8'
before.parent.mkdir(parents=True, exist_ok=True)
before.write_bytes(raw)
old = raw.decode('utf-8')
detail_start = old.index('namespace detail {')
detail_end = old.index('} // namespace detail', detail_start) + len('} // namespace detail')
detail = old[detail_start:detail_end]
norm_start = old.index('  const auto norm = [&]')
pre_start = old.index('  const auto hc_pre = [&]', norm_start)
post_start = old.index('  const auto hc_post = [&]', pre_start)
after = old.index('  if (!hc_pre(ports.attention_hc', post_start)


def body(text):
    return text[text.index('{') + 1:text.rindex('};')]


norm_body = body(old[norm_start:pre_start])
pre_body = body(old[pre_start:post_start])
post_body = body(old[post_start:after])
mapped_norm = norm_body.replace('data.norm(gamma)', 'gamma').replace('roles::kNormEpsilon', 'graph::kNormEpsilon')
mapped_pre = pre_body.replace('data.bytes(fn)', 'fn').replace('data.floats(scales)', 'scales').replace('data.floats(bases)', 'bases')
mapped_pre = mapped_pre.replace('roles::kNormEpsilon', 'graph::kNormEpsilon').replace('roles::kHcEpsilon', 'graph::kHcEpsilon')
mapped_pre = mapped_pre.replace('norm(part.norm, gamma)', 'expect_norm(part.norm, gamma, actual)')
includes = old[:old.index('#include "dspark_original_hc_reference.h"')]
prefix = includes + '''#include "dspark_original_hc_reference.h"
#include "glm_hyper_connection_fragment.h"
#include "glm_shared_vocabulary_reference.h"

// The exact former target44 HC local checks, shared by ordinary43/44 model
// fragments. Raw fn remains original BF16 bytes; its runtimeF32 widening is
// exact. This helper follows fixed06992 torch/unfused semantics only.
namespace glm_hyper_connection_reference {
namespace graph = glm_hyper_connection_fragment;
namespace lm = glm_shared_vocabulary_reference;
namespace hc = dspark_original_hc_reference;
namespace scalar = glm_original_indexer_reference::detail;
using F32 = std::span<const float>;
using BF16 = std::span<const std::uint16_t>;
using Bytes = std::span<const std::byte>;
inline constexpr std::size_t kHidden = 4096, kStreams = 4;

'''
readers = '''
  const auto f32 = [&](graph::Value value) { return detail::floats(actual(value)); };
  const auto bf16 = [&](graph::Value value) { return detail::bfloats(actual(value)); };'''
common = prefix + detail + '''

template<class ReadValue>
inline bool expect_norm(const graph::NormPorts &part, BF16 gamma, ReadValue &&actual) {'''
common += readers + mapped_norm + '''}

template<class ReadValue>
inline bool expect_pre(const graph::HcPorts &part, Bytes fn, F32 scales, F32 bases,
                       BF16 gamma, ReadValue &&actual) {'''
common += readers + mapped_pre + '''}

template<class ReadValue>
inline bool expect_post(const graph::PostPorts &part, const graph::HcPorts &pre, ReadValue &&actual) {'''
common += readers + post_body + '''}
} // namespace glm_hyper_connection_reference
'''
common_path.write_text(common, encoding='utf-8')
wrappers = '''  const auto norm = [&](const graph::NormPorts &part, Role gamma) {
    return glm_hyper_connection_reference::expect_norm(part, data.norm(gamma), actual);
  };
  const auto hc_pre = [&](const graph::HcPorts &part, Role fn, Role scales, Role bases, Role gamma) {
    return glm_hyper_connection_reference::expect_pre(part, data.bytes(fn), data.floats(scales), data.floats(bases), data.norm(gamma), actual);
  };
  const auto hc_post = [&](const graph::PostPorts &part, const graph::HcPorts &pre) {
    return glm_hyper_connection_reference::expect_post(part, pre, actual);
  };
'''
current = old[:norm_start] + wrappers + old[after:]
current = current[:detail_start] + 'namespace detail = glm_hyper_connection_reference::detail;' + current[detail_end:]
current = current.replace('#include "dspark_original_hc_reference.h"', '#include "glm_hyper_connection_reference.h"')
old_path.write_text(current, encoding='utf-8')
proof = dict(mode='mechanical source-only HC reference extraction',
    baseline_sha256=hashlib.sha256(raw).hexdigest(), detail_exact=detail in common,
    norm_body_exact_after_parameter_substitution=mapped_norm in common,
    pre_body_exact_after_parameter_substitution=mapped_pre in common,
    post_body_exact=post_body in common,
    old_projection_helpers_exact=old[detail_end:norm_start] in current,
    old_KDA_and_return_suffix_exact=old[after:] in current,
    substitutions=['data.norm(gamma)->gamma', 'data.bytes(fn)->fn', 'data.floats(scales/bases)->scales/bases',
        'roles::epsilon->identical common graph::epsilon', 'norm->same extracted expect_norm'],
    native=False, math_or_threshold_change=False)
assert all(value for key,value in proof.items() if key.endswith('exact') or key.endswith('substitution'))
(S / 'review/reference-extraction-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(common_bytes=common_path.stat().st_size, target44_bytes=old_path.stat().st_size, proof=proof)))
