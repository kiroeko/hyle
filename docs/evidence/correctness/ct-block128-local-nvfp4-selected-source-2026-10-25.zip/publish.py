"""Package the completed finite CT18 CPU check; no build/run/download."""
from pathlib import Path
import hashlib
import json
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
PUBLIC = ROOT / 'docs/evidence/correctness/ct-block128-local-nvfp4-selected-source-2026-10-25.json'
ZIP = PUBLIC.with_suffix('.zip')

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

sources = read(WORK / 'source-pins.json')['files']
for item in sources:
    assert pin((ROOT / item['path']).read_bytes()) == item['after']
    assert pin((WORK / 'source' / item['path']).read_bytes()) == item['after']
actual = read(WORK / 'cpu2/summary.json')
assert actual['status'] == 'PASS'
assert actual['xml'] == dict(tests=1, failures=0, errors=0, skipped=0)
first = read(WORK / 'cpu1/summary.json')
assert first['status'] == 'COMPILE_FAILED_NO_RUN'
facts = read(WORK / 'source-facts.json')
header_path = Path(facts['header']['path'])
assert pin(header_path.read_bytes()) == {key: facts['header'][key] for key in ('bytes', 'sha256')}
header = json.loads(header_path.read_bytes())
assert all(header[name] == value for name, value in facts['roles'].items())
config_path = Path(facts['config']['path'])
assert pin(config_path.read_bytes()) == {key: facts['config'][key] for key in ('bytes', 'sha256')}

r2_header = WORK / 'r2/source' / sources[0]['path']
after_header = WORK / 'source' / sources[0]['path']
old = b'check(validate(source[i],ct_specs[i],identity));'
new = b'check(validate(source[i],ct_specs[i],identity),"CT18 paired original-role validation");'
assert r2_header.read_bytes().count(old) == 1
assert r2_header.read_bytes().replace(old, new) == after_header.read_bytes()
assert (WORK / 'r2/source' / sources[1]['path']).read_bytes() == (WORK / 'source' / sources[1]['path']).read_bytes()
revision3 = dict(previous_revision=2, revision=3,
    change='Supply the existing scalar::check(Status,string_view) error context at the paired CT-role preflight. No math, graph, data, oracle or test-body changes.',
    first_attempt=first,
    changed_source=sources[0]['path'], old=pin(r2_header.read_bytes()), new=pin(after_header.read_bytes()),
    canonical_and_private_match=True)
(WORK / 'revision3-source-checks.json').write_bytes(encode(revision3))

report = dict(
    status='CT_BF16_BLOCK128_AND_SELECTED_LOCAL_NVFP4_SOURCE_CPU_PASS', date='2026-10-25',
    change='A finite ordinary source adapter binds original CT BF16 block128 roles and selected local-NVFP4 expert quartet spans to genuine readonly leases, the existing resident-bank/map supply and existing shared Graph math.',
    integration='Root reviewed and exact-applied revision2. The authorized revision3 fix supplies one missing error-context argument in canonical and private helper sources. The checked two-source canonical hashes are listed below; packaging did not rebuild or rerun.',
    sources=sources,
    source_contract=dict(repository=facts['repository'], revision=facts['revision'], file=facts['file'],
        header=facts['header'], config=facts['config'], reader_commit='compressed-tensors@46196ce607421d9992a47644612dc6b443f3c434',
        original_numeric_payload_bytes=0,
        CT='Original layer0 linear_attn.in_proj_a E4[128,8192] and BF16 SF[1,64]. They enter the same shared CT block128 BF16 append without converting the SF contract to code-dot/F32 scales or channel/token math.',
        experts='Original layer0 expert0..3 gate quartet headers: packed U8[2048,4096], E4 SF[2048,512], F32 WG[1] and IG[1]. This consumer explicitly selects the first N3 rows/full K8192 of the full source descriptors.',
        input_boundaries='Independent BF16 GDN[1,8192] and post-attention MLP[1,1,8192] boundaries. The128-wide CT projection is not connected to the8192-wide MLP input.'),
    math=dict(
        CT='Existing shared BF16 block128 dynamic activation: BF16 intermediates, zero-only epsilon1/128, original positive/negative zero handling and E4 casts; BF16 SF axes and weight dequant store points are preserved.',
        local='Existing GroupedLocalNvfp4Linear with explicit kBFloat16 input rounding: original local WG/IG division and group16 math. It is not the ModelOpt multiplier equation and does not substitute F32 pre-round.',
        oracle='CT uses the existing independent BF16/E4 scalar reference and F64/F32 dot-to-BF16 interval. Sparse local generated weights use existing independent local activation/weight equations with exact BF16 endpoints. Existing numerical gates were not widened.'),
    geometry=dict(CT_N=128, CT_K=8192, expert_prefix_N=3, expert_K=8192,
        domain=512, selected_capacity=2, generations=[[0, 1], [2, 3]],
        successful_graph_submissions=2, checked_BF16_endpoints=268,
        resident_logical_bytes_per_generation=29712, independent_CT_result_copy_bytes=256),
    ownership='Original source WG/IG rank1 is preserved: the existing Layout prepends capacity to produce[E,1]; explicit reader reshapes remove this original singleton axis only at the grouped scalar-vector boundary. Each generation supplies all four compressed planes and its checked I32 map together. No new owner table, route, op, registry or executor is introduced.',
    assertions=[
        'A bad CT scale span and a bad expert IG span reject cold source admission.',
        'The original CT parameter ConstantBindings retain genuine source leases and the same actual StorageOwner/resource.',
        'All64 CT scale columns and signed/zero activation groups participate in the nonzero generated fixture; floor substitution differs from the zero-only reference.',
        'The local fixture distinguishes BF16 from F32 pre-round and independent per-expert IG from a shared scale.',
        'Both generations remain readable together. Supply live_blocks is10; dropping batch handles keeps10 Invocation-held blocks, dropping Invocations retires all10. Independent old output leases remain readable after constants and the compiled graph are released.'
    ],
    actual=actual, filter='CpuLocalNvfp4ReferenceGraph.OriginalCtMixedRolesKeepBfloatPreRoundAndSelectedSourceGenerations',
    failures_and_revisions=[
        'Revision1 was an uncompiled source proposal. Revision2 explicitly copies the256-byte shared terminal reshape result so its output storage can escape independently; no execution failure was claimed for revision1.',
        'cpu1 actually failed strict compilation in1.562s: C2660 at helper125, missing the existing check function message argument. No link or test ran. Original commands and logs are retained.',
        'Revision3 adds that message only. cpu2 strict compilation, cached link and the single CPU test all passed; no numerical/ownership threshold or input was changed.'
    ],
    limits=[
        'Original cached configuration/header identities and exact role spans are checked; all numerical tensor bodies in this test are explicitly generated original-shape fixtures. Original publisher numeric payload bytes are0.',
        'This is a finite source/lease/selected-bank Graph consumer, not a complete layer, router, FFN, Model constructor or generation journey. It does not certify publisher quality, new MTP, GPU native execution or throughput.',
        'Only one existing CPU test TU was rebuilt. Cached core/provider/SDK/native objects were reused unchanged; no GPU, HTTP or additional test matrix ran.',
        'Archive retains the two changed sources, original test before-image, commands, actual dependencies, frozen-source/object hashes and raw results. Unchanged frozen source trees, SDK, binaries and model bodies are omitted. Source-only status fields in historical pins remain preparation checkpoints.'
    ])

members = {}
def add(path, name):
    assert name not in members
    members[name] = path.read_bytes()

for name in ['source.patch', 'source-pins.json', 'scope.json', 'source-facts.json',
             'unchanged-dependencies.json', 'revision2-source-checks.json', 'revision3-source-checks.json', 'check_cpu.py', 'publish.py']:
    add(WORK / name, name)
for item in sources:
    add(WORK / 'source' / item['path'], 'source/' + item['path'])
    if item['before']:
        add(WORK / 'before' / item['path'], 'before/' + item['path'])
for revision in [1, 2]:
    for name in ['source-pins.json', 'scope.json']:
        add(WORK / ('r' + str(revision)) / name, 'history-r' + str(revision) + '/' + name)
for attempt in ['cpu1', 'cpu2']:
    for name in ['summary.json', 'frozen-project.json']:
        add(WORK / attempt / name, attempt + '/' + name)
    phases = ['compile'] if attempt == 'cpu1' else ['compile', 'link', 'run']
    for phase in phases:
        for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
            add(WORK / attempt / phase / name, attempt + '/' + phase + '/' + name)
for name in ['tests.xml', 'actual-dependencies.json', 'link-inputs.json', 'runtime.json', 'compile/dependencies.json']:
    add(WORK / 'cpu2' / name, 'cpu2/' + name)
add(config_path, 'original-source/config.json')
members['original-source/selected-header-roles.json'] = encode(dict(header=facts['header'], roles=facts['roles'],
    note='Exact selected entries rechecked against the pinned original cached raw header; full header and numeric bodies are not duplicated.'))
for name in ['local_nvfp4_reference_fixture.h', 'ct_block128_qdq_fixture.h']:
    path = ROOT / 'tests/compute_models' / name
    members['original-source/' + name + '.pin.json'] = encode(dict(path=path.relative_to(ROOT).as_posix(), **pin(path.read_bytes())))
add(ROOT / '.scratch/inference-e4-append-implementation-20261025/check_finite.py', 'runner-dependencies/check_finite.py')
add(ROOT / 'scripts/hyle_environment.py', 'runner-dependencies/hyle_environment.py')
members['report-without-archive.json'] = encode(report)
manifest = [dict(path=name, **pin(raw)) for name, raw in sorted(members.items())]
members['archive-manifest.json'] = encode(dict(files=manifest, excludes='Manifest does not list itself.'))
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(members.items()):
        entry = zipfile.ZipInfo(name, date_time=(2026, 10, 25, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(entry, raw)
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(members)
    for item in manifest:
        assert pin(archive.read(item['path'])) == {key: item[key] for key in ('bytes', 'sha256')}
report['archive'] = dict(path=ZIP.relative_to(ROOT).as_posix(), **pin(ZIP.read_bytes()), members=len(members),
    logical_bytes=sum(map(len, members.values())), CRC_and_member_SHA256_verified=True)
PUBLIC.write_bytes(encode(report))
result = dict(public=dict(path=PUBLIC.relative_to(ROOT).as_posix(), **pin(PUBLIC.read_bytes())), archive=report['archive'])
(WORK / 'public-manifest.json').write_bytes(encode(result))
print(json.dumps(result, indent=2))
