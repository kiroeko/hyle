$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$scope = (Resolve-Path -LiteralPath (Join-Path $repoRoot '.scratch/dspark-original-experts-20261023')).Path.TrimEnd('\') + '\'
$relativeTargets = @(
  'tests-link1/dspark-original-expert-checks.exe',
  'tests-link1/dspark-original-expert-checks.map',
  'tests-link2/dspark-original-expert-checks.exe',
  'tests-link2/dspark-original-expert-checks.map',
  'tests-link3/dspark-original-expert-checks.exe',
  'tests-link3/dspark-original-expert-checks.map',
  'mapping-tests-recipe.json'
)
# Superseded executables/maps only. Keep link4, all source/object/runtime
# caches, original compressed weights and every command/result/failed attempt.
$entries = @(
  foreach ($relative in $relativeTargets) {
    $target = [IO.Path]::GetFullPath((Join-Path $scope $relative))
    if (-not $target.StartsWith($scope, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside batch directory: $target" }
    if (Test-Path -LiteralPath $target) {
      $resolved = (Resolve-Path -LiteralPath $target).Path
      if (-not $resolved.StartsWith($scope, [StringComparison]::OrdinalIgnoreCase)) { throw "Resolved outside batch: $resolved" }
      $item = Get-Item -LiteralPath $resolved
      if ($item.PSIsContainer) { throw "Expected a file: $resolved" }
      [pscustomobject]@{ path = $resolved; bytes = $item.Length }
    }
  }
)
foreach ($entry in $entries) { Remove-Item -LiteralPath $entry.path -Force }
$record = [ordered]@{
  complete = $true
  removed_files = $entries.Count
  logical_removed_bytes = ($entries | Measure-Object -Property bytes -Sum).Sum
  targets = $entries
  retained = 'Current link4 executable/map, all objects/runtime/SDK/source/data and all failure/command/result records'
}
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $scope 'cleanup/result.json') -Encoding utf8
$record | ConvertTo-Json -Depth 5
