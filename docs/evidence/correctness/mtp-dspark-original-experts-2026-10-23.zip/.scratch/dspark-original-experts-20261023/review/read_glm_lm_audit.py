from collections import deque
from pathlib import Path
import re

root=Path(__file__).resolve().parents[3]
source=root/'.scratch/official-weight-audit.json'
active=None
start=0
tail=deque(maxlen=8)
remaining=0
for number,line in enumerate(source.open(encoding='utf-8'),1):
    if re.match(r'    "glm53(_flash)?": \{',line):
        active=line.strip();start=number
        print('MODEL',number,active)
    selected_range=any(first<=number<=last for first,last in (
        (10799315,10799340),(11712752,11712778)))
    if active and (number-start<3500 or selected_range):
        if re.match(r'      "',line) or selected_range or any(term in line for term in (
            '"lm_head.weight"','"model.embed_tokens.weight"',
            '"model.language_model.embed_tokens.weight"','"shared_head.norm.weight"',
            '"hidden_size"','"vocab_size"','"tie_word_embeddings"',
            '"header_sha','"data_base"','"header_bytes"','"header_size"')):
            if remaining==0:
                for old_number,old_line in tail: print(f'{old_number}: {old_line}',end='')
            remaining=max(remaining,20)
        if remaining:
            print(f'{number}: {line}',end='');remaining-=1
    tail.append((number,line))
