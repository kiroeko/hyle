import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'.scratch/dspark-original-experts-20261023/hooks-source'
FILES=['tests/compute_models/cpu_c4_model_branches.h',
       'tests/compute_models/d5_deepseek_official_fragments.h',
       'tests/compute_models/dspark_complete_graph_fixture.h',
       'tests/compute_models/dspark_resident_draft.h']
def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(),bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())
entries=[]
for relative in FILES:
    source=ROOT/relative
    before=BASE/'before'/relative
    frozen=BASE/'frozen'/relative
    frozen.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,frozen)
    entry=dict(**identity(source),frozen=identity(frozen))
    if before.exists():
        delta=subprocess.run(['git','diff','--no-index','--',str(before),str(source)],cwd=ROOT,capture_output=True)
        if delta.returncode not in (0,1):raise RuntimeError(delta.stderr.decode(errors='replace'))
        target=BASE/'diff'/(source.name+'.diff');target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(delta.stdout)
        entry.update(before=identity(before),diff=identity(target))
    else:entry['before']='New source; absent before BM.'
    entries.append(entry)
record={
    'source_only':True,'native_build_run_ssh_download':False,'files':entries,
    'supply':'DraftParameters.routed_experts(parentFragment,stage)->RoutedExpertParameters{router,bias,weights[3],map,capacity=30}. Router BF16[256,4096] and bias F32[256] actual parent constants; three canonical native GGUF MXFP4 E30 banks and I32map[256] actual parent inputs.',
    'child':'x+sharedGate/sharedUp/sharedDown+router+bias+expertGate/expertUp/expertDown+map:10 typed inputs. Old20 semantic/shared outputs followed by24 actual routed observation fields:44 outputs. Old generated/68-mode math and node order retained.',
    'math':'Actual BF16 input/coeff BFloatLinearF32 -> softplus -> sqrt -> original F32 bias -> full256 TopK6. Original I32 IDs survive; weights use unbiased selected scores/divide sum/scale. Explicit mapGather changes only physical expert indices. Gate/up native MXFP4 GroupedMatMul thenBF16, original clip/SwiGLU, route weighting BEFORE downBF16/nativeGroupedMatMul, then original routed/shared/HC merge. No generated7 experts in supplied mode.',
    'observations':'RoutedExpertPorts24 actual values include logits/softplus/scores/selection/selected_scores/sum/normalized/ids/weights/map/local_ids, actual input, gate/up raw+stored/clip/activation and weighted raw+stored/down raw+stored/combined. Stable3 RoutedBoundary records are not changed by Copy visitor.',
    'full_inputs':'Encoded full draft retains6 semantic inputs plus12 bounded resident bank/map inputs=18 after deleting the original unused teacher input. Fixture validates exact extra count only in supplied residency mode.',
    'cuts':'dspark_resident_draft::split(full,threeBoundaries)->four ordinary Phase Fragments. Each cut ends at max producer of actual x/globalIDs/normalized weights. Prefix cannot read future bank/map inputs. Later phases consume only actual source leases by original full ordinal; origin phase exposes cross-phase results with independent Copy. Terminal diagnostic Copies move to actual predecessor phase and existing Copy outputs are reused. Full output Location table preserves every original semantic/diagnostic port.',
    'constants':'Phase constants have empty payload and parallel original_constants identities. Caller cold-prepares/uploads full constant registry exactly once and shares real readonly owners/leases across ordinary phase Graphs. No perphase2GB vocabulary copy, provider branch, host activation replacement, dynamic public callback or new executor.',
    'ownership':'Caller owns existing Context/queues/StorageOwner, four ordinary Invocation objects and bounded upload slots. Real IDs alone choose exact original byte slices. StateHead publishes original complete accepted state tuple after whole journey; no partial state publication is introduced.',
    'review':'Source reviewed independently; terminal Copy double-materialization finding fixed by reusing existing Copy. Root owns focused single-TU native validation; no native pass is asserted by this freeze.'
}
target=BASE/'freeze.json';target.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(freeze=identity(target),files=[identity(ROOT/f)for f in FILES]),indent=2))
