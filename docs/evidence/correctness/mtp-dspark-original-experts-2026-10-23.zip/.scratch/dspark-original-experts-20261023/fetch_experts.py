"""Acquire the fifteen pinned DSpark router/bias/MXFP4 roles, with bounded IO."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import os
import time
import urllib.error
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
CHUNK = 128 * 1024 * 1024
IO = 1024 * 1024


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


plan_path = R / '.scratch/dspark-original-hc-20261023/review/remaining-original-roles.json'
groups = read(plan_path)['remaining']['groups']
old = read(R / '.scratch/glm-mtp-catchup-20261022/review/dspark-original-target-roles.json')
header = read(R / old['header_source'])[old['header_cache_key']]
for key in ('repository', 'revision', 'file', 'tensor_table_sha256'):
    assert header[key] == old[key], key
assert header['tensor_count'] == 81
table = {row['name']: row for row in header['tensors']}
roles = [row for name in ('router', 'router_bias', 'expert') for row in groups[name]['roles']]
roles.sort(key=lambda row: (row['payload_bytes'], row['absolute_range_inclusive'][0]))
assert len(roles) == 15
assert sum(row['payload_bytes'] for row in roles) == 10273950720
codecs = {'F32': (0, 1, 4), 'BF16': (30, 1, 2), 'MXFP4': (39, 32, 17)}
for role in roles:
    row = table[role['name']]
    dtype, block, storage = codecs[role['codec']]
    assert row['dtype'] == role['codec'] and row['dtype_code'] == dtype, row
    assert [int(x) for x in row['shape']] == role['gguf_dimensions']
    assert role['gguf_dimensions'][0] % block == 0
    extent = math.prod(role['gguf_dimensions']) // block * storage
    start = int(header['tensor_data_offset']) + int(row['offset'])
    assert extent == role['payload_bytes']
    assert role['absolute_range_inclusive'] == [start, start + extent - 1]

out = S / 'original-experts'
out.mkdir(exist_ok=True)
receipt = out / 'acquisition.json'
identity = dict(repository=old['repository'], revision=old['revision'], file=old['file'],
    url=old['url'], whole_file_bytes=old['known_whole_file_bytes'], etag=old['known_etag'],
    tensor_table_sha256=old['tensor_table_sha256'], tensor_data_offset=old['tensor_data_offset'],
    source_plan=plan_path.relative_to(R).as_posix())
if receipt.exists():
    record = read(receipt)
    for key, value in identity.items():
        assert record[key] == value, key
else:
    record = dict(**identity, complete=False, original_roles=15,
        expected_role_payload_bytes=10273950720, whole_file_downloaded=False,
        chunk_bytes=CHUNK, stream_buffer_bytes=IO, requests=[], roles=[])
    for role in roles:
        path = out / (role['name'] + '.' + role['codec'].lower())
        assert not path.exists(), 'Unreceipted existing file: ' + str(path)
        record['roles'].append(dict(**role, complete=False, chunks=[],
            payload=dict(path=path.relative_to(R).as_posix(), bytes=role['payload_bytes'], sha256=None)))


def save():
    temporary = receipt.with_suffix('.json.next')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, receipt)


def verify_prefix(row, path):
    offset = 0
    if not path.exists():
        assert not row['chunks'] and not row['complete'], row['name']
        return offset
    with path.open('rb') as stream:
        for chunk in row['chunks']:
            assert chunk['offset'] == offset and chunk['bytes'] <= CHUNK
            digest = hashlib.sha256()
            remaining = chunk['bytes']
            while remaining:
                data = stream.read(min(IO, remaining))
                assert data, 'Truncated verified prefix: ' + str(path)
                digest.update(data)
                remaining -= len(data)
            assert digest.hexdigest() == chunk['sha256'], path
            offset += chunk['bytes']
    size = path.stat().st_size
    assert offset <= size <= min(row['payload_bytes'], offset + CHUNK)
    if row['complete']:
        assert size == offset == row['payload_bytes']
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['payload']['sha256']
    return offset


save()
for row in record['roles']:
    path = R / row['payload']['path']
    offset = verify_prefix(row, path)
    if row['complete']:
        print('REUSED', row['name'], row['payload_bytes'], flush=True)
        continue
    while offset < row['payload_bytes']:
        size = min(CHUNK, row['payload_bytes'] - offset)
        first = row['absolute_range_inclusive'][0] + offset
        last = first + size - 1
        attempt = dict(role=row['name'], first=first, last=last, requested_bytes=size,
                       complete=False, started_utc=now())
        record['requests'].append(attempt)
        save()
        print('REQUEST', row['name'], offset, size, flush=True)
        request = urllib.request.Request(old['url'], headers={
            'Range': f'bytes={first}-{last}', 'If-Range': old['known_etag'],
            'Accept-Encoding': 'identity', 'User-Agent': 'hyle-original-role-consumer/1'})
        try:
            # Transient TLS handshakes must not discard an authenticated prefix.
            # Content/header mismatches below remain terminal, without retry.
            for transport_attempt in range(5):
                try:
                    response = urllib.request.urlopen(request, timeout=60)
                    break
                except (urllib.error.URLError, TimeoutError, OSError) as error:
                    attempt.setdefault('transport_errors', []).append(dict(
                        error_type=type(error).__name__, error=str(error), utc=now()))
                    save()
                    if transport_attempt == 4:
                        raise
                    time.sleep(2)
            with response:
                assert response.status == 206, response.status
                assert response.headers.get('Content-Range') == f'bytes {first}-{last}/{old["known_whole_file_bytes"]}'
                assert response.headers.get('ETag') == old['known_etag']
                assert response.headers.get('Content-Length') in (None, str(size))
                assert response.headers.get('Content-Encoding') in (None, 'identity')
                digest = hashlib.sha256()
                mode = 'r+b' if path.exists() else 'x+b'
                with path.open(mode) as stream:
                    stream.seek(offset)
                    remaining = size
                    while remaining:
                        data = response.read(min(IO, remaining))
                        assert data, 'Early EOF'
                        digest.update(data)
                        stream.write(data)
                        remaining -= len(data)
                    assert not response.read(1), 'Overlong body'
                    stream.flush()
                    os.fsync(stream.fileno())
            assert path.stat().st_size == offset + size
            chunk = dict(offset=offset, bytes=size, sha256=digest.hexdigest(),
                         absolute_range_inclusive=[first, last])
            row['chunks'].append(chunk)
            attempt.update(complete=True, http_status=206, bytes=size,
                content_range=f'bytes {first}-{last}/{old["known_whole_file_bytes"]}',
                etag=old['known_etag'], sha256=chunk['sha256'], finished_utc=now())
            offset += size
            save()
            print('VERIFIED', row['name'], offset, '/', row['payload_bytes'], flush=True)
        except Exception as error:
            attempt.update(error_type=type(error).__name__, error=str(error), finished_utc=now())
            save()
            raise
    with path.open('rb') as stream:
        row['payload']['sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
    row['complete'] = True
    save()
    print('ACQUIRED', row['name'], row['payload']['sha256'], flush=True)

record.update(complete=True, role_payload_bytes=sum(row['payload']['bytes'] for row in record['roles']),
    successful_request_body_bytes=sum(row['bytes'] for row in record['requests'] if row['complete']),
    finished_utc=now())
assert len(record['roles']) == 15 and record['role_payload_bytes'] == 10273950720
assert record['successful_request_body_bytes'] == record['role_payload_bytes']
save()
print(json.dumps(dict(roles=15, payload_bytes=record['role_payload_bytes'],
                     request_body_bytes=record['successful_request_body_bytes'])), flush=True)
