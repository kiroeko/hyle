"""Publish bounded real-ID DSpark expert/state results, excluding weight bodies."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    name=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path)
    return dict(path=name,bytes=path.stat().st_size,sha256=digest)


def check_identity(row):
    actual = identity(R / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--new-run', type=int,nargs='+',required=True)
parser.add_argument('--regression-run', type=int, required=True)
parser.add_argument('--link-attempt', type=int, required=True)
parser.add_argument('--mapping-run', type=int, required=True)
parser.add_argument('--consumer-freeze',default='source')
parser.add_argument('--supply-freeze',default='supply-source')
args = parser.parse_args()
run_indices=[*args.new_run,args.regression_run]
runs = [read(S / f'checks{index}/summary.json') for index in run_indices]
cases = []
for index, run in zip(run_indices,runs):
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert run['tests'] == (2 if index==args.regression_run else 2//len(args.new_run))
    assert not any(run[key] for key in ('failures','errors','disabled','skips'))
    tree = ET.parse(S / f'checks{index}/results.xml').getroot()
    for case in tree.iter('testcase'):
        assert case.attrib['result'] == 'completed' and case.find('failure') is None and case.find('skipped') is None
    cases.extend(run['cases'])
assert len(cases) == len({(c['attributes']['classname'],c['attributes']['name']) for c in cases}) == 4
mapping_run=read(S / f'checks{args.mapping_run}/summary.json')
assert mapping_run['process']['exit']==0 and not mapping_run['process']['timed_out']
assert mapping_run['tests']==3 and not any(mapping_run[key] for key in ('failures','errors','disabled','skips'))
for case in [case for run in runs[:-1] for case in run['cases']]:
    props = case['properties']
    assert props['original_role_count'] == '83' and props['original_role_bytes'] == '13008927644'
    assert props['actual_submissions'] == '37' and props['resident_draft_phases'] == '4'
    assert props['actual_draft_phase_submissions'] == '16' and props['actual_draft_episodes'] == '4'
    providers = {key:value for key,value in props.items() if key.startswith('expert_stage') and key.endswith('_provider')}
    assert len(providers) == 9
    assert set(providers.values()) == ({'ggml-cpu'} if case['attributes']['name'].startswith('Cpu') else {'ggml-cuda'})
for case in runs[-1]['cases']:
    assert case['properties']['original_role_count'] == '68' and case['properties']['actual_submissions'] == '25'

freezes = [S / folder / 'freeze.json' for folder in (args.consumer_freeze,'hooks-source','reference-source',args.supply_freeze,'mapping-source')]
for path in freezes:
    freeze = read(path)
    rows = freeze.get('files',freeze.get('file',freeze.get('source')))
    if isinstance(rows,dict):
        rows = [rows]
    assert all(rows), path
    for row in rows:
        check_identity(row)
link = read(S / f'tests-link{args.link_attempt}/link-plan.json')
for row in link['compiled_records']:
    check_identity(row)
    compiled = read(row['path'])
    # Reused baseline objects keep their original compile-time dependency
    # records. Only this batch's rebuilt TUs assert current source/deps; every
    # actual linked input is independently pinned by the link plan below.
    if Path(row['path']).is_relative_to(S):
        for value in (compiled['source'],compiled['object'],*compiled['dependencies']):
            check_identity(value)
for row in link['inputs']:
    check_identity(row)
image = read(S / f'tests-link{args.link_attempt}/ready.json')['image']
check_identity(image)
for run in [*runs,mapping_run]:
    assert run['image'] == image, 'Run results belong to a different executable'
    check_identity(run['image'])
    assert Path(run['process']['command'][0]).resolve() == Path(image['path']).resolve()
acquisition = read(S / 'original-experts/acquisition.json')
assert acquisition['complete'] and len(acquisition['roles']) == 15
assert acquisition['role_payload_bytes'] == acquisition['successful_request_body_bytes'] == 10273950720
for role in acquisition['roles']:
    assert role['complete']
    check_identity(role['payload'])
tail = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
tail = tail[tail.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode('utf-8')).hexdigest()
assert tail_hash == read(S / 'start.json')['performance_tail_utf8_sha256']

pattern = re.compile(r'^original-MXFP4 role=(.*?) outputs=(\d+) max_error=(\S+) max_ratio=(\S+) '
                     r'max_AQ_ambiguity=(\S+) ambiguous_codes=(\d+) ambiguous_scales=(\d+)$')
numerics = []
for line in [line for index in args.new_run for line in (S / f'checks{index}/stderr.log').read_text(encoding='utf-8').splitlines()]:
    match = pattern.match(line)
    if match:
        role,count,error,ratio,ambiguity,codes,scales = match.groups()
        numerics.append(dict(role=role,values=int(count),maximum_absolute_error=float(error),
            maximum_bound_ratio=float(ratio),maximum_quantization_ambiguity=float(ambiguity),
            ambiguous_activation_codes=int(codes),ambiguous_activation_scales=int(scales)))
assert len(numerics) == 18
assert sum(row['values'] for row in numerics) == 1474560
assert all(row['maximum_bound_ratio'] <= 1 for row in numerics)
(S / 'numerical-observations.json').write_text(json.dumps(numerics,indent=2)+'\n',encoding='utf-8')

sources = [R / value for value in (
    'tests/compute_models/cpu_c4_model_branches.h',
    'tests/compute_models/d5_deepseek_official_fragments.h',
    'tests/compute_models/dspark_complete_graph_fixture.h',
    'tests/compute_models/dspark_resident_draft.h',
    'tests/compute_models/dspark_original_expert_roles.h',
    'tests/compute_models/dspark_original_expert_reference.h',
    'tests/compute_models/dspark_original_resident_weights.h',
    'tests/compute_models/dspark_original_state_consumer.h',
    'tests/compute_models/dspark_original_state_consumer_test.cc',
    'src/mem_vm/mapping.cc','tests/mem_vm/file_mapping_test.cc',
    'docs/developer/current-work.md','docs/implementation/model-operators.md')]
metadata = [R / value for value in (
    '.scratch/dspark-original-attention-20261023/review/expert-residency-next.json',
    '.scratch/dspark-original-hc-20261023/review/remaining-original-roles.json',
    '.scratch/dspark-original-shared-20261023/review/cpu-q8-quantizer.json',
    '.scratch/dspark-original-shared-20261023/reference-source/source-notes.json')]
paths = set(sources + metadata)
paths.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in (
    '.h','.cc','.py','.json','.txt','.diff','.log','.xml','.ps1'))
paths.discard(S / 'publication.json')
archive = D / 'mtp-dspark-original-experts-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
    for path in sorted(paths):
        zipped.write(path,path.relative_to(R).as_posix())

record = dict(date='2026-10-23',stage='BM',goal_complete=False,
    conclusion='All81 pinned DSpark sidecar original roles, plus2 formalBF16 vocabulary roles, now feed the complete three-stage draft/accepted-state journey on CPU and CUDA. Actual256-domain routing consumes original selected MXFP4 experts with finite explicit residency.',
    artifact=dict(original_roles=83,sidecar_original_roles=81,sidecar_total_roles=81,
        additional_formal_BF16_vocabulary_roles=2,original_payload_bytes=13008927644,
        acquisition=acquisition,original_payloads_archived=False,
        scope='Source-role extents, not all expert IDs exercised, a whole trained target run or measured physical memory.'),
    implementation=dict(
        routing='OriginalBF16[256,4096] router with actualBF16 input/F32 accumulation; originalF32 bias affects selection only. Top6 weights use unbiased sqrtsoftplus scores/divide sum/scale. Real global IDs are never filtered/clamped/modulo-remapped to generated experts.',
        arithmetic='Nine native GroupedMatMul consume original17B/32MXFP4 selected ranges. Gate/up/down stores, clip/SwiGLU and route weighting before down activation quantization remain. CPU Q8_0/CUDA Q8_1 activation math is distinct from official E4-A128/FP4.',
        phases='One complete model Fragment cold-cuts at three actual router frontiers into four ordinary Graphs on the existing Context/queue. Original semantic/diagnostic outputs map by phase/port. Only30I32 router IDs are scheduling readback; activation/weights/state pass by direct leases.',
        supply='E30 gate/up/down and I32map share each immutable generation.91 exact-coverage slices include valid duplicated unaddressed tail experts. CPU uses fixed two-generation ready lease pool; CUDA atomic span WeightBinding from one WeightBatch. Original nine banks stay mapped, no full F32 expert shadow.',
        foundation_fix='Borrowed FileMapping/SharedMapping views now truthfully advertise existing stable canonical CPU addresses. The mapping/access/lifetime implementation and weight-slice overlap validator remain unchanged; original mapped compressed ranges can directly feed sliced uploads without an extra resident host copy.',
        lifetime='Native resource addresses stay stable across Supply moves. Phase Invocations retire/reset before generation release, and their destruction precedes Supply. Explicit close reports upload retirement; exception teardown drains uploads before native resources. Complete accepted state publishes only after full proposal/verification.',
        state='Same encoded three-main-ring/carry/captures/protocol tuple; prefix0/1/2, wrap, Head continuation, cancellation/stale publication, retained results and collection.'),
    allocation_scope=dict(resident_capacity=30,expert_bytes_per_leg=4456448,
        per_slot_payload_bytes=401081344,CUDA_two_device_slots_bytes=802162688,
        CUDA_two_pinned_slots_bytes=802162688,CPU_two_generation_pool_bytes=802162688,
        scope='Declared native pool/backing capacities and upload reports; no physical peak, private workspace or bus-traffic measurement.'),
    validation=dict(unique_tests=7,model_consumer_tests=4,mapping_tests=3,failures=0,errors=0,skips=0,
        model_graph_submissions=sum(int(case['properties']['actual_submissions']) for case in cases),
        new_original_model_graph_submissions=74,related_regression_graph_submissions=50,
        cases=[*cases,*mapping_run['cases']],expert_projection_values_checked=1474560,numerical_observations=numerics,
        numerical='Firstepisode independent original-selected-byte F64/native-AQ projection bounds; everyepisode actualrouter dot/selection/unbiasedweights/map/clip/gate/weighteddown/BF16 and prior attention/shared/HC/LM/confidence/state gates. No tolerance widening or ideal-predecessor propagation through rounding.',
        precision_scope='CPU fixed actualAVX Q8_0 quantizer. CUDA SM89 M5 MMVQ Q8_1 interval remains conditional under existing division/FTZ/range assumptions. Does not assert all-input vendor accuracy.',
        commands_and_results=[identity(S / f'checks{index}/summary.json') for index in [*run_indices,args.mapping_run]],
        compiled_host_translation_units=3,
        host_compile_attempts=len(list(S.glob('compile*/*/identity.json'))),
        prior_attempts=[read(S / f'checks{index}/summary.json') for index in (1,2,4)],
        prior_attempt_scope='Preserved separately: checks1 failed2 provenance reports before expert arithmetic. checks2 CPU complete83 passed; CUDA upload exposed the missing mapped-host-address capability. checks4 CPU passed and CUDA then exposed the separate device resource rejected by fallback Gather. Final7 passing cases above use the repaired frozen executable.',
        SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
    source_reviews=[identity(path) for path in freezes],source_metadata=[identity(path) for path in metadata],
    limitations=['WindowsCPU/CUDA finite journey only; no new Linux/Apple/Vulkan model execution.',
        'Target captures/verifier remain generated. No full trainedtarget, Pro geometry, primaryUD-Q4 vocabulary, natural acceptance or generation-quality claim.',
        'Exact original selected codec/activation math does not certify official FP8/FP4 or all other quantization artifacts.',
        'No new TPS/loading/physical-memory peak measurement; latestAV comparison remains unchanged.',
        'Full MTP, images and broader architecture/performance goal remain incomplete.'],
    remaining='Other original roles/sharedLM/real targettaps/Pro geometry and confirmed applicable quantization supply; necessary final ordinary/MTP complete performance comparison before images.',
    final_image=image,sources=[identity(path) for path in sources],performance_tail_sha256=tail_hash,
    archive=identity(archive),archive_items=len(paths))
out = D / 'mtp-dspark-original-experts-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(out),archive=identity(archive)),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=identity(out),archive=identity(archive),tests=7,graphs=record['validation']['model_graph_submissions'])))
