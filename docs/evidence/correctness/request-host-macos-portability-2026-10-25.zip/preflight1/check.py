from pathlib import Path
import base64
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
tests = ['inference_request_window_test', 'inference_request_progress_test', 'inference_output_delivery_test']
paths = ['engine/inference/request_window.h', 'engine/inference/request_progress.h',
         'engine/inference/output_delivery.h', 'engine/inference/sampling_cursor.h']
paths += ['tests/tools/'+test+'.cc' for test in tests]
contents = {name: (root/name).read_bytes() for name in paths}
pins = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in contents.items()}
payload = {name: base64.b64encode(data).decode('ascii') for name, data in contents.items()}
for name, data in contents.items():
    destination = base/'source'/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)

remote = r'''
from pathlib import Path
import base64, hashlib, json, platform, shutil, subprocess, time
model = subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()
assert model == 'Mac16,12', model
checkout = Path('/Users/kiro/project-hyle/hyle')
assert checkout.is_dir(), str(checkout)
work = checkout/'.scratch/inference-host-macos-20261025'
work.mkdir(exist_ok=False)
source = work/'source'
payload = PAYLOAD
for name, encoded in payload.items():
    path = source/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(base64.b64decode(encoded))
compiler = shutil.which('clang++')
assert compiler
facts = {'scope':'standard-library-only request host primitives; no SDK/model/GPU/HTTP',
         'model':model, 'system':platform.platform(),'machine':platform.machine(),
         'os':subprocess.check_output(['sw_vers'],text=True),
         'compiler':compiler,'version':subprocess.check_output([compiler,'--version'],text=True),
         'work':str(work),'source_pins':PINS,'results':{}}
for test in TESTS:
    directory = work/test
    directory.mkdir()
    image = directory/'checks'
    command = [compiler,'-std=c++23','-O2','-Wall','-Wextra','-Wpedantic','-Werror',
               '-MMD','-MF',str(directory/'dependencies.d'),str(source/'tests/tools'/(test+'.cc')),'-o',str(image)]
    facts['results'][test] = {}
    for stage, args in [('compile',command),('run',[str(image)])]:
        started = time.time()
        process = subprocess.run(args,cwd=source,text=True,capture_output=True,timeout=60 if stage=='compile' else 30)
        record = {'command':args,'exit':process.returncode,'seconds':time.time()-started,
                  'stdout':process.stdout,'stderr':process.stderr}
        facts['results'][test][stage] = record
        for channel in ('stdout','stderr'):
            (directory/(stage+'-'+channel+'.log')).write_text(record[channel])
        if process.returncode:
            break
facts['status'] = 'HOST_COMPONENT_ONLY_PASS' if all(len(result)==2 and all(stage['exit']==0 for stage in result.values()) for result in facts['results'].values()) else 'HOST_CHECK_FAILED'
assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==pin['sha256'] for name,pin in facts['source_pins'].items())
(work/'summary.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps(facts))
raise SystemExit(0 if facts['status']=='HOST_COMPONENT_ONLY_PASS' else 1)
'''.replace('PAYLOAD', repr(payload)).replace('PINS', repr(pins)).replace('TESTS', repr(tests))
(base/'remote-check.py').write_text(remote, encoding='utf-8')
command = ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -']
(base/'command.json').write_text(json.dumps(command)+'\n')
process = subprocess.run(command, input=remote, text=True, capture_output=True, timeout=150)
(base/'stdout.json').write_text(process.stdout, encoding='utf-8')
(base/'stderr.log').write_text(process.stderr, encoding='utf-8')
(base/'exit.json').write_text(json.dumps({'exit':process.returncode})+'\n')
if process.stdout.strip():
    facts = json.loads(process.stdout)
    (base/'summary.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
    for name, result in facts['results'].items():
        for stage, record in result.items():
            directory = base/name
            directory.mkdir(exist_ok=True)
            for channel in ('stdout','stderr'):
                (directory/(stage+'-'+channel+'.log')).write_text(record[channel],encoding='utf-8')
    print(json.dumps({'status':facts['status'],'model':facts['model'],'compiler':facts['version'].splitlines()[0],
                      'results':{name:{stage:record['exit'] for stage,record in result.items()} for name,result in facts['results'].items()}},indent=2))
else:
    print(process.stderr)
assert all((root/name).read_bytes()==data for name,data in contents.items())
raise SystemExit(process.returncode)
