"""The authorized new host case or original synthetic CUDA case, once each."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
R = Path.cwd()
D = Path(__file__).resolve().parent
T = D / 'attempt2'
mode = sys.argv[1]
assert mode in ('host', 'cuda')
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
ready = b.read(T / 'ready.json')
assert b.pin(T / 'checks.exe') == ready['image']
for pin in ready['sources']:
    assert b.pin(Path(pin['path'])) == pin
plan = b.read(D / 'check-plan.json')
env = os.environ.copy()
env['PATH'] = str(T) + ';' + b.read(R / plan['runtime_environment'].split(' PATH')[0])['PATH']
out = T / (mode + '1')
assert not out.exists(), 'Do not overwrite or rerun an actual result'
# The retained WDDM inventory lists desktop/browser C+G contexts. Root grants
# this one native correctness case; desktop activity is no idle qualification.
filter_name = plan['host_filter'] if mode == 'host' else plan['gpu_filter']
b.execute([str(T / 'checks.exe'), '--gtest_color=no', '--gtest_filter=' + filter_name,
           '--gtest_output=xml:' + str(out / 'results.xml')], out, env, 120)
tree = ET.parse(out / 'results.xml').getroot()
assert int(tree.get('tests')) == 1 and int(tree.get('failures')) == 0 and not list(tree.iter('skipped'))
summary = {'status': 'PASS', 'tests': 1, 'skips': 0, 'image': ready['image'],
           'original_weights_loaded': False, 'source_23_role_numeric_qualified': False,
           'native_context_created': mode == 'cuda', 'SDK_builds': 0, 'core_builds': 0, 'HTTP': 0}
b.save(out / 'summary.json', summary)
print(json.dumps(summary))
