"""One authorized consumer TU; retained current core/resources; no SDK build."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
R = Path.cwd()
D = Path(__file__).resolve().parent
T = D / (sys.argv[1] if len(sys.argv) > 1 else 'attempt1')
T.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
plan = b.read(D / 'check-plan.json')
expected = b.read(D / 'after-pins.json')['files']
sources = [D / 'source' / row['path'] for row in expected]
for row, path in zip(expected, sources):
    actual = b.pin(path)
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
before = [b.pin(p) for p in sources]
b.save(T / 'checked-source-pins.json', before)
base = R / '.scratch/inference-system-review-20261025/kimi-heterogeneous-state/attempt2'
original = b.args(base / 'compile/command.json')
flags = []
skip = False
for flag in original[1:]:
    if skip:
        skip = False
        continue
    if flag == '/sourceDependencies':
        skip = True
        continue
    lower = flag.lower()
    if lower.startswith(('/fo', '/fd')) or lower.endswith(('.cc', '.cpp')):
        continue
    flags.append(flag)
source = D / 'source/tests/compute_models/kimi_heterogeneous_state_consumer_test.cc'
env = b.environment(original[0])
link = b.args(base / 'link/command.json')
replacements = {str(Path(row['old_argument'])).lower(): str(R / row['new']['path'])
                for row in plan['replace_shared_objects']}
replacements[str(base / 'consumer.obj').lower()] = str(T / 'consumer.obj')
counts = {name: 0 for name in replacements}
args = []
for word in link[1:]:
    key = word.lower()
    if key in replacements:
        args.append(replacements[key])
        counts[key] += 1
    elif not key.startswith(('/out:', '/pdb:', '/implib:', '/map:')):
        args.append(word)
assert all(count == 1 for count in counts.values()), counts
library_paths = [Path(word[len('/LIBPATH:'):].strip('"')) for word in args
                 if word.upper().startswith('/LIBPATH:')]
library_paths += [Path(word) for word in env.get('LIB', '').split(';') if word]
def resolved_input(word):
    path = Path(word)
    if path.is_file():
        return path
    if not path.is_absolute() and path.suffix.lower() == '.lib':
        for directory in library_paths:
            candidate = directory / path
            if candidate.is_file():
                return candidate
    raise AssertionError(('missing retained link input', word))
for word in args:
    if not word.startswith('/') and word.lower() != str(T / 'consumer.obj').lower():
        resolved_input(word)
b.save(T / 'link-replacements.json', {'map': replacements, 'matches': counts})
for row in plan['replace_shared_objects']:
    actual = b.pin(R / row['new']['path'])
    assert actual == dict(row['new'], path=actual['path']), ('changed retained object', row)
b.execute([original[0], '/I' + str(source.parent), '/I' + str(R / 'tests/compute_models'),
           *flags, str(source), '/sourceDependencies', str(T / 'dependencies.json'),
           '/Fo' + str(T / 'consumer.obj'), '/Fd' + str(T / 'consumer.pdb')], T / 'compile', env, 120)
assert before == [b.pin(p) for p in sources], 'Private source changed during compile'
deps = b.read(T / 'dependencies.json')['Data']
selected = {str(Path(p).resolve()).lower() for p in [deps['Source'], *deps['Includes']]}
for path in sources:
    assert str(path.resolve()).lower() in selected, ('private input not compiled', path)
for row in expected:
    assert str((R / row['path']).resolve()).lower() not in selected, ('duplicate canonical input', row)
for name in ['resource_budget.h', 'resource_leases.h']:
    assert str((R / 'include/hyle/compute' / name).resolve()).lower() in selected
pins = []
for name in [deps['Source'], *deps['Includes']]:
    path = Path(name).resolve()
    if path.is_relative_to(R):
        pins.append(b.pin(path))
b.save(T / 'actual-repository-dependencies.json', pins)
b.execute([link[0], *args, '/OUT:' + str(T / 'checks.exe'), '/IMPLIB:' + str(T / 'checks.lib'),
           '/PDB:' + str(T / 'checks.pdb')], T / 'link', env, 120)
object_map = [dict(argument=arg, **b.pin(resolved_input(arg))) for arg in args if not arg.startswith('/')]
b.save(T / 'actual-link-inputs.json', object_map)
native = R / plan['native_DLL']['path']
assert b.pin(native) == dict(plan['native_DLL'], path=str(native))
os.link(native, T / native.name)
b.save(T / 'ready.json', {'image': b.pin(T / 'checks.exe'), 'object': b.pin(T / 'consumer.obj'),
                        'sources': before, 'actual_dependencies': len(pins), 'link_inputs': len(object_map),
                        'native': b.pin(native), 'SDK_builds': 0, 'core_builds': 0, 'HTTP': 0})
print(json.dumps({'status': 'READY', 'image': b.pin(T / 'checks.exe'),
                  'repository_dependencies': len(pins), 'link_inputs': len(object_map)}))
