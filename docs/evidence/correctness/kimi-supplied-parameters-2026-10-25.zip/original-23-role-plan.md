# Original Kimi attention: minimal cached-role plan

Read-only local inventory; no network, acquisition, build or execution. Fixed official source: `moonshotai/Kimi-K3@f831ab66814297da540d832a5235f8e904f29d06`.

The cached audit provides exact role/type/shape and data-relative offsets. The examined publisher/router manifest has261 source views but **zero exact target-role matches**; its layer1 FP8 f_a pair cannot substitute for official layer0/3. The original API/tree LFS/size, original shard1/4 headers and ETag/range receipts are absent from these examined caches. The old audit fetcher parsed headers but did not retain raw headers/HTTP identity.

| Component | Complete roles | Needed payload | Minimal data-relative unions (end exclusive) |
|---|---:|---:|---|
| KDA0 / model-00001-of-000096.safetensors | 14 | 887,800,832 B | [0,640000); [1454052352,2341213184) |
| MLA3 / model-00004-of-000096.safetensors | 9 | 464,406,528 B | [379857408,379871744); [379943424,844335616) |

Total23 roles **1,352,207,360B**; only4 disjoint exact unions, no expert/whole-model body. Every role name/shape/range is in the adjacent JSON. Absolute HTTP ranges remain unknown until the actual original header establishes data_base.

A genuine MLA-only source component needs only9 roles /464,406,528B; a genuine KDA-only component needs14 /887,800,832B. Both source appends together need23, but not intervening layers or model93-layer/expert banks. The6 original small F32 KDA roles total640,000B and can independently check scalar/conv math; they cannot qualify a full original KDA with synthetic projections.

Reuse the new supplied-Value appends, current complete StateStore consumer, original geometry/config facts and retained Ready SDK/object closure. A cold original adapter must pack Q/K/V conv in actual order, slice A_log128 to96 and derive absorbed K/V from original KV-b bits; it must not insert generated replacement parameters. No new IR, executor or schema is needed.

The first missing batch would be **metadata only**: fixed-revision API/tree entries for the2 files, then each8-byte prefix and exact header range, all via current guarded hf-mirror.net path. Only after validating file identity/size/strongETag and exact inventory agreement can payload ranges be computed as data_base+offset. A subsequent explicitly authorized body batch can stream these4 unions under existing per-request bounds and retain role SHA/receipt proofs. No such requests are started here.

This is a scoped local-cache conclusion, not a universal filesystem absence claim. Partial roles cannot prove the whole shard LFS hash; future numeric evidence must retain that limitation.
