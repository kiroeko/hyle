# Kimi supplied-parameter boundary

Private three-file delta and finite checks PASS; canonical source is unchanged.

The shared KDA and Kimi NoPE MLA appends consume supplied typed parameter Values; their deterministic fixture factories call the same math. The direct host case uses Fragment.input for BF16, non-square F32 and GGUF operands without allocating numeric parameter bodies.

One consumer TU compiled with /W4 /WX (4.625s) and linked retained objects (1.703s). Host case passed (0.454s). The sole CUDA process passed the existing synthetic whole-state journey (1.844s wall; six commits, one unpublished cancellation, six stale rejections, two sessions and an immutable restored fork). GPU is released. Commands, stdout/stderr, XML and exact dependencies are in attempt2.

The original independent oracles and native journey body remain unchanged. Review fixes for BF16 [N,K] versus F32/GGUF [K,N] projection shape and explicit plain F32 state validation landed before compilation. Pre-launch readiness/runner failures remain recorded and are not native test failures.

This completes supplied-parameter wiring. It does not qualify the original trained 23-role payload or full Kimi model, quality, MTP, or GPU preemption. See summary.json for exact pins, limits and original results. No further run is required for this batch.
