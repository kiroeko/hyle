from pathlib import Path
from collections import Counter
import hashlib,json,os,re,subprocess,time,uuid
root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05';ext=Path('/root/hyle-scratch/compute-unified')
job=json.loads((base/'cuda-encoded-p1/6/job.json').read_text());assert job['state']=='TERMINAL' and job['verify_exit']==0
binary=ext/'g04-cuda-encoded-p1-fresh-6/bin/g04_cuda_encoded_bench';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
aa=json.loads((ext/'g04-cuda-encoded-p1-output-6/cuda-encoded-aa.json').read_text());assert sha(binary)==aa['identity']['artifacts']['primary']
out=base/'ce20-original-peer-race-1';out.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('HYLE_BENCH_AA_ROUTE',None);env.update(HYLE_BENCH_VERIFY_ONLY='1',HYLE_PERF_RUN_NONCE=uuid.uuid4().hex)
command=['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','racecheck','--error-exitcode','86','--print-limit','0','--racecheck-num-workers','4',str(binary)]
r=dict(state='SETUP',scope='Original pinned peer safety preflight only; old HYLE arm not final CE20 acceptance, no P1 or throughput verdict',binary_sha256=sha(binary),command=command)
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
save();start=time.monotonic()
with (out/'racecheck.log').open('w') as f:
 proc=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',pid=proc.pid);save();print('original-peer-race',proc.pid,flush=True);code=proc.wait()
log=(out/'racecheck.log').read_text();errors=re.findall(r'# CUDA_ENCODED_CORRECTNESS max_abs_error=([^ ]+)',log)
assert len(errors)==24 and max(map(float,errors))<=8e-3 and log.count('# CUDA_FP8_PAIR ')==3
assert sha(binary)==r['binary_sha256']
counts=Counter()
for line in log.splitlines():
 if not line.startswith(('========= Error:','========= Warning:')):continue
 route='original_peer' if 'hyle_benchmark_original_flashinfer_69ff::' in line else 'old_hyle' if 'flashinfer::' in line else 'other'
 kind='warning' if line.startswith('========= Warning:') else 'error';counts[(route,kind)]+=1
r.update(state='TERMINAL_FINITE_PEER_SAFETY_RESULT',exit_code=code,elapsed_seconds=time.monotonic()-start,
 max_abs_error=max(map(float,errors)),diagnostic_counts={':'.join(k):v for k,v in counts.items()},
 summaries=[line for line in log.splitlines() if 'SUMMARY:' in line]);r.pop('pid',None);save();print(json.dumps(r))
