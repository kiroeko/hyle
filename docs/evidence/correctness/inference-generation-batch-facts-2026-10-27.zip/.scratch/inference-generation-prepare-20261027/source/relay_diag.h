#pragma once

// Included only by the scratch Model TU, inside namespace qwen35. These are
// serialized host-call wall clocks, never GPU durations or CPU busy-time.
namespace relay_diag {
enum class Metric : std::size_t {
  kPrepareTotal, kDirectPrepareCall, kRelayPrepareCall, kHelperReuseQuery,
  kSourceMetadata, kOriginalSubmit, kWholeSource, kTokenCapture, kStoreCapture,
  kKvCapture, kFinishTotal, kOriginalWait, kFinishPostWait, kPublishTakeCommit,
  kReleaseInputs, kGenerationObserve, kPrepareLayout, kPrepareBind, kPrepareReplay, kCount
};
inline constexpr std::size_t metric_count = static_cast<std::size_t>(Metric::kCount);
inline constexpr const char *metric_names[metric_count]{
  "model_prepare_total", "direct_prepare_call", "relay_prepare_call", "helper_reuse_query",
  "source_metadata", "original_submit", "whole_source_create", "token_capture", "store_capture",
  "kv_capture", "finish_total", "original_wait", "finish_post_wait", "publish_take_commit",
  "release_inputs", "generation_host_observe", "prepare_layout_admission",
  "prepare_batch_source_slot_bind", "prepare_replay"
};
struct Measure final { double seconds = 0; std::size_t calls = 0; };
struct Episode final {
  bool active = false;
  std::size_t ordinal = 0, recorded = 0, reused = 0;
  int pair_role = 0;
  std::array<Measure, metric_count> values{};
  void add_elapsed(Metric metric, double elapsed) noexcept {
    if (!active) return;
    auto &value = values[static_cast<std::size_t>(metric)];
    value.seconds += elapsed; ++value.calls;
  }
  void add(Metric metric, Clock::time_point begin) noexcept {
    if (!active) return;
    auto &value = values[static_cast<std::size_t>(metric)];
    value.seconds += std::chrono::duration<double>(Clock::now() - begin).count(); ++value.calls;
  }
};
struct Bucket final {
  std::size_t episodes = 0, completed = 0, recorded = 0, reused = 0;
  std::array<Measure, metric_count> values{};
};
struct State final {
  std::size_t prepared = 0;
  int last_bucket = -1;
  std::array<Bucket, 4> buckets{};
};
inline State state;
struct Timer final {
  Episode &episode;
  Metric metric;
  Clock::time_point begin{};
  Timer(Episode &value, Metric selected) noexcept : episode(value), metric(selected) {
    if (episode.active) begin = Clock::now();
  }
  ~Timer() { if (episode.active) episode.add(metric, begin); }
};
struct FinishSample final {
  Episode episode;
  bool completed = false;
  std::optional<Clock::time_point> post_wait;
  explicit FinishSample(const Episode &value) : episode(value) {}
  ~FinishSample() {
    if (!episode.active) { state.last_bucket = -1; return; }
    if (post_wait) episode.add(Metric::kFinishPostWait, *post_wait);
    const int selected = episode.ordinal < 8 ? 0 : episode.pair_role == 1 ? 2 : episode.pair_role == 2 ? 3 : 1;
    state.last_bucket = selected;
    auto &bucket = state.buckets[static_cast<std::size_t>(selected)];
    ++bucket.episodes; bucket.completed += completed ? 1 : 0;
    bucket.recorded += episode.recorded; bucket.reused += episode.reused;
    for (std::size_t index = 0; index < metric_count; ++index) {
      bucket.values[index].seconds += episode.values[index].seconds;
      bucket.values[index].calls += episode.values[index].calls;
    }
  }
};
struct DirectTimer final {
  int selected = -1;
  Metric metric;
  Clock::time_point begin{};
  DirectTimer(bool active, Metric value) noexcept : metric(value) {
    if (active) selected = state.last_bucket;
    if (selected >= 0) begin = Clock::now();
  }
  ~DirectTimer() {
    if (selected < 0) return;
    auto &value = state.buckets[static_cast<std::size_t>(selected)].values[static_cast<std::size_t>(metric)];
    value.seconds += std::chrono::duration<double>(Clock::now() - begin).count(); ++value.calls;
  }
};
struct Report final {
  ~Report() noexcept {
    try {
      const char *names[]{"first8_decode", "steady_single", "steady_pair_a", "steady_pair_b"};
      std::cerr << "RELAY_DIAG {\"version\":1,\"scope\":\"R1 ordinary T1 host-call wall\","
          "\"gpu_duration\":false,\"cpu_busy_time\":false,\"nested_buckets_not_additive\":true,"
          "\"prepared_decode_steps\":" << state.prepared << ",\"buckets\":[";
      for (std::size_t index = 0; index < state.buckets.size(); ++index) {
        const auto &bucket = state.buckets[index];
        std::cerr << (index ? "," : "") << "{\"name\":\"" << names[index]
            << "\",\"episodes\":" << bucket.episodes << ",\"completed\":" << bucket.completed
            << ",\"capture_recorded\":" << bucket.recorded << ",\"capture_reused\":" << bucket.reused
            << ",\"metrics\":{";
        for (std::size_t item = 0; item < metric_count; ++item)
          std::cerr << (item ? "," : "") << '\"' << metric_names[item] << "\":{\"seconds\":"
              << bucket.values[item].seconds << ",\"calls\":" << bucket.values[item].calls << '}';
        std::cerr << "}}";
      }
      std::cerr << "]}\n";
    } catch (...) {}
  }
};
} // namespace relay_diag
