from pathlib import Path
import json

W = Path(__file__).resolve().parent
keys = ['model_prepare_total', 'prepare_layout_admission', 'prepare_batch_source_slot_bind', 'prepare_replay']
result = {}
for mode in ['off', 'auto']:
    data = json.loads((W / ('run-' + mode) / 'diagnostic.json').read_text(encoding='utf8'))
    groups = {'first8': data['buckets'][:1], 'remaining88': data['buckets'][1:], 'all96': data['buckets']}
    summaries = {}
    for name, buckets in groups.items():
        values = {key: sum(bucket['metrics'][key]['seconds'] for bucket in buckets) for key in keys}
        values['residual'] = values['model_prepare_total'] - sum(values[key] for key in keys[1:])
        summaries[name] = dict(episodes=sum(bucket['episodes'] for bucket in buckets),
            recorded=sum(bucket['capture_recorded'] for bucket in buckets), seconds=values)
    summaries['steady_bucket_means_us'] = {
        bucket['name']: dict(episodes=bucket['episodes'], metrics={key:
            bucket['metrics'][key]['seconds'] * 1e6 / bucket['episodes'] if bucket['episodes'] else 0
            for key in keys}) for bucket in data['buckets'][1:]}
    summaries['source_metadata_and_capture_seconds'] = sum(
        bucket['metrics'][key]['seconds'] for bucket in data['buckets'] for key in
        ['source_metadata', 'whole_source_create', 'token_capture', 'store_capture', 'kv_capture'])
    result[mode] = summaries
result['auto_minus_off_seconds'] = {group: {key:
    result['auto'][group]['seconds'][key] - result['off'][group]['seconds'][key]
    for key in [*keys, 'residual']} for group in ['first8', 'remaining88', 'all96']}
result['contract'] = dict(base_product='Model3 3069eb808b3908b034283268a3002cad515940c9af781651897c6f39e6cac1b9 with A query retained',
    first8='Actual first eight decode ordinals, includes the first pair A. Remaining88 is A43+B44+tail1 for auto and88 singles for off.',
    timings='Host-call wall only. Three prepare phases are disjoint; residual=model_prepare_total minus phases. Do not add these children to their parent prepare total.',
    sources='Source prepare/create/capture is measured outside Model prepare and must not be added twice.',
    comparison='This is one diagnostic off/auto pair, not an exact decomposition of a different previous run or an update to formal TPS.',
    gpu='Both original97 IDs/full non-timefacts passed; two processes only; GPU released.')
(W / 'analysis-summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
print(json.dumps(result['auto_minus_off_seconds'], indent=2))
