from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
P = R / '.scratch/inference-generation-continuation-20261027'
BASE = P / 'diag'
spec = importlib.util.spec_from_file_location('prior_build', P / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, h = m.b, m.h


def prepare():
    assert not (W / 'plan.json').exists()
    baseline = b.read(BASE / 'ready.json')
    for row in [baseline['source'], baseline['header'], baseline['actual_dependencies']]:
        b.exact(row)
    source = Path(baseline['source']['path']).read_text(encoding='utf8')
    header = Path(baseline['header']['path']).read_text(encoding='utf8')
    before_source, before_header = source, header
    old = '      const auto replay_end = Clock::now();\n'
    new = old + '''      step.diagnostic.add_elapsed(relay_diag::Metric::kPrepareLayout,
          std::chrono::duration<double>(batch_start - cold_start).count());
      step.diagnostic.add_elapsed(relay_diag::Metric::kPrepareBind,
          std::chrono::duration<double>(batch_end - batch_start).count());
      step.diagnostic.add_elapsed(relay_diag::Metric::kPrepareReplay,
          std::chrono::duration<double>(replay_end - batch_end).count());
'''
    assert source.count(old) == 1
    source = source.replace(old, new)
    assert header.count('  kReleaseInputs, kGenerationObserve, kCount') == 1
    header = header.replace('  kReleaseInputs, kGenerationObserve, kCount',
        '  kReleaseInputs, kGenerationObserve, kPrepareLayout, kPrepareBind, kPrepareReplay, kCount')
    assert header.count('  "release_inputs", "generation_host_observe"') == 1
    header = header.replace('  "release_inputs", "generation_host_observe"',
        '  "release_inputs", "generation_host_observe", "prepare_layout_admission",\n'
        '  "prepare_batch_source_slot_bind", "prepare_replay"')
    old = '  void add(Metric metric, Clock::time_point begin) noexcept {\n'
    new = '''  void add_elapsed(Metric metric, double elapsed) noexcept {
    if (!active) return;
    auto &value = values[static_cast<std::size_t>(metric)];
    value.seconds += elapsed; ++value.calls;
  }
''' + old
    assert header.count(old) == 1
    header = header.replace(old, new)
    target = W / 'source'
    target.mkdir(parents=True, exist_ok=True)
    (target / 'main.cc').write_bytes(source.encode('utf8'))
    (target / 'relay_diag.h').write_bytes(header.encode('utf8'))
    patch = ''.join(difflib.unified_diff(before_source.splitlines(keepends=True), source.splitlines(keepends=True),
        fromfile='previous-diag/main.cc', tofile='source/main.cc'))
    patch += ''.join(difflib.unified_diff(before_header.splitlines(keepends=True), header.splitlines(keepends=True),
        fromfile='previous-diag/relay_diag.h', tofile='source/relay_diag.h'))
    (target / 'three-buckets.patch').write_bytes(patch.encode('utf8'))
    current = b.read(P / 'ready7.json')
    model = next(row for row in current['compiled'] if row['name'] == 'model4')
    command = b.read(BASE / 'compile-recipe.json')['command']
    command = [arg.replace(str(BASE / 'compile/model'), str(W / 'compile/model'))
        .replace(str(BASE / 'source/main.cc'), str(target / 'main.cc')) for arg in command]
    b.save(W / 'recipe.json', dict(command=command, original_recipe=b.pin(BASE / 'compile-recipe.json')))
    b.save(W / 'plan.json', dict(source=b.pin(target / 'main.cc'), header=b.pin(target / 'relay_diag.h'),
        patch=b.pin(target / 'three-buckets.patch'), baseline_diagnostic=b.pin(BASE / 'ready.json'),
        base_product_snapshot=b.read(BASE / 'source-identity.json')['original']['snapshot'],
        base_source='Frozen Model3 3069eb808b3908b034283268a3002cad515940c9af781651897c6f39e6cac1b9; A helper query retained.',
        base_dependencies=baseline['actual_dependencies'], current_closure=b.pin(P / 'ready7.json'),
        original_object=model['object'], inputs=b.pin(P / 'cli-link-inputs7.json'),
        scope='Only 3 duration accumulations at pre-existing Clock points. No new timestamps or algorithm/permission changes. First8 actual ordinals, steady single/A43/B44 classification retained. Residual is model_prepare_total minus three buckets. No product-source read/hash dependency during build.'))
    print('PREPARED frozen Model3 diagnostic + three existing-timepoint buckets', flush=True)


def build():
    plan = b.read(W / 'plan.json')
    for row in [plan['source'], plan['header'], plan['base_product_snapshot'], plan['original_object'], plan['inputs']]:
        b.exact(row)
    previous_deps = b.read(plan['base_dependencies']['path'])
    stable = {b.key(row['path']): row for row in previous_deps
        if b.key(row['path']) not in {b.key(BASE / 'source/main.cc'), b.key(BASE / 'source/relay_diag.h')}}
    for row in stable.values(): b.exact(row)
    out = W / 'compile/model'
    out.mkdir(parents=True, exist_ok=False)
    process = h.execute(b.read(W / 'recipe.json')['command'], m.env(), W / 'logs/model', timeout=180)
    b.exact(plan['source']); b.exact(plan['header'])
    raw = b.read(out / 'dependencies.json')['Data']
    deps = [b.pin(path) for path in dict.fromkeys([raw['Source'], *raw['Includes']])]
    for row in deps:
        key = b.key(row['path'])
        if key in stable: assert row == stable[key], row['path']
        else: assert key in {b.key(plan['source']['path']), b.key(plan['header']['path'])}, row['path']
    assert stable.keys() <= {b.key(row['path']) for row in deps}
    b.save(out / 'actual-dependencies.json', deps)
    obj = b.pin(out / 'unit.obj')
    b.save(out / 'compiled.json', dict(source=plan['source'], header=plan['header'], object=obj,
        process=process, actual_dependencies=b.pin(out / 'actual-dependencies.json')))
    inputs = []
    replacements = 0
    for row in b.read(plan['inputs']['path']):
        if b.key(row['path']) == b.key(plan['original_object']['path']): row = obj; replacements += 1
        b.exact(row); inputs.append(row)
    assert len(inputs) == 224 and replacements == 1
    b.save(W / 'link-inputs.json', inputs)
    image = W / 'bin/hyle-prepare-diag.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    command = b.read(P / 'link-cli7/command.json')['command']
    command = [obj['path'] if b.key(arg) == b.key(plan['original_object']['path'])
        else '/OUT:' + str(image) if arg.upper().startswith('/OUT:') else arg for arg in command]
    link = h.execute(command, m.env(), W / 'link', timeout=120)
    b.save(W / 'ready.json', dict(status='LINKED_NOT_RUN', image=b.pin(image), object=obj,
        compiler_process=process, linker_process=link, source=plan['source'], header=plan['header'],
        base_product_snapshot=plan['base_product_snapshot'], base_source=plan['base_source'],
        reused_closure=plan['current_closure'], replaced_object=plan['original_object'],
        inputs=b.pin(W / 'link-inputs.json'), actual_dependencies=b.pin(out / 'actual-dependencies.json'),
        compiler_attempts=1, links=1, gpu_runs=0))
    run_plan = b.read(BASE / 'run-plan.json')
    for run in run_plan['runs']:
        run['command'][0] = str(image)
        run['output_directory'] = str(W / ('run-' + run['mode']))
    run_plan['scope'] = 'Commands prepared only, no execution. Frozen Model3/query baseline plus three existing-clock buckets; current ready7 resources/SDK.'
    b.save(W / 'run-plan.json', run_plan)
    print('READY: 1 Model CXX + 1 link, 224 inputs, no GPU run', flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'prepare': prepare()
    elif sys.argv[1] == 'build': build()
    else: raise ValueError(sys.argv[1])
