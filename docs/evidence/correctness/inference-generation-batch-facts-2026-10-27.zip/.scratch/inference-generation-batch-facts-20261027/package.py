from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
D = R / '.scratch/inference-generation-prepare-20261027'
BASE = R / '.scratch/inference-generation-continuation-20261027'
CORRECT = R / 'docs/evidence/correctness/inference-generation-batch-facts-2026-10-27.json'
PERF = R / 'docs/evidence/performance/inference-generation-prepare-2026-10-27.json'
ZIP = CORRECT.with_suffix('.zip')
cache = {}

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    path = Path(path).resolve()
    key = str(path).casefold()
    if key not in cache:
        data = path.read_bytes()
        cache[key] = dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return dict(cache[key])

def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), (row, actual)
    return actual

def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def compact(value, depth=0):
    if depth >= 2 or not isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    if isinstance(value, dict):
        if not value: return '{}'
        body = [('  '*(depth+1) + json.dumps(k, ensure_ascii=False) + ': ' + compact(v, depth+1)) for k,v in value.items()]
        return '{\n' + ',\n'.join(body) + '\n' + '  '*depth + '}'
    if not value: return '[]'
    return '[\n' + ',\n'.join('  '*(depth+1) + compact(v, depth+1) for v in value) + '\n' + '  '*depth + ']'

def non_time(value, diagnostic=False):
    ignored = {'cache_shared_backing_bytes','cache_live_requested_bytes','cache_peak_requested_bytes',
        'cache_requested_byte_limit','cache_metadata_requested_bytes','cache_retained_output_backing_bytes'} if diagnostic else set()
    if isinstance(value, list): return [non_time(x, diagnostic) for x in value]
    if isinstance(value, dict):
        return {k: non_time(v, diagnostic) for k,v in value.items() if k not in ignored and
            not any(x in k for x in ['seconds','per_second','capture','replay','trace_name'])}
    return value

ready = {name: read(W / ('ready-'+name+'.json')) for name in ['relay1','facts1']}
expected = {
    'model1': 'e3e71d796184fc496c4531022d825265769585edcac58f203c7e0221b8bc202d',
    'facts1': 'e76b59314c3624e9d699996fb3db6a00e462204e3c77f79e0ed9b7425224c1ed',
    'relay1': '584245551ea2d7795c11c22e1ef38b4f4fea123467739117219e5ca5ed89a7e6'}
units = {unit['name']: unit for rec in ready.values() for unit in rec['compiled']}
audit_units = []
for name, unit in units.items():
    assert unit['source']['sha256'] == unit['snapshot']['sha256'] == expected[name]
    for key in ['source','snapshot','object','dependencies']: exact(unit[key])
    deps = read(unit['dependencies']['path'])
    for dep in deps: exact(dep)
    assert unit['process']['exit'] == 0
    audit_units.append(dict(name=name, source=unit['source'], snapshot=unit['snapshot'],
        object=unit['object'], dependency_manifest=unit['dependencies'], dependency_count=len(deps),
        all_actual_dependency_bytes_match_current_files=True, process=unit['process']))

# Only final files are rehashed. The relay1 CLI was overwritten by facts1 at the same path.
for version, name in [('facts1','cli'),('facts1','probe'),('relay1','probe')]:
    exact(next(x for x in ready[version]['artifacts'] if x['name']==name)['image'])
for version, record in ready.items():
    exact(record['runtime'])
    for artifact in record['artifacts']:
        exact(artifact['inputs']); rows=read(artifact['inputs']['path'])
        assert len(rows) == (224 if artifact['name']=='cli' else 223)
        for row in rows: exact(row)
        assert artifact['process']['exit'] == 0

runs = []
for directory in sorted((W/'runs').iterdir()):
    result = read(directory/'result.json'); exact(result['report'])
    report = read(directory/'report.json')
    assert read(directory/'stdout.log') == report
    assert result['process']['exit'] == read(directory/'process.json')['exit'] == 0
    version = 'facts1' if directory.name.startswith('facts-') or directory.name=='long-auto' else 'relay1'
    kind = 'probe' if directory.name.startswith(('facts-','relay-')) else 'cli'
    image = next(x['image'] for x in ready[version]['artifacts'] if x['name']==kind)
    row = dict(name=directory.name, ready=version, image=image, process=result['process'], report=result['report'])
    if directory.name.startswith('facts-'):
        assert report['status']=='PASS' and report['cases']==3
        for key in ['original_request_keys','bounded_output_credit','controlled_child_maps_to_B',
                    'controlled_error_actually_retired','ledger_and_outputs_checked']:
            assert report[key] is True
        assert report['mixed_width_graphs']==2 and report['mixed_width_rows']==5
        assert report['same_width_graphs']==1 and report['same_width_rows']==6
        assert report['controlled_error_submits']==1 and report['final_live_versions']==0
        row['facts']=report
    elif directory.name.startswith('relay-'):
        expected_arms=10 if directory.name=='relay-real' else 8
        assert report['status']=='PASS' and report['serial_and_relay_arms']==expected_arms
        assert report['complete_state_equal'] and report['final_live_versions']==0
        if directory.name=='relay-real':
            assert report['late_extra_stop_run']
            assert report['continuations'][-1]['successor_submissions']==1
            assert report['continuations'][-1]['successor_publications']==0
            assert report['continuations'][-1]['successor_discards']==1
        row['facts']=report
    else:
        prior = BASE/'runs'/('final-long' if directory.name=='long-auto' else directory.name)/'report.json'
        assert non_time(report)==non_time(read(prior)), directory.name
        row['complete_non_time_report_equal_to']=pin(prior)
        if directory.name=='long-auto':
            assert report['generated_tokens']==97 and report['generated_decode_tokens']==96
            assert report['overlap_successor_submissions']==report['overlap_successor_publications']==44
            assert report['overlap_successor_discards']==report['overlap_successor_refusals']==0
        row['facts']={k:report[k] for k in ['generated_tokens','generated_decode_tokens','actual_graph_calls',
            'prefill_graph_calls','decode_graph_calls','graph_participations','logical_dispatches',
            'overlap_successor_submissions','overlap_successor_publications','overlap_successor_discards',
            'overlap_successor_refusals','live_committed_versions']}
    runs.append(row)
assert len(runs)==9

# Diagnostic uses its frozen Model3-derived snapshot, not the current product main.
diag_ready=read(D/'ready.json'); plan=read(D/'plan.json'); summary=read(D/'run-summary.json')
analysis=read(D/'analysis-summary.json'); run_plan=read(D/'run-plan.json')
for key in ['image','object','source','header','base_product_snapshot','inputs','actual_dependencies']:
    exact(diag_ready[key])
for dep in read(diag_ready['actual_dependencies']['path']): exact(dep)
for row in read(diag_ready['inputs']['path']): exact(row)
assert len(read(diag_ready['inputs']['path']))==224
assert summary['status']=='PASS' and summary['processes']==2
exact(run_plan['oracle']); oracle=read(run_plan['oracle']['path'])
for row in summary['runs']:
    assert row['process']['exit']==0
    for key in ['report','diagnostic','image']: exact(row[key])
    report=read(row['report']['path']); diagnostic=read(row['diagnostic']['path'])
    assert non_time(report['sessions'][0]['result'],True)==oracle
    assert report['generated_tokens']==len(report['sessions'][0]['result']['generated_ids'])==97
    assert diagnostic['prepared_decode_steps']==96
    assert sum(b['episodes'] for b in diagnostic['buckets'])==96
    assert sum(b['completed'] for b in diagnostic['buckets'])==96
    mode=row['mode']
    for group,buckets in [('first8',diagnostic['buckets'][:1]),('remaining88',diagnostic['buckets'][1:]),('all96',diagnostic['buckets'])]:
        value=analysis[mode][group]
        assert value['episodes']==sum(b['episodes'] for b in buckets)
        assert value['recorded']==sum(b['capture_recorded'] for b in buckets)
        for key in ['model_prepare_total','prepare_layout_admission','prepare_batch_source_slot_bind','prepare_replay']:
            assert abs(value['seconds'][key]-sum(b['metrics'][key]['seconds'] for b in buckets))<1e-12

# Preserve actual inherited auxiliary linker outputs; never rewrite as-run commands.
aux=[]
all_inputs={str(Path(x['path']).resolve()).casefold() for rec in ready.values() for a in rec['artifacts']
            for x in read(a['inputs']['path'])}
all_inputs.update(str(Path(x['path']).resolve()).casefold() for x in read(diag_ready['inputs']['path']))
for command_path in [*W.glob('link-*/command.json'), D/'link/command.json']:
    command=read(command_path)['command']
    outputs=[x for x in command if x.upper().startswith(('/OUT:','/PDB:','/IMPLIB:'))]
    for arg in outputs:
        if arg.upper().startswith('/IMPLIB:'):
            path=Path(arg.split(':',1)[1]); assert str(path.resolve()).casefold() not in all_inputs
            assert str(path.with_suffix('.exp').resolve()).casefold() not in all_inputs
    aux.append(dict(command=pin(command_path), outputs=outputs, inherited_lib_and_exp_not_actual_link_inputs=True))

# Current CMake is registration evidence only; no new CMake configure/build was performed.
cmake=W/'source/cmake/CMakeLists.txt'; cmake.parent.mkdir(parents=True,exist_ok=True)
cmake.write_bytes((R/'tests/CMakeLists.txt').read_bytes())
assert 'if(TARGET hyle_engine)\n  add_executable(hyle_qwen_generation_batch_facts_probe' in cmake.read_text()
base_snapshot=D/'source/base-product-main.cc'
base_snapshot.write_bytes(Path(diag_ready['base_product_snapshot']['path']).read_bytes())
assert pin(base_snapshot)['sha256']==diag_ready['base_product_snapshot']['sha256']
audit=dict(status='PASS', operation='Offline receipt/archive validation only; no build, model run or cleanup',
    current_product=pin(R/'engine/models/qwen35/main.cc'), current_test_registration=pin(R/'tests/CMakeLists.txt'),
    compiled_units=audit_units, runs=runs,
    actual_image_assignment='Root confirmed as-run argv: regression relay1; long facts1; each probe its own ready. File times independently place all regressions before facts1 relink.',
    overwritten_cli='ready-relay1 d1a181... is a preserved historical pin; only final facts1 c9fd07... was rehashed. Equal CLI input lists do not imply identical PE hash.',
    diagnostic_actual_dependencies=diag_ready['actual_dependencies'], diagnostic_run_summary=pin(D/'run-summary.json'),
    inherited_link_auxiliary_outputs=aux, auxiliary_output_note='As-run /PDB and /IMPLIB retain historical model-submission-source paths. No relink/rewrite was done. Their lib/exp are not actual inputs. Future recipes should isolate all output paths.')
save(W/'package-verification.json',audit)

members={}
allowed={'.py','.json','.log','.xml','.cc','.h','.txt','.patch','.diff','.ps1'}
for folder in [W,D]:
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.suffix.lower() in allowed and path.name not in ['running.json','runs-partial.json','package-result.json']:
            members[path.relative_to(R).as_posix()]=path.read_bytes()
for path in [BASE/'screen-oracle.json',BASE/'runtime.json',BASE/'build.py',
    *[BASE/'runs'/('final-long' if row['name']=='long-auto' else row['name'])/'report.json'
      for row in runs if 'complete_non_time_report_equal_to' in row]]:
    members[path.relative_to(R).as_posix()]=path.read_bytes()
manifest=dict(format='sha256+bytes for every archive member except this manifest',
    files=[dict(path=k,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(members.items())],
    exclusions=['exe','obj','pdb','dll','lib','exp','SDK sources','model payload','transient running markers'],
    historical_image_policy=audit['overwritten_cli'])
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
ZIP.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()): z.writestr(name,data)
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(members)
    for row in manifest['files']:
        value=z.read(row['path'])
        assert len(value)==row['bytes'] and hashlib.sha256(value).hexdigest()==row['sha256']
archive=pin(ZIP); archive.update(members=len(members), uncompressed_bytes=sum(map(len,members.values())), all_members_read_back_and_verified=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
common=dict(date='2026-10-27', platform='Windows x64; MSVC 14.50.35717 /O2 /MD /W4 /WX; existing CUDA13.3 runtime, RTX4070 CC8.9/12281MiB from run logs',
    base_head=head, archive=archive, archive_relative_link='../correctness/'+ZIP.name)
correct=dict(schema='hyle.inference-generation-batch-facts.v1',status='PASS',**common,
    scope='Actual child-batch observations and request-owner accounting; finite CPU/CUDA consumers. Statistics correctness, no TPS improvement claim.',
    current_sources=[pin(R/'engine/models/qwen35/main.cc'),pin(R/'tests/tools/qwen_generation_batch_facts_probe.cc'),pin(R/'tests/CMakeLists.txt')],
    changes=[
        'One borrowed GenerationBatchFacts per actual completed child: role/completion/generation/input rows/original members/step_seconds; no retained temporary span.',
        'Request owner copies original keys and consumes facts for actual Graph counts, rows and step sum. Outer bucket keeps wall/peak/selected-return accounting; physical_episodes removed.',
        'Mixed-width verifier groups forward the same observer; child EvaluationFailure participant maps through members to its parent while preserving original Status and typed real retirement.',
        'Full-prefix hit keeps its logical dispatch without inventing a physical Graph call. Target duration counted once, plus every serial proposal duration.',
        'Ordinary continuation reports A/B separately only after their original finish; accepted discarded B observed only after actual abort/retirement. Existing AfterSubmit ordering remains.'],
    build=dict(fresh_cxx=3,links=4,units=audit_units,
        reuse='224-input CLI and223-input combined probes reuse existing SDK/native objects; probe includes main, no duplicate Model object.',
        image_assignment='Four regressions: relay1 historical CLI. Long: facts1 final CLI. Facts and relay probes use their separate images; exact assignments in package-verification.json.',
        auxiliary_outputs=audit['auxiliary_output_note'], cmake='Probe target registered under TARGET hyle_engine; standalone manual compile/link is the tested path, no fresh CMake configure.'),
    tests=dict(processes=9, facts_processes=[dict(name=x['name'],process=x['process'],facts=x['facts']) for x in runs if x['name'].startswith('facts-')],
        cli_regressions=[dict(name=x['name'],process=x['process'],facts=x['facts'],complete_non_time_report_equal=True) for x in runs if x['name'].startswith('regression-')],
        relay=[dict(name=x['name'],process=x['process'],prompt=x['facts']['prompt_tokens'],arms=x['facts']['serial_and_relay_arms'],complete_state_equal=True,
            late_extra_stop=x['facts']['late_extra_stop_run'],continuations=x['facts']['continuations']) for x in runs if x['name'].startswith('relay-')],
        long=[dict(process=x['process'],facts=x['facts'],complete_non_time_report_equal=True) for x in runs if x['name']=='long-auto']),
    oracle='Complete JSON report comparison uses the exact run.py recursive exclusions: keys containing seconds/per_second/capture/replay/trace_name; no other facts dropped for current regression/long comparisons.',
    diagnostic='Separate old-Model3 prepare diagnosis has its own performance receipt and shares this archive; it does not validate current-main performance.',
    limitations=['No new genuine natural-EOS variable-width run; width mismatch is a controlled real verifier fixture.',
        'Controlled AfterSubmit error is not hardware/device fault injection; observer-throw paths are source-reviewed, not a new runtime fault matrix.',
        'No new Apple/Vulkan, multi-Queue, continuous full pipeline, HTTP/server or MTP throughput result.',
        'No new download/SDK/shader/NVCC build. Full-prefix dispatch and every proposal-time branch are source-reviewed plus full non-time report regression, not independently injected timing oracles.'])
perf=dict(schema='hyle.inference-generation-prepare-diagnostic.v1',status='PASS',**common,
    scope='One off/auto diagnostic pair using frozen old Model3 with retained A query; three existing-clock prepare buckets. Not current-main TPS or CPU-busy/GPU-time measurement.',
    actual_build=dict(source=diag_ready['source'],header=diag_ready['header'],base_product_snapshot=diag_ready['base_product_snapshot'],
        image=diag_ready['image'],compiler_process=diag_ready['compiler_process'],linker_process=diag_ready['linker_process'],
        inputs=diag_ready['inputs'],actual_dependencies=diag_ready['actual_dependencies'],fresh_cxx=1,links=1),
    runs=summary['runs'],
    correctness='Both processes preserve exact97 IDs and complete original screen session-result facts (same original six cache-accounting exclusions plus time/replay keys); decode96, zero refusals/discards, zero live versions; auto44 publications.',
    measurements=analysis,
    interpretation=[
        'Three child prepare phases are disjoint; residual=Model prepare total minus those phases. Do not add children again to the parent total.',
        'First8 actual decode ordinals include first pair A. Remaining88 auto=A43+B44+tail1, off=88 singles; capture recordings first8 off1/auto5 and steady0.',
        'Source metadata/create/capture is outside Model prepare; do not double-count it. One off/auto observation does not establish statistical significance.',
        'Host-call durations may contain waits. They are not CPU utilization or GPU duration, and cannot decompose a separate earlier measurement window.',
        'No refreshed formal TPS result; current batch-facts fix is correctness/accounting only, and current main has removed the redundant A query retained in this diagnostic.'],
    limitations=['No additional samples, memory peak study, new reference-engine peer, MTP performance, native-fault or cross-platform diagnosis.',
        'Raw ready.json is a build-stage LINKED_NOT_RUN record; subsequent run-summary/process/log records establish the two actual successful runs.'])
for path,value in [(CORRECT,correct),(PERF,perf)]:
    text=compact(value)+'\n'; assert len(text.splitlines())<=200,(path,len(text.splitlines()))
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8')
result=dict(status='PASS',outputs=[pin(CORRECT),pin(ZIP),pin(PERF)],zip_members=len(members),
    uncompressed_bytes=sum(map(len,members.values())),member_hashes_verified=True,
    public_json_lines={str(p.relative_to(R)):len(p.read_text().splitlines()) for p in [CORRECT,PERF]})
save(W/'package-result.json',result)
print(json.dumps(result,indent=2))
