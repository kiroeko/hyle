from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('facts_build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m);b,h=m.b,m.h
ready=b.read(W/('ready-'+sys.argv[2]+'.json'))
needed='probe' if sys.argv[1] in ['facts','relay'] else 'cli'
for item in ready['artifacts']:
    if item['name']==needed:b.exact(item['image'])
def run(name,command):
    out=W/'runs'/name;process=h.execute(command,m.env(),out,timeout=180)
    report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
    b.save(out/'report.json',report);b.save(out/'result.json',dict(process=process,report=b.pin(out/'report.json')))
    print('PASS '+name+' '+json.dumps({k:report.get(k) for k in ['status','cases','backend',
        'actual_graph_calls','generated_tokens','overlap_successor_publications','serial_and_relay_arms']}),flush=True)
    return report
def facts(value):
    if isinstance(value,list):return [facts(x) for x in value]
    if isinstance(value,dict):return {k:facts(v) for k,v in value.items()
        if not any(x in k for x in ['seconds','per_second','capture','replay','trace_name'])}
    return value
tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
real=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
cli=next(x['image']['path'] for x in ready['artifacts'] if x['name']=='cli')
probe=next(x['image']['path'] for x in ready['artifacts'] if x['name']=='probe')
if sys.argv[1]=='facts':
    for backend in ['cpu','cuda']:run('facts-'+backend,[probe,'--'+backend,str(tiny)])
elif sys.argv[1]=='relay':
    for name,input in [('tiny',tiny),('real',real)]:run('relay-'+name,[probe,'--cuda',str(input)])
elif sys.argv[1]=='regression':
    for row in b.read(R/'.scratch/inference-metadata-queue-20261027/run-plan.json')['cli']:
        command=row['command'][:];command[0]=cli
        report=run('regression-'+row['name'],command)
        before=b.read(R/'.scratch/inference-generation-continuation-20261027/runs'/('regression-'+row['name'])/'report.json')
        assert facts(report)==facts(before),row['name']
elif sys.argv[1]=='long':
    report=run('long-auto',[cli,'--inputs',str(real),'--backend','cuda','--mtp','off',
        '--capacity','256','--steps','97','--max-sessions','1','--active-sequences','1','--decode-overlap','auto'])
    before=b.read(R/'.scratch/inference-generation-continuation-20261027/runs/final-long/report.json')
    assert facts(report)==facts(before),'complete non-time long-auto report changed'
    assert report['overlap_successor_publications']==44 and report['live_committed_versions']==0
else:raise ValueError(sys.argv[1])
