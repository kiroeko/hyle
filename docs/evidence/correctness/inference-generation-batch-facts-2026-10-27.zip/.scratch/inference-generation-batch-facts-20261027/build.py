from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-generation-continuation-20261027'
s=importlib.util.spec_from_file_location('facts_baseline',BASE/'build.py')
p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
b,h=p.b,p.h
def env():
    result=p.env();result['PATH']=str(W/'bin')+';'+result['PATH'];return result
def compile_unit(kind,attempt):
    name=kind+attempt;out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
    prior='model4' if kind=='model' else 'probe7'
    prior_source=R/('engine/models/qwen35/main.cc' if kind=='model' else 'tests/tools/qwen_generation_relay_probe.cc')
    source=R/('engine/models/qwen35/main.cc' if kind=='model' else
        'tests/tools/qwen_generation_batch_facts_probe.cc' if kind=='facts' else 'tests/tools/qwen_generation_relay_probe.cc')
    command=b.read(BASE/'logs'/prior/'command.json')['command']
    command=[x.replace(str(BASE/'compile'/prior),str(out)).replace(str(prior_source),str(source)) for x in command]
    frozen=b.pin(source);snapshot=W/'source'/name/source.name
    snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(source.read_bytes())
    process=h.execute(command,env(),W/'logs'/name,timeout=180)
    b.exact(frozen);deps=b.read(out/'dependencies.json')['Data']
    inputs=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
    b.save(out/'actual-dependencies.json',inputs)
    record=dict(name=name,source=frozen,snapshot=b.pin(snapshot),object=b.pin(out/'unit.obj'),
                process=process,dependencies=b.pin(out/'actual-dependencies.json'))
    b.save(out/'compiled.json',record);print('COMPILED '+name,flush=True)
def link(name,model_version,probe_kind,probe_version):
    model=b.read(W/'compile'/('model'+model_version)/'compiled.json')
    probe=b.read(W/'compile'/(probe_kind+probe_version)/'compiled.json')
    (W/'bin').mkdir(parents=True,exist_ok=True)
    runtime=b.read(BASE/'runtime.json');dll=Path(runtime['native_cpu']['path']);b.exact(runtime['native_cpu'])
    target=W/'bin'/dll.name
    if not target.exists():os.link(dll,target)
    runtime['PATH']=env()['PATH'];b.save(W/'runtime.json',runtime)
    replacements={b.key(BASE/'compile/model4/unit.obj'):model['object']['path'],
        b.key(BASE/'compile/probe7/unit.obj'):probe['object']['path']}
    artifacts=[]
    for kind,filename in [('cli','hyle.exe'),('probe','qwen-'+probe_kind+'-probe.exe')]:
        for unit in [model,probe]:
            for key in ['source','snapshot','object','dependencies']:b.exact(unit[key])
            for row in b.read(unit['dependencies']['path']):b.exact(row)
        rows=[b.pin(replacements[b.key(x['path'])]) if b.key(x['path']) in replacements else x
              for x in b.read(BASE/(kind+'-link-inputs7.json'))]
        for row in rows:b.exact(row)
        b.save(W/(kind+'-link-inputs-'+name+'.json'),rows)
        image=W/'bin'/filename
        command=b.read(BASE/('link-'+kind+'7')/'command.json')['command']
        command=[replacements.get(b.key(x),'/OUT:'+str(image) if x.upper().startswith('/OUT:') else x) for x in command]
        process=h.execute(command,env(),W/('link-'+kind+'-'+name),timeout=120)
        artifacts.append(dict(name=kind,image=b.pin(image),process=process,inputs=b.pin(W/(kind+'-link-inputs-'+name+'.json'))))
    b.save(W/('ready-'+name+'.json'),dict(compiled=[model,probe],artifacts=artifacts,runtime=b.pin(W/'runtime.json')))
    print('READY '+name,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='link':link(*sys.argv[2:])
    else:compile_unit(*sys.argv[1:])
