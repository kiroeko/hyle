from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent; R = W.parents[1]
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value): Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
        sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest())

def diff(a, b, path='$'):
    if type(a) is not type(b): return [path]
    if isinstance(a, dict):
        return [p for k in sorted(set(a) | set(b)) for p in (
            [path+'.'+k] if k not in a or k not in b else diff(a[k], b[k], path+'.'+k))]
    if isinstance(a, list):
        if len(a) != len(b): return [path+'.length']
        return [p for n, (x,y) in enumerate(zip(a,b)) for p in diff(x,y,f'{path}[{n}]')]
    return [] if a == b else [path]

plan = read(W / 'plan.json')
for name in plan['units']:
    receipt = read(W / 'compile' / name / 'receipt.json')
    assert pin(receipt['object']['path']) == receipt['object']
    for item in receipt['source_identities']: assert pin(item['path']) == item
for item in plan['retained']: assert pin(item['path']) == item
for field in ('runtime','sdk'): assert pin(plan[field]['path']) == plan[field]
for unit in read(plan['sdk']['path'])['engine_consumers']:
    for item in unit['source_identities']:
        actual = pin(item['path'])
        assert all(actual[key] == item[key] for key in ('bytes', 'sha256'))

results=[]
comparison=[]
short_keys={'status','tests','failures','skipped','case','mode','backend','requests','base_lags','controlled_accepted',
    'output_limit','outputs','original_ledger_equal','generated_ids_equal','source_submissions','successor_submissions',
    'successor_publications','successor_discards','final_versions','final_images','N','target_calls','request_waves',
    'ledger_rebuild_graph_calls','idle_evictions','host_restores','restore_capacity_status','restored_state_byte_equal',
    'control_and_candidate_arms','complete_prefix_state_epoch_rng_equal','all_source_session_page_owners_retired'}
for name in plan['cases']:
    folder=W/'runs'/name/'current'; process=read(folder/'process.json'); report=read(folder/'report.json')
    assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out'] and report['status']=='PASS'
    results.append(dict(case=name,native_exit=0,report={k:v for k,v in report.items() if k in short_keys},
        details='batch/runs/'+name+'/current/report.json'))
    if name!='sequence-cpu':
        prior=R/'.scratch/inference-paged-sequence-20261029/runs'/name/'attempt1/report.json'
        changes=diff(read(prior),report)
        comparison.append(dict(case=name,previous=pin(prior),full_report_equal=not changes,
            changed_paths=changes[:30],changed_path_count=len(changes)))
save(W/'previous-report-comparison.json',comparison)

builds=[dict(unit=p.parent.parent.name,attempt=p.parent.name,native_exit=read(p)['exit'])
    for p in sorted((W/'compile').glob('*/*/process.json'))]
links=[dict(unit=p.parent.parent.name,attempt=p.parent.name,native_exit=read(p)['exit'])
    for p in sorted((W/'link').glob('*/*/process.json'))]
assert set(x['unit'] for x in links)==set(plan['units']) and all(x['native_exit']==0 for x in links)
native_attempts=[dict(case=p.parent.parent.name,attempt=p.parent.name,process=read(p))
    for p in sorted((W/'runs').glob('*/*/process.json'))]
sources=['engine/inference/append_transactions.h','engine/inference/paged_append.h',
    'engine/models/qwen35/main.cc','tests/tools/inference_paged_sequence_test.cc']
save(W/'product-sources.json',[pin(R/name) for name in sources])
current=read(W/'compile/budget/receipt.json')
save(W/'model-link-base.json',dict(schema='hyle.paged-append-cohort.current-link-base.v1',base=plan['base'],
    compile=plan['units']['budget']['compile'],link=plan['units']['budget']['link'],
    consumer_source=pin(plan['units']['budget']['source']),previous_consumer=pin(W/'compile/budget/receipt.json'),
    retained=plan['retained'],runtime=plan['runtime'],sdk_engine_dependencies=plan['sdk'],
    source_freeze=[p for p in current['source_identities'] if '.scratch' not in Path(p['path']).relative_to(R).parts]))
summary=dict(schema='hyle.correctness.paged-append-cohort.v1',date='2026-10-29',status='PASS_WITH_PRESERVED_PRE_FIX_FAILURE',base_commit=plan['worktree_base_commit'],
    changes=[
      'Share whole paged append cohort preparation: original page/tail acquire, member/aggregate layouts and original ready/pending Source Append construction.',
      'Share original delta/ticket preparation and tail return algorithms; keep their model-specific call order, complete acceptance, Head/ledger/RNG and actual episode retirement.',
      'Cold scratch reuses source footprint and owner metadata; every synchronous return clears temporary source pins. No per-step source-vector allocation, second owner, executor or retained callback.',
      'Retain total-reference/schema preflight before any candidate/page acquisition, original per-member begin/acquire order, R1 fast path, ahead borrowed integers, withdrawn members and partial accepted physical tail facts.'
      'Zero-bank tail return still validates the original empty transaction cohort, but does not impose physical-tail owner uniqueness on shared policy-only pages.'
    ],counts=dict(consumer_TUs=len(plan['units']),CXX_attempts=len(builds),
        successful_CXX=sum(x['native_exit']==0 for x in builds),preserved_compile_failures=sum(x['native_exit']!=0 for x in builds),
        links=len(links),unchanged_SDK_engine_inputs=227,SDK_CXX=0,NVCC=0,full_builds=0,downloads=0,
        native_processes=len(native_attempts),current_passed_native_processes=len(results),
        preserved_failed_native_processes=sum(x['process']['exit']!=0 for x in native_attempts),
        current_component_tests=plan['cases']['sequence-cpu']['tests'],current_component_Graph_submissions=5,current_model_processes=7),
    builds=builds,links=links,results=results,
    preserved_corrections=[
        'Three first CXX attempts exposed the same move-only Result conditional-expression copy error. Replace selection with explicit branch returns, no permission or identity change.',
        'Actual four-case component run before the zero-bank fix failed only shared policy-page tail uniqueness; original three cases passed. Empty original cohort handling fixes it without relaxing nonempty-bank permissions.'
    ],
    previous_report_comparison=dict(cases=len(comparison),full_reports_equal=sum(x['full_report_equal'] for x in comparison),
        details='batch/previous-report-comparison.json in accompanying ZIP'),
    source_identity_manifest='batch/product-sources.json in accompanying ZIP',current_link_base=pin(W/'model-link-base.json'),
    limitations=['Finite CPU/CUDA only; no new Apple/Vulkan, multi-device or device-fault claim.',
        'Original numeric tolerances remain; no universal byte-equality or model-task quality claim.',
        'No new throughput/full memory window. Full execution orchestration and remaining Source/Store contracts are not complete.'])
file=R/'docs/evidence/correctness/inference-paged-append-cohort-2026-10-29.json';save(file,summary)
archive=file.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.write(file,'summary.json')
    for name in sources:z.write(R/name,'sources/'+name)
    z.writestr('product.patch',subprocess.check_output(['git','diff','--','engine','tests'],cwd=R))
    for p in sorted(W.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.py','.cc','.h','.xml','.log') and p.name!='archive.json' and 'ordinary-input' not in p.relative_to(W).parts:
            z.write(p,'batch/'+p.relative_to(W).as_posix())
    for name in ('weights.tsv','prompt.ids'):z.write(W/'ordinary-input'/name,'batch/ordinary-input/'+name)
    for helper in ('inference-multimodel-observation-20261029/build.py','inference-program-identity-20261029/build.py'):
        z.write(R/'.scratch'/helper,'helpers/'+helper)
save(W/'archive.json',pin(archive))
print('Saved finite correctness evidence; original reports equal',sum(x['full_report_equal'] for x in comparison),'/',len(comparison),'archive bytes',archive.stat().st_size)
