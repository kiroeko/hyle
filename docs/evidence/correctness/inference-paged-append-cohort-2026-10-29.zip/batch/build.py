"""Bounded current consumers; reuse current227 native SDK/engine inputs."""
from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-multimodel-observation-20261029/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); b.W = W; b.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    base_path = R / '.scratch/inference-paged-sequence-20261029/model-link-base.json'
    base = read(base_path)
    assert len(base['retained']) == 227
    for item in base['retained']: exact(item)
    exact(base['runtime']); exact(base['sdk_engine_dependencies'])
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']: exact(item)
    old_object = read(base['previous_consumer']['path'])['object']['path']
    units = {}
    for name, source in [('sequence', R / 'tests/tools/inference_paged_sequence_test.cc'),
        ('model', W / 'model_consumer.cc'), ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc'),
        ('host-image', W / 'host_image_consumer.cc'), ('budget', W / 'budget_consumer.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index-1].lower() == '/sourcedependencies': arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(base['consumer_source']['path']): arg = str(source)
            args.append(arg)
        link = []
        for arg in base['link']:
            if key(arg) == key(old_object): arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / name).with_suffix(suffix)); break
            link.append(arg)
        if name == 'sequence':
            for lib in ('gtest_main.lib', 'gtest.lib'):
                path = R / '.scratch/build-compute-v2-dev/lib' / lib
                if not any(key(a) == key(path) for a in link): link.append(str(path))
        assert sum(key(a) == key(source) for a in args) == 1
        assert sum(key(a) == key(folder / 'unit.obj') for a in link) == 1
        units[name] = dict(source=str(source), compile=args, link=link)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    previous = read(R / '.scratch/inference-paged-sequence-20261029/plan.json')
    fixtures = previous['fixtures']
    for fixture in (fixtures['conditional'], fixtures['natural']):
        exact(fixture['manifest']); exact(fixture['prompt'])
    ordinary = W / 'ordinary-input'; ordinary.mkdir(exist_ok=True)
    for file in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(R / '.scratch/inference-paged-sequence-20261029/ordinary-input' / file, ordinary / file)
    conditional = fixtures['conditional']['directory']
    tiny = previous['cpu_fixture']
    cases = {
        'sequence-cpu': dict(unit='sequence', filter='InferencePagedSequence.*', tests=3),
        'history-cpu': dict(unit='model', args=['history', 'cpu', conditional]),
        'mixed-lag-cuda': dict(unit='model', args=['mixed-lag', 'cuda', conditional]),
        'mtp-ragged-cuda': dict(unit='model', args=['ragged', 'cuda', conditional]),
        'mtp-natural-cuda': dict(unit='model', args=['natural', 'cuda', fixtures['natural']['directory']]),
        'ordinary-cuda': dict(unit='ordinary', args=['--cuda-continuous', str(ordinary)]),
        'host-image-cpu': dict(unit='host-image', args=[tiny]),
        'budget-cpu': dict(unit='budget', args=[tiny])}
    save(W / 'plan.json', dict(base=pin(base_path), worktree_base_commit=subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), units=units, cases=cases,
        retained=base['retained'], runtime=base['runtime'], sdk=base['sdk_engine_dependencies'], fixtures=fixtures,
        ordinary_fixture=dict(manifest=pin(ordinary / 'weights.tsv'), prompt=pin(ordinary / 'prompt.ids')), cpu_fixture=tiny,
        scope='Five bounded current consumers, eight finite processes;227 existing SDK/engine inputs unchanged. No NVCC, downloads or throughput claim.'))
    print('Prepared five bounded TUs/eight finite processes;227 current SDK/engine inputs reused.')


def run(name, attempt):
    plan = read(W / 'plan.json'); case = plan['cases'][name]; b.receipt(case['unit'])
    image = read(W / ('ready-' + case['unit'] + '.json')); exact(image)
    folder = W / 'runs' / name / attempt
    args = case.get('args', [])
    if 'filter' in case:
        args = ['--gtest_color=no', '--gtest_filter=' + case['filter'], '--gtest_output=xml:' + str(folder / 'results.xml')]
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    save(folder / 'image.json', image)
    b.b.execute([image['path'], *args], folder, 300)
    if 'filter' in case:
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors', '0') == '0'
        assert not result.findall('.//skipped')
        report = dict(status='PASS', tests=case['tests'], failures=0, skipped=0)
    else:
        report = read(folder / 'stdout.log'); assert report['status'] == 'PASS'
    save(folder / 'report.json', report); print('PASS', name)


action = sys.argv[1]
if action == 'prepare': prepare()
elif action in ('compile', 'link'):
    if action == 'compile':
        attempt = sys.argv[3] if len(sys.argv) > 3 else 'attempt1'; folder = W / 'compile' / sys.argv[2] / attempt
        folder.mkdir(parents=True, exist_ok=True)
        for relative in ('engine/inference/paged_append.h', 'engine/models/qwen35/main.cc', 'tests/tools/inference_paged_sequence_test.cc'):
            shutil.copyfile(R / relative, folder / Path(relative).name)
    b.main()
elif action == 'run': run(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else 'attempt1')
else: raise ValueError(action)
