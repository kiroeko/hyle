#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <cstring>
#include <span>
#include <vector>

#include "hyle/compute/model_ops.h"

#if defined(HYLE_TEST_BATCHED_BFLOAT_CPU)
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/mem/buffer.h"
#elif defined(HYLE_TEST_BATCHED_BFLOAT_METAL)
#import <Metal/Metal.h>
#include "native_program.h"
#else
#error Select exactly one focused backend
#endif

namespace {
using namespace hyle::compute;

TensorDesc dense(DataType type, std::initializer_list<std::int64_t> shape) {
  return TensorDesc::dense(type, {shape.begin(), shape.size()}).value();
}

struct Fixture final {
  std::int64_t batches, rows, width, columns;
  TensorDesc activation, weight, output;
  std::vector<float> a;
  std::vector<std::uint16_t> w;
  Fixture(std::int64_t b, std::int64_t m, bool rank3)
      : batches(b), rows(m), width(66), columns(4),
        activation(rank3 ? dense(DataType::kFloat32, {b, m, width})
                         : dense(DataType::kFloat32, {m, width})),
        weight(rank3 ? dense(DataType::kBFloat16, {b, columns, width})
                     : dense(DataType::kBFloat16, {columns, width})),
        output(rank3 ? dense(DataType::kFloat32, {b, m, columns})
                     : dense(DataType::kFloat32, {m, columns})),
        a(std::size_t(b * m * width), 0.F),
        w(std::size_t(b * columns * width), 0) {
    for (std::int64_t batch = 0; batch < b; ++batch) {
      for (std::int64_t row = 0; row < m; ++row) {
        const auto index = std::size_t((batch * m + row) * width);
        a[index] = 1.F + float((batch + row) % 3 + 1) / 262144.F;
        a[index + 1] = -1.F;
      }
      for (std::int64_t column = 0; column < columns; ++column) {
        const auto index = std::size_t((batch * columns + column) * width);
        const float coefficient = float((batch + 1) * (column + 1));
        const auto bf = std::uint16_t(std::bit_cast<std::uint32_t>(coefficient) >> 16);
        w[index] = w[index + 1] = bf;
      }
    }
  }
  void check(std::span<const float> actual) const {
    ASSERT_EQ(actual.size(), std::size_t(batches * rows * columns));
    for (std::int64_t b = 0; b < batches; ++b)
      for (std::int64_t m = 0; m < rows; ++m)
        for (std::int64_t n = 0; n < columns; ++n)
          EXPECT_EQ(actual[std::size_t((b * rows + m) * columns + n)],
                    float((b + 1) * (n + 1)) * float((b + m) % 3 + 1) / 262144.F)
              << "batch=" << b << " row=" << m << " column=" << n;
  }
};

void check_description(const TensorDesc &actual, const TensorDesc &expected) {
  EXPECT_EQ(actual.data_type(), DataType::kFloat32);
  EXPECT_EQ(actual.dimensions().size(), expected.dimensions().size());
  EXPECT_TRUE(std::equal(actual.dimensions().begin(), actual.dimensions().end(),
                         expected.dimensions().begin(), expected.dimensions().end()));
  EXPECT_TRUE(actual.is_dense());
  EXPECT_EQ(actual.required_bytes().value(), expected.required_bytes().value());
}

#if defined(HYLE_TEST_BATCHED_BFLOAT_CPU)
template<class T> hyle::mem::Buffer buffer(std::span<const T> data) {
  auto result = hyle::mem::Buffer::create(hyle::mem::system_resource(), data.size_bytes(), 256).value();
  EXPECT_TRUE(result.write(0, std::as_bytes(data)).ok());
  return result;
}

void execute_fixture(const Fixture &fixture) {
  auto context = Context::create(cpu::device(), ggml_cpu::provider()).value();
  auto a = buffer<float>(fixture.a), w = buffer<std::uint16_t>(fixture.w);
  auto y = hyle::mem::Buffer::create(hyle::mem::system_resource(), fixture.output.required_bytes().value(), 256).value();
  const std::array inputs{ConstTensorView::create(fixture.activation, a.view()).value(),
                          ConstTensorView::create(fixture.weight, w.view()).value()};
  auto output = TensorView::create(fixture.output, y.view()).value();
  auto prepared = prepare(context, model_ops::bfloat_linear_f32(), inputs, std::span(&output, 1));
  ASSERT_TRUE(prepared) << prepared.error().message();
  EXPECT_EQ(prepared->provider().id, ggml_cpu::kProviderId);
  check_description(prepared->output_description().value(), fixture.output);
  auto invocation = prepared->create_invocation();
  ASSERT_TRUE(invocation) << invocation.error().message();
  auto queue = context.create_queue();
  ASSERT_TRUE(queue) << queue.error().message();
  auto completion = invocation->submit(*queue, inputs, std::span(&output, 1));
  ASSERT_TRUE(completion) << completion.error().message();
  auto status = completion->wait();
  ASSERT_TRUE(status.ok()) << status.message();
  std::vector<float> actual(std::size_t(fixture.batches * fixture.rows * fixture.columns));
  ASSERT_TRUE(y.read(0, std::as_writable_bytes(std::span(actual))).ok());
  fixture.check(actual);
}

void cold_shape(std::int64_t k, std::int64_t n) {
  auto context = Context::create(cpu::device(), ggml_cpu::provider()).value();
  const std::array inputs{dense(DataType::kFloat32, {64, 1, k}),
                          dense(DataType::kBFloat16, {64, n, k})};
  const std::array outputs{dense(DataType::kFloat32, {64, 1, n})};
  auto prepared = prepare(context, model_ops::bfloat_linear_f32(), inputs, outputs,
                          hyle::mem::system_resource());
  ASSERT_TRUE(prepared) << prepared.error().message();
  EXPECT_EQ(prepared->provider().id, ggml_cpu::kProviderId);
  check_description(prepared->output_description().value(), outputs[0]);
}
#else
void execute_fixture(const Fixture &fixture) {
  @autoreleasepool {
    id<MTLDevice> device = MTLCreateSystemDefaultDevice();
    ASSERT_NE(device, nil);
    __attribute__((objc_precise_lifetime)) id<MTLBuffer> a =
        [device newBufferWithLength:fixture.a.size() * sizeof(float) options:MTLResourceStorageModeShared];
    __attribute__((objc_precise_lifetime)) id<MTLBuffer> w =
        [device newBufferWithLength:fixture.w.size() * sizeof(std::uint16_t) options:MTLResourceStorageModeShared];
    __attribute__((objc_precise_lifetime)) id<MTLBuffer> y =
        [device newBufferWithLength:fixture.output.required_bytes().value() options:MTLResourceStorageModeShared];
    ASSERT_NE(a, nil); ASSERT_NE(w, nil); ASSERT_NE(y, nil);
    std::memcpy([a contents], fixture.a.data(), fixture.a.size() * sizeof(float));
    std::memcpy([w contents], fixture.w.data(), fixture.w.size() * sizeof(std::uint16_t));
    std::memset([y contents], 0xCD, fixture.output.required_bytes().value());
    const std::array descriptions{fixture.activation, fixture.weight};
    auto program = ggml_metal::NativeProgram::create(model_ops::bfloat_linear_f32(), descriptions);
    ASSERT_TRUE(program) << program.error().message();
    ASSERT_EQ((*program)->output_count(), 1U);
    check_description((*program)->output_description(0), fixture.output);
    ASSERT_EQ((*program)->output_offset(0), 0U);
    ASSERT_EQ((*program)->output_bytes(), fixture.output.required_bytes().value());
    EXPECT_FALSE((*program)->input_is_packed(0));
    EXPECT_FALSE((*program)->input_is_packed(1));
    const std::array ports{ggml_metal::BufferView{(__bridge void *)a, 0},
                           ggml_metal::BufferView{(__bridge void *)w, 0},
                           ggml_metal::BufferView{(__bridge void *)y, 0}};
    const auto status = (*program)->run(ports);
    ASSERT_TRUE(status.ok()) << status.message();
    fixture.check({static_cast<const float *>([y contents]),
                   std::size_t(fixture.batches * fixture.rows * fixture.columns)});
  }
}

void cold_shape(std::int64_t k, std::int64_t n) {
  @autoreleasepool {
    const std::array inputs{dense(DataType::kFloat32, {64, 1, k}),
                            dense(DataType::kBFloat16, {64, n, k})};
    const auto output = dense(DataType::kFloat32, {64, 1, n});
    auto program = ggml_metal::NativeProgram::create(model_ops::bfloat_linear_f32(), inputs);
    ASSERT_TRUE(program) << program.error().message();
    ASSERT_EQ((*program)->output_count(), 1U);
    check_description((*program)->output_description(0), output);
    EXPECT_EQ((*program)->output_offset(0), 0U);
    EXPECT_EQ((*program)->output_bytes(), output.required_bytes().value());
    EXPECT_FALSE((*program)->input_is_packed(1));
  }
}

TEST(BatchedBfloatApple, MetalRejectsOddNForPairedRowKernel) {
  const std::array inputs{dense(DataType::kFloat32, {3, 2, 66}),
                          dense(DataType::kBFloat16, {3, 3, 66})};
  const auto status = ggml_metal::NativeProgram::validate(model_ops::bfloat_linear_f32(), inputs);
  EXPECT_EQ(status.code(), hyle::StatusCode::Unimplemented);
  const std::array legacy{dense(DataType::kFloat32, {2, 66}),
                          dense(DataType::kBFloat16, {3, 66})};
  EXPECT_EQ(ggml_metal::NativeProgram::validate(model_ops::bfloat_linear_f32(), legacy).code(),
            hyle::StatusCode::Unimplemented);
}
#endif

TEST(BatchedBfloatApple, OriginalFloat32ActivationsAndDifferentBatchWeights) {
  for (const auto m : {std::int64_t{1}, std::int64_t{2}, std::int64_t{17}}) {
    SCOPED_TRACE(m);
    execute_fixture(Fixture(3, m, true));
  }
}

TEST(BatchedBfloatApple, Rank2Float32Regression) {
  for (const auto m : {std::int64_t{1}, std::int64_t{2}, std::int64_t{17}}) {
    SCOPED_TRACE(m);
    execute_fixture(Fixture(1, m, false));
  }
}

TEST(BatchedBfloatApple, Actual64HeadKeyAndValueColdPreparation) {
  // Metadata-only checks. No tensor payloads or 16MiB weight banks are allocated/submitted.
  cold_shape(256, 512);
  cold_shape(512, 256);
}

TEST(BatchedBfloatApple, ExactBatchIdentityRequired) {
  const std::array inputs{dense(DataType::kFloat32, {3, 2, 66}),
                          dense(DataType::kBFloat16, {1, 4, 66})};
  EXPECT_FALSE(infer_single_output(model_ops::bfloat_linear_f32(), inputs));
}
} // namespace
