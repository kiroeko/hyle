from pathlib import Path
from datetime import datetime,timezone
import io,json,hashlib,tarfile,zipfile,xml.etree.ElementTree as ET
S=Path(__file__).resolve().parent;R=S.parents[2]
D=R/'docs/evidence/correctness';NAME='mtp-batched-f32-bfloat-apple-2026-10-24'
def ident(p):
    raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def block(t,name):return t.extractfile(name).read()
results=tarfile.open(S/'actual-results.tar.gz');executions=[]
for backend,count in (('cpu',4),('metal',5)):
    root=ET.fromstring(block(results,backend+'-tests.xml'))
    assert int(root.attrib['tests'])==count and all(int(root.attrib.get(k,0))==0 for k in ('failures','errors','disabled'))
    assert not root.findall('.//skipped')
    rows=json.loads(block(results,backend+'-run.result.json'))
    assert len(rows)==1 and rows[0]['exit_code']==0
    executions.append(dict(backend=backend,tests=count,failures=0,skips=0,
        cases=[x.attrib['name'] for x in root.findall('.//testcase')],
        image=rows[0]['inputs'][0],xml=backend+'-tests.xml',
        scope='CPU Context prepare/submit' if backend=='cpu' else 'Metal NativeProgram lowering and actual shared MTLBuffers; not the full Graph/provider assembly'))
for name in ('cpu-compile.result.json','cpu-compile-helpers.result.json','cpu-link.result.json',
             'metal-compile.result.json','metal-link.result.json'):
    assert all(row['exit_code']==0 for row in json.loads(block(results,name)))
files={}
for name in ('abi2-frozen-source.tar.gz','helper-source.tar.gz'):
    with tarfile.open(S/name) as source:
        for m in source.getmembers():
            assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
            # Later helper package replaces only build commands/manifest;
            # previously compiled source remains byte-identical.
            raw=block(source,m.name)
            if m.name in files and m.name.startswith('source/'):assert files[m.name]==raw
            files[m.name]=raw
for m in results.getmembers():
    assert m.isfile() and '/' not in m.name
    files['actual/'+m.name]=block(results,m.name)
for name in ('run_metal_remote.py','publish.py','ready.json'):
    files['local/'+name]=(S/name).read_bytes()
archive=D/(NAME+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
hardware=json.loads(block(results,'actual-hardware.json'))
record=dict(created_at=datetime.now(timezone.utc).isoformat(),
    scope='Representative Apple CPU/Metal checks for the shared batched F32 activation x original BF16 weight projection',
    hardware=hardware,executions=executions,
    inputs='Different original test BF16 W for each B=3, F32 cancellation rows, M1/M2/M17; rank2 regression.',
    cold_only='Actual Q32 key/value-sized B64 descriptors are preparation checks only, not actual Q32 weights or whole-model execution.',
    cpu_runtime='Current ABI2 cpu_program/cpu_execution/metadata_arena host sources plus actual standard_index/native_batch/batch_layout helpers; old ABI1 runtime is not linked. Cached native CPU library reused, missing FWHT symbol supplied by mechanically extracted current small source.',
    cpu_host_translation_units=9,metal_host_translation_units=2,SDK_builds=0,native_GGML_library_builds=0,
    limits=['No complete Q32 model, MTP state journey, task quality, throughput or physical-memory peak claim.',
        'Metal checks current native lowering directly; full Graph assembly and Vulkan remain outside this batch.'],
    archive=ident(archive),archived_files=len(files),throughput_evidence=False,memory_evidence=False)
out=D/(NAME+'.json');assert not out.exists();out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=ident(out),archive=ident(archive),tests=9)))
