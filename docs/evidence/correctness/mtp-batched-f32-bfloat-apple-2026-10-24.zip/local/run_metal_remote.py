from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile,sys
S=Path(__file__).resolve().parent
HOST='kiro@172.22.10.198'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/batched-bfloat-linear-20261024/attempt1'
SHA='60601eb3ac6eefafde0b0e926280a9d6f5a7cef8a9cb0c8412d04a1eab90e38b'
def execute(tag,argv):
    print('START',tag,flush=True)
    with (S/(tag+'.stdout.log')).open('wb') as out:
        p=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT)
    (S/(tag+'.process.json')).write_text(json.dumps(dict(command=argv,exit=p.returncode),indent=2)+'\n')
    print('END',tag,p.returncode,flush=True)
    if p.returncode:
        print((S/(tag+'.stdout.log')).read_text(encoding='utf-8',errors='replace')[-12000:]);sys.exit(p.returncode)
def ssh(code):return ['ssh','-oBatchMode=yes','-oConnectTimeout=10',HOST,'python3 -c '+shlex.quote(code)]
archive=S/'metal-frozen-source.tar.gz'
if not archive.exists():
    raw=(S/'focused-source.tar.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()==SHA
    archive.write_bytes(raw)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==SHA
with tarfile.open(archive) as tar:
    members=tar.getmembers()
    assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and m.isfile() for m in members)
    assert {'build.py','commands.json','sync-manifest.json'} <= {m.name for m in members}
action=sys.argv[1]
if action=='sync':
    execute('metal-mkdir',ssh('from pathlib import Path; Path('+repr(REMOTE)+').mkdir(parents=True,exist_ok=False)'))
    execute('metal-upload',['scp','-oBatchMode=yes','-oConnectTimeout=10',str(archive),HOST+':'+REMOTE+'/source.tar.gz'])
if action in ('sync','extract','extract-abi2','extract-helpers'):
    filename='helper-source.tar.gz' if action=='extract-helpers' else 'source-abi2.tar.gz' if action=='extract-abi2' else 'source.tar.gz'
    expected='fd94c2c8f990da30b2a48924dbf8cd44b2cf82e20962d07c55004faefc89a1d2' if action=='extract-helpers' else '79ee3663ce9944e65167c6fac6f29294607bb2f6101e72abb4955ffee63f9ba8' if action=='extract-abi2' else SHA
    code='from pathlib import Path; import hashlib,tarfile; p=Path('+repr(REMOTE)+'); a=p/'+repr(filename)+'; assert hashlib.sha256(a.read_bytes()).hexdigest()=='+repr(expected)+'; t=tarfile.open(a); assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in t.getmembers()); t.extractall(p)'
    execute('metal-extract',ssh(code))
elif action in ('compile','link','run'):
    execute('metal-'+action,['ssh','-oBatchMode=yes','-oConnectTimeout=10',HOST,
        'python3 '+shlex.quote(REMOTE+'/build.py')+' metal '+action])
elif action in ('cpu-compile','cpu-compile-helpers','cpu-link','cpu-run'):
    stage=action.removeprefix('cpu-')
    execute(action,['ssh','-oBatchMode=yes','-oConnectTimeout=10',HOST,
        'python3 '+shlex.quote(REMOTE+'/build.py')+' cpu '+stage])
elif action=='collect':
    code='''from pathlib import Path
import hashlib,json,tarfile,subprocess
p=Path(REMOTE_VALUE)
rows=[]
for command in [['uname','-m'],['sw_vers'],['sysctl','-n','hw.model'],['sysctl','-n','hw.memsize'],['/usr/bin/clang++','--version']]:
 r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 rows.append(dict(command=command,exit=r.returncode,output=r.stdout.decode('utf-8','replace')))
(p/'actual-hardware.json').write_text(json.dumps(rows,indent=2)+'\\n')
files={x for pattern in ('*.result.json','*.log','*.xml','*.o.d') for x in p.glob(pattern)}
files.update(p/name for name in ('actual-hardware.json','commands.json','sync-manifest.json','build.py','cpu-hadamard-source-facts.json'))
with tarfile.open(p/'actual-results.tar.gz','w:gz') as t:
 for x in sorted(files):
  assert x.is_file() and x.parent==p
  t.add(x,arcname=x.name)
print(json.dumps(dict(files=len(files),bytes=(p/'actual-results.tar.gz').stat().st_size)))
'''.replace('REMOTE_VALUE',repr(REMOTE))
    execute('apple-collect',ssh(code))
    execute('apple-download-results',['scp','-oBatchMode=yes','-oConnectTimeout=10',HOST+':'+REMOTE+'/actual-results.tar.gz',str(S/'actual-results.tar.gz')])
elif action not in ('sync','extract','extract-abi2','extract-helpers'):raise SystemExit('Unknown action')
