"""Fixed Mac16,12 focused check; run only after reviewing/syncing this proposal."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PLAN = json.loads((HERE / "commands.json").read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("backend", choices=("cpu", "metal"))
    parser.add_argument("stage", choices=("compile", "compile-helpers", "link", "run"))
    args = parser.parse_args()
    expected = Path(PLAN["remote_directory"])
    if HERE != expected:
        raise SystemExit(f"Expected fixed directory {expected}; got {HERE}")
    manifest = json.loads((HERE / "sync-manifest.json").read_text())
    for item in manifest["files"]:
        path = HERE / item["archive_path"]
        if path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
            raise SystemExit(f"Synchronized file differs: {path}")
    records = []
    if args.stage not in PLAN[args.backend]:
        raise SystemExit(f"No {args.stage} stage for {args.backend}")
    for row in PLAN[args.backend][args.stage]:
        inputs = []
        for name in row["inputs"]:
            path = Path(name)
            inputs.append({"path": name, "bytes": path.stat().st_size, "sha256": sha(path)})
        log = HERE / row["name"]
        log = log.with_suffix(".log")
        with log.open("wb") as output:
            run = subprocess.run(row["argv"], cwd=row["cwd"], stdout=output,
                                 stderr=subprocess.STDOUT, env=None)
        record = {"name": row["name"], "cwd": row["cwd"], "argv": row["argv"],
                  "inputs": inputs, "exit_code": run.returncode, "log": str(log)}
        if run.returncode == 0:
            record["outputs"] = [{"path": name, "bytes": Path(name).stat().st_size,
                                  "sha256": sha(name)} for name in row["outputs"]]
            for name in row["outputs"]:
                if name.endswith(".d"):
                    # All fixed workspace/include paths used here contain no spaces.
                    content = Path(name).read_text().replace("\\\n", " ").split(":", 1)[1]
                    record["dependencies"] = [{"path": item, "bytes": Path(item).stat().st_size,
                                                "sha256": sha(item)} for item in content.split()]
        records.append(record)
        (HERE / f"{args.backend}-{args.stage}.result.json").write_text(json.dumps(records, indent=2) + "\n")
        if run.returncode:
            print(log.read_text(errors="replace")[-16000:])
            return run.returncode
    return 0


if __name__ == "__main__":
    sys.exit(main())
