"""Archive existing finite results only; no C++ build or model execution."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
DEST = ROOT / 'docs/evidence/correctness'
STEM = 'q24-modelopt-mixed-source-2026-10-25'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def pin(path):
    return dict(path=path.relative_to(ROOT).as_posix(), **digest(path.read_bytes()))


first, final = (read(WORK / attempt / 'summary.json') for attempt in ('cpu1', 'cpu2'))
assert first['status'] == 'TEST_FAILED' and first['run']['exit'] == 1
assert first['xml'] == dict(tests=1, failures=1, errors=0, skipped=0)
assert b'Fill requires a valid shape and exactly typed scalar' in (WORK / 'cpu1/run/stdout.log').read_bytes()
assert final['status'] == 'PASS' and final['xml'] == dict(tests=1, failures=0, errors=0, skipped=0)
assert all(final[stage]['exit'] == 0 for stage in ('compile', 'link', 'run'))
assert final['source_revision'] == 3 and final['frozen_files'] == 60
xml = ET.parse(WORK / 'cpu2/tests.xml').getroot()
case = xml.find('testsuite/testcase')
props = {p.attrib['name']: p.attrib['value'] for p in case.findall('properties/property')}
assert props['connected_source_roles'] == '7' and props['actual_submissions'] == '2'
assert props['source_value_scope'] == 'generated fixture, not original publisher payload'
assert 'unknown' in props['original_scale_span_status']

sources = read(WORK / 'product-pins.json')
assert sources['revision'] == 3 and len(sources['files']) == 2
frozen = {f['relative']: f for f in read(WORK / 'cpu2/frozen-project.json')}
for item in sources['files']:
    assert digest((ROOT / item['path']).read_bytes()) == item['after']
    assert digest((WORK / 'source' / item['path']).read_bytes()) == item['after']
    assert {k: frozen[item['path']]['canonical'][k] for k in ('bytes', 'sha256')} == item['after']
    assert digest(Path(frozen[item['path']]['frozen']['path']).read_bytes()) == item['after']
before = WORK / 'r2/source/tests/compute_models/q24_modelopt_mixed_source_case.h'
after = WORK / 'source/tests/compute_models/q24_modelopt_mixed_source_case.h'
assert before.read_bytes().replace(b'c::ScalarValue(0.F)', b'c::ScalarValue::from_bits(Type::kBFloat16,0)', 1) == after.read_bytes()
for attempt in ('cpu1', 'cpu2'):
    command = read(WORK / attempt / 'compile/command.json')['command']
    assert '/W4' in command and '/WX' in command
    assert sum(arg.lower().endswith(('.cc', '.cpp')) for arg in command) == 1

members, origins = {}, {}


def add_raw(name, raw, origin):
    assert name not in members
    assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})', raw), name
    members[name], origins[name] = raw, origin


def add(name, path):
    assert path.is_file(), path
    assert path.suffix.lower() not in {'.obj', '.exe', '.dll', '.lib', '.pdb', '.bin', '.gguf', '.safetensors'}
    add_raw(name, path.read_bytes(), path.relative_to(ROOT).as_posix())


for name in ('product-pins.json', 'source.patch', 'r2-to-r3.patch', 'scope.json',
             'source-spans.json', 'config-facts.json', 'independent-review-sampling.json'):
    add('candidate/' + name, WORK / name)
for item in sources['files']:
    add('final-source/' + item['path'], WORK / 'source' / item['path'])
for name in ('product-pins.json', 'source.patch', 'scope.json', 'check_cpu.py'):
    add('first-r2/' + name, WORK / 'r2' / name)
add('first-r2/tests/compute_models/q24_modelopt_mixed_source_case.h', before)
add('commands/check_cpu.py', WORK / 'check_cpu.py')
add('commands/check_finite.py', ROOT / '.scratch/inference-e4-append-implementation-20261025/check_finite.py')
add('commands/archive-proof.py', Path(__file__).resolve())
for attempt in ('cpu1', 'cpu2'):
    for path in sorted((WORK / attempt).rglob('*')):
        rel = path.relative_to(WORK / attempt)
        if path.is_file() and 'source' not in rel.parts and path.suffix.lower() in {'.json', '.log', '.xml'}:
            add('actual/' + attempt + '/' + rel.as_posix(), path)

span_facts = read(WORK / 'source-spans.json')
known = [r for r in span_facts['roles'] if r['status'] == 'ORIGINAL_HEADER_EXTENT_CONFIRMED_VALUE_UNREAD']
assert len(known) == 6
headers = {}
for role in known:
    item = role['header']
    path = ROOT / item['path']
    assert digest(path.read_bytes()) == {k: item[k] for k in ('bytes', 'sha256')}
    actual = read(path)[role['role']]
    assert all(actual[key] == role[key] for key in ('dtype', 'shape', 'data_offsets'))
    headers[path] = role
assert len(headers) == 3
for path, role in headers.items():
    shard = role['source_file']
    add('source-evidence/' + shard + '.header.json', path)
    receipt = role['header_request_receipt']
    assert digest((ROOT / receipt['path']).read_bytes()) == {k: receipt[k] for k in ('bytes', 'sha256')}
    add('source-evidence/' + shard + '.receipt.json', ROOT / receipt['path'])
index_file = ROOT / span_facts['index']['path']
assert digest(index_file.read_bytes()) == {k: span_facts['index'][k] for k in ('bytes', 'sha256')}
index = read(index_file)
selected_index = {r['role']: index['weight_map'][r['role']] for r in span_facts['roles']}
assert all(selected_index[r['role']] == r['source_file'] for r in span_facts['roles'])
index_excerpt = dict(source_index=span_facts['index'], source_index_receipt=span_facts['index_receipt'],
    repository=span_facts['repository'], revision=span_facts['revision'], weight_map=selected_index,
    limit='Selected seven mappings only. SA137 is index-only: original dtype/shape/offset and all body values remain unknown.')
add_raw('source-evidence/index-selected-roles.json', (json.dumps(index_excerpt, indent=2) + '\n').encode(),
        span_facts['index']['path'] + ' (seven-role extraction; full index not duplicated)')
add('source-evidence/index-acquisition.json', ROOT / span_facts['index_receipt']['path'])
config = read(WORK / 'config-facts.json')
with zipfile.ZipFile(ROOT / config['archive']['path']) as archive:
    raw = archive.read(config['entry'])
assert digest(raw) == {k: config[k] for k in ('bytes', 'sha256')}
add_raw('source-evidence/config.json', raw, config['archive']['path'] + '#' + config['entry'])

manifest = dict(scope='No SDK, compiled binary, publisher body or full frozen include tree.',
    members=[dict(member=name, original_path=origins[name], **digest(raw)) for name, raw in sorted(members.items())])
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
archive_path = DEST / (STEM + '.zip')
report_path = DEST / (STEM + '.json')
assert not archive_path.exists() and not report_path.exists(), 'Preserve an existing publication'
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted({**members, 'member-sha256.json': manifest_bytes}.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, raw, compresslevel=9)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(members) + 1
    for name, raw in members.items():
        assert digest(archive.read(name)) == digest(raw)
    assert archive.read('member-sha256.json') == manifest_bytes

report = dict(
    status='CONNECTED_MIXED_MODELOPT_GENERATED_SOURCE_ROLES_CPU_PASS', date='2026-10-25',
    base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    change='Two test-source paths connect seven independently named/owned typed fixture roles in one ordinary Graph: one selected NVFP4 expert-down contribution, original ordered BF16 tail/residual/norm, then adjacent static-FP8 GDN input projection. No product math, loader, codec, owner, registry or executor is added.',
    sources=sources['files'],
    source_evidence=dict(repository=span_facts['repository'], revision=span_facts['revision'],
        roles=7, confirmed_header_roles=6, unique_cached_headers=3, original_payload_bytes=0,
        unresolved='Layer41 in_proj_a.input_scale is mapped by the fixed index to shard137, but its original header/dtype/shape/offset are unknown. F32[1] is the existing reader requirement, not an observed source fact.',
        qualification='Runtime binds generated hyle-fixture/q24-modelopt-mixed leases. It does not execute authenticated original-file source binding or original publisher values.'),
    finite_journey=dict(rows=1, expert_down_NK=[8192, 2048], next_projection_NK=[128, 8192],
        semantic_inputs=14, constant_roles=7, generations=2, actual_submissions=int(props['actual_submissions']),
        upstream_boundaries='Nine other already-weighted BF16 expert terms, shared-gated contribution, residual and effective F32 gamma are explicit fixture inputs; no router, complete FFN or full GDN is constructed.',
        math='Original NVFP4 output BF16; routing multiply F32 then BF16; zero+expert0 and nine ordered BF16 adds; shared and residual BF16 adds; original F32 RMS/effective gamma then BF16; separate static-FP8 reciprocal SA, E4 cast, F32 code-dot, SA then SW and BF16 store.',
        numerical_gate='Reuses existing independent NVFP4 projection and norm gates; exact scalar BF16 tail checks and independent sparse static-FP8 scalar oracle. No new tolerance or unreported max-error/bit-level claim.',
        lifetime='Original external parameter, binding and compile handles are dropped before submit. Held GraphOutputs remain readable across the second source generation and after external invocation handles leave scope; GraphOutput retains the original slot. This does not prove underlying Invocation destruction or independent output export.',
        rejections='Same-typed SA/SW logical-role swap rejects. Both generations and held old results pass the existing checks; any output pools used by the selected ownership mode report zero live blocks after held readers reset.'),
    actual_CPU=dict(compile=final['compile'], link=final['link'], run=final['run'], xml=final['xml'],
        filter=final['filter'], gtest_case_seconds=float(case.attrib['time']), frozen_files=60,
        native=final['native'], new_test_TUs_per_attempt=1, attempts=2, core_provider_SDK_rebuilds=0,
        GPU_or_Model_processes=0, HTTP=0),
    first_failure=dict(compile=first['compile'], link=first['link'], run=first['run'], xml=first['xml'],
        phase='Graph construction before numerical comparison',
        cause='BF16 Fill received ScalarValue(0.F), an F32 scalar. The strict original operation correctly rejected it.',
        fix='Only replace that zero with ScalarValue::from_bits(Type::kBFloat16,0). R2 source/patch/pins/raw are retained, with exact r2-to-r3.patch; no operation contract, oracle, tolerance or other math changed.'),
    independent_review=dict(path='candidate/independent-review-sampling.json', scope='Source-only r2 review; actual cpu1 subsequently exposed the Fill type mistake. R3 changes only the explicit zero scalar type.',
        result='No other source blocker identified; GraphOutput slot-lifetime boundary retained.'),
    reproduction=dict(command='python .scratch/inference-q24-modelopt-mixed-binding-20261025/check_cpu.py cpuN',
        required='Fresh cpuN directory, r3 canonical source pins and existing pinned CPU closure/native DLL. Actual cpu1/cpu2 commands and dependency/link pins are archived.'),
    not_claimed=['Original source-file binding, publisher payload numerical qualification or SA137 source extent.',
        'Complete ten-expert FFN/router/shared branch, full GDN, Model construction, prefill/decode or entire selected profile.',
        'GPU/other-backend execution, quality, TPS, speedup, complete zero-allocation or total resource-budget-zero.'],
    archive=dict(**pin(archive_path), members=len(members) + 1, CRC_and_member_SHA256_verified=True))
report_path.write_bytes((json.dumps(report, indent=2) + '\n').encode())
print(json.dumps(dict(report=pin(report_path), archive=pin(archive_path), members=len(members) + 1,
    actual_xml=final['xml'], original_payload_bytes=0), indent=2))
