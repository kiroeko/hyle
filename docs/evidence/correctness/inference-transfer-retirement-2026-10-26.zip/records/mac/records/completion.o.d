/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/completion.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/src/compute/completion.cc \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/compute/completion.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/compute/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/error/result.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/core/compiler.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/core/detail/compiler_attributes.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/core/environment.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/core/assert.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/core/detail/preprocessor.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/error/status.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/compute/completion_retention.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/compute/detail/completion_access.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/include/hyle/obs/trace.h \
  /Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/source/src/compute/completion_internal.h
