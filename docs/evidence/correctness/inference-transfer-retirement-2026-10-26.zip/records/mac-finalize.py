from pathlib import Path
import hashlib,json,os,subprocess,time
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026')
P=json.loads((W/'plan.json').read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
d=W/'run-cpu-faults2';d.mkdir(exist_ok=False)
cmd=[str(W/'state-transfer'),'--faults'];env=os.environ.copy();env.update(P['environment'])
save(d/'command.json',dict(command=cmd,cwd=str(W),environment=P['environment']))
start=time.perf_counter()
with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
    proc=subprocess.Popen(cmd,cwd=W,env=env,stdout=out,stderr=err)
    save(d/'running.json',dict(pid=proc.pid));code=proc.wait(timeout=30)
row=dict(pid=proc.pid,exit=code,seconds=time.perf_counter()-start)
save(d/'process.json',row);print(json.dumps(row),flush=True)
if code:raise RuntimeError('Corrected CPU fault process failed')
save(W/'actual-dependencies.json',{p.name:p.read_text() for p in W.glob('*.o.d')})
save(W/'map-selection.json',dict(lines=[s for s in (W/'image.map').read_text().splitlines()
    if any(n in s for n in ('completion.o','batch_transfer.o','apple_copy_program.o','test2.o'))]))
rows={str(p.parent.name):json.loads(p.read_text()) for p in W.glob('*/process.json')}
assert rows['run-apple-closed']['exit']==0
save(W/'summary.json',dict(status='FINITE_SCOPE_PASS_WITH_PRESERVED_FAILURES',processes=rows,
    compiled_TUs=5,successful_compile_TUs=4,SDK_builds=0,HTTP=0,scope=P['scope'],
    preserved_failures=['First transfer test copied noncopyable LeasePools; test-only observer fixed.',
                        'First CPU fault invocation used --cpu --faults; actual standalone --faults corrected without rebuild.'],
    limits=['CPU accepted/error/unknown retirement is controlled; no physical Apple driver failure injected.',
            'Only small byte/lifetime transfer; no model quality or performance claim.']))
