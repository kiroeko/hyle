from pathlib import Path
import base64, hashlib, io, json, re, subprocess, tarfile

W = Path(__file__).resolve().parent / 'mac'
W.mkdir(exist_ok=True)
R = W.parents[2]
M = '/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026'
old = json.loads((R/'.scratch/inference-native-host-image-20261026/mac-model-attempt4/plan.json').read_text())
ready = json.loads((R/'.scratch/inference-native-host-image-20261026/mac-model-attempt4/ready.json').read_text())
def save(p, v): p.write_text(json.dumps(v, indent=2)+'\n', encoding='utf-8')
def remote(code, tag):
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -']
    p=subprocess.run(cmd, input=code, text=True, capture_output=True, timeout=60)
    save(W/(tag+'.json'),dict(command=cmd,exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if p.returncode: raise RuntimeError(p.stderr or p.stdout)
    return json.loads(p.stdout)

entries=['src/compute/completion.cc','src/compute/batch_transfer.cc',
         'src/compute_route_apple/apple_copy_program.cc','tests/tools/inference_state_transfer_test.cc']
names=set(entries); queue=list(entries)
roots=[R/'include', R/'src/compute', R/'src/graph', R/'src/compute_route_apple']
while queue:
    name=queue.pop(); path=R/name
    for inc in re.findall(r'^\s*#\s*include\s*[<"]([^">]+)[">]',path.read_text(encoding='utf-8'),re.M):
        candidates=[path.parent/inc, *[root/inc for root in roots]]
        found=next((p.resolve() for p in candidates if p.is_file() and p.resolve().is_relative_to(R)),None)
        if found:
            rel=found.relative_to(R).as_posix()
            if rel not in names: names.add(rel);queue.append(rel)
stream=io.BytesIO(); pins=[]
with tarfile.open(fileobj=stream,mode='w:gz') as out:
    for name in sorted(names):
        raw=(R/name).read_bytes();pins.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
        info=tarfile.TarInfo(name);info.size=len(raw);out.addfile(info,io.BytesIO(raw))
data=stream.getvalue();assert len(data)<5*1024*1024
(W/'source.tar.gz').write_bytes(data);save(W/'source-freeze.json',pins)
payload=base64.b64encode(data).decode()
remote(f'''from pathlib import Path
import base64,io,json,tarfile
w=Path({M!r});s=w/'source';s.mkdir(parents=True,exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(base64.b64decode({payload!r})),mode='r:gz') as t:
 for row in t.getmembers():
  p=(s/row.name).resolve();assert p.is_relative_to(s.resolve()) and row.isfile()
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(row).read())
print(json.dumps(dict(files={len(pins)},compressed_bytes={len(data)})))
''','sync')
args=old['jobs'][0]['command'];flags=[];i=1
while i<len(args):
    arg=args[i]
    if arg in ('-o','-MF','-MT','-MQ','-c'): i+=2;continue
    if arg in ('-MMD','-MD'): i+=1;continue
    flags.append(arg);i+=1
flags=['-I'+M+'/source/include','-I'+M+'/source/src/compute',
       '-I'+M+'/source/src/compute_route_apple','-I'+M+'/source',*flags]
objects=[M+'/'+Path(n).stem+'.o' for n in entries]
jobs=[dict(tag='compile-'+Path(name).stem, command=[args[0],*flags,'-MMD','-MF',obj+'.d','-c',M+'/source/'+name,'-o',obj], timeout=120)
      for name,obj in zip(entries,objects)]
removed={x['path'] for x in ready['reused_model_objects']}
link=old['jobs'][-1]['command'];assert all(link.count(n)==1 for n in removed)
assert not any('completion' in x or 'batch_transfer' in x or 'apple_copy_program' in x for x in link if x.endswith('.o'))
new=[link[0],*objects,*[x for x in link[1:] if x not in removed]]
for i,arg in enumerate(new):
    if arg=='-o':new[i+1]=M+'/state-transfer'
    elif arg.startswith('-Wl,-map,'):new[i]='-Wl,-map,'+M+'/image.map'
jobs.append(dict(tag='link',command=new,timeout=120))
plan=dict(remote=M,jobs=jobs,environment=old['environment'],source_files=len(pins),compressed_source_bytes=len(data),
          scope='Four current transfer/Completion/copy leaves; latest CPU+Apple closure with Model/weights/report removed; all SDK/vendor archives reused unchanged.')
save(W/'plan.json',plan)
remote(f'''from pathlib import Path
import json
w=Path({M!r});(w/'plan.json').write_text({json.dumps(plan)!r});(w/'source-freeze.json').write_text({json.dumps(pins)!r})
print(json.dumps(dict(status='PREPARED_NOT_BUILT',jobs={len(jobs)})))
''','plan-upload')
print(json.dumps(dict(status='PREPARED_NOT_BUILT',files=len(pins),compressed_bytes=len(data))))
