param([switch]$Delete)
$ErrorActionPreference = 'Stop'
# Default is a read-only identity check; -Delete removes only these exact files.
# Superseded images only; current case/test images and all link inputs remain.
$scope = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch')).TrimEnd('\') + '\'
$targets = @(
  @{ path='.scratch/inference-stream-padding-20261026/case/link/host-image-vulkan-test.exe'; bytes=69549568; sha256='0ba79545243f061d4e0e7bc70a34ef9d6ff5e636b48de7ed9c46bbbd88ae6121' },
  @{ path='.scratch/inference-stream-padding-20261026/test3/link/padding-focused-test.exe'; bytes=69073920; sha256='5b677fad4f868724605e0fd3f22424c3d30935a7eafd16bad58b195c034dd801' },
  @{ path='.scratch/inference-native-host-image-20261026/windows-attempt3/link/state-transfer-test.exe'; bytes=67409920; sha256='4c4b05f5fe84cf22d0fea60f420318358ac814b639712c9670ce77ade5614597' }
)
foreach ($row in $targets) {
  $resolved = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot $row.path)).ProviderPath
  if (-not $resolved.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes repository scratch' }
  $file = Get-Item -LiteralPath $resolved
  if ($file.PSIsContainer -or $file.Length -ne $row.bytes) { throw 'Target identity mismatch' }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ine $row.sha256) { throw 'Target digest changed' }
}
if (-not $Delete) {
  $targets | ForEach-Object { [pscustomobject]$_ } | Format-Table path,bytes
  Write-Output 'Read-only check completed. No files deleted.'
  return
}
$scriptHash = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
foreach ($row in $targets) { Remove-Item -LiteralPath (Join-Path $PSScriptRoot $row.path) -Force }
$receipt = [ordered]@{
  status='REMOVED_THREE_EXACT_SUPERSEDED_IMAGES'
  command='& .\test.ps1 -Delete'
  executed_script_sha256=$scriptHash
  logical_bytes=206033408
  targets=$targets
  current_case_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-transfer-retirement-20261026/case/link/host-image-test.exe'))
  current_focused_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-transfer-retirement-20261026/test/link/completion-test.exe'))
  current_transfer_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-transfer-retirement-20261026/transfer/link/state-transfer-test.exe'))
}
$receipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-transfer-retirement-20261026/cleanup-result.json') -Encoding UTF8
$receipt | ConvertTo-Json -Depth 4
