from pathlib import Path
import hashlib,json,os,subprocess,time
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026')
P=json.loads((W/'plan.json').read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(tag,cmd,timeout):
    d=W/tag;d.mkdir(exist_ok=False)
    save(d/'command.json',dict(command=cmd,cwd=str(W),environment=P['environment']))
    env=os.environ.copy();env.update(P['environment']);start=time.perf_counter()
    with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
        proc=subprocess.Popen(cmd,cwd=W,env=env,stdout=out,stderr=err)
        save(d/'running.json',dict(pid=proc.pid))
        try:code=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:proc.terminate();code=proc.wait(timeout=5)
    row=dict(tag=tag,pid=proc.pid,exit=code,seconds=time.perf_counter()-start)
    save(d/'process.json',row);print(json.dumps(row),flush=True)
    if code:raise RuntimeError(tag+' failed')
    return row
save(W/'hardware.json',dict(model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),
     compiler=subprocess.check_output(['/usr/bin/clang++','--version'],text=True)))
for row in json.loads((W/'source-freeze.json').read_text()):
    assert hashlib.sha256((W/'source'/row['path']).read_bytes()).hexdigest()==row['sha256']
rows=[]
for job in P['jobs']:rows.append(run(job['tag'],job['command'],job['timeout']))
image=W/'state-transfer'
save(W/'ready.json',dict(image=dict(path=str(image),bytes=image.stat().st_size,sha256=hashlib.sha256(image.read_bytes()).hexdigest()),scope=P['scope']))
rows.append(run('run-apple-closed',[str(image),'--apple','--closed-recovery'],30))
rows.append(run('run-cpu-faults',[str(image),'--cpu','--faults'],30))
deps={p.name:p.read_text() for p in W.glob('*.o.d')}
save(W/'actual-dependencies.json',deps)
save(W/'map-selection.json',dict(lines=[s for s in (W/'image.map').read_text().splitlines()
    if any(n in s for n in ('completion.o','batch_transfer.o','apple_copy_program.o','inference_state_transfer_test.o'))]))
save(W/'summary.json',dict(status='PASS',processes=rows,compiled_TUs=4,SDK_builds=0,HTTP=0,
     scope=P['scope'],limits=['CPU accepted/error/unknown retirement is controlled; no physical Apple driver failure injected.','Only small byte/lifetime transfer; no model quality or performance claim.']))
