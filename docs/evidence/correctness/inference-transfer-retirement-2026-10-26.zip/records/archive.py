from pathlib import Path
import hashlib,json,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
D=R/'docs/evidence/correctness/inference-transfer-retirement-2026-10-26.json'
Z=D.with_suffix('.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):return dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=digest(p))
win=read(W/'final-summary.json');mac=read(W/'mac/records/summary.json')
assert len(win['runs'])==6 and all(r['process']['exit']==0 for r in win['runs'])
assert win['runs'][0]['tests']==47 and win['runs'][0]['passed']==47
for row in read(W/'source3-freeze.json'):
    assert digest(row['path'])==row['sha256'],row['path']
for row in win['runs']:
    for key in ('command','stdout','stderr'):
        assert digest(row[key]['path'])==row[key]['sha256']
assert mac['processes']['run-apple-closed']['exit']==0
assert mac['processes']['run-cpu-faults2']['exit']==0
for row in read(W/'mac/records/source-freeze-final.json'):
    assert digest(R/row['path'])==row['sha256'],row['path']
cleanup=read(W/'cleanup-result.json')
assert cleanup['current_case_present'] and cleanup['current_focused_present'] and cleanup['current_transfer_present']
assert all(not (R/n['path']).exists() for n in cleanup['targets'])
assert read(W/'header-owner/process.json')['exit']==0
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
patch=subprocess.check_output(['git','diff','--cached','--binary','--','engine','include','src','tests'],cwd=R)
(W/'product.patch').write_bytes(patch)
suffixes={'.json','.log','.py','.patch','.cc','.d'}
files=sorted(p for p in W.rglob('*') if p.is_file() and
    not p.is_relative_to(W/'header-owner/build') and (p.suffix in suffixes or p.name=='CMakeLists.txt'))
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for p in files:out.write(p,'records/'+str(p.relative_to(W)).replace('\\','/'))
    out.write(R/'test.ps1','records/test.ps1')
with zipfile.ZipFile(Z) as check:assert check.testzip() is None
document=dict(
    status='FINITE_SCOPE_PASS_WITH_PRESERVED_FAILURES',date='2026-10-26',
    source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    source_patch='records/product.patch',
    changes=[
        'Public nonmoving CompletionRetention reuses the original intrusive retirement chain without allocation, waits, another executor or a Completion layout change. Success transfers one existing owner reference; failure consumes none.',
        'Engine RetainedResources uses the public node and a host-only duplicate-attachment guard. Its atomic idle publication remains the reuse authority.',
        'StateTransfer now exposes nonblocking poll with independent retirement/status and forwards advisory cancellation. Pending diagnostics do not poison successful completion; final status is re-read after observing retirement.',
        'Common, Vulkan and Apple CopyBatch can return original successful retired writers after close. New binding, replay and submission remain closed; pending, unknown, failed and retained-submission gates remain.'
    ],
    validation=dict(
        windows=dict(completion='47/47',finite_processes=6,all_exit_zero=True,
            processes=[dict(name=n['name'],**n['process']) for n in win['runs']],
            unique_TUs=6,compile_invocations=8,compile_failures=2,
            summary='records/final-summary.json',summary_sha256=digest(W/'final-summary.json')),
        mac=dict(model='Mac16,12',architecture='arm64',
            apple_closed_recovery=mac['processes']['run-apple-closed'],
            cpu_controlled_faults=mac['processes']['run-cpu-faults2'],
            unique_TUs=4,compile_invocations=5,
            summary='records/mac/records/summary.json',summary_sha256=digest(W/'mac/records/summary.json')),
        sdk_header='Compute ownership and automatically selected install header set checked by configure-only LANGUAGES NONE project.'),
    checked_contracts=[
        'Inline success/error release, synchronous self-destruction, failed/duplicate attachment, inherited lifetime chain, unknown observation and abandonment until original retirement.',
        'Actual CPU copies plus controlled Completion: pending success, accepted prefix then rejected suffix, first-copy rejection, unknown retirement, abandonment scope/budget/image retention, supported and unsupported cancellation.',
        'Original complete writer and untouched suffix returned once only after success. Failed, pending and unknown work never publish writers. Closed controls reject rebinding/replay/submission after writer recovery.',
        'Actual Vulkan and Apple export/import with known successful retirement, then close and recover; host bytes remain independent after Backend destruction.',
        'Unchanged tiny GA/H64 Vulkan ordinary/MTP and explicit-prefix lag1 host-image continuation, snapshot, RNG and resource checks.'
    ],
    preserved_failures=[
        'Windows test fixture used an incomplete class in static table lambdas; moved table definition after complete type. Product compile TUs were not rebuilt.',
        'Windows and Mac test fixture tried to copy noncopyable LeasePools; replaced with a scoped weak-owner observation, without moving pools or extending their lifetime.',
        'Mac first CPU fault command used --cpu --faults. Actual standalone --faults was rerun with the same executable; no recompilation or repeated Apple run.'
    ],
    remaining=[
        'No physical GPU driver-failure/unknown-retirement injection in this batch. CPU controlled protocol is not labelled as GPU fault coverage.',
        'Model export/restore remains synchronous; StateTransfer primitive support does not claim asynchronous request parking is integrated.',
        'CopyBatch original Completion borrowing/Apple serialization and ContextRef detail remain separate SDK boundaries.',
        'No new CUDA/full335 model run, throughput/memory benchmark, model quality or natural MTP acceptance claim. Existing SDK/vendor archives were reused, not rebuilt from all current sources.'
    ],cleanup=cleanup,archive={**pin(Z),'entries':len(files)+1})
D.write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=pin(D),archive=document['archive']),ensure_ascii=False))
