"""After root's new test-only freeze: prepare-resume.py EXPECTED_SHA.

Preserves failed source/compile, reuses all four successful TUs, and changes only
the canonical transfer test to a new output directory. No native process starts.
"""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch',W/'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b,R = m.b,m.R


def prepare(expected,attempt=2):
    assert attempt in (2,3)
    p = b.read(W/('plan.json' if attempt == 2 else 'plan2.json'))
    assert not (W/f'plan{attempt}.json').exists()
    unit = next(x for x in p['units'] if x['name'] == 'transfer')
    before = unit['source']
    current = b.pin(R/'tests/tools/inference_state_transfer_test.cc')
    assert current['sha256'] == expected
    for row in b.read(p['source_freeze']['path']):
        if b.key(row['path']) != b.key(current['path']):
            b.exact(row)
    unit['source'] = current
    unit['command'] = m.m.command(Path(unit['recipe']['path']),Path(current['path']),W/f'compile{attempt}/transfer')
    frozen = m.m.c.closure([x['source']['path'] for x in p['units']],[Path(x['recipe']['path']) for x in p['units']])
    b.save(W/f'source{attempt}-freeze.json',frozen)
    p['source_freeze'] = b.pin(W/f'source{attempt}-freeze.json')
    p['test_correction'] = dict(old_source=before,new_source=current,
        preserved_source=b.pin(W/('transfer-first-failed-source.cc' if attempt == 2 else 'transfer-second-failed-source.cc')),
        failed_compile=b.pin(W/('compile/transfer/process.json' if attempt == 2 else 'compile2/transfer/process.json')),
        reason='MSVC requires complete fixture type before vtable lambdas.' if attempt == 2 else 'Observe the original noncopyable LeasePools through their retained owner rather than copying them.',
        previously_successful_TUs_recompiled=0,Model_compile_already_started=False)
    b.save(W/f'plan{attempt}.json',p)
    print('RESUME_PLAN',json.dumps(b.pin(W/f'plan{attempt}.json')),flush=True)


if __name__ == '__main__':
    if len(sys.argv) in (2,3) and len(sys.argv[1]) == 64:
        prepare(sys.argv[1],int(sys.argv[2]) if len(sys.argv) == 3 else 2)
    else:
        print(__doc__)
