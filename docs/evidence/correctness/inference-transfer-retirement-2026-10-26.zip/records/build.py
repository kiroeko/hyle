"""After final SOURCE_FROZEN: plan, then build. Default does nothing.

Reuse the already compiled Completion core; compile exactly five remaining TUs,
link focused Completion tests, canonical transfer tests and canonical Qwen case.
No model run, native/SDK/weight/report build, archive mutation, or download.
"""
from pathlib import Path
import ctypes
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-stream-padding-20261026'
spec = importlib.util.spec_from_file_location('previous',B/'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b = m.b


def plan():
    assert not (W/'plan.json').exists()
    # Parse the exact read-only ninja command as Windows argv, never via shell.
    command_text = b.read(W/'recipes/completion-test.json')['command_text'].strip()
    argc = ctypes.c_int()
    parse = ctypes.windll.shell32.CommandLineToArgvW
    parse.argtypes = [ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
    parse.restype = ctypes.POINTER(ctypes.c_wchar_p)
    argv = parse(command_text,ctypes.byref(argc))
    try:
        command = [argv[n] for n in range(argc.value)]
    finally:
        release = ctypes.windll.kernel32.LocalFree
        release.argtypes = [ctypes.c_void_p]
        release.restype = ctypes.c_void_p
        release(argv)
    test_recipe = W/'recipes/completion-test-command.json'
    b.save(test_recipe,dict(command=command,origin=b.pin(W/'recipes/completion-test.json')))
    units = [('common-copy','src/compute/batch_transfer.cc',W/'recipes/batch-transfer.json'),
        ('vulkan-copy','src/compute_route_vulkan/vulkan_copy_program.cc',W/'recipes/vulkan-copy.json'),
        ('completion-test','tests/compute/completion_test.cc',test_recipe),
        ('transfer','tests/tools/inference_state_transfer_test.cc',B/'compile/model/command.json'),
        ('model','tests/tools/qwen_host_image_test.cc',B/'compile/model/command.json')]
    jobs = [dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),
        command=m.command(recipe,R/source,W/'compile'/name)) for name,source,recipe in units]
    frozen = m.c.closure([x['source']['path'] for x in jobs],[recipe for _,_,recipe in units])
    b.save(W/'source-freeze.json',frozen)
    core = b.read(W/'core-ready.json')
    b.exact(core['object'])
    for row in b.read(core['dependencies']['path']):
        b.exact(row)
    baseline = {}
    for name,folder in [('case',B/'case'),('test',B/'test3')]:
        inputs = b.read(folder/'link-inputs.json')
        assert len(inputs) == (133 if name == 'case' else 136)
        assert all(Path(x['path']).is_file() for x in inputs)
        baseline[name] = dict(command=b.pin(folder/'link/command.json'),inputs=b.pin(folder/'link-inputs.json'),
            image=b.read(folder/'ready.json')['image'])
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',base_commit='9ae135d86',units=jobs,
        core_ready=b.pin(W/'core-ready.json'),source_freeze=b.pin(W/'source-freeze.json'),baselines=baseline,
        runtime=b.pin(B/'case/cpu-runtime2.json'),product_core_TUs_already_built=1,remaining_TUs=5,
        weight_report_native_SDK_TUs=0,archive_rewrites=0,native_runs=0))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)


def build(resume=False,plan_name='plan2.json'):
    p = b.read(W/(plan_name if resume else 'plan.json'))
    assert not (W/'ready.json').exists()
    frozen = b.read(p['source_freeze']['path'])
    for row in frozen:
        b.exact(row)
    b.exact(p['core_ready'])
    core = b.read(p['core_ready']['path'])
    b.exact(core['object'])
    for row in b.read(core['dependencies']['path']):
        b.exact(row)
    helper = b.helper()
    cl = p['units'][0]['command'][0]
    env = helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    own = {b.key(x['path']):x for x in frozen}
    objects,results = {'core':core['object']},[]
    for u in p['units']:
        b.exact(u['source'])
        out = Path(next(x[3:] for x in u['command'] if x.lower().startswith('/fo'))).parent
        reused = resume and (out/'process.json').exists()
        if reused:
            process = b.read(out/'process.json')
            assert process['exit'] == 0, 'Never reuse or overwrite a failed compile'
            actual = b.read(out/'actual-dependencies.json')
            for row in actual:
                b.exact(row)
        else:
            process = helper.execute(u['command'],env,out,timeout=180)
            dep = b.read(out/'dependencies.json')['Data']
            actual = [b.pin(path) for path in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
                assert b.key(path) in own and row['sha256'] == own[b.key(path)]['sha256'],str(path)
        if not reused:
            b.save(out/'actual-dependencies.json',actual)
        objects[u['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=u['name'],source=u['source'],object=objects[u['name']],
            process=process,reused_compilation=reused,dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:
            b.exact(row)
    artifacts = {}
    for name in ('test','transfer','case'):
        baseline = p['baselines']['test' if name == 'test' else 'case']
        inputs = b.read(baseline['inputs']['path'])
        remove = set()
        replacement = {}
        if name == 'test':
            remove = {b.key(x['path']) for x in inputs if any(x['path'].endswith(s) for s in [
                'compile\\file-stream-test\\unit.obj','compile\\tensor-test\\unit.obj',
                'compile2\\graph-test\\unit.obj','compile\\vulkan-test\\unit.obj'])}
            assert len(remove) == 4
        elif name == 'transfer':
            remove = {b.key(x['path']) for x in inputs if any(x['path'].endswith(s) for s in [
                'inference-stream-padding-20261026\\compile\\model\\unit.obj',
                'inference-stream-padding-20261026\\compile\\weights\\unit.obj',
                'inference-review-fixes-20261026\\product2\\report\\unit.obj'])}
            assert len(remove) == 3
        else:
            old = next(x for x in inputs if x['path'].endswith('inference-stream-padding-20261026\\compile\\model\\unit.obj'))
            replacement[b.key(old['path'])] = objects['model']
        added = [objects['core'],objects['common-copy'],objects['vulkan-copy'],
            *([objects['completion-test' if name == 'test' else 'transfer']] if name != 'case' else [])]
        image = W/name/'link'/('completion-test.exe' if name == 'test' else 'state-transfer-test.exe' if name == 'transfer' else 'host-image-test.exe')
        args,removed,replaced = [],0,0
        for arg in b.read(baseline['command']['path'])['command']:
            if b.key(arg) in remove:
                removed += 1
                continue
            if b.key(arg) in replacement:
                arg = replacement[b.key(arg)]['path']
                replaced += 1
            elif arg.upper().startswith('/OUT:'):
                arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'):
                arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'):
                arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            args.append(arg)
        args += [x['path'] for x in added]
        assert removed == len(remove) and replaced == len(replacement)
        linked = helper.execute(args,env,image.parent,timeout=120)
        final = [replacement.get(b.key(x['path']),x) for x in inputs if b.key(x['path']) not in remove]+added
        assert len(final) == (136 if name in ('test','case') else 134)
        b.save(W/name/'link-inputs.json',final)
        runtime = b.read(p['runtime']['path'])
        b.exact(runtime['native'])
        alias = image.parent/Path(runtime['native']['path']).name
        os.link(runtime['native']['path'],alias)
        runtime['native_hardlink'] = b.pin(alias)
        b.save(W/name/'runtime.json',runtime)
        ready = dict(status='LINKED_NOT_RUN',image=b.pin(image),inputs=b.pin(W/name/'link-inputs.json'),
            runtime=b.pin(W/name/'runtime.json'),link=linked,archive_rewrites=0)
        b.save(W/name/'ready.json',ready)
        artifacts[name] = ready
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',plan=b.pin(W/(plan_name if resume else 'plan.json')),core=core,
        compiled=results,artifacts=artifacts,SDK_native_weight_report_compiles=0,native_runs=0))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']:
        plan()
    elif sys.argv[1:] == ['build']:
        build()
    elif sys.argv[1:] == ['resume']:
        build(resume=True)
    elif sys.argv[1:] == ['resume3']:
        build(resume=True,plan_name='plan3.json')
    else:
        print(__doc__)
