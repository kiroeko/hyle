"""Only compile the frozen Completion implementation. No link or native run."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('previous',R/'.scratch/inference-stream-padding-20261026/build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b = m.b


def build():
    source = R/'src/compute/completion.cc'
    header = R/'include/hyle/compute/completion_retention.h'
    assert b.pin(source)['sha256'] == 'ae74d3d0e3b7e14a0ebbc081ec6302d83cac693a91b3259e75414bc43eb3ef49'
    assert b.pin(header)['sha256'] == 'c1aee9f386fbf4daf1cd971e3cf496426bfab65d241c88275035b05f09685b6b'
    recipe = W/'recipes/completion.json'
    out = W/'compile/core'
    command = m.command(recipe,source,out)
    frozen = m.c.closure([source],[recipe])
    b.save(W/'core-source-freeze.json',frozen)
    b.save(W/'core-plan.json',dict(source=b.pin(source),header=b.pin(header),recipe=b.pin(recipe),
        command=command,compiled_TUs=1,link=False,native_run=False))
    helper = b.helper()
    cl = command[0]
    env = helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    process = helper.execute(command,env,out,timeout=180)
    dep = b.read(out/'dependencies.json')['Data']
    actual = [b.pin(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]
    own = {b.key(p['path']):p for p in frozen}
    for row in actual:
        p = Path(row['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'):
            assert b.key(p) in own and row['sha256'] == own[b.key(p)]['sha256'],str(p)
    b.save(out/'actual-dependencies.json',actual)
    b.save(W/'core-ready.json',dict(status='COMPILED_NOT_LINKED_OR_RUN',object=b.pin(out/'unit.obj'),
        source=b.pin(source),plan=b.pin(W/'core-plan.json'),source_freeze=b.pin(W/'core-source-freeze.json'),
        dependencies=b.pin(out/'actual-dependencies.json'),process=process))
    print('CORE_READY',json.dumps(b.pin(W/'core-ready.json')),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['build']:
        build()
    else:
        print(__doc__)
