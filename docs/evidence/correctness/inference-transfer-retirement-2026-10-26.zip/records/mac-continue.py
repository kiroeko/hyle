from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026')
P=json.loads((W/'plan.json').read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(tag,cmd,timeout=120):
    d=W/tag;d.mkdir(exist_ok=False)
    save(d/'command.json',dict(command=cmd,cwd=str(W),environment=P['environment']))
    env=os.environ.copy();env.update(P['environment']);start=time.perf_counter()
    with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
        proc=subprocess.Popen(cmd,cwd=W,env=env,stdout=out,stderr=err)
        save(d/'running.json',dict(pid=proc.pid));code=proc.wait(timeout=timeout)
    row=dict(tag=tag,pid=proc.pid,exit=code,seconds=time.perf_counter()-start)
    save(d/'process.json',row);print(json.dumps(row),flush=True)
    if code:raise RuntimeError(tag+' failed')
    return row
shutil.copyfile(W/'source-freeze.json',W/'source-freeze-initial.json')
pins=json.loads((W/'source-freeze.json').read_text())
for row in pins:
    actual=(W/'source'/row['path']).read_bytes()
    if row['path']=='tests/tools/inference_state_transfer_test.cc':
        row.update(bytes=len(actual),sha256=hashlib.sha256(actual).hexdigest())
    else:assert hashlib.sha256(actual).hexdigest()==row['sha256'],row['path']
save(W/'source-freeze-final.json',pins)
job=P['jobs'][3];old_object=str(W/'inference_state_transfer_test.o');new_object=str(W/'test2.o')
compile=[x.replace(old_object,new_object) for x in job['command']]
rows=[run('compile-test2',compile)]
link=[new_object if x==old_object else x for x in P['jobs'][-1]['command']]
rows.append(run('link',link))
image=W/'state-transfer'
save(W/'ready.json',dict(image=dict(path=str(image),bytes=image.stat().st_size,sha256=hashlib.sha256(image.read_bytes()).hexdigest()),scope=P['scope']))
rows.append(run('run-apple-closed',[str(image),'--apple','--closed-recovery'],30))
rows.append(run('run-cpu-faults',[str(image),'--cpu','--faults'],30))
save(W/'actual-dependencies.json',{p.name:p.read_text() for p in W.glob('*.o.d')})
save(W/'map-selection.json',dict(lines=[s for s in (W/'image.map').read_text().splitlines()
    if any(n in s for n in ('completion.o','batch_transfer.o','apple_copy_program.o','test2.o'))]))
save(W/'summary.json',dict(status='PASS',processes=rows,compiled_TUs=5,successful_compile_TUs=4,SDK_builds=0,HTTP=0,
     scope=P['scope'],preserved_failure='Original transfer test tried to copy noncopyable LeasePools; test-only observer fixed.',
     limits=['CPU accepted/error/unknown retirement is controlled; no physical Apple driver failure injected.','Only small byte/lifetime transfer; no model quality or performance claim.']))
