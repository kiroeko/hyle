from pathlib import Path
import base64,hashlib,json,subprocess
W=Path(__file__).resolve().parent/'mac'
M='/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026'
code=f'''from pathlib import Path
import base64,hashlib,json
w=Path({M!r})
rows=[]
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.is_relative_to(w/'source') or p.suffix not in ('.json','.log','.py','.d'):continue
 data=p.read_bytes();rows.append(dict(path=str(p.relative_to(w)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),body=base64.b64encode(data).decode()))
print(json.dumps(rows))
'''
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -']
p=subprocess.run(cmd,input=code,text=True,capture_output=True,timeout=45)
(W/'collection-process.json').write_text(json.dumps(dict(command=cmd,exit=p.returncode,stderr=p.stderr),indent=2)+'\n')
if p.returncode:raise RuntimeError(p.stderr)
receipts=[]
for row in json.loads(p.stdout):
    dest=(W/'records'/row['path']).resolve();assert dest.is_relative_to((W/'records').resolve())
    raw=base64.b64decode(row.pop('body'));assert hashlib.sha256(raw).hexdigest()==row['sha256']
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);receipts.append(row)
(W/'collected-files.json').write_text(json.dumps(receipts,indent=2)+'\n')
summary=json.loads((W/'records/summary.json').read_text())
assert summary['status']=='FINITE_SCOPE_PASS_WITH_PRESERVED_FAILURES'
assert summary['processes']['run-apple-closed']['exit']==0
assert summary['processes']['run-cpu-faults2']['exit']==0
print(json.dumps(dict(status=summary['status'],files=len(receipts),bytes=sum(r['bytes'] for r in receipts))))
