from pathlib import Path
import json,subprocess,time
w=Path(__file__).resolve().parent
cmd=['cmake','-S',str(w/'source'),'-B',str(w/'build')]
start=time.perf_counter();p=subprocess.run(cmd,capture_output=True,text=True)
(w/'stdout.log').write_text(p.stdout);(w/'stderr.log').write_text(p.stderr)
(w/'process.json').write_text(json.dumps(dict(command=cmd,exit=p.returncode,seconds=time.perf_counter()-start),indent=2)+'\n')
print(p.stdout);print(p.stderr)
assert p.returncode==0
