# AO: only superseded executables/linker outputs; all cached source/objects stay.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = @('vulkan-retained-paged-20261022','vulkan-qwen-assembly-20261022','vulkan-bf16-linear-20261022') | ForEach-Object { Join-Path $workspace ('.scratch\' + $_) }
$targets = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\diagnostic-link1\qwen.exe'; Bytes = 68982784; SHA256 = '821f1e869581dc9630d4412ed97c77c2a625a8a3f0c09a4fbc72fea4b98d86de' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\diagnostic-link1\qwen.exp'; Bytes = 24985; SHA256 = 'f3a918f5a9c822faa9c4e20786eae9509d608777bd21d1f04a5c487f6b1770b7' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\diagnostic-link1\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\diagnostic-link1\qwen.map'; Bytes = 32548442; SHA256 = 'cfc6c63b4c1f06b00512c4a95a9553d4326439a7d3c40c1531af7eae74df02ab' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\qwen-link1\qwen.exe'; Bytes = 68981760; SHA256 = '99d63c2730591a543ed10e4725e66b3014c6e7d462625990998b3e8a49cf7a56' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\qwen-link1\qwen.exp'; Bytes = 24979; SHA256 = 'f0a49374814bc84f29cdc151338ca0197c35022da6d0ca05aa5631fd08aa5d7e' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\qwen-link1\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\qwen-link1\qwen.map'; Bytes = 32546516; SHA256 = 'fe58fadefe23ce0108ca83922fa21cc78adb9e22eb24a07d0186dcdbd947fe1c' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\qwen-link2\qwen.exp'; Bytes = 24979; SHA256 = '520d224501a724eff695046a68d31a6eaf5b84f5d1d63b2480654d2cf9a2f092' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\qwen-link2\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\qwen-link2\qwen.map'; Bytes = 32547369; SHA256 = '606bf9402e9d3c4e5507ee764cdd89285720fd24a86f3ac314a89754b88ef0d6' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\reuse-link1\reuse.exp'; Bytes = 24981; SHA256 = '043e1fb1979cdade73f0e706c0e319d19842c99b24b657467bf8649b8bd7b81d' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\reuse-link1\reuse.lib'; Bytes = 41474; SHA256 = '49931d400525d89837ada805b2102071f231a0de282d944255c7513ee71e10b8' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\reuse-link1\reuse.map'; Bytes = 30510901; SHA256 = '4e627c1067c8141cfdf9a22bc353ba6ec9e306625d99fb6bf1cca16a0ce0b95d' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\test-link1\test.exe'; Bytes = 68165120; SHA256 = '9cc9e30e114e5e3ef447b03a764ee722a39374ec9dd40ed75b7acd8948c07512' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\test-link1\test.exp'; Bytes = 24979; SHA256 = 'cfa913bceeceb0bea0c9e3062e1e81ebed45838fdad9464c12ec24751918bc32' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\test-link1\test.lib'; Bytes = 41384; SHA256 = 'e8b2f56b280c09b2f7a259f184ba9923439c597a6227843d256c824b87a691fa' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\test-link1\test.map'; Bytes = 30872330; SHA256 = '33b3b1dc50bac82c0b34cfe8ea4ebf62a011d97aee60f7107d56c04bda3a8cd6' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\test-link2\test.exp'; Bytes = 24979; SHA256 = '1e760d0bc29a0a136ced27c319c432b6dfab85850e7b353e76e5bf5754afeb54' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\test-link2\test.lib'; Bytes = 41384; SHA256 = 'e8b2f56b280c09b2f7a259f184ba9923439c597a6227843d256c824b87a691fa' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-retained-paged-20261022\test-link2\test.map'; Bytes = 30872983; SHA256 = '35817b38e530b48923d2b211ed14e4ae5b1f1ea91f1b3ba0657025b21f8e1dc1' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link3\qwen.exe'; Bytes = 68978176; SHA256 = '8a7043b6c9a4611c81d4ce09b81515467309d45316b7498ecc7ea172368b4585' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link3\test.exe'; Bytes = 67955712; SHA256 = 'f53ed83d3ba3dfb153ce9ccef226b5471ca77517b17946a5eefb510497693c4c' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\qwen-link1\qwen.exe'; Bytes = 68980224; SHA256 = 'e9b4f32661c8d0efc81f0be9bda1012bcae426e343531db917a032be30ec87e5' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link2\test.exe'; Bytes = 67931136; SHA256 = '22a2d167fcdd33ba0d33edb7e1395b1c72b112751f077700ebfc19abed91e5e2' }
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  $inside = @($allowed | Where-Object { $leaf.FullName.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) }).Count -eq 1
  if ($leaf.PSIsContainer -or -not $inside -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
