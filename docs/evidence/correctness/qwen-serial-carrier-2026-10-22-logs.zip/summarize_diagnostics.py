"""Summarize observed heap snapshots and requested native storage separately."""
from pathlib import Path
import collections, hashlib, json, re
S=Path(__file__).resolve().parent

def identity(p):
    x=p.read_bytes(); return dict(path=str(p),bytes=len(x),sha256=hashlib.sha256(x).hexdigest())

def analyze(attempt):
    folder=S/f'qwen-N2R2-run{attempt}'; path=folder/'stderr.log'
    lines=path.read_text(encoding='utf8',errors='replace').splitlines()
    failure=next(i for i,x in enumerate(lines)if 'Device memory allocation of size 'in x)
    before=lines[:failure+1]
    regions=[(int(a),int(b))for line in before if (m:=re.fullmatch(r'AM_REGION_ALLOCATED id=(\d+) private=(\d+)',line))for a,b in [m.groups()]]
    heaps=[]
    for line in lines:
        if line.startswith('AP_MEMORY_HEAP '):
            heaps.append({k:int(v)for k,v in re.findall(r'(region|heap|size|flags|usage|budget)=(\d+)',line)})
    allocations=collections.Counter(); frees=collections.Counter()
    for line in before:
        m=re.search(r'ggml_vulkan memory: .*: ([+-])(\d+(?:\.\d+)? (?:B|KiB|MiB|GiB)) (device|host) at ',line)
        if m: (allocations if m[1]=='+'else frees)[(m[2],m[3])]+=1
    totals=[line for line in before if 'Total device:'in line]
    last_batch=next((line for line in reversed(before)if line.startswith('mtp_batch ')),None)
    return dict(result=json.loads((folder/'result.json').read_bytes()),stderr=identity(path),
        failure_line=failure+1,failure=lines[failure],last_batch=last_batch,
        successful_region_graph_allocations=len(regions),positive_region_graph_allocations=sum(n>0 for _,n in regions),
        cumulative_successful_region_graph_requested_capacity_bytes=sum(n for _,n in regions),
        last_region=regions[-1],heap_snapshots=heaps,
        native_logger_last_report_before_failure=totals[-1]if totals else None,
        native_requested_allocations_before_failure=[dict(size=k[0],kind=k[1],count=v,net_count=v-frees[k])for k,v in allocations.most_common(12)],
        caveats=[
            'Graph capacity is cumulative across constructions, not live/peak physical memory or VkDeviceMemory allocation count.',
            'Heap usage/budget are Vulkan implementation estimates at observed instants; do not sum distinct heaps as one fungible pool.',
            'Original ggml memory logger prints requested sizes rounded to two decimals and excludes Hyle-owned allocations and driver internal costs.',
            'Failure callback may run after failed local temporary cleanup; it is not the exact maximum before allocation.',
            'No new throughput, quality, or full multi-session success claim.'
        ])

report=dict(status='ACTUAL_FAILURE_DIAGNOSTICS',attempts=[analyze(1),analyze(2)])
out=S/'review/memory-observations.json'; out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
for x in report['attempts']:
    print(json.dumps({k:x[k]for k in ['failure','last_batch','successful_region_graph_allocations','positive_region_graph_allocations','cumulative_successful_region_graph_requested_capacity_bytes','last_region','native_logger_last_report_before_failure']},indent=2))
print('REPORT',identity(out))
