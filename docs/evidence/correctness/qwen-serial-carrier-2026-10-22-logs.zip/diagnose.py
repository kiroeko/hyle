"""Failure-time Vulkan heap query plus cached region storage counters."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode = True
S=Path(__file__).resolve().parent; R=S.parents[1]
AO=R/'.scratch/vulkan-retained-paged-20261022'
AM=R/'.scratch/vulkan-qwen-assembly-20261022'
spec=importlib.util.spec_from_file_location('ap_cached',AO/'build.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b,c,h=m.b,m.c,m.h
h.S=S

def compile_one(attempt):
    original=R/'src/compute_provider_ggml_vulkan/region.cc'
    assert b.identity(original)['sha256']=='f3f3a8d642906f2f17fa6293241a2a70c9c552988ebcdcd1b1a6247de25915d5'
    text=(AM/'diagnostic/source/region.cc').read_text(encoding='utf8')
    needle='namespace hyle::compute::ggml_vulkan::detail {'
    assert text.count(needle)==1
    helper=(S/'review/region_memory_diagnostic.inc').read_text(encoding='utf8')
    text=text.replace(needle,helper+'\n'+needle)
    fail='if(!diagnostic_allocation) { std::fprintf(stderr,"AM_REGION_FAIL id=%zu\\n",diagnostic_index); return std::unexpected(diagnostic_allocation.error()); }'
    assert text.count(fail)==1
    text=text.replace(fail,fail.replace('return std::unexpected','ap_dump_heap_budget(state.device,diagnostic_index); return std::unexpected'))
    begin='const auto diagnostic_index = ++diagnostic_region;'
    assert text.count(begin)==1
    text=text.replace(begin,begin+'\n    if(diagnostic_index==1 || diagnostic_index%512==0) ap_dump_heap_budget(state.device,diagnostic_index);')
    work='HYLE_ASSIGN_OR_RETURN(state.work, state.device.create_work());'
    assert text.count(work)==1
    text=text.replace(work,'''auto diagnostic_work=state.device.create_work();
    if(!diagnostic_work) { std::fprintf(stderr,"AP_WORK_FAIL region=%zu\\n",diagnostic_index); ap_dump_heap_budget(state.device,diagnostic_index); return std::unexpected(diagnostic_work.error()); }
    state.work=std::move(*diagnostic_work);''')
    submit='''state_->work.submit(state_->graph.get(), state_->graph.lease());'''
    assert text.count(submit)==1
    text=text.replace(submit,submit+'''
  if(!result.status.ok()) { std::fprintf(stderr,"AP_SUBMIT_FAIL\\n"); ap_dump_heap_budget(state_->device,0); }''')
    source=S/'diagnostic/source/region.cc'; source.parent.mkdir(parents=True,exist_ok=True)
    source.write_text(text,encoding='utf8')
    recipe=c.read(AM/'diagnostic/recipe.json')
    recipe['command']=[{'-MD':'/MD','-O2':'/O2'}.get(x,x)for x in recipe['command']]
    path=S/'diagnostic/recipe.json'; c.save(path,recipe)
    h.RECIPES['diag-region']=path; h.SOURCES['diag-region']=source
    h.compile_one('diag-region',attempt)

def link(attempt):
    root=AO/'qwen-link2'; base=c.read(root/'link-plan.json')
    old=c.read(AM/'diagnostic/recipe.json')['object']
    new=c.read(S/f'compile{attempt}/diag-region/identity.json')['object']
    assert sum(c.key(x['path'])==c.key(old['path'])for x in base['inputs'])==1
    inputs=[new if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
    for x in inputs: assert b.identity(x['path'])==x
    out=S/f'diagnostic-link{attempt}'; out.mkdir(); (out/'tmp').mkdir(); image=out/'qwen.exe'
    command=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,diagnostic_only=True,SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out); c.execute('link',command,env,out)
    runtime=c.read(root/'runtime-environment.json'); c.save(out/'runtime-environment.json',runtime)
    for x in runtime.get('staged_dlls',[]):
        p=Path(x['path'])
        if not(out/p.name).exists(): os.link(p,out/p.name)
    c.save(out/'ready.json',dict(image=b.identity(image))); print('LINKED diagnostic',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('actions',nargs='+',choices=['compile','link']); p.add_argument('--attempt',type=int,default=1); a=p.parse_args()
    for action in a.actions: compile_one(a.attempt)if action=='compile'else link(a.attempt)
