param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$scratch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch')) + [IO.Path]::DirectorySeparatorChar
$receipt = Join-Path $workspace '.scratch/vulkan-native-memory-20261022/cleanup-result.json'
if (Test-Path -LiteralPath $receipt) { throw 'This exact cleanup has already been executed; do not rerun.' }
$targets = @'
[
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\cuda-main-link1\\qwen.exp",
    "bytes": 24983,
    "sha256": "49265e15c0f9e09b106e9c4b97285194a44cced4929161951fd42b1070c20d40"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\cuda-main-link1\\qwen.lib",
    "bytes": 41384,
    "sha256": "339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\cuda-main-link1\\qwen.map",
    "bytes": 59065448,
    "sha256": "a39bb7f0999c77cb2b16091add7f50d99201141ca7c5091f856bb7034823bdbf"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link1\\qwen.exp",
    "bytes": 24984,
    "sha256": "9d9d29740b4782c9426547b5bf2cc0d4a2cf29a39025e9ff6ef86abb4a2017dc"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link1\\qwen.lib",
    "bytes": 41384,
    "sha256": "339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link1\\qwen.map",
    "bytes": 32549279,
    "sha256": "de10a38c5f2cf03c1f038bd87fde105217c6fbfcee8aadf5945ea5ee66239014"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link2\\qwen.exp",
    "bytes": 24984,
    "sha256": "7337020c798866c156a56fce5b36afb65f4b565533f214164ffc27cea861cebb"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link2\\qwen.lib",
    "bytes": 41384,
    "sha256": "339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link2\\qwen.map",
    "bytes": 32549487,
    "sha256": "2609d0f8d0d8a2d7e457de8610f96413c3eb95277ab3bdb987901f43bdf36e34"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\retirement-link1\\qwen.exp",
    "bytes": 24984,
    "sha256": "326ba6450faf4833e79b3392dc8608d389996b6c6ad58e521240395b967bd979"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\retirement-link1\\qwen.lib",
    "bytes": 41384,
    "sha256": "339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\retirement-link1\\qwen.map",
    "bytes": 58654224,
    "sha256": "1c3c72c55e8fbee394ecbf7c9235d685eca11861fb9cae9acbf0cd14db3da4a4"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\vulkan-main-link1\\qwen.exp",
    "bytes": 24985,
    "sha256": "8951bb268367990e64f287e4b6e7b0b058803add702d5e83453a498d6ea07c92"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\vulkan-main-link1\\qwen.lib",
    "bytes": 41384,
    "sha256": "339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\vulkan-main-link1\\qwen.map",
    "bytes": 32591248,
    "sha256": "3de5ffade746928b2cbf232b135597e1ade9e79df86c55c0a713cb23d25c054a"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link1\\qwen.exe",
    "bytes": 68985856,
    "sha256": "2397b72abc91e25f0ee335461c8df21ce9e98cb1f8558cc4ad746d5f77845951"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\diagnostic-link2\\qwen.exe",
    "bytes": 68985856,
    "sha256": "7a0761b4bcf89673756fc31f5a8238420b64ee1fda439408536ecea05089c51f"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-native-memory-20261022\\retirement-link1\\qwen.exe",
    "bytes": 140230144,
    "sha256": "97ffd1e43c9aebbef8166b27971ad4b62f75e9b3a7e4fe9033f4eb8e5370ba36"
  },
  {
    "path": "C:\\public\\project-hyle\\hyle\\.scratch\\vulkan-retained-paged-20261022\\qwen-link2\\qwen.exe",
    "bytes": 68982784,
    "sha256": "118bd52eab44664f35d1b1f8b3b4aacdc4b163b5c71afe3fddfafca267a3daa6"
  }
]
'@ | ConvertFrom-Json
$checked = @()
foreach ($item in $targets) {
  $path = (Resolve-Path -LiteralPath $item.path).Path
  if (-not $path.StartsWith($scratch, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside intended scratch workspace: $path" }
  $file = Get-Item -LiteralPath $path
  if ($file.PSIsContainer -or $file.Length -ne $item.bytes) { throw "File identity changed: $path" }
  if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "SHA256 changed: $path" }
  $checked += $path
}
$bytes = ($targets | Measure-Object -Property bytes -Sum).Sum
if (-not $Execute) {
  [pscustomobject]@{ action='checked_only'; exact_files=$checked.Count; logical_bytes=$bytes } | ConvertTo-Json
  return
}
foreach ($path in $checked) { Remove-Item -LiteralPath $path -Force }
foreach ($path in $checked) { if (Test-Path -LiteralPath $path) { throw "Still present after deletion: $path" } }
$result = [pscustomobject]@{ status='executed_once'; removed_files=$checked.Count; removed_logical_bytes=$bytes; physical_free_space_change_unknown=$true; targets=$targets }
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $receipt -Encoding utf8
$result | Select-Object status, removed_files, removed_logical_bytes | ConvertTo-Json
