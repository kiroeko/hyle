"""One cached Apple consumer TU plus the same N2/R2 functional regression."""
from pathlib import Path
import argparse, importlib.util, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]
AL=R/'.scratch/qwen-retained-budget-20261022'
spec=importlib.util.spec_from_file_location('ap_apple_build',AL/'apple.py')
h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
h.S=S; h.ROOT=h.m.BASE+'/qwen-serial-slot-20261022'
p=argparse.ArgumentParser(description=__doc__); p.add_argument('action',choices=['build','run']); a=p.parse_args()
if a.action=='build': h.build(1,False)
else:
    spec=importlib.util.spec_from_file_location('ap_apple_run',AL/'run.py')
    runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
    runner.S=S; runner.h.ROOT=h.ROOT
    runner.apple('N2R2')
