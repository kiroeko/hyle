"""Run the same actual N2/R2 workload with the current single-slot consumer."""
from pathlib import Path
S=Path(__file__).resolve().parent; R=S.parents[1]
source=R/'.scratch/vulkan-retained-paged-20261022/run_sessions.py'
text=source.read_text(encoding='utf8')
text=text.replace('S=Path(__file__).resolve().parent;R=S.parents[1]',
                  'S=Path('+repr(str(S))+');R=S.parents[1]')
text=text.replace('args=p.parse_args()',"p.add_argument('--backend',choices=['vulkan','cuda'],required=True);args=p.parse_args()")
text=text.replace("root=S/('diagnostic-link1'if args.diagnostic else'qwen-link'+str(args.image_attempt))",
                  "root=S/(args.backend+'-main-link'+str(args.image_attempt))")
text=text.replace("('qwen-N2R2-run'+str(args.attempt))","(args.backend+'-N2R2-run'+str(args.attempt))")
text=text.replace("now['backend']=='vulkan'","now['backend']==args.backend ")
exec(compile(text,str(source),'exec'),{'__name__':'__main__','__file__':str(source)})
