"""Consumer-only serial-slot change over current cached Vulkan/CUDA closures."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]
AO=R/'.scratch/vulkan-retained-paged-20261022'
AL=R/'.scratch/qwen-retained-budget-20261022'
spec=importlib.util.spec_from_file_location('ap_product_cached',AO/'build.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b,c,h=m.b,m.c,m.h; h.S=S
PROBES=['retirement','batch','mtp_session','retained_budget']
SOURCES={tag:R/('tools/qwen35_text/'+tag+'_probe.cc')for tag in PROBES}
SOURCES.update({'vulkan-main':R/'tools/qwen35_text/main.cc','cuda-main':R/'tools/qwen35_text/main.cc'})
RECIPES={tag:AL/'compile1/main/identity.json'for tag in SOURCES}
RECIPES['vulkan-main']=AO/'compile2/main/identity.json'

def compile_one(tag,attempt):
    original=c.read(RECIPES[tag])
    original['command']=[{'-MD':'/MD','-O2':'/O2'}.get(x,x)for x in original['command']]
    p=S/'recipes'/f'{tag}.json'; p.parent.mkdir(exist_ok=True); c.save(p,original)
    h.RECIPES[tag]=p; h.SOURCES[tag]=SOURCES[tag]
    h.compile_one(tag,attempt)

def link(tag,attempt):
    root=AO/'qwen-link2'if tag=='vulkan-main'else AL/'cuda-link1'
    base=c.read(root/'link-plan.json'); old=c.read(RECIPES[tag])['object']
    record=c.read(S/f'compile{attempt}/{tag}/identity.json'); new=record['object']
    assert all(b.identity(x['path'])==x for x in [record['source'],record['object'],*record['dependencies']])
    assert sum(c.key(x['path'])==c.key(old['path'])for x in base['inputs'])==1
    inputs=[new if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
    for x in inputs: assert b.identity(x['path'])==x
    out=S/f'{tag}-link{attempt}'; out.mkdir(); (out/'tmp').mkdir(); image=out/'qwen.exe'
    command=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_record=b.identity(S/f'compile{attempt}/{tag}/identity.json'),SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out); c.execute('link',command,env,out)
    runtime=c.read(root/'runtime-environment.json'); c.save(out/'runtime-environment.json',runtime)
    for x in runtime.get('staged_dlls',[]):
        p=Path(x['path'])
        if not(out/p.name).exists(): os.link(p,out/p.name)
    c.save(out/'ready.json',dict(image=b.identity(image))); print('LINKED',tag,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('actions',nargs='+',choices=[*SOURCES,*['link-'+x for x in SOURCES]]); p.add_argument('--attempt',type=int,default=1); a=p.parse_args()
    for action in a.actions: link(action[5:],a.attempt)if action.startswith('link-')else compile_one(action,a.attempt)
