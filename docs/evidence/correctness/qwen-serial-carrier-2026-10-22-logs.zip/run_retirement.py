"""Actual CUDA blocked-queue retirement/retry regression for the serial slot."""
from pathlib import Path
import argparse, json, os, subprocess, time
S=Path(__file__).resolve().parent; R=S.parents[1]
p=argparse.ArgumentParser(description=__doc__); p.add_argument('--attempt',type=int,required=True); a=p.parse_args()
root=S/'retirement-link1'; out=S/f'retirement-run{a.attempt}'; out.mkdir()
command=[str(root/'qwen.exe'),'--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),'--mtp','on']
env=dict(os.environ,PATH=json.loads((root/'runtime-environment.json').read_bytes())['PATH'])
record=dict(command=command,cwd=str(R),started=time.time(),performance_comparison=False)
def save(path,x): path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
    child=subprocess.Popen(command,cwd=R,env=env,stdout=so,stderr=se)
    record.update(pid=child.pid,state='running'); save(out/'command.json',record); save(S/'live.json',record)
    print('START retirement PID',child.pid,flush=True); child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']); save(out/'result.json',record); save(S/'live.json',record)
if child.returncode:
    print((out/'stderr.log').read_text(errors='replace')[-6500:]); raise SystemExit(1)
report=json.loads((out/'stdout.log').read_bytes()); assert report['status']=='PASS'
print(json.dumps(report),flush=True)
