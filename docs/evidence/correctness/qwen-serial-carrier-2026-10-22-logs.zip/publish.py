"""Publish the bounded serial-carrier fix with actual red/green evidence."""
from pathlib import Path
import argparse, hashlib, json, zipfile
S=Path(__file__).resolve().parent; R=S.parents[1]
DEST=R/'docs/evidence/correctness/qwen-serial-carrier-2026-10-22.json'
ARCHIVE=DEST.with_name(DEST.stem+'-logs.zip')
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def prepare():
    old=R/'test.ps1'; before=S/'before/test.ps1'; before.parent.mkdir(parents=True,exist_ok=True)
    before.write_bytes(old.read_bytes())
    assert ident(old)['sha256']=='4f7fd8dfdf8b00f4dabf558f8570414449dcb5b6e426693851d6dc25a961807a'
    paths=[]
    for folder in sorted(S.glob('*-link*')):
        if folder.is_dir():paths.extend(x for x in folder.iterdir()if x.is_file()and x.suffix.lower()in ['.map','.lib','.exp'])
    paths += [S/'diagnostic-link1/qwen.exe',S/'diagnostic-link2/qwen.exe',S/'retirement-link1/qwen.exe',R/'.scratch/vulkan-retained-paged-20261022/qwen-link2/qwen.exe']
    records=[ident(x)for x in paths]
    assert len({x['path']for x in records})==len(records)
    for x in records:
        p=Path(x['path']).resolve();assert p.is_file()and p.is_relative_to(R/'.scratch')
    manifest=dict(files=records,total_logical_bytes=sum(x['bytes']for x in records),
                  retained=['vulkan-main-link1/qwen.exe','cuda-main-link1/qwen.exe','all source, object, command, result and dependency caches'],
                  physical_free_space_change_unknown=True)
    save(S/'cleanup-plan.json',manifest)
    table=json.dumps(records,indent=2)
    script=r'''param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$scratch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch')) + [IO.Path]::DirectorySeparatorChar
$receipt = Join-Path $workspace '.scratch/vulkan-native-memory-20261022/cleanup-result.json'
if (Test-Path -LiteralPath $receipt) { throw 'This exact cleanup has already been executed; do not rerun.' }
$targets = @'
TABLE
'@ | ConvertFrom-Json
$checked = @()
foreach ($item in $targets) {
  $path = (Resolve-Path -LiteralPath $item.path).Path
  if (-not $path.StartsWith($scratch, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside intended scratch workspace: $path" }
  $file = Get-Item -LiteralPath $path
  if ($file.PSIsContainer -or $file.Length -ne $item.bytes) { throw "File identity changed: $path" }
  if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "SHA256 changed: $path" }
  $checked += $path
}
$bytes = ($targets | Measure-Object -Property bytes -Sum).Sum
if (-not $Execute) {
  [pscustomobject]@{ action='checked_only'; exact_files=$checked.Count; logical_bytes=$bytes } | ConvertTo-Json
  return
}
foreach ($path in $checked) { Remove-Item -LiteralPath $path -Force }
foreach ($path in $checked) { if (Test-Path -LiteralPath $path) { throw "Still present after deletion: $path" } }
$result = [pscustomobject]@{ status='executed_once'; removed_files=$checked.Count; removed_logical_bytes=$bytes; physical_free_space_change_unknown=$true; targets=$targets }
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $receipt -Encoding utf8
$result | Select-Object status, removed_files, removed_logical_bytes | ConvertTo-Json
'''.replace('TABLE',table)
    old.write_text(script,encoding='utf8'); (S/'cleanup-test.ps1').write_bytes(old.read_bytes())
    print(json.dumps(dict(script=ident(old),exact_files=len(records),logical_bytes=manifest['total_logical_bytes']),indent=2))

def publish():
    assert not DEST.exists()and not ARCHIVE.exists()
    frozen=read(S/'consumer-single-slot/source-freeze.json')
    for f in frozen['files']:assert ident(R/f['path'])['sha256']==f['after_sha256']
    assert read(S/'cleanup-result.json')['status']=='executed_once'
    cases={}
    for backend in ['cuda','vulkan']:
        out=S/f'{backend}-N2R2-run1'; comparison=read(out/'comparison.json'); result=read(out/'result.json')
        assert result['exit']==0 and all(comparison['fields'].values())
        cases[backend]=dict(result=result,comparison=comparison)
    apple=read(S/'apple-N2R2-run1.json'); assert apple['record']['exit']==0
    cases['apple']=dict(result=apple['record'],comparison=read(S/'apple-N2R2-comparison.json'))
    assert all(cases['apple']['comparison']['fields'].values())
    retirement=read(S/'retirement-run2/stdout.log'); assert retirement['status']=='PASS'
    full=read(S/'vulkan-prefix-full-run1/comparison.json'); partial=read(S/'vulkan-prefix-staged-run2/comparison.json')
    builds={tag:dict(source=read(p)['source'],object=read(p)['object'],compile=read(p.parent/'compile.result.json'))for tag in ['vulkan-main','cuda-main','retirement','batch','mtp_session','retained_budget']for p in [S/f'compile1/{tag}/identity.json']}
    for v in builds.values():assert v['compile']['exit']==0
    documents=['docs/developer/current-work.md','docs/developer/performance/decode.md','docs/architecture/compute-design.md','tools/qwen35_text/README.md']
    current=S/'current'
    for name in [x['path']for x in frozen['files']]+documents:
        target=current/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/name).read_bytes())
    report=dict(status='PASS_LIMITED_SERIAL_CARRIER_AND_NATIVE_MULTI_SESSION',date='2026-10-22',
        change='Consumer already admits one Graph batch through native retirement and final readback. Remove global parity and duplicate per-shape Invocation slots; keep one serial slot for all backends. Four permanent probes use actual slot identity without compatibility names.',
        math_and_lifetime='Original weights, BF16/F32 policy, full state/candidate budgets, readonly leases, whole-block output rotation, capture identity invalidation, cancellation and actual native retirement unchanged.',
        source_freeze=ident(S/'consumer-single-slot/source-freeze.json'),sources=[dict(path=x['path'],before=x['before_sha256'],current=x['after_sha256'])for x in frozen['files']],
        diagnostic_observations=read(S/'review/memory-observations.json'),builds=builds,
        actual_multi_session=cases,actual_cuda_retirement=retirement,
        actual_vulkan_prefix=dict(full=full,staged_partial=partial),
        unsuccessful_setup_and_expectation_checks=[
            dict(record='retirement-run1/result.json',meaning='Root supplied AJ short prompt to an existing probe fixed to the older P15 fixture. Same source/weights; corrected only runner input to original fixture; retirement-run2 passed.'),
            dict(record='vulkan-prefix-partial-run1/result.json',meaning='Native process exited zero; host expected two hits from an old CLI window. Current all-active-wave lookup happens before any publication, so all three correctly missed. No product change; staged composition establishes the required publication-before-lookup order.'),
            dict(record='vulkan-prefix-staged-run1/result.json',meaning='Explicit --steps conflicted with existing generate 1 in warmup schedule; parser rejected before loading model. Removed explicit --steps, leaving original default4 for suffix schedules, and staged-run2 passed.')
        ],
        limitations=[
            'Selected short finite workloads only; no full quality or cross-shape bitwise equivalence acceptance.',
            'Prefix CLI does not export all old KV/recurrent/carry payload bytes; complete COW old-state and Apple/Vulkan native cancellation combinations remain.',
            'One slot removes unnecessary consumer duplication. Per-region native backend context/scratch and driver costs remain a library resource-convergence item; no context pool has been implemented.',
            'The failed Vulkan heap snapshot and requested region/logger sizes have different semantics. No exact physical memory savings are inferred from them.',
            'No new complete prefill/decode/TPS or GPU/CPU memory benchmark; current-work final table remains the pre-change four-arm window.',
            'Other selected applicable model/quantization MTP artifacts, quality, image projection and overall architecture/performance goal remain incomplete.'
        ],
        reused_caches=dict(SDK_rebuilds=0,shaders=0,NVCC=0,Windows_host_product_TUs=6,Windows_host_diagnostic_TUs=2,Apple_host_product_TUs=1),
        cleanup=read(S/'cleanup-result.json'),documents=[ident(R/x)for x in documents],archive=None)
    selected=[]
    for p in sorted(S.rglob('*')):
        if not p.is_file()or p.suffix.lower()not in ['.json','.py','.log','.inc','.diff','.ps1','.cc','.h','.md','.txt']:continue
        if '__pycache__'in p.parts:continue
        selected.append(p)
    with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in selected:z.write(p,p.relative_to(S).as_posix())
    report['archive']=ident(ARCHIVE);save(DEST,report)
    print(json.dumps(dict(evidence=ident(DEST),archive=ident(ARCHIVE),archive_entries=len(selected)),indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','publish']);a=p.parse_args()
    prepare()if a.action=='prepare'else publish()
