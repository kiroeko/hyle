"""Reuse the exact AO N2/R2 fixture and workload with the AP diagnostic image."""
from pathlib import Path
import argparse, os, sys
S=Path(__file__).resolve().parent; R=S.parents[1]
source=R/'.scratch/vulkan-retained-paged-20261022/run_sessions.py'
text=source.read_text(encoding='utf8')
# The original runner selects all fixture/model files relative to R and writes
# live/terminal records in S. Only its own folder changes here.
text=text.replace('S=Path(__file__).resolve().parent;R=S.parents[1]',
                  'S=Path('+repr(str(S))+');R=S.parents[1]')
p=argparse.ArgumentParser(description=__doc__); p.add_argument('--attempt',type=int,required=True); p.add_argument('--memory-logger',action='store_true'); args=p.parse_args()
text=text.replace("'diagnostic-link1'if args.diagnostic",repr('diagnostic-link'+str(args.attempt))+"if args.diagnostic")
if args.memory_logger: os.environ['GGML_VK_MEMORY_LOGGER']='1'
sys.argv=[str(source),'--diagnostic','--attempt',str(args.attempt)]
exec(compile(text,str(source),'exec'),{'__name__':'__main__','__file__':str(source)})
