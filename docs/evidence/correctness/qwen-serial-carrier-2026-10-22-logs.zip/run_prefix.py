"""Two bounded existing Vulkan MTP prefix CLI journeys, no TPS claim."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, time
S=Path(__file__).resolve().parent; R=S.parents[1]
p=argparse.ArgumentParser(description=__doc__); p.add_argument('case',choices=['full','partial','staged']); p.add_argument('--attempt',type=int,default=1); a=p.parse_args()
root=S/'vulkan-main-link1'; out=S/f'vulkan-prefix-{a.case}-run{a.attempt}'; out.mkdir()
fixture=R/('.scratch/qwen-mtp-batch-20261022/fixtures/prefix4.txt'if a.case=='full'else'.scratch/qwen-mtp-prefix-20261022/fixtures/partials.txt')
if a.case=='staged':fixture=S/'fixtures/staged-prefix.txt'
command=[str(root/'qwen.exe'),'--inputs',str(R/'.scratch/qwen-native-assembly-20261022/inputs/mtp'),'--mtp','on','--capacity','64','--session-schedules',str(fixture),'--max-sessions','2'if a.case=='full'else'3','--active-sequences','2'if a.case=='full'else'1','--cache-bytes',str(256*1024*1024),'--prefix-cache','auto','--progress','direct','--replay','commands']
if a.case=='partial':command+=['--steps','4']
def save(path,x):path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(path):
    raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
files={fixture}
for line in fixture.read_text().splitlines():
    if line.strip():files.add(fixture.parent/line.split()[1])
record=dict(command=command,cwd=str(R),image=ident(root/'qwen.exe'),fixtures=[ident(x)for x in sorted(files)],started=time.time(),performance_comparison=False)
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
    child=subprocess.Popen(command,cwd=R,env=dict(os.environ,PATH=json.loads((root/'runtime-environment.json').read_bytes())['PATH']),stdout=so,stderr=se)
    record.update(pid=child.pid,state='running');save(out/'command.json',record);save(S/'live.json',record);print('START prefix',a.case,'PID',child.pid,flush=True);child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);save(out/'result.json',record);save(S/'live.json',record)
if child.returncode:
    print((out/'stderr.log').read_text(errors='replace')[-6000:]);raise SystemExit(1)
d=json.loads((out/'stdout.log').read_bytes());assert d['mtp']and d['backend']=='vulkan'and d['prefix_cache']
keys=['prefix_hits','prefix_misses','prefix_full_hits','reused_tokens','prefill_target_rows','prefill_draft_rows','prefill_graph_calls']
expected=dict(zip(keys,[2,2,2,30,30,30,1]if a.case=='full'else[2,3,0,30,54,54,5]if a.case=='staged'else[2,1,0,30,24,24,3]))
for k,v in expected.items():assert d[k]==v,(k,d[k],v)
if a.case=='full':
    assert d['actual_graph_calls']==1 and d['generated_tokens']==4
    ids=[x['result']['generated_ids']for x in d['sessions']];assert len(ids)==4 and all(x==ids[0]and len(x)==1 for x in ids)
    assert all(x['result']['actual_target_rows']==0 and x['result']['actual_draft_rows']==0 for x in d['sessions'][2:])
else:
    rows=[15,15,15,1,8]if a.case=='staged'else[15,1,8]
    assert [x['result']['prefill_target_rows']for x in d['sessions']]==rows
    assert [x['result']['prefill_draft_rows']for x in d['sessions']]==rows
assert d['cache_live_requested_bytes']<=d['cache_requested_byte_limit']and d['cache_peak_requested_bytes']<=d['cache_requested_byte_limit']
assert d['peak_committed_versions']<=d['max_sessions']
report=dict(status='PASS_LIMITED_PREFIX_CLI',case=a.case,expected=expected,work={k:d[k]for k in ['actual_graph_calls','generated_tokens','prefill_target_rows','prefill_draft_rows']},sessions=[dict(id=x['session_id'],ids=x['result']['generated_ids'],prefill_target_rows=x['result']['prefill_target_rows'],prefill_draft_rows=x['result']['prefill_draft_rows'])for x in d['sessions']],cache={k:v for k,v in d.items()if k.startswith('cache_')},old_full_state_bytes_checked=False,quality_pass=False,performance_comparison=False)
save(out/'comparison.json',report);print(json.dumps(report),flush=True)
