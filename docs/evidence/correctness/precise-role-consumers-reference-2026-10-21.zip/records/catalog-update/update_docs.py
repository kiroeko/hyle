from pathlib import Path
import copy
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[4]
STAGE = Path(__file__).resolve().parent
EVIDENCE = 'docs/evidence/correctness/precise-role-consumers-reference-2026-10-21.json'
LINK = '../evidence/correctness/precise-role-consumers-reference-2026-10-21.json'
DOCS = ('docs/implementation/model-operators.md', 'docs/implementation/model-quantizations.json')


def identify(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def replace_once(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new, 1)


def set_remaining(coverage, remaining):
    coverage['artifact_unaligned_or_unverified'] = copy.deepcopy(remaining)
    coverage['missing_capabilities'] = copy.deepcopy(remaining)
    coverage['role_domains'][0]['unresolved'] = copy.deepcopy(remaining)


before = {name: (STAGE / 'before' / name).read_bytes() for name in DOCS}
for name in DOCS:
    assert (ROOT / name).read_bytes() == before[name], 'Canonical changed after snapshot: ' + name

old = json.loads(before[DOCS[1]])
data = copy.deepcopy(old)
pb = data['artifacts'][20]['provider_coverage']
pb_mapping = (
    'Confirmed mixed ModelOpt0.45.0: per-expert group16 NVFP4 plus FP8_PB_WO attention and original BF16/F32 roles. '
    'Layer0 g_proj E4M3[12288,7168], SF F32[96,1,56,1]; o_proj E4M3[7168,12288], SF F32[56,1,96,1]. '
    'The stored PB_WO name does not establish A16: the fixed vLLM reader selects dynamic group128 FP8 activation. '
    'Original F32 scale bits now import into the canonical block128 carrier after explicit singleton-axis folding; '
    'four backends execute the chosen Float8BlockLinear(kNone) software numerical/resource reference. '
    'This is neither scalar static SA/SW nor a claim of bitwise equivalence to native vLLM deployment or the distinct QTensor pre-scale BF16 reference.'
)
pb['mapping_status'] = pb_mapping
pb['role_domains'][0]['observed'] = pb_mapping
pb['role_domains'][0]['followup_evidence'] = EVIDENCE
pb['fixed_source_role_binding']['facts']['attention'] = (
    'Layer0 g_proj E4M3[12288,7168], SF F32[96,1,56,1]; o_proj E4M3[7168,12288], SF F32[56,1,96,1]. '
    'This is block128 stored PB_WO, not scalar static FP8. Activation math cannot be inferred from WO: '
    'the fixed vLLM reader selects dynamic128 A. The current chosen software reference uses original F32 SF '
    'with Float8BlockLinear(kNone); QTensor pre-SF BF16 arithmetic is a separate reference, not substituted into Float8WeightDecode.'
)
pb['fixed_source_role_binding']['facts']['unknown'] = (
    'Original tensor numeric values, all-role payload/import and full artifact execution remain unverified. '
    'The chosen dynamic128 software reference is executed, but exact native vLLM backend accumulation/output behavior '
    'and equivalence to the distinct QTensor pre-SF BF16 reference are not signed.'
)
set_remaining(pb, [
    'Generic selected-bank assembly/atomic binding has a synthetic ModelOpt NVFP4 GPU witness, not this Kimi expert import/working-set journey.',
    'Original F32 block128 scale import plus the chosen dynamic128 software reference is implemented on four backends. Exact Kimi role binding/payload, QTensor pre-SF BF16 reference and native vLLM backend bitwise equivalence remain unverified.',
    'No whole-artifact or Linux execution, quality, throughput or peak-memory acceptance.'
])
pb['reachable_entry_points'].append({
    'operation': 'import_float8_block128_weight(E4M3FN[N,K], F32[ceil(N/128),K/128], canonical) -> Float8BlockLinear{kNone, absmax_floor=1e-4}',
    'execution': 'Explicitly fold original singleton SF axes into 2D without changing bytes; cold import preserves E4 codes and each original F32 scale bit. BF16 A is dynamically quantized per128; F32 block-scaled accumulation returns BF16 under the existing operation contract.',
    'providers': ['CPU', 'CUDA', 'Vulkan', 'Apple'],
    'evidence': EVIDENCE,
    'validation': 'One stored-F32 consumer per backend, two slots/four successful submissions, original constant/result lifetimes and CUDA RequireCapture. SF deliberately is not BF16-representable and A deliberately is not E4-exact; the no-AQDQ counterfactual differs.',
    'limits': 'Synthetic bounded software reference, not original artifact payload, native vLLM scaled-GEMM bit equivalence, QTensor pre-SF BF16 equivalence, quality or throughput.'
})
pb['fusion_coverage'] = (
    'Existing bounded Float8BlockLinear(kNone) is reused after stored-F32 scale import; this package adds no new projection fusion. '
    'No exact NVFP4 artifact fusion or native vLLM PB_WO bitwise equivalence is established; GGUF MXFP4 and GroupedFloat4Linear remain different contracts.'
)
pb['precise_role_consumer_reference'] = {
    'observed_on': '2026-10-21', 'evidence': EVIDENCE,
    'scope': 'Original F32 block128 scale carrier and chosen dynamic128 software consumer are connected; the fixed producer/reference/deployment distinctions are retained in the evidence.',
    'artifact_execution_verified': False
}
for code in ('include/hyle/compute/weight_import.h', 'src/compute/weight_import.cc',
             'tests/compute_models/e8m0_weight_import_fixture.h'):
    if code not in pb['code']:
        pb['code'].append(code)

composition = (
    'Separate affine4/5/6/8 packed dot primitives exist. Generic ordinary mixed-width MoE composition is verified '
    'on CPU/CUDA/Vulkan and now Apple: gate5/up6/down4 g32, F32 A and BF16 metadata, final-output-only '
    'TopK/normalization/SiLU/combine with independent slots. This is not an exact GLM layer or its routing/shared-expert/mHC implementation. '
    'Physical gate/up GLU fusion remains optional; GGUF MMVQ is a separate codec/provider.'
)
for index in (31, 32):
    coverage = data['artifacts'][index]['provider_coverage']
    coverage['fusion_coverage'] = composition
    coverage['composition_followup_evidence'] = EVIDENCE
    coverage['primitive_validation']['scope'] = (
        'Historical directed synthetic primitive tests below retain their original per-provider scope; '
        'the later generic Apple MoE composition is recorded separately. Neither executes this catalog artifact.'
    )
    coverage['precise_role_consumer_reference'] = {
        'observed_on': '2026-10-21', 'evidence': EVIDENCE,
        'Apple_generic_MoE': 'One ordinary full composition using the existing gate5/up6/down4 g32 fixture, F32 A/BF16 metadata, E3/E17, two slots/two updates and retained final results; no new leaf or executor.',
        'artifact_execution_verified': False
    }

head = data['artifacts'][31]['provider_coverage']
head['mapping_status'] = (
    'Stored affine4 g64 U32/BF16 triples fit the existing codec and scale-type domains. '
    'The 156 attention head-bank triples are 78 embed_q plus 78 unembed_out with 64 heads, not MoE experts. '
    'L1 transposed-W projections can use existing grouped primitives with explicit q_nope slice Copy/head ordering; '
    'the actual L>1 embed_q(...,transpose=False) prefill branch exposes an unimplemented non-transposed packed-W interface.'
)
head['role_domains'][0]['observed'] = head['mapping_status']
head['role_domains'][0]['followup_evidence'] = EVIDENCE
set_remaining(head, [
    'Implement the generic non-transposed packed-W projection required by embed_q(...,transpose=False) prefill; current MlxQuantized linear/grouped formulas only provide transposed-W dot. This specific capability gap is not repaired by the generic MoE run.',
    'The 156 head-bank triples have fixed forward geometry, but their exact L1 consumer/import remains unexecuted: preserve 64-head order, BF16 metadata and the q_nope K192 slice from a256-wide backing with an explicit small activation Copy.',
    'Same-low-type native MLX QMM tile arithmetic is not signed as equivalent to Hyle F32 affine decode/dot. Generic F32-A/BF16-metadata MoE does not qualify this BF16/BF16 head role.',
    'No artifact payload or whole-model execution, Linux closure, quality or throughput acceptance.'
])
head['precise_role_consumer_reference']['head_bank_source_review'] = (
    'Fixed mlx-lm 72be8c955d9a0d3099bd01865af288e0e947c3fa maps glm_moe_dsa through deepseek_v32 and QuantizedMultiLinear. '
    'embed_q W[64,512,192], unembed_out W[64,256,512]; L1 uses transpose=True, '
    'L>1 embed_q uses transpose=False. Source review only, no head-role execution or original exporter-version identity claim.'
)

flash = data['artifacts'][32]['provider_coverage']
flash['mapping_status'] = (
    'Stored affine4/5/6 g64 U32/F16 scale/bias triples fit existing descriptor domains. '
    'The pinned default MLX-VLM reader preserves loaded F16 metadata; ordinary BF16 activation plus F16 metadata '
    'promotes to F32 affine QMM/gather_qmm, consistent with Hyle mixed-type output inference. '
    'This source-level mapping and the generic Apple F32-A/BF16-metadata MoE run do not execute the artifact-specific GLM layer.'
)
flash['role_domains'][0]['observed'] = flash['mapping_status']
flash['role_domains'][0]['followup_evidence'] = EVIDENCE
set_remaining(flash, [
    'Generic slice assembly/atomic bank binding and Apple complete generic mixed-bit MoE are implemented. The actual 37152-triple/129-bank MLX import/working-set journey remains unexecuted; independently padded layouts still require explicit packing.',
    'Pinned default MLX-VLM load/promotion is source-qualified, but exact original exporter identity, actual GLM bit4/5/6 g64/F16-metadata consumers and full routing/shared-expert/mHC behavior are not executed by the generic g32/F32-A/BF16-metadata fixture.',
    'Same-low-type native QMM equivalence, explicit set_dtype/converted-artifact overrides and special short-block producer paths are outside this reference; no artifact payload or whole-model execution, Linux closure, quality or throughput acceptance.'
])
flash['precise_role_consumer_reference']['default_reader_promotion'] = (
    'mlx-vlm f1a9b7bac6f2b95f588ffc9343495a3c61c6e328 default load/sanitize/load_weights retains original F16 metadata. '
    'MLX core 1f8e74e3f12f31365464a6867c6579f0e9b29d85 promotes BF16+F16 to F32; '
    'the ordinary switch layer passes A/SF/bias without an unconditional pre-cast. '
    'Explicit conversion/set_dtype and special optimized branches are separate, and the original exporter commit is not pinned by the artifact.'
)

data['followup_reviews'].append({
    'observed_on': '2026-10-21', 'evidence': EVIDENCE, 'artifact_indices': [20, 31, 32],
    'scope': 'Stored-F32 block128 scale import and chosen dynamic128 Float8BlockLinear(kNone) reference are connected on four backends; Apple completes the existing generic mixed5/6/4 MoE fixture. Fixed PB_WO reader and MLX default-load/head-forward research distinguish these references from exact artifact execution. Catalog31 non-transposed packed-W prefill remains an explicit interface gap.',
    'distinct_cases': 14, 'new_cases': 6, 'neighbor_cases': 8,
    'backend_cases': {'CPU': 7, 'CUDA': 2, 'Vulkan': 2, 'Apple': 3},
    'execution_limits': 'Six new cases are one host F32 importer, four stored-F32 dynamic128 consumers and one Apple generic MoE; neighbors are four original U8 Graph consumers and four host importer cases. No whole-artifact execution, upstream native bitwise equivalence, Linux, quality, throughput or peak-memory claim.'
})

text = before[DOCS[0]].decode('utf-8').replace('\r\n', '\n')
text = replace_once(text,
    '嵌套旧MXFP4配置不能覆盖物理dtype。ModelOpt Kimi注意力存F32四维block128 scale，不能套标量静态SA/SW；',
    '嵌套旧MXFP4配置不能覆盖物理dtype。ModelOpt Kimi注意力存F32四维block128 scale，不能套标量静态SA/SW；\n'
    '[固定PB_WO部署reader与参考](%s)另确认动态A128，不能从WO名称推出A16。原F32 scale冷导入与所选动态参考已四端执行，\n'
    'QTensor先将scale转BF16的参考与原生vLLM后端逐位等价仍分开核定；' % LINK)
old_row = next(line for line in text.splitlines() if line.startswith('| E8M0 macroblock128权重冷导入；'))
new_row = old_row + '\n' + (
    '| stored-F32 macroblock128导入；ModelOpt Kimi PB_WO所选动态A128参考 | '
    '`import_float8_block128_weight`现也接原F32 scale表；四维singleton轴须显式折为二维，E4码与SF各bit原样保留。'
    '复用`Float8BlockLinear(kNone,1e-4F)`，BF16 A刻意不落E4，反无AQDQ见证可区分；四端各双槽4次提交，CUDA实际capture。'
    '[本批14项](%s)含6项新增与8项邻居、无跳过，另补Apple通用MoE | '
    '这里只签所选动态128软件数值／资源参考；PB_WO名字不等于A16。QTensor先转BF16 scale的参考、原生vLLM累加／输出逐位、'
    '精确角色／payload／整模型、Linux、质量或吞吐未签；不展开NK浮点bank，也不改旧Float8WeightDecode数学 |' % LINK)
text = replace_once(text, old_row, new_row)
old_mlx = next(line for line in text.splitlines() if line.startswith('| MLX混合位宽；'))
new_mlx = (
    '| MLX混合位宽；Qwen、GLM等 | `MlxQuantized{format,kind,bits,group_size}`已接affine4/5/6/8，连续U32行末轴`(K/32)*bits`。'
    'Grouped支持`A[T,1,K]`、`A[T,S,K]`及真实零slot步幅／token行距View，IDs决定`[T,S,N]`并保重复槽，'
    '[四后端共享输入回归](../evidence/correctness/mlx-grouped-shared-activation-2026-10-20.json)通过。'
    'Vulkan mixed affine直接读原类型；CPU/CUDA/Vulkan的[完整普通MoE](../evidence/correctness/mlx-moe-typed-inputs-2026-10-20.json)'
    '与[本批Apple旅程](%s)覆盖泛用5/6/4bit、g32、F32 A／BF16 metadata，未冒充GLM整层。'
    '六制品164个header已核，GLM Flash全部37338份scale/bias为F16；固定默认MLX-VLM加载保原F16，BF16 A＋F16 metadata按原MLX提升F32 | '
    '37152专家碎片到129组MLX working-set实际旅程未验。GLM31的156个head-bank是64头投影：L1可用原grouped＋小A Copy，实际consumer未跑；'
    'prefill `embed_q(...,transpose=False)`所需非转置packed-W接口尚缺。原低类型QMM逐位、特殊short-block分支及嵌套lazy View未签；'
    'Vulkan合资格bank已[跨槽复用](../evidence/correctness/vulkan-mlx-constant-bank-reuse-2026-10-20.json)。'
    '不签实际GLM routing／shared expert／mHC、payload／整制品、质量、吞吐或峰值；MXFP8不能替代integer affine8 |' % LINK)
text = replace_once(text, old_mlx, new_mlx)

after = {
    DOCS[0]: text.replace('\n', '\r\n').encode('utf-8'),
    DOCS[1]: (json.dumps(data, ensure_ascii=False, indent=2) + '\n').replace('\n', '\r\n').encode('utf-8')
}
changes = [i for i, (a, b) in enumerate(zip(old['artifacts'], data['artifacts'])) if a != b]
assert changes == [20, 31, 32], changes
for i in changes:
    a = copy.deepcopy(old['artifacts'][i]); b = copy.deepcopy(data['artifacts'][i])
    a.pop('provider_coverage'); b.pop('provider_coverage'); assert a == b
    assert old['artifacts'][i]['provider_coverage']['metadata_sources'] == data['artifacts'][i]['provider_coverage']['metadata_sources']
for key in old:
    if key not in ('artifacts', 'followup_reviews'):
        assert old[key] == data[key]
assert data['followup_reviews'][:-1] == old['followup_reviews']
assert len(data['artifacts']) == 33
assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in data['artifacts'])

diff = []
for name in DOCS:
    (ROOT / name).write_bytes(after[name])
    target = STAGE / 'after' / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(after[name])
    diff.extend(difflib.unified_diff(before[name].decode('utf-8').splitlines(True),
                                   after[name].decode('utf-8').splitlines(True),
                                   fromfile='before/' + name, tofile='after/' + name))
(STAGE / 'implementation.diff').write_text(''.join(diff), encoding='utf-8', newline='')
validation = {
    'status': 'applied_documentation_only', 'changed_artifact_indices': changes,
    'changed_artifact_fields': 'provider_coverage only', 'metadata_sources_unchanged': True,
    'other_artifact_fields_unchanged': True, 'all33_artifact_execution_verified_false': True,
    'prior_followup_reviews_unchanged': True, 'followup_review_count': len(data['followup_reviews']),
    'CRLF_preserved': all(b.count(b'\n') == b.count(b'\r\n') for b in after.values()),
    'evidence': EVIDENCE, 'evidence_exists_at_update': (ROOT / EVIDENCE).exists(),
    'build_or_test_run': False, 'product_or_tests_changed_by_script': False,
    'sources': [identify(ROOT / name) for name in DOCS]
}
(STAGE / 'validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(STAGE / 'source-freeze.json').write_text(json.dumps(validation['sources'], ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(validation, ensure_ascii=False, indent=2))
