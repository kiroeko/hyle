"""Record the bounded PB_WO contract/design review without product mutation."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent
A=S.parents[1]
ROOT=A.parents[1]
M=S/'primary/ec87a82927d003986d44fb7f4fa8b3d10c31b095'
K=A/'fixed-role-binding-2026-10-21/kimi/20'

def identity(path):
 path=Path(path);data=path.read_bytes()
 return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def anchor(path,needle):
 lines=Path(path).read_text(encoding='utf-8').splitlines()
 hits=[i+1 for i,line in enumerate(lines) if needle in line]
 assert hits,(str(path),needle)
 return dict(source=identity(path),needle=needle,lines=hits)

header=json.loads((K/'headers/model-00001-of-000096.safetensors/header.json').read_text())
prefix='language_model.model.layers.0.self_attn.'
roles=[]
for role in ['b_proj','f_a_proj','f_b_proj','g_proj','k_proj','o_proj','q_proj','v_proj']:
 w=header[prefix+role+'.weight'];sf=header[prefix+role+'.weight_scale']
 roles.append(dict(role=prefix+role,weight=w,scale=sf,
    scales_2D=[sf['shape'][0],sf['shape'][2]],
    complete_N128=w['shape'][0]%128==0,complete_K128=w['shape'][1]%128==0))
config=json.loads((K/'config.json').read_text())
hf=json.loads((K/'hf_quant_config.json').read_text())
producer_anchors=[
 anchor(M/'modelopt/torch/quantization/qtensor/fp8_tensor.py','def dequantize'),
 anchor(M/'modelopt/torch/quantization/qtensor/fp8_tensor.py','return (quantized_data.to(dtype) * scales.to(dtype))'),
 anchor(M/'modelopt/torch/quantization/qtensor/fp8_tensor.py','original_input.dtype'),
 anchor(M/'modelopt/torch/quantization/nn/modules/tensor_quantizer.py','return qtensor.dequantize(**kwarg)'),
 anchor(M/'modelopt/torch/quantization/nn/modules/tensor_quantizer.py','if self.fake_quant:'),
 anchor(M/'modelopt/torch/quantization/nn/modules/quant_linear.py','self.input_quantizer(input)'),
 anchor(M/'modelopt/torch/export/quant_utils.py','return QUANTIZATION_FP8_PB_WO'),
 anchor(M/'modelopt/torch/export/quant_utils.py','if quantization == QUANTIZATION_FP8_PB_WO:')]
runtime=S/'runtime/vllm-modelopt.py'
runtime_anchors=[anchor(runtime,needle) for needle in ['class KFp8Block128','s = s.squeeze(1).squeeze(-1)',
 'if algo == "FP8_PB_WO":','QuantSpec(weight=kFp8Static128BlockSym, activation=kFp8Dynamic128Sym)',
 'def select_linear_kernel','model_config.dtype','out_dtype=rt.out_dtype']]
current_anchors=[
 anchor(ROOT/'include/hyle/compute/model_ops.h','struct Float8WeightDecode'),
 anchor(ROOT/'src/compute_provider_native/torch_cpu_program.cc','} else if constexpr (Selected == Kind::kDecode)'),
 anchor(ROOT/'src/compute_route_apple/apple_mature_float.cc','if (operation.custom_as<model_ops::Float8WeightDecode>())'),
 anchor(ROOT/'include/hyle/compute/weight_import.h','F32 scale bits are copied unchanged'),
 anchor(ROOT/'src/compute/weight_import.cc','if (stored_f32) {')]
doc=dict(
 status='Bounded contract/design research complete; no new missing arithmetic operation established. A pre-SF BF16 software reference differs from current F32-carrier decode and from fixed vLLM deployment.',
 scope='Only fixed artifact20 Kimi ModelOpt FP8_PB_WO attention roles. No model payload, build, GPU, product/docs/catalog mutation or whole-artifact claim.',
 artifact=dict(index=20,repository='nvidia/Kimi-K3-NVFP4',revision='b2428a0b83a8b712ff2e1a8448a103d4175341f1',
    producer=hf['producer'],top_level_dtype=config.get('dtype'),text_dtype=config.get('text_config',{}).get('dtype'),
    metadata=[identity(K/'config.json'),identity(K/'hf_quant_config.json'),identity(K/'headers/model-00001-of-000096.safetensors/header.json')],
    group1=dict(quant_algo=config['quantization_config']['config_groups']['group_1']['quant_algo'],
      alias_target_count=len(config['quantization_config']['config_groups']['group_1']['targets']),
      input_activations_field_present='input_activations'in config['quantization_config']['config_groups']['group_1']),
    roles=roles,tensor_payload_bytes_read=0,
    note='The tag and 4D scale metadata describe stored weights; they do not fix every deployment activation quantizer or native GEMM accumulation policy.'),
 pinned_sources=dict(modelopt_release='0.45.0',modelopt_commit='ec87a82927d003986d44fb7f4fa8b3d10c31b095',
    modelopt_identity=identity(S/'primary-source-identities.json'),vllm_commit='7b569ec8953cf8099638a6d2ee1e915b75867c3a',
    runtime_identity=identity(S/'reader-source-identities.json'),
    producer_anchors=producer_anchors,runtime_anchors=runtime_anchors,
    bounded_source_requests='Five official ModelOpt files202679B plus fixed vLLM dispatch106968B, all capped262144B per file. Two guessed preset paths404 (web first path, saved second receipt) are retained as lookup failures, not proof that a preset is absent. No source checkout or large dependency download.'),
 exact_distinctions=dict(
    stored_layout='W E4M3FN[N,K] row-major. F32SF[ceil(N/128),1,K/128,1] has N-block major then K-block physical order. Explicit singleton removal to2D is metadata-only and lossless; do not transpose the grid or treat it as scalar static SA/SW.',
    qtensor_reference='FP8QTensor.dequantize repeats scales along each128 block axis, casts both code and expanded SF to requested dtype, then multiplies in that dtype and crops any padded tail. For dtype BF16, Wref=BF16(BF16(E4code)*BF16(originalF32SF)). E4 finite codes widen exactly, but original SF generally does not.',
    qtensor_dtype_source='No dtype argument uses QTensor metadata original dtype; quantize constructs that metadata from original_input.dtype. TensorQuantizer.dequantize forwards scale/block_sizes without overriding dtype. Artifact model config declares BF16, supporting an explicit BF16 reference choice; serialized codes/SF alone do not prove original local wheel or every forward dtype.',
    fake_QDQ='The exporter distinguishes fake block quantizer FP8_PB_WO from real FP8_PB_REAL. The former follows scaled_e4m3 fake quantization before export; quant_utils serializes PB_WO via FP8QTensor.quantize. Consequently the QTensor stored-weight reconstruction is a precise selectable reference, not proof of bit equality to original unavailable fake-QDQ/calibration or a universal PB_WO execution policy.',
    vllm='The fixed reader keeps W row-major, squeezes SF singleton axes to contiguous2D, and resolve(PB_WO) selects static128 weight plus dynamic128 activation keys. It deliberately executes a W8A8 block-scaled policy. input_dtype/output_dtype come from model_config.dtype (BF16 by the inspected default config, CLI override possible). Native kernel details choose scale packing/reduction separately.',
    sglang='Already cached fixed82f1d216... modelopt_quant.py similarly maps PB_WO to Fp8LinearMethod with dynamic activation_scheme and128x128 weight block. This confirms that the storage name cannot require all deployment readers to keep A unquantized.',
    output='Chosen unquantized-A reference: original BF16 A, BF16 reconstructed W, F32 accumulation and BF16 MatMul output. F32 reduction trees may differ across providers; finite sparse-A witnesses isolate pointwise boundaries. This is not signed as vLLM native FP8 dot or original model quality.'),
 minimal_reference_graph=dict(
    inputs=['A BF16[M,K]','W plain E4M3FN[N,K]','SF F32[NB,1,KB,1], NB=N/128,KB=K/128 for the first complete-block domain'],
    nodes=['Cast W toBF16[N,K]', 'View reshape to[NB,128,KB,128]',
      'Cast original SF toBF16[NB,1,KB,1]', 'Binary Multiply inBF16 with ordinary broadcast',
      'View reshape decoded W to[N,K]', 'Exact transpose View to[K,N]',
      'MatMul(A,BF16Wt,accumulation_type=F32) ->BF16[M,N]'],
    bounded_geometry=dict(M=2,N=256,K=384,SF=[2,1,3,1],reason='Non-square multiple N/K blocks distinguish both scale axes and transpose; no role-sized payload required to prove the composition.'),
    role_geometries=[dict(role='g/q/k/v_proj',N=12288,K=7168,SF=[96,1,56,1]),dict(role='o_proj',N=7168,K=12288,SF=[56,1,96,1])],
    ordinary_policy='No activation QDQ, no input_scale, no Float8BlockLinear, no encoded-A MatMul and no rewrite of old Float8WeightDecode semantics. Only publish required final Y; publish a decoded probe separately to verify the SF boundary and keep any probe escape exact.',
    tail_limit='The actual b_proj N96 is a partial N block; the simple four-axis W reshape is not valid for it. Existing ordinary pad/slice or explicitly repeated/sliced SF can represent the tail. It must be qualified separately rather than silently padding all complete-block tests or signing it from g/o results.'),
 cold_resources=dict(
    raw_graph='Original W and 4D SF are independent ready/immutable graph inputs or constants. New WeightSlots/atomic WeightBinding can retain both from one upload generation without type conversion. No canonical carrier is needed for the ordinary separate-input graph.',
    carrier='If an existing encoded consumer is chosen, float8_weight_description(K,N,F32Block128) is a distinct opaque carrier: unchanged row-major NK code bytes followed by2D nativeF32 SF. It must be assembled by an actual importer, not by changing the dtype/format tag of W alone.',
    current_import='Root current-source import_float8_block128_weight now accepts2D rawF32 SF and copies every32-bit scale payload unchanged, while retaining old U8E8 conversion. The caller explicitly collapses4D singleton axes. This is a natural cold resource extension, not PB_WO numerical qualification; it was not built/run by this reviewer.',
    decoder_mismatch='Current CPU and Apple Float8WeightDecode multiply F32-decoded code by original F32SF and only then cast BF16. The old operation should not be changed to pre-SF BF16, because its declared canonical F32-scale contract and existing consumers differ.',
    alternative='Explicitly Cast SF toBF16 then widen backF32 before constructing an encoded carrier can express the chosen pre-SF boundary through old decode, but this is an explicit numerical preprocessing step, not the raw-bit-preserving importer. The ordinary graph keeps this boundary more directly visible.'),
 space=dict(
    code_bytes_per_g_or_o=12288*7168,scale_bytes_per_g_or_o=96*56*4,
    minimum_explicit_BF16_decoded_bytes_per_g_or_o=2*12288*7168,
    minimum_explicit_F32_decoded_bytes_per_g_or_o=4*12288*7168,
    interpretation='A BF16 dense decoded matrix is168MiB per g/o role in addition to84MiB codes and21KiB F32SF. Ordinary W Cast/Multiply or Float8WeightDecode materializes an NK decoded value; provider-private temporaries and lifetime reuse may add or overlap storage. These are logical byte counts, not measured peak allocation/DRAM or a proven throughput loss.',
    distinction='If decode runs once cold and the consumer accepts resident BF16 W, this is a complete executable policy at higher resident memory. If compressed residency or repeated replay without NK expansion is required, a bounded closed decoder-to-MatMul candidate is a real remaining space optimization, not a missing scalar/MatMul primitive.',
    possible_lowering='Recognize only the exact closed BF16 code/SF Cast-Mul-reshape/transpose-MatMul recipe, preserve SF pre-round and output boundaries, read packed/code tiles and SF grid directly, and reuse the existing prepared/mapped pattern framework. Escaping decoded values retain ordinary decomposition. No new public operator or executor is justified by the4D header alone.'),
 witnesses=identity(S/'scalar-witness.json'),
 recommended_next=['Run one exact ordinary separate-input BF16 reference with the non-BF16 SF witness, both N/K scale axes and immutable W/SF ownership/two slots.',
   'Retain current raw-F32 importer unit tests as a resource contract independent of the BF16 pre-SF equation; do not route its unchanged canonical decode as if it already signed the latter.',
   'Inspect the actual cold plan logical workspace/private-known budget before implementing a bounded contraction. Do not make the unquantized-A reference a claim about fixed vLLM dynamic-A deployment or whole Kimi execution.'],
 actual_product_gap=dict(arithmetic='No newly missing public arithmetic operation proved. The ordinary chosen reference composes existing leaves.',
    resource='Initial rawF32 canonical importer gap is addressed by root current-source extension; execution qualification belongs to the root batch.',
    bounded_space='No dedicated closed weight-only FP8 pre-SF BF16 decoder+MatMul candidate is established by this review. NK decoded materialization remains visible and may warrant one after the ordinary path is qualified.'),
 current_source_anchors=current_anchors,
 nonclaims=['No original numeric weight/scale payload, full header census, publisher local patches, whole model, native FP8 hardware equivalence, quality or throughput.',
   'No GPU or build performed by this reviewer. The two scalar witnesses use Python struct/manual RNE and an independent E4 formula, not Torch or Hyle codecs.',
   'No product, tests, schema, catalog or current docs edited by this task.'])
(S/'design-review.json').write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(S/'source-inventory.json').write_text(json.dumps(dict(primary=identity(S/'primary-source-identities.json'),runtime=identity(S/'reader-source-identities.json'),current_sources=[x['source']for x in current_anchors]),indent=2)+'\n')
print(json.dumps(identity(S/'design-review.json')))
