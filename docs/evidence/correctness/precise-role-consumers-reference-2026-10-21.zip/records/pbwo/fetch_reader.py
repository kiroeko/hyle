"""Fetch only fixed vLLM dispatch and one fixed ModelOpt preset if present."""
from pathlib import Path
import hashlib,json,time,urllib.request,urllib.error
S=Path(__file__).resolve().parent
requests=[
 ('https://raw.githubusercontent.com/vllm-project/vllm/7b569ec8953cf8099638a6d2ee1e915b75867c3a/vllm/model_executor/layers/quantization/modelopt.py','runtime/vllm-modelopt.py'),
 ('https://raw.githubusercontent.com/NVIDIA/Model-Optimizer/ec87a82927d003986d44fb7f4fa8b3d10c31b095/modelopt/configs/ptq/presets/model/fp8_2d_blockwise_weight_only.yaml','primary/fp8_2d_blockwise_weight_only.yaml')]
if __name__=='__main__':
 rows=[]
 for url,name in requests:
  path=S/name;path.parent.mkdir(parents=True,exist_ok=True);cap=262144
  row=dict(url=url,path=str(path),cap=cap,tensor_payload_bytes=0)
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'hyle-bounded-pbwo-review'}),timeout=30)as response:
    row.update(status=response.status,headers=dict(response.headers));length=response.headers.get('Content-Length')
    if length:assert int(length)<=cap
    data=response.read(cap+1);assert len(data)<=cap
    path.write_bytes(data);row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  except urllib.error.HTTPError as error:row.update(status=error.code,error=str(error))
  path.with_suffix(path.suffix+'.http.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
 (S/'reader-source-identities.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{'path':x['path'],'status':x['status'],'bytes':x.get('bytes')}for x in rows]))
