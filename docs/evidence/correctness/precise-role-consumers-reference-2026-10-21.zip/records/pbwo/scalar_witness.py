"""Independent scalar storage witnesses: no Torch, product codec, or GPU."""
from pathlib import Path
import json,struct,math
S=Path(__file__).resolve().parent
def bits(value):return struct.unpack('<I',struct.pack('<f',value))[0]
def f32(value):return struct.unpack('<f',struct.pack('<f',value))[0]
def value(word):return struct.unpack('<f',struct.pack('<I',word))[0]
def bf16_word(x):
 word=bits(x)
 if word&0x7f800000==0x7f800000:
  return (word>>16)|0x40 if word&0x7fffff else word>>16
 return ((word+0x7fff+((word>>16)&1))>>16)&0xffff
def bf16(x):return value(bf16_word(x)<<16)
def e4(code):
 sign=-1. if code&128 else 1.
 exponent=(code>>3)&15;mantissa=code&7
 if exponent==15 and mantissa==7:return math.nan
 if exponent==0:return sign*math.ldexp(mantissa,-9)
 return sign*math.ldexp(8+mantissa,exponent-10)
if __name__=='__main__':
 rows=[]
 for label,scale in [('direct non-BF16 SF',value(0x3f808001)),('F32(450/448), BF16-representable block amax',f32(450./448.))]:
  code=e4(0x3c)
  before=bf16(f32(bf16(code)*bf16(scale)))
  after=bf16(f32(code*scale))
  assert before!=after and bf16(scale)!=scale
  rows.append(dict(label=label,code_byte='0x3c',code_value=code,scale=scale,
      scale_F32_bits=hex(bits(scale)),scale_BF16_bits=hex(bf16_word(scale)),
      producer_qtensor_preSF_weight_BF16_bits=hex(bf16_word(before)),
      canonical_F32_product_then_BF16_bits=hex(bf16_word(after)),
      sparse_A='A has exactly one BF16 1, all other K entries+0; these finite positive weights avoid reduction-tree ambiguity.',
      expected_reference_Y_BF16_bits=hex(bf16_word(before))))
 output=dict(status='independent scalar storage witnesses completed',cases=rows,
   scope='Pre-SF BF16 rounding differs from F32 multiplication followed by BF16. These are selected synthetic inputs, not artifact numeric payload values or model quality.')
 (S/'scalar-witness.json').write_text(json.dumps(output,indent=2)+'\n')
 print(json.dumps(output,indent=2))
