"""Bounded official ModelOpt0.45 source snapshots; no model tensor payload."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import time
import urllib.request
S=Path(__file__).resolve().parent
COMMIT='ec87a82927d003986d44fb7f4fa8b3d10c31b095'
FILES=['modelopt/torch/quantization/qtensor/fp8_tensor.py',
       'modelopt/torch/quantization/config.py',
       'modelopt/torch/export/quant_utils.py',
       'modelopt/torch/quantization/nn/modules/quant_linear.py',
       'modelopt/torch/quantization/nn/modules/tensor_quantizer.py']
def fetch(name):
    path=S/'primary'/COMMIT/name
    path.parent.mkdir(parents=True,exist_ok=True)
    url='https://raw.githubusercontent.com/NVIDIA/Model-Optimizer/'+COMMIT+'/'+name
    cap=262144
    started=time.time()
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'hyle-bounded-source-contract-review'}),timeout=30) as r:
        length=r.headers.get('Content-Length')
        if length is not None: assert int(length)<=cap,(name,length)
        body=r.read(cap+1)
        assert len(body)<=cap
        row=dict(url=url,status=r.status,headers=dict(r.headers),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),
            maximum_bytes_read=cap,model_payload_bytes=0,seconds=time.time()-started,path=str(path))
    path.write_bytes(body)
    path.with_suffix(path.suffix+'.http.json').write_text(json.dumps(row,indent=2)+'\n')
    return row
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: rows=list(pool.map(fetch,FILES))
    (S/'primary-source-identities.json').write_text(json.dumps(dict(
        producer='NVIDIA ModelOpt0.45.0',tag_commit=COMMIT,
        resolved_by='git ls-remote https://github.com/NVIDIA/Model-Optimizer.git refs/tags/0.45.0 refs/tags/0.45.0^{} (one lightweight tag ec87a829...)',
        sources=rows),indent=2)+'\n')
    print('FIXED_PRIMARY',len(rows),sum(r['bytes']for r in rows))
