from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[1];A=P.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
path=P/'root/common-plan.json';plan=read(path)
assert len(plan['owners'])==2
for arm,attempt in [('cpu','attempt1'),('cuda','attempt1'),('vulkan','attempt2')]:
 recipe=A/f'e8m0-block128-import-reference/{arm}/checks/{attempt}/test-identity.json';d=read(recipe)
 command=d.get('command',read(recipe.with_name('compile-plan.json'))['command'])
 source=next(x for x in command if x.replace('\\','/').endswith('/e8m0_weight_import_test.cc'))
 plan['owners'].append(dict(old_object=d['object'],source=ident(Path(source)),recipe=ident(recipe),command=command,arms=[arm]))
path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(dict(targeted_sources=len(plan['owners'])))
