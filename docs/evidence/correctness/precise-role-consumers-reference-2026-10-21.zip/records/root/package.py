from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(row):
 p=resolve(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cases=[];receipts=[]
def collect(arm,path):
 for x in ET.parse(path).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name')
  cases.append(dict(backend=arm,name=name,new='StoredFloat32' in name or name.startswith('AppleMlxMoeGraph.'),
      properties={p.get('name'):p.get('value') for p in x.findall('./properties/property')}))
for arm in ('cpu','cuda','vulkan'):
 p=P/arm/'validation/final1/receipt.json';d=read(p)
 assert d['passed'] and not d['failed'] and not d['skipped']
 for key in ('image','xml','link_plan'):check(d[key])
 for row in read(resolve(d['link_plan']['path']))['inputs']:check(row)
 collect(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
ap=P/'apple/final-validation.json';ad=read(ap);assert ad['tests']==3 and ad['failed']==ad['skipped']==0
check(ad['gtest']);collect('apple',resolve(ad['gtest']['path']))
assert len(cases)==14 and sum(x['new'] for x in cases)==6
new_import_submissions=sum(int(x['properties'].get('successful_submissions','0')) for x in cases if x['new'])
apple_import_submissions=sum(int(x['properties'].get('successful_submissions','0')) for x in cases if x['backend']=='apple')
moe_submissions=ad['successful_submissions']-apple_import_submissions
neighbor_submissions=sum(int(x['properties'].get('successful_submissions','0')) for x in cases if not x['new'])
assert (new_import_submissions,moe_submissions,neighbor_submissions)==(16,8,16)
objects=[]
for attempt in ('import1','wrappers2'):
 for row in read(P/f'common/checks/{attempt}/summary.json')['identities']:
  path=resolve(row['path']);d=read(path);check(d['source']);check(d['object'])
  objects.append(dict(identity=ident(path),source=d['source'],object=d['object']))
assert len(objects)==5
sources=['include/hyle/compute/weight_import.h','include/hyle/compute/model_ops.h','src/compute/weight_import.cc',
 'src/compute_ops/weight_decode.cc','src/compute_route_apple/apple_tensor.cc','src/compute_route_apple/apple_mature_float.cc',
 'tests/compute/weight_import_test.cc','tests/compute_models/e8m0_weight_import_fixture.h',
 'tests/compute_models/nvfp4_reference_fixture.h','tests/compute_models/mlx_moe_fixture.h','tests/compute_models/mlx_affine_bitstream.h',
 'tests/graph_route_apple/mlx_moe_test.cc','tests/graph_route_apple/CMakeLists.txt',
 'docs/user/compute.md','docs/developer/current-work.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
sources += [f'tests/graph_route_{a}/e8m0_weight_import_test.cc' for a in ('cpu','cuda','vulkan','apple')]
assert 'mlx_moe_test.cc' in (R/'tests/graph_route_apple/CMakeLists.txt').read_text()
catalog=read(R/'docs/implementation/model-quantizations.json')
assert len(catalog['artifacts'])==33 and all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c','.md','.cu','.d','.metal','.comp','.mm','.ps1'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
archive=R/'docs/evidence/correctness/precise-role-consumers-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='raw_F32_scale_import_four_backend_consumer_and_Apple_generic_MoE_passed',
 implementation='Original import_float8_block128_weight accepts raw2D F32 scales in addition to unsigned E8M0 U8. Original E4 codes and F32 scale bits are copied unchanged with uint32 memcpy, not requantized or rounded to BF16. Same existing canonical F32block128 carrier, original host geometry/alias/map/flush/unmap contract. No new descriptor, executor, model policy or decoded NK bank.',
 regression=dict(total=14,new=6,neighbors=8,failed=0,skipped=0,windows=receipts,apple=ident(ap),cases=cases,
  new_Graph_successful_submissions=new_import_submissions+moe_submissions,neighbor_Graph_successful_submissions=neighbor_submissions,
  count='1 new host import test,4 new original dynamic-FP8 Graph consumers,1 new Apple generic MoE;4 old U8 importer Graph neighbors plus4 old host import neighbors.',
  import_host='N129/K384 partial N macroblock, noncontiguous F32 scale source with canaries, raw non-BF16 scale/signedzero/tiny/sNaN/negative/Inf bits. Four singleton axes rejected without mutation; explicit metadata-only flatten succeeds. Existing U8 all256scale codes, aliases, mapping/flush/close failures remain passing.',
  import_graph='N129/K256 source E4 bytes plus raw F32 grid{1.0039,.7,.3333,1.997}, import once. BF16 A has non-E4 values and group maximum448*2^q. Original Float8BlockLinear kNone dynamic128 quantization, F32 coded dot then A-scale/W-scale order and BF16 output. Independent exhaustive E4 RNE oracle; no-AQDQ counterfactual differs. Existing E8 mode stays power2 with original data/math.',
  lifetime='Each four-backend new import case runs2 slots and2 content generations, retains old outputs across opposite slot updates and invocation/compiled release. CUDA both old and new cases require/assert actual capture.',
  Apple_MoE='Original generic TopK/softmax/gate5/up6/SiLU/multiply/down4/route-sum graph, BF16 metadata/F32 activations, E3 andE17,2slots*2updates each=8successful submits. Existing scalar oracle/tolerances retained. No exact GLM routing/shared/mHC or native low-dtype bit equality claimed.'),
 source_contracts=dict(PB_WO=ident(P/'pbwo/design-review.json'),MLX_loader=ident(P/'apple/producer-contract-review.json'),MLX_head=ident(P/'mlx-head-review.json'),
  findings=['Fixed ModelOpt0.45 FP8QTensor.dequantize(dtype=BF16) rounds scale to BF16 before multiply. Existing Float8WeightDecode uses F32(code*originalSF) then output cast. Independent code0x3c/SF0x3f809249 witness yields3fc2 vs3fc1; neither contract is silently changed.',
   'Fixed vLLM7b569 resolves FP8_PB_WO as static128 weight plus dynamic128 activation (W8A8), default output dtype from BF16 config. Missing input_activations metadata/name WO does not prove A16. This batch validates Hyle stored-F32/dynamic128 software reference, not all native vLLM kernel arithmetic or original fake-QDQ equivalence.',
   'GLM32 actual fixed MLX-VLM default loader preserves original F16 SF/bias. MLX promotion of BF16 A plus F16 SF is F32, consistent with Hyle that mixed affine domain. Explicit dtype conversion and native same-low-dtype kernels are separate.',
   'GLM31 fixed mlx-lm glm_moe_dsa -> deepseek_v32 -> mla uses156 head banks, not routed experts. L1 transposed projection can use existing grouped operation and head IDs plus explicit small activation Copy. L>1 needs non-transposed packed multiplication: a real missing orientation in current API.']),
 remaining_required='Next implement affine packed A*W orientation in original MlxQuantized across backends, preserving physical K packing/grouping and compressed residency; test both head decode/prefill. Do not swap N/K or fake completion with full floating expansion. Capability package8 and all3delivery packages stay open.',
 source_review=ident(P/'apple/importer-source-review.json'),windows_targeted_objects=objects,
 build='Windows5 final fresh CXX owners:common import/test plus3 existing wrappers.3 first wrapper attempts failed only W4/WX lambda shadow warning; renamed local lambda and3 retries passed. Apple3new CXX inclMoE wrapper/import/old+new importer wrapper. Original CUDA AOT/SPIRV/Metal programs, SDKs and all unrelated objects reused, no NVCC/shader/full build.',
 limitations=['Finite generated scale/role/software-math/resource witnesses. No publisher payload or all-shard binding, whole-model, Linux, quality or throughput acceptance.',
 'Ordinary BF16 pre-SF graph is a source-derived design here, not a newly executed reference or replacement for the dynamic deployment path. Original F32 decode contract retained.',
 'Apple generic MoE pass is not a GLM whole layer or every MLX low-dtype native kernel. Head non-transposed packed prefill remains to implement. All33catalog artifact_execution_verified flags stayfalse.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],current_sources=len(sources),cases=14,new=6,neighbors=8)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
