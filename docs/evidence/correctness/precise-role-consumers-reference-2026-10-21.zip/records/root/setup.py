from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[1];A=P.parent
old=A/'expert-working-set-2026-10-21'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for name in ('build_common.py','build_wrapper.py','run_windows.py'):
 (P/'root'/name).write_bytes((old/'root'/name).read_bytes())
script=(old/'root/link_windows.py').read_text()
start=script.index("if arm=='cuda':");end=script.index('if len(sys.argv)>3:')
(P/'root/link_windows.py').write_text(script[:start]+script[end:],encoding='utf-8')
rows=[]
for attempt,name in [('import2','weight_import.cc'),('test1','weight_import_test.cc')]:
 for row in read(old/f'common/checks/{attempt}/summary.json')['identities']:
  rec=read(Path(row['path']))
  if Path(rec['source']['path']).name==name:
   rows.append(dict(old_object=rec['object'],source=identity(Path(rec['source']['path'])),
      recipe=identity(Path(row['path'])),command=rec['command'],arms=rec['arms']))
bases={arm:identity(old/arm/'checks'/link/'link-plan.json')
 for arm,link in [('cpu','link4'),('cuda','link1'),('vulkan','link1')]}
(P/'root/common-plan.json').write_text(json.dumps(dict(bases=bases,owners=rows),indent=2)+'\n',encoding='utf-8')
print(dict(targeted_owners=len(rows),SDK_builds=0))
