from pathlib import Path
P=Path(__file__).resolve().parents[1]
text=(P.parent/'expert-working-set-2026-10-21/root/prepare_cleanup.py').read_text()
text=text.replace('expert-working-set-reference-2026-10-21','precise-role-consumers-reference-2026-10-21')
text=text.replace('expert-working-set-2026-10-21','precise-role-consumers-2026-10-21')
text=text.replace('expert working-set','precise role consumer')
# Windows PowerShell5.1 adds provider properties to Get-Content strings.
# Reading through .NET avoids serializing PSDrive/PSProvider recursively.
text=text.replace('source_script = (Get-Content -LiteralPath $PSCommandPath -Raw)',
                  'source_script = [IO.File]::ReadAllText($PSCommandPath)')
(P/'root/prepare_cleanup.py').write_text(text,encoding='utf-8')
print('Prepared exact-file cleanup generator with plain-string receipt text.')
