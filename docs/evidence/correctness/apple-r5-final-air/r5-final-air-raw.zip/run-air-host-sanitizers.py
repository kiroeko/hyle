from pathlib import Path
import hashlib, json, os, shutil, subprocess, time
r=Path('/Users/kiro/hyle-verify/r5-apple-20260917')
source=r/'candidate-1636365b'
build=r/'host-sanitizers-1636365b'
logs=r/'logs/host-sanitizers-1636365b'
logs.mkdir(exist_ok=True)
commit='1636365bbe47779de24e84d7c7d1ed8088fe1af2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
env=os.environ.copy()
env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env['CMAKE_BUILD_PARALLEL_LEVEL']='2'
env['CTEST_PARALLEL_LEVEL']='1'
env['ASAN_OPTIONS']='halt_on_error=1'
env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
env['TSAN_OPTIONS']='halt_on_error=1'
for name in ('DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH','MLX_METAL_PATH'):
    env.pop(name,None)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,args,directory,timeout=1800):
    print(label,flush=True)
    start=time.monotonic()
    with (directory/(label+'.log')).open('w') as log:
        p=subprocess.run([str(x) for x in args],cwd=source,env=env,
                         stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    print(label+': rc='+str(p.returncode)+' seconds='+str(round(time.monotonic()-start,2)),flush=True)
    if p.returncode:
        print((directory/(label+'.log')).read_text()[-12000:],flush=True)
    p.check_returncode()
for sanitizer,flag in (('asan','address'),('ubsan','undefined'),('tsan','thread')):
    d=logs/sanitizer
    assert not d.exists(),'finite sanitizer attempt already has evidence; inspect before resuming'
    d.mkdir()
    run('configure',['/opt/homebrew/bin/cmake','-S',source,'-B',build,'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
        '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DHYLE_DEV_FACTORS=compute_route_apple;graph_route_apple',
        '-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=ON',
        '-DHYLE_STATIC=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_TESTS=ON',
        '-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_SANITIZER='+sanitizer,
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'],d)
    run('build',['/opt/homebrew/bin/cmake','--build',build,'--parallel','2','--target',
        'hyle_compute_route_apple_tests','hyle_graph_route_apple_tests'],d)
    commands=json.loads((build/'compile_commands.json').read_text())
    own=[x for x in commands if any('/'+p+'/' in x['file'] for p in (
        'src/compute_route_apple','src/graph_route_apple',
        'tests/compute_route_apple','tests/graph_route_apple'))]
    assert len(own)>=8,own
    assert all('-fsanitize='+flag in x['command'] for x in own)
    vendor=[x for x in commands if '/mlx/' in x['file'] and '/dependencies/' in x['file']]
    assert vendor and all('-fsanitize=' not in x['command'] for x in vendor)
    (d/'instrumented-commands.json').write_text(json.dumps(own,indent=2)+'\n')
    shutil.copyfile(build/'CMakeCache.txt',d/'CMakeCache.txt')
    record={'candidate':commit,'sanitizer':sanitizer,'scope':'HYLE host C++/ObjC++ and tests; MLX vendor/Metal GPU uninstrumented',
        'instrumented_own_units':len(own),'uninstrumented_mlx_units':len(vendor),
        'commands_sha256':sha(build/'compile_commands.json'),
        'artifacts':{p.name:sha(p) for p in (build/'bin/hyle_compute_route_apple_test',build/'bin/hyle_graph_route_apple_test')},
        'result':'RUNNING'}
    (d/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    run('ctest',['/opt/homebrew/bin/ctest','--test-dir',build,'--output-on-failure',
        '--no-tests=error','--timeout','120','-L','^(compute_route_apple|graph_route_apple)$','-LE','headers'],d,timeout=300)
    shutil.copyfile(build/'Testing/Temporary/LastTest.log',d/'LastTest.log')
    record['result']='PASS'
    record['logs']={p.name:sha(p) for p in d.glob('*.log')}
    (d/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(sanitizer+' PASS',flush=True)
print('PASS all three separate HYLE host sanitizer configurations',flush=True)
