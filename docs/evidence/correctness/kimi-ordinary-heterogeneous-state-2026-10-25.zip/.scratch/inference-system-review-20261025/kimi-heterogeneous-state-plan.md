# Kimi ordinary heterogeneous state: first bounded slice

Read-only cache/source audit; no Kimi build, GPU, network or product edit. This is independent of MTP.

## Actual reusable pieces and limits

- `d5_kda_full_fragments.h:85–182`: original H7168,96 heads×D128, convK4, three projected history rows and per-key-channel GatedDeltaNet state `[1,96,128,128]`. Existing `Reference*` mode gives the independent evaluator without constructing canned replays.
- KDA outputs0/2/5 are actual next history, recurrent state and hidden. Keep the public per-channel GatedDeltaNet, original A_log128→first96 and native F32 conv/gate/norm roles; no scalar GDN substitution.
- `d5_kimi_remaining_fragments.h:169–205`: MLA7168/Qrank1536/latent512+64,96 heads, K576/V512, gate and output. Existing public Graph ops and original BF16 grouped-weight/native-input contract are available.
- **Important finite-fixture limit:** current `mla()` always takes3 past rows, attends4, then drops the oldest row (`next_cache=rows(cache,1,3)`). It is not a full growing ordinary Kimi prefix cache. Do not quietly call that window a complete-model history adapter.
- `attention_residual:287+` owns a within-forward layer bank. Exclude this bank from cross-token StateSchema; no evidence says it is independent persistent session history.

## Cache/source identity

- The examined `fixed-role-binding-2026-10-21/kimi/{20,21,22,24}` caches contain configs, header samples, index prefixes and reader contracts; `review.json` explicitly records zero numeric tensor payload. These selected publishers are not the pinned official artifact.
- Official fixed source is `moonshotai/Kimi-K3@f831ab66814297da540d832a5235f8e904f29d06`. The examined official role facts are metadata, not source-body authentication.
- `kimi-original-state-role-gap.json` retains exact names/type/shape/shard/data-relative ranges for KDA0's14 roles plus MLA3's9 roles: **23 roles,1,352,207,360B**. They lie in original shards1 and4; original shard header/ETag/LFS identities and body receipts are missing from the examined cache. No acquisition is requested/started here.
- KDA0 small A_log/dt/three conv/o_norm roles total640,000B, but fetching just them cannot turn generated projection matrices into an original-source execution claim. Never substitute another publisher or another layer's same-shaped matrices.

## Minimal actual implementation shape

1. Add one test-only ordinary Kimi consumer, reusing `model_graph_run` for original Invocation bind/submit/wait/reset; no new executor or shared model framework. Start with generated original-geometry BF16/F32 parameters and label them synthetic.
2. One existing StateStore/StateHead per session retains conv historyF32 `[3,36864]`, KDA recurrenceF32 `[1,96,128,128]`, finite MLA cacheF32 `[capacity,576]`, actual I32 cursor and final featureF32 `[1,7168]`, plus a small epoch witness. No fake LM pending or MTP journal.
3. KDA executes from the complete expected-base Head. Its actual output5 lease feeds MLA input directly. Both graphs finish before a single StateDraft replaces all successor resources and one expected-base publish occurs.
4. For MLA, factor its existing pure prefix/attention/gate/output builder and independent reference just enough to use a cold finite position/visible count. Append into the fixed capacity with existing Scatter/view operations; attention sees only initialized rows0..position, including the actual new row. No zero-row attention or dropped-prefix substitution.
5. Keep old `mla()` warm fixture behavior and KDA graph/precision unchanged for their current callers. An optional independent MLA evaluator, like the existing KDA Reference mode, can consume actual KDA hidden and actual prior cache; it is test-only and never feeds a native result.
6. Cold prepare the few actual position phases before admission. Persistent buffers use existing leases/pools/StateStore accounting; bound retained generations for2 heads+candidate+fork+old readers. No per-token graph construction or new scope-wide owner table.

## One finite journey, not a matrix

- Two independent Heads, same prepared programs: A step0→1, B step0→1 with a distinct input; immutable fork of A then divergent next inputs. Check all physical KDA/MLA state and cursor against the actual predecessor/reference.
- After actual KDA output, abandon an unpublished candidate before MLA/publication; both Heads/epoch remain unchanged. Retry from the same expected base, complete both phases and publish. Reject stale publish; retain/read old leases through reuse.
- End with original Invocation retirement plus explicit StateStore.collect and exact zero live versions/backing. Report generated-geometry state integration only; authentic23-role binding remains a separate source task.

## Reusable closure

- New consumer can reuse current validated GLM/DeepSeek CUDA application closure (latest `.scratch/inference-system-review-20261025/glm-pro-early-history/attempt7/{compile,link}/command.json`, original native DLL), replacing only its consumer TU. No SDK/native rebuild or new dependency tree.
- Existing Kimi math cases remain in `tests/graph_route_cuda/d5_qwen38_official_test.cc:1333,1360` and CPU:987,1014. Their old finite proof is not a new joint-state execution. Ask root for GPU ownership before any future actual run.
