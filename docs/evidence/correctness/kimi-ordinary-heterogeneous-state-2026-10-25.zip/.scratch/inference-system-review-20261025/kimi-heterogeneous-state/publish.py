"""Offline evidence: generated original-geometry Kimi state, no artifact claim."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET,zipfile
R=Path.cwd();D=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def dump(p,x):p.write_bytes((json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for p in load(D/'after-pins.json'):
    actual=R/p['path'];assert pin(actual)==p
one=load(D/'attempt1/ready.json');two=load(D/'attempt2/ready.json')
old={p['path'].lower():p for p in one['sources']}
for p in two['sources']:
    if p['path'].lower().endswith('kimi_heterogeneous_state_consumer_test.cc'):continue
    assert old[p['path'].lower()]==p
dump(D/'source-reuse.json',dict(non_consumer_headers='All23 source dependencies except consumer itself match byte/SHA across attempts1/2; archive one common source tree.',header_changed_after_GPU=False))
tree=ET.parse(D/'attempt1/actual/results.xml').getroot()
assert tree.get('tests')=='1' and tree.get('failures')=='0' and not list(tree.iter('skipped'))
properties={p.get('name'):p.get('value') for p in tree.iter('property')}
rows=[dict(session=int(s),position=int(p),visible=int(v),epoch=int(e),resource_members=int(r))
      for s,p,v,e,r in re.findall(r'Kimi synthetic ordinary session=(\d+) position=(\d+) visible=(\d+) epoch=(\d+) completeResources=(\d+)',
          (D/'attempt1/actual/stdout.log').read_text())]
assert [(r['session'],r['position']) for r in rows]==[(0,0),(1,0),(0,1),(2,1),(0,2),(1,1)]
assert properties['ordinary_commits']=='6' and properties['cancelled_unpublished_candidates']=='1' and properties['stale_publish_rejections']=='6'
assert load(D/'attempt1/actual/process.json')['exit']==0
assert load(D/'attempt2/host/process.json')['exit']==0
host=ET.parse(D/'attempt2/host/results.xml').getroot();assert host.get('tests')=='3' and host.get('failures')=='0'
dump(D/'actual-facts.json',dict(status='PASS_FINITE_SYNTHETIC_COMPONENT',rows=rows,properties=properties,
    actual_process=load(D/'attempt1/actual/process.json'),KDA_submissions=7,MLA_submissions=6,
    final_state_assertions=dict(versions=0,drafts=0,backing_bytes=0,explicit_collect=True),
    GPU_processes=1,SDK_builds=0,backend_TU_builds=0,HTTP=0,
    actual_source=one['sources'],epoch_followup='Later CPU3 host suite reads the same Epoch type through real StateStore/Head; added native-consumer Epoch observation assertions compiled but not GPU rerun.'))
dump(D/'source-review.json',dict(default_warm=dict(before_header=load(D/'before-pins.json'),
    graph='Without OrdinaryHistory: same past3 input, Concat to4, rows1/3 next state, visible4 attention, same projection/Cast/output/state-port order. No extra graph node is created by the absent optional branch.',
    reference='Same four-row F64 accumulation order and BF16 reader rounding; array4 becomes vector4 in test-only oracle. No new warm execution claim.'),
    ordinary=dict(cache='Full fixed-capacity Scatter successor; attention sees only initialized prefix position+1. Unwritten NaN rows copied unchanged and checked by exact bits.',
    cursor='Actual stored I32 lease is bound to existing public Concat/Scan/Gather and produces next cursor, verified on all6 actual commits.',
    publication='StateDraft holds KDA and MLA successor resources plus actual cursor/final feature/Epoch; finalize/publish only after both original Graph invocations retire and all numerical checks pass.',
    cancellation='After retired KDA, cancel unpublished StateDraft before MLA; no Head/epoch commit. Retry uses same original base. No native GPU preemption claim.',
    ownership='Original StorageOwner/Graph bindings/ReadLease/output pools and model_graph_run reset/retirement; no executor, Store implementation, model app or new primitive.'),
    registration=dict(path='tests/graph_route_cuda/CMakeLists.txt',target='hyle_graph_route_cuda_kimi_heterogeneous_state_test',kind='Static registration only, no CMake configure/full build; actual manual compile/link commands preserved.')))
files=set()
def add(p):
    assert p.is_file(),p
    assert p.suffix.lower() not in {'.exe','.obj','.dll','.lib','.exp','.pdb'},p
    files.add(p)
for p in D.iterdir():
    if p.is_file() and p.name!='publication.json' and p.suffix in {'.json','.py','.patch'}:add(p)
for p in (D/'before').rglob('*'):
    if p.is_file():add(p)
for attempt in [1,2]:
    folder=D/f'attempt{attempt}'
    for p in folder.rglob('*'):
        if not p.is_file() or 'runtime-tmp' in p.relative_to(folder).parts:continue
        parts=p.relative_to(folder).parts
        if 'source' in parts and attempt==1 and p.name!='kimi_heterogeneous_state_consumer_test.cc':continue
        if p.suffix in {'.json','.log','.xml'} or 'source' in parts:add(p)
for p in load(D/'after-pins.json'):add(R/p['path'])
for name in ['kimi-heterogeneous-state-plan.md','kimi-original-state-role-gap.json']:
    add(D.parent/name)
add(R/'.scratch/mtp-extraction-regression-20261024/check.py')
add(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')
public=R/'docs/evidence/correctness/kimi-ordinary-heterogeneous-state-2026-10-25'
archive=public.with_suffix('.zip');manifest=[pin(p) for p in sorted(files)]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
    z.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in manifest:
        raw=z.read(p['path']);assert len(raw)==p['bytes'] and hashlib.sha256(raw).hexdigest()==p['sha256']
proof=dict(schema=1,date='2026-10-25',status='PASS_FINITE_SYNTHETIC_ORIGINAL_GEOMETRY_COMPONENT',
    scope='Ordinary heterogeneous Kimi7168 KDA+absorbed MLA StateStore/StateHead component, generated sparse BF16/F32 weights. No original Kimi artifact, full model or quality claim.',
    changes=load(D/'after-pins.json'),source_review=load(D/'source-review.json'),
    validation=dict(actual=load(D/'actual-facts.json'),
        GPU_image=one['image'],GPU_frozen_source_consumer=next(p for p in one['sources'] if p['path'].endswith('kimi_heterogeneous_state_consumer_test.cc')),
        initial_host=load(D/'attempt1/host/process.json'),initial_host_tests=2,
        epoch_host=load(D/'attempt2/host/process.json'),epoch_host_tests=3,epoch_host_image=two['image'],
        epoch_host_followup_patch=str((D/'epoch-observation-only.patch').relative_to(R)),
        initial_compile=load(D/'attempt1/compile/process.json'),initial_link=load(D/'attempt1/link/process.json'),
        followup_compile=load(D/'attempt2/compile/process.json'),followup_link=load(D/'attempt2/link/process.json'),
        native_DLL=one['native'],compiler='MSVC14.50 /W4 /WX, one consumer TU per source snapshot, original GLM/DeepSeek native closure reused',
        actual_hardware='Original native log: NVIDIA GeForce RTX4070, sm89,12281MiB; Windows x64',retained_failures=[],
        summary_note='The original actual/summary.json inherited weights_loaded=false from the host runner: this denotes no original artifact payload, not absence of generated uploaded parameters. Raw commands/XML/source remain untouched; actual-facts.json is the precise statement.'),
    original_source_boundary=dict(repository='moonshotai/Kimi-K3',revision='f831ab66814297da540d832a5235f8e904f29d06',
        authenticated_original_body=False,original_roles_still_unbound=23,original_role_bytes=1352207360,
        role_gap='Archived exact metadata-only role/range inventory; original headers/strong identity/body acquisition not performed in this task.',
        source_downloads=0,existing_cache='Bounded known cache scan found metadata/header samples but no additional original numeric payload.'),
    limits=['No original source-bound execution or trained quality/TPS result.',
        'Actual KDA output feeds actual MLA; omitted intervening full model layers and residual connections are an explicit composite boundary.',
        'Finite capacity4, actual initialized visibility1/2/3, two initial Heads and one restored fork; no all-context/backend matrix.',
        'AttnRes remains frame-local and is excluded from persistent session state; no LM pending/token/MTP claim.',
        'The only GPU process used frozen attempt1. Later Epoch observation assertions are compile+CPU-host followup, not a second GPU pass.',
        'StateStore budget105969664B is the finite tracked state backing limit, not a total physical VRAM cap.',
        'No SDK rebuild, backend source change, original weight download/copy or new executor.'],
    archive={**pin(archive),'members':len(manifest)+1,'CRC':'PASS','each_member_sha256':'PASS','excluded':'All weights, executables, objects, DLLs, SDK/dependency trees'})
dump(public.with_suffix('.json'),proof)
dump(D/'publication.json',dict(summary=pin(public.with_suffix('.json')),archive=pin(archive),members=len(manifest)+1))
print(json.dumps(load(D/'publication.json')))
