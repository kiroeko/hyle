"""Refresh one model consumer TU using a real already-validated native closure."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=R/'.scratch/inference-system-review-20261025/glm-pro-early-history/attempt7'
target=D/(sys.argv[1] if len(sys.argv)>1 else 'attempt1');target.mkdir(exist_ok=False)
original=b.args(old/'compile/command.json');flags=[];skip=False
for flag in original[1:]:
    if skip:skip=False;continue
    if flag=='/sourceDependencies':skip=True;continue
    lower=flag.lower().replace('\\','/')
    if lower.startswith(('/fo','/fd')) or lower.endswith(('.cc','.cpp')):continue
    flags.append(flag)
source=R/'tests/compute_models/kimi_heterogeneous_state_consumer_test.cc'
paths=[source,R/'tests/compute_models/d5_kimi_remaining_fragments.h',R/'tests/compute_models/d5_kda_full_fragments.h']
before=[b.pin(p) for p in paths];b.save(target/'before-pins.json',before)
env=b.environment(original[0])
b.execute([original[0],*flags,'/DHYLE_TEST_KIMI_STATE_CUDA=1',str(source),
    '/sourceDependencies',str(target/'dependencies.json'),'/Fo'+str(target/'consumer.obj')],target/'compile',env,120)
assert before==[b.pin(p) for p in paths],'Product source changed during compile'
deps=b.read(target/'dependencies.json')['Data'];pins=[]
for name in [deps['Source'],*deps['Includes']]:
    p=Path(name).resolve()
    if p.is_relative_to(R/'tests') or p.is_relative_to(R/'engine'):
        record=b.pin(p);q=target/'source'/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True)
        q.write_bytes(p.read_bytes());pins.append(record)
b.save(target/'actual-source-pins.json',pins)
link=b.args(old/'link/command.json');args=[];replaced=0
for word in link[1:]:
    if word.lower()==str(old/'consumer.obj').lower():args.append(str(target/'consumer.obj'));replaced+=1
    elif not word.lower().startswith(('/out:','/pdb:','/implib:','/map:')):args.append(word)
assert replaced==1
b.execute([link[0],*args,'/OUT:'+str(target/'checks.exe'),'/IMPLIB:'+str(target/'checks.lib')],target/'link',env,120)
native=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
os.link(native,target/native.name)
b.save(target/'ready.json',dict(image=b.pin(target/'checks.exe'),object=b.pin(target/'consumer.obj'),sources=pins,
    native=b.pin(native),SDK_builds=0,HTTP=0,base_compile=b.pin(old/'compile/command.json'),base_link=b.pin(old/'link/command.json')))
print(json.dumps(dict(status='compiled_linked',image=b.pin(target/'checks.exe'),project_sources=len(pins))))
