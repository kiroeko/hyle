from pathlib import Path
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else 'attempt1')
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(D/'ready.json');assert b.pin(D/'checks.exe')==ready['image']
env=os.environ.copy();env['PATH']=str(D)+';'+b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')['PATH']
out=D/'actual'
b.execute([str(D/'checks.exe'),'--gtest_color=no','--gtest_filter=KimiHeterogeneousState.*',
    '--gtest_output=xml:'+str(out/'results.xml')],out,env,600)
tree=ET.parse(out/'results.xml').getroot()
assert int(tree.get('tests'))==1 and int(tree.get('failures'))==0 and not list(tree.iter('skipped'))
b.save(out/'summary.json',dict(status='PASS',tests=1,skips=0,original_weights_loaded=False,generated_parameter_buffers_uploaded=True,
    native_context_created=True,SDK_builds=0,HTTP=0))
