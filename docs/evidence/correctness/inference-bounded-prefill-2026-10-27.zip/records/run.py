"""One CUDA journey: generated prefix reveals an unlisted T2/B2 tail; no retry."""
from pathlib import Path
import importlib.util
import json
import re
import sys
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('bounded_build',W/'build.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
b=build.b


def fnv(ids):
    value=1469598103934665603
    for token in ids:value=((value^token)*1099511628211)&((1<<64)-1)
    return value


def main():
    if sys.argv[1:]!=['run']:print('Prepared only; explicit run after successful host and CLI build.');return
    assert not (W/'run-plan.json').exists()
    ready=b.read(W/'ready.json')
    for field in ('image','source','header','test'):b.exact(ready[field])
    source_control=R/'.scratch/inference-shape-policy-20261027/warmup/runs/fixed-planned/report.json'
    assert b.read(source_control)['generated_ids'][0]==37
    prompts={'A':[1,2,3],'C':[20],'B':[1,2,3,37,4,5],'D':[1,2,3,37,6,7]}
    quotas={'A':2,'C':2,'B':1,'D':1}
    folder=W/'case';folder.mkdir()
    for name,ids in prompts.items():
        (folder/(name+'.ids')).write_text(' '.join(map(str,ids))+'\n',encoding='utf-8')
        (folder/(name+'.schedule')).write_text(f'prompt {name}.ids\ngenerate {quotas[name]}\n',encoding='utf-8')
    (folder/'sessions.tsv').write_text(''.join(f'{name} {name}.schedule\n' for name in prompts),encoding='utf-8')
    inputs=R/'.scratch/inference-shape-policy-20261027/cli/inputs'
    command=[ready['image']['path'],'--inputs',str(inputs),'--backend','cuda','--capacity','16',
        '--sampling','greedy','--mtp','off','--prefill-chunk-tokens','3','--warmup-shapes','planned',
        '--session-schedules',str(folder/'sessions.tsv'),'--max-sessions','4','--active-sequences','2',
        '--prefix-cache','auto','--progress','direct','--replay','commands']
    b.save(W/'run-plan.json',dict(image=ready['image'],source=ready['source'],command=command,
        input_files=[b.pin(p) for p in sorted(folder.iterdir())],manifest=b.pin(inputs/'weights.tsv'),
        seed_first_output_control=b.pin(source_control),prompts=prompts,quotas=quotas,
        intent='A/C have distinct first T to preserve A T3 B1, both finish on wave2; B/D next wave adopt generated A prefix length4, not its initial prompt length3. Their real T2 tail must already have B2 EmitNext cold key.',
        scope='One functional CUDA process, no baseline rerun/quality/performance/cross-chunk bitwise assertion.'))
    helper=b.helper();cl=b.read(W/'compile-plan.json')['command'][0]
    env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    env['PATH']=b.read(ready['runtime']['path'])['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    process=helper.execute(command,env,W/'cli/run1',timeout=90)
    raw=json.loads((W/'cli/run1/stdout.log').read_text(encoding='utf-8-sig'));b.save(W/'cli/run1/report.json',raw)
    assert raw['backend']=='cuda' and not raw['mtp'] and raw['sampling']=='greedy'
    assert raw['admitted_requests']==raw['retired_requests']==4 and raw['generated_tokens']==6
    assert raw['cold_exact_admissions']==raw['cold_exact_evictions']==0
    assert raw['actual_graph_calls']==4 and raw['actual_target_rows']==10 and raw['restore_count']==0
    sessions={s['session_id']:s for s in raw['sessions']};assert sessions['A']['result']['generated_ids'][0]==37
    facts={}
    for name,session in sessions.items():
        result,ledger=session['result'],session['ledger'];generated=result['generated_ids']
        assert len(generated)==quotas[name] and result['sampling_draw_cursor']==0
        consumed=prompts[name]+generated[:-1];offset=0
        for row in ledger:
            part=consumed[offset:offset+row['input_rows']]
            assert part and row['input_hash']==fnv(part) and row['first_input']==part[0]
            offset+=len(part);assert row['after_length']==offset
        assert offset==len(consumed)==result['visible_tokens']
        facts[name]=dict(generated_ids=generated,visible=result['visible_tokens'],reused=result['reused_tokens'],
            imported_rows=sum(x['input_rows'] for x in ledger if x['imported']),
            actual_rows=[x['input_rows'] for x in ledger if not x['imported']])
        if name in ('B','D'):
            assert result['reused_tokens']==4 and result['prefix_hits']==1 and not result['prefix_full_hits']
            actual=[x for x in ledger if not x['imported']]
            assert len(actual)==1 and actual[0]['input_rows']==2 and actual[0]['requests']==2
    assert any(batch['requests']==2 and batch['tokens']==2 and set(batch['session_ids'])=={'B','D'} and not batch['generation'] for batch in raw['batches'])
    stderr=(W/'cli/run1/stderr.log').read_text(encoding='utf-8-sig').splitlines()
    ready_line=next(i for i,x in enumerate(stderr) if x.startswith('generation_shape_prepare_seconds='))
    plans=[re.fullmatch(r'cold_shape_plan planned_shapes=(\d+) extra_capacity=(\d+)',x) for x in stderr if x.startswith('cold_shape_plan ')]
    assert len(plans)==1 and plans[0] and int(plans[0][1])==int(plans[0][2])>0
    assert not any(x.startswith(('compiled T=','cold_exact_admission ')) for x in stderr[ready_line+1:])
    b.save(W/'summary.json',dict(status='SIX_HOST_AND_GENERATED_PREFIX_TAIL_B2_CUDA_PASS',source=ready['source'],header=ready['header'],test=ready['test'],
        image=ready['image'],host=ready['standalone']['run'],CUDA_process=process,sessions=facts,
        actual_graph_calls=raw['actual_graph_calls'],actual_target_rows=raw['actual_target_rows'],
        planned_shapes=int(plans[0][1]),extra_shape_capacity=int(plans[0][2]),
        cold_exact_admissions=0,cold_exact_evictions=0,compiled_after_ready=0,
        counts=dict(CXX_TUs=2,links=2,host_groups=6,host_processes=1,CUDA_processes=1,baseline_reruns=0,MTP_reruns=0,SDK=0,NVCC=0,downloads=0),
        scope='One untrained cached CUDA journey proves actual generated-prefix partial hit T2/B2 is preplanned; shared integer contracts cover additional powers/nonpowers and SIZE_MAX. No speed/quality/full-model/all-platform claim.'))
    print('PASS',json.dumps(b.pin(W/'summary.json')),flush=True)


if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'run-failure.json',dict(error=traceback.format_exc(),note='Original process and outputs retained; no automatic retry'))
        raise
