"""Offline bounded-prefill receipt. No compiler, device or model execution."""
from pathlib import Path
import hashlib
import json
import zipfile
W=Path(__file__).resolve().parent
R=W.parents[1]


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(path):return dict(path=str(Path(path).resolve()),**digest(Path(path).read_bytes()))


def main():
    ready,summary=read(W/'ready.json'),read(W/'summary2.json')
    assert summary['status']=='SIX_HOST_AND_GENERATED_PREFIX_TAIL_B2_CUDA_PASS'
    assert summary['cold_exact_admissions']==summary['cold_exact_evictions']==summary['compiled_after_ready']==0
    assert ready['source']['sha256']=='0f73055bd8b6590a67d0af4621584848b5e66316750cab97b09cb03a11648eac'
    out=R/'docs/evidence/correctness/inference-bounded-prefill-2026-10-27.json'
    archive=out.with_suffix('.zip');assert not out.exists() and not archive.exists()
    members,origins={},{}
    def add(name,path):
        path=Path(path);assert path.is_file() and name not in members
        assert path.suffix.lower() in {'.py','.json','.cc','.h','.log','.ids','.schedule','.tsv','.txt'}
        members[name]=path.read_bytes();origins[name]=str(path.resolve())
    for path in sorted(W.iterdir()):
        if path.is_file() and path.suffix.lower() in {'.py','.json','.cc','.h','.txt'}:add('records/'+path.name,path)
    for folder in ('compile','link','host/compile','host/link','host/run1','cli/run1','cli/run2','case'):
        for path in sorted((W/folder).iterdir()):
            if path.is_file() and path.suffix.lower() in {'.json','.log','.ids','.schedule','.tsv'}:
                add('records/'+path.relative_to(W).as_posix(),path)
    add('control/current-closure-ready.json',R/'.scratch/inference-request-error-identity-20261027/ready.json')
    seed=R/'.scratch/inference-shape-policy-20261027/warmup/runs/fixed-planned'
    for name in ('report.json','facts.json'):add('control/seed-first-output-'+name,seed/name)
    inputs=R/'.scratch/inference-shape-policy-20261027/cli/inputs'
    for name in ('weights.tsv','prompt.ids'):add('inputs/'+name,inputs/name)
    index=dict(members=[dict(member=name,original_path=origins[name],**digest(raw)) for name,raw in sorted(members.items())],
        exclusions='No EXE/OBJ/PDB/library, model payload, SDK or dependency source tree. Actual dependencies and retained objects remain hash metadata.')
    index_bytes=(json.dumps(index,indent=2,ensure_ascii=False)+'\n').encode()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(members.items()):z.writestr(name,raw)
        z.writestr('member-sha256.json',index_bytes)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(members)+1
        assert z.read('member-sha256.json')==index_bytes
        for name,raw in members.items():assert digest(z.read(name))==digest(raw)
    report=dict(status='PASS_FINITE_BOUNDED_PREFILL_WITH_COVERAGE_SETUP_CORRECTION',date='2026-10-27',
        source=ready['source'],header=ready['header'],test=ready['test'],image=ready['image'],ready=pin(W/'ready.json'),
        changes=['Finite Q consumes full Q blocks and exact bit_floor tail blocks; default SIZE_MAX and explicit finite-Q MTP rejection remain.',
            'Exact parts uses quotient+popcount; parts_bound covers the nonmonotonic count of shorter unknown prefix suffixes.',
            'Possible ordinary prefix tail rows/completion/member support join the existing finite Family and complete B/sampling keys before carrier preparation.',
            'Original extra exact FIFO capacity is frozen once from initial planned complete keys (minimum1), independent of N; same owners, drain and budgets.'],
        counts=summary['counts'],build=dict(model=ready['compile'],CLI_link=ready['link'],host_compile=ready['standalone']['compile'],host_link=ready['standalone']['link'],
            actual_dependencies=ready['actual_dependencies'],host_actual_dependencies=ready['standalone']['actual_dependencies'],
            retained_CLI_inputs=pin(W/'retained-inputs.json'),failed_CXX_or_link_processes=0),
        results=dict(host=dict(process=summary['host'],groups=6,
                scope='Real partition examples, exact/upper-bound counts, all possible first suffix keys for Q1/2/3/5/8/16 and remaining0..40, invalid cursor and SIZE_MAX.'),
            generated_prefix_tail=dict(process=summary['CUDA_process'],sessions=summary['sessions'],
                actual_graph_calls=summary['actual_graph_calls'],actual_target_rows=summary['actual_target_rows'],
                source_initial_prompt_rows=3,source_generated_checkpoint_rows=4,adopted_prefix_rows_each=4,remaining_real_rows_each=2,physical_batch_requests=2,
                planned_shapes=summary['planned_shapes'],extra_shape_capacity=summary['extra_shape_capacity'],N=2,R=2,N_times_R=4,
                cold_exact_admissions=0,cold_exact_evictions=0,compiled_after_ready=0)),
        first_attempt=dict(process=read(W/'cli/run1/process.json'),classification='Native success, intended coverage not reached; post-run expectation failed.',
            actual_graph_calls=5,actual_target_rows=18,prefix_hits=0,cold_exact_admissions=0,
            cause='N4 admitted all four requests in one wave; R2 only limited physical buckets. Same-wave prefix lookup isolation correctly hid the new source checkpoint.',
            correction=pin(W/'fixture-correction.json'),scope='Only N4 to N2, same image/input/seed/R2. Root authorized one extra process; no rebuild or host rerun.'),
        reuse=dict(previous_evidence=pin(R/'docs/evidence/correctness/inference-request-error-identity-2026-10-27.json'),
            baseline=read(W/'plan.json')['baseline_image'],SDK_builds=0,NVCC=0,weights_rebuilds=0,report_rebuilds=0,downloads=0),
        limits=['One successful targeted untrained tiny CUDA generated-prefix journey after one preserved coverage setup mismatch; six standalone host groups.',
            'Q3 actual B2 tail was checked; extra binary tail episodes for Q8 and other finite quantums were host contracts, not additional model runs.',
            'No padding or new varlen/provider execution semantics, no full-model/platform matrix, no MTP rerun or native fault injection.',
            'Different real chunk widths can change legal GEMM/attention rounding and add episodes; no cross-chunk bitwise quality or performance benefit claim.',
            'Only one sampling configuration was exercised by this CUDA journey. Complete sampler-key handling was source-reviewed.',
            'The neighboring qwen_chunked_prefill_case migration and its execution are a separate consumer/evidence owned by the parent team.'],
        archive=dict(**pin(archive),members=len(members)+1,CRC_and_member_SHA256_verified=True))
    out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=pin(out),archive=report['archive']),indent=2))


if __name__=='__main__':main()
