from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;E=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_text())
def identity(p):
 raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
tests=read(O/'tests.json');assert tests['tests']==2 and tests['failures']==tests['errors']==0
cases=tests['testsuites'][0]['testsuite'];assert all(int(x['checked_F32_values'])==2732 and int(x['successful_submissions'])==6 and int(x['nonfinite_failed_Completions'])==6 for x in cases)
files={}
def add(p,name=None):assert p.is_file(),p;files[name or p.relative_to(R).as_posix()]=p
for p in [O/'check.py',Path(__file__),O/'tests.json']:
 add(p)
for phase in ['provider','consumer','link','run','initial-fixture-failure']:
 for p in (O/phase).iterdir():
  if p.is_file()and p.suffix in('.json','.log','.cc'):add(p)
kernel=R/'.scratch/fp8-quant-output-20261023/compile1/quant-kernel/quant-kernel.obj';assert kernel.is_file()
for p in [R/'src/compute_provider_cuda/float8_quantize_kernel.h',R/'src/compute_provider_cuda/fp8_provider.h',R/'tests/graph_route_cpu/CMakeLists.txt',R/'tests/graph_route_cuda/CMakeLists.txt']:add(p)
stem='cuda-fp8-f32-power2-linear-2026-10-24';archive=E/(stem+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(files.items()):z.write(p,name)
proof=dict(date='2026-10-24',status='PASS bounded CPU/CUDA F32 PowerOfTwo dynamic linear',
 problem='The public Float8BlockLinear contract admitted F32 A with PowerOfTwo dynamic group128 quantization, but the CUDA route declined it because its embedded pow2 Triton quantizer only accepted BF16.',
 implementation=dict(source=identity(O/'provider/fp8_provider.cc'),
  public_ABI_changed=False,native_kernel_ABI_changed=False,
  new_path='Existing native F32 PowerOfTwo quantizer writes E4 codes and row-major F32[M,K/128] scales into the existing caller-owned encoded activation workspace, then the existing F32-output encoded GEMM runs on the original shared CUDA queue.',
  unchanged_path='The original BF16 pow2 Triton entry remains explicitly BF16-only and retains column-major activation scales. Divide and MultiplyReciprocal routes and their original modules remain unchanged.',
  layout='The GEMM launch chooses scale strides from the actual selected quantizer carrier. New native F32 uses row-major group strides; existing BF16 pow2 uses the old col-major ABI.',
  failure='The new native quantizer uses the original sequence device status. A real status-reset prefix is retained across later launch errors; NaN/+Inf fails the original Completion and publishes no successful Graph result. No CPU readback/executor is introduced.',
  ownership='Existing immutable provider plan, invocation workspace, original runtime retirement and Graph caller/result leases. Native kernel loading finishes during prepare, before replay/capture.',
  native_quantizer_object_reused=identity(kernel),
  native_quantizer_prior_evidence='docs/evidence/correctness/fp8-quantize-output-2026-10-23.json'),
 validation=dict(tests=2,failures=0,cases=cases,successful_graph_submissions=12,intentional_nonfinite_failed_Completions=12,exact_checked_F32_output_values=5464,
  shapes=[dict(M=3,N=3,K=128),dict(M=3,N=129,K=384),dict(M=5,N=[65,129],K=256,shared_A=True)],
  inputs='Nonunit/nonpower2 group maxima, non-BF16-representable F32 values adjacent to E4 RNE boundaries, distinct row/group scales, nonpower2 original F32 weight scales and partial N tiles.',
  oracle='Independent scalar code table, RNE enumeration, frexp power2 scale and explicit F32 boundaries; sparse code-domain dots isolate layout/operand/output arithmetic without a vendor reduction-tree claim.',
  exact_F32_output_witness=dict(first_case_phase0_row0_column0=0.0044116973876953125,incorrect_final_BF16=0.004425048828125),
  wrong_BF16_input_witnesses_per_backend=2732,
  paired_graph='CPU executes2steps; CUDA executes1selected shared-prologue pair step, so the two-output shared native quantization path actually runs.',
  lifetime='Old readonly results remain exact across independent NaN/+Inf failures, later successful generation and compiled-plan release.',
  fixture_correction=read(O/'initial-fixture-failure/cause.json'),
  fixture_limit='The initial focused test forgot Invocation::prepare_resources before owned bindings; both backends rejected before executing the new dynamic linear. The normal binding API fixed this test error; no product resource guard was relaxed.'),
 source_binding=dict(affected_catalogs=[6,15],
  statement='This closes a genuine generic CUDA combination gap. It does not assert that the two pinned Qwen FP8 sources require F32 activation or this PowerOfTwo reader policy; source configs only establish dynamic block128 FP8 and Q24 bfloat16.',
  original_source_evidence='docs/evidence/correctness/mtp-original-source-format-tiles-2026-10-24.json',
  historical_note='The older frozen source-tile proof correctly records that F32 dynamic PowerOfTwo was then unavailable; its F32 profile explicitly used already encoded A MatMul. That archive was not rewritten.'),
 tooling=dict(HTTP=0,SDK_rebuilds=0,native_kernel_rebuilds=0,scope='Only the provider TU and existing quantize-output test TU were incrementally compiled, reusing native kernels, cubins and existing CPU/CUDA SDK closure.',
  normal_CTest=['hyle_graph_route_cpu_float8_quantize_output_test','hyle_graph_route_cuda_float8_quantize_output_test'],
  commands=['python .scratch/fp8-f32-power2-20261024/check.py build','python .scratch/fp8-f32-power2-20261024/check.py run']),
 limitations=['No model weights were acquired or new complete model executed for this generic function fix.',
  'No throughput, physical-memory peak or BF16 performance comparison was run.',
  'CUDA still uses the existing SM89 AOT GEMM qualification; no claim is made for another GPU architecture.',
  'Commands replay was measured for correctness. No new capture-specific claim is signed by these two tests.',
  'No SDK, object, executable, cubin body or model tensor is embedded in this archive.'],archive=identity(archive),archived_files=len(files))
path=E/(stem+'.json');path.write_text(json.dumps(proof,indent=2,allow_nan=False)+'\n',encoding='utf8');print(json.dumps(dict(report=identity(path),archive=identity(archive))))
