from pathlib import Path
import importlib.util,json,os,sys
O=Path(__file__).resolve().parent;R=O.parents[1]
spec=importlib.util.spec_from_file_location('bounded_native_helpers',R/'.scratch/mtp-metadata-offline-20261024/source-components/check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.O=O;b=m.b
def flags(command):
 out=[];skip=False
 for x in command:
  if skip:skip=False;continue
  if x=='/sourceDependencies':skip=True;continue
  if x.startswith(('/Fo','/Fd'))or x.lower().endswith('.cc'):continue
  out.append(x)
 return out
def build(consumer_only=False):
 original=b.read(R/'.scratch/mtp-metadata-offline-20261024/source-components/fp4-provider/identity.json')['command'];native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':original[0],'CMAKE_CXX_COMPILER':original[0],'CMAKE_GENERATOR':'Ninja'},backends=());sources=[]
 for label,source,command in [('provider',R/'src/compute_provider_cuda/fp8_provider.cc',flags(original)),('consumer',R/'tests/compute_models/float8_quantize_output_test.cc',flags(b.read(R/'.scratch/dense-linear-f32-20261024/test-ggml/identity.json')['command'])+['/DHYLE_TEST_FP8_QUANT_CPU=1','/DHYLE_TEST_FP8_QUANT_CUDA=1'])]:
  if consumer_only and label=='provider':
   prior=b.read(O/'provider/identity.json');b.require(prior['source']);b.require(prior['object']);sources.append(prior['source']);continue
  folder=O/label;folder.mkdir(parents=True,exist_ok=True);obj=folder/(label+'.obj');frozen=b.identity(source)
  m.execute([*command,'/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(folder/(label+'.pdb'))],native.env,label,180);b.require(frozen);sources.append(frozen);(folder/source.name).write_bytes(source.read_bytes())
  b.save(folder/'identity.json',dict(source=frozen,object=b.identity(obj)))
 link=[];replaced=0
 for x in b.read(R/'.scratch/dense-linear-f32-20261024/link-plan.json')['command']:
  if x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))or Path(x).name in('test-ggml.obj','test-cublas.obj','test-infer.obj'):continue
  if Path(x).name=='compute_provider_cuda--fp8_provider.obj':x=str(O/'provider/provider.obj');replaced+=1
  if Path(x).name=='graph--executable.obj':x=str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj')
  link.append(x)
 assert replaced==1
 image=O/'checks.exe';link +=[str(O/'consumer/consumer.obj'),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 m.execute(link,native.env,'link',120)
 runtime=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll';staged=O/runtime.name
 if not staged.exists():os.link(runtime,staged)
 assert b.identity(staged)['sha256']=='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'
 ready=b.read(R/'.scratch/dense-linear-f32-20261024/ready.json');b.save(O/'ready.json',dict(image=b.identity(image),PATH=str(O)+os.pathsep+ready['PATH'],sources=sources,fresh_TUs=2,reused_native_quantizer=True,SDK_builds=0,HTTP=0))
def run():
 ready=b.read(O/'ready.json');b.require(ready['image']);m.execute([ready['image']['path'],'--gtest_filter=Float8QuantizeOutput.*F32Power2Linear','--gtest_output=json:'+str(O/'tests.json')],dict(os.environ,PATH=ready['PATH']),'run',120);print((O/'run/stdout.log').read_text())
if __name__=='__main__':
 if sys.argv[1]in('build','all'):build()
 if sys.argv[1]=='build-consumer':build(True)
 if sys.argv[1]in('run','all'):run()
