"""Publish actual BW packed small-batch results. Root invokes after terminal checks.

Only small sources/metadata/logs are archived. Original payloads and cached
native binary bodies are not rehashed or archived by this publisher.
"""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
TEXT = {'.h', '.hh', '.hpp', '.c', '.cc', '.cpp', '.py', '.mjs', '.json',
        '.txt', '.log', '.xml', '.ps1', '.diff', '.rsp', '.cmd', '.md'}
EXPECTED_HOST = {'tensor_program.cc', 'ggml_cuda_provider.cc',
                 'packed_matmul_bounds_test.cc', 'qwen_mtp_state_consumer_test.cc'}
EXPECTED_CASES = {f'{backend}{model}OriginalNextNAndVocabularyPublishesAndContinues'
                  for backend in ('Cpu', 'Cuda') for model in ('Q27', 'Q24')}
_verified = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def identity(path):
    path = resolve(path)
    # Streaming is also used for the two executable identities. No padded or
    # whole-file byte vector is made, and no original model body is accessed.
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path),
                bytes=path.stat().st_size, sha256=digest)


def verify(row):
    path = resolve(row['path'])
    if path not in _verified:
        _verified[path] = identity(path)
    assert (_verified[path]['bytes'], _verified[path]['sha256']) == (row['bytes'], row['sha256']), row['path']
    return path


def integer(properties, key):
    value = int(properties[key])
    assert value >= 0, (key, value)
    return value


def successful(path):
    result = read(path)
    assert result['exit'] == 0 and result.get('terminal', True)
    assert not result.get('timed_out', False)
    return result


def protect(before):
    verify(before['protected_qwen_image'])
    text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    tail = text[text.index('## 最新完整性能对比'):]
    digest = hashlib.sha256(tail.encode()).hexdigest()
    assert digest == before['protected_performance_tail_sha256']
    return digest


def check_cases(run):
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert run['tests'] == len(run['cases']) == 7
    assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
    assert run['throughput_evidence'] is False and run['physical_memory_evidence'] is False
    assert run['whole_original_model'] is False
    for case in run['cases']:
        assert case['attributes']['status'] == 'run' and case['attributes']['result'] == 'completed'
    cases = [case for case in run['cases'] if case['attributes']['classname'] == 'QwenMtpStateConsumer']
    bounds = [case for case in run['cases'] if case['attributes']['classname'] == 'GgmlCudaPackedBounds']
    assert len(cases) == 4 and len(bounds) == 3
    assert {case['attributes']['name'] for case in cases} == EXPECTED_CASES
    for case in cases:
        props = case['properties']
        for key, expected in dict(packed_head_m2_rows=2, packed_head_m2_matmuls=1,
                packed_head_m2_full_reference_values=496640, packed_head_m2_pending_feedback_rows=2,
                packed_head_m2_submissions=2, logical_nextn_steps=5, complete_draft_resources=6,
                full_vocabulary=248320, original_native_reference_submissions=0).items():
            assert props[key] == str(expected), (case['attributes']['name'], key, props.get(key))
        expected_provider = 'ggml-cuda' if case['attributes']['name'].startswith('Cuda') else 'ggml-cpu'
        assert props['packed_head_m2_provider'] == props['full_head_provider'] == expected_provider
        assert integer(props, 'actual_submissions') > integer(props, 'packed_head_m2_submissions')
    # Descriptor tests perform prepare only; they must not acquire invented Graph counts.
    assert all('actual_submissions' not in case['properties'] for case in bounds)
    counts = {case['attributes']['name']: integer(case['properties'], 'actual_submissions') for case in cases}
    return cases, bounds, counts


def main():
    before = read(S / 'before.json')
    for row in before['previous_publication'].values():
        verify(row)
    protected = protect(before)
    freeze_path = S / 'source-final/freeze.json'
    freeze = read(freeze_path)
    assert freeze['stage'] == 'BW'
    frozen = {}
    for row in freeze['source']:
        source = verify(row)
        snapshot = resolve(row['snapshot'])
        assert identity(snapshot)['sha256'] == row['sha256']
        assert source.is_relative_to(R) and source.suffix.lower() in TEXT
        frozen[source] = row
    assert len(frozen) == 140
    changed = before['source'] + read(S / 'before-extra.json')['files']
    assert len(changed) == 5 and len({row['path'] for row in changed}) == 5
    changes = []
    for old in changed:
        current = frozen[resolve(old['path'])]
        assert old['sha256'] != current['sha256']
        assert identity(old['snapshot'])['sha256'] == old['sha256']
        changes.append(dict(before=old, after=current))
    linkdir = S / 'tests-link1'
    image = read(linkdir / 'ready.json')['image']
    image_path = verify(image)
    successful(linkdir / 'link.result.json')
    link = read(linkdir / 'link-plan.json')
    runtime = read(linkdir / 'runtime-environment.json')
    assert all(link[key] == 0 for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
    input_paths = {resolve(row['path']): row for row in link['inputs']}
    # Link/compile cache records carry native binary identities from the actual
    # build. Check existing extents, not an unnecessary full SDK hash sweep.
    for row in (*link['inputs'], *runtime['staged_dlls']):
        assert resolve(row['path']).stat().st_size == row['bytes']
        assert len(row['sha256']) == 64
    hosts, cached_records = {}, []
    for row in link['compiled_records']:
        record_path = verify(row)
        cached_records.append(record_path)
        record = read(record_path)
        if not record_path.is_relative_to(S / 'compile1'):
            continue
        source = verify(record['source'])
        assert source in frozen
        for dependency in record['dependencies']:
            path = resolve(dependency['path'])
            if path in frozen:
                verify(dependency)
            else:
                assert path.stat().st_size == dependency['bytes']
                assert len(dependency['sha256']) == 64
        object_path = resolve(record['object']['path'])
        assert object_path in input_paths
        assert record['object']['sha256'] == input_paths[object_path]['sha256']
        assert object_path.stat().st_size == record['object']['bytes']
        successful(record_path.with_name('compile.result.json'))
        hosts[source.name] = record_path
    assert set(hosts) == EXPECTED_HOST
    summary_path = S / 'checks1/summary.json'
    run = read(summary_path)
    assert run['image'] == image
    verify(run['image'])
    assert resolve(run['process']['command'][0]) == image_path
    cases, bounds, counts = check_cases(run)
    proof_path = S / 'review/native-small-batch.json'
    proof = read(proof_path)
    assert proof['final_four_source_review']['findings'] == []
    docs = [R / 'docs/developer/current-work.md', R / 'docs/implementation/model-operators.md']
    files = set(frozen) | set(docs) | set(cached_records)
    files.add(verify(before['previous_publication']['evidence']))
    files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in TEXT)
    files.discard(S / 'publication.json')
    for path in files:
        assert path.resolve().is_relative_to(R)
        assert path.suffix.lower() in TEXT and path.stat().st_size < 10_000_000, path
    destination = D / 'mtp-packed-head-m2-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert D.is_dir() and not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(files):
            zipped.write(path, path.relative_to(R).as_posix())
    graph_count = sum(counts.values())
    record = dict(date='2026-10-23', stage='BW', goal_complete=False,
        conclusion='The stated Windows CPU/CUDA Q27/Q24 original consumers passed single-full-packed-M2 head and actual pending-to-embedding feedback; the focused CUDA descriptor bounds also passed.',
        implementation=dict(
            qualification='Provider cold-caches its existing actual device Environment: current non-Orin NVIDIA MMVQ common domain M1..4, Orin M1. The default internal caller remains M1. No model/MTP whitelist, new user configuration or hot device query.',
            bounds='Canonical rank2 recognized GGUF logicalF32 RHS, denseF32 activation/output, K%512, retained signed logical/block/byte/stride limits; new M>1 also requires even N for two-row native reads. Other operand limits remain unchanged.',
            native='Admitted new batches reach fixed MMVQ before MMQ/cuBLAS; one original packed bank is reused, with bounded per-row Q8_1 activation scratch and no full F32 weight expansion. The proof is fixed-source and not an all-device native test.',
            consumers='Two actual M1 normalized-hidden leases are concatenated in an ordinary Graph. One full MatMul reads the original Q27Q6_K or Q24Q4_K head, stable TopK1 yields two separately owned row IDs, and a second ordinary Graph feeds both actual ID leases to the original full embedding. Original six-resource acceptance/continuation and old result leases remain checked.',
            reference='Each listed consumer checks all 2*248320 logits against original bytes and the existing independent actual-F32 activation-codec certificate. No new native reference batches, generated vocabulary or full F32 weight shadow.',
            builds='Four host TUs (two provider implementation TUs and two test TUs), one link, shared cached native inputs. The changed private tensor header is included in frozen compile dependencies. No SDK, CPU worker, NVCC or shader rebuild.'),
        validation=dict(tests=run['tests'], failures=run['failures'], errors=run['errors'], skips=run['skips'],
            graph_submissions=graph_count, graph_submissions_by_case=counts,
            M2_additional_graph_submissions=sum(integer(case['properties'], 'packed_head_m2_submissions') for case in cases),
            M2_full_reference_values_by_case=496640, M2_total_full_reference_values=sum(integer(case['properties'], 'packed_head_m2_full_reference_values') for case in cases),
            actual_native_summary=identity(summary_path), image=image, cases=run['cases'], process=run['process'],
            source_freeze=identity(freeze_path), host_translation_units=len(hosts),
            host_compile_records=[identity(path) for path in hosts.values()],
            linked_input_identity_cache=identity(linkdir / 'link-plan.json'), runtime_identity_cache=identity(linkdir / 'runtime-environment.json'),
            cache_identity_scope='Repository source/dependency snapshots and active executable identities are authenticated here. Reused native inputs and external headers retain recorded build identities with current byte extents; their bodies are not swept or archived.',
            SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0),
        limitations=['Native numeric coverage is the listed Windows CPU/CUDA Q27Q6_K and Q24Q4_K M2 workloads. Descriptor prepare M4 and fixed-source mapped-codec proof are not M4/all-codec/all-GPU numeric execution.',
            'Orin large-packed M2 and larger batches needing MMQ qualification remain unsupported by this narrow admission. Two M1 calls do not close that gap.',
            'Inputs are two actual M1 NextN normalized-hidden results; this does not establish two-token NextN or target equivalence. Actual target blocks/full verifier and finite external target hidden/history remain separate remaining work.',
            'No prompt-to-output trained-model quality, natural acceptance rate, loading/TPS speedup or measured physical memory/VRAM result. Protected AV performance and the Q35 executable remain unchanged.'],
        remaining='Actual Q27/Q24 target/verifier wiring, other confirmed applicable MTP artifact gaps, and final ordinary/MTP performance comparison. Broader goal remains incomplete.',
        changed_sources=changes, sources=[identity(path) for path in sorted(frozen) + docs],
        source_proof=identity(proof_path), reused_publication=before['previous_publication'],
        protected_performance_tail_sha256=protected, protected_qwen_image=before['protected_qwen_image'],
        archive=identity(archive), archive_items=len(files), original_weight_acquisition=False, original_payload_bodies_archived=False)
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert protect(before) == protected
    print(json.dumps(dict(**publication, tests=run['tests'], graphs=graph_count)))


if __name__ == '__main__':
    main()
