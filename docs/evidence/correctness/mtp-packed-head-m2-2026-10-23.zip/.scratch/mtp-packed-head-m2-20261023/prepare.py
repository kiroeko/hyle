from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size, sha256=digest)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


assert not (S / 'before.json').exists()
sources = []
for name in ('src/compute_provider_ggml_cuda/tensor_program.cc',
             'tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc',
             'tests/compute_models/qwen_mtp_state_consumer_test.cc'):
    path = R / name
    raw = path.read_bytes()
    snapshot = S / 'before' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(raw)
    sources.append(dict(**identity(path), snapshot=snapshot.relative_to(R).as_posix()))
assert sources[0]['sha256'] == 'd3f710fa6ee7fc99af3bcb6b9ab9c0c2dbea05e14abca3e967906490e8495238'
text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
previous = json.loads((R / '.scratch/glm-pro-nextn-20261023/publication.json').read_text())
save(S / 'before.json', dict(utc=datetime.now(timezone.utc).isoformat(), stage='BW',
    previous_goal_turn_classification='progress: BV original Pro NextN and affected Flash passed4cases222Graphs, source/evidence/docs published.',
    previous_publication=previous, source=sources,
    protected_performance_tail_sha256=hashlib.sha256(tail.encode()).hexdigest(),
    protected_qwen_image=identity(R / '.scratch/qwen-mtp-next-20261022/hyle-link4/qwen.exe'),
    reuse_base='.scratch/q24-original-nextn-20261023/tests-link3'))
save(S / 'progress.json', dict(stage='BW', stage_complete=False, goal_complete=False,
    state='Checking native small-batch packed safety and extending actual shared-weight full-vocabulary verifier capability.',
    native_checks_run=False, new_TPS=False, scope='Natural bounded packed F32 small-batch MatMul, real Q27/Q24 fullV M2, unchanged generic limits and original codec/readonly banks.',
    next='Prove native algorithm and bounds, edit the affected backend predicate/tests, then incrementally build and execute relevant consumers.'))
print('Prepared BW current source/provenance baseline; no weight acquisition or native run')
