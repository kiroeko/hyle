from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
result = json.loads((S / 'checks1/summary.json').read_text())
assert result['process']['exit'] == 0 and not result['process']['timed_out']
assert result['tests'] == 7 and not any(result[k] for k in ('failures', 'errors', 'disabled', 'skips'))
cases = [case for case in result['cases'] if case['attributes']['classname'] == 'QwenMtpStateConsumer']
assert len(cases) == 4
graphs = sum(int(case['properties']['actual_submissions']) for case in cases)
assert graphs == 38
for case in cases:
    p = case['properties']
    assert p['packed_head_m2_matmuls'] == '1' and p['packed_head_m2_full_reference_values'] == '496640'
    assert p['packed_head_m2_rows'] == '2' and p['packed_head_m2_pending_feedback_rows'] == '2'


def replace_once(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new, 1)


path = R / 'docs/developer/current-work.md'
text = path.read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
before = json.loads((S / 'before.json').read_text())
assert hashlib.sha256(tail.encode()).hexdigest() == before['protected_performance_tail_sha256']
start = text.index('**最近已验证进展：**', text.index('## MTP当前剩项'))
end = text.index('| 模型／制品 |', start)
latest = f'''**最近已验证进展：** [CUDA大packed词表head双行计算](../evidence/correctness/mtp-packed-head-m2-2026-10-23.json)已补后端小批次准入。Q27／Q24各复用同一份原压缩head，以两个实际NextN normalized-hidden租约完成一次M2 MatMul，并将两份实际pending租约直接送入原embedding Gather；CPU／CUDA每项全核496,640个logits，旧M1接受／续算检查保留。7项、{graphs}次Graph，0失败／0跳过；无新权重下载、SDK／NVCC重编或TPS数据。

安全批宽属于Provider冷准备事实：当前非Orin NVIDIA的统一MMVQ域为1～4行，新多行须偶数N；原canonical／K%512／I32索引、encoded字节与stride界不变。Orin保持单行，其M2和更大批次的MMQ资格仍待补，不能由本机结果推断全设备支持。模型消费者无需知道该设备分支；真实target／完整verifier仍按下表推进。

前批[GLM Pro原NextN](../evidence/correctness/mtp-glm-pro-nextn-2026-10-23.json)1571角色、完整576宽缓存／latent512 attention／value256投影、非池化index、原256域Top8及11资源＋Epoch接受后续算已有CPU／CUDA检查；上游target taps与初始历史仍是显式fixture。两批均不代签完整训练模型、任务质量、真实任务接受率或吞吐。

'''
text = text[:start] + latest + text[end:]
text = replace_once(text,
    '实际ID／hidden及六资源同Head接受0／1／2后续算，CPU／CUDA通过 |',
    '实际ID／hidden及六资源同Head接受0／1／2后续算；本轮原head单次M2及真实pending反馈CPU／CUDA通过 |')
text = replace_once(text,
    '六资源接受后续算CPU／CUDA通过 |',
    '六资源接受后续算CPU／CUDA通过；本轮原head单次M2及真实pending反馈也已核 |')
text = replace_once(text,
    '1. 补大packed全词表head的CUDA双行M2准入：保原压缩bank与有界native计算，避免整份F32展开；两次M1不能代替该缺口收尾。\n2. 接Q27末target63和Q24末target91的实际参数、独立target norm及全V verifier。两末层均为完整attention；复用已有词表／head和共同状态机制，上游主干与历史边界明确保留。\n3. 补DeepSeek原target／Pro组合及其它已确认MTP量化接线，不为每种制品复制执行器。\n4. 做必要回归、普通／MTP完整性能对照与实测热点处理，之后进入图片完整链路。',
    '1. 接Q27末target63和Q24末target91的实际参数、独立target norm及全V verifier。两末层均为完整attention；复用已有词表／head、单次M2能力和共同状态机制，上游主干与历史边界明确保留。\n2. 补DeepSeek原target／Pro组合及其它已确认MTP量化接线，不为每种制品复制执行器。\n3. 随接线修专家codec／stride和重复状态组合；Orin／更大批次的packed MMQ能力继续保留为明确剩项。\n4. 做必要回归、普通／MTP完整性能对照与实测热点处理，之后进入图片完整链路。')
old = next(line for line in text.splitlines() if line.startswith('| 3 | MTP |'))
text = replace_once(text, old,
    '| 3 | MTP | 当前优先；列明完整draft／状态及Qwen原全词表单次M2已有CPU／CUDA检查。接Qwen实际target／verifier，再补DeepSeek／已确认量化，最后完整性能对照；详细边界见上表 |')
text = replace_once(text,
    '共用普通Graph执行与MoE几何／供给已从Flash／Pro中提取；下一批先解决大packed head的双行能力边界，再让专家供给按实际codec／stride派生布局，并压缩消费者重复的完整状态接线。',
    '共用普通Graph执行与MoE几何／供给已从Flash／Pro中提取，大packed head的安全批宽也已归Provider冷准备；下一批让专家供给按实际codec／stride派生布局，并压缩消费者重复的完整状态接线。')
assert text[text.index('## 最新完整性能对比'):] == tail
path.write_text(text, encoding='utf-8', newline='\n')

path = R / 'docs/implementation/model-operators.md'
text = path.read_text(encoding='utf-8-sig')
anchor = '## 续算状态与多会话接入'
block = f'''[大packed词表head双行接线](../evidence/correctness/mtp-packed-head-m2-2026-10-23.json)已由Q27／Q24的两个实际normalized-hidden租约构成M2，一次普通MatMul读取同一份完整原Q6_K／Q4_K head；稳定TopK产生的两份独立I32 pending租约直接进入原embedding Gather。四项CPU／CUDA消费者保留原M1接受／状态续算，逐行全核原248320词表，共每项496,640个logits；加3项descriptor边界，共7项{graphs}次Graph，0失败／0跳过。

Provider Context从已有设备Environment冷保存MMVQ保证批宽：非Orin NVIDIA统一1～4、Orin1；新多行要求N为偶数，原canonical布局、K整512、I32逻辑／block索引、encoded字节／stride及其它端口界保留。没有新模型白名单、用户宏、完整F32权重副本或逐token设备查询。Orin大packed M2及更大批次的MMQ资格尚未开启，descriptor M4通过不代签M4数值执行；本批不代表完整target verifier／模型或速度收益。

'''
text = replace_once(text, anchor, block + anchor)
text = replace_once(text,
    '下一步是大packed全词表head的CUDA双行M2、Q27／Q24实际target／verifier、其它已确认量化和最终普通／MTP性能对照。',
    '单次原packed head M2已补列明CPU／CUDA范围；下一步是Q27／Q24实际target／verifier、其它已确认量化和最终普通／MTP性能对照。')
path.write_text(text, encoding='utf-8', newline='\n')
print('Updated current-work and model-operators from actual7cases38Graphs; AV performance unchanged')
