from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[1]
original = (R / '.scratch/large-gguf-head-20261023/build.py').read_text(encoding='utf-8-sig')
text = original.replace('Focused packed single-row CUDA MatMul and full-vocabulary MTP consumers.',
                        'Focused packed small-batch CUDA MatMul and original full-vocabulary consumers.')
text = text.replace("BG = R / '.scratch/qwen-mtp-state-20261023'", "BG = R / '.scratch/q24-original-nextn-20261023'")
text = text.replace("BASE = BG / 'tests-link5'", "BASE = BG / 'tests-link3'")
start = text.index('RECIPES = {')
end = text.index('\n\n\ndef host(', start)
text = text[:start] + '''RECIPES = {
    'tensor-program': R / '.scratch/large-gguf-head-20261023/compile1/tensor-program/identity.json',
    'ggml-provider': R / '.scratch/glm-mtp-seed-cache-20261022/compile6/ggml-provider/identity.json',
    'qwen-state': BG / 'compile3/qwen-state/identity.json',
    'bounds': R / '.scratch/large-gguf-head-20261023/compile2/bounds/identity.json',
}
SOURCES = {
    'tensor-program': R / 'src/compute_provider_ggml_cuda/tensor_program.cc',
    'ggml-provider': R / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'qwen-state': R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc',
    'bounds': R / 'tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc',
}
''' + text[end:]
old = '''        elif c.key(rec['source']['path']) == c.key(str(SOURCES['tensor-program'])):
            replacement[c.key(rec['object']['path'])] = g.latest('tensor-program')[1]['object']'''
new = '''        elif c.key(rec['source']['path']) in {c.key(str(SOURCES[tag])) for tag in ('tensor-program', 'ggml-provider')}:
            tag = next(tag for tag in ('tensor-program', 'ggml-provider')
                if c.key(rec['source']['path']) == c.key(str(SOURCES[tag])))
            replacement[c.key(rec['object']['path'])] = g.latest(tag)[1]['object']'''
assert text.count(old) == 1
text = text.replace(old, new).replace('assert len(replacement) == 1', 'assert len(replacement) == 2')
text = text.replace("product = g.latest('tensor-program')", "products = [g.latest(tag) for tag in ('tensor-program', 'ggml-provider')]")
text = text.replace('(*added, product)', '(*added, *products)')
text = text.replace('packed-head-checks.exe', 'packed-head-small-batch-checks.exe')
text = text.replace("print('LINKED full packed-head checks'", "print('LINKED full packed small-batch head checks'")
text = text.replace('import sys\n', 'import sys\nimport xml.etree.ElementTree as ET\n')
source = (R / '.scratch/q24-original-nextn-20261023/build.py').read_text(encoding='utf-8-sig')
run = source[source.index('def run('):source.index("if __name__ == '__main__':")]
run = run.replace("str(S / 'original-q24-nextn')", "str(R / '.scratch/q24-original-nextn-20261023/original-q24-nextn')")
run = run.replace("print('PASS original Q24 and related Qwen state consumers'", "print('PASS packed small-batch bounds and original Qwen consumers'")
marker = "if __name__ == '__main__':"
assert text.count(marker) == 1
text = text.replace(marker, run + '\n' + marker)
text = text.replace('g.run(args.link_attempt, args.attempt, args.filter, args.expected_tests)',
                    'run(args.link_attempt, args.attempt, args.filter, args.expected_tests)')
assert '(*added, *products)' in text
assert "'ggml-provider': R / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'" in text
(S / 'build.py').write_text(text, encoding='utf-8', newline='\n')
print('Prepared host-only incremental build for2 provider/2 test TUs; cached native/SDK unchanged')
