"""Verify actual BW publication without inferring broader MTP completion."""
from datetime import datetime, timezone
from pathlib import Path
import json
import sys
import zipfile
sys.dont_write_bytecode = True
import publish as p

S, R = p.S, p.R
publication = p.read(S / 'publication.json')
for row in publication.values():
    p.verify(row)
evidence = p.read(p.verify(publication['evidence']))
assert evidence['stage'] == 'BW' and evidence['goal_complete'] is False
validation = evidence['validation']
assert validation['tests'] == 7 and validation['host_translation_units'] == 4
assert not any(validation[key] for key in ('failures', 'errors', 'skips', 'SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
run = p.read(p.verify(validation['actual_native_summary']))
assert run['image'] == validation['image']
p.verify(run['image'])
assert p.resolve(run['process']['command'][0]) == p.resolve(run['image']['path'])
cases, bounds, counts = p.check_cases(run)
assert run['cases'] == validation['cases']
assert counts == validation['graph_submissions_by_case']
assert sum(counts.values()) == validation['graph_submissions']
assert sum(p.integer(case['properties'], 'packed_head_m2_submissions') for case in cases) == validation['M2_additional_graph_submissions']
assert sum(p.integer(case['properties'], 'packed_head_m2_full_reference_values') for case in cases) == validation['M2_total_full_reference_values']
assert len(evidence['changed_sources']) == 5
assert evidence['original_weight_acquisition'] is False and evidence['original_payload_bodies_archived'] is False
with zipfile.ZipFile(p.verify(publication['archive'])) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == evidence['archive_items']
    for item in archive.infolist():
        assert Path(item.filename).suffix.lower() in p.TEXT and item.file_size < 10_000_000
protected = p.protect(p.read(S / 'before.json'))
assert protected == evidence['protected_performance_tail_sha256']
progress = dict(utc=datetime.now(timezone.utc).isoformat(), stage='BW', stage_complete=True, goal_complete=False,
    state='The stated original Q27/Q24 full packed M2 heads and actual pending embedding feedback passed the finite CPU/CUDA checks; focused descriptor bounds passed and durable evidence was published.',
    tests=validation['tests'], graph_submissions=validation['graph_submissions'],
    actual_graph_submissions_by_case=counts, M2_additional_graph_submissions=validation['M2_additional_graph_submissions'],
    failures=0, skips=0, native_checks_run=True, native_process_status='completed_exit0_not_timed_out',
    publication=publication, new_TPS=False, physical_memory_peak=False,
    protected_AV_tail_unchanged=True, protected_Q35_image_unchanged=True,
    scope='Current non-Orin NVIDIA packed MMVQ small-batch admission M1..4, Orin1; M>1 evenN and retained bounds. Listed numeric M2 cases only, not all-GPU/all-codec execution or complete target/verifier/model quality.',
    next='Wire actual Q27/Q24 targets and fullV verifier, continue other confirmed MTP gaps and necessary checks, then final ordinary/MTP performance comparison. Orin M2/larger MMQ qualification remains explicit.')
(S / 'progress.json').write_text(json.dumps(progress, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PUBLISHED BW', validation['tests'], 'cases', validation['graph_submissions'], 'Graphs; broader MTP remains incomplete')
