"""Freeze actual host source/dependencies; no payload bodies or native work."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    path = path.resolve()
    raw = path.read_bytes()
    assert len(raw) < 10_000_000
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


out = S / 'source-final'
assert not out.exists()
paths = {}
for tag in ('tensor-program', 'ggml-provider', 'bounds', 'qwen-state'):
    record = read(S / 'compile1' / tag / 'identity.json')
    for row in (record['source'], *record['dependencies']):
        path = Path(row['path']).resolve()
        if not any(path.is_relative_to(R / prefix) for prefix in ('src', 'include', 'tests')):
            continue
        actual = identity(path)
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), str(path)
        paths[path] = actual
for source in read(S / 'admission-source/freeze.json')['files']:
    assert identity(R / source['path'])['sha256'] == source['sha256']
assert identity(R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc')['sha256'] == '60310884c0e569fbe9f92ff3ef2773690de184297b320061c9ff7c6df9e3f52e'
out.mkdir()
entries = []
for path, row in sorted(paths.items()):
    frozen = out / 'source' / row['path']
    frozen.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_bytes(path.read_bytes())
    entries.append(dict(**row, snapshot=frozen.relative_to(R).as_posix()))
(out / 'freeze.json').write_text(json.dumps(dict(stage='BW', source=entries,
    scope='Actual current host dependencies in repository src/include/tests; original bodies and third-party SDKs excluded.',
    native_run=False, original_weight_acquisition=False), indent=2) + '\n', encoding='utf-8')
print('Frozen', len(entries), 'actual product/test source inputs; no weight payload bodies read')
