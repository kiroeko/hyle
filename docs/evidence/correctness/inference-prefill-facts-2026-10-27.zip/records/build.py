"""Explicit cached two-TU build. Default: describe only; no build or inference."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
B=R/'.scratch/inference-shape-policy-20261027/warmup'
spec=importlib.util.spec_from_file_location('warmup_recipe',B/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
MAIN=R/'engine/models/qwen35/main.cc'
HEADER=R/'engine/inference/prefill_plan.h'
TEST=R/'tests/tools/inference_prefill_plan_test.cc'


def actual_deps(folder,frozen):
    raw=b.read(folder/'dependencies.json')['Data']
    deps=[b.pin(p) for p in dict.fromkeys([raw['Source'],*raw['Includes']])]
    own={b.key(x['path']):x for x in frozen}
    for dep in deps:
        p=Path(dep['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'):
            assert own[b.key(p)]['sha256']==dep['sha256'],str(p)
    b.save(folder/'actual-dependencies.json',deps)
    return b.pin(folder/'actual-dependencies.json')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',nargs='?',choices=['build'])
    for name in ('main','header','test'):parser.add_argument('--'+name+'-sha')
    args=parser.parse_args()
    if args.action is None:
        print('Prepared only: build --main-sha SHA --header-sha SHA --test-sha SHA after parent SOURCE_FROZEN.');return
    assert all((args.main_sha,args.header_sha,args.test_sha)) and not (W/'plan.json').exists()
    for path,expected in ((MAIN,args.main_sha),(HEADER,args.header_sha),(TEST,args.test_sha)):
        assert b.pin(path)['sha256']==expected,str(path)
    baseline=b.read(B/'ready.json');b.exact(baseline['image'])
    assert baseline['image']['sha256']=='a1ba07f344162bc4cdb7907c9dd09b8fcb066ad6049a3655f3d0dbebe6fb9f9f'
    retained=[x for x in b.read(baseline['inputs']['path']) if b.key(x['path'])!=b.key(baseline['object']['path'])]
    assert len(retained)==223
    command=m.command(B/'compile/command.json',MAIN,W/'compile')
    # The original host command is a standard-library-capable /W4 /WX recipe.
    original=b.read(R/'.scratch/inference-working-state-20261026/host/compile/command.json')['command']
    host=[];skip=False
    for x in original:
        if skip:skip=False;continue
        if x=='/sourceDependencies':skip=True;continue
        if x=='/DHYLE_PREFIX_CACHE_STANDALONE' or x.startswith('/Fo') or x.lower().endswith('.cc'):continue
        host.append(x)
    host+=['/I'+str(R),str(TEST),'/sourceDependencies',str(W/'host/compile/dependencies.json'),'/Fo'+str(W/'host/compile/unit.obj')]
    image=W/'image/hyle.exe';link=[];replaced=0
    for x in b.read(B/'link-plan.json')['command']:
        if b.key(x)==b.key(baseline['object']['path']):x=str(W/'compile/unit.obj');replaced+=1
        elif x.upper().startswith('/OUT:'):x='/OUT:'+str(image)
        elif x.upper().startswith('/PDB:'):x='/PDB:'+str(image.with_suffix('.pdb'))
        elif x.upper().startswith('/IMPLIB:'):x='/IMPLIB:'+str(image.with_suffix('.lib'))
        link.append(x)
    assert replaced==1
    host_image=W/'host/image/prefill-plan-test.exe'
    linker=str(Path(command[0]).with_name('link.exe'))
    host_link=[linker,'/NOLOGO','/MACHINE:X64','/OPT:REF','/OPT:ICF','/INCREMENTAL:NO',str(W/'host/compile/unit.obj'),'/SUBSYSTEM:CONSOLE','/OUT:'+str(host_image)]
    for name,cmd,timeout in (('compile',command,180),('link',link,120),('host-compile',host,60),('host-link',host_link,60)):
        b.save(W/(name+'-plan.json'),dict(command=cmd,cwd=str(R),timeout_seconds=timeout))
    frozen=m.c.closure([MAIN,TEST],[W/'compile-plan.json',W/'host-compile-plan.json'])
    b.save(W/'source-freeze.json',frozen)
    b.save(W/'retained-inputs.json',retained)
    for source in (MAIN,HEADER,TEST):(W/source.name).write_bytes(source.read_bytes())
    b.save(W/'plan.json',dict(baseline=b.pin(B/'ready.json'),baseline_image=baseline['image'],
        source=b.pin(MAIN),header=b.pin(HEADER),test=b.pin(TEST),source_freeze=b.pin(W/'source-freeze.json'),
        counts=dict(CXX_TUs=2,Model_TUs=1,standalone_TUs=1,links=2,retained_CLI_inputs=223,SDK=0,NVCC=0,weights=0,report=0,downloads=0),
        runtime_source=baseline['runtime'],scope='Build only; no host test or model execution in this script.'))
    helper=b.helper();env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=helper.execute(command,env,W/'compile',timeout=180)
    deps=actual_deps(W/'compile',frozen)
    host_compiled=helper.execute(host,env,W/'host/compile',timeout=60)
    host_deps=actual_deps(W/'host/compile',frozen)
    for pin in frozen:b.exact(pin)
    for pin in retained:b.exact(pin)
    image.parent.mkdir(parents=True,exist_ok=True);host_image.parent.mkdir(parents=True,exist_ok=True)
    linked=helper.execute(link,env,W/'link',timeout=120)
    host_linked=helper.execute(host_link,env,W/'host/link',timeout=60)
    b.save(W/'link-inputs.json',retained+[b.pin(W/'compile/unit.obj')])
    runtime=b.read(baseline['runtime']['path']);native=runtime['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_cpu_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH']
    b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',source=b.pin(MAIN),header=b.pin(HEADER),test=b.pin(TEST),
        image=b.pin(image),object=b.pin(W/'compile/unit.obj'),actual_dependencies=deps,compile=compiled,link=linked,
        inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),
        standalone=dict(image=b.pin(host_image),compile=host_compiled,link=host_linked,actual_dependencies=host_deps)))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)


if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'build-failure.json',dict(error=traceback.format_exc(),note='First failure retained; no automatic retry'))
        raise
