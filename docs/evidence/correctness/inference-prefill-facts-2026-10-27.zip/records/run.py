"""One standalone process and one ordinary planned Q2/B2 journey; default no run."""
from pathlib import Path
import importlib.util
import json
import re
import sys
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
B=R/'.scratch/inference-shape-policy-20261027/warmup'
spec=importlib.util.spec_from_file_location('prefill_facts_build',W/'build.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
b=build.b
spec=importlib.util.spec_from_file_location('retained_warmup_checks',B/'run.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)


def main():
    if sys.argv[1:]!=['run']:
        print('Prepared only: run after SOURCE_FROZEN and successful build.');return
    assert not (W/'run-plan.json').exists()
    ready=b.read(W/'ready.json')
    for x in (ready['image'],ready['source'],ready['header'],ready['test'],ready['standalone']['image']):b.exact(x)
    baseline_ready=b.read(B/'ready.json');b.exact(baseline_ready['image'])
    base=next(x for x in b.read(B/'run-plan.json')['cases'] if x['name']=='planned')
    command=list(base['command']);assert command[0]==baseline_ready['image']['path'];command[0]=ready['image']['path']
    control=B/'runs/planned/report.json'
    b.save(W/'run-plan.json',dict(image=ready['image'],source=ready['source'],standalone=ready['standalone']['image'],
        command=command,control=b.pin(control),original_command=b.pin(B/'run-plan.json'),
        expected_turns=base['expected_turns'],scope='One stdlib host test process plus one original Q2/B2 planned CUDA process. Baseline observed report reused, no baseline or MTP run.'))
    helper=b.helper();cl=b.read(W/'compile-plan.json')['command'][0]
    env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    env['PATH']=b.read(ready['runtime']['path'])['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    host=helper.execute([ready['standalone']['image']['path']],env,W/'host/run1',timeout=30)
    assert '4 host contract groups passed' in (W/'host/run1/stdout.log').read_text(encoding='utf-8-sig')
    process=helper.execute(command,env,W/'cli/run1',timeout=90)
    report=json.loads((W/'cli/run1/stdout.log').read_text(encoding='utf-8-sig'));b.save(W/'cli/run1/report.json',report)
    facts=old.prior.check_regular(report,dict(base,name='b2-multiturn'))
    normalizer,normalizer_pin=old.normalize_functions()
    differences=normalizer['differences'](normalizer['normalize'](b.read(control)),normalizer['normalize'](report))
    b.save(W/'nontime-differences.json',differences);assert not differences,'Complete non-clock report changed'
    lines=(W/'cli/run1/stderr.log').read_text(encoding='utf-8-sig').splitlines()
    ready_at=next(i for i,x in enumerate(lines) if x.startswith('generation_shape_prepare_seconds='))
    first=next(i for i,x in enumerate(lines) if x.startswith('generation_session '))
    warm=[(i,re.search(r'^shape_warmup policy=planned shapes=(\d+) seconds=',x)) for i,x in enumerate(lines) if x.startswith('shape_warmup ')]
    assert len(warm)==1 and warm[0][1] and warm[0][0]<ready_at<first
    assert int(warm[0][1][1])==6 and not any(x.startswith('compiled T=') for x in lines[ready_at+1:])
    b.save(W/'summary.json',dict(status='HOST_FOUR_AND_PLANNED_Q2_B2_PASS',source=ready['source'],header=ready['header'],test=ready['test'],
        image=ready['image'],standalone_process=host,CLI_process=process,ledger=facts,eligible_planned_shapes=6,
        complete_nontime_report_differences=0,control=b.pin(control),normalizer=normalizer_pin,
        counts=dict(CXX_TUs=2,links=2,host_processes=1,host_groups=4,CUDA_model_processes=1,baseline_reruns=0,MTP_reruns=0,SDK=0,NVCC=0,downloads=0),
        scope='Shared prefill partition facts and unchanged ordinary planned Q2/B2 behavior only. No quality, performance, capture warmup, varlen, full model or all-platform claim.'))
    print('PASS',json.dumps(b.pin(W/'summary.json')),flush=True)


if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'run-failure.json',dict(error=traceback.format_exc(),note='First failure retained; no automatic retry'))
        raise
