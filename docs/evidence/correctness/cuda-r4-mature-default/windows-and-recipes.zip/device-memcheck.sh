#!/usr/bin/env bash
set -euo pipefail
r4_root=/root/hyle-validation/r4-cuda-sgl-f7d14870
mkdir -p "$r4_root/logs/device-memcheck"
for r4_exe in hyle_compute_provider_cuda_test hyle_compute_route_cuda_test hyle_graph_route_cuda_test; do
  timeout 180 /usr/local/cuda-13.3/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 \
    "$r4_root/build-off/bin/$r4_exe" > "$r4_root/logs/device-memcheck/$r4_exe.log" 2>&1
  tail -n 7 "$r4_root/logs/device-memcheck/$r4_exe.log"
done
