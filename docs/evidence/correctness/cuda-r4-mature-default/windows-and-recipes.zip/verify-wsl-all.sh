#!/usr/bin/env bash
set -euo pipefail
sgl_root=/root/hyle-validation/r4-cuda-sgl-f7d14870
cd "$sgl_root"
for sgl_mode in off asan ubsan tsan; do
  bash verify-host-wsl.sh "$sgl_mode"
done
python3 - <<'PY'
from pathlib import Path
import re
p=Path('logs/asan/tests.log')
text=p.read_text()
rows=re.findall(r'^\d+:\s+(\d+)\s+(\d+)\s+libcuda\.so\.1\s*$',text,re.M)
assert len(rows)==3,rows
assert all(row==('2','280') for row in rows),rows
assert '100% tests passed, 0 tests failed out of 6' in text
print('ASan exact existing external-driver exception: 3 executables x 2 allocations/280 bytes; all other leaks remain visible')
PY
bash device-memcheck.sh
bash verify-wsl.sh
for sgl_linkage in shared static; do
  python3 check-cuda-sdk.py "$sgl_root/sdk-$sgl_linkage-relocated" "$sgl_root/source" "$sgl_root/logs/$sgl_linkage/sdk-projection.json"
done
printf '%s\n' 'WSL CUDA kernel/routes, host/device checks and three C++ deliveries PASS'
