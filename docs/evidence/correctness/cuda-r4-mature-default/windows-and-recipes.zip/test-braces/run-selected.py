import ctypes
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

repo = Path('C:/public/project-hyle/hyle')
task = Path('C:/hyle-scratch/r4-cuda-20260916/mature-rule/test-braces')
ctypes.windll.kernel32.SetErrorMode(0x8003)
os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] = '2'
os.environ['CTEST_PARALLEL_LEVEL'] = '1'
os.environ['CTEST_INTERACTIVE_DEBUG_MODE'] = '0'
spec = importlib.util.spec_from_file_location('hyle_selector', repo / 'scripts/validation-select.py')
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
context = repo / '.scratch/validation/windows-msvc-context.json'
candidate = '755fb7c76132908e15cc8e2c298c69c227af775a'
cache = task / 'selected-receipts'
scratch_base = Path('C:/hvt4')
plan = selector.make_plan(repo, 'f7d14870', candidate, context=context, cache=cache)
assert plan['verdict'] != 'BLOCKED', plan
identity = selector.environment_identity(context, native=True)
scratch = scratch_base / selector.digest({'tree': plan['candidate_tree'], 'context': identity})[:20]
build = scratch / ('build-' + selector.digest({'tree': plan['candidate_tree'], 'context': identity, 'factors': plan['selected_factors']})[:20])
for gate in plan['gates']:
    for command in gate['commands']:
        for arg in command:
            if arg.startswith('-DHYLE_SMOKE_ROOT='):
                target = Path(arg.split('=',1)[1].replace('{scratch}',str(scratch))).resolve()
                target.relative_to(scratch_base.resolve())
                assert target != scratch_base.resolve(), target
build_bin = build / 'bin'
build_bin.mkdir(parents=True, exist_ok=True)
dlls = [Path('C:/Windows/System32') / name for name in ('msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll')]
dlls += [Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64') / name for name in ('cudart64_13.dll','cublasLt64_13.dll')]
for dll in dlls:
    shutil.copyfile(dll, build_bin / dll.name)
(task/'logs/selected-paths.json').write_text(json.dumps({'candidate': candidate,'scratch':str(scratch),'build':str(build),'context':str(context),'DLLs':[str(p) for p in dlls]},indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'Exact selected native gates: {build}; actual CUDA/CRT DLLs staged before tests',flush=True)
selector.execute(repo, plan, cache, scratch_base, context=context)
selector.write_json(task/'logs/selected-result.json', selector.public_report(plan))
print(f'Selected gates verdict: {plan["verdict"]}',flush=True)
sys.exit(0 if plan['verdict']=='PASS' else 2)
