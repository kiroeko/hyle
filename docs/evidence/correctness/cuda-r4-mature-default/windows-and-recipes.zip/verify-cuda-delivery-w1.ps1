$ErrorActionPreference = 'Stop'
$sglRoot = 'C:/hyle-scratch/r4-cuda-20260916/mature-rule'
$sglSource = 'C:/public/project-hyle/hyle'
Set-Location $sglSource
if ((git rev-parse HEAD) -ne '755fb7c76132908e15cc8e2c298c69c227af775a') { throw 'Candidate changed' }
if (git status --porcelain) { throw 'Candidate worktree is not clean' }
foreach ($sglScript in @('source-w1.ps1', 'packages-w1.ps1')) {
  & pwsh -NoProfile -File "$sglRoot/$sglScript"
  if ($LASTEXITCODE -ne 0) { throw "$sglScript failed; retain evidence and stop" }
}
foreach ($sglLinkage in @('shared', 'static')) {
  python "$sglRoot/check-cuda-sdk.py" "$sglRoot/w1-sdk-$sglLinkage-relocated" $sglSource "$sglRoot/logs/w1-$sglLinkage/sdk-projection.json"
  if ($LASTEXITCODE -ne 0) { throw "$sglLinkage SDK projection failed" }
}
Write-Output 'CUDA-only source/static/shared actual FFN, relocation and exact LICENSE/NOTICE checks PASS'
