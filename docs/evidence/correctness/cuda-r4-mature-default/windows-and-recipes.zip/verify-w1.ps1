$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$sglRoot = 'C:/hyle-scratch/r4-cuda-20260916/mature-rule'
$sglBuild = 'C:/hv4s1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
& scripts/hyle-windows.ps1 -Action Configure -Preset windows-ninja -BinaryDir $sglBuild -Factor 'compute_provider_cuda;compute_route_cuda;graph_route_cuda' -DependencySourceCache C:/public/project-hyle/.deps -ExtraArgs @('-DHYLE_COMPUTE_CUDA=ON','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_ONEDNN=OFF','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF') *> "$sglRoot/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$sglRoot/configure.log" -Tail 50; exit $LASTEXITCODE }
& scripts/hyle-windows.ps1 -Action Build -Preset windows-ninja -BinaryDir $sglBuild -ExtraArgs @('--target','hyle_compute_provider_cuda_tests','hyle_compute_route_cuda_tests','hyle_graph_route_cuda_tests','--parallel','2') *> "$sglRoot/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$sglRoot/build.log" -Tail 70; exit $LASTEXITCODE }
$sglDlls = @('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cudart64_13.dll','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cublasLt64_13.dll','C:/Windows/System32/msvcp140.dll','C:/Windows/System32/msvcp140_atomic_wait.dll','C:/Windows/System32/vcruntime140.dll','C:/Windows/System32/vcruntime140_1.dll')
$sglExecutables = Get-ChildItem -LiteralPath "$sglBuild/bin" -Filter '*cuda_test.exe'
foreach ($sglExecutable in $sglExecutables) {
 foreach ($sglDll in $sglDlls) { Copy-Item -LiteralPath $sglDll -Destination $sglExecutable.DirectoryName -Force }
}
$sglDlls | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$sglRoot/runtime.json" -Encoding utf8
ctest --test-dir $sglBuild -C Release --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 -R '^hyle_(compute_provider_cuda|compute_route_cuda|graph_route_cuda)(_header_self_contained)?_test$' *> "$sglRoot/test.log"
$sglVerdict = $LASTEXITCODE
Copy-Item -LiteralPath "$sglBuild/Testing/Temporary/LastTest.log" -Destination "$sglRoot/LastTest.log"
Get-Content "$sglRoot/test.log" -Tail 90
exit $sglVerdict
