$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_PARALLEL_LEVEL = '1'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$r4BenchRoot = 'C:/hyle-scratch/r4-cuda-20260916/mature-rule/bench'
New-Item -ItemType Directory -Force -Path $r4BenchRoot | Out-Null
& cmake -S C:/public/project-hyle/hyle -B C:/hv4s2 -G Ninja `
    -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=ON -DHYLE_INSTALL=OFF `
    -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_ONEDNN=OFF `
    -DHYLE_DEV_FACTORS=graph_route_cuda -DHYLE_BUILD_BENCH=ON `
    -DHYLE_BUILD_TESTS=OFF -DHYLE_WERROR=ON -DHYLE_SANITIZER=off `
    -DHYLE_TEST_INSTRUMENTATION=OFF *> "$r4BenchRoot/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r4BenchRoot/configure.log" -Tail 50; throw 'CUDA bench configure failed' }
& cmake --build C:/hv4s2 --parallel 2 --target hyle_compute_route_cuda_bench hyle_compute_route_cuda_bench_placement hyle_graph_route_cuda_bench hyle_graph_route_cuda_bench_placement hyle_compute_cuda_native_cost_bench hyle_graph_cuda_native_cost_bench *> "$r4BenchRoot/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r4BenchRoot/build.log" -Tail 65; throw 'CUDA bench build failed' }
$r4CudaBin = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64'
foreach ($r4Dll in @('cudart64_13.dll', 'cublasLt64_13.dll')) {
    Copy-Item -LiteralPath "$r4CudaBin/$r4Dll" -Destination C:/hv4s2/bin -Force
}
foreach ($r4Dll in @('msvcp140.dll', 'msvcp140_atomic_wait.dll', 'vcruntime140.dll', 'vcruntime140_1.dll')) {
    Copy-Item -LiteralPath "C:/Windows/System32/$r4Dll" -Destination C:/hv4s2/bin -Force
}
Write-Output 'Six benchmark executables built; actual CUDA/CRT DLLs staged. No timing or oracle run by this script.'
