#!/usr/bin/env bash
set -euo pipefail
r4_root=/root/hyle-validation/r4-cuda-sgl-f7d14870
r4_source="$r4_root/source"
r4_build="$r4_root/source-shared"
r4_harness="$r4_root/consumer"
export PATH="/usr/local/cuda-13.3/bin:$PATH"
cd "$r4_source"
run() {
 local name=$1
 shift
 if ! "$@" >"$r4_logs/$name" 2>&1; then tail -n 90 "$r4_logs/$name"; return 1; fi
}
cmake_run() { bash scripts/hyle-unix.sh /usr/bin/cmake "$@"; }
r4_logs="$r4_root/logs/source"
mkdir -p "$r4_logs"
nvidia-smi >"$r4_logs/nvidia-smi.txt"
nvcc --version >"$r4_logs/nvcc.txt"
run configure.log cmake_run -S "$r4_harness" -B "$r4_build" -G Ninja -DCMAKE_BUILD_TYPE=Release  "-DHYLE_SOURCE_DIR=$r4_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r4_source"  -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_ONEDNN=AUTO  -DHYLE_BUILD_TESTS=OFF -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=ON -DHYLE_STATIC=OFF  -DHYLE_WERROR=ON -DHYLE_TEST_INSTRUMENTATION=OFF -DCMAKE_POSITION_INDEPENDENT_CODE=ON
run build.log cmake --build "$r4_build" --parallel 2
run tests.log ctest --test-dir "$r4_build" --output-on-failure --no-tests=error --timeout 120 -j 1
cp "$r4_build/Testing/Temporary/LastTest.log" "$r4_logs/LastTest.log"
tail -n 15 "$r4_logs/tests.log"
for linkage in shared static; do
 r4_logs="$r4_root/logs/$linkage"
 mkdir -p "$r4_logs"
 if [ "$linkage" = static ]; then
  run configure.log cmake_run -S "$r4_harness" -B "$r4_build" -DHYLE_STATIC=ON -DBUILD_SHARED_LIBS=OFF
  run build.log cmake --build "$r4_build" --parallel 2
 fi
 r4_stage="$r4_root/sdk-$linkage"
 r4_sdk="$r4_root/sdk-$linkage-relocated"
 test ! -e "$r4_stage"
 test ! -e "$r4_sdk"
 run install.log cmake --install "$r4_build" --prefix "$r4_stage"
 mv "$r4_stage" "$r4_sdk"
 r4_consumer="$r4_root/consume-$linkage"
 run consumer-configure.log cmake_run -S "$r4_harness" -B "$r4_consumer" -G Ninja -DCMAKE_BUILD_TYPE=Release   "-DCMAKE_PREFIX_PATH=$r4_sdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$r4_source"
 run consumer-build.log cmake --build "$r4_consumer" --parallel 2
 run consumer-tests.log ctest --test-dir "$r4_consumer" --output-on-failure --no-tests=error --timeout 120 -j 1
 cp "$r4_consumer/Testing/Temporary/LastTest.log" "$r4_logs/LastTest.log"
 cp "$r4_build/CMakeCache.txt" "$r4_logs/CMakeCache.txt"
 find "$r4_sdk" -type f | sort >"$r4_logs/installed-files.txt"
 tail -n 15 "$r4_logs/consumer-tests.log"
done
