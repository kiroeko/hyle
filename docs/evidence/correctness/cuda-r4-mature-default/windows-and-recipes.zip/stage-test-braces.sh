#!/usr/bin/env bash
set -euo pipefail
sgl_root=/root/hyle-validation/r4-cuda-sgl-f7d14870
sgl_windows=/mnt/c/hyle-scratch/r4-cuda-20260916/mature-rule
test ! -e "$sgl_root/logs/off/build-initial-f7d14870-failed.log"
cp "$sgl_root/logs/off/build.log" "$sgl_root/logs/off/build-initial-f7d14870-failed.log"
printf '%s  %s\n' 05163c090ea9637d023883354d1dd0942b38d4e8599a0619a5df8f786e40ccda "$sgl_windows/test-braces-755fb7c7.tar" | sha256sum -c -
tar -xf "$sgl_windows/test-braces-755fb7c7.tar" -C "$sgl_root/source"
cp "$sgl_windows/test-braces-source-identity.json" "$sgl_windows/candidate.txt" "$sgl_root/"
