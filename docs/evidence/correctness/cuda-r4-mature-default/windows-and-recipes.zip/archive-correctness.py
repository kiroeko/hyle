from pathlib import Path
import hashlib
import json
import shutil
import zipfile

scratch = Path('C:/hyle-scratch/r4-cuda-20260916/mature-rule')
root = Path('C:/public/project-hyle/hyle')
out = root / 'evidence/correctness/cuda-r4-mature-default'
out.mkdir(exist_ok=True)

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

files = set()
for pattern in ('*.ps1', '*.py', '*.sh', '*.supp'):
    files.update(scratch.glob(pattern))
for name in ('configure.log', 'build.log', 'test.log', 'LastTest.log', 'runtime.json',
             'build-cpu-budget.json', 'validation-process-tree.json', 'product-plan.json',
             'test-braces-plan.json', 'test-braces-source-identity.json'):
    files.add(scratch / name)
for name in ('logs', 'consumer', 'projection', 'test-braces/logs', 'test-braces/selected-receipts'):
    files.update(p for p in (scratch / name).rglob('*') if p.is_file())
files.add(scratch / 'test-braces/run-selected.py')
with zipfile.ZipFile(out / 'windows-and-recipes.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):
        z.write(p, p.relative_to(scratch).as_posix())
for name in ('wsl-raw.tar.gz', 'mac-air-raw.tar.gz', 'mac-mini-raw.tar.gz',
             'selected-validation-raw.zip', 'selected-validation-summary.json',
             'source-identity.json', 'test-braces-source-identity.json'):
    shutil.copy2(scratch / name, out / name)
shutil.copy2(scratch / 'loc-f7d14870.json', out / 'loc.json')
write(out / 'summary.json', {
    'candidate': '755fb7c76132908e15cc8e2c298c69c227af775a',
    'tree': '5f91d6d548e6e59406adcdc683c67ee473e59f4b',
    'ordinary_base': 'f7d14870fc7066dad5092b7b5200d49ba0581a25',
    'base_to_candidate': 'Only GCC-warning hygiene braces in one Graph test; product unchanged.',
    'full_selector': {'pass': 106, 'skipped': 5},
    'incremental_test_selector': {'pass': 4, 'skipped': 106},
    'windows_targeted': {'pass': 6},
    'windows_cuda_only_delivery': {'source': '2/2 PASS', 'shared_relocated': '2/2 PASS', 'static_relocated': '2/2 PASS', 'dependency_and_license_projection': 'PASS', 'dll_policy': 'physically staged beside executables'},
    'wsl': {'off': '6/6 PASS', 'asan': '6/6 PASS with registered exact libcuda leak exception', 'ubsan': '6/6 PASS', 'tsan': '6/6 PASS', 'device_memcheck': 'provider 6, Direct 3, Graph 4 cases; 0 errors and 0 device leaks', 'delivery': 'source/shared/static each 2/2 PASS; relocation, dependency and license projection PASS'},
    'mac_air_cuda_off': {'public_consumers': '2/2 PASS', 'none_cpu_core_projection': 'PASS'},
    'mac_mini_cuda_off': {'public_consumers': '2/2 PASS', 'none_cpu_core_projection': 'PASS'},
    'performance': 'Final-default P1 and native boundary diagnostic pending; no performance verdict in this bundle.',
})
write(out / 'sha256.json', {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name not in ('sha256.json', 'README.md')})
print(json.dumps({'archive_files': len(files), 'evidence_bytes': sum(p.stat().st_size for p in out.iterdir())}))
