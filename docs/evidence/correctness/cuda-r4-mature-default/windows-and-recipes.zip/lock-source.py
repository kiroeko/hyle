from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

repo = Path('C:/public/project-hyle/hyle')
scratch = Path(__file__).parent
pin = '06992c92ad4494fe9f9636e75be3e35040512447'
target = repo / 'third_party/sglang_activation'
provenance = json.loads((target / 'provenance.json').read_text())
archive = scratch / 'sglang-06992c92.tar.gz'
archive_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive_sha == 'e31827d3f8ef3ae171da08242c2f249110c763cab8d89603dc4c6c57076c3796'
with tarfile.open(archive, 'r:gz') as package:
    for relative, expected in provenance['files'].items():
        raw = package.extractfile('sglang-' + pin + '/' + relative).read()
        assert hashlib.sha256(raw).hexdigest() == expected, relative
def sha(path):
    return hashlib.sha256(path.read_bytes().replace(b'\r\n', b'\n')).hexdigest()
manifest = ''.join(p.relative_to(target).as_posix() + '|' + sha(p) + '\n'
                   for p in sorted(target.rglob('*')) if p.is_file())
tree = hashlib.sha256(manifest.encode()).hexdigest()
path = repo / 'cmake/HyleDependencyLock.json'
lock = json.loads(path.read_text(encoding='utf-8'))
assert all(row['name'] != 'sglang_activation' for row in lock['dependencies'])
lock['dependencies'].append({
    'name': 'sglang_activation', 'class': 'in_tree',
    'repository': 'https://github.com/sgl-project/sglang.git',
    'version': 'sglang-snapshot-06992c92ad44', 'revision': pin,
    'git_tree': '6504cefc56f2b228800eb72a513420e956e21846',
    'archive': {'url': 'https://codeload.github.com/sgl-project/sglang/tar.gz/' + pin,
                'sha256': archive_sha},
    'vendored': {'path': 'third_party/sglang_activation', 'tree_sha256': tree},
    'license': {'expression': 'Apache-2.0', 'files': [
        {'root': 'hyle', 'path': 'third_party/sglang_activation/' + name, 'sha256': sha(target / name)}
        for name in ('LICENSE', 'NOTICE')]}})
path.write_text(json.dumps(lock, indent=2) + '\n', encoding='utf-8', newline='\n')
(scratch / 'source-identity.json').write_text(json.dumps({'upstream_archive_sha256': archive_sha,
    'git_tree': lock['dependencies'][-1]['git_tree'], 'adapted_tree_sha256': tree,
    'archive_blobs_match_git': True, 'upstream_files': provenance['files']}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'archive': archive_sha, 'adapted_tree': tree, 'archive_blobs_match_git': True}))
