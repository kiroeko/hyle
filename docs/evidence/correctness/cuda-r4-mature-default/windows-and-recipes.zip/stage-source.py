from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

repo = Path('C:/public/project-hyle/hyle')
peer = Path('C:/public/project-hyle/sglang')
pin = '06992c92ad4494fe9f9636e75be3e35040512447'
namespace = 'hyle::compute::cuda_native::sglang_vendor'
target = repo / 'third_party/sglang_activation'
target.mkdir(parents=True, exist_ok=True)
def write(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')
def blob(path):
    return subprocess.check_output(['git', 'show', pin + ':' + path], cwd=peer)
source_path = 'python/sglang/kernels/jit/csrc/elementwise/activation.cuh'
original = blob(source_path).decode('utf-8')
fragment = original[original.index('namespace sglang {'):original.index('struct UnaryActivationParams {')]
fragment = fragment.replace('namespace sglang {', 'namespace ' + namespace + ' {').replace('SGL_DEVICE', 'HYLE_SGL_DEVICE')
write(target / 'activation.cuh', '// SGLang Apache-2.0 device fragment at ' + pin + '.\n'
      '// Arithmetic/indexing retained; namespace and support macro isolated.\n'
      '// See LICENSE, NOTICE and provenance.json.\n#pragma once\n\n'
      '#include "sglang_device_compat.cuh"\n\n' + fragment + '\n} // namespace ' + namespace + '\n\n#undef HYLE_SGL_DEVICE\n')
compat = (repo / 'bench/compute_route_cuda/reference/sglang_device_compat.cuh').read_text(encoding='utf-8')
compat = compat.replace('namespace sglang {', 'namespace ' + namespace + ' {').replace('// namespace sglang', '// namespace ' + namespace)
compat = compat.replace('SGL_DEVICE', 'HYLE_SGL_DEVICE').replace('SM89 reference does not use PDL', 'precise CUDA activation does not use PDL')
write(repo / 'src/compute_provider_cuda/sglang_device_compat.cuh', compat)
write(target / 'LICENSE', blob('LICENSE').decode('utf-8'))
write(target / 'NOTICE', 'This distribution contains a narrow SGLang device-kernel fragment.\n'
      'Origin: https://github.com/sgl-project/sglang\nRevision: ' + pin + '\n'
      'Licensed under Apache-2.0; see LICENSE. HYLE adaptations isolate the\n'
      'namespace and support macro and omit unrelated host glue. The original\n'
      'activation arithmetic and packed indexing are retained.\n')
write(target / 'README.md', '# Pinned precise SGLang activation\n\n'
      'Origin: SGLang `' + pin + '`, Apache-2.0.\n'
      '`provenance.json` records the exact upstream Git blobs and adaptations.\n'
      '`cmake/HyleDependencyLock.json` binds the official archive and this adapted tree.\n\n'
      'The owning adapter is `src/compute_provider_cuda`; its standalone device\n'
      'compatibility code remains in HYLE implementation sources. Only packed\n'
      'SiLU-times-value, FP16/FP32, 16-byte vectors, PDL/filter/reuse disabled,\n'
      'and FP32 activation/multiply followed by one output conversion are admitted.\n'
      'No fast-math is enabled. Uninstantiated upstream enum/template branches\n'
      'do not expose additional HYLE operations. TVM/Python runtime is excluded.\n\n'
      'HYLE maintains this narrow source adapter. Upgrades require review of\n'
      'arithmetic, indexing, flags, vector eligibility, namespace isolation and\n'
      'the host ABI together; renew blob/archive/tree hashes, oracle and boundary\n'
      'tests, native lifetime/capture, three C++ deliveries and applicable complete\n'
      'consumer performance. Replacing this directory alone is not an upgrade.\n')
paths = [source_path, 'python/sglang/kernels/ops/activation/activation.py',
         'python/sglang/kernels/jit/utils/arch.py', 'LICENSE']
files = {path: hashlib.sha256(blob(path)).hexdigest() for path in paths}
write(target / 'provenance.json', json.dumps({
    'repository': 'https://github.com/sgl-project/sglang.git', 'revision': pin,
    'files': files, 'hash_semantics': 'SHA-256 of the original upstream Git blob',
    'adaptations': ['Extract ActivationKind, FP32 activation and packed act_and_mul device body; omit TVM/Python host and unary wrapper.',
       'Replace global sglang namespace with ' + namespace + ' to isolate the independent benchmark reference.',
       'Rename SGL_DEVICE to HYLE_SGL_DEVICE; undefine the private support macro after the fragment.',
       'HYLE standalone vector/cast/disabled-PDL support lives in src/compute_provider_cuda/sglang_device_compat.cuh; arithmetic and indexing are unchanged.'],
    'configuration': {'fast_math': False, 'pdl': False, 'filter_expert': False,
                      'round_activation': False, 'reuse_input': False, 'vector_bytes': 16},
    'qualification': 'R4 W1 SM89 full FFN v2 evidence; final default integration acceptance remains in the owning task.'}, indent=2) + '\n')
print(json.dumps({'upstream': files, 'staged': str(target)}))
