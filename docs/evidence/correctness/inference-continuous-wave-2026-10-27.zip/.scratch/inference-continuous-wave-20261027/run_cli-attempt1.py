from pathlib import Path
import importlib.util, json, sys, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('continuous_build', W / 'check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
OLD = W.parent / 'inference-wave-ownership-20261027'


def facts(value):
    if isinstance(value, list): return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k: facts(v) for k, v in value.items()
                if not any(x in k for x in ('seconds', 'per_second', 'capture', 'replay', 'trace_name'))}
    return value


def run(name):
    ready = b.read(W / 'ready-model.json'); b.exact(ready['image'])
    for row in b.read(W / 'source-freeze-model.json'): b.exact(row['original']); b.exact(row['snapshot'])
    row = next(r for r in b.read(OLD / 'build-plan.json')['planned_runs'] if r['name'] == name)
    b.exact(row['fixture_manifest'])
    out = W / 'runs' / name
    assert not out.exists(), 'Preserve every actual attempt'
    process = b.h.execute([ready['image']['path'], *row['args']], b.environment(), out, timeout=180)
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    b.save(out / 'report.json', report)
    reference = OLD / 'runs' / name / 'report.json'
    actual = facts(report); expected = facts(b.read(reference))
    if actual != expected:
        keys = sorted(k for k in set(actual) | set(expected) if actual.get(k) != expected.get(k))
        b.save(out / 'comparison-failure.json', dict(keys=keys, reference=b.pin(reference)))
        raise AssertionError(('Complete non-time report changed', keys))
    assert report['live_committed_versions'] == 0
    result = dict(status='PASS', process=process, ready=b.pin(W / 'ready-model.json'),
                  original=b.pin(reference), report=b.pin(out / 'report.json'),
                  complete_non_time_report_equal=True, generated_tokens=report['generated_tokens'],
                  actual_graph_calls=report['actual_graph_calls'])
    b.save(out / 'summary.json', result)
    print('PASS', name, process['pid'], flush=True)


if __name__ == '__main__':
    try: run(sys.argv[1])
    except BaseException:
        (W / ('failure-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
