from pathlib import Path
import importlib.util, json, sys, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('continuous_probe_build', W / 'check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)


def run():
    ready = b.read(W / 'ready-probe.json'); b.exact(ready['image'])
    for row in b.read(W / 'source-freeze-probe.json'): b.exact(row['original']); b.exact(row['snapshot'])
    folder = W / 'inputs/context32'; fixture = b.read(W / 'fixture.json')
    assert b.pin(folder / 'weights.tsv')['sha256'] == fixture['prepared_sha256']
    output = W / 'runs/continuous-controls'
    assert not output.exists(), 'Preserve every actual attempt'
    process = b.h.execute([ready['image']['path'], '--cuda-continuous', str(folder)], b.environment(), output, timeout=180)
    result = json.loads((output / 'stdout.log').read_text(encoding='utf-8-sig'))
    b.save(output / 'report.json', result)
    assert result['status'] == 'PASS' and result['control_and_candidate_arms'] == 10
    assert result['complete_prefix_state_epoch_rng_equal'] and result['all_source_session_page_owners_retired']
    b.save(output / 'summary.json', dict(status='PASS', process=process, ready=b.pin(W / 'ready-probe.json'),
        report=b.pin(output / 'report.json'), fixture=b.pin(W / 'fixture.json'), throughput_claim=False))
    print('PASS ten finite CUDA arms pid=' + str(process['pid']), flush=True)


if __name__ == '__main__':
    try: run()
    except BaseException:
        (W / 'failure-continuous-controls.log').write_text(traceback.format_exc(), encoding='utf-8')
        raise
