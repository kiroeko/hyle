from pathlib import Path
import hashlib, json
W = Path(__file__).resolve().parent
original = W.parent / 'inference-paged-frame-20261026/tiny-recursive-input'
folder = W / 'inputs/context32'
assert not folder.exists(), 'Preserve explicitly prepared fixtures'
manifest = (original / 'weights.tsv').read_bytes()
lines = manifest.decode('utf-8-sig').splitlines()
geometry = lines[2].split(); assert geometry[0] == 'geometry' and geometry[14] == '16'
geometry[14] = '32'; lines[2] = ' '.join(geometry)
lines[1] = hashlib.sha256(manifest + b' explicit-untrained-GA-context32').hexdigest()
body = ('\n'.join(lines) + '\n').encode('utf-8')
folder.mkdir(parents=True)
(folder / 'weights.tsv').write_bytes(body)
(folder / 'prompt.ids').write_bytes((original / 'prompt.ids').read_bytes())
receipt = dict(original_manifest=str(original / 'weights.tsv'),
               original_sha256=hashlib.sha256(manifest).hexdigest(),
               prepared_manifest=str(folder / 'weights.tsv'), prepared_sha256=hashlib.sha256(body).hexdigest(),
               change='Explicit untrained GA context limit 16 to 32; original absolute weight ranges reused',
               copied_weight_bytes=0, downloads=0, trained_model_quality_claim=False)
(W / 'fixture.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(folder)
