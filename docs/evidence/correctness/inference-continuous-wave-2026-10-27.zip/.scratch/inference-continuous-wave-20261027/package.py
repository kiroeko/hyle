"""Offline W15 receipt: exact historical sources/commands; no binaries/payloads."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness'
STEM = 'inference-continuous-wave-2026-10-27'
UNITS = ('ledger', 'paged', 'model', 'model2', 'probe')
TINY = ('cli-cpu-ordinary-b2', 'cli-cpu-mtp-k3-b2', 'cli-cuda-ordinary-b2', 'cli-cuda-mtp-k3-b2')
REAL = ('real-r1-off', 'real-r1-auto', 'real-b2-off', 'real-b2-auto')
FORBIDDEN = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.gguf', '.safetensors', '.pt', '.spv', '.db', '.sqlite'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def facts(value):
    if isinstance(value, list): return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k: facts(v) for k, v in value.items()
                if not any(x in k for x in ('seconds', 'per_second', 'capture', 'replay', 'trace_name'))}
    return value


def differences(a, b, path=''):
    if type(a) is not type(b): return [dict(path=path, before=b, after=a)]
    if isinstance(a, dict):
        assert a.keys() == b.keys(), ('report key mismatch', path)
        return [row for k in sorted(a) for row in differences(a[k], b[k], path + '/' + k)]
    if isinstance(a, list):
        assert len(a) == len(b), ('report list mismatch', path)
        return [row for at, (x, y) in enumerate(zip(a, b)) for row in differences(x, y, path + '/' + str(at))]
    return [] if a == b else [dict(path=path, before=b, after=a)]


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def compact_json(path, receipt):
    # Parallel records stay one per line; raw closure/report detail is in ZIP.
    lines = ['{']
    for at, (key, value) in enumerate(receipt.items()):
        prefix = '  ' + json.dumps(key) + ': '
        if isinstance(value, list):
            lines.append(prefix + '[')
            for index, row in enumerate(value):
                lines.append('    ' + json.dumps(row, ensure_ascii=False, separators=(',', ': ')) + (',' if index + 1 < len(value) else ''))
            lines.append('  ]' + (',' if at + 1 < len(receipt) else ''))
        else:
            lines.append(prefix + json.dumps(value, ensure_ascii=False, separators=(',', ': ')) + (',' if at + 1 < len(receipt) else ''))
    lines.append('}'); Path(path).write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main():
    ready = {name: read(W / ('ready-' + name + '.json')) for name in UNITS}
    builds = {name: read(W / 'compile' / name / 'compiled.json') for name in UNITS}
    assert all(row['process']['exit'] == 0 for row in builds.values())
    assert all(row['link']['exit'] == 0 for row in ready.values())
    assert {name: len(read(row['inputs']['path'])) for name, row in ready.items()} == dict(ledger=2, paged=242, model=224, model2=224, probe=223)
    for name, build in builds.items():
        for field in ('snapshot', 'command', 'compiler_dependencies', 'actual_dependencies'): exact(build[field])
        for field in ('inputs', 'recipe', 'plan', 'runtime'): exact(ready[name][field])
    assert builds['model']['source']['sha256'] == '8a7867123cee61c8ae46a599031a66b8e1b17c18cd533591fd1a45d056e3c647'
    assert builds['model2']['source']['sha256'] == '09f47468917ddc2c342a18df8490e7b2acfc993f049674e0a8ffb92ebed64260'
    frozen = {name: read(W / ('source-freeze-' + name + '.json')) for name in UNITS}
    for rows in frozen.values():
        for row in rows: exact(row['snapshot'])
    # Historical model1 canonical bytes intentionally changed. Never relabel
    # the current main as that old tested source.
    for name in ('ledger', 'paged', 'model2', 'probe'):
        for row in frozen[name]: exact(row['original'])

    host = read(W / 'host-results.json'); assert host['status'] == 'PASS' and len(host['runs']) == 2
    assert json.loads((W / 'runs/ledger/stdout.log').read_text()) == dict(status='PASS', groups=5, device_execution=False)
    tests = ET.parse(W / 'runs/paged/results.xml').getroot().findall('./testsuite/testcase')
    assert [x.attrib['classname'] + '.' + x.attrib['name'] for x in tests] == ['GraphPagedAppend.ConsumedCowTransactionReleasesOnlyItsRetiredInputs']
    assert all(x.find(tag) is None for x in tests for tag in ('failure', 'error', 'skipped'))
    cli = {name: read(W / 'runs' / name / 'summary.json') for name in (*TINY, *REAL)}
    for name, row in cli.items():
        assert row['status'] == 'PASS' and row['process']['exit'] == 0
        exact(row['report']); exact(row['original'])
        report, reference = read(row['report']['path']), read(row['original']['path'])
        assert report['live_committed_versions'] == 0
        changed = differences(facts(report), facts(reference))
        if name in TINY:
            assert not changed and row['ready']['sha256'] == pin(W / 'ready-model.json')['sha256']
        else:
            expected = [{'path': '/overlap_successor_publications', 'before': 44, 'after': 88},
                        {'path': '/overlap_successor_submissions', 'before': 44, 'after': 88}] if name.endswith('auto') else []
            assert changed == expected == row['exact_non_time_differences']
            width = 2 if 'b2' in name else 1
            assert report['generated_tokens'] == width * 97 and report['actual_graph_calls'] == 97
            assert report['overlap_successor_refusals'] == report['overlap_successor_discards'] == 0
    control = read(W / 'runs/continuous-controls/summary.json')
    report = read(W / 'runs/continuous-controls/report.json')
    assert control['status'] == report['status'] == 'PASS' and control['process']['exit'] == 0
    assert report['control_and_candidate_arms'] == 10 and len(report['candidates']) == 5
    assert report['complete_prefix_state_epoch_rng_equal'] and report['actual_owner_credit_checked'] and report['all_source_session_page_owners_retired']
    assert all(x['max_consecutive_pending'] >= 3 and x['pending_length27'] for x in report['candidates'])
    assert [x['credit_drains'] for x in report['candidates']] == [0, 0, 1, 0, 0]
    assert [x['cancelled_requests'] for x in report['candidates']] == [0, 0, 0, 1, 0]
    assert [x['yield_drains'] for x in report['candidates']] == [0, 0, 0, 0, 1]
    assert "KeyError: 'model2'" in (W / 'failure-build-model2.log').read_text()
    assert "KeyError: 'fixture_manifest'" in (W / 'failure-cli-cpu-ordinary-b2.log').read_text()

    files = {p for p in W.iterdir() if p.is_file() and p.suffix.lower() in {'.py', '.json', '.log'}
             and p.name not in {'package-result.json', 'archive-manifest.json'}}
    for directory in ('recipes', 'logs', 'runs'):
        files.update(p for p in (W / directory).rglob('*') if p.is_file())
    for name in UNITS:
        files.update(p for p in (W / ('link-' + name)).rglob('*') if p.is_file())
        files.update(W / 'compile' / name / filename for filename in ('compiled.json', 'dependencies.json', 'actual-dependencies.json'))
    selected = {'engine/models/qwen35/main.cc', 'engine/models/qwen35/generation_ledger.h',
        'engine/models/qwen35/session_state.h', 'engine/inference/request_loop.h',
        'tests/tools/qwen_generation_ledger_test.cc', 'tests/graph_batch/paged_append_graph_test.cc',
        'tests/tools/qwen_generation_batch_relay_probe.cc', 'tests/tools/qwen_continuous_generation_case.h',
        'tests/tools/qwen_generation_state_case.h', 'tests/tools/qwen_geometry_fixture.h'}
    snapshots, by_hash, snapshot_aliases = [], {}, []
    for name in UNITS:
        for row in frozen[name]:
            relative = Path(row['original']['path']).relative_to(R).as_posix()
            if relative not in selected: continue
            snapshot = row['snapshot']; identity = (snapshot['sha256'], snapshot['bytes'])
            if identity not in by_hash:
                source = Path(snapshot['path']); files.add(source); by_hash[identity] = source.relative_to(R).as_posix()
                snapshots.append(dict(logical_source=relative, actual_snapshot=by_hash[identity], **{k:snapshot[k] for k in ('bytes','sha256')}))
            snapshot_aliases.append(dict(unit=name, original_snapshot=snapshot['path'], archived=by_hash[identity], sha256=snapshot['sha256']))
    # Exact comparison controls and their identities, not old SDK/cache copies.
    for row in cli.values(): files.add(Path(row['original']['path']))
    V = W.parent / 'inference-wave-ownership-20261027'
    S = W.parent / 'inference-store-source-range-20261027'
    L = W.parent / 'inference-successor-ledger-20261027/attempt2'
    B = W.parent / 'inference-current-review-profile-20261027'
    files.update([V / 'ready-model.json', V / 'ready-probe2.json', V / 'build-plan.json', V / 'runtime.json',
        S / 'ready-component2.json', L / 'logs/compile/command.json', L / 'logs/link/command.json',
        B / 'ready-hyle.json', B / 'plan.json', W / 'inputs/context32/weights.tsv', W / 'inputs/context32/prompt.ids'])
    for name in TINY: files.add(Path(cli[name]['fixture_manifest']['path']))
    assert not any(path.suffix.lower() in FORBIDDEN for path in files), 'binary/payload accidentally selected'
    members = []
    for path in sorted(files):
        assert path.is_file() and path.resolve().is_relative_to(R), path
        data = path.read_bytes()
        members.append(dict(member=path.relative_to(R).as_posix(), bytes=len(data), sha256=digest(data)))
    manifest = dict(schema=1, members=members, source_snapshot_aliases=snapshot_aliases,
        binary_pins='Compile/link/run-time object and image hashes are retained in receipts; no binary is archived or re-labeled as a different generation.',
        harness='check.py is the final harness; per-process command.json is authoritative. Both pre-launch script failures and original failed model2 plan are preserved.')
    DEST.mkdir(parents=True, exist_ok=True); archive = DEST / (STEM + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for row in members: out.write(R / row['member'], row['member'])
        out.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        assert set(check.namelist()) == {x['member'] for x in members} | {'manifest.json'}
        for row in members:
            data = check.read(row['member']); assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert json.loads(check.read('manifest.json')) == manifest

    build_rows = [dict(unit=name, source_sha256=builds[name]['source']['sha256'],
        object=builds[name]['object'], CXX=builds[name]['process'], link=ready[name]['link'],
        image=ready[name]['image'], inputs=len(read(ready[name]['inputs']['path']))) for name in UNITS]
    process_rows = [dict(name=x['unit'], image=x['unit'], **x['process']) for x in host['runs']]
    process_rows += [dict(name=name, image='model1' if name in TINY else 'model2', **cli[name]['process']) for name in (*TINY,*REAL)]
    process_rows.append(dict(name='continuous-controls', image='probe/main-model2', arms=10, **control['process']))
    assert len(process_rows) == 11 and all(x['exit'] == 0 for x in process_rows)
    receipt = dict(schema=1, status='PASS', date='2026-10-27', subject='Continuous ordinary decode across RequestLoop pumps using original Step/Source owners',
        repository_head_at_packaging=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        counts=dict(CXX=5, links=5, actual_processes=11, host_processes=2, tiny_CLI=4, real_Qwen_CLI=4, controls_processes=1, controls_arms=10, SDK=0, NVCC=0, downloads=0),
        implementation=[
            'Deferred PreparedGenerationCall metadata crosses pumps; original Model active/successor Step and single SubmissionSource retain all native work and complete outcome.',
            'Resumed work observes its original submitted episode, renews only actual held/additional output grants, and may submit the next exact successor before observing that episode.',
            'Three physical carriers retain at most D2 candidates; expected Session base/epoch, complete ordered cohort, existing capture tuple and original Source permissions remain mandatory.',
            'After whole success, original deltas, tails and input withdrawal are complete before consumed returned append transactions are dropped; stale COW source tails no longer pin the next candidate page.',
            'Normal publication, bounded-credit drain, one-member cancellation with surviving peer, explicit yield/requeue and reverse actual retirement use the same original owners.'],
        source_snapshots=snapshots, builds=build_rows, actual_processes=process_rows,
        host_checks=['Ledger five groups include renewed ordinary quota rejection/strong guarantees.',
            'One CPU GTest checks returned COW transaction old-tail pin, true reacquire after dropping it, exact committed new bytes, and both drop-before/after-commit orders.'],
        tiny_model1=dict(sha256=builds['model']['source']['sha256'], scope='CPU/CUDA ordinary B2 and MTP K3 B2; each once, complete normalized reports equal W14 and final live versions zero; these do not validate the later Model2 edit'),
        real_model2=dict(sha256=builds['model2']['source']['sha256'], scope='Cached Qwen3.5-2B R1/R2 ordinary off/auto; 97/194 IDs, 97 original Graph calls each, complete normalized report comparison against W13',
            auto_only_differences=['/overlap_successor_submissions:44->88','/overlap_successor_publications:44->88'], refusals=0, discards=0, final_live_versions=0),
        comparisons=dict(normalizer_excludes_key_substrings=['seconds','per_second','capture','replay','trace_name'], exact_additional_exceptions='Only the two auto top-level successor counters listed above; off has none',
            continuous_oracle='Every published initialized logical KV/GDN/conv byte, IDs, ledger result/actual member geometry, epochs and RNG match serial controls. Quota is validated against each real wave grant before its intentional control/candidate normalization.'),
        continuous_candidates=report['candidates'],
        controls_fixture=dict(type='Untrained cached GA/H64', prompt_rows=18, outputs_per_live_member=14, context=32, delivery_credit=2, D=2, N='actual width 1 or 2', R='actual width 1 or 2',
            state_snapshot_slots='N+2R, exactly 3*width', old_tail_boundary='length27 within context32; no budget enlargement', copied_weight_bytes=0, context_manifest_only='Existing tiny context16 changed explicitly to32; original absolute binary ranges reused'),
        recorded_correction=dict(old_model='8a7867 had four tiny passes; independent static review found live version count includes deferred B.next',
            new_model='09f474 subtracts only actual nonempty active/successor candidate versions for committed-N observation, while keeping the physical snapshot_slots gate; extra model2 CXX/link and current probe used distinct artifacts',
            boundary='No actual failed Model1 real-model process was run for this known issue; it was corrected before those four real journeys.'),
        recorded_script_failures=[dict(error="KeyError:'model2'",stage='After successful model2 CXX, before any link process',action='Preserved failed plan/log; separate corrected immutable link plan reused the one successful OBJ; no CXX retry'),
            dict(error="KeyError:'fixture_manifest'",stage='Before any tiny model process',action='Preserved original run_cli-attempt1.py/log; pinned actual --inputs/weights.tsv; each of four real tiny processes then ran once')],
        boundaries=['Functional evidence only: recorded process seconds are not a TPS/latency comparison or speedup.',
            'No new natural model EOS, new fault-injection or new MTP device-continuation proof; MTP appears only in the four existing tiny regressions.',
            'Continuous controls are ordinary greedy CUDA and an untrained tiny fixture; no sampling continuation or other-platform claim.',
            'No SDK, shader, NVCC or model-weight rebuild/download; no second executor, Completion owner or fake ready state introduced.'],
        evidence=dict(archive=pin(archive), members=len(members)+1, all_member_bytes_sha_read_back=True,
            includes='Necessary exact old/new source snapshots, source alias map, plans, compiler dependencies, object/image hash references, complete commands/logs/XML/reports and comparison controls',
            omits='EXE/OBJ/PDB/DLL/LIB/EXP, SDK copies, shader binaries and model payloads'))
    output = DEST / (STEM + '.json'); compact_json(output, receipt)
    result = dict(receipt=pin(output), archive=pin(archive), members=len(members)+1, source_snapshots=len(snapshots), actual_processes=11)
    save(W / 'package-result.json', result); print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
