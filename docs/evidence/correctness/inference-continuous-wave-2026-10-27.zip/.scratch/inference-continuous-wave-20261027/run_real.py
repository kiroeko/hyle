from pathlib import Path
import importlib.util, json, sys, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('continuous_current_build', W / 'check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
OLD = W.parent / 'inference-current-review-profile-20261027'


def facts(value):
    if isinstance(value, list): return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k: facts(v) for k, v in value.items()
                if not any(x in k for x in ('seconds', 'per_second', 'capture', 'replay', 'trace_name'))}
    return value


def differences(a, z, path=''):
    if type(a) is not type(z): return [dict(path=path, before=z, after=a)]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(z)):
            p = path + '/' + key
            result += differences(a[key], z[key], p) if key in a and key in z else [dict(path=p, before=z.get(key), after=a.get(key))]
        return result
    if isinstance(a, list):
        if len(a) != len(z): return [dict(path=path + '/length', before=len(z), after=len(a))]
        return [d for at, (x, y) in enumerate(zip(a, z)) for d in differences(x, y, path + '/' + str(at))]
    return [] if a == z else [dict(path=path, before=z, after=a)]


def run(name):
    assert name in ('r1-off', 'r1-auto', 'b2-off', 'b2-auto')
    ready = b.read(W / 'ready-model2.json'); b.exact(ready['image'])
    for row in b.read(W / 'source-freeze-model2.json'): b.exact(row['original']); b.exact(row['snapshot'])
    original = next(x for x in b.read(OLD / 'plan.json')['commands'] if x['name'] == name)
    command = [ready['image']['path'], *original['consumer'][1:]]
    out = W / 'runs' / ('real-' + name)
    assert not out.exists(), 'Preserve every actual attempt'
    b.save(out.parent / ('plan-real-' + name + '.json'), dict(command=command, ready=b.pin(W / 'ready-model2.json')))
    process = b.h.execute(command, b.environment(), out, timeout=180)
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig')); b.save(out / 'report.json', report)
    reference = OLD / 'runs' / name / 'report.json'
    changed = differences(facts(report), facts(b.read(reference))); b.save(out / 'non-time-differences.json', changed)
    allowed = {'/overlap_successor_submissions', '/overlap_successor_publications'} if name.endswith('auto') else set()
    unexpected = [x for x in changed if x['path'] not in allowed]
    assert not unexpected, ('Complete non-time report changed', unexpected[:10])
    width = 2 if name.startswith('b2') else 1
    assert report['generated_tokens'] == width * 97 and report['actual_graph_calls'] == 97
    assert report['live_committed_versions'] == 0
    if name.endswith('auto'):
        accepted = report['overlap_successor_submissions']
        assert 80 <= accepted <= 96 and report['overlap_successor_publications'] == accepted
        assert report['overlap_successor_refusals'] == report['overlap_successor_discards'] == 0
    result = dict(status='PASS', process=process, report=b.pin(out / 'report.json'), original=b.pin(reference),
                  exact_non_time_differences=changed, complete_semantic_report_equal=True,
                  scope='Real cached Qwen3.5-2B functional journey only; no timing benchmark or memory peak claim')
    b.save(out / 'summary.json', result)
    print('PASS real-' + name + ' pid=' + str(process['pid']) + ' successors=' + str(report['overlap_successor_submissions']), flush=True)


if __name__ == '__main__':
    try: run(sys.argv[1])
    except BaseException:
        (W / ('failure-real-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
