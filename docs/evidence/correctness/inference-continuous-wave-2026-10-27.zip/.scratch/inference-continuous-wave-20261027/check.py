"""Four finite CXX/link actions. prepare reads metadata; freeze alone copies sources.

No SDK/NVCC/model download. No action runs a test or a model.
"""
from pathlib import Path
import hashlib, importlib.util, json, os, re, sys, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
V = R / '.scratch/inference-wave-ownership-20261027'
S = R / '.scratch/inference-store-source-range-20261027'
L = R / '.scratch/inference-successor-ledger-20261027/attempt2'
P = R / '.scratch/inference-paged-frame-20261026/engine/compile2/test'
spec = importlib.util.spec_from_file_location('continuous_prior', V / 'build.py')
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
m, h = prior.m, prior.h
SOURCES = dict(ledger='tests/tools/qwen_generation_ledger_test.cc',
              paged='tests/graph_batch/paged_append_graph_test.cc',
              model='engine/models/qwen35/main.cc',
              probe='tests/tools/qwen_generation_batch_relay_probe.cc')
IMAGES = dict(ledger='generation-ledger-test.exe', paged='paged-append-test.exe',
              model='hyle.exe', model2='hyle-model2.exe', probe='qwen-continuous-generation-probe.exe')
MODEL2_SHA = '09f47468917ddc2c342a18df8490e7b2acfc993f049674e0a8ffb92ebed64260'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def active_plan():
    pointer = W / 'active-plan.json'
    return Path(read(pointer)['path']) if pointer.exists() else W / 'build-plan.json'


def pin(path):
    path = Path(path).resolve(); digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20): digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def key(path):
    return str(path).replace('/', '\\').casefold()


def project(path):
    path = Path(path).resolve()
    return path.is_relative_to(R) and bool(path.relative_to(R).parts) and path.relative_to(R).parts[0] in ('include', 'engine', 'src', 'tests')


def aliases():
    result = {}
    for name in ('source-freeze.json', 'source-freeze-probe2.json'):
        for row in read(V / name):
            result[key(row['snapshot']['path'])] = Path(row['original']['path'])
    return result


def canonical(path, mapping):
    if key(path) in mapping: return mapping[key(path)]
    path = Path(path).resolve()
    for directory in (V / 'source', V / 'source2', V / 'source3'):
        if path.is_relative_to(directory): return R / path.relative_to(directory)
    return path


def environment():
    result = dict(os.environ); result.update(read(V / 'environment.json'))
    result['PATH'] = str(W / 'bin') + ';' + read(V / 'runtime.json')['PATH']
    for name in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE'): result[name] = '1'
    return result


def prepare():
    assert not (W / 'preparation-plan.json').exists(), 'preserve prior preparation'
    cli, probe, component = [read(path) for path in
        (V / 'model-link-inputs.json', V / 'probe2-link-inputs.json', S / 'component-link-inputs2.json')]
    assert (len(cli), len(probe), len(component)) == (224, 223, 241)
    mapping = aliases()
    indices = {name: m.index(rows) for name, rows in (('model', cli), ('probe', probe), ('paged', component))}
    def find(name, relative):
        found = [row for row in indices[name].values()
                 if key(canonical(row['data']['Source'], mapping)) == key(R / relative)]
        assert len(found) == 1, (name, relative, len(found))
        return found[0]
    old_model = find('model', SOURCES['model'])
    old_probe = find('probe', 'tests/tools/qwen_request_lifecycle_test.cc')
    old_paged = [row for row in indices['paged'].values()
                 if key(canonical(row['data']['Source'], mapping)) == key(R / SOURCES['paged'])]
    assert not old_paged, 'reassess actual closure instead of appending a duplicate TU'
    recipes = dict(ledger=L / 'logs/compile/command.json', paged=P / 'command.json',
                   model=V / 'logs/model/command.json', probe=V / 'logs/probe2/command.json')
    dependencies = dict(ledger=L / 'compile/dependencies.json', paged=P / 'dependencies.json',
                        model=Path(old_model['dependencies']['path']), probe=Path(old_probe['dependencies']['path']))
    for path in (*recipes.values(), *dependencies.values()): assert path.is_file(), path
    rows = {}
    for name in SOURCES:
        template = read(recipes[name])['command']
        assert '/MD' in template and '/O2' in template and '/DNDEBUG' in template and '/DHYLE_STATIC' in template
        rows[name] = dict(source=str(R / SOURCES[name]), recipe=str(recipes[name]),
                          compiler_dependencies=str(dependencies[name]),
                          original_object=(old_model if name == 'model' else old_probe if name == 'probe' else None))
    links = dict(ledger=dict(inputs=str(L / 'link-inputs.json'), recipe=str(L / 'logs/link/command.json'), count=2),
                 paged=dict(inputs=str(S / 'component-link-inputs2.json'), recipe=str(S / 'link-component2/command.json'), count=242),
                 model=dict(inputs=str(V / 'model-link-inputs.json'), recipe=str(V / 'link-model/command.json'), count=224),
                 probe=dict(inputs=str(V / 'probe2-link-inputs.json'), recipe=str(V / 'link-probe2/command.json'), count=223))
    for row in links.values(): assert Path(row['recipe']).is_file()
    save(W / 'preparation-plan.json', dict(status='RECIPES_ONLY_NOT_SOURCE_FROZEN_NOT_BUILT', units=rows, links=links,
        environment=str(V / 'environment.json'), runtime=str(V / 'runtime.json'),
        expected=dict(CXX=4, links=4, SDK=0, NVCC=0, tests_run=0, models_run=0, downloads=0),
        source_policy='Do not snapshot WIP. Invoke freeze only after root confirms all four current sources/headers frozen.',
        component_exception='The actual W12 241-input closure has no paged_append_graph_test.cc object. Append one real GTest TU: 242 inputs. '
                            'The historical exact TU command is reused with only HYLE_APPEND_STANDALONE removed to select its existing GTest entry.',
        binary_policy='Reuse retained OBJ/libs/SDK paths; do not require or rebuild old EXEs. Every OUT/PDB/IMPLIB/MAP output is within this scratch.'))
    print('PREPARED 4 CXX / 4 links; input counts ledger2/paged242/model224/probe223; no source freeze/build/run', flush=True)


def freeze(names):
    plan = read(W / 'preparation-plan.json'); mapping = aliases()
    build = read(active_plan()) if active_plan().exists() else dict(plan)
    build['units'] = plan['units']
    build['links'] = plan['links']
    build.setdefault('frozen_units', {})
    revised_main = bool(set(names) & {'model2', 'probe'})
    if revised_main:
        assert pin(R / SOURCES['model'])['sha256'] == MODEL2_SHA, 'root-approved model2 canonical source drifted'
    for previous in build['frozen_units'].values():
        for row in read(previous['source_freeze']['path']):
            exact(row['snapshot'])
            if revised_main and key(row['original']['path']) == key(R / SOURCES['model']):
                assert row['original']['sha256'] in {MODEL2_SHA,
                    '8a7867123cee61c8ae46a599031a66b8e1b17c18cd533591fd1a45d056e3c647'}
            else: exact(row['original'])
    for name in names:
        assert name not in build['frozen_units'], ('preserve frozen unit', name)
        unit = plan['units'][name]; files = set()
        source = Path(unit['source']); assert source.is_file(), source
        files.add(source)
        for path in read(unit['compiler_dependencies'])['Data']['Includes']:
            original = canonical(path, mapping)
            if project(original): files.add(original)
        roots = [R, R / 'include', R / 'engine', R / 'engine/models/qwen35', R / 'tests/tools', R / 'src/graph', R / 'src/compute']
        todo = list(files)
        while todo:
            source = todo.pop()
            for include in re.findall(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', source.read_text(encoding='utf-8-sig'), re.M):
                found = next((path.resolve() for directory in [source.parent, *roots] if (path := directory / include).is_file()), None)
                if found is not None and project(found) and found not in files: files.add(found); todo.append(found)
        overlay = W / 'source' / name
        frozen = []
        for source in sorted(files):
            snapshot = overlay / source.relative_to(R); snapshot.parent.mkdir(parents=True, exist_ok=True)
            snapshot.write_bytes(source.read_bytes()); original, copy = pin(source), pin(snapshot)
            assert (original['bytes'], original['sha256']) == (copy['bytes'], copy['sha256'])
            frozen.append(dict(original=original, snapshot=copy))
        freeze_path = W / ('source-freeze-' + name + '.json'); save(freeze_path, frozen)
        template = read(unit['recipe'])['command']; out = W / 'compile' / name
        snapshot = overlay / Path(unit['source']).relative_to(R); command = []
        for index, arg in enumerate(template):
            if name == 'paged' and arg == '/DHYLE_APPEND_STANDALONE=1': continue
            if index and template[index-1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(snapshot)
            elif arg.lower().startswith('/i'):
                path = canonical(arg[2:], mapping)
                if project(path): arg = '/I' + str(overlay / path.relative_to(R))
                elif key(path) == key(R): arg = '/I' + str(overlay)
            command.append(arg)
        command[1:1] = ['/I' + str(overlay / 'include'), '/I' + str(overlay),
                         '/I' + str(overlay / 'engine/models/qwen35'), '/I' + str(overlay / 'tests/tools')]
        build['frozen_units'][name] = dict(**unit, original_source=pin(unit['source']), snapshot=pin(snapshot),
                           command=command, template=pin(unit['recipe']), overlay=str(overlay), source_freeze=pin(freeze_path))
        save(W / 'recipes' / (name + '.json'), dict(command=command))
    cpu = read(V / 'runtime.json')['original_native_cpu']; exact(cpu)
    save(W / 'runtime-plan.json', dict(original_native_cpu=cpu, alias=str(W / 'bin' / Path(cpu['path']).name),
                                     PATH=environment()['PATH']))
    # No model payload is part of this source/ABI/dependency receipt.
    build['status'] = 'SELECTED_UNITS_FROZEN_NOT_BUILT'
    if revised_main:
        build['authorized_model_revision'] = dict(current=pin(R / SOURCES['model']),
            historical='model1 8a7867 snapshot/OBJ/image/readiness and four CLI runs remain unchanged',
            reason='root-approved actual live version accounting excludes only existing active/successor next candidates from the committed-N observation; no capacity is enlarged')
    # Existing readiness receipts keep their immutable, actually used plan.
    # A later probe freeze gets a new plan, rather than rewriting that evidence.
    destination = W / ('build-plan-' + '-'.join(names) + '.json') if (W / 'build-plan.json').exists() else W / 'build-plan.json'
    assert not destination.exists(), 'preserve immutable prior plan'
    save(destination, build); save(W / 'active-plan.json', pin(destination))
    print('FROZEN ' + ','.join(names) + '; no CXX/link/run', flush=True)


def compile_unit(name):
    plan = read(active_plan()); unit = plan['frozen_units'][name]
    for row in read(unit['source_freeze']['path']): exact(row['original']); exact(row['snapshot'])
    out = W / 'compile' / name; out.mkdir(parents=True, exist_ok=False)
    result = h.execute(unit['command'], environment(), W / 'logs' / name, timeout=240)
    data = read(out / 'dependencies.json')['Data']; assert key(data['Source']) == key(unit['snapshot']['path'])
    assert not any(project(path) for path in data['Includes']), 'live project header escaped frozen include tree'
    mapping = aliases()
    assert not any(project(canonical(path, mapping)) for path in data['Includes']
                   if not Path(path).is_relative_to(Path(unit['overlay']))), 'old project overlay header leaked'
    deps = [pin(path) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    frozen = {key(row['snapshot']['path']): row['snapshot'] for row in read(unit['source_freeze']['path'])}
    for row in deps:
        if Path(row['path']).is_relative_to(W / 'source'): assert row == frozen[key(row['path'])]
    if name == 'probe': assert key(Path(unit['overlay']) / 'engine/models/qwen35/main.cc') in {key(x) for x in data['Includes']}
    save(out / 'actual-dependencies.json', deps)
    save(out / 'compiled.json', dict(source=unit['original_source'], snapshot=unit['snapshot'], object=pin(out / 'unit.obj'),
        process=result, command=pin(W / 'logs' / name / 'command.json'),
        actual_dependencies=pin(out / 'actual-dependencies.json'), compiler_dependencies=pin(out / 'dependencies.json')))
    print('CXX_PASS ' + name, flush=True)


def link(name):
    plan = read(active_plan()); unit = plan['frozen_units'][name]
    compiled = read(W / 'compile' / name / 'compiled.json'); exact(compiled['object'])
    base = plan['links'][name]; old = read(base['inputs']); template = read(base['recipe'])['command']
    if name == 'paged':
        inputs = [*old, compiled['object']]; replacements = {}
    else:
        original = old[0] if name == 'ledger' else unit['original_object']['object']
        assert sum(key(row['path']) == key(original['path']) for row in old) == 1
        inputs = [compiled['object'] if key(row['path']) == key(original['path']) else row for row in old]
        replacements = {key(original['path']): compiled['object']['path']}
    assert len(inputs) == base['count']
    for row in inputs: exact(row)
    image = W / 'bin' / IMAGES[name]; image.parent.mkdir(parents=True, exist_ok=True)
    command = []
    for arg in template:
        if key(arg) in replacements: arg = replacements[key(arg)]
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    if name == 'paged': command.append(compiled['object']['path'])
    if not any(arg.upper().startswith('/PDB:') for arg in command): command.append('/PDB:' + str(image.with_suffix('.pdb')))
    if not any(arg.upper().startswith('/IMPLIB:') for arg in command): command.append('/IMPLIB:' + str(image.with_suffix('.lib')))
    cpu = read(W / 'runtime-plan.json')['original_native_cpu']; exact(cpu)
    alias = image.parent / Path(cpu['path']).name
    if not alias.exists(): os.link(cpu['path'], alias)
    save(W / (name + '-link-inputs.json'), inputs)
    save(W / 'environment.json', {k: environment().get(k, '') for k in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    result = h.execute(command, environment(), W / ('link-' + name), timeout=180)
    save(W / ('ready-' + name + '.json'), dict(status='LINKED_NOT_RUN', image=pin(image), compiled=compiled, link=result,
        inputs=pin(W / (name + '-link-inputs.json')), recipe=pin(W / ('link-' + name) / 'command.json'),
        runtime=pin(W / 'runtime-plan.json'), plan=pin(active_plan())))
    print('LINK_PASS ' + name, flush=True)


def run_hosts():
    results = []
    case = 'GraphPagedAppend.ConsumedCowTransactionReleasesOnlyItsRetiredInputs'
    for name in ('ledger', 'paged'):
        ready = read(W / ('ready-' + name + '.json')); exact(ready['image'])
        compiled = read(active_plan())['frozen_units'][name]
        for row in read(compiled['source_freeze']['path']): exact(row['original']); exact(row['snapshot'])
        output = W / 'runs' / name
        command = [ready['image']['path']]
        if name == 'paged': command += ['--gtest_color=no', '--gtest_fail_fast', '--gtest_filter=' + case,
                                       '--gtest_output=xml:' + str(output / 'results.xml')]
        process = h.execute(command, environment(), output, timeout=60)
        if name == 'ledger':
            actual = json.loads((output / 'stdout.log').read_text(encoding='utf-8'))
            assert actual == dict(status='PASS', groups=5, device_execution=False), actual
        else:
            tests = ET.parse(output / 'results.xml').getroot().findall('./testsuite/testcase')
            assert [x.attrib['classname'] + '.' + x.attrib['name'] for x in tests] == [case]
            assert all(x.find(tag) is None for x in tests for tag in ('failure', 'error', 'skipped'))
            actual = dict(status='PASS', selected_cases=1, CPU=True, GPU=False)
        results.append(dict(unit=name, ready=pin(W / ('ready-' + name + '.json')), process=process, result=actual))
        save(W / 'host-results.json', dict(status='PARTIAL' if len(results) == 1 else 'PASS', runs=results))
    print('PASS ledger5 + paged1; no model/GPU execution', flush=True)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'update-probe':
            plan = read(W / 'preparation-plan.json')
            plan['units']['probe']['source'] = str(R / SOURCES['probe'])
            plan['probe_entry'] = '--cuda-continuous INPUT; shared tests/tools/qwen_continuous_generation_case.h'
            save(W / 'preparation-plan.json', plan)
            print('UPDATED pending probe metadata only; no source freeze/CXX/link/run', flush=True)
        elif action == 'prepare-model2':
            plan = read(W / 'preparation-plan.json')
            assert 'model2' not in plan['units'], 'preserve supplementary recipe'
            plan['units']['model2'] = dict(plan['units']['model'])
            plan['links']['model2'] = dict(plan['links']['model'])
            plan['expected'].update(CXX=5, links=5)
            plan['supplement'] = dict(model2_sha=MODEL2_SHA, budget='three original CXX/links passed, add only model2 and the final shared probe',
                policy='All model2 outputs are distinct; original model1 image/OBJ/snapshots/commands/readiness are preserved')
            save(W / 'preparation-plan.json', plan)
            print('PREPARED independent model2 recipe; no source freeze/CXX/link/run', flush=True)
        elif action == 'repair-model2-link-plan':
            old = active_plan(); plan = read(old)
            assert 'model2' in plan['frozen_units'] and 'model2' not in plan['links']
            fixed = dict(plan); fixed['links'] = read(W / 'preparation-plan.json')['links']
            fixed['script_plan_correction'] = dict(original=pin(old), reason='link lookup KeyError before any link process; existing successful CXX/object unchanged')
            destination = W / 'build-plan-model2-link-fixed.json'; assert not destination.exists()
            save(destination, fixed); save(W / 'active-plan.json', pin(destination))
            print('REPAIRED only model2 link metadata; no CXX/link/run', flush=True)
        elif action == 'freeze': freeze(sys.argv[2:] or list(SOURCES))
        elif action == 'compile': compile_unit(sys.argv[2])
        elif action == 'link': link(sys.argv[2])
        elif action == 'run-hosts': run_hosts()
        elif action == 'build':
            for name in sys.argv[2:] or SOURCES: compile_unit(name)
            for name in sys.argv[2:] or SOURCES: link(name)
        else: raise ValueError(action)
    except BaseException:
        (W / ('failure-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
