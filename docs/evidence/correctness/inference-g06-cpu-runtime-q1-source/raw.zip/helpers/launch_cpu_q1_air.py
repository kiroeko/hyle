from pathlib import Path
import subprocess,json,hashlib,zipfile,sys
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';attempt=sys.argv[1]
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
r=json.loads((base/'common-source-6/result.json').read_bytes());assert r['state']=='TERMINAL_PASS'
roots={'include','src','cmake','scripts','tests','samples','third_party'}
names=[s for s in subprocess.check_output(['git','ls-files'],text=True).splitlines() if s.split('/')[0] in roots or s=='CMakeLists.txt' or (s.count('/')==0 and s.endswith('.cmake'))]
manifest={'candidate':candidate,'scope':'Canonical tracked product/CMake/test inputs; one-way disposable Air sync, changed bytes only','inputs':[{'path':s,'sha256':hashlib.sha256((root/s).read_bytes()).hexdigest()} for s in names]}
package=base/('cpu-q1-input-'+attempt+'.zip')
with zipfile.ZipFile(package,'x',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 z.writestr('input-manifest.json',json.dumps(manifest,indent=2))
 for s in names:z.write(root/s,s)
remote='/Users/kiro/hyle-scratch/compute-unified';host='kiro@172.22.10.198'
subprocess.run(['ssh','-o','BatchMode=yes',host,'test ! -e '+remote+'/g06-cpu-q1-'+attempt],check=True)
subprocess.run(['scp','-q',str(package),host+':'+remote+'/g06-cpu-q1-input-'+attempt+'.zip'],check=True)
subprocess.run(['scp','-q',str(base/'cpu_q1_air.py'),host+':'+remote+'/g06_cpu_q1_air.py'],check=True)
print('packed',len(names),'files',package.stat().st_size,'bytes; serial Air',attempt,'candidate',candidate,flush=True)
p=Path('.scratch/inference-gaps/g01/handoff-current.json');d=json.loads(p.read_bytes());g=d['g06_current'].setdefault('cpu_q1',{});g.update(air_state='STARTING_ATTEMPT'+attempt,air_remote_result=remote+'/g06-cpu-q1-'+attempt+'/result.json',product_snapshot=candidate,head=candidate)
g.setdefault('air_attempts',[]).append({'attempt':attempt,'candidate':candidate,'state':'STARTING'})
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
code=subprocess.call(['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15',host,'/usr/bin/python3 '+remote+'/g06_cpu_q1_air.py '+attempt+' '+candidate+(' --joint-only' if '--joint-only' in sys.argv else '')]);raise SystemExit(code)
