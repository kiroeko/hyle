from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';windows=base/'common-source-6';air=base/'cpu-q1-air-1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
w=json.loads((windows/'result.json').read_bytes());a=json.loads((air/'result.json').read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert w['candidate']==a['candidate']==head and w['state']==a['state']=='TERMINAL_PASS'
assert all(x['exit_code']==0 for r in [w,a] for x in r['stages'])
tests=[]
for target,count in [('hyle_compute_provider_ggml_test',62),('g04_g05_encoded_common_pages',25)]:
 p=windows/(target+'.xml');x=E.parse(p).getroot()
 assert int(x.get('tests'))==count and all(int(x.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
 tests.append(dict(target=target,tests=count,failures=0,skipped=0,testcases=[t.get('classname')+'.'+t.get('name') for t in x.findall('.//testcase')]))
assert any('RuntimeQ1UsesOriginalDecodeSlotAcrossPagesAndTails' in name for t in tests for name in t['testcases'])
for target in ['g04_plain_pending_control','g04_encoded_pending_risks']:assert (windows/(target+'.log')).read_text().count('PASS')==9
for route in ['apple','vulkan']:
 text=(air/(route+'-g06_cpu_q1.log')).read_text()
 assert '[  PASSED  ] 25 tests.' in text and '[  FAILED  ]' not in text and '[  SKIPPED ]' not in text
 assert '[       OK ] GgmlCpuPaged.RuntimeQ1UsesOriginalDecodeSlotAcrossPagesAndTails' in text
manifest=json.loads((air/'input-manifest.json').read_bytes());assert manifest['candidate']==head
for item in manifest['inputs']:assert sha(root/item['path'])==item['sha256'],item['path']
inputs=[dict(path=s,sha256=sha(root/s)) for s in subprocess.check_output(['git','diff','--name-only','e13833ae3',head],text=True).splitlines() if (root/s).is_file()]
artifacts=[]
for name in ['hyle_compute_provider_ggml.dll',*[t+'.exe' for t in w['targets']]]:
 p=Path(w['build'])/'bin'/name;assert p.is_file();artifacts.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
dest=root/'evidence/correctness/inference-g06-cpu-runtime-q1-source';dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in [windows,air]:
  for p in sorted(folder.iterdir()):
   if p.is_file():z.write(p,folder.name+'/'+p.name)
 for name in ['run_cpu_q1_source.py','cpu_q1_air.py','launch_cpu_q1_air.py','seal_cpu_q1_source.py']:z.write(base/name,'helpers/'+name)
 for item in inputs:z.write(root/item['path'],'source/'+item['path'])
r=dict(kind='G06_D2_ORIGINAL_CPU_Q1_RUNTIME_SOURCE',verdict='PASS_WINDOWS_CPU_AND_AIR_MIXED_CORE_SOURCE',candidate=head,
 windows=dict(execution=w,tests=tests,total_tests=87,pending_risk_scenarios=18,artifacts=artifacts),
 air=dict(execution=a,tests_by_build={'cpu_apple':25,'cpu_vulkan':25},artifacts=json.loads((air/'artifacts-after-run.json').read_bytes())),
 source_inputs=inputs,input_manifest_sha256=sha(air/'input-manifest.json'),raw_zip_sha256=sha(dest/'raw.zip'),
 proven=['32 finite single/multi/type/plain-Q8/depth/window configurations each run64 independent numeric episodes. Length growth/shrink, shared/reordered IDs, page crossing, original long-KV512 split boundary and request join/end/empty middle are checked.',
 'Stable Q topology reuses the original native graph/pool/scratch, with next injected allocation prohibited and unchanged float_workspace_bytes. Changed Q topology/request set genuinely replans. Old owning output still rejects reuse.',
 'Current slot layout owns updated native I32 leaf spans; each cold Request separately owns its immutable initial recipe layout. Equal-content new snapshots refresh Q1 pointers before old owner replacement; general paged recipes retain the original leaf owner.',
 'Only private paged Q1 causal zero masks are omitted. Original kernels, arithmetic, window/boxed flags, dispatch thresholds, ordinary attention masks and native workspace planning remain unchanged.',
 'Unused physical page contains poison and remains independently writable; exact original page frames and actual completion gates remain. Original plain/encoded pending nine-scenario risk sets pass.',
 'Windows provider ordinary62 tests and original native/common/Graph25 tests run without duplicate long native suites. Real Air mixed CPU-only work runs inside both CPU+Apple and CPU+Vulkan library configurations.'],
 limits=['This is CPU runtime correctness/P0 source evidence, not native Apple/Vulkan GPU speed, CUDA/FI qualification, new P1 or full G06 acceptance.',
 'No-injected-allocation assertions cover prepared update after caller-created immutable versions. Version creation still owns an active-sized snapshot and native/driver/private costs keep their original accounting limits.',
 'Variable ragged extents, native Apple/Vulkan runtime lengths, FI Q1/capture and final san/header/relocated SDK remain required; no goal scope was reduced.',
 'Original G04/G05 performance failures and UNKNOWN costs remain. No runtime/vendor/CMake/public ABI source changes, CUDA/P1/profile/model/server or global build.',
 'Recorded stage and outer durations overlap. Packaging, launch and observation gaps without a captured stopwatch remain UNKNOWN rather than zero.'])
(dest/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=r['verdict'],windows_tests=87,pending_scenarios=18,air_tests_by_build=r['air']['tests_by_build'],receipt=str(dest/'receipt.json'))))
