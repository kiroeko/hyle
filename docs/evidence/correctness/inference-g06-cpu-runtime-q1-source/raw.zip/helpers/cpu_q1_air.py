from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified')
source=base/'source-c8874688';out=base/('g06-cpu-q1-'+sys.argv[1])
out.mkdir(exist_ok=False);started=time.monotonic()
identity={k:subprocess.check_output(args,text=True).strip() for k,args in [
 ('model',['/usr/sbin/sysctl','-n','hw.model']),('cpu',['/usr/sbin/sysctl','-n','machdep.cpu.brand_string']),
 ('memory',['/usr/sbin/sysctl','-n','hw.memsize']),('arch',['uname','-m']),('os',['sw_vers']),
 ('compiler',['xcrun','clang','--version']),('gpu',['/usr/sbin/system_profiler','SPDisplaysDataType']),
 ('cmake',['/opt/homebrew/bin/cmake','--version']),('ninja',['/opt/homebrew/bin/ninja','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
assert source.is_dir() and source.resolve().is_relative_to(base.resolve()) and not (source/'.git').exists()
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
assert not any('/opt/homebrew/bin/cmake --build' in s or '/opt/homebrew/bin/ninja -C' in s for s in ps.splitlines()),'Another heavy native run exists'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
r=dict(state='SYNC',pid=os.getpid(),candidate=sys.argv[2],identity=identity,max_jobs=4,source=str(source),stages=[],
 scope='G06 D2 actual CPU Q1 runtime growth/reorder/source risk consumers under original mixed Apple/Vulkan core builds; not native GPU, SDK, san, P1 or aggregate G06 verdict')
def save():
 r['outer_elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
save()
with zipfile.ZipFile(base/('g06-cpu-q1-input-'+sys.argv[1]+'.zip')) as z:
 manifest=json.loads(z.read('input-manifest.json'));assert manifest['candidate']==r['candidate'];changed=[]
 for item in manifest['inputs']:
  relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
  data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
  dest=source/relative;assert dest.resolve().is_relative_to(source.resolve())
  if not dest.exists() or dest.read_bytes()!=data:
   dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(item['path'])
  assert hashlib.sha256(dest.read_bytes()).hexdigest()==item['sha256']
 (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 r['synced_files']=changed;r['input_count']=len(manifest['inputs']);r['one_way_canonical_sync']=True
save()
def run(route,stage,command,required=True):
 log=out/(route+'-'+stage+'.log');stamp=time.monotonic()
 with log.open('w') as stream:
  p=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
  r.update(state='RUNNING',route=route,stage=stage,child_pid=p.pid);save();print(route,stage,p.pid,flush=True);code=p.wait()
 row=dict(route=route,stage=stage,command=command,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log));r['stages'].append(row);r.pop('child_pid',None);save()
 if code:
  print(log.read_text(errors='replace')[-3500:],flush=True)
  if required:r['state']='TERMINAL_FAIL';save();raise SystemExit(code)
 return code
for route in ['apple','vulkan']:
 parent=base/f'a-cpu-{route}/selected-graph/source-parent';build=parent.parent/'source-build'
 cache=(build/'CMakeCache.txt').read_text();assert f'CMAKE_HOME_DIRECTORY:INTERNAL={parent}' in cache
 targets=['g06_cpu_q1']
 p=parent/'CMakeLists.txt';text=p.read_text()
 if 'add_executable(g06_cpu_q1 ' not in text:
  text+='\nadd_executable(g06_cpu_q1 "'+str(source/'tests/compute_provider_ggml/native_paged_test.cc')+'" "'+str(source/'tests/compute_provider_ggml/native_ragged_test.cc')+'" "'+str(source/'tests/compute_batch/encoded_page_common_consumer.cc')+'")\n'
  text+='target_compile_features(g06_cpu_q1 PRIVATE cxx_std_23)\ntarget_compile_options(g06_cpu_q1 PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(g06_cpu_q1 PRIVATE hyle::graph hyle::compute GTest::gtest_main)\nhyle_stage_runtime(g06_cpu_q1)\n'
  p.write_text(text)
 (out/(route+'-parent.cmake')).write_text(text)
 run(route,'configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build)])
 run(route,'prepare-manifest',['/opt/homebrew/bin/ninja','-C',str(build),'build.ninja'])
 preview=out/(route+'-preview.ninja');preview.write_bytes((build/'build.ninja').read_bytes())
 command=['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-n',*targets]
 dry=subprocess.check_output(command,env=env,text=True);(out/(route+'-dry-run.log')).write_text(dry)
 assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry
 assert 'ggml-cuda' not in dry
 run(route,'build',['/opt/homebrew/bin/cmake','--build',str(build),'--target',*targets,'--parallel','4'])
 for target in targets:run(route,target,[str(build/target)],required=False)
r['state']='TERMINAL_PASS' if all(s['exit_code']==0 for s in r['stages']) else 'TERMINAL_FAIL';save();print(r['state'],flush=True);raise SystemExit(0 if r['state']=='TERMINAL_PASS' else 1)
