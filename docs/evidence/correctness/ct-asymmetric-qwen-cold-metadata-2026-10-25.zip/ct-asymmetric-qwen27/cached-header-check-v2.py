from pathlib import Path
import hashlib,importlib.util,json,struct,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/ct-asymmetric-qwen27-20261025';C=R/'.scratch/ct-asymmetric-int4-header'
sys.path.insert(0,str(R));from engine.models.qwen35 import prepare as current
facts=json.loads((C/'header-facts.json').read_text());fixed=json.loads((C/'source-contract.json').read_text())
assert facts['revision']=='6e134bae811fb5adac50ee042ae5f029ac6779aa' and facts['tensor_count']==2396 and facts['quantized_roles']==399
def pin(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
config=json.loads((C/'config.json').read_text());assert pin(C/'config.json')['sha256']==fixed['retained_fixed_config']['sha256']
roles={};headers=[]
for entry in facts['files']:
 p=C/'headers'/Path(entry['header']['path']).name
 actual=pin(p);assert actual['bytes']==entry['header']['bytes']and actual['sha256']==entry['header']['sha256']
 headers.append(actual)
 for name,record in json.loads(p.read_bytes()).items():
  if name=='__metadata__':continue
  assert name not in roles
  roles[name]=dict(record,name=name,bytes=record['data_offsets'][1]-record['data_offsets'][0])
assert len(roles)==2396
all_header_tensors=len(roles)
roles={name:record for name,record in roles.items()if name.startswith(('model.language_model.','mtp.','lm_head.'))}
packed=current.ct_packed_groups(roles);policy=current.ct_asymmetric_policy(packed,config)
assert len(packed)==399 and all(g['asymmetric'] and g['group_size']==32 and g['scale_dtype']=='BF16'for g in packed.values())
geometry=current.geometry.from_hf(config);current.validate_role_geometry(roles,geometry)
assert len(current.logical_roles(roles))==len(current.geometry.role_shapes(geometry,include_mtp=True))
assert sum(n.startswith('mtp.')for n in roles)==15
# Non-asymmetric metadata output is compared directly to the frozen pre-edit source.
sys.path.insert(0,str(R/'engine/models/qwen35'))
spec=importlib.util.spec_from_file_location('prepare_before',W/'before/engine/models/qwen35/prepare.py');before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
spec=importlib.util.spec_from_file_location('host_fixtures',R/'tests/tooling/qwen_hf_roles_test.py');tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
original=tests.source_fixture();fixture_roles={r['name']:r for r in original['roles']};shapes=current.ct_packed_groups(fixture_roles)
def auth(role):return Path(role['path']),struct.pack('<qq',*shapes[role['name'][:-13]]['logical_shape'])if role['name'].endswith('.weight_shape')else None
old=before._prepare_role_records(original,False,tests.source_config(),auth);new=current._prepare_role_records(original,False,tests.source_config(),auth)
assert old==new
result=dict(status='PASS_CACHED_ORIGINAL_HEADERS',repository='cyankiwi/Qwen3.8-27B-AWQ-INT4',revision=facts['revision'],original_tensors=all_header_tensors,text_and_existing_MTP_physical_roles=len(roles),ordinary_selected_physical_roles=sum(not n.startswith('mtp.')for n in roles),original_asymmetric_groups=len(packed),complete_logical_roles=len(current.logical_roles(roles)),geometry=geometry,headers=headers,config=pin(C/'config.json'),reader_policy=policy,original_code_zero_scale_dtypes={'weight_packed':'I32[N,K/8]','weight_zero_point':'I32[ceil(N/8),K/32]','weight_scale':'BF16[N,K/32]','weight_shape':'I64[2]'},existing_MTP_plain_roles=15,new_MTP_functionality=False,original_weight_shape_payload_read=False,original_tensor_payload_bytes_read=0,SDK_builds=0,HTTP=0,unchanged_symmetric_fixture=dict(lines_and_receipt_exact_equal=True,physical_records=old[1]['metadata_tensor_count']),scope='Complete cached original headers + cold typed schema only; no authenticated body import, decode or model/provider execution.')
(W/'cached-header-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in('status','original_tensors','original_asymmetric_groups','complete_logical_roles','original_weight_shape_payload_read','unchanged_symmetric_fixture')},indent=2))
