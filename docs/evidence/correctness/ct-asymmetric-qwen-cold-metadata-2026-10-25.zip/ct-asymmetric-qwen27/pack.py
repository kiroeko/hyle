from pathlib import Path
import json,hashlib,difflib,shutil,zipfile
R=Path.cwd();W=R/'.scratch/ct-asymmetric-qwen27-20261025'
def pin(p):
 raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
paths=['engine/models/qwen35/prepare.py','engine/models/qwen35/prepared_roles.h','tests/tooling/qwen_hf_roles_test.py','tests/tools/qwen_prepared_roles_test.cc']
patch=''
for name in paths:
 before=(W/'before'/name).read_text();current=(R/name).read_text();patch+=''.join(difflib.unified_diff(before.splitlines(True),current.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 dst=W/'source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,dst)
(W/'changes.patch').write_text(patch)
save(W/'after-pins.json',[pin(R/p)for p in paths])
oldproof=R/'docs/evidence/correctness/ct-asymmetric-int4-header-2026-10-20.zip'
summary={'status':'PASS_COLD_METADATA_ONLY','scope':{'repository':'cyankiwi/Qwen3.8-27B-AWQ-INT4','revision':'6e134bae811fb5adac50ee042ae5f029ac6779aa','ordinary_CT_asymmetric_groups':399,'ordinary_selected_physical_roles':2048,'complete_text_and_existing_NextN_physical_roles':2063,'existing_BF16_NextN_roles':15,'full_original_headers_including_excluded_vision':2396,'new_MTP_functionality':False,'no_model_or_GPU':True,'original_numeric_payload_read':False,'source_weight_shape_I64_values_checked':False},'changes':['Recognize original I32 packed zero points alongN and exclude them from logical parameter inventory.','Require explicit source-derived CT asymmetric g32/BF16 reader policy; missing Z cannot silently select symmetric.','Distinct kCtAsymmetric4 typed selected principal, original codes/Z/scales/shape retained without conversion.','Reuse shape metadata helper for symmetric/asymmetric; subtraction/product remain existing Compute operator responsibilities.'],'interfaces':{'codec':'prepared::ProjectionCodec::kCtAsymmetric4','policy':'prepared::CtAsymmetricPolicy','roles_field':'Roles.ct_asymmetric_policy.enabled','manifest':__import__('sys').modules.get('unused',None)},'validation':{'CXX':{'strict':'MSVC /O2 /W4 /WX /permissive-','checks':356,'new_checks':14,'compile':json.loads((W/'host/compile/process.json').read_text()),'run':json.loads((W/'host/run/process.json').read_text())},'Python':{'tests':16,'new_tests':2,'run':json.loads((W/'python/process.json').read_text())},'cached_original_headers':json.loads((W/'cached-header-summary.json').read_text()),'private_header_first_failure':'cached-header-first-failure.json','private_header_fix':'Apply existing text-scope filter to333visual roles; keep15existing BF16 NextN metadata. No product repair or provider retry needed.','non_asymmetric_symmetric_fixture_lines_receipt_equal':True,'SDK_builds':0,'HTTP':0},'source_pins':json.loads((W/'after-pins.json').read_text()),'uncompleted':['Full original body authentication and actual I64 weight_shape values.','Consumer resolver/ProjectionBinding/ordinary Graph operation with zero input; main must fail fast before weight IO until that is connected.','Original numeric component and full ordinary engine are not certified by these metadata checks.'],'header_dependency':pin(oldproof)}
summary['interfaces']['manifest']='ct_asymmetric_int4\t32\tBF16\tpacked_N\tcompressed-tensors@ac8e2ba82f4e0d5eaa40069f8fc642738f124cd4'
binaries=[p for p in W.rglob('*')if p.is_file()and p.suffix.lower()in{'.obj','.exe','.pdb','.lib','.exp'}]
cleanup=dict(performed=False,files=[pin(p)for p in sorted(binaries)],logical_bytes=sum(p.stat().st_size for p in binaries));save(W/'cleanup-candidates.json',cleanup);summary['cleanup']=cleanup
save(W/'proof-summary.json',summary)
# Generated malformed TSV fixtures are recreatable and deliberately not duplicated.
files=[p for p in W.rglob('*')if p.is_file()and 'fixtures'not in p.parts and p.suffix.lower()not in{'.obj','.exe','.pdb','.lib','.exp','.zip'}and p.name not in{'archive.json','live.json'}]
with zipfile.ZipFile(W/'proof.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,'ct-asymmetric-qwen27/'+p.relative_to(W).as_posix())
save(W/'archive.json',dict(summary=pin(W/'proof-summary.json'),archive=pin(W/'proof.zip'),cleanup=pin(W/'cleanup-candidates.json'),files=len(files)))
print(json.dumps(json.loads((W/'archive.json').read_text()),indent=2));print('cleanup',len(binaries),cleanup['logical_bytes'])
