from pathlib import Path
import hashlib,importlib.util,json,sys,os
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/ct-asymmetric-qwen27-20261025'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
paths=['engine/models/qwen35/prepare.py','engine/models/qwen35/prepared_roles.h','tests/tooling/qwen_hf_roles_test.py','tests/tools/qwen_prepared_roles_test.cc']
pins=[b.pin(R/p)for p in paths];b.save(W/'check-source-pins.json',pins)
recipe=b.args(R/'.scratch/inference-system-review-20261025/nf4-metadata/host2/compile/command.json')
cmd=[a for a in recipe if not a.lower().startswith(('/fe:','/fo:','/fd:'))]
at=cmd.index('/link');cmd[at:at]=['/Fe:'+str(W/'host/checks.exe'),'/Fo:'+str(W/'host/checks.obj'),'/Fd:'+str(W/'host/checks.pdb')]
env=b.environment(recipe[0]);env['PYTHONDONTWRITEBYTECODE']='1'
b.execute(cmd,W/'host/compile',env,60)
b.execute([str(W/'host/checks.exe'),str(W/'host/fixtures')],W/'host/run',env,30)
b.execute([sys.executable,str(R/'tests/tooling/qwen_hf_roles_test.py')],W/'python',env,30)
assert pins==[b.pin(R/p)for p in paths]
b.save(W/'host-summary.json',dict(status='PASS',scope='Cold source/role metadata only; no GPU, model, decoder build or network',cpp_stdout=(W/'host/run/stdout.log').read_text(),cpp=b.read(W/'host/run/process.json'),python=b.read(W/'python/process.json'),source_pins=pins,SDK_builds=0,HTTP=0))
print((W/'host/run/stdout.log').read_text());print((W/'python/stderr.log').read_text())
