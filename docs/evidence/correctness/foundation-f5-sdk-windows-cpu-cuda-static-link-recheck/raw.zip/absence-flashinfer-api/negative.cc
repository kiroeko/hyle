#include <hyle/compute/cuda.h>
void probe(){(void)hyle::compute::flashinfer::provider();}
