#include <hyle/compute/cuda.h>
#if !defined(HYLE_COMPUTE_CUDA)
#error CUDA route missing
#endif
void probe(){auto f=&hyle::compute::cuda::create_context;(void)f;}
