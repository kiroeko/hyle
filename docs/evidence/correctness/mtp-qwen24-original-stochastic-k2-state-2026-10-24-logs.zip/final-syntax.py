from pathlib import Path
import importlib.util,json,sys,difflib
sys.dont_write_bytecode=True
r=Path.cwd();s=r/'.scratch/qwen-multik-moe-20261024'
spec=importlib.util.spec_from_file_location('buildhelper',s/'build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=m.read(s/'compile1/command.json')['command'];cmd=[];skip=False
for x in base:
 if skip:skip=False;continue
 if x=='/sourceDependencies':skip=True;continue
 if x.startswith(('/Fo','/Fd')) or x.endswith('qwen_mtp_state_consumer_test.cc'):continue
 cmd.append(x)
cmd+=['/Zs',str(r/'tests/compute_models/qwen_mtp_state_consumer_test.cc')]
env=m.m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cmd[0],'CMAKE_CXX_COMPILER':cmd[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
m.m.b.execute(cmd,env,s/'final-syntax',timeout=120)
p=r/'tests/compute_models/qwen_mtp_state_consumer_test.cc';m.save(s/'final-syntax/source.json',m.ident(p))
(s/'final-syntax/source.cc').write_bytes(p.read_bytes())
a=(s/'source1/tests/compute_models/qwen_mtp_state_consumer_test.cc').read_text().splitlines(keepends=True);b=p.read_text().splitlines(keepends=True)
(s/'final-syntax/after-run-control-only.patch').write_text(''.join(difflib.unified_diff(a,b,fromfile='source1/qwen_mtp_state_consumer_test.cc',tofile='current/qwen_mtp_state_consumer_test.cc')))
