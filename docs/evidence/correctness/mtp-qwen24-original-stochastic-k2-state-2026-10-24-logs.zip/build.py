from pathlib import Path
import importlib.util,json,os,sys,hashlib,shutil
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('glib',R/'.scratch/glm-random-mtp-20261024/build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def compile(attempt):
 root=S/f'source{attempt}';root.mkdir(exist_ok=False)
 files=[R/'tests/compute_models/qwen_mtp_state_consumer_test.cc',*sorted((R/'tests/compute_models').glob('*.h')),*sorted((R/'engine/inference').glob('*.h'))]
 identities=[]
 for source in files:
  destination=root/source.relative_to(R);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination);identities.append(dict(original=ident(source),frozen=ident(destination)))
 save(S/f'source{attempt}-identities.json',identities)
 out=S/f'compile{attempt}';base=read(R/'.scratch/qwen27-target-verifier-20261023/compile1/qwen-state/compile.command.json')['command'];command=[];skip=False
 for flag in base:
  if skip:skip=False;continue
  if flag=='/sourceDependencies':skip=True;continue
  if flag.startswith(('/Fo','/Fd')) or flag.endswith('qwen_mtp_state_consumer_test.cc'):continue
  command.append(flag)
 command+=['/sourceDependencies',str(out/'deps.json'),str(root/'tests/compute_models/qwen_mtp_state_consumer_test.cc'),'/Fo'+str(out/'consumer.obj')]
 env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 m.b.execute(command,env,out,timeout=240)
 save(out/'identity.json',dict(source=ident(root/'tests/compute_models/qwen_mtp_state_consumer_test.cc'),object=ident(out/'consumer.obj'),dependencies=[ident(p) for p in read(out/'deps.json')['Data']['Includes']]))
def link(attempt):
 base=read(R/'.scratch/dspark-random-mtp-20261024/link-command.json');command=[x for x in base if not x.upper().startswith(('/OUT:','/IMPLIB:','/MAP:','/PDB:')) and not x.endswith('dspark-random-mtp-20261024\\consumer.obj')]
 image=S/f'checks{attempt}.exe';command.insert(1,str(S/f'compile{attempt}/consumer.obj'));command+=['/OUT:'+str(image),'/IMPLIB:'+str(S/f'checks{attempt}.lib')]
 compiler=str(Path(command[0]).with_name('cl.exe'));env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
 save(S/f'link{attempt}-inputs.json',[ident(x) for x in command if x.lower().endswith(('.obj','.lib')) and Path(x).is_absolute()]);m.b.execute(command,env,S/f'link{attempt}')
 save(S/f'ready{attempt}.json',dict(image=ident(image),new_SDK_TUs=0,consumer_TUs=1,source_manifest=ident(S/f'source{attempt}-identities.json')))
 dll=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
 if not (S/dll.name).exists():os.link(dll,S/dll.name)
def run(attempt,image_attempt):
 env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_QWEN')};env['PATH']=str(S)+';'+read(R/'.scratch/dspark-random-mtp-20261024/runtime.json')['PATH']
 env.update(HYLE_QWEN24_MTP_KV_DIR=str(R/'.scratch/qwen24-original-mtp-20261022/original-q24'),HYLE_QWEN24_ORIGINAL_NEXTN_DIR=str(R/'.scratch/q24-original-nextn-20261023/original-q24-nextn'),HYLE_QWEN24_ORIGINAL_TARGET_DIR=str(R/'.scratch/q24-target-verifier-20261023/original-target91'))
 folder=S/f'run{attempt}';save(S/f'run{attempt}-inputs.json',{k:v for k,v in env.items() if k.startswith('HYLE_QWEN')})
 ready=read(S/f'ready{image_attempt}.json');assert ident(ready['image']['path'])==ready['image']
 command=[ready['image']['path'],'--gtest_filter=QwenMtpStateConsumer.CudaQ24OriginalTargetAndNextNK2RandomVerifierContinuesAtomically','--gtest_output=xml:'+str(folder/'results.xml')]
 m.b.execute(command,env,folder,timeout=600)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('actions',nargs='+',choices=['compile','link','run']);p.add_argument('--attempt',type=int,default=1);p.add_argument('--image-attempt',type=int,default=1);a=p.parse_args()
 for action in a.actions:
  if action=='run':run(a.attempt,a.image_attempt)
  else:globals()[action](a.attempt)
