from pathlib import Path
import hashlib
import json
import subprocess

base = Path(__file__).resolve().parent
root = base.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
pins = json.loads((base/'after-pins.json').read_text('utf-8'))
for pin in pins:
    if pin['path'].endswith('main.cc'): continue
    assert (root/pin['path']).read_bytes().replace(b'\r\n',b'\n') == (base/'source'/pin['path']).read_bytes().replace(b'\r\n',b'\n')
changed = subprocess.check_output(['git','diff','--name-only','-z'],cwd=root).decode().split('\0')
assert sorted(x for x in changed if x) == sorted(x['path'] for x in pins)
main = root/'engine/models/qwen35/main.cc'
summary = dict(status='NF4_LOCAL_PATCH_APPLIED_OVER_SAMPLING_CANDIDATE',
    sampling_main_sha256='2a261e1a34f367128809c79154a1a96d91f2759b30346d7806994c5feca018bb',
    NF4_private_main_sha256=pins[0]['sha256'], combined_main_sha256=sha(main.read_bytes()), bytes=main.stat().st_size,
    header_equivalence='Both changed headers exactly equal their actual-run private sources after CRLF-to-LF normalization.',
    initial_post_apply_check='Patch check and application succeeded. Initial post-apply raw header hash assertion failed because private headers had CRLF and canonical patch has LF; normalized source is identical. No reapplication or rollback occurred.',
    scope='Only the three reviewed NF4 files differ from committed sampling implementation; combined source compilation remains separate.')
(base/'canonical-integration.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
