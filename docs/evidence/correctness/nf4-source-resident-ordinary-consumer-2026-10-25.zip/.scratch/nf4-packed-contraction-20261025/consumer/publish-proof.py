from pathlib import Path
import json,hashlib,shutil,re,zipfile
R=Path.cwd();W=R/'.scratch/nf4-packed-contraction-20261025/consumer';pub=R/'docs/evidence/correctness'
def load(p):return json.loads(Path(p).read_text())
def pin(p):p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,j):Path(p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
# Preserve exact canonical post-merge files independently from the actual-run private image.
final=W/'product-final';final.mkdir();paths=['engine/models/qwen35/main.cc','engine/models/qwen35/projection_binding.h','engine/models/qwen35/nf4_weight_import.h','engine/models/qwen35/prepare.py','tests/tooling/qwen_hf_roles_test.py'];products=[]
for n in paths:
 p=R/n;t=final/n;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t);products.append(pin(p))
assert products[0]['sha256']=='7ac7ae01c4b56632822689f2456fc46eed8f9003c7a7ba0e2ba852e647a18fca'
save(final/'pins.json',products)
comparisons=load(W/'same-geometry-old-cold-import-comparison.json');comparepins=[]
for x in comparisons:
 old=R/x['old_folder'];new=R/x['new_folder']
 for p in sorted(old.rglob('*')):
  if p.is_file():comparepins.append(dict(old=pin(p),new=pin(new/p.relative_to(old)),byte_equal=p.read_bytes()==(new/p.relative_to(old)).read_bytes()))
save(W/'same-geometry-comparison-pins.json',comparepins)
results={};plans={}
for kind in ['cpu','cuda']:
 results[kind]=json.loads((W/f'ga1/{kind}/run/stdout.log').read_text().strip())
 log=(W/f'ga1/{kind}/run/stderr.log').read_text();plans[kind]=[dict(projections=int(a),packed=int(b),decomposed=int(c),whole_graph_workspace_bytes=int(d))for a,b,c,d in re.findall(r'original_quantized_projections=(\d+) packed_contractions=(\d+) decomposed_projections=(\d+) graph_workspace_bytes=(\d+)',log)]
 assert len(plans[kind])==2
cleanup=[p for p in W.rglob('*')if p.is_file()and p.suffix.lower()in{'.obj','.exe','.exp','.lib','.pdb','.dll'}]
clean=dict(performed=False,files=[pin(p)for p in sorted(cleanup)],logical_bytes=sum(p.stat().st_size for p in cleanup),scope='Only this private consumer entry/image/hardlink. The five new low-level NF4 leaves and original SDK/clean baseline are excluded and remain reusable.')
save(W/'cleanup-candidates.json',clean)
summary=dict(status='PASS_SOURCE_RETAINING_NF4_ORDINARY_CONSUMER',
 scope='One existing ordinary Qwen target path with original six-operand NF4 binding, F16 activation/state profile, actual planner-selected packed/decomposed routes and original state/lease/retirement machinery. Both executed models are small untrained GA fixtures, not the original full27B artifact or a generation-quality test.',
 implementation=dict(changed_files=products,private_actual_patch=pin(W/'consumer-changes.patch'),
 source_bank='Same LoadedWeight map owns original codes, absmax, nested_absmax, nested_quant_map, exact F32 offset and quant_map; authenticated JSON remains metadata and source accounting only. No decoded full-bank cache/second loader.',
 cold_validation='Single validate_nf4_decode_inputs checks authenticated JSON SHA/values, source shape, all real Ready leases/resource and exact F32 offset. Explicit standalone cold import delegates to it; source-retaining loader invokes it without Decode.',
 projection='Nf4Projection borrows six stable Tensor children; same public Decode(F16)->transpose View->F32-accumulation F16 MatMul recipe. Engine constructs no private packed op and checks no provider names.',
 fallback='Cold Graph selects contraction or original decomposition. Default CPU multirow policy remains unchanged. Its Graph workspace and provider-private unknown bounds are not hidden behind compressed source bytes.',
 retirement='Original ColdResources/Backend/Graph domains retain the six source Ready owners and actual output leases until original terminal retirement; no additional state/resource executor.'),
 actual=results,actual_default_plans=plans,
 actual_weight_inventory=dict(resident_Tensors_per_fixture=32,NF4_original_source_group_bytes=3339,NF4_numeric_ready_bytes=3208,generated_offset_bytes=4,JSON_not_uploaded=True,
 CPU_source_fixture_bytes=186383,CPU_resident_canonical_bank_bytes=186252,CUDA_source_fixture_bytes=211731,CUDA_resident_canonical_bank_bytes=211600,
 group_known_mapping_plus_copy_bytes=6547,source_group_fields_not_global_peak_measurement=True,
 full_original27B_canonical_packed_bank_estimate=None,full_model_memory_measured=False),
 actual_state_and_sampling=dict(prefill_rows=2,decode_rows=1,same_request_pending_and_RNG_restore_replays_exact_state=True,new_request_prefix_own_stream_sampling=True,
 nonzero_GDN_history_and_recurrent=True,old_Snapshot_bytes_unchanged=True,actual_retirement_and_bounded_cache=True,
 state_types='F16 activation/history/KV/hidden and F32 recurrent/gates/convolution',
 offline_same_geometry_old_cold_import_comparison=comparisons,offline_file_pins=pin(W/'same-geometry-comparison-pins.json'),
 no_cross_device_numeric_comparison=True),
 source_versions=dict(actual_private_main_sha256=pin(W/'ga1/source/engine/models/qwen35/main.cc')['sha256'],
 actual_baseline_main_sha256='2da022c6a43b3d37f4ad85524a47933d386cfc89b77683a89aa2de399a99ef43',
 canonical_post_merge_main_sha256=products[0]['sha256'],
 canonical_merge_followup=load(W/'canonical-integration.json'),
 canonical_followup_strict=load(R/'.scratch/inference-packed-sampling-interface-20261025/summary.json'),
 followup_scope='Canonical merged sampling+NF4 source passed CPU/CUDA lifecycle/chunked/dual/sampling interface strict syntax. No extra GPU inference after merging; changed header bodies equal actual-run private headers after newline normalization.'),
 metadata_receipt=dict(description='Preparation is metadata-only; runtime consumer retains source operands and reports actual packed/decomposition/workspace; full artifact remains unverified.',
 source_pins=pin(W/'metadata-receipt/pins.json'),host_cases=16,host_process=load(W/'metadata-receipt/run/process.json')),
 execution_accounting=dict(private_syntax_processes=1,consumer_compile_TUs=1,consumer_links=1,actual_CPU_model_processes=1,actual_CUDA_model_processes=1,
 host_metadata_test_processes=1,full_original_model_runs=0,HTTP_requests=0,SDK_rebuilds=0,
 all_actual_processes_terminal=True,GPU_released=True),
 boundaries=['CPU C192 and CUDA C256 are distinct original already-used tiny geometries; each is compared only with its own earlier fixture.','CPU P2 legitimately selects decomposition; packed source residency does not mean every backend/row shape executes a packed kernel.','CUDA P2/T1 real packed plans have no Graph dense-W intermediate, per the existing cold report check.','Opaque provider temporaries are not independently measured. Whole Graph workspace includes all GDN/attention work.','No MTP functionality, full27B execution, throughput, whole-model quality or all-backend completion claim.','The standalone F16 import API still exists, but this engine path does not eagerly create that decoded resident bank.'],
 related_evidence=[dict(path='docs/evidence/correctness/nf4-packed-ordinary-cpu-cuda-2026-10-25.zip',sha256='72c5a0c1a6c2914e7176d1651f98af8ff2e55ab10c0242ba526790b113de478b'),dict(path='docs/evidence/correctness/nf4-f16-profile-and-cold-import-2026-10-25.zip',sha256='a000f80c35b0185bc67ab69331e3129a6afdc4fb9f38bf46c723b6ab7b93b913')],cleanup=clean)
save(W/'proof-summary.json',summary)
files=set();blocked={'.obj','.exe','.lib','.exp','.pdb','.dll','.zip'};omitted=[]
for p in W.rglob('*'):
 if not p.is_file()or p.name=='payload-manifest.json' or p.suffix.lower()in blocked:continue
 if p.name=='untrained-f16.bin':omitted.append(pin(p));continue
 files.add(p)
follow=R/'.scratch/inference-packed-sampling-interface-20261025'
for p in follow.rglob('*'):
 if p.is_file()and p.suffix.lower()not in blocked:files.add(p)
files.add(R/'.scratch/mtp-extraction-regression-20261024/check.py')
# The actual five-leaf closure is frozen in the immediately prior low-level proof;
# retain exact link argv and its current leaf pins, without republishing large libraries.
files.add(R/'.scratch/nf4-packed-contraction-20261025/after-pins.json')
payloads={};entries=[];source_store={}
for p in sorted(files):
 row=pin(p);source=('source'in p.parts or'product-final'in p.parts)and p.suffix.lower()in{'.h','.cc','.py','.txt'}
 if source and row['sha256']in source_store:target=source_store[row['sha256']]
 else:
  target=row['path'];payloads[target]=p
  if source:source_store[row['sha256']]=target
 row['archive_payload']=target;entries.append(row)
save(W/'payload-manifest.json',dict(entries=entries,intentionally_omitted_generated_fixture_bodies=omitted,
 reproduction='Fixture generator and exact body pins are retained; no original new HTTP or full-model body is required. Actual old state files are in the previous F16 proof ZIP by the pinned paths; new files and pairwise SHA audit are here. Compiler/SDK/native closure paths are environment identities, not archive promises.'))
payloads[(W/'payload-manifest.json').relative_to(R).as_posix()]=W/'payload-manifest.json'
archive=pub/'nf4-source-resident-ordinary-consumer-2026-10-25.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(payloads.items()):z.write(p,name)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for row in entries:
  b=z.read(row['archive_payload']);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
public=dict(summary);public['archive']={**pin(archive),'CRC_verified':True,'payloads':len(payloads),'path_mapping':(W/'payload-manifest.json').relative_to(R).as_posix()}
save(pub/'nf4-source-resident-ordinary-consumer-2026-10-25.json',public)
print(json.dumps(dict(archive=public['archive'],cleanup_files=len(cleanup),cleanup_bytes=clean['logical_bytes'],canonical_main=products[0]['sha256'],all_runs_terminal=True,GPU_released=True),indent=2))
