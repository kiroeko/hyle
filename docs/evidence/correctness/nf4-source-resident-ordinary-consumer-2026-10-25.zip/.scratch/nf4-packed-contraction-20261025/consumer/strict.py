from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/nf4-packed-contraction-20261025/consumer'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
base=b.args(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json');cmd=[base[0],'/I'+str(W/'source')];skip=False
for arg in base[1:]:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 low=arg.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(arg)
cmd+=['/Zs',str(W/'syntax.cc'),'/sourceDependencies',str(W/'strict1/dependencies.json')]
b.execute(cmd,W/'strict1',b.environment(base[0]),90)
