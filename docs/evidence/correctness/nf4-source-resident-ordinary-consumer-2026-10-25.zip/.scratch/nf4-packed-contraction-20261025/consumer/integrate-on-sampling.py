from pathlib import Path
import hashlib
import json
import subprocess

base = Path(__file__).resolve().parent
root = base.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
main = root / 'engine/models/qwen35/main.cc'
assert sha(main.read_bytes()) == '2a261e1a34f367128809c79154a1a96d91f2759b30346d7806994c5feca018bb'
pins = json.loads((base/'after-pins.json').read_text('utf-8'))
for item in pins:
    data = (base/'source'/item['path']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256'], item['path']
patch = base/'consumer-changes.patch'
normalized = base/'consumer-changes-lf.patch'
normalized.write_bytes(patch.read_bytes().replace(b'\r\n',b'\n'))
before = main.read_bytes()
for arguments in (['git','apply','--check',str(normalized)], ['git','apply',str(normalized)]):
    subprocess.run(arguments, cwd=root, check=True)
for item in pins:
    if item['path'].endswith('main.cc'): continue
    assert (root/item['path']).read_bytes().replace(b'\r\n',b'\n') == (base/'source'/item['path']).read_bytes().replace(b'\r\n',b'\n')
result = dict(status='NF4_LOCAL_PATCH_APPLIED_OVER_SAMPLING_CANDIDATE',
    sampling_main_sha256=sha(before), NF4_private_main_sha256=pins[0]['sha256'],
    combined_main_sha256=sha(main.read_bytes()), bytes=len(main.read_bytes()),
    scope='Only reviewed NF4 loader, projection, reporter and shared metadata-validation hunks. No overwrite of the independent sampling implementation. Combined consumer compilation still required.')
(base/'canonical-integration.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
