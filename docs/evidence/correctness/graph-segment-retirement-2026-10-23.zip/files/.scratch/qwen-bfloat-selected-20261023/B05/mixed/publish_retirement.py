"""Publish the recorded Graph segment-retirement before/after check only.

No build, inference, network, model payload or SDK copying is performed here.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
SOURCE = BASE.parent / "graph-retirement-source"
NAME = "graph-segment-retirement-2026-10-23"
CASE = "LeasedWaitRetiresEarlierQueuePrefixesBeforePublishingResults"
EXPECTED_CASES = {
    "ObservationErrorKeepsAllAcceptedCublasBranchesAlive",
    "LeasedGraphOwnsBindingsAndOldResultsPreventReplay",
    "LeasedPrivateOutputRetainsOriginalWorkspaceAfterAdapterDestruction",
    CASE,
}
PRODUCTS = ("src/graph/submission.cc", "src/graph/executable.cc")
OLD_RECORDS = (
    ".scratch/qwen-capture-variants-20261022/compile3/submission/identity.json",
    ".scratch/qwen-mtp-next-20261022/compile4/executable/identity.json",
)


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def identity(path: Path):
    # All hashes here are small source/metadata/object identities, not weights.
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError(f"unexpected large metadata input: {path}")
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def verify_record(record, path: Path | None = None):
    actual = identity(path or Path(record["path"]))
    assert (actual["bytes"], actual["sha256"]) == (record["bytes"], record["sha256"]), record
    return actual


def collect():
    files: set[Path] = {Path(__file__).resolve()}

    def keep(path: Path):
        path = path.resolve()
        assert path.is_file() and path.is_relative_to(ROOT), path
        assert path.suffix.lower() in {".json", ".log", ".xml", ".cc", ".patch", ".py"}, path
        files.add(path)
        return identity(path)

    final_freeze_path = SOURCE / "source2/freeze.json"
    final_freeze = load(final_freeze_path)
    source1_freeze_path = SOURCE / "freeze.json"
    assert identity(source1_freeze_path)["sha256"] == final_freeze["previous_freeze_sha256"]
    keep(source1_freeze_path)
    keep(final_freeze_path)
    source_items = {item["path"]: item for item in final_freeze["sources"]}
    sources = []
    for product in PRODUCTS:
        after = SOURCE / "final" / product
        verify_record(source_items[product], after)
        # Freeze the compiled patch, not unrelated later workspace changes.
        sources.append({"product": product, "before": keep(SOURCE / "before" / product),
                        "after": keep(after)})
    test_path = SOURCE / "source2/aggregate_native_retirement_test.cc"
    verify_record(source_items["tests/graph/aggregate_native_retirement_test.cc"], test_path)
    test_source = keep(test_path)

    old = [load(ROOT / path) for path in OLD_RECORDS]
    new_paths = [BASE / "compile1" / name / "identity.json"
                 for name in ("graph-submission", "graph-executable")]
    new = [load(path) for path in new_paths]
    test_record_path = BASE / "compile2/retirement-test/identity.json"
    test = load(test_record_path)
    assert test["source"]["sha256"] == test_source["sha256"]
    compiler_records = []
    for index, (old_item, new_item) in enumerate(zip(old, new)):
        assert old_item["source"]["sha256"] == sources[index]["before"]["sha256"]
        assert new_item["source"]["sha256"] == sources[index]["after"]["sha256"]
    for role, paths in (("old_product", [ROOT / path for path in OLD_RECORDS]),
                        ("new_product", new_paths), ("shared_final_test", [test_record_path])):
        for path in paths:
            record = load(path)
            verify_record(record["object"])
            verify_record(record["recipe"])
            result = load(path.parent / "compile.result.json")
            assert result["terminal"] and result["exit"] == 0
            compiler_records.append({"role": role, "identity": keep(path),
                                     "source": record["source"], "object": record["object"],
                                     "recipe": keep(Path(record["recipe"]["path"]))})
            for suffix in ("compile.command.json", "compile.result.json", "compile.stdout.log", "compile.stderr.log"):
                keep(path.parent / suffix)
    for path, record in zip(new_paths + [test_record_path], new + [test]):
        snapshot = path.parent / "source" / Path(record["source"]["path"]).relative_to(ROOT)
        verify_record(record["source"], snapshot)
        keep(snapshot)

    links = []
    plans = []
    for number in (3, 4):
        folder = BASE / f"tests-link{number}"
        plan = load(folder / "link-plan.json")
        plans.append(plan)
        result = load(folder / "link.result.json")
        assert result["terminal"] and result["exit"] == 0
        assert result["command"] == plan["command"]
        assert all(plan[key] == 0 for key in ("SDK_builds", "native_CPU_builds", "NVCC_builds", "shaders"))
        links.append({"old_graph": number == 3, "plan": keep(folder / "link-plan.json"),
                      "inputs": plan["inputs"], "result": keep(folder / "link.result.json")})
        for suffix in ("link.command.json", "link.stdout.log", "link.stderr.log", "runtime-environment.json"):
            keep(folder / suffix)
    old_inputs = {item["path"].lower(): item for item in plans[0]["inputs"]}
    new_inputs = {item["path"].lower(): item for item in plans[1]["inputs"]}
    assert set(old_inputs) - set(new_inputs) == {item["object"]["path"].lower() for item in old}
    assert set(new_inputs) - set(old_inputs) == {item["object"]["path"].lower() for item in new}
    assert all(old_inputs[key] == new_inputs[key] for key in old_inputs.keys() & new_inputs.keys())
    for plan, records in zip(plans, (old, new)):
        inputs = {item["path"].lower(): item for item in plan["inputs"]}
        for record in records + [test]:
            assert inputs[record["object"]["path"].lower()] == record["object"]

    runs = []
    for number in (3, 4):
        folder = BASE / f"checks{number}"
        summary = load(folder / "summary.json")
        process = summary["process"]
        assert process["finished"] and not process["timed_out"]
        assert not process["throughput_evidence"] and not process["memory_evidence"]
        assert not process["trace"] and not process["profiler"]
        expected_image = BASE / f"tests-link{number}/graph-retirement-checks.exe"
        assert Path(process["command"][0]) == expected_image == Path(summary["image"]["path"])
        assert expected_image.stat().st_size == summary["image"]["bytes"]
        out_option = "/out:" + str(expected_image).lower()
        assert out_option in [arg.lower() for arg in plans[number - 3]["command"]]
        xml = ET.parse(folder / "results.xml").getroot()
        cases = xml.findall(".//testcase")
        assert int(xml.attrib["tests"]) == summary["tests"] == len(cases)
        assert int(xml.attrib["failures"]) == summary["failures"]
        assert summary["skips"] == summary["disabled"] == summary["errors"] == 0
        assert all(not case.findall("skipped") and case.attrib["status"] == "run" for case in cases)
        if number == 3:
            assert summary["old_graph"] and summary["expected_failure"]
            assert process["exit"] == 1 and summary["tests"] == summary["failures"] == 1
            assert cases[0].attrib["name"] == CASE
            failures = [failure.text or "" for failure in cases[0].findall("failure")]
            # Both episodes reached wait/result; this is not the earlier fixture rejection.
            assert len(failures) == 12
            assert sum("invocation.in_flight()" in text for text in failures) == 2
            assert sum("pool.stats().active_uses" in text and "Which is: 4" in text for text in failures) == 2
            assert sum("host_pool.stats().active_uses" in text and "Which is: 1" in text for text in failures) == 2
            assert sum("result.has_value()" in text for text in failures) == 4
            assert not any("device_wait_dependency_count" in text for text in failures)
        else:
            assert not summary["old_graph"] and not summary["expected_failure"]
            assert process["exit"] == 0 and summary["tests"] == 4 and summary["failures"] == 0
            assert {case.attrib["name"] for case in cases} == EXPECTED_CASES
            assert all(not case.findall("failure") for case in cases)
        runs.append({"classification": "expected_old_bug" if number == 3 else "new_graph_regression_pass",
                     "summary": summary, "summary_record": keep(folder / "summary.json"),
                     "xml": keep(folder / "results.xml")})
        for suffix in ("command.json", "stdout.log", "stderr.log"):
            keep(folder / suffix)

    fixture_history = []
    for number in (1, 2):
        folder = BASE / f"checks{number}"
        summary = load(folder / "summary.json")
        xml = ET.parse(folder / "results.xml").getroot()
        failure_text = "\n".join(item.text or "" for item in xml.findall(".//failure"))
        assert "device_wait_dependency_count" in failure_text
        fixture_history.append({"classification": "fixture_failure_not_old_bug_proof",
                                "summary": keep(folder / "summary.json"), "xml": keep(folder / "results.xml")})
        for suffix in ("command.json", "stdout.log", "stderr.log"):
            keep(folder / suffix)

    evidence = {
        "schema_version": 1, "id": NAME, "date": "2026-10-23",
        "conclusion": "The same final regression reproduces the old Graph retirement bug and passes with the two-source public Graph fix; all four available GraphNativeRetirement cases pass.",
        "scope": "Public ordinary Graph segment completion/leased-result retirement. No model payload, full-model, quality, throughput, peak-memory or cross-backend claim.",
        "root_cause": "Each accepted segment held its own submission guard, while final completion selected only the latest Queue prefixes. Earlier native Completion guards could remain after wait, preventing result publication.",
        "change": "Collect every valid accepted segment from the current episode for success and synchronous tail rejection; size cold aggregate cells by actual segment count. Preserve zero-native rejection and original native retirement/error/output gates.",
        "fixture": "One CUDA Context, two compute/transfer Queues: direct device MatMul, actual pinned-input H2D, second MatMul. The early compute Completion remains asynchronous and is omitted from the old per-lane completion set. Both replays check successful wait, both actual results and zero device/host lease uses. Only the test settles leftover old guards after recording failure.",
        "sources": sources, "shared_final_test_source": test_source,
        "source_freeze": identity(final_freeze_path), "compilation": compiler_records,
        "link_difference": "The test object and all other link inputs are identical; only the two Graph product objects differ.",
        "links": links, "runs": runs, "fixture_history": fixture_history,
        "counts": {"expected_old_failure_cases": 1, "new_passed_cases": 4, "new_failed_cases": 0, "new_skipped_cases": 0},
        "timing_scope": "Recorded subsecond runs were correctness checks while B05 was waiting at an authenticated expert acquisition frontier. Times are not TPS/performance evidence; B05 success is not required or claimed.",
        "archive_policy": "Only listed source snapshots, recipes, identity records, commands, logs and XML. Link input objects/images are identified but not copied; no weight body or SDK tree.",
    }
    return evidence, files


def main():
    evidence, files = collect()
    output = ROOT / "docs/evidence/correctness"
    output.mkdir(parents=True, exist_ok=True)
    archive = output / (NAME + ".zip")
    raw = (json.dumps(evidence, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        zipped.writestr("evidence.json", raw)
        for path in sorted(files):
            zipped.write(path, "files/" + path.relative_to(ROOT).as_posix())
    evidence["archive"] = identity(archive)
    destination = output / (NAME + ".json")
    destination.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"evidence": identity(destination), "archive": evidence["archive"]}, indent=2))


if __name__ == "__main__":
    main()
