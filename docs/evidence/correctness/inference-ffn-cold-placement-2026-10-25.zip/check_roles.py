from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import discover_environment

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def execute(command, env, folder, timeout):
    folder.mkdir(parents=True, exist_ok=True)
    save(folder / 'command.json', dict(command=command, cwd=str(ROOT), timeout_seconds=timeout))
    start = time.monotonic()
    with (folder / 'stdout.log').open('wb') as stdout, (folder / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        save(folder / 'running.json', dict(pid=process.pid))
        print('START', folder.name, process.pid, flush=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill(); process.wait(); code = -999
    save(folder / 'process.json', dict(pid=process.pid, exit=code, seconds=time.monotonic()-start))
    print('END', folder.name, code, round(time.monotonic()-start, 3), flush=True)
    print((folder / 'stdout.log').read_text(encoding='utf-8', errors='replace')[-5000:], flush=True)
    print((folder / 'stderr.log').read_text(encoding='utf-8', errors='replace')[-3000:], flush=True)
    return code

def main():
    attempt = WORK / (sys.argv[1] if len(sys.argv) > 1 else 'roles1')
    assert not attempt.exists(), 'Keep previous raw output and use a new attempt name'
    pins = json.loads((WORK / 'source-pins.json').read_text())['files']
    overrides = {p['path']: p for p in pins}
    for pin in pins:
        assert identity(WORK / 'source' / pin['path'])['sha256'] == pin['after_sha256']
    tree = attempt / 'source'
    queue = ['tests/tools/qwen_prepared_roles_test.cc']
    seen = set()
    records = []
    directories = [ROOT / 'include', ROOT, ROOT / 'engine', ROOT / 'tests/tools']
    while queue:
        name = queue.pop()
        if name in seen: continue
        seen.add(name)
        source = WORK / 'source' / name if name in overrides else ROOT / name
        data = source.read_bytes()
        dest = tree / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        records.append(dict(relative=name, original=identity(source), frozen=identity(dest), overlay=name in overrides))
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"', data.decode('utf-8-sig'), re.M):
            for directory in [(ROOT / name).parent, *directories]:
                path = (directory / include).resolve()
                try: child = path.relative_to(ROOT).as_posix()
                except ValueError: continue
                if child in overrides or path.is_file():
                    queue.append(child); break
    fixture = 'tests/tooling/fixtures/qwen_nf4_quant_state.json'
    dest = tree / fixture
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((ROOT / fixture).read_bytes())
    assert {p for p in overrides if not p.endswith('/main.cc')}.issubset(seen)
    save(attempt / 'frozen-source.json', records)
    save(attempt / 'source-pins.json', pins)
    compiler = json.loads((ROOT / '.scratch/inference-sampling-range-20261025/cpu/candidate2/compile/command.json').read_text())['command'][0]
    env = discover_environment(compiler='msvc', cache=dict(CMAKE_C_COMPILER=compiler, CMAKE_CXX_COMPILER=compiler, CMAKE_GENERATOR='Ninja'), backends=()).env
    image = attempt / 'qwen-roles.exe'
    command = [compiler, '/nologo', '/std:c++latest', '/EHsc', '/O2', '/MD', '/W4', '/WX',
        '/utf-8', '/permissive-', '/Zc:preprocessor', '/Zc:__cplusplus', '/wd4324', '/wd4702',
        '/DNOMINMAX', '/DHYLE_STATIC', '/I'+str(tree/'include'), '/I'+str(tree),
        str(tree/'tests/tools/qwen_prepared_roles_test.cc'), '/sourceDependencies', str(attempt/'dependencies.json'),
        '/Fo'+str(attempt/'unit.obj'), '/Fd'+str(attempt/'unit.pdb'), '/Fe'+str(image), '/link', '/INCREMENTAL:NO']
    code = execute(command, env, attempt/'compile', 120)
    if code: raise RuntimeError('roles compile/link failed; raw kept')
    code = execute([str(image), str(attempt/'fixtures')], env, attempt/'run', 30)
    deps = json.loads((attempt/'dependencies.json').read_text())['Data']
    save(attempt/'actual-dependencies.json', [identity(Path(x)) for x in dict.fromkeys([deps['Source'], *deps['Includes']])])
    save(attempt/'summary.json', dict(result='PASS' if code == 0 else 'FAIL', kind='standard-library-only metadata test',
        frozen_project_files=len(records), source_pins=pins, compile_exit=0, run_exit=code,
        native_or_model_loading=False, sdk_core_provider_rebuilds=0))
    if code: raise RuntimeError('roles regression failed; raw kept')

if __name__ == '__main__': main()
