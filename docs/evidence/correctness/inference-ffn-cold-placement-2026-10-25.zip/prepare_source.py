from pathlib import Path
import difflib
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
FILES = [
    'engine/models/qwen35/prepared_roles.h',
    'engine/models/qwen35/ffn_placement.h',
    'engine/models/qwen35/main.cc',
    'tests/tools/qwen_prepared_roles_test.cc',
]
before = {}
source = {}
for name in FILES:
    path = ROOT / name
    data = path.read_bytes() if path.exists() else b''
    before[name] = data
    source[name] = data.decode().replace('\r\n', '\n')
assert hashlib.sha256(before[FILES[2]]).hexdigest() == 'c7fa995914c3258cef15cf05352d72db56579f184893b077ee7fd3eccbc0b3eb'

def replace(name, old, new, count=1):
    assert source[name].count(old) == count, (name, old, source[name].count(old))
    source[name] = source[name].replace(old, new)

roles, placement, main, test = FILES
replace(roles, '#include <map>\n', '#include <map>\n#include <optional>\n')
replace(roles, '  bool linear = false, allow_f32 = false;\n',
    '  bool linear = false, allow_f32 = false;\n'
    '  // Derived model ownership, never a prepared-manifest placement switch.\n'
    '  std::optional<std::size_t> target_ffn_layer{};\n')
replace(roles,
    '                       bool linear = false, bool allow_f32 = false) {\n'
    '    result.emplace(std::move(name), Parameter{{shape.begin(), shape.end()}, linear, allow_f32});\n',
    '                       bool linear = false, bool allow_f32 = false,\n'
    '                       std::optional<std::size_t> target_ffn_layer = {}) {\n'
    '    result.emplace(std::move(name), Parameter{{shape.begin(), shape.end()}, linear, allow_f32, target_ffn_layer});\n')
replace(roles,
    '  const auto common = [&](const std::string &p) {\n'
    '    add(p + "input_layernorm.weight", {h}, false, true);\n'
    '    add(p + "post_attention_layernorm.weight", {h}, false, true);\n'
    '    add(p + "mlp.gate_proj.weight", {ff, h}, true);\n'
    '    add(p + "mlp.up_proj.weight", {ff, h}, true);\n'
    '    add(p + "mlp.down_proj.weight", {h, ff}, true);\n'
    '  };\n',
    '  const auto common = [&](const std::string &p, std::optional<std::size_t> target_ffn_layer) {\n'
    '    add(p + "input_layernorm.weight", {h}, false, true);\n'
    '    add(p + "post_attention_layernorm.weight", {h}, false, true, target_ffn_layer);\n'
    '    add(p + "mlp.gate_proj.weight", {ff, h}, true, false, target_ffn_layer);\n'
    '    add(p + "mlp.up_proj.weight", {ff, h}, true, false, target_ffn_layer);\n'
    '    add(p + "mlp.down_proj.weight", {h, ff}, true, false, target_ffn_layer);\n'
    '  };\n')
replace(roles, '    common(p);\n', '    common(p, i);\n')
replace(roles, '    common("mtp.layers.0."); full_attention("mtp.layers.0.");\n',
    '    common("mtp.layers.0.", {}); full_attention("mtp.layers.0.");\n')

source[placement] = '''#pragma once

#include <cstddef>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>

#include "prepared_roles.h"

namespace qwen35 {
// One cold requested placement, shared by weight loading and graph assembly.
// BackendSelection still owns actual endpoint availability and resource rules.
// Roles have already been selected and authenticated by the source reader; this
// only binds their placement, including every codec component of a linear group.
class FfnPlacement final {
 public:
  static void validate(std::size_t cpu_layers, std::size_t target_layers) {
    if (cpu_layers > target_layers)
      throw std::runtime_error("--cpu-ffn-layers exceeds the source target layer count");
  }
  FfnPlacement(const prepared::Roles &roles, std::size_t cpu_layers)
      : target_layers_(roles.geometry.layers.size()), cpu_layers_(cpu_layers) {
    validate(cpu_layers_, target_layers_);
    if (!cpu_layers_) return;
    const auto inventory = prepared::parameter_inventory(roles.geometry.mtp_layers != 0, roles.geometry);
    for (const auto &[name, parameter] : inventory) {
      if (!parameter.target_ffn_layer || !ffn_on_cpu(*parameter.target_ffn_layer)) continue;
      // Linear physical components share the principal's group root. The
      // reader owns codec suffix/shape validation; placement has no codec list.
      const auto group = std::string_view(name).substr(0, name.size() - std::string_view("weight").size());
      for (const auto &role : roles.selected)
        if (role.name == name || (parameter.linear && role.name.starts_with(group)))
          host_roles_.insert(role.name);
    }
  }
  std::size_t target_layers() const noexcept { return target_layers_; }
  std::size_t cpu_layers() const noexcept { return cpu_layers_; }
  bool ffn_on_cpu(std::size_t layer) const noexcept { return layer < cpu_layers_; }
  bool role_on_cpu(std::string_view name) const { return host_roles_.contains(name); }

 private:
  const std::size_t target_layers_, cpu_layers_;
  std::set<std::string, std::less<>> host_roles_;
};
} // namespace qwen35
'''

replace(main, '#include "prepared_roles.h"\n', '#include "prepared_roles.h"\n#include "ffn_placement.h"\n')
start = source[main].index('bool cpu_ffn_weight(')
end = source[main].index('void validate_mtp_source(', start)
source[main] = source[main][:start] + source[main][end:]
source[main] = source[main].replace('validate_cpu_ffn_layers(', 'FfnPlacement::validate(')
replace(main, '    std::vector<c::LeasePool> &weight_pools, std::size_t cpu_ffn_layers = 0,\n',
    '    std::vector<c::LeasePool> &weight_pools, const FfnPlacement &placement,\n')
replace(main, '  FfnPlacement::validate(cpu_ffn_layers, roles.geometry.layers.size());\n',
    '  if (placement.target_layers() != roles.geometry.layers.size())\n'
    '    throw std::runtime_error("weight source differs from the cold FFN placement");\n')
replace(main, 'cpu_ffn_weight(role.name, cpu_ffn_layers)', 'placement.role_on_cpu(role.name)', 3)
replace(main, '  return load_selected_weight_roles(roles, backend, weights, weight_pools, cpu_ffn_layers);\n',
    '  const FfnPlacement placement(roles, cpu_ffn_layers);\n'
    '  return load_selected_weight_roles(roles, backend, weights, weight_pools, placement);\n')
replace(main, '  const std::size_t cpu_ffn_layers;\n',
    '  const FfnPlacement ffn_placement;\n')
replace(main, '       : sampling_seed(sampling_configuration.seed), cpu_ffn_layers(cpu_ffn_layer_count),\n',
    '       : sampling_seed(sampling_configuration.seed), ffn_placement(source.roles, cpu_ffn_layer_count),\n')
replace(main, 'load_selected_weight_roles(source_roles, execution, weights, weight_pools, cpu_ffn_layers, allocation_budget)',
    'load_selected_weight_roles(source_roles, execution, weights, weight_pools, ffn_placement, allocation_budget)')
replace(main, 'i < cpu_ffn_layers ? assembly.cpu() : assembly.primary()',
    'ffn_placement.ffn_on_cpu(i) ? assembly.cpu() : assembly.primary()')
start = source[main].index('class Model final {')
end = source[main].index('\n};', start)
body = source[main][start:end]
body = re.sub(r'"(?:\\.|[^"\\])*"|\bcpu_ffn_layers\b',
    lambda m: m.group() if m.group().startswith('"') else 'ffn_placement.cpu_layers()', body)
source[main] = source[main][:start] + body + source[main][end:]

replace(test, '#include "../../engine/models/qwen35/prepared_roles.h"\n',
    '#include "../../engine/models/qwen35/prepared_roles.h"\n'
    '#include "../../engine/models/qwen35/ffn_placement.h"\n')
helper = '''void check_placement(const p::Roles &roles) {
  const qwen35::FfnPlacement primary(roles, 0), mixed(roles, 2), all_ffn(roles, roles.geometry.layers.size());
  require(primary.cpu_layers() == 0 && mixed.cpu_layers() == 2 &&
      mixed.target_layers() == roles.geometry.layers.size(), "cold FFN dimensions differ");
  for (std::size_t i = 0; i < roles.geometry.layers.size(); ++i)
    require(!primary.ffn_on_cpu(i) && mixed.ffn_on_cpu(i) == (i < 2) && all_ffn.ffn_on_cpu(i),
        "ordinary graph FFN placement differs from the requested prefix");
  for (const auto &role : roles.selected) {
    bool expected = false;
    for (const auto *prefix : {"model.language_model.layers.0.", "model.language_model.layers.1."}) {
      const std::string layer(prefix);
      expected |= role.name == layer + "post_attention_layernorm.weight";
      for (const auto *projection : {"mlp.gate_proj.", "mlp.up_proj.", "mlp.down_proj."})
        expected |= role.name.starts_with(layer + projection);
    }
    require(!primary.role_on_cpu(role.name) && mixed.role_on_cpu(role.name) == expected,
        "physical FFN principal/auxiliary differs from graph placement");
    if (role.name.starts_with("mtp.")) require(!all_ffn.role_on_cpu(role.name),
        "NextN roles must retain their independent primary placement");
  }
}
void cold_ffn_placement_comes_from_inventory() {
  const auto inventory = p::parameter_inventory(true, geometry);
  require(std::ranges::count_if(inventory, [](const auto &entry) { return entry.second.target_ffn_layer.has_value(); }) ==
      static_cast<std::ptrdiff_t>(geometry.layers.size() * 4), "target FFN inventory ownership differs");
  for (const auto &[name, parameter] : inventory) {
    if (name.starts_with("mtp.")) require(!parameter.target_ffn_layer, "NextN unexpectedly owns a target FFN layer");
  }
  const auto selected = p::select_roles(quantized(false), identity, true, geometry);
  check_placement(selected);
  auto partial = selected;
  std::erase_if(partial.selected, [](const auto &role) {
    return role.name != "model.language_model.layers.0.mlp.gate_proj.qweight" &&
        role.name != "model.language_model.layers.0.mlp.gate_proj.scales" &&
        role.name != "model.language_model.layers.2.mlp.up_proj.qzeros" &&
        role.name != "model.language_model.embed_tokens.weight" &&
        role.name != "mtp.layers.0.mlp.gate_proj.weight";
  });
  require(partial.selected.size() == 5, "selected component fixture differs");
  check_placement(partial);
  rejects([&] { (void)qwen35::FfnPlacement(selected, geometry.layers.size() + 1); }, "exceeds");
}
'''
replace(test, 'void check_selected(const p::Roles &result, std::size_t count, std::size_t bytes, bool mtp) {\n',
    helper + 'void check_selected(const p::Roles &result, std::size_t count, std::size_t bytes, bool mtp) {\n'
    '  check_placement(result);\n')
# Existing reader fixtures cover original codecs and GGUF using their real
# selected metadata. Do not invent a parallel physical-role selector in tests.
for old, new in [
    ('  const auto all = p::read_roles(path, true), selected = p::read_roles(path, false);\n',
     '  const auto all = p::read_roles(path, true), selected = p::read_roles(path, false);\n  check_placement(all); check_placement(selected);\n'),
    ('  const auto all = p::select_roles(roles, identity, true, geometry, {}, {true}, {true});\n',
     '  const auto all = p::select_roles(roles, identity, true, geometry, {}, {true}, {true});\n  check_placement(all);\n'),
    ('  const auto text=select(all,states),full=select(all,states,true);\n',
     '  const auto text=select(all,states),full=select(all,states,true);\n  check_placement(text); check_placement(full);\n'),
    ('  const auto text=p::select_gguf_roles(all,identity,original,false, gguf_geometry);\n',
     '  const auto text=p::select_gguf_roles(all,identity,original,false, gguf_geometry);\n  check_placement(complete); check_placement(text);\n'),
    ('    const auto path=directory/("mlx-"+std::to_string(bits)+".tsv"); write(path,manifest); const auto parsed=p::read_roles(path,false);\n',
     '    const auto path=directory/("mlx-"+std::to_string(bits)+".tsv"); write(path,manifest); const auto parsed=p::read_roles(path,false);\n    check_placement(parsed);\n'),
    ('  const auto text_roles=select(all),full_roles=select(all,true);\n',
     '  const auto text_roles=select(all),full_roles=select(all,true);\n  check_placement(text_roles); check_placement(full_roles);\n'),
    ('    modelopt_static_fp8_preserves_original_scalar_roles(directory);\n',
     '    cold_ffn_placement_comes_from_inventory();\n    modelopt_static_fp8_preserves_original_scalar_roles(directory);\n'),
]:
    replace(test, old, new)
# A forward declaration suffices for the earlier original-codec fixture calls.
replace(test, 'void fp8_blocks_and_policy(const fs::path &directory) {\n',
    'void check_placement(const p::Roles &roles);\nvoid fp8_blocks_and_policy(const fs::path &directory) {\n')

pins = []
patch = []
for name in FILES:
    old = before[name]
    newline = '\r\n' if old.count(b'\r\n') else '\n'
    new = source[name].replace('\n', newline).encode()
    old_path, new_path = WORK / 'before' / name, WORK / 'source' / name
    if old:
        old_path.parent.mkdir(parents=True, exist_ok=True)
        old_path.write_bytes(old)
    new_path.parent.mkdir(parents=True, exist_ok=True)
    new_path.write_bytes(new)
    pins.append({'path': name, 'before_sha256': hashlib.sha256(old).hexdigest() if old else None,
        'after_sha256': hashlib.sha256(new).hexdigest(), 'bytes': len(new), 'newline': 'CRLF' if newline == '\r\n' else 'LF'})
    patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True),
        fromfile='a/' + name if old else '/dev/null', tofile='b/' + name))
(WORK / 'source-pins.json').write_text(json.dumps({'baseline_commit': '2af3380c8', 'files': pins}, indent=2) + '\n', encoding='utf-8')
(WORK / 'source.patch').write_bytes(''.join(patch).encode())
print(json.dumps(pins, indent=2))
