from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import discover_environment

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def verify(pin):
    assert identity(Path(pin['path'])) == pin, pin['path']
def execute(command, env, folder, timeout):
    folder.mkdir(parents=True, exist_ok=False)
    save(folder / 'command.json', dict(command=command, cwd=str(ROOT), timeout_seconds=timeout))
    start = time.monotonic()
    with (folder/'stdout.log').open('wb') as stdout, (folder/'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
            creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder/'running.json', dict(pid=process.pid))
        print('START', folder.name, process.pid, flush=True)
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired: process.kill(); process.wait(); code = -999
    result = dict(pid=process.pid, exit=code, seconds=time.monotonic()-start)
    save(folder/'process.json', result)
    print('END', folder.name, json.dumps(result), flush=True)
    if code:
        print((folder/'stdout.log').read_text(encoding='utf-8', errors='replace')[-10000:], flush=True)
        print((folder/'stderr.log').read_text(encoding='utf-8', errors='replace')[-4000:], flush=True)
        raise RuntimeError(folder.name+' failed; original source/raw preserved')
    return result

def main():
    attempt = WORK/(sys.argv[1] if len(sys.argv)>1 else 'consumer1')
    resume = len(sys.argv)>2 and sys.argv[2]=='resume-link'
    assert resume or not attempt.exists(), 'Keep prior raw; use a new attempt name'
    pins = read(WORK/'integrated-source-pins.json')
    for pin in pins['files']:
        assert identity(ROOT/pin['path']) == dict(pin, path=str(ROOT/pin['path'])), pin['path']
    old_root = ROOT/'.scratch/inference-turn-sampling-budget-20261025'
    recipe = read(old_root/'recipe.json')
    for pin in [*recipe['common_inputs'], recipe['native'], recipe['runtime'], recipe['fixture'], recipe['fixture_body']]: verify(pin)
    tree = attempt/'source'
    queue = ['engine/models/qwen35/main.cc', 'tests/tools/qwen_sampling_budget_case.h']
    directories = [ROOT/'include', ROOT, ROOT/'engine', ROOT/'tests/tools', ROOT/'engine/models/qwen35']
    seen = set(); frozen = []
    while queue:
        name = queue.pop()
        if name in seen: continue
        seen.add(name)
        path = ROOT/name; data = path.read_bytes(); target = tree/name
        target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
        frozen.append(dict(relative=name, original=identity(path), frozen=identity(target)))
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"', data.decode('utf-8-sig'), re.M):
            for directory in [path.parent, *directories]:
                candidate = (directory/include).resolve()
                try: child = candidate.relative_to(ROOT).as_posix()
                except ValueError: continue
                if candidate.is_file(): queue.append(child); break
    assert {'engine/models/qwen35/main.cc','engine/models/qwen35/prepared_roles.h',
        'engine/models/qwen35/ffn_placement.h'}.issubset(seen)
    save(attempt/'integrated-source-pins.json', pins)
    save(attempt/'frozen-source.json', frozen)
    consumer = attempt/'consumer.cc'
    consumer.write_text('#include "source/engine/models/qwen35/main.cc"\n'
        '#include "source/tests/tools/qwen_sampling_budget_case.h"\n'
        'int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("placement PREPARED_INPUTS");'
        'return qwen_sampling_budget_case::run(argv[1]);}catch(const std::exception &e){'
        'std::cerr<<"placement_failure="<<e.what()<<"\\n";return 1;}}\n', encoding='utf-8')
    compiler = recipe['compile'][0]
    env = discover_environment(compiler='msvc', cache=dict(CMAKE_C_COMPILER=compiler,
        CMAKE_CXX_COMPILER=compiler, CMAKE_GENERATOR='Ninja'), backends=()).env
    flags=[];skip=False
    for arg in recipe['compile'][1:]:
        if skip: skip=False;continue
        if arg == '/sourceDependencies': skip=True;continue
        if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
        if str(old_root).lower() in arg.lower():continue
        flags.append(arg)
    flags = ['/I'+str(tree/'include'),'/I'+str(tree),*flags]
    assert '/W4' in flags and '/WX' in flags
    obj=attempt/'compile/unit.obj';image=attempt/'link/component.exe'
    command=[compiler,*flags,str(consumer),'/sourceDependencies',str(attempt/'compile/dependencies.json'),
        '/Fo'+str(obj),'/Fd'+str(attempt/'compile/unit.pdb')]
    if resume:
        assert read(attempt/'compile/command.json')['command']==command
        build=read(attempt/'compile/process.json')
        assert build['exit']==0
        save(attempt/'driver-first-stop.json',dict(
            reason='Driver system-library count assertion included the /IMPLIB output switch in its original recipe count; app compile passed and no link/run had begun.',
            original_recipe_reported_system_libraries=24,actual_relative_system_libraries=23,
            reused_exact_app=identity(obj),new_app_compiles=0))
    else:
        build=execute(command,env,attempt/'compile',120)
    data=read(attempt/'compile/dependencies.json')['Data']
    deps=[Path(x) for x in dict.fromkeys([data['Source'],*data['Includes']])]
    actual={str(p.resolve()).casefold() for p in deps}
    for name in ['engine/models/qwen35/main.cc','engine/models/qwen35/prepared_roles.h',
        'engine/models/qwen35/ffn_placement.h','tests/tools/qwen_sampling_budget_case.h']:
        assert str((tree/name).resolve()).casefold() in actual,name
    assert not any(p.is_relative_to(ROOT/'engine') or p.is_relative_to(ROOT/'tests') or p.is_relative_to(ROOT/'include') for p in deps)
    save(attempt/'actual-dependencies.json',[identity(p) for p in deps])
    old_app=old_root/'app1/compile/unit.obj'
    command=[];replaced=0
    for arg in recipe['link']:
        if arg.lower().startswith(('/out:','/pdb:','/implib:','/map:')):continue
        if arg == str(old_app): arg=str(obj);replaced+=1
        command.append(arg)
    assert replaced==1
    absolute=[x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
    system=[x for x in command if not x.startswith(('/','-')) and not Path(x).is_absolute() and x.lower().endswith('.lib')]
    assert len(absolute)==130 and len(system)==23
    command += ['/OUT:'+str(image),'/PDB:'+str(attempt/'link/component.pdb'),'/IMPLIB:'+str(attempt/'link/component.lib')]
    linked=execute(command,env,attempt/'link',90)
    native=Path(recipe['native']['path']);alias=image.parent/native.name
    os.link(native,alias);assert os.path.samefile(native,alias)
    save(attempt/'link/inputs.json',dict(unchanged_common_inputs=recipe['common_inputs'],app=identity(obj),
        native_original=recipe['native'],native_alias=identity(alias),same_native_file=True,system_libraries=system,
        absolute_input_count=len(absolute),unchanged_absolute_inputs=129))
    run_env=dict(env);run_env['PATH']=str(image.parent)+';'+read(Path(recipe['runtime']['path']))['PATH']
    run_env['HF_HUB_OFFLINE']=run_env['TRANSFORMERS_OFFLINE']='1'
    run=execute([str(image),str(Path(recipe['fixture']['path']).parent)],run_env,attempt/'run',120)
    result=json.loads((attempt/'run/stdout.log').read_text().strip().splitlines()[-1])
    assert result['status']=='PASS'
    for pin in pins['files']:
        assert identity(ROOT/pin['path']) == dict(pin,path=str(ROOT/pin['path'])),pin['path']
    for pin in frozen:assert identity(Path(pin['frozen']['path']))==pin['frozen']
    save(attempt/'summary.json',dict(status='FINITE_ACTUAL_ORDINARY_CPU_PASS',source_pins=pins,
        compile=build,link=linked,run=run,result=result,frozen_project_files=len(frozen),
        actual_dependencies=len(deps),actual_consumer_product_overlays=3,
        metadata_test_note='Fourth integrated pin qwen_prepared_roles_test.cc was verified unchanged; it passed in prior standard-only roles1 and is not included by this thin consumer.',
        cache_fixture=[recipe['fixture'],recipe['fixture_body']],native=recipe['native'],
        unchanged_link_inputs=129,total_absolute_link_inputs=130,system_libraries=23,
        SDK_TUs=0,core_TUs=0,provider_TUs=0,GPU=False,HTTP=0,
        unproven=['Mixed CPU+GPU actual execution','GPU-only native execution','MTP native execution','Expert/shared FFN implementation','Performance difference']))
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
