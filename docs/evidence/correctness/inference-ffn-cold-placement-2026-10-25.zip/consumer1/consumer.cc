#include "source/engine/models/qwen35/main.cc"
#include "source/tests/tools/qwen_sampling_budget_case.h"
int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("placement PREPARED_INPUTS");return qwen_sampling_budget_case::run(argv[1]);}catch(const std::exception &e){std::cerr<<"placement_failure="<<e.what()<<"\n";return 1;}}
