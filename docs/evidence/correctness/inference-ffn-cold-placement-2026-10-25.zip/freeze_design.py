from pathlib import Path
import difflib
import hashlib
import json
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
def save(name, value):
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

name = 'engine/models/qwen35/main.cc'
current = (ROOT / name).read_bytes()
before = (WORK / 'before' / name).read_bytes()
assert current == before, 'Root must rebase the exact disjoint main hunks if canonical has advanced'
candidate = (WORK / 'source' / name).read_bytes()
patch = ''.join(difflib.unified_diff(before.decode().splitlines(True), candidate.decode().splitlines(True),
    fromfile='a/' + name, tofile='b/' + name))
(WORK / 'main.patch').write_bytes(patch.encode())
save('design.json', dict(
    baseline_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    status='PRIVATE_SOURCE_AND_STD_ONLY_PASS_NOT_NATIVE_CONSUMER',
    ownership=[
        'Parameter.target_ffn_layer is derived solely by the canonical model inventory: four dense target FFN parameters per layer.',
        'FfnPlacement binds actual selected physical names cold from tagged principal roots. Existing reader retains codec, role, shape and provenance validation.',
        'Model owns one immutable requested placement. Source streaming/FP8/NF4 loader and target graph FFN Scope consume it. No duplicate count field.',
        'Non-target and MTP roles stay primary. No role tag in prepared manifests, codec suffix registry, executor, queue rule, or hot string dispatch.',
        'BackendSelection and GraphAssembly retain actual endpoints, storage domains, crossings and availability checks.'
    ],
    modes={
        'cpu_only':'cpu_layers=0: all roles and target operations remain on the primary CPU endpoint; same existing loader path.',
        'gpu_only':'cpu_layers=0: all roles and operations stay primary GPU; constructor returns after bound validation, no inventory/map allocation.',
        'mixed':'first N target dense FFN groups, including post-attention norm and every selected projection codec component, bind host; target Scope uses same N.',
        'mtp':'NextN inventory deliberately has no target FFN ownership, preserving current independent primary route.',
        'expert_shared':'Not present in current Qwen inventory and not claimed implemented. Future explicit target FFN inventory ownership can reuse the policy.'
    },
    caller_contract='load_selected_weight_roles now requires the placement built from its selected Roles; both canonical callers migrated. Historical private consumers are not compatibility requirements.',
    std_only_evidence='roles1/summary.json: /W4 /WX compile-link 4.687s, metadata process 0.844s, 13543 checks; 18 frozen project files; no native/model loading.',
    source_files=4,
    main_patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),
    preserved=['All pre-existing file newline bytes', 'Sampling-budget work in main baseline c7fa9959', 'CPU0 / source precision / MTP mathematics / queues / resource retirement']
))
save('finite-check-plan.json', dict(
    completed=dict(kind='one standard-only metadata application TU and one process', evidence='roles1/summary.json',
        coverage=['dense/GPTQ/NVFP4/CT/FP8/NF4/MLX and GGUF selected groups', 'primary and mixed requested policy',
            'ordinary and MTP primary separation', 'selected partial FFN principal plus auxiliary roles', 'CPU prefix overflow']),
    proposed_not_started=dict(
        need='Main is not included in the std-only TU; one actual thin CPU consumer can check constructor/loader/graph integration after root merges the disjoint main hunks.',
        source='Reuse current tests/tools/qwen_sampling_budget_case.h through the existing thin consumer shape in .scratch/inference-turn-sampling-budget-20261025/consumer.cc, with canonical headers plus these placement overlays.',
        recipe='.scratch/inference-turn-sampling-budget-20261025/recipe.json',
        closure='.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/attempt2/link/{command,ready}.json',
        native_sha256='1066e80261cc58d1c0ea57e50475e2e38b7675b666eb2b639969e01e85916a46',
        limits='At most one thin app TU /W4 /WX, one link with 129 unchanged cached absolute OBJ/LIBs plus replaced app and 24 system libs, one bounded CPU run using existing prepared tiny weights; no SDK/core/provider rebuild or weight copy.',
        run='Pass the original recipe prepared-input path, keep same native DLL as an exe-directory hardlink, and use original recorded CPU runtime environment.',
        not_proven=['No actual mixed/CUDA/Metal/Vulkan native run', 'No MTP native execution from metadata checks', 'No performance speedup claim', 'No expert/shared FFN implementation']
    )
))
print('frozen main patch', hashlib.sha256(patch.encode()).hexdigest())
