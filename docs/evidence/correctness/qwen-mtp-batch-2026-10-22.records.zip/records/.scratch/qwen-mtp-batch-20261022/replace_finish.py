from pathlib import Path
p=Path('tools/qwen35_text/main.cc');s=p.read_text()
s=s.replace('    MtpReplayRecord *commit_record = nullptr;\n    MtpReplayLedger *commit_ledger = nullptr;',
'''    std::vector<MtpReplayRecord *> commit_records(outputs.size(), nullptr);
    std::vector<MtpReplayLedger *> commit_ledgers(outputs.size(), nullptr);''',1)
a=s.index('      if (outputs[0].mtp_ledger) {');b=s.index('      // Selection observes',a)
s=s[:a]+'''      for (std::size_t j = 0; j < outputs.size(); ++j) {
        if (outputs[j].mtp_ledger) {
          if (!has_mtp(phase.family->role)) throw std::runtime_error("MTP ledger requires an MTP participant");
          for (std::size_t k = 0; k < j; ++k) if (outputs[k].mtp_ledger == outputs[j].mtp_ledger)
            throw std::runtime_error("batch participants cannot share a mutable MTP ledger");
          auto &record = outputs[j].mtp_ledger->next();
          commit_ledgers[j] = outputs[j].mtp_ledger; commit_records[j] = &record;
          if (record.role != phase.family->role || record.before != mtp_boundary(*step.members[j].base) ||
              record.ids().size() != (drafts_token(phase.family->role) ? 1u : tokens) ||
              record.ids().empty() || record.ids().front() != step.members[j].first_input)
            throw std::runtime_error("MTP prepared ledger entry differs from its actual episode");
          if (outputs[j].mtp_expected && !outputs[j].mtp_expected->committed)
            throw std::runtime_error("MTP replay expected record is not committed");
        } else if (outputs[j].mtp_expected)
          throw std::runtime_error("MTP expected replay record requires a fresh commit witness");
      }
      check(step.completion.wait()); step.completion = {};
      if (drafts_token(phase.family->role)) {
        std::vector<std::int32_t> drafts(outputs.size());
        check(phase.draft_id.buffer.view().read(std::as_writable_bytes(std::span(drafts))));
        for (std::size_t j = 0; j < outputs.size(); ++j) step.members[j].draft_token = drafts[j];
        step.draft_token = drafts[0]; // Existing R1 diagnostic observation.
      }
'''+s[b:]
a=s.index('      if (has_mtp(phase.family->role)) {\n        auto &member = step.members[0];');b=s.index('      if (!layer0_probe.empty())',a)
s=s[:a]+'''      if (has_mtp(phase.family->role)) for (auto &member : step.members) {
        auto &draft = *member.next->draft;
        draft.lag = static_cast<std::uint32_t>(member.next->length - draft.frontier);
        draft.catchup_token = draft.lag ? member.draft_token : -1;
      }
      for (std::size_t j = 0; j < outputs.size(); ++j) if (auto *record = commit_records[j]) {
        const auto &member = step.members[j];
        record->requests = outputs.size(); record->member_index = j;
        record->accepted = member.accepted_tokens;
        record->draft_rows = member.next->draft->frontier - member.base->draft->frontier;
        record->after = mtp_boundary(*member.next); record->after.next_id = next_ids[j];
        record->accepted_inputs = {member.first_input, member.accepted_tokens == 2 ? member.draft_token : -1};
        if (!record->generation) {
          record->draft = -1; record->target_first = next_ids[j]; record->target_second = -1;
          record->agreed = false; record->accepted_draft = false;
          record->stopped = is_end_of_generation(next_ids[j]);
          record->emitted = {next_ids[j], -1}; record->emitted_count = 1;
        }
        if (outputs[j].mtp_expected && !record->same_result(*outputs[j].mtp_expected))
          throw std::runtime_error("MTP replay natural decision or state boundary diverged from its recorded episode");
      }
'''+s[b:]
a=s.index('      if (has_mtp(phase.family->role)) {\n        for (std::size_t bank = 12;');b=s.index('      hyle::container::SmallVector<std::pair',a)
s=s[:a]+'''      if (has_mtp(phase.family->role)) {
        for (std::size_t bank = 12; bank < 14; ++bank) {
          step.appends[bank] = take(g::batch::take_append(run, step.nodes[bank])); step.bound[bank] = false;
        }
        auto key = take(step.appends[12].ready()), value = take(step.appends[13].ready());
        std::vector<std::pair<std::uint32_t, std::size_t>> owners; owners.reserve(outputs.size());
        for (std::size_t j = 0; j < outputs.size(); ++j) {
          auto &member = step.members[j]; auto &draft = *member.next->draft;
          draft.key = outputs.size() == 1 ? key : take(draft_inventory.keys[0].reframe(member.draft_layout, std::span(&key, 1)));
          draft.value = outputs.size() == 1 ? value : take(draft_inventory.values[0].reframe(member.draft_layout, std::span(&value, 1)));
          owners.emplace_back(draft.pages.back().page(), j);
        }
        std::sort(owners.begin(), owners.end());
        for (std::size_t bank = 12; bank < 14; ++bank)
          for (std::size_t i = 0; i < step.appends[bank].appender_count(); ++i) {
            auto &tail = take(step.appends[bank].appender(i)); if (!tail.valid()) continue;
            const auto found = std::lower_bound(owners.begin(), owners.end(), std::pair{tail.page(), std::size_t{0}});
            if (found == owners.end() || found->first != tail.page())
              throw std::runtime_error("draft append returned a tail outside all final pages");
            auto &member = step.members[found->second]; auto &draft = *member.next->draft;
            if (tail.reserved_rows() || member.next_draft_tails[bank - 12].valid() ||
                tail.initialized_rows() != draft.frontier % cache::Plan::page_rows)
              throw std::runtime_error("draft append returned an invalid committed frontier");
            member.next_draft_tails[bank - 12] = std::move(tail);
          }
        for (const auto &member : step.members) validate_mtp_snapshot(*member.next);
      }
'''+s[b:]
s=s.replace('''      if (commit_record) {
        commit_record->committed = true;
        ++commit_ledger->committed_count;
      }''','''      for (std::size_t j = 0; j < outputs.size(); ++j) if (commit_records[j]) {
        commit_records[j]->committed = true;
        ++commit_ledgers[j]->committed_count;
      }''',1)
s=s.replace('''    if (commit_record) {
      commit_record->endpoint = finished;
      commit_record->step_seconds = std::chrono::duration<double>(finished - step_start).count();
    }''','''    for (auto *record : commit_records) if (record) {
      record->endpoint = finished;
      record->step_seconds = std::chrono::duration<double>(finished - step_start).count();
    }''',1)
a=s.index('  MtpRoundResult finish_mtp_round(');b=s.index('\n  std::int32_t finish_evaluation(',a)
s=s[:a]+'''  void finish_mtp_rounds(std::span<const MtpGenerationSelection> selections,
      std::span<const std::int32_t> eos, std::span<const EvaluationOutput> outputs,
      std::span<MtpRoundResult> results) {
    if (!active_step || selections.empty() || selections.size() != active_step->members.size() ||
        outputs.size() != selections.size() || results.size() != selections.size() || !active_step->phase ||
        !has_mtp(active_step->phase->family->role) || is_mtp_prefill(active_step->phase->family->role))
      throw std::runtime_error("MTP finish requires its original complete generation batch");
    const auto role = active_step->phase->family->role;
    const auto ended = [&](std::int32_t id) { return std::find(eos.begin(), eos.end(), id) != eos.end(); };
    for (std::size_t j = 0; j < selections.size(); ++j) {
      if (!selections[j].output_quota || selections[j].session != active_step->members[j].session ||
          selections[j].session != outputs[j].session || selections[j].expected_pending < 0 ||
          selections[j].expected_pending >= vocabulary || ended(selections[j].expected_pending))
        throw std::runtime_error("MTP generation requires its emitted pending token and positive quota");
      results[j].emitted.clear(); results[j].emitted.reserve(2);
      results[j].pending = selections[j].expected_pending;
    }
    std::vector<std::int32_t> next(selections.size(), -1);
    finish_selected_evaluations(outputs, next,
        [&](std::span<const std::int32_t> ids, StepState &step, std::span<std::int32_t> selected) {
          for (std::size_t j = 0; j < selections.size(); ++j) {
            const auto &selection = selections[j]; auto &member = step.members[j]; auto &result = results[j];
            if (member.first_input != selection.expected_pending)
              throw std::runtime_error("MTP generation input differs from its emitted pending token");
            result.target_first = ids[drafts_token(role) ? 2 * j : j]; result.draft = member.draft_token;
            result.target_second = -1; result.agreed = false; result.accepted_draft = false;
            if (drafts_token(role)) {
              if (result.draft < 0 || result.draft >= vocabulary) throw std::runtime_error("MTP draft ID outside vocabulary");
              result.target_second = ids[2 * j + 1]; result.agreed = result.draft == result.target_first;
              result.accepted_draft = result.agreed && selection.output_quota >= 2 && !ended(result.target_first);
            }
            const auto accepted = result.accepted_draft ? 2u : 1u;
            member.accepted_tokens = accepted;
            selected[j] = result.next_id = result.accepted_draft ? result.target_second : result.target_first;
            result.processed_target = accepted; result.processed_draft = draft_lag(role) + 1;
            result.emitted.push_back(result.target_first);
            if (result.accepted_draft) result.emitted.push_back(result.target_second);
            result.stopped = ended(result.emitted.back());
            if (outputs[j].mtp_ledger) {
              auto &record = outputs[j].mtp_ledger->next();
              if (!record.generation || record.quota != selection.output_quota)
                throw std::runtime_error("MTP ledger quota differs from its original selection");
              record.draft = result.draft; record.target_first = result.target_first;
              record.target_second = result.target_second; record.agreed = result.agreed;
              record.accepted_draft = result.accepted_draft; record.stopped = result.stopped;
              record.emitted = {result.emitted[0], result.emitted.size() == 2 ? result.emitted[1] : -1};
              record.emitted_count = result.emitted.size();
            }
          }
        });
  }

  MtpRoundResult finish_mtp_round(Session &session, std::int32_t expected_pending,
      std::size_t output_quota, std::span<const std::int32_t> eos = {}, const EvaluationOutput *output = nullptr) {
    const std::array selections{MtpGenerationSelection{session.shared_from_this(), expected_pending, output_quota}};
    const std::array outputs{output ? *output : EvaluationOutput{.session = session.shared_from_this(), .name = "mtp"}};
    std::array<MtpRoundResult, 1> results;
    finish_mtp_rounds(selections, eos, outputs, results);
    return std::move(results[0]);
  }
'''+s[b:]
p.write_text(s)
