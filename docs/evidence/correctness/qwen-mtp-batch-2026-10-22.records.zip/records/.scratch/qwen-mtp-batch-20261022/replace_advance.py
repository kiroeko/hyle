from pathlib import Path
p=Path('tools/qwen35_text/main.cc');s=p.read_text();a=s.index('// One complete original episode per visit.');b=s.index('\nvoid retire_mtp_request(',a)
s=s[:a]+r'''struct PreparedMtpCall final {
  MtpGenerationRequest *request = nullptr;
  GraphRole role = GraphRole::kMtpPrefill;
  std::span<const std::int32_t> prompt;
  std::int32_t pending = -1;
  std::size_t quota = 0, steps = 0;
  bool generation = false, full_hit = false, initial_prefix = false;
  std::string name;
  double step_seconds = 0;
  std::span<const std::int32_t> ids() const noexcept {
    return generation ? std::span(&pending, 1) : prompt;
  }
};

PreparedMtpCall prepare_mtp_call(Model &model, MtpGenerationRequest &request, std::size_t steps,
    cache::PrefixCache *prefix, std::span<const MtpGenerationRequest> requests) {
  if (request.done) throw std::runtime_error("MTP request has already completed");
  if (request.ledger && (steps > request.generated.capacity() || request.round_emitted.size() < steps - 1))
    throw std::runtime_error("MTP observer slots must be reserved for every turn before execution");
  PreparedMtpCall call; call.request = &request; call.steps = steps;
  call.generation = request.prefilled;
  if (!call.generation) {
    std::cerr << "memory_phase=" << request.memory_name << "_prefill_begin\n";
    request.prefill_start = request.admission_start == Clock::time_point{} ? Clock::now()
        : std::exchange(request.admission_start, Clock::time_point{});
    call.initial_prefix = prefix && request.turn_index == 0;
    if (call.initial_prefix) {
      auto hit = prefix->lookup(*request.input, request.prompt.size(), 1, &model, model.math_identity());
      if (hit) {
        if (!hit.snapshot->draft || hit.snapshot->draft->lag)
          throw std::runtime_error("MTP prompt directory contains a non-prompt frontier");
        request.reused_tokens = hit.snapshot->length; request.prefix_hits = 1;
        request.prefix_full_hits = request.reused_tokens == request.prompt.size() ? 1 : 0;
        request.history = cache::copy_history(hit.replay, model.capacity);
        if (request.ledger) {
          import_mtp_prompt_ledger(*request.ledger, hit.replay, request.prefix_full_hits != 0);
          request.ledger_observed = request.ledger->committed_count;
        }
        const auto suffix = request.prompt.size() - request.reused_tokens;
        const std::array chunks{suffix};
        request.session = model.create_session(suffix ? std::span<const std::size_t>(chunks) : std::span<const std::size_t>{},
            std::move(hit.snapshot), (suffix == 1 || request.prompt.size() == 1) ? GraphRole::kMtpSingle : GraphRole::kMtpPrefill);
        hit.reset();
      } else { request.prefix_misses = 1; request.history = std::make_shared<cache::ReplayHistory>(model.capacity); }
    }
    call.prompt = request.prompt.subspan(request.turn_index == 0 ? request.reused_tokens : 0);
    const auto lag = request.session ? request.session->head->draft->lag : 0;
    call.role = call.prompt.size() == 1 ? (lag ? GraphRole::kMtpCatchupSingle : GraphRole::kMtpSingle)
        : (lag ? GraphRole::kMtpCatchupPrefill : GraphRole::kMtpPrefill);
    if (!request.session) {
      make_mtp_room(model, prefix, nullptr, requests);
      const std::array chunks{call.prompt.size()}; request.session = model.create_session(chunks, {}, call.role);
    }
    call.full_hit = call.prompt.empty();
    call.name = request.turn_index ? "round" + std::to_string(request.turn_index + 1) + "_prefill" : "prefill";
  } else {
    call.quota = steps - request.generated.size(); call.pending = request.generated.back();
    const bool one = call.quota == 1 || model.capacity - request.session->length() == 1;
    const auto lag = request.session->head->draft->lag;
    call.role = one ? (lag ? GraphRole::kMtpCatchupSingle : GraphRole::kMtpSingle)
        : (lag ? GraphRole::kMtpCatchupRound : GraphRole::kMtpRound);
    call.name = (request.turn_index ? "round" + std::to_string(request.turn_index + 1) + "_" : "") +
        "mtp" + std::to_string(request.rounds.size() + 1);
  }
  return call;
}

bool make_mtp_batch_room(Model &model, cache::PrefixCache *prefix,
    std::span<const PreparedMtpCall> calls, std::span<const MtpGenerationRequest> requests) {
  const auto limit = model.cache_plan.resident_sessions;
  const auto fits = [&] {
    const auto live = std::size_t(model.snapshot_versions.live);
    if (live > limit || model.active_step) throw std::runtime_error("MTP batch admission requires retired heads within N");
    std::size_t released = 0;
    for (std::size_t j = 0; j < calls.size(); ++j) {
      const auto *head = calls[j].request->session->head.get();
      bool seen = false;
      for (std::size_t k = 0; k < j; ++k) seen = seen || calls[k].request->session->head.get() == head;
      if (seen) continue;
      bool external = prefix && prefix->retains(head);
      for (const auto &request : requests) if (request.session && request.session->head.get() == head) {
        bool selected = false;
        for (const auto &call : calls) selected = selected || call.request->session == request.session;
        external = external || !selected;
      }
      if (!external) ++released;
    }
    if (released > live) throw std::runtime_error("MTP batch version inventory is inconsistent");
    return calls.size() <= limit - (live - released);
  };
  while (!fits()) if (!prefix || !prefix->evict_one()) return false;
  return true;
}

void finish_mtp_call(Model &model, PreparedMtpCall &call, const MtpRoundResult *result) {
  auto &request = *call.request;
  if (call.full_hit) {
    request.generated.push_back(request.session->head->next_id);
    request.prefill_endpoint = Clock::now(); request.endpoint = request.prefill_endpoint;
    std::cerr << "prefix_hit name=prefill reused_tokens=" << request.reused_tokens << " graph_calls=0 visible=" << request.session->length() << '\n';
    if (!request.trace.empty()) {
      const auto path = request.trace / "prefill"; std::filesystem::create_directories(path);
      std::ofstream metadata(path / "cache-hit.json");
      if (!metadata) throw std::runtime_error("cannot write MTP prefix-hit metadata");
      metadata << "{\"prefix_hit\":true,\"graph_calls\":0,\"tensor_payload_available\":false,\"reused_tokens\":"
               << request.reused_tokens << ",\"next_id\":" << request.generated.back() << "}\n";
    }
  } else if (request.ledger) observe_mtp_commits(request);
  else if (!call.generation) {
    request.generated.push_back(request.session->head->next_id); request.prefill_step_seconds += call.step_seconds;
    ++request.prefill_graph_calls; request.prefill_graph_tokens += call.ids().size();
    request.prefill_draft_rows += cache::add(call.ids().size(), draft_lag(call.role));
  } else {
    request.decode_step_sum_seconds += call.step_seconds;
    request.verified_rows += drafts_token(call.role) ? 2 : 1; request.draft_rows += result->processed_draft;
    request.draft_rounds += drafts_token(call.role) ? 1 : 0; request.agreements += result->agreed ? 1 : 0;
    request.accepts += result->accepted_draft ? 1 : 0;
    request.generated.insert(request.generated.end(), result->emitted.begin(), result->emitted.end());
    request.rounds.push_back(*result);
  }
  if (!call.generation) {
    request.prefilled = true; request.endpoint = request.prefill_endpoint;
    std::cerr << "memory_phase=" << request.memory_name << "_prefill_end\n"
              << "memory_phase=" << request.memory_name << "_decode_begin\n";
  }
  request.visible_tokens = request.session->length(); request.draft_frontier = request.session->head->draft->frontier;
  request.draft_lag = request.session->head->draft->lag;
  request.done = request.generated.size() >= call.steps || is_end_of_generation(request.generated.back());
  if (!request.turn_observations.empty()) {
    auto &turn = request.turn_observations[request.turn_index];
    if (!call.generation) { turn.start = request.prefill_start; turn.prefill_endpoint = request.prefill_endpoint; }
    turn.endpoint = request.endpoint; turn.output_end = request.generated.size();
  }
  if (request.done) std::cerr << "memory_phase=" << request.memory_name << "_decode_end\n";
  (void)model;
}

void execute_mtp_calls(Model &model, std::span<PreparedMtpCall> calls, bool trace_states,
    cache::PrefixCache *prefix = nullptr, std::span<const MtpGenerationRequest> requests = {}) {
  if (calls.empty()) return;
  if (calls.size() == 1 && calls[0].full_hit) { finish_mtp_call(model, calls[0], nullptr); return; }
  if (!make_mtp_batch_room(model, prefix, calls, requests)) throw std::runtime_error("MTP batch exceeds committed head budget");
  std::vector<EvaluationRequest> inputs; std::vector<EvaluationOutput> outputs;
  std::vector<MtpGenerationSelection> selections; std::vector<MtpRoundResult> results(calls.size());
  std::vector<std::int32_t> next(calls.size());
  inputs.reserve(calls.size()); outputs.reserve(calls.size()); selections.reserve(calls.size());
  const auto role = calls[0].role; const auto generation = calls[0].generation;
  for (auto &call : calls) {
    auto &request = *call.request;
    if (call.full_hit || call.role != role || call.generation != generation || call.ids().size() != calls[0].ids().size())
      throw std::runtime_error("MTP batch requires equal role, kind and input rows without padding");
    if (request.ledger) prepare_mtp_replay_record(*request.ledger, *request.session, role, call.ids(), generation,
        call.quota, request.turn_index, generation ? std::shared_ptr<const void>{} : std::shared_ptr<const void>(request.warm_inputs.at(request.turn_index)));
    inputs.push_back({request.session, call.ids()});
    outputs.push_back({.session = request.session, .name = call.name, .trace = &request.trace,
        .trace_states = trace_states, .complete_seconds = &call.step_seconds,
        .host_endpoint = generation ? &request.endpoint : &request.prefill_endpoint, .mtp_ledger = request.ledger.get()});
    if (generation) selections.push_back({request.session, call.pending, call.quota});
  }
  model.prepare_evaluations(inputs, nullptr, role); model.submit_evaluations();
  const std::array<std::int32_t, 2> eos{248044, 248046};
  try {
    if (generation) model.finish_mtp_rounds(selections, eos, outputs, results);
    else model.finish_evaluations(outputs, next);
    for (std::size_t j = 0; j < calls.size(); ++j) finish_mtp_call(model, calls[j], generation ? &results[j] : nullptr);
  } catch (...) {
    for (auto &call : calls) observe_mtp_commits(*call.request);
    throw;
  }
}

void publish_mtp_prompt(Model &model, PreparedMtpCall &call, cache::PrefixCache *prefix) {
  if (!call.initial_prefix || call.full_hit) return;
  auto &request = *call.request;
  request.history->append(request.input, request.reused_tokens, call.ids().size(), request.session->head->next_id);
  if (request.session->head->draft->lag) throw std::runtime_error("only a complete lag0 MTP prompt may enter the directory");
  prefix->publish(request.input, request.session->head, {request.history, request.history->chunks.size(), request.prompt.size()});
  (void)model;
}

void advance_mtp_request(Model &model, MtpGenerationRequest &request,
    std::size_t steps, bool trace_states, cache::PrefixCache *prefix = nullptr,
    std::span<const MtpGenerationRequest> requests = {}) {
  std::array calls{prepare_mtp_call(model, request, steps, prefix, requests)};
  execute_mtp_calls(model, calls, trace_states, prefix, requests);
  publish_mtp_prompt(model, calls[0], prefix);
}
'''+s[b:]
p.write_text(s)
