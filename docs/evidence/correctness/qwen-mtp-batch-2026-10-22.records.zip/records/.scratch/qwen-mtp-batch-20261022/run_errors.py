"""New natural-turn input validation without a weight manifest."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
Z=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('build',Z/'build_hyle.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c
ready=c.read(Z/'qwen-ready-attempt1.json');assert h.same(ready['image'])and h.same(ready['source'])
f=Z/'fixtures';out=Z/'errors1';out.mkdir(exist_ok=False)
base=[ready['image']['path'],'--inputs',str(f/'no-weights'),'--mtp','on','--capacity','64']
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
cases=[
 ('steps-conflict',['--schedule',str(f/'a.txt'),'--steps','4'],['steps']),
 ('incomplete',['--schedule',str(f/'incomplete.txt')],['generate']),
 ('zero',['--schedule',str(f/'zero.txt')],['generate']),
 ('too-long',['--schedule',str(f/'too-long.txt')],['capacity']),
 ('empty',['--schedule',str(f/'empty.txt')],['prompt']),
 ('fixed-decode',['--schedule',str(f/'tape.txt')],['decode']),
 ('active-over-resident',['--session-schedules',str(f/'sessions.txt'),'--active-sequences','2','--max-sessions','1'],['active-sequences']),
 ('budget',['--session-schedules',str(f/'sessions.txt'),'--active-sequences','2','--max-sessions','2','--cache-bytes','119554098'],['bytes']),
]
checks=[]
for name,args,need in cases:
 d=out/name;d.mkdir();command=base+args;c.save(d/'plan.json',dict(command=command,expected_exit=1,missing_weight_manifest=True))
 try:c.execute('run',command,env,d)
 except RuntimeError:pass
 result=c.read(d/'run.result.json');stderr=(d/'run.stderr.log').read_text(encoding='utf-8',errors='replace')
 assert result['exit']==1 and result['terminal']and all(s.lower()in stderr.lower()for s in need),(name,stderr)
 assert 'weights_load_seconds='not in stderr and'cannot open weight'not in stderr.lower()and not(d/'run.stdout.log').read_bytes()
 checks.append(dict(name=name,command=command,expected_exit=1,stderr=stderr,terminal=b.identity(d/'run.result.json')))
c.save(Z/'review/errors-analysis.json',dict(status='PASS_EXPECTED_EARLY_VALIDATION',cases=checks,source=ready['source'],image=ready['image'],model_weight_loads=0,GPU_inference_runs=0))
print('EXPECTED_VALIDATION',len(checks))
