from pathlib import Path
p=Path('tools/qwen35_text/main.cc');s=p.read_text()
a=s.index('  const std::array single{std::size_t{1}}, pair{std::size_t{2}};',s.index('int run_mtp_sessions('))
b=s.index('  std::vector<std::size_t> waiting, active, dispatch, dispatch_turns;',a)
s=s[:a]+r'''  const std::array single{std::size_t{1}}, pair{std::size_t{2}};
  std::map<GraphRole, std::map<std::size_t, std::size_t>> prompt_uses;
  std::map<GraphRole, std::map<std::size_t, std::vector<std::size_t>>> support;
  const auto note_prompt = [&](GraphRole role, std::size_t tokens, std::size_t member) {
    auto &count = prompt_uses[role][tokens]; count = cache::add(count, 1);
    auto &members = support[role][tokens];
    if (std::find(members.begin(), members.end(), member) == members.end()) members.push_back(member);
  };
  std::size_t decoding_requests = 0;
  for (std::size_t i = 0; i < requests.size(); ++i) {
    std::vector<std::size_t> suffixes{requests[i].prompt.size()};
    if (prefix) for (std::size_t j = 0; j < i; ++j) {
      const auto length = requests[j].prompt.size();
      if (length < requests[i].prompt.size() && cache::same_prefix(*requests[i].input, *requests[j].input, length))
        suffixes.push_back(requests[i].prompt.size() - length);
    }
    std::sort(suffixes.begin(), suffixes.end()); suffixes.erase(std::unique(suffixes.begin(), suffixes.end()), suffixes.end());
    for (auto tokens : suffixes) note_prompt(tokens == 1 ? GraphRole::kMtpSingle : GraphRole::kMtpPrefill, tokens, i);
    for (std::size_t turn = 1; turn < requests[i].turns.size(); ++turn) {
      const auto tokens = cache::add(requests[i].turns[turn].prompt.size(), 1);
      for (auto role : {GraphRole::kMtpPrefill, GraphRole::kMtpCatchupPrefill}) note_prompt(role, tokens, i);
    }
    if (std::ranges::any_of(requests[i].turns, [](const auto &turn) { return turn.steps > 1; })) ++decoding_requests;
  }
  const std::array roles{GraphRole::kMtpRound, GraphRole::kMtpCatchupRound,
      GraphRole::kMtpSingle, GraphRole::kMtpCatchupSingle};
  // Normal rebuild preserves original committed chunks, not original proposals.
  // Every natural accept2 can become one teacher-forced T2 prefill chunk.
  prompt_uses[GraphRole::kMtpSingle].try_emplace(1, 0);
  if (model.capacity >= 2) prompt_uses[GraphRole::kMtpPrefill].try_emplace(2, 0);
  for (std::size_t width = 1; width <= model.cache_plan.active_sequences; ++width) {
    std::map<GraphRole, std::map<std::size_t, std::size_t>> shapes;
    for (const auto &[role, tokens] : prompt_uses) for (const auto &[count, uses] : tokens) {
      const auto found_role = support.find(role);
      const auto eligible = found_role == support.end() || !found_role->second.contains(count) ? 0 : found_role->second.at(count).size();
      if (width == 1 || width <= eligible) shapes[role][count] = cache::add(uses, width == 1 ? restore_bound : 0);
    }
    if (decode_bound && width <= decoding_requests) for (auto role : roles) {
      auto &uses = shapes[role][drafts_token(role) ? 2 : 1]; uses = cache::add(uses, decode_bound);
    }
    // R1 restoration also needs lag0 versions of each original warm chunk.
    if (width == 1) for (const auto &[tokens, uses] : prompt_uses[GraphRole::kMtpCatchupPrefill]) {
      (void)uses; shapes[GraphRole::kMtpPrefill].try_emplace(tokens, restore_bound);
    }
    for (const auto &[role, entries] : shapes) {
      std::vector<std::size_t> chunks; chunks.reserve(entries.size());
      for (const auto &[tokens, uses] : entries) { (void)uses; chunks.push_back(tokens); }
      model.prepare_family(chunks, false, width, role);
      for (const auto &[tokens, uses] : entries) model.plan_replay_uses(tokens, width,
          cache::add(uses, width == 1 ? restore_bound : 0), role);
    }
  }
  const std::array first_prefill{requests.front().prompt.size()};
  model.prepare_execution(first_prefill, false, 1,
      first_prefill[0] == 1 ? GraphRole::kMtpSingle : GraphRole::kMtpPrefill);
  if (decode_bound) for (auto role : roles) if (drafts_token(role)) model.prepare_execution(pair, true, 1, role);
'''+s[b:]
s=s.replace('  std::size_t waiting_cursor = 0, cursor = 0, completed = 0, admitted = 0, idle_clock = 0;',
'''  std::size_t waiting_cursor = 0, completed = 0, admitted = 0, idle_clock = 0;
  struct BatchObservation { std::size_t tokens; GraphRole role; bool generation; std::vector<std::size_t> members; };
  std::vector<BatchObservation> batches; batches.reserve(requested_outputs);
  std::size_t actual_prefill_calls = 0, actual_decode_calls = 0;
  double actual_step_sum = 0;''',1)
a=s.index('  while (completed != requests.size()) {',s.index('int run_mtp_sessions('))
b=s.index('  const auto post_endpoint_seconds',a)
s=s[:a]+r'''  while (completed != requests.size()) {
    while (active.size() < model.cache_plan.resident_sessions && waiting_cursor < waiting.size()) {
      const auto index = waiting[waiting_cursor++]; auto &request = requests[index];
      request.admission_start = Clock::now();
      if (!request.session) {
        while (resident_count() >= model.cache_plan.resident_sessions) {
          std::size_t victim = requests.size();
          for (std::size_t i = 0; i < requests.size(); ++i)
            if (requests[i].session && std::find(active.begin(), active.end(), i) == active.end() &&
                (victim == requests.size() || requests[i].last_idle < requests[victim].last_idle)) victim = i;
          if (victim == requests.size()) throw std::runtime_error("all MTP heads are generating; no idle owner may be evicted");
          retire_mtp_request(requests[victim]); ++requests[victim].idle_evictions; evictions.push_back(victim);
        }
        if (request.ledger->committed_count) {
          const auto restore_trace = request.trace.empty() ? request.trace : request.trace / "restores" / ("restore" + std::to_string(request.restore_count));
          request.session = rebuild_mtp_session(model, *request.ledger, restore_trace, trace_states, &request.restored, prefix.get(), requests);
          ++request.restore_count;
        }
      }
      if (request.turn_index) {
        if (!request.session) throw std::runtime_error("later MTP turn requires its rebuilt complete head");
        (*request.warm_inputs[request.turn_index])[0] = request.generated.back();
      }
      request.prompt = *request.warm_inputs[request.turn_index]; request.prefilled = false; request.done = false;
      request.turn_output_begin = request.generated.size(); request.turn_observations[request.turn_index].output_begin = request.generated.size();
      active.push_back(index); ++admitted;
    }
    if (active.empty()) throw std::runtime_error("MTP admission has no runnable resident request");
    // Resolve every lookup/admission in this wave before any checkpoint is
    // published. A same-wave prompt cannot observe another member's new head.
    std::vector<PreparedMtpCall> calls; calls.reserve(active.size());
    for (auto index : active) {
      auto &request = requests[index];
      std::cerr << "mtp_session id=" << request.id << " turn=" << request.turn_index + 1 << " episode=" << request.rounds.size() << '\n';
      calls.push_back(prepare_mtp_call(model, request, cache::add(request.turn_output_begin, request.turns[request.turn_index].steps), prefix.get(), requests));
    }
    std::vector<bool> executed(calls.size(), false);
    for (std::size_t first = 0; first < calls.size(); ++first) {
      if (executed[first]) continue;
      std::vector<std::size_t> selected; selected.reserve(model.cache_plan.active_sequences);
      for (std::size_t j = first; j < calls.size() && selected.size() < model.cache_plan.active_sequences; ++j)
        if (!executed[j] && calls[j].full_hit == calls[first].full_hit &&
            calls[j].generation == calls[first].generation && calls[j].role == calls[first].role &&
            calls[j].ids().size() == calls[first].ids().size() && (!calls[first].full_hit || selected.empty())) selected.push_back(j);
      std::vector<PreparedMtpCall> bucket; bucket.reserve(selected.size());
      for (auto j : selected) bucket.push_back(calls[j]);
      while (!bucket[0].full_hit && !make_mtp_batch_room(model, prefix.get(), bucket, requests)) {
        if (bucket.size() == 1) throw std::runtime_error("MTP committed budget cannot advance its selected request");
        bucket.pop_back(); selected.pop_back();
      }
      std::cerr << "mtp_batch requests=" << bucket.size() << " T=" << (drafts_token(bucket[0].role) ? 2 : bucket[0].ids().size())
                << " role=" << static_cast<int>(bucket[0].role) << " full_hit=" << bucket[0].full_hit << '\n';
      execute_mtp_calls(model, bucket, trace_states, prefix.get(), requests);
      auto finished = endpoint;
      std::vector<std::size_t> members; members.reserve(bucket.size());
      for (std::size_t j = 0; j < bucket.size(); ++j) {
        executed[selected[j]] = true; const auto index = active[selected[j]];
        dispatch.push_back(index); dispatch_turns.push_back(requests[index].turn_index); members.push_back(index);
        finished = (std::max)(finished, requests[index].endpoint);
      }
      const auto seconds = std::chrono::duration<double>(finished - endpoint).count();
      (bucket[0].generation ? decode_seconds : prefill_seconds) += seconds; endpoint = finished;
      if (!bucket[0].full_hit) {
        (bucket[0].generation ? actual_decode_calls : actual_prefill_calls)++;
        actual_step_sum += bucket[0].step_seconds;
        batches.push_back({drafts_token(bucket[0].role) ? 2 : bucket[0].ids().size(), bucket[0].role, bucket[0].generation, std::move(members)});
      }
      peak_resident = (std::max)(peak_resident, resident_count());
      peak_committed = (std::max)(peak_committed, std::size_t(model.snapshot_versions.live));
      if (model.snapshot_versions.live > model.cache_plan.resident_sessions) throw std::runtime_error("MTP committed version count exceeds N after publication");
    }
    for (auto &call : calls) publish_mtp_prompt(model, call, prefix.get());
    for (auto at = active.begin(); at != active.end();) {
      const auto index = *at; auto &request = requests[index];
      if (!request.done) { ++at; continue; }
      at = active.erase(at);
      if (request.turn_index + 1 == request.turns.size()) { retire_mtp_request(request); ++completed; }
      else { request.last_idle = ++idle_clock; ++request.turn_index; waiting.push_back(index); }
    }
  }
'''+s[b:]
s=s.replace('  const auto graph_calls = cache::add(cache::add(prefill_calls, decode_calls), restored.graph_calls);',
'''  const auto graph_calls = cache::add(cache::add(actual_prefill_calls, actual_decode_calls), restored.graph_calls);''',1)
s=s.replace('<< ",\\\"active_sequences\\\":1,\\\"max_sessions\\\":"', '<< ",\\\"active_sequences\\\":" << model.cache_plan.active_sequences << ",\\\"max_sessions\\\":"',1)
s=s.replace('<< ",\\\"prefill_graph_calls\\\":" << prefill_calls << ",\\\"decode_graph_calls\\\":" << decode_calls',
'''<< ",\\\"prefill_graph_calls\\\":" << actual_prefill_calls << ",\\\"decode_graph_calls\\\":" << actual_decode_calls
      << ",\\\"graph_participations\\\":" << prefill_calls + decode_calls''',1)
s=s.replace('<< ",\\\"step_sum_seconds\\\":" << step_sum_seconds + restored.step_seconds',
'''<< ",\\\"step_sum_seconds\\\":" << actual_step_sum + restored.step_seconds
      << ",\\\"participation_step_sum_seconds\\\":" << step_sum_seconds''',1)
s=s.replace('''      if (active_sequences > 1)
        throw std::runtime_error("--mtp on currently requires --active-sequences auto or 1; sessions are interleaved at R1");
      active_sequences = 1;''','',1)
p.write_text(s)
