"""Freeze the consumer-only first implementation; no compilation or inference."""
from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
relative = Path('tools/qwen35_text/main.cc')
source = R / relative
before = S / 'before' / relative
expected = 'fec0ae846af8cac287bf590a6dbaec69cc3879634aaf50406764a8870b494ce7'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == expected
target = S / 'source' / relative
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(data)
diff = ''.join(difflib.unified_diff(before.read_text().splitlines(True), source.read_text().splitlines(True),
                                 fromfile='before/' + relative.as_posix(), tofile=relative.as_posix()))
diff_path = S / 'diff/main.cc.diff'
diff_path.parent.mkdir(parents=True, exist_ok=True)
diff_path.write_text(diff, encoding='utf-8')

def identity(path):
    content = path.read_bytes()
    return dict(path=str(path.relative_to(R)).replace('\\', '/'), bytes=len(content), sha256=hashlib.sha256(content).hexdigest())

record = dict(status='SOURCE_FROZEN_NOT_COMPILED_OR_GPU_RUN', source=identity(source), before=identity(before),
              snapshot=identity(target), diff=identity(diff_path), helper=identity(R / 'tools/qwen35_text/mtp_graph.h'),
              probe=identity(R / 'tools/qwen35_text/mtp_session_probe.cc'),
              owned_product_files=[relative.as_posix()], host_TUs_to_recompile=['qwen main', 'probe(s) including main.cc'],
              public_or_native_ABI_changes=False, SDK_builds=0, native_builds=0, GPU_runs=0,
              checks=['manual exact before diff', 'git diff --check', 'C++ lexical delimiter balance (not a compiler)'],
              API=dict(selection='MtpGenerationSelection{shared_ptr<Session> session,int32_t expected_pending,size_t output_quota}',
                       batch_finish='Model::finish_mtp_rounds(span<const Selection>,span<const int32_t> eos,span<const EvaluationOutput>,span<MtpRoundResult>)',
                       single_finish='Model::finish_mtp_round(Session&,int32_t expected_pending,size_t quota,span<const int32_t> eos={},const EvaluationOutput*=nullptr)',
                       normal_rebuild='rebuild_mtp_session(Model&,const MtpReplayLedger&,trace={},trace_states=true,MtpRestoreStats*=nullptr,PrefixCache*=nullptr,span<const MtpGenerationRequest>={}) -> shared_ptr<Session>',
                       strict='restore_mtp_session keeps original-role strict R1 diagnostics; rejects R>1/unknown imported geometry',
                       committed_ids='MtpReplayRecord::committed_ids(): exact original prompt span or bounded inline accepted inputs [pending,accepted draft]'),
              implemented=['per-member MTP projection/positions/carry and 14-bank composition/reframe/tail ownership',
                           'post-retirement independent quota/EOS/pending selection followed by all-head/witness publication',
                           'normal committed-token rebuild using original accepted chunks, fresh predictions, normalized lag0',
                           'CLI real equal-kind/role/T buckets, no padding, multi-turn idle LRU and complete prompt prefix reuse',
                           'wave lookup before execution and checkpoint publication after all wave buckets',
                           'global actual batch calls/wall once, per-session participation/latency, explicit restore work/decision changes',
                           'inline short scratch for R1/B2; ordinary finish adds no witness-vector allocation'],
              not_proven=['C++ compilation', 'actual R2 MTP result/retirement', 'normal rebuild numeric evidence',
                          'CLI pressure/prefix/legacy regression', 'performance or quality'],
              numerical_contract='Immutable emitted output history is retained; normal rebuild may change fresh state/greedy/proposals. It is not exact original B2 replay or a model-quality claim.')
(S / 'source-freeze.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(identity(S / 'source-freeze.json')))
