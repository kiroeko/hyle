"""Read-only design report from retained local source; no model work."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def identity(name: str) -> dict:
    path = ROOT / name
    raw = path.read_bytes()
    return {"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def anchor(name: str, needle: str) -> dict:
    lines = (ROOT / name).read_text(encoding="utf-8").splitlines()
    return {"path": name, "line": next(i for i, line in enumerate(lines, 1) if needle in line), "text": needle}


def main() -> None:
    helper = "tools/qwen35_text/mtp_graph.h"
    model = "tools/qwen35_text/main.cc"
    report = {
        "status": "read-only implementation design; no product changes, builds or GPU execution",
        "conclusion": "True equal-T MTP request batching can use the original single Recipe/Graph/Invocation chain, ordinary views/Concat/Gather/RoPE and existing paged BatchSchema. No new operation/provider/executor or host draft-to-target round trip is required. RS1 restrictions are in consumer helper geometry and single-member transaction plumbing, not the public tensor operators.",
        "sources": [identity(name) for name in (helper, model,
            "tools/qwen35_text/session_state.h", "include/hyle/compute/operation.h",
            "include/hyle/compute/batch_layout.h", "src/compute_ops/operation.cc",
            "src/compute_provider_ggml_cuda/tensor_program.cc")],
        "source_scope": "Source identities describe the inspected base (main40103f1f/helperfcae), not a future implementation or a runtime closure.",
        "existing_reuse": [
            {"fact": "input_projection already consumes flat I32[P] and BF16[P,2048]. Its embedding Gather, F32(raw+1) norms, BF16 concatenation/fc and input norm are independent per row; request-major P=R*T can reuse this code.",
             "anchor": anchor(helper, "Projection input_projection")},
            {"fact": "Recipe already defines a shared per-request T=last_row+1 and request-major packed_rows=R*T. All24 target layers are one batched graph, not duplicated24-layer graphs per request.",
             "anchor": anchor(model, "packed_rows = requests == 1 ? token_rows")},
            {"fact": "Public RoPE accepts batched positions matching the data prefix through sequence_axis. [R,T,H,D] with sequence_axis1 and I32[R,T] is directly expressible, with each request's actual base position independent of the others.",
             "anchor": anchor("src/compute_ops/operation.cc", "RoPE batched positions must match the data prefix through sequence")},
            {"fact": "BatchSchema already groups request-major query rows with query_indptr, independent KV page references and last-page lengths; packed query/output extent is the sum of real request rows, without padding.",
             "anchor": anchor("include/hyle/compute/batch_layout.h", "struct HostBatchLayout final")}
        ],
        "RS1_changes_required": [
            "project_kv/full_head currently reshape to[1,projection.rows,H,D] and coordinates accepts rank1 positions only. Carry logical request count and per-request sequence rows alongside flat packed rows, and use[R,Td,H,D]/positions[R,Td] for R>1.",
            "prefill_kv currently shifts globally on flat axis0 and requires old carry[1,2048]. Reshape target hidden to[R,T,2048], shift/Concat on axis1 within each request, then flatten. Global flat shift would leak the previous request's last hidden into the next request.",
            "full_head currently selects one Slice row and declares[1,V]/[1,1]. For R>1, use caller/cold I32 selected-row indices[r*Td+local_last] and ordinary axis0 Gather after finalnorm to material[R,2048], tied BF16 head[R,248320], CastF32 and TopK IDs[R,1]. R1 keeps its original Slice/Copy route.",
            "Main currently has one carry/prior/catchup port, scalar first_input/draft_token, one draft layout and member0 prepare/take/ready/ledger restrictions. Generalize these to per-member ports/scalars and one composed request-major draft layout, preserving the existing multi-head publication transaction."
        ],
        "minimal_geometry_interface": {
            "proposal": "Keep Projection.rows as total packed rows, and carry the caller's request count plus actual shared per-request rows into project_kv/full_head/prefill shift (two explicit geometry arguments or one tiny consumer-private shape tuple). This is shape metadata only, not a cache/executor framework. Append still receives flat key/value rows.",
            "identity": "Main constructs per-request Td and packed R*Td once and shares those Dimension identities with positions and helper output specs. Do not independently recreate dimension_sum/product in helpers: derived dimensions are not interned.",
            "R1": "Use defaults/straight-through geometry for R1 and retain the exact original material/rounding boundaries. Avoid an extra input copy or host-generated mutable per-token index buffer for the R1 path."
        },
        "shapes": [
            {"item": "target supplied prompt", "shape": "I32[R*T] request-major; target positions I32[R,T]", "note": "May have different L_r, but actual T equal within the bucket."},
            {"item": "target normalized hidden", "shape": "BF16[R*T,2048] <-> view[R,T,2048]", "note": "Post-final-RMS hidden, not pre-norm residual."},
            {"item": "carry/prior input leases", "shape": "R separate BF16[1,2048] inputs -> Concat axis0[R,2048] -> view[R,1,2048]", "note": "Each port is bound from its own Snapshot. No state from the previous carrier borrower remains as math input."},
            {"item": "draft projection", "shape": "I32[R*Td] + BF16[R*Td,2048]", "note": "Td=T+lag for prompt; Td=lag+1 for generation/Single."},
            {"item": "draft K/RoPE", "shape": "BF16[R,Td,2,256] with I32[R,Td] positions, then flat BF16[R*Td,2,256]", "note": "rotary64 halfsplit, theta1e7, same BF16/F32 norms."},
            {"item": "draft Q/gate", "shape": "BF16[R,Td,8,512] -> last-axis query256/gate256; query[R,Td,8,256]", "note": "Keep gate Slice/Copy and BF16 sigmoid/multiply boundaries."},
            {"item": "draft paged attention", "shape": "Q/output BF16[R*Td,8,256], query_indptr=[0,Td,2Td,...,R*Td]", "note": "Each request has its own D_r, KV refs and last-page length; same lag does not require same context length."},
            {"item": "draft selected logits", "shape": "Gather hidden indices[r*Td+lag] -> BF16[R,2048] -> BF16[R,V] -> F32[R,V]; TopK I32[R,1]", "note": "Proposal remains a device value until the whole original graph terminates."},
            {"item": "target verification input", "shape": "pending view I32[R,1] Concat(axis1) proposal I32[R,1] -> [R,2] -> flat I32[2R]", "note": "Correct order is[p0,d0,p1,d1,...], never[p0,p1,...,d0,d1,...]."},
            {"item": "target verification output", "shape": "BF16[2R,2048], logitsF32[2R,V], IDs I32[2R,1]", "note": "Member r owns candidate rows2r and2r+1. Acceptance/remaining quota/EOS is selected per member only after real terminal wait."}
        ],
        "index_examples": {
            "R2_lag0_round": {"draft_ids": ["pA", "pB"], "draft_hidden": ["carryA", "carryB"], "selected_flat_rows": [0, 1], "target_ids": ["pA", "dA", "pB", "dB"]},
            "R2_lag1_round": {"draft_ids": [["catchA", "pA"], ["catchB", "pB"]], "draft_hidden": [["priorA", "carryA"], ["priorB", "carryB"]], "positions": [["LA-1", "LA"], ["LB-1", "LB"]], "selected_flat_rows": [1, 3]},
            "R2_T3_lag1_prompt": {"target_ids": [["pA", "uA0", "uA1"], ["pB", "uB0", "uB1"]], "draft_ids": [["catchA", "pA", "uA0", "uA1"], ["catchB", "pB", "uB0", "uB1"]], "draft_hidden": [["priorA", "carryA", "newhA0", "newhA1"], ["priorB", "carryB", "newhB0", "newhB1"]], "query_indptr": [0, 4, 8]}
        },
        "target_RNN_verify_reuse": {
            "conv": "Inputs remain BF16[R,3,6144]; new qkv[R,T,6144] is concatenated on time to[R,T+3,6144]. Existing F32 causal-conv then BF16/Silu boundaries remain. T2 row0 history is original samples[:,1:4], row1 is samples[:,2:5], then per-request Slice and material Copy to[1,3,6144].",
            "GDN": "Current code packs F32[R,16,128,128] initial state, F32 Q/K/V/g/beta and requests snapshot_count2 for targetT2. Output state is F32[R,2,16,128,128]. It already slices request first, then chronological alternative, reshapes to[1,16,128,128], and material Copies both alternatives. All36 original state outputs remain independent leases.",
            "head": "Current verifies_two already exports both target hidden rows and carries per request; finish selects accepted_tokens1/2 for each member before complete-head swaps. Those per-member loops are reusable. The MTP-specific member0 portions and scalar ledger/selector gates are the parts to generalize.",
            "anchors": [anchor(model, "auto first = r.slice(samples, 1, f(1), f(3));"), anchor(model, ".snapshot_count = verifies_two(role) ? 2u : 1u"), anchor(model, "auto per_request = r.slice(recurrent[1], 0, f(static_cast<std::int64_t>(request)), f(1));")],
            "actual_evidence_boundary": "Retained whole-Qwen batch_probe is R2/T1 ordinary text; retained target_probe is R1/T2. CUDA GDN snapshot neighbors use two batches and multiple chronological snapshots. These provide components/source coverage, not an already-run whole-Qwen R2/T2 MTP claim.",
            "existing_sources": ["tools/qwen35_text/batch_probe.cc:312", ".scratch/qwen-mtp-graph-20261022/target_probe.cc:299", "tests/compute_provider_ggml_cuda/tensor_test.cc:441", "tests/compute_models/gdn_snapshot_fixture.h:19"]
        },
        "resources_and_transaction": [
            "Bucket by exact role, actual per-request T and lag; quota/context1 requests use Single/CatchupSingle buckets, not padded T2 rows. Post-episode accepted1/2 may differ and produce next lag0/1, so regroup next time.",
            "Compose all old draft frames through the original PagedArena::reframe, build one request-major draft layout, and bind the same two draft append nodes. There remain14 bank effects per graph, not14*R separate graphs. Typed per-member projections/read permissions and complete old-tail metadata remain mandatory.",
            "A round starts targetL_r/draftL_r-lag and appends draft lag+1 rows, so new draft frontier is L_r+1. Target commit a_r1/2 ends L_r+a_r and new lag=a_r-1. accepted2 retains prior row0 and catchup proposal; accepted1 uses row0 target state/carry and keeps lag0. Narrow rejected target row1 authority and discard its mutable tail capability as today, without rewinding an already published frontier.",
            "Export all members'36state/carry/prior outputs before first take. Complete14 ready/project/unbind/base checks for every member before any head swap. Prevalidate all witness slots and then commit all member heads/records with no fallible work between them. A stopped participant aborts the whole active batch as the original episode contract requires.",
            "Plan already supports N+R Snapshot candidates, N+2R recurrent alternatives, 2*(N+R) hidden rows and N*ceil(C/16)+R pages independently in each of14 banks. Schema must reserve Rmax*max(targetT,draftTd) active query rows, max_requestsRmax and aggregate KV bounds.",
            "Postcommit distinct versions obey L+R-D<=N, where D counts distinct selected base versions that truly lose their last owners. Shared base aliases/prefix Hits cannot be counted once per Session; directory eviction alone is not byte or version release."
        ],
        "precision_geometry": {
            "preserve": "Same trained weights, BF16 material node boundaries, F32 raw+1 norms/state/attention behavior, real rotary coordinates, BF16 LM output then F32 logits and stable TopK policy. Request reshape/Concat must not transpose token-major and request-major order.",
            "not_guaranteed": "Changing R*Td or R*T changes native matrix geometry/reduction choices. R1 and B2 can differ numerically or choose a different near-tie greedy ID / MTP accept boundary even with no state leak. No batch invariance, byteexactness, acceptance ratio or quality threshold is established by this design.",
            "relevant_local_fact": "W control2 at one exact checkpoint showed T1/T2 shape alone could flip near-tie top2. That was a finite native-control result, not proof that every batching difference is harmless or that B2 is wrong.",
            "scope": "Same-B/role/T before-after regression and full per-member state isolation are meaningful; do not demand or claim R1 byte equality as the general B2 contract. No new numerical tolerance is proposed here."
        },
        "general_cache_recompute_direction": {
            "assessment": "Recomputing actual committed token chunks is a simpler general cache policy than preserving every original speculative cohort/execution DAG. It reconstructs a logically equivalent consumed prefix under the selected current numerical geometry; it does not promise the original state bytes, argmax or accept decisions.",
            "actual_chunks": "For each old round append only the accepted prefix of actual target inputs: accept2 adds[pending,natural_draft]; reject/Single adds[pending]. record.emitted holds successor predictions and must not be used directly as that round's consumed input. Warm adds[previously returned pending]+new user IDs once.",
            "draft": "Use existing Prefill/Single for recomputed committed target chunks, pairing reconstructed target h[p-1] with each actual token to rebuild draft through the whole prefix. Canonical restored draft frontier=L, lag0, no retained prior/catchup token. No old proposal is forced or accepted anew during recomputation.",
            "pending": "Keep the last already returned, not-yet-consumed token as an engine CPU fact, separate from fresh head.next_id (the new recompute prediction). Report a difference rather than overwrite either fact. A later user warm naturally consumes[fact_pending]+U. Natural generation with no new user input needs its selector to validate against that separately trusted published pending fact.",
            "current_required_seam": "Current prepare/finish_mtp_round uses base.next_id as pending policy authority. If fresh recompute prediction differs from the previously returned pending, it rejects the real history token. Add a small consumer-private explicit expected-pending fact at the generation policy boundary (or equivalent independently maintained Session fact), retaining the actual first-input postwait check. Do not overwrite head.next_id or globally remove the teacher-forced-generation guard.",
            "strict_diagnostic": "Keep original-role/T2/accept-boundary ledger replay as an optional strict numerical/protocol diagnostic. It need not be the sole general cache restoration policy. Exact B2 replay would need actual geometry/cohort history; this design does not implement it and does not recommend keeping every cohort resident.",
            "lifetime": "Still retire/drop the old resident head before rebuilding within N+R; keep only host token facts during reconstruction, count restore work and preserve actual native page/lease retirement. A directory key/frame stamp is never suffix write authority."
        },
        "implementation_order": [
            "Generalize only helper shape/index metadata and batched carry/prior/token packing, retaining R1 forms and same graph math.",
            "Reuse the already general R>1 target/kVerify Conv/GDN and whole-batch publication loops; generalize the2draft-bank composition, per-member scalar decisions and all-witness commit.",
            "Enable bounded equal-role/T/lag request buckets only after one actual original-Invocation B2 path exists. Separately choose general committed-prefix recompute semantics and explicit pending fact; do not silently run strict old R1 replay for B2 history."
        ],
        "activity": {"product_edits": 0, "builds": 0, "GPU_runs": 0, "model_computations": 0},
        "not_claimed": "No MTP batching runtime, CLI implementation, measured performance, quality/acceptance guarantee, new public cache contract, other-model support or native backend extension."
    }
    output = HERE / "helper-review.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(identity(output.relative_to(ROOT).as_posix())))


if __name__ == "__main__":
    main()
