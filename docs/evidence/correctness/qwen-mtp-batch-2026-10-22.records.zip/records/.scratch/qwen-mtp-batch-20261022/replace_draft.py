from pathlib import Path
p=Path('tools/qwen35_text/main.cc')
s=p.read_text()
a=s.index('  void prepare_draft_append(StepState &step, GraphRole role) {')
b=s.index('\n  void prepare_evaluations(',a)
replacement=r'''  void prepare_draft_append(StepState &step, GraphRole role) {
    auto &phase = *step.phase; auto &run = *step.run;
    const auto width = step.members.size();
    const auto rows = is_mtp_prefill(role) ? cache::add(step.input_tokens, draft_lag(role)) : draft_lag(role) + 1;
    std::vector<std::int32_t> query{0}, old_ptr{0}, next_ptr{0}, old_last, next_last;
    std::vector<std::int32_t> old_ids, next_ids, positions, catchups;
    for (auto *table : {&query, &old_ptr, &next_ptr, &old_last, &next_last}) table->reserve(width + 1);
    positions.reserve(cache::multiply(width, rows)); catchups.reserve(width);
    std::size_t old_count = 0, next_count = 0;
    for (const auto &member : step.members) {
      old_count = cache::add(old_count, member.base->draft->pages.size());
      next_count = cache::add(next_count, (cache::add(member.base->draft->frontier, rows) + cache::Plan::page_rows - 1) / cache::Plan::page_rows);
    }
    old_ids.reserve(old_count); next_ids.reserve(next_count);
    for (std::size_t j = 0; j < width; ++j) {
      auto &member = step.members[j]; auto &session = *member.session;
      const auto &old = *member.base->draft;
      member.next->draft.emplace(); auto &next = *member.next->draft;
      next.frontier = cache::add(old.frontier, rows);
      if (next.frontier > capacity) throw std::runtime_error("draft cache exceeds context capacity");
      const auto prefix_pages = old.frontier / cache::Plan::page_rows;
      const auto count = (next.frontier + cache::Plan::page_rows - 1) / cache::Plan::page_rows;
      const auto dirty_count = count - prefix_pages, old_tail = old.frontier % cache::Plan::page_rows;
      bool reuse = old_tail && session.draft_tail_head == member.base.get() && !old.pages.empty();
      if (reuse) for (const auto &tail : session.draft_tails)
        reuse = reuse && tail.valid() && !tail.reserved_rows() &&
            tail.page() == old.pages.back().page() && tail.initialized_rows() == old_tail;
      next.pages.reserve(count);
      for (std::size_t bank = 12; bank < 14; ++bank) step.dirty[bank].reserve(cache::add(step.dirty[bank].size(), dirty_count));
      if (reuse) {
        const auto added = static_cast<std::uint32_t>((std::min)(rows, cache::Plan::page_rows - old_tail));
        std::size_t reserved = 0; hyle::Status status;
        for (; reserved < session.draft_tails.size(); ++reserved) {
          status = session.draft_tails[reserved].reserve_rows(added); if (!status.ok()) break;
        }
        if (!status.ok()) {
          for (std::size_t i = 0; i < reserved; ++i) check(session.draft_tails[i].rollback());
          if (!status.IsUnavailable()) check(status);
          reuse = false;
        }
      }
      for (std::size_t page = 0; page < prefix_pages; ++page) next.pages.push_back(old.pages.at(page));
      if (reuse) {
        next.pages.push_back(old.pages.back());
        for (std::size_t bank = 0; bank < 2; ++bank) step.tails[12 + bank].push_back(std::move(session.draft_tails[bank]));
      } else session.draft_tails = {};
      session.draft_tail_head = nullptr;
      for (std::size_t page = reuse ? 1 : 0; page < dirty_count; ++page) {
        auto reservation = take(draft_inventory.acquire()); next.pages.push_back(std::move(reservation.reference));
        step.dirty[12].push_back(std::move(reservation.keys[0])); step.dirty[13].push_back(std::move(reservation.values[0]));
      }
      for (const auto &page : old.pages) old_ids.push_back(static_cast<std::int32_t>(page.page()));
      const auto begin = next_ids.size();
      for (const auto &page : next.pages) next_ids.push_back(static_cast<std::int32_t>(page.page()));
      query.push_back(static_cast<std::int32_t>((j + 1) * rows));
      old_ptr.push_back(static_cast<std::int32_t>(old_ids.size())); next_ptr.push_back(static_cast<std::int32_t>(next_ids.size()));
      old_last.push_back(old.frontier ? static_cast<std::int32_t>((old.frontier - 1) % cache::Plan::page_rows + 1) : 0);
      next_last.push_back(static_cast<std::int32_t>((next.frontier - 1) % cache::Plan::page_rows + 1));
      const std::array<std::int32_t, 2> one_query{0, static_cast<std::int32_t>(rows)}, one_kv{0, static_cast<std::int32_t>(count)};
      member.draft_layout = take(attention_schema.version({one_query, one_kv, std::span(next_ids).subspan(begin, count), std::span(&next_last.back(), 1)}));
      for (std::size_t i = 0; i < rows; ++i) positions.push_back(static_cast<std::int32_t>(old.frontier + i));
      const auto &ports = phase.draft_hidden_inputs[j];
      check(run.bind(ports[0], dense(Type::kBFloat16, {1, hidden}), member.base->carry_hidden));
      if (draft_lag(role)) {
        catchups.push_back(old.catchup_token);
        check(run.bind(ports[1], dense(Type::kBFloat16, {1, hidden}), member.base->prior_hidden));
      }
    }
    const auto layout = width == 1 ? step.members[0].draft_layout : take(attention_schema.version({query, next_ptr, next_ids, next_last}));
    std::vector<std::int32_t> old_query(width + 1, 0);
    const auto old_layout = width == 1 ? c::BatchLayoutVersion{} : take(attention_schema.version({old_query, old_ptr, old_ids, old_last}));
    std::vector<c::PagedArenaRead> sources(width);
    for (std::size_t bank = 12; bank < 14; ++bank) {
      auto &arena = bank == 12 ? draft_inventory.keys[0] : draft_inventory.values[0];
      for (std::size_t j = 0; j < width; ++j) sources[j] = bank == 12 ? step.members[j].base->draft->key : step.members[j].base->draft->value;
      const auto previous = width == 1 ? sources[0] : take(arena.reframe(old_layout, sources));
      step.appends[bank] = take(g::batch::PagedAppendPages::create(arena, layout, previous,
          step.dirty[bank], step.tails[bank], {.resource_budget = cache_budget}));
    }
    phase.draft_positions.write<std::int32_t>(positions);
    if (draft_lag(role)) phase.catchup_token.write<std::int32_t>(catchups);
  }
'''
s=s[:a]+replacement+s[b:]
p.write_text(s)
