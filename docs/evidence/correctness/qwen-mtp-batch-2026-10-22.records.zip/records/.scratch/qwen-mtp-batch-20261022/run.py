"""Finite actual natural-turn MTP/resume checks. Reuse model/toolchain caches."""
from pathlib import Path
import argparse,importlib.util,json,os,sys
sys.dont_write_bytecode=True
Z=Path(__file__).resolve().parent;R=Z.parents[1]
s=importlib.util.spec_from_file_location('build',Z/'build_hyle.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c

def prepare():
 f=Z/'fixtures';f.mkdir(exist_ok=False)
 ids=list(map(int,(R/'.scratch/qwen-mtp-weights-20261022/prepared/prompt.ids').read_text().split()))
 for name,tokens in [('p15',ids[:15]),('p23',ids[:23]),('u1',[ids[16]]),('u8',ids[:8]),('u24',ids[:23]+[ids[16]])]:
  (f/(name+'.ids')).write_text(' '.join(map(str,tokens))+'\n')
 (f/'a.txt').write_text('prompt p15.ids\ngenerate 8\nprompt u1.ids\ngenerate 4\n')
 (f/'a-long.txt').write_text('prompt p15.ids\ngenerate 8\nprompt u24.ids\ngenerate 4\n')
 (f/'b.txt').write_text('prompt p15.ids\ngenerate 4\nprompt u1.ids\ngenerate 4\n')
 (f/'c.txt').write_text('prompt p23.ids\ngenerate 16\nprompt u8.ids\ngenerate 4\n')
 (f/'sessions.txt').write_text('A a-long.txt\nB b.txt\nC c.txt\n')
 (f/'shorthand.txt').write_text('prompt p15.ids\n')
 (f/'tape.txt').write_text('prompt p15.ids\ndecode u1.ids\n')
 (f/'incomplete.txt').write_text('prompt p15.ids\ngenerate 4\nprompt u1.ids\n')
 (f/'empty.txt').write_text('')
 (f/'zero.txt').write_text('prompt p15.ids\ngenerate 0\n')
 (f/'too-long.txt').write_text('prompt p23.ids\ngenerate 64\nprompt u8.ids\ngenerate 64\n')
 p=f/'single';p.mkdir();os.link(R/'.scratch/qwen-mtp-weights-20261022/prepared/weights.tsv',p/'weights.tsv');(p/'prompt.ids').write_text(' '.join(map(str,ids[:15]))+'\n')
 p=f/'ordinary';p.mkdir();os.link(R/'.scratch/qwen-mtp-window-20261022/inputs/text/weights.tsv',p/'weights.tsv');(p/'prompt.ids').write_text(' '.join(map(str,ids[:23]))+'\n')

def run(name,args,probe=False):
 ready=c.read(Z/('mtp_session-ready-attempt1.json'if probe else'qwen-ready-attempt1.json'))
 assert all(h.same(ready[k])for k in('image','source','main'))
 out=Z/('probe-run1'if probe else'cli-runs1/'+name);out.mkdir(parents=True,exist_ok=False)
 command=[ready['image']['path'],*args]
 if probe:command+=['--output',str(out/'vectors')]
 else:command+=['--trace',str(out/'trace'),'--trace-level','decisions']
 env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
 c.save(out/'plan.json',dict(command=command,ready=ready,diagnostic=True,throughput_evidence=False))
 c.execute('run',command,env,out)
 if not probe:c.save(out/'parsed.json',json.loads((out/'run.stdout.log').read_text().splitlines()[-1]))

def positive():
 f=Z/'fixtures';base=['--inputs',str(f/'single'),'--mtp','on','--capacity','64','--prefix-cache','off','--progress','direct','--replay','auto','--session-schedules',str(f/'sessions.txt')]
 for name,n,width in [('r1-resident',3,1),('r1-recompute',1,1),('r2-resident',3,2),('r2-recompute',2,2)]:
  run(name,base+['--max-sessions',str(n),'--active-sequences',str(width)])
 run('r2-prefix',base+['--max-sessions','2','--active-sequences','2','--prefix-cache','auto'])
 run('r2-whole-hits',['--inputs',str(f/'single'),'--mtp','on','--capacity','64','--session-schedules',str(f/'prefix4.txt'),'--max-sessions','2','--active-sequences','2','--prefix-cache','auto'])
 run('single',['--inputs',str(f/'single'),'--mtp','on','--capacity','64','--steps','4'])
 run('ordinary',['--inputs',str(f/'ordinary'),'--capacity','64','--steps','4'])

def warm():
 f=Z/'fixtures';base=['--inputs',str(f/'single'),'--mtp','on','--capacity','64','--prefix-cache','off','--session-schedules',str(f/'warm-sessions.txt'),'--max-sessions','2']
 for name,width in [('r1-warm',1),('r2-warm',2)]:run(name,base+['--active-sequences',str(width)])

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','positive','probe','warm']);a=p.parse_args()
 if a.mode=='prepare':prepare()
 elif a.mode=='positive':positive()
 elif a.mode=='warm':warm()
 else:run('resume',['--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),'--scenario','batch'],True)
