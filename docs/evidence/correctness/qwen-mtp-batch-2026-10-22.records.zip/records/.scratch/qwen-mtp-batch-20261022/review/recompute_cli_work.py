"""Offline AA scalar/ledger accounting. No tensor payload reads or subprocesses."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import shlex

S = Path(__file__).resolve().parents[1]
COUNT = 0
EOS = {248044, 248046}


def check(value, reason):
    global COUNT
    COUNT += 1
    if not value:
        raise AssertionError(reason)


def close(a, b, reason, tol=2e-12):
    check(math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, rel_tol=tol, abs_tol=tol), reason)


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def option(command, name):
    return command[command.index(name) + 1]


def fnv(ids):
    h = 1469598103934665603
    for value in ids:
        h = ((h ^ value) * 1099511628211) & ((1 << 64) - 1)
    return h


def specs(command):
    manifest = Path(option(command, '--session-schedules'))
    out = {}
    for line in manifest.read_text().splitlines():
        sid, filename = shlex.split(line)
        p = manifest.parent / filename
        lines = [shlex.split(line) for line in p.read_text().splitlines() if line.strip()]
        out[sid] = [(list(map(int, (p.parent / lines[i][1]).read_text().split())), int(lines[i + 1][1]))
                    for i in range(0, len(lines), 2)]
    return out


def result(path, expected=0):
    r = read(path)
    check(r['terminal'] and r['exit'] == expected and r['finished'] >= r['started'], str(path))
    return r


def main():
    ready = read(S / 'qwen-ready-attempt1.json')
    check(ready['main']['sha256'] == 'fec0ae846af8cac287bf590a6dbaec69cc3879634aaf50406764a8870b494ce7', 'compiled main identity')
    arms, raw = {}, {}
    for d in sorted((S / 'cli-runs1').iterdir()):
        name = d.name
        receipt = result(d / 'run.result.json')
        p = read(d / 'parsed.json'); raw[name] = p
        log = (d / 'run.stderr.log').read_text()
        check(p == json.loads((d / 'run.stdout.log').read_text().splitlines()[-1]), name + ' parsed is actual stdout')
        plan = read(d / 'plan.json')
        check(receipt['command'] == plan['command'] and plan['ready']['image'] == ready['image'], name + ' actual command/image')
        check(log.count('resident text weights:') == 1 and p['diagnostic'], name + ' one model load / diagnostic')
        close(p['prefill_seconds'] + p['decode_seconds'], p['session_seconds'], name + ' global P+D=wall')
        arm = {'terminal_exit': 0, 'raw_directory': str(d.relative_to(S)), 'diagnostic': True,
               'timing_seconds': {k: p[k] for k in ('prefill_seconds', 'decode_seconds', 'session_seconds')}}
        if 'sessions' not in p:
            check(p['generated_tokens'] == len(p['generated_ids']), name + ' flat output count')
            arm['work'] = {k: p[k] for k in ('actual_graph_calls', 'actual_target_rows', 'actual_draft_rows', 'generated_ids')}
            arms[name] = arm
            continue
        spec = specs(receipt['command']); summaries = []; new_by_session = {}; restores = []
        for session_index, e in enumerate(p['sessions']):
            sid, r, ledger = e['session_id'], e['result'], e['ledger']
            emitted = []; last_length = 0; counts = Counter(); current_turn = 0; current_begin = 0
            new_records = []; turn_data = []
            for i, x in enumerate(ledger):
                label = f'{name}/{sid}/{i}'
                check(x['index'] == i and x['before_length'] == last_length, label + ' committed length continuity')
                check(x['before_length'] - x['before_frontier'] == x['before_lag'] and x['before_lag'] in (0, 1), label + ' old lag')
                if x['generation']:
                    ids = [emitted[-1]]; quota = spec[sid][current_turn - 1][1] - (len(emitted) - current_begin)
                    check(x['quota'] == quota and quota > 0 and ids[0] not in EOS, label + ' actual emitted pending/quota')
                    check(x['role'] == ((6 if x['before_lag'] else 5) if quota == 1 else (4 if x['before_lag'] else 3)), label + ' generation shape')
                    accepted_draft = x['role'] in (3, 4) and x['draft'] == x['target_first'] and quota >= 2 and x['target_first'] not in EOS
                    check(x['accepted'] == 1 + int(accepted_draft), label + ' fresh acceptance and EOS')
                    committed = ids + ([x['draft']] if accepted_draft else [])
                    check(committed == x['committed_input_ids'], label + ' committed tape excludes unconsumed bonus')
                    outputs = [x['target_first']] + ([x['target_second']] if accepted_draft else [])
                    counts['decode_graph_calls'] += 1
                    counts['verified_target_rows'] += 2 if x['role'] in (3, 4) else 1
                    counts['draft_rows'] += x['draft_rows']
                    counts['agreements'] += int(x['role'] in (3, 4) and x['draft'] == x['target_first'])
                    counts['accepted_drafts'] += int(accepted_draft)
                else:
                    current_turn += 1; current_begin = len(emitted)
                    check(x['turn'] == current_turn, label + ' prompt turn')
                    user, quota = spec[sid][current_turn - 1]
                    ids = ([emitted[-1]] if current_turn > 1 else []) + user
                    check(x['accepted'] == len(ids) and x['quota'] == 0, label + ' prompt consumed input')
                    check(x['role'] == (6 if x['before_lag'] else 5) if len(ids) == 1 else x['role'] == (7 if x['before_lag'] else 2), label + ' prompt role')
                    committed = ids; outputs = [x['target_first']]
                    turn_data.append({'turn': current_turn, 'user_rows': len(user), 'actual_prompt_rows': len(ids),
                                      'draft_rows': x['draft_rows'], 'quota': quota, 'input_pending': ids[0] if current_turn > 1 else None,
                                      'role': x['role'], 'requests': x['requests'], 'imported': x['imported']})
                    if not x['imported']:
                        counts['prefill_graph_calls'] += 1; counts['prefill_target_rows'] += len(ids)
                        counts['prefill_draft_rows'] += x['draft_rows']
                check(x['input_rows'] == len(ids) and x['first_input'] == ids[0] and x['input_hash'] == fnv(ids), label + ' original input/hash')
                check(x['draft_rows'] == (len(ids) + x['before_lag'] if not x['generation'] else 1 + x['before_lag']), label + ' draft writer rows')
                check(x['after_length'] == x['before_length'] + len(committed), label + ' committed rows')
                check(x['after_frontier'] == x['before_frontier'] + x['draft_rows'] and x['after_length'] - x['after_frontier'] == x['after_lag'], label + ' new frontier')
                emitted.extend(outputs); last_length = x['after_length']
                check(x['next_id'] == outputs[-1], label + ' fresh next')
                if not x['imported']:
                    check(x['source_geometry'] == 'recorded', label + ' recorded geometry')
                    new_records.append(x)
                else:
                    check(x['requests'] == 0 and x['source_geometry'] == 'unknown' and x['trace_name'] == '', label + ' imported source not fake R1')
            check(emitted == r['generated_ids'] and emitted[-1] == r['emitted_pending'], name + sid + ' immutable outputs/pending')
            check((r['visible_tokens'], r['draft_frontier'], r['draft_lag'], r['fresh_next_id']) ==
                  (ledger[-1]['after_length'], ledger[-1]['after_frontier'], ledger[-1]['after_lag'], ledger[-1]['next_id']), name + sid + ' terminal head')
            for k, v in counts.items():
                check(r[k] == v, name + sid + ' ' + k)
            for turn, meta in zip(r['turns'], turn_data):
                outputs = emitted[turn['output_begin']:turn['output_end']]
                check(turn['requested_steps'] == meta['quota'] and turn['new_user_tokens'] == meta['user_rows'] and
                      turn['pending_flushed'] == int(turn['turn'] > 1), name + sid + ' turn plan')
                check(len(outputs) <= meta['quota'] and (len(outputs) == meta['quota'] or outputs[-1] in EOS), name + sid + ' quota/EOS stops turn')
                meta.update(actual_outputs=len(outputs), eos=outputs[-1] in EOS)
            close(sum(t['prefill_seconds'] for t in r['turns']), r['prefill_seconds'], name + sid + ' turn P')
            close(sum(t['decode_seconds'] for t in r['turns']), r['decode_seconds'], name + sid + ' turn D')
            close(r['prefill_seconds'] + r['decode_seconds'] + r['between_turn_seconds'], r['session_seconds'], name + sid + ' P+D+between=session')
            session_restores = []
            sd = d / 'trace' / f'session{session_index}_{sid}'
            for folder in sorted((sd / 'restores').glob('restore*')):
                episodes = sorted((v for v in folder.iterdir() if v.is_dir()), key=lambda v: int(v.name[7:]))
                check([v.name for v in episodes] == [f'episode{i}' for i in range(len(episodes))], name + sid + ' real contiguous rebuild episodes')
                prefix = ledger[:len(episodes)]
                tape = [x['committed_input_ids'] if x['generation'] else None for x in prefix]
                tr = sum(x['accepted'] for x in prefix)
                session_restores.append({'session': sid, 'episodes': len(prefix), 'target_rows': tr, 'draft_rows': tr,
                                         'normalized_lag_rows': prefix[-1]['after_lag'], 'tape': tape,
                                         'expected': prefix})
            check(len(session_restores) == e['restore_count'], name + sid + ' real restore count')
            for key in ('restored_graph_calls', 'restored_target_rows', 'restored_draft_rows', 'normalized_lag_rows'):
                source = {'restored_graph_calls': 'episodes', 'restored_target_rows': 'target_rows', 'restored_draft_rows': 'draft_rows', 'normalized_lag_rows': 'normalized_lag_rows'}[key]
                check(r[key] == sum(v[source] for v in session_restores), name + sid + ' ' + key)
            check(r['graph_participations'] == len(new_records) + r['restored_graph_calls'], name + sid + ' participations including restore')
            check(r['actual_target_rows'] == counts['prefill_target_rows'] + counts['verified_target_rows'] + r['restored_target_rows'], name + sid + ' target actual work')
            check(r['actual_draft_rows'] == counts['prefill_draft_rows'] + counts['draft_rows'] + r['restored_draft_rows'], name + sid + ' draft actual work')
            if r['prefix_full_hits']:
                hit = read(sd / 'prefill/cache-hit.json')
                check(hit['graph_calls'] == 0 and not hit['tensor_payload_available'] and hit['next_id'] == emitted[0], name + sid + ' true 0Graph hit')
                check(not list((sd / 'prefill').glob('*.f32')) and not list((sd / 'prefill').glob('*.bf16')), name + sid + ' no fake hit payload')
            for restore in session_restores:
                restore['decision_changes'] = r['decision_changes']
            restores.extend(session_restores); new_by_session[sid] = list(new_records)
            summaries.append({'session_id': sid, 'generated_ids': emitted, 'turns': turn_data,
                              'terminal': {k: r[k] for k in ('visible_tokens', 'draft_frontier', 'draft_lag', 'emitted_pending', 'fresh_next_id')},
                              'participations': r['graph_participations'], 'new_participations': len(new_records),
                              'restore_count': e['restore_count'], 'normalized_lag_rows': r['normalized_lag_rows'], 'decision_changes': r['decision_changes'],
                              'between_turn_seconds': r['between_turn_seconds']})
        cursors = Counter(); expected_steps = []
        for i, batch in enumerate(p['batches']):
            check(batch['index'] == i and batch['requests'] == len(batch['session_ids']) <= p['active_sequences'], name + ' real batch width')
            for j, sid in enumerate(batch['session_ids']):
                x = new_by_session[sid][cursors[sid]]; cursors[sid] += 1
                check(x['requests'] == batch['requests'] and x['member_index'] == j and x['role'] == batch['role'] and x['generation'] == batch['generation'], name + ' per-member actual geometry')
                check(batch['tokens'] == (2 if x['role'] in (3, 4) else x['input_rows']), name + ' actual target T')
                expected_steps.append((x['trace_name'], batch['tokens'], x['after_length'], x['next_id'], i))
        check(all(cursors[sid] == len(rows) for sid, rows in new_by_session.items()), name + ' every actual episode belongs to one batch')
        check(p['actual_graph_calls'] == len(p['batches']) + p['restored_graph_calls'], name + ' physical calls once')
        check(p['graph_participations'] == sum(b['requests'] for b in p['batches']), name + ' participations differ from calls')
        check(p['prefill_graph_calls'] == sum(not b['generation'] for b in p['batches']) and p['decode_graph_calls'] == sum(b['generation'] for b in p['batches']), name + ' physical phase calls')
        lines = re.findall(r'^(\S+) tokens=(\d+) visible=(\d+).*?step_seconds=([\d.e+-]+).*?next=(-?\d+)$', log, re.M)
        natural = [(a, int(b), int(c), float(t), int(e)) for a, b, c, t, e in lines if not a.startswith('episode')]
        check([(a, b, c, e) for a, b, c, _, e in natural] == [v[:4] for v in expected_steps], name + ' actual stderr episodes match ledger')
        unique_step = 0; seen = set()
        for row, expected in zip(natural, expected_steps):
            if expected[-1] not in seen:
                unique_step += row[3]; seen.add(expected[-1])
        groups = []
        for a, b, c, t, e in lines:
            if not a.startswith('episode'): continue
            idx = int(a[7:])
            if idx == 0: groups.append([])
            groups[-1].append((idx, int(b), int(c), float(t), int(e)))
        check(len(groups) == len(restores) == p['restore_count'], name + ' actual rebuild log groups')
        unmatched = list(restores); restored_step = 0; changes = []
        for group in groups:
            matches = [v for v in unmatched if len(group) == v['episodes'] and
                       [(r[0], r[1], r[2]) for r in group] == [(i, x['accepted'], x['after_length']) for i, x in enumerate(v['expected'])]]
            check(len(matches) == 1, name + ' rebuild matches exact committed chunks, not original verified rows')
            restore = matches[0]; unmatched.remove(restore)
            fresh_changes = [{'episode': i, 'historical_next': x['next_id'], 'fresh_next': row[4]}
                             for i, (x, row) in enumerate(zip(restore['expected'], group)) if x['next_id'] != row[4]]
            check(fresh_changes == restore['decision_changes'], name + ' actual fresh prediction changes')
            changes.extend(fresh_changes); restored_step += sum(r[3] for r in group)
        close(restored_step, p['restore_step_seconds'], name + ' real rebuild step sum', 2e-6)
        close(unique_step + restored_step, p['step_sum_seconds'], name + ' physical step time not summed participation latency', 2e-6)
        check(p['recomputed_decision_changes'] == len(changes), name + ' change count')
        for key in ('restored_graph_calls', 'restored_target_rows', 'restored_draft_rows', 'normalized_lag_rows'):
            check(p[key] == sum(e['result'][key] for e in p['sessions']), name + ' top ' + key)
        check(p['peak_committed_versions'] <= p['max_sessions'] and p['peak_resident_requests'] <= p['max_sessions'] and p['live_committed_versions'] <= p['max_sessions'], name + ' N budget')
        check(p['restore_contract'] == 'recompute_committed_inputs' and p['generated_tokens'] == sum(len(e['result']['generated_ids']) for e in p['sessions']), name + ' restore/output contract')
        arm.update(work={k: p[k] for k in ('max_sessions', 'active_sequences', 'shared_backing_bytes', 'actual_graph_calls', 'graph_participations',
                   'restored_graph_calls', 'restored_target_rows', 'restored_draft_rows', 'normalized_lag_rows', 'recomputed_decision_changes', 'generated_tokens',
                   'actual_target_rows', 'actual_draft_rows', 'prefix_full_hits', 'reused_tokens', 'peak_committed_versions', 'live_committed_versions')},
                   batch_geometries=dict(Counter(f"R{b['requests']}/T{b['tokens']}/role{b['role']}" for b in p['batches'])), sessions=summaries,
                   rebuilds=[{k: v for k, v in item.items() if k != 'expected'} for item in restores])
        arms[name] = arm
    differences = []
    for reference, name in [('r1-resident', v) for v in ('r2-resident', 'r2-recompute', 'r2-prefix')] + [('r1-warm', 'r2-warm')]:
        for left, right in zip(raw[reference]['sessions'], raw[name]['sessions']):
            a, b = left['result']['generated_ids'], right['result']['generated_ids']
            index = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), None)
            if index is not None:
                preceding = []
                for entry in (left, right):
                    count = 0
                    for x in entry['ledger']:
                        count += x['accepted'] if x['generation'] else 1
                        if count > index:
                            preceding.append({k: x[k] for k in ('index', 'role', 'requests', 'input_hash', 'first_input', 'before_length', 'before_frontier', 'before_lag', 'draft', 'target_first', 'target_second', 'accepted', 'committed_input_ids')}); break
                boundaries = ('role', 'input_hash', 'first_input', 'before_length', 'before_frontier', 'before_lag')
                differences.append({'comparison': reference + ' vs ' + name, 'session': left['session_id'], 'first_index_zero_based': index,
                                    'ordinal': index + 1, 'R1_id': a[index], 'other_id': b[index], 'deciding_records': preceding,
                                    'same_declared_input_boundary': all(preceding[0][k] == preceding[1][k] for k in boundaries),
                                    'same_committed_inputs_at_this_call': preceding[0]['committed_input_ids'] == preceding[1]['committed_input_ids'],
                                    'prior_GPU_state_equality_claimed': False})
    errors = []
    for d in sorted((S / 'errors1').iterdir()):
        if not d.is_dir(): continue
        result(d / 'run.result.json', 1)
        log = (d / 'run.stderr.log').read_text()
        check('weights_load_seconds=' not in log and 'resident text weights:' not in log and not (d / 'run.stdout.log').read_bytes(), d.name + ' reject before load')
        errors.append({'case': d.name, 'exit': 1, 'stderr': log.strip()})
    check(len(errors) == 8, 'eight early errors')
    result(S / 'probe-run1/run.result.json')
    probe = json.loads((S / 'probe-run1/run.stdout.log').read_text().splitlines()[-1])
    obs = read(S / 'probe-run1/vectors/observation.json')
    check(probe['actual_graph_calls'] == 14 and probe['all_finite'], 'actual probe summary')
    probe_scope = {k: obs[k] for k in ('status', 'actual_graph_calls', 'accepted_tokens', 'different_member_acceptance_observed',
                    'cancelled_whole_batch', 'blocked_candidates_retained', 'dropped_live_completion', 'same_R2_carrier_slot_retry',
                    'normal_rebuild_graph_calls', 'normal_rebuild_target_rows', 'normal_rebuild_draft_rows', 'normalized_lag_rows',
                    'canonical_teacherforced_rebuild_byte_exact', 'external_policy_original_prediction', 'external_policy_published_pending',
                    'external_pending_used_without_overwriting_head', 'managed_backing_bytes', 'planned_backing_bytes')}
    report = dict(status='PASS_OFFLINE_WORK_ACCOUNTING; cross-R outputs differ', source=ready['main'], recorded_image=ready['image'],
                  scope='Ten completed CLI processes, their scalar/ledger/log records, eight pre-load errors and probe summary only; no tensor payloads/build/GPU.',
                  checks=COUNT, arms=arms, cross_R_output_differences=differences, early_errors=errors, probe_reported_observation=probe_scope,
                  conclusions=['R2 resident: 17 physical Graph calls / 20 new member participations. R2 N2 recompute: 16 new batches + 10 rebuild calls = 26; prefix-auto same main inputs has no artificial same-wave hit.',
                               'Each pressure case restores ten original accepted input chunks, 64 target + 64 draft rows, with one final lag row normalized. Fresh next changes remain diagnostics, not forced proposals or replay acceptance.',
                               'Four identical quota1 requests: first wave is one real B2 prefill, second wave two whole hits with zero Graph and no tensor payload; one prefix-owned committed version remains within N2.',
                               'Warm extra case actually runs R2/T2/role7 with draft3 rows per member; this is one shared catch-up prefill Graph.',
                               'A output index5 (6th output) differs: R1 271, R2 198. Equal pending/input token and length/frontier do not prove equal prior tensor state; do not attribute the change solely to the current MatMul or call this equal-quality evidence.',
                               'Global P+D equals token-visible wall once. Per-session participation/turn latency overlaps; between-turn idle is explicit. All runs are trace diagnostics, not throughput windows.'],
                  limitations=['No raw hidden/logits/KV/36-state/carry comparison was repeated; root owns payload ZIP linkage/byte/finite review.',
                               'The probe flags are read from real terminal observation, not independently recomputed tensor results here.',
                               'Committed-token recompute does not promise exact old B2 state, old lag or future greedy trajectory. No numerical tolerance or quality gate was invented.',
                               'State backing request bytes are not physical GPU peaks; workspace/IO/runtime memory are separate.',
                               'Only recorded image/source identities were bound; large binaries/weights/SDK closures were not rehashed.'])
    out = S / 'review/cli-work-analysis.json'
    out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'path': str(out), 'checks': COUNT, 'bytes': out.stat().st_size, 'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
