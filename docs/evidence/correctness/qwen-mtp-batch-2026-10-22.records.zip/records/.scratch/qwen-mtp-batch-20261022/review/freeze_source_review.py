"""Freeze the finite, source-only AA MTP batch review; never run a model."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
MAIN_SHA = "fec0ae846af8cac287bf590a6dbaec69cc3879634aaf50406764a8870b494ce7"
HELPER_SHA = "dbc30a0e0e71233f474230112cf5fa360570c741491d4f256cb9c54d6a8bd1c3"


def identity(path):
    path = ROOT / path
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


main = identity("tools/qwen35_text/main.cc")
helper = identity("tools/qwen35_text/mtp_graph.h")
assert main["sha256"] == MAIN_SHA, main
assert helper["sha256"] == HELPER_SHA, helper
lines = (ROOT / main["path"]).read_text(encoding="utf-8").splitlines()


def anchor(needle):
    found = [i + 1 for i, line in enumerate(lines) if needle in line]
    assert len(found) == 1, (needle, found)
    return {"path": main["path"], "line": found[0], "text": needle}


report = {
    "status": "FINAL_SOURCE_REVIEW_NO_BLOCKING_FINDING",
    "scope": "Finite review of the AA equal-T MTP Model transaction, generation helpers, committed-token rebuild and CLI wave driver. This is not a build, native-runtime, numerical-quality or throughput result.",
    "sources": [main, helper],
    "findings": [],
    "checked": [
        {
            "topic": "Actual old draft frame authority and per-member geometry",
            "anchor": anchor("  void prepare_draft_append(StepState &step, GraphRole role)"),
            "facts": [
                "The shared old layout is constructed from every member's real frontier/page list and arena.reframe receives the corresponding existing key/value PagedArenaRead owners. Numeric page IDs alone do not grant read permission.",
                "Old carry/prior and catch-up inputs are bound per member; positions are request-major old.frontier+i. The common row count follows the exact selected role/lag.",
                "Draft tail reuse requires the original base identity, exact page and initialized frontier, plus reserve_rows on both original capabilities. Failed reservation rolls back already-reserved tails; the ordinary COW path remains available. Containers needed for moves are reserved before capability transfer."
            ]
        },
        {
            "topic": "Whole-batch publication and returned ownership",
            "anchor": anchor("  void finish_selected_evaluations(std::span<const EvaluationOutput> outputs,"),
            "facts": [
                "Participant, ledger uniqueness, original role/base/input and terminal completion checks precede selection. Selection is per member; every target/draft append is taken and made ready before publication.",
                "Common draft ready frames are projected back through each member's actual draft layout. Tail capabilities are mapped by physical page to the corresponding member and checked against its frontier. Rejected target suffix capability is discarded rather than rewound.",
                "All selected recurrent/hidden exports, frame projections, metadata checks and selective unbind complete before all member heads are swapped under the original serialized producer contract. No partial-head observation is introduced by this loop.",
                "Every reserved ledger record is marked committed only after every head swap; those scalar writes cannot allocate. The endpoint is then recorded via stable output ledger storage after detach, before diagnostic IO can throw."
            ]
        },
        {
            "topic": "Committed inputs and generation policy",
            "anchor": anchor("  std::span<const std::int32_t> committed_ids() const noexcept"),
            "facts": [
                "Accept2 records the actual consumed pending and natural draft; reject/Single records only the actual consumed pending. Prompt records retain their exact teacher-forced chunk owner. Successor emitted IDs are not misused as this step's consumed token tape.",
                "finish_mtp_rounds checks each retired member.first_input against its explicit expected_pending. This separates already-returned engine policy from the newly recomputed head prediction without overwriting head.next_id.",
                "Preallocated generated/round storage and two-ID emitted pools let observe_mtp_commits consume all committed witnesses even if later diagnostic IO throws. The model transaction remains authoritative."
            ]
            ,"selector_anchor": anchor("  void finish_mtp_rounds(std::span<const MtpGenerationSelection> selections,"),
            "observer_anchor": anchor("void observe_mtp_commits(MtpGenerationRequest &request)")
        },
        {
            "topic": "General cache rebuild versus strict replay",
            "anchor": anchor("std::shared_ptr<Session> rebuild_mtp_session(Model &model, const MtpReplayLedger &ledger,"),
            "facts": [
                "Rebuild prevalidates a continuous bounded committed input tape and legal accepted1/2 boundaries before executing. It reuses the original R1 Prefill/Single graph chain and normalizes the draft to lag0; it does not force old proposals, resample prior outputs or claim old B2 numerical identity.",
                "The old resident head must actually retire/drop before a new rebuild head can enter N. Returned pending remains the request's historical CPU output; fresh rebuild predictions are retained in the head and any differences are reported.",
                "Strict role/decision replay is separate and rejects non-R1 source geometry and imported prompt history with unknown original geometry (requests=0). It is not the universal cache-recovery contract."
            ],
            "strict_anchor": anchor("std::shared_ptr<Session> restore_mtp_session(Model &model, const MtpReplayLedger &ledger,")
        },
        {
            "topic": "Real wave batching, input lifetime and bounded admission",
            "anchor": anchor("int run_mtp_sessions(Model &model, std::span<const benchmark::MtpSessionSchedule> schedules,"),
            "facts": [
                "Every active request supplies at most one call per wave. Calls are grouped only by equal kind, role and actual rows, bounded by active_sequences, without padding. Every lookup/admission precedes every checkpoint publication in that wave.",
                "PreparedMtpCall::ids returns its own pending scalar after bucket copying. Prompt spans remain owned by per-turn warm_inputs and ledger input_owner. A request is not advanced twice before its original wave call is used to publish the prompt boundary.",
                "Admission counts distinct selected base heads once and treats directory aliases/unselected resident requests as external owners. It evicts only directory entries or truly idle requests; a generating request is protected. A smaller actual R may be chosen when the committed-version bound prevents the larger bucket.",
                "Finite cold families include actual possible prompt/suffix roles, compatible request widths, generation roles and R1 rebuild chunks. Plans are installed before execution carriers; no provider-specific executor or host draft-to-target handoff is introduced.",
                "Physical graph calls and step time are counted once per executed bucket. Per-session graph participation and interleaved latency remain separate report fields. Restore work is separately included in actual graph/row/time totals."
            ],
            "call_anchor": anchor("struct PreparedMtpCall final"),
            "admission_anchor": anchor("bool make_mtp_batch_room(Model &model, cache::PrefixCache *prefix,")
        }
    ],
    "limitations": [
        "This review found no blocking source defect in the named frozen files. It does not replace the root's strict compilation, original R1 regressions, actual R2 cancellation/retry, precision observations, CLI ledgers or performance measurements.",
        "Batched and R1 dense/quantized geometry may produce different floating-point predictions. Normal cache rebuild deliberately records such differences; no bytewise cross-geometry or general model-quality threshold is signed here.",
        "Budget reasoning is for the serialized consumer and its explicit session/directory owners, not an arbitrary external SnapshotRef graph. Real library permission, candidate admission and retirement gates remain authoritative.",
        "The helper's independent index check covers finite synthetic request/row indices only; it is not a device/model-math proof. No new tests, builds, GPU work or performance experiments were run by this review."
    ],
    "existing_helper_evidence": {
        "source_freeze": ".scratch/qwen-mtp-batch-20261022/helper/source-freeze.json",
        "index_review": ".scratch/qwen-mtp-batch-20261022/helper/index-review.json"
    },
    "builds": 0,
    "GPU_runs": 0,
    "product_edits_during_review": 0
}
OUT.mkdir(parents=True, exist_ok=True)
path = OUT / "source-review.json"
path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
freeze = {"status": "FROZEN_SOURCE_ONLY_REVIEW", "sources": [main, helper],
          "report": identity(path.relative_to(ROOT)),
          "script": identity(Path(__file__).relative_to(ROOT))}
(OUT / "source-review-freeze.json").write_text(
    json.dumps(freeze, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(freeze["report"], ensure_ascii=False))
