"""Actual CLI payloads, scoped equality, and fair cross-batch observations."""
from pathlib import Path
import hashlib,json,math,zipfile
import numpy as np
A=Path(__file__).resolve().parents[1];R=A.parents[1]
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def identity(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def norm(p):return str(p).replace('\\','/').casefold()
def values(raw,suffix):
 if suffix=='.bf16':
  assert len(raw)%2==0
  return(np.frombuffer(raw,dtype='<u2').astype(np.uint32)<<16).view(np.float32)
 assert suffix=='.f32'and len(raw)%4==0;return np.frombuffer(raw,dtype='<f4')
class Archive:
 def __init__(self):
  self.path=R/'docs/evidence/correctness/qwen-mtp-resume-2026-10-22.json';self.meta=load(self.path)
  self.zip=zipfile.ZipFile(self.meta['archives'][0]['path']);self.files={norm(v['path']):v for v in self.meta['archive_files']};self.used={}
 def raw(self,p):
  v=self.files[norm(p)];raw=self.zip.read(v['entry']);assert len(raw)==v['bytes']and hashlib.sha256(raw).hexdigest()==v['sha256']
  self.used[norm(p)]=v;return raw
def timing(d):
 p,q,w=[d[k]for k in ['prefill_seconds','decode_seconds','session_seconds']]
 assert p>0 and q>=0 and math.isclose(p+q,w,rel_tol=1e-12,abs_tol=1e-12)
 assert math.isclose(d['output_tokens_per_second'],d['generated_tokens']/w,rel_tol=1e-12)
 assert d['startup_to_ready_seconds']<=d['first_token_elapsed_seconds']<=d['startup_to_endpoint_seconds']
 return dict(P=p,D=q,wall=w,sum_error=p+q-w,diagnostic=True,performance_evidence=False)
def main():
 raw_files={};pairs=[];cross=[];skipped=[];runs=[];results={};old=Archive()
 def inspect(p):
  p=Path(p).resolve();raw=p.read_bytes();v=values(raw,p.suffix);assert np.isfinite(v).all(),str(p)
  raw_files[str(p)]=dict(**identity(p),elements=int(v.size),nonfinite=0);return raw
 def equal(p,ref,raw=None,label='same_geometry'):
  actual=inspect(p);reference=Path(ref).read_bytes()if raw is None else raw
  assert actual==reference and np.isfinite(values(reference,Path(p).suffix)).all(),(str(p),str(ref))
  pairs.append(dict(actual=str(p),reference=str(ref),label=label,bytes=len(actual),sha256=hashlib.sha256(actual).hexdigest(),byte_equal=True))
 names=['r1-resident','r1-recompute','r2-resident','r2-recompute','r2-prefix','r2-whole-hits','single','ordinary','r1-warm','r2-warm']
 ready=load(A/'qwen-ready-attempt1.json')
 for name in names:
  directory=A/'cli-runs1'/name;t=load(directory/'run.result.json');plan=load(directory/'plan.json');d=load(directory/'parsed.json')
  assert t['terminal']and t['exit']==0 and t['command']==plan['command']and plan['ready']==ready
  assert plan['diagnostic']and not plan['throughput_evidence']and json.loads((directory/'run.stdout.log').read_text())==d
  results[name]=d;runs.append(dict(case=name,terminal=identity(directory/'run.result.json'),parsed=identity(directory/'parsed.json'),timing=timing(d)))
  for p in(directory/'trace').rglob('*'):
   if p.suffix in('.bf16','.f32'):inspect(p)
 def files(name,logical=False):
  root=A/'cli-runs1'/name/'trace'
  return{p.relative_to(root).as_posix():p for p in root.rglob('*')if p.suffix in('.bf16','.f32')and(not logical or 'restores'not in p.relative_to(root).parts)}
 for name,previous in [('r1-resident','resident-n3'),('single','single'),('ordinary','ordinary')]:
  for rel,p in files(name).items():
   ref=R/'.scratch/qwen-mtp-resume-20261022/cli-runs1'/previous/'trace'/rel
   equal(p,ref,old.raw(ref),'unchanged_R1_or_ordinary')
 assert results['r2-prefix']['batches']==results['r2-recompute']['batches']
 assert files('r2-prefix').keys()==files('r2-recompute').keys()
 for rel,p in files('r2-prefix').items():equal(p,files('r2-recompute')[rel],label='same_actual_R2_partitions_prefix_off_vs_auto_misses')
 def transcripts(name):
  result={};warm='warm'in name
  for i,s in enumerate(results[name]['sessions']):
   sid=f"session{i}_{s['session_id']}";history=[]
   initial=load_ids('p15')if warm or i<2 else load_ids('p23')
   user=load_ids('u1')if warm and i==0 else load_ids('u_other')if warm else load_ids(['u24','u1','u8'][i])
   for v in s['ledger']:
    actual=(v['committed_input_ids']if v['generation']else initial if v['turn']==1 else[v['first_input'],*user])
    assert v['before_length']==len(history)and len(actual)==v['accepted']
    candidate=[v['first_input'],v['draft']]if v['role']in(3,4)else actual
    key=(tuple(history),tuple(candidate),v['role'])
    if not v['imported']:result[f"{sid}/{v['trace_name']}"]=(key,v)
    history.extend(actual);assert len(history)==v['after_length']
  return result
 def compare_scope(actual,reference):
  left,right=transcripts(actual),transcripts(reference)
  for phase,(signature,v)in left.items():
   if phase not in right or right[phase][0]!=signature:
    skipped.append(dict(actual=actual,reference=reference,phase=phase,reason='different actual history, candidate input, or role; not a numerical comparison'));continue
   for leaf in ['hidden.bf16','logits.f32']:
    p=files(actual,True)[phase+'/'+leaf];q=files(reference,True)[phase+'/'+leaf]
    x,y=inspect(p),q.read_bytes();assert len(x)==len(y)
    xv,yv=values(x,p.suffix).astype(np.float64),values(y,q.suffix).astype(np.float64);delta=xv-yv
    xx,yy=float(xv@xv),float(yv@yv);err=float(delta@delta)
    cross.append(dict(actual=str(p),reference=str(q),actual_requests=v['requests'],reference_requests=right[phase][1]['requests'],
     actual_role=v['role'],history_rows=v['before_length'],bytes=len(x),byte_equal=x==y,max_abs=float(np.max(np.abs(delta))),
     squared_error=err,relative_l2=math.sqrt(err/yy)if yy else None,cosine=float(xv@yv)/math.sqrt(xx*yy)if xx and yy else None,
     policy='same token history/candidate input/role; different batch or prior recompute geometry may change arithmetic; no quality threshold'))
 compare_scope('r2-resident','r1-resident');compare_scope('r1-recompute','r1-resident')
 compare_scope('r2-warm','r1-warm')
 divergences=[]
 for actual,reference in [('r2-resident','r1-resident'),('r1-recompute','r1-resident'),('r2-recompute','r2-resident'),('r2-warm','r1-warm')]:
  for a,b in zip(results[actual]['sessions'],results[reference]['sessions']):
   x,y=a['result']['generated_ids'],b['result']['generated_ids'];idx=next((i for i in range(min(len(x),len(y)))if x[i]!=y[i]),None)
   if idx is None and len(x)!=len(y):idx=min(len(x),len(y))
   divergences.append(dict(actual=actual,reference=reference,session_id=a['session_id'],first_different_zero_index=idx,
    actual_id=x[idx]if idx is not None and idx<len(x)else None,reference_id=y[idx]if idx is not None and idx<len(y)else None,
    actual_count=len(x),reference_count=len(y),same_output_ids=x==y))
 hits=results['r2-whole-hits'];assert(hits['actual_graph_calls'],hits['generated_tokens'],hits['prefix_full_hits'],hits['reused_tokens'])==(1,4,2,30)
 for sid in ['session2_C','session3_D']:
  root=A/'cli-runs1/r2-whole-hits/trace'/sid/'prefill'
  assert {p.name for p in root.iterdir()}=={'cache-hit.json'}
  assert load(root/'cache-hit.json')==dict(prefix_hit=True,graph_calls=0,tensor_payload_available=False,reused_tokens=15,next_id=198)
 warm=[v for v in results['r2-warm']['batches']if v['requests']==2 and v['role']==7]
 assert len(warm)==1 and warm[0]['tokens']==2
 errors=load(A/'review/errors-analysis.json');assert len(errors['cases'])==8 and errors['model_weight_loads']==0
 probe=load(A/'probe/actual-analysis.json');assert probe['status'].startswith('PASS')
 report=dict(status='PASS_SCOPED_CLI_EQUALITY_AND_FINITE_CROSS_GEOMETRY_OBSERVATIONS',runs=runs,results=results,
  raw_files=list(raw_files.values()),byte_exact_pairs=pairs,cross_geometry=cross,not_compared_work=skipped,output_divergences=divergences,
  old_archive_used=list(old.used.values()),probe_analysis=identity(A/'probe/actual-analysis.json'),early_errors=identity(A/'review/errors-analysis.json'),
  performance_window_performed=False,limits=['No throughput or physical-memory comparison; diagnostic trace timings are not speed evidence.',
   'R2 continuation differs from R1. Matching output IDs and finite vectors are not complete model quality evidence.',
   'Only original R1/ordinary and identical real R2 prefix-off/auto-miss partitions have byte-equality assertions. Other metrics have no invented quality tolerance.',
   'Input/history/role mismatches are skipped, not used as equal-work numerical comparisons.'])
 save(A/'review/actual-analysis.json',report)
 print(json.dumps(dict(status=report['status'],numeric_files=len(raw_files),byte_exact_pairs=len(pairs),cross_geometry_pairs=len(cross),work_mismatches_skipped=len(skipped),numeric_bytes=sum(v['bytes']for v in raw_files.values()))))
def load_ids(name):return list(map(int,(A/'fixtures'/(name+'.ids')).read_text().split()))
if __name__=='__main__':main()
