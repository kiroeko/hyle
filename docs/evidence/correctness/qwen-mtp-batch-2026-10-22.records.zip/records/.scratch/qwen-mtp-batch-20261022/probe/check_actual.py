"""Pure-host checks of the finite actual MTP B2 consumer; no native execution."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
SOURCE_SHA = '256253dd7df03975b84b618b71e946f6cc28cffd443345f9f2756b661bd2747b'
VOCAB = 248320


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for raw in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(raw)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify(record):
    found = identity(record['path'])
    assert (found['bytes'], found['sha256']) == (record['bytes'], record['sha256']), record
    return found


def scalar_values(raw, dtype):
    if dtype == 'BF16':
        assert len(raw) % 2 == 0
        return (np.frombuffer(raw, dtype='<u2').astype(np.uint32) << 16).view(np.float32)
    assert dtype == 'F32' and len(raw) % 4 == 0
    return np.frombuffer(raw, dtype='<f4')


def expected_inventory(head, rows):
    assert 0 < head['length'] <= 64
    assert head['draft_frontier'] + head['lag'] == head['length'] and head['lag'] in [0, 1]
    assert head['carry_bytes'] == 4096 and head['prior_bytes'] == (4096 if head['lag'] else 0)
    assert (head['catchup_token'] >= 0) == bool(head['lag'])
    assert 0 <= head['next_id'] < VOCAB
    expected = {}
    for layer in range(24):
        if layer % 4 != 3:
            expected[f'layer{layer}.conv.bf16'] = ('BF16', 36864)
            expected[f'layer{layer}.gdn.f32'] = ('F32', 1048576)
    for layer in range(6):
        for kind in ['key', 'value']:
            expected[f'target{layer}.{kind}.bf16'] = ('BF16', head['length'] * 1024)
    for kind in ['key', 'value']:
        expected[f'draft.{kind}.bf16'] = ('BF16', head['draft_frontier'] * 1024)
    expected['carry.bf16'] = ('BF16', head['carry_bytes'])
    expected['prior.bf16'] = ('BF16', head['prior_bytes'])
    assert len(expected) == 52
    expected['output.logits.f32'] = ('F32', rows * VOCAB * 4)
    expected['output.hidden.bf16'] = ('BF16', rows * 4096)
    assert len(expected) == 54
    return expected


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, default=STAGE / 'probe-run1')
    parser.add_argument('--ready', type=Path, default=STAGE / 'mtp_session-ready-attempt1.json')
    parser.add_argument('--output', type=Path, default=HERE / 'actual-analysis.json')
    args = parser.parse_args()
    # No polling, synthetic result, native process or fallback. Missing data fails.
    native = load(args.run / 'run.result.json')
    plan = load(args.run / 'plan.json')
    ready = load(args.ready)
    assert native['terminal'] and native['exit'] == 0
    assert native['command'] == plan['command'] and plan['ready'] == ready
    command = native['command']
    assert command[0] == ready['image']['path']
    assert command[command.index('--scenario') + 1] == 'batch'
    assert Path(command[command.index('--output') + 1]).resolve() == (args.run / 'vectors').resolve()
    assert ready['source']['sha256'] == SOURCE_SHA
    image_id = verify(ready['image'])
    verify(ready['link_plan'])
    verify(ready['runtime_environment'])
    link = load(ready['link_plan']['path'])
    verify(link['compiled_record'])
    compiled = load(link['compiled_record']['path'])
    assert compiled['source'] == ready['source'] and compiled['main'] == ready['main']
    assert any(row == ready['main'] for row in compiled['dependencies'])
    assert sum(row == compiled['object'] for row in link['inputs']) == 1
    source_snapshot = Path(link['compiled_record']['path']).parent / 'source/tools/qwen35_text/mtp_session_probe.cc'
    assert identity(source_snapshot)['sha256'] == SOURCE_SHA
    main_snapshot = next(path for path in STAGE.glob('compile*/qwen/source/tools/qwen35_text/main.cc')
                         if path.stat().st_size == ready['main']['bytes'] and identity(path)['sha256'] == ready['main']['sha256'])
    source_text = source_snapshot.read_text(encoding='utf-8-sig')
    batch_start = source_text.index('void run_batch(')
    prepare = source_text.index('model.prepare_evaluations(requests', batch_start)
    gate = source_text.index('gate.wait_until_entered(); model.submit_evaluations()', prepare)
    drop = source_text.index('episode->completion = {}', gate)
    blocked_check = source_text.index('!q::take(sessions[0]->try_retire())', drop)
    release = source_text.index('gate.release(); q::check(blocked.wait())', blocked_check)
    read_old = source_text.index('same(old_images[j],image(model,*old_heads[j]))', release)
    assert prepare < gate < drop < blocked_check < release < read_old
    observation_path = args.run / 'vectors/observation.json'
    observed = load(observation_path)
    assert observed['status'] == 'PASS_STRUCTURE_NUMERICAL_METRICS_RECORDED' and observed['scenario'] == 'batch'
    assert (observed['model_objects'], observed['weight_tensors'], observed['capacity']) == (1, 335, 64)
    assert (observed['resident_limit'], observed['active_sequences'], observed['actual_graph_calls']) == (4, 2, 14)
    assert observed['peak_live_snapshot_versions'] == 4 and observed['final_live_snapshot_versions'] == 0
    assert observed['old_head_full_byte_checks'] == 4 and observed['idle_B_full_byte_checks'] == 2
    assert (observed['versions_before_cancel'], observed['versions_blocked'], observed['versions_after_cancel']) == (2, 4, 2)
    assert observed['blocked_retirement_polls'] == 1
    for flag in ['all_finite', 'independent_ready_frames_and_states', 'cancelled_whole_batch',
                 'blocked_candidates_retained', 'dropped_live_completion', 'same_R2_carrier_slot_retry',
                 'canonical_teacherforced_rebuild_byte_exact', 'external_pending_used_without_overwriting_head']:
        assert observed[flag] is True, flag
    planned_backing = 14 * ((4 * 4 + 2) * 16 * 1024 + 1) + 19537920 * (4 + 2 * 2) + 36 + 4096 * (2 * (4 + 2)) + 1
    assert observed['managed_backing_bytes'] == observed['planned_backing_bytes'] == planned_backing == 160481331
    assert observed['timing_comparison'] is False and observed['numerical_tolerance_policy'] is None
    assert 'not a natural-greedy disagreement' in observed['external_sampling_policy']
    episodes = {row['name']: row for row in observed['episodes']}
    assert len(episodes) == len(observed['episodes']) == 10
    assert set(episodes) == {'reference_prefill0', 'reference_round0', 'reference_prefill1', 'reference_round1',
                             'batch_prefill0', 'batch_prefill1', 'batch_member0', 'batch_member1',
                             'warm_actual_pending_plus_user', 'external_sampled_pending'}
    for episode in episodes.values():
        row = episode['record']
        assert row['committed']
        assert 0 < row['accepted_tokens'] == len(episode['committed_inputs'])
        assert row['after']['length'] == row['before']['length'] + row['accepted_tokens']
        assert row['after']['length'] == row['after']['frontier'] + row['after']['lag']
        assert row['emitted'] and row['emitted'][-1] == row['after']['next_id']
        assert all(0 <= token < VOCAB for token in row['inputs'] + row['emitted'] + episode['committed_inputs'])
        if row['generation']:
            assert row['accepted_tokens'] in [1, 2] and len(row['inputs']) == 1
            expected = row['inputs'] + ([row['draft']] if row['accepted_tokens'] == 2 else [])
            assert episode['committed_inputs'] == expected
            assert row['accepted_draft'] == (row['accepted_tokens'] == 2)
            if row['accepted_draft']:
                assert row['draft'] == row['target_first'] and row['quota'] >= 2
                assert row['emitted'] == [row['target_first'], row['target_second']]
            else:
                assert row['emitted'] == [row['target_first']]
        else:
            assert episode['committed_inputs'] == row['inputs']
    for member in range(2):
        reference_seed = episodes[f'reference_prefill{member}']['record']
        seed = episodes[f'batch_prefill{member}']['record']
        actual = episodes[f'batch_member{member}']
        assert seed == reference_seed
        assert actual['requests'] == 2 and actual['member_index'] == member
        row = actual['record']
        assert row['role'] == 3 and row['generation'] and row['quota'] == (1 if member else 2)
        assert row['before'] == seed['after'] and row['inputs'] == [seed['after']['next_id']]
        assert row['after']['frontier'] == row['before']['frontier'] + 1
        assert row['after']['lag'] == row['accepted_tokens'] - 1
        assert row['after']['catchup_token'] == (row['draft'] if row['accepted_tokens'] == 2 else -1)
        assert row['accepted_tokens'] == observed['accepted_tokens'][member]
    assert observed['accepted_tokens'][1] == 1
    assert observed['different_member_acceptance_observed'] == (observed['accepted_tokens'][0] != observed['accepted_tokens'][1])
    a = episodes['batch_member0']['record']
    assert observed['historical_unconsumed_pending'] == a['after']['next_id']
    assert observed['normal_rebuild_graph_calls'] == 2
    assert observed['normal_rebuild_target_rows'] == observed['normal_rebuild_draft_rows'] == a['after']['length']
    assert observed['normalized_lag_rows'] == a['after']['lag']
    stdout = (args.run / 'run.stdout.log').read_text(encoding='utf-8-sig')
    final = json.loads(stdout.strip().splitlines()[-1])
    assert final['status'] == 'MTP_BATCH_PROBE_COMPLETED' and final['actual_graph_calls'] == 14
    assert final['mixed_acceptance_observed'] == observed['different_member_acceptance_observed']
    assert final['all_finite'] and final['timing_comparison'] is False
    labels = ['reference_member0', 'reference_member1', 'batch_member0', 'batch_member1',
              'canonical_committed_rebuild', 'normal_rebuild', 'warm_actual_pending_plus_user', 'external_sampled_pending']
    images = {row['label']: row for row in observed['images']}
    assert len(images) == len(observed['images']) == 8 and set(images) == set(labels)
    raw_manifest, by_component, payload_cache = {}, {}, {}

    def read_vector(path, dtype):
        key = str(Path(path).resolve())
        if key not in payload_cache:
            raw = Path(path).read_bytes()
            vals = scalar_values(raw, dtype)
            assert np.isfinite(vals).all(), path
            raw_manifest[key] = dict(path=key, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                                     dtype=dtype, elements=int(vals.size), nonfinite=0)
            payload_cache[key] = raw
        assert raw_manifest[key]['dtype'] == dtype
        return payload_cache[key]

    for label in labels:
        img = images[label]
        rows = 2 if label.startswith(('reference_member', 'batch_member')) or label == 'external_sampled_pending' else 1
        inventory = expected_inventory(img['metadata'], rows)
        assert len(img['vectors']) == 54 and {row['name'] for row in img['vectors']} == set(inventory)
        by_component[label] = {}
        for vector in img['vectors']:
            dtype, size = inventory[vector['name']]
            assert (vector['dtype'], vector['bytes']) == (dtype, size)
            raw = read_vector(vector['path'], dtype)
            assert len(raw) == size
            by_component[label][vector['name']] = vector
    assert sum(len(row['vectors']) for row in images.values()) == 432

    def payload(label, component):
        record = by_component[label][component]
        return read_vector(record['path'], record['dtype'])

    argmax_checks = []
    for label in ['reference_member0', 'reference_member1', 'batch_member0', 'batch_member1', 'external_sampled_pending']:
        episode_label = label.replace('reference_member', 'reference_round')
        episode = episodes[episode_label]['record']
        logits = scalar_values(payload(label, 'output.logits.f32'), 'F32').reshape(2, VOCAB)
        winners = np.argmax(logits, axis=1).tolist()  # First index implements deterministic lower-ID ties.
        assert winners == [episode['target_first'], episode['target_second']]
        hidden = payload(label, 'output.hidden.bf16')
        accepted = episode['accepted_tokens']
        assert payload(label, 'carry.bf16') == hidden[(accepted - 1) * 4096:accepted * 4096]
        assert payload(label, 'prior.bf16') == (hidden[:4096] if accepted == 2 else b'')
        assert images[label]['metadata']['next_id'] == winners[accepted - 1]
        argmax_checks.append(dict(label=label, independently_computed_ids=winners, accepted_tokens=accepted,
                                 selected_carry_matches_raw_hidden=True, prior_matches_acceptance=True))
    canonical = images['canonical_committed_rebuild']['metadata']
    rebuilt = images['normal_rebuild']['metadata']
    assert canonical == rebuilt
    assert rebuilt['length'] == rebuilt['draft_frontier'] == a['after']['length']
    assert rebuilt['lag'] == 0 and rebuilt['catchup_token'] == -1 and rebuilt['prior_bytes'] == 0
    assert rebuilt['next_id'] == observed['rebuilt_actual_prediction']
    changes = observed['recomputed_decision_changes']
    assert len({row['episode'] for row in changes}) == len(changes)
    source_records = [episodes['batch_prefill0']['record'], a]
    for change in changes:
        assert change['episode'] in [0, 1]
        assert change['historical'] == source_records[change['episode']]['after']['next_id']
        assert 0 <= change['fresh'] < VOCAB and change['fresh'] != change['historical']
        if change['episode'] == 1:
            assert change['fresh'] == rebuilt['next_id']
    final_changed = rebuilt['next_id'] != observed['historical_unconsumed_pending']
    assert observed['recomputed_decision_changed'] == final_changed
    assert any(row['episode'] == 1 for row in changes) == final_changed
    warm = episodes['warm_actual_pending_plus_user']['record']
    assert warm['turn'] == 1 and warm['role'] == 2 and not warm['generation']
    assert len(warm['inputs']) == 2 and warm['inputs'][0] == observed['historical_unconsumed_pending']
    assert warm['before']['length'] == rebuilt['length'] and warm['before']['next_id'] == rebuilt['next_id']
    assert warm['after']['length'] == rebuilt['length'] + 2
    policy = episodes['external_sampled_pending']['record']
    assert policy['turn'] == 1 and policy['role'] == 3 and policy['generation']
    assert policy['before'] == warm['after'] and policy['inputs'] == [observed['external_policy_published_pending']]
    assert observed['external_policy_original_prediction'] == warm['after']['next_id']
    assert observed['external_policy_published_pending'] != observed['external_policy_original_prediction']
    assert observed['external_policy_published_pending'] not in [248044, 248046]
    for label in ['canonical_committed_rebuild', 'normal_rebuild', 'warm_actual_pending_plus_user']:
        head = images[label]['metadata']
        winner = int(np.argmax(scalar_values(payload(label, 'output.logits.f32'), 'F32')))
        assert winner == head['next_id']
        assert payload(label, 'carry.bf16') == payload(label, 'output.hidden.bf16')
        assert payload(label, 'prior.bf16') == b''

    comparisons, metric_groups = [], dict(batch_member0=0, batch_member1=0, normal_rebuild=0)
    seen = set()
    for metric in observed['vectors']:
        assert metric['name'] not in seen
        seen.add(metric['name'])
        label, component = metric['name'].split('/', 1)
        assert label in metric_groups
        actual = by_component[label][component]
        reference_label = 'canonical_committed_rebuild' if label == 'normal_rebuild' else label.replace('batch_member', 'reference_member')
        reference = by_component[reference_label][component]
        assert (metric['actual'], metric['baseline'], metric['dtype'], metric['bytes']) == (
            actual['path'], reference['path'], actual['dtype'], actual['bytes'])
        x_raw = read_vector(reference['path'], reference['dtype'])
        y_raw = read_vector(actual['path'], actual['dtype'])
        assert len(x_raw) == len(y_raw)
        equal = x_raw == y_raw
        assert metric['byte_equal'] == metric['actual_reuses_baseline_payload'] == equal
        if equal:
            assert Path(metric['actual']) == Path(metric['baseline'])
        assert metric['nonfinite_baseline'] == metric['nonfinite_actual'] == 0
        x = scalar_values(x_raw, metric['dtype']).astype(np.float64)
        y = scalar_values(y_raw, metric['dtype']).astype(np.float64)
        difference = y - x
        maximum = float(np.abs(difference).max(initial=0))
        squared = float(np.dot(difference, difference))
        reference_squared = float(np.dot(x, x))
        for key, value in [('max_abs', maximum), ('squared_error', squared), ('reference_squared', reference_squared)]:
            assert math.isclose(metric[key], value, rel_tol=2e-12, abs_tol=1e-20), (metric['name'], key, metric[key], value)
        if label == 'normal_rebuild':
            assert equal  # Only the identical canonical TF contract has this byte oracle.
        metric_groups[label] += 1
        comparisons.append(dict(name=metric['name'], dtype=metric['dtype'], bytes=len(x_raw), byte_equal=equal,
                                baseline_sha256=hashlib.sha256(x_raw).hexdigest(), actual_sha256=hashlib.sha256(y_raw).hexdigest(),
                                nonfinite=0, max_abs=maximum, squared_error=squared, reference_squared=reference_squared,
                                relative_l2=math.sqrt(squared / reference_squared) if reference_squared else 0.0,
                                exact_oracle=label == 'normal_rebuild'))
    expected_changes = []
    for member in range(2):
        label = f'batch_member{member}'
        for component, actual in by_component[label].items():
            reference = by_component[f'reference_member{member}'][component]
            if (actual['dtype'], actual['bytes']) != (reference['dtype'], reference['bytes']):
                expected_changes.append(label + '/' + component)
            else:
                assert label + '/' + component in seen
    assert observed['cross_B_extent_changes'] == expected_changes
    assert metric_groups['normal_rebuild'] == 54 and final['compared_vectors'] == len(comparisons)
    result = dict(status='PASS_HOST_RAW_REVIEW_NUMERICAL_METRICS_ONLY', native_exit=0,
                  records=dict(ready=identity(args.ready), image=image_id, source=identity(source_snapshot), main=identity(main_snapshot),
                               terminal=identity(args.run / 'run.result.json'), plan=identity(args.run / 'plan.json'),
                               stdout=identity(args.run / 'run.stdout.log'), stderr=identity(args.run / 'run.stderr.log'),
                               observation=identity(observation_path), compiled_record=link['compiled_record']),
                  actual_graph_calls=14, complete_images=8, per_image_components=54, head_components=52,
                  image_vector_records=432, unique_raw_files=len(raw_manifest), unique_raw_bytes=sum(row['bytes'] for row in raw_manifest.values()),
                  all_finite=True, comparison_counts=metric_groups, cross_B_extent_changes=expected_changes,
                  cross_B_numeric_pairs=len(comparisons) - 54,
                  cross_B_nonbyte_pairs=sum(not row['byte_equal'] for row in comparisons if not row['exact_oracle']),
                  canonical_TF_rebuild=dict(compared_vectors=54, all_byte_equal=True, target_rows=observed['normal_rebuild_target_rows'],
                                            draft_rows=observed['normal_rebuild_draft_rows'], normalized_lag_rows=observed['normalized_lag_rows'],
                                            historical_pending=observed['historical_unconsumed_pending'], rebuilt_prediction=rebuilt['next_id'],
                                            decision_changes=changes),
                  per_member_acceptance=observed['accepted_tokens'], mixed_acceptance_observed=observed['different_member_acceptance_observed'],
                  argmax_and_carry_checks=argmax_checks,
                  lifetime=dict(N=4, R=2, versions_before_cancel=2, versions_blocked=4, versions_after_cancel=2,
                                one_blocked_poll=True, completion_dropped=True, actual_native_retirement=True, same_slot_retry=True,
                                final_versions=0, backing_bytes=planned_backing, old_full_byte_checks=4, idle_B_byte_checks=2),
                  external_sampling=dict(label='Explicit non-argmax emitted token policy, not natural numerical divergence',
                                         actual_head_prediction=observed['external_policy_original_prediction'],
                                         published_pending=observed['external_policy_published_pending'], expected_pending_honored=True),
                  raw_files=list(raw_manifest.values()), comparisons=comparisons,
                  limits=['R1 versus R2 natural proposals/accepted inputs may differ; same vector extent does not make those computations identical. No cross-B byte/ID or model-quality tolerance is asserted.',
                          'Canonical same-chunk R1 teacherforced rebuild alone has a byteexact oracle. Rebuilding a discarded B2 head is normal token recomputation, not exact old-state import.',
                          'Equal actual payloads explicitly reuse canonical baseline raw paths; native complete-array equality/oldhead checks are corroborated by exact compiled source and successful runtime assertions, not a second independently retained actual payload.',
                          'Gate/retirement/unchanged oldheads and absence of premature publication are native source/runtime assertions; offline logs cannot reconstruct all permission events.',
                          'Only this finite14Graph scene was checked. No performance, MTP concurrent multi-Invocation execution, other backend/quantization or whole-model quality claim.'])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ['status', 'actual_graph_calls', 'complete_images', 'image_vector_records',
                                                'comparison_counts', 'cross_B_nonbyte_pairs', 'mixed_acceptance_observed', 'all_finite']}, indent=2))


if __name__ == '__main__':
    main()
