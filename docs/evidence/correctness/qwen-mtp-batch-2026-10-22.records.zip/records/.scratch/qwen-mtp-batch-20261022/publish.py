"""Publish actual finite CUDA MTP batch/rebuild evidence, without a speed claim."""
from pathlib import Path
import difflib, hashlib, json, subprocess, zipfile

A = Path(__file__).resolve().parent
R = A.parents[1]
O = R / 'docs/evidence/correctness'
NAME = 'qwen-mtp-batch-2026-10-22'

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')

def identity(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=h.hexdigest())

sources = ['tools/qwen35_text/' + n for n in (
    'main.cc', 'mtp_session_probe.cc', 'mtp_graph.h', 'retirement_probe.cc',
    'mtp_schedule.h', 'session_schedule.h', 'schedule.h', 'README.md')]
sources += ['docs/developer/current-work.md', 'docs/architecture/compute-design.md']
frozen = []
for name in sources:
    p = R / name
    before = A / 'before' / name
    snapshot = A / 'current' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(p.read_bytes())
    assert before.exists(), name
    previous = before.read_text(encoding='utf-8-sig')
    diff = A / 'product-diffs' / (name.replace('/', '--') + '.diff')
    diff.parent.mkdir(exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff(previous.splitlines(True),
        p.read_text(encoding='utf-8-sig').splitlines(True), fromfile='before/' + name, tofile=name)), encoding='utf-8')
    check = subprocess.run(['git', 'diff', '--no-index', '--check', str(before), str(p)],
        capture_output=True, text=True, encoding='utf-8', errors='replace')
    assert check.returncode in (0, 1) and not (check.stdout.strip() or check.stderr.strip()), (name, check.stdout, check.stderr)
    frozen.append(dict(source=identity(p), snapshot=identity(snapshot), before=identity(before), diff=identity(diff)))
save(A / 'product-freeze.json', dict(files=frozen))

ready = {}
for tag in ('qwen', 'mtp_session'):
    record = read(A / f'{tag}-ready-attempt1.json')
    assert all(identity(record[k]['path']) == record[k] for k in ('image', 'source', 'main'))
    plan = read(record['link_plan']['path'])
    compiled = read(plan['compiled_record']['path'])
    assert all(identity(v['path']) == v for v in compiled['dependencies'])
    ready[tag] = record

probe = read(A / 'probe-run1/vectors/observation.json')
probe_analysis = read(A / 'probe/actual-analysis.json')
cli = read(A / 'review/actual-analysis.json')
work = read(A / 'review/cli-work-analysis.json')
assert probe['status'] == 'PASS_STRUCTURE_NUMERICAL_METRICS_RECORDED'
assert probe['actual_graph_calls'] == 14 and len(probe['images']) == 8
assert probe['final_live_snapshot_versions'] == 0
assert probe_analysis['image_vector_records'] == 432 and probe_analysis['unique_raw_files'] == 274
assert probe_analysis['canonical_TF_rebuild']['compared_vectors'] == 54
assert probe_analysis['canonical_TF_rebuild']['all_byte_equal']
assert probe_analysis['cross_B_numeric_pairs'] == 108 and probe_analysis['cross_B_nonbyte_pairs'] == 4
assert all(v['status'].startswith('PASS') for v in (probe_analysis, cli, work))
assert len(cli['raw_files']) == 308 and len(cli['byte_exact_pairs']) == 108
assert len(cli['cross_geometry']) == 84 and len(cli['not_compared_work']) == 6
assert work['checks'] == 2515
assert work['arms']['r2-recompute']['work']['recomputed_decision_changes'] == 1
errors = read(A / 'review/errors-analysis.json')
assert len(errors['cases']) == 8 and errors['model_weight_loads'] == errors['GPU_inference_runs'] == 0

runs = []
for directory in [A / 'probe-run1', *sorted((A / 'cli-runs1').iterdir())]:
    terminal = read(directory / 'run.result.json')
    assert terminal['terminal'] and terminal['exit'] == 0
    runs.append(dict(command=terminal['command'], terminal=identity(directory / 'run.result.json'),
        stdout=identity(directory / 'run.stdout.log'), stderr=identity(directory / 'run.stderr.log'),
        diagnostic=True, performance_evidence=False))
assert len(runs) == 11
reports = {p.name: read(p) for p in sorted((A / 'review').glob('*.json'))}
summary = dict(
    status='CUDA real MTP batch execution and committed-input cache rebuild implemented; finite checks passed with explicit cross-geometry numerical/output differences; broader goal remains active',
    date='2026-10-22', product_freeze=identity(A / 'product-freeze.json'), ready=ready,
    actual_runs=runs, actual_diagnostic_model_processes=11, early_validation_processes=8,
    build_scope=dict(host_compile_attempts=2, successful_host_compiles=2, successful_links=2,
        final_consumer_TUs=2, library_TUs=0, SDK_builds=0, NVCC_builds=0, full_configures=0,
        reused_link_inputs_per_consumer=194,
        note='Only main.cc and mtp_session_probe.cc compiled, both first attempt. retirement_probe.cc received mechanical explicit-pending API updates but was not compiled/run this batch. All native model runs use attempt1 images.'),
    reports=reports, probe=probe, probe_analysis=probe_analysis, performance_window_performed=False,
    findings=[
        'One shared335 Model, original ordinary Graph/Queue/Completion and14-bank append transaction remain authoritative. No new executor, native provider path or GPU history shadow was added.',
        'MTP graph helper has explicit requests/sequence_rows/packed_rows geometry and shared dimension identities. Packed request-major rows retain independent RoPE, per-request pending/draft concatenation and warm-input shifts. Existing target T2 Conv/GDN row boundaries supply each member selection.',
        'Actual finite CLI waves group by compatible real T, role and draft lag without padding, and respect N committed versions and state-byte budgets. Wave prefix lookups occur before new checkpoint publication. One actual bucket counts one physical Graph; each Session records its own participation.',
        'Each member derives its natural draft/target result and acceptance independently. Whole-batch expected-base validation precedes all no-throw head swaps; preallocated per-member commit witnesses become authoritative before trace/report IO. Cancelling any member cancels the original entire episode and retains resources until actual retirement.',
        'Normal cache recovery rebuilds original already-consumed input chunks, never resamples old generation. Accept2 consumes old pending plus old accepted draft, not bonus output. The original immutable host inputs and owned fixed-size accepted-input witnesses are retained; old GPU heads are truly retired under pressure.',
        'Rebuild uses original Graph teacher-forced Single/Prefill operations, normalizes draft to target prefix/lag0 and publishes only after complete success. The new head keeps its actual fresh prediction; already-issued unconsumed pending remains a separate engine fact. Strict original-role R1 replay remains diagnostic-only and rejects unknown/R>1 provenance.',
        'The14-Graph batch probe exercised natural per-member accepted lengths[2,1], separate projected frames/states and carry row selection. Blocking the actual CUDA queue retained versions2->4->2 through cancel, dropped Completion, native retirement and original R2-slot retry; final versions0.',
        'Eight54-component probe images yield432 vector records and274 unique raw payloads. Cross-B comparisons have108 finite metrics,104 byte-equal and4 differing draft K/V. Same-chunk canonical teacher-forced rebuild has54 byte-equal components;17 target/17 draft rows normalize one lag row.',
        'The natural probe rebuild happened to predict the same pending74455 and does not prove a natural mismatch. A separate explicit sampling-policy case consumes legal published248045 despite greedy74455, without overwriting head prediction. Actual R2 pressure CLI independently records one fresh-next decision change during normal rebuild.',
        'Ten CLI cases cover R1/R2 resident and pressure, prefix miss and full hit, original flat MTP/ordinary entries and a focused equal-length warm pair. Main3-session/2-turn runs have26 outputs and89 logical inputs=86 user+3 pending. R1resident uses19 Graph, R1N1 uses29=19+10 rebuild; R2resident uses17 Graph/20 participations; R2N2 uses26=16 new+10 rebuild,64target/64draft replay rows and one normalized lag.',
        'Four equal quota1 requests execute one real B2 prefill, then two complete prefix hits with zero Graph/no fabricated tensor payload,30 reused tokens and one remaining prefix-owned version within N2. Focused warm R2 actually runs role7 targetT2/draftT3 per member.',
        'CLI host review validates308 finite raw payloads,108 scoped byte-equal pairs and84 equal-input/history/role cross-geometry metrics. Six work mismatches are explicitly excluded from numerical comparisons.2515 independent scalar/work-accounting checks pass. Eight malformed/capacity inputs reject before weight loading.',
        'Cross-R output divergence is retained: mainA differs at zero-index5/R1=271,R2=198; warmB differs at zero-index4/R1=198,R2=271. At the main deciding call input/pending/draft/role/position match, but prior GPU state is not proved equal; the pressure deciding call is itself R1, so the cause cannot be attributed solely to current B2.',
        'Global P/D remain disjoint token-visible wall intervals and include recovery. Per-Session participation latency overlaps and cannot be summed as throughput. All11 native model processes are trace diagnostics; no new throughput, physical-memory or full quality window was run.'],
    limitations=[
        'These finite CUDA BF16 Qwen checks do not establish whole-model quality, all selected model/quant routes, other native backends, concurrent multi-Invocation serving or general batch-size invariance.',
        'Byte equality is asserted only for original same-partition R1/ordinary regressions, identical real R2 prefix-miss partitions and the canonical teacher-forced rebuild. No invented cross-B tolerance or forced historical proposal is used.',
        'Cross-B numeric and continuation differences remain unresolved. Different accepted candidate/history/role comparisons are not treated as equal work; equal input metadata alone does not establish equal prior tensor state.',
        'Probe actual full-array equality/oldhead/permission assertions are tied to frozen compiled source and successful native execution; canonical raw aliases are not represented as independently retained second payloads.',
        'retirement_probe.cc mechanical call updates are not a native compile/run result for that separate TU. The new batch scenario in mtp_session_probe.cc provides this batch cancellation/retirement checks.',
        'No new speed or physical-memory comparison. The previous complete four-metric current-work table remains authoritative; fewer Graph calls with different natural acceptance/work are not a speed claim.',
        'Extra capture invalidations, selected backend/model/quant coverage, image encoder/projector and full architecture audit remain active.'],
    previous_evidence=['docs/evidence/correctness/qwen-mtp-resume-2026-10-22.json',
        'docs/evidence/correctness/qwen-mtp-prefix-2026-10-22.json',
        'docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json'],
    remaining=['Resolve scoped cross-batch numerical/continuation differences and capture causes, then run an appropriate four-metric performance window.',
        'Continue other backend/model/quant, image projector and architecture work.'])
save(A / 'actual-summary.json', summary)

excluded = {'.exe', '.dll', '.obj', '.map', '.lib', '.exp', '.pdb', '.pyc'}
files = sorted(p for p in A.rglob('*') if p.is_file() and p.suffix.lower() not in excluded
    and not any(v in ('tmp', '__pycache__') for v in p.relative_to(A).parts)
    and p.name not in ('published.json', 'cleanup-plan.json', 'cleanup-result.json', 'cleanup_script.ps1', 'postconditions.json'))
archive = O / (NAME + '.data.zip')
assert not archive.exists()
entries, unique = [], {}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files:
        e = identity(p)
        key = (e['bytes'], e['sha256'])
        canonical = unique.get(key)
        if canonical is None:
            canonical = p.relative_to(R).as_posix()
            unique[key] = canonical
            z.write(p, canonical)
        else:
            e['identical_content_alias'] = True
        e['entry'] = canonical
        entries.append(e)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(unique)
    for (size, sha), entry in unique.items():
        raw = z.read(entry)
        assert len(raw) == size and hashlib.sha256(raw).hexdigest() == sha
manifest = O / (NAME + '.json')
assert not manifest.exists()
save(manifest, dict(**summary, archives=[identity(archive)], archive_files=entries,
    archive_verified=dict(CRC=True, all_unique_entry_SHA256=True, source_files=len(entries), unique_entries=len(unique),
        original_bytes=sum(e['bytes'] for e in entries), unique_bytes=sum(k[0] for k in unique),
        content_deduplication='Every original path retains SHA/size and canonical ZIP entry; identical payloads stored once.')))
published = dict(manifest=identity(manifest), archives=[identity(archive)])
save(A / 'published.json', published)
print(json.dumps(dict(**published, source_files=len(entries), unique_entries=len(unique),
    original_bytes=sum(e['bytes'] for e in entries), unique_bytes=sum(k[0] for k in unique)), indent=2))
