"""Only request-major matrix/index algebra; no Torch, C++ build or GPU."""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main() -> None:
    cases = 0
    for requests in (1, 2, 3, 4):
        for tokens in (2, 3, 8, 15, 16, 17):
            for lag in (0, 1):
                lengths = [17 + r * 13 for r in range(requests)]
                # Every request and logical position has its own row marker.
                target = [[(r, lengths[r] + t) for t in range(tokens)] for r in range(requests)]
                carry = [(r, lengths[r] - 1) for r in range(requests)]
                prior = [(r, lengths[r] - 2) for r in range(requests)]
                shifted = [([prior[r]] if lag else []) + [carry[r]] + target[r][:-1]
                           for r in range(requests)]
                draft_ids = [[(r, lengths[r] - lag + t) for t in range(tokens + lag)]
                             for r in range(requests)]
                for r in range(requests):
                    assert len(shifted[r]) == tokens + lag
                    for token, hidden in zip(draft_ids[r], shifted[r]):
                        assert token[0] == hidden[0] == r
                        assert token[1] - 1 == hidden[1]
                cases += 1
        for lag in (0, 1):
            draft_rows = lag + 1
            packed = [(r, t) for r in range(requests) for t in range(draft_rows)]
            selected = [packed[r * draft_rows + lag] for r in range(requests)]
            assert selected == [(r, lag) for r in range(requests)]
            target_pairs = [(r, name) for r in range(requests) for name in ("pending", "proposal")]
            assert target_pairs[::2] == [(r, "pending") for r in range(requests)]
            assert target_pairs[1::2] == [(r, "proposal") for r in range(requests)]
            cases += 1
    result = {"status": "PASS index/row-order assertions", "cases": cases,
              "scope": "Synthetic request markers and integer positions only. Not execution of the C++ template or model arithmetic.",
              "checked": ["prefill/catchup hidden never crosses a request", "each draft token pairs with h[position-1]", "local lag row equals flat r*Td+lag", "target pending/proposal pairs remain adjacent per request"]}
    (HERE / "index-review.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
