"""Freeze the single owned helper; main and all runtime work belong to root."""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def function(text: str, name: str) -> str:
    start = text.index(name)
    brace = text.index("{", start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[start:end]


def write(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    source = ROOT / "tools/qwen35_text/mtp_graph.h"
    before = HERE.parent / "before/tools/qwen35_text/mtp_graph.h"
    old = before.read_text(encoding="utf-8")
    new = source.read_text(encoding="utf-8")
    unchanged = ("Value linear_absolute(", "Value norm_absolute(", "Projection input_projection(", "AppendNodes append_kv(")
    for name in unchanged:
        assert function(old, name) == function(new, name), name
    assert "dimension_sum(" not in new and "dimension_product(" not in new
    frozen = HERE / "source/tools/qwen35_text/mtp_graph.h"
    frozen.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_bytes(source.read_bytes())
    diff = HERE / "implementation.diff"
    diff.write_text("".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile="before/tools/qwen35_text/mtp_graph.h", tofile="tools/qwen35_text/mtp_graph.h")), encoding="utf-8")
    report = {
        "status": "owned helper source implemented/frozen; not compiled or run on a device",
        "source": identity(source), "before": identity(before),
        "API": {
            "Geometry": "{size_t requests; Dimension sequence_rows,packed_rows;}",
            "project_kv": "(r,projection,positions,frequencies,const Geometry&)",
            "full_head": "(r,projection,kv,positions,frequencies,paged,last_row,const Geometry&)",
            "prefill_kv": "(r,target_ids,normalized_target_rows,carry,prior,catchup_token,const Geometry& target,const Geometry& draft,positions,frequencies,bool catchup)",
            "compatibility": "One updated private API; no old overload. Quant owns all main callsites. No public Compute/Graph ABI or provider/executor changes."
        },
        "geometry": [
            "Main creates each derived per-request/packed Dimension once. The helper never derives another sum/product. Positive geometry, R1 exact identity and fixed-product overflow/count mismatches are checked; original finite-child inference remains authoritative for symbolic products and Concat extents.",
            "R1 positions remain I32[Td]; R>1 requires I32[R,Td], shared actual dimensions. Q/K RoPE uses BF16[R,Td,H,D] with original rotary64/halfsplit/frequency32, then flat request-major rows for original append/attention.",
            "Batched full_head picks each local last_row via hidden view[R,Td,2048], axis1 Slice1, material Copy and view[R,2048]. This is equivalent to flat rows r*Td+last_row without an additional Gather-index port. Tied BF16 LM head then F32 Cast and stable TopK produce I32[R,1].",
            "Multirow prefill first views new target hidden[R,T,2048]. Slice/count uses the original last_row=T-1 on axis1; carry/prior are reshaped from[R,2048] to[R,1,2048]. Concat stays inside each request, followed by flatten to the shared packed draft dimension. Catch-up IDs use the same per-request axis1 concatenation before flatten."
        ],
        "R1_preservation": {
            "unchanged_functions": list(unchanged),
            "project_kv": "R1 Geometry enforces sequence_rows==packed_rows==projection.rows, so the old[1,rows,2,256] reshape, norm, RoPE and flat output nodes are retained.",
            "full_head": "R1 uses the original axis0 selected Slice+Copy and[1,1] TopK outputs, with the same BF16/F32 trained math. Shape checks add no Graph nodes.",
            "prefill": "R1 follows the original flat axis0 Slice/Concat path and skips batched reshape nodes. Same selected Geometry identities are passed to positions and project_kv.",
            "limit": "Source equivalence and shape argument only; no compiled graph comparison or runtime numerical/byte claim."
        },
        "caller_contract": [
            "Same exact role/lag and per-request T in one batch; every request has its own actual absolute positions, complete Snapshot, carry/prior and draft pages. T1 uses existing Single/CatchupSingle rather than zero-row previous-hidden Slice.",
            "For generation, main must join pending[R,1] and proposal[R,1] along axis1 then flatten, yielding[p0,d0,p1,d1,...]. Never directly concatenate two flat[R] vectors.",
            "All14 typed effects, original whole-Graph success/retirement and multi-head atomic publication remain main/StepState duties. This helper creates only ordinary mathematical nodes and original typed append nodes.",
            "Schema/plan includes R*max(targetT,draftTd), max_requestsR and complete per-member state alternatives; no padding or extra unsanctioned prefix write authority.",
            "B2 and R1 floating-point geometry need not give identical greedy/accept decisions. General cache recompute must preserve actual consumed token facts and already returned pending separately from fresh head predictions; no forcing old proposals."
        ],
        "checks": identity(HERE / "index-review.json"),
        "activity": {"product_files_changed": 1, "CXX_builds": 0, "GPU_runs": 0, "model_calculations": 0},
        "not_signed": "Main B2 integration, actual backend admission, MTP batch runtime/state isolation, restoration runtime, numerical threshold/quality or performance. Root controls related compilation and GPU checks."
    }
    write(HERE / "report.json", report)
    write(HERE / "source-freeze.json", {
        "status": "source-only single owned helper freeze",
        "files": [{"current": identity(source), "before": identity(before), "frozen": identity(frozen), "diff": identity(diff)}],
        "report": identity(HERE / "report.json"), "index_check": identity(HERE / "index-review.json"),
        "scripts": [identity(HERE / "check_indices.py"), identity(Path(__file__))],
        "builds": 0, "GPU_runs": 0,
    })
    print(json.dumps({"source": identity(source), "freeze": identity(HERE / "source-freeze.json")}))


if __name__ == "__main__":
    main()
