from pathlib import Path
import importlib.util
import json
import subprocess
import zipfile

W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('current_build',W / 'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
p=read(W / 'plan.json')


def stable(value):
    if isinstance(value,dict):return {k:stable(v) for k,v in value.items() if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value,list):return [stable(v) for v in value]
    return value


reports=[]
cases=[('host','attempt2'),('ordinary','attempt2'),('source-failure','attempt1'),('warm-cohort','attempt1'),
       ('boundaries','attempt2'),('mtp','attempt1'),('greedy-cuda','attempt1'),('request-cuda','attempt1')]
for name,attempt in cases:
    folder=W / 'runs' / name / attempt
    data=read(folder / 'report.json');process=read(folder / 'process.json')
    assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
    if name!='mtp':assert data['status']=='PASS'
    reports.append(dict(name=name,attempt=attempt,report=pin(folder / 'report.json'),process=process))
comparisons=[]
for name in ('greedy-cuda','request-cuda'):
    previous=R / '.scratch/inference-glm-math-boundary-20261030/runs' / name / 'attempt1/report.json'
    a=read(previous)['cases'][0]['properties']
    c=read(W / 'runs' / name / 'attempt1/report.json')['cases'][0]['properties']
    assert a==c
    comparisons.append(dict(name=name,properties=len(c),all_equal=True,previous=pin(previous)))
old_mtp=R / '.scratch/inference-cross-turn-warmth-20261030/runs/single/control/aa-mtp-6/report.json'
current=read(W / 'runs/mtp/attempt1/report.json')
assert stable(read(old_mtp))==stable(current)
guard=[]
reference=None
for name,attempt in [('mtp-control','guard1'),('mtp','guard2'),('mtp-control','guard3')]:
    path=W / 'runs' / name / attempt / 'report.json';data=read(path)
    if reference is None:reference=stable(data)
    assert stable(data)==reference
    guard.append(dict(arm='control' if name=='mtp-control' else 'candidate',report=pin(path),
        prefill=data['prefill_tokens_per_second'],decode=data['decode_output_tokens_per_second'],
        combined=data['output_tokens_per_second']))
failed=[]
for name,attempt,reason in [
    ('host','attempt1','Initial exception_ptr identity test was not portable on this MSVC runtime; corrected to compare the active rethrown original exception address and payload, retaining committed-record checks.'),
    ('ordinary','attempt1','The original fixture already contained generated stop-fixture output. Only manifests were copied into a fresh batch input; no product change.'),
    ('boundaries','attempt1','Old cold-tuple test expected permanent continuation disable after a temporary capture miss.'),
    ('boundaries-control','attempt1','The unchanged retained baseline probe fails the exact same stale permanent-disable assertion; product failure was not attributed to the new driver.')]:
    folder=W / 'runs' / name / attempt
    process=read(folder / 'process.json');assert process['exit']==1 and not process['timed_out']
    failed.append(dict(name=name,attempt=attempt,process=process,reason=reason))
source_files=['engine/inference/step_execution.h','engine/models/qwen35/main.cc',
    'tests/compute_models/glm_pro_mtp_state_consumer_test.cc','tests/tools/inference_step_execution_test.cc',
    'tests/tools/qwen_generation_batch_relay_probe.cc','tests/CMakeLists.txt']
receipts={}
for name in ('cli','relay','glm','host'):
    path=W / 'compile' / name / 'receipt.json';v=read(path)
    for item in [v['object'],*v['source_identities']]:exact(item)
    receipts[name]=dict(receipt=pin(path),object=v['object'])
for item in p['retained']:exact(item)
base=read(p['base']['path']);base['base']=p['base'];base['compile']=p['consumers']['cli']['compile']
link_command=read(W / 'link/cli/attempt1/command.json')
base['link']=link_command if isinstance(link_command,list) else link_command['command']
base.setdefault('current_consumers',{}).update(receipts)
base['current_consumers']['warm-cohort']=receipts['relay']
base['note']='Current shared-step consumers and same retained SDK ABI; no standalone performance candidates. Original legacy previous_consumer field is historical; use current_consumers receipts.'
save(W / 'model-link-base.json',base)
(W / 'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--',*source_files],cwd=R))
summary=dict(schema='hyle.common-step-driver.v1',date='2026-10-30',base_commit=p['base_commit'],status='FINITE_CHECKS_PASSED',
    implementation=[
        'drive_steps controls prepare/submit current, cancellation checkpoints, optional successor prepare/submit, current completion, refusal/discard/bind, deferred/synchronous successor completion and exception recovery.',
        'Qwen continuation adapter retains actual model mathematics, legality, Head/ledger publication, original Source pins, scratch and physical facts. No new executor, Completion, credit ledger or retirement owner.',
        'GLM ordinary preflight, actual model execution and explicit observation use the synchronous branch with no successor interface.',
        'Standalone six-group host control test registered with CMake when hyle_error exists; CMake offline error-only configuration and CTest discovery passed.'
    ],sources=[pin(R / x) for x in source_files],checks=reports,glm_non_timing_comparison=comparisons,
    real_qwen_mtp=dict(generated_tokens=64,all_non_timing_fields_equal=True,previous=pin(old_mtp),
        successor_submissions=current['overlap_successor_submissions'],publications=current['overlap_successor_publications'],
        discards=current['overlap_successor_discards']),
    obvious_regression_check=dict(order=guard,all_non_timing_fields_equal=True,
        conclusion='No obvious degradation in this adjacent control/candidate/control check; not a throughput improvement or cross-engine result. Earlier unpaired process is retained separately.'),
    corrected_checks=failed,cmake=read(W / 'cmake-registration.json'),
    build=dict(consumer_translation_units=4,consumer_compiler_processes=6,max_compiler_concurrency=2,SDK_CXX=0,NVCC=0,
        retained_sdk_inputs=227,missing_cached_dependency_records=len(p['missing_cached_dependencies']),
        missing_dependency_scope='Unchanged native-kernel objects and library inputs; changed engine CXX consumer dependencies were checked separately.',downloads=0),
    cleanup=read(W / 'cleanup-report.json'),
    limits=[
        'Qwen serial/packed/recursive preparation and publication paths still require common-drive migration; mathematical differences and request-record boundary remain under review.',
        'GLM uses real finite target77/NextN78 with explicit upstream/initial-state fixtures, not complete GLM prompt inference. Its shared step consumer is synchronous, not cross-pump.',
        'Source-failure native check validates the underlying original Source lifecycle, not every driver error branch. Host retirement reports are scripted, not device evidence.',
        'This batch did not run other model artifacts/platforms, full CPU+GPU, multi-GPU or multi-machine execution.',
        'The previous full llama.cpp comparison remains authoritative for its recorded version; no new complete performance or memory window.'
    ])
save(W / 'summary.json',summary)
dest=R / 'docs/evidence/correctness';dest.mkdir(parents=True,exist_ok=True)
save(dest / 'inference-common-step-driver-2026-10-30.json',summary)
archive=dest / 'inference-common-step-driver-2026-10-30.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as out:
    for name in ('build.py','finish.py','plan.json','summary.json','source-change.patch','original-continuation.cc',
            'cmake-registration.json','cleanup-targets.json','cleanup-report.json','cleanup.ps1'):
        out.write(W / name,name)
    for name in ('engine/inference/step_execution.h','tests/tools/inference_step_execution_test.cc'):
        out.write(R / name,'sources/'+name)
    for path in W.rglob('*'):
        if path.is_file() and (path.name in ('command.json','process.json','receipt.json','report.json','results.xml','image.json') or
            (path.name in ('stdout.log','stderr.log') and any(x in path.parts for x in ('runs','compile','configure','ctest-list')))):
            out.write(path,str(path.relative_to(W)))
print(json.dumps(dict(status=summary['status'],checks=len(reports),identical_glm_properties=107,archive_bytes=archive.stat().st_size)))
