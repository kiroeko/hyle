$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$batch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-common-step-driver-20261030'))
$bin = [IO.Path]::GetFullPath((Join-Path $batch 'bin'))
$inputs = [IO.Path]::GetFullPath((Join-Path $batch 'inputs'))
$manifest = Get-Content -LiteralPath (Join-Path $batch 'cleanup-targets.json') -Raw | ConvertFrom-Json
if ($manifest.workspace -cne $workspace -or $manifest.batch -cne $batch -or -not $batch.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected cleanup boundary' }
$targets = @($manifest.targets)
if ($targets.Count -ne 23) { throw 'Unexpected exact target count' }
$total = [long]0
foreach ($pin in $targets) {
  $target = [IO.Path]::GetFullPath($pin.path)
  $isImage = [IO.Path]::GetDirectoryName($target) -ceq $bin -and [IO.Path]::GetExtension($target).ToLowerInvariant() -in @('.exe','.dll','.lib','.exp')
  $isPayload = $target.StartsWith($inputs + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($target) -cin @('boundary-weights.bin','chain-weights.bin')
  if (-not $isImage -and -not $isPayload) { throw ('Target escaped exact recreatable image/payload scope: ' + $target) }
  $item = Get-Item -LiteralPath $target
  if ($item.PSIsContainer -or $item.Length -ne $pin.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pin.sha256) { throw ('Changed target: ' + $target) }
  $total += $item.Length
}
foreach ($pin in $targets) { Remove-Item -LiteralPath $pin.path -Force }
$report = @{status='REMOVED_EXACT_RECREATABLE_IMAGES_AND_SYNTHETIC_PAYLOADS';files=$targets.Count;bytes=$total;boundary=$batch;retained='SDK and current consumer objects, original cached weights, source and fixture metadata, commands, failed attempts and reports'}
$report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $batch 'cleanup-report.json') -Encoding utf8
$report | ConvertTo-Json
