"""Compile only changed consumers; bounded shared-step checks with cached SDK."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('cached', R / '.scratch/inference-source-binding-20261030/build.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
s.W = s.b.W = W
read, save, pin, exact, key = s.read, s.save, s.pin, s.exact, s.key
BASE = R / '.scratch/inference-glm-math-boundary-20261030/model-link-base.json'


def prepare():
    assert not (W / 'plan.json').exists()
    base = read(BASE)
    for item in [*base['retained'], base['runtime']]: exact(item)
    prior = read(R / '.scratch/inference-glm-math-boundary-20261030/plan.json')
    cli = read(base['current_consumers']['cli']['receipt']['path'])
    changed = {key(R / x) for x in subprocess.check_output(
        ['git', 'diff', '--name-only', '--', 'include', 'src', 'engine'], cwd=R, text=True).splitlines()}
    sdk = read(base['sdk_engine_dependencies']['path'])
    rows = {key(x['object']): x for x in [*sdk['inspected'], *sdk['engine_consumers']] if 'dependencies' in x}
    affected, missing = [], []
    for item in base['retained']:
        obj = Path(item['path'])
        adjacent = [obj.parent / 'dependencies.json', obj.parent / (obj.stem + '-deps.json'), obj.with_suffix('.deps.json')]
        row = rows.get(key(obj))
        for candidate in adjacent:
            if candidate.is_file() and 'Data' in read(candidate):
                row = dict(dependencies=pin(candidate)); break
        if row is None:
            missing.append(str(obj)); continue
        data = read(row['dependencies']['path'])['Data']
        if any(key(x) in changed for x in [data['Source'], *data['Includes']]): affected.append(data['Source'])
    assert not affected, affected
    wrapper = W / 'cli.cc'
    wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
    sources = {'cli': wrapper, 'relay': R / 'tests/tools/qwen_generation_batch_relay_probe.cc',
        'host': R / 'tests/tools/inference_step_execution_test.cc'}
    consumers = {name: dict(source=str(source), compile=s.relocated(base['compile'], name, source)) for name, source in sources.items()}
    consumers['glm'] = dict(prior['consumers']['glm'], compile=s.relocated(prior['consumers']['glm']['compile'], 'glm'))
    history = read(R / '.scratch/inference-cross-turn-warmth-20261030/plan.json')
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    save(W / 'plan.json', dict(base=pin(BASE), base_commit='0c2872914', retained=base['retained'], runtime=base['runtime'],
        original_link=base['link'], original_consumer=cli['object']['path'], units={}, consumers=consumers,
        environment=prior['environment'], glm_cases=prior['cases'], sdk=base['sdk_engine_dependencies'],
        SDK_CXX=0, NVCC=0, downloads=0, max_compilers=2, missing_cached_dependencies=missing,
        args=history['args'], sdk_affected_sources=affected,
        fixture=str(R / '.scratch/inference-continuous-wave-20261027/inputs/context32'),
        source_failure_fixture=str(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input')))
    print('Prepared4 consumers;227 SDK objects retained, affected SDK CXX0; missing dependency records', len(missing), flush=True)


def compile_group(attempt, names):
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs = [pool.submit(s.compile_one, name, attempt) for name in names]
        for job in jobs: job.result()


def link(name, attempt):
    p = read(W / 'plan.json')
    if name in ('control','relay-control'):
        base=read(p['base']['path'])
        receipt=read(base['current_consumers']['cli' if name=='control' else 'warm-cohort']['receipt']['path'])
        for item in [receipt['object'], *p['retained']]: exact(item)
    else:
        receipt = read(W / 'compile' / name / 'receipt.json')
        for item in [receipt['object'], *receipt['source_identities'], *p['retained']]: exact(item)
    args = []
    replaced = 0
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']): arg=receipt['object']['path']; replaced += 1
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg=prefix+str((W / 'bin' / name).with_suffix(suffix)); break
        args.append(arg)
    assert replaced == 1
    if name == 'glm': args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / v) for v in ('gtest_main.lib', 'gtest.lib'))
    s.b.execute(args, W / 'link' / name / attempt, 240)
    save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))


def run(name, attempt):
    p = read(W / 'plan.json')
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    folder = W / 'runs' / name / attempt
    if name.endswith('-cuda') and name in p['glm_cases']:
        os.environ.update(p['environment'])
        os.environ.update(HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0', HYLE_GLM_MLX_WAIT_FOR_EXPERTS='0', HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS='0')
        image=read(W / 'ready-glm.json'); args=['--gtest_color=no','--gtest_fail_fast',
            '--gtest_filter='+p['glm_cases'][name]['filter'],'--gtest_output=xml:'+str(folder / 'results.xml')]
    else:
        if name == 'host': consumer, args='host', []
        elif name == 'ordinary':
            fixture=W / 'inputs' / name / attempt
            fixture.mkdir(parents=True,exist_ok=True)
            for entry in ('weights.tsv','prompt.ids'): shutil.copyfile(Path(p['fixture']) / entry,fixture / entry)
            consumer, args='relay', ['--cuda-continuous',str(fixture)]
        elif name == 'source-failure': consumer, args='relay', ['--cuda-source-failure',p['source_failure_fixture']]
        elif name == 'warm-cohort': consumer, args='relay', ['--warm-cohort',p['fixture']]
        elif name in ('boundaries','boundaries-control'):
            consumer, args=('relay-control' if name=='boundaries-control' else 'relay'), ['--cuda-boundaries',p['fixture'],str(W / 'inputs' / name / attempt)]
        elif name in ('mtp','mtp-control'): consumer, args=('control' if name=='mtp-control' else 'cli'), list(p['args'])
        else: raise ValueError(name)
        image=read(W / ('ready-'+consumer+'.json'))
    exact(image); save(folder / 'image.json',image)
    s.b.execute([image['path'],*args],folder,600)
    if name in p['glm_cases']:
        xml=ET.parse(folder / 'results.xml').getroot()
        assert xml.get('tests')=='1' and xml.get('failures')==xml.get('errors','0')=='0' and not xml.findall('.//skipped')
        result=dict(status='PASS', tests=1, skipped=0, cases=[dict(name=x.get('classname')+'.'+x.get('name'),
            properties={y.get('name'):y.get('value') for y in x.findall('./properties/property')}) for x in xml.findall('.//testcase')])
    else:
        result=read(folder / 'stdout.log')
        if name in ('mtp','mtp-control'): assert result['generated_tokens']==64 and result['live_committed_versions']==0
        else: assert result['status']=='PASS'
        if name == 'host': assert result['groups']==6 and not result['device_execution']
    save(folder / 'report.json',result)
    print('PASS',name,flush=True)


def configure(attempt):
    p=read(W / 'plan.json')
    command=['C:/Program Files/CMake/bin/cmake.exe','-S',str(R),'-B',str(W / 'cmake-host'),'-G','Ninja',
        '-DCMAKE_MAKE_PROGRAM=C:/Program Files/Python312/Scripts/ninja.exe',
        '-DCMAKE_CXX_COMPILER='+p['consumers']['cli']['compile'][0], '-DCMAKE_BUILD_TYPE=Release',
        '-DHYLE_COMPONENTS=error','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF',
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON']
    s.b.execute(command,W / 'configure' / attempt,120)
    s.b.execute(['C:/Program Files/CMake/bin/ctest.exe','--test-dir',str(W / 'cmake-host'),
        '--show-only=json-v1','-R','^hyle_inference_step_execution_test$'], W / 'ctest-list' / attempt,30)
    result=read(W / 'ctest-list' / attempt / 'stdout.log')
    assert [x['name'] for x in result['tests']]==['hyle_inference_step_execution_test']
    save(W / 'cmake-registration.json',dict(status='REGISTERED_ONLY', test=result['tests'][0]['name'],
        component='error',offline=True,build_performed=False))
    print('PASS CMake target registration; existing native host binary separately checked.',flush=True)


if __name__ == '__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':compile_group(sys.argv[2],sys.argv[3:])
    elif action=='link':link(sys.argv[2],sys.argv[3])
    elif action=='run':run(sys.argv[2],sys.argv[3])
    elif action=='configure':configure(sys.argv[2])
    else:raise ValueError(action)
