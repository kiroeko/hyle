"""Root-only: refresh one tensor host owner and retain the actual MMVQ tail object.

No acquisition, native compilation or consumer compilation. The prior tensor
record is a historical command recipe; only its freshly compiled replacement
may be advertised as current after the parity-removal patch.
"""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
R = S.parents[2]
import json
F = json.loads((S / 'inputs.json').read_text(encoding='utf-8'))
path = Path(F['previous_helper']['path'])
import hashlib
assert hashlib.sha256(path.read_bytes()).hexdigest() == F['previous_helper']['sha256']
spec = importlib.util.spec_from_file_location('_parity_current_previous', path)
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
base = previous.base
read, save, identity, require, resolve = base.read, base.save, base.identity, base.require, base.resolve
SOURCE = R / 'src/compute_provider_ggml_cuda/tensor_program.cc'


def native_tail():
    info = read(require(F['tail_link_input'])['path'])
    for key in ('object', 'record', 'dependencies', 'replace_exactly'):
        require(info[key])
    record = read(info['record']['path'])
    for key in ('source', 'object', 'dependencies_file', 'recipe', 'process'):
        require(record[key])
    process = read(record['process']['path'])
    if process['exit'] != 0 or process['timed_out'] or process['command'] != record['command']:
        raise ValueError('MMVQ object must have its actual successful native compile')
    deps = read(info['dependencies']['path'])
    require(deps['depfile'])
    for row in deps['local']:
        require(row)
    if info['object'] != record['object'] or info['replace_exactly'] != record['retired_object']:
        raise ValueError('MMVQ replacement differs from its owning native record')
    return info


def inputs(after):
    require(F['previous_helper'])
    for key in ('prior_ready', 'prior_plan', 'prior_hosts', 'prior_runtime', 'retired_record', 'consumer_record', 'parity_patch'):
        require(F[key])
    wanted = F['source_after'] if after else F['source_before']
    actual = identity(SOURCE)
    if any(actual[key] != wanted[key] for key in ('bytes', 'sha256')):
        raise ValueError('Expected exact parity-removal source ' + ('after' if after else 'before'))
    ready = read(F['prior_ready']['path'])
    for key in ('image', 'link_plan', 'runtime_environment', 'host_records', 'consumer_record', 'link_result'):
        require(ready[key])
    plan = read(F['prior_plan']['path'])
    process = read(ready['link_result']['path'])
    if process['exit'] != 0 or process['command'] != plan['command']:
        raise ValueError('Prior current image must have its actual successful link')
    host = read(F['prior_hosts']['path'])
    paths = [resolve(row['path']) for row in host['records']]
    retired = resolve(F['retired_record']['path'])
    if host['count'] != 131 or len(paths) != 131 or len(set(paths)) != 131 or paths.count(retired) != 1:
        raise ValueError('Expected exact131-host collection with one retired tensor record')
    for row in host['records']:
        require(row)
        if resolve(row['path']) != retired:
            base.check_record(resolve(row['path']))
    old = read(retired)
    require(old['object'])
    if resolve(old['source']['path']) != SOURCE or ready['consumer_record'] != F['consumer_record']:
        raise ValueError('Wrong historical tensor record or retained consumer')
    previous.consumer()
    require(plan['native_inputs'])
    for row in base.native_inputs():
        if sum(x.lower().endswith('.obj') and resolve(x) == resolve(row['object']['path']) for x in plan['command']) != 1:
            raise ValueError('Original native2 object must remain exactly once')
    for row in plan['retained_inputs']:
        require(row)
    for row in read(F['prior_runtime']['path'])['staged_dlls']:
        require(row)
    return plan, paths, retired, old, native_tail()


def compile_host(attempt):
    inputs(True)
    h = base.helpers()
    h.S = S
    h.RECIPES = {'tensor-program': resolve(F['retired_record']['path'])}
    h.SOURCES = {'tensor-program': SOURCE}
    h.compile_one('tensor-program', attempt)
    base.check_record(S / f'compile{attempt}/tensor-program/identity.json')


def link(attempt):
    original, paths, retired, old, tail = inputs(True)
    fresh_path = S / f'compile{attempt}/tensor-program/identity.json'
    fresh = base.check_record(fresh_path)
    replacements = {resolve(old['object']['path']): fresh['object'], resolve(tail['replace_exactly']['path']): tail['object']}
    counts = dict.fromkeys(replacements, 0)
    command = []
    for arg in original['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        key = resolve(arg) if arg.lower().endswith('.obj') else None
        if key in replacements:
            counts[key] += 1
            arg = replacements[key]['path']
        command.append(arg)
    retained = [tail['object'] if resolve(row['path']) == resolve(tail['replace_exactly']['path']) else row for row in original['retained_inputs']]
    if set(counts.values()) != {1} or sum(resolve(row['path']) == resolve(tail['object']['path']) for row in retained) != 1:
        raise ValueError('Replace exactly one tensor object and one retained MMVQ object')
    paths = [fresh_path if path == retired else path for path in paths]
    objects = [resolve(arg) for arg in command if arg.lower().endswith('.obj')]
    known = {resolve(read(path)['object']['path']) for path in paths}
    known |= {resolve(previous.consumer()['object']['path']), *(resolve(row['object']['path']) for row in base.native_inputs())}
    known |= {resolve(row['path']) for row in retained}
    if not set(objects) <= known or any(key in objects for key in replacements) or objects.count(resolve(tail['object']['path'])) != 1:
        raise ValueError('Unaccounted or retired object remains in new link command')
    out = S / f'current-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'hyle-current-flash.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    save(out / 'host-records.json', dict(records=[identity(path) for path in paths], count=131,
        current_source_dependencies_checked=True, retired=[F['retired_record']], fresh=[identity(fresh_path)]))
    save(out / 'link-plan.json', dict(command=command, base=F['prior_plan'], consumer_record=F['consumer_record'],
        host_records=identity(out / 'host-records.json'), retained_inputs=retained, native_inputs=original['native_inputs'],
        tail_native_input=F['tail_link_input'], replaced_objects=[str(path) for path in replacements],
        current_host_count=131, pending_consumer=False, parity_patch=F['parity_patch'],
        SDK_builds=0, NVCC_builds=0, rebuilt_product_host_TUs=1, new_consumer_TUs=0))
    h = base.helpers()
    env, _ = h.b.environment(command, [], out)
    h.c.execute('link', command, env, out)
    runtime = read(F['prior_runtime']['path'])
    for row in runtime['staged_dlls']:
        os.link(resolve(row['path']), out / resolve(row['path']).name)
    runtime['PATH'] = runtime['PATH'].replace(str(resolve(F['prior_runtime']['path']).parent), str(out))
    runtime.update(previous=F['prior_runtime'], staged_dlls=[identity(path) for path in out.glob('*.dll')],
        host_translation_units=1, consumer_translation_units=0, full_SDK_builds=0, NVCC_builds=0)
    runtime['matched_HC_PRE_worker'] = runtime['staged_dlls'][0]
    save(out / 'runtime-environment.json', runtime)
    save(out / 'ready.json', dict(image=identity(image), link_plan=identity(out / 'link-plan.json'),
        runtime_environment=identity(out / 'runtime-environment.json'), host_records=identity(out / 'host-records.json'),
        consumer_record=F['consumer_record'], link_result=identity(out / 'link.result.json'), native_result=False,
        Orin_native_verified=False))
    print('PUBLISHED CURRENT', out)


def closure(attempt=1):
    """The existing five-tuple contract for a later single-consumer overlay."""
    out = S / f'current-link{attempt}'
    ready = read(out / 'ready.json')
    for key in ('image', 'link_plan', 'runtime_environment', 'host_records', 'consumer_record', 'link_result'):
        require(ready[key])
    plan = read(out / 'link-plan.json')
    process = read(out / 'link.result.json')
    if process['exit'] != 0 or process['command'] != plan['command']:
        raise ValueError('Current image link failed or its command changed')
    require(plan['parity_patch'])
    require(plan['native_inputs'])
    base.native_inputs()
    require(plan['tail_native_input'])
    native_tail()
    for row in plan['retained_inputs']:
        require(row)
    for row in read(out / 'runtime-environment.json')['staged_dlls']:
        require(row)
    host = read(out / 'host-records.json')
    paths = [resolve(row['path']) for row in host['records']]
    if host['count'] != 131 or len(paths) != 131 or len(set(paths)) != 131:
        raise ValueError('Current host collection must have131 distinct actual records')
    for row in host['records']:
        require(row)
        base.check_record(resolve(row['path']))
    consumer = base.check_record(resolve(ready['consumer_record']['path']))
    return plan, ready, out / 'runtime-environment.json', consumer, paths


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('compile', 'link'))
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    if args.attempt <= 0:
        raise ValueError('Positive attempt required')
    {'compile': compile_host, 'link': link}[args.action](args.attempt)
