"""Narrow six-case integration of the current packed admission and MMVQ tail fix."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
P = S.parent
SOURCE = R / 'tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc'
TAIL_SOURCE = R / 'tests/compute_provider_ggml_cuda/packed_matmul_tail_test.cc'
TAIL_RECORD = P / 'tail-read-proposal/test1/identity.json'
NATIVE_RECORD = P / 'tail-read-proposal/native1/identity.json'
TENSOR_RECORD = P / 'parity-current-integration/compile1/tensor-program/identity.json'
OLD_PROOF = R / 'docs/evidence/correctness/mtp-packed-mmvq-tail-read-2026-10-24.json'
OLD_ZIP = OLD_PROOF.with_suffix('.zip')
EXPECTED = {
    ('GgmlCudaPackedBounds', 'FullVocabularySmallBatchPreparesWithoutWeightStorage'),
    ('GgmlCudaPackedBounds', 'LargeHeadsDeclineFallbackAndPaddedLayouts'),
    ('GgmlCudaPackedBounds', 'EncodedAndLogicalLimitsKeepOtherPortsBounded'),
    ('GgmlCudaPackedTail', 'Q8K512N1M1'),
    ('GgmlCudaPackedTail', 'Q8K512N3M1'),
    ('GgmlCudaPackedTail', 'Q8K512N3M2'),
}


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def verify(info):
    assert identity(info['path']) == info, info['path']


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def protected():
    assert identity(OLD_PROOF)['sha256'] == '06c075f0ca65020854d1997bdda7b95660bb8cc923e4626160dc7a95165cd7fa'
    assert identity(OLD_ZIP)['sha256'] == 'ab3e0710e9689d25cff6b35ae6681e68d8bed1a9dbb1abf0a7f52a3a80ff4e08'
    return [identity(OLD_PROOF), identity(OLD_ZIP)]


h = module('packed_parity_host_env', R / '.scratch/native-paged-effects-20261022/build_windows.py')
q = module('packed_parity_execute', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')


def compile_test():
    recipe = P / 'tail-read-proposal/test1/identity.json'
    old = read(recipe)
    assert identity(TAIL_SOURCE)['sha256'] == old['source']['sha256']
    for info in (old['source'], old['object'], *old['dependencies']):
        verify(info)
    out = S / 'compile1/bounds-test'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command = []
    for arg in old['command']:
        if arg == old['source']['path']:
            arg = str(SOURCE)
        elif arg.startswith('/Fo'):
            arg = '/Fo' + str(out / 'bounds-test.obj')
        elif arg.startswith('/Fd'):
            arg = '/Fd' + str(out / 'bounds-test.pdb')
        command.append(arg)
    command[command.index('/sourceDependencies') + 1] = str(out / 'source-deps.json')
    save(out / 'plan.json', dict(command=command, source=identity(SOURCE), recipe=identity(recipe),
         reused_tail_record=identity(TAIL_RECORD), old_proof=protected()))
    env, _ = h.b.environment(command, [], out)
    env.update(TEMP=str(out / 'tmp'), TMP=str(out / 'tmp'))
    process = q.execute(command, env, out / 'run', timeout=1800)
    assert process['exit'] == 0 and not process['timed_out'], process
    deps = read(out / 'source-deps.json')['Data']
    dependencies = [identity(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])]
    save(out / 'identity.json', dict(command=command, source=identity(SOURCE), object=identity(out / 'bounds-test.obj'),
         dependencies=dependencies, recipe=identity(recipe), process=process))
    print('PASS: one canonical bounds-test TU compiled; tail test object reused', flush=True)


def link():
    current = module('packed_parity_current', P / 'parity-current-integration/build.py')
    original, ready, runtime_path, consumer, host_paths = current.closure(1)
    bounds = read(S / 'compile1/bounds-test/identity.json')
    tail, native, tensor = (read(path) for path in (TAIL_RECORD, NATIVE_RECORD, TENSOR_RECORD))
    assert identity(TAIL_SOURCE)['sha256'] == tail['source']['sha256']
    for record in (bounds, tail):
        for info in (record['source'], record['object'], *record['dependencies']):
            verify(info)
    for info in (native['source'], native['object'], tensor['source'], tensor['object']):
        verify(info)
    assert native['object']['sha256'] == '602b4938b5a2d5cb2bbaa67f156d35ecc3d8fc6c41a6dffce591d5c322363cf4'
    assert tensor['source']['sha256'] == '1acd1421bc179e10d7d31f9f87a530316de58dc10479c7e887b64ac1bf883825'
    out = S / 'tests-link1'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'packed-parity-tail-checks.exe'
    command = []
    replaced = 0
    for arg in original['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        if arg.casefold() == consumer['object']['path'].casefold():
            replaced += 1
            command += [bounds['object']['path'], tail['object']['path']]
        else:
            command.append(arg)
    assert replaced == 1
    for info in (native['object'], tensor['object'], bounds['object'], tail['object']):
        assert sum(arg.casefold() == info['path'].casefold() for arg in command) == 1, info
    assert not any(arg.casefold() == consumer['object']['path'].casefold() for arg in command)
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    if not any(arg.upper().startswith('/SUBSYSTEM:') for arg in command):
        command += ['/SUBSYSTEM:CONSOLE']
    save(out / 'link-plan.json', dict(command=command, base=ready, removed_consumer=consumer['object'],
         test_records=[identity(S / 'compile1/bounds-test/identity.json'), identity(TAIL_RECORD)],
         tensor_record=identity(TENSOR_RECORD), tensor_object=tensor['object'], native_record=identity(NATIVE_RECORD),
         native_object=native['object'], host_records=[identity(path) for path in host_paths],
         tensor_occurrences=1, mmvq_occurrences=1, new_test_TUs=1, reused_test_TUs=1,
         product_host_TUs=0, NVCC_commands=0, SDK_builds=0, old_proof=protected()))
    env, _ = h.b.environment(command, [], out)
    env.update(TEMP=str(out / 'tmp'), TMP=str(out / 'tmp'))
    process = q.execute(command, env, out / 'link', timeout=1800)
    assert process['exit'] == 0 and not process['timed_out'], process
    runtime = read(runtime_path)
    for info in runtime['staged_dlls']:
        verify(info)
        dll = Path(info['path'])
        os.link(dll, out / dll.name)
    runtime['PATH'] = str(out) + os.pathsep + runtime['PATH']
    runtime['staged_dlls'] = [identity(path) for path in out.glob('*.dll')]
    runtime['previous'] = identity(runtime_path)
    save(out / 'runtime-environment.json', runtime)
    save(out / 'ready.json', dict(image=identity(image), link_plan=identity(out / 'link-plan.json'),
         runtime=identity(out / 'runtime-environment.json'), process=process))
    print('PASS: focused image linked with current tensor and tail-native objects exactly once', flush=True)


def run():
    out = S / 'checks1'
    out.mkdir(exist_ok=False)
    ready = read(S / 'tests-link1/ready.json')
    for key in ('image', 'link_plan', 'runtime'):
        verify(ready[key])
    runtime = read(ready['runtime']['path'])
    for info in runtime['staged_dlls']:
        verify(info)
    env = os.environ.copy()
    env['PATH'] = runtime['PATH']
    command = [ready['image']['path'], '--gtest_filter=GgmlCudaPackedBounds.*:GgmlCudaPackedTail.*',
               '--gtest_output=xml:' + str(out / 'results.xml')]
    save(out / 'plan.json', dict(command=command, image=ready['image'], runtime=ready['runtime'], expected=sorted(EXPECTED),
         scope='Descriptor bounds plus generated small-Q8 numeric regression; no memory-access instrumentation.'))
    process = q.execute(command, env, out / 'run', timeout=180)
    root = ET.parse(out / 'results.xml').getroot() if (out / 'results.xml').exists() else None
    cases = list(root.iter('testcase')) if root is not None else []
    observed = {(case.attrib['classname'], case.attrib['name']) for case in cases}
    passed = process['exit'] == 0 and not process['timed_out'] and len(cases) == 6 and observed == EXPECTED and not any(
        case.find('failure') is not None or case.find('skipped') is not None or case.attrib.get('status') != 'run'
        for case in cases)
    save(out / 'summary.json', dict(passed=passed, process=process, cases=len(cases), expected=sorted(EXPECTED),
         xml=identity(out / 'results.xml') if root is not None else None, image=ready['image'],
         descriptor_cases=3, numeric_cases=3, memcheck=False, model_inference=False,
         numeric_reference='Exact Q8 scale1/code(row+1) times AQ8_1 scale1/codes +/-127: +/-65024*(row+1)',
         new_test_TUs=1, reused_test_TUs=1, product_host_TUs=0, NVCC_commands=0, SDK_builds=0,
         protected_previous_evidence=protected()))
    assert passed, process
    print('PASS: exact six cases, zero failure/skip; numeric scope only', flush=True)


def finish():
    summary = read(S / 'checks1/summary.json')
    assert summary['passed'] and summary['cases'] == 6
    plan = read(S / 'tests-link1/link-plan.json')
    link_map = S / 'tests-link1/packed-parity-tail-checks.map'
    symbols = [line for line in link_map.read_text().splitlines()
               if 'ggml_cuda_mul_mat_vec_q' in line or 'ggml_cuda_should_use_mmvq' in line]
    assert symbols and all('mmvq.obj' in line for line in symbols)
    (S / 'link-map-excerpt.txt').write_text('\n'.join(symbols) + '\n', encoding='utf-8', newline='\n')
    proof = R / 'docs/evidence/correctness/mtp-packed-mmvq-tail-integration-2026-10-24.json'
    archive = proof.with_suffix('.zip')
    assert not proof.exists() and not archive.exists()
    files = [Path(__file__), S / 'link-map-excerpt.txt', SOURCE, TAIL_SOURCE, R / 'src/compute_provider_ggml_cuda/tensor_program.cc',
             R / 'third_party/ggml_cuda_runtime/LICENSE',
             R / 'third_party/ggml_cuda_runtime/patches.json', R / 'cmake/HyleDependencyLock.json',
             P / 'tail-read-proposal/generated/src/ggml-cuda/mmvq.cu',
             P / 'tail-read-proposal/native.diff', P / 'tail-read-proposal/source.patch',
             P / 'parity-removal-proposal/source.patch', P / 'parity-current-integration/build.py',
             P / 'parity-current-integration/inputs.json', TAIL_RECORD, NATIVE_RECORD, TENSOR_RECORD,
             P / 'tail-read-proposal/native1/dependencies.json',
             P / 'parity-current-integration/current-link1/ready.json',
             P / 'parity-current-integration/current-link1/link-plan.json',
             P / 'parity-current-integration/current-link1/link.result.json',
             P / 'parity-current-integration/current-link1/host-records.json']
    for directory in (S / 'compile1', S / 'tests-link1', S / 'checks1'):
        files += [path for path in directory.rglob('*') if path.is_file() and path.suffix.lower() in ('.json', '.log', '.xml')]
    files = sorted(set(files))
    assert all(path.is_file() for path in files)
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for path in files:
            assert path.stat().st_size < 10_000_000 and (path.name == 'LICENSE' or path.suffix.lower() in ('.py', '.cc', '.cu', '.json', '.diff', '.patch', '.log', '.xml', '.txt'))
            target.write(path, path.relative_to(R).as_posix())
    value = dict(schema='hyle-focused-correctness-v1', date='2026-10-24', status='passed',
        scope='Three CUDA packed descriptor-bound cases and three generated Q8 K512 numeric tail cases on the current tensor/MMVQ closure.',
        tests=dict(total=6, passed=6, failed=0, skipped=0, descriptor=3, numeric=3),
        hardware=dict(device='NVIDIA GeForce RTX 4070', compute_capability='8.9',
                      source=identity(S / 'checks1/run/stderr.log')),
        cases=summary['expected'], xml=summary['xml'], process=summary['process'], image=summary['image'],
        tensor_record=plan['tensor_record'], tensor_object=plan['tensor_object'],
        mmvq_record=plan['native_record'], mmvq_object=plan['native_object'],
        link_occurrences=dict(tensor=1, mmvq=1), compile=dict(new_test_TUs=1, reused_test_TUs=1, product_host_TUs=0, NVCC_commands=0, SDK_builds=0),
        current_image=plan['base'], link_plan=identity(S / 'tests-link1/link-plan.json'),
        runtime=identity(S / 'tests-link1/runtime-environment.json'),
        link_map=dict(full=identity(link_map), excerpt=identity(S / 'link-map-excerpt.txt')),
        numeric_reference=summary['numeric_reference'],
        limitations=['No memcheck or sanitizer was run.', 'Descriptor tests allocate no full weight storage.',
                     'Generated numeric matrices cover K512 N1/M1 and N3/M1,M2; this is not an original-model or throughput result.',
                     'Execution is on the recorded local CUDA device; Orin remains source-only.'],
        protected_previous_evidence=protected(), files=[identity(path) for path in files], archive=identity(archive))
    save(proof, value)
    protected()
    save(S / 'finished.json', dict(proof=identity(proof), archive=identity(archive)))
    print(json.dumps(read(S / 'finished.json'), indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('compile', 'link', 'run', 'finish'))
    args = parser.parse_args()
    {'compile': compile_test, 'link': link, 'run': run, 'finish': finish}[args.action]()
