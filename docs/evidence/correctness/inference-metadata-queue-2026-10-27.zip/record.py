from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R / 'docs/evidence/correctness'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

summary = read(W/'summary.json')
ready = read(W/'ready.json')
old = read(R/'.scratch/inference-relay-carriers-20261027/attempt2/summary.json')
assert summary['status'] == 'PASS' and len(summary['results']) == 5
assert len(summary['results'][0]['tests']) == 43
old_ids = {row['name']:row['generated_ids'] for row in old['results'][1:]}
new_ids = {row['name']:row['generated_ids'] for row in summary['results'][1:]}
assert old_ids == new_ids
files = []
allowed = {'.py', '.json', '.xml', '.log', '.cc', '.h'}
for p in W.rglob('*'):
    if p.is_file() and p.suffix in allowed:
        files.append(p)
bundle = D/'inference-metadata-queue-2026-10-27.zip'
assert not bundle.exists()
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files): z.write(p, p.relative_to(W).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None and len(z.namelist()) == len(files)
    for p in files: assert z.read(p.relative_to(W).as_posix()) == p.read_bytes()
report = dict(status='PASS', date='2026-10-27',
    scope='One original Graph metadata transfer Queue per actual Context/lane. Real upload wait/ready publication; no new executor or pending-control protocol.',
    changes=['Original ResourceEpisode caches stable shared Queue wrappers across configuration reset, derived from exact plan lane ExecutionSource.',
        'Batch metadata F2 uses only the metadata Queue; BatchBuffers retains its borrowed wrapper along original buffer domains.',
        'PagedAppend MirrorGroup and slots IDs reference the same owner. All native execution, Source, proof and capture Queue identities are unchanged.',
        'Host uploads still wait for their actual copy retirement before publishing initialized controls. Same-ID optimization remains unchanged.'],
    counts=summary['counts'], results=summary['results'], images=ready['artifacts'],
    proofs=['FreshMetadata test sees one cached owner, a different actual CUDA stream, and rejects a foreign lane.',
        'An actual compute-stream callback gate remains unreleased while changed page-ID metadata preparation returns; original capture is reused and results remain exact.',
        'New GDN relay swaps the two actual destination writers, forcing a real changed-ID upload while the original producer is still pending; Source remains device-wait once, capture is reused, state/output/padding match original dense results.',
        'All original 38 pending/source/slots checks, two new Queue checks, and three capacity/readback checks pass in one final process.',
        'Four CPU/CUDA ordinary/MTP-K3 B2 journeys retain identical generated IDs to the previous successful carrier batch and end with two retired requests and no committed versions.'],
    prior_tiny_ids_match=True, prior_summary=pin(R/'.scratch/inference-relay-carriers-20261027/attempt2/summary.json'),
    source_snapshots=read(W/'frozen-plan.json')['snapshots'],
    failures=[], limitations=['Only CUDA Queue isolation is newly gated. CPU tiny/direct paths run, but no new Apple/Vulkan/Linux run.',
        'No full model overlap/scheduling or new throughput measurement. Current engine remains single-slot.',
        'Metadata preparation still waits for the small upload. Ordinary Tensor.write is host-synchronous and has not been replaced.',
        'Backend Queue internal allocations obey the existing Context allocator contract, distinct from the explicitly budgeted shared owner control block.',
        'MTP noncontiguous accepted subsets and complete model ordered successor publication remain open.'],
    evidence=dict(bundle=pin(bundle), members=len(files)))
target = D/'inference-metadata-queue-2026-10-27.json'
assert not target.exists()
target.write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(report=pin(target), bundle=pin(bundle), members=len(files))))
