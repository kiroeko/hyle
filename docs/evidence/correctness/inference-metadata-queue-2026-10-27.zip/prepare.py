"""Prepare seven exact CXX recipes and two links; no freeze/build/run."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-relay-carriers-20261027/attempt2'
spec = importlib.util.spec_from_file_location('metadata_queue_recipe_helpers', B.parent / 'prepare.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
q.W = W  # Reuse its path guard for this batch's new OUT/PDB/IMPLIB roots.
read, save, pin, key = q.read, q.save, q.pin, q.key
SOURCES = ['src/compute_batch/batch_execution.cc', 'src/graph/resources.cc',
           'src/graph/slots_region.cc', 'src/graph_batch/batch.cc',
           'src/graph_batch/paged_append.cc',
           'tests/graph_provider_ggml_cuda/pending_indexed_state_test.cc',
           'tests/graph_batch/batch_capture_test.cc']
HEADERS = ['include/hyle/compute/detail/batch_graph_access.h',
           'include/hyle/graph/detail/region_access.h', 'src/graph_batch/paged_append.h']


def command(template, source, out):
    result = []
    for i, arg in enumerate(template):
        if i and template[i - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        elif arg.lower().endswith(('.cc', '.cpp', '.cxx')):
            arg = str(R / source)
        result.append(arg)
    assert '/O2' in result and '/MD' in result and '/DHYLE_STATIC' in result
    assert q.build_contract(template) == q.build_contract(result)
    return result


def main():
    assert not (W / 'plan.json').exists(), 'Keep prepared attempts distinct'
    cli, test = read(B / 'cli-link-inputs.json'), read(B / 'test-link-inputs.json')
    assert len(cli) == 224 and len(test) == 236
    ci, ti = q.index(cli), q.index(test)
    for source in SOURCES[:5]:
        assert ci[key(R / source)]['object'] == ti[key(R / source)]['object'], source
    units = []
    replacement = {}
    pending = ti[key(R / SOURCES[5])]
    for index, source in enumerate(SOURCES):
        old = ti.get(key(R / source))
        template = old or pending
        recipe, argv = q.recipe(template)
        name = f'{index:02d}-' + Path(source).stem
        out = W / 'compile' / name
        target = W / 'recipes' / (name + '.json')
        save(target, dict(command=command(argv, source, out), cwd=str(R), timeout_seconds=180))
        unit = dict(name=name, source=str(R / source), source_frozen=False,
                    command=pin(target), baseline_recipe=pin(recipe),
                    baseline_dependencies=template['dependencies'],
                    baseline_object=old['object'] if old else None,
                    object=str(out / 'unit.obj'),
                    compiled_contract=q.build_contract(argv),
                    action='replace' if old else 'add')
        units.append(unit)
        if old:
            replacement[key(old['object']['path'])] = unit['object']
    assert len(replacement) == 6 and len(units) == 7
    for label, rows, count in [('cli', cli, 224), ('test', test, 237)]:
        keys = {key(row['path']) for row in rows}
        actual_replacements = {path: obj for path, obj in replacement.items() if path in keys}
        assert len(actual_replacements) == (5 if label == 'cli' else 6)
        additions = [units[-1]['object']] if label == 'test' else []
        output = W / ('bin/hyle.exe' if label == 'cli' else 'bin/metadata-queue-test.exe')
        link = q.link_command(read(B / ('link-' + label + '/command.json'))['command'],
                              actual_replacements, additions, output)
        save(W / ('recipes/link-' + label + '.json'), dict(command=link, cwd=str(R), timeout_seconds=120))
        inputs = [dict(path=actual_replacements[key(row['path'])], status='PLANNED_NOT_BUILT')
                  if key(row['path']) in actual_replacements else row for row in rows]
        inputs += [dict(path=path, status='PLANNED_NOT_BUILT') for path in additions]
        assert len(inputs) == count
        save(W / ('planned-' + label + '-inputs.json'), inputs)

    # Record actual include consumers. The new RegionAccess/static method and
    # BatchGraphAccess overload are additive; their classes gain no data.
    # AppendQueueBinding has a new shared_ptr and is constructed/indexed only
    # in the two recompiled GraphBatch TUs. No public Invocation/Node ABI changed.
    consumers = []
    header_keys = {str((R / path)).lower() for path in HEADERS}
    selected_sources = {str(R / path).lower() for path in SOURCES}
    for label, entries in [('cli', ci), ('test', ti)]:
        for source, entry in entries.items():
            matches = [path for path in entry['data'].get('Includes', [])
                       if str(path).lower() in header_keys]
            if matches:
                consumers.append(dict(closure=label, source=source, headers=matches,
                    dependencies=entry['dependencies'],
                    recompiled=source in selected_sources))
    save(W / 'header-consumers.json', consumers)
    tests = list(read(R / '.scratch/inference-pending-indexed-source-20261027/plan.json')['tests'])
    assert len(tests) == 38
    tests += ['GgmlCudaPendingIndexedState.ChangedDestinationIdsUploadWhileOriginalProducerIsPending',
              'GraphBatchCapture.FreshMetadataPermissionsRetainOnlyUnchangedNativeCommands']
    previous_runs = read(B / 'run-plan.json')
    tests += previous_runs['test']['expected_tests']
    assert len(tests) == len(set(tests)) == 43
    runs = previous_runs
    runs['status'] = 'PROPOSED_NOT_RUN'
    runs['test'] = dict(command=[str(W / 'bin/metadata-queue-test.exe'),
        '--gtest_color=no', '--gtest_filter=' + ':'.join(tests),
        '--gtest_output=xml:' + str(W / 'run-test/results.xml')], cwd=str(W),
        timeout_seconds=180, expected_tests=tests)
    for item in runs['cli']:
        item['command'][0] = str(W / 'bin/hyle.exe')
        item['cwd'] = str(W)
    runs['scope'] = 'Independent checked metadata Queue uploads retain original execution/proof/capture queues and real wait/publication. 43 finite tests plus original four tiny B2 CLI journeys; no full engine overlap/TPS, SDK/NVCC, or download claim.'
    save(W / 'run-plan.json', runs)
    runtime = read(B / 'runtime.json')
    runtime['planned_alias'] = str(W / 'bin' / Path(runtime['native_cpu']['path']).name)
    runtime.pop('native_cpu_hardlink', None)
    for field in ['PATH', 'test_PATH']:
        runtime[field] = str(W / 'bin') + ';' + runtime[field]
    save(W / 'runtime-plan.json', runtime)
    save(W / 'plan.json', dict(status='PREPARED_NOT_FROZEN_NOT_BUILT_NOT_RUN',
        baseline=dict(ready=pin(B / 'ready.json'), cli_inputs=pin(B / 'cli-link-inputs.json'),
                      test_inputs=pin(B / 'test-link-inputs.json'), runtime=pin(B / 'runtime.json'),
                      cli_link=pin(B / 'link-cli/command.json'), test_link=pin(B / 'link-test/command.json')),
        units=units, changed_headers=[str(R / path) for path in HEADERS],
        sources_frozen=False, images=[str(W / 'bin/metadata-queue-test.exe'),str(W / 'bin/hyle.exe')],
        counts=dict(CXX_TUs=7, product_TUs=5, test_TUs=2, links=2,
                    test_processes=1, exact_GTests=43, CLI_processes=4,
                    CLI_link_inputs=224, test_link_inputs=237, SDK=0, NVCC=0, downloads=0),
        retained_engine='Reuse exact successful attempt2 main+matching weights+capacity/readback test objects. No source-including probe object is linked.',
        ABI='BatchBuffers and metadata queue caches are TU-private. RegionAccess and BatchGraphAccess gain only static methods. AppendQueueBinding and shared GraphBatch Slot layouts change only in batch.cc/paged_append.cc, both recompiled. No Node/Recipe/InvocationState/public Backend/Plan/Readback layout change in this batch.',
        ordering='Wait for root/core final source freeze before generating snapshots or invoking compiler. This script has no build or run phase.',
        scope=runs['scope']))
    print('PREPARED 7 CXX / 2 links / 43 GTests / 4 tiny CLI; no freeze/build/run.')


if __name__ == '__main__':
    main()
