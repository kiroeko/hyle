"""Bounded metadata-Queue validation: explicit freeze/build/run stages."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('metadata_previous_check',
    R / '.scratch/inference-relay-carriers-20261027/attempt2/check.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
old.W = W
b, h, m = old.b, old.h, old.m
active = None


def freeze():
    assert not (W / 'frozen-plan.json').exists()
    plan = b.read(W / 'plan.json')
    for row in plan['baseline'].values():
        b.exact(row)
    units = plan['units']
    for unit in units:
        b.exact(unit['command'])
        unit['source'] = b.pin(unit['source'])
        unit['source_frozen'] = True
    paths = [Path(unit['source']['path']) for unit in units]
    paths += [Path(path) for path in plan['changed_headers']]
    closure = m.c.closure(paths, [unit['command']['path'] for unit in units])
    b.save(W / 'source-freeze.json', closure)
    snapshots = []
    for source in paths:
        target = W / 'source' / source.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
        snapshots.append(dict(original=b.pin(source), snapshot=b.pin(target)))
    records = [W / 'plan.json', W / 'run-plan.json', W / 'runtime-plan.json',
               W / 'planned-cli-inputs.json', W / 'planned-test-inputs.json',
               W / 'header-consumers.json', W / 'recipes/link-cli.json', W / 'recipes/link-test.json']
    b.save(W / 'frozen-plan.json', dict(status='SOURCE_FROZEN_NOT_BUILT',
        plan=b.pin(W / 'plan.json'), units=units, sources=b.pin(W / 'source-freeze.json'),
        snapshots=snapshots, records=[b.pin(path) for path in records],
        scope=plan['scope'], counts=plan['counts']))
    print('FROZEN 7 CXX sources + 3 changed private headers; dependency hashes only, no SDK copy.', flush=True)


def frozen():
    data = b.read(W / 'frozen-plan.json')
    b.exact(data['plan']); b.exact(data['sources'])
    for row in b.read(data['sources']['path']):
        b.exact(row)
    for entry in data['snapshots']:
        b.exact(entry['original']); b.exact(entry['snapshot'])
    for row in data['records']:
        b.exact(row)
    for unit in data['units']:
        b.exact(unit['command'])
    return data


def build():
    global active
    data = frozen()
    assert not (W / 'compile').exists() and not (W / 'ready.json').exists()
    plan = b.read(W / 'plan.json')
    for row in plan['baseline'].values():
        b.exact(row)
    env = old.environment('cli')
    own = {b.key(row['path']): row for row in b.read(data['sources']['path'])}
    compiled, objects = [], {}
    for unit in data['units']:
        active = 'compile/' + unit['name']
        out = W / active
        process = h.execute(b.read(unit['command']['path'])['command'], env, out, timeout=180)
        raw = b.read(out / 'dependencies.json')['Data']
        assert b.key(raw['Source']) == b.key(unit['source']['path'])
        actual = [b.pin(path) for path in dict.fromkeys([raw['Source'], *raw['Includes']])]
        b.save(out / 'actual-dependencies.json', actual)
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert own[b.key(path)]['sha256'] == row['sha256'], str(path)
        obj = b.pin(out / 'unit.obj')
        objects[b.key(obj['path'])] = obj
        compiled.append(dict(name=unit['name'], source=unit['source'], object=obj,
            process=process, actual_dependencies=b.pin(out / 'actual-dependencies.json')))
        b.save(W / 'compiled-partial.json', compiled)
        frozen()
    artifacts = []
    for name, count in [('test', 237), ('cli', 224)]:
        active = 'link-' + name
        inputs = []
        for row in b.read(W / ('planned-' + name + '-inputs.json')):
            if row.get('status') == 'PLANNED_NOT_BUILT':
                row = objects[b.key(row['path'])]
            b.exact(row); inputs.append(row)
        assert len(inputs) == count
        b.save(W / (name + '-link-inputs.json'), inputs)
        command = b.read(W / ('recipes/link-' + name + '.json'))['command']
        image = Path(next(arg[5:] for arg in command if arg.upper().startswith('/OUT:')))
        image.parent.mkdir(parents=True, exist_ok=True)
        linked = h.execute(command, old.environment(name), W / active, timeout=120)
        artifacts.append(dict(name=name, image=b.pin(image), link=linked,
                              inputs=b.pin(W / (name + '-link-inputs.json'))))
        b.save(W / 'linked-partial.json', artifacts)
        frozen()
    runtime = b.read(W / 'runtime-plan.json')
    b.exact(runtime['native_cpu'])
    alias = Path(runtime['planned_alias'])
    if alias.exists():
        assert b.pin(alias)['sha256'] == runtime['native_cpu']['sha256']
    else:
        os.link(runtime['native_cpu']['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(status='BUILT_NOT_RUN', compiled=compiled,
        artifacts=artifacts, frozen=b.pin(W / 'frozen-plan.json'),
        runtime=b.pin(W / 'runtime.json'), counts=plan['counts']))
    print('READY 7 CXX / 2 links', flush=True)


def run():
    global active
    frozen()
    ready = b.read(W / 'ready.json')
    b.exact(ready['frozen']); b.exact(ready['runtime'])
    for artifact in ready['artifacts']:
        b.exact(artifact['image']); b.exact(artifact['inputs'])
    assert not (W / 'run-test').exists() and not (W / 'summary.json').exists()
    plan = b.read(W / 'run-plan.json')
    active = 'run-test'
    test = plan['test']
    process = h.execute(test['command'], old.environment('test'), W / active, timeout=test['timeout_seconds'])
    xml = Path(next(arg.split('xml:', 1)[1] for arg in test['command']
                    if arg.startswith('--gtest_output=xml:')))
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    assert len(cases) == len(test['expected_tests']) == 43
    assert {case.attrib['classname'] + '.' + case.attrib['name'] for case in cases} == set(test['expected_tests'])
    assert all(case.attrib.get('status') == 'run' and not case.findall('failure')
        and not case.findall('error') and not case.findall('skipped') for case in cases)
    results = [dict(name='test', process=process, tests=[case.attrib for case in cases])]
    b.save(W / 'summary-partial.json', results)
    for journey in plan['cli']:
        frozen()
        active = 'runs/' + journey['name']
        out = W / active
        assert not out.exists()
        process = h.execute(journey['command'], old.environment('cli'), out,
                            timeout=journey['timeout_seconds'])
        report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
        b.save(out / 'report.json', report)
        expected = journey['expected']
        for name in ['backend', 'mtp', 'session_count', 'admitted_requests',
                     'retired_requests', 'live_committed_versions']:
            assert report[name] == expected[name], (journey['name'], name, report[name], expected[name])
        assert len(report['sessions']) == 2 and report['active_sequences'] == 2
        assert {session['session_id'] for session in report['sessions']} == {'A', 'B'}
        assert report['generated_tokens'] == report['requested_output_tokens'] == 16
        assert any(batch['requests'] == 2 and len(batch['session_ids']) == 2 for batch in report['batches'])
        for session in report['sessions']:
            result = session['result']
            assert result['generated_tokens'] == result['requested_steps'] == expected['generated_tokens_per_session'] == 8
            assert len(result['generated_ids']) == 8 and all(type(token) is int and 0 <= token < 64 for token in result['generated_ids'])
            assert result['backend'] == expected['backend'] and result['mtp'] == expected['mtp']
            assert result['visible_tokens'] == 10 and result['logical_prompt_tokens'] == 3
            assert len(result['turns']) == 1
            turn = result['turns'][0]
            assert turn['output_begin'] == 0 and turn['output_end'] == 8 and turn['context_after'] == 10
            assert turn['input_ids'] == ([1, 2, 3] if session['session_id'] == 'A' else [4, 5, 6])
            if expected['mtp']:
                assert result['mtp_max_drafts'] == 3
        results.append(dict(name=journey['name'], process=process, report=b.pin(out / 'report.json'),
            generated_ids={session['session_id']:session['result']['generated_ids'] for session in report['sessions']},
            max_actual_batch_requests=max(batch['requests'] for batch in report['batches'])))
        b.save(W / 'summary-partial.json', results)
    frozen()
    b.save(W / 'summary.json', dict(status='PASS', results=results,
        ready=b.pin(W / 'ready.json'), scope=plan['scope'], counts=b.read(W / 'plan.json')['counts']))
    print('PASS 43 GTests + 4 tiny CLI journeys', flush=True)


if __name__ == '__main__':
    stage = sys.argv[1]
    try:
        {'freeze': freeze, 'build': build, 'run': run}[stage]()
    except Exception:
        target = W / (stage + '-failure.json')
        if not target.exists():
            b.save(target, dict(stage=stage, active=active, error=traceback.format_exc(),
                note='Original command/process/stdout/stderr/XML remain. No automatic retry or SDK rebuild.'))
        raise
