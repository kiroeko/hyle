from pathlib import Path
import difflib, hashlib, json, zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
O = R / 'docs/evidence/correctness'
NAME = 'inference-execution-observation-2026-10-24'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p): return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                        sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v): p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')

regression = read(D/'regression/proof-summary.json')
assert regression['state']=='passed'
assert all(read(D/'source-only.json')['checks'].values())
assert read(D/'cmake-targets/process.json')['exit']==0
assert pin(R/'engine/models/qwen35/main.cc')['sha256']=='88a791f481351eb38af1cbd78bec9c23c0dc887bc24ec5f6c875cdef21ade63b'
for row in read(D/'after-pins.json'):
    p=Path(row['path'])
    if not p.is_absolute(): p=R/p
    assert pin(p)['sha256']==row['sha256']
changes=[]
for name in ['engine/CMakeLists.txt','tests/CMakeLists.txt']:
    changes.extend(difflib.unified_diff((D/'before'/name).read_text().splitlines(True),
        (R/name).read_text().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
(D/'build.patch').write_text(''.join(changes),encoding='utf8')
additional=['source-only.json','after-pins.json','changes.patch',
            'root-before-pins.json','build.patch','integration-review.md','publish.py']
assert all((D/name).is_file() for name in additional)
archive=O/(NAME+'.zip');assert not archive.exists()
allowed={'.cc','.h','.py','.md','.json','.log','.patch','.txt','.ids'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
    with zipfile.ZipFile(D/'regression/proof.zip')as original:
        for item in original.infolist():
            assert not item.is_dir() and Path(item.filename).suffix in allowed
            out.writestr('regression/'+item.filename,original.read(item))
    for folder in ['before','cmake-targets']:
        for p in sorted((D/folder).rglob('*')):
            if p.is_file()and p.suffix in allowed:out.write(p,'additional/'+p.relative_to(D).as_posix())
    for name in additional:
        out.write(D/name,'additional/'+name)
    for name in ['engine/CMakeLists.txt','tests/CMakeLists.txt','engine/inference/execution_observation.h',
                 'engine/reporting/execution_report.h','engine/reporting/execution_report.cc',
                 'engine/models/qwen35/mtp_session_probe.cc']:
        out.write(R/name,'canonical/'+name)
report=dict(state='passed',date='2026-10-24',
 scope='Model-independent execution observation records and separate CLI formatters, shared by ordinary/MTP and fixed replay. Finite Windows CPU/Vulkan consumer regression.',
 changes=['StepObservation and PreparationObservation belong to hyle::inference with unchanged fields/defaults.',
          'Two formatters live in a real separate reporting translation unit with explicit ostream; original commit/observation/trace ordering retained.',
          'Existing target helper and registered include-main test build the small reporting TU; no new SDK module, registry or compatibility alias.'],
 actual_consumer_regression=regression,source_only=read(D/'source-only.json'),
 build_configuration=dict(state='passed',test='Existing EngineComponentsTest.test_actual_application_target_is_default_and_probes_are_opt_in',
                         scope='Real application/probe CMake directory configured against tiny existing interface fixture, no SDK build.',
                         process=read(D/'cmake-targets/process.json')),
 limitations=['Actual runtime fixture is small untrained A-only; no whole-model quality, all-platform or performance claim.',
              'Actual runtime reaches step/prepared writers; prefix/preparation/batch-plan writer branches have source-equivalence evidence only.',
              'Model fallback printing, request JSON/trace separation and cross-model state/generation adaptation remain unfinished.'],
 SDK_builds=0,HTTP_requests=0,downloads_bytes=0,archive=pin(archive),
 cleanup='Rebuildable private objects/images removed through root test.ps1 after evidence publication; source/logs/cache retained.')
save(O/(NAME+'.json'),report)
print(json.dumps(dict(report=pin(O/(NAME+'.json')),archive=pin(archive))))
