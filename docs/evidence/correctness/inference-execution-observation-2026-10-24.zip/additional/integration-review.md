# Execution observation boundary

The two observation records contain only host values and public Graph/Compute
facts. They own no Qwen state, backend, queue or execution lease. Their fields,
defaults and vector ownership are unchanged in `hyle::inference`.

Both formatters are real separately compiled functions in `engine/reporting`.
The caller supplies the stream; current call sites still pass `std::cerr` at the
original positions. Precision 17 and successful-return restoration remain as
before; no new restoration guarantee is claimed if the stream throws.

The model still captures observations after authoritative batch/head publication.
Ledger observation, pending/RNG advancement and trace capture were not moved into
the writer. The remaining model fallback output is still after commit and before
trace; fully removing Model I/O remains a later migration.

The existing engine target helper adds this small `.cc` to the executable and
all four opt-in model diagnostics. The only registered include-main test also
includes that `.cc` in its source list. No new SDK module/library or compatibility
alias was added. Two unregistered manual diagnostic sources must link the small
reporting object when built manually, like the private consumer does here.

Independent source review reconstructed the old complete main/probe by reversing
only this extraction and the explicit shared type/writer substitutions. The
remaining source bytes, mathematical graph and control ordering match. Actual
regression separately covers the existing finite request journeys and emitted
step fields. Prefix/preparation/batch-plan formatter branches not reached by that
journey are reported as unexercised; source equivalence is their evidence here.
