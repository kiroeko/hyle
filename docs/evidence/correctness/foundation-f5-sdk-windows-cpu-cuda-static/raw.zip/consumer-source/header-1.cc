#include <hyle/compute/batch_ops.h>
