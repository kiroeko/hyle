#include <gtest/gtest.h>

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <mutex>
#include <span>
#include <thread>

#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#include "hyle/graph/detail/output_source.h"
#include "hyle/graph/detail/submission_source.h"
#include "hyle/graph/detail/region_access.h"
#include "hyle/graph/detail/replay_access.h"
#include "hyle/graph/region_provider.h"
#include "hyle/graph/slots.h"
#include "hyle/graph/graph.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace gd = g::detail;

// Original Queue host gate, never a device spin kernel. The watchdog only
// releases this test gate, so a bad unexpected host wait cannot hang the GPU.
struct Gate final {
  cudaStream_t stream = nullptr;
  std::atomic<bool> released{false}, timed_out{false};
  std::mutex lock;
  std::condition_variable changed;
  std::thread watchdog;
  static void CUDART_CB wait(void *opaque) {
    auto &gate = *static_cast<Gate *>(opaque);
    gate.released.wait(false, std::memory_order_acquire);
  }
  void arm(cudaStream_t value) {
    stream = value;
    watchdog = std::thread([this] {
      std::unique_lock guard(lock);
      if (!changed.wait_for(guard, std::chrono::seconds(10),
              [this] { return released.load(std::memory_order_acquire); })) {
        timed_out.store(true, std::memory_order_release);
        release();
      }
    });
  }
  void release() noexcept {
    released.store(true, std::memory_order_release);
    released.notify_all(); changed.notify_all();
  }
  ~Gate() {
    release();
    if (watchdog.joinable()) watchdog.join();
    if (stream) EXPECT_EQ(cudaStreamSynchronize(stream), cudaSuccess);
  }
};

void relay(bool bad_producer_index, bool reuse_producer = false, bool region_consumer = false) {
  auto context_result = g::cuda::create_context();
  ASSERT_TRUE(context_result) << context_result.error().message();
  auto context = std::move(*context_result);
  auto queue = context.create_queue().value();
  ASSERT_TRUE(queue.reserve_completions(8).ok());
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto storage = c::StorageOwner::adopt(context, std::move(memory)).value();
  const auto i32 = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{1}).value();
  const auto table_i32 = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{4}).value();
  const auto table_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{4, 2}).value();
  const auto row_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{1, 2}).value();
  auto inputs = c::LeasePool::create(storage.ref(), 3 * 256, {.max_blocks = 3}).value();
  const auto source_blocks = reuse_producer ? 2u : 1u;
  auto source_pool = c::LeasePool::create(storage.ref(), source_blocks * 256,
      {.max_blocks = source_blocks}).value();
  auto output_pool = c::LeasePool::create(storage.ref(), 256, {.max_blocks = 1}).value();
  c::cuda::MemoryResource staging;
  if (region_consumer) staging = c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kPinnedHost).value();
  auto table = inputs.allocate(4 * sizeof(std::int32_t), 256).value();
  auto index = inputs.allocate(sizeof(std::int32_t), 256).value();
  auto embedding = inputs.allocate(8 * sizeof(float), 256).value();
  constexpr std::array<std::int32_t, 4> tokens{2, 1, 3, 0};
  const std::array<std::int32_t, 1> select{bad_producer_index ? 4 : 0};
  constexpr std::array<float, 8> rows{10, 11, 20, 21, 30, 31, 40, 41};
  ASSERT_TRUE(table.view()->write(std::as_bytes(std::span(tokens))).ok());
  ASSERT_TRUE(index.view()->write(std::as_bytes(std::span(select))).ok());
  ASSERT_TRUE(embedding.view()->write(std::as_bytes(std::span(rows))).ok());
  auto table_ready = table.publish().value(), index_ready = index.publish().value();
  auto embedding_ready = embedding.publish().value();
  // Prepare every new payload/allocation before any native host gate. The
  // reuse step itself only binds these existing genuine owners.
  c::LeasePool next_index_pool;
  c::ReadLease next_index;
  c::WriteLease next_token_writer;
  if (reuse_producer) {
    next_index_pool = c::LeasePool::create(storage.ref(), 256, {.max_blocks = 1}).value();
    auto prepared_index = next_index_pool.allocate(sizeof(std::int32_t), 256).value();
    constexpr std::array<std::int32_t, 1> other_index{1};
    ASSERT_TRUE(prepared_index.view()->write(std::as_bytes(std::span(other_index))).ok());
    next_index = prepared_index.publish().value();
  }

  auto first = g::GraphBuilder::create().value();
  const auto first_table = first.input(table_i32).value();
  const auto first_index = first.input(i32).value();
  const auto token = first.add(c::Gather{.axis = 0}, first_table, first_index).value();
  ASSERT_TRUE(first.publish(token).ok());
  auto first_graph = std::move(first).finish().value();
  auto producer_plan = g::cuda::compile(first_graph, context, storage);
  ASSERT_TRUE(producer_plan) << producer_plan.error().message();
  auto producer = producer_plan->executable.create_invocation().value();
  ASSERT_TRUE(producer.prepare_resources().ok());
  ASSERT_TRUE(producer.bind(first_table, table_i32, table_ready).ok());
  ASSERT_TRUE(producer.bind(first_index, i32, index_ready).ok());
  auto token_writer = source_pool.allocate(sizeof(std::int32_t), 256).value();
  if (reuse_producer) {
    next_token_writer = source_pool.allocate(sizeof(std::int32_t), 256).value();
    const auto original_storage = token_writer.view().value();
    const auto next_storage = next_token_writer.view().value();
    EXPECT_EQ(original_storage.native_handle(), next_storage.native_handle());
    EXPECT_NE(original_storage.offset(), next_storage.offset());
  }
  ASSERT_TRUE(producer.bind(token, i32, std::move(token_writer)).ok());

  auto second = g::GraphBuilder::create().value();
  const auto second_table = second.input(table_f32).value();
  const auto second_index = second.input(i32).value();
  const auto selected = second.add(c::Gather{.axis = 0}, second_table, second_index).value();
  const auto item = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 1>{2}).value();
  g::NodeId store;
  if (region_consumer) {
    const auto ids = second.input(i32).value();
    store = second.add_node(c::Operation::custom(g::slots::Store{
        g::slots::Schema::create(item, 1, 256).value()}), std::array{selected, ids}).value();
  } else {
    ASSERT_TRUE(second.publish(selected).ok());
  }
  auto second_graph = std::move(second).finish().value();
  auto consumer_plan = g::cuda::compile(second_graph, context, storage);
  ASSERT_TRUE(consumer_plan) << consumer_plan.error().message();
  auto consumer = consumer_plan->executable.create_invocation().value();
  ASSERT_TRUE(consumer.prepare_resources().ok());
  if (region_consumer) {
    ASSERT_EQ(consumer_plan->report.region_count(), 1u);
    ASSERT_EQ(consumer_plan->report.step_count(), 2u);
    bool store_region = false;
    for (std::size_t i = 0; i < consumer_plan->report.step_count(); ++i) {
      const auto step = consumer_plan->report.step(i).value();
      EXPECT_EQ(step.runtime.mode, c::ProviderRuntimeMode::kSharedQueue);
      EXPECT_EQ(step.runtime.replay_class, c::ProviderReplayClass::kPrepared);
      EXPECT_FALSE(step.runtime.blocks_host);
      if (step.kind == g::CompileStepKind::kProviderRegion) {
        EXPECT_EQ(step.node_count, 1u); store_region = true;
      }
    }
    ASSERT_TRUE(store_region);
    bool hooks = false;
    const auto inspected = gd::RegionAccess::visit(consumer,
        [](void *opaque, const gd::RegionAccessView &view) noexcept -> hyle::Status {
          *static_cast<bool *>(opaque) = view.prepared_vtable &&
              view.prepared_vtable->prepare_bindings && view.prepared_vtable->seal_bindings;
          return hyle::Status::Ok();
        }, &hooks);
    ASSERT_TRUE(inspected.ok()) << inspected.message();
    ASSERT_TRUE(hooks); // A genuine selected region, never a leaf/proxy fallback.
  }
  ASSERT_TRUE(consumer.bind(second_table, table_f32, embedding_ready).ok());
  auto row_writer = output_pool.allocate(2 * sizeof(float), 256).value();
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  if (region_consumer) {
    const auto layout = c::LeaseSlotLayout::create(output_pool, item, 1, 256).value();
    std::array<c::WriteLease, 1> destination{std::move(row_writer)};
    auto transaction = g::slots::SlotBindings::create(layout, {}, destination).value();
    ASSERT_TRUE(g::slots::prepare(consumer, queues, {.host_workspace = staging.ref()}).ok());
    ASSERT_TRUE(g::slots::bind(consumer, second_graph, store, std::move(transaction)).ok());
  } else {
    ASSERT_TRUE(consumer.bind(selected, row_f32, std::move(row_writer)).ok());
  }
  ASSERT_TRUE(producer.prepare_replay(queues,
      {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kReject}).ok());

  Gate gate;
  Gate reader_gate;
  gate.arm(c::cuda::stream(queue).value());
  ASSERT_EQ(cudaLaunchHostFunc(gate.stream, &Gate::wait, &gate), cudaSuccess);
  auto submitted = producer.submit(queues);
  ASSERT_TRUE(submitted) << submitted.error().message();
  auto foreign = c::Completion::completed();
  EXPECT_FALSE(gd::SubmissionSource::create(producer, std::move(foreign), storage));
  EXPECT_TRUE(foreign.valid());
  auto submission_result = gd::SubmissionSource::create(producer, std::move(*submitted), storage);
  ASSERT_TRUE(submission_result) << submission_result.error().message();
  auto submission_source = std::move(*submission_result);
  auto source_result = gd::OutputSource::create(submission_source, token, storage, source_pool);
  ASSERT_TRUE(source_result) << source_result.error().message();
  auto source = std::move(*source_result);
  const std::array bindings{gd::OutputBinding{second_index, &source}};
  EXPECT_FALSE(submitted->valid());
  ASSERT_TRUE(source.poll());
  EXPECT_EQ(*source.poll(), c::CompletionPoll::kPending);
  EXPECT_TRUE(source.detach().IsUnavailable());
  EXPECT_FALSE(producer.reset().ok());
  EXPECT_FALSE(gd::bind_outputs(producer, std::array{gd::OutputBinding{first_index, &source}}).ok());
  const auto bound = gd::bind_outputs(consumer, bindings);
  ASSERT_TRUE(bound.ok()) << bound.message();
  EXPECT_FALSE(gd::bind_outputs(consumer, bindings).ok());
  EXPECT_FALSE(consumer.prepare_replay(queues,
      {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject}).ok());
  const auto prepared = gd::prepare_outputs(consumer, bindings, queues);
  ASSERT_TRUE(prepared.ok()) << prepared.message();
  EXPECT_EQ(consumer.replay_route(), g::ReplayRoute::kCommands);
  if (region_consumer) {
    EXPECT_FALSE(gate.released.load(std::memory_order_acquire));
    ASSERT_TRUE(source.poll());
    EXPECT_EQ(*source.poll(), c::CompletionPoll::kPending);
  }
  const auto source_report = consumer.input_source_report().value();
  EXPECT_EQ(source_report.source_count, 1u);
  EXPECT_EQ(source_report.device_wait_count, 1u);
  EXPECT_EQ(source_report.host_wait_count, 0u);
  // The ordinary public entry cannot silently treat pending bytes as ready.
  EXPECT_FALSE(consumer.submit(queues));
  EXPECT_FALSE(consumer.in_flight());
  if (reuse_producer) {
    // The producer's original completion precedes this gate; B's actual read
    // follows it. Thus A can retire while B still owns a pending native read.
    reader_gate.arm(gate.stream);
    ASSERT_EQ(cudaLaunchHostFunc(reader_gate.stream, &Gate::wait, &reader_gate), cudaSuccess);
  }
  auto consumed = gd::submit_outputs(consumer, bindings, queues);
  ASSERT_TRUE(consumed) << consumed.error().message();
  auto pending = consumed->poll();
  ASSERT_TRUE(pending) << pending.error().message();
  EXPECT_EQ(*pending, c::CompletionPoll::kPending);
  EXPECT_TRUE(producer.in_flight()); EXPECT_TRUE(consumer.in_flight());
  EXPECT_GT(source_pool.stats().active_uses, 0u);
  gate.release();
  c::Completion next_submission;
  if (reuse_producer) {
    const auto first_status = source.wait();
    ASSERT_TRUE(first_status.ok()) << first_status.message();
    ASSERT_FALSE(producer.in_flight());
    ASSERT_TRUE(consumer.in_flight());
    EXPECT_EQ(*consumed->poll(), c::CompletionPoll::kPending);
    const auto detached = source.detach();
    ASSERT_TRUE(detached.ok()) << detached.message();
    EXPECT_TRUE(source.detach().ok());
    const auto closed_submission = submission_source.detach();
    ASSERT_TRUE(closed_submission.ok()) << closed_submission.message();
    ASSERT_TRUE(producer.bind(first_index, i32, next_index).ok());
    ASSERT_TRUE(producer.bind(token, i32, std::move(next_token_writer)).ok());
    const auto prepared_next = producer.prepare_replay(queues,
        {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kReject});
    ASSERT_TRUE(prepared_next.ok()) << prepared_next.message();
    auto next = producer.submit(queues);
    ASSERT_TRUE(next) << next.error().message();
    next_submission = std::move(*next);
    EXPECT_TRUE(producer.in_flight()); EXPECT_TRUE(consumer.in_flight());
    EXPECT_EQ(*next_submission.poll(), c::CompletionPoll::kPending);
    // The old source's terminal identity no longer names A's observation slot.
    EXPECT_EQ(*source.poll(), c::CompletionPoll::kComplete);
    EXPECT_TRUE(source.wait().ok());
    reader_gate.release();
  }
  const auto consumer_status = consumed->wait();
  const auto producer_status = source.wait();
  if (reuse_producer) {
    const auto next_status = next_submission.wait();
    ASSERT_TRUE(next_status.ok()) << next_status.message();
    std::array<std::int32_t, 1> actual_next{};
    ASSERT_TRUE(producer.output(token)->storage().read(
        std::as_writable_bytes(std::span(actual_next))).ok());
    EXPECT_EQ(actual_next, (std::array<std::int32_t, 1>{1}));
    EXPECT_TRUE(source.detach().ok());
  }
  EXPECT_FALSE(gate.timed_out.load(std::memory_order_acquire));
  EXPECT_FALSE(reader_gate.timed_out.load(std::memory_order_acquire));
  EXPECT_FALSE(producer.in_flight()); EXPECT_FALSE(consumer.in_flight());
  EXPECT_EQ(source_pool.stats().active_uses, 0u);
  EXPECT_EQ(output_pool.stats().active_uses, 0u);
  if (bad_producer_index) {
    EXPECT_FALSE(producer_status.ok()); EXPECT_FALSE(consumer_status.ok());
    EXPECT_EQ(consumer_status.code(), producer_status.code());
    EXPECT_EQ(consumer_status.message(), producer_status.message());
    EXPECT_FALSE(consumer.output(selected));
    const auto detached = source.detach();
    EXPECT_FALSE(detached.ok());
    EXPECT_EQ(detached.code(), producer_status.code());
    EXPECT_EQ(detached.message(), producer_status.message());
  } else {
    ASSERT_TRUE(producer_status.ok()) << producer_status.message();
    ASSERT_TRUE(consumer_status.ok()) << consumer_status.message();
    std::array<float, 2> actual{};
    if (region_consumer) {
      auto returned = g::slots::take(consumer, store);
      ASSERT_TRUE(returned) << returned.error().message();
      ASSERT_EQ(returned->destination_count(), 1u);
      auto ready = returned->destinations()[0].publish();
      ASSERT_TRUE(ready) << ready.error().message();
      ASSERT_TRUE(ready->view()->read(std::as_writable_bytes(std::span(actual))).ok());
    } else {
      ASSERT_TRUE(consumer.output(selected)->storage().read(
          std::as_writable_bytes(std::span(actual))).ok());
    }
    EXPECT_EQ(actual, (std::array<float, 2>{30, 31}));
    // Successful observation does not drop the immutable producer pin.
    if (!reuse_producer) EXPECT_FALSE(producer.reset().ok());
  }
  *consumed = {};
  source = {};
  consumer = {};
  if (bad_producer_index) {
    EXPECT_FALSE(gd::RegionAccess::outcome_available(producer));
    const auto closed = submission_source.detach();
    ASSERT_TRUE(closed.ok()) << closed.message();
    EXPECT_TRUE(gd::RegionAccess::outcome_available(producer));
    const auto original_failure = submission_source.wait();
    EXPECT_EQ(original_failure.code(), producer_status.code());
    EXPECT_EQ(original_failure.message(), producer_status.message());
  }
  submission_source = {}; producer = {};
  EXPECT_EQ(source_pool.stats().live_blocks, 0u);
  EXPECT_EQ(output_pool.stats().live_blocks, 0u);
}

TEST(GraphOutputSourceCuda, PendingI32UsesOriginalQueueAndLeasesForCheckedGather) { relay(false); }
TEST(GraphOutputSourceCuda, PendingI32PreparesRealStoreRegionBindingHooks) { relay(false, false, true); }
TEST(GraphOutputSourceCuda, ProducerCheckedFailureRejectsConsumerPublicationAfterRetirement) { relay(true); }
TEST(GraphOutputSourceCuda, RetiredSourceDetachesWhileReaderPendingAndProducerReusesNewWriter) { relay(false, true); }
TEST(GraphOutputSourceCuda, PendingI32ReusesRealNativeRegionCaptureWithoutRecording) {
  auto context_result = g::cuda::create_context();
  ASSERT_TRUE(context_result) << context_result.error().message();
  auto context = std::move(*context_result);
  auto queue = context.create_queue().value();
  ASSERT_TRUE(queue.reserve_completions(8).ok());
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto storage = c::StorageOwner::adopt(context, std::move(memory)).value();
  const auto i32 = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{1}).value();
  const auto table_i32 = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{4}).value();
  const auto table_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{4, 2}).value();
  const auto row_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{1, 2}).value();
  auto inputs = c::LeasePool::create(storage.ref(), 4 * 256, {.max_blocks = 4}).value();
  auto token_pool = c::LeasePool::create(storage.ref(), 256, {.max_blocks = 1}).value();
  auto output_pool = c::LeasePool::create(storage.ref(), 256, {.max_blocks = 1}).value();
  auto table = inputs.allocate(4 * sizeof(std::int32_t), 256).value();
  auto index = inputs.allocate(sizeof(std::int32_t), 256).value();
  auto embedding = inputs.allocate(8 * sizeof(float), 256).value();
  auto other_embedding = inputs.allocate(8 * sizeof(float), 256).value();
  auto token_writer = token_pool.allocate(sizeof(std::int32_t), 256).value();
  constexpr std::array<std::int32_t, 4> tokens{2, 1, 3, 0};
  constexpr std::array<std::int32_t, 1> select{0}, warm_token{1};
  constexpr std::array<float, 8> rows{10, 11, 20, 21, 30, 31, 40, 41};
  ASSERT_TRUE(table.view()->write(std::as_bytes(std::span(tokens))).ok());
  ASSERT_TRUE(index.view()->write(std::as_bytes(std::span(select))).ok());
  ASSERT_TRUE(embedding.view()->write(std::as_bytes(std::span(rows))).ok());
  ASSERT_TRUE(other_embedding.view()->write(std::as_bytes(std::span(rows))).ok());
  ASSERT_TRUE(token_writer.view()->write(std::as_bytes(std::span(warm_token))).ok());
  auto table_ready = table.publish().value(), index_ready = index.publish().value();
  auto embedding_ready = embedding.publish().value();
  auto other_embedding_ready = other_embedding.publish().value();
  auto token_ready = token_writer.publish().value();
  const auto token_generation = token_ready.generation();
  // A descriptor alone retains no extra read permission. The original ready
  // alias is explicitly withdrawn before handing its one block to A.
  const auto token_view = token_ready.tensor(i32).value();
  const auto token_storage = token_view.storage();

  auto first = g::GraphBuilder::create().value();
  const auto first_table = first.input(table_i32).value();
  const auto first_index = first.input(i32).value();
  const auto token = first.add(c::Gather{.axis = 0}, first_table, first_index).value();
  ASSERT_TRUE(first.publish(token).ok());
  const auto first_graph = std::move(first).finish().value();
  auto producer_plan = g::cuda::compile(first_graph, context, storage);
  ASSERT_TRUE(producer_plan) << producer_plan.error().message();
  auto producer = producer_plan->executable.create_invocation().value();
  ASSERT_TRUE(producer.prepare_resources().ok());
  ASSERT_TRUE(producer.bind(first_table, table_i32, table_ready).ok());
  ASSERT_TRUE(producer.bind(first_index, i32, index_ready).ok());

  auto second = g::GraphBuilder::create().value();
  const auto second_table = second.input(table_f32).value();
  const auto second_index = second.input(i32).value();
  const auto gathered = second.add(c::Gather{.axis = 0}, second_table, second_index).value();
  const auto selected = second.add(c::Binary{.kind = c::BinaryKind::kAdd}, gathered, gathered).value();
  ASSERT_TRUE(second.publish(selected).ok());
  const auto second_graph = std::move(second).finish().value();
  auto consumer_plan = g::cuda::compile(second_graph, context, storage,
      {.operation_fallback = g::OperationFallbackPolicy::kReject});
  ASSERT_TRUE(consumer_plan) << consumer_plan.error().message();
  ASSERT_EQ(consumer_plan->report.region_count(), 1u);
  ASSERT_EQ(consumer_plan->report.step_count(), 1u);
  const auto compiled_step = consumer_plan->report.step(0).value();
  EXPECT_EQ(compiled_step.kind, g::CompileStepKind::kProviderRegion);
  EXPECT_EQ(compiled_step.node_count, 2u);
  EXPECT_EQ(compiled_step.runtime.mode, c::ProviderRuntimeMode::kSharedQueue);
  EXPECT_EQ(compiled_step.runtime.replay_class, c::ProviderReplayClass::kManaged);
  EXPECT_TRUE(compiled_step.runtime.blocks_host); // Original properties are unchanged.
  auto consumer = consumer_plan->executable.create_invocation().value();
  ASSERT_TRUE(consumer.prepare_resources().ok());
  bool hooks = false;
  ASSERT_TRUE(gd::RegionAccess::visit(consumer,
      [](void *opaque, const gd::RegionAccessView &view) noexcept -> hyle::Status {
        *static_cast<bool *>(opaque) = view.prepared_vtable &&
            view.prepared_vtable->prepare_bindings && view.prepared_vtable->seal_bindings;
        return hyle::Status::Ok();
      }, &hooks).ok());
  ASSERT_TRUE(hooks);
  ASSERT_TRUE(consumer.bind(second_table, table_f32, embedding_ready).ok());
  ASSERT_TRUE(consumer.bind(second_index, i32, token_ready).ok());
  auto row_writer = output_pool.allocate(2 * sizeof(float), 256).value();
  ASSERT_TRUE(consumer.bind(selected, row_f32, std::move(row_writer)).ok());
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  const auto warm = consumer.prepare_replay(queues,
      {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject});
  ASSERT_TRUE(warm.ok()) << warm.message();
  ASSERT_EQ(consumer.replay_route(), g::ReplayRoute::kCaptured);
  ASSERT_EQ(consumer.replay_report()->recorded_capture_range_count, 1u);
  ASSERT_EQ(consumer.replay_report()->reused_capture_range_count, 0u);

  // A different real embedding block invalidates the complete physical tuple.
  // Reuse-only preparation must reject rather than record it or choose Commands.
  ASSERT_TRUE(consumer.bind(second_table, table_f32, other_embedding_ready).ok());
  auto miss = gd::ReplayAccess::can_reuse_capture(consumer,
      std::array{gd::ReplayInputBinding{second_index, token_view}});
  ASSERT_TRUE(miss) << miss.error().message();
  EXPECT_FALSE(*miss);
  EXPECT_FALSE(gd::ReplayAccess::prepare_reuse(consumer, queues).ok());
  EXPECT_EQ(consumer.replay_route(), g::ReplayRoute::kUnprepared);
  EXPECT_FALSE(consumer.replay_report());
  ASSERT_TRUE(consumer.bind(second_table, table_f32, embedding_ready).ok());
  ASSERT_TRUE(consumer.unbind(second_index).ok());
  auto reclaimed = token_ready.try_write();
  ASSERT_TRUE(reclaimed) << reclaimed.error().message();
  EXPECT_FALSE(token_ready.valid());
  EXPECT_EQ(reclaimed->generation(), token_generation);
  const auto reclaimed_storage = reclaimed->view().value();
  EXPECT_EQ(reclaimed_storage.resource(), token_storage.resource());
  EXPECT_EQ(reclaimed_storage.native_handle(), token_storage.native_handle());
  EXPECT_EQ(reclaimed_storage.offset(), token_storage.offset());
  EXPECT_EQ(reclaimed_storage.size(), token_storage.size());
  ASSERT_TRUE(producer.bind(token, i32, std::move(*reclaimed)).ok());
  ASSERT_TRUE(producer.prepare_replay(queues,
      {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kReject}).ok());

  Gate gate;
  gate.arm(c::cuda::stream(queue).value());
  ASSERT_EQ(cudaLaunchHostFunc(gate.stream, &Gate::wait, &gate), cudaSuccess);
  auto submitted = producer.submit(queues);
  ASSERT_TRUE(submitted) << submitted.error().message();
  auto submission_result = gd::SubmissionSource::create(producer, std::move(*submitted), storage);
  ASSERT_TRUE(submission_result) << submission_result.error().message();
  auto submission_source = std::move(*submission_result);
  auto source_result = gd::OutputSource::create(submission_source, token, storage, token_pool);
  ASSERT_TRUE(source_result) << source_result.error().message();
  auto source = std::move(*source_result);
  const std::array bindings{gd::OutputBinding{second_index, &source}};
  ASSERT_TRUE(source.poll());
  ASSERT_EQ(*source.poll(), c::CompletionPoll::kPending);
  ASSERT_TRUE(consumer.bind(second_table, table_f32, other_embedding_ready).ok());
  EXPECT_FALSE(gd::bind_outputs(consumer, bindings).ok());
  EXPECT_TRUE(source.valid());
  EXPECT_FALSE(consumer.in_flight());
  EXPECT_EQ(consumer.replay_route(), g::ReplayRoute::kUnprepared);
  EXPECT_FALSE(consumer.replay_report());
  ASSERT_TRUE(source.poll());
  EXPECT_EQ(*source.poll(), c::CompletionPoll::kPending);
  ASSERT_TRUE(consumer.bind(second_table, table_f32, embedding_ready).ok());
  const auto bound = gd::bind_outputs(consumer, bindings);
  ASSERT_TRUE(bound.ok()) << bound.message();
  const auto prepared = gd::prepare_outputs(consumer, bindings, queues);
  ASSERT_TRUE(prepared.ok()) << prepared.message();
  EXPECT_FALSE(gate.released.load(std::memory_order_acquire));
  ASSERT_TRUE(source.poll());
  EXPECT_EQ(*source.poll(), c::CompletionPoll::kPending);
  ASSERT_EQ(consumer.replay_route(), g::ReplayRoute::kCaptured);
  EXPECT_EQ(consumer.replay_report()->recorded_capture_range_count, 0u);
  EXPECT_EQ(consumer.replay_report()->reused_capture_range_count, 1u);
  const auto dependencies = consumer.input_source_report().value();
  EXPECT_EQ(dependencies.source_count, 1u);
  EXPECT_EQ(dependencies.device_wait_count, 1u);
  EXPECT_EQ(dependencies.host_wait_count, 0u);
  EXPECT_FALSE(consumer.submit(queues)); // The pending input still needs ordered admission.
  auto consumed = gd::submit_outputs(consumer, bindings, queues);
  ASSERT_TRUE(consumed) << consumed.error().message();
  ASSERT_TRUE(consumed->poll());
  EXPECT_EQ(*consumed->poll(), c::CompletionPoll::kPending);
  gate.release();
  const auto finished = consumed->wait();
  ASSERT_TRUE(finished.ok()) << finished.message();
  ASSERT_TRUE(source.wait().ok());
  EXPECT_FALSE(gate.timed_out.load(std::memory_order_acquire));
  std::array<float, 2> actual{};
  ASSERT_TRUE(consumer.output(selected)->storage().read(
      std::as_writable_bytes(std::span(actual))).ok());
  EXPECT_EQ(actual, (std::array<float, 2>{60, 62}));
  EXPECT_FALSE(producer.in_flight()); EXPECT_FALSE(consumer.in_flight());
  EXPECT_EQ(token_pool.stats().active_uses, 0u);
  EXPECT_EQ(output_pool.stats().active_uses, 0u);
  *consumed = {}; source = {}; consumer = {}; submission_source = {}; producer = {};
  EXPECT_EQ(token_pool.stats().live_blocks, 0u);
  EXPECT_EQ(output_pool.stats().live_blocks, 0u);
}
TEST(GraphOutputSourceCuda, CapturedManagedI32ProducerRetainsItsOriginalSubmission) {
  auto context_result = g::cuda::create_context();
  ASSERT_TRUE(context_result) << context_result.error().message();
  auto context = std::move(*context_result);
  auto queue = context.create_queue().value();
  ASSERT_TRUE(queue.reserve_completions(8).ok());
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto storage = c::StorageOwner::adopt(context, std::move(memory)).value();
  const auto i32 = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{1}).value();
  const auto table_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{4, 2}).value();
  const auto row_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{1, 2}).value();
  auto inputs = c::LeasePool::create(storage.ref(), 2 * 256, {.max_blocks = 2}).value();
  auto token_pool = c::LeasePool::create(storage.ref(), 256, {.max_blocks = 1}).value();
  auto output_pool = c::LeasePool::create(storage.ref(), 256, {.max_blocks = 1}).value();
  auto index = inputs.allocate(sizeof(std::int32_t), 256).value();
  auto embedding = inputs.allocate(8 * sizeof(float), 256).value();
  constexpr std::array<std::int32_t, 1> wanted{2};
  constexpr std::array<float, 8> rows{10, 11, 20, 21, 30, 31, 40, 41};
  ASSERT_TRUE(index.view()->write(std::as_bytes(std::span(wanted))).ok());
  ASSERT_TRUE(embedding.view()->write(std::as_bytes(std::span(rows))).ok());
  auto index_ready = index.publish().value(), embedding_ready = embedding.publish().value();

  auto first = g::GraphBuilder::create().value();
  const auto first_index = first.input(i32).value();
  // A nonempty one-input Concat is an owned integer copy. Two such ordinary
  // operations form a real ggml region without introducing a sampling kernel.
  const auto copy0 = first.add_node(c::Operation(c::Concat{.axis = 0}),
      std::array{first_index}).value();
  const auto intermediate = first.result(copy0).value();
  const auto copy1 = first.add_node(c::Operation(c::Concat{.axis = 0}),
      std::array{intermediate}).value();
  const auto token = first.result(copy1).value();
  ASSERT_TRUE(first.publish(token).ok());
  const auto first_graph = std::move(first).finish().value();
  auto producer_plan = g::cuda::compile(first_graph, context, storage,
      {.operation_fallback = g::OperationFallbackPolicy::kReject});
  ASSERT_TRUE(producer_plan) << producer_plan.error().message();
  ASSERT_EQ(producer_plan->report.region_count(), 1u);
  ASSERT_EQ(producer_plan->report.step_count(), 1u);
  ASSERT_EQ(producer_plan->report.segment_count(), 1u);
  const auto producer_step = producer_plan->report.step(0).value();
  EXPECT_EQ(producer_step.kind, g::CompileStepKind::kProviderRegion);
  EXPECT_EQ(producer_step.node_count, 2u);
  EXPECT_EQ(producer_step.runtime.mode, c::ProviderRuntimeMode::kSharedQueue);
  EXPECT_EQ(producer_step.runtime.replay_class, c::ProviderReplayClass::kManaged);
  EXPECT_TRUE(producer_step.runtime.blocks_host);
  auto producer = producer_plan->executable.create_invocation().value();
  ASSERT_TRUE(producer.prepare_resources().ok());
  ASSERT_TRUE(producer.bind(first_index, i32, index_ready).ok());
  auto token_writer = token_pool.allocate(sizeof(std::int32_t), 256).value();
  ASSERT_TRUE(producer.bind(token, i32, std::move(token_writer)).ok());
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  const auto captured = producer.prepare_replay(queues,
      {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject});
  ASSERT_TRUE(captured.ok()) << captured.message();
  ASSERT_EQ(producer.replay_route(), g::ReplayRoute::kCaptured);
  const auto replay = producer.replay_report().value();
  EXPECT_EQ(replay.route, g::ReplayRoute::kCaptured);
  EXPECT_EQ(replay.recorded_capture_range_count, 1u);
  EXPECT_EQ(replay.reused_capture_range_count, 0u);
  EXPECT_EQ(replay.immediate_transfer_count, 0u);
  EXPECT_EQ(replay.host_wait_dependency_count, 0u);

  auto second = g::GraphBuilder::create().value();
  const auto second_table = second.input(table_f32).value();
  const auto second_index = second.input(i32).value();
  const auto selected = second.add(c::Gather{.axis = 0}, second_table, second_index).value();
  ASSERT_TRUE(second.publish(selected).ok());
  const auto second_graph = std::move(second).finish().value();
  auto consumer_plan = g::cuda::compile(second_graph, context, storage);
  ASSERT_TRUE(consumer_plan) << consumer_plan.error().message();
  ASSERT_EQ(consumer_plan->report.step_count(), 1u);
  const auto consumer_step = consumer_plan->report.step(0).value();
  EXPECT_EQ(consumer_step.runtime.replay_class, c::ProviderReplayClass::kPrepared);
  EXPECT_FALSE(consumer_step.runtime.blocks_host);
  auto consumer = consumer_plan->executable.create_invocation().value();
  ASSERT_TRUE(consumer.prepare_resources().ok());
  ASSERT_TRUE(consumer.bind(second_table, table_f32, embedding_ready).ok());
  auto row_writer = output_pool.allocate(2 * sizeof(float), 256).value();
  ASSERT_TRUE(consumer.bind(selected, row_f32, std::move(row_writer)).ok());

  Gate gate;
  gate.arm(c::cuda::stream(queue).value());
  ASSERT_EQ(cudaLaunchHostFunc(gate.stream, &Gate::wait, &gate), cudaSuccess);
  auto submitted = producer.submit(queues);
  ASSERT_TRUE(submitted) << submitted.error().message();
  auto common_result = gd::SubmissionSource::create(producer, std::move(*submitted), storage);
  ASSERT_TRUE(common_result) << common_result.error().message();
  auto common = std::move(*common_result);
  auto source_result = gd::OutputSource::create(common, token, storage, token_pool);
  ASSERT_TRUE(source_result) << source_result.error().message();
  auto source = std::move(*source_result);
  ASSERT_TRUE(common.poll());
  EXPECT_EQ(*common.poll(), c::CompletionPoll::kPending);
  EXPECT_FALSE(producer.reset().ok());
  const std::array bindings{gd::OutputBinding{second_index, &source}};
  const auto bound = gd::bind_outputs(consumer, bindings);
  ASSERT_TRUE(bound.ok()) << bound.message();
  const auto prepared = gd::prepare_outputs(consumer, bindings, queues);
  ASSERT_TRUE(prepared.ok()) << prepared.message();
  EXPECT_EQ(consumer.replay_route(), g::ReplayRoute::kCommands);
  EXPECT_FALSE(gate.released.load(std::memory_order_acquire));
  const auto dependency = consumer.input_source_report().value();
  EXPECT_EQ(dependency.source_count, 1u);
  EXPECT_EQ(dependency.device_wait_count, 1u);
  EXPECT_EQ(dependency.host_wait_count, 0u);
  EXPECT_FALSE(consumer.submit(queues));
  auto consumed = gd::submit_outputs(consumer, bindings, queues);
  ASSERT_TRUE(consumed) << consumed.error().message();
  ASSERT_TRUE(consumed->poll());
  EXPECT_EQ(*consumed->poll(), c::CompletionPoll::kPending);
  gate.release();
  const auto terminal = consumed->wait();
  ASSERT_TRUE(terminal.ok()) << terminal.message();
  ASSERT_TRUE(common.wait().ok());
  EXPECT_FALSE(gate.timed_out.load(std::memory_order_acquire));
  std::array<std::int32_t, 1> actual_token{};
  ASSERT_TRUE(producer.output(token)->storage().read(
      std::as_writable_bytes(std::span(actual_token))).ok());
  EXPECT_EQ(actual_token, wanted);
  std::array<float, 2> actual{};
  ASSERT_TRUE(consumer.output(selected)->storage().read(
      std::as_writable_bytes(std::span(actual))).ok());
  EXPECT_EQ(actual, (std::array<float, 2>{30, 31}));
  EXPECT_FALSE(producer.in_flight()); EXPECT_FALSE(consumer.in_flight());
  EXPECT_EQ(token_pool.stats().active_uses, 0u);
  EXPECT_EQ(output_pool.stats().active_uses, 0u);
  *consumed = {}; source = {}; consumer = {}; common = {}; producer = {};
  EXPECT_EQ(token_pool.stats().live_blocks, 0u);
  EXPECT_EQ(output_pool.stats().live_blocks, 0u);
}
TEST(GraphOutputSourceCuda, TwoOutputsShareOneOriginalSubmissionAndAtomicBundle) {
  auto context_result = g::cuda::create_context();
  ASSERT_TRUE(context_result) << context_result.error().message();
  auto context = std::move(*context_result);
  auto queue = context.create_queue().value();
  ASSERT_TRUE(queue.reserve_completions(8).ok());
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto storage = c::StorageOwner::adopt(context, std::move(memory)).value();
  const auto i32 = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{1}).value();
  const auto table_i32 = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{4}).value();
  const auto table_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{4, 2}).value();
  const auto row_f32 = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{1, 2}).value();
  auto inputs = c::LeasePool::create(storage.ref(), 6 * 256, {.max_blocks = 6}).value();
  auto tokens_pool = c::LeasePool::create(storage.ref(), 2 * 256, {.max_blocks = 2}).value();
  auto output_pool = c::LeasePool::create(storage.ref(), 2 * 256, {.max_blocks = 2}).value();
  auto table = inputs.allocate(4 * sizeof(std::int32_t), 256).value();
  auto embedding = inputs.allocate(8 * sizeof(float), 256).value();
  constexpr std::array<std::int32_t, 4> token_values{2, 1, 3, 0};
  constexpr std::array<float, 8> rows{10, 11, 20, 21, 30, 31, 40, 41};
  ASSERT_TRUE(table.view()->write(std::as_bytes(std::span(token_values))).ok());
  ASSERT_TRUE(embedding.view()->write(std::as_bytes(std::span(rows))).ok());
  auto table_ready = table.publish().value(), embedding_ready = embedding.publish().value();
  std::array<c::ReadLease, 2> selection, previous_indices;
  for (std::size_t i = 0; i < 2; ++i) {
    auto index = inputs.allocate(sizeof(std::int32_t), 256).value();
    const std::array<std::int32_t, 1> wanted{static_cast<std::int32_t>(i)};
    ASSERT_TRUE(index.view()->write(std::as_bytes(std::span(wanted))).ok());
    selection[i] = index.publish().value();
    auto previous = inputs.allocate(sizeof(std::int32_t), 256).value();
    const std::array<std::int32_t, 1> old{static_cast<std::int32_t>(i == 0 ? 3 : 0)};
    ASSERT_TRUE(previous.view()->write(std::as_bytes(std::span(old))).ok());
    previous_indices[i] = previous.publish().value();
  }

  auto first = g::GraphBuilder::create().value();
  const auto first_table = first.input(table_i32).value();
  std::array<g::ValueId, 2> first_indices, tokens;
  for (std::size_t i = 0; i < 2; ++i) {
    first_indices[i] = first.input(i32).value();
    tokens[i] = first.add(c::Gather{.axis = 0}, first_table, first_indices[i]).value();
    ASSERT_TRUE(first.publish(tokens[i]).ok());
  }
  const auto first_graph = std::move(first).finish().value();
  auto producer_plan = g::cuda::compile(first_graph, context, storage);
  ASSERT_TRUE(producer_plan) << producer_plan.error().message();
  ASSERT_EQ(producer_plan->report.step_count(), 2u);
  auto producer = producer_plan->executable.create_invocation().value();
  ASSERT_TRUE(producer.prepare_resources().ok());
  ASSERT_TRUE(producer.bind(first_table, table_i32, table_ready).ok());
  std::array<c::ConstTensorView, 2> original_tokens;
  for (std::size_t i = 0; i < 2; ++i) {
    ASSERT_TRUE(producer.bind(first_indices[i], i32, selection[i]).ok());
    auto writer = tokens_pool.allocate(sizeof(std::int32_t), 256).value();
    original_tokens[i] = writer.tensor(i32)->as_const();
    ASSERT_TRUE(producer.bind(tokens[i], i32, std::move(writer)).ok());
    const auto step = producer_plan->report.step(i).value();
    EXPECT_EQ(step.runtime.mode, c::ProviderRuntimeMode::kSharedQueue);
    EXPECT_EQ(step.runtime.replay_class, c::ProviderReplayClass::kPrepared);
    EXPECT_FALSE(step.runtime.blocks_host);
  }
  EXPECT_EQ(original_tokens[0].storage().resource(), original_tokens[1].storage().resource());
  EXPECT_EQ(original_tokens[0].storage().native_handle(), original_tokens[1].storage().native_handle());
  EXPECT_NE(original_tokens[0].storage().offset(), original_tokens[1].storage().offset());

  auto second = g::GraphBuilder::create().value();
  const auto second_table = second.input(table_f32).value();
  std::array<g::ValueId, 2> second_indices, selected;
  for (std::size_t i = 0; i < 2; ++i) {
    second_indices[i] = second.input(i32).value();
    selected[i] = second.add(c::Gather{.axis = 0}, second_table, second_indices[i]).value();
    ASSERT_TRUE(second.publish(selected[i]).ok());
  }
  const auto second_graph = std::move(second).finish().value();
  auto consumer_plan = g::cuda::compile(second_graph, context, storage);
  ASSERT_TRUE(consumer_plan) << consumer_plan.error().message();
  ASSERT_EQ(consumer_plan->report.step_count(), 2u);
  auto consumer = consumer_plan->executable.create_invocation().value();
  ASSERT_TRUE(consumer.prepare_resources().ok());
  ASSERT_TRUE(consumer.bind(second_table, table_f32, embedding_ready).ok());
  for (std::size_t i = 0; i < 2; ++i) {
    ASSERT_TRUE(consumer.bind(second_indices[i], i32, previous_indices[i]).ok());
    auto writer = output_pool.allocate(2 * sizeof(float), 256).value();
    ASSERT_TRUE(consumer.bind(selected[i], row_f32, std::move(writer)).ok());
    const auto step = consumer_plan->report.step(i).value();
    EXPECT_EQ(step.runtime.mode, c::ProviderRuntimeMode::kSharedQueue);
    EXPECT_EQ(step.runtime.replay_class, c::ProviderReplayClass::kPrepared);
    EXPECT_FALSE(step.runtime.blocks_host);
  }
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  ASSERT_TRUE(producer.prepare_replay(queues,
      {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kReject}).ok());
  Gate gate;
  gate.arm(c::cuda::stream(queue).value());
  ASSERT_EQ(cudaLaunchHostFunc(gate.stream, &Gate::wait, &gate), cudaSuccess);
  auto submitted = producer.submit(queues);
  ASSERT_TRUE(submitted) << submitted.error().message();
  auto common_result = gd::SubmissionSource::create(producer, std::move(*submitted), storage);
  ASSERT_TRUE(common_result) << common_result.error().message();
  auto common = std::move(*common_result);
  EXPECT_FALSE(submitted->valid());
  auto left_result = gd::OutputSource::create(common, tokens[0], storage, tokens_pool);
  auto right_result = gd::OutputSource::create(common, tokens[1], storage, tokens_pool);
  ASSERT_TRUE(left_result) << left_result.error().message();
  ASSERT_TRUE(right_result) << right_result.error().message();
  std::array<gd::OutputSource, 2> views{std::move(*left_result), std::move(*right_result)};
  ASSERT_TRUE(common.poll());
  ASSERT_EQ(*common.poll(), c::CompletionPoll::kPending);
  // The second input is foreign. A late rejection must neither replace the
  // first original reader nor claim either typed view's one-shot input name.
  const std::array rejected{gd::OutputBinding{second_indices[0], &views[0]},
                            gd::OutputBinding{first_indices[1], &views[1]}};
  EXPECT_FALSE(gd::bind_outputs(consumer, rejected).ok());
  auto preserved = previous_indices[0].try_write();
  ASSERT_FALSE(preserved) << "rejected bundle partially replaced its first input";
  EXPECT_TRUE(previous_indices[0].valid());
  EXPECT_TRUE(views[0].valid()); EXPECT_TRUE(views[1].valid());
  EXPECT_FALSE(consumer.in_flight());
  const std::array bindings{gd::OutputBinding{second_indices[0], &views[0]},
                            gd::OutputBinding{second_indices[1], &views[1]}};
  const auto bound = gd::bind_outputs(consumer, bindings);
  ASSERT_TRUE(bound.ok()) << bound.message();
  EXPECT_FALSE(gd::bind_outputs(consumer, bindings).ok());
  const auto prepared = gd::prepare_outputs(consumer, bindings, queues);
  ASSERT_TRUE(prepared.ok()) << prepared.message();
  EXPECT_FALSE(gate.released.load(std::memory_order_acquire));
  EXPECT_EQ(consumer.replay_route(), g::ReplayRoute::kCommands);
  const auto report = consumer.input_source_report().value();
  EXPECT_EQ(report.source_count, 1u);
  EXPECT_EQ(report.device_wait_count, 1u);
  EXPECT_EQ(report.host_wait_count, 0u);
  EXPECT_FALSE(consumer.submit(queues));
  auto consumed = gd::submit_outputs(consumer, bindings, queues);
  ASSERT_TRUE(consumed) << consumed.error().message();
  ASSERT_TRUE(consumed->poll());
  EXPECT_EQ(*consumed->poll(), c::CompletionPoll::kPending);
  gate.release();
  const auto terminal = consumed->wait();
  ASSERT_TRUE(terminal.ok()) << terminal.message();
  ASSERT_TRUE(common.wait().ok());
  EXPECT_FALSE(gate.timed_out.load(std::memory_order_acquire));
  constexpr std::array<std::array<float, 2>, 2> expected{{{30, 31}, {20, 21}}};
  for (std::size_t i = 0; i < 2; ++i) {
    std::array<float, 2> actual{};
    ASSERT_TRUE(consumer.output(selected[i])->storage().read(
        std::as_writable_bytes(std::span(actual))).ok());
    EXPECT_EQ(actual, expected[i]);
  }
  EXPECT_EQ(tokens_pool.stats().active_uses, 0u);
  EXPECT_EQ(output_pool.stats().active_uses, 0u);
  *consumed = {}; views = {}; consumer = {}; common = {}; producer = {};
  EXPECT_EQ(tokens_pool.stats().live_blocks, 0u);
  EXPECT_EQ(output_pool.stats().live_blocks, 0u);
}
} // namespace
