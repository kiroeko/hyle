from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('current_recipe', W / 'build.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b = q.b


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    q.check()
    ready = b.read(W / 'ready.json')
    b.exact(ready['image'])
    summary = b.read(W / 'summary.json')
    assert summary['status'] == 'PASS' and len(summary['tests']) == 12
    before = b.read(q.OLD / 'link-inputs2.json')
    after = b.read(W / 'link-inputs.json')
    assert len(before) == 230 and len(after) == 231
    for row in after:
        b.exact(row)
    old_by_path = {b.key(x['path']): x for x in before}
    new_by_path = {b.key(x['path']): x for x in after}
    retained = [x for k, x in old_by_path.items() if k in new_by_path]
    assert len(retained) == 227 and all(x == new_by_path[b.key(x['path'])] for x in retained)
    for row in retained:
        b.exact(row)
    command = b.read(W / 'link/command.json')['command']
    implib = next(x.split(':', 1)[1] for x in command if x.lower().startswith('/implib:'))
    side_outputs = [Path(implib), Path(implib).with_suffix('.exp')]
    assert all(b.key(x) not in old_by_path and b.key(x) not in new_by_path for x in side_outputs)

    changes = subprocess.run(['git', 'diff', '--', *q.SOURCES], cwd=R,
                             check=True, stdout=subprocess.PIPE).stdout
    (W / 'changes.patch').write_bytes(changes)
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=R,
                          check=True, stdout=subprocess.PIPE, text=True).stdout.strip()
    files = {}
    for name in ['build.py', 'publish.py', 'changes.patch', 'authorized-source-hashes.json',
                 'preparation-first-error.json', 'preparation.json', 'plan.json', 'ready.json',
                 'summary.json', 'selection.json', 'source-freeze.json', 'closure.json',
                 'link-inputs.json', 'runtime.json', 'results.xml']:
        files['records/' + name] = W / name
    files['records/baseline/ready2.json'] = q.OLD / 'ready2.json'
    files['records/baseline/link-inputs2.json'] = q.OLD / 'link-inputs2.json'
    for row in b.read(W / 'source-freeze.json'):
        relative = Path(row['path']).relative_to(R)
        snapshot = W / 'source' / relative
        assert snapshot.read_bytes() == Path(row['path']).read_bytes()
        files['source/' + relative.as_posix()] = snapshot
    for unit in ready['compiled']:
        base = W / 'compile' / unit['name']
        for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log', 'actual-dependencies.json']:
            files['records/compile/' + unit['name'] + '/' + name] = base / name
    for phase in ['link', 'run']:
        for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
            files['records/' + phase + '/' + name] = W / phase / name
    members = []
    for name, path in sorted(files.items()):
        assert path.suffix.lower() not in ['.exe', '.obj', '.pdb', '.dll', '.lib', '.exp']
        data = path.read_bytes()
        members.append(dict(name=name, bytes=len(data), sha256=digest(data)))
    manifest = json.dumps(members, indent=2).encode() + b'\n'
    destination = R / 'docs/evidence/correctness/inference-captured-submission-2026-10-27'
    archive = destination.with_suffix('.zip')
    assert not archive.exists() and not destination.with_suffix('.json').exists()
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, path in sorted(files.items()):
            z.writestr(name, path.read_bytes())
        z.writestr('archive-member-manifest.json', manifest)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for member in members:
            data = z.read(member['name'])
            assert len(data) == member['bytes'] and digest(data) == member['sha256']
        assert z.read('archive-member-manifest.json') == manifest

    receipt = dict(
        schema='hyle.finite-correctness-receipt.v1', date='2026-10-27', status='PASS',
        title='Actual captured producer admission and independent pending-read lease tickets',
        source_base=head,
        results=dict(total=12, passed=12, failed=0, skipped=0,
            process=summary['process'],
            blocks=[
                dict(name='Graph submission sources', tests=7, execution='Actual CUDA device',
                    new_case='GraphOutputSourceCuda.CapturedManagedI32ProducerRetainsItsOriginalSubmission',
                    claim='Two nonempty owned I32 Concat operations form one original shared-Queue managed/blocking region. RequireCapture creates complete actual coverage; the exact original submit proxy feeds one checked Gather consumer while a host gate keeps it pending. Token 2 and float row [30,31] are checked after actual retirement. Six previous source/bundle/error/detach/reuse cases also pass.',
                    capture_assertions=['Original static SharedQueue/Managed/blocks_host=true unchanged',
                        'One region, one step, one segment, two logical nodes',
                        'Actual Captured route, recorded ranges=1, reused=0, immediate transfers=0, host-wait dependencies=0',
                        'Pending source routes one native device dependency; no host wait or ordinary pending-input submit',
                        'Actual output values, native retirement and lease-use release']),
                dict(name='Compute pending-read protocol', tests=3,
                    execution='In-memory resources and controlled Completion fixture; not a GPU Store consumer',
                    claim='An exact writer-generation/range read ticket pins the original block without creating an ordinary ready lease. Tests cover writer-object lifetime and genuine publication, sealing new writes and allocation-free unique-ready promotion, consumer-error isolation and closed-domain rejection.'),
                dict(name='Adjacent original lease contracts', tests=2,
                    execution='Controlled Completion fixture',
                    claim='All ordered writes must really retire before publication; ordinary writer-capacity and closed-source checks remain.')],
            cases=[x['classname'] + '.' + x['name'] for x in summary['tests']]),
        build=dict(CXX_TUs=4, NVCC_TUs=0, links=1, test_images=1, test_processes=1,
            baseline_ready=b.pin(q.OLD / 'ready2.json'), baseline_inputs=b.pin(q.OLD / 'link-inputs2.json'),
            before_inputs=230, after_inputs=231, retained_unchanged=227, replaced=3, added_test_objects=1,
            compiled=ready['compiled'], link=ready['link'], image=ready['image'],
            ready=b.pin(W / 'ready.json'),
            reused='Existing native CUDA/CPU provider objects, libraries, compiler and runtime aliases. No SDK, shader, kernel, model or dependency download/build/copy.',
            header_boundary='Existing public lease/Invocation layouts unchanged; the new ticket is a separate detail class. The LeaseBlock private flag is read only by the rebuilt resource_leases.cc TU.',
            stale_recipe_include='The lease-test template historical scratch implementation include override was removed before compilation; actual dependencies record the current product headers.',
            linker_side_outputs=dict(
                fact='The as-run inherited /IMPLIB path rewrote these old scratch import/export auxiliary files. Neither file is in the old or new actual input closure. Original EXE/OBJ/SDK inputs were not replaced.',
                files=[b.pin(x) for x in side_outputs],
                future_recipe_fix='Rebase OUT, PDB, IMPLIB and other generated outputs together into the new scratch directory. The successful as-run recipe was preserved; no additional link or test was performed.')),
        sources=b.read(W / 'source-freeze.json'),
        observations=dict(
            device='Run stderr reports one NVIDIA GeForce RTX 4070, compute capability 8.9, 12281 MiB VRAM.',
            failures='No CXX/link/test failures. Recipe preparation initially failed Python parsing due to an extra parenthesis before any source freeze/child process; the correction and original error are recorded.',
            permission_boundary='Captured producer admission checks actual prepared Captured ranges for complete native-command coverage. Static capture-compatible flags alone, Hybrid coverage, missing/overlapping/out-of-segment ranges and uncovered emitted commands do not qualify the newly allowed blocking-producer branch. The original nonblocking path remains unchanged.'),
        not_claimed=['No pending Store/KV Graph bridge or complete rotating engine overlap pipeline is connected by this batch.',
            'No model/engine/ordinary-or-MTP performance benchmark, memory-speed claim or throughput claim.',
            'No multi-segment/multi-Queue/delegated producer or arbitrary dtype output support.',
            'No native GPU fault injection, unknown-retirement success claim or cross-platform run.'],
        archive=dict(**b.pin(archive), member_count=len(members) + 1,
            member_manifest_sha256=digest(manifest), verification='All ZIP members read back; every payload byte count and SHA-256 matched, and ZIP CRC test passed.',
            contents='Six exact validated product/header/test snapshots, patch, as-run recipes/commands/logs, source/dependency and old/new input identities. No executables, objects, PDBs, DLLs, SDK or model payload.'))
    b.save(destination.with_suffix('.json'), receipt)
    b.save(W / 'publication.json', dict(receipt=b.pin(destination.with_suffix('.json')),
                                       archive=b.pin(archive), image=ready['image']))
    print(json.dumps(b.read(W / 'publication.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()
