import difflib, hashlib, json, pathlib, posixpath, shlex, tarfile
STAGE=pathlib.Path(__file__).resolve().parent
ROOT=STAGE.parents[3]
BASE=ROOT/'.scratch/architecture-refactor-2026-10-18/mlx-affine-contract'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/mlx-affine-widths-20261019/apple'
OLD='/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019'
def read(p): return json.loads(p.read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value): (STAGE/name).write_text(json.dumps(value,indent=2)+'\n')
manifest=read(BASE/'current-source-manifest.json')
paths={x['path'] for x in manifest}
paths.add('tests/compute_models/mlx_affine_bitstream.h')
current={p:dict(path=p,bytes=(ROOT/p).stat().st_size,sha256=digest(ROOT/p)) for p in sorted(paths)}
old={x['path']:x['sha256'] for x in manifest}
records=read(BASE/'validation/control-retry1/compile-summary.json')
records.update(read(BASE/'validation/fixed/compile-summary.json'))
fresh={}
for rel,record in records.items():
    reasons=[]
    if current[rel]['sha256']!=record['source']['sha256']: reasons.append(rel)
    dep_remote=record['object']['path']+'.d'
    dep=BASE/'validation'/pathlib.PurePosixPath(dep_remote).relative_to(OLD)
    if not dep.exists():
        assert rel.endswith('.S'), rel
        if reasons: fresh[rel]=reasons
        continue
    text=dep.read_text().replace('\\\n',' ')
    for item in shlex.split(text.split(':',1)[1]):
        if item.startswith(OLD+'/current/'):
            name=posixpath.normpath(item[len(OLD+'/current/'):])
            assert name in current and name in old, name
            if name!=rel and old[name]!=current[name]['sha256']: reasons.append(name)
    if reasons: fresh[rel]=sorted(set(reasons))
before=read(STAGE/'before.json')
after=[]; diff=[]
for item in before:
    rel=item['path']; after.append(current.get(rel,dict(path=rel,bytes=(ROOT/rel).stat().st_size,sha256=digest(ROOT/rel))))
    p=STAGE/'source'/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes((ROOT/rel).read_bytes())
    diff.extend(difflib.unified_diff((STAGE/'before'/rel).read_text().splitlines(True),
        (ROOT/rel).read_text().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
(STAGE/'changes.diff').write_text(''.join(diff))
save('source-freeze.json',dict(before=before,after=after,
    public_header=current['include/hyle/compute/model_ops.h'],
    common_schema=current['src/compute_ops/weight_decode.cc'],
    independent_bit_writer=current['tests/compute_models/mlx_affine_bitstream.h']))
save('current-source-manifest.json',list(current.values()))
save('incremental-plan.json',dict(remote=REMOTE,base_remote=OLD,base_records=records,
    fresh=fresh,reused=[k for k in records if k not in fresh],
    test_compile=read(BASE/'validation/fixed/test-compile.command.json')['argv'],
    link=read(BASE/'validation/fixed/link.command.json')['argv']))
with tarfile.open(STAGE/'source.tar.gz','w:gz') as archive:
    for p in current: archive.add(ROOT/p,arcname='current/'+p)
    for name in ['run_incremental.py','incremental-plan.json','current-source-manifest.json']:
        archive.add(STAGE/name,arcname=name)
print(json.dumps(dict(fresh=len(fresh),reused=len(records)-len(fresh),
    sources=len(records),package_bytes=(STAGE/'source.tar.gz').stat().st_size,fresh_paths=list(fresh))))
