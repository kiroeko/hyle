import hashlib,json,pathlib,tarfile
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'checks').rglob('*') if p.is_file() and p.suffix in {'.json','.log','.xml','.d'}]
files += list(root.glob('build-run.*.log'))
cleanup=[]; retained=[]
for p in (root/'checks').rglob('*'):
    if not p.is_file() or not (p.suffix in {'.o','.a','.map','.metallib'} or p.name=='mlx-affine-width-tests'): continue
    row=dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    (cleanup if p.suffix in {'.map','.metallib'} or p.name=='mlx-affine-width-tests' else retained).append(row)
(root/'cleanup-plan.json').write_text(json.dumps(dict(targets=cleanup,retained_build_cache=retained,
    rule='Exact private image/map/metallib only; root writes test.ps1 before deletion. Shared native pair/SDK and current objects stay.'),indent=2)+'\n')
files.append(root/'cleanup-plan.json')
with tarfile.open(root/'proofs.tar.gz','w:gz') as archive:
    for p in files: archive.add(p,arcname=p.relative_to(root).as_posix())
print(json.dumps(dict(files=len(files),proof_bytes=(root/'proofs.tar.gz').stat().st_size,cleanup_bytes=sum(x['bytes'] for x in cleanup))))
