import hashlib,json,pathlib,shutil,tarfile,xml.etree.ElementTree as ET,zipfile
STAGE=pathlib.Path(__file__).resolve().parent
ROOT=STAGE.parents[3]
BASE=ROOT/'.scratch/architecture-refactor-2026-10-18/mlx-affine-contract'
DEST=ROOT/'docs/evidence/correctness/mlx-affine-widths-apple-2026-10-19.zip'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(b): return hashlib.sha256(b).hexdigest()
def save(name,value): (STAGE/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for row in read(STAGE/'final-freeze.json')['files']:
    b=(STAGE/row['path']).read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
summary=read(STAGE/'summary.json')
assert summary['exit']==0 and summary['tests_passed']==5 and summary['skipped']==0
xml=ET.parse(STAGE/'validation/checks/tests.xml').getroot()
assert xml.attrib['tests']=='5' and xml.attrib['failures']=='0' and not xml.findall('.//skipped')
plan=read(STAGE/'incremental-plan.json')
assert len(plan['fresh'])==12 and len(plan['reused'])==122
index={}
for rel,record in plan['base_records'].items():
    dep=pathlib.PurePosixPath(record['object']['path']+'.d').relative_to(plan['base_remote'])
    source=BASE/'validation'/dep
    if not source.exists():
        assert rel.endswith('.S'),rel
        index[rel]=dict(assembly_without_cpp_headers=True)
        continue
    target=STAGE/'baseline-deps'/dep
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.read_bytes())
    index[rel]=dict(path=target.relative_to(STAGE).as_posix(),sha256=sha(target.read_bytes()))
save('baseline-deps/index.json',index)
shutil.copy2(BASE/'current-source-manifest.json',STAGE/'baseline-deps/current-source-manifest.json')
with tarfile.open(STAGE/'source.tar.gz') as archive:
    for row in read(STAGE/'current-source-manifest.json'):
        b=archive.extractfile('current/'+row['path']).read()
        assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
save('archive-summary.json',dict(**summary,
    mathematical_scope='Only selected dyadic F32 code/scale/bias examples for5/g32,6/g64,8/g128 and retained affine4/MX neighbours plus BF16/F16 M1/M64 premature-narrowing witnesses. No general native F32 contraction/reduction bit parity, embedding two-RNE, all-artifact, Graph, full-model, performance or workspace claim.',
    dependency_scope='12 current owners refreshed by real source/header .d differences;122 old objects reused only after exact object SHA and dependency comparison. Baseline dependency files and current source snapshot included. Locked SDK and native host/metallib are referenced by identity, not copied.',
    cleanup='Existing validation/cleanup-plan.json is planning only. No product or test.ps1 edited for packaging.'))
skip={'remote-proofs.tar.gz','archive-receipt.json'}
payload=[p for p in STAGE.rglob('*') if p.is_file() and p.name not in skip
    and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.o','.obj','.a','.lib','.exe','.map','.pdb','.dll','.exp','.metallib','.cubin'}]
hashes={p.relative_to(STAGE).as_posix():sha(p.read_bytes()) for p in payload}
DEST.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in sorted(payload): archive.write(p,p.relative_to(STAGE).as_posix())
    archive.writestr('payload-sha256.json',json.dumps(hashes,indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist())==set(hashes)|{'payload-sha256.json'}
    for name,digest in hashes.items(): assert sha(archive.read(name))==digest
save('archive-receipt.json',dict(path=str(DEST),bytes=DEST.stat().st_size,sha256=sha(DEST.read_bytes()),
    payloads=len(hashes),crc_verified=True,payload_sha256_verified=True,tests=5,failures=0,skipped=0))
print(json.dumps(read(STAGE/'archive-receipt.json'),indent=2))
