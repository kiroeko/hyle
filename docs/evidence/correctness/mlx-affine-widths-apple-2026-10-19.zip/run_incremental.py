import concurrent.futures,hashlib,json,os,pathlib,shutil,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'incremental-plan.json').read_text())
OUT=ROOT/'checks'
OUT.mkdir(exist_ok=True)
(OUT/'objects').mkdir(exist_ok=True)
def ident(p):
    p=pathlib.Path(p); return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name,value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def run(tag,argv):
    with (OUT/(tag+'.stdout.log')).open('w') as stdout,(OUT/(tag+'.stderr.log')).open('w') as stderr:
        p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,cwd=ROOT)
        record=dict(argv=argv,pid=p.pid,started=time.time()); save(tag+'.command.json',record)
        record.update(exit=p.wait(),elapsed=time.time()-record['started']); save(tag+'.command.json',record)
    print(tag,record['exit'],round(record['elapsed'],2),flush=True)
    return record
for row in json.loads((ROOT/'current-source-manifest.json').read_text()):
    assert ident(ROOT/'current'/row['path'])['sha256']==row['sha256'],row['path']
records=PLAN['base_records']
for record in records.values(): assert ident(record['object']['path'])==record['object']
save('host.json',dict(pid=os.getpid(),hardware=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),
    clang=subprocess.check_output(['clang++','--version'],text=True).splitlines()[0]))
def remap(argv,target,source=None):
    argv=[a.replace(PLAN['base_remote']+'/current',str(ROOT/'current')) for a in argv]
    argv[argv.index('-o')+1]=str(target)
    if '-MF' in argv: argv[argv.index('-MF')+1]=str(target)+'.d'
    else: argv+=['-MMD','-MF',str(target)+'.d']
    if source: argv[argv.index('-c')+1]=str(ROOT/'current'/source)
    return argv
def compile_one(rel):
    target=OUT/'objects'/(rel.replace('/','--')+'.o')
    record=run('compile-'+rel.replace('/','--'),remap(records[rel]['argv'],target))
    record['source']=ident(ROOT/'current'/rel)
    if record['exit']==0: record['object']=ident(target)
    return rel,record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    fresh=dict(pool.map(compile_one,PLAN['fresh']))
save('fresh-compile-summary.json',fresh)
if any(r['exit'] for r in fresh.values()): raise SystemExit(2)
records.update(fresh)
save('complete-object-closure.json',records)
archive=OUT/'libcurrent-hyle.a'
if run('archive',['ar','rcs',str(archive)]+[x['object']['path'] for x in records.values()])['exit']: raise SystemExit(3)
test=OUT/'mlx-quantized-test.o'
if run('test-compile',remap(PLAN['test_compile'],test,'tests/compute_route_apple/mlx_quantized_test.cc'))['exit']: raise SystemExit(4)
image=OUT/'mlx-affine-width-tests'
argv=PLAN['link'][:]
for i,a in enumerate(argv):
    if a.endswith('/mlx-quantized-test.o'): argv[i]=str(test)
    elif a.endswith('/libcurrent-hyle.a'): argv[i]=str(archive)
    elif a.startswith('-Wl,-map,'): argv[i]='-Wl,-map,'+str(OUT/'mlx-affine-width-tests.map')
argv[argv.index('-o')+1]=str(image)
assert not any('libhyle' in a for a in argv)
if run('link',argv)['exit']: raise SystemExit(5)
native=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib')
shutil.copy2(native,OUT/'mlx.metallib')
save('native-pair.json',dict(metallib=ident(native),host=ident(native.parent/'native-host.f32.o')))
result=run('tests',[str(image),'--gtest_filter=AppleMlxQuantized.*','--gtest_output=xml:'+str(OUT/'tests.xml')])
save('summary.json',dict(exit=result['exit'],fresh=len(fresh),reused=len(records)-len(fresh),
    image=ident(image),test=ident(ROOT/'current/tests/compute_route_apple/mlx_quantized_test.cc'),
    provider=ident(ROOT/'current/src/compute_route_apple/apple_tensor.cc'),
    header=ident(ROOT/'current/include/hyle/compute/model_ops.h'),shared_sdk_rebuilt=False))
raise SystemExit(result['exit'])
