"""One explicit probe link; preserve the frozen parent recipes and two CXX results."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('native_program_frozen_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R


def main():
    plan, _ = b.validate()
    for name in ('link', 'ready.json', 'inputs.json', 'recipe-link-probe.json', 'link-refinement.json'):
        assert not (W / name).exists(), ('Single-use link output already exists', name)
    compiled = []; replacements = {}
    for unit in plan['units']:
        path = W / f"compile/{unit['name']}/compiled.json"
        record = t.read(path); actual = t.read(W / f"logs/{unit['name']}/process.json")
        assert record['process'] == actual and actual['state'] == 'TERMINAL'
        assert actual['exit'] == 0 and actual['timed_out'] is False, actual
        for field in ('source', 'object', 'command', 'dependencies', 'actual_project_dependencies'): t.exact(record[field])
        assert t.key(t.read(record['dependencies']['path'])['Data']['Source']) == t.key(unit['source'])
        replacements[t.key(unit['old_object']['path'])] = record['object']
        compiled.append(dict(unit=unit['name'], receipt=t.pin(path), record=record))
    assert len(compiled) == len(replacements) == 2

    # Prove the removed object by the original actual compiler Data.Source and
    # command, rather than treating every directory named entry as removable.
    inventory_path = R / '.scratch/inference-native-state-only-20261028/vulkan/inventory.json'
    inventory = t.read(inventory_path)
    entries = [row for row in inventory['vulkan'] if row.get('source') == 'engine/main.cc']
    assert len(entries) == 1
    entry = entries[0]; entry_deps = t.read(entry['dependencies'])
    assert t.key(entry_deps['Data']['Source']) == t.key(R / 'engine/main.cc')
    entry_command = t.command(entry['recipe'])
    assert sum(t.key(arg) == t.key(entry_deps['Data']['Source']) for arg in entry_command) == 1
    outputs = [arg[3:] for arg in entry_command if arg.lower().startswith('/fo')]
    assert len(outputs) == 1 and t.key(outputs[0]) == t.key(entry['object']['path'])
    t.exact(entry['object'])

    original_rows = t.read(plan['inputs']['path']); assert len(original_rows) == 170
    assert sum(t.key(row['path']) == t.key(entry['object']['path']) for row in original_rows) == 1
    assert t.key(entry['object']['path']) not in replacements
    rows = [replacements.get(t.key(row['path']), row) for row in original_rows
        if t.key(row['path']) != t.key(entry['object']['path'])]
    assert len(rows) == 169
    retained = [row for row in original_rows if t.key(row['path']) not in replacements
        and t.key(row['path']) != t.key(entry['object']['path'])]
    assert len(retained) == 167
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    original_recipe = t.command(plan['link']['path'])
    assert sum(t.key(arg) == t.key(entry['object']['path']) for arg in original_recipe) == 1
    command = [arg for arg in original_recipe if t.key(arg) != t.key(entry['object']['path'])]
    for row in rows: assert sum(t.key(arg) == t.key(row['path']) for arg in command) == 1, row['path']
    t.save(W / 'recipe-link-probe.json', dict(command=command, cwd=str(R), timeout_seconds=240))
    t.save(W / 'link-refinement.json', dict(status='PREPARED_AFTER_TWO_SUCCESSFUL_CXX', helper=t.pin(__file__),
        parent_plan=t.pin(W / 'plan.json'), source_freeze=t.pin(W / 'source-freeze.json'),
        original_recipe=plan['link'], original_inputs=plan['inputs'], recipe=t.pin(W / 'recipe-link-probe.json'),
        counts=dict(original_inputs=170, actual_inputs=169, retained_inputs=167, new_objects=2, removed_CLI_entries=1,
            additional_CXX=0, link_attempts_planned=1),
        removed_entry=dict(object=entry['object'], data_source=entry_deps['Data']['Source'],
            source=t.pin(R / 'engine/main.cc'), dependencies=t.pin(entry['dependencies']),
            actual_compile_recipe=t.pin(entry['recipe']), inventory=t.pin(inventory_path)),
        successful_compiles=[dict(unit=row['unit'], receipt=row['receipt'], object=row['record']['object'],
            process=row['record']['process']) for row in compiled], retained_stats=plan['retained_stats'],
        reason='Combined qwen_host_image_test.cc supplies main. Remove only the original engine/main.cc object; retain all other flags, SDK objects, libraries and both successful new objects.'))

    (W / 'bin').mkdir(exist_ok=True)
    t.save(W / 'inputs.json', rows)
    process = t.execute(command, W / 'link', 240)
    b.validate()
    for row in compiled: t.exact(row['record']['object'])
    runtime = t.read(plan['runtime']['path']); t.exact(runtime['native'])
    alias = Path(runtime['hardlink_on_link'])
    if not alias.exists(): os.link(runtime['native']['path'], alias)
    assert os.path.samefile(runtime['native']['path'], alias)
    t.save(W / 'ready.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=t.pin(W / 'inputs.json'),
        compiled=[row['record'] for row in compiled], process=process, recipe=t.pin(W / 'link/command.json'),
        plan=t.pin(W / 'plan.json'), source_freeze=t.pin(W / 'source-freeze.json'),
        refinement=t.pin(W / 'link-refinement.json'), runtime=plan['runtime'], native_hardlink=t.pin(alias), same_file=True,
        counts=dict(inputs=169, retained_inputs=167, new_objects=2, additional_CXX=0)))
    print('PROBE LINK READY: 169 inputs, 167 retained + two successful CXX; no model run')


if __name__ == '__main__': main()
