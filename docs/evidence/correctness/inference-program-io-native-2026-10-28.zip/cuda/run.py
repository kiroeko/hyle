"""Eight finite consumers; every launch is explicit and offline parsing never reruns one."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('native_program_cuda_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
ARMS = {f'{name}-{backend}': (backend, flag, case, checks) for name, flag, case, checks in (
    ('logits', '--mtp-logits', 'mtp-logits-modifiers', 10),
    ('history', '--history-logits', 'history-logits', 17),
    ('replay', '--history-replay', 'history-replay', 9),
    ('control', '--history-control', 'history-control', 2)) for backend in ('cpu', 'cuda')}


def prepare():
    plan = b.prepared()
    t.save(W / 'run-plan.json', dict(parser=t.pin(__file__), fixture=t.pin(FIXTURE / 'weights.tsv'),
        runtime=plan['runtime'], order=list(ARMS), actual_planned_model_processes=8,
        arms={arm: dict(backend=backend, flag=flag, case=case, state_checks=checks,
            command_arguments=['--' + backend, str(FIXTURE), flag], timeout_seconds=300)
            for arm, (backend, flag, case, checks) in ARMS.items()},
        scope='Existing cached synthetic GA/H64/V64/C16, one Model per process. '
            'Original modifier/history finite Graphs, strict history replay, cancellation and C0 lifetime consumers. '
            'No SDK/model/DLL payload copy, download, quality, throughput, or cross-backend bit-identity claim. '
            'A failed attempt keeps its raw logs; parse acts only on existing output.'))
    print('PREPARED eight finite CPU/CUDA commands; no consumer executed')


def parse(arm):
    backend, _, case, expected_checks = ARMS[arm]; out = W / 'runs' / arm
    process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
        if line.startswith('{')]
    by_case = {report['case']: report for report in reports}
    expected_cases = {case, 'history-finite-math'} if case == 'history-logits' else {case}
    assert len(reports) == len(by_case) and set(by_case) == expected_cases, (arm, [r.get('case') for r in reports])
    report = by_case[case]
    assert report['status'] == 'PASS' and report['backend'] == backend and report['models'] == 1
    assert report['configurations'] == (1 if case == 'history-control' else 2) and report['final_versions'] == 0
    assert report['quality_claim'] is False and report['performance_claim'] is False
    if case == 'mtp-logits-modifiers':
        assert report['finite_math_branches'] == 2 and report['numeric_q_failures'] == 2
        fields = ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
            'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage', 'prefix_frontier_numeric_failure',
            'new_prefix_policy_payload', 'strict_modifier_replay_rejected', 'historical_StateOnly_rebuild',
            'known_key_metadata_zero_native', 'same_key_retry', 'synthetic_untrained')
    elif case == 'history-logits':
        assert report['draft'] is True
        fields = ('K1_K2_greedy_random', 'derived_vs_manual_B2', 'StateOnly_no_counts_or_draw',
            'same_key_HostImage', 'full_hit_seed_before_frontier', 'synthetic_untrained')
        finite = by_case['history-finite-math']
        assert finite['backend'] == backend and finite['result'] == 'PASS'
        assert (finite['neutral_nodes'], finite['hand_rows'], finite['duplicate_prefix_ids']) == (0, 4, 2)
        for field in ('p_q_bonus', 'negative_counts_rejected', 'masked_raw_nan_rejected', 'masked_raw_inf_rejected',
            'masked_bias_nan_rejected', 'readonly_counts', 'normalized_q_unchanged', 'count_above_2pow24_exact',
            'int32_overflow_rejected', 'managed_commands'):
            assert finite[field] is True, field
    elif case == 'history-replay':
        fields = ('history_only', 'strict_K1_K2_greedy_random', 'StateOnly_history', 'HostImage_same_ledger',
            'post_replay_K1_K2', 'full_hit_explicit_C0', 'synthetic_untrained')
    else:
        fields = ('history_only', 'cancelled_B2_K2', 'whole_episode_retired', 'postsubmit_cancel_returned_normally',
            'peer_same_key_R1', 'committed_counts_only', 'escaped_readonly_C0', 'bounded_pool_refusal',
            'release_then_retry', 'idle_HostImage_restore', 'idle_resident_versions_zero', 'old_checkpoints_unchanged')
    for field in fields:
        assert report[field] is True, field
    checks = report['state_checks']; assert len(checks) == expected_checks, (arm, len(checks), expected_checks)
    for check in checks:
        assert check['boundary_equal'] is True and check['numerically_equivalent'] is True, check
        assert check['payloads_byte_equal'] is True and check['differences'] == [], check
    as_run = t.read(out / 'as-run.json')
    assert as_run['process'] == process and as_run['same_file'] is True
    # Retain all original report fields, including the separate finite math report.
    t.save(out / 'report.json', by_case)
    t.save(out / 'summary.json', dict(status='PASS', arm=arm, process=process, actual_state_checks=len(checks),
        complete_payloads_byte_equal=True, report=t.pin(out / 'report.json'),
        as_run=t.pin(out / 'as-run.json'), source_freeze=as_run['source_freeze'],
        quality_claim=False, performance_claim=False))
    print('PARSED PASS', arm, 'PID', process['pid'], 'state_checks', len(checks))


def run(arm):
    backend, flag, _, _ = ARMS[arm]
    plan, _ = b.validate(); run_plan = t.read(W / 'run-plan.json')
    for field in ('parser', 'fixture', 'runtime'):
        t.exact(run_plan[field])
    assert run_plan['runtime'] == plan['runtime'] and run_plan['order'] == list(ARMS)
    ready = t.read(W / 'ready-tiny.json')
    for field in ('image', 'inputs', 'plan', 'source_freeze'):
        t.exact(ready[field])
    assert ready['plan'] == t.pin(W / 'plan.json') and ready['source_freeze'] == t.pin(W / 'source-freeze.json')
    runtime = t.read(plan['runtime']['path']); native = runtime['native']; t.exact(native)
    alias = W / 'bin' / Path(native['path']).name
    if not alias.exists():
        os.link(native['path'], alias)
    assert os.path.samefile(native['path'], alias), 'The runtime DLL must be the retained same-file hardlink'
    out = W / 'runs' / arm
    assert not out.exists(), 'Already attempted; preserve logs and use parse instead of rerunning'
    identity = dict(ready=t.pin(W / 'ready-tiny.json'), image=ready['image'], inputs=ready['inputs'],
        source_freeze=ready['source_freeze'], plan=t.pin(W / 'run-plan.json'), environment=plan['environment'],
        fixture=run_plan['fixture'], native=native, native_hardlink=t.pin(alias), same_file=True,
        offline=dict(HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1'))
    try:
        t.execute([ready['image']['path'], '--' + backend, str(FIXTURE), flag], out, 300)
    finally:
        if out.is_dir():
            terminal = out / 'process.json'; running = out / 'running.json'
            t.save(out / 'as-run.json', dict(**identity,
                process=t.read(terminal) if terminal.is_file() else None,
                running=t.read(running) if running.is_file() else None))
    parse(arm)


def summary():
    results = []
    for arm in ARMS:
        path = W / 'runs' / arm / 'summary.json'; item = t.read(path)
        assert item['status'] == 'PASS' and item['arm'] == arm
        results.append(dict(arm=arm, process=item['process'], actual_state_checks=item['actual_state_checks'],
            summary=t.pin(path)))
    t.save(W / 'run-summary.json', dict(status='PASS', actual_model_processes=len(results), arms=results,
        complete_payloads_byte_equal=True, quality_claim=False, performance_claim=False))
    print('PASS eight finite processes; no performance or quality claim')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    elif action == 'summary': summary()
    else: raise ValueError(action)
