"""Thin Windows CPU/Vulkan consumer; actions are explicit and single-use."""
from pathlib import Path
import importlib.util
import json
import os
import re
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-native-state-only-20261028/vulkan'
spec = importlib.util.spec_from_file_location('native_program_original_runner', BASE / 'build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
t.W, t.R = W, R
SOURCES = {'tiny': 'tests/tools/qwen_host_image_test.cc', 'weights': 'engine/models/qwen35/weights.cc'}


def sdk_boundary():
    changed = subprocess.check_output(['git', 'diff', '--name-only', '4974345de', '--', 'include', 'src'], cwd=R, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'include', 'src'], cwd=R, text=True).splitlines()
    assert not changed and not untracked, ('SDK changed; retained boundary needs review', changed, untracked)
    return dict(base='4974345de', tracked_changes=changed, untracked=untracked,
        scope='Actual source/include delta is empty. Engine-private changes compile in Tiny and weights; this is not a blanket ABI exemption.')


def prepare():
    assert not (W / 'plan.json').exists()
    old = t.read(BASE / 'ready.json'); t.exact(old['inputs'])
    rows = t.read(old['inputs']['path']); assert len(rows) == 170
    compiled = {x['unit']['name']: x for x in old['compiled']}
    mapping = {}; units = []
    for name, source in SOURCES.items():
        before = compiled['model' if name == 'tiny' else name]
        deps = Path(before['object']['path']).parent / 'dependencies.json'
        data = t.read(deps)['Data']
        assert t.key(data['Source']) == t.key(before['source']['path'])
        command = []; original = t.command(before['command']['path'])
        for at, arg in enumerate(original):
            if t.key(arg) == t.key(data['Source']): arg = str(R / source)
            elif at and original[at - 1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            command.append(arg)
        assert '/MD' in command and '/O2' in command
        assert '/DHYLE_COMPUTE_CPU=1' in command and '/DHYLE_COMPUTE_VULKAN=1' in command
        assert not any('HYLE_COMPUTE_CUDA' in x or 'HYLE_COMPUTE_APPLE' in x for x in command)
        t.save(W / f'recipes/{name}.json', dict(command=command, cwd=str(R), timeout_seconds=300))
        mapping[t.key(before['object']['path'])] = str(W / f'compile/{name}/unit.obj')
        units.append(dict(name=name, source=str(R / source), old_object=before['object'],
            old_command=before['command'], old_dependencies=t.pin(deps), recipe=t.pin(W / f'recipes/{name}.json')))
    link = []
    for arg in t.command(old['recipe']['path']):
        arg = mapping.get(t.key(arg), arg)
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map'), ('/ILK:', '.ilk')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    assert all(sum(t.key(arg) == t.key(path) for arg in link) == 1 for path in mapping.values())
    t.save(W / 'recipe-link.json', dict(command=link, cwd=str(R), timeout_seconds=240))
    retained = [row for row in rows if t.key(row['path']) not in mapping]; assert len(retained) == 168
    stats = []
    for row in retained:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    t.save(W / 'retained-input-stats.json', stats)
    t.save(W / 'environment.json', t.read(BASE / 'environment.json'))
    runtime = t.read(BASE / 'runtime.json')
    runtime['PATH'] = str(W / 'bin') + ';' + runtime['PATH']
    runtime['hardlink_on_link'] = str(W / 'bin' / Path(runtime['native']['path']).name)
    t.save(W / 'runtime.json', runtime)
    fixture = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    t.save(W / 'plan.json', dict(status='PREPARED_UNFROZEN', baseline=t.pin(BASE / 'ready.json'), inputs=old['inputs'],
        sdk_boundary=sdk_boundary(), units=units, retained_stats=t.pin(W / 'retained-input-stats.json'),
        old_link=old['recipe'], link=t.pin(W / 'recipe-link.json'), original_runner=t.pin(BASE / 'build.py'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        fixture=str(fixture), fixture_manifest=t.pin(fixture / 'weights.tsv'),
        counts=dict(CXX=2, links=1, inputs=170, unchanged_inputs=168, SDK_CXX=0, NVCC=0, downloads=0),
        policy='Canonical sources preserve original quoted-include lookup; no source, SDK, weights or runtime DLL payload copy. No source freeze is implied by prepare.'))
    print('PREPARED UNFROZEN: Tiny + weights, 170 inputs, four finite Vulkan consumers')


def prepared():
    plan = t.read(W / 'plan.json')
    for field in ('baseline', 'inputs', 'retained_stats', 'link', 'original_runner', 'environment', 'runtime', 'fixture_manifest'): t.exact(plan[field])
    for unit in plan['units']:
        for field in ('old_command', 'old_dependencies', 'recipe'): t.exact(unit[field])
    return plan


def freeze():
    plan = prepared(); expected = t.read(W / 'expected-sources.json')
    assert set(SOURCES.values()) | {'engine/models/qwen35/main.cc', 'engine/inference/sampling_graph.h'} <= set(expected)
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    sdk_boundary()
    # Pin only the reachable project dependency closure. Snapshot authored files
    # only; installed SDK/system headers and third-party payloads are not copied.
    known = {}; pending = [R / relative for relative in expected]
    roots = [R, R / 'include', R / 'engine']
    for unit in plan['units']:
        pending.extend(Path(p) for p in t.depfiles(unit['old_dependencies']['path']) if t.project(p))
        roots.extend(Path(arg[2:]) for arg in t.command(unit['recipe']['path']) if arg.lower().startswith('/i'))
    while pending:
        path = pending.pop().resolve(); k = t.key(path)
        if k in known: continue
        assert t.project(path), path
        known[k] = t.pin(path)
        for include in re.findall(r'^\s*#\s*include\s*[<"]([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((p.resolve() for root in [path.parent, *roots] if (p := root / include).is_file()), None)
            if found and t.project(found): pending.append(found)
    t.save(W / 'project-dependencies.json', list(known.values()))
    snapshots = []
    for relative in expected:
        source, target = R / relative, W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / 'source-freeze.json', dict(expected=t.pin(W / 'expected-sources.json'), helper=t.pin(__file__),
        plan=t.pin(W / 'plan.json'), sdk_boundary=sdk_boundary(), snapshots=snapshots,
        project_dependencies=t.pin(W / 'project-dependencies.json')))
    print('FROZEN; no compilation started')


def validate():
    plan = prepared(); frozen = t.read(W / 'source-freeze.json')
    for field in ('expected', 'helper', 'plan', 'project_dependencies'): t.exact(frozen[field])
    for row in frozen['snapshots']: t.exact(row['original']); t.exact(row['snapshot'])
    sdk_boundary()
    return plan, frozen


def parse_compile(name):
    plan, frozen = validate(); unit = next(x for x in plan['units'] if x['name'] == name)
    out = W / 'compile' / name; proc = t.read(W / f'logs/{name}/process.json')
    assert proc['exit'] == 0 and not proc['timed_out']
    known = {t.key(row['path']): row for row in t.read(frozen['project_dependencies']['path'])}; actual = []
    for path in t.depfiles(out / 'dependencies.json'):
        if t.project(path):
            assert t.key(path) in known, ('Successful CXX: missing prepin is metadata-only; do not rerun CXX', path)
            t.exact(known[t.key(path)]); actual.append(known[t.key(path)])
    t.save(out / 'actual-project-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(unit['source']), object=t.pin(out / 'unit.obj'), process=proc,
        command=t.pin(W / f'logs/{name}/command.json'), dependencies=t.pin(out / 'dependencies.json'),
        actual_project_dependencies=t.pin(out / 'actual-project-dependencies.json')))
    print('CXX PARSED', name)


def compile_one(name):
    plan, frozen = validate(); unit = next(x for x in plan['units'] if x['name'] == name)
    for row in t.read(frozen['project_dependencies']['path']): t.exact(row)
    (W / 'compile' / name).mkdir(parents=True, exist_ok=False)
    t.execute(t.command(unit['recipe']['path']), W / 'logs' / name, 300)
    parse_compile(name)


def link():
    plan, _ = validate(); rows = t.read(plan['inputs']['path']); compiled = []
    for unit in plan['units']:
        current = t.read(W / f"compile/{unit['name']}/compiled.json"); t.exact(current['object']); compiled.append(current)
        matches = [at for at, row in enumerate(rows) if t.key(row['path']) == t.key(unit['old_object']['path'])]
        assert len(matches) == 1; rows[matches[0]] = current['object']
    assert len(rows) == 170
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns'])
    (W / 'bin').mkdir(exist_ok=True); t.save(W / 'inputs.json', rows)
    proc = t.execute(t.command(plan['link']['path']), W / 'link', 240)
    runtime = t.read(plan['runtime']['path']); t.exact(runtime['native'])
    alias = Path(runtime['hardlink_on_link']); assert not alias.exists()
    os.link(runtime['native']['path'], alias); assert os.path.samefile(runtime['native']['path'], alias)
    t.save(W / 'ready.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=t.pin(W / 'inputs.json'), compiled=compiled,
        process=proc, recipe=t.pin(W / 'link/command.json'), plan=t.pin(W / 'plan.json'),
        source_freeze=t.pin(W / 'source-freeze.json'), runtime=plan['runtime'], native_hardlink=t.pin(alias), same_file=True))
    print('LINK READY; no model process started')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'parse-compile': parse_compile(sys.argv[2])
    elif action == 'link': link()
    else: raise ValueError(action)
