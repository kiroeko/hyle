param(
    [switch]$Execute,
    [string]$EvidenceArchive,
    [string]$EvidenceSha256
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$taskRepo = 'C:\public\project-hyle\hyle'
$taskWork = Join-Path $taskRepo '.scratch\inference-native-program-io-20261028'
$taskScratch = [IO.Path]::GetFullPath((Join-Path $taskRepo '.scratch'))
$inventoryPath = Join-Path $taskWork 'cleanup-inventory.json'
$inventorySha256 = 'f41f99b184a54ce61a2e0b61394667a6da69cf9d41ac47616ad844a092446513'
$receiptPath = Join-Path $taskWork 'cleanup-executed.json'

# This proposal never removes directories or follows a reparse point.
function Get-CheckedFile([string]$Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    $item = Get-Item -LiteralPath $absolute -Force
    if ($item.PSIsContainer -or $item.PSProvider.Name -ne 'FileSystem') { throw "Not a regular file: $absolute" }
    for ($cursor = $item; $null -ne $cursor; $cursor = $cursor.Parent) {
        if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse point: $($cursor.FullName)" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory; if ($null -eq $cursor) { break } }
        if (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse ancestor: $($cursor.FullName)" }
    }
    return $item
}

function Assert-Pin($Pin, [bool]$HashBody = $true) {
    $item = Get-CheckedFile ([string]$Pin.path)
    if ($item.Length -ne [long]$Pin.bytes) { throw "Size changed: $($item.FullName)" }
    if ($HashBody -and (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash -ne [string]$Pin.sha256) {
        throw "SHA256 changed: $($item.FullName)"
    }
    return $item
}

function Read-JsonPin($Pin) {
    $item = Assert-Pin $Pin
    return Get-Content -LiteralPath $item.FullName -Raw | ConvertFrom-Json
}

$inventoryFile = Get-CheckedFile $inventoryPath
if ((Get-FileHash -LiteralPath $inventoryFile.FullName -Algorithm SHA256).Hash -ne $inventorySha256) { throw 'Inventory SHA256 changed' }
$inventory = Get-Content -LiteralPath $inventoryFile.FullName -Raw | ConvertFrom-Json
if ($inventory.candidate_count -ne 11 -or $inventory.candidate_total_bytes -ne 330308454 -or @($inventory.candidates).Count -ne 11) { throw 'Inventory count/total changed' }
if (@($inventory.protected_closures).Count -ne 7) { throw 'Expected seven protection closures' }
if ($Execute -and (Test-Path -LiteralPath $receiptPath)) { throw "Execution receipt already exists: $receiptPath" }

$protectedPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
function Protect-File([string]$Path) {
    $item = Get-CheckedFile $Path
    [void]$protectedPaths.Add($item.FullName)
}

# Read current metadata and actual link inputs. SDK/object/image bodies are
# size-checked, not rehashed; each small manifest/recipe/source receipt is pinned.
foreach ($closure in $inventory.protected_closures) {
    $ready = Read-JsonPin $closure.ready
    Protect-File $closure.ready.path
    if ($ready.inputs.path -ne $closure.inputs.path -or $ready.inputs.sha256 -ne $closure.inputs.sha256 -or
        $ready.recipe.path -ne $closure.recipe.path -or $ready.recipe.sha256 -ne $closure.recipe.sha256) { throw "Protection metadata changed: $($closure.name)" }
    $inputs = @(Read-JsonPin $closure.inputs)
    $recipe = Read-JsonPin $closure.recipe
    Protect-File $closure.inputs.path
    Protect-File $closure.recipe.path
    if ($inputs.Count -ne $closure.input_count) { throw "Input count changed: $($closure.name)" }
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($inputPin in $inputs) {
        $item = Assert-Pin $inputPin $false
        if (-not $seen.Add($item.FullName)) { throw "Duplicate input: $($item.FullName)" }
        $matches = @($recipe.command | Where-Object { ([string]$_).Replace('/', '\').Equals($item.FullName, [StringComparison]::OrdinalIgnoreCase) })
        if ($matches.Count -ne 1) { throw "Input not unique in actual link command: $($item.FullName)" }
        [void]$protectedPaths.Add($item.FullName)
    }
    $image = Assert-Pin $ready.image $false
    if ($ready.image.path -ne $closure.image.path -or $ready.image.sha256 -ne $closure.image.sha256) { throw "Protected image identity changed: $($closure.name)" }
    [void]$protectedPaths.Add($image.FullName)
    if ($ready.PSObject.Properties.Name -contains 'source_freeze') {
        $null = Read-JsonPin $ready.source_freeze
        Protect-File $ready.source_freeze.path
    }
    # Frozen source copies remain protected. Canonical source metadata records
    # historical compilation identity, so it is not requalified as current code.
    foreach ($compiled in @($ready.compiled)) {
        foreach ($field in 'source', 'canonical_source', 'snapshot') {
            if ($compiled.PSObject.Properties.Name -contains $field) {
                Protect-File $compiled.$field.path
            }
        }
    }
}
foreach ($kept in $inventory.preserved_original_vulkan_objects) {
    $item = Assert-Pin $kept.object $false
    if (-not $protectedPaths.Contains($item.FullName)) { throw "Reusable original object missing from protected inputs: $($item.FullName)" }
}

$evidence = $null
if ($EvidenceArchive -or $EvidenceSha256) {
    if (-not $EvidenceArchive -or $EvidenceSha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Supply both archive path and exact SHA256' }
    $archive = Get-CheckedFile $EvidenceArchive
    $archiveHash = (Get-FileHash -LiteralPath $archive.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($archiveHash -ne $EvidenceSha256.ToLowerInvariant()) { throw 'Evidence archive SHA256 changed' }
    $evidence = @{ path = $archive.FullName; bytes = $archive.Length; sha256 = $archiveHash }
    [void]$protectedPaths.Add($archive.FullName)
}

$targets = @()
$targetPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$total = 0L
foreach ($pin in $inventory.candidates) {
    $item = Assert-Pin $pin
    if (-not $item.FullName.StartsWith($taskScratch + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Target outside repository .scratch: $($item.FullName)" }
    if ($item.Extension -notin '.exe', '.exp', '.lib', '.obj') { throw "Forbidden target type: $($item.FullName)" }
    if ($item.FullName -ne $pin.resolved_absolute_path -or -not $targetPaths.Add($item.FullName)) { throw 'Target path changed or duplicated' }
    if ($protectedPaths.Contains($item.FullName)) { throw "Live protected target: $($item.FullName)" }
    $targets += @{ path = $item.FullName; bytes = $item.Length; sha256 = $pin.sha256 }
    $total += $item.Length
}
if ($targets.Count -ne 11 -or $total -ne 330308454) { throw 'Verified target count/total mismatch' }

$receipt = [ordered]@{
    status = 'PREVIEW'; inventory = @{ path = $inventoryPath; sha256 = $inventorySha256 }
    targets = $targets; count = $targets.Count; bytes = $total
    protected_closures = @($inventory.protected_closures | ForEach-Object { @{ name = $_.name; ready = $_.ready; input_count = $_.input_count } })
    protected_path_count = $protectedPaths.Count; protected_intersection = 0
    evidence_archive = $evidence; removed = @(); started_utc = [DateTime]::UtcNow.ToString('o')
}
if (-not $Execute) {
    $receipt | ConvertTo-Json -Depth 12
    return
}

# The once-only receipt is created before the first removal, after all targets
# and closures passed. Partial failure remains recorded and is never auto-retried.
$receipt.status = 'EXECUTING'
[IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
try {
    foreach ($target in $targets) {
        Remove-Item -LiteralPath $target.path -Force
        $receipt.removed += $target
    }
    $receipt.status = 'DELETED'
} catch {
    $receipt.status = 'FAILED_AFTER_PARTIAL_DELETE'
    $receipt.error = $_.Exception.Message
    throw
} finally {
    $receipt.finished_utc = [DateTime]::UtcNow.ToString('o')
    [IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
}
$receipt | ConvertTo-Json -Depth 12
