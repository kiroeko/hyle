"""Root-invoked Apple actions, reusing the existing original process recorder."""
from pathlib import Path
import importlib.util
import json
import os
import shlex
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())
spec = importlib.util.spec_from_file_location('original_native_recorder', P['original_remote_driver'])
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); b.W = W


def read(path): return json.loads(Path(path).read_text())
def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')
def exact(row):
    current = b.pin(row['path'])
    assert (current['bytes'], current['sha256']) == (row['bytes'], row['sha256']), row['path']
def verify():
    frozen = read(W / 'source-freeze.json')
    current_driver = b.pin(__file__)
    assert (current_driver['bytes'], current_driver['sha256']) == (frozen['remote_driver']['bytes'], frozen['remote_driver']['sha256'])
    for row in frozen['sources']:
        current = b.pin(W / 'source' / row['path'])
        assert (current['bytes'], current['sha256']) == (row['bytes'], row['sha256']), row['path']
    assert b.pin(P['native_header']['path'])['sha256'] == P['native_header']['sha256']
    return frozen


def preflight():
    verify(); originals = {u['old_object']['path'] for u in P['units']} | {P['removed_entry']['object']}; stats = []
    for row in P['old_inputs']:
        if row['path'] in originals: continue
        current = b.stat(row['path']); assert current['bytes'] == row['bytes'], row['path']
        prior = row.get('current_stat', row)
        if 'mtime_ns' in prior: assert current['mtime_ns'] == prior['mtime_ns'], row['path']
        stats.append(current)
    assert len(stats) == 118
    save(W / 'preflight.json', dict(status='PASS', retained_stats=stats, inputs=120,
        header=b.pin(P['native_header']['path']), runtime=P['runtime'],
        note='Recorded actual archive/object identities retained; stat checked, no SDK payload rehash or rebuild.'))
    print('PREFLIGHT PASS')


def compile_one(name):
    frozen = verify(); assert (W / 'preflight.json').is_file()
    unit = next(x for x in P['units'] if x['name'] == name)
    out = W / 'compile' / name; out.mkdir(parents=True, exist_ok=False)
    process = b.execute(unit['command'], out / 'logs', 300)
    verify(); text = (out / 'dependencies.d').read_text().replace('\\\n', '')
    actual = []
    for value in dict.fromkeys(shlex.split(text.split(':', 1)[1])):
        path = Path(value); path = path if path.is_absolute() else W / path
        row = b.pin(path) if path.is_relative_to(W / 'source') else b.stat(path)
        if path.name == 'apple_carrier.h':
            assert str(path) == P['native_header']['path'], ('Wrong old carrier selected', str(path))
            assert b.pin(path)['sha256'] == P['native_header']['sha256']
        actual.append(row)
    save(out / 'actual-dependencies.json', actual)
    save(out / 'compiled.json', dict(source=next(row for row in frozen['sources'] if row['path'] == unit['source']),
        object=b.pin(unit['object']), process=process, command=b.pin(out / 'logs/command.json'),
        dependencies=b.pin(out / 'dependencies.d'), actual_dependencies=b.pin(out / 'actual-dependencies.json')))
    print('CXX PASS', name)


def link():
    verify(); compiled = {}; replacements = {}
    for unit in P['units']:
        record = read(W / 'compile' / unit['name'] / 'compiled.json'); exact(record['object'])
        compiled[unit['name']] = record; replacements[unit['old_object']['path']] = record['object']
    for row in read(W / 'preflight.json')['retained_stats']: assert b.stat(row['path']) == row
    inputs = [replacements.get(row['path'], row) for row in P['old_inputs'] if row['path'] != P['removed_entry']['object']]
    assert len(inputs) == 120
    (W / 'bin').mkdir(exist_ok=True)
    process = b.execute(P['link_command'], W / 'link/logs', 240)
    save(W / 'inputs.json', inputs)
    save(W / 'ready.json', dict(image=b.pin(W / 'bin/tiny'), inputs=b.pin(W / 'inputs.json'),
        compiled=compiled, process=process, recipe=b.pin(W / 'link/logs/command.json'),
        plan=b.pin(W / 'plan.json'), source_freeze=b.pin(W / 'source-freeze.json'), runtime=P['runtime']))
    print('LINK READY')


def run(arm):
    verify(); ready = read(W / 'ready.json'); exact(ready['image']); exact(ready['inputs']); exact(ready['source_freeze'])
    flag = P['arms'][arm]; saved = {key: os.environ.get(key) for key in P['runtime']}
    os.environ.update(P['runtime']); out = W / 'runs' / arm
    assert not out.exists(), 'Already attempted; no automatic rerun'
    try:
        b.execute([ready['image']['path'], '--apple', P['fixture'], flag], out, 300)
    finally:
        if (out / 'process.json').is_file():
            save(out / 'as-run.json', dict(image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'],
                runtime_overrides=P['runtime'], inherited_environment_whitelist={key: os.environ[key] for key in
                    ('PATH', 'DYLD_LIBRARY_PATH', 'DYLD_FALLBACK_LIBRARY_PATH', 'HOME', 'TMPDIR') if key in os.environ},
                process=read(out / 'process.json')))
        for key, value in saved.items():
            if value is None: os.environ.pop(key, None)
            else: os.environ[key] = value


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'preflight': preflight()
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'link': link()
    elif action == 'run': run(sys.argv[2])
    else: raise ValueError(action)
