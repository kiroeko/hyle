"""Two current ABI readers, original owner/consumer objects, bounded archive replacement."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())
spec = importlib.util.spec_from_file_location('original_native_recorder', P['original_remote_driver'])
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); b.W = W


def read(path): return json.loads(Path(path).read_text())
def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')
def exact(row):
    actual = b.pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def verify():
    frozen = read(W / 'source-freeze.json'); actual = b.pin(__file__)
    assert (actual['bytes'], actual['sha256']) == (frozen['remote_driver']['bytes'], frozen['remote_driver']['sha256'])
    for row in frozen['sources']:
        actual = b.pin(W / 'source' / row['path'])
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
    guard = b.pin(W / 'abi_size_guard.h'); assert (guard['bytes'], guard['sha256']) == (frozen['guard']['bytes'], frozen['guard']['sha256'])
    assert b.pin(P['native_header']['path'])['sha256'] == P['native_header']['sha256']
    old = b.pin(P['previous_ready']['remote']); original = P['previous_ready']['local']
    assert (old['bytes'], old['sha256']) == (original['bytes'], original['sha256'])
    assert read(P['previous_ready']['remote']) == P['previous_ready']['record']
    for record in P['previous_ready']['record']['compiled'].values():
        assert record['process']['exit'] == 0 and record['process']['timeout'] is False
        exact(record['object'])
    exact(P['resources'])
    return frozen


def members(archive):
    listing = subprocess.check_output(['/usr/bin/ar', '-t', str(archive)], text=True).splitlines()
    names = [name for name in listing if not name.startswith('__.SYMDEF') and name not in ('/', '//', '/SYM64/')]
    assert names and len(names) == len(set(names)), listing
    rows = []
    for name in names:
        data = subprocess.check_output(['/usr/bin/ar', '-p', str(archive), name])
        rows.append(dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    return listing, rows


def preflight():
    verify(); exact(P['old_progress_archive']); stats = []
    replaced = {P['old_submission']['path'], P['old_progress_archive']['path']}
    for row in P['old_inputs']:
        if row['path'] in replaced: continue
        actual = b.stat(row['path']); assert actual['bytes'] == row['bytes'], row['path']
        previous = row.get('current_stat', row)
        if 'mtime_ns' in previous: assert actual['mtime_ns'] == previous['mtime_ns'], row['path']
        stats.append(actual)
    assert len(stats) == 118
    listing, original_members = members(P['old_progress_archive']['path'])
    candidates = [row for row in original_members if re.fullmatch(r'progress(?:\.cc|\.cpp)?\.o', Path(row['name']).name)]
    assert len(candidates) == 1, ('Progress member must be identified; no CXX started', listing)
    target = candidates[0]; assert target['name'] == Path(target['name']).name
    mode = 'single_member_to_direct_object' if len(original_members) == 1 else 'replace_one_member_preserve_others'
    replacement = P['units'][1]['object'] if len(original_members) == 1 else str(W / 'lib/libhyle_graph_progress_refined.a')
    save(W / 'archive-admission.json', dict(archive=b.pin(P['old_progress_archive']['path']),
        ar_command=['/usr/bin/ar', '-t', P['old_progress_archive']['path']], actual_listing=listing,
        original_members=original_members, progress_member=target, mode=mode, replacement=replacement))
    save(W / 'preflight.json', dict(status='PASS', retained_stats=stats, inputs=120,
        archive_admission=b.pin(W / 'archive-admission.json'), abi_headers=P['abi_headers'],
        retained_consumers=P['previous_ready']['record']['compiled']))
    print('PREFLIGHT PASS; progress archive mode:', mode)


def compile_one(name):
    verify(); assert (W / 'preflight.json').is_file()
    unit = next(unit for unit in P['units'] if unit['name'] == name)
    out = W / 'compile' / name; out.mkdir(parents=True, exist_ok=False)
    process = b.execute(unit['command'], out / 'logs', 300)
    verify(); raw = (out / 'dependencies.d').read_text().replace('\\\n', '')
    actual = []; seen_abi = set()
    for value in dict.fromkeys(shlex.split(raw.split(':', 1)[1])):
        path = Path(value); path = path if path.is_absolute() else W / path
        row = b.pin(path) if path.is_relative_to(W / 'source') else b.stat(path)
        for abi in P['abi_headers']:
            if str(path).endswith('/' + abi['path']):
                assert path == W / 'source' / abi['path'], ('Older ABI header selected', str(path))
                assert (row['bytes'], row['sha256']) == (abi['bytes'], abi['sha256'])
                seen_abi.add(abi['path'])
        if path.name == 'apple_carrier.h':
            assert str(path) == P['native_header']['path'] and b.pin(path)['sha256'] == P['native_header']['sha256']
        actual.append(row)
    assert 'include/hyle/graph/detail/region_access.h' in seen_abi
    save(out / 'actual-dependencies.json', actual)
    save(out / 'compiled.json', dict(source=unit['source'], object=b.pin(unit['object']), process=process,
        command=b.pin(out / 'logs/command.json'), actual_dependencies=b.pin(out / 'actual-dependencies.json'),
        verified_ABI_headers=sorted(seen_abi), ordered_pointer_count=5, ordered_arm64_bytes=40))
    print('CXX PASS', name)


def link():
    verify(); compiled = {}
    for unit in P['units']:
        record = read(W / 'compile' / unit['name'] / 'compiled.json'); exact(record['object'])
        assert record['process']['exit'] == 0 and record['process']['timeout'] is False
        compiled[unit['name']] = record
    for row in read(W / 'preflight.json')['retained_stats']: assert b.stat(row['path']) == row
    admission = read(W / 'archive-admission.json'); exact(admission['archive'])
    replacement = compiled['progress']['object']
    if admission['mode'] == 'replace_one_member_preserve_others':
        destination = Path(admission['replacement']); destination.parent.mkdir(parents=True, exist_ok=True)
        assert not destination.exists(); shutil.copyfile(admission['archive']['path'], destination)
        member = W / 'archive-member' / admission['progress_member']['name']; member.parent.mkdir(exist_ok=True)
        assert not member.exists(); shutil.copyfile(compiled['progress']['object']['path'], member)
        b.execute(['/usr/bin/ar', '-r', str(destination), str(member)], W / 'archive-replace/logs', 120)
        listing, after = members(destination); before = {row['name']: row for row in admission['original_members']}
        assert set(row['name'] for row in after) == set(before)
        for row in after:
            expected = compiled['progress']['object'] if row['name'] == admission['progress_member']['name'] else before[row['name']]
            assert (row['bytes'], row['sha256']) == (expected['bytes'], expected['sha256'])
        save(W / 'archive-replacement.json', dict(mode=admission['mode'], actual_listing=listing, members=after,
            original_archive=admission['archive'], refined_archive=b.pin(destination), unrelated_members_unchanged=True))
        replacement = b.pin(destination)
    else:
        assert len(admission['original_members']) == 1
        save(W / 'archive-replacement.json', dict(mode=admission['mode'], old_archive=admission['archive'],
            original_members=admission['original_members'], replacement=replacement))
    command = [replacement['path'] if arg == '@PROGRESS_REPLACEMENT@' else arg for arg in P['link_template']]
    rows = [compiled['submission']['object'] if row['path'] == P['old_submission']['path'] else
        replacement if row['path'] == P['old_progress_archive']['path'] else row for row in P['old_inputs']]
    assert len(rows) == 120
    for row in rows: assert command.count(row['path']) == 1, row['path']
    (W / 'bin').mkdir(exist_ok=True)
    save(W / 'recipe-link.json', dict(command=command, inputs=120, archive_mode=admission['mode']))
    process = b.execute(command, W / 'link/logs', 240)
    save(W / 'inputs.json', rows)
    save(W / 'ready.json', dict(image=b.pin(W / 'bin/tiny'), inputs=b.pin(W / 'inputs.json'), compiled=compiled,
        retained_consumers=P['previous_ready']['record']['compiled'], process=process,
        recipe=b.pin(W / 'link/logs/command.json'), source_freeze=b.pin(W / 'source-freeze.json'),
        plan=b.pin(W / 'plan.json'), runtime=P['runtime'], archive_replacement=b.pin(W / 'archive-replacement.json'),
        counts=dict(CXX=2, links=1, inputs=120, retained=118)))
    print('LINK READY; successful Tiny/weights were retained')


def run(arm):
    verify(); ready = read(W / 'ready.json')
    for field in ('image', 'inputs', 'source_freeze'): exact(ready[field])
    saved = {key: os.environ.get(key) for key in P['runtime']}; os.environ.update(P['runtime'])
    out = W / 'runs' / arm; assert not out.exists(), 'Already attempted; no automatic rerun'
    try: b.execute([ready['image']['path'], '--apple', P['fixture'], P['arms'][arm]], out, 300)
    finally:
        if (out / 'process.json').is_file():
            save(out / 'as-run.json', dict(image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'],
                runtime_overrides=P['runtime'], inherited_environment_whitelist={key: os.environ[key] for key in
                    ('PATH', 'DYLD_LIBRARY_PATH', 'DYLD_FALLBACK_LIBRARY_PATH', 'HOME', 'TMPDIR') if key in os.environ},
                process=read(out / 'process.json')))
        for key, value in saved.items():
            if value is None: os.environ.pop(key, None)
            else: os.environ[key] = value


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'preflight': preflight()
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'link': link()
    elif action == 'run': run(sys.argv[2])
    else: raise ValueError(action)
