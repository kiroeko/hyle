"""Two SDK ABI consumers only; retain the successful Tiny and weights objects."""
from pathlib import Path
import importlib.util
import re
import sys
import tarfile
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
APPLE = W.parent
REF1 = APPLE / 'refinement1'
R = Path(r'C:\public\project-hyle\hyle')
spec = importlib.util.spec_from_file_location('original_apple_transport', APPLE / 'build.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
t = p.t
ABI = ('include/hyle/graph/detail/region_access.h', 'src/graph/plan_state.h',
    'src/graph/submission_internal.h', 'src/graph/progress_internal.h',
    'src/graph/resource_episode.h', 'src/graph/submission_lifetime.h')


def freeze():
    assert not (W / 'plan.json').exists()
    previous = t.read(REF1 / 'plan.json'); records = REF1 / 'readback-logits/records'
    ready_path = records / 'ready.json'; ready = t.read(ready_path)
    rows_path = records / 'inputs.json'; rows = t.read(rows_path); assert len(rows) == 120
    remote = previous['parent_remote'] + '/refinement2'
    retained = [ready['compiled']['tiny'], ready['compiled']['retained_weights']]
    assert all(row['process']['exit'] == 0 and row['process']['timeout'] is False for row in retained)
    assert all(row['object'] in rows for row in retained)
    old_sub_path = '/Users/kiro/hyle-scratch/compute-unified/inference-paged-frame-20261026/submission.o'
    old_progress_path = previous['cold'].split('/inference-native-state-only-20261028')[0] + '/architecture-refactor-20261019-apple-page-invocation/gdn-graph-bridge-20261024/attempt1/libhyle_graph_progress_current.a'
    old_sub = next(row for row in rows if row['path'] == old_sub_path)
    old_progress = next(row for row in rows if row['path'] == old_progress_path)
    resources = next(row for row in rows if row['path'].endswith('/apple/compile/resources/unit.o'))
    assert resources['sha256'] == '74de13c4ea734ff1605dd42d4b3f88f599d097088e5bfc8b45295487b244d0e3'
    resource_deps_path = R / '.scratch/inference-native-state-only-20261028/apple/readback-final/records/compile/resources/actual-dependencies.json'
    resource_deps = t.read(resource_deps_path); abi = []
    for relative in ABI:
        original = next(row for row in resource_deps if row['path'].endswith('/' + relative))
        current = t.pin(R / relative)
        assert (current['bytes'], current['sha256']) == (original['bytes'], original['sha256']), ('Resources ABI drift', relative)
        abi.append(dict(path=relative, bytes=current['bytes'], sha256=current['sha256'], resources_header=original))
    source_template = R / '.scratch/inference-paged-frame-20261026/mac/records/compile-submission/command.json'
    command = t.command(source_template)
    assert command[command.index('-c') + 1].endswith('/src/graph/submission.cc') and command[command.index('-o') + 1] == old_sub_path
    units = []
    for name, source in (('submission', 'src/graph/submission.cc'), ('progress', 'src/graph_progress/progress.cc')):
        args = list(command)
        args[args.index('-c') + 1] = remote + '/source/' + source
        args[args.index('-o') + 1] = remote + f'/compile/{name}/unit.o'
        args[args.index('-MF') + 1] = remote + f'/compile/{name}/dependencies.d'
        args[1:1] = ['-I' + remote + '/source/include', '-I' + remote + '/source',
            '-I' + remote + '/source/src/graph', '-I' + remote + '/source/src/graph_progress',
            '-I' + remote + '/source/src/compute', '-I' + previous['cold'] + '/source/include',
            '-I' + previous['cold'] + '/source', '-I' + previous['cold'] + '/source/src/compute_route_apple',
            '-include', remote + '/abi_size_guard.h',
            '-DHYLE_GRAPH_BUILD' if name == 'submission' else '-DHYLE_GRAPH_PROGRESS_BUILD']
        assert '-O3' in args and '-std=c++23' in args and '-arch' in args
        units.append(dict(name=name, source=source, object=remote + f'/compile/{name}/unit.o', command=args,
            template=t.pin(source_template), template_basis='Actual successful submission CXX platform flags; progress derives only its source/output/module define, using the current single-source graph_progress CMake declaration.'))
    old_link_path = records / 'link/logs/command.json'; original_link = t.command(old_link_path); link = []
    for at, arg in enumerate(original_link):
        if arg == old_sub_path: arg = units[0]['object']
        elif arg == old_progress_path: arg = '@PROGRESS_REPLACEMENT@'
        elif at and original_link[at - 1] == '-o': arg = remote + '/bin/tiny'
        elif arg.startswith('-Wl,-map,'): arg = '-Wl,-map,' + remote + '/link/image.map'
        link.append(arg)
    assert original_link.count(old_sub_path) == original_link.count(old_progress_path) == 1
    pending = [R / unit['source'] for unit in units]; seen = {}
    while pending:
        path = pending.pop().resolve(); relative = path.relative_to(R).as_posix()
        if relative in seen: continue
        assert relative.startswith(('include/', 'src/')), relative
        seen[relative] = t.pin(path)
        for include in re.findall(r'^\s*#\s*include\s*[<"]([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((candidate.resolve() for root in (path.parent, R / 'include', R) if (candidate := root / include).is_file()), None)
            if found and found.is_relative_to(R) and found.relative_to(R).parts[0] in ('include', 'src'): pending.append(found)
    assert set(ABI) <= set(seen)
    expected = {relative: row['sha256'] for relative, row in seen.items()}
    t.save(W / 'expected-sources.json', expected)
    sources = []
    for relative, row in seen.items():
        target = W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write((R / relative).read_bytes())
        sources.append(dict(path=relative, bytes=row['bytes'], sha256=row['sha256']))
    guard = '#pragma once\n#include <cstddef>\n#include "hyle/graph/detail/region_access.h"\nusing NativeOrderedAbi = hyle::graph::detail::OrderedGraphSubmission;\nstatic_assert(sizeof(void*) == 8);\nstatic_assert(sizeof(NativeOrderedAbi) == 5 * sizeof(void*));\nstatic_assert(offsetof(NativeOrderedAbi, pending_effect) == 4 * sizeof(void*));\n'
    with (W / 'abi_size_guard.h').open('x', encoding='utf-8') as stream: stream.write(guard)
    failure_path = records / 'runs/logits/process.json'; failed = t.read(failure_path)
    assert failed['pid'] == 29130 and failed['exit'] == 1
    plan = dict(status='FROZEN_TWO_SDK_ABI_CONSUMERS_NOT_SYNCED', remote=remote,
        original_remote_driver=previous['original_remote_driver'], native_header=previous['native_header'],
        runtime=previous['runtime'], fixture=previous['fixture'], arms=previous['arms'], units=units,
        old_inputs=rows, old_submission=old_sub, old_progress_archive=old_progress, link_template=link,
        previous_ready=dict(local=t.pin(ready_path), remote=previous['remote'] + '/ready.json', record=ready),
        previous_inputs=t.pin(rows_path), previous_link=t.pin(old_link_path), resources=resources,
        resources_actual_dependencies=t.pin(resource_deps_path), abi_headers=abi,
        graph_progress_CMake=t.pin(R / 'src/graph_progress/CMakeLists.txt'),
        prior_runtime_failure=dict(process=failed, receipt=t.pin(failure_path), stderr=t.pin(records / 'runs/logits/stderr.log'),
            classification='Mixed private OrderedGraphSubmission ABI in retained Graph objects. Neither ProgramIo nor test submission/permissions are changed.'),
        old_submission_abi=dict(header_bytes=19611, header_sha256='e431dcf747a168074849d20da638201d06ba44c5753857653c7e4afe1c32e1bc',
            pointers=4, arm64_bytes=32), new_submission_abi=dict(pointers=5, arm64_bytes=40),
        scope='Only submission.cc and graph_progress/progress.cc are compiled. The existing resources and successful Tiny/weights objects remain. Archive membership is an explicit root-executed preflight, not an assumed fact.',
        counts=dict(CXX=2, links=1, baseline_inputs=120, actual_inputs=120, retained_inputs=118,
            planned_Apple_model_processes=4, third_party_rebuilds=0, downloads=0))
    t.save(W / 'plan.json', plan)
    t.save(W / 'source-freeze.json', dict(status='FROZEN_NOT_SYNCED', expected=t.pin(W / 'expected-sources.json'),
        plan=t.pin(W / 'plan.json'), sources=sources, source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources),
        abi_headers=abi, guard=t.pin(W / 'abi_size_guard.h'), remote_driver=t.pin(W / 'driver.py'), helper=t.pin(__file__)))
    with tarfile.open(W / 'thin-sync.tar.gz', 'x:gz') as tar:
        for name in ('plan.json', 'source-freeze.json', 'driver.py', 'abi_size_guard.h'): tar.add(W / name, arcname=name)
        for row in sources: tar.add(W / 'source' / row['path'], arcname='source/' + row['path'])
    t.save(W / 'prepared.json', dict(archive=t.pin(W / 'thin-sync.tar.gz'), remote=remote,
        source_freeze=t.pin(W / 'source-freeze.json'), source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources)))
    print('FROZEN two exact SDK consumers; no global src-diff gate, SSH, CXX, or model execution')


def configure():
    plan = t.read(W / 'plan.json'); p.W, p.REMOTE = W, plan['remote']


def parse(arm, label):
    spec = importlib.util.spec_from_file_location('frozen_native_parser', APPLE.parent / 'run.py')
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    parser.parse_output(arm, 'apple', W / ('readback-' + label) / 'records/runs' / arm, W / 'source-freeze.json')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'freeze': freeze()
    elif action == 'parse': parse(sys.argv[2], sys.argv[3])
    else:
        configure()
        if action == 'sync': p.sync()
        elif action == 'fetch': p.fetch(sys.argv[2])
        elif action in ('preflight', 'link'): p.invoke(action)
        elif action in ('compile', 'run'): p.invoke(action, sys.argv[2])
        else: raise ValueError(action)
