"""Admit a previously stat-only archive without changing the frozen plan/driver."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import os
import shlex
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent


def remote_preflight():
    spec = importlib.util.spec_from_file_location('unchanged_refinement2_driver', W / 'driver.py')
    d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
    d.verify()
    for name in ('preflight.json', 'archive-admission.json', 'preflight-v2-admission.json', 'preflight-v2.json'):
        assert not (W / name).exists(), ('Single-use metadata output exists', name)
    original = copy.deepcopy(d.P['old_progress_archive'])
    assert 'sha256' not in original, 'Unexpected source manifest: this amendment is only for the recorded missing SHA field'
    archive = Path(original['path']); assert archive.is_file()
    before = d.b.stat(archive)
    assert before['bytes'] == original['bytes']
    expected_stat = original.get('current_stat', original)
    assert 'mtime_ns' in expected_stat and before['mtime_ns'] == expected_stat['mtime_ns']
    if 'mtime_ns' in original: assert before['mtime_ns'] == original['mtime_ns']
    current_pin = d.b.pin(archive)
    assert d.b.stat(archive) == before, 'Archive changed while computing the new admission hash'
    enriched = dict(original, **current_pin)
    # In-memory only. The original plan, source-freeze and driver bytes remain
    # unchanged; the original manifest is not retrospectively given a hash.
    d.P['old_progress_archive'] = enriched
    d.save(W / 'preflight-v2-admission.json', dict(status='STAT_VERIFIED_AND_NEW_SHA_ADMITTED',
        sidecar=d.b.pin(__file__), original_plan=d.b.pin(W / 'plan.json'),
        original_manifest_entry=original, verified_stat=before, newly_computed_archive_pin=current_pin,
        reason='Original preflight expected sha256, but this historical manifest entry contained only size/mtime. No compiler, linker or model had started.',
        mutation='Only the imported driver in-memory archive row is enriched. Frozen files and the old failed invocation are preserved.',
        original_preflight_action='Unchanged ar member inspection and 118 retained-input stat checks follow.'))
    d.preflight()
    d.save(W / 'preflight-v2.json', dict(status='PASS', admission=d.b.pin(W / 'preflight-v2-admission.json'),
        original_preflight=d.b.pin(W / 'preflight.json'), archive_admission=d.b.pin(W / 'archive-admission.json'),
        new_CXX=0, new_links=0, model_processes=0,
        link_gate='The unchanged link() reads and hashes archive-admission.json.archive, which now contains the actual SHA; it does not require the missing SHA from the original plan row.'))
    print('PREFLIGHT V2 PASS: original stat provenance retained; archive SHA admitted now')


def local(action):
    # Reuse the original local transport recorder. Importing it does not call
    # a frozen parent validator, SSH, compiler or model implicitly.
    spec = importlib.util.spec_from_file_location('original_apple_transport', W.parent / 'build.py')
    p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
    plan = p.t.read(W / 'plan.json'); remote = plan['remote']
    if action == 'sync':
        payload = Path(__file__).read_bytes(); sha = hashlib.sha256(payload).hexdigest()
        code = '''import hashlib,pathlib,sys
p=pathlib.Path(%r)
data=sys.stdin.buffer.read()
if hashlib.sha256(data).hexdigest()!=%r:raise RuntimeError('sidecar transfer hash mismatch')
if not p.parent.is_dir():raise RuntimeError('original refinement2 directory is missing')
with p.open('xb') as f:f.write(data)
print('SYNCED SIDECAR',p,hashlib.sha256(data).hexdigest())
''' % (remote + '/preflight_v2.py', sha)
        p.m.call(p.m.SSH + ['python3 -c ' + shlex.quote(code)], W / 'sync-preflight-v2', payload)
    elif action == 'run':
        p.m.call(p.m.SSH + [shlex.join(['python3', remote + '/preflight_v2.py'])], W / 'invocations/preflight-v2')
    else: raise ValueError('Expected sync or run')


if __name__ == '__main__':
    if os.name == 'nt': local(sys.argv[1])
    else: remote_preflight()
