"""Exact observed one-member archive; preserve both earlier metadata failures."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
MEMBER = 'src--graph_progress--progress.cc.o'


def remote_preflight():
    spec = importlib.util.spec_from_file_location('unchanged_refinement2_driver', W / 'driver.py')
    d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
    d.verify()
    for name in ('archive-admission.json', 'preflight.json', 'preflight-v3.json'):
        assert not (W / name).exists(), ('Single-use metadata output exists', name)
    admission_path = W / 'preflight-v2-admission.json'
    earlier = d.read(admission_path)
    assert earlier['status'] == 'STAT_VERIFIED_AND_NEW_SHA_ADMITTED'
    assert earlier['original_manifest_entry'] == d.P['old_progress_archive']
    archive = earlier['newly_computed_archive_pin']
    assert archive['path'] == d.P['old_progress_archive']['path']
    assert d.b.stat(archive['path']) == earlier['verified_stat']
    d.exact(archive)
    stats = []; replaced = {d.P['old_submission']['path'], d.P['old_progress_archive']['path']}
    for row in d.P['old_inputs']:
        if row['path'] in replaced: continue
        actual = d.b.stat(row['path']); assert actual['bytes'] == row['bytes'], row['path']
        previous = row.get('current_stat', row)
        if 'mtime_ns' in previous: assert actual['mtime_ns'] == previous['mtime_ns'], row['path']
        stats.append(actual)
    assert len(stats) == 118
    listing, original_members = d.members(archive['path'])
    assert len(original_members) == 1 and original_members[0]['name'] == MEMBER, listing
    progress = next(unit for unit in d.P['units'] if unit['name'] == 'progress')
    assert progress['source'] == 'src/graph_progress/progress.cc'
    # The current frozen CMake declaration has exactly that source. The actual
    # archive contains exactly its named object, so no other member is dropped.
    d.save(W / 'archive-admission.json', dict(archive=archive,
        ar_command=['/usr/bin/ar', '-t', archive['path']], actual_listing=listing,
        original_members=original_members, progress_member=original_members[0],
        mode='single_member_to_direct_object', replacement=progress['object']))
    d.save(W / 'preflight.json', dict(status='PASS', retained_stats=stats, inputs=120,
        archive_admission=d.b.pin(W / 'archive-admission.json'), abi_headers=d.P['abi_headers'],
        retained_consumers=d.P['previous_ready']['record']['compiled']))
    d.save(W / 'preflight-v3.json', dict(status='PASS', sidecar=d.b.pin(__file__),
        original_plan=d.b.pin(W / 'plan.json'), previous_sha_admission=d.b.pin(admission_path),
        archive_admission=d.b.pin(W / 'archive-admission.json'), preflight=d.b.pin(W / 'preflight.json'),
        exact_observed_member=MEMBER, graph_progress_CMake=d.P['graph_progress_CMake'],
        reason='Original regex did not match the actual uniquely named module object. Exact observed one-member admission replaces it; original regex, driver, plan and both failed invocations remain unchanged.',
        new_CXX=0, new_links=0, model_processes=0))
    print('PREFLIGHT V3 PASS: exact sole progress module object; 118 retained inputs checked')


def local(action):
    # Reuse only the v2 transport implementation, with this sidecar's file and
    # independent output paths. Its remote preflight function is never called.
    import hashlib
    import shlex
    spec = importlib.util.spec_from_file_location('original_apple_transport', W.parent / 'build.py')
    p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
    remote = p.t.read(W / 'plan.json')['remote']
    if action == 'sync':
        payload = Path(__file__).read_bytes(); sha = hashlib.sha256(payload).hexdigest()
        code = '''import hashlib,pathlib,sys
p=pathlib.Path(%r);data=sys.stdin.buffer.read()
if hashlib.sha256(data).hexdigest()!=%r:raise RuntimeError('sidecar transfer hash mismatch')
if not p.parent.is_dir():raise RuntimeError('original refinement2 directory missing')
with p.open('xb') as f:f.write(data)
print('SYNCED SIDECAR',p,hashlib.sha256(data).hexdigest())
''' % (remote + '/preflight_v3.py', sha)
        p.m.call(p.m.SSH + ['python3 -c ' + shlex.quote(code)], W / 'sync-preflight-v3', payload)
    elif action == 'run':
        p.m.call(p.m.SSH + [shlex.join(['python3', remote + '/preflight_v3.py'])], W / 'invocations/preflight-v3')
    else: raise ValueError('Expected sync or run')


if __name__ == '__main__':
    if os.name == 'nt': local(sys.argv[1])
    else: remote_preflight()
