#pragma once
#include <cstddef>
#include "hyle/graph/detail/region_access.h"
using NativeOrderedAbi = hyle::graph::detail::OrderedGraphSubmission;
static_assert(sizeof(void*) == 8);
static_assert(sizeof(NativeOrderedAbi) == 5 * sizeof(void*));
static_assert(offsetof(NativeOrderedAbi, pending_effect) == 4 * sizeof(void*));
