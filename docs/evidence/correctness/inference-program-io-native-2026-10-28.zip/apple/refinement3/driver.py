"""Single native-region replacement in the existing ABI-correct 120-input closure."""
from pathlib import Path
import importlib.util
import json
import os
import shlex
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())
spec = importlib.util.spec_from_file_location('original_native_recorder', P['original_remote_driver'])
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); b.W = W


def read(path): return json.loads(Path(path).read_text())
def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')
def exact(row):
    actual = b.pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def verify():
    frozen = read(W / 'source-freeze.json'); actual = b.pin(__file__)
    assert (actual['bytes'], actual['sha256']) == (frozen['remote_driver']['bytes'], frozen['remote_driver']['sha256'])
    for row in frozen['sources']:
        actual = b.pin(W / 'source' / row['path'])
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
    assert b.pin(P['native_header']['path'])['sha256'] == P['native_header']['sha256']
    identity = b.pin(P['previous_ready']['remote']); prior = P['previous_ready']['local']
    assert (identity['bytes'], identity['sha256']) == (prior['bytes'], prior['sha256'])
    assert read(P['previous_ready']['remote']) == P['previous_ready']['record']
    for group in ('compiled', 'retained_consumers'):
        for record in P['previous_ready']['record'][group].values():
            assert record['process']['exit'] == 0 and record['process']['timeout'] is False
            exact(record['object'])
    return frozen


def preflight():
    verify(); exact(P['unit']['old_object']); stats = []
    for row in P['old_inputs']:
        if row['path'] == P['unit']['old_object']['path']: continue
        actual = b.stat(row['path']); assert actual['bytes'] == row['bytes'], row['path']
        prior = row.get('current_stat', row)
        if 'mtime_ns' in prior: assert actual['mtime_ns'] == prior['mtime_ns'], row['path']
        stats.append(actual)
    assert len(stats) == 119
    save(W / 'preflight.json', dict(status='PASS', retained_stats=stats, inputs=120,
        abi_headers=P['abi_headers'], retained_carrier=b.pin(P['native_header']['path']),
        retained_successful_components=P['previous_ready']['record']))
    print('PREFLIGHT PASS: one region replacement, 119 retained inputs, no archive operation')


def compile_one():
    verify(); assert (W / 'preflight.json').is_file(); unit = P['unit']
    out = W / 'compile/region'; out.mkdir(parents=True, exist_ok=False)
    process = b.execute(unit['command'], out / 'logs', 300)
    verify(); raw = (out / 'dependencies.d').read_text().replace('\\\n', '')
    actual = []; seen = set()
    for value in dict.fromkeys(shlex.split(raw.split(':', 1)[1])):
        path = Path(value); path = path if path.is_absolute() else W / path
        row = b.pin(path) if path.is_relative_to(W / 'source') else b.stat(path)
        for abi in P['abi_headers']:
            if str(path).endswith('/' + abi['path']):
                assert path == W / 'source' / abi['path'], ('Unexpected header selection', str(path))
                assert (row['bytes'], row['sha256']) == (abi['bytes'], abi['sha256'])
                seen.add(abi['path'])
        if path.name == 'apple_carrier.h':
            assert str(path) == P['native_header']['path'] and b.pin(path)['sha256'] == P['native_header']['sha256']
        actual.append(row)
    assert seen == {row['path'] for row in P['abi_headers']}
    save(out / 'actual-dependencies.json', actual)
    save(out / 'compiled.json', dict(source=unit['source_pin'], object=b.pin(unit['object']), process=process,
        command=b.pin(out / 'logs/command.json'), dependencies=b.pin(out / 'dependencies.d'),
        actual_dependencies=b.pin(out / 'actual-dependencies.json'), verified_ABI_headers=sorted(seen)))
    print('CXX PASS native_region only')


def link():
    verify(); compiled = read(W / 'compile/region/compiled.json'); exact(compiled['object'])
    assert compiled['process']['exit'] == 0 and compiled['process']['timeout'] is False
    for row in read(W / 'preflight.json')['retained_stats']: assert b.stat(row['path']) == row
    rows = [compiled['object'] if row['path'] == P['unit']['old_object']['path'] else row for row in P['old_inputs']]
    assert len(rows) == 120
    for row in rows: assert P['link_command'].count(row['path']) == 1, row['path']
    (W / 'bin').mkdir(exist_ok=True)
    process = b.execute(P['link_command'], W / 'link/logs', 240)
    save(W / 'inputs.json', rows)
    save(W / 'ready.json', dict(image=b.pin(W / 'bin/tiny'), inputs=b.pin(W / 'inputs.json'), compiled={'region': compiled},
        retained_successful_components=P['previous_ready']['record'], process=process,
        recipe=b.pin(W / 'link/logs/command.json'), source_freeze=b.pin(W / 'source-freeze.json'),
        plan=b.pin(W / 'plan.json'), runtime=P['runtime'], counts=dict(CXX=1, links=1, inputs=120, retained=119)))
    print('LINK READY: one region TU, original successful ABI consumers/Tiny/weights retained')


def run(arm):
    verify(); ready = read(W / 'ready.json')
    for field in ('image', 'inputs', 'source_freeze'): exact(ready[field])
    saved = {key: os.environ.get(key) for key in P['runtime']}; os.environ.update(P['runtime'])
    out = W / 'runs' / arm; assert not out.exists(), 'Already attempted; no automatic rerun'
    try: b.execute([ready['image']['path'], '--apple', P['fixture'], P['arms'][arm]], out, 300)
    finally:
        if (out / 'process.json').is_file():
            save(out / 'as-run.json', dict(image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'],
                runtime_overrides=P['runtime'], inherited_environment_whitelist={key: os.environ[key] for key in
                    ('PATH', 'DYLD_LIBRARY_PATH', 'DYLD_FALLBACK_LIBRARY_PATH', 'HOME', 'TMPDIR') if key in os.environ},
                process=read(out / 'process.json')))
        for key, value in saved.items():
            if value is None: os.environ.pop(key, None)
            else: os.environ[key] = value


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'preflight': preflight()
    elif action == 'compile': compile_one()
    elif action == 'link': link()
    elif action == 'run': run(sys.argv[2])
    else: raise ValueError(action)
