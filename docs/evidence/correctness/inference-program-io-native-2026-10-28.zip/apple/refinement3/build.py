"""One Apple native-region TU, based on the successful 120-input ABI-correct link."""
from pathlib import Path
import importlib.util
import re
import sys
import tarfile
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
APPLE = W.parent
REF2 = APPLE / 'refinement2'
R = Path(r'C:\public\project-hyle\hyle')
spec = importlib.util.spec_from_file_location('original_apple_transport', APPLE / 'build.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
t = p.t
SOURCE = 'src/graph_route_apple/native_region.cc'
SHA = '8a5ed5c2384ed8303a5dbb63f790c10d8234a3c4e6269372d0d31233bf586a4b'
ABI = ('include/hyle/graph/region_provider.h', 'include/hyle/compute/detail/apple_plan.h',
    'include/hyle/graph/detail/region_access.h', 'src/graph_route_apple/apple_lowering_internal.h',
    'src/graph_route_apple/native_output.h')
CARRIER = 'src/compute_route_apple/apple_carrier.h'


def freeze():
    assert not (W / 'plan.json').exists()
    source = t.pin(R / SOURCE); assert source['sha256'] == SHA and source['bytes'] == 52624
    previous = t.read(REF2 / 'plan.json'); records = REF2 / 'readback-logits/records'
    ready_path = records / 'ready.json'; ready = t.read(ready_path)
    rows_path = records / 'inputs.json'; rows = t.read(rows_path); assert len(rows) == 120
    assert all(record['process']['exit'] == 0 and record['process']['timeout'] is False
        for group in ('compiled', 'retained_consumers') for record in ready[group].values())
    remote = previous['remote'].rsplit('/', 1)[0] + '/refinement3'
    old_records = R / '.scratch/inference-native-state-only-20261028/apple/readback-final/records'
    template_path = old_records / 'cold-pruning/compile/region/logs/command.json'
    command = t.command(template_path); original_object = command[command.index('-o') + 1]
    old_object = next(row for row in rows if row['path'] == original_object)
    assert command[command.index('-c') + 1].endswith('/' + SOURCE)
    command[command.index('-c') + 1] = remote + '/source/' + SOURCE
    command[command.index('-o') + 1] = remote + '/compile/region/unit.o'
    command[command.index('-MF') + 1] = remote + '/compile/region/dependencies.d'
    command[1:1] = ['-I' + remote + '/source/include', '-I' + remote + '/source',
        '-I' + remote + '/source/src/graph_route_apple', '-I' + remote + '/source/src/graph',
        '-I' + remote + '/source/src/compute', '-I' + previous['native_header']['path'].rsplit('/src/compute_route_apple/', 1)[0] + '/src/graph_route_apple']
    assert '-O3' in command and '-std=c++23' in command and '-DHYLE_GRAPH_ROUTE_APPLE_BUILD' in command
    original_link_path = records / 'link/logs/command.json'; old_link = t.command(original_link_path); link = []
    for at, arg in enumerate(old_link):
        if arg == original_object: arg = remote + '/compile/region/unit.o'
        elif at and old_link[at - 1] == '-o': arg = remote + '/bin/tiny'
        elif arg.startswith('-Wl,-map,'): arg = '-Wl,-map,' + remote + '/link/image.map'
        link.append(arg)
    assert old_link.count(original_object) == link.count(remote + '/compile/region/unit.o') == 1
    assert sum(arg.endswith(('.o', '.a', '.dylib')) for arg in link) == 120
    old_header_manifest_path = R / '.scratch/inference-native-state-only-20261028/apple/headers-v3/source-freeze-headers-v3.json'
    old_header_manifest = t.read(old_header_manifest_path)['files']
    old_region_deps_path = old_records / 'cold-pruning/compile/region/actual-dependencies.json'
    old_region_deps = t.read(old_region_deps_path); abi = []
    for relative in ABI:
        prior = next((row for row in old_region_deps if row['path'].endswith('/' + relative) and 'sha256' in row), None)
        if prior is None: prior = next(row for row in old_header_manifest if row['path'] == relative)
        actual = t.pin(R / relative)
        assert (actual['bytes'], actual['sha256']) == (prior['bytes'], prior['sha256']), ('ABI header changed', relative)
        abi.append(dict(path=relative, bytes=actual['bytes'], sha256=actual['sha256'], previous=prior))
    carrier = t.pin(R / CARRIER)
    assert carrier['sha256'] == previous['native_header']['sha256'] == 'f286ebe991efffb4de87b90e479b75e6c8a17b0300dc95bb5791e2f6e87cc106'
    pending = [R / SOURCE]; seen = {}
    while pending:
        path = pending.pop().resolve(); relative = path.relative_to(R).as_posix()
        if relative in seen: continue
        assert relative.startswith(('include/', 'src/')), relative
        seen[relative] = t.pin(path)
        for include in re.findall(r'^\s*#\s*include\s*[<"]([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((candidate.resolve() for root in (path.parent, R / 'include', R) if (candidate := root / include).is_file()), None)
            if found and found.is_relative_to(R) and found.relative_to(R).parts[0] in ('include', 'src'): pending.append(found)
    assert set(ABI) <= set(seen) and CARRIER in seen
    # Keep this original f286 header at its old physical cold path. Relative
    # includes resolve via the preserved cold graph-route include directory.
    seen.pop(CARRIER)
    sources = []
    for relative, row in seen.items():
        target = W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write((R / relative).read_bytes())
        sources.append(dict(path=relative, bytes=row['bytes'], sha256=row['sha256']))
    t.save(W / 'expected-sources.json', {row['path']: row['sha256'] for row in sources})
    failed_path = records / 'runs/logits/process.json'; failed = t.read(failed_path)
    assert failed['pid'] == 29252 and failed['exit'] == 1
    plan = dict(status='FROZEN_ONE_NATIVE_REGION_TU_NOT_SYNCED', remote=remote,
        original_remote_driver=previous['original_remote_driver'], native_header=previous['native_header'],
        runtime=previous['runtime'], fixture=previous['fixture'], arms=previous['arms'],
        unit=dict(name='region', source=SOURCE, source_pin=source, object=remote + '/compile/region/unit.o',
            command=command, template=t.pin(template_path), old_object=old_object),
        link_command=link, old_inputs=rows, abi_headers=abi, retained_carrier=dict(current=carrier, remote=previous['native_header']),
        old_header_manifest=t.pin(old_header_manifest_path), old_region_dependencies=t.pin(old_region_deps_path),
        previous_ready=dict(local=t.pin(ready_path), remote=previous['remote'] + '/ready.json', record=ready),
        previous_inputs=t.pin(rows_path), previous_link=t.pin(original_link_path),
        prior_runtime_failure=dict(process=failed, receipt=t.pin(failed_path), stderr=t.pin(records / 'runs/logits/stderr.log'),
            classification='Ordinary upstream NativeRef checked Gather was classified as an external address-only projected bank. Original source/failed image retained.'),
        counts=dict(CXX=1, links=1, inputs=120, retained_inputs=119, planned_Apple_model_processes=4,
            additional_consumer_CXX=0, third_party_rebuilds=0, downloads=0),
        scope='Only native_region.cc changes. Exact existing RegionValue, RowAccess and native output/carrier declarations match. No archive modification, success-consumer recompile, permissions or test-submission change.')
    t.save(W / 'plan.json', plan)
    t.save(W / 'source-freeze.json', dict(status='FROZEN_NOT_SYNCED', expected=t.pin(W / 'expected-sources.json'),
        plan=t.pin(W / 'plan.json'), sources=sources, source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources),
        abi_headers=abi, retained_carrier=plan['retained_carrier'], remote_driver=t.pin(W / 'driver.py'), helper=t.pin(__file__)))
    with tarfile.open(W / 'thin-sync.tar.gz', 'x:gz') as tar:
        for name in ('plan.json', 'source-freeze.json', 'driver.py'): tar.add(W / name, arcname=name)
        for row in sources: tar.add(W / 'source' / row['path'], arcname='source/' + row['path'])
    t.save(W / 'prepared.json', dict(archive=t.pin(W / 'thin-sync.tar.gz'), remote=remote,
        source_freeze=t.pin(W / 'source-freeze.json'), source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources)))
    print('FROZEN 1 native_region TU + 119 retained inputs; no remote/compiler/model action')


def configure():
    plan = t.read(W / 'plan.json'); p.W, p.REMOTE = W, plan['remote']


def parse(arm, label):
    spec = importlib.util.spec_from_file_location('frozen_native_parser', APPLE.parent / 'run.py')
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    parser.parse_output(arm, 'apple', W / ('readback-' + label) / 'records/runs' / arm, W / 'source-freeze.json')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'freeze': freeze()
    elif action == 'parse': parse(sys.argv[2], sys.argv[3])
    else:
        configure()
        if action == 'sync': p.sync()
        elif action == 'fetch': p.fetch(sys.argv[2])
        elif action in ('preflight', 'link'): p.invoke(action)
        elif action == 'compile': p.invoke('compile')
        elif action == 'run': p.invoke('run', sys.argv[2])
        else: raise ValueError(action)
