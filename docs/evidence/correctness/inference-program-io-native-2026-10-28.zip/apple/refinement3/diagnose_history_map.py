"""Root-only: one LLDB history launch on the unchanged ready image, new raw logs."""
from pathlib import Path
import importlib.util
import json
import shlex
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_apple_transport', W.parent / 'build.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)

CALLBACK = '''import json,lldb
counts={'throws_seen':0,'unreadable_type':0,'out_of_range_seen':0}
def only_out_of_range(frame,location,internal):
 counts['throws_seen']+=1
 process=frame.GetThread().GetProcess(); target=process.GetTarget()
 register=frame.FindRegister('x1')
 if not register.IsValid():
  counts['unreadable_type']+=1;return False
 error=lldb.SBError()
 name_pointer=process.ReadPointerFromMemory(register.GetValueAsUnsigned()+target.GetAddressByteSize(),error)
 if error.Fail():
  counts['unreadable_type']+=1;return False
 name=process.ReadCStringFromMemory(name_pointer,256,error)
 if error.Fail():
  counts['unreadable_type']+=1;return False
 matched=name=='St12out_of_range' or name.endswith('12out_of_rangeE')
 if matched:
  counts['out_of_range_seen']+=1
  print('DIAGNOSTIC_EXCEPTION_TYPE '+name)
 return matched
def install(debugger):
 target=debugger.GetSelectedTarget()
 helper=target.BreakpointCreateByRegex('__throw_out_of_range')
 resolved=helper.GetNumLocations()
 print('DIAGNOSTIC_THROW_HELPER_LOCATIONS '+str(resolved))
 if resolved==0:
  helper.SetEnabled(False)
  fallback=target.BreakpointCreateByName('__cxa_throw')
  fallback.SetScriptCallbackFunction(__name__+'.only_out_of_range')
  print('DIAGNOSTIC_FALLBACK type_info read-only arm64 x1; locations='+str(fallback.GetNumLocations()))
def report():print('DIAGNOSTIC_CALLBACK_COUNTS '+json.dumps(counts))
'''


def main():
    plan = p.t.read(W / 'plan.json')
    records = W / 'readback-final/records'
    if not (records / 'ready.json').is_file(): records = W / 'readback-history-failure/records'
    ready = p.t.read(records / 'ready.json')
    remote = plan['remote']; diagnostic = remote + '/diagnose-history-map'
    code = '''import datetime,hashlib,json,os,pathlib,re,signal,subprocess,sys,time
d=pathlib.Path(%r);d.mkdir(exist_ok=False)
w=d.parent;ready_path=w/'ready.json';ready=json.loads(ready_path.read_text())
if hashlib.sha256(ready_path.read_bytes()).hexdigest()!=%r:raise RuntimeError('ready receipt changed')
if ready['image']!=%r:raise RuntimeError('not the original R3 image')
image=pathlib.Path(ready['image']['path'])
if image.stat().st_size!=ready['image']['bytes'] or hashlib.sha256(image.read_bytes()).hexdigest()!=ready['image']['sha256']:raise RuntimeError('image changed')
runtime=%r;env=os.environ.copy();env.update(runtime)
(d/'breakpoints.py').write_text(%r)
commands='version\\nsettings set auto-confirm true\\ncommand script import '+str(d/'breakpoints.py')+'\\nscript breakpoints.install(lldb.debugger)\\nrun\\nthread backtrace -c 40 all\\nscript breakpoints.report()\\nprocess status\\nquit\\n'
(d/'commands.lldb').write_text(commands)
command=['/usr/bin/lldb','--no-lldbinit','--batch','--source',str(d/'commands.lldb'),'--',str(image),'--apple',%r,'--history-logits']
record={'command':command,'cwd':str(w),'image':ready['image'],'ready_sha256':%r,'environment_overrides':runtime,'inherited_environment_whitelist':{k:env[k] for k in ('PATH','DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH','HOME','TMPDIR') if k in env},'scope':'One diagnostic history target; no build or performance assertion. Source debug info is optional; symbol backtrace only.'}
(d/'command.json').write_text(json.dumps(record,indent=2)+'\\n')
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();timed_out=False;timeout_cleanup=[]
with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
 child=subprocess.Popen(command,cwd=w,env=env,stdout=out,stderr=err,start_new_session=True)
 (d/'running.json').write_text(json.dumps({'debugger_pid':child.pid,'started_utc':started})+'\\n')
 try:child.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed_out=True
  # Only target PIDs explicitly reported by this debugger session are killed.
  # Then stop the debugger process group; there is no diagnostic relaunch.
  partial=(d/'stdout.log').read_text(errors='replace')
  targets=set(re.findall(r'Process ([0-9]+) launched',partial))
  for value in targets:
   target=int(value)
   try:os.kill(target,signal.SIGKILL);timeout_cleanup.append({'target_pid':target,'signal':'SIGKILL'})
   except ProcessLookupError:timeout_cleanup.append({'target_pid':target,'already_exited':True})
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait(timeout=10)
stdout=(d/'stdout.log').read_text(errors='replace');stderr=(d/'stderr.log').read_text(errors='replace')
process={'debugger_pid':child.pid,'exit':child.returncode,'timed_out':timed_out,'timeout_seconds':180,'timeout_cleanup':timeout_cleanup,'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-start,'reported_target_pids':list(dict.fromkeys(re.findall(r'Process ([0-9]+) (?:launched|stopped|exited)',stdout))),'interpretation':'Debugger result only; no Model PASS inferred. Inspect actual breakpoint and stack.'}
(d/'process.json').write_text(json.dumps(process,indent=2)+'\\n')
sys.stdout.write(stdout);sys.stderr.write(stderr);print('DIAGNOSTIC_PROCESS '+json.dumps(process))
sys.exit(child.returncode)
''' % (diagnostic, p.t.pin(records / 'ready.json')['sha256'], ready['image'], plan['runtime'], CALLBACK,
        plan['fixture'], p.t.pin(records / 'ready.json')['sha256'])
    # Original transport preserves command, SSH PID/exit and returned raw LLDB
    # text locally. Remote command/process/raw files remain in the same new dir.
    p.m.call(p.m.SSH + ['python3 -c ' + shlex.quote(code)], W / 'diagnose-history-map')


if __name__ == '__main__': main()
