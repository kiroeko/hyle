"""Parse the already successful region CXX; canonicalize dependency spellings only."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent


def remote_parse():
    import shlex
    spec = importlib.util.spec_from_file_location('unchanged_refinement3_driver', W / 'driver.py')
    d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
    d.verify()
    out = W / 'compile/region'; unit = d.P['unit']
    for name in ('actual-dependencies.json', 'compiled.json', 'parse-compile.json'):
        assert not (out / name).exists(), ('Successful parse receipt already exists', name)
    process = d.read(out / 'logs/process.json')
    assert process['pid'] == 29306 and process['exit'] == 0 and process['timeout'] is False
    assert process['ended_utc'] and process['seconds'] >= 0
    command = d.read(out / 'logs/command.json')['command']
    assert command == unit['command']
    assert Path(command[command.index('-o') + 1]).resolve() == Path(unit['object']).resolve()
    object_pin = d.b.pin(unit['object'])
    raw = (out / 'dependencies.d').read_text().replace('\\\n', '')
    actual = []; seen = set(); normalized = []; carrier_seen = False
    source_root = (W / 'source').resolve()
    carrier_path = Path(d.P['native_header']['path']).resolve()
    for reported in dict.fromkeys(shlex.split(raw.split(':', 1)[1])):
        path = Path(reported); path = path if path.is_absolute() else W / path
        canonical = path.resolve(strict=True)
        row = d.b.pin(canonical) if canonical.is_relative_to(source_root) else d.b.stat(canonical)
        if str(path) != str(canonical):
            row['reported_path'] = str(path)
            normalized.append(dict(reported=str(path), canonical=str(canonical)))
        for abi in d.P['abi_headers']:
            expected = (W / 'source' / abi['path']).resolve()
            if canonical == expected:
                identity = d.b.pin(canonical)
                assert (identity['bytes'], identity['sha256']) == (abi['bytes'], abi['sha256'])
                seen.add(abi['path'])
            elif canonical.name == Path(abi['path']).name:
                raise AssertionError(('Unexpected physical ABI header', str(canonical), str(expected)))
        if canonical.name == 'apple_carrier.h':
            assert canonical == carrier_path, ('Wrong physical carrier', str(canonical), str(carrier_path))
            identity = d.b.pin(canonical)
            assert identity['sha256'] == d.P['native_header']['sha256'] == 'f286ebe991efffb4de87b90e479b75e6c8a17b0300dc95bb5791e2f6e87cc106'
            row.update(bytes=identity['bytes'], sha256=identity['sha256'])
            carrier_seen = True
        actual.append(row)
    assert seen == {abi['path'] for abi in d.P['abi_headers']} and carrier_seen
    d.verify()
    assert d.b.pin(unit['object']) == object_pin, 'Successful object changed during offline parsing'
    d.save(out / 'actual-dependencies.json', actual)
    d.save(out / 'compiled.json', dict(source=unit['source_pin'], object=object_pin, process=process,
        command=d.b.pin(out / 'logs/command.json'), dependencies=d.b.pin(out / 'dependencies.d'),
        actual_dependencies=d.b.pin(out / 'actual-dependencies.json'), verified_ABI_headers=sorted(seen),
        offline_parse_sidecar=d.b.pin(__file__)))
    d.save(out / 'parse-compile.json', dict(status='PASS_OFFLINE_PARSE', sidecar=d.b.pin(__file__),
        process=process, object=object_pin, path_normalizations=normalized,
        compiled=d.b.pin(out / 'compiled.json'), source_freeze=d.b.pin(W / 'source-freeze.json'),
        reason='The original wrapper compared literal path spellings. Canonical physical path plus the same exact ABI/carrier SHA now validates ../ aliases without changing the compiler output or source.',
        additional_CXX=0, additional_links=0, model_processes=0))
    print('PARSED successful CXX 29306; canonical physical header identities verified, no recompile')


def local(action):
    import hashlib
    import shlex
    spec = importlib.util.spec_from_file_location('original_apple_transport', W.parent / 'build.py')
    p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
    remote = p.t.read(W / 'plan.json')['remote']
    if action == 'sync':
        payload = Path(__file__).read_bytes(); sha = hashlib.sha256(payload).hexdigest()
        code = '''import hashlib,pathlib,sys
p=pathlib.Path(%r);data=sys.stdin.buffer.read()
if hashlib.sha256(data).hexdigest()!=%r:raise RuntimeError('sidecar transfer hash mismatch')
if not p.parent.is_dir():raise RuntimeError('original refinement3 directory missing')
with p.open('xb') as f:f.write(data)
print('SYNCED SIDECAR',p,hashlib.sha256(data).hexdigest())
''' % (remote + '/parse_compile.py', sha)
        p.m.call(p.m.SSH + ['python3 -c ' + shlex.quote(code)], W / 'sync-parse-compile', payload)
    elif action == 'run':
        p.m.call(p.m.SSH + [shlex.join(['python3', remote + '/parse_compile.py'])], W / 'invocations/parse-compile')
    else: raise ValueError('Expected sync or run')


if __name__ == '__main__':
    if os.name == 'nt': local(sys.argv[1])
    else: remote_parse()
