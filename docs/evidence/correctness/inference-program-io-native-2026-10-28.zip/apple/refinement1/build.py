"""Independent Apple test-portability refinement; no parent validation or CXX retry."""
from pathlib import Path
import difflib
import importlib.util
import sys
import tarfile
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
PARENT = W.parent
R = Path(r'C:\public\project-hyle\hyle')
spec = importlib.util.spec_from_file_location('apple_original_thin_transport', PARENT / 'build.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
t = p.t
AMENDED = {
    'tests/tools/qwen_packed_prefill_case.h': '9623268cbf60cfaf7c3019283fb8bcf32d0c23a755387dd7cacd904e54b11c9c',
    'tests/tools/qwen_mtp_sampling_case.h': 'c691f197eba375a9a8bc880e5021923f033ea3dac0db60cef560048a0af6698a'}


def freeze():
    assert not (W / 'plan.json').exists()
    old = t.read(PARENT / 'plan.json'); previous = t.read(PARENT / 'source-freeze.json')
    remote_parent = old['remote']; remote = remote_parent + '/refinement1'
    expected = t.read(previous['expected']['path']); t.exact(previous['expected'])
    expected.update(AMENDED)
    old_sources = {row['path']: row for row in previous['sources']}
    for relative, row in old_sources.items():
        actual = t.pin(R / relative)
        assert actual['sha256'] == AMENDED.get(relative, row['sha256']), ('Unexpected source drift', relative)
    assert set(AMENDED) <= set(old_sources)
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    record_root = PARENT / 'readback-compile/records'
    weights_path = record_root / 'compile/weights/compiled.json'
    weights = t.read(weights_path); failure_path = record_root / 'compile/tiny/logs/process.json'; failure = t.read(failure_path)
    assert weights['process']['exit'] == 0 and weights['process']['timeout'] is False and weights['process']['pid'] == 29058
    assert failure['pid'] == 29059 and failure['exit'] == 1 and failure['timeout'] is False
    assert weights['source']['sha256'] == t.pin(R / 'engine/models/qwen35/weights.cc')['sha256']
    old_tiny = next(unit for unit in old['units'] if unit['name'] == 'tiny')
    unit = dict(old_tiny); unit['object'] = remote + '/compile/tiny/unit.o'
    unit['command'] = [arg.replace(remote_parent + '/source', remote + '/source') for arg in old_tiny['command']]
    unit['command'][unit['command'].index('-o') + 1] = unit['object']
    unit['command'][unit['command'].index('-MF') + 1] = remote + '/compile/tiny/dependencies.d'
    link = []
    for at, arg in enumerate(old['link_command']):
        if arg == old_tiny['object']: arg = unit['object']
        elif at and old['link_command'][at - 1] == '-o': arg = remote + '/bin/tiny'
        elif arg.startswith('-Wl,-map,'): arg = '-Wl,-map,' + remote + '/link/image.map'
        link.append(arg)
    assert link.count(unit['object']) == 1 and link.count(weights['object']['path']) == 1
    assert sum(arg.endswith(('.o', '.a', '.dylib')) for arg in link) == 120
    plan = dict(status='FROZEN_TEST_ONLY_REFINEMENT', remote=remote, parent_remote=remote_parent,
        original_remote_driver=old['original_remote_driver'], base=old['base'], cold=old['cold'],
        native_header=old['native_header'], units=[unit], link_command=link, old_inputs=old['old_inputs'],
        removed_entry=old['removed_entry'], runtime=old['runtime'], fixture=old['fixture'], arms=old['arms'],
        retained_weights=dict(receipt=t.pin(weights_path), record=weights,
            remote_receipt=remote_parent + '/compile/weights/compiled.json'),
        parent_preflight=dict(remote=remote_parent + '/preflight.json', local=t.pin(record_root / 'preflight.json')),
        parent_plan=t.pin(PARENT / 'plan.json'), parent_source_freeze=t.pin(PARENT / 'source-freeze.json'),
        prior_Tiny_failure=dict(process=failure, receipt=t.pin(failure_path),
            stderr=t.pin(record_root / 'compile/tiny/logs/stderr.log'),
            scope='One actual Clang CXX failure with twelve test portability diagnostics; no failed link or model process.'),
        counts=dict(new_CXX=1, new_links=1, original_SDK_inputs=118, retained_successful_weights=1,
            new_Tiny_objects=1, actual_inputs=120, planned_Apple_model_processes=4, SDK_CXX=0, downloads=0),
        source_amendment='Only the two frozen test headers change. Product main/ProgramIo, weights and the old successful weights object are retained. Parent failed source, logs and metadata are immutable.')
    t.save(W / 'expected-sources.json', expected)
    sources = []
    for relative in old_sources:
        original = t.pin(R / relative); target = W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write((R / relative).read_bytes())
        sources.append(dict(path=relative, bytes=original['bytes'], sha256=original['sha256']))
    delta = []
    for relative in AMENDED:
        delta.extend(difflib.unified_diff((PARENT / 'source' / relative).read_text(encoding='utf-8-sig').splitlines(True),
            (R / relative).read_text(encoding='utf-8-sig').splitlines(True), fromfile='failed/'+relative, tofile='refinement1/'+relative))
    with (W / 'test-portability.diff').open('x', encoding='utf-8') as stream: stream.write(''.join(delta))
    t.save(W / 'plan.json', plan)
    t.save(W / 'source-freeze.json', dict(status='FROZEN_NOT_SYNCED', expected=t.pin(W / 'expected-sources.json'),
        plan=t.pin(W / 'plan.json'), sources=sources, source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources),
        amended_tests=AMENDED, parent_source_freeze=plan['parent_source_freeze'],
        retained_weights=plan['retained_weights'], remote_driver=t.pin(W / 'driver.py'), helper=t.pin(__file__)))
    archive = W / 'thin-sync.tar.gz'
    with tarfile.open(archive, 'x:gz') as tar:
        for name in ('plan.json', 'source-freeze.json', 'driver.py', 'test-portability.diff'): tar.add(W / name, arcname=name)
        for row in sources: tar.add(W / 'source' / row['path'], arcname='source/' + row['path'])
    t.save(W / 'prepared.json', dict(archive=t.pin(archive), remote=remote, source_freeze=t.pin(W / 'source-freeze.json'),
        source_files=len(sources), source_bytes=sum(row['bytes'] for row in sources), new_CXX=1, retained_weights=weights['object']))
    print('FROZEN independent refinement1: one Tiny CXX, original successful weights retained; no remote action')


def configure_transport():
    plan = t.read(W / 'plan.json'); p.W, p.REMOTE = W, plan['remote']
    return plan


def parse(arm, label):
    spec = importlib.util.spec_from_file_location('frozen_native_report_parser', PARENT.parent / 'run.py')
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    parser.parse_output(arm, 'apple', W / ('readback-' + label) / 'records/runs' / arm, W / 'source-freeze.json')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'freeze': freeze()
    elif action == 'parse': parse(sys.argv[2], sys.argv[3])
    else:
        configure_transport()
        if action == 'sync': p.sync()
        elif action == 'fetch': p.fetch(sys.argv[2])
        elif action in ('preflight', 'link'): p.invoke(action)
        elif action == 'compile': p.invoke('compile', 'tiny')
        elif action == 'run': p.invoke('run', sys.argv[2])
        else: raise ValueError(action)
