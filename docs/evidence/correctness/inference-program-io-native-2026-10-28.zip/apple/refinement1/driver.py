"""Single-Tiny Apple retry; retain prior successful weights and original native SDK."""
from pathlib import Path
import importlib.util
import json
import os
import shlex
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())
spec = importlib.util.spec_from_file_location('original_native_recorder', P['original_remote_driver'])
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); b.W = W


def read(path): return json.loads(Path(path).read_text())
def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')
def exact(row):
    current = b.pin(row['path'])
    assert (current['bytes'], current['sha256']) == (row['bytes'], row['sha256']), row['path']
def verify():
    frozen = read(W / 'source-freeze.json')
    current = b.pin(__file__)
    assert (current['bytes'], current['sha256']) == (frozen['remote_driver']['bytes'], frozen['remote_driver']['sha256'])
    for row in frozen['sources']:
        current = b.pin(W / 'source' / row['path'])
        assert (current['bytes'], current['sha256']) == (row['bytes'], row['sha256']), row['path']
    assert b.pin(P['native_header']['path'])['sha256'] == P['native_header']['sha256']
    retained = P['retained_weights']; receipt = b.pin(retained['remote_receipt'])
    assert (receipt['bytes'], receipt['sha256']) == (retained['receipt']['bytes'], retained['receipt']['sha256'])
    record = read(retained['remote_receipt']); assert record == retained['record']
    assert record['process']['pid'] == 29058 and record['process']['exit'] == 0 and record['process']['timeout'] is False
    exact(record['object'])
    return frozen


def preflight():
    verify(); previous = read(P['parent_preflight']['remote'])
    identity = b.pin(P['parent_preflight']['remote']); prior = P['parent_preflight']['local']
    assert (identity['bytes'], identity['sha256']) == (prior['bytes'], prior['sha256'])
    assert previous['status'] == 'PASS' and len(previous['retained_stats']) == 118
    for row in previous['retained_stats']: assert b.stat(row['path']) == row, row['path']
    save(W / 'preflight.json', dict(status='PASS', retained_stats=previous['retained_stats'],
        retained_weights=P['retained_weights'], inputs=120, new_CXX=1, retained_SDK_inputs=118,
        header=b.pin(P['native_header']['path']), parent_preflight=identity))
    print('PREFLIGHT PASS: 118 original inputs and one successful weights object')


def compile_tiny():
    frozen = verify(); assert (W / 'preflight.json').is_file()
    unit = P['units'][0]; assert unit['name'] == 'tiny' and len(P['units']) == 1
    out = W / 'compile/tiny'; out.mkdir(parents=True, exist_ok=False)
    process = b.execute(unit['command'], out / 'logs', 300)
    verify(); text = (out / 'dependencies.d').read_text().replace('\\\n', '')
    actual = []
    for value in dict.fromkeys(shlex.split(text.split(':', 1)[1])):
        path = Path(value); path = path if path.is_absolute() else W / path
        row = b.pin(path) if path.is_relative_to(W / 'source') else b.stat(path)
        if path.name == 'apple_carrier.h':
            assert str(path) == P['native_header']['path']
            assert b.pin(path)['sha256'] == P['native_header']['sha256']
        actual.append(row)
    save(out / 'actual-dependencies.json', actual)
    save(out / 'compiled.json', dict(source=next(row for row in frozen['sources'] if row['path'] == unit['source']),
        object=b.pin(unit['object']), process=process, command=b.pin(out / 'logs/command.json'),
        dependencies=b.pin(out / 'dependencies.d'), actual_dependencies=b.pin(out / 'actual-dependencies.json')))
    print('CXX PASS Tiny; weights were not recompiled')


def link():
    verify(); unit = P['units'][0]; compiled = read(W / 'compile/tiny/compiled.json'); exact(compiled['object'])
    for row in read(W / 'preflight.json')['retained_stats']: assert b.stat(row['path']) == row
    weights = P['retained_weights']['record']
    original_weights = next(row for row in P['old_inputs'] if row['path'].endswith('/apple/compile/weights/unit.o'))
    replacements = {unit['old_object']['path']: compiled['object'], original_weights['path']: weights['object']}
    rows = [replacements.get(row['path'], row) for row in P['old_inputs'] if row['path'] != P['removed_entry']['object']]
    assert len(rows) == 120 and weights['object'] in rows and compiled['object'] in rows
    for row in rows: assert P['link_command'].count(row['path']) == 1, row['path']
    (W / 'bin').mkdir(exist_ok=True)
    process = b.execute(P['link_command'], W / 'link/logs', 240)
    save(W / 'inputs.json', rows)
    save(W / 'ready.json', dict(image=b.pin(W / 'bin/tiny'), inputs=b.pin(W / 'inputs.json'),
        compiled={'tiny': compiled, 'retained_weights': weights}, process=process,
        recipe=b.pin(W / 'link/logs/command.json'), plan=b.pin(W / 'plan.json'),
        source_freeze=b.pin(W / 'source-freeze.json'), runtime=P['runtime'],
        counts=dict(new_CXX=1, new_links=1, inputs=120, retained_SDK=118, retained_weights=1, new_Tiny=1)))
    print('LINK READY 120 inputs; original failed attempt preserved')


def run(arm):
    verify(); ready = read(W / 'ready.json')
    for field in ('image', 'inputs', 'source_freeze'): exact(ready[field])
    saved = {key: os.environ.get(key) for key in P['runtime']}; os.environ.update(P['runtime'])
    out = W / 'runs' / arm; assert not out.exists(), 'Already attempted; no automatic rerun'
    try:
        b.execute([ready['image']['path'], '--apple', P['fixture'], P['arms'][arm]], out, 300)
    finally:
        if (out / 'process.json').is_file():
            save(out / 'as-run.json', dict(image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'],
                runtime_overrides=P['runtime'], inherited_environment_whitelist={key: os.environ[key] for key in
                    ('PATH', 'DYLD_LIBRARY_PATH', 'DYLD_FALLBACK_LIBRARY_PATH', 'HOME', 'TMPDIR') if key in os.environ},
                process=read(out / 'process.json')))
        for key, value in saved.items():
            if value is None: os.environ.pop(key, None)
            else: os.environ[key] = value


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'preflight': preflight()
    elif action == 'compile': compile_tiny()
    elif action == 'link': link()
    elif action == 'run': run(sys.argv[2])
    else: raise ValueError(action)
