"""Local thin Apple preparation. Remote actions execute only when root invokes them."""
from pathlib import Path, PurePosixPath
import importlib.util
import io
import json
import re
import shlex
import sys
import tarfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
OLD = R / '.scratch/inference-native-state-only-20261028/apple'
RECORDS = OLD / 'readback-final/records'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-native-program-io-20261028'
BASE = '/Users/kiro/hyle-scratch/compute-unified/inference-native-state-only-20261028/apple'
COLD = BASE + '/cold-pruning'
spec = importlib.util.spec_from_file_location('native_program_windows_metadata', W.parent / 'build.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
t = v.t
spec = importlib.util.spec_from_file_location('original_apple_transport', OLD / 'build.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def prepare():
    assert not (W / 'plan.json').exists()
    old_ready = t.read(RECORDS / 'cold-pruning/ready-v2.json')
    old_inputs = t.read(RECORDS / 'cold-pruning/link-inputs-v2.json'); assert len(old_inputs) == 121
    entry_plan_path = R / '.scratch/inference-apple-engine-slots-20261027/plan.json'
    entry_plan = t.read(entry_plan_path)
    entry_job = next(job for job in entry_plan['jobs'] if job.get('source') == 'engine/main.cc')
    entry_object = entry_job['command'][entry_job['command'].index('-o') + 1]
    assert sum(row['path'] == entry_object for row in old_inputs) == 1
    units = []; replacements = {}
    for name, source, template in (
        ('tiny', 'tests/tools/qwen_host_image_test.cc', 'compile/model-v2/logs/command.json'),
        ('weights', 'engine/models/qwen35/weights.cc', 'compile/weights/logs/command.json')):
        old_command = t.command(RECORDS / template); command = list(old_command)
        old_source = old_command[old_command.index('-c') + 1]
        old_object = old_command[old_command.index('-o') + 1]
        assert sum(row['path'] == old_object for row in old_inputs) == 1
        command[command.index('-c') + 1] = REMOTE + '/source/' + source
        command[command.index('-o') + 1] = REMOTE + f'/compile/{name}/unit.o'
        command[command.index('-MF') + 1] = REMOTE + f'/compile/{name}/dependencies.d'
        # Current package contains no SDK/src overlay. Cold native headers must
        # precede source-v3's older apple_carrier declaration (f286, not 9f82).
        command[1:1] = ['-I' + REMOTE + '/source', '-I' + REMOTE + '/source/engine',
            '-I' + REMOTE + '/source/tests/tools', '-I' + COLD + '/source/include',
            '-I' + COLD + '/source', '-I' + COLD + '/source/src/compute_route_apple']
        assert '-DHYLE_COMPUTE_APPLE=1' in command and '-DHYLE_COMPUTE_CPU=1' in command
        assert '-O3' in command and '-std=c++23' in command and command[command.index('-arch') + 1] == 'arm64'
        units.append(dict(name=name, source=source, command=command, old_source=old_source,
            old_object=next(row for row in old_inputs if row['path'] == old_object),
            object=REMOTE + f'/compile/{name}/unit.o', template=t.pin(RECORDS / template)))
        replacements[old_object] = units[-1]['object']
    link = []
    old_link = t.command(RECORDS / 'cold-pruning/link-v2/logs/command.json')
    for at, arg in enumerate(old_link):
        if arg == entry_object: continue
        if at and old_link[at - 1] == '-o': arg = REMOTE + '/bin/tiny'
        elif arg.startswith('-Wl,-map,'): arg = '-Wl,-map,' + REMOTE + '/link/image.map'
        else: arg = replacements.get(arg, arg)
        link.append(arg)
    assert all(link.count(value) == 1 for value in replacements.values())
    assert sum(x.endswith(('.o', '.a', '.dylib')) for x in link) == 120
    t.save(W / 'plan.json', dict(status='PREPARED_UNFROZEN', remote=REMOTE, base=BASE, cold=COLD,
        local_base_ready=t.pin(RECORDS / 'cold-pruning/ready-v2.json'),
        local_base_inputs=t.pin(RECORDS / 'cold-pruning/link-inputs-v2.json'),
        local_link=t.pin(RECORDS / 'cold-pruning/link-v2/logs/command.json'),
        base_ready=COLD + '/ready-v2.json', base_inputs=COLD + '/link-inputs-v2.json',
        original_remote_driver=BASE + '/driver-v4.py', units=units, link_command=link, old_inputs=old_inputs,
        removed_entry=dict(source='engine/main.cc', object=entry_object, actual_recipe=entry_job,
            provenance=t.pin(entry_plan_path), reason='Combined Tiny source supplies its own main; no third CXX.'),
        runtime=old_ready['runtime'], fixture='/Users/kiro/hyle-scratch/compute-unified/inference-apple-engine-slots-20261027/fixture',
        native_header=dict(path=COLD + '/source/src/compute_route_apple/apple_carrier.h',
            sha256='f286ebe991efffb4de87b90e479b75e6c8a17b0300dc95bb5791e2f6e87cc106'),
        sdk_boundary=v.sdk_boundary(), counts=dict(CXX=2, links=1, baseline_inputs=121, inputs=120, unchanged_inputs=118,
            planned_Apple_model_processes=4, third_party_rebuilds=0, downloads=0),
        arms={'logits':'--mtp-logits', 'history':'--history-logits', 'replay':'--history-replay', 'control':'--history-control'},
        policy='Only reachable engine/tests files and two TUs are transferred at freeze. Existing source-v3, cold-pruning, installed SDK, MLX/Metal/BF16/cache libraries and fixture payloads stay remote. No freeze is implied by prepare.'))
    print('PREPARED UNFROZEN Apple 2TU / 120 inputs (121 minus CLI entry) / 4 arms; no remote command')


def freeze():
    plan = t.read(W / 'plan.json'); expected = t.read(W.parent / 'expected-sources.json')
    v.sdk_boundary()
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    pending = [R / unit['source'] for unit in plan['units']]; seen = {}
    while pending:
        path = pending.pop().resolve(); relative = path.relative_to(R).as_posix()
        if relative in seen: continue
        assert relative.startswith(('engine/', 'tests/')), relative
        seen[relative] = t.pin(path)
        for include in re.findall(r'^\s*#\s*include\s*[<"]([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((p.resolve() for root in (path.parent, R, R / 'engine', R / 'include') if (p := root / include).is_file()), None)
            if found and found.is_relative_to(R) and found.relative_to(R).parts[0] in ('engine', 'tests'): pending.append(found)
    assert all(relative in seen for relative in expected), 'Expected changed source is outside the actual thin consumer closure'
    sources = []
    for relative, original in seen.items():
        target = W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write((R / relative).read_bytes())
        sources.append(dict(path=relative, bytes=original['bytes'], sha256=original['sha256']))
    t.save(W / 'source-freeze.json', dict(status='FROZEN_NOT_SYNCED', expected=t.pin(W.parent / 'expected-sources.json'),
        plan=t.pin(W / 'plan.json'), sources=sources, source_files=len(sources), source_bytes=sum(x['bytes'] for x in sources),
        sdk_boundary=v.sdk_boundary(), remote_driver=t.pin(W / 'driver.py'), helper=t.pin(__file__)))
    archive = W / 'thin-sync.tar.gz'; assert not archive.exists()
    with tarfile.open(archive, 'x:gz') as tar:
        for name in ('plan.json', 'source-freeze.json', 'driver.py'): tar.add(W / name, arcname=name)
        for row in sources: tar.add(W / 'source' / row['path'], arcname='source/' + row['path'])
    t.save(W / 'prepared.json', dict(archive=t.pin(archive), remote=REMOTE,
        source_freeze=t.pin(W / 'source-freeze.json'), source_files=len(sources), source_bytes=sum(x['bytes'] for x in sources)))
    print('FROZEN THIN PACKAGE; no SSH or compiler invoked')


def sync():
    prepared = t.read(W / 'prepared.json'); t.exact(prepared['archive'])
    code = '''import io,pathlib,sys,tarfile
w=pathlib.Path(%r)
if w.exists() and any(w.iterdir()):raise RuntimeError('destination already exists; no overwrite')
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or p.is_absolute() or '..' in p.parts:raise RuntimeError('unsafe member')
 for m in t.getmembers():
  p=w/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
print('SYNCED',w)
''' % REMOTE
    m.call(m.SSH + ['python3 -c ' + shlex.quote(code)], W / 'sync', Path(prepared['archive']['path']).read_bytes())


def invoke(action, arg=None):
    command = ['python3', REMOTE + '/driver.py', action] + ([arg] if arg else [])
    label = action + ('-' + arg if arg else '')
    m.call(m.SSH + [shlex.join(command)], W / 'invocations' / label)


def fetch(label):
    out = W / ('readback-' + label); assert not out.exists(); out.mkdir()
    code = '''import io,pathlib,sys,tarfile
w=pathlib.Path(%r)
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as t:
 for sub in ('compile','link','runs'):
  for p in sorted((w/sub).rglob('*')):
   if p.is_file() and p.suffix in ('.json','.log','.d'):t.add(p,arcname='records/'+str(p.relative_to(w)))
 for name in ('ready.json','inputs.json','preflight.json','plan.json','source-freeze.json'):
  p=w/name
  if p.is_file():t.add(p,arcname='records/'+name)
''' % REMOTE
    # The original local transport records raw stdout to a file; here stdout is
    # the bounded evidence tar, not a model/SDK payload.
    m.call(m.SSH + ['python3 -c ' + shlex.quote(code)], out / 'transport')
    payload = (out / 'transport/stdout.log').read_bytes()
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as tar:
        for member in tar.getmembers():
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            target = out / str(path); target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream: stream.write(tar.extractfile(member).read())
    print('FETCHED', out)


def parse(arm, label):
    spec = importlib.util.spec_from_file_location('native_program_shared_parser', W.parent / 'run.py')
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    parser.parse_output(arm, 'apple', W / ('readback-' + label) / 'records/runs' / arm, W / 'source-freeze.json')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'sync': sync()
    elif action in ('preflight', 'compile', 'link', 'run'): invoke(action, sys.argv[2] if len(sys.argv) > 2 else None)
    elif action == 'fetch': fetch(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2], sys.argv[3])
    else: raise ValueError(action)
