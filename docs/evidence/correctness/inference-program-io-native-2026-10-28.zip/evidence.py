"""Offline evidence only. Never imports/runs builders, compilers, SSH or models."""
from pathlib import Path
import argparse, difflib, hashlib, json, re, zlib, zipfile
W=Path(__file__).resolve().parent
R=Path(r'C:\public\project-hyle\hyle')
DEST=R/'docs/evidence/correctness/inference-program-io-native-2026-10-28'
CASES={'logits':'mtp-logits-modifiers','history':'history-logits','replay':'history-replay','control':'history-control'}
EXPECTED={'logits':10,'history':17,'replay':9,'control':2}
SOURCE_NAMES={'program_io.h','program_carrier.h','prepared_output.h','readback.h','sampling_graph.h','main.cc',
 'qwen_host_image_test.cc','qwen_mtp_sampling_case.h','qwen_packed_prefill_case.h','qwen_mtp_logits_case.h',
 'qwen_history_logits_case.h','qwen_history_replay_case.h','qwen_history_control_case.h','inference_history_math_case.h',
 'vulkan_program.cc','native_region.cc','native_region.h','retained_output_reuse_consumer.cc','submission.cc','progress.cc','abi_size_guard.h',
 'region_access.h','plan_state.h','submission_internal.h','progress_internal.h','resource_episode.h','submission_lifetime.h'}
TEXT_EXT={'.json','.log','.py','.diff','.patch','.ps1','.txt','.d'}


def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def relative(p):return Path(p).resolve().relative_to(W).as_posix()
def terminal(p):
 v=read(p);assert v.get('pid') is not None and 'exit'in v,p
 assert not v.get('timed_out',v.get('timeout',False)),p
 return v

def producer(folder,backend,arm):
 folder=Path(folder);p=terminal(folder/'process.json')
 rows=[]
 for line in (folder/'stdout.log').read_text(encoding='utf-8-sig',errors='replace').splitlines():
  if line.startswith('{'):
   try:rows.append(json.loads(line))
   except json.JSONDecodeError:pass
 reports={row.get('case'):row for row in rows};report=reports.get(CASES[arm]);status='FAIL' if p['exit'] else 'UNCONFIRMED'
 checks=[]
 if p['exit']==0 and report is not None:
  assert report['backend']==backend and report['status']=='PASS' and report['models']==1,(folder,report)
  assert report['configurations']==(1 if arm=='control' else 2)
  assert report['final_versions']==0 and report['quality_claim'] is False and report['performance_claim'] is False
  checks=report['state_checks'];assert len(checks)==EXPECTED[arm],(folder,len(checks))
  for check in checks:
   assert check['boundary_equal'] is True and check['numerically_equivalent'] is True
   assert check['payloads_byte_equal'] is True and check['differences']==[],(folder,check)
  if arm=='history':assert reports['history-finite-math']['result']=='PASS'
  status='PASS'
 return dict(backend=backend,arm=arm,pid=p['pid'],exit=p['exit'],status=status,complete_state_byte_checks=len(checks) if status=='PASS' else None,
  process=relative(folder/'process.json'),stdout=relative(folder/'stdout.log'),stderr=relative(folder/'stderr.log'))

def failure(folder,label):
 folder=Path(folder);p=terminal(folder/'process.json')
 return dict(label=label,pid=p['pid'],exit=p['exit'],process=relative(folder/'process.json'),stderr=relative(folder/'stderr.log'))

def debugger_limitation():
 folder=W/'apple/refinement3/diagnose-history-map'
 stdout=(folder/'stdout.log').read_text(encoding='utf-8-sig')
 stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig')
 lines=[line.removeprefix('DIAGNOSTIC_PROCESS ')for line in stdout.splitlines()if line.startswith('DIAGNOSTIC_PROCESS ')]
 assert len(lines)==1
 debugger=json.loads(lines[0]);assert debugger['debugger_pid']==29421 and debugger['exit']==1
 assert debugger['reported_target_pids']==[] and 'cannot get permission to debug processes'in stderr
 wrapper=read(folder/'process.json')
 return dict(kind='noninteractive debugger permission denied',debugger_pid=debugger['debugger_pid'],exit=debugger['exit'],
  target_launched=False,reported_target_pids=[],transport_wrapper_pid=wrapper.get('pid'),
  counted_as_Model_or_CXX=False,raw_process=relative(folder/'process.json'),raw_stdout=relative(folder/'stdout.log'),
  raw_stderr=relative(folder/'stderr.log'),raw_command=relative(folder/'command.json'),
  interpretation='No target was launched and no exception stack was obtained. This is a diagnostic permission limitation, not another history Model attempt or a native/CXX failure/pass.')

def key_values(line):return dict(re.findall(r'(\w+)=([^\s]+)',line))
def diagnostic_cause():
 d=read(W/'vulkan-diag/old-tiny/runs/logits/diagnostic.json');events={int(key_values(s)['record']):key_values(s) for s in d['events']}
 outputs=[key_values(s) for s in d['outputs']]
 rejected=next(e for e in events.values() if e['where']=='can-detach-private-decrease')
 row=next(o for o in outputs if o['record']==rejected['record'] and int(o['current'])<int(o['baseline']))
 series=[]
 for record,e in events.items():
  if e['state']!=rejected['state'] or record>int(rejected['record']):continue
  matching=next((o for o in outputs if int(o['record'])==record and o['output']==row['output']),None)
  if matching:series.append(dict(where=e['where'],record=record,current=int(matching['current']),baseline=int(matching['baseline']),
   value_refs=int(matching['value_refs']),native_stage_refs=int(matching['native_stage_refs']),managed_parent_binding_refs=int(matching['managed_parent_binding_refs'])))
 create=next(x for x in series if x['where']=='create-baseline');seal=next(x for x in reversed(series) if x['where']in('seal','reseal'));failed=series[-1]
 assert(create['baseline'],seal['baseline'],failed['current'])==(13,18,15),series
 assert all(seal[k]==failed[k]==v for k,v in [('value_refs',4),('native_stage_refs',2),('managed_parent_binding_refs',2)])
 return dict(process_pid=d['process']['pid'],state=rejected['state'],output=int(row['output']),alias_root=int(row['alias_root']),
  series=series,measured_local_refs_unchanged=True,opaque_managed_region_private_refs_measured=False,
  interpretation='The old global shared-owner count fell after other retired regions detached; the visible own value/native/managed parent references stayed 4/2/2. This is the diagnosed old-count gate failure, not a new escaped writer permission.')

def is_apple_model_command(p):
 # Producer runs are direct calls to the retained Tiny image. A debugger may
 # contain the same argv after '--', but its PID belongs to the debugger.
 if not Path(p).is_file():return False
 value=read(p);args=value.get('command',value)if isinstance(value,dict)else value
 return isinstance(args,list)and bool(args)and Path(str(args[0])).name.lower()in('tiny','tiny.exe','tiny-current.exe','tiny-old-tiny.exe')and '--apple'in args and any(flag in args for flag in('--mtp-logits','--history-logits','--history-replay','--history-control'))

def classify_command(p):
 v=read(p);a=v.get('command',v) if isinstance(v,dict)else v
 if not isinstance(a,list):return None
 lower=[str(x).lower() for x in a]
 first=Path(str(a[0])).name.lower() if a else ''
 compiler=first in('cl.exe','clang++','clang','c++','g++')or(first=='xcrun'and any(Path(str(x)).name.lower()in('clang++','clang','c++')for x in a[1:5]))
 if compiler and('/c'in lower or '-c'in lower):return 'CXX'
 if first in('link.exe','ld') or ('-o'in a and (first in('c++','clang++','g++') or any('clang' in str(x) for x in a[:2]))):return 'link'
 if first in('ar','llvm-ar','lib.exe'):return 'archive'
 return None

def operation_rows(mac):
 rows=[]
 # Only native/compiler producer logs; transport/SSH/readback wrapper processes
 # are preserved as artifacts but never counted as compilation/model work.
 win=[('logs/tiny','CXX'),('logs/weights','CXX'),('cuda/logs/tiny','CXX'),
  ('vulkan-diag/logs/program','CXX'),('vulkan-diag/logs/tiny','CXX'),('vulkan-current/logs/program','CXX'),('vulkan-current/reader/logs/test','CXX'),
  ('link','link'),('cuda/link/tiny','link'),('vulkan-diag/old-tiny/link','link'),('vulkan-current/link','link'),('vulkan-current/reader/link','link')]
 for name,kind in win:
  p=terminal(W/name/'process.json');rows.append(dict(platform='Windows',kind=kind,pid=p['pid'],exit=p['exit'],process=relative(W/name/'process.json')))
 roots=list(dict.fromkeys([W/'apple/readback-compile/records',*sorted((W/'apple').glob('refinement*/readback*/records')),mac]))
 seen=set()
 for root in roots:
  for procpath in sorted(root.rglob('process.json')):
   rel=procpath.relative_to(root).as_posix()
   if not(rel.startswith('compile/')or rel.startswith('link/')):continue
   command=procpath.with_name('command.json')
   if not command.exists():continue
   kind=classify_command(command)
   if kind is None:continue
   p=terminal(procpath);identity=(p['pid'],p.get('started_utc',p.get('started')))
   if identity in seen:continue
   seen.add(identity);rows.append(dict(platform='Mac',kind=kind,pid=p['pid'],exit=p['exit'],process=relative(procpath)))
 return rows

def gather(mac):
 runs=[producer(W/'cuda/runs'/f'{arm}-{backend}',backend,arm)for backend in('cpu','cuda')for arm in CASES]
 runs += [producer(W/'vulkan-current/runs'/arm,'vulkan',arm)for arm in CASES]
 mac_runs=[]
 for arm in CASES:
  folder=mac/'runs'/arm
  if not(folder/'process.json').exists():mac_runs.append(dict(backend='apple',arm=arm,status='NOT_RUN',complete_state_byte_checks=None))
  else:mac_runs.append(producer(folder,'apple',arm))
 runs+=mac_runs
 for backend in('cpu','cuda','vulkan'):
  selected=[x for x in runs if x['backend']==backend];assert len(selected)==4 and all(x['status']=='PASS' for x in selected)
 reader=terminal(W/'vulkan-current/reader/run/process.json');assert reader['pid']==49688 and reader['exit']==0
 assert 'PASS Vulkan 3 cases:' in (W/'vulkan-current/reader/run/stdout.log').read_text(encoding='utf-8-sig')
 failures=[failure(W/'runs/logits','original Vulkan Model consumer'),failure(W/'vulkan-diag/old-tiny/runs/logits','diagnostic original Vulkan consumer')]
 # Preserve every actual prior Mac consumer failure once, including repeated
 # fetches of the same producer. Transport/wrapper PID is never a model PID.
 final_ids={(x.get('pid'),x.get('arm'))for x in mac_runs if x.get('pid') is not None}
 seen_failures=set()
 for records in sorted((W/'apple').glob('refinement*/readback*/records')):
  for process in sorted((records/'runs').glob('*/process.json')):
   if not is_apple_model_command(process.with_name('command.json')):continue
   value=terminal(process);arm=process.parent.name
   identity=(value['pid'],value.get('started_utc',value.get('started')))
   if value['exit']==0 or identity in seen_failures or (value['pid'],arm)in final_ids:continue
   seen_failures.add(identity)
   failures.append(failure(process.parent,'Apple prior backend Model consumer; see exact stage source/closure'))
 operations=operation_rows(mac)
 original_tiny=terminal(W/'apple/readback-compile/records/compile/tiny/logs/process.json');assert original_tiny['pid']==29059 and original_tiny['exit']!=0
 diag_tiny=terminal(W/'vulkan-diag/logs/tiny/process.json');assert diag_tiny['pid']==20068 and diag_tiny['exit']==2
 ready_mac=read(mac/'ready.json')if(mac/'ready.json').exists()else None
 mac_input_count=len(read(mac/'inputs.json'))if(mac/'inputs.json').exists()else None
 if mac_input_count is not None:assert mac_input_count==120
 summary=dict(schema=1,title='ProgramIo native consumers and retained-output rearm',date='2026-10-28',
  status='PASS_FINITE_NATIVE_SCOPE' if all(x['status']=='PASS'for x in runs)else 'PARTIAL_OR_FAILED',
  architecture=dict(migrated=['NextN fixed/dynamic IO and retained q/counts','prefix program IO','frontier IO'],
   carrier='Original ProgramCarrier owns Invocation/queue bindings/retention; ProgramIo is cold immutable IO schema plus original PreparedReadback, not another executor or authority owner.',
   unchanged='Original Graph bind/output permissions, pools/budgets, Completion, Step Store/Append, whole status, numeric validators and publication. Frontier fresh reset; prefix/NextN reuse.'),
  checked_scope=dict(fixture='Cached small synthetic GA/H64/V64/C16',entry='Original Model generation entry and RequestWindow consumers; not a new full RequestLoop service test',
   state_byte_checks={backend:(sum(x['complete_state_byte_checks']for x in runs if x['backend']==backend) if all(x['complete_state_byte_checks'] is not None for x in runs if x['backend']==backend) else None)for backend in('cpu','cuda','vulkan','apple')},
   verified_subtotal={backend:sum(x['complete_state_byte_checks']for x in runs if x['backend']==backend and x['status']=='PASS')for backend in('cpu','cuda','vulkan','apple')},
   verified_all_backend_subtotal=sum(x['complete_state_byte_checks']for x in runs if x['status']=='PASS'),
   reader=dict(pid=reader['pid'],exit=reader['exit'],original_cases=3,scope='F32/BF16 escaped independent whole/slice readonly old bytes, budgets/retry, stale submit, bounded spare and IO ranges'),
   quality_claim=False,performance_claim=False,all_platforms_claim=False,unknown_native_failure_pass_claim=False),
  model_processes=runs,prior_consumer_failures=failures,actual_compile_link_processes=operations,
  operation_counts={platform:{kind:dict(attempts=sum(x['platform']==platform and x['kind']==kind for x in operations),passed=sum(x['platform']==platform and x['kind']==kind and x['exit']==0 for x in operations),failed=sum(x['platform']==platform and x['kind']==kind and x['exit']!=0 for x in operations))for kind in('CXX','link','archive')}for platform in('Windows','Mac')},
  diagnostic=diagnostic_cause(),debugger_limitations=[debugger_limitation()],
  provenance=dict(original_program_io_sources=pin(W/'source-freeze.json'),cpu_cuda_sources=pin(W/'cuda/source-freeze.json'),
   windows_consumers='Historical successful Tiny/weights compilation receipts and frozen snapshots are retained; current equivalent portability header hashes are not written back into old compiled records.',
   mac_final_sources=pin(mac/'source-freeze.json')if(mac/'source-freeze.json').exists()else None,
   apple_projected_bank_fix=pin(W/'apple/refinement3/source/src/graph_route_apple/native_region.cc'),
   apple_projected_bank_fix_freeze=pin(W/'apple/refinement3/source-freeze.json')),
  vulkan_fix=dict(source=read(W/'vulkan-current/source-freeze.json')['snapshot'],
   gate='Only opt-in retained_output_reuse nonconstant owned output avoids the old shared-owner count proof. owned_output_block, input-alias refusal, actual retirement and forced new output epoch remain; direct/constant exact count gates remain.',
   diagnostic_printf_in_product=False),
  refinements=[
   dict(kind='test portability only',fact='Mac Tiny29059 failed strict Clang: split size_t/uint64 auto declaration, differences{} DMI and four explicit neutral modifiers{}; numerical assertions unchanged, successful weights retained.'),
   dict(kind='diagnostic-only CXX failure',fact='Tiny20068 failed mixed copied/canonical pragma-once definitions. It was never linked; diagnostic48700 reused the original successful Tiny/weights with the successful diagnostic SDK TU. No product change came from this compiler failure.'),
   dict(kind='prelaunch helper fault',note='cuda/prelaunch-note.json',fact='Concurrent native hardlink FileExistsError occurred before Model PID/arm-directory creation. It is not a native model failure or an extra inference attempt; actual first CPU logits PID39984 passed. Successful CUDA was not rerun.'),
   dict(kind='link closure refinement',fact='Remove independent CLI main supplied by the test: Vulkan170→169 and Mac121→120, not a CXX failure.'),
   dict(kind='Mac private ABI refresh',fact='The two SDK ABI consumers were refreshed after the first Apple runtime failure. This alone is not a model PASS: the next actual consumer PID29252 failed the projected-bank storage gate.'),
   dict(kind='Apple projected-bank selection',fact='Ordinary checked Gather may bind a lawful NativeRef. The frozen native_region.cc refinement distinguishes this from an address-only projected bank; final producer results determine the tested boundary.'),
   dict(kind='post-CXX metadata repair',fact='Region CXX PID29306 exited0 once. Relative ../ actual-dependency paths initially failed wrapper metadata parsing, then the sidecar resolved paths and parsed the original successful object; no successful CXX was repeated.'),
   dict(kind='actual Mac provenance',fact='Final Mac records and parse-compile sidecar/actual-dependencies receipts are authoritative. Only real producer compile/link/run PID/exit are counted; transports/fetch copies are not duplicate work.')],
  closures=dict(cpu_cuda=read(W/'cuda/ready-tiny.json')['inputs'],vulkan=read(W/'vulkan-current/ready.json')['inputs'],reader=read(W/'vulkan-current/reader/ready.json')['inputs'],
   apple=dict(records=relative(mac),input_count=mac_input_count,ready=pin(mac/'ready.json')if ready_mac else None)),
  limitations=['Finite synthetic functionality and complete-state bytes only; no trained quality, TPS, latency or memory-peak conclusion.',
   'Default math/ports and existing policies are preserved; this is a bounded IO lifecycle migration, not complete engine extraction.',
   'Apple history29362 remains a cold MLX compile unordered_map::at failure; LLDB29421 was denied noninteractive permission before any target launch, so its cause is not established by a captured stack.',
   'No new downloads, SDK rebuild, NVCC, shader build or rerun is performed by this offline collector.'])
 return summary

def wanted(path):
 if not path.is_file():return False
 rel=path.relative_to(W)
 if rel.parts[0]=='packaging':return False
 if path.suffix.lower()in TEXT_EXT:return True
 return path.name in SOURCE_NAMES and path.suffix.lower()in('.h','.cc')

def payloads(mac,summary):
 selected={relative(p):p.read_bytes()for p in sorted(W.rglob('*'))if wanted(p)}
 # Do not acquire dependencies/payloads via recorded paths. Only this bounded
 # workspace and explicitly frozen source snapshots enter the archive.
 selected['summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
 before=R/'.scratch/inference-program-io-20261028/main-before.cc'
 after=W/'source/engine/models/qwen35/main.cc'
 if before.exists():
  diff=''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),after.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/main.cc',tofile='ProgramIo/main.cc'))
  selected['derived/main-program-io.diff']=diff.encode()
  selected['derived/main-before-identity.json']=(json.dumps(pin(before),indent=2)+'\n').encode()
 before=W/'vulkan-diag/source-base/vulkan_program.cc';after=W/'vulkan-current/source/vulkan_program.cc'
 diff=''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),after.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/vulkan_program.cc',tofile='current/vulkan_program.cc'))
 selected['derived/vulkan-owned-rearm.diff']=diff.encode()
 return selected

def package(mac):
 mac=Path(mac).resolve();assert mac.is_dir() and W in mac.parents,mac
 # Missing records stay NOT_RUN and are never silently promoted to PASS.
 summary=gather(mac);members=payloads(mac,summary)
 assert not DEST.with_suffix('.json').exists()and not DEST.with_suffix('.zip').exists(),'Evidence is single-write; preserve prior package'
 manifest=[dict(name=name,bytes=len(data),sha256=sha(data),crc32=f'{zlib.crc32(data)&0xffffffff:08x}')for name,data in sorted(members.items())]
 manifest_data=(json.dumps(dict(payload_members=manifest,self_entry='Manifest itself is verified against its separately recorded identity.'),indent=2)+'\n').encode()
 members['member-manifest.json']=manifest_data
 DEST.parent.mkdir(parents=True,exist_ok=True)
 archive=DEST.with_suffix('.zip')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,data in sorted(members.items()):z.writestr(name,data)
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None
  assert set(z.namelist())==set(members)
  for name,expected in members.items():
   actual=z.read(name);info=z.getinfo(name)
   assert len(actual)==len(expected)and sha(actual)==sha(expected)and info.CRC==(zlib.crc32(expected)&0xffffffff),name
 summary['archive']={**pin(archive),'members':len(members),'all_member_sha256_and_crc_readback':True,
  'member_manifest':dict(name='member-manifest.json',bytes=len(manifest_data),sha256=sha(manifest_data),crc32=f'{zlib.crc32(manifest_data)&0xffffffff:08x}'),
  'excludes':['EXE/OBJ/O/PDB/LIB/A/EXP/DLL','SDK/system/dependency payloads','model/weights/GGUF/fixture payloads','tar/sync payloads']}
 target=DEST.with_suffix('.json');target.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
 assert read(target)==summary
 print(json.dumps(dict(status=summary['status'],evidence=pin(target),archive=summary['archive'],checks=summary['checked_scope']['state_byte_checks'],verified_subtotal=summary['checked_scope']['verified_subtotal'],verified_all_backend_subtotal=summary['checked_scope']['verified_all_backend_subtotal']),indent=2))

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--mac',required=True,help='Actual final fetched records directory under this W; never SSH wrappers')
 args=parser.parse_args();package(args.mac)
