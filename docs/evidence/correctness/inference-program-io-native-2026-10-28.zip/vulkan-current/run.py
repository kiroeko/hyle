"""Four original finite consumers; use original parser without old source validation."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parent
spec=importlib.util.spec_from_file_location('vulkan_current_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
t,R=b.t,b.R
ARMS={'logits':'--mtp-logits','history':'--history-logits','replay':'--history-replay','control':'--history-control'}

def prepare():
    p,_=b.load()
    t.save(W/'run-plan.json',dict(status='PLANNED_NOT_RUN',parser=t.pin(__file__),original_parser=p['original_parser'],plan=t.pin(W/'plan.json'),order=list(ARMS),model_processes=4,
        commands={name:[str(W/'bin/tiny-current.exe'),'--vulkan',p['fixture'],flag] for name,flag in ARMS.items()},timeout_seconds=300))
    print('PLANNED four original consumers; no execution')

def parse(arm):
    rp=t.read(W/'run-plan.json');t.exact(rp['original_parser'])
    spec=importlib.util.spec_from_file_location('original_program_io_parser',rp['original_parser']['path']);original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
    # This pure parser reads original producer output only. Do not call its
    # b.validate(), which belongs to the earlier SDK and header identities.
    original.parse_output(arm,'vulkan',W/'runs'/arm,W/'source-freeze.json')

def run(arm):
    p,_=b.load();rp=t.read(W/'run-plan.json');t.exact(rp['parser']);t.exact(rp['plan']);assert arm in ARMS
    ready=t.read(W/'ready.json');t.exact(ready['image']);t.exact(ready['native_hardlink'])
    runtime=t.read(p['runtime']['path']);assert os.path.samefile(runtime['native']['path'],runtime['hardlink_on_link'])
    out=W/'runs'/arm;assert not out.exists(),'Already attempted: parse original files offline, no rerun'
    try:t.execute(rp['commands'][arm],out,300,runtime=True)
    finally:
        if(out/'process.json').exists():t.save(out/'as-run.json',dict(ready=t.pin(W/'ready.json'),image=ready['image'],inputs=ready['inputs'],source_freeze=ready['source_freeze'],parent_source_freeze=ready['parent_source_freeze'],run_plan=t.pin(W/'run-plan.json'),native=ready['native_hardlink'],process=t.read(out/'process.json')))
    parse(arm)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='run':run(sys.argv[2])
    elif action=='parse':parse(sys.argv[2])
    else:raise ValueError(action)
