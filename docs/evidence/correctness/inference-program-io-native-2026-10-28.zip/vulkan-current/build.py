"""Current Vulkan source-only fix: one SDK TU, original successful Tiny/weights."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parent;R=Path(r'C:\public\project-hyle\hyle')
spec=importlib.util.spec_from_file_location('original_vulkan_runner_current',R/'.scratch/inference-native-state-only-20261028/vulkan/build.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
t.W,t.R=W,R

def prepare():
    assert not (W/'plan.json').exists()
    old=t.read(P/'ready.json');t.exact(old['inputs']);rows=t.read(old['inputs']['path']);assert len(rows)==169
    prior=t.read(P/'vulkan-diag/compile/program/compiled.json');recipe=prior['unit']['original_command'];deps=prior['dependencies']
    t.exact(recipe);t.exact(deps)
    source=R/'src/compute_route_vulkan/vulkan_program.cc';data=source.read_bytes()
    assert b'const bool rearm_owned = state->retained_output_reuse' in data and b'VK_IO' not in data
    snapshot=W/'source/vulkan_program.cc';snapshot.parent.mkdir(parents=True,exist_ok=True)
    with snapshot.open('xb') as f:f.write(data)
    args=t.command(recipe['path']);command=[]
    for i,arg in enumerate(args):
        if t.key(arg)==t.key(source):arg=str(snapshot)
        elif i and args[i-1].lower()=='/sourcedependencies':arg=str(W/'compile/program/dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(W/'compile/program/unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(W/'compile/program/unit.pdb')
        command.append(arg)
    command.insert(1,'/I'+str(source.parent))
    assert command.count(str(snapshot))==1
    t.save(W/'recipe-program.json',dict(command=command,cwd=str(R),timeout_seconds=300))
    known={}
    for path in t.depfiles(deps['path']):
        if t.key(path)==t.key(prior['source']['path']):continue
        known[t.key(path)]=t.pin(path)
    for path in [source,snapshot]:known[t.key(path)]=t.pin(path)
    t.save(W/'dependencies-prepin.json',list(known.values()))
    t.save(W/'source-freeze.json',dict(status='SOURCE_SNAPSHOT_CURRENT_FIX',source=t.pin(source),snapshot=t.pin(snapshot),dependencies=t.pin(W/'dependencies-prepin.json'),
        original_recipe=recipe,original_actual_dependencies=deps,SDK_delta=['src/compute_route_vulkan/vulkan_program.cc'],
        scope='The canonical SDK implementation changed. No empty-sdk-boundary exemption applies. Header layouts are not changed by this patch; retained native/Graph objects keep their original identities. Original successful consumer objects retain their historical source/Includes receipts.'))
    original=prior['unit']['old_object'];assert sum(t.key(row['path'])==t.key(original['path']) for row in rows)==1
    link=[]
    for arg in t.command(old['recipe']['path']):
        if t.key(arg)==t.key(original['path']):arg=str(W/'compile/program/unit.obj')
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map'),('/ILK:','.ilk')):
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/tiny-current').with_suffix(suffix));break
        link.append(arg)
    assert not any('/engine/entry/unit.obj' in t.key(a) or '/vulkan-diag/' in t.key(a) for a in link)
    t.save(W/'recipe-link.json',dict(command=link,cwd=str(R),timeout_seconds=240))
    retained=[row for row in rows if t.key(row['path'])!=t.key(original['path'])];assert len(retained)==168
    stats=[]
    for row in retained:
        st=Path(row['path']).stat();assert st.st_size==row['bytes'];stats.append(dict(path=row['path'],bytes=st.st_size,mtime_ns=st.st_mtime_ns))
    t.save(W/'retained-stats.json',stats)
    t.save(W/'environment.json',t.read(P/'environment.json'))
    runtime=t.read(P/'runtime.json');runtime['PATH']=str(W/'bin')+';'+runtime['PATH'];runtime['hardlink_on_link']=str(W/'bin'/Path(runtime['native']['path']).name)
    t.save(W/'runtime.json',runtime)
    pp=t.read(P/'plan.json')
    t.save(W/'plan.json',dict(status='PREPARED_CURRENT_SDK_NOT_COMPILED',helper=t.pin(__file__),original_ready=t.pin(P/'ready.json'),inputs=old['inputs'],
        original_successful_consumers=old['compiled'],parent_source_freeze=old['source_freeze'],source_freeze=t.pin(W/'source-freeze.json'),
        old_object=original,recipe=t.pin(W/'recipe-program.json'),link=t.pin(W/'recipe-link.json'),retained_stats=t.pin(W/'retained-stats.json'),
        environment=t.pin(W/'environment.json'),runtime=t.pin(W/'runtime.json'),fixture=pp['fixture'],fixture_manifest=pp['fixture_manifest'],
        original_runner=t.pin(R/'.scratch/inference-native-state-only-20261028/vulkan/build.py'),original_parser=t.pin(P/'run.py'),
        diagnostic_process=t.pin(P/'vulkan-diag/old-tiny/runs/logits/process.json'),
        budgets=dict(CXX=1,SDK_TU=1,Tiny_CXX=0,weights_CXX=0,links=1,model_processes=4,inputs=169,retained_SDK=166,CLI_entries=0,diagnostic_objects=0),
        scope='Only current canonical SDK program changes; original successful Tiny and weights remain. Four finite original logits/history/replay/control consumers, no new framework or numerical oracle.'))
    print('PREPARED current program1CXX + link, 169inputs, four planned consumers; no execution')

def load():
    p=t.read(W/'plan.json')
    for key in ('helper','original_ready','inputs','parent_source_freeze','source_freeze','recipe','link','retained_stats','environment','runtime','fixture_manifest','original_runner','original_parser','diagnostic_process'):t.exact(p[key])
    frozen=t.read(p['source_freeze']['path'])
    for key in ('source','snapshot','dependencies','original_recipe','original_actual_dependencies'):t.exact(frozen[key])
    return p,frozen

def freeze():
    p,f=load()
    for row in t.read(f['dependencies']['path']):t.exact(row)
    t.save(W/'freeze.json',dict(status='FROZEN_CURRENT_SDK_NOT_COMPILED',plan=t.pin(W/'plan.json'),helper=t.pin(__file__),source_freeze=p['source_freeze']))
    print('FROZEN, 0CXX/0link/0run')

def parse_compile():
    p,f=load();proc=t.read(W/'logs/program/process.json');assert proc['exit']==0 and not proc['timed_out']
    known={t.key(x['path']):x for x in t.read(f['dependencies']['path'])};actual=[];external=[]
    for path in t.depfiles(W/'compile/program/dependencies.json'):
        row=known.get(t.key(path))
        if row is None:
            assert not t.project(path) and not W in Path(path).resolve().parents,('Successful compiler; missing project prepin is metadata-only, do not recompile',path)
            row=t.pin(path);external.append(row)
        else:t.exact(row)
        actual.append(row)
    t.save(W/'compile/program/actual-dependencies.json',actual)
    t.save(W/'compile/program/compiled.json',dict(source=f['snapshot'],canonical_source=f['source'],object=t.pin(W/'compile/program/unit.obj'),process=proc,
        command=t.pin(W/'logs/program/command.json'),dependencies=t.pin(W/'compile/program/dependencies.json'),actual_dependencies=t.pin(W/'compile/program/actual-dependencies.json'),external_postcompile_additions=external))
    print('PARSED current program')

def compile_one():
    p,f=load();t.exact(t.read(W/'freeze.json')['helper'])
    for row in t.read(f['dependencies']['path']):t.exact(row)
    (W/'compile/program').mkdir(parents=True,exist_ok=False)
    t.execute(t.command(p['recipe']['path']),W/'logs/program',300);parse_compile()

def link():
    p,_=load();compiled=t.read(W/'compile/program/compiled.json');t.exact(compiled['object'])
    rows=t.read(p['inputs']['path']);matches=[i for i,x in enumerate(rows) if t.key(x['path'])==t.key(p['old_object']['path'])];assert len(matches)==1
    rows[matches[0]]=compiled['object'];assert len(rows)==169
    for row in t.read(p['retained_stats']['path']):
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    (W/'bin').mkdir(exist_ok=True);t.save(W/'inputs.json',rows)
    proc=t.execute(t.command(p['link']['path']),W/'link',240)
    runtime=t.read(p['runtime']['path']);t.exact(runtime['native']);alias=Path(runtime['hardlink_on_link']);assert not alias.exists();os.link(runtime['native']['path'],alias)
    assert os.path.samefile(runtime['native']['path'],alias)
    t.save(W/'ready.json',dict(image=t.pin(W/'bin/tiny-current.exe'),inputs=t.pin(W/'inputs.json'),compiled=[compiled],retained_consumers=p['original_successful_consumers'],
        process=proc,recipe=t.pin(W/'link/command.json'),plan=t.pin(W/'plan.json'),source_freeze=p['source_freeze'],parent_source_freeze=p['parent_source_freeze'],runtime=p['runtime'],native_hardlink=t.pin(alias)))
    print('CURRENT LINK READY; no model process')

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='compile':compile_one()
    elif action=='parse-compile':parse_compile()
    elif action=='link':link()
    else:raise ValueError(action)
