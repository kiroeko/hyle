"""Existing retained-output regression on the same current SDK; no Model objects."""
from pathlib import Path
import importlib.util,re,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;Q=W/'reader';P=W.parent;R=Path(r'C:\public\project-hyle\hyle')
spec=importlib.util.spec_from_file_location('current_vulkan_program_reader',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
t=b.t;t.W=Q

def prepare():
    assert not(Q/'plan.json').exists()
    p,_=b.load();base=R/'.scratch/vulkan-qwen-assembly-20261022';identity=t.read(base/'compile3/test/identity.json')
    source=R/'tests/graph_route_vulkan/retained_output_reuse_consumer.cc';text=source.read_text(encoding='utf-8')
    assert t.pin(source)==identity['source'];assert re.search(r'\bint\s+main\s*\(',text)
    snapshot=Q/'source/retained_output_reuse_consumer.cc';snapshot.parent.mkdir(parents=True,exist_ok=True)
    with snapshot.open('xb') as f:f.write(source.read_bytes())
    old_recipe=base/'compile3/test/compile.command.json';args=t.command(old_recipe);command=[]
    for i,arg in enumerate(args):
        if t.key(arg)==t.key(source):arg=str(snapshot)
        elif i and args[i-1].lower()=='/sourcedependencies':arg=str(Q/'compile/test/dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(Q/'compile/test/unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(Q/'compile/test/unit.pdb')
        command.append(arg)
    assert command.count(str(snapshot))==1
    assert '/DHYLE_COMPUTE_VULKAN=1' in command
    assert '/sourceDependencies' in command
    t.save(Q/'recipe-test.json',dict(command=command,cwd=str(R),timeout_seconds=300))
    known={}
    for row in identity['dependencies']:
        path=Path(row['path'])
        if path.is_file():known[t.key(path)]=t.pin(path)
    pending=[source,snapshot];seen=set();roots=[source.parent,R/'include',R]
    while pending:
        path=pending.pop().resolve();key=t.key(path)
        if key in seen:continue
        seen.add(key);known[key]=t.pin(path)
        for inc in re.findall(r'^\s*#\s*include\s*[<"]([^>"\r\n]+)[>"]',path.read_text(encoding='utf-8-sig',errors='replace'),re.M):
            target=next((q.resolve() for root in [path.parent,*roots] if(q:=root/inc).is_file()),None)
            if target and t.project(target):pending.append(target)
    t.save(Q/'dependencies-prepin.json',list(known.values()))
    t.save(Q/'source-freeze.json',dict(source=t.pin(source),snapshot=t.pin(snapshot),dependencies=t.pin(Q/'dependencies-prepin.json'),
        original_recipe=t.pin(old_recipe),original_identity=t.pin(base/'compile3/test/identity.json'),prior_ready=t.pin(base/'test-link3/ready.json'),
        prior_process=t.pin(base/'test-run3/run.result.json'),scope='Existing source is byte-identical to its last tested source, but it is recompiled with current canonical public headers; old test OBJ is not reused.'))
    current=t.command(p['link']['path']);consumers=p['original_successful_consumers'];removed={t.key(x['object']['path']) for x in consumers}
    assert len(removed)==2
    link=[]
    for arg in current:
        if t.key(arg) in removed:continue
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map'),('/ILK:','.ilk')):
            if arg.upper().startswith(prefix):arg=prefix+str((Q/'bin/retained-output').with_suffix(suffix));break
        link.append(arg)
    link.insert(1,str(Q/'compile/test/unit.obj'))
    assert not any(t.key(a) in removed or '/engine/entry/unit.obj' in t.key(a) or '/vulkan-diag/' in t.key(a) for a in link)
    t.save(Q/'recipe-link.json',dict(command=link,cwd=str(R),timeout_seconds=240))
    t.save(Q/'environment.json',t.read(W/'environment.json'))
    runtime=t.read(W/'runtime.json');runtime['PATH']=str(Q/'bin')+';'+runtime['PATH'];runtime['hardlink_on_link']=str(Q/'bin'/Path(runtime['native']['path']).name)
    t.save(Q/'runtime.json',runtime)
    t.save(Q/'plan.json',dict(status='PREPARED_NOT_COMPILED',helper=t.pin(__file__),current_sdk_plan=t.pin(W/'plan.json'),source_freeze=t.pin(Q/'source-freeze.json'),
        recipe=t.pin(Q/'recipe-test.json'),link=t.pin(Q/'recipe-link.json'),environment=t.pin(Q/'environment.json'),runtime=t.pin(Q/'runtime.json'),
        removed_consumers=[x['object'] for x in consumers],budgets=dict(additional_test_CXX=1,SDK_CXX=0,links=1,processes=1,inputs=168,Model_objects=0,new_fixtures=0,downloads=0),
        scope='Original F32 Neg/BF16 Cast three generations, escaped independent whole/slice readonly leases and unchanged old bytes, GraphOutput pin gate, stale-submit rejection, budget rejection/retry, bounded-spare reuse plus original IO ranges. No new test framework.'))
    print('PREPARED reader1CXX + separate168link + one run; no execution')

def load():
    p=t.read(Q/'plan.json')
    for key in('helper','current_sdk_plan','source_freeze','recipe','link','environment','runtime'):t.exact(p[key])
    b.load();f=t.read(p['source_freeze']['path'])
    for key in('source','snapshot','dependencies','original_recipe','original_identity','prior_ready','prior_process'):t.exact(f[key])
    return p,f

def parse_compile():
    p,f=load();proc=t.read(Q/'logs/test/process.json');assert proc['exit']==0 and not proc['timed_out']
    known={t.key(x['path']):x for x in t.read(f['dependencies']['path'])};actual=[];external=[]
    for path in t.depfiles(Q/'compile/test/dependencies.json'):
        row=known.get(t.key(path))
        if row is None:
            assert not t.project(path) and not Q in Path(path).resolve().parents,('Successful compiler; missing project prepin is metadata-only, do not recompile',path)
            row=t.pin(path);external.append(row)
        else:t.exact(row)
        actual.append(row)
    t.save(Q/'compile/test/actual-dependencies.json',actual)
    t.save(Q/'compile/test/compiled.json',dict(source=f['snapshot'],canonical_source=f['source'],object=t.pin(Q/'compile/test/unit.obj'),process=proc,
        command=t.pin(Q/'logs/test/command.json'),dependencies=t.pin(Q/'compile/test/dependencies.json'),actual_dependencies=t.pin(Q/'compile/test/actual-dependencies.json'),external_postcompile_additions=external))
    print('PARSED reader')

def compile_one():
    p,f=load()
    for row in t.read(f['dependencies']['path']):t.exact(row)
    (Q/'compile/test').mkdir(parents=True,exist_ok=False)
    t.execute(t.command(p['recipe']['path']),Q/'logs/test',300);parse_compile()

def link():
    p,_=load();parent,_=b.load();program=t.read(W/'compile/program/compiled.json');test=t.read(Q/'compile/test/compiled.json')
    t.exact(program['object']);t.exact(test['object'])
    removed={t.key(x['path']) for x in p['removed_consumers']};rows=[]
    for row in t.read(parent['inputs']['path']):
        if t.key(row['path']) in removed:continue
        rows.append(program['object'] if t.key(row['path'])==t.key(parent['old_object']['path']) else row)
    rows.insert(0,test['object']);assert len(rows)==168
    for row in t.read(parent['retained_stats']['path']):
        if t.key(row['path']) in removed:continue
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    command=t.command(p['link']['path']);assert all(sum(t.key(a)==t.key(row['path']) for a in command)==1 for row in rows)
    (Q/'bin').mkdir(exist_ok=True);t.save(Q/'inputs.json',rows)
    proc=t.execute(command,Q/'link',240)
    runtime=t.read(p['runtime']['path']);t.exact(runtime['native']);alias=Path(runtime['hardlink_on_link']);assert not alias.exists();os.link(runtime['native']['path'],alias)
    assert os.path.samefile(runtime['native']['path'],alias)
    t.save(Q/'ready.json',dict(image=t.pin(Q/'bin/retained-output.exe'),inputs=t.pin(Q/'inputs.json'),compiled=[program,test],process=proc,
        recipe=t.pin(Q/'link/command.json'),plan=t.pin(Q/'plan.json'),source_freeze=p['source_freeze'],runtime=p['runtime'],native_hardlink=t.pin(alias)))
    print('READER LINK READY; no run')

def parse():
    out=Q/'run';proc=t.read(out/'process.json');assert proc['exit']==0 and not proc['timed_out']
    text=(out/'stdout.log').read_text(encoding='utf-8-sig');assert 'PASS Vulkan 3 cases:' in text
    t.save(out/'summary.json',dict(status='PASS',process=proc,original_cases=3,stdout=t.pin(out/'stdout.log'),stderr=t.pin(out/'stderr.log'),ready=t.pin(Q/'ready.json'),quality_claim=False,performance_claim=False))
    print('READER PASS',proc['pid'],'original3cases')

def run():
    p,_=load();ready=t.read(Q/'ready.json');t.exact(ready['image']);t.exact(ready['native_hardlink'])
    runtime=t.read(p['runtime']['path']);assert os.path.samefile(runtime['native']['path'],runtime['hardlink_on_link'])
    out=Q/'run';assert not out.exists(),'Original process only; parse offline after any parser failure'
    try:t.execute([ready['image']['path']],out,300,runtime=True)
    finally:
        if(out/'process.json').exists():t.save(out/'as-run.json',dict(ready=t.pin(Q/'ready.json'),image=ready['image'],inputs=ready['inputs'],source_freeze=ready['source_freeze'],process=t.read(out/'process.json')))
    parse()

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':compile_one()
    elif action=='parse-compile':parse_compile()
    elif action=='link':link()
    elif action=='run':run()
    elif action=='parse':parse()
    else:raise ValueError(action)
