"""Scratch-only Vulkan IO diagnosis. Explicit, single-use host actions; no SDK build."""
from pathlib import Path
import hashlib, importlib.util, json, os, re, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
P = W.parent
R = Path(r'C:\public\project-hyle\hyle')
spec = importlib.util.spec_from_file_location('vulkan_original_runner', R / '.scratch/inference-native-state-only-20261028/vulkan/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
t.W, t.R = W, R

def copy(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, ('Refuse overwrite of prior prepared snapshot', path)
        return
    with path.open('xb') as f: f.write(data)

def replace(s, old, new, count=1):
    assert s.count(old) == count, (old[:120], s.count(old), count)
    return s.replace(old, new)

def instrument(s):
    s = replace(s, '#include <array>', '#include <array>\n#include <atomic>\n#include <cstdio>')
    helper = r'''
// Scratch diagnosis only. No shared_ptr copy, native admission or gate change.
static void diagnostic_output_owners(const char *where, const InvocationState &state) noexcept {
  static std::atomic<unsigned> records{0};
  const auto record = records.fetch_add(1, std::memory_order_relaxed);
  if (record >= 256) return;
  const auto &run = *state.run;
  const auto &program = *state.program;
  std::fprintf(stderr, "VK_IO record=%u where=%s state=%p run=%p program=%p outputs=%zu stages=%zu sealed=%d preparing=%d rearm=%d epoch_pending=%d reuse=%d bound=%d pending=%d observers=%u retiring=%d completion=%p\n",
      record, where, static_cast<const void *>(&state), static_cast<const void *>(&run),
      static_cast<const void *>(&program), program.outputs.size(), run.stages.size(),
      int(state.composition_sealed), int(state.composition_preparing), int(state.output_rearm_required),
      int(state.output_epoch_pending), int(state.retained_output_reuse), int(state.bound),
      int(run.pending), run.observers, int(run.retiring), static_cast<const void *>(run.completion_owner.get()));
  for (std::size_t i = 0; i < program.outputs.size(); ++i) {
    const auto output = program.outputs[i];
    const auto root = program.aliases[output].root;
    const auto *owner = run.retained_buffers[output].get();
    const auto *root_owner = run.retained_buffers[root].get();
    std::size_t native_refs = 0, managed_binding_refs = 0, value_refs = 0, old_input_refs = 0;
    for (const auto &buffer : run.retained_buffers) value_refs += buffer.get() == owner;
    for (const auto &buffer : state.old_inputs) old_input_refs += buffer.get() == owner;
    for (const auto &stage : run.stages) {
      if (stage.native) for (const auto &buffer : stage.native->retained_buffers)
        native_refs += buffer.get() == owner;
      if (stage.managed) for (const auto &binding : stage.bindings)
        managed_binding_refs += binding.owner.get() == owner;
    }
    const auto baseline = i < state.output_owner_counts.size() ? state.output_owner_counts[i] : -1L;
    std::fprintf(stderr, "VK_IO_OUTPUT record=%u ordinal=%zu output=%u alias_root=%u alias_offset=%llu owner=%p root_owner=%p current=%ld baseline=%ld root_current=%ld value_refs=%zu old_input_refs=%zu native_stage_refs=%zu managed_parent_binding_refs=%zu\n",
        record, i, output, root, static_cast<unsigned long long>(program.aliases[output].byte_offset),
        static_cast<const void *>(owner), static_cast<const void *>(root_owner),
        run.retained_buffers[output].use_count(), baseline, run.retained_buffers[root].use_count(),
        value_refs, old_input_refs, native_refs, managed_binding_refs);
  }
  std::fflush(stderr);
}
'''
    s = replace(s, 'namespace hyle::compute::vulkan::detail {', 'namespace hyle::compute::vulkan::detail {\n' + helper)
    s = replace(s, '    invocation->bound = state_->inputs.empty();', '    detail::diagnostic_output_owners("create-baseline", *invocation);\n    invocation->bound = state_->inputs.empty();')
    a = s.index('Status detail::CompositionAccess::seal('); b = s.index('Status detail::PagedBatchAccess::reuse_gate(', a)
    section = s[a:b]
    section = replace(section, '  return Status::Ok();', '  detail::diagnostic_output_owners("seal", state);\n  return Status::Ok();')
    s = s[:a] + section + s[b:]
    a = s.index('Status detail::PagedBatchAccess::reseal_composition('); b = s.index('Status detail::PagedBatchAccess::release_inputs(', a)
    section = replace(s[a:b], '  return Status::Ok();', '  detail::diagnostic_output_owners("reseal", *state);\n  return Status::Ok();')
    s = s[:a] + section + s[b:]
    a = s.index('Status detail::PagedBatchAccess::can_detach_inputs('); b = s.index('void detail::PagedBatchAccess::detach_inputs(', a)
    section = s[a:b]
    section = replace(section, '  if (run.pending || run.observers || run.retiring || run.completion_owner)\n    return Status::Unavailable("Vulkan native inputs are still in use");', '  if (run.pending || run.observers || run.retiring || run.completion_owner) {\n    detail::diagnostic_output_owners("can-detach-busy", *state);\n    return Status::Unavailable("Vulkan native inputs are still in use");\n  }')
    section = replace(section, '      if (count < state->output_owner_counts[i])\n        return Status::Unavailable("Vulkan native private output owners changed");', '      if (count < state->output_owner_counts[i]) {\n        detail::diagnostic_output_owners("can-detach-private-decrease", *state);\n        return Status::Unavailable("Vulkan native private output owners changed");\n      }')
    section = replace(section, '        if (!state->retained_output_reuse)\n          return Status::Unavailable("Vulkan native output retained");', '        if (!state->retained_output_reuse) {\n          detail::diagnostic_output_owners("can-detach-output-retained", *state);\n          return Status::Unavailable("Vulkan native output retained");\n        }')
    section = replace(section, '      return Status::Unimplemented("Vulkan input-alias output cannot detach its fixed carrier");', '      { detail::diagnostic_output_owners("can-detach-input-alias", *state);\n        return Status::Unimplemented("Vulkan input-alias output cannot detach its fixed carrier"); }')
    section = replace(section, '        HYLE_ASSIGN_OR_RETURN(auto block,\n            detail::owned_output_block(*state->program, run, output));\n        (void)block;', '        auto checked_block = detail::owned_output_block(*state->program, run, output);\n        if (!checked_block) { detail::diagnostic_output_owners("can-detach-output-block", *state); return checked_block.error(); }')
    section = replace(section, '      HYLE_ASSIGN_OR_RETURN(auto block,\n          detail::owned_output_block(*state->program, run, output));\n      (void)block;', '      auto checked_block = detail::owned_output_block(*state->program, run, output);\n      if (!checked_block) { detail::diagnostic_output_owners("can-detach-reuse-block", *state); return checked_block.error(); }')
    section = replace(section, '  for (const auto &stage : run.stages)\n    if (stage.managed) HYLE_RETURN_IF_ERROR(stage.managed->can_detach_bindings());', '  for (const auto &stage : run.stages) if (stage.managed) {\n    const auto checked = stage.managed->can_detach_bindings();\n    if (!checked.ok()) { detail::diagnostic_output_owners("can-detach-managed", *state); return checked; }\n  }')
    section = replace(section, '  return cd::can_detach_retired(state->slot, result);', '  const auto checked = cd::can_detach_retired(state->slot, result);\n  if (!checked.ok()) detail::diagnostic_output_owners("can-detach-retired-slot", *state);\n  return checked;')
    s = s[:a] + section + s[b:]
    a = s.index('void detail::PagedBatchAccess::detach_inputs('); b = s.index('Status detail::PagedBatchAccess::update_layout(', a)
    section = replace(s[a:b], '    cd::discard_retired_payload(state.slot);', '    detail::diagnostic_output_owners("detach-before", state);\n    cd::discard_retired_payload(state.slot);')
    section = replace(section, '  for (auto &input : state.old_inputs) input.reset();', '  for (auto &input : state.old_inputs) input.reset();\n  { std::lock_guard lock(state.program->runtime->mutex);\n    detail::diagnostic_output_owners("detach-after", state); }')
    s = s[:a] + section + s[b:]
    return s

def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve the original preparation'
    ready = t.read(P / 'ready.json'); rows = t.read(ready['inputs']['path']); assert len(rows) == 169
    inventory_path = R / '.scratch/inference-native-state-only-20261028/vulkan/inventory.json'
    inventory = t.read(inventory_path)
    original = next(x for x in inventory['vulkan'] if x.get('source') == 'src/compute_route_vulkan/vulkan_program.cc')
    assert t.key(t.read(original['dependencies'])['Data']['Source']) == t.key(R / original['source'])
    assert sum(t.key(x['path']) == t.key(original['object']['path']) for x in rows) == 1
    weights = next(x for x in ready['compiled'] if t.key(x['source']['path']) == t.key(R / 'engine/models/qwen35/weights.cc'))
    old_tiny = next(x for x in ready['compiled'] if t.key(x['source']['path']) == t.key(R / 'tests/tools/qwen_host_image_test.cc'))
    authored = {}
    program_source = R / original['source']
    dest = W / 'source/src/compute_route_vulkan/vulkan_program.cc'
    copy(W / 'source-base/vulkan_program.cc', program_source.read_bytes())
    copy(dest, instrument(program_source.read_text(encoding='utf-8')).encode('utf-8'))
    authored['program'] = dict(original=t.pin(program_source), snapshot=t.pin(dest))
    driver = R / 'tests/tools/qwen_host_image_test.cc'
    text = replace(driver.read_text(encoding='utf-8'), '#include "../../engine/models/qwen35/main.cc"', '#include "' + (R / 'engine/models/qwen35/main.cc').as_posix() + '"')
    copy(W / 'source/tests/tools/qwen_host_image_test.cc', text.encode('utf-8'))
    authored['tiny'] = dict(original=t.pin(driver), snapshot=t.pin(W / 'source/tests/tools/qwen_host_image_test.cc'))
    test = R / 'tests/tools/qwen_mtp_logits_case.h'
    text = test.read_text(encoding='utf-8')
    text = replace(text, '#pragma once', '#pragma once\n#include <cstdio>')
    text = replace(text, 'cold(model); finite_math(model, kind);', 'cold(model);\n  std::fprintf(stderr, "VK_DIAG before finite_math\\n"); std::fflush(stderr);\n  finite_math(model, kind);\n  std::fprintf(stderr, "VK_DIAG after finite_math\\n"); std::fflush(stderr);')
    a = text.index('  for (std::size_t branch = 0; branch != 2; ++branch) {\n    q::check(run.reset());')
    b = text.index('\ninline void cold(', a)
    section = text[a:b]
    section = replace(section, '    q::check(run.reset());', '    std::fprintf(stderr, "VK_DIAG finite_math branch=%zu begin\\n", branch); std::fflush(stderr);\n    q::check(run.reset());')
    section = replace(section, '        "modified speculative residual/bonus changed q twice or lost its independent original final draw");', '        "modified speculative residual/bonus changed q twice or lost its independent original final draw");\n    std::fprintf(stderr, "VK_DIAG finite_math branch=%zu end\\n", branch); std::fflush(stderr);')
    text = text[:a] + section + text[b:]
    copy(W / 'source/tests/tools/qwen_mtp_logits_case.h', text.encode('utf-8'))
    authored['finite_markers'] = dict(original=t.pin(test), snapshot=t.pin(W / 'source/tests/tools/qwen_mtp_logits_case.h'))
    for name in ('qwen_packed_prefill_case.h', 'qwen_mtp_sampling_case.h'):
        src = R / 'tests/tools' / name; dst = W / 'source/tests/tools' / name
        copy(dst, src.read_bytes()); authored[name] = dict(original=t.pin(src), snapshot=t.pin(dst), refinement='Already corrected portability initialization; no numerical changes')
    units = []; dependency_paths = []
    for name, old_command, old_deps, old_object, source in [
        ('program', original['recipe'], original['dependencies'], original['object'], dest),
        ('tiny', old_tiny['command']['path'], old_tiny['dependencies']['path'], old_tiny['object'], Path(authored['tiny']['snapshot']['path']))]:
        args = t.command(old_command); data_source = t.read(old_deps)['Data']['Source']; command = []
        for i, arg in enumerate(args):
            if t.key(arg) == t.key(data_source): arg = str(source)
            elif i and args[i - 1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            command.append(arg)
        command.insert(1, '/I' + str(R / ('src/compute_route_vulkan' if name == 'program' else 'tests/tools')))
        assert all('HYLE_COMPUTE_CUDA' not in x and 'HYLE_COMPUTE_APPLE' not in x for x in command)
        t.save(W / f'recipes/{name}.json', dict(command=command, cwd=str(R), timeout_seconds=300))
        units.append(dict(name=name, source=t.pin(source), original_command=t.pin(old_command), original_dependencies=t.pin(old_deps), old_object=old_object, recipe=t.pin(W / f'recipes/{name}.json')))
        dependency_paths += [Path(p) for p in t.depfiles(old_deps)]
    # Pin the complete already-observed Includes, then close new project quote
    # dependencies. System/SDK headers are receipts only, never copied.
    known = {t.key(p): t.pin(p) for p in dependency_paths if p.is_file()}
    pending = [R / 'engine/models/qwen35/main.cc'] + [Path(x['snapshot']['path']) for x in authored.values()]
    roots = [W / 'source/tests/tools', R / 'tests/tools', R / 'src/compute_route_vulkan', R, R / 'include', R / 'engine']
    scanned = set()
    while pending:
        path = pending.pop().resolve(); key = t.key(path)
        if key in scanned: continue
        scanned.add(key); known[key] = t.pin(path)
        for inc in re.findall(r'^\s*#\s*include\s*[<"]([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig', errors='replace'), re.M):
            target = next((q.resolve() for root in [path.parent, *roots] if (q := root / inc).is_file()), None)
            if target and (t.project(target) or W in target.parents): pending.append(target)
    t.save(W / 'dependencies-prepin.json', list(known.values()))
    t.save(W / 'source-freeze.json', dict(authored=authored, original_main=t.pin(R / 'engine/models/qwen35/main.cc'), dependencies=t.pin(W / 'dependencies-prepin.json'), scope='Only scratch SDK source plus consumer markers; canonical product and tests unchanged.'))
    replacements = {t.key(u['old_object']['path']): str(W / f"compile/{u['name']}/unit.obj") for u in units}
    command = []
    for arg in t.command(ready['recipe']['path']):
        arg = replacements.get(t.key(arg), arg)
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map'), ('/ILK:', '.ilk')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny-diag').with_suffix(suffix)); break
        command.append(arg)
    assert sum('engine/entry/unit.obj' in t.key(arg) for arg in command) == 0
    t.save(W / 'recipe-link.json', dict(command=command, cwd=str(R), timeout_seconds=240))
    retained = [x for x in rows if t.key(x['path']) not in replacements]; assert len(retained) == 167
    stats = []
    for row in retained:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']; stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    t.save(W / 'retained-stats.json', stats)
    t.save(W / 'environment.json', t.read(P / 'environment.json'))
    runtime = t.read(P / 'runtime.json'); runtime['PATH'] = str(W / 'bin') + ';' + runtime['PATH']; runtime['hardlink_on_link'] = str(W / 'bin' / Path(runtime['native']['path']).name)
    t.save(W / 'runtime.json', runtime)
    parent_plan = t.read(P / 'plan.json')
    t.save(W / 'plan.json', dict(status='PREPARED_NOT_COMPILED', original_ready=t.pin(P / 'ready.json'), inputs=ready['inputs'], units=units,
        inventory=t.pin(inventory_path), original_successful_weights=weights, parent_run_failure=t.pin(P / 'runs/logits/process.json'),
        source_freeze=t.pin(W / 'source-freeze.json'), environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        link=t.pin(W / 'recipe-link.json'), retained_stats=t.pin(W / 'retained-stats.json'), original_runner=t.pin(R / '.scratch/inference-native-state-only-20261028/vulkan/build.py'),
        original_parser=t.pin(P / 'run.py'), fixture=parent_plan['fixture'], fixture_manifest=parent_plan['fixture_manifest'],
        budgets=dict(CXX=2, SDK_TU=1, Tiny_TU=1, links=1, model_processes=1, input_count=169, retained_SDK=166, retained_weights=1, CLI_entries=0, NVCC=0, downloads=0),
        diagnostics=dict(cap=256, markers=['create-baseline','seal','reseal','can-detach-error','detach-before','detach-after','finite_math branches'],
            reference_counts='Non-owning raw-pointer comparison; native child retained_buffers and parent managed binding owners only. Opaque managed Region-internal owners are not separately observable in this TU.', epoch='Existing output_epoch_pending boolean; no invented generation counter', gate='Unchanged exact predicates/Status; diagnostics are not performance measurements')))
    print('PREPARED: program + tiny, one link, 169 inputs; no execution')

def load():
    p = t.read(W / 'plan.json')
    for field in ('source_freeze','environment','runtime','link','retained_stats','original_runner','original_parser','fixture_manifest'): t.exact(p[field])
    frozen = t.read(p['source_freeze']['path']); t.exact(frozen['dependencies']); t.exact(frozen['original_main'])
    for row in frozen['authored'].values(): t.exact(row['original']); t.exact(row['snapshot'])
    for u in p['units']: t.exact(u['source']); t.exact(u['recipe'])
    return p, frozen

def freeze():
    p, frozen = load()
    for row in t.read(frozen['dependencies']['path']): t.exact(row)
    t.save(W / 'freeze.json', dict(status='SOURCE_FROZEN_NOT_COMPILED', helper=t.pin(__file__), plan=t.pin(W / 'plan.json'), source_freeze=p['source_freeze']))
    print('FROZEN, 0CXX/0link/0run')

def parse_compile(name):
    p, frozen = load(); unit = next(x for x in p['units'] if x['name'] == name)
    out = W / f'compile/{name}'; proc = t.read(W / f'logs/{name}/process.json'); assert proc['exit'] == 0 and not proc['timed_out']
    known = {t.key(x['path']): x for x in t.read(frozen['dependencies']['path'])}; actual = []; additional_external = []
    for path in t.depfiles(out / 'dependencies.json'):
        row = known.get(t.key(path))
        if row is None:
            assert not t.project(path) and not W in Path(path).resolve().parents, ('Successful compiler; missing authored prepin is metadata error, do not recompile', path)
            row = t.pin(path); additional_external.append(row)
        else: t.exact(row)
        actual.append(row)
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(unit=unit, source=unit['source'], object=t.pin(out / 'unit.obj'), process=proc,
        command=t.pin(W / f'logs/{name}/command.json'), dependencies=t.pin(out / 'dependencies.json'), actual_dependencies=t.pin(out / 'actual-dependencies.json'),
        external_postcompile_additions=additional_external, external_timing='Only additional external SDK/compiler dependencies, if any, are explicitly postcompile pins. No CXX rerun is authorized.'))
    print('PARSED CXX', name)

def compile_one(name):
    p, frozen = load(); t.exact(t.read(W / 'freeze.json')['helper'])
    unit = next(x for x in p['units'] if x['name'] == name)
    for row in t.read(frozen['dependencies']['path']): t.exact(row)
    (W / f'compile/{name}').mkdir(parents=True, exist_ok=False)
    t.execute(t.command(unit['recipe']['path']), W / 'logs' / name, 300)
    parse_compile(name)

def link():
    p, _ = load(); rows = t.read(p['inputs']['path']); assert len(rows) == 169
    compiled = []
    for u in p['units']:
        record = t.read(W / f"compile/{u['name']}/compiled.json"); t.exact(record['object']); compiled.append(record)
        matches = [i for i,x in enumerate(rows) if t.key(x['path']) == t.key(u['old_object']['path'])]; assert len(matches) == 1
        rows[matches[0]] = record['object']
    for row in t.read(p['retained_stats']['path']):
        st=Path(row['path']).stat(); assert (st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    (W / 'bin').mkdir(exist_ok=True); t.save(W / 'inputs.json', rows)
    process = t.execute(t.command(p['link']['path']), W / 'link', 240)
    runtime=t.read(p['runtime']['path']);t.exact(runtime['native']); alias=Path(runtime['hardlink_on_link']); assert not alias.exists();os.link(runtime['native']['path'],alias)
    assert os.path.samefile(runtime['native']['path'],alias)
    t.save(W / 'ready.json',dict(image=t.pin(W/'bin/tiny-diag.exe'),inputs=t.pin(W/'inputs.json'),compiled=compiled,process=process,recipe=t.pin(W/'link/command.json'),plan=t.pin(W/'plan.json'),source_freeze=p['source_freeze'],runtime=p['runtime'],native_hardlink=t.pin(alias)))
    print('DIAGNOSTIC LINK READY; no model run')

if __name__ == '__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='compile':compile_one(sys.argv[2])
    elif action=='parse-compile':parse_compile(sys.argv[2])
    elif action=='link':link()
    else:raise ValueError(action)
