"""One existing Vulkan logits journey; keep terminal failure and parse offline."""
from pathlib import Path
import importlib.util, json, os, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('program_io_vulkan_diagnostic',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
t,R=b.t,b.R

def prepare():
    p,_=b.load()
    t.save(W/'run-plan.json',dict(status='PLANNED_NOT_RUN',runner=t.pin(__file__),plan=t.pin(W/'plan.json'),
        command=[str(W/'bin/tiny-diag.exe'),'--vulkan',p['fixture'],'--mtp-logits'],timeout_seconds=300,
        original_run_command=t.pin(W.parent/'runs/logits/command.json'),original_run_process=t.pin(W.parent/'runs/logits/process.json'),
        model_processes=1,scope='Single unchanged MTP logits consumer with finite branch stderr markers and scratch SDK reference counts. Numerical and permission predicates remain unchanged; failing exit is retained, never passed by this parser.'))
    print('PLANNED one Vulkan diagnostic process; no execution')

def parse():
    out=W/'runs/logits';proc=t.read(out/'process.json')
    text=(out/'stderr.log').read_text(encoding='utf-8-sig',errors='replace')
    markers=[x for x in text.splitlines() if x.startswith(('VK_IO ','VK_IO_OUTPUT ','VK_DIAG '))]
    events=[x for x in markers if x.startswith('VK_IO ')];outputs=[x for x in markers if x.startswith('VK_IO_OUTPUT ')]
    t.save(out/'diagnostic.json',dict(status='PROCESS_EXIT0' if proc['exit']==0 and not proc['timed_out'] else 'DIAGNOSTIC_PROCESS_FAILED',
        process=proc,events=events,outputs=outputs,consumer_markers=[x for x in markers if x.startswith('VK_DIAG ')],
        raw_stdout=t.pin(out/'stdout.log'),raw_stderr=t.pin(out/'stderr.log'),command=t.pin(out/'command.json'),
        numerical_pass_claim=False,permission_gate_changed=False,opaque_managed_internal_references_measured=False))
    print('DIAGNOSTIC TERMINAL',proc['pid'],'exit',proc['exit'],'events',len(events),'outputs',len(outputs))

def run():
    p,_=b.load();rp=t.read(W/'run-plan.json');t.exact(rp['runner']);t.exact(rp['plan'])
    ready=t.read(W/'ready.json');t.exact(ready['image']);t.exact(ready['native_hardlink'])
    runtime=t.read(p['runtime']['path']);assert os.path.samefile(runtime['native']['path'],runtime['hardlink_on_link'])
    args=list(rp['command']);assert t.key(args[0])==t.key(ready['image']['path'])
    out=W/'runs/logits';assert not out.exists(),'Already attempted; parse the original files without rerunning'
    try:t.execute(args,out,rp['timeout_seconds'],runtime=True)
    finally:
        if (out/'process.json').exists():
            proc=t.read(out/'process.json')
            t.save(out/'as-run.json',dict(ready=t.pin(W/'ready.json'),image=ready['image'],inputs=ready['inputs'],source_freeze=ready['source_freeze'],run_plan=t.pin(W/'run-plan.json'),native=ready['native_hardlink'],process=proc))
            parse()

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='run':run()
    elif action=='parse':parse()
    else:raise ValueError(action)
