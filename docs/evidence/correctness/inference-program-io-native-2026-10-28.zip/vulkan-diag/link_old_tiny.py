"""Metadata refinement: link the successful diagnostic SDK TU with old successful Tiny."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parent;O=W/'old-tiny'
spec=importlib.util.spec_from_file_location('vulkan_diag_existing',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
t,R=b.t,b.R
t.W=O

def prepare():
    assert not (O/'plan.json').exists()
    ready=t.read(P/'ready.json');t.exact(ready['inputs']);rows=t.read(ready['inputs']['path']);assert len(rows)==169
    program=t.read(W/'compile/program/compiled.json');assert program['process']['exit']==0 and not program['process']['timed_out']
    for key in ('source','object','command','dependencies','actual_dependencies'):t.exact(program[key])
    original=program['unit']['old_object'];at=[i for i,row in enumerate(rows) if t.key(row['path'])==t.key(original['path'])];assert len(at)==1
    rows[at[0]]=program['object']
    consumers={Path(x['source']['path']).name:x for x in ready['compiled']}
    assert set(consumers)=={'qwen_host_image_test.cc','weights.cc'}
    for record in consumers.values():
        assert record['process']['exit']==0 and not record['process']['timed_out'];t.exact(record['object'])
        assert sum(t.key(x['path'])==t.key(record['object']['path']) for x in rows)==1
    failed=t.read(W/'logs/tiny/process.json');assert failed['pid']==20068 and failed['exit']==2 and not failed['timed_out']
    assert all(t.key(x['path'])!=t.key(W/'compile/tiny/unit.obj') for x in rows)
    args=[]
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg)==t.key(original['path']):arg=program['object']['path']
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map'),('/ILK:','.ilk')):
            if arg.upper().startswith(prefix):arg=prefix+str((O/'bin/tiny-old-tiny').with_suffix(suffix));break
        args.append(arg)
    assert len({t.key(x['path']) for x in rows})==169
    assert all(sum(t.key(a)==t.key(row['path']) for a in args)==1 for row in rows)
    assert not any('/engine/entry/unit.obj' in t.key(a) for a in args)
    t.save(O/'inputs.json',rows);t.save(O/'recipe-link.json',dict(command=args,cwd=str(R),timeout_seconds=240))
    stats=[]
    for row in rows:
        st=Path(row['path']).stat();assert st.st_size==row['bytes'];stats.append(dict(path=row['path'],bytes=st.st_size,mtime_ns=st.st_mtime_ns))
    t.save(O/'input-stats.json',stats)
    t.save(O/'environment.json',t.read(P/'environment.json'))
    runtime=t.read(P/'runtime.json');runtime['PATH']=str(O/'bin')+';'+runtime['PATH'];runtime['hardlink_on_link']=str(O/'bin'/Path(runtime['native']['path']).name)
    t.save(O/'runtime.json',runtime)
    pp=t.read(P/'plan.json')
    t.save(O/'plan.json',dict(status='PREPARED_NO_ADDITIONAL_CXX',helper=t.pin(__file__),run_helper=t.pin(W/'run_old_tiny.py'),
        parent_ready=t.pin(P/'ready.json'),parent_source_freeze=ready['source_freeze'],old_compiled=ready['compiled'],
        diagnostic_compiled=t.pin(W/'compile/program/compiled.json'),diagnostic_source_freeze=t.pin(W/'source-freeze.json'),
        failed_tiny_process=t.pin(W/'logs/tiny/process.json'),failed_tiny_command=t.pin(W/'logs/tiny/command.json'),
        reason='Diagnostic Tiny failed from mixed physical pragma-once test paths. Preserve it unused. Reuse historical successful Tiny/weights objects with their actual original source receipts; current portability headers are not claimed as recompiled.',
        inputs=t.pin(O/'inputs.json'),input_stats=t.pin(O/'input-stats.json'),recipe=t.pin(O/'recipe-link.json'),environment=t.pin(O/'environment.json'),runtime=t.pin(O/'runtime.json'),
        fixture=pp['fixture'],fixture_manifest=pp['fixture_manifest'],budgets=dict(additional_CXX=0,links=1,model_processes=1,inputs=169,retained_SDK=166,diagnostic_SDK=1,successful_Tiny=1,successful_weights=1,CLI_entries=0),
        finite_markers=False,all_original_numerical_assertions_preserved=True))
    print('PREPARED old-Tiny refinement: 0additionalCXX, 1link, 169inputs; no process started')

def load():
    p=t.read(O/'plan.json')
    for key in ('helper','run_helper','parent_ready','parent_source_freeze','diagnostic_compiled','diagnostic_source_freeze','failed_tiny_process','failed_tiny_command','inputs','input_stats','recipe','environment','runtime','fixture_manifest'):t.exact(p[key])
    for row in t.read(p['input_stats']['path']):
        st=Path(row['path']).stat();assert (st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    return p

def link():
    p=load();(O/'bin').mkdir(exist_ok=True)
    proc=t.execute(t.command(p['recipe']['path']),O/'link',240)
    runtime=t.read(p['runtime']['path']);t.exact(runtime['native']);alias=Path(runtime['hardlink_on_link']);assert not alias.exists();os.link(runtime['native']['path'],alias)
    assert os.path.samefile(runtime['native']['path'],alias)
    t.save(O/'ready.json',dict(image=t.pin(O/'bin/tiny-old-tiny.exe'),inputs=p['inputs'],process=proc,recipe=t.pin(O/'link/command.json'),plan=t.pin(O/'plan.json'),
        source_freeze=p['diagnostic_source_freeze'],parent_source_freeze=p['parent_source_freeze'],runtime=p['runtime'],native_hardlink=t.pin(alias),finite_markers=False))
    print('LINK READY, old successful Tiny + weights, diagnostic SDK only; no run')

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='link':link()
    else:raise ValueError(action)
