"""One diagnostic run with original successful Tiny; no consumer markers or recompilation."""
from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;O=W/'old-tiny'
spec=importlib.util.spec_from_file_location('link_old_tiny_refinement',W/'link_old_tiny.py')
l=importlib.util.module_from_spec(spec);spec.loader.exec_module(l)
t,R=l.t,l.R

def parse():
    out=O/'runs/logits';proc=t.read(out/'process.json');text=(out/'stderr.log').read_text(encoding='utf-8-sig',errors='replace')
    record=dict(status='PROCESS_EXIT0' if proc['exit']==0 and not proc['timed_out'] else 'DIAGNOSTIC_PROCESS_FAILED',process=proc,
        events=[s for s in text.splitlines() if s.startswith('VK_IO ')],outputs=[s for s in text.splitlines() if s.startswith('VK_IO_OUTPUT ')],
        raw_stdout=t.pin(out/'stdout.log'),raw_stderr=t.pin(out/'stderr.log'),command=t.pin(out/'command.json'),finite_markers=False,
        numerical_pass_claim=False,permission_gate_changed=False,opaque_managed_internal_references_measured=False)
    target=out/'diagnostic.json'
    if target.exists():assert t.read(target)==record
    else:t.save(target,record)
    print('ACTUAL DIAGNOSTIC',proc['pid'],'exit',proc['exit'],'events',len(record['events']),'outputs',len(record['outputs']))

def run():
    p=l.load();ready=t.read(O/'ready.json');t.exact(ready['image']);t.exact(ready['native_hardlink'])
    runtime=t.read(p['runtime']['path']);assert os.path.samefile(runtime['native']['path'],runtime['hardlink_on_link'])
    out=O/'runs/logits';assert not out.exists(),'Single attempt only; use parse for existing output'
    args=[ready['image']['path'],'--vulkan',p['fixture'],'--mtp-logits']
    try:t.execute(args,out,300,runtime=True)
    finally:
        if (out/'process.json').exists():
            t.save(out/'as-run.json',dict(helper=t.pin(__file__),ready=t.pin(O/'ready.json'),image=ready['image'],inputs=ready['inputs'],plan=t.pin(O/'plan.json'),native=ready['native_hardlink'],process=t.read(out/'process.json')))
            parse()

if __name__=='__main__':
    action=sys.argv[1]
    if action=='run':run()
    elif action=='parse':parse()
    else:raise ValueError(action)
