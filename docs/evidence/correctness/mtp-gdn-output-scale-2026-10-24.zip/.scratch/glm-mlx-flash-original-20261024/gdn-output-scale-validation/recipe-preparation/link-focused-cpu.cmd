@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
cd /d C:\public\project-hyle\hyle
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\link.exe" @C:\public\project-hyle\hyle\.scratch\glm-mlx-flash-original-20261024\gdn-output-scale-validation\recipe-preparation\link-focused-cpu.rsp
exit /b %errorlevel%
