"""Offline recipe emitter. It never invokes a compiler/linker or copies an SDK."""
from pathlib import Path
import ctypes
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
OUT = HERE.parent / 'native1'
PROPOSAL = ROOT / '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-proposal'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def ident(path):
    b = path.read_bytes()
    return dict(path=str(path), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def split_windows(command):
    # CommandLineToArgvW preserves Windows paths, quoted SDK includes, and defines.
    count = ctypes.c_int()
    f = ctypes.windll.shell32.CommandLineToArgvW
    f.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    f.restype = ctypes.POINTER(ctypes.c_wchar_p)
    values = f(command, ctypes.byref(count))
    if not values:
        raise OSError('CommandLineToArgvW')
    try:
        return [values[i] for i in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree(values)


def cl_command(command, old_source, source, name):
    args = []
    skip = False
    for arg in command:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')):
            continue
        if Path(arg).as_posix().lower() == Path(old_source).as_posix().lower():
            continue
        args.append(arg)
    args += ['/I' + str(ROOT / 'src/compute_ggml_runtime'),
             '/sourceDependencies', str(OUT / (name + '-deps.json')),
             str(source), '/Fo' + str(OUT / (name + '.obj')),
             '/Fd' + str(OUT / (name + '.pdb')), '/FS']
    assert args.count(str(source)) == 1
    return args


def main():
    OUT.mkdir(exist_ok=True)
    causal_path = ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/commands.json'
    causal = {x['label']: x['argv'] for x in read(causal_path)}
    facts = read(PROPOSAL / 'actual-native-cache-facts.json')
    for fact in facts[:2]:
        assert ident(ROOT / fact['actual_cached_source'])['sha256'] == fact['before_sha256']
        assert ident(ROOT / fact['incremental_source'])['sha256'] == fact['after_sha256']
    compdb_path = ROOT / '.scratch/build-cpu-final-mixed-probe/compile_commands.json'
    baseline = next(x for x in read(compdb_path)
                    if x['file'].replace('\\', '/').endswith('/ggml-cpu/ops.cpp'))
    jobs = []
    def add(name, command, source, recipe):
        jobs.append(dict(name=name, command=command, source=ident(source),
                         recipe=ident(recipe), working_directory=str(ROOT)))
    source = ROOT / facts[0]['incremental_source']
    add('cpu-baseline', cl_command(split_windows(baseline['command']), baseline['file'],
                                   source, 'cpu-baseline'), source, compdb_path)
    source = ROOT / facts[1]['incremental_source']
    old = ROOT / facts[1]['actual_cached_source']
    add('cpu-avx2', cl_command(causal['ffa4-native-avx2'], old, source, 'cpu-avx2'),
        source, causal_path)
    source = ROOT / 'src/compute_ggml_runtime/cpu_program_export.cc'
    add('cpu-program-export', cl_command(causal['ffa4-program-export'], source,
                                         source, 'cpu-program-export'), source, causal_path)
    link = []
    for arg in causal['ffa4-module-link']:
        if arg.upper().startswith('/OUT:'):
            arg = '/OUT:' + str(OUT / 'hyle_ggml_cpu_gdn_scale_v3.dll')
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:' + str(OUT / 'cpu-avx2-module.lib')
        elif arg.upper().startswith('/MAP:'):
            arg = '/MAP:' + str(OUT / 'cpu-avx2-module.map')
        elif arg.endswith('native-avx2.obj'):
            arg = str(OUT / 'cpu-avx2.obj')
        elif arg.endswith('program-export.obj'):
            arg = str(OUT / 'cpu-program-export.obj')
        link.append(arg)
    jobs.append(dict(name='cpu-avx2-dll', command=link, working_directory=str(ROOT),
                     recipe=ident(causal_path),
                     retained_inputs=[ident(Path(x)) for x in link
                                      if x.endswith(('.obj', '.lib')) and Path(x).exists()]))
    cuda_path = ROOT / '.scratch/architecture-refactor-2026-10-18/bf16-grouped-bank/checks/native1/native--gated_delta_net-identity.json'
    cuda = read(cuda_path)
    assert cuda['source']['sha256'] == facts[2]['complete_owning_overlay_before_sha256']
    source = PROPOSAL / facts[2]['new_source']
    assert ident(source)['sha256'] == facts[2]['after_sha256']
    args = list(cuda['command'])
    for i, arg in enumerate(args):
        if arg == cuda['source']['path']:
            args[i] = str(source)
        elif arg == cuda['object']['path']:
            args[i] = str(OUT / 'cuda-gated-delta.obj')
        elif arg.endswith('native--gated_delta_net.d'):
            args[i] = str(OUT / 'cuda-gated-delta.d')
        elif arg.startswith('-Xcompiler=-Fd'):
            args[i] = '-Xcompiler=-Fd' + str(OUT / 'cuda-gated-delta.pdb') + ',-FS'
    args.insert(1, '-I' + str(ROOT / 'src/compute_ggml_runtime'))
    add('cuda-gated-delta', args, source, cuda_path)
    plan = dict(executed=False, sdk_builds=0, jobs=jobs,
                cpu_baseline_family='mixed 456172ec; baseline static exe override only',
                cpu_avx2_family='ffa4 causal; separate DLL; export ABI3',
                cuda_family='current fixed456172ec owning overlay; one NVCC TU',
                note='No command has run. Compiler/link exit and final dependencies must be recorded by root.')
    (HERE / 'native-commands.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    vcvars = Path(jobs[0]['command'][0]).parents[6] / 'Auxiliary/Build/vcvars64.bat'
    assert vcvars.is_file(), vcvars
    for label, selected in [('cpu', jobs[:4]), ('cuda', jobs[4:]), ('all', jobs)]:
        lines = ['@echo off', 'call ' + subprocess.list2cmdline([str(vcvars)]),
                 'if errorlevel 1 exit /b %errorlevel%',
                 'cd /d ' + subprocess.list2cmdline([str(ROOT)])]
        for job in selected:
            lines += ['rem ' + job['name'], subprocess.list2cmdline(job['command']),
                      'if errorlevel 1 exit /b %errorlevel%']
        (HERE / ('compile-native-' + label + '.cmd')).write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8')
    print('PREPARED', len(jobs), 'commands; not executed')


if __name__ == '__main__':
    main()
