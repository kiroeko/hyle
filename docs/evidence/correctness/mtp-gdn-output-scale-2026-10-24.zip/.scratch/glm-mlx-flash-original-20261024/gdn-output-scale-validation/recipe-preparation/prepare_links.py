"""Offline focused link plans; requires no newly built object to prepare."""
from pathlib import Path
import json
import subprocess
import prepare_native as n

ROOT, HERE = n.ROOT, n.HERE
STAGE = HERE.parent


def main():
    host = n.read(HERE / 'host-commands.json')
    native = n.read(HERE / 'native-commands.json')
    old_path = ROOT / '.scratch/glm-mlx-flash-original-20261024/batched-bfloat-linear-validation/tests-link1/link-plan.json'
    old = n.read(old_path)
    link = str(Path(host['jobs'][0]['command'][0]).with_name('link.exe'))
    bin = ROOT / '.scratch/build-compute-v2-dev/bin'
    common = [str(bin / (x + '.lib')) for x in [
        'hyle_container', 'hyle_mem', 'mimalloc_static', 'hyle_platform',
        'hyle_error', 'hyle_platform_thread', 'hyle_time', 'hyle_simd',
        'hyle_sched', 'hyle_mem_vm', 'hyle_platform_fs']]
    common += [str(ROOT / '.scratch/build-compute-v2-dev/lib' / (x + '.lib'))
               for x in ['gtest_main', 'gtest']]
    systems = ['bcrypt.lib', 'PowrProf.lib', 'Synchronization.lib', 'advapi32.lib',
               'user32.lib', 'shell32.lib', 'ole32.lib', 'ws2_32.lib']
    # These are native ggml math/bridge overrides from the actual cached image,
    # not HYLE providers, Operation-copy code, Graph objects, or old tests.
    native_names = {
        'native--mmid.obj', 'native-getrows.obj', 'native-convert.obj',
        'native--ssm-conv.obj', 'mmvq.obj', 'norm.obj', 'binbcast.obj',
        'unary.obj', 'native-main.obj', 'ggml-alloc.obj', 'diagmask-current.obj',
        'mmvf.obj',
    }
    cuda_math = [x for x in old['command'] if Path(x).name in native_names]
    assert len(cuda_math) == len(native_names), (len(cuda_math), native_names - {Path(x).name for x in cuda_math})
    plans = []
    for backend in ['cpu', 'cuda']:
        out = STAGE / ('focused-' + backend + '-link1')
        out.mkdir(exist_ok=True)
        jobs = [x for x in host['jobs'] if x['name'].startswith(('compute--', 'compute_ops--'))]
        if backend == 'cpu':
            jobs += [x for x in host['jobs'] if x['name'].startswith((
                'compute_backend_cpu--', 'compute_provider_ggml--', 'compute_ggml_runtime--'))]
            records = [STAGE / 'compile1' / x / 'identity.json' for x in ['cpu-test', 'cpu-provider']]
            retained = [str(STAGE / 'native1/cpu-baseline.obj'),
                        str(ROOT / '.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-cpu.lib'),
                        str(ROOT / '.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-base.lib')]
        else:
            jobs += [x for x in host['jobs'] if x['name'].startswith((
                'compute_backend_cuda--', 'compute_provider_ggml_cuda--'))]
            records = [STAGE / 'compile1' / x / 'identity.json' for x in ['cuda-test', 'tensor-program']]
            retained = cuda_math + [
                str(STAGE / 'native1/cuda-gated-delta.obj'),
                str(ROOT / '.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices/guard.obj'),
                str(ROOT / '.scratch/build-compute-v2-dev/src/compute_backend_cuda/CMakeFiles/hyle_compute_backend_cuda.dir/device_status_kernel.cu.obj'),
                str(ROOT / '.scratch/paged-capture-20261021/cuda/checks1/kernel/kernel.obj'),
            ]
            retained += [str(ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows/lib' / (x + '.lib'))
                         for x in ['ggml', 'ggml-cuda', 'ggml-base']]
            retained += [str(Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/lib/x64') / (x + '.lib'))
                         for x in ['cudart', 'cuda', 'cublas', 'cublasLt']]
        objects = [str(STAGE / 'host1' / (x['name'] + '.obj')) for x in jobs]
        objects += [n.read(x)['object']['path'] for x in records]
        foundation = ['batch-layout', 'metadata-arena']
        if backend == 'cpu':
            foundation += ['cpu-execution', 'cpu-hadamard']
        objects += [str(STAGE / 'foundation1' / (x + '.obj')) for x in foundation]
        args = [link, '/NOLOGO', '/MACHINE:X64', '/INCREMENTAL:NO', '/OPT:REF', '/OPT:ICF',
                '/SUBSYSTEM:CONSOLE', '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(out / 'gdn-scale-checks.exe'),
                '/MAP:' + str(out / 'gdn-scale-checks.map')]
        args += objects + retained + common + systems
        # Static low-level libraries are retained by exact identity. Newly
        # compiled HYLE host objects replace entire corresponding modules;
        # no old hyle_compute/provider/backend/Graph archive is on this line.
        plans.append(dict(backend=backend, command=args, working_directory=str(ROOT),
                          fresh_host_jobs=[x['name'] for x in jobs],
                          reused_current_records=[n.ident(x) for x in records],
                          retained_inputs=[n.ident(Path(x)) for x in retained + common if Path(x).is_file()],
                          future_objects=[x for x in objects + retained if not Path(x).exists()],
                          link_recipe=n.ident(old_path), executed=False))
        vcvars = Path(host['jobs'][0]['command'][0]).parents[6] / 'Auxiliary/Build/vcvars64.bat'
        rsp = HERE / ('link-focused-' + backend + '.rsp')
        rsp.write_text('\r\n'.join(subprocess.list2cmdline([x]) for x in args[1:]) + '\r\n', encoding='utf-8')
        lines = ['@echo off', 'call ' + subprocess.list2cmdline([str(vcvars)]),
                 'if errorlevel 1 exit /b %errorlevel%', 'cd /d ' + subprocess.list2cmdline([str(ROOT)]),
                 subprocess.list2cmdline([link, '@' + str(rsp)]), 'exit /b %errorlevel%']
        (HERE / ('link-focused-' + backend + '.cmd')).write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8')
    (HERE / 'focused-link-plans.json').write_text(json.dumps(plans, indent=2) + '\n', encoding='utf-8')
    print('PREPARED two independent focused links; not linked or run')


if __name__ == '__main__':
    main()
