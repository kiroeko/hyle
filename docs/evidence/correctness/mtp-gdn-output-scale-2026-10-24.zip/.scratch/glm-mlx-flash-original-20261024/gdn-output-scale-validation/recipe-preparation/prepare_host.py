"""Emit fresh focused host closure commands from actual cached recipes; no build."""
from pathlib import Path
import json
import re
import subprocess
import prepare_native as n

ROOT, HERE = n.ROOT, n.HERE
OUT = HERE.parent / 'host1'
NINJA = ROOT / '.scratch/build-compute-v2-dev/build.ninja'
CURRENT = HERE.parent / 'compile1'


def ninja_recipes():
    text = NINJA.read_text()
    rows = {}
    for match in re.finditer(r'^build ([^\r\n]+): CXX_COMPILER_[^\r\n]+? (C\$:[^\r\n]+?) \|\|[^\r\n]*\r?\n((?:  [^\r\n]*\r?\n)+)', text, re.M):
        source = match[2].replace('$:', ':').replace('$ ', ' ')
        values = dict(re.findall(r'^  (\w+) = ([^\r\n]*)', match[3], re.M))
        tokens = n.split_windows('cl ' + ' '.join(values.get(k, '') for k in ['DEFINES', 'INCLUDES', 'FLAGS']))[1:]
        rows[Path(source).as_posix().lower()] = tokens
    return rows


def main():
    OUT.mkdir(exist_ok=True)
    recipes = ninja_recipes()
    cpu_base_path = CURRENT / 'cpu-provider/identity.json'
    cuda_base_path = ROOT / '.scratch/mtp-packed-head-m2-20261023/compile1/ggml-provider/identity.json'
    selector_base_path = ROOT / '.scratch/paged-append-20261021/checks/attempt7/compute_ggml_runtime--cpu_program/identity.json'
    cpu_base, cuda_base, selector = map(n.read, [cpu_base_path, cuda_base_path, selector_base_path])
    cl = cpu_base['command'][0]
    jobs = []
    def add(module, filename, fallback=None):
        source = ROOT / 'src' / module / filename
        name = module + '--' + source.stem
        key = source.as_posix().lower()
        if key in recipes:
            command = [cl, '/nologo', '/TP', '/c'] + recipes[key]
            recipe = NINJA
            old_source = source
        elif fallback:
            old_source = ROOT / 'src' / module / fallback
            command = [cl, '/nologo', '/TP', '/c'] + recipes[old_source.as_posix().lower()]
            recipe = NINJA
        elif module == 'compute_provider_ggml':
            command, old_source, recipe = cpu_base['command'], cpu_base['source']['path'], cpu_base_path
        elif module == 'compute_provider_ggml_cuda':
            command, old_source, recipe = cuda_base['command'], cuda_base['source']['path'], cuda_base_path
        elif module == 'compute_ggml_runtime':
            command, old_source, recipe = selector['command'], selector['source']['path'], selector_base_path
        else:
            raise RuntimeError('no actual recipe: ' + str(source))
        command = n.cl_command(command, old_source, source, name)
        # cl_command's destination is native1; only output arguments move to host1.
        command = [arg.replace(str(n.OUT), str(OUT)) for arg in command]
        if module == 'compute_ggml_runtime':
            command = [x for x in command if not x.startswith('/DHYLE_GGML_CPU_PROGRAM_LIBRARY=')]
            command += ['/DHYLE_GGML_CPU_PROGRAM_LIBRARY="hyle_ggml_cpu_gdn_scale_v3.dll"']
        jobs.append(dict(name=name, command=command, source=n.ident(source),
                         recipe=n.ident(recipe), working_directory=str(ROOT)))
    compute = ('batch_transfer command_capture completion copy_control copy_ranges custom_kernel '
               'device operation provider resource_budget resource_leases retained_completion '
               'leased_operation route_policy result shape_domain shape_program tensor_view '
               'transfer weight_import workload').split()
    for name in compute:
        add('compute', name + '.cc', 'operation.cc')
    for name in ['operation', 'tensor_desc', 'low_precision', 'weight_decode', 'sampling_ops']:
        add('compute_ops', name + '.cc')
    add('compute_ops', 'blockwise_w4a8.cc', 'operation.cc')
    add('compute_backend_cpu', 'cpu_backend.cc')
    for name in ['cuda_backend', 'cuda_batch_transfer', 'cuda_memory', 'cuda_device_status', 'driver_release']:
        add('compute_backend_cuda', name + '.cc')
    add('compute_backend_cuda', 'cuda_paged_append.cc', 'cuda_backend.cc')
    for name in ['standard_index', 'native_batch']:
        add('compute_provider_ggml', name + '.cc')
    add('compute_provider_ggml_cuda', 'ggml_cuda_provider.cc')
    add('compute_ggml_runtime', 'cpu_program.cc')
    reused = [CURRENT / (x + '/identity.json') for x in ['cpu-test', 'cuda-test', 'cpu-provider', 'tensor-program']]
    for path in reused:
        record = n.read(path)
        assert n.ident(Path(record['source']['path'])) == record['source'], path
        assert n.ident(Path(record['object']['path'])) == record['object'], path
        for dep in record['dependencies']:
            assert n.ident(Path(dep['path'])) == dep, (path, dep['path'])
    plan = dict(executed=False, jobs=jobs, freshly_compiled_reused=[n.ident(x) for x in reused],
                provider_contract=18, sdk_builds=0, nvcc_builds=0,
                scope='Focused explicit ggml_cpu/ggml_cuda only. No old test TU, Graph/default-route/provider assembly.',
                link_rule='Use fresh complete compute/compute_ops/backends plus explicit ggml providers. Do not add old hyle_compute*.lib implementations over missing fresh objects.')
    (HERE / 'host-commands.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    vcvars = Path(cl).parents[6] / 'Auxiliary/Build/vcvars64.bat'
    lines = ['@echo off', 'call ' + subprocess.list2cmdline([str(vcvars)]),
             'if errorlevel 1 exit /b %errorlevel%', 'cd /d ' + subprocess.list2cmdline([str(ROOT)])]
    for job in jobs:
        lines += ['rem ' + job['name'], subprocess.list2cmdline(job['command']),
                  'if errorlevel 1 exit /b %errorlevel%']
    (HERE / 'compile-host.cmd').write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8')
    print('PREPARED', len(jobs), 'fresh host commands, reused 4 current identities; not executed')


if __name__ == '__main__':
    main()
