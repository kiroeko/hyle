"""Prepare the four exact foundation gaps diagnosed by focused link3."""
from pathlib import Path
import json
import subprocess
import prepare_native as n

ROOT, HERE = n.ROOT, n.HERE
OUT = HERE.parent / 'foundation1'


def function(text, signature):
    begin = text.index(signature)
    start = text.index('{', begin)
    depth = 1
    end = start + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[begin:end]


def main():
    OUT.mkdir(exist_ok=True)
    cached = ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/ops.cpp'
    old = cached.read_text(encoding='utf-8')
    head = old[:old.index('// ggml_compute_forward_dup')]
    helper = (head + '\n// Verbatim same-family cached FWHT and CUSTOM bridge only.\n' +
              function(old, 'static void ggml_compute_forward_fwht_f32') + '\n\n' +
              function(old, 'extern "C" void ggml_hyle_cpu_hadamard') + '\n')
    source = HERE / 'same-family-hadamard.cpp'
    source.write_text(helper, encoding='utf-8')
    assert 'void ggml_compute_forward_fwht(' not in helper
    base_path = HERE.parent / 'compile1/cpu-provider/identity.json'
    base = n.read(base_path)
    jobs = []
    for name, source in [
        ('batch-layout', ROOT / 'src/compute_batch/batch_layout.cc'),
        ('metadata-arena', ROOT / 'src/compute_ggml_runtime/metadata_arena.cc'),
        ('cpu-execution', ROOT / 'src/compute_ggml_runtime/cpu_execution.cc'),
    ]:
        args = n.cl_command(base['command'], base['source']['path'], source, name)
        args = [x.replace(str(n.OUT), str(OUT)) for x in args]
        jobs.append(dict(name=name, command=args, source=n.ident(source), recipe=n.ident(base_path)))
    native = n.read(HERE / 'native-commands.json')['jobs'][0]
    source = HERE / 'same-family-hadamard.cpp'
    args = n.cl_command(native['command'], native['source']['path'], source, 'cpu-hadamard')
    args = [x.replace(str(n.OUT), str(OUT)) for x in args]
    jobs.append(dict(name='cpu-hadamard', command=args, source=n.ident(source),
                     original_verbatim_body=n.ident(cached),
                     recipe=n.ident(HERE / 'native-commands.json')))
    data = dict(executed=False, reason='actual focused CPU link3 24 unresolved foundation symbols',
                jobs=jobs, batch_and_metadata_for_both_images=True,
                cpu_execution_and_hadamard_cpu_only=True,
                no_old_abi_provider_or_graph_archive=True)
    (HERE / 'foundation-commands.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    vcvars = Path(jobs[0]['command'][0]).parents[6] / 'Auxiliary/Build/vcvars64.bat'
    lines = ['@echo off', 'call ' + subprocess.list2cmdline([str(vcvars)]),
             'if errorlevel 1 exit /b %errorlevel%', 'cd /d ' + subprocess.list2cmdline([str(ROOT)])]
    for job in jobs:
        lines += ['rem ' + job['name'], subprocess.list2cmdline(job['command']),
                  'if errorlevel 1 exit /b %errorlevel%']
    (HERE / 'compile-foundation.cmd').write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8')
    print('PREPARED four small foundation TUs; no compile/link/native')


if __name__ == '__main__':
    main()
