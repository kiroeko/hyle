"""Fresh CPU/CUDA lowering host objects, reusing their actual compile recipes."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[2]
spec=importlib.util.spec_from_file_location('gdn_lowering_host_build',R/'.scratch/native-paged-effects-20261022/build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.S=S
h.RECIPES={name:R/f'.scratch/glm-mlx-flash-original-20261024/batched-bfloat-linear-validation/compile1/{name}/identity.json'
           for name in ('cpu-provider','tensor-program')}
h.SOURCES={}
for name in h.RECIPES:h.compile_one(name,1)
