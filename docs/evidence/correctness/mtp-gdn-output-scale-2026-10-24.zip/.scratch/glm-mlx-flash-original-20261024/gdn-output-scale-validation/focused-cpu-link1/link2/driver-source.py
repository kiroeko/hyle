from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[2]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
h=module('gdn_check_build_env',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=module('gdn_check_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def identity(path):
    raw=Path(path).read_bytes()
    return dict(path=str(Path(path)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def verify(info):assert identity(info['path'])==info,info['path']
p=argparse.ArgumentParser();p.add_argument('action',choices=('link','run'));p.add_argument('backend',choices=('cpu','cuda'));p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
plan_path=S/'recipe-preparation/focused-link-plans.json'
plan=next(x for x in read(plan_path) if x['backend']==a.backend)
out=S/f'focused-{a.backend}-link1';image=out/'gdn-scale-checks.exe'
(out/'tmp').mkdir(exist_ok=True)
env,_=h.b.environment(plan['command'],[],out)
env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
if a.action=='link':
    for item in plan['retained_inputs']:verify(item)
    for item in plan['reused_current_records']:
        verify(item)
        record=read(Path(item['path']))
        for x in (record['source'],record['object'],*record['dependencies']):verify(x)
    for name in plan['fresh_host_jobs']:
        record=read(S/'host1/records'/name/'identity.json')
        for x in (record['source'],record['object'],*record['dependencies']):verify(x)
    log='link' if a.attempt==1 else f'link{a.attempt}'
    result=q.execute(plan['command'],env,out/log,timeout=1800)
    if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
    if a.backend=='cpu':os.link(S/'native1/hyle_ggml_cpu_gdn_scale_v3.dll',out/'hyle_ggml_cpu_gdn_scale_v3.dll')
    (out/'ready.json').write_text(json.dumps(dict(image=identity(image),link_plan=identity(plan_path)),indent=2)+'\n',encoding='utf-8')
    print('LINKED focused',a.backend,flush=True)
else:
    verify(read(out/'ready.json')['image'])
    env['PATH']=str(out)+os.pathsep+env['PATH']
    checks=out/'checks1'
    result=q.execute([str(image),'--gtest_filter=GdnOutputScale.*','--gtest_output=xml:'+str(checks/'results.xml')],env,checks,timeout=1800)
    if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
    tree=ET.parse(checks/'results.xml').getroot()
    assert int(tree.get('tests'))==3
    assert all(int(tree.get(k,'0'))==0 for k in ('failures','errors','disabled')) and not list(tree.iter('skipped'))
    (checks/'summary.json').write_text(json.dumps(dict(tests=3,failures=0,skips=0,backend=a.backend,
        image=identity(image),xml=identity(checks/'results.xml'),
        scope='Explicit raw/default GDN/KDA/Recurrent output scaling, two state snapshots and retained input state; cold finite/presence/bit-domain checks.',
        throughput_evidence=False,memory_evidence=False),indent=2)+'\n',encoding='utf-8')
    print('PASSED focused',a.backend,'3 cases',flush=True)
