from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[2]
P=S.parent/'gdn-output-scale-proposal';D=R/'docs/evidence/correctness'
NAME='mtp-gdn-output-scale-2026-10-24'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def identity(path):
    raw=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
executions=[]
for backend in ('cpu','cuda'):
    out=S/f'focused-{backend}-link1';result=read(out/'checks1/summary.json');process=read(out/'checks1/process.json')
    assert result['tests']==3 and result['failures']==result['skips']==process['exit']==0 and not process['timed_out']
    assert identity(out/'gdn-scale-checks.exe')['sha256']==read(out/'ready.json')['image']['sha256']
    executions.append(dict(backend=backend,tests=3,failures=0,skips=0,
                           summary=identity(out/'checks1/summary.json'),XML=identity(out/'checks1/results.xml')))
files=set()
for base in (S,P):
    for path in base.rglob('*'):
        if path.is_file() and path.suffix in ('.json','.py','.cc','.cpp','.cu','.h','.metal','.patch','.cmd','.rsp','.xml','.log','.txt'):
            files.add(path)
for item in read(P/'changed-files.json'):
    path=R/item['path']
    raw=path.read_bytes();assert len(raw)==item['after_bytes'] and hashlib.sha256(raw).hexdigest()==item['after_sha256']
    files.add(path)
for path in list((S/'host1/records').glob('*/identity.json'))+list((S/'foundation1/records').glob('*/identity.json'))+list((S/'compile1').glob('*/identity.json')):
    record=read(path)
    for entry in (record['source'],*record['dependencies']):
        src=Path(entry['path'])
        if src.is_relative_to(R) and src.parts[len(R.parts)] in ('include','src'):
            assert identity(src)['sha256']==entry['sha256']
            files.add(src)
archive=D/(NAME+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(files):z.write(path,path.relative_to(R).as_posix())
record=dict(created_at=datetime.now(timezone.utc).isoformat(),
    scope='Public GatedDeltaNet optional output_scale, actual CPU/CUDA direct Compute Prepared/Invocation/Completion execution.',
    contract=dict(empty='Unchanged native1/sqrt(Dk)',explicit_one='Raw final F32 S*q dot',
                  finite_values='Explicit finite F32 including signed zero/negative values; nonfinite rejected before preparation',
                  state='Output multiply follows dot reduction; Q/K, recurrent state and snapshot math unchanged',
                  fused='recurrent_gated_delta_net(snapshot_count, output_scale)',
                  native_params='Slot0 K and slot1 CUDA state marker unchanged; slot2 scale F32 bits, slot3 explicit-presence tag'),
    executions=executions,source_files=23,checks=6,
    windows_build=dict(focused_test_TUs=2,lowering_host_TUs=2,core_backend_host_TUs=38,foundation_TUs=4,
                       CPU_native_TUs=3,CPU_AVX2_DLL_links=1,CUDA_native_NVCC_TUs=1,SDK_builds=0,
                       closure='Fresh actual core/ops/backend/provider18, CPU selector/export ABI3 and exact-revision native deltas; no old Graph/provider/default-route/test archives.'),
    state_checks='GDN, per-channel KDA and fused recurrent gates, T2/K2 snapshots, unmodified initial state and cancellation-sensitive F32 final dots.',
    source_only_backends=['Metal host/kargs/shader lowering and Vulkan host/clone lowering are applied and owning manifests/locks verified; not native-executed in this record.'],
    limits=['Direct Compute cases do not certify the new Graph/default-provider assembly closure.',
            'Q32 MLX original source and whole-model/task-quality/performance are not executed by these focused checks.',
            'No TPS, physical CPU/GPU memory peak, Linux/macOS execution, or complete dtype/device matrix claim.'],
    retained_failures=['CUDA environment preparation originally treated nvcc as the host compiler; no NVCC was executed in that attempt.',
                       'CPU link1 missing temporary directory, link2 missing console subsystem, link3 omitted foundational symbols. All retained; successful link4 adds real current owners.'],
    throughput_evidence=False,memory_evidence=False,archive=identity(archive),archived_files=len(files))
destination=D/(NAME+'.json');assert not destination.exists()
destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=identity(destination),archive=identity(archive),checks=6)))
