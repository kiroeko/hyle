"""Compile only the two actual current focused CPU/CUDA test TUs."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[2]
spec=importlib.util.spec_from_file_location('gdn_focused_test_build',R/'.scratch/native-paged-effects-20261022/build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
S.mkdir(exist_ok=True)
recipes={}
for backend in ('cpu','cuda'):
    old=R/f'.scratch/glm-mlx-flash-original-20261024/batched-bfloat-linear-validation/compile1/{backend}-test/identity.json'
    recipe=json.loads(old.read_text(encoding='utf-8-sig'))
    recipe['command'].insert(1,f'/DHYLE_GDN_SCALE_{backend.upper()}=1')
    output=S/f'{backend}-test-recipe.json'
    assert not output.exists()
    output.write_text(json.dumps(recipe,indent=2)+'\n',encoding='utf-8')
    recipes[f'{backend}-test']=output
h.S=S;h.RECIPES=recipes
h.SOURCES={name:R/'tests/compute_provider_native/gdn_output_scale_test.cc' for name in recipes}
for name in recipes:h.compile_one(name,1)
