"""Run the exact reviewed native delta jobs, serially, with recorded logs."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[2]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
h=module('gdn_native_build_env',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=module('gdn_native_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
def identity(path):
    raw=Path(path).read_bytes()
    return dict(path=str(Path(path)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def check(info):
    assert identity(info['path'])==info,info['path']
p=argparse.ArgumentParser(description=__doc__);p.add_argument('backend',choices=('cpu','cuda'))
p.add_argument('--attempt',type=int,default=1)
args=p.parse_args()
path=S/'recipe-preparation/native-commands.json'
plan=json.loads(path.read_text(encoding='utf-8-sig'))
jobs=[job for job in plan['jobs'] if job['name'].startswith(args.backend+'-')]
assert len(jobs)==(4 if args.backend=='cpu' else 1)
for job in jobs:
    if 'source' in job:check(job['source'])
    check(job['recipe'])
    for item in job.get('retained_inputs',[]):check(item)
    name=job['name'] if args.attempt==1 else job['name']+f'-attempt{args.attempt}'
    out=S/'native1/records'/name;assert not out.exists()
    out.mkdir(parents=True);(out/'tmp').mkdir()
    (out/'plan.json').write_text(json.dumps(dict(job=job,source_plan=identity(path)),indent=2)+'\n',encoding='utf-8')
    # The environment helper accepts a host C++ compiler, not nvcc. CUDA uses
    # the same validated MSVC host environment as the baseline CPU command.
    host=job['command'] if args.backend=='cpu' else plan['jobs'][0]['command']
    env,_=h.b.environment(host,[],out)
    if args.backend=='cuda':env['PATH']=str(Path(job['command'][0]).parent)+os.pathsep+env['PATH']
    env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
    result=q.execute(job['command'],env,out/'run',timeout=1800)
    if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
    if 'source' in job:check(job['source'])
    print('PASSED native delta',job['name'],flush=True)
