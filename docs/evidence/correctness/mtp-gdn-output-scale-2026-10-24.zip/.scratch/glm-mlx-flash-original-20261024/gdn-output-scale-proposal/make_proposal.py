"""Construct this fixed offline proposal. Never edits the live product."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
BEFORE = HERE / "before"
AFTER = HERE / "after"
changed = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    if name not in changed:
        data = (REPO / name).read_bytes() if (REPO / name).is_file() else b""
        changed[name] = [data, data.decode("utf-8")]
    return changed[name][1]


def put(name, text):
    load(name)
    original = changed[name][0]
    if original.count(b"\r\n") and original.count(b"\r\n") == original.count(b"\n"):
        text = text.replace("\r\n", "\n").replace("\n", "\r\n")
    changed[name][1] = text


def replace(name, old, new, count=1):
    text = load(name)
    if text.count(old) != count:
        raise ValueError(f"Expected {count} unique contexts in {name}: {old[:100]!r}; got {text.count(old)}")
    put(name, text.replace(old, new))


replace("include/hyle/compute/operation.h",
        "//   y = S*q / sqrt(Dk).",
        "//   y = (S*q) * scale, where scale is output_scale or 1/sqrt(Dk).\n"
        "// The F32 dot reduction precedes this scalar multiply; scale never changes\n"
        "// Q/K inputs or the recurrent state. Explicit 1 returns the raw dot.")
replace("include/hyle/compute/operation.h",
        "struct GatedDeltaNet final {\n  std::uint32_t snapshot_count = 1;\n};",
        "struct GatedDeltaNet final {\n  std::uint32_t snapshot_count = 1;\n"
        "  // Empty retains native 1/sqrt(Dk); every explicit value must be finite.\n"
        "  // Preserve signed zero and F32 bits; empty and explicit 1 are distinct.\n"
        "  std::optional<float> output_scale{};\n};")
replace("src/compute_ops/operation.cc",
        "  case OperationKind::kGatedDeltaNet:\n    first = infer_gated_delta_net(inputs);",
        "  case OperationKind::kGatedDeltaNet:\n"
        "    if (const auto scale = operation.get_if<GatedDeltaNet>()->output_scale;\n"
        "        scale && !std::isfinite(*scale))\n"
        "      return Status::InvalidArgument(\"GatedDeltaNet output_scale must be finite\");\n"
        "    first = infer_gated_delta_net(inputs);")
replace("include/hyle/compute/model_ops.h", "0x47444e4741540008ULL", "0x47444e4741540009ULL")
replace("include/hyle/compute/model_ops.h",
        "  std::uint32_t snapshot_count = 1;\n\n  constexpr OperationTraits operation_traits()",
        "  std::uint32_t snapshot_count = 1;\n  std::optional<float> output_scale{};\n\n  constexpr OperationTraits operation_traits()")
replace("include/hyle/compute/model_ops.h",
        "Operation(GatedDeltaNet{.snapshot_count = snapshot_count}),",
        "Operation(GatedDeltaNet{.snapshot_count = snapshot_count, .output_scale = output_scale}),")
replace("include/hyle/compute/model_ops.h",
        "inline Operation recurrent_gated_delta_net(std::uint32_t snapshot_count = 1) noexcept {\n"
        "  return Operation::custom(RecurrentGatedDeltaNet{.snapshot_count = snapshot_count});\n}",
        "inline Operation recurrent_gated_delta_net(\n"
        "    std::uint32_t snapshot_count = 1,\n"
        "    std::optional<float> output_scale = {}) noexcept {\n"
        "  return Operation::custom(RecurrentGatedDeltaNet{\n"
        "      .snapshot_count = snapshot_count, .output_scale = output_scale});\n}")
replace("src/compute/provider_internal.h", "kProviderContractVersion = 17;", "kProviderContractVersion = 18;")

native_header = '''#pragma once

// Private C++17 metadata contract shared by current Hyle hosts and locked
// native programs. Slot 0 is K; slot 1 belongs to CUDA state-output planning.
#include <cmath>
#include <cstdint>
#include <cstring>
#include <optional>
#include "ggml.h"

namespace hyle::compute::ggml_runtime {
inline constexpr std::int32_t kGdnOutputScaleContract = 0x48594732;
inline constexpr int kGdnOutputScaleSlot = 2;
inline constexpr int kGdnOutputScalePresenceSlot = 3;

inline bool valid_gdn_output_scale(std::optional<float> scale) noexcept {
  return !scale || std::isfinite(*scale);
}
inline void set_gdn_output_scale(ggml_tensor *node,
                                 std::optional<float> scale) noexcept {
  node->op_params[kGdnOutputScalePresenceSlot] =
      scale ? kGdnOutputScaleContract : 0;
  // Never hash/compare optional padding or use float equality. Empty has a
  // canonical zero payload; explicit signed zero retains its original bits.
  const float value = scale.value_or(0.0F);
  std::memcpy(&node->op_params[kGdnOutputScaleSlot], &value, sizeof(value));
}
inline bool has_gdn_output_scale(const ggml_tensor *node) noexcept {
  return node->op_params[kGdnOutputScalePresenceSlot] == kGdnOutputScaleContract;
}
inline float gdn_output_scale(const ggml_tensor *node,
                              float default_scale) noexcept {
  if (!has_gdn_output_scale(node)) return default_scale;
  float value;
  std::memcpy(&value, &node->op_params[kGdnOutputScaleSlot], sizeof(value));
  return value;
}
} // namespace hyle::compute::ggml_runtime

// Link each host against its real native implementation, not a header-only
// capability claim. An old native cache cannot silently ignore the attribute.
extern "C" std::int32_t ggml_hyle_cpu_gdn_output_scale_contract();
extern "C" std::int32_t ggml_hyle_cuda_gdn_output_scale_contract();
extern "C" std::int32_t ggml_hyle_metal_gdn_output_scale_contract();
extern "C" std::int32_t ggml_hyle_vulkan_gdn_output_scale_contract();
'''
put("src/compute_ggml_runtime/gated_delta_scale.h", native_header)

providers = {
    "cpu": "src/compute_provider_ggml/ggml_cpu_provider.cc",
    "cuda": "src/compute_provider_ggml_cuda/tensor_program.cc",
    "metal": "src/compute_provider_ggml_metal/native_program.cc",
    "vulkan": "src/compute_provider_ggml_vulkan/region.cc",
}
for backend, name in providers.items():
    # Every provider already has the runtime private include directory.
    text = load(name)
    first = text.index("\n", text.index("#include")) + 1
    put(name, text[:first] + '#include "gated_delta_scale.h"\n' + text[first:])
    if backend in ("cpu", "cuda"):
        replace(name,
                "    auto *packed = ggml_gated_delta_net(\n"
                "        context, recurrent_input(0), recurrent_input(1), recurrent_input(2),\n"
                "        decay, beta, initial, snapshots);",
                "    auto *packed = ggml_gated_delta_net(\n"
                "        context, recurrent_input(0), recurrent_input(1), recurrent_input(2),\n"
                "        decay, beta, initial, snapshots);\n"
                "    ggml_runtime::set_gdn_output_scale(\n"
                "        packed, gdn ? gdn->output_scale\n"
                "                    : node.operation.custom_as<model_ops::RecurrentGatedDeltaNet>()->output_scale);")
        context = "  if (operation.get_if<GatedDeltaNet>() || recurrent) {\n"
        replace(name, context, context +
                "    const auto *gdn = operation.get_if<GatedDeltaNet>();\n"
                "    const auto scale = gdn ? gdn->output_scale\n"
                "        : operation.custom_as<model_ops::RecurrentGatedDeltaNet>()->output_scale;\n"
                "    if (!ggml_runtime::valid_gdn_output_scale(scale)) return false;\n"
                f"    if (ggml_hyle_{backend}_gdn_output_scale_contract() !=\n"
                "        ggml_runtime::kGdnOutputScaleContract) return false;\n")
    elif backend == "metal":
        context = ("  if (operation.get_if<GatedDeltaNet>() ||\n"
                   "      operation.custom_as<model_ops::RecurrentGatedDeltaNet>()) {\n")
        replace(name, context, context +
                "    if (ggml_hyle_metal_gdn_output_scale_contract() !=\n"
                "        ggml_runtime::kGdnOutputScaleContract)\n"
                "      return Status::Unimplemented(\"ggml Metal native GDN scale contract differs\");\n")
        replace(name,
                "      result = ggml_gated_delta_net(context, t[0], t[1], t[2], gate, beta,\n"
                "                                    initial, snapshots);",
                "      result = ggml_gated_delta_net(context, t[0], t[1], t[2], gate, beta,\n"
                "                                    initial, snapshots);\n"
                "      const auto *gdn = operation.get_if<GatedDeltaNet>();\n"
                "      ggml_runtime::set_gdn_output_scale(\n"
                "          result, gdn ? gdn->output_scale\n"
                "                      : operation.custom_as<model_ops::RecurrentGatedDeltaNet>()->output_scale);")
    else:
        context = "  if (operation.get_if<GatedDeltaNet>() || recurrent) {\n"
        replace(name, context, context +
                "    if (ggml_hyle_vulkan_gdn_output_scale_contract() !=\n"
                "        ggml_runtime::kGdnOutputScaleContract) return false;\n")
        replace(name,
                "        auto *fused = ggml_gated_delta_net(\n"
                "            context, left, arguments[1], value, gate, beta, initial,\n"
                "            gdn_snapshot_count(node.operation));",
                "        auto *fused = ggml_gated_delta_net(\n"
                "            context, left, arguments[1], value, gate, beta, initial,\n"
                "            gdn_snapshot_count(node.operation));\n"
                "        const auto *gdn = node.operation.get_if<GatedDeltaNet>();\n"
                "        ggml_runtime::set_gdn_output_scale(\n"
                "            fused, gdn ? gdn->output_scale\n"
                "                       : node.operation.custom_as<model_ops::RecurrentGatedDeltaNet>()->output_scale);")

# A CPU program is a complete native ABI; old isolated AVX2 modules must not
# accept new operation metadata while retaining fixed-scale GDN arithmetic.
replace("src/compute_ggml_runtime/cpu_program_abi.h", "kCpuProgramAbi = 2;", "kCpuProgramAbi = 3;")
for name in ("src/compute_ggml_runtime/cpu_program.cc", "src/compute_ggml_runtime/cpu_program_export.cc"):
    text = load(name)
    put(name, '#include "gated_delta_scale.h"\n' + text.replace("hyle_ggml_cpu_program_v2", "hyle_ggml_cpu_program_v3"))
replace("src/compute_ggml_runtime/cpu_program.cc",
        "Result<const CpuProgram *> select_cpu_program() noexcept {",
        "Result<const CpuProgram *> select_cpu_program() noexcept {\n"
        "  if (ggml_hyle_cpu_gdn_output_scale_contract() != kGdnOutputScaleContract)\n"
        "    return std::unexpected(Status::FailedPrecondition(\"ggml CPU GDN scale contract\"));")
replace("src/compute_ggml_runtime/cpu_program_export.cc",
        "  return &program;",
        "  return ggml_hyle_cpu_gdn_output_scale_contract() ==\n"
        "                 hyle::compute::ggml_runtime::kGdnOutputScaleContract\n"
        "             ? &program : nullptr;")

# One shared header and no user options. Set an include only on the native
# sources which read this contract (and the isolated CPU copy in this scope).
cmake = "src/compute_ggml_runtime/CMakeLists.txt"
replace(cmake, "string(SHA256 _source_identity \"${_source_identity}\")",
        'file(SHA256 "${CMAKE_CURRENT_SOURCE_DIR}/gated_delta_scale.h" _gdn_scale_sha)\n'
        'string(APPEND _source_identity "${_gdn_scale_sha}")\n'
        'set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS\n'
        '  "${CMAKE_CURRENT_SOURCE_DIR}/gated_delta_scale.h")\n'
        'string(SHA256 _source_identity "${_source_identity}")')
replace(cmake, "foreach(_target IN LISTS _vendor_targets)\n",
        'foreach(_gdn_entry IN ITEMS\n'
        '    "ggml-cpu|src/ggml-cpu/ops.cpp"\n'
        '    "ggml-cuda|src/ggml-cuda/gated_delta_net.cu"\n'
        '    "ggml-metal|src/ggml-metal/ggml-metal-ops.cpp"\n'
        '    "ggml-vulkan|src/ggml-vulkan/ggml-vulkan.cpp")\n'
        '  string(REPLACE "|" ";" _gdn_parts "${_gdn_entry}")\n'
        '  list(GET _gdn_parts 0 _gdn_target)\n'
        '  list(GET _gdn_parts 1 _gdn_relative)\n'
        '  if(TARGET ${_gdn_target})\n'
        '    get_target_property(_gdn_directory ${_gdn_target} SOURCE_DIR)\n'
        '    set_property(SOURCE "${_patched_source}/${_gdn_relative}"\n'
        '      DIRECTORY "${_gdn_directory}" APPEND PROPERTY INCLUDE_DIRECTORIES\n'
        '      "${CMAKE_CURRENT_SOURCE_DIR}")\n'
        '  endif()\n'
        'endforeach()\n'
        '# The isolated CPU module is declared in this directory.\n'
        'if(_cpu)\n'
        '  set_property(SOURCE "${_patched_source}/src/ggml-cpu/ops.cpp"\n'
        '    APPEND PROPERTY INCLUDE_DIRECTORIES "${CMAKE_CURRENT_SOURCE_DIR}")\n'
        'endif()\n'
        'foreach(_target IN LISTS _vendor_targets)\n')

def save():
    rows, patch = [], []
    for name, (old, text) in sorted(changed.items()):
        new = text.encode("utf-8")
        if old == new:
            continue
        for root, data in ((BEFORE, old), (AFTER, new)):
            dest = root / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        rows.append({"path": name, "before_bytes": len(old), "before_sha256": sha(old),
                     "after_bytes": len(new), "after_sha256": sha(new)})
        patch.extend(difflib.unified_diff(old.decode("utf-8").splitlines(True), text.splitlines(True),
                                        fromfile="a/" + name if old else "/dev/null", tofile="b/" + name))
    (HERE / "source.patch").write_text("".join(patch), encoding="utf-8", newline="")
    (HERE / "changed-files.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps({"files": len(rows), "patch_bytes": (HERE / "source.patch").stat().st_size,
                      "patch_sha256": sha((HERE / "source.patch").read_bytes())}))


# Native owning-manifest edits are appended below before save().
native_facts = []


def native_update(manifest_name, file_name, original_root, edits):
    manifest = json.loads(load(manifest_name))
    original = (REPO / original_root / file_name).read_bytes().replace(b"\r\n", b"\n")
    entry = next((x for x in manifest["files"] if x["path"] == file_name), None)
    if entry is None:
        entry = {"path": file_name, "before_sha256": sha(original),
                 "after_sha256": sha(original), "edits": []}
        manifest["files"].append(entry)
    if sha(original) != entry["before_sha256"]:
        raise ValueError("Native before identity differs: " + file_name)
    current = original.decode("utf-8")
    for edit in entry["edits"]:
        if current.count(edit["before"]) != 1:
            raise ValueError("Existing native context changed: " + file_name)
        current = current.replace(edit["before"], edit["after"], 1)
    if sha(current.encode()) != entry["after_sha256"]:
        raise ValueError("Existing native after identity differs: " + file_name)
    old = current
    for before, after in edits:
        if current.count(before) != 1:
            raise ValueError("New native context changed: " + file_name + ": " + before[:100])
        current = current.replace(before, after, 1)
        entry["edits"].append({"before": before, "after": after})
    entry["after_sha256"] = sha(current.encode())
    put(manifest_name, json.dumps(manifest, indent=2) + "\n")
    native_facts.append({"manifest": manifest_name, "native_path": file_name,
                         "original_cache": str(original_root), "before_sha256": sha(original),
                         "old_after_sha256": sha(old.encode()), "after_sha256": entry["after_sha256"]})
    # Only changed native files, not an SDK/repo copy, for manual incremental builds.
    for directory, content in (("native-before", old), ("native-after", current)):
        dest = HERE / directory / file_name
        if "ggml-cpu" in file_name:
            dest = HERE / directory / "cpu-new-core" / file_name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8", newline="")


def feature_export(backend):
    return ('extern "C" std::int32_t ggml_hyle_' + backend + '_gdn_output_scale_contract() {\n'
            '    return hyle::compute::ggml_runtime::kGdnOutputScaleContract;\n}\n\n')


new_core = Path(".scratch/inference-gaps/g01/original-ggml-cpu-peer")
old_core = Path(".scratch/validation/cpu-final-f1/mixed-iq1/source")
vk_core = Path(".scratch/bench-api-runtime/vulkan/ggml-peer")
native_update("third_party/ggml_cpu_runtime/patches.json", "src/ggml-cpu/ops.cpp", new_core, [
    ('#include "ops.h"\n', '#include "ops.h"\n#include "gated_delta_scale.h"\n'),
    ('// ggml_compute_forward_gated_delta_net\n', feature_export("cpu") + '// ggml_compute_forward_gated_delta_net\n'),
    ('    const float scale = 1.0f / sqrtf((float) S_v);',
     '    const float scale = hyle::compute::ggml_runtime::gdn_output_scale(\n'
     '        dst, 1.0f / sqrtf((float) S_v));'),
])
native_update("third_party/ggml_cuda_runtime/patches.json", "src/ggml-cuda/gated_delta_net.cu", new_core, [
    ('#include "gated_delta_net.cuh"\n', '#include "gated_delta_net.cuh"\n#include "gated_delta_scale.h"\n\n' + feature_export("cuda")),
    ('    const float scale = 1.0f / sqrtf((float) S_v);',
     '    const float scale = hyle::compute::ggml_runtime::gdn_output_scale(\n'
     '        dst, 1.0f / sqrtf((float) S_v));'),
])
native_update("third_party/ggml_vulkan_runtime/patches.json", "src/ggml-vulkan/ggml-vulkan.cpp", vk_core, [
    ('#include "ggml-vulkan.h"\n', '#include "ggml-vulkan.h"\n#include "gated_delta_scale.h"\n\n' + feature_export("vulkan")),
    ('    const float scale = 1.0f / sqrtf((float)S_v);',
     '    const float scale = hyle::compute::ggml_runtime::gdn_output_scale(\n'
     '        dst, 1.0f / sqrtf((float)S_v));'),
    ('            src_clone[2], src_clone[3], src_clone[4], src_clone[5],\n'
     '            ggml_get_op_params_i32(tensor, 0));',
     '            src_clone[2], src_clone[3], src_clone[4], src_clone[5],\n'
     '            ggml_get_op_params_i32(tensor, 0));\n'
     '            // Retain explicit-scale presence and F32 bits in the CPU oracle clone.\n'
     '            tensor_clone->op_params[hyle::compute::ggml_runtime::kGdnOutputScaleSlot] =\n'
     '                tensor->op_params[hyle::compute::ggml_runtime::kGdnOutputScaleSlot];\n'
     '            tensor_clone->op_params[hyle::compute::ggml_runtime::kGdnOutputScalePresenceSlot] =\n'
     '                tensor->op_params[hyle::compute::ggml_runtime::kGdnOutputScalePresenceSlot];'),
])
native_update("third_party/ggml_runtime/metal-patches.json", "src/ggml-metal/ggml-metal-ops.cpp", old_core, [
    ('#include "ggml-metal-ops.h"\n', '#include "ggml-metal-ops.h"\n#include "gated_delta_scale.h"\n\n' + feature_export("metal")),
    ('        /*.nb_out =*/ nb_out,\n    };',
     '        /*.nb_out =*/ nb_out,\n'
     '        /*.output_scale =*/ hyle::compute::ggml_runtime::gdn_output_scale(op, 0.0f),\n'
     '        /*.has_output_scale =*/ hyle::compute::ggml_runtime::has_gdn_output_scale(op) ? 1 : 0,\n'
     '    };'),
])
native_update("third_party/ggml_runtime/metal-patches.json", "src/ggml-metal/ggml-metal-impl.h", old_core, [
    ('    uint64_t nb_out; // 0 => snapshots are appended after the attn scores (unfused)\n'
     '} ggml_metal_kargs_gated_delta_net;',
     '    uint64_t nb_out; // 0 => snapshots are appended after the attn scores (unfused)\n'
     '    float output_scale;\n'
     '    int32_t has_output_scale;\n'
     '} ggml_metal_kargs_gated_delta_net;'),
])
shader_scale = '    const float scale = 1.0f / sqrt((float)S_v);'
shader_raw = ('    const float scale = args.has_output_scale\n'
              '        ? args.output_scale : 1.0f / sqrt((float)S_v);')
# The two variants have different state load layouts; both retain the same final multiply.
shader_text = (REPO / old_core / "src/ggml-metal/kernels/gated_delta_net.metal").read_text(encoding="utf-8")
if shader_text.count(shader_scale) != 2:
    raise ValueError("Metal GDN shader variants changed")
native_update("third_party/ggml_runtime/metal-patches.json", "src/ggml-metal/kernels/gated_delta_net.metal", old_core, [
    (shader_scale + '\n\n    // input state layout',
     shader_raw + '\n\n    // input state layout'),
    (shader_scale + '\n\n    device const float * s_ptr',
     shader_raw + '\n\n    device const float * s_ptr'),
])

# Vendored locks own the actual native edits. Preserve the existing normalized
# file-tree algorithm; no new audit mechanism or external dependency is added.
lock_name = "cmake/HyleDependencyLock.json"
lock = json.loads(load(lock_name))
for dep in lock["dependencies"]:
    if dep["name"] not in ("ggml_cpu_runtime_patches", "ggml_cuda_runtime_patches",
                           "ggml_runtime_patches", "ggml_vulkan_runtime_patches"):
        continue
    root = Path(dep["vendored"]["path"])
    entries = []
    for path in sorted((REPO / root).rglob("*"), key=lambda p:p.relative_to(REPO / root).as_posix()):
        if not path.is_file():
            continue
        name = path.relative_to(REPO).as_posix()
        data = changed[name][1].encode() if name in changed else path.read_bytes()
        data = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        entries.append(path.relative_to(REPO / root).as_posix() + "|" + sha(data) + "\n")
    dep["vendored"]["tree_sha256"] = sha("".join(entries).encode())
put(lock_name, json.dumps(lock, indent=2) + "\n")

(HERE / "native-source-facts.json").write_text(json.dumps(native_facts, indent=2) + "\n")

focused_test = r'''#include <gtest/gtest.h>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <limits>
#include <span>
#include <vector>
#include "hyle/compute/model_ops.h"

#if defined(HYLE_GDN_SCALE_CPU) || defined(HYLE_GDN_SCALE_CUDA)
#include "hyle/compute/prepared_operation.h"
#include "hyle/mem/buffer.h"
#include "../../src/compute_ggml_runtime/gated_delta_scale.h"
#if defined(HYLE_GDN_SCALE_CPU)
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#else
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/ggml_cuda.h"
#endif
#elif defined(HYLE_GDN_SCALE_APPLE)
#include "hyle/compute/apple.h"
#elif defined(HYLE_GDN_SCALE_VULKAN)
#include "../compute_route_vulkan/tensor_test_support.h"
#else
#error Select the focused GDN scale backend
#endif

namespace {
namespace c = hyle::compute;
struct Fixture final {
  static constexpr std::int64_t depth = 128;
  static constexpr float delta = 1.F / 1048576.F;
  bool recurrent;
  std::vector<c::TensorDesc> inputs;
  std::vector<std::vector<float>> data;
  Fixture(bool kda, bool raw_gates) : recurrent(raw_gates) {
    const auto add = [&](std::array<std::int64_t,4> shape) {
      auto d = c::TensorDesc::dense(c::DataType::kFloat32, shape).value();
      inputs.push_back(d); data.emplace_back(d.element_count().value(), 0.F);
    };
    for (int port = 0; port != 3; ++port) add({1,2,1,depth});
    add({1,2,1,kda ? depth : 1}); add({1,2,1,1});
    if (raw_gates) { add({1,1,1,1}); add({1,1,1,1}); }
    add({1,1,depth,depth});
    for (int t = 0; t != 2; ++t) {
      data[0][std::size_t(t*depth)] = 1.F + delta;
      data[0][std::size_t(t*depth+1)] = -1.F;
    }
    for (std::int64_t row = 0; row < depth; ++row)
      data.back()[std::size_t(row*depth)] =
          data.back()[std::size_t(row*depth+1)] = float(row%3+1);
  }
  c::Operation operation(std::optional<float> scale) const {
    return recurrent ? c::model_ops::recurrent_gated_delta_net(2, scale)
                     : c::Operation(c::GatedDeltaNet{.snapshot_count=2, .output_scale=scale});
  }
  std::array<c::TensorDesc,2> outputs(std::optional<float> scale) const {
    std::array<c::TensorDesc,2> result;
    EXPECT_TRUE(c::infer_output_descriptions(operation(scale), inputs, result).ok());
    return result;
  }
  void check(std::span<const float> scores, std::span<const float> states,
             std::optional<float> scale) const {
    ASSERT_EQ(scores.size(), 2*std::size_t(depth));
    ASSERT_EQ(states.size(), 2*data.back().size());
    for (std::size_t i = 0; i < scores.size(); ++i) {
      const float raw = float((i%std::size_t(depth))%3+1)*delta;
      if (scale) EXPECT_EQ(scores[i], raw* *scale);
      else EXPECT_NEAR(scores[i], raw*(1.F/std::sqrt(float(depth))), 1.e-12F);
    }
    for (std::size_t i = 0; i < states.size(); ++i)
      EXPECT_EQ(states[i], data.back()[i%data.back().size()]);
  }
};

#if defined(HYLE_GDN_SCALE_CPU) || defined(HYLE_GDN_SCALE_CUDA)
void exercise(c::Context &context, hyle::mem::MemoryResourceRef resource) {
  auto queue = context.create_queue().value();
  for (int mode = 0; mode != 3; ++mode) {
    const Fixture f(mode == 1, mode == 2);
    for (const std::optional<float> scale : {std::optional<float>{}, std::optional<float>{1.F}}) {
      SCOPED_TRACE(::testing::Message() << "mode=" << mode << " explicit=" << scale.has_value());
      std::vector<hyle::mem::Buffer> owners;
      std::vector<c::ConstTensorView> inputs;
      owners.reserve(f.inputs.size());
      for (std::size_t port = 0; port < f.inputs.size(); ++port) {
        owners.push_back(hyle::mem::Buffer::create(resource, f.inputs[port].required_bytes().value(),256).value());
        ASSERT_TRUE(owners.back().write(0, std::as_bytes(std::span(f.data[port]))).ok());
        inputs.push_back(c::ConstTensorView::create(f.inputs[port],owners.back().view()).value());
      }
      const auto desc = f.outputs(scale);
      std::array<hyle::mem::Buffer,2> output_owners;
      std::array<c::TensorView,2> outputs;
      for (std::size_t port=0;port<2;++port) {
        output_owners[port]=hyle::mem::Buffer::create(resource,desc[port].required_bytes().value(),256).value();
        outputs[port]=c::TensorView::create(desc[port],output_owners[port].view()).value();
      }
      auto prepared=c::prepare(context,f.operation(scale),inputs,outputs,resource);
      ASSERT_TRUE(prepared)<<prepared.error().message();
      const auto w=prepared->workspace_requirement();
      auto workspace=w.size?hyle::mem::Buffer::create(resource,w.size,w.alignment).value():hyle::mem::Buffer{};
      auto invocation=prepared->create_invocation(workspace.view());
      ASSERT_TRUE(invocation)<<invocation.error().message();
      auto completion=invocation->submit(queue,inputs,outputs);
      ASSERT_TRUE(completion)<<completion.error().message();
      ASSERT_TRUE(completion->wait().ok());
      std::array<std::vector<float>,2> actual;
      for(std::size_t port=0;port<2;++port) {
        actual[port].resize(desc[port].element_count().value());
        ASSERT_TRUE(output_owners[port].read(0,std::as_writable_bytes(std::span(actual[port]))).ok());
      }
      f.check(actual[0],actual[1],scale);
      std::vector<float> retained(f.data.back().size());
      ASSERT_TRUE(owners.back().read(0,std::as_writable_bytes(std::span(retained))).ok());
      EXPECT_EQ(retained,f.data.back());
    }
  }
}
TEST(GdnOutputScale, RawDefaultAndFusedGatesKeepStateSnapshots) {
#if defined(HYLE_GDN_SCALE_CPU)
  auto context=c::Context::create(c::cpu::device(),c::ggml_cpu::provider()).value();
  exercise(context,hyle::mem::system_resource());
#else
  auto context=c::Context::create(c::cuda::device(0).value(),c::ggml_cuda::provider()).value();
  auto resource=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice).value();
  exercise(context,resource.ref());
#endif
}
TEST(GdnOutputScale, ColdParameterIdentityRetainsPresenceAndSignedFloatBits) {
  ggml_tensor node{};
  node.op_params[0]=2;node.op_params[1]=0x48594731;
  c::ggml_runtime::set_gdn_output_scale(&node,{});
  EXPECT_FALSE(c::ggml_runtime::has_gdn_output_scale(&node));
  for(float value:{1.F,0.F,-0.F,-2.F}) {
    c::ggml_runtime::set_gdn_output_scale(&node,value);
    EXPECT_TRUE(c::ggml_runtime::has_gdn_output_scale(&node));
    EXPECT_EQ(std::bit_cast<std::uint32_t>(c::ggml_runtime::gdn_output_scale(&node,17.F)),
              std::bit_cast<std::uint32_t>(value));
  }
  EXPECT_EQ(node.op_params[0],2);EXPECT_EQ(node.op_params[1],0x48594731);
}
#else
TEST(GdnOutputScale, RawDefaultAndFusedGatesKeepStateSnapshots) {
#if defined(HYLE_GDN_SCALE_APPLE)
  namespace mx=mlx::core;namespace a=c::apple;
  auto context=a::Context::create();ASSERT_TRUE(context)<<context.error().message();
#else
  namespace v=c::vulkan;
  auto context=vulkan_test::context().value();
#endif
  for(int mode=0;mode!=3;++mode) {
    const Fixture f(mode==1,mode==2);
    for(const std::optional<float> scale:{std::optional<float>{},std::optional<float>{1.F}}) {
      SCOPED_TRACE(::testing::Message()<<"mode="<<mode<<" explicit="<<scale.has_value());
#if defined(HYLE_GDN_SCALE_APPLE)
      std::vector<mx::array> inputs;std::vector<a::InputSpec> specs;
      for(std::size_t port=0;port<f.inputs.size();++port) {
        mx::Shape shape;for(auto d:f.inputs[port].dimensions())shape.push_back(int(d));
        inputs.emplace_back(f.data[port].data(),shape);
        specs.push_back({shape,inputs.back().dtype()});
      }
      auto prepared=context->prepare(f.operation(scale),specs);
      ASSERT_TRUE(prepared)<<prepared.error().message();
      auto invocation=prepared->create_invocation();ASSERT_TRUE(invocation);
      ASSERT_TRUE(invocation->bind(inputs).ok());
      auto work=invocation->submit();ASSERT_TRUE(work)<<work.error().message();
      auto done=work->wait();ASSERT_TRUE(done)<<done.error().message();
      const auto result=done->get()->arrays();ASSERT_EQ(result.size(),2U);
      f.check({result[0].data<float>(),result[0].size()},{result[1].data<float>(),result[1].size()},scale);
      EXPECT_EQ(std::memcmp(inputs.back().data<float>(),f.data.back().data(),f.data.back().size()*sizeof(float)),0);
#else
      std::vector<v::Argument> specs;std::vector<v::Tensor> inputs;
      for(std::size_t port=0;port<f.inputs.size();++port) {
        specs.emplace_back(f.inputs[port]);inputs.push_back(vulkan_test::upload(context,f.inputs[port],f.data[port]).value());
      }
      auto prepared=v::prepare(context,f.operation(scale),specs);
      ASSERT_TRUE(prepared)<<prepared.error().message();
      auto invocation=prepared->create_invocation();ASSERT_TRUE(invocation);
      ASSERT_TRUE(invocation->bind(inputs).ok());
      auto work=invocation->submit();ASSERT_TRUE(work)<<work.error().message();
      auto done=work->wait();ASSERT_TRUE(done)<<done.error().message();
      const auto result=done->get()->tensors();ASSERT_EQ(result.size(),2U);
      auto y=vulkan_test::read(context,result[0]).value(),s=vulkan_test::read(context,result[1]).value();
      f.check(y,s,scale);EXPECT_EQ(vulkan_test::read(context,inputs.back()).value(),f.data.back());
#endif
    }
  }
}
#endif

TEST(GdnOutputScale, PublicInferenceRejectsNonfiniteAndRetainsExplicitDomain) {
  for(bool recurrent:{false,true}) {
    const Fixture f(false,recurrent);
    for(float scale:{0.F,-0.F,-2.F,1.F}) {
      std::array<c::TensorDesc,2> outputs;
      EXPECT_TRUE(c::infer_output_descriptions(f.operation(scale),f.inputs,outputs).ok());
    }
    for(float scale:{std::numeric_limits<float>::infinity(),-std::numeric_limits<float>::infinity(),
                     std::numeric_limits<float>::quiet_NaN()}) {
      std::array<c::TensorDesc,2> outputs;
      EXPECT_TRUE(c::infer_output_descriptions(f.operation(scale),f.inputs,outputs).IsInvalidArgument());
      EXPECT_FALSE(outputs[0].valid());EXPECT_FALSE(outputs[1].valid());
    }
  }
}
} // namespace
'''
put("tests/compute_provider_native/gdn_output_scale_test.cc", focused_test)
test_targets = [
    ("tests/compute_provider_ggml/CMakeLists.txt", "if(HYLE_GGML_CPU_ENABLED)\n", "compute_provider_ggml", "CPU", "hyle_compute_backend_cpu"),
    ("tests/compute_provider_ggml_cuda/CMakeLists.txt", "if(_HYLE_COMPUTE_HAVE_CUDA)\n", "compute_provider_ggml_cuda", "CUDA", "hyle_compute_backend_cuda"),
    ("tests/compute_route_apple/CMakeLists.txt", "if(_HYLE_COMPUTE_HAVE_APPLE)\n", "compute_route_apple", "APPLE", ""),
    ("tests/compute_route_vulkan/CMakeLists.txt", "if(_HYLE_COMPUTE_HAVE_VULKAN)\n", "compute_route_vulkan", "VULKAN", "hyle_compute_provider_ggml_vulkan"),
]
for name, marker, module, backend, deps in test_targets:
    text = load(name)
    index = text.index(marker)+len(marker)
    block = (f"  hyle_add_test({module} NAME gdn_output_scale\n"
             "    SOURCES ../compute_provider_native/gdn_output_scale_test.cc" +
             (" DEPS " + deps if deps else "") + ")\n"
             f"  target_compile_definitions(hyle_{module}_gdn_output_scale_test PRIVATE HYLE_GDN_SCALE_{backend}=1)\n")
    if backend in ("CPU", "CUDA"):
        block += f"  target_link_libraries(hyle_{module}_gdn_output_scale_test PRIVATE ggml)\n"
    block += f"  hyle_stage_runtime(hyle_{module}_gdn_output_scale_test)\n"
    put(name, text[:index]+block+text[index:])
save()
