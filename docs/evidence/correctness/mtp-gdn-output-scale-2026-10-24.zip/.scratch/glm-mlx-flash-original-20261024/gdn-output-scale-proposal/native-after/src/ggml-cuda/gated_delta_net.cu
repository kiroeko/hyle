#include "gated_delta_net.cuh"
#include "gated_delta_scale.h"

extern "C" std::int32_t ggml_hyle_cuda_gdn_output_scale_contract() {
    return hyle::compute::ggml_runtime::kGdnOutputScaleContract;
}

#include "ggml-cuda/common.cuh"
#include "convert.cuh"

// Private carrier: only V/beta may replace a materialized F32 widening edge.
// This predicate is metadata-only: buffers/data need not exist during sizing.
bool ggml_cuda_supports_gated_delta_net_typed(const ggml_tensor * dst) {
    if (!dst || dst->op != GGML_OP_GATED_DELTA_NET || dst->type != GGML_TYPE_F32) return false;
    const ggml_tensor * const q = dst->src[0], * const k = dst->src[1], * const v = dst->src[2];
    const ggml_tensor * const g = dst->src[3], * const beta = dst->src[4], * const state = dst->src[5];
    if (!q || !k || !v || !g || !beta || !state || q->type != GGML_TYPE_F32 ||
        k->type != GGML_TYPE_F32 || g->type != GGML_TYPE_F32 || state->type != GGML_TYPE_F32 ||
        (v->type != GGML_TYPE_F32 && v->type != GGML_TYPE_BF16) ||
        (beta->type != GGML_TYPE_F32 && beta->type != GGML_TYPE_BF16)) return false;
    const int64_t S = v->ne[0], H = v->ne[1], T = v->ne[2], B = v->ne[3];
    const int K = ggml_get_op_params_i32(dst, 0);
    if ((S != 16 && S != 32 && S != 64 && S != 128) || H <= 0 || H > INT32_MAX ||
        T <= 0 || T > INT32_MAX || B <= 0 || B > UINT32_MAX || K < 1 ||
        !ggml_are_same_shape(q, k) || !ggml_are_same_stride(q, k) ||
        q->ne[0] != S || q->ne[1] <= 0 || H % q->ne[1] || q->ne[2] != T ||
        q->ne[3] <= 0 || B % q->ne[3] ||
        (g->ne[0] != 1 && g->ne[0] != S) || beta->ne[0] != 1 ||
        g->ne[1] != H || g->ne[2] != T || g->ne[3] != B ||
        beta->ne[1] != H || beta->ne[2] != T || beta->ne[3] != B ||
        state->ne[0] != S || state->ne[1] != S || state->ne[2] != H || state->ne[3] != B ||
        !ggml_is_contiguous_rows(q) || !ggml_is_contiguous_rows(k) ||
        !ggml_is_contiguous_rows(v) || !ggml_is_contiguous(g) ||
        !ggml_is_contiguous(beta) || !ggml_is_contiguous(state) || !ggml_is_contiguous(dst)) return false;
    // All kernel offsets are signed element offsets. Also prove ggml_nbytes
    // cannot overflow before later bound owner/capacity/range validation.
    const ggml_tensor * const tensors[] = {q, k, v, g, beta, state, dst};
    for (const auto * tensor : tensors) {
        const size_t element = ggml_type_size(tensor->type);
        size_t bytes = element;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0 ||
                (tensor->ne[axis] > 1 && tensor->nb[axis] % element)) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
    }
    const auto mul = [](int64_t a, int64_t b, int64_t & result) {
        if (a > INT64_MAX / b) return false;
        result = a * b;
        return true;
    };
    int64_t width, token_rows, state_rows, rows, elements;
    if (!mul(S, H, width) || !mul(T, B, token_rows) || !mul(K, S, state_rows) ||
        !mul(state_rows, B, state_rows) || token_rows > INT64_MAX - state_rows) return false;
    rows = token_rows + state_rows;
    return mul(width, rows, elements) && elements <= INT64_MAX / int64_t(sizeof(float)) &&
        dst->ne[0] == width && dst->ne[1] == rows && dst->ne[2] == 1 && dst->ne[3] == 1;
}


template <int S_v, bool KDA, bool keep_rs_t, typename TV, typename TB>
__global__ void __launch_bounds__((ggml_cuda_get_physical_warp_size() < S_v ? ggml_cuda_get_physical_warp_size() : S_v) * 4, 2)
gated_delta_net_cuda(const float * q,
                                     const float * k,
                                     const TV * v,
                                     const float * g,
                                     const TB * beta,
                                     const float * curr_state,
                                     float *       dst,
                                     float *       state,
                                     int64_t       H,
                                     int64_t       n_tokens,
                                     int64_t       n_seqs,
                                     int64_t       sq1,
                                     int64_t       sq2,
                                     int64_t       sq3,
                                     int64_t       sv1,
                                     int64_t       sv2,
                                     int64_t       sv3,
                                     int64_t       sg1,
                                     int64_t       sg2,
                                     int64_t       sg3,
                                     int64_t       sb1,
                                     int64_t       sb2,
                                     int64_t       sb3,
                                     const uint3   neqk1_magic,
                                     const uint3   rq3_magic,
                                     float         scale,
                                     int64_t       state_slot_stride,
                                     int           K) {
    const uint32_t h_idx    = blockIdx.x;
    const uint32_t sequence = blockIdx.y;
    // each warp owns one column, using warp-level primitives to reduce across rows
    const int      lane     = threadIdx.x;
    const int      col      = blockIdx.z * blockDim.y + threadIdx.y;

    const uint32_t iq1 = fastmodulo(h_idx, neqk1_magic);
    const uint32_t iq3 = fastdiv(sequence, rq3_magic);

    float *       attn_data        = dst;

    // input state holds s0 only: [S_v, S_v, H, n_seqs] — seq stride is D = H * S_v * S_v.
    // output state layout (per-slot D * n_seqs) — same per-(seq,head) offset as before.
    const int64_t state_in_offset      = sequence * H * S_v * S_v + h_idx * S_v * S_v;
    const int64_t state_out_offset     = (sequence * H + h_idx) * S_v * S_v;
    state += state_out_offset;
    curr_state += state_in_offset + col * S_v;
    attn_data += (sequence * n_tokens * H + h_idx) * S_v;

    constexpr int warp_size = ggml_cuda_get_physical_warp_size() < S_v ? ggml_cuda_get_physical_warp_size() : S_v;
    static_assert(S_v % warp_size == 0, "S_v must be a multiple of warp_size");
    constexpr int rows_per_lane = (S_v + warp_size - 1) / warp_size;
    float         s_shard[rows_per_lane];
    // state is stored transposed: M[col][i] = S[i][col], row col is contiguous

    ggml_cuda_pdl_sync();
#pragma unroll
    for (int r = 0; r < rows_per_lane; r++) {
        const int i = r * warp_size + lane;
        s_shard[r]  = curr_state[i];
    }

    for (int t = 0; t < n_tokens; t++) {
        const float * q_t = q + iq3 * sq3 + t * sq2 + iq1 * sq1;
        const float * k_t = k + iq3 * sq3 + t * sq2 + iq1 * sq1;
        const TV * v_t = v + sequence * sv3 + t * sv2 + h_idx * sv1;

        const TB * beta_t = beta + sequence * sb3 + t * sb2 + h_idx * sb1;
        const float * g_t = g + sequence * sg3 + t * sg2 + h_idx * sg1;

        const float beta_val = ggml_cuda_cast<float>(*beta_t);

        // Cache k and q in registers
        float k_reg[rows_per_lane];
        float q_reg[rows_per_lane];
#pragma unroll
        for (int r = 0; r < rows_per_lane; r++) {
            const int i = r * warp_size + lane;
            k_reg[r] = k_t[i];
            q_reg[r] = q_t[i];
        }

        if constexpr (!KDA) {
            const float g_val = expf(*g_t);

            // kv[col] = (S^T @ k)[col] = sum_i S[i][col] * k[i]
            float kv_shard = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                kv_shard += s_shard[r] * k_reg[r];
            }
            float kv_col = warp_reduce_sum<warp_size>(kv_shard);

            // delta[col] = (v[col] - g * kv[col]) * beta
            float delta_col = (ggml_cuda_cast<float>(v_t[col]) - g_val * kv_col) * beta_val;

            // fused: S[i][col] = g * S[i][col] + k[i] * delta[col]
            // attn[col] = (S^T @ q)[col] = sum_i S[i][col] * q[i]
            float attn_partial = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                s_shard[r]  = g_val * s_shard[r] + k_reg[r] * delta_col;
                attn_partial += s_shard[r] * q_reg[r];
            }

            float attn_col = warp_reduce_sum<warp_size>(attn_partial);

            if (lane == 0) {
                attn_data[col] = attn_col * scale;
            }
        } else {
            // kv[col] = sum_i g[i] * S[i][col] * k[i]
            float kv_shard = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                const int i = r * warp_size + lane;
                kv_shard += expf(g_t[i]) * s_shard[r] * k_reg[r];
            }

            float kv_col = warp_reduce_sum<warp_size>(kv_shard);

            // delta[col] = (v[col] - kv[col]) * beta
            float delta_col = (ggml_cuda_cast<float>(v_t[col]) - kv_col) * beta_val;

            // fused: S[i][col] = g[i] * S[i][col] + k[i] * delta[col]
            // attn[col] = (S^T @ q)[col] = sum_i S[i][col] * q[i]
            float attn_partial = 0.0f;
#pragma unroll
            for (int r = 0; r < rows_per_lane; r++) {
                const int i = r * warp_size + lane;
                s_shard[r]  = expf(g_t[i]) * s_shard[r] + k_reg[r] * delta_col;
                attn_partial += s_shard[r] * q_reg[r];
            }

            float attn_col = warp_reduce_sum<warp_size>(attn_partial);

            if (lane == 0) {
                attn_data[col] = attn_col * scale;
            }
        }

        attn_data += S_v * H;

        if constexpr (keep_rs_t) {
            // snapshot slot mapping: slot 0 = most recent state, slot s = s tokens back.
            // When n_tokens < K only slots 0..n_tokens-1 are written; older slots are caller-owned.
            const int target_slot = (int) n_tokens - 1 - t;
            if (target_slot >= 0 && target_slot < K) {
                float * curr_state = state + target_slot * state_slot_stride;
#pragma unroll
                for (int r = 0; r < rows_per_lane; r++) {
                    const int i = r * warp_size + lane;
                    curr_state[col * S_v + i] = s_shard[r];
                }
            }
        }
    }

    if constexpr (!keep_rs_t) {
#pragma unroll
        for (int r = 0; r < rows_per_lane; r++) {
            const int i          = r * warp_size + lane;
            state[col * S_v + i] = s_shard[r];
        }
    }
}

template <bool KDA, bool keep_rs_t, typename TV, typename TB>
static void launch_gated_delta_net(
        const float * q_d, const float * k_d, const TV * v_d,
        const float * g_d, const TB * b_d, const float * s_d,
        float * dst_d, float * state_d,
        int64_t S_v,   int64_t H, int64_t n_tokens, int64_t n_seqs,
        int64_t sq1,   int64_t sq2, int64_t sq3,
        int64_t sv1,   int64_t sv2, int64_t sv3,
        int64_t sg1,   int64_t sg2, int64_t sg3,
        int64_t sb1,   int64_t sb2, int64_t sb3,
        int64_t neqk1, int64_t rq3,
        float scale, int64_t state_slot_stride, int K, cudaStream_t stream) {
    //TODO: Add chunked kernel for even faster pre-fill
    const int warp_size = ggml_cuda_info().devices[ggml_cuda_get_device()].warp_size;
    const int num_warps = 4;
    dim3      grid_dims(H, n_seqs, (S_v + num_warps - 1) / num_warps);
    dim3      block_dims(warp_size <= S_v ? warp_size : S_v, num_warps, 1);

    const uint3 neqk1_magic = init_fastdiv_values(neqk1);
    const uint3 rq3_magic   = init_fastdiv_values(rq3);

    const ggml_cuda_kernel_launch_params launch_params = ggml_cuda_kernel_launch_params(grid_dims, block_dims, 0, stream);
    switch (S_v) {
        case 16:
            ggml_cuda_kernel_launch(gated_delta_net_cuda<16, KDA, keep_rs_t, TV, TB>, launch_params,
                q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d, H,
                n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1_magic, rq3_magic, scale, state_slot_stride, K);
            break;
        case 32:
            ggml_cuda_kernel_launch(gated_delta_net_cuda<32, KDA, keep_rs_t, TV, TB>, launch_params,
                q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d, H,
                n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1_magic, rq3_magic, scale, state_slot_stride, K);
            break;
        case 64: {
            ggml_cuda_kernel_launch(gated_delta_net_cuda<64, KDA, keep_rs_t, TV, TB>, launch_params,
                q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d, H,
                n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1_magic, rq3_magic, scale, state_slot_stride, K);
            break;
        }
        case 128: {
            ggml_cuda_kernel_launch(gated_delta_net_cuda<128, KDA, keep_rs_t, TV, TB>, launch_params,
                q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d, H,
                n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1_magic, rq3_magic, scale, state_slot_stride, K);
            break;
        }
        default:
            GGML_ABORT("fatal error");
            break;
    }
}

template <typename TV, typename TB>
static void ggml_cuda_op_gated_delta_net_impl(
        ggml_backend_cuda_context & ctx, ggml_tensor * dst, const ggml_cuda_gated_delta_net_fused_cache * cache) {
    ggml_tensor * src_q     = dst->src[0];
    ggml_tensor * src_k     = dst->src[1];
    ggml_tensor * src_v     = dst->src[2];
    ggml_tensor * src_g     = dst->src[3];
    ggml_tensor * src_beta  = dst->src[4];
    ggml_tensor * src_state = dst->src[5];

    GGML_TENSOR_LOCALS(int64_t, neq, src_q, ne);
    GGML_TENSOR_LOCALS(size_t , nbq, src_q, nb);
    GGML_TENSOR_LOCALS(int64_t, nek, src_k, ne);
    GGML_TENSOR_LOCALS(size_t , nbk, src_k, nb);
    GGML_TENSOR_LOCALS(int64_t, nev, src_v, ne);
    GGML_TENSOR_LOCALS(size_t,  nbv, src_v, nb);
    GGML_TENSOR_LOCALS(size_t,  nbb, src_beta, nb);
    GGML_TENSOR_LOCALS(size_t,  nbg, src_g, nb);

    const int64_t S_v      = nev0;
    const int64_t H        = nev1;
    const int64_t n_tokens = nev2;
    const int64_t n_seqs   = nev3;

    const bool kda = (src_g->ne[0] == S_v);

    GGML_ASSERT(neq1 == nek1);
    const int64_t neqk1 = neq1;

    const int64_t rq3 = nev3 / neq3;

    const float * q_d = (const float *) src_q->data;
    const float * k_d = (const float *) src_k->data;
    const TV * v_d = (const TV *) src_v->data;
    const float * g_d = (const float *) src_g->data;
    const TB * b_d = (const TB *) src_beta->data;

    const float * s_d   = (const float *) src_state->data;
    float *       dst_d = (float *) dst->data;

    GGML_ASSERT(ggml_is_contiguous_rows(src_q));
    GGML_ASSERT(ggml_is_contiguous_rows(src_k));
    GGML_ASSERT(ggml_is_contiguous_rows(src_v));
    GGML_ASSERT(ggml_are_same_stride(src_q, src_k));
    GGML_ASSERT(src_g->ne[0] == 1 || kda);
    GGML_ASSERT(ggml_is_contiguous(src_g));
    GGML_ASSERT(ggml_is_contiguous(src_beta));
    GGML_ASSERT(ggml_is_contiguous(src_state));

    // Per-port element strides: g remains F32, independently of typed beta.
    const int64_t sq1 = nbq1 / sizeof(float);
    const int64_t sq2 = nbq2 / sizeof(float);
    const int64_t sq3 = nbq3 / sizeof(float);
    const int64_t sv1 = nbv1 / sizeof(TV);
    const int64_t sv2 = nbv2 / sizeof(TV);
    const int64_t sv3 = nbv3 / sizeof(TV);
    const int64_t sg1 = nbg1 / sizeof(float);
    const int64_t sg2 = nbg2 / sizeof(float);
    const int64_t sg3 = nbg3 / sizeof(float);
    const int64_t sb1 = nbb1 / sizeof(TB);
    const int64_t sb2 = nbb2 / sizeof(TB);
    const int64_t sb3 = nbb3 / sizeof(TB);

    const float scale = hyle::compute::ggml_runtime::gdn_output_scale(
        dst, 1.0f / sqrtf((float) S_v));

    cudaStream_t stream = ctx.stream();

    // K (snapshot slot count) is an op param; state holds s0 only [S_v, S_v, H, n_seqs].
    const int K = ggml_get_op_params_i32(dst, 0);
    const bool keep_rs = K > 1;

    // recurrent state -> gdn_out tail (after attention scores), or the cache when fusing
    float * state_d           = dst_d + S_v * H * n_tokens * n_seqs;
    int64_t state_slot_stride = S_v * S_v * H * n_seqs;
    if (cache != nullptr) {
        state_d           = cache->data;
        state_slot_stride = cache->slot_stride;
    }

    if (kda) {
        if (keep_rs) {
            launch_gated_delta_net<true, true>(q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d,
                S_v, H, n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1, rq3, scale, state_slot_stride, K, stream);
        } else {
            launch_gated_delta_net<true, false>(q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d,
                S_v, H, n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1, rq3, scale, state_slot_stride, K, stream);
        }
    } else {
        if (keep_rs) {
            launch_gated_delta_net<false, true>(q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d,
                S_v, H, n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1, rq3, scale, state_slot_stride, K, stream);
        } else {
            launch_gated_delta_net<false, false>(q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d,
                S_v, H, n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1, rq3, scale, state_slot_stride, K, stream);
        }
    }
}

static void ggml_cuda_dispatch_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst,
        const ggml_cuda_gated_delta_net_fused_cache * cache) {
    if (dst->src[2]->type != GGML_TYPE_F32 || dst->src[4]->type != GGML_TYPE_F32) {
        if (!ggml_cuda_supports_gated_delta_net_typed(dst)) {
            hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid typed GDN metadata");
        }
        if (dst->src[2]->type == GGML_TYPE_BF16) {
            if (dst->src[4]->type == GGML_TYPE_BF16) {
                ggml_cuda_op_gated_delta_net_impl<nv_bfloat16, nv_bfloat16>(ctx, dst, cache);
            } else {
                ggml_cuda_op_gated_delta_net_impl<nv_bfloat16, float>(ctx, dst, cache);
            }
        } else {
            ggml_cuda_op_gated_delta_net_impl<float, nv_bfloat16>(ctx, dst, cache);
        }
    } else {
        ggml_cuda_op_gated_delta_net_impl<float, float>(ctx, dst, cache);
    }
}

void ggml_cuda_op_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_dispatch_gated_delta_net(ctx, dst, nullptr);
}

void ggml_cuda_op_gated_delta_net_fused_cache(
        ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_cuda_gated_delta_net_fused_cache cache) {
    ggml_cuda_dispatch_gated_delta_net(ctx, dst, &cache);
}
