from pathlib import Path
import hashlib,json,subprocess
S=Path(__file__).resolve().parent
R=S.parents[2]
def ident(path):
    raw=path.read_bytes()
    return len(raw),hashlib.sha256(raw).hexdigest()
ready=json.loads((S/'ready.json').read_text(encoding='utf-8-sig'))
patch=S/'source.patch'
assert ident(patch)==(ready['patch_bytes'],ready['patch_sha256'])
changes=json.loads((S/'changed-files.json').read_text(encoding='utf-8-sig'))
assert len(changes)==ready['files']==23
for item in changes:
    path=R/item['path']
    if item['before_bytes']==0:
        assert not path.exists(),item['path']
    else:
        assert ident(path)==(item['before_bytes'],item['before_sha256']),item['path']
subprocess.run(['git','apply','--check',str(patch)],cwd=R,check=True)
subprocess.run(['git','apply',str(patch)],cwd=R,check=True)
for item in changes:
    assert ident(R/item['path'])==(item['after_bytes'],item['after_sha256']),item['path']
(S/'applied.json').write_text(json.dumps(dict(patch_sha256=ready['patch_sha256'],
    files=changes,applied=True,compiled=False,native_executed=False),indent=2)+'\n',encoding='utf-8')
print('Applied optional GDN output scale and four native lowering paths; build/native pending')
