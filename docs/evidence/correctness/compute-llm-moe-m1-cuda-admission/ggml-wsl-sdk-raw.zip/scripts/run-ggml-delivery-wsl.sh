#!/bin/bash
set -euo pipefail
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
for source in /root/hyle-m1c-source /root/hyle-m1c-ggml-source; do
  test -d "$source"
  tar -xzf "$task/product-worktree.tar.gz" -C "$source"
done
python3 "$task/ggml-delivery-wsl.py"
