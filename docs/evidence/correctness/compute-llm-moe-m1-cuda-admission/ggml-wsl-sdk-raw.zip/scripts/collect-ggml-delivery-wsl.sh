#!/bin/bash
set -euo pipefail
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission/ggml-delivery-wsl
root=/root/hyle-m1c-sdk
for pair in 'static ggml-static-consumer' 'source source-build' 'shared ggml-shared-consumer'; do
  read -r label build <<< "$pair"
  cp "$root/$build/Testing/Temporary/LastTest.log" "$task/$label-LastTest.log"
  cp "$root/$build/CMakeCache.txt" "$task/$label-CMakeCache.txt"
  sha256sum "$root/$build/m1c_attention" > "$task/$label-binary-sha256.log"
done
cp "$root/consumer/CMakeLists.txt" "$task/consumer-CMakeLists.txt"
nm -D --defined-only "$root/ggml-shared-relocated/lib/libhyle_compute_provider_ggml_cuda.so" \
  > "$task/ggml-compute-exports.log"
nm -D --defined-only "$root/ggml-shared-relocated/lib/libhyle_graph_provider_ggml_cuda.so" \
  > "$task/ggml-graph-exports.log"
if grep -E ' [TDB] (ggml_|_Z[^ ]*ggml_backend)' "$task/ggml-compute-exports.log" "$task/ggml-graph-exports.log"; then
  exit 1
fi
find "$root/ggml-shared-relocated/share/licenses/Hyle" -maxdepth 1 -type f -name '*ggml*' -print \
  > "$task/ggml-license-files.log"
cat "$task/ggml-compute-exports.log" "$task/ggml-graph-exports.log"
