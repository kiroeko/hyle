"""Bounded compile-only adaptation of two CUDA spellings; no shipping changes."""
from pathlib import Path
import hashlib
import json
import shutil

upstream = Path('C:/hyle-scratch/m1c-qapi/flashinfer-69ff11fc4954396d98326656dc85debd2223f637/include')
output = Path('.scratch/m1c-fi/include')
assert not output.exists()
shutil.copytree(upstream, output)
changes = []
for relative, old, new in [
    ('flashinfer/vec_dtypes.cuh', '#define FLASHINFER_INLINE inline __attribute__((always_inline)) __device__',
     '#define FLASHINFER_INLINE __forceinline__ __device__'),
    ('flashinfer/attention/decode.cuh', 'extern __attribute__((shared)) uint8_t smem[];',
     'extern __shared__ uint8_t smem[];'),
]:
    path = output / relative
    before = path.read_bytes()
    assert before.count(old.encode()) == 1
    after = before.replace(old.encode(), new.encode())
    path.write_bytes(after)
    changes.append(dict(path=relative, before_sha256=hashlib.sha256(before).hexdigest(),
                        after_sha256=hashlib.sha256(after).hexdigest(), old=old, new=new))
Path('.scratch/validation/m1-cuda-admission/portability-inputs.json').write_text(
    json.dumps(dict(qualification_only=True, changes=changes), indent=2) + '\n', encoding='utf-8')
