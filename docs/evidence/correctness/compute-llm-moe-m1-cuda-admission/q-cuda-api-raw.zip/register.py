import json
from pathlib import Path

p = Path('docs/implementation/module-status.json')
data = json.loads(p.read_text(encoding='utf-8'))
names = ('compute_provider_ggml_cuda', 'graph_provider_ggml_cuda', 'compute_provider_flashinfer')
assert not any(r['module'] in names for r in data['modules'])
for name in names:
    data['modules'].append({'module': name, 'state': 'QUEUED',
                           'summary': 'M1-C 准入身份已登记；先按模型需求审计原版 CUDA 资源/ABI 与接入资格，无 target、依赖、产品实现或覆盖声明。全部自研算子仍冻结。'})
p.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())
