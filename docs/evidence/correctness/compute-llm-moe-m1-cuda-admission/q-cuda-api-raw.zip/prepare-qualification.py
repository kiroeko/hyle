import hashlib
import json
from pathlib import Path
import shutil
import tarfile

task = Path(__file__).resolve().parent
intake = task.parent / 'm1-route-binding/m1-cuda-intake'
revision = '69ff11fc4954396d98326656dc85debd2223f637'
archive = intake / ('flashinfer-' + revision + '.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '4fc85abaa6210d6a1773e6011ff572aa0c04b7030644b74f75a2db2dbda472a9'
root = Path('C:/hyle-scratch/m1c-qapi')
root.mkdir(parents=True, exist_ok=True)
upstream = root / ('flashinfer-' + revision)
assert not upstream.exists()
with tarfile.open(archive) as source:
    prefix = 'flashinfer-' + revision + '/'
    members = [m for m in source.getmembers() if m.name.startswith(prefix + 'include/') or m.name == prefix + 'LICENSE']
    source.extractall(root, members=members, filter='data')
shutil.copyfile(task / 'flashinfer_qual.cu', root / 'probe.cu')
command = r'''@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
if errorlevel 1 exit /b %errorlevel%
cd /d C:\hyle-scratch\m1c-qapi
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\nvcc.exe" --version
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\nvcc.exe" --std=c++17 -arch=sm_89 --cudart=static -DFLASHINFER_ENABLE_BF16 -DFLASHINFER_ENABLE_F16 -I"C:\hyle-scratch\m1c-qapi\flashinfer-69ff11fc4954396d98326656dc85debd2223f637\include" probe.cu -o probe.exe
exit /b %errorlevel%
'''
(root / 'compile.cmd').write_bytes(command.replace('\n', '\r\n').encode())
record = {'source': revision, 'source_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'probe_sha256': hashlib.sha256((root / 'probe.cu').read_bytes()).hexdigest(),
          'qualification_only': True, 'product_coverage': 0}
(task / 'qualification-inputs.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(root)
