@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
if errorlevel 1 exit /b %errorlevel%
cd /d C:\public\project-hyle\hyle\.scratch\validation\m1-cuda-admission
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\nvcc.exe" --std=c++17 -arch=sm_89 --cudart=static -DFLASHINFER_ENABLE_BF16 -DFLASHINFER_ENABLE_F16 -Xcompiler /Zc:preprocessor -Xcompiler /utf-8 -Xcompiler /Drestrict=__restrict -I"C:\public\project-hyle\hyle\.scratch\m1c-fi\include" flashinfer_qual.cu -o flashinfer_qual.exe
exit /b %errorlevel%
