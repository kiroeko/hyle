// Task-local qualification of the pinned upstream C++ entries, not HYLE product code.
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <flashinfer/attention/default_decode_params.cuh>
#include <flashinfer/attention/default_prefill_params.cuh>
#include <flashinfer/attention/variants.cuh>
#include <flashinfer/attention/decode.cuh>
#include <flashinfer/attention/prefill.cuh>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <vector>

void check(cudaError_t status) {
  if (status != cudaSuccess) throw std::runtime_error(cudaGetErrorString(status));
}
template<class T> struct Buffer {
  T *data = nullptr;
  explicit Buffer(std::size_t count) { check(cudaMalloc(&data, count * sizeof(T))); }
  ~Buffer() { if (data) (void)cudaFree(data); }
  Buffer(const Buffer &) = delete;
  Buffer &operator=(const Buffer &) = delete;
};
struct Stream {
  cudaStream_t value = nullptr;
  Stream() { check(cudaStreamCreateWithFlags(&value, cudaStreamNonBlocking)); }
  ~Stream() { if (value) (void)cudaStreamDestroy(value); }
};
template<class T> T encode(float value);
template<> half encode<half>(float value) { return __float2half_rn(value); }
template<> __nv_bfloat16 encode<__nv_bfloat16>(float value) { return __float2bfloat16_rn(value); }
float decode(half value) { return __half2float(value); }
float decode(__nv_bfloat16 value) { return __bfloat162float(value); }

template<class T> void exercise(const char *name, int query_length, int kv_length) {
  constexpr int heads = 8, kv_heads = 2, depth = 256;
  constexpr float scale = 0.0625f;
  std::vector<T> q(query_length * heads * depth), k(kv_length * kv_heads * depth), v(k.size()), out(q.size());
  for (std::size_t i = 0; i < q.size(); ++i) q[i] = encode<T>((int(i % 29) - 14) * 0.03125f);
  for (std::size_t i = 0; i < k.size(); ++i) {
    k[i] = encode<T>((int(i % 23) - 11) * 0.0625f);
    v[i] = encode<T>((int(i % 31) - 15) * 0.046875f);
  }
  // Each call has independent device/workspace/stream ownership.
  Stream stream;
  Buffer<T> dq(q.size()), dk(k.size()), dv(v.size()), output(out.size()), temporary(1024 * 1024);
  check(cudaMemcpyAsync(dq.data, q.data(), q.size() * sizeof(T), cudaMemcpyHostToDevice, stream.value));
  check(cudaMemcpyAsync(dk.data, k.data(), k.size() * sizeof(T), cudaMemcpyHostToDevice, stream.value));
  check(cudaMemcpyAsync(dv.data, v.data(), v.size() * sizeof(T), cudaMemcpyHostToDevice, stream.value));
  using Variant = flashinfer::DefaultAttention<false, false, false, false>;
  for (int replay = 0; replay < 3; ++replay) {
    if (query_length == 1) {
      flashinfer::SingleDecodeParams<T, T, T> params(dq.data, dk.data, dv.data, output.data, nullptr,
        kv_length, heads, kv_heads, flashinfer::QKVLayout::kNHD, depth, -1, 0.0f, scale, 1.0f, 10000.0f);
      check(flashinfer::SingleDecodeWithKVCacheDispatched<depth, flashinfer::PosEncodingMode::kNone, Variant>(params, temporary.data, stream.value));
    } else {
      flashinfer::SinglePrefillParams<T, T, T> params(dq.data, dk.data, dv.data, nullptr, output.data,
        nullptr, nullptr, heads, kv_heads, query_length, kv_length, heads * depth, depth,
        kv_heads * depth, depth, depth, -1, 0.0f, scale, 1.0f, 10000.0f);
      check(flashinfer::SinglePrefillWithKVCacheDispatched<depth, depth,
        flashinfer::PosEncodingMode::kNone, false, flashinfer::MaskMode::kCausal, Variant>(params, temporary.data, stream.value));
    }
  }
  check(cudaMemcpyAsync(out.data(), output.data, out.size() * sizeof(T), cudaMemcpyDeviceToHost, stream.value));
  check(cudaStreamSynchronize(stream.value));
  // Independent double-precision reference over the actual quantized inputs.
  double max_error = 0;
  for (int n = 0; n < query_length; ++n) for (int h = 0; h < heads; ++h) {
    const int count = n + kv_length - query_length + 1;
    std::vector<double> logits(count);
    for (int s = 0; s < count; ++s) {
      double dot = 0;
      for (int d = 0; d < depth; ++d)
        dot += double(decode(q[(n * heads + h) * depth + d])) * decode(k[(s * kv_heads + h / 4) * depth + d]);
      logits[s] = dot * scale;
    }
    const double maximum = *std::max_element(logits.begin(), logits.end());
    double denominator = 0;
    for (double &x : logits) { x = std::exp(x - maximum); denominator += x; }
    for (int d = 0; d < depth; ++d) {
      double expected = 0;
      for (int s = 0; s < count; ++s)
        expected += logits[s] * decode(v[(s * kv_heads + h / 4) * depth + d]);
      expected /= denominator;
      double actual = decode(out[(n * heads + h) * depth + d]);
      if (!std::isfinite(actual)) throw std::runtime_error("non-finite attention output");
      max_error = std::max(max_error, std::abs(actual - expected));
      const double tolerance = sizeof(T) == 2 && name[0] == 'b' ? 0.01 : 0.002;
      if (std::abs(actual - expected) > tolerance) throw std::runtime_error("attention reference mismatch");
    }
  }
  std::printf("PASS %s head=256 heads=8 kv_heads=2 q=%d kv=%d replays=3 max_abs_error=%.9g\n", name, query_length, kv_length, max_error);
}
int main() {
  try {
    check(cudaSetDevice(0));
    cudaDeviceProp properties{};
    check(cudaGetDeviceProperties(&properties, 0));
    std::printf("Device=%s SM=%d%d CUDA=%d\n", properties.name, properties.major, properties.minor, CUDART_VERSION);
    if (properties.major != 8 || properties.minor != 9) throw std::runtime_error("qualification expects SM89");
    exercise<half>("fp16", 17, 17);
    exercise<half>("fp16", 1, 257);
    exercise<__nv_bfloat16>("bf16", 17, 17);
    exercise<__nv_bfloat16>("bf16", 1, 257);
    return 0;
  } catch (const std::exception &failure) {
    std::fprintf(stderr, "FAIL: %s\n", failure.what());
    return 1;
  }
}
