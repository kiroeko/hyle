#!/bin/sh
set -eu
qapi_root=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
qapi_upstream=/mnt/c/hyle-scratch/m1c-qapi/flashinfer-69ff11fc4954396d98326656dc85debd2223f637/include
cd "$qapi_root"
/usr/local/cuda-13.3/bin/nvcc --version
/usr/bin/g++-14 --version
/usr/local/cuda-13.3/bin/nvcc --std=c++17 -arch=sm_89 --cudart=static -ccbin /usr/bin/g++-14 \
  -DFLASHINFER_ENABLE_BF16 -DFLASHINFER_ENABLE_F16 -I"$qapi_upstream" \
  flashinfer_qual.cu -o flashinfer_qual-linux > wsl-original-build.log 2>&1
./flashinfer_qual-linux > wsl-original-run.log 2>&1
cat wsl-original-run.log
