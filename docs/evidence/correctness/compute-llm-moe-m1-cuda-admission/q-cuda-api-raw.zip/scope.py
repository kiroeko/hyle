import json
from pathlib import Path

p = Path('docs/implementation/module-status.json')
data = json.loads(p.read_text(encoding='utf-8'))
new = {'compute_provider_ggml_cuda', 'graph_provider_ggml_cuda', 'compute_provider_flashinfer'}
existing = {'compute_ggml_runtime', 'compute_route_cuda', 'graph_route_cuda'}
seen = set()
for r in data['modules']:
    name = r['module']
    if name not in new | existing:
        continue
    assert r['state'] == ('QUEUED' if name in new else 'CLOSED')
    r.clear()
    r.update(module=name, state='SCOPED', record='docs/implementation/tasks/compute/llm-moe-m1-cuda-admission.md',
             summary='M1-C SCOPED：按已锁ggml CUDA/FlashInfer原版入口审计资源、ABI、完成/失败与普通工厂；有限拟定C1–C6，尚无产品实现授权。全部自研冻结，旧CPU/oneDNN阻塞不变。')
    seen.add(name)
assert seen == new | existing
p.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())
