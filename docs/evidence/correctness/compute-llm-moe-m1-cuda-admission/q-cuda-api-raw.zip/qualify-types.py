"""Qualify LLP64/native CUDA type spellings without changing arithmetic."""
from pathlib import Path
import hashlib
import json

root = Path('.scratch/m1c-fi/include/flashinfer')
records = []
for name, old, new, count in [
    ('math.cuh', 'ushort y_u16;', 'unsigned short y_u16;', 2),
    ('attention/decode.cuh', 'std::max(16UL / sizeof(DTypeKV),',
     'std::max<size_t>(16UL / sizeof(DTypeKV),', 3),
]:
    path = root / name
    before = path.read_bytes()
    assert before.count(old.encode()) == count, (name, before.count(old.encode()))
    after = before.replace(old.encode(), new.encode())
    path.write_bytes(after)
    records.append(dict(path=name, before_sha256=hashlib.sha256(before).hexdigest(),
                        after_sha256=hashlib.sha256(after).hexdigest(), old=old, new=new, count=count))
Path('.scratch/validation/m1-cuda-admission/portability-type-inputs.json').write_text(
    json.dumps(records, indent=2) + '\n', encoding='utf-8')
