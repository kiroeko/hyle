"""Run the task-local qualification with noninteractive Windows failures."""
from pathlib import Path
import ctypes
import subprocess
import sys

root = Path('.scratch/validation/m1-cuda-admission')
if sys.argv[1] == 'windows':
    ctypes.windll.kernel32.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    with (root / 'windows-run.log').open('wb') as output:
        result = subprocess.run([str((root / 'flashinfer_qual.exe').resolve())],
                                stdout=output, stderr=subprocess.STDOUT)
    print((root / 'windows-run.log').read_text(encoding='utf-8', errors='replace'))
else:
    result = subprocess.run(['wsl', '-d', 'Ubuntu-24.04', '--', 'sh', '-s'],
                            input=(root / 'qualify-wsl.sh').read_bytes().replace(b'\r\n', b'\n'))
raise SystemExit(result.returncode)
