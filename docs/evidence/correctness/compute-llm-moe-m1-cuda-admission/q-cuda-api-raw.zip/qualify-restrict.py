"""Fix the two host declaration spellings exposed by the native compile."""
from pathlib import Path
import hashlib
import json

path = Path('.scratch/m1c-fi/include/flashinfer/pos_enc.cuh')
before = path.read_bytes()
old = b'cudaError_t BatchQKApplyLlama31Rotary(\n    DType* q, DType* k, DType* q_rope, DType* k_rope, IdType* __restrict__ indptr,\n    IdType* __restrict__ offsets,'
new = old.replace(b'__restrict__', b'__restrict')
assert before.count(old) == 1
after = before.replace(old, new)
path.write_bytes(after)
Path('.scratch/validation/m1-cuda-admission/portability-restrict-inputs.json').write_text(
    json.dumps(dict(path='flashinfer/pos_enc.cuh', before_sha256=hashlib.sha256(before).hexdigest(),
                    after_sha256=hashlib.sha256(after).hexdigest(), old=old.decode(), new=new.decode()),
               indent=2) + '\n', encoding='utf-8')
