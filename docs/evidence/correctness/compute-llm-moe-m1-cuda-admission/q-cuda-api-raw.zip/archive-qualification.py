"""Archive the bounded upstream admission evidence, including rejected paths."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

task = Path('.scratch/validation/m1-cuda-admission')
evidence = Path('evidence/correctness/compute-llm-moe-m1-cuda-admission')
evidence.mkdir(parents=True, exist_ok=True)
command = ['wsl', '-d', 'Ubuntu-24.04', '--',
           '/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission/flashinfer_qual-linux']
# The interrupted approval call lost its process receipt. Run only the exact,
# already-built small executable once to retain a terminal return code.
binary = task / 'flashinfer_qual-linux'
receipt = {'command': command, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(task / 'wsl-terminal-run.log').write_bytes(result.stdout)
receipt['returncode'] = result.returncode
assert result.returncode == 0
assert result.stdout.count(b'PASS ') == 4
for name, command in [
    ('nvcc', ['wsl', '-d', 'Ubuntu-24.04', '--', '/usr/local/cuda-13.3/bin/nvcc', '--version']),
    ('gxx', ['wsl', '-d', 'Ubuntu-24.04', '--', '/usr/bin/g++-14', '--version']),
]:
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
    receipt[name] = result.stdout.decode('utf-8')
(task / 'wsl-terminal-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
generated = (task / 'host-diagnostic.cpp').read_text(encoding='utf-8', errors='replace').splitlines()
start = next(i for i, line in enumerate(generated) if line.startswith('cudaError_t BatchQKApplyLlama31Rotary ('))
(task / 'windows-host-generated-excerpt.txt').write_text('\n'.join(generated[start:start + 9]) + '\n', encoding='utf-8')
bundle = evidence / 'q-cuda-api-raw.zip'
assert not bundle.exists()
names = sorted(p for p in task.iterdir() if p.is_file() and p.suffix in {'.log', '.json', '.py', '.cu', '.cmd', '.sh', '.txt'})
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in names:
        archive.write(path, path.name)
identity = {
    'baseline': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'upstream_commit': '69ff11fc4954396d98326656dc85debd2223f637',
    'upstream_archive_sha256': '4fc85abaa6210d6a1773e6011ff572aa0c04b7030644b74f75a2db2dbda472a9',
    'probe_sha256': hashlib.sha256((task / 'flashinfer_qual.cu').read_bytes()).hexdigest(),
    'qualification_only': True, 'new_model_coverage_cells': 0,
    'wsl': {'original_headers': True, 'sm': 89, 'head_dim': 256, 'returncode': receipt['returncode'],
            'verdict': 'PASS_ENTRY_QUALIFICATION', 'prefill': [17, 17], 'decode': [1, 257],
            'dtypes': ['FP16', 'BF16'], 'replays': 3},
    'windows': {'verdict': 'NOT_ADMITTED_THIS_PIN',
                'reason': 'native C++ compilation failed; bounded restrict root corrections exhausted',
                'mature_alternative': 'ggml CUDA original attention; product validation remains required',
                'diagnostic_source_patches_shipped': False},
    'raw': {'file': bundle.name, 'sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
            'bytes': bundle.stat().st_size, 'members': len(names)}
}
(evidence / 'q-cuda-api.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
print(json.dumps(identity, indent=2))
