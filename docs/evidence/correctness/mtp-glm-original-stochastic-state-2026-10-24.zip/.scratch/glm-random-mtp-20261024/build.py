from pathlib import Path
import argparse, importlib.util, json, os, subprocess, sys, time, hashlib
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
SOURCE=R/'tests/compute_models/glm_mtp_state_consumer_test.cc'
PRO=False
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
spec=importlib.util.spec_from_file_location('cached_cpu_builder',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def compile(attempt):
 out=S/f'compile{attempt}';out.mkdir(exist_ok=False)
 rec=read(R/'.scratch/glm-original-target43-20261023/compile1/glm-state/compile.command.json')
 command=[];skip=False
 for flag in rec['command']:
  if skip:skip=False;continue
  if flag=='/sourceDependencies':skip=True;continue
  if flag.startswith(('/Fo','/Fd')) or flag.endswith('glm_mtp_state_consumer_test.cc'):continue
  command.append(flag)
 command+=['/sourceDependencies',str(out/'deps.json'),str(SOURCE),'/Fo'+str(out/'test.obj')]
 env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 before=ident(SOURCE);save(out/'command.json',dict(command=command,cwd=str(R)))
 t=time.time()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  p=subprocess.run(command,cwd=R,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
 save(out/'process.json',dict(exit=p.returncode,seconds=time.time()-t))
 print('COMPILE',p.returncode,time.time()-t,flush=True)
 if p.returncode: print((out/'stdout.log').read_text(errors='replace'),(out/'stderr.log').read_text(errors='replace'));sys.exit(p.returncode)
 assert before==ident(before['path'])
 save(out/'identity.json',dict(source=before,object=ident(out/'test.obj'),command=command,dependencies=[ident(x) for x in read(out/'deps.json')['Data']['Includes']]))
def link(attempt):
 base=read(R/'.scratch/dspark-random-mtp-20261024/link-command.json')
 command=[x for x in base if not x.upper().startswith(('/OUT:','/IMPLIB:','/MAP:','/PDB:')) and not x.endswith('dspark-random-mtp-20261024\\consumer.obj')]
 command.insert(1,str(S/f'compile{attempt}/test.obj'))
 command+=['/OUT:'+str(S/'checks.exe'),'/IMPLIB:'+str(S/'checks.lib')]
 env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':str(Path(command[0]).with_name('cl.exe')),'CMAKE_CXX_COMPILER':str(Path(command[0]).with_name('cl.exe')),'CMAKE_GENERATOR':'Ninja'},backends=()).env
 objects=[ident(x) for x in command if x.lower().endswith(('.obj','.lib')) and Path(x).is_absolute()]
 save(S/'link-inputs.json',objects)
 b.execute(command,env,S/f'link{attempt}')
 save(S/'ready.json',dict(image=ident(S/'checks.exe'),new_SDK_TUs=0,consumer_TUs=1))
 dll=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
 if not (S/dll.name).exists():os.link(dll,S/dll.name)
def run(attempt):
 env=dict(os.environ,PATH=str(S)+';'+read(R/'.scratch/dspark-random-mtp-20261024/runtime.json')['PATH'])
 paths={
 'TARGET43_DIR':'glm-original-target43-20261023/original-target43',
 'TARGET43_MOE_DIR':'glm-original-target43-20261023/original-moe',
 'TARGET44_DIR':'glm-original-target44-20261023/original-target44',
 'TARGET44_MOE_DIR':'glm-original-target44-20261023/original-moe',
 'INPUT_DIR':'dspark-natural-journey-20261022/original-glm-input',
 'QUERY_DIR':'glm-mtp-carry-20261022/original-glm-q-a',
 'INDEXER_DIR':'glm-original-indexer-20261023/original-indexer',
 'SHARED_LM_DIR':'glm-shared-lm-20261023/original-lm',
 'ATTENTION_DIR':'glm-original-attention-20261023/original-attention',
 'MOE_DIR':'glm-original-moe-20261023/original-moe'}
 for key,path in paths.items():env['HYLE_GLM_MTP_'+key]=str(R/'.scratch'/path)
 if PRO:
  env.update(HYLE_GLM_PRO_DIR=str(R/'.scratch/glm-pro-nextn-20261023/original-static'),HYLE_GLM_PRO_MOE_DIR=str(R/'.scratch/glm-pro-nextn-20261023/original-moe'),HYLE_GLM_PRO_TARGET_DIR=str(R/'.scratch/glm-pro-target77-20261023/original-static'),HYLE_GLM_PRO_TARGET_MOE_DIR=str(R/'.scratch/glm-pro-target77-20261023/original-moe'))
 save(S/f'run{attempt}-inputs.json',{k:v for k,v in env.items() if k.startswith('HYLE_GLM')})
 name='GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically' if PRO else 'GlmMtpStateConsumer.CudaOriginalTarget43And44AndNextNRandomVerifierContinuesAtomically'
 command=[str(S/'checks.exe'),'--gtest_filter='+name,'--gtest_output=xml:'+str(S/f'run{attempt}/results.xml')]
 b.execute(command,env,S/f'run{attempt}',timeout=600)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('actions',nargs='*',choices=['compile','link','run']);p.add_argument('--attempt',type=int,default=1);p.add_argument('--pro',action='store_true');a=p.parse_args()
 if a.pro:PRO=True;S=S/'pro';S.mkdir(exist_ok=True);SOURCE=R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
 for action in a.actions or ['compile']:globals()[action](a.attempt)
