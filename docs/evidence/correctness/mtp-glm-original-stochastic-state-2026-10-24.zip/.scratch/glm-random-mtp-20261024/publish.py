from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,difflib
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def case(p):
 tree=ET.parse(p/'run1/results.xml').getroot()
 assert tree.attrib['tests']=='1' and all(tree.attrib.get(k,'0')=='0' for k in ('failures','errors','disabled'))
 item=next(tree.iter('testcase'));assert item.find('skipped') is None
 return dict(process=read(p/'run1/process.json'),image=read(p/'ready.json')['image'],test=item.attrib,properties={q.attrib['name']:q.attrib['value'] for q in item.iter('property')},
  actual_transitions=[line for line in (p/'run1/stdout.log').read_text(errors='replace').splitlines() if 'GLM RANDOM K1 ' in line or 'GLM Pro K1 stochastic=1 ' in line])
flash=case(S);pro=case(S/'pro')
assert flash['process']['exit']==pro['process']['exit']==0
assert flash['properties']['random_published_rounds']=='4' and flash['properties']['random_accepted']=='1' and flash['properties']['random_rejected']=='1'
assert pro['properties']['random_committed_draws']=='4'
old=S/'source/tests/compute_models/glm_mtp_state_consumer_test.cc';current=R/'tests/compute_models/glm_mtp_state_consumer_test.cc'
delta=''.join(difflib.unified_diff(old.read_text().splitlines(True),current.read_text().splitlines(True),fromfile='executed-flash-source',tofile='current-product-source'))
(S/'flash-post-run-registration-and-cpu-guard.patch').write_text(delta,encoding='utf8')
records=[]
for root in (S,S/'pro'):
 for sub in ('compile3' if root==S else 'compile1','link3' if root==S else 'link1','run1'):
  for p in (root/sub).glob('*'):
   if p.is_file() and p.suffix in ('.json','.log','.xml'):records.append(p)
 for name in ('ready.json','link-inputs.json','source-records.json','run1-inputs.json'):
  records.append(root/name)
 records.extend(p for p in (root/'source').rglob('*') if p.is_file())
for sub in ('adapter-command.json','adapter-process.json','adapter-stderr.log','adapter-stdout.log','build.py','publish.py','flash-post-run-registration-and-cpu-guard.patch','cpu-syntax2-source.json','pro-cpu-syntax-source.json'):
 records.append(S/sub)
for sub in ('cpu-syntax2','pro-cpu-syntax'):
 records.extend(p for p in (S/sub).glob('*') if p.is_file() and p.suffix in ('.json','.log'))
for relative in ('tests/compute_models/glm_mtp_state_consumer_test.cc','tests/compute_models/glm_pro_mtp_state_consumer_test.cc','tests/compute_models/glm_target_verifier_fragment.h','tests/compute_models/model_sampling_fragment.h','engine/inference/sampling_graph.h','engine/inference/sampling_cursor.h'):
 records.append(R/relative)
out=R/'docs/evidence/correctness/mtp-glm-original-stochastic-state-2026-10-24'
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(records)):z.write(p,p.relative_to(R))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
summary=dict(date='2026-10-24',scope='Finite original-role GLM Flash/Pro stochastic MTP consumer closure; not a complete GLM inference engine or whole-model quality result',
 result='PASS bounded original-role CUDA component journeys and CPU-only strict syntax',
 changes=[
  'Use one shared hyle::inference sampling Graph construction and SamplingCursor; fixed fragment-local IDs are statically adapted without forged Graph IDs, duplicated acceptance mathematics or new executor.',
  'Retain actual original NextN full-vocabulary logits, categorical-sample q, bind its real I32 proposal lease into target row1, and use real p0/q/p1 common acceptance/residual/bonus outputs.',
  'Append one optional Cursor HostMetadata member to each original model schema; complete prefix state, actual pending and advanced cursor publish through the existing expected-base StateHead atomically.',
  'Keep original trained-state repair/catchup and finite pools/supplier. Cancelled/wrong-type/stale/pre-submit failures do not advance committed RNG.',
  'Register separate CPU/CUDA stochastic tests in their existing CMake-discovered consumer sources. A CPU-only compile also caught and fixed an existing artifact-MoE helper unused-parameter/CUDA-unavailable guard.'],
 flash=flash,pro=pro,
 coverage=dict(flash='Natural default proposal0/accept1/final2 rejects and consumes its true residual in the next K1 round; independent host Philox search finds accept address31 in [2,262144) for the identical real proposal/q/p0/p1, commits the full reserved range33, then consumes its true bonus in another ordinary K1 round. Four actual successful complete state publications, cancel/stale/retry/disabled-driver checks.',
  pro='One natural default three-draw K1 rejection, real residual consumption by original target77+NextN78, then a one-draw target-only actual continuation and atomic final pending/cursor. Original complete StateStore resources and previous trained repair/catchup remain shared; no forced branch.',
  cpu='MSVC /Zs /W4 /WX with HYLE_COMPUTE_CPU and CPU-only test macro passed separately for current Flash and Pro sources; stochastic CPU device runtime is not claimed by these syntax checks.',
  source='Official selected original roles and exact bounded expert caches already present. No new HTTP or weight bytes, no new SDK/provider/native compilation; exactly one consumer TU per executed model.'),
 architecture_seams=dict(model_consumers_changed=2,shared_math_copies_added=0,
  unavoidable_model_parts=['Access to the real NextN logits port and each model original target verifier tap','Existing model-specific complete resource schema plus one optional metadata cursor','Original accepted-prefix state repair/catchup and target-only continuation'],
  common_parts=['Static local-Value fragment adapter','Shared cold distribution/acceptance/residual/bonus Graph mathematics','Shared overflow-checked SamplingCursor'],
  next_architecture_work='Use these real boundaries to simplify model continuation/acceptance publication later; this functional patch does not introduce a universal model executor, a second state/cache manager, provider whitelist, dynamic dispatch or compatibility path.'),
 limitations=[
  'Upstream previous-layer activations/residual, initial history and upstream shared-index selection remain explicit source-component fixtures. No complete trained target generation, task-quality, natural acceptance-rate, cross-provider bit equality or throughput/physical-memory claim.',
  'Pro natural trial rejected. Pro stochastic acceptance is not claimed by that run; its original accepted state repair/catchup was covered by prior greedy trained-role evidence, while the new shared stochastic acceptance/bonus path ran on Flash.',
  'No new stochastic run of GLM quantized derivatives. Their existing role/mathematics/state evidence is not silently upgraded by an official-source stochastic run.',
  'Flash executed source predates only a CPU test registration and the non-CUDA artifact-MoE compile guard. Its exact compiled source is archived separately; current CPU-only source syntax is recorded and the precise post-run delta is included.',
  'No legacy full greedy matrix was repeated; actual new source journeys exercise reused model producers, StateHead, typed pending and complete state boundaries.'],
 inherited_evidence=['docs/evidence/correctness/mtp-glm-original-target43-2026-10-23.json','docs/evidence/correctness/mtp-glm-original-target44-2026-10-23.json','docs/evidence/correctness/mtp-glm-pro-target-verifier-2026-10-23.json'],
 archive=identity(archive),archive_records=len(set(records)))
out.with_suffix('.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(out.with_suffix('.json'));print(identity(archive));print('records',len(set(records)))
