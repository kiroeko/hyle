"""Default offline check; explicit --apply permits only the reviewed 171-byte NF4 state.

Apply must run through the original budget.py run guard. This script never
changes PAUSED, budget files, proxy configuration, or retries a failed request.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import inspect
import json
import sys
import urllib.request

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BUDGET = ROOT / '.scratch/mtp-download-budget-20261023/budget.py'
TRANSPORT = ROOT / '.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py'
PLAN = HERE / 'nf4-missing-ranges.json'
SCRIPT = Path(__file__).resolve().relative_to(ROOT).as_posix()
PINS = {
    BUDGET: '24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17',
    TRANSPORT: '3dc89fb1efc369615d7a3132bd08b3aabcf125259498b5f8581cec83d559a7da',
    PLAN: 'a3675102c91665145830ca5405a0be607a40b45f63d12aac73d94b5a76ccb49b',
}
FIRST, LAST, AMOUNT = 15264695436, 15264695606, 171
REPOSITORY = 'unsloth/Qwen3.8-27B-unsloth-bnb-4bit'
REVISION = '8aa5f05d26b7205477066e1449e0af13f762a299'
URL = f'https://hf-mirror.net/{REPOSITORY}/resolve/{REVISION}/model.safetensors'
OUTPUT = HERE / 'nf4-quant-state'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def prepare():
    for path, expected in PINS.items():
        if digest(path.read_bytes()) != expected:
            raise ValueError('Reviewed local input/helper changed: ' + path.relative_to(ROOT).as_posix())
    spec = importlib.util.spec_from_file_location('nf4_retained_range_transport', TRANSPORT)
    transport = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transport)
    transport.SCRIPT = SCRIPT
    budget = transport.module()
    plan = transport.parse_json(PLAN.read_bytes())
    if (plan['repository'], plan['revision'], plan['url']) != (REPOSITORY, REVISION, URL):
        raise ValueError('Fixed NF4 identity differs')
    row = dict(repository=REPOSITORY, revision=REVISION, file='model.safetensors', uri=URL)
    base = ROOT / '.scratch/mtp-metadata-offline-20261024/cat13'
    source = transport.crosscheck_tree_identity(row, (base / 'expanded-api.json').read_bytes(),
                                              (base / 'tree-api.json').read_bytes())
    if source != plan['source']:
        raise ValueError('Independent cached API/tree original identity differs')
    if (source['size'] != 22344833801 or
        source['lfs_sha256'] != 'd5ced71fee428687bca87ed1b62a1518e936e8698b180fbba35431ebd31e1a25' or
        source['etag'] != '"88fa9db8893864a95b1499026c93b2784fa63c98e878688f05069524e2d42752"'):
        raise ValueError('Fixed source size/LFS/strong ETag differs')
    header_raw = (base / 'header.json').read_bytes()
    if len(header_raw) != 392344 or digest(header_raw) != plan['header']['sha256']:
        raise ValueError('Original header changed')
    header = transport.parse_json(header_raw)
    role = plan['first_request']
    entry = header[role['role']]
    if (entry['dtype'] != 'U8' or entry['shape'] != [AMOUNT] or
        8 + len(header_raw) + entry['data_offsets'][0] != FIRST or
        8 + len(header_raw) + entry['data_offsets'][1] - 1 != LAST or
        role['range_inclusive'] != [FIRST, LAST] or role['bytes'] != AMOUNT):
        raise ValueError('The only permitted 171-byte role range changed')
    budget.require_mirror_url(URL)
    # Leave the user's environment/system proxy route unchanged. A CONNECT
    # proxy does not change the HTTPS destination checked by the budget guard.
    # Do not inspect or log proxy URLs, which may contain credentials.
    return transport, budget, plan, row, source


def run(apply=False):
    transport, budget, plan, row, source = prepare()
    paused = (BUDGET.parent / 'PAUSED').exists()
    checkpoint = dict(mode='apply' if apply else 'dry-run', HTTP_requests=0,
        repository=REPOSITORY, revision=REVISION, uri=URL, range=[FIRST, LAST], expected_bytes=AMOUNT,
        expected_content_range=f'bytes {FIRST}-{LAST}/{source["size"]}', expected_status=206,
        expected_strong_etag=source['etag'], expected_content_encoding='identity',
        expected_range_sha256=None,
        hash_scope='No prior source-range digest exists. Record payload SHA256 after exact Range/ETag validation; do not claim full LFS verification.',
        cached_API_tree_LFS_size_Xet_crosscheck=True, original_budget_SHA256=PINS[BUDGET],
        paused=paused, proxy_policy='Existing proxy settings unchanged; actual HTTPS URL and every redirect destination remain hf-mirror.net.',
        required_entry='python .scratch/mtp-download-budget-20261023/budget.py run .scratch/inference-system-review-20261025/nf4-fetch-quant-state.py -- --apply',
        auto_enable=False, automatic_retries=0, following_component_ranges_permitted=False,
        PAUSED_and_ledger_modified_by_dry_run=False)
    if not apply:
        print(json.dumps(checkpoint, indent=2))
        return
    budget.require_enabled()
    guard = urllib.request.urlopen
    code = getattr(guard, '__code__', None)
    if code is None or Path(code.co_filename).resolve() != BUDGET.resolve():
        raise RuntimeError('Apply only through unchanged original budget.py run guard')
    if inspect.getclosurevars(guard).nonlocals.get('script') != SCRIPT:
        raise RuntimeError('Budget guard must account this exact script, not another acquisition')
    # Any prior attempt is a preserved witness, never an automatic retry.
    OUTPUT.mkdir(exist_ok=False)
    transport.save(OUTPUT / 'request-plan.json', dict(checkpoint, script_sha256=digest(Path(__file__).read_bytes()),
        local_input_pins={p.relative_to(ROOT).as_posix(): sha for p, sha in PINS.items()}, source=source))
    fetch = transport.Fetch(budget, row, timeout=45, receipt_dir=OUTPUT)
    try:
        # Exactly one existing Fetch.get: original reserve/host/redirect/Range/
        # length/ETag/error-receipt mechanism; no independent HTTP downloader.
        raw, response = fetch.get(FIRST, LAST, source=source)
        if len(raw) != AMOUNT:
            raise ValueError('Original quant_state byte count differs')
        (OUTPUT / 'quant-state.bin').write_bytes(raw)
        state = transport.parse_json(raw)
        if not isinstance(state, dict) or not state:
            raise ValueError('Original quant_state is not a nonempty JSON object')
        transport.save(OUTPUT / 'quant-state.json', state)
        transport.save(OUTPUT / 'complete.json', dict(state='downloaded_exact_original_quant_state_JSON',
            repository=REPOSITORY, revision=REVISION, source=source, role=plan['first_request'],
            bytes=len(raw), sha256=digest(raw), response=response, HTTP_requests=1,
            full_source_LFS_verified=False, whole_tensor_body_downloaded=False,
            remaining_component_bytes_downloaded=0, paused_marker_modified=False, automatic_retries=0))
        print(json.dumps(dict(state='complete', bytes=len(raw), sha256=digest(raw),
            parsed=state, receipt=(OUTPUT / 'complete.json').relative_to(ROOT).as_posix()), indent=2))
    except BaseException as error:
        transport.save(OUTPUT / 'failed.json', dict(state='failed_preserved_no_retry',
            error_type=type(error).__name__, error=str(error), maximum_requested_body_bytes=AMOUNT,
            remaining_component_bytes_downloaded=0))
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    run(args.apply)
