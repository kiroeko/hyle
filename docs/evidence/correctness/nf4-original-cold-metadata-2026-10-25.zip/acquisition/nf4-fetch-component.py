"""Offline by default; --apply fetches only the reviewed9012B NF4 component view.

Use original budget.py run. Never change PAUSED/proxies, retry, or fetch a whole
projection. The original171B state has already been acquired independently.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,inspect,json,sys,urllib.request
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SCRIPT=Path(__file__).resolve().relative_to(ROOT).as_posix()
FIRST_SCRIPT=HERE/'nf4-fetch-quant-state.py'
FIRST_SCRIPT_SHA='169147528ad28d713200fdfd2d91672d479e185acf06a43868c18c9e7117464f'
STATE_SHA='9210c25c0ca8632c7166cc3a92dc0cc43ffe528a45a11e3b8dde08941ed9d6c1'
RANGES=((15261992076,15261999755),(15264613516,15264613755),(2502816,2502819),(2504096,2505183))
NAMES=('weight.bin','absmax.bin','nested_absmax.bin','codebooks.bin')
OUTPUT=HERE/'nf4-component-values'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def prepare():
    if sha(FIRST_SCRIPT.read_bytes())!=FIRST_SCRIPT_SHA:raise ValueError('Reviewed first-stage helper changed')
    spec=importlib.util.spec_from_file_location('reviewed_nf4_state_acquisition',FIRST_SCRIPT)
    first=importlib.util.module_from_spec(spec);spec.loader.exec_module(first);first.SCRIPT=SCRIPT
    transport,budget,plan,row,source=first.prepare()
    state_dir=HERE/'nf4-quant-state';raw=(state_dir/'quant-state.bin').read_bytes()
    receipt=transport.parse_json((state_dir/'complete.json').read_bytes())
    state=transport.parse_json(raw)
    expected=dict(quant_type='nf4',blocksize=64,dtype='float16',shape=[1024,5120],nested_blocksize=256,
                  nested_dtype='float32',nested_offset=.04292804002761841)
    if (len(raw)!=171 or sha(raw)!=STATE_SHA or state!=expected or receipt['sha256']!=STATE_SHA or
        receipt['bytes']!=171 or receipt['source']!=source or receipt['repository']!=first.REPOSITORY or
        receipt['revision']!=first.REVISION or receipt['role']!=plan['first_request'] or
        receipt['response']['status']!=206 or receipt['response']['etag']!=source['etag'] or
        receipt['response']['content_range']!=f'bytes {first.FIRST}-{first.LAST}/{source["size"]}' or
        receipt['response']['final_url']!=first.URL):
        raise ValueError('The required independent original171B state/receipt differs')
    component=plan['conditional_N3_fullK_component']; requests=component['coalesced_requests']
    if (component['shape']!=[3,5120] or component['additional_bytes']!=9012 or len(requests)!=4 or
        tuple(tuple(p['range_inclusive'])for p in requests)!=RANGES or
        sum(p['bytes']for p in requests)!=9012):raise ValueError('Reviewed exact component bounds differ')
    header=transport.parse_json((ROOT/'.scratch/mtp-metadata-offline-20261024/cat13/header.json').read_bytes())
    for part in component['roles']:
        entry=header[part['role']];begin,end=entry['data_offsets'];offset=392352+begin
        if (entry['dtype']!=part['original_dtype'] or entry['shape']!=part['original_shape'] or
            end-begin!=part['original_role_bytes'] or part['role_relative_offset']!=0 or
            part['source_offset']!=offset or part['range_inclusive']!=[offset,offset+part['bytes']-1] or
            not 0<part['bytes']<=end-begin):raise ValueError('Component is outside its original physical role')
    for part,(begin,end)in zip(requests,RANGES):
        if part['source_offset']!=begin or part['bytes']!=end-begin+1:raise ValueError('Coalesced Range differs')
    books=component['roles'][-2:]
    if (books[0]['source_offset'],books[0]['bytes'],books[1]['source_offset'],books[1]['bytes'])!=(2504096,1024,2505120,64):
        raise ValueError('Both complete original codebooks must remain adjacent')
    return first,transport,budget,plan,row,source,requests

def run(apply=False):
    first,transport,budget,plan,row,source,requests=prepare()
    checkpoint=dict(mode='apply'if apply else'dry-run',HTTP_requests=0,maximum_HTTP_requests=4,maximum_payload_bytes=9012,
        original_quant_state_bytes_reused=171,quant_state_sha256=STATE_SHA,original_shape=[1024,5120],component_view_shape=[3,5120],
        range_inclusive=[list(r)for r in RANGES],source=source,repository=first.REPOSITORY,revision=first.REVISION,uri=first.URL,
        required_status=206,strong_etag_required=True,identity_content_encoding=True,exact_Content_Range_required=True,
        range_sha256_scope='No prior component digests: record each payload SHA only after fixed original Range/ETag validation; not full LFS.',
        paused=(first.BUDGET.parent/'PAUSED').exists(),PAUSED_and_ledger_modified_by_dry_run=False,auto_enable=False,automatic_retries=0,
        whole_projection_download=False,full_model_binding=False,proxy_policy='Existing route unchanged; actual HTTPS destination and every redirect stay hf-mirror.net.',
        required_entry='python .scratch/mtp-download-budget-20261023/budget.py run '+SCRIPT+' -- --apply')
    if not apply:print(json.dumps(checkpoint,indent=2));return
    budget.require_enabled()
    code=getattr(urllib.request.urlopen,'__code__',None)
    if (code is None or Path(code.co_filename).resolve()!=first.BUDGET.resolve()or
        inspect.getclosurevars(urllib.request.urlopen).nonlocals.get('script')!=SCRIPT):
        raise RuntimeError('Apply only through the unchanged original budget.py run guard for this exact script')
    OUTPUT.mkdir(exist_ok=False)
    transport.save(OUTPUT/'request-plan.json',dict(checkpoint,script_sha256=sha(Path(__file__).read_bytes()),
        first_stage_helper_sha256=FIRST_SCRIPT_SHA,original_budget_sha256=first.PINS[first.BUDGET],
        original_transport_sha256=first.PINS[first.TRANSPORT],original_range_plan_sha256=first.PINS[first.PLAN]))
    fetch=transport.Fetch(budget,row,timeout=45,receipt_dir=OUTPUT);completed=[]
    try:
        for request,filename,(begin,end)in zip(requests,NAMES,RANGES):
            payload,response=fetch.get(begin,end,source=source)
            if len(payload)!=request['bytes']:raise ValueError('Exact component response length differs')
            (OUTPUT/filename).write_bytes(payload)
            item=dict(path=filename,bytes=len(payload),sha256=sha(payload),original_range=request,response=response)
            completed.append(item);transport.save(OUTPUT/'verified-parts.json',dict(complete=False,parts=completed))
        transport.save(OUTPUT/'complete.json',dict(state='complete_original_N3_component_view_not_whole_role',repository=first.REPOSITORY,
            revision=first.REVISION,source=source,original_logical_shape=[1024,5120],component_view_shape=[3,5120],
            total_new_payload_bytes=9012,HTTP_requests=4,quant_state_reused_sha256=STATE_SHA,parts=completed,
            original_physical_roles=plan['conditional_N3_fullK_component']['roles'],full_source_LFS_verified=False,
            canonical_full_role_files_manifest=False,automatic_retries=0,paused_marker_modified=False))
        print(json.dumps(dict(state='complete',bytes=9012,receipt=str((OUTPUT/'complete.json').relative_to(ROOT))),indent=2))
    except BaseException as error:
        transport.save(OUTPUT/'failed.json',dict(state='failed_preserved_no_retry',error_type=type(error).__name__,error=str(error),
            verified_parts=len(completed),verified_payload_bytes=sum(p['bytes']for p in completed),maximum_requested_payload_bytes=9012))
        raise
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apply',action='store_true');run(parser.parse_args().apply)
