from pathlib import Path
import hashlib,json,sys,subprocess
R=Path.cwd();sys.path.insert(0,str(R))
from engine.models.qwen35 import prepare
W=R/'.scratch/inference-system-review-20261025/nf4-metadata'
H=R/'.scratch/mtp-metadata-offline-20261024/cat13/header.json'
C=R/'.scratch/model-quantization-discovery-2026-10-19/qwen-kimi/unsloth--Qwen3.8-27B-unsloth-bnb-4bit/config.json'
header=json.loads(H.read_bytes()); config=json.loads(C.read_bytes())
g=prepare.geometry.from_hf(config)
roles={n:r for n,r in header.items() if n.startswith(('model.language_model.','mtp.','lm_head.'))}
groups=prepare.nf4_state.groups(roles,config,prepare.geometry.role_shapes(g))
prepare.validate_role_geometry(roles,g,(),groups)
assert len(roles)==2611 and len(groups)==352
known='model.language_model.layers.3.self_attn.k_proj.weight'
result=dict(state='original_header_schema_checked_only',physical_roles=len(roles),logical_roles=len(prepare.logical_roles(roles)),nf4_six_role_groups=len(groups),
    original_F16_unquantized_roles=len(roles)-6*len(groups),selected_original_bytes=sum(r['data_offsets'][1]-r['data_offsets'][0]for r in roles.values()),
    each_group_quant_state_raw_bytes_required=True,known_actual_state=known,known_actual_states=1,unread_group_states=351,
    all_group_raw_state_validation=False,canonical_prepare_complete=False,full_model_execution_supported=False,HTTP_requests=0,
    source_pins={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in (H,C)})
(W/'actual-schema.json').write_text(json.dumps(result,indent=2)+'\n')
paths=['engine/models/qwen35/prepare.py','engine/models/qwen35/prepared_roles.h','engine/models/qwen35/nf4_state.py','engine/models/qwen35/nf4_state.h','tests/tooling/qwen_hf_roles_test.py','tests/tools/qwen_prepared_roles_test.cc','tests/tooling/fixtures/qwen_nf4_quant_state.json']
after=W/'after';after.mkdir(exist_ok=True)
for n in paths:
 p=R/n; target=after/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
patch=subprocess.check_output(['git','diff','--',*paths]);(W/'changes.patch').write_bytes(patch)
print(json.dumps(result,indent=2))
