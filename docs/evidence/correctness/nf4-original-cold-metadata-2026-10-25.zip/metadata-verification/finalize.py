from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess,sys
R=Path.cwd();W=R/'.scratch/inference-system-review-20261025/nf4-metadata'
(W/'host2/source-pins.json').write_bytes((W/'source-pins.json').read_bytes())
checks= W/'python-final'; checks.mkdir(exist_ok=False)
command=[sys.executable,str(R/'tests/tooling/qwen_hf_roles_test.py')]
p=subprocess.run(command,cwd=R,capture_output=True)
(checks/'command.json').write_text(json.dumps(dict(command=command,cwd=str(R)),indent=2)+'\n')
(checks/'stdout.log').write_bytes(p.stdout);(checks/'stderr.log').write_bytes(p.stderr)
(checks/'result.json').write_text(json.dumps(dict(exit_code=p.returncode),indent=2)+'\n');assert p.returncode==0
sys.path.insert(0,str(R));sys.path.insert(0,str(R/'engine/models/qwen35'))
from engine.models.qwen35 import prepare
spec=importlib.util.spec_from_file_location('before_nf4_prepare',W/'before/prepare.py');before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
spec=importlib.util.spec_from_file_location('existing_roles_tests',R/'tests/tooling/qwen_hf_roles_test.py');fixtures=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixtures)
original=fixtures.source_fixture();config=fixtures.source_config();ct=prepare.ct_symmetric_groups({r['name']:r for r in original['roles']})
def auth(r):return Path('retained-original.bin'),struct.pack('<qq',*ct[r['name'][:-13]]['logical_shape'])if r['name'].endswith('.weight_shape')else None
comparison=[]
for mode in ('ct','dense'):
 if mode=='dense':
  original=dict(complete=True,repository='test/dense',revision='a'*40,roles=[])
  for n,shape in prepare.geometry.role_shapes(prepare.geometry.from_hf(config)).items():
   count=2
   for v in shape:count*=v
   original['roles'].append(dict(name=n,dtype='BF16',shape=list(shape),path='x',offset=0,bytes=count,sha256='1'*64))
 for mtp in (False,True):
  old=before._prepare_role_records(original,mtp,config,auth);new=prepare._prepare_role_records(original,mtp,config,auth)
  assert old==new;comparison.append(dict(source=mode,mtp=mtp,lines_and_receipt_byte_equivalent=True))
(W/'non-nf4-compatibility.json').write_text(json.dumps(comparison,indent=2)+'\n')
paths=['engine/models/qwen35/prepare.py','engine/models/qwen35/prepared_roles.h','engine/models/qwen35/nf4_state.py','engine/models/qwen35/nf4_state.h','tests/tooling/qwen_hf_roles_test.py','tests/tools/qwen_prepared_roles_test.cc','tests/tooling/fixtures/qwen_nf4_quant_state.json']
pins={n:dict(bytes=(R/n).stat().st_size,sha256=hashlib.sha256((R/n).read_bytes()).hexdigest())for n in paths}
(W/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for n in paths:
 target=W/'after'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/n).read_bytes())
(W/'changes.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths]))
summary=dict(state='PASS',cpp_checks=342,cpp_compile='host2/compile',cpp_run='host2/run',python_tests=14,python_final='python-final',
 cpp_header_pins_match_final=all(pins[n]==json.loads((W/'host2/source-pins.json').read_text())[n]for n in ('engine/models/qwen35/prepared_roles.h','engine/models/qwen35/nf4_state.h')),
 non_nf4_equivalent_cases=comparison,actual_header_schema='actual-schema.json',actual_original_states_read=1,unread_original_states=351,
 complete_artifact_prepared=False,full_model_execution_supported=False,scope='Host cold metadata only; no model/SDK/GPU/HTTP',source_pins='source-pins.json',
 first_helper_failure='Initial private check2.py generation used incorrect PowerShell/Python escaping; no compile or product execution; corrected private script then host2 passed',
 cleanup_candidates=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in W.glob('host*/*')if p.is_file()and p.suffix.lower()in ('.exe','.obj','.pdb','.exp','.lib')])
(W/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
