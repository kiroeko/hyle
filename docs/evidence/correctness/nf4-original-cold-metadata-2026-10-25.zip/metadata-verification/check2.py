from pathlib import Path
import hashlib,importlib.util,json,sys
R=Path.cwd(); W=R/'.scratch/inference-system-review-20261025/nf4-metadata'; F=W/'host2'; F.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('retained_cpu_build',R/'.scratch/engine-product-20261024/cpu-build.py'); b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
recipe=b.read(R/'.scratch/mtp-q27-fp8-20261024/cat08-metadata1/compile/command.json')['command']
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
paths=['engine/models/qwen35/prepare.py','engine/models/qwen35/prepared_roles.h','engine/models/qwen35/nf4_state.py','engine/models/qwen35/nf4_state.h','tests/tooling/qwen_hf_roles_test.py','tests/tools/qwen_prepared_roles_test.cc','tests/tooling/fixtures/qwen_nf4_quant_state.json']
def pins():return {p:dict(bytes=(R/p).stat().st_size,sha256=hashlib.sha256((R/p).read_bytes()).hexdigest()) for p in paths}
original=pins();(W/'source-pins.json').write_text(json.dumps(original,indent=2)+'\n')
cmd=[a for a in recipe if not a.startswith(('/Fe:','/Fo:','/Fd:'))]
cmd[cmd.index('/link'):cmd.index('/link')]=['/Fe:'+str(F/'checks.exe'),'/Fo:'+str(F/'checks.obj'),'/Fd:'+str(F/'checks.pdb')]
b.execute(cmd,env,F/'compile',120)
b.execute([str(F/'checks.exe'),str(F/'fixtures')],env,F/'run',30)
b.execute([sys.executable,str(R/'tests/tooling/qwen_hf_roles_test.py')],env,F/'python',30)
assert pins()==original
(W/'summary.json').write_text(json.dumps(dict(state='PASS',cpp=(F/'run/stdout.log').read_text(),python=(F/'python/stderr.log').read_text(),scope='host cold metadata only; no model/SDK/GPU/HTTP',source_pins='source-pins.json'),indent=2)+'\n')
print((F/'run/stdout.log').read_text())

