from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import discover_environment


def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
def pin(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def execute(args, env, folder, timeout=120):
    folder.mkdir(parents=True, exist_ok=False)
    save(folder/'command.json', dict(command=args, cwd=str(ROOT), timeout_seconds=timeout))
    start = time.monotonic()
    with (folder/'stdout.log').open('wb') as out, (folder/'stderr.log').open('wb') as err:
        proc = subprocess.Popen(args, cwd=ROOT, env=env, stdout=out, stderr=err,
            creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder/'running.json', dict(pid=proc.pid))
        print('START', folder.name, proc.pid, flush=True)
        try: code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired: proc.kill(); proc.wait(); code = -999
    result = dict(exit=code, seconds=round(time.monotonic()-start, 3), pid=proc.pid)
    save(folder/'process.json', result)
    print('END', folder.name, json.dumps(result), flush=True)
    if code:
        print((folder/'stdout.log').read_text(errors='replace')[-12000:], flush=True)
        print((folder/'stderr.log').read_text(errors='replace')[-4000:], flush=True)
    return result
def project(path):
    try: rel = path.resolve().relative_to(ROOT)
    except ValueError: return False
    return bool(rel.parts) and rel.parts[0] in {'src', 'include', 'engine', 'tests'}
def include_path(arg):
    for prefix in ('/external:i', '/i'):
        if arg.lower().startswith(prefix): return arg[:len(prefix)], Path(arg[len(prefix):])
    return None


def main():
    attempt = WORK / (sys.argv[1] if len(sys.argv) > 1 else 'check1')
    assert not attempt.exists(), 'Preserve original raw: use a fresh attempt name'
    pins = read(WORK/'source-pins.json')
    integrated = read(WORK/'root-integrated.json')
    # Fixture-only follow-ups remain private until ROOT reviews their hashes.
    original_test = ('837e6ffe98e3d7ade516a7a530f5e6d4c30165be6e3acace52d7214ee24f79b4'
        if len(sys.argv) > 2 else next(item['after'] for item in pins['files'] if item['path'].startswith('tests/')))
    for item in pins['files']:
        expected = original_test if item['path'].startswith('tests/') else item['after']
        assert pin(ROOT/item['path'])['sha256'] == expected, item['path']
    baseline = ROOT/'.scratch/inference-layout-storage-validation-20261025/cpu1'
    old_native_tree = ROOT/'.scratch/inference-layout-storage-native-20261025/host1/source'
    jobs = [
        ('cpu-append', 'src/graph_batch/paged_append.cc', baseline/'compile/graph_batch--paged_append/command.json'),
        ('cpu-test', 'tests/graph_batch/typed_capability_graph_test.cc', baseline/'compile/graph_batch--typed_capability_graph_test/command.json'),
        ('vk-append', 'src/graph_route_vulkan/native_paged_append.cc',
            ROOT/'.scratch/inference-layout-storage-native-20261025/host1/vk-paged/command.json')]
    recipes = {tag: read(recipe)['command'] for tag, _, recipe in jobs}
    def canonical_directory(path):
        try: return ROOT/path.resolve().relative_to(old_native_tree)
        except ValueError: return path
    def frozen_directory(path):
        path = canonical_directory(path)
        if path.resolve() == ROOT.resolve(): return tree
        if project(path): return tree/path.resolve().relative_to(ROOT)
        return path
    search = [ROOT/'include', ROOT, ROOT/'src/compute', ROOT/'src/compute_backend_cuda']
    for args in recipes.values():
        for arg in args:
            parsed = include_path(arg)
            if parsed: search.append(canonical_directory(parsed[1]))
    tree = attempt/'source'
    pending = [name for _, name, _ in jobs]
    seen = set(); frozen = []
    while pending:
        name = pending.pop()
        if name in seen: continue
        seen.add(name)
        original = ROOT/name
        supplied = WORK/'source'/name if name == 'tests/graph_batch/typed_capability_graph_test.cc' else original
        data = supplied.read_bytes(); target = tree/name
        target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
        frozen.append(dict(relative=name, original=pin(original), supplied=pin(supplied), frozen=pin(target)))
        for inc in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]', data.decode('utf-8-sig'), re.M):
            for directory in [original.parent, *search]:
                candidate = (directory/inc).resolve()
                if candidate.is_file():
                    if project(candidate): pending.append(candidate.relative_to(ROOT).as_posix())
                    break
    assert 'include/hyle/compute/model_ops.h' in seen
    save(attempt/'frozen-project.json', frozen)
    save(attempt/'source-pins.json', pins)
    compiler = recipes['cpu-append'][0]
    env = discover_environment(compiler='msvc', cache=dict(CMAKE_C_COMPILER=compiler,
        CMAKE_CXX_COMPILER=compiler, CMAKE_GENERATOR='Ninja'), backends=()).env
    def compile_one(job):
        tag, name, recipe = job
        flags = []; skip = False
        for arg in recipes[tag][1:]:
            if skip: skip = False; continue
            if arg == '/sourceDependencies': skip = True; continue
            if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')): continue
            parsed = include_path(arg)
            flags.append(parsed[0] + str(frozen_directory(parsed[1])) if parsed else arg)
        flags = ['/I'+str(tree/'include'), '/I'+str(tree), '/I'+str(tree/'src/compute'),
            '/I'+str(tree/Path(name).parent), *flags]
        assert '/W4' in flags and '/WX' in flags
        folder = attempt/'compile'/tag
        args = [compiler, *flags, str(tree/name), '/sourceDependencies', str(folder/'dependencies.json'),
            '/Fo'+str(folder/'unit.obj'), '/Fd'+str(folder/'unit.pdb')]
        result = execute(args, env, folder)
        if result['exit']: return dict(tag=tag, source=name, result=result)
        data = read(folder/'dependencies.json')['Data']
        deps = [Path(x) for x in dict.fromkeys([data['Source'], *data['Includes']])]
        assert not any(project(path) for path in deps), 'Unfrozen canonical project header consumed'
        save(folder/'actual-dependencies.json', [pin(path) for path in deps])
        return dict(tag=tag, source=name, result=result, object=pin(folder/'unit.obj'),
            dependencies=len(deps), recipe=pin(recipe))
    reused = []
    compile_jobs = jobs
    if len(sys.argv) > 2:
        previous = WORK/sys.argv[2]
        previous_pins = read(previous/'source-pins.json')
        assert [x for x in previous_pins['files'] if not x['path'].startswith('tests/')] == [
            x for x in pins['files'] if not x['path'].startswith('tests/')]
        reused = [item for item in read(previous/'compiled.json')
            if item['tag'] != 'cpu-test' and item['result']['exit'] == 0]
        assert {item['tag'] for item in reused} == {'cpu-append', 'vk-append'}
        for item in reused: assert pin(Path(item['object']['path'])) == item['object']
        compile_jobs = [job for job in jobs if job[0] == 'cpu-test']
    print('FROZEN', len(frozen), 'files', sum(x['frozen']['bytes'] for x in frozen), 'bytes;',
        len(compile_jobs), 'strict TUs/max2workers;', len(reused), 'prior PASS objects reused', flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        compiled = reused + list(pool.map(compile_one, compile_jobs))
    save(attempt/'compiled.json', compiled)
    if any(x['result']['exit'] for x in compiled):
        save(attempt/'summary.json', dict(status='COMPILE_FAILED_NO_EXECUTION', compiled=compiled)); return 1
    bytag = {x['tag']: x for x in compiled}
    baseargs = read(baseline/'test-link/command.json')['command']
    replacements = {
        str(baseline/'compile/graph_batch--paged_append/unit.obj'): bytag['cpu-append']['object']['path'],
        str(baseline/'compile/graph_batch--typed_capability_graph_test/unit.obj'): bytag['cpu-test']['object']['path']}
    assert all(baseargs.count(path) == 1 for path in replacements)
    args = [replacements.get(arg, arg) for arg in baseargs
        if not arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
    dependencies = [pin(Path(arg)) for arg in args[1:] if Path(arg).is_absolute() and Path(arg).suffix.lower() in {'.obj', '.lib'}]
    system = [arg for arg in args[1:] if not Path(arg).is_absolute() and arg.lower().endswith('.lib')]
    save(attempt/'link-inputs.json', dict(replacements=replacements, absolute_files=dependencies,
        absolute_count=len(dependencies), system_arguments=system, system_count=len(system)))
    image = attempt/'link/component.exe'
    linked = execute([*args, '/OUT:'+str(image), '/PDB:'+str(image.with_suffix('.pdb'))], env, image.parent)
    if linked['exit']:
        save(attempt/'summary.json', dict(status='LINK_FAILED_NO_EXECUTION', compiled=compiled, link=linked)); return 1
    native = ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
    assert pin(native)['sha256'] == '1066e80261cc58d1c0ea57e50475e2e38b7675b666eb2b639969e01e85916a46'
    os.link(native, image.parent/native.name)
    runtime = read(ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')
    runenv = dict(env); runenv['PATH'] = str(image.parent)+';'+runtime['PATH']
    runenv['HF_HUB_OFFLINE'] = runenv['TRANSFORMERS_OFFLINE'] = '1'
    ran = execute([str(image), '--gtest_filter=TypedCapabilityGraph.*',
        '--gtest_output=xml:'+str(attempt/'test-result.xml')], runenv, attempt/'run')
    for item in pins['files']:
        expected = original_test if item['path'].startswith('tests/') else item['after']
        assert pin(ROOT/item['path'])['sha256'] == expected, item['path']
    summary = dict(status='PASS' if ran['exit'] == 0 else 'CPU_TEST_FAILED', compiled=compiled, link=linked,
        run=ran, source_pins=pins, native=pin(native), replaced_cpu_objects=2, cpu_processes=1,
        requested_cases=6, CUDA=False, Vulkan_runtime=False, Apple=False, SDK_rebuilt=False, HTTP=0)
    save(attempt/'summary.json', summary)
    print(json.dumps(summary, indent=2), flush=True)
    return int(ran['exit'] != 0)


if __name__ == '__main__': sys.exit(main())
