"""Archive the completed finite CPU check; never compiles or runs inference."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
CHECK=ROOT/'.scratch/inference-kimi-ct-int4-binding-check-20261025'
SPLIT=ROOT/'.scratch/inference-readonly-role-split-20261025'
DEST=ROOT/'docs/evidence/correctness'
STEM='kimi-ct-int4-selected-source-2026-10-25'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def pin(path):
    return {'path':path.relative_to(ROOT).as_posix(),**digest(path.read_bytes())}

cpu1=read(CHECK/'cpu1/summary.json')
cpu2=read(CHECK/'cpu2/summary.json')
assert cpu1['status']=='COMPILE_FAILED_NO_RUN' and cpu1['compile']['exit']==2
first=(CHECK/'cpu1/compile/stdout.log').read_bytes()
assert b'C1083' in first and b'ggml.h' in first
assert cpu2['status']=='PASS' and cpu2['xml']=={'tests':1,'failures':0,'errors':0,'skipped':0}
for stage in ('compile','link','run'):
    assert cpu2[stage]['exit']==0
compile_command=read(CHECK/'cpu2/compile/command.json')['command']
assert '/W4' in compile_command and '/WX' in compile_command
xml=ET.parse(CHECK/'cpu2/tests.xml').getroot()
case=xml.find('testsuite/testcase')
assert case.attrib['name']=='KimiInt4IndependentSourceRolesKeepSelectedBanksAndBfloatStore'
properties={p.attrib['name']:p.attrib['value'] for p in case.findall('properties/property')}
assert properties['source_generations']=='2' and properties['selected_experts_per_generation']=='2'
assert properties['bf16_weight_store_final_output_witnesses_query0']=='4096'
assert properties['bf16_weight_store_final_output_witnesses_query1']=='8192'
assert 'generated fixture only' in properties['source_value_scope']

final_pins=read(SPLIT/'source-pins.json')['files']
frozen={item['relative']:item for item in read(CHECK/'cpu2/frozen-project.json')}
for item in final_pins:
    assert digest((ROOT/item['path']).read_bytes())==item['after'],item['path']
    if item['path'] in frozen:
        assert item['after']=={k:v for k,v in frozen[item['path']]['canonical'].items() if k in ('bytes','sha256')}
        assert digest(Path(frozen[item['path']]['frozen']['path']).read_bytes())==item['after']
assert 'tests/compute_models/original_readonly_role.h' in frozen
assert 'tests/compute_models/kimi_ct_int4_source_roles.h' in frozen
assert 'tests/graph_route_cpu/ct_packed_grouped_test.cc' in frozen
review=read(WORK/'independent-review-performance.json')
assert review['status']=='SOURCE_ONLY_R2_NO_BLOCKER_FOUND'
assert review['lightweight_dependency_followup']['status']=='SOURCE_ONLY_MECHANICAL_SPLIT_NO_NEW_BLOCKER'

members={}
origins={}
def add(name,path):
    assert name not in members
    assert path.is_file(),path
    assert path.suffix.lower() not in {'.obj','.lib','.dll','.exe','.pdb','.bin','.safetensors','.gguf','.tar','.gz'}
    raw=path.read_bytes()
    assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})',raw),name
    members[name]=raw;origins[name]=path.relative_to(ROOT).as_posix()

for label,directory in [('r2',WORK),('readonly-split',SPLIT)]:
    for filename in ('source.patch','source-pins.json','prepare.py'):
        add('candidate/'+label+'/'+filename,directory/filename)
add('candidate/r2/binding-plan.json',WORK/'binding-plan.json')
add('candidate/r1-source-only/source.patch',WORK/'r1/source.patch')
add('candidate/r1-source-only/source-pins.json',WORK/'r1/source-pins.json')
add('candidate/readonly-split/source-checks.json',SPLIT/'source-checks.json')
add('review/independent-review-performance.json',WORK/'independent-review-performance.json')
for item in final_pins:
    add('final-source/'+item['path'],ROOT/item['path'])
add('commands/check_cpu.py',CHECK/'check_cpu.py')
add('commands/check_finite.py',ROOT/'.scratch/inference-e4-append-implementation-20261025/check_finite.py')
add('commands/archive-proof.py',Path(__file__).resolve())
for attempt in ('cpu1','cpu2'):
    for path in sorted((CHECK/attempt).rglob('*')):
        if not path.is_file() or 'source' in path.relative_to(CHECK/attempt).parts:
            continue
        if path.suffix.lower() not in {'.json','.log','.xml'}:
            continue
        add('actual/'+attempt+'/'+path.relative_to(CHECK/attempt).as_posix(),path)

manifest={'status':'CRC_AND_MEMBER_SHA256_VERIFIED_AFTER_WRITE',
          'payloads':'No SDK, binary, model body, credentials or full frozen include copies.',
          'members':[{'member':name,'original_path':origins[name],**digest(raw)} for name,raw in sorted(members.items())]}
index=json.dumps(manifest,indent=2).encode()+b'\n'
archive=DEST/(STEM+'.zip')
assert not archive.exists(),'Do not silently overwrite an existing public archive'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,raw in sorted({**members,'member-sha256.json':index}.items()):
        info=zipfile.ZipInfo(name)
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o644<<16
        output.writestr(info,raw,compresslevel=9)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name,raw in members.items():
        assert digest(check.read(name))==digest(raw),name
    assert check.read('member-sha256.json')==index
    assert len(check.namelist())==len(members)+1
assert archive.stat().st_size<1024*1024

report={
    'status':'KIMI_CT_INT4_INDEPENDENT_SOURCE_ROLES_TWO_GENERATIONS_CPU_FIXTURE_PASS',
    'date':'2026-10-25',
    'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'problem':'The generic asymmetric expert witness did not connect the selected Kimi symmetric group128 source Q/I64 shape/BF16 SF roles to its actual selected-bank ownership and BF16 operand/store boundary.',
    'change':'One finite caller-side source adapter validates cached header identities/ranges/types and the contents of supplied ready I64 shape leases, then feeds existing CpuSupply Q/SF/map batches. Existing closed CT grouped Graph consumes compressed banks; no new codec, math operator, owner, registry or executor.',
    'source':{
        'repository':properties['source_repository'],'revision':properties['source_revision'],
        'shard':'model-00001-of-00142.safetensors',
        'cached_header_roles':'Layer1 W1 expert0/1 and2/3; original header contains I32 Q[3072,448], I64 shape[2], BF16 SF[3072,28]. Independent exact data-relative spans are recorded in binding-plan.json.',
        'weight_shape_contract':'Cold admission reads the supplied16-byte I64 buffer and requires actual values [3072,3584]. The original shape[2] header alone does not establish those two original body values.',
        'value_qualification':'All Q/shape/SF body bytes used in this test are explicitly generated fixture values. Original publisher payload was not cached/downloaded or numerically qualified in this batch.'},
    'sources':final_pins,
    'lightweight_dependency_split':{
        'reason':'First CPU compile could not find ggml.h through original_named_role_source.h; no link or test ran.',
        'change':'Identity/ReadonlyRole/detail::take/detail::bind moved byte-for-byte to original_readonly_role.h in the same namespace; native GGUF manifest/Data definitions stay in the original header. Kimi includes only the lightweight role header; the test explicitly includes its existing SHA helper.',
        'source_only_native_suffix':read(SPLIT/'source-checks.json')['native_manifest_and_Data_suffix'],
        'scope':'Light header/Kimi/test are frozen and compiled in CPU2. The retained original GGUF manifest/Data suffix is mechanically unchanged; no separate original GGUF consumer run is signed.'},
    'geometry':{'source_projection':'W1 N3072/K3584/group128, noZ/noA quantizer, BF16 SF',
                'global_domain':896,'selected_capacity':2,'generation0':[0,1],'generation1':[2,3],
                'tokens':2,'slots_per_token':2,
                'precision':'BF16 activation widened explicitly toF32; source code*SF rounds BF16, BF16 weight operand, F32 accumulation then BF16 projection store.',
                'source_bank_logical_bytes_per_generation':11357696,
                'two_generation_pool_capacity_bytes':22715392,
                'memory_limit':'Known CpuSupply fixture capacity, not measured RAM/VRAM peak or a complete Model memory bound.'},
    'actual_CPU':{**cpu2,'gtest_case_seconds':float(case.attrib['time']),
                  'successful_Graph_submissions':2,
                  'numeric_witnesses':{'query0_final_BF16_diff_without_weight_store':4096,
                                       'query1_final_BF16_diff_without_weight_store':8192},
                  'same_generation':'Original Q/SF plane bytes are SHA-compared after copy. Each Invocation binds one complete Q/SF/map generation before prepare/submit. Source leases/mappings close before Graph execution; Invocation input readers retain actual bank lifetime.',
                  'ownership_checks':'Two generations occupy six bank blocks; third upload is rejected. Dropping CpuBatch alone leaves six original Invocation-held blocks; destroying both retired Invocations releases them. Independent BF16 result leases remain byte-identical after bank/compiled owners retire.',
                  'cold_rejections':'Wrong source range, actual shape values and SF dtype reject without consuming caller roles. These are cold input checks, not native device-fault tests.',
                  'filter':'CpuCtPackedGrouped.KimiInt4IndependentSourceRolesKeepSelectedBanksAndBfloatStore'},
    'first_attempt':{**cpu1,'reason':'MSVC C1083 missing ggml.h through the original heavy role header; no link/run, not a numerical or Graph failure. Original command/stdout/stderr/frozen pins preserved.'},
    'review_correction':'The first source-only one-hot oracle could not distinguish an intermediate BF16 weight store from final output rounding. Before any CPU run, r2 changed both queries to two terms and independently compared final BF16 against omission of the intermediate store. Actual XML records4096 and8192 distinguishing outputs; r1 and r2 patches/pins remain in archive.',
    'independent_review':{'status':review['status'],'path':'review/independent-review-performance.json',
                          'pin':digest((WORK/'independent-review-performance.json').read_bytes()),
                          'lightweight_followup':review['lightweight_dependency_followup']['status']},
    'not_claimed':['Original publisher Q/shape/SF numeric values or full artifact/model qualification.',
                   'W2/W3, full expert FFN/SiTU/combine, natural Top16 router or all selected experts.',
                   'New GPU/Linux/Apple/Vulkan execution, CUDA WeightSlots composition, native faults or cross-platform qualification.',
                   'TPS, speedup, complete prefill/decode/window update, measured peak memory or task quality.'],
    'archive':{**pin(archive),'members':len(members)+1,'CRC_and_member_SHA256_verified':True,
               'index':'member-sha256.json','no_model_SDK_or_binary_payloads':True}}
output=DEST/(STEM+'.json')
assert not output.exists(),'Do not silently overwrite an existing public report'
output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'report':pin(output),'archive':pin(archive),'members':len(members)+1,
                  'actual_tests':cpu2['xml'],'witnesses':report['actual_CPU']['numeric_witnesses']},indent=2))
