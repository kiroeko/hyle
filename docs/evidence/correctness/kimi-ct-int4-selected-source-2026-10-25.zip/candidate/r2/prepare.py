"""Prepare private source only. This script never downloads, compiles or executes C++."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
CACHE = ROOT / '.scratch/architecture-refactor-2026-10-18/fixed-role-binding-2026-10-21/kimi/22'
HEADER = CACHE / 'headers/model-00001-of-00142.safetensors/header.json'
metadata = json.loads(HEADER.read_text())
config = json.loads((CACHE / 'config.json').read_text())
quant = config['quantization_config']['config_groups']['group_0']
assert quant['weights']['symmetric'] and quant['weights']['group_size'] == 128
assert quant['weights']['num_bits'] == 4 and quant['input_activations'] is None

def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

source_rows = []
specs = []
for expert in range(4):
    roles = []
    for suffix, dtype, rank, shape in [('weight_packed', 'I32', 2, [3072, 448]),
                                     ('weight_shape', 'I64', 1, [2]),
                                     ('weight_scale', 'BF16', 2, [3072, 28])]:
        name = f'language_model.model.layers.1.block_sparse_moe.experts.{expert}.w1.{suffix}'
        item = metadata[name]
        assert item['dtype'] == dtype and item['shape'] == shape
        type_name = {'I32': 'kInt32', 'I64': 'kInt64', 'BF16': 'kBFloat16'}[dtype]
        dims = shape + [0] * (2 - len(shape))
        first, last = item['data_offsets']
        roles.append(f'{{"{name}",Type::{type_name},{{{dims[0]},{dims[1]}}},{rank},{first}ULL,{last}ULL}}')
        source_rows.append({'expert': expert, 'name': name, **item,
                            'file_offsets': [8 + 615872 + first, 8 + 615872 + last],
                            'payload_status': 'NOT_CACHED_OR_VERIFIED'})
    specs.append('    {' + str(expert) + ', {{' + ',\n      '.join(roles) + '}}}')

header = r'''#pragma once

#include "model_plane_resident_weights.h"
#include "original_named_role_source.h"

// Finite source-role adapter for the four cached layer1/W1 header entries.
// It authenticates no body: the caller supplies already-ready exact ranges and
// the original scalar shape payload. No model loader, codec or owner is added.
namespace kimi_ct_int4_source_roles {
namespace c=hyle::compute;namespace m=hyle::mem;
namespace named=original_named_role_source;
using Type=c::DataType;
using named::detail::take;
inline constexpr std::string_view repository="RedHatAI/Kimi-K3-INT4";
inline constexpr std::string_view revision="d5048a3ba6d23dd68749ea4b84abcb66d59a07e3";
inline constexpr std::string_view shard="model-00001-of-00142.safetensors";
inline constexpr named::Identity identity{repository,revision,"symmetric-group128-BF16-W4A16",shard};
inline constexpr std::int64_t n=3072,k=3584,group=128,domain=896,capacity=2;
struct RoleSpec final {
  std::string_view name;Type type;std::array<std::int64_t,2> shape;
  std::size_t rank;std::uint64_t data_begin,data_end;
  c::TensorDesc description()const {
    return take(c::TensorDesc::dense(type,{shape.data(),rank}),"Kimi CT exact source role");
  }
};
struct ExpertSpec final {std::int32_t global;std::array<RoleSpec,3> roles;};
inline constexpr std::array<ExpertSpec,4> specs{{
__SPECS__
}};
struct ExternalRole final {
  named::ReadonlyRole ready;
  // Safetensors data-relative range; the fixed header base is615880.
  std::uint64_t data_begin=0,data_end=0;
};
struct ExternalExpert final {std::int32_t global=-1;std::array<ExternalRole,3> roles;};

class Source final {
 public:
  Source()=default;Source(Source&&)=default;Source&operator=(Source&&)=delete;
  Source(const Source&)=delete;Source&operator=(const Source&)=delete;
  // Validate every supplied role/shape before retaining any caller input.
  // The I64[2] header alone is not evidence for its two integer body values.
  static hyle::Result<Source> accept(const std::array<ExternalExpert,2> &external) {
    for(std::size_t index=0;index<external.size();++index) {
      const auto &expert=external[index];
      if(expert.global<0||expert.global>=std::int32_t(specs.size())||
          (index&&external[index-1].global>=expert.global))
        return std::unexpected(hyle::Status::InvalidArgument("finite Kimi source experts must be sorted, distinct cached IDs"));
      const auto &expected=specs[std::size_t(expert.global)];
      for(std::size_t role=0;role<expert.roles.size();++role) {
        const auto &input=expert.roles[role];const auto &spec=expected.roles[role];
        const auto *id=input.ready.identity;
        if(!id||id->repository!=repository||id->revision!=revision||id->file!=shard||id->variant!=identity.variant||
            input.ready.name!=spec.name||input.ready.description!=spec.description()||
            !input.ready.owner||!input.ready.lease.valid()||
            input.data_begin!=spec.data_begin||input.data_end!=spec.data_end||
            input.ready.lease.size()!=spec.data_end-spec.data_begin)
          return std::unexpected(hyle::Status::InvalidArgument("Kimi CT exact source identity/span/type differs"));
        HYLE_ASSIGN_OR_RETURN(auto tensor,input.ready.lease.tensor(input.ready.description));
        (void)tensor;
      }
      std::array<std::int64_t,2> logical{};
      HYLE_ASSIGN_OR_RETURN(auto shape,expert.roles[1].ready.lease.view());
      HYLE_RETURN_IF_ERROR(shape.read(std::as_writable_bytes(std::span(logical))));
      if(logical!=std::array<std::int64_t,2>{n,k})
        return std::unexpected(hyle::Status::InvalidArgument("Kimi CT weight_shape body differs from packed Q/SF geometry"));
    }
    Source result;result.original_=external;
    for(std::size_t index=0;index<external.size();++index)for(std::size_t plane=0;plane<2;++plane) {
      HYLE_ASSIGN_OR_RETURN(auto view,result.original_[index].roles[plane?2:0].ready.lease.view());
      HYLE_ASSIGN_OR_RETURN(result.mappings_[index][plane],view.map_host());
      HYLE_RETURN_IF_ERROR(result.mappings_[index][plane].invalidate());
    }
    return result;
  }
  hyle::Status close() {
    for(auto &expert:mappings_)for(auto &mapping:expert)if(mapping.valid())HYLE_RETURN_IF_ERROR(mapping.close());
    original_={};return hyle::Status::Ok();
  }
  std::span<const std::byte> plane_bytes(std::size_t plane,std::int32_t global)const {
    if(plane>=2)throw std::runtime_error("Kimi CT source plane is not Q or BF16 SF");
    for(std::size_t i=0;i<original_.size();++i)if(original_[i].global==global)return mappings_[i][plane].bytes();
    throw std::runtime_error("Kimi CT selected expert was not supplied");
  }
  m::ConstBufferView plane_view(std::size_t plane,std::int32_t global)const {
    if(plane>=2)throw std::runtime_error("Kimi CT source plane is not Q or BF16 SF");
    for(const auto &expert:original_)if(expert.global==global)
      return take(expert.roles[plane?2:0].ready.lease.view(),"Kimi CT retained source view");
    throw std::runtime_error("Kimi CT selected expert was not supplied");
  }
 private:
  // Mapping scopes end before the original ready leases/resource owners.
  std::array<ExternalExpert,2> original_{};
  std::array<std::array<m::HostMapping,2>,2> mappings_{};
};
inline std::array<c::TensorDesc,2> source_descriptions() {
  return {specs[0].roles[0].description(),specs[0].roles[2].description()};
}
} // namespace kimi_ct_int4_source_roles
'''.replace('__SPECS__', ',\n'.join(specs))

addition = r'''

TEST(CpuCtPackedGrouped, KimiInt4IndependentSourceRolesKeepSelectedBanksAndBfloatStore) {
  namespace r=kimi_ct_int4_source_roles;
  namespace s=model_plane_resident_weights;
  namespace nv=nvfp4_reference_test;
  namespace c=f::c;namespace g=f::g;namespace m=f::m;
  using Type=f::Type;
  auto context=f::take(g::cpu::create_context(),"Kimi CT CPU context");
  auto queue=f::take(context.create_queue(),"Kimi CT CPU queue");
  struct Drain{c::Context &value;~Drain(){value.drain().IgnoreError();}}drain{context};
  struct SystemResource{m::MemoryResourceRef ref()const noexcept{return m::system_resource();}};
  auto owner=f::take(c::StorageOwner::adopt(context,SystemResource{}),"external source CPU owner");
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
  const auto layout=f::take(s::Layout::create(r::source_descriptions(),r::domain,r::capacity),"original independent Q/SF planes");
  auto supply=f::take(s::CpuSupply::create(owner,layout),"existing two-generation CPU supply");
  struct Selection{std::vector<std::int32_t> globals,map;};
  const auto selection=[](unsigned generation) {
    Selection result;result.globals={std::int32_t(generation*2),std::int32_t(generation*2+1)};
    result.map.assign(std::size_t(r::domain),-1);
    for(std::size_t i=0;i<result.globals.size();++i)result.map[std::size_t(result.globals[i])]=std::int32_t(i);
    return result;
  };
  const auto scale=[](std::int32_t expert,std::int64_t row,std::int64_t group) {
    return std::uint16_t(0x3f81u+unsigned((expert+row+group)%3));
  };
  const auto code=[](std::int32_t expert,std::int64_t row,std::int64_t group) {
    return 3+int((expert+row+group)%3)*2;
  };
  const auto source=[&](const Selection &selected) {
    std::array<r::ExternalExpert,2> result;
    for(std::size_t i=0;i<result.size();++i) {
      const auto global=selected.globals[i];const auto &spec=r::specs[std::size_t(global)];
      result[i].global=global;
      std::vector<std::uint32_t> packed(std::size_t(r::n*r::k/8),0x88888888u);
      std::vector<std::uint16_t> sf(std::size_t(r::n*r::k/r::group));
      for(std::int64_t row=0;row<r::n;++row) {
        for(std::int64_t group=0;group<r::k/r::group;++group)
          sf[std::size_t(row*(r::k/r::group)+group)]=scale(global,row,group);
        for(std::int64_t group=0;group<2;++group) {
          const auto at=std::size_t(row*(r::k/8)+group*r::group/8);
          packed[at]=(packed[at]&~15u)|unsigned(8+code(global,row,group));
        }
      }
      const std::array<std::int64_t,2> logical{r::n,r::k};
      const std::array<std::span<const std::byte>,3> bodies{
          std::as_bytes(std::span(packed)),std::as_bytes(std::span(logical)),std::as_bytes(std::span(sf))};
      for(std::size_t role=0;role<3;++role)result[i].roles[role]={
          r::named::detail::bind(spec.roles[role].name,spec.roles[role].description(),owner,bodies[role],&r::identity),
          spec.roles[role].data_begin,spec.roles[role].data_end};
    }
    return result;
  };
  auto builder=f::take(g::GraphBuilder::create(),"Kimi CT source graph");
  const auto adesc=f::dense(Type::kBFloat16,{2,1,r::k}),idesc=f::dense(Type::kInt32,{2,2});
  const auto activation=f::take(builder.input(adesc),"original BF16 A");
  const auto ids=f::take(builder.input(idesc),"actual global IDs");
  std::array<g::ValueId,3> banks;
  for(std::size_t p=0;p<2;++p)banks[p]=f::take(builder.input(layout.resident[p]),"selected compressed plane");
  banks[2]=f::take(builder.input(layout.map_description()),"same-generation map");
  const auto local=f::take(builder.add(c::Gather{0,c::IndexBoundsPolicy::kChecked},banks[2],ids),"checked actual local IDs");
  const auto reshape=[&](g::ValueId value,std::initializer_list<std::int64_t> dimensions) {
    const auto shape=f::take(c::TensorShape::create({dimensions.begin(),dimensions.size()}),"original source shape");
    return f::take(builder.add(f::take(c::View::reshape(shape),"original source View"),value),"original source reshape");
  };
  const auto q=reshape(banks[0],{r::capacity*r::n,r::k/8});
  const auto sf=reshape(banks[1],{r::capacity*r::n,r::k/r::group});
  const auto decoded=f::take(builder.add(c::model_ops::artifact_weight_decode(
      c::model_ops::WeightArtifactFormat::kCompressedTensorsSymmetric4,128,Type::kBFloat16),q,sf),"original BF16 CT decode boundary");
  const auto weights=reshape(decoded,{r::capacity,r::n,r::k});
  const auto widened=f::take(builder.add(c::Cast{Type::kFloat32},activation),"explicit widened BF16 A");
  const auto dot=f::take(builder.add(c::model_ops::grouped_matmul(),weights,widened,local),"original selected BF16 weight operand");
  const auto output=f::take(builder.add(c::Cast{Type::kBFloat16},dot),"original projection BF16 store");
  f::check(builder.publish(output),"publish actual projection store");
  auto graph=f::take(std::move(builder).finish(),"finite selected Kimi source graph");
  auto compiled=f::take(g::cpu::compile(graph,context),"compile existing grouped packed path");
  bool packed=false;
  for(std::size_t step=0;step<compiled.report.step_count();++step) {
    const auto record=f::take(compiled.report.step(step),"actual Kimi source step");
    if(record.policy==ct_packed_graph_test::kPackedPolicy) {
      packed=true;EXPECT_LT(record.workspace.size,std::size_t(r::capacity*r::n*r::k*2));
    }
  }
  ASSERT_TRUE(packed)<<"Existing CT grouped contraction must retain compressed banks until selected access";
  const auto odesc=f::take(graph.value_description(output),"actual BF16 projection output");
  auto pool=f::take(c::LeasePool::create(owner.ref(),256u<<10,{.max_blocks=8}),"finite original input/output pool");
  const auto upload=[&](std::span<const std::byte> bytes) {
    auto writer=f::take(pool.allocate(bytes.size(),64),"dynamic source bytes");
    f::check(writer.view()->write(bytes),"write dynamic source");return f::take(writer.publish(),"ready dynamic source");
  };
  std::array<s::CpuBatch,2> generations;
  std::array<g::Invocation,2> runs;
  std::array<c::ReadLease,2> results;
  std::array<std::vector<std::uint16_t>,2> saved;
  constexpr std::array<std::array<float,2>,2> coefficients{{{1.F,-1.F},{.5F,1.F}}};
  std::array<int,2> weight_store_witnesses{};
  for(unsigned generation=0;generation<2;++generation) {
    const auto selected=selection(generation);auto external=source(selected);
    if(!generation) {
      auto bad=external;bad[0].roles[0].data_begin+=4;
      EXPECT_FALSE(r::Source::accept(bad));
      const std::array<std::int64_t,2> wrong{r::k,r::n};
      bad=external;const auto &spec=r::specs[0].roles[1];
      bad[0].roles[1].ready=r::named::detail::bind(spec.name,spec.description(),owner,std::as_bytes(std::span(wrong)),&r::identity);
      EXPECT_FALSE(r::Source::accept(bad));
      bad=external;bad[0].roles[2].ready.description=f::dense(Type::kFloat16,{r::n,r::k/r::group});
      EXPECT_FALSE(r::Source::accept(bad));
      EXPECT_TRUE(external[0].roles[0].ready.lease.valid());
    }
    auto accepted=f::take(r::Source::accept(external),"actual external shape/Q/SF roles");
    // ReadonlyRole and scoped mappings retain the original external leases.
    external={};
    std::array<std::string,2> expected_hash;
    for(std::size_t p=0;p<2;++p) {
      std::vector<std::byte> bytes;
      for(const auto global:selected.globals) {
        const auto plane=accepted.plane_bytes(p,global);bytes.insert(bytes.end(),plane.begin(),plane.end());
      }
      expected_hash[p]=original_role_input::sha256(bytes);
    }
    generations[generation]=f::take(supply.upload(selected,accepted),"existing same-generation compressed Q/SF/map upload");
    f::check(accepted.close(),"release original source mappings/leases before Graph");
    for(std::size_t p=0;p<2;++p) {
      std::vector<std::byte> bytes(generations[generation].banks[p].size());
      f::check(generations[generation].banks[p].view()->read(bytes),"read copied original plane bytes");
      EXPECT_EQ(original_role_input::sha256(bytes),expected_hash[p]);
    }
    auto &run=runs[generation];run=f::take(compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"original source Invocation");
    for(std::size_t p=0;p<banks.size();++p)f::check(run.bind(banks[p],p<2?layout.resident[p]:layout.map_description(),
        generations[generation].banks[p]),"same-generation original bank/map bind");
    std::vector<std::uint16_t> a(std::size_t(2*r::k),0);
    for(std::size_t query=0;query<coefficients.size();++query)for(std::size_t term=0;term<2;++term)
      a[query*std::size_t(r::k)+term*std::size_t(r::group)]=nv::bf16(coefficients[query][term]);
    const std::array<std::int32_t,4> route{selected.globals[1],selected.globals[0],selected.globals[0],selected.globals[1]};
    f::check(run.bind(activation,adesc,upload(std::as_bytes(std::span(a)))),"actual A lease");
    f::check(run.bind(ids,idesc,upload(std::as_bytes(std::span(route)))),"actual current global IDs");
    if(f::take(compiled.executable.output_ownership(),"Kimi source output ownership")==g::OutputOwnership::kCaller)
      f::check(run.bind(output,odesc,f::take(pool.allocate(f::take(odesc.required_bytes(),"BF16 output bytes"),64),"original result writer")),"bind output writer");
    f::check(run.prepare_replay(queues),"prepare original selected Graph");
    {auto done=f::take(run.submit(queues),"submit original selected Graph");f::check(done.wait(),"actual projection Completion");}
    results[generation]=f::take(f::take(run.result(output),"original projection result").storage_lease(),"retain old projection storage");
    saved[generation].resize(std::size_t(4*r::n));
    f::check(results[generation].view()->read(std::as_writable_bytes(std::span(saved[generation]))),"read actual BF16 store");
    for(std::size_t item=0;item<route.size();++item)for(std::int64_t row=0;row<r::n;++row) {
      const auto query=item/2;float sum=0,without_weight_store=0;
      for(std::int64_t group=0;group<2;++group) {
        const auto raw=nv::f32(double(code(route[item],row,group))*nv::wide(scale(route[item],row,group)));
        const auto weight=nv::wide(nv::bf16(raw));
        const auto a_value=double(coefficients[query][std::size_t(group)]);
        sum=nv::f32(double(sum)+double(nv::f32(double(weight)*a_value)));
        // Forbidden omission of the original BF16 weight-product boundary.
        // Compare FINAL BF16 outputs: one-term dots cannot witness this gate.
        without_weight_store=nv::f32(double(without_weight_store)+double(nv::f32(double(raw)*a_value)));
      }
      const auto expected=nv::bf16(sum),alternative=nv::bf16(without_weight_store);
      weight_store_witnesses[query]+=int(expected!=alternative);
      EXPECT_EQ(saved[generation][item*std::size_t(r::n)+std::size_t(row)],expected);
    }
  }
  EXPECT_GT(weight_store_witnesses[0],0)<<"Cancellation query must distinguish the intermediate BF16 weight store";
  EXPECT_GT(weight_store_witnesses[1],0)<<"Second query must distinguish the intermediate BF16 weight store";
  EXPECT_NE(saved[0],saved[1]);
  EXPECT_EQ(supply.stats().live_blocks,6u);
  {
    const auto selected=selection(0);auto external=source(selected);
    auto accepted=f::take(r::Source::accept(external),"third cold valid source");
    EXPECT_FALSE(supply.upload(selected,accepted))<<"Two original retained generations exhaust the existing finite pool";
    f::check(accepted.close(),"close third original source mappings");
  }
  generations={};EXPECT_EQ(supply.stats().live_blocks,6u); // Invocations still own Q/SF/map.
  runs={};EXPECT_EQ(supply.stats().live_blocks,0u);
  compiled={};
  for(std::size_t generation=0;generation<results.size();++generation) {
    std::vector<std::uint16_t> actual(saved[generation].size());
    f::check(results[generation].view()->read(std::as_writable_bytes(std::span(actual))),"old BF16 output after all bank owners retire");
    EXPECT_EQ(actual,saved[generation]);
  }
  ::testing::Test::RecordProperty("source_repository",std::string(r::repository));
  ::testing::Test::RecordProperty("source_revision",std::string(r::revision));
  ::testing::Test::RecordProperty("source_value_scope","generated fixture only; publisher Q/shape/SF body not cached or verified");
  ::testing::Test::RecordProperty("source_generations",2);
  ::testing::Test::RecordProperty("selected_experts_per_generation",2);
  ::testing::Test::RecordProperty("actual_projection_rows",3072);
  ::testing::Test::RecordProperty("actual_projection_depth",3584);
  ::testing::Test::RecordProperty("bf16_weight_store_final_output_witnesses_query0",weight_store_witnesses[0]);
  ::testing::Test::RecordProperty("bf16_weight_store_final_output_witnesses_query1",weight_store_witnesses[1]);
}
'''

paths = ['tests/compute_models/kimi_ct_int4_source_roles.h',
         'tests/graph_route_cpu/ct_packed_grouped_test.cc']
files, patch = [], []
for relative in paths:
    path = ROOT / relative
    before = path.read_bytes() if path.exists() else b''
    if relative.endswith('_roles.h'):
        after = header.encode()
    else:
        text = before.decode()
        newline = '\r\n' if b'\r\n' in before else '\n'
        anchor = '#include "../compute_models/ct_packed_grouped_fixture.h"'
        assert text.count(anchor) == 1
        text = text.replace(anchor, anchor+newline+'#include "../compute_models/kimi_ct_int4_source_roles.h"'+newline+
                            '#include "../compute_models/nvfp4_reference_fixture.h"')
        assert text.count('} // namespace') == 1
        text = text.replace('} // namespace',addition.replace('\n',newline)+newline+'} // namespace')
        after = text.encode()
    for directory, raw in [('before',before),('source',after)]:
        target = WORK/directory/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)
    files.append({'path':relative,'before':dict(exists=path.exists(),**pin(before)),'after':pin(after)})
    patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),
                                    fromfile='a/'+relative,tofile='b/'+relative))
(WORK/'source.patch').write_text(''.join(patch),encoding='utf-8',newline='')
(WORK/'source-pins.json').write_text(json.dumps({'revision':2,'status':'PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN','files':files},indent=2)+'\n')
facts = {'revision':2,'status':'PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN',
         'source':{'repository':'RedHatAI/Kimi-K3-INT4','revision':'d5048a3ba6d23dd68749ea4b84abcb66d59a07e3',
                   'shard':'model-00001-of-00142.safetensors','header':pin(HEADER.read_bytes()),
                   'config':pin((CACHE/'config.json').read_bytes()),'payload_cached':False,
                   'role_metadata':source_rows},
         'minimum_glue':'One finite caller-side typed role adapter validates exact Q/shape/SF identity, data-relative ranges and actual I64[2] contents, retaining external ReadonlyRole leases and scoped mappings. Existing CpuSupply and CudaSupply interfaces remain unchanged.',
         'consumer':'CpuCtPackedGrouped.KimiInt4IndependentSourceRolesKeepSelectedBanksAndBfloatStore',
         'geometry':'layer1 W1, source N3072/K3584/group128/noZ/BF16 SF; two selected original IDs0,1 then2,3 from domain896; T2/S2; BF16 A->F32; BF16 decode and W operand; F32 accumulation->BF16 original projection store',
         'numerical_witness':'Each query has two nonzero BF16 terms, group0/group1: query0(+1,-1), query1(+0.5,+1). Independent scalar oracle rounds each code*SF to BF16 before F32 multiply/add and final BF16; a second oracle omits the intermediate weight-product BF16 store. Require at least one differing FINAL BF16 output for each query, not merely a pre-store product difference.',
         'same_generation':'CpuSupply keeps two original Q/SF/map lease batches; each Invocation binds one batch only and prepares/submits after every binding succeeds. CudaSupply plane_view/upload_slices composes with the same source, but no CUDA use is claimed.',
         'finite_check_plan':'ROOT may replace only existing graph_route_cpu/ct_packed_grouped_test.cc TU in its current compatible CPU closure and run the exact one new filter. No model/provider/core/SDK rebuild and no native matrix.',
         'not_qualified':['All numeric Q/shape/SF bodies are explicitly generated fixture values, never original publisher payload.',
                          'Only four cached W1 role triplets are bound; W2/W3, Top16, SiTU/combine and whole model are outside this finite projection consumer.',
                          'No CPU/CUDA/other native check has been executed by this preparation.']}
(WORK/'binding-plan.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({'files':files,'patch':pin((WORK/'source.patch').read_bytes())},indent=2))
