"""Mechanical private source extraction; no compile, runtime, SDK or network."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent

def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

heavy = 'tests/compute_models/original_named_role_source.h'
light = 'tests/compute_models/original_readonly_role.h'
kimi = 'tests/compute_models/kimi_ct_int4_source_roles.h'
test = 'tests/graph_route_cpu/ct_packed_grouped_test.cc'
raw = (ROOT/heavy).read_bytes()
text = raw.decode()
newline = '\r\n' if b'\r\n' in raw else '\n'
begin = text.index('namespace c=hyle::compute;')
end = text.index('struct ManifestSpec final {')
original_definitions = text[begin:end]
alias = 'namespace input=original_role_input;' + newline
assert original_definitions.count(alias) == 1
moved = original_definitions.replace(alias, '')
light_text = '''#pragma once

#include <cstddef>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>

#include "hyle/compute/storage_owner.h"
#include "hyle/compute/tensor_desc.h"
#include "hyle/graph/executable.h"

// Shared ready-role identity, storage and original upload contract. Source
// authentication and native GGUF metadata remain in their existing adapter.
namespace original_named_role_source {
'''.replace('\n',newline) + moved + '} // namespace original_named_role_source' + newline
new_heavy = text[:begin] + alias + text[end:]
anchor = '#include "original_role_input.h"'
assert new_heavy.count(anchor) == 1
new_heavy = new_heavy.replace(anchor, '#include "original_readonly_role.h"'+newline+anchor)
new_kimi = (ROOT/kimi).read_bytes().decode()
assert new_kimi.count('#include "original_named_role_source.h"') == 1
new_kimi = new_kimi.replace('#include "original_named_role_source.h"', '#include "original_readonly_role.h"')
test_raw = (ROOT/test).read_bytes()
new_test = test_raw.decode()
test_newline = '\r\n' if b'\r\n' in test_raw else '\n'
test_anchor = '#include "../compute_models/nvfp4_reference_fixture.h"'
assert new_test.count(test_anchor) == 1
new_test = new_test.replace(test_anchor, test_anchor+test_newline+'#include "../compute_models/original_role_input.h"')
outputs = {heavy:new_heavy.encode(), light:light_text.encode(), kimi:new_kimi.encode(), test:new_test.encode()}
files, patch = [], []
for relative, after in outputs.items():
    path = ROOT/relative
    before = path.read_bytes() if path.exists() else b''
    for directory,data in [('before',before),('source',after)]:
        target=WORK/directory/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    files.append({'path':relative,'before':{'exists':path.exists(),**pin(before)},'after':pin(after)})
    patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),
                                    fromfile='a/'+relative,tofile='b/'+relative))
(WORK/'source.patch').write_text(''.join(patch),encoding='utf-8',newline='')
(WORK/'source-pins.json').write_text(json.dumps({'status':'PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN','files':files},indent=2)+'\n')
assert moved.encode() in outputs[light]
assert text[end:] == new_heavy[new_heavy.index('struct ManifestSpec final {'):]
checks = {'status':'PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN',
          'mechanical_definition_bytes':pin(moved.encode()),
          'definitions':'Identity, ReadonlyRole, detail::take, detail::bind and namespace c/g/m aliases moved unchanged; input alias stays with original_role_input.',
          'native_manifest_and_Data_suffix':pin(text[end:].encode()),
          'native_manifest_and_Data_byte_identical':True,
          'kimi_delta':'Only include original_named_role_source.h -> original_readonly_role.h; body and runtime statements unchanged.',
          'cpu_test_delta':'Only explicit original_role_input.h include for its existing sha256 call; all r2 math/runtime statements unchanged.',
          'not_done':['No C++ compile, link or test process.', 'No change to original CPU1 failure/raw.', 'No SDK/provider/core rebuild or network.']}
(WORK/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'files':files,'patch':pin((WORK/'source.patch').read_bytes())},indent=2))
