from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time,os
repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/inference-gaps/g01'
source=Path('/home/kiro/hyle-f1/sanitizers/source-03242e7723cb')
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert source.is_dir() and source.parent==Path('/home/kiro/hyle-f1/sanitizers')
manifest=[];copied=[]
names=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
for name in names:
 if not name or not(name.startswith(('include/','src/','cmake/','third_party/','tests/','scripts/')) or name in ('CMakeLists.txt','CMakePresets.json')):continue
 p=repo/name
 if not p.is_file():continue
 data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();target=source/name
 manifest.append({'path':name,'sha256':sha})
 if target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest()==sha:continue
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);copied.append(name)
(out/'cpu-ragged-validation-inputs.json').write_text(json.dumps({'candidate':candidate,'source':str(source),'copied':copied,'files':manifest},indent=2)+'\n')
mode=sys.argv[1];assert mode in ('asan','ubsan','tsan')
build=source.parent/(mode+'-03242e7723cb');hook=out/('cpu-ragged-'+mode+'-project.cmake')
body='''if(PROJECT_NAME STREQUAL "hyle")
 get_property(_ready GLOBAL PROPERTY G01_RAGGED_GTEST)
 if(NOT _ready)
  set_property(GLOBAL PROPERTY G01_RAGGED_GTEST TRUE)
  set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
  add_subdirectory(/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-ragged-gtest EXCLUDE_FROM_ALL)
 endif()
 function(g01_ragged_tests)
  add_executable(g01_cpu_ragged_test "'''+str(source/'tests/compute_provider_ggml/native_ragged_test.cc')+'''" "'''+str(source/'tests/compute_provider_ggml/layout_broadcast_test.cc')+'''")
  target_compile_features(g01_cpu_ragged_test PRIVATE cxx_std_23)
  target_link_libraries(g01_cpu_ragged_test PRIVATE hyle::compute hyle_compute_provider_ggml hyle_compute_batch hyle_compute_backend_cpu hyle_simd GTest::gtest_main)
  hyle_apply_sanitizer(g01_cpu_ragged_test)
  hyle_stage_runtime(g01_cpu_ragged_test)
  add_executable(g01_cpu_ragged_public "/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g01/public_cpu_ragged.cc")
  target_compile_features(g01_cpu_ragged_public PRIVATE cxx_std_23)
  target_link_libraries(g01_cpu_ragged_public PRIVATE hyle::compute hyle::graph hyle_compute_provider_ggml)
  hyle_apply_sanitizer(g01_cpu_ragged_public)
  hyle_stage_runtime(g01_cpu_ragged_public)
 endfunction()
 cmake_language(DEFER CALL g01_ragged_tests)
endif()
'''
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
record=out/('cpu-ragged-'+mode+'-result.json');records=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args,env=None):
 n=1+sum(x['stage']==stage for x in records);log=out/f'cpu-ragged-{mode}-{stage}-{n}.log';start=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 record.write_text(json.dumps({'candidate':candidate,'mode':mode,'stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2200));print(f.read(2200).decode(errors='replace'))
  raise SystemExit(r.returncode)
run('configure',['cmake','-S',str(source),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook),'-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES'])
run('build',['cmake','--build',str(build),'--target','g01_cpu_ragged_test','g01_cpu_ragged_public','--parallel','4'])
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True));flag={'asan':'-fsanitize=address','ubsan':'-fsanitize=undefined','tsan':'-fsanitize=thread'}[mode];checked=[]
for name in ['src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml/native_batch.cc','src/compute_batch/batch_execution.cc','tests/compute_provider_ggml/native_ragged_test.cc','src/graph_batch/batch.cc','public_cpu_ragged.cc']:
 rows=[x for x in commands if x['file'].endswith(name)];assert rows and all(flag in x['command'] for x in rows),name;checked+=rows
(out/('cpu-ragged-'+mode+'-instrumented-inputs.json')).write_text(json.dumps(checked,indent=2)+'\n')
env=os.environ.copy();env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
exe=build/'bin/g01_cpu_ragged_test';args=[str(exe)]
if mode=='tsan':args=['setarch','x86_64','-R',*args]
run('run',args,env)
args=[str(build/'bin/g01_cpu_ragged_public')]
if mode=='tsan':args=['setarch','x86_64','-R',*args]
run('run-public-graph',args,env)
