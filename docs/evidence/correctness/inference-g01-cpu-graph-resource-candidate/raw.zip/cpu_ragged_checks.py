from pathlib import Path
import os,subprocess,json,time
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';build=repo/'.scratch/build-compute-v2-dev'
batch=out/'cpu-ragged-env.cmd';batch.write_text('@echo off\ncall "C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\Common7\\Tools\\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul\nif errorlevel 1 exit /b 1\nset\n')
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(batch)],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
hook=out/'cpu-ragged-project.cmake'
hook_body='''if(PROJECT_NAME STREQUAL "hyle")
  get_property(_ready GLOBAL PROPERTY G01_RAGGED_GTEST)
  if(NOT _ready)
    set_property(GLOBAL PROPERTY G01_RAGGED_GTEST TRUE)
    set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
    add_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-ragged-gtest EXCLUDE_FROM_ALL)
  endif()
  function(g01_ragged_tests)
    add_executable(g01_cpu_ragged_test "'''+str(repo/'tests/compute_provider_ggml/native_ragged_test.cc').replace('\\','/')+'''")
    target_compile_features(g01_cpu_ragged_test PRIVATE cxx_std_23)
    target_compile_options(g01_cpu_ragged_test PRIVATE /W4 /WX /wd4324 /utf-8)
    target_link_libraries(g01_cpu_ragged_test PRIVATE hyle::compute hyle_compute_provider_ggml hyle_compute_batch hyle_compute_backend_cpu hyle_simd GTest::gtest_main)
    hyle_stage_runtime(g01_cpu_ragged_test)
  endfunction()
  cmake_language(DEFER CALL g01_ragged_tests)
endif()
'''
if not hook.exists() or hook.read_text()!=hook_body:
 hook.write_text(hook_body)
result_file=out/'cpu-ragged-checks.json';records=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
def run(stage,args):
 n=1+sum(x['stage']==stage for x in records);log=out/f'cpu-ragged-{stage}-{n}.log';start=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'phase':'AUDITED CPU ragged, not candidate/P1','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2400));print(f.read(2400).decode(errors='replace'))
  raise SystemExit(r.returncode)
if next((x for x in reversed(records) if x['stage']=='configure'),{}).get('exit_code')!=0:
 run('configure',['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
run('build',['cmake','--build',str(build),'--target','g01_cpu_ragged_test','--parallel','4'])
run('run',[str(build/'bin/g01_cpu_ragged_test.exe')])
