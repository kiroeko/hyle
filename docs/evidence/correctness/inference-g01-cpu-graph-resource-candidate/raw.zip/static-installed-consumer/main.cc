#include <hyle/compute/cpu.h>
#include <hyle/compute/batch_execution.h>
#include <hyle/compute/providers/ggml_cpu.h>
#include <hyle/graph/batch.h>
#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <vector>
namespace c=hyle::compute;
namespace g=hyle::graph;
using hyle::Status;
Status run(){
 HYLE_ASSIGN_OR_RETURN(auto context,c::cpu::create_context({.native_threads=1}));
 HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
 for(auto dtype:{c::DataType::kFloat16,c::DataType::kBFloat16})for(unsigned depth:{64u,128u,256u}){
  constexpr unsigned hq=8,hk=2,qcap=20,kcap=84;
  c::BatchCapacity capacity{.storage=c::BatchStorage::kRagged,.data_type=dtype,.max_requests=3,
    .max_query_rows=qcap,.max_kv_rows=kcap,.max_pages=0,.max_page_refs=0,.query_heads=hq,.kv_heads=hk,.head_dim=depth,.page_size=1};
  HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(capacity));
  const std::array<std::int32_t,4> qp{0,1,18,18},kp{0,31,78,78};
  HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({qp,kp,{},{}}));
  HYLE_ASSIGN_OR_RETURN(auto program,c::BatchProgram::prepare(context,schema,{.resource=hyle::mem::system_resource(),.max_float_workspace_bytes=8u<<20,.max_int_workspace_bytes=4096,.scale=1.F/std::sqrt(float(depth))}));
  HYLE_ASSIGN_OR_RETURN(auto first,c::BatchInvocation::create(program,queue));
  HYLE_ASSIGN_OR_RETURN(auto second,c::BatchInvocation::create(program,queue));
  HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(hyle::mem::system_resource(),(qcap*hq+2*kcap*hk)*depth*2u+2048));
  std::vector<std::uint16_t> q(qcap*hq*depth),k(kcap*hk*depth),v(k.size(),dtype==c::DataType::kBFloat16?0x4300:0x5800);
  for(unsigned row=0;row<78;++row)for(unsigned head=0;head<hk;++head)for(unsigned d=0;d<depth;++d)
   v[(row*hk+head)*depth+d]=dtype==c::DataType::kBFloat16?(head?0x3f80:0x3f00):(head?0x3c00:0x3800);
  const auto load=[&](const auto &values)->hyle::Result<c::ReadLease>{HYLE_ASSIGN_OR_RETURN(auto w,pool.allocate(values.size()*2u));HYLE_ASSIGN_OR_RETURN(auto view,w.view());HYLE_RETURN_IF_ERROR(view.write(std::as_bytes(std::span(values))));return w.publish();};
  HYLE_ASSIGN_OR_RETURN(auto qr,load(q));HYLE_ASSIGN_OR_RETURN(auto kr,load(k));HYLE_ASSIGN_OR_RETURN(auto vr,load(v));
  const std::array inputs{qr,kr,vr};
  const auto verify=[&](const c::ReadLease &lease)->Status{
   std::vector<std::uint16_t> actual(q.size());HYLE_ASSIGN_OR_RETURN(auto view,lease.view());HYLE_RETURN_IF_ERROR(view.read(std::as_writable_bytes(std::span(actual))));
   for(unsigned row=0;row<18;++row)for(unsigned head=0;head<hq;++head)for(unsigned d=0;d<depth;++d){
    const auto bits=actual[(row*hq+head)*depth+d];const auto wanted=dtype==c::DataType::kBFloat16?(head/4?0x3f80:0x3f00):(head/4?0x3c00:0x3800);
    if(bits!=wanted)return Status::Internal("CPU native ragged GQA/tail output differs");
   }
   return Status::Ok();
  };
  HYLE_ASSIGN_OR_RETURN(auto one,first.prepare_batch(layout));HYLE_ASSIGN_OR_RETURN(auto a,one.run(inputs));HYLE_RETURN_IF_ERROR(a.wait());HYLE_ASSIGN_OR_RETURN(auto old,first.output());HYLE_RETURN_IF_ERROR(verify(old));
  HYLE_ASSIGN_OR_RETURN(auto two,second.prepare_batch(layout));HYLE_ASSIGN_OR_RETURN(auto b,two.run(inputs));HYLE_RETURN_IF_ERROR(b.wait());HYLE_ASSIGN_OR_RETURN(auto independent,second.output());HYLE_RETURN_IF_ERROR(verify(independent));
  one={};a={};auto blocked=first.update_batch(layout);if(blocked||!blocked.error().IsUnavailable())return Status::Internal("CPU ragged overwrote retained output");old.reset();
  HYLE_ASSIGN_OR_RETURN(auto next,schema.version({qp,kp,{},{}}));HYLE_ASSIGN_OR_RETURN(auto replay,first.update_batch(next));
  if(!first.report().reused_native_plan)return Status::Internal("CPU ragged unchanged topology was rebuilt");
  HYLE_ASSIGN_OR_RETURN(auto c,replay.run(inputs));HYLE_RETURN_IF_ERROR(c.wait());HYLE_ASSIGN_OR_RETURN(auto output,first.output());HYLE_RETURN_IF_ERROR(verify(output));
  for(auto port:{1u,2u}){std::vector<std::uint16_t> after(k.size());HYLE_ASSIGN_OR_RETURN(auto view,inputs[port].view());HYLE_RETURN_IF_ERROR(view.read(std::as_writable_bytes(std::span(after))));if(after!=(port==1?k:v))return Status::Internal("CPU ragged readonly K/V changed");}
  replay={};c={};output.reset();two={};b={};independent.reset();HYLE_RETURN_IF_ERROR(first.close());HYLE_RETURN_IF_ERROR(second.close());
 }
 HYLE_RETURN_IF_ERROR(context.close());
#if defined(HYLE_COMPUTE_GGML_CPU)
 const c::BatchCapacity cap{.storage=c::BatchStorage::kRagged,.data_type=c::DataType::kBFloat16,.max_requests=2,
   .max_query_rows=2,.max_kv_rows=6,.max_pages=0,.max_page_refs=0,.query_heads=4,.kv_heads=2,.head_dim=64,.page_size=1};
 HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(cap));
 HYLE_ASSIGN_OR_RETURN(auto wrapped,g::batch::provider(c::ggml_cpu::provider({.native_threads=1}),schema,
   {.resource=hyle::mem::system_resource(),.max_float_workspace_bytes=1u<<20,.max_int_workspace_bytes=4096,.scale=.125F}));
 HYLE_ASSIGN_OR_RETURN(auto ctx,c::Context::create(c::cpu::device(),wrapped));HYLE_ASSIGN_OR_RETURN(auto qqueue,ctx.create_queue());
 const std::array<std::int32_t,3> qp{0,1,2},kp{0,3,6};HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({qp,kp,{},{}}));
 HYLE_ASSIGN_OR_RETURN(auto qd,c::TensorDesc::dense(cap.data_type,std::array<std::int64_t,3>{2,4,64}));
 HYLE_ASSIGN_OR_RETURN(auto kd,c::TensorDesc::dense(cap.data_type,std::array<std::int64_t,3>{6,2,64}));
 HYLE_ASSIGN_OR_RETURN(auto md,schema.metadata_description());const std::array desc{qd,kd,kd,md};
 HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());std::array<g::ValueId,4> ports;
 for(unsigned i=0;i<4;++i){HYLE_ASSIGN_OR_RETURN(ports[i],builder.input(desc[i]));}
 const auto operation=c::Operation::custom(c::RaggedAttention{cap,.125F});
 HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(operation,ports));HYLE_ASSIGN_OR_RETURN(auto middle,builder.result(node));
 const std::array next_inputs{middle,ports[1],ports[2],ports[3]};HYLE_ASSIGN_OR_RETURN(auto second_node,builder.add_node(operation,next_inputs));
 HYLE_ASSIGN_OR_RETURN(auto final,builder.result(second_node));HYLE_RETURN_IF_ERROR(builder.publish(final));HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
 const std::array storage{g::StorageDomain{hyle::mem::system_resource()}};const std::array targets{g::ExecutionTarget{&ctx,g::StorageDomainId{0}}};
 HYLE_ASSIGN_OR_RETURN(auto compiled,g::compile(graph,{storage,targets,{}},{.operation_fallback=g::OperationFallbackPolicy::kReject}));
 const std::array lanes{g::batch::LaneBinding{g::ExecutionLaneId{0},&ctx,&qqueue,hyle::mem::system_resource()}};
 HYLE_ASSIGN_OR_RETURN(auto slot,g::batch::Invocation::create(compiled.executable,lanes));
 HYLE_RETURN_IF_ERROR(slot.prepare_batch(std::array{g::batch::NodeLayout{node,layout},g::batch::NodeLayout{second_node,layout}}));
 HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(hyle::mem::system_resource(),8192));
 std::vector<std::uint16_t> zeros(512),values(768,0x3f00);
 const auto load=[&](const auto &data)->hyle::Result<c::ReadLease>{HYLE_ASSIGN_OR_RETURN(auto writer,pool.allocate(data.size()*2));HYLE_ASSIGN_OR_RETURN(auto view,writer.view());HYLE_RETURN_IF_ERROR(view.write(std::as_bytes(std::span(data))));return writer.publish();};
 HYLE_ASSIGN_OR_RETURN(auto qr,load(zeros));zeros.resize(768);HYLE_ASSIGN_OR_RETURN(auto kr,load(zeros));HYLE_ASSIGN_OR_RETURN(auto vr,load(values));
 const std::array inputs{qr,kr,vr};for(unsigned i=0;i<3;++i)HYLE_RETURN_IF_ERROR(slot.bind(ports[i],desc[i],inputs[i]));
 HYLE_ASSIGN_OR_RETURN(auto writer,pool.allocate(1024));HYLE_RETURN_IF_ERROR(slot.bind(final,qd,std::move(writer)));
 HYLE_ASSIGN_OR_RETURN(auto done,slot.submit());HYLE_RETURN_IF_ERROR(done.wait());HYLE_ASSIGN_OR_RETURN(auto output,slot.output(final));
 HYLE_ASSIGN_OR_RETURN(auto lease,output.storage_lease());std::vector<std::uint16_t> actual(512);HYLE_ASSIGN_OR_RETURN(auto view,lease.view());HYLE_RETURN_IF_ERROR(view.read(std::as_writable_bytes(std::span(actual))));
 for(auto value:actual)if(value!=0x3f00)return Status::Internal("CPU graph native ragged dependent output differs");
 lease.reset();output.reset();done={};HYLE_RETURN_IF_ERROR(slot.drain());return ctx.close();
#else
 return Status::Ok();
#endif
}
int main(){const auto status=run();if(!status.ok()){std::fprintf(stderr,"%.*s\n",int(status.message().size()),status.message().data());return 1;}std::puts("ordinary CPU ragged two dtypes/three depths/two slots/old output/reuse/readonly/tail PASS");}
