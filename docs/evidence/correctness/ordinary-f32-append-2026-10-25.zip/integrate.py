from pathlib import Path
import hashlib
import json
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not (WORK / 'integrated.json').exists()
    status = subprocess.run(['git', 'status', '--porcelain'], cwd=ROOT,
                            capture_output=True, text=True, check=True)
    assert not status.stdout.strip(), status.stdout
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head.startswith('505eb5f71'), head
    entries = []
    for manifest, directory in [('product-pins.json', 'source'), ('test-pins.json', 'test-source')]:
        pins = read(WORK / manifest)
        for item in pins['files']:
            name = item['path']
            assert name.startswith(('src/', 'include/', 'tests/'))
            current = ROOT / name
            candidate = WORK / directory / name
            assert sha(current) == item['before']['sha256'], name
            assert sha(candidate) == item['after']['sha256'], name
            assert candidate.stat().st_size == item['after']['bytes'], name
            entries.append((item, candidate))
    assert len({item['path'] for item, _ in entries}) == len(entries)
    for item, candidate in entries:
        (ROOT / item['path']).write_bytes(candidate.read_bytes())
    combined = {'base_commit': head, 'files': [item for item, _ in entries]}
    (WORK / 'source-pins.json').write_text(json.dumps(combined, indent=2) + '\n', encoding='utf-8')
    (WORK / 'integrated.json').write_text(json.dumps({'base': head, 'paths': [item['path'] for item, _ in entries]}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'integrated_paths': len(entries), 'base': head}))


if __name__ == '__main__':
    main()
