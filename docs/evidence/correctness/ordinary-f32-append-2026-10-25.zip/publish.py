from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
NAME = 'ordinary-f32-append-2026-10-25'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': digest(data)}


def main():
    pins = read(WORK / 'source-pins.json')
    for item in pins['files']:
        assert pin(ROOT / item['path'])['sha256'] == item['after']['sha256']
    cpu = read(WORK / 'cpu1/summary.json')
    assert cpu['status'] == 'PASS'
    assert cpu['xml'] == {'tests': 8, 'failures': 0, 'errors': 0, 'skipped': 0}
    report = {
        'status': 'FINITE_CPU_PASS; NO_NEW_NATIVE_GPU_OR_MODEL_OR_TPS_RUN',
        'base_commit': pins['base_commit'],
        'source': [pin(ROOT / item['path']) for item in pins['files']],
        'implementation': [
            'Use original canonical one-row cache carrier to recover logical token rows; validate the entire actual description including strides.',
            'Explicitly exclude RowCache domain. Arena uses already validated whole attention rows; original identity, suffix permissions and actual retirement checks are unchanged.',
            'Remove redundant Vulkan dtype list after common carrier validation; exact native range, resource and alignment gates remain.',
            'No new CacheEncode identity, codec, owner, IR, registry, conversion, transfer or execution path.'
        ],
        'checks': {
            'CPU': {'xml': cpu['xml'], 'run_seconds': cpu['run']['seconds'],
                    'native': cpu['native'], 'replaced_objects': 3,
                    'cases': 'Seven existing CPU graph cases plus one new F32 case with COW and appendable modes; actual case details and raw XML/logs are in the archive.'},
            'new_F32_case': {'sequences': 1, 'query_rows': 2, 'query_heads': 24,
                             'kv_heads': 4, 'depth': 256, 'page_size': 16,
                             'old_KV': 17, 'new_KV': 19,
                             'modes': ['COW partial page', 'original reserved two-row suffix'],
                             'old_causal_ends': [16, 17], 'new_causal_ends': [18, 19],
                             'oracle': 'Independent F64 dot/softmax/value, nonzero and head-dependent inputs, abs1e-6; both K/V exact bytes and old reader permissions checked.',
                             'precision_witness': 'Expected outputs differ from both F16 and BF16 rounding by more than 2e-6.'},
            'strict_compile': [{'tag': item['tag'], 'exit': item['result']['exit'],
                                'seconds': item['result']['seconds']} for item in cpu['compiled']],
            'Vulkan': 'Affected host TU strictly compiled only; no new native copy/reader execution.',
            'Apple_CUDA_Linux': 'No new build or execution in this slice.',
            'new_Model_quality_TPS': False,
            'SDK_rebuilt': False, 'HTTP_model_download': 0
        },
        'boundaries': [
            'Finite CPU producer-to-Append-to-original-reader check, not a new F32 model or all geometry/format/backend certification.',
            'Reader capability remains independent of raw byte-copy capability. No new plain-F32 GPU reader support is claimed.',
            'Existing E4/Q8 CPU graph cases are adjacent regressions; this slice does not rerun previous full Model or native GPU checks.',
            'The new case has two T2 episodes, no independent T1 continuation and no explicit final zero-owner/budget assertion.',
            'Harness reuses existing toolchain/dependency/object caches; exact commands, source and native pins are retained, with no SDK or binary payload in the archive.'
        ]
    }
    for key, name in [('product_scope', 'product-scope.json'), ('test_scope', 'test-scope.json'),
                      ('source_review', 'source-review.json'), ('test_review', 'test-review.json')]:
        path = WORK / name
        if path.exists():
            data = path.read_bytes()
            report[key] = {'archive_member': name, 'bytes': len(data),
                           'sha256': digest(data), 'status': read(path).get('status')}
    subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True, capture_output=True)
    report['diff_check'] = 'PASS'
    payloads = {}
    for path in sorted(WORK.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(WORK)
        if any(part in {'source', 'before', 'test-source', '__pycache__', 'archive-private', 'source-before', 'test-before'} for part in relative.parts):
            continue
        if path.suffix.lower() not in {'.json', '.py', '.patch', '.md', '.xml', '.txt', '.log'}:
            continue
        payloads[relative.as_posix()] = path.read_bytes()
    payloads['summary.json'] = (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    manifest = [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in payloads.items()]
    payloads['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
    target = ROOT / 'docs/evidence/correctness' / (NAME + '.zip')
    outer = target.with_suffix('.json')
    assert not target.exists() and not outer.exists()
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for name, data in payloads.items():
            package.writestr(name, data)
    with zipfile.ZipFile(target) as package:
        assert package.testzip() is None
        for item in manifest:
            data = package.read(item['path'])
            assert len(data) == item['bytes'] and digest(data) == item['sha256']
    report['archive'] = {**pin(target), 'members': len(payloads), 'CRC_and_member_SHA_verified': True,
                         'SDK_binary_model_payload': False}
    report['publication_note'] = 'Archive summary predates the outer archive pin; source and check facts are identical.'
    outer.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'report': pin(outer), 'archive': pin(target)}))


if __name__ == '__main__':
    main()
