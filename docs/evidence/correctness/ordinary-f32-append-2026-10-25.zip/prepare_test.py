from pathlib import Path
import difflib
import hashlib
import json

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
NAME = 'tests/graph_batch/typed_capability_graph_test.cc'
def sha(data): return hashlib.sha256(data).hexdigest()
def replace(data, old, new):
    assert data.count(old) == 1, old
    return data.replace(old, new)

original_path = WORK/'test-before'/NAME
before = original_path.read_bytes() if original_path.is_file() else (ROOT/NAME).read_bytes()
newline = b'\r\n' if b'\r\n' in before else b'\n'
after = before
after = replace(after, b'#include <array>', b'#include <array>'+newline+b'#include <cmath>')
after = replace(after, b'#include <cstdint>', b'#include <cstdint>'+newline+b'#include <cstring>')
after = replace(after, b'#include <exception>', b'#include <exception>'+newline+b'#include <limits>')
after = replace(after, b'#include "hyle/compute/backends/cpu.h"',
    b'#include "hyle/compute/backends/cpu.h"'+newline+b'#include "hyle/compute/detail/batch_provider.h"')
after = replace(after, b'for (const auto type : {c::DataType::kFloat16, c::DataType::kBFloat16})',
    b'for (const auto type : {c::DataType::kFloat16, c::DataType::kBFloat16, c::DataType::kFloat32})')
old = '''  const auto f32 = c::CacheStorage::plain(c::DataType::kFloat32).value();
  const auto unsupported = gb::paged_append(schema.with_cache_storage(f32, f32).value(), c::BatchCacheRole::kKey);
  ASSERT_FALSE(unsupported);
  EXPECT_TRUE(unsupported.error().IsUnimplemented());'''.encode().replace(b'\n', newline)
after = replace(after, old+newline, b'')
addition = (WORK/'f32-test.inc').read_text(encoding='utf-8').encode().replace(b'\n', newline)
after = replace(after, b'} // namespace', addition+newline+b'} // namespace')
for directory, data in [('test-before', before), ('test-source', after)]:
    path = WORK/directory/NAME;path.parent.mkdir(parents=True, exist_ok=True);path.write_bytes(data)
pins = dict(status='PRIVATE_TEST_SOURCE_ONLY_NOT_COMPILED_OR_RUN', files=[dict(path=NAME,
    before=dict(bytes=len(before), sha256=sha(before)), after=dict(bytes=len(after), sha256=sha(after)))])
(WORK/'test-pins.json').write_text(json.dumps(pins, indent=2)+'\n', encoding='utf-8')
patch = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
    fromfile='a/'+NAME, tofile='b/'+NAME)).encode()
(WORK/'test.patch').write_bytes(patch)
print(json.dumps(dict(pins=pins, patch_sha256=sha(patch)), indent=2))
