from pathlib import Path
import subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
for case in ('rows-cuda','history-cpu','natural-cuda','natural-control-cuda','session-cuda'):
 subprocess.run([sys.executable,str(W/'build.py'),'run',case,'attempt1'],cwd=R,check=True)
