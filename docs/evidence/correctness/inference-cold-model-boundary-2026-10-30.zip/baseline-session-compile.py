from pathlib import Path
import importlib.util
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('baseline_session_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
p=b.read(W/'baseline-session-consumer.json');folder=W/'compile/baseline-session'
for key in ('main','original_main','probe','original_probe'):b.exact(p[key])
b.s.b.execute(p['compile'],folder/'attempt1',600)
d=b.read(folder/'dependencies.json')['Data']
paths=sorted({Path(x).resolve() for x in [d['Source'],*d['Includes']] if Path(x).is_relative_to(R)})
assert not any(path.name=='graph_builder.h' for path in paths),'Baseline accidentally consumed new cold header'
b.save(folder/'receipt.json',dict(object=b.pin(folder/'unit.obj'),dependencies=b.pin(folder/'dependencies.json'),process=b.pin(folder/'attempt1/process.json'),source_identities=[b.pin(path) for path in paths]))
print('BASELINE_SESSION_COMPILED_ORIGINAL_INLINE_MAIN')
