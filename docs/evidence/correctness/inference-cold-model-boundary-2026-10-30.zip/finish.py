from pathlib import Path
import json,hashlib,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
s=read(W/'summary-draft.json');assert s['status']=='PASS_FINITE_COLD_GRAPH_BUILDER_BOUNDARY' and not s['full_goal_complete']
for item in s['sources']:
 p=Path(item['path']);d=p.read_bytes();assert len(d)==item['bytes'] and hashlib.sha256(d).hexdigest()==item['sha256'],p
s['cleanup']=read(W/'cleanup-report.json')
s['limits'].append('Both378vector raw payload sets were removed after direct byte equality, all SHA256/size manifests and archive readback verification. Raw tensors are no longer re-readable; exact cached objects, sources, commands and original input identities remain reproducible.')
s['next']='Isolate cold cache plan/row-byte/checked-math facts currently pulled through weights.h into session_state.h; then continue family/phase factory and genuinecrossmodeladapter boundaries. Preserve sharedexecution and defaultperformance.'
payload=(json.dumps(s,indent=2,ensure_ascii=False)+'\n').encode()
(W/'summary.json').write_bytes(payload)
d=R/'docs/evidence/correctness';(d/'inference-cold-model-boundary-2026-10-30.json').write_bytes(payload)
archive=d/'inference-cold-model-boundary-2026-10-30.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as out:
 with zipfile.ZipFile(W/'evidence-draft.zip') as prior:
  for item in prior.infolist():out.writestr(item,prior.read(item.filename))
 for name in ['summary.json','finish.py','cleanup.ps1','cleanup-targets.json','cleanup-report.json']:out.write(W/name,name)
with zipfile.ZipFile(archive) as check:assert check.testzip() is None and check.read('summary.json')==payload
print('Published15finitechecks, 2oldSessionfailures, exact378vectors anddefault4casepairs; zip',archive.stat().st_size)
