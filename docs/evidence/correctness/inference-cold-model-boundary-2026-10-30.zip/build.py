"""Finite cold-model boundary build; unchanged cached SDK, max2 compilers."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,importlib.util,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('cold_model_prior_build',R/'.scratch/inference-source-binding-20261030/build.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.W=s.b.W=W
read,save,pin,exact,key=s.read,s.save,s.pin,s.exact,s.key
BASE=R/'.scratch/inference-draft-vocabulary-20261030/model-link-base.json'
def prepare_baseline():
 assert not (W/'baseline-plan.json').exists()
 base=read(BASE);cli=read(base['current_consumers']['cli']['receipt']['path'])
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 proofs=[]
 for item in [cli['object'],*base['retained'],base['runtime']]:exact(item)
 for item in cli['source_identities']:
  path=Path(item['path']);data=path.read_bytes()
  if len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']:
   proofs.append(dict(identity=item,proof='CURRENT_EXACT'))
  else:
   relative=path.relative_to(R).as_posix()
   old=subprocess.check_output(['git','show',commit+':'+relative],cwd=R)
   assert len(old)==item['bytes'] and hashlib.sha256(old).hexdigest()==item['sha256'],relative
   snapshot=W/'baseline-source'/relative;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(old)
   proofs.append(dict(identity=item,proof='EXACT_COMMITTED_BASELINE_SNAPSHOT',commit=commit,snapshot=pin(snapshot)))
 # Preserve only the model implementation and directly relevant type headers,
 # rather than a complete SDK/source tree. All other includes retain identities.
 snapshots=[]
 for relative in ('engine/models/qwen35/main.cc','engine/models/qwen35/mtp_graph.h','engine/models/qwen35/weights.h'):
  old=subprocess.check_output(['git','show',commit+':'+relative],cwd=R)
  target=W/'baseline-source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(old)
  snapshots.append(dict(relative=relative,snapshot=pin(target)))
 args=[]
 for arg in base['link']:
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/baseline').with_suffix(suffix));break
  args.append(arg)
 assert sum(key(arg)==key(cli['object']['path']) for arg in args)==1
 (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
 original=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
 common=['--inputs',str(original),'--capacity','1024','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','auto','--backend','cuda','--sampling','greedy','--decode-overlap','auto']
 cases={}
 for mode in ('ordinary','mtp'):
  for turn in ('single','two'):
   command=[*common,'--mtp','on' if mode=='mtp' else 'off']
   if mode=='mtp':command+=['--mtp-max-drafts','1']
   command+=['--steps','64'] if turn=='single' else ['--schedule',str(R/'.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt')]
   cases[mode+'-'+turn]=dict(consumer='cli',args=command,outputs=64 if turn=='single' else 128)
 fixture=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
 cases.update({'history-cpu':dict(consumer='tiny',args=['--cpu',str(fixture),'--history-control']),
  'natural-cuda':dict(consumer='tiny',args=['--cuda',str(fixture),'--natural-logits'])})
 save(W/'baseline-plan.json',dict(base=pin(BASE),base_commit=commit,cli_receipt=base['current_consumers']['cli']['receipt'],
  cli_object=cli['object'],source_proofs=proofs,snapshots=snapshots,retained=base['retained'],runtime=base['runtime'],
  link=args,cases=cases,SDK_CXX=0,NVCC=0,downloads=0,note='Zero-compile pre-split CLI; original current227-input cache and source identities, never the modified cold split.'))
 print('PREPARED_BASELINE',len(base['retained']),'cached inputs;',len(proofs),'source proofs;0 compilers/native/downloads.')
def link_baseline(attempt):
 p=read(W/'baseline-plan.json')
 for item in [p['cli_object'],*p['retained'],p['runtime']]:exact(item)
 s.b.execute(p['link'],W/'link/baseline'/attempt,240);save(W/'ready-baseline.json',pin(W/'bin/baseline.exe'))
def prepare_candidate(cold_source):
 assert not (W/'plan.json').exists()
 p=read(W/'baseline-plan.json');base=read(p['base']['path']);sdk=read(base['sdk_engine_dependencies']['path'])
 changed={key(R/name) for name in subprocess.check_output(['git','diff','--name-only','--','include','src','engine'],cwd=R,text=True).splitlines()}
 rows={key(row['object']):row for row in sdk['inspected']}
 rows.update({key(row['object']):row for row in sdk['engine_consumers'] if 'dependencies' in row})
 units={};actual=[];unavailable=[]
 for item in p['retained']:
  exact(item);obj=Path(item['path']);row=rows.get(key(obj))
  for adjacent in (obj.parent/'dependencies.json',obj.with_name(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')):
   if adjacent.is_file() and 'Data' in read(adjacent):row=dict(object=str(obj),dependencies=pin(adjacent));break
  if row is None:unavailable.append(str(obj));continue
  actual.append(row);d=read(row['dependencies']['path'])['Data']
  if not any(key(x) in changed for x in [d['Source'],*d['Includes']]):continue
  command,recipe=s.command_for(obj,d['Source'])
  name='sdk-'+Path(d['Source']).relative_to(R).as_posix().replace('/','__').replace('.','_')
  units[name]=dict(source=d['Source'],original=item,recipe=recipe,compile=s.relocated(command,name))
 source=Path(cold_source).resolve();assert source.is_relative_to(R/'engine/models/qwen35') and source.is_file()
 engine_units={'cold':dict(source=str(source),compile=s.relocated(base['compile'],'cold',source))}
 wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 consumers={name:dict(source=str(path),compile=s.relocated(base['compile'],name,path)) for name,path in
  [('cli',wrapper),('tiny',R/'tests/tools/qwen_host_image_test.cc'),('session',R/'engine/models/qwen35/mtp_session_probe.cc')]}
 save(W/'plan.json',dict(base=p['base'],base_commit=p['base_commit'],retained=p['retained'],runtime=p['runtime'],
  original_link=base['link'],original_consumer=p['cli_object']['path'],sdk=base['sdk_engine_dependencies'],
  actual_dependency_rows=actual,unavailable_dependencies=unavailable,units=units,engine_units=engine_units,consumers=consumers,
  cases=p['cases'],SDK_CXX=len(units),new_engine_CXX=1,NVCC=0,downloads=0,max_compilers=2))
 print('PREPARED_CANDIDATE affectedSDK',len(units),'newcold1;cli/tiny/session recipes; no build/native started.')
def compile_group(attempt,names):
 p=read(W/'plan.json');available=p['units']|p['engine_units']|p['consumers']
 for extra in ('extra-consumers.json','session-fixed-consumers.json'):
  if (W/extra).exists():available|=read(W/extra)
 names=list(p['units']) if names==['sdk'] else names
 def one(name):
  unit=available[name];folder=W/'compile'/name
  s.b.execute(unit['compile'],folder/attempt,600)
  deps=read(folder/'dependencies.json')['Data'];paths=sorted({Path(x).resolve() for x in [deps['Source'],*deps['Includes']] if Path(x).is_relative_to(R)})
  save(folder/'receipt.json',dict(object=pin(folder/'unit.obj'),dependencies=pin(folder/'dependencies.json'),process=pin(folder/attempt/'process.json'),source_identities=[pin(path) for path in paths]))
  print('COMPILED',name,flush=True)
 errors=[]
 with ThreadPoolExecutor(max_workers=2) as pool:
  jobs={pool.submit(one,name):name for name in names}
  for job in as_completed(jobs):
   try:job.result()
   except BaseException as error:errors.append(dict(name=jobs[job],error=str(error)))
 save(W/('compile-'+attempt+'-'+names[0]+'.json'),dict(units=names,errors=errors,max_concurrency=2));assert not errors,errors
def link(name,attempt):
 p=read(W/'plan.json');receipt=read(W/'compile'/name/'receipt.json');cold=read(W/'compile/cold/receipt.json')
 retained=list(p['retained']);replacement={}
 for unit,value in p['units'].items():
  current=read(W/'compile'/unit/'receipt.json');replacement[key(value['original']['path'])]=current['object']
 retained=[replacement.get(key(item['path']),item) for item in retained]
 for item in [receipt['object'],cold['object'],*retained,*receipt['source_identities'],*cold['source_identities']]:exact(item)
 args=[];count=0
 for arg in p['original_link']:
  if key(arg)==key(p['original_consumer']):arg=receipt['object']['path'];count+=1
  if key(arg) in replacement:arg=replacement[key(arg)]['path']
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert count==1;args.append(cold['object']['path'])
 s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
def run(case,attempt,baseline=False):
 p=read(W/'baseline-plan.json');cases=p['cases']
 if (W/'extra-cases.json').exists():cases|=read(W/'extra-cases.json')
 row=cases[case];consumer=('baseline-session' if row['consumer']=='session' else 'baseline') if baseline else row['consumer']
 image=read(W/('ready-'+consumer+'.json'));exact(image)
 folder=W/'runs'/('baseline' if baseline else 'candidate')/case/attempt
 save(folder/'image.json',image)
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
 args=[str(folder/'vectors') if value=='{OUTPUT}' else value for value in row['args']]
 s.b.execute([image['path'],*args],folder,600)
 text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();values=[];offset=0
 while offset<len(text):
  while offset<len(text) and text[offset].isspace():offset+=1
  if offset==len(text):break
  value,offset=decoder.raw_decode(text,offset);values.append(value)
 assert values
 result=values[0] if len(values)==1 else dict(status='PASS',reports=values)
 if 'outputs' in row:assert result['generated_tokens']==row['outputs'] and result['live_committed_versions']==0
 elif row.get('expected_status'):assert result['status']==row['expected_status']
 else:assert all(value['status'].startswith('PASS') for value in values)
 save(folder/'report.json',result);print('PASS',consumer,case)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare-baseline':prepare_baseline()
 elif action=='link-baseline':link_baseline(sys.argv[2])
 elif action=='prepare':prepare_candidate(sys.argv[2])
 elif action=='compile':compile_group(sys.argv[2],sys.argv[3:])
 elif action=='link':link(sys.argv[2],sys.argv[3])
 elif action=='run':run(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='baseline')
 else:raise ValueError(action)
