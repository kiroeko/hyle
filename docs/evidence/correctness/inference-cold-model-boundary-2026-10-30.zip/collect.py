"""Seal finite cold-boundary evidence. No build/native execution or cleanup."""
from pathlib import Path
import copy,hashlib,json,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def pin(path):
 path=Path(path);data=path.read_bytes()
 return dict(path=str(path.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def exact(item):assert pin(item['path'])==item,item['path']
def terminal(process):assert process['state']=='TERMINAL' and not process.get('timed_out'),process
def norm(path):return str(Path(path).resolve()).lower()

plan=read(W/'plan.json');baseline=read(W/'baseline-plan.json')
assert not plan['units'] and len(plan['retained'])==227
for item in [*plan['retained'],plan['runtime']]:exact(item)
receipts={};source_proofs=[]
for path in sorted((W/'compile').glob('*/receipt.json')):
 name=path.parent.name;receipt=read(path)
 for item in (receipt['object'],receipt['process'],receipt['dependencies']):exact(item)
 process=read(receipt['process']['path']);terminal(process);assert process['exit']==0
 proofs=[]
 for item in receipt['source_identities']:
  original=Path(item['path'])
  if original.is_file() and pin(original)==item:proofs.append(dict(identity=item,status='CURRENT_EXACT'))
  else:
   relative=original.relative_to(R)
   previous=subprocess.check_output(['git','show',baseline['base_commit']+':'+relative.as_posix()],cwd=R)
   assert len(previous)==item['bytes'] and hashlib.sha256(previous).hexdigest()==item['sha256'],str(original)
   target=W/'source-historical'/name/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(previous)
   proofs.append(dict(identity=item,status='HISTORICAL_EXACT_BASELINE_SOURCE',snapshot=pin(target)))
 receipts[name]=dict(receipt=pin(path),object=receipt['object'],source_pin_count=len(receipt['source_identities']),
  all_source_pins_current=all(row['status']=='CURRENT_EXACT' for row in proofs))
 source_proofs.append(dict(unit=name,sources=proofs))
save(W/'source-receipt-proofs.json',source_proofs)
assert {'cold','cli','tiny','rows','session','session-fixed','baseline-session','baseline-session-fixed'}==set(receipts)
rows=read(receipts['rows']['receipt']['path'])['source_identities']
assert not any(norm(item['path'])==norm(R/'engine/models/qwen35/main.cc') for item in rows)
assert any(norm(item['path'])==norm(R/'engine/models/qwen35/session_state.h') for item in rows)
assert any(norm(item['path'])==norm(R/'engine/models/qwen35/graph_builder.h') for item in rows)

attempts=[];checks=[];failures=[]
for directory in ('compile','link','runs'):
 for path in sorted((W/directory).rglob('process.json')):
  process=read(path);terminal(process)
  row=dict(name=path.parent.relative_to(W).as_posix(),process=pin(path),actual=process,
   command=pin(path.parent/'command.json'))
  attempts.append(row)
  if process['exit']:
   failures.append(dict(**row,stdout=pin(path.parent/'stdout.log'),stderr=pin(path.parent/'stderr.log')))
  elif directory=='runs':
   report=read(path.parent/'report.json')
   assert report.get('status','PASS') in ('PASS','MTP_SESSION_PROBE_COMPLETED')
   checks.append(dict(**row,report=pin(path.parent/'report.json')))
assert len([row for row in attempts if row['name'].startswith('compile/')])==8
assert len(failures)==2 and all('session-cuda/attempt1' in row['name'] for row in failures)

whole=read(W/'whole-cli-summary.json');assert whole['status']=='PASS_ALL_FOUR_DEFAULT_CASES'
assert len(whole['checks'])==4 and all(row['all_non_timing_fields_equal'] and not row['differences'] for row in whole['checks'])
attribution=read(W/'session-pre-split-attribution.json')
assert attribution['status']=='PREEXISTING_IDENTICAL_BEFORE_SESSION_CREATION'
assert attribution['facts']['baseline']==attribution['facts']['candidate']
fixed=read(W/'session-fixed-source-proof.json')
assert fixed['candidate_probe']==pin(fixed['candidate_probe']['path'])
assert fixed['candidate_probe']['sha256']==fixed['baseline_probe']['sha256']
assert fixed['baseline_inline_main']['sha256']==fixed['original_inline_main']['sha256']

# Full arrays are compared without numerical tolerances and hashed before
# cleanup. Keep original numerical vector observations, but no raw payload ZIP.
vectors={};observations={}
for arm in ('baseline','candidate'):
 folder=W/'runs'/arm/'session-cuda/attempt2/vectors'
 observation=read(folder/'observation.json');observations[arm]=observation
 assert observation['status']=='PASS_BYTE_EXACT' and observation['all_vectors_byte_equal'] and observation['all_finite']
 assert observation['numerical_tolerance_policy'] is None and observation['final_live_snapshot_versions']==0
 assert observation['managed_backing_bytes']==observation['planned_backing_bytes']==80240691
 assert observation['idle_head_full_byte_checks']==4 and observation['A_calls_after_B_stop']==3
 for row in observation['vectors']:
  assert row['byte_equal'] and row['max_abs']==0 and row['squared_error']==0
  assert row['nonfinite_baseline']==row['nonfinite_actual']==0
 inventory={}
 for path in sorted(folder.rglob('*')):
  if path.is_file() and path.suffix in ('.f32','.bf16','.f16','.bin'):
   inventory[path.relative_to(folder).as_posix()]=pin(path)
 assert inventory
 vectors[arm]=inventory
assert vectors['baseline'].keys()==vectors['candidate'].keys()
for name in vectors['baseline']:
 first,second=(vectors[arm][name] for arm in ('baseline','candidate'))
 assert first['bytes']==second['bytes'] and first['sha256']==second['sha256'],name
 assert Path(first['path']).read_bytes()==Path(second['path']).read_bytes(),name
def normalized_paths(value,arm):
 if isinstance(value,str):return value.replace(str(W/'runs'/arm/'session-cuda/attempt2/vectors'),'{VECTORS}')
 if isinstance(value,list):return [normalized_paths(x,arm) for x in value]
 if isinstance(value,dict):return {k:normalized_paths(v,arm) for k,v in value.items()}
 return value
assert normalized_paths(observations['baseline'],'baseline')==normalized_paths(observations['candidate'],'candidate')
save(W/'session-vector-manifest.json',dict(status='PASS_EXACT_COMPLETE_VECTOR_BYTES',arms=vectors,
 file_count_per_arm=len(vectors['candidate']),all_cross_arm_bytes_identical=True,numerical_tolerance=None,
 bytes_per_arm=sum(row['bytes'] for row in vectors['candidate'].values()),
 metadata_equal_except_output_root=True,original_numerical_observations='Retained original observation.json files include everyvector maxabs/squarederror/nonfinite and same-model interleaved/idle comparisons.',
 scope='All exported logical complete target/draft KV,GDN,conv,carry/prior,logits/hidden arrays retained as hashes and exact numerical evidence; raw binary payload excluded from archive.'))

review_root=R/'.scratch/inference-graph-builder-review-20261030'
review=read(review_root/'static-review.json');assert review['status']=='STATIC_EXTRACTION_REVIEW_PASSED_NOT_NATIVE_VALIDATION'
for item in review['source_pins']:exact(item)
guard=read(review_root/'cmake-guard/result.json');assert guard['status']=='FOUR_EXACT_GUARD_CONFIGURE_FIXTURES_PASSED'
reference=read(review_root/'reference-boundaries.json')
assert sum(len(row['files']) for row in reference.values())==9
for value in reference.values():
 for item in value['files']:assert item['HEAD_content_equal_normalized_line_endings']
external=[]
for directory in (review_root,R/'.scratch/inference-cold-recipe-extract-20261030'):
 for path in sorted(directory.rglob('*')):
  if path.is_file() and path.suffix in ('.json','.txt','.md','.cc','.h','.log') and 'CMakeFiles' not in path.parts and path.name!='CMakeCache.txt':
   target=W/'external-evidence'/directory.name/path.relative_to(directory)
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes());external.append(pin(target))

sources=['engine/models/qwen35/main.cc','engine/models/qwen35/graph_builder.h','engine/models/qwen35/graph_builder.cc',
 'engine/models/qwen35/cold_sources.cmake','engine/models/qwen35/CMakeLists.txt','tests/CMakeLists.txt',
 'tests/tools/qwen_draft_vocabulary_probe.cc','engine/models/qwen35/mtp_session_probe.cc']
for relative in sources:
 target=W/'source-current'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/relative).read_bytes())
(W/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','engine','tests'],cwd=R))
model_base=read(W/'model-link-base.json');assert len(model_base['retained'])==228
for item in model_base['retained']:exact(item)
assert model_base['retained'][-1]==receipts['cold']['object']
summary=dict(schema='hyle.inference-cold-model-boundary.v1',date='2026-10-30',
 status='PASS_FINITE_COLD_GRAPH_BUILDER_BOUNDARY',base_commit=baseline['base_commit'],full_goal_complete=False,
 sources=[pin(R/path) for path in sources],baseline=pin(W/'baseline-plan.json'),candidate=pin(W/'plan.json'),
 receipts=receipts,source_proofs=pin(W/'source-receipt-proofs.json'),model_link_base=pin(W/'model-link-base.json'),
 compile_closure=dict(original_SDK_inputs=227,unchanged_SDK_inputs=227,new_cold_model_objects=1,new_closure_inputs=228,
  SDK_CXX=0,NVCC=0,downloads=0,candidate_initial_consumers=4,extra_Session_diagnostic_TUs=3,actual_CXX_attempts=8,
  baseline_CLI_CXX=0,ABI='Pre-split CLI227-input closure and inline Sessiondiagnostics stay separate. Current split consumers link matching new coldobject plus unchanged227; oldinclude-main objects are historical, no mixed inline/outofline Recipe program.'),
 checks=checks,all_process_attempts=attempts,failed_native_attempts=failures,
 whole_default_four_cases=whole,whole_comparison_scope='Exactly8 current/baseline processes,defaultfullV greedy CUDA ordinary/MTP single64/two128. All non-timing reports equal; process timing only finite obvious-regression diagnostics, no speedup claim.',
 Session_probe_fix=dict(attribution=pin(W/'session-pre-split-attribution.json'),source_proof=pin(W/'session-fixed-source-proof.json'),
  prior_error='Both pre-split and split consumers refused before any Session because firstobserve compared KV-only2064398 against completeplan80240691.',
  change='Canonical prepare_state_storage beforefullplanobserve; payload=cacheusage.live−metadata remains strictly equal known_cache_backing andplan, total<=limit andsnapshotbounds retained. No model math/work/Head/RNG/EOS/Prefix/Resume algorithms changed.',
  corrected_baseline_and_candidate_pass=True,vectors=pin(W/'session-vector-manifest.json')),
 static_extraction_review=pin(review_root/'static-review.json'),reference_boundaries=pin(review_root/'reference-boundaries.json'),
 CMake_guard_fixture=pin(review_root/'cmake-guard/result.json'),external_artifacts=external,
 independent_cold_consumer=dict(source_pin_count=len(rows),receipt=receipts['rows']['receipt'],main_cc_included=False,
  actual_remaining_transitive_edge='graph_builder.h -> weights.h -> session_state.h for CacheRowBytes/cachePlan/checkedcachemath; this slice does NOT remove runtimeSnapshot/cacheState header parsing.',
  object_borrows='No Model/Session/GenerationLedger object dependency added. Only original Tensor/Backend/Graph geometry/weight/lease facts.'),
 propagation=dict(old_main_include_edges=16,original_canonical_main_TU=1,current_main_include_edges=15,
  private_cold_edit='Only graph_builder.cc source object per instantiatedtarget plus relink,not15heavyinclude-main TUs/canonicalmain. Not one globalsharedobject,not fullmodel isolation.'),
 limits=['This is a model-local first compiled graph-construction boundary, not completed overallcrossmodelarchitecture or universalRecipe.',
  'Sharedstepdriver,resource/retirementauthority,modelmath,operation/portorder,dtype/shape andborrowedliteralowners preserved.48bodytokenproof plus layouts/defaults/templates review retained.',
  'CMake predicate fixtures evaluate exactguard with NONE-language targets: no full SDK/CMakebuild/install or allplatform claim.',
  'Session fix is a reproduced pre-existing diagnosticfixture accounting issue. Corrected baseline andcandidate receive identical strictprobe body and separate original/new closures.',
  'No performance candidate,Nsightprofile,download,new reference build or formalTPSwindow. EightCLI process times only detect obvious issues; no stable speedup claim.',
  'Rows stilltransitively includes session_state.h. Nextmodule task separate coldcachePlan/rowbytes/checkedmathfacts fromruntimeSnapshot/State; keep originalmechanisms. Familyfactory/recovery seams remain beyondthisslice.',
  'Local llama.cpp23b0202a andTensorRT-LLM46d9966b listed9files verifiedagainstactualHEAD; not latestupstream or allenginesidenticalfileorganization. Their dynamic/virtualinterfaces are not copied.'])
save(W/'summary-draft.json',summary)

extensions={'.py','.json','.jsonl','.log','.xml','.txt','.md','.cc','.h','.cmake','.patch','.ids'}
files=set()
for path in W.iterdir():
 if path.is_file() and path.suffix in extensions and path.name not in ('archive-draft.json','retention-manifest.json'):files.add(path)
for directory in ('compile','link','runs','baseline-source','baseline-model','baseline-model-fixed','source-current',
 'source-historical','external-evidence','session-input','metadata-cpu','metadata-cuda'):
 for path in (W/directory).rglob('*'):
  if path.is_file() and path.suffix in extensions:files.add(path)
manifest=[dict(member=path.relative_to(W).as_posix(),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in sorted(files)]
save(W/'retention-manifest.json',dict(members=manifest,excluded='EXE/OBJ/PDB/DLL/LIB/EXP,SDK/vendor/model payloads and raw Session vector binaries. Allvector hashes/exactcomparison metadata and source/commands/process reports retained.'))
files.add(W/'retention-manifest.json');archive=W/'evidence-draft.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for path in sorted(files):z.write(path,path.relative_to(W).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in manifest:
  body=z.read(item['member']);assert len(body)==item['bytes'] and hashlib.sha256(body).hexdigest()==item['sha256']
save(W/'archive-draft.json',dict(archive=pin(archive),members=len(files),all_member_bytes_sha256_verified=True,
 summary=pin(W/'summary-draft.json'),model_link_base=pin(W/'model-link-base.json'),vectors=pin(W/'session-vector-manifest.json')))
print(json.dumps(dict(status=summary['status'],checks=len(checks),failed_native=len(failures),archive_bytes=archive.stat().st_size,
 archive_members=len(files),vector_files_per_arm=len(vectors['candidate']),rows_source_pins=len(rows))))
