$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
if ([IO.Path]::GetFileName($PSScriptRoot) -eq 'hyle') { $workspace = [IO.Path]::GetFullPath($PSScriptRoot) }
$batch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-cold-model-boundary-20261030'))
$manifest = Get-Content -LiteralPath (Join-Path $batch 'cleanup-targets.json') -Raw | ConvertFrom-Json
if ($manifest.workspace -cne $workspace -or $manifest.batch -cne $batch) { throw 'Unexpected cleanup boundary' }
$expectedRoots = @('bin','runs/baseline/session-cuda/attempt2/vectors','runs/candidate/session-cuda/attempt2/vectors')
$roots = @($manifest.roots)
if ($roots.Count -ne 3) { throw 'Unexpected root count' }
for ($i=0; $i -lt 3; $i++) {
  if ([IO.Path]::GetFullPath($roots[$i]) -cne [IO.Path]::GetFullPath((Join-Path $batch $expectedRoots[$i]))) { throw 'Unexpected exact root' }
}
$targets = @($manifest.targets)
if ($targets.Count -ne 781) { throw 'Unexpected exact target count' }
$total = [long]0
foreach ($pin in $targets) {
  $target = [IO.Path]::GetFullPath($pin.path)
  $inScope = $false
  foreach ($root in $roots) { if ($target.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { $inScope = $true } }
  if (-not $inScope) { throw ('Target escaped exact images/vectors roots: ' + $target) }
  $item = Get-Item -LiteralPath $target
  if ($item.PSIsContainer -or $item.Length -ne $pin.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pin.sha256) { throw ('Changed target: ' + $target) }
  $total += $item.Length
}
if ($total -ne 1445752493) { throw 'Unexpected exact bytes' }
foreach ($pin in $targets) { Remove-Item -LiteralPath $pin.path -Force }
$report = @{status='REMOVED_EXACT_RECREATABLE_IMAGES_AND_SESSION_PAYLOADS';files=$targets.Count;bytes=$total;retained='Verified archive and full vector hashes/metadata; SDK/model objects, runtime originals, sources, inputs, commands and reports'}
$report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $batch 'cleanup-report.json') -Encoding utf8
$report | ConvertTo-Json
