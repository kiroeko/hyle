"""Run only the two explicitly authorized corrected original Session probes."""
from pathlib import Path
import importlib.util,os,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('cold_session_run',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
for arm,name in [('baseline','baseline-session-fixed'),('candidate','session-fixed')]:
 image=b.read(W/('ready-'+name+'.json'));b.exact(image)
 folder=W/'runs'/arm/'session-cuda/attempt2';b.save(folder/'image.json',image)
 args=['--backend','cuda','--inputs',str(W/'session-input'),'--output',str(folder/'vectors'),'--scenario','sessions']
 b.s.b.execute([image['path'],*args],folder,600)
 result=b.read(folder/'stdout.log');assert result['status']=='MTP_SESSION_PROBE_COMPLETED'
 observation=b.read(folder/'vectors/observation.json');assert observation['status'].startswith('PASS')
 assert observation['final_live_snapshot_versions']==0 and observation['idle_head_full_byte_checks']>0 and observation['A_calls_after_B_stop']>0
 b.save(folder/'report.json',result);print('PASS fixed session',arm,flush=True)
