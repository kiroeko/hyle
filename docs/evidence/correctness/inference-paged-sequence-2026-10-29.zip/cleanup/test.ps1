﻿$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-paged-sequence-20261029'
$ExpectedRoots = @(
    'C:\public\project-hyle\hyle\.scratch\inference-paged-sequence-20261029\bin',
    'C:\public\project-hyle\hyle\.scratch\inference-full-hit-retry-20261029\compile\consumer',
    'C:\public\project-hyle\hyle\.scratch\inference-full-hit-retry-20261029\compile\host-image',
    'C:\public\project-hyle\hyle\.scratch\inference-cold-bindings-20261029\compile\weights'
)
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$AllowedRoots = @($Plan.allowed_roots | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') })
if ($AllowedRoots.Count -ne 4 -or @($AllowedRoots | Where-Object { $_ -notin $ExpectedRoots }).Count) { throw 'Unexpected cleanup roots' }
foreach ($Receipt in Get-ChildItem -LiteralPath $TaskRoot -Filter 'process.json' -File -Recurse) {
    $Fact = Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json
    if ($Fact.state -ne 'TERMINAL') { throw "Original native process is not terminal: $($Receipt.FullName)" }
}
$Current = Get-Content -LiteralPath (Join-Path $TaskRoot 'model-link-base.json') -Raw | ConvertFrom-Json
$Protected = @($Current.retained.path) + @($Current.runtime.path)
foreach ($Target in $Plan.targets) {
    $Resolved = [IO.Path]::GetFullPath($Target.path)
    if ([IO.Path]::GetDirectoryName($Resolved) -notin $AllowedRoots -or $Resolved -in $Protected) { throw "Outside exact cleanup scope: $Resolved" }
    $Item = Get-Item -LiteralPath $Resolved
    if ($Item.PSIsContainer -or $Item.Length -ne $Target.bytes) { throw "Changed cleanup target: $Resolved" }
    if ((Get-FileHash -LiteralPath $Resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Target.sha256) { throw "Changed cleanup hash: $Resolved" }
}
$Removed = @()
foreach ($Target in $Plan.targets) {
    Remove-Item -LiteralPath $Target.path -Force
    $Removed += [pscustomobject]@{ path=$Target.path; bytes=$Target.bytes; removed=(-not (Test-Path -LiteralPath $Target.path)) }
}
if (@($Removed | Where-Object { -not $_.removed }).Count) { throw 'Cleanup incomplete' }
[pscustomobject]@{ status='PASS'; files=$Removed.Count; bytes=($Removed | Measure-Object bytes -Sum).Sum; removed=$Removed } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-result.json') -Encoding utf8
Write-Output "Removed $($Removed.Count) checked reconstructible binary files."
