from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value): Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
        sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest())

plan = read(W / 'plan.json')
for name in plan['units']:
    receipt = read(W / 'compile' / name / 'receipt.json')
    assert pin(receipt['object']['path']) == receipt['object']
    for item in receipt['source_identities']: assert pin(item['path']) == item
for item in plan['retained']: assert pin(item['path']) == item
for field in ('runtime', 'sdk'): assert pin(plan[field]['path']) == plan[field]

results = []
for name, case in plan['cases'].items():
    folder = W / 'runs' / name / 'attempt1'
    process, report = read(folder / 'process.json'), read(folder / 'report.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    assert report['status'] == 'PASS'
    results.append(dict(case=name, process=process, report=report))

builds = []
for file in sorted((W / 'compile').glob('*/*/process.json')):
    builds.append(dict(unit=file.parent.parent.name, attempt=file.parent.name, process=read(file)))
links = [dict(unit=file.parent.parent.name, attempt=file.parent.name, process=read(file))
    for file in sorted((W / 'link').glob('*/*/process.json'))]
assert len(builds) == 9 and sum(x['process']['exit'] != 0 for x in builds) == 2
assert len(links) == 6 and all(x['process']['exit'] == 0 for x in links)

sources = subprocess.check_output(['git', 'diff', '--name-only', '--', 'engine', 'tests'], cwd=R, text=True).splitlines()
sources += ['engine/inference/paged_sequence.h', 'tests/tools/inference_paged_sequence_test.cc']
source_pins = [pin(R / name) for name in sorted(set(sources))]
current = read(W / 'compile/budget/receipt.json')
save(W / 'model-link-base.json', dict(schema='hyle.paged-sequence.current-link-base.v1', base=plan['base'],
    compile=plan['units']['budget']['compile'], link=plan['units']['budget']['link'],
    consumer_source=pin(plan['units']['budget']['source']), previous_consumer=pin(W / 'compile/budget/receipt.json'),
    retained=plan['retained'], runtime=plan['runtime'], sdk_engine_dependencies=plan['sdk'],
    source_freeze=[p for p in current['source_identities'] if '.scratch' not in Path(p['path']).relative_to(R).parts]))

summary = dict(schema='hyle.correctness.paged-sequence.v1', date='2026-10-29',
    status='PASS_WITH_PRESERVED_BUILD_AND_HARNESS_CORRECTIONS', base_commit=plan['worktree_base_commit'],
    sources=source_pins,
    changes=[
        'Move original policy-page inventory/ref/reservation and original frame fork/freeze/source/commit into model-independent paged_sequence.h; remove Qwen duplicate implementation without aliases.',
        'Each policy ID spans an arbitrary cohort of original arena banks. Shared state has no K/V pairing, model layer, GDN, NextN, duplicated row count or frontier.',
        'Qwen ordinary/successor target, fused draft and private recursive NextN use original shared edits. Model keeps complete Head/ledger/RNG publication and semantic lengths/lag/hidden.',
        'Original Arena/Frame/Append/Store permissions and actual retirement remain authoritative. Borrowed edits do not create another executor, completion, state owner or hot callback table.',
        'Unavailable inventory scan preserves original selection/order using one final rotation instead of per-page vector insertions; partial native writers release before policy reuse.'
    ],
    counts=dict(consumer_TUs=6, refreshed_engine_weights_TUs=1, CXX_attempts=9, successful_CXX=7,
        preserved_compile_failures=2, links=6, unchanged_SDK_inputs=226, current_link_inputs=227,
        NVCC=0, full_builds=0, downloads=0, native_processes=9, passed_native_processes=9,
        new_actual_Graph_tests=2, current_session_prefix_tests=14, finite_model_processes=7),
    build_corrections=[
        dict(unit='sequence', attempt='attempt1', kind='new_test_compile_error',
            detail='Const bank traversal called the original nonconst writer lease accessor; change traversal qualification, preserve all native assertions.'),
        dict(unit='model', attempt='attempt1', kind='generated_consumer_include_error',
            detail='Bounded generated consumer omitted the original chunked-prefill helper namespace dependency; include the existing helper, no product change.'),
        dict(case='prefix-cpu', attempt='attempt1', kind='harness_expected_count_error',
            detail='Native exit0 and XML14/14 passed. Harness expected16; correct expectation and recheck the same original XML, no native rerun.')],
    builds=builds, links=links, results=results,
    current_link_base=pin(W / 'model-link-base.json'), sdk_engine_dependencies=plan['sdk'],
    fixture_metadata=dict(conditional=plan['fixtures']['conditional'], natural=plan['fixtures']['natural'],
        ordinary=plan['ordinary_fixture'], cpu=dict(directory=plan['cpu_fixture'],
            manifest=pin(Path(plan['cpu_fixture']) / 'weights.tsv'), prompt=pin(Path(plan['cpu_fixture']) / 'prompt.ids'))),
    limitations=[
        'Finite CPU/CUDA checks on the existing machine; no new Apple/Vulkan run, multi-device implementation, device fault injection or complete family engine claim.',
        'Single-bank real Graph demonstrates a non-NextN/non-GDN consumer. Pure-GDN zero-target-bank path was read-reviewed, not a separate native model process in this batch.',
        'Ragged/packed and exact math retain original tolerances; numerical equivalence is not universal byte equality. Trained2B natural relay checks the original two paths, not general model task quality.',
        'No current throughput or full memory window; prior complete performance numbers remain dated2026-10-28. Architecture extraction alone is not evidence of faster decode.',
        'Full preparation/publication orchestration and Source/ordinary/successor contract convergence remain unfinished.'
    ])
summary_file = R / 'docs/evidence/correctness/inference-paged-sequence-2026-10-29.json'
save(summary_file, summary)
archive = summary_file.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.write(summary_file, 'summary.json')
    for name in sorted(set(sources)):
        z.write(R / name, 'sources/' + name)
    z.writestr('product.patch', subprocess.check_output(['git', 'diff', '--', 'engine', 'tests'], cwd=R))
    selected = [p for p in W.rglob('*') if p.is_file() and (
        p.suffix in ('.json', '.py', '.cc', '.h', '.xml', '.log')) and 'ordinary-input' not in p.relative_to(W).parts]
    for file in sorted(selected): z.write(file, 'batch/' + file.relative_to(W).as_posix())
    for helper in ('inference-multimodel-observation-20261029/build.py', 'inference-program-identity-20261029/build.py'):
        z.write(R / '.scratch' / helper, 'helpers/' + helper)
    for file in (W / 'ordinary-input').iterdir(): z.write(file, 'batch/ordinary-input/' + file.name)
save(W / 'archive.json', pin(archive))
print('Evidence saved: 9 current native processes passed; archive bytes', archive.stat().st_size)
