"""One shared lifecycle, bounded real consumers; retained native SDK/cache."""
from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-multimodel-observation-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = W
b.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    base_path = R / '.scratch/inference-full-hit-retry-20261029/model-link-base.json'
    base = read(base_path)
    assert len(base['retained']) == 227
    for item in base['retained']: exact(item)
    exact(base['runtime'])
    sdk = read(base['sdk_engine_dependencies']['path'])
    weights = next(u for u in sdk['engine_consumers'] if any(
        key(p['path']) == key(R / 'engine/models/qwen35/weights.cc') for p in u['source_identities']))
    changed = []
    for unit in sdk['engine_consumers']:
        for item in unit['source_identities']:
            if key(item['path']) == key(R / 'engine/models/qwen35/session_state.h'):
                changed.append(dict(before=item, after=pin(item['path'])))
            else: exact(item)
    assert len(changed) == 1
    old_object = read(base['previous_consumer']['path'])['object']['path']
    units = {}
    for name, source in [
        ('sequence', R / 'tests/tools/inference_paged_sequence_test.cc'),
        ('prefix', R / 'tests/tools/qwen_prefix_cache_test.cc'),
        ('model', W / 'model_consumer.cc'),
        ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc'),
        ('host-image', W / 'host_image_consumer.cc'),
        ('budget', W / 'budget_consumer.cc'),
        ('weights', R / 'engine/models/qwen35/weights.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index-1].lower() == '/sourcedependencies': arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(base['consumer_source']['path']): arg = str(source)
            args.append(arg)
        units[name] = dict(source=str(source), compile=args)
        if name == 'weights': continue
        link = []
        for arg in base['link']:
            if key(arg) == key(old_object): arg = str(folder / 'unit.obj')
            elif key(arg) == key(weights['object']): arg = str(W / 'compile/weights/unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / name).with_suffix(suffix)); break
            link.append(arg)
        if name in ('sequence', 'prefix'):
            for lib in ('gtest_main.lib', 'gtest.lib'):
                path = R / '.scratch/build-compute-v2-dev/lib' / lib
                if not any(key(a) == key(path) for a in link): link.append(str(path))
        assert sum(key(a) == key(source) for a in args) == 1
        assert sum(key(a) == key(folder / 'unit.obj') for a in link) == 1
        units[name]['link'] = link
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    fixtures = read(R / '.scratch/inference-paged-layout-20261029/plan.json')['fixtures']
    for fixture in (fixtures['conditional'], fixtures['natural']):
        exact(fixture['manifest']); exact(fixture['prompt'])
    ordinary = W / 'ordinary-input'
    ordinary.mkdir(exist_ok=True)
    for file in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(R / '.scratch/inference-paged-layout-20261029/ordinary-input' / file, ordinary / file)
    tiny = read(R / '.scratch/inference-full-hit-retry-20261029/plan.json')['fixture']
    conditional = fixtures['conditional']['directory']
    cases = {
        'sequence-cpu': dict(unit='sequence', filter='InferencePagedSequence.*', tests=2),
        'prefix-cpu': dict(unit='prefix', filter='QwenSessionState.*:QwenPrefixCache.*', tests=16),
        'history-cpu': dict(unit='model', args=['history', 'cpu', conditional]),
        'mixed-lag-cuda': dict(unit='model', args=['mixed-lag', 'cuda', conditional]),
        'mtp-ragged-cuda': dict(unit='model', args=['ragged', 'cuda', conditional]),
        'mtp-natural-cuda': dict(unit='model', args=['natural', 'cuda', fixtures['natural']['directory']]),
        'ordinary-cuda': dict(unit='ordinary', args=['--cuda-continuous', str(ordinary)]),
        'host-image-cpu': dict(unit='host-image', args=[tiny]),
        'budget-cpu': dict(unit='budget', args=[tiny])}
    save(W / 'plan.json', dict(base=pin(base_path), worktree_base_commit=subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), units=units,
        retained=base['retained'], runtime=base['runtime'], sdk=base['sdk_engine_dependencies'],
        original_weights=weights['object'], changed_SDK_source=changed, fixtures=fixtures,
        ordinary_fixture=dict(manifest=pin(ordinary / 'weights.tsv'), prompt=pin(ordinary / 'prompt.ids')),
        cpu_fixture=tiny, cases=cases,
        scope='Six bounded consumers and one refreshed engine weights TU; 226 native SDK inputs unchanged. No NVCC, downloads or throughput claim.'))
    print('Prepared six consumer TUs + one refreshed engine weights TU; nine finite processes, native SDK retained.')


def seal_sdk():
    plan = read(W / 'plan.json')
    receipt = b.receipt('weights')
    sdk = read(plan['sdk']['path'])
    unit = next(u for u in sdk['engine_consumers'] if key(u['object']) == key(plan['original_weights']))
    unit.update(object=receipt['object']['path'], source_identities=receipt['source_identities'],
        engine_dependencies=[p['path'] for p in receipt['source_identities'] if Path(p['path']).is_relative_to(R / 'engine')],
        original_receipt=pin(W / 'compile/weights/receipt.json'),
        dependencies=pin(W / 'compile/weights/dependencies.json'))
    save(W / 'sdk-engine-dependencies.json', sdk)
    plan['retained'] = [p for p in plan['retained'] if key(p['path']) != key(plan['original_weights'])] + [receipt['object']]
    assert len(plan['retained']) == 227
    plan['sdk'] = pin(W / 'sdk-engine-dependencies.json')
    save(W / 'plan.json', plan)
    print('Sealed refreshed engine weights object; retained 226 unchanged SDK inputs.')


def run(name, attempt):
    plan = read(W / 'plan.json')
    case = plan['cases'][name]
    b.receipt(case['unit'])
    b.receipt('weights')
    image = read(W / ('ready-' + case['unit'] + '.json'))
    exact(image)
    folder = W / 'runs' / name / attempt
    args = case.get('args', [])
    if 'filter' in case:
        args = ['--gtest_color=no', '--gtest_filter=' + case['filter'], '--gtest_output=xml:' + str(folder / 'results.xml')]
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    save(folder / 'image.json', image)
    b.b.execute([image['path'], *args], folder, 300)
    if 'filter' in case:
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors', '0') == '0'
        assert not result.findall('.//skipped')
        report = dict(status='PASS', tests=case['tests'], failures=0, skipped=0)
    else:
        report = read(folder / 'stdout.log')
        assert report['status'] == 'PASS'
    save(folder / 'report.json', report)
    print('PASS', name)


action = sys.argv[1]
if action == 'prepare': prepare()
elif action == 'seal-sdk': seal_sdk()
elif action in ('compile', 'link'):
    if action == 'compile':
        attempt = sys.argv[3] if len(sys.argv) > 3 else 'attempt1'
        folder = W / 'compile' / sys.argv[2] / attempt
        folder.mkdir(parents=True, exist_ok=True)
        for relative in ('engine/inference/paged_sequence.h', 'engine/models/qwen35/session_state.h', 'engine/models/qwen35/main.cc'):
            shutil.copyfile(R / relative, folder / Path(relative).name)
    b.main()
elif action == 'run': run(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else 'attempt1')
else: raise ValueError(action)
