#include "../../engine/models/qwen35/main.cc"
#include "qwen_host_image_case.h"
#include "qwen_state_reuse_case.h"
#include "qwen_mtp_batch_state_case.h"
#include "qwen_packed_prefill_case.h"
#include "qwen_ragged_prefill_case.h"
#include "qwen_mtp_packed_prefill_case.h"
#include "qwen_mtp_ragged_prefill_case.h"
#include "qwen_logits_preflight_case.h"
#include "qwen_mtp_stop_case.h"
#include "qwen_mtp_sampling_case.h"
#include "qwen_mtp_logits_case.h"
#include "qwen_mtp_e4_case.h"
#include "inference_history_math_case.h"
#include "qwen_history_logits_case.h"
#include "qwen_history_replay_case.h"
#include "qwen_history_control_case.h"
#include "qwen_mtp_mixed_lag_case.h"
#include "qwen_mtp_natural_relay_case.h"

int main(int argc, char **argv) {
  try {
    if (argc != 4) throw std::runtime_error("usage: sequence_model_test case cpu|cuda prepared_input_directory");
    const std::string_view name(argv[1]), backend(argv[2]);
    if (backend != "cpu" && backend != "cuda") throw std::runtime_error("unsupported test backend");
    const auto kind = backend == "cpu" ? qwen35::BackendKind::kCpu : qwen35::BackendKind::kCuda;
    if (name == "history") return qwen_history_control_case::run(argv[3], kind);
    if (name == "mixed-lag") return qwen_mtp_mixed_lag_case::run(argv[3], kind);
    if (name == "ragged") return qwen_mtp_ragged_prefill_case::run(argv[3], kind);
    if (name == "natural") return qwen_mtp_natural_relay_case::run(argv[3], kind);
    throw std::runtime_error("unknown test case");
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n'; return 1;
  }
}
