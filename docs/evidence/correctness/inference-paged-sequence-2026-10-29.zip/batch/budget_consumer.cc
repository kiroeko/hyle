#include "../../engine/models/qwen35/main.cc"
#include "../../engine/inference/output_delivery.h"
#include "../../tests/tools/qwen_sampling_budget_case.h"

int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("usage: full_hit_retry_test prepared_input_directory");
    return qwen_sampling_budget_case::run(argv[1]);
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n'; return 1;
  }
}
