#include "../compute_models/ct_packed_graph_fixture.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"

namespace {
namespace f = ct_packed_graph_test;
// The actual process-lifetime system resource needs no separate native owner.
// StorageOwner still retains this original CPU Context and allocator contract.
struct SystemResource final {
  f::m::MemoryResourceRef ref() noexcept { return f::m::system_resource(); }
};
struct Backend final {
  static constexpr bool supports_capture = false;
  static constexpr auto provider_id = f::c::native::kProviderId;
  static f::c::Context create_context() {
    return f::take(f::g::cpu::create_context(), "CPU Context");
  }
  static f::c::StorageOwner create_owner(const f::c::Context &context) {
    return f::take(f::c::StorageOwner::adopt(context, SystemResource{}), "CPU StorageOwner");
  }
  static hyle::Result<f::g::CompiledGraph> compile(const f::g::Graph &graph,
      const f::c::Context &context, const f::c::StorageOwner &,
      f::g::CompileOptions options = {}) noexcept {
    return f::g::cpu::compile(graph, context, options);
  }
  static hyle::Status prepare(f::g::Invocation &slot, f::c::Queue &queue,
      bool capture) noexcept {
    if (capture) return hyle::Status::InvalidArgument("CPU fixture has no capture backend");
    const std::array queues{f::g::QueueBinding{f::g::ExecutionLaneId{0}, &queue}};
    return slot.prepare_replay(queues,
        {.mode = f::g::ReplayMode::kCommands, .host_wait = f::g::HostWaitPolicy::kAllow});
  }
};

TEST(CpuCtPackedLinear, PublicChainsKeepSourceRoundsAndTypedCastWitnesses) {
  f::PublicChainsKeepSourceRoundsAndTypedCastWitnesses<Backend>();
}

TEST(CpuCtPackedLinear, CapturedDynamicInputsRebindAcrossOwnedSlotsAndRetainResults) {
  f::CapturedDynamicInputsRebindAcrossOwnedSlotsAndRetainResults<Backend>();
}

TEST(CpuCtPackedLinear, PublishedViewAndControlEscapesExecuteTheOriginalDecomposition) {
  f::PublishedViewAndControlEscapesExecuteTheOriginalDecomposition<Backend>();
}

TEST(CpuCtPackedLinear, OriginalPackedConstantsDoNotRetainOrWorkspaceADenseWeightBank) {
  f::OriginalPackedConstantsDoNotRetainOrWorkspaceADenseWeightBank<Backend>();
}
} // namespace
