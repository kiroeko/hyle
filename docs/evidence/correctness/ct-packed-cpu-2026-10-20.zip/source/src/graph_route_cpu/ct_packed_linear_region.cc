#include "ct_packed_linear_region.h"

#include "../graph/ct_packed_region.h"
#include "hyle/compute/providers/native.h"

namespace hyle::graph::cpu::internal {
namespace {
const compute::detail::ProviderVTable &original() noexcept {
  return *compute::detail::ProviderAccess::vtable(compute::native::provider());
}
}
compute::Provider ct_packed_regions(compute::Provider provider) noexcept {
  return graph::detail::CtPackedRegion<&original>::decorate(std::move(provider));
}
} // namespace hyle::graph::cpu::internal
