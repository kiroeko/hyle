from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time,sys
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=Path(__file__).resolve().parent;out=S/'checks'/('attempt'+(sys.argv[1] if len(sys.argv)>1 else '1'));out.mkdir(parents=True,exist_ok=True)
def ident(path):
 p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(path,x):path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();r=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '='in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
jobs=[('native-provider','src/compute_provider_native/native_provider.cc','nvfp4-reference-linear/cpu/native_provider-identity.json'),('ct-packed','src/compute_provider_native/ct_packed.cc','nvfp4-reference-linear/cpu/native_provider-identity.json'),('test','tests/compute_provider_native/ct_packed_test.cc','nvfp4-reference-linear/cpu/workspace-alias-test-identity.json')]
def compile_one(job):
 name,source,recipe=job;source=R/source;recipe=A/recipe;old=json.loads(recipe.read_bytes())['command'];base=[];skip=False
 for arg in old:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd'))or arg.lower().endswith(('.cc','.cpp')):continue
  base.append(arg)
 obj=out/(name+'.obj');dep=out/(name+'-deps.json');command=base+['/sourceDependencies',str(dep),str(source),'/Fo'+str(obj),'/Fd'+str(out/(name+'.pdb'))]
 save(out/(name+'-command.json'),dict(command=command,source=ident(source),recipe=ident(recipe)))
 start=time.time();r=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
 (out/(name+'.stdout.log')).write_text(r.stdout,encoding='utf-8');(out/(name+'.stderr.log')).write_text(r.stderr,encoding='utf-8');save(out/(name+'-result.json'),dict(exit_code=r.returncode,seconds=time.time()-start,command=ident(out/(name+'-command.json'))));print(name,r.returncode,flush=True)
 if r.returncode:print(r.stdout+r.stderr,flush=True);return r.returncode
 d=json.loads(dep.read_bytes())['Data'];save(out/(name+'-identity.json'),dict(command=command,source=ident(source),object=ident(obj),recipe=ident(recipe),source_dependencies=ident(dep),dependencies=[ident(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]))
 return 0
if len(sys.argv)>2:jobs=[job for job in jobs if job[0]in sys.argv[2:]]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:codes=list(pool.map(compile_one,jobs))
save(out/'summary.json',dict(attempts=len(codes),successes=sum(c==0 for c in codes),failures=sum(c!=0 for c in codes)));raise SystemExit(max(codes))
