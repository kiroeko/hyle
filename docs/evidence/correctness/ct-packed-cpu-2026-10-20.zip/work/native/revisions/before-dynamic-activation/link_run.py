from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=Path(__file__).resolve().parent;out=S/'validation';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('ct_cpu_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'nvfp4-reference-linear/cpu-final/link-plan.json';base=c.read(basepath);old=c.read(A/'nvfp4-reference-linear/cpu/native_provider-identity.json');new=c.read(S/'checks/attempt1/native-provider-identity.json');extra=[c.read(S/'checks/attempt1/ct-packed-identity.json')['object'],c.read(S/'checks/attempt2/test-identity.json')['object']]
inputs=[b.identity(Path(arg)) for arg in base['command']if Path(arg).is_absolute()and Path(arg).suffix.lower()in{'.obj','.lib'}]
assert sum(c.key(row['path'])==c.key(old['object']['path'])for row in inputs)==1
assert h.same_identity(old['object'])
assert c.key(old['source']['path'])==c.key(R/'src/compute_provider_native/native_provider.cc')
for row in [new['object'],*extra]:assert h.same_identity(row)
repl={c.key(old['object']['path']):new['object']};current=[repl.get(c.key(row['path']),row)for row in inputs]+extra
for row in current:assert h.same_identity(row),row['path']
env,runtime=b.environment(base['command'],[row['path']for row in current],out);c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
command=[repl.get(c.key(arg),{}).get('path',arg)for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];command.extend(row['path']for row in extra);image=out/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=current,base=b.identity(basepath),replacements=repl,old_owner_receipt=b.identity(A/'nvfp4-reference-linear/cpu/native_provider-identity.json')))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));c.execute('run',[str(image),'--gtest_filter=NativeCtPackedLinear.*','--gtest_output=xml:'+str(out/'tests.xml')],env,out)
