from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'checks'
spec=importlib.util.spec_from_file_location('ct_shared_link_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm,mode=sys.argv[1:3]
basepath=A/f'nvfp4-cross-backend-reference/{arm}/link-plan.json';base=c.read(basepath)
meta=h.metadata({arm:base});roots=c.read(O/'compile-summary.json')['rows'];rows=[r for r in roots if r['arm']==arm]
if arm=='cpu'and mode!='red':
 for name in ['ct-packed','native-provider']:
  rows.append(c.read(A/f'ct-packed-cpu-native/checks/attempt1/{name}-identity.json'))
replacements={};new=[]
for row in rows:
 source=row['source']['path']
 matches=[r for r in base['inputs']if c.key(r['path'])in meta and c.key(meta[c.key(r['path'])]['source_path'])==c.key(source)]
 assert len(matches)<=1,(source,matches)
 if matches:replacements[c.key(matches[0]['path'])]=row['object']
 else:new.append(row['object'])
test=c.read(A/f'ct-packed-linear-cpu/tests/checks/{arm}/test-identity.json')
matches=[r for r in base['inputs']if c.key(r['path'])in meta and c.key(meta[c.key(r['path'])]['source_path'])==c.key(test['source']['path'])]
assert len(matches)<=1
if matches:replacements[c.key(matches[0]['path'])]=test['object']
else:new.append(test['object'])
if arm=='cpu'and mode!='red':new.append(c.read(A/'ct-packed-cpu-native/checks/attempt3/test-identity.json')['object'])
inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]+new
for row in inputs:assert h.same_identity(row),row['path']
out=S/(arm+'-'+mode);out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
image=out/(arm+'.exe')
cmd=[replacements.get(c.key(arg),{}).get('path',arg)for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
cmd += [x['path']for x in new]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
env,runtime=b.environment(base['command'],[x['path']for x in inputs],out)
c.save(out/'link-plan.json',dict(command=cmd,inputs=inputs,base=b.identity(basepath),replacements=replacements,new=new))
c.execute('link',cmd,env,out);c.save(out/'image.json',b.identity(image))
filt='CpuCtPackedLinear.OriginalPackedConstantsDoNotRetainOrWorkspaceADenseWeightBank'if mode=='red'else'CpuCtPackedLinear.*:NativeCtPackedLinear.*:CpuNvfp4ReferenceGraph.*'
if arm=='cuda':filt='CudaCtPackedLinear.*:CudaNvfp4ReferenceGraph.*:CudaMlxSharedActivation.*:CudaMlxMoeGraph.*'
c.execute('run',[str(image),'--gtest_filter='+filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
