from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as E
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
 p=p.resolve();data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def check(row):
 actual=ident(Path(row['path']));assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),row['path']
def tests(name,count):
 p=S/name/'tests.xml';r=E.parse(p).getroot();assert int(r.get('tests'))==count and int(r.get('failures'))==0 and int(r.get('errors'))==0
 cases=[(s.get('name'),t.get('name'))for s in r.findall('testsuite')for t in s.findall('testcase')];assert len(cases)==len(set(cases))
 assert not any(int(s.get('skipped','0'))for s in r.findall('testsuite'))
 return dict(tests=count,failures=0,skip=0,xml=ident(p),cases=cases,properties=[dict(case=t.get('name'),values={x.get('name'):x.get('value')for x in t.findall('properties/property')})for s in r.findall('testsuite')for t in s.findall('testcase')if t.findall('properties/property')])
validation={arm:tests(path,count)for arm,path,count in [('cpu','cpu-green',9),('cuda','cuda-final',8)]}
for name in ['cpu-green','cuda-final']:
 for row in read(S/name/'link-plan.json')['inputs']:check(row)
sources=['src/compute_packed_shared/ct_packed_linear.h','src/graph/ct_packed_region.h','src/graph/mapped_native_region.h',
 'src/compute_provider_native/ct_packed.cc','src/compute_provider_native/native_provider.cc','src/compute_provider_native/native_plan.h','src/compute_provider_native/CMakeLists.txt',
 'src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_route_cpu/cpu_context.cc','src/compute_route_cpu/default_policy.h',
 'src/graph_route_cpu/cpu_context.cc','src/graph_route_cpu/ct_packed_linear_region.h','src/graph_route_cpu/ct_packed_linear_region.cc','src/graph_route_cpu/CMakeLists.txt',
 'src/graph_route_cuda/ct_packed_linear_region.cc','src/graph_route_cuda/dense_bfloat_scores_region.cc','src/graph_route_cuda/fp8_shared_prologue_region.cc',
 'tests/compute_provider_native/ct_packed_test.cc','tests/compute_provider_native/CMakeLists.txt','tests/compute_models/ct_packed_graph_fixture.h','tests/compute_models/ct_packed_linear_fixture.h',
 'tests/graph_route_cpu/ct_packed_linear_test.cc','tests/graph_route_cpu/CMakeLists.txt','tests/graph_route_cuda/ct_packed_linear_test.cc',
 'docs/user/compute.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json','docs/developer/current-work.md']
for path in ['src/compute_provider_torch_cuda/ct_packed_linear.h','src/graph_route_cuda/mapped_native_region.h']:assert not (R/path).exists()
report=dict(date='2026-10-20',status='implemented_and_focused_correctness_passed_performance_unverified',
 scope='CPU ordinary same-Graph compressed-tensors symmetric/asymmetric INT4 Decode[/Cast]/exact transpose/MatMul packed contraction plus shared CUDA/CPU cold discovery. No selected artifact payload, full model, throughput or whole-platform acceptance.',
 contract='Original low-first I32 codes along K, asymmetric I32 zeros packed along N, complete natural groups and F16/BF16/F32 scales. Keep scale-dtype subtraction/product, decode RNE, operand RNE, F32 accumulation and declared output RNE. One optional weight Cast before or after exact transpose. Closed intermediate data/control proof unchanged.',
 architecture=dict(common='One private format/rounding descriptor, one existing reader/control discovery and original prepared port adapter. CPU and CUDA bind their actual provider vtable; CPU preserves Graph default scope/executor/thread options and original Context. No executor/core/NativePlan layout or public API fields changed.',
  removed=['Old CUDA-only ct_packed_linear.h owner','Old CUDA-only mapped_native_region.h owner'],
  cpu='27 cold type route combinations;64-element A/W stack tiles, original ParallelExecutor and host mapping/Completion lifecycle. No workspace, dense W bank or hot provider heap allocation.',
  precision='F32 source product materialized before dot to prevent accidental multiply-add contraction across the public boundary. Backend dot reduction may differ; exact one-hot witnesses isolate operand rounding.',
  facade='Private CPU assembly accepts the decorated original native provider only for Graph. Ordinary Direct facade and existing oneDNN/ggml/ATen/native order and preferences remain unchanged. Both affected private-function symbol owners were recompiled.'),
 validation=validation,
 memory=dict(synthetic='N257/K1024 borrowed original packed constants: CPU report known compiled owned bytes376 and caller workspace0, versus a hypothetical decoded F32 bank1052672B (BF16526336B). Borrowed original bank/backing, Graph metadata, outputs and system/opaque allocations are separate. This is not measured whole-process/whole-model peak memory.',
  true_geometry='Direct cold preparation of real Q27 gate N17408/K5120 passed with0workspace; no large payload was allocated or executed.',
  artifact_research=ident(S/'research.json'),capacity_scope='Header-derived399-role dense BF16 sum45.254GiB vs original CT carriers13.081GiB is a hypothetical full-bank capacity comparison, not observed resident memory or total inference requirement.'),
 failures=dict(cpu_red='Same final Graph test object with new facade/shared discovery but old CPU native implementation: no packed region selected; old opaque-storage report remained unknown. Not a measured old dense-memory byte count.',
  source_review='Initial extraction retained a duplicated CUDA original() function; independently detected and removed before the7 product compiles. No compile failure hidden.',
  native_test='First strict Direct test CXX rejected implicit double-to-float narrowing. Test-only explicit cast corrected, later dynamic A witness changed to actual varying data; both earlier observations retained.',
  duplicate_test_closure='Initial CUDA integration appended the new shared test owner while retaining the old owner, producing12 registered tests with duplicate CT names. Replaced the exact old test owner, relinked and ran final8 unique tests; initial run is retained and is not final coverage.'),
 build=dict(CXX_attempts=14,CXX_successful=13,CXX_failed=1,product_CXX_successful=9,test_CXX_successful=4,NVCC=0,SDK=0,links=6,model_runs=0,profiler_runs=0,notes='Root7 product CXX + native2 product/3 test attempts + shared2 test CXX. All six actual links succeeded; final acceptance is CPU9/CUDA8 only, not cumulative repeated case counts.'),
 independent_reviews=[ident(S/'shared-review.json'),ident(A/'ct-packed-linear-cpu/tests/final-source-freeze.json')],
 source_freeze=[ident(R/p)for p in sources],
 execution_limits=['Windows CPU/CUDA SM89 only; no Linux/macOS execution, new CMake configure/install or shared-library acceptance.',
  'Apple/Vulkan packed CT paths remain absent; original cold dense decode remains available.',
  'No throughput benchmark. Large-M prefill may prefer a mature dense GEMM; packed-vs-dense default planning and performance tradeoff require follow-up rather than assuming memory savings imply faster execution.',
  'No GPTQ/permutation/expert/FFN/W4A4 extension; group128/512 numerical execution and selected publisher payloads remain unverified.',
  'No new Qwen BF16 speed claim or independent model quality acceptance.'])
(S/'final-validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
payload={}
for name in sources:payload['source/'+name]=(R/name).read_bytes()
for label,folder in [('root',S),('native',A/'ct-packed-cpu-native'),('tests',A/'ct-packed-linear-cpu/tests')]:
 for p in folder.rglob('*'):
  if p.is_file()and p.suffix.lower()in {'.json','.xml','.log','.cc','.h','.py','.diff'}and p.stat().st_size<3_000_000 and not any(x in p.relative_to(folder).parts for x in ('tmp','cleanup')):
   payload['work/'+label+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
manifest=[dict(member=k,bytes=len(v),sha256=hashlib.sha256(v).hexdigest())for k,v in sorted(payload.items())]
payload['payload-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=R/'docs/evidence/correctness';arc=dest/'ct-packed-cpu-2026-10-20.zip';assert not arc.exists()
with zipfile.ZipFile(arc,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for k,v in sorted(payload.items()):z.writestr(k,v)
with zipfile.ZipFile(arc)as z:
 assert z.testzip()is None
 for row in manifest:
  data=z.read(row['member']);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
report['archive']=dict(**ident(arc),payloads=len(manifest),CRC_checked=True,all_payload_SHA256_checked=True)
out=dest/'ct-packed-cpu-2026-10-20.json';out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(report=ident(out),archive=ident(arc)),indent=2))
