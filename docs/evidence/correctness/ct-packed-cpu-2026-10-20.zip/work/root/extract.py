from pathlib import Path
import re
R=Path.cwd();S=Path(__file__).resolve().parent
def write(name,text):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8',newline='\n')
old=R/'src/compute_provider_torch_cuda/ct_packed_linear.h'
text=old.read_text(encoding='utf-8').replace('namespace hyle::compute::torch_cuda::internal','namespace hyle::compute::packed::internal').replace('private-cuda-ct-packed-linear','private-ct-packed-linear')
write('src/compute_packed_shared/ct_packed_linear.h',text)
old.unlink()
p=R/'src/compute_provider_torch_cuda/artifact_provider.cc'
text=p.read_text(encoding='utf-8').replace('#include "ct_packed_linear.h"','#include "../compute_packed_shared/ct_packed_linear.h"').replace('internal::CtPackedLinear','packed::internal::CtPackedLinear')
write(str(p.relative_to(R)),text)
old=R/'src/graph_route_cuda/mapped_native_region.h'
text=old.read_text(encoding='utf-8').replace('namespace hyle::graph::cuda::internal::mapped_native_region','namespace hyle::graph::detail::mapped_native_region')
write('src/graph/mapped_native_region.h',text);old.unlink()
for name in ['dense_bfloat_scores_region.cc','fp8_shared_prologue_region.cc']:
 p=R/'src/graph_route_cuda'/name;text=p.read_text(encoding='utf-8').replace('#include "mapped_native_region.h"','#include "../graph/mapped_native_region.h"').replace('mapped_native_region::','graph::detail::mapped_native_region::')
 write(str(p.relative_to(R)),text)
p=R/'src/graph_route_cuda/ct_packed_linear_region.cc';original=p.read_text(encoding='utf-8')
(S/'before').mkdir(exist_ok=True)
(S/'before/ct_packed_linear_region.cc').write_text(original,encoding='utf-8',newline='\n')
start=original.index('inline constexpr c::RoutePolicyId')
end=original.index('\n} // namespace\n\nc::Provider ct_packed_linear_provider()')
body=original[start:end]
body=re.sub(r'const c::detail::ProviderVTable &original\(\) noexcept \{.*?\n\}\n\n','',body,flags=re.S)
body=body.replace('inline constexpr','inline static constexpr')
body=body.replace('const RegionProviderVTable kRegion','inline static const RegionProviderVTable kRegion')
for name in ['operation','producer','arity','pattern','closed','native_proposal','propose','qualify','same_requirement','resources','compile','query_extension','decorated']:
 body=re.sub(r'^(?!\s)([^\n]*\b'+name+r'\()',r'static \1',body,flags=re.M)
header='''#pragma once

#include "hyle/graph/region_provider.h"
#include "hyle/container/small_vector.h"
#include "../compute/provider_internal.h"
#include "../compute_packed_shared/ct_packed_linear.h"
#include "mapped_native_region.h"

#include <algorithm>
#include <array>
#include <limits>
#include <optional>

namespace hyle::graph::detail {
namespace c = compute;
namespace native = c::packed::internal;

// One exact public recipe and reader/control proof, bound to an existing
// backend provider. Original context, resources and prepared submit are reused.
template <const c::detail::ProviderVTable &(*Original)() noexcept>
struct CtPackedRegion final {
static const c::detail::ProviderVTable &original() noexcept { return Original(); }
'''
tail='''
static c::Provider decorate(c::Provider provider) noexcept {
  return c::detail::ProviderAccess::with_vtable(std::move(provider), &decorated());
}
};
} // namespace hyle::graph::detail
'''
write('src/graph/ct_packed_region.h',header+body+tail)
write('src/graph_route_cuda/ct_packed_linear_region.cc','''#include "ct_packed_linear_region.h"

#if defined(HYLE_COMPUTE_TORCH_CUDA)
#include "../graph/ct_packed_region.h"
#include "hyle/compute/providers/torch_cuda.h"

namespace hyle::graph::cuda::internal {
namespace {
const compute::detail::ProviderVTable &original() noexcept {
  return *compute::detail::ProviderAccess::vtable(compute::torch_cuda::provider());
}
}
compute::Provider ct_packed_linear_provider() noexcept {
  return graph::detail::CtPackedRegion<&original>::decorate(compute::torch_cuda::provider());
}
} // namespace hyle::graph::cuda::internal
#else
namespace hyle::graph::cuda::internal {
compute::Provider ct_packed_linear_provider() noexcept { return {}; }
} // namespace hyle::graph::cuda::internal
#endif
''')
print('Shared CT descriptor, exact region and mapped prepared adapter extracted; no Graph executor/ABI changed.')
