from pathlib import Path
import concurrent.futures,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1];O=S/'checks';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('ct_shared_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
bases={arm:c.read(A/path)for arm,path in [('cpu','nvfp4-cross-backend-reference/cpu/link-plan.json'),('cuda','decode-current-rebenchmark/build/link-plan.json')]}
meta=h.metadata(bases)
def owner(arm,source):
 rows=[x for x in bases[arm]['inputs']if c.key(x['path'])in meta and c.key(meta[c.key(x['path'])]['source_path'])==c.key(R/source)]
 assert len(rows)==1,(arm,source,len(rows))
 return rows[0],meta[c.key(rows[0]['path'])]
def build_one(item):
 arm,source=item
 recipe_source=source if source!='src/graph_route_cpu/ct_packed_linear_region.cc'else'src/graph_route_cpu/cpu_context.cc'
 old,recipe=owner(arm,recipe_source)
 tag=source.replace('/','--').rsplit('.',1)[0];obj=O/(tag+'.obj');cmd=b.host_command(recipe['command'],R/source,tag,O)
 env,runtime=b.environment(bases[arm]['command'],[x['path']for x in bases[arm]['inputs']],O)
 c.execute(tag,cmd,env,O)
 dep=Path(cmd[cmd.index('/sourceDependencies')+1]);data=c.read(dep)['Data']
 row=dict(arm=arm,source=b.identity(R/source),object=b.identity(obj),command=cmd,recipe=recipe['recipe'],source_dependencies=b.identity(dep),dependencies=[b.identity(Path(p))for p in dict.fromkeys([data['Source'],*data['Includes']])],old_object=None if recipe_source!=source else old)
 c.save(O/(tag+'-identity.json'),row);return row
items=[('cpu','src/compute_route_cpu/cpu_context.cc'),('cpu','src/graph_route_cpu/cpu_context.cc'),('cpu','src/graph_route_cpu/ct_packed_linear_region.cc'),('cuda','src/graph_route_cuda/ct_packed_linear_region.cc'),('cuda','src/graph_route_cuda/dense_bfloat_scores_region.cc'),('cuda','src/graph_route_cuda/fp8_shared_prologue_region.cc'),('cuda','src/compute_provider_torch_cuda/artifact_provider.cc')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(build_one,items))
c.save(O/'compile-summary.json',dict(CXX=len(rows),NVCC=0,SDK=0,rows=rows,bases={a:[x for x in p['inputs']]for a,p in bases.items()}))
print('SEVEN_ROOT_PRODUCT_OWNERS_COMPILED')
