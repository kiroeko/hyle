from pathlib import Path
import hashlib,json,difflib,re
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/ct-packed-linear-cpu/tests';S.mkdir(parents=True,exist_ok=True)
def I(p):
 p=Path(p);v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
old=R/'tests/graph_route_cuda/ct_packed_linear_test.cc';cmake=R/'tests/graph_route_cpu/CMakeLists.txt'
for p in [old,cmake]:
 target=S/'before'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(p.read_bytes())
text=old.read_bytes().decode();assert '\r'not in text
for line in ['#include "hyle/compute/backends/cuda.h"\n','#include "hyle/compute/providers/torch_cuda.h"\n','#include "hyle/graph/cuda.h"\n']:assert line in text;text=text.replace(line,'')
text=text.replace('#include "../compute_models/ct_packed_linear_fixture.h"','#pragma once\n\n#include "ct_packed_linear_fixture.h"\n#include "hyle/graph/executable.h"')
text=text.replace('namespace {\nnamespace c = hyle::compute;','namespace ct_packed_graph_test {\nnamespace c = hyle::compute;',1)
names=['PublicChainsKeepSourceRoundsAndTypedCastWitnesses','CapturedDynamicInputsRebindAcrossOwnedSlotsAndRetainResults','PublishedViewAndControlEscapesExecuteTheOriginalDecomposition','OriginalPackedConstantsDoNotRetainOrWorkspaceADenseWeightBank']
for name in names:
 a=f'TEST(CudaCtPackedLinear, {name}) {{';assert a in text;text=text.replace(a,f'template <class Backend>\nvoid {name}() {{')
a='  auto context = g::cuda::create_context().value();\n  auto owner = c::StorageOwner::adopt(context,\n      c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value()).value();';assert text.count(a)==4;text=text.replace(a,'  auto context = Backend::create_context();\n  auto owner = Backend::create_owner(context);')
text=text.replace('g::cuda::compile(', 'Backend::compile(')
a='void selected(const Logical &f, const g::CompileReport &report, bool expected) {';assert a in text;text=text.replace(a,'template <class Backend>\nvoid selected(const Logical &f, const g::CompileReport &report, bool expected) {').replace('c::torch_cuda::kProviderId','Backend::provider_id')
text=text.replace('    selected(f,','    selected<Backend>(f,').replace('  selected(f,','  selected<Backend>(f,')
a='''void submit(g::Invocation &slot, c::Queue &queue, bool capture) {
  const auto prepared = g::cuda::prepare_replay(slot, queue,
      {.mode = capture ? g::ReplayMode::kRequireCapture : g::ReplayMode::kCommands,
       .host_wait = g::HostWaitPolicy::kAllow});''';assert a in text;text=text.replace(a,'''template <class Backend>
void submit(g::Invocation &slot, c::Queue &queue, bool capture) {
  const auto prepared = Backend::prepare(slot, queue, capture);''')
text=re.sub(r'\bsubmit\((slot|slots\[lane\]), (queue|queues\[lane\]), true\)',r'submit<Backend>(\1, \2, Backend::supports_capture)',text)
text=text.replace('submit(slot, queue, false)','submit<Backend>(slot, queue, false)')
text=text.replace('  RecordProperty(', '  ::testing::Test::RecordProperty(')
for first in ['void check(', 'c::TensorDesc dense(', 'Logical build(', 'std::vector<std::byte> floating(', 'std::vector<double> read(', 'void exact_values(', 'c::ReadLease upload(', 'void bind(', 'c::ConstTensorView output(', 'g::Invocation invocation(', 'void expect_dot(', 'void stage(', 'void ordinary_control(']:
 assert first in text,first;text=text.replace('\n'+first,'\ninline '+first)
text=text.replace('} // namespace\n','} // namespace ct_packed_graph_test\n')
text=text.replace('// Single-domain cuda::compile fixes the exact resource object, rather','// The selected compile domain fixes the exact resource object, rather')
assert 'g::cuda::'not in text and 'c::cuda::'not in text and 'torch_cuda'not in text and 'TEST('not in text
fixture=R/'tests/compute_models/ct_packed_graph_fixture.h';assert not fixture.exists();fixture.write_bytes(text.encode())
cuda='''#include "../compute_models/ct_packed_graph_fixture.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/torch_cuda.h"
#include "hyle/graph/cuda.h"

namespace {
namespace f = ct_packed_graph_test;
struct Backend final {
  static constexpr bool supports_capture = true;
  static constexpr auto provider_id = f::c::torch_cuda::kProviderId;
  static f::c::Context create_context() {
    return f::take(f::g::cuda::create_context(), "CUDA Context");
  }
  static f::c::StorageOwner create_owner(const f::c::Context &context) {
    return f::take(f::c::StorageOwner::adopt(context,
        f::take(f::c::cuda::MemoryResource::create(context,
            f::c::cuda::MemoryKind::kDevice), "CUDA resource")), "CUDA StorageOwner");
  }
  static hyle::Result<f::g::CompiledGraph> compile(const f::g::Graph &graph,
      const f::c::Context &context, const f::c::StorageOwner &owner,
      f::g::CompileOptions options = {}) noexcept {
    return f::g::cuda::compile(graph, context, owner, options);
  }
  static hyle::Status prepare(f::g::Invocation &slot, f::c::Queue &queue,
      bool capture) noexcept {
    return f::g::cuda::prepare_replay(slot, queue,
        {.mode = capture ? f::g::ReplayMode::kRequireCapture : f::g::ReplayMode::kCommands,
         .host_wait = f::g::HostWaitPolicy::kAllow});
  }
};
'''
cpu='''#include "../compute_models/ct_packed_graph_fixture.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"

namespace {
namespace f = ct_packed_graph_test;
// The actual process-lifetime system resource needs no separate native owner.
// StorageOwner still retains this original CPU Context and allocator contract.
struct SystemResource final {
  f::m::MemoryResourceRef ref() noexcept { return f::m::system_resource(); }
};
struct Backend final {
  static constexpr bool supports_capture = false;
  static constexpr auto provider_id = f::c::native::kProviderId;
  static f::c::Context create_context() {
    return f::take(f::g::cpu::create_context(), "CPU Context");
  }
  static f::c::StorageOwner create_owner(const f::c::Context &context) {
    return f::take(f::c::StorageOwner::adopt(context, SystemResource{}), "CPU StorageOwner");
  }
  static hyle::Result<f::g::CompiledGraph> compile(const f::g::Graph &graph,
      const f::c::Context &context, const f::c::StorageOwner &,
      f::g::CompileOptions options = {}) noexcept {
    return f::g::cpu::compile(graph, context, options);
  }
  static hyle::Status prepare(f::g::Invocation &slot, f::c::Queue &queue,
      bool capture) noexcept {
    if (capture) return hyle::Status::InvalidArgument("CPU fixture has no capture backend");
    const std::array queues{f::g::QueueBinding{f::g::ExecutionLaneId{0}, &queue}};
    return slot.prepare_replay(queues,
        {.mode = f::g::ReplayMode::kCommands, .host_wait = f::g::HostWaitPolicy::kAllow});
  }
};
'''
for body,suite,p in [(cuda,'CudaCtPackedLinear',old),(cpu,'CpuCtPackedLinear',R/'tests/graph_route_cpu/ct_packed_linear_test.cc')]:
 for name in names:body+=f'\nTEST({suite}, {name}) {{\n  f::{name}<Backend>();\n}}\n'
 body+='} // namespace\n';p.write_bytes(body.encode())
a='SOURCES fp8_channel_token_qdq_test.cc nvfp4_reference_test.cc';b=cmake.read_bytes();assert a.encode()in b;cmake.write_bytes(b.replace(a.encode(),(a+' ct_packed_linear_test.cc').encode()))
for rel in ['tests/compute_models/ct_packed_graph_fixture.h','tests/graph_route_cuda/ct_packed_linear_test.cc','tests/graph_route_cpu/ct_packed_linear_test.cc','tests/graph_route_cpu/CMakeLists.txt']:
 p=R/rel;target=S/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
 if (S/'before'/rel).exists():(S/(p.stem+'.diff')).write_bytes(''.join(difflib.unified_diff((S/'before'/rel).read_bytes().decode().splitlines(True),p.read_bytes().decode().splitlines(True),fromfile='before/'+rel,tofile=rel)).encode())
paths=[R/rel for rel in ['tests/compute_models/ct_packed_graph_fixture.h','tests/graph_route_cuda/ct_packed_linear_test.cc','tests/graph_route_cpu/ct_packed_linear_test.cc','tests/graph_route_cpu/CMakeLists.txt']];(S/'source-freeze.json').write_text(json.dumps(dict(status='extracted_not_built',sources=[I(p)for p in paths],before=[I(p)for p in (S/'before').rglob('*')if p.is_file()],math='Original mathematical/oracle/rounding, escapes, twoownedslots, changedA/codes/Z/scales, oldoutputs and constantspace checks are shared verbatim; backendadapter changes only factory/resource/compile/providerid/capture capability.',product_edits=0,GPU=0),indent=2)+'\n');print('COMMON_CT_GRAPH_FIXTURE_EXTRACTED')
