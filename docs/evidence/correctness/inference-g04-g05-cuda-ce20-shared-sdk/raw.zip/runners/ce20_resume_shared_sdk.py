from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,zipfile

route,mode,attempt=sys.argv[1:4]
assert route in ('apple','vulkan','cuda') and mode in ('static','shared')
air=os.uname().sysname=='Darwin'
assert air==(route!='cuda')
BASE=Path('/Users/kiro/hyle-scratch/compute-unified' if air else '/root/hyle-scratch/compute-unified')
SOURCE=BASE/('source-c8874688' if air else 'source-7a7b4c3b')
OUT=(BASE/'g04-g05-encoded-sdk' if air else Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/sdk'))
OUT.mkdir(parents=True,exist_ok=True)
tag=f'{route}-{mode}-{attempt}';result_file=OUT/f'result-{tag}.json'
assert not result_file.exists() and SOURCE.is_dir() and not (SOURCE/'.git').exists()
with zipfile.ZipFile(OUT/f'source-{tag}.zip') as archive:
    inputs=json.loads(archive.read('source-manifest.json'))
    for row in inputs:
        relative=Path(row['path']);assert not relative.is_absolute() and '..' not in relative.parts
        data=archive.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
        destination=SOURCE/relative
        if not destination.exists() or destination.read_bytes()!=data:
            destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
identity={name:subprocess.check_output(args,text=True).strip() for name,args in (
    [('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]
    if air else [('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'])])}
if air:assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
cmake='/opt/homebrew/bin/cmake' if air else 'cmake';ninja='/opt/homebrew/bin/ninja' if air else 'ninja'
env=os.environ.copy()
env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
producer=BASE/f'{"a" if air else "l"}-cpu-{route}/selected-graph/{mode}-sdk-build'
cache=(producer/'CMakeCache.txt').read_text()
assert f'CMAKE_HOME_DIRECTORY:INTERNAL={SOURCE}' in cache and 'HYLE_SANITIZER:STRING=off' in cache
folder=(OUT/tag if air else BASE/'g04-g05-encoded-sdk'/tag)
folder.parent.mkdir(parents=True,exist_ok=True);folder.mkdir(exist_ok=False)
staging=folder/'staging';prefix=folder/'relocated';consumer=folder/'consumer';consumer.mkdir();build=folder/'build'
record={'state':'RUNNING','route':route,'mode':mode,'attempt':attempt,'identity':identity,'inputs':inputs,'max_jobs':4,'stages':[],'cumulative_seconds':0,
        'scope':'G04/G05 actual relocated shipping static/shared public consumers, new mathematical domain and twelve independent public headers; no repository HYLE headers, HYLE_TESTING, P1 or full model.',
        'producer':str(producer),'prefix':str(prefix),'prior_project_include':[s for s in cache.splitlines() if s.startswith('CMAKE_PROJECT_INCLUDE:')]}
def run(stage,args):
    log=OUT/f'{stage}-{tag}.log';start=time.monotonic()
    with log.open('w') as handle:
        process=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'RUNNING','pid':process.pid,'stage':stage,'log':str(log)}))
        print(tag,stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start
    record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    record['cumulative_seconds']+=elapsed;record['state']='TERMINAL_FAIL' if code else 'RUNNING'
    result_file.write_text(json.dumps(record,indent=2)+'\n')
    print(tag,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}))
        print(log.read_text(errors='replace')[-6500:],flush=True);raise SystemExit(code)

args=[cmake,'-S',str(SOURCE),'-B',str(producer)]
if route=='cuda':args+=['-UCMAKE_PROJECT_INCLUDE','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_TESTING=OFF']
assert route=='cuda'
args+=['-DCMAKE_PROJECT_INCLUDE=/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce19_cuda_compile.cmake']
reuse=next((a.split('=',1)[1] for a in sys.argv[4:] if a.startswith('--reuse-configure=')),None)
if reuse:
    prior=json.loads((OUT/f'result-{reuse}.json').read_text())
    assert prior['route']==route and prior['mode']==mode and prior['inputs']==inputs
    assert {k:v for k,v in prior['identity'].items() if k!='gpu'}=={k:v for k,v in identity.items() if k!='gpu'}
    assert prior['identity']['gpu'].split(',')[:3]==identity['gpu'].split(',')[:3]
    record['prior_gpu_telemetry']=prior['identity']['gpu']
    assert any(s['stage']=='producer-configure' and s['exit_code']==0 for s in prior['stages'])
    record['configuration_reused_from']=reuse
else:run('producer-configure',args)
configured_cache=(producer/'CMakeCache.txt').read_text()
assert 'HYLE_BUILD_TESTS:BOOL=OFF' in configured_cache and 'HYLE_INSTALL:BOOL=ON' in configured_cache
commands=json.loads(subprocess.check_output([ninja,'-C',str(producer),'-t','compdb'],env=env,text=True))
shipping=[r for r in commands if r['file'].startswith(str(SOURCE/'src')+'/')]
assert shipping and all('HYLE_TESTING' not in r['command'] and '-fsanitize=' not in r['command'] for r in shipping)
(OUT/f'shipping-{tag}.json').write_text(json.dumps(shipping,indent=2)+'\n')
targets=['hyle_compute','hyle_compute_batch','hyle_graph','hyle_graph_batch',f'hyle_graph_route_cpu_{route}']
if route!='cuda':targets += [f'hyle_compute_route_{route}',f'hyle_graph_route_{route}']
else:targets += ['hyle_compute_provider_flashinfer','hyle_compute_state']
if attempt.startswith('ce19-'):
    run('producer-prepare-manifest',[ninja,'-C',str(producer),'build.ninja'])
    manifest=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce20-shared-native-reuse-1/reuse.ninja')
    reuse_proof=json.loads((manifest.parent/'result.json').read_text());assert reuse_proof['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
    assert hashlib.sha256((producer/'build.ninja').read_bytes()).hexdigest()==reuse_proof['original_manifest_sha256']
    record['native_cuda_reuse']=reuse_proof
    run('producer-plan',[ninja,'-C',str(producer),'-f',str(manifest),'-n',*targets])
    plan=(OUT/f'producer-plan-{tag}.log').read_text()
    assert 'Re-running CMake' not in plan,'Incomplete dry plan'
    cuda_edges=[line for line in plan.splitlines() if 'Building CUDA object' in line]
    assert all('compute_provider_flashinfer' in line for line in cuda_edges),'Unrelated native CUDA rebuild rejected'
    assert len(cuda_edges)<=4,cuda_edges
if attempt.startswith('ce14-'):
    manifest=OUT/f'exact-build-{tag}.ninja';manifest.write_bytes((producer/'build.ninja').read_bytes())
    run('producer-plan',[ninja,'-C',str(producer),'-f',str(manifest),'-n',*targets])
    plan=(OUT/f'producer-plan-{tag}.log').read_text()
    assert not any(x in plan for x in ('Building CUDA object','vulkan-shaders-gen','vulkan_shaders.cc')),'Unrelated native build in CE14 Apple-only plan'
run('producer-build',[ninja,'-C',str(producer),'-f',str(manifest),'-j','2',*targets])
assert hashlib.sha256((producer/'build.ninja').read_bytes()).hexdigest()==reuse_proof['original_manifest_sha256']
for item in json.loads((manifest.parent/'mapped-edges.json').read_text()):
    assert hashlib.sha256((producer/item['old_output']).read_bytes()).hexdigest()==item['object_sha256']
run('install',[cmake,'--install',str(producer),'--prefix',str(staging)])
staging.rename(prefix);assert not staging.exists()
headers=['compute/batch_execution.h','compute/batch_layout.h','compute/batch_materialize.h','compute/batch_ops.h',
         'compute/batch_paged_native.h','compute/detail/materialized_native_controller.h','compute/detail/paged_arena_access.h',
         'compute/low_precision.h','compute/model_ops.h','compute/operation.h','compute/paged_arena.h','graph/batch.h']
for i,name in enumerate(headers):
    assert (prefix/'include/hyle'/name).read_bytes()==(SOURCE/'include/hyle'/name).read_bytes()
    (consumer/f'header-{i}.cc').write_text(f'#include <hyle/{name}>\n')
files=['tests/compute_batch/encoded_page_common_consumer.cc','tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_native/half_test_support.h']
if route!='cuda':files+=['tests/compute_batch/encoded_page_native_consumer.cc',f'tests/compute_route_{route}/native_cache_test.cc']
else:files+=['tests/compute_provider_flashinfer/native_cache_test.cc']
for name in files:
    destination=consumer/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((SOURCE/name).read_bytes())
gtest='/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6' if air else None
if not gtest:
    matches=[folder/'googletest-063de7e9578f-162765170ae6' for folder in
             (Path('/root/.cache/hyle/dependencies/v1/sources'),Path('/mnt/c/public/tools/hyle-dependencies/v1/sources'))]
    gtest=str(next(p for p in matches if p.is_dir()))
body=f'''cmake_minimum_required(VERSION 3.25)
project(g04_g05_encoded_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory("{gtest}" gtest EXCLUDE_FROM_ALL)
add_executable(cpu tests/compute_batch/encoded_page_common_consumer.cc)
target_link_libraries(cpu PRIVATE GTest::gtest_main)
add_executable(cpu_math tests/compute_provider_ggml/native_paged_test.cc)
target_link_libraries(cpu_math PRIVATE GTest::gtest_main)
add_executable(native {'tests/compute_batch/encoded_page_common_consumer.cc' if route=='cuda' else 'tests/compute_batch/encoded_page_native_consumer.cc'})
target_link_libraries(native PRIVATE GTest::gtest_main)
add_executable(native_math tests/{'compute_provider_flashinfer' if route=='cuda' else 'compute_route_'+route}/native_cache_test.cc)
target_link_libraries(native_math PRIVATE GTest::gtest_main)
add_library(headers OBJECT {' '.join('header-'+str(i)+'.cc' for i in range(len(headers)))})
foreach(t cpu cpu_math native native_math headers)
 target_compile_features(${{t}} PRIVATE cxx_std_23)
 target_compile_options(${{t}} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${{t}} PRIVATE hyle::graph)
endforeach()
foreach(t cpu cpu_math native native_math)
 hyle_stage_runtime(${{t}})
endforeach()
'''
if route in ('apple','cuda'):body+=f'target_compile_definitions(native PRIVATE HYLE_ENCODED_{route.upper()}=1)\n'
(consumer/'CMakeLists.txt').write_text(body)
(OUT/f'consumer-project-{tag}.cmake').write_text(body)
args=[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
if route=='cuda':args+=['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3']
run('consumer-configure',args)
run('consumer-build',[cmake,'--build',str(build),'--target','cpu','cpu_math','native','native_math','headers','--parallel','2'])
commands=json.loads((build/'compile_commands.json').read_text())
actual=[r for r in commands if r['file'].startswith(str(consumer)+'/')]
assert len(actual)==16,len(actual)
assert all(str(SOURCE) not in r['command'] and str(producer) not in r['command'] and str(prefix/'include') in r['command'] for r in actual)
(OUT/f'consumer-commands-{tag}.json').write_text(json.dumps(actual,indent=2)+'\n')
for name in ['cpu_math','native_math','cpu','native']:
    args=[str(build/name),'--gtest_output=xml:'+str(OUT/f'{name}-{tag}.xml')]
    if name=='cpu_math':args+=['--gtest_filter=GgmlCpuCacheEncode.*:GgmlCpuBoxed.*']
    run(name,args)
if route=='apple':
    header=prefix/'include/metal_cpp/Foundation/NSSharedPtr.hpp'
    assert hashlib.sha256(header.read_bytes()).hexdigest()=='d93f38effcc9556aa2cd2dec13db0cdcf37cd36bfd217bcbeedeb7e6c55fd2f4'
    manifest=json.loads((SOURCE/'third_party/mlx_cast/patches.json').read_text())
    allocator_header=next(f for f in manifest['files'] if f['path']=='mlx/backend/metal/allocator.h')
    assert hashlib.sha256((prefix/'include/mlx/backend/metal/allocator.h').read_bytes()).hexdigest()==allocator_header['after_sha256']
    lifetime=consumer/'metal_shared_ptr_lifetime.cc';lifetime.write_bytes((SOURCE/'tests/compute_route_apple/metal_shared_ptr_lifetime.cc').read_bytes())
    run('installed-metal-lifetime-compile',['xcrun','clang++','-std=c++20','-O3','-g','-Wall','-Wextra','-Wpedantic','-Werror','-fsanitize=undefined','-fno-sanitize-recover=all','-isystem',str(prefix/'include/metal_cpp'),str(lifetime),'-framework','Foundation','-framework','Metal','-o',str(build/'metal_lifetime')])
    run('installed-metal-lifetime',[str(build/'metal_lifetime')])
    license=prefix/'share/licenses/Hyle/mlx-metal-cpp-LICENSE.txt'
    assert license.read_bytes()==(SOURCE/'third_party/mlx_cast/metal-cpp-LICENSE.txt').read_bytes()
    assert (prefix/'share/licenses/Hyle/mlx-cast-NOTICE.md').read_bytes()==(SOURCE/'third_party/mlx_cast/NOTICE.md').read_bytes()
artifacts=[p for p in (prefix/'lib').rglob('*') if p.is_file() and p.name.startswith('libhyle') and p.suffix in ('.a','.dylib','.so')]
assert artifacts and any(p.name.startswith('libhyle_graph_batch') for p in artifacts)
(OUT/f'artifacts-{tag}.json').write_text(json.dumps([{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in artifacts],indent=2)+'\n')
(OUT/f'public-inputs-{tag}.json').write_text(json.dumps({'headers':[{'path':name,'sha256':hashlib.sha256((prefix/'include/hyle'/name).read_bytes()).hexdigest()} for name in headers],
    'consumers':[{'path':str(p.relative_to(consumer)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in consumer.rglob('*') if p.is_file()]},indent=2)+'\n')
record['state']='TERMINAL_PASS';result_file.write_text(json.dumps(record,indent=2)+'\n')
(OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
print(tag,'ALL SHIPPING SDK STAGES PASS',flush=True)
