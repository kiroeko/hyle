from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path(__file__).resolve().parents[3]
work=root/'.scratch/inference-gaps/g03/copy-update-source';work.mkdir(exist_ok=True)
script=work/'copy_update_source_air.py'
text=(work.parent/'pending-owner-probe/pending_owner_air.py').read_text()
text=text.replace('g03-pending-owner-probe','g03-copy-update-source')
text=text.replace('g03_pending_copy_owner','g03_copy_update_owner')
text=text.replace('SCOPED prototype; product fixed dab23ba92256cad21f2e83af6141eb8ad51264c5','AUDITED WORKTREE CU01 and CU02 source probe, baseline f764; CU03 incomplete')
text=text.replace('actual pending Apple copy ownership handoff of original invocation/submission; five lifecycle modes; no pending attention claim','actual public CopyBatchUpdate Apple ownership/identity/lifecycle five modes; not pending attention')
text=text.replace('f764a1053','5eda0cc0f')
script.write_text(text)
paths=['include/hyle/compute/batch_transfer.h','include/hyle/compute/apple_memory.h',
       'include/hyle/compute/vulkan_memory.h','include/hyle/compute/detail/copy_stream_access.h',
       'src/compute_route_apple/apple_file_stream_access.h','src/compute_route_vulkan/vulkan_file_stream_access.h',
       'src/compute/batch_transfer.cc',
       'src/compute_route_apple/apple_copy_program.cc','src/compute_route_vulkan/vulkan_copy_program.cc',
       'tests/compute_batch/pending_copy_owner_probe.cc','tests/compute_batch/dirty_page_native_risk_fixture.h',
       'tests/compute_batch/native_paged_risk_fixture.h','tests/compute_batch/native_apple_failure_fixture.h']
number=1
while (work/f'input-{number}.zip').exists():number+=1
archive=work/f'input-{number}.zip';manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for path in paths:
  data=(root/path).read_bytes();manifest.append({'path':path,'sha256':hashlib.sha256(data).hexdigest()});package.writestr(path,data)
 package.writestr('input-manifest.json',json.dumps(manifest,indent=2)+'\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-copy-update-source'
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,'mkdir -p '+remote],check=True)
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',str(archive),str(script),f'{host}:{remote}/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,f'python3 {remote}/{script.name} {archive.name} apple'])
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',f'{host}:{remote}/result.json',f'{host}:{remote}/job.json',str(work)],check=True)
raise SystemExit(result.returncode)
