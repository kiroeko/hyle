"""Retain Windows v4 evidence only; no build/device/remote/selector command."""
from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path.cwd()
scratch = root / '.scratch/g09-completion-wake-correction'
bundle = scratch / 'run-final-v4'
source = bundle / 'windows-vulkan/source'
out = root / 'evidence/correctness/inference-g09-completion-wake'
archive = out / 'ordinary-checkpoint-4.zip'
summary = out / 'ordinary-checkpoint-4.json'
assert not archive.exists() and not summary.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(Path(path).read_bytes())
artifact = lambda path: {'path': str(path), 'sha256': digest(path), 'bytes': Path(path).stat().st_size}

manifest = json.loads((bundle / 'manifest.json').read_text())
receipt = json.loads((source / 'receipt.json').read_text())
plan = json.loads((source / 'plan.json').read_text())
review = json.loads((source / 'windows-source-device-review.json').read_text())
candidate = 'a0cc517332129c403b4e464a2e865712a2842290'
assert manifest['candidate'] == receipt['candidate'] == candidate
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
assert digest(scratch / 'verify-v4.py') == manifest['script_sha256'] == '77d78e15ad8778afd36c7e3b482e0ec880919c549bbbec8c5a4fe74cf222309c'
assert digest(bundle / 'manifest.json') == '4b76cb54b5f00ed3b9577dfe7d2ea369acdc2f8821c6683c95250f4d45333c45'
assert digest(source / 'receipt.json') == '1913cfb7b55a248d18850583802cf01d1ff209981754cbf4c389e5cd376a9e9a'
assert digest(source / 'windows-source-device-review.json') == '45fec0feafc75c16e271d91ce54038293ca7d4571b1fe61461e8e1531ada8548'
assert len(manifest['files']) == 2677 and len(receipt['built_artifacts']) == 49
assert len(plan['compiled_lines']) == 48 and len(plan['generated_152_data_before']) == 152
assert not receipt['failures'] and [x['stage'] for x in receipt['steps']] == ['sync', 'configure', 'plan', 'build', 'test', 'device']
assert abs(receipt['inherited_measured_command_seconds'] - 958.640) < 1e-6
assert abs(receipt['cumulative_measured_command_seconds_including_inherited'] - 1175.780) < 1e-6
assert review['state'] == 'PASS_CURRENT_FIXED_CANDIDATE_WINDOWS_SOURCE_DEVICE_GATE_ONLY'
for item in manifest['files']:
    assert digest(root / item['path']) == item['sha256']
for item in receipt['built_artifacts'] + plan['generated_152_data_before']:
    assert digest(item['path']) == item['sha256']
for item in receipt['commands']:
    assert digest(item['log']) == item['log_sha256'] and item['exit_code'] == 0
assert digest(bundle / 'source.zip') == manifest['source_zip_sha256']
assert digest(bundle / 'source.git-archive.raw.zip') == manifest['exact_archive_metadata_mapping']['raw_archive_sha256']

payload = {}
originals = {}
for path in [bundle / 'source.zip', bundle / 'source.git-archive.raw.zip']:
    originals[str(path)] = digest(path)
def add(path, member=None):
    path = Path(path).resolve()
    assert path.is_file(), path
    member = member or path.relative_to(scratch).as_posix()
    assert member not in payload, member
    payload[member] = path.read_bytes()
    originals[str(path)] = digest(path)

for name in [
    'verify-v4.py', 'verify-v4.patch', 'verify-v4-preparation.json', 'verify-v4-review.md',
    'retain-fourth-ordinary.py',
    'native-retirement-v4-implementation.diff',
    'selector-windows-v4-plan.json', 'selector-windows-v4-plan-command.log',
    'selector-windows-v4-plan-preparation.json', 'selector-windows-v4-plan-review.json',
    'selector-windows-v4-execution-preparation.json',
    'loc-compute_route_apple-v4.json', 'loc-compute_route_vulkan-v4.json',
    'loc-graph_route_cpu_apple-v4.json', 'loc-graph_route_cpu_vulkan-v4.json',
    'loc-v4-preparation-refusal.json',
    'air-v4-cache-readonly.json', 'air-v4-cache-origin-readonly.json',
    'air-v4-cache-blockers.txt', 'air-v4-staged-plan.json',
    'air-entry-final-v4-transfer.json',
    'air-vulkan-queue-identity.json', 'air-vulkan-queue-identity.txt',
    'windows-sdk-v4-readonly-preparation.json',
    'ordinary-checkpoint-4-retention-preflight-failure.json',
]:
    add(scratch / name)
for name in ['manifest.json', 'context-windows-vulkan.json', 'context-air.json']:
    add(bundle / name)
for path in sorted((bundle / 'models').rglob('*')):
    if path.is_file():
        add(path)
for path in sorted(source.iterdir()):
    if path.is_file() and path.suffix != '.zip':
        add(path)

# All Air source run artifacts and its changing receipt belong to cp5. Only
# original read-only preparation/identity context is retained above.

cache = Path(plan['build_ninja']['path']).parent
parent = Path(receipt['external_parent']['path'])
assert digest(parent) == receipt['external_parent']['sha256']
for name, path in [
    ('CMakeCache.txt', cache / 'CMakeCache.txt'),
    ('compile_commands.json', cache / 'compile_commands.json'),
    ('final-parent.cmake', parent),
    ('windows-envcmd.cmd', Path(receipt['windows_envcmd']['path'])),
]:
    add(path, 'external-configured-cache/' + name)
add(out / 'source-review.json', 'independent/original-owner-source-review.json')

roots = sorted({x['path'].split('/')[0] for x in manifest['files'] if not x['path'].startswith('docs/')})
reconstruction = {
    'candidate': candidate,
    'canonical_archive': artifact(bundle / 'source.zip'),
    'raw_git_archive': artifact(bundle / 'source.git-archive.raw.zip'),
    'archives_in_this_checkpoint': False,
    'git_archive_arguments': ['git', 'archive', '--format=zip', candidate, '--', *roots, 'docs/implementation/module-status.json'],
    'canonicalization': manifest['exact_archive_metadata_mapping'],
    'algorithm': 'Use retained exact verify-v4.py prepare archive construction: preserve raw member order and ZipInfo; restore only SOURCE-MANIFEST.txt to the immutable Git blob. Verify every other member byte-identical and every manifest file SHA. Do not re-prepare the active task or reset any failure budget.',
    'git_blob_member_map': 'run-final-v4/manifest.json /files; 2677 exact candidate-relative paths, hashes and sizes',
}
payload['derived/source-reconstruction.json'] = (json.dumps(reconstruction, indent=2) + '\n').encode()
assert not any(Path(name).suffix.lower() in ['.dll', '.exe', '.lib', '.dylib', '.a', '.o', '.obj', '.zip'] for name in payload)
members = [{'member': name, 'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(payload.items())]
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(payload.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and sorted(z.namelist()) == sorted(payload)
    for item in members:
        assert sha(z.read(item['member'])) == item['sha256']
for path, expected in originals.items():
    assert digest(path) == expected, 'Original evidence changed: ' + path

fixtures = ['contracts', 'pipeline', 'pending', 'encoded', 'paged_joint', 'sampling', 'public_effect', 'symmetry']
record = {
    'schema_version': 1,
    'state': 'WINDOWS_V4_SOURCE_ORDINARY_AND_DEVICE_PASS_ONLY_GLOBAL_AGGREGATE_NOT_PASSED',
    'product_checkpoint': candidate,
    'audited_checkpoint': manifest['audited_checkpoint'],
    'archive': archive.name, 'archive_sha256': digest(archive), 'archive_bytes': archive.stat().st_size,
    'members': members,
    'runner_sha256': manifest['script_sha256'], 'original_manifest_sha256': digest(bundle / 'manifest.json'),
    'ordinary': {'aggregate': 'PASS_WINDOWS_SOURCE_ONLY', 'public_consumers': fixtures, 'all_eight_exit_zero': True,
                 'native_tests': {'RUN_COMPLETED': 4, 'failed': 0, 'skipped': 0},
                 'encoded_tests': {'RUN_COMPLETED': 3, 'failed': 0, 'skipped': 0}},
    'device': {'aggregate': 'PASS_WINDOWS_SOURCE_DEVICE_GATE_ONLY', 'all_nine_exit_zero': True,
               'independent_actual_activation_review': artifact(source / 'windows-source-device-review.json'),
               'contexts_with_Khronos_instance_device_and_sync_proof': 28,
               'validation_error_vuid_sync_hazard_messages': 0,
               'raw_loader_error_lines': 196,
               'raw_error_boundary': 'Missing per-user OBS manifest loader errors, OBS warnings and deprecated settings remain verbatim; zero Khronos validation errors is not zero raw errors.'},
    'source_compilation': {'objects': 48, 'SIMD_mtime_objects': 38, 'native_vulkan_run_objects': 1,
                           'fixture_objects': 9, 'new_shader_or_cuda_compilation': False,
                           'generated_DATA': 152, 'inner_generator': 'no work'},
    'binary_data_identity': {'built_artifacts_in_archive': False, 'all49_hashes': receipt['built_artifacts'],
                             'DATA_hashes_member': 'run-final-v4/windows-vulkan/source/plan.json /generated_152_data_before',
                             'full_source_archives_in_archive': False,
                             'source_reconstruction_member': 'derived/source-reconstruction.json',
                             'post_run_identity': artifact(source / 'post-run-identity.json')},
    'costs': {'inherited_command_seconds': 958.640,
              'Windows_command_seconds_this_checkpoint': receipt['cumulative_measured_command_seconds'],
              'Windows_cumulative_command_seconds': receipt['cumulative_measured_command_seconds_including_inherited'],
              'Windows_cumulative_rounded_seconds': 1175.780,
              'other_Air_costs': 'UNSETTLED_SEPARATE_CHECKPOINT_NOT_ADDED_TO_WINDOWS_TOTAL',
              'boundary': 'Inherited time is counted once. Air receipts also carry inherited time; their cumulative values must not be summed. All raw stage timing remains preserved.'},
    'inherited_failures': manifest['inherited_failures'],
    'prior_checkpoint': {'summary': artifact(out / 'ordinary-checkpoint-3.json'), 'archive': artifact(out / 'ordinary-checkpoint-3.zip'),
                         'V3_real_VUID_and_failed_receipt': 'Retained unchanged; source proof of V4 does not uniquely bind the old raw fence handle to its owner.'},
    'selector': {'plan_and_skipped_reasons_retained': True, 'all_selected_gates_executed_by_this_checkpoint': False},
    'Air_boundary': {'payload': 'Historical read-only cache blockers/staged plan/queue identity/entry transfer only. All Air source logs, plans and its updated receipt belong to cp5 and are excluded.',
                     'subsequent_fact_from_root': 'AirApple source device pending fixture exited -6 with resource-budget fatal 58368 > 32768 after cp4 Windows completion, triggering the final ordinary stop condition. Separate cp5 terminal owns this failure.',
                     'Air_aggregate': 'NOT_CERTIFIED_BY_CP4'},
    'SDK_boundary': {'preparation_only': artifact(scratch / 'windows-sdk-v4-readonly-preparation.json'),
                     'stages_executed': 0, 'current_status': 'STOPPED_AFTER_SUBSEQUENT_AIR_FAILURE',
                     'no_cache_runner_product_mutations': True},
    'stop': {'original_receipts_logs_modified': False, 'Windows_owned_build_fixture_processes_remaining': 0,
             'native_commands_during_archiving': 0, 'automatic_retries': 0, 'SDK_commands': 0,
             'selector_commands': 0, 'AA_commands': 0, 'P1_commands': 0, 'failure_budget_reset': False},
    'retention_preflight': {'corrections': 1, 'failure_record_member': 'ordinary-checkpoint-4-retention-preflight-failure.json',
                            'native_activity': 0, 'original_artifact_mutations': 0,
                            'boundary': 'Only retention helper path normalization was corrected before any archive output; no validation retry or verify entry change.'},
    'unqualified': 'This signs Windows source ordinary/device only. Air, host sanitizer/SDK delivery, selected-tool completion and P1/closure aggregates are not signed here. Global native work is stopped by the later Air ordinary failure.',
}
summary.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': digest(archive),
                  'summary': str(summary), 'summary_sha256': digest(summary), 'members': len(members), 'state': record['state']}, indent=2))
