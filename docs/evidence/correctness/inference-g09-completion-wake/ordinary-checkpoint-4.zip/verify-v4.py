"""One finite, explicitly staged G09 ordinary-validation entry. Never runs P1.

Preparation and plan are inert with respect to compilation/device execution.
Every configure/build/test/install stage additionally requires --execute-reviewed.
Copy this same script and its prepared bundle to Air; do not run old launchers.

Ordinary v4 preserves the original export-subst preparation failure, DATA-path
plan guard failure, and first build's omitted encoded-fixture GTest dependency.
The prior 958.640 measured command seconds, encoded-device numeric failure,
real resetFenceInUse VUID, Air PATH refusal and all failure budgets carry
forward. This copy adds only checkpoint3 metadata and the split-transfer native
case to the exact default4 selection; no budget or validation guard is reset.
"""
from pathlib import Path
import argparse,ctypes,fnmatch,hashlib,json,os,platform,re,signal,subprocess,sys,time,traceback,zipfile

P=argparse.ArgumentParser()
P.add_argument('--stage',required=True,choices=['prepare','sync','configure','plan','build','test','device','install','consumer-configure','consumer-plan','consumer-build','consumer-test'])
P.add_argument('--profile',choices=['windows-vulkan','air-vulkan','air-apple'])
P.add_argument('--facet',default='source',choices=['source','static','shared','asan','ubsan','tsan'])
P.add_argument('--candidate')
P.add_argument('--canonical',default='C:/public/project-hyle/hyle')
P.add_argument('--bundle',required=True)
P.add_argument('--execute-reviewed',action='store_true')
# Optional Vulkan lifecycle subsets are frozen once, at prepare, never per retry.
P.add_argument('--native-host-filter')
P.add_argument('--native-host-tests',type=int)
P.add_argument('--native-device-filter')
P.add_argument('--native-device-tests',type=int)
A=P.parse_args();B=Path(A.bundle).resolve();B.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda p:sha(Path(p).read_bytes())
def changed(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if not path.is_file() or path.read_bytes()!=data:path.write_bytes(data);return True
    return False
def git(*args):return subprocess.check_output(['git',*args],cwd=A.canonical)

if A.stage=='prepare':
    prepare_start=time.monotonic()
    original_exception_hook=sys.excepthook
    def prepare_failure(kind,error,tb):
        text=''.join(traceback.format_exception(kind,error,tb))
        failure=B/'prepare-failure.json'
        if failure.exists():failure=B/('prepare-failure-preserved-'+str(time.time_ns())+'.json')
        log=failure.with_suffix('.log');log.write_text(text)
        record={'state':'PREPARE_FAILED_STOPPED_BEFORE_SYNC_CONFIGURE_BUILD_GPU','candidate_argument':A.candidate,'runner_sha256':digest(__file__),'error':repr(error),'traceback_log':str(log),'seconds':time.monotonic()-prepare_start,'partial_archives':[{'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(B.glob('*.zip'))],'sync_commands':0,'configure_commands':0,'build_commands':0,'gpu_processes':0,'automatic_retries':0}
        failure.write_text(json.dumps(record,indent=2)+'\n');original_exception_hook(kind,error,tb)
    sys.excepthook=prepare_failure
    assert A.candidate and not (B/'manifest.json').exists(),'Preparation is one-shot; preserve prior bundle/receipts'
    candidate=git('rev-parse',A.candidate+'^{commit}').decode().strip()
    assert git('rev-parse','HEAD').decode().strip()==candidate
    paths=git('ls-tree','-r','--name-only',candidate).decode().splitlines()
    paths=[p for p in paths if not p.startswith(('evidence/','docs/')) or p=='docs/implementation/module-status.json']
    inputs=[];roots=sorted({name.split('/')[0] for name in paths if not name.startswith('docs/')})
    raw=B/'source.git-archive.raw.zip'
    raw.write_bytes(git('archive','--format=zip',candidate,'--',*roots,'docs/implementation/module-status.json'))
    metadata=git('show',candidate+':SOURCE-MANIFEST.txt')
    attributes=git('show',candidate+':.gitattributes')
    assert attributes.splitlines().count(b'SOURCE-MANIFEST.txt export-subst')==1
    assert metadata.count(b'$Format:%H$')==1
    expanded=metadata.replace(b'$Format:%H$',candidate.encode())
    with zipfile.ZipFile(raw) as original,zipfile.ZipFile(B/'source.zip','x') as canonical_zip:
        assert original.read('SOURCE-MANIFEST.txt')==expanded,'Unexpected export-subst mapping; do not generalize normalization'
        for member in original.infolist():
            data=original.read(member.filename)
            if member.filename=='SOURCE-MANIFEST.txt':data=metadata
            canonical_zip.writestr(member,data)
    with zipfile.ZipFile(raw) as original,zipfile.ZipFile(B/'source.zip') as canonical_zip:
        assert original.namelist()==canonical_zip.namelist()
        for name in original.namelist():
            assert canonical_zip.read(name)==(metadata if name=='SOURCE-MANIFEST.txt' else original.read(name)),name
    with zipfile.ZipFile(B/'source.zip') as z:
        for name in paths:
            data=z.read(name)
            assert Path(A.canonical,name).read_bytes()==data,'Canonical file differs from candidate: '+name
            inputs.append({'path':name,'sha256':sha(data),'bytes':len(data)})
    baseline=git('rev-parse','6b26cd4b2^{commit}').decode().strip()
    assert not any(line.startswith('D\t') for line in git('diff','--name-status',baseline,candidate).decode().splitlines()),'No implicit stale-file/deletion policy'
    # Reuse the exact already reviewed external Metal ObjC publication model.
    with zipfile.ZipFile(Path(A.canonical)/'evidence/architecture/inference-g09-metal-objc-tsan-tool/raw.zip') as z:
        original=z.read('canonical-apple_weights.mm');modeled=z.read('modeled-apple_weights.mm')
        assert original==git('show',candidate+':src/compute_route_apple/apple_weights.mm'),'External model contract changed; review separately'
        changed(B/'models/canonical-apple_weights.mm',original);changed(B/'models/modeled-apple_weights.mm',modeled)
    manifest={'candidate':candidate,'audited_checkpoint':baseline,'source_zip_sha256':digest(B/'source.zip'),'files':inputs,'script_sha256':digest(__file__),
      'model':{'canonical_sha256':sha(original),'modeled_sha256':sha(modeled),'qualification':'evidence/architecture/inference-g09-metal-objc-tsan-tool/tool-task.json; exact unchanged external edge only'},
      'scope':'Ordinary owner/direct-consumer/device/host/SDK validation only; no A/A/P1 and no original failure-budget reset'}
    manifest['exact_archive_metadata_mapping']={'member':'SOURCE-MANIFEST.txt','tracked_attribute':'SOURCE-MANIFEST.txt export-subst','gitattributes_blob_sha256':sha(attributes),'gitattributes_git_object':git('rev-parse',candidate+':.gitattributes').decode().strip(),'candidate_original_blob_sha256':sha(metadata),'raw_export_subst_member_sha256':sha(expanded),'raw_archive_sha256':digest(raw),'canonical_archive_sha256':digest(B/'source.zip'),'all_other_members_byte_identical':True,'prior_failed_bundle':'run-6c6222e51/prepare-failure.json','budget_reset':False}
    manifest['contexts']={}
    for name in ['context-windows-vulkan.json','context-air.json']:
        data=(Path(__file__).parent/name).read_bytes();changed(B/name,data);manifest['contexts'][name]=sha(data)
    inherited=Path(A.canonical)/'.scratch/g09-completion-wake-correction'
    old=inherited/'run-6c6222e51-prepare-correction1/windows-vulkan/source'
    manifest['inherited_failures']=[{'path':str(p),'sha256':digest(p)} for p in [
      inherited/'run-6c6222e51/prepare-failure.json',old/'receipt.json',old/'explicit-build-test-continuation.json']]
    checkpoint2=Path(A.canonical)/'evidence/correctness/inference-g09-completion-wake/ordinary-checkpoint-2.json'
    checkpoint=json.loads(checkpoint2.read_text());cost=checkpoint['costs']['cumulative_measured_command_seconds']
    assert abs(cost-718.405)<0.000001,'Review any additional inherited cost; never reset it'
    ordinary2=inherited/'run-e2a55aaab-ordinary-v2/windows-vulkan/source'
    manifest['inherited_failures'] += [{'path':str(p),'sha256':digest(p)} for p in [
      checkpoint2,checkpoint2.with_suffix('.zip'),ordinary2/'receipt.json',ordinary2/'device-encoded.json',ordinary2/'device-g09_wake_v2_encoded.log']]
    manifest['inherited_measured_command_seconds']=cost
    manifest['inherited_ordinary_checkpoint2']={'summary':str(checkpoint2),'summary_sha256':digest(checkpoint2),'rounded_command_seconds':718.405,'encoded_device_failure_preserved':True}
    checkpoint3=Path(A.canonical)/'evidence/correctness/inference-g09-completion-wake/ordinary-checkpoint-3.json'
    prior3=json.loads(checkpoint3.read_text());cost3=prior3['costs']['cumulative_measured_command_seconds']
    assert abs(cost3-958.640)<0.000001,'Review any additional inherited cost; never reset it'
    assert prior3['prior_checkpoint']['summary']['sha256']==digest(checkpoint2),'Original checkpoint2 changed'
    assert digest(checkpoint3.with_suffix('.zip'))==prior3['archive_sha256'],'Checkpoint3 archive changed'
    ordinary3=inherited/'run-native-retirement-v3/windows-vulkan/source'
    manifest['inherited_failures'] += [{'path':str(p),'sha256':digest(p)} for p in [
      checkpoint3,checkpoint3.with_suffix('.zip'),ordinary3/'receipt.json',ordinary3/'device-failure-stop.json',
      ordinary3/'device-encoded.json',ordinary3/'device-g09_wake_v3_encoded.log',ordinary3/'device-native-unit.json',
      inherited/'air-sync-path-refusal.json',inherited/'run-native-retirement-v3/air-apple/source/receipt.json']]
    manifest['inherited_measured_command_seconds']=cost3
    manifest['inherited_ordinary_checkpoint3']={'summary':str(checkpoint3),'summary_sha256':digest(checkpoint3),'rounded_command_seconds':958.640,
      'resetFenceInUse_VUID_failure_preserved':True,'Air_PATH_refusal_and_sync_only_preserved':True}
    def frozen_native_selection(relative,selected_filter,expected,default_filter,default_count):
        declarations=re.findall(r'TEST(?:_F)?\(\s*([A-Za-z_]\w*)\s*,\s*([A-Za-z_]\w*)\s*\)',git('show',candidate+':'+relative).decode())
        names=[suite+'.'+name for suite,name in declarations]
        custom=selected_filter is not None
        if custom:assert expected is not None and expected>0,'A custom native subset needs an explicit positive expected count'
        else:assert expected is None,'An expected-count override needs an explicit native filter'
        selected_filter=selected_filter or default_filter;expected=expected if custom else default_count
        assert re.fullmatch(r'[A-Za-z0-9_.*?:-]+',selected_filter),'Only the existing GTest filter grammar'
        positive,separator,negative=selected_filter.partition('-')
        selected=[name for name in names if any(fnmatch.fnmatchcase(name,p) for p in (positive or '*').split(':'))
                  and not any(fnmatch.fnmatchcase(name,p) for p in negative.split(':') if p)]
        assert len(selected)==expected and len(set(selected))==expected,(relative,selected_filter,selected,expected)
        return {'source':relative,'filter':selected_filter,'tests':expected,'names':selected,'custom_subset':custom,'whole_lifecycle_claim':False}
    assert re.search(r'TEST(?:_F)?\(\s*VulkanRetirementPublication\s*,\s*SplitTransferRequiresBothFenceSignals\s*\)',
      git('show',candidate+':tests/compute_route_vulkan/lifecycle_test.cc').decode()),'V4 split-transfer test is not declared in immutable candidate'
    vulkan_filter='VulkanLifetime.ManagedWaitAllowsIndependentProducerAndCancelledSlotReuse:VulkanRetirementPublication.*'
    manifest['native_unit_tests']={'vulkan':{
      'host':frozen_native_selection('tests/compute_route_vulkan/lifecycle_test.cc',A.native_host_filter,A.native_host_tests,vulkan_filter,4),
      'device':frozen_native_selection('tests/compute_route_vulkan/lifecycle_test.cc',A.native_device_filter,A.native_device_tests,vulkan_filter,4)},
      'apple':{phase:frozen_native_selection('tests/compute_route_apple/lifecycle_test.cc',None,None,'AppleCompletionNotification.*',4) for phase in ['host','device']}}
    manifest['budget_reset']=False
    # These are historical qualified receipts, not launchers. Bind every DATA
    # item to its original machine/facet before allowing the new finite plan.
    qualified={}
    archive=Path(A.canonical)/'evidence/delivery/inference-g09-air-sdk-checkpoint/raw.zip'
    for profile in ['windows-vulkan','air-vulkan']:
        qualified[profile]={}
        for prior_facet in ['source','static','shared']:
            field=('consumer' if prior_facet=='source' else 'producer')+('_original_generator_freshness' if profile.startswith('windows') else '_generated_shader_reuse')
            member=f'vulkan-{prior_facet}-1/result.json'
            if profile.startswith('windows'):
                p=Path(A.canonical)/'.scratch/inference-gaps/g09-sdk-windows'/member
                raw=p.read_bytes();origin={'path':str(p),'sha256':sha(raw)}
            else:
                with zipfile.ZipFile(archive) as z:raw=z.read(member)
                origin={'archive':str(archive),'archive_sha256':digest(archive),'member':member,'member_sha256':sha(raw)}
            report=json.loads(raw);items=report[field]['generated_152_data' if profile.startswith('windows') else 'copied'];assert len(items)==152
            qualified[profile][prior_facet]={'origin':origin,'field':field,'data':[{'path':x['path'],'sha256':x['sha256'],'bytes':x['bytes']} for x in items]}
    manifest['qualified_same_facet_vulkan_data']=qualified
    (B/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'state':'PREPARED_NO_BUILD_NO_GPU','candidate':candidate,'files':len(inputs),'manifest_sha256':digest(B/'manifest.json')},indent=2));sys.exit(0)

assert all(getattr(A,key) is None for key in ['native_host_filter','native_host_tests','native_device_filter','native_device_tests']),'Native filters/counts are prepare-only; a failure never permits a per-stage subset change'
assert A.profile
M=json.loads((B/'manifest.json').read_text());assert digest(__file__)==M['script_sha256'],'Runner changed after freeze'
assert digest(B/'source.zip')==M['source_zip_sha256']
for name,value in M['contexts'].items():assert digest(B/name)==value,name
WIN=A.profile.startswith('windows');route=A.profile.split('-')[1]
assert WIN==(os.name=='nt') and (WIN or platform.system()=='Darwin')
if not WIN:assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
base=Path('C:/h7') if WIN else Path('/Users/kiro/hyle-scratch/compute-unified')
S=Path(A.canonical).resolve() if WIN else base/'source-c8874688'
facet=A.facet;san=facet in ['asan','ubsan','tsan']
assert not (WIN and san),'Use the actual Air host sanitizer profiles; no invented Windows runtime support'
family=base/'w-cpu-vulkan/selected-graph' if WIN else base/f'a-cpu-{route}/selected-graph'
if san:build=base/f'foundation-f5-native-host-{route}-{facet}/build'
elif facet=='source':build=family/'source-build'
else:build=(base/'w-vulkan/selected-graph' if WIN else family)/(facet+'-sdk-build')
assert build.is_dir(),build
O=B/A.profile/facet;O.mkdir(parents=True,exist_ok=True)
receipt=O/'receipt.json'
R=json.loads(receipt.read_text()) if receipt.exists() else {'candidate':M['candidate'],'profile':A.profile,'facet':facet,'steps':[],'failures':[],'scope':M['scope'],'inherited_failures':M['inherited_failures'],'inherited_measured_command_seconds':M['inherited_measured_command_seconds'],'budget_reset':False}
assert R['candidate']==M['candidate'] and not R['failures'],'Stop after failure; retain receipt and obtain finite correction review'
assert not any(x['stage']==A.stage for x in R['steps']),'Stage already recorded; no implicit rerun'
prerequisite={'configure':'sync','plan':'configure','build':'plan','test':'build','device':'test','install':'build','consumer-configure':'install','consumer-plan':'consumer-configure','consumer-build':'consumer-plan','consumer-test':'consumer-build'}
if A.stage in prerequisite:assert any(x['stage']==prerequisite[A.stage] for x in R['steps']),'Missing prerequisite stage: '+prerequisite[A.stage]
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
if WIN:
    envcmd=S/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd'
    expected_envcmd=R.setdefault('windows_envcmd',{'path':str(envcmd),'sha256':digest(envcmd)})
    assert digest(envcmd)==expected_envcmd['sha256']
    setup=subprocess.check_output(['cmd','/d','/c',str(envcmd)],text=True,errors='replace')
    assert digest(envcmd)==expected_envcmd['sha256']
    env={k.upper():v for k,v in env.items()}
    env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
    env['VSLANG']='1033'
else:
    env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env.get('PATH','')
    os.nice(10)
env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0')
if san:env['HYLE_VULKAN_VALIDATION']='0'
cmake='cmake' if WIN else '/opt/homebrew/bin/cmake'
ninja='C:/PROGRA~1/PYTHON~1/Scripts/ninja.exe' if WIN else '/opt/homebrew/bin/ninja'
cache=dict((line.split('=',1)[0].split(':',1)[0],line.split('=',1)[1]) for line in (build/'CMakeCache.txt').read_text().splitlines() if '=' in line and not line.startswith(('#','//')))
parent=Path(cache['CMAKE_HOME_DIRECTORY']);assert parent.is_dir()
assert Path(cache['hyle_SOURCE_DIR']).resolve()==S.resolve(),'Cached product source differs from frozen canonical/forward replica'
parent_file=parent/'CMakeLists.txt'
expected_parent=R.setdefault('external_parent',{'path':str(parent_file),'sha256':digest(parent_file)})
assert digest(parent_file)==expected_parent['sha256'],'External parent changed after stage freeze'
if san:assert cache['HYLE_SANITIZER']==facet
context=json.loads((B/('context-windows-vulkan.json' if WIN else 'context-air.json')).read_text())
assert Path(cache['CMAKE_CXX_COMPILER']).resolve()==Path(context['toolchain']['compiler_path']).resolve(),'Cached compiler path differs from selected context'
if not san:
    for name,value in context['toolchain']['flags'].items():assert cache[name]==value,(name,cache[name],value)
R['selected_context']=context
model_includes=[]
if facet=='tsan':
    model_includes=sorted(set(re.findall(r'target_include_directories\(g09_(?:common|contracts|pipeline) BEFORE PRIVATE "([^"]+)"\)',(parent/'CMakeLists.txt').read_text())))
    assert model_includes,'Original qualified TSan observation include paths are required'
    ref=[Path(p)/'hyle/util/ref_counted.h' for p in model_includes if (Path(p)/'hyle/util/ref_counted.h').is_file()]
    assert len(ref)==1 and digest(ref[0])=='2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
    if route=='apple':
        metal=[Path(p)/'Metal/MTLCommandBuffer.hpp' for p in model_includes if (Path(p)/'Metal/MTLCommandBuffer.hpp').is_file()]
        assert len(metal)==1 and digest(metal[0])=='4a58c6e564e3a7efcdf5c7709eeee99ec7b7c40594e2ada5ec5c91012171d504'
    R['qualified_original_model_inputs']=[{'path':str(p),'sha256':digest(p)} for p in ref+([] if route!='apple' else metal)]
def save():receipt.write_text(json.dumps(R,indent=2)+'\n')
def verify_source():
    if WIN:assert git('rev-parse','HEAD').decode().strip()==M['candidate']
    for item in M['files']:
        p=S/item['path'];expected=item['sha256']
        if not WIN and route=='apple' and facet=='tsan' and item['path']=='src/compute_route_apple/apple_weights.mm':
            assert digest(p) in [expected,M['model']['modeled_sha256']];continue
        assert p.is_file() and digest(p)==expected,'Source identity: '+str(p)
def artifact(path):
    p=Path(path);return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
def gtest_reuse_receipt():
    source_output=B/A.profile/'source'
    source_receipt=json.loads((source_output/'receipt.json').read_text())
    assert artifact(source_output/'gtest-reuse.json')==source_receipt['gtest_reuse']
    record=json.loads((source_output/'gtest-reuse.json').read_text())
    assert record['candidate']==M['candidate'] and record['profile']==A.profile
    for item in record['artifacts']:assert artifact(item['path'])==item,'Qualified source GTest reuse changed'
    return record
def command(label,args,extra=None,timeout=1800):
    log=O/(A.stage+'-'+label+'.log');assert not log.exists(),log
    start=time.monotonic();flags={};child=None
    if WIN:flags['creationflags']=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS
    else:flags['start_new_session']=True
    item={'label':label,'command':list(map(str,args)),'log':str(log)};R['active']=item;save()
    def cleanup():
        if WIN:
            subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        else:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        child.wait()
    try:
        with log.open('wb') as stream:
            child=subprocess.Popen(list(map(str,args)),cwd=S,env=dict(env,**(extra or {})),stdout=stream,stderr=subprocess.STDOUT,**flags)
            if WIN:
                k=ctypes.windll.kernel32;k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)];k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
                available=ctypes.c_size_t();system=ctypes.c_size_t();h=ctypes.c_void_p(int(child._handle))
                assert k.GetProcessAffinityMask(h,ctypes.byref(available),ctypes.byref(system))
                mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4]);assert k.SetProcessAffinityMask(h,mask);item['affinity_mask']=hex(mask)
            item['child_pid']=child.pid;save();code=child.wait(timeout=timeout)
            if code:cleanup()
    except BaseException:
        if child is not None:cleanup()
        raise
    finally:
        item.update(seconds=time.monotonic()-start,log_sha256=digest(log));R.pop('active',None);R.setdefault('commands',[]).append(item);save()
    item['exit_code']=code;save();assert code==0,(label,code,log)
    return log.read_text(errors='replace')

fixtures={
 'contracts':(f'tests/graph/cpu_{route}_contracts.cc',[]),
 'pipeline':('tests/graph/native_joint_pipeline.cc',['HYLE_G09_APPLE=1'] if route=='apple' else []),
 'pending':('tests/compute_batch/pending_paged_receiver_native_consumer.cc',['HYLE_PENDING_NATIVE_JOINT_GRAPH=1']+(['HYLE_PENDING_RECEIVER_APPLE=1'] if route=='apple' else [])),
 'encoded':('tests/compute_batch/encoded_page_native_consumer.cc',['HYLE_ENCODED_APPLE=1'] if route=='apple' else []),
 'paged_joint':('tests/graph_batch/native_paged_joint_consumer.cc',['HYLE_JOINT_PAGE_APPLE=1'] if route=='apple' else []),
 'sampling':(f'tests/graph_route_cpu_{route}/sampling_consumer.cc',[]),
 'public_effect':('tests/graph/public_effect_consumer.cc',[]),
 'symmetry':(f'tests/graph/route_symmetry_{route}.cc',['HYLE_FOUNDATION_A_HYBRID=1'])}
target_prefix='g09_wake_v4_'
targets=[target_prefix+name for name in fixtures]
native_target=(not WIN and route=='apple' and facet in ['source','shared','asan','ubsan','tsan']) or (route=='vulkan' and facet in ['source','asan','ubsan','tsan'])
def fixture_cmake(source,installed=False):
    text='\n# BEGIN G09_WAKE_CORRECTION_FINITE_V4\n'
    if not installed:text+='if(NOT TARGET GTest::gtest_main)\n message(FATAL_ERROR "Reuse original qualified GTest target; do not fetch a new dependency")\nendif()\n'
    for name,(relative,defs) in fixtures.items():
        target=target_prefix+name
        text+=f'add_executable({target} "{(source/relative).as_posix()}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_link_libraries({target} PRIVATE hyle::compute hyle::graph)\n'
        if name=='encoded':text+=f'target_link_libraries({target} PRIVATE GTest::gtest_main)\n'
        if defs:text+=f'target_compile_definitions({target} PRIVATE '+ ' '.join(defs)+')\n'
        if san:text+=f'hyle_apply_sanitizer({target})\n'
        for include in model_includes:text+=f'target_include_directories({target} BEFORE PRIVATE "{include}")\n'
        text+=f'set_target_properties({target} PROPERTIES RUNTIME_OUTPUT_DIRECTORY "{(O/"bin").as_posix()}")\nhyle_stage_runtime({target})\n'
    if not installed and native_target:
        target=target_prefix+'native_unit'
        text+=f'add_executable({target} "'+(S/f'tests/compute_route_{route}/lifecycle_test.cc').as_posix()+'")\n'
        text+=f'target_compile_features({target} PRIVATE cxx_std_23)\ntarget_link_libraries({target} PRIVATE hyle::compute GTest::gtest_main)\n'
        text+=f'target_include_directories({target} PRIVATE "'+(S/f'src/compute_route_{route}').as_posix()+'")\n'
        if route=='vulkan':
            # Exact private seam from tests/compute_route_vulkan/CMakeLists.txt.
            # The wrapper parent need not inherit HYLE_GGML_SOURCE_DIR; ggml's
            # declaration is in that locked source's src/CMakeLists.txt.
            text+='get_target_property(_g09_native_ggml_src ggml SOURCE_DIR)\n'
            text+='if(NOT EXISTS "${_g09_native_ggml_src}/ggml-backend-impl.h")\n message(FATAL_ERROR "Bind original ggml private src directory")\nendif()\n'
            text+=f'target_include_directories({target} PRIVATE "'+(S/'src/compute').as_posix()+'")\n'
            text+=f'target_include_directories({target} SYSTEM PRIVATE "${{_g09_native_ggml_src}}")\n'
            text+=f'target_link_libraries({target} PRIVATE hyle_compute_provider_ggml_vulkan hyle_compute_ggml_runtime ggml)\n'
        if san:text+=f'hyle_apply_sanitizer({target})\n'
        for include in model_includes:text+=f'target_include_directories({target} BEFORE PRIVATE "{include}")\n'
        text+=f'set_target_properties({target} PROPERTIES RUNTIME_OUTPUT_DIRECTORY "'+(O/'bin').as_posix()+f'")\nhyle_stage_runtime({target})\n'
    if not installed and facet=='source':
        text+='export(TARGETS gtest gtest_main NAMESPACE GTest:: FILE "'+(O/'GTestReuseTargets.cmake').as_posix()+'")\n'
        text+='file(GENERATE OUTPUT "'+(O/'gtest-reuse-paths.txt').as_posix()+'" CONTENT "$<TARGET_FILE:gtest>\\n$<TARGET_FILE:gtest_main>\\n$<TARGET_PROPERTY:gtest,SOURCE_DIR>\\n$<TARGET_GENEX_EVAL:gtest,$<TARGET_PROPERTY:gtest,INTERFACE_INCLUDE_DIRECTORIES>>\\n")\n'
    text+='# END G09_WAKE_CORRECTION_FINITE_V4\n';return text
producer_targets=['hyle_compute','hyle_compute_ops','hyle_compute_batch','hyle_compute_state','hyle_compute_stream','hyle_graph','hyle_graph_batch',f'hyle_compute_route_{route}',f'hyle_graph_route_{route}',f'hyle_graph_route_cpu_{route}']
consumer=A.stage.startswith('consumer-');actual_build=O/'consumer-build' if consumer else build
requested=targets+([target_prefix+'native_unit'] if native_target and facet not in ['static','shared'] else [])
if facet in ['static','shared'] and not consumer:requested=producer_targets
if consumer:requested=targets+[target_prefix+'headers']
def make_plan():
    preview=O/('consumer-preview.ninja' if consumer else 'preview.ninja')
    changed(preview,(actual_build/'build.ninja').read_bytes())
    text=command('dry-run',[ninja,'-C',actual_build,'-f',preview,'-n',*requested])
    assert 'Re-running CMake' not in text,'Explicit configure/manifest must finish before finite plan'
    assert not re.search(r'Building CUDA object|Generate vulkan shaders|Generating.*(?:\.spv|vulkan-shaders)',text,re.I),'Unexpected native shader/CUDA recompile; stop for identity review'
    assert len(text.splitlines())<200,'Unexpected broad rebuild; inspect before changing guard'
    commands=json.loads(subprocess.check_output([ninja,'-C',str(actual_build),'-t','compdb'],env=env,text=True))
    generated=[]
    if route=='vulkan' and not consumer:
        layout=actual_build/'hyle' if (actual_build/'hyle/src').is_dir() else actual_build
        generator=layout/'_deps/gg-5909b243d5fdb965/src/vulkan-shaders-gen-build'
        assert generator.is_dir(),generator
        inner=command('original-generator-freshness',[ninja,'-C',generator,'-n'])
        assert 'ninja: no work to do.' in inner and 'Building ' not in inner and 'Re-running CMake' not in inner
        data=layout/'src/compute_ggml_runtime/vendor/src/ggml-vulkan'
        files=[*sorted(data.glob('*.cpp')),data/'ggml-vulkan-shaders.hpp'];assert len(files)==152
        generated=[artifact(p) for p in files]
        if not san:
            prior=M['qualified_same_facet_vulkan_data'][A.profile][facet]
            by_path={str(Path(x['path']).resolve()):x for x in prior['data']};assert len(by_path)==152
            for item in generated:assert item==by_path.get(str(Path(item['path']).resolve())),'DATA differs from original qualified same facet: '+item['path']
            R['qualified_same_facet_vulkan_data']=prior['origin']
    plan={'fixture_counts':{'public_fixtures':len(fixtures),'source_native_unit':int(native_target and not consumer and facet not in ['static','shared'])},'native_unit_contract':M['native_unit_tests'][route] if native_target and not consumer else None,'build_ninja':artifact(actual_build/'build.ninja'),'preview':artifact(preview),'targets':requested,'dry_run':text,'compiled_lines':[line for line in text.splitlines() if 'Building ' in line],'commands':commands,'generated_152_data_before':generated,'source_manifest_sha256':digest(B/'manifest.json')}
    changed(O/('consumer-plan.json' if consumer else 'plan.json'),(json.dumps(plan,indent=2)+'\n').encode());return plan
def test_all(device=False):
    for item in R['built_artifacts']:assert artifact(item['path'])==item
    paths=[]
    for name in targets:
        binary=O/'bin'/(name+('.exe' if WIN else ''));assert binary.is_file(),binary;paths.append(artifact(binary))
        run_env=dict(device_environment) if device else {}
        if consumer:
            if WIN:
                compiler=Path(cache['CMAKE_CXX_COMPILER']);dumpbin=compiler.with_name('dumpbin.exe');pending=[binary];seen=set()
                while pending:
                    image=pending.pop()
                    if image.name.lower() in seen:continue
                    seen.add(image.name.lower())
                    deps=subprocess.check_output([str(dumpbin),'/nologo','/dependents',str(image)],env=env,text=True,errors='replace')
                    changed(O/(image.name+'-dependents.txt'),deps.encode())
                    for dll in re.findall(r'^\s+(hyle_[^\s]+\.dll)\s*$',deps,re.M|re.I):
                        staged=O/'bin'/dll;matches=[p for p in (O/'relocated').rglob(dll) if p.is_file()]
                        assert staged.is_file() and len(matches)==1 and digest(staged)==digest(matches[0]),dll
                        R.setdefault('staged_runtime',[]).append(artifact(staged));pending.append(staged)
                run_env['PATH']=';'.join(p for p in env['PATH'].split(';') if p and not Path(p).resolve().is_relative_to(S) and not Path(p).resolve().is_relative_to(build.resolve()))
            else:
                deps=subprocess.check_output(['otool','-L',str(binary)],text=True)
                changed(O/(name+'-dependencies.txt'),deps.encode());assert str(S) not in deps and str(build) not in deps
                run_env['DYLD_PRINT_LIBRARIES']='1'
        args=[binary]
        if name==target_prefix+'encoded':
            output=O/(A.stage+'-encoded.json');assert not output.exists()
            args+=['--gtest_filter=EncodedNativePages.*','--gtest_output=json:'+str(output)]
        text=command(name,args,run_env,timeout=600)
        assert artifact(binary)==paths[-1],'Application binary changed during execution'
        if name==target_prefix+'encoded':
            report=json.loads(output.read_text());expected_count=4 if route=='apple' else 3
            assert report['tests']==expected_count and report['failures']==0 and report.get('disabled',0)==0
            suites=report['testsuites'];assert len(suites)==1 and suites[0]['name']=='EncodedNativePages'
            cases=suites[0]['testsuite'];assert len(cases)==expected_count
            assert all(x['status']=='RUN' and x['result']=='COMPLETED' and not x.get('failures') for x in cases),'Missing, skipped, or failed encoded native test'
            paths.append(artifact(output));R.setdefault('encoded_test_reports',[]).append({'stage':A.stage,'tests':expected_count,'report':artifact(output)})
        if consumer and not WIN:
            loaded=re.findall(r'^dyld\[[^]]+\]:[^\n]* (/[^\n]+)',text,re.M)
            hyle=[p for p in loaded if '/libhyle_' in p];assert hyle,'Missing actual dyld HYLE identity'
            for path in hyle:
                p=Path(path);assert p.resolve().is_relative_to((O/'relocated').resolve()) or p.resolve().is_relative_to((O/'bin').resolve()),path
                R.setdefault('actual_dyld_hyle',[]).append(artifact(p))
        if name.endswith('pipeline'):
            cases=[json.loads(line) for line in text.splitlines() if line.startswith('{"case":')]
            expected={('cpu-first',1,False),('gpu-first',1,False),('cpu-first',2,False),('gpu-first',2,False),('gpu-first',2,True)}
            observed={(r['case'],r['workers'],r['native_input']) for r in cases if r['changed_steps']==65 and r['slots']==2 and r['oracle']=='PASS'}
            assert expected<=observed,'Missing finite ordinary pipeline cases'
    if native_target and not consumer and facet not in ['static','shared']:
        binary=O/'bin'/(target_prefix+'native_unit'+('.exe' if WIN else ''));output=O/(A.stage+'-native-unit.json')
        assert binary.is_file() and not output.exists()
        selection=M['native_unit_tests'][route]['device' if device else 'host']
        run_env=dict(device_environment) if device else {}
        if device and route=='vulkan':run_env['HYLE_VULKAN_VALIDATION']='1'
        before=artifact(binary)
        command('native-unit',[binary,'--gtest_filter='+selection['filter'],'--gtest_output=json:'+str(output)],run_env,timeout=600)
        assert artifact(binary)==before
        report=json.loads(output.read_text())
        assert report['tests']==selection['tests'] and report['failures']==0 and report.get('disabled',0)==0 and report.get('errors',0)==0
        cases=[(suite['name'],case) for suite in report['testsuites'] for case in suite['testsuite']]
        assert len(cases)==selection['tests'] and sorted(suite+'.'+case['name'] for suite,case in cases)==sorted(selection['names'])
        assert all(case['status']=='RUN' and case['result']=='COMPLETED' and not case.get('failures') for _,case in cases),'Missing, skipped, or failed finite native unit case'
        paths.append(before);paths.append(artifact(output))
        R.setdefault('native_unit_reports',[]).append({'stage':A.stage,'selection':selection,'report':artifact(output),'whole_lifecycle_claim':False})
    R.setdefault('artifacts',[]).extend(paths)
    for item in R['built_artifacts']:assert artifact(item['path'])==item

start=time.monotonic()
try:
    if A.stage=='sync':
        if WIN:verify_source();R['sync']='Windows reads immutable canonical candidate directly, preserving original cached compile paths'
        else:
            synced=[]
            with zipfile.ZipFile(B/'source.zip') as z:
                for item in M['files']:
                    relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
                    p=S/relative;assert p.resolve().is_relative_to(S.resolve())
                    data=z.read(item['path']);assert sha(data)==item['sha256']
                    if changed(p,data):synced.append(item['path'])
            R['incrementally_synced_paths']=synced
        verify_source()
    else:
        verify_source()
        if A.stage not in ['plan','consumer-plan']:assert A.execute_reviewed,'Root review/serial GO required for this exact stage'
        R['identity']={'platform':platform.platform(),'compiler':cache['CMAKE_CXX_COMPILER'],'facet':facet,'source':str(S),'cached_build':str(build)}
        if not WIN:R['identity'].update(model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),os=subprocess.check_output(['sw_vers'],text=True),compiler_version=subprocess.check_output(['xcrun','clang++','--version'],env=env,text=True))
        if A.stage=='configure':
            if facet=='tsan' and route=='apple':
                assert not WIN;changed(S/'src/compute_route_apple/apple_weights.mm',(B/'models/modeled-apple_weights.mm').read_bytes());R['external_objc_model']=M['model']
            if facet in ['source','asan','ubsan','tsan']:
                file=parent/'CMakeLists.txt';text=file.read_text();assert 'G09_WAKE_CORRECTION_FINITE_V4' not in text
                changed(O/'original-parent.cmake',file.read_bytes());addition=fixture_cmake(S)
                changed(file,(text+addition).encode())
                R['external_parent']['sha256']=digest(file)
                command('configure',[cmake,'-S',parent,'-B',build,'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
            else:
                command('configure',[cmake,'-S',S,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_SANITIZER=off','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu;'+route,'-DHYLE_STATIC='+('ON' if facet=='static' else 'OFF'),'-UCMAKE_PROJECT_INCLUDE','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
            command('manifest',[ninja,'-C',build,'build.ninja'])
            if facet=='source':
                paths=(O/'gtest-reuse-paths.txt').read_text().splitlines();assert len(paths)==4,paths
                libraries=list(map(Path,paths[:2]));gtest_source=Path(paths[2]);includes=[Path(p) for p in paths[3].split(';') if p]
                assert len(libraries)==2 and all(p.is_file() for p in libraries)
                assert (gtest_source/'include/gtest/gtest.h').is_file() and (gtest_source/'CMakeLists.txt').is_file()
                assert any((p/'gtest/gtest.h').is_file() for p in includes)
                artifacts=[artifact(O/'GTestReuseTargets.cmake'),artifact(O/'gtest-reuse-paths.txt'),*[artifact(p) for p in libraries],artifact(gtest_source/'CMakeLists.txt')]
                artifacts += [artifact(p) for p in sorted((gtest_source/'include').rglob('*')) if p.is_file()]
                reuse={'candidate':M['candidate'],'profile':A.profile,'qualification':'Existing same-machine source-parent GTest::gtest_main; no fetch or product SDK dependency','artifacts':artifacts,'libraries':list(map(str,libraries)),'gtest_source':str(gtest_source),'include_directories':list(map(str,includes))}
                changed(O/'gtest-reuse.json',(json.dumps(reuse,indent=2)+'\n').encode());R['gtest_reuse']=artifact(O/'gtest-reuse.json')
        elif A.stage in ['plan','consumer-plan']:make_plan()
        elif A.stage in ['build','consumer-build']:
            plan=json.loads((O/('consumer-plan.json' if consumer else 'plan.json')).read_text());assert artifact(actual_build/'build.ninja')==plan['build_ninja'] and requested==plan['targets']
            assert artifact(plan['preview']['path'])==plan['preview']
            for item in plan['generated_152_data_before']:assert artifact(item['path'])==item
            command('build',[ninja,'-C',actual_build,'-f',plan['preview']['path'],'-j','2',*requested])
            for item in plan['generated_152_data_before']:assert artifact(item['path'])==item
            if consumer or facet not in ['static','shared']:
                R['built_artifacts']=[artifact(p) for p in sorted((O/'bin').iterdir()) if p.is_file()]
                assert all(any(Path(x['path']).name==t+('.exe' if WIN else '') for x in R['built_artifacts']) for t in requested if t!=target_prefix+'headers')
        elif A.stage=='install':
            assert facet in ['static','shared']
            staging=O/'staging';prefix=O/'relocated';assert not staging.exists() and not prefix.exists()
            assert staging.resolve().is_relative_to(O.resolve()) and prefix.resolve().is_relative_to(O.resolve())
            command('install',[cmake,'--install',build,'--prefix',staging]);staging.rename(prefix)
            R['installed_files']=[artifact(p) for p in sorted(prefix.rglob('*')) if p.is_file()]
        elif A.stage=='consumer-configure':
            assert facet in ['static','shared'];prefix=O/'relocated';assert prefix.is_dir() and not (O/'staging').exists()
            source=O/'consumer';copied=set()
            def copy(relative):
                if relative in copied:return
                p=(S/relative).resolve();assert p.is_relative_to(S.resolve()) and relative.split('/')[0] in ['tests','samples']
                data=p.read_bytes();changed(source/relative,data);copied.add(relative)
                for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode(),re.M):
                    if not inc.startswith('hyle/'):copy((p.parent/inc).resolve().relative_to(S.resolve()).as_posix())
            for relative,_ in fixtures.values():copy(relative)
            R['copied_consumer_files']=[artifact(source/name) for name in sorted(copied)]
            reuse=gtest_reuse_receipt();R['source_gtest_reuse']=artifact(B/A.profile/'source/gtest-reuse.json')
            text='cmake_minimum_required(VERSION 3.25)\nproject(g09_wake_public_sdk LANGUAGES CXX)\nfind_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\nfind_package(Threads REQUIRED)\ninclude("'+(B/A.profile/'source/GTestReuseTargets.cmake').as_posix()+'")\n'+fixture_cmake(source,installed=True)
            for i,header in enumerate(['graph/cpu.h',f'graph/cpu_{route}.h']):
                assert digest(prefix/'include/hyle'/header)==digest(S/'include/hyle'/header)
                changed(source/f'header-{i}.cc',('#include <hyle/'+header+'>\n').encode())
            target=target_prefix+'headers';text+=f'add_library({target} OBJECT header-0.cc header-1.cc)\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_link_libraries({target} PRIVATE hyle::compute hyle::graph)\n'
            changed(source/'CMakeLists.txt',text.encode());command('configure',[cmake,'-S',source,'-B',actual_build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
            rows=json.loads((actual_build/'compile_commands.json').read_text());assert rows
            for row in rows:
                cmd=row['command'].replace('\\','/')
                assert (S/'include').as_posix() not in cmd and (S/'src').as_posix() not in cmd and build.as_posix() not in cmd
                assert (prefix/'include').as_posix() in cmd and 'HYLE_TESTING' not in cmd and '-fsanitize=' not in cmd
            changed(O/'installed-only-consumer-commands.json',(json.dumps(rows,indent=2)+'\n').encode())
        elif A.stage in ['test','consumer-test']:test_all()
        elif A.stage=='device':
            assert facet=='source'
            if route=='apple':device_environment={'MTL_DEBUG_LAYER':'1','MTL_SHADER_VALIDATION':'1'}
            elif WIN:device_environment={'PATH':'C:/public/tools/hyle-vulkan/1.4.357.0/Bin;'+env['PATH'],'VK_LAYER_PATH':'C:/public/tools/hyle-vulkan/1.4.357.0/Bin','VK_INSTANCE_LAYERS':'VK_LAYER_KHRONOS_validation','VK_LOADER_DEBUG':'error,warn,layer','VK_LAYER_ENABLES':'VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT'}
            else:raise RuntimeError('Air Vulkan math runs in source test; no unqualified Metal validation layer substitution')
            test_all(device=True)
            for p in O.glob('device-*.log'):
                text=p.read_text(errors='replace');assert not any(x in text for x in ['Validation Error','VUID-','SYNC-HAZARD','Shader Validation Error','failed assertion']),p
            R['device_activation']='REQUIRES_INDEPENDENT_ACTUAL_LAYER_ACTIVATION_REVIEW; exit zero alone is not PASS'
        verify_source()
        assert digest(parent_file)==R['external_parent']['sha256']
    R['steps'].append({'stage':A.stage,'state':'STEP_COMPLETE_NOT_AGGREGATE','seconds':time.monotonic()-start});save()
except BaseException as error:
    R['failures'].append({'stage':A.stage,'error':repr(error),'seconds':time.monotonic()-start});save();raise
finally:
    if not WIN and route=='apple' and facet=='tsan' and A.stage=='test':
        changed(S/'src/compute_route_apple/apple_weights.mm',(B/'models/canonical-apple_weights.mm').read_bytes())
        R['external_objc_model_source_restored']=digest(S/'src/compute_route_apple/apple_weights.mm')==M['model']['canonical_sha256']
    R['cumulative_measured_command_seconds']=sum(x['seconds'] for x in R.get('commands',[]));save()
    R['cumulative_measured_command_seconds_including_inherited']=M['inherited_measured_command_seconds']+R['cumulative_measured_command_seconds'];save()
print(json.dumps({'state':'STAGE_COMPLETE_NOT_AGGREGATE','profile':A.profile,'facet':facet,'stage':A.stage,'receipt':str(receipt)},indent=2))
