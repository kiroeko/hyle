"""One explicit Windows build -> eight ordinary fixtures; prior failures stay sealed."""
from pathlib import Path
import argparse,ctypes,hashlib,json,os,subprocess,time,traceback

p=argparse.ArgumentParser();p.add_argument('--execute-reviewed',action='store_true');a=p.parse_args()
assert a.execute_reviewed and os.name=='nt'
S=Path('C:/public/project-hyle/hyle');B=S/'.scratch/g09-completion-wake-correction/run-6c6222e51-prepare-correction1'
O=B/'windows-vulkan/source';build=Path('C:/h7/w-cpu-vulkan/selected-graph/source-build')
record=O/'explicit-build-test-continuation.json';assert not record.exists(),'One shot; retain any prior failure'
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fixed={'manifest.json':'2382a3b09fd86d1f1e36ed775ce45c24a3ca2e6fe06ccc19047ee6caa09f144c','windows-vulkan/source/plan-readonly-supplement.json':'c43e0110c443969e64fca92bba5e4febaf69f881b0dfa53c61cf36f3d478c520'}
for relative,sha in fixed.items():assert digest(B/relative)==sha,relative
M=json.loads((B/'manifest.json').read_text());Q=json.loads((O/'plan-readonly-supplement.json').read_text());prior=json.loads((O/'receipt.json').read_text())
assert digest(O/'receipt.json')==Q['original_receipt_sha256'] and prior['failures']==[{'stage':'plan','error':'AssertionError()','seconds':prior['failures'][0]['seconds']}]
assert digest(S/'.scratch/g09-completion-wake-correction/verify.py')==M['script_sha256']=='18e0460ef38ad113b34a0002291dabfbdcebca6539898c7d68c17c34f08586e2'
assert Q['all152_match_prior'] and Q['current_count']==Q['qualified_prior_count']==152
assert digest(O/'preview.ninja')==Q['preview_sha256'] and digest(Q['compile_database']['path'])==Q['compile_database']['sha256']
assert digest(S/Q['qualified_prior_receipt'])==Q['qualified_prior_receipt_sha256']
envcmd=Path(prior['windows_envcmd']['path']);assert digest(envcmd)==prior['windows_envcmd']['sha256']
parent=Path(prior['external_parent']['path']);assert digest(parent)==prior['external_parent']['sha256']
setup=subprocess.check_output(['cmd','/d','/c',str(envcmd)],text=True,errors='replace')
env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env.update(VSLANG='1033',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
names=['contracts','pipeline','pending','encoded','paged_joint','sampling','public_effect','symmetry'];targets=['g09_wake_'+x for x in names]
R={'state':'RUNNING_EXPLICIT_CONTINUATION','candidate':M['candidate'],'helper_sha256':digest(__file__),'original_inputs':fixed,'original_receipt_sha256':digest(O/'receipt.json'),'original_failures':prior['failures'],'original_measured_command_seconds':prior['cumulative_measured_command_seconds'],'prior_prepare_failure':str(B.parent/'run-6c6222e51/prepare-failure.json'),'no_budget_reset':True,'targets':targets,'commands':[],'failures':[],'scope':'One existing-preview Ninja -j2 build and eight original ordinary public fixtures. No configure/prepare/device/Air/P1.'}
def save():record.write_text(json.dumps(R,indent=2)+'\n')
def artifact(path):p=Path(path);return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
def inputs():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==M['candidate']
    for item in M['files']:assert digest(S/item['path'])==item['sha256'],item['path']
    for item in Q['data']:assert artifact(item['path'])==item,item['path']
    assert digest(O/'preview.ninja')==Q['preview_sha256'] and digest(parent)==prior['external_parent']['sha256']
    assert digest(envcmd)==prior['windows_envcmd']['sha256'] and digest(__file__)==R['helper_sha256']
def command(label,args,timeout):
    log=O/('continuation-'+label+'.log');assert not log.exists();start=time.monotonic();child=None
    item={'label':label,'command':list(map(str,args)),'log':str(log)};R['active']=item;save()
    def cleanup():
        subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);child.wait()
    try:
        with log.open('wb') as stream:
            child=subprocess.Popen(list(map(str,args)),cwd=S,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            k=ctypes.windll.kernel32;k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)];k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
            available=ctypes.c_size_t();system=ctypes.c_size_t();h=ctypes.c_void_p(int(child._handle))
            assert k.GetProcessAffinityMask(h,ctypes.byref(available),ctypes.byref(system))
            mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4]);assert k.SetProcessAffinityMask(h,mask)
            item.update(pid=child.pid,affinity_mask=hex(mask),priority='BELOW_NORMAL');save()
            code=child.wait(timeout=timeout)
            if code:cleanup()
    except BaseException:
        if child is not None:cleanup()
        raise
    finally:
        item.update(seconds=time.monotonic()-start,log_sha256=digest(log));R.pop('active',None);R['commands'].append(item);save()
    item['exit_code']=code;save();assert code==0,(label,code,str(log))
    return log.read_text(errors='replace')
started=time.monotonic();save()
try:
    inputs();R['generated_data_before']=Q['data'];save()
    command('build',['C:/PROGRA~1/PYTHON~1/Scripts/ninja.exe','-C',build,'-f',O/'preview.ninja','-j','2',*targets],1800)
    inputs()
    files=[p for p in sorted((O/'bin').iterdir()) if p.is_file()];R['built_artifacts']=[artifact(p) for p in files]
    assert all((O/'bin'/(target+'.exe')).is_file() for target in targets)
    owners=[]
    for dll in [p for p in files if p.name.lower().startswith('hyle_') and p.suffix.lower()=='.dll']:
        matches=[p for p in (build/'hyle/src').rglob(dll.name) if p.is_file()]
        assert len(matches)==1 and digest(dll)==digest(matches[0]),str(dll)
        owners.append({'staged':artifact(dll),'actual_built_owner':artifact(matches[0])})
    assert owners;R['staged_owner_bindings']=owners;save()
    def binaries():
        for item in R['built_artifacts']:assert artifact(item['path'])==item,item['path']
        for item in owners:assert artifact(item['actual_built_owner']['path'])==item['actual_built_owner']
    for target in targets:
        inputs();binaries();text=command(target,[O/'bin'/(target+'.exe')],600);inputs();binaries()
        if target=='g09_wake_pipeline':
            cases=[json.loads(line) for line in text.splitlines() if line.startswith('{"case":')]
            expected={('cpu-first',1,False),('gpu-first',1,False),('cpu-first',2,False),('gpu-first',2,False),('gpu-first',2,True)}
            observed={(r['case'],r['workers'],r['native_input']) for r in cases if r['changed_steps']==65 and r['slots']==2 and r['oracle']=='PASS'}
            assert expected<=observed;R['pipeline_cases']=cases
    R['state']='EXPLICIT_BUILD_AND_EIGHT_ORDINARY_FIXTURES_PASS_NOT_DEVICE_OR_P1'
except BaseException as error:
    R['state']='FAILED_STOPPED_NO_RETRY';R['failures'].append({'error':repr(error),'traceback':traceback.format_exc()});raise
finally:
    R['continuation_wall_seconds']=time.monotonic()-started
    R['continuation_measured_command_seconds']=sum(x['seconds'] for x in R['commands'])
    R['old_plus_continuation_measured_command_seconds']=R['original_measured_command_seconds']+R['continuation_measured_command_seconds'];save()
print(json.dumps({'state':R['state'],'receipt':str(record),'commands':len(R['commands']),'seconds':R['continuation_wall_seconds']},indent=2))
