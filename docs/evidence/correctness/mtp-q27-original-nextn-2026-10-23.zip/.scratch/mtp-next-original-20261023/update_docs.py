"""Update actual Q27 original-parameter facts after focused native checks."""
from pathlib import Path
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
runs=[read(S/f'checks{i}/summary.json') for i in range(1,6)]
assert sum(run['tests'] for run in runs)==9
assert all(run['process']['exit']==0 and not run['process']['timed_out'] and
    not any(run[k] for k in ('failures','errors','disabled','skips')) for run in runs)
cases=[case for run in runs for case in run['cases']]
assert sum(int(case['properties'].get('actual_submissions','0')) for case in cases)==104
for run in runs[1:3]:
    properties=run['cases'][0]['properties']
    assert properties['original_role_count']=='17' and properties['original_role_bytes']=='2109114368'
    assert properties['original_first_full_projection_values']=='312832'
    assert properties['original_first_full_head_values']=='248320'
    assert properties['original_native_reference_submissions']=='0'

p=R/'docs/developer/current-work.md';text=p.read_text(encoding='utf-8-sig')
def change(old,new):
    global text
    assert text.count(old)==1,old
    text=text.replace(old,new)
change('本轮补上CUDA公共I32→F32 Cast，核整数舍入边界、stride、重复提交及原浮点／Bool转换。',
       'CUDA公共I32→F32 Cast已有整数舍入边界、stride、重复提交及原浮点／Bool转换检查。')
change('Q27原EH／两norm、Q24原K／V／K norm已进入各自完整NextN。剩余原角色、真实target taps、Pro实际几何及已确认量化供给继续按精确制品身份接入',
       'Q27主UD-Q4_K_M的全部15份NextN原角色与独立原embedding／head已接，Q24原K／V／K norm也在完整NextN中。Q24其余原角色、真实target taps、Pro实际几何及已确认量化供给继续按精确制品身份接入')
change('Q27／Q24单次完整量化head、GLM Flash完整原NextN与共享全词表、DSpark全部81份sidecar原角色已有列明检查。下一步继续真实target taps／verifier、Q27／Q24剩余原角色、Pro实际几何与已确认适用量化组合。',
       'Q27主UD-Q4_K_M完整原NextN与共享全词表、GLM Flash完整原NextN与共享全词表、DSpark全部81份sidecar原角色已有列明检查；Q24仍为部分原角色。下一步继续Q24原参数与真实512专家供给、真实target taps／verifier、Pro实际几何与已确认适用量化组合。')
start=text.index('**最近已验证进展**：');end=text.index('前批[DSpark原专家]',start)
text=text[:start]+'''**最近已验证进展**：[Q27完整原NextN／词表](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)新增14份主UD-Q4_K_M原角色（2,066,065,408B），加旧EH／两norm共17份、2,109,114,368B；逐header核对覆盖全部15份blk64参数与原embedding／head。原Q4_K embedding和独立Q6_K head只准备一次，完整模式不先构造生成词表；原Q／K／V／O、dense FFN及所有norm均接入普通Graph。

CPU／CUDA新旅程各5次Graph，保六项完整状态、接受0／1／2、旧结果及真实ID反馈。首轮每端独立核312,832个投影值（含全部248,320词表分数），以后固定行与实际Top4采样，所有实际logits继续核greedy。参考按CPU AQ8_K／Q8_0与CUDA AQ8_1分别核原packed bytes及实际F32前驱，不增加GPU参考提交；Q4_K行解码逐值核embedding。相关旧Q27／Q24四项、DSpark两项和有界SHA八标准向量单项均通过，共9项、104次Graph，无失败或跳过。真实target hidden／初始历史仍为显式外部生成边界；没有新任务质量、自然接受率、TPS或物理内存／显存峰值结论，页末AV表保持原样。

前批[GLM原MoE／FFN](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)已补齐layer45全部1760原角色，加共享embedding／head共1762份。真实288域Top8、原FP8专家有界供给、BF16存储边界及完整状态反馈CPU／CUDA通过；GLM与DSpark继续共用纯冷图切分及普通Graph／Invocation。本批对[真实target接线边界的源码审查](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)未发现需新增公共MTP算子／状态API的具体证据；剩余实际producer／tap／verifier与完整状态组合继续走既有机制，不以另造八套完整引擎为前置，也不把片段检查当成整模型质量证据。

'''+text[end:]
start=text.index('- **Q27／Q24**：');end=text.index('- **GLM-Flash**：',start)
text=text[:start]+'''- **Q27**：[主UD-Q4_K_M原17角色](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)覆盖完整NextN与原全V248320 embedding／head；原norm不额外加1，使用blk64 shared_head_norm而非target output_norm，原Q／gate按每head256＋256解释。一次Step Graph带单次完整Q6_K head，实际预测ID、normalized hidden、完整cap6 KV、cursor与position同Head选择prefix0／1／2并继续。CPU／CUDA各5次Graph与首轮全量packed局部参考通过；target64层GDN／conv主干、初始历史、其它量化及自然接受率仍保明确边界。
- **Q24**：[旧完整草拟状态](../evidence/correctness/mtp-shared-vocabulary-state-2026-10-23.json)保主UD-IQ4_XS原K／V／K norm、完整NextN六资源与接受0／1／2续算。其余参数／词表仍生成，生成%8专家map不得代替原512域Top10；原embedding与head虽同Q4_K也属两份独立权重。下一步补真实原参数／有界专家供给，不代签target主干、其它量化或自然接受率。旧C5两profile依据保留。
'''+text[end:]
change('GLM编码状态、Q27／Q24完整草拟六资源、DSpark真实全词表＋编码main历史／完整draft已有CPU／CUDA检查。',
       'Q27原17角色／全词表与完整草拟六资源、GLM编码状态、Q24部分原角色／完整草拟六资源、DSpark真实全词表＋编码main历史／完整draft已有CPU／CUDA检查。')
change('下一步真实target taps／其余原角色／Pro几何与已确认量化组合，最后完整性能对照',
       '下一步Q24原512域供给／真实target taps／Pro几何与已确认量化组合，最后完整性能对照')
tail=text[text.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest()==read(S/'before.json')['protected_performance_tail_sha256']
p.write_text(text,encoding='utf-8',newline='\n')

p=R/'docs/implementation/model-operators.md';text=p.read_text(encoding='utf-8-sig')
start=text.index('[Q27／Q24角色核对]');start=text.rfind('\n',0,start)+1
end=text.index('\n\nPro GA GGUF',start)
text=text[:start]+'''[Q27／Q24角色核对](../evidence/correctness/qwen-original-mtp-input-2026-10-22.json)区分主GGUF与独立C4 sidecar：Q27主UD-Q4_K_M内嵌blk64 NextN，EH／Q／O／FFN为Q6_K、K／V为Q8_0；fidelity的EH／Q／K／V为BF16、O／FFN为Q8_0，norm均F32。Q24主UD-IQ4_XS的attention为Q5_K、专家Q4_K、shared gate／up Q5_K、down Q6_K、EH Q8_0；C5明确选primary54及fidelity48（Q8_0），不沿旧UD-IQ1_M推导。

[Q27完整原NextN与共享词表](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)已接主UD-Q4_K_M全部15份blk64原参数及原Q4_K embedding／独立Q6_K head，共17份、2,109,114,368B，固定header差集为空。保持原GGUF压缩格式及F32激活，原norm不再加1；blk64 shared_head_norm优先于global output_norm。原QG物理每head为Q256＋gate256，无热重排；普通Graph复用QKV／GQA／dense FFN构图，原全V248320 head只需一次MatMul。两份词表各冷准备一次，完整原模式不生成占位大bank或整份F32权重副本。

CPU／CUDA各5次Graph保完整cap6 KV、normalized hidden、pending、cursor与position六资源；prefix0／1／2原子发布，各Head续算与旧结果通过。首轮独立检查312,832个投影值（含248,320全部分数），后续7行及实际Top4；参考明确CPU AQ8_K／Q8_0与CUDA AQ8_1舍入及误差界，Q4_K仅核真实embedding解码，不冒称额外MatMul格式已证。共享原输入SHA改为64B块＋128B tail，不复制整份词表做padding。旧Q27／Q24、DSpark与SHA标准向量共9项104次Graph通过；真实target／初始历史仍外部生成，官方BF16数学、其它量化、整模型质量、自然接受率和TPS未代签。

Q24仍是[原K／V／K norm三角色进入完整NextN](../evidence/correctness/mtp-shared-vocabulary-state-2026-10-23.json)；其余原参数和512专家待接。已核原blk92共20角色14,980,286,464B，独立embedding／head各Q4_K1,144,258,560B；不能因codec相同而共享字节。原Top10须保持512域并按实际ID供给至少10槽，生成%8 map不是原实现；单份三bank的Top10容量283,115,520B不等于整模型或物理显存峰。此前[单次完整head](../evidence/correctness/mtp-full-packed-head-2026-10-23.json)去除61片构图的公共能力继续复用，原C5两profile证据保留。'''+text[end:]
old='Qwen3.5-2B已有完整分页状态和四会话淘汰重建；Q27／Q24 primary完整NextN的六资源、实际ID／hidden反馈、接受0／1／2及各Head续算已CPU／CUDA核，其target主干与其它原制品仍保边界'
new='Qwen3.5-2B已有完整分页状态和四会话淘汰重建；Q27 primary完整原NextN／词表17角色、Q24部分原角色的完整NextN六资源与实际ID／hidden反馈、接受0／1／2及各Head续算已CPU／CUDA核；target主干与其它原制品仍保边界'
assert text.count(old)==1;text=text.replace(old,new)
p.write_text(text,encoding='utf-8',newline='\n')
print('UPDATED original Q27 facts; AV comparison unchanged')
