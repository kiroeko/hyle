from pathlib import Path
import hashlib,json,difflib,re,shutil
base=Path('.scratch/mtp-next-original-20261023')
def ident(p):
 p=Path(p); b=p.read_bytes(); return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def out(p,x):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8'); return ident(p)
shared=Path('tests/compute_models/dspark_original_shared_reference.h')
old=base/'qwen27-reference-source/before'/shared
s0=old.read_text(encoding='utf-8');s1=shared.read_text(encoding='utf-8')
expect=s0.replace('inline ActivationBlock quantize(std::span<const float, 32> input, ActivationCodec codec) {','inline ActivationBlock quantize(std::span<const float, 32> input, ActivationCodec codec,\n    bool require_bfloat = true) {').replace('if ((std::bit_cast<std::uint32_t>(term) & 0xffffU) ||','if ((require_bfloat && (std::bit_cast<std::uint32_t>(term) & 0xffffU)) ||')
assert expect==s1,'shared helper has an unexpected delta'
fr=base/'qwen27-reference-source/frozen'/shared
fr.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(shared,fr)
diff=''.join(difflib.unified_diff(s0.splitlines(True),s1.splitlines(True),fromfile=str(old),tofile=str(shared)))
(base/'qwen27-reference-source/shared-helper.diff').write_text(diff,encoding='utf-8')
print(out(base/'qwen27-reference-source/shared-helper-freeze.json',{
 'scope':'Source-only minimal shared activation certificate extension. No native/build/download/run.',
 'source':ident(shared),'before':ident(old),'frozen':ident(fr),
 'mechanical_source_check':{'whole_file_equal_after_two_expected_text_replacements':True,'old_require_bfloat_true_default_path':'The former bit-mask || nonnormal condition is identical when default true is substituted. All quantizer arithmetic, finite/normal/scale/rounding/code/range/envelope behavior remains text-identical.','new_use':'Q27 explicitly passes false for actual normal F32 predecessor values. It does not bypass any other guard.'},
 'required_regression':'Root recompiles DSpark TU and runs its existing original83 CPU/CUDA pair; this manifest claims no native result.'}))
roles=Path('tests/compute_models/qwen27_original_nextn_roles.h');sha=Path('tests/compute_models/original_role_input.h')
receipt_path=base/'original-q27-nextn/acquisition.json';receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
entries=re.findall(r'Spec\{"([^"]+)", "([^"]+)", "([0-9a-f]{64})", ([^\n]+)\}',roles.read_text(encoding='utf-8'))
assert len(entries)==14
comp=[]
for name,file,pin,rest in entries:
 r=next(r for r in receipt['roles'] if r['name']==name)
 tail=re.search(r', (\d+), (\d+), (\d+)$',rest);assert tail
 k,n,size=map(int,tail.groups());assert r['file']==file and r['payload']['sha256']==pin and r['bytes']==size and r['payload']['bytes']==size and r['complete']
 assert r['gguf_shape_K_N']==([n] if k==0 else [k,n])
 assert (base/'original-q27-nextn'/file).stat().st_size==size
 comp.append({'role':name,'file':file,'shape':r['gguf_shape_K_N'],'bytes':size,'sha256':pin})
assert sum(x['bytes'] for x in comp)==2066065408
oldsha=base/'source/before'/sha
oldtext=oldsha.read_text(encoding='utf-8');newtext=sha.read_text(encoding='utf-8')
oldround=oldtext[oldtext.index('    std::array<std::uint32_t, 64> words{};'):oldtext.index('  std::ostringstream result;')].rsplit('\n  }',1)[0]
newround=newtext[newtext.index('    std::array<std::uint32_t, 64> words{};'):newtext.index('  };')]
assert oldround.replace('padded[block + i * 4 + byte]','block[i * 4 + byte]')==newround.rstrip('\n')
assert oldtext[oldtext.index('  constexpr std::array'):oldtext.index('  Bytes padded')]==newtext[newtext.index('  constexpr std::array'):newtext.index('  if (input.size()')]
assert oldtext[oldtext.index('\n\n\ninline float widen'):]==newtext[newtext.index('\n\n\ninline float widen'):]
print(out(base/'review/q27-supplier-sha-independent.json',{
 'scope':'Narrow independent source-only review of final supplier and bounded SHA delta. No native/build/download, no rehash of twoGB input bodies.',
 'sources':[ident(roles),ident(sha)],'receipt':ident(receipt_path),'confirmed_blockers':[],
 'checks':{
 'all14_receipt_pins_shapes_sizes':comp,
 'geometry':'H5120,V248320,Qheads24,KVheads4,D256,intermediate17408. 14new roles2066065408B + existingEH/enorm/hnorm43048960B =2109114368B. Complete15 NextN roles plus untied originalembedding and head; shared_head_norm is distinct from target output_norm.',
 'packed_layout':'Embedding transposes descriptor metadata only from canonical GGUF RHS; physical original[N,K] bytes and read lease are unchanged. Head retains one complete canonical[K,V] RHS, no shard/prototype bank.',
 'lifetime':'Each FileMapping moves into Data before norm decoding; mapped address remains valid. Roles.source strongly retains Data, each ReadonlyRole owns nominated StorageOwner plus immutable ready lease; build borrows the same original banks. Small F32 norm vectors only. One upload per bank, no full expanded weight shadow.',
 'bounded_sha_constants_initialstate_equal':True,'bounded_sha_round_body_equal_except_input_block_index':True,'nonsha_helpers_text_unchanged':True,
 'padding':'Direct full64-byte blocks followed by remainder r<64,0x80,zeros,and BE64bitlength. r<56 uses64tail otherwise128tail. Empty span never adds offset to null because both direct loop and remaining copy skip. Length guard prevents bitlength multiplication overflow. Only128B padding buffer and existing64word compressor stack remain.',
 'result_limit':'Source and metadata evidence only; real payload SHA authentication and graph numeric/state execution belong to root.'}}))
