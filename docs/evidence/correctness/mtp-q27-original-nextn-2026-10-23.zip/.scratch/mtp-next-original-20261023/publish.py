"""Publish actual Q27 original NextN/state checks without weight bodies."""
from pathlib import Path
import hashlib
import json
import zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
D=R/'docs/evidence/correctness'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p)
    with p.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),bytes=p.stat().st_size,sha256=sha)
def verify(row):
    current=identity(R/row['path'])
    assert current['bytes']==row['bytes'] and current['sha256']==row['sha256'],row['path']

runs=[read(S/f'checks{i}/summary.json') for i in range(1,6)]
image=read(S/'tests-link1/ready.json')['image'];verify(image)
for run in runs:
    assert run['image']==image and run['process']['exit']==0 and not run['process']['timed_out']
    assert not any(run[k] for k in ('failures','errors','disabled','skips'))
auth=runs[0]['cases'];new=[case for run in runs[1:3] for case in run['cases']]
old_qwen=runs[3]['cases'];old_dspark=runs[4]['cases']
assert len(auth)==1 and len(new)==len(old_dspark)==2 and len(old_qwen)==4
assert auth[0]['attributes']['classname']=='OriginalRoleInput'
assert auth[0]['attributes']['name']=='BoundedSha256AuthenticatesBlockAndPaddingBoundaries'
for case in new:
    props=case['properties']
    assert props['original_role_count']=='17' and props['original_role_bytes']=='2109114368'
    assert props['actual_submissions']=='5' and props['complete_draft_resources']=='6'
    assert props['original_first_full_projection_values']=='312832' and props['original_first_full_head_values']=='248320'
    assert props['original_prediction_embedding_observations']=='5' and props['original_native_reference_submissions']=='0'
assert sorted((case['properties']['original_role_bytes'],case['properties']['actual_submissions']) for case in old_qwen)==[
    ('11535360','5'),('11535360','5'),('43048960','5'),('43048960','5')]
for case in old_dspark:
    assert case['properties']['original_role_count']=='83' and case['properties']['actual_submissions']=='37'
models=[*new,*old_qwen,*old_dspark]
graphs=sum(int(case['properties']['actual_submissions']) for case in models);assert graphs==104
native_reference=sum(int(case['properties'].get('original_native_reference_submissions','0')) for case in models)
assert native_reference==225
freeze_path=S/'source-final/freeze.json';freeze=read(freeze_path)
assert len(freeze['source'])==8
for row in freeze['source']:verify(row)
link_path=S/'tests-link1/link-plan.json';link=read(link_path)
for row in link['inputs']:verify(row)
for row in link['compiled_records']:
    verify(row)
    if Path(row['path']).is_relative_to(S):
        compiled=read(row['path'])
        for item in (compiled['source'],compiled['object'],*compiled['dependencies']):verify(item)
acquisition=read(S/'original-q27-nextn/acquisition.json')
assert acquisition['complete'] and acquisition['original_roles']==14
assert acquisition['role_payload_bytes']==acquisition['successful_request_body_bytes']==2066065408
assert len(acquisition['roles'])==14 and all(role['complete'] for role in acquisition['roles'])
for role in acquisition['roles']:
    assert (R/role['payload']['path']).stat().st_size==role['payload']['bytes']
    assert len(role['payload']['sha256'])==64
# Each actual native Data::load verified the bodies against compiled SHA pins.
# Do not add another2GB input hash pass merely to publish its receipt.
before=read(S/'before.json');protected=before['protected_qwen_image'];verify(protected.get('image',protected))
text=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail=text[text.index('## 最新完整性能对比'):];tail_hash=hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash==before['protected_performance_tail_sha256']
sources=[R/row['path'] for row in freeze['source']]
sources.extend(R/path for path in ('docs/developer/current-work.md','docs/implementation/model-operators.md'))
metadata=[R/'.scratch/qwen-original-mtp-20261022/original-q27/header.json',
          R/'.scratch/qwen-original-mtp-20261022/original-q27/acquisition.json',
          R/'.scratch/qwen24-original-mtp-20261022/original-q24/acquisition.json']
files=set(sources+metadata)
files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in
    ('.h','.cc','.py','.json','.txt','.log','.xml','.ps1','.diff'))
files.discard(S/'publication.json')
archive=D/'mtp-q27-original-nextn-2026-10-23.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
    for path in sorted(files):
        assert path.suffix.lower() not in ('.q6_k','.q8_0','.q4_k','.f32','.bin')
        zipped.write(path,path.relative_to(R).as_posix())
record=dict(date='2026-10-23',stage='BQ',goal_complete=False,
    conclusion='All15 embedded mainQ27 UD-Q4_K_M NextN roles plus original full vocabulary embedding/head now feed the ordinary complete-state CPU/CUDA journey.',
    artifact=dict(repository='unsloth/Qwen3.8-27B-GGUF',revision='4ca720788d1e01f1bff70c033e0d0028fd02e502',
        variant='UD-Q4_K_M',original_roles=17,original_role_bytes=2109114368,
        additional_original_roles=14,additional_original_payload_bytes=2066065408,
        existing_original_roles=3,existing_original_bytes=43048960,
        acquisition=acquisition,weight_bodies_archived=False),
    implementation=dict(
        weights='Original Q6_K EH/Q/O/FFN, Q8_0 K/V and F32 norms. Q4_K embedding and independent Q6_K fullV head are immutable once-bound banks. The original branch is selected before generated vocabulary construction; no duplicate generated full bank or dense F32 weight shadow.',
        math='Existing shared input/QKV/GQA construction consumes actual original weights. Q/G physical rows stay per-head Q256+gate256; original Q/K norms and text HalfSplit64 RoPE stay. GGUF gamma is already converted, so no extra+1. blk64 shared_head_norm has precedence over global output_norm.',
        prediction='One original complete248320-output packed MatMul plus stable TopK returns actual I32 pending. Its existing readonly lease directly feeds the next original embedding Gather, together with complete KV/hidden/cursor/position.',
        reference='Independent original packed-byte decode and actual native activation codec: fixed CPU Q8_K/Q8_0 or CUDA MMVQ Q8_1 with explicit strict/fast division interval. Firstepisode all9 projections/fullV, later deterministic7rows and actualTop4; everyhead allactualgreedy and everyembedding exact decoded row. Q4_K MatMul is deliberately not claimed by this certificate.',
        sha='Existing original_role_input::sha256 API now directly traverses64-byte blocks and a128-byte stacktail; no padded full-input copy. Eight independent hashlib-known vectors cover empty/abc and block/padding boundaries.',
        state='Existing six-resource StateStore, ordinary Graph/Invocation, real immutable result leases, accepted0/1/2 heads, branch continuation, injected wrongV cancellation and old results remain. No new public op, provider branch, model registry or executor.'),
    validation=dict(tests=9,failures=0,errors=0,skips=0,graph_submissions=graphs,
        new_graph_submissions=10,related_qwen_graph_submissions=20,related_dspark_graph_submissions=74,
        authentication_cases=auth,new_cases=new,related_qwen_cases=old_qwen,related_dspark_cases=old_dspark,
        first_full_projection_values=625664,first_full_head_values=496640,
        new_native_reference_submissions=0,unchanged_related_native_reference_submissions=native_reference,
        results=[identity(S/f'checks{i}/summary.json') for i in range(1,6)],
        source_freeze=identity(freeze_path),linked_inputs=identity(link_path),
        host_translation_units=2,host_compile_attempts=len(list(S.glob('compile*/*/plan.json'))),
        SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
    scope_review=dict(
        evidence='Bounded source review did not identify a concrete missing public MTP math/state primitive in the inspected actual paths. Real model/codec roles, remaining geometry/state adapters and real target producer/verifier integration remain consumer work through existing Graph/leases/StateHead.',
        target_boundary='Current Q27 initial target hidden/history, GLM target43/44 generated parameters and DSpark ID/position capture+small verifier are explicit generated boundaries. They cannot be relabelled as trained target outputs by replacing only a head.',
        q24_next='Main UD-IQ4_XS blk92 has20 physical roles; embedding/head are two distinct Q4_K bodies. Replace generated modulo8 routing by true512-domain Top10 and bounded actual expert supply; headers/selected codecs are not payload execution.'),
    limitations=['Finite Windows CPU/CUDA M1/cap6 integration, not all systems/shapes/codecs.',
        'Initial target hidden/KV history and acceptance selector remain explicit external fixtures, not a full64-layer trained Q27 target or natural speculative acceptance.',
        'Native-codec local reference and exact feedback are not full-task quality or official BF16 arithmetic equivalence.',
        'CUDA __fdividef interval is source/documentation-conditioned, not a formal guarantee of every GPU/input.',
        'Q24 original512-expert integration, remaining real target taps/verifier, Pro geometry and confirmed applicable quantization combinations remain unfinished.',
        'No new TPS/loading or physical memory/VRAM peak claim; protected AV benchmark and Qwen image remain unchanged.',
        'MTP/images and the broader goal remain incomplete.'],
    remaining='OriginalQ24 nonexpert/shared-vocabulary roles and actual512-domain top10 compressed expert supply; real target producer/taps/verifier, Pro geometry, confirmed applicable quantization and final necessary regressions/performance comparison before images.',
    final_image=image,sources=[identity(path) for path in sources],source_metadata=[identity(path) for path in metadata],
    performance_tail_sha256=tail_hash,archive=identity(archive),archive_items=len(files))
destination=D/'mtp-q27-original-nextn-2026-10-23.json';assert not destination.exists()
destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
publication=dict(evidence=identity(destination),archive=identity(archive))
(S/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(**publication,tests=9,graphs=graphs)))
