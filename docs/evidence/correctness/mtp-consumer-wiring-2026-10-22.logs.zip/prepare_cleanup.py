"""Plan exact superseded image/map cleanup in root test.ps1; no deletion."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1]
def ident(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
folders=[S/name for name in ['hyle-link1','hyle-link2','tests-link1','tests-link2','tests-link4','dspark-link1','dspark-link2']]
folders += [R/'.scratch/qwen-capture-variants-20261022/hyle-link2',R/'.scratch/qwen-capture-reuse-20261022/hyle-link2']
files=[ident(p.resolve())for folder in folders for p in sorted(folder.iterdir())if p.suffix in ['.exe','.map']]
assert len(files)==18
plan=dict(files=files,bytes=sum(x['bytes']for x in files),
    allowed_prefixes=[str(p.resolve())+'\\'for p in [S,R/'.scratch/qwen-capture-variants-20261022',R/'.scratch/qwen-capture-reuse-20261022']],
    keep_current_image=str(S/'hyle-link4/qwen.exe'),keep_current_map=str(S/'hyle-link4/qwen.map'),
    kept='All compiled source/object/link closures, dependency DLLs/libraries, commands/results and the8704B original role remain available. Only superseded executable images/maps are removed.')
(S/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=r'''$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-mtp-next-20261022'
$taskPlan = Get-Content -LiteralPath ($taskRoot + '\cleanup-plan.json') -Raw | ConvertFrom-Json
$taskFiles = @($taskPlan.files)
foreach ($taskFile in $taskFiles) {
  $taskResolved = (Resolve-Path -LiteralPath $taskFile.path).Path
  $taskAllowed = $false
  foreach ($taskPrefix in $taskPlan.allowed_prefixes) {
    if ($taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { $taskAllowed = $true }
  }
  if (-not $taskAllowed -or $taskResolved -in @($taskPlan.keep_current_image, $taskPlan.keep_current_map)) { throw 'Cleanup outside exact selected workspaces or current retained image' }
  $taskInfo = Get-Item -LiteralPath $taskResolved
  if ($taskInfo.PSIsContainer -or $taskInfo.Length -ne $taskFile.bytes) { throw 'Cleanup target changed' }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Cleanup hash changed' }
}
Get-Process -Name qwen,checks,dspark-checks -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.Path -in $taskFiles.path) { throw 'Cleanup image is still running' }
}
$taskRemoved = @()
foreach ($taskFile in $taskFiles) {
  Remove-Item -LiteralPath $taskFile.path -Force
  $taskRemoved += $taskFile
}
[PSCustomObject]@{ Removed = $taskRemoved; Bytes = ($taskRemoved | Measure-Object -Property bytes -Sum).Sum; CurrentImageRetained = (Test-Path -LiteralPath $taskPlan.keep_current_image); CurrentMapRetained = (Test-Path -LiteralPath $taskPlan.keep_current_map) } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($taskRoot + '\cleanup-result.json') -Encoding utf8
'''
(R/'test.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(files=len(files),bytes=plan['bytes'],targets=[x['path']for x in files],script=str(R/'test.ps1')),indent=2))
