"""Acquire one exact 8704-byte original role; refuse whole-sidecar responses."""
from pathlib import Path
import hashlib,json,time,urllib.parse,urllib.request
S=Path(__file__).resolve().parent
report=json.loads((S/'review/next-payload-inputs.json').read_text(encoding='utf-8-sig'))
source=report['smallest_conditional_original_payload_component']['exact_pinned_sources'][0]
folder=S/'original-confidence';folder.mkdir(exist_ok=False)
url='https://huggingface.co/'+source['repository']+'/resolve/'+source['revision']+'/'+urllib.parse.quote(source['file'],safe='/')
record=dict(source=source,url=url,requested_range=[source['absolute_start'],source['absolute_end_inclusive']],
    requested_bytes=source['payload_bytes_needed'],started_unix=time.time(),status='REQUESTING',whole_file_download_allowed=False)
def save():
    (folder/'acquisition.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()
try:
    request=urllib.request.Request(url,headers={'Range':f"bytes={source['absolute_start']}-{source['absolute_end_inclusive']}",'Accept-Encoding':'identity','User-Agent':'hyle-finite-role-consumer/1'})
    with urllib.request.urlopen(request,timeout=45)as response:
        expected=f"bytes {source['absolute_start']}-{source['absolute_end_inclusive']}/"
        content_range=response.headers.get('Content-Range','')
        record.update(http_status=response.status,content_range=content_range,
            content_length=response.headers.get('Content-Length'),etag=response.headers.get('ETag'))
        assert response.status==206 and content_range.startswith(expected),'Refuse non-exact range or whole-sidecar response before reading body'
        payload=response.read(source['payload_bytes_needed']+1)
        assert len(payload)==source['payload_bytes_needed']
    path=folder/'conf_proj.weight.bf16';path.write_bytes(payload)
    record.update(status='ACQUIRED_EXACT_ROLE',payload=dict(path=str(path),bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest()),
        model_inference_run=False,whole_file_downloaded=False)
except Exception as error:
    record.update(status='ACQUISITION_FAILED_NO_WHOLE_FILE',error=repr(error));raise
finally:
    record['finished_unix']=time.time();save()
print(json.dumps(record,indent=2))
