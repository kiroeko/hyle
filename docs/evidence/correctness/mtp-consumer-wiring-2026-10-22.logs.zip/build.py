"""One common host TU overlay on the retained AU closure; no SDK rebuild."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];AU=R/'.scratch/qwen-capture-variants-20261022'
sp=importlib.util.spec_from_file_location('av_cached',AU/'build.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
b,c,h=a.b,a.c,a.h
BASE=AU/'hyle-link2';PLAN=c.read(BASE/'link-plan.json');h.S=S

def compile_common(attempt):
    h.RECIPES['executable']=AU/'recipes/executable.json'
    h.SOURCES['executable']=R/'src/graph/executable.cc'
    h.compile_one('executable',attempt)

EXTRA = {
    'ggml-provider': (143,R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',AU/'recipes/ggml-provider.json'),
    'ggml-region': (145,R/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',AU/'recipes/ggml-region.json'),
    'tensor-program': (146,R/'src/compute_provider_ggml_cuda/tensor_program.cc',R/'.scratch/architecture-refactor-2026-10-18/ga-ratio4-producer-2026-10-21/common/checks/attempt1/cuda-tensor/identity.json'),
    'graph-test': (None,R/'tests/graph/region_provider_test.cc',AU/'recipes/graph-test.json'),
    'confidence': (None,R/'tests/graph_route_cuda/dspark_original_confidence_test.cc',R/'.scratch/qwen-capture-reuse-20261022/compile1/cuda-test/identity.json')}

def compile_extra(tag,attempt):
    _,source,recipe=EXTRA[tag];h.RECIPES[tag]=recipe;h.SOURCES[tag]=source;h.compile_one(tag,attempt)

def latest(tag):
    paths=sorted(S.glob(f'compile*/{tag}/identity.json'),key=lambda p:int(p.parents[1].name[7:]))
    assert paths,tag
    return paths[-1],c.read(paths[-1])

def link(tests,attempt,link_attempt):
    rec=c.read(S/f'compile{attempt}/executable/identity.json')
    assert all(b.identity(x['path'])==x for x in [rec['source'],rec['object'],*rec['dependencies']])
    old=c.key(PLAN['inputs'][80]['path']);assert 'executable' in old
    replacements={old:rec['object']}
    for tag,(index,_,_) in EXTRA.items():
        if index is None or not list(S.glob(f'compile*/{tag}/identity.json')):continue
        _,item=latest(tag)
        assert all(b.identity(x['path'])==x for x in [item['source'],item['object'],*item['dependencies']])
        replacements[c.key(PLAN['inputs'][index]['path'])]=item['object']
    inputs=[replacements.get(c.key(x['path']),x)for x in PLAN['inputs']]
    command=[replacements.get(c.key(x),{}).get('path',x)for x in PLAN['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    if tests:
        main=c.key(c.read(R/'.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json')['object']['path'])
        inputs=[x for x in inputs if c.key(x['path'])!=main];command=[x for x in command if c.key(x)!=main]
        graph_test=latest('graph-test')[1]if list(S.glob('compile*/graph-test/identity.json'))else c.read(AU/'compile3/graph-test/identity.json')
        extra=[graph_test['object'],
            c.read(R/'.scratch/qwen-capture-reuse-20261022/compile1/cuda-test/identity.json')['object'],
            b.identity(R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/native-fix/tests/attempt1/kernel/cuda-test-kernel.obj'),
            b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
        inputs=extra+inputs;command[1:1]=[x['path']for x in extra]
    assert all(b.identity(x['path'])==x for x in inputs)
    out=S/f'{"tests"if tests else"hyle"}-link{link_attempt}';out.mkdir();(out/'tmp').mkdir()
    image=out/('checks.exe'if tests else'qwen.exe')
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_record=b.identity(S/f'compile{attempt}/executable/identity.json'),base=b.identity(BASE/'link-plan.json'),SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(BASE/'runtime-environment.json')
    for x in runtime['staged_dlls']:os.link(x['path'],out/Path(x['path']).name)
    runtime['staged_dlls']=[b.identity(p)for p in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image)))
    print('LINKED',image,flush=True)

def compile_dspark(attempt):
    h.RECIPES['dspark']=R/'.scratch/qwen-capture-reuse-20261022/compile1/cuda-test/identity.json'
    h.SOURCES['dspark']=R/'tests/graph_route_cuda/dspark_feedback_consumer_test.cc'
    h.compile_one('dspark',attempt)

def link_dspark(attempt,link_attempt):
    bases=sorted(S.glob('hyle-link*/link-plan.json'),key=lambda p:int(p.parent.name[9:]))
    base_path=bases[-1];base=c.read(base_path)
    rec=c.read(S/f'compile{attempt}/dspark/identity.json')
    assert all(b.identity(x['path'])==x for x in [rec['source'],rec['object'],*rec['dependencies']])
    main=c.key(c.read(R/'.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json')['object']['path'])
    inputs=[x for x in base['inputs']if c.key(x['path'])!=main]
    command=[x for x in base['command']if c.key(x)!=main and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    extra=[rec['object'],b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
    if list(S.glob('compile*/confidence/identity.json')):
        _,confidence=latest('confidence')
        assert all(b.identity(x['path'])==x for x in [confidence['source'],confidence['object'],*confidence['dependencies']])
        extra.insert(1,confidence['object'])
    inputs=extra+inputs;command[1:1]=[x['path']for x in extra]
    assert all(b.identity(x['path'])==x for x in inputs)
    out=S/f'dspark-link{link_attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'dspark-checks.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_record=b.identity(S/f'compile{attempt}/dspark/identity.json'),base=b.identity(base_path),SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(base_path.parent/'runtime-environment.json')
    for x in runtime['staged_dlls']:os.link(x['path'],out/Path(x['path']).name)
    runtime['staged_dlls']=[b.identity(p)for p in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image)))
    print('LINKED',image,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('actions',nargs='+',choices=['common','link','link-tests','dspark','link-dspark',*EXTRA]);p.add_argument('--attempt',type=int,default=1);p.add_argument('--link-attempt',type=int,default=1);args=p.parse_args()
    for action in args.actions:
        if action=='common':compile_common(args.attempt)
        elif action=='dspark':compile_dspark(args.attempt)
        elif action=='link-dspark':link_dspark(args.attempt,args.link_attempt)
        elif action in EXTRA:compile_extra(action,args.attempt)
        else:link(action=='link-tests',args.attempt,args.link_attempt)
