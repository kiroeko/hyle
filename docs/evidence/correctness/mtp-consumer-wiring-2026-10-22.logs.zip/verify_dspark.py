"""Run only the finite DSpark head feedback consumer, not a model benchmark."""
from pathlib import Path
import argparse,importlib.util,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
sp=importlib.util.spec_from_file_location('av_dspark_helpers',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
p=argparse.ArgumentParser();p.add_argument('--attempt',type=int,default=1);args=p.parse_args()
folder=S/f'dspark-link{args.attempt}';image=h.read(folder/'ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(folder/'runtime-environment.json')['PATH']
payload=S/'original-confidence/conf_proj.weight.bf16'
assert h.ident(payload)['sha256']=='15c5d09c7842d0f947ce0afdc154691ead377e6263af71bd2f7cb34bd592f30f'
env['HYLE_DSPARK_CONFIDENCE_BF16']=str(payload)
out=S/f'dspark-checks{args.attempt}';xml=out/'results.xml'
process=h.execute([image['path'],'--gtest_output=xml:'+str(xml)],env,out,timeout=120)
root=ET.parse(xml).getroot()
result=dict(process=process,image=image,tests=int(root.attrib['tests']),failures=int(root.attrib['failures']),
    errors=int(root.attrib['errors']),disabled=int(root.attrib['disabled']),
    skips=sum(1 for x in root.iter('testcase')if x.find('skipped')is not None),
    cases=[x.attrib for x in root.iter('testcase')],
    scope='Finite CUDA ordinary Graph five-row DSpark head feedback, deterministic synthetic boundary inputs/weights. Not a full 129280-vocabulary, three-stage original-payload model or accepted-target-state journey; no TPS/memory claim.')
h.save(out/'summary.json',result)
assert process['exit']==0 and not process['timed_out'],process
assert result['tests']==2 and not any(result[k]for k in ['failures','errors','disabled','skips']),result
cases=list(root.iter('testcase'))
properties={case.attrib['name']:{p.attrib['name']:p.attrib['value']for p in case.iter('property')}for case in cases}
feedback=properties['FiveGreedyRowsFeedActualMarkovIdsAndKeepPriorResults']
original=properties['FullWidthRawAndSidecarPolicyKeepPriorLeases']
assert feedback['actual_submissions']=='4'and feedback['proposal_rows_per_submission']=='5',properties
assert original['actual_submissions']=='4'and original['original_payload_sha256']==h.ident(payload)['sha256'],properties
result['test_properties']=properties
h.save(out/'summary.json',result)
print('DSPARK',root.attrib,flush=True)
