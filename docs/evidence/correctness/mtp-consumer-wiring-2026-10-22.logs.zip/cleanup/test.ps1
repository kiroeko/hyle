$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-mtp-next-20261022'
$taskPlan = Get-Content -LiteralPath ($taskRoot + '\cleanup-plan.json') -Raw | ConvertFrom-Json
$taskFiles = @($taskPlan.files)
foreach ($taskFile in $taskFiles) {
  $taskResolved = (Resolve-Path -LiteralPath $taskFile.path).Path
  $taskAllowed = $false
  foreach ($taskPrefix in $taskPlan.allowed_prefixes) {
    if ($taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { $taskAllowed = $true }
  }
  if (-not $taskAllowed -or $taskResolved -in @($taskPlan.keep_current_image, $taskPlan.keep_current_map)) { throw 'Cleanup outside exact selected workspaces or current retained image' }
  $taskInfo = Get-Item -LiteralPath $taskResolved
  if ($taskInfo.PSIsContainer -or $taskInfo.Length -ne $taskFile.bytes) { throw 'Cleanup target changed' }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Cleanup hash changed' }
}
Get-Process -Name qwen,checks,dspark-checks -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.Path -in $taskFiles.path) { throw 'Cleanup image is still running' }
}
$taskRemoved = @()
foreach ($taskFile in $taskFiles) {
  Remove-Item -LiteralPath $taskFile.path -Force
  $taskRemoved += $taskFile
}
[PSCustomObject]@{ Removed = $taskRemoved; Bytes = ($taskRemoved | Measure-Object -Property bytes -Sum).Sum; CurrentImageRetained = (Test-Path -LiteralPath $taskPlan.keep_current_image); CurrentMapRetained = (Test-Path -LiteralPath $taskPlan.keep_current_map) } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($taskRoot + '\cleanup-result.json') -Encoding utf8
