"""Finite current common-path regressions; no new formal TPS comparison."""
from pathlib import Path
import argparse,importlib.util,json,os,re,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
p=argparse.ArgumentParser();p.add_argument('--resume-completed-checks',action='store_true');p.add_argument('--attempt',type=int,default=1);args=p.parse_args()
sp=importlib.util.spec_from_file_location('av_verify_helpers',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
image=h.read(S/f'tests-link{args.attempt}/ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/f'tests-link{args.attempt}/runtime-environment.json')['PATH']
out=S/f'checks{args.attempt}';xml=out/'results.xml'
filters=':'.join(['GraphRegions.*Captur*','CudaDeviceStatus.*',
    'GraphRegions.DeferredPortsBindOriginalSourcesAndProjectOnlyAfterSuccess',
    'GraphRegions.OwnedNativeInputsKeepFirstCoveringPermissionAcrossRetryAndRebind',
    'GraphRegions.EmptyOwnedNativeInputKeepsItsValidZeroBytePermission',
    'GraphRegions.ExclusiveDeferredInputDoesNotCaptureItsUpgradeableReader',
    'GraphRegions.InputSliceAlignmentDeclinesRegionAndLeafBeforePreparation',
    'GraphRegions.CopiedSliceGetsItsOwnAlignedInputBeforeCandidateQualification'])
command=[image['path'],'--gtest_filter='+filters,'--gtest_output=xml:'+str(xml)]
process=h.read(out/'process.json')if args.resume_completed_checks else h.execute(command,env,out,timeout=120)
assert process['command']==command
assert process['exit']==0 and not process['timed_out'],process
root=ET.parse(xml).getroot();assert int(root.attrib['tests'])==29
assert all(int(root.attrib[k])==0 for k in ['failures','disabled','errors'])
assert not any(x.find('skipped')is not None for x in root.iter('testcase'))
h.save(out/'summary.json',dict(status='PASS',process=process,image=image,tests=29,failures=0,skips=0,
    cases=[x.attrib for x in root.iter('testcase')],scope='Capture lifetime plus original nonborrowed native F1 permission selection, zero-byte owned input, exclusive upgrade, failure/rebind and generated references.'))
print('CHECKS',root.attrib,flush=True)

image=h.read(S/f'hyle-link{args.attempt}/ready.json')['image'];assert h.ident(image['path'])==image
env['PATH']=h.read(S/f'hyle-link{args.attempt}/runtime-environment.json')['PATH']
previous=h.read(R/'.scratch/qwen-capture-variants-20261022/current-window/timing/runs.json')
fields=['generated_ids','actual_graph_calls','actual_target_rows','actual_draft_rows',
    'committed_target_rows','verified_target_rows','committed_target_decode_rows',
    'draft_rows','draft_rounds','agreements','accepted_drafts','generated_decode_tokens',
    'prefill_target_rows','prefill_draft_rows','visible_tokens','cache_live_requested_bytes',
    'cache_peak_requested_bytes','score_dtype','score_policy']
records=[]
for mtp in [False,True]:
    arm='hyle_mtp'if mtp else'hyle_plain';folder=S/f'screen{args.attempt}'/arm
    command=[image['path'],'--inputs',str(h.V/'inputs'/('mtp'if mtp else'text')),
        '--steps','64','--capacity','1024','--max-sessions','1','--active-sequences','1',
        '--prefix-cache','off','--progress','direct','--replay','auto','--mtp','on'if mtp else'off']
    process=h.execute(command,env,folder,timeout=120)
    assert process['exit']==0 and not process['timed_out'],process
    raw=json.loads((folder/'stdout.log').read_text().strip().splitlines()[-1]);h.save(folder/'parsed.json',raw)
    old=next(x for x in previous if x['arm']==arm)['observation']['raw']
    equal={key:raw.get(key)==old.get(key)for key in fields};assert all(equal.values()),equal
    log=(folder/'stderr.log').read_text()
    rec=dict(arm=arm,process=process,image=image,unchanged_fields=equal,
        capture_recorded=sum(map(int,re.findall(r'capture_recorded=(\d+)',log))),
        capture_reused=sum(map(int,re.findall(r'capture_reused=(\d+)',log))),
        decode_tokens_per_second=63/raw['decode_seconds'],throughput_claim=False)
    assert (rec['capture_recorded'],rec['capture_reused'])==((19,49)if mtp else(2,61))
    records.append(rec);print('SCREEN',arm,'unchanged IDs/work/budget',flush=True)
h.save(S/f'screen{args.attempt}/summary.json',dict(status='PASS',records=records,
    scope='One current ordinary and one MTP process, output/work/decisions/resource regression only. Not a formal TPS or memory window; latest four-arm table remains AU.'))
