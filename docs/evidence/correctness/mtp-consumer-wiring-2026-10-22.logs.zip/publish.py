"""Publish the completed AV implementation and finite actual results; no runs."""
from pathlib import Path
import collections,difflib,hashlib,json,re,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
COR=R/'docs/evidence/correctness/mtp-consumer-wiring-2026-10-22.json'
PERF=R/'docs/evidence/performance/qwen-mtp-assembly-2026-10-22.json'
ZIP=COR.with_suffix('.logs.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
    p=Path(p).resolve();raw=p.read_bytes()
    return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,j):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert not COR.exists()and not PERF.exists()and not ZIP.exists()
products=['src/graph/executable.cc','src/compute_provider_ggml_cuda/program.h',
    'tests/graph/region_provider_test.cc','tests/graph_route_cuda/dspark_feedback_consumer_test.cc',
    'tests/graph_route_cuda/dspark_original_confidence_test.cc','tests/graph_route_cuda/CMakeLists.txt']
for rel in products:
    p=S/'source-current'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes())
product_ids=[ident(R/p)for p in products];save(S/'source-current/identities.json',product_ids)
for group,rel in [('common','src/graph/executable.cc'),('alignment','src/compute_provider_ggml_cuda/program.h')]:
    old=S/group/'before'/rel;new=R/rel
    delta=''.join(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(True),new.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+rel,tofile=rel))
    (S/group/'final.diff').write_text(delta,encoding='utf-8')
checks=read(S/'checks4/summary.json');dspark=read(S/'dspark-checks2/summary.json')
assert checks['tests']==29 and checks['failures']==checks['skips']==0
assert dspark['tests']==2 and not any(dspark[k]for k in ['failures','errors','disabled','skips'])
props=dspark['test_properties']
assert props['FiveGreedyRowsFeedActualMarkovIdsAndKeepPriorResults']['actual_submissions']=='4'
assert props['FullWidthRawAndSidecarPolicyKeepPriorLeases']['actual_submissions']=='4'
payload=S/'original-confidence/conf_proj.weight.bf16'
assert ident(payload)['bytes']==8704 and ident(payload)['sha256']=='15c5d09c7842d0f947ce0afdc154691ead377e6263af71bd2f7cb34bd592f30f'
acquisition=read(S/'original-confidence/acquisition.json')
assert acquisition['http_status']==206 and acquisition['status']=='ACQUIRED_EXACT_ROLE'
timing=read(S/'current-window/timing/summary.json');memory=read(S/'current-window/memory/summary.json')
assert timing['processes']==12 and memory['processes']==4
assert timing['within_arm_fixed_work_valid']and memory['within_arm_fixed_work_valid']
assert all(all(x.values())for x in timing['previous_AR_work_preserved_by_arm'].values())
runs=read(S/'current-window/timing/runs.json');capture=collections.defaultdict(list)
for run in runs:
    assert run['process']['exit']==0
    if run['arm'].startswith('hyle'):
        log=(Path(run['folder'])/'stderr.log').read_text(encoding='utf-8')
        values=dict(recorded=sum(map(int,re.findall(r'capture_recorded=(\d+)',log))),
            reused=sum(map(int,re.findall(r'capture_reused=(\d+)',log))))
        assert tuple(values.values())==((2,61)if run['arm']=='hyle_plain'else(19,49))
        capture[run['arm']].append(values)
old=read(R/'.scratch/qwen-capture-variants-20261022/current-window/timing/summary.json')
old_memory=read(R/'.scratch/qwen-capture-variants-20261022/current-window/memory/summary.json')
comparisons={}
for mode in ['plain','mtp']:
    ours=timing['groups']['hyle_'+mode];peer=timing['groups']['peer_'+mode]
    comparisons[mode]={metric:100*(ours[metric]['median']/peer[metric]['median']-1)
        for metric in ['prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second']}
    for arm in ['hyle_'+mode,'peer_'+mode]:
        comparisons[mode][arm+'_descriptive_decode_change_vs_AU_percent']=100*(timing['groups'][arm]['full_decode_tokens_per_second']['median']/old['groups'][arm]['full_decode_tokens_per_second']['median']-1)
    comparisons[mode]['causal_speedup_claim_vs_AU']=False
within={engine:dict(decode_MTP_change_percent=100*(timing['groups'][engine+'_mtp']['full_decode_tokens_per_second']['median']/timing['groups'][engine+'_plain']['full_decode_tokens_per_second']['median']-1),
    combined_MTP_change_percent=100*(timing['groups'][engine+'_mtp']['session_output_tokens_per_second']['median']/timing['groups'][engine+'_plain']['session_output_tokens_per_second']['median']-1))for engine in ['hyle','peer']}
gpu_deltas={}
for arm in timing['groups']:
    a=memory['groups'][arm]['sampled_peaks'];b=old_memory['groups'][arm]['sampled_peaks']
    gpu_deltas[arm]={k:a[k]-b[k]for k in ['sampled_peak_gpu_dedicated_bytes','sampled_peak_gpu_shared_bytes','sampled_peak_gpu_total_bytes']}
    assert all(v==0 for v in gpu_deltas[arm].values())
image=read(S/'hyle-link4/ready.json')['image'];assert ident(image['path'])['sha256']==image['sha256']
review=read(S/'review/alignment-capability-review.json')
performance=dict(status='COMPLETE_FIXED_FOUR_ARM_WINDOW_NOT_CAUSAL_SPEEDUP',date='2026-10-22',goal_complete=False,
    image=image,product_changes=product_ids,timing=timing,independent_memory=memory,
    comparisons=comparisons,within_engine_MTP=within,capture_counts=dict(capture),GPU_sampled_peak_byte_change_vs_AU=gpu_deltas,
    actual_work={arm:next(x for x in runs if x['arm']==arm)['observation']['work']for arm in timing['groups']},
    reference_AU=ident(R/'docs/evidence/performance/qwen-capture-variants-2026-10-22.json'),
    scope='Current AV original BF16 Qwen3.5-2B, RTX4070, full CUDA; fixed P154/64 visible outputs, C1024 N1/R1, prefix off, replay auto; greedy K1. Three interleaved timing processes per arm; independent one-process memory sample per arm.',
    limits=[
        'Both current Hyle and unchanged peer are faster than AU. No causal performance improvement is claimed for the small AV host/alignment changes; previous windows are not pooled.',
        'Ordinary and MTP common-path performance are reported separately. Within-engine MTP gains and cross-engine gap changes describe natural complete consumers, not an exclusive attribution to MTP overhead.',
        'The inherited previous_AR_work_preserved_by_arm key now compares the actual immediately prior AU runs; the archived driver preserves this reference path.',
        'Cross-engine continuations diverge at output19; BF16/F32 intermediate arithmetic, draft prefill and acceptance work differ. There is no same-token/per-operation same-math or complete quality claim.',
        'Complete decode includes all63 outputs after prefill through the host-visible endpoint, including binding, capture, waits and result processing. Combined=64/(prefill+decode), excluding loading; single turn, not multi-round or serving throughput.',
        'All timing samples and ranges retained. Three processes per arm give descriptive medians, not a universal statistical guarantee. Memory sampling is independent and not TPS evidence.',
        'PSAPI/PDH per-process peaks are not exact physical allocation. Dedicated/shared peaks cannot be summed; GPUtotal is sampled at the same instant. CPU WS/commit and shared GPU memory overlap. Unknown driver/capture private bytes remain unknown.'])
correctness=dict(status='IMPLEMENTED_FINITE_CONSUMER_AND_COLD_ALIGNMENT_CHECKS_PASS',date='2026-10-22',goal_complete=False,
    product_changes=product_ids,public_API_changed=False,model_provider_whitelist_added=False,SDK_builds=0,NVCC_builds=0,shader_builds=0,
    implementation=dict(
        lease_lookup='Collect the current resource episode ReadLease candidates once, at the first actual nonborrowed native lookup. Optional distinguishes never-built from a valid empty list; existing borrowed-carrier facts are reused, without an extra provider-query pass. No cross-episode permission/readiness cache.',
        alias_qualification='After actual local resource/alias placement, reject incompatible known static owned caller-buffer input offsets before preparing the candidate. Reuse original region/leaf suffix retry and hard required-instance constraints. A real materializing Copy has a new root. Symbolic, external, constant and generated unknown bases retain original later validation.',
        F32_Add='GGML CUDA F32 Binary(Add) declares natural4B alignment. Actual linked native normal/unravel and multi-Add scalar32 accesses, same-dtype semantic contract and other fused-reader guards were checked. Other op/dtype requirements and workspace allocation alignment remain unchanged.',
        feedback='Ordinary Graph five-row actual TopK1 I32 output drives the next Markov Gather, F32 bias and selected token. Confidence pairs original collapsed BF16 hidden with that row token_i Markov embedding. A separate teacher-forced path supplies a counterexample.',
        original_role='Exact8704B trained sidecar BF16 conf_proj.weight, full hidden4096+Markov256 BF16 inputs, cold exact F32 parameter widening, Concat/Cast/F32 MatMul raw output and a separately declared sigmoid probability. No new model-specific public API or GPU kernel.'),
    checks=dict(common=checks,dspark=dspark,ordinary_MTP_screen=read(S/'screen4/summary.json'),
        linked_native_alignment_review=review,lease_lifetime_review=read(S/'review/lease-lookup-final.json'),
        alias_route_source_review=read(S/'alias-route/source-freeze.json'),
        original_payload=dict(acquisition=acquisition,identity=ident(payload)),
        first_graph_alias_rejection=ident(S/'dspark-checks1/summary.json'),
        historical_driver_count_correction='Initial common selector union ran27, allpassed; an expected28 parser assertion double-counted ExclusiveDeferredInput already matched by Captur. The completed process was analyzed without rerun.',
        build_corrections='First head recipe lacked CUDA include paths; reused cached CUDA test recipe. Original-role TU used Windows-deprecated getenv; switched to owned _dupenv_s and corrected string c_str call. Strict warning/error flags stayed enabled; failed command/log receipts retained.'),
    remaining=['Other applicable original MTP role/codec bindings and full model-specific draft/target accepted-prefix state adapters remain incomplete. Finite test consumers do not require building eight production inference engines.',
        'DSpark synthetic head boundary is V17/H8/Markov4 with20 proposal rows over4 submissions. It does not execute full129280-vocabulary trained Markov/LM weights, the three trained draft stages, target verification or accepted complete state.',
        'One trained confidence role and finite source-correct synthetic feedback do not certify the whole artifact, semantic quality, all quantization formats or other backends.',
        'Q35 greedy K1 main protocol and listed finite state/lifetime checks already exist; the prior8QKV investigation is closed. Remaining shared decode gap belongs to the ongoing performance line, not proof of an MTP calculation defect.',
        'No new current full-state vector/prefix matrix was run after this host/cold-binding batch. Current checks are the29 targeted cases, two actual DSpark consumers, ordinary/MTP screens and full performance processes. Earlier AU/AQ state evidence keeps its own scope.',
        'Images remain deferred; the broad active capability/architecture/performance goal is not complete.'],
    source_scope_review=ident(R/'docs/evidence/research/mtp-artifact-scope-2026-10-22.json'),performance_result=str(PERF.relative_to(R)))
selected=[p for p in S.rglob('*')if p.is_file()and p.suffix.lower()in ['.json','.py','.cc','.h','.diff','.log','.xml','.tsv','.txt','.bf16']and '__pycache__'not in p.parts and 'tmp'not in p.parts]
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in sorted(selected):z.write(p,p.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP)as z:assert z.testzip()is None
performance['archived_logs']=ident(ZIP);correctness['archived_logs']=ident(ZIP)
save(PERF,performance);save(COR,correctness)
save(S/'publication-receipt.json',dict(correctness=ident(COR),performance=ident(PERF),logs=ident(ZIP),goal_complete=False))
print(json.dumps(dict(correctness=ident(COR),performance=ident(PERF),logs=ident(ZIP),comparisons=comparisons,within_engine_MTP=within),indent=2))
