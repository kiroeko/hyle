"""Archive final documentation and the already executed cleanup; no builds or runs."""
from pathlib import Path
import collections
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
COR = R / 'docs/evidence/correctness/mtp-consumer-wiring-2026-10-22.json'
PERF = R / 'docs/evidence/performance/qwen-mtp-assembly-2026-10-22.json'
ZIP = COR.with_suffix('.logs.zip')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def ident(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n',
                          encoding='utf-8')


correctness, performance = read(COR), read(PERF)
assert 'finalization' not in correctness and 'finalization' not in performance
for expected in correctness['product_changes']:
    assert ident(R / expected['path']) == expected, expected['path']
image = performance['image']
actual_image = ident(image['path'])
assert all(actual_image[key] == image[key] for key in ('bytes', 'sha256'))
assert Path(image['path']).with_suffix('.map').is_file()
cleanup = read(S / 'cleanup-result.json')
assert len(cleanup['Removed']) == 18
assert sum(row['bytes'] for row in cleanup['Removed']) == int(cleanup['Bytes']) == 1807132794
assert cleanup['CurrentImageRetained'] and cleanup['CurrentMapRetained']
for removed in cleanup['Removed']:
    assert not Path(removed['path']).exists(), removed['path']

docs = [
    'docs/developer/current-work.md',
    'docs/developer/performance/decode.md',
    'docs/implementation/model-operators.md',
    'docs/implementation/model-quantizations.json',
    'docs/architecture/graph-design.md',
]
finalization = dict(
    status='ARCHIVED_FINAL_DOCUMENTATION_AND_ALREADY_EXECUTED_CLEANUP',
    no_additional_build_test_or_model_run=True,
    documentation=[ident(R / path) for path in docs],
    cleanup=dict(
        removed_files=18, removed_bytes=1807132794,
        current_image=actual_image,
        current_map=ident(Path(image['path']).with_suffix('.map')),
        scope='Only the eighteen exactly listed obsolete exe/map files were removed. '
              'No object, dependency, SDK, source or original role payload path was deleted.',
        result=ident(S / 'cleanup-result.json'),
        deletion_script=ident(R / 'test.ps1'),
        already_executed=True, rerun_cleanup=False),
    goal_complete=False,
)
save(S / 'finalization.json', finalization)
additions = [(S / name, name) for name in (
    'prepare_cleanup.py', 'cleanup-plan.json', 'cleanup-result.json',
    'finalize.py', 'finalization.json')]
additions.append((R / 'test.ps1', 'cleanup/test.ps1'))
additions.extend((R / path, 'documentation/' + path) for path in docs)
with zipfile.ZipFile(ZIP) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names))
    assert not (set(names) & {name for _, name in additions})
with zipfile.ZipFile(ZIP, 'a', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path, name in additions:
        archive.write(path, name)
with zipfile.ZipFile(ZIP) as archive:
    counts = collections.Counter(archive.namelist())
    assert max(counts.values()) == 1
    assert archive.testzip() is None
archive_identity = ident(ZIP)
for path, document in ((COR, correctness), (PERF, performance)):
    document['archived_logs'] = archive_identity
    document['finalization'] = finalization
    save(path, document)
receipt = dict(correctness=ident(COR), performance=ident(PERF), logs=archive_identity,
               finalization=ident(S / 'finalization.json'), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
