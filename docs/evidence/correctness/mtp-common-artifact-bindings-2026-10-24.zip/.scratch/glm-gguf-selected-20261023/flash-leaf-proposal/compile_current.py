"""Compile the new pure Flash builder headers; no data or native execution."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[2]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def identity(p):
    p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
h=module('leaf_environment',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=module('leaf_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
before=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/consumer1/records/flash-state-attempt2/identity.json'
recipe=read(before)
out=S/'compile1';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
source=out/'packed-flash-headers.cc'
source.write_text('#include "glm_gguf_flash_fragment.h"\n',encoding='utf-8')
command=[]
for arg in recipe['command']:
    if arg==recipe['source']['path']:arg=str(source)
    elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'packed-flash-headers.obj')
    elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'packed-flash-headers.pdb')
    command.append(arg)
command[command.index('/sourceDependencies')+1]=str(out/'dependencies.json')
command.insert(1,'/I'+str(R/'tests/compute_models'))
env,_=h.b.environment(command,[],out);env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
result=q.execute(command,env,out/'run',timeout=1800)
if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
data=read(out/'dependencies.json')['Data']
record=dict(source=identity(source),object=identity(out/'packed-flash-headers.obj'),command=command,
    recipe=identity(before),dependencies=[identity(x)for x in dict.fromkeys([data['Source'],*data['Includes']])],
    scope='Actual C++ compilation of pure builder headers; no original weights, numerical or state execution claim.')
(out/'identity.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('COMPILED shared packed Flash builders; original B12/B13 execution pending',flush=True)
