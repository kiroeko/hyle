from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[5];S=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
checks=[];files=[Path(__file__),S/'build.py',S/'tests-link1/ready.json',S/'tests-link1/runtime-environment.json',S/'compile1/qwen-state/identity.json']
for attempt,backend in [(1,'cpu'),(2,'cuda')]:
    out=S/f'checks{attempt}';d=read(out/'summary.json')
    assert d['passed'] and d['tests']==1 and d['failures']==d['skips']==0
    assert d['properties']['actual_submissions']=='23' and d['properties']['target_dense_weight_materializations']=='0'
    checks.append(dict(backend=backend,summary=ident(out/'summary.json'),graphs=23,properties=d['properties']))
    files += [out/'summary.json',out/'results.xml',out/'plan.json',out/'run/command.json',out/'run/process.json',out/'run/stdout.log',out/'run/stderr.log']
b07=R/'.scratch/qwen-gguf-selected-20261023/B07/consumer-proposal'
glm=R/'.scratch/glm-gguf-selected-20261023/flash-leaf-proposal'
for base in [b07,glm]:
    files += [base/'source.patch',base/'ready.json',base/'applied.json']
facts=read(b07/'source-facts.json')
files += [b07/'source-facts.json']
for item in facts['files']:
    p=R/item['path'];assert ident(p)['sha256']==item['after_sha256'];files.append(p)
for item in read(glm/'ready.json')['files']:
    p=R/item['path'];assert ident(p)['sha256']==item['after']['sha256'];files.append(p)
files += [glm/'compile_current.py',glm/'compile1/identity.json',glm/'compile1/packed-flash-headers.cc',glm/'compile1/run/process.json',glm/'compile1/run/command.json',glm/'compile1/run/stdout.log',glm/'compile1/run/stderr.log']
name=R/'docs/evidence/correctness/mtp-common-artifact-bindings-2026-10-24'
with zipfile.ZipFile(name.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in dict.fromkeys(files):z.write(p,p.relative_to(R).as_posix())
d=dict(status='Common test-consumer source applied and compiled; existing Q01 CPU/CUDA original regression passed',
       changes=dict(qwen='One cold packed-MoE role view for primary Q24 and B07 actual descriptor/selected-expert sources; same Recipe/Program/StateHead/K1. Dense Q01/Q03/B04/Q14 paths retained.',
                    glm='Shared cold packed projection hooks, original negative-exp KDA rate, explicit pooled scale/order and shared clamp; same pooled builders and sixteen-state shape.'),
       checks=checks,original_regression_cases=2,original_regression_graphs=46,failures=0,skips=0,
       new_GLM_pure_builder_compilation=ident(glm/'compile1/identity.json'),
       new_B07_original_execution=False,new_B12_B13_original_execution=False,
       limits='Q01 verifies its own dense GPTQ/BF16 path. It does not validate original B07 MoE or GLM Flash quantized data. These still require their own real headers, payloads, observers and state runs.',
       throughput_evidence=False,physical_memory_evidence=False,archive=ident(name.with_suffix('.zip')),
       files=[ident(p)for p in dict.fromkeys(files)])
name.with_suffix('.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(ident(name.with_suffix('.json'))))
