"""Reuse existing authenticated Q01 data to check the shared Qwen source edit."""
from pathlib import Path
import hashlib, importlib.util, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
adapter=load('q01_original_metadata_only',S.parent/'native-integration/build.py')
adapter.S=S
adapter.ENTRY_SCRIPT=Path(__file__).resolve()
path=S.parents[1]/'native_build_current.py'
assert hashlib.sha256(path.read_bytes()).hexdigest()=='fc0bea30eabdf82286447fe29549bcf430204958c886007fb0963237ce764eb8'
helper=load('qwen_current_one_tu_regression',path)
if __name__=='__main__':helper.main(adapter,Path(__file__).resolve())
