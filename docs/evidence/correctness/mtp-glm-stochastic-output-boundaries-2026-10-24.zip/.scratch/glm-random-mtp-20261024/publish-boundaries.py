from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
S=Path(__file__).resolve().parent;R=S.parents[1];T=R/'.scratch/glm-sampled-boundaries-20261024'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
records=[S/'build-boundaries.py',S/'publish-boundaries.py'];cases=[]
for kind,attempt in [('flash',2),('pro',1)]:
 folder=T/kind/f'attempt{attempt}';run=folder/'run1';root=ET.parse(run/'results.xml').getroot();assert root.attrib['tests']=='1' and root.attrib['failures']=='0' and read(run/'process.json')['exit']==0
 stdout=(run/'stdout.log').read_text(errors='replace')
 transitions=[line for line in stdout.splitlines() if 'RANDOM TAIL ' in line or 'RANDOM BOUNDARY ' in line or 'RANDOM K1 ' in line or 'GLM Pro K1 stochastic=' in line]
 case=next(root.iter('testcase'))
 cases.append(dict(kind=kind,result=root.attrib,process=read(run/'process.json'),commands=read(run/'command.json'),image=read(folder/'ready.json'),properties={p.attrib['name']:p.attrib['value'] for p in case.iter('property')},actual_transitions=transitions,source=read(folder/'source-identity.json')['source']))
 records.extend(p for p in folder.rglob('*') if p.is_file() and (p.suffix in ('.json','.log','.xml') or (folder/'source') in p.parents))
 # Only original source identities/acquisition manifests are inherited; no
 # parameter payload, object, DLL, SDK archive or executable enters evidence.
out=R/'docs/evidence/correctness/mtp-glm-stochastic-output-boundaries-2026-10-24';archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(records)):z.write(p,p.relative_to(R))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
summary=dict(date='2026-10-24',status='PASS finite original-role CUDA Flash and Pro stochastic output-boundary journeys',
 implementation=['One shared pure hyle::inference::mtp::select_sampled_prefix selects consumed target rows and emitted pending IDs. The random acceptance flag alone no longer chooses the committed state.',
 'An accepted proposal stopped by EOS or post-verification quota stays pending in its original I32 q-proposal lease; only after-current target/NextN state is published. A consumed accepted nonterminal proposal uses the original repaired prefix; a bonus EOS stays unconsumed pending after that prefix.',
 'Explicit model-private SamplingLimits contains output quota, remaining context and EOS IDs. Invalid zero limits/out-of-vocabulary EOS reject at controller entry before its cold graph work; source arguments can already be authenticated by the caller. One-row quota/context tails retain mandatory-current target+NextN maintenance, project actual target p0 through the same original one-row full head, draw once, and publish no q proposal or second row.',
 'Finite limits describe one component verifier episode and stop its automatic continuation. Default unbounded fixtures retain the existing real second-round/pending continuation. Thin Flash plain/GGUF/source adapters forward the same limits; Pro official/converted template receives the same type.',
 'Independent expected-base boundary Heads reuse the actual retired original resources and real proposal/residual/bonus leases. Reserved RNG ranges publish atomically with all resources and pending; no host ID reconstruction, state rollback by approximate hidden, logit/p/q mutation or TopK substitution.'],
 cases=cases,
 coverage=['Flash: actual target43+44+complete NextN, natural rejection and a separately labelled legal opposite acceptance from bounded independent Philox address search. Both genuine p/q branches retain original cancellation/stale retry/RNG and complete-state continuation checks.',
 'Flash: target-only p0 ID78176, complete after-current cursor2055 and one committed draw; independent ordinary/EOS one-row Heads with zero speculative-second submissions. Actual quota1/rejected residual EOS144924, accepted proposal EOS100550 and bonus EOS92526 select consumed1/1/2 respectively.',
 'Pro: original target77+complete NextN78 natural rejection; target-only p0 ID43038 one-row tail/terminal control, post-verification quota1/residual EOS16495, immutable retained complete state and original target-only pending continuation28122. The complete true-source task output remains a finite component fixture.'],
 verification=dict(new_SDK_or_provider_TUs=0,new_HTTP_requests=0,new_weight_bytes=0,consumer_TUs=2,strict_MSVC_W4_WX=True,CUDAruntime_cases=2,throughput_or_physical_memory_claim=False),
 limits=['EOS IDs in boundary controls are chosen from the actual generated IDs to exercise the caller policy. They are not claimed to be the source tokenizer natural EOS or a quality/termination result of a full model task.',
 'The one-row tail includes mandatory-current NextN maintenance to keep target and draft at the same prefix; it avoids proposal sampling and second-token execution, not all NextN work.',
 'A stopped final emitted token remains pending and is not inserted into committed KV/conv/index state. RNG advance reflects the actual verified proposal width/address reservation, including explicitly controlled acceptance addresses, rather than the number of consumed rows.',
 'This is not a complete GLM inference engine/server/scheduler, full trained trunk generation, multi-backend matrix, each publisher runtime, natural acceptance-rate measurement or performance result. Source component upstream/history adapters remain as documented in inherited evidence.',
 'Q30/B09 entry paths were compiled with their actual artifact gates in the new consumer TUs. Their previous runtime images and source journeys remain separate; this evidence does not relabel the old quantized images as new EOS/quota checks.'],
 inherited_evidence=['docs/evidence/correctness/mtp-glm-original-stochastic-state-2026-10-24.json','docs/evidence/correctness/mtp-qwen24-original-stochastic-state-2026-10-24.json'],archive=identity(archive),archive_records=len(set(records)))
out.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(identity(archive))
