#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <vector>

// Host policy for one retired, finite verifier. This owns no model state,
// sampler or cache. The final emitted token remains pending; only consumed
// target rows may select a committed conv/GDN/KV prefix.
namespace hyle::inference::mtp {
struct AcceptedPrefix final {
  // Nonterminal accepted proposals that entered model state, not acceptance
  // probability/count of emitted proposals. An accepted EOS is still pending.
  std::size_t consumed = 0, consumed_drafts = 0;
  std::int32_t next_id = -1;
  bool first_agrees = false, stopped = false;
};
namespace detail {
inline void token_ids(std::span<const std::int32_t> ids, std::int32_t vocabulary) {
  if (vocabulary <= 0 || std::ranges::any_of(ids,
      [vocabulary](auto id) { return id < 0 || id >= vocabulary; }))
    throw std::runtime_error("MTP prefix contains an invalid token ID or vocabulary");
}
template<class Accept, class Final>
AcceptedPrefix choose_prefix(std::span<const std::int32_t> inputs,
    std::size_t quota, std::span<const std::int32_t> eos,
    std::vector<std::int32_t> &emitted, Accept accept, Final final_id) {
  if (inputs.empty() || !quota) throw std::runtime_error("MTP selection needs a pending input and positive output quota");
  const auto ended = [&](auto id) { return std::ranges::find(eos, id) != eos.end(); };
  if (ended(inputs.front())) throw std::runtime_error("MTP cannot consume a terminal pending token");
  emitted.clear(); emitted.reserve((std::min)(quota, inputs.size()));
  AcceptedPrefix result;
  const auto proposals = inputs.size() - 1;
  for (std::size_t row = 0; row <= proposals; ++row) {
    const bool agrees = row < proposals && accept(row);
    if (!row) result.first_agrees = agrees;
    const auto token = agrees ? inputs[row + 1] : final_id(row);
    emitted.push_back(token);
    // Even a matching/accepted EOS is an emitted pending token. Quota has the
    // same boundary: never consume the last output merely because it agrees.
    if (!agrees || ended(token) || emitted.size() == quota) {
      result.consumed = row + 1; result.next_id = token; result.stopped = ended(token);
      return result;
    }
    ++result.consumed_drafts;
  }
  throw std::runtime_error("MTP prefix selection did not reach a final output");
}
} // namespace detail

inline AcceptedPrefix select_greedy_prefix(std::span<const std::int32_t> inputs,
    std::span<const std::int32_t> target_ids, std::size_t quota,
    std::span<const std::int32_t> eos, std::int32_t vocabulary,
    std::vector<std::int32_t> &emitted) {
  if (inputs.size() != target_ids.size()) throw std::runtime_error("MTP greedy target rows differ from verifier inputs");
  detail::token_ids(inputs, vocabulary); detail::token_ids(target_ids, vocabulary);
  return detail::choose_prefix(inputs, quota, eos, emitted,
      [&](auto row) { return inputs[row + 1] == target_ids[row]; },
      [&](auto row) { return target_ids[row]; });
}

// Each final_ids[i] is the public sampling::decision result for p_i/q_i:
// rejection uses its residual; acceptance uses p_{i+1}. Only the first rejected
// row or the last accepted row's bonus is selected, with one final RNG address.
inline AcceptedPrefix select_sampled_prefix(std::span<const std::int32_t> inputs,
    std::span<const std::uint8_t> accepts, std::span<const std::int32_t> final_ids,
    std::size_t quota, std::span<const std::int32_t> eos, std::int32_t vocabulary,
    std::vector<std::int32_t> &emitted) {
  if (inputs.size() == 1 && accepts.empty() && final_ids.size() == 1) {
    detail::token_ids(inputs, vocabulary); detail::token_ids(final_ids, vocabulary);
    return detail::choose_prefix(inputs, quota, eos, emitted,
        [](auto) { return false; }, [&](auto) { return final_ids[0]; });
  }
  if (inputs.size() < 2 || accepts.size() != inputs.size() - 1 || final_ids.size() != accepts.size() ||
      std::ranges::any_of(accepts, [](auto value) { return value > 1; }))
    throw std::runtime_error("MTP sampled prefix needs one valid decision per proposal");
  detail::token_ids(inputs, vocabulary); detail::token_ids(final_ids, vocabulary);
  return detail::choose_prefix(inputs, quota, eos, emitted,
      [&](auto row) { return accepts[row] != 0; },
      [&](auto row) { return final_ids[(std::min)(row, final_ids.size() - 1)]; });
}
} // namespace hyle::inference::mtp
