from pathlib import Path
import json,hashlib,struct,copy
from engine.models.qwen35 import prepare,geometry
R=Path.cwd();B=R/'.scratch/mtp-q27-fp8-20261024/cat08-tiny-loader2';B.mkdir(exist_ok=False)
c=json.loads((R/'.scratch/model-quantization-discovery-2026-10-19/qwen-kimi/unsloth--Qwen3.8-27B-NVFP4/config.json').read_text());t=c['text_config'];t.update(hidden_size=16,intermediate_size=32,vocab_size=32,num_attention_heads=2,num_key_value_heads=1,head_dim=4,linear_num_key_heads=1,linear_num_value_heads=2,linear_key_head_dim=2,linear_value_head_dim=2,linear_conv_kernel_dim=2,max_position_embeddings=32,num_hidden_layers=2,mtp_num_hidden_layers=1,layer_types=['linear_attention','full_attention'],tie_word_embeddings=True);t['rope_parameters'].update(partial_rotary_factor=.5,mrope_section=[1])
c['tie_word_embeddings']=True
g=geometry.from_hf(c);specs=[]
def add(n,d,shape,data=None):
 count=prepare.ROLE_SIZES[d]
 for v in shape:count*=v
 if data is None:data=b'\0'*count
 assert len(data)==count
 specs.append((n,d,list(shape),data))
for n,shape in geometry.role_shapes(g).items():
 if n=='model.language_model.layers.1.self_attn.k_proj.weight':
  add(n,'F8_E4M3',shape,b'\x38'*(shape[0]*shape[1]));add(n[:-7]+'.weight_scale','BF16',[shape[0],1],b'\x80\x3c'*shape[0])
 elif n=='model.language_model.layers.0.mlp.gate_proj.weight':
  out,k=shape;add(n[:-7]+'.weight_packed','U8',[out,k//2],b'\x23'*(out*k//2));add(n[:-7]+'.weight_scale','F8_E4M3',[out,k//16],b'\x38'*(out*k//16));add(n[:-7]+'.weight_global_scale','F32',[1],struct.pack('<f',2.0));add(n[:-7]+'.input_global_scale','F32',[1],struct.pack('<f',3.0))
 else:add(n,'BF16',shape)
for which in ['k','v']:add('model.language_model.layers.1.self_attn.'+which+'_scale','BF16',[1],b'\x00\x3f')
raw=bytearray();rows=[]
for n,d,shape,data in specs:
 raw.extend(b'\0'*((-len(raw))%16));off=len(raw);raw.extend(data)
 rows.append(dict(name=n,dtype=d,shape=shape,path=str(B/'original.bin'),offset=off,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert len(raw)<1048576
(B/'original.bin').write_bytes(raw);(B/'config.json').write_text(json.dumps(c,indent=2)+'\n')
source=dict(complete=True,repository='synthetic/ct-mixed-loader',revision='a'*40,roles=rows)
(B/'roles.json').write_text(json.dumps(source,indent=2)+'\n')
lines,receipt=prepare.prepare_role_files(B/'roles.json',True,c,prepare.CT_MIXED_READER,'bf16')
(B/'weights.tsv').write_text('\n'.join(lines)+'\n');(B/'input.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(source_id=receipt['source_id'],physical_roles=receipt['physical_roles'],metadata_roles=receipt['metadata_tensor_count'],payload_bytes=len(raw),omitted=receipt['cache_calibration_omission']['bytes'],HTTP=0,models_started=0)))
