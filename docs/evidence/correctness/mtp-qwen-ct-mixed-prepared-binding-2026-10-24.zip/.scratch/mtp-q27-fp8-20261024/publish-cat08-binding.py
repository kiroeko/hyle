from pathlib import Path
import json,hashlib,zipfile
R=Path.cwd();B=R/'.scratch/mtp-q27-fp8-20261024';D=R/'docs/evidence/correctness/mtp-qwen-ct-mixed-prepared-binding-2026-10-24.json'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
contract=load(B/'cat08-cached-target-contract.json');plan=load(B/'cat08-minimal-tiles-plan.json');tiles=[]
for index in range(8):
 f=B/'cat08-tiles'/f'{index:02d}';receipt=load(f/'complete.json');record=ident(f/'payload.bin')
 assert receipt['tile']==plan['tiles'][index]and record['bytes']==receipt['bytes']==receipt['tile']['bytes']and record['sha256']==receipt['sha256']
 assert receipt['response']['status']==206 and receipt['response']['final_url']==receipt['tile']['url']
 tiles.append(dict(tile=receipt['tile'],payload=record,receipt=ident(f/'complete.json')))
assert sum(x['payload']['bytes']for x in tiles)==39380
for file in ['main.cc','prepared_roles.h']:
 assert ident(R/'engine/models/qwen35'/file)['sha256']==ident(B/'cat08-binding-cpu2/source/engine/models/qwen35'/file)['sha256']
 for backend in ['cuda']:
  assert ident(B/f'cat08-binding-{backend}2/source/engine/models/qwen35'/file)['sha256']==ident(B/'cat08-binding-cpu2/source/engine/models/qwen35'/file)['sha256']
cases=[]
for backend in ['cpu','cuda']:
 f=B/f'cat08-binding-{backend}2';process=load(f/'run/process.json');assert process['exit']==0
 raw=(f/'run/stdout.log').read_text();assert raw.count('PASS recipe=')==3 and 'output_preround_witnesses=3'in raw
 cases.append(dict(backend=backend,status='PASS',process=process,original_graphs=3,original_output_values=27,oracle='Independent finite scalar F32/BF16/E4M3/E2M1 arithmetic; F64 dot over stored BF16 operands, then RNE BF16 output, widened exactly for logits',nonzero_BF16_results_equal=True,signed_zero='Compared numerically; zero sign is unconstrained, so no general bitwise-equality claim',raw_log=ident(f/'run/stdout.log'),source=ident(f/'sources.json'),fresh_consumer_TUs=1,additional_SDK_builds=0))
metadata=load(B/'cat08-metadata1/original-headers-result.json');tiny=load(B/'cat08-tiny-loader2/input.json')
assert metadata['channel_groups']==233 and metadata['local_groups']==168 and metadata['omitted_cache_calibration']==32
proof=dict(status='PASS',date='2026-10-24',scope='Fixed CT0.17.2 channel/token FP8 plus local NVFP4 prepared-input binding and ordinary/MTP cold loader; original small projection components only, no complete27B generation.',source=dict(repository=contract['repository'],revision=contract['revision'],original_target=contract['source'],target_header=contract['header'],whole_target_body_acquired_or_LFS_verified=False,sidecar_header=ident(R/'.scratch/mtp-metadata-offline-20261024/cat08/header.json'),sidecar_original_identity=load(R/'.scratch/mtp-metadata-offline-20261024/cat08/file-identity.json'),whole_sidecar_body_acquired_or_LFS_verified=False),source_geometry=dict(hidden=5120,layers=64,gdn_layers=48,full_attention_layers=16,independent_head=True),binding=dict(channel=dict(groups=233,codes='original E4M3FN[N,K]',scales='original BF16[N,1]',activation='BF16 row absmax/448 typed divide; replace only exactly zero with1/128; BF16 normalize/clip→E4M3→BF16 dequant; original E4M3 W×BF16 SF rounds to BF16 before F32 dot and BF16 output'),local=dict(groups=168,operation='LocalNvfp4Linear(Fp4InputRounding::kFloat32)',original_WG_IG='Retained independent F32 quantization multipliers; passed unchanged, not reciprocated into ModelOpt fields'),scores='Reuse source projection BF16 result and widen to F32 logits',cache_omission='Separate explicit BF16-KV omission manifest line; only geometry-derived full-attention original BF16[1] k_scale/v_scale pairs, retained names/shapes/hashes and reason in source identity/receipt; unknown roles reject',ordinary_and_MTP='Same full-inventory validation and source identity; select only needed physical weights for IO',unrelated_sources='No new policy line or identity field for unrelated dense/GPTQ/NVFP4/CTsym/block128 sources'),metadata=metadata,metadata_tests=load(B/'cat08-metadata1/observed-metadata-checks.json'),tiny_loader=dict(source='Synthetic complete2-layer GA geometry, not trained model generation',source_id=tiny['source_id'],source_payload_bytes=13682,ordinary_selected_roles=31,ordinary_selected_bytes=8268,MTP_selected_roles=46,MTP_selected_bytes=13564,omitted_original_BF16_cache_roles=2,omitted_bytes=4,original_hashes_authenticated_by_product_preparer=True,actual_load_weight_bank_cpu=True,auxiliary_bank_allocations=0,original_policy_and_identity_preserved=True,canonical_bank_bytes_equal_original_selected_bytes=True),original_tile_bytes=39380,original_tile_records=tiles,cases=cases,numerical_witnesses=dict(attention=dict(original_non_BF16_weight_products=4401,final_weight_product_rounding=2,final_zero_only_epsilon_vs_floor=3),head=dict(original_non_BF16_weight_products=12501,final_weight_product_rounding=2,final_zero_only_epsilon_vs_floor=6),local=dict(original_WG=6400,original_IG=836,final_F32_vs_BF16_preround=3)),initial_setup_failures_preserved=['Synthetic scratch config first mismatched top-level/text tied flags; no payload or model IO occurred. Corrected both flags in a new fixture directory.','First private probe passed WeightSelection and Geometry to load_weight_bank in the wrong order; both compiler failures retained. Corrected probe argument order; product code did not change for this fix.'],additional_HTTP_by_this_task=0,additional_SDK_builds=0,whole_model_runs=0,performance_claim=False,limitations=['This source has only header/selected trained tiles, not all21.65GB target text weights or849MB BF16 sidecar body; complete27B generation remains unverified.','CPU component uses the actual CPU endpoint of the retained standard SDK closure, not a new pure-CPU deployment certification.','Only CPU/CUDA original-component routes were executed here; existing synthetic primitive coverage does not substitute for new Apple/Vulkan full-model evidence.','The real original headers drive1635 metadata roles,1603 selected with MTP and1588 text-only roles. Their metadata-only fixture identity is explicitly not a whole-payload source fingerprint.','Numerical equality is finite-value equality with zero sign unconstrained; this is not a complete task-quality guarantee.','No throughput or whole-model memory inference follows from these small correctness graphs.'])
files=[]
def add(p):
 if p.is_file()and p not in files:files.append(p)
for p in [Path(__file__).resolve(),B/'cat08-binding-probe.cc',B/'build-cat08-binding.py',B/'run-cat08-binding.py',B/'check-cat08-metadata.py',B/'prepare-cat08-tiny.py',B/'cat08-cached-target-contract.json',B/'cat08-minimal-tiles-plan.json',B/'cat08-bf16-cache-auxiliary-roles.json'] :add(p)
for p in [R/contract['header']['path'],R/contract['preamble']['path'],R/contract['config']['path'],R/'.scratch/mtp-metadata-offline-20261024/cat08/header.json',R/'.scratch/mtp-metadata-offline-20261024/cat08/header-length.bin',R/'.scratch/mtp-metadata-offline-20261024/cat08/file-identity.json',R/'.scratch/mtp-metadata-offline-20261024/cat08/acquisition.json']:add(p)
for f in [B/'cat08-metadata1',B/'cat08-metadata1/compile',B/'cat08-metadata1/run',B/'cat08-tiny-loader',B/'cat08-tiny-loader2']:
 for p in sorted(f.iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.jsonl','.log','.tsv','.bin']:add(p)
for backend in ['cpu','cuda']:
 f=B/f'cat08-binding-{backend}2'
 for p in [f/'ready.json',f/'sources.json',f/'link-plan.json',f/'dependencies.json']:add(p)
 for folder in [f/'compile',f/'link',f/'run']:
  for p in sorted(folder.iterdir()):
   if p.is_file()and p.suffix in ['.json','.log']:add(p)
 failed=B/f'cat08-binding-{backend}1'
 add(failed/'source/probe.cc')
 for p in sorted((failed/'compile').iterdir()):
  if p.is_file()and p.suffix in ['.json','.log']:add(p)
for p in sorted((B/'cat08-binding-cpu2/source').rglob('*')):
 if p.is_file()and p.suffix in ['.cc','.h']:add(p)
for index in range(8):
 f=B/'cat08-tiles'/f'{index:02d}'
 for name in ['payload.bin','complete.json']:add(f/name)
for name in ['engine/models/qwen35/prepare.py','engine/models/qwen35/geometry.py','tests/tooling/qwen_hf_roles_test.py','tests/tools/qwen_prepared_roles_test.cc','docs/user/inference.md']:add(R/name)
proof['files']=[ident(p)for p in files]
archive=D.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 z.writestr('result.json',json.dumps(proof,indent=2,allow_nan=False)+'\n')
 for p in files:
  assert p.stat().st_size<4000000
  assert p.suffix.lower()not in ['.exe','.dll','.obj','.lib','.safetensors','.gguf']
  z.write(p,p.relative_to(R).as_posix())
proof['archive']=ident(archive)
with D.open('x')as f:json.dump(proof,f,indent=2,allow_nan=False);f.write('\n')
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
print(json.dumps(dict(evidence=str(D),archive=proof['archive'],files=len(files),source_tile_bytes=39380,synthetic_fixture_bytes=13682,whole_models=0,CPU='PASS',CUDA='PASS')))
