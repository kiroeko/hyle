from pathlib import Path
import json,hashlib
from engine.models.qwen35 import prepare,geometry
R=Path.cwd();B=Path(__file__).resolve().parent
config=R/'.scratch/model-quantization-discovery-2026-10-19/qwen-kimi/unsloth--Qwen3.8-27B-NVFP4/config.json'
headers=[R/'.scratch/architecture-refactor-2026-10-18/ct-local-nvfp4-contract-review/artifact/8/model.safetensors/header.json',R/'.scratch/mtp-metadata-offline-20261024/cat08/header.json']
roles={}
for index,p in enumerate(headers):
 h=json.loads(p.read_text());base=8+p.stat().st_size
 for n,r in h.items():
  if not n.startswith(('model.language_model.','lm_head.','mtp.')):continue
  if n in roles:raise ValueError('duplicate original role')
  first,last=r['data_offsets'];roles[n]=dict(name=n,dtype=r['dtype'],shape=r['shape'],bytes=last-first,offset=base+first,path=str(p.parent/('original-target-not-fetched.safetensors'if index==0 else'original-mtp-not-fetched.safetensors')))
g=geometry.from_hf(json.loads(config.read_text()))
m=prepare.ct_mixed_groups(roles,json.loads(config.read_text()),g,prepare.CT_MIXED_READER,'bf16')
prepare.validate_role_geometry(roles,g,m['omitted_cache_calibration'])
identity=hashlib.sha256(json.dumps(roles,sort_keys=True).encode()).hexdigest()
lines=['HYLE_QWEN_ROLE_FILES_V2',identity,geometry.line(g),prepare.CT_MIXED_POLICY_LINE,prepare.BF16_CACHE_POLICY_LINE]
for n,r in sorted(roles.items()):lines.append('\t'.join([n,r['dtype'],str(len(r['shape'])),*(str(x)for x in r['shape']),json.dumps(Path(r['path']).as_posix()),str(r['offset']),str(r['bytes'])]))
(B/'original-headers.tsv').write_text('\n'.join(lines)+'\n')
result=dict(scope='Only actual original headers and selected reader metadata; no original target or MTP body authentication claimed',metadata_only_identity=identity,target_and_sidecar_roles=len(roles),channel_groups=len(m['channel']),local_groups=len(m['local']),omitted_cache_calibration=len(m['omitted_cache_calibration']),selected_with_mtp=len(roles)-len(m['omitted_cache_calibration']),selected_text=sum(not n.startswith('mtp.')and n not in m['omitted_cache_calibration']for n in roles),HTTP=0,models_started=0)
(B/'original-headers-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
