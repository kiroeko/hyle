from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,re,zipfile
D=Path(__file__).resolve().parent;R=D.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
actual=read(D/'verification/proof-summary.json');host=read(D/'host/summary.json')
assert actual['state']=='passed' and host['state']=='passed'
sources=['engine/inference/request_progress.h','engine/models/qwen35/main.cc',
 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc','tests/tools/inference_request_progress_test.cc',
 'tests/tools/qwen_generation_schedule_test.cc','tests/CMakeLists.txt']
pins=[pin(R/p)for p in sources];save(D/'final-source-pins.json',pins)
assert pins[0]['sha256']=='a06699ce15e6db0a8847bd26f7a322d01e97389bbfeab3d87a8b748793e537e3'
assert pins[1]['sha256']=='9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9'
before=(D/'implementation/before/engine/models/qwen35/main.cc').read_bytes();after=(R/sources[1]).read_bytes();sep=b'enum class GenerationMode'
assert before.split(sep)[0]==after.split(sep)[0]
bridge=dict(original_model_math_commit_and_completion_prefix_byte_equal=True,bytes=len(after.split(sep)[0]),
 scope='The previous 8dfff cold quant/fusion audit remains applicable: this batch changes only the subsequent request host code and shared progress header.')
save(D/'source-bridge.json',bridge)
cleanup=[]
for folder in[D/'host',D/'verification']:
 for p in folder.rglob('*'):
  if p.is_file()and p.suffix.lower()in{'.exe','.obj','.pdb','.lib','.exp','.ilk','.dll'}:
   assert p.resolve().is_relative_to(D);cleanup.append(pin(p))
save(D/'cleanup-plan.json',dict(files=cleanup,count=len(cleanup),logical_bytes=sum(p['bytes']for p in cleanup),performed=False,
 scope='Only current batch host/consumer rebuildable files and two private native DLL hardlinks. Original caches/fixtures and all sources/logs remain.'))
allowed={'.cc','.h','.py','.json','.md','.log','.patch','.txt'};selected=[]
for name in['implementation','glm-implementation','host']:
 selected.extend(p for p in(D/name).rglob('*')if p.is_file()and p.suffix in allowed and p.name!='live.json')
selected.extend(D/name for name in['root-review.md','final-source-pins.json','source-bridge.json','cleanup-plan.json','archive.py'])
selected.extend(D/'verification'/name for name in['proof.zip','proof-summary.json','publication.json'])
audit=R/'.scratch/inference-extension-check-20261025'
reviews=[audit/name for name in['quant-and-fusion.md','quant-and-fusion.json','cross-model-review.md','cross-model-review.json']]
archive=R/'docs/evidence/correctness/inference-request-progress-2026-10-25.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(selected):z.write(p,p.relative_to(D).as_posix())
 for p in reviews:z.write(p,'extension-review/'+p.name)
 for p in sources:z.write(R/p,'final-source/'+p)
with zipfile.ZipFile(archive)as z:
 assert not any(Path(n).suffix.lower()in{'.exe','.obj','.pdb','.lib','.dll','.safetensors'}for n in z.namelist())
evidence=dict(state='passed',date='2026-10-25',scope='Global inference architecture: real model-independent turn input/output progress shared by ordinary/MTP Qwen and finite original GLM StateHead requests.',
 changes=['One host observation cursor; repeated commits are no-ops and gaps/quota/capacity fail before host mutation.',
  'Real output maximum is independent of reserved vector capacity. Quota/stop/prefill/output append/turn advancement are shared.',
  'Borrow the original prepared input buffer; validate pending/extent/suffix before filling one later-turn slot. Original token owners and model pending/RNG stay authoritative.',
  'Full cache-hit output uses the same host rules without manufacturing another Graph commit; imported history is not delivered again.',
  'Qwen ordinary/MTP/legacy/full-hit paths and the original GLM two-request/two-turn component consume the same real algorithm.',
  'Existing prefix/cache checks enter the normal project test aggregate only when compute_batch already exists; new progress checks are standard-only.'],
 sources=pins,source_checks=read(D/'implementation/source-checks.json'),source_bridge=bridge,
 root_independent_review=pin(D/'root-review.md'),extension_review=[pin(p)for p in reviews],
 host=dict(state=host['state'],actual_TUs=2,groups=['Scalar/batched delivery, quota/stop and pending-only continuation','Gap/duplicate/invalid begin/quota failure atomicity','History adoption without fake model commit','Mixed two-user FIFO turns and zero hot allocations','Existing generation/schedule/parser regression'],
   compile_and_run=[{k:v for k,v in row.items()if k in('source','compile','run','stdout')}for row in host['checks']]),
 actual_regression=actual,verification_archive=pin(D/'verification/proof.zip'),archive=pin(archive),
 limits=['Finite original GLM component only: its existing single-emission K1 branch, new-request fork and two original ordinary continuations; no arbitrary GLM prompt/server claim.',
  'Original model resource/publisher/repair/phase/epoch/RNG mechanisms remain family-specific. Host progress does not publish state or prove native retirement.',
  'CMake registration was source-reviewed; the two actual host TUs ran directly. No new parent CMake configure or full SDK build was run in this batch.',
  'Same-family codec and fusion checks reuse previous actual evidence plus current source mapping; no new full quant model runs.',
  'No throughput result or speedup is claimed. Performance work starts separately with the current CUDA application closure.'],
 HTTP=0,SDK_builds=0,performance_claim=False,
 cleanup=dict(performed=False,count=len(cleanup),logical_bytes=sum(p['bytes']for p in cleanup),plan=pin(D/'cleanup-plan.json')))
target=R/'docs/evidence/correctness/inference-request-progress-2026-10-25.json';save(target,evidence)
board=R/'docs/developer/mtp-progress.md';text=board.read_text(encoding='utf8')
stamp=datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')
board.write_bytes(re.sub(r'更新：[^（]+（北京时间）',f'更新：{stamp}（北京时间）',text,count=1).encode('utf8'))
print(json.dumps(dict(evidence=pin(target),archive=pin(archive),cleanup_count=len(cleanup),cleanup_logical_bytes=sum(p['bytes']for p in cleanup)),ensure_ascii=False))
