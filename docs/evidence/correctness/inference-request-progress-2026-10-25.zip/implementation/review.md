# Source-only implementation boundary

Edited only request_progress.h and qwen35/main.cc. No direct Qwen probe required an API change after engine/tests search; existing parser host test is being migrated by root. GLM is another agent's source ownership.

RequestProgress now owns the sole host observation cursor, actual output limit, one borrowed turn span, turn-input/advance rules and the common output/quota/stop algorithm. It borrows the original prepared mutable input; GenerationRequest retains all original warm-input ownership. No model state, pending/RNG authority, graph role, endpoint or repair moved into it.

Each ledger record first preflights shared output limits and original family round capacities. Family statistics and endpoints are staged before observe_commit applies output and advances its cursor last. All normal generated vectors were already cold-reserved; no new hot allocation is introduced. Full prefix hits adopt the real initial ledger count and apply exactly their newly chosen pending once, guarded by prefilled, without an invented ledger ordinal. Legacy no-ledger callers apply the same host output algorithm under their constructor's actual one-turn limit.

Natural Qwen Text and MTP both bind once, begin from original input storage and actual committed pending, use shared quota, and advance only after original checkpoint publication and FIFO release. Qwen CLI still rejects empty user input; the shared pending-only later-turn case supports the finite GLM adapter.

Checks here are source assertions only. Root/verification own strict compilation, existing natural/late-IO regressions, host properties and the real GLM case. No build, model run, HTTP or numerical claim is added by this implementation record.
