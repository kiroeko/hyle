# 独立源码审查：真实请求主机边界

主代理审查，独立于共享实现与 GLM 适配作者。依据当前源码及两个精确 diff；实际运行结果另列。

- `RequestProgress` 保留一个实际最大输出量，与 vector capacity 分开；bind 借不可变 turn 合同，begin 只借原冷准备输入。
- later turn 先检查实际 pending 等于已交付末 token、输入 extent 和用户 suffix，再原位写唯一首 slot。目录键与状态仍只能由实际模型消费推进。
- 观察序号是主机观察游标，不发布模型状态。重复 ordinal 无操作，gap／额度／容量在任何主机变更之前拒绝；模型 ledger 仍是提交权威。
- Qwen 在共享 preflight 后更新原已预留 round／计数和 endpoint，最后 observe；合法路径中中间没有分配、IO 或用户回调。旧 head／RNG／repair／发布代码未迁移。
- 完整缓存命中保留原历史 adoption；新 pending 通过无 Graph 的共同输出规则观察一次，不伪造另一提交序号。实际 late-IO 检查仍负责证明逻辑不重复。
- 普通、MTP、legacy 单 turn 和有 schedule 的自然请求共用额度／停止／append；权威 pending 来自模型 head，主机输出只核对一致性。
- GLM 新代码只把既有自然 K1 的真实单输出、新请求采样 fork 和两次原 ordinary continuation 接入同一主机算法。首次额度 1 与实际 selected prefix 一致，原 selector 上限／计算均未改；不声称任意 prompt 或一般 quota clipping 已由此案例覆盖。
- GLM 第二 turn 只有历史 pending、没有新增用户 suffix；使用真实恢复 Head 的 pending，并核对原 state consumer 读取同一值。取消／stale 不推进主机观察，原完整状态、资源和随机地址仍由 StateHead 负责。
- 初始采样身份没有作为另一可变 RNG；不增加张量／状态所有者或 token 副本。原 warm_inputs 所有者保留在请求，模型账簿保原输入 owner。
- copy 禁用、move 保留冷预留 vector；合法热转换不依赖重新分配。
- project-owned 的现 prefix/cache 检查仅在实际 compute_batch 已选择时注册；新 progress 检查只用标准库，不把引擎依赖塞进 Compute，也不让 util-only 引入它。

有限架构结论：跨模型共用的是实际窗口、目录、输入／输出进度、接受规则和原执行资源机制。
原模型桥接仍负责角色／阶段、容量证明、完整 checkpoint、状态修复和真实 ledger 投影；不把多阶段调用拼成一个仅转发回调的通用控制器。
在线 server、任意 GLM prefill、多在途 Invocation 和全平台性能仍不在本次有限实现证据内。

本审查未发现具体源码缺陷；最终通过须以已分配的 host、Qwen 8 流程和 GLM 单例终态为准。
