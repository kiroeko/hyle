# 同族量化与后端融合有限扩展检查

- 性质：当前源码调用审查＋既有实际证据；本次 0 构建、0 执行、0 HTTP。main SHA `8dfff21459d59388f231da9ddc2968b53c80c971bc3751780bf045cd4a437d13`。
- 两个真实配置属于同一 Qwen 家族，但尺寸、权重、精度不同；不作同输入质量或速度比较。结论仅限下面的修改范围，不宣布整体架构完成。

## 共用的真实调用链

1. `prepared_roles.h::select_roles`（206）按 source-derived geometry 的 `parameter_inventory` 认证物理角色；`read_manifest`（359–424）固定来源、数学政策、原 dtype/shape/bytes。普通选择 Text，MTP 另选原 NextN 角色。
2. `main.cc::load_weight_bank`（1319）按实际资源加载并冻结原存储；`LoadedWeight`（134）独占源 codec/group 注解，通用 Tensor 不持格式注解。
3. Model 构造（1883–1887）先加载稳定 map 节点，再 `prepare_projection_bindings`（343）；所有 inventory linear 与实际 tied/untied head 经同一 `resolve_projection`（225）。绑定只借原 Tensor，不复制权重或引入第二元数据表。
4. `Recipe::emit_projection`（750）、`linear_absolute`（843）、`scores`（846）使用同一 typed variant；head 精度报告由 `score_policy`（364）派生。variant 只在冷构图访问。
5. `prepare_family`（2179）、`prepare_draft_program`（2675）、prefix/frontier sampling（2915/3064）沿原 GraphAssembly/Recipe；`run_generation_sessions`（5254）选真实 Text 或 MTP 阶段，不按 codec 选请求、目录或提交代码。

## A：实际 GPTQ-v1 INT4

- `Vishva007/Qwen3.5-2B-W4A16-AutoRound-GPTQ@8ec79a3b08636bc68fd40d69df80e97ff1263995`，原物理角色 785。
- `prepared_roles.h:284–299`：I32 qweight[K/8,N]、I32 qzeros[G,N/8]、F16 scales[G,N]、I32 g_idx[K]，由完整 geometry 求 group 并认证。
- `load_weight_bank:1423` 原样持有各角色；`resolve_projection:243–255` 绑定四原 operand 和 `ArtifactWeightDecode(kGptqV1Int4,group,F16)`。
- `emit_projection:779–792` 保留 decode F16 → Cast BF16 → transpose → MatMul(F32 accumulation,BF16 result)；scores 仅将同结果扩至 F32。原零点加一、F16 decode 舍入不是 F32 decode 的别名。
- 已有实际证据 `qwen-mtp-original-gptq-2026-10-24.json`：原完整 CPU/CUDA ordinary/K1；`qwen35-original-quantized-mtp-k4-random-2026-10-24.json`：Q01 完整 CUDA K4 random。均为其原冻结源，不冒称本次 current main 又跑过完整模型。

## B：实际官方 block128 FP8

- `Qwen/Qwen3.8-27B-FP8@017b9c7af6b5689d5dd426a76e0bc077eb5ca20a`，原 physical text1251＋MTP22；不是前一配置的同几何版本。
- `prepared_roles.h:319–326`：原 E4M3[N,K]＋BF16 weight_scale_inv[ceil(N/128),K/128]，固定 reader divide/floor `2edbe6ff`，不是 channel/token 或 PowerOfTwo 政策。
- `fp8_weight_import.h::import_float8_block128_roles` 只将原 scale 网格精确扩为 F32 并与 codes 导入 encoded carrier；`load_weight_bank:1458–1483` 每组导入/冻结，不创建全 bank BF16/F32 影子。
- `resolve_projection:299–306` 绑定 carrier＋原 `Float8BlockLinear(kDivide,floor)`；`emit_projection:812–817` 调原 typed op，BF16 result → head F32。物理 source 角色计数与 canonical invocation operand 计数明确不同。
- 已有 `mtp-qwen27-fp8-complete-cpu-2026-10-24.json`：原完整纯 CPU ordinary/K1 random、P1/C32；含首次 stale mapping-view object 失败和一次局部修正，不能隐去首次失败。
- `inference-cold-projection-bindings-2026-10-24.json` 补证同一冷 resolver/emitter 的 bounded CPU 组件；GPTQ 该组件是合成舍入见证，不能代签原完整 trained bank。

## 一个实际融合接入：GPTQ 四节点 packed region

- `src/graph/artifact_packed_region.h::ArtifactPackedPattern::pattern`（49）识别上述 decode/cast/permute/MatMul 原节点与真实类型；闭包、effects 和逃逸输出限制保留。
- `src/graph/mapped_pattern_region.h::propose_one`（55）将真实边界/资源交原 Provider 冷资格与 prepare；CPU `graph_route_cpu/ct_packed_linear_region.cc` 和 CUDA 同名文件仅装饰已有原 Provider，并由各自 context 装配。
- `compute_packed_shared/artifact_packed_linear.h` 携带原 format/group/decode_type/operand_type；native `ct_packed.cc` 与 CUDA `artifact_provider.cc` 执行原舍入/F32 累加。Provider 不读取请求、pending 或 ledger。
- `main.cc::report_packed_projections`（912，调用2590）只是 cold selected-plan 观察，允许 decomposition；没有强制融合或热 Provider 重选。
- `gptq-reference-2026-10-20.json` 是真实 Graph/backend 有限执行证据（含 CUDA/CPU 原 packed、g_idx 错误和 published-decode decomposition）；其数学数据是 fixture，非 trained 模型，也不是本次重跑或融合提速证明。

## 支持的修改范围与边界

- 同族新 codec：主要改 source preparer/role 验证、必要的原存储 import、cold binding 与 genuinely different typed equation emitter；已有 typed op 可表达时复用它。head/report 继续同源派生。
- 同一数学的后端融合：改 Graph capability/matcher、Provider prepare/kernel 与实际资源/精度资格；不要求改 RequestProgress/RequestWindow、PrefixDirectory、accepted-prefix、状态 repair/commit/RNG。编入 route 不等于某个图必然选择它。
- 改原 reader/精度身份必须重新加载/冷准备并隔离缓存数学域；不得静默改变原图的 Cast/QDQ、扩大权重或在每 token 加格式/Provider 分派。
- 本审查未找到上述两条链或该融合的阻断缺陷；这不覆盖“新模型无需复制主机 turn/pending/quota/commit-observation”的剩余检查。当前通用窗口/目录不等于完整请求进度合同已跨家族共享，该项由后续实际切片收口。
