# Cross-model finite extension review

Read-only review, main `8dfff21459d59388f231da9ddc2968b53c80c971bc3751780bf045cd4a437d13`. No product edits, builds, model runs, downloads or matrix added. Exact source pins are in the companion JSON.

## Concrete remaining gap

**Do not call global request architecture complete yet.** Shared RequestWindow and PrefixDirectory are real reusable algorithms, with actual Qwen and original GLM StateHead consumers. However, the current RequestProgress is only passive output storage plus `begin_turn()` flag reset.

Qwen `main.cc:4594` alone implements committed-record observation/idempotence; `:4926` combines generic turn completion with family bookkeeping; `:5433` alone prepends the previous pending to the next input; `:5492` advances completed turns. The GLM demonstration reuses the FIFO/directory but manually organizes these host semantics. A new family would still copy quota/stop, observation and turn-input rules. This is architecture debt, not a newly demonstrated numerical/runtime defect.

Minimum viable correction: extend the existing RequestProgress rather than add ModelOps or another controller.

- Move the one host observed-commit cursor there. `observe_commit(ordinal, emitted, user_output, prefill_complete, stopped)` rejects gaps/overflow/output-capacity and turn-quota violations before mutation, ignores already observed ordinals, then appends actual user output and updates prefilled/turn_done exactly once. It never commits model state or RNG.
- Retain an actual maximum-output limit; vector capacity is storage, not user quota. Derive current turn endpoint/remaining quota from the existing turn span and actual output begin.
- Begin a turn using a borrowed, already cold-prepared mutable input span. Validate exact user-input-plus-optional-pending extent first; later turns place only the actual historical head pending in slot0, without adding it to consumed journal/key. Reject repeated begin rather than resetting active progress.
- Share legal completion/next-turn advancement. Publish the original complete checkpoint before releasing the FIFO slot; advance only after successful release, and begin the next turn only after successful model admission/restoration.

Family ledgers remain authoritative. Their adapters project actual committed facts into this helper; cold-reserved/no-throw family metrics run only for newly observed facts. Imported partial-prefix history advances observation without user output; a full hit's actual newly chosen pending uses the same observation path rather than a second manual push.

Reuse must be real in current Qwen ordinary/MTP and the existing GLM original StateHead case. GLM's second finite turn can have an explicitly empty new-user suffix and consume only its actual pending; do not manufacture additional GLM prompt execution to fit the host shape. No whole-loop seven-callback abstraction or full-model matrix is needed.

## What is already reusable

- RequestWindow owns no model state; PrefixDirectory owns the real typed checkpoint and shares one radix/LRU/pin implementation. The GLM consumer directly holds StateVersion rather than manufacturing a Snapshot canonical pointer.
- Qwen, GLM and DeepSeek use the common actual prefix selectors. DS's trained-six width/confidence/all-ID/exhaustion checks and pending-row lease selection remain genuine model adapters.
- Prepared output/readback, Backend's cold resource/queue facts, original Completion retention and entry observation boundaries are independent of family request policy. Core Graph/Compute paths do not include engine/model policy.
- New engine family sources can directly include engine/inference headers. The actual engine CMake target helper supplies C++23 and SDK link dependencies, including for installed-SDK standalone builds. Shared std-only request/directory headers do not require the Qwen executable.
- The previously unregistered17-check prefix host test was a real build-discoverability omission. Root now registers the existing standalone as a project test conditional on actual `hyle_compute_batch`, with its real transitive compute/mem dependencies and no util-only expansion; this does not inject engine tests into Compute.

## Necessary differences and finite end condition

Qwen recursive/batched verification, GLM target-tap/index repair and DeepSeek trained block/Markov/history work have different stage sequences and RNG address rules. Their complete state identities, layouts and version/byte/retirement proofs differ. These must remain model bridges; forcing a common executor, universal state container or phase callback registry would obscure real contracts.

Codec-dependent projections likewise keep genuine scale/layout/rounding differences in cold artifact binding and required math. A new codec should not require editing FIFO/LRU/turn-observation algorithms, but it may require new model operators. New backend fusion belongs to actual Provider qualification/cold lowering, not request control.

Finite completion requires the remaining common RequestProgress algorithm to be implemented and actually consumed by Qwen ordinary/MTP plus the bounded real GLM adapter. After that, explicit family bridges and the existing single-carrier/server/backpressure/hardware exclusions are not hidden failures. This review does not claim a generic online server, arbitrary GLM prompt support, all-family engine applications or all hardware/quant combinations.
