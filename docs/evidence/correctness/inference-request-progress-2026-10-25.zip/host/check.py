"""Two actual std-only host TUs with the installed MSVC, no SDK or model."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
compiler=b.args(R/'.scratch/inference-prefix-directory-20261024/host/compile/command.json')[0]
env=b.environment(compiler)
sources=[R/'tests/tools/inference_request_progress_test.cc',R/'tests/tools/qwen_generation_schedule_test.cc']
header=R/'engine/inference/request_progress.h';before=[b.pin(header),*[b.pin(p)for p in sources]]
records=[]
for source in sources:
    target=D/source.stem
    command=[compiler,'/nologo','/std:c++latest','/EHsc','/MD','/O2','/W4','/WX','/wd4324','/permissive-',
        '/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/DHYLE_STATIC','/DNOMINMAX',
        '/I'+str(R/'include'),'/sourceDependencies',str(target/'compile/dependencies.json'),str(source),
        '/Fo'+str(target/'compile/host.obj'),'/Fe'+str(target/'compile/checks.exe')]
    b.execute(command,target/'compile',env,60)
    argv=[str(target/'compile/checks.exe')]
    if 'schedule' in source.name:argv.append(str(target/'fixture'))
    b.execute(argv,target/'run',env,30)
    records.append(dict(source=b.pin(source),compile=b.read(target/'compile/process.json'),
        run=b.read(target/'run/process.json'),stdout=(target/'run/stdout.log').read_text()))
after=[b.pin(header),*[b.pin(p)for p in sources]]
if before!=after:raise ValueError('Sources changed during host checks')
b.save(D/'summary.json',dict(state='passed',checks=records,before=before,after=after,
    scope='Actual standard-only request lifecycle regression and existing schedule parser consumer; no native SDK, model, HTTP or native build.',SDK_builds=0,HTTP=0))
