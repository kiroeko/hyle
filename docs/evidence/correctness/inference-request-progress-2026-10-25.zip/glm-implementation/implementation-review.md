# GLM original consumer shared RequestProgress adapter

Scope: only the existing opt-in original Pro target77/NextN78 random K1 two-request/two-turn directory case. No new model, backend, math, logits, proposal, selector limits, epoch, RNG address, state publication, Graph call, output pool or StateStore budget was changed.

- Both requests cold-prepare the same two-turn host schedule: the initial actual fixed suffix token and quota1; then an empty new-user suffix and quota1. Total output storage is exactly2 each. The original known natural K1 branch must actually emit1; this assertion never clips or alters the original unlimited verifier result.
- Initial begin_turn receives the actual prepared initial token. Later begin_turn writes its only pending slot from the actual restored StateHead, verifies that token equals the request's last actual emission, and the existing ordinary step consumes that original pending lease. No extra user token or full GLM prompt capability is invented.
- Request0 preflights its actual K1 result before original Head publication, then observes commit0 only after the complete lag0 boundary is ready. Request0's unchanged ordinary continuation preflights/observes commit1.
- Request1's cache-hit sampling fork preflights/applies its real new pending with no fake Graph ordinal. Its unchanged ordinary continuation preflights/observes commit0. Model StateHead publication remains authoritative throughout.
- Each real committed observation is immediately repeated with the same ordinal; the shared helper must returnfalse with unchanged output count, pending and observation cursor. Both requests finish each turn through the common quota rules; more_turns drives original FIFO release, and advance_turn occurs only after successful release.
- EOS/stopped comes from the real original selector or actual configured EOS lookup. This fixture has no configured EOS, so no fabricated stop is used to force a boundary. Shared host-only EOS cases belong to the separately assigned common-helper checks.
- Existing hit cancellation/stale publication now also assert the request has no emitted output/observed commit. Existing Head/RNG/state immutability, FIFO0,1,0,1, source counters, pool/budget and first-request stdout checks remain intact.
- The original generated storage address/capacity stays stable. No additional state owner, generic ModelOps, runtime callback table or controller is added.

Expected validation: all prior numeric/state/role/source/RNG/pool/call and directory properties remain identical. New properties are request_progress_output_counts=2,2; committed_observations=2,1; duplicate_commit_noops=3; full_hit_outputs=1; pending_only_turn_inputs=2 plus the explicit finite scope. No quality/TPS/full-model claim.

Implementation agent ran only git diff --check (PASS), not compilation, execution, HTTP or downloads. Separate verification owns one existing canonical TU and one original-role case after root approval/shared-header final pin.
