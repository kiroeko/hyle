"""Authorized exact32x2B original KV calibration acquisition via existing Fetch."""
from pathlib import Path
import hashlib,importlib.util,inspect,json,math,os,struct,sys,urllib.parse,urllib.request
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];SCRIPT=Path(__file__).resolve().relative_to(ROOT).as_posix()
BUDGET=ROOT/'.scratch/mtp-download-budget-20261023/budget.py';TRANSPORT=ROOT/'.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py';OUT=HERE/'attempt1'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
 plan=json.loads((HERE/'network-plan.json').read_bytes());assert plan['revision']=='f0b7c9e722f5565102fff8481c99e4d86ae099c7'
 assert plan['repository']=='unsloth/Qwen3.8-27B-NVFP4'and plan['budgets']['hard_application_body_bytes']==64
 assert len(plan['roles'])==len(plan['requests'])==32 and sum(r['bytes']for r in plan['requests'])==64
 for pin in plan['source_pins']:
  p=ROOT/pin['path']
  if p in [BUDGET,TRANSPORT]or pin['path']in[plan['source']['header']['path'],plan['source']['revision_API']['path']]:
   assert len(p.read_bytes())==pin['bytes']and sha(p.read_bytes())==pin['sha256'],pin['path']
 spec=importlib.util.spec_from_file_location('ct_e4_existing_transport',TRANSPORT);transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport);transport.SCRIPT=SCRIPT
 budget=transport.module();guard=urllib.request.urlopen
 assert Path(guard.__code__.co_filename).resolve()==BUDGET.resolve()and inspect.getclosurevars(guard).nonlocals.get('script')==SCRIPT
 budget.require_enabled();budget.require_mirror_url(plan['uri']);OUT.mkdir(exist_ok=False)
 with budget.locked()as ledger:floor=len(ledger['requests'])
 admitted=0;roles=[];failure=None;file=OUT/'scalars.partial.bf16'
 expected={r['name']:r for r in plan['roles']};assert sorted(r['destination_offset']for r in expected.values())==list(range(0,64,2))
 row=dict(repository=plan['repository'],revision=plan['revision'],file=plan['file'],uri=plan['uri']);source=dict(size=plan['source']['size'],etag=plan['source']['strong_etag'])
 fetch=transport.Fetch(budget,row,timeout=45,receipt_dir=OUT)
 try:
  with file.open('xb+')as output:
   output.truncate(64)
   for request in plan['requests']:
    assert request['bytes']==2 and admitted<=62;first,last=request['range'];assert last-first+1==2
    role=expected[request['role']];assert role['absolute_inclusive']==[first,last]
    admitted+=2;budget.require_enabled();raw,response=fetch.get(first,last,source=source);assert len(raw)==2
    output.seek(role['destination_offset']);output.write(raw);output.flush();os.fsync(output.fileno())
    bits16=int.from_bytes(raw,'little');bits32=bits16<<16;value=struct.unpack('<f',struct.pack('<I',bits32))[0]
    if not math.isfinite(value)or not value>0:raise ValueError('Original K/V scale is not positive finite; no substitution')
    roles.append(dict(role,source_sha256=sha(raw),original_bf16_bits=f'{bits16:04x}',value_f32_bits=f'{bits32:08x}',dequant_scale=value,budget_request_id=response['budget_request_id']))
  assert admitted==64 and len(roles)==32;file.rename(OUT/'scalars.bf16')
  ordered=sorted(roles,key=lambda r:r['destination_offset']);pairs=[dict(layer=ordered[i]['layer'],attention_slot=ordered[i]['attention_slot'],key_f32_bits=ordered[i]['value_f32_bits'],value_f32_bits=ordered[i+1]['value_f32_bits'],key_scale=ordered[i]['dequant_scale'],value_scale=ordered[i+1]['dequant_scale'])for i in range(0,32,2)]
  transport.save(OUT/'complete.json',dict(status='ORIGINAL_32_KV_BF16_SCALES_ACQUIRED_AND_POSITIVE_FINITE',repository=plan['repository'],revision=plan['revision'],file=plan['file'],source=plan['source'],bytes=64,payload=dict(path=(OUT/'scalars.bf16').relative_to(ROOT).as_posix(),bytes=64,sha256=sha((OUT/'scalars.bf16').read_bytes())),roles=ordered,pairs=pairs,unique_KV_pairs=len({(p['key_f32_bits'],p['value_f32_bits'])for p in pairs}),whole_file_LFS_body_verified=False))
 except BaseException as error:
  failure=type(error).__name__;raise
 finally:
  with budget.locked()as ledger:requests=[r for r in ledger['requests'][floor:]if r['script']==SCRIPT]
  total=sum(r.get('received_bytes')or 0 for r in requests);assert total<=64
  summary=dict(status='PASS'if failure is None else'FAILED',error_type=failure,requests=len(requests),request_ids=[r['id']for r in requests],application_body_received_bytes=total,admitted_range_bytes=admitted,hard_application_body_bytes=64,received_bytes_by_final_host={host:sum((r.get('received_bytes')or 0)for r in requests if r.get('final_host')==host)for host in sorted({r.get('final_host')or'not-opened'for r in requests})},all_opened_final_hosts_mirror=all(r.get('final_host')in(None,'hf-mirror.net')for r in requests),automatic_retries=0,metadata_requests=0,roles_complete=len(roles))
  transport.save(OUT/'transfer-summary.json',summary);print(json.dumps(summary),flush=True)
if __name__=='__main__':main()
