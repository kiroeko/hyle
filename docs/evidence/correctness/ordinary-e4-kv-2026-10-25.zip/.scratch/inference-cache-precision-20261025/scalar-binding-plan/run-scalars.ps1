$ErrorActionPreference = 'Stop'
$ctRoot = 'C:\public\project-hyle\hyle'
$ctExpected = Join-Path $ctRoot '.scratch/inference-cache-precision-20261025/scalar-binding-plan'
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ne $ctExpected) { throw 'Unexpected fixed scalar task directory' }
$ctPause = Join-Path $ctRoot '.scratch/mtp-download-budget-20261023/PAUSED'
$ctHeld = Join-Path $PSScriptRoot 'PAUSED.before'
if (!(Test-Path -LiteralPath $ctPause -PathType Leaf) -or (Test-Path -LiteralPath $ctHeld)) { throw 'Expected unchanged PAUSED marker' }
$ctHash = (Get-FileHash -LiteralPath $ctPause -Algorithm SHA256).Hash.ToLowerInvariant()
$ctStarted = [DateTime]::UtcNow.ToString('o')
Move-Item -LiteralPath $ctPause -Destination $ctHeld
$ctExit = $null
try {
    & python (Join-Path $ctRoot '.scratch/mtp-download-budget-20261023/budget.py') run (Join-Path $PSScriptRoot 'fetch-scalars.py')
    $ctExit = $LASTEXITCODE
} finally {
    if ((Test-Path -LiteralPath $ctPause) -or !(Test-Path -LiteralPath $ctHeld -PathType Leaf)) { throw 'PAUSED marker changed during exclusive scalar batch' }
    Move-Item -LiteralPath $ctHeld -Destination $ctPause
    $ctAfter = (Get-FileHash -LiteralPath $ctPause -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($ctAfter -ne $ctHash) { throw 'Restored PAUSED bytes differ' }
    [ordered]@{ started_utc=$ctStarted; finished_utc=[DateTime]::UtcNow.ToString('o'); process_exit=$ctExit; paused_restored=$true; original_pause_sha256=$ctHash; restored_pause_sha256=$ctAfter; automatic_retries=0 } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'pause-restoration.json') -Encoding utf8
}
if ($ctExit -ne 0) { throw "Original scalar batch failed; exit $ctExit; no retry" }
