# CT E4 KV 原标量冷绑定（私有设计；未改／编／跑产品）

## 来源与获取

`network-plan.json` 已逐项重算32角色：unsloth/Qwen3.8-27B-NVFP4@f0b7c9e722f5565102fff8481c99e4d86ae099c7，model.safetensors 22568192096B；header251128B/data_base251136/SHA4b84e021…，原strongETag a0d562e2…。原config/API固定rev吻合；64层里3,7,…63为16个full_attention，每层真实BF16[1] K/V各1份。
未来授权批只32个2B请求，共64B，不合并其间50125120B，不再请求metadata。沿现budget.py + Fetch.get，initial及redirect仅HTTPS hf-mirror.net，原If-Match/206/Content-Range/Content-Length/ETag/identity门，0retry；失败也保receipt/实际bytes。PAUSED仅该窗口临时持有，finally核原字节恢复。原file LFS仅声明身份，不签未获取整文件body hash。

## 最小模型私有事实

- 不把校准元数据放进通用Tensor、LoadedWeight、ProjectionBinding或新registry。
- 将现Bf16CachePolicy自然归为有限`CachePolicy{activation_default,bf16_omit_original,e4m3_original}`；旧V2 BF16 policy line逐字保留，新增唯一明确E4M3FN+原K/V校准line。新增prepare选项值可用e4m3fn，不另加运行期provider开关。
- 现`Roles.omitted_cache_calibration`改为一份`cache_calibration`原Role向量，并由cache_policy解释；严格按geometry.attention_slot的K/V顺序存放。BF16保原省略计数／不读值，E4全部成对／dtype BF16／shape[1]／覆盖16个A层，GDN不得有此角色，缺失/多余/重复都冷拒绝。不要同时再建一份相同Role表。
- `selected`仍只给原权重loader，64B校准不进入GPU权重bank、不多造Tensor/ReadLease。`Roles.bytes`的原权重计账不混入缓存标量；原scope与selected-weight report含义不变。

## Preparer（prepare.py::ct_mixed_groups/_prepare_role_records）

- 保现BF16显式omission；E4选择必须核原kv_cache_scheme为static float8/tensor/symmetric、dynamic=false且K/V32完整，不凭NVFP4名字或权重dtype推断KV。
- 现authenticate已经读/哈希原role：复用该64B，检查BF16 little-endian位模式精确扩成F32、positive finite；不钳值、不取倒数、不替1，也不借MLX/NF4/其它profile的校准。
- V2 role记录仍原source/path/offset/bytes；fingerprint既有identity.roles含每role原SHA，再加入所选cache_policy，BF16与E4源身份不同。receipt单列实际校准role/bytes及原bits，不能把旧BF16 omission写成E4执行通过。

## Model冷接纳

- `prepare_weight_source`/现PreparedWeightSource最合适：在权重IO/任何Session之前，仅按这份Role表读原64B（单scalars.bf16缓存可一次读；一般分散role沿原本地文件冷读，不HTTP）。预检完整source extents，精确BF16→F32，再`CacheStorage::float8(scale)`构造每attention_slot的唯一typed K/V pair。
- 这份临时pair向量move到原ColdResources不可变持有；原Role表随PreparedWeightSource结束，不另外pin文件／模型bank。现输入和权重同样遵守准备后source immutable合同；最终proof另外核实际64B文件与每role SHA。
- 无需新原生API。仅E4+ordinary合同；在cold角色接纳时拒绝draft_cache/MTP选择，原默认普通／MTP/BF16数学不变。
- shared-layout派生方案由另一片处理：这里提供真实pair和已有geometry.attention_slot；相等pair可冷归组，不能以未知值先假定G=1或16，不能按model名字路由。每层真实schema必须保pair，layout只能承载共同拓扑。

## 实际图接线与预算（main已有位置）

- prepare_cache:2581原plain storage改从选定pair取；各PagedArena保真实schema，保持local+additional预算和完整tuple成功后才发布。bank字节从实际cache TensorDesc.required_bytes()+原arena终字节推导，保--cache-bytes；GDN/conv/F32 recurrent/hidden精度不变。
- prepare_family:2935–2956：原Q/K norm、RoPE与activation store点不动；K在RoPE后、V在原投影后仅加既有`CacheEncode{storage}`，再给原typed PagedAppend。按真实schema声明key/value inputs与PagedAttention.capacity；attention.scale仍1/sqrt(D)。CacheStorage已固定编码/舍入/反量化，不再复制第二套precision字段。
- actual PagedAppend/PagedAttention保存同pair，读code*scale恰好一次；旧Snapshot/各层Arena owner/页COW/ready/retirement原路，不能从共享layout.origin猜实际scale。
- Model source_identity/原cache domain与这份冷资源共同隔离；新选择须新ColdResources，不准有Session后改scale。不改RequestProgress/Window/ledger/commit算法。

## 有限后续检查（本轮尚未执行）

先获取64B，报告每role rawSHA/BF16bits/F32bits/finite及实际unique K/V pair数。metadata-only host检查保旧BF16输出不变、新E4缺半对/非法scale/错层冷拒绝与不同source_id。实际组件沿既有CacheEncode+E4参考合同；随后仅原ordinary tiny旅程核两种不等pair、编码bytes、旧reader/fork/完整前缀与预算。完整27B运行、强迫packed路由、MTP新功能、整制品／vLLM逐位一致均不由这个64B批次证明。
