from pathlib import Path
import ast
import difflib
import hashlib
import json

R = Path.cwd()
W = R / '.scratch/inference-cache-precision-20261025/role-policy'
S = W / 'source'
OWNED = [
    'engine/models/qwen35/prepare.py',
    'engine/models/qwen35/prepared_roles.h',
    'engine/models/qwen35/precision_profile.h',
    'tests/tooling/qwen_hf_roles_test.py',
    'tests/tools/qwen_prepared_roles_test.cc',
    'tests/tools/qwen_precision_profile_test.cc',
]
SUPPORT = [
    'engine/models/qwen35/model_geometry.h',
    'engine/models/qwen35/nf4_state.h',
    'engine/models/qwen35/prepared_gguf_roles.h',
    'engine/models/qwen35/ffn_placement.h',
    'engine/models/qwen35/geometry.py',
    'engine/models/qwen35/nf4_state.py',
    'engine/inference/artifact_digest.h',
    'tests/tools/qwen_geometry_fixture.h',
    'tests/tooling/fixtures/qwen_nf4_quant_state.json',
]

def item(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

for rel in OWNED:
    if (R / rel).read_bytes() != (W / 'before' / rel).read_bytes():
        raise RuntimeError('Canonical before changed: ' + rel)
for rel in SUPPORT:
    path = S / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != (R / rel).read_bytes():
        raise RuntimeError('Support closure changed: ' + rel)
    path.write_bytes((R / rel).read_bytes())
for rel in OWNED:
    if rel.endswith('.py'):
        ast.parse((S / rel).read_text(encoding='utf-8'), filename=rel)
patch = ''
for rel in OWNED:
    a = (W / 'before' / rel).read_text(encoding='utf-8').splitlines(keepends=True)
    b = (S / rel).read_text(encoding='utf-8').splitlines(keepends=True)
    patch += ''.join(difflib.unified_diff(a, b, fromfile='a/'+rel, tofile='b/'+rel))
(W / 'source.patch').write_text(patch, encoding='utf-8', newline='\n')
pins = dict(status='FROZEN_PRIVATE_SOURCE', files=[dict(path=rel, **item(S / rel)) for rel in OWNED])
(W / 'after-pins.json').write_text(json.dumps(pins, indent=2)+'\n', encoding='utf-8')
(W / 'support-pins.json').write_text(json.dumps([dict(path=rel, **item(S / rel)) for rel in SUPPORT], indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(paths=len(OWNED), support=len(SUPPORT), patch=item(W/'source.patch'), after_pins=item(W/'after-pins.json')), indent=2))
