from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

R = Path.cwd()
W = R / '.scratch/inference-cache-precision-20261025/role-policy'
S = W / 'source'
F = W / 'host1'
F.mkdir(exist_ok=False)
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('retained_cpu_build', R/'.scratch/engine-product-20261024/cpu-build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
recipe_path = R / '.scratch/inference-system-review-20261025/nf4-metadata/host2/compile/command.json'
recipe = b.read(recipe_path)['command']
env = b.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': recipe[0], 'CMAKE_CXX_COMPILER': recipe[0], 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
env = dict(env, PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
expected = b.read(W/'after-pins.json')['files'] + b.read(W/'support-pins.json')
def unchanged():
    for p in expected:
        raw = (S/p['path']).read_bytes()
        if len(raw) != p['bytes'] or hashlib.sha256(raw).hexdigest() != p['sha256']:
            raise RuntimeError('Frozen source changed: '+p['path'])
unchanged()
summary = dict(status='IN_PROGRESS', scope='Python and two std-only metadata tests; no Model/Graph/native/GPU/HTTP', recipe=str(recipe_path), checks=[])
try:
    b.execute([sys.executable, str(S/'tests/tooling/qwen_hf_roles_test.py'), '-v'], env, F/'python', 30)
    summary['checks'].append('original Python metadata suite')
    for name in ('qwen_prepared_roles_test', 'qwen_precision_profile_test'):
        T = F/name
        T.mkdir()
        flags = recipe[1:recipe.index('/link')]
        flags = [a for a in flags if not a.startswith(('/Fe:', '/Fo:', '/Fd:')) and not a.endswith('.cc')]
        command = [recipe[0], *flags, '/I'+str(R/'include'),
            '/sourceDependencies', str(T/'sourceDependencies.json'),
            str(S/('tests/tools/'+name+'.cc')),
            '/Fe:'+str(T/'checks.exe'), '/Fo:'+str(T/'checks.obj'), '/Fd:'+str(T/'checks.pdb'),
            '/link', '/INCREMENTAL:NO']
        b.execute(command, env, T/'compile', 120)
        args = [str(T/'checks.exe')]
        if name == 'qwen_prepared_roles_test':
            args.append(str(T/'fixtures'))
        b.execute(args, env, T/'run', 30)
        summary['checks'].append(name)
    unchanged()
    summary['status'] = 'PASS'
except Exception as error:
    summary['status'] = 'FAILED'
    summary['error'] = str(error)
    raise
finally:
    b.save(F/'summary.json', summary)
print(json.dumps(summary, indent=2))
