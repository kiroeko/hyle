from pathlib import Path
import hashlib
import json

R = Path.cwd()
W = R / '.scratch/inference-cache-precision-20261025/role-policy'
S = W / 'source'
F = W / 'host1'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
owned = read(W/'after-pins.json')['files']
for row in owned:
    assert pin(S/row['path']) == {key:row[key] for key in ('bytes','sha256')}
before = read(W/'before-pins.json')['files']
for row in before:
    assert pin(R/row['path']) == {key:row[key] for key in ('bytes','sha256')}
assert read(F/'summary.json')['status'] == 'PASS'
dependency_paths = set()
for name in ('qwen_prepared_roles_test', 'qwen_precision_profile_test'):
    data = read(F/name/'sourceDependencies.json')['Data']
    for raw in [data['Source'], *data['Includes']]:
        path = Path(raw).resolve()
        if path.is_relative_to(R): dependency_paths.add(path)
dependencies = [dict(path=p.relative_to(R).as_posix(), **pin(p)) for p in sorted(dependency_paths)]
(W/'dependency-pins.json').write_text(json.dumps(dependencies, indent=2)+'\n', encoding='utf-8')
processes = []
for rel in ('python', 'qwen_prepared_roles_test/compile', 'qwen_prepared_roles_test/run',
            'qwen_precision_profile_test/compile', 'qwen_precision_profile_test/run'):
    p = read(F/rel/'process.json')
    processes.append(dict(path='host1/'+rel+'/process.json', exit=p['exit'],
        wall_seconds=p['process_wall_seconds'], timed_out=p['timed_out']))
summary = dict(
    status='PRIVATE_SIX_FILE_POLICY_READY_HOST_CHECKED_CANONICAL_UNTOUCHED',
    source=dict(before='before-pins.json', after='after-pins.json', patch=dict(path='source.patch', **pin(W/'source.patch')),
        support='support-pins.json', actual_cpp_dependencies='dependency-pins.json'),
    API=dict(type='prepared::CachePolicy', values=['kDefault','kBFloat16OmitCalibration','kFloat8OriginalCalibration'],
        roles_fields=['CachePolicy cache_policy','vector<Role> cache_calibration'],
        order='numeric attention slot, original K then V; no second map or scale owner',
        policies=['kv_cache\tBF16\tomit_original_calibration', 'kv_cache\tE4M3FN\toriginal_kv_scales']),
    checks=dict(python=dict(tests=19, log='host1/python/stderr.log'),
        prepared_roles=dict(checks=13555, log='host1/qwen_prepared_roles_test/run/stdout.log'),
        precision_profile=dict(checks=17, log='host1/qwen_precision_profile_test/run/stdout.log'),
        strict_flags=['/W4','/WX','/permissive-'], processes=processes, failures=[]),
    invariants=[
        'Both cache choices keep calibration outside selected weight operands and weight byte totals.',
        'E4 requires all original BF16[1] K/V pairs and the source static tensor float8 scheme.',
        'Preparer returns and authenticates the exact bounded two-byte source scalar; F32 is exact BF16 widening.',
        'Zero, negative and nonfinite E4 scales reject; no clipping, inverse or synthetic default.',
        'E4 cache does not select F16/FP8 activation math; CT activation remains BF16.',
        'E4 plus MTP rejects cold; original BF16 MTP metadata control remains valid.',
        'Same source bytes with BF16 vs E4 policy have different source identity.',
        'Manifest parsing and original numeric-layer ordering reject missing, malformed or duplicate policy/pairs.'
    ],
    original_calibration=dict(reference='../scalar-binding-plan/attempt1/complete.json', bytes=64,
        roles=32, unique_pairs=16, payload_sha256='aabf9095ed6a1d2d8ce6f71d282e6812160b0ea9dfc30cf4d2def08c4d0f12a6',
        reused_not_reacquired=True, whole_checkpoint_LFS_body_verified=False),
    integration_notes=[
        'Root owns Model source IO/cache/Graph wiring; these six canonical paths remain byte-identical to before pins.',
        'Delete old Bf16CachePolicy/omitted_cache_calibration uses, without aliases.',
        'A report named omitted must count cache_calibration only for kBFloat16OmitCalibration.',
        'E4 receipt ct_mixed_policy.cache_dtype states E4M3FN; legacy BF16 policy/identity path remains BF16.',
        'Root consumes original Role source/offset/bytes independently; do not assume scalars are contiguous.'
    ],
    not_verified=['No Model or Graph execution', 'No E4 KV native numerical case', 'No native or SDK builds',
        'No new HTTP or payload copies', 'No Apple/Vulkan/CUDA route checks', 'No E4 MTP support'])
(W/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(summary=pin(W/'summary.json'), patch=pin(W/'source.patch'), paths=len(owned), cpp_repository_dependencies=len(dependencies)), indent=2))
