from pathlib import Path
import re,json,hashlib,difflib
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent;S=D/'source';B=D/'before'
paths=['engine/models/qwen35/session_state.h','engine/models/qwen35/model_geometry.h']
for base in ['engine','tests','samples']:
 for f in (R/base).rglob('*'):
  if f.is_file() and f.suffix in {'.h','.cc','.cpp'} and f != R/'engine/models/qwen35/main.cc':
   if re.search(r'(?:cache|p)::plan\(',f.read_text(encoding='utf-8-sig')):paths.append(f.relative_to(R).as_posix())
assert len(paths)==21,len(paths)
for name in paths:
 p=B/name;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():p.write_bytes((R/name).read_bytes())
 p=S/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((B/name).read_bytes())
def read(n):return (S/n).read_bytes().decode('utf-8')
def write(n,t):(S/n).write_bytes(t.encode('utf-8'))
def rep(t,a,b):
 assert t.count(a)==1,(a,t.count(a));return t.replace(a,b)
n='engine/models/qwen35/session_state.h';t=read(n);e='\r\n' if '\r\n' in t else '\n'
t=rep(t,'// Target and draft inventories',('struct KvRowBytes final {'+e+'  std::size_t key = 0, value = 0;'+e+'  friend constexpr bool operator==(const KvRowBytes &, const KvRowBytes &) noexcept = default;'+e+'};'+e+e+'// Target and draft inventories'))
t=rep(t,'  static constexpr std::uint32_t page_rows = 16;','  static constexpr std::uint32_t page_rows = 16;'+e+'  KvRowBytes row_bytes;')
t=rep(t,'inline Plan plan(const ModelGeometry &geometry, std::size_t context, std::size_t residents,','inline Plan plan(const ModelGeometry &geometry, KvRowBytes row_bytes,'+e+'                 std::size_t context, std::size_t residents,')
t=rep(t,'  geometry.validate();','  geometry.validate();'+e+'  if (!row_bytes.key || !row_bytes.value)'+e+'    throw std::runtime_error("cache plan requires positive actual K/V row byte extents");')
t=rep(t,'  Plan result;','  Plan result;'+e+'  result.row_bytes = row_bytes;')
t=t.replace('geometry.key_row_bytes()','row_bytes.key').replace('geometry.value_row_bytes()','row_bytes.value');write(n,t)
n='engine/models/qwen35/model_geometry.h';t=read(n)
t=rep(t,'  std::size_t key_row_bytes() const { return static_cast<std::size_t>(multiply(multiply(kv_heads, key_depth), 2)); }'+e,'')
t=rep(t,'  std::size_t value_row_bytes() const { return static_cast<std::size_t>(multiply(multiply(kv_heads, value_depth), 2)); }'+e,'')
t=rep(t,'    (void)key_row_bytes(); (void)value_row_bytes();','    (void)multiply(kv_heads, key_depth); (void)multiply(kv_heads, value_depth);');write(n,t)
# Each native probe reads the actual selected source once, before planning, and moves it into Model.
probes=['engine/models/qwen35/batch_probe.cc','engine/models/qwen35/retained_budget_probe.cc','engine/models/qwen35/retirement_probe.cc','engine/models/qwen35/mtp_session_probe.cc']
for n in probes:
 t=read(n);e='\r\n' if '\r\n' in t else '\n';lines=t.splitlines(keepends=True);out=[]
 for line in lines:
  if 'q::cache::plan(geometry,' in line:
   # All MTP probe plans explicitly include the draft cache; the first retirement case is Text only.
   include_mtp= n!='engine/models/qwen35/batch_probe.cc' and not(n.endswith('retirement_probe.cc') and 'capacity, 1, prompt.size()' in line)
   indent=line[:len(line)-len(line.lstrip())]
   out.append(indent+'auto weight_source = q::prepare_weight_source(inputs / "weights.tsv", '+str(include_mtp).lower()+');'+e)
   line=line.replace('q::cache::plan(geometry,','q::cache::plan(geometry, weight_source.cache_row_bytes,')
  out.append(line)
 t=''.join(out)
 count=t.count('q::Model model(inputs / "weights.tsv",')
 t=t.replace('q::Model model(inputs / "weights.tsv",','q::Model model(std::move(weight_source),')
 assert count in {1,2,5},(n,count)
 write(n,t)
# Original actual Model consumer fixtures explicitly use plain 16-bit KV carriers.
for n in paths:
 if not n.startswith('tests/') or n.endswith('qwen_prefix_cache_test.cc'):continue
 t=read(n);e='\r\n' if '\r\n' in t else '\n';m=re.search(r'^(\s*)const auto plan\s*=\s*q::cache::plan\((geometry|shape),',t,re.M);assert m,n
 indent=m[1].split(e)[-1];g=m[2]
 pre=(indent+'// This case uses the original plain 16-bit K/V cache carriers.'+e+
      indent+'const q::cache::KvRowBytes cache_rows{'+e+
      indent+'    q::cache::multiply(q::cache::multiply(static_cast<std::size_t>('+g+'.kv_heads), static_cast<std::size_t>('+g+'.key_depth)), 2),'+e+
      indent+'    q::cache::multiply(q::cache::multiply(static_cast<std::size_t>('+g+'.kv_heads), static_cast<std::size_t>('+g+'.value_depth)), 2)};'+e)
 # Match only indentation on this source line, not preceding blank-line whitespace.
 pos=t.rfind(e,0,m.end()-len(g)-1)+len(e)
 t=t[:pos]+pre+t[pos:];t=t.replace('q::cache::plan('+g+',','q::cache::plan('+g+', cache_rows,')
 write(n,t)
# The pure capacity suite names its fixture's BF16 widths, without needing CacheStorage or a provider.
n='tests/tools/qwen_prefix_cache_test.cc';t=read(n);e='\r\n' if '\r\n' in t else '\n'
helper=('p::KvRowBytes bf16_cache_rows(const qwen35::ModelGeometry &g) {'+e+
'  // These host capacity fixtures explicitly model plain BF16 K/V rows.'+e+
'  return {p::multiply(p::multiply(static_cast<std::size_t>(g.kv_heads), static_cast<std::size_t>(g.key_depth)), 2),'+e+
'      p::multiply(p::multiply(static_cast<std::size_t>(g.kv_heads), static_cast<std::size_t>(g.value_depth)), 2)};'+e+'}'+e)
t=rep(t,'void batch_state_capacity() {',helper+e+'void batch_state_capacity() {')
t=t.replace('p::plan(geometry,','p::plan(geometry, bf16_cache_rows(geometry),').replace('p::plan(larger,','p::plan(larger, bf16_cache_rows(larger),')
a='  const auto three=p::plan(geometry, bf16_cache_rows(geometry), 256,4,16,payload,2,3,true);'
insert='''  const auto bf16_rows = bf16_cache_rows(geometry);
  const p::KvRowBytes e4_rows{bf16_rows.key / 2, bf16_rows.value / 2};
  const auto e4 = p::plan(geometry, e4_rows, 256, 4, 16, payload, 2);
  const auto mixed_widths = p::plan(geometry, {e4_rows.key, bf16_rows.value}, 256, 4, 16, payload, 2);
  require(batch.row_bytes == bf16_rows && e4.row_bytes == e4_rows &&
      e4.key_bank_bytes == (batch.key_bank_bytes - 1) / 2 + 1 &&
      e4.value_bank_bytes == (batch.value_bank_bytes - 1) / 2 + 1 &&
      batch.backing_bytes - e4.backing_bytes ==
          ((batch.key_bank_bytes - e4.key_bank_bytes) + (batch.value_bank_bytes - e4.value_bank_bytes)) * batch.attention_layers &&
      mixed_widths.key_bank_bytes == e4.key_bank_bytes && mixed_widths.value_bank_bytes == batch.value_bank_bytes &&
      e4.recurrent_payload_bytes == batch.recurrent_payload_bytes && e4.state_slots == batch.state_slots &&
      e4.hidden_row_bytes == batch.hidden_row_bytes && e4.hidden_bytes == batch.hidden_bytes,
      "actual K/V row extents must change only physical KV backing, independently for each bank");
'''.replace('\n',e)
t=rep(t,a,insert+a)
a='  const auto maximum = (std::numeric_limits<std::size_t>::max)();'
# That name occurs in another unrelated capacity function as well; restrict insertion to batch_state_capacity.
start=t.index('void batch_state_capacity() {');at=t.index(a,start)
extra='''  rejects([&] { return p::plan(geometry, {0, 1024}, 256, 4, 16, payload, 1); });
  rejects([&] { return p::plan(geometry, {1024, 0}, 256, 4, 16, payload, 1); });
'''.replace('\n',e)
t=t[:at]+extra+t[at:]
a='  rejects([&] { return p::plan(geometry, bf16_cache_rows(geometry), maximum, 1, 1, payload, 1); });'
extra='''  rejects([&] { return p::plan(geometry, {maximum, 1024}, 1, 1, 1, 0); });
  rejects([&] { return p::plan(geometry, {1024, maximum}, 1, 1, 1, 0); });
'''.replace('\n',e)
t=rep(t,a,extra+a);write(n,t)
# Only required unchanged support for the std-only Plan consumer, not product changes.
support=['engine/inference/sampling_cursor.h','tests/tools/qwen_geometry_fixture.h']
for n in support:
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
# Generate host from the actual updated formal capacity function, not a mirror implementation.
t=read('tests/tools/qwen_prefix_cache_test.cc');begin=t.index('p::KvRowBytes bf16_cache_rows(');end=t.index('\nvoid exact_boundaries_and_domains()',begin)
body=t[begin:end].replace('\r\n','\n')
host='#include "source/engine/models/qwen35/session_state.h"\n#include "source/tests/tools/qwen_geometry_fixture.h"\n#include <cstdio>\nnamespace {\nnamespace p=qwen35::cache;\nconst auto geometry=qwen_test::q35();\nvoid require(bool x,const char*m){if(!x)throw std::runtime_error(m);}\n'+body+'\n}\nint main(){try{batch_state_capacity();std::puts("PASS canonical Plan capacity suite: original BF16 counts, explicit E4/asymmetric rows, bounds/overflow");return 0;}catch(const std::exception&e){std::fprintf(stderr,"%s\\n",e.what());return 1;}}\n'
(D/'plan-host.cc').write_text(host,encoding='utf-8')
def pin(p):
 b=p.read_bytes();return {'path':p.relative_to(D).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
changed=[];patch=[]
for n in paths:
 before=(B/n).read_bytes();after=(S/n).read_bytes();assert before!=after,n
 assert (b'\r\n' in before)==(b'\r\n' in after),n
 changed.append({'path':n,'before':pin(B/n),'after':pin(S/n)})
 patch.extend(difflib.unified_diff(before.decode('utf-8').splitlines(keepends=True),after.decode('utf-8').splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n))
(D/'source.patch').write_bytes(''.join(patch).encode('utf-8'))
(D/'source-pins.json').write_text(json.dumps({'products':changed,'support':[pin(S/n) for n in support],'host':pin(D/'plan-host.cc'),'scope':'private only; main/roles/typed-capability untouched'},indent=2)+'\n',encoding='utf-8')
print('PRIVATE_PRODUCT_FILES',len(paths),'PATCH_BYTES',(D/'source.patch').stat().st_size)
