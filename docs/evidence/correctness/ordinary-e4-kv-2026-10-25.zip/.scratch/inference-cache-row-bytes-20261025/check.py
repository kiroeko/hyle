from pathlib import Path
import sys,json,hashlib,subprocess,time,os
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
compiler=read(R/'.scratch/inference-system-review-20261025/request-lifecycle/window/compile/command.json')['command'][0]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
A=D/'host1'
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def execute(args,folder):
 folder.mkdir(parents=True,exist_ok=False)
 save(folder/'command.json',{'command':list(map(str,args)),'cwd':str(R),'timeout_seconds':60})
 t=time.monotonic()
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
  p=subprocess.Popen(list(map(str,args)),cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  try:code=p.wait(timeout=60);timeout=False
  except subprocess.TimeoutExpired:p.kill();code=p.wait();timeout=True
 result={'exit':code,'seconds':time.monotonic()-t,'timeout':timeout};save(folder/'process.json',result)
 print(folder.name,result,flush=True)
 if code or timeout:
  print((folder/'stdout.log').read_text(errors='replace'));print((folder/'stderr.log').read_text(errors='replace'));raise SystemExit(1)
 return result
compile=execute([compiler,'/nologo','/std:c++latest','/EHsc','/W4','/WX','/utf-8','/permissive-','/Zc:__cplusplus','/O2','/MD','/I'+str(R/'include'),'/sourceDependencies',A/'compile/dependencies.json','/c',D/'plan-host.cc','/Fo'+str(A/'compile/unit.obj')],A/'compile')
link=execute([Path(compiler).parent/'link.exe','/NOLOGO','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/OPT:REF',A/'compile/unit.obj','/OUT:'+str(A/'link/checks.exe')],A/'link')
run=execute([A/'link/checks.exe'],A/'run')
source=read(D/'source-pins.json');dep=read(A/'compile/dependencies.json')['Data']['Includes']
required=['engine/models/qwen35/session_state.h','engine/models/qwen35/model_geometry.h','tests/tools/qwen_geometry_fixture.h','engine/inference/sampling_cursor.h']
norm=lambda p:str(Path(p).resolve()).lower().replace('\\','/')
includes={norm(p) for p in dep}
assert all(norm(D/'source'/x) in includes for x in required)
assert not any('/hyle/engine/' in p or '/hyle/tests/' in p for p in includes), 'canonical private header leaked into host compilation'
pin=lambda p:{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
summary={'status':'HOST_PLAN_SUITE_PASS','scope':'One std-only host TU, extracting the actual updated batch_state_capacity function and BF16 row-fact fixture helper from private formal qwen_prefix_cache_test.cc; actual private planner/geometry headers; no alternate Plan implementation.', 'compile':compile,'link':link,'run':run,'product_files':len(source['products']),'checks':['Original Q35 R1/R2/candidate/draft/hidden/backing expected counts unchanged','Original Q27 geometry/backing expected counts unchanged','Explicit half-width KV and asymmetric K/V row extents, retained row facts, unchanged non-KV state capacity','Existing invalid context/resident/query/candidate/index/backing cases plus zero row byte extents and K/V row overflow'], 'excluded':['No Model or native runtime executed','No four-probe compilation or actual engine tests','No full prefix-directory suite or real LeasePool execution','No SDK/core/provider build, GPU or network'], 'source_pins':source,'actual_dependencies':[pin(Path(x)) for x in dep if Path(x).exists() and (norm(x).startswith(norm(R)+'/'))],'image':pin(A/'link/checks.exe'),'reproduce':'python .scratch/inference-cache-row-bytes-20261025/check.py (host1 paths must be unused; preserve prior results)','failures':[]}
save(D/'summary.json',summary);print(json.dumps({'status':summary['status'],'summary':str(D/'summary.json')}))
