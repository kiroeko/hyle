from pathlib import Path
import hashlib,json
work=Path(__file__).resolve().parent
root=work.parents[1]
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def check(path,pin):
    data=path.read_bytes()
    assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],str(path)
before=read(work/'before-pins.json')['files'];after=read(work/'after-pins.json')['files']
assert [p['path'] for p in before]==[p['path'] for p in after]
for old,new in zip(before,after):
    check(root/old['path'],old);check(work/'source'/new['path'],new)
for old,new in zip(before,after):
    (root/new['path']).write_bytes((work/'source'/new['path']).read_bytes());check(root/new['path'],new)
(work/'integrated.json').write_text(json.dumps(dict(files=after,status='EXACT_TWO_PATH_INTEGRATED'),indent=2)+'\n',encoding='utf-8')
print('integrated 2 exact paths')
