from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def replace_once(data, old, new):
    assert data.count(old) == 1, old
    return data.replace(old, new)


paths = [
    "src/graph_batch/paged_append.cc",
    "src/graph_route_vulkan/native_paged_append.cc",
    "tests/graph_batch/typed_capability_graph_test.cc",
]
before = {path: (OUT / "before" / path).read_bytes() if (OUT / "before" / path).is_file()
          else (ROOT / path).read_bytes() for path in paths}
after = dict(before)
path = paths[0]
newline = b"\r\n" if b"\r\n" in before[path] else b"\n"
old = '''  if(storage.data_type()!=c::DataType::kFloat16 && storage.data_type()!=c::DataType::kBFloat16)
    return std::unexpected(Status::Unimplemented("paged append currently copies plain F16/BF16 rows"));
  return c::TensorDesc::dense(storage.data_type(),std::array<std::int64_t,3>{rows,cap.kv_heads,
      op.role==c::BatchCacheRole::kValue?cap.value_head_dim:cap.qk_head_dim});'''
new = '''  if(!storage.format().is_plain() ||
      (storage.data_type()!=c::DataType::kFloat16 && storage.data_type()!=c::DataType::kBFloat16 &&
       storage.data_type()!=c::DataType::kFloat8E4M3FN))
    return std::unexpected(Status::Unimplemented("paged append copies plain F16/BF16/E4 rows"));
  return c::cache_carrier_description(storage,std::array<std::int64_t,3>{rows,cap.kv_heads,
      op.role==c::BatchCacheRole::kValue?cap.value_head_dim:cap.qk_head_dim});'''
after[path] = replace_once(before[path], old.encode().replace(b"\n", newline), new.encode().replace(b"\n", newline))
path = paths[1]
newline = b"\r\n" if b"\r\n" in before[path] else b"\n"
old = '''  if (type != compute::DataType::kFloat16 && type != compute::DataType::kBFloat16)
    return std::unexpected(Status::Unimplemented("Vulkan append requires plain F16/BF16 rows"));'''
new = '''  if (type != compute::DataType::kFloat16 && type != compute::DataType::kBFloat16 &&
      type != compute::DataType::kFloat8E4M3FN)
    return std::unexpected(Status::Unimplemented("Vulkan append requires plain F16/BF16/E4 rows"));'''
after[path] = replace_once(before[path], old.encode().replace(b"\n", newline), new.encode().replace(b"\n", newline))
path = paths[2]
newline = b"\r\n" if b"\r\n" in before[path] else b"\n"
addition = (OUT / "tests-addition.txt").read_text(encoding="utf-8")
after[path] = replace_once(before[path], b"} // namespace", addition.encode().replace(b"\n", newline) + newline + b"} // namespace")
after[path] = replace_once(after[path], b'#include "hyle/compute/backends/cpu.h"',
    b'#include "hyle/compute/backends/cpu.h"' + newline + b'#include "hyle/compute/model_ops.h"')
after[path] = replace_once(after[path], b'#include <cstdint>',
    b'#include <cstdint>' + newline + b'#include <exception>' + newline + b'#include <string_view>')

pins = []
diff = []
for path in paths:
    for directory, data in (("before", before[path]), ("source", after[path])):
        target = OUT / directory / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    pins.append({"path": path, "before": sha(before[path]), "after": sha(after[path]),
                 "before_bytes": len(before[path]), "after_bytes": len(after[path]),
                 "newline": "CRLF" if b"\r\n" in before[path] else "LF"})
    diff.extend(difflib.unified_diff(before[path].decode().splitlines(keepends=True),
        after[path].decode().splitlines(keepends=True), fromfile="a/" + path, tofile="b/" + path))
(OUT / "source.patch").write_bytes("".join(diff).encode())
result = {"status": "PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN", "base_commit": subprocess.check_output(
    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(), "files": pins,
    "patch_sha256": sha((OUT / "source.patch").read_bytes())}
(OUT / "source-pins.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
