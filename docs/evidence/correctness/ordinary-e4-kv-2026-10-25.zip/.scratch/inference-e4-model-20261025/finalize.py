from pathlib import Path
import hashlib,json,subprocess
work=Path(__file__).resolve().parent;root=work.parents[1]
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def pin(path):
    body=path.read_bytes();return dict(path=path.relative_to(root).as_posix(),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
cuda=work/'cuda-plan/attempt1';plan=read(work/'cuda-plan/plan.json');ready=read(cuda/'ready.json')
for item in ready['source_pins']:
    data=Path(item['path']).read_bytes()
    if hashlib.sha256(data).hexdigest()!=item['sha256']:
        assert Path(item['path']).resolve()==(root/'engine/models/qwen35/main.cc').resolve()
        prior=(work/'cpu1/source/engine/models/qwen35/main.cc').read_bytes()
        assert hashlib.sha256(prior).hexdigest()==item['sha256']
        old=prior.decode('utf-8-sig');new=data.decode('utf-8-sig')
        expected=old.replace('    const auto active_slots = selected_cache.active_sequences;\n',
            '    const auto active_slots = selected_cache.active_sequences;\n    const auto metadata_prepare_seconds = weight_source.metadata_prepare_seconds;\n',1)
        expected=expected.replace('std::cerr << "initialized model_seconds=" << std::chrono::duration<double>(constructed - model_start).count()',
            'std::cerr << "initialized model_seconds=" << metadata_prepare_seconds +\n                  std::chrono::duration<double>(constructed - model_start).count()',1)
        assert expected==new
        marker='int qwen35::run(int argc, char **argv)'
        assert old.split(marker)[0]==new.split(marker)[0]
        save(work/'final-source-delta.json',dict(status='SOURCE_ONLY_CLI_DIAGNOSTIC_TIMING_CORRECTION',
            validated_main=item,final_main=pin(Path(item['path'])),Model_and_all_previous_definitions_byte_identical=True,
            executed_source_prefix_sha256=hashlib.sha256(new.split(marker)[0].encode()).hexdigest(),
            change='Save source metadata preparation elapsed before move; add only this elapsed stage to initialized model_seconds. startup and weights_load_seconds already include it and are unchanged.',
            checked='Exact two replacements and identical prefix before CLI run. No model recompile or execution for this report-only delta.'))
checks={name:read(cuda/name/'process.json') for name in ['app','cpu-native-batch','link','run']}
assert all(value['exit']==0 and not value['timeout'] for value in checks.values())
result=json.loads((cuda/'run/stdout.log').read_text().splitlines()[-1]);assert result['status']=='PASS' and result['backend']=='cuda'
save(cuda/'summary.json',dict(status='FINITE_ACTUAL_CUDA_E4_MODEL_PASS',processes=checks,result=result,
    source_pins=ready['source_pins'],app_actual_dependencies=pin(cuda/'app/actual-dependencies.json'),
    CPU_companion_actual_dependencies=pin(cuda/'cpu-native-batch/actual-dependencies.json'),
    reused_link_inputs=plan['base_link_inputs']-len(plan['replacements']),total_absolute_link_inputs=plan['base_link_inputs'],
    current_cached_replacements=plan['reused_replacements'],arena=plan['arena_object'],native_CPU_Dll=plan['native_dll'],
    native_CUDA_ABI=plan['native_cuda_records'],SDK_or_device_rebuilt=False,HTTP=0,
    scope='Generated two-attention-layer CT AA consumer; original four cache scales; actual CUDA context; source graph/calibration/physical banks/old rows/equal-prefix fork/complete retirement.',
    not_proven=['Original full Q27 model','Full-model mathematical/quality oracle','Performance or peak VRAM','MTP E4','Apple/Vulkan/Linux E4 Model native execution']))
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
paths=sorted({name for name in [*changed,*untracked] if name.startswith(('engine/','src/','include/','tests/'))})
save(work/'final-source-pins.json',dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),files=[pin(root/name) for name in paths]))
print(json.dumps(dict(cuda=result,final_source_paths=len(paths))))
