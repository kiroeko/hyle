from pathlib import Path
import importlib.util, json, os, sys
WORK=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('bounded_cpu',WORK/'check_cpu.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
ROOT=c.ROOT
attempt=WORK/'cpu2'
assert not attempt.exists()
recipe=c.read(ROOT/'.scratch/inference-cache-shared-source-20261025/attempt1/arena/command.json')['command']
compiler=recipe[0];flags=[];skip=False
for arg in recipe[1:]:
    if skip:skip=False;continue
    if arg=='/sourceDependencies':skip=True;continue
    if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
    if 'inference-cache-shared-source-20261025' in arg:continue
    flags.append(arg)
env=c.discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
source=ROOT/'src/compute_batch/paged_arena.cc';header=ROOT/'include/hyle/compute/paged_arena.h'
before=[c.pin(source),c.pin(header)]
obj=attempt/'compile-arena/unit.obj'
build=c.execute([compiler,*flags,str(source),'/sourceDependencies',str(attempt/'compile-arena/dependencies.json'),'/Fo'+str(obj),'/Fd'+str(attempt/'compile-arena/unit.pdb')],env,attempt/'compile-arena')
data=c.read(attempt/'compile-arena/dependencies.json')['Data'];deps=[Path(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]
c.save(attempt/'actual-dependencies.json',[c.pin(p) for p in deps])
previous=c.read(WORK/'cpu1/link/command.json')['command'];command=[];replaced=[]
old=ROOT/'.scratch/inference-cache-shared-source-20261025/attempt1/arena/unit.obj'
for arg in previous:
    if arg.lower().startswith(('/out:','/pdb:','/implib:','/map:')):continue
    if arg==str(old):replaced.append(dict(before=arg,after=str(obj)));arg=str(obj)
    command.append(arg)
assert len(replaced)==1,replaced
image=attempt/'link/component.exe'
c.save(attempt/'link-inputs.json',dict(inputs=[c.pin(Path(arg)) for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')],replaced=replaced,reused_app=c.pin(WORK/'cpu1/compile/unit.obj')))
linked=c.execute([*command,'/OUT:'+str(image),'/PDB:'+str(attempt/'link/component.pdb'),'/IMPLIB:'+str(attempt/'link/component.lib')],env,attempt/'link',90)
native=ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,image.parent/native.name)
run_env=dict(env);run_env['PATH']=str(image.parent)+';'+c.read(ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')['PATH']
run_env['HF_HUB_OFFLINE']=run_env['TRANSFORMERS_OFFLINE']='1'
default=c.execute([str(image),'default',str(WORK/'fixture-preparation/bf16-original')],run_env,attempt/'run-default')
e4=c.execute([str(image),'e4',str(WORK/'fixture-preparation/ct-e4-aa')],run_env,attempt/'run-e4')
for value in before:assert c.pin(Path(value['path']))==value
c.save(attempt/'summary.json',dict(status='FINITE_ACTUAL_CPU_DEFAULT_AND_E4_PASS',arena_compile=build,link=linked,default=default,E4=e4,sources=before,new_main_compiles=0,reused_main=c.pin(WORK/'cpu1/compile/unit.obj'),native=c.pin(native),SDK_rebuilt=False,HTTP=0,quality=False,CUDA=False))
