from pathlib import Path
import hashlib,json
work=Path(__file__).resolve().parent;root=work.parents[1]
base=root/'.scratch/inference-e4-append-implementation-20261025'
files=[]
for index in range(1,8):
    folder=(base/f'check{index}').resolve();assert folder.is_relative_to(root/'.scratch')
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.suffix.lower() in {'.exe','.obj','.pdb','.lib','.exp'}:
            data=path.read_bytes();files.append(dict(path=path.relative_to(root).as_posix(),task_base=folder.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert len(files)==26
out=work/'cleanup';out.mkdir(exist_ok=False)
(out/'plan.json').write_text(json.dumps(dict(files=files,logical_bytes=sum(row['bytes'] for row in files),scope='Only superseded check1-check7 append test binaries. Keep final current objects, source, commands, logs, results, native DLLs and SDKs.'),indent=2)+'\n',encoding='utf-8')
prior=(root/'test.ps1').read_text(encoding='utf-8-sig')
(out/'prior-test.ps1').write_text(prior,encoding='utf-8')
script=prior.replace('.scratch/inference-system-review-20261025/archived-case-cleanup','.scratch/inference-e4-model-20261025/cleanup')
script=script.replace('$taskPlan.files.Count -ne 27','$taskPlan.files.Count -ne '+str(len(files)))
script=script.replace('$taskPlan.logical_bytes -ne 315321532L','$taskPlan.logical_bytes -ne '+str(sum(row['bytes'] for row in files))+'L')
script=script.replace("@('.exe','.obj','.lib','.exp','.dll')","@('.exe','.obj','.lib','.exp','.pdb')")
assert '315321532' not in script and 'archived-case-cleanup' not in script
(root/'test.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(files=len(files),logical_bytes=sum(row['bytes'] for row in files),scope='Preview only until archived evidence has been verified')))
