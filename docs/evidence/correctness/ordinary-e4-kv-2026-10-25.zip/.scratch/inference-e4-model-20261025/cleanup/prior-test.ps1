param([switch]$Apply)
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
if ($taskRoot -ne 'C:\public\project-hyle\hyle') { throw 'Unexpected workspace' }
$taskBase = Join-Path $taskRoot '.scratch/inference-system-review-20261025/archived-case-cleanup'
$taskPlan = Get-Content -LiteralPath (Join-Path $taskBase 'plan.json') -Raw | ConvertFrom-Json
if ((Test-Path -LiteralPath (Join-Path $taskBase 'removed.json')) -or $taskPlan.files.Count -ne 27 -or $taskPlan.logical_bytes -ne 315321532L) { throw 'Plan changed or already applied' }
$taskActive = @(Get-CimInstance Win32_Process | Select-Object -ExpandProperty ExecutablePath)
$taskTargets = @(foreach ($entry in $taskPlan.files) {
  $taskPath = [IO.Path]::GetFullPath((Join-Path $taskRoot $entry.path))
  $taskAllowed = [IO.Path]::GetFullPath((Join-Path $taskRoot $entry.task_base))
  if (!$taskPath.StartsWith($taskAllowed+'\',[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetExtension($taskPath) -notin @('.exe','.obj','.lib','.exp','.dll')) { throw 'Target outside exact binary scope' }
  if ((Resolve-Path -LiteralPath $taskPath).Path -ne $taskPath -or $taskActive -contains $taskPath) { throw 'Target changed or active' }
  for ($taskParent=$taskPath; $taskParent; $taskParent=[IO.Path]::GetDirectoryName($taskParent)) {
    if ((Get-Item -LiteralPath $taskParent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point in target path' }
  }
  $taskItem = Get-Item -LiteralPath $taskPath
  if ($taskItem.PSIsContainer -or $taskItem.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash -ne $entry.sha256) { throw 'Recorded binary differs' }
  $taskFile = [IO.File]::Open($taskPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
  $taskFile.Dispose()
  [pscustomobject]@{path=$taskPath;bytes=$entry.bytes;sha256=$entry.sha256}
})
$taskResult = [ordered]@{applied=[bool]$Apply;files=$taskTargets;logical_bytes=$taskPlan.logical_bytes;physical_bytes_freed_unknown=$true}
$taskLog = if ($Apply) { 'checked-apply.json' } else { 'preview.json' }
$taskResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $taskBase $taskLog) -Encoding utf8
if ($Apply) {
  foreach ($entry in $taskTargets) { Remove-Item -LiteralPath $entry.path }
  foreach ($entry in $taskTargets) { if (Test-Path -LiteralPath $entry.path) { throw 'Target still present' } }
  $taskResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $taskBase 'removed.json') -Encoding utf8
}
[ordered]@{files=$taskTargets.Count;logical_bytes=$taskPlan.logical_bytes;applied=[bool]$Apply} | ConvertTo-Json
