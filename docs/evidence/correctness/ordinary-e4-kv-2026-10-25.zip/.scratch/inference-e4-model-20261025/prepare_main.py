from pathlib import Path
import difflib
import hashlib
import json

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
name='engine/models/qwen35/main.cc'
old=(ROOT/name).read_bytes()
assert hashlib.sha256(old).hexdigest()=='0d87c013574852d8dc6670e0ea98aa39682290c971963662423bf648b5318c48'
text=old.decode().replace('\r\n','\n')
def replace(a,b):
    global text
    assert text.count(a)==1,(a[:100],text.count(a))
    text=text.replace(a,b)
replace('#include "precision_profile.h"','#include "precision_profile.h"\n#include "cache_precision.h"')
replace('''struct PreparedWeightSource {
  prepared::Roles roles;
  double metadata_prepare_seconds = 0;
};
PreparedWeightSource prepare_weight_source(const std::filesystem::path &manifest, bool include_mtp) {
  const auto start = Clock::now();
  auto roles = read_weight_roles(manifest, include_mtp);
  return {std::move(roles), std::chrono::duration<double>(Clock::now() - start).count()};
}''','''struct PreparedWeightSource {
  prepared::Roles roles;
  std::vector<CacheStoragePair> cache_storage;
  cache::KvRowBytes cache_row_bytes;
  double metadata_prepare_seconds = 0;
};
PreparedWeightSource prepare_weight_source(const std::filesystem::path &manifest, bool include_mtp) {
  const auto start = Clock::now();
  auto roles = read_weight_roles(manifest, include_mtp);
  auto storage = read_cache_calibration(roles);
  const auto plain = take(c::CacheStorage::plain(PrecisionProfile::from_roles(roles).activation_type()));
  const auto rows = cache_storage_row_bytes(roles.geometry, storage.empty() ? CacheStoragePair{plain, plain} : storage.front());
  for (const auto &pair : storage)
    if (cache_storage_row_bytes(roles.geometry, pair) != rows)
      throw std::runtime_error("selected cache layers require different physical row extents");
  return {std::move(roles), std::move(storage), {rows[0], rows[1]},
      std::chrono::duration<double>(Clock::now() - start).count()};
}''')
replace('roles.omitted_cache_calibration.size(), nf4_groups,','(roles.cache_policy == prepared::CachePolicy::kBFloat16OmitCalibration ? roles.cache_calibration.size() : 0), nf4_groups,')
replace('''  std::vector<StateSchema> state_schema;
  c::ResourceBudget cache_budget''','''  std::vector<StateSchema> state_schema;
  const prepared::CachePolicy cache_policy;
  const std::vector<CacheStoragePair> attention_storage;
  c::ResourceBudget cache_budget''')
replace('''      SamplingConfiguration first, std::span<const SamplingConfiguration> additional)
      : state_schema(state_schema_for(geometry, capacity, precision)), state_pools(geometry.layers.size()),''','''      SamplingConfiguration first, std::span<const SamplingConfiguration> additional,
      prepared::CachePolicy policy, std::vector<CacheStoragePair> storage)
      : state_schema(state_schema_for(geometry, capacity, precision)),
        cache_policy(policy), attention_storage(std::move(storage)), state_pools(geometry.layers.size()),''')
replace('''  c::BatchSchema attention_schema;
  cache::VersionCount &snapshot_versions;''','''  c::BatchSchema attention_schema;
  std::vector<c::BatchSchema> attention_schemas;
  const c::BatchSchema &target_attention_schema(std::size_t layer) const {
    if (layer >= target_kv_layers) throw std::runtime_error("invalid target attention cache slot");
    return attention_schemas.empty() ? attention_schema : attention_schemas.at(layer);
  }
  cache::VersionCount &snapshot_versions;''')
replace('''              SamplingConfiguration{sampling_configuration.enabled, sampling_configuration.policy}, additional_sampling)),''','''              SamplingConfiguration{sampling_configuration.enabled, sampling_configuration.policy}, additional_sampling,
              source.roles.cache_policy, std::move(source.cache_storage))),''')
replace('''    if (source_roles.geometry != geometry) throw std::runtime_error("source geometry changed before weight loading");
    if (cache_plan.hidden_row_bytes''','''    if (source_roles.geometry != geometry) throw std::runtime_error("source geometry changed before weight loading");
    const bool calibrated = resources_->cache_policy == prepared::CachePolicy::kFloat8OriginalCalibration;
    if ((calibrated && resources_->attention_storage.size() != target_kv_layers) ||
        (!calibrated && !resources_->attention_storage.empty()) || (calibrated && cache_plan.draft_cache))
      throw std::runtime_error("prepared E4 cache storage requires its complete ordinary target pairs");
    if (cache_plan.row_bytes != source.cache_row_bytes ||
        cache_plan.key_bank_bytes != cache::add(cache::multiply(cache::multiply(cache_plan.max_pages,
            cache::Plan::page_rows), source.cache_row_bytes.key), 1) ||
        cache_plan.value_bank_bytes != cache::add(cache::multiply(cache::multiply(cache_plan.max_pages,
            cache::Plan::page_rows), source.cache_row_bytes.value), 1))
      throw std::runtime_error("cache backing plan differs from prepared physical storage");
    if (cache_plan.hidden_row_bytes''')
replace('''    if (omitted_cache_roles) result += ",\\\"kv_cache_dtype\\\":\\\"BF16\\\",\\\"omitted_original_cache_calibration_roles\\\":" +
        std::to_string(omitted_cache_roles);
    return result;''','''    if (omitted_cache_roles) result += ",\\\"kv_cache_dtype\\\":\\\"BF16\\\",\\\"omitted_original_cache_calibration_roles\\\":" +
        std::to_string(omitted_cache_roles);
    if (resources_->cache_policy == prepared::CachePolicy::kFloat8OriginalCalibration)
      result += ",\\\"kv_cache_dtype\\\":\\\"E4M3FN\\\",\\\"original_cache_calibration_roles\\\":" +
          std::to_string(resources_->attention_storage.size() * 2);
    return result;''')
replace('''    cache::PageInventory prepared_inventory, prepared_draft;
    prepared_inventory.prepare(cache_plan.max_pages, target_kv_layers);''','''    std::vector<c::BatchSchema> prepared_schemas;
    prepared_schemas.reserve(resources_->attention_storage.size());
    for (const auto &pair : resources_->attention_storage)
      prepared_schemas.push_back(take(prepared_schema.with_cache_storage(pair[0], pair[1])));
    cache::PageInventory prepared_inventory, prepared_draft;
    prepared_inventory.prepare(cache_plan.max_pages, target_kv_layers);''')
replace('''    for (std::size_t i = 0; i < prepared_inventory.keys.size(); ++i) {
      prepared_inventory.keys[i] = take(c::PagedArena::create(prepared_schema, c::BatchCacheRole::kKey,''','''    for (std::size_t i = 0; i < prepared_inventory.keys.size(); ++i) {
      const auto &schema = prepared_schemas.empty() ? prepared_schema : prepared_schemas[i];
      prepared_inventory.keys[i] = take(c::PagedArena::create(schema, c::BatchCacheRole::kKey,''')
replace('''      prepared_inventory.values[i] = take(c::PagedArena::create(prepared_schema, c::BatchCacheRole::kValue,''','''      prepared_inventory.values[i] = take(c::PagedArena::create(schema, c::BatchCacheRole::kValue,''')
replace('''    snapshot_versions.capacity = cache_plan.snapshot_slots;
    attention_schema = std::move(prepared_schema);''','''    snapshot_versions.capacity = cache_plan.snapshot_slots;
    attention_schemas = std::move(prepared_schemas);
    attention_schema = std::move(prepared_schema);''')
replace('''        ports.key = r.input(take(c::batch_cache_description(attention_schema, c::BatchCacheRole::kKey)));
        ports.value = r.input(take(c::batch_cache_description(attention_schema, c::BatchCacheRole::kValue)));''','''        const auto layer = geometry.attention_slot(i);
        const auto &schema = target_attention_schema(layer);
        ports.key = r.input(take(c::batch_cache_description(schema, c::BatchCacheRole::kKey)));
        ports.value = r.input(take(c::batch_cache_description(schema, c::BatchCacheRole::kValue)));''')
replace('''        const auto layer = geometry.attention_slot(i);
        auto &key_append = definition.append_nodes[layer * 2];''','''        auto &key_append = definition.append_nodes[layer * 2];''')
replace('''        r.op(c::Operation::custom(take(g::batch::paged_append(attention_schema, c::BatchCacheRole::kKey))),
            {r.reshape(k, {packed, f(geometry.kv_heads), f(geometry.key_depth)})}, {}, &key_append);
        r.op(c::Operation::custom(take(g::batch::paged_append(attention_schema, c::BatchCacheRole::kValue))),
            {r.reshape(v, {packed, f(geometry.kv_heads), f(geometry.value_depth)})}, {}, &value_append);''','''        auto key_rows = r.reshape(k, {packed, f(geometry.kv_heads), f(geometry.key_depth)});
        auto value_rows = r.reshape(v, {packed, f(geometry.kv_heads), f(geometry.value_depth)});
        const auto cache_capacity = schema.capacity();
        if (cache_capacity.key_storage.data_type() == Type::kFloat8E4M3FN)
          key_rows = r.one(c::Operation::custom(c::model_ops::CacheEncode{cache_capacity.key_storage}),
              {key_rows}, r.dense_spec(Type::kFloat8E4M3FN, {packed, f(geometry.kv_heads), f(geometry.key_depth)}));
        if (cache_capacity.value_storage.data_type() == Type::kFloat8E4M3FN)
          value_rows = r.one(c::Operation::custom(c::model_ops::CacheEncode{cache_capacity.value_storage}),
              {value_rows}, r.dense_spec(Type::kFloat8E4M3FN, {packed, f(geometry.kv_heads), f(geometry.value_depth)}));
        r.op(c::Operation::custom(take(g::batch::paged_append(schema, c::BatchCacheRole::kKey))),
            {key_rows}, {}, &key_append);
        r.op(c::Operation::custom(take(g::batch::paged_append(schema, c::BatchCacheRole::kValue))),
            {value_rows}, {}, &value_append);''')
replace('''.capacity = definition.attention_schema.capacity(), .scale = 1.F / std::sqrt(static_cast<float>(geometry.key_depth)), .causal = true}),''','''.capacity = cache_capacity, .scale = 1.F / std::sqrt(static_cast<float>(geometry.key_depth)), .causal = true}),''')
replace('''    const auto geometry = qwen35::read_weight_geometry(input / "weights.tsv");''','''    auto weight_source = qwen35::prepare_weight_source(input / "weights.tsv", mtp_enabled);
    const auto geometry = weight_source.roles.geometry;''')
replace('''      return qwen35::cache::plan(geometry, capacity, residents,''','''      return qwen35::cache::plan(geometry, weight_source.cache_row_bytes, capacity, residents,''')
replace('''    qwen35::Model model(input / "weights.tsv", geometry, capacity, selected_cache, layer0_probe, progress, replay, cache_bytes, sampler, cpu_ffn_layers, backend_selection);''','''    qwen35::Model model(std::move(weight_source), geometry, capacity, selected_cache, layer0_probe, progress, replay, cache_bytes, sampler, cpu_ffn_layers, backend_selection);''')
newline='\r\n' if b'\r\n' in old else '\n'
new=text.replace('\n',newline).encode()
for folder,data in [('before',old),('source',new)]:
    target=WORK/folder/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
paths=[name,'engine/models/qwen35/cache_precision.h']
pins=[];patch=[]
for path in paths:
    before=(ROOT/path).read_bytes() if (ROOT/path).exists() else b''
    after=(WORK/'source'/path).read_bytes()
    pins.append(dict(path=path,before=hashlib.sha256(before).hexdigest() if before else None,
        after=hashlib.sha256(after).hexdigest(),bytes=len(after)))
    patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),
        fromfile='a/'+path if before else '/dev/null',tofile='b/'+path))
(WORK/'source-pins.json').write_text(json.dumps(dict(files=pins),indent=2)+'\n')
(WORK/'source.patch').write_bytes(''.join(patch).encode())
print(json.dumps(pins,indent=2))
