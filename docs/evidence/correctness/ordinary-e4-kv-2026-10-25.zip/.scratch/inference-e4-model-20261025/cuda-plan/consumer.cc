// Thin actual Model consumer; no alternate execution or numerical implementation.
#include "../../../engine/models/qwen35/main.cc"
#include "../../../tests/tools/qwen_e4_cache_case.h"
int main(int argc, char **argv) {
  if (argc != 2) { std::fprintf(stderr, "usage: e4-cuda INPUT_DIR\n"); return 2; }
  try { return qwen_e4_cache_case::run(argv[1], {.primary=qwen35::BackendKind::kCuda}); }
  catch (const std::exception &error) { std::fprintf(stderr, "%s\n", error.what()); return 1; }
}
