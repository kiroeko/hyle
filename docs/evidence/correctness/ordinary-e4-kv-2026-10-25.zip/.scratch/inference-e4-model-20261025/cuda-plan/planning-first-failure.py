"""E4 CUDA Model finite cache plan. Default action is source/metadata only.
plan: no compile/link/run; build: two host TUs + original link; run: explicit separate GPU action.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];WORK=Path(__file__).resolve().parent
BASE=ROOT/'.scratch/inference-qwen-static-fp8-20261025/original-cuda/attempt1'
OLD=ROOT/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1'
CPU=ROOT/'.scratch/inference-layout-storage-validation-20261025/cpu1/compile'
SIX=[
 ('src/compute_batch/batch_layout.cc',ROOT/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2/layout/layout.obj',CPU/'compute_batch--batch_layout'),
 ('src/graph_batch/batch.cc',OLD/'graph_batch--batch.obj',CPU/'graph_batch--batch'),
 ('src/graph_batch/native_batch_regions.cc',OLD/'graph_batch--native_batch_regions.obj',CPU/'graph_batch--native_batch_regions'),
 ('src/graph_batch/native_paged_node.cc',OLD/'graph_batch--native_paged_node.obj',CPU/'graph_batch--native_paged_node'),
 ('src/graph_batch/paged_append.cc',OLD/'graph_batch--paged_append.obj',ROOT/'.scratch/inference-e4-append-implementation-20261025/clean-final/compile/cpu-append'),
 ('src/compute_provider_flashinfer/flashinfer_provider.cc',OLD/'compute_provider_flashinfer--flashinfer_provider.obj',ROOT/'.scratch/inference-layout-storage-native-20261025/host1/flashinfer')]
CPU_OLD=ROOT/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2/native-batch/native-batch.obj'
ARENA_OLD=ROOT/'.scratch/inference-cache-shared-source-20261025/attempt1/arena/unit.obj'
NATIVE=ROOT/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
RUNTIME=ROOT/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json'
FROZEN=[ROOT/'.scratch/inference-layout-storage-native-20261025/host1/source',ROOT/'.scratch/inference-e4-append-implementation-20261025/clean-final/source']
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
def command(p):
 x=read(p);return x['command'] if isinstance(x,dict) else x

def current(p):
 p=Path(p).resolve()
 for prefix in FROZEN:
  try:return ROOT/p.relative_to(prefix)
  except ValueError:pass
 return p

def abi_fields(text,name):
 # Compare actual native C++ records, ignoring only preprocessor line markers/default initializers/whitespace.
 text=re.sub(r'^\s*#.*$','',text,flags=re.M)
 body=re.search(r'struct\s+'+name+r'\s+final\s*\{(.*?)\};',text,re.S).group(1)
 body=re.sub(r'=\s*[^,;]+','',body)
 return re.sub(r'\s+','',body)

def flags(recipe):
 result=[];skip=False
 for word in command(recipe)[1:]:
  if skip:skip=False;continue
  if word=='/sourceDependencies':skip=True;continue
  lower=word.lower()
  if lower.startswith(('/fo','/fd')) or lower.endswith(('.cc','.cpp')):continue
  if lower.replace('\\','/').startswith('/i'+str(ROOT/'.scratch/inference-qwen-static-fp8-20261025/source').lower().replace('\\','/')):continue
  result.append(word)
 return result

def plan(arena,attempt):
 inputs=read(BASE/'actual-link-inputs.json');assert len(inputs)==233
 checked=[];missing=[];old_getters=[]
 for row in inputs:
  p=Path(row['path'])
  if p==BASE/'consumer.obj':continue
  assert p.exists(),p
  actual=pin(p);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],p
  checked.append(actual)
  if p.suffix=='.obj' and b'?schema@BatchLayoutVersion@' in p.read_bytes():old_getters.append(str(p))
 replace={};reuse=[]
 for source,old,folder in SIX:
  obj=folder/'unit.obj';assert obj.exists(),obj
  deps=read(folder/'actual-dependencies.json');count=0
  for dep in deps:
   q=current(dep['path'])
   try:rel=q.relative_to(ROOT)
   except ValueError:continue
   if rel.parts[0] not in ('src','include','engine','tests'):continue
   count+=1;assert pin(q)['sha256']==dep['sha256'],('cached own source/header changed',q)
  assert count>0,folder
  replace[str(old)]=str(obj);reuse.append(dict(source=source,old_object=str(old),object=pin(obj),actual_own_dependencies_matched=count,recipe=pin(folder/'command.json')))
 expected={str(x[1]) for x in SIX}|{str(CPU_OLD)}
 assert set(old_getters)==expected,(old_getters,expected)
 # Existing generated NVCC host text proves the native records already include the current flags/fields.
 pre=ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch/native-batch-portable-llp64-hostrestrict-hostsyntax.cpp'
 header=ROOT/'src/compute_provider_flashinfer/native_batch.h';oldtext=pre.read_text(errors='replace');newtext=header.read_text()
 records={name:dict(equal=abi_fields(oldtext,name)==abi_fields(newtext,name),fields=abi_fields(newtext,name)) for name in ('BatchSpec','BatchFacts')}
 assert all(x['equal'] for x in records.values())
 A=WORK/attempt
 app=A/'app/unit.obj';cpu_obj=A/'cpu-native-batch/unit.obj'
 replace[str(CPU_OLD)]=str(cpu_obj)
 replace[str(BASE/'consumer.obj')]=str(app)
 if arena:
  arena=Path(arena).resolve();assert arena.exists() and arena.suffix=='.obj'
  replace[str(ARENA_OLD)]=str(arena)
 else:replace[str(ARENA_OLD)]='REQUIRED_FRESH_PAGED_ARENA_OBJECT'
 app_recipe=BASE/'compile/command.json';cpu_recipe=CPU_OLD.parent/'command.json'
 compiler=command(app_recipe)[0];assert compiler==command(cpu_recipe)[0]
 builds=[]
 for tag,source,recipe,obj in [('app',WORK/'consumer.cc',app_recipe,app),('cpu-native-batch',ROOT/'src/compute_provider_ggml/native_batch.cc',cpu_recipe,cpu_obj)]:
  folder=A/tag
  argv=[compiler,*flags(recipe),str(source),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(obj),'/Fd'+str(folder/'unit.pdb')]
  assert '/W4' in argv and '/WX' in argv
  builds.append(dict(tag=tag,source=pin(source),recipe=pin(recipe),command=argv))
 old=command(BASE/'link2/command.json');args=[]
 for word in old[1:]:
  if word.lower().startswith(('/out:','/pdb:','/implib:','/map:')):continue
  args.append(replace.get(word,word))
 image=A/'link/e4-cuda.exe'
 link=[old[0],*args,'/OUT:'+str(image),'/IMPLIB:'+str(A/'link/e4-cuda.lib'),'/PDB:'+str(A/'link/e4-cuda.pdb')]
 fixture=ROOT/'.scratch/inference-e4-model-20261025/fixture-preparation/ct-e4-aa'
 own_sources=[ROOT/'engine/models/qwen35/main.cc',ROOT/'engine/models/qwen35/cache_precision.h',ROOT/'engine/models/qwen35/session_state.h',ROOT/'engine/models/qwen35/model_geometry.h',ROOT/'tests/tools/qwen_e4_cache_case.h',ROOT/'src/compute_batch/paged_arena.cc']
 result=dict(status='PLAN_READY_ONLY' if arena else 'PLAN_PENDING_NEW_PAGED_ARENA_OBJECT',executed_build_link_run=False,base_link_recipe=pin(BASE/'link2/command.json'),base_link_inputs=233,verified_existing_inputs=len(checked),expected_old_app_missing=not(BASE/'consumer.obj').exists(),old_getter_object_count=len(old_getters),old_getter_objects=old_getters,reused_replacements=reuse,replacements=replace,new_builds=builds,link_command=link,run_command=[str(image),str(fixture)],current_source_pins=[pin(p) for p in own_sources],native_dll=pin(NATIVE),runtime=pin(RUNTIME),fixture_pins=read(fixture.parent/'fixture-pins.json'),cached_input_pins=checked,native_cuda_records=dict(header=pin(header),old_generated_host=pin(pre),records=records,scope='Current BatchSpec/BatchFacts field ABI equals preserved generated host text; no new CUDA numerical claim; final native cache remains the already used portable-llp64-posenc object, not CPU native_batch.'),arena_object=pin(arena) if arena else None,scope=['Two new host TUs only: thin canonical Model app + original CPU companion native_batch macros','Six exact current cached core/Graph/CUDA-host replacement objects','One additional fresh arena object supplied by ROOT; do not use old plain-only arena','Native CUDA batch, append kernels, vendors, report and all other 224 base inputs retained','No SDK/device TU, third-party rebuild, download, profiling or performance window'])
 save(WORK/'plan.json',result);return result

def execute(argv,folder,env):
 folder.mkdir(parents=True,exist_ok=False);save(folder/'command.json',dict(command=argv,cwd=str(ROOT),timeout_seconds=120));start=time.monotonic()
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
  p=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  try:code=p.wait(timeout=120);timeout=False
  except subprocess.TimeoutExpired:p.kill();code=p.wait();timeout=True
 result=dict(exit=code,seconds=time.monotonic()-start,timeout=timeout);save(folder/'process.json',result)
 if code or timeout:raise SystemExit('First failure retained at '+str(folder))
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('action',nargs='?',choices=['plan','build','run'],default='plan');ap.add_argument('--arena-object');ap.add_argument('--attempt',default='attempt1');a=ap.parse_args()
 assert a.attempt.replace('-','').isalnum()
 if a.action=='run':
  p=read(WORK/'plan.json');A=WORK/a.attempt;assert read(A/'ready.json')['status']=='LINKED_NOT_RUN'
  sys.path.insert(0,str(ROOT/'scripts'));from hyle_environment import discover_environment
  compiler=p['new_builds'][0]['command'][0];env=discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
  env['PATH']=str(A/'link')+';'+read(RUNTIME)['PATH'];env['HF_HUB_OFFLINE']=env['TRANSFORMERS_OFFLINE']='1'
  execute(p['run_command'],A/'run',env);return
 p=plan(a.arena_object,a.attempt);print(p['status'],len(p['new_builds']),'new host TUs; no CUDA SDK/device rebuild')
 if a.action=='plan':return
 assert p['status']=='PLAN_READY_ONLY','ROOT must supply its actual fresh E4-capable arena object'
 sys.path.insert(0,str(ROOT/'scripts'));from hyle_environment import discover_environment
 compiler=p['new_builds'][0]['command'][0];env=discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
 A=WORK/a.attempt
 for job in p['new_builds']:execute(job['command'],A/job['tag'],env)
 execute(p['link_command'],A/'link',env)
 for s in p['current_source_pins']:assert pin(Path(s['path']))==s,('Source changed during build',s['path'])
 image=A/'link/e4-cuda.exe';os.link(NATIVE,image.parent/NATIVE.name)
 save(A/'ready.json',dict(status='LINKED_NOT_RUN',image=pin(image),source_pins=p['current_source_pins'],native=pin(NATIVE),scope=p['scope']))
if __name__=='__main__':main()
