# Finite E4 CUDA Model reuse plan (not executed)

Default command only verifies source/cache metadata. Product files were read, not changed. No compiler, linker, CUDA process, SDK/device build or HTTP was started.

## Exact chain

`runner.py plan --arena-object .scratch/inference-e4-model-20261025/cpu2/compile-arena/unit.obj` passed. It preserves the original static-FP8 CUDA link2 command and all 233 logical OBJ/LIB inputs, replacing exactly 9 entries (224 retained). The sole absent original input is the deliberately cleaned old consumer OBJ; it is replaced, not reconstructed. `plan.json` contains exact compile/link/run argv and all 232 existing input hashes, source/header pins, native/runtime and fixture pins. No original model-value payload is needed by this wiring fixture.

1. Compile new thin consumer.cc: include canonical Qwen main + formal qwen_e4_cache_case.h; call run(input,{.primary=kCuda}). Preserve original `/std:c++latest /O2 /MD /W4 /WX`, `/DGGML_USE_CUDA /DHYLE_COMPUTE_CUDA=1 /DHYLE_COMPUTE_GGML_CUDA=1`, CUDA13.3 include and current MSVC14.50 toolchain. Only the original private source include path and old app/output args are removed.
2. Compile current `src/compute_provider_ggml/native_batch.cc` as the CPU companion under its OWN original strict host flags, notably `HYLE_COMPUTE_GGML_CPU=1`, `HYLE_GGML_CPU_IQ1_EXTENSIONS=1`, `HYLE_GGML_CPU_F32_FLASH=1`, and provider version `hadamard-unary-overlay`. This preserves the original linked gdn_scale_v3 native DLL identity. Do not substitute a CUDA kernel with this CPU object or silently take the newer ffa4 CPU provider identity.
3. Reuse six already-compiled matching objects: batch_layout; graph_batch batch/native_batch_regions/native_paged_node; final E4-enabled graph paged_append; CUDA-macro FlashInfer host provider. Each cached actual project dependency was mapped to current canonical source and byte-hash checked. The only mismatch is ROOT's newly changed paged_arena.h contract COMMENT; stripped declaration text is identical, and exact preserved/current hashes are recorded.
4. Replace the old arena object with ROOT cpu2 `compile-arena/unit.obj` (SHA a11c14ed9e42a6e6d9392543c29792070eec2728d9f45c6ca3661a1cbfdaa173). It contains the actual E4 appendable publication fix. This common Core object has no CUDA/CPU provider dispatch identity.
5. Original linker + retained report, CUDA providers/kernels, CPU/native companions, vendors and system libraries. Hardlink the original `hyle_ggml_cpu_gdn_scale_v3.dll` beside the EXE and reuse ready-cuda.json runtime PATH. ROOT controls the GPU grant before the separate run command.

## Old getter and ABI coverage

Raw COFF string/symbol-marker scan found exactly seven old BatchLayoutVersion::schema objects: layout, CPU native_batch, four Graph objects above and FlashInfer host. All seven are replaced. The actual layout/schema public handles remain opaque pointer owners; A+B added no public wrapper data layout. The private AppendStorageBinding added CacheStorage and has only batch.cc/paged_append.cc consumers; both replaced objects were compiled together against that field.

Unchanged batch_execution, native_paged_program, paged_append_program and the raw16 CUDA append bridge contain no old Layout getter. They keep their original opaque schema/layout handles and actual recipe CacheStorage; the new out-of-line schema domain/owns implementation comes from refreshed batch_layout. The CUDA raw16 writer needs even row bytes; this fixture's E4 row is 64 bytes. No claim is made for odd CUDA row sizes.

The actual CUDA device batch remains `windows-batch/native-batch-portable-llp64-posenc.obj`, not the CPU companion. Its preserved generated NVCC host text contains exactly the current BatchSpec and BatchFacts field declarations, including allow_bf16_partials and bf16_partials (native-abi-excerpt.txt and plan.json normalized field equality). Original sm_89/CUDA13.3/NVCC command, native OBJ identity and current header are pinned. This is a field ABI check using prior native cache evidence, not a new device math test or a reconstructed full original sourceDependency list.

The model helper executes the same AA/H64/D64 CT/E4 preparation fixture as ROOT's CPU test: 4 real calibration roles with distinct layer/K/V scales, prefill T2, decode T1, retained old reader, equal fork and zero final versions. It is a generated wiring/state fixture, not trained-model quality, BF16-vs-E4 numerical equivalence or complete model support certification. Its existing assertions/report are unchanged.

## ROOT commands

```powershell
python .scratch/inference-e4-model-20261025/cuda-plan/runner.py plan --arena-object .scratch/inference-e4-model-20261025/cpu2/compile-arena/unit.obj
python .scratch/inference-e4-model-20261025/cuda-plan/runner.py build --arena-object .scratch/inference-e4-model-20261025/cpu2/compile-arena/unit.obj --attempt attempt1
# Only after ROOT grants GPU; build does not run:
python .scratch/inference-e4-model-20261025/cuda-plan/runner.py run --attempt attempt1
```

Use a fresh attempt name after any real failure; preserve first source/cmd/raw. Each compiler/linker/model process has a120s watchdog. Build captures actual sourceDependencies and checks canonical main/helper consumed plus source stability. No automatic model retry, new fixture, device rebuild or fallback is implemented. A first metadata-only dry run encountered ROOT's simultaneous doc-comment edit; planning-first-failure.py/json retain it, followed by the exact comment-only normalization proof. Nothing executed on GPU in this preparation.
