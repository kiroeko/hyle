#include "tests/compute_models/paged_e4_kv_fixture.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/compute/detail/paged_arena_access.h"
#include "hyle/graph/apple.h"

namespace {
namespace f = paged_e4_kv_test;
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace gb = hyle::graph::batch;
namespace a = hyle::compute::apple;
using f::take;
using f::check;

TEST(AppleE4Appendable, EncodesAppendsAndKeepsBoundedOldReader) {
  std::string_view phase = "native context";
  try {
    auto context = take(a::Context::create(), "Apple context");
    RecordProperty("device", context.environment()->device_name);
    auto memory = take(a::MemoryResource::create(context), "Apple shared memory");
    const auto resource = memory.ref();
    const std::array limits{c::ResourceBudgetLimit{resource, 1u << 20}};
    auto budget = take(c::ResourceBudget::create({.limits = limits}), "arena budget");
    std::array<c::ReadLease, 2> escaped_old;
    std::array<std::array<std::uint8_t, 64>, 2> original_bytes{};
    {
      constexpr std::size_t depth = 64;
      const auto plain = take(c::CacheStorage::plain(c::DataType::kBFloat16), "plain BF16");
      const c::BatchCapacity cap{
          .query_type = c::DataType::kBFloat16, .output_type = c::DataType::kBFloat16,
          .key_storage = plain, .value_storage = plain, .max_requests = 1,
          .max_query_rows = 1, .max_kv_rows = 4, .max_pages = 2, .max_page_refs = 1,
          .query_heads = 2, .kv_heads = 1, .qk_head_dim = 64, .value_head_dim = 64,
          .page_size = 4};
      const auto root = take(c::BatchSchema::create(cap), "root schema");
      const std::array scales{.5F, 2.F};
      const std::array storage{take(c::CacheStorage::float8(scales[0]), "K storage"),
                               take(c::CacheStorage::float8(scales[1]), "V storage")};
      const auto schema = take(root.with_cache_storage(storage[0], storage[1]), "E4 schema");
      const std::array<std::int32_t, 2> query_ptr{0, 1}, page_ptr{0, 1};
      const std::array<std::int32_t, 1> page_id{0}, old_tail{1}, next_tail{2};
      const auto before = take(root.version({query_ptr, page_ptr, page_id, old_tail}), "old layout");
      const auto after = take(root.version({query_ptr, page_ptr, page_id, next_tail}), "new layout");
      std::array<c::PagedArena, 2> arenas;
      std::array<c::PagedArenaRead, 2> previous;
      std::array<gb::PagedAppendPages, 2> pending;
      std::array<std::array<std::uint16_t, depth>, 2> incoming{};
      std::array<std::array<std::uint8_t, depth * 2>, 2> expected{};
      phase = "actual E4 appendable publication";
      for (std::size_t role = 0; role < 2; ++role) {
        arenas[role] = take(c::PagedArena::create(schema,
            role ? c::BatchCacheRole::kValue : c::BatchCacheRole::kKey, resource,
            {.max_backing_bytes = 4096, .resource_budget = budget}), "arena");
        ASSERT_EQ(arenas[role].page_bytes(), 256u);
        auto writer = take(arenas[role].acquire(0), "initial page");
        std::array<std::uint8_t, 256> page;
        page.fill(0x7f); // Uninitialized suffix is never a readable attention row.
        for (std::size_t d = 0; d < depth; ++d) {
          const auto first = f::scalar::bf16(float(int(d % 5) - 2) * .125F + (role ? .25F : -.5F));
          incoming[role][d] = f::scalar::bf16(float(int(d % 7) - 3) * .25F + (role ? .75F : -.25F));
          expected[role][d] = f::encode(f::scalar::wide(first), scales[role]);
          expected[role][depth + d] = f::encode(f::scalar::wide(incoming[role][d]), scales[role]);
          page[d] = original_bytes[role][d] = expected[role][d];
        }
        check(take(writer.lease().view(), "initial page view").write(std::as_bytes(std::span(page))), "initialize page");
        auto published = take(writer.publish_appendable(1), "publish one E4 row");
        ASSERT_EQ(published.prefix.size(), depth);
        escaped_old[role] = published.prefix;
        previous[role] = take(arenas[role].read(before, std::span(&published.prefix, 1)), "old frame");
        EXPECT_FALSE(arenas[role].read(after, std::span(&published.prefix, 1))) << "Old one-row permission must not widen";
        std::array<c::PagedPageAppender, 1> tail{std::move(published.appender)};
        check(tail[0].reserve_rows(1), "reserve one exact E4 suffix row");
        ASSERT_EQ(take(tail[0].view(), "reserved row").size(), depth);
        pending[role] = take(gb::PagedAppendPages::create(arenas[role], after, previous[role],
            std::span<c::PagedPageWriter>{}, tail), "append transaction");
        EXPECT_FALSE(pending[role].ready()) << "No ready state before successful native completion";
      }
      ASSERT_EQ(take(budget.usage(resource), "live arena bytes").live_bytes, 1026u);

      phase = "native encode append reader graph";
      auto builder = take(g::GraphBuilder::create(), "builder");
      const auto rows_desc = take(c::TensorDesc::dense(c::DataType::kBFloat16,
          std::array<std::int64_t, 3>{1, 1, 64}), "BF16 input row");
      const auto qdesc = take(c::batch_query_description(schema.capacity(), 1), "query description");
      const auto q = take(builder.input(qdesc), "query");
      std::array<g::ValueId, 2> row_inputs, bank_inputs;
      std::array<g::NodeId, 2> writers;
      for (std::size_t role = 0; role < 2; ++role) {
        row_inputs[role] = take(builder.input(rows_desc), "incoming row");
        const auto encoded = take(builder.add(c::Operation::custom(c::model_ops::CacheEncode{storage[role]}),
            row_inputs[role]), "native CacheEncode");
        writers[role] = take(builder.add_node(c::Operation::custom(take(gb::paged_append(schema,
            role ? c::BatchCacheRole::kValue : c::BatchCacheRole::kKey), "typed append")),
            std::array{encoded}), "append node");
        bank_inputs[role] = take(builder.input(take(c::batch_cache_description(schema,
            role ? c::BatchCacheRole::kValue : c::BatchCacheRole::kKey), "bank description")), "bank port");
      }
      check(builder.depends_on(writers[1], writers[0]), "ordered append effects");
      const auto attention = take(gb::paged_attention(after, {.scale = .125F, .causal = true}), "native reader");
      const auto reader = take(builder.add_node(c::Operation::custom(attention),
          std::array{q, bank_inputs[0], bank_inputs[1]}), "reader node");
      for (const auto writer : writers) check(builder.depends_on(reader, writer), "write before read");
      const auto out = take(builder.result(reader), "reader result");
      check(builder.publish(out), "publish output");
      auto graph = take(std::move(builder).finish(), "graph");
      const std::array domains{g::StorageDomain{resource}};
      const std::array targets{g::ExecutionTarget{
          take(g::apple::execution_source(context), "native Apple source"), g::StorageDomainId{0}}};
      auto compiled = take(gb::compile(graph, {domains, targets}), "native compile");
      ASSERT_EQ(compiled.report.target_count(), 1u);
      EXPECT_EQ(compiled.report.target(0)->device_class, c::DeviceClass::kGpu);
      EXPECT_EQ(compiled.report.copy_bytes(), 0u);
      RecordProperty("target", "original Apple native Context, no CPU lane");
      RecordProperty("step_count", static_cast<int>(compiled.report.step_count()));
      auto invocation = take(compiled.executable.create_invocation({.resources = g::ResourceOptions{}}), "invocation");
      const std::span<const g::QueueBinding> queues;
      check(gb::prepare(invocation, queues, std::array{gb::NodeLayout{reader, after}},
          {.host_workspace = hyle::mem::system_resource(), .max_float_workspace_bytes = 1u << 20,
           .max_int_workspace_bytes = 64u << 10}), "native batch prepare");
      for (std::size_t role = 0; role < 2; ++role)
        check(gb::bind_append(invocation, graph, writers[role], bank_inputs[role], std::move(pending[role])), "bind original tail");
      auto io = take(c::LeasePool::create(resource, 2048, {.max_blocks = 8}), "IO pool");
      const auto load = [&](std::span<const std::uint16_t> words) {
        auto writer = take(io.allocate(words.size_bytes(), 64), "IO writer");
        check(take(writer.view(), "IO view").write(std::as_bytes(words)), "IO upload");
        return take(writer.publish(), "IO readonly");
      };
      const std::array<std::uint16_t, 128> zeros{};
      check(invocation.bind(q, qdesc, load(zeros)), "bind zero Q");
      for (std::size_t role = 0; role < 2; ++role)
        check(invocation.bind(row_inputs[role], rows_desc, load(incoming[role])), "bind BF16 row");
      const auto out_desc = take(c::batch_output_description(schema.capacity(), 1), "output description");
      if (take(compiled.executable.output_ownership(), "output ownership") == g::OutputOwnership::kCaller)
        check(invocation.bind(out, out_desc, take(io.allocate(take(out_desc.required_bytes(), "output bytes"), 64), "output writer")), "bind output");
      check(invocation.prepare_replay(queues), "prepare native replay");
      phase = "native submit retirement and independent numerical checks";
      auto done = take(invocation.submit(queues), "native submit");
      check(done.wait(), "real native completion");
      done = {};
      {
        auto output = take(take(invocation.result(out), "result").storage_lease(), "output lease");
        std::array<std::uint16_t, 128> actual{};
        check(take(output.view(), "output view").read(std::as_writable_bytes(std::span(actual))), "read output");
        for (std::size_t i = 0; i < actual.size(); ++i) {
          const auto d = i % depth;
          const double mean = (double(f::scalar::e4m3(expected[1][d])) +
              double(f::scalar::e4m3(expected[1][depth + d]))) * double(scales[1]) * .5;
          const auto value = f::scalar::rounded_bf16(static_cast<float>(mean));
          ASSERT_TRUE(std::isfinite(f::scalar::wide(actual[i])));
          EXPECT_EQ(f::scalar::wide(actual[i]), value) << "attention lane " << i;
        }
      }
      for (std::size_t role = 0; role < 2; ++role) {
        auto returned = take(gb::take_append(invocation, writers[role]), "take retired original append");
        const auto ready = take(returned.ready(), "publish successful ready prefix");
        EXPECT_EQ(ready.layout(), after);
        EXPECT_EQ(ready.page_count(), 1u);
        EXPECT_EQ(returned.page_count(), 0u) << "In-place append must not allocate a COW page";
        ASSERT_EQ(returned.appender_count(), 1u);
        auto tail_result = returned.appender(0);
        ASSERT_TRUE(tail_result) << tail_result.error().message();
        auto &tail = *tail_result;
        EXPECT_EQ(tail.page(), 0u);
        EXPECT_EQ(tail.initialized_rows(), 2u);
        EXPECT_EQ(tail.reserved_rows(), 0u);
        const auto guarded = c::detail::PagedArenaAccess::pages(ready);
        ASSERT_EQ(guarded.size(), 1u);
        ASSERT_EQ(guarded[0].size(), 128u);
        std::array<std::uint8_t, 128> actual{};
        check(take(guarded[0].view(), "ready bounded view").read(std::as_writable_bytes(std::span(actual))), "read exact committed bytes");
        EXPECT_EQ(actual, expected[role]) << "Independent E4 code enumeration, K/V scale " << role;
        std::array<std::uint8_t, 64> old{};
        check(take(escaped_old[role].view(), "old prefix view").read(std::as_writable_bytes(std::span(old))), "read retained old prefix");
        EXPECT_EQ(old, original_bytes[role]);
        EXPECT_EQ(escaped_old[role].size(), 64u);
        EXPECT_FALSE(arenas[role].read(after, std::span(&escaped_old[role], 1)));
        EXPECT_FALSE(arenas[role].acquire(0)) << "Escaped readers and original tail still own the page";
      }
      auto stale_submit = invocation.submit(queues);
      EXPECT_FALSE(stale_submit) << "Taking append transactions must revoke old preparation";
      if (stale_submit) stale_submit->wait().IgnoreError();
      check(invocation.close(), "close retired invocation");
      RecordProperty("encoded_bytes_checked", 256);
      RecordProperty("bounded_old_bytes_checked", 128);
      RecordProperty("native_copy_alignment_bytes", 4);
    }
    phase = "original backing retained until last old reader";
    EXPECT_EQ(take(budget.usage(resource), "escaped-reader usage").live_bytes, 1026u);
    for (std::size_t role = 0; role < 2; ++role) {
      std::array<std::uint8_t, 64> actual{};
      check(take(escaped_old[role].view(), "escaped view").read(std::as_writable_bytes(std::span(actual))), "read after Graph/arena teardown");
      EXPECT_EQ(actual, original_bytes[role]);
    }
    escaped_old = {};
    EXPECT_EQ(take(budget.usage(resource), "retired budget usage").live_bytes, 0u);
    check(context.close(), "native Context retirement");
  } catch (const std::exception &error) {
    FAIL() << phase << ": " << error.what();
  }
}
} // namespace
