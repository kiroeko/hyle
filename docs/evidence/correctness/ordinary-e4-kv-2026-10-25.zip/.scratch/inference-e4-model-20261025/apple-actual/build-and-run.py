import hashlib
import json
import pathlib
import shlex
import subprocess
import sys
import time

ROOT = pathlib.Path('/Users/kiro/hyle/.scratch/inference-e4-appendable-20261025')
OLD = pathlib.Path('/Users/kiro/hyle/.scratch/inference-layout-storage-20261025')

def digest(path):
    p = pathlib.Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def command(argv, destination, timeout=120):
    destination.mkdir(parents=True, exist_ok=True)
    save(destination / 'command.json', {'command': argv, 'cwd': str(ROOT)})
    started = time.perf_counter()
    with (destination / 'stdout.log').open('wb') as out, (destination / 'stderr.log').open('wb') as err:
        try:
            p = subprocess.run(argv, cwd=ROOT, stdout=out, stderr=err, timeout=timeout)
            result = {'exit_code': p.returncode, 'wall_seconds': time.perf_counter() - started}
        except subprocess.TimeoutExpired:
            result = {'exit_code': None, 'timed_out': True, 'wall_seconds': time.perf_counter() - started}
    save(destination / 'process.json', result)
    print(str(destination.relative_to(ROOT)), json.dumps(result), flush=True)
    if result['exit_code'] != 0:
        sys.exit(1)
    return result

if sys.argv[1] in ('build', 'resume-consumer'):
    pins = json.loads((ROOT / 'source-pins.json').read_text())
    for pin in pins:
        actual = digest(ROOT / 'source' / pin['path'])
        assert (pin['bytes'], pin['sha256']) == (actual['bytes'], actual['sha256'])
    old_plan = json.loads((ROOT / 'old-consumer-plan.json').read_text())
    flags = ['-I' + str(ROOT / 'source/include'), '-I' + str(ROOT / 'source'),
             '-I' + str(OLD / 'source/include'), '-I' + str(OLD / 'source'),
             '-I' + str(OLD / 'source/src/graph_batch'), '-I' + str(OLD / 'source/src/compute'),
             '-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64',
             '-isysroot', '/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk',
             '-mmacosx-version-min=14.4', '-Wall', '-Wextra', '-Wpedantic', '-Werror', '-DHYLE_STATIC']
    units = [
        ('budget', 'src/compute/resource_budget.cc', 'HYLE_COMPUTE_BUILD'),
        ('leases', 'src/compute/resource_leases.cc', 'HYLE_COMPUTE_BUILD'),
        ('arena', 'src/compute_batch/paged_arena.cc', 'HYLE_COMPUTE_BATCH_BUILD'),
        ('append', 'src/graph_batch/paged_append.cc', 'HYLE_GRAPH_BATCH_BUILD')]
    deps = {}
    compiled = {}
    for name, source, definition in units:
        directory = ROOT / 'compile' / name
        obj, dep = directory / 'unit.o', directory / 'unit.d'
        argv = ['/usr/bin/c++', *flags, '-D' + definition, '-MMD', '-MF', str(dep),
                '-c', str(ROOT / 'source' / source), '-o', str(obj)]
        if sys.argv[1] == 'build':
            command(argv, directory)
        compiled[name] = str(obj)
        save(directory / 'object.json', digest(obj))
    directory = ROOT / ('compile/consumer' if sys.argv[1] == 'build' else 'compile/consumer5')
    app_command = old_plan['compile'][:]
    app_command[1:1] = ['-I' + str(ROOT / 'source/include'), '-I' + str(ROOT / 'source')]
    app_command[app_command.index('-MF') + 1] = str(directory / 'unit.d')
    app_command[app_command.index('-c') + 1] = str(ROOT / 'source/apple_e4_appendable_test.cc')
    app_command[app_command.index('-o') + 1] = str(directory / 'unit.o')
    command(app_command, directory)
    compiled['consumer'] = str(directory / 'unit.o')
    save(directory / 'object.json', digest(directory / 'unit.o'))
    for directory in (ROOT / 'compile').iterdir():
        dep = directory / 'unit.d'
        if not dep.exists():
            continue
        words = shlex.split(dep.read_text().replace('\\\n', ' ').split(':', 1)[1])
        for path in words:
            if path.startswith(str(ROOT / 'source')) or path.startswith(str(OLD / 'source')):
                deps[path] = digest(path)
    save(ROOT / 'actual-source-dependencies.json', list(deps.values()))
    core = '/Users/kiro/hyle-scratch/compute-unified/qwen-k1-functional-20261024/attempt1/objects/'
    replacement = {
        old_plan['link'][1]: compiled['consumer'],
        core + 'src--compute--resource_budget.cc.o': compiled['budget'],
        core + 'src--compute--resource_leases.cc.o': compiled['leases'],
        core + 'src--compute_batch--paged_arena.cc.o': compiled['arena'],
        old_plan['link'][6]: compiled['append']}
    link = [replacement.get(arg, arg) for arg in old_plan['link']]
    link[link.index('-o') + 1] = str(ROOT / 'apple-e4-appendable')
    link = [('-Wl,-map,' + str(ROOT / 'apple-e4-appendable.map'))
            if arg.startswith('-Wl,-map,') else arg for arg in link]
    inputs = [digest(arg) for arg in link if pathlib.Path(arg).is_file() and
              (arg.endswith('.o') or arg.endswith('.a') or arg.endswith('.dylib'))]
    save(ROOT / 'object-map.json', {'replacement': replacement, 'inputs': inputs})
    command(link, ROOT / 'link4')
    save(ROOT / 'image.json', digest(ROOT / 'apple-e4-appendable'))
    save(ROOT / 'build-summary.json', {'status': 'READY', 'units': compiled,
                                      'dependency_count': len(deps), 'link_input_count': len(inputs)})
elif sys.argv[1] == 'run':
    command([str(ROOT / 'apple-e4-appendable'),
             '--gtest_filter=AppleE4Appendable.EncodesAppendsAndKeepsBoundedOldReader',
             '--gtest_output=xml:' + str(ROOT / 'run4/results.xml')], ROOT / 'run4')
else:
    raise SystemExit('expected build or run')
