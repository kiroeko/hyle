from pathlib import Path
import hashlib
import json

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
changes=[]
base=ROOT/'.scratch/inference-cache-precision-20261025/role-policy'
before={d['path']:d for d in read(base/'before-pins.json')['files']}
for p in read(base/'after-pins.json')['files']:
    changes.append((p['path'],(base/'source'/p['path']).read_bytes(),before[p['path']]['sha256'],p['sha256']))
base=ROOT/'.scratch/inference-cache-row-bytes-20261025'
for p in read(base/'source-pins.json')['products']:
    changes.append((p['path'],(base/p['after']['path']).read_bytes(),p['before']['sha256'] if p['before'] else None,p['after']['sha256']))
for p in read(WORK/'source-pins.json')['files']:
    changes.append((p['path'],(WORK/'source'/p['path']).read_bytes(),p['before'],p['after']))
assert len(changes)==29 and len({p for p,_,_,_ in changes})==29
for name,body,before,after in changes:
    path=ROOT/name
    assert (sha(path.read_bytes())==before if before else not path.exists()),name
    assert sha(body)==after,name
for name,body,_,_ in changes:(ROOT/name).write_bytes(body)
(WORK/'integrated-pins.json').write_text(json.dumps(dict(files=[dict(path=p,before=b,after=a,bytes=len(body)) for p,body,b,a in changes]),indent=2)+'\n')
print('INTEGRATED_29_SOURCE_FILES')
