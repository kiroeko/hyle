#include "source/engine/models/qwen35/main.cc"
#include "source/tests/tools/qwen_e4_cache_case.h"
#include "source/tests/tools/qwen_sampling_budget_case.h"
int main(int argc,char **argv){try{if(argc!=3)throw std::runtime_error("e4-consumer e4|default INPUTS");if(std::string_view(argv[1])=="default")return qwen_sampling_budget_case::run(argv[2]);return qwen_e4_cache_case::run(argv[2]);}catch(const std::exception &e){std::cerr<<"e4_consumer_failure="<<e.what()<<"\n";return 1;}}
