from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time
sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import discover_environment
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2)+'\n', encoding='utf-8')
def pin(path):
    data=path.read_bytes(); return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def execute(args, env, folder, timeout=120):
    folder.mkdir(parents=True, exist_ok=False)
    save(folder/'command.json',dict(command=args,cwd=str(ROOT),timeout_seconds=timeout))
    start=time.monotonic()
    with (folder/'stdout.log').open('wb') as out, (folder/'stderr.log').open('wb') as err:
        process=subprocess.Popen(args,cwd=ROOT,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder/'running.json',dict(pid=process.pid));print('START',folder.name,process.pid,flush=True)
        try: code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired: process.kill();process.wait();code=-999
    result=dict(pid=process.pid,exit=code,seconds=round(time.monotonic()-start,3));save(folder/'process.json',result)
    print('END',folder.name,result,flush=True)
    if code:
        print((folder/'stdout.log').read_text(errors='replace')[-13000:],flush=True)
        print((folder/'stderr.log').read_text(errors='replace')[-6000:],flush=True)
        raise RuntimeError('actual stage failed; original raw retained: '+str(folder))
    return result
def main():
    attempt=WORK/(sys.argv[1] if len(sys.argv)>1 else 'cpu1')
    assert not attempt.exists()
    # Freeze just the real quoted include closure, never a full source/SDK copy.
    tree=attempt/'source'; queue=['engine/models/qwen35/main.cc','tests/tools/qwen_e4_cache_case.h','tests/tools/qwen_sampling_budget_case.h']
    dirs=[ROOT/'include',ROOT,ROOT/'engine',ROOT/'tests/tools',ROOT/'engine/models/qwen35']
    seen=set();frozen=[]
    while queue:
        name=queue.pop()
        if name in seen: continue
        seen.add(name);src=ROOT/name;data=src.read_bytes();dst=tree/name
        dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
        frozen.append(dict(relative=name,original=pin(src),frozen=pin(dst)))
        for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode('utf-8-sig'),re.M):
            for base in [src.parent,*dirs]:
                child=(base/inc).resolve()
                if child.is_file() and child.is_relative_to(ROOT): queue.append(child.relative_to(ROOT).as_posix());break
    save(attempt/'frozen-source.json',frozen)
    consumer=attempt/'consumer.cc'
    consumer.write_text('#include "source/engine/models/qwen35/main.cc"\n#include "source/tests/tools/qwen_e4_cache_case.h"\n#include "source/tests/tools/qwen_sampling_budget_case.h"\n'
        'int main(int argc,char **argv){try{if(argc!=3)throw std::runtime_error("e4-consumer e4|default INPUTS");'
        'if(std::string_view(argv[1])=="default")return qwen_sampling_budget_case::run(argv[2]);'
        'return qwen_e4_cache_case::run(argv[2]);}catch(const std::exception &e){std::cerr<<"e4_consumer_failure="<<e.what()<<"\\n";return 1;}}\n',encoding='utf-8')
    recipe=read(ROOT/'.scratch/inference-assembly-placement-20261025/consumer1/compile/command.json')['command']
    compiler=recipe[0];flags=[];skip=False
    for arg in recipe[1:]:
        if skip:skip=False;continue
        if arg=='/sourceDependencies':skip=True;continue
        if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
        if 'inference-assembly-placement-20261025' in arg:continue
        flags.append(arg)
    flags=['/I'+str(tree/'include'),'/I'+str(tree),*flags]
    assert '/W4' in flags and '/WX' in flags
    env=discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
    obj=attempt/'compile/unit.obj';image=attempt/'link/component.exe'
    build=execute([compiler,*flags,str(consumer),'/sourceDependencies',str(attempt/'compile/dependencies.json'),'/Fo'+str(obj),'/Fd'+str(attempt/'compile/unit.pdb')],env,attempt/'compile')
    deps=read(attempt/'compile/dependencies.json')['Data'];paths=[Path(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]
    assert not any(p.is_relative_to(ROOT/'engine') or p.is_relative_to(ROOT/'tests') or p.is_relative_to(ROOT/'include') for p in paths)
    save(attempt/'actual-dependencies.json',[pin(p) for p in paths])
    previous=read(ROOT/'.scratch/inference-layout-storage-validation-20261025/cpu1/ordinary-link/command.json')['command']
    old_app=ROOT/'.scratch/inference-assembly-placement-20261025/consumer1/compile/unit.obj'
    old_append=ROOT/'.scratch/inference-layout-storage-validation-20261025/cpu1/compile/graph_batch--paged_append/unit.obj'
    new_append=ROOT/'.scratch/inference-e4-append-implementation-20261025/clean-final/compile/cpu-append/unit.obj'
    replaced=[];command=[]
    for arg in previous:
        if arg.lower().startswith(('/out:','/pdb:','/implib:','/map:')):continue
        if arg==str(old_app):replaced.append(dict(before=arg,after=str(obj)));arg=str(obj)
        if arg==str(old_append):replaced.append(dict(before=arg,after=str(new_append)));arg=str(new_append)
        command.append(arg)
    assert len(replaced)==2,replaced
    inputs=[pin(Path(arg)) for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
    save(attempt/'link-inputs.json',dict(inputs=inputs,replaced=replaced))
    command+=['/OUT:'+str(image),'/PDB:'+str(attempt/'link/component.pdb'),'/IMPLIB:'+str(attempt/'link/component.lib')]
    link=execute(command,env,attempt/'link',90)
    native=ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
    os.link(native,image.parent/native.name)
    runtime=read(ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')
    run_env=dict(env);run_env['PATH']=str(image.parent)+';'+runtime['PATH'];run_env['HF_HUB_OFFLINE']=run_env['TRANSFORMERS_OFFLINE']='1'
    default=execute([str(image),'default',str(WORK/'fixture-preparation/bf16-original')],run_env,attempt/'run-default')
    e4=execute([str(image),'e4',str(WORK/'fixture-preparation/ct-e4-aa')],run_env,attempt/'run-e4')
    for item in frozen:assert pin(Path(item['original']['path']))==item['original']
    save(attempt/'summary.json',dict(status='FINITE_ACTUAL_CPU_DEFAULT_AND_E4_PASS',compile=build,link=link,default=default,E4=e4,native=pin(native),frozen_files=len(frozen),dependencies=len(paths),absolute_link_inputs=len(inputs),SDK_rebuilt=False,HTTP=0,quality=False,CUDA=False))
if __name__=='__main__':main()
