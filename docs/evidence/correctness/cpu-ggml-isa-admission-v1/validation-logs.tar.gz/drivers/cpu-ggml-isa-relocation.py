exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
import os
for stage in ('static','shared'):
    prefix=Path('C:/hv/cpu-ggml-isa-'+stage+'-sdk').resolve()
    moved=Path(str(prefix)+'-moved').resolve()
    boundary=Path('C:/hv').resolve()
    assert prefix.parent==boundary and moved.parent==boundary
    assert prefix.is_dir() and not prefix.is_symlink() and not moved.exists()
    assert (prefix/'lib/cmake/Hyle/HyleConfig.cmake').is_file()
    installed=Path('C:/hv/cpu-ggml-isa-'+stage+'-installed')
    try:
        # Exact named disposable SDKs only; no directory enumeration is used to
        # decide what is moved and no content is edited while moved.
        os.rename(prefix,moved)
        run(stage+'-relocated-configure',['cmake','-S',out.parent/'consumer','-B',installed,'-UHyle_DIR','-DCMAKE_PREFIX_PATH='+str(moved),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
        run(stage+'-relocated-build',['cmake','--build',installed,'--target','cpu_program_consumer','--parallel','2'])
        run(stage+'-relocated-public-f16',[installed/'cpu_program_consumer.exe'])
        scripts=list(installed.glob('hyle-runtime/*.cmake'))
        assert scripts and any(moved.as_posix() in p.read_text(encoding='utf-8') for p in scripts)
    finally:
        assert moved.parent==boundary and not prefix.exists()
        os.rename(moved,prefix)
    run(stage+'-restored-configure',['cmake','-S',out.parent/'consumer','-B',installed,'-UHyle_DIR','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
