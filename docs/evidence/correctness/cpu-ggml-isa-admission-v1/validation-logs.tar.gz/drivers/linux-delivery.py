import hashlib,json,os,subprocess,sys,time
from pathlib import Path
repo=Path('/mnt/c/public/project-hyle/hyle')
out=repo/'.scratch/validation/cpu-ggml-isa-admission/linux'
out.mkdir(exist_ok=True)
manifest=json.loads((out.parent/'linux-source-manifest.json').read_text())
source=Path('/root/hyle-scratch/active-cpu-z/source').resolve()
assert source.is_relative_to(Path('/root/hyle-scratch/active-cpu-z').resolve()) and source.is_dir()
for name,sha in manifest['files'].items():
    data=(repo/name).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,name
    dest=(source/name).resolve();assert dest.is_relative_to(source)
    if not dest.exists() or dest.read_bytes()!=data:dest.write_bytes(data)
build=source.parent/'build'
os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
os.environ.pop('LD_LIBRARY_PATH',None)
receipt=out/'receipt.json'
records=json.loads(receipt.read_text()) if receipt.exists() else []
def run(name,args):
    start=time.monotonic();path=out/(str(len(records)+1)+'-'+name+'.log')
    with path.open('wb') as log:r=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=list(map(str,args)),candidate=manifest['candidate'],log=path.name,returncode=r.returncode,seconds=round(time.monotonic()-start,3)))
    receipt.write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
    if r.returncode:
        print(path.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(r.returncode)
overlay=out.parent/'linux-overlay.cmake'
if '--resume-build' not in sys.argv:
    run('cpu-runtime-provider-configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_STATIC=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(overlay)])
run('cpu-runtime-provider-build',['cmake','--build',build,'--target','hyle_compute_ggml_runtime_tests','hyle_compute_provider_ggml_tests','cpu_program_consumer','--parallel','2'])
run('cpu-runtime-provider-tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-L','^(compute_ggml_runtime|compute_provider_ggml)$','-LE','headers','-j','1','--output-junit',out/'tests.xml'])
run('static-source-public-f16',[build/'bin/cpu_program_consumer'])
# Delivery switches only after correctness; keep the same qualified producer.
for stage in ('static','shared'):
    prefix=Path('/root/hyle-scratch/cpu-ggml-isa-delivery')/stage
    run(stage+'-producer-configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if stage=='static' else 'OFF'),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(stage+'-producer-build',['cmake','--build',build,'--target','cpu_program_consumer','hyle_time','--parallel','2'])
    run(stage+'-source-public-f16',[build/'bin/cpu_program_consumer'])
    run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
    consumer=prefix.parent/(stage+'-consumer')
    run(stage+'-consumer-configure',['cmake','-S',out.parent/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
    run(stage+'-installed-public-f16',[consumer/'cpu_program_consumer'])
