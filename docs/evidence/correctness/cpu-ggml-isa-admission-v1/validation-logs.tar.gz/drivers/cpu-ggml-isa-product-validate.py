exec(open('.scratch/cpu-ggml-isa-probe.py',encoding='utf-8').read().split('records=[]')[0])
out=repo/'.scratch/validation/cpu-ggml-isa-admission/product'
out.mkdir(exist_ok=True)
build=repo/'.scratch/build-compute-v2-dev'
env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
records=json.loads((out/'receipt.json').read_text(encoding='utf-8')) if (out/'receipt.json').exists() else []
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def run(name,args):
    start=time.monotonic()
    number=len(records)+1
    path=out/(str(number)+'-'+name+'.log')
    with path.open('wb') as log:
        r=subprocess.run(list(map(str,args)),env=env,stdout=log,stderr=subprocess.STDOUT,**flags)
    records.append(dict(name=name,args=list(map(str,args)),candidate=candidate,log=path.name,returncode=r.returncode,seconds=round(time.monotonic()-start,3)))
    (out/'receipt.json').write_bytes((json.dumps(records,indent=2)+'\n').encode('utf-8'));print(records[-1],flush=True)
    if r.returncode:
        print(path.read_text(encoding='utf-8',errors='replace')[-5000:],flush=True);raise SystemExit(r.returncode)
run('configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build-cpu-batch',['cmake','--build',build,'--target','hyle_compute_ggml_runtime_tests','hyle_compute_provider_ggml_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','--parallel','2'])
run('cpu-batch-tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-L','^(compute_ggml_runtime|compute_provider_ggml|compute_route_cpu|graph_route_cpu)$','-LE','headers','-j','1','--output-junit',out/'tests.xml'])
