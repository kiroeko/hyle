#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <span>
#include <utility>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/cpu.h"
#include "hyle/mem/buffer.h"
namespace c=hyle::compute; namespace g=hyle::graph;
template<class T>T take(hyle::Result<T> value){if(!value){std::fprintf(stderr,"%.*s\n",int(value.error().message().size()),value.error().message().data());std::exit(1);}return std::move(*value);}
void require(hyle::Status status){if(!status.ok()){std::fprintf(stderr,"%.*s\n",int(status.message().size()),status.message().data());std::exit(2);}}
int main(){
  auto xd=take(c::TensorDesc::dense(c::DataType::kFloat16,std::array<std::int64_t,2>{2,128}));
  auto wd=take(c::TensorDesc::dense(c::DataType::kFloat16,std::array<std::int64_t,2>{128,4}));
  auto yd=take(c::TensorDesc::dense(c::DataType::kFloat16,std::array<std::int64_t,2>{2,4}));
  auto xb=take(hyle::mem::Buffer::create(hyle::mem::system_resource(),512,64));
  auto wb=take(hyle::mem::Buffer::create(hyle::mem::system_resource(),1024,64));
  auto yb=take(hyle::mem::Buffer::create(hyle::mem::system_resource(),16,64));
  std::array<std::uint16_t,256>x{};x.fill(0x3c00);
  std::array<std::uint16_t,512>w{};w.fill(0x3c00);
  require(xb.view().write(std::as_bytes(std::span(x))));require(wb.view().write(std::as_bytes(std::span(w))));
  auto xv=take(c::ConstTensorView::create(xd,xb.view()));auto wv=take(c::ConstTensorView::create(wd,wb.view()));auto yv=take(c::TensorView::create(yd,yb.view()));
  auto check=[&]{std::array<std::uint16_t,8> actual{};require(yb.view().read(std::as_writable_bytes(std::span(actual))));for(auto value:actual)if(value!=0x5800){std::fprintf(stderr,"expected FP16 128, actual %x\n",value);std::exit(3);}};
  {
    auto context=take(c::cpu::create_context({.native_threads=2}));auto queue=take(context.create_queue());
    const std::array inputs{xd,wd};
    auto p=take(c::prepare(context,c::Operation{c::MatMul{}},inputs,std::span(&yd,1),hyle::mem::system_resource()));
    if(p.provider().id!=c::ggml_cpu::kProviderId)return 4;
    auto lane=take(p.create_invocation());const std::array views{xv,wv};
    for(int i=0;i<2;++i){auto done=take(lane.submit(queue,views,std::span(&yv,1)));require(done.wait());check();}
  }
  {
    auto builder=take(g::GraphBuilder::create());auto xi=take(builder.input(xd));auto wi=take(builder.input(wd));
    auto norm=take(builder.add(c::RmsNorm{.epsilon=0.0f},xi));auto yi=take(builder.add(c::MatMul{},norm,wi));
    require(builder.publish(yi));auto logical=take(std::move(builder).finish());
    auto context=take(g::cpu::create_context({.native_threads=2}));auto queue=take(context.create_queue());auto compiled=take(g::compile(logical,context));
    auto lane=take(compiled.executable.create_invocation());require(lane.bind(xi,xv));require(lane.bind(wi,wv));require(lane.bind(yi,yv));
    const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&queue}};require(lane.prepare_replay(queues));
    for(int i=0;i<2;++i){auto done=take(lane.submit(queue));require(done.wait());check();}
  }
  std::puts("ordinary CPU ggml FP16 Direct MatMul and full RMSNorm-MatMul Graph; two replays PASS");
}
