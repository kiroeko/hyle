import sys
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
copy=Path('C:/hv/d5cd/source-tree').resolve()
assert copy==Path('C:/hv/d5cd/source-tree') and copy.is_dir()
names=subprocess.check_output(['git','diff','--name-only','f1156a87','HEAD','--','cmake','src'],cwd=repo,text=True).splitlines()
for name in names:
    dest=(copy/name).resolve();assert dest.is_relative_to(copy)
    data=(repo/name).read_bytes()
    if not dest.exists() or dest.read_bytes()!=data:dest.write_bytes(data)
fixture=out.parent/'consumer'
static_build=Path('C:/hv/d5cp/source-build')
prefix=Path('C:/hv/cpu-ggml-isa-static-sdk')
source_fixture=Path('C:/hv/d5cp/consumer')
cmake=source_fixture/'CMakeLists.txt'
extra='\n# CPU original program delivery probe, reusing the qualified static producer.\nadd_executable(cpu_program_consumer "'+(out.parent/'cpu_program_consumer.cc').as_posix()+'")\ntarget_compile_features(cpu_program_consumer PRIVATE cxx_std_23)\ntarget_link_libraries(cpu_program_consumer PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(cpu_program_consumer)\n'
text=cmake.read_text(encoding='utf-8')
if 'add_executable(cpu_program_consumer ' not in text:cmake.write_bytes((text+extra).encode('utf-8'))
if '--resume-configured' not in sys.argv:
    run('static-source-configure-reused',['cmake','-S',source_fixture,'-B',static_build,'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
if '--resume-install' not in sys.argv:
    run('static-source-build',['cmake','--build',static_build,'--target','cpu_program_consumer','--parallel','2'])
run('static-source-execute',[static_build/'cpu_program_consumer.exe'])
# The selected SDK includes Time even though the probe does not link it.
run('static-sdk-build',['cmake','--build',static_build,'--target','hyle_time','--parallel','2'])
run('static-install',['cmake','--install',static_build/'hyle','--prefix',prefix])
installed=Path('C:/hv/cpu-ggml-isa-static-installed')
run('static-installed-configure',['cmake','-S',fixture,'-B',installed,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('static-installed-build',['cmake','--build',installed,'--target','cpu_program_consumer','--parallel','2'])
run('static-installed-execute',[installed/'cpu_program_consumer.exe'])
# Reuse the qualified canonical shared artifacts, without rebuilding unchanged tests.
run('shared-sdk-configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('shared-sdk-build',['cmake','--build',build,'--target','hyle_compute_provider_ggml','hyle_time','--parallel','2'])
prefix=Path('C:/hv/cpu-ggml-isa-shared-sdk')
run('shared-install',['cmake','--install',build,'--prefix',prefix])
installed=Path('C:/hv/cpu-ggml-isa-shared-installed')
run('shared-installed-configure',['cmake','-S',fixture,'-B',installed,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('shared-installed-build',['cmake','--build',installed,'--target','cpu_program_consumer','--parallel','2'])
run('shared-installed-execute',[installed/'cpu_program_consumer.exe'])
