exec(open('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-ggml-isa-admission/linux-delivery.py').read().split("run('cpu-runtime-provider-configure'")[0].split("if '--resume-build'")[0])
import os
boundary=Path('/root/hyle-scratch/cpu-ggml-isa-delivery').resolve()
for stage in ('static','shared'):
    prefix=(boundary/stage).resolve();moved=(boundary/(stage+'-moved')).resolve()
    assert prefix.parent==boundary and moved.parent==boundary
    assert prefix.is_dir() and not prefix.is_symlink() and not moved.exists()
    assert (prefix/'lib/cmake/Hyle/HyleConfig.cmake').is_file()
    consumer=boundary/(stage+'-consumer')
    try:
        os.rename(prefix,moved)
        run(stage+'-relocated-configure',['cmake','-S',out.parent/'consumer','-B',consumer,'-UHyle_DIR','-DCMAKE_PREFIX_PATH='+str(moved),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
        run(stage+'-relocated-build',['cmake','--build',consumer,'--parallel','2'])
        run(stage+'-relocated-public-f16',[consumer/'cpu_program_consumer'])
    finally:
        assert not prefix.exists() and moved.parent==boundary
        os.rename(moved,prefix)
    run(stage+'-restored-configure',['cmake','-S',out.parent/'consumer','-B',consumer,'-UHyle_DIR','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
