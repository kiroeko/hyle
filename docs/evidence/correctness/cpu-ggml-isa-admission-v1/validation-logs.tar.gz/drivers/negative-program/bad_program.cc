#include "cpu_program_abi.h"
using hyle::compute::ggml_runtime::CpuProgram;
const CpuProgram program{BAD_ABI, sizeof(CpuProgram), sizeof(ggml_tensor),
                         sizeof(ggml_cplan), nullptr, nullptr, nullptr, nullptr,
                         nullptr};
extern "C" __declspec(dllexport) const CpuProgram *
hyle_ggml_cpu_program_v1() noexcept { return &program; }
