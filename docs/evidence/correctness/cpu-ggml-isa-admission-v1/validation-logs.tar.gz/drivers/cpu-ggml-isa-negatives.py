exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
import os,shutil
fixture=out.parent/'negative-program'
negative_build=out.parent/'negative-build'
run('abi-negative-fixture-build-configure',['cmake','-S',fixture,'-B',negative_build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCPU_PROGRAM_HEADER_DIR='+str(repo/'src/compute_ggml_runtime'),'-DGGML_HEADER_DIR='+str(build/'src/compute_ggml_runtime/source-d8ea95b566c61d43/include')])
run('abi-negative-fixture-build',['cmake','--build',negative_build,'--parallel','2'])
qualified=Path('C:/hv/cpu-ggml-isa-static-installed')
module='hyle_ggml_cpu_avx2_456172ec.dll'
for variant in ('missing_program','bad_version','missing_callback'):
    target=out.parent/('negative-'+variant);target.mkdir(exist_ok=True)
    for original in [qualified/'cpu_program_consumer.exe',*qualified.glob('*.dll')]:
        if original.name==module:continue
        dest=target/original.name
        if not dest.exists():os.link(original,dest)
    if variant!='missing_program':shutil.copyfile(negative_build/(variant+'.dll'),target/module)
    log=out/(str(len(records)+1)+'-'+variant+'.log');start=time.monotonic()
    with log.open('wb') as stream:
        r=subprocess.run([str(target/'cpu_program_consumer.exe')],env=env,stdout=stream,stderr=subprocess.STDOUT,**flags)
    message='ggml CPU AVX2 program' if variant=='missing_program' else 'ggml CPU program ABI'
    passed=r.returncode==1 and message in log.read_text(errors='replace')
    records.append(dict(name=variant,candidate=candidate,log=log.name,returncode=r.returncode,expected_returncode=1,expected_message=message,passed=passed,seconds=round(time.monotonic()-start,3)))
    (out/'receipt.json').write_bytes((json.dumps(records,indent=2)+'\n').encode());print(records[-1],flush=True)
    assert passed,log.read_text(errors='replace')
run('cpu-off-isolation-configure',['cmake','-S',repo,'-B',out.parent/'cpu-off-build','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_TORCH_CPU_ROOT=C:/__hyle_invalid_cpu_sdk__','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(out.parent/'cpu-off-overlay.cmake')])
