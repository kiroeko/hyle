from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('process', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); b.W = W
read, save, pin, exact = b.read, b.save, b.pin, b.exact

def receipt(name):
    result = read(W / 'compile' / name / 'receipt.json'); exact(result['object'])
    for item in result['source_identities']: exact(item)
    return result

def main():
    plan = read(W / 'plan.json'); action, name = sys.argv[1:3]
    attempt = sys.argv[3] if len(sys.argv) > 3 else 'attempt1'
    if action == 'compile':
        folder = W / 'compile' / name
        b.execute(plan['units'][name]['compile'], folder / attempt, 240)
        deps = read(folder / 'dependencies.json')['Data']
        paths = sorted({Path(p).resolve() for p in [deps['Source'], *deps['Includes']] if Path(p).is_relative_to(R)})
        result = dict(object=pin(folder / 'unit.obj'), process=pin(folder / attempt / 'process.json'), source_identities=[pin(p) for p in paths])
        save(folder / 'receipt.json', result); save(folder / attempt / 'receipt.json', result)
    elif action == 'link':
        receipt(name)
        for item in plan['retained']: exact(item)
        exact(plan['runtime']); exact(plan['sdk'])
        for unit in read(plan['sdk']['path'])['engine_consumers']:
            for item in unit['source_identities']: exact(item)
        folder = W / 'link' / name / attempt
        b.execute(plan['units'][name]['link'], folder, 180)
        image = pin(W / 'bin' / (name + '.exe'))
        save(W / ('ready-' + name + '.json'), image); save(folder / 'image.json', image)
    elif action == 'run':
        unit, *args = plan['cases'][name]; receipt(unit)
        image = read(W / ('ready-' + unit + '.json')); exact(image)
        folder = W / 'runs' / name / attempt; save(folder / 'image.json', image)
        if unit == 'append': args += ['--gtest_output=xml:' + str(folder / 'results.xml')]
        b.execute([image['path'], *args], folder, 300)
        if unit == 'append':
            import xml.etree.ElementTree as ET
            root = ET.parse(folder / 'results.xml').getroot()
            assert root.get('tests') == '8' and root.get('failures') == '0' and not root.findall('.//skipped')
            result = dict(status='PASS', tests=int(root.get('tests')), failures=0, errors=int(root.get('errors', '0')))
        else:
            result = read(folder / 'stdout.log'); assert result['status'] == 'PASS'
        save(folder / 'report.json', result); print('PASS', name)
    else: raise ValueError(action)

if __name__ == '__main__': main()
