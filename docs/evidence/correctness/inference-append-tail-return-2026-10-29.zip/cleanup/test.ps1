﻿$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$expectedRoots = @(
    [IO.Path]::GetFullPath((Join-Path $repo '.scratch/inference-append-tail-return-20261029')),
    [IO.Path]::GetFullPath((Join-Path $repo '.scratch/inference-mtp-member-withdrawal-20261029'))
)
$plan = Get-Content -LiteralPath (Join-Path $expectedRoots[0] 'cleanup-plan.json') -Raw | ConvertFrom-Json
if ($plan.roots.Count -ne 2 -or $plan.files.Count -ne 12) { throw 'Unexpected bounded cleanup plan' }
for ($i = 0; $i -lt 2; $i++) {
    $resolved = (Resolve-Path -LiteralPath $expectedRoots[$i]).Path
    if (-not $resolved.Equals($expectedRoots[$i], [StringComparison]::OrdinalIgnoreCase) -or -not $resolved.Equals($plan.roots[$i], [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected cleanup root' }
    $rootItem = Get-Item -LiteralPath $resolved
    if ($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Cleanup root is a link' }
}
function Confirm-OriginalFile($record) {
    $item = Get-Item -LiteralPath $record.path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $record.bytes) { throw 'Invalid original file' }
    if ((Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256) { throw 'File identity changed' }
    return $item
}
foreach ($record in @($plan.evidence) + @($plan.keep) + @($plan.reuse_base)) { $null = Confirm-OriginalFile $record }
$reuse = Get-Content -LiteralPath $plan.reuse_base.path -Raw | ConvertFrom-Json
if ($reuse.retained.Count -ne 227 -or $plan.retained_SDK_inputs -ne 227) { throw 'Unexpected retained SDK closure' }
foreach ($record in $reuse.retained) { $null = Confirm-OriginalFile $record }
$targets = @()
foreach ($record in $plan.files) {
    $absolute = [IO.Path]::GetFullPath($record.path)
    if (-not (@($expectedRoots | Where-Object { $absolute.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) }).Count -eq 1)) { throw 'Target escapes explicit scratch roots' }
    $item = Confirm-OriginalFile $record
    if (-not $absolute.Equals($item.FullName, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected resolved file' }
    $parent = $item.Directory
    while ($parent -and -not $parent.FullName.Equals($repo, [StringComparison]::OrdinalIgnoreCase)) {
        if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Target ancestor is a link' }
        $parent = $parent.Parent
    }
    if (-not $parent) { throw 'Target is outside workspace' }
    if (@(@($plan.keep) + @($reuse.retained) + @($plan.evidence) + @($plan.reuse_base) | Where-Object { $_.path -eq $absolute }).Count) { throw 'Attempted to delete retained input' }
    $targets += $item.FullName
}
if (@($targets | Sort-Object -Unique).Count -ne 12) { throw 'Duplicate deletion target' }
$bytes = [int64]($plan.files | Measure-Object -Property bytes -Sum).Sum
foreach ($target in $targets) { Remove-Item -LiteralPath $target -Force }
foreach ($record in @($plan.evidence) + @($plan.keep) + @($plan.reuse_base) + @($reuse.retained)) { $null = Confirm-OriginalFile $record }
$result = [ordered]@{ deleted_files = $targets.Count; deleted_bytes = $bytes; retained_objects = 6; retained_SDK_inputs = 227; native_source_and_receipts_deleted = $false }
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $expectedRoots[0] 'cleanup-result.json') -Encoding UTF8
Write-Output ('Removed {0} rebuildable files ({1} bytes); retained latest objects and source/receipts' -f $targets.Count, $bytes)
