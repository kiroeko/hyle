from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess

base = Path('/root/hyle-scratch/compute-unified')
source = base / 'source-7a7b4c3b'
fixture = '2f9c8200f9a0c219d2dfc52cfe7f2ed20e01329d'
assert fixture in (source / 'SOURCE-MANIFEST.txt').read_text()
qualification = json.loads((base / 'foundation-f3-wsl-vulkan-device.json').read_text())
assert not qualification['vulkan']['qualified_gpu']
parent = base / 'l-vulkan/selected-graph/source-parent'; build = parent.parent / 'source-build'
root = base / 'foundation-f3-wsl-vulkan-source-97858fbc8'; assert not root.exists(); root.mkdir()
file = parent / 'CMakeLists.txt'; original = file.read_text(); text = original
for target, name in [('hyle_f3_file_streaming', 'main.cc'), ('hyle_f3_qwen_file_streaming', 'qwen_main.cc')]:
    if target not in text:
        text += '\nadd_executable(' + target + ' "' + str(source / 'samples/package/graph/file_streaming' / name) + '")\n'
        text += 'target_link_libraries(' + target + ' PRIVATE hyle::graph)\nhyle_stage_runtime(' + target + ')\n'
if text != original: file.write_text(text)
env = os.environ.copy(); env['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
job = {'product_commit': '97858fbc88a6b5a87f109290b956eeaeee632dd2', 'fixture': fixture,
       'source': str(source), 'build': str(build), 'device_qualification': qualification,
       'scope': 'Ordinary Vulkan source add_subdirectory Graph consumers build only; actual GPU math NOT_APPLICABLE, only software llvmpipe available.', 'stages': []}
commands = [('configure', ['/usr/bin/cmake', '-S', str(parent), '-B', str(build)], 300),
            ('build', ['/usr/bin/cmake', '--build', str(build), '--target', 'hyle_f3_file_streaming', 'hyle_f3_qwen_file_streaming', '--parallel', '4'], 1800)]
for name, command, timeout in commands:
    free = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
    assert free >= 4 * 1024**3
    if '--parallel' in command: command[command.index('--parallel') + 1] = str(4 if free >= 12 * 1024**3 else 2 if free >= 8 * 1024**3 else 1)
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'log': log.name, 'available_bytes': free}
        job['stages'].append(row); (root / 'job.json').write_text(json.dumps(job, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait()
            row.update(state='terminal', verdict='TIMEOUT'); (root / 'job.json').write_text(json.dumps(job, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(job, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
for target in ['hyle_f3_file_streaming', 'hyle_f3_qwen_file_streaming']:
    log = root / ('ldd-' + target + '.log')
    result = subprocess.run(['/usr/bin/ldd', str(build / target)], env=env, capture_output=True, text=True, timeout=30)
    log.write_text(result.stdout + result.stderr); assert result.returncode == 0 and 'not found' not in result.stdout
    job['stages'].append({'name': 'ldd-' + target, 'command': ['/usr/bin/ldd', str(build / target)], 'state': 'terminal',
                         'exit_code': 0, 'verdict': 'PASS', 'log': log.name, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
job['verdict'] = 'PASS_WSL_VULKAN_ORDINARY_SOURCE_BUILD_ONLY_NO_GPU_MATH'
(root / 'job.json').write_text(json.dumps(job, indent=2))
