"""Two frozen CXX units and three synchronous IO checks; no SDK/shader rebuild."""
from pathlib import Path
import importlib.util,json,os,sys,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
G=R/'.scratch/inference-vulkan-raw16-gather-20261027'
spec=importlib.util.spec_from_file_location('raw16_recipe',G/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
EXPECTED={'src/compute_route_vulkan/vulkan_memory.cc':'2293adf3f6417b30f110b3df35b9b066f43ac88e8228aa7be18f8b72a2be1c01',
 'tests/compute_route_vulkan/copy_recording_test.cc':'f441c6b3d8f65ecdd760c7ac472ad31b8748f8a2241088bd7b6d800d4c87f444'}
def plan():
    assert not (W/'plan.json').exists()
    for path,digest in EXPECTED.items():assert b.pin(R/path)['sha256']==digest,path
    units=[]
    for name,source,recipe in [
      ('memory','src/compute_route_vulkan/vulkan_memory.cc',R/'.scratch/inference-stream-padding-20261026/compile/vulkan-memory/command.json'),
      ('test','tests/compute_route_vulkan/copy_recording_test.cc',G/'fixture2/compile/command.json')]:
        command=m.command(recipe,R/source,W/'compile'/name)
        dest=W/'recipes'/f'{name}.json';b.save(dest,dict(command=command,cwd=str(R),timeout_seconds=180))
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(dest)))
    frozen=m.c.closure([u['source']['path'] for u in units],[u['recipe']['path'] for u in units]);b.save(W/'source-freeze.json',frozen)
    for path in EXPECTED:
        dest=W/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((R/path).read_bytes())
    ready=b.read(G/'fixture2/ready.json');inputs=b.read(ready['inputs']['path'])
    before={'memory':str(R/'.scratch/inference-stream-padding-20261026/compile/vulkan-memory/unit.obj'),
        'test':str(G/'fixture2/compile/unit.obj')}
    assert all(sum(b.key(row['path'])==b.key(path) for row in inputs)==1 for path in before.values())
    for row in inputs:b.exact(row)
    b.save(W/'plan.json',dict(status='SOURCE_FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(W/'source-freeze.json'),baseline=ready,
      baseline_ready=b.pin(G/'fixture2/ready.json'),replaced_inputs=before,expected=EXPECTED,
      scope='One original private MemoryState TU changes, no shared/public header layout change. Reuse original 1MiB staging/word CopyRecording; two halfword edges use an independent 8B device owner and existing halfword Recording on the original Runtime/FIFO/Completion. Metadata is lazy and actual-range bounded.',
      selection='VulkanMemoryIO.*',expected_tests=3,CXX_TUs=2,SDK=0,shaders=0,models=0,downloads=0))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def build():
    p=b.read(W/'plan.json');assert not (W/'compile').exists() and not (W/'ready.json').exists()
    frozen=b.read(p['source_freeze']['path']);[b.exact(row) for row in frozen]
    h,e=old.old.env();own={b.key(row['path']):row for row in frozen};compiled=[];objects={}
    for unit in p['units']:
        out=W/'compile'/unit['name'];result=h.execute(b.read(unit['recipe']['path'])['command'],e,out,timeout=180)
        data=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([data['Source'],*data['Includes']])];b.save(out/'actual-dependencies.json',actual)
        for row in actual:
            path=Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):assert own[b.key(path)]['sha256']==row['sha256'],path
        objects[unit['name']]=b.pin(out/'unit.obj');compiled.append(dict(unit=unit,object=objects[unit['name']],process=result,dependencies=b.pin(out/'actual-dependencies.json')));b.save(W/'partial-build.json',compiled)
        [b.exact(row) for row in frozen]
    replacements={b.key(path):objects[name] for name,path in p['replaced_inputs'].items()}
    args=b.read(G/'fixture2/link/command.json')['command'];image=W/'bin/halfword-io-test.exe';image.parent.mkdir(parents=True,exist_ok=True);seen=set()
    for i,arg in enumerate(args):
        if b.key(arg) in replacements:seen.add(b.key(arg));args[i]=replacements[b.key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):args[i]='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):args[i]='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):args[i]='/IMPLIB:'+str(image.with_suffix('.lib'))
    assert seen==set(replacements)
    linked=h.execute(args,e,W/'link',timeout=120)
    previous=b.read(p['baseline']['inputs']['path']);[b.exact(row) for row in previous]
    b.save(W/'link-inputs.json',[replacements.get(b.key(row['path']),row) for row in previous])
    runtime=b.read(p['baseline']['runtime']['path']);native=runtime['native'];b.exact(native);alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',compiled=compiled,link=linked,image=b.pin(image),inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json')))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run():
    p=b.read(W/'plan.json');ready=b.read(W/'ready.json');b.exact(ready['image']);assert not (W/'run').exists();h,e=old.old.env();e['PATH']=b.read(ready['runtime']['path'])['PATH'];xml=W/'results.xml'
    result=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+p['selection'],'--gtest_output=xml:'+str(xml)],e,W/'run',timeout=90)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase');assert root.attrib['tests']=='3' and root.attrib['failures']=='0' and len(cases)==3
    assert all(c.attrib.get('status')=='run' and not list(c) for c in cases)
    b.save(W/'summary.json',dict(status='THREE_HALFWORD_IO_CASES_PASS',process=result,ready=b.pin(W/'ready.json'),results=b.pin(xml),cases=[c.attrib for c in cases],scope=p['scope']))
    print('PASS',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    try:{'plan':plan,'build':build,'run':run}[sys.argv[1]]()
    except Exception:b.save(W/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc()));raise
