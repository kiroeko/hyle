$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$specs = @(
  @{ path = 'C:\public\project-hyle\hyle\.scratch\inference-shape-policy-20261027\cli\link\hyle.exe'; bytes = 142049280; sha256 = '217bad1bb6eb6bc1412fa093eb33fabb5f2f2d352c6b76491af4ac74a5541b59' },
  @{ path = 'C:\public\project-hyle\hyle\.scratch\inference-vulkan-raw16-gather-20261027\bin\raw16-gather-test.exe'; bytes = 68480000; sha256 = '28d2a95a79522d860a8df97e02e4c3570868fccbd5641fe36545f3cf092711b6' },
  @{ path = 'C:\public\project-hyle\hyle\.scratch\inference-vulkan-raw16-gather-20261027\fixture2\bin\raw16-fixture.exe'; bytes = 68481536; sha256 = 'd3edba23f0810e61896a5687bfcb7c156609ba6736f4812410e5fa49ea02deff' }
)
$kept = @(
  @{ path = 'C:\public\project-hyle\hyle\.scratch\inference-shape-policy-20261027\warmup\image\hyle.exe'; sha256 = 'a1ba07f344162bc4cdb7907c9dd09b8fcb066ad6049a3655f3d0dbebe6fb9f9f' },
  @{ path = 'C:\public\project-hyle\hyle\.scratch\inference-vulkan-halfword-io-20261027\bin\halfword-io-test.exe'; sha256 = 'ba60e45f98fde3a942fe1dae6c6dc11607730b252fea45f04a907dfc9de20c3a' }
)
foreach ($spec in $kept) {
  if (!(Test-Path -LiteralPath $spec.path -PathType Leaf) -or (Get-FileHash -LiteralPath $spec.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $spec.sha256) { throw 'Required replacement image missing or changed' }
}
foreach ($spec in $specs) {
  $resolved = [IO.Path]::GetFullPath($spec.path)
  if (!$resolved.StartsWith($workspace + '\.scratch\', [StringComparison]::OrdinalIgnoreCase) -or $resolved -ne $spec.path -or [IO.Path]::GetExtension($resolved) -ne '.exe') { throw 'Unexpected cleanup target' }
  $item = Get-Item -LiteralPath $resolved
  if ($item.Length -ne $spec.bytes -or (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $spec.sha256) { throw 'Superseded image identity changed' }
  Write-Output "Verified superseded image: $resolved ($($spec.bytes) bytes)"
}
if ($env:HYLE_EXECUTE_CLEANUP -ne '1') { Write-Output 'Preview only'; exit 0 }
foreach ($spec in $specs) { Remove-Item -LiteralPath $spec.path }
[pscustomobject]@{ removed = $specs; retained = $kept; logical_removed_bytes = ($specs | Measure-Object -Property bytes -Sum).Sum } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $workspace '.scratch\inference-vulkan-halfword-io-20261027\cleanup-result.json') -Encoding UTF8
