"""Publish the finite exact-halfword Vulkan I/O check; no execution."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


plan = read(W / "plan.json")
ready = read(W / "ready.json")
summary = read(W / "summary.json")
assert summary["status"] == "THREE_HALFWORD_IO_CASES_PASS"
assert summary["process"]["exit"] == 0
for relative, expected in plan["expected"].items():
    assert pin(R / relative)["sha256"] == expected
    assert pin(W / "source" / relative)["sha256"] == expected
assert pin(ready["image"]["path"]) == ready["image"]
assert pin(W / "ready.json") == summary["ready"]
assert pin(W / "results.xml") == summary["results"]
for unit in ready["compiled"]:
    assert unit["process"]["exit"] == 0
    assert pin(unit["object"]["path"]) == unit["object"]
    assert pin(unit["dependencies"]["path"]) == unit["dependencies"]
assert ready["link"]["exit"] == 0
xml = ET.parse(W / "results.xml").getroot()
cases = xml.findall("./testsuite/testcase")
assert xml.attrib["tests"] == "3" and xml.attrib["failures"] == "0"
assert len(cases) == 3 and all(case.attrib["status"] == "run" and not list(case) for case in cases)
inputs = read(W / "link-inputs.json")
assert len(inputs) == len(read(plan["baseline"]["inputs"]["path"]))
cleanup = read(W / "cleanup-result.json")
assert cleanup["logical_removed_bytes"] == 279010816

# Include actual source snapshots, recipes and diagnostic records, never binary/cache payloads.
names = [
    "build.py", "publish.py", "plan.json", "source-freeze.json", "partial-build.json",
    "ready.json", "summary.json", "results.xml", "runtime.json", "link-inputs.json",
    "recipes/memory.json", "recipes/test.json", "cleanup-result.json", "cleanup-executed.ps1",
    "source/src/compute_route_vulkan/vulkan_memory.cc",
    "source/tests/compute_route_vulkan/copy_recording_test.cc",
]
for directory in ("compile/memory", "compile/test", "link", "run"):
    for path in sorted((W / directory).iterdir()):
        if path.is_file() and path.suffix.lower() in {".json", ".log"}:
            names.append(path.relative_to(W).as_posix())
members = {name: (W / name).read_bytes() for name in names}
assert len(members) == len(names)
receipt = dict(
    schema=1,
    date="2026-10-27",
    title="Exact halfword synchronous Vulkan memory I/O",
    status="IMPLEMENTED_FINITE_SCOPE_PASS",
    scope="Synchronous read/write/fill of actual even-origin/even-length native spans, including exact two-byte partial ReadLease spans. The original word-aligned path and whole-owned odd allocation padding path are preserved. No Graph permission or public ABI widening.",
    current_sources=[pin(R / relative) for relative in plan["expected"]],
    implementation=[
        "The original 1MiB staging, word CopyRecording, Runtime FIFO and Completion retirement mechanism remain. A lazy independent 8B device scratch joins at most head2 + word-aligned middle + tail2; edge copies use the existing native halfword Recording, not a host payload fallback.",
        "Both real edge ranges are prebound together before payload writes. Scratch is fully initialized through an original word copy; staging is never treated as STORAGE. Real source/destination logical ranges and neighboring padding are not expanded.",
        "Scratch MemoryState does not retain the parent resource. Every prepared-word/edge path is cleared after Completion scope, including early errors. Unknown retirement poisons the original runtime/cache and drops reusable recording roots; the original pending Run owns actual buffers/pipeline until retirement. Host map/read/write/fill errors remain recorded in the cache.",
    ],
    builds=dict(
        actual_CXX_processes=2, distinct_CXX_TUs=2, link_processes=1,
        compiled=ready["compiled"], link=ready["link"], image=ready["image"],
        ready=pin(W / "ready.json"), link_inputs=pin(W / "link-inputs.json"),
        linked_input_count=len(inputs),
        reuse="The exact previous raw16 fixture link closure is reused, replacing only vulkan_memory.cc and this existing test TU. Per-object hashes and actual compiler dependencies are retained. Earlier raw16/halfword CopyRecording/shaders/native frontend remain the same cached objects; no SDK, shader, NVCC, model or download operation in this batch.",
        baseline_ready=plan["baseline_ready"], replaced_inputs=plan["replaced_inputs"],
        SDK_builds=0, shader_builds=0, NVCC_processes=0, downloads=0,
    ),
    execution=dict(
        test_processes=1, actual_cases=3, passes=3, failures=0,
        process=summary["process"], filter=plan["selection"],
        results=summary["results"], cases=summary["cases"],
        attempts="Each CXX TU, link and actual test process ran once. No failed attempt or retry in this batch; no previously passing Gather/Store suite rerun.",
    ),
    verified=[
        "Exact read/write/fill at offsets/lengths (0,2),(2,2),(2,4),(0,6),(2,6),(26,6); every neighboring byte compared after each operation.",
        "A true six-byte ready ReadLease remains readable after pool/public-resource wrappers are released; all owners released at test end with QuotaAllocator usage zero.",
        "A range at offset2 of length1MiB+8 covers two edges and a word middle spanning the original staging capacity; write/read/fill preserve both neighbors.",
        "Original aligned I/O and full owned 3B allocation read/write/fill pass; partial odd bytes/odd native origin remain rejected without changing original bytes.",
    ],
    unverified_and_limits=[
        "No device/runtime fault injection, validation-layer run, full model, throughput comparison or platform/device matrix. Failure/unknown-retirement cleanup is source-reviewed, not runtime fault-injection evidence.",
        "This adds even native-origin/even-length device I/O. Arbitrary odd-byte partial I/O remains unsupported; the existing complete-owned odd allocation exception is retained.",
        "Generic ReadLease tensor import still retains its original four-byte carrier gate; this receipt does not claim arbitrary two-byte tensor bindings. The existing exact halfword copy path requires the actually enabled native storage16 feature and real device-backed storage.",
        "This targeted I/O run closes the short-lease read limitation observed by the previous raw16 Gather receipt; that older experiment and its initial failures remain unchanged. No complete Gather or engine rerun is claimed.",
    ],
    cleanup=dict(
        logical_removed_bytes=cleanup["logical_removed_bytes"],
        record=pin(W / "cleanup-result.json"),
        explanation="Parent executed repository test.ps1 after exact path/hash checks, deleting three superseded EXEs only. Their original image identities and run logs remain; the current I/O image, sources, OBJ and recipes are retained. Archive does not require old image files to exist.",
    ),
    members=[dict(name=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(members.items())],
)
manifest = (json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
members["manifest.json"] = manifest
dest = R / "docs/evidence/correctness"
stem = "inference-vulkan-halfword-io-2026-10-27"
archive = dest / (stem + ".zip")
public = dest / (stem + ".json")
assert not archive.exists() and not public.exists(), "Preserve any existing published receipt"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(members.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(members) and z.testzip() is None
    for name, data in members.items():
        actual = z.read(name)
        assert len(actual) == len(data) and digest(actual) == digest(data) and actual == data
receipt["archive"] = pin(archive)
receipt["archive_manifest_sha256"] = digest(manifest)
receipt["integrity"] = "Every archive member reopened and checked byte-for-byte and by SHA256; CRC passed. Current sources/snapshots, image, actual compiler records and XML checked before publication."
public.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
published = dict(receipt=pin(public), archive=pin(archive), members=len(members))
(W / "published.json").write_text(json.dumps(published, indent=2) + "\n", encoding="utf-8")
print(json.dumps(published, indent=2))
