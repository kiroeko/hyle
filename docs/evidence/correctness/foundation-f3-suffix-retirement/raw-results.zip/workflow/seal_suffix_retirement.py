from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'
failed = scratch / 'suffix-wsl-logs/foundation-f3-current-cuda-bf59b57f0'
failure = json.loads((failed / 'job.json').read_text())
assert failure['stages'][-1]['exit_code'] == -6
log = (failed / 'files.log').read_text()
assert 'Which is: 1' in log and 'host.metadata.balanced()' in log and 'HYLE fatal' in log
subjects = [(scratch / 'suffix-cpu-air-logs', 13, 'Air-CPU'),
            (scratch / 'suffix-apple-air-logs', 6, 'Air-Apple'),
            (scratch / 'suffix-vulkan-air-logs', 5, 'Air-Vulkan'),
            (scratch / 'native-windows-vulkan-suffix-retirement-regression', 5, 'Windows-Vulkan')]
subjects += [(scratch / 'suffix-wsl-logs' / ('foundation-f3-current-' + mode + '-97858fbc8'),
              7 if mode == 'cuda' else 13, 'WSL-' + mode) for mode in ['cuda', 'asan', 'ubsan', 'tsan']]
rows = []
for folder, count, label in subjects:
    job = json.loads((folder / 'job.json').read_text())
    for stage in job['stages']:
        assert stage['state'] == 'terminal' and stage['exit_code'] == 0
        assert hashlib.sha256((folder / stage['log']).read_bytes()).hexdigest() == stage['sha256']
    tests = ET.parse(folder / 'files.xml').getroot()
    assert tests.attrib['tests'] == str(count) and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
    rows.append({'label': label, 'tests_passed': count, 'identity': job.get('identity', job.get('compiler'))})
out = repo / 'evidence/correctness/foundation-f3-suffix-retirement'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for folder, count, label in subjects + [(failed, 0, 'Original-FAIL')]:
        for path in sorted(folder.iterdir()):
            if path.is_file(): packed.writestr(label + '/' + path.name, path.read_bytes())
    for name in ['suffix-audited-binding.json', 'wsl-source-bf59b57f0.json', 'wsl-source-97858fbc8.json', 'air-source-97858fbc8.json']:
        packed.writestr(name, (scratch / name).read_bytes())
    for name in ['run_wsl_current_delta.py', 'seal_suffix_retirement.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1, 'product_commit': '97858fbc88a6b5a87f109290b956eeaeee632dd2',
    'product_tree': '6398479c76fdc9677206ee692943664814463ebd',
    'original_failure_fixture': 'bf59b57f087f159d2e274bb1cacde62852b5b2a1',
    'original_failure': 'K1 first readonly file group errors; admitted blocked producer of unstarted second group remains in state/Completion/retention cycle. After actual GPU drain one active use and unbalanced F3 metadata, isolated child abort6.',
    'finite_correction': 'Only compute_stream returned CANDIDATE->AUDITED before product write. Move failed group Completion out under monitor, destroy outside monitor; original native owner retains through actual retirement. Worker, admission spawn failure and collect spawn failure paths covered. No new runtime/API/field/array/allocation.',
    'runs': rows, 'common_changed_tu_sha256': hashlib.sha256((repo / 'src/compute_stream/file_stream.cc').read_bytes()).hexdigest(),
    'cost_delta': 'Fixed Failed directory traversal O(QGR); per-cell monitor entry, no native wait under lock.',
    'budget': 'One concrete original F3-06 suffix counterexample and one focused correction/acceptance; all previous errors/corrections/ASan timeout+supplement retained, no research/budget reset.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_F3_SUFFIX_RETIREMENT_AND_SELECTED_PLATFORM_REGRESSIONS_ONLY',
    'unproven': ['Windows CUDA new suffix test directly', 'Current source/installed math and new headers/delivery after correction', 'Final candidate/red team/all gates/closure']}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('Original suffix abort6 retained; focused correction, actual CUDA seven and three sanitizer thirteen risks verified.')
