#pragma once
#include "vulkan_program_internal.h"
#include <cstddef>
namespace raw16_incremental_abi {
using namespace hyle::compute::vulkan::detail;
struct Before { std::uint32_t value=0,input_port=0; bool byte_origin=false; VkDescriptorBufferInfo buffer{}; VkWriteDescriptorSet write{}; };
static_assert(sizeof(Before)==sizeof(DescriptorBinding));
static_assert(alignof(Before)==alignof(DescriptorBinding));
static_assert(offsetof(Before,value)==offsetof(DescriptorBinding,value));
static_assert(offsetof(Before,input_port)==offsetof(DescriptorBinding,input_port));
static_assert(offsetof(Before,byte_origin)==offsetof(DescriptorBinding,byte_origin));
static_assert(offsetof(Before,buffer)==offsetof(DescriptorBinding,buffer));
static_assert(offsetof(Before,write)==offsetof(DescriptorBinding,write));
static_assert(offsetof(DescriptorBinding,storage_granularity)<offsetof(DescriptorBinding,buffer));
}
