"""Publish finite raw16 Gather-to-Store evidence; no new execution."""
from pathlib import Path
import hashlib,json,struct,xml.etree.ElementTree as ET,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=sha(raw))
ready=read(W/'ready.json');final=read(W/'fixture2/ready.json');summary=read(W/'fixture2/summary.json')
assert summary['status']=='BOTH_RAW16_GATHER_STORE_CHAINS_PASS'
original_xml=ET.parse(W/'results.xml').getroot();final_xml=ET.parse(W/'fixture2/results.xml').getroot()
assert original_xml.attrib['tests']=='4' and original_xml.attrib['failures']=='2'
assert final_xml.attrib['tests']=='2' and final_xml.attrib['failures']=='0'
for row in read(W/'product-freeze.json'):
    rel=Path(row['path']).relative_to(R);snapshot=W/'source'/rel
    assert pin(snapshot)['sha256']==row['sha256']
    if rel.as_posix()!='tests/graph_route_vulkan/slot_store_test.cc':assert pin(R/rel)['sha256']==row['sha256']
assert pin(W/'fixture2/source/tests/graph_route_vulkan/slot_store_test.cc')['sha256']==final['source']['sha256']
assert pin(R/'tests/graph_route_vulkan/slot_store_test.cc')['sha256']==final['source']['sha256']
inspection=read(W/'shader/inspection.json');raw=(W/'generated/raw16_gather.spv').read_bytes()
assert sha(raw)==inspection['shader']['sha256'] and set(inspection['capabilities'])=={1,4433} and inspection['OpFConvert_count']==0
words=struct.unpack('<'+'I'*(len(raw)//4),raw);at=5;caps=[];converts=0
while at<len(words):
    size,opcode=words[at]>>16,words[at]&65535;assert size and at+size<=len(words)
    if opcode==17:caps.append(words[at+1])
    converts+=opcode==115;at+=size
assert set(caps)=={1,4433} and converts==0
changed=[row['path'] for row in read(W/'product-freeze.json')]
current=[pin(path) for path in changed]
members={}
for path in W.rglob('*'):
    if path.is_file() and path.suffix.lower() in {'.py','.json','.log','.cc','.h','.xml','.comp','.spv'}:
        members[path.relative_to(W).as_posix()]=path.read_bytes()
receipt=dict(schema=1,date='2026-10-27',title='Exact raw16 checked Vulkan Gather and external Store',status='IMPLEMENTED_FINITE_SCOPE_PASS',
    implementation='A real model-independent native raw16 Gather reads only selected rows with original even byte pitch, using U16 storage load/store and original checked safe I32 IDs/status. No whole-bank pack, floating conversion or CPU payload fallback. Four-byte rows keep their original raw I32 route. An explicit private Pipeline access granularity qualifies exact two-byte descriptors during record, input bind and rebind; ordinary shaders retain four-byte rounding.',
    current_sources=current,
    changes=[
      dict(path='src/compute_route_vulkan/shaders/raw16_gather.comp',summary='Native exact selected halfword rows, safe IDs and checked-status gate; no floating or 16-bit arithmetic.'),
      dict(path='src/compute_route_vulkan/build_shaders.py',summary='Admits this variant and optional variant/output-stem selection, enabling one-kernel incremental generation with the cached compiler.'),
      dict(path='src/compute_route_vulkan/vulkan_program_internal.h',summary='Private Pipeline access fact and per-descriptor copy of it, plus helper declarations; mathematical ProgramState/Dispatch/InvocationState fields unchanged.'),
      dict(path='src/compute_route_vulkan/vulkan_pipeline.cc',summary='Actual enabled storage16 gate, exact qualified descriptors, and original word descriptor overload retained.'),
      dict(path='src/compute_route_vulkan/vulkan_program.cc',summary='Original all-input preflight uses the actual prepared descriptor access fact before mutating any binding.'),
      dict(path='src/compute_route_vulkan/vulkan_region.cc',summary='Real checked raw16 lowering before the old full-bank padding path; bounded U32 address/workgroup domain.'),
      dict(path='tests/graph_route_vulkan/slot_store_test.cc',summary='Real BF16 E1 and F16 E3 partial-source Gather-to-Store, original F32 word neighbor, and valid-then-invalid checked ID; exact source and full initialized diagnostic image oracle.')],
    ABI=dict(proof=pin(W/'abi.h'),actual_static_asserts='New pipeline/program/region compiler processes all passed old DescriptorBinding sizeof/alignment and every old member offset comparison; the new field is in old padding. This proves cached private compatibility for this actual Windows toolchain, not an unbuilt cross-platform ABI.',
      construction='Pipeline is allocated only in recompiled vulkan_pipeline.cc. DescriptorBinding new entry is constructed there with default4 and the selected pipeline fact. New-field reader Invocation.bind is recompiled vulkan_program.cc; vector copies are in recompiled vulkan_region.cc. No old allocator/stack object is assumed to initialize the new field.',
      unchanged='No public SpirvDescription field, ProgramState, Dispatch, InvocationState, native frontend bridge, Queue or Run layout change.'),
    shader=inspection,
    builds=dict(first_ready=pin(W/'ready.json'),first_compiled=ready['compiled'],first_link=ready['link'],
      fixture_only_ready=pin(W/'fixture2/ready.json'),fixture_only_compile=final['compile'],fixture_only_link=final['link'],
      distinct_CXX_TUs=5,CXX_processes=6,shader_compiles=1,links=2,images=2,SDK_builds=0,native_frontend_builds=0,downloads=0,models=0),
    execution=dict(first_process=read(W/'run/process.json'),first_results=pin(W/'results.xml'),first_cases=[c.attrib for c in original_xml.findall('./testsuite/testcase')],
      first_outcome='Four executed: original F32 word neighbor and checked invalid-ID case passed; two raw16 chain cases failed only at the later diagnostic short-lease D2H call, after successful GPU completion, generated byte comparison and complete pool/padding comparison.',
      final_process=summary['process'],final_results=pin(W/'fixture2/results.xml'),final_cases=summary['cases'],
      final_outcome='Only two affected raw16 chain cases reran and passed after the diagnostic fixture adjustment. Product sources/shader/objects unchanged. Original two passing cases were not rerun.',
      distinct_cases=4,actual_case_executions=6,test_processes=2),
    failures_preserved=[
      dict(kind='Orchestration script',record=pin(W/'first-script-failure.json'),explanation='Old source-closure helper rejected the newly generated scratch CXX root before any CXX compile; the successful shader was reused. Product compilation did not fail.'),
      dict(kind='Fixture diagnostic assumption exposes existing capability gap',record=pin(W/'run-failure.json'),explanation='MemoryState::device_io requires exact four-byte-aligned offsets and rejects padding an unaligned partial span (vulkan_memory.cc:193-207). Source ready leases at 18/6 or 30/10 legitimately have two-byte alignment. No product range gate was relaxed. The fixture instead checks the same exact source bytes in the independently initialized complete-pool diagnostic image it retained before lease adoption; Graph still receives only the two actual source leases.')],
    verified=['BF16 E1 and F16 E3 raw selected rows including signed zero/NaN payloads, physical stride6/10 and capacity ending at 2mod4.',
      'Actual SourceBinding accepts only original partial ready leases; destination writes preserve unused items and every gap byte.',
      'Original generated-result ownership and Completion retirement guard take; reset withdraws actual projection/write authority.',
      'Valid standalone raw16 Gather executes first; a later out-of-range I32 ID makes Completion OutOfRange and prevents result publication.',
      'One old F32 raw-word Gather-to-Store case passes on the new descriptor implementation.'],
    unverified_and_remaining=['Exact synchronous short-lease halfword D2H remains unsupported and is a goal follow-up, not reported as fixed by raw Gather.',
      'Generic ready two-byte ReadLease tensor import still keeps its original four-byte carrier requirement; this batch uses the explicit selected-row capacity/projection path.',
      'Only rank2 axis0/-2 checked plain two-byte scalars, inner-contiguous positive rows/indices, even row pitch, enabled storageBuffer16BitAccess and checked descriptor/U32/dispatch bounds. Arbitrary odd-byte Gather/Store not supported.',
      'No complete-model inference, throughput, capture optimization, driver validation-layer, device-fault injection or broader hardware/platform matrix.'],
    members=[dict(name=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())])
manifest=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode('utf-8');members['manifest.json']=manifest
dest=R/'docs/evidence/correctness';stem='inference-vulkan-raw16-gather-2026-10-27';zip_path=dest/(stem+'.zip');json_path=dest/(stem+'.json')
assert not zip_path.exists() and not json_path.exists(),'Preserve existing published evidence'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(zip_path) as z:
    assert set(z.namelist())==set(members) and z.testzip() is None
    for name,data in members.items():assert z.read(name)==data
receipt['archive']=pin(zip_path);receipt['archive_manifest_sha256']=sha(manifest);receipt['integrity']='Every member reopened and compared byte-for-byte; CRC passed.'
json_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(receipt=pin(json_path),archive=pin(zip_path),members=len(members)),indent=2))
