"""One fixture-only TU; preserve the first four-case result and rerun only two cases."""
from pathlib import Path
import importlib.util,json,os,sys,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];A=W/'fixture2'
spec=importlib.util.spec_from_file_location('raw16_recipe',W/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
def build():
    assert not (A/'freeze.json').exists()
    previous=b.read(W/'ready.json');source=R/'tests/graph_route_vulkan/slot_store_test.cc'
    command=m.command(W/'recipes/test.json',source,A/'compile')
    b.save(A/'recipe.json',dict(command=command,cwd=str(R),timeout_seconds=180))
    frozen=m.c.closure([source],[A/'recipe.json']);b.save(A/'source-freeze.json',frozen)
    saved=A/'source/tests/graph_route_vulkan/slot_store_test.cc';saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(source.read_bytes())
    b.save(A/'freeze.json',dict(previous=b.pin(W/'ready.json'),first_failure=b.pin(W/'run-failure.json'),source=b.pin(source),source_freeze=b.pin(A/'source-freeze.json'),
        reason='Only diagnostic fixture correction: original exact ready source views remain checked; raw16 source bytes are checked in the independently retained, completely initialized pool diagnostic image. No Graph projected permissions or mathematical/byte oracle changes. Existing synchronous short-lease D2H four-byte limitation remains explicitly unimplemented.',
        rerun='Only the two raw16 chain cases. Original passing F32 neighbor and valid-to-invalid checked-ID case are not repeated.'))
    own={b.key(row['path']):row for row in frozen};h,e=old.old.env();result=h.execute(command,e,A/'compile',timeout=180)
    raw=b.read(A/'compile/dependencies.json')['Data'];actual=[b.pin(p) for p in dict.fromkeys([raw['Source'],*raw['Includes']])];b.save(A/'compile/actual-dependencies.json',actual)
    for row in actual:
        path=Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):assert own[b.key(path)]['sha256']==row['sha256'],path
    obj=b.pin(A/'compile/unit.obj');prior=next(c['object'] for c in previous['compiled'] if c['unit']['name']=='test')
    args=b.read(W/'link/command.json')['command'];image=A/'bin/raw16-fixture.exe';image.parent.mkdir(parents=True,exist_ok=True);count=0
    for i,arg in enumerate(args):
        if b.key(arg)==b.key(prior['path']):args[i]=obj['path'];count+=1
        elif arg.upper().startswith('/OUT:'):args[i]='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):args[i]='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):args[i]='/IMPLIB:'+str(image.with_suffix('.lib'))
    assert count==1
    linked=h.execute(args,e,A/'link',timeout=120)
    retained=b.read(previous['inputs']['path']);[b.exact(row) for row in retained]
    b.save(A/'link-inputs.json',[obj if b.key(row['path'])==b.key(prior['path']) else row for row in retained])
    runtime=b.read(previous['runtime']['path']);native=runtime['native'];b.exact(native);alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(A/'runtime.json',runtime)
    b.save(A/'ready.json',dict(status='BUILT_NOT_RUN',previous=b.pin(W/'ready.json'),source=b.pin(source),object=obj,compile=result,link=linked,image=b.pin(image),inputs=b.pin(A/'link-inputs.json'),runtime=b.pin(A/'runtime.json'),freeze=b.pin(A/'freeze.json'),shader_recompiled=False,products_recompiled=False))
    print('READY',json.dumps(b.pin(A/'ready.json')),flush=True)
def run():
    ready=b.read(A/'ready.json');b.exact(ready['image']);assert not (A/'run').exists();h,e=old.old.env();e['PATH']=b.read(ready['runtime']['path'])['PATH'];xml=A/'results.xml'
    selection='VulkanSlotStore.Bfloat16ScalarGatherReadsOnlyExactSelectedHalfwords:VulkanSlotStore.Float16ThreeElementGatherKeepsRawBitsAndOriginalPitch'
    result=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+selection,'--gtest_output=xml:'+str(xml)],e,A/'run',timeout=90)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase');assert root.attrib['tests']=='2' and root.attrib['failures']=='0' and len(cases)==2
    assert all(c.attrib.get('status')=='run' and not list(c) for c in cases)
    b.save(A/'summary.json',dict(status='BOTH_RAW16_GATHER_STORE_CHAINS_PASS',process=result,ready=b.pin(A/'ready.json'),results=b.pin(xml),cases=[c.attrib for c in cases],
        previous_four_case_results=b.pin(W/'results.xml'),existing_gap='Synchronous short-lease halfword D2H remains unsupported. Source oracle uses the same original completely initialized retained diagnostic pool; this is not a whole-pool Graph read permission.'))
    print('PASS',json.dumps(b.pin(A/'summary.json')),flush=True)
if __name__=='__main__':
    try:{'build':build,'run':run}[sys.argv[1]]()
    except Exception:b.save(A/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc()));raise
