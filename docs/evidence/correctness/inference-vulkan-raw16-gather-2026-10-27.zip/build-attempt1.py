"""One raw16 shader and five CXX units; no SDK/native frontend rebuild."""
from pathlib import Path
import importlib.util,json,os,struct,sys,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
S=R/'.scratch/inference-vulkan-halfword-store-20261027'
spec=importlib.util.spec_from_file_location('halfword_store_recipe',S/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
FILES=['src/compute_route_vulkan/build_shaders.py','src/compute_route_vulkan/shaders/raw16_gather.comp',
 'src/compute_route_vulkan/vulkan_program_internal.h','src/compute_route_vulkan/vulkan_pipeline.cc',
 'src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_region.cc',
 'tests/graph_route_vulkan/slot_store_test.cc']
def build():
    assert not (W/'freeze.json').exists(),'Preserve each attempt'
    h,e=old.env();compiler=Path('C:/public/tools/glslang/glslangValidator.exe')
    source=R/'.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e/src/ggml-vulkan/vulkan-shaders'
    product=[b.pin(R/p) for p in FILES]
    for path in FILES:
        dest=W/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((R/path).read_bytes())
    b.save(W/'product-freeze.json',product)
    shader_cmd=[sys.executable,str(R/'src/compute_route_vulkan/build_shaders.py'),'--compiler',str(compiler),
        '--source',str(source),'--tensor-source',str(R/'src/compute_route_vulkan/shaders'),
        '--output',str(W/'generated'),'--variant','raw16_gather','--output-stem','vulkan_raw16_shaders']
    process=h.execute(shader_cmd,e,W/'shader',timeout=90)
    raw=(W/'generated/raw16_gather.spv').read_bytes();words=struct.unpack('<'+'I'*(len(raw)//4),raw)
    caps=[];converts=0;at=5
    while at<len(words):
        count,op=words[at]>>16,words[at]&65535;assert count and at+count<=len(words)
        if op==17:caps.append(words[at+1])
        converts+=op==115;at+=count
    assert set(caps)=={1,4433} and converts==0
    b.save(W/'shader/inspection.json',dict(process=process,compiler=b.pin(compiler),shader=b.pin(W/'generated/raw16_gather.spv'),
      capabilities=caps,OpFConvert_count=converts,source=b.pin(R/FILES[1]),note='Only Shader and StorageBuffer16BitAccess; no sixteen-bit arithmetic capability.'))
    # Actual static compatibility proof for reused private readers. The old
    # descriptor fields keep offsets/size; every writer and new-field reader
    # is one of the newly compiled pipeline/program/region units below.
    check=W/'abi.h';check.write_text('''#pragma once
#include "vulkan_program_internal.h"
#include <cstddef>
namespace raw16_incremental_abi {
using namespace hyle::compute::vulkan::detail;
struct Before { std::uint32_t value=0,input_port=0; bool byte_origin=false; VkDescriptorBufferInfo buffer{}; VkWriteDescriptorSet write{}; };
static_assert(sizeof(Before)==sizeof(DescriptorBinding));
static_assert(alignof(Before)==alignof(DescriptorBinding));
static_assert(offsetof(Before,value)==offsetof(DescriptorBinding,value));
static_assert(offsetof(Before,input_port)==offsetof(DescriptorBinding,input_port));
static_assert(offsetof(Before,byte_origin)==offsetof(DescriptorBinding,byte_origin));
static_assert(offsetof(Before,buffer)==offsetof(DescriptorBinding,buffer));
static_assert(offsetof(Before,write)==offsetof(DescriptorBinding,write));
static_assert(offsetof(DescriptorBinding,storage_granularity)<offsetof(DescriptorBinding,buffer));
}
''',encoding='utf-8')
    units=[]
    for name,source_path,recipe in [
      ('pipeline',R/'src/compute_route_vulkan/vulkan_pipeline.cc',R/'.scratch/gdn-vulkan-output-scale-20261024/compile1/route--vulkan_pipeline/run/command.json'),
      ('program',R/'src/compute_route_vulkan/vulkan_program.cc',R/'.scratch/inference-native-host-image-20261026/current-vulkan-program/compile/vulkan_program/command.json'),
      ('lowerer',R/'src/compute_route_vulkan/vulkan_region.cc',old.V/'compile/vulkan-region/command.json'),
      ('shader',W/'generated/vulkan_raw16_shaders.cc',old.V/'compile/vulkan-region/command.json'),
      ('test',R/'tests/graph_route_vulkan/slot_store_test.cc',S/'retention/compile/test/command.json')]:
        command=m.command(recipe,source_path,W/'compile'/name)
        if name in ['pipeline','program','lowerer']:command.insert(1,'/FI'+str(check))
        b.save(W/'recipes'/f'{name}.json',dict(command=command,cwd=str(R),timeout_seconds=180))
        units.append(dict(name=name,source=b.pin(source_path),recipe=b.pin(W/'recipes'/f'{name}.json')))
    frozen=m.c.closure([u['source']['path'] for u in units],[u['recipe']['path'] for u in units]);b.save(W/'source-freeze.json',frozen)
    baseline=b.read(S/'retention/link-inputs.json');[b.exact(row) for row in baseline]
    b.save(W/'freeze.json',dict(products=product,units=units,abi_assertions=b.pin(check),source_freeze=b.pin(W/'source-freeze.json'),baseline=b.pin(S/'retention/link-inputs.json'),
      boundaries='Pipeline allocated only by recompiled vulkan_pipeline.cc. DescriptorBinding default creation in that TU and copies in recompiled vulkan_region.cc; new-field reader Invocation.bind in recompiled vulkan_program.cc. ProgramState/Dispatch/InvocationState unchanged. Static assertions compare old descriptor size/alignment/member offsets; no new field is read from an old constructor.',
      SDK=0,native_frontend=0,shader_compiles=1,CXX_TUs=5,models=0,downloads=0))
    own={b.key(row['path']):row for row in frozen};compiled=[];objects={}
    for unit in units:
        out=W/'compile'/unit['name'];result=h.execute(b.read(unit['recipe']['path'])['command'],e,out,timeout=180)
        data=b.read(out/'dependencies.json')['Data'];actual=[b.pin(p) for p in dict.fromkeys([data['Source'],*data['Includes']])];b.save(out/'actual-dependencies.json',actual)
        for row in actual:
            path=Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):assert own[b.key(path)]['sha256']==row['sha256'],path
        objects[unit['name']]=b.pin(out/'unit.obj');compiled.append(dict(unit=unit,object=objects[unit['name']],process=result,actual_dependencies=b.pin(out/'actual-dependencies.json')));b.save(W/'partial-build.json',compiled)
        [b.exact(row) for row in product]
    replacements={b.key(R/'.scratch/inference-native-host-image-20261026/current-vulkan-program/compile/vulkan_program/unit.obj'):objects['program'],
        b.key(old.V/'compile/vulkan-region/unit.obj'):objects['lowerer'],b.key(S/'retention/compile/test/unit.obj'):objects['test']}
    command=b.read(S/'retention/link/command.json')['command'];image=W/'bin/raw16-gather-test.exe';image.parent.mkdir(parents=True,exist_ok=True);seen=set()
    for i,arg in enumerate(command):
        if b.key(arg) in replacements:seen.add(b.key(arg));command[i]=replacements[b.key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):command[i]='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):command[i]='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):command[i]='/IMPLIB:'+str(image.with_suffix('.lib'))
    assert seen==set(replacements)
    command[1:1]=[objects[n]['path'] for n in ['pipeline','shader']]
    linked=h.execute(command,e,W/'link',timeout=120)
    inputs=[objects[n] for n in ['pipeline','shader']]+[replacements.get(b.key(row['path']),row) for row in baseline]
    b.save(W/'link-inputs.json',inputs)
    runtime=b.read(S/'retention/runtime.json');native=runtime['native'];b.exact(native);alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',compiled=compiled,link=linked,image=b.pin(image),inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),freeze=b.pin(W/'freeze.json'),shader=b.pin(W/'shader/inspection.json')))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run():
    ready=b.read(W/'ready.json');b.exact(ready['image']);assert not (W/'run').exists();h,e=old.env();e['PATH']=b.read(ready['runtime']['path'])['PATH'];xml=W/'results.xml'
    selection=':'.join('VulkanSlotStore.'+name for name in ['Bfloat16ScalarGatherReadsOnlyExactSelectedHalfwords','Float16ThreeElementGatherKeepsRawBitsAndOriginalPitch','Raw16GatherInvalidIdsRejectPublication','Float32DenseGeneratedRowsKeepExactOwnersAcrossReset'])
    result=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+selection,'--gtest_output=xml:'+str(xml)],e,W/'run',timeout=90)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase');assert root.attrib['tests']=='4' and root.attrib['failures']=='0' and len(cases)==4
    assert all(c.attrib.get('status')=='run' and not list(c) for c in cases)
    b.save(W/'summary.json',dict(status='RAW16_GATHER_THREE_PLUS_WORD_NEIGHBOR_PASS',process=result,ready=b.pin(W/'ready.json'),results=b.pin(xml),cases=[c.attrib for c in cases],scope='Two real partial-source Gather-to-Store cases (BF16 E1 and F16 E3), standalone checked invalid ID after valid execution, and one original F32 word-row neighbor. No engine/performance or broader hardware claim.'))
    print('PASS',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    try:{'build':build,'run':run}[sys.argv[1]]()
    except Exception:b.save(W/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc()));raise
