#pragma once
#include <cstdint>
#include <span>
namespace hyle::compute::vulkan::detail::shaders {
std::span<const std::uint32_t> raw16_gather() noexcept;
} // namespace hyle::compute::vulkan::detail::shaders
