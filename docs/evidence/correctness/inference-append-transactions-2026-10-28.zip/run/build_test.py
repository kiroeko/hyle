from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/inference-indexed-store-20261028/build.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
if sys.argv[1]=='compile':
 source=R/'tests/tools/inference_append_transactions_test.cc';out=W/'compile/test';out.mkdir(parents=True,exist_ok=False)
 old=t.command(R/'.scratch/inference-slot-cohort-refinement-20261028/logs/test/command.json');args=[]
 for i,a in enumerate(old):
  if i and old[i-1].casefold()=='/sourcedependencies':a=str(out/'dependencies.json')
  elif a.casefold().startswith('/fo'):a='/Fo'+str(out/'unit.obj')
  elif a.casefold().startswith('/fd'):a='/Fd'+str(out/'unit.pdb')
  elif a.casefold().endswith(('.cc','.cpp','.cxx')):a=str(source)
  args.append(a)
 before=t.pin(source);process=t.execute(args,W/'logs/test',180);t.exact(before)
 deps=[t.pin(x) for x in dict.fromkeys(t.dep_paths(out/'dependencies.json'))]
 t.save(out/'actual-dependencies.json',deps)
 t.save(out/'compiled.json',dict(source=before,object=t.pin(out/'unit.obj'),process=process,
  command=t.pin(W/'logs/test/command.json'),actual_dependencies=t.pin(out/'actual-dependencies.json')))
 print('CXX_PASS test')
elif sys.argv[1]=='link':
 base=t.read(R/'.scratch/inference-prefill-offset-refinement-20261028/ready-component.json')
 rows=t.read(base['inputs']['path']);unit=t.read(W/'compile/test/compiled.json')['object'];t.exact(unit)
 rows.append(unit)
 for x in rows:
  p=Path(x['path']);assert p.is_file() and p.stat().st_size==x['bytes'],p
 assert len(rows)==237
 image=W/'bin/test.exe';image.parent.mkdir(exist_ok=True);assert not image.exists()
 args=[]
 for a in t.command(base['recipe']['path']):
  for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
   if a.upper().startswith(prefix):a=prefix+str(image.with_suffix(suffix));break
  args.append(a)
 args.append(unit['path']);t.save(W/'inputs-test.json',rows)
 process=t.execute(args,W/'link/test',180)
 t.save(W/'ready-test.json',dict(image=t.pin(image),inputs=t.pin(W/'inputs-test.json'),recipe=t.pin(W/'link/test/command.json'),process=process))
 print('LINK_PASS test',len(rows))
else:raise ValueError(sys.argv[1])
