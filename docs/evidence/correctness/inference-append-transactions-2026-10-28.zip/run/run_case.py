from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/inference-indexed-store-20261028/build.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
name=sys.argv[1];binary=W/'bin'
source=R/'.scratch/inference-slot-cohort-refinement-20261028/bin/hyle_ggml_cpu_gdn_scale_v3.dll';target=binary/source.name
if not target.exists():os.link(source,target)
assert os.path.samefile(source,target)
fixture=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
if name=='test':
 args=[str(binary/'test.exe'),'--gtest_filter=InferenceAppendTransactions.*','--gtest_fail_fast',
  '--gtest_output=xml:'+str(W/'test-run/results.xml')]
elif name in ('tiny-cpu','tiny-cuda'):
 args=[str(binary/'tiny.exe'),'--'+name.split('-')[1],str(fixture),'--mtp-chunked-prefill']
elif name=='ragged-cuda':
 args=[str(binary/'tiny.exe'),'--cuda',str(fixture),'--mtp-ragged-prefill']
elif name in ('ordinary-relay','mtp-k2'):
 args=[str(binary/'model.exe'),'--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),
  '--capacity','512','--max-sessions','1','--active-sequences','1','--prefix-cache','off',
  '--progress','direct','--replay','auto','--mtp','off' if name=='ordinary-relay' else 'on',
  '--steps','16' if name=='ordinary-relay' else '8','--backend','cuda','--sampling','greedy','--warmup-shapes','planned']
 if name=='mtp-k2':args += ['--mtp-max-drafts','2']
else:raise ValueError(name)
out=W/(name+'-run');t.execute(args,out,240)
if name=='test':print('GTEST_PROCESS_PASS; inspect XML')
else:
 reports=[json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
 assert len(reports)==1,len(reports)
 report=reports[0];t.save(out/'report.json',report)
 print(json.dumps(dict(case=name,status=report.get('status','PROCESS_PASS'),
  generated=[x.get('result',{}).get('generated_ids') for x in report.get('sessions',[])],
  draft_calls=report.get('draft_program_graph_calls'),relay_steps=report.get('decode_overlap_steps')),indent=2))
