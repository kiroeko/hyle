from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
F=R/'.scratch/inference-append-transactions-refinement-20261028'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
sources=['engine/inference/append_transactions.h','engine/models/qwen35/main.cc',
 'tests/tools/qwen_mtp_chunked_prefill_case.h','tests/tools/inference_append_transactions_test.cc','tests/graph_batch/CMakeLists.txt']
for p in sources:
 out=W/'source'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((R/p).read_bytes())
tiny={}
for backend in ('cpu','cuda'):
 path=W/('tiny-'+backend+'-run/report.json');a=read(path)
 assert a['status']=='PASS' and a['numerically_equivalent']
 assert (a['C']['state_only_target_rows'],a['C']['state_only_draft_rows'])==(1,2)
 assert a['C']['state_only_pending']==-1 and a['C']['state_only_draw']==1
 assert a['C']['final_length']==a['C']['final_frontier']==7 and a['C']['final_draw']==2
 assert a['old_checkpoints_byte_unchanged'] and a['partial_restore_byte_equal']
 assert a['final_versions']==a['final_images']==a['final_native_episodes']==0
 diffs=[d for k in ('A','B','C') for d in a[k]['comparison']['differences']]
 assert all(d['role']==3 and not d['nonfinite_differences'] for d in diffs)
 tiny[backend]=dict(report=pin(path),status='PASS',
  maximum_absolute_gdn_error=max([d['maximum_absolute'] for d in diffs],default=0),
  catches_single_state_only=dict(target_rows=1,draft_rows=2,pending=-1,draw=1,
   final_length=7,final_frontier=7,final_draw=2),
  original_A_Q1_cancel_and_ledger_rebuild=True,original_B_lag1_and_partial_HostImage=True,
  final_versions=0,final_images=0,final_native_episodes=0)
ordinary=read(W/'ordinary-relay-run/report.json');mtp=read(W/'mtp-k2-run/report.json')
assert ordinary['decode_overlap'] and ordinary['overlap_successor_submissions']==ordinary['overlap_successor_publications']==7
assert ordinary['overlap_successor_refusals']==ordinary['overlap_successor_discards']==0
oi=ordinary['sessions'][0]['result']['generated_ids'];mi=mtp['sessions'][0]['result']['generated_ids']
assert len(oi)==16 and len(mi)==8 and oi[:8]==mi==[71093,12305,198,464,19298,198,1445,18904]
assert mtp['draft_program_graph_calls']==9
ragged=read(W/'ragged-cuda-run/report.json');assert ragged['status']=='PASS'
xml=ET.parse(F/'test-run/results.xml').getroot()
assert int(xml.attrib['tests'])==2 and int(xml.attrib['failures'])==int(xml.attrib['errors'])==0
assert not any(c.find('skipped') is not None for c in xml.iter('testcase'))
processes=[]
for folder in (W,F):
 for p in sorted(folder.rglob('process.json')):
  x=read(p);assert not x['timed_out']
  expected_failure=p==W/'test-run/process.json'
  assert x['exit']==(1 if expected_failure else 0),(p,x)
  processes.append(dict(path=str(p),expected_test_fixture_failure=expected_failure,**x))
target=R/'docs/evidence/correctness/inference-append-transactions-2026-10-28.json'
data=dict(date='2026-10-28',base_commit='90e232e17',status='Finite checks passed after one test readback correction',
 scope='Shared original Append bind/retired take/recovery and fourth teacher-forced StateOnly role; not complete execution-core extraction or performance closure.',
 sources=[pin(R/p) for p in sources],
 implementation=['AppendTransactions borrows existing node/transaction/bound spans, with no allocation, queue, permission, completion, publication policy or owner.',
  'Ordinary and relay Step, and NextN, share ordered original bind, successful atomic take, remembered partial recovery and original rollback/discard.',
  'Cold same-cohort cache input ports select reader or original write-only binding. NextN borrows exactly its two draft banks.',
  'Model keeps source construction, frame commit, accepted prefix, whole terminal status and real resource retirement; main net removes 35 lines.'],
 protocol_tests=dict(xml=pin(F/'test-run/results.xml'),passed=2,
  coverage=['Late second-bind refusal leaves the actual earlier transfer bound, refuses premature discard and recovers original reservations without ready authority.',
   'Real CPU Graph append effects followed by a deterministic rejected effect; completion gates recovery, a returned bank is not retaken, old bytes and page reacquisition remain correct.'],
  first_failure=dict(process=pin(W/'test-run/process.json'),source=pin(W/'failed-test-source.cc'),
   reason='Test read a full-page BufferView into a short initialized-prefix array; corrected readback size, no product code change. First process failed one test and skipped the second due fail-fast.'),
  failure_kind='Deterministic CPU Graph effect refusal, not a simulated native/device fault.'),
 tiny=tiny,
 real_consumers=dict(image=read(W/'ready-model.json')['image'],
  ordinary=dict(report=pin(W/'ordinary-relay-run/report.json'),outputs=16,successor_submissions=7,successor_publications=7,successor_refusals=0),
  recursive_MTP=dict(report=pin(W/'mtp-k2-run/report.json'),max_drafts=2,outputs=8,NextN_graph_calls=9),
  common_first_eight_ids=mi,performance_claim=False),
 b2_mtp_regression=dict(report=pin(W/'ragged-cuda-run/report.json'),status='PASS',backend='cuda',batches=7),
 numerical_contract='Only finite recomputed F32 GDN values use the inherited 3e-6 absolute component budget; other payloads, original checkpoints and state boundaries are strict.',
 processes=processes,cost=dict(CXX=4,links=4,consumer_processes=5,protocol_test_processes=2,SDK_builds=0,NVCC=0,downloads=0),
 remaining=['Current Apple/Vulkan exact StateOnly and cold packed fallback execution',
  'Larger shared execution orchestration and steady-state preparation','GPU hotspots, MTP device successor and current performance comparison'],
 limits=['Current Apple/Vulkan source audit found no definite fallback blocker; existing platform results do not cover these changes.',
  'New direct CatchupSingle StateOnly branch uses controlled real lag1 snapshots, not a natural acceptance-rate claim.',
  'No proof of speed improvement from fewer duplicated source lines or preserved output IDs.'])
save(target,data)
files={'evidence.json':target}
for folder,name in ((W,'run'),(F,'test-refinement')):
 for p in folder.rglob('*'):
  if p.is_file() and p.suffix.lower() in {'.json','.log','.py','.h','.cc','.xml','.txt'} and '__pycache__' not in p.parts:
   files[name+'/'+str(p.relative_to(folder)).replace('\\','/')]=p
manifest=[dict(name=k,**pin(v)) for k,v in sorted(files.items())]
archive=target.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,v in sorted(files.items()):z.write(v,k)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
save(W/'packaged.json',dict(evidence=pin(target),archive=pin(archive),members=len(manifest)+1))
print(json.dumps(read(W/'packaged.json'),indent=2))
