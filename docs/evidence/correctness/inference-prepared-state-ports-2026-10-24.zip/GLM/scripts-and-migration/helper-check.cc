#include "tests/compute_models/model_graph_run.h"
#include "engine/inference/backend.h"

#include <array>
#include <cstdio>
#include <stdexcept>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace i = hyle::inference;
void require(bool ok, const char *message) {
  if (!ok) throw std::runtime_error(message);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
int main() {
  try {
    auto backend = take(i::Backend::create({.primary = i::BackendKind::kCpu}));
    require(backend.host_only() && !backend.storage_owner().valid(), "CPU helper test acquired native storage");
    const std::array limits{c::ResourceBudgetLimit{backend.device(), 64 * 1024}};
    auto budget = take(c::ResourceBudget::create({.limits = limits, .allow_unattributed = true}));
    const auto baseline = take(budget.usage(backend.device())).live_bytes;
    std::array<float, 17> values{}, observed{};
    for (std::size_t n = 0; n < values.size(); ++n) values[n] = float(int(n) - 8) / 8.F;
    std::vector<c::ReadLease> retained;
    std::size_t submissions = 0;
    bool alias_rejected = false;
    {
      const auto description = take(c::TensorDesc::dense(c::DataType::kFloat32,
          std::array<std::int64_t, 1>{17}));
      auto builder = take(g::GraphBuilder::create());
      const auto x = take(builder.input(description));
      const auto y = take(builder.add(c::Unary{c::UnaryKind::kNeg}, x));
      check(builder.publish(y)); check(builder.publish(x));
      auto graph = take(std::move(builder).finish());
      auto compiled = take(backend.compile(graph, {}));
      const auto output = model_graph_run::prepare_output(compiled, {y, description});
      require(output.caller_owned(), "positive fixture was not caller-owned");
      const auto alias = take(i::prepare_output(compiled, x));
      require(alias.ownership == g::OutputOwnership::kSourceAlias, "negative fixture was not an actual source alias");
      try { (void)model_graph_run::prepare_output(compiled, {x, description}); }
      catch (const std::runtime_error &error) {
        alias_rejected = std::string_view(error.what()) == "ordinary model Graph requires caller-owned result storage";
      }
      require(alias_rejected, "cold preparation silently broadened caller-only policy");
      auto input = take(m::Buffer::create(backend.device(), sizeof(values), 256));
      check(input.view().write(std::as_bytes(std::span(values))));
      const std::array inputs{take(backend.adopt_buffer(std::move(input)))};
      auto pool = take(c::LeasePool::create(backend.device(), 512,
          {.max_blocks = 2, .backing_alignment = 256, .resource_budget = budget}));
      auto run = take(compiled.executable.create_invocation({.resources = g::ResourceOptions{}}));
      const std::array input_ports{model_graph_run::Port{x, description}};
      const std::array output_ports{output};
      retained = model_graph_run::execute(run, pool, *take(backend.common_queue()),
          input_ports, inputs, output_ports, submissions);
      require(submissions == 1 && retained.size() == 1, "shared helper did not finish exactly once");
      require(!run.result(y), "reset left completed output observable through the Invocation");
      require(retained[0].size() == sizeof(values), "retained output logical extent changed");
      check(take(retained[0].view()).read(std::as_writable_bytes(std::span(observed))));
      for (std::size_t n = 0; n < values.size(); ++n) require(observed[n] == -values[n], "retained result differs after reset");
    }
    const auto retained_live = take(budget.usage(backend.device())).live_bytes;
    require(retained_live > baseline, "output owner lost its finite pool charge after pool destruction");
    observed.fill(0);
    check(take(retained[0].view()).read(std::as_writable_bytes(std::span(observed))));
    for (std::size_t n = 0; n < values.size(); ++n)
      require(observed[n] == -values[n], "retained result died with Invocation/pool/CompiledGraph");
    retained.clear(); check(backend.collect_retired());
    require(take(budget.usage(backend.device())).live_bytes == baseline, "original caller pool did not retire to its control baseline");
    std::printf("{\"status\":\"PASS_MODEL_GRAPH_RUN_RETAIN_OUTPUT\",\"backend\":\"cpu\",\"compiled_image\":\"cpu+cuda\",\"CUDA_VISIBLE_DEVICES\":\"-1\",\"values\":17,\"submissions\":1,\"source_alias_cold_rejected\":true,\"lease_valid_after_reset_and_pool_destruction\":true,\"finite_budget_baseline\":%zu,\"finite_budget_retained_live\":%zu,\"retired_to_baseline\":true}\n", baseline, retained_live);
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "model_graph_run shared capture: %s\n", error.what()); return 1;
  }
}
