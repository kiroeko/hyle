from pathlib import Path
import importlib.util
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent / 'check1'
spec = importlib.util.spec_from_file_location('retained_tools', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
steps = {}
for name in ['flash-compile', 'pro-compile', 'flash-compile2', 'pro-compile2', 'toy-compile', 'toy-link', 'toy-run']:
    process = b.read(D / name / 'process.json')
    steps[name] = {'process': process, 'command': b.pin(D / name / 'command.json'),
        'stdout': b.pin(D / name / 'stdout.log'), 'stderr': b.pin(D / name / 'stderr.log')}
for name in ['flash-compile2', 'pro-compile2', 'toy-compile', 'toy-link', 'toy-run']:
    assert steps[name]['process']['exit'] == 0 and not steps[name]['process']['timeout']
assert steps['flash-compile']['process']['exit'] != 0 and steps['pro-compile']['process']['exit'] != 0
toy = json.loads((D / 'toy-run/stdout.log').read_text().strip())
assert toy['status'] == 'PASS_MODEL_GRAPH_RUN_RETAIN_OUTPUT' and toy['values'] == 17
pins = b.read(D / 'source-pins.json')
source_comparison = []
for row in pins:
    now = b.pin(Path(row['canonical']['path']))
    source_comparison.append({'path': now['path'], 'same_as_freeze': now['sha256'] == row['canonical']['sha256'],
        'frozen_sha256': row['frozen']['sha256'], 'canonical_now_sha256': now['sha256']})
summary = {
    'state': 'complete', 'purpose': 'bounded shared prepared output capture consumer migration',
    'actual_result': {'GLM_Flash_strict_consumer_compile': 'PASS', 'GLM_Pro_strict_consumer_compile': 'PASS',
        'shared_model_graph_run_actual_graph': 'PASS'},
    'GLM_compile_mode': 'original /c /O2 /W4 /WX CPU+CUDA retained command, not syntax-only',
    'GLM_runtime_runs': 0, 'source_pins': b.pin(D / 'source-pins.json'),
    'source_comparison': source_comparison, 'steps': steps, 'toy': toy,
    'first_attempt_setup_failures': {'paths': ['flash-compile', 'pro-compile'],
        'classification': 'private frozen source layout duplicated the same shared SamplingCursor header at two physical paths',
        'root_diagnostic': 'C2011 hyle::inference::SamplingCursor struct redefinition',
        'product_defect_claim': False, 'preserved': True,
        'correction': 'attempt2 compiled canonical unchanged consumer TUs and original include closure; before/after SHA equality checked'},
    'caller_pool_budget_and_capture': {'caller_only_cold_policy_preserved': True,
        'actual_source_alias_rejected_before_execute': True, 'original_inputs_and_pool_bindings_preserved': True,
        'retained_output_valid_after_reset': True, 'retained_output_valid_after_pool_invocation_graph_destruction': True,
        'finite_budget_remains_charged_until_last_lease_and_returns_to_baseline': True,
        'capture_does_not_add_new_controller_or_fallback': True},
    'execution_environment': b.read(D / 'runtime-selection.json'),
    'successful_consumer_translation_units_compiled': 3, 'additional_first_attempt_failed_compilations': 2,
    'SDK_builds': 0, 'HTTP_requests': 0, 'full_model_runs': 0, 'performance_claim': False,
    'limitations': ['GLM actual source math/state journeys were not repeated; these were strict complete consumer TU compiles',
        'generic helper actual runtime used one CPU graph in retained CPU+CUDA image; CUDA devices hidden',
        'generated output support remains intentionally rejected by the two GLM fixture callers; no allocator policy broadening']}
b.save(D / 'summary.json', summary)
archive = D / 'logs.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for path in [D.parent / 'check.py', D.parent / 'helper-check.cc', D.parent / 'package-check.py',
            D.parent / 'consumer-migration.json', *(D.parent.glob('*.patch'))]:
        z.write(path, 'scripts-and-migration/' + path.name)
    for path in sorted(D.rglob('*')):
        if not path.is_file() or path == archive or path.name in {'live.json', 'dependencies.json'}: continue
        if path.suffix not in {'.json', '.log', '.cc', '.h'}: continue
        z.write(path, str(path.relative_to(D)))
print(json.dumps({'summary': b.pin(D / 'summary.json'), 'archive': b.pin(archive),
    'canonical_source_unchanged_since_freeze': all(x['same_as_freeze'] for x in source_comparison)}, indent=2))
