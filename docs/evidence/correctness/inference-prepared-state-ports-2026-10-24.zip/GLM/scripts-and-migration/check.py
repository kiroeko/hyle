from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent / 'check1'
R = D.parents[2]
S = D / 'source'
spec = importlib.util.spec_from_file_location('retained_tools', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
CUDA = R / '.scratch/qwen-cpu-gpu-backend-20261024/cuda-regression1'

def freeze():
    D.mkdir(exist_ok=False); S.mkdir()
    sources = [R / 'tests/compute_models' / name for name in ['model_graph_run.h',
        'glm_mtp_state_consumer_test.cc', 'glm_pro_mtp_state_consumer_test.cc']]
    sources += list((R / 'engine/inference').glob('*.h'))
    pins = []
    for source in sources:
        target = S / source.relative_to(R); target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes()); pins.append({'canonical': b.pin(source), 'frozen': b.pin(target)})
    (S / 'helper-check.cc').write_bytes((D.parent / 'helper-check.cc').read_bytes())
    b.save(D / 'source-pins.json', pins)

def compile(previous, source, folder, frozen=True):
    original = b.args(previous); command = [original[0]]
    if frozen: command.append('/I' + str(S))
    command.append('/I' + str(R / 'tests/compute_models'))
    skip = False
    for word in original[1:]:
        if skip: skip = False; continue
        if word == '/sourceDependencies': skip = True; continue
        lower = word.lower().replace('\\', '/')
        if lower.startswith(('/fo', '/fd')) or lower.endswith(('.cc', '.cpp')): continue
        if lower.startswith('/i') and '/.scratch/' in lower and lower.endswith('/source'): continue
        command.append(word)
    command += ['/I' + str(R), '/I' + str(R / 'include'), '/sourceDependencies',
        str(folder / 'dependencies.json'), str(source), '/Fo' + str(folder / 'unit.obj'), '/Fd' + str(folder / 'unit.pdb')]
    env = b.environment(command[0]); b.execute(command, folder, env, 180)
    own = [Path(p) for p in b.read(folder / 'dependencies.json')['Data']['Includes'] if Path(p).is_relative_to(R)]
    b.save(folder / 'hyle-header-pins.json', [b.pin(p) for p in own])
    return env

def glm(name):
    pro = name == 'pro'
    previous = R / '.scratch/glm-random-mtp-20261024' / ('pro/compile1/command.json' if pro else 'compile3/command.json')
    relative = Path('tests/compute_models') / ('glm_pro_mtp_state_consumer_test.cc' if pro else 'glm_mtp_state_consumer_test.cc')
    source = S / relative
    compile(previous, source, D / (name + '-compile'))

def glm_canonical(name):
    pro = name == 'pro'
    previous = R / '.scratch/glm-random-mtp-20261024' / ('pro/compile1/command.json' if pro else 'compile3/command.json')
    relative = Path('tests/compute_models') / ('glm_pro_mtp_state_consumer_test.cc' if pro else 'glm_mtp_state_consumer_test.cc')
    canonical = R / relative; frozen = S / relative
    before = b.pin(canonical)
    assert before['sha256'] == b.pin(frozen)['sha256']
    compile(previous, canonical, D / (name + '-compile2'), frozen=False)
    assert b.pin(canonical) == before
    b.save(D / (name + '-compile2/source-unchanged.json'), {'before': before, 'after': b.pin(canonical),
        'frozen_source_sha256': b.pin(frozen)['sha256'], 'one_physical_common_header_tree': True})

def toy():
    env = compile(CUDA / 'compile/command.json', S / 'helper-check.cc', D / 'toy-compile')
    old = str(CUDA / 'compile/backend-test.obj'); original = b.args(CUDA / 'link/command.json')
    assert old in original
    command = [str(D / 'toy-compile/unit.obj') if word == old else word for word in original
        if not word.upper().startswith(('/OUT:', '/MAP:', '/PDB:', '/IMPLIB:'))]
    image = D / 'toy-link/helper-check.exe'; command.append('/OUT:' + str(image))
    b.execute(command, D / 'toy-link', env, 120)
    native = []
    for source in (CUDA / 'link').glob('*.dll'):
        os.link(source, image.parent / source.name); native.append(b.pin(source))
    b.save(image.parent / 'native.json', native)
    env['PATH'] = b.read(CUDA / 'ready.json')['PATH']; env['CUDA_VISIBLE_DEVICES'] = '-1'
    b.save(D / 'runtime-selection.json', {'CUDA_VISIBLE_DEVICES': '-1', 'selected_primary': 'cpu',
        'compiled_image': ['cpu', 'cuda'], 'native': native, 'runtime_base': b.pin(CUDA / 'ready.json')})
    b.R = D / 'toy-run'; b.execute([str(image)], D / 'toy-run', env, 30)

if __name__ == '__main__':
    {'freeze': freeze, 'flash': lambda: glm('flash'), 'pro': lambda: glm('pro'),
        'flash2': lambda: glm_canonical('flash'), 'pro2': lambda: glm_canonical('pro'), 'toy': toy}[sys.argv[1]]()
