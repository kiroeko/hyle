#include "engine/inference/prepared_output.h"
#include "tests/compute/native_context_fixture.h"
#include "hyle/mem/buffer.h"

#include <array>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <algorithm>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace i = hyle::inference;

template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status result) {
  if (!result.ok()) throw std::runtime_error(std::string(result.message()));
}
void require(bool condition, const char *message) {
  if (!condition) throw std::runtime_error(message);
}
c::TensorDesc row(std::int64_t count) {
  return take(c::TensorDesc::dense(c::DataType::kFloat32, std::array{count}));
}
void facts(const g::CompiledGraph &compiled, g::ValueId value,
           c::TensorDesc description, g::OutputOwnership ownership) {

  std::vector<i::PreparedOutputFacts> all(compiled.executable.output_count());
  std::size_t capacity = 0;
  for (std::size_t n = 0; n < all.size(); ++n)
    capacity = (std::max)(capacity, std::size_t(take(compiled.executable.output_id(n)).ordinal()) + 1);
  std::vector<std::uint32_t> indices(capacity);
  check(i::prepare_outputs(compiled, all, indices));
  for (const auto &fact : all) {
    const auto single = take(i::prepare_output(compiled, fact.value));
    require(fact.value == single.value && fact.description == single.description &&
        fact.storage == single.storage && fact.ownership == single.ownership &&
        all[indices[fact.value.ordinal()]].value == fact.value, "bulk and concrete output facts differ");
  }
  require(!i::prepare_outputs(compiled, {}, indices).ok(), "wrong bulk output count accepted");
  require(!i::prepare_outputs(compiled, all, {}).ok(), "short ordinal index accepted");
  const auto output = take(i::prepare_output(compiled, value));
  require(output.value == value, "wrong output identity");
  require(output.description == description, "wrong actual output description");
  require(output.storage == g::StorageDomainId{0}, "wrong actual output storage");
  require(output.ownership == ownership, "wrong actual output ownership");
  require(output.caller_owned() == (ownership == g::OutputOwnership::kCaller),
          "caller binding policy disagrees with actual ownership");
}

int main() {
  try {
    auto context = take(c::test::native_context());
    auto builder = take(g::GraphBuilder::create());
    const auto input = take(builder.input(row(6)));
    const auto constant = take(builder.constant(row(6)));
    const auto computed = take(builder.add(c::RmsNorm{}, input));
    const auto internal = take(builder.add(c::RmsNorm{}, computed));
    const auto view = take(builder.add(take(c::View::slice(0, 2, 3)), internal));
    for (const auto value : {input, constant, computed, view}) check(builder.publish(value));
    auto graph = take(std::move(builder).finish());
    auto backing = take(m::Buffer::create(m::system_resource(), 6 * sizeof(float), 64));
    const std::array<float, 6> values{1, 2, 3, 4, 5, 6};
    check(backing.view().write(std::as_bytes(std::span(values))));
    const auto tensor = take(c::ConstTensorView::create(row(6), backing.view()));
    const std::array constants{g::ConstantBinding{constant, tensor, g::ConstantPolicy::kMaterialize}};
    auto compiled = take(g::compile(graph, context, {.constants = constants}));
    require(!compiled.executable.is_shape_domain(), "static default compile unexpectedly symbolic");
    facts(compiled, input, row(6), g::OutputOwnership::kSourceAlias);
    facts(compiled, constant, row(6), g::OutputOwnership::kExecutable);
    facts(compiled, computed, row(6), g::OutputOwnership::kCaller);
    facts(compiled, view, row(3), g::OutputOwnership::kInvocation);
    auto missing = i::prepare_output(compiled, internal);
    require(!missing && missing.error().IsNotFound(), "nonpublished value accepted");
    auto invalid = i::prepare_output(compiled, {});
    require(!invalid && invalid.error().IsInvalidArgument(), "invalid value accepted");
    auto no_compile = i::prepare_output(g::CompiledGraph{}, input);
    require(!no_compile && no_compile.error().IsFailedPrecondition(), "invalid compiled pair accepted");

    auto dynamic = take(g::GraphBuilder::create());
    const auto rows = take(dynamic.dimension({1, 2, 1}));
    const auto spec = take(g::TensorSpec::dense(c::DataType::kFloat32,
        std::array{g::Dimension(rows), g::Dimension::fixed(4)}));
    const auto dynamic_input = take(dynamic.input(spec));
    const auto dynamic_output = take(dynamic.add(c::RmsNorm{}, spec, dynamic_input));
    check(dynamic.publish(dynamic_output));
    auto dynamic_graph = take(std::move(dynamic).finish());
    const std::array shape0{g::ShapeBinding{rows, 1}};
    const std::array shape1{g::ShapeBinding{rows, 2}};
    const std::array variants{g::ExactShapeVariant{shape0}, g::ExactShapeVariant{shape1}};
    auto family = take(g::compile(dynamic_graph, context,
        {.shape_policy = g::CompileShapePolicy::kFiniteExact, .exact_variants = variants}));
    auto parent = i::prepare_output(family, dynamic_output);
    require(!parent && parent.error().IsFailedPrecondition(), "finite parent accepted as concrete");
    auto child0 = g::CompiledGraph{take(family.executable.exact_variant(0)), take(family.report.exact_variant(0))};
    auto child1 = g::CompiledGraph{take(family.executable.exact_variant(1)), take(family.report.exact_variant(1))};
    facts(child0, dynamic_output, take(c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t, 2>{1, 4})), g::OutputOwnership::kCaller);
    facts(child1, dynamic_output, take(c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t, 2>{2, 4})), g::OutputOwnership::kCaller);
    std::array<i::PreparedOutputFacts, 1> outputs;
    std::vector<std::uint32_t> index(std::size_t(dynamic_output.ordinal()) + 1);
    require(i::prepare_outputs(family, outputs, index).IsFailedPrecondition(), "bulk parent was accepted");
    require(i::prepare_outputs(g::CompiledGraph{child0.executable, child1.report}, outputs, index).IsInvalidArgument(),
        "bulk mismatch exact child was accepted");
    auto mismatched = i::prepare_output(g::CompiledGraph{child0.executable, child1.report}, dynamic_output);
    require(!mismatched && mismatched.error().IsInvalidArgument(), "different exact child report accepted");
    std::cout << "{\"passed\":true,\"actual_ownerships\":4,\"static_default_route\":true,"
                 "\"finite_children\":2,\"nonpublished_rejected\":true,\"invalid_rejected\":true,"
                 "\"finite_parent_rejected\":true,\"mismatched_child_rejected\":true,"
                 "\"GPU\":0,\"models\":0,\"HTTP\":0}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
