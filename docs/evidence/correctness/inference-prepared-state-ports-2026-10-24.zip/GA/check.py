"""One reviewed private fixture alignment correction; no product/math change."""
from pathlib import Path
import difflib,importlib.util,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;FIRST=D.parent
spec=importlib.util.spec_from_file_location('first_check',FIRST/'check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.D=D
def build():
 old=(FIRST/'gdn.cc').read_text(encoding='utf8');new=old
 changes=[
  ('(void)name; std::size_t n=1; for(auto d:p.shape) n*=static_cast<std::size_t>(d); expected+=n*2;',
   'const bool scalar_f32=p.allow_f32 && p.shape==std::vector<std::int64_t>{1} && (name.ends_with(".A_log") || name.ends_with(".dt_bias"));\n    std::size_t n=1; for(auto d:p.shape) n*=static_cast<std::size_t>(d); expected+=n*(scalar_f32?4:2);'),
  ('payload.write(reinterpret_cast<const char*>(values.data()),static_cast<std::streamsize>(n*2));\n    manifest<<name<<" BF16 "<<p.shape.size();for(auto d:p.shape)manifest<<\' \'<<d;\n    manifest<<\' \'<<std::quoted(body.generic_string())<<\' \'<<offset<<\' \'<<n*2<<\'\\n\';\n    offset+=n*2;++index;',
   'const bool scalar_f32=p.allow_f32 && p.shape==std::vector<std::int64_t>{1} && (name.ends_with(".A_log") || name.ends_with(".dt_bias"));\n    const std::size_t bytes=n*(scalar_f32?4:2);\n    if(scalar_f32) { const float exact_zero=0.F; payload.write(reinterpret_cast<const char*>(&exact_zero),4); }\n    else payload.write(reinterpret_cast<const char*>(values.data()),static_cast<std::streamsize>(bytes));\n    manifest<<name<<(scalar_f32?" F32 ":" BF16 ")<<p.shape.size();for(auto d:p.shape)manifest<<\' \'<<d;\n    manifest<<\' \'<<std::quoted(body.generic_string())<<\' \'<<offset<<\' \'<<bytes<<\'\\n\';\n    offset+=bytes;++index;')]
 for before,after in changes:
  m.require(new.count(before)==1,'Unexpected private fixture source');new=new.replace(before,after)
 with(D/'gdn.cc').open('x',encoding='utf8',newline='\n')as f:f.write(new)
 (D/'fixture-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='first/gdn.cc',tofile='gdn2/gdn.cc')),encoding='utf8')
 m.b.save(D/'fixture-correction.json',dict(first_failure=m.b.pin(FIRST/'first-failure.json'),original_probe=m.b.pin(FIRST/'gdn.cc'),corrected_probe=m.b.pin(D/'gdn.cc'),delta='Only allow_f32=true singleton A_log/dt_bias store exact F32 zero4B instead of exact BF16 zero2B; all other role bytes, geometry, values, state-control and runtime configuration unchanged.',actual_failed_processes_before_correction=1,corrected_model_process_limit=2,SDK_builds=0,HTTP=0))
 m.freeze();m.compile('old');m.compile('current')
if __name__=='__main__':
 if sys.argv[1]=='build':build()
 elif sys.argv[1]=='run':m.run()
 else:raise SystemExit('build|run')
