"""One bounded ordinary/MTP shared-state-port migration evidence bundle."""
from pathlib import Path
import hashlib
import json
import zipfile

D = Path(__file__).resolve().parent
R = D.parents[1]
G = D/'gdn-regression/gdn2'
M = R/'.scratch/mtp-output-capture-migration-20261024/check1'
C = D/'check1'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def pin(path): return {'path': path.relative_to(R).as_posix(), 'bytes': path.stat().st_size,
                       'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
g = read(G/'summary-final.json'); m = read(M/'summary.json'); witness = read(G/'state-witnesses.json')
assert g['state'] == 'passed' and g['all_state_bytes_equal'] and not g['report_differences']
assert witness['all_GDN_snapshots_nonzero_finite'] and witness['selected_prefix1_differs_from_prefix0_and_prefix2']
assert m['state'] == 'complete' and all(x['same_as_freeze'] for x in m['source_comparison'])
assert all(read(C/x/'process.json')['exit'] == 0 for x in ['bulk-compile','bulk-link','bulk-run',
    'probe-syntax','tiny-compile','tiny-link','tiny-run'])
for row in read(C/'source-pins.json'):
    for kind in ['canonical', 'frozen']:
        p = Path(row[kind]['path']); assert pin(p)['sha256'] == row[kind]['sha256']
tiny = next(json.loads(line) for line in (C/'tiny-run/stdout.log').read_text().splitlines() if line.startswith('{'))
assert tiny['status'] == 'PASS_TINY_PHASE_READBACK' and tiny['cursor'] == 6 and tiny['classic_cursors'] == [4,4]
out = R/'docs/evidence/correctness/inference-prepared-state-ports-2026-10-24'
archive = out.with_suffix('.zip')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for prefix, previous in [('GA', G/'logs.zip'), ('GLM', M/'logs.zip')]:
        with zipfile.ZipFile(previous) as source:
            assert source.testzip() is None
            for entry in source.infolist():
                if not entry.is_dir(): z.writestr(prefix+'/'+entry.filename, source.read(entry))
    extras = [G/'summary-final.json', G/'state-witnesses.json', D/'gdn-regression/first-failure.json',
              D/'gdn-regression/gdn.cc', Path(__file__), D/'check.py']
    extras += [p for p in (D/'gdn-regression/old/run').glob('*') if p.suffix in {'.json','.log'}]
    for path in extras: z.write(path, 'extra/'+path.relative_to(R/'.scratch').as_posix())
    # Retain only this current engine/test source closure and exact commands,
    # logs and results, never objects, executables, SDKs or model weights.
    for path in C.rglob('*'):
        if path.is_file() and path.suffix in {'.cc','.h','.json','.log'}:
            z.write(path, 'current/'+path.relative_to(C).as_posix())
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
result = {
    'status': 'PASS bounded ordinary/MTP prepared output and state capture migration',
    'scope': 'Shared lower-level inference assembly; no new scheduler/executor, application/server, model math or precision policy',
    'changes': [
        'Each exact child stores only published output facts and one compact ValueId ordinal index; duplicate caller bitmap and model-private description scans removed.',
        'Cold bulk preparation scans published outputs and physical reports once; full ValueId, exact route, ambiguity and missing output checks remain.',
        'Ordinary and MTP GDN/history/carry binding and capture use actual cold descriptions/ownership; persistent logits/hidden/probes allocate in their actual resource domain.',
        'Original output leases are captured before append extraction/reset, preserving model-specific prefix selection, repair, budgets and atomic state/pending/RNG publication.',
        'Two GLM real component consumers use the same facts and capture helper while keeping their existing caller-pool and model contracts.'
    ],
    'actual_checks': {
        'CPU_bulk_facts': {'four_actual_ownerships': True, 'finite_children': 2,
            'wrong_count_and_short_index_rejected': True, 'finite_parent_and_mismatched_child_rejected': True},
        'untrained_GA_state_comparison': {'reports': g['reports'], 'state_files_compared': len(g['state_files']['current']),
            'all_state_bytes_equal': g['all_state_bytes_equal'], 'nonzero_finite_GDN_and_distinct_prefixes': True,
            'summary': pin(G/'summary-final.json'), 'witness': pin(G/'state-witnesses.json')},
        'existing_untrained_A_natural_K2_and_R2': tiny,
        'GLM_consumer_compile_and_shared_graph': {'actual_result': m['actual_result'],
            'GLM_compile_mode': m['GLM_compile_mode'], 'GLM_runtime_runs': m['GLM_runtime_runs'],
            'toy': m['toy'], 'summary': pin(M/'summary.json')},
        'CPU_projection_probe_strict_syntax': read(C/'probe-syntax/process.json')
    },
    'source': [pin(R/p) for p in ['engine/inference/prepared_output.h','engine/models/qwen35/main.cc',
        'tests/compute_models/model_graph_run.h','tests/compute_models/glm_mtp_state_consumer_test.cc',
        'tests/compute_models/glm_pro_mtp_state_consumer_test.cc','tests/tools/qwen_mtp_projection_width_probe.cc']],
    'first_attempts_preserved': [
        'Private GA fixture used two 2-byte BF16 scalars, violating Vulkan file-stream alignment before execution; corrected only to legal allow_f32 scalar zeros for the same old/current comparison.',
        'Private GLM source freeze mixed duplicated physical headers; corrected to canonical TU compilation with before/after source pins. No product workaround.'
    ],
    'limits': ['GA consumed2 is an explicit state control, not natural acceptance evidence.',
        'Small untrained fixtures and helper tests do not establish trained-model quality or end-to-end speed.',
        'No full GLM model or new backend/model matrix was run; complete architecture and performance remain active.'],
    'SDK_builds': 0, 'HTTP': 0, 'performance_claim': False, 'archive': pin(archive)
}
out.with_suffix('.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
print(json.dumps({'result': pin(out.with_suffix('.json')), 'archive': pin(archive)}))
