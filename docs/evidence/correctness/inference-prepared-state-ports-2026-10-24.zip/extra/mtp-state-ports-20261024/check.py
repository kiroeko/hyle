"""One cold-facts CPU check and one reused finite Vulkan consumer."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[1]
OUT = D/'check1'
S = OUT/'source'
spec = importlib.util.spec_from_file_location('state_ports_tools', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)

def freeze():
    if S.exists(): return
    S.mkdir(parents=True)
    sources = [R/'engine/models/qwen35/main.cc', *(R/'engine/models/qwen35').glob('*.h'),
        *(R/'engine/inference').glob('*.h'), R/'tests/tools/qwen_mtp_projection_width_probe.cc']
    pins = []
    for path in sources:
        target = S/path.relative_to(R); target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes()); pins.append({'canonical': b.pin(path), 'frozen': b.pin(target)})
    b.save(OUT/'source-pins.json', pins)
    original = R/'.scratch/mtp-runtime-backend-20261024/verification1/source/tiny.cc'
    (S/'tiny.cc').write_bytes(original.read_bytes())
    old = (R/'.scratch/prepared-output-20261024/cpu-probe.cc').read_text()
    old = old.replace('#include <string>', '#include <string>\n#include <vector>\n#include <algorithm>')
    hook = '''
  std::vector<i::PreparedOutputFacts> all(compiled.executable.output_count());
  std::size_t capacity = 0;
  for (std::size_t n = 0; n < all.size(); ++n)
    capacity = (std::max)(capacity, std::size_t(take(compiled.executable.output_id(n)).ordinal()) + 1);
  std::vector<std::uint32_t> indices(capacity);
  check(i::prepare_outputs(compiled, all, indices));
  for (const auto &fact : all) {
    const auto single = take(i::prepare_output(compiled, fact.value));
    require(fact.value == single.value && fact.description == single.description &&
        fact.storage == single.storage && fact.ownership == single.ownership &&
        all[indices[fact.value.ordinal()]].value == fact.value, "bulk and concrete output facts differ");
  }
  require(!i::prepare_outputs(compiled, {}, indices).ok(), "wrong bulk output count accepted");
  require(!i::prepare_outputs(compiled, all, {}).ok(), "short ordinal index accepted");
'''
    marker = '  const auto output = take(i::prepare_output(compiled, value));'
    assert old.count(marker) == 1
    old = old.replace(marker, hook + marker)
    marker = '    auto mismatched = i::prepare_output(g::CompiledGraph{child0.executable, child1.report}, dynamic_output);'
    extra = '''    std::array<i::PreparedOutputFacts, 1> outputs;
    std::vector<std::uint32_t> index(std::size_t(dynamic_output.ordinal()) + 1);
    require(i::prepare_outputs(family, outputs, index).IsFailedPrecondition(), "bulk parent was accepted");
    require(i::prepare_outputs(g::CompiledGraph{child0.executable, child1.report}, outputs, index).IsInvalidArgument(),
        "bulk mismatch exact child was accepted");
'''
    assert old.count(marker) == 1
    (S/'bulk.cc').write_text(old.replace(marker, extra + marker))

freeze()
if sys.argv[1] == 'bulk':
    env = b.compile(S/'bulk.cc', OUT/'bulk-compile')
    image = b.link(OUT/'bulk-compile/unit.obj', OUT/'bulk-link', env)
    env.update({k: v for k, v in b.read(b.CPU/'runtime-environment.json').items() if isinstance(v, str)})
    b.execute([str(image)], OUT/'bulk-run', env, 60)
elif sys.argv[1] == 'tiny-build':
    env = b.compile(S/'tiny.cc', OUT/'tiny-compile', vulkan=True)
    image = b.link(OUT/'tiny-compile/unit.obj', OUT/'tiny-link', env, vulkan=True)
    b.save(OUT/'tiny-ready.json', {'image': b.pin(image), 'environment': b.pin(b.VK/'runtime.json')})
elif sys.argv[1] == 'tiny-run':
    image = OUT/'tiny-link/probe.exe'
    assert b.pin(image) == b.read(OUT/'tiny-ready.json')['image']
    env = b.environment(b.args(b.CPU/'compile-command.json')[0])
    env.update({k: v for k, v in b.read(b.VK/'runtime.json').items() if isinstance(v, str)})
    b.execute([str(image), str(OUT/'tiny-run')], OUT/'tiny-run', env, 60)
elif sys.argv[1] == 'probe-syntax':
    b.compile(S/'tests/tools/qwen_mtp_projection_width_probe.cc', OUT/'probe-syntax', syntax=True)
else:
    raise SystemExit('bulk | tiny-build | tiny-run | probe-syntax')
