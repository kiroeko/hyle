// Actual untrained GA Model state regression. The T3 accepted prefix is an
// explicit consumed2 state control, not a natural acceptance/quality claim.
#include "engine/models/qwen35/main.cc"
#include "hyle/compute/detail/paged_arena_access.h"

namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;
void require(bool yes, const char* message) { if (!yes) throw std::runtime_error(message); }
q::ModelGeometry geometry() {
  q::ModelGeometry s;
  s.hidden=64; s.intermediate=128; s.vocabulary=64;
  s.query_heads=s.kv_heads=1; s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=s.gdn_value_heads=1; s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4; s.context_limit=16; s.rope_theta=10000; s.epsilon=1.e-6F;
  s.tied_head=true; s.layers="GA"; s.mtp_layers=1; s.validate(); return s;
}
std::pair<std::filesystem::path,std::size_t> weights(const std::filesystem::path& folder,const q::ModelGeometry& s) {
  std::size_t expected=0;
  for (const auto& [name,p] : q::prepared::parameter_inventory(true,s)) {
    (void)name; std::size_t n=1; for(auto d:p.shape) n*=static_cast<std::size_t>(d); expected+=n*2;
  }
  require(expected<1024*1024,"GA fixture exceeds1MiB");
  const auto body=folder/"untrained-bf16.bin", list=folder/"weights.tsv";
  if(std::filesystem::exists(list)) {
    require(std::filesystem::file_size(body)==expected,"shared fixture size changed");
    return {list,expected};
  }
  std::filesystem::create_directories(folder);
  std::ofstream payload(body,std::ios::binary), manifest(list);
  require(bool(payload)&&bool(manifest),"cannot create GA fixture");
  manifest<<"HYLE_QWEN_ROLE_FILES_V2\n"<<std::string(64,'6')<<'\n'
    <<"geometry 64 128 64 1 1 64 64 64 1 1 64 64 4 16 10000 1e-6 1 1 grouped \"GA\"\n";
  std::size_t offset=0,index=0;
  for(const auto& [name,p]:q::prepared::parameter_inventory(true,s)) {
    std::size_t n=1;for(auto d:p.shape)n*=static_cast<std::size_t>(d);
    std::vector<std::uint16_t> values(n);
    for(std::size_t i=0;i<n;++i) {
      const float value=p.shape.size()==1?0.F:.03F*std::sin(float(i+index*17)*.13F);
      auto bits=std::bit_cast<std::uint32_t>(value);bits+=0x7fffU+((bits>>16)&1U);
      values[i]=static_cast<std::uint16_t>(bits>>16);
    }
    payload.write(reinterpret_cast<const char*>(values.data()),static_cast<std::streamsize>(n*2));
    manifest<<name<<" BF16 "<<p.shape.size();for(auto d:p.shape)manifest<<' '<<d;
    manifest<<' '<<std::quoted(body.generic_string())<<' '<<offset<<' '<<n*2<<'\n';
    offset+=n*2;++index;
  }
  require(bool(payload)&&bool(manifest)&&offset==expected,"GA fixture write differs");return {list,expected};
}
Bytes read(q::Model& model,const c::ReadLease& lease) {
  if(!lease.valid())return{};
  Bytes result(lease.size());q::check(model.execution.read(q::take(lease.view()),result));return result;
}
void store(const std::filesystem::path& file,const Bytes& bytes) {
  std::filesystem::create_directories(file.parent_path());std::ofstream out(file,std::ios::binary);
  out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
  require(bool(out),"cannot write actual state bytes");
}
Bytes logical_rows(q::Model& model,const c::PagedArena& arena,const c::PagedArenaRead& frame,std::size_t rows,std::size_t row_bytes) {
  const auto layout=frame.layout().host();const auto pages=(rows+15)/16;
  require(frame.valid()&&layout.page_indices.size()==pages&&frame.page_count()==pages,"logical state page footprint differs");
  Bytes result(rows*row_bytes);std::size_t at=0;
  const auto guards=c::detail::PagedArenaAccess::pages(frame);
  for(std::size_t i=0;i<pages;++i) {
    const c::ReadLease* selected=nullptr;
    for(const auto& guard:guards)if(q::take(c::detail::PagedArenaAccess::page(arena,guard))==static_cast<std::uint32_t>(layout.page_indices[i]))selected=&guard;
    require(selected!=nullptr,"logical page lost original read guard");
    const auto bytes=(std::min)(16*row_bytes,result.size()-at);
    q::check(model.execution.read(q::take(q::take(selected->view()).subview(0,bytes)),std::span(result).subspan(at,bytes)));at+=bytes;
  }
  return result;
}
using Image=std::map<std::string,Bytes>;
Image image(q::Model& model,const q::cache::Snapshot& head) {
  Image result;
  const auto add=[&](std::string name,const c::ReadLease& lease){if(lease.valid())result.emplace(std::move(name),read(model,lease));};
  for(std::size_t i=0;i<head.state.size();++i)if(model.geometry.is_gdn(i)) {
    add("gdn"+std::to_string(i)+".history.bf16",head.state[i].history);
    add("gdn"+std::to_string(i)+".recurrent.f32",head.state[i].recurrent);
  }
  for(std::size_t i=0;i<head.keys.size();++i) {
    result.emplace("target"+std::to_string(i)+".key.bf16",logical_rows(model,model.page_inventory.keys[i],head.keys[i],head.length,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("target"+std::to_string(i)+".value.bf16",logical_rows(model,model.page_inventory.values[i],head.values[i],head.length,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  add("carry.bf16",head.carry_hidden);add("prior.bf16",head.prior_hidden);
  if(head.draft) {
    result.emplace("draft.key.bf16",logical_rows(model,model.draft_inventory.keys[0],head.draft->key,head.draft->frontier,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("draft.value.bf16",logical_rows(model,model.draft_inventory.values[0],head.draft->value,head.draft->frontier,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  std::ostringstream meta;
  meta<<"length="<<head.length<<" next="<<head.next_id<<" seed="<<head.sampling.seed<<" stream="<<head.sampling.stream<<" draw="<<head.sampling.draw;
  if(head.draft)meta<<" frontier="<<head.draft->frontier<<" lag="<<head.draft->lag<<" catchup="<<head.draft->catchup_token;
  const auto text=meta.str();result.emplace("metadata.txt",Bytes(reinterpret_cast<const std::byte*>(text.data()),reinterpret_cast<const std::byte*>(text.data()+text.size())));return result;
}
void dump(const std::filesystem::path& folder,const Image& data){for(const auto& [name,bytes]:data)store(folder/name,bytes);}
struct Prefix {c::ReadLease history,recurrent;};
std::vector<Prefix> retain_prefixes(q::Model& model) {
  auto& step=*model.active_step;q::check(step.completion.wait());
  const auto& ports=step.phase->layers[0].sequences[0];std::vector<Prefix> result;
  for(std::size_t row=0;row<ports.history_prefix.size();++row)
    result.push_back({q::take(q::take(step.run->result(ports.history_prefix[row])).storage_lease()),q::take(q::take(step.run->result(ports.recurrent_prefix[row])).storage_lease())});
  return result;
}
void check_prefix(q::Model& model,const q::cache::Snapshot& head,const Prefix& expected) {
  require(read(model,head.state[0].history)==read(model,expected.history),"published history is not the actual selected prefix");
  require(read(model,head.state[0].recurrent)==read(model,expected.recurrent),"published recurrent state is not the actual selected prefix");
}
void retire(std::shared_ptr<q::Session>& s){q::check(s->stop());q::check(s->drain());require(q::take(s->try_retire()),"actual session did not retire");s.reset();}
int main(int argc,char** argv) {
  try {
    require(argc==3,"gdn-check SHARED_FIXTURE OUTPUT");const auto shape=geometry();const auto fixture=weights(argv[1],shape);const std::filesystem::path out=argv[2];
    std::filesystem::create_directories(out);std::int32_t ordinary_first=-1,ordinary_next=-1;std::size_t ordinary_peak=0;
    {
      const auto plan=q::cache::plan(shape,16,4,3,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,1,false,true);
      q::Model model(fixture.first,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
        {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
      const std::array chunks{std::size_t{2},std::size_t{1}};model.prepare_family(chunks);model.plan_execution(chunks);
      auto session=model.create_session(chunks);const std::array<std::int32_t,2> prompt{1,2};
      model.prepare_evaluation(*session,prompt);model.submit_evaluation(*session);auto expected=retain_prefixes(model);
      require(expected.size()==1,"ordinary T2 must expose one final state at row0");
      ordinary_first=model.finish_evaluation(*session,"ordinary-P2",{},false);check_prefix(model,*session->head,expected[0]);
      require(!session->head->draft&&session->head->length==2&&session->head->sampling.draw==1,"ordinary prefill state/RNG differs");
      auto base=session->head;const auto saved=image(model,*base);dump(out/"ordinary-base",saved);expected.clear();
      const std::array ids{ordinary_first};model.prepare_evaluation(*session,ids);model.submit_evaluation(*session);expected=retain_prefixes(model);
      require(expected.size()==1,"ordinary T1 must expose state row0");ordinary_next=model.finish_evaluation(*session,"ordinary-T1",{},false);check_prefix(model,*session->head,expected[0]);
      require(session->head->length==3&&session->head->sampling.draw==2&&!session->head->draft,"ordinary continuation state/RNG differs");
      require(saved==image(model,*base),"ordinary old Snapshot changed after append extraction");dump(out/"ordinary-final",image(model,*session->head));
      ordinary_peak=model.cache_usage().peak_bytes;require(ordinary_peak<=16*1024*1024,"ordinary finite budget escaped");
      expected.clear();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"ordinary resources remain admitted");
    }
    std::vector<std::int32_t> proposals,candidates;std::int32_t mtp_pending=-1;std::size_t mtp_peak=0;
    {
      const auto plan=q::cache::plan(shape,16,4,3,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,3,true,true);
      q::Model model(fixture.first,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
        {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
      model.max_drafts=2;const std::array p2{std::size_t{2}},t3{std::size_t{3}};
      model.prepare_family(p2,false,1,q::GraphRole::kMtpPrefill);model.plan_replay_uses(2,1,1,q::GraphRole::kMtpPrefill);
      model.prepare_family(t3,false,1,q::GraphRole::kVerify);model.plan_replay_uses(3,1,1,q::GraphRole::kVerify);
      for(std::size_t rows=1;rows<=3;++rows)model.prepare_draft_program(rows,false);
      model.prepare_draft_program(1,true);model.prepare_draft_program(2,true);
      auto session=model.create_session(p2,{},q::GraphRole::kMtpPrefill);const std::array<std::int32_t,2> prompt{1,2};
      model.prepare_evaluation(*session,prompt,nullptr,q::GraphRole::kMtpPrefill);model.submit_evaluation(*session);auto seed_prefix=retain_prefixes(model);
      model.finish_evaluation(*session,"mtp-P2",{},false);check_prefix(model,*session->head,seed_prefix.at(0));seed_prefix.clear();
      auto base=session->head;const auto saved=image(model,*base);dump(out/"mtp-base",saved);
      std::vector<c::ReadLease> qrows;proposals=model.propose_recursive(*session,2,{},&qrows);
      require(proposals.size()==3&&qrows.size()==2&&model.draft_program_graph_calls==2,"real two recursive proposals missing");
      model.prepare_evaluation(*session,proposals,nullptr,q::GraphRole::kVerify);model.submit_evaluation(*session);auto expected=retain_prefixes(model);
      require(expected.size()==3,"T3 did not publish all three complete GDN prefixes");
      require(read(model,expected[0].history)!=read(model,expected[1].history)&&read(model,expected[2].history)!=read(model,expected[1].history),"GDN selected-row history witness is degenerate");
      require(read(model,expected[0].recurrent)!=read(model,expected[1].recurrent),"GDN recurrent selected-row witness is degenerate");
      for(std::size_t row=0;row<3;++row){store(out/("verifier-prefix"+std::to_string(row)+".history.bf16"),read(model,expected[row].history));store(out/("verifier-prefix"+std::to_string(row)+".recurrent.f32"),read(model,expected[row].recurrent));}
      const std::array outputs{q::EvaluationOutput{.session=session,.name="forced-consumed2-T3",.trace_states=false}};std::array<std::int32_t,1> next{};
      model.finish_selected_evaluations(outputs,next,[&](std::span<const std::int32_t> actual,q::StepState& step,std::span<std::int32_t> selected){
        candidates.assign(actual.begin(),actual.end());require(candidates.size()==3,"real target candidate count differs");
        auto& member=step.members[0];member.accepted_tokens=2;selected[0]=actual[1];member.next->sampling=member.base->sampling.advanced(5);
      },[&](q::StepState& step){model.repair_recursive_draft(step);});
      mtp_pending=next[0];check_prefix(model,*session->head,expected[1]);
      require(session->head->length==4&&session->head->next_id==mtp_pending&&session->head->sampling.draw==6&&base->sampling.draw==1,"controlled prefix pending/RNG publication differs");
      require(model.draft_program_graph_calls==3&&session->head->draft->frontier==3&&session->head->draft->lag==1&&session->head->draft->catchup_token==proposals[1],"real head=false NextN repair did not retain complete selected prefix");
      model.validate_mtp_snapshot(*session->head);require(saved==image(model,*base),"MTP old Snapshot mutated by verifier/repair/take_append");dump(out/"mtp-final",image(model,*session->head));
      mtp_peak=model.cache_usage().peak_bytes;require(mtp_peak<=16*1024*1024,"MTP finite budget escaped");
      expected.clear();qrows.clear();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"MTP resources remain admitted");
    }
    std::cout<<"{\"state\":\"passed\",\"backend\":\"vulkan\",\"layers\":\"GA\",\"fixture_bytes\":"<<fixture.second<<",\"ordinary_ids\":["<<ordinary_first<<','<<ordinary_next<<"],\"ordinary_rng\":2,\"ordinary_state_prefix_row\":0,\"real_proposals\":[";
    for(std::size_t i=0;i<proposals.size();++i)std::cout<<(i?",":"")<<proposals[i];
    std::cout<<"],\"real_target_candidates\":[";for(std::size_t i=0;i<candidates.size();++i)std::cout<<(i?",":"")<<candidates[i];
    std::cout<<"],\"controlled_consumed\":2,\"selected_prefix_row\":1,\"mtp_pending\":"<<mtp_pending<<",\"mtp_rng\":6,\"draft_frontier\":3,\"draft_lag\":1,\"real_head_false_repair\":true,\"old_snapshots_unchanged\":true,\"leases_survive_take_append\":true,\"ordinary_cache_peak\":"<<ordinary_peak<<",\"mtp_cache_peak\":"<<mtp_peak<<",\"cache_limit\":16777216,\"natural_acceptance_claim\":false,\"quality_claim\":false,\"performance_claim\":false,\"HTTP\":0}\n";return 0;
  }catch(const std::exception& error){std::cerr<<"GA state regression: "<<error.what()<<'\n';return 1;}
}
