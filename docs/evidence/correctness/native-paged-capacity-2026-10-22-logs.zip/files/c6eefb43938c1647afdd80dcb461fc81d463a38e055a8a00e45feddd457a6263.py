"""Reuse the AH Mac closure; rebuild only the AI source owners and consumer."""
from pathlib import Path
import argparse, base64, importlib.util, json, sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
AH=ROOT/'.scratch/native-paged-effects-20261022/apple'
spec=importlib.util.spec_from_file_location('ai_mac_cached_helpers',AH/'mac.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
OLD=m.REMOTE
m.REMOTE=m.BASE+'/native-paged-capacity-20261022'
m.HERE=HERE
SOURCES=[
 'src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc',
 'src/compute_route_apple/apple_batch.cc','src/compute_route_apple/apple_materialized_invocation.cc',
 'src/graph_route_apple/native_paged_region.cc','src/graph_route_apple/native_ragged_region.cc',
]
CONSUMER='tests/graph_batch/native_paged_capacity_consumer.cc'

def plan():
    base=json.loads((AH/'mac-plan.json').read_bytes());jobs=[];replacements={}
    for source in SOURCES:
        old=next(x for x in base['jobs']if x['source']==source)
        obj=m.REMOTE+'/objects/'+old['module']+'/'+Path(source).name+'.o'
        command=m.overlay_command(old['original'],source,obj)
        jobs.append(dict(tag=old['tag'],source=source,module=old['module'],object=obj,argv=command))
        replacements[old['object']]=obj
    old=base['consumer_job'];obj=m.REMOTE+'/objects/consumer.o'
    # Keep the original exact compiler/platform flags and current source roots.
    command=[x.replace(OLD,m.REMOTE) for x in old['argv']]
    command[command.index('-c')+1]=m.REMOTE+'/source/'+CONSUMER
    command[command.index('-o')+1]=obj
    command[command.index('-MF')+1]=obj+'.d'
    consumer=dict(tag='consumer',source=CONSUMER,module='consumer',object=obj,argv=command)
    replacements[old['object']]=obj
    archives=[];libs={};changed_modules={x['module']for x in jobs}
    corrected_old=OLD+'/lowering-fix1/apple_lowering.o'
    corrected_lib=OLD+'/lowering-fix1/libhyle_graph_route_apple.a'
    for old in base['archives']:
        old_path=corrected_lib if old['module']=='graph_route_apple'else old['path']
        if old['module']not in changed_modules:continue
        objects=[replacements.get(x,corrected_old if x==OLD+'/objects/graph_route_apple/apple_lowering.cc.o'else x)for x in old['objects']]
        dest=m.REMOTE+'/lib/'+old['name'];libs[old['path']]=dest
        archives.append(dict(module=old['module'],name=old['name'],changed=True,path=dest,objects=objects,argv=['/usr/bin/libtool','-static','-o',dest,*objects]))
    link=[replacements.get(x,libs.get(x,m.REMOTE+'/native-append'if x==OLD+'/native-append'else x))for x in base['link']]
    files=m.include_closure([*SOURCES,CONSUMER],[x['argv']for x in [*jobs,consumer]])
    entries=[]
    for path in files:
        entry=m.ident(path);entry['path']=path.relative_to(ROOT).as_posix();entries.append(entry)
    p=dict(remote=m.REMOTE,sdk=m.SDK,hardware='Mac16,12',jobs=jobs,consumer_job=consumer,
        archives=archives,link=link,files=entries,blockers=[],base=m.ident(AH/'mac-plan.json'),
        source_policy='Windows product sources; original cached deps/native archives retained. AH corrected lowering object preserved.',
        counts=dict(CXX=len(jobs)+1,archives=len(archives),overlay_files=len(entries),overlay_bytes=sum(x['bytes']for x in entries)),
        SDK_builds=0,shaders=0)
    m.save(HERE/'mac-plan.json',p);print(json.dumps(p['counts']))

def run():
    code=r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);out=root/'native-run1';out.mkdir()
image=root/'native-append';raw=image.read_bytes();(out/'image.json').write_text(json.dumps(dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),indent=2)+'\n')
start=time.time();record=dict(command=[str(image)],cwd=str(root),started=start)
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
 child=subprocess.Popen([str(image)],cwd=root,env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_LIBRARY_PATH=p['sdk']+'/relocated/sdk/lib'),stdout=so,stderr=se)
 record.update(pid=child.pid,state='running');(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-start)
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(record=record,stdout=(out/'stdout.log').read_text(errors='replace'),stderr=(out/'stderr.log').read_text(errors='replace'))))
'''
    p=m.prepared_plan();result=m.ssh(code,dict(remote=m.REMOTE,sdk=m.SDK),timeout=180)
    m.save(HERE/'mac-native-run1.json',result);print(json.dumps(result,ensure_ascii=False))
    if result['record']['exit']:raise SystemExit(1)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('plan','prepare','compile','link','run'));p.add_argument('--limit',type=int,default=3);p.add_argument('--job');a=p.parse_args()
    if a.action=='plan':plan()
    elif a.action=='prepare':m.prepare(a)
    elif a.action=='run':run()
    else:m.build(a)
