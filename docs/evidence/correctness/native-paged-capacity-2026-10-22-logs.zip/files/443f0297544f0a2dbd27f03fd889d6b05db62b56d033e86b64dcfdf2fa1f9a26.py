"""Build and run only the two ordered-cast checks using the current native closure."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ai_ordered_helpers',S/'build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.h.RECIPES['ordered-cast']=h.AH/'compile2/vk-test/identity.json'
h.h.SOURCES['ordered-cast']=R/'tests/compute_route_vulkan/ordered_cast_test.cc'
h.h.compile_one('ordered-cast',1)
base=h.c.read(S/'vulkan-link2/link-plan.json')
old=h.c.read(S/'compile1/vk-test/identity.json')['object']
new=h.c.read(S/'compile1/ordered-cast/identity.json')['object']
addons=[h.b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),h.b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
assert sum(h.c.key(x['path'])==h.c.key(old['path'])for x in base['inputs'])==1
assert all(h.b.identity(x['path'])==x for x in base['inputs'])
out=S/'ordered-cast-link1';out.mkdir();(out/'tmp').mkdir()
image=out/'ordered-cast.exe'
command=[new['path']if h.c.key(x)==h.c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command[1:1]=[x['path']for x in addons]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[new if h.c.key(x['path'])==h.c.key(old['path'])else x for x in base['inputs']]+addons
h.c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=h.b.identity(S/'vulkan-link2/link-plan.json'),consumer=h.b.identity(S/'compile1/ordered-cast/identity.json'),SDK_builds=0,shaders=0))
env,_=h.b.environment(command,[x['path']for x in inputs],out)
h.c.execute('link',command,env,out)
runtime=h.c.read(S/'vulkan-link2/runtime-environment.json');env['PATH']=runtime['PATH']
h.c.save(out/'ready.json',dict(image=h.b.identity(image),plan=h.b.identity(out/'link-plan.json')))
run=S/'ordered-cast-run1';run.mkdir()
h.c.save(run/'image.json',h.b.identity(image));h.c.execute('run',[str(image),'--gtest_filter=VulkanOrderedCast.*'],env,run)
print('RAN two ordered conversion checks',flush=True)
