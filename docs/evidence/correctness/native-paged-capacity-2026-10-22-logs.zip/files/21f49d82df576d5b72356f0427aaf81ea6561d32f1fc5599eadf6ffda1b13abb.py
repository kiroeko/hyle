"""Publish lean source/command/result evidence; never bundle rebuildable binaries."""
from pathlib import Path
import hashlib, json, zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
E=R/'docs/evidence/correctness';PREFIX='native-paged-capacity-2026-10-22'
def read(path):return json.loads(Path(path).read_bytes())
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def ident(path):
 p=Path(path);raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def current_image(path):return read(path)['image']
source_paths=set()
for item in read(S/'apple/mac-plan.json')['files']:source_paths.add(R/item['path'])
for tag in ('batch','native-batch','vk-materialized','vk-ragged','vk-test','ordered-cast'):
 record=read(S/'compile1'/tag/'identity.json')
 for item in [record['source'],*record['dependencies']]:
  p=Path(item['path'])
  if p.is_relative_to(R)and '.scratch'not in p.relative_to(R).parts:source_paths.add(p)
for tag in ('vk-batch','vk-paged','vk-program'):
 record=read(S/'compile2'/tag/'identity.json')
 for item in [record['source'],*record['dependencies']]:
  p=Path(item['path'])
  if p.is_relative_to(R)and '.scratch'not in p.relative_to(R).parts:source_paths.add(p)
for rel in ('tests/graph_batch/CMakeLists.txt','tests/compute_route_vulkan/CMakeLists.txt',
 'docs/developer/current-work.md','docs/user/batch-attention.md','docs/architecture/graph-design.md'):
 source_paths.add(R/rel)
sources=[ident(x)for x in sorted(source_paths)]
windows_compiles=[]
for path in sorted(S.glob('compile*/*/compile.result.json')):
 item=read(path);assert item['exit']==0;windows_compiles.append(ident(path))
assert len(windows_compiles)==11,len(windows_compiles)
mac=read(S/'apple/mac-actual-review.json');mac_run=read(S/'apple/mac-native-run1.json')
assert mac_run['record']['exit']==0 and mac_run['stdout'].count(' PASS\n')==3
win_run=read(S/'vulkan-run2/run.result.json');assert win_run['exit']==0
win_text=(S/'vulkan-run2/run.stdout.log').read_text();assert win_text.count(' PASS\n')==3
unit=read(S/'ordered-cast-run1/run.result.json');assert unit['exit']==0
unit_text=(S/'ordered-cast-run1/run.stdout.log').read_text();assert '[  PASSED  ] 2 tests.'in unit_text
assert read(S/'vulkan-run1/run.result.json')['exit']==1
manifest=dict(schema=1,date='2026-10-22',scope='Apple/Vulkan native ordinary Graph capacity+explicit metadata; not full Qwen/MTP acceptance',
 result='PASS_LIMITED_NATIVE_SCOPE',implementation=[
 'Page classification uses immutable capacity storage and exact selected callbacks; capacity form never fabricates an owned-operation recipe.',
 'Actual NodeLayout schema owns each original controller; cold schema replacement succeeds before swapping; old permissions/results gate reuse.',
 'Explicit metadata consumes the original common upload and a retained page_indices sublease. No private page-table bank or copy program is allocated.',
 'Physical Q/output rows remain fixed while active queries may be fewer. Only active math runs; the inactive output suffix is bitwise positive zero.',
 'Vulkan capacity endpoint is stable from Invocation creation. Cold RuntimeQueueOnly compilation selects the existing native Cast and rejects asynchronous carriers; actual invocation capabilities are checked again.',
 'Ordinary unconstrained compilation and owned Direct page defaults retain their original delegation choices. No new public knob, Plan field, executor or queue bridge.'],
 native=dict(shape_domain=dict(query_type='BF16',cache='BF16',output='BF16',page_rows=16,depth=256,query_heads=2,kv_heads=1,children=[dict(physical=1,active=1),dict(physical=2,active=2),dict(physical=2,active=1)]),
  checks=['one logical Graph/one finite compile','native Cast -> dual PagedAppend -> causal compute::PagedAttention(Q,K,V,metadata)','independent 2.5/3.0 visible-row means','inactive NaN Q never becomes a live query; zero output suffix','COW and retained old entire page/NaN tail unchanged','dual-take success latch, guards, untaken reset and stale submit rejection'],
  apple=dict(hardware=mac['hardware'],image=next(x for x in mac['outputs']if x['path'].endswith('/native-append')),cases=3,run=ident(S/'apple/mac-native-run1.json')),
  vulkan=dict(hardware='Windows RTX 4070, driver 617.14, 12282 MiB',image=current_image(S/'vulkan-link2/ready.json'),cases=3,run=ident(S/'vulkan-run2/run.result.json'))),
 conversion=dict(tests=2,ieee_boundaries=19,input='original buffer offset 4 bytes, stride 8 bytes, odd 19 elements',verified=['RNE positive/negative even/odd ties','signed zero/subnormal/overflow/infinity','quiet and signaling NaN payload/quieting','actual submission/readback with no async or IREE','original unconstrained dense Cast still creates its IREE carrier'],run=ident(S/'ordered-cast-run1/run.result.json')),
 build=dict(windows_CXX=11,apple_CXX=7,windows_receipts=windows_compiles,SDK_builds=0,NVCC=0,shader_builds=0,windows_current_link=ident(S/'vulkan-link2/link-plan.json'),apple_current_plan=ident(S/'apple/mac-plan.json'),prior_current_closure='native-paged-effects-2026-10-22.json'),
 troubleshooting=dict(first_run=ident(S/'vulkan-run1/run.result.json'),first_error=(S/'vulkan-run1/run.stderr.log').read_text().strip(),causes=['Graph caches delegated lane endpoints at Invocation creation; explicit capacity had no native program then, causing observed->Runtime identity drift.','BF16 output Cast actually selected IREE and created async state, so simply changing the endpoint would have been incorrect.'],resolution='stable original Runtime identity plus required native-queue cold plan and actual invocation qualification; preserve all original import/write gates'),
 limitations=['No new tokens/s or memory benchmark; latest current-work performance table unchanged.','Not full Qwen plain/MTP, GDN snapshot composition, all models/quantizations, general speculative sampling or model-quality acceptance.','CPU/CUDA runtime regression was not rerun in this slice; prior AH CPU checks remain separate.','No device-loss, late GPU failure, in-flight cancellation or OOM fault injection in this slice.','Only the listed BF16/page16/D256 finite children and F32->BF16 conversion domain were actually executed.'],
 next=read(S/'consumer-next.json'),sources=sources)
save(S/'result.json',manifest)
paths=set(source_paths)
allowed={'.py','.json','.log','.diff','.cc','.h','.md','.ps1','.txt'}
for path in S.rglob('*'):
 if path.is_file()and path.suffix in allowed:paths.add(path)
archive=E/(PREFIX+'-logs.zip');entries=[];seen={}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7)as z:
 for path in sorted(paths):
  item=ident(path);sha=item['sha256'];member=seen.get(sha)
  if member is None:
   member='files/'+sha+path.suffix;z.writestr(member,path.read_bytes());seen[sha]=member
  entries.append(dict(item,member=member))
 z.writestr('manifest.json',json.dumps(dict(files=entries,unique_files=len(seen)),indent=2,ensure_ascii=False)+'\n')
manifest['archive']=ident(archive);manifest['archive']['unique_files']=len(seen);manifest['archive']['mapped_files']=len(entries)
save(E/(PREFIX+'.json'),manifest)
print(json.dumps(dict(evidence=ident(E/(PREFIX+'.json')),archive=manifest['archive'],CXX=18,native_cases=6,conversion_tests=2),ensure_ascii=False))
