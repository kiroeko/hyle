"""Prepare exact cleanup targets, then execute only through root test.ps1."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ai_cleanup_mac',S/'apple/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def ident(path):
 raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def prepare():
 targets=[]
 for folder,stem,suffixes in [
  (R/'.scratch/native-paged-effects-20261022/vulkan-link1','native-paged-append',('.exe','.map','.lib','.exp')),
  (S/'vulkan-link1','native-paged-capacity',('.exe','.map','.lib','.exp')),
  (S/'vulkan-link2','native-paged-capacity',('.map','.lib','.exp')),
  (S/'ordered-cast-link1','ordered-cast',('.exe','.map','.lib','.exp'))]:
  for suffix in suffixes:
   path=folder/(stem+suffix);assert path.resolve().is_relative_to(R/'.scratch');assert path.is_file()and not path.is_symlink();targets.append(ident(path))
 old=h.OLD+'/lowering-fix1'
 remote=h.m.ssh(r'''
from pathlib import Path
import hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['root']).resolve();result=[]
for name in ('native-append','libhyle_graph_route_apple.a'):
 path=root/name;assert path.is_file()and not path.is_symlink()and path.resolve().parent==root
 raw=path.read_bytes();result.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
print(json.dumps(result))
''',dict(root=old))
 plan=dict(windows=targets,mac=remote,reason='Superseded AH/failed first images, current link maps/import stubs and one-shot ordered test image. Keep current capacity image, objects, sources, commands/results, dependency caches and native libraries in use.',recursive_deletion=False)
 save(S/'cleanup-plan.json',plan)
 before=S/'before/test.ps1';assert not before.exists();before.write_bytes((R/'test.ps1').read_bytes())
 rows=['$ErrorActionPreference = "Stop"',"$repo = (Resolve-Path -LiteralPath $PSScriptRoot).Path",'$targets = @(']
 for item in targets:
  rel=Path(item['path']).relative_to(R).as_posix();rows.append("  @{ Relative = '"+rel+"'; Bytes = "+str(item['bytes'])+"; SHA256 = '"+item['sha256']+"' }")
 rows+=[')',"$scratch = [IO.Path]::GetFullPath((Join-Path $repo '.scratch')) + [IO.Path]::DirectorySeparatorChar",
 'foreach ($target in $targets) {',
 '  $path = [IO.Path]::GetFullPath((Join-Path $repo $target.Relative))',
 '  if (-not $path.StartsWith($scratch, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }',
 '  $file = Get-Item -LiteralPath $path',
 '  if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not an original file: $path" }',
 '  if ($file.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $target.SHA256) { throw "Changed target: $path" }',
 '}',
 '$removed = @()',
 'foreach ($target in $targets) {',
 '  $path = [IO.Path]::GetFullPath((Join-Path $repo $target.Relative))',
 '  Remove-Item -LiteralPath $path -Force',
 '  $removed += @{ Path = $path; Bytes = $target.Bytes; SHA256 = $target.SHA256 }',
 '}',
 "$receipt = Join-Path $repo '.scratch/native-paged-capacity-20261022/cleanup-windows.json'",
 '@{ Removed = $removed; Recursive = $false } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $receipt -Encoding utf8',
 '# Exact remote targets, validated by full path, size and SHA before unlink:',
 *['# '+item['path']+' SHA256 '+item['sha256']for item in remote],
 "& python (Join-Path $repo '.scratch/native-paged-capacity-20261022/cleanup.py') remote",
 'if ($LASTEXITCODE -ne 0) { throw "Remote cleanup failed; inspect its receipt" }',
 'Write-Output ("Removed {0} exact Windows leaves; no recursive deletion" -f $removed.Count)']
 (R/'test.ps1').write_text('\n'.join(rows)+'\n',encoding='utf8')
 print(json.dumps(dict(windows_files=len(targets),mac_files=len(remote),bytes=sum(x['bytes']for x in targets+remote),script=ident(R/'test.ps1'))))
def remote():
 plan=json.loads((S/'cleanup-plan.json').read_bytes());value=h.m.ssh(r'''
from pathlib import Path
import hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['allowed']).resolve();checked=[]
for item in p['targets']:
 path=Path(item['path']);assert path.is_file()and not path.is_symlink()and path.resolve().parent==root
 raw=path.read_bytes();assert len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256'];checked.append(path)
for path in checked:path.unlink()
print(json.dumps(dict(removed=p['targets'],recursive=False)))
''',dict(allowed=h.OLD+'/lowering-fix1',targets=plan['mac']))
 save(S/'cleanup-mac.json',value);print(json.dumps(dict(mac_removed=len(value['removed']),bytes=sum(x['bytes']for x in value['removed']))))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('prepare','remote'));a=p.parse_args()
 if a.action=='prepare':prepare()
 else:remote()
