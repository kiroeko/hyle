"""Read the actual Mac receipts and identities; no build or native execution."""
from pathlib import Path
import base64, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ai_mac_collect_helpers',S/'apple/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
code=r'''
from pathlib import Path
import base64,hashlib,json,subprocess,sys
p=json.load(sys.stdin);root=Path(p['remote']);plan=json.loads((root/'plan.json').read_text())
def ident(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
source_checks=[]
for item in plan['files']:
 actual=ident(root/'source'/item['path']);assert (actual['bytes'],actual['sha256'])==(item['bytes'],item['sha256']);source_checks.append(actual)
files=[root/'plan.json',root/'live.json',root/'ready.json']
for directory in ('receipts','native-run1'):
 files.extend(x for x in sorted((root/directory).iterdir())if x.is_file()and x.suffix in ('.json','.log'))
assert json.loads((root/'live.json').read_text())['state']=='terminal'
records=[dict(path=str(x.relative_to(root)),data=base64.b64encode(x.read_bytes()).decode(),identity=ident(x))for x in files]
outputs=[ident(root/'native-append'),*[ident(Path(x['object']))for x in plan['jobs']+[plan['consumer_job']]],*[ident(Path(x['path']))for x in plan['archives']]]
hardware=dict(model=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip(),memory_bytes=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.memsize'],text=True).strip(),cpu=subprocess.check_output(['/usr/sbin/sysctl','-n','machdep.cpu.brand_string'],text=True).strip())
print(json.dumps(dict(records=records,source_checks=source_checks,outputs=outputs,hardware=hardware)))
'''
result=h.m.ssh(code,dict(remote=h.m.REMOTE),timeout=60)
out=S/'apple/downloaded-logs';out.mkdir(exist_ok=False)
for item in result.pop('records'):
    path=out/item['path'];path.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(item['data']);path.write_bytes(raw)
    assert h.m.ident(path)['sha256']==item['identity']['sha256']
h.m.save(S/'apple/mac-actual-review.json',result)
print(json.dumps(dict(files=sum(1 for x in out.rglob('*')if x.is_file()),source_checks=len(result['source_checks']),hardware=result['hardware'])))
