"""Record completed exact cleanup and check final source/evidence consistency."""
from pathlib import Path
import hashlib,json,subprocess
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(path):return json.loads(Path(path).read_bytes())
def ident(path):
 raw=path.read_bytes();return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
script=R/'test.ps1';(S/'cleanup-script.ps1').write_bytes(script.read_bytes())
plan=read(S/'cleanup-plan.json');win=read(S/'cleanup-windows.json');mac=read(S/'cleanup-mac.json')
assert len(win['Removed'])==15 and len(mac['removed'])==2
assert all(not Path(x['path']).exists()for x in plan['windows'])
assert sum(x['Bytes']for x in win['Removed'])==sum(x['bytes']for x in plan['windows'])
assert mac['removed']==plan['mac']
record=dict(status='COMPLETED_DO_NOT_RERUN_SCRIPT',plan=plan,windows=win,mac=mac,
 bytes_removed=sum(x['bytes']for x in plan['windows']+plan['mac']),
 script=ident(script),script_text=script.read_text(encoding='utf8'),recursive=False,
 retained='Current capacity executable, original/new object caches, live Mac libraries/image, source/commands/results; no SDK or dependency deletion.')
target=R/'docs/evidence/correctness/native-paged-capacity-2026-10-22-cleanup.json'
target.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
old=(S/'before/docs/developer/current-work.md').read_text(encoding='utf8')
new=(R/'docs/developer/current-work.md').read_text(encoding='utf8')
marker='## 最新完整性能对比'
assert marker in old and marker in new and old.split(marker,1)[1]==new.split(marker,1)[1], 'performance table changed without a new full benchmark'
paths=['include/hyle/compute/detail/materialized_native_controller.h','include/hyle/compute/detail/apple_batch_access.h','include/hyle/compute/detail/vulkan_batch_access.h','src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.h','src/graph_batch/native_batch_regions.cc','src/graph_route_apple/native_paged_region.cc','src/compute_route_apple/apple_batch.cc','src/graph_route_vulkan/native_paged_region.cc','src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_carrier.h','tests/graph_batch/native_paged_capacity_consumer.cc','tests/graph_batch/CMakeLists.txt','tests/compute_route_vulkan/ordered_cast_test.cc','tests/compute_route_vulkan/CMakeLists.txt','docs/developer/current-work.md','docs/user/batch-attention.md','docs/architecture/graph-design.md']
check=subprocess.run(['git','diff','--check','--',*paths],cwd=R,capture_output=True,text=True)
assert check.returncode==0,check.stdout+check.stderr
summary=dict(git_diff_check=0,performance_table_unchanged=True,cleanup=ident(target),sources=[ident(R/x)for x in paths])
(S/'final-review.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(cleanup_bytes=record['bytes_removed'],source_files=len(paths),performance_table_unchanged=True)))
