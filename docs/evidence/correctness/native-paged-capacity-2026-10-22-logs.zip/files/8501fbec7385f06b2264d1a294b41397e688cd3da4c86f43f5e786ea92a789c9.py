"""AI focused incremental host builds. Import executes no build or native run."""
from pathlib import Path
import argparse, importlib.util, json, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AH = R/'.scratch/native-paged-effects-20261022'
spec = importlib.util.spec_from_file_location('ai_cached_helpers', AH/'build_windows.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c
h.S = S
h.RECIPES = {
 'batch': AH/'compile2/batch/identity.json',
 'native-batch': AH/'compile2/native-batch/identity.json',
 'vk-paged': AH/'compile2/vk-paged/identity.json',
 'vk-ragged': AH/'compile2/vk-ragged/identity.json',
 'vk-batch': R/'.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/vulkan/checks/attempt2/batch-identity.json',
 'vk-materialized': AH/'compile2/vk-paged/identity.json',
 'vk-program': R/'.scratch/paged-append-20261021/unbind-native/checks/attempt1/program/identity.json',
 'vk-test': AH/'compile2/vk-test/identity.json',
}
h.SOURCES = {
 'vk-batch': R/'src/compute_route_vulkan/vulkan_batch.cc',
 'vk-materialized': R/'src/compute_route_vulkan/vulkan_materialized_invocation.cc',
 'vk-program': R/'src/compute_route_vulkan/vulkan_program.cc',
 'vk-test': R/'tests/graph_batch/native_paged_capacity_consumer.cc',
}

def owner_identity_record(path):
    for candidate in (path.parent/'identity.json',path.with_name(path.stem+'-identity.json')):
        if candidate.is_file():
            data=c.read(candidate)
            if 'object' in data and c.key(data['object']['path'])==c.key(path): return data
    return None

def link(attempt, link_attempt):
    old=c.read(AH/'vulkan-link1/link-plan.json')
    tags=tuple(h.RECIPES)
    paths={tag:(S/f'compile{attempt}'/tag/'identity.json' if (S/f'compile{attempt}'/tag/'identity.json').is_file() else S/'compile1'/tag/'identity.json') for tag in tags}
    records={tag:c.read(path) for tag,path in paths.items()}
    replacement={}
    for tag, rec in records.items():
        assert b.identity(rec['source']['path'])==rec['source'], ('source drift',tag)
        assert b.identity(rec['object']['path'])==rec['object']
        if tag=='vk-materialized':
            matches=[x for x in old['inputs'] if Path(x['path']).name.endswith('vulkan_materialized_invocation.obj')]
            assert len(matches)==1,matches
            previous=matches[0]
        else: previous=c.read(h.RECIPES[tag])['object']
        assert sum(c.key(x['path'])==c.key(previous['path']) for x in old['inputs'])==1,(tag,previous)
        replacement[c.key(previous['path'])]=rec['object']
    for value in old['inputs']: assert b.identity(value['path'])==value
    out=S/f'vulkan-link{link_attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    image=out/'native-paged-capacity.exe'
    command=[replacement.get(c.key(x),{}).get('path',x) for x in old['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[replacement.get(c.key(x['path']),x) for x in old['inputs']]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(AH/'vulkan-link1/link-plan.json'),compiled_records=[b.identity(path) for path in paths.values()],reused_inputs=len(inputs)-len(tags),SDK_builds=0,shaders=0,NVCC=0))
    env,_=b.environment(command,[x['path'] for x in inputs],out)
    c.execute('link',command,env,out)
    runtime=c.read(AH/'vulkan-link1/runtime-environment.json');runtime['PATH']=os.pathsep.join([*runtime['runtime'],env['PATH']])
    c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=b.identity(image),plan=b.identity(out/'link-plan.json'),runtime=b.identity(out/'runtime-environment.json')))
    print('LINKED Vulkan capacity consumer; not run',flush=True)

def run(link_attempt):
    image=S/f'vulkan-link{link_attempt}/native-paged-capacity.exe'
    out=S/f'vulkan-run{link_attempt}';out.mkdir(exist_ok=False)
    runtime=c.read(image.parent/'runtime-environment.json');env=os.environ.copy();env['PATH']=runtime['PATH']
    c.save(out/'image.json',b.identity(image));c.execute('run',[str(image)],env,out)
    print('RAN Vulkan capacity consumer',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('tags',nargs='+',choices=(*h.RECIPES,'link','run'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--link-attempt',type=int,default=1);a=p.parse_args()
    for tag in a.tags:
        if tag=='link':link(a.attempt,a.link_attempt)
        elif tag=='run':run(a.link_attempt)
        else:h.compile_one(tag,a.attempt)
