# AH cleanup: exact files only. This script is one-shot; do not rerun.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repoRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
if ($repoRoot -ne 'C:\public\project-hyle\hyle') { throw 'Unexpected workspace' }
$stageRoot = Join-Path $repoRoot '.scratch\native-paged-effects-20261022'
$plan = Get-Content -LiteralPath (Join-Path $stageRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$receiptPath = Join-Path $stageRoot 'cleanup-result.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup already has a terminal receipt' }
if ((Get-FileHash -LiteralPath $plan.archive.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $plan.archive.sha256) { throw 'Evidence archive changed' }
$allowedParents = @((Join-Path $stageRoot 'cpu-link1'), (Join-Path $stageRoot 'cpu-link2'))
foreach ($item in $plan.windows) {
  $file = Get-Item -LiteralPath $item.path
  $resolved = (Resolve-Path -LiteralPath $item.path).Path
  if ($file.PSIsContainer -or $file.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or $resolved -ne $file.FullName -or $file.DirectoryName -notin $allowedParents) { throw "Unexpected cleanup target $resolved" }
  if ($file.Length -ne $item.bytes -or (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "Cleanup target changed $resolved" }
}
foreach ($item in $plan.keep_windows) {
  if ((Get-FileHash -LiteralPath $item.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw 'Kept current image changed' }
}
$remoteCode = @'
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.load(sys.stdin);root=Path(p['root']).resolve(strict=True)
assert root.name=='native-paged-effects-20261022' and str(root).startswith('/Users/kiro/hyle-scratch/compute-unified/')
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
def same(x):
 q=Path(x['path']);raw=q.read_bytes();return len(raw)==x['bytes']and hashlib.sha256(raw).hexdigest()==x['sha256']
for x in p['keep']:assert same(x),'kept Mac image changed'
for x in p['files']:
 q=Path(x['path']);assert q.is_file()and not q.is_symlink()and q.resolve(strict=True).is_relative_to(root)
 assert same(x),'Mac cleanup target changed'
for x in p['files']:Path(x['path']).unlink()
assert all(not Path(x['path']).exists()for x in p['files'])
assert all(same(x)for x in p['keep'])
print(json.dumps(dict(status='PASS',files=len(p['files']),bytes=sum(x['bytes']for x in p['files']),removed=p['files'],kept_current_image_verified=True)))
'@
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($remoteCode))
$payload = @{root=$plan.mac_root;files=$plan.mac;keep=$plan.keep_mac} | ConvertTo-Json -Depth 10 -Compress
$remoteOutput = $payload | & ssh -o BatchMode=yes -o ConnectTimeout=8 kiro@172.22.10.198 "python3 -c `"import base64;exec(base64.b64decode('$encoded'))`""
if ($LASTEXITCODE -ne 0) { throw 'Mac exact-file cleanup failed' }
$macResult = $remoteOutput | ConvertFrom-Json
foreach ($item in $plan.windows) { Remove-Item -LiteralPath $item.path -Force }
foreach ($item in $plan.windows) { if (Test-Path -LiteralPath $item.path) { throw 'A cleanup target remains' } }
foreach ($item in $plan.keep_windows) { if ((Get-FileHash -LiteralPath $item.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw 'Kept current image changed after cleanup' } }
$result = @{status='PASS';windows_files=$plan.windows.Count;windows_bytes=($plan.windows | Measure-Object -Property bytes -Sum).Sum;windows_removed=$plan.windows;mac=$macResult;kept_current_images_verified=$true;recursive_delete=$false}
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
$result | Select-Object status,windows_files,windows_bytes,@{Name='mac_files';Expression={$_.mac.files}},@{Name='mac_bytes';Expression={$_.mac.bytes}} | ConvertTo-Json -Compress
