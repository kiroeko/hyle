from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess

root = Path('/root/hyle-scratch/compute-unified/foundation-f3-tsan-c36c40bed')
job = json.loads((root / 'job.json').read_text())
original = job['stages'][-1]
assert original['name'] == 'files' and original['exit_code'] == 66
assert 'unexpected memory mapping' in (root / original['log']).read_text()
assert not (root / 'files-layout.log').exists()
assert not (root / 'files.xml').exists()
command = ['/usr/bin/setarch', 'x86_64', '-R', str(Path(job['build']) / 'bin/hyle_compute_stream_test'),
           '--gtest_filter=FileStream.*', '--gtest_output=xml:' + str(root / 'files-layout.xml')]
env = os.environ.copy()
env.update(PATH='/usr/bin:/bin:/usr/sbin:/sbin', TSAN_OPTIONS='halt_on_error=1')
log = root / 'files-layout.log'
with log.open('w') as output:
    process = subprocess.Popen(command, cwd=job['source'], env=env, stdout=output,
                               stderr=subprocess.STDOUT, start_new_session=True)
    row = {'name': 'files-layout', 'command': command, 'pid': process.pid, 'state': 'running',
           'log': log.name, 'budget_seconds': 120,
           'recovery': 'One process-local ASLR-disabled recovery for identical F2 startup failure; original exit66 retained.'}
    job['stages'].append(row)
    (root / 'job.json').write_text(json.dumps(job, indent=2))
    try:
        code = process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()
        row.update(state='terminal', verdict='TIMEOUT')
        (root / 'job.json').write_text(json.dumps(job, indent=2))
        raise
    row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL',
               sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    job['verdict'] = 'PASS_WSL_F3_TSAN_LAYOUT_RECOVERY_ONLY' if code == 0 else 'FAIL_WSL_F3_TSAN_LAYOUT_RECOVERY'
    (root / 'job.json').write_text(json.dumps(job, indent=2))
print('files-layout', code, flush=True)
raise SystemExit(code)
