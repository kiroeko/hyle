from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd();W=R/'.scratch/inference-dual-model-20261025';A=W/'attempt2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
result=json.loads((A/'run1/result.json').read_bytes());assert result['status']=='PASS'
pins=json.loads((A/'compile/actual-source-pins.json').read_bytes())
for v in pins:
 p=Path(v['path']);assert p.stat().st_size==v['bytes']and sha(p)==v['sha256']
rebuildable=[]
for name in ('compile/unit.obj','link/consumer.exe','link/consumer.exp','link/consumer.lib','link/hyle_ggml_cpu_gdn_scale_v3.dll'):
 p=A/name;rebuildable.append(record(p))
summary=dict(status='PASS_TWO_ORIGINAL_MODELS_ONE_CUDA_DEVICE',date='2026-10-25',
 scope='One finite ordinary CUDA process using two independently created HYLE Backends/ColdResources and the original Qwen BF16 bank; no server, thread-safety or throughput claim.',
 result=result,actual_source_pins=pins,canonical_bridge=json.loads((W/'canonical-bridge.json').read_bytes()),
 process=json.loads((A/'run1/process.json').read_bytes()),compile=json.loads((A/'compile/process.json').read_bytes()),link=json.loads((A/'link/process.json').read_bytes()),
 inputs=json.loads((A/'inputs.json').read_bytes()),command=json.loads((A/'run1/command.json').read_bytes()),
 frozen_engine_main='28875a2240b4e9ea701c8977a14a382166dfd1404d300eb2b7055436b9c3bea5',
 endpoint_facts=dict(same_physical_device_ordinal=0,same_CUDA_primary_context=result['same_CUDA_primary_context'],independent_HYLE_context_owner_ids=True,independent_native_streams=True,independent_ColdResources=True,
   interpretation='Both logical HYLE Contexts use the SAME CUDA primary context, not isolated physical CUDA contexts. Original distinct queue streams and scoped allocations remain alive independently.'),
 checks=['Two original320text/0MTP Models load the same source roles into their own existing original allocation domains. No additional global physical-budget owner was introduced.',
 'Independent P15 prefills publish one authoritative head/ledger/random draw per Model.',
 'A Session submitted to ModelB is rejected before native admission and neither head/ledger/cursor changes.',
 'Both original T1 Invocations are submitted through different original Model carriers and streams before either is finished.',
 'A cancellation returns its original status, completes retirement, releases its Session, and its Model destruction expires the weak ColdResources owner.',
 'While A is stopped/retired/destroyed, B retains the exact original committed head pointer, boundary/pending/cursor, ledger1/uncommitted candidate, Context/stream/resource identities and original pending carrier.',
 'B finishes the already-submitted original Invocation after A Model destruction, then submits another original T1; pending chain, ledger3/cursor3/length17 and normal final retirement succeed.'],
 boundaries=['CUDA primary context is shared. Logical context/queue/resource independence does not imply independent physical contexts or GPU scheduling isolation.',
 'Logical in_flight flags are actual owner facts; physical GPU completion/order at A teardown is unknown. A teardown may wait for shared-device work; no hardware preemption or noninterference latency bound is claimed.',
 'No independent F64/tensor-byte numerical oracle, output-quality claim, model-weight sharing, concurrent host mutation, multi-thread/server scheduler or inter-model throughput measurement.',
 'Per-Model cache caps256MiB scope the existing Model caches; they are not a global VRAM hard bound. Vendor contexts/allocator caches/workspace remain separately scoped as before.',
 'Actual execution uses frozen main28875 engine, excluding ongoing later NF4 changes. Canonical same-exe case is source-only entry/namespace adaptation and was not recompiled/rerun against the changing product Model.'],
 first_failures=json.loads((W/'first-failures.json').read_bytes()),actual_model_processes=1,actual_model_failures=0,strict_compile_attempts=2,SDK_builds=0,HTTP_requests=0,new_model_downloads=0,GPU_released=True,
 cleanup=dict(files=rebuildable,count=len(rebuildable),logical_bytes=sum(v['bytes']for v in rebuildable),deleted=False,failed_compile_rebuildable_binaries=0,scope='Only successful private verification binaries; retain pending parent cleanup decision. All frozen source/commands/logs/results and SDK/weights remain.'))
(W/'cleanup-candidates.json').write_text(json.dumps(summary['cleanup'],indent=2)+'\n');(W/'proof-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
def add(p,n=None):files[n or p.relative_to(W).as_posix()]=p
for p in (W/'source').rglob('*'):
 if p.is_file():add(p)
for v in pins:
 p=Path(v['path']).resolve()
 if p.is_relative_to(R/'include'):add(p,'public-at-compile/'+p.relative_to(R).as_posix())
for p in W.iterdir():
 if p.is_file()and p.suffix in('.cc','.py','.md','.json','.patch','.txt'):add(p)
for name in ('tests/tools/qwen_request_lifecycle_test.cc','tests/tools/qwen_dual_model_case.h','tests/CMakeLists.txt'):add(R/name,'canonical/'+name)
for name in ('attempt1','attempt2'):
 for p in (W/name).rglob('*'):
  if p.is_file()and p.suffix in('.json','.log')and 'tmp'not in p.relative_to(W/name).parts:add(p)
Z=W/'proof.zip'
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED)as dst:
 for n,p in sorted(files.items()):dst.writestr(n,p.read_bytes())
 dst.writestr('archive-inventory.json',json.dumps([dict(path=n,bytes=p.stat().st_size,sha256=sha(p))for n,p in sorted(files.items())],indent=2)+'\n')
with zipfile.ZipFile(Z)as dst:
 assert dst.testzip()is None
 assert not any(Path(n).suffix.lower()in('.exe','.obj','.exp','.lib','.dll','.pdb')for n in dst.namelist())
 for v in json.loads(dst.read('archive-inventory.json')):
  b=dst.read(v['path']);assert len(b)==v['bytes']and hashlib.sha256(b).hexdigest()==v['sha256']
 count=len(dst.namelist())
publication=dict(summary=record(W/'proof-summary.json'),archive=record(Z),members=count,CRC_and_all_member_SHA='PASS',cleanup_count=len(rebuildable),cleanup_logical_bytes=summary['cleanup']['logical_bytes'])
(W/'publication.json').write_text(json.dumps(publication,indent=2)+'\n');print(json.dumps(publication,indent=2))
