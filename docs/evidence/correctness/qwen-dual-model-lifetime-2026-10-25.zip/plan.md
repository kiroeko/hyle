# Two original Models on one CUDA device �� finite plan only

- Authoritative stage frozen under source/engine:32 self-written files691,978B; main28875a2240b4e9ea701c8977a14a382166dfd1404d300eb2b7055436b9c3bea5. NF4 changes will not be read back into this private consumer.
- Original inputs: `.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/{weights.tsv,prompt.ids}`. Use first15 original prompt IDs, C32/N1/R1 for each Model, ordinary Text random temp1/topK8/topP.9/seed123, independent streams100/101. No synthetic/untrained weights, tokenizer, HTTP, SDK build or full source scan.
- Reuse exact attempt2 consumer compile/link closure from previous chunk proof, replacing only one consumer OBJ. Each actual Model creates its existing Backend and ColdResources/cache/execution budgets; no new global/physical memory owner or registry.
- Query result: RTX4070 driver617.14,total12,282MiB,used1,942MiB at one read. Two known BF16 banks require2*3,763,655,360=7,527,310,720B(~7,178MiB), leaving about3,162MiB versus that instantaneous sample for contexts/workspace/cache. This is feasibility, not a hard VRAM bound or OOM exemption.

## One process, one original case
1. Create ModelA and ModelB independently against the same original manifest; each cold family {15,1}, cache cap256MiB and sampler frontier enabled. Assert distinct Backend Context wrapper and ColdResources identity, same requested CUDA physical device/domain policy,320text/0MTP per Model. Weight/lease owners remain within their own Model, no cross-bank borrowing.
2. Actual P15 prefill A then B, each ledger1/cursor1/one pending. Preserve both complete head boundaries and B's Backend/context/resource identities.
3. Prepare and submit A T1 and B T1 via their original, independent Model carriers/ledgers before finishing either. There are two actual Invocation owners, not two requests in one Model. Capture logical in_flight/owners only; physical device completion order remains unknown.
4. Stop A, drive its original whole episode abort/retirement, allow only caller-requested Cancelled without hiding native/retirement errors, retire its Session and destroy ModelA. B's active episode/head/ledger/cursor/pending must remain unchanged and owned by ModelB throughout. A may wait for shared device progress; this test makes no noninterference latency assertion.
5. Finish already-submitted B through its actual retained Graph outputs; ledger2/cursor2 and pending are published once. Then submit/finish another B T1 after ModelA's destruction: ledger3/cursor3/length17, actual pending chain continuous. Stop/drain/retire B normally and destroy ModelB.

## Meaningful assertions / limits
- Test also rejects an A Session passed to B preparation before native submission; no change to either head/ledger/cursor (optional pre-submit host check within this process).
- Source identities match original inputs, while model/math owner identities and native Backend/ColdResources are distinct. A's cancellation/destruction must not poison B retirement_status or invalidate B's pre-existing output leases/native carrier; B final stop must return OK.
- Current constructor puts execution before resources_; destructor hands the original Backend to ColdResources after original retirement. Reuse these mechanisms, no extra resource teardown loop/callback/executor.
- No throughput, inter-model simultaneous-kernel overlap, hardware preemption, all-provider memory accounting or global VRAM cap claim. Main owner remains serialized per Model; two host threads/server queues are outside this case.
- Only one actual GPU process after root confirms the window. Compile/syntax failures and any real OOM/native/frontier failure stay preserved; no automatic fallback, dropping a Model before intended overlap or silently reducing the work.
- Prefer a new namespaced case header and `--dual-model` dispatch in the existing lifecycle regression executable later; private verification uses the frozen pre-NF4 engine closure. Do not add another permanent heavy target.

Status: DESIGN_ONLY; no compile/model run/GPU workload performed.
