from pathlib import Path
import hashlib,importlib.util,json,os
R=Path.cwd();W=R/'.scratch/inference-dual-model-20261025';F=W/'attempt2';F.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=R/'.scratch/inference-system-review-20261025/schedule-inputs';original=b.args(old/'compile/command.json')
flags=[];skip=False
for a in original[1:]:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd'))or a.lower().endswith(('.cc','.cpp')):continue
 flags.append(a)
flags=['/I'+str(W/'source'),'/I'+str(W/'source/engine/models/qwen35'),*flags]
command=[original[0],*flags,str(W/'consumer2.cc'),'/sourceDependencies',str(F/'compile/dependencies.json'),'/Fo'+str(F/'compile/unit.obj'),'/Fd'+str(F/'compile/unit.pdb')]
sourcepins=[b.pin(W/'source'/v['path'])for v in b.read(W/'source-pins.json')]
b.save(F/'before-sources.json',sourcepins)
inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
b.save(F/'inputs.json',dict(manifest=b.pin(inputs/'weights.tsv'),prompt=b.pin(inputs/'prompt.ids'),runtime=b.pin(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'),scope='Original retained source ranges, no new source copies/full bank hash scan'))
b.save(F/'consumer-pin.json',b.pin(W/'consumer2.cc'))
env=b.environment(original[0]);b.execute(command,F/'compile',env,90)
deps=b.read(F/'compile/dependencies.json')['Data'];actual=[]
for n in [deps['Source'],*deps['Includes']]:
 p=Path(n).resolve()
 if p.is_relative_to(R/'engine')or p.is_relative_to(R/'tests'):raise RuntimeError('Frozen consumer leaked canonical source: '+str(p))
 if p.is_relative_to(R):actual.append(b.pin(p))
b.save(F/'compile/actual-source-pins.json',actual)
for pin in sourcepins:assert b.pin(Path(pin['path']))==pin
link=b.args(old/'link/command.json');oldobj=str(old/'compile/unit.obj').lower();args=[];replaced=0
for a in link[1:]:
 if a.lower()==oldobj:args.append(str(F/'compile/unit.obj'));replaced+=1
 elif not a.lower().startswith(('/out:','/pdb:','/map:','/implib:')):args.append(a)
assert replaced==1
for a in args:
 if Path(a).is_absolute()and a.lower().endswith(('.obj','.lib'))and not Path(a).is_file():raise RuntimeError('Retained input missing: '+a)
b.execute([link[0],*args,'/OUT:'+str(F/'link/consumer.exe'),'/IMPLIB:'+str(F/'link/consumer.lib')],F/'link',env,90)
os.link(old/'link/hyle_ggml_cpu_gdn_scale_v3.dll',F/'link/hyle_ggml_cpu_gdn_scale_v3.dll')
for pin in actual:
 p=Path(pin['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
b.save(F/'ready.json',dict(image=b.pin(F/'link/consumer.exe'),object=b.pin(F/'compile/unit.obj'),native=b.pin(F/'link/hyle_ggml_cpu_gdn_scale_v3.dll'),sources=actual,SDK_builds=0,HTTP_requests=0))
print(json.dumps(dict(state='BUILT',image=b.pin(F/'link/consumer.exe'),actual_self_sources=len(actual))),flush=True)
