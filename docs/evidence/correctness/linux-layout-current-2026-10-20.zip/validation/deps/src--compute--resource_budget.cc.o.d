/root/hyle-scratch/compute-unified/linux-layout-current/objects/src--compute--resource_budget.cc.o: \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/src/compute/resource_budget.cc \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/resource_budget.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/visibility.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/visibility.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/error/result.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/compiler.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/detail/compiler_attributes.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/environment.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/assert.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/detail/preprocessor.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/error/status.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/mem/quota_allocator.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/mem/allocator.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/mem/resource.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/detail/resource_budget_access.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/util/ref_counted.h
