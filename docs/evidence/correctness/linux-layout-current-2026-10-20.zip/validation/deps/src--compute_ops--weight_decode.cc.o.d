/root/hyle-scratch/compute-unified/linux-layout-current/objects/src--compute_ops--weight_decode.cc.o: \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/src/compute_ops/weight_decode.cc \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/model_ops.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/operation.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/ops_visibility.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/visibility.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/tensor_desc.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/error/result.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/compiler.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/detail/compiler_attributes.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/environment.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/assert.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/core/detail/preprocessor.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/error/status.h \
 /root/hyle-scratch/compute-unified/linux-layout-current/source/include/hyle/compute/low_precision.h
