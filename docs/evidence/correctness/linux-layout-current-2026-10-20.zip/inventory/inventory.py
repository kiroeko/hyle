"""Read-only WSL/cache inventory; never compiles, runs a test, or writes in WSL."""
import hashlib
import json
import pathlib
import subprocess
import time

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parents[2]
OLD = HERE.parent / 'linux-current-graph'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

results = read(OLD / 'compile-results.json')
owners = {}
for row in results:
    if row['exit_code'] == 0 and 'object' in row:
        owners[row['source']] = row
link = read(OLD / 'link-plan.json')
payload = {
    'objects': read(OLD / 'retained-objects.json'),
    'libraries': link['retained_libraries'],
    'runtime': link['runtime'],
    'owners': [{ 'source': k, 'object': v['object']['path'], 'command': v['command'] }
               for k, v in owners.items()],
}
remote = r'''
import json,pathlib,sys,subprocess,hashlib,platform,os,shutil
x=json.load(sys.stdin)
def command(args):
 try:
  q=subprocess.run(args,text=True,capture_output=True,timeout=20)
  return {'command':args,'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
 except Exception as e:return {'command':args,'error':str(e)}
def ident(row, hash_it):
 p=pathlib.Path(row['path']); out={'recorded':row,'exists':p.exists()}
 if p.exists():
  s=p.stat();out.update(bytes=s.st_size,mtime_ns=s.st_mtime_ns)
  if hash_it:out['sha256']=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
  out['recorded_size_matches']=s.st_size==row['bytes']
  if hash_it:out['recorded_sha_matches']=out['sha256']==row['sha256']
 return out
base=pathlib.Path('/root/hyle-scratch/compute-unified')
root=base/'linux-current-graph'
o={'uname':platform.uname()._asdict(),'os_release':pathlib.Path('/etc/os-release').read_text(),
 'user':command(['id']),'cpu':command(['lscpu']),
 'memory':pathlib.Path('/proc/meminfo').read_text().splitlines()[:4],
 'tools':[command(a) for a in [['/usr/bin/g++-14','--version'],['cmake','--version'],['ninja','--version'],['/usr/local/cuda-13.3/bin/nvcc','--version']]],
 'latest_fixed_workdirs':sorted([{'path':str(p),'mtime_ns':p.stat().st_mtime_ns} for p in base.iterdir() if p.is_dir()],key=lambda a:a['mtime_ns'],reverse=True)[:12],
 'objects':[ident(r,True) for r in x['objects']],
 'libraries':[ident(r,False) for r in x['libraries']],
 'runtime':[ident(r,False) for r in x['runtime']],
 'dependencies':[]}
for r in x['owners']:
 c=r['command'];d=c[c.index('-MF')+1] if '-MF' in c else None
 q={'source':r['source'],'object':r['object'],'depfile':d,'command':c}
 if d:
  p=pathlib.Path(d);q['exists']=p.exists()
  if p.exists():q['text']=p.read_text()
 o['dependencies'].append(q)
# Existing exact source-build records: inspect only these known caches, not the full filesystem.
o['cmake_caches']=[]
for d in ['l-cuda/selected-graph/source-build','l-cpu-cuda/selected-graph/source-build','l-cpu/selected-graph/source-build']:
 p=base/d; z={'path':str(p),'exists':p.exists()}
 cc=p/'compile_commands.json'
 if cc.exists():
  rows=json.loads(cc.read_text());z['commands_count']=len(rows)
  z['test_commands']=[r for r in rows if '/tests/' in r.get('file','') and any(s in r.get('file','') for s in ['batch','graph','gtest'])]
 cm=p/'CMakeCache.txt'
 if cm.exists():z['cache_selected']=[s for s in cm.read_text().splitlines() if not s.startswith('//') and any(k in s for k in ['CMAKE_CXX_COMPILER:','CMAKE_BUILD_TYPE:','HYLE_BUILD_TEST','GTEST','gtest','CMAKE_HOME_DIRECTORY:'])]
 o['cmake_caches'].append(z)
o['gtest_locations']=[]
for parent in [base/'l-cpu-cuda/selected-graph/static-sdk-relocated',base/'l-cuda/selected-graph/source-build',pathlib.Path('/usr/lib/x86_64-linux-gnu'),pathlib.Path('/usr/src/googletest')]:
 if parent.exists():
  # SDK directories may be large: a bounded filename walk skips sources and third-party heavyweight trees.
  for current,dirs,files in os.walk(parent):
   rel=pathlib.Path(current).relative_to(parent)
   if len(rel.parts)>5:dirs[:]=[];continue
   dirs[:]=[d for d in dirs if d not in ['.git','torch','libtorch','node_modules']]
   for f in files:
    if f in ['libgtest.a','libgtest_main.a','gtest.h']:
     p=pathlib.Path(current)/f;o['gtest_locations'].append({'path':str(p),'bytes':p.stat().st_size})
print(json.dumps(o))
'''
q = subprocess.run(['wsl','-d','Ubuntu-24.04','--','python3','-c',remote],
                   input=json.dumps(payload),capture_output=True,text=True,encoding='utf-8',timeout=90)
save('inspection-command.json', {'command':['wsl','-d','Ubuntu-24.04','--','python3','-c','<remote_source below>'],
 'remote_source':remote,'exit_code':q.returncode,'stderr':q.stderr,
 'scope':'Read-only identity, stat, hash, .d and existing compile recipe inspection; no compile/link/test/GPU/filesystem mutation in WSL.'})
if q.returncode:
    raise SystemExit(q.stderr)
inventory=json.loads(q.stdout)
save('wsl-cache-inventory.json', inventory)

snapshot=read(OLD/'final-source-identities.json')
changed=[]
for r in snapshot:
 p=REPO/r['relative']
 if not p.exists():
  changed.append({'relative':r['relative'],'status':'missing_current','cached_sha256':r['compiled_snapshot']['sha256']});continue
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h!=r['compiled_snapshot']['sha256']:
  changed.append({'relative':r['relative'],'status':'changed','cached_sha256':r['compiled_snapshot']['sha256'],'current_sha256':h,'bytes':p.stat().st_size})
save('cached-source-drift.json',changed)
print(json.dumps({'objects':len(inventory['objects']),
 'missing_objects':sum(not r['exists'] for r in inventory['objects']),
 'mismatched_objects':sum(r.get('recorded_sha_matches') is False for r in inventory['objects']),
 'libraries':len(inventory['libraries']),'missing_libraries':sum(not r['exists'] for r in inventory['libraries']),
 'gtest_locations':inventory['gtest_locations'],'recorded_owners':len(owners),
 'changed_snapshot_files':len(changed)},indent=2))
