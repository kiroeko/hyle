"""Seal actual bounded Linux CPU results, retaining the failed GNU attempt."""
import collections
import difflib
import hashlib
import json
import pathlib
import posixpath
import subprocess
import xml.etree.ElementTree as ET
HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
STAGE=HERE/'validation'
OLD=HERE.parent/'linux-current-graph'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
results=read(STAGE/'compile-results.json')
successful={r['source']:r for r in results if r['exit_code']==0}
assert len(results)==42 and len(successful)==41
failed=[r for r in results if r['exit_code']]
assert len(failed)==1 and failed[0]['source']=='src/graph/constant_artifact.cc'
assert sum(r['kind']=='current-product' for r in successful.values())==38
assert sum(r['kind']=='new-test-owner' for r in successful.values())==3
manifest={r['relative']:r for r in read(STAGE/'source-manifest.json')}
closure={}
remote_prefix='/root/hyle-scratch/compute-unified/linux-layout-current/source/'
for r in successful.values():
 assert r['source_before']==r['source_after']
 for d in r['actual_project_dependencies']:
  rel=posixpath.normpath(d['path'][len(remote_prefix):])
  assert d['path'].startswith(remote_prefix)
  assert rel in manifest,(r['source'],rel)
  assert (d['sha256'],d['bytes'])==(manifest[rel]['sha256'],manifest[rel]['bytes']),(r['source'],rel)
  closure[rel]=d
oldinclude=[]
for r in successful.values():
 for d in r['other_dependencies']:
  if '/linux-current-graph/source/' in d['path']:oldinclude.append([r['source'],d])
assert not oldinclude
drift=[]
for rel,r in manifest.items():
 now=identity(REPO/rel)
 if now['sha256']!=r['sha256']:drift.append({'relative':rel,'frozen_sha256':r['sha256'],'current':now})
save(STAGE/'actual-project-dependency-closure.json',{'files':closure,'count':len(closure),'stale_old_overlay_headers':oldinclude,'canonical_drift_after_run':drift})

reuse=read(STAGE/'reuse-plan.json')['owners']
reuse_proof=[]
exempt={'include/hyle/compute/provider.h':'Complete diff is comments only.',
        'include/hyle/compute/resource_budget.h':'Complete diff adds only forward/friend declarations; existing fields, declarations and inline bodies unchanged.'}
for r in reuse:
 changes=r['changed_project_dependencies']
 assert all(p in exempt for p in changes),(r['source'],changes)
 assert not r['changed_source']
 reuse_proof.append({'source':r['source'],'object':r['object'],
  'actual_cached_depfile':r['depfile'],'changed_included_headers':{p:exempt[p] for p in changes},
  'reason':'Source and all included project header bytes match prior compiled source' if not changes else 'Only explicit no-emitted-code/layout header differences; full diffs retained below.'})
diffs={}
for rel in exempt:
 before=OLD/'current-source'/rel;after=STAGE/'source'/rel
 diffs[rel]=''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),after.read_text(encoding='utf-8').splitlines(True),fromfile='cached/'+rel,tofile='current/'+rel))
save(STAGE/'retained-abi-proof.json',{'owners':reuse_proof,'four_header_only_no_emitted_change_diffs':diffs,'count':len(reuse_proof)})

remote=r'''
import pathlib,json,hashlib,subprocess,sys
root=pathlib.Path('/root/hyle-scratch/compute-unified/linux-layout-current')
def identity(p):
 p=pathlib.Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
plan=json.loads((root/'link-plan.json').read_text());changed=[]
for group in ['new_objects','retained_objects','retained_native_objects','libraries']:
 for r in plan[group]:
  if identity(r['path'])!=r:changed.append({'group':group,'recorded':r,'actual':identity(r['path'])})
companion=root.parent/'linux-current-graph/native/avx2/libhyle_ggml_cpu_avx2_linux_current.so'
out={'actual_link_input_count':sum(len(plan[k]) for k in ['new_objects','retained_objects','retained_native_objects','libraries']),
 'changed_inputs':changed,'companion':identity(companion),
 'compiler':subprocess.run(['/usr/bin/g++-14','--version'],capture_output=True,text=True).stdout,
 'uname':subprocess.run(['uname','-a'],capture_output=True,text=True).stdout,
 'image':identity(root/'layout-cpu'),
 'runtime_environment':{'LD_LIBRARY_PATH_prefix':str(companion.parent)+':','inherited_suffix':'validate_remote.py retained the calling environment suffix; not separately snapshotted at run time.','test_backend':'CPU coherent host resources and ggml CPU, native_threads=1; no CUDA target or execution.'}}
print(json.dumps(out))
'''
q=subprocess.run(['wsl','-d','Ubuntu-24.04','--','python3','-c',remote],capture_output=True,text=True,encoding='utf-8',timeout=60)
assert q.returncode==0,q.stderr
runtime=json.loads(q.stdout);assert not runtime['changed_inputs'];save(STAGE/'final-input-identities.json',runtime)
xml=ET.parse(STAGE/'tests.xml').getroot()
counts={k:int(xml.attrib[k]) for k in ['tests','failures','disabled','errors']}
counts['skipped']=sum(int(s.attrib.get('skipped',0)) for s in xml.findall('testsuite'))
assert counts=={'tests':9,'failures':0,'disabled':0,'errors':0,'skipped':0},counts
cases=[s.attrib['name']+'.'+t.attrib['name'] for s in xml.findall('testsuite') for t in s.findall('testcase')]
link=read(STAGE/'link-plan.json');selection=read(STAGE/'selected-owners.json')
assert not selection['prohibited_old_hyle_host_members']
assert read(STAGE/'link-result.json')['exit_code']==0
assert read(STAGE/'run-result.json')['exit_code']==0
report={
 'status':'passed bounded actual Linux CPU layout/source/reset regression',
 'scope':'Current Windows canonical source, targeted one-way immutable source overlay in existing fixed WSL Hyle work root; current shipping-layout CPU typed graph path only.',
 'actual_environment':{'distro':'Ubuntu-24.04 / Ubuntu 24.04.4 LTS, WSL2','compiler':runtime['compiler'].splitlines()[0],'kernel':runtime['uname'].strip(),'cpu':'Intel Core i9-13900K,32 logical CPUs','gtest':'Existing GNU14 cached GTest static archives; source/hash/compiler records in ../gtest-recipe-inventory.json'},
 'actual_counts':{
  'product_cxx_success':38,'test_cxx_success':3,'cxx_attempts':42,'cxx_failures':1,
  'links':1,'link_failures':0,'test_processes':1,'gtest':counts,
  'max_host_compile_parallelism':2,'nvcc':0,'sdk_builds':0,'downloads':0,'gpu_compute_processes':0,
  'retained_self_host_objects':44,'retained_native_objects':2,'cached_libraries':8,
  'all_actual_link_inputs':runtime['actual_link_input_count']},
 'passed_cases':cases,
 'journey':'Real CPU ragged readers on two coherent resource identities bind caller payload/output once and prepare layouts 0/1/0, rejected layout/queue preparation revokes replay, retained result blocks configuration changes. Existing ConfigurationInput covers caller lease/source retention, metadata expiry, explicit full reset; InputSourceFrontier covers fresh route qualification, pending/failed sources, independent accepted prefix and scratch reuse.',
 'canonical_product_fix':{'file':'src/graph/constant_artifact.cc','before_failed_line':'PreparationQueue{.endpoint = identity}','after':'PreparationQueue{.endpoint = identity, .queue = {}}','reason':'GNU14 -Wextra -Werror missing-field-initializers for omitted Queue member. Explicit empty Queue equals prior omitted-member default construction. No public/class/ABI change and no warning suppression.','proof':identity(STAGE/'gnu-queue-init.json'),'diff':identity(STAGE/'gnu-queue-init.diff')},
 'source_closure':{'manifest':identity(STAGE/'source-manifest.json'),'synchronized_files':len(manifest),'bytes':sum(r['bytes'] for r in manifest.values()),'actual_successfully_compiled_project_dependency_files':len(closure),'canonical_drift':drift,'stale_old_project_overlay_headers':oldinclude,'proof':identity(STAGE/'actual-project-dependency-closure.json')},
 'abi_reuse':{'proof':identity(STAGE/'retained-abi-proof.json'),'statement':'Refreshed changed common Graph/Compute/batch owners rather than mixing the earlier PlanState/Provider v16 layouts. 44 self owners have unchanged source/dependency bytes except four owners whose only changed headers add comments or forward/friend declarations. All actual retained object bytes were SHA matched before link and all 95 link inputs rechecked after actual run.'},
 'original_failure_preserved':{'record':failed[0],'source':identity(STAGE/'revisions/pre-gnu-queue-init/constant_artifact.cc'),'source_manifest':identity(STAGE/'revisions/pre-gnu-queue-init/source-manifest.json')},
 'references':[identity(STAGE/n) for n in ['compile-plan.json','compile-results.json','link-plan.json','link-result.json','selected-owners.json','run-result.json','tests.xml','final-input-identities.json','retained-abi-proof.json','actual-project-dependency-closure.json','sync-command.json','sync-result.json','neighbor-sync-result.json']],
 'scripts':[identity(HERE/n) for n in ['prepare_validation.py','add_neighbors.py','validate_remote.py','finalize_validation.py']],
 'limits':['Only the one named TypedCapabilityGraph bind-once journey ran; the other typed shape/tail matrix cases were intentionally not rerun.','No Linux CUDA capture, Vulkan, model, throughput or quality acceptance.','The cached native CPU kernel/AVX2 libraries and selected native objects were reused, with exact actual identities retained; this does not claim the latest complete SDK/patch closure has been rebuilt or accepted.','No cleanup performed; product source was not copied back from WSL.'],
}
assert runtime['actual_link_input_count']==95,runtime['actual_link_input_count']
save(STAGE/'final-validation.json',report)
print(json.dumps({'report':identity(STAGE/'final-validation.json'),'gtest':counts,'canonical_drift':drift,'inputs':runtime['actual_link_input_count']},indent=2))
