"""Write the bounded read-only assessment from captured inventory."""
import collections
import hashlib
import json
import pathlib

HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def ident(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
inventory=read(HERE/'wsl-cache-inventory.json')
closure=read(HERE/'cpu-minimum-closure.json')
rows=closure['owners']
# These complete header diffs were manually inspected: provider.h changes only
# comments; resource_budget.h only adds forward/friend declarations, no layout,
# inline code, calling convention or existing function signature change.
no_emitted_change={'src/compute/copy_ranges.cc','src/compute/leased_operation.cc',
                   'src/compute/retained_completion.cc','src/compute/route_policy.cc'}
refresh=[r for r in rows if r['changed_project_dependencies'] and r['source'] not in no_emitted_change]
reuse=[r for r in rows if r not in refresh]
old=HERE.parent/'linux-current-graph'
old_plan=read(old/'compile-plan.json')
recorded={r['source']:r for r in inventory['dependencies']}
refresh_recipes=[{'source':r['source'],'cached_object':r['object'],
                  'actual_recorded_command':recorded[r['source']]['command'],
                  'reason_changed_dependencies':r['changed_project_dependencies']}
                 for r in refresh]
(HERE/'cpu-refresh-recipes.json').write_text(json.dumps(refresh_recipes,indent=2)+'\n',encoding='utf-8')
summary={
 'status':'inventory-complete; current Linux layout-reset validation NOT RUN',
 'scope':'Read-only WSL cache/toolchain/hardware/dependency assessment. No product/test/doc edits, source synchronization, compilation, link, numerical/GPU work, SDK download, clone, cache deletion or cleanup.',
 'environment':{
  'distro':'Ubuntu-24.04 (default), Ubuntu 24.04.4 LTS, WSL2',
  'kernel':inventory['uname']['release'],
  'compiler':inventory['tools'][0]['stdout'].splitlines()[0],
  'cmake':inventory['tools'][1]['stdout'].splitlines()[0],
  'ninja':inventory['tools'][2]['stdout'].strip(),
  'cpu':'13th Gen Intel Core i9-13900K, 32 logical CPUs',
  'memory_total_kib':32720076,
  'cuda':'CUDA toolkit 13.3.73 exists; queried version only',
  'gpu':'NVIDIA GeForce RTX 4070, driver 617.14, 12282 MiB; nvidia-smi identity query only, no GPU validation',
  'default_user':'root',
  'existing_fixed_work_root':'/root/hyle-scratch/compute-unified',
 },
 'latest_actual_linux_baseline':{
  'local_recipe_root':str(old.relative_to(REPO)),
  'remote_root':'/root/hyle-scratch/compute-unified/linux-current-graph',
  'compile_recipe':'linux-current-graph/compile-plan.json and compile-results.json',
  'link_recipe':'linux-current-graph/link-plan.json',
  'last_actual_result':read(old/'summary.json'),
  'interpretation':'The retained October 19 route_symmetry_cuda consumer passed its then-current ordinary finite family. It is neither a current layout-reset/bind-once test nor attention/capture/model/whole-Linux acceptance.',
  'retained_objects':{'count':len(inventory['objects']),'missing':sum(not r['exists'] for r in inventory['objects']),
    'sha_mismatch':sum(r.get('recorded_sha_matches') is False for r in inventory['objects']),
    'verification':'All 190 actual retained objects were read and SHA-256 matched against the retained receipt.'},
  'retained_libraries':{'count':len(inventory['libraries']),'missing':sum(not r['exists'] for r in inventory['libraries']),
    'size_mismatch':sum(r.get('recorded_size_matches') is False for r in inventory['libraries']),
    'verification':'Existence and exact byte size checked; these 11 libraries were not all rehashed in this inventory.'},
  'recipe_warning':'Recorded include paths point at the OLD linux-current-graph/source overlay. A future incremental build must replace every changed project header in its selected closure together with changed CXX sources; merely substituting four .cc paths would compile against stale ABI.',
 },
 'four_owner_increment_is_not_sufficient':{
  'answer':False,
  'reason':'This Linux baseline predates multiple shared ABI/extension changes that were already present in the more recent Windows/Mac baselines. The four layout-reset CXX sources alone cannot safely reuse this older Linux Graph/Compute host closure.',
  'specific_current_source_anchors':[
   {'path':'src/graph/plan_state.h','line':737,'fact':'PlanState and InvocationState (line 1130) gained fields and changed inline access; seven actually compiled Graph core owners include this header.'},
   {'path':'include/hyle/graph/executable.h','line':100,'fact':'StorageDomain/ConstantBinding retain new owner/lease fields; existing structure layouts differ from the cache.'},
   {'path':'include/hyle/graph/region_provider.h','line':21,'fact':'Region extension 26 -> 30, changed payload/compile request/callback structures.'},
   {'path':'src/compute/provider_internal.h','line':27,'fact':'Provider contract 16 -> 17; stale factories are rejected by current Context.'},
   {'path':'include/hyle/compute/detail/prepared_callbacks.h','line':49,'fact':'Prepared operation callback table gains prepare_bindings.'},
   {'path':'include/hyle/compute/detail/queue_sequence.h','line':128,'fact':'QueueSequence gains recording_ state; old inline constructors/users cannot be silently mixed with the current layout.'},
   {'path':'include/hyle/compute/detail/batch_provider.h','line':36,'fact':'Batch extension 6 -> 7 / MLA 4 -> 5 and workspace callback signature changed.'},
  ],
  'graph_planstate_actual_owners':read(HERE/'abi-header-owners.json')['src/graph/plan_state.h']['owners'],
 },
 'smallest_recommended_next_validation':{
  'target':'Existing CPU hyle_graph_batch_typed_capability_test; start with TypedCapabilityGraph.SharedMetadataAcrossHostResourcesSurvivesLayoutUpdates (bind once, three actual layout generations, failed preparation revokes readiness).',
  'target_cmake_anchor':'tests/graph_batch/CMakeLists.txt:6',
  'test_source_anchor':'tests/graph_batch/typed_capability_graph_test.cc:47; caller binds only in round==0 at lines 158-164',
  'reason':'Exercises the same common layout reset through the low-level CPU+ggml typed path and real metadata owners, without pulling default Torch/oneDNN/CUDA route products into this next validation.',
  'roots':closure['roots'], 'modules':closure['modules'],
  'actual_cached_selected_host_objects':len(rows),
  'conservative_raw_header_drift_candidates':42,
  'recommended_self_cxx_refresh':len(refresh),
  'refresh_by_module':dict(collections.Counter(r['module'] for r in refresh)),
  'additional_test_cxx':1,
  'proposed_link_count':1,
  'sdk_or_nvcc_rebuild_required_by_these_changes':False,
  'estimate_limitation':'38 self CXX + 1 test is a bounded source/dependency-derived refresh candidate, not an executed link or an assertion of the mathematically smallest possible TU set. Further reduction is optional; do not refresh all 156 historical host owners or any SDK just because they existed in the larger route image.',
  'refresh_sources':[r['source'] for r in refresh],
  'reuse_sources':[r['source'] for r in reuse],
  'four_explicit_no_emitted_change_reuses':{
   'sources':sorted(no_emitted_change),
   'proof':'Their only changed included project headers are provider.h (comments only) and/or resource_budget.h (forward/friend declarations only). The source bodies are byte-identical to the retained compiled snapshots; existing layouts/inline definitions/signatures did not change.'},
  'recipe_file':'cpu-refresh-recipes.json preserves every actual GNU14 compiler command; future source/header/output overlay changes must be explicit, not described as an already-run command.',
  'existing_native_cache':'Reuse the original ggml/base/CPU, AVX2 companion, SIMD/container/mimalloc and any transitive libraries actually selected by the new link. Keep selected-member/map checking so old Hyle host archive members do not silently replace current source. Existing full link and native identities are retained in linux-current-graph; no numerical kernel build has been authorized/performed here.',
  'gtest':{
    'source':'/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest',
    'lib':'/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/build/lib/libgtest.a',
    'main':'/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/build/lib/libgtest_main.a',
    'provenance':'Existing GNU14 gtest-all/gtest_main compile_commands and CMakeCache retained, both archives and gtest.h freshly SHA-256 inventoried in gtest-recipe-inventory.json.',
    'missing_current_owner':'No actual cached Linux typed_capability_graph_test.cc or batch_capture_test.cc compile recipe/object was found in the inspected source-build caches or selected consumer databases. Their exact Linux test compile command still needs generation/derivation from the current target and these genuine GNU14/GTest records; do not call a Windows recipe a Linux receipt.'},
 },
 'not_done':['No current Linux bind-once/capture/attention tests ran.','No conclusion about Linux CUDA graph capture or latest full native SDK/patch closure.','No full model, numerical quality, throughput, memory or all-provider acceptance.'],
 'evidence':[ident(p) for p in [HERE/'wsl-cache-inventory.json',HERE/'hardware-gtest-inventory.json',HERE/'gtest-recipe-inventory.json',HERE/'actual-owner-dependencies.json',HERE/'abi-header-owners.json',HERE/'cached-source-drift.json',HERE/'cpu-minimum-closure.json',HERE/'cpu-refresh-recipes.json']],
 'current_relevant_source_identities':[ident(REPO/p) for p in ['src/graph/executable.cc','src/graph/resources.cc','src/graph/input_sources.cc','src/graph_batch/batch.cc','src/graph/plan_state.h','include/hyle/graph/executable.h','include/hyle/graph/region_provider.h','src/compute/provider_internal.h','include/hyle/compute/detail/prepared_callbacks.h','include/hyle/compute/detail/queue_sequence.h','include/hyle/compute/detail/batch_provider.h','tests/graph_batch/typed_capability_graph_test.cc','tests/graph_batch/CMakeLists.txt']],
}
(HERE/'review.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'report':ident(HERE/'review.json'),'refresh_cxx':len(refresh),'reuse_host_objects':len(reuse),'test_cxx':1},indent=2))
