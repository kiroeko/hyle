"""Run the explicitly bounded GNU14 CPU increment using existing caches."""
import concurrent.futures
import hashlib
import json
import os
import pathlib
import re
import shlex
import subprocess
import sys
import threading
import time

ROOT=pathlib.Path('/root/hyle-scratch/compute-unified/linux-layout-current')
OLD=ROOT.parent/'linux-current-graph'
SDK=ROOT.parent/'l-cpu-cuda/selected-graph/static-sdk-relocated'
LOCAL=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/linux-layout-current-review/validation')
lock=threading.Lock()
def read(p):return json.loads(p.read_text())
def identity(p):
 p=pathlib.Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
def save(n,v):
 data=json.dumps(v,indent=2)+'\n'
 for base in [ROOT,LOCAL]:
  p=base/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
def invoke(tag,command,env=None):
 start=time.monotonic()
 out=ROOT/'logs'/f'{tag}.stdout.log';err=ROOT/'logs'/f'{tag}.stderr.log'
 with out.open('wb') as o,err.open('wb') as e:
  q=subprocess.run(command,cwd=ROOT,stdout=o,stderr=e,env=env)
 r={'tag':tag,'command':command,'exit_code':q.returncode,'seconds':time.monotonic()-start,'stdout':identity(out),'stderr':identity(err)}
 for p in [out,err]:(LOCAL/'logs'/p.name).write_bytes(p.read_bytes())
 return r
def compile_all():
 plan=read(ROOT/'compile-plan.json')['entries']
 results=read(ROOT/'compile-results.json') if (ROOT/'compile-results.json').exists() else []
 good={r['source'] for r in results if r['exit_code']==0}
 pending=[r for r in plan if r['source'] not in good]
 def one(row):
  source=ROOT/'source'/row['source'];before=identity(source)
  stem=f'compile-{len(results):03d}-{row["source"].replace("/","--")}'
  r=invoke(stem,row['command']);r.update(source=row['source'],kind=row['kind'],source_before=before,source_after=identity(source))
  dep=pathlib.Path(row['object']+'.d')
  if r['exit_code']==0:
   r['object']=identity(row['object']);r['depfile']=identity(dep)
   text=dep.read_text();(LOCAL/'deps'/dep.name).write_text(text)
   tokens=shlex.split(text.replace('\\\n',' ').split(':',1)[1])
   r['actual_project_dependencies']=[identity(p) for p in sorted(set(tokens)) if p.startswith(str(ROOT/'source')+'/')]
   r['other_dependencies']=[identity(p) for p in sorted(set(tokens)) if not p.startswith(str(ROOT/'source')+'/')]
  with lock:
   results.append(r);save('compile-results.json',results)
   print('CXX',len(results),r['exit_code'],row['source'],round(r['seconds'],2),flush=True)
   if r['exit_code']:print(pathlib.Path(r['stderr']['path']).read_text()[-7000:],flush=True)
  return r['exit_code']
 (LOCAL/'logs').mkdir(exist_ok=True);(LOCAL/'deps').mkdir(exist_ok=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  exits=list(pool.map(one,pending))
 raise SystemExit(int(any(exits)))
def link():
 results=read(ROOT/'compile-results.json');latest={r['source']:r for r in results if r['exit_code']==0}
 plan=read(ROOT/'compile-plan.json')['entries'];assert all(r['source'] in latest for r in plan)
 reuse=read(ROOT/'reuse-plan.json')
 ids={r['path']:r for r in read(LOCAL.parent/'wsl-cache-inventory.json')['objects'] for r in [r['recorded']]}
 retained=[]
 for row in reuse['owners']:
  got=identity(row['object']);assert got==ids[row['object']],got
  retained.append(got)
 current=[r['object'] for r in latest.values()]
 native=[identity(OLD/'native'/n) for n in ['ggml-alloc.c.o','ops.cpp.o']]
 for r in native:assert r==ids[r['path']]
 all_objects=current+retained+native
 libraries=[SDK/'lib'/n for n in ['libhyle_container.a','libhyle_simd.a','libggml.a','libggml-cpu.a','libggml-base.a','libmimalloc_static.a']]
 gt=ROOT.parent/'g06-final-sdk/cuda-static-1/build/lib'
 libraries+=[gt/'libgtest_main.a',gt/'libgtest.a']
 cmd=['/usr/bin/g++-14','-O3','-DNDEBUG','-pthread','-Wl,--disable-new-dtags',
  '-Wl,-rpath,'+str(OLD/'native/avx2'),*[r['path'] for r in all_objects],
  '-Wl,--start-group',*map(str,libraries),'-Wl,--end-group','-ldl','-lm',
  '-Wl,-Map,'+str(ROOT/'layout-cpu.map'),'-o',str(ROOT/'layout-cpu')]
 save('link-plan.json',{'command':cmd,'new_objects':current,'retained_objects':retained,'retained_native_objects':native,
  'libraries':[identity(p) for p in libraries]})
 r=invoke('link-01',cmd);save('link-result.json',r)
 print('LINK',r['exit_code'],round(r['seconds'],2),flush=True)
 if r['exit_code']:
  print(pathlib.Path(r['stderr']['path']).read_text()[-10000:],flush=True);raise SystemExit(r['exit_code'])
 text=(ROOT/'layout-cpu.map').read_text();(LOCAL/'layout-cpu.map').write_text(text)
 members=sorted(set(re.findall(r'(\S+\.a)\(([^\n)]+)\)',text)))
 bad=[r for r in members if '/libhyle_' in r[0] and not (r[0].endswith('/libhyle_simd.a') or r[0].endswith('/libhyle_container.a') and 'container_bitset' in r[1])]
 assert not bad,bad
 assert not any(a.endswith('/libggml-base.a') and m=='ggml-alloc.c.o' for a,m in members)
 save('selected-owners.json',{'image':identity(ROOT/'layout-cpu'),'map':identity(ROOT/'layout-cpu.map'),'members':members,'prohibited_old_hyle_host_members':bad})
def run():
 selected=read(ROOT/'selected-owners.json');assert identity(ROOT/'layout-cpu')==selected['image']
 # This is deliberately a named journey, not the full TypedCapability matrix.
 filt=('TypedCapabilityGraph.SharedMetadataAcrossHostResourcesSurvivesLayoutUpdates'
       ':ConfigurationInput.*:InputSourceFrontier.*')
 env=os.environ.copy();env['LD_LIBRARY_PATH']=str(OLD/'native/avx2')+':'+env.get('LD_LIBRARY_PATH','')
 cmd=[str(ROOT/'layout-cpu'),'--gtest_filter='+filt,'--gtest_output=xml:'+str(ROOT/'tests.xml')]
 r=invoke('run-bind-once',cmd,env);save('run-result.json',r)
 if (ROOT/'tests.xml').exists():(LOCAL/'tests.xml').write_bytes((ROOT/'tests.xml').read_bytes())
 print('RUN',r['exit_code'],flush=True);print(pathlib.Path(r['stdout']['path']).read_text()[-6500:],flush=True)
 raise SystemExit(r['exit_code'])
if __name__=='__main__':
 {'compile':compile_all,'link':link,'run':run}[sys.argv[1]]()
