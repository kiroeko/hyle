"""Add two authorized existing Graph test owners and the one GCC init fix."""
import difflib
import hashlib
import json
import pathlib
import re
import subprocess
import shutil
HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
STAGE=HERE/'validation'
REMOTE='/root/hyle-scratch/compute-unified/linux-layout-current'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def identity(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
revision=STAGE/'revisions/pre-gnu-queue-init'
shutil.copyfile(STAGE/'source-manifest.json',revision/'source-manifest.json')
manifest=read(STAGE/'source-manifest.json');existing={r['relative']:r for r in manifest}
sources=['tests/graph/configuration_input_test.cc','tests/graph/input_source_frontier_test.cc']
paths=set(sources+['tests/graph/CMakeLists.txt'])
roots=[REPO/'include',REPO,*[p for p in (REPO/'src').iterdir() if p.is_dir()]]
pending=list(paths)
while pending:
 rel=pending.pop();p=REPO/rel
 if p.suffix not in ['.h','.cc','.hpp','.inc']:continue
 for token in re.findall(r'^\s*#\s*include\s*[<"]([^">]+)[">]',p.read_text(encoding='utf-8'),re.M):
  for parent in [p.parent,*roots]:
   q=parent/token
   if q.is_file() and q.resolve().is_relative_to(REPO):
    found=q.resolve().relative_to(REPO).as_posix()
    if found not in paths:paths.add(found);pending.append(found)
    break
paths.add('src/graph/constant_artifact.cc')
changed=[]
for rel in sorted(paths):
 src=REPO/rel;out=STAGE/'source'/rel;data=src.read_bytes()
 if out.exists() and out.read_bytes()!=data:
  assert rel=='src/graph/constant_artifact.cc',rel
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 existing[rel]={'relative':rel,**identity(out),'canonical_source':identity(src)}
 changed.append({'relative':rel,'sha256':hashlib.sha256(data).hexdigest()})
save(STAGE/'source-manifest.json',[existing[r] for r in sorted(existing)])
old=revision/'constant_artifact.cc';new=REPO/'src/graph/constant_artifact.cc'
(STAGE/'gnu-queue-init.diff').write_text(''.join(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(True),new.read_text(encoding='utf-8').splitlines(True),fromfile='before/src/graph/constant_artifact.cc',tofile='after/src/graph/constant_artifact.cc')),encoding='utf-8')
save(STAGE/'gnu-queue-init.json',{'before':identity(old),'after':identity(new),'difference':'Explicit empty .queue = {} for omitted aggregate field, no layout or runtime behavior change; preserved -Werror.'})
plan=read(STAGE/'compile-plan.json');base=next(r for r in plan['entries'] if r['kind']=='new-test-owner')
for rel in sources:
 obj=REMOTE+'/objects/'+rel.replace('/','--')+'.o';cmd=base['command'].copy()
 cmd[cmd.index('-MF')+1]=obj+'.d';cmd[cmd.index('-c')+1]=REMOTE+'/source/'+rel;cmd[cmd.index('-o')+1]=obj
 plan['entries'].append({'source':rel,'object':obj,'kind':'new-test-owner','command':cmd,
  'provenance':['Current tests/graph/CMakeLists.txt hyle_graph_executable_test existing source owner',*base['provenance']],
  'not_a_historical_receipt':True})
save(STAGE/'compile-plan.json',plan)
remote=r'''
import pathlib,json,sys,hashlib,shutil
x=json.load(sys.stdin);local=pathlib.Path(x['local']);root=pathlib.Path(x['remote']);copied=[]
for r in x['files']:
 p=local/'source'/r['relative'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==r['sha256']
 q=root/'source'/r['relative'];q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists() and q.read_bytes()!=data:
  assert r['relative']=='src/graph/constant_artifact.cc'
  before=root/'revisions/pre-gnu-queue-init/constant_artifact.cc';before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(q.read_bytes())
 q.write_bytes(data);copied.append({'path':str(q),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
for n in ['compile-plan.json','source-manifest.json','gnu-queue-init.json']:shutil.copyfile(local/n,root/n)
print(json.dumps({'copied':copied}))
'''
payload={'files':changed,'local':'/mnt/c/public/project-hyle/hyle/'+STAGE.relative_to(REPO).as_posix(),'remote':REMOTE}
q=subprocess.run(['wsl','-d','Ubuntu-24.04','--','python3','-c',remote],input=json.dumps(payload),capture_output=True,text=True,encoding='utf-8',timeout=60)
save(STAGE/'neighbor-sync-result.json',{'remote_source':remote,'exit_code':q.returncode,'stderr':q.stderr,'result':json.loads(q.stdout) if q.returncode==0 else q.stdout})
if q.returncode:raise SystemExit(q.stderr)
print(json.dumps({'commands':len(plan['entries']),'source_files':len(existing),'synced_files':len(changed)},indent=2))
