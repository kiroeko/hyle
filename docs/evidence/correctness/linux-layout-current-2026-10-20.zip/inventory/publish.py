"""Publish only the actual nine-case Linux CPU result and its small closure."""
import hashlib
import json
import pathlib
import re
import xml.etree.ElementTree as ET
import zipfile

HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
STAGE=HERE/'validation'
DEST=REPO/'docs/evidence/correctness'
NAME='linux-layout-current-2026-10-20'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def data_json(x):return (json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
def digest(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def identity(p):return {'path':str(p),**digest(p.read_bytes())}
report=read(STAGE/'final-validation.json')
assert report['actual_counts']['gtest']=={'tests':9,'failures':0,'disabled':0,'errors':0,'skipped':0}
assert not report['source_closure']['canonical_drift']
assert report['actual_counts']['links']==1 and report['actual_counts']['test_processes']==1
assert read(STAGE/'run-result.json')['exit_code']==0
assert read(STAGE/'link-result.json')['exit_code']==0
xml=ET.parse(STAGE/'tests.xml').getroot()
actual_names=[s.attrib['name']+'.'+t.attrib['name'] for s in xml.findall('testsuite') for t in s.findall('testcase')]
assert actual_names==report['passed_cases']

# Keep the complete archive-member selection prefix and LOAD lines. Discard
# the multi-megabyte per-symbol map body, whose exact identity remains recorded.
fullmap=(STAGE/'layout-cpu.map').read_text(encoding='utf-8')
cut=fullmap.find('Merging program properties')
if cut<0:cut=fullmap.find('Discarded input sections')
assert 0<cut<100000,cut
prefix=fullmap[:cut]
loads='\n'.join(line for line in fullmap.splitlines() if line.startswith('LOAD '))+'\n'
excerpt=prefix+'\n--- Actual LOAD inputs (symbol/body sections omitted) ---\n'+loads
(STAGE/'map-excerpt.txt').write_text(excerpt,encoding='utf-8')
selected=read(STAGE/'selected-owners.json')
assert not selected['prohibited_old_hyle_host_members']
assert digest((STAGE/'layout-cpu.map').read_bytes())=={k:selected['map'][k] for k in ['bytes','sha256']}
members=sorted(set(re.findall(r'(\S+\.a)\(([^\n)]+)\)',fullmap)))
assert [list(r) for r in members]==selected['members']
map_receipt={'full_map':selected['map'],'excerpt':identity(STAGE/'map-excerpt.txt'),
 'complete_selected_archive_members':selected['members'],
 'prohibited_old_hyle_host_members':[],
 'reason':'The complete member-selection prefix and every actual LOAD line are retained; per-symbol body omitted. Original full map hash retained, with actual selection checked before publishing.'}
(STAGE/'map-excerpt.json').write_bytes(data_json(map_receipt))

payload={}
def add(path,member):
 p=pathlib.PurePosixPath(member)
 assert member==p.as_posix() and not p.is_absolute() and '..' not in p.parts and ':' not in member and '\\' not in member,member
 assert member not in payload and member.casefold() not in {k.casefold() for k in payload},member
 assert path.suffix.lower() not in ['.o','.obj','.exe','.a','.lib','.so','.dll','.dylib','.map','.pdb','.cubin','.ptx','.metallib','.bin'],path
 assert '__pycache__' not in path.parts
 payload[member]=path.read_bytes()

# The inventory is small metadata, not the 190 objects or any cached library.
for p in sorted(HERE.iterdir()):
 if p.is_file() and p.suffix in ['.py','.json']:
  add(p,'inventory/'+p.name)
# Current targeted source closure and actual compile/run records. The original
# historical Linux baseline .cc snapshots are not necessary to rerun these
# current tests; retain only its relevant ABI/declaration headers and the exact
# separate GNU-failure source revision.
retained_before_headers={
 'include/hyle/compute/provider.h','include/hyle/compute/resource_budget.h',
 'include/hyle/compute/detail/prepared_callbacks.h','include/hyle/compute/detail/queue_sequence.h',
 'include/hyle/compute/detail/batch_provider.h','include/hyle/graph/executable.h',
 'include/hyle/graph/region_provider.h','src/graph/plan_state.h',
 'src/compute/provider_internal.h'}
for p in sorted(STAGE.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(STAGE).as_posix()
 if p.suffix=='.map' or '__pycache__' in p.parts:continue
 if rel.startswith('before-source/') and rel[len('before-source/'):] not in retained_before_headers:continue
 add(p,'validation/'+rel)

manifest={'format':'Hyle evidence payload SHA256 v1','date':'2026-10-20',
 'scope':'Actual Linux CPU nine-case layout/configuration/input-source regression only.',
 'payloads':[{'member':n,**digest(payload[n])} for n in sorted(payload)]}
payload['payload-manifest.json']=data_json(manifest)
DEST.mkdir(parents=True,exist_ok=True)
zpath=DEST/(NAME+'.zip')
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for member in sorted(payload):
  info=zipfile.ZipInfo(member,(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  info.external_attr=0o100644<<16
  z.writestr(info,payload[member],compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)

# Reopen the actual bytes written, test CRCs and every manifest SHA, and reject
# duplicates, traversal, drive prefixes, binary/cache payloads and symlinks.
with zipfile.ZipFile(zpath) as z:
 names=z.namelist();assert len(names)==len(set(names))==len({n.casefold() for n in names})
 assert z.testzip() is None
 for info in z.infolist():
  n=info.filename;p=pathlib.PurePosixPath(n)
  assert not p.is_absolute() and '..' not in p.parts and ':' not in n and '\\' not in n
  assert ((info.external_attr>>16)&0o170000)!=0o120000
  assert z.read(n)==payload[n]
 actual_manifest=json.loads(z.read('payload-manifest.json'))
 assert {r['member'] for r in actual_manifest['payloads']}==set(names)-{'payload-manifest.json'}
 for r in actual_manifest['payloads']:
  assert digest(z.read(r['member']))=={k:r[k] for k in ['bytes','sha256']}

key_members=['validation/final-validation.json','validation/compile-plan.json',
 'validation/compile-results.json','validation/link-plan.json','validation/link-result.json',
 'validation/run-result.json','validation/tests.xml','validation/source-manifest.json',
 'validation/actual-project-dependency-closure.json','validation/retained-abi-proof.json',
 'validation/final-input-identities.json','validation/map-excerpt.json','validation/map-excerpt.txt',
 'validation/gnu-queue-init.json','validation/gnu-queue-init.diff',
 'validation/revisions/pre-gnu-queue-init/constant_artifact.cc',
 'validation/source/src/graph/constant_artifact.cc']
summary={
 'date':'2026-10-20','status':'Linux_CPU_nine_case_regression_executed',
 'problem':'The current layout-reset fix had actual Windows/Mac coverage but had not run against the older retained Linux host closure.',
 'behavior':'Actual CPU graph journeys retain ordinary caller bindings and source/lease owners across layout configuration changes, revoke metadata/preparation on failures, gate mutation on retained results, and preserve full Invocation::reset clearing semantics.',
 'actual':{'platform':report['actual_environment'],'cases':9,'failures':0,'skipped':0,'exit_code':0,
  'names':actual_names,'counts':report['actual_counts'],
  'closure':{'current_source_files':report['source_closure']['synchronized_files'],
   'actual_compiler_project_dependency_files':report['source_closure']['actual_successfully_compiled_project_dependency_files'],
   'stale_old_overlay_headers':0,'canonical_source_drift':0,'actual_link_inputs_rechecked':95}},
 'build_diagnostic':{'failed_attempts':1,'file':'src/graph/constant_artifact.cc',
  'diagnostic':'GNU14 -Wextra -Werror missing-field-initializers for PreparationQueue::queue.',
  'fix':'Explicit .queue = {} at the existing aggregate initialization. Same empty Queue default construction, no layout/ABI change and no warning suppression.',
  'failure_source_and_log_preserved':True},
 'reuse':'38 product CXX plus three existing test owners were rebuilt; 44 compatible host objects, two native objects and eight cached libraries were SHA verified. No SDK/NVCC/download/whole-suite or GPU execution was performed.',
 'scope_limits':report['limits'],
 'evidence':[{'member':n,**digest(payload[n])} for n in key_members],
 'archive':{**identity(zpath),'payloads':len(payload),
  'uncompressed_bytes':sum(len(v) for v in payload.values()),'CRC_checked':True,
  'all_payload_SHA256_checked':True,'safe_paths_and_unique_names_checked':True,
  'payload_manifest':{'member':'payload-manifest.json',**digest(payload['payload-manifest.json'])},
  'excluded':'No object/executable/archive/shared-library/SDK/cache payloads; full per-symbol map body and unneeded historical baseline .cc snapshots omitted.'}}
json_path=DEST/(NAME+'.json');json_path.write_bytes(data_json(summary))

# Verify the published JSON itself against the reopened ZIP, not only the
# in-memory input dictionary used when preparing the package.
published=read(json_path)
assert identity(zpath)=={k:published['archive'][k] for k in ['path','bytes','sha256']}
with zipfile.ZipFile(zpath) as z:
 for r in [*published['evidence'],published['archive']['payload_manifest']]:
  assert digest(z.read(r['member']))=={k:r[k] for k in ['bytes','sha256']}
 assert published['archive']['payloads']==len(z.namelist())
receipt={'json':identity(json_path),'zip':identity(zpath),'payloads':len(payload),
 'CRC':True,'all_payload_SHA256':True,'JSON_member_identities_match_ZIP':True,
 'safe_paths_unique_names_no_symlink_or_binaries':True}
(STAGE/'publication-receipt.json').write_bytes(data_json(receipt))
print(json.dumps(receipt,indent=2))
