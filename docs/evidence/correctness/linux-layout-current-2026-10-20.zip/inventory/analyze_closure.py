"""Analyze retained actual .d data against the authoritative current source."""
import hashlib
import json
import pathlib
import shlex

HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
OLD=HERE.parent/'linux-current-graph'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(n,x):(HERE/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
inventory=read(HERE/'wsl-cache-inventory.json')
cached={r['relative']:r for r in read(OLD/'final-source-identities.json')}
drift={r['relative']:r for r in read(HERE/'cached-source-drift.json')}
prefixes=['/root/hyle-scratch/compute-unified/linux-current-graph/source/','/mnt/c/public/project-hyle/hyle/']
def relative(p):
 for pre in prefixes:
  if p.startswith(pre):return p[len(pre):]
 return None
abi_headers={
 'src/graph/plan_state.h':'PlanState/InvocationState/member layouts and inlined access changed',
 'include/hyle/graph/executable.h':'StorageDomain/ConstantBinding contain new retained owner/lease fields; InvocationReport counters added',
 'include/hyle/graph/region_provider.h':'Region provider extension 26 -> 30; request/payload/vtable and constant artifact callback contracts changed',
 'src/compute/provider_internal.h':'Provider contract version 16 -> 17; old factories are rejected by current Context',
 'include/hyle/compute/detail/prepared_callbacks.h':'PreparedOperationVTable gains prepare_bindings callback',
 'include/hyle/compute/detail/command_capture.h':'CommandCapture extension 1 -> 2, trailing stable-identity fact',
 'include/hyle/compute/detail/queue_sequence.h':'QueueSequence gains recording_ member and inlined recording accessor',
 'include/hyle/compute/detail/batch_provider.h':'Batch planning extension 6 -> 7 / MLA 4 -> 5; workspace callback gains bool parameter',
 'include/hyle/graph/detail/region_access.h':'ResourcePayloadVTable reset callback signature changed',
 'src/compute_backend_cuda/native_context.h':'defer_native_retirement return type changed void -> NativeRetirement',
}
records=[]
for r in inventory['dependencies']:
 text=r.get('text','').replace('\\\n',' ')
 parts=shlex.split(text.split(':',1)[1]) if ':' in text else []
 deps=sorted({rel for p in parts if (rel:=relative(p))})
 changed=[p for p in deps if p in drift]
 records.append({'source':r['source'],'object':r['object'],'depfile':r['depfile'],
  'depfile_exists':r.get('exists',False),'project_dependencies':deps,
  'changed_project_dependencies':changed,
  'changed_source':r['source'] in drift,
  'abi_header_dependencies':{p:abi_headers[p] for p in deps if p in abi_headers}})
save('actual-owner-dependencies.json',records)
save('abi-header-owners.json',{
 p:{'reason':why,'owners':[r['source'] for r in records if p in r['abi_header_dependencies']]}
 for p,why in abi_headers.items()})
graphcore=[r['source'] for r in records if 'src/graph/plan_state.h' in r['abi_header_dependencies']]
print(json.dumps({'owners':len(records),'owners_with_any_snapshot_drift':sum(bool(r['changed_project_dependencies']) for r in records),
 'abi_header_owner_counts':{p:sum(p in r['abi_header_dependencies'] for r in records) for p in abi_headers},
 'graphcore_layout_owners':graphcore,
 'changed_self_sources':[r['source'] for r in records if r['changed_source']]},indent=2))
