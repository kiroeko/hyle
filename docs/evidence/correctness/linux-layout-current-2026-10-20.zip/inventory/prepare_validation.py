"""Prepare a targeted immutable Linux source overlay, without building SDKs."""
import hashlib
import json
import pathlib
import re
import subprocess

HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
STAGE=HERE/'validation'
STAGE.mkdir(exist_ok=True)
REMOTE='/root/hyle-scratch/compute-unified/linux-layout-current'
OLD_REMOTE='/root/hyle-scratch/compute-unified/linux-current-graph'
OLD=HERE.parent/'linux-current-graph'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def identity(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}

review=read(HERE/'review.json')
refresh=set(review['smallest_recommended_next_validation']['refresh_sources'])
cached=read(HERE/'cpu-minimum-closure.json')['owners']
deps=read(HERE/'wsl-cache-inventory.json')['dependencies']
by_source={r['source']:r for r in deps}
test_sources=['tests/graph_batch/typed_capability_graph_test.cc']
paths=set(p for r in cached for p in r['project_dependencies'])
paths.update(test_sources)
paths.update(['cmake/HyleModule.cmake','cmake/HyleWarnings.cmake','cmake/HyleComputeCapabilities.cmake',
              'cmake/HyleComponents.cmake','cmake/HyleTesting.cmake','tests/graph_batch/CMakeLists.txt'])
# Follow literal current project includes so new private headers do not silently
# fall back to the older Linux overlay. SDK headers keep their recorded roots.
include_roots=[REPO/'include',REPO]
for r in deps:
 c=r['command']
 for i,t in enumerate(c[:-1]):
  if t=='-I':
   old=c[i+1]
   for pre in [OLD_REMOTE+'/source/','/mnt/c/public/project-hyle/hyle/']:
    if old.startswith(pre):include_roots.append(REPO/old[len(pre):])
include_roots=list(dict.fromkeys(include_roots))
pending=list(paths);visited=set()
while pending:
 rel=pending.pop()
 if rel in visited:continue
 visited.add(rel);p=REPO/rel
 if not p.is_file():raise RuntimeError('missing current project dependency: '+rel)
 if p.suffix not in ['.h','.cc','.c','.cpp','.inc','.hpp']:continue
 for token in re.findall(r'^\s*#\s*include\s*[<"]([^">]+)[">]',p.read_text(encoding='utf-8',errors='strict'),re.M):
  for parent in [p.parent,*include_roots]:
   q=parent/token
   if q.is_file() and q.resolve().is_relative_to(REPO):
    found=q.resolve().relative_to(REPO).as_posix()
    if found not in paths:paths.add(found);pending.append(found)
    break

manifest=[]
for rel in sorted(paths):
 source=REPO/rel;out=STAGE/'source'/rel;out.parent.mkdir(parents=True,exist_ok=True)
 data=source.read_bytes()
 if out.exists() and out.read_bytes()!=data:raise RuntimeError('frozen local overlay differs: '+rel)
 out.write_bytes(data)
 manifest.append({'relative':rel,**identity(out),'canonical_source':identity(source)})
before=[]
for rel in sorted(paths):
 old=OLD/'current-source'/rel
 if old.exists() and old.read_bytes()!=(REPO/rel).read_bytes():
  out=STAGE/'before-source'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(old.read_bytes())
  before.append({'relative':rel,**identity(out)})
write(STAGE/'source-manifest.json',manifest)
write(STAGE/'before-source-manifest.json',before)

commands=[]
for rel in sorted(refresh):
 r=by_source[rel];cmd=r['command']
 new=[]
 for token in cmd:
  if token.startswith(OLD_REMOTE+'/source'):token=token.replace(OLD_REMOTE+'/source',REMOTE+'/source',1)
  elif token.startswith(OLD_REMOTE+'/objects/'):token=token.replace(OLD_REMOTE+'/objects/',REMOTE+'/objects/',1)
  elif token.startswith('/mnt/c/public/project-hyle/hyle'):token=token.replace('/mnt/c/public/project-hyle/hyle',REMOTE+'/source',1)
  new.append(token)
 commands.append({'source':rel,'kind':'current-product','recorded_command':cmd,'command':new,
  'object':new[new.index('-o')+1]})
# New GNU test-owner command: current hyle_add_test/Warnings + inherited public
# C++23/static/capability flags; no HYLE_TESTING instrumentation was enabled in
# this shipping-layout baseline. It is explicitly NOT an old executed receipt.
base=by_source['src/graph_batch/batch.cc']['command']
flags=base[1:base.index('-MMD')]
flags=[f for f in flags if f not in ['-DHYLE_GRAPH_BATCH_BUILD','-fPIC','-fvisibility=hidden','-fvisibility-inlines-hidden']]
mapped=[]
for t in flags:
 t=t.replace(OLD_REMOTE+'/source',REMOTE+'/source').replace('/mnt/c/public/project-hyle/hyle',REMOTE+'/source')
 mapped.append(t)
gtest='/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest'
for rel in test_sources:
 obj=REMOTE+'/objects/'+rel.replace('/','--')+'.o'
 cmd=['/usr/bin/g++-14',*mapped,'-isystem',gtest+'/include','-MMD','-MF',obj+'.d','-c',REMOTE+'/source/'+rel,'-o',obj]
 commands.append({'source':rel,'kind':'new-test-owner','command':cmd,'object':obj,
  'provenance':['current tests/graph_batch/CMakeLists.txt typed_capability target',
   'current cmake/HyleModule.cmake hyle_add_test and HyleWarnings.cmake',
   'recorded Linux GNU14 Release C++23/static/capability flags',
   'existing genuine GNU14 GoogleTest source/archive recipes; no instrumentation'],
  'not_a_historical_receipt':True})
write(STAGE/'compile-plan.json',{'entries':commands,'max_parallel':2})
write(STAGE/'reuse-plan.json',{'owners':[r for r in cached if r['source'] not in refresh],
 'libraries':read(OLD/'link-plan.json')['retained_libraries'],
 'runtime':read(OLD/'link-plan.json')['runtime'],
 'original_link':read(OLD/'link-plan.json'),'remote_root':REMOTE})

payload={'files':[{'relative':r['relative'],'sha256':r['sha256']} for r in manifest],
 'local_stage':'/mnt/c/public/project-hyle/hyle/'+STAGE.relative_to(REPO).as_posix(),
 'remote':REMOTE}
remote=r'''
import json,pathlib,sys,hashlib,shutil
x=json.load(sys.stdin);source=pathlib.Path(x['local_stage']);root=pathlib.Path(x['remote']);root.mkdir(parents=True,exist_ok=True)
out=[]
for r in x['files']:
 p=source/'source'/r['relative'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==r['sha256']
 q=root/'source'/r['relative'];q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert q.read_bytes()==data,str(q)
 else:q.write_bytes(data)
 out.append({'path':str(q),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
for name in ['compile-plan.json','reuse-plan.json','source-manifest.json','before-source-manifest.json']:
 shutil.copyfile(source/name,root/name)
(root/'objects').mkdir(exist_ok=True);(root/'logs').mkdir(exist_ok=True)
print(json.dumps({'synced':len(out),'bytes':sum(r['bytes'] for r in out),'identities':out}))
'''
q=subprocess.run(['wsl','-d','Ubuntu-24.04','--','python3','-c',remote],input=json.dumps(payload),capture_output=True,text=True,encoding='utf-8',timeout=60)
write(STAGE/'sync-command.json',{'command':['wsl','-d','Ubuntu-24.04','--','python3','-c','<remote_source>'],
 'remote_source':remote,'exit_code':q.returncode,'stderr':q.stderr})
if q.returncode:raise SystemExit(q.stderr)
synced=json.loads(q.stdout);write(STAGE/'sync-result.json',synced)
print(json.dumps({'commands':len(commands),'source_files':len(manifest),'source_bytes':synced['bytes'],'before_files':len(before),'remote':REMOTE},indent=2))
