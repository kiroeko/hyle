"""Recover successful owner metadata, then refresh only root's corrected shader and embed."""
from pathlib import Path
import importlib.util

S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('outer_resume',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c;P=h.P
frozen=[row['source'] for row in c.read(S/'source-freeze-attempt1.json')['sources']]
frozen_by_key={c.key(row['path']):row for row in frozen}
records=[]
for tag in [*h.TAGS,'vulkan-shaders']:
    out=P/'windows/checks/attempt1'/tag
    plan=c.read(out/'compile-plan.json')
    assert c.read(out/'compile.result.json')['exit']==0
    if (out/'identity.json').exists():record=c.read(out/'identity.json')
    else:
        source=Path(plan['source']['path']);assert b.same(plan['source'])
        native=source.suffix=='.cu'
        if native:
            deps=out/(tag+'.d');paths=h.n.native_dependencies(deps)
        else:
            deps=out/(tag+'-deps.json');data=c.read(deps)['Data'];paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
        dependencies=[b.identity(path) for path in paths]
        for row in dependencies:
            if c.key(row['path']) in frozen_by_key:assert row==frozen_by_key[c.key(row['path'])]
        record=dict(command=plan['command'],source=plan['source'],old_object=plan['old_object'],
            object=b.identity(out/(tag+'.obj')),recipe=plan['recipe'],dependencies=dependencies,
            source_dependencies=b.identity(deps),native=native,
            recovery='Compile succeeded; receipt assertion had incorrectly gated unrelated shader source. Actual source/dependencies match their frozen snapshots.',
            SDK_builds=0,GPU_runs=0)
        c.save(out/'identity.json',record)
    assert all(b.same(row) for row in [record['source'],record['object'],*record['dependencies']])
    records.append(record)
c.save(S/'products-attempt1-first-shader.json',dict(records=records,CXX=10,NVCC=1,GLSL=1,
    metadata_assertion='Global source gate noticed concurrent independent shader edit; no compiler failure or numerical execution.',SDK_builds=0,GPU_runs=0))
current_frozen=h.freeze('attempt2')
assert b.identity(h.R/'src/compute_route_vulkan/shaders/static_fp8.comp')['sha256']=='e4267d670939193752f0815ad7e6cd16845db16234044e70cbf2fb8c9e2d7781'
generated=h.shader('attempt2')
old=h.PLAN['generated_owner'][0]
row=dict(source=b.identity(generated/'vulkan_shaders.cc'),old_object=old['old_object'],command=old['command'],recipe=old['recipe'])
latest=h.compile_job(row,'vulkan-shaders','attempt2',current_frozen,generated)
records[-1]=latest
c.save(S/'products-attempt1.json',dict(records=records,CXX=11,NVCC=1,GLSL=2,SDK_builds=0,GPU_runs=0,
    first_shader_products=b.identity(S/'products-attempt1-first-shader.json'),
    final_shader_proof=b.identity(generated/'artifact-proof.json')))
print(b.identity(S/'products-attempt1.json'))
