#include "../compute_models/fp8_outer_scale_fixture.h"
#include "../../src/graph/static_fp8_region.h"
#include "../../src/compute_packed_shared/static_fp8_linear.h"
#include "hyle/graph/cpu.h"
#include "hyle/compute/providers/native.h"

namespace {
template<class Run> void run_cpu(Run run,bool contracted,bool pattern_only=false) {
  namespace f=static_fp8_reference_test;
  auto context=f::take(f::g::cpu::create_context(),"CPU static FP8 context");
  auto queue=f::take(context.create_queue(),"CPU queue");
  const std::array queues{f::g::QueueBinding{f::g::ExecutionLaneId{0},&queue}};
  run(f::m::system_resource(),queues,
      [&](const f::g::Graph &graph,f::g::CompileOptions options) {
        std::vector<f::g::NodeProviderConstraint> required;
        if(contracted)for(std::size_t i=0;i<graph.node_count();++i)
          required.push_back({f::take(graph.node_id(i),"constrained original node"),f::c::native::kProviderId,{}});
        if(pattern_only) {
          using Rule=f::g::detail::StaticFloat8Pattern;
          std::size_t matches=0;
          for(std::size_t i=0;i<graph.node_count();++i) {
            Rule::Pattern pattern;
            if(!Rule::pattern(graph,f::take(graph.node_id(i),"static FP8 terminal"),pattern))continue;
            ++matches;
            for(const auto node:pattern.span())
              required.push_back({node,f::c::native::kProviderId,{}});
          }
          EXPECT_EQ(matches,std::size_t{1});
          EXPECT_EQ(required.size(),Rule::kMaxNodes);
        }
        options.node_providers=required;
        options.provider_replay=contracted?f::g::ProviderReplayPolicy::kRequirePrepared:f::g::ProviderReplayPolicy::kAllowAny;
        return f::g::cpu::compile(graph,context,options);
      },[](f::m::BufferView d,std::span<const std::byte> s) {return d.write(s);},
      [](f::m::ConstBufferView s,std::span<std::byte> d) {return s.read(d);},
      [](f::g::Invocation &i,std::span<const f::g::QueueBinding> q) {return i.prepare_replay(q);});
}
}
TEST(CpuFp8OuterScale, RowAndChannelScalesKeepWeightThenActivationOrder) {
  run_cpu([](auto r,auto q,auto compile,auto write,auto read,auto prepare) {
    fp8_outer_scale_test::run_lifetimes(r,q,compile,write,read,prepare);
  }, true);
}
TEST(CpuFp8OuterScale, DynamicRowPrologueKeepsActivationThenWeightOrder) {
  run_cpu([](auto r,auto q,auto compile,auto write,auto read,auto prepare) {
    fp8_outer_scale_test::run_prologue(r,q,compile,write,read,prepare);
  }, false, true);
}
TEST(CpuFp8OuterScale, PublishedCodesKeepTheOrdinaryOuterScaleGraph) {
  run_cpu([](auto r,auto q,auto compile,auto write,auto read,auto prepare) {
    fp8_outer_scale_test::run_escape(r,q,compile,write,read,prepare);
  }, false);
}
TEST(CpuFp8OuterScale, OriginalScalarLifetimeNeighbor) {
  run_cpu([](auto r,auto q,auto compile,auto write,auto read,auto prepare) {
    static_fp8_reference_test::run_lifetimes(r,q,compile,write,read,prepare);
  }, true);
}
TEST(CpuFp8OuterScale, OriginalScalarIeeeNeighbor) {
  run_cpu([](auto r,auto q,auto compile,auto write,auto read,auto prepare) {
    static_fp8_reference_test::run_runtime_domain(r,q,compile,write,read,prepare);
  }, true);
}
TEST(CpuFp8OuterScale, OriginalScalarPublishedCodesNeighbor) {
  run_cpu([](auto r,auto q,auto compile,auto write,auto read,auto prepare) {
    static_fp8_reference_test::run_escape(r,q,compile,write,read,prepare);
  }, false);
}
