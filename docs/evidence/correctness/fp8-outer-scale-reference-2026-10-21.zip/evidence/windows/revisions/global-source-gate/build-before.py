"""Build only actual outer-scale owners and three six-case focused wrappers; never run."""
from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import importlib.util
import re
import struct
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('outer_build_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
spec=importlib.util.spec_from_file_location('outer_native_helpers',A/'mlx-weight-orientation-2026-10-21/cpu-cuda/build.py')
n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
PLAN=c.read(S/'proposed-plan.json')
TAGS=['native-provider','native-static-fp8','cpu-packed-region','cuda-artifact-provider',
    'cuda-packed-region','cuda-mlx-packed-kernel','vulkan-static-fp8','vulkan-program',
    'vulkan-operations','vulkan-native-region']
FIXTURE_SHA='f8ef18558604c0e7af89fbe6a1c15c12b9f315f20c2fa19e7e1f80922eda7cd8'

def freeze(attempt):
    names=['src/compute_packed_shared/static_fp8_linear.h','src/graph/static_fp8_region.h',
        'src/compute_provider_torch_cuda/mlx_packed_kernel.h',
        'src/compute_route_vulkan/shaders/static_fp8.comp',
        'src/compute_route_vulkan/shaders/fp8_storage.glsl',
        'src/compute_shader_shared/nvfp4_f32.h','src/compute_shader_shared/ct_packed.h',
        'tests/compute_models/fp8_outer_scale_fixture.h','tests/compute_models/static_fp8_reference_fixture.h',
        *[str(Path(row['source']['path']).relative_to(R)) for row in PLAN['product_compiles']],
        *[f'tests/graph_route_{arm}/fp8_outer_scale_test.cc' for arm in ['cpu','cuda','vulkan']],
        *[f'tests/graph_route_{arm}/CMakeLists.txt' for arm in ['cpu','cuda','vulkan']]]
    rows=[]
    for name in names:
        source=R/name;dest=S/('source-'+attempt)/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:dest.write_bytes(source.read_bytes())
        rows.append(dict(source=b.identity(source),snapshot=b.identity(dest)))
    assert b.identity(R/'tests/compute_models/fp8_outer_scale_fixture.h')['sha256']==FIXTURE_SHA
    c.save(S/('source-freeze-'+attempt+'.json'),dict(sources=rows,source_count=len(rows),
        common_freeze=b.identity(P/'outer-scale/source-freeze.json'),agent_GPU_runs=0))
    return [row['source'] for row in rows]

def shader(attempt):
    out=P/'vulkan/shaders'/attempt;out.mkdir(parents=True,exist_ok=True)
    old=PLAN['generated_owner'][0]
    old_text=Path(old['source']).read_text(encoding='utf8')
    old_header=Path(old['source']).with_name('vulkan_shaders.h')
    helpers=[]
    for name in ['nvfp4_f32.h','ct_packed.h']:
        source=R/'src/compute_shader_shared'/name
        helpers.append(source.read_text(encoding='utf8').split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0])
    source=R/'src/compute_route_vulkan/shaders/static_fp8.comp'
    generated=out/'static_fp8.generated.comp'
    text=source.read_text(encoding='utf8');assert text.count('// HYLE_STATIC_FP8_F32_SOURCE')==1
    generated.write_text(text.replace('// HYLE_STATIC_FP8_F32_SOURCE','\n'.join(helpers)),encoding='utf8')
    command=['C:/public/tools/glslang/glslangValidator.exe','-V','--target-env','vulkan1.2',
        '--preamble-text','#extension GL_GOOGLE_include_directive : require\n',
        '-I'+str(R/'third_party/ggml_vulkan_shaders/shaders'),
        '-I'+str(R/'src/compute_route_vulkan/shaders'),'-S','comp',
        '-o',str(out/'static_fp8.spv'),str(generated)]
    (out/'tmp').mkdir(exist_ok=True)
    env,_=b.environment(PLAN['product_compiles'][6]['command'],[],out)
    c.execute('shader',command,env,out)
    raw=(out/'static_fp8.spv').read_bytes();assert len(raw)%4==0
    words=struct.unpack('<'+'I'*(len(raw)//4),raw);assert words[0]==0x07230203 and words[1]<=0x00010500
    at=5
    while at<len(words):
        size,opcode=words[at]>>16,words[at]&65535
        assert size and at+size<=len(words)
        if opcode==17:assert size==2 and words[at+1]==1
        at+=size
    pattern=r'namespace \{ constexpr std::uint32_t (\w+)_words\[\] = \{(.*?)\}; \}'
    arrays=re.findall(pattern,old_text,re.S);assert len(arrays)==27
    replacement='namespace { constexpr std::uint32_t static_fp8_words[] = {\n'
    for offset in range(0,len(words),8):replacement+='  '+', '.join(f'0x{x:08x}u' for x in words[offset:offset+8])+',\n'
    replacement+='}; }'
    updated,count=re.subn(r'namespace \{ constexpr std::uint32_t static_fp8_words\[\] = \{.*?\}; \}',lambda _:replacement,old_text,flags=re.S)
    assert count==1
    (out/'vulkan_shaders.cc').write_text(updated,encoding='utf8',newline='\n')
    (out/'vulkan_shaders.h').write_bytes(old_header.read_bytes())
    inventory=[]
    for name,body in arrays:
        before=b''.join(struct.pack('<I',int(x,16)) for x in re.findall(r'0x([0-9a-f]+)u',body))
        after_body=dict(re.findall(pattern,updated,re.S))[name]
        after=b''.join(struct.pack('<I',int(x,16)) for x in re.findall(r'0x([0-9a-f]+)u',after_body))
        if name!='static_fp8':assert before==after
        inventory.append(dict(name=name,bytes=len(after),sha256=hashlib.sha256(after).hexdigest(),
            reused_byte_exact=name!='static_fp8'))
    c.save(out/'artifact-proof.json',dict(old_embed=b.identity(Path(old['source'])),new_embed=b.identity(out/'vulkan_shaders.cc'),
        source=b.identity(source),generated=b.identity(generated),static_spv=b.identity(out/'static_fp8.spv'),
        artifacts=inventory,GLSL_compiles=1,old_variants_reused=26,SDK_builds=0,GPU_runs=0))
    return out

def compile_job(row,tag,attempt,frozen,extra_include=None):
    source=Path(row['source']['path'])
    out=P/'windows/checks'/attempt/tag;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists(),out
    native=source.suffix=='.cu'
    template=[arg for arg in row['command'] if arg not in ['/W3','/W0']]
    if not native:
        for flag in ['/W4','/WX']:
            if flag not in template:template.append(flag)
    command=(n.n.native_command if native else b.host_command)(template,source,tag,out)
    if extra_include:command.insert(1,'/I'+str(extra_include))
    source_id=b.identity(source)
    c.save(out/'compile-plan.json',dict(command=command,source=source_id,old_object=row['old_object'],
        recipe=row['recipe'],frozen_source_count=len(frozen),native=native,SDK_builds=0,GPU_runs=0))
    environment_command=command
    if native:environment_command=[str(Path(command[command.index('-ccbin')+1])/'cl.exe'),*command[1:]]
    env,_=b.environment(environment_command,[],out)
    c.execute('compile',command,env,out)
    if native:
        dep_path=out/(tag+'.d');paths=n.native_dependencies(dep_path)
    else:
        dep_path=out/(tag+'-deps.json');data=c.read(dep_path)['Data'];paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
    dependencies=[b.identity(path) for path in paths]
    assert all(b.same(x) for x in [source_id,*frozen,*dependencies])
    record=dict(command=command,source=source_id,old_object=row['old_object'],object=b.identity(out/(tag+'.obj')),
        recipe=row['recipe'],dependencies=dependencies,source_dependencies=b.identity(dep_path),native=native,
        SDK_builds=0,GPU_runs=0)
    c.save(out/'identity.json',record);print('COMPILED',tag,flush=True)
    return record

def test_row(arm):
    old=next(x for x in PLAN['old_test_owners'] if x['arm']==arm)['drop'];assert len(old)==1
    X=A/'glm-flash-mixed-mlx-2026-10-21'
    recipe=X/arm/'checks'/('attempt3' if arm=='cuda' else 'attempt2')/'identity.json'
    return dict(source=b.identity(R/f'tests/graph_route_{arm}/fp8_outer_scale_test.cc'),
        old_object=old[0]['object'],command=c.read(recipe)['command'],recipe=b.identity(recipe))

def link(arm,products,test,folder):
    base_path=Path(PLAN['bases'][arm]['path']);base=c.read(base_path)
    replacements={c.key(x['old_object']['path']):x['object'] for x in [*products,test]}
    assert all(b.same(row) for row in base['inputs'])
    inputs=[replacements.get(c.key(x['path']),x) for x in base['inputs']]
    assert all(b.same(row) for row in inputs)
    if arm=='cuda':assert PLAN['required_current_CUDA_weights'] in inputs
    command=[replacements[c.key(arg)]['path'] if c.key(arg) in replacements else arg for arg in base['command']
        if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out=P/arm/'checks'/folder;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists(),out
    image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
        '/IMPLIB:'+str(image.with_suffix('.lib'))]
    objects=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ['.obj','.lib']]
    assert list(map(c.key,objects))==[c.key(x['path']) for x in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),
        replacements=[dict(old_object=x['old_object'],object=x['object'],source=x['source']) for x in [*products,test]
            if any(c.key(row['path'])==c.key(x['old_object']['path']) for row in base['inputs'])],
        owner_audit=b.identity(S/'private-descriptor-owner-audit.json'),SDK_builds=0,GPU_runs=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    label={'cpu':'Cpu','cuda':'Cuda','vulkan':'Vulkan'}[arm]
    return dict(arm=arm,image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),
        runtime_environment=b.identity(out/'runtime-environment.json'),filter=label+'Fp8OuterScale.*',expected_tests=6)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt',default='attempt1');parser.add_argument('--link-dir',default='link1')
    parser.add_argument('--phase',choices=['all','products','tests','link'],default='all')
    parser.add_argument('--products-attempt',default='attempt1');parser.add_argument('--test-attempt')
    args=parser.parse_args();frozen=freeze(args.attempt)
    if args.phase in ['all','products']:
        generated=shader(args.attempt)
        rows=[(row,tag,None) for row,tag in zip(PLAN['product_compiles'],TAGS)]
        old=PLAN['generated_owner'][0]
        rows.append((dict(source=b.identity(generated/'vulkan_shaders.cc'),old_object=old['old_object'],
            command=old['command'],recipe=old['recipe']),'vulkan-shaders',generated))
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            products=list(pool.map(lambda job:compile_job(job[0],job[1],args.attempt,frozen,job[2]),rows))
        c.save(S/('products-'+args.attempt+'.json'),dict(records=products,CXX=10,NVCC=1,GLSL=1,SDK_builds=0,GPU_runs=0))
    else:products=c.read(S/('products-'+args.products_attempt+'.json'))['records']
    if args.phase in ['all','tests']:
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            records=dict(pool.map(lambda arm:(arm,compile_job(test_row(arm),arm+'-outer-scale-test',args.attempt,frozen)),['cpu','cuda','vulkan']))
        c.save(S/('tests-'+args.attempt+'.json'),dict(records=records,CXX=3,SDK_builds=0,GPU_runs=0))
    else:records=c.read(S/('tests-'+(args.test_attempt or args.attempt)+'.json'))['records'] if args.phase=='link' else {}
    if args.phase in ['all','link','tests']:
        ready=[link(arm,products,records[arm],args.link_dir) for arm in ['cpu','cuda','vulkan']]
        c.save(S/'ready-for-root-run.json',dict(status='strict_builds_and_focused_links_ready_not_executed',
            arms=ready,private_ABI='StaticFloat8Linear8B/rev2',SDK_builds=0,agent_GPU_runs=0))
        print(b.identity(S/'ready-for-root-run.json'))

if __name__=='__main__':main()
