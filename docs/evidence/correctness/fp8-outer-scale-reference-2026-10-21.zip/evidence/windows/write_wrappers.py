"""Create the three owned thin wrappers once; compilation never writes source."""
from pathlib import Path

P=Path(__file__).resolve().parent
R=P.parents[3]
for arm,label in [('cpu','Cpu'),('cuda','Cuda'),('vulkan','Vulkan')]:
    old=(R/f'tests/graph_route_{arm}/static_fp8_reference_test.cc').read_text(encoding='utf8')
    marker={'cpu':'TEST(CpuStaticFloat8ReferenceGraph,','cuda':'TEST(CudaStaticFp8ReferenceGraph,',
        'vulkan':'TEST(VulkanStaticFp8ReferenceGraph,'}[arm]
    prefix=old.split(marker,1)[0]
    prefix=prefix.replace('#include "../compute_models/static_fp8_reference_fixture.h"',
        '#include "../compute_models/fp8_outer_scale_fixture.h"')
    if arm=='cpu':prefix=prefix.replace('#include "../compute/native_context_fixture.h"\n','')
    if arm=='vulkan':
        prefix=prefix.replace('constexpr std::size_t capacity = 64U * 1024U;',
            'constexpr std::size_t capacity = 4U * 1024U * 1024U;')
        first=prefix.index('    HYLE_ASSIGN_OR_RETURN(auto done, transfer.download(native));')
        last=prefix.index('    return target_bytes.read(bytes);',first)+len('    return target_bytes.read(bytes);')
        prefix=prefix[:first]+'    return context.download(native, bytes);'+prefix[last:]
    calls=[('RowAndChannelScalesKeepWeightThenActivationOrder','fp8_outer_scale_test','run_lifetimes',True),
        ('DynamicRowPrologueKeepsActivationThenWeightOrder','fp8_outer_scale_test','run_prologue',True),
        ('PublishedCodesKeepTheOrdinaryOuterScaleGraph','fp8_outer_scale_test','run_escape',False),
        ('OriginalScalarLifetimeNeighbor','static_fp8_reference_test','run_lifetimes',True),
        ('OriginalScalarIeeeNeighbor','static_fp8_reference_test','run_runtime_domain',True),
        ('OriginalScalarPublishedCodesNeighbor','static_fp8_reference_test','run_escape',False)]
    text=prefix
    for name,namespace,function,packed in calls:
        parameters='auto r,auto q,auto compile,auto write,auto read,auto prepare'
        if arm=='cuda':parameters+=',auto owner'
        arguments='r,q,compile,write,read,prepare'+(',owner' if arm=='cuda' and function=='run_lifetimes' else '')
        # The new outer helpers accept an owner on every run; old scalar only
        # needs its owner for the constant lifetime journey.
        if arm=='cuda' and namespace=='fp8_outer_scale_test' and function!='run_lifetimes':arguments+=',owner'
        text+=f'TEST({label}Fp8OuterScale, {name}) {{\n'
        text+=f'  run_{arm}([]({parameters}) {{\n    {namespace}::{function}({arguments});\n'
        text+='  }, '+str(packed).lower()+');\n}\n'
    target=R/f'tests/graph_route_{arm}/fp8_outer_scale_test.cc'
    if target.exists():assert target.read_text(encoding='utf8')==text
    else:target.write_text(text,encoding='utf8',newline='\r\n')
    cmake=R/f'tests/graph_route_{arm}/CMakeLists.txt'
    before=P/'before'/f'tests/graph_route_{arm}/CMakeLists.txt'
    before.parent.mkdir(parents=True,exist_ok=True)
    if not before.exists():before.write_bytes(cmake.read_bytes())
    extra=f'\nif(_HYLE_COMPUTE_HAVE_{arm.upper()})\n'
    extra+=f'  hyle_add_test(graph_route_{arm} NAME fp8_outer_scale\n'
    deps='hyle_simd'+(' hyle_compute_backend_cuda' if arm=='cuda' else '')
    extra+=f'    SOURCES fp8_outer_scale_test.cc DEPS {deps})\n'
    extra+=f'  hyle_stage_runtime(hyle_graph_route_{arm}_fp8_outer_scale_test)\nendif()\n'
    if 'NAME fp8_outer_scale' not in cmake.read_text(encoding='utf8'):
        with cmake.open('a',encoding='utf8',newline='\r\n') as stream:stream.write(extra)
    print(target)
