"""Inspect current X link inputs and original compile receipts; no compilation or execution."""
from pathlib import Path
import importlib.util
import subprocess
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;A=P.parent;R=A.parents[1]
X=A/'glm-flash-mixed-mlx-2026-10-21'
spec=importlib.util.spec_from_file_location('outer_scale_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASES={arm:X/arm/'checks'/('link2' if arm=='cuda' else 'link1')/'link-plan.json'
    for arm in ['cpu','cuda','vulkan']}
TARGETS=[
 'src/compute_provider_native/native_provider.cc',
 'src/compute_provider_native/static_fp8.cc',
 'src/graph_route_cpu/ct_packed_linear_region.cc',
 'src/compute_provider_torch_cuda/artifact_provider.cc',
 'src/graph_route_cuda/ct_packed_linear_region.cc',
 'src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
 'src/compute_route_vulkan/vulkan_static_fp8.cc',
 'src/compute_route_vulkan/vulkan_program.cc',
 'src/compute_route_vulkan/vulkan_operations.cc',
 'src/graph_route_vulkan/native_region.cc',
]
plans={arm:c.read(path) for arm,path in BASES.items()}
assert all(b.same(row) for plan in plans.values() for row in plan['inputs'])
meta=h.metadata(plans)
unique={}
for arm,plan in plans.items():
    for row in plan['inputs']:
        if Path(row['path']).suffix.lower()!='.obj':continue
        key=c.key(row['path'])
        item=unique.setdefault(key,dict(old_object=row,arms=[]))
        item['arms'].append(arm)
        record=meta.get(key)
        if record:item['receipt']=record
compiles=[];unresolved=[]
for name in TARGETS:
    matches=[row for row in unique.values() if c.key(row.get('receipt',{}).get('source_path',''))==c.key(R/name)]
    if not matches:unresolved.append(name)
    for item in matches:
        receipt=item['receipt']
        compiles.append(dict(source=b.identity(R/name),old_object=item['old_object'],arms=item['arms'],
            recipe=b.identity(receipt['recipe']),command=receipt['command'],
            reason='Actual linked constructor/extractor or matcher of private StaticFloat8Linear rev2/8B, or changed CUDA kernel.'))
generated=[dict(old_object=row['old_object'],arms=row['arms'],
    recipe=b.identity(row['receipt']['recipe']),command=row['receipt']['command'],
    source=row['receipt']['source_path']) for row in unique.values()
    if row.get('receipt') and Path(row['receipt']['source_path']).name=='vulkan_shaders.cc']
assert len(generated)==1,generated
old_tests=[]
for arm,plan in plans.items():
    rows=[row for row in unique.values() if arm in row['arms'] and row.get('receipt')
        and c.key(row['receipt']['source_path']).startswith(c.key(R/'tests')+'\\')]
    old_tests.append(dict(arm=arm,drop=[dict(source=row['receipt']['source_path'],object=row['old_object']) for row in rows]))
current_weights=b.identity(X/'cuda/checks/bank-alignment-product1/cuda-weights.obj')
assert any(c.key(row['path'])==c.key(current_weights['path']) for row in plans['cuda']['inputs'])
private_headers={c.key(R/'src/compute_packed_shared/static_fp8_linear.h'),c.key(R/'src/graph/static_fp8_region.h')}
included=[]
for item in unique.values():
    receipt=item.get('receipt')
    if not receipt:continue
    deps=receipt.get('dependencies') or []
    direct=[row for row in deps if isinstance(row,dict) and c.key(row.get('path','')) in private_headers]
    if not direct:continue
    included.append(dict(source=receipt['source_path'],object=item['old_object'],arms=item['arms'],headers=direct))
assert all(any(c.key(row['object']['path'])==c.key(x['old_object']['path']) for x in compiles)
    for row in included),included
dumpbin=Path(next(x['command'][0] for x in compiles if Path(x['command'][0]).name.lower()=='cl.exe')).with_name('dumpbin.exe')
symbols=[]
for row in included:
    command=[str(dumpbin),'/nologo','/symbols',row['object']['path']]
    output=subprocess.run(command,cwd=R,capture_output=True,text=True,encoding='utf8',errors='replace',check=True)
    matched=[line for line in output.stdout.splitlines() if 'StaticFloat8' in line]
    defined=[line for line in matched if 'UNDEF' not in line and 'SECT' in line]
    symbols.append(dict(source=row['source'],object=row['object'],command=command,exit=output.returncode,
        defined_matches=defined,undefined_matches=[line for line in matched if 'UNDEF' in line]))
c.save(S/'private-descriptor-owner-audit.json',dict(status='actual_receipt_header_owners_all_scheduled_for_refresh',
    old_descriptor='StaticFloat8Linear4B/revision1',new_descriptor='8B/revision2',
    actual_header_include_owners=included,symbols=symbols,
    focused_test_policy='Drop prior X test-only TU; add new wrapper with scalar neighbors and current private header in one build.',
    no_public_operation_ABI_change=True,GPU_runs=0))
plan=dict(status='actual_current_owner_plan_waiting_shared_fixture_freeze',
    bases={arm:b.identity(path) for arm,path in BASES.items()},base_input_counts={arm:len(plan['inputs']) for arm,plan in plans.items()},
    product_compiles=compiles,generated_owner=generated,unresolved_sources=unresolved,
    old_test_owners=old_tests,required_current_CUDA_weights=current_weights,
    shader_scope='Compile only static_fp8.comp; all other SPIRVs retain byte identity. Re-embed the actual generated owner once.',
    no_SDK_rebuild=True,only_NVCC_owner='src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
    private_owner_audit=b.identity(S/'private-descriptor-owner-audit.json'),GPU_runs=0,compile_jobs_started=0)
c.save(S/'proposed-plan.json',plan)
print(b.identity(S/'proposed-plan.json'))
for row in compiles:print(row['source']['path'],row['arms'],row['old_object']['path'])
print('generated',generated[0]['old_object']['path'])
print('unresolved',unresolved)
