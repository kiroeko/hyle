"""Bundle finite reference evidence; compiled images and caches remain outside."""
from pathlib import Path
import hashlib,json,zipfile

P=Path(__file__).resolve().parent.parent
R=P.parents[2]
E=R/'docs/evidence/correctness'
def sha(data):return hashlib.sha256(data).hexdigest()
def ident(path):
    data=path.read_bytes()
    return dict(path=str(path.relative_to(R)),bytes=len(data),sha256=sha(data))
report=json.loads((P/'root/final-results.json').read_text('utf-8'))
assert report['passed'] is True
for arm in ('cpu','cuda','vulkan','apple'):
    assert report['backends'][arm]['passed'] is True
source=json.loads((P/'root/source-freeze.json').read_text('utf-8'))
for row in source['sources']:
    actual=ident(R/row['path'])
    assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']
excluded={'.obj','.exe','.map','.lib','.dll','.pdb','.pyc','.spv','.tgz','.gz','.zip','.ilk','.exp'}
files={}
for path in sorted(P.rglob('*')):
    if not path.is_file() or path.suffix.lower() in excluded:continue
    if any(part in ('__pycache__','tmp') for part in path.relative_to(P).parts):continue
    data=path.read_bytes()
    # Payloads, if introduced later, require a deliberate finite artifact
    # choice. Do not silently archive a toolchain or generated model bank.
    assert len(data)<8*1024*1024,path
    files['evidence/'+str(path.relative_to(P)).replace('\\','/')]=data
for row in source['sources']:
    path=R/row['path']
    files['source/'+str(path.relative_to(R)).replace('\\','/')]=path.read_bytes()
manifest=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(files.items())]
files['manifest.json']=(json.dumps(dict(files=manifest),indent=2)+'\n').encode()
E.mkdir(parents=True,exist_ok=True)
archive=E/'fp8-outer-scale-reference-2026-10-21.zip'
assert not archive.exists(),'Do not overwrite a published evidence artifact'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(files)
    for row in manifest:assert sha(z.read(row['path']))==row['sha256']
summary={**report,'archive':ident(archive),'manifest_members':len(manifest),
    'source_freeze':ident(P/'root/source-freeze.json'),
    'scope':'Portable stored-scale FP8 outer-axis software references and the explicitly recorded finite role; not full artifact/model, Linux, AMD hardware equivalence, quality or throughput.'}
target=E/'fp8-outer-scale-reference-2026-10-21.json'
assert not target.exists()
target.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(summary=ident(target),archive=ident(archive),members=len(files))))
