"""Freeze this change, with archived before-sources; no build or runtime work."""
from pathlib import Path
import argparse, difflib, hashlib, json, zipfile

P=Path(__file__).resolve().parent.parent
R=P.parents[2]
def identity(path):
    data=path.read_bytes()
    return dict(path=str(path.relative_to(R)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
sources=[
    'src/compute_packed_shared/static_fp8_linear.h',
    'src/graph/static_fp8_region.h',
    'src/compute_provider_native/static_fp8.cc',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.h',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
    'src/compute_provider_torch_cuda/artifact_provider.cc',
    'src/compute_route_vulkan/vulkan_static_fp8.cc',
    'src/compute_route_vulkan/shaders/static_fp8.comp',
    'src/compute_route_apple/apple_static_fp8.cc',
    'tests/compute_models/static_fp8_reference_fixture.h',
    'tests/compute_models/fp8_outer_scale_fixture.h',
]
sources += [f'tests/graph_route_{arm}/{name}'
    for arm in ('cpu','cuda','vulkan','apple')
    for name in ('fp8_outer_scale_test.cc','CMakeLists.txt')
    if (R/f'tests/graph_route_{arm}/{name}').is_file()]
parser=argparse.ArgumentParser()
parser.add_argument('--fixture-sha')
args=parser.parse_args()
frozen=json.loads((P/'outer-scale/source-freeze.json').read_text('utf-8'))
for item in frozen['sources']:
    actual=identity(R/item['path'])
    if args.fixture_sha and item['path']=='tests/compute_models/fp8_outer_scale_fixture.h':
        assert actual['sha256']==args.fixture_sha
        continue
    assert actual['bytes']==item['bytes'] and actual['sha256']==item['sha256'],item
archives={
    'cuda':R/'docs/evidence/correctness/glm-flash-mixed-mlx-reference-2026-10-21.zip',
    'static':R/'docs/evidence/correctness/static-fp8-reference-2026-10-20.zip',
}
before={}
for rel in sources:
    current=(R/rel).read_bytes()
    target=P/'source'/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and target.read_bytes()!=current:
        previous=target.read_bytes()
        revision=P/'root/revisions'/hashlib.sha256(previous).hexdigest()[:12]/rel
        revision.parent.mkdir(parents=True,exist_ok=True)
        revision.write_bytes(previous)
    target.write_bytes(current)
    if rel=='tests/compute_models/fp8_outer_scale_fixture.h' or '/graph_route_' in rel:continue
    key='cuda' if '/compute_provider_torch_cuda/' in rel else 'static'
    with zipfile.ZipFile(archives[key]) as z:
        names=[n for n in z.namelist() if n=='source/'+rel]
        assert len(names)==1,(rel,names)
        original=z.read(names[0])
    baseline=P/'root/before'/rel
    baseline.parent.mkdir(parents=True,exist_ok=True)
    baseline.write_bytes(original)
    before[rel]=dict(archive=identity(archives[key]),member=names[0],bytes=len(original),sha256=hashlib.sha256(original).hexdigest())
    old_lines=original.decode('utf-8-sig').replace('\r\n','\n').splitlines(True)
    new_lines=current.decode('utf-8-sig').replace('\r\n','\n').splitlines(True)
    diff=''.join(difflib.unified_diff(old_lines,new_lines,fromfile='before/'+rel,tofile=rel))
    (P/'root'/('diff-'+Path(rel).name+'.patch')).write_text(diff,encoding='utf-8',newline='\n')
report=dict(status='actual_product_and_shared_test_sources_frozen',
    sources=[identity(R/rel) for rel in sources],before=before,
    note='The archived CUDA before source is the immediate X baseline. Static-family before sources are its prior signed scalar implementation; unrelated later work is not reset.')
target=P/'root/source-freeze.json'
if target.exists():
    previous=target.read_bytes()
    revision=P/'root/revisions'/('source-freeze-'+hashlib.sha256(previous).hexdigest()[:12]+'.json')
    revision.parent.mkdir(parents=True,exist_ok=True)
    revision.write_bytes(previous)
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(identity(target))
