from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET

P=Path(__file__).resolve().parent.parent
R=P.parents[2]
def ident(path):
    raw=path.read_bytes()
    return dict(path=str(path.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
backends={}
for arm in ('cpu','cuda','vulkan','apple'):
    if arm=='apple':
        receipt=P/'apple/final-validation.json'
        xml=P/'apple/mac/current7/results/current7-tests.xml'
    else:
        receipt=P/arm/'validation/final-current/receipt.json'
        xml=P/arm/'validation/final-current/tests.xml'
    cases=ET.parse(xml).findall('.//testcase')
    assert len(cases)==7 and not any(x.find('failure') is not None or x.find('skipped') is not None for x in cases)
    records=[]
    for case in cases:
        properties={x.get('name'):x.get('value') for x in case.findall('./properties/property')}
        submits=int(properties.get('successful_submissions',properties.get('actual_submissions','0')))
        assert submits in (2,4,7,8,16,22)
        records.append(dict(name=case.get('classname')+'.'+case.get('name'),successful_submissions=submits))
    assert sum(x['successful_submissions'] for x in records)==63
    backends[arm]=dict(passed=True,cases=7,new_cases=4,scalar_neighbors=3,
        successful_submissions=63,skipped=0,receipt=ident(receipt),xml=ident(xml),tests=records)
result=dict(passed=True,scope='Finite portable stored-scale FP8 reference through the original four backend execution systems',
    cases=28,new_cases=16,scalar_neighbors=12,successful_submissions=252,skipped=0,backends=backends,
    semantics=dict(SA='F32 scalar or explicit [M,1]',SW='F32 scalar, [N] or [1,N]',
        order='Both explicit code-dot->SA->SW and code-dot->SW->SA; two F32 RNE boundaries retained',
        weights='Original E4 bytes; no N*K floating weight expansion on the qualified candidate',
        native_activation_workspace='CPU/CUDA M*K encoded bytes and bounded64-element CPU weight tile; Vulkan/Metal quantize inside the bounded code-dot kernel',
        role='Catalog23 fixed header f_a_proj: M1/M2,N128,K7168; finite artificial E4/F32 bytes; no-floor F32 maximum times F32 reciprocal448, strict F32 reciprocal, SW then SA, BF16 output'),
    selection=dict(proof='Executions explicitly select the available native candidate using existing test constraints/adapters; no production preference changes',
        default_compile='CPU9/CUDA14 steps for both M1/M2; no static-FP8 policy selected; one3,670,016-byte F32 weight workspace view plus its transpose alias',
        caveat='Compile-only observations do not measure allocation frequency, traffic or throughput. Default selection and its memory/time tradeoff remain delivery3 work.'),
    fixes=['Private8B descriptor revision2 and common closed12-node pattern; cold outer axes and original scale order',
        'Vulkan half/BF16 writer now ignores fully padded two-dimensional grid pairs; source-level defect found independently, not reproduced as a local out-of-bounds run'],
    retained_failures=['CPU/CUDA initial test wrapper constrained the entire new prologue to a limited provider; compilation of the graph correctly rejected unsupported unary',
        'Unconstrained default executed correct values but did not select the candidate, so strict selection tests failed; final tests constrain only the12-node candidate',
        'Two Windows diagnostic-wrapper C2039 compilation failures fixed to the actual Result error API',
        'Shader-independent build metadata assertion after a concurrent shader source update; all actual compiler exits were0, exact shader and embedding refreshed'],
    new_decode_measurement=False,
    remaining=['GLM catalog30 block128 reciprocal-multiply scale policy and related backend wiring',
        'Three delivery packages, final end-to-end comparison, then MTP and mmproj'],
    not_verified=['Original numerical checkpoint payload or complete model/artifact','Linux','AMD rcpf/FTZ and every native GEMM bit equivalence','Default automatic contraction benefit','Quality or throughput'])
target=P/'root/final-results.json'
target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(ident(target))
