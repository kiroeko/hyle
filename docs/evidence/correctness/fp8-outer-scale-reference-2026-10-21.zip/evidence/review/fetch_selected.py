"""Bounded fixed-revision primary-source retrieval; no dependency/model downloads."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import sys
import urllib.request
import urllib.error

P=Path(__file__).resolve().parent
SOURCES=[
 ('vllm-276fbcff','https://raw.githubusercontent.com/vllm-project/vllm/276fbcff2717bd934cfa37c8a2e4c391f3e7237b/',
  ['vllm/model_executor/layers/quantization/quark/quark.py',
   'vllm/model_executor/layers/quantization/quark/schemes/quark_w8a8_fp8.py',
   'vllm/model_executor/kernels/linear/__init__.py',
   'vllm/model_executor/kernels/linear/scaled_mm/ScaledMMLinearKernel.py',
   'vllm/model_executor/kernels/linear/scaled_mm/rocm.py',
   'vllm/model_executor/kernels/linear/scaled_mm/aiter.py',
   'vllm/model_executor/layers/quantization/input_quant_fp8.py',
   'vllm/_aiter_ops.py',
   'requirements/rocm.txt','vllm/models/kimi_k3/amd/kda.py']),
 ('sglang-654df43','https://raw.githubusercontent.com/sgl-project/sglang/654df43cbee108a81fa1736c34ba8c701f199285/',
  ['python/sglang/srt/layers/quantization/quark/quark.py',
   'python/sglang/srt/layers/quantization/fp8.py',
   'python/sglang/srt/layers/quantization/fp8_utils.py',
   'python/sglang/kernels/ops/quantization/fp8_kernel.py',
   'python/sglang/srt/models/glm5_next.py',
   'docker/Dockerfile.rocm']),
 ('aiter-d9e5ef7','https://raw.githubusercontent.com/ROCm/aiter/d9e5ef7ce08ee7045d583aed768cff41aa9210fe/',
  ['aiter/ops/quant.py','csrc/kernels/quant.cu','csrc/include/quant.h','csrc/kernels/quant_kernels.cu',
   'aiter/ops/triton/gemm_a8w8_blockscale.py','csrc/include/aiter_opus_plus.h',
   'aiter/ops/triton/__init__.py','aiter/ops/triton/gemm/basic/gemm_a8w8_blockscale.py',
   'aiter/ops/triton/_triton_kernels/gemm/basic/gemm_a8w8_blockscale.py']),
 ('aiter-7a3da22','https://raw.githubusercontent.com/ROCm/aiter/7a3da22d5d35f29149e8d319b513c8b4da851585/',
  ['aiter/ops/quant.py','csrc/kernels/quant_kernels.cu','aiter/ops/gemm_op_a8w8.py',
   'csrc/ck_gemm_a8w8_bpreshuffle/gemm_a8w8_bpreshuffle.cu',
   'csrc/ck_gemm_a8w8_bpreshuffle/include/gemm_a8w8_bpreshuffle_common.cuh']),
]

def fetch(row):
    group,base,name=row
    path=P/'selected-sources'/group/name
    receipt=path.with_name(path.name+'.http.json')
    if path.exists():
        old=json.loads(receipt.read_text(encoding='utf8'))
        assert hashlib.sha256(path.read_bytes()).hexdigest()==old['sha256']
        return old
    request=urllib.request.Request(base+name,headers={'User-Agent':'hyle-bounded-source-review/1','Accept-Encoding':'identity'})
    try:
        with urllib.request.urlopen(request,timeout=45) as response:
            body=response.read(500001)
            assert len(body)<=500000
            meta=dict(url=base+name,status=response.status,headers=dict(response.headers),
                bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),maximum_bytes=500000)
    except urllib.error.HTTPError as error:
        meta=dict(url=base+name,status=error.code,maximum_bytes=500000)
        path.parent.mkdir(parents=True,exist_ok=True)
        receipt.write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8')
        return meta
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(body)
    receipt.write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8')
    return meta

if __name__=='__main__':
    jobs=[(group,base,name) for group,base,names in SOURCES for name in names]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(fetch,jobs))
    print(json.dumps([{k:row[k] for k in ['url','status','bytes'] if k in row} for row in rows],indent=2))
