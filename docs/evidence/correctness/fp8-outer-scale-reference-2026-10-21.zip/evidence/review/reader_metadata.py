"""Inspect small official git/OCI metadata only. Never retrieve image layers."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request

P=Path(__file__).resolve().parent/'reader-metadata'
P.mkdir(exist_ok=True)

def get(url,name,headers=None,limit=300000):
    path=P/name
    if path.exists():return json.loads(path.read_text(encoding='utf8'))
    request=urllib.request.Request(url,headers={'User-Agent':'hyle-bounded-source-review/1',
        'Accept-Encoding':'identity',**(headers or {})})
    with urllib.request.urlopen(request,timeout=30) as response:
        body=response.read(limit+1);assert len(body)<=limit
        meta=dict(url=url,status=response.status,headers={k:v for k,v in response.headers.items()},
            bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),maximum_bytes=limit)
    path.write_bytes(body)
    path.with_suffix(path.suffix+'.http.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8')
    return json.loads(body)

def image(repository,reference,prefix):
    token_url='https://auth.docker.io/token?service=registry.docker.io&scope=repository:'+repository+':pull'
    # Public pull token is transient and deliberately not written to receipts.
    with urllib.request.urlopen(token_url,timeout=30) as response:
        body=response.read(20000);token=json.loads(body)['token']
    headers={'Authorization':'Bearer '+token,
        'Accept':'application/vnd.oci.image.index.v1+json,application/vnd.docker.distribution.manifest.list.v2+json,application/vnd.oci.image.manifest.v1+json,application/vnd.docker.distribution.manifest.v2+json'}
    base='https://registry-1.docker.io/v2/'+repository
    manifest=get(base+'/manifests/'+reference,prefix+'-manifest.json',headers)
    if 'manifests' in manifest:
        amd64=next(row for row in manifest['manifests'] if row.get('platform',{}).get('architecture')=='amd64')
        manifest=get(base+'/manifests/'+amd64['digest'],prefix+'-amd64-manifest.json',headers)
    config=get(base+'/blobs/'+manifest['config']['digest'],prefix+'-config.json',headers)
    return dict(image=repository+'@'+reference,created=config.get('created'),labels=config.get('config',{}).get('Labels'),
        env=config.get('config',{}).get('Env'),relevant_history=[row.get('created_by') for row in config.get('history',[])
            if any(x in row.get('created_by','').lower() for x in ['aiter','vllm','sglang','commit'])])

def main():
    jobs={
        'vllm_recommended_image':lambda:image('vllm/vllm-openai-rocm','kimi-k3','vllm-kimi-k3'),
        'sglang_recommended_image':lambda:image('lmsysorg/sglang','sha256:6d68cd19206716cb3f1e31e2ad89cd0852d7ae614a792773c30a4277f8955c72','sglang-fixed'),
        'vllm_031':lambda:get('https://api.github.com/repos/vllm-project/vllm/git/ref/tags/v0.31.0','vllm-v0.31.0-ref.json'),
        'sglang_docker':lambda:get('https://api.github.com/repos/sgl-project/sglang/contents/docker?ref=654df43cbee108a81fa1736c34ba8c701f199285','sglang-docker-directory.json'),
    }
    rows={}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        pending={key:pool.submit(job) for key,job in jobs.items()}
        for key,job in pending.items():
            try:rows[key]=job.result()
            except Exception as error:rows[key]=dict(error=str(error),no_image_layer_download=True)
    (P/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
    for key,row in rows.items():
        if key=='sglang_docker' and isinstance(row,list):row=[x['name'] for x in row]
        print(key,json.dumps(row))

if __name__=='__main__':main()
