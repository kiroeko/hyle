import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[4]
stage = Path(__file__).resolve().parent
names = [
    'src/compute_packed_shared/static_fp8_linear.h',
    'src/graph/static_fp8_region.h',
    'src/compute_provider_torch_cuda/artifact_provider.cc',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.h',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
    'src/compute_route_vulkan/vulkan_static_fp8.cc',
    'src/compute_route_vulkan/shaders/static_fp8.comp',
    'src/compute_route_vulkan/vulkan_operations.cc',
    'src/compute_route_vulkan/vulkan_program.cc',
    'src/graph_route_vulkan/native_region.cc',
    'src/graph_route_cuda/ct_packed_linear_region.cc',
]
inventory = []
for name in names:
    data = (root / name).read_bytes()
    inventory.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
shader = (root / names[6]).read_text(encoding='utf-8')
assert '} else if (local == 0u && valid) {' in shader
old_path = root / '.scratch/architecture-refactor-2026-10-18/quark-fp8-side-2026-10-21/windows/source-attempt1/src/compute_route_vulkan/shaders/static_fp8.comp'
old = old_path.read_bytes()
assert '} else if (local == 0u) {' in old.decode('utf-8')
report = {
    'status': 'bounded independent source review; one pre-existing tail finding fixed in current source; no remaining source blocker found',
    'verification': {'GPU': 'not run by reviewer', 'build': 'not run by reviewer',
                     'new_guard_runtime': 'not claimed; root will rebuild generated shader owner and run current odd-N/tail regressions'},
    'current_sources': inventory,
    'CUDA': {
        'ABI': 'artifact_provider.cc and mlx_packed_kernel.cu include the same native StaticFloat8 declaration. Added fields are uint32 activation/weight element strides and order; no duplicate device-side definition. Both actual owners require the already planned refresh.',
        'private_descriptor': 'Common descriptor is 8B with ID suffix2 and policy revision2. CUDA select/propose/prepare all use custom_as<StaticFloat8Linear>; its current inference proves explicit axes and rejects unknown order before Program creation.',
        'indices': 'Cold shape proof permits scalar or SA[M,1], SW scalar/[N]/[1,N]. Native static_program uses zero-or-one element strides; quantizer reads SA[i/K], dot reads SA[row*stride] and SW[column*stride]. For M1/N1 outer shape collapses safely to scalar-equivalent address0.',
        'tail': 'Quantizer grid-stride loop checks i<M*K. Each complete warp processes one output; all lanes in an active warp execute the same dot/reduction loop, lane0 stores only i<M*N. No block barrier or partial-warp divergence was introduced.',
        'rounding': 'Two nested explicit __fmul_rn calls preserve selected scale order; actual NVCC command contains no use_fast_math or ftz=true switch. Existing code-domain FMA/reduction is unchanged. This is not proof of arbitrary hardware reduction bit identity.',
        'resources': 'Original caller M*K U8 workspace and two launches remain; output/input/workspace overlap checks and prepared function materialization remain. No N*K floating bank, ATen submit tensor or host wait was introduced.'
    },
    'Vulkan': {
        'private_extractors': 'native_region constructs Pattern descriptor; vulkan_program admits E4 weight only for current StaticFloat8Linear; vulkan_operations dispatches it; vulkan_static_fp8 validates current descriptor before pipeline specialization. These actual consumers must all be refreshed, as assigned to Windows owner.',
        'indices': 'Specialization IDs5/6 carry zero-or-one element strides after common axes inference; shader derives row/column separately for each of two logical 32-lane outputs. Invalid tail output uses safe row0/column0 scale addresses.',
        'barriers': 'All64 threads initialize the two subgroup scale slots, reach every workgroup barrier and reduction barrier; no early return bypasses them. Shared partial[local+width] stays inside the same32-lane logical subgroup.',
        'rounding': 'Software hyle_f32_mul is called twice in the selected SA/SW order; hyle_f32_div forms each subgroup reciprocal. Partial reduction is unchanged. BF16/F16 outputs pack the two neighboring logical outputs into one owned word, with the last high half omitted.',
        'resources': 'Pipeline has five original storage bindings and16B byte origins. No float weight bank or activation workspace allocation was added; shared scale storage grows from3uints to6uints.',
    },
    'finding': {
        'id': 'VULKAN_RECTANGULAR_PADDED_PAIR_WRITE',
        'origin': 'Present in the previous scalar shader too; discovered while checking the newly changed tail path, not introduced by outer scales.',
        'before': {'path': old_path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(old).hexdigest()},
        'condition': 'pairs=ceil(M*N/2); x=min(pairs,maxCountX); y=ceil(pairs/x). If x*y>pairs, wholly padded groups previously entered the F16/BF16 writer and stored y[pair] past logical output.',
        'symbolic_example': {'conditional_maxCountX': 65535, 'M': 1024, 'N': 129,
                             'pairs': 66048, 'grid': [65535, 2], 'first_invalid_pair': 66048,
                             'BF16_output_bytes': 264192,
                             'note': 'Conditional admitted geometry, not an assertion that the local device has this maxCountX.'},
        'minimum_fix': 'Only final packed writer changed to local==0u && valid. No barrier, reduction, valid-output arithmetic or shape admission changed.',
        'fixed_current_sha256': next(x['sha256'] for x in inventory if x['path'] == names[6]),
        'status': 'Current source guard verified; not yet called a GPU regression result.',
        'local_device_reproduction': 'Windows owner has no immediately available verified cached maxCountX/maxCountY receipt. No new device query or artificial cap reduction was requested. If maxCountX exceeds every pair count admitted by output storage bounds, no natural local 2D reproduction exists; the current3x5 odd-N test exercises only one-dimensional dispatch.'
    },
    'scope_limits': ['No complete artifact/deployment/model claim.',
                     'No proof of AMD approximate reciprocal or arbitrary FP8 hardware accumulation.',
                     'Source review does not replace current shader rebuild and GPU results.'],
}
path = stage / 'outer-scale-root-gpu-review.json'
path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'path': path.relative_to(root).as_posix(), 'bytes': path.stat().st_size,
                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}, indent=2))
