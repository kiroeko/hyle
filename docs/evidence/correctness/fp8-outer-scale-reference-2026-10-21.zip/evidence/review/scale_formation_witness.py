"""Independent host witness; no product imports, GPU, or deployment claim."""
from pathlib import Path
import bisect, json, struct

def f32(x): return struct.unpack('<f', struct.pack('<f', x))[0]
def bits(x): return struct.unpack('<I', struct.pack('<f', x))[0]
def value(x): return struct.unpack('<f', struct.pack('<I', x))[0]
def bf16(x):
    b=bits(x)
    return value(((b+0x7fff+((b>>16)&1))>>16)<<16)
def e4(c):
    exponent=(c>>3)&15; mantissa=c&7
    return mantissa/512 if not exponent else (1+mantissa/8)*2**(exponent-7)
levels=[e4(c) for c in range(127)]
def code(x):
    if x>=448: return 126
    i=bisect.bisect_left(levels,x)
    if i==0: return 0
    lo=x-levels[i-1]; hi=levels[i]-x
    return i-1 if lo<hi or (lo==hi and (i-1)%2==0) else i

found=[]
for maximum in [6.,450.,*[value(x<<16) for x in range(0x3f80,0x4100)]]:
    direct=f32(maximum/448.)
    multiply=f32(maximum*f32(1/448.))
    if bits(direct)==bits(multiply): continue
    rd=f32(1/direct); rm=f32(1/multiply)
    for c in range(126):
        midpoint=(levels[c]+levels[c+1])/2
        candidate=bf16(direct*midpoint)
        for ab in [bits(candidate)-0x10000,bits(candidate),bits(candidate)+0x10000]:
            if ab<0: continue
            a=value(ab)
            if not 0<a<=maximum: continue
            qd=code(f32(a*rd)); qm=code(f32(a*rm))
            yd=f32(levels[qd]*direct); ym=f32(levels[qm]*multiply)
            if qd!=qm and bits(bf16(yd))!=bits(bf16(ym)):
                found.append(dict(maximum=maximum,activation=a,
                    direct_scale=f'0x{bits(direct):08x}',
                    reciprocal_multiply_scale=f'0x{bits(multiply):08x}',
                    direct_code=f'0x{qd:02x}',multiply_code=f'0x{qm:02x}',
                    direct_bf16=f'0x{bits(bf16(yd))>>16:04x}',
                    multiply_bf16=f'0x{bits(bf16(ym))>>16:04x}'))
                break
        if found: break
    if found: break
result=dict(status='independent_host_only',
    scope='BF16 input, F32 scale and reciprocal, SATFINITE RNE E4, W code1 and SF1; not hardware-rcpf equivalence',
    witnesses=found)
target=Path(__file__).with_name('scale-formation-witness.json')
target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
