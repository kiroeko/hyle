"""Record finite reader contracts separately from producer fake-QDQ and unexecuted deployment."""
from pathlib import Path
import hashlib
import json

P=Path(__file__).resolve().parent
A=P.parents[1]
R=A.parents[1]
OLD=A/'quark-mxfp4-contract-review'

def identity(path):
    path=Path(path)
    return dict(path=str(path.relative_to(R)),bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def src(group,name,lines):
    path=P/'selected-sources'/group/name
    http=json.loads(path.with_name(path.name+'.http.json').read_text(encoding='utf8'))
    assert identity(path)['sha256']==http['sha256']
    return dict(**identity(path),url=http['url'],lines=lines)

sources={
 'vllm_reader':src('vllm-276fbcff','vllm/model_executor/layers/quantization/quark/quark.py',[419,488]),
 'vllm_scheme':src('vllm-276fbcff','vllm/model_executor/layers/quantization/quark/schemes/quark_w8a8_fp8.py',[50,210]),
 'vllm_flatten':src('vllm-276fbcff','vllm/model_executor/kernels/linear/scaled_mm/ScaledMMLinearKernel.py',[135,184]),
 'vllm_quant':src('vllm-276fbcff','vllm/model_executor/layers/quantization/input_quant_fp8.py',[151,181,223,290]),
 'vllm_dispatch':src('vllm-276fbcff','vllm/model_executor/kernels/linear/__init__.py',[425,484]),
 'vllm_aiter':src('vllm-276fbcff','vllm/model_executor/kernels/linear/scaled_mm/aiter.py',[133,384]),
 'vllm_aiter_adapter':src('vllm-276fbcff','vllm/_aiter_ops.py',[1267,1287]),
 'vllm_KDA_role':src('vllm-276fbcff','vllm/models/kimi_k3/amd/kda.py',[136,165,311,341]),
 'aiter23_quant':src('aiter-7a3da22','csrc/kernels/quant_kernels.cu',[82,164,177,241,269,359,724,824]),
 'aiter23_epilogue':src('aiter-7a3da22','csrc/ck_gemm_a8w8_bpreshuffle/include/gemm_a8w8_bpreshuffle_common.cuh',[46,101,180,206]),
 'sglang_reader':src('sglang-654df43','python/sglang/srt/layers/quantization/quark/quark.py',[393,434]),
 'sglang_linear':src('sglang-654df43','python/sglang/srt/layers/quantization/fp8.py',[432,482,655,735,957,1034]),
 'sglang_load':src('sglang-654df43','python/sglang/srt/models/glm5_next.py',[1619,1626,1689,1781]),
 'sglang_dispatch':src('sglang-654df43','python/sglang/srt/layers/quantization/fp8_utils.py',[168,200,553,568,771,794,1164,1264]),
 'aiter30_quant_adapter':src('aiter-d9e5ef7','aiter/ops/quant.py',[368,384,449,506]),
 'aiter30_quant':src('aiter-d9e5ef7','csrc/kernels/quant_kernels.cu',[28,171,724,824]),
 'aiter30_cast':src('aiter-d9e5ef7','csrc/include/aiter_opus_plus.h',[20,64]),
 'aiter30_triton':src('aiter-d9e5ef7','aiter/ops/triton/_triton_kernels/gemm/basic/gemm_a8w8_blockscale.py',[160,192,365,415]),
 'sglang_triton_quant':src('sglang-654df43','python/sglang/kernels/ops/quantization/fp8_kernel.py',[155,195,246,333]),
}
inventory=[]
for path in sorted((P/'selected-sources').rglob('*.http.json')):
    row=json.loads(path.read_text(encoding='utf8'))
    body=path.with_name(path.name.removesuffix('.http.json'))
    inventory.append(dict(request=identity(path),url=row['url'],status=row['status'],
        **({'body':identity(body)} if body.exists() else {})))
metadata=[identity(path) for path in sorted((P/'reader-metadata').glob('*.json'))
    if path.name!='summary.json']
artifact_facts=json.loads((OLD/'artifact/artifact-facts.json').read_text(encoding='utf8'))['artifacts']
facts={str(row['catalog_index']):row for row in artifact_facts if row['catalog_index'] in [23,30]}
report=dict(
 status='read_only_selected_reader_contracts_no_product_or_deployment_execution',
 previous_precheck=identity(P/'review.json'),
 decisions={
  '23':dict(
   conclusion='The deployed reader geometry is per flattened token, not literal QuarkObserver axis1. A bounded external-scale code-dot leaf is a natural missing optimization; the scale formation and epilogue order must remain explicit.',
   implementable_reference='Ordinary F32 activation normalization with supplied F32 SA[M,1], original E4 W[N,K], F32 SW[N] or [1,N], E4 code dot/F32 accumulation, explicit ordered output multiplications and final output Cast. The existing scalar static-FP8 private family can support these shapes without a new public operator or full decoded W bank.',
   required_boundary='Do not call the existing SA-then-SW tree exact Aiter bpreshuffle math: the inspected Aiter candidate applies SW then SA. A cold order field or explicit graph order is necessary when qualifying that candidate.',
   not_closed='The README names a mutable container tag, not a vLLM source commit. The pinned inspected vLLM source below proves its own reader contract, not the exact historical image wheel or every kernel selected for all roles.'),
  '30':dict(
   conclusion='The pinned recommended SGLang mixed loader consumes the original E4/F32 block128 storage through a hardware FP8 code-dot path; it does not execute the Quark BF16 fake-QDQ tree.',
   primary_recipe='SGLang654df43 with the README-fixed ROCm image, gfx950, SGLANG_USE_AITER=1, automatic block backend: Aiter per1x128 HIP quantization plus shape-selected Triton or CK/bpreshuffle block GEMM.',
   implementable_reference='Reuse original block128 encoded carrier/import, group traversal, selected-ID/status and F32 dot. Add an explicit reciprocal-multiply scale-formation policy only if implementing the recommended Aiter source tree; retain current kNone direct-divide448 and power2 semantics unchanged.',
   supported_alternative='The same pinned SGLang source has an explicit --fp8-gemm-backend=triton path. Its continuous F32 scale uses max(amax,1e-10)/448 and reciprocal normalization, structurally matching the existing Float8BlockLinear(None,1e-10) portable reference. This is an explicitly selected alternative, not the README automatic Aiter execution.',
   not_closed='Exact CK/bpreshuffle per-group scaling, compiler reciprocal precision and reduction/epilogue choices were not completely proved or run here. Current BlockLinear(None) must not be relabeled as exact default Aiter math.')},
 artifact23=dict(
  repository=facts['23']['repository'],revision=facts['23']['revision'],
  README=identity(OLD/'artifact/23/README.md'),config=identity(OLD/'artifact/23/config.json'),
  recommended=dict(engine='vLLM',image_tag='vllm/vllm-openai-rocm:kimi-k3',
    stated_versions={'ROCm':'7.1.1','PyTorch':'2.10.0','Transformers':'5.2.0'},
    environment='VLLM_ROCM_USE_AITER=1',
    manual_change='QuarkOCP_MX.emulate=True only changes the OCP-MX branch; it does not define PTPC attention.',
    provenance_limit='README publishes no vLLM source commit or immutable image digest.'),
  observed_container=dict(date='2026-10-21',manifest_digest='sha256:5aa7e626ff73672f5ca7aae46754570488c23d33ca1ac90756a1d2d1a3fe099b',
    config_digest='sha256:a8798d4aae3b463dc87e1436038daa17c2a4a0ded0c4c3a3894b7dcabf382bc4',
    created='2026-07-27T14:10:45.946525451Z',aiter_build_ref='v0.1.16.post5',
    aiter_tag_commit='7a3da22d5d35f29149e8d319b513c8b4da851585',
    caveat='Current tag observation/build arguments are not runtime package introspection or proof of the publisher evaluation image; no image layer was downloaded.'),
  inspected_reader_revision='276fbcff2717bd934cfa37c8a2e4c391f3e7237b (same primary pin as retained earlier MX deployment research; not claimed to equal the container wheel)',
  loader=dict(weight='E4M3FN[N,K], original F32 channel multiplier SW[N]; transpose weight metadata for GEMM and reshape SW[N,1].',
    activation='Dynamic qscheme per_channel is mapped directly to PER_TOKEN without using ch_axis; kernel wrapper flattens all leading dimensions to A[M,K] then restores output leading shape.',
    scale_dtype='SW allocated F32. Dynamic SA returned F32. No BF16 QDQ reconstruction before dot.',
    output='Reader supplies framework/model output dtype; BF16 model configuration and Aiter BF16 candidates are consistent. Exact actual image dtype selection is not executed here.'),
  quantizer=dict(
    hip='Pinned Aiter per-token path widens source elements to F32. For K>128 general per-row reduction initializes amax to0; scale is F32(amax*F32(1/448)). Normalization uses AMD rcpf(scale) and F32 multiply before saturated FP8 conversion.',
    K128='Aiter K=32/64/128 uses the group-specialized dispatch, initializing amax at1e-10F. Catalog23 f_b_proj has K128, whereas q/k/v and other roles have larger K. This statement applies only when the Aiter quantizer is actually selected.',
    physical_f_b='The pinned AMD KDA caller obtains f_a by splitting a much wider fused in_proj output, and passes that view directly into f_b_proj. For multiple tokens that column slice is not contiguous; QuantFP8.forward_hip requires contiguous input for Aiter and otherwise calls the vLLM native custom quant operator. M1 versus multi-token can therefore change the quantization implementation. No engine Copy is inserted by this research.',
    zero_tiny='General zero/tiny scale handling and hardware NaN/FTZ/rcpf details are not certified here. Do not silently insert CT1/128, Quark fake-QDQ epsilon or the native torch fallback scale clamp.',
    torch_native_fallback='Inspected vLLM QuantFP8.forward_native is a distinct path with scale clamp min=1/(448*512), then reciprocal multiply; it is not evidence that ROCm Aiter or the separate compiled custom-op fallback uses that clamp.'),
  finite_role_consumer=dict(
    stored_role='language_model.model.layers.0.self_attn.f_a_proj',
    observed_weight='E4M3FN[128,7168]',observed_scale='F32[128]',
    observed_header=identity(OLD/'artifact/23/model-00001-of-000096.safetensors/header.json'),
    original_weight_bytes=917504,scale_bytes=512,
    reader_context='The AMD KDA reader merges q/k/v/g/f_a/b projections into one original-code bank; f_a is an output-channel slice of that affine linear, sharing hidden-token activation quantization. No recurrence/head role is implied.',
    bounded_reference='M1/M2 nonzero finite BF16 A[M,7168], supplied explicit F32 SA[M,1], original E4 W and F32 SW[128]. Normalize A with explicit reciprocal-multiply, code dot in F32, then chosen graph order of scale products and BF16/F32 output.',
    signed_scope='This can prove the original role storage/geometry, selected external-scale F32 reference and old-result resource journey. It does not certify the unpinned image dynamic quantizer, approximate AMD rcpf on all values, zero/tiny domain, fusion selection or complete KDA/model.'),
  epilogue=dict(candidate='Aiter CK bpreshuffle PTPC',accumulation='F32',
    order='C*SW*SA, followed by F16/BF16 conversion. D0 is SW and D1 is SA in MakeArgument.',
    selection='Current inspected vLLM has HipbMM, tuned bpreshuffle, tuned regular Aiter and framework fallbacks. Their availability, tuning and environment predicates prevent declaring one exact universal kernel from README alone.',
    F32_order_witness=dict(code_dot=3,SA_bits='0x3b124925',SW_bits='0x2edbe6ff',
      SA_then_SW='0x2b3c7cdc',SW_then_SA='0x2b3c7cdb',
      method='Independent host struct F32 rounding of two separate multiplications; no product/GPU execution.'))),
 artifact30=dict(
  repository=facts['30']['repository'],revision=facts['30']['revision'],
  README=identity(OLD/'artifact/30/README.md'),config=identity(OLD/'artifact/30/config.json'),
  recommendation=dict(engine='SGLang',source_commit='654df43cbee108a81fa1736c34ba8c701f199285',
    version='0.5.18',image_digest='sha256:6d68cd19206716cb3f1e31e2ad89cd0852d7ae614a792773c30a4277f8955c72',
    README_evaluated_model_revision='fc676278b68ba33f6b4724be286af9d7f6c814c2',
    revision_caveat='The README evaluation model revision differs from catalog fixed b5688f; retained fixed config/header observations remain the catalog source and are not replaced.',
    aiter_build_commit='d9e5ef7ce08ee7045d583aed768cff41aa9210fe',
    pin_evidence='Exact OCI image config ENV AITER_COMMIT and build history, only metadata retrieved.'),
  loader=dict(
    config='Static E4 per_block weight plus dynamic E4 input override is detected before ignore handling and converted to Fp8Config(dynamic,block_size=[128,128]). Original input observer axis/scale_type do not drive its quantization kernel.',
    storage='Original row-major E4 W[N,K], F32 dequant multipliers SF[ceil(N/128),K/128]. GLM loader renames weight_scale to weight_scale_inv if that parameter exists; the numbers are not inverted.',
    A='Flatten all leading dimensions to input_2d[M,K]; SA per token and Kgroup128. For input_scale=None output dtype follows input.dtype (BF16 model). Prequantized fused tuples are an additional source path, not assumed here.',
    SF='F32 storage remains F32 for gfx950. ROCm gfx942 fnuz normalization is a separate hardware branch, not this MI350/MI355 recommendation.'),
  quantizer=dict(
    source_tree='max(F32(abs(Agroup)),1e-10F) -> F32 multiply by F32(1/448) -> F32 reciprocal -> multiply F32 A -> saturating FP8 RNE. No BF16 scale or BF16 dequantized-A intermediate.',
    difference_from_None='Existing Float8BlockLinear kNone specifies direct F32 divide448, not multiply by the pre-rounded reciprocal.',
    F32_scale_witness=[dict(amax=450,direct_divide='0x3f809249',reciprocal_multiply='0x3f80924a'),
       dict(amax=6,direct_divide='0x3c5b6db7',reciprocal_multiply='0x3c5b6db8')],
    precision_limit='Source-level F32 operations/ISA conversion are established; this review does not certify compiler-specific reciprocal accuracy, denormal execution or full-kernel bit equality.'),
  GEMM=dict(
    choice='With automatic backend, Aiter is selected on ROCm when enabled. The tuned-shape list selects regular Triton; remaining gfx950/ROCm7.2 shapes use bpreshuffle CK. Weight shuffling and transposed SA are cold/native representations, not a different SF numerical convention.',
    ordinary_triton='Regular Aiter Triton kernel source accumulates dot(Acodes,Wcodes)*SA*SW in F32 by group and casts only the output.',
    preshuffled_triton='Separate preshuffle Triton branch forms SA*SW first. This is another reason not to assert one rounded scale order across every hardware implementation.',
    remaining='CK/bpreshuffle block numerical implementation not exhaustively traced; no deployment/GPU execution claim.')),
 hyle_minimal_changes=dict(
   channel='Existing ordinary Reduce/Cast/Binary/Select can explicitly generate per-token SA. Broaden only private StaticFloat8Linear/closed pattern and actual bounded kernels for scalar or SA[M,1] and scalar/SW[N]/SW[1,N]; keep original E4 bank. Preserve output-scale order in graph/cold descriptor.',
   block_storage='Current import_float8_block128_weight already accepts raw F32 macroblock scale grids and preserves bits; it can pack original E4 and the small F32 grid into canonical carrier without full floating W expansion.',
   block_math='Do not change kNone or power2 contracts to accommodate Aiter. If choosing the automatic Aiter reference, explicitly describe reciprocal scale formation and scale application order; add finite exact-boundary witnesses for these differences before qualifying it.',
   no_new_executor=True,no_model_allowlist=True,
   next_windows_base='X/cuda/checks/link2 and X/cuda/checks/bank-alignment-product1/cuda-weights.obj remain mandatory current CUDA baseline; no build undertaken in this review.'),
 sources=sources,
 unique_successful_source_bytes=sum(x['body']['bytes'] for x in inventory if 'body' in x),
 scope_limits=['No product edits','No compile/link/test/GPU/model payload/image layer downloads',
   'No equivalence claim to literal Quark eager fake-QDQ','No exact historical mutable-image reader SHA claim',
   'No full model, end-to-end reader execution, quality, performance or Linux validation'],
 network='Only bounded pinned GitHub primary sources and small official OCI manifests/config metadata; no clone/dependencies/install.')
inventory_path=P/'selected-reader-source-inventory.json'
inventory_path.write_text(json.dumps(dict(source_downloads=inventory,OCI_git_metadata=metadata),indent=2)+'\n',encoding='utf8')
report['source_and_metadata_inventory']=identity(inventory_path)
path=P/'selected-reader-contract.json'
path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(identity(path))
print('successful source bodies',sum('body' in x for x in inventory),'bytes',report['unique_successful_source_bytes'])
