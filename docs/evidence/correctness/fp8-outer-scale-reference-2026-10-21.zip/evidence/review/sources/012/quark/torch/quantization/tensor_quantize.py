#
# Copyright (C) 2023 - 2026 Advanced Micro Devices, Inc. All rights reserved.
# SPDX-License-Identifier: MIT
#
import quark.torch.kernel  # noqa

from typing import Any, Union
from abc import ABC, abstractmethod
import math
import torch
import torch.nn as nn
from quark.torch.quantization.observer.observer import (
    ObserverBase,
    PerBlockMXBufferReuseObserver,
    PerBlockMXObserver,
    PlaceholderObserver,
)
from quark.torch.quantization.config.config import QTensorConfig
from quark.torch.quantization.observer.tqt_observer import TQTObserver
from quark.torch.quantization.observer.lsq_observer import LSQObserver
from quark.torch.quantization.config.type import Dtype, QSchemeType, ZeroPointType, ScaleType
from quark.torch.quantization.utils import calculate_qmin_qmax, get_num_bits
from quark.torch.quantization.constants import (
    INT_QUANT_DTYPES,
    SCALED_QUANT_DTYPES,
    USING_NON_SCALED_QUANT,
)
from quark.torch.utils import assert_no_nan
from quark.torch.utils import (
    QUARK_COUNT_OBSERVED_SAMPLES,
    QUARK_DISABLE_COMPILE,
    QUARK_ENABLE_BUFFER_REUSE,
    QUARK_LOG_BUFFER_STATS,
)
from packaging.version import Version
from quark.common.utils.import_utils import TORCH_HIGHER_OR_EQUAL_2_5
from quark.common.utils.log import ScreenLogger
from quark.torch.kernel import mxfp4_dynamic_fake_quantize  # type: ignore

_logger = ScreenLogger(__name__)

# See: https://github.com/pytorch/pytorch/pull/141542
# TODO: Remove once we drop torch<=2.5 support.
if Version(torch.__version__) >= Version("2.6"):
    from torch._dynamo.exc import FailOnRecompileLimitHit

    PYTORCH_DYNAMO_RECOMPILE_EXCEPTION = FailOnRecompileLimitHit
elif Version(torch.__version__) >= Version("2.5"):
    from torch._dynamo.exc import FailOnCacheLimitHit

    PYTORCH_DYNAMO_RECOMPILE_EXCEPTION = FailOnCacheLimitHit
else:

    class DummyException(Exception):
        pass

    PYTORCH_DYNAMO_RECOMPILE_EXCEPTION = DummyException


if Version(torch.__version__) >= Version("2.7"):
    cache_limit_config_name = "recompile_limit"
elif Version(torch.__version__) >= Version("2.5"):
    cache_limit_config_name = "cache_size_limit"
else:
    cache_limit_config_name = None  # type: ignore

# TODO: remove once it is clear we require `torch>=2.5`.
if Version(torch.__version__) >= Version("2.5"):
    PYTORCH_DYNAMO_RECOMPILE_MESSAGE = f"The call to `scaled_fake_quantize` that is by default compiled with `torch.compile(..., fullgraph=True)` failed with the exception `{PYTORCH_DYNAMO_RECOMPILE_EXCEPTION.__name__}`. This should normally not happen, please report the issue with a reproduction. To bypass this issue, please use the environment variable `QUARK_DISABLE_COMPILE=1` to disable torch.compile usage in `scaled_fake_quantize`. In case you are using several different quantization schemes, consider increasing `torch._dynamo.config.{cache_limit_config_name}` (current torch._dynamo.config.{cache_limit_config_name}={getattr(torch._dynamo.config, cache_limit_config_name)})."
else:
    PYTORCH_DYNAMO_RECOMPILE_MESSAGE = None  # type: ignore[assignment]


class BufferReusePool:
    """Reusable tensor buffer pool with per-device statistics."""

    def __init__(self, max_buffer_numel: int = 4 * 1024 * 1024) -> None:
        self.max_buffer_numel = max_buffer_numel
        # Per-device pool, keyed by ``(buffer_name, dtype, rank)``. Keeping rank in the
        # key avoids cross-rank collisions (e.g. a 1-D ``scale`` and a 2-D MX block
        # ``scale`` of the same dtype map to different slots).
        self._device_buffer_pools: dict[str, dict[tuple[str, torch.dtype, int], torch.Tensor]] = {}
        self._buffer_stats: dict[str, dict[str, int]] = {}

    @staticmethod
    def _canonicalize_device(device: torch.device | str) -> torch.device:
        """Resolve an indexless CUDA device to its concrete index.

        ``torch.device("cuda")`` and ``torch.device("cuda:0")`` compare unequal even though
        they refer to the same physical device. PyTorch resolves the index lazily at
        allocation time, so a tensor created with ``device="cuda"`` ends up on
        ``cuda:<current>``. Without this normalization, ``can_reuse`` would short-circuit to
        False whenever a caller passes the indexless form (e.g. ``torch_device`` from the
        test harness when CUDA is available).
        """
        d = torch.device(device) if not isinstance(device, torch.device) else device
        if d.type == "cuda" and d.index is None:
            return torch.device(f"cuda:{torch.cuda.current_device()}")
        return d

    def can_reuse(self, value: torch.Tensor, target_device: torch.device) -> bool:
        """Check if a tensor buffer can be reused.

        Args:
            value: The tensor to check for buffer reuse eligibility.
            target_device: The target device where the tensor should reside.

        Returns:
            True if the tensor can be reused (i.e., its size is within the buffer limit
            and it is on the target device), False otherwise.

        """
        if value.numel() > self.max_buffer_numel:
            return False
        return self._canonicalize_device(value.device) == self._canonicalize_device(target_device)

    def _init_device_state(self, target_device: torch.device) -> None:
        """Initialize device-specific state for buffer pooling and statistics.

        This method ensures that the necessary data structures (buffer pools and statistics)
        are initialized for the given device. If they already exist, no action is taken.

        Parameters:
            target_device (torch.device): The device for which to initialize state.
        """
        device_str = str(target_device)
        if device_str not in self._device_buffer_pools:
            self._device_buffer_pools[device_str] = {}
        if device_str not in self._buffer_stats:
            self._buffer_stats[device_str] = {"reuse_count": 0, "total_bytes": 0, "call_count": 0}

    def record_call(self, target_device: torch.device) -> None:
        """
        Record a buffer usage call for the specified device.

        Args:
            target_device: The torch device for which to record the call.
        """
        self._init_device_state(target_device)
        device_str = str(target_device)
        self._buffer_stats[device_str]["call_count"] += 1

    def get_buffer_stats(self, target_device: torch.device) -> dict[str, int]:
        """
        Retrieve buffer statistics for a specific device.

        Parameters:
        - target_device: The device for which to retrieve buffer statistics

        Returns:
        A dictionary containing buffer statistics with the following keys:
        - 'reuse_count': Number of times buffers were reused
        - 'total_bytes': Total memory allocated for buffers in bytes
        - 'call_count': Total number of calls to the buffer pool
        """
        self._init_device_state(target_device)
        return self._buffer_stats[str(target_device)]

    def _get_or_allocate_buffer(
        self, target_device: torch.device, shape: tuple[int, ...], dtype: torch.dtype, buffer_name: str, numel: int
    ) -> torch.Tensor:
        """Get or allocate a per-device reusable buffer for a given shape.

        The pool keeps a **single** buffer per ``(buffer_name, dtype, rank)`` slot per
        device, replacing the previous linear scan over heterogeneous buffers:

        * If the slot's existing buffer already covers ``shape`` along every dim, the
          request is satisfied with a sliced view (counted as a reuse).
        * Otherwise the slot is reallocated to the element-wise maximum of its current
          shape and the requested shape, so subsequent calls keep reusing the slot
          regardless of which axis grew (counted as a fresh allocation).

        This is O(1) per call and bounds the pool size to the number of distinct
        ``(name, dtype, rank)`` triples per device, while still allowing slice-based
        reuse across heterogeneous shapes.
        """
        self._init_device_state(target_device)
        device_str = str(target_device)
        rank = len(shape)

        if numel > self.max_buffer_numel:
            _logger.warning(
                f"Buffer reuse fallback for oversize tensor {shape} ({numel} elements > {self.max_buffer_numel})."
            )
            return torch.empty(shape, device=target_device, dtype=dtype)

        buffer_pool = self._device_buffer_pools[device_str]
        key = (buffer_name, dtype, rank)
        existing = buffer_pool.get(key)
        slices = tuple(slice(0, s) for s in shape)

        if existing is not None and all(existing.shape[i] >= shape[i] for i in range(rank)):
            self._buffer_stats[device_str]["reuse_count"] += 1
            return existing[slices]

        # Need to allocate (slot empty) or grow (request exceeds slot in some dim).
        if existing is None:
            new_shape: tuple[int, ...] = tuple(shape)
        else:
            new_shape = tuple(max(existing.shape[i], shape[i]) for i in range(rank))

        new_numel = 1
        for s in new_shape:
            new_numel *= s
        if new_numel > self.max_buffer_numel:
            # Growing the slot would exceed the pool cap; serve this request from a
            # transient allocation and leave the slot's existing buffer untouched.
            _logger.warning(
                f"Buffer reuse slot {key} would grow to {new_shape} "
                f"({new_numel} elements > {self.max_buffer_numel}); using non-pooled allocation."
            )
            return torch.empty(shape, device=target_device, dtype=dtype)

        new_buffer = torch.empty(new_shape, device=target_device, dtype=dtype)
        if existing is not None:
            self._buffer_stats[device_str]["total_bytes"] -= existing.numel() * existing.element_size()
        buffer_pool[key] = new_buffer
        self._buffer_stats[device_str]["total_bytes"] += new_numel * new_buffer.element_size()
        return new_buffer[slices]

    def _print_buffer_stats(self, target_device: torch.device) -> None:
        stats = self.get_buffer_stats(target_device)
        reuse_rate = stats["reuse_count"] / stats["call_count"] * 100.0
        total_mb = stats["total_bytes"] / (1024 * 1024)
        _logger.info(
            f"[FakeQuantize Buffer Stats - {target_device}] Calls: {stats['call_count']}, "
            f"Buffer Reuses: {stats['reuse_count']} ({reuse_rate:.1f}%), "
            f"Total Buffer Memory: {total_mb:.2f} MiB"
        )

    def maybe_log_stats(self, target_device: torch.device, log_every_calls: int = 100) -> None:
        if not QUARK_LOG_BUFFER_STATS:
            return
        stats = self.get_buffer_stats(target_device)
        if stats["call_count"] == 0 or stats["call_count"] % log_every_calls != 0:
            return
        self._print_buffer_stats(target_device)


class FakeQuantizeBase(ABC, nn.Module):
    r"""Base fake quantize module.

    Base fake quantize module
    Any fake quantize implementation should derive from this class.

    Concrete fake quantize module should follow the same API. In forward, they will update
    the statistics of the observed Tensor and fake quantize the input. They should also provide a
    `calculate_qparams` function that computes the quantization parameters given
    the collected statistics.

    """

    fake_quant_enabled: bool
    observer_enabled: bool
    is_dynamic: bool | None = None
    _buffer_pool: BufferReusePool = BufferReusePool()

    def __init__(self, quant_spec: QTensorConfig, device: torch.device | None = None) -> None:
        """Set fake_quant_enabled and observer_enabled."""
        super().__init__()

        self.quant_spec = quant_spec
        self.is_dynamic = quant_spec.is_dynamic
        self.fake_quant_enabled = True
        self.observer_enabled = True
        self.enable_buffer_reuse = QUARK_ENABLE_BUFFER_REUSE

    @abstractmethod
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        pass

    def calculate_qparams(self, x: torch.Tensor) -> None:
        pass

    @abstractmethod
    def to_frozen_module(self, frozen_params: bool) -> nn.Module:
        pass

    def enable_fake_quant(self, enabled: bool = True) -> None:
        self.fake_quant_enabled = enabled

    def disable_fake_quant(self) -> None:
        self.enable_fake_quant(False)

    def enable_observer(self, enabled: bool = True) -> None:
        self.observer_enabled = enabled

    def disable_observer(self) -> None:
        self.enable_observer(False)

    @property
    def is_observer_enabled(self) -> bool:
        return self.observer_enabled

    @property
    def is_fake_quant_enabled(self) -> bool:
        return self.fake_quant_enabled

    def update_buffer(
        self, buffer_name: str, new_value: torch.Tensor | None, input_tensor_device: torch.device
    ) -> None:
        """
        Update the value of a registered buffer while ensuring that its shape,
        device, and data type match the input tensor.

        Parameters:
        - buffer_name: The name of the buffer to update
        - new_value: The new value to assign to the buffer
        - input_tensor_device: The target device (e.g., torch.device('cuda') or torch.device('cpu'))
        """

        buffer = getattr(self, buffer_name)
        self._buffer_pool.record_call(input_tensor_device)

        if new_value is not None:
            if self.enable_buffer_reuse and self._buffer_pool.can_reuse(new_value, input_tensor_device):
                buffer = self._buffer_pool._get_or_allocate_buffer(
                    input_tensor_device,
                    tuple(new_value.shape),
                    new_value.dtype,
                    buffer_name,
                    numel=new_value.numel(),
                )
                buffer.copy_(new_value)
            else:
                if buffer.shape != new_value.shape:
                    buffer.resize_(new_value.shape)
                buffer = buffer.to(new_value.dtype)
                buffer.copy_(new_value)

        buffer = buffer.to(input_tensor_device)
        setattr(self, buffer_name, buffer)
        if QUARK_LOG_BUFFER_STATS:
            self._buffer_pool.maybe_log_stats(input_tensor_device)

    # TODO: remove kwargs.
    @staticmethod
    def get_fake_quantize(
        quant_spec: QTensorConfig | list[QTensorConfig],
        device: torch.device | None = None,
        sequential: bool = False,
        **kwargs: Any,
    ) -> Union["FakeQuantizeBase", "SequentialQuantize"]:
        # Handle list of specs for sequential quantization (e.g. NVFP4).
        if isinstance(quant_spec, list):
            return SequentialQuantize(quant_specs=quant_spec, device=device)

        constructor_kwargs = {}
        # Handle single spec case.
        if quant_spec.dtype in USING_NON_SCALED_QUANT:
            scaled_fake_quantize_cls = NonScaledFakeQuantize
        else:
            # In case sequential quantization is used, we need to retain the
            # first-level quantization parameters (scale, zero-point), even though
            # dynamic quantization is used.
            # It is because the next quantizer actually quantizes the scale.
            if quant_spec.is_dynamic and not sequential:
                scaled_fake_quantize_cls = DynamicScaledFakeQuantize  # type: ignore[assignment]
            else:
                scaled_fake_quantize_cls = StaticScaledFakeQuantize  # type: ignore[assignment]
                constructor_kwargs["sequential"] = sequential

        return scaled_fake_quantize_cls(quant_spec=quant_spec, device=device, **constructor_kwargs)


class ScaledFakeQuantize(FakeQuantizeBase):
    def __init__(
        self,
        quant_spec: QTensorConfig,
        device: torch.device | None = None,
    ) -> None:
        super().__init__(quant_spec, device)

        # Set properties with Quant Config
        self.frozen_params = False

        self.dtype = quant_spec.dtype
        self.mx_element_dtype = quant_spec.mx_element_dtype
        self.qscheme = quant_spec.qscheme
        self.qscheme_str_name = getattr(quant_spec.qscheme, "value", None)
        self.ch_axis = quant_spec.ch_axis
        self.group_size = quant_spec.group_size
        self.symmetric = quant_spec.symmetric
        self.round_method = getattr(quant_spec.round_method, "value", None)
        self.scale_type = quant_spec.scale_type
        self._num_bits = get_num_bits(quant_spec.dtype)
        self.is_scale_quant = quant_spec.is_scale_quant

        self.scale_torch_dtype = None
        if self.scale_type in [ScaleType.float32, ScaleType.float16, ScaleType.bfloat16]:
            self.scale_torch_dtype = self.scale_type.to_torch_dtype()
        self.zero_point_type = quant_spec.zero_point_type
        self.quant_min, self.quant_max = calculate_qmin_qmax(self.dtype)

    @staticmethod
    def create_observer(quant_spec: QTensorConfig, device: torch.device | None = None) -> ObserverBase:
        if quant_spec.observer_cls is not None:
            observer_cls = quant_spec.observer_cls
            # The buffer-reuse observer can be opted into per-spec (consistent with
            # ``DynamicScaledQuantizer.create_observer``) or globally via the env var.
            if observer_cls is PerBlockMXObserver and (
                QUARK_ENABLE_BUFFER_REUSE or getattr(quant_spec, "enable_buffer_reuse", False)
            ):
                observer_cls = PerBlockMXBufferReuseObserver
            return observer_cls(quant_spec, device)
        else:
            return PlaceholderObserver(quant_spec)

    def fake_quantize_with_qparams(
        self, X: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor
    ) -> torch.Tensor:
        if isinstance(self.observer, TQTObserver):
            X = quark.torch.kernel.tqt_quantize(  # type: ignore[attr-defined]
                X, self.observer.log_threshold, zero_point, self.observer.domain, self.round_method
            )
        elif isinstance(self.observer, LSQObserver):
            grad_factor = 1.0 / math.sqrt(X.numel() * self.observer.quant_max)
            X = quark.torch.kernel.lsq_quantize(  # type: ignore[attr-defined]
                X,
                scale + self.observer.eps,
                zero_point,
                grad_factor,
                self.observer.quant_min,
                self.observer.quant_max,
                self.ch_axis,
                self.round_method,
            )
        else:
            mx_element_dtype_value = "None" if self.mx_element_dtype is None else self.mx_element_dtype.value

            if (
                QUARK_DISABLE_COMPILE
                or not TORCH_HIGHER_OR_EQUAL_2_5
                or torch.jit.is_tracing()
                or torch.compiler.is_compiling()  # type: ignore[attr-defined]
                or not X.is_contiguous()
            ):
                # torch.onnx.export uses jit.trace by default to get a ScriptModule model, which currently does not supported tracing a dynamo-optimized model.
                # Reference: https://github.com/pytorch/pytorch/blob/v2.7.1/torch/_dynamo/eval_frame.py#L634.
                # In case we compile at a level above, we will obey the high level `torch.compile` parameters and thus does not use the compiled `scaled_fake_quantize` here.
                # In case the input `X` is not contiguous, `torch.compile` has some overhead from `copy_misaligned_inputs` that may make the compiled function
                # slower than eager in some cases. We disable torch.compile by default in this case until further investigation is done.
                fake_quantize = quark.torch.kernel.scaled_fake_quantize  # type: ignore[attr-defined]
            else:
                fake_quantize = quark.torch.kernel.scaled_fake_quantize_compiled  # type: ignore[attr-defined]

            if self.zero_point_type == ZeroPointType.float32:
                zero_point_dtype = torch.float32
            else:
                zero_point_dtype = torch.int32

            zero_point = zero_point.to(zero_point_dtype) if zero_point is not None else None

            try:
                X = fake_quantize(
                    self.dtype.value,
                    X,
                    scale,
                    zero_point,
                    self.ch_axis,
                    self.group_size,
                    self.quant_min,
                    self.quant_max,
                    self.round_method,
                    self.qscheme_str_name,
                    mx_element_dtype_value,
                )
            except PYTORCH_DYNAMO_RECOMPILE_EXCEPTION as e:  # pragma: no cover
                raise PYTORCH_DYNAMO_RECOMPILE_EXCEPTION(PYTORCH_DYNAMO_RECOMPILE_MESSAGE) from e

        return X


class StaticScaledFakeQuantize(ScaledFakeQuantize):
    scale: torch.Tensor
    zero_point: torch.Tensor

    def __init__(self, quant_spec: QTensorConfig, device: torch.device | None = None, sequential: bool = False) -> None:
        super().__init__(quant_spec, device)

        if quant_spec.is_dynamic and not sequential:
            raise ValueError(
                f"StaticScaledFakeQuantize is meant to be instantiated only for a static quantization configuration, but got `quant_spec.is_dynamic={quant_spec.is_dynamic}`. Please check your code or open an issue."
            )

        self.is_dynamic = False
        if sequential:
            self.is_dynamic = quant_spec.is_dynamic

        # Dynamic quantizers should compute qparams from current tensors and must
        # not persist/export scale or zero-point buffers.
        self.persistent = not self.is_dynamic

        self.observer = self.create_observer(quant_spec, device)

        self.register_buffer(
            "scale", torch.tensor(1.0, dtype=self.scale_torch_dtype, device=device), persistent=self.persistent
        )

        persistent = self.persistent and self.dtype in INT_QUANT_DTYPES
        if self.zero_point_type == ZeroPointType.float32:
            self.register_buffer(
                "zero_point", torch.tensor(0.0, dtype=torch.float, device=device), persistent=persistent
            )
        else:
            self.register_buffer("zero_point", torch.tensor(0, dtype=torch.int, device=device), persistent=persistent)

    def calculate_qparams(self, X: torch.Tensor) -> None:
        assert_no_nan(X, message="tensor contains NaN!")
        qparams = self.observer._calculate_qparams()
        if qparams is not None:
            _scale, _zero_point = qparams

            assert_no_nan(_scale, message="scale contains NaN!")
            assert_no_nan(_zero_point, message="zero_point contains NaN!")

            self.update_buffer("scale", _scale, X.device)
            self.update_buffer("zero_point", _zero_point, X.device)

    def observe(self, X: torch.Tensor) -> None:
        if QUARK_COUNT_OBSERVED_SAMPLES:
            self.observer.record_observed_tokens(X)

        self.observer(X.detach())
        self.calculate_qparams(X)

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        if self.is_observer_enabled:
            self.observe(X)

        if self.is_fake_quant_enabled:
            # TODO: There should not be this mismatch for `LSQObserver` as to where
            # scales and zero_points are held.
            if isinstance(self.observer, LSQObserver):
                scale = self.observer.scale
                zero_point = self.observer.zero_point
            else:
                scale = self.scale  # type: ignore[assignment]
                zero_point = self.zero_point

            # TODO: do we really need the `.to(X.device)` here? Should we not expect
            # correct device in the first place?
            X = self.fake_quantize_with_qparams(X, scale=scale.to(X.device), zero_point=zero_point.to(X.device))

        assert_no_nan(X, message="output tensor X contains NaN!")
        return X

    def extra_repr(self) -> str:
        return (
            f"fake_quant_enabled={self.fake_quant_enabled}, observer_enabled={self.observer_enabled}, "
            f"quant_min={self.quant_min}, quant_max={self.quant_max}, dtype={self.dtype}, qscheme={self.qscheme}, mx_element_dtype={self.mx_element_dtype}, ch_axis={self.ch_axis}, "
            f"scale={self.scale}, zero_point={self.zero_point}"
        )

    def _save_to_state_dict(
        self, destination: dict[str, torch.nn.Parameter | torch.Tensor], prefix: str, keep_vars: bool
    ) -> None:
        # TODO: do we really need this? state_dict() already contains persistent buffers!

        # We cannot currently register scalar values as buffers, so need to manually
        # specify serialization here.
        super()._save_to_state_dict(destination, prefix, keep_vars)  # type: ignore
        if not self.persistent:
            return

        if self.dtype in [
            Dtype.int4,
            Dtype.uint4,
            Dtype.int8,
            Dtype.uint8,
            Dtype.fp8_e4m3,
            Dtype.fp8_e5m2,
            Dtype.mx,
            Dtype.mx6,
            Dtype.mx9,
        ]:
            destination[prefix + "scale"] = self.scale

            if self.dtype in INT_QUANT_DTYPES:
                destination[prefix + "zero_point"] = self.zero_point

    def _load_from_state_dict(
        self,
        state_dict: dict[str, torch.nn.Parameter | torch.Tensor],
        prefix: str,
        local_metadata: dict[str, Any],
        strict: bool,
        missing_keys: list[str],
        unexpected_keys: list[str],
        error_msgs: list[str],
    ) -> None:
        # Removing this function throws an error that the the size of the loaded tensor does not match the original size
        # i.e., These buffers start out with numel 0 and become numel 1 once they have their first forward pass.
        local_state = ["scale", "zero_point"]
        for name in local_state:
            key = prefix + name
            if key in state_dict:
                val = state_dict[key]
                # Custom handling to allow loading scale and zero_point
                # of size N into uninitialized buffers of size 0. The
                # buffers are resized here, and the values are copied in
                # the default state_dict loading code of the parent.
                if name == "scale":
                    self.scale.resize_(val.shape)
                else:
                    assert name == "zero_point"
                    self.zero_point.resize_(val.shape)
                # For torchscript module we need to update the attributes here since we do not
                # call the `_load_from_state_dict` function defined module.py
                if torch.jit.is_scripting():  # type: ignore[attr-defined]
                    if name == "scale":
                        self.scale.copy_(val)
                    else:
                        assert name == "zero_point"
                        self.zero_point.copy_(val)

        super()._load_from_state_dict(
            state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs
        )  # type: ignore

    def to_frozen_module(self, frozen_params: bool) -> nn.Module:
        frozen_fake_quantize_model = FrozenScaledFakeQuantize(self.dtype, self.quant_spec)
        if self.dtype in SCALED_QUANT_DTYPES:
            frozen_fake_quantize_model.register_buffer("scale", self.scale, persistent=self.persistent)

            persistent = self.persistent and self.dtype in INT_QUANT_DTYPES
            frozen_fake_quantize_model.register_buffer("zero_point", self.zero_point, persistent=persistent)

        frozen_fake_quantize_model.qscheme = self.qscheme
        frozen_fake_quantize_model.qscheme_str_name = self.qscheme_str_name
        frozen_fake_quantize_model.ch_axis = self.ch_axis
        frozen_fake_quantize_model.group_size = self.group_size
        frozen_fake_quantize_model.round_method = self.round_method
        frozen_fake_quantize_model.quant_min = getattr(self, "quant_min", None)
        frozen_fake_quantize_model.quant_max = getattr(self, "quant_max", None)
        frozen_fake_quantize_model.mx_element_dtype = self.mx_element_dtype
        frozen_fake_quantize_model.zero_point_type = self.zero_point_type
        frozen_fake_quantize_model.is_scale_quant = self.is_scale_quant
        frozen_fake_quantize_model.quant_spec = self.quant_spec
        if hasattr(self, "_quantized_block_scale"):
            frozen_fake_quantize_model._quantized_block_scale = self._quantized_block_scale
        frozen_fake_quantize_model.frozen_params = frozen_params
        return frozen_fake_quantize_model


class DynamicScaledFakeQuantize(ScaledFakeQuantize):
    def __init__(
        self,
        quant_spec: QTensorConfig,
        device: torch.device | None = None,
    ) -> None:
        super().__init__(quant_spec, device)

        if not quant_spec.is_dynamic:
            raise ValueError(
                f"DynamicScaledFakeQuantize is meant to be instantiated only for a dynamic quantization configuration, but got `quant_spec.is_dynamic={quant_spec.is_dynamic}`. Please check your code or open an issue."
            )
        self.is_dynamic = True

        if quant_spec.is_ocp_mxfp4() and quant_spec.scale_calculation_mode == "even":
            self.fake_quantize_func = mxfp4_dynamic_fake_quantize
            self.fake_quantize_func_kwargs = {
                "fake_quantizer": self,
                "scale_calculation_mode": quant_spec.scale_calculation_mode,
            }
        else:
            self.fake_quantize_func = self.fake_quantize  # type: ignore[assignment]
            self.fake_quantize_func_kwargs = {}

        # Even though we use a fast fused observer + QDQ kernel in some cases,
        # we always define the correspondig `self.observer` in order to be able to call
        # the `observe` method if necessary (e.g. debugging).
        self.observer = self.create_observer(quant_spec, device)

    def observe(self, X: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if QUARK_COUNT_OBSERVED_SAMPLES:
            self.observer.record_observed_tokens(X)

        self.observer(X.detach())

        qparams = self.observer._calculate_qparams()
        scale, zero_point = qparams

        return scale, zero_point

    def fake_quantize(self, X: torch.Tensor) -> torch.Tensor:
        """
        Default QDQ fake quantization method.
        """
        scale, zero_point = self.observe(X)

        # TODO: do we really need the `.to(X.device)` here? Should we not expect
        # correct device in the first place?
        zero_point = zero_point.to(X.device) if zero_point is not None else None
        X = self.fake_quantize_with_qparams(X, scale=scale.to(X.device), zero_point=zero_point)

        return X

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        if self.is_fake_quant_enabled:
            X = self.fake_quantize_func(X, **self.fake_quantize_func_kwargs)  # type: ignore

        return X

    def extra_repr(self) -> str:
        return (
            f"fake_quant_enabled={self.fake_quant_enabled}"
            f"quant_min={self.quant_min}, quant_max={self.quant_max}, dtype={self.dtype}, qscheme={self.qscheme}, mx_element_dtype={self.mx_element_dtype}, ch_axis={self.ch_axis}, "
        )

    # The type hint is correct here but mypy complains.
    def to_frozen_module(self) -> nn.Module:  # type: ignore
        return self


class FrozenScaledFakeQuantize(nn.Module):
    scale: torch.Tensor
    zero_point: torch.Tensor

    def __init__(self, dtype: Dtype, quant_spec: QTensorConfig) -> None:
        super().__init__()

        self.zero_point_type: ZeroPointType | None = quant_spec.zero_point_type

        persistent = not quant_spec.is_dynamic
        self.register_buffer("scale", torch.tensor([1.0], dtype=torch.float), persistent=persistent)

        persistent = persistent and quant_spec.dtype in INT_QUANT_DTYPES
        if self.zero_point_type == ZeroPointType.float32:
            self.register_buffer("zero_point", torch.tensor([0.0], dtype=torch.float), persistent=persistent)
        else:
            self.register_buffer("zero_point", torch.tensor([0], dtype=torch.int), persistent=persistent)

        self.dtype: Dtype = dtype
        self.quant_spec = quant_spec
        self.quant_min: int | None = None
        self.quant_max: int | None = None
        self.qscheme: QSchemeType | None = None
        self.qscheme_str_name: str | None = None
        self.ch_axis: int | None = None
        self.group_size: int | None = None
        self.round_method: int | None = None
        self.mx_element_dtype: Dtype | None = None
        self.is_scale_quant: bool = False
        self.frozen_params: bool | None = None

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        mx_element_dtype_value = "None" if self.mx_element_dtype is None else self.mx_element_dtype.value

        if (
            QUARK_DISABLE_COMPILE
            or not TORCH_HIGHER_OR_EQUAL_2_5
            or torch.jit.is_tracing()
            or torch.compiler.is_compiling()  # type: ignore[attr-defined]
            or not X.is_contiguous()
        ):
            # torch.onnx.export uses jit.trace by default to get a ScriptModule model, which currently does not supported tracing a dynamo-optimized model.
            # Reference: https://github.com/pytorch/pytorch/blob/v2.7.1/torch/_dynamo/eval_frame.py#L634.
            # In case we compile at a level above, we will obey the high level `torch.compile` parameters and thus does not use the compiled `scaled_fake_quantize` here.
            # In case the input `X` is not contiguous, `torch.compile` has some overhead from `copy_misaligned_inputs` that may make the compiled function
            # slower than eager in some cases. We disable torch.compile by default in this case until further investigation is done.
            fake_quantize = quark.torch.kernel.scaled_fake_quantize  # type: ignore[attr-defined]
        else:
            fake_quantize = quark.torch.kernel.scaled_fake_quantize_compiled  # type: ignore[attr-defined]

            # Bypass a PyTorch bug: https://github.com/pytorch/pytorch/issues/165051
            # This is fine to do as ScaledFakeQuantize backward is a straight-through estimator.
            if isinstance(X, torch.nn.Parameter):
                X = X.data

        if self.zero_point_type == ZeroPointType.float32:
            zero_point_dtype = torch.float32
        else:
            zero_point_dtype = torch.int32

        try:
            X = fake_quantize(
                self.dtype.value,
                X,
                self.scale,
                self.zero_point.to(zero_point_dtype),
                self.ch_axis,
                self.group_size,
                self.quant_min,
                self.quant_max,
                self.round_method,
                self.qscheme_str_name,
                mx_element_dtype_value,
            )
        except PYTORCH_DYNAMO_RECOMPILE_EXCEPTION as e:  # pragma: no cover
            raise PYTORCH_DYNAMO_RECOMPILE_EXCEPTION(PYTORCH_DYNAMO_RECOMPILE_MESSAGE) from e

        assert isinstance(X, torch.Tensor)

        return X

    def _load_from_state_dict(
        self,
        state_dict: dict[str, Any],
        prefix: str,
        local_metadata: dict[str, Any],
        strict: bool,
        missing_keys: list[str],
        unexpected_keys: list[str],
        error_msgs: list[str],
    ) -> None:
        for name, value in state_dict.items():
            if "scale" in name:
                self.scale.resize_(value.shape)

            if "zero_point" in name:
                self.zero_point.resize_(value.shape)

        super()._load_from_state_dict(
            state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs
        )  # type: ignore


class NonScaledFakeQuantize(FakeQuantizeBase):
    def __init__(self, quant_spec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(quant_spec, device)

        self.dtype = quant_spec.dtype
        self.mx_element_dtype = quant_spec.mx_element_dtype
        self.axis = quant_spec.ch_axis
        self.group_size = quant_spec.group_size
        self.scale_calculation_mode = quant_spec.scale_calculation_mode
        self.observer = self.create_observer(quant_spec, device)
        self.frozen_params = False

    @staticmethod
    def create_observer(quant_spec: QTensorConfig, device: torch.device | None = None) -> ObserverBase:
        return PlaceholderObserver(quant_spec)

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        if self.is_fake_quant_enabled:
            X = quark.torch.kernel.non_scaled_fake_quantize(  # type: ignore[attr-defined]
                X,
                self.dtype.value,
                self.mx_element_dtype.value if self.mx_element_dtype is not None else "",
                self.axis,
                self.group_size,
                self.scale_calculation_mode,
            )
        assert isinstance(X, torch.Tensor)
        return X

    def to_frozen_module(self, frozen_params: bool) -> nn.Module:
        self.frozen_params = frozen_params
        return self


class SequentialQuantize(nn.Sequential):
    """A sequential container for  :class:`FakeQuantizeBase` modules.

    This modules is used to quantize a tensor in multiple formats sequentially. It takes as input
    a list of quantization specifications and containerize them similar to :class:`torch.nn.Sequential`.

    Args:
        quant_specs (List[QTensorConfig]): List of quantization specifications.
        device (Optional[torch.device]): Device to run the quantization on.

    """

    is_dynamic: bool | None = None

    def __init__(self, quant_specs: list[QTensorConfig], device: torch.device | None = None) -> None:
        """Initialize SequentialQuantize module."""
        quantizers = [FakeQuantizeBase.get_fake_quantize(spec, device, sequential=True) for spec in quant_specs]
        assert not any(not isinstance(q, FakeQuantizeBase) for q in quantizers), (
            "All quantizers must be a FakeQuantizeBase."
        )
        super().__init__(*quantizers)

        assert all(quantizer.frozen_params == quantizers[0].frozen_params for quantizer in quantizers), (  # type: ignore
            "The frozen_params configuration of all quantizers should be the same"
        )
        self.frozen_params = quantizers[0].frozen_params  # type: ignore

        assert all(not isinstance(quantizer, NonScaledFakeQuantize) for quantizer in quantizers), (
            "NonScaledFakeQuantize is not supported in SequentialQuantize currently"
        )
        assert all(not isinstance(quantizer.observer, TQTObserver | LSQObserver) for quantizer in quantizers), (
            "TQTObserver and LSQObserver are not supported in SequentialQuantize currently"
        )
        assert all((quantizer.zero_point_type != ZeroPointType.float32) for quantizer in quantizers), (
            "Float32 zero point is not supported in SequentialQuantize currently"
        )

        tensor_quantizers = [quantizer for quantizer in quantizers if quantizer.is_scale_quant is False]
        assert len(tensor_quantizers) > 0, "SequentialQuantize must contain at least one tensor quantizer"
        assert all(
            tensor_quantizer.is_dynamic == tensor_quantizers[0].is_dynamic for tensor_quantizer in tensor_quantizers
        ), "Tensor quantizers in SequentialQuantize must share the same is_dynamic configuration"

        self.is_dynamic = tensor_quantizers[0].is_dynamic

        # For FP8 scale quantizers following an amax-based quantizer, configure combined
        # division to avoid intermediate rounding precision loss. See forward() for details.
        for quantizer_index, quantizer in enumerate(quantizers):
            if quantizer.is_scale_quant and quantizer_index > 0:
                preceding_quantizer = quantizers[quantizer_index - 1]
                is_fp8_scale = quantizer.quant_spec.dtype in (Dtype.fp8_e4m3, Dtype.fp8_e5m2, Dtype.fp8_e5m3)
                if is_fp8_scale and hasattr(preceding_quantizer.observer, "amax"):
                    _, element_format_max = calculate_qmin_qmax(preceding_quantizer.quant_spec.dtype)
                    quantizer.observer.quant_max_first_level = float(element_format_max)

    def disable_fake_quant(self) -> None:
        for module in self:
            if isinstance(module, FrozenScaledFakeQuantize):
                continue
            module.disable_fake_quant()

    def enable_observer(self, enabled: bool = True) -> None:
        for module in self:
            if isinstance(module, FrozenScaledFakeQuantize):
                continue
            module.enable_observer(enabled)

    @property
    def is_observer_enabled(self) -> bool:
        return any((not isinstance(module, FrozenScaledFakeQuantize)) and module.is_observer_enabled for module in self)

    @property
    def is_fake_quant_enabled(self) -> bool:
        return any(isinstance(module, FrozenScaledFakeQuantize) or module.is_fake_quant_enabled for module in self)

    # store the config of the is_fake_quant_enabled status of each module
    def get_fake_quant_enabled_config(self) -> list[bool | None]:
        return [
            module.is_fake_quant_enabled if not isinstance(module, FrozenScaledFakeQuantize) else None
            for module in self
        ]

    # restore the config of the is_fake_quant_enabled status of each module
    def restore_fake_quant_enabled_config(self, config: list[bool | None]) -> None:
        for module, enabled in zip(self, config, strict=False):
            if isinstance(module, FrozenScaledFakeQuantize):
                continue
            module.enable_fake_quant(enabled)

    # check the class contains at least two tensor quantizers
    def contains_at_least_two_tensor_quantizers(self) -> bool:
        tensor_quantizers = [module for module in self if module.is_scale_quant is False]
        return len(tensor_quantizers) >= 2

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        """Forward pass for sequential quantization."""
        # Observer mode
        if self.is_observer_enabled:
            fake_quant_enabled_config = self.get_fake_quant_enabled_config()
            self.disable_fake_quant()

            previous_tensor_quantizer = None
            quant_x = X.clone() if self.contains_at_least_two_tensor_quantizers() else X

            for module_index, module in enumerate(self):
                if module.is_scale_quant:
                    self._validate_scale_quantizer(module_index)
                    preceding_quantizer = self[module_index - 1]
                    is_fp8_scale = module.quant_spec.dtype in (Dtype.fp8_e4m3, Dtype.fp8_e5m2, Dtype.fp8_e5m3)
                    if is_fp8_scale and hasattr(preceding_quantizer.observer, "amax"):
                        # Combined division: in two-stage quantization, the global scale is
                        # normally computed as two sequential divisions:
                        #   scale = (amax / element_format_max) / scale_format_max
                        # The intermediate result gets rounded, causing precision loss.
                        # Instead, pass raw amax here. The observer's quant_max_first_level
                        # (set in __init__) combines both divisors into a single division:
                        #   scale = amax / (element_format_max * scale_format_max)
                        module(preceding_quantizer.observer.amax)
                    else:
                        # Standard path: pass the computed scale from the preceding quantizer.
                        module(preceding_quantizer.scale)
                else:
                    quant_x = self._process_tensor_quantizer(
                        module_index, module, previous_tensor_quantizer, quant_x, X.dtype
                    )
                    previous_tensor_quantizer = module

            if self.contains_at_least_two_tensor_quantizers():
                del quant_x
            self.restore_fake_quant_enabled_config(fake_quant_enabled_config)

        # Fake quantization mode
        if self.is_fake_quant_enabled:
            # Forward quantization
            X = self._apply_forward_quantization(X)
            # Reverse dequantization
            X = self._apply_reverse_dequantization(X)

        return X

    def _validate_scale_quantizer(self, module_index: int) -> None:
        """Validate scale quantizer configuration."""
        assert module_index > 0, "Scale quantizer could not be the first one"
        previous_module = self[module_index - 1]
        assert isinstance(previous_module, ScaledFakeQuantize), "Previous module must be ScaledFakeQuantize"
        assert previous_module.qscheme_str_name == "per_group", "Only per_group scheme supported"
        assert not previous_module.is_scale_quant, "Previous module cannot be scale quantizer"

    def _process_tensor_quantizer(
        self, module_index: int, module: Any, previous_quantizer: Any, x: torch.Tensor, target_dtype: torch.dtype
    ) -> torch.Tensor:
        """Process tensor quantizer and apply quantization."""
        if previous_quantizer is None:
            module(x)
            return x

        if self[module_index - 1].is_scale_quant:
            prev_module = self[module_index - 1]
            previous_quantizer.scale = self._apply_scale_quantization(previous_quantizer, prev_module)

        x = self._apply_tensor_quantization(previous_quantizer, x, target_dtype)
        module(x)
        return x

    def _apply_forward_quantization(self, X: torch.Tensor) -> torch.Tensor:
        """Apply forward quantization to input tensor."""
        x_dtype = X.dtype
        for module_index, module in enumerate(self):
            if not module.is_scale_quant:
                if module_index < len(self) - 1 and self[module_index + 1].is_scale_quant:
                    next_module = self[module_index + 1]
                    module.scale = self._apply_scale_quantization(module, next_module)
                X = self._apply_tensor_quantization(module, X, x_dtype)
        return X

    def _apply_reverse_dequantization(self, X: torch.Tensor) -> torch.Tensor:
        """Apply reverse dequantization to input tensor."""
        x_dtype = X.dtype
        for module in reversed(self):
            if not module.is_scale_quant:
                X = quark.torch.kernel.dequantize(  # type: ignore[attr-defined]
                    module.dtype.value,
                    X,
                    module.scale,
                    module.zero_point.to(torch.int) if module.zero_point is not None else None,
                    module.ch_axis,
                    module.group_size,
                    module.qscheme_str_name,
                )
        return X.to(x_dtype)

    def _apply_scale_quantization(self, source_module: Any, scale_module: Any) -> torch.Tensor:
        """Apply scale quantization between modules."""

        if (
            QUARK_DISABLE_COMPILE
            or not TORCH_HIGHER_OR_EQUAL_2_5
            or torch.jit.is_tracing()
            or torch.compiler.is_compiling(  # type: ignore[attr-defined]
            )
            or not source_module.scale.is_contiguous()
        ):
            # torch.onnx.export uses jit.trace by default to get a ScriptModule model, which currently does not supported tracing a dynamo-optimized model.
            # Reference: https://github.com/pytorch/pytorch/blob/v2.7.1/torch/_dynamo/eval_frame.py#L634.
            # In case we compile at a level above, we will obey the high level `torch.compile` parameters and thus does not use the compiled `scaled_fake_quantize` here.
            # In case the input `X` is not contiguous, `torch.compile` has some overhead from `copy_misaligned_inputs` that may make the compiled function
            # slower than eager in some cases. We disable torch.compile by default in this case until further investigation is done.
            fake_quantize = quark.torch.kernel.scaled_fake_quantize  # type: ignore[attr-defined]
        else:
            fake_quantize = quark.torch.kernel.scaled_fake_quantize_compiled  # type: ignore[attr-defined]

        try:
            result = fake_quantize(
                scale_module.dtype.value,
                source_module.scale,
                scale_module.scale,
                scale_module.zero_point.to(torch.int) if scale_module.zero_point is not None else None,
                scale_module.ch_axis,
                scale_module.group_size,
                scale_module.quant_min,
                scale_module.quant_max,
                scale_module.round_method,
                scale_module.qscheme_str_name,
                None,
            )
        except PYTORCH_DYNAMO_RECOMPILE_EXCEPTION as e:  # pragma: no cover
            raise PYTORCH_DYNAMO_RECOMPILE_EXCEPTION(PYTORCH_DYNAMO_RECOMPILE_MESSAGE) from e

        assert isinstance(result, torch.Tensor)  # Runtime check to ensure correct type
        return result

    def _apply_tensor_quantization(self, module: Any, x: torch.Tensor, target_dtype: torch.dtype) -> torch.Tensor:
        """Apply tensor quantization using module parameters."""
        x = quark.torch.kernel.scaled_real_quantize(  # type: ignore[attr-defined]
            module.dtype.value,
            x,
            module.scale,
            module.zero_point.to(torch.int) if module.zero_point is not None else None,
            module.ch_axis,
            module.group_size,
            module.quant_min,
            module.quant_max,
            module.round_method,
            module.qscheme_str_name,
        )
        assert isinstance(x, torch.Tensor)  # Runtime check to ensure correct type
        return x.to(target_dtype)


def enable_or_disable_quantizer(quantizer: FakeQuantizeBase | SequentialQuantize, enable: bool | None = False) -> None:
    quantizers = [quantizer] if isinstance(quantizer, ScaledFakeQuantize) else quantizer
    assert isinstance(quantizers, list)
    for _quantizer in quantizers:
        if enable:
            _quantizer.enable_observer()
            _quantizer.enable_fake_quant()
        else:
            _quantizer.disable_observer()
            _quantizer.disable_fake_quant()
