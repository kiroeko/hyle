#
# Copyright (C) 2023 - 2026 Advanced Micro Devices, Inc. All rights reserved.
# SPDX-License-Identifier: MIT
#

from __future__ import annotations

import os
from abc import abstractmethod
from collections import Counter
from typing import TYPE_CHECKING, Any, cast

import torch
import torch.nn as nn
from torch.ao.quantization import HistogramObserver

import quark.torch.kernel  # noqa

if TYPE_CHECKING:
    from quark.torch.quantization.config.config import QTensorConfig
from quark.common.data_type import BaseObserverBase
from quark.common.utils.import_utils import is_torch_greater_or_equal_2_5
from quark.common.utils.log import ScreenLogger, log_errors
from quark.torch.kernel.hw_emulation.hw_emulation_interface import fake_quantize_int  # type: ignore
from quark.torch.quantization.config.type import Dtype, QSchemeType, ScaleType, ZeroPointType
from quark.torch.quantization.nn.utils import check_min_max_valid
from quark.torch.quantization.utils import (
    calculate_qmin_qmax,
    even_round,
    get_dtype_params,
    reshape_to_blocks,
    t_exponent,
)
from quark.torch.utils.numerics import safe_max, safe_min

logger = ScreenLogger(__name__)


class ObserverBase(BaseObserverBase, nn.Module):
    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__()
        self.dtype = qspec.dtype

        self.qspec = qspec
        self.scale_torch_dtype = None

        # TODO: Remove the usage of `scale_format` throughout Quark codebase and rely solely on `scale_type`
        self.scale_format = qspec.scale_format
        self.scale_calculation_mode = qspec.scale_calculation_mode

        if qspec.scale_type in [ScaleType.float32, ScaleType.float16, ScaleType.bfloat16]:
            self.scale_torch_dtype = qspec.scale_type.to_torch_dtype()

        self._num_observed_tokens: int = 0
        self.quant_max_first_level: float | None = None

    @abstractmethod
    def forward(self, x: torch.Tensor) -> Any:
        pass

    @abstractmethod
    def _calculate_qparams(self) -> Any:
        pass

    @abstractmethod
    def reset_state(self) -> None:
        pass

    def record_observed_tokens(self, batch_tensor: torch.Tensor) -> None:
        """
        Recording the number of tokens observed during the
        calibration process.

        Note: The batch_tensor is expected to have two dimensions
            (batch_size * sequence_length, num_features). This is the
            general shape expected by the forward pass of the expert
            layers in a MOE model. If the input tensor does not have
            two dimensions, the _num_observed_tokens attribute will be set
            to None.
        """
        # Some of the utilies in graph quantization may (for some reason) apply quantizers on 1D or 0D tensors,
        # e.g. in test/test_for_torch/test_fx_quant_align_hw_pow_of_2.py::test_torch_postquant_concat_strategy.
        if batch_tensor.ndim < 2:
            return

        if not isinstance(batch_tensor, torch.Tensor):
            raise ValueError(f"Expected value to be a tensor, got {type(batch_tensor)}")

        # For some models with MoE (e.g., Llama4), the MoE computation is performed by matrix multiplication
        # between the input and the weights of experts. In these models, the routing mechanism selectively assigns
        # tokens to different experts. When the input corresponding to a particular expert is all zeros, it indicates
        # that the token was not routed to that expert, and therefore should not be counted as a valid token for that expert.
        # The code below filters out tokens that were not assigned to the current expert by checking whether each row
        # (corresponding to a token) contains any non-zero elements, thus accurately counting the number of tokens actually
        # processed by this expert.
        batch_tensor = batch_tensor.reshape(-1, batch_tensor.shape[-1])
        row_mask = (batch_tensor != 0).any(dim=1)
        valid_rows = torch.nonzero(row_mask, as_tuple=True)[0]
        observed_tokens = valid_rows.numel()
        self._num_observed_tokens += observed_tokens

    def get_scale(
        self,
        amax: torch.Tensor,
        eps: float,
        scale_format: str,
    ) -> torch.Tensor:
        """
        Calculate scale based on ``amax`` and ``scale_format``.

        :param torch.Tensor amax: Maximum absolute value tensor used for scale calculation.
        :param float eps: Small epsilon value to prevent division by zero.
        :return: Calculated scale tensor.
        """
        if scale_format == "e8m0":
            dtype = self.qspec.dtype if self.qspec.mx_element_dtype is None else self.qspec.mx_element_dtype
            _, _, emax = get_dtype_params(dtype)
            if self.scale_calculation_mode is None or self.scale_calculation_mode == "even":
                scale = even_round(amax, dtype)
            elif self.scale_calculation_mode == "floor":
                # The masked_fill below is load-bearing: torch.log2(0) -> -inf,
                # pow(2, -inf - emax) -> exact 0, which masked_fill then replaces
                # with eps. Do NOT route this through safe_log2 — that would
                # produce a tiny finite scale (~2**(-126-emax)) that slips past
                # the `scale == 0.0` check and breaks test_per_block_simple_scale.
                scale = torch.pow(2, torch.floor(torch.log2(amax)) - emax)
                scale = scale.masked_fill(scale == 0.0, eps)
            elif self.scale_calculation_mode == "ceil":
                scale = torch.pow(2, torch.ceil(torch.log2(amax)) - emax)
                scale = scale.masked_fill(scale == 0.0, eps)
            else:
                raise ValueError(f"Unsupported scale_calculation_mode: {self.scale_calculation_mode}")
        elif scale_format == "e4m3":
            _, quant_max = calculate_qmin_qmax(self.qspec.dtype)
            scale = torch.div(amax, quant_max)
            scale = scale.masked_fill(scale == 0.0, eps)

            # two-level scale
            local_amax = amax.float()
            elem_format_max = quant_max
            global_amax = amax.max().float()
            scale_format_max = 448.0  # FP8E4M3 scale
            local_unscale = local_amax / elem_format_max
            two_level_scale = scale_format_max * (elem_format_max / global_amax)
            scale = (local_unscale * two_level_scale).to(torch.float8_e4m3fn).float() / two_level_scale
            # Output dtype is controlled by self.scale_torch_dtype (set via scale_type config).
            # When scale_type="float32", scale stays in float32; otherwise follows model dtype.
            scale = scale.to(self.scale_torch_dtype)
        elif scale_format == "e5m3":
            # E5M3 format: 5 exponent bits, 3 mantissa bits, no sign bit
            # Compute scale to remap amax to e.g. FP4 max (similar to float32 case).
            _, quant_max = calculate_qmin_qmax(self.qspec.dtype)
            scale = torch.div(amax, quant_max)
            scale = scale.masked_fill(scale == 0.0, eps)

            # TODO: we should be able to call `non_scaled_fake_quantize`, `scaled_fake_quantize`, etc. with named arguments. This is quite ugly!
            scale = quark.torch.kernel.non_scaled_fake_quantize(
                scale,
                "fp8_e5m3",
                "",  # mx_element_dtype
                -1,  # ch_axis
                1,  # group_size=1, i.e. elementwise fake quantization.
                "",  # scale_calculation_mode
            )
        elif scale_format == "float32":
            _, quant_max = calculate_qmin_qmax(self.qspec.dtype)
            # Cast amax to scale_torch_dtype before division to avoid precision loss.
            # When scale_type="float32", this ensures the division is computed in float32
            # rather than the model's native dtype (e.g. BF16).
            amax = amax.to(self.scale_torch_dtype) if self.scale_torch_dtype else amax
            # In sequential quantization (e.g. FP4 with FP8 global scale), use a single
            # division amax / (quant_max_first_level * quant_max) instead of successive
            # divisions amax / quant_max_first_level / quant_max, avoiding intermediate rounding.
            if self.quant_max_first_level is not None:
                divisor = self.quant_max_first_level * quant_max
            else:
                divisor = quant_max

            scale = torch.div(amax, divisor)
            scale = scale.masked_fill(scale == 0.0, eps)
        else:
            raise ValueError(
                f"scale_format must be one of e8m0, e4m3, e5m3, or float32, got scale_format={scale_format}."
            )

        return scale


class PlaceholderObserver(ObserverBase):
    r"""
    Observer only passes its configuration to the quantized module's ``.from_float()``.

    Does not have any calculation.

    Only can be used for quantization to float16 and bfloat16 which doesn't require determining
    ranges.
    """

    def __init__(
        self,
        qspec: QTensorConfig,
        device: torch.device | None = None,
    ) -> None:
        super().__init__(qspec, device)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x

    def _calculate_qparams(self) -> None:
        pass

    def reset_state(self) -> None:
        pass

    def extra_repr(self) -> str:
        return f"dtype={self.dtype}"


class UniformScalingObserver(ObserverBase):
    """
    Observer for uniform scaling quantizer. For example 'int uniform quantizer' or 'fp8 uniform scaling'.

    """

    eps: torch.Tensor
    min_val: torch.Tensor
    max_val: torch.Tensor

    def __init__(
        self, qspec: QTensorConfig, device: torch.device | None = None, eps: float = torch.finfo(torch.float32).eps
    ) -> None:
        super().__init__(qspec, device)

        self.symmetric = qspec.symmetric
        self.scale_type = qspec.scale_type
        self.qscheme = qspec.qscheme
        self.is_dynamic = qspec.is_dynamic
        self.zero_point_type = qspec.zero_point_type

        self.register_buffer("min_val", torch.tensor(float("inf"), device=device), persistent=False)
        self.register_buffer("max_val", torch.tensor(float("-inf"), device=device), persistent=False)
        self.register_buffer("eps", torch.tensor(eps, device=device), persistent=False)

        self.quant_min, self.quant_max = calculate_qmin_qmax(qspec.dtype)

    def _calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:
        r"""Calculates the quantization parameters."""
        return self.calculate_qparams(self.min_val, self.max_val)

    def calculate_qparams(self, min_val: torch.Tensor, max_val: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        r"""Calculates the quantization parameters."""
        if self.dtype in [Dtype.fp8_e4m3, Dtype.fp8_e5m2, Dtype.fp8_e5m3]:
            return self.calculate_fp8_quant_parameters(min_val, max_val)
        elif self.dtype == Dtype.fp4:
            return self.calculate_fp4_quant_parameters(min_val, max_val)
        else:
            return self.calculate_int_quant_params(min_val, max_val)

    def calculate_int_quant_params(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if not check_min_max_valid(min_val, max_val):
            return torch.tensor([1.0], device=min_val.device.type), torch.tensor([0], device=min_val.device.type)

        quant_min, quant_max = self.quant_min, self.quant_max
        assert isinstance(quant_min, int)
        assert isinstance(quant_max, int)
        min_val_neg = torch.clamp(min_val, max=0)
        max_val_pos = torch.clamp(max_val, min=0)

        device = min_val_neg.device
        scale = torch.ones(min_val_neg.size(), dtype=torch.float32, device=device)

        # TODO: This makes the assumption that signed integer dtype is used when doing symmetric quantization. There
        # is no enforcement on that in quark.
        zero_point = torch.zeros(min_val_neg.size(), dtype=torch.int32, device=device)

        if self.symmetric:
            max_val_pos = torch.max(-min_val_neg, max_val_pos)
            scale = max_val_pos / (float(quant_max - quant_min) / 2)
            scale = torch.max(scale, self.eps.to(scale.device))
        else:
            if self.zero_point_type == ZeroPointType.float32:
                scale = (max_val - min_val) / float(quant_max - quant_min)
                scale = torch.where(scale > self.eps, scale, torch.ones_like(scale))
                zero_point = -1 * min_val / scale
            else:
                # AWQ
                scale = (max_val_pos - min_val_neg) / float(quant_max - quant_min)
                scale = torch.max(scale, self.eps.to(scale.device))
                zero_point = quant_min - torch.round(min_val_neg / scale).to(torch.int)
                zero_point = torch.clamp(zero_point, quant_min, quant_max)
        return scale.to(self.scale_torch_dtype), zero_point

    def calculate_fp8_quant_parameters(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        min_val_neg = torch.min(min_val, torch.zeros_like(min_val))
        max_val_pos = torch.max(max_val, torch.zeros_like(max_val))

        self.eps = self.eps.to(min_val.dtype).to(min_val.device)
        amax = torch.maximum(torch.abs(min_val_neg), torch.abs(max_val_pos))

        scale = self.get_scale(
            amax=amax,
            eps=self.eps,
            scale_format="float32",
        )
        # TODO: We should just use `zero_point = None` here - not allocating unnecessary memory.
        zero_point = torch.zeros_like(scale)

        return scale.to(self.scale_torch_dtype), zero_point

    def calculate_fp4_quant_parameters(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        min_val_neg = torch.min(min_val, torch.zeros_like(min_val))
        max_val_pos = torch.max(max_val, torch.zeros_like(max_val))

        amax = torch.maximum(torch.abs(min_val_neg), torch.abs(max_val_pos))

        scale = self.get_scale(amax=amax, eps=self.eps, scale_format=self.scale_format)
        # TODO: We should just use `zero_point = None` here - not allocating unnecessary memory.
        zero_point = torch.zeros_like(scale)

        return scale.masked_fill(scale == 0.0, torch.finfo(torch.float32).eps).to(self.scale_torch_dtype), zero_point

    def extra_repr(self) -> str:
        return f"min_val={self.min_val}, max_val={self.max_val}"

    def reset_state(self) -> None:
        self.reset_min_max_vals()

    def reset_min_max_vals(self) -> None:
        """Resets the min/max values."""
        self.min_val = torch.tensor(float("inf"))
        self.max_val = torch.tensor(float("-inf"))

    # NOTE this class should not be instance, so we set to abs class
    @abstractmethod
    def forward(self, x: torch.Tensor) -> Any:
        pass


class PerTensorMinMaxObserver(UniformScalingObserver):
    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec, device)

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        r"""Records the running minimum and maximum of ``x``."""
        if x_orig.numel() == 0:
            return x_orig

        x = x_orig.detach()  # avoid keeping autograd tape
        min_val, max_val = torch.aminmax(x)

        if not self.is_dynamic:
            min_val = torch.min(min_val, self.min_val)
            max_val = torch.max(max_val, self.max_val)

        self.min_val.copy_(min_val)
        self.max_val.copy_(max_val)

        self.min_val = self.min_val.to(x_orig.dtype)
        self.max_val = self.max_val.to(x_orig.dtype)
        return x_orig


class PerTensorPowOf2MinMaxObserver(PerTensorMinMaxObserver):
    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec, device)
        if qspec.dtype not in [Dtype.int8, Dtype.uint8, Dtype.int32]:
            raise ValueError(
                f"PerTensorPowOf2MinMaxObserver only supports int8, uint8, and int32 dtypes, got {qspec.dtype}."
            )

        self.record_scale: list[float] = []
        self.record_zp: list[float] = []

    def _scale2pos(self, scale: torch.Tensor) -> torch.Tensor:
        """
        Ref: quark/onnx/quant_utils.py scale2pos
        """
        target_device = scale.device
        scale = min(max(scale.item(), float(2**-127)), float(2**127))
        return torch.round(-torch.log2(torch.tensor(scale))).to(device=target_device)

    def _pos2scale(self, pos: torch.Tensor) -> torch.Tensor:
        """
        Ref: quark/onnx/quant_utils.py pos2scale
        """
        return torch.pow(2.0, -pos)

    def _calculate_one_batch_quant_param(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # ref: quark/onnx/quant_utils.py: compute_scale_zp
        self.eps = self.eps.to(min_val.dtype).to(min_val.device)

        if not check_min_max_valid(min_val, max_val):
            return torch.tensor([1.0], device=min_val.device.type), torch.tensor([0], device=min_val.device.type)

        quant_min, quant_max = self.quant_min, self.quant_max  # e.g -128, 127
        assert isinstance(quant_min, int)
        assert isinstance(quant_max, int)
        min_val_neg = torch.min(min_val, torch.zeros_like(min_val))
        max_val_pos = torch.max(max_val, torch.zeros_like(max_val))
        # quantize range
        if self.symmetric:
            abs_max = torch.max(min_val_neg.abs(), max_val_pos.abs())
            min_val_neg = -1 * abs_max
            max_val_pos = 1 * abs_max

        dr = max_val_pos - min_val_neg
        dq = quant_max - quant_min
        scale = dr / dq if dr != 0 else torch.tensor(1.0, dtype=torch.float32)
        assert scale > 0, "scale should larger than 0, please check"
        zero_point = torch.tensor(quant_min - min_val_neg / scale).to(dtype=torch.int32)

        pos = self._scale2pos(scale)
        pof2_scale = self._pos2scale(pos)
        new_rmin = torch.min((quant_min - zero_point) * pof2_scale, torch.tensor(0, dtype=torch.int32))
        new_zero_point = torch.round(quant_min - new_rmin / pof2_scale).to(dtype=torch.int32)
        # TODO refine other dtype haoliang
        if self.symmetric and self.qspec.dtype == Dtype.uint8 and new_zero_point.item() == 127:  # [0, 255]
            new_zero_point = torch.tensor(128, dtype=torch.int32)
        return pof2_scale.to(self.scale_torch_dtype), new_zero_point

    def calculate_int_quant_params(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        device = min_val.device
        one_batch_scale, one_batch_zero_point = self._calculate_one_batch_quant_param(min_val, max_val)
        self.record_scale.append(one_batch_scale.item())
        self.record_zp.append(one_batch_zero_point.item())

        # select the most common scale & zp
        matrix = torch.tensor([self.record_scale, self.record_zp])
        columns = matrix.T
        keys = [tuple(col.tolist()) for col in columns]
        counter = Counter(keys)
        most_common_key, count = counter.most_common(1)[0]

        po2_scale = torch.tensor(most_common_key[0]).to(device)
        zero_point = torch.tensor(most_common_key[1]).to(device)
        return po2_scale, zero_point

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        r"""Records the running minimum and maximum of ``x``."""
        x = super().forward(x_orig)
        return x


class PerTensorPowOf2MinMSEObserver(PerTensorPowOf2MinMaxObserver):
    """
    MINMSE method to get the the proper scale for target input tensor
    More ref: Quark/quark/onnx/quant_utils.py func: quantize_data
    """

    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec, device)
        self.original_tensor: torch.Tensor | None = (
            None  # not use `register_buffer`, as this function will save dict, waist disk space
        )
        self.pos_range = 5
        self.compute_device = "cpu"

    def _fake_quantize_data(self, data: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
        cliplow, cliphigh = self.quant_min, self.quant_max
        arr_fp32 = torch.round(data / scale) + zero_point
        clip_tensor = torch.clamp(arr_fp32, min=cliplow, max=cliphigh)
        return clip_tensor

    def _fake_dequantize_data(self, data: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
        deq_tensor = (data - zero_point) * scale
        return deq_tensor

    def _calculate_one_batch_quant_param(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        assert self.original_tensor is not None
        # ref: quark/onnx/quant_utils.py quantize_data
        # Step 1, give a initial power of 2 scale
        scale, zero_point = PerTensorPowOf2MinMaxObserver._calculate_one_batch_quant_param(self, min_val, max_val)
        scale_device = scale.device
        # Step 2, find the best through the MSE TODO
        # NOTE move to cpu to compute
        scale = scale.to(device=self.compute_device)
        zero_point = zero_point.to(device=self.compute_device)  # NOTE will not change
        data = self.original_tensor
        scale_mse = scale
        diff_min = float("inf")
        for i in range(self.pos_range):
            new_scale = self._pos2scale(self._scale2pos(scale) + i - 2)
            new_quantized_data = self._fake_quantize_data(data, scale=new_scale, zero_point=zero_point)
            new_data = self._fake_dequantize_data(new_quantized_data, new_scale, zero_point=zero_point)
            diff = torch.pow(new_data - data, 2).sum().item()
            if diff < diff_min:
                diff_min = diff
                scale_mse = new_scale
        # # NOTE used for debug
        # rmin_mse = (self.quant_min - zero_point) * scale_mse # NOTE
        # rmax_mse = (self.quant_max - zero_point) * scale_mse

        # NOTE after using self.original_tensor we can free self.original_tensor
        self.original_tensor = None  # to save memory
        return scale_mse.to(scale_device), zero_point.to(scale_device)

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        """
        collect alll the original tensor, we then perform mes to calculate the best scale
        """
        if x_orig.numel() == 0:
            return x_orig
        _ = super().forward(x_orig)  # this will init the min & max val
        x = x_orig.detach().to(self.compute_device)  # avoid keeping autograd tape
        self.original_tensor = x
        return x_orig


class PerChannelMinMaxObserver(UniformScalingObserver):
    def __init__(
        self, qspec: QTensorConfig, device: torch.device | None = None, eps: float = torch.finfo(torch.float32).eps
    ) -> None:
        super().__init__(qspec, device)

        self.ch_axis = qspec.ch_axis

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        return self._forward(x_orig)

    @log_errors
    def _forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        x_orig_device = x_orig.device
        if x_orig.numel() == 0:
            return x_orig
        x = x_orig.detach()  # avoid keeping autograd tape

        x_dim = x.size()

        if self.min_val.device != x_orig_device:
            self.min_val = self.min_val.to(x_orig_device)
            self.max_val = self.max_val.to(x_orig_device)

        new_axis_list = [i for i in range(len(x_dim))]  # noqa: C416
        if self.ch_axis is not None:
            new_axis_list[self.ch_axis] = 0
        else:
            raise ValueError("ch_axis cannot be None")
        new_axis_list[0] = self.ch_axis
        y = x.permute(new_axis_list)
        y = y.unsqueeze(-1) if y.dim() == 1 else y  # if y is bias, usually bias has shape [n]
        # Need to match dtype of min/max because the updates to buffers
        # are done in place and types need to match for comparisons
        y = y.to(self.min_val.dtype)
        y = torch.flatten(y, start_dim=1)

        min_val, max_val = torch.aminmax(y, dim=1)

        if not self.is_dynamic:
            if self.min_val.numel() == min_val.numel() and self.min_val.numel() == max_val.numel():
                min_val = torch.minimum(self.min_val, min_val)
                max_val = torch.maximum(self.max_val, max_val)

        self.min_val.resize_(min_val.shape)
        self.max_val.resize_(max_val.shape)
        self.min_val.copy_(min_val)
        self.max_val.copy_(max_val)

        input_origin_type = x_orig.dtype
        self.min_val = self.min_val.to(input_origin_type)
        self.max_val = self.max_val.to(input_origin_type)
        return x_orig

    def reset_state(self) -> None:
        self.reset_min_max_vals()

    def reset_min_max_vals(self) -> None:  # TODO
        """Resets the min/max values."""
        if not hasattr(self, "min_val") or not hasattr(self, "max_val"):
            raise RuntimeError("PerChannelMinMaxObserver has no attribute 'min_val' or 'max_val'.")
        self.min_val = torch.tensor(float("inf"))
        self.max_val = torch.tensor(float("-inf"))


class PerChannelPowOf2MinMaxObserver(PerChannelMinMaxObserver):
    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec, device)
        if qspec.dtype not in [Dtype.int8, Dtype.uint8, Dtype.int32]:
            raise ValueError(
                f"PerChannelPowOf2MinMaxObserver only supports int8, uint8, and int32 dtypes, got {qspec.dtype}."
            )

        self.record_scale_zp: list[torch.Tensor] = []
        self.compute_device = "cpu"

    def _scale2pos(self, scale: torch.Tensor) -> torch.Tensor:
        """
        Ref: quark/onnx/quant_utils.py scale2pos
        """
        target_device = scale.device
        scale = torch.clamp(scale, min=float(2**-127), max=float(2**127))
        return torch.round(-torch.log2(scale)).to(device=target_device)

    def _pos2scale(self, pos: torch.Tensor) -> torch.Tensor:
        """
        Ref: quark/onnx/quant_utils.py pos2scale
        """
        return torch.pow(2.0, -pos)

    def _calculate_one_batch_quant_param(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # ref: quark/onnx/quant_utils.py: compute_scale_zp
        self.eps = self.eps.to(min_val.dtype).to(min_val.device)

        if not check_min_max_valid(min_val, max_val):
            return torch.tensor([1.0], device=min_val.device.type), torch.tensor([0], device=min_val.device.type)

        quant_min, quant_max = self.quant_min, self.quant_max  # e.g -128, 127
        assert isinstance(quant_min, int)
        assert isinstance(quant_max, int)
        min_val_neg = torch.min(min_val, torch.zeros_like(min_val))
        max_val_pos = torch.max(max_val, torch.zeros_like(max_val))
        # quantize range
        if self.symmetric:
            abs_max = torch.max(min_val_neg.abs(), max_val_pos.abs())
            min_val_neg = -1 * abs_max
            max_val_pos = 1 * abs_max

        dr = max_val_pos - min_val_neg
        dq = quant_max - quant_min
        scale = dr / dq
        # scale = dr / dq if dr != 0 else torch.ones(min_val.size(), dtype=torch.float32)
        # assert scale > 0, "scale should larger than 0, please check"
        # NOTE asser 0
        zero_point = torch.tensor(quant_min - min_val_neg / scale).to(dtype=torch.int32)

        pos = self._scale2pos(scale)
        pof2_scale = self._pos2scale(pos)
        new_rmin = torch.min((quant_min - zero_point) * pof2_scale, torch.zeros_like(min_val, dtype=torch.int32))
        new_zero_point = torch.round(quant_min - new_rmin / pof2_scale).to(dtype=torch.int32)
        # TODO refine other dtype haoliang
        if self.symmetric and self.qspec.dtype == Dtype.uint8 and torch.all(new_zero_point == 127):  # [0, 255]
            new_zero_point = torch.full_like(zero_point, 128, dtype=torch.int32)
        return pof2_scale.to(self.scale_torch_dtype), new_zero_point

    def calculate_int_quant_params(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        device = min_val.device
        one_batch_scale, one_batch_zero_point = self._calculate_one_batch_quant_param(min_val, max_val)
        cat_scale_zp = torch.cat([one_batch_scale, one_batch_zero_point])
        self.record_scale_zp.append(cat_scale_zp.to(device=self.compute_device))
        scale_size = int(cat_scale_zp.size()[0] / 2)
        # select the most common scale & zp
        tensor_tuples = [tuple(tensor.tolist()) for tensor in self.record_scale_zp]
        counter = Counter(tensor_tuples)

        most_common_tensor, freq = counter.most_common(1)[0]

        po2_scale = torch.tensor(most_common_tensor[:scale_size]).to(device)
        zero_point = torch.tensor(most_common_tensor[scale_size:], dtype=torch.int32).to(device).to()
        return po2_scale, zero_point

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        r"""Records the running minimum and maximum of ``x``."""
        x = super().forward(x_orig)
        return x


class PerChannelPowOf2MinMSEObserver(PerChannelPowOf2MinMaxObserver):
    """
    MINMSE method to get the the proper scale for target input tensor
    More ref: Quark/quark/onnx/quant_utils.py func: quantize_data
    """

    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec, device)
        self.original_tensor: torch.Tensor | None = (
            None  # not use `register_buffer`, as this function will save dict, waist disk space
        )
        self.pos_range = 5
        self.compute_device = "cpu"

    def _fake_quantize_data(self, data: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
        cliplow, cliphigh = self.quant_min, self.quant_max
        scale_shape = [1 for _ in range(data.dim())]
        assert isinstance(self.ch_axis, int)
        scale_shape[self.ch_axis] = scale.numel()

        arr_fp32 = torch.round(data / scale.view(scale_shape)) + zero_point.view(scale_shape)
        clip_tensor = torch.clamp(arr_fp32, min=cliplow, max=cliphigh)
        return clip_tensor

    def _fake_dequantize_data(self, data: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
        scale_shape = [1 for _ in range(data.dim())]
        assert isinstance(self.ch_axis, int)
        scale_shape[self.ch_axis] = scale.numel()
        deq_tensor = (data - zero_point.view(scale_shape)) * scale.view(scale_shape)
        return deq_tensor

    def _calculate_one_batch_quant_param(
        self, min_val: torch.Tensor, max_val: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        assert self.original_tensor is not None
        # ref: quark/onnx/quant_utils.py quantize_data
        # Step 1, give a initial power of 2 scale
        scale, zero_point = PerChannelPowOf2MinMaxObserver._calculate_one_batch_quant_param(self, min_val, max_val)
        scale_device = scale.device
        # Step 2, find the best through the MSE
        # NOTE move to cpu to compute
        scale = scale.to(device=self.compute_device)
        zero_point = zero_point.to(device=self.compute_device)  # NOTE will not change
        data = self.original_tensor
        scale_mse = scale
        diff_min = float("inf")
        for i in range(self.pos_range):
            new_scale = self._pos2scale(self._scale2pos(scale) + i - 2)
            new_quantized_data = self._fake_quantize_data(data, scale=new_scale, zero_point=zero_point)
            new_data = self._fake_dequantize_data(new_quantized_data, new_scale, zero_point=zero_point)
            diff = torch.pow(new_data - data, 2).sum().item()
            if diff < diff_min:
                diff_min = diff
                scale_mse = new_scale
        # # NOTE used for debug
        # rmin_mse = (self.quant_min - zero_point) * scale_mse
        # rmax_mse = (self.quant_max - zero_point) * scale_mse

        # NOTE after using self.original_tensor we can free self.original_tensor
        self.original_tensor = None  # to save memory
        return scale_mse.to(scale_device), zero_point.to(scale_device)

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        """
        collect alll the original tensor, we then perform mes to calculate the best scale
        """
        if x_orig.numel() == 0:
            return x_orig
        _ = super().forward(x_orig)  # this will init the min & max val
        x = x_orig.detach().to(self.compute_device)  # avoid keeping autograd tape
        self.original_tensor = x
        return x_orig


class PerBlockMXObserver(ObserverBase):
    def __init__(
        self, qspec: QTensorConfig, device: torch.device | None = None, eps: float = torch.finfo(torch.float32).eps
    ) -> None:
        super().__init__(qspec=qspec, device=device)
        assert self.qspec.dtype in [Dtype.fp4, Dtype.fp8_e4m3, Dtype.fp8_e5m2, Dtype.fp6_e2m3, Dtype.fp6_e3m2]
        assert qspec.group_size is not None
        assert qspec.ch_axis is not None

        self.block_size = qspec.group_size
        self.axis = qspec.ch_axis
        self.mx_element_dtype = qspec.mx_element_dtype
        self.eps = eps
        self.is_dynamic = qspec.is_dynamic
        self.amax = torch.tensor(0.0, dtype=torch.float)

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        block_x = reshape_to_blocks(x_orig, self.block_size, self.axis)
        amax, _ = torch.max(torch.abs(block_x), dim=-1, keepdim=True)
        amax = amax.squeeze(-1)
        if self.is_dynamic:
            self.amax = amax
        else:
            if self.amax.shape != amax.shape and self.amax.dim() > 0:
                self.amax = torch.tensor(0.0, dtype=torch.float32)
            self.amax = torch.max(self.amax, amax)

        return x_orig

    def calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:
        if self.scale_format in ["e8m0", "e4m3", "e5m3", "float32"]:
            scale = self.get_scale(
                amax=self.amax,
                eps=self.eps,
                scale_format=self.scale_format,
            )
        else:
            # TODO: there is no test covering this case.
            # TODO: Most likely should be removed.
            scale = t_exponent(self.amax)  # pragma: no cover

        # TODO: We should just use `zero_point = None` here - not allocating unnecessary memory.
        zero_point = torch.zeros_like(scale)

        scale = scale.to(self.scale_torch_dtype)
        return scale, zero_point

    def _calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:
        return self.calculate_qparams()

    def reset_state(self) -> None:
        self.reset_min_max_vals()

    def reset_min_max_vals(self) -> None:
        """Resets the amax values."""
        if not hasattr(self, "amax"):
            raise RuntimeError("PerBlockMXObserver has no attribute 'amax'.")
        self.amax = torch.tensor(0.0)


class PerBlockMXBufferReuseObserver(PerBlockMXObserver):
    """Per-block MX observer using reusable device buffers for memory efficiency."""

    _device_buffers: dict[str, dict[str, Any]] = {}
    _gpu_stats: dict[str, dict[str, int]] = {}

    def __init__(
        self, qspec: QTensorConfig, device: torch.device | None = None, eps: float = torch.finfo(torch.float32).eps
    ) -> None:
        super().__init__(qspec=qspec, device=device, eps=eps)
        self.max_input_numel: int = getattr(qspec, "max_input_numel", 16 * 1024 * 1024)
        self.buffer_reuse_debug: bool = os.environ.get("QUARK_BUFFER_REUSE_DEBUG", "0") == "1"

    @classmethod
    def _allocate_buffers(cls, block_shape: tuple[int, int, int], device: torch.device) -> None:
        """Pre-allocate reusable buffers for the given shape and device."""
        device_str = str(device)

        cls._device_buffers[device_str] = {
            "block_x": torch.empty(block_shape, device=device, dtype=torch.float32),
            "amax": torch.empty((block_shape[0], block_shape[1], 1), device=device, dtype=torch.float32),
            "shape": block_shape,
        }

        if device_str not in cls._gpu_stats:
            cls._gpu_stats[device_str] = {"reuse_count": 0, "total_bytes": 0, "call_count": 0}

        block_bytes = block_shape[0] * block_shape[1] * block_shape[2] * 4
        amax_bytes = block_shape[0] * block_shape[1] * 4
        total_bytes = block_bytes + amax_bytes
        cls._gpu_stats[device_str]["total_bytes"] = total_bytes

    @classmethod
    def _can_use_buffers(cls, block_shape: tuple[int, int, int], device: torch.device) -> bool:
        device_str = str(device)
        if device_str not in cls._device_buffers:
            return False

        buffer_shape = cls._device_buffers[device_str]["shape"]
        return all(current <= max_size for current, max_size in zip(block_shape, buffer_shape, strict=False))

    @classmethod
    def _print_stats(cls, device: torch.device) -> None:
        device_str = str(device)
        if device_str in cls._gpu_stats:
            stats = cls._gpu_stats[device_str]
            reuse_rate = (stats["reuse_count"] / stats["call_count"] * 100) if stats["call_count"] > 0 else 0
            total_mb = stats["total_bytes"] / (1024 * 1024)
            logger.info(
                f"[PerBlockMXBufferReuseObserver Stats - {device_str}] "
                f"Calls: {stats['call_count']}, "
                f"Buffer Reuses: {stats['reuse_count']} ({reuse_rate:.1f}%), "
                f"Total Buffer Memory: {total_mb:.2f} MB"
            )
            if torch.cuda.is_available():
                logger.info(torch.cuda.memory_summary(device=None, abbreviated=False))

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        device_str = str(x_orig.device)
        if device_str not in self._gpu_stats:
            self._gpu_stats[device_str] = {"reuse_count": 0, "total_bytes": 0, "call_count": 0}
        self._gpu_stats[device_str]["call_count"] += 1

        shape_list = list(x_orig.shape)
        shape_list[self.axis], shape_list[-1] = shape_list[-1], shape_list[self.axis]

        flat_size = 1
        for i in range(len(shape_list) - 1):
            flat_size *= shape_list[i]
        last_dim = shape_list[-1]

        num_elem_to_be_padded = self.block_size - last_dim % self.block_size
        if num_elem_to_be_padded == self.block_size:
            num_elem_to_be_padded = 0
        padded_last_dim = last_dim + num_elem_to_be_padded

        num_blocks = padded_last_dim // self.block_size
        block_shape = (flat_size, num_blocks, self.block_size)

        block_numel = block_shape[0] * block_shape[1] * block_shape[2]
        within_range = block_numel <= self.max_input_numel
        if not within_range:
            return super().forward(x_orig)

        if not self._can_use_buffers(block_shape, x_orig.device):
            self._allocate_buffers(block_shape, x_orig.device)
        else:
            self._gpu_stats[device_str]["reuse_count"] += 1

        device_buffers = self._device_buffers[device_str]
        block_work_view = device_buffers["block_x"][: block_shape[0], : block_shape[1], : block_shape[2]]
        amax_view = device_buffers["amax"][: block_shape[0], : block_shape[1], :]

        x_t = x_orig.transpose(self.axis, -1)
        x_2d = x_t.reshape(-1, last_dim)

        if num_elem_to_be_padded > 0:
            block_x_2d = block_work_view.reshape(flat_size, padded_last_dim)
            block_x_2d[:, :last_dim].copy_(x_2d)
            block_x_2d[:, last_dim:].zero_()
        else:
            block_work_view.copy_(x_2d.reshape(block_shape))

        torch.abs(block_work_view, out=block_work_view)
        torch.amax(block_work_view, dim=-1, keepdim=True, out=amax_view)
        amax = amax_view.squeeze(-1)

        if x_orig.dtype != torch.float32:
            amax = amax.to(x_orig.dtype)

        if self.is_dynamic:
            if self.amax.shape == amax.shape:
                self.amax.copy_(amax)
            else:
                self.amax = amax.clone()
        else:
            if self.amax.shape != amax.shape and self.amax.dim() > 0:
                self.amax = torch.tensor(0.0, dtype=torch.float32)
            if self.amax.shape == amax.shape and self.amax.dim() > 0:
                torch.maximum(self.amax, amax, out=self.amax)
            else:
                self.amax = torch.max(self.amax, amax)

        if self.buffer_reuse_debug and self._gpu_stats[device_str]["call_count"] % 1000 == 1:
            self._print_stats(x_orig.device)

        return x_orig


class PerBlockMXDiffsObserver(PerBlockMXObserver):
    def __init__(
        self,
        qspec: QTensorConfig,
        device: torch.device | None = None,
        eps: float = torch.finfo(torch.float32).eps,
        scope: int = 1,
    ) -> None:
        super().__init__(qspec=qspec, device=device, eps=eps)
        self.quant_min, self.quant_max = calculate_qmin_qmax(self.qspec.dtype)
        self.round_method = getattr(self.qspec.round_method, "value", None)
        self.qscheme_str_name = getattr(self.qspec.qscheme, "value", None)
        self.scope = scope
        self.mx_element_dtype_value = "None" if self.mx_element_dtype is None else self.mx_element_dtype.value
        self.mx_dtype = self.mx_element_dtype if self.mx_element_dtype is not None else self.qspec.dtype

    def calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:
        _, _, emax = get_dtype_params(self.mx_dtype)
        init_scale = torch.ceil(torch.log2(self.amax)) - emax
        best_scale = init_scale.clone()

        block_x = reshape_to_blocks(self.last_x, self.block_size, self.axis)
        best_diffs = torch.full(init_scale.shape, float("inf"), device=self.last_x.device)

        for scale_offset in range(0, -self.scope - 1, -1):
            test_scales = init_scale + scale_offset
            scale_factors = torch.pow(2.0, test_scales)
            zero_points = torch.zeros_like(scale_factors)

            # Quantize entire tensor at once using per-group quantization
            quantized = quark.torch.kernel.scaled_fake_quantize(  # type: ignore[attr-defined]
                self.dtype.value,
                self.last_x,
                scale_factors,
                zero_points.to(torch.int),
                self.axis,
                self.block_size,
                self.quant_min,
                self.quant_max,
                self.round_method,
                self.qscheme_str_name,
                self.mx_element_dtype_value,
            )
            block_quantized = reshape_to_blocks(quantized, self.block_size, self.axis)

            # Calculate MSE for all blocks at once
            diffs = torch.sum((block_x - block_quantized) ** 2, dim=-1)

            # Update best_scale only where new diff is better
            better_mask = diffs < best_diffs
            best_scale = torch.where(better_mask, test_scales, best_scale)
            best_diffs = torch.minimum(diffs, best_diffs)

        self.scale = torch.pow(2.0, torch.tensor(best_scale, device=self.amax.device))
        self.scale = self.scale.masked_fill(self.scale == 0.0, self.eps)
        self.zero_point = torch.zeros_like(self.scale)
        return self.scale, self.zero_point

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        # Store input for diffs calculation
        self.last_x = x_orig.detach()
        return super().forward(x_orig)


class PerBlockBFPObserver(ObserverBase):
    def __init__(
        self, qspec: QTensorConfig, device: torch.device | None = None, eps: float = torch.finfo(torch.float32).eps
    ) -> None:
        super().__init__(qspec=qspec, device=device)
        self.block_size = qspec.group_size
        self.axis = qspec.ch_axis
        self.eps = eps
        self.is_dynamic = qspec.is_dynamic
        self.amax = torch.tensor(0.0, dtype=torch.float)

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        block_x = reshape_to_blocks(x_orig.detach(), self.block_size, self.axis)  # type: ignore
        block_x = block_x.nan_to_num(nan=0.0, posinf=0.0, neginf=0.0)
        amax, _ = torch.max(torch.abs(block_x), dim=-1)
        if self.is_dynamic:
            self.amax = amax
        else:
            self.amax = torch.max(self.amax, amax)
        scale, zero_point = self.calculate_qparams()
        quantized_block_x_int = fake_quantize_int(
            inputs=block_x,
            scale=scale,
            zero_point=zero_point,
            axis=-1,
            group_size=self.block_size,
            quant_min=-129,
            quant_max=128,
            qscheme=QSchemeType.per_group.value,
        ) / scale.unsqueeze(-1)
        bool_mask = torch.logical_or(quantized_block_x_int >= 128, quantized_block_x_int < -128)
        scale_adjust = torch.pow(2, torch.any(bool_mask, dim=-1).to(torch.float32))
        self.amax *= scale_adjust
        return x_orig

    # TODO: there is no test covering this method.
    def calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:  # pragma: no cover
        scale = torch.pow(2, torch.floor(torch.log2(self.amax)) - 6)
        scale = scale.masked_fill(scale == 0.0, self.eps)
        scale = scale.to(self.scale_torch_dtype)
        zero_point = torch.zeros_like(scale).to(torch.int32)
        return scale, zero_point

    def _calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:
        return self.calculate_qparams()

    def reset_state(self) -> None:
        self.reset_min_max_vals()

    def reset_min_max_vals(self) -> None:
        """Resets the min/max values."""
        self.min_val = torch.tensor(float("inf"))
        self.max_val = torch.tensor(float("-inf"))


class PerGroupMinMaxObserver(UniformScalingObserver):
    def __init__(
        self, qspec: QTensorConfig, device: torch.device | None = None, eps: float = torch.finfo(torch.float32).eps
    ) -> None:
        super().__init__(qspec, device)

        self.ch_axis = cast(int, qspec.ch_axis)
        self.group_size = cast(int, qspec.group_size)
        self.group_count = 1  # Set default value

        # NOTE: per-group static quantization is only supported for weights (that are static per definition) in QLayerConfig, hence no special handling required for static quantization here.

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        return self._forward(x_orig)

    def _forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        x_orig_device = x_orig.device
        if x_orig.numel() == 0:
            return x_orig
        x = x_orig.detach()  # avoid keeping autograd tape

        x_dim = x.size()

        if self.min_val.device != x_orig_device:
            self.min_val = self.min_val.to(x_orig_device)
            self.max_val = self.max_val.to(x_orig_device)

        # Get group_count, group_count * group_size = dim_of_axis
        x_group_channel_element_num = x_dim[self.ch_axis]
        if self.group_size == -1:
            self.group_count = 1
        elif x_group_channel_element_num % self.group_size != 0:
            raise ValueError(
                f"The number of element per dimension ch_axis={self.ch_axis} is {x_group_channel_element_num} which is not divisible by group_size={self.group_size}. The `group_size` used should be updated in the QTensorConfig."
            )
        else:
            self.group_count = x_group_channel_element_num // self.group_size

        # Transpose the dim of ch_axis and the end dim of the tensor.
        new_axis_list = [i for i in range(len(x_dim))]  # noqa: C416
        if self.ch_axis is not None:
            new_axis_list[self.ch_axis] = -1
        else:
            raise ValueError("ch_axis cannot be None")
        new_axis_list[-1] = self.ch_axis
        if self.group_size is not None:
            x = x.permute(new_axis_list)
            if self.group_size > 0:
                x = x.reshape(-1, self.group_size)
        else:
            raise ValueError("group_size cannot be None")

        min_val, max_val = torch.aminmax(x, dim=1)

        self.min_val.resize_(min_val.shape)
        self.max_val.resize_(max_val.shape)
        self.min_val.copy_(min_val)
        self.max_val.copy_(max_val)

        input_origin_type = x_orig.dtype
        self.min_val = self.min_val.to(input_origin_type)
        self.max_val = self.max_val.to(input_origin_type)
        return x_orig

    def calculate_qparams(self, min_val: torch.Tensor, max_val: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        r"""Calculates the quantization parameters."""
        if self.dtype in [Dtype.fp8_e4m3, Dtype.fp8_e5m2, Dtype.fp8_e5m3]:
            _scale, _zero_point = super().calculate_fp8_quant_parameters(min_val, max_val)
        else:
            _scale, _zero_point = super().calculate_int_quant_params(min_val, max_val)
        _scale = _scale.reshape(-1, self.group_count)
        _zero_point = _zero_point.reshape(-1, self.group_count)
        return _scale, _zero_point


class PerBlock2DMinMaxObserver(UniformScalingObserver):
    """Placeholder observer for 2D per-block quantization (e.g. FP8 per_block with block_size=[128, 128]).

    Currently Quark does not perform per_block calibration on tensors at runtime.
    This class exists so that ``QTensorConfig`` with ``qscheme=per_block`` can reference
    a valid observer_cls (used during export config generation for pre-quantized layers).

    If per_block calibration is needed in the future, implement ``forward()`` to divide
    the input into 2D blocks of shape ``(block_size[0], block_size[1])`` and compute
    per-block min/max statistics.
    """

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError(
            "PerBlock2DMinMaxObserver does not support calibration yet. "
            "It is currently only used as a config placeholder for pre-quantized layer export."
        )


class PerTensorHistogramObserver(UniformScalingObserver):
    calib_bin_edges: torch.Tensor
    calib_hist: torch.Tensor

    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec)

        self.register_buffer("calib_bin_edges", torch.tensor([], device=device), persistent=False)
        self.register_buffer("calib_hist", torch.tensor([], device=device), persistent=False)

        # TODO: make the value can be set
        self._skip_zeros = False
        self._num_bins = 2048

    def forward(self, x_orig: torch.Tensor) -> torch.Tensor:
        """
        Records the running histogram of ``x_orig``.

        Raises:
        - ValueError: If the `self.symmetric` argument is False.

        """
        self.device = x_orig.device
        x = x_orig.detach()  # avoid keeping autograd tape
        x = x.float()

        with torch.no_grad():
            if self._skip_zeros:
                x = x[torch.where(x != 0)]

            assert isinstance(x, torch.Tensor)
            # safe_max/safe_min guard against the all-zero + skip_zeros path where
            # x is empty; without them .max()/.min() would raise RuntimeError.
            if self.symmetric is not None and self.symmetric is False:
                x_max = safe_max(x)
                x_min = safe_min(x)
            else:
                if x.numel() > 0 and torch.min(x) < 0.0:
                    x = x.abs()
                x_max = safe_max(x)
                x_min = 0.0

            # Constant-valued input (x_min == x_max) would make torch.histc /
            # linspace degenerate. Nudge x_max enough that linspace produces
            # strictly increasing bins in fp32 — the gap between consecutive
            # fp32 values near |x_min| is |x_min| * eps_fp32, so the span must
            # exceed num_bins * |x_min| * eps_fp32 to avoid bin collisions.
            if x_min == x_max:
                eps_fp32 = torch.finfo(torch.float32).eps
                span = max(abs(x_min), 1.0) * self._num_bins * eps_fp32
                x_max = x_min + max(span, torch.finfo(torch.float32).tiny)

            if self.calib_bin_edges.nelement() == 0 and self.calib_hist.nelement() == 0:
                self.calib_hist = torch.histc(x, bins=self._num_bins, min=x_min, max=x_max)
                self.calib_bin_edges = torch.linspace(x_min, x_max, self._num_bins + 1)
            else:
                if x_min < self.calib_bin_edges[0]:
                    width = (self.calib_bin_edges[1] - self.calib_bin_edges[0]).item()
                    self._num_bins += int(((self.calib_bin_edges[0] - x_min) / width).ceil().item())
                    self.calib_bin_edges = torch.arange(
                        x_min - width, self.calib_bin_edges[-1].item(), width, device=x.device
                    )
                if x_max > self.calib_bin_edges[-1]:
                    width = (self.calib_bin_edges[1] - self.calib_bin_edges[0]).item()
                    self._num_bins += int(((x_max - self.calib_bin_edges[-1]) / width).ceil().item())
                    self.calib_bin_edges = torch.arange(
                        self.calib_bin_edges[0].item(), x_max + width, width, device=x.device
                    )
                assert x_max <= self.calib_bin_edges[-1]
                assert x_min >= self.calib_bin_edges[0]

                hist = torch.histc(
                    x, bins=self._num_bins, min=self.calib_bin_edges[0].item(), max=self.calib_bin_edges[-1].item()
                )
                hist[: self.calib_hist.numel()] += self.calib_hist
                self.calib_hist = hist

            assert isinstance(self.calib_hist, torch.Tensor)
            assert isinstance(self.calib_bin_edges, torch.Tensor)
            self.calib_hist = self.calib_hist.to(self.device)
            self.calib_bin_edges = self.calib_bin_edges.to(self.device)

        return x_orig


class PerTensorHistogramObserverPro(UniformScalingObserver):
    """
    A wrap of pytorch version observer: HistogramObserver
    """

    def __init__(
        self,
        qspec: QTensorConfig,
        device: torch.device | None = None,
        bins: int = 256,
        reduce_range: bool = False,
        upsample_rate: int = 384,
    ) -> None:
        super().__init__(qspec, device)
        self.qscheme = qspec.qscheme
        self.symmetric = qspec.symmetric

        if self.qscheme != QSchemeType.per_tensor:
            raise ValueError("PerTensorHistogramObserverPro only supports per_tensor")
        torch_qscheme = torch.per_tensor_symmetric if self.symmetric else torch.per_tensor_affine

        dtype = qspec.dtype
        if dtype not in [Dtype.uint4, Dtype.int8, Dtype.uint8]:
            raise ValueError("PerTensorHistogramObserverPro only supports 4bit and 8bit")
        else:
            quant_min, quant_max = calculate_qmin_qmax(dtype)
            if dtype == Dtype.uint4:
                torch_dtype = torch.quint4x2
            elif dtype == Dtype.int8:
                torch_dtype = torch.qint8
            elif dtype == Dtype.uint8:
                torch_dtype = torch.quint8

        # The argument `upsample_rate` was removed from `HistogramObserver` in torch 2.5.
        if is_torch_greater_or_equal_2_5():
            kwargs = {}
        else:  # pragma: no cover
            kwargs = {"upsample_rate": upsample_rate}

        self.histogram = HistogramObserver(
            qscheme=torch_qscheme,
            dtype=torch_dtype,
            bins=bins,
            quant_min=quant_min,
            quant_max=quant_max,
            reduce_range=reduce_range,
            **kwargs,
        )

    def forward(self, x_orig: torch.Tensor) -> Any:
        return self.histogram(x_orig)

    def _calculate_qparams(self) -> Any:
        new_min, new_max = self.histogram._non_linear_param_search()
        return self.histogram._calculate_qparams(new_min, new_max)


class PerTensorPercentileObserver(PerTensorHistogramObserver):
    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec, device)

        # TODO: make the value can be set
        self._skip_zeros = True
        self._num_bins = 4200
        self.percentile = 99.99999999

    def _calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:
        r"""Calculates the quantization parameters."""
        self.min_val, self.max_val = self._calculate_min_and_max_using_percentile()
        return self.calculate_qparams(self.min_val, self.max_val)

    def _calculate_min_and_max_using_percentile(self) -> tuple[torch.Tensor, torch.Tensor]:
        assert isinstance(self.calib_hist, torch.Tensor)
        assert isinstance(self.calib_bin_edges, torch.Tensor)
        return self.get_min_max_by_percentile(self.calib_hist, self.calib_bin_edges, self.percentile)

    def get_min_max_by_percentile(
        self, histogram: torch.Tensor, bin_edges: torch.Tensor, percentile: float
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Calculate the minimum and maximum values of a histogram at a specified percentile.

        Parameters:
        - histogram (torch.Tensor): A tensor representing the histogram of the data. Each element
        in the histogram represents the frequency of data in the corresponding bin.
        - bin_edges (torch.Tensor): A tensor containing the edge values that correspond to the
        bins represented in the histogram. There should be one more element in `bin_edges` than
        in `histogram`.
        - percentile (int): The percentile at which to determine the minimum and maximum values.
        The value should be an integer between 0 and 100.

        Returns:
        - Tuple[torch.Tensor, torch.Tensor]: A tuple containing two tensors. The first tensor
        is the value at the specified percentile, and the second tensor is the value at the
        complementary percentile (i.e., 100-percentile).

        Raises:
        - ValueError: If the `percentile` argument is not within the range 0 to 100.
        """
        if percentile < 0 or percentile > 100:
            raise ValueError("Percentile value must be between 0 and 100.")

        # Return None if no data is available
        if bin_edges is None and histogram is None:
            raise ValueError("no data available")

        # Calculate cumulative distribution function
        hist_total = histogram.sum()

        # Empty / zero-mass histogram: no meaningful percentile exists. Return a
        # zero range so downstream qparam calculation produces a degenerate but
        # valid (zero-scale-handled) result rather than a low-level NaN crash.
        if hist_total.item() <= 0:
            logger.warning(
                f"PerTensorPercentileObserver (id={hex(id(self))}) received an empty / zero-mass histogram; "
                "returning a zero (min, max) range. This usually means the layer's activations were all "
                "zero across the calibration set, which produces a degenerate quantization for this layer. "
                "To locate the offending layer, run "
                "`[n for n, m in model.named_modules() if id(m) == "
                f"{id(self)}]` after calibration."
            )
            zero = torch.zeros(1, device=self.device)
            return zero, zero

        cumulative_dist = torch.cumsum(histogram / hist_total, dim=0)
        last_idx = cumulative_dist.numel() - 1

        if self.symmetric is not None and self.symmetric is False:
            target_pct_one_side = (100.0 - percentile) / 200.0

            upper_matches = (cumulative_dist >= target_pct_one_side).nonzero()
            upper_idx = upper_matches.min().item() if upper_matches.numel() > 0 else last_idx
            assert isinstance(upper_idx, int), "Index must be an integer"
            max_value = bin_edges[upper_idx]

            lower_matches = (cumulative_dist <= (1 - target_pct_one_side)).nonzero()
            lower_idx = lower_matches.min().item() if lower_matches.numel() > 0 else 0
            assert isinstance(lower_idx, int), "Index must be an integer"
            min_value = bin_edges[lower_idx]

        else:
            target_pct = percentile / 100.0
            cumulative_dist_max = cumulative_dist[-1].item()
            assert isinstance(cumulative_dist_max, float)
            target_pct = min(target_pct, cumulative_dist_max)

            upper_matches = (cumulative_dist >= target_pct).nonzero()
            upper_idx = upper_matches.min().item() if upper_matches.numel() > 0 else last_idx
            assert isinstance(upper_idx, int), "Index must be an integer"
            max_value = bin_edges[upper_idx]

            min_value = torch.tensor(0, device="cpu")

        max_value = max_value.to(self.device)
        min_value = min_value.to(self.device)
        return min_value, max_value


class PerTensorMSEObserver(PerTensorHistogramObserver):
    def __init__(self, qspec: QTensorConfig, device: torch.device | None = None) -> None:
        super().__init__(qspec, device)

    def _calculate_qparams(self) -> tuple[torch.Tensor, torch.Tensor]:
        self.min_val, self.max_val = self._calculate_min_and_max_using_mse()
        return self.calculate_qparams(self.min_val, self.max_val)

    def _calculate_min_and_max_using_mse(self) -> tuple[torch.Tensor, torch.Tensor]:
        assert isinstance(self.calib_hist, torch.Tensor)
        assert isinstance(self.calib_bin_edges, torch.Tensor)
        return self.get_min_max_by_mse(self.calib_hist, self.calib_bin_edges)

    def get_min_max_by_mse(
        self, calib_hist: torch.Tensor, calib_bin_edges: torch.Tensor, stride: int = 1, start_bin: int = 2045
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Returns amax that minimizes MSE of the collected histogram."""
        # If calibrator hasn't collected any data, return none
        if calib_bin_edges is None and calib_hist is None:
            raise ValueError("no data available")

        counts = calib_hist
        edges = calib_bin_edges

        # Need at least two edges to form a single bin center.
        if edges.numel() < 2:
            raise ValueError(f"calib_bin_edges must have at least 2 elements, got {edges.numel()}")

        counts = counts.to(self.device)
        edges = edges.to(self.device)

        centers = (edges[1:] + edges[:-1]) / 2

        # Default start_bin (2045) targets the standard 2048-bin histogram. Clamp
        # so the search loop always evaluates at least one center for smaller
        # histograms instead of leaving ``mses`` empty for torch.stack.
        effective_start_bin = min(start_bin, max(0, len(centers) - 1))

        mses = []
        arguments = []

        min_value = torch.tensor(0, device="cpu")
        min_value = min_value.to(self.device)

        for i in range(effective_start_bin, len(centers), stride):
            amax = centers[i]
            if self.dtype in [Dtype.int4, Dtype.uint4, Dtype.int8, Dtype.uint8]:
                quant_centers = self.int_fake_tensor_quant(centers, min_value, amax)
            elif self.dtype in [Dtype.fp8_e4m3, Dtype.fp8_e5m2]:
                quant_centers = self.scaling_fp8(centers, amax)
            else:
                raise ValueError(
                    f"Invalid dtype {self.dtype}. dtype must be a positive integer, fp8_e4m3 or fp8_e5m2."
                )  # pragma: no cover

            mse = ((quant_centers - centers) ** 2 * counts).mean()

            mses.append(mse.cpu())
            arguments.append(i)

        argmin = torch.argmin(torch.stack(mses))
        calib_amax = centers[arguments[argmin]]

        calib_amax = calib_amax.to(self.device)

        return min_value, calib_amax

    def int_fake_tensor_quant(self, X: torch.Tensor, min_value: torch.Tensor, max_value: torch.Tensor) -> torch.Tensor:
        scale, zero_point = self.calculate_int_quant_params(min_value, max_value)
        assert isinstance(self.quant_min, int)
        assert isinstance(self.quant_max, int)
        X = torch.fake_quantize_per_tensor_affine(
            X, scale.to(torch.float), zero_point.to(torch.int), self.quant_min, self.quant_max
        )
        return X

    @log_errors
    def scaling_fp8(self, X: torch.Tensor, amax: torch.Tensor) -> torch.Tensor:
        min_norm, max_norm = calculate_qmin_qmax(self.dtype)
        X_orig_dtype = X.dtype
        scale = amax / max_norm
        X = X / scale
        X = torch.clamp(X, min=min_norm, max=max_norm)
        if self.dtype == Dtype.fp8_e4m3:
            fp8_dtype = torch.float8_e4m3fn
        elif self.dtype == Dtype.fp8_e5m2:
            fp8_dtype = torch.float8_e5m2
        else:
            raise ValueError(
                f"Invalid dtype {self.dtype}. Supported fp8 formats: fp8_e4m3, fp8_e5m2."
            )  # pragma: no cover
        X = X.to(fp8_dtype).to(X_orig_dtype) * scale
        return X
