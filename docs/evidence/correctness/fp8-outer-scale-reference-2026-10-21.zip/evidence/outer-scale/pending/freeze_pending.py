import difflib
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[5]
stage = Path(__file__).resolve().parent
name = 'tests/compute_models/fp8_outer_scale_fixture.h'
current = (root / name).read_bytes()
assert hashlib.sha256(current).hexdigest() == 'f8ef18558604c0e7af89fbe6a1c15c12b9f315f20c2fa19e7e1f80922eda7cd8'
candidate = stage / name
data = candidate.read_text(encoding='utf-8')
data = data.replace('actual(std::size_t(rows*depth))', 'actual(std::size_t(test.rows*test.depth))')
candidate.write_text(data, encoding='utf-8', newline='\n')
encoded = candidate.read_bytes()
patch = ''.join(difflib.unified_diff(current.decode().replace('\r\n', '\n').splitlines(True), data.splitlines(True),
                                    fromfile='before/' + name, tofile='after/' + name))
(stage / 'source-role-fixture.diff').write_text(patch, encoding='utf-8')
receipt = {
    'status': 'pending candidate only; canonical product/tests remain untouched',
    'target': name,
    'before': {'bytes': len(current), 'sha256': hashlib.sha256(current).hexdigest()},
    'candidate': {'path': candidate.relative_to(root).as_posix(), 'bytes': len(encoded),
                  'sha256': hashlib.sha256(encoded).hexdigest()},
    'entry': 'fp8_outer_scale_test::run_source_role(resource,queues,compile,write,read,prepare,owner={})',
    'shape': {'M': [1, 2], 'N': 128, 'K': 7168},
    'submissions': 8,
    'generic_compatibility': 'Existing run_lifetimes/run_prologue/run_escape retain original Case defaults, graph equations, payload formulas, oracle and invocation body. The common body is factored as run_case.',
    'equation': 'No-floor F32 amax * literal reciprocal448 bits3b124925, strict reciprocal normalization, E4 code dot, SW then SA, final BF16.',
    'finite_maximum_equivalence': 'AbsBF16->CastF32->ReduceF32 is exact for these finite BF16 inputs and avoids an extra reader of the contracted CastA result. No activation value is first quantized or altered.',
    'counters': 'Reuses existing independent table/bit oracle; wrong direct division448, early BF16 operands, wrong row and wrong channel each produce a different final BF16 output.',
    'actual_counterfactual_outputs': {
        'scale_formation_row0_column0': {'correct': '3bc1', 'wrong': '3c01'},
        'early_operands_row0_column1': {'correct': '3f82', 'wrong': '3f83'},
        'wrong_row_row1_column2': {'correct': '3ef0', 'wrong': '3ef1'},
        'wrong_channel_row0_column2': {'A': '.375', 'SW_correct': 1.25, 'SW_wrong': 1,
                                      'correct': '3ef1', 'wrong': '3ec1'},
        'note': 'The earlier independent design witness used A1 for its wrong-channel example. This candidate intentionally uses the .375 lane; both are separate valid witnesses, not changed tolerances.'},
    'resources': 'Original W E4 constant and F32 SW typed input, original two invocations/slots and two generations per shape, same old-result checks. SW remains a dynamic typed input as in generic core; no extra weight import or checkpoint payload is claimed.',
    'limits': ['Finite artificial carrier bytes at fixed primary-header geometry; no downloaded checkpoint values.',
               'No claim of AMD approximate rcpf or arbitrary hardware accumulation equivalence.',
               'No product source, public op, backend executor or model routing was added.',
               'Candidate not compiled or run.'],
}
(stage / 'source-freeze.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
