"""Finite software reference witnesses only; no product imports or GPU use."""
import hashlib
import json
import math
import struct
from pathlib import Path

stage = Path(__file__).resolve().parent
root = Path(__file__).resolve().parents[4]

def f32(x):
    try:
        return struct.unpack('<f', struct.pack('<f', x))[0]
    except OverflowError:
        return math.copysign(math.inf, x)

def bits(x):
    return struct.unpack('<I', struct.pack('<f', f32(x)))[0]

def bf16(x):
    value = bits(x)
    rounded = (value + 0x7fff + ((value >> 16) & 1)) & 0xffffffff
    return struct.unpack('<f', struct.pack('<I', rounded & 0xffff0000))[0]

def e4_value(code):
    magnitude = code & 127
    exponent, fraction = magnitude >> 3, magnitude & 7
    value = math.ldexp(fraction, -9) if exponent == 0 else math.ldexp(1 + fraction / 8, exponent - 7)
    return -value if code & 128 else value

positive_e4 = [e4_value(i) for i in range(127)]

def e4_code(value):
    # Independent finite exhaustive table, SATFINITE at 448, nearest-even.
    sign = 128 if math.copysign(1, value) < 0 else 0
    value = min(abs(value), 448)
    winner = min(range(127), key=lambda i: (abs(value - positive_e4[i]), i & 1))
    return sign | winner

recip448 = f32(1 / 448)

def scale(amax, divide=False):
    return f32(amax / 448) if divide else f32(amax * recip448)

def quantize(value, sa):
    return e4_code(f32(value * f32(1 / sa)))

def restored(code, sa, sw):
    return bf16(f32(f32(e4_value(code) * sw) * sa))

def early_operand(code, sa, sw):
    # Wrong software tree: separately reconstruct the two BF16 operands first.
    return bf16(f32(bf16(f32(e4_value(code) * sa)) * bf16(sw)))

amax = bf16(450)
sa = scale(amax)
divide_sa = scale(amax, True)
tiny = bf16(0.006866455078125)
correct_code, wrong_code = quantize(tiny, sa), quantize(tiny, divide_sa)
assert (bits(sa), bits(divide_sa), correct_code, wrong_code) == (0x3f80924a, 0x3f809249, 3, 4)
scale_formation = {
    'amax_BF16': amax, 'entry_BF16': tiny, 'reciprocal448_F32_bits': f'{bits(recip448):08x}',
    'correct_scale_bits': f'{bits(sa):08x}', 'wrong_direct_divide_scale_bits': f'{bits(divide_sa):08x}',
    'correct_A_E4_code': correct_code, 'wrong_direct_divide_A_E4_code': wrong_code,
    'W_code': 0x38, 'SW_F32': 1,
    'correct_Y_BF16_bits': f'{bits(restored(correct_code, sa, 1)) >> 16:04x}',
    'wrong_Y_BF16_bits': f'{bits(restored(wrong_code, divide_sa, 1)) >> 16:04x}',
}
assert scale_formation['correct_Y_BF16_bits'] == '3bc1'
assert scale_formation['wrong_Y_BF16_bits'] == '3c01'

# Choose the early-BF16 counterexample before any device observation. The
# constrained search is over ten declared F32 scales, not a benchmark matrix.
scales = [f32(1 + numerator / 256) for numerator in range(1, 11)]
early = None
for sw in scales:
    code = quantize(bf16(1), sa)
    expected, wrong = restored(code, sa, sw), early_operand(code, sa, sw)
    if bits(expected) != bits(wrong):
        early = {'A_BF16': 1, 'A_E4_code': code, 'SW_F32': sw,
                 'SW_F32_bits': f'{bits(sw):08x}',
                 'correct_Y_BF16_bits': f'{bits(expected) >> 16:04x}',
                 'wrong_operand_BF16_Y_bits': f'{bits(wrong) >> 16:04x}'}
        break
assert early is not None

row_scales = [sa, scale(bf16(896))]
channel_scales = [f32(1), early['SW_F32'], f32(1.25), f32(.5)]
row_value = bf16(.375)
row_code = quantize(row_value, row_scales[1])
wrong_row_code = quantize(row_value, row_scales[0])
row_expected = restored(row_code, row_scales[1], channel_scales[2])
row_wrong = restored(wrong_row_code, row_scales[0], channel_scales[2])
# Merely using the same SA during quantization and restoration can occasionally
# mask a wrong row; this finite input has a decisive quantization difference.
assert bits(row_expected) != bits(row_wrong)
channel_code = quantize(bf16(1), sa)
channel_expected = restored(channel_code, sa, channel_scales[2])
channel_wrong = restored(channel_code, sa, channel_scales[0])
assert bits(channel_expected) != bits(channel_wrong)

reader = root / '.scratch/architecture-refactor-2026-10-18/quark-fp8-side-2026-10-21/review/selected-reader-contract.json'
report = {
    'status': 'independent finite host witnesses; no product, compiler, GPU or checkpoint numerical payload',
    'reader_contract': {'path': reader.relative_to(root).as_posix(),
                        'sha256': hashlib.sha256(reader.read_bytes()).hexdigest()},
    'shape': {'M': [1, 2], 'N': 128, 'K': 7168},
    'equation': 'SA=RNE_F32(amax(A)*RNE_F32(1/448)), Aq=SATFINITE_E4(RNE_F32(A*RNE_F32(1/SA))), Y=BF16(RNE_F32(RNE_F32(dot_F32(Aq,Wq)*SW)*SA))',
    'scale_formation': scale_formation,
    'early_BF16': early,
    'wrong_row': {'row1_amax_BF16': 896, 'row1_scale_bits': f'{bits(row_scales[1]):08x}',
                  'entry_BF16': row_value, 'correct_A_E4_code': row_code,
                  'wrong_row0_A_E4_code': wrong_row_code, 'SW': channel_scales[2],
                  'correct_Y_BF16_bits': f'{bits(row_expected) >> 16:04x}',
                  'wrong_Y_BF16_bits': f'{bits(row_wrong) >> 16:04x}'},
    'wrong_channel': {'SW_correct': channel_scales[2], 'SW_wrong': channel_scales[0],
                      'correct_Y_BF16_bits': f'{bits(channel_expected) >> 16:04x}',
                      'wrong_Y_BF16_bits': f'{bits(channel_wrong) >> 16:04x}'},
    'limits': ['finite nonzero amax only; no zero/tiny/NaN policy inference',
               'strict F32 software reciprocal, not proof of AMD approximate rcpf',
               'synthetic original E4/F32 carriers at fixed-header role geometry; no checkpoint weights read'],
}
(stage / 'source-role-witness.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
