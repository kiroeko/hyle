#pragma once

#include "hyle/compute/model_ops.h"

#include <array>

namespace hyle::compute::packed::internal {

// Same-build contraction of a public, stored-scale software graph:
// F32(A) * F32(1/SA) -> SATFINITE E4M3 RNE -> F32 code dot W codes,
// then separate F32 *SA, *SW and final output Cast. Never operand BF16 QDQ.
// Scalar bytes are current inputs, including IEEE exceptional values.
struct StaticFloat8Linear final {
  DataType output_type = DataType::kBFloat16;
  static constexpr OperationId operation_id{0x48594c4553465038ULL, 1};
  static constexpr std::string_view operation_name = "private-static-float8-linear";
  constexpr OperationTraits operation_traits() const noexcept {
    return {{4, 4}, 1, AliasPolicy::kNone, EffectKind::kPure,
            PrecisionPolicy::kAccumulateInDeclaredType, DataType::kFloat32, true};
  }
  Status infer_output_descriptions(std::span<const TensorDesc> in,
                                   std::span<TensorDesc> out) const noexcept {
    const auto floating = [](DataType t) {
      return t == DataType::kFloat32 || t == DataType::kFloat16 || t == DataType::kBFloat16;
    };
    if (in.size() != 4 || out.size() != 1 || !floating(output_type) ||
        !floating(in[0].data_type()) || in[1].data_type() != DataType::kFloat8E4M3FN)
      return Status::InvalidArgument("static FP8 linear ports or types differ");
    for (const auto &d : in)
      if (!d.is_plain() || !d.is_dense())
        return Status::Unimplemented("static FP8 linear requires plain dense ports");
    for (std::size_t i = 2; i < 4; ++i)
      if (in[i].data_type() != DataType::kFloat32 ||
          !(in[i].rank() == 0 || (in[i].rank() == 1 && in[i].dimensions()[0] == 1)))
        return Status::InvalidArgument("static FP8 linear requires independent F32 scalars");
    if (in[0].rank() != 2 || in[1].rank() != 2 ||
        in[0].dimensions()[1] != in[1].dimensions()[1])
      return Status::InvalidArgument("static FP8 linear matrix dimensions differ");
    if (in[0].dimensions()[0] <= 0 || in[1].dimensions()[0] <= 0 || in[0].dimensions()[1] <= 0)
      return Status::Unimplemented("static FP8 linear leaves empty matrices to the ordinary graph");
    HYLE_ASSIGN_OR_RETURN(out[0], TensorDesc::dense(output_type,
        std::array{in[0].dimensions()[0], in[1].dimensions()[0]}));
    return Status::Ok();
  }
};
static_assert(detail::InlineCustomOperationDescriptor<StaticFloat8Linear>);

} // namespace hyle::compute::packed::internal
