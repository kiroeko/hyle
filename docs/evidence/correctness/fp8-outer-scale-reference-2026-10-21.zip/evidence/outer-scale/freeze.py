import difflib
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[4]
stage = Path(__file__).resolve().parent
paths = [
    'src/compute_packed_shared/static_fp8_linear.h',
    'src/graph/static_fp8_region.h',
    'src/compute_provider_native/static_fp8.cc',
    'tests/compute_models/fp8_outer_scale_fixture.h',
]
inventory, patches = [], []
for name in paths:
    data = (root / name).read_bytes()
    dest = stage / 'source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    inventory.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    before = stage / 'before' / name
    patches.extend(difflib.unified_diff(
        before.read_text(encoding='utf-8').splitlines(True) if before.exists() else [],
        data.decode('utf-8').splitlines(True), fromfile='before/' + name, tofile='after/' + name))
(stage / 'product-and-fixture.diff').write_text(''.join(patches), encoding='utf-8')
report = {
    'status': 'source frozen; not compiled or executed by this owner',
    'scope': 'private static FP8 scalar/outer axes and two explicit ordered F32 scale products',
    'sources': inventory,
    'descriptor': {'bytes': 8, 'operation_revision': 2, 'policy_revision': 2,
                   'sa': ['scalar []/[1]', '[M,1]'], 'sw': ['scalar []/[1]', '[N]', '[1,N]'],
                   'invalid_scale_order_rejected': True},
    'native': {'workspace': 'M*K U8 bytes', 'weight_float_tile_elements': 64,
               'new_native_plan_fields': 0, 'scale_strides': 'existing row_first_stride/row_second_stride'},
    'fixture': {'namespace': 'fp8_outer_scale_test',
                'functions': ['run_lifetimes', 'run_prologue', 'run_escape'],
                'signature': '(resource, queues, compile, write, read, prepare, owner={})',
                'shape': {'M': 3, 'N': 5, 'K': 128},
                'planned_submissions': {'run_lifetimes': 4, 'run_prologue': 4, 'run_escape': 2},
                'order_witness': {'dot': .375, 'SA_bits': '3f808000', 'SW_bits': '3f812345',
                                  'SW_then_SA_F32_bits': '3ec2769d', 'SA_then_SW_F32_bits': '3ec2769c'},
                'scope_limits': ['generic software graph, not artifact deployment closure',
                                 'prologue declares direct divide448 and floor1e-10',
                                 'published encoded A must retain ordinary fallback']},
    'verification': {'compile': 'not run', 'GPU': 'not run', 'source_review': 'bounded local review'},
}
(stage / 'source-freeze.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(inventory, indent=2))
