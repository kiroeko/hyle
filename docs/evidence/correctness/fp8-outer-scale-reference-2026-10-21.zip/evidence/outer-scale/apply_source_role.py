import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[4]
stage = Path(__file__).resolve().parent
name = 'tests/compute_models/fp8_outer_scale_fixture.h'
target = root / name
before = target.read_bytes()
assert hashlib.sha256(before).hexdigest() == 'f8ef18558604c0e7af89fbe6a1c15c12b9f315f20c2fa19e7e1f80922eda7cd8'
candidate = (stage / 'pending' / name).read_bytes()
assert hashlib.sha256(candidate).hexdigest() == 'df62449003a0f5d34df21d55ce3a1dbc0df69267e55ac0497aea6bdc597b81ad'
core = stage / 'revisions' / 'generic-core' / name
core.parent.mkdir(parents=True, exist_ok=True)
if core.exists():
    assert core.read_bytes() == before
else:
    core.write_bytes(before)
expected = {
    'src/compute_packed_shared/static_fp8_linear.h': '454fd995f6bddf96cb517c656f21b793c32f175dd7ad82a07ab87bd705ad2ce8',
    'src/graph/static_fp8_region.h': 'f22a0ac2ce8cecae75a283a6470402ba1d672cdf4087cc780ac5d8c742f1d95f',
    'src/compute_provider_native/static_fp8.cc': 'aae79be16b2353687e707338d9f05930ed9deedc21f51fbb56319f385e9e2777',
}
inventory = []
for path, sha in expected.items():
    data = (root / path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == sha, path
    inventory.append({'path': path, 'bytes': len(data), 'sha256': sha, 'changed_this_revision': False})
target.write_bytes(candidate)
inventory.append({'path': name, 'bytes': len(candidate), 'sha256': hashlib.sha256(candidate).hexdigest(), 'changed_this_revision': True})
snapshot = stage / 'revisions' / 'source-role' / name
snapshot.parent.mkdir(parents=True, exist_ok=True)
snapshot.write_bytes(candidate)
report = {
    'status': 'source-role fixture applied after four-backend core validation; new role not executed at freeze',
    'sources': inventory,
    'before': {'path': core.relative_to(root).as_posix(), 'sha256': hashlib.sha256(before).hexdigest()},
    'diff': (stage / 'pending/source-role-fixture.diff').relative_to(root).as_posix(),
    'namespace': 'fp8_outer_scale_test',
    'entry': 'run_source_role(resource,queues,compile,write,read,prepare,owner={})',
    'role_scope': 'Catalog23 f_a_proj fixed-header geometry, M1/M2 N128 K7168, finite artificial E4/F32 carrier bytes; no checkpoint payload claim',
    'equation': 'No-floor F32 maximum*F32 reciprocal448, strict F32 reciprocal, E4 code dot, ordered SW then SA, BF16 output',
    'submissions': 8,
    'wrapper_selection': 'CPU/CUDA constrain only the12 recipe nodes; prologue stays natural. Vulkan/Apple native ordinary selection. Record a separate default compile report without new execution or production rank changes.',
    'verification': 'Products unchanged; new role compile/GPU not yet run by this owner.',
}
(stage / 'source-role-freeze.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
