from pathlib import Path
import json, runpy

A = Path('.scratch/architecture-refactor-2026-10-18')
P = A / 'quark-fp8-side-2026-10-21/apple'
ssh = runpy.run_path(str(A / 'batch-query-extent/delegated/apple/validate.py'))['ssh']
remote = json.loads((P / 'mac/plan.json').read_text())['remote']
code = r'''
from pathlib import Path
import hashlib, json, os, subprocess, sys, time, xml.etree.ElementTree as E
r = Path(json.load(sys.stdin)['remote']); o = r/'results'
def identity(p):
    p=Path(p); b=p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def save(n,v): (o/n).write_text(json.dumps(v,indent=2)+'\n')
manifest=json.loads((r/'source-manifest.json').read_text())
for row in manifest: assert identity(r/row['path'])['sha256']==row['sha256']
compiles=json.loads((o/'compile-summary.json').read_text())['compiles']
for row in compiles:
    assert identity(row['source']['path'])==row['source']
    assert identity(row['object'])==row['object_identity']
    assert all(identity(x['path'])==x for x in row['dependencies'])
image=r/'fp8-source-role'; before=identity(image)
argv=[str(image),'--gtest_filter=AppleFp8OuterScaleGraph.*:AppleStaticFloat8ReferenceGraph.*',
      '--gtest_output=xml:'+str(o/'current7-tests.xml')]
record=dict(argv=argv, started=time.time(), environment={})
save('current7-run.command.json', record)
p=subprocess.run(argv,cwd=r,capture_output=True,text=True)
(o/'current7-run.stdout.log').write_text(p.stdout)
(o/'current7-run.stderr.log').write_text(p.stderr)
record.update(exit=p.returncode, seconds=time.time()-record['started'])
save('current7-run.result.json',record)
cases=E.parse(o/'current7-tests.xml').findall('.//testcase')
failed=[x.attrib for x in cases if x.findall('failure')]
skipped=[x.attrib for x in cases if x.findall('skipped')]
assert identity(image)==before
validation=dict(image=before,tests=len(cases),failed=failed,skipped=skipped,exit=p.returncode,
 names=[x.get('classname')+'.'+x.get('name') for x in cases],
 source_manifest=identity(r/'source-manifest.json'), compiled=False, linked=False)
save('current7-validation.json',validation)
print(json.dumps(validation))
'''
result=ssh(code,dict(remote=remote))
(P/'current7-direct-run.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['exit']==0 and result['tests']==7 and not result['failed'] and not result['skipped']
print(json.dumps(result))
