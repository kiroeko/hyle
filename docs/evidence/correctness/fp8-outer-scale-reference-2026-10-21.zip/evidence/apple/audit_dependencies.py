"""Read-only audit of actual dependencies and remote artifacts; write local receipts."""
from pathlib import Path
import hashlib
import json
import posixpath
import sys
import runpy
import shutil
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
A = ROOT / ".scratch/architecture-refactor-2026-10-18"
P = A / "quark-fp8-side-2026-10-21/apple"
OUT = P / "mac" / (sys.argv[1] if len(sys.argv) > 1 else "final")
RESULTS = OUT / "results"


def read(p):
    return json.loads(p.read_text())


def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n")


def identity(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), bytes=len(b),
                sha256=hashlib.sha256(b).hexdigest())


def canonical(remote):
    normal = posixpath.normpath(remote)
    for prefix in ("include/hyle/", "tests/", "src/", "third_party/"):
        marker = "/" + prefix
        start = normal.find(marker)
        while start >= 0:
            local = ROOT / normal[start + 1:]
            if local.is_file():
                return local
            start = normal.find(marker, start + 1)
    return None


compiles = read(RESULTS / "compile-summary.json")["compiles"]
audits, drifts, unique = [], [], {}
for c in compiles:
    own, external = [], []
    for dep in c["dependencies"]:
        local = canonical(dep["path"])
        if local is None:
            external.append(dep)
            continue
        current = identity(local)
        equal = current["sha256"] == dep["sha256"] and current["bytes"] == dep["bytes"]
        row = dict(actual=dep, current=current, equal=equal)
        own.append(row)
        unique[current["path"]] = current
        if not equal:
            drifts.append(row)
    actual_source = c["source"]
    assert identity(canonical(actual_source["path"]))["sha256"] == actual_source["sha256"]
    assert c["exit"] == 0 and c["source_drifts"] == []
    audits.append(dict(source=actual_source, exit=c["exit"],
                       dependencies=len(c["dependencies"]), canonical_count=len(own),
                       external_count=len(external), canonical=own, external=external))
audit = dict(status="all_actual_dependency_files_classified_and_canonical_bytes_equal" if not drifts else "drift",
             scope="Every actual -MMD dependency of current eight CXX invocations; SDK/system/generated paths retained by identity without copying SDK text.",
             translation_units=len(compiles), actual_dependency_references=sum(x["dependencies"] for x in audits),
             canonical_dependency_references=sum(x["canonical_count"] for x in audits),
             external_dependency_references=sum(x["external_count"] for x in audits),
             unique_canonical_files=len(unique), drift_count=len(drifts), drifts=drifts, compiles=audits)
save(P / "actual-dependencies-canonical-audit.json", audit)
assert not drifts

print(json.dumps({k:v for k,v in audit.items() if k not in ("compiles", "drifts")},indent=2))
