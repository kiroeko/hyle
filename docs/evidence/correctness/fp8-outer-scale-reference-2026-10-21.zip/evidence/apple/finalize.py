from pathlib import Path
import hashlib, json, runpy, shutil, xml.etree.ElementTree as E

A=Path('.scratch/architecture-refactor-2026-10-18')
P=A/'quark-fp8-side-2026-10-21/apple'
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
remote=json.loads((P/'mac/plan.json').read_text())['remote']
def identity(p):
    p=Path(p); b=p.read_bytes()
    return dict(path=p.as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,data): (P/name).write_text(json.dumps(data,indent=2)+'\n')

code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(json.load(sys.stdin)['remote'])
def identity(p):
    b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
p=r/'fp8-source-role.map'; lines=p.read_text().splitlines()
objects=lines[lines.index('# Object files:')+1:lines.index('# Sections:')]
names=['apple_static_fp8','apple_mature_float','apple_operations','apple_lowering','native_region','native_provider','static_fp8']
related=[x for x in objects if any(n in x for n in names)]
old=[x for x in related if '.a(' in x or '.a[' in x]
assert len(related)==7 and not old
assert all(str(r/'objects') in x for x in related)
map_audit=dict(map=identity(p),related_loaded_objects=related,related_old_archive_members=old,
  private_type_symbols=[x for x in lines if 'StaticFloat8Linear' in x or 'StaticFloat8Pattern' in x],
  loaded_objects=objects,loaded_object_count=len(objects))
files=[]; objs=[]
for p in sorted(r.rglob('*')):
    if not p.is_file() or p.is_symlink(): continue
    if p.suffix=='.o': objs.append(identity(p)); continue
    with p.open('rb') as f: magic=f.read(4)
    if p.suffix=='.map' or magic in [bytes.fromhex('cffaedfe'),bytes.fromhex('feedfacf'),bytes.fromhex('cafebabe')]:
        files.append(identity(p))
assert len(files)==4 and len(objs)==9
images=[p['path'] for p in files if not p['path'].endswith('.map')]
ps=subprocess.run(['ps','-axo','pid=,args='],capture_output=True,text=True)
active=[line for line in ps.stdout.splitlines() if any(x in line for x in images)]
lsof=subprocess.run(['/usr/sbin/lsof','-Fn',*images],capture_output=True,text=True)
assert not active and not lsof.stdout.strip() and not r.is_symlink()
inventory=dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=files,
 retained_objects=objs,dsym=[str(p) for p in r.rglob('*.dSYM')],
 active_image_processes=active,lsof_stdout=lsof.stdout,lsof_exit=lsof.returncode,deleted=False,
 policy='Read-only inventory; root test.ps1 must review and delete exact image/map files. Preserve all objects, source, receipts and SDK.')
print(json.dumps(dict(map_audit=map_audit,inventory=inventory)))
'''
result=ssh(code,dict(remote=remote))
save('source-role-link-map-audit.json',result['map_audit'])
save('cleanup-inventory.json',result['inventory'])
generic=json.loads((P/'generic-source-freeze.json').read_text())
sources=[]
for old in generic['sources']:
    rel=old['path']; current=identity(rel)
    if rel not in ['tests/compute_models/fp8_outer_scale_fixture.h','tests/graph_route_apple/fp8_outer_scale_test.cc']:
        assert current==old,rel
    sources.append(current)
    q=P/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(rel,q)
audit=json.loads((P/'source-role-actual-dependencies-canonical-audit.json').read_text())
assert audit['drift_count']==0 and audit['translation_units']==8
freeze=dict(status='current_source_and_every_actual_MMD_dependency_equal_canonical',sources=sources,
 source_snapshot='source/',canonical_dep_audit=identity(P/'source-role-actual-dependencies-canonical-audit.json'),
 actual_whole_dep_drift=0,current_CXX_objects=8,products_retained_from_generic=7,wrapper_new=1,
 historical_generic_source_freeze=identity(P/'generic-source-freeze.json'))
save('source-freeze.json',freeze)
base=P/'mac/current7/results'
compiles=json.loads((base/'compile-summary.json').read_text())['compiles']
previous=json.loads((P/'mac/generic-first/results/compile-summary.json').read_text())['compiles']
oldproducts={x['source']['path']:x for x in previous if '/tests/' not in x['source']['path']}
for row in compiles:
    assert row['exit']==0 and not row['source_drifts']
    if '/tests/' not in row['source']['path']:
        assert row['object_identity']==oldproducts[row['source']['path']]['object_identity']
cases=[]; submissions=0
for c in E.parse(base/'current7-tests.xml').findall('.//testcase'):
    assert not c.findall('failure') and not c.findall('skipped')
    properties={x.get('name'):x.get('value') for x in c.findall('properties/property')}
    count=int(properties.get('successful_submissions',properties.get('actual_submissions','0')))
    assert count>0
    submissions+=count
    cases.append(dict(name=c.get('classname')+'.'+c.get('name'),successful_submissions=count,properties=properties))
assert len(cases)==7 and submissions==63
validation=json.loads((base/'current7-validation.json').read_text())
assert validation['tests']==7 and not validation['failed'] and not validation['skipped'] and validation['exit']==0
final=dict(status='actual_Apple_current_source_7of7_PASS',tests=7,new_tests=4,scalar_neighbors=3,
 successful_submissions=63,new_submissions=18,neighbor_submissions=45,expected_failed_submissions=0,
 failed=0,skipped=0,cases=cases,source_freeze=identity(P/'source-freeze.json'),
 hardware=identity(P/'mac/current7/hardware.json'),
 run=json.loads((base/'current7-run.result.json').read_text()),validation=validation,
 current_actual_compile_records=8,CXX_jobs_this_batch=9,Apple_product_jobs=5,CPU_product_jobs=2,
 test_jobs_this_batch=2,SDK_jobs=0,current_CXX_product_objects_reused=7,
 actual_whole_dep_drift=0,actual_dep_refs=audit['actual_dependency_references'],
 canonical_unique=audit['unique_canonical_files'],map_audit=identity(P/'source-role-link-map-audit.json'),
 compile_summary=identity(base/'compile-summary.json'),prior_generic_compile_summary=identity(P/'mac/generic-first/results/compile-summary.json'),
 current_run='Existing source-role image directly ran all7 tests, without a further compile or link.',
 scope='Explicit test-selected original Apple adapter candidate proof, not default automatic fusion. Fixed-header role23 uses finite artificial original E4/F32 data and strict F32 reciprocal. No checkpoint-payload, full deployment or AMD approximate rcpf bit-equivalence claim. Artifact30 typed-QDQ remains separate.',
 prior_results=[identity(P/'generic-validation.json'),identity(P/'mac/source-role/results/validation.json')],
 cleanup_inventory=identity(P/'cleanup-inventory.json'),no_deletion=True)
save('final-validation.json',final)
print(json.dumps(dict(source_freeze=identity(P/'source-freeze.json'),final_validation=identity(P/'final-validation.json'),
 cleanup_inventory=identity(P/'cleanup-inventory.json'),deletable_bytes=sum(x['bytes'] for x in result['inventory']['deletable_files']),
 tests=7,successful_submissions=63,drift=0),indent=2))
