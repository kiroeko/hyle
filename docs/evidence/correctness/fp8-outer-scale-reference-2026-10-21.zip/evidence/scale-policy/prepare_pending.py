import difflib
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[4]
stage = Path(__file__).resolve().parent

def identity(name, data):
    return {'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

names = ['include/hyle/compute/model_ops.h',
         'src/compute_provider_native/torch_cpu_program.cc',
         'tests/compute_ops/operation_test.cc']
records, patches = [], []
for name in names:
    original = (root / name).read_bytes()
    before = stage / 'before' / name
    before.parent.mkdir(parents=True, exist_ok=True)
    if before.exists():
        assert before.read_bytes() == original
    else:
        before.write_bytes(original)
    text = original.decode('utf-8').replace('\r\n', '\n')
    text = text.replace('Float8ScaleRounding', 'Float8ScalePolicy').replace('scale_rounding', 'scale_policy')
    text = text.replace('Float8ScalePolicy::kNone', 'Float8ScalePolicy::kDivide')
    if name == names[0]:
        text = text.replace('enum class Float8ScalePolicy : std::uint32_t { kNone, kPowerOfTwo };',
            'enum class Float8ScalePolicy : std::uint32_t {\n'
            '  kDivide = 0,\n  kPowerOfTwo = 1,\n  kMultiplyReciprocal = 2,\n};')
        text = text.replace('0x4650384c494e0001ULL', '0x4650384c494e0002ULL')
        text = text.replace('0x4650384752500002ULL', '0x4650384752500003ULL')
        text = text.replace('scale_policy != Float8ScalePolicy::kPowerOfTwo)',
            'scale_policy != Float8ScalePolicy::kPowerOfTwo &&\n'
            '         scale_policy != Float8ScalePolicy::kMultiplyReciprocal)')
        text = text.replace('Float8ScalePolicy rounding =', 'Float8ScalePolicy policy =')
        text = text.replace('Float8BlockLinear{rounding, absmax_floor}', 'Float8BlockLinear{policy, absmax_floor}')
        text = text.replace('GroupedFloat8Linear{rounding, absmax_floor}', 'GroupedFloat8Linear{policy, absmax_floor}')
        old = ('// kNone divides the F32 maximum by 448. kPowerOfTwo multiplies by the F32\n'
               '// reciprocal of 448, then rounds upward to a power of two, without a BF16\n'
               '// intermediate. Codes use saturated nearest-even conversion. Scales remain\n'
               '// F32 values; power-of-two rounding does not mean a group32 storage format.\n')
        new = ('// First take the F32 absolute maximum and clamp it by absmax_floor.\n'
               '// kDivide stores F32(maximum/448). kMultiplyReciprocal stores\n'
               '// F32(maximum*F32(1/448)), then normalizes with two separate F32 stages:\n'
               '// reciprocal=F32(1/scale), normalized=F32(activation*reciprocal).\n'
               '// kPowerOfTwo forms the same multiply-based raw scale, then rounds it\n'
               '// upward to a power of two and retains the original normalization.\n'
               '// No BF16 intermediate is inserted. Codes use saturated nearest-even\n'
               '// conversion. Scales remain F32; this is not a group32 storage format.\n')
        assert old in text
        text = text.replace(old, new)
        text = text.replace('a known rounding mode', 'a known scale policy')
        text = text.replace('// floor is explicit: ordinary SGLang uses 1e-10, official DeepSeek uses 1e-4.',
                            '// floor is explicit, for example 1e-10 or official DeepSeek\'s 1e-4.')
        text = text.replace('including its explicit rounding\n// policy', 'including its explicit scale\n// policy')
        text = text.replace('};\n\ninline Operation float8_block_linear(',
                            '};\nstatic_assert(sizeof(Float8BlockLinear) == 8);\n\ninline Operation float8_block_linear(')
        text = text.replace('};\n\ninline Operation grouped_float8_linear(',
                            '};\nstatic_assert(sizeof(GroupedFloat8Linear) == 8);\n\ninline Operation grouped_float8_linear(')
    elif name == names[1]:
        text = text.replace('#include <array>\n', '#include <array>\n#include <bit>\n', 1)
        text = text.replace('  bool power = false;',
            '  model_ops::Float8ScalePolicy scale_policy = model_ops::Float8ScalePolicy::kDivide;')
        text = text.replace('s.kind = Kind::kRoundtrip; s.power = true; s.floor = 1.0e-4F;',
            's.kind = Kind::kRoundtrip; s.scale_policy = model_ops::Float8ScalePolicy::kPowerOfTwo; s.floor = 1.0e-4F;')
        text = text.replace('s.power = !grouped ||\n        grouped->scale_policy == model_ops::Float8ScalePolicy::kPowerOfTwo;',
            's.scale_policy = grouped ? grouped->scale_policy : model_ops::Float8ScalePolicy::kPowerOfTwo;')
        text = text.replace('s.power = linear->scale_policy == model_ops::Float8ScalePolicy::kPowerOfTwo;',
                            's.scale_policy = linear->scale_policy;')
        text = text.replace('if (s.power) {', 'if (s.scale_policy == model_ops::Float8ScalePolicy::kPowerOfTwo) {')
        old = '  } else scale = torchao_cpu::choose_scale_float8(data, s.floor);'
        new = ('  } else if (s.scale_policy == model_ops::Float8ScalePolicy::kMultiplyReciprocal) {\n'
               '    // Separate F32 source boundaries: a stored reciprocal448 literal,\n'
               '    // scale, reciprocal(scale), then activation multiplication.\n'
               '    auto maximum = data.abs().amax(-1, true).clamp_min(s.floor);\n'
               '    scale = maximum * std::bit_cast<float>(std::uint32_t{0x3b124925});\n'
               '    auto reciprocal = scale.reciprocal();\n'
               '    auto codes = (data * reciprocal).clamp(-448, 448).to(at::kFloat8_e4m3fn);\n'
               '    return {std::move(codes), std::move(scale), {}};\n'
               '  } else scale = torchao_cpu::choose_scale_float8(data, s.floor);')
        assert old in text
        text = text.replace(old, new)
        assert 's.power' not in text
    else:
        text = text.replace('for (auto rounding : {model_ops::Float8ScalePolicy::kDivide,\n'
                            '                           model_ops::Float8ScalePolicy::kPowerOfTwo})',
                            'for (auto policy : {model_ops::Float8ScalePolicy::kDivide,\n'
                            '                        model_ops::Float8ScalePolicy::kPowerOfTwo,\n'
                            '                        model_ops::Float8ScalePolicy::kMultiplyReciprocal})')
        text = text.replace('float8_block_linear(rounding, 1e-4F)', 'float8_block_linear(policy, 1e-4F)')
        anchor = ('      EXPECT_EQ(infer_single_output(model_ops::grouped_float8_linear(\n'
                  '          model_ops::Float8ScalePolicy::kPowerOfTwo, 1.0e-4F), std::array{w, a, ids}).value(), *result);')
        assert anchor in text
        text = text.replace(anchor, anchor + '\n' +
            '      EXPECT_EQ(infer_single_output(model_ops::grouped_float8_linear(\n'
            '          model_ops::Float8ScalePolicy::kMultiplyReciprocal, 1.0e-10F), std::array{w, a, ids}).value(), *result);')
    assert 'Float8ScaleRounding' not in text and 'scale_rounding' not in text
    pending = stage / 'pending' / name
    pending.parent.mkdir(parents=True, exist_ok=True)
    pending.write_text(text, encoding='utf-8', newline='\n')
    records.append({'before': identity(name, original), 'pending': identity(name, pending.read_bytes())})
    patches.extend(difflib.unified_diff(original.decode().replace('\r\n', '\n').splitlines(True),
                                     text.splitlines(True), fromfile='before/' + name, tofile='after/' + name))
(stage / 'public-cpu-schema.pending.diff').write_text(''.join(patches), encoding='utf-8')
live = subprocess.check_output(['rg', '-l', 'Float8ScaleRounding|scale_rounding',
    'include', 'src', 'tests', '-g', '*.h', '-g', '*.cc', '-g', '*.cu', '-g', '*.cpp'], cwd=root, text=True).splitlines()
constructors = subprocess.check_output(['rg', '-l', 'Float8BlockLinear|GroupedFloat8Linear|float8_block_linear|grouped_float8_linear',
    'include', 'src', 'tests', '-g', '*.h', '-g', '*.cc', '-g', '*.cu', '-g', '*.cpp'], cwd=root, text=True).splitlines()
report = {'status': 'pending only; no canonical product or test files changed',
          'files': records, 'current_name_reference_file_count': len(live),
          'current_name_reference_files': [p.replace('\\', '/') for p in live],
          'constructor_or_extractor_inventory': [p.replace('\\', '/') for p in constructors],
          'ABI': {'public_bytes': 8, 'enum_underlying': 'uint32', 'numeric_values': {'kDivide': 0, 'kPowerOfTwo': 1, 'kMultiplyReciprocal': 2},
                  'dense_operation_revision': '1 -> 2', 'grouped_operation_revision': '2 -> 3',
                  'private_pair_revision_recommendation': '1 -> 2 in fp8_shared_linear.h; CUDA owner to implement',
                  'native_plan_change': False,
                  'CPU_private_state': 'One enum replaces private bool power within the opaque CPU Program owner; no cross-TU public layout contract.'},
          'remaining_source_updates': 'Other backends and live tests need the mechanical name/field migration and explicit new-policy selection or rejection. No old-name aliases. This script intentionally prepares only the public+CPU+schema owners allocated to this agent.',
          'refresh_boundary': 'Use actual linked constructor/extractor/inline thunk owners and fresh relevant test wrappers; remove/rebuild conflicting old descriptor thunks. Do not rebuild all header includers or SDKs.',
          'verification': 'No CXX/NVCC/link/GPU run. The existing independent host450/tiny witness is referenced by design.'}
(stage / 'pending-source-freeze.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': records, 'reference_files': len(live), 'constructor_extractor_files': len(constructors)}, indent=2))
