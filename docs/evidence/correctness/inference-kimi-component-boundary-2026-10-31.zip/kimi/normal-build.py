"""Owned normal shared Kimi build stages; never starts inference."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,subprocess,sys,time
B=Path(__file__).resolve().parent;R=B.parents[1];CACHE=R/'.scratch/build-compute-v2-dev'
PLAN=B/'candidate-plan-v3.json';ENV=R/'.scratch/inference-default-product-build-20261031/environment.json'
CMAKE='C:/Program Files/CMake/bin/cmake.exe'
def pin(path):
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':digest}
def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def values():
    return {m[1]:m[2] for l in (CACHE/'CMakeCache.txt').read_text().splitlines() if (m:=re.match(r'([^/#][^:]*):[^=]+=(.*)',l))}
def sources():
    result=[];overrides={}
    for path in sorted((B/'validation').glob('approved-consumer-*.json')):
        for row in json.loads(path.read_text())['source_pins']:overrides[str(Path(row['path']).resolve())]=row
    seen=set()
    for row in json.loads(PLAN.read_text())['files']:
        path=R/row['path'];identity=pin(path);expected=overrides.get(str(path.resolve()),row['candidate'])
        assert identity['bytes']==expected['bytes'] and identity['sha256']==expected['sha256'],row['path'];result.append(identity);seen.add(str(path.resolve()))
    for key,row in overrides.items():
        if key not in seen:
            identity=pin(Path(row['path']));assert identity==row,row['path'];result.append(identity)
    supplement=B/'validation/approved-unified-source-freeze.json'
    if supplement.exists():
        for row in json.loads(supplement.read_text())['source_pins']:
            identity=pin(Path(row['path']));assert identity==row,row['path'];result.append(identity)
    return result
def environment(folder):
    env=dict(os.environ);env.update(json.loads(ENV.read_text()))
    for name in ['CL','_CL_','CFLAGS','CXXFLAGS','LDFLAGS','CUDAFLAGS','CUDAARCHS','CUDACXX','CXX','CC','TORCH_INSTALL_PREFIX','CMAKE_PREFIX_PATH']:env.pop(name,None)
    temporary=B/'validation/tmp';temporary.mkdir(parents=True,exist_ok=True);env['TEMP']=env['TMP']=str(temporary)
    save(folder/'environment.json',{'inherited_normal':pin(ENV),'overrides':{'TEMP':str(temporary),'TMP':str(temporary)}})
    return env
def execute(stage,attempt,command):
    folder=B/'validation/control'/stage/attempt;folder.mkdir(parents=True,exist_ok=False)
    save(folder/'command.json',{'argv':command,'cwd':str(R),'source_plan':pin(PLAN),'actual_sources':sources()})
    if stage=='configure':(folder/'CMakeCache.before.txt').write_bytes((CACHE/'CMakeCache.txt').read_bytes())
    env=environment(folder);start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
    with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
        process=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err)
        save(folder/'process.json',{'pid':process.pid,'state':'RUNNING','start_utc':start})
        print(json.dumps({'stage':stage,'attempt':attempt,'pid':process.pid,'state':'RUNNING'}),flush=True)
        code=process.wait()
    receipt={'pid':process.pid,'state':'TERMINAL','exit_code':code,'start_utc':start,'elapsed_seconds':time.monotonic()-t}
    save(folder/'process.json',receipt);print(json.dumps({'stage':stage,**receipt}),flush=True)
    return folder,receipt
def main():
    stage,attempt=sys.argv[1:3];before=values()
    assert before.get('HYLE_STATIC')=='OFF' and 'HYLE_DEV_FACTORS' not in before
    assert before.get('FETCHCONTENT_FULLY_DISCONNECTED')=='ON' and before.get('FETCHCONTENT_UPDATES_DISCONNECTED')=='ON'
    assert before.get('HYLE_COMPUTE_ROUTES')=='cpu;cuda'
    ninja=before['CMAKE_MAKE_PROGRAM']
    if stage=='configure':
        snapshot=B/'validation/original-normal-CMakeCache.txt'
        if not snapshot.exists():
            snapshot.write_bytes((CACHE/'CMakeCache.txt').read_bytes());save(B/'validation/original-normal-config.json',before)
        command=[CMAKE,'-S',str(R),'-B',str(CACHE),'-UHYLE_DEV_FACTORS','-DHYLE_COMPONENTS:STRING=engine','-DHYLE_BUILD_TESTS:BOOL=OFF',
          '-DHYLE_COMPUTE_ROUTES:STRING=cpu;cuda','-DFETCHCONTENT_FULLY_DISCONNECTED:BOOL=ON','-DFETCHCONTENT_UPDATES_DISCONNECTED:BOOL=ON']
        folder,receipt=execute(stage,attempt,command)
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
        after=values();assert all(before.get(k)==after.get(k) for k in ['HYLE_STATIC','HYLE_TRACE','HYLE_TEST_INSTRUMENTATION','HYLE_SANITIZER','CMAKE_CXX_COMPILER','CMAKE_CUDA_ARCHITECTURES'])
        save(folder/'configuration-after.json',after)
        supplement=B/'validation/approved-unified-source-freeze.json'
        if supplement.exists():
            original=json.loads(Path(json.loads(supplement.read_text())['simd_generated_before']).read_text())['files']
            current=[]
            for row in original:
                path=Path(row['path']);identity=pin(path);identity['mtime_ns']=path.stat().st_mtime_ns
                assert all(identity[key]==row[key] for key in ['bytes','sha256','mtime_ns']),str(path)
                current.append(identity)
            save(folder/'simd-generated-stability.json',{'status':'ALL_29_BYTES_AND_MTIMES_UNCHANGED','files':current,'scope':'compared with actual after-first-configure snapshot; not historical compiled-content proof'})
    elif stage=='inspect':
        # Ninja dry-run cannot restat CMake's always-run VerifyGlobs edge, so
        # the main manifest stops at regeneration. Query its exact bytes under
        # a different filename: same cwd/rules/deps, no manifest output edge.
        query=B/'validation/query-manifests'/(attempt+'.ninja');query.parent.mkdir(parents=True,exist_ok=True)
        assert not query.exists();query.write_bytes((CACHE/'build.ninja').read_bytes())
        folder,receipt=execute(stage,attempt,[ninja,'-C',str(CACHE),'-f',str(query),'-n','hyle_kimi_kda_mla_probe'])
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
        spec=importlib.util.spec_from_file_location('kimi_preparation',B/'prepare-validation.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
        helper.inspect_ninja(folder)
        text=(folder/'stdout.log').read_text(errors='replace');lines=text.splitlines()
        actions=[l for l in lines if re.match(r'^\[\d+/\d+\]',l)]
        cxx=[l for l in actions if 'Building CXX object' in l];cuda=[l for l in actions if 'Building CUDA object' in l]
        unexpected=[l for l in cxx if not ('hyle_kimi_k3_component.dir' in l or 'hyle_kimi_kda_mla_probe.dir' in l)]
        allowed=len(cxx)==4 and not cuda and not unexpected
        expected=B/'validation/approved-unified-source-freeze.json'
        if expected.exists():
            approved=json.loads(expected.read_text())
            actual=sorted(l.split('Building CXX object ',1)[1].replace('\\','/') for l in unexpected)
            allowed=len(cxx)==approved['expected_total_cxx'] and not cuda and actual==approved['expected_sdk_objects']
        consumer_only=(B/'validation/approved-consumer-scalar-fix.json').exists()
        if consumer_only:
            allowed=len(cxx)==1 and not cuda and not unexpected and 'hyle_kimi_kda_mla_probe.dir' in cxx[0]
        ninja_text=(CACHE/'build.ninja').read_text();edge=next(l for l in ninja_text.splitlines() if l.startswith('build bin\\hyle.exe:'))
        assert 'kimi_k3' not in edge and 'kimi_kda_mla' not in edge
        result={'status':('EXPECTED_UNIFIED_44_CXX_PLAN' if expected.exists() else 'EXPECTED_FOUR_TU_PLAN') if allowed else 'STOP_UNEXPECTED_BUILD_PLAN','ninja':pin(CACHE/'build.ninja'),'actions':actions,
          'cxx':len(cxx),'cuda':len(cuda),'sdk_cxx':unexpected,'normal_qwen_link_edge':edge,'normal_qwen_has_kimi':False}
        result['query_manifest']=pin(query);result['query_same_bytes_as_normal_manifest']=query.read_bytes()==(CACHE/'build.ninja').read_bytes()
        if allowed and consumer_only:result['status']='EXPECTED_ONE_PROBE_CXX_PLAN'
        save(folder/'inspection.json',result);print(json.dumps({'inspection':result['status'],'cxx':len(cxx),'cuda':len(cuda),'unexpected':unexpected}))
        if not allowed:raise SystemExit(3)
    elif stage=='build':
        available=sorted((B/'validation/control/inspect').glob('attempt*/inspection.json'),key=lambda p:int(p.parent.name.removeprefix('attempt')))
        inspected=available[-1];report=json.loads(inspected.read_text());assert report['status'] in ['EXPECTED_FOUR_TU_PLAN','EXPECTED_UNIFIED_44_CXX_PLAN','EXPECTED_ONE_PROBE_CXX_PLAN']
        assert pin(CACHE/'build.ninja')==report['ninja'],'Ninja changed after inspection'
        folder,receipt=execute(stage,attempt,[CMAKE,'--build',str(CACHE),'--target','hyle_kimi_kda_mla_probe','--parallel','2'])
        text=(folder/'stdout.log').read_text(errors='replace');actions=[l for l in text.splitlines() if re.match(r'^\[\d+/\d+\]',l)]
        result={'receipt':receipt,'actions':actions,'cxx':sum('Building CXX object' in l for l in actions),'cuda':sum('Building CUDA object' in l for l in actions),'source_plan':pin(PLAN)}
        if not receipt['exit_code']:result['image']=pin(CACHE/'bin/hyle_kimi_kda_mla_probe.exe')
        save(folder/'result.json',result)
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
    else:raise ValueError(stage)
if __name__=='__main__':main()
