"""Root-authorized known-mtime perturbation; no compiler or native execution."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time
B=Path(__file__).resolve().parent;R=B.parents[1];CACHE=R/'.scratch/build-compute-v2-dev'
folder=B/'validation/private-source-impact';folder.mkdir(exist_ok=False)
source=R/'engine/models/kimi_k3/cold_graph.cc';before=source.read_bytes();stat=source.stat()
def pin():return {'path':str(source),'bytes':source.stat().st_size,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'mtime_ns':source.stat().st_mtime_ns}
manifest=(CACHE/'build.ninja').read_bytes();query=folder/'exact-query.ninja';query.write_bytes(manifest)
before_pin=pin();receipt={}
try:
    future=max(time.time_ns(),stat.st_mtime_ns+1_000_000_000)
    os.utime(source,ns=(stat.st_atime_ns,future));changed=pin();assert changed['sha256']==before_pin['sha256']
    command=[r'C:/Program Files/Python312/Scripts/ninja.exe','-C',str(CACHE),'-f',str(query),'-n','hyle_graph_route_cuda_kimi_heterogeneous_state_test']
    process=subprocess.run(command,cwd=R,capture_output=True);(folder/'stdout.log').write_bytes(process.stdout);(folder/'stderr.log').write_bytes(process.stderr)
    receipt={'command':command,'exit_code':process.returncode,'before':before_pin,'temporary':changed};assert process.returncode==0,process.stderr
    lines=process.stdout.decode(errors='replace').splitlines();actions=[x for x in lines if re.match(r'^\[\d+/\d+\]',x)]
    cxx=[x for x in actions if 'Building CXX object' in x];assert len(cxx)==1 and 'cold_graph.cc.obj' in cxx[0],cxx
    assert not any('Building CUDA object' in x for x in actions)
    receipt.update(actions=actions,cxx=1,consumer_cxx=0,other_model_cxx=0,sdk_cxx=0,cuda=0,
      expected_link_actions=[x for x in actions if 'Linking CXX' in x])
finally:
    assert source.read_bytes()==before,'Source content changed concurrently; never backdate unverified different bytes'
    os.utime(source,ns=(stat.st_atime_ns,stat.st_mtime_ns));receipt['after']=pin();receipt['restored_bytes_and_mtime_exact']=receipt['after']==before_pin
    (folder/'proof.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert receipt['restored_bytes_and_mtime_exact']
# Primary source is an explicit Ninja edge, not repeated in its header cache.
entries=[]
for line in manifest.decode().splitlines():
    if 'CXX_COMPILER_' in line and 'kimi_k3/cold_graph.cc' in line.replace('\\','/'):
        entries.append(line)
assert len(entries)==1
receipt['explicit_primary_source_edges']=entries
receipt['actual_header_deps_log']='validation/module-postbuild/1-deps.log'
receipt['scope']='Prediction from exact actual manifest and a temporary known source timestamp. No CXX/link/native run; original known source timestamp restored in finally.'
(folder/'proof.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'cxx':1,'consumer':0,'other_model':0,'sdk':0,'links':len(receipt['expected_link_actions']),'mtime_restored':True}))
