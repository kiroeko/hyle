# 独立源码复核（14-file V1）

审查对象是冻结 `kimi-component.patch`：140405B，SHA `cd5ae6154f578dbfa302bf0e1b019a9db72e99d3bdac0964def528485a3364fb`。只读；无产品修改、CXX、链接、原生/模型运行或网络。没有把作者的 37 项 token 相同当成 emitted Graph 或数值证据。

结论：数学及原 owner/事务迁移未发现新的静态阻断；但 V1 有两个必须修补的问题，已通知 root/作者。修补前不能写整体候选通过。

## 两项阻断

1. `tests/graph_route_cuda/CMakeLists.txt:154–160` 的原 Kimi GTest target 没有链接新增模型 cc/组件。迁移后该 TU 的 Run/State/roles/layout 方法已变为外部符号，而新组件只在 engine 子目录注册，module-only CUDA tests 可能没有该 target。手工添加三个模型对象不能代签正常测试入口。最小修正是模型-owned 单一 source inventory、engine/module-only 均可达且幂等的私有目标，再给真实消费 target 接线；不让 module-only 配置进入整个 engine。库本身现用五个 SDK 产品 alias，compute 产品已包含 compute_state，并未据名字误报缺 state SDK。
2. 原 `Run::finish` 的 `reset()` 后故意 `submit` 并要求失败的 stale-replay 负检查，被外移时完全删除；V1 GTest 和新薄 probe 没有对应检查。保留为消费者关注不能只写注释。最小修正是在 test-derived Run 的 finish 包装中调用产品 finish 后，借同一原 carrier Invocation 检查 reset 后的 submit 被拒绝，再返回结果；不往产品热路径塞故意无效 submit。其它原数值、cursor、完整状态、old-reader/fork/cancel/stale-base 断言及容差未发现放宽。

## 实际 lowering 的源码核对

独立读取了旧 `Fragment::append`、`sem::make_graph`、`Run::prepare/prepare_original_kda/prepare_original_mla`，以及公共 `GraphBuilder::input/constant/add_node/result/publish`，再对照新 Assembly。旧 lowering 不重写数学：它先声明所有 inputs/constants，随后按原 node 顺序传同一个 Operation 和映射后的有序 ports 给 GraphBuilder。新 Assembly 在 emit 时立即作同一 add_node/result，保存的 descriptions 只是冷类型事实，没有第二 node list/执行 IR。

- 原 KDA inputs 仍是 `[1,7168]`、`[3,36864]`、`[1,96,128,128]`；MLA inputs 仍是 hidden、完整 `[4,576]` cache、I32 cursor。MLA cursor 在新 builder 中创建较晚，因此 raw ValueId 变化是实质编号差异，不能要求未经规范化的 ID 相同；端口来源仍是相同 input ordinal/constant ordinal/producer result。
- KDA 的八个 BF16 projection 均保输入 BF16 Cast + `DenseLinearF32`；不是把 BF16 权重改成 F32 MatMul。Q/K/V join、history window、Gather 选行、causal_conv1d、separate GatedActivation、Q/K L2 的 `epsilon=1e-5/128` 与 `1/sqrt(128)` scale、96 个 A_log 选行及 Exp、`sigmoid((fb+dt)*exp(A))*-5`、beta sigmoid、GatedDeltaNet 六输入和两个输出顺序、output RMSNorm 与 sigmoid gate 都相同。末尾每个结果仍单独 Copy 后作为 caller output。
- MLA 保 norm BF16→F32 参数 Cast、五个 BF16 projection 边界、KV-b 的逐 head K 转置/V原行序、GroupedMatMul 的 `{weight,input,head_ids}` 顺序。Scatter 仍以 `{past,position,current}` 写完整 successor cache；attention 只读正 visible 前缀。NoPE Q/K 拼接、SDPA `scale=1/sqrt(192), causal=true, accumulation=F32` 与 Q/K/V 的 reshape 不变；无 RoPE 新增/省略。cursor 仍用原 Concat→Scan→Gather，非主机推算。
- learned 常量顺序仍 KDA12/MLA10；QKV convolution 原 F32 tap 顺序、A/dt reshape 和 KV-b BF16 bits/layout 不变。新 `Assembly.constant` 的 LiteralBank slot 仍取包括 learned prefix 的常量序号，等价旧 `Run::prepare` 的 i，不是从0重新编号 generated literals。
- 据固定官方 BF16分支逐项展开的**源码预期**：KDA 56 个节点（含6 Copy）、20常量/3输入；MLA 58 个节点（含10 Copy）、20常量/3输入。尚未运行 Graph 来证明这些实际计数。直接 publish 发生在各 Copy 之后而非所有 Copy 后统一 publish；公共 publish 仅追加原输出ID，不发节点或禁止继续建图，因此输出顺序和依赖不变。
- 真实行为差异：小 generated literal 的上传从旧 Graph finish 后提前到冷 emit 中。失败时未发布 Program/Phase；局部 GraphDefinition 会释放其 leases，但调用者原 LiteralBank 可保留已插入的小 literal cache，旧版在后续 literal 上传失败时也有这种部分 cache。不能声称所有失败的 native 分配顺序或冷峰值完全未变，需后续有限验证。

## State / Carrier / IO / 失败寿命

`State::candidate` 六项映射逐一对照旧实际 complete draft：history←KDA0，recurrent←KDA2，完整 MLA cache←MLA0，cursor←MLA9，feature←MLA6，host Epoch←调用者原 Epoch。仍从原 before `StateStore::begin`、replace 后 finalize，返回未发布 version；Head.publish 和数值校验继续由原消费者做。max_versions12/max_drafts3/max_retained_blocks128、snapshot cap4096、未写 cache poison bits不变。

Program 的 backend、logical Graph、literal leases、CompiledGraph、ProgramIo 先于原 carrier 声明，逆析构先撤 carrier/Invocation，再 IO/compiled/literals/logical，Backend 最后；同一个稳定 make_shared 对象直接嵌 compiled/io，替代 test ColdProgram 的唯一冷 holder。test-derived Run 的 `enable_shared_from_this<Program>` 使用同一个 make_shared 控制块，不产生第二 owner/Run。产品不保存 Fragment；测试保留的 Fragment 只作 oracle facts/测试 Graph 构造。

Pending 仍保原 Program/Episode，析构只对自己的当前 pending 调原 recovery。输入 bind 失败走同 Invocation reset/重试；已有 Source 或接受提交后仍先退 consumer，再按 predecessor gate 退 producer；未知退休保留原 pending。Source 仍是原 hidden output5→MLA input0、完整 writer same generation/backing、consumer 先于 producer host observation，原 capture reuse/zero new record/host-wait 检查未删。finish 除上述遗漏的故意无效 submit 外，仍原 retain outputs→reset，同一 carrier 无额外 Completion 或状态 owner。

尚未证明：独立 CXX/链接、规范化后的实际 emitted Graph/constant bytes、真实数值、Source/capture/部分失败退休、跨平台及所有受影响原 target。范围仅固定 KDA0→NoPE MLA3，不能推广为完整 Kimi 模型或 token/MTP 引擎。
