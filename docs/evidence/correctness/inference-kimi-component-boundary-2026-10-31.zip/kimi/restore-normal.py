"""Restore the original public engine cache, then inspect without building."""
from pathlib import Path
import hashlib,importlib.util,json,re,sys
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('normal_control',B/'normal-build.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
plan=json.loads((B/'module-transition-plan.json').read_text())
stage,attempt=sys.argv[1:3]
if stage=='configure':
    before=c.values();assert before['HYLE_COMPONENTS']=='graph' and before['HYLE_BUILD_TESTS']=='ON'
    folder,receipt=c.execute('restore-configure',attempt,plan['commands']['restore_engine'])
    if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
    after=c.values();original=json.loads((B/'validation/original-normal-config.json').read_text())
    keys=['CMAKE_CXX_COMPILER','CMAKE_CUDA_COMPILER','CMAKE_BUILD_TYPE','CMAKE_CUDA_ARCHITECTURES','HYLE_COMPONENTS','HYLE_BUILD_TESTS','HYLE_COMPUTE_ROUTES','HYLE_STATIC','HYLE_TRACE','HYLE_TEST_INSTRUMENTATION','HYLE_SANITIZER','FETCHCONTENT_FULLY_DISCONNECTED','FETCHCONTENT_UPDATES_DISCONNECTED']
    assert all(after.get(k)==original.get(k) for k in keys),{k:[original.get(k),after.get(k)] for k in keys if original.get(k)!=after.get(k)}
    assert 'HYLE_DEV_FACTORS' not in after
    generated=json.loads((c.R/'.scratch/inference-simd-configure-dirty-20261031/normal-generated-before-fix.json').read_text())['files']
    for row in generated:
        p=Path(row['path']);assert c.pin(p)['sha256']==row['sha256'] and p.stat().st_mtime_ns==row['mtime_ns']
    c.save(folder/'restoration.json',{'same_original_configuration':True,'compared_keys':keys,'configuration':after,'all_29_generated_bytes_and_mtimes_unchanged':True,'built':False})
elif stage=='inspect':
    cache=c.values();assert cache['HYLE_COMPONENTS']=='engine' and cache['HYLE_BUILD_TESTS']=='OFF'
    manifest=(c.CACHE/'build.ninja').read_bytes();query=B/'validation/query-manifests'/('restore-'+attempt+'.ninja');assert not query.exists();query.write_bytes(manifest)
    text=manifest.decode();edge=next(l for l in text.splitlines() if l.startswith('build bin\\hyle.exe:'))
    assert 'kimi_k3' not in edge
    reports=[]
    for target in ['hyle_engine','hyle_kimi_kda_mla_probe']:
        folder,receipt=c.execute('restore-inspect-'+target,attempt,[cache['CMAKE_MAKE_PROGRAM'],'-C',str(c.CACHE),'-f',str(query),'-n',target])
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
        actions=[l for l in (folder/'stdout.log').read_text(errors='replace').splitlines() if re.match(r'^\[\d+/\d+\]',l)]
        cxx=[l for l in actions if 'Building CXX object' in l];cuda=[l for l in actions if 'Building CUDA object' in l]
        row={'target':target,'actions':actions,'cxx':len(cxx),'cuda':len(cuda),'sdk_cxx':[l for l in cxx if 'hyle_kimi_k3_component.dir' not in l and 'hyle_kimi_kda_mla_probe.dir' not in l],
          'manifest':c.pin(c.CACHE/'build.ninja'),'query_manifest':c.pin(query),'query_exact':query.read_bytes()==manifest,'build_executed':False}
        c.save(folder/'inspection.json',row);reports.append(row)
    c.save(B/'validation/restoration-summary.json',{'configuration_restored':True,'normal_qwen_has_kimi':False,'normal_qwen_link_edge':edge,'reports':reports,'status':'RESTORED_INSPECTED_NO_BUILD'})
    print(json.dumps([{'target':r['target'],'cxx':r['cxx'],'cuda':r['cuda'],'sdk_cxx':r['sdk_cxx']} for r in reports]))
else:raise ValueError(stage)
