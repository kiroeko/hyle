"""One original two-step probe, only when root separately authorizes native."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
B=Path(__file__).resolve().parent;R=B.parents[1];CACHE=R/'.scratch/build-compute-v2-dev'
def pin(path):
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':digest}
def main():
    attempt=sys.argv[1];name=B/'validation/runtime'/attempt;name.mkdir(parents=True,exist_ok=False)
    source=json.loads((B/'candidate-plan-v3.json').read_text());pins=[];overrides={};seen=set()
    for path in sorted((B/'validation').glob('approved-consumer-*.json')):
        for row in json.loads(path.read_text())['source_pins']:overrides[str(Path(row['path']).resolve())]=row
    for row in source['files']:
        path=R/row['path'];identity=pin(path);expected=overrides.get(str(path.resolve()),row['candidate']);assert identity['bytes']==expected['bytes'] and identity['sha256']==expected['sha256'],row['path'];pins.append(identity);seen.add(str(path.resolve()))
    for key,row in overrides.items():
        if key not in seen:
            identity=pin(Path(row['path']));assert identity==row; pins.append(identity)
    receipts=sorted((B/'validation/control/build').glob('attempt*/result.json'),key=lambda p:int(p.parent.name.removeprefix('attempt')))
    build_receipt=receipts[-1];built=json.loads(build_receipt.read_text());assert built['receipt']['exit_code']==0
    image=CACHE/'bin/hyle_kimi_kda_mla_probe.exe';assert pin(image)==built['image']
    ready_path=B/'validation/postbuild'/build_receipt.parent.name/'ready.json';ready=json.loads(ready_path.read_text())
    assert ready['backend_layout_identical']
    for identity in ready['current_sdk_not_old_baseline']+ready['four_compiled_sources']+ready['four_compiled_objects']:
        assert pin(Path(identity['path']))==identity,identity['path']
    common=json.loads((B/'validation/approved-unified-source-freeze.json').read_text())
    for identity in common['source_pins']:assert pin(Path(identity['path']))==identity
    module=R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py'
    spec=importlib.util.spec_from_file_location('kimi_normal_runtime_observer',module);observer=importlib.util.module_from_spec(spec);spec.loader.exec_module(observer)
    observer.HERE=name;observer.ROOT=R;observer.CACHE=CACHE;observer.IMAGE=image
    env=dict(os.environ);env.update(json.loads((R/'.scratch/inference-default-product-build-20261031/environment.json').read_text()))
    for key in ['CL','_CL_','CFLAGS','CXXFLAGS','LDFLAGS','CUDAFLAGS','CUDAARCHS','CUDACXX','CXX','CC','TORCH_INSTALL_PREFIX','CMAKE_PREFIX_PATH']:env.pop(key,None)
    temporary=B/'validation/tmp';temporary.mkdir(exist_ok=True);env['TEMP']=env['TMP']=str(temporary)
    input=R/'.scratch/inference-kimi-original-binding-20261025/payload-only/attempt1'
    command=[str(image),str(input),str(name/'vectors')]
    manifest=pin(input/'original-role-pins.txt');original_input=json.loads((B/'validation/normal-attempt1/plan.json').read_text())['input']
    assert manifest==original_input['pins']
    for part in original_input['parts']:assert Path(part['path']).stat().st_size==part['bytes']
    (name/'inputs.json').write_text(json.dumps({'image':pin(image),'sources':pins,'observer_script':pin(module),'command':command,'output_directory':str(name/'vectors'),
      'normal_shared_build':pin(build_receipt),'ready_receipt':pin(ready_path),'normal_sdk':ready['current_sdk_not_old_baseline'],'four_compiled_sources':ready['four_compiled_sources'],
      'common_source_pins':common['source_pins'],'input_manifest':manifest,'expected_source_identity':original_input,'authentication':'Probe Data::load performs union+role SHA/finiteness validation before native use'},indent=2)+'\n')
    error=None
    try:folder,process=observer.execute('two-step',command,env)
    except Exception as caught:
        error=str(caught);folder=name/'checks/two-step/attempt1';process=json.loads((folder/'process.json').read_text())
    runtime=[]
    for value in process.get('observed_modules',[]):
        path=Path(value)
        if path.name.lower().startswith(('hyle_','ggml')):
            runtime.append(pin(path));assert 'gdn_scale_v3' not in path.name.lower()
            assert path.resolve().is_relative_to((CACHE/'bin').resolve()),'Unexpected Hyle runtime outside the normal bin'
    summary={'process':process,'loaded_normal_runtime':runtime,'observation_scope':'10ms PSAPI samples; may see limited error299, not a complete loader/kernel trace','native_error':error}
    if process['exit_code']==0:
        lines=(folder/'stdout.log').read_text().splitlines();actual=json.loads(next(line for line in reversed(lines) if line.startswith('{')))
        assert actual['result']=='pass' and actual['full_model'] is False and actual['steps']==2 and actual['committed']==2
        assert actual['stale_refused']==2 and actual['cancelled']==1 and actual['bind_refused']==1 and actual['state_versions']==0
        summary['actual_report']=actual
    (name/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'exit_code':process['exit_code'],'runtime_modules':len(runtime),'summary':str(name/'summary.json')}))
    if process['exit_code']:raise SystemExit(process['exit_code'])
if __name__=='__main__':main()
