"""Seal only the authorized Kimi component correctness evidence; no build/native."""
from pathlib import Path
import difflib,hashlib,importlib.util,json,re,subprocess,zipfile
B=Path(__file__).resolve().parent;R=B.parents[1]
spec=importlib.util.spec_from_file_location('normal_control',B/'normal-build.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
E=B/'evidence-final';E.mkdir(exist_ok=True)
base=json.loads((B/'candidate-plan-v3.json').read_text())['base_head']
paths=[r['path'] for r in json.loads((B/'candidate-plan-v3.json').read_text())['files']]
paths+=['tests/compute_models/original_scalar_reference.h','tests/compute_models/kimi_original_attention_reference.h','tests/compute_state/CMakeLists.txt']
assert len(paths)==len(set(paths))
source_rows=[];patch=[]
for name in sorted(paths):
    result=subprocess.run(['git','show',base+':'+name],cwd=R,capture_output=True)
    old=result.stdout if result.returncode==0 else b''
    current=(R/name).read_bytes();destination=E/'current-source'/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(current)
    source_rows.append({'path':name,'base':{'bytes':len(old),'sha256':hashlib.sha256(old).hexdigest()} if result.returncode==0 else None,
      'current':{'bytes':len(current),'sha256':hashlib.sha256(current).hexdigest()}})
    if old==current:continue
    patch.append('diff --git a/'+name+' b/'+name+'\n')
    if result.returncode:patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),current.decode().splitlines(keepends=True),
      fromfile='a/'+name if result.returncode==0 else '/dev/null',tofile='b/'+name))
patch_path=E/'final-source.patch';patch_path.write_bytes(''.join(patch).encode())
reverse=subprocess.run(['git','apply','--reverse','--check',str(patch_path)],cwd=R,capture_output=True)
assert reverse.returncode==0,reverse.stderr.decode(errors='replace')
(E/'source-reverse-check.log').write_bytes(reverse.stdout+reverse.stderr)
c.save(E/'source-pins.json',{'base_head':base,'files':source_rows,'patch':c.pin(patch_path),'reverse_apply_check':0,
  'scope':'Kimi 17-file migration plus pure scalar fixture header fix and module test-owner metadata. SDK/Graph fixes are separate historical inputs.'})
restoration=json.loads((B/'validation/restoration-summary.json').read_text());assert restoration['configuration_restored']
assert all(r['cxx']==0 and r['cuda']==0 for r in restoration['reports'])
normal=json.loads((B/'validation/runtime/attempt2/summary.json').read_text())
module=json.loads((B/'validation/module-native/attempt1/summary.json').read_text())
assert normal['process']['exit_code']==0 and module['process']['exit_code']==0 and module['gtest']==dict(module['gtest'],tests=1,failures=0,skips=0)
vectors=json.loads((B/'validation/native-attempt2-vector-manifest.json').read_text());assert vectors['file_count']==32 and vectors['total_bytes']==15378440
for row in vectors['files']:
    p=B/row['path'];assert p.stat().st_size==row['bytes']
builds=[]
for stage in ['build','module-build']:
    for path in sorted((B/'validation/control'/stage).glob('attempt*/result.json')):
        value=json.loads(path.read_text());text=(path.parent/'stdout.log').read_text(errors='replace')
        actions=[l for l in text.splitlines() if re.match(r'^\[\d+/\d+\]',l)]
        builds.append({'stage':stage,'attempt':path.parent.name,'exit_code':value['receipt']['exit_code'],
          'cxx':sum('Building CXX object' in l for l in actions),'nvcc':sum('Building CUDA object' in l for l in actions),
          'links':sum('Linking CXX' in l for l in actions),'receipt':str(path.relative_to(B))})
assert sum(r['cxx'] for r in builds)==52 and sum(r['links'] for r in builds)==9 and sum(r['nvcc'] for r in builds)==0
processes=[]
for path in sorted((B/'validation/control').glob('*/*/process.json')):
    value=json.loads(path.read_text());assert value.get('state','TERMINAL')=='TERMINAL' and 'exit_code' in value
    processes.append({'stage':path.parents[1].name,'attempt':path.parent.name,**value})
for scope in ['runtime','module-native']:
    for path in sorted((B/'validation'/scope).glob('attempt*/summary.json')):
        value=json.loads(path.read_text());processes.append({'stage':scope,'attempt':path.parent.name,**{k:v for k,v in value['process'].items() if k in ['pid','state','exit_code','start_utc','end_utc']}})
c.save(E/'process-inventory.json',{'scope':'Owned configure/query/build/CTest top-level processes plus real native children; CXX/link counts separately come from actual Ninja actions.',
  'processes':processes,'ninja_build_actions':builds})
historical=json.loads((B/'validation/approved-unified-source-freeze.json').read_text())
final_graph=R/'.scratch/inference-captured-graph-copy-20261031/final-source-freeze.json'
summary={'schema':'HYLE_CORRECTNESS_EVIDENCE_V1','date':'2026-10-31','result':'PASS_WITH_RETAINED_FAILED_ATTEMPTS',
  'scope':{'component':'Original Kimi K3 KDA layer0 to NoPE MLA layer3, two-step stateful component','full_model':False,
    'not_proved':['Intervening layers1/2, residual/FFN/head or token generation','Complete Kimi model or Kimi MTP','All model/backend configurations or decode performance'],
    'architecture':'Model-private compiled GraphBuilder math and six-entry complete state; original ProgramIo/Carrier/Episode/LeasePool/StateVersion and Graph execution owners. No GTest, Qwen main or semantic Fragment in model implementation.'},
  'source':{'base_head':base,'files':len(source_rows),'patch':'final-source.patch','source_pins':'source-pins.json',
    'math_and_state_projection':'37 static original/new token checks passed; static result is separate from actual native checks',
    'five_model_cpp_files_unchanged_from_v3':True},
  'normal_shared_build':{'cache':str(c.CACHE),'components':'engine','routes':'cpu;cuda','configuration':'Release/shared, testsOFF, DEV_FACTORS absent, trace/instrumentation/sanitizer off, fully offline',
    'sdk_cxx_actual':40,'sdk_cxx_breakdown':{'simd_from_pre_fix_generated_mtime_churn':38,'graph_capture_copy_fix':2},
    'all_build_attempts':builds,'total_cxx_actions':52,'total_link_actions':9,'total_nvcc_actions':0,
    'historical_graph_scope':'Both successful Kimi native checks used executable.cc +7 and resources.cc +6 (13-line candidate); exact source/DLL/import pins retained. Later resources six-line unreachable branch was reverted; no claim that Kimi was rerun against the final seven-line SDK.',
    'final_graph_scope_reference':'external/graph-copy/final-source-freeze.json'},
  'native':{'thin_probe':{'attempt':'attempt2','pid':normal['process']['pid'],'exit_code':0,'report':normal['actual_report'],
      'vector_files':32,'vector_bytes':15378440,'vector_manifest':'kimi/validation/native-attempt2-vector-manifest.json','raw_vectors_in_zip':False},
    'public_graph_module':{'components':'graph','routes':'cpu;cuda','engine_target_absent':True,'tests':1,'failures':0,'skips':0,
      'filter':'KimiHeterogeneousState.CudaOriginalParametersKdaMlaKeepCompleteStateAcrossContinuation','pid':module['process']['pid'],
      'original_assertions':'Existing six/nine outputs, actual F64 projection certificates, complete state feedback, old readers/fork/cancel/stale, Source submission before host observation and stale reset-submit rejection preserved.'},
    'configure_ctests':{'hyle_engine_components_test':'PASS','hyle_simd_configure_generation_test':'PASS'},
    'runtime_observation':'Actual loaded normal shared runtime DLL paths/SHA retained; finite 10ms PSAPI observations may contain error299 and are not a complete loader/kernel trace.'},
  'isolation':{'all_four_tu_backend_macros':{'HYLE_COMPUTE_CPU':1,'HYLE_COMPUTE_CUDA':1},
    'model_impl_forbidden_actual_header_deps':0,'private_cold_edit_prediction':{'cold_cxx':1,'consumer_cxx':0,'other_model_cxx':0,'sdk_cxx':0,'nvcc':0,'source_bytes_and_known_mtime_restored':True},
    'normal_qwen_has_kimi_link_dependency':False,'same_cache_restored':True,'restore_prediction':{'engine_cxx':0,'kimi_cxx':0,'sdk_cxx':0,'nvcc':0},
    'same_configuration_generated_sources':{'files':29,'bytes_and_mtimes_stable_after_fix':True}},
  'retained_failures':[
    {'stage':'normal build attempt1','exit_code':2,'detail':'Probe included old GLM test reference with four ADD_FAILURE calls but no GTest. Pure scalar block extracted; GLM GTest diagnostics restored, probe kept GTest-free.'},
    {'stage':'thin native attempt1','exit_code':1,'detail':'New probe wrongly expected InvalidArgument for 4-byte MLA cache view. Original public contract/GTest requires OutOfRange; corrected strict status/no-native/observed-retired requirements without changing original model math.'},
    {'stage':'module configure attempt1','exit_code':1,'detail':'Existing compute_state native_fault_consumer lacked HYLE_TEST_MODULE owner; only metadata corrected, original aggregate/CTest retained.'}],
  'preparation_notes':['Initial main-manifest Ninja dry-run only exposed VerifyGlobs/regeneration; byte-exact query manifests then exposed actual actions.',
    'Initial module dependency postprocessor incorrectly expected the primary source in the header cache; corrected proof uses the explicit actual source edge plus actual header dependencies. No build/native rerun for this note.'],
  'input':{'fixed_revision':'f831ab66814297da540d832a5235f8e904f29d06','cached_union_parts':4,'union_bytes':1352207360,'authenticated_roles':23,
    'authentication':'Real Data.load verifies fixed source identities, each union/role SHA and finite coefficients. No payload/model copied into evidence.'},
  'downloads':0,'performance_claim':False,'archive':None}
c.save(E/'verification-summary.json',summary)
files={}
def add(path,arc):
    path=Path(path);assert path.is_file(),path
    assert not any(part in ['vectors','__pycache__','tmp'] for part in path.parts)
    assert path.suffix.lower() not in ['.obj','.dll','.lib','.exe','.bin','.pdb','.pyc','.zip']
    data=path.read_bytes();assert len(data)<5_000_000,(path,len(data));assert arc not in files,arc;files[arc]=data
for path in E.rglob('*'):
    if path.is_file():add(path,str(path.relative_to(E)).replace('\\','/'))
for name in ['candidate-plan-v3.json','kimi-component-v3.patch','independent-review-bridge-v3.json','independent-review-bridge.md','static-review-final.json','include-closure-final.json','sources.json',
  'normal-build.py','runtime-runner.py','module-validation.py','module-runner.py','module-transition-plan.json','predict-private-source-impact.py','restore-normal.py','prepare-validation.py','collect-evidence.py']:
    add(B/name,'kimi/'+name)
for dirname in ['module-cmake-facade','scalar-reference-fix','short-cache-expectation-fix','module-state-owner-fix']:
    for path in (B/dirname).rglob('*'):
        if path.is_file() and path.suffix.lower() in ['.json','.patch','.h','.cc','.txt']:add(path,'kimi/'+str(path.relative_to(B)).replace('\\','/'))
for path in (B/'validation').rglob('*'):
    if not path.is_file() or path.suffix.lower() not in ['.json','.log','.xml','.txt']:continue
    relative=path.relative_to(B/'validation');parts=relative.parts
    if parts[0] not in ['control','runtime','module-native','module-postbuild','postbuild','private-source-impact'] and len(parts)!=1:continue
    if parts[0]=='formal-graph-recipes' or any(p in ['vectors','tmp','query-manifests'] for p in parts):continue
    if path.name in ['normal-verification-summary.json','original-normal-CMakeCache.txt']:continue
    if path.name in ['configuration-after.json'] and parts[0]=='control':continue
    add(path,'kimi/validation/'+str(relative).replace('\\','/'))
add(c.R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py','external/normal-runtime/inspect-smoke.py')
add(c.R/'.scratch/inference-kimi-original-binding-20261025/payload-only/attempt1/original-role-pins.txt','input/original-role-pins.txt')
for name in ['source-freeze.json','graph-copy.patch','final-source-freeze.json','final-graph-copy.patch','resources-branch-reachability.md']:
    add(final_graph.parent/name,'external/graph-copy/'+name)
for name in ['summary.json','simd-configure-stability.patch','normal-generated-before-fix.json']:
    add(c.R/'.scratch/inference-simd-configure-dirty-20261031'/name,'external/simd-configure/'+name)
manifest={'scope':'Every payload member is listed; manifest.json is excluded from its own recursive hash. ZIP SHA pins the whole archive.',
  'members':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(files.items())]}
files['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
destination=R/'docs/evidence/correctness/inference-kimi-component-boundary-2026-10-31.zip';assert not destination.exists();destination.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(files.items()):
        entry=zipfile.ZipInfo(name,(2026,10,31,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(entry,raw)
with zipfile.ZipFile(destination) as archive:
    assert len(archive.infolist())==len(files)
    assert archive.testzip() is None
    for name,raw in files.items():assert archive.read(name)==raw,name
identity=c.pin(destination);summary['archive']={'path':str(destination.relative_to(R)).replace('\\','/'),'bytes':identity['bytes'],'sha256':identity['sha256'],
  'members':len(files),'payload_members':len(manifest['members']),'all_members_readback_bytes_and_sha_verified':True,'excludes':'Models, SDK copies, DLL/object/executable binaries and raw vectors'}
public=destination.with_suffix('.json');assert not public.exists();c.save(public,summary)
c.save(E/'readback.json',{'public':c.pin(public),'zip':identity,'members':len(files),'all_bytes_exact':True,'member_sha_verified':True})
print(json.dumps({'json':c.pin(public),'zip':identity,'members':len(files),'cxx':52,'links':9,'nvcc':0,'native_attempts':3,'native_failures_retained':1}))
