"""The one canonical Kimi case, followed by the two named configure-only CTests."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
B=Path(__file__).resolve().parent;R=B.parents[1];CACHE=R/'.scratch/build-compute-v2-dev'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
control=load('kimi_module_control',B/'normal-build.py')
def main():
    stage,attempt=sys.argv[1:3];cache=control.values();assert cache['HYLE_COMPONENTS']=='graph' and cache['HYLE_BUILD_TESTS']=='ON'
    if stage=='native':
        built=json.loads((B/'validation/control/module-build/attempt1/result.json').read_text());assert built['receipt']['exit_code']==0
        name=B/'validation/module-native'/attempt;name.mkdir(parents=True,exist_ok=False)
        image=CACHE/'bin/hyle_graph_route_cuda_kimi_heterogeneous_state_test.exe';assert control.pin(image)==built['image']
        plan=json.loads((B/'module-transition-plan.json').read_text());command=plan['commands']['module_native'][:-1]+['--gtest_output=xml:'+str(name/'results.xml')]
        env=dict(os.environ);env.update(json.loads((R/'.scratch/inference-default-product-build-20261031/environment.json').read_text()));env.update(plan['commands']['module_environment'])
        for key in ['CL','_CL_','CFLAGS','CXXFLAGS','LDFLAGS','CUDAFLAGS','CUDAARCHS','CUDACXX','CXX','CC','TORCH_INSTALL_PREFIX','CMAKE_PREFIX_PATH']:env.pop(key,None)
        temp=B/'validation/tmp';env['TEMP']=env['TMP']=str(temp)
        sdk=[control.pin(CACHE/'bin'/x) for x in ['hyle_graph.dll','hyle_graph.lib','hyle_simd.dll','hyle_kimi_k3_component.lib']]
        control.save(name/'inputs.json',{'command':command,'image':control.pin(image),'source_pins':control.sources(),'sdk':sdk,'input_directory':plan['commands']['module_environment'],'module_inspection':control.pin(B/'validation/control/module-inspect/attempt1/inspection.json')})
        observer=load('kimi_module_runtime_observer',R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py');observer.HERE=name;observer.IMAGE=image;observer.ROOT=R;observer.CACHE=CACHE
        error=None
        try:folder,process=observer.execute('original-case',command,env)
        except Exception as caught:
            error=str(caught);folder=name/'checks/original-case/attempt1';process=json.loads((folder/'process.json').read_text())
        result={'process':process,'error':error,'observed_normal_runtime':[]}
        for path in process.get('observed_modules',[]):
            value=Path(path)
            if value.name.lower().startswith(('hyle_','ggml')):
                assert value.resolve().is_relative_to((CACHE/'bin').resolve());assert 'gdn_scale_v3' not in value.name.lower();result['observed_normal_runtime'].append(control.pin(value))
        if process['exit_code']==0:
            xml=ET.parse(name/'results.xml').getroot();tests=int(xml.attrib.get('tests',0));failures=int(xml.attrib.get('failures',0));skips=int(xml.attrib.get('disabled',0))
            skips+=len(xml.findall('.//skipped'));assert tests==1 and failures==0 and skips==0,(tests,failures,skips)
            result['gtest']={'tests':tests,'failures':failures,'skips':skips,'xml':control.pin(name/'results.xml')}
            result['properties']={p.attrib['name']:p.attrib.get('value','') for p in xml.findall('.//property')}
        control.save(name/'summary.json',result);print(json.dumps({'exit_code':process['exit_code'],'summary':str(name/'summary.json')}))
        if process['exit_code']:raise SystemExit(process['exit_code'])
    elif stage=='ctest':
        cmake=Path('C:/Program Files/CMake/bin/ctest.exe');command=[str(cmake),'--test-dir',str(CACHE),'-R','^(hyle_simd_configure_generation_test|hyle_engine_components_test)$','--output-on-failure','--no-tests=error','-j','1']
        folder,receipt=control.execute('module-ctest',attempt,command)
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
    else:raise ValueError(stage)
if __name__=='__main__':main()
