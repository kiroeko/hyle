"""Same-cache public module configuration/query; native requires root stage approval."""
from pathlib import Path
import hashlib,importlib.util,json,re,sys
B=Path(__file__).resolve().parent;R=B.parents[1];CACHE=R/'.scratch/build-compute-v2-dev'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
control=load('kimi_normal_control',B/'normal-build.py')
helper=load('kimi_preparation',B/'prepare-validation.py')
def main():
    stage,attempt=sys.argv[1:3];plan=json.loads((B/'module-transition-plan.json').read_text());cache=control.values()
    assert cache['HYLE_COMPUTE_ROUTES']=='cpu;cuda' and cache['HYLE_STATIC']=='OFF' and 'HYLE_DEV_FACTORS' not in cache
    if stage=='configure':
        assert (cache['HYLE_COMPONENTS'],cache['HYLE_BUILD_TESTS']) in [('engine','OFF'),('graph','ON')]
        folder,receipt=control.execute('module-configure',attempt,plan['commands']['module_configure'])
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
        after=control.values();assert after['HYLE_COMPONENTS']=='graph' and after['HYLE_BUILD_TESTS']=='ON'
        original=json.loads((B/'validation/original-normal-config.json').read_text())
        unchanged=['CMAKE_CXX_COMPILER','CMAKE_CUDA_ARCHITECTURES','HYLE_COMPUTE_ROUTES','HYLE_STATIC','HYLE_TRACE','HYLE_TEST_INSTRUMENTATION','HYLE_SANITIZER','FETCHCONTENT_FULLY_DISCONNECTED','FETCHCONTENT_UPDATES_DISCONNECTED']
        assert all(after.get(k)==original.get(k) for k in unchanged)
        control.save(folder/'configuration-after.json',after)
        before=json.loads((R/'.scratch/inference-simd-configure-dirty-20261031/normal-generated-before-fix.json').read_text())['files']
        for row in before:
            path=Path(row['path']);raw=path.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and path.stat().st_mtime_ns==row['mtime_ns']
        control.save(folder/'simd-generated-stability.json',{'all_29_bytes_and_mtimes_unchanged':True,'scope':'same CPU target set, compared to actual after-first-configure snapshot'})
    elif stage=='inspect':
        assert cache['HYLE_COMPONENTS']=='graph' and cache['HYLE_BUILD_TESTS']=='ON'
        manifest=(CACHE/'build.ninja').read_bytes();query=B/'validation/query-manifests'/('module-'+attempt+'.ninja');assert not query.exists();query.write_bytes(manifest)
        target='hyle_graph_route_cuda_kimi_heterogeneous_state_test'
        folder,receipt=control.execute('module-inspect',attempt,[cache['CMAKE_MAKE_PROGRAM'],'-C',str(CACHE),'-f',str(query),'-n',target])
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
        helper.inspect_ninja(folder)
        generated=json.loads((folder/'generated-command-and-macro-plan.json').read_text())
        assert generated['component_cxx']==3 and generated['probe_cxx']==0 and generated['optional_gtest_cxx']==1
        ninja=manifest.decode();assert not re.search(r'^build bin[\\/]hyle.exe:',ninja,re.M),'Module configuration retained the engine'
        rows=generated['translation_units'];assert all(row['backend_layout_macros']=={'HYLE_COMPUTE_CPU':'1','HYLE_COMPUTE_CUDA':'1'} for row in rows)
        text=(folder/'stdout.log').read_text(errors='replace');actions=[l for l in text.splitlines() if re.match(r'^\[\d+/\d+\]',l)]
        cxx=[l for l in actions if 'Building CXX object' in l];cuda=[l for l in actions if 'Building CUDA object' in l]
        known=('hyle_kimi_k3_component.dir','hyle_graph_route_cuda_kimi_heterogeneous_state_test.dir','gtest.dir','gtest_main.dir')
        extra=[l for l in cxx if not any(name in l for name in known)]
        result={'status':'AWAIT_ROOT_BUILD_REVIEW','actions':actions,'cxx':len(cxx),'cuda':len(cuda),'sdk_cxx':extra,
          'all_4_backend_layouts_identical':True,'backend_layout_macros':rows[0]['backend_layout_macros'],'engine_target_absent':True,
          'actual_gtest_link':generated['links'][target],'normal_manifest':control.pin(CACHE/'build.ninja'),'query_manifest':control.pin(query),
          'query_manifest_bytes_exact':query.read_bytes()==manifest,'source_pins':control.sources()}
        control.save(folder/'inspection.json',result);print(json.dumps({'module_cxx':len(cxx),'cuda':len(cuda),'sdk_cxx':extra,'all4_macros_equal':True,'engine_absent':True}))
    elif stage=='build':
        report=json.loads((B/'validation/control/module-inspect/attempt1/inspection.json').read_text())
        assert report['cxx']==6 and report['cuda']==0 and not report['sdk_cxx']
        assert control.pin(CACHE/'build.ninja')==report['normal_manifest']
        folder,receipt=control.execute('module-build',attempt,plan['commands']['module_build'])
        text=(folder/'stdout.log').read_text(errors='replace');actions=[l for l in text.splitlines() if re.match(r'^\[\d+/\d+\]',l)]
        result={'receipt':receipt,'actions':actions,'cxx':sum('Building CXX object' in l for l in actions),'cuda':sum('Building CUDA object' in l for l in actions),'links':sum('Linking CXX' in l for l in actions)}
        if not receipt['exit_code']:result['image']=control.pin(CACHE/'bin/hyle_graph_route_cuda_kimi_heterogeneous_state_test.exe')
        control.save(folder/'result.json',result)
        if receipt['exit_code']:raise SystemExit(receipt['exit_code'])
    else:raise ValueError(stage)
if __name__=='__main__':main()
