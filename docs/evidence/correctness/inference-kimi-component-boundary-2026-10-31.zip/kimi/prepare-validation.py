"""Read-only preparation/query. This script never configures/builds/runs a model."""
from pathlib import Path
import argparse,datetime,hashlib,json,re,subprocess

B=Path(__file__).resolve().parent;R=B.parents[1]
CACHE=R/'.scratch/build-compute-v2-dev'
ENV=R/'.scratch/inference-default-product-build-20261031/environment.json'
INPUT=R/'.scratch/inference-kimi-original-binding-20261025/payload-only/attempt1'
EXPECTED={'CMAKE_BUILD_TYPE':'Release','HYLE_COMPONENTS':'engine','HYLE_COMPUTE_ROUTES':'cpu;cuda',
 'HYLE_STATIC':'OFF','HYLE_TRACE':'OFF','HYLE_TEST_INSTRUMENTATION':'OFF','HYLE_SANITIZER':'off',
 'FETCHCONTENT_FULLY_DISCONNECTED':'ON','FETCHCONTENT_UPDATES_DISCONNECTED':'ON'}

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def pin(path):return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}
def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:json.dump(data,stream,ensure_ascii=False,indent=2);stream.write('\n')
def cache_values():
    return {m[1]:m[2] for line in (CACHE/'CMakeCache.txt').read_text().splitlines()
       if (m:=re.match(r'([^/#][^:]*):[^=]+=(.*)',line))}
def input_facts():
    lines=(INPUT/'original-role-pins.txt').read_text().splitlines()
    assert lines[:3]==['KIMI_ORIGINAL_ATTENTION_V1','moonshotai/Kimi-K3','f831ab66814297da540d832a5235f8e904f29d06']
    expected=[640000,887160832,14336,464392192];parts=[]
    for index,size in enumerate(expected):
        name,digest=lines[3+index].split();assert name=='union-%02d.bin'%index
        assert re.fullmatch('[0-9a-f]{64}',digest)
        path=INPUT/name;assert path.stat().st_size==size
        parts.append({'path':str(path),'bytes':size,'expected_sha256':digest,'new_payload_hash_run':False})
    roles=[dict(zip(['name','expected_sha256'],line.split())) for line in lines[7:]]
    assert len(roles)==23 and len({e['name'] for e in roles})==23
    assert all(re.fullmatch('[0-9a-f]{64}',e['expected_sha256']) for e in roles)
    return {'directory':str(INPUT),'pins':pin(INPUT/'original-role-pins.txt'),'components':['layer0 KDA 14 original roles','layer3 NoPE MLA 9 original roles'],
       'parts':parts,'total_payload_bytes':sum(expected),'roles':roles,
       'authentication':'Actual Data::load must verify each union + role SHA and all used finite coefficients before native use. Preparation checks only manifest/extent; no model download.'}

def commands():
    cmake='C:/Program Files/CMake/bin/cmake.exe'
    vector=B/'validation/runs/two-step/attempt1/vectors'
    image=CACHE/'bin/hyle_kimi_kda_mla_probe.exe'
    values=cache_values()
    module_dir=B/'validation/module-only-configure'
    module_configure=[cmake,'-S',str(R),'-B',str(module_dir),'-G','Ninja',
      '-DCMAKE_BUILD_TYPE:STRING=Release','-DHYLE_COMPONENTS:STRING=graph','-DHYLE_COMPUTE_ROUTES:STRING=cuda',
      '-DHYLE_STATIC:BOOL=OFF','-DHYLE_WERROR:BOOL=OFF','-DHYLE_BUILD_TESTS:BOOL=ON',
      '-DHYLE_TEST_INSTRUMENTATION:BOOL=OFF','-DHYLE_TRACE:BOOL=OFF','-DHYLE_SANITIZER:STRING=off',
      '-DFETCHCONTENT_FULLY_DISCONNECTED:BOOL=ON','-DFETCHCONTENT_UPDATES_DISCONNECTED:BOOL=ON',
      '-DHYLE_DEP_SOURCE_CACHE:PATH='+values['HYLE_DEP_SOURCE_CACHE']]
    for key in ['CMAKE_C_COMPILER','CMAKE_CXX_COMPILER','CMAKE_CUDA_COMPILER','CMAKE_MAKE_PROGRAM','CUDAToolkit_ROOT','CMAKE_CUDA_ARCHITECTURES']:
        if key in values:module_configure.append('-D'+key+':STRING='+values[key])
    for key in sorted(values):
        if key.startswith('FETCHCONTENT_SOURCE_DIR_') and values[key]:module_configure.append('-D'+key+':PATH='+values[key])
    return {'normal_build':[cmake,'--build',str(CACHE),'--target','hyle_kimi_kda_mla_probe','--parallel','2'],
      'two_step':[str(image),str(INPUT),str(vector)],
      'optional_existing_gtest_build':[cmake,'--build',str(CACHE),'--target','hyle_graph_route_cuda_kimi_heterogeneous_state_test','--parallel','2'],
      'optional_existing_gtest':[str(CACHE/'bin/hyle_graph_route_cuda_kimi_heterogeneous_state_test.exe'),
        '--gtest_filter=KimiHeterogeneousState.CudaOriginalParametersKdaMlaKeepCompleteStateAcrossContinuation',
        '--gtest_output=xml:'+str(B/'validation/runs/original-gtest/attempt1/results.xml')],
      'optional_existing_gtest_environment':{'HYLE_KIMI_ORIGINAL_ATTENTION_DIR':str(INPUT)},
      'module_only_configure_template':module_configure,
      'module_only_scope':'Optional configure/query only, not another SDK build: require no hyle_engine target, one private model target and canonical Kimi GTest linked to it; query the actual selected macros/links. Does not prove a module-only native link/run unless separately authorized and executed.',
      'optional_gtest_configure_requirement':'Current normal cache BUILD_TESTS=OFF: do not pretend this target exists. Root may explicitly authorize same-cache offline BUILD_TESTS=ON, reusing locked cached googletest; then only build this target. Expect an additional 1 consumer CXX (plus any actual GTest prerequisites), never include it in the four-TU claim.',
      'no_execution_here':True}

def sdk_link_snapshot(ninja,target):
    line=next((l for l in ninja.splitlines() if l.startswith('build bin\\'+target+'.exe:')),None)
    if line is None:return {'target':target,'present':False}
    names=sorted(set(token for token in line.split() if token.startswith('bin\\') and token.endswith('.lib')))
    imports=[]
    for name in names:
        path=CACHE/Path(name.replace('\\','/'))
        if path.exists():imports.append(pin(path))
    # These are actual normal CMake import-library dependencies, never the old
    # manual retained static/object list. Actual loaded DLLs still need sampling.
    return {'target':target,'present':True,'build_edge':line,'normal_import_libraries':imports,
       'scope':'snapshot from current normal build.ninja; not loaded-module proof and not an old baseline pin match'}

def inspect_ninja(folder):
    text=(CACHE/'build.ninja').read_text();blocks=re.split(r'(?m)(?=^build )',text)
    rows=[]
    for block in blocks:
        first=block.splitlines()[0] if block else ''
        if 'CXX_COMPILER_' not in first:continue
        if not any(part in first for part in ['hyle_kimi_k3_component.dir','hyle_kimi_kda_mla_probe.dir','hyle_graph_route_cuda_kimi_heterogeneous_state_test.dir']):continue
        defines=next((line.strip()[len('DEFINES = '):] for line in block.splitlines() if line.strip().startswith('DEFINES = ')),'')
        macros=dict(re.findall(r'(?:-D|/D)(HYLE_COMPUTE_(?:CPU|CUDA|APPLE|VULKAN))(?:=([^\s]+))?',defines))
        output=first[len('build '):first.index(': CXX_COMPILER_')].replace('\\','/')
        rows.append({'object':output,'backend_layout_macros':macros,'ninja_compile_edge':block.rstrip()})
    components=[row for row in rows if 'hyle_kimi_k3_component.dir' in row['object']]
    probe=[row for row in rows if 'hyle_kimi_kda_mla_probe.dir' in row['object']]
    gtest=[row for row in rows if 'hyle_graph_route_cuda_kimi_heterogeneous_state_test.dir' in row['object']]
    assert len(components)==3 and (len(probe)==1 or len(gtest)==1),'Run only after final source migration and CMake regeneration; no target guessed'
    assert all(row['backend_layout_macros']==components[0]['backend_layout_macros'] for row in rows),'Backend layout macro sets differ: stop before CXX/native'
    links={name:sdk_link_snapshot(text,name) for name in ['hyle_kimi_kda_mla_probe','hyle_graph_route_cuda_kimi_heterogeneous_state_test']}
    save(folder/'generated-command-and-macro-plan.json',{'status':'actual generated Ninja rules, not CXX receipts','ninja':pin(CACHE/'build.ninja'),
      'translation_units':rows,'component_cxx':len(components),'probe_cxx':len(probe),'optional_gtest_cxx':len(gtest),'backend_layout_macros_identical':True,'links':links,
      'post_build_deps_commands':[[cache_values()['CMAKE_MAKE_PROGRAM'],'-C',str(CACHE),'-t','deps',row['object']] for row in rows]})

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['draft','freeze','inspect-ninja'])
    parser.add_argument('--source-plan',default='candidate-plan-v3.json')
    parser.add_argument('--name',default='attempt1')
    parser.add_argument('--build-dir',type=Path,default=CACHE)
    args=parser.parse_args();folder=B/'validation'/args.name
    globals()['CACHE']=args.build_dir.resolve()
    if args.mode=='inspect-ninja':inspect_ninja(folder);return
    values=cache_values()
    assert all(values.get(k)==v for k,v in EXPECTED.items()),'Normal shared/offline cache contract differs'
    assert 'HYLE_DEV_FACTORS' not in values,'Developer factor cache is not the normal public product'
    source_plan=json.loads((B/args.source_plan).read_text());reference=pin(B/args.source_plan)
    record={'status':'DRAFT_COMMANDS_ONLY' if args.mode=='draft' else 'ACTUAL_PREBUILD_SNAPSHOT',
      'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_plan':reference,
      'commands':commands(),'configuration':{k:values.get(k) for k in [*EXPECTED,'CMAKE_CXX_COMPILER','CMAKE_CUDA_ARCHITECTURES','CMAKE_MAKE_PROGRAM','HYLE_BUILD_TESTS','HYLE_WERROR','HYLE_DEP_SOURCE_CACHE']},
      'environment':pin(ENV),'cache':pin(CACHE/'CMakeCache.txt'),'input':input_facts(),
      'environment_overrides':{'TEMP':str(B/'validation/tmp'),'TMP':str(B/'validation/tmp'),
        'scope':'Future child process only; use the preserved normal toolchain environment and remove CL/_CL_/CXXFLAGS/LDFLAGS/CUDAFLAGS/TORCH_INSTALL_PREFIX/CMAKE_PREFIX_PATH overrides. Do not inject old harness DLL directories.'},
      'expected_compile_actions':{'component':3,'probe':1,'sdk':0,'nvcc':0,'qualification':'Expectation only. A concurrently changed Graph may legitimately require one real Graph CXX/shared relink; capture actual actions and current source/import/DLL pins rather than forbid, hide or reuse static objects.'},
      'proof_requirements':['Before CXX, inspect actual generated Ninja flags/response input for all component3TU/probe and optional GTest: Backend HYLE_COMPUTE_CPU/CUDA/APPLE/VULKAN macro sets must be identical within the build.',
        'Retain actual CMake/Ninja compile/link commands, receipts and all errors. Query actual ninja -t deps for the new object paths; model/probe closures must exclude GTest, Qwen main, d5 IR and test ColdProgram.',
        'For change propagation, use actual dep lists and target DAG: cold_graph.cc private source has only its own object consumer, model headers legitimately propagate. Do not fake-edit sources or rerun native merely for a rebuild count.',
        'Default hyle_engine target has no Kimi object/archive dependency. Read actual generated hyle_engine link edge; a future normal default build should not pull the explicit model targets.',
        'Actual probe stdout JSON must show two commits, two stale rejections, one cancelled candidate, one plain bind rejection, StateStore zero after collection, two Source submits before producer host observation and no consumer new capture/host wait.',
        'Probe already runs original raw-coefficient independent six/nine-output accuracy gates and actual-producer row certificates; numerical oracle is not a production fallback. Preserve all 6/10 outputs per step if a vector directory is supplied.',
        'Record actual loaded normal bin DLL paths/SHA through the existing bounded PSAPI observer; old ready/loaded-runtime manifests are historical. Reject old gdn_scale_v3/manual runtime selection. Keep sample error299 scope honest.'],
      'existing_gtest_note':'Canonical real GTest consumer is correctly linked by V3, but is not claimed compiled/run in normal BUILD_TESTS=OFF. Optional extra one-TU test validation must be explicit, with the same actual Backend layout flags.',
      'product_edits':0,'builds':0,'native_runs':0,'network_requests':0}
    if args.mode=='freeze':
        pins=[]
        for row in source_plan['files']:
            actual=pin(R/row['path']);assert actual['bytes']==row['candidate']['bytes'] and actual['sha256']==row['candidate']['sha256'],row['path'];pins.append(actual)
        record['applied_source_pins']=pins
        record['actual_graph_source']=pin(R/'src/graph/executable.cc')
        graph_object=CACHE/'src/graph/CMakeFiles/hyle_graph.dir/executable.cc.obj'
        if graph_object.exists():record['actual_graph_object']=pin(graph_object)
        record['actual_shared_engine_contract_sources']=[pin(R/name) for name in ['engine/inference/backend.h','engine/inference/program_io.h',
          'engine/inference/program_carrier.h','engine/inference/execution_episode.h','engine/inference/output_pool_capacity.h']]
        text=(CACHE/'build.ninja').read_text();record['ninja']=pin(CACHE/'build.ninja')
        record['current_normal_hyle_link']=sdk_link_snapshot(text,'hyle')
        for name in ['hyle_graph.dll','hyle_graph.lib','hyle_compute.dll','hyle_compute.lib']:
            path=CACHE/'bin'/name
            if path.exists():record.setdefault('actual_current_normal_sdk_pins',[]).append(pin(path))
        record['boundary']='Snapshot only: after build pin actual new Graph DLL/imports and observe real runtime modules. No promise that this prebuild snapshot survives a legitimate Graph rebuild.'
    save(folder/'plan.json',record)
    print(json.dumps({'mode':args.mode,'plan':str(folder/'plan.json'),'expected_component_probe_cxx':4,'payload_bytes':record['input']['total_payload_bytes'],'executed_build_native':0}))

if __name__=='__main__':main()
