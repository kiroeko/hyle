# Why the resources.cc Copy preservation branch is unnecessary

Read-only source audit, 2026-10-31, resources source 18a523e4 (the 13-line combined candidate). The six inserted lines in resources.cc are unreachable through current legal binding APIs. Recommend removing exactly this block, retaining the seven executable.cc qualification/full-tuple lines. Do not expand projection permissions to make it reachable.

- `withdraw_bindings_impl` 386–388 examines these preservation rules only for `ready_projection || source_owner`, then only if the exact value binding has `BindingScope::kProjected`.
- Ordinary OutputSource uses `InputAccess::bind` and `note_borrowed_binding` (resources619–640), which sets Caller scope. `bind_sources` entry.view branch3858–3861 supplies descriptor/ready lease but never changes that scope. Caller OutputSource therefore continues before the added block.
- Generic `bind_projected_impl`701–780 requires every proof to identify an actual selected Region at725–727 and every physical consumer to be direct, qualified Region at746–753. Physical Copy is rejected before Projected scope is committed.
- `bind_read_projection`1441–1548 validates all direct/alias physical consumers. Declared readers must be Operation or Region; its inspector1515 rejects every materializing/Copy consumer. Alias metadata does not create an escape.
- Row projection `bind_projection`1649 calls validate_projection_binding, which calls projection_resource1585–1610. That function requires the sole checked Operation/Region physical reader and rejects Copy or unrelated readers.
- StoreSource uses validate_pending_projection/validate_ready_projection3795–3798, hence the row restriction. ResourceSource uses validate_pending_projected3778–3779, hence the generic Region restriction. Both checks occur before Source attachment and Projected scope publication. Effect-only Source entries do not publish a projected input binding.
- Written projections first pass bind_projected_impl1114, then change the binding to WrittenProjection1126; they do not reach this Projected-only loop. Extra page guards do not have independently valid external ValueIds for the withdrawal entry.

The physical Plan is immutable after compilation, so a legal Projected binding cannot later acquire a plain Graph Copy consumer. This matches the existing GraphRouteBoundary.ProjectedInputRetainsAllReadersAndLivePageGuards rejection around3523. A whole-capacity Copy is not a qualified sparse/page reader.

The repaired original warm-cohort PASS was compiled with all13lines; it did not separately prove that this unreachable resources branch was needed. After removing it, the final DLL and existing CPU/CUDA regression cases still need actual validation. The two frozen tests do not claim to cover projected Copy withdrawal. No source, build, or native action occurred during this audit.
