"""Post-build help/import proof and exactly two authorized tiny smokes; no benchmark."""
from pathlib import Path
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
import re
import subprocess
import time
import datetime

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CACHE = ROOT / '.scratch/build-compute-v2-dev'
IMAGE = CACHE / 'bin/hyle.exe'
TINY = ROOT / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
KERNEL = ctypes.WinDLL('kernel32', use_last_error=True)
PSAPI = ctypes.WinDLL('psapi', use_last_error=True)
KERNEL.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
KERNEL.OpenProcess.restype = w.HANDLE
KERNEL.CloseHandle.argtypes = [w.HANDLE]
PSAPI.EnumProcessModulesEx.argtypes = [w.HANDLE, ctypes.POINTER(w.HMODULE), w.DWORD, ctypes.POINTER(w.DWORD), w.DWORD]
PSAPI.GetModuleFileNameExW.argtypes = [w.HANDLE, w.HMODULE, w.LPWSTR, w.DWORD]


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest())


def modules(handle):
    items = (w.HMODULE * 4096)()
    needed = w.DWORD()
    if not PSAPI.EnumProcessModulesEx(handle, items, ctypes.sizeof(items), ctypes.byref(needed), 3):
        return [], ctypes.get_last_error()
    if needed.value > ctypes.sizeof(items):
        raise RuntimeError('Module observation buffer exhausted')
    result = []
    for item in items[:needed.value // ctypes.sizeof(w.HMODULE)]:
        buf = ctypes.create_unicode_buffer(32768)
        if PSAPI.GetModuleFileNameExW(handle, item, buf, len(buf)):
            result.append(buf.value)
    return result, 0


def execute(name, command, env):
    folder = HERE / 'checks' / name / 'attempt1'
    folder.mkdir(parents=True, exist_ok=False)
    save(folder / 'command.json', dict(command=command, cwd=str(ROOT), image=identity(IMAGE)))
    observed, errors = {}, {}
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (folder / 'stdout.log').open('wb') as out, (folder / 'stderr.log').open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=out, stderr=err)
        save(folder / 'process.json', dict(pid=process.pid, start_utc=start, state='RUNNING'))
        handle = KERNEL.OpenProcess(0x400 | 0x10, False, process.pid)
        while process.poll() is None:
            if handle:
                found, code = modules(handle)
                observed.update({p.lower(): p for p in found})
                if code:
                    errors[str(code)] = errors.get(str(code), 0) + 1
            time.sleep(0.01)
        if handle:
            KERNEL.CloseHandle(handle)
    result = dict(pid=process.pid, start_utc=start,
                  end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  exit_code=process.returncode, state='TERMINAL',
                  observed_modules=sorted(observed.values()), module_sample_errors=errors,
                  scope='10ms live module sampling; correctness smoke, not timing or complete loader-event tracing')
    save(folder / 'process.json', result)
    print(json.dumps(dict(case=name, pid=process.pid, exit_code=process.returncode, modules=len(observed))), flush=True)
    if process.returncode:
        raise RuntimeError('Actual command failed; preserve this first outcome: ' + name)
    return folder, result


def main():
    receipts = list((HERE / 'build').glob('attempt*/result.json'))
    build_receipt = max(receipts, key=lambda p: int(p.parent.name.removeprefix('attempt')))
    built = json.loads(build_receipt.read_text(encoding='utf-8'))
    if built['exit_code'] or identity(IMAGE) != built['image']:
        raise RuntimeError('The normal product build/image is not terminal PASS/exact')
    env = dict(os.environ)
    env.update(json.loads((HERE / 'environment.json').read_text(encoding='utf-8')))
    for key in ['CL', '_CL_', 'CUDAARCHS', 'TORCH_INSTALL_PREFIX', 'CMAKE_PREFIX_PATH']:
        env.pop(key, None)
    folder, _ = execute('help', [str(IMAGE), '--help'], env)
    if 'Usage: hyle --inputs DIR' not in (folder / 'stdout.log').read_text(errors='replace'):
        raise RuntimeError('Expected actual help text missing')
    dumpbin = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/dumpbin.exe')
    dep_folder = HERE / 'checks/dependencies/attempt1'
    dep_folder.mkdir(parents=True, exist_ok=False)
    imports = []
    for path in [IMAGE, CACHE / 'bin/hyle_compute_ggml_runtime.dll', CACHE / 'bin/hyle_compute_provider_ggml_cuda.dll']:
        command = [str(dumpbin), '/DEPENDENTS', str(path)]
        r = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
        (dep_folder / (path.name + '.stdout.log')).write_bytes(r.stdout)
        (dep_folder / (path.name + '.stderr.log')).write_bytes(r.stderr)
        imports.append(dict(command=command, exit_code=r.returncode, image=identity(path)))
        if r.returncode:
            save(dep_folder / 'results.json', imports)
            raise RuntimeError('dumpbin dependency query failed')
    save(dep_folder / 'results.json', imports)
    ninja = (CACHE / 'build.ninja').read_text(errors='replace')
    names = sorted(set(re.findall(r'HYLE_GGML_CPU_PROGRAM_LIBRARY[^\r\n]*?(hyle_ggml_cpu_avx2_[A-Za-z0-9_]+\.dll)', ninja)))
    if len(names) != 1:
        raise RuntimeError('Cannot identify exactly one normal CPU fingerprint runtime: ' + str(names))
    shared_runtime = identity(CACHE / 'bin' / names[0])
    base = ['--inputs', str(TINY), '--steps', '4', '--capacity', '16', '--max-sessions', '1',
            '--active-sequences', '1', '--prefix-cache', 'off', '--progress', 'direct',
            '--replay', 'auto', '--decode-overlap', 'auto', '--sampling', 'greedy']
    summaries = []
    for name, args in [('tiny-cpu-ordinary', ['--backend', 'cpu', '--mtp', 'off']),
                       ('tiny-cuda-mtp-k1', ['--backend', 'cuda', '--mtp', 'on', '--mtp-max-drafts', '1'])]:
        folder, process = execute(name, [str(IMAGE), *base, *args], env)
        report = json.loads((folder / 'stdout.log').read_text(encoding='utf-8-sig'))
        save(folder / 'report.json', report)
        if report['generated_tokens'] != 4 or report['requested_output_tokens'] != 4:
            raise RuntimeError('Tiny smoke did not produce exactly four requested outputs')
        loaded = [Path(p) for p in process['observed_modules'] if Path(p).name.lower().startswith(('hyle_', 'ggml'))]
        pins = [identity(p) for p in loaded]
        if any('gdn_scale_v3' in p.name for p in loaded):
            raise RuntimeError('An experimental CPU runtime was loaded')
        if name == 'tiny-cpu-ordinary' and str(CACHE / 'bin' / names[0]).lower() not in {str(p).lower() for p in loaded}:
            raise RuntimeError('CPU fingerprint runtime not observed; do not claim actual load')
        save(folder / 'runtime-pins.json', pins)
        summaries.append(dict(case=name, pid=process['pid'], exit_code=0, generated_tokens=4,
                              runtime_pins=pins, output_report=identity(folder / 'report.json')))
    loaded = dict(normal_cpu_fingerprint_runtime=shared_runtime, cases=summaries,
                  scope='Actual observed process module paths and independently read-back file SHA256; not proof that every loaded provider executed a kernel')
    save(HERE / 'loaded-runtime.json', loaded)
    source = json.loads((HERE / 'prepared.json').read_text(encoding='utf-8'))
    pins = {p['path']: p for p in source['source_pins']}
    supplement = HERE / ('source-freeze-build-' + build_receipt.parent.name + '.json')
    if supplement.exists():
        pins.update({p['path']: p for p in json.loads(supplement.read_text(encoding='utf-8'))['additional_source_pins']})
    for pin in pins.values():
        if identity(Path(pin['path'])) != pin:
            raise RuntimeError('Final source differs from the successful build source freeze')
    ready = dict(image=identity(IMAGE), build=identity(build_receipt),
                 runtime_environment=identity(HERE / 'environment.json'),
                 loaded_runtime=identity(HERE / 'loaded-runtime.json'),
                 source_pins=list(pins.values()), smoke_passed=True, instrumented=False,
                 scope='Normal shared Release engine+cpu;cuda CMake product; no manual SDK/image substitution; root owns final window binding')
    save(HERE / 'normal-product-ready-draft.json', ready)
    save(HERE / 'smoke-summary.json', dict(status='PASS', image=identity(IMAGE), build=identity(build_receipt),
         normal_cpu_fingerprint_runtime=shared_runtime, cases=summaries,
         scope='Help/imports plus exactly two H64/V64/C16 4-output correctness smokes; no benchmark/profile'))
    print(json.dumps(dict(status='PASS', cases=len(summaries), image_sha=identity(IMAGE)['sha256'], cpu_runtime=names[0])))


if __name__ == '__main__':
    main()
