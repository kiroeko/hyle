"""Archive the completed bounded Graph checks, without builds or execution."""
from pathlib import Path
import hashlib,json,sys,zipfile

N=Path(__file__).resolve().parent;R=N.parents[1];W=N/'graph-integration'
OUT=R/'docs/evidence/correctness/inference-indexed-gdn-graph-2026-10-27'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def pin(p):
    p=Path(p);data=p.read_bytes()
    return dict(path=str(p),bytes=len(data),sha256=sha(data))
def publish():
    summary=read(W/'summary.json');ready=read(W/'ready5.json');members={}
    def add(p,name=None,expected=None):
        p=Path(p);data=p.read_bytes()
        if expected:assert sha(data)==expected,(str(p),'source identity changed')
        if name is None:name='records/'+p.relative_to(W).as_posix()
        assert name not in members,name
        members[name]=data
    # Final actual source only. Old failed test versions have pins/raw results,
    # but no complete byte snapshots and are explicitly not reconstructed here.
    source_pins={x['source']['path'].lower():x['source'] for x in ready['compiled']}
    frozen=read(W/'source-freeze.json')
    source_pins.update({x['path'].lower():x for x in frozen if x['path'].lower() not in source_pins})
    sources=['include/hyle/graph/detail/region_access.h',
      'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
      'src/compute_provider_ggml_cuda/tensor_program.cc',
      'src/compute_provider_ggml_cuda/program.h',
      'src/compute_provider_ggml_cuda/indexed_state.h',
      'src/graph/resources.cc','src/graph/slots_region.cc','src/graph/slots_region.h',
      'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
      'tests/graph/region_provider_test.cc',
      'tests/graph_provider_ggml_cuda/indexed_state_test.cc']
    for source in sources:
        p=R/source;expected=source_pins[str(p).lower()]['sha256']
        add(p,'source/'+source,expected)
    cmake='tests/graph_provider_ggml_cuda/CMakeLists.txt'
    add(R/cmake,'source/'+cmake,read(W/'plan.json')['test_CMake']['sha256'])
    # Existing CPU/CUDA neighbor fixtures were reused as original test objects.
    baseline=read(R/'.scratch/inference-slot-store-20261027/attempt2/ready.json')
    for name in ['cpu-test','cuda-test']:
        row=next(x for x in baseline['compiled'] if x['name']==name)['source']
        p=Path(row['path']);add(p,'source/'+p.relative_to(R).as_posix(),row['sha256'])
    add(N/'graph-build.py','scripts/graph-build.py')
    add(Path(__file__),'scripts/publish-graph.py')
    add(N/'native-final.json','native/native-final.json')
    native_receipt=R/'docs/evidence/correctness/inference-indexed-gdn-native-2026-10-27.json'
    add(native_receipt,'native/published-native-receipt.json')
    for name in ['plan.json','canonical-recipes.json','source-freeze.json',
      'region-test2-plan.json','region-test2-freeze.json',
      'test3-plan.json','test3-freeze.json','test4-plan.json','test4-freeze.json',
      'link-inputs.json','link2-inputs.json','link3-inputs.json','link4-inputs.json',
      'ready.json','ready2.json','ready3.json','ready4.json','ready5.json',
      'runtime.json','runtime2.json','runtime3.json','runtime4.json','runtime5.json',
      'runtime-correction.json','summary.json',
      'partial-results.json','partial-results3.json','partial-results5.json',
      'results-cpu.xml','results-cuda.xml','results-region.xml','results2-region.xml',
      'results3-region.xml','results3-indexed.xml','results4-indexed.xml','results5-indexed.xml']:
        add(W/name)
    compile_dirs=['compile/'+x for x in ['resources','store','provider','tensor','graph-provider','region-test','test']]
    compile_dirs+=['compile2/region-test','compile3/test','compile4/test']
    for directory in compile_dirs:
        for name in ['command.json','process.json','stdout.log','stderr.log','actual-dependencies.json']:
            add(W/directory/name)
    for directory in ['link','link2','link3','link4','run-cpu','run-cuda','run-region',
                      'run2-region','run3-region','run3-indexed','run4-indexed','run5-indexed']:
        for name in ['command.json','process.json','stdout.log','stderr.log']:add(W/directory/name)
    # Confirm reused product identity across all four linked test images.
    product_names=['resources','store','provider','tensor','graph-provider']
    identity=[]
    for name in product_names:
        rows=[next(x for x in read(W/('ready'+suffix+'.json'))['compiled'] if x['name']==name)
              for suffix in ['', '3','4','5']]
        assert len({x['source']['sha256'] for x in rows})==1
        assert len({x['object']['sha256'] for x in rows})==1
        identity.append(dict(name=name,source=rows[0]['source'],object=rows[0]['object']))
    manifests=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())]
    OUT.parent.mkdir(parents=True,exist_ok=True);zpath=OUT.with_suffix('.zip')
    assert not zpath.exists() and not OUT.with_suffix('.json').exists()
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(members.items()):z.writestr(name,data)
    with zipfile.ZipFile(zpath) as z:
        assert z.namelist()==[x['path'] for x in manifests]
        for row in manifests:
            data=z.read(row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
    assert zpath.stat().st_size<2_000_000
    final=dict(status='FIFTEEN_BOUNDED_GRAPH_TESTS_PASS',date='2026-10-27',
      scope='Actual default CUDA Graph indexed GDN state consumer and adjacent Store/projected-read contracts; no engine or performance claim.',
      passed_tests=15,groups=[
        dict(name='CPU Store',tests=4,process=read(W/'run-cpu/process.json'),ready=pin(W/'ready.json')),
        dict(name='CUDA Store',tests=1,process=read(W/'run-cuda/process.json'),ready=pin(W/'ready.json')),
        dict(name='Projected region',tests=8,process=read(W/'run3-region/process.json'),ready=pin(W/'ready3.json')),
        dict(name='Indexed state Graph',tests=2,process=read(W/'run5-indexed/process.json'),ready=pin(W/'ready5.json'))],
      observation_rule='15 is the union of four passing group observations on three images; not all 15 rerun on the final image. All use the identical five product objects below.',
      unchanged_product_objects=identity,distinct_CXX_TUs=7,CXX_compile_attempts=10,
      link_attempts=4,linked_images=4,native_test_processes=8,
      native_objects_reused=ready['reused_native'],native_receipt=pin(native_receipt),
      indexed_coverage=dict(batches=2,tokens=4,snapshots=2,heads=2,depth=16,
        pool_slots=17,slot_stride_bytes=4096,allocation_alignment_bytes=256,
        source_slots=[13,2],destination_slots=[7,16,4,11],
        route_policy=[0x48594c4547474355,6,1],implementation=7,logical_nodes=5,dispatch_count=1,
        cases=['Published Y plus batch-major chronological last-K candidate slots',
               'No public Y: original external effect still executes; second real transaction reset, stale prepare/submit rejected, take returns original owner'],
        reference='Original public dense GDN in the same Context; no Gather/Store pattern.',
        checks=['Activation/state F32 bits','Original sources and unused slots unchanged',
                'All slot gaps and trailing padding unchanged','Mathematical input buffers unchanged',
                'Real exact source/destination leases and common owner-generated private controls'],
        padding_authority='Separate ordinary initialized gap blocks; no Graph writer includes padding. Whole backing alias is diagnostic read only after retirement, never a pool ReadLease or Graph input.'),
      failed_attempts=[
        dict(process=read(W/'run-region/process.json'),kind='Runtime staging',
          reason='CPU DLL absent from image directory; DEFAULT_DIRS loader does not search PATH. Reused same-SHA existing DLL hardlink, no product/image change.'),
        dict(process=read(W/'run2-region/process.json'),kind='Root test budget setup',
          reason='Zero-byte system budget cannot create its own control state. Corrected to create 64KiB scope and reserve its remaining metadata allowance before testing denied growth.'),
        dict(process=read(W/'run3-indexed/process.json'),kind='Own test diagnostic deficiency',
          reason='Bad expected access hid the Buffer allocation error; subsequent test made fallible fixture calls explicit.'),
        dict(process=read(W/'run4-indexed/process.json'),kind='Own test resource setup',
          reason='4096-byte requested allocation alignment exceeded original CUDA resource limit256. Kept actual logical/math/IDs/stride; used legal256 alignment and retained separate2048-byte gaps.')],
      historical_source_limit='Earlier failed test source byte snapshots are incomplete. Their source hashes, freezes, exact commands, logs and error descriptions are retained; final canonical source is not presented as their old bytes. Final replay script contains retry support added after initial attempts.',
      exclusions=['No engine integration','No indexed convolution integration','No model-quality or model inference run',
                  'No performance/speedup measurement','No full-platform or arbitrary-shape claim',
                  'No SDK/weights downloads, SDK rebuild or new NVCC build',
                  'No arbitrary user device-ID validation guarantee; actual lease-derived private controls only'],
      SDK_builds=0,NVCC_builds=0,model_runs=0,downloads=0,performance_claim=False,
      final_ready=pin(W/'ready5.json'),raw_summary=pin(W/'summary.json'),
      archive=dict(path=zpath.relative_to(R).as_posix(),bytes=zpath.stat().st_size,sha256=sha(zpath.read_bytes()),members=len(manifests)),
      members=manifests)
    OUT.with_suffix('.json').write_text(json.dumps(final,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    for p in [OUT.with_suffix('.json'),zpath]:print(json.dumps(pin(p)))
if __name__=='__main__':
    if sys.argv[1:]!=['publish']:raise SystemExit('Explicit action required: publish')
    publish()
