"""Seven CXX leaves + passed native objects; explicit plan/build/run only."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
N=Path(__file__).resolve().parent;R=N.parents[1];W=N/'graph-integration'
B=R/'.scratch/inference-slot-store-20261027/attempt2'
spec=importlib.util.spec_from_file_location('passed_store',B.parent/'build.py')
store=importlib.util.module_from_spec(spec);spec.loader.exec_module(store)
m,b=store.m,store.b
GROUPS=[*store.GROUPS,('indexed','GgmlCudaIndexedStateGraph.*',2)]
def specs():
    ready=b.read(B/'ready.json');old={x['name']:x for x in ready['compiled']}
    q=R/'.scratch/inference-current-closure-20261026'
    return [
      ('resources','src/graph/resources.cc',Path(old['resources']['object']['path']).parent/'command.json',old['resources']['object']),
      ('store','src/graph/slots_region.cc',Path(old['store']['object']['path']).parent/'command.json',old['store']['object']),
      ('provider','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',q/'headers79/compute_provider_ggml_cuda--ggml_cuda_provider_cc/command.json',b.pin(q/'headers79/compute_provider_ggml_cuda--ggml_cuda_provider_cc/unit.obj')),
      ('tensor','src/compute_provider_ggml_cuda/tensor_program.cc',R/'.scratch/inference-cuda-slot-gather-20261026/compile/program/command.json',b.pin(R/'.scratch/inference-cuda-slot-gather-20261026/compile/program/unit.obj')),
      ('graph-provider','src/graph_provider_ggml_cuda/ggml_cuda_region.cc',q/'drift8/graph_provider_ggml_cuda--ggml_cuda_region_cc/command.json',b.pin(q/'drift8/graph_provider_ggml_cuda--ggml_cuda_region_cc/unit.obj')),
      ('region-test','tests/graph/region_provider_test.cc',Path(old['region-test']['object']['path']).parent/'command.json',old['region-test']['object']),
      ('test','tests/graph_provider_ggml_cuda/indexed_state_test.cc',N/'compile/test/command.json',None)]
def plan():
    assert not (W/'plan.json').exists()
    baseline=b.read(B/'ready.json');inputs=b.read(baseline['inputs']['path'])
    assert len(inputs)==225
    for row in inputs:b.exact(row)
    units=[]
    for name,source,recipe,before in specs():
        if before:assert sum(b.key(x['path'])==b.key(before['path']) for x in inputs)==1,name
        command=m.command(recipe,R/source,W/'compile'/name)
        # Quoted private includes must resolve canonical current module headers.
        for p in [R/'src/compute_provider_ggml_cuda',R/'src/graph']:
            if '/I'+str(p) not in command:command.insert(1,'/I'+str(p))
        assert all(x in command for x in ['/O2','/W4','/WX','/DHYLE_STATIC'])
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),command=command,before=before))
    native=b.read(N/'ready2.json');native_plan=b.read(N/'build-plan2.json')
    replacements=[]
    for row in native['compiled']:
        if row['name'] not in ['gdn','dispatcher']:continue
        old=next(x['replaces'] for x in native_plan['native'] if x['name']==row['name'])
        assert sum(b.key(x['path'])==b.key(old['path']) for x in inputs)==1
        b.exact(row['object']);replacements.append(dict(before=old,after=row['object']))
    assert len(replacements)==2
    canonical=W/'canonical-recipes.json';b.save(canonical,dict(command=[x for u in units for x in u['command']]))
    frozen=m.c.closure([x['source']['path'] for x in units],[canonical]);b.save(W/'source-freeze.json',frozen)
    b.save(W/'plan.json',dict(status='SOURCE_FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(W/'source-freeze.json'),
      baseline=dict(ready=b.pin(B/'ready.json'),inputs=baseline['inputs'],runtime=baseline['runtime'],command=b.pin(B/'link/command.json')),
      reused_native=replacements,native_receipt=b.pin(N/'native-final.json'),test_CMake=b.pin(R/'tests/graph_provider_ggml_cuda/CMakeLists.txt'),
      groups=GROUPS,CXX_TUs=7,images=1,NVCC_builds=0,SDK_model_perf_downloads=0))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['units'][0]['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def build():
    p=b.read(W/'plan.json');assert not (W/'compile').exists() and not (W/'ready.json').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for row in frozen:b.exact(row)
    for row in b.read(p['baseline']['inputs']['path']):b.exact(row)
    h,env=environment(p);objects={};results=[]
    for unit in p['units']:
        out=W/'compile'/unit['name'];process=h.execute(unit['command'],env,out,timeout=180)
        deps=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
        for row in actual:
            q=Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):assert own[b.key(q)]['sha256']==row['sha256'],str(q)
        b.save(out/'actual-dependencies.json',actual);objects[unit['name']]=b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:b.exact(row)
        print('COMPILED',unit['name'],json.dumps(process),flush=True)
    replace={b.key(u['before']['path']):objects[u['name']] for u in p['units'] if u['before']}
    replace.update({b.key(x['before']['path']):x['after'] for x in p['reused_native']})
    for row in p['reused_native']:b.exact(row['after'])
    image=W/'bin/indexed-state-graph-test.exe';args=[];changed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in replace:arg=replace[b.key(arg)]['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert changed==8
    args.append(objects['test']['path']);image.parent.mkdir(parents=True,exist_ok=True)
    result=h.execute(args,env,W/'link',timeout=120)
    inputs=[replace.get(b.key(x['path']),x) for x in b.read(p['baseline']['inputs']['path'])]+[objects['test']]
    assert len(inputs)==226
    b.save(W/'link-inputs.json',inputs);b.save(W/'runtime.json',b.read(p['baseline']['runtime']['path']))
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=result,
      inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),reused_native=p['reused_native']))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def runtime_fix():
    assert not (W/'ready2.json').exists()
    ready=b.read(W/'ready.json');b.exact(ready['image']);runtime=b.read(ready['runtime']['path'])
    native=runtime['native_cpu'];b.exact(native)
    alias=Path(ready['image']['path']).parent/Path(native['path']).name
    assert not alias.exists();os.link(native['path'],alias)
    runtime['native_cpu_hardlink']=b.pin(alias)
    b.save(W/'runtime2.json',runtime)
    b.save(W/'runtime-correction.json',dict(
      reason='CPU AVX2 loader uses LOAD_LIBRARY_SEARCH_DEFAULT_DIRS, not PATH. Original Store image had same-directory native DLL hardlink; new image omitted it.',
      native=native,alias=b.pin(alias),original_runtime=ready['runtime'],new_runtime=b.pin(W/'runtime2.json'),
      failed_process=b.read(W/'run-region/process.json'),product_or_image_changes=0,builds=0,
      remaining_groups=['region','indexed'],already_passed_not_repeated=['cpu','cuda']))
    ready['runtime']=b.pin(W/'runtime2.json');ready['original_ready']=b.pin(W/'ready.json')
    ready['runtime_correction']=b.pin(W/'runtime-correction.json');b.save(W/'ready2.json',ready)
    print('READY2',json.dumps(b.pin(W/'ready2.json')),flush=True)
def retry_region():
    # Only root's corrected budget fixture changed; retain every old receipt.
    assert not (W/'ready3.json').exists()
    p=b.read(W/'plan.json');ready=b.read(W/'ready2.json')
    unit=next(x for x in p['units'] if x['name']=='region-test')
    changed=[]
    for row in b.read(p['source_freeze']['path']):
        if b.pin(row['path'])['sha256']!=row['sha256']:changed.append(row['path'])
    assert [b.key(x) for x in changed]==[b.key(unit['source']['path'])],changed
    source=b.pin(unit['source']['path']);out=W/'compile2/region-test'
    command=m.command(Path(unit['recipe']['path']),Path(source['path']),out)
    for include in [R/'src/compute_provider_ggml_cuda',R/'src/graph']:
        if '/I'+str(include) not in command:command.insert(1,'/I'+str(include))
    frozen=m.c.closure([source['path']],[Path(unit['recipe']['path'])])
    b.save(W/'region-test2-freeze.json',frozen)
    b.save(W/'region-test2-plan.json',dict(source=source,original_source=unit['source'],command=command,
      reason='Root corrected test budget setup to admit scope control first, then reserve all remaining metadata capacity. No product change.',
      reused_ready=b.pin(W/'ready2.json'),changed_files=changed,CXX_TUs=1,images=1))
    h,env=environment(p);process=h.execute(command,env,out,timeout=180)
    dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    b.save(out/'actual-dependencies.json',actual);obj=b.pin(out/'unit.obj')
    previous=next(x for x in ready['compiled'] if x['name']=='region-test')
    image=W/'bin2/indexed-state-graph-test.exe';args=[];changed_count=0
    for arg in b.read(W/'link/command.json')['command']:
        if b.key(arg)==b.key(previous['object']['path']):arg=obj['path'];changed_count+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed_count==1;image.parent.mkdir(parents=True,exist_ok=True)
    inputs=b.read(ready['inputs']['path'])
    for row in inputs:b.exact(row)
    linked=h.execute(args,env,W/'link2',timeout=120)
    new_inputs=[obj if b.key(x['path'])==b.key(previous['object']['path']) else x for x in inputs]
    b.save(W/'link2-inputs.json',new_inputs)
    rt=b.read(ready['runtime']['path']);alias=image.parent/Path(rt['native_cpu']['path']).name
    assert not alias.exists();os.link(rt['native_cpu']['path'],alias);rt['native_cpu_hardlink']=b.pin(alias)
    b.save(W/'runtime3.json',rt)
    new_record=dict(name='region-test',source=source,object=obj,process=process,actual_dependencies=b.pin(out/'actual-dependencies.json'))
    ready['compiled']=[new_record if x['name']=='region-test' else x for x in ready['compiled']]
    ready.update(image=b.pin(image),link=linked,inputs=b.pin(W/'link2-inputs.json'),runtime=b.pin(W/'runtime3.json'),
      original_ready=b.pin(W/'ready2.json'),test_retry=b.pin(W/'region-test2-plan.json'))
    b.save(W/'ready3.json',ready);print('READY3',json.dumps(b.pin(W/'ready3.json')),flush=True)
def retry_indexed(attempt=4):
    assert attempt in [4,5]
    assert not (W/('ready'+str(attempt)+'.json')).exists()
    p=b.read(W/'plan.json');prior_ready=W/('ready'+str(attempt-1)+'.json');ready=b.read(prior_ready)
    unit=next(x for x in p['units'] if x['name']=='test')
    for row in ready['compiled']:
        if row['name']!='test':b.exact(row['source']);b.exact(row['object'])
    for row in b.read(p['source_freeze']['path']):
        if b.key(row['path']) not in [b.key(unit['source']['path']),b.key(R/'tests/graph/region_provider_test.cc')]:b.exact(row)
    source=b.pin(unit['source']['path']);stage=str(attempt-1);out=W/('compile'+stage)/'test'
    command=m.command(Path(unit['recipe']['path']),Path(source['path']),out)
    for include in [R/'src/compute_provider_ggml_cuda',R/'src/graph']:
        if '/I'+str(include) not in command:command.insert(1,'/I'+str(include))
    frozen=m.c.closure([source['path']],[Path(unit['recipe']['path'])])
    b.save(W/('test'+stage+'-freeze.json'),frozen)
    b.save(W/('test'+stage+'-plan.json'),dict(source=source,original_source=unit['source'],command=command,
      reason=('Own test makes fallible construction explicit.' if attempt==4 else 'Own test uses legal CUDA allocation alignment and explicit unchanged slot-padding blocks; logical input/math/stride/IDs unchanged.'),
      reused_ready=b.pin(prior_ready),CXX_TUs=1,images=1))
    h,env=environment(p);process=h.execute(command,env,out,timeout=180)
    dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    b.save(out/'actual-dependencies.json',actual);obj=b.pin(out/'unit.obj')
    previous=next(x for x in ready['compiled'] if x['name']=='test')
    image=W/('bin'+stage)/'indexed-state-graph-test.exe';args=[];changed=0
    for arg in b.read(W/('link'+str(attempt-2))/'command.json')['command']:
        if b.key(arg)==b.key(previous['object']['path']):arg=obj['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed==1;image.parent.mkdir(parents=True,exist_ok=True)
    inputs=b.read(ready['inputs']['path'])
    for row in inputs:b.exact(row)
    linked=h.execute(args,env,W/('link'+stage),timeout=120)
    b.save(W/('link'+stage+'-inputs.json'),[obj if b.key(x['path'])==b.key(previous['object']['path']) else x for x in inputs])
    rt=b.read(ready['runtime']['path']);alias=image.parent/Path(rt['native_cpu']['path']).name
    assert not alias.exists();os.link(rt['native_cpu']['path'],alias);rt['native_cpu_hardlink']=b.pin(alias)
    b.save(W/('runtime'+str(attempt)+'.json'),rt)
    record=dict(name='test',source=source,object=obj,process=process,actual_dependencies=b.pin(out/'actual-dependencies.json'))
    ready['compiled']=[record if x['name']=='test' else x for x in ready['compiled']]
    ready.update(image=b.pin(image),link=linked,inputs=b.pin(W/('link'+stage+'-inputs.json')),runtime=b.pin(W/('runtime'+str(attempt)+'.json')),
      original_ready=b.pin(prior_ready),test_retry=b.pin(W/('test'+stage+'-plan.json')))
    b.save(W/('ready'+str(attempt)+'.json'),ready);print('READY'+str(attempt),json.dumps(b.pin(W/('ready'+str(attempt)+'.json'))),flush=True)
def run(resume=False,attempt=1):
    ready_name='ready'+str(attempt)+'.json' if resume else 'ready.json'
    p=b.read(W/'plan.json');ready=b.read(W/ready_name);b.exact(ready['image'])
    h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH']
    groups=b.read(W/('partial-results3.json' if attempt>=4 else 'partial-results.json')) if resume else []
    if resume:assert [x['name'] for x in groups]==(['cpu','cuda','region'] if attempt>=4 else ['cpu','cuda'])
    for name,filter,count in p['groups'][len(groups):]:
        xml=W/(('results'+str(attempt)+'-' if resume else 'results-')+name+'.xml')
        process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(xml)],env,W/(('run'+str(attempt)+'-' if resume else 'run-')+name),timeout=90)
        root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
        assert int(root.attrib['tests'])==count and int(root.attrib['failures'])==0
        assert len(cases)==count and all(x.attrib.get('status')=='run' and not list(x) for x in cases)
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)));b.save(W/('partial-results'+str(attempt)+'.json' if resume else 'partial-results.json'),groups)
        print('PASSED',name,count,flush=True)
    b.save(W/'summary.json',dict(status='FIFTEEN_RELEVANT_GRAPH_TESTS_PASS',groups=groups,ready=b.pin(W/ready_name),tests=15,failures=0,
      scope='13 existing adjacent Store/projected-region tests + 2 real indexed-state Graph regions; no engine or performance claim.',NVCC_SDK_model_downloads=0))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    elif sys.argv[1:]==['runtime-fix']:runtime_fix()
    elif sys.argv[1:]==['run2']:run(True,2)
    elif sys.argv[1:]==['retry-region']:retry_region()
    elif sys.argv[1:]==['run3']:run(True,3)
    elif sys.argv[1:]==['retry-indexed']:retry_indexed()
    elif sys.argv[1:]==['run4']:run(True,4)
    elif sys.argv[1:]==['retry-indexed5']:retry_indexed(5)
    elif sys.argv[1:]==['run5']:run(True,5)
    else:print(__doc__)
