"""Eight finite native consumers and one host-only contract; parse never reruns native work."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('wave_build',W/'build.py');wrapper=importlib.util.module_from_spec(spec);spec.loader.exec_module(wrapper)
b=wrapper.b;t=wrapper.t;R=wrapper.R
FIXTURE=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
CASES={'group-cpu':('cpu','--mtp-group-return'),'group-cuda':('cuda','--mtp-group-return')}
def prepare():
 b.validate();ready=t.read(W/'ready-tiny.json');t.exact(ready['image']);t.exact(ready['inputs'])
 t.save(W/'run-plan.json',dict(script=t.pin(__file__),fixture=t.pin(FIXTURE/'weights.tsv'),ready=t.pin(W/'ready-tiny.json'),native_processes=2,host_contract_processes=0,automatic_retries=0,cases={name:dict(backend=backend,flag=flag,command=[ready['image']['path'],'--'+backend,str(FIXTURE),flag]) for name,(backend,flag) in CASES.items()},performance_claim=False,quality_claim=False))
 print('RUN PLAN2: group CPU/CUDA; no process started')
def run(name):
 b.validate();plan=t.read(W/'run-plan.json')
 for field in ['script','fixture','ready']:t.exact(plan[field])
 ready=t.read(plan['ready']['path']);t.exact(ready['image']);t.exact(ready['inputs'])
 row=plan['cases'][name];out=W/'runs'/name
 assert not out.exists(),'Preserve every attempt; parse offline, never retry'
 process=t.execute(row['command'],out,300)
 t.save(out/'as-run.json',dict(image=ready['image'],ready=plan['ready'],inputs=ready['inputs'],source_freeze=ready['source_freeze'],run_plan=t.pin(W/'run-plan.json'),fixture=plan['fixture'],process=process))
 reports=[json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
 assert reports and all(x.get('status','PASS')=='PASS' for x in reports if 'case' in x or 'mode' in x)
 print('NATIVE EXIT0',name,'PID',process['pid'],'reports',len(reports))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='run':run(sys.argv[2])
 else:raise ValueError(sys.argv[1])
