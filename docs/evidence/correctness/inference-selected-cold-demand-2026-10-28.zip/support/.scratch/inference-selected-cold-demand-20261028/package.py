"""Offline-only nine-consumer parser/package. Complete reports stay in ZIP, public JSON is compact."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import sys
import zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
V=W/'validation'
DEST=R/'docs/evidence/correctness/inference-selected-cold-demand-2026-10-28'
PREVIOUS=R/'.scratch/inference-wave-batches-20261028/package.py'
SAMPLER=R/'.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py'
OLD=R/'.scratch/inference-wave-batches-20261028/validation/attempt2'
CASES={'cold-demand':('host','cold','--cold-demand')}
for kind,flag in [('group','--mtp-group-return'),('wave','--generation-wave'),
                  ('policies','--sampling-policies'),('sampler','--mtp-sampling')]:
 for backend in ('cpu','cuda'):CASES[kind+'-'+backend]=(backend,kind,flag)

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def exact(row):assert pin(row['path'])==row,row['path']
def save(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def reports(p):
 return [json.loads(line) for line in Path(p).read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]

def cold_report(xs):
 assert len(xs)==1
 x=xs[0];assert x['status']=='PASS' and x['case']=='cold-demand'
 assert x['models']==x['native_submissions']==0 and x['performance_claim'] is False
 for field in ('inventory_zero_without_support','ordered_counted_possible','unique_members',
   'cumulative_rows_policy_and_key_isolation','overflow_without_partial_note','use_hints_not_measured_native_calls'):
  assert x[field] is True,field
 return x

def group_report(xs,backend):
 assert len(xs)==1
 x=xs[0];assert x['status']=='PASS' and x['case']=='mtp-group-return' and x['backend']==backend
 assert (x['models'],x['actual_active_sequences'],x['logical_requests'])==(1,2,3)
 assert x['submitted_widths']==[2,3] and x['original_participant']==2
 assert x['actual_q_before_grouping']==5 and x['actual_q_after_failure']==4
 assert x['successful_peer_repairs']==1 and x['no_proposal_regeneration'] is True
 assert x['draft_program_calls_after_failure']==x['draft_program_calls_before_grouping']+1
 for field in ('original_calls_and_q_returned','earlier_group_commit_preserved',
   'failed_heads_ledger_rng_unchanged','actual_retirement','same_key_host_restore_retry','synthetic_untrained'):
  assert x[field] is True,field
 assert x['quality_claim'] is False and x['performance_claim'] is False and x['final_versions']==0
 return x

def cold_facts(path):
 selected=[]
 for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
  if line.startswith(('planned_replay ','compiled T=','compiled text finite family ','cold_shape_plan ')):
   selected.append(re.sub(r'\s+(?:cold_seconds|child_prepare_seconds)=[^ ]+','',line))
 return selected

def comparisons(validation,previous):
 rows=[]
 for name in ('policies-cpu','policies-cuda','sampler-cpu','sampler-cuda'):
  old=OLD/'runs'/name/'stderr.log';new=validation/'runs'/name/'stderr.log'
  a,z=cold_facts(old),cold_facts(new)
  assert a and z
  differences=[]
  for index in range(max(len(a),len(z))):
   aa=a[index] if index<len(a) else None;zz=z[index] if index<len(z) else None
   if aa!=zz:differences.append(dict(index=index,previous=aa,current=zz))
  signature=lambda values:hashlib.sha256(('\n'.join(values)+'\n').encode('utf-8')).hexdigest()
  rows.append(dict(case=name,status='MATCH' if not differences else 'FACT_DIFFERENCES_PRESERVED',
   previous_stderr=pin(old),current_stderr=pin(new),previous_facts=a,current_facts=z,differences=differences,
   previous_line_count=len(a),current_line_count=len(z),previous_signature=signature(a),current_signature=signature(z),
   explanation='Only actual printed cold metadata is compared. Timing fields cold_seconds/child_prepare_seconds are removed. Any remaining differences are retained for source review, never silently exempted.'))
 return dict(scope='Four retained prior processes are offline cold-fact references only, not new runs, pooled tests, performance samples or proof of complete generated-output mathematical equality.',
  previous_evidence=pin(R/'docs/evidence/correctness/inference-request-wave-batches-2026-10-28.json'),
  comparisons=rows,total_current_lines=sum(row['current_line_count'] for row in rows),all_match=all(not row['differences'] for row in rows))

def ready_metadata(path):
 ready=read(path);assert ready['compiled']['process']['exit']==ready['process']['exit']==0
 exact(ready['inputs']);assert len(read(ready['inputs']['path']))==228
 exact(ready['source_freeze']);freeze=read(ready['source_freeze']['path'])
 for row in freeze['snapshots']:exact(row['snapshot'])
 return dict(pin=pin(path),ready=ready)

def product_dependencies(builds):
 manifests=[];baseline=None
 for build in builds:
  path=Path(build['pin']['path']).parent/'frozen-project-dependencies.json'
  product={row['path']:dict(bytes=row['bytes'],sha256=row['sha256']) for row in read(path)
   if Path(row['path']).relative_to(R).parts[0] in ('engine','include','src')}
  assert product
  if baseline is None:baseline=product
  else:assert product==baseline,'Product dependencies changed across test-only refinements'
  manifests.append(pin(path))
 return dict(product_SHA256_equal=True,product_files=len(baseline),manifests=manifests,
  explanation='Frozen actual project-dependency identities under engine/include/src are identical across all three images. Only the group test header was refined; the other seven successful consumers were retained without rerun.')

def analyze(validation,groups):
 previous=module('previous_actual_wave_package',PREVIOUS)
 sampler=module('previous_actual_sampler_parser',SAMPLER)
 cases=[];checks=[]
 for name,(backend,kind,flag) in CASES.items():
  folder=(groups if kind=='group' else validation)/'runs'/name
  p=read(folder/'process.json');command=read(folder/'command.json')
  assert p['exit']==0 and not p.get('timed_out',False) and p.get('state','TERMINAL')=='TERMINAL',name
  assert flag in command['command'] and (backend=='host' or '--'+backend in command['command']),name
  actual=read(folder/'as-run.json');assert actual['process']==p
  xs=reports(folder/'stdout.log')
  if kind=='cold':value=cold_report(xs)
  elif kind=='group':value=group_report(xs,backend)
  elif kind=='wave':value=previous.wave_report(xs,backend)
  elif kind=='policies':value=previous.policy_reports(xs,backend)
  else:
   value=sampler.sampler_reports(xs,backend);state=value['manual']['state_checks'];assert len(state)==17
   checks.extend(state)
  cases.append(dict(name=name,backend=backend,kind=kind,status='PASS',process=p,command=command,reports=value,
   as_run=actual,evidence=[pin(folder/f) for f in ('command.json','process.json','stdout.log','stderr.log','as-run.json')]))
 assert len({row['process']['pid'] for row in cases})==9 and len(checks)==34
 builds=[ready_metadata(p) for p in sorted(validation.rglob('ready-tiny.json'))]
 assert len(builds)==3
 ready_by_path={x['pin']['path']:x for x in builds}
 for case in cases:
  original=case['as_run'];exact(original['ready']);exact(original['inputs']);exact(original['source_freeze'])
  ready=ready_by_path[original['ready']['path']]['ready']
  assert original['image']==ready['image'] and original['inputs']==ready['inputs'] and original['source_freeze']==ready['source_freeze']
 # Only the test header changed across these actual compiler images. No
 # canonical-source hash is backdated onto either earlier successful consumer.
 identities={}
 for build in builds:
  for row in read(build['ready']['source_freeze']['path'])['snapshots']:
   identities.setdefault(row['original']['path'],set()).add(row['original']['sha256'])
 changed=[path for path,values in identities.items() if len(values)>1]
 assert changed==[str(R/'tests/tools/qwen_mtp_group_return_case.h')],changed
 failures=[]
 for path in sorted(validation.glob('**/runs/group-cpu/process.json')):
  process=read(path)
  if process['exit']==0:continue
  assert process['exit']==1 and not process.get('timed_out',False)
  folder=path.parent;owner=folder.parent.parent;freeze=read(owner/'final-source-freeze.json')
  header=next(row for row in freeze['snapshots'] if row['original']['path'].endswith('qwen_mtp_group_return_case.h'))
  failures.append(dict(process=process,kind='native_test_assertion_failure',source=header,
   evidence=[pin(folder/f) for f in ('command.json','process.json','stdout.log','stderr.log')],
   explanation='The test wrongly expected no additional draft-program call after its earlier successful B verifier. B actually performs one head=false repair; its original q is not regenerated. The first catch hid the error details; the second diagnostic confirmed InvalidArgument/participant2/retired OK, submitted [2,3], five-to-four live q and draft calls5-to6. Product and N6/q6 budgets were unchanged.'))
 assert len(failures)==2
 assert len({row['process']['pid'] for row in cases+failures})==11
 cxx=[dict(receipt=pin(p),process=read(p)) for p in sorted(validation.glob('**/logs/tiny/process.json'))]
 links=[dict(receipt=pin(p),process=read(p)) for p in sorted(validation.glob('**/links/tiny/process.json'))]
 assert all(x['process']['exit']==0 for x in cxx+links)
 build=dict(CXX_attempts=cxx,link_attempts=links,source_images=[x['pin'] for x in builds],
  link_inputs_per_image=228,retained_SDK_weights=227,SDK_CXX=0,NVCC=0)
 return dict(schema='hyle.selected-calls-cold-demand.correctness.v1',status='PASS_NINE_FINITE_CONSUMERS',
  successful_consumer_processes=9,host_contract_processes=1,native_model_successful_processes=8,
  native_model_failed_processes=2,total_native_or_host_attempts=11,automatic_retries=0,
  group_CPU_attempts=3,group_CUDA_attempts=1,unchanged_seven_consumers_run_once=True,
  structured_state_comparisons=34,byte_exact_state_comparisons=sum(bool(row['payloads_byte_equal']) for row in checks),
  cases=cases,failed_attempts=failures,builds=builds,actual_build=build,product_dependencies=product_dependencies(builds),
  cold_fact_comparison=comparisons(validation,previous),parser=pin(__file__),reused_parsers=[pin(PREVIOUS),pin(SAMPLER)],
  boundaries=dict(synthetic_cached_fixture=True,performance_claim=False,quality_claim=False,Apple_tested=False,Vulkan_tested=False,
   unknown_native_failure_claim=False,full_RequestLoop_service_claim=False,
   notes=['Only sampler17 structured full-state rows per backend are counted; group/host/wave/policy assertions are not invented state-check rows.',
    'Group failure is a real submitted target/private terminal with actual retirement; it is a finite component regression, not a claim that a user workload failure was observed.',
    'The previous old-copy witness remains a component recipe within a successful process, not execution of the old complete natural entry.',
    'Ordinary natural endpoint retains one charged prefix/version; its original C++ case verifies zero versions after function return.',
    'Cold demand counters are conservative scheduling hints, not measured native work. Mathematical/role eligibility and native resource/retirement authority remain with their original owners.',
    'Seven original successful consumers were not rerun; the final group CPU/CUDA use the corrected test-only image. Two earlier real CPU assertion failures and all three frozen test identities remain archived.']))

def compact(analysis):
 cases=[]
 for row in analysis['cases']:
  report=row['reports']
  if row['kind']=='policies':
   n=report['natural'];brief=dict(final=report['final'],endpoint=dict(
    sessions=n['session_count'],turns=n['turn_count'],admitted=n['admitted_requests'],retired=n['retired_requests'],
    prefix_entries=n['prefix_entries'],live_versions=n['live_committed_versions']))
  elif row['kind']=='sampler':
   brief=dict(final=report['final'],manual_structured_state_checks=len(report['manual']['state_checks']),
    all_manual_payloads_byte_equal=all(x['payloads_byte_equal'] for x in report['manual']['state_checks']))
  else:brief=report
  cases.append(dict(name=row['name'],backend=row['backend'],status=row['status'],process=row['process'],facts=brief))
 return dict(schema=analysis['schema'],status=analysis['status'],successful_consumer_processes=9,host_contract_processes=1,
  native_model_successful_processes=8,native_model_failed_processes=2,total_native_or_host_attempts=11,
  automatic_retries=0,group_CPU_attempts=3,group_CUDA_attempts=1,unchanged_seven_consumers_run_once=True,
  structured_state_comparisons=34,
  byte_exact_state_comparisons=analysis['byte_exact_state_comparisons'],actual_build=analysis['actual_build'],cases=cases,
  failed_attempts=[dict(process=row['process'],kind=row['kind'],explanation=row['explanation']) for row in analysis['failed_attempts']],
  product_dependencies=analysis['product_dependencies'],
  cold_fact_comparison=dict(all_match=analysis['cold_fact_comparison']['all_match'],
   scope=analysis['cold_fact_comparison']['scope'],total_current_lines=analysis['cold_fact_comparison']['total_current_lines'],
   cases=[dict(case=x['case'],status=x['status'],current_lines=x['current_line_count'],
    previous_signature=x['previous_signature'],current_signature=x['current_signature'],differing_lines=len(x['differences']))
    for x in analysis['cold_fact_comparison']['comparisons']]),
  boundaries=analysis['boundaries'],parser=analysis['parser'])

def package(validation,analysis):
 paths={}
 def add(p,name):
  p=Path(p)
  if p.is_file():paths[name.replace('\\','/')]=p
 snapshots={}
 for build in analysis['builds']:
  for row in read(build['ready']['source_freeze']['path'])['snapshots']:
   source=Path(row['snapshot']['path']).resolve()
   member='source-snapshots/'+row['snapshot']['sha256']+'/'+source.name
   snapshots[str(source)]=member;add(source,member)
 for p in sorted(validation.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(validation)
  if p.suffix.lower() not in ('.json','.py','.log','.cc','.h','.patch','.txt'):continue
  if rel.parts[0]=='bin':continue
  if 'source' in rel.parts and p.suffix.lower() in ('.cc','.h'):continue
  add(p,'validation/'+rel.as_posix())
 for root in (R/'.scratch/inference-selected-request-calls-20261028',R/'.scratch/inference-cold-demand-20261028'):
  for p in sorted(root.glob('*')):
   if p.is_file() and p.suffix.lower() in ('.json','.patch','.py'):add(p,'support/'+p.relative_to(R).as_posix())
 for p in (Path(__file__),W/'analysis.json',PREVIOUS,SAMPLER):add(p,'support/'+p.relative_to(R).as_posix())
 for row in analysis['cold_fact_comparison']['comparisons']:
  add(row['previous_stderr']['path'],'previous-cold-facts/'+row['case']+'/stderr.log')
 generated={'source-snapshot-index.json':(json.dumps(snapshots,indent=2)+'\n').encode('utf-8')}
 manifest=[dict(member=name,bytes=p.stat().st_size,sha256=pin(p)['sha256']) for name,p in sorted(paths.items())]
 manifest.extend(dict(member=name,bytes=len(value),sha256=hashlib.sha256(value).hexdigest()) for name,value in generated.items())
 archive=DEST.with_suffix('.zip');archive.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in sorted(paths.items()):z.write(p,name)
  z.writestr('manifest.json',json.dumps(dict(members=manifest),indent=2)+'\n')
  for name,value in generated.items():z.writestr(name,value)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for row in manifest:
   b=z.read(row['member']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 public=compact(analysis);public.update(archive=pin(archive),archive_members=len(manifest)+1,
  archive_readback=dict(CRC=True,member_SHA256=True),complete_analysis=pin(W/'analysis.json'),
  excludes=['OBJ','EXE','DLL','PDB','LIB','SDK/weight payloads'])
 save(DEST.with_suffix('.json'),public)
 print(json.dumps(dict(status=public['status'],json=pin(DEST.with_suffix('.json')),zip=public['archive'],members=len(manifest)+1),indent=2))

def main():
 p=argparse.ArgumentParser();p.add_argument('--validation',type=Path,default=V)
 p.add_argument('--group-validation',type=Path,default=V/'final');p.add_argument('--package',action='store_true')
 args=p.parse_args();validation=args.validation.resolve();groups=args.group_validation.resolve()
 assert validation.is_relative_to(W) and groups.is_relative_to(validation) and groups!=validation
 result=analyze(validation,groups)
 target=W/'analysis.json'
 if target.exists():assert read(target)==result,'Preserve prior analysis; use an explicit offline refinement'
 else:save(target,result)
 if args.package:package(validation,result)
 else:print('OFFLINE_ANALYSIS_SAVED; no archive/native process started')

if __name__=='__main__':main()
