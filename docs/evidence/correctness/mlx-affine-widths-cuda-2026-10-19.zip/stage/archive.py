"""Archive measured CUDA affine-width contracts, with exact vector restoration."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent.parent
ROOT = ARCH.parents[1]
OUT = STAGE / 'checks/20261019T135721'
DEST = ROOT / 'docs/evidence/correctness/mlx-affine-widths-cuda-2026-10-19.zip'
BASELINE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/recurrent-gdn-schema.zip'
LATEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/decode-resource-binding-index.zip'
EXCLUDED = {'.exe', '.obj', '.lib', '.exp', '.map', '.pdb', '.dll', '.pyc', '.tmp'}
SUPPORT = (
    'decode-host-path-review/build.py', 'cuda-grouped-fusion/build.py', 'cuda-fusion-allocation/build.py',
    'recurrent-gdn-schema/build.py', 'immutable-alias-index/build.py', 'cuda-fusion-precision/build.py',
    'cuda-fusion-layout/build.py', 'cuda-gdn-l2-epilogue/build.py', 'cuda-explicit-rope/build.py',
    'cuda-bf16-dual-projection/build_current.py', 'cuda-projection-fusion/build.py',
    'cold-constant-retirement/cold_check.py', 'cuda-bf16-dual-projection/compare_numerics.py',
)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(8 << 20), b''):
            h.update(data)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def verify(row):
    if identity(row['path']) != row:
        raise ValueError('Compiled/frozen identity drift: ' + row['path'])
    return Path(row['path']).resolve()


def main():
    if DEST.exists():
        raise ValueError('Archive exists')
    compile_plan = read(OUT / 'plan-for-link.json')
    link_plan = read(OUT / 'link-plan.json')
    tests = read(OUT / 'run-cuda/summary.json')
    model = read(STAGE / 'correctness/summary.json')
    if not all(read(OUT / name)['passed'] for name in ('compile-summary.json', 'summary.json')):
        raise ValueError('Successful compile/link required')
    if not tests['passed'] or tests['arms']['cuda']['counts'] != {
            'tests': 23, 'failures': 0, 'disabled': 0, 'errors': 0, 'skipped': 0}:
        raise ValueError('Actual23 zero-skip tests required')
    if tests['arms']['direct-consumer']['PASS_lines'] != 1 or tests['arms']['graph-consumer']['PASS_lines'] != 4:
        raise ValueError('Public consumer observations differ')
    if not model['passed'] or model['observation']['equal_vectors'] != 64:
        raise ValueError('Expected64 exact model vectors')
    payloads = {}

    def add(name, path, expected=None):
        path = Path(path).resolve()
        if expected:
            verify(expected)
        if name in payloads and payloads[name] != path:
            raise ValueError('Conflicting payload name')
        payloads[name] = path

    for row in compile_plan['frozen']:
        path = verify(row)
        if path.is_relative_to(ROOT) and not path.is_relative_to(STAGE) and path.suffix.lower() not in EXCLUDED:
            add('frozen-input/' + path.relative_to(ROOT).as_posix(), path, row)
    for row in read(STAGE / 'application.json')['files']:
        path = ROOT / row['target']
        actual = identity(path)
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Applied CUDA source differs')
    if len(compile_plan['compile']) != 27:
        raise ValueError('Expected27 fresh CUDA-side owners')
    for row in compile_plan['compile']:
        receipt = read(OUT / (row['tag'] + '-identity.json'))
        verify(receipt['object'])
        path = verify(receipt['source'])
        snapshot = OUT / 'compiled-source' / path.relative_to(ROOT)
        if snapshot.read_bytes() != path.read_bytes():
            raise ValueError('Actual27 source snapshot differs')
        for dep in receipt['dependencies']:
            path = verify(dep)
            if path.is_relative_to(ROOT):
                add('compiled-header/' + path.relative_to(ROOT).as_posix(), path, dep)
    # The compile-phase script is retained under its original SHA, while only
    # link input accounting/implib placement changed after successful compiles.
    original = read(OUT / 'plan.json')
    historical = next(row for row in original['frozen'] if Path(row['path']) == STAGE / 'build.py')
    saved = identity(STAGE / 'build-before-link-input-fix.py')
    if (saved['bytes'], saved['sha256']) != (historical['bytes'], historical['sha256']):
        raise ValueError('Historical successful compile script is not preserved')
    shared_path = verify(link_plan['shared_object_receipt'])
    shared = read(shared_path)
    verify(shared['object'])
    if shared['object'] != link_plan['shared_object']:
        raise ValueError('Shared Mlx infer object differs')
    for row in [shared['source']] + shared['dependencies']:
        path = verify(row)
        if path.is_relative_to(ROOT):
            add('shared-compiled-source/' + path.relative_to(ROOT).as_posix(), path, row)
    add('shared-compile/weight-decode-identity.json', shared_path)
    for suffix in ('command.json', 'result.json', 'stdout.log', 'stderr.log'):
        path = shared_path.parent / ('weight-decode-compile.' + suffix)
        if path.exists():
            add('shared-compile/' + path.name, path)
    dep_index = shared['command'].index('/sourceDependencies')
    add('shared-compile/weight-decode-deps.json', Path(shared['command'][dep_index + 1]))
    for arm, expected in (('cuda', 138), ('qwen', 127), ('direct-consumer', 127), ('graph-consumer', 127)):
        link = read(OUT / (arm + '-link-plan.json'))
        if len(link['inputs']) != expected:
            raise ValueError('Actual final link closure differs')
        verify(read(OUT / (arm + '-image.json')))

    reference = {Path(row['path']).relative_to(ARCH / 'decode-host-path-review/correctness/trace').as_posix(): row
                 for row in read(STAGE / 'correctness/inputs.json')['reference_vectors']}
    baseline = identity(BASELINE)
    vectors = []
    with zipfile.ZipFile(BASELINE) as archive:
        for path in sorted((STAGE / 'correctness/trace').rglob('*')):
            if path.suffix not in ('.bf16', '.f32'):
                continue
            relative = path.relative_to(STAGE / 'correctness/trace').as_posix()
            current = identity(path)
            expected = reference[relative]
            entry = 'stage/correctness/trace/' + relative
            data = archive.read(entry)
            if (current['bytes'], current['sha256']) != (expected['bytes'], expected['sha256']) or (
                    len(data), sha(data)) != (current['bytes'], current['sha256']):
                raise ValueError('Model observation is not restorable from the archived baseline')
            vectors.append({'actual': current, 'latest_reference': expected,
                'archived_payload': {'entry': entry, 'bytes': len(data), 'sha256': sha(data)}})
    if len(vectors) != 64:
        raise ValueError('Expected64 current/latest/archive matches')
    restoration = {'all64_actual_latest_and_archived_payloads_equal': True,
        'baseline_payload_zip': baseline, 'latest_reference_evidence_zip': identity(LATEST),
        'vectors': vectors, 'same_raw_vector_payloads_omitted_from_this_ZIP': True,
        'all_current_and_latest_raw_vectors_retained': True}
    (STAGE / 'correctness/vector-restoration.json').write_text(json.dumps(restoration, indent=2) + '\n')
    # Planning only: root owns deletion. Keep both current production images.
    targets = [identity(path) for path in sorted(OUT.iterdir()) if path.is_file() and (
        path.suffix in ('.lib', '.exp', '.map') or path.name in ('direct-consumer.exe', 'graph-consumer.exe'))]
    reclaim = {'executed': False, 'must_use_root_test_ps1': True, 'targets': targets,
        'count': len(targets), 'bytes': sum(row['bytes'] for row in targets),
        'retained_current_images': [read(OUT / (arm + '-image.json')) for arm in ('cuda', 'qwen')],
        'all_objects_recipes_and_raw_model_vectors_retained': True}
    (STAGE / 'reclaim-targets.json').write_text(json.dumps(reclaim, indent=2) + '\n')
    scope = {'public_header': compile_plan['header'], 'fresh_cuda_side_owners': 27,
        'native_TUs': 1, 'host_TUs': 26, 'additional_shared_root_weight_decode_owner': shared['object'],
        'link_inputs': {'cuda': 138, 'qwen': 127, 'direct-consumer': 127, 'graph-consumer': 127},
        'gtest_cases': 23, 'gtest_failure_skip_count': 0, 'public_Direct_domains': 1, 'public_Graph_domains': 4,
        'fresh_full_model_processes': 1, 'exact_model_vectors': 64,
        'current_model':'BF16 Qwen; this is public-schema/provider regression, not a full MLX affine artifact execution claim',
        'throughput_claim': False, 'new_profile_runs': 0, 'SDK_rebuild': False,
        'raw_vectors_retained_but_deduplicated_in_ZIP': True,
        'other_platform_and_unapplied_sources_excluded': True,
        'images_objects_SDK_weights_maps_tmp_excluded': True,
        'historical_compile_script_preserved_and_link_only_correction_explained': True}
    (STAGE / 'archive-scope.json').write_text(json.dumps(scope, indent=2) + '\n')
    for relative in SUPPORT:
        path = ARCH / relative
        add('replay-support/' + path.relative_to(ROOT).as_posix(), path)
    add('replay-support/tests/compute_provider_native/half_test_support.h', ROOT / 'tests/compute_provider_native/half_test_support.h')
    for path in sorted(STAGE.rglob('*')):
        relative = path.relative_to(STAGE)
        if not path.is_file() or path.suffix.lower() in EXCLUDED or 'tmp' in relative.parts or '__pycache__' in relative.parts:
            continue
        if path.name == 'archive-verification.json' or (path.is_relative_to(STAGE / 'correctness/trace') and path.suffix in ('.bf16', '.f32')):
            continue
        add('stage/' + relative.as_posix(), path)
    records = []
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(payloads.items()):
            data = path.read_bytes()
            records.append({'entry': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)})
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(records) + 1:
            raise ValueError('ZIP CRC/count failed')
        for row in records:
            data = archive.read(row['entry'])
            if (len(data), sha(data)) != (row['bytes'], row['sha256']):
                raise ValueError('ZIP payload SHA/size differs')
    receipt = dict(identity(DEST), CRC_and_every_payload_SHA_verified=True, payloads=len(records),
        entries_including_manifest=len(records)+1, uncompressed_payload_bytes=sum(row['bytes'] for row in records),
        fresh_cuda_side_owners=27, CUDA_gtests=23, public_Direct_domains=1, public_Graph_domains=4,
        exact_model_vectors=64, throughput_claim=False, repeated_vector_payloads_omitted=True)
    text = json.dumps(receipt, indent=2) + '\n'
    (STAGE / 'archive-verification.json').write_text(text)
    DEST.with_name('mlx-affine-widths-cuda-2026-10-19-archive.json').write_text(text)
    print(text, flush=True)


if __name__ == '__main__':
    main()
