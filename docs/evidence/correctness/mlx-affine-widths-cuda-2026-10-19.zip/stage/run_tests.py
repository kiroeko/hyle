"""Run the packed MLX contract checks and real public Direct/Graph consumers."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('mlx_cuda_checks_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan)
out = plan_path.parent / 'run-cuda'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
if not c.read(plan_path.parent / 'summary.json')['passed']:
    raise ValueError('Successful current links required')
summary = {'passed': False, 'arms': {}, 'new_throughput_or_profiler_runs': 0,
           'actual_model_artifact_validation': False}
try:
    for arm in ('cuda', 'direct-consumer', 'graph-consumer'):
        link = plan['links'][arm]
        arm_out = out / arm
        arm_out.mkdir()
        (arm_out / 'tmp').mkdir()
        image = b.identity(link['image'])
        if image != c.read(plan_path.parent / (arm + '-image.json')):
            raise ValueError('Test image differs from final link receipt')
        env, directories = b.environment(link['command'], link['inputs'], arm_out)
        c.save(arm_out / 'runtime-environment.json', {'link_input_paths': link['inputs'],
            'runtime_directories': directories, 'CPU_CUDA_DLL_union_used': False})
        command = [link['image']]
        if arm == 'cuda':
            command += ['--gtest_color=no',
                '--gtest_filter=CudaPackedWeights.*:OriginalDtypes/CudaMlxPrecision.*',
                '--gtest_output=xml:' + str(arm_out / 'cuda.xml')]
        c.execute(arm, command, env, arm_out)
        if arm == 'cuda':
            root = ET.parse(arm_out / 'cuda.xml').getroot()
            counts = {key: int(root.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
            counts['skipped'] = len(root.findall('testsuite/testcase/skipped'))
            passed = counts['tests'] == 23 and not any(counts[k] for k in ('failures', 'disabled', 'errors', 'skipped'))
            row = {'passed': passed, 'counts': counts, 'image': image}
        else:
            log = (arm_out / (arm + '.stdout.log')).read_text()
            expected = 4 if arm == 'graph-consumer' else 1
            passes = sum(line.startswith('PASS CUDA') for line in log.splitlines())
            row = {'passed': passes == expected, 'PASS_lines': passes, 'expected_domains': expected, 'image': image}
        summary['arms'][arm] = row
        c.save(arm_out / 'summary.json', row)
        if not row['passed']:
            raise ValueError('Actual executed MLX checks differ from expected scope')
    build.check(plan)
    summary['passed'] = True
finally:
    c.save(out / 'summary.json', summary)
print('MLX_CUDA', summary, flush=True)
