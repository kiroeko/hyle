"""Compile the actual MLX inline/CUDA closure, then link only affected images."""
from pathlib import Path
import argparse
import ctypes
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('mlx_cuda_cached', ARCH / 'decode-host-path-review/build.py')
cached = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cached)
b, c = cached.b, cached.c
BASE = ARCH / 'decode-host-path-review/checks/20261019T133822-fixture'


def split_windows(command):
    parser = ctypes.windll.shell32.CommandLineToArgvW
    parser.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    parser.restype = ctypes.POINTER(ctypes.c_wchar_p)
    count = ctypes.c_int()
    values = parser(command, ctypes.byref(count))
    if not values:
        raise ValueError('Windows command parsing failed')
    result = [values[i] for i in range(count.value)]
    ctypes.windll.kernel32.LocalFree(ctypes.cast(values, ctypes.c_void_p))
    return result


def check(plan):
    for row in plan['frozen']:
        if b.identity(row['path']) != row:
            raise ValueError('Source/header/recipe drift: ' + row['path'])


def prepare():
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    inventory = c.read(STAGE / 'owner-inventory-draft.json')
    if inventory['unknown'] or len(inventory['header_owners']) != 22:
        raise ValueError('Expected22 actual header-dependent bare-object owners and no unknown')
    ninja = c.read(STAGE / 'ninja-cuda-test-recipes.json')
    rows, frozen = [], []
    for i, owner in enumerate(inventory['header_owners']):
        source = Path(owner['source'])
        tag = f'{i:02d}-' + source.parent.name + '-' + source.stem
        row = {'tag': tag, 'source': b.identity(source), 'recipe': b.identity(owner['recipe']),
            'command': b.host_command(owner['command_template'], source, tag, out),
            'object': str(out / (tag + '.obj')), 'closures': owner['closures'],
            'old_object': {key: owner[key] for key in ('path', 'bytes', 'sha256')},
            'native': False, 'model_ops_header_required': True}
        rows.append(row)
        frozen += [row['source'], row['recipe']]
        frozen += [b.identity(path) for path in b.host_dependencies(owner['command_template'])]
    extra = [
        ('packed-test', 'tests/compute_provider_torch_cuda/packed_test.cc', ['cuda']),
        ('precision-test', 'tests/compute_provider_torch_cuda/mlx_precision_test.cc', ['cuda']),
        ('direct-consumer', 'tests/compute_provider_torch_cuda/packed_resident_consumer.cc', ['direct-consumer']),
        ('graph-consumer', 'tests/graph_route_cuda/packed_resident_consumer.cc', ['graph-consumer']),
    ]
    for tag, relative, closures in extra:
        source = ROOT / relative
        entry = next((row for row in ninja['entries'] if Path(row['file']).resolve() == source), None)
        basis = 'actual literal Ninja target recipe'
        if entry is None and tag == 'graph-consumer':
            entry = next(row for row in ninja['entries'] if row['file'].endswith('/compute_provider_torch_cuda/packed_resident_consumer.cc'))
            basis = 'same public Direct consumer C++ target recipe, changed source only; Graph route libraries inherited from actual Qwen closure'
        if entry is None:
            raise ValueError('Missing fixture compile recipe')
        command = b.host_command(split_windows(entry['command']), source, tag, out)
        rows.append({'tag': tag, 'source': b.identity(source), 'recipe': b.identity(STAGE / 'ninja-cuda-test-recipes.json'),
            'recipe_basis': basis, 'command': command, 'object': str(out / (tag + '.obj')),
            'closures': closures, 'old_object': None, 'native': False, 'model_ops_header_required': True})
        frozen.append(b.identity(source))
    native = next(row for row in ninja['entries'] if row['file'].endswith('/mlx_packed_kernel.cu'))
    source = ROOT / 'src/compute_provider_torch_cuda/mlx_packed_kernel.cu'
    command, skip = [], False
    for arg in split_windows(native['command']):
        if skip:
            skip = False
        elif arg in ('-MT', '-MF', '-c', '-o'):
            skip = True
        elif not arg.startswith('-Xcompiler=-Fd'):
            command.append(arg)
    tag = 'mlx-packed-kernel'
    command += ['-MT', str(out / (tag + '.obj')), '-MF', str(out / (tag + '.d')),
        '-c', str(source), '-o', str(out / (tag + '.obj')),
        '-Xcompiler=-Fd' + str(out / (tag + '.pdb')) + ',-FS']
    rows.insert(0, {'tag': tag, 'source': b.identity(source), 'recipe': b.identity(STAGE / 'ninja-cuda-test-recipes.json'),
        'command': command, 'object': str(out / (tag + '.obj')), 'native': True,
        'closures': ['cuda', 'qwen', 'direct-consumer', 'graph-consumer'], 'old_object': None,
        'model_ops_header_required': False})
    for path in (Path(__file__), STAGE / 'owner-inventory-draft.json', STAGE / 'ninja-cuda-test-recipes.json',
            STAGE / 'application.json', STAGE / 'source-freeze.json', STAGE.parent / 'header-freeze.json',
            ROOT / 'include/hyle/compute/model_ops.h', ROOT / 'tests/compute_models/mlx_affine_bitstream.h',
            ROOT / 'src/compute_provider_torch_cuda/mlx_packed_kernel.h',
            ROOT / 'src/compute_backend_cuda/device_status_kernel.h',
            ROOT / 'third_party/mlx_cuda_quant/mlx_cuda_quant.h'):
        frozen.append(b.identity(path))
    frozen += [row['source'] for row in rows]
    for row in rows:
        source = Path(row['source']['path'])
        target = out / 'compiled-source' / source.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
    plan = {'out': str(out), 'compile': rows, 'frozen': list({row['path'].casefold(): row for row in frozen}.values()),
        'base_links': {arm: b.identity(BASE / (arm + '-link-plan.json')) for arm in ('cuda', 'qwen')},
        'header': b.identity(ROOT / 'include/hyle/compute/model_ops.h'),
        'native_TUs': 1, 'host_TUs': 26, 'SDK_rebuild': False,
        'shared_weight_decode_object_supplied_at_link': True}
    if len(rows) != 27:
        raise ValueError('Expected one native and26 host compiles')
    c.save(out / 'plan.json', plan)
    print('COMPILE_PLAN', out / 'plan.json', flush=True)
    return out / 'plan.json'


def compile_all(path):
    plan = c.read(path)
    out = Path(plan['out'])
    check(plan)
    inputs = [row['path'] for row in c.read(BASE / 'cuda-link-plan.json')['inputs']]
    summary = {'passed': False, 'compiled': [], 'SDK_build': False}
    try:
        for row in plan['compile']:
            check(plan)
            # Successful owners are immutable and safely reused on fixture-only
            # retry. Do not repeat expensive C++ or unchanged link arms.
            receipt_path = out / (row['tag'] + '-identity.json')
            if receipt_path.exists():
                receipt = c.read(receipt_path)
                if receipt['source'] == row['source'] and b.identity(receipt['object']['path']) == receipt['object']:
                    summary['compiled'].append(row['tag'])
                    continue
                raise ValueError('Existing owner receipt differs')
            # NVCC inherits the real host compiler environment; its own bin
            # directory is not an MSVC installation or a new -ccbin choice.
            host_command = next(item['command'] for item in plan['compile'] if not item['native'])
            env, _ = b.environment(host_command, inputs, out)
            c.execute(row['tag'] + '-compile', row['command'], env, out)
            deps = [] if row['native'] else sorted(b.host_dependencies(row['command']))
            if row['model_ops_header_required'] and ROOT / 'include/hyle/compute/model_ops.h' not in deps:
                raise ValueError('Fresh inline owner did not include current public model_ops')
            c.save(receipt_path, {'source': row['source'], 'object': b.identity(row['object']), 'command': row['command'],
                'dependencies': [b.identity(path) for path in deps], 'native': row['native'], 'closures': row['closures']})
            summary['compiled'].append(row['tag'])
        check(plan)
        summary['passed'] = True
    finally:
        c.save(out / 'compile-summary.json', summary)
    print('COMPILE', summary, flush=True)


def link_all(path, common_path, common_receipt):
    plan = c.read(path)
    out = Path(plan['out'])
    check(plan)
    if not c.read(out / 'compile-summary.json')['passed']:
        raise ValueError('Successful compile closure required')
    common = b.identity(common_path)
    external = b.identity(common_receipt)
    replacements = {row['old_object']['path'].casefold(): row['object']
                    for row in plan['compile'] if row['old_object']}
    by_tag = {row['tag']: row for row in plan['compile']}
    qwen_main = next(row for row in plan['compile'] if Path(row['source']['path']) == ROOT / 'tools/qwen35_text/main.cc')
    links = {}
    for arm in ('cuda', 'qwen', 'direct-consumer', 'graph-consumer'):
        base = c.read(BASE / (('cuda' if arm == 'cuda' else 'qwen') + '-link-plan.json'))
        command = [replacements.get(arg.casefold(), arg) for arg in base['command']
                   if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if arm.endswith('consumer'):
            if command.count(qwen_main['object']) != 1:
                raise ValueError('Expected unique original Qwen main replacement')
            command = [by_tag[arm]['object'] if arg == qwen_main['object'] else arg for arg in command]
        additions = [by_tag['mlx-packed-kernel']['object'], common['path']]
        if arm == 'cuda':
            additions += [by_tag['packed-test']['object'], by_tag['precision-test']['object']]
        command[1:1] = additions
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image)]
        inputs = [arg for arg in command if Path(arg).suffix.lower() in ('.obj', '.lib')]
        if len(set(map(str.casefold, inputs))) != len(inputs):
            raise ValueError('Duplicate actual link input')
        links[arm] = {'command': command, 'inputs': inputs, 'image': str(image)}
    link_plan = {'compile_plan': b.identity(path), 'links': links, 'shared_object': common,
        'shared_object_receipt': external, 'header': plan['header'], 'frozen': plan['frozen']}
    c.save(out / 'link-plan.json', link_plan)
    summary = {'passed': False, 'links': []}
    try:
        for arm, link in links.items():
            check(plan)
            env, directories = b.environment(link['command'], link['inputs'], out)
            c.execute(arm + '-link', link['command'], env, out)
            c.save(out / (arm + '-image.json'), b.identity(link['image']))
            c.save(out / (arm + '-link-plan.json'), {'command': link['command'],
                'inputs': [b.identity(p) for p in link['inputs']]})
            summary['links'].append(arm)
        summary['passed'] = True
    finally:
        c.save(out / 'summary.json', summary)
    print('LINK', summary, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--plan', type=Path)
    parser.add_argument('--common-object', type=Path)
    parser.add_argument('--common-receipt', type=Path)
    args = parser.parse_args()
    path = args.plan.resolve() if args.plan else prepare()
    if args.compile:
        compile_all(path)
    if args.link:
        link_all(path, args.common_object, args.common_receipt)
