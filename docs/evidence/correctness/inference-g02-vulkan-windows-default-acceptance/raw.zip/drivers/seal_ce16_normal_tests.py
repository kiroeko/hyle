from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET

root=Path.cwd();base=root/'.scratch/inference-gaps/g02'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
normal=read(base/'ce16-normal-test-fixes/result.json');assert normal['state']=='TERMINAL_TARGETED_PASS' and len(normal['cases'])==18
original=read(base/'current-windows-cases-ce16-1/vulkan-layer-resume/result.json');assert original['pass_cases']==842 and original['failed_cases']==9 and original['skipped_cases']==0
for a in normal['artifacts']:assert sha(Path(a['path']))==a['sha256']
for row in normal['cases']:
 t=ET.parse(row['xml']).getroot();assert row['verdict']=='PASS' and t.attrib['tests']=='1' and t.attrib['failures']=='0' and t.attrib['errors']=='0' and not t.findall('.//skipped')
corrected={r['original_graph_case']:r for r in normal['cases'] if r['route']=='graph'};assert len(corrected)==9
effective=[]
for row in original['cases']:
 if row['name'] in corrected:effective.append({'name':row['name'],'verdict':'PASS','source':'normal-targeted-correction','stage':corrected[row['name']]['stage']})
 else:assert row['verdict']=='PASS';effective.append({'name':row['name'],'verdict':'PASS','source':'original-851-current-product','log':row['log'],'xml':row['xml']})
assert [r['name'] for r in effective]==original['expected_cases'] and len(effective)==851
reuse=read(base/'resume-windows-4/native-reuse.json')
for r in reuse['reused']:assert sha(Path(r['output']))==r['sha256']
for path,digest in reuse['post_build_generated_inputs'].items():assert sha(Path(path))==digest
dest=root/'evidence/correctness/inference-g02-vulkan-windows-default-acceptance';dest.mkdir(exist_ok=False)
(base/'ce16-normal-test-fixes/effective-851.json').write_text(json.dumps(effective,indent=2)+'\n')
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((base/'ce16-normal-test-fixes').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(base).as_posix())
 for name in ('validate_ce16_test_fixes.py','seal_ce16_normal_tests.py','ce16-collected-test-fixes.json'):z.write(base/name,'drivers/'+name)
 for row in normal['test_changes']:z.write(root/row['path'],'fixed-source/'+row['path'])
receipt={'kind':'G02_ORIGINAL_VULKAN_DEFAULT_GATE_FINITE_WINDOWS_ACCEPTANCE','verdict':'PASS_ALL_851_ORIGINAL_DEFAULT_CASES_AFTER_FINITE_TEST_CORRECTIONS','product_candidate':normal['product_candidate'],'evidence_head_before_test_only_commit':normal['evidence_head'],'normal_targeted':normal,
 'effective_original_default_cases':851,'original_unaffected_pass_cases':842,'corrected_graph_pass_cases':9,'counterpart_direct_pass_cases':9,'skipped':0,'original_monolithic_ctest_executed':False,
 'raw_original_gate':'evidence/correctness/inference-g02-vulkan-final-test-diagnostics/receipt.json','raw_original_gate_sha256':sha(root/'evidence/correctness/inference-g02-vulkan-final-test-diagnostics/receipt.json'),
 'inheritance_proof':['Only two private Vulkan run_q24_semantic_fragment reference callers and one private Vulkan Bank constructor changed; full product source/candidate/API/oracles/thresholds/shapes unchanged.','F32 reference branch only region0x08030801..04, nonquantized fixture with F32 MatMul. Direct and Graph call sites use this original region in pooled indexer test; DSA test explicitly excludes official models, sparse_attention changes region to0x07080310+tail. Other native reference branches untouched.','Bank branch only three public custom IQ1 formats. Complete C5 demand has exactly eight such items, all Kind::kExpert; all eight failed and now actually pass. All104 identities only chooses Kind::kProjection. Other Bank callers generate Q8_0/Q4_K/F16/BF16, unchanged.','Rebuilt exactly four test CXX TUs and two test exes. Native shader generator reports no work/up-to-date. Original provider DLL/test executable retain exact SHA.321 nativeobjects and151 generatedinputs independently rehashed unchanged after build.'],
 'native_reuse_post_build':{'objects':len(reuse['reused']),'generated_inputs':len(reuse['post_build_generated_inputs']),'all_sha_unchanged':True},
 'scope':'Only original851 Windows graph_route_vulkan default set, plus18affectednormaltests. OriginalCUDA804 already independently complete; new CE15/16 Air/source/static/shared still pending. No aggregateG02/goal/registry acceptance.',
 'history':'Original842PASS/9FAIL, missinglayer failures/parent-only interruption/unobserved in-flight child, oldalias/phase/math/build failures and all elapsed retained in immutable linked receipts; no failure reset or widened tolerance.',
 'raw_zip_sha256':sha(dest/'raw.zip')}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(receipt['verdict'])
