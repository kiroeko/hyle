from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';out=base/'ce16-normal-test-fixes';out.mkdir(exist_ok=False);build=Path('C:/h7/inference-g02-impacted')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
allowed={'tests/compute_route_vulkan/catalogue_gguf_test_support.h','tests/compute_route_vulkan/d5_qwen35_execution_test.cc','tests/graph_route_vulkan/d5_qwen35_execution_test.cc'}
dirty=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines());assert dirty==allowed
old=read(base/'current-windows-cases-ce16-1/vulkan-layer-resume/result.json');assert old['state']=='TERMINAL_ALL_DEFAULT_CASES_EXECUTED' and old['pass_cases']==842 and old['failed_cases']==9 and old['skipped_cases']==0
normal=read(base/'vulkan-phase-normal-fix-4/result.json')
for a in normal['artifacts']:assert sha(Path(a['path']))==a['sha256']
diagnostic=read(base/'vulkan-pooled-oracle-diagnostic/result.json');assert diagnostic['state']=='TERMINAL_DIAGNOSTIC_COLLECTED'
t=ET.parse(base/'vulkan-pooled-oracle-diagnostic/test.xml').getroot();assert t.attrib['tests']=='1' and t.attrib['failures']=='0' and not t.findall('.//skipped')
env={k.upper():v for k,v in os.environ.items()}
for line in subprocess.check_output(['cmd','/d','/c',str(base/'resume-windows-2/vs-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):k,v=line.split('=',1);env[k.upper()]=v
env['VK_LAYER_PATH']='C:/public/tools/hyle-vulkan/1.4.357.0/Bin';env['PATH']=env['VK_LAYER_PATH']+';'+env['PATH'];env['HYLE_D5_QWEN35_FIXTURE']=read(base/'current-model-fixture.json')['root']
record={'state':'SETUP','product_candidate':normal['candidate'],'evidence_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'test_changes':[{ 'path':n,'sha256':sha(root/n)} for n in sorted(dirty)],'scope':'Only original ninefailedGraph cases and counterpartDirect cases. Test reference/carrier corrections, no product/numerical threshold change. Original842PASS inherited only after exact unaffected-reference proof.','stages':[],'cases':[]}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def run(stage,args):
 t=time.monotonic()
 with (out/(stage+'.log')).open('w') as f:
  child=subprocess.Popen(args,cwd=build,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);record.update(state='RUNNING',stage=stage,pid=child.pid);save();print(stage,child.pid,flush=True);code=child.wait()
 row={'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-t};record['stages'].append(row);save()
 if code and stage in ('dry-plan','build'):record['state']='TERMINAL_BUILD_FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-5000:],flush=True);raise SystemExit(code)
 return row
args=['ninja','-C',str(build),'-f',str(base/'resume-windows-4/reuse-build.ninja'),'-j','4','-k','0'];targets=['hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests']
run('dry-plan',args+['-n']+targets);dry=(out/'dry-plan.log').read_text();assert 'Building CUDA object' not in dry and 'compute_ggml_runtime' not in dry and 'compute_provider' not in dry
for line in dry.splitlines():
 if 'Building CXX object' in line:assert 'd5_qwen35_execution_test.cc.obj' in line or 'catalogue_test.cc.obj' in line,line
run('build',args+targets)
for a in normal['artifacts'][:2]:assert sha(Path(a['path']))==a['sha256'],'product/provider binary changed in test-only build'
failed=[r['name'] for r in old['cases'] if r['verdict']!='PASS'];assert len(failed)==9
for route in ('graph','direct'):
 exe=build/'bin'/('hyle_graph_route_vulkan_test.exe' if route=='graph' else 'hyle_compute_route_vulkan_test.exe')
 for index,original in enumerate(failed):
  name=original if route=='graph' else original.replace('VulkanGraph','Vulkan');stage=f'{route}-{index:02d}';xml=out/(stage+'.xml')
  row=run(stage,[str(exe),'--gtest_filter='+name,'--gtest_color=no','--gtest_output=xml:'+str(xml)])
  verdict='FAIL_NO_XML'
  if xml.exists():
   t=ET.parse(xml).getroot();cases=t.findall('.//testcase');verdict='PASS' if row['exit_code']==0 and t.attrib['tests']=='1' and t.attrib['failures']=='0' and t.attrib['errors']=='0' and len(cases)==1 and not t.findall('.//skipped') else 'FAIL'
   assert len(cases)==1 and cases[0].attrib['classname']+'.'+cases[0].attrib['name']==name
  record['cases'].append({'route':route,'original_graph_case':original,'name':name,'verdict':verdict,'stage':stage,'xml':str(xml)});save()
record.update(state='TERMINAL_TARGETED_PASS' if all(r['verdict']=='PASS' for r in record['cases']) else 'TERMINAL_TARGETED_FAIL',artifacts=[{'path':a['path'],'sha256':sha(Path(a['path']))} for a in normal['artifacts']]);save();print(record['state'],[(r['name'],r['verdict']) for r in record['cases'] if r['verdict']!='PASS'],flush=True)
