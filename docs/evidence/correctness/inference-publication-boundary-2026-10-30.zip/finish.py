from pathlib import Path
import importlib.util,json,re,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('current_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact;p=read(W/'plan.json')
def stable(x):
 if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if not k.endswith('_seconds') and not k.endswith('_per_second')}
 if isinstance(x,list):return [stable(v) for v in x]
 return x
pairs=[('commit-host','attempt1'),('publication-cpu','attempt1'),('history-cpu','attempt1'),('varlen-cuda','attempt1'),('relay-cuda','attempt1'),('mtp','attempt1'),('greedy-cuda','attempt1'),('random-cuda','attempt2')]
checks=[]
for name,attempt in pairs:
 folder=W/'runs'/name/attempt;data=read(folder/'report.json');process=read(folder/'process.json')
 assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
 checks.append(dict(name=name,attempt=attempt,report=pin(folder/'report.json'),process=process))
old_mtp=R/'.scratch/inference-synchronous-step-driver-20261030/runs/mtp/attempt1/report.json'
assert stable(read(old_mtp))==stable(read(W/'runs/mtp/attempt1/report.json'))
old_glm=R/'.scratch/inference-common-step-driver-20261030/runs/greedy-cuda/attempt1/report.json'
props=read(W/'runs/greedy-cuda/attempt1/report.json')['cases'][0]['properties']
assert props==read(old_glm)['cases'][0]['properties'] and len(props)==54
receipts={}
for name in p['consumers']:
 path=W/'compile'/name/'receipt.json';v=read(path)
 for item in [v['object'],*v['source_identities']]:exact(item)
 receipts[name]=dict(receipt=pin(path),object=v['object'])
for item in p['retained']:exact(item)
base=read(p['base']['path']);base['base']=p['base'];base['compile']=p['consumers']['cli']['compile']
link=read(W/'link/cli/attempt1/command.json');base['link']=link if isinstance(link,list) else link['command']
for name,value in list(base.get('current_consumers',{}).items()):
 if name in receipts:continue
 prior=read(value['receipt']['path']);current=True
 for item in prior['source_identities']:
  try:exact(item)
  except (AssertionError,FileNotFoundError):current=False;break
 if not current:base.setdefault('historical_consumers',{})[name]=base['current_consumers'].pop(name)
base['current_consumers'].update(receipts);base['current_consumers']['warm-cohort']=receipts['relay']
base['note']='Current publication-boundary consumers with unchanged227 SDK inputs; gate is a separate test shim. Actual request records never live in Step. No independent performance experiment.'
save(W/'model-link-base.json',base)
changed=subprocess.check_output(['git','diff','--name-only','--','engine','tests'],cwd=R,text=True).splitlines()
new=['engine/models/qwen35/state_boundary.h','engine/models/qwen35/publication_facts.h','engine/models/qwen35/generation_publication.h']
sources=sorted(set(changed+new))
(W/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','engine','tests'],cwd=R))
main=(R/'engine/models/qwen35/main.cc').read_text();a=main.index('class Model final {');z=main.index('\n};\n\n} // namespace qwen35',a)
model=main[a:z]
for term in ('GenerationCommitRecord','generation_ledger','expected_episode','commit_record','commit_ledger'):assert not re.search(r'\b'+term+r'\b',model),term
assert len(re.findall(r'\bGenerationLedger\b',model))==2
step=main[main.index('struct StepMember final {'):main.index('struct StepState final {')]
for term in ('commit_record','commit_ledger','commit_publication','PreparedRecordCommit'):assert term not in step
failures=[dict(kind='compile',units=['cli','lifecycle'],attempt='attempt1',reason='First compile found remaining old strict-restore argument wiring; repaired with actual/expected publication, not by removing replay validation.'),
 dict(kind='link',unit='random',attempt='attempt1',reason='The general CLI link recipe omitted the NativeGate test shim; compiled current shim and added its pinned object for this test only.'),
 dict(kind='native',unit='random-cuda',attempt='attempt1',process=read(W/'runs/random-cuda/attempt1/process.json'),reason='Historical fixture used obsolete V1 manifest; rejected before model creation. Retried with the current verified local2B prepared manifest, zero downloads.')]
summary=dict(schema='hyle.inference-publication-boundary.v1',date='2026-10-30',base_commit=p['base_commit'],status='FINITE_CHECKS_PASSED',
 implementation=[
  'Original PreparedRecordCommit is record-type-independent, still borrowing only the original bool witness/count/ordinal. Factory checks original concrete slot identity; no new owner or ledger.',
  'Call-scoped GenerationPublicationBatch owns only scratch borrowing original ledger, exact attempted record and optional original ticket. It projects preflight, actual selected result, post-repair boundary, cohort timing and actual-retirement cleanup.',
  'StepMember no longer contains any request ledger, record or ticket; EvaluationOutput contains only model output/observation metadata. Model finish keeps only call-stack generic ticket pointers alongside existing row scratch.',
  'Complete state and numerical choices remain in Model; Head publish is immediately followed by original witness publication. All surviving peers are stamped before fallible reporting/observation.',
  'Ordinary, recursive, packed, continuous A/B, strict restore and request helper consumers explicitly pass synchronous publication. No new vtable, persistent callback, executor, Completion, progress ledger or resource authority.'
 ],sources=[pin(R/x) for x in sources],checks=checks,
 comparisons=dict(real_K1_all_non_timing_fields_equal=True,real_K1_previous=pin(old_mtp),glm_equal_properties=54,glm_previous=pin(old_glm)),
 source_audit=dict(Step_has_request_record_or_ticket=False,Model_finish_has_ledger_or_replay_oracle=False,remaining_Model_GenerationLedger_bridges=['sampling_index(GenerationLedger)','history_logits_inputs(GenerationLedger,...)']),
 build=dict(consumer_translation_units=9,test_shim_translation_units=1,compiler_processes=12,max_compiler_concurrency=2,retained_sdk_inputs=227,SDK_CXX=0,NVCC=0,downloads=0,missing_cached_dependency_records=len(p['missing_cached_dependency_records']),missing_dependency_scope='Unchanged native-kernel objects/library inputs; changed engine consumer CXX dependencies were checked.'),
 corrected_attempts=failures,cleanup=read(W/'cleanup-report.json'),
 limits=['Independent performance optimization remains paused; no new profiler or full peer speed/memory window.',
  'Qwen Model still has two request sampling/history bridges. GLM K1 request candidate step still needs the common step driver. Full common architecture is not complete.',
  'GLM is the finite target77/NextN78 component, not complete GLM prompt inference or cross-pump GLM.',
  'Raw probes source/relay/session/quota were freshly compiled and linked, not all native scenarios rerun.',
  'Other complete models/artifacts, Apple/Vulkan, full hybrid, multi-GPU and multi-machine were not run. Synthetic tests do not claim model quality.',
  'Quota diagnostic runtime_error message is consolidated; original error class and validation point are preserved. Typed Status/participant/retirement and tested original exceptions remain unchanged.'])
save(W/'summary.json',summary);dest=R/'docs/evidence/correctness';save(dest/'inference-publication-boundary-2026-10-30.json',summary)
archive=dest/'inference-publication-boundary-2026-10-30.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as out:
 for name in ('build.py','finish.py','plan.json','summary.json','original-main.cc','source-change.patch','cleanup.ps1','cleanup-targets.json','cleanup-report.json'):out.write(W/name,name)
 for name in new+['engine/inference/commit_observation.h','tests/tools/inference_commit_observation_case.h']:out.write(R/name,'sources/'+name)
 for path in W.rglob('*'):
  if path.is_file() and (path.name in ('command.json','process.json','receipt.json','report.json','results.xml','image.json') or (path.name in ('stdout.log','stderr.log') and any(x in path.parts for x in ('runs','compile','link')))):out.write(path,str(path.relative_to(W)))
print(json.dumps(dict(status=summary['status'],checks=len(checks),changed_sources=len(sources),archive_bytes=archive.stat().st_size,remaining_architecture=True)))
