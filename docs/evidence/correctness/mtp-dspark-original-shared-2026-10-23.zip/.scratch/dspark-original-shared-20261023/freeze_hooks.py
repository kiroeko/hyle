from pathlib import Path
import difflib,hashlib,json,shutil
stage=Path('.scratch/dspark-original-shared-20261023/hooks-source')
sources=[Path('tests/compute_models/d5_deepseek_official_fragments.h'),Path('tests/compute_models/cpu_c4_model_branches.h')]
def identity(path):
    body=path.read_bytes()
    return {'path':path.as_posix(),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
files=[]
for source in sources:
    before=stage/'before'/source
    frozen=stage/'frozen'/source
    frozen.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,frozen)
    old=before.read_text(encoding='utf-8-sig').splitlines(keepends=True)
    new=source.read_text(encoding='utf-8-sig').splitlines(keepends=True)
    (stage/(source.name+'.diff')).write_text(''.join(difflib.unified_diff(old,new,fromfile=before.as_posix(),tofile=source.as_posix())),encoding='utf-8')
    files.append({**identity(source),'before':identity(before)})
data={
    'source_only':True,'native_build_run_download_ssh':False,'files':files,
    'unchanged_complete_graph_header':identity(Path('tests/compute_models/dspark_complete_graph_fixture.h')),
    'contract':{
        'supplier':'DraftParameters.shared_ffn(parent Fragment&,size_t stage,official::SharedFfnRole)->PackedSharedParameter{ValueId value,span<const byte>codes,rawF32 reference}',
        'roles':['kGate','kUp','kDown'],'stages':[0,1,2],
        'codec':'All nine banks are canonical GGUF Q8_0 MatMul RHS logical[K,N], logicalF32, original row-major physical[N,K]. They are not F32-hook parameters or official E4/A128 carriers.',
        'shape':'Flash gate/up K4096,N2048; down K2048,N4096;8912896 bytes each and80216064 bytes total.',
        'qualification':'Before attachment, require actual same-parent-Fragment immutable constant, exact canonical descriptor, complete encoded source extent and nonempty actual-bank mathematical reference.',
        'child':'MoE x remains child input0; three appended weight inputs1,2,3 map to the exact parent gate/up/down constants. The same actual BF16-rounded x feeds routed and shared math.',
        'composition':'The packed shared branch is used with an explicit parent/reference consumer. No standalone generated Replay is built with missing external weight inputs.'
    },
    'math':[
        'Gate/up/down are ordinary public MatMul operations with F32 input/output and canonical packed Q8 RHS; their provider and activation-quantization choices belong to normal cold planning/native implementation.',
        'Gate/up raw F32 outputs each have explicit BF16 stores; the original moe::gated clip/SiLU/multiply graph is reused. Diagnostics read its actual bounded operands without another activation formula.',
        'The actual gated output is explicitly BF16-stored before down; down raw F32 is BF16-stored before adding actual routed combined values; the full raw sum then has the established BF16 boundary.',
        'Actual-bank reference callbacks return raw F32 mathematical scores and never produce Graph inputs or replace a Graph result. Local native activation-quantization bounds are separately checked by the original shared-reference integration.',
        'Null shared supplier preserves the original FP8 shared nodes, operation order,12 semantic outputs and original reference math. Router/expert behavior and selected IDs are unchanged.'
    ],
    'observations':{
        'old_semantic_outputs':12,'new_mode_total_moe_outputs':20,
        'new_eight_outputs':['actual input','raw gate','raw up','actual clipped gate','actual clipped up','stored activated','raw down','raw full sum'],
        'named_fields':['input','gate_raw','gate_stored','up_raw','up_stored','gate_clipped','up_clipped','activated_raw','activated_stored','down_raw','down_stored','routed','combined','full_raw','full_stored'],
        'optional':'Each DraftStagePorts.shared_ffn is optional; visit_values visits its15 fields only when real packed-shared computation exists. Existing47/default mode receives no fake ValueId0 or added output.'
    },
    'independent_source_review':'Portable inspected child mapping,20-output/15-field mapping,actual common input,clip/BF16 boundaries and unchanged default nodes/math. No confirmed remaining issue.',
    'status':'Frozen for root-owned compile and native state-consumer checks. This file records no native pass.'
}
(stage/'freeze.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identity(stage/'freeze.json')))
