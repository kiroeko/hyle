#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <limits>
#include <memory>
#include <numeric>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

#include "dspark_original_state_consumer.h"
#include "dspark_original_roles.h"
#include "dspark_original_lm_reference.h"
#include "dspark_original_hc_reference.h"
#include "dspark_prepare_constants.h"
#include "cpu_c4_flash_sidecars.h"
#include "row_cache_fixture.h"
#include "../graph_route_cuda/dspark_head_checks.h"
#if defined(HYLE_TEST_DSPARK_STATE_CPU)
#include "hyle/graph/cpu.h"
#endif
#if defined(HYLE_TEST_DSPARK_STATE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#endif

namespace {
namespace x=dspark_original_state_consumer;
namespace h=dspark_main_history;
namespace b=dspark_target_binding;
namespace d=dspark_complete_graph;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace original=dspark_original_roles;
namespace hc=x::parameters;
namespace hc_reference=dspark_original_hc_reference;
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
using Bytes=std::vector<std::byte>;
template<class T> T take(hyle::Result<T> value,const char *where) {
  if(!value) throw std::runtime_error(std::string(where)+": "+std::string(value.error().message()));
  return std::move(*value);
}
void check(hyle::Status status,const char *where) {
  if(!status.ok()) throw std::runtime_error(std::string(where)+": "+std::string(status.message()));
}
template<class T> Bytes bytes(std::span<const T> value) {
  auto raw=std::as_bytes(value);return {raw.begin(),raw.end()};
}
Bytes read(const c::ReadLease &value) {
  Bytes result(value.size());check(take(value.view(),"readonly bytes").read(result),"read result bytes");return result;
}
template<class T> std::vector<T> values(const c::ReadLease &value) {
  const auto raw=read(value);if(raw.size()%sizeof(T)) throw std::runtime_error("typed result byte extent");
  std::vector<T> result(raw.size()/sizeof(T));std::memcpy(result.data(),raw.data(),raw.size());return result;
}
c::ReadLease upload(const c::StorageOwner &owner,std::span<const std::byte> source) {
  auto backing=take(m::Buffer::create(owner.ref(),source.size(),256),"explicit input backing");
  check(backing.view().write(source),"explicit one-time input upload");
  return take(owner.adopt_buffer(std::move(backing)),"ready input permission");
}
c::TensorDesc dense(c::DataType type,std::initializer_list<std::int64_t> dims) {
  return take(c::TensorDesc::dense(type,{dims.begin(),dims.size()}),"dense description");
}
std::string environment(const char *name) {
#if defined(_WIN32)
  char *value=nullptr;std::size_t count=0;
  if(_dupenv_s(&value,&count,name)) throw std::runtime_error("environment lookup");
  const std::unique_ptr<char,decltype(&std::free)> cleanup(value,&std::free);return value?value:"";
#else
  auto value=std::getenv(name);return value?value:"";
#endif
}
b::TargetIdentity target() {
  return {b::kModelRepository,b::kModelRevision,b::kSidecarRepository,b::kSidecarRevision,"UD-Q4_K_XL"};
}
b::SidecarIdentity sidecar() {return {b::kSidecarRepository,b::kSidecarRevision,b::kSidecarFile};}
struct Data final {
  Bytes fc;
  std::vector<float> main_norm;
  std::array<Bytes,3> wkv;
  std::array<std::vector<float>,3> norm;
  original::Roles heads;
  static Data load(const std::filesystem::path &base,const std::filesystem::path &extra,
                   const std::filesystem::path &markov,const std::filesystem::path &confidence) {
    Data result;
    result.fc=original_role_input::read_bytes(base/"fc.weight.q8_0",53477376,
        "4516df35cd05ecd36b93e73ac2ae74c524ec6edda13b634a7895b7eabe0c8c04");
    result.main_norm=original_role_input::read_float(base/"enc.output_norm.weight.f32",b::kHidden,
        "0f99d64b4fa46264c9bd2efdffcb66d3ec0cdd0ca61109f929ed958bcb843f0b");
    constexpr std::array weight_sha{
      "a52e49dc69f4eff1c8287b3887123dd7a583bdaee7d42efe55310f035bafd35f",
      "0a707c0a1eb00673838914bb12b070fe45d70c851efdfe8931e6b914979eb09d",
      "8624943fb84a7d82a235d65d262e79ccf93823b6af67afbcc9e2ff83c1856138"};
    constexpr std::array norm_sha{
      "edbbd17729cfb3c0852c8b6cdb8c1044eb9f501d8864c7ef4444c568e56fc966",
      "733bdaab61d5b429b3a0caa6f74d082d34d7e993f1cb27d508e403eff4baf569",
      "1e49befb7879c1a6fd05311bc7c23f5436b1818238b33bcf272f4f54cc53b556"};
    for(std::size_t stage=0;stage<3;++stage) {
      const auto root=stage?extra:base;const auto prefix="blk."+std::to_string(stage);
      result.wkv[stage]=original_role_input::read_bytes(root/(prefix+".attn_kv.weight.q8_0"),2228224,weight_sha[stage]);
      result.norm[stage]=original_role_input::read_float(root/(prefix+".attn_kv_a_norm.weight.f32"),b::kKv,norm_sha[stage]);
    }
    result.heads=original::load(markov,confidence);return result;
  }
};
struct SharedVocabularyData final {
  std::vector<std::uint16_t> embedding,head;
  static SharedVocabularyData load(const std::filesystem::path &directory) {
    constexpr auto elements=original::vocabulary*original::hidden;
    return {original_role_input::read_bfloat(directory/"embed.weight.bf16",elements,
        "c05019ecf9435fa47cdcbb35df74c8ade6c4ceedd6ebe75db9ea7a607f6ad2ef"),
      original_role_input::read_bfloat(directory/"head.weight.bf16",elements,
        "029e3c5293b29cc426e21d87795e15efa4d363f27b2bc4a9e3aef7d79f047919")};
  }
};
b::ReadonlyRole role(std::string name,const c::TensorDesc &desc,const c::StorageOwner &owner,
                      std::span<const std::byte> source) {return {std::move(name),desc,owner,upload(owner,source)};}

// One ordinary public Graph lifecycle for the complete proposal and all model
// components. No additional executor, host tensor bridge or provider switch.
struct Run final {
  g::Graph graph;
  std::vector<c::TensorDesc> inputs,outputs;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool pool;
};
struct Backend final {
  c::Context &context;
  const c::StorageOwner &owner;
  c::Queue &queue;
  bool cuda;
  int submissions=0;
  hyle::Result<g::CompiledGraph> compile(const g::Graph &graph,g::CompileOptions options) {
#if defined(HYLE_TEST_DSPARK_STATE_CPU)
    if(!cuda) return g::cpu::compile(graph,context,options);
#endif
#if defined(HYLE_TEST_DSPARK_STATE_CUDA)
    if(cuda) return g::cuda::compile(graph,context,owner,options);
#endif
    return std::unexpected(hyle::Status::Unimplemented("DSpark state test backend"));
  }
  c::WorkloadContext workload() {
    return {take(c::ModelArtifactProfile::create(cpu_c4_flash_sidecars::q8_profile),"selected Q8 sidecar profile"),
      c::WorkloadPhase::kDecode,{0x48594c454d4f444cULL,0x4453505354415445ULL,1}};
  }
  Run prepare(g::Graph graph,std::span<const g::ConstantBinding> constants={},std::uint32_t generations=4) {
    Run result{.graph=std::move(graph)};
    for(std::size_t i=0;i<result.graph.input_count();++i)
      result.inputs.push_back(take(result.graph.input_description(i),"input description"));
    std::size_t capacity=0;
    for(std::size_t i=0;i<result.graph.output_count();++i) {
      result.outputs.push_back(take(result.graph.output_description(i),"output description"));
      capacity+=(take(result.outputs.back().required_bytes(),"output bytes")+255u)/256u*256u;
    }
    result.compiled=take(compile(result.graph,{.constants=constants,.workload=workload()}),"ordinary model compile");
    for(std::size_t i=0;i<result.outputs.size();++i)
      if(take(result.compiled.executable.output_ownership(i),"persistent component output ownership")!=g::OutputOwnership::kCaller)
        throw std::runtime_error("component result must explicitly materialize independent caller storage, output "+std::to_string(i));
    result.invocation=take(result.compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"ordinary model Invocation");
    result.pool=take(c::LeasePool::create(owner.ref(),capacity*generations,
        {.max_blocks=std::uint32_t(result.outputs.size())*generations,.backing_alignment=256}),"independent result generations");
    return result;
  }
  std::vector<c::ReadLease> execute(Run &run,std::span<const c::ReadLease> inputs) {
    if(inputs.size()!=run.inputs.size()) throw std::runtime_error("actual model input count");
    for(std::size_t i=0;i<inputs.size();++i)
      check(run.invocation.bind(take(run.graph.input_id(i),"input ID"),run.inputs[i],inputs[i]),"bind direct producer lease");
    for(std::size_t i=0;i<run.outputs.size();++i)
      check(run.invocation.bind(take(run.graph.output_id(i),"output ID"),run.outputs[i],
          take(run.pool.allocate(take(run.outputs[i].required_bytes(),"result bytes")),"caller result writer")),"bind output writer");
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
    check(run.invocation.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}),"prepare one complete DAG");
    {auto done=take(run.invocation.submit(queues),"strict model submit");check(done.wait(),"actual terminal retirement");}
    ++submissions;
    std::vector<c::ReadLease> result;
    for(std::size_t i=0;i<run.outputs.size();++i) {
      auto output=take(run.invocation.result(take(run.graph.output_id(i),"published ID")),"successful model result");
      result.push_back(take(output.storage_lease(),"independent result lease"));
    }
    check(run.invocation.reset(),"withdraw Invocation permissions");EXPECT_FALSE(run.invocation.submit(queues));return result;
  }
};

Run prepare_draft(Backend &backend,x::Draft &logical) {
  auto &program=logical.program;auto &f=program.fragment;
  const auto &cold_program=*f.preparation;
  const c::WorkloadContext cold_workload{
      take(c::ModelArtifactProfile::create(*cold_program.profile),"actual cold artifact profile"),
      cold_program.phase,{0x48594c454d4f444cULL,cold_program.region,1}};
  auto prepared=dspark_prepare_constants::prepare(program,backend.owner,backend.queue,cold_workload,
      [&](const g::Graph &graph,g::CompileOptions options){return backend.compile(graph,options);});
  ++backend.submissions;
  f.preparation.reset();
  const auto graph=sem::make_graph(f);
  std::vector<c::ReadLease> parameters;
  std::vector<g::ConstantBinding> bindings;
  for(std::size_t i=0;i<f.constants.size();++i) {
    const auto external=std::find_if(logical.constants.begin(),logical.constants.end(),
        [&](const auto &item){return item.value.ordinal()==f.constants[i].ordinal();});
    if(external!=logical.constants.end()) {
      bindings.push_back(take(b::constant(graph.constants[i],external->role),"share actual original KV/norm/frequency"));
      continue;
    }
    const auto cold=std::find(f.prepared_constants.begin(),f.prepared_constants.end(),i);
    if(cold!=f.prepared_constants.end()) parameters.push_back(take(backend.owner.adopt_buffer(
        std::move(prepared[std::size_t(cold-f.prepared_constants.begin())])),"retain actual cold output"));
    else parameters.push_back(upload(backend.owner,f.constant_bytes[i]));
    bindings.push_back({.value=graph.constants[i],.tensor=take(parameters.back().tensor(f.description(f.constants[i])),"immutable parameter"),
        .owner=backend.owner,.lease=parameters.back()});
  }
  auto result=backend.prepare(graph.graph,bindings,2);
  f.constant_bytes.clear();f.constant_bytes.shrink_to_fit();return result;
}

g::Graph target_captures(std::int64_t rows) {
  auto builder=take(g::GraphBuilder::create(),"projected target capture fixture");
  std::array<g::ValueId,3> previous;
  for(auto &input:previous) input=take(builder.input(dense(c::DataType::kFloat32,{1,4,b::kHidden})),"prior target capture");
  const auto ids=take(builder.input(dense(c::DataType::kInt32,{rows})),"actual proposal input IDs");
  const auto positions=take(builder.input(dense(c::DataType::kInt32,{rows})),"actual verification positions");
  const auto scaled=[&](g::ValueId value) {
    auto wide=take(builder.add(c::Cast{c::DataType::kFloat32},value),"ID/position conversion");
    auto factor=take(builder.constant(dense(c::DataType::kFloat32,{})),"explicit feature factor");
    return std::pair{wide,factor};
  };
  // Both factors are supplied as immutable constants below by their order.
  auto [token,token_scale]=scaled(ids);
  auto [position,position_scale]=scaled(positions);
  auto tf=take(builder.add(c::Binary{c::BinaryKind::kMultiply},token,token_scale),"token feature");
  auto pf=take(builder.add(c::Binary{c::BinaryKind::kMultiply},position,position_scale),"position feature");
  auto features=take(builder.add(c::Binary{c::BinaryKind::kAdd},tf,pf),"actual-ID target feature");
  auto shape=take(c::View::reshape(take(c::TensorShape::create(std::array<std::int64_t,3>{rows,1,1}),"capture feature shape")),"feature reshape");
  auto expanded=take(builder.add(shape,features),"broadcast target features");
  for(auto input:previous) check(builder.publish(take(builder.add(c::Binary{c::BinaryKind::kAdd},input,expanded),"target capture continuation")),"capture output");
  return take(std::move(builder).finish(),"capture Graph");
}
Run prepare_target(Backend &backend,std::int64_t rows) {
  auto graph=target_captures(rows);
  const std::array<float,2> factors{1.F/131072.F,1.F/512.F};
  std::array<g::ConstantBinding,2> bindings;
  for(std::size_t i=0;i<2;++i) {
    const auto lease=upload(backend.owner,bytes<float>(std::span(&factors[i],1)));
    bindings[i]={.value=take(graph.constant_id(i),"target factor ID"),
      .tensor=take(lease.tensor(dense(c::DataType::kFloat32,{})),"target factor"),.owner=backend.owner,.lease=lease};
  }
  return backend.prepare(std::move(graph),bindings);
}
Run prepare_target_head(Backend &backend,std::int64_t rows) {
  auto builder=take(g::GraphBuilder::create(),"finite target verifier head");
  auto input=take(builder.input(dense(c::DataType::kFloat32,{rows,b::kHidden})),"actual main input");
  auto weight=take(builder.constant(dense(c::DataType::kFloat32,{b::kHidden,17})),"finite target score weights");
  auto scores=take(builder.add(c::MatMul{},input,weight),"finite verifier scores");
  auto node=take(builder.add_node(c::Operation(c::TopK{.count=1,.stable=true}),std::array{scores}),"finite verifier TopK");
  auto selected=take(builder.result(node,1),"actual target ID result");
  auto flat=take(builder.add(take(c::View::reshape(take(c::TensorShape::create(std::array{rows}),"target ID shape")),"target ID view"),selected),"target ID reshape");
  auto materialized=take(builder.add(c::Copy{},flat),"independent target ID generation");
  check(builder.publish(materialized),"target ID output");auto graph=take(std::move(builder).finish(),"finite verifier Graph");
  std::vector<float> weights(std::size_t(b::kHidden*17));
  for(int id=0;id<17;++id) {weights[std::size_t(id)]=float(id-8)/8;weights[std::size_t(17+id)]=float((id*7)%13-6)/8;}
  const auto lease=upload(backend.owner,bytes<float>(weights));
  const std::array bindings{g::ConstantBinding{.value=weight,.tensor=take(lease.tensor(dense(c::DataType::kFloat32,{b::kHidden,17})),"finite verifier weight"),
      .owner=backend.owner,.lease=lease}};
  return backend.prepare(std::move(graph),bindings);
}
Bytes encoded_reference(std::span<const std::uint16_t> input) {
  const auto rows=input.size()/std::size_t(b::kKv);
  const auto width=std::size_t(h::kEncoding.row_bytes());Bytes result(rows*width);
  std::vector<std::uint16_t> chunk(row_cache_test::kRows*std::size_t(b::kKv));
  for(std::size_t first=0;first<rows;first+=row_cache_test::kRows) {
    const auto count=(std::min)(row_cache_test::kRows,rows-first);std::fill(chunk.begin(),chunk.end(),0);
    std::copy_n(input.begin()+std::ptrdiff_t(first*b::kKv),count*std::size_t(b::kKv),chunk.begin());
    const auto expected=row_cache_test::reference(h::kEncoding,chunk);
    std::memcpy(result.data()+first*width,expected.bytes.data(),count*width);
  }return result;
}
// Same bounded original-Q8/F64 compensated-dot oracle as the verified main
// history test, now on all five ACTUAL proposal activations. No provider dot or
// dense decoded weight shadow is used; one decoded 4096-element row suffices.
std::vector<float> proposal_norm_reference(const Data &data,std::size_t stage,
                                           std::span<const float> activation) {
  if(activation.size()!=std::size_t(x::base::block*b::kHidden))
    throw std::runtime_error("proposal reference activation extent");
  const auto stride=std::size_t(ggml_row_size(GGML_TYPE_Q8_0,b::kHidden));
  const auto *codec=ggml_get_type_traits(GGML_TYPE_Q8_0);
  std::vector<float> row(std::size_t(b::kHidden),0.F),projected(std::size_t(x::base::block*b::kKv),0.F);
  for(std::size_t output=0;output<std::size_t(b::kKv);++output) {
    codec->to_float(data.wkv[stage].data()+output*stride,row.data(),b::kHidden);
    for(std::int64_t token=0;token<x::base::block;++token) {
      double sum=0,correction=0;
      for(std::size_t column=0;column<row.size();++column) {
        const double term=double(activation[std::size_t(token*b::kHidden)+column])*row[column];
        const double next=sum+term;
        correction+=std::abs(sum)>=std::abs(term)?(sum-next)+term:(term-next)+sum;sum=next;
      }
      projected[std::size_t(token*b::kKv)+output]=float(sum+correction);
    }
  }
  return cpu_c4_flash_sidecars::norm_ref(projected,data.norm[stage]);
}
// Independent reader used by the existing encoded-history attention check.
// Decode the actual stored code/scale bytes, including BF16 materialization.
std::vector<float> decode_reference(std::span<const std::byte> carrier) {
  if(carrier.size()%h::kEncoding.row_bytes()) throw std::runtime_error("proposal reader reference row extent");
  const auto rows=carrier.size()/h::kEncoding.row_bytes();
  std::vector<float> result(rows*std::size_t(b::kKv),0.F);
  for(std::size_t row=0;row<rows;++row) {
    const auto entry=carrier.subspan(row*h::kEncoding.row_bytes(),h::kEncoding.row_bytes());
    for(std::size_t column=0;column<448;++column) {
      const auto code=std::to_integer<std::uint8_t>(entry[column]);
      EXPECT_NE(code&127,127);
      const int exponent=int(std::to_integer<std::uint8_t>(entry[576+column/64]))-127;
      const double decoded=std::ldexp(row_cache_test::value(code&127,false),exponent)*(code&128?-1:1);
      result[row*std::size_t(b::kKv)+column]=float(row_cache_test::decode(row_cache_test::bfloat(float(decoded))));
    }
    for(std::size_t column=448;column<std::size_t(b::kKv);++column) {
      const auto offset=448+(column-448)*2;
      const auto bits=std::uint16_t(std::uint16_t(std::to_integer<std::uint8_t>(entry[offset]))|
          std::uint16_t(std::to_integer<std::uint8_t>(entry[offset+1]))<<8);
      result[row*std::size_t(b::kKv)+column]=float(row_cache_test::decode(bits));
    }
    EXPECT_EQ(entry[583],std::byte{0});
  }
  return result;
}
using Image=std::array<Bytes,8>;
Image image(const x::State &state,const c::StateVersion &version) {
  Image result;for(std::size_t i=0;i<8;++i) result[i]=read(take(version.member(state.entries[i]),"actual complete state member"));return result;
}

// Check each local arithmetic boundary against its ACTUAL producer. In
// particular, no F64 HC result is fed through a later sigmoid, Sinkhorn or
// BF16 decision, and the old generated-coefficient references stay intact.
template<class Get> void check_original_parameters(const hc::Data &source,
    const x::base::DraftObservations &ports,Get &&get) {
  const auto close=[](std::span<const float> actual,std::span<const float> expected) {
    sem::oracle::expect_close(actual,expected,8.0e-5F,4.0e-5F);
  };
  const auto norm=[&](const x::base::ds::NormPorts &p,std::span<const float> coefficients) {
    const auto input=get(p.input),raw=get(p.raw),stored=get(p.stored);
    close(raw,hc_reference::rms(input,coefficients));
    EXPECT_TRUE(hc_reference::expect_bfloat_store(stored,raw,"original RMS store"));
  };
  const auto normalized_mix=[&](std::span<const float> projected,std::span<const float> inverse,
                                std::span<const float> actual,std::size_t width) {
    if(projected.size()!=inverse.size()*width||actual.size()!=projected.size())
      throw std::runtime_error("original HC normalized mix extent");
    std::vector<float> expected(projected.size());
    for(std::size_t i=0;i<expected.size();++i)expected[i]=projected[i]*inverse[i/width];
    close(actual,expected);
  };
  const auto pre=[&](const x::base::ds::HyperPrePorts &p,std::span<const float> fn,
                     std::span<const float> scale,std::span<const float> base,const std::string &label) {
    SCOPED_TRACE(label);
    const auto state=get(p.state),flat=get(p.flat),projected=get(p.projection),inverse=get(p.inverse),mixes=get(p.mixes);
    EXPECT_EQ(flat,state);
    EXPECT_TRUE(hc_reference::expect_linear(projected,hc_reference::linear(flat,fn,24),label));
    close(inverse,hc_reference::inverse_rms(flat,std::size_t(4*b::kHidden)));
    normalized_mix(projected,inverse,mixes,24);
    const auto split=hc_reference::split(mixes,scale,base);
    const auto actual_pre=get(p.pre),actual_post=get(p.post),actual_combination=get(p.combination);
    close(actual_pre,split.pre);close(actual_post,split.post);close(actual_combination,split.comb);
    const auto collapsed=get(p.collapsed_raw);
    close(collapsed,hc_reference::collapse(state,actual_pre));
    EXPECT_TRUE(hc_reference::expect_bfloat_store(get(p.collapsed),collapsed,label+" collapse"));
  };
  const auto post=[&](const x::base::ds::HyperPostPorts &p,const x::base::ds::HyperPrePorts &before,
                      const std::string &label) {
    SCOPED_TRACE(label);
    const auto branch=get(p.branch),residual=get(p.residual),expanded=get(p.expanded);
    close(expanded,hc_reference::expand(branch,residual,get(before.post),get(before.combination)));
    EXPECT_TRUE(hc_reference::expect_bfloat_store(get(p.stored),expanded,label+" expand"));
  };
  using S=hc::StageRole;
  for(std::size_t stage=0;stage<3;++stage) {
    SCOPED_TRACE(::testing::Message()<<"actual original HC stage="<<stage);
    const auto &p=ports.stages[stage];const auto prefix="blk."+std::to_string(stage);
    pre(p.attention_hc,source.values(stage,S::kAttentionFn),source.values(stage,S::kAttentionScale),
        source.values(stage,S::kAttentionBase),prefix+".hc_attn");
    norm(p.attention_norm,source.values(stage,S::kAttentionNorm));
    norm(p.attention.query_norm,source.values(stage,S::kQueryNorm));
    const auto &sink=p.attention.sink;
    const auto query=get(sink.query),keys=get(sink.keys),mask=get(sink.mask),raw=get(sink.raw);
    // The existing independent full512-depth reference consumes the actual
    // physical-ring/proposal reader and actual visibility mask, including
    // the source's learned extra softmax denominator for every head.
    close(raw,x::base::ds::old::sink_reference(query,keys,keys,mask,source.values(stage,S::kSinks),
        x::base::block,h::kWindow+x::base::block,1.0F/std::sqrt(512.0F)));
    EXPECT_TRUE(hc_reference::expect_bfloat_store(get(sink.stored),raw,prefix+" sink store"));
    post(p.attention_post,p.attention_hc,prefix+" attention post");
    pre(p.ffn_hc,source.values(stage,S::kFfnFn),source.values(stage,S::kFfnScale),
        source.values(stage,S::kFfnBase),prefix+".hc_ffn");
    norm(p.ffn_norm,source.values(stage,S::kFfnNorm));
    post(p.ffn_post,p.ffn_hc,prefix+" FFN post");
  }
  SCOPED_TRACE("actual original output HC");
  const auto &p=ports.head;
  const auto state=get(p.state),flat=get(p.flat),projected=get(p.projection),inverse=get(p.inverse),mixes=get(p.mixes);
  EXPECT_EQ(flat,state);
  EXPECT_TRUE(hc_reference::expect_linear(projected,
      hc_reference::linear(flat,source.values(hc::HeadRole::kFn),4),"output_hc_fn"));
  close(inverse,hc_reference::inverse_rms(flat,std::size_t(4*b::kHidden)));
  normalized_mix(projected,inverse,mixes,4);
  const auto gate=get(p.gate),collapsed=get(p.collapsed_raw);
  close(gate,hc_reference::head_gate(mixes,source.values(hc::HeadRole::kScale),source.values(hc::HeadRole::kBase)));
  close(collapsed,hc_reference::collapse(state,gate));
  EXPECT_TRUE(hc_reference::expect_bfloat_store(get(p.collapsed),collapsed,"original head collapse"));
  norm(p.output_norm,source.values(hc::HeadRole::kOutputNorm));
}

void report_original_projection(const Run &run,std::size_t port,const std::string &label) {
  const auto observed=take(run.graph.output_id(port),"original HC projection observer");
  const auto copied=take(run.graph.producer(observed),"original HC independent observer producer");
  if(take(run.graph.operation_kind(copied),"original HC observer kind")!=c::OperationKind::kCopy)
    throw std::runtime_error("original HC projection must have independent Copy output");
  const auto projected=take(run.graph.node_input(copied,0),"original HC actual projection");
  const auto node=take(run.graph.producer(projected),"original HC actual MatMul");
  const auto operation=take(run.graph.operation(node),"original HC actual operation");
  const auto *matmul=operation.get_if<c::MatMul>();
  if(!matmul||matmul->accumulation_type!=c::DataType::kFloat32)
    throw std::runtime_error("original HC projection must preserve explicit F32 MatMul accumulation");
  for(std::size_t input=0;input<2;++input)
    if(take(run.graph.value_description(take(run.graph.node_input(node,input),"original HC operand")),
        "original HC operand description").data_type()!=c::DataType::kFloat32)
      throw std::runtime_error("original HC projection must preserve original F32 coefficients and widened operands");
  std::size_t steps=0;
  for(std::size_t index=0;index<run.compiled.report.step_count();++index) {
    const auto selected=take(run.compiled.report.step(index),"original HC selected step");
    for(std::size_t logical=0;logical<selected.node_count;++logical)
      if(take(run.compiled.report.step_node(index,logical),"original HC selected logical node")==node) {
        ++steps;::testing::Test::RecordProperty(label+"_provider",std::string(selected.provider.name));
      }
  }
  if(steps!=1)throw std::runtime_error("original HC MatMul must occur in exactly one selected plan step");
}

void exercise(const Data &data,c::Context &context,const c::StorageOwner &owner,bool cuda,
                const SharedVocabularyData *vocabulary=nullptr,
                std::shared_ptr<const hc::Data> parameter_source={}) {
  if(parameter_source&&!vocabulary)throw std::runtime_error("original HC journey requires its actual full shared vocabulary");
  auto queue=take(context.create_queue(),"ordinary shared Queue");Backend backend{context,owner,queue,cuda};
  const auto actual_target=vocabulary?b::TargetIdentity{b::kModelRepository,b::kModelRevision,
      b::kModelRepository,b::kModelRevision,parameter_source?"BF16-vocabulary+Q8_0-originalHC-DSpark":"BF16-shared-vocabulary+Q8_0-DSpark"}:target();
  const auto fc_desc=take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,3*b::kHidden,b::kHidden),"original fc layout");
  const auto kv_desc=take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,b::kHidden,b::kKv),"original wkv layout");
  b::ProjectionRoles projection{actual_target,sidecar(),role("fc.weight",fc_desc,owner,data.fc),
    role("enc.output_norm.weight",dense(c::DataType::kFloat32,{b::kHidden}),owner,bytes<float>(data.main_norm))};
  std::array<b::StageKvRoles,3> roles;
  for(std::size_t stage=0;stage<3;++stage) {
    const auto prefix="blk."+std::to_string(stage);
    roles[stage]={actual_target,sidecar(),std::int32_t(stage),role(prefix+".attn_kv.weight",kv_desc,owner,data.wkv[stage]),
      role(prefix+".attn_kv_a_norm.weight",dense(c::DataType::kFloat32,{b::kKv}),owner,bytes<float>(data.norm[stage]))};
  }
  const auto frequencies=x::base::ds::rope_frequencies(false,false);
  auto frequency=role("dflash.rope.frequencies",dense(c::DataType::kFloat32,{32}),owner,bytes<float>(frequencies));
  x::vocabulary::Roles shared;
  if(vocabulary) {
    const auto desc=dense(c::DataType::kBFloat16,{d::vocabulary,d::hidden});
    shared={role("embed.weight",desc,owner,std::as_bytes(std::span(vocabulary->embedding))),
        role("head.weight",desc,owner,std::as_bytes(std::span(vocabulary->head)))};
  }
  hc::Roles original_parameters;
  if(parameter_source)original_parameters=hc::bind(parameter_source,owner);
  auto logical=take(x::make_draft(roles,frequency,{data.heads.w1,data.heads.w2,data.heads.confidence},
      true,vocabulary?&shared:nullptr,parameter_source?&original_parameters:nullptr),"full encoded draft assembly");
  ASSERT_TRUE(logical.program.encoded);ASSERT_EQ(logical.constants.size(),parameter_source?45u:(vocabulary?11u:9u));
  auto &fragment=logical.program.fragment;const auto named=*logical.program.encoded;
  std::size_t lm_port=std::numeric_limits<std::size_t>::max(),embedding_port=lm_port;
  if(vocabulary) {
    // Observe actual arithmetic results, not a replacement model input.
    // Both outputs have independent caller storage through later episodes.
    const auto table=std::find_if(logical.constants.begin(),logical.constants.end(),
        [](const auto &entry){return entry.role.name=="embed.weight";});
    ASSERT_NE(table,logical.constants.end());
    bool found_embedding=false,found_lm=false;
    const auto count=fragment.nodes.size();
    for(std::size_t i=0;i<count;++i) {
      const auto &node=fragment.nodes[i];
      if(node.operation.get_if<c::Gather>() && node.inputs.size()==2 &&
          node.inputs[0].ordinal()==table->value.ordinal()) {
        const auto value=node.outputs[0];
        embedding_port=fragment.outputs.size();
        fragment.outputs.push_back(fragment.one(c::Operation(c::Copy{}),{value}));
        found_embedding=true;
      } else if(node.operation.custom_as<c::model_ops::BFloatLinearF32>()) {
        const auto value=node.outputs[0];
        lm_port=fragment.outputs.size();
        fragment.outputs.push_back(fragment.one(c::Operation(c::Copy{}),{value}));
        found_lm=true;
      }
    }
    ASSERT_TRUE(found_embedding);ASSERT_TRUE(found_lm);
  }
  const auto output=[&](sem::ValueId id) {const auto found=std::find_if(fragment.outputs.begin(),fragment.outputs.end(),
        [&](auto value){return value.ordinal()==id.ordinal();});
    if(found==fragment.outputs.end()) throw std::runtime_error("named encoded draft output absent");return std::size_t(found-fragment.outputs.begin());};
  const auto hidden_port=output(named.hidden),norm_port=output(named.normalized),ids_port=output(named.ids),
    markov_port=output(named.markov),logits_port=output(named.logits),confidence_port=output(named.confidence);
  auto proposal=prepare_draft(backend,logical);
  if(parameter_source) {
    ASSERT_TRUE(logical.program.observations);
    const auto &p=*logical.program.observations;
    for(std::size_t stage=0;stage<3;++stage) {
      report_original_projection(proposal,output(p.stages[stage].attention_hc.projection),"stage"+std::to_string(stage)+"_attention_fn");
      report_original_projection(proposal,output(p.stages[stage].ffn_hc.projection),"stage"+std::to_string(stage)+"_ffn_fn");
    }
    report_original_projection(proposal,output(p.head.projection),"output_hc_fn");
  }
  auto history1=take(h::make_history(roles,frequency,1),"verified one-row catchup"),history2=take(h::make_history(roles,frequency,2),"verified two-row catchup");
  auto projection1=take(b::make_projection(projection,1),"original single main projection"),projection2=take(b::make_projection(projection,2),"original verify2 main projection");
  auto hc1=take(history1.constants(),"single stage constants"),hc2=take(history2.constants(),"verify stage constants");
  auto pc1=take(projection1.constants(),"single fc constants"),pc2=take(projection2.constants(),"verify fc constants");
  auto history_run1=backend.prepare(history1.graph,hc1,5),history_run2=backend.prepare(history2.graph,hc2);
  auto main_run1=backend.prepare(projection1.graph,pc1,5),main_run2=backend.prepare(projection2.graph,pc2);
  auto captures1=prepare_target(backend,1),captures2=prepare_target(backend,2);
  auto head1=prepare_target_head(backend,1),head2=prepare_target_head(backend,2);
  auto state=take(x::State::create(actual_target),"whole encoded target/draft state schema");
  struct Verified {std::vector<c::ReadLease> captures,history;std::vector<std::int32_t> ids;};
  const auto verify=[&](const c::StateVersion &from,const b::CaptureFrame &frame,const c::ReadLease &actual_ids) {
    const auto placement=take(h::placement(frame),"actual verification positions");
    const auto positions=upload(owner,bytes<std::int32_t>(placement.positions));
    std::vector<c::ReadLease> input;
    for(std::size_t stage=0;stage<3;++stage) input.push_back(take(from.member(state.entries[4+stage]),"prior real capture member"));
    input.push_back(take(actual_ids.subview(0,std::size_t(frame.rows)*sizeof(std::int32_t)),"actual draft ID prefix"));input.push_back(positions);
    auto produced=backend.execute(frame.rows==1?captures1:captures2,input);
    auto &p=frame.rows==1?projection1:projection2;
    const std::array taps{b::TargetTap{frame,b::LayerConvention::kOfficialBlockZeroBased,40,p.capture,produced[0]},
      b::TargetTap{frame,b::LayerConvention::kOfficialBlockZeroBased,41,p.capture,produced[1]},
      b::TargetTap{frame,b::LayerConvention::kOfficialBlockZeroBased,42,p.capture,produced[2]}};
    const auto qualified=take(p.qualify(frame,taps),"qualified actual three-layer capture tuple");
    auto main=backend.execute(frame.rows==1?main_run1:main_run2,qualified);
    auto &hist=frame.rows==1?history1:history2;
    auto lease=take(hist.qualify(frame,frame,main[0]),"actual fc result lease");
    std::vector<c::ReadLease> hi{lease,positions,upload(owner,bytes<std::int32_t>(placement.slots))};
    for(std::size_t stage=0;stage<3;++stage) hi.push_back(take(from.member(state.entries[stage]),"actual encoded history source"));
    auto caught=backend.execute(frame.rows==1?history_run1:history_run2,hi);
    auto target_ids=backend.execute(frame.rows==1?head1:head2,std::array{lease});
    for(std::size_t stage=0;stage<3;++stage) {
      const auto bf16=values<std::uint16_t>(caught[std::size_t(frame.rows*4)+stage*3+2]);
      const auto expected=encoded_reference(bf16);const auto old=read(hi[3+stage]);
      for(std::int64_t prefix=1;prefix<=frame.rows;++prefix) {
        auto all=old;
        for(std::int64_t row=0;row<prefix;++row) std::memcpy(all.data()+std::size_t(placement.slots[std::size_t(row)])*h::kEncoding.row_bytes(),
            expected.data()+std::size_t(row)*h::kEncoding.row_bytes(),h::kEncoding.row_bytes());
        EXPECT_EQ(read(caught[std::size_t((prefix-1)*4)+stage]),all);
      }
    }
    caught.resize(std::size_t(frame.rows*4));return Verified{std::move(produced),std::move(caught),values<std::int32_t>(target_ids[0])};
  };
  bool checked_proposal_boundaries=false,checked_original_lm=false;
  const auto draft=[&](const c::StateVersion &version) {
    const auto facts=take(state.boundary(version),"complete proposal frontier");
    std::vector<std::int32_t> positions(std::size_t(x::base::block),0);std::iota(positions.begin(),positions.end(),std::int32_t(facts.next_position));
    const std::array<std::int32_t,1> pending{facts.pending};
    std::vector<float> mask(std::size_t(x::base::block*(h::kWindow+x::base::block)),0);
    // Main slots are physical ring positions. Before filling the first
    // window, only 0..frontier-1 are visible; all five proposal columns remain
    // visible to every query in the source's parallel draft episode.
    const auto visible=(std::min)(std::int64_t(h::kWindow),facts.next_position);
    for(std::int64_t row=0;row<x::base::block;++row)
      for(std::int64_t column=visible;column<h::kWindow;++column)
        mask[std::size_t(row*(h::kWindow+x::base::block)+column)]=-std::numeric_limits<float>::infinity();
    std::vector<c::ReadLease> input{upload(owner,bytes<std::int32_t>(pending)),upload(owner,bytes<std::int32_t>(positions)),upload(owner,bytes<float>(mask))};
    for(std::size_t stage=0;stage<3;++stage) input.push_back(take(version.member(state.entries[stage]),"actual committed encoded draft input"));
    const auto old=image(state,version);auto result=backend.execute(proposal,input);EXPECT_EQ(image(state,version),old);
    if(parameter_source)check_original_parameters(*parameter_source,*logical.program.observations,
        [&](sem::ValueId value){return values<float>(result[output(value)]);});
    if(!checked_proposal_boundaries) {
      for(std::size_t stage=0;stage<3;++stage) {
        SCOPED_TRACE(::testing::Message()<<"original proposal stage="<<stage);
        const auto &ports=logical.checkpoints[stage];
        const auto activation=values<float>(result[output(ports.activation)]);
        const auto normalized=values<float>(result[output(ports.normalized)]);
        const auto rotated=values<float>(result[output(ports.rotated)]);
        const auto entry=values<std::uint16_t>(result[output(ports.entry)]);
        const auto encoded=read(result[output(ports.encoded)]);
        const auto expected_norm=proposal_norm_reference(data,stage,activation);
        d5_qwen38_24t_moe_profiles::expect_output(&cpu_c4_flash_sidecars::q8_profile,normalized,expected_norm);
        std::vector<float> rounded(normalized.size(),0.F);
        for(std::size_t i=0;i<rounded.size();++i)
          rounded[i]=float(row_cache_test::decode(row_cache_test::bfloat(normalized[i])));
        const auto expected_rotation=cpu_c4_flash_sidecars::rope_ref(rounded,1,positions);
        if(rotated.size()!=rounded.size() || entry.size()!=rotated.size())
          throw std::runtime_error("proposal arithmetic boundary dimensions differ");
        for(std::size_t i=0;i<rotated.size();++i) {
          EXPECT_TRUE(std::isfinite(rotated[i]));
          if(i%std::size_t(b::kKv)<448) EXPECT_EQ(rotated[i],rounded[i])<<i;
          else EXPECT_NEAR(rotated[i],expected_rotation[i],3.e-6+3.e-6*std::abs(expected_rotation[i]))<<i;
          // Test the discontinuous Cast against its ACTUAL F32 predecessor,
          // then the codec against those actual BF16 bits, not a F32 tolerance
          // propagated through several independent rounding decisions.
          EXPECT_EQ(entry[i],row_cache_test::bfloat(rotated[i]))<<i;
        }
        EXPECT_EQ(encoded,encoded_reference(entry));
        auto actual_carriers=old[stage];actual_carriers.insert(actual_carriers.end(),encoded.begin(),encoded.end());
        const auto expected_reader=decode_reference(actual_carriers);
        EXPECT_EQ(read(result[output(ports.decoded)]),bytes<float>(expected_reader));
      }
      checked_proposal_boundaries=true;
    }
    auto ids=values<std::int32_t>(result[ids_port]);EXPECT_EQ(ids.front(),facts.pending);
    const auto hidden=values<float>(result[hidden_port]),normalized=values<float>(result[norm_port]);
    const auto base_logits=vocabulary?values<float>(result[lm_port]):d::lm_reference(normalized);
    const auto expected=original::reference(data.heads,base_logits,hidden,facts.pending);
    EXPECT_EQ(ids,expected.tokens);EXPECT_EQ(values<std::uint16_t>(result[markov_port]),expected.markov);
    EXPECT_TRUE(dspark_head_checks::adjusted_logits_equal(values<float>(result[logits_port]),base_logits,expected));
    if(vocabulary) EXPECT_TRUE(dspark_original_lm_reference::confidence_equal(
        values<float>(result[confidence_port]),hidden,values<std::uint16_t>(result[markov_port]),data.heads.confidence));
    else EXPECT_TRUE(dspark_head_checks::projection_equal(values<float>(result[confidence_port]),expected.confidence,"original encoded-draft confidence"));
    if(vocabulary) {
      const auto embedded=values<std::uint16_t>(result[embedding_port]);
      if(embedded.size()!=std::size_t(d::rows*d::hidden))
        throw std::runtime_error("actual shared embedding observation extent differs");
      for(std::size_t row=0;row<std::size_t(d::rows);++row) {
        const auto token=row?x::base::noise_token:std::int64_t(facts.pending);
        EXPECT_TRUE(std::equal(embedded.begin()+std::ptrdiff_t(row*d::hidden),
            embedded.begin()+std::ptrdiff_t((row+1)*d::hidden),
            vocabulary->embedding.begin()+std::ptrdiff_t(token*d::hidden)));
      }
      if(!checked_original_lm) {
        const auto reference=dspark_original_lm_reference::evaluate(vocabulary->head,normalized);
        EXPECT_TRUE(dspark_original_lm_reference::logits_equal(base_logits,reference));
        EXPECT_TRUE(dspark_original_lm_reference::composed_logits_equal(
            values<float>(result[logits_port]),reference,expected));
        checked_original_lm=true;
      }
    }
    return result;
  };
  {
    std::vector<c::StateMember> members;
    for(std::size_t stage=0;stage<3;++stage) {
      std::vector<std::uint16_t> initial(std::size_t(h::kWindow*b::kKv));
      for(std::size_t i=0;i<initial.size();++i) initial[i]=row_cache_test::bfloat(double(stage+1)+double(i%67)/64);
      members.push_back({state.entries[stage],upload(owner,encoded_reference(initial))});
    }
    std::vector<float> carry(std::size_t(b::kHidden),0);members.push_back({state.entries[3],upload(owner,bytes<float>(carry))});
    for(std::size_t layer=0;layer<3;++layer) {
      std::vector<float> initial(std::size_t(4*b::kHidden));
      for(std::size_t i=0;i<initial.size();++i) initial[i]=float(int((i*17+layer*23)%101)-50)/64;
      members.push_back({state.entries[4+layer],upload(owner,bytes<float>(initial))});
    }
    const x::Boundary initial{5,7,1,126,3,0};members.push_back({state.entries[7],{},std::as_bytes(std::span(&initial,1))});
    auto imported=take(state.store.import(members),"finite imported target boundary");members.clear();
    const std::array<std::int32_t,1> initial_token{3};
    const b::CaptureFrame warm{actual_target,5,7,2,126,1};
    auto bootstrap=verify(imported,warm,upload(owner,bytes<std::int32_t>(initial_token)));
    auto base=take(state.select(imported,bootstrap.history,bootstrap.captures,warm,1,bootstrap.ids[0]),"actual caught-up bootstrap state");
    bootstrap={};const auto old=image(state,base);
    auto proposed=draft(base);const auto proposal_snapshot=read(proposed[ids_port]);
    const b::CaptureFrame frame{actual_target,5,7,3,127,2};auto verified=verify(base,frame,proposed[ids_port]);
    std::array<c::StateHead,3> heads;
    for(std::uint32_t accepted=0;accepted<=2;++accepted) {
      heads[accepted]=take(c::StateHead::create(state.store,base),"accepted/rejected branch head");
      auto candidate=take(state.select(base,verified.history,verified.captures,frame,accepted,verified.ids[accepted?accepted-1:0]),"select one whole accepted prefix");
      if(accepted) check(heads[accepted].publish(base.identity(),candidate),"single captures/history/carry/protocol publication");
      else EXPECT_EQ(candidate.identity(),base.identity());
      auto prior=take(heads[accepted].current(),"nominated branch state");const auto snapshot=image(state,prior);
      if(accepted) {
        for(std::size_t i=0;i<4;++i) EXPECT_EQ(snapshot[i],read(verified.history[std::size_t(accepted-1)*4+i]));
        for(std::size_t i=0;i<3;++i) EXPECT_EQ(snapshot[4+i],read(take(verified.captures[i].subview(std::size_t(accepted-1)*4*b::kHidden*sizeof(float),std::size_t(4*b::kHidden*sizeof(float))),"accepted actual capture slice")));
        EXPECT_TRUE(heads[accepted].publish(base.identity(),base).IsUnavailable());
      } else EXPECT_EQ(snapshot,old);
      auto next=draft(prior);const auto facts=take(state.boundary(prior),"actual resumed frontier");
      const b::CaptureFrame continuation{actual_target,5,7,4+accepted,facts.next_position,1};
      auto continued=verify(prior,continuation,next[ids_port]);
      auto candidate2=take(state.select(prior,continued.history,continued.captures,continuation,1,continued.ids[0]),"continue actual accepted/old branch");
      check(heads[accepted].publish(prior.identity(),candidate2),"atomic continued complete state");
      EXPECT_EQ(take(state.boundary(candidate2),"continued protocol").next_position,facts.next_position+1);
      EXPECT_EQ(take(state.boundary(candidate2),"continued consumed count").consumed,facts.consumed+1);
      EXPECT_EQ(image(state,prior),snapshot);EXPECT_EQ(image(state,base),old);EXPECT_EQ(read(proposed[ids_port]),proposal_snapshot);
    }
    auto cancelled=take(state.store.begin(base),"partial staged failure");
    check(cancelled.replace(state.entries[0],verified.history[0]),"stage one ring without publishing");
    EXPECT_TRUE(cancelled.replace(state.entries[3],verified.history[0]).IsInvalidArgument());
    check(cancelled.cancel(),"cancel whole unpublished draft");EXPECT_FALSE(cancelled.finalize());EXPECT_EQ(image(state,base),old);
  }
  check(state.store.collect(),"collect retired complete state");EXPECT_EQ(state.store.stats().versions,0u);EXPECT_EQ(state.store.stats().drafts,0u);
  EXPECT_EQ(read(projection.projection.lease),data.fc);
  for(std::size_t stage=0;stage<3;++stage) EXPECT_EQ(read(roles[stage].projection.lease),data.wkv[stage]);
  if(parameter_source)for(std::size_t i=0;i<hc::kRoles;++i) {
    auto lease=original_parameters.at(i).lease;EXPECT_FALSE(lease.try_write());
    EXPECT_EQ(read(lease),bytes<float>(parameter_source->values(i)))<<hc::spec(i).name;
  }
  ::testing::Test::RecordProperty("actual_submissions",backend.submissions);
  ::testing::Test::RecordProperty("original_role_count",parameter_source?47:(vocabulary?13:11));
  ::testing::Test::RecordProperty("original_role_bytes",parameter_source?"2320527260":(vocabulary?"2310699520":"192576000"));
  ::testing::Test::RecordProperty("encoded_draft_inputs",6);
  ::testing::Test::RecordProperty("semantic_draft_outputs",7);
  ::testing::Test::RecordProperty("test_boundary_outputs",int(proposal.graph.output_count()-7));
  ::testing::Test::RecordProperty("proposal_numerics","all3 original M5 wkv/norm independent Q8 decode + compensated F64 dot/norm gate on actual activation; actual postnorm BF16 then independent RoPE gate; exact actual-F32->BF16 bits; exact actual-BF16->584B codes/scales; independent actual committed/proposal carrier reader equals prepared attention F32 keys byte-for-byte");
  if(vocabulary) {
    EXPECT_TRUE(checked_original_lm);
    ::testing::Test::RecordProperty("full_vocabulary_lm_values_checked",int(d::rows*d::vocabulary));
    ::testing::Test::RecordProperty("lm_reference_episodes",1);
    ::testing::Test::RecordProperty("confidence_numerics","every-episode independent original BF16 coefficients and actual widened-BF16 rawhidden/actualBF16 Markov dot; exact-F32-product/nonFTZ/overflow preconditions; analytic gamma4352(F32)+F64 absolute-product bound; old relative-gate exceedances/error/sumabs/maxratio in stdout, generated gate unchanged");
    ::testing::Test::RecordProperty("shared_vocabulary","formal Flash0731 BF16 full embedding/head, target-owned immutable banks; no dense F32 LM weight shadow");
    if(parameter_source) {
      ::testing::Test::RecordProperty("original_hc_numerics","every-episode seven actual widened-BF16 x original-F32 dense HC projections with independent F64/product+accum bound; actual inverse RMS, original scale/base Sinkhorn20 and head gates, actual 4-stream collapse/expansion; actual learned RMS/sink inputs and exact local BF16 stores. Seven fn providers recorded from actual CompileReport.");
      ::testing::Test::RecordProperty("scope","47 original roles: formal Flash0731 BF16 full-V shared embedding/head plus Q8 DSpark original fc/mainnorm, 3 wkv/kvnorm, Markov/confidence, 13 norm/sink and21 HC parameters. Same complete three-stage encoded state and all-V head journey; remaining attention/MoE coefficients and target-capture/verifier boundary generated. All-V greedy, exact embedding, independent full-V LM and actual4352-term confidence bounds, old Markov cancellation/IDs gates; prefix0/1/2, wrap, continuation, retained results and collection. Not main UD-Q4 vocabulary, full original target/stages, natural acceptance or throughput.");
    } else ::testing::Test::RecordProperty("scope","original shared BF16 full-V embedding/head plus original Q8 DSpark eleven roles, complete three-stage generated remainder and generated target-capture/verifier boundary; all-V greedy and exact actual embedding rows, first-episode independent full-V F64 LM/error propagation, unchanged Markov cancellation/IDs gates, independent actual-input4352-term confidence error bound; prefix0/1/2, wrap, own-head continuation, old results and collection. Not main UD-Q4 vocabulary, full official BF16 target/stages, natural acceptance or throughput.");
  } else ::testing::Test::RecordProperty("scope","full three-stage draft HC/attention/MoE plus natural original Markov/confidence; original fc/norm and three original wkv/norm share readonly roles with accepted encoded history; prefix0/1/2, wrap, rejection, own-head continuation and retained results. Generated shared LM/embedding/other stage parameters and generated target-capture/verifier boundary, not trained target/full model or measured natural acceptance.");
}
class DSparkOriginalState : public ::testing::Test {
protected:
  static inline std::unique_ptr<const Data> data;
  static inline std::unique_ptr<const SharedVocabularyData> vocabulary;
  static inline std::shared_ptr<const hc::Data> parameter_data;
  static bool require_parameters() {
    if(parameter_data)return true;
    const auto directory=environment("HYLE_DSPARK_PARAMETER_ROLES_DIR");
    if(directory.empty())return false;
    parameter_data=std::make_shared<const hc::Data>(hc::Data::load(directory));return true;
  }
  static bool require_vocabulary() {
    if(vocabulary) return true;
    const auto directory=environment("HYLE_DSPARK_SHARED_VOCAB_DIR");
    if(directory.empty()) return false;
    vocabulary=std::make_unique<const SharedVocabularyData>(SharedVocabularyData::load(directory));
    return true;
  }
  static void SetUpTestSuite() {
    const auto base=environment("HYLE_DSPARK_TARGET_ROLES_DIR"),extra=environment("HYLE_DSPARK_HISTORY_ROLES_DIR"),
      markov=environment("HYLE_DSPARK_MARKOV_DIR"),confidence=environment("HYLE_DSPARK_CONFIDENCE_BF16");
    if(!base.empty()&&!extra.empty()&&!markov.empty()&&!confidence.empty())
      data=std::make_unique<const Data>(Data::load(base,extra,markov,confidence));
  }
  static void TearDownTestSuite(){parameter_data.reset();vocabulary.reset();data.reset();}
  void SetUp() override {if(!data) GTEST_SKIP()<<"Set authenticated DSpark target/history/Markov/confidence role paths";}
};
#if defined(HYLE_TEST_DSPARK_STATE_CPU)
struct System final {m::MemoryResourceRef ref() noexcept{return m::system_resource();}};
TEST_F(DSparkOriginalState,CpuEncodedMainHistoryFeedsFullDraftAndAtomicAcceptedState) {
  auto context=take(g::cpu::create_context(),"ordinary CPU Context");
  auto owner=take(c::StorageOwner::adopt(context,System{}),"CPU allocation owner");exercise(*data,context,owner,false);
}
TEST_F(DSparkOriginalState,CpuOriginalSharedVocabularyFeedsFullDraftAndAtomicAcceptedState) {
  if(!require_vocabulary()) GTEST_SKIP()<<"Set authenticated HYLE_DSPARK_SHARED_VOCAB_DIR";
  auto context=take(g::cpu::create_context(),"ordinary CPU Context");
  auto owner=take(c::StorageOwner::adopt(context,System{}),"CPU allocation owner");
  exercise(*data,context,owner,false,vocabulary.get());
}
TEST_F(DSparkOriginalState,CpuOriginalHyperConnectionsFeedFullDraftAndAtomicAcceptedState) {
  if(!require_vocabulary()||!require_parameters())GTEST_SKIP()<<"Set authenticated shared-vocabulary and HYLE_DSPARK_PARAMETER_ROLES_DIR inputs";
  auto context=take(g::cpu::create_context(),"ordinary CPU Context");
  auto owner=take(c::StorageOwner::adopt(context,System{}),"CPU allocation owner");
  exercise(*data,context,owner,false,vocabulary.get(),parameter_data);
}
#endif
#if defined(HYLE_TEST_DSPARK_STATE_CUDA)
TEST_F(DSparkOriginalState,CudaEncodedMainHistoryFeedsFullDraftAndAtomicAcceptedState) {
  auto context=take(g::cuda::create_context(),"ordinary CUDA Context");
  auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"CUDA memory")),"CUDA allocation owner");exercise(*data,context,owner,true);
}
TEST_F(DSparkOriginalState,CudaOriginalSharedVocabularyFeedsFullDraftAndAtomicAcceptedState) {
  if(!require_vocabulary()) GTEST_SKIP()<<"Set authenticated HYLE_DSPARK_SHARED_VOCAB_DIR";
  auto context=take(g::cuda::create_context(),"ordinary CUDA Context");
  auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"CUDA memory")),"CUDA allocation owner");
  exercise(*data,context,owner,true,vocabulary.get());
}
TEST_F(DSparkOriginalState,CudaOriginalHyperConnectionsFeedFullDraftAndAtomicAcceptedState) {
  if(!require_vocabulary()||!require_parameters())GTEST_SKIP()<<"Set authenticated shared-vocabulary and HYLE_DSPARK_PARAMETER_ROLES_DIR inputs";
  auto context=take(g::cuda::create_context(),"ordinary CUDA Context");
  auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"CUDA memory")),"CUDA allocation owner");
  exercise(*data,context,owner,true,vocabulary.get(),parameter_data);
}
#endif
} // namespace
