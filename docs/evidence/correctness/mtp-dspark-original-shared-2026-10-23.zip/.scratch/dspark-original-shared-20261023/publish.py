"""Publish actual original shared-FFN Graph/state results; omit weight bodies."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def identity(p):
    p = Path(p)
    return dict(path=str(p.relative_to(R)), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


runs = [read(S / f'checks{i}/summary.json') for i in (1, 2)]
cases = []
for i, run in enumerate(runs, 1):
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert run['tests'] == 2
    assert not any(run[k] for k in ('failures', 'errors', 'disabled', 'skips'))
    tree = ET.parse(S / f'checks{i}/results.xml').getroot()
    assert int(tree.attrib['tests']) == 2
    for case in tree.iter('testcase'):
        assert case.attrib['result'] == 'completed'
        assert case.find('failure') is None and case.find('skipped') is None
    cases.extend(run['cases'])
assert len(cases) == len({(c['attributes']['classname'], c['attributes']['name']) for c in cases}) == 4
assert all(c['properties']['actual_submissions'] == '25' for c in cases)
for case in runs[0]['cases']:
    p = case['properties']
    assert p['original_role_count'] == '56' and p['original_role_bytes'] == '2400743324'
    providers = {k: v for k, v in p.items() if k.endswith('_provider')}
    assert len(providers) == 16
    if case['attributes']['name'].startswith('Cpu'):
        assert set(providers.values()) == {'ggml-cpu'}
    else:
        assert sum(v == 'cublasLt' for v in providers.values()) == 7
        assert sum(v == 'ggml-cuda' for v in providers.values()) == 9
for case in runs[1]['cases']:
    assert case['properties']['original_role_count'] == '47'

freezes = [S / p / 'freeze.json' for p in ('source', 'hooks-source', 'reference-source')]
for p in freezes:
    freeze = read(p)
    for row in freeze['files'] if 'files' in freeze else [freeze['file']]:
        actual = identity(R / row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
compiled = read(S / 'compile1/dspark-state/identity.json')
for row in (compiled['source'], compiled['object'], *compiled['dependencies']):
    p = Path(row['path'])
    assert p.stat().st_size == row['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
image = read(S / 'tests-link1/ready.json')['image']
assert identity(Path(image['path']))['sha256'] == image['sha256']
payloads = read(S / 'original-shared/acquisition.json')
assert payloads['complete'] and len(payloads['roles']) == 9
assert payloads['role_payload_bytes'] == payloads['successful_request_body_bytes'] == 80216064
assert len(payloads['requests']) == 3
for row in payloads['roles']:
    assert identity(R / row['payload']['path']) == row['payload']
tail = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
tail = tail[tail.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == read(S / 'start.json')['performance_tail_utf8_sha256']

numeric_pattern = re.compile(r'^shared-Q8-local role=(\S+) codec=(\d+) outputs=(\d+) '
    r'max_error=(\S+) max_ratio=(\S+) max_quantization_ambiguity=(\S+) '
    r'ambiguous_codes=(\d+) ambiguous_scales=(\d+)$')
numerics = []
for line in (S / 'checks1/stderr.log').read_text(encoding='utf-8').splitlines():
    match = numeric_pattern.match(line)
    if match:
        role, codec, count, error, ratio, ambiguity, codes, scales = match.groups()
        numerics.append(dict(role=role, codec=int(codec), values=int(count),
            maximum_absolute_error=float(error), maximum_bound_ratio=float(ratio),
            maximum_quantization_ambiguity=float(ambiguity),
            ambiguous_activation_codes=int(codes), ambiguous_activation_scales=int(scales)))
assert len(numerics) == 18
assert {row['codec'] for row in numerics} == {0, 2}
assert all(sum(row['values'] for row in numerics if row['codec'] == codec) == 122880 for codec in (0, 2))
assert all(row['maximum_bound_ratio'] <= 1 for row in numerics)
(S / 'numerical-observations.json').write_text(json.dumps(numerics, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

sources = [R / p for p in (
    'tests/compute_models/d5_deepseek_official_fragments.h',
    'tests/compute_models/cpu_c4_model_branches.h',
    'tests/compute_models/dspark_complete_graph_fixture.h',
    'tests/compute_models/dspark_original_shared_roles.h',
    'tests/compute_models/dspark_original_shared_reference.h',
    'tests/compute_models/dspark_original_state_consumer.h',
    'tests/compute_models/dspark_original_state_consumer_test.cc',
    'docs/developer/current-work.md', 'docs/implementation/model-operators.md')]
metadata = [R / p for p in (
    '.scratch/dspark-original-hc-20261023/review/remaining-original-roles.json',
    '.scratch/dspark-original-hc-20261023/original-parameters/acquisition.json',
    '.scratch/glm-mtp-catchup-20261022/native-cpu-hc/link-plan.json',
    '.scratch/glm-mtp-catchup-20261022/native-cpu-hc/ready.json',
    '.scratch/model-scope-2026-10-19/flash-0731/inference-model.py')]
assert all(p.is_file() for p in sources + metadata)
paths = set(sources + metadata)
paths.update(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in (
    '.h', '.cc', '.py', '.json', '.txt', '.diff', '.log', '.xml', '.ps1'))
paths.discard(S / 'publication.json')
archive = D / 'mtp-dspark-original-shared-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for p in sorted(paths):
        z.write(p, p.relative_to(R).as_posix())

record = dict(date='2026-10-23', stage='BK', goal_complete=False,
    conclusion='All nine original shared FFN Q8_0 gate/up/down banks now run in the existing complete three-stage DSpark accepted-state journey on CPU and CUDA, together with the previous47 original roles.',
    artifact=dict(original_roles=56, original_payload_bytes=2400743324,
        sidecar_original_roles=54, sidecar_total_roles=81, additional_formal_BF16_vocabulary_roles=2,
        acquisition=payloads, original_payloads_archived=False,
        byte_scope='Original checkpoint payload extents only, not physical memory or VRAM peaks.'),
    implementation=dict(
        assembly='Typed optional cold shared-FFN supplier binds three parent-owned canonical Q8_0 operands to each child through ordinary inputs. Same-Fragment descriptors are checked. Existing generated/default path and its12 semantic MoE outputs retained.',
        lifetime='Nine encoded banks uploaded once per backend under readonly owner/lease. Every episode reuses them; host immutable source is retained. No full F32 decoded weight shadow and no additional executor/provider/dispatcher.',
        mathematics='Original gate/up projections, existing clipping and gated activation, BF16 stores, down projection and routed-plus-shared accumulation feed the existing HC residual path. Q8_0 storage and its native activation quantizer remain distinct from official FP8/E4-A128 math.',
        state='Same25-Graph journey per case: encoded main-ring bootstrap, complete three-stage draft, accepted prefixes0/1/2, wrap, independent nominated-Head continuation, rejection/cancellation/stale publication, retained results and collection. Proposal KV remains temporary.'),
    validation=dict(unique_tests=4, failures=0, errors=0, skips=0,
        model_graph_submissions=100, new_original_model_graph_submissions=50,
        related_regression_graph_submissions=50, cases=cases,
        numerical='First episode checks all nine dense projections from actual predecessors and original Q8_0 bytes against independent integer-block/F64 arithmetic with the actual activation-quantizer rules and explicit quantization/accumulation bounds. Every episode retains local BF16 stores, clipping/gating, residual merge, originalHC/sink/norm, embedding/greedy/Markov/confidence and complete-state checks. The earlier full-V LM oracle remains first-episode only.',
        precision_scope='CPU actual archived AVX quantizer object inspected directly; VROUNDPS immediate0 confirms nearest-even. CUDA MMVQ Q8_1 activation interval uses NVIDIA published2-ULP division envelope with explicit finite/normal-domain checks. NVIDIA describes these intrinsic errors as non-exhaustive observations; this conditional scope is not a formal all-input proof. Actual MatMul providers and canonical encoded operands are checked through the public graph/report.',
        original_Q8_projection_values_checked=245760,
        numerical_observations=numerics,
        commands_and_results=[identity(S / f'checks{i}/summary.json') for i in (1, 2)],
        compiled_host_translation_units=1, SDK_builds=0, native_CPU_builds=0,
        NVCC_builds=0, shaders=0, first_native_run_failures=0),
    source_reviews=[identity(p) for p in freezes],
    source_metadata=[identity(p) for p in metadata],
    remaining=dict(sidecar_roles=27,
        groups={'attention_projection':12, 'router':3, 'router_bias':3, 'expert_MXFP4':9},
        sidecar_payload_bytes=10608184320,
        constraints='Original router/bias requires actual selected experts resident with explicit original-ID mapping; never filter IDs to fit generated smallbanks. Whole original expert banks are not required to reside on a12GB GPU. WeightSlots carries selected immutable banks and retirement; it does not silently map global expert IDs.'),
    limitations=['WindowsCPU/CUDA only; no new Linux/Apple/Vulkan model run.',
        'Other attention/router/expert coefficients and target-capture/verifier boundary remain generated. No full original trained target/stages, Pro geometry, primaryUD-Q4 vocabulary, natural acceptance or generation-quality claim.',
        'GGUF Q8_0 shared weights with native activation quantization do not establish equality to officialFP8/E4-A128 or other codecs.',
        'No new TPS, loading or physical memory/VRAM peak measurement; latestAV performance table retained.',
        'Full MTP and broader architecture/performance/image goal remain incomplete.'],
    next='Remaining attention projections, actual expert residency and router coupling, other actual-role/sharedLM/targettap/Pro/confirmedquant work, then necessary final ordinary/MTP performance comparison before images.',
    final_image=image, sources=[identity(p) for p in sources], performance_tail_sha256=tail_hash,
    cleanup='One executable/map and one host object retained for replay and subsequent incremental linking; no superseded BK image, whole shard or SDK copy was produced. No deletion required.',
    archive=identity(archive), archive_items=len(paths))
out = D / 'mtp-dspark-original-shared-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(out), archive=identity(archive)),
    ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(out), archive=identity(archive), tests=4, graphs=100), ensure_ascii=False))
