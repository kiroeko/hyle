from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
base=R/'.scratch/engine-product-20261024/cpu-budget-fix1/budget'
old_link=R/'.scratch/inference-request-sampling-20261025/host3/link/command.json'
files=[R/x for x in ['include/hyle/compute/resource_budget.h','include/hyle/mem/quota_allocator.h','src/compute/resource_budget.cc','tests/compute/shared_backing_budget_test.cc','tests/compute/retained_lease_budget_test.cc']]
def build(attempt):
 out=D/attempt;out.mkdir(exist_ok=False)
 a=b.args(base/'command.json');env=b.environment(a[0]);flags=[];skip=False
 for f in a[1:]:
  if skip:skip=False;continue
  if f=='/sourceDependencies':skip=True;continue
  if f.lower().startswith(('/fo','/fd'))or f.lower().endswith(('.cc','.cpp')):continue
  flags.append(f)
 flags+=['/I'+str(R/'src/compute')]
 before=[b.pin(p)for p in files];b.save(out/'before-source-pins.json',before)
 objs=[]
 for label,source in [('core',R/'src/compute/resource_budget.cc'),('backing',R/'tests/compute/shared_backing_budget_test.cc'),('retained',R/'tests/compute/retained_lease_budget_test.cc')]:
  folder=out/label
  b.execute([a[0],*flags,str(source),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(folder/'unit.obj')],folder,env,90)
  objs.append(str(folder/'unit.obj'))
 assert before==[b.pin(p)for p in files]
 b.save(out/'source-pins.json',before)
 link=b.args(old_link);args=[];removed=[]
 for f in link[1:]:
  n=f.lower().replace('\\','/')
  if n.endswith(('/cpu-budget-fix1/budget/budget.obj','/host3/host.obj','/current-cuda/report/unit.obj')):removed.append(f);continue
  if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
  args.append(f)
 assert len(removed)==3,removed
 args+=[*objs,str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib')]
 b.execute([link[0],*args,'/OUT:'+str(out/'link/checks.exe'),'/IMPLIB:'+str(out/'link/checks.lib')],out/'link',env,120)
 b.save(out/'ready.json',dict(image=b.pin(out/'link/checks.exe'),refreshed_core_TUs=1,test_TUs=2,source=before,removed_old_objects=removed,scope='One refreshed compute core TU and related host tests, all remaining SDK objects retained. No GPU/Model/SDK rebuild.'))
def run(attempt):
 out=D/attempt;env=os.environ.copy();env['PATH']=b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
 b.execute([str(out/'link/checks.exe'),'--gtest_filter=SharedBackingBudget.*:SharedRequestedBudget.*:RetainedLeaseBudget.*','--gtest_output=xml:'+str(out/'results.xml')],out/'run',env,60)
if __name__=='__main__':globals()[sys.argv[1]](sys.argv[2])
