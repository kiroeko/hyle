from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
a=b.args(R/'.scratch/engine-product-20261024/cpu-budget-fix1/budget/command.json');env=b.environment(a[0]);flags=[];skip=False
for f in a[1:]:
 if skip:skip=False;continue
 if f=='/sourceDependencies':skip=True;continue
 if f.lower().startswith(('/fo','/fd'))or f.lower().endswith(('.cc','.cpp')):continue
 flags.append(f)
link=str(Path(a[0]).with_name('link.exe'));results={}
for label in ['before','after']:
 out=D/('abi-'+label)
 extra=['/I'+str(D/'before/include')]if label=='before'else[]
 b.execute([a[0],*extra,*flags,str(D/'abi.cc'),'/sourceDependencies',str(out/'compile/dependencies.json'),'/Fo'+str(out/'compile/abi.obj')],out/'compile',env,60)
 b.execute([link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE',str(out/'compile/abi.obj'),'/OUT:'+str(out/'link/abi.exe')],out/'link',env,60)
 b.execute([str(out/'link/abi.exe')],out/'run',env,30)
 results[label]=b.read(out/'run/stdout.log')
assert results['before']==results['after'],results
b.save(D/'abi-summary.json',dict(status='PASS',layouts=results,scope='Actual Windows MSVC x64 before pinned public headers vs current headers; size/alignment only, not a universal ABI guarantee. Old cached lease/SDK objects also linked and executed against refreshed core.'))
print(json.dumps(results,indent=2))
