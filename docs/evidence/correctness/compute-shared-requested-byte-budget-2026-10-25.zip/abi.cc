#include "hyle/compute/resource_budget.h"
#include <cstdio>
int main() {
  using namespace hyle;
  std::printf("{\"ResourceBudget\":[%zu,%zu],\"Reservation\":[%zu,%zu],\"Options\":[%zu,%zu],\"QuotaAllocator\":[%zu,%zu],\"QuotaReservation\":[%zu,%zu]}\n",
      sizeof(compute::ResourceBudget), alignof(compute::ResourceBudget),
      sizeof(compute::ResourceBudget::Reservation), alignof(compute::ResourceBudget::Reservation),
      sizeof(compute::ResourceBudgetOptions), alignof(compute::ResourceBudgetOptions),
      sizeof(mem::QuotaAllocator), alignof(mem::QuotaAllocator),
      sizeof(mem::QuotaAllocator::Reservation), alignof(mem::QuotaAllocator::Reservation));
}
