from pathlib import Path
import json,hashlib,zipfile
R=Path.cwd();D=Path(__file__).resolve().parent
PUBLIC=R/'docs/evidence/correctness/compute-shared-requested-byte-budget-2026-10-25'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files={}
for base in [D/'before',D/'after']:
 for p in base.rglob('*'):
  if p.is_file():files[p.relative_to(D).as_posix()]=p
for base in [D/'attempt1',D/'abi-before',D/'abi-after']:
 for p in base.rglob('*'):
  if p.is_file()and p.suffix in{'.json','.log','.xml'}and p.name!='live.json':files[p.relative_to(D).as_posix()]=p
for name in ['before-pins.json','after-pins.json','source.patch','summary.json','abi-summary.json','abi.cc','check.py','check-abi.py','publish.py']:
 files[name]=D/name
note=R/'.scratch/inference-system-review-20261025/shared-known-byte-admission-design.md'
files['engine-followup-design.md']=note
manifest=[dict(name=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for name,p in sorted(files.items())]
(D/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files['archive-manifest.json']=D/'archive-manifest.json'
archive=PUBLIC.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for v in manifest:
  raw=z.read(v['name']);assert len(raw)==v['bytes']and hashlib.sha256(raw).hexdigest()==v['sha256']
summary=read(D/'summary.json')
proof={
 'title':'One ResourceBudget scope aggregates explicitly nominated resource rows',
 'date':'2026-10-25','status':'PASS','stage':'foundation complete; engine integration not implemented',
 'API':[
  'ResourceBudget::create(ResourceBudgetOptions, span<const mem::MemoryResourceRef> nominated_resources, size_t max_shared_bytes)',
  'ResourceBudget::shared_usage() const noexcept -> optional<SharedRequestedBytesUsage>',
  'QuotaAllocator::try_acquire_bytes(size_t) / release_bytes(size_t): paired no-allocation accounting for existing RAII owners'
 ],
 'contract':[
  'Copies of ONE budget handle share its State, nominated-row total, and original backing identity table. Independent scopes remain independent.',
  'Each local row limit and the nominated shared limit must both admit known requested bytes; rejection rolls back live charges.',
  'Nominated CPU metadata includes scope control storage before State backing allocation and metadata allocator allocate/reallocate/free.',
  'Original aliases/adoption share one same-scope payload charge; no relaxed same_scope or inferred resource/device mapping.',
  'Unattributed private upper bounds and unknown provider memory remain separately reported, outside the explicit nominated total.'
 ],
 'actual':summary,
 'ABI_scope':'Windows MSVC x64 before/current size+alignment equal; old cached lease/Completion/SDK objects actually linked and executed with one refreshed resource_budget core TU.',
 'proof_limits':[
  '16 host tests, including 8 new cases; no engine, Model, GPU, native GPU error injection or platform matrix.',
  'The controlled Completion test exercises original accepted-use retention after public Completion/drop; the host-controlled terminal releases the original backing charge.',
  'No per-Model shared physical-device cap is claimed. Engine source allocations and meaningful local cache subset policy still need consistent same-scope wiring.',
  'Tensor move replacement and source-aware charge transfer/adoption must preserve backing-before-charge release and prevent reset gaps or duplicate charging.',
  'The nomination is explicit accounting scope, not authority over driver allocation, other processes, or opaque provider private memory.'
 ],
 'source_patch':pin(D/'source.patch'),
 'archive':dict(pin(archive),members=len(files),CRC='PASS',member_SHA='PASS',binaries_or_weights=False),
 'raw':D.relative_to(R).as_posix(),'new_core_TUs':1,'full_SDK_rebuild':False,'vendor_builds':0,'GPU_runs':0,'HTTP':0,
}
PUBLIC.with_suffix('.json').write_text(json.dumps(proof,indent=2)+'\n')
(D/'publication.json').write_text(json.dumps(dict(json=pin(PUBLIC.with_suffix('.json')),archive=pin(archive),members=len(files),CRC='PASS',SHA='PASS'),indent=2)+'\n')
print((D/'publication.json').read_text())
