from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-paged-submission-source-2026-10-27'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
pin = lambda p: dict(path=str(p.relative_to(R)), bytes=p.stat().st_size,
                    sha256=hashlib.sha256(p.read_bytes()).hexdigest())
plan, ready, result = (read(W / p) for p in ('plan.json', 'ready.json', 'summary.json'))
assert result['status'] == 'PASS' and len(result['tests']) == 26
for row in plan['sources']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
metadata = ['cmake/HyleComponents.cmake', 'tests/graph_batch/CMakeLists.txt']
for name in metadata:
    dest = W / 'source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((R / name).read_bytes())
receipt = {
    'date': '2026-10-27', 'status': 'PASS',
    'scope': 'Original PagedAppend transactions to a real shared-Queue CUDA attention consumer using explicit metadata; finite resource/publication checks.',
    'hardware': {'gpu': 'NVIDIA GeForce RTX 4070', 'compute_capability': '8.9', 'driver': '617.14'},
    'build': {'CXX_TUs': 9, 'links': 1, 'images': 1, 'test_processes': 1,
              'NVCC_TUs': 0, 'SDK_rebuilds': 0, 'downloads': 0,
              'baseline_inputs': plan['input_count'], 'replaced_inputs': 7, 'added_test_objects': 2,
              'final_inputs': 233, 'retained_inputs': 224,
              'compile_and_link_first_attempt_exit_zero': True,
              'processes': ready['compiled'], 'link': ready['link']},
    'tests': {'passed': 26, 'skipped': 0, 'failed': 0, 'process': result['process'],
              'groups': {'GraphOutputSourceCuda': 10, 'AppendLeases': 4,
                         'PendingReadTickets': 3, 'PendingAppendReadTickets': 3, 'CopyLeaseHandoff': 2,
                         'PagedArena': 3, 'GraphPagedAppendSourceCuda': 1}, 'cases': result['tests']},
    'actual_cuda_observations': [
        'One original A submission owns key and value PagedAppend transactions. Each source contributes two untouched ready pages, three full writers, and one existing append epoch. The second request has a real COW page.',
        'B has a different query_indptr but the same required KV prefix footprint. Its explicit metadata retains the original real ready mirror lease; no fake ready frame is constructed.',
        'B is recorded before A using only the original physical capacities for metadata/capture preparation, without submitting a reader. Its two typed reader descriptors are also prepared before A.',
        'A is genuinely pending behind an original CUDA Queue host gate while B binds both KV resources through the same concrete output bundle and original SubmissionSource.',
        'B reuses the existing capture with recorded=0/reused=1; dependency reports one source, one device wait, zero host waits. Ordinary submit cannot bypass the ordered permission map.',
        'After A actually retires and detaches, B remains gated while the original bulk take returns both transactions. Key publication makes an original ready_delta and commits a WorkingFrame; value publication and its retry make the original ready frame.',
        'Old key/value layouts and prefixes remain bounded. Fresh/COW partial pages acquire real appenders; reserve on an admitted reader remains unavailable. Final BF16 attention results are exactly 0.5 and 1.0 per request; all selected value rows and old snapshot bytes match.'
    ],
    'resource_and_architecture_observations': [
        'ResourceSource cold-reserves fixed ready/full/append metadata and charges the original budget. Capture authenticates the exact submitted parent, selected/nominated writer, registered page set, and real resource/allocator lifetimes.',
        'Source metadata visits temporarily pin original results and release the observation mutex before invoking the existing typed metadata visitor. Capture leaves no writer/appender/transaction pointer retained.',
        'Ready, full and append roots are mutually exclusive in the receiver footprint. An append ticket covers its old prefix without a second ordinary read admission; COW-copy-only source pages are not incorrectly treated as receiver pages.',
        'Every exact append prefix is purely checked before the first writer is sealed. The new pure query shares the original validation formula and cannot export a view, allocate a ticket, or change the epoch/seal.',
        'Token, Store and resource entries retain the same original terminal table, proxy, Queue and whole verdict. A private read-only InputSources query rejects splitting one Invocation into multiple pending bundles, avoiding representative-dependent prepare gates.',
        'The original projected-reader pure checks are shared with atomic bundle binding. Required-ready metadata retains its real block/generation/range and is rechecked at preparation/submission; configuration ownership is preserved.',
        'Fresh conversion only follows successful actual write retirement and exact full-ticket/page identity. Existing readonly uses retire normally; old full tickets cannot admit new readers after appendable conversion. New readers use real bounded ready leases.',
        'Paged publication bridges update the original arena frontier and consume full appenders without relaxing public publish/reserve/rollback. Foreign tickets, bad row counts, reacquired ordinary pages, and failed producer publication reject while old snapshots remain unchanged.'
    ],
    'header_catalog_check': {
        'scope': 'CMake registry ownership only; core selected to avoid inference toolchain/dependency setup.',
        'command': 'cmake -S .scratch/inference-paged-source-20261027/owner-project -B .scratch/inference-paged-source-20261027/owner-build -G Ninja',
        'final_exit': 0, 'owner': 'graph_batch',
        'harness_failures_before_final_check': [
            'Initial -P omitted HYLE_COMPONENTS and was rejected as an embedding parent.',
            '-P with graph selected reached CONFIGURE_DEPENDS, which CMake forbids in script mode.',
            'A LANGUAGES NONE graph project had no detected processor for the complete CPU route; no SDK build was attempted.'
        ],
        'resolution': 'Use a LANGUAGES NONE configure project and core selection to inspect the same declared header ownership catalog. No CXX/link/test process was repeated.',
        'sources': [pin(R / name) for name in metadata]
    },
    'remaining_scope': [
        'The actual B only reads KV for attention. A complete successor decode also needs to append/COW from the pending predecessor as its previous state; the current PagedAppendPages construction still requires ready footprints.',
        'Owned-layout readers without an explicit metadata input are currently rejected; their private control identity/retention must still be integrated. This is an outstanding capability, not an out-of-scope model.',
        'Delegated Apple/Vulkan, multi-segment relays, pending indexed GDN/conv readers, continuous bounded rotation and actual model overlap remain unimplemented/unverified by this batch.',
        'No new ordinary/MTP model benchmark, tokens/s, peak memory, numerical quality or throughput result.',
        'The actual CUDA case is positive. Append/fresh failure/publication checks use controlled Completion protocol; the inherited Source error cases do not constitute a GPU KV driver-fault injection.',
        'The new Paged source and Source metadata/ticket arrays are cold, but common Source/bundle/preparation can still allocate after predecessor submission; full-model cold-budget admission remains required.',
        'Only the header ownership catalog was checked in CMake; no installed SDK packaging, full project configure or separate header-test target was run.'
    ],
    'source_freeze': plan['sources'], 'image': ready['image'], 'baseline': plan['baseline']
}
members = [W / p for p in ('check.py', 'evidence.py', 'selection.json', 'plan.json', 'compiled.json',
    'ready.json', 'link-inputs.json', 'summary.json', 'results.xml', 'header-owner.cmake',
    'header-owner-initial.cmake', 'owner-project/CMakeLists.txt', 'owner-build/CMakeCache.txt')]
members += [p for p in (W / 'source').rglob('*') if p.is_file()]
for folder in ('compile', 'link', 'run'):
    members += [p for p in (W / folder).rglob('*') if p.is_file() and p.suffix in ('.json', '.log')]
with zipfile.ZipFile(OUT.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in members:
        archive.write(p, p.relative_to(W))
receipt['archive'] = pin(OUT.with_suffix('.zip'))
OUT.with_suffix('.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'receipt': pin(OUT.with_suffix('.json')), 'archive': receipt['archive']}, indent=2))
