from pathlib import Path
import importlib.util
import json
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-hybrid-append-20261027'
spec = importlib.util.spec_from_file_location('cached_recipe', OLD / 'check.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b, h = q.b, q.h

SPECS = [
    ('resources', 'src/graph/resources.cc', OLD / 'compile/resources/command.json', OLD / 'compile/resources/unit.obj'),
    ('inputs', 'src/graph/input_sources.cc', R / '.scratch/inference-submission-source-20261027/compile/inputs/command.json', R / '.scratch/inference-submission-source-20261027/compile/inputs/unit.obj'),
    ('leases', 'src/compute/resource_leases.cc', OLD / 'compile/leases/command.json', OLD / 'compile/leases/unit.obj'),
    ('arena', 'src/compute_batch/paged_arena.cc', R / '.scratch/inference-paged-frame-20261026/compile/arena/command.json', R / '.scratch/inference-paged-frame-20261026/compile/arena/unit.obj'),
    ('append', 'src/graph_batch/paged_append.cc', R / '.scratch/inference-paged-frame-20261026/engine/compile/append/command.json', R / '.scratch/inference-paged-frame-20261026/engine/compile/append/unit.obj'),
    ('batch', 'src/graph_batch/batch.cc', R / '.scratch/inference-slot-store-20261027/attempt1/compile/batch/command.json', R / '.scratch/inference-slot-store-20261027/attempt1/compile/batch/unit.obj'),
    ('graph-test', 'tests/graph/output_source_cuda_test.cc', OLD / 'compile/graph-test/command.json', OLD / 'compile/graph-test/unit.obj'),
    ('arena-test', 'tests/compute_batch/paged_arena_test.cc', R / '.scratch/inference-host-image-20261026/arena/paged-test/command.json', None),
    ('paged-test', 'tests/graph_batch/paged_append_source_test.cc', OLD / 'compile/graph-test/command.json', None),
]
EXTRA = ['include/hyle/compute/detail/lease_access.h', 'include/hyle/compute/detail/paged_arena_access.h',
    'include/hyle/graph/detail/submission_source.h', 'include/hyle/graph/detail/resource_source.h',
    'include/hyle/graph/detail/output_source.h', 'include/hyle/graph/detail/region_access.h',
    'include/hyle/graph/detail/paged_append_source.h', 'include/hyle/graph/batch.h',
    'src/graph/input_sources.h', 'src/graph_batch/paged_append.h']


def environment(command):
    cl = command[0]
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': cl, 'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = b.read(Path(b.read(OLD / 'ready.json')['runtime']['path']))['PATH']
    return env


def freeze():
    assert not (W / 'plan.json').exists()
    inputs = b.read(OLD / 'link-inputs.json')
    units = []
    for name, source, template, old in SPECS:
        assert old is None or sum(b.key(x['path']) == b.key(old) for x in inputs) == 1, name
        out = W / 'compile' / name
        argv = b.read(template)['command']
        command = []
        for i, arg in enumerate(argv):
            if i and argv[i - 1].lower() == '/sourcedependencies':
                arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith('.cc'):
                arg = str(R / source)
            command.append(arg)
        units.append(dict(name=name, source=b.pin(R / source), old=b.pin(old) if old else None, command=command))
    sources = [b.pin(R / path) for path in [*(s[1] for s in SPECS), *EXTRA]]
    for row in sources:
        dest = W / 'source' / Path(row['path']).relative_to(R)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(Path(row['path']).read_bytes())
    selection = b.read(W / 'selection.json')['tests']
    assert selection and len(set(selection)) == len(selection)
    b.save(W / 'plan.json', dict(units=units, sources=sources, tests=selection,
        baseline=b.pin(OLD / 'link-inputs.json'), input_count=len(inputs),
        scope='Original PagedAppend Source to shared CUDA attention, concrete common Graph bundle, and controlled Paged publication bridges. No model overlap or performance claim.'))
    print('FROZEN', len(units), 'CXX,', len(selection), 'tests', flush=True)


def check(plan):
    for row in plan['sources']:
        b.exact(row)


def build():
    plan = b.read(W / 'plan.json')
    check(plan)
    env = environment(plan['units'][0]['command'])
    inputs = b.read(OLD / 'link-inputs.json')
    for row in inputs:
        b.exact(row)
    replacements, compiled, additions = {}, [], []
    for unit in plan['units']:
        out = W / 'compile' / unit['name']
        assert not out.exists()
        process = h.execute(unit['command'], env, out, timeout=180)
        check(plan)
        obj = b.pin(out / 'unit.obj')
        if unit['old']:
            replacements[b.key(unit['old']['path'])] = obj
        else:
            additions.append(obj)
        compiled.append(dict(name=unit['name'], object=obj, process=process))
        b.save(W / 'compiled.json', compiled)
    linked_inputs = [replacements.get(b.key(x['path']), x) for x in inputs] + additions
    b.save(W / 'link-inputs.json', linked_inputs)
    image = W / 'bin/paged-source-test.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    command = []
    for arg in b.read(OLD / 'link/command.json')['command']:
        if b.key(arg) in replacements:
            arg = replacements[b.key(arg)]['path']
        elif arg.lower().startswith('/out:'):
            arg = '/OUT:' + str(image)
        elif arg.lower().startswith('/pdb:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.lower().startswith('/implib:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    command += [row['path'] for row in additions]
    link = h.execute(command, env, W / 'link', timeout=120)
    b.save(W / 'ready.json', dict(image=b.pin(image), compiled=compiled, link=link,
        inputs=b.pin(W / 'link-inputs.json'), plan=b.pin(W / 'plan.json'),
        runtime=b.pin(Path(b.read(OLD / 'ready.json')['runtime']['path']))))
    print('READY', flush=True)


def run():
    plan, ready = b.read(W / 'plan.json'), b.read(W / 'ready.json')
    check(plan)
    b.exact(ready['image'])
    xml = W / 'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter=' + ':'.join(plan['tests']), '--gtest_output=xml:' + str(xml)],
        environment(plan['units'][0]['command']), W / 'run', timeout=90)
    root = ET.parse(xml).getroot()
    cases = root.findall('./testsuite/testcase')
    actual = {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases}
    ok = actual == set(plan['tests']) and all(x.attrib.get('status') == 'run' and
        not x.findall('failure') and not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(W / 'summary.json', dict(status='PASS' if ok else 'FAIL', process=process,
        tests=[x.attrib for x in cases], image=ready['image'], sources=plan['sources']))
    assert ok
    print('PASS', len(cases), flush=True)


if __name__ == '__main__':
    try:
        {'freeze': freeze, 'build': build, 'run': run}[sys.argv[1]]()
    except Exception:
        b.save(W / (sys.argv[1] + '-failure.json'), dict(error=traceback.format_exc()))
        raise
