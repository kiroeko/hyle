"""Two current consumers using retained SDK inputs; no SDK build or download."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')

W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-natural-logits-control-20261029'
BASE = OLD / 'model-link-base.json'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest())

def exact(item):
    actual = pin(item['path'])
    assert key(actual['path']) == key(item['path']) and all(
        actual[field] == item[field] for field in ('bytes', 'sha256')), item['path']

def key(path):
    return os.path.normcase(os.path.abspath(path))

def prepare():
    base = read(BASE)
    assert len(base['retained']) == 227
    for item in base['retained']:
        exact(item)
    exact(base['runtime'])
    sdk = read(base['sdk_engine_dependencies']['path'])
    for consumer in sdk['engine_consumers']:
        for item in consumer['source_identities']:
            exact(item)
    old_source = R / 'tests/tools/qwen_host_image_test.cc'
    old_object = read(base['previous_consumer']['path'])['object']['path']
    units = {}
    for name, source in [('tiny', old_source), ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        compile_args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index - 1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(old_source):
                arg = str(source)
            compile_args.append(arg)
        link_args = []
        for arg in base['link']:
            if key(arg) == key(old_object):
                arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link_args.append(arg)
        assert sum(key(a) == key(source) for a in compile_args) == 1
        assert sum(key(a) == key(folder / 'unit.obj') for a in link_args) == 1
        units[name] = dict(source=str(source), compile=compile_args, link=link_args)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    fixtures = read(OLD / 'plan.json')['fixtures']
    conditional, natural = fixtures['conditional']['directory'], fixtures['natural']['directory']
    ordinary = R / '.scratch/inference-continuous-wave-20261027/inputs/context32'
    assert (ordinary / 'weights.tsv').is_file() and (ordinary / 'prompt.ids').is_file()
    save(W / 'plan.json', dict(base=pin(BASE), units=units, retained=base['retained'], runtime=base['runtime'],
        fixtures=fixtures, ordinary_fixture=dict(manifest=pin(ordinary / 'weights.tsv'), prompt=pin(ordinary / 'prompt.ids')),
        cases={
            'program-cpu': ['tiny', '--cpu', '--program-carrier'],
            'program-cuda': ['tiny', '--cuda', '--program-carrier'],
            'controls-cpu': ['tiny', '--cpu', conditional, '--natural-logits-control'],
            'controls-cuda': ['tiny', '--cuda', conditional, '--natural-logits-control'],
            'mtp-cuda': ['tiny', '--cuda', natural, '--mtp-natural-relay'],
            'ordinary-cuda': ['ordinary', '--cuda-continuous', str(ordinary)]},
        scope='Current consumer compilation; retain original SDK binaries. License-only SDK header updates did not change SDK code. No SDK CXX/NVCC, model download, or throughput claim.'))
    print('Prepared 2 consumers, 227 retained SDK inputs, 6 bounded native cases; no compile/run started.')

def execute(command, folder, timeout):
    folder.mkdir(parents=True, exist_ok=True)
    assert not (folder / 'process.json').exists(), 'Preserve the prior attempt; select a new output folder.'
    env = os.environ.copy()
    env.update(read(OLD / 'environment.json'))
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    temporary = W / 'tmp'
    temporary.mkdir(exist_ok=True)
    env['TEMP'] = env['TMP'] = str(temporary)
    save(folder / 'command.json', command)
    started = time.time()
    with (folder / 'stdout.log').open('wb') as stdout, (folder / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=R, env=env, stdout=stdout, stderr=stderr,
                                   creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        save(folder / 'process.json', dict(state='RUNNING', pid=process.pid, started=started))
        print('RUNNING', process.pid, folder.relative_to(W), flush=True)
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            code = process.wait()
    save(folder / 'process.json', dict(state='TERMINAL', pid=process.pid, started=started,
                                      seconds=time.time() - started, exit=code, timed_out=timed_out))
    if code or timed_out:
        print((folder / 'stdout.log').read_text(encoding='utf-8', errors='replace')[-7000:])
        print((folder / 'stderr.log').read_text(encoding='utf-8', errors='replace')[-7000:])
        raise SystemExit(code or 1)
    print('PASS process', process.pid, flush=True)

def main():
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
        return
    plan = read(W / 'plan.json')
    name = sys.argv[2]
    if action == 'compile':
        attempt = 'process' if len(sys.argv) < 4 else 'process-' + sys.argv[3]
        folder = W / 'compile' / name / attempt
        execute(plan['units'][name]['compile'], folder, 240)
        deps = read(W / 'compile' / name / 'dependencies.json')['Data']
        project = [Path(deps['Source']), *map(Path, deps['Includes'])]
        project = sorted({p.resolve() for p in project if p.is_relative_to(R) and '.scratch' not in p.relative_to(R).parts})
        assert R / 'engine/inference/program_slots.h' in project
        save(W / 'compile' / name / 'receipt.json', dict(object=pin(W / 'compile' / name / 'unit.obj'), process=pin(folder / 'process.json'),
             dependencies=pin(W / 'compile' / name / 'dependencies.json'), source_identities=[pin(p) for p in project]))
    elif action == 'link':
        execute(plan['units'][name]['link'], W / 'link' / name, 180)
        save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))
    elif action == 'run':
        unit, *args = plan['cases'][name]
        image = read(W / ('ready-' + unit + '.json'))
        exact(image)
        folder = W / 'runs' / name
        execute([image['path'], *args], folder, 300)
        report = read(folder / 'stdout.log')
        assert report['status'] == 'PASS'
        save(folder / 'report.json', report)
        print('PASS', name)
    else:
        raise ValueError(action)

if __name__ == '__main__':
    main()
