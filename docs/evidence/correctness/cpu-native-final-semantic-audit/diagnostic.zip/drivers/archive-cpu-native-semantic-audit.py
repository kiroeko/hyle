from pathlib import Path
import hashlib,json,subprocess,zipfile
repo=Path(__file__).resolve().parents[1]
out=repo/'.scratch/validation/cpu-native-final'
evidence=repo/'evidence/correctness/cpu-native-final-semantic-audit';evidence.mkdir(parents=True,exist_ok=True)
manifest=json.loads((repo/'.scratch/validation/cpu-aten-compilation-storage/manifest.json').read_text())
for name,digest in manifest['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
identity={'product_candidate':manifest['candidate'],'canonical_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'unchanged_product_fixture_inputs':len(manifest['files']),'timing':False,'source_scope':'Frozen Native and current mature default; no product edits or new performance measurement'}
(out/'product-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
files=[(p,p.name) for p in out.iterdir() if p.is_file() and p.suffix!='.obj']
for name in ('cpu-native-semantic-probe.py','summarize-cpu-native-semantics.py','archive-cpu-native-semantic-audit.py'):
    files.append((repo/'.scratch'/name,'drivers/'+name))
with zipfile.ZipFile(evidence/'diagnostic.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p,name in files:z.write(p,name)
result={'identity':identity,'rows':322,'native_rows':161,'mature_rows':161,'native_bad_rows':31,'mature_bad_rows':0,'prepare_rejects':0,'not_inferred':'Not P1/whole model/all-input correctness; failed public qualified numeric domains cannot enter SOTA comparison. No product retirement yet.','artifact':{'entries':len(files),'bytes':(evidence/'diagnostic.zip').stat().st_size,'sha256':hashlib.sha256((evidence/'diagnostic.zip').read_bytes()).hexdigest()}}
(evidence/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result['artifact']))
