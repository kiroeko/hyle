from pathlib import Path
import json
repo=Path(__file__).resolve().parents[1]
out=repo/'.scratch/validation/cpu-native-final'
lines=(out/'11-same-contract-frozen-semantic-witness.log').read_text(encoding='utf-8').splitlines()
rows=[line.split('\t') for line in lines if line.startswith('ROW\t')]
summary=[]
for name in dict.fromkeys(row[1] for row in rows):
    for dtype in dict.fromkeys(row[2].split('=')[1] for row in rows if row[1]==name):
        own=[row for row in rows if row[1]==name and row[2]=='dtype='+dtype and row[4]=='Native']
        peers=[row for row in rows if row[1]==name and row[2]=='dtype='+dtype and row[4]=='mature']
        summary.append({'operation':name,'dtype':dtype,'native_rows':len(own),'native_failed':sum(row[-1]!='mismatches=0' for row in own),'mature_rows':len(peers),'mature_failed':sum(row[-1]!='mismatches=0' for row in peers)})
(out/'semantic-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps([row for row in summary if row['native_failed'] or row['mature_failed']],indent=2))
