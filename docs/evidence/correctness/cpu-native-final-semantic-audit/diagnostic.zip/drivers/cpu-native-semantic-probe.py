import shutil
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-native-final';out.mkdir(parents=True,exist_ok=True)
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
reference=(repo/'tests/compute_provider_native/half_test_support.h').read_text(encoding='utf-8').replace('#include <gtest/gtest.h>','').split('template <class Value> hyle::mem::Buffer buffer(')[0]+'}\n'
(out/'semantic_reference.h').write_text(reference,encoding='utf-8',newline='\n')
exe=build/'bin/cpu_native_semantic_probe.exe'
compiler=shutil.which('cl',path=env.get('Path',env.get('PATH','')));assert compiler
libs=['compute_route_cpu','compute_provider_ggml','compute_provider_onednn','compute_provider_native','compute_backend_cpu','compute','compute_ops','mem','platform','error','simd']
run('compile-frozen-semantic-witness',[compiler,'/nologo','/std:c++latest','/Zc:__cplusplus','/Zc:preprocessor','/utf-8','/EHsc','/O2','/MD','/I'+str(repo/'include'),'/I'+str(repo/'tests/compute_provider_native'),str(out/'semantic_probe.cc'),'/Fo'+str(out/'semantic-probe.obj'),'/Fe'+str(exe)]+[str(build/('bin/hyle_'+lib+'.lib')) for lib in libs])
run('same-contract-frozen-semantic-witness',[exe])
