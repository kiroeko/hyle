from pathlib import Path
import importlib.util, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('bool_consumer_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
out=S/'consumer-final';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
basepath=S/'green/link-plan.json';base=c.read(basepath)
receipt=c.read(Path(sys.argv[1]));obj=receipt['object'];assert h.h.same_identity(obj)
old=S.parent/'fp8-channel-token-qdq/checks/cuda/test.obj'
assert sum(c.key(r['path'])==c.key(old) for r in base['inputs'])==1
inputs=[obj if c.key(r['path'])==c.key(old) else r for r in base['inputs']]
command=[obj['path'] if c.key(a)==c.key(old) else a for a in base['command']
 if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
for row in inputs:assert h.h.same_identity(row),row['path']
env,runtime=b.environment(command,[r['path'] for r in inputs],out)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),fixture_receipt=b.identity(sys.argv[1])))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
filt=':'.join(['CudaFp8ChannelTokenQdqGraph.*','CudaTensor.BoolConversionsPreserveNonzeroBitsAndNormalizeTruthValues',
 'CudaTensor.FloatStorageConversionsMatchIndependentRounding','CudaTensor.SelectCopyFillPreserveBitsWithBroadcastMaskAndOddStride',
 'CudaTensor.ViewUsesRequiredStorageOffsetAndCopyRejectsOverlap','CudaFp8Cast.*'])
c.execute('run',[str(image),'--gtest_filter='+filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
c.save(out/'input-recheck.json',dict(inputs=[b.identity(r['path']) for r in inputs],fixture=b.identity(receipt['source']['path'])))
