from pathlib import Path
import importlib.util, sys, json, concurrent.futures, shutil, subprocess, ctypes
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; A=S.parent; ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('bool_cast_helpers', A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'fp8-channel-token-qdq/checks/cuda/link-plan.json'
base=c.read(BASE); meta=h.metadata({'cuda':base})
wanted={'tensor_provider.cc','row_cache_indexer_provider.cc','tensor_kernel.cu'}
owners={Path(r['source_path']).name:r for obj in base['inputs']
        if (r:=meta.get(c.key(obj['path'])))
        if Path(r['source_path']).parent.name=='compute_provider_cuda' and Path(r['source_path']).name in wanted}
tests=[r for r in meta.values() if c.key(r['source_path'])==c.key(ROOT/'tests/compute_provider_cuda/tensor_test.cc')]
if not tests:
 tests=[r for r in meta.values() if Path(r['source_path']).name=='fp8_cast_test.cc']
compdb=json.loads(subprocess.check_output(
 ['C:/PROGRA~1/PYTHON~1/Scripts/ninja.exe','-C',str(ROOT/'.scratch/b-cuda-d5'),'-t','compdb'],text=True))
entry=next(r for r in compdb if Path(r['file']).name=='tensor_kernel.cu')
argc=ctypes.c_int();parse=ctypes.windll.shell32.CommandLineToArgvW
parse.restype=ctypes.POINTER(ctypes.c_wchar_p);parse.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
argv=parse(entry['command'],ctypes.byref(argc));native_command=[argv[i] for i in range(argc.value)]
ctypes.windll.kernel32.LocalFree(argv)
old_native=next(r for r in base['inputs'] if Path(r['path']).name=='tensor_kernel.cu.obj')
owners['tensor_kernel.cu']=dict(command=native_command,source_path=str(ROOT/'src/compute_provider_cuda/tensor_kernel.cu'),
 recipe='actual retained CMake Ninja compdb',object=old_native)
def save_inventory():
 c.save(S/'inventory.json',dict(owners=owners,tests=tests,missing=sorted(wanted-owners.keys())))
 print('OWNERS',[(k,v['recipe']) for k,v in owners.items()], 'TESTS',len(tests),flush=True)
def host(recipe,source,tag,out,env):
 command=b.host_command(recipe['command'],source,tag,out)
 c.execute(tag+'-compile',command,env,out)
 deps=c.read(out/(tag+'-deps.json'))['Data']
 result=dict(command=command,source=b.identity(source),object=b.identity(out/(tag+'.obj')),
  dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
 c.save(out/(tag+'-identity.json'),result);return result
def link(out,replacements,env,test):
 inputs=[replacements.get(c.key(r['path']),r) for r in base['inputs']]
 command=[replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command']
  if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 inputs.append(test);command.append(test['path'])
 image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 for row in inputs:assert h.same_identity(row),row['path']
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(BASE)))
 c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
def main():
 save_inventory()
 mode=sys.argv[1] if len(sys.argv)>1 else 'inventory'
 if mode=='inventory':return
 out=S/mode;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
 env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
 c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
 replacements={}
 if mode=='red':
  assert len(tests)==1,len(tests)
  recipe=tests[0];result=host(recipe,ROOT/'tests/compute_provider_cuda/tensor_test.cc','test',out,env)
  test=result['object']
 elif mode=='green':
  red=c.read(S/'red/test-identity.json');assert h.same_identity(red['object'])
  test=red['object']
  assert wanted<=owners.keys(), sorted(wanted-owners.keys())
  for name in ['tensor_provider.cc','row_cache_indexer_provider.cc']:
   recipe=owners[name];result=host(recipe,Path(recipe['source_path']),Path(name).stem,out,env)
   old=next(r for r in base['inputs'] if c.key(r['path']) in meta and meta[c.key(r['path'])] is recipe)
   replacements[c.key(old['path'])]=result['object']
  recipe=owners['tensor_kernel.cu'];old_command=recipe['command'];source=Path(recipe['source_path'])
  command=list(old_command)
  assert '-o' in command
  command[command.index('-o')+1]=str(out/'tensor_kernel.obj')
  for flag in ['-MF','--dependency-output']:
   if flag in command:command[command.index(flag)+1]=str(out/'tensor_kernel.d')
  command=[('-Xcompiler=-Fd'+str(out/'tensor-kernel.pdb')+',-FS') if a.startswith('-Xcompiler=-Fd') else a for a in command]
  if '-MT' in command:command[command.index('-MT')+1]=str(out/'tensor_kernel.obj')
  c.execute('tensor-kernel-compile',command,env,out)
  result=dict(command=command,source=b.identity(source),header=b.identity(source.with_suffix('.h')),object=b.identity(out/'tensor_kernel.obj'))
  c.save(out/'tensor-kernel-identity.json',result)
  replacements[c.key(old_native['path'])]=result['object']
 else:raise ValueError(mode)
 c.save(out/'replacements.json',replacements);link(out,replacements,env,test)
 filt='CudaTensor.BoolConversionsPreserveNonzeroBitsAndNormalizeTruthValues'
 c.execute('run',[str(out/'cuda.exe'),'--gtest_filter='+filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
if __name__=='__main__':main()
