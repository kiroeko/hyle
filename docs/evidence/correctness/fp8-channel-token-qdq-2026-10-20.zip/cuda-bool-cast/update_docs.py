from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
path=ROOT/'docs/implementation/model-operators.md'
text=path.read_text(encoding='utf-8')
changes={
 'CT channel/token scale域、更多分支与完整FFN另核精确合同；共享量化不等于两个GEMM物理融合':
 'CT channel/token已另以固定BF16 QDQ参考接通普通图，部署端原生FP8算术、更多分支与完整FFN另核；共享量化不等于两个GEMM物理融合',
 'channel/token GEMM及整制品仍未接通。':
 '固定CT rank3 BF16 QDQ现用普通Reduce/Cast/Select/Binary/MatMul在CPU、CUDA各执行双槽四次，最终BF16逐bit等于独立oracle；补齐通用浮点↔Bool Cast，保零scale才替换epsilon和逐元素权重反量化舍入。[实际消费者](../evidence/correctness/fp8-channel-token-qdq-2026-10-20.json)不代表整制品、部署端原生FP8 GEMM或性能支持。'
}
for old,new in changes.items():
 assert text.count(old)==1,(old,text.count(old))
 text=text.replace(old,new)
path.write_text(text,encoding='utf-8',newline='\n')
