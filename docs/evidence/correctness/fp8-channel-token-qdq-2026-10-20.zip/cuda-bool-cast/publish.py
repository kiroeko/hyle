"""Keep the actual Bool route repair and CT reference consumer, without binaries."""
from pathlib import Path
import hashlib,json,difflib,zipfile,xml.etree.ElementTree as ET
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
Q=A/'fp8-channel-token-qdq'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def ident(p):
 p=Path(p);data=p.read_bytes()
 return dict(path=str(p.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def checked_tests(path,n):
 cases=ET.parse(path).findall('.//testcase');assert len(cases)==n
 assert not any(x.findall('failure') or x.findall('skipped') for x in cases)
 return [dict(name=x.attrib['classname']+'.'+x.attrib['name'],properties={p.attrib['name']:p.attrib['value']
  for p in x.findall('./properties/property')}) for x in cases]
cpu=checked_tests(Q/'fixture-api-correction/final-checks/cpu/tests.xml',3)
cuda=checked_tests(S/'consumer-final/tests.xml',10)
for cases in [cpu,cuda]:
 qdq=[r for r in cases if 'Fp8ChannelTokenQdqGraph.' in r['name']]
 assert len(qdq)==1 and qdq[0]['properties']['actual_submissions']=='4'
for plan in [Q/'fixture-api-correction/final-checks/cpu/link-plan.json',S/'consumer-final/link-plan.json']:
 for row in read(plan)['inputs']:
  actual=ident(row['path']);assert actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'],row['path']
for arm in ['cpu','cuda']:
 receipt=read(Q/f'fixture-api-correction/final-checks/{arm}/test-identity.json')
 assert ident(receipt['object']['path'])==receipt['object']
 for row in receipt['dependencies']:
  actual=ident(row['path']);assert actual['sha256']==row['sha256'],row['path']
red=ET.parse(S/'red/tests.xml').findall('.//testcase');assert len(red)==1 and red[0].findall('failure')
for arm in ['cpu','cuda']:
 old=ET.parse(Q/f'checks/{arm}/tests.xml').findall('.//testcase')
 assert len(old)==1 and old[0].findall('failure')
paths=['src/compute_provider_native/cast.cc','src/compute_provider_cuda/tensor_provider.cc',
 'src/compute_provider_cuda/tensor_kernel.h','src/compute_provider_cuda/tensor_kernel.cu',
 'tests/compute_provider_native/cast_test.cc','tests/compute_provider_cuda/tensor_test.cc',
 'tests/compute_models/fp8_channel_token_qdq_fixture.h','tests/graph_route_cpu/fp8_channel_token_qdq_test.cc',
 'tests/graph_route_cuda/fp8_channel_token_qdq_test.cc','tests/graph_route_cpu/CMakeLists.txt','tests/graph_route_cuda/CMakeLists.txt']
for rel in paths:
 target=S/'frozen'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/rel).read_bytes())
diff=''
for rel in paths:
 old=(Q/'cpu-bool/before'/rel) if rel.startswith('src/compute_provider_native') or rel.startswith('tests/compute_provider_native') else S/'before'/rel
 if old.is_file():diff+=''.join(difflib.unified_diff(old.read_text().splitlines(True),(ROOT/rel).read_text().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
(S/'source.diff').write_text(diff,encoding='utf-8')
final=dict(status='passed focused Windows CPU/CUDA reference consumer; broader goal remains active',date='2026-10-20',
 scope='Synthetic fixed compressed-tensors BF16 QDQ reference on ordinary public Graph, not an artifact payload or native FP8 dot implementation',
 source= [ident(ROOT/p) for p in paths],cpu=cpu,cuda=cuda,
 mathematical_contract=dict(source_research='docs/evidence/research/fp8-channel-token-contract-2026-10-20.json',
  shape='BF16 A[1,3,16]; E4M3FN W[4,16]; BF16 Ws[4,1]',
  reference='BF16 last-K absmax/448; replace only exactly-zero scale by BF16 epsilon; BF16 divide/clamp, FP8 RNE, BF16 dequant A and per-channel W before ordinary BF16 MatMul/F32 accumulation',
  oracle='Independent finite BF16 bit rounding, enumerated FP8 RNE and scalar products; final BF16 bits equal for all four submissions on each backend',
  negative_controls='Payload rejects a positive epsilon floor and omission of BF16 per-element weight dequant rounding'),
 product_changes=['CPU Native Cast adds F32/F16/BF16 <-> Bool using original NativePlan/materializer',
  'CUDA Native tensor provider and private kernel add the same conversions without changing shared ElementType or layout',
  'Floating magnitude bits distinguish +/-0 from every nonzero pattern without FTZ/DAZ loss; Bool bytes normalize via !=0',
  'Bool arithmetic and integer/FP8 Bool Cast remain unadmitted; same-type Bool Cast materializes Copy; out-of-place rules remain'],
 actual_lifetimes='Five materialized constants; original bindings/read leases cleared after compile and Invocation creation; two independent slots, four content updates, old-result replay gate, retained results read after Invocation destruction',
 red_proof=['Original CPU/CUDA Graph each refuses BF16 -> Bool at node3, before submit',
  'Native-only CUDA Direct regression has six expected admission failures before the repair; the identical test object passes afterward',
  'CPU has no pre-repair Direct Bool run; its original Graph route failure is the red evidence'],
 fixture_errors='Preserved initial CompileReport receiver compile errors, missing Invocation resources, aligned output pool capacity, CUDA constant owner/readiness errors. These are new test fixture mistakes, not additional product defects.',
 final_build='CPU repair: one product CXX and one existing Cast test CXX. CUDA private-header closure: two host owners and one NVCC TU, plus one native Tensor test CXX; all other objects and SDKs reused. A preliminary CUDA green build and formatting rebuild both ran this same product closure.',
 agent_counts=read(Q/'cpu-final-validation.json')['cumulative_agent_owned_counts'],
 root_counts=dict(host_CXX=5,NVCC=2,links=5,GPU_test_processes=5,SDK_builds=0,model_runs=0,
  detail='One red test CXX; two successive product builds each two CXX+one NVCC; red, preliminary green, final green, fixture-owner rejection and final consumer each link/run once'),
 cpu_receipt=ident(Q/'cpu-final-validation.json'),device=ident(S/'device.txt'),
 not_verified=['Full artifact payload/role loader, base-model identity or quality','Deployment quantizer and native FP8 Tensor Core dot',
  'Whole Qwen speed, kernels, loading, memory or power','CT QDQ CUDA capture (existing FP8 Cast is not capture-compatible)',
  'Other CPU/GPU backends or operating systems for this new Bool/CT path','No new dedicated Bool zero-stride/empty/same-type regression'],
 related_linux='docs/evidence/correctness/linux-layout-current-2026-10-20.json')
save(S/'final-validation.json',final)
payload={}
for prefix,folder in [('cuda-bool-cast',S),('fp8-channel-token-qdq',Q)]:
 for p in folder.rglob('*'):
  if not p.is_file() or p.suffix.lower() not in {'.json','.log','.xml','.py','.cc','.h','.txt','.diff','.d'}:continue
  if any(x in {'tmp','cleanup','__pycache__'} for x in p.relative_to(folder).parts):continue
  if p.stat().st_size>8_000_000:continue
  payload[prefix+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(payload.items())}
target=ROOT/'docs/evidence/correctness/fp8-channel-token-qdq-2026-10-20.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in payload.items():z.writestr(name,data)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(n.casefold() for n in z.namelist()))
 for name,row in manifest.items():
  assert not name.startswith('/') and '..' not in Path(name).parts
  data=z.read(name);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
public=dict(final,archive=ident(target),payloads=len(payload),manifest='manifest.json',
 members={name:manifest[name] for name in ['cuda-bool-cast/final-validation.json','fp8-channel-token-qdq/cpu-final-validation.json',
 'cuda-bool-cast/consumer-final/tests.xml','fp8-channel-token-qdq/fixture-api-correction/final-checks/cpu/tests.xml']})
save(target.with_suffix('.json'),public)
print(json.dumps(dict(json=ident(target.with_suffix('.json')),archive=ident(target),payloads=len(payload)),indent=2))
