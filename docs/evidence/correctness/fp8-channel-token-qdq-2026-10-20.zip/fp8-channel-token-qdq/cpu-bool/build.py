from pathlib import Path
import importlib.util,sys,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];ROOT=A.parents[1];out=S/'checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('cpu_bool_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=S.parent/'checks/cpu/link-plan.json';base=c.read(basepath);meta=h.metadata({'cpu':base});freeze=c.read(S/'source-freeze.json')
for r in base['inputs']:assert h.same_identity(r),r['path']
for r in c.read(S.parent/'source-freeze.json')['files']:assert b.identity(ROOT/r['path'])['sha256']==r['sha256']
product=next((o,meta[c.key(o['path'])])for o in base['inputs']if c.key(o['path'])in meta and Path(meta[c.key(o['path'])]['source_path']).name=='cast.cc')
template=next(r for r in meta.values()if Path(r['source_path']).name=='aten_cast_test.cc')
rows=[dict(source=ROOT/'src/compute_provider_native/cast.cc',recipe=product[1],tag='cast'),dict(source=ROOT/'tests/compute_provider_native/cast_test.cc',recipe=template,tag='cast-test')]
env,runtime=b.environment(base['command'],[r['path']for r in base['inputs']],out);c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
def frozen_check():
 for r in freeze['files']:assert b.identity(ROOT/r['path'])['sha256']==r['sha256']
def compile_one(row):
 command=b.host_command(row['recipe']['command'],row['source'],row['tag'],out);before=b.identity(row['source']);c.save(out/(row['tag']+'-plan.json'),dict(source=before,command=command,recipe=row['recipe']['recipe'],same_original_CMake_test_target=row['tag']=='cast-test'))
 frozen_check();c.execute(row['tag']+'-compile',command,env,out);frozen_check();dep=out/(row['tag']+'-deps.json');d=c.read(dep)['Data'];r=dict(command=command,source=before,object=b.identity(out/(row['tag']+'.obj')),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=row['recipe']['recipe']);c.save(out/(row['tag']+'-identity.json'),r);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:finished=list(pool.map(compile_one,rows))
command=[finished[0]['object']['path']if c.key(a)==c.key(product[0]['path'])else a for a in base['command']if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];image=out/'cpu.exe';command+=[finished[1]['object']['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
lookup={c.key(r['path']):r for r in [*base['inputs'],*[r['object']for r in finished]]};inputs=[lookup[c.key(a)]for a in command if Path(a).is_absolute()and Path(a).suffix.lower()in('.obj','.lib')]
for r in inputs:assert h.same_identity(r),r['path']
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),original_qdq_test_object=c.read(S.parent/'checks/cpu/test-identity.json')['object']));c.execute('link',command,env,out);frozen_check();c.save(out/'image.json',b.identity(image));c.execute('tests',[str(image),'--gtest_filter=NativeCast.*:CpuFp8ChannelTokenQdqGraph.*','--gtest_output=xml:'+str(out/'tests.xml')],env,out)
