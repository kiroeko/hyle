from pathlib import Path
import importlib.util,sys,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;Q=S.parent;A=Q.parent;ROOT=A.parents[1];out=S/'final-checks';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('fixture_resource_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
freeze=c.read(Q/'source-freeze.json')
def frozen_check():
 for r in freeze['files']:assert b.identity(ROOT/r['path'])['sha256']==r['sha256']
def build(arm):
 dest=out/arm;dest.mkdir(exist_ok=True);(dest/'tmp').mkdir(exist_ok=True);recipe=c.read(Q/f'checks/{arm}/test-identity.json');basepath=Q/('cpu-bool/checks/link-plan.json'if arm=='cpu'else'checks/cuda/link-plan.json');base=c.read(basepath)
 for r in base['inputs']:assert h.same_identity(r),r['path']
 source=ROOT/f'tests/graph_route_{arm}/fp8_channel_token_qdq_test.cc';command=b.host_command(recipe['command'],source,'test',dest);env,runtime=b.environment(base['command'],[r['path']for r in base['inputs']],dest);c.save(dest/'environment.json',dict(PATH=env['PATH'],runtime=runtime));c.save(dest/'plan.json',dict(command=command,source=b.identity(source),recipe=str(Q/f'checks/{arm}/test-identity.json'),base=b.identity(basepath),freeze=b.identity(Q/'source-freeze.json')))
 frozen_check();c.execute('compile',command,env,dest);frozen_check();dep=dest/'test-deps.json';d=c.read(dep)['Data'];receipt=dict(command=command,source=b.identity(source),object=b.identity(dest/'test.obj'),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=str(Q/f'checks/{arm}/test-identity.json'));c.save(dest/'test-identity.json',receipt);print('FIXTURE_OBJECT',arm,receipt['object']['sha256'],flush=True)
 return
 if arm!='cpu':return
 old=recipe['object'];command=[receipt['object']['path']if c.key(a)==c.key(old['path'])else a for a in base['command']if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];image=dest/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))];lookup={c.key(r['path']):r for r in [*base['inputs'],receipt['object']]};inputs=[lookup[c.key(a)]for a in command if Path(a).is_absolute()and Path(a).suffix.lower()in('.obj','.lib')]
 assert sum(c.key(a)==c.key(receipt['object']['path'])for a in command)==1
 for r in inputs:assert h.same_identity(r),r['path']
 c.save(dest/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replaced_original_qdq_object=old));c.execute('link',command,env,dest);frozen_check();c.save(dest/'image.json',b.identity(image));c.execute('tests',[str(image),'--gtest_filter=NativeCast.*:CpuFp8ChannelTokenQdqGraph.*','--gtest_output=xml:'+str(dest/'tests.xml')],env,dest)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(build,['cpu','cuda']))
