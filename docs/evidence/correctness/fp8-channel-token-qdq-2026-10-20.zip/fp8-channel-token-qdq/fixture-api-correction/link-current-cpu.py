from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;Q=S.parent;A=Q.parent;ROOT=A.parents[1];out=S/'final-checks/cpu'
spec=importlib.util.spec_from_file_location('qdq_final_cpu_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=Q/'cpu-bool/checks/link-plan.json';base=c.read(basepath);new=c.read(out/'test-identity.json');old=c.read(Q/'checks/cpu/test-identity.json')['object']
assert h.same_identity(new['source'])and h.same_identity(new['object'])and all(h.same_identity(x)for x in new['dependencies'])
for r in c.read(Q/'source-freeze.json')['files']:assert b.identity(ROOT/r['path'])['sha256']==r['sha256']
for r in base['inputs']:assert h.same_identity(r),r['path']
command=[new['object']['path']if c.key(a)==c.key(old['path'])else a for a in base['command']if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];image=out/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))];lookup={c.key(r['path']):r for r in [*base['inputs'],new['object']]};inputs=[lookup[c.key(a)]for a in command if Path(a).is_absolute()and Path(a).suffix.lower()in('.obj','.lib')]
assert sum(c.key(a)==c.key(new['object']['path'])for a in command)==1
for r in inputs:assert h.same_identity(r),r['path']
env,runtime=b.environment(command,[r['path']for r in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replaced_original_qdq_object=old));c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));c.execute('tests',[str(image),'--gtest_filter=NativeCast.*:CpuFp8ChannelTokenQdqGraph.*','--gtest_output=xml:'+str(out/'tests.xml')],env,out)
