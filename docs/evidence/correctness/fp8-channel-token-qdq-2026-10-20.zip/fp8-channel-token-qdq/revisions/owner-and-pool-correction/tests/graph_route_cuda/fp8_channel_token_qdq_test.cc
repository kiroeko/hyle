#include "../compute_models/fp8_channel_token_qdq_fixture.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"

TEST(CudaFp8ChannelTokenQdqGraph, RankThreeBfloatReferenceKeepsTypedRoundingAndLifetimes) {
  namespace f = fp8_channel_token_qdq_test;
  auto context = f::take(hyle::graph::cuda::create_context(), "CUDA context");
  auto memory = f::take(f::c::cuda::MemoryResource::create(context, f::c::cuda::MemoryKind::kDevice), "CUDA memory");
  auto queue = f::take(context.create_queue(), "CUDA queue");
  const std::array queues{f::g::QueueBinding{f::g::ExecutionLaneId{0}, &queue}};
  f::run(memory.ref(), queues, [&](const f::g::Graph &graph, f::g::CompileOptions options) {
      return f::g::cuda::compile(graph, context, memory.ref(), options); },
      [](f::m::BufferView destination, std::span<const std::byte> source) { return destination.write(source); },
      [](f::m::ConstBufferView source, std::span<std::byte> destination) { return source.read(destination); });
}
