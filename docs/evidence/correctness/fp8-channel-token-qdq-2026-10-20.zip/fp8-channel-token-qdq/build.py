from pathlib import Path
import importlib.util,sys,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1];out=S/'checks';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('qdq_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
freeze=c.read(S/'source-freeze.json')
def frozen_check():
 for row in freeze['files']:assert b.identity(ROOT/row['path'])['sha256']==row['sha256'],row['path']
def build(arm):
 dest=out/arm;dest.mkdir(exist_ok=True);(dest/'tmp').mkdir(exist_ok=True)
 basepath=A/f'mlx-moe-typed-inputs/checks/{arm}-link-plan.json';base=c.read(basepath);meta=h.metadata({arm:base})
 for row in base['inputs']:assert h.same_identity(row),row['path']
 if arm=='cpu':
  candidates=[r for r in meta.values()if Path(r['source_path']).name=='cpu_mlx_quantized_test.cc'and any(a=='/DHYLE_TEST_GRAPH_ROUTE_CPU=1'for a in r['command'])];assert candidates;recipe=candidates[-1]
 else:recipe=next(r for r in meta.values()if Path(r['source_path']).name=='fp8_cast_test.cc')
 source=ROOT/f'tests/graph_route_{arm}/fp8_channel_token_qdq_test.cc';command=b.host_command(recipe['command'],source,'test',dest);env,runtime=b.environment(base['command'],[r['path']for r in base['inputs']],dest);c.save(dest/'environment.json',dict(PATH=env['PATH'],runtime=runtime));c.save(dest/'plan.json',dict(base=b.identity(basepath),source=b.identity(source),recipe=recipe['recipe'],command=command,freeze=b.identity(S/'source-freeze.json'),product_compiles=0,SDK=0,NVCC=0))
 frozen_check();c.execute('test-compile',command,env,dest);frozen_check();dep=dest/'test-deps.json';deps=c.read(dep)['Data'];obj=b.identity(dest/'test.obj');receipt=dict(command=command,source=b.identity(source),object=obj,source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])],recipe=recipe['recipe']);c.save(dest/'test-identity.json',receipt)
 link=[a for a in base['command']if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];image=dest/f'{arm}.exe';link+=[obj['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))];inputs=[*base['inputs'],obj]
 for row in inputs:assert h.same_identity(row),row['path']
 c.save(dest/'link-plan.json',dict(command=link,inputs=inputs,base=b.identity(basepath)));c.execute('link',link,env,dest);frozen_check();c.save(dest/'image.json',b.identity(image));print('BUILT',arm,flush=True)
if '--build'in sys.argv:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(build,['cpu','cuda']))
if '--run'in sys.argv:
 arm=sys.argv[sys.argv.index('--run')+1];dest=out/arm;plan=c.read(dest/'link-plan.json');env,_=b.environment(plan['command'],[r['path']for r in plan['inputs']],dest);frozen_check();c.execute('run',[str(dest/f'{arm}.exe'),'--gtest_filter='+arm.capitalize()+'Fp8ChannelTokenQdqGraph.*','--gtest_output=xml:'+str(dest/'tests.xml')],env,dest)
