from pathlib import Path
from fractions import Fraction
import hashlib,json,struct
S=Path(__file__).resolve().parent
ROOT=S.parents[3]
def exact(bits):
 e=(bits>>23)&255;m=bits&0x7fffff
 if e:m|=1<<23
 power=(e-150)if e else -149
 return Fraction(m<<max(power,0),1<<max(-power,0))
def nearest(value):
 # Independent generic positive F32 nearest-neighbor search, including
 # subnormals and ties. Does not reuse the proposed /7 normalization.
 lo,hi=0,0x7f7fffff
 while lo<hi:
  mid=(lo+hi+1)//2
  if exact(mid)<=value:lo=mid
  else:hi=mid-1
 if exact(lo)==value:return lo
 upper=lo+1;a=value-exact(lo);b=exact(upper)-value
 return lo if a<b or(a==b and lo%2==0)else upper
def candidate(bits):
 e=(bits>>23)&255;m=(bits&0x7fffff)|0x800000
 shift=2 if m>=0xe00000 else 3
 n=m<<shift;q,r=divmod(n,7);q+=r>=4
 out_e=e-6-shift
 assert n<1<<27 and 0x800000<=q<0x1000000 and 1<=out_e<=246
 return(out_e<<23)|(q&0x7fffff)
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
floors=[]
for b in range(0x04e00000-4,0x04e00000+5):
 out=nearest(exact(b)/448)
 floors.append(dict(input=f'{b:08x}',quotient=f'{out:08x}',common_isnormal=0x00800000<=out<0x7f800000))
assert not any(x['common_isnormal']for x in floors[:4])and all(x['common_isnormal']for x in floors[4:])
minimum=0x04e00000
values={minimum,0x7f7fffff}
for e in [9,10,127,135,254]:
 for m in [0x800000,0x800001,0x9abcde,0xdffffe,0xdfffff,0xe00000,0xe00001,0xfffffe,0xffffff]:
  b=(e<<23)|(m&0x7fffff)
  if b>=minimum:values.add(b)
for d in range(7):values.add((135<<23)|((0x900000+d)&0x7fffff))
for x in [1.e-10,1.e-4,1.,446.,448.,450.]:values.add(bits(x))
rows=[];residues=set()
for b in sorted(values):
 out=nearest(exact(b)/448);actual=candidate(b);assert actual==out,(hex(b),hex(actual),hex(out))
 m=(b&0x7fffff)|0x800000;s=2 if m>=0xe00000 else 3;residues.add((m<<s)%7)
 rows.append(dict(input=f'{b:08x}',oracle=f'{out:08x}',candidate=f'{actual:08x}'))
assert residues==set(range(7))
reciprocal=nearest(Fraction(1,448));a450=bits(450.);exact_div=nearest(exact(a450)/448)
reciprocal_mul=nearest(exact(a450)*exact(reciprocal))
assert exact_div==0x3f809249 and reciprocal_mul==0x3f80924a
generator=ROOT/'third_party/iree_vulkan_runtime/programs/generate_official.py'
result=dict(kind='independent-exact-scalar-source-review',GPU=False,compilation=False,exhaustive=False,
 oracle='Generic Fraction exact-value nearest positive F32 search over all representable bit patterns; binary search plus distance/ties-even selection, independent of the candidate integer normalization.',
 common_minimum_floor=dict(bits='04e00000',exact='448 * 2^-126',minimum_rounded_quotient='00800000',predecessor='04dfffff',predecessor_quotient='007fffff',reason='One input step is 4/7 of a subnormal output ulp. The immediate predecessor lies more than half an output ulp below minimum normal; it rounds to largest subnormal and is rejected by existing common isnormal. No extra admission gate is introduced.'),
 floor_neighbors=floors,
 algorithm=['amax is positive finite F32 and at least the existing valid floor. Extract biased exponent e and 24-bit significand m.','If m < 0xe00000: numerator=m<<3 and result exponent=e-9; otherwise numerator=m<<2 and result exponent=e-8.','q=numerator div7; r=numerator-7*q; q += (r>=4). Since7 is odd, exact halfway is impossible here.','Pack result exponent and low23 bits of q. Do not first round m/7 then shift; do not normalize by a second rounding.'],
 bounds=dict(max_numerator_bits=27,denominator=7,remainder_range=[0,6],rounded_significand_range=['00800000','00ffffff'],output_biased_exponent_range=[1,246],rounding_carry_impossible='At upper/lower normalization boundary the predecessor rounds at most to0x00ffffff; the boundary itself is handled by the other branch and is exactly representable.'),
 scalar_checks=len(rows),residues_covered=sorted(residues),all_match=True,witnesses=rows,
 reciprocal_counterexample=dict(input='450',input_bits=f'{a450:08x}',RN_divide448=f'{exact_div:08x}',F32_rounded_reciprocal=f'{reciprocal:08x}',F32_multiply_reciprocal=f'{reciprocal_mul:08x}',difference_ULP=1),
 generator_at_review=identity(generator),
 source_scope=['Only None quantizer scale amax/448 requires this replacement. Power policy retains original F32 reciprocal multiplication and ceil.','Normalized A/scale remains original expression; this review does not prove its complete E4 tie domain.','Nonfinite source behavior is outside the finite input contract; source helper preserves its existing special-value forwarding.','No general F32/F64 arithmetic library, newexecutor, policy flag or full-domain exhaustive validation is needed.'])
p=S/'fraction-review.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(report=identity(p),checks=len(rows),all_match=True,floor_neighbors=floors,divide450=f'{exact_div:08x}',reciprocal_mul450=f'{reciprocal_mul:08x}')))
