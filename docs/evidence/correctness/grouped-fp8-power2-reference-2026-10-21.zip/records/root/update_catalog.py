from pathlib import Path
import json
P=Path(__file__).resolve().parents[1];R=P.parents[2]
p=R/'docs/implementation/model-quantizations.json';before=P/'root/model-quantizations-before.json'
assert not before.exists();before.write_bytes(p.read_bytes())
d=json.loads(p.read_text(encoding='utf-8-sig'));e='docs/evidence/correctness/grouped-fp8-power2-reference-2026-10-21.json'
old='GroupedFloat8Linear currently lacks the matching power2 activation scale rule; extend/qualify its actual numerical domain, rather than reinterpret F32 SF as UE8M0.'
c=d['artifacts'][27]['provider_coverage'];assert old in c['missing_capabilities']
for key in ('missing_capabilities','artifact_unaligned_or_unverified'):
 c[key]=[s for s in c[key] if s!=old]
for role in c['role_domains']:role['unresolved']=[s for s in role['unresolved'] if s!=old]
c['mapping_status']+=' Grouped power2/floor1e-4 now has a bounded BF16 four-backend reference using the original E4/F32 scale carrier; no stored-scale reinterpretation or whole-role execution.'
c['reachable_entry_points'].append(dict(operation='grouped_float8_linear(Float8ScaleRounding::kPowerOfTwo,1e-4F)',
 execution='BF16 A[T,1|S,K], original E4 W[E,N,K] followed by F32 macroblock128 SF, I32 IDs[T,S]; F32 amax/reciprocal multiplication/ceil power2 and original FP8 group-dot.',
 providers=['CPU native ATen','CUDA existing BF16 colmajor AOT and grouped GEMM','Apple original MLX/packed FP8 dot','Vulkan existing official program with new explicit power entry'],
 qualification='Bounded T2/S3/K256/N129/E3 software math/lifetimes. CUDA F32-power prepares Unimplemented; no fixed artifact payload, whole role/model, Linux, quality or throughput acceptance.',evidence=e))
c['operator_regression_evidence']=e
c['grouped_power2_reference']=dict(evidence=e,artifact_execution_verified=False,ordinary_default='kNone',
 descriptor='8bytes enum32+float, operation ID suffix0002; no old4byte parser or float-only overload',
 CUDA_scale_layout='As strides(1,quant_rows); shared A quantizesT rows once',
 Vulkan_None_precision='Existing scale FDiv450/448 +1F32ulp corrected with integer RN /7; power reciprocal multiply and normalized FDiv unchanged.')
for i in (25,26):
 c=d['artifacts'][i]['provider_coverage']
 old_import='Resolve scale-only importer and any grouped power2 activation quantizer before binding the corresponding routed role; do not infer grouped equivalence from dense support.'
 replacement='Scale-only E8M0 macroblock128 importer/resource binding remains unverified. The generic grouped power2 BF16 reference is now qualified separately; bind only roles with matching physical storage and producer math.'
 for key in ('missing_capabilities','artifact_unaligned_or_unverified'):
  c[key]=[replacement if s==old_import else s for s in c[key]]
 for role in c['role_domains']:role['unresolved']=[replacement if s==old_import else s for s in role['unresolved']]
 c['related_grouped_power2_reference']=dict(evidence=e,role_binding_verified=False,
   scope='Generic numerical building block only; sampled FP8 E8M0 scales still need an exact scale-only import bridge. NVFP4 routed weights keep their separate GroupedFloat4Linear contract.')
d['followup_reviews'].append(dict(observed_on='2026-10-21',evidence=e,artifact_indices=[25,26,27],
 scope='Four-backend grouped power2 BF16 numerical/lifetime reference for matching E4/F32 macroblock128 roles; CUDA F32 negative prepare. E8M0 scale importer and full artifact execution remain unverified.'))
assert len(d['artifacts'])==33 and all(not a['provider_coverage']['artifact_execution_verified'] for a in d['artifacts'])
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('Catalog27 grouped power2 reference added; 25/26 exact E8M0 import stays open; all33 full artifact flags false.')
