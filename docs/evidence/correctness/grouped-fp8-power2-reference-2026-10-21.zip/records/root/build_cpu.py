from pathlib import Path
import importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('power_cpu_host',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'ct-bf16-block128-reference/cpu/checks/attempt5/link-plan.json'
base=c.read(basepath);recipes=h.metadata({'cpu':base})
out=P/'cpu/checks/attempt1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'link.result.json').exists()
dumpbin=Path(base['command'][0]).with_name('dumpbin.exe')
env,_=b.environment(base['command'],[x['path'] for x in base['inputs']],out)
affected=[]
for row in base['inputs']:
    if Path(row['path']).suffix.lower()!='.obj':continue
    result=subprocess.run([str(dumpbin),'/symbols',row['path']],capture_output=True,text=True,env=env,check=True)
    matching=[line for line in result.stdout.splitlines() if 'GroupedFloat8Linear' in line and 'UNDEF' not in line]
    if matching:
        recipe=recipes.get(c.key(row['path']));assert recipe,(row,matching)
        affected.append(dict(object=row,source=recipe['source_path'],recipe=recipe,defined_symbols=matching))
c.save(out/'old-descriptor-owner-audit.json',dict(method='dumpbin /symbols actual explicit objects; defined GroupedFloat8Linear only, not all model_ops.h includes',
    baseline=b.identity(basepath),affected=affected,objects_scanned=sum(Path(x['path']).suffix.lower()=='.obj' for x in base['inputs'])))
replacements={};fresh=[]
def compile_one(source,recipe,tag,old=None):
    identity_file=out/(tag+'-identity.json')
    if identity_file.exists():
        record=c.read(identity_file)
        assert b.same(record['source']) and b.same(record['object'])
        assert any(c.key(x['path'])==c.key(R/'include/hyle/compute/model_ops.h') and
                   x['sha256']==b.identity(R/'include/hyle/compute/model_ops.h')['sha256'] for x in record['dependencies'])
        fresh.append(record);return record['object']
    command=b.host_command(recipe['command'],source,tag,out)
    environment,_=b.environment(command,[],out)
    c.save(out/(tag+'-plan.json'),dict(command=command,source=b.identity(source),recipe=b.identity(recipe['recipe'])))
    c.execute(tag,command,environment,out)
    dependency_file=out/(tag+'-deps.json');deps=c.read(dependency_file)['Data'];obj=b.identity(out/(tag+'.obj'))
    record=dict(command=command,source=b.identity(source),object=obj,replaces=old,
      source_dependencies=b.identity(dependency_file),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
    c.save(out/(tag+'-identity.json'),record);fresh.append(record)
    return obj
for index,row in enumerate(affected):
    source=Path(row['source']);old=row['object']
    if source==R/'src/compute_provider_native/torch_cpu_program.cc':
        other=P/'vulkan/checks/products/torch-cpu-identity.json';record=c.read(other)
        assert b.same(record['source']) and c.key(record['replaces']['path'])==c.key(old['path'])
        # The same recipe/SDK was compiled in this wave. Check canonical
        # project content without treating drive/path casing as source drift.
        project=[x for x in record['dependencies'] if c.key(x['path']).startswith(c.key(R)+str(Path('/')))]
        for x in project:
            current=b.identity(x['path']);assert (current['bytes'],current['sha256'])==(x['bytes'],x['sha256'])
        obj=record['object'];assert b.same(obj)
        c.save(out/'reused-torch.json',dict(identity=b.identity(other),object=obj,replaces=old,
            checked_project_dependencies=len(project),SDK_source='Unchanged actual recipe and this-wave SDK compile, not rebuilt or rescanned.'))
    else:obj=compile_one(source,row['recipe'],'affected'+str(index),old)
    replacements[c.key(old['path'])]=obj
previous=R/'tests/graph_route_cpu/fp8_channel_token_qdq_test.cc'
matches=[recipes[c.key(x['path'])] for x in base['inputs'] if c.key(recipes.get(c.key(x['path']),{}).get('source_path',''))==c.key(previous)]
assert len(matches)==1
test=compile_one(R/'tests/graph_route_cpu/grouped_fp8_power2_test.cc',matches[0],'power-test')
command=[replacements.get(c.key(x),{}).get('path',x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'cpu.exe';command.insert(1,test['path']);command.extend(['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))])
inputs=[test,*[replacements.get(c.key(x['path']),x) for x in base['inputs']]]
assert all(b.same(x) for x in inputs)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replaced=len(replacements),SDK_builds=0,GPU_runs=0))
environment,runtime=b.environment(command,[x['path'] for x in inputs],out)
c.save(out/'runtime-environment.json',dict(PATH=environment['PATH'],runtime=runtime))
c.execute('link',command,environment,out);c.save(out/'image.json',b.identity(image))
c.save(out/'summary.json',dict(CXX=len(fresh),reused_products=1,affected_definition_owners=len(affected),
    unchanged_link_inputs=len(base['inputs'])-len(replacements),SDK_builds=0,GPU_runs=0))
print(out/'link-plan.json')
