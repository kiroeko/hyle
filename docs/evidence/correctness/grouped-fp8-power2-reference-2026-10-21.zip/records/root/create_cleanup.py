from pathlib import Path
P=Path(__file__).resolve().parents[1]
s=(P.parent/'ct-bf16-block128-reference/root/prepare_cleanup.py').read_text()
s=s.replace('ct-bf16-block128-reference','grouped-fp8-power2-reference').replace('Exact CT BF16 block128','Exact grouped FP8 power2')
before="""m1=read(P/'apple/cleanup-readonly-inventory.json');m2=read(P/'apple/activation-edges/cleanup-readonly-inventory.json')
mac_remove=m1['removable_files']+m2['deletable_files'];mac_keep=m1['retain_objects']+m2['retain_small_objects']"""
after="""m=read(P/'apple/cleanup-readonly-inventory.json')
mac_base=m['remote']
mac_remove=m['deletable_files'];mac_keep=m['retain_small_objects']"""
assert before in s
s=s.replace(before,after).replace('$result | Select-Object completed','[pscustomobject]$result | Select-Object completed')
(P/'root/prepare_cleanup.py').write_text(s,encoding='utf8')
