from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
windows=[('CPU new, None and schema','cpu/validation/attempt1/receipt.json',None),
 ('CUDA original neighbors','cuda/validation/attempt1/receipt.json',
  ['CudaGroupedFp8.RuntimeSlotsAndExactRowsDirect','CudaGroupedFp8.RuntimeSlotsAndExactRowsGraph',
   'CudaGroupedFp8.CheckedIdsFailCompletionAndFreshInvocationRecovers','CudaGroupedFp8.ZeroCodesAndFiniteScalesKeepZeroProducts',
   'CudaGroupedFp8ScaleOrder.ZeroCodesAndFiniteScalesKeepZeroProducts',
   'CudaFp8SharedPrologue.PowerOfTwoBfloatSiblingsKeepTheirOriginalScaleLayoutAcrossCapturedSlots']),
 ('CUDA new power2','cuda/validation/attempt2/receipt.json',None),
 ('CUDA F32 power prepare decline','cuda/validation/attempt3/receipt.json',None),
 ('Vulkan new and None after scale fix','vulkan/validation/attempt2/receipt.json',None)]
names=set();records=[]
for label,relative,selected in windows:
 p=P/relative;d=read(p);failed={x['classname']+'.'+x['name'] for x in d['failed']}
 assert not d['skipped']
 if selected is None:assert d['passed'];selected=d['names']
 assert set(selected)<=set(d['names']) and not set(selected)&failed
 names.update(selected);records.append(dict(label=label,receipt=identity(p),green_names=selected,original_failed_names=sorted(failed)))
apple_path=P/'apple/final-validation.json';apple=read(apple_path)
# The Apple owner reports exact XML names and counters; use its actual shape.
apple_runs=apple.get('validation',apple)
apple_names=apple_runs.get('names') or apple.get('names') or [x['name'] for x in apple.get('cases',[])]
assert apple_names,apple.keys()
assert not apple_runs.get('failed') and not apple_runs.get('skipped')
names.update(apple_names)
new={n for n in names if 'GroupedFp8Power2' in n and 'DefaultNone' not in n}
assert len(new)==9 and len(names)==19,(len(new),len(names),sorted(names))
sources=['include/hyle/compute/model_ops.h','src/compute_provider_native/torch_cpu_program.cc',
 'src/compute_provider_cuda/grouped_fp8_provider.cc','src/compute_provider_cuda/cuda_provider.cc',
 'src/compute_route_apple/apple_mature_float.cc','src/compute_route_vulkan/vulkan_official.cc',
 'src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_iree.cc',
 'src/compute_provider_iree_vulkan/native_program.h','src/compute_provider_iree_vulkan/native_program.cc',
 'third_party/iree_vulkan_runtime/programs/generate_official.py',
 'third_party/iree_vulkan_runtime/programs/compile_official.py',
 'third_party/iree_vulkan_runtime/programs/official.mlir',
 'third_party/iree_vulkan_runtime/programs/official.vmfb.b64',
 'third_party/iree_vulkan_runtime/programs/manifest.json','cmake/HyleDependencyLock.json',
 'tests/compute_models/grouped_fp8_power2_fixture.h','tests/compute_models/nvfp4_reference_fixture.h',
 'tests/compute_ops/operation_test.cc','tests/compute_provider_native/torch_cpu_test.cc',
 'tests/compute_provider_cuda/grouped_fp8_test.cc']
for arm in ('cpu','cuda','vulkan','apple'):
 sources.extend(f'tests/graph_route_{arm}/{name}' for name in ('grouped_fp8_power2_test.cc','CMakeLists.txt'))
source_ids=[identity(R/s) for s in sources];entries={'source/'+s:R/s for s in sources}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.cuh','.mlir','.b64','.cmake','.spvasm'}:
  relative=p.relative_to(P).as_posix()
  if relative=='root/package-summary.json':continue
  entries['records/'+relative]=p
design=A/'grouped-fp8-power2-2026-10-21/design.json'
entries['research/design.json']=design
archive=R/'docs/evidence/correctness/grouped-fp8-power2-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for n,p in sorted(entries.items()):z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for n,p in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p),n
doc=dict(observed_on='2026-10-21',status='four_backend_bounded_grouped_power2_reference_passed',
 producer_research_evidence='../research/fixed-role-binding-2026-10-21.json',
 producer_contract=read(design)['producer_contract'],fixed_sources=read(design)['fixed_sources'],
 math='F32 absmax max floor, F32 multiply rounded1/448, ceil power2, F32 normalize and E4 SATFINITE RNE; original E4 W/F32 macroblock128 SF, F32 per-group dot then As then Ws and accumulation, final BF16. No BF16 quantization intermediates.',
 public_api='GroupedFloat8Linear{Float8ScaleRounding,floatfloor}8bytes, operation_id suffix0002, factory(enum=kNone,floatfloor=1e-10). No old4byte parsing or float-only overload. kNone default semantics retained.',
 architecture='Original backend plans/Invocation/Completion/checked-ID path. Shared A quantizes once per token; selected encoded experts remain compressed. CUDA reuses existing BF16 colmajor AOT with As strides(1,quant_rows), original workspace size. Vulkan appends private kind without ProgramSpecV4 expansion and reuses existing IREE quantizer; no SDK rebuild.',
 tests=dict(distinct_total=len(names),new_cases=len(new),neighbors=len(names-new),new_names=sorted(new),neighbor_names=sorted(names-new),
   windows=records,apple=identity(apple_path),new_graph_successes=44,new_graph_expected_failed_completions=8,
   counting='Each backend power lifetime8 plus ID recovery3success/2failed; CUDA F32-negative performs zero submissions. None neighbors/schema separate. Temporary diagnostic probes are excluded from19 distinct permanent cases.'),
 failures_retained=['First shared fixture omitted factory.resources for caller-owned result bind; CUDA failed before arithmetic. Four resource setup sites corrected, data/oracle/tolerance unchanged; Apple originally green unaffected.',
   'CPU build helper used path-sensitive identity equality on lower-case compiler dependency paths, then resumed the successful schema object with canonical content checks; no product compile failure.',
   'Vulkan ordinary None neighbor exposed pre-existing FDiv scale450/448 one-F32-ULP error; F32 sparse probe located first error and final normal scale computation uses RN integer /7 decomposition. No tolerance widening.'],
 limits=['Fixed GA producer BF16 activation reference; no publisher numeric tensor payload, whole artifact/model, Linux, quality or performance acceptance.',
   'CUDA power F32 shape is mathematically inferable but native prepare returns Unimplemented; BF16 evidence does not qualify F32 CUDA AOT.',
   'Canonical weight scales are F32 macroblock128; stored E8M0 block128 import is a separate scale-only resource conversion, not UE8M0 group32.',
   'Independent expert working sets, paged E4 KV/compact MLA and unresolved Inferact producer contract remain open.'],
 current_sources=source_ids,archive=dict(**identity(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=identity(archive.with_suffix('.json')),archive=identity(archive),new_cases=len(new),neighbors=len(names-new),members=len(entries))
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
