from pathlib import Path
import hashlib,json,runpy,xml.etree.ElementTree as E
S=Path(__file__).resolve().parent;ROOT=S.parents[3]
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
changed=['src/compute_route_apple/apple_mature_float.cc','tests/graph_route_apple/grouped_fp8_power2_test.cc','tests/graph_route_apple/CMakeLists.txt']
shared=['include/hyle/compute/model_ops.h','src/compute_provider_native/torch_cpu_program.cc','tests/compute_models/grouped_fp8_power2_fixture.h']
for rel in changed:
 p=S/'after'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/rel).read_bytes())
old=(S/'first-pass-fc8b/grouped_fp8_power2_fixture.h').read_text();new=(ROOT/shared[-1]).read_text()
oldcall='.create_invocation()';newcall='.create_invocation({.resources=g::ResourceOptions{}})'
assert old.count(oldcall)==4 and old.replace(oldcall,newcall)==new
save(S/'fixture-mechanical-proof.json',dict(before=identity(S/'first-pass-fc8b/grouped_fp8_power2_fixture.h'),after=identity(ROOT/shared[-1]),occurrences=4,only_difference='Explicit existing ResourceOptions on invocation creation; mathematics, input data, oracle and tolerances unchanged.'))
freeze=dict(owned_sources=[identity(ROOT/rel)for rel in changed],shared_sources=[identity(ROOT/rel)for rel in shared],public_descriptor=dict(bytes=8,revision=2,old4byte_compatibility=False),
 Apple_change='Existing grouped quantize power = four || GroupedFloat8Linear.scale_rounding==kPowerOfTwo; original F32 quantizer, selected packed dot, A1 prequantization and checked completion reused.',
 actual_owner_refresh=['apple_mature_float.cc','torch_cpu_program.cc','new grouped_fp8_power2_test.cc wrapper'],unrelated_header_consumers='Not recompiled; no construction or extraction of this class in other actual linked objects.',SDK_rebuilt=False)
save(S/'source-freeze.json',freeze)
out=S/'mac/remote/results';compiles=json.loads((out/'compile-summary.json').read_text())['compiles']
assert len(compiles)==3 and all(x['exit']==0 and not x['source_drifts']for x in compiles)
manifest=json.loads((S/'mac/source-manifest.json').read_text());assert all(identity(ROOT/x['path'])['sha256']==x['sha256']for x in manifest)
cases=E.parse(out/'tests.xml').getroot().findall('.//testcase');run=json.loads((out/'run.result.json').read_text())
assert len(cases)==3 and not run['exit'] and not any(x.findall('failure')or x.findall('skipped')for x in cases)
validation=dict(source_freeze=identity(S/'source-freeze.json'),fixture_mechanical_proof=identity(S/'fixture-mechanical-proof.json'),source_manifest=identity(S/'mac/source-manifest.json'),canonical_remote_source_count=len(manifest),all_canonical_hashes_match=True,
 compiles=[dict(source=x['source'],object=x['object_identity'],exit=x['exit'],dependency_count=len(x['dependencies']),source_drifts=x['source_drifts'])for x in compiles],actual_commands='mac/remote/results/*command.json',
 link=identity(out/'link.result.json'),run=identity(out/'run.result.json'),gtest=identity(out/'tests.xml'),tests=3,failed=0,skipped=0,
 cases=[dict(name=x.get('classname')+'.'+x.get('name'),properties={p.get('name'):p.get('value')for p in x.findall('./properties/property')})for x in cases],successful_submissions=19,expected_failed_completions=2,
 prior_fixture_first_pass='first-pass-fc8b: original 3-test success retained; final 81d863 fixture wrapper rebuilt and same 3 tests rerun.',
 hardware=identity(S/'mac/remote/hardware.json'),runtime=identity(S/'mac/remote/runtime-identity.json'),performance_claim=False,
 scope=['Finite BF16 A1 and AS T2/S3/K256/N129/E3; two slots, actual content updates and retained outputs.','Independent frexp ceil oracle distinguishes None, incorrect BF16 intermediate and incorrect floor; 446/448/450 plus zero/tiny and negative-zero witnesses.','Checked last ID -1/E fails Completion, results unavailable, failed invocation rejected and fresh invocation recovers.','Default None and grouped4 source behavior retained; this package does not claim whole-model import or throughput.'])
save(S/'final-validation.json',validation)
ssh=runpy.run_path(str(ROOT/'.scratch/architecture-refactor-2026-10-18/batch-query-extent/delegated/apple/validate.py'))['ssh']
remote=json.loads((S/'mac/plan.json').read_text())['remote']
code=r'''
from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['remote'])
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
files=[r/'grouped-fp8-power2',r/'grouped-fp8-power2.map'];objects=sorted((r/'objects').glob('*.o'))
ps=subprocess.run(['ps','-axo','pid=,command='],capture_output=True,text=True)
live=[x for x in ps.stdout.splitlines()if str(r)in x and 'python3 -c'not in x and '/bin/sh -c'not in x]
checks=[]
for f in files:
 if f.is_file():
  p=subprocess.run(['lsof',str(f)],capture_output=True,text=True);checks.append(dict(path=str(f),exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
print(json.dumps(dict(remote=str(r),remote_root_is_symlink=r.is_symlink(),deletable_files=[identity(x)for x in files if x.is_file()and not x.is_symlink()],retain_small_objects=[identity(x)for x in objects],dSYM=[str(x)for x in r.glob('*.dSYM')],process_matches=live,lsof=checks,metallib=dict(path=str(r/'mlx.metallib'),is_symlink=(r/'mlx.metallib').is_symlink(),target=str((r/'mlx.metallib').resolve())),action='Read-only inventory; no removal. Root writes and executes test.ps1.')))
'''
cleanup=ssh(code,dict(remote=remote));save(S/'cleanup-readonly-inventory.json',cleanup)
print(json.dumps(dict(freeze=identity(S/'source-freeze.json'),validation=identity(S/'final-validation.json'),cleanup=identity(S/'cleanup-readonly-inventory.json'),tests=3,deletable_bytes=sum(x['bytes']for x in cleanup['deletable_files']),retained_object_bytes=sum(x['bytes']for x in cleanup['retain_small_objects']),process_matches=cleanup['process_matches'])))
