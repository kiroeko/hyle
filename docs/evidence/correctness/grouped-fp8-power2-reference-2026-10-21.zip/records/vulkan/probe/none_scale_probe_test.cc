#include "tests/compute_route_vulkan/tensor_test_support.h"
#include "hyle/compute/low_precision.h"
#include "hyle/compute/model_ops.h"

TEST(VulkanGroupedFp8NoneProbe, Scale450AndSparseDotExposeFirstRounding) {
  namespace t = vulkan_tensor_test;
  namespace c = t::c;
  auto context = vulkan_test::context().value();
  const auto weight = c::float8_grouped_weight_description(1, 3, 256).value();
  std::vector<std::byte> bank(*weight.required_bytes(), std::byte{0});
  bank[1] = std::byte{0x38};
  bank[256 + 129] = std::byte{0x38};
  bank[512 + 1] = std::byte{0x28};
  bank[512 + 129] = std::byte{0x40};
  const std::array scales{1.F, 1.F};
  std::memcpy(bank.data() + 768, scales.data(), sizeof(scales));
  auto w = context.upload(weight, bank).value();
  std::array<float, 256> input{};
  input[0] = 446.F; input[1] = 1.F / 512.F;
  input[128] = 450.F; input[129] = 1.F / 512.F;
  auto a = context.upload(t::dense(c::DataType::kFloat32, {1, 1, 256}),
      std::as_bytes(std::span(input))).value();
  const std::array<std::int32_t, 1> index{0};
  auto ids = context.upload(t::dense(c::DataType::kInt32, {1, 1}),
      std::as_bytes(std::span(index))).value();
  auto output = t::execute(context, c::model_ops::grouped_float8_linear(),
      std::array{w, a, ids});
  ASSERT_TRUE(output) << output.error().message();
  const auto bytes = t::bytes(context, *output);
  ASSERT_EQ(bytes.size(), 3 * sizeof(float));
  std::array<float, 3> y{};
  std::memcpy(y.data(), bytes.data(), bytes.size());
  RecordProperty("inferred_s446_bits", std::to_string(std::bit_cast<std::uint32_t>(y[0] * 512.F)));
  RecordProperty("inferred_s450_bits", std::to_string(std::bit_cast<std::uint32_t>(y[1] * 512.F)));
  RecordProperty("sparse_sum_bits", std::to_string(std::bit_cast<std::uint32_t>(y[2])));
  RecordProperty("sparse_sum_bf16_if_rne", std::to_string(t::encode(y[2], c::DataType::kBFloat16)));
}
