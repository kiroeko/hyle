from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'grouped-fp8-power2-reference/vulkan';B=A/'ct-bf16-block128-reference/vulkan-batched-matmul/checks/cold-runs/link-plan.json'
C=S/'checks/products';C.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(Path(p).read_bytes())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
env=os.environ.copy();result=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in result.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
tmp=S/'tmp';tmp.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(tmp)
base=read(B)
def recipe_for(obj):
 for p in Path(obj).parent.glob('*identity.json'):
  d=read(p)
  if Path(d.get('object',{}).get('path',''))==Path(obj):return p
 raise AssertionError(obj)
def compile_one(tag,source,old=None,recipe=None,extra=()):
 recipe=recipe or recipe_for(old);command=[];skip=False
 for arg in read(recipe)['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 command+=list(extra)+['/W4','/WX','/sourceDependencies',str(C/(tag+'-deps.json')),str(source),'/Fo'+str(C/(tag+'.obj')),'/Fd'+str(C/(tag+'.pdb'))]
 start=time.time();result=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
 save(C/(tag+'-compile.command.json'),dict(command=command,exit_code=result.returncode,seconds=time.time()-start,cwd=str(R)))
 (C/(tag+'-compile.stdout.txt')).write_text(result.stdout);(C/(tag+'-compile.stderr.txt')).write_text(result.stderr);print(tag,result.returncode,flush=True)
 if result.returncode:raise RuntimeError((result.stdout+result.stderr)[-5000:])
 deps=read(C/(tag+'-deps.json'))['Data'];save(C/(tag+'-identity.json'),dict(command=command,source=identity(source),object=identity(C/(tag+'.obj')),recipe=identity(recipe),replaces=identity(old) if old else None,dependencies=[identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
pairs=[('native-program','src/compute_provider_iree_vulkan/native_program.cc','compute_provider_iree_vulkan-native_program.obj'),('official','src/compute_route_vulkan/vulkan_official.cc','compute_route_vulkan-vulkan_official.obj'),('iree','src/compute_route_vulkan/vulkan_iree.cc','vulkan_iree.obj'),('program','src/compute_route_vulkan/vulkan_program.cc','vulkan_program.obj'),('torch-cpu','src/compute_provider_native/torch_cpu_program.cc','torch-cpu.obj'),('embedded',str(S/'generated/programs.cc'),'embedded-programs.obj')]
if sys.argv[1]=='rne-compile':
 C=S/'checks/none-rne';C.mkdir(parents=True,exist_ok=True)
 old=next(x['path'] for x in base['inputs'] if Path(x['path']).name=='embedded-programs.obj');compile_one('embedded',S/'generated/none-rne/programs.cc',old)
elif sys.argv[1]=='rne-link':
 C=S/'checks/none-rne';prior=read(S/'checks/final2/link-plan.json')
 for x in prior['inputs']:assert identity(x['path'])==x
 old=str(S/'checks/products/embedded.obj');new=str(C/'embedded.obj');assert any(x['path']==old for x in prior['inputs']);command=[new if arg==old else arg for arg in prior['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))];exe=C/'grouped-fp8-power2.exe';command+=['/OUT:'+str(exe),'/MAP:'+str(C/'grouped-fp8-power2.map'),'/IMPLIB:'+str(C/'grouped-fp8-power2.lib')]
 plan=dict(command=command,inputs=[identity(x) for x in command[1:] if Path(x).is_file()],baseline=identity(S/'checks/final2/link-plan.json'),replacements={old:new},unchanged_baseline_inputs=len(prior['inputs'])-1,SDK=0,GPU_by_this_agent=0)
 save(C/'proposed-link-plan.json',plan);start=time.time();result=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace');save(C/'link.command.json',dict(command=command,exit_code=result.returncode,seconds=time.time()-start,cwd=str(R)));(C/'link.stdout.txt').write_text(result.stdout);(C/'link.stderr.txt').write_text(result.stderr);print('rne-link',result.returncode,flush=True)
 if result.returncode:raise RuntimeError((result.stdout+result.stderr)[-5000:])
 plan['executable']=identity(exe);save(C/'link-plan.json',plan)
elif sys.argv[1]=='probe-compile':
 C=S/'probe/checks';C.mkdir(parents=True,exist_ok=True)
 compile_one('none-probe',S/'probe/none_scale_probe_test.cc',recipe=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json',extra=['/I'+str(R)])
elif sys.argv[1]=='probe-link':
 C=S/'probe/checks';prior=read(S/'checks/final2/link-plan.json')
 for x in prior['inputs']:assert identity(x['path'])==x
 command=[arg for arg in prior['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))];command.insert(1,str(C/'none-probe.obj'));exe=C/'none-scale-probe.exe';command+=['/OUT:'+str(exe),'/MAP:'+str(C/'none-scale-probe.map'),'/IMPLIB:'+str(C/'none-scale-probe.lib')]
 plan=dict(command=command,inputs=[identity(x) for x in command[1:] if Path(x).is_file()],baseline=identity(S/'checks/final2/link-plan.json'),unchanged_baseline_inputs=len(prior['inputs']),SDK=0,GPU_by_this_agent=0)
 save(C/'proposed-link-plan.json',plan);start=time.time();result=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace');save(C/'link.command.json',dict(command=command,exit_code=result.returncode,seconds=time.time()-start,cwd=str(R)));(C/'link.stdout.txt').write_text(result.stdout);(C/'link.stderr.txt').write_text(result.stderr);print('probe-link',result.returncode,flush=True)
 if result.returncode:raise RuntimeError((result.stdout+result.stderr)[-5000:])
 plan['executable']=identity(exe);save(C/'link-plan.json',plan)
elif sys.argv[1] in ('test','test2'):
 C=S/('checks/test2' if sys.argv[1]=='test2' else 'checks/test');C.mkdir(parents=True,exist_ok=True)
 compile_one('grouped-power',R/'tests/graph_route_vulkan/grouped_fp8_power2_test.cc',recipe=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
elif sys.argv[1] in ('link','link2'):
 C=S/('checks/final2' if sys.argv[1]=='link2' else 'checks/final');C.mkdir(parents=True,exist_ok=True);replacements={}
 for tag,_,name in pairs:
  old=next(x['path'] for x in base['inputs'] if Path(x['path']).name==name);replacements[old]=str(S/'checks/products'/(tag+'.obj'))
 for x in base['inputs']:assert identity(x['path'])==x
 command=[replacements.get(arg,arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 command.insert(1,str(S/('checks/test2' if sys.argv[1]=='link2' else 'checks/test')/'grouped-power.obj'));exe=C/'grouped-fp8-power2.exe';command+=['/OUT:'+str(exe),'/MAP:'+str(C/'grouped-fp8-power2.map'),'/IMPLIB:'+str(C/'grouped-fp8-power2.lib')]
 plan=dict(command=command,inputs=[identity(x) for x in command[1:] if Path(x).is_file()],baseline=identity(B),replacements=replacements,unchanged_baseline_inputs=len(base['inputs'])-len(replacements),SDK=0,GPU_by_this_agent=0)
 save(C/'proposed-link-plan.json',plan);start=time.time();result=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace');save(C/'link.command.json',dict(command=command,exit_code=result.returncode,seconds=time.time()-start,cwd=str(R)));(C/'link.stdout.txt').write_text(result.stdout);(C/'link.stderr.txt').write_text(result.stderr);print('link',result.returncode,flush=True)
 if result.returncode:raise RuntimeError((result.stdout+result.stderr)[-5000:])
 plan['executable']=identity(exe);save(C/'link-plan.json',plan)
elif sys.argv[1]=='products':
 def one(item):
  tag,source,name=item;old=next(x['path'] for x in base['inputs'] if Path(x['path']).name==name);compile_one(tag,R/source,old)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(one,pairs))
 save(C/'summary.json',dict(CXX_success=len(pairs),NVCC=0,SDK_build=0,GPU=0,objects=[read(C/(tag+'-identity.json'))['object'] for tag,_,_ in pairs]))
else:raise ValueError(sys.argv[1])
