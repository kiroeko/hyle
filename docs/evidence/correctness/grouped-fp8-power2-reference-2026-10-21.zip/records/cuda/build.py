"""Bounded current CUDA owners; never executes an image or GPU."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
BASE = A / 'ct-bf16-block128-reference/cuda-bfloat-binary/checks/attempt1/link-plan.json'
RECIPES = {
    'grouped-provider': A / 'grouped-fp8-scale-order/checks/grouped-provider-identity.json',
    'cuda-provider': A / 'fixed-role-binding-2026-10-21/blockwise-w4a8/cuda/checks/attempt1/cuda-provider/cuda-provider-identity.json',
    'grouped-test': A / 'grouped-fp8-scale-order/checks/grouped-test-identity.json',
    'scale-test': A / 'grouped-fp8-scale-order/reproduction/scale-test-identity.json',
}
HEADER_SHA = '9b756a476355de744b48cad12b72bbcd4239870d7243dc1efdef22fc06204a18'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def compile_owner(name):
    old = read(RECIPES[name])
    out = S / 'checks' / name / 'attempt1'
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'compile-result.json').exists():
        raise RuntimeError('Preserve old attempt; do not overwrite ' + str(out))
    source = Path(old['source']['path'])
    args, skip = [], False
    for arg in old['command']:
        if skip:
            skip = False
            continue
        low = arg.lower()
        if low == '/sourcedependencies':
            skip = True
            continue
        if low.startswith(('/fo', '/fd')):
            continue
        args.append(arg)
    obj, deps = out / (name + '.obj'), out / 'source-dependencies.json'
    args += ['/sourceDependencies', str(deps), '/Fo' + str(obj), '/Fd' + str(out / (name + '.pdb'))]
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': args[0]})
    env['VSLANG'] = '1033'
    tmp = out / 'tmp'
    tmp.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(tmp)
    snapshot = out / 'source.cc'
    snapshot.write_bytes(source.read_bytes())
    plan = {'command': args, 'cwd': str(ROOT), 'source': ident(source),
            'retained_source': ident(snapshot), 'recipe': ident(RECIPES[name]),
            'public_header': ident(ROOT / 'include/hyle/compute/model_ops.h'),
            'started': time.time(), 'SDK_rebuild': False, 'GPU_run': False}
    save(out / 'compile-command.json', plan)
    with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
        result = subprocess.run(args, cwd=ROOT, env=env, stdout=so, stderr=se,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    plan.update(exit=result.returncode, finished=time.time())
    save(out / 'compile-result.json', plan)
    print(name, result.returncode, flush=True)
    if result.returncode:
        print((out / 'stdout.log').read_text(errors='replace')[-7000:], flush=True)
        print((out / 'stderr.log').read_text(errors='replace')[-2000:], flush=True)
        raise RuntimeError(name + ' actual compiler failure')
    assert plan['source'] == ident(source)
    paths = [source] + [Path(p) for p in read(deps)['Data']['Includes']]
    plan.update(object=ident(obj), old_object=old['object'],
                dependency_file=ident(deps),
                dependencies=[ident(p) for p in dict.fromkeys(paths)])
    save(out / 'identity.json', plan)
    return plan


def main():
    assert ident(ROOT / 'include/hyle/compute/model_ops.h')['sha256'] == HEADER_SHA
    source_freeze = read(S / 'source-freeze.json')
    for row in source_freeze['sources'] + source_freeze['AOT_unchanged']:
        assert ident(row['path']) == row
    source_freeze['public_header_not_yet_frozen'] = False
    source_freeze['public_header'] = ident(ROOT / 'include/hyle/compute/model_ops.h')
    save(S / 'source-freeze.json', source_freeze)
    mode = sys.argv[1] if len(sys.argv) > 1 else 'products'
    names = ['grouped-provider', 'cuda-provider'] if mode == 'products' else ['grouped-test', 'scale-test']
    assert mode in ('products', 'old-tests')
    base = read(BASE)
    base_paths = {r['path'].lower() for r in base['inputs']}
    for name in RECIPES:
        assert read(RECIPES[name])['object']['path'].lower() in base_paths
    save(S / 'owner-inventory.json', {
        'actual_base': ident(BASE), 'base_inputs': len(base['inputs']),
        'refresh': [{'source': read(recipe)['source'], 'old_object': read(recipe)['object'],
                     'actual_recipe': ident(recipe), 'reason': 'New 8-byte revision2 constructor/extractor' if 'test' in name or name == 'cuda-provider' else 'New policy and matching scale strides'}
                    for name, recipe in RECIPES.items()],
        'new_fixture_wrapper': 'Root will provide a new Graph CUDA test owner; add after its freeze.',
        'not_linked': ['src/compute_provider_native/torch_cpu_program.cc',
                       'tests/compute_provider_cuda/cuda_provider_test.cc',
                       'tests/compute_ops/operation_test.cc',
                       'tests/compute_provider_native/torch_cpu_test.cc',
                       'tests/compute_route_cuda/d5_qwen38_official_test.cc',
                       'tests/graph_route_cuda/d5_qwen38_official_test.cc'],
        'shared_schema': 'GroupedFloat8Linear output inference is inline in model_ops.h. No Grouped8 definition/extractor exists in weight_decode.cc; its unchanged existing object is retained, not rebuilt for a public include alone.',
        'method': 'Bounded exact class/factory caller inventory intersected with actual linked objects and retained identity source owners. No blanket public-header refresh or SDK build.'})
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(compile_owner, names))
    save(S / 'checks' / (mode + '-summary.json'), {
        'CXX': len(rows), 'NVCC': 0, 'links': 0, 'SDK_rebuilds': 0, 'GPU_runs': 0,
        'objects': [r['object'] for r in rows],
        'identities': [ident(S / 'checks' / name / 'attempt1/identity.json') for name in names]})


if __name__ == '__main__':
    main()
