#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <span>
#include <string>
#include <vector>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/low_precision.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/cuda.h"

namespace {
namespace c = hyle::compute;
namespace m = hyle::mem;

struct Tensor final {
  m::Buffer owner;
  c::TensorView view;
  Tensor(c::TensorDesc description, m::MemoryResourceRef resource)
      : owner(m::Buffer::create(resource, description.required_bytes().value(),
                                256).value()),
        view(c::TensorView::create(description, owner.view()).value()) {}
  template <class T> void write(const std::vector<T> &values) {
    const auto status = view.storage().write(std::as_bytes(std::span(values)));
    ASSERT_TRUE(status.ok()) << status.message();
  }
  std::vector<float> read() const {
    const auto count = view.description().element_count().value();
    std::vector<float> result(count);
    if (view.description().data_type() == c::DataType::kFloat32) {
      const auto status = view.storage().read(std::as_writable_bytes(std::span(result)));
      EXPECT_TRUE(status.ok()) << status.message();
    } else {
      std::vector<std::uint16_t> raw(count);
      const auto status = view.storage().read(std::as_writable_bytes(std::span(raw)));
      EXPECT_TRUE(status.ok()) << status.message();
      std::transform(raw.begin(), raw.end(), result.begin(), [](std::uint16_t value) {
        return std::bit_cast<float>(std::uint32_t(value) << 16);
      });
    }
    return result;
  }
};

// This is a semantic witness, not a tolerance comparison with the product
// quantizer or a second invocation of the same GPU implementation. Every
// encoded weight is positive zero, so its real scaled value is exactly zero.
// A=896 and As=896/448=2 are exact in F32/BF16/E4M3FN after quantization.
TEST(CudaGroupedFp8ScaleOrder, ZeroCodesAndFiniteScalesKeepZeroProducts) {
  const float weight_scale = std::ldexp(1.0F, 127);
  const float activation_scale = 896.0F / 448.0F;
  ASSERT_TRUE(std::isfinite(weight_scale));
  ASSERT_EQ(activation_scale, 2.0F);
  volatile float dot = 0.0F;
  volatile float scaled_dot = dot * activation_scale;
  volatile float sequential_result = scaled_dot * weight_scale;
  volatile float combined_scale = activation_scale * weight_scale;
  volatile float prescaled_result = dot * combined_scale;
  ASSERT_EQ(sequential_result, 0.0F);
  ASSERT_TRUE(std::isinf(combined_scale));
  ASSERT_TRUE(std::isnan(prescaled_result));

  auto context = c::Context::create(c::cuda::device(0).value(),
                                   c::cuda_native::sglang_provider()).value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto queue = context.create_queue().value();
  constexpr std::int64_t e = 1, n = 128, k = 128;
  for (const auto type : {c::DataType::kFloat32, c::DataType::kBFloat16}) {
    const bool bfloat = type == c::DataType::kBFloat16;
    const std::string label = bfloat ? "bf16" : "f32";
    SCOPED_TRACE(label);
    const std::array descriptions{
        c::float8_grouped_weight_description(e, n, k).value(),
        c::TensorDesc::dense(type, std::array<std::int64_t, 3>{1, 1, k}).value(),
        c::TensorDesc::dense(c::DataType::kInt32,
                             std::array<std::int64_t, 2>{1, 1}).value()};
    const auto operation = c::model_ops::grouped_float8_linear();
    auto inferred = c::infer_single_output(operation, descriptions);
    ASSERT_TRUE(inferred) << inferred.error().message();
    const auto output_description = *inferred;
    Tensor weights(descriptions[0], memory.ref());
    Tensor activation(descriptions[1], memory.ref());
    Tensor ids(descriptions[2], memory.ref());
    Tensor output(output_description, memory.ref());
    const auto payload = static_cast<std::size_t>(e * n * k);
    std::vector<std::byte> encoded(descriptions[0].required_bytes().value(), std::byte{0});
    ASSERT_EQ(encoded.size(), payload + sizeof(float));
    std::memcpy(encoded.data() + payload, &weight_scale, sizeof(weight_scale));
    weights.write(encoded);
    if (bfloat) {
      std::vector<std::uint16_t> values(static_cast<std::size_t>(k), 0);
      const auto bits = std::bit_cast<std::uint32_t>(896.0F);
      ASSERT_EQ(bits & 0xffffU, 0U);
      values[0] = static_cast<std::uint16_t>(bits >> 16);
      activation.write(values);
    } else {
      std::vector<float> values(static_cast<std::size_t>(k), 0.0F);
      values[0] = 896.0F;
      activation.write(values);
    }
    ids.write(std::vector<std::int32_t>{0});
    auto prepared = c::prepare(context, operation, descriptions,
                               std::array{output_description}, memory.ref());
    ASSERT_TRUE(prepared) << prepared.error().message();
    EXPECT_EQ(prepared->provider().id, c::cuda_native::kSglangProviderId);
    const auto need = prepared->workspace_requirement();
    auto workspace = m::Buffer::create(memory.ref(), need.size, need.alignment).value();
    auto invocation = prepared->create_invocation(workspace.view()).value();
    const std::array inputs{weights.view.as_const(), activation.view.as_const(),
                            ids.view.as_const()};
    auto submitted = invocation.submit(queue, inputs, std::array{output.view});
    ASSERT_TRUE(submitted) << submitted.error().message();
    const auto status = submitted->wait();
    ASSERT_TRUE(status.ok()) << status.message();
    const auto actual = output.read();
    ASSERT_EQ(actual.size(), static_cast<std::size_t>(n));
    int nan_count = 0, infinite_count = 0, finite_nonzero_count = 0;
    for (const auto value : actual) {
      if (std::isnan(value)) ++nan_count;
      else if (std::isinf(value)) ++infinite_count;
      else if (value != sequential_result) ++finite_nonzero_count;
    }
    RecordProperty(label + "_nan_count", nan_count);
    RecordProperty(label + "_infinite_count", infinite_count);
    RecordProperty(label + "_finite_nonzero_count", finite_nonzero_count);
    RecordProperty(label + "_first_f32_bits",
                   std::to_string(std::bit_cast<std::uint32_t>(actual.front())));
    EXPECT_EQ(nan_count, 0) << "Finite input and finite scaled zero weights produced NaN";
    EXPECT_EQ(infinite_count, 0);
    EXPECT_EQ(finite_nonzero_count, 0);
  }
}
} // namespace
