"""Scoped CUDA source change and retained before/after; no build or GPU."""
from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
A = ROOT / '.scratch/architecture-refactor-2026-10-18'


def ident(path):
    p = Path(path).resolve()
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


owners = ['src/compute_provider_cuda/grouped_fp8_provider.cc',
          'src/compute_provider_cuda/cuda_provider.cc']
before = []
for name in owners:
    source = ROOT / name
    snapshot = S / 'before' / name
    assert not snapshot.exists(), 'Do not overwrite the original before snapshot'
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    before.append(ident(source))
save(S / 'before.json', before)
path = ROOT / owners[0]
raw = path.read_bytes()
newline = '\r\n' if b'\r\n' in raw else '\n'
text = raw.decode('utf-8').replace('\r\n', '\n')


def replace(old, new):
    global text
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)


replace('#include "fp8/sglang_fp8_quantize_cuda_sm89.h"',
        '#include "fp8/sglang_fp8_quantize_cuda_sm89.h"\n#include "fp8/sglang_fp8_dynamic_sm89.h"')
replace('  bool bfloat, small;', '  bool bfloat, small, power2;')
replace('  s.quant_groups = 16;\n  while ((s.rows * (s.k / 128)) % s.quant_groups) s.quant_groups /= 2;\n  s.bfloat = a.data_type() == DataType::kBFloat16;',
        '  s.bfloat = a.data_type() == DataType::kBFloat16;\n'
        '  s.power2 = op->scale_rounding == model_ops::Float8ScaleRounding::kPowerOfTwo;\n'
        '  if (s.power2 && !s.bfloat)\n'
        '    return std::unexpected(Status::Unimplemented(\n'
        '        "grouped FP8 power-of-two activation scales are qualified for BF16 input"));\n'
        '  s.quant_groups = s.power2 ? 1 : 16;\n'
        '  while ((s.rows * (s.k / 128)) % s.quant_groups) s.quant_groups /= 2;')
replace('  auto result = launch(p.quant, unsigned(groups / per_block), unsigned(per_block * 16), 0, quant);',
        '  std::array<CUdeviceptr, 2> scratch{};\n'
        '  int columns = s.k, scale_stride = s.rows;\n'
        '  if (s.power2) {\n'
        '    // Reuse the unchanged BF16 pow2 AOT ABI; scales are col-major.\n'
        '    quant[4] = &columns;\n'
        '    quant[5] = &scale_stride;\n'
        '    quant[9] = &scratch[0];\n'
        '    quant[10] = &scratch[1];\n'
        '  }\n'
        '  auto result = launch(p.quant, unsigned(groups / per_block),\n'
        '                       s.power2 ? 32u : unsigned(per_block * 16), 0, quant);')
replace('      0, 0, s.n, 1, s.k / 128, 1, (s.n / 128 + (s.n % 128 != 0)) * (s.k / 128), 1, s.k / 128,',
        '      0, 0, s.n, 1, s.power2 ? 1 : s.k / 128, s.power2 ? s.rows : 1,\n'
        '      (s.n / 128 + (s.n % 128 != 0)) * (s.k / 128), 1, s.k / 128,')
replace('  auto result = load(p->modules[0], fp8::kSglangFp8QuantizeCuda, p->quant,\n      shape->bfloat ? fp8::kSglangFp8QuantizeBf16Name : fp8::kSglangFp8QuantizeF32Name);',
        '  auto result = load(p->modules[0],\n'
        '      shape->power2 ? fp8::kSglangFp8QuantizeBf16Pow2 : fp8::kSglangFp8QuantizeCuda,\n'
        '      p->quant, shape->power2 ? "_per_token_group_quant_8bit_colmajor"\n'
        '      : shape->bfloat ? fp8::kSglangFp8QuantizeBf16Name : fp8::kSglangFp8QuantizeF32Name);')
path.write_bytes(text.replace('\n', newline).encode('utf-8'))
diff = []
for name in owners:
    source = ROOT / name
    old = S / 'before' / name
    after = S / 'after' / name
    after.parent.mkdir(parents=True, exist_ok=True)
    after.write_bytes(source.read_bytes())
    diff.extend(difflib.unified_diff(old.read_text().splitlines(True), source.read_text().splitlines(True),
                                     fromfile='before/' + name, tofile='after/' + name))
(S / 'implementation.diff').write_text(''.join(diff), encoding='utf-8')
save(S / 'source-freeze.json', {
    'sources': [ident(ROOT / name) for name in owners],
    'product_edits': [owners[0]], 'ABI_only_recompile': [owners[1]],
    'public_header_not_yet_frozen': True,
    'AOT_unchanged': [ident(ROOT / name) for name in (
        'third_party/sglang_activation/fp8/sglang_fp8_dynamic_sm89.h',
        'third_party/sglang_activation/fp8/dynamic-compilation.json',
        'third_party/sglang_activation/fp8/grouped/sglang_grouped_fp8_sm89.h',
        'third_party/sglang_activation/fp8/grouped/compilation.json')],
    'SDK_rebuild': False, 'GPU_run': False})
save(S / 'design.json', {
    'domain': 'Existing exact GroupedFloat8Linear dense A[T,1|S,K], original E4/F32 macroblock128 W[E,N,K], I32 IDs[T,S]. Existing indexing, packed weights, output types, alias and permission/capture domain retained.',
    'new_policy': 'kPowerOfTwo BF16 only. F32 power declines cold with Unimplemented, matching existing dense FP8 AOT qualification. kNone remains original BF16/F32 row-major quantizer.',
    'quantizer': 'Unchanged kSglangFp8QuantizeBf16Pow2; one K128 group per 32-thread CTA. Arguments after pointers are group128,K,quant_rows,floor,-448,448,nullscratch,nullscratch. Quant rows=T for A1, T*S for per-slot A.',
    'scale_layout': 'Same workspace byte count. Power S is physical strides (1,quant_rows), ordinary S stays (K/128,1). GEMM stride_asm/stride_ask are updated together; no transpose/copy/extra allocation.',
    'preserved': 'All original checked-align/sort/status/Invocation/GEMM/queue/capture semantics and kNone arithmetic remain unchanged.',
    'implementation_owners': owners,
    'compile_gate': 'Wait for root public descriptor/revision2 and fixture freeze. Refresh actual linked constructors/extractors only, not every public-header includer.'})
print(json.dumps({'freeze': ident(S / 'source-freeze.json'), 'edited': ident(path)}, indent=2))
