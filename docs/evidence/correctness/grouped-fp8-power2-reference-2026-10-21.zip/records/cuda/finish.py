"""Compile the one new wrapper and link current 8-byte Grouped8 closure; no GPU."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
BASE = A / 'ct-bf16-block128-reference/cuda-bfloat-binary/checks/attempt1/link-plan.json'
ATTEMPT = sys.argv[2] if len(sys.argv) > 2 else 'attempt1'
assert ATTEMPT in ('attempt1', 'attempt2', 'attempt3')
OUT = S / 'checks/new-wrapper' / ATTEMPT


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    p = Path(path).resolve()
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    expected_fixture = sys.argv[1]
    fixture = ROOT / 'tests/compute_models/grouped_fp8_power2_fixture.h'
    assert ident(fixture)['sha256'] == expected_fixture
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / 'compile-result.json').exists(), 'Keep old attempts, do not overwrite'
    old_path = A / 'grouped-fp8-scale-order/checks/grouped-test-identity.json'
    old = read(old_path)
    source = ROOT / 'tests/graph_route_cuda/grouped_fp8_power2_test.cc'
    source_id, fixture_id = ident(source), ident(fixture)
    source_snapshot = S / 'after/tests/graph_route_cuda/grouped_fp8_power2_test.cc'
    source_snapshot.parent.mkdir(parents=True, exist_ok=True)
    source_snapshot.write_bytes(source.read_bytes())
    args, skip = [], False
    for arg in old['command']:
        if skip:
            skip = False
            continue
        low = arg.lower()
        if low == '/sourcedependencies':
            skip = True
            continue
        if low.startswith(('/fo', '/fd')) or arg == old['source']['path']:
            continue
        args.append(arg)
    deps, obj = OUT / 'source-dependencies.json', OUT / 'power-test.obj'
    args += [str(source), '/sourceDependencies', str(deps), '/Fo' + str(obj), '/Fd' + str(OUT / 'power-test.pdb')]
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': args[0]})
    env['VSLANG'] = '1033'
    tmp = OUT / 'tmp'
    tmp.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(tmp)

    def run(name, command):
        row = {'command': command, 'cwd': str(ROOT), 'started': time.time(),
               'GPU_run': False, 'SDK_rebuild': False}
        save(OUT / (name + '-command.json'), row)
        with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=so, stderr=se,
                                    creationflags=subprocess.CREATE_NO_WINDOW)
        row.update(exit=result.returncode, finished=time.time())
        save(OUT / (name + '-result.json'), row)
        print(name, result.returncode, flush=True)
        if result.returncode:
            print((OUT / (name + '.stdout.log')).read_text(errors='replace')[-7000:], flush=True)
            print((OUT / (name + '.stderr.log')).read_text(errors='replace')[-3000:], flush=True)
            raise RuntimeError(name + ' failed')

    save(OUT / 'new-owner-command-origin.json', {
        'retained_compatible_test_recipe': ident(old_path),
        'current_target': ident(ROOT / 'tests/graph_route_cuda/CMakeLists.txt'),
        'new_source': source_id,
        'note': 'New owner command reuses retained MSVC/CRT/flags/includes from actual grouped Direct+Graph test recipe. Its CMake registration uses existing graph_route_cuda target; not claimed to be a historical recipe for this new file.'})
    run('compile', args)
    assert source_id == ident(source) and fixture_id == ident(fixture)
    dependency_paths = [source] + [Path(p) for p in read(deps)['Data']['Includes']]
    save(OUT / 'identity.json', {'command': args, 'source': source_id, 'fixture': fixture_id,
        'object': ident(obj), 'dependency_file': ident(deps),
        'dependencies': [ident(p) for p in dict.fromkeys(dependency_paths)]})
    base = read(BASE)
    replacements = {}
    rows = []
    for name in ('grouped-provider', 'cuda-provider', 'grouped-test', 'scale-test'):
        owner = read(S / 'checks' / name / 'attempt1/identity.json')
        assert ident(owner['source']['path']) == owner['source']
        assert ident(owner['object']['path']) == owner['object']
        replacements[owner['old_object']['path'].lower()] = owner['object']
        rows.append({'old': owner['old_object'], 'new': owner['object'],
                     'identity': ident(S / 'checks' / name / 'attempt1/identity.json')})
    inputs = [ident(obj)]
    for row in base['inputs']:
        current = replacements.get(row['path'].lower(), row)
        assert ident(current['path']) == current, 'Input drift: ' + current['path']
        inputs.append(current)
    assert len(replacements) == 4
    replaced = set()
    args = [base['command'][0], str(obj)]
    for arg in base['command'][1:]:
        if arg.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:')):
            continue
        if arg.lower() in replacements:
            replaced.add(arg.lower())
            arg = replacements[arg.lower()]['path']
        args.append(arg)
    assert replaced == set(replacements)
    image = OUT / 'cuda.exe'
    args += ['/OUT:' + str(image), '/PDB:' + str(OUT / 'cuda.pdb'), '/MAP:' + str(OUT / 'cuda.map')]
    save(OUT / 'link-plan.json', {'command': args, 'inputs': inputs, 'base': ident(BASE),
        'replacements': rows, 'new_wrapper': ident(OUT / 'identity.json'),
        'ABI': 'All actual linked GroupedFloat8Linear constructors/extractors refreshed to8B/revision2. Inline infer only; unchanged weight_decode object retained.',
        'SDK_rebuild': False, 'GPU_run': False})
    run('link', args)
    cmake = ROOT / 'tests/graph_route_cuda/CMakeLists.txt'
    cmake_snapshot = S / 'after/tests/graph_route_cuda/CMakeLists.txt'
    cmake_snapshot.write_bytes(cmake.read_bytes())
    (S / 'wrapper-and-cmake.diff').write_text(''.join(difflib.unified_diff(
        (S / 'before/tests/graph_route_cuda/CMakeLists.txt').read_text().splitlines(True),
        cmake.read_text().splitlines(True), fromfile='before/tests/graph_route_cuda/CMakeLists.txt',
        tofile='after/tests/graph_route_cuda/CMakeLists.txt')), encoding='utf-8')
    save(S / 'final-source-freeze.json', {
        'sources': [ident(ROOT / name) for name in (
            'include/hyle/compute/model_ops.h', 'src/compute_provider_cuda/grouped_fp8_provider.cc',
            'src/compute_provider_cuda/cuda_provider.cc', 'tests/graph_route_cuda/grouped_fp8_power2_test.cc',
            'tests/graph_route_cuda/CMakeLists.txt', 'tests/compute_models/grouped_fp8_power2_fixture.h',
            'tests/compute_provider_cuda/grouped_fp8_test.cc')],
        'retained_scratch_regression': read(S / 'checks/scale-test/attempt1/identity.json')['source'],
        'AOT_unchanged': read(S / 'source-freeze.json')['AOT_unchanged'],
        'no_new_public_or_provider_ABI': 'Only root-owned public Grouped8 numerical descriptor intentionally revised4B->8B/ID2. No Queue/Plan/Invocation/provider ABI or native AOT interface changed.'})
    attempt_number = int(ATTEMPT.removeprefix('attempt'))
    save(OUT / 'summary.json', {'CXX_this_stage': 1, 'CXX_total_this_agent': 4 + attempt_number,
        'NVCC': 0, 'links_this_stage': 1, 'links_total_this_agent': attempt_number,
        'SDK_rebuilds': 0, 'GPU_runs': 0,
        'image': ident(image), 'link_plan': ident(OUT / 'link-plan.json'),
        'actual_link_inputs': len(inputs),
        'root_run_filter': 'CudaGroupedFp8Power2Graph.*:CudaGroupedFp8.*:CudaGroupedFp8ScaleOrder.ZeroCodesAndFiniteScalesKeepZeroProducts:CudaFp8SharedPrologue.PowerOfTwoBfloatSiblingsKeepTheirOriginalScaleLayoutAcrossCapturedSlots',
        'no_execution_claim': 'Root owns actual GPU run. This stage only compiles/links.'})
    print(json.dumps(read(OUT / 'summary.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()
