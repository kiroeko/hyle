from pathlib import Path
import json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
s=read(W/'summary-draft.json');assert s['status']=='FINITE_CHECKS_PASSED'
s['cleanup']=read(W/'cleanup-report.json')
s['architecture_conclusion']={'status':'DEFINED_COMMON_ARCHITECTURE_RESPONSIBILITIES_COMPLETED',
'basis':'Joint actual-call-path review, original common-step/cross-pump/synchronous/publication evidence, six bridge checks and the real unpublished-candidate observer failure regression.',
'scope':'Current single-machine shared execution contracts and runnable original components. Not a second complete engine, GLM cross-pump, arbitrary models/platforms or multi-device implementation.',
'full_goal_status':'active', 'next':'Ordinary/MTP performance causes and improvements, GPU hotspots and complete consumer comparisons; no new full performance window in these two slices.'}
text=json.dumps(s,ensure_ascii=False,indent=2)+'\n'
(W/'summary.json').write_bytes(text.encode())
dest=R/'docs/evidence/correctness';(dest/'inference-glm-candidate-failure-2026-10-30.json').write_bytes(text.encode())
with zipfile.ZipFile(dest/'inference-glm-candidate-failure-2026-10-30.zip','w',compression=zipfile.ZIP_DEFLATED) as out:
 with zipfile.ZipFile(W/'evidence-draft.zip') as prev:
  for item in prev.infolist():out.writestr(item,prev.read(item.filename))
 for name in ['summary.json','finish.py','cleanup.ps1','cleanup-targets.json','cleanup-report.json']:out.write(W/name,name)
print('Archived candidate failure regression, joint architecture audit and exact cleanup')
