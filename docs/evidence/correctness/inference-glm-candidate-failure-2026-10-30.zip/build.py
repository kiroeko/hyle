"""One finite GLM failure-path check, original owners and unchanged SDK."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('bridge',R/'.scratch/inference-request-bridges-20261030/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=b.s.W=b.s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
BASE=R/'.scratch/inference-request-bridges-20261030/model-link-base.json'

def prepare():
    assert not (W/'plan.json').exists()
    base=read(BASE);prior=read(BASE.parent/'plan.json')
    for item in [*base['retained'],base['runtime']]:exact(item)
    # Only a test consumer changes; no SDK or engine implementation rebuild.
    changed=subprocess.check_output(['git','diff','--name-only','--','include','src','engine'],cwd=R,text=True).splitlines()
    assert not changed,changed
    cli=read(base['current_consumers']['cli']['receipt']['path'])
    consumer=dict(prior['consumers']['glm'],compile=b.s.relocated(prior['consumers']['glm']['compile'],'glm'))
    (W/'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    save(W/'plan.json',dict(base=pin(BASE),base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        retained=base['retained'],runtime=base['runtime'],original_link=base['link'],original_consumer=cli['object']['path'],
        units={},consumers={'glm':consumer},sdk=base['sdk_engine_dependencies'],SDK_CXX=0,NVCC=0,downloads=0,max_compilers=1,
        cases={},glm_environment=prior['glm_environment'],glm_cases={'request-cuda':prior['glm_cases']['request-cuda']}))
    print('Prepared one GLM consumer; unchanged SDK; zero SDK CXX/NVCC/downloads.',flush=True)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':b.compile_group(sys.argv[2],sys.argv[3:])
    elif action=='link':b.link(sys.argv[2],sys.argv[3])
    elif action=='run':b.run(sys.argv[2],sys.argv[3])
    else:raise ValueError(action)
