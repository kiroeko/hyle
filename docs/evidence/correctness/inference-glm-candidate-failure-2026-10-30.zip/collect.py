"""Collect one existing original GLM observer-failure run; no native execution."""
from pathlib import Path
import hashlib,json,subprocess,zipfile

W=Path(__file__).resolve().parent;R=W.parents[1]
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def pin(path):
 path=Path(path).resolve();data=path.read_bytes()
 return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def exact(value):assert pin(value['path'])==value,value['path']

plan=read(W/'plan.json');exact(plan['base'])
for item in [*plan['retained'],plan['runtime']]:exact(item)
receipt_path=W/'compile/glm/receipt.json';receipt=read(receipt_path)
for item in [receipt['object'],receipt['process'],receipt['dependencies'],*receipt['source_identities']]:exact(item)
compile_process=read(receipt['process']['path']);link_process=read(W/'link/glm/attempt1/process.json')
for process in [compile_process,link_process]:
 assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
base=read(plan['base']['path']);prior_glm=base['current_consumers']['glm']
base['base']=plan['base'];base['historical_consumers']['glm-request-bridges']=prior_glm
base['current_consumers']['glm']=dict(receipt=pin(receipt_path),object=receipt['object'])
base['note']='One new original GLM test consumer adds an unpublished candidate observer refusal/retry. CLI, main consumers and227 retained SDK inputs remain current and unchanged; no implementation, SDK or NVCC rebuild.'
save(W/'model-link-base.json',base)

previous=R/'.scratch/inference-request-bridges-20261030/runs/request-cuda/attempt1/report.json'
old=read(previous)['cases'][0]['properties'];assert len(old)==53
added={
 'request_candidate_observer_refusals':'1',
 'request_candidate_retired_unpublished_cleanup':'1',
 'request_candidate_refusal_native_submissions':'6',
 'request_candidate_refusal_reproposal_submissions':'0',
 'request_candidate_refusal_head_publications':'0',
 'request_candidate_refusal_committed_rng_draws':'0'}
expected_changed={
 'actual_nextn_steps':str(int(old['actual_nextn_steps'])+1),
 'actual_target_calls':str(int(old['actual_target_calls'])+1),
 'actual_target_submissions':str(int(old['actual_target_submissions'])+2),
 'request_progress_scope':'Shared RequestProgress with the actual grant applied to the selected K1 prefix and new-request cache fork, then the two original ordinary continuations. Each finite turn has quota1; actual model selector/EOS facts are preserved. A later empty new-user suffix consumes only its actual historical pending. The injected unpublished-candidate observer refusal executes verification once more with the original proposal and RNG identities; it adds no Head publication, committed RNG draw, complete GLM prompt prefill or request server.',
 'scope':'Finite original target77+NextN78 natural K1 plus one unpublished-candidate observer refusal/retry and the two-request/two-turn typed directory and FIFO adapter; original request tokens/pending/draw4 unchanged, second request independently resamples and continues actual target+NextN from the complete cached boundary. Previous layer input/residual/upstream74 index selection and initial history remain explicit fixtures. Not arbitrary prompt prefill, full-model generation, task quality, acceptance-rate measurement, TPS or other quantized source coverage.'}
expected=dict(old);expected.update(expected_changed);expected.update(added)
folder=W/'runs/request-cuda/attempt1';checks=[]
comparison=dict(previous=pin(previous),previous_properties=53,expected_current_properties=59,
 added=added,expected_changes={key:dict(previous=old[key],current=value) for key,value in expected_changed.items()},
 matching_unchanged_properties=48,normalization='None; exact comparison of every original53 property plus precisely6 named additions.')
if (folder/'report.json').exists():
 process=read(folder/'process.json');report=read(folder/'report.json')
 assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
 assert report['status']=='PASS' and len(report['cases'])==1
 actual=report['cases'][0]['properties']
 differences={key:dict(expected=expected.get(key),actual=actual.get(key)) for key in expected.keys()|actual.keys() if expected.get(key)!=actual.get(key)}
 comparison.update(actual_properties=len(actual),exact_match=actual==expected,unexpected_differences=differences)
 save(W/'comparison.json',comparison)
 assert actual==expected,differences
 checks.append(dict(name='request-cuda',attempt='attempt1',report=pin(folder/'report.json'),
  command=pin(folder/'command.json'),image=read(folder/'image.json'),process=process))
else:
 comparison.update(exact_match=None,pending=True)
 save(W/'comparison.json',comparison)

source=R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
(W/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','tests/compute_models/glm_pro_mtp_state_consumer_test.cc'],cwd=R))
summary=dict(schema='hyle.inference-glm-candidate-failure.v1',date='2026-10-30',base_commit=plan['base_commit'],
 status='FINITE_CHECKS_PASSED' if checks else 'CHECK_IN_PROGRESS',sources=[pin(source)],checks=checks,comparisons=comparison,
 implementation=[
  'The original stochastic target77/NextN78 RequestLoop K1 branch injects one typed observer failure after its original native work has completed and temporary observation leases have been released.',
  'Existing drive_steps preserves the original typed first error, records actual original Invocation retirement and drops only the unpublished candidate/emitted prefix after retirement.',
  'The native fixture checks original Head identity, complete state image, committed RNG, records and request progress unchanged; StateStore versions/drafts/retained blocks/backing bytes return to their pre-attempt values.',
  'The retry reuses original proposal q and RNG identities, verifies the complete candidate image, emitted IDs, selected prefix and sampled acceptance, then publishes only the original successful result.',
  'The injected verification adds exactly6 native submissions:2 NextN phases,2 target phases,1 verifier and1 decision. It adds no proposal submission, Head publication, repair or committed RNG draw.'],
 model_link_base=pin(W/'model-link-base.json'),
 consumer=dict(receipt=pin(receipt_path),object=receipt['object'],dependencies=receipt['dependencies'],
  compile_process=compile_process,link_process=link_process),
 build=dict(consumer_translation_units=1,retained_sdk_inputs=len(plan['retained']),SDK_CXX=0,NVCC=0,downloads=0,max_compiler_concurrency=1,
  implementation_sources_changed=False,prior_environment=pin(R/'.scratch/inference-request-bridges-20261030/hardware.json')),
 limits=[
  'This is an already-idle original-native observer failure; it does not demonstrate blocked-native cancellation, a failing drain, or unretired-candidate retry.',
  'One finite original target77/NextN78 request component is checked, not complete GLM prompt inference, cross-pump GLM, another complete engine model, or model quality.',
  'No independent performance candidate, new profiler or complete cross-engine speed/memory window; the full goal remains active. Joint architecture review is recorded separately; this finite check does not alone prove complete common architecture.',
  'Other platforms/artifacts, Apple/Vulkan, complete hybrid, multi-GPU and multi-machine were not run.'])
audit=R/'.scratch/inference-architecture-audit-20261030'
audit_paths=[audit/name for name in ('README.md','comparison.json') if (audit/name).exists()]
if audit_paths:summary['joint_architecture_review']=[pin(path) for path in audit_paths]
save(W/'summary-draft.json',summary)
with zipfile.ZipFile(W/'evidence-draft.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for name in ('build.py','collect.py','plan.json','patch-base.json','candidate-observer-failure.patch','source-change.patch','comparison.json','summary-draft.json','model-link-base.json'):
  archive.write(W/name,name)
 for path in W.rglob('*'):
  if path.is_file() and path.parts[len(W.parts)] in ('compile','link','runs') and path.suffix in ('.json','.log','.xml'):
   archive.write(path,str(path.relative_to(W)))
 for path in audit_paths:archive.write(path,'architecture-audit/'+path.name)
print(json.dumps(dict(status=summary['status'],checks=len(checks),exact_match=comparison.get('exact_match'),archive_bytes=(W/'evidence-draft.zip').stat().st_size)))
