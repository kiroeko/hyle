# 共同执行架构联合复审（2026-10-30）

复审基线：`c6bcaefe379be8c67f1ae600bd18b21e50e048cf`，源行号以下均指该提交。产品只读；另一个 agent 正补 GLM 候选观察首错的有限回归，该未提交改动不在本复审中计为通过。本审查没有运行新构建、推理或性能实验。

## 结论

未发现必须再从 Qwen 抽出、而仍被它独占的共同执行控制算法。原 80%／90% 是迁移中的估计，不能当作源码中必然还有 20%／10% 未实现的证据。此处应按下面实际职责核销；不新增总 ModelOps、阶段转发器或第二资源／账簿 owner。

当前明确未完成项是 **GLM K1 候选驱动内部观察失败的有限检查**。该回归通过、原首错／退休／未发布清理和重试事实保存后，本轮已定义的共同执行架构职责没有再查到需要实施的新片。可把相应架构节点按实际完成更新，并保留验证范围；这不完成整个 goal，普通流水、MTP 性能、GPU 热点及完整对照仍需随后推进。

## 原进度节点与实际实现

| 节点／职责 | 活代码 | 已有检查与界限 |
|---|---|---|
| 前后继准备／提交／观察共同驱动（原95%） | `engine/inference/step_execution.h:23`：准备A、提交A、取消、可选B准备／提交、完成A、B保留／丢弃／绑定、延迟返回／完成、统一失败退休及清理。Qwen `main.cc:6981`、`:7268`、`:7305`、`:7584` 实际消费。 | `inference-common-step-driver-2026-10-30.json`：host顺序／异常；ordinary原生16臂跨pump；source-failure、warm-cohort、boundaries、真实K1。同步／packed／递归目标另见 `inference-synchronous-step-driver-2026-10-30.json`。 |
| 跨pump连续cohort与额度控制（原90%） | `continuation.h:24` 保 ordered RequestKey＋turn 与 drain；`:86` 核 held＋additional grant；`:103` 统一发布后保留政策。`request_wave_execution.h:38` 核 pending身份／reserved、选择Start／Resume／Drain、失败交原owner。Qwen `main.cc:7678` 只投影原pending calls，`:7683` 接已提交原episode，`:7705` 以真实退休清元数据。 | `inference-continuation-control-2026-10-30.json` 27组host合同＋原生连续16臂；共同驱动批次的ordinary再次实际运行 `--cuda-continuous`（command.json已核）。`qwen_continuous_generation_case.h:225`、`:271`、`:297` 核恢复、原提交归属、credit drain／取消／yield／控制异常及逐前缀完整状态。没有GLM跨pump证明，也不需要强迫同步组件伪装异步。 |
| 结构不同组件消费同一步骤（原95%） | GLM `glm_pro_mtp_state_consumer_test.cc:1853` ordinary、`:1906` K1分别直接消费同步drive_steps。实际StateVersion、target／NextN、Native Invocation均为原owner；没有空successor协议。 | `inference-request-bridges-2026-10-30.json`：greedy54项／random53项保持；六项本片检查通过。候选驱动内部观察首错回归正在补，不能把发布后的观察重试当成同一覆盖。 |
| 阶段事实与模型数学／发布适配（原90%） | Qwen `main.cc:5013` 通用资源交接后解释实际状态；`:5242` 投影原完成事实；`:5384` 递归提案、`:5466` target-hidden修复、`:5551` 原p/q决定。账簿只在类外请求桥接`:5687`、`:5696`及调用期publication。GLM `:1726` 接受、实际目标修复及完整版本构造。 | `inference-publication-boundary-2026-10-30.json` 八项，含晚错／首错／真实退休；`inference-request-bridges-2026-10-30.json` Model请求账簿词0项、CPU history／CUDA replay／ordinary-K1-K2／真实K1／两个GLM原case。 |
| 跨模型MTP阶段事实与装配（原80%） | `mtp_acceptance.h` 同一AcceptedPrefix／停止／额度算法；Qwen`:5572`、`:5576`、`:5660`、`:5665` 与GLM`:1744`、`:1750`消费。共同步骤驱动、`ExecutionEpisode::finish_success`、原提交见证、ProgramIo与实际存储域已接线；模型供真实程序、输入状态、合法阶段、接受／修复及Head发布。 | common-step／synchronous-step／publication-boundary／request-bridges加先前private-handoff、effect-views、node-storage有限证据。证明共享控制与真实异构组件，不扩大为第二完整引擎、任意模型或全平台。 |

## 仍留在模型里的阶段为何合理

- Qwen递归提案在目标驱动前运行（`main.cc:7529`），因为每轮q、概率阈值、动态modifier、hidden接力与修复长度是其实际数学。内部Graph仍使用原ProgramCarrier／ExecutionEpisode成功交接与退休，没有另造执行控制owner。把它包成另一层阶段调度不增加共同政策。
- GLM第一段NextN／target及q提案（`:2599`、`:2614`）形成K1真实输入；候选驱动只控制其验证／未发布候选。完整Head CAS（`:2667`）成功后才维护journal（`:2687`），不同于Qwen发布前target-hidden修复。统一两者的具体顺序会改变已有语义；共用的已是提交见证、观察去重、额度／接受事实与真实退休。
- Qwen successor的Source、warm计数、有限slot／state容量、role和width限制是实际模型／后端能力；共同层没有规定单KV银行、两阶段、K1、单Queue或GPU序号。`drive_steps`负责这些事实之后的共同推进顺序，不能为目录整齐把资格判断升级成通用硬限制。
- 普通流水下的“CUDA跨pump与控制边界约90%”属于后续性能／配置覆盖节点，不能和已落实的共同cohort／grant／pending控制混算。随机／K>1／条件后继等扩展仍按性能阶段及真实能力推进，不是恢复独立性能候选前必须补的伪架构接口。

## 下一步与保留边界

1. 等待并审阅GLM候选驱动首错回归的真实结果：不发布Head／ledger／RNG、原Invocation退休后才清候选、保首错、同提案重试一致。
2. 按此职责映射修正看板及设计／工程计划中的迁移中旧措辞，移出已完成的架构事项；不删已有证据中的历史验证边界。
3. 本次未找到新的必需产品架构改动；若后续有限回归失败则以真实根因补修，再开始集中性能。

保留：GLM为target77／NextN78有限组件；没有GLM跨pump／完整prompt引擎或第二完整模型证明。多卡／跨Context／跨机实现、条件后继产品接入、其它制品／平台完整覆盖及新完整速度／显存窗口都没有由本审查取得。延迟退休／未知native故障未注入，不能将host脚本的退休输入称为真实设备故障覆盖。
