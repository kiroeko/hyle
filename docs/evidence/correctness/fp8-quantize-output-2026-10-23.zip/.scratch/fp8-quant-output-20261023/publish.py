"""Publish this finite implementation round; never claim a whole MTP model pass."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def ident(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


windows = read(S / 'checks1/summary.json')
vulkan = read(S / 'vulkan-build/run1/summary.json')
apple = read(S / 'apple/attempt1-run.json')
actual_apple = read(S / 'apple/actual-artifacts.json')
assert windows['tests'] == 19 and vulkan['tests'] == 2 and apple['tests'] == 2
for result in (windows, vulkan):
    assert result['process']['exit'] == 0 and not result['process']['timed_out']
    assert not any(result[x] for x in ('failures', 'errors', 'disabled', 'skips'))
assert apple['passed'] and not apple['failed'] and not apple['skipped']
apple_xml = ET.fromstring(actual_apple['files']['tests.xml'])
apple_cases = [dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value']
    for p in case.iter('property')}) for case in apple_xml.iter('testcase')]
cases = windows['cases'] + vulkan['cases'] + apple_cases
inherited = sum(int(case['properties'].get('actual_submissions', 0)) for case in windows['cases'])
successful = sum(int(case['properties'].get('successful_submissions', 0)) for case in cases)
failed = sum(int(case['properties'].get('failed_submissions', 0)) for case in cases)
assert (inherited, successful, failed) == (234, 24, 8)
source_names = [
    'include/hyle/compute/model_ops.h',
    'src/compute_provider_native/torch_cpu_program.cc',
    'src/compute_provider_cuda/CMakeLists.txt',
    'src/compute_provider_cuda/cuda_provider.cc',
    *['src/compute_provider_cuda/float8_quantize_' + x for x in ('kernel.cu', 'kernel.h', 'provider.cc', 'provider.h')],
    'src/compute_route_apple/apple_mature_float.cc',
    *['src/compute_route_vulkan/' + x for x in ('vulkan_official.cc', 'vulkan_iree.cc', 'vulkan_iree.h', 'vulkan_program.cc')],
    *['src/compute_provider_iree_vulkan/' + x for x in ('native_program.h', 'native_program.cc', 'prepare_source.py')],
    *['third_party/iree_vulkan_runtime/programs/' + x for x in ('generate_official.py', 'compile_official.py', 'official.mlir', 'official.vmfb.b64', 'manifest.json', 'compilation.json')],
    'tests/compute_models/float8_quantize_output_test.cc',
    'tests/compute_models/glm_official_index_cache.h',
    'tests/compute_models/glm_official_index_cache_test.cc',
    *['tests/graph_route_' + backend + '/CMakeLists.txt' for backend in ('cpu', 'cuda', 'vulkan', 'apple')],
]
archive = D / 'fp8-quantize-output-2026-10-23.zip'
assert not archive.exists(), archive
suffixes = {'.py', '.json', '.xml', '.log', '.diff', '.patch', '.cc', '.h', '.cu', '.txt', '.mlir', '.d'}
members = {R / name for name in source_names}
members.update(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in suffixes
               and '__pycache__' not in p.parts and p.name != 'publication.json')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(members):
        z.write(path, path.relative_to(R).as_posix())
result = dict(
    date='2026-10-23', round='BE', scope='Generic dynamic Float8BlockQuantize actual outputs and GLM Flash default UE8M0 logical cache',
    complete_MTP=False, whole_original_model=False, throughput_evidence=False, physical_memory_evidence=False,
    implementation=dict(
        operation='model_ops::Float8BlockQuantize',
        input='dense plain finite F32/BF16 [M,K], M,K>0 and K%128=0',
        outputs=['plain E4M3FN actual codes [M,K]', 'plain F32 actual group scales [M,K/128]'],
        defaults='Divide, absmax_floor=1e-10F; GLM chooses explicit PowerOfTwo, floor=1e-4F',
        policies=['F32(max/f448), x/scale', 'F32(max*F32recip448), ceil power2, x/scale',
                  'F32(max*F32recip448), F32(1/scale), F32(x*reciprocal)'],
        rounding='F32 named boundaries; E4 SATFINITE/RNE with signed zero; finite input check fails Completion and exposes no successful outputs',
        resources='ordinary immutable provider plans, independent Invocation, two typed no-alias outputs, shared queue/status/retirement mechanisms; no cache shadow or new executor',
        cuda='one warp per contiguous group128; explicit RN scale/normalization; native CUDA E4 conversion',
        portable='Apple existing integer IEEE helpers; Vulkan integer normalization for visible bytes, six added typed exports, two ordinary native outputs followed by finite flag; old ProgramSpecV4 and enum values retained'),
    glm=dict(
        source='SGLang 06992c92ad4494fe9f9636e75be3e35040512447 default scale_fmt=ue8m0',
        replaced='Prior optional scale_fmt=None component replaced by default PowerOfTwo actual output primitive, no duplicate compatibility path',
        chain='F32 pooled -> BF16 -> normalized Hadamard128 -> BF16 -> E4+F32scale; matching query -> scorer -> TopK512 -> I32 2048 tokens -> MLA',
        state='one StateHead codes/scales/cursor/IDs/attention; accept A, reject B, continue C and independent base, stale/cancel/old readonly leases',
        checks='CPU and CUDA each 12 Graph submissions, unchanged layered Hadamard math/BF16 and exact code/scale gates',
        limits='generated raw K4/query/headweight/latent boundaries and complete closed pools; logical cache, not vendor page/footer ABI, original full GLM model, natural acceptance or throughput'),
    validation=dict(
        executed_test_instances=23, unique_test_names=len({x['attributes']['name'] for x in cases}),
        graph_submission_attempts=inherited + successful + failed,
        inherited_related_model_state_attempts=inherited,
        new_quantization=dict(successful=successful, intentional_nonfinite_failed_Completions=failed,
            coverage='four backends each two M2/K256 Graphs F32/BF16; three policies floor1e-4 plus Divide default1e-10, eight actual outputs; two generations, NaN failure, fresh recovery; exact independent code/scale oracle, no alias and retained old outputs'),
        windows_cpu_cuda=windows, windows_vulkan=vulkan,
        apple=dict(result=apple, cases=apple_cases, hardware=read(S/'apple/attempt1-prepare.json')['hardware'],
                   actual_artifacts=actual_apple['artifacts']),
        build='Windows 5 host TUs+1 small NVCC TU; Vulkan 7 product host TUs+1 test TU+existing fixed offline compiler; Apple 2 TUs. Existing SDK, native workers and libraries reused; no download/CI/full SDK rebuild',
        limitations=['No Linux run', 'New-op finite bounded fixtures do not certify every shape/input or physical device memory peak',
            'New primitive passed Apple/Vulkan; GLM full state-cache consumer here remains CPU/CUDA only',
            'No ordinary/MTP end-to-end performance rerun']),
    reproducibility=dict(stage=S.relative_to(R).as_posix(), archive=ident(archive), sources=[ident(R/name) for name in source_names],
        windows_command='python .scratch/fp8-quant-output-20261023/build.py torch-cpu cuda-provider quant-provider quant-kernel quant-test glm-cache link run --attempt NEW',
        vulkan_command='python .scratch/fp8-quant-output-20261023/vulkan_build.py native-program embedded iree official program region vulkan-run test link run --attempt NEW',
        apple_command='apple_build.py: plan/prepare/compile --job mature/compile --job test/link/run; see recorded attempt1 plan and receipts',
        harness_corrections=['After successful first NVCC compile, corrected only its evidence local status-header path and generated identity without recompiling',
                            'Renamed Vulkan product tag run to vulkan-run after detecting collision with the test action; reused six successful compiles and resumed remaining two']),
    remaining=['GLM target43 MLA/index history -> target44 and default encoded cache -> complete NextN state',
               'DSpark encoded main history with complete draft state, actual trained target taps and shared LM roles; applicable Pro roles',
               'Q27/Q24 applicable original roles, complete state composition and confirmed MTP quantized artifacts',
               'Necessary final correctness checks and ordinary/MTP performance comparison before image projection'])
path = D / 'fp8-quantize-output-2026-10-23.json'
assert not path.exists(), path
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=ident(path), archive=ident(archive)), indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(evidence=ident(path), archive=ident(archive), test_instances=23, graph_attempts=266), ensure_ascii=False))
