"""Fetch the small actual XML, log and object identities; no new build/test."""
import runpy
import json
from pathlib import Path
S = Path(__file__).resolve().parent
m = runpy.run_path(str(S / 'apple_build.py'))
p = json.loads((S / 'apple/attempt1-plan.json').read_bytes())
script = '''from pathlib import Path
import json,sys,hashlib
p=json.load(sys.stdin);r=Path(p['remote'])
def ident(path):
 b=path.read_bytes();return dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
print(json.dumps(dict(files={name:(r/name).read_text(errors='replace') for name in ['tests.xml','mature-compile.stdout.log','mature-compile.stderr.log','test-compile.stdout.log','test-compile.stderr.log','link.stderr.log','run.stdout.log','run.stderr.log']},artifacts=[ident(r/name) for name in ['mature.o','test.o','mature.o.d','test.o.d','fp8-quant-output-checks','fp8-quant-output-checks.map']])))
'''
result = m['m'].ssh(script, {'remote': p['remote']}, timeout=60)
(S / 'apple/actual-artifacts.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('Fetched actual Apple XML, logs and six artifact identities')
