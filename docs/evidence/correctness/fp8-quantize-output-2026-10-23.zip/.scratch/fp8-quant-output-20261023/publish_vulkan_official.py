"""Publish the actually compiled official Vulkan bytecode and regenerate its embedding.

No compiler, model execution, downloads, SDK/source copy, or runtime pass claim.
Run only after vulkan-official/compile_official.py has produced compilation.json.
"""
import base64
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
BE = Path(__file__).resolve().parent
ROOT = BE.parents[1]
VENDOR = ROOT / 'third_party/iree_vulkan_runtime'
PRODUCT = VENDOR / 'programs'
COMPILED = BE / 'vulkan-official'
RECORD = BE / 'vulkan-artifact-source'
EXPORTS = [
    'weight_decode_f32', 'weight_decode_bf16', 'fp8_roundtrip_64', 'fp8_roundtrip_128',
    'fp4_roundtrip_32', 'linear_normal_f32', 'linear_power_f32', 'grouped8_f32',
    'grouped4_f32', 'encoded_block128', 'grouped8_power_f32', 'linear_reciprocal_f32',
    'grouped8_reciprocal_f32', 'quantize_normal_f32', 'quantize_power_f32',
    'quantize_reciprocal_f32', 'quantize_normal_bf16', 'quantize_power_bf16',
    'quantize_reciprocal_bf16',
]
PIN = '6ef606b6fa3e12bd2c12d36a07463069eb71185f'
PROVENANCE_KEY = 'float8_quantize_output'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def normalized(path):
    raw = path.read_bytes()
    return raw.replace(b'\r\n', b'\n') if path.suffix in ('.py', '.mlir', '.txt') else raw


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': sha(raw)}


def official_span(text):
    """Replace exactly one entry while retaining every other manifest byte."""
    match = re.search(r'"programs"\s*:\s*\[', text)
    if not match:
        raise ValueError('program manifest array missing')
    decoder = json.JSONDecoder()
    pos = match.end()
    found = []
    while True:
        while pos < len(text) and (text[pos].isspace() or text[pos] == ','):
            pos += 1
        if text[pos] == ']':
            break
        value, end = decoder.raw_decode(text, pos)
        if value.get('name') == 'official':
            found.append((pos, end))
        pos = end
    if len(found) != 1:
        raise ValueError('exactly one official program entry required')
    return found[0]


def main():
    if ROOT != Path.cwd().resolve():
        raise ValueError('run the publisher from the authoritative Hyle repository root')
    receipt_path = COMPILED / 'compilation.json'
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    recipe = normalized(PRODUCT / 'official.mlir')
    if receipt.get('exports') != EXPORTS or re.findall(rb'^func.func @(\w+)\(', recipe, re.M) != [x.encode() for x in EXPORTS]:
        raise ValueError('actual recipe and compilation exports must be the nineteen expected entries')
    source_names = {'official.mlir', 'compile_official.py', 'generate_official.py', 'generate_mlx.py'}
    output_names = {'configured.mlir', 'annotated.mlir', 'official.vmfb', 'compiler-version.txt'}
    spirv_names = {p.name for p in (COMPILED / 'spirv').glob('*.spirv.mlir')}
    files = receipt.get('files', {})
    if set(files) != source_names | output_names | spirv_names:
        raise ValueError('actual compilation file set differs from its recorded inputs and outputs')
    for name, expected in files.items():
        path = PRODUCT / name if name in source_names else COMPILED / name if name in output_names else COMPILED / 'spirv' / name
        if sha(normalized(path)) != expected:
            raise ValueError(f'compiled input/output changed: {name}')
    if PIN not in (COMPILED / 'compiler-version.txt').read_text(encoding='utf-8'):
        raise ValueError('compiler/runtime pin differs')
    if not isinstance(receipt.get('math_schedules'), int) or receipt['math_schedules'] <= 0 or receipt.get('spirv_modules') != len(spirv_names) or not spirv_names:
        raise ValueError('actual configured and compiled schedule records missing')
    if not set(receipt.get('integer_only_modules', [])) <= spirv_names:
        raise ValueError('integer control modules differ')
    binary = (COMPILED / 'official.vmfb').read_bytes()
    manifest_path = PRODUCT / 'manifest.json'
    manifest_raw = manifest_path.read_bytes()
    manifest_text = manifest_raw.decode('utf-8')
    manifest = json.loads(manifest_text)
    entries = manifest['programs']
    official = [x for x in entries if x['name'] == 'official']
    if len(official) != 1 or manifest['upstream_iree'] != PIN:
        raise ValueError('official manifest identity differs')
    # Validate unchanged program bytes before touching any product artifact.
    for entry in entries:
        if entry['name'] == 'official':
            continue
        raw = base64.b64decode((PRODUCT / entry['file']).read_bytes())
        if sha(raw) != entry['sha256'] or len(raw) != entry['bytes'] or sha(normalized(PRODUCT / entry['recipe'])) != entry['recipe_sha256']:
            raise ValueError(f'unchanged offline program identity differs: {entry["name"]}')
    updated = copy.deepcopy(official[0])
    updated.update(sha256=sha(binary), bytes=len(binary), recipe_sha256=sha(recipe), exports_used=EXPORTS)
    updated['execution_contract'] = (
        'Original QAT/RNE and bounded shared dense or selected grouped code-dot; existing linear and roundtrip recipes unchanged. '
        'Typed Float8BlockQuantize returns E4M3FN codes[M,K], F32 scales[M,K/128] and a trailing finite-input flag; '
        'Divide/PowerOfTwo/MultiplyReciprocal preserve explicit F32 scale/normalization, SATFINITE/RNE and signed zero. '
        'New byte-producing normalization uses U32 significand division and U16 partial products without Int64; '
        'compiled schedule/module identities are recorded in compilation.json.float8_quantize_output.')
    start, end = official_span(manifest_text)
    newline = '\r\n' if b'\r\n' in manifest_raw else '\n'
    replacement = json.dumps(updated, ensure_ascii=True, indent=2).replace('\n', newline + '    ')
    new_manifest_raw = (manifest_text[:start] + replacement + manifest_text[end:]).encode('utf-8')
    new_manifest = json.loads(new_manifest_raw)
    if [x for x in new_manifest['programs'] if x['name'] != 'official'] != [x for x in entries if x['name'] != 'official']:
        raise ValueError('publisher changed an unrelated program entry')
    provenance_path = PRODUCT / 'compilation.json'
    provenance = json.loads(provenance_path.read_text(encoding='utf-8'))
    if PROVENANCE_KEY in provenance:
        raise ValueError('publication provenance already exists; inspect it before repeating')
    provenance[PROVENANCE_KEY] = receipt
    products = {
        PRODUCT / 'official.vmfb.b64': base64.encodebytes(binary),
        manifest_path: new_manifest_raw,
        provenance_path: (json.dumps(provenance, ensure_ascii=True, indent=2) + '\n').encode(),
    }
    # Backups are exclusive and precede every product mutation. No cleanup or
    # SDK preparation happens in this script; all new generated output is BE-local.
    previous = []
    for path in products:
        backup = RECORD / 'before' / path.relative_to(ROOT)
        backup.parent.mkdir(parents=True, exist_ok=True)
        with backup.open('xb') as output:
            output.write(path.read_bytes())
        previous.append(identity(path))
    staged = RECORD / 'staged'
    staged.mkdir(parents=True, exist_ok=True)
    for path, payload in products.items():
        temporary = staged / path.name
        with temporary.open('xb') as output:
            output.write(payload)
        os.replace(temporary, path)
    preparation_path = ROOT / 'src/compute_provider_iree_vulkan/prepare_source.py'
    spec = importlib.util.spec_from_file_location('hyle_offline_program_embedding', preparation_path)
    preparation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preparation)
    generated = BE / 'generated'
    program_count = preparation.generate_programs(VENDOR, generated)
    # programs.cc includes the original module programs.h via its source include
    # directory. Do not invent/copy another header or any third-party SDK tree.
    result = {
        'compilation_receipt': identity(receipt_path),
        'before': previous, 'after': [identity(p) for p in products],
        'generated': identity(generated / 'programs.cc'),
        'prepare_source': identity(preparation_path),
        'offline_program_count': program_count, 'exports': EXPORTS,
        'native_runtime_tested_by_this_script': False,
    }
    (RECORD / 'publication.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
