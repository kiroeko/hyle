"""Focused actual FP8-output increment; serialize all native work in root."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BD = R / '.scratch/glm-mtp-seed-cache-20261022'
A = R / '.scratch/architecture-refactor-2026-10-18'
spec = importlib.util.spec_from_file_location('fp8_cached_build', BD / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = BD / 'tests-link8'
CPU_RECIPE = A / 'quark-block128-scale-2026-10-21/windows/checks/attempt1/torch-cpu/identity.json'
CUDA_RECIPE = A / 'quark-block128-scale-2026-10-21/cuda/windows/checks/attempt1/cuda-provider/identity.json'
TEST_RECIPE = BD / 'compile4/glm-cache/identity.json'
SOURCES = {
    'torch-cpu': R / 'src/compute_provider_native/torch_cpu_program.cc',
    'cuda-provider': R / 'src/compute_provider_cuda/cuda_provider.cc',
    'quant-provider': R / 'src/compute_provider_cuda/float8_quantize_provider.cc',
    'quant-test': R / 'tests/compute_models/float8_quantize_output_test.cc',
    'glm-cache': R / 'tests/compute_models/glm_official_index_cache_test.cc',
}
RECIPES = {'torch-cpu': CPU_RECIPE, 'cuda-provider': CUDA_RECIPE,
           'quant-provider': CUDA_RECIPE, 'quant-test': TEST_RECIPE, 'glm-cache': TEST_RECIPE}


def host(tag, attempt):
    recipe = c.read(RECIPES[tag])
    if tag == 'quant-test':
        recipe['command'] = [x for x in recipe['command'] if not x.startswith('/DHYLE_TEST_GLM_CACHE_')]
        recipe['command'] += ['/DHYLE_TEST_FP8_QUANT_CPU=1', '/DHYLE_TEST_FP8_QUANT_CUDA=1']
    path = S / 'recipes' / (tag + '.json')
    path.parent.mkdir(exist_ok=True)
    c.save(path, recipe)
    h.RECIPES[tag], h.SOURCES[tag] = path, SOURCES[tag]
    h.compile_one(tag, attempt)


def kernel(attempt):
    out = S / f'compile{attempt}/quant-kernel'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    source = R / 'src/compute_provider_cuda/float8_quantize_kernel.cu'
    sdk = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
    host_recipe = c.read(CUDA_RECIPE)
    command = [str(sdk / 'bin/nvcc.exe'), '-forward-unknown-to-host-compiler',
        '-ccbin', str(Path(host_recipe['command'][0]).parent),
        '-DHYLE_STATIC=1', '-DHYLE_COMPUTE_CUDA=1', '-DNOMINMAX',
        '-I' + str(R / 'include'), '-I' + str(source.parent),
        '-I' + str(R / 'src/compute'), '-I' + str(R / 'src/compute_backend_cuda'),
        '-isystem', str(sdk / 'include'), '-isystem', str(sdk / 'include/cccl'),
        '-D_WINDOWS', '-Xcompiler=/EHsc', '-Xcompiler=-O2,-Ob2', '-DNDEBUG',
        '-std=c++20', '--generate-code=arch=compute_89,code=[sm_89]',
        '-Xcompiler=-MD', '--expt-relaxed-constexpr', '-Xcompiler=/utf-8,/wd4211',
        '-MD', '-MT', str(out / 'quant-kernel.obj'), '-MF', str(out / 'quant-kernel.d'),
        '-x', 'cu', '-c', str(source), '-o', str(out / 'quant-kernel.obj'),
        '-Xcompiler=-Fd' + str(out / 'quant-kernel.pdb') + ',-FS']
    frozen = b.identity(source)
    snap = out / 'source' / source.relative_to(R)
    snap.parent.mkdir(parents=True)
    snap.write_bytes(source.read_bytes())
    c.save(out / 'plan.json', dict(source=frozen, command=command,
        recipe=b.identity(R / '.scratch/b-cuda-d5/build.ninja'),
        precision='Existing SM89 C++20 no-fastmath defaults, explicit RN device intrinsics',
        SDK_builds=0, NVCC_translation_units=1))
    env, _ = b.environment(host_recipe['command'], [], out)
    c.execute('compile', command, env, out)
    assert b.identity(source) == frozen
    dependencies = [source, source.with_suffix('.h'), R / 'src/compute_backend_cuda/device_status_kernel.h']
    c.save(out / 'identity.json', dict(source=frozen,
        object=b.identity(out / 'quant-kernel.obj'), command=command,
        dependencies=[b.identity(p) for p in dependencies],
        dependency_file=b.identity(out / 'quant-kernel.d'), compiler=b.identity(command[0])))
    print('COMPILED quant-kernel', flush=True)


def latest(tag):
    rows = sorted(S.glob(f'compile*/{tag}/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    if not rows:
        raise RuntimeError('No compiled source: ' + tag)
    path = rows[-1]
    record = c.read(path)
    assert all(b.identity(x['path']) == x for x in [record['source'], record['object'], *record['dependencies']])
    return path, record


def link(attempt):
    base = c.read(BASE / 'link-plan.json')
    remove = {c.key(c.read(p)['object']['path']) for p in (CPU_RECIPE, CUDA_RECIPE, TEST_RECIPE)}
    retained = []
    for item in base['compiled_records']:
        record = c.read(item['path'])
        if c.key(record['source']['path']) in {c.key(str(p)) for p in SOURCES.values()}:
            remove.add(c.key(record['object']['path']))
        else:
            retained.append(item)
    compiled = [latest(tag) for tag in (*SOURCES, 'quant-kernel')]
    added = [record['object'] for _, record in compiled]
    inputs = added + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [x['path'] for x in added]
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'fp8-quant-output-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(path) for path, _ in compiled] + retained,
        base=b.identity(BASE / 'link-plan.json'), SDK_builds=0,
        native_CPU_builds=0, NVCC_translation_units=1, shader_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        assert b.identity(item['path']) == item
        os.link(item['path'], out / Path(item['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(
        p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    runtime['base_runtime'] = b.identity(BASE / 'runtime-environment.json')
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image)))
    print('LINKED', image, flush=True)


def run(link_attempt, attempt, test_filter, expected):
    spec_run = importlib.util.spec_from_file_location('fp8_run_helpers', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    q = importlib.util.module_from_spec(spec_run)
    spec_run.loader.exec_module(q)
    folder = S / f'tests-link{link_attempt}'
    image = c.read(folder / 'ready.json')['image']
    assert b.identity(image['path']) == image
    env = os.environ.copy()
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    env['HYLE_DSPARK_TARGET_ROLES_DIR'] = str(R / '.scratch/glm-mtp-catchup-20261022/original-dspark-target')
    env['HYLE_DSPARK_HISTORY_ROLES_DIR'] = str(BD / 'original-dspark-history')
    out = S / f'checks{attempt}'
    xml = out / 'results.xml'
    command = [image['path'], '--gtest_filter=' + test_filter, '--gtest_output=xml:' + str(xml)]
    process = q.execute(command, env, out, timeout=600)
    result = dict(process=process, image=image, throughput_evidence=False,
                  physical_memory_evidence=False, whole_original_model=False)
    if xml.is_file():
        root = ET.parse(xml).getroot()
        result.update(tests=int(root.attrib['tests']), failures=int(root.attrib['failures']),
            errors=int(root.attrib['errors']), disabled=int(root.attrib['disabled']),
            skips=sum(case.find('skipped') is not None for case in root.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value']
                for p in case.iter('property')}) for case in root.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == expected, result
    assert not any(result[k] for k in ('failures', 'errors', 'disabled', 'skips')), result
    print('PASS related checks', expected, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('actions', nargs='+', choices=[*SOURCES, 'quant-kernel', 'link', 'run'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--filter', default='*')
    parser.add_argument('--expected-tests', type=int, default=19)
    args = parser.parse_args()
    for action in args.actions:
        if action == 'quant-kernel': kernel(args.attempt)
        elif action == 'link': link(args.attempt)
        elif action == 'run': run(args.link_attempt, args.attempt, args.filter, args.expected_tests)
        else: host(action, args.attempt)
