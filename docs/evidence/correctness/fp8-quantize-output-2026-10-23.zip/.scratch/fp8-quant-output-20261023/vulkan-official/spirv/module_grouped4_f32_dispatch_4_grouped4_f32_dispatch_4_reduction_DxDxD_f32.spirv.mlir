spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @grouped4_f32_dispatch_4_reduction_DxDxD_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst32_i32 = spirv.Constant 32 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst-64_i32 = spirv.Constant -64 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst15_i32 = spirv.Constant 15 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst_f32 = spirv.Constant 0.000000e+00 : f32
    %cst = spirv.Constant dense<[0.000000e+00, 5.000000e-01, 1.000000e+00, 1.500000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 6.000000e+00, -0.000000e+00, -5.000000e-01, -1.000000e+00, -1.500000e+00, -2.000000e+00, -3.000000e+00, -4.000000e+00, -6.000000e+00]> : tensor<16xf32> : !spirv.array<16 x f32>
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %12 = spirv.SLessThanEqual %9, %cst0_i32 : i32
    %13 = spirv.ISub %cst0_i32, %9 : i32
    %14 = spirv.ISub %9, %cst1_i32 : i32
    %15 = spirv.Select %12, %13, %14 : i1, i32
    %16 = spirv.SDiv %15, %cst64_i32 : i32
    %17 = spirv.ISub %cst0_i32, %16 : i32
    %18 = spirv.IAdd %16, %cst1_i32 : i32
    %19 = spirv.Select %12, %17, %18 : i1, i32
    %20 = spirv.IMul %7, %19 : i32
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %21 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %22 = spirv.CompositeExtract %21[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %23 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %24 = spirv.CompositeExtract %23[0 : i32] : vector<3xi32>
    spirv.mlir.loop {
      spirv.Branch ^bb1(%22 : i32)
    ^bb1(%25: i32):  // 2 preds: ^bb0, ^bb2
      %26 = spirv.SLessThan %25, %20 : i32
      spirv.BranchConditional %26, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %27 = spirv.SDiv %25, %19 : i32
      %28 = spirv.IMul %27, %19 : i32
      %29 = spirv.INotEqual %25, %28 : i32
      %30 = spirv.SLessThan %25, %cst0_i32 : i32
      %31 = spirv.SLessThan %19, %cst0_i32 : i32
      %32 = spirv.LogicalNotEqual %30, %31 : i1
      %33 = spirv.LogicalAnd %29, %32 : i1
      %34 = spirv.IAdd %27, %cst-1_i32 : i32
      %35 = spirv.Select %33, %34, %27 : i1, i32
      %36 = spirv.GL.SAbs %25 : i32
      %37 = spirv.GL.SAbs %19 : i32
      %38 = spirv.UMod %36, %37 : i32
      %39 = spirv.IEqual %25, %36 : i32
      %40 = spirv.SNegate %38 : i32
      %41 = spirv.Select %39, %38, %40 : i1, i32
      %42 = spirv.SLessThan %41, %cst0_i32 : i32
      %43 = spirv.IAdd %41, %19 : i32
      %44 = spirv.Select %42, %43, %41 : i1, i32
      %45 = spirv.IMul %44, %cst-64_i32 : i32
      %46 = spirv.IAdd %45, %9 : i32
      %47 = spirv.GL.SMin %46, %cst64_i32 : i32
      %48 = spirv.SGreaterThan %47, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %48, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %50 = spirv.IMul %44, %cst64_i32 : i32
        %51 = spirv.IAdd %50, %11 : i32
        %52 = spirv.IMul %35, %9 : i32
        %53 = spirv.IAdd %51, %52 : i32
        %54 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %53] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %54, %cst_f32 : f32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%55: i32):  // 2 preds: ^bb0, ^bb2
          %56 = spirv.SLessThan %55, %cst32_i32 : i32
          spirv.BranchConditional %56, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %57 = spirv.IMul %35, %cst32_i32 : i32
          %58 = spirv.IAdd %57, %55 : i32
          %59 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %58] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %60 = spirv.Load "StorageBuffer" %59 : f32
          %61 = spirv.Load "StorageBuffer" %54 : f32
          %62 = spirv.IAdd %1, %55 : i32
          %63 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %35] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
          %64 = spirv.Load "StorageBuffer" %63 : i32
          %65 = spirv.UDiv %62, %cst8_i32 : i32
          %66 = spirv.UMod %62, %cst8_i32 : i32
          %67 = spirv.IMul %64, %9 : i32
          %68 = spirv.IAdd %51, %67 : i32
          %69 = spirv.IMul %68, %5 : i32
          %70 = spirv.IAdd %69, %65 : i32
          %71 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %70] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
          %72 = spirv.Load "StorageBuffer" %71 : i32
          %73 = spirv.IMul %66, %cst4_i32 : i32
          %74 = spirv.ShiftRightLogical %72, %73 : i32, i32
          %75 = spirv.BitwiseAnd %74, %cst15_i32 : i32
          %76 = spirv.Variable : !spirv.ptr<!spirv.array<16 x f32>, Function>
          spirv.Store "Function" %76, %cst : !spirv.array<16 x f32>
          %77 = spirv.AccessChain %76[%75] : !spirv.ptr<!spirv.array<16 x f32>, Function>, i32 -> !spirv.ptr<f32, Function>
          %78 = spirv.Load "Function" %77 : f32
          %79 = spirv.FMul %60, %78 : f32
          %80 = spirv.FAdd %61, %79 : f32
          spirv.Store "StorageBuffer" %54, %80 : f32
          %81 = spirv.IAdd %55, %cst1_i32 : i32
          spirv.Branch ^bb1(%81 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %49 = spirv.IAdd %25, %24 : i32
      spirv.Branch ^bb1(%49 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @grouped4_f32_dispatch_4_reduction_DxDxD_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @grouped4_f32_dispatch_4_reduction_DxDxD_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @grouped4_f32_dispatch_4_reduction_DxDxD_f32 "SignedZeroInfNanPreserve", 32
}