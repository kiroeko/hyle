spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_16bit_storage, SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__workgroup_mem__6 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @quantize_power_bf16_dispatch_1_reduction_Dx128_i16xf32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst2_i32 = spirv.Constant 2 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst16777216_i32 = spirv.Constant 16777216 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst134217728_i32 = spirv.Constant 134217728 : i32
    %cst-9_i32 = spirv.Constant -9 : i32
    %cst1048575_i32 = spirv.Constant 1048575 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst146_i32 = spirv.Constant 146 : i32
    %cst18725_i32 = spirv.Constant 18725 : i32
    %cst65535_i32 = spirv.Constant 65535 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2139095040_i32 = spirv.Constant 2139095040 : i32
    %cst2147483647_i32 = spirv.Constant 2147483647 : i32
    %cst-2147483648_i32 = spirv.Constant -2147483648 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.Bitcast %3 : i32 to f32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %5 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %6 = spirv.CompositeExtract %5[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %7 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %8 = spirv.CompositeExtract %7[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %9 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %10 = spirv.CompositeExtract %9[0 : i32] : vector<3xi32>
    %11 = spirv.IMul %8, %cst64_i32 : i32
    %12 = spirv.IMul %10, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%11 : i32)
    ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
      %14 = spirv.SLessThan %13, %1 : i32
      spirv.BranchConditional %14, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %15 = spirv.ISub %1, %13 : i32
      %16 = spirv.GL.SMin %15, %cst64_i32 : i32
      %__workgroup_mem__6_addr = spirv.mlir.addressof @__workgroup_mem__6 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
      %17 = spirv.SGreaterThan %16, %6 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %17, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %19 = spirv.AccessChain %__workgroup_mem__6_addr[%cst0_i32, %6] : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>, i32, i32 -> !spirv.ptr<f32, Workgroup>
        spirv.Store "Workgroup" %19, %4 : f32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%39: i32):  // 2 preds: ^bb0, ^bb2
          %40 = spirv.SLessThan %39, %cst128_i32 : i32
          spirv.BranchConditional %40, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %41 = spirv.IMul %13, %cst128_i32 : i32
          %42 = spirv.IAdd %39, %41 : i32
          %43 = spirv.IMul %6, %cst128_i32 : i32
          %44 = spirv.IAdd %42, %43 : i32
          %45 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %44] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
          %46 = spirv.Load "StorageBuffer" %45 : i16
          %47 = spirv.Load "Workgroup" %19 : f32
          %48 = spirv.UConvert %46 : i16 to i32
          %49 = spirv.ShiftLeftLogical %48, %cst16_i32 : i32, i32
          %50 = spirv.Bitcast %49 : i32 to f32
          %51 = spirv.GL.FAbs %50 : f32
          %52 = spirv.GL.FMax %51, %47 : f32
          %53 = spirv.IsNan %51 : f32
          %54 = spirv.IsNan %47 : f32
          %55 = spirv.Select %53, %51, %52 : i1, f32
          %56 = spirv.Select %54, %47, %55 : i1, f32
          spirv.Store "Workgroup" %19, %56 : f32
          %57 = spirv.IAdd %39, %cst1_i32 : i32
          spirv.Branch ^bb1(%57 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %20 = spirv.Load "Workgroup" %19 : f32
        %21 = spirv.Bitcast %20 : f32 to i32
        %22 = spirv.BitwiseAnd %21, %cst-2147483648_i32 : i32
        %23 = spirv.BitwiseAnd %21, %cst2147483647_i32 : i32
        %24 = spirv.IEqual %23, %cst0_i32 : i32
        %25 = spirv.UGreaterThanEqual %23, %cst2139095040_i32 : i32
        %26 = spirv.LogicalOr %24, %25 : i1
        %27 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.selection {
          spirv.BranchConditional %26, ^bb1, ^bb2
        ^bb1:  // pred: ^bb0
          spirv.Store "Function" %27, %22 : i32
          spirv.Branch ^bb3
        ^bb2:  // pred: ^bb0
          %39 = spirv.ShiftRightLogical %23, %cst23_i32 : i32, i32
          %40 = spirv.BitwiseAnd %21, %cst8388607_i32 : i32
          %41 = spirv.INotEqual %39, %cst0_i32 : i32
          %42 = spirv.Select %41, %cst8388608_i32, %cst0_i32 : i1, i32
          %43 = spirv.BitwiseOr %40, %42 : i32
          %44 = spirv.Select %41, %39, %cst1_i32 : i1, i32
          %45 = spirv.Variable : !spirv.ptr<i32, Function>
          %46 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%43, %44 : i32, i32)
          ^bb1(%107: i32, %108: i32):  // 2 preds: ^bb0, ^bb2
            %109 = spirv.ULessThan %107, %cst8388608_i32 : i32
            spirv.Store "Function" %45, %107 : i32
            spirv.Store "Function" %46, %108 : i32
            spirv.BranchConditional %109, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %110 = spirv.ShiftLeftLogical %107, %cst1_i32 : i32, i32
            %111 = spirv.ISub %108, %cst1_i32 : i32
            spirv.Branch ^bb1(%110, %111 : i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %47 = spirv.Load "Function" %46 : i32
          %48 = spirv.Load "Function" %45 : i32
          %49 = spirv.BitwiseAnd %48, %cst65535_i32 : i32
          %50 = spirv.ShiftRightLogical %48, %cst16_i32 : i32, i32
          %51 = spirv.IMul %49, %cst18725_i32 : i32
          %52 = spirv.IMul %50, %cst18725_i32 : i32
          %53 = spirv.IMul %49, %cst146_i32 : i32
          %54 = spirv.IMul %50, %cst146_i32 : i32
          %55 = spirv.ShiftRightLogical %51, %cst16_i32 : i32, i32
          %56 = spirv.BitwiseAnd %52, %cst65535_i32 : i32
          %57 = spirv.BitwiseAnd %53, %cst65535_i32 : i32
          %58 = spirv.IAdd %55, %56 : i32
          %59 = spirv.IAdd %58, %57 : i32
          %60 = spirv.ShiftRightLogical %59, %cst16_i32 : i32, i32
          %61 = spirv.ShiftRightLogical %52, %cst16_i32 : i32, i32
          %62 = spirv.ShiftRightLogical %53, %cst16_i32 : i32, i32
          %63 = spirv.IAdd %54, %61 : i32
          %64 = spirv.IAdd %63, %62 : i32
          %65 = spirv.IAdd %64, %60 : i32
          %66 = spirv.BitwiseAnd %51, %cst65535_i32 : i32
          %67 = spirv.ShiftLeftLogical %59, %cst16_i32 : i32, i32
          %68 = spirv.BitwiseOr %66, %67 : i32
          %69 = spirv.ShiftLeftLogical %65, %cst12_i32 : i32, i32
          %70 = spirv.ShiftRightLogical %68, %cst20_i32 : i32, i32
          %71 = spirv.BitwiseAnd %68, %cst1048575_i32 : i32
          %72 = spirv.INotEqual %71, %cst0_i32 : i32
          %73 = spirv.Select %72, %cst1_i32, %cst0_i32 : i1, i32
          %74 = spirv.BitwiseOr %69, %70 : i32
          %75 = spirv.BitwiseOr %74, %73 : i32
          %76 = spirv.IAdd %47, %cst-9_i32 : i32
          %77 = spirv.UGreaterThanEqual %75, %cst134217728_i32 : i32
          %78 = spirv.BitwiseAnd %75, %cst1_i32 : i32
          %79 = spirv.ShiftRightLogical %75, %cst1_i32 : i32, i32
          %80 = spirv.BitwiseOr %79, %78 : i32
          %81 = spirv.Select %77, %80, %75 : i1, i32
          %82 = spirv.Select %77, %cst1_i32, %cst0_i32 : i1, i32
          %83 = spirv.IAdd %76, %82 : i32
          %84 = spirv.BitwiseAnd %81, %cst7_i32 : i32
          %85 = spirv.UGreaterThan %84, %cst4_i32 : i32
          %86 = spirv.IEqual %84, %cst4_i32 : i32
          %87 = spirv.BitwiseAnd %81, %cst8_i32 : i32
          %88 = spirv.INotEqual %87, %cst0_i32 : i32
          %89 = spirv.LogicalAnd %86, %88 : i1
          %90 = spirv.LogicalOr %85, %89 : i1
          %91 = spirv.Select %90, %cst1_i32, %cst0_i32 : i1, i32
          %92 = spirv.ShiftRightLogical %81, %cst3_i32 : i32, i32
          %93 = spirv.IAdd %92, %91 : i32
          %94 = spirv.UGreaterThanEqual %93, %cst16777216_i32 : i32
          %95 = spirv.ShiftRightLogical %93, %cst1_i32 : i32, i32
          %96 = spirv.Select %94, %95, %93 : i1, i32
          %97 = spirv.Select %94, %cst1_i32, %cst0_i32 : i1, i32
          %98 = spirv.IAdd %83, %97 : i32
          %99 = spirv.BitwiseAnd %96, %cst8388607_i32 : i32
          %100 = spirv.ShiftLeftLogical %98, %cst23_i32 : i32, i32
          %101 = spirv.BitwiseOr %100, %99 : i32
          %102 = spirv.SLessThan %98, %cst1_i32 : i32
          %103 = spirv.SGreaterThanEqual %98, %cst255_i32 : i32
          %104 = spirv.Select %103, %cst2139095040_i32, %101 : i1, i32
          %105 = spirv.Select %102, %cst0_i32, %104 : i1, i32
          %106 = spirv.BitwiseOr %22, %105 : i32
          spirv.Store "Function" %27, %106 : i32
          spirv.Branch ^bb3
        ^bb3:  // 2 preds: ^bb1, ^bb2
          spirv.mlir.merge
        }
        %28 = spirv.Load "Function" %27 : i32
        %29 = spirv.ShiftRightLogical %28, %cst23_i32 : i32, i32
        %30 = spirv.BitwiseAnd %28, %cst8388607_i32 : i32
        %31 = spirv.INotEqual %30, %cst0_i32 : i32
        %32 = spirv.Select %31, %cst1_i32, %cst0_i32 : i1, i32
        %33 = spirv.IAdd %29, %32 : i32
        %34 = spirv.ShiftLeftLogical %33, %cst23_i32 : i32, i32
        %35 = spirv.Bitcast %34 : i32 to f32
        %36 = spirv.IAdd %13, %6 : i32
        %37 = spirv.IAdd %36, %cst16_i32 : i32
        %38 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %37] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %38, %35 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %18 = spirv.IAdd %13, %12 : i32
      spirv.Branch ^bb1(%18 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @quantize_power_bf16_dispatch_1_reduction_Dx128_i16xf32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @quantize_power_bf16_dispatch_1_reduction_Dx128_i16xf32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @quantize_power_bf16_dispatch_1_reduction_Dx128_i16xf32 "SignedZeroInfNanPreserve", 32
}