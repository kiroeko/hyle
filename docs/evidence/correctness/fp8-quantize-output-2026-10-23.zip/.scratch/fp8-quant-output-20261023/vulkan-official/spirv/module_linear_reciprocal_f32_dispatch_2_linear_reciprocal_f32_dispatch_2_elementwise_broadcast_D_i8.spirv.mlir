spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst255_i32 = spirv.Constant 255 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst126_i32 = spirv.Constant 126 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst-2147483648_i32 = spirv.Constant -2147483648 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst2147483647_i32 = spirv.Constant 2147483647 : i32
    %cst_f32 = spirv.Constant 4.480000e+02 : f32
    %cst_f32_0 = spirv.Constant -4.480000e+02 : f32
    %cst_f32_1 = spirv.Constant 5.96046448E-8 : f32
    %cst_f32_2 = spirv.Constant 2.3509887E-38 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %14 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %15 = spirv.CompositeExtract %14[0 : i32] : vector<3xi32>
    %16 = spirv.IMul %13, %cst64_i32 : i32
    %17 = spirv.IMul %15, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
      %19 = spirv.SLessThan %18, %3 : i32
      spirv.BranchConditional %19, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %20 = spirv.ISub %3, %18 : i32
      %21 = spirv.GL.SMin %20, %cst64_i32 : i32
      %22 = spirv.SGreaterThan %21, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %22, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %24 = spirv.IAdd %18, %11 : i32
        %25 = spirv.GL.SAbs %24 : i32
        %26 = spirv.GL.SAbs %7 : i32
        %27 = spirv.UMod %25, %26 : i32
        %28 = spirv.IEqual %24, %25 : i32
        %29 = spirv.SNegate %27 : i32
        %30 = spirv.Select %28, %27, %29 : i1, i32
        %31 = spirv.SDiv %24, %7 : i32
        %32 = spirv.UDiv %30, %cst128_i32 : i32
        %33 = spirv.IMul %31, %7 : i32
        %34 = spirv.IAdd %33, %30 : i32
        %35 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %36 = spirv.Load "StorageBuffer" %35 : f32
        %37 = spirv.IMul %31, %9 : i32
        %38 = spirv.IAdd %37, %32 : i32
        %39 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %38] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %40 = spirv.Load "StorageBuffer" %39 : f32
        %41 = spirv.Bitcast %36 : f32 to i32
        %42 = spirv.BitwiseAnd %41, %cst2147483647_i32 : i32
        %43 = spirv.INotEqual %42, %cst0_i32 : i32
        %44 = spirv.ULessThan %42, %cst8388608_i32 : i32
        %45 = spirv.LogicalAnd %43, %44 : i1
        %46 = spirv.Variable : !spirv.ptr<f32, Function>
        spirv.mlir.selection {
          spirv.BranchConditional %45, ^bb1, ^bb2
        ^bb1:  // pred: ^bb0
          %104 = spirv.ConvertUToF %42 : i32 to f32
          %105 = spirv.FMul %104, %cst_f32_2 : f32
          %106 = spirv.Bitcast %105 : f32 to i32
          %107 = spirv.BitwiseAnd %41, %cst-2147483648_i32 : i32
          %108 = spirv.BitwiseOr %106, %107 : i32
          %109 = spirv.Bitcast %108 : i32 to f32
          %110 = spirv.FMul %109, %40 : f32
          %111 = spirv.FMul %110, %cst_f32_1 : f32
          spirv.Store "Function" %46, %111 : f32
          spirv.Branch ^bb3
        ^bb2:  // pred: ^bb0
          %112 = spirv.FMul %36, %40 : f32
          spirv.Store "Function" %46, %112 : f32
          spirv.Branch ^bb3
        ^bb3:  // 2 preds: ^bb1, ^bb2
          spirv.mlir.merge
        }
        %47 = spirv.Load "Function" %46 : f32
        %48 = spirv.GL.FMax %47, %cst_f32_0 : f32
        %49 = spirv.IsNan %47 : f32
        %50 = spirv.IsNan %cst_f32_0 : f32
        %51 = spirv.Select %49, %47, %48 : i1, f32
        %52 = spirv.Select %50, %cst_f32_0, %51 : i1, f32
        %53 = spirv.GL.FMin %52, %cst_f32 : f32
        %54 = spirv.IsNan %52 : f32
        %55 = spirv.IsNan %cst_f32 : f32
        %56 = spirv.Select %54, %52, %53 : i1, f32
        %57 = spirv.Select %55, %cst_f32, %56 : i1, f32
        %58 = spirv.GL.FAbs %57 : f32
        %59 = spirv.GL.FMin %58, %cst_f32 : f32
        %60 = spirv.IsNan %58 : f32
        %61 = spirv.Select %60, %58, %59 : i1, f32
        %62 = spirv.Select %55, %cst_f32, %61 : i1, f32
        %63 = spirv.Variable : !spirv.ptr<i32, Function>
        %64 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst126_i32 : i32, i32)
        ^bb1(%104: i32, %105: i32):  // 2 preds: ^bb0, ^bb2
          %106 = spirv.ULessThan %104, %105 : i32
          spirv.Store "Function" %63, %104 : i32
          spirv.Store "Function" %64, %105 : i32
          spirv.BranchConditional %106, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %107 = spirv.IAdd %104, %105 : i32
          %108 = spirv.IAdd %107, %cst1_i32 : i32
          %109 = spirv.UDiv %108, %cst2_i32 : i32
          %110 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %109] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %111 = spirv.Load "StorageBuffer" %110 : f32
          %112 = spirv.FOrdLessThanEqual %111, %62 : f32
          %113 = spirv.ISub %109, %cst1_i32 : i32
          %114 = spirv.Select %112, %109, %104 : i1, i32
          %115 = spirv.Select %112, %105, %113 : i1, i32
          spirv.Branch ^bb1(%114, %115 : i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %65 = spirv.Load "Function" %64 : i32
        %66 = spirv.Load "Function" %63 : i32
        %67 = spirv.IAdd %66, %cst1_i32 : i32
        %68 = spirv.GL.UMin %67, %cst126_i32 : i32
        %69 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %66] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %70 = spirv.Load "StorageBuffer" %69 : f32
        %71 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %68] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %72 = spirv.Load "StorageBuffer" %71 : f32
        %73 = spirv.FSub %62, %70 : f32
        %74 = spirv.FSub %62, %72 : f32
        %75 = spirv.GL.FAbs %73 : f32
        %76 = spirv.GL.FAbs %74 : f32
        %77 = spirv.FOrdLessThan %76, %75 : f32
        %78 = spirv.FOrdEqual %76, %75 : f32
        %79 = spirv.BitwiseAnd %66, %cst1_i32 : i32
        %80 = spirv.BitwiseAnd %68, %cst1_i32 : i32
        %81 = spirv.INotEqual %79, %cst0_i32 : i32
        %82 = spirv.IEqual %80, %cst0_i32 : i32
        %83 = spirv.LogicalAnd %78, %82 : i1
        %84 = spirv.LogicalAnd %83, %81 : i1
        %85 = spirv.LogicalOr %77, %84 : i1
        %86 = spirv.Select %85, %68, %66 : i1, i32
        %87 = spirv.Bitcast %57 : f32 to i32
        %88 = spirv.ShiftRightLogical %87, %cst24_i32 : i32, i32
        %89 = spirv.BitwiseAnd %88, %cst128_i32 : i32
        %90 = spirv.BitwiseOr %86, %89 : i32
        %91 = spirv.BitwiseAnd %90, %cst255_i32 : i32
        %92 = spirv.IAdd %1, %18 : i32
        %93 = spirv.IAdd %92, %11 : i32
        %94 = spirv.UMod %93, %cst4_i32 : i32
        %95 = spirv.IMul %94, %cst8_i32 : i32
        %96 = spirv.ShiftLeftLogical %cst255_i32, %95 : i32, i32
        %97 = spirv.Not %96 : i32
        %98 = spirv.BitwiseAnd %91, %cst255_i32 : i32
        %99 = spirv.ShiftLeftLogical %98, %95 : i32, i32
        %100 = spirv.SDiv %93, %cst4_i32 : i32
        %101 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %100] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %102 = spirv.AtomicAnd <Device> <AcquireRelease|UniformMemory> %101, %97 : !spirv.ptr<i32, StorageBuffer>
        %103 = spirv.AtomicOr <Device> <AcquireRelease|UniformMemory> %101, %99 : !spirv.ptr<i32, StorageBuffer>
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %23 = spirv.IAdd %18, %17 : i32
      spirv.Branch ^bb1(%23 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 "SignedZeroInfNanPreserve", 32
}