spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.func @quantize_reciprocal_bf16_dispatch_2_elementwise_broadcast_D_i8() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst126_i32 = spirv.Constant 126 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst127_i32 = spirv.Constant 127 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst16777216_i32 = spirv.Constant 16777216 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst134217728_i32 = spirv.Constant 134217728 : i32
    %cst1048575_i32 = spirv.Constant 1048575 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst65535_i32 = spirv.Constant 65535 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2139095040_i32 = spirv.Constant 2139095040 : i32
    %cst2147483647_i32 = spirv.Constant 2147483647 : i32
    %cst-2147483648_i32 = spirv.Constant -2147483648 : i32
    %cst_f32 = spirv.Constant 4.480000e+02 : f32
    %cst_f32_0 = spirv.Constant -4.480000e+02 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %14 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %15 = spirv.CompositeExtract %14[0 : i32] : vector<3xi32>
    %16 = spirv.IMul %13, %cst64_i32 : i32
    %17 = spirv.IMul %15, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
      %19 = spirv.SLessThan %18, %3 : i32
      spirv.BranchConditional %19, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %20 = spirv.ISub %3, %18 : i32
      %21 = spirv.GL.SMin %20, %cst64_i32 : i32
      %22 = spirv.SGreaterThan %21, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %22, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %24 = spirv.IAdd %18, %11 : i32
        %25 = spirv.GL.SAbs %24 : i32
        %26 = spirv.GL.SAbs %7 : i32
        %27 = spirv.UMod %25, %26 : i32
        %28 = spirv.IEqual %24, %25 : i32
        %29 = spirv.SNegate %27 : i32
        %30 = spirv.Select %28, %27, %29 : i1, i32
        %31 = spirv.SDiv %24, %7 : i32
        %32 = spirv.UDiv %30, %cst128_i32 : i32
        %33 = spirv.IMul %31, %7 : i32
        %34 = spirv.IAdd %33, %30 : i32
        %35 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %36 = spirv.Load "StorageBuffer" %35 : i16
        %37 = spirv.UConvert %36 : i16 to i32
        %38 = spirv.ShiftLeftLogical %37, %cst16_i32 : i32, i32
        %39 = spirv.IMul %31, %9 : i32
        %40 = spirv.IAdd %39, %32 : i32
        %41 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %40] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %42 = spirv.Load "StorageBuffer" %41 : f32
        %43 = spirv.Bitcast %42 : f32 to i32
        %44 = spirv.BitwiseAnd %38, %cst-2147483648_i32 : i32
        %45 = spirv.BitwiseAnd %38, %cst2147483647_i32 : i32
        %46 = spirv.BitwiseAnd %43, %cst2147483647_i32 : i32
        %47 = spirv.IEqual %45, %cst0_i32 : i32
        %48 = spirv.UGreaterThanEqual %45, %cst2139095040_i32 : i32
        %49 = spirv.UGreaterThanEqual %46, %cst2139095040_i32 : i32
        %50 = spirv.ShiftRightLogical %46, %cst23_i32 : i32, i32
        %51 = spirv.IEqual %50, %cst0_i32 : i32
        %52 = spirv.LogicalOr %47, %48 : i1
        %53 = spirv.LogicalOr %49, %51 : i1
        %54 = spirv.LogicalOr %52, %53 : i1
        %55 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.selection {
          spirv.BranchConditional %54, ^bb1, ^bb2
        ^bb1:  // pred: ^bb0
          spirv.Store "Function" %55, %44 : i32
          spirv.Branch ^bb3
        ^bb2:  // pred: ^bb0
          %114 = spirv.ShiftRightLogical %45, %cst23_i32 : i32, i32
          %115 = spirv.BitwiseAnd %38, %cst8388607_i32 : i32
          %116 = spirv.INotEqual %114, %cst0_i32 : i32
          %117 = spirv.Select %116, %cst8388608_i32, %cst0_i32 : i1, i32
          %118 = spirv.BitwiseOr %115, %117 : i32
          %119 = spirv.Select %116, %114, %cst1_i32 : i1, i32
          %120 = spirv.Variable : !spirv.ptr<i32, Function>
          %121 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%118, %119 : i32, i32)
          ^bb1(%187: i32, %188: i32):  // 2 preds: ^bb0, ^bb2
            %189 = spirv.ULessThan %187, %cst8388608_i32 : i32
            spirv.Store "Function" %120, %187 : i32
            spirv.Store "Function" %121, %188 : i32
            spirv.BranchConditional %189, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %190 = spirv.ShiftLeftLogical %187, %cst1_i32 : i32, i32
            %191 = spirv.ISub %188, %cst1_i32 : i32
            spirv.Branch ^bb1(%190, %191 : i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %122 = spirv.Load "Function" %121 : i32
          %123 = spirv.Load "Function" %120 : i32
          %124 = spirv.BitwiseAnd %43, %cst8388607_i32 : i32
          %125 = spirv.BitwiseOr %124, %cst8388608_i32 : i32
          %126 = spirv.BitwiseAnd %123, %cst65535_i32 : i32
          %127 = spirv.ShiftRightLogical %123, %cst16_i32 : i32, i32
          %128 = spirv.BitwiseAnd %125, %cst65535_i32 : i32
          %129 = spirv.ShiftRightLogical %125, %cst16_i32 : i32, i32
          %130 = spirv.IMul %126, %128 : i32
          %131 = spirv.IMul %127, %128 : i32
          %132 = spirv.IMul %126, %129 : i32
          %133 = spirv.IMul %127, %129 : i32
          %134 = spirv.ShiftRightLogical %130, %cst16_i32 : i32, i32
          %135 = spirv.BitwiseAnd %131, %cst65535_i32 : i32
          %136 = spirv.BitwiseAnd %132, %cst65535_i32 : i32
          %137 = spirv.IAdd %134, %135 : i32
          %138 = spirv.IAdd %137, %136 : i32
          %139 = spirv.ShiftRightLogical %138, %cst16_i32 : i32, i32
          %140 = spirv.ShiftRightLogical %131, %cst16_i32 : i32, i32
          %141 = spirv.ShiftRightLogical %132, %cst16_i32 : i32, i32
          %142 = spirv.IAdd %133, %140 : i32
          %143 = spirv.IAdd %142, %141 : i32
          %144 = spirv.IAdd %143, %139 : i32
          %145 = spirv.BitwiseAnd %130, %cst65535_i32 : i32
          %146 = spirv.ShiftLeftLogical %138, %cst16_i32 : i32, i32
          %147 = spirv.BitwiseOr %145, %146 : i32
          %148 = spirv.ShiftLeftLogical %144, %cst12_i32 : i32, i32
          %149 = spirv.ShiftRightLogical %147, %cst20_i32 : i32, i32
          %150 = spirv.BitwiseAnd %147, %cst1048575_i32 : i32
          %151 = spirv.INotEqual %150, %cst0_i32 : i32
          %152 = spirv.Select %151, %cst1_i32, %cst0_i32 : i1, i32
          %153 = spirv.BitwiseOr %148, %149 : i32
          %154 = spirv.BitwiseOr %153, %152 : i32
          %155 = spirv.IAdd %122, %50 : i32
          %156 = spirv.ISub %155, %cst127_i32 : i32
          %157 = spirv.UGreaterThanEqual %154, %cst134217728_i32 : i32
          %158 = spirv.BitwiseAnd %154, %cst1_i32 : i32
          %159 = spirv.ShiftRightLogical %154, %cst1_i32 : i32, i32
          %160 = spirv.BitwiseOr %159, %158 : i32
          %161 = spirv.Select %157, %160, %154 : i1, i32
          %162 = spirv.Select %157, %cst1_i32, %cst0_i32 : i1, i32
          %163 = spirv.IAdd %156, %162 : i32
          %164 = spirv.BitwiseAnd %161, %cst7_i32 : i32
          %165 = spirv.UGreaterThan %164, %cst4_i32 : i32
          %166 = spirv.IEqual %164, %cst4_i32 : i32
          %167 = spirv.BitwiseAnd %161, %cst8_i32 : i32
          %168 = spirv.INotEqual %167, %cst0_i32 : i32
          %169 = spirv.LogicalAnd %166, %168 : i1
          %170 = spirv.LogicalOr %165, %169 : i1
          %171 = spirv.Select %170, %cst1_i32, %cst0_i32 : i1, i32
          %172 = spirv.ShiftRightLogical %161, %cst3_i32 : i32, i32
          %173 = spirv.IAdd %172, %171 : i32
          %174 = spirv.UGreaterThanEqual %173, %cst16777216_i32 : i32
          %175 = spirv.ShiftRightLogical %173, %cst1_i32 : i32, i32
          %176 = spirv.Select %174, %175, %173 : i1, i32
          %177 = spirv.Select %174, %cst1_i32, %cst0_i32 : i1, i32
          %178 = spirv.IAdd %163, %177 : i32
          %179 = spirv.BitwiseAnd %176, %cst8388607_i32 : i32
          %180 = spirv.ShiftLeftLogical %178, %cst23_i32 : i32, i32
          %181 = spirv.BitwiseOr %180, %179 : i32
          %182 = spirv.SLessThan %178, %cst1_i32 : i32
          %183 = spirv.SGreaterThanEqual %178, %cst255_i32 : i32
          %184 = spirv.Select %183, %cst2139095040_i32, %181 : i1, i32
          %185 = spirv.Select %182, %cst0_i32, %184 : i1, i32
          %186 = spirv.BitwiseOr %44, %185 : i32
          spirv.Store "Function" %55, %186 : i32
          spirv.Branch ^bb3
        ^bb3:  // 2 preds: ^bb1, ^bb2
          spirv.mlir.merge
        }
        %56 = spirv.Load "Function" %55 : i32
        %57 = spirv.Bitcast %56 : i32 to f32
        %58 = spirv.GL.FMax %57, %cst_f32_0 : f32
        %59 = spirv.IsNan %57 : f32
        %60 = spirv.IsNan %cst_f32_0 : f32
        %61 = spirv.Select %59, %57, %58 : i1, f32
        %62 = spirv.Select %60, %cst_f32_0, %61 : i1, f32
        %63 = spirv.GL.FMin %62, %cst_f32 : f32
        %64 = spirv.IsNan %62 : f32
        %65 = spirv.IsNan %cst_f32 : f32
        %66 = spirv.Select %64, %62, %63 : i1, f32
        %67 = spirv.Select %65, %cst_f32, %66 : i1, f32
        %68 = spirv.GL.FAbs %67 : f32
        %69 = spirv.GL.FMin %68, %cst_f32 : f32
        %70 = spirv.IsNan %68 : f32
        %71 = spirv.Select %70, %68, %69 : i1, f32
        %72 = spirv.Select %65, %cst_f32, %71 : i1, f32
        %73 = spirv.Variable : !spirv.ptr<i32, Function>
        %74 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst126_i32 : i32, i32)
        ^bb1(%114: i32, %115: i32):  // 2 preds: ^bb0, ^bb2
          %116 = spirv.ULessThan %114, %115 : i32
          spirv.Store "Function" %73, %114 : i32
          spirv.Store "Function" %74, %115 : i32
          spirv.BranchConditional %116, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %117 = spirv.IAdd %114, %115 : i32
          %118 = spirv.IAdd %117, %cst1_i32 : i32
          %119 = spirv.UDiv %118, %cst2_i32 : i32
          %120 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %119] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %121 = spirv.Load "StorageBuffer" %120 : f32
          %122 = spirv.FOrdLessThanEqual %121, %72 : f32
          %123 = spirv.ISub %119, %cst1_i32 : i32
          %124 = spirv.Select %122, %119, %114 : i1, i32
          %125 = spirv.Select %122, %115, %123 : i1, i32
          spirv.Branch ^bb1(%124, %125 : i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %75 = spirv.Load "Function" %74 : i32
        %76 = spirv.Load "Function" %73 : i32
        %77 = spirv.IAdd %76, %cst1_i32 : i32
        %78 = spirv.GL.UMin %77, %cst126_i32 : i32
        %79 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %76] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %80 = spirv.Load "StorageBuffer" %79 : f32
        %81 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %78] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %82 = spirv.Load "StorageBuffer" %81 : f32
        %83 = spirv.FSub %72, %80 : f32
        %84 = spirv.FSub %72, %82 : f32
        %85 = spirv.GL.FAbs %83 : f32
        %86 = spirv.GL.FAbs %84 : f32
        %87 = spirv.FOrdLessThan %86, %85 : f32
        %88 = spirv.FOrdEqual %86, %85 : f32
        %89 = spirv.BitwiseAnd %76, %cst1_i32 : i32
        %90 = spirv.BitwiseAnd %78, %cst1_i32 : i32
        %91 = spirv.INotEqual %89, %cst0_i32 : i32
        %92 = spirv.IEqual %90, %cst0_i32 : i32
        %93 = spirv.LogicalAnd %88, %92 : i1
        %94 = spirv.LogicalAnd %93, %91 : i1
        %95 = spirv.LogicalOr %87, %94 : i1
        %96 = spirv.Select %95, %78, %76 : i1, i32
        %97 = spirv.Bitcast %67 : f32 to i32
        %98 = spirv.ShiftRightLogical %97, %cst24_i32 : i32, i32
        %99 = spirv.BitwiseAnd %98, %cst128_i32 : i32
        %100 = spirv.BitwiseOr %96, %99 : i32
        %101 = spirv.BitwiseAnd %100, %cst255_i32 : i32
        %102 = spirv.IAdd %1, %18 : i32
        %103 = spirv.IAdd %102, %11 : i32
        %104 = spirv.UMod %103, %cst4_i32 : i32
        %105 = spirv.IMul %104, %cst8_i32 : i32
        %106 = spirv.ShiftLeftLogical %cst255_i32, %105 : i32, i32
        %107 = spirv.Not %106 : i32
        %108 = spirv.BitwiseAnd %101, %cst255_i32 : i32
        %109 = spirv.ShiftLeftLogical %108, %105 : i32, i32
        %110 = spirv.SDiv %103, %cst4_i32 : i32
        %111 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %110] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %112 = spirv.AtomicAnd <Device> <AcquireRelease|UniformMemory> %111, %107 : !spirv.ptr<i32, StorageBuffer>
        %113 = spirv.AtomicOr <Device> <AcquireRelease|UniformMemory> %111, %109 : !spirv.ptr<i32, StorageBuffer>
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %23 = spirv.IAdd %18, %17 : i32
      spirv.Branch ^bb1(%23 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @quantize_reciprocal_bf16_dispatch_2_elementwise_broadcast_D_i8, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @quantize_reciprocal_bf16_dispatch_2_elementwise_broadcast_D_i8 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @quantize_reciprocal_bf16_dispatch_2_elementwise_broadcast_D_i8 "SignedZeroInfNanPreserve", 32
}