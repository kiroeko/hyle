spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.func @quantize_normal_f32_dispatch_2_elementwise_broadcast_D_i8() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst126_i32 = spirv.Constant 126 : i32
    %cst26_i32 = spirv.Constant 26 : i32
    %cst27_i32 = spirv.Constant 27 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst127_i32 = spirv.Constant 127 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst16777216_i32 = spirv.Constant 16777216 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2139095040_i32 = spirv.Constant 2139095040 : i32
    %cst2147483647_i32 = spirv.Constant 2147483647 : i32
    %cst-2147483648_i32 = spirv.Constant -2147483648 : i32
    %cst_f32 = spirv.Constant 4.480000e+02 : f32
    %cst_f32_0 = spirv.Constant -4.480000e+02 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %14 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %15 = spirv.CompositeExtract %14[0 : i32] : vector<3xi32>
    %16 = spirv.IMul %13, %cst64_i32 : i32
    %17 = spirv.IMul %15, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
      %19 = spirv.SLessThan %18, %3 : i32
      spirv.BranchConditional %19, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %20 = spirv.ISub %3, %18 : i32
      %21 = spirv.GL.SMin %20, %cst64_i32 : i32
      %22 = spirv.SGreaterThan %21, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %22, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %24 = spirv.IAdd %18, %11 : i32
        %25 = spirv.GL.SAbs %24 : i32
        %26 = spirv.GL.SAbs %7 : i32
        %27 = spirv.UMod %25, %26 : i32
        %28 = spirv.IEqual %24, %25 : i32
        %29 = spirv.SNegate %27 : i32
        %30 = spirv.Select %28, %27, %29 : i1, i32
        %31 = spirv.SDiv %24, %7 : i32
        %32 = spirv.UDiv %30, %cst128_i32 : i32
        %33 = spirv.IMul %31, %7 : i32
        %34 = spirv.IAdd %33, %30 : i32
        %35 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %36 = spirv.Load "StorageBuffer" %35 : f32
        %37 = spirv.IMul %31, %9 : i32
        %38 = spirv.IAdd %37, %32 : i32
        %39 = spirv.IAdd %38, %cst16_i32 : i32
        %40 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %39] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %41 = spirv.Load "StorageBuffer" %40 : f32
        %42 = spirv.Bitcast %36 : f32 to i32
        %43 = spirv.Bitcast %41 : f32 to i32
        %44 = spirv.BitwiseAnd %42, %cst-2147483648_i32 : i32
        %45 = spirv.BitwiseAnd %42, %cst2147483647_i32 : i32
        %46 = spirv.BitwiseAnd %43, %cst2147483647_i32 : i32
        %47 = spirv.IEqual %45, %cst0_i32 : i32
        %48 = spirv.UGreaterThanEqual %45, %cst2139095040_i32 : i32
        %49 = spirv.UGreaterThanEqual %46, %cst2139095040_i32 : i32
        %50 = spirv.ShiftRightLogical %46, %cst23_i32 : i32, i32
        %51 = spirv.IEqual %50, %cst0_i32 : i32
        %52 = spirv.LogicalOr %47, %48 : i1
        %53 = spirv.LogicalOr %49, %51 : i1
        %54 = spirv.LogicalOr %52, %53 : i1
        %55 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.selection {
          spirv.BranchConditional %54, ^bb1, ^bb2
        ^bb1:  // pred: ^bb0
          spirv.Store "Function" %55, %44 : i32
          spirv.Branch ^bb3
        ^bb2:  // pred: ^bb0
          %114 = spirv.ShiftRightLogical %45, %cst23_i32 : i32, i32
          %115 = spirv.BitwiseAnd %42, %cst8388607_i32 : i32
          %116 = spirv.INotEqual %114, %cst0_i32 : i32
          %117 = spirv.Select %116, %cst8388608_i32, %cst0_i32 : i1, i32
          %118 = spirv.BitwiseOr %115, %117 : i32
          %119 = spirv.Select %116, %114, %cst1_i32 : i1, i32
          %120 = spirv.Variable : !spirv.ptr<i32, Function>
          %121 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%118, %119 : i32, i32)
          ^bb1(%163: i32, %164: i32):  // 2 preds: ^bb0, ^bb2
            %165 = spirv.ULessThan %163, %cst8388608_i32 : i32
            spirv.Store "Function" %120, %163 : i32
            spirv.Store "Function" %121, %164 : i32
            spirv.BranchConditional %165, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %166 = spirv.ShiftLeftLogical %163, %cst1_i32 : i32, i32
            %167 = spirv.ISub %164, %cst1_i32 : i32
            spirv.Branch ^bb1(%166, %167 : i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %122 = spirv.Load "Function" %121 : i32
          %123 = spirv.Load "Function" %120 : i32
          %124 = spirv.BitwiseAnd %43, %cst8388607_i32 : i32
          %125 = spirv.BitwiseOr %124, %cst8388608_i32 : i32
          %126 = spirv.ISub %122, %50 : i32
          %127 = spirv.IAdd %126, %cst127_i32 : i32
          %128 = spirv.ULessThan %123, %125 : i32
          %129 = spirv.ShiftLeftLogical %123, %cst1_i32 : i32, i32
          %130 = spirv.Select %128, %129, %123 : i1, i32
          %131 = spirv.Select %128, %cst1_i32, %cst0_i32 : i1, i32
          %132 = spirv.ISub %127, %131 : i32
          %133 = spirv.Variable : !spirv.ptr<i32, Function>
          %134 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%cst0_i32, %cst0_i32, %130 : i32, i32, i32)
          ^bb1(%163: i32, %164: i32, %165: i32):  // 2 preds: ^bb0, ^bb2
            %166 = spirv.SLessThan %163, %cst27_i32 : i32
            spirv.BranchConditional %166, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %167 = spirv.UGreaterThanEqual %165, %125 : i32
            %168 = spirv.Select %167, %125, %cst0_i32 : i1, i32
            %169 = spirv.ISub %165, %168 : i32
            %170 = spirv.ShiftLeftLogical %164, %cst1_i32 : i32, i32
            %171 = spirv.Select %167, %cst1_i32, %cst0_i32 : i1, i32
            %172 = spirv.BitwiseOr %170, %171 : i32
            %173 = spirv.ShiftLeftLogical %169, %cst1_i32 : i32, i32
            %174 = spirv.IEqual %163, %cst26_i32 : i32
            %175 = spirv.Select %174, %169, %173 : i1, i32
            spirv.Store "Function" %133, %172 : i32
            spirv.Store "Function" %134, %175 : i32
            %176 = spirv.IAdd %163, %cst1_i32 : i32
            spirv.Branch ^bb1(%176, %172, %175 : i32, i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %135 = spirv.Load "Function" %134 : i32
          %136 = spirv.Load "Function" %133 : i32
          %137 = spirv.INotEqual %135, %cst0_i32 : i32
          %138 = spirv.Select %137, %cst1_i32, %cst0_i32 : i1, i32
          %139 = spirv.BitwiseOr %136, %138 : i32
          %140 = spirv.BitwiseAnd %139, %cst7_i32 : i32
          %141 = spirv.UGreaterThan %140, %cst4_i32 : i32
          %142 = spirv.IEqual %140, %cst4_i32 : i32
          %143 = spirv.BitwiseAnd %139, %cst8_i32 : i32
          %144 = spirv.INotEqual %143, %cst0_i32 : i32
          %145 = spirv.LogicalAnd %142, %144 : i1
          %146 = spirv.LogicalOr %141, %145 : i1
          %147 = spirv.Select %146, %cst1_i32, %cst0_i32 : i1, i32
          %148 = spirv.ShiftRightLogical %139, %cst3_i32 : i32, i32
          %149 = spirv.IAdd %148, %147 : i32
          %150 = spirv.UGreaterThanEqual %149, %cst16777216_i32 : i32
          %151 = spirv.ShiftRightLogical %149, %cst1_i32 : i32, i32
          %152 = spirv.Select %150, %151, %149 : i1, i32
          %153 = spirv.Select %150, %cst1_i32, %cst0_i32 : i1, i32
          %154 = spirv.IAdd %132, %153 : i32
          %155 = spirv.BitwiseAnd %152, %cst8388607_i32 : i32
          %156 = spirv.ShiftLeftLogical %154, %cst23_i32 : i32, i32
          %157 = spirv.BitwiseOr %156, %155 : i32
          %158 = spirv.SLessThan %154, %cst1_i32 : i32
          %159 = spirv.SGreaterThanEqual %154, %cst255_i32 : i32
          %160 = spirv.Select %159, %cst2139095040_i32, %157 : i1, i32
          %161 = spirv.Select %158, %cst0_i32, %160 : i1, i32
          %162 = spirv.BitwiseOr %44, %161 : i32
          spirv.Store "Function" %55, %162 : i32
          spirv.Branch ^bb3
        ^bb3:  // 2 preds: ^bb1, ^bb2
          spirv.mlir.merge
        }
        %56 = spirv.Load "Function" %55 : i32
        %57 = spirv.Bitcast %56 : i32 to f32
        %58 = spirv.GL.FMax %57, %cst_f32_0 : f32
        %59 = spirv.IsNan %57 : f32
        %60 = spirv.IsNan %cst_f32_0 : f32
        %61 = spirv.Select %59, %57, %58 : i1, f32
        %62 = spirv.Select %60, %cst_f32_0, %61 : i1, f32
        %63 = spirv.GL.FMin %62, %cst_f32 : f32
        %64 = spirv.IsNan %62 : f32
        %65 = spirv.IsNan %cst_f32 : f32
        %66 = spirv.Select %64, %62, %63 : i1, f32
        %67 = spirv.Select %65, %cst_f32, %66 : i1, f32
        %68 = spirv.GL.FAbs %67 : f32
        %69 = spirv.GL.FMin %68, %cst_f32 : f32
        %70 = spirv.IsNan %68 : f32
        %71 = spirv.Select %70, %68, %69 : i1, f32
        %72 = spirv.Select %65, %cst_f32, %71 : i1, f32
        %73 = spirv.Variable : !spirv.ptr<i32, Function>
        %74 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst126_i32 : i32, i32)
        ^bb1(%114: i32, %115: i32):  // 2 preds: ^bb0, ^bb2
          %116 = spirv.ULessThan %114, %115 : i32
          spirv.Store "Function" %73, %114 : i32
          spirv.Store "Function" %74, %115 : i32
          spirv.BranchConditional %116, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %117 = spirv.IAdd %114, %115 : i32
          %118 = spirv.IAdd %117, %cst1_i32 : i32
          %119 = spirv.UDiv %118, %cst2_i32 : i32
          %120 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %119] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %121 = spirv.Load "StorageBuffer" %120 : f32
          %122 = spirv.FOrdLessThanEqual %121, %72 : f32
          %123 = spirv.ISub %119, %cst1_i32 : i32
          %124 = spirv.Select %122, %119, %114 : i1, i32
          %125 = spirv.Select %122, %115, %123 : i1, i32
          spirv.Branch ^bb1(%124, %125 : i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %75 = spirv.Load "Function" %74 : i32
        %76 = spirv.Load "Function" %73 : i32
        %77 = spirv.IAdd %76, %cst1_i32 : i32
        %78 = spirv.GL.UMin %77, %cst126_i32 : i32
        %79 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %76] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %80 = spirv.Load "StorageBuffer" %79 : f32
        %81 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %78] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %82 = spirv.Load "StorageBuffer" %81 : f32
        %83 = spirv.FSub %72, %80 : f32
        %84 = spirv.FSub %72, %82 : f32
        %85 = spirv.GL.FAbs %83 : f32
        %86 = spirv.GL.FAbs %84 : f32
        %87 = spirv.FOrdLessThan %86, %85 : f32
        %88 = spirv.FOrdEqual %86, %85 : f32
        %89 = spirv.BitwiseAnd %76, %cst1_i32 : i32
        %90 = spirv.BitwiseAnd %78, %cst1_i32 : i32
        %91 = spirv.INotEqual %89, %cst0_i32 : i32
        %92 = spirv.IEqual %90, %cst0_i32 : i32
        %93 = spirv.LogicalAnd %88, %92 : i1
        %94 = spirv.LogicalAnd %93, %91 : i1
        %95 = spirv.LogicalOr %87, %94 : i1
        %96 = spirv.Select %95, %78, %76 : i1, i32
        %97 = spirv.Bitcast %67 : f32 to i32
        %98 = spirv.ShiftRightLogical %97, %cst24_i32 : i32, i32
        %99 = spirv.BitwiseAnd %98, %cst128_i32 : i32
        %100 = spirv.BitwiseOr %96, %99 : i32
        %101 = spirv.BitwiseAnd %100, %cst255_i32 : i32
        %102 = spirv.IAdd %1, %18 : i32
        %103 = spirv.IAdd %102, %11 : i32
        %104 = spirv.UMod %103, %cst4_i32 : i32
        %105 = spirv.IMul %104, %cst8_i32 : i32
        %106 = spirv.ShiftLeftLogical %cst255_i32, %105 : i32, i32
        %107 = spirv.Not %106 : i32
        %108 = spirv.BitwiseAnd %101, %cst255_i32 : i32
        %109 = spirv.ShiftLeftLogical %108, %105 : i32, i32
        %110 = spirv.SDiv %103, %cst4_i32 : i32
        %111 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %110] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %112 = spirv.AtomicAnd <Device> <AcquireRelease|UniformMemory> %111, %107 : !spirv.ptr<i32, StorageBuffer>
        %113 = spirv.AtomicOr <Device> <AcquireRelease|UniformMemory> %111, %109 : !spirv.ptr<i32, StorageBuffer>
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %23 = spirv.IAdd %18, %17 : i32
      spirv.Branch ^bb1(%23 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @quantize_normal_f32_dispatch_2_elementwise_broadcast_D_i8, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @quantize_normal_f32_dispatch_2_elementwise_broadcast_D_i8 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @quantize_normal_f32_dispatch_2_elementwise_broadcast_D_i8 "SignedZeroInfNanPreserve", 32
}