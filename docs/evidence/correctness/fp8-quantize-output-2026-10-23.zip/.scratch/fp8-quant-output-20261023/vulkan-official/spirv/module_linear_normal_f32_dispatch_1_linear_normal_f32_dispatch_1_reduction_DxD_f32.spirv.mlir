spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__workgroup_mem__6 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_normal_f32_dispatch_1_reduction_DxD_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst1_i32 = spirv.Constant 1 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst9_i32 = spirv.Constant 9 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst14680064_i32 = spirv.Constant 14680064 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst1_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst3_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.Bitcast %5 : i32 to f32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %7 = spirv.UDiv %1, %cst4_i32 : i32
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %8 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %9 = spirv.CompositeExtract %8[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %14 = spirv.IMul %11, %cst64_i32 : i32
    %15 = spirv.IMul %13, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%14 : i32)
    ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb2
      %17 = spirv.SLessThan %16, %3 : i32
      spirv.BranchConditional %17, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %18 = spirv.ISub %3, %16 : i32
      %19 = spirv.GL.SMin %18, %cst64_i32 : i32
      %__workgroup_mem__6_addr = spirv.mlir.addressof @__workgroup_mem__6 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
      %20 = spirv.SGreaterThan %19, %9 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %20, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %22 = spirv.AccessChain %__workgroup_mem__6_addr[%cst0_i32, %9] : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>, i32, i32 -> !spirv.ptr<f32, Workgroup>
        spirv.Store "Workgroup" %22, %6 : f32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%48: i32):  // 2 preds: ^bb0, ^bb2
          %49 = spirv.SLessThan %48, %cst128_i32 : i32
          spirv.BranchConditional %49, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %50 = spirv.IMul %16, %cst128_i32 : i32
          %51 = spirv.IAdd %48, %50 : i32
          %52 = spirv.IMul %9, %cst128_i32 : i32
          %53 = spirv.IAdd %51, %52 : i32
          %54 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %53] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %55 = spirv.Load "StorageBuffer" %54 : f32
          %56 = spirv.Load "Workgroup" %22 : f32
          %57 = spirv.GL.FAbs %55 : f32
          %58 = spirv.GL.FMax %57, %56 : f32
          %59 = spirv.IsNan %57 : f32
          %60 = spirv.IsNan %56 : f32
          %61 = spirv.Select %59, %57, %58 : i1, f32
          %62 = spirv.Select %60, %56, %61 : i1, f32
          spirv.Store "Workgroup" %22, %62 : f32
          %63 = spirv.IAdd %48, %cst1_i32 : i32
          spirv.Branch ^bb1(%63 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %23 = spirv.Load "Workgroup" %22 : f32
        %24 = spirv.Bitcast %23 : f32 to i32
        %25 = spirv.BitwiseAnd %24, %cst8388607_i32 : i32
        %26 = spirv.BitwiseOr %25, %cst8388608_i32 : i32
        %27 = spirv.UGreaterThanEqual %26, %cst14680064_i32 : i32
        %28 = spirv.Select %27, %cst2_i32, %cst3_i32 : i1, i32
        %29 = spirv.ShiftLeftLogical %26, %28 : i32, i32
        %30 = spirv.UDiv %29, %cst7_i32 : i32
        %31 = spirv.UMod %29, %cst7_i32 : i32
        %32 = spirv.UGreaterThanEqual %31, %cst4_i32 : i32
        %33 = spirv.Select %32, %cst1_i32, %cst0_i32 : i1, i32
        %34 = spirv.IAdd %30, %33 : i32
        %35 = spirv.ShiftRightLogical %24, %cst23_i32 : i32, i32
        %36 = spirv.BitwiseAnd %35, %cst255_i32 : i32
        %37 = spirv.Select %27, %cst8_i32, %cst9_i32 : i1, i32
        %38 = spirv.ISub %36, %37 : i32
        %39 = spirv.ShiftLeftLogical %38, %cst23_i32 : i32, i32
        %40 = spirv.BitwiseAnd %34, %cst8388607_i32 : i32
        %41 = spirv.BitwiseOr %39, %40 : i32
        %42 = spirv.Bitcast %41 : i32 to f32
        %43 = spirv.IEqual %36, %cst255_i32 : i32
        %44 = spirv.Select %43, %23, %42 : i1, f32
        %45 = spirv.IAdd %16, %9 : i32
        %46 = spirv.IAdd %45, %7 : i32
        %47 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %46] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %47, %44 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %21 = spirv.IAdd %16, %15 : i32
      spirv.Branch ^bb1(%21 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_normal_f32_dispatch_1_reduction_DxD_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @linear_normal_f32_dispatch_1_reduction_DxD_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @linear_normal_f32_dispatch_1_reduction_DxD_f32 "SignedZeroInfNanPreserve", 32
}