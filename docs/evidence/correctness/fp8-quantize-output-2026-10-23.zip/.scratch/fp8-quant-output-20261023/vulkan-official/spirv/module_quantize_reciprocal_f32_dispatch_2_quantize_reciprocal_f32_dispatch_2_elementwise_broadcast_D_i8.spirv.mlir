spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.func @quantize_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst126_i32 = spirv.Constant 126 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst127_i32 = spirv.Constant 127 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst16777216_i32 = spirv.Constant 16777216 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst134217728_i32 = spirv.Constant 134217728 : i32
    %cst1048575_i32 = spirv.Constant 1048575 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst65535_i32 = spirv.Constant 65535 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2139095040_i32 = spirv.Constant 2139095040 : i32
    %cst2147483647_i32 = spirv.Constant 2147483647 : i32
    %cst-2147483648_i32 = spirv.Constant -2147483648 : i32
    %cst_f32 = spirv.Constant 4.480000e+02 : f32
    %cst_f32_0 = spirv.Constant -4.480000e+02 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %14 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %15 = spirv.CompositeExtract %14[0 : i32] : vector<3xi32>
    %16 = spirv.IMul %13, %cst64_i32 : i32
    %17 = spirv.IMul %15, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
      %19 = spirv.SLessThan %18, %3 : i32
      spirv.BranchConditional %19, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %20 = spirv.ISub %3, %18 : i32
      %21 = spirv.GL.SMin %20, %cst64_i32 : i32
      %22 = spirv.SGreaterThan %21, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %22, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %24 = spirv.IAdd %18, %11 : i32
        %25 = spirv.GL.SAbs %24 : i32
        %26 = spirv.GL.SAbs %7 : i32
        %27 = spirv.UMod %25, %26 : i32
        %28 = spirv.IEqual %24, %25 : i32
        %29 = spirv.SNegate %27 : i32
        %30 = spirv.Select %28, %27, %29 : i1, i32
        %31 = spirv.SDiv %24, %7 : i32
        %32 = spirv.UDiv %30, %cst128_i32 : i32
        %33 = spirv.IMul %31, %7 : i32
        %34 = spirv.IAdd %33, %30 : i32
        %35 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %36 = spirv.Load "StorageBuffer" %35 : f32
        %37 = spirv.IMul %31, %9 : i32
        %38 = spirv.IAdd %37, %32 : i32
        %39 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %38] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %40 = spirv.Load "StorageBuffer" %39 : f32
        %41 = spirv.Bitcast %36 : f32 to i32
        %42 = spirv.Bitcast %40 : f32 to i32
        %43 = spirv.BitwiseAnd %41, %cst-2147483648_i32 : i32
        %44 = spirv.BitwiseAnd %41, %cst2147483647_i32 : i32
        %45 = spirv.BitwiseAnd %42, %cst2147483647_i32 : i32
        %46 = spirv.IEqual %44, %cst0_i32 : i32
        %47 = spirv.UGreaterThanEqual %44, %cst2139095040_i32 : i32
        %48 = spirv.UGreaterThanEqual %45, %cst2139095040_i32 : i32
        %49 = spirv.ShiftRightLogical %45, %cst23_i32 : i32, i32
        %50 = spirv.IEqual %49, %cst0_i32 : i32
        %51 = spirv.LogicalOr %46, %47 : i1
        %52 = spirv.LogicalOr %48, %50 : i1
        %53 = spirv.LogicalOr %51, %52 : i1
        %54 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.selection {
          spirv.BranchConditional %53, ^bb1, ^bb2
        ^bb1:  // pred: ^bb0
          spirv.Store "Function" %54, %43 : i32
          spirv.Branch ^bb3
        ^bb2:  // pred: ^bb0
          %113 = spirv.ShiftRightLogical %44, %cst23_i32 : i32, i32
          %114 = spirv.BitwiseAnd %41, %cst8388607_i32 : i32
          %115 = spirv.INotEqual %113, %cst0_i32 : i32
          %116 = spirv.Select %115, %cst8388608_i32, %cst0_i32 : i1, i32
          %117 = spirv.BitwiseOr %114, %116 : i32
          %118 = spirv.Select %115, %113, %cst1_i32 : i1, i32
          %119 = spirv.Variable : !spirv.ptr<i32, Function>
          %120 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%117, %118 : i32, i32)
          ^bb1(%186: i32, %187: i32):  // 2 preds: ^bb0, ^bb2
            %188 = spirv.ULessThan %186, %cst8388608_i32 : i32
            spirv.Store "Function" %119, %186 : i32
            spirv.Store "Function" %120, %187 : i32
            spirv.BranchConditional %188, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %189 = spirv.ShiftLeftLogical %186, %cst1_i32 : i32, i32
            %190 = spirv.ISub %187, %cst1_i32 : i32
            spirv.Branch ^bb1(%189, %190 : i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %121 = spirv.Load "Function" %120 : i32
          %122 = spirv.Load "Function" %119 : i32
          %123 = spirv.BitwiseAnd %42, %cst8388607_i32 : i32
          %124 = spirv.BitwiseOr %123, %cst8388608_i32 : i32
          %125 = spirv.BitwiseAnd %122, %cst65535_i32 : i32
          %126 = spirv.ShiftRightLogical %122, %cst16_i32 : i32, i32
          %127 = spirv.BitwiseAnd %124, %cst65535_i32 : i32
          %128 = spirv.ShiftRightLogical %124, %cst16_i32 : i32, i32
          %129 = spirv.IMul %125, %127 : i32
          %130 = spirv.IMul %126, %127 : i32
          %131 = spirv.IMul %125, %128 : i32
          %132 = spirv.IMul %126, %128 : i32
          %133 = spirv.ShiftRightLogical %129, %cst16_i32 : i32, i32
          %134 = spirv.BitwiseAnd %130, %cst65535_i32 : i32
          %135 = spirv.BitwiseAnd %131, %cst65535_i32 : i32
          %136 = spirv.IAdd %133, %134 : i32
          %137 = spirv.IAdd %136, %135 : i32
          %138 = spirv.ShiftRightLogical %137, %cst16_i32 : i32, i32
          %139 = spirv.ShiftRightLogical %130, %cst16_i32 : i32, i32
          %140 = spirv.ShiftRightLogical %131, %cst16_i32 : i32, i32
          %141 = spirv.IAdd %132, %139 : i32
          %142 = spirv.IAdd %141, %140 : i32
          %143 = spirv.IAdd %142, %138 : i32
          %144 = spirv.BitwiseAnd %129, %cst65535_i32 : i32
          %145 = spirv.ShiftLeftLogical %137, %cst16_i32 : i32, i32
          %146 = spirv.BitwiseOr %144, %145 : i32
          %147 = spirv.ShiftLeftLogical %143, %cst12_i32 : i32, i32
          %148 = spirv.ShiftRightLogical %146, %cst20_i32 : i32, i32
          %149 = spirv.BitwiseAnd %146, %cst1048575_i32 : i32
          %150 = spirv.INotEqual %149, %cst0_i32 : i32
          %151 = spirv.Select %150, %cst1_i32, %cst0_i32 : i1, i32
          %152 = spirv.BitwiseOr %147, %148 : i32
          %153 = spirv.BitwiseOr %152, %151 : i32
          %154 = spirv.IAdd %121, %49 : i32
          %155 = spirv.ISub %154, %cst127_i32 : i32
          %156 = spirv.UGreaterThanEqual %153, %cst134217728_i32 : i32
          %157 = spirv.BitwiseAnd %153, %cst1_i32 : i32
          %158 = spirv.ShiftRightLogical %153, %cst1_i32 : i32, i32
          %159 = spirv.BitwiseOr %158, %157 : i32
          %160 = spirv.Select %156, %159, %153 : i1, i32
          %161 = spirv.Select %156, %cst1_i32, %cst0_i32 : i1, i32
          %162 = spirv.IAdd %155, %161 : i32
          %163 = spirv.BitwiseAnd %160, %cst7_i32 : i32
          %164 = spirv.UGreaterThan %163, %cst4_i32 : i32
          %165 = spirv.IEqual %163, %cst4_i32 : i32
          %166 = spirv.BitwiseAnd %160, %cst8_i32 : i32
          %167 = spirv.INotEqual %166, %cst0_i32 : i32
          %168 = spirv.LogicalAnd %165, %167 : i1
          %169 = spirv.LogicalOr %164, %168 : i1
          %170 = spirv.Select %169, %cst1_i32, %cst0_i32 : i1, i32
          %171 = spirv.ShiftRightLogical %160, %cst3_i32 : i32, i32
          %172 = spirv.IAdd %171, %170 : i32
          %173 = spirv.UGreaterThanEqual %172, %cst16777216_i32 : i32
          %174 = spirv.ShiftRightLogical %172, %cst1_i32 : i32, i32
          %175 = spirv.Select %173, %174, %172 : i1, i32
          %176 = spirv.Select %173, %cst1_i32, %cst0_i32 : i1, i32
          %177 = spirv.IAdd %162, %176 : i32
          %178 = spirv.BitwiseAnd %175, %cst8388607_i32 : i32
          %179 = spirv.ShiftLeftLogical %177, %cst23_i32 : i32, i32
          %180 = spirv.BitwiseOr %179, %178 : i32
          %181 = spirv.SLessThan %177, %cst1_i32 : i32
          %182 = spirv.SGreaterThanEqual %177, %cst255_i32 : i32
          %183 = spirv.Select %182, %cst2139095040_i32, %180 : i1, i32
          %184 = spirv.Select %181, %cst0_i32, %183 : i1, i32
          %185 = spirv.BitwiseOr %43, %184 : i32
          spirv.Store "Function" %54, %185 : i32
          spirv.Branch ^bb3
        ^bb3:  // 2 preds: ^bb1, ^bb2
          spirv.mlir.merge
        }
        %55 = spirv.Load "Function" %54 : i32
        %56 = spirv.Bitcast %55 : i32 to f32
        %57 = spirv.GL.FMax %56, %cst_f32_0 : f32
        %58 = spirv.IsNan %56 : f32
        %59 = spirv.IsNan %cst_f32_0 : f32
        %60 = spirv.Select %58, %56, %57 : i1, f32
        %61 = spirv.Select %59, %cst_f32_0, %60 : i1, f32
        %62 = spirv.GL.FMin %61, %cst_f32 : f32
        %63 = spirv.IsNan %61 : f32
        %64 = spirv.IsNan %cst_f32 : f32
        %65 = spirv.Select %63, %61, %62 : i1, f32
        %66 = spirv.Select %64, %cst_f32, %65 : i1, f32
        %67 = spirv.GL.FAbs %66 : f32
        %68 = spirv.GL.FMin %67, %cst_f32 : f32
        %69 = spirv.IsNan %67 : f32
        %70 = spirv.Select %69, %67, %68 : i1, f32
        %71 = spirv.Select %64, %cst_f32, %70 : i1, f32
        %72 = spirv.Variable : !spirv.ptr<i32, Function>
        %73 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst126_i32 : i32, i32)
        ^bb1(%113: i32, %114: i32):  // 2 preds: ^bb0, ^bb2
          %115 = spirv.ULessThan %113, %114 : i32
          spirv.Store "Function" %72, %113 : i32
          spirv.Store "Function" %73, %114 : i32
          spirv.BranchConditional %115, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %116 = spirv.IAdd %113, %114 : i32
          %117 = spirv.IAdd %116, %cst1_i32 : i32
          %118 = spirv.UDiv %117, %cst2_i32 : i32
          %119 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %118] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %120 = spirv.Load "StorageBuffer" %119 : f32
          %121 = spirv.FOrdLessThanEqual %120, %71 : f32
          %122 = spirv.ISub %118, %cst1_i32 : i32
          %123 = spirv.Select %121, %118, %113 : i1, i32
          %124 = spirv.Select %121, %114, %122 : i1, i32
          spirv.Branch ^bb1(%123, %124 : i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %74 = spirv.Load "Function" %73 : i32
        %75 = spirv.Load "Function" %72 : i32
        %76 = spirv.IAdd %75, %cst1_i32 : i32
        %77 = spirv.GL.UMin %76, %cst126_i32 : i32
        %78 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %75] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %79 = spirv.Load "StorageBuffer" %78 : f32
        %80 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %77] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %81 = spirv.Load "StorageBuffer" %80 : f32
        %82 = spirv.FSub %71, %79 : f32
        %83 = spirv.FSub %71, %81 : f32
        %84 = spirv.GL.FAbs %82 : f32
        %85 = spirv.GL.FAbs %83 : f32
        %86 = spirv.FOrdLessThan %85, %84 : f32
        %87 = spirv.FOrdEqual %85, %84 : f32
        %88 = spirv.BitwiseAnd %75, %cst1_i32 : i32
        %89 = spirv.BitwiseAnd %77, %cst1_i32 : i32
        %90 = spirv.INotEqual %88, %cst0_i32 : i32
        %91 = spirv.IEqual %89, %cst0_i32 : i32
        %92 = spirv.LogicalAnd %87, %91 : i1
        %93 = spirv.LogicalAnd %92, %90 : i1
        %94 = spirv.LogicalOr %86, %93 : i1
        %95 = spirv.Select %94, %77, %75 : i1, i32
        %96 = spirv.Bitcast %66 : f32 to i32
        %97 = spirv.ShiftRightLogical %96, %cst24_i32 : i32, i32
        %98 = spirv.BitwiseAnd %97, %cst128_i32 : i32
        %99 = spirv.BitwiseOr %95, %98 : i32
        %100 = spirv.BitwiseAnd %99, %cst255_i32 : i32
        %101 = spirv.IAdd %1, %18 : i32
        %102 = spirv.IAdd %101, %11 : i32
        %103 = spirv.UMod %102, %cst4_i32 : i32
        %104 = spirv.IMul %103, %cst8_i32 : i32
        %105 = spirv.ShiftLeftLogical %cst255_i32, %104 : i32, i32
        %106 = spirv.Not %105 : i32
        %107 = spirv.BitwiseAnd %100, %cst255_i32 : i32
        %108 = spirv.ShiftLeftLogical %107, %104 : i32, i32
        %109 = spirv.SDiv %102, %cst4_i32 : i32
        %110 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %109] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %111 = spirv.AtomicAnd <Device> <AcquireRelease|UniformMemory> %110, %106 : !spirv.ptr<i32, StorageBuffer>
        %112 = spirv.AtomicOr <Device> <AcquireRelease|UniformMemory> %110, %108 : !spirv.ptr<i32, StorageBuffer>
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %23 = spirv.IAdd %18, %17 : i32
      spirv.Branch ^bb1(%23 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @quantize_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @quantize_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @quantize_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 "SignedZeroInfNanPreserve", 32
}