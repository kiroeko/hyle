spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_16bit_storage, SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__workgroup_mem__6 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @quantize_normal_bf16_dispatch_1_reduction_Dx128_i16xf32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst16_i32 = spirv.Constant 16 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst9_i32 = spirv.Constant 9 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst14680064_i32 = spirv.Constant 14680064 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.Bitcast %3 : i32 to f32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %5 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %6 = spirv.CompositeExtract %5[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %7 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %8 = spirv.CompositeExtract %7[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %9 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %10 = spirv.CompositeExtract %9[0 : i32] : vector<3xi32>
    %11 = spirv.IMul %8, %cst64_i32 : i32
    %12 = spirv.IMul %10, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%11 : i32)
    ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
      %14 = spirv.SLessThan %13, %1 : i32
      spirv.BranchConditional %14, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %15 = spirv.ISub %1, %13 : i32
      %16 = spirv.GL.SMin %15, %cst64_i32 : i32
      %__workgroup_mem__6_addr = spirv.mlir.addressof @__workgroup_mem__6 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
      %17 = spirv.SGreaterThan %16, %6 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %17, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %19 = spirv.AccessChain %__workgroup_mem__6_addr[%cst0_i32, %6] : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>, i32, i32 -> !spirv.ptr<f32, Workgroup>
        spirv.Store "Workgroup" %19, %4 : f32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%45: i32):  // 2 preds: ^bb0, ^bb2
          %46 = spirv.SLessThan %45, %cst128_i32 : i32
          spirv.BranchConditional %46, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %47 = spirv.IMul %13, %cst128_i32 : i32
          %48 = spirv.IAdd %45, %47 : i32
          %49 = spirv.IMul %6, %cst128_i32 : i32
          %50 = spirv.IAdd %48, %49 : i32
          %51 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %50] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
          %52 = spirv.Load "StorageBuffer" %51 : i16
          %53 = spirv.Load "Workgroup" %19 : f32
          %54 = spirv.UConvert %52 : i16 to i32
          %55 = spirv.ShiftLeftLogical %54, %cst16_i32 : i32, i32
          %56 = spirv.Bitcast %55 : i32 to f32
          %57 = spirv.GL.FAbs %56 : f32
          %58 = spirv.GL.FMax %57, %53 : f32
          %59 = spirv.IsNan %57 : f32
          %60 = spirv.IsNan %53 : f32
          %61 = spirv.Select %59, %57, %58 : i1, f32
          %62 = spirv.Select %60, %53, %61 : i1, f32
          spirv.Store "Workgroup" %19, %62 : f32
          %63 = spirv.IAdd %45, %cst1_i32 : i32
          spirv.Branch ^bb1(%63 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %20 = spirv.Load "Workgroup" %19 : f32
        %21 = spirv.Bitcast %20 : f32 to i32
        %22 = spirv.BitwiseAnd %21, %cst8388607_i32 : i32
        %23 = spirv.BitwiseOr %22, %cst8388608_i32 : i32
        %24 = spirv.UGreaterThanEqual %23, %cst14680064_i32 : i32
        %25 = spirv.Select %24, %cst2_i32, %cst3_i32 : i1, i32
        %26 = spirv.ShiftLeftLogical %23, %25 : i32, i32
        %27 = spirv.UDiv %26, %cst7_i32 : i32
        %28 = spirv.UMod %26, %cst7_i32 : i32
        %29 = spirv.UGreaterThanEqual %28, %cst4_i32 : i32
        %30 = spirv.Select %29, %cst1_i32, %cst0_i32 : i1, i32
        %31 = spirv.IAdd %27, %30 : i32
        %32 = spirv.ShiftRightLogical %21, %cst23_i32 : i32, i32
        %33 = spirv.BitwiseAnd %32, %cst255_i32 : i32
        %34 = spirv.Select %24, %cst8_i32, %cst9_i32 : i1, i32
        %35 = spirv.ISub %33, %34 : i32
        %36 = spirv.ShiftLeftLogical %35, %cst23_i32 : i32, i32
        %37 = spirv.BitwiseAnd %31, %cst8388607_i32 : i32
        %38 = spirv.BitwiseOr %36, %37 : i32
        %39 = spirv.Bitcast %38 : i32 to f32
        %40 = spirv.IEqual %33, %cst255_i32 : i32
        %41 = spirv.Select %40, %20, %39 : i1, f32
        %42 = spirv.IAdd %13, %6 : i32
        %43 = spirv.IAdd %42, %cst16_i32 : i32
        %44 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %43] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %44, %41 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %18 = spirv.IAdd %13, %12 : i32
      spirv.Branch ^bb1(%18 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @quantize_normal_bf16_dispatch_1_reduction_Dx128_i16xf32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @quantize_normal_bf16_dispatch_1_reduction_Dx128_i16xf32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @quantize_normal_bf16_dispatch_1_reduction_Dx128_i16xf32 "SignedZeroInfNanPreserve", 32
}