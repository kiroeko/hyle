spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_16bit_storage, SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__workgroup_mem__7 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @quantize_reciprocal_bf16_dispatch_1_reduction_Dx128_i16xf32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst2_i32 = spirv.Constant 2 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst253_i32 = spirv.Constant 253 : i32
    %cst254_i32 = spirv.Constant 254 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst16777216_i32 = spirv.Constant 16777216 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst134217728_i32 = spirv.Constant 134217728 : i32
    %cst-9_i32 = spirv.Constant -9 : i32
    %cst1048575_i32 = spirv.Constant 1048575 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst146_i32 = spirv.Constant 146 : i32
    %cst18725_i32 = spirv.Constant 18725 : i32
    %cst65535_i32 = spirv.Constant 65535 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2139095040_i32 = spirv.Constant 2139095040 : i32
    %cst2147483647_i32 = spirv.Constant 2147483647 : i32
    %cst-2147483648_i32 = spirv.Constant -2147483648 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.Bitcast %3 : i32 to f32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %5 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %6 = spirv.CompositeExtract %5[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %7 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %8 = spirv.CompositeExtract %7[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %9 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %10 = spirv.CompositeExtract %9[0 : i32] : vector<3xi32>
    %11 = spirv.IMul %8, %cst64_i32 : i32
    %12 = spirv.IMul %10, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%11 : i32)
    ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
      %14 = spirv.SLessThan %13, %1 : i32
      spirv.BranchConditional %14, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %15 = spirv.ISub %1, %13 : i32
      %16 = spirv.GL.SMin %15, %cst64_i32 : i32
      %__workgroup_mem__7_addr = spirv.mlir.addressof @__workgroup_mem__7 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
      %17 = spirv.SGreaterThan %16, %6 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %17, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %19 = spirv.AccessChain %__workgroup_mem__7_addr[%cst0_i32, %6] : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>, i32, i32 -> !spirv.ptr<f32, Workgroup>
        spirv.Store "Workgroup" %19, %4 : f32
        %20 = spirv.IAdd %13, %6 : i32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%64: i32):  // 2 preds: ^bb0, ^bb2
          %65 = spirv.SLessThan %64, %cst128_i32 : i32
          spirv.BranchConditional %65, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %66 = spirv.IMul %13, %cst128_i32 : i32
          %67 = spirv.IAdd %64, %66 : i32
          %68 = spirv.IMul %6, %cst128_i32 : i32
          %69 = spirv.IAdd %67, %68 : i32
          %70 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %69] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
          %71 = spirv.Load "StorageBuffer" %70 : i16
          %72 = spirv.Load "Workgroup" %19 : f32
          %73 = spirv.UConvert %71 : i16 to i32
          %74 = spirv.ShiftLeftLogical %73, %cst16_i32 : i32, i32
          %75 = spirv.Bitcast %74 : i32 to f32
          %76 = spirv.GL.FAbs %75 : f32
          %77 = spirv.GL.FMax %76, %72 : f32
          %78 = spirv.IsNan %76 : f32
          %79 = spirv.IsNan %72 : f32
          %80 = spirv.Select %78, %76, %77 : i1, f32
          %81 = spirv.Select %79, %72, %80 : i1, f32
          spirv.Store "Workgroup" %19, %81 : f32
          %82 = spirv.IAdd %64, %cst1_i32 : i32
          spirv.Branch ^bb1(%82 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %21 = spirv.Load "Workgroup" %19 : f32
        %22 = spirv.Bitcast %21 : f32 to i32
        %23 = spirv.BitwiseAnd %22, %cst-2147483648_i32 : i32
        %24 = spirv.BitwiseAnd %22, %cst2147483647_i32 : i32
        %25 = spirv.IEqual %24, %cst0_i32 : i32
        %26 = spirv.UGreaterThanEqual %24, %cst2139095040_i32 : i32
        %27 = spirv.LogicalOr %25, %26 : i1
        %28 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.selection {
          spirv.BranchConditional %27, ^bb1, ^bb2
        ^bb1:  // pred: ^bb0
          spirv.Store "Function" %28, %23 : i32
          spirv.Branch ^bb3
        ^bb2:  // pred: ^bb0
          %64 = spirv.ShiftRightLogical %24, %cst23_i32 : i32, i32
          %65 = spirv.BitwiseAnd %22, %cst8388607_i32 : i32
          %66 = spirv.INotEqual %64, %cst0_i32 : i32
          %67 = spirv.Select %66, %cst8388608_i32, %cst0_i32 : i1, i32
          %68 = spirv.BitwiseOr %65, %67 : i32
          %69 = spirv.Select %66, %64, %cst1_i32 : i1, i32
          %70 = spirv.Variable : !spirv.ptr<i32, Function>
          %71 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%68, %69 : i32, i32)
          ^bb1(%132: i32, %133: i32):  // 2 preds: ^bb0, ^bb2
            %134 = spirv.ULessThan %132, %cst8388608_i32 : i32
            spirv.Store "Function" %70, %132 : i32
            spirv.Store "Function" %71, %133 : i32
            spirv.BranchConditional %134, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %135 = spirv.ShiftLeftLogical %132, %cst1_i32 : i32, i32
            %136 = spirv.ISub %133, %cst1_i32 : i32
            spirv.Branch ^bb1(%135, %136 : i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %72 = spirv.Load "Function" %71 : i32
          %73 = spirv.Load "Function" %70 : i32
          %74 = spirv.BitwiseAnd %73, %cst65535_i32 : i32
          %75 = spirv.ShiftRightLogical %73, %cst16_i32 : i32, i32
          %76 = spirv.IMul %74, %cst18725_i32 : i32
          %77 = spirv.IMul %75, %cst18725_i32 : i32
          %78 = spirv.IMul %74, %cst146_i32 : i32
          %79 = spirv.IMul %75, %cst146_i32 : i32
          %80 = spirv.ShiftRightLogical %76, %cst16_i32 : i32, i32
          %81 = spirv.BitwiseAnd %77, %cst65535_i32 : i32
          %82 = spirv.BitwiseAnd %78, %cst65535_i32 : i32
          %83 = spirv.IAdd %80, %81 : i32
          %84 = spirv.IAdd %83, %82 : i32
          %85 = spirv.ShiftRightLogical %84, %cst16_i32 : i32, i32
          %86 = spirv.ShiftRightLogical %77, %cst16_i32 : i32, i32
          %87 = spirv.ShiftRightLogical %78, %cst16_i32 : i32, i32
          %88 = spirv.IAdd %79, %86 : i32
          %89 = spirv.IAdd %88, %87 : i32
          %90 = spirv.IAdd %89, %85 : i32
          %91 = spirv.BitwiseAnd %76, %cst65535_i32 : i32
          %92 = spirv.ShiftLeftLogical %84, %cst16_i32 : i32, i32
          %93 = spirv.BitwiseOr %91, %92 : i32
          %94 = spirv.ShiftLeftLogical %90, %cst12_i32 : i32, i32
          %95 = spirv.ShiftRightLogical %93, %cst20_i32 : i32, i32
          %96 = spirv.BitwiseAnd %93, %cst1048575_i32 : i32
          %97 = spirv.INotEqual %96, %cst0_i32 : i32
          %98 = spirv.Select %97, %cst1_i32, %cst0_i32 : i1, i32
          %99 = spirv.BitwiseOr %94, %95 : i32
          %100 = spirv.BitwiseOr %99, %98 : i32
          %101 = spirv.IAdd %72, %cst-9_i32 : i32
          %102 = spirv.UGreaterThanEqual %100, %cst134217728_i32 : i32
          %103 = spirv.BitwiseAnd %100, %cst1_i32 : i32
          %104 = spirv.ShiftRightLogical %100, %cst1_i32 : i32, i32
          %105 = spirv.BitwiseOr %104, %103 : i32
          %106 = spirv.Select %102, %105, %100 : i1, i32
          %107 = spirv.Select %102, %cst1_i32, %cst0_i32 : i1, i32
          %108 = spirv.IAdd %101, %107 : i32
          %109 = spirv.BitwiseAnd %106, %cst7_i32 : i32
          %110 = spirv.UGreaterThan %109, %cst4_i32 : i32
          %111 = spirv.IEqual %109, %cst4_i32 : i32
          %112 = spirv.BitwiseAnd %106, %cst8_i32 : i32
          %113 = spirv.INotEqual %112, %cst0_i32 : i32
          %114 = spirv.LogicalAnd %111, %113 : i1
          %115 = spirv.LogicalOr %110, %114 : i1
          %116 = spirv.Select %115, %cst1_i32, %cst0_i32 : i1, i32
          %117 = spirv.ShiftRightLogical %106, %cst3_i32 : i32, i32
          %118 = spirv.IAdd %117, %116 : i32
          %119 = spirv.UGreaterThanEqual %118, %cst16777216_i32 : i32
          %120 = spirv.ShiftRightLogical %118, %cst1_i32 : i32, i32
          %121 = spirv.Select %119, %120, %118 : i1, i32
          %122 = spirv.Select %119, %cst1_i32, %cst0_i32 : i1, i32
          %123 = spirv.IAdd %108, %122 : i32
          %124 = spirv.BitwiseAnd %121, %cst8388607_i32 : i32
          %125 = spirv.ShiftLeftLogical %123, %cst23_i32 : i32, i32
          %126 = spirv.BitwiseOr %125, %124 : i32
          %127 = spirv.SLessThan %123, %cst1_i32 : i32
          %128 = spirv.SGreaterThanEqual %123, %cst255_i32 : i32
          %129 = spirv.Select %128, %cst2139095040_i32, %126 : i1, i32
          %130 = spirv.Select %127, %cst0_i32, %129 : i1, i32
          %131 = spirv.BitwiseOr %23, %130 : i32
          spirv.Store "Function" %28, %131 : i32
          spirv.Branch ^bb3
        ^bb3:  // 2 preds: ^bb1, ^bb2
          spirv.mlir.merge
        }
        %29 = spirv.Load "Function" %28 : i32
        %30 = spirv.Bitcast %29 : i32 to f32
        %31 = spirv.BitwiseAnd %29, %cst8388607_i32 : i32
        %32 = spirv.BitwiseOr %31, %cst8388608_i32 : i32
        %33 = spirv.ShiftRightLogical %29, %cst23_i32 : i32, i32
        %34 = spirv.IEqual %32, %cst8388608_i32 : i32
        %35 = spirv.Select %34, %cst8388608_i32, %cst16777216_i32 : i1, i32
        %36 = spirv.Select %34, %cst254_i32, %cst253_i32 : i1, i32
        %37 = spirv.ISub %36, %33 : i32
        %38 = spirv.ISub %35, %32 : i32
        %39 = spirv.Variable : !spirv.ptr<i32, Function>
        %40 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst1_i32, %38 : i32, i32, i32)
        ^bb1(%64: i32, %65: i32, %66: i32):  // 2 preds: ^bb0, ^bb2
          %67 = spirv.SLessThan %64, %cst23_i32 : i32
          spirv.BranchConditional %67, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %68 = spirv.ShiftLeftLogical %66, %cst1_i32 : i32, i32
          %69 = spirv.UGreaterThanEqual %68, %32 : i32
          %70 = spirv.Select %69, %32, %cst0_i32 : i1, i32
          %71 = spirv.ISub %68, %70 : i32
          %72 = spirv.ShiftLeftLogical %65, %cst1_i32 : i32, i32
          %73 = spirv.Select %69, %cst1_i32, %cst0_i32 : i1, i32
          %74 = spirv.BitwiseOr %72, %73 : i32
          spirv.Store "Function" %39, %74 : i32
          spirv.Store "Function" %40, %71 : i32
          %75 = spirv.IAdd %64, %cst1_i32 : i32
          spirv.Branch ^bb1(%75, %74, %71 : i32, i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %41 = spirv.Load "Function" %40 : i32
        %42 = spirv.Load "Function" %39 : i32
        %43 = spirv.ShiftLeftLogical %41, %cst1_i32 : i32, i32
        %44 = spirv.UGreaterThan %43, %32 : i32
        %45 = spirv.IEqual %43, %32 : i32
        %46 = spirv.BitwiseAnd %42, %cst1_i32 : i32
        %47 = spirv.INotEqual %46, %cst0_i32 : i32
        %48 = spirv.LogicalAnd %45, %47 : i1
        %49 = spirv.LogicalOr %44, %48 : i1
        %50 = spirv.Select %49, %cst1_i32, %cst0_i32 : i1, i32
        %51 = spirv.IAdd %42, %50 : i32
        %52 = spirv.UGreaterThanEqual %51, %cst16777216_i32 : i32
        %53 = spirv.ShiftRightLogical %51, %cst1_i32 : i32, i32
        %54 = spirv.Select %52, %53, %51 : i1, i32
        %55 = spirv.Select %52, %cst1_i32, %cst0_i32 : i1, i32
        %56 = spirv.IAdd %37, %55 : i32
        %57 = spirv.ShiftLeftLogical %56, %cst23_i32 : i32, i32
        %58 = spirv.BitwiseAnd %54, %cst8388607_i32 : i32
        %59 = spirv.BitwiseOr %57, %58 : i32
        %60 = spirv.Bitcast %59 : i32 to f32
        %61 = spirv.IAdd %20, %cst16_i32 : i32
        %62 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %61] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %62, %30 : f32
        %63 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %20] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %63, %60 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %18 = spirv.IAdd %13, %12 : i32
      spirv.Branch ^bb1(%18 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @quantize_reciprocal_bf16_dispatch_1_reduction_Dx128_i16xf32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @quantize_reciprocal_bf16_dispatch_1_reduction_Dx128_i16xf32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @quantize_reciprocal_bf16_dispatch_1_reduction_Dx128_i16xf32 "SignedZeroInfNanPreserve", 32
}