spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.func @quantize_normal_bf16_dispatch_2_elementwise_broadcast_D_i8() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst6_i32 = spirv.Constant 6 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst126_i32 = spirv.Constant 126 : i32
    %cst26_i32 = spirv.Constant 26 : i32
    %cst27_i32 = spirv.Constant 27 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst127_i32 = spirv.Constant 127 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst16777216_i32 = spirv.Constant 16777216 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2139095040_i32 = spirv.Constant 2139095040 : i32
    %cst2147483647_i32 = spirv.Constant 2147483647 : i32
    %cst-2147483648_i32 = spirv.Constant -2147483648 : i32
    %cst_f32 = spirv.Constant 4.480000e+02 : f32
    %cst_f32_0 = spirv.Constant -4.480000e+02 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %14 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %15 = spirv.CompositeExtract %14[0 : i32] : vector<3xi32>
    %16 = spirv.IMul %13, %cst64_i32 : i32
    %17 = spirv.IMul %15, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
      %19 = spirv.SLessThan %18, %3 : i32
      spirv.BranchConditional %19, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %20 = spirv.ISub %3, %18 : i32
      %21 = spirv.GL.SMin %20, %cst64_i32 : i32
      %22 = spirv.SGreaterThan %21, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %22, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %24 = spirv.IAdd %18, %11 : i32
        %25 = spirv.GL.SAbs %24 : i32
        %26 = spirv.GL.SAbs %7 : i32
        %27 = spirv.UMod %25, %26 : i32
        %28 = spirv.IEqual %24, %25 : i32
        %29 = spirv.SNegate %27 : i32
        %30 = spirv.Select %28, %27, %29 : i1, i32
        %31 = spirv.SDiv %24, %7 : i32
        %32 = spirv.UDiv %30, %cst128_i32 : i32
        %33 = spirv.IMul %31, %7 : i32
        %34 = spirv.IAdd %33, %30 : i32
        %35 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %36 = spirv.Load "StorageBuffer" %35 : i16
        %37 = spirv.UConvert %36 : i16 to i32
        %38 = spirv.ShiftLeftLogical %37, %cst16_i32 : i32, i32
        %39 = spirv.IMul %31, %9 : i32
        %40 = spirv.IAdd %39, %32 : i32
        %41 = spirv.IAdd %40, %cst16_i32 : i32
        %42 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %41] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %43 = spirv.Load "StorageBuffer" %42 : f32
        %44 = spirv.Bitcast %43 : f32 to i32
        %45 = spirv.BitwiseAnd %38, %cst-2147483648_i32 : i32
        %46 = spirv.BitwiseAnd %38, %cst2147483647_i32 : i32
        %47 = spirv.BitwiseAnd %44, %cst2147483647_i32 : i32
        %48 = spirv.IEqual %46, %cst0_i32 : i32
        %49 = spirv.UGreaterThanEqual %46, %cst2139095040_i32 : i32
        %50 = spirv.UGreaterThanEqual %47, %cst2139095040_i32 : i32
        %51 = spirv.ShiftRightLogical %47, %cst23_i32 : i32, i32
        %52 = spirv.IEqual %51, %cst0_i32 : i32
        %53 = spirv.LogicalOr %48, %49 : i1
        %54 = spirv.LogicalOr %50, %52 : i1
        %55 = spirv.LogicalOr %53, %54 : i1
        %56 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.selection {
          spirv.BranchConditional %55, ^bb1, ^bb2
        ^bb1:  // pred: ^bb0
          spirv.Store "Function" %56, %45 : i32
          spirv.Branch ^bb3
        ^bb2:  // pred: ^bb0
          %115 = spirv.ShiftRightLogical %46, %cst23_i32 : i32, i32
          %116 = spirv.BitwiseAnd %38, %cst8388607_i32 : i32
          %117 = spirv.INotEqual %115, %cst0_i32 : i32
          %118 = spirv.Select %117, %cst8388608_i32, %cst0_i32 : i1, i32
          %119 = spirv.BitwiseOr %116, %118 : i32
          %120 = spirv.Select %117, %115, %cst1_i32 : i1, i32
          %121 = spirv.Variable : !spirv.ptr<i32, Function>
          %122 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%119, %120 : i32, i32)
          ^bb1(%164: i32, %165: i32):  // 2 preds: ^bb0, ^bb2
            %166 = spirv.ULessThan %164, %cst8388608_i32 : i32
            spirv.Store "Function" %121, %164 : i32
            spirv.Store "Function" %122, %165 : i32
            spirv.BranchConditional %166, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %167 = spirv.ShiftLeftLogical %164, %cst1_i32 : i32, i32
            %168 = spirv.ISub %165, %cst1_i32 : i32
            spirv.Branch ^bb1(%167, %168 : i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %123 = spirv.Load "Function" %122 : i32
          %124 = spirv.Load "Function" %121 : i32
          %125 = spirv.BitwiseAnd %44, %cst8388607_i32 : i32
          %126 = spirv.BitwiseOr %125, %cst8388608_i32 : i32
          %127 = spirv.ISub %123, %51 : i32
          %128 = spirv.IAdd %127, %cst127_i32 : i32
          %129 = spirv.ULessThan %124, %126 : i32
          %130 = spirv.ShiftLeftLogical %124, %cst1_i32 : i32, i32
          %131 = spirv.Select %129, %130, %124 : i1, i32
          %132 = spirv.Select %129, %cst1_i32, %cst0_i32 : i1, i32
          %133 = spirv.ISub %128, %132 : i32
          %134 = spirv.Variable : !spirv.ptr<i32, Function>
          %135 = spirv.Variable : !spirv.ptr<i32, Function>
          spirv.mlir.loop {
            spirv.Branch ^bb1(%cst0_i32, %cst0_i32, %131 : i32, i32, i32)
          ^bb1(%164: i32, %165: i32, %166: i32):  // 2 preds: ^bb0, ^bb2
            %167 = spirv.SLessThan %164, %cst27_i32 : i32
            spirv.BranchConditional %167, ^bb2, ^bb3
          ^bb2:  // pred: ^bb1
            %168 = spirv.UGreaterThanEqual %166, %126 : i32
            %169 = spirv.Select %168, %126, %cst0_i32 : i1, i32
            %170 = spirv.ISub %166, %169 : i32
            %171 = spirv.ShiftLeftLogical %165, %cst1_i32 : i32, i32
            %172 = spirv.Select %168, %cst1_i32, %cst0_i32 : i1, i32
            %173 = spirv.BitwiseOr %171, %172 : i32
            %174 = spirv.ShiftLeftLogical %170, %cst1_i32 : i32, i32
            %175 = spirv.IEqual %164, %cst26_i32 : i32
            %176 = spirv.Select %175, %170, %174 : i1, i32
            spirv.Store "Function" %134, %173 : i32
            spirv.Store "Function" %135, %176 : i32
            %177 = spirv.IAdd %164, %cst1_i32 : i32
            spirv.Branch ^bb1(%177, %173, %176 : i32, i32, i32)
          ^bb3:  // pred: ^bb1
            spirv.mlir.merge
          }
          %136 = spirv.Load "Function" %135 : i32
          %137 = spirv.Load "Function" %134 : i32
          %138 = spirv.INotEqual %136, %cst0_i32 : i32
          %139 = spirv.Select %138, %cst1_i32, %cst0_i32 : i1, i32
          %140 = spirv.BitwiseOr %137, %139 : i32
          %141 = spirv.BitwiseAnd %140, %cst7_i32 : i32
          %142 = spirv.UGreaterThan %141, %cst4_i32 : i32
          %143 = spirv.IEqual %141, %cst4_i32 : i32
          %144 = spirv.BitwiseAnd %140, %cst8_i32 : i32
          %145 = spirv.INotEqual %144, %cst0_i32 : i32
          %146 = spirv.LogicalAnd %143, %145 : i1
          %147 = spirv.LogicalOr %142, %146 : i1
          %148 = spirv.Select %147, %cst1_i32, %cst0_i32 : i1, i32
          %149 = spirv.ShiftRightLogical %140, %cst3_i32 : i32, i32
          %150 = spirv.IAdd %149, %148 : i32
          %151 = spirv.UGreaterThanEqual %150, %cst16777216_i32 : i32
          %152 = spirv.ShiftRightLogical %150, %cst1_i32 : i32, i32
          %153 = spirv.Select %151, %152, %150 : i1, i32
          %154 = spirv.Select %151, %cst1_i32, %cst0_i32 : i1, i32
          %155 = spirv.IAdd %133, %154 : i32
          %156 = spirv.BitwiseAnd %153, %cst8388607_i32 : i32
          %157 = spirv.ShiftLeftLogical %155, %cst23_i32 : i32, i32
          %158 = spirv.BitwiseOr %157, %156 : i32
          %159 = spirv.SLessThan %155, %cst1_i32 : i32
          %160 = spirv.SGreaterThanEqual %155, %cst255_i32 : i32
          %161 = spirv.Select %160, %cst2139095040_i32, %158 : i1, i32
          %162 = spirv.Select %159, %cst0_i32, %161 : i1, i32
          %163 = spirv.BitwiseOr %45, %162 : i32
          spirv.Store "Function" %56, %163 : i32
          spirv.Branch ^bb3
        ^bb3:  // 2 preds: ^bb1, ^bb2
          spirv.mlir.merge
        }
        %57 = spirv.Load "Function" %56 : i32
        %58 = spirv.Bitcast %57 : i32 to f32
        %59 = spirv.GL.FMax %58, %cst_f32_0 : f32
        %60 = spirv.IsNan %58 : f32
        %61 = spirv.IsNan %cst_f32_0 : f32
        %62 = spirv.Select %60, %58, %59 : i1, f32
        %63 = spirv.Select %61, %cst_f32_0, %62 : i1, f32
        %64 = spirv.GL.FMin %63, %cst_f32 : f32
        %65 = spirv.IsNan %63 : f32
        %66 = spirv.IsNan %cst_f32 : f32
        %67 = spirv.Select %65, %63, %64 : i1, f32
        %68 = spirv.Select %66, %cst_f32, %67 : i1, f32
        %69 = spirv.GL.FAbs %68 : f32
        %70 = spirv.GL.FMin %69, %cst_f32 : f32
        %71 = spirv.IsNan %69 : f32
        %72 = spirv.Select %71, %69, %70 : i1, f32
        %73 = spirv.Select %66, %cst_f32, %72 : i1, f32
        %74 = spirv.Variable : !spirv.ptr<i32, Function>
        %75 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst126_i32 : i32, i32)
        ^bb1(%115: i32, %116: i32):  // 2 preds: ^bb0, ^bb2
          %117 = spirv.ULessThan %115, %116 : i32
          spirv.Store "Function" %74, %115 : i32
          spirv.Store "Function" %75, %116 : i32
          spirv.BranchConditional %117, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %118 = spirv.IAdd %115, %116 : i32
          %119 = spirv.IAdd %118, %cst1_i32 : i32
          %120 = spirv.UDiv %119, %cst2_i32 : i32
          %121 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %120] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %122 = spirv.Load "StorageBuffer" %121 : f32
          %123 = spirv.FOrdLessThanEqual %122, %73 : f32
          %124 = spirv.ISub %120, %cst1_i32 : i32
          %125 = spirv.Select %123, %120, %115 : i1, i32
          %126 = spirv.Select %123, %116, %124 : i1, i32
          spirv.Branch ^bb1(%125, %126 : i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %76 = spirv.Load "Function" %75 : i32
        %77 = spirv.Load "Function" %74 : i32
        %78 = spirv.IAdd %77, %cst1_i32 : i32
        %79 = spirv.GL.UMin %78, %cst126_i32 : i32
        %80 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %77] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %81 = spirv.Load "StorageBuffer" %80 : f32
        %82 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %79] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %83 = spirv.Load "StorageBuffer" %82 : f32
        %84 = spirv.FSub %73, %81 : f32
        %85 = spirv.FSub %73, %83 : f32
        %86 = spirv.GL.FAbs %84 : f32
        %87 = spirv.GL.FAbs %85 : f32
        %88 = spirv.FOrdLessThan %87, %86 : f32
        %89 = spirv.FOrdEqual %87, %86 : f32
        %90 = spirv.BitwiseAnd %77, %cst1_i32 : i32
        %91 = spirv.BitwiseAnd %79, %cst1_i32 : i32
        %92 = spirv.INotEqual %90, %cst0_i32 : i32
        %93 = spirv.IEqual %91, %cst0_i32 : i32
        %94 = spirv.LogicalAnd %89, %93 : i1
        %95 = spirv.LogicalAnd %94, %92 : i1
        %96 = spirv.LogicalOr %88, %95 : i1
        %97 = spirv.Select %96, %79, %77 : i1, i32
        %98 = spirv.Bitcast %68 : f32 to i32
        %99 = spirv.ShiftRightLogical %98, %cst24_i32 : i32, i32
        %100 = spirv.BitwiseAnd %99, %cst128_i32 : i32
        %101 = spirv.BitwiseOr %97, %100 : i32
        %102 = spirv.BitwiseAnd %101, %cst255_i32 : i32
        %103 = spirv.IAdd %1, %18 : i32
        %104 = spirv.IAdd %103, %11 : i32
        %105 = spirv.UMod %104, %cst4_i32 : i32
        %106 = spirv.IMul %105, %cst8_i32 : i32
        %107 = spirv.ShiftLeftLogical %cst255_i32, %106 : i32, i32
        %108 = spirv.Not %107 : i32
        %109 = spirv.BitwiseAnd %102, %cst255_i32 : i32
        %110 = spirv.ShiftLeftLogical %109, %106 : i32, i32
        %111 = spirv.SDiv %104, %cst4_i32 : i32
        %112 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %111] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %113 = spirv.AtomicAnd <Device> <AcquireRelease|UniformMemory> %112, %108 : !spirv.ptr<i32, StorageBuffer>
        %114 = spirv.AtomicOr <Device> <AcquireRelease|UniformMemory> %112, %110 : !spirv.ptr<i32, StorageBuffer>
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %23 = spirv.IAdd %18, %17 : i32
      spirv.Branch ^bb1(%23 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @quantize_normal_bf16_dispatch_2_elementwise_broadcast_D_i8, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @quantize_normal_bf16_dispatch_2_elementwise_broadcast_D_i8 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @quantize_normal_bf16_dispatch_2_elementwise_broadcast_D_i8 "SignedZeroInfNanPreserve", 32
}