spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__workgroup_mem__7 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_reciprocal_f32_dispatch_1_reduction_DxD_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst2_i32 = spirv.Constant 2 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst253_i32 = spirv.Constant 253 : i32
    %cst254_i32 = spirv.Constant 254 : i32
    %cst16777216_i32 = spirv.Constant 16777216 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst8388608_i32 = spirv.Constant 8388608 : i32
    %cst8388607_i32 = spirv.Constant 8388607 : i32
    %cst_f32 = spirv.Constant 0.00223214296 : f32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<3 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.Bitcast %3 : i32 to f32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %5 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %6 = spirv.CompositeExtract %5[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %7 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %8 = spirv.CompositeExtract %7[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %9 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %10 = spirv.CompositeExtract %9[0 : i32] : vector<3xi32>
    %11 = spirv.IMul %8, %cst64_i32 : i32
    %12 = spirv.IMul %10, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%11 : i32)
    ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
      %14 = spirv.SLessThan %13, %1 : i32
      spirv.BranchConditional %14, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %15 = spirv.ISub %1, %13 : i32
      %16 = spirv.GL.SMin %15, %cst64_i32 : i32
      %__workgroup_mem__7_addr = spirv.mlir.addressof @__workgroup_mem__7 : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>
      %17 = spirv.SGreaterThan %16, %6 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %17, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %19 = spirv.AccessChain %__workgroup_mem__7_addr[%cst0_i32, %6] : !spirv.ptr<!spirv.struct<(!spirv.array<64 x f32>)>, Workgroup>, i32, i32 -> !spirv.ptr<f32, Workgroup>
        spirv.Store "Workgroup" %19, %4 : f32
        %20 = spirv.IAdd %13, %6 : i32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%56: i32):  // 2 preds: ^bb0, ^bb2
          %57 = spirv.SLessThan %56, %cst128_i32 : i32
          spirv.BranchConditional %57, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %58 = spirv.IMul %13, %cst128_i32 : i32
          %59 = spirv.IAdd %56, %58 : i32
          %60 = spirv.IMul %6, %cst128_i32 : i32
          %61 = spirv.IAdd %59, %60 : i32
          %62 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %61] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %63 = spirv.Load "StorageBuffer" %62 : f32
          %64 = spirv.Load "Workgroup" %19 : f32
          %65 = spirv.GL.FAbs %63 : f32
          %66 = spirv.GL.FMax %65, %64 : f32
          %67 = spirv.IsNan %65 : f32
          %68 = spirv.IsNan %64 : f32
          %69 = spirv.Select %67, %65, %66 : i1, f32
          %70 = spirv.Select %68, %64, %69 : i1, f32
          spirv.Store "Workgroup" %19, %70 : f32
          %71 = spirv.IAdd %56, %cst1_i32 : i32
          spirv.Branch ^bb1(%71 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %21 = spirv.Load "Workgroup" %19 : f32
        %22 = spirv.FMul %21, %cst_f32 : f32
        %23 = spirv.Bitcast %22 : f32 to i32
        %24 = spirv.BitwiseAnd %23, %cst8388607_i32 : i32
        %25 = spirv.BitwiseOr %24, %cst8388608_i32 : i32
        %26 = spirv.ShiftRightLogical %23, %cst23_i32 : i32, i32
        %27 = spirv.IEqual %25, %cst8388608_i32 : i32
        %28 = spirv.Select %27, %cst8388608_i32, %cst16777216_i32 : i1, i32
        %29 = spirv.Select %27, %cst254_i32, %cst253_i32 : i1, i32
        %30 = spirv.ISub %29, %26 : i32
        %31 = spirv.ISub %28, %25 : i32
        %32 = spirv.Variable : !spirv.ptr<i32, Function>
        %33 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst1_i32, %31 : i32, i32, i32)
        ^bb1(%56: i32, %57: i32, %58: i32):  // 2 preds: ^bb0, ^bb2
          %59 = spirv.SLessThan %56, %cst23_i32 : i32
          spirv.BranchConditional %59, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %60 = spirv.ShiftLeftLogical %58, %cst1_i32 : i32, i32
          %61 = spirv.UGreaterThanEqual %60, %25 : i32
          %62 = spirv.Select %61, %25, %cst0_i32 : i1, i32
          %63 = spirv.ISub %60, %62 : i32
          %64 = spirv.ShiftLeftLogical %57, %cst1_i32 : i32, i32
          %65 = spirv.Select %61, %cst1_i32, %cst0_i32 : i1, i32
          %66 = spirv.BitwiseOr %64, %65 : i32
          spirv.Store "Function" %32, %66 : i32
          spirv.Store "Function" %33, %63 : i32
          %67 = spirv.IAdd %56, %cst1_i32 : i32
          spirv.Branch ^bb1(%67, %66, %63 : i32, i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %34 = spirv.Load "Function" %33 : i32
        %35 = spirv.Load "Function" %32 : i32
        %36 = spirv.ShiftLeftLogical %34, %cst1_i32 : i32, i32
        %37 = spirv.UGreaterThan %36, %25 : i32
        %38 = spirv.IEqual %36, %25 : i32
        %39 = spirv.BitwiseAnd %35, %cst1_i32 : i32
        %40 = spirv.INotEqual %39, %cst0_i32 : i32
        %41 = spirv.LogicalAnd %38, %40 : i1
        %42 = spirv.LogicalOr %37, %41 : i1
        %43 = spirv.Select %42, %cst1_i32, %cst0_i32 : i1, i32
        %44 = spirv.IAdd %35, %43 : i32
        %45 = spirv.UGreaterThanEqual %44, %cst16777216_i32 : i32
        %46 = spirv.ShiftRightLogical %44, %cst1_i32 : i32, i32
        %47 = spirv.Select %45, %46, %44 : i1, i32
        %48 = spirv.Select %45, %cst1_i32, %cst0_i32 : i1, i32
        %49 = spirv.IAdd %30, %48 : i32
        %50 = spirv.ShiftLeftLogical %49, %cst23_i32 : i32, i32
        %51 = spirv.BitwiseAnd %47, %cst8388607_i32 : i32
        %52 = spirv.BitwiseOr %50, %51 : i32
        %53 = spirv.Bitcast %52 : i32 to f32
        %54 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %20] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %54, %22 : f32
        %55 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %20] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %55, %53 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %18 = spirv.IAdd %13, %12 : i32
      spirv.Branch ^bb1(%18 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_reciprocal_f32_dispatch_1_reduction_DxD_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @linear_reciprocal_f32_dispatch_1_reduction_DxD_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @linear_reciprocal_f32_dispatch_1_reduction_DxD_f32 "SignedZeroInfNanPreserve", 32
}