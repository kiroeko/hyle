"""Source-only snapshot for the two-output CUDA FP8 quantizer."""
from pathlib import Path
import hashlib
import json
import difflib

R = Path(__file__).resolve().parents[3]
S = Path(__file__).resolve().parent
paths = [R / 'src/compute_provider_cuda' / name for name in (
    'float8_quantize_kernel.h', 'float8_quantize_kernel.cu',
    'float8_quantize_provider.h', 'float8_quantize_provider.cc',
    'cuda_provider.cc')]
records = []
for path in paths:
    raw = path.read_bytes()
    (S / path.name).write_bytes(raw)
    record = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    records.append(record)
    text = raw.decode('utf-8')
    before = ''
    if path.name == 'cuda_provider.cc':
        before = text.replace('#include "float8_quantize_provider.h"\n', '')
        before = before.replace(
            '    if (request.operation.custom_as<model_ops::Float8BlockQuantize>())\n'
            '      return float8_quantize::propose(request, inputs, outputs, proposal);\n', '')
        before = before.replace(
            '    if (request.route == float8_quantize::kRoute)\n'
            '      return float8_quantize::prepare(state, request, allocator, output);\n', '')
        assert before != text and 'float8_quantize' not in before
        (S / 'cuda_provider.before.cc').write_text(before, encoding='utf-8', newline='')
    diff = ''.join(difflib.unified_diff(before.splitlines(True), text.splitlines(True),
        fromfile='before/' + path.name, tofile='after/' + path.name))
    (S / (path.name + '.diff')).write_text(diff, encoding='utf-8', newline='')

review = dict(
    files=records,
    native_builds=0, native_runs=0, downloads=0,
    operation='model_ops::Float8BlockQuantize',
    input='One dense plain BF16/F32 [M,K], M,K>0, K%128==0',
    outputs=['plain E4M3FN [M,K] codes', 'plain F32 [M,K/128] scales'],
    default='Divide / 1e-10, exactly the public Linear default; GLM chooses explicit PowerOfTwo / 1e-4',
    math=['Divide uses __fdiv_rn(maximum,448)',
          'MultiplyReciprocal uses __fmul_rn(maximum,F32 bits 0x3b124925), __fdiv_rn(1,scale), __fmul_rn(value,reciprocal)',
          'PowerOfTwo uses multiply-based raw scale, exponent bit-ceil and __fdiv_rn(value,scale)',
          'SDK __nv_cvt_float_to_fp8 SATFINITE E4M3 nearest-even preserves signed zero'],
    resources=dict(queue='existing admitted QueueSequence',
        status='acquire_device_status; invalid input writes kInvalidNumericInput; original Completion fails',
        aliases='none for either output; both actual pointers validated before status reset or launch',
        copies=0, shadow_buffers=0, workspace=0, invocation_private_bytes=0,
        persistent='sizeof(Prepared) metadata only',
        dispatch='one quantize kernel plus at most the common status reset',
        limits='descriptor bytes each <= PTRDIFF_MAX; 64-bit group/element offsets, grid capped at 65535'),
    design='one warp per contiguous group128, four register F32 values/lane; no host payload work',
    cuda_compile=dict(tu='src/compute_provider_cuda/float8_quantize_kernel.cu',
        recipe_build='.scratch/b-cuda-d5/build.ninja',
        recipe_object='src/compute_provider_cuda/CMakeFiles/hyle_compute_provider_cuda.dir/tensor_kernel.cu.obj',
        rule='.scratch/b-cuda-d5/CMakeFiles/rules.ninja: CUDA_COMPILER__hyle_compute_provider_cuda_unscanned_Release',
        notes='Reuse existing CUDA13.3 NVCC/includes/SM89 flags and cached toolchain; replace source/output/dependency paths. One small TU; no SDK build. Provider .cc and cuda_provider.cc require two host TU compiles. CMake registration belongs to root.'),
    review_limit='Source-reviewed only here. Root owns serialized compile/link/numeric and state checks.')
(S / 'review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(records, indent=2))
