"""Two-TU Apple validation using the existing MacBook Air SDK/cache.

`plan` is local only. Other explicit actions contact the configured Air; import
starts no native process, transfer, compilation, or remote action.
"""
from pathlib import Path
import argparse
import base64
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
HELPER = R / '.scratch/native-paged-effects-20261022/apple/mac.py'
spec = importlib.util.spec_from_file_location('fp8_apple_transport', HELPER)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)  # Source audited: only definitions; main is guarded.


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def plan_path(attempt):
    return S / 'apple' / ('attempt' + str(attempt) + '-plan.json')


def plan(attempt):
    target = plan_path(attempt)
    if target.exists():
        raise RuntimeError('Plan exists; use a new attempt rather than overwriting its frozen sources')
    m.REMOTE = m.BASE + '/fp8-quant-output-20261023/attempt' + str(attempt)
    cache_path = R / '.scratch/native-paged-effects-20261022/apple/mac-cached-closure.json'
    cache = json.loads(cache_path.read_bytes())
    baseline_path = R / '.scratch/qwen-retained-budget-20261022/apple-consumer1-plan.json'
    baseline = json.loads(baseline_path.read_bytes())
    mature = 'src/compute_route_apple/apple_mature_float.cc'
    test = 'tests/compute_models/float8_quantize_output_test.cc'
    row = next(x for x in cache['compile'] if x['file'].endswith('/' + mature))
    command = m.overlay_command(row, mature, m.REMOTE + '/mature.o')
    test_row = next(x for x in cache['compile'] if x['file'].endswith('/src/graph_route_apple/native_region.cc'))
    test_command = m.overlay_command(test_row, test, m.REMOTE + '/test.o')
    gtest = '/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
    test_command[1:1] = ['-DHYLE_TEST_FP8_QUANT_APPLE=1', '-isystem', gtest]
    # Use the latest exercised Graph/Compute closure, not the original SDK's
    # pre-state-ownership or pre-copy-retirement archives.
    link = next(x[1] for x in baseline['actions'] if x[0] == 'link').copy()
    old_consumer = baseline['remote'] + '/consumer.o'
    assert link.count(old_consumer) == 1
    point = link.index(old_consumer)
    link[point:point + 1] = [m.REMOTE + '/test.o', m.REMOTE + '/mature.o',
        '/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/lib/libgtest_main.a',
        '/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/lib/libgtest.a']
    image = m.REMOTE + '/fp8-quant-output-checks'
    link[link.index('-o') + 1] = image
    link = [x for x in link if not x.startswith('-Wl,-map,')]
    link += ['-Wl,-map,' + image + '.map']
    assert not any('force_load' in x or x == '-all_load' for x in link)
    # Existing Apple ExecutionSource interfaces and the last adapter fix are
    # unchanged. Only the public custom descriptor/header and mature lowering
    # need rebuilding for this operation.
    previous = {x['path']: x for x in baseline['files']}
    interfaces = ['include/hyle/graph/apple.h', 'include/hyle/graph/execution_source.h',
        'include/hyle/graph/executable.h', 'include/hyle/graph/graph.h',
        'include/hyle/compute/apple.h', 'include/hyle/compute/apple_memory.h']
    interface_facts = []
    for path in interfaces:
        now = m.ident(R / path)
        assert now['sha256'] == previous[path]['sha256'], path
        interface_facts.append(dict(path=path, sha256=now['sha256'], matches_retained_consumer=True))
    adapter = m.ident(R / 'src/graph_route_apple/execution_source.cc')
    prior_adapter = json.loads((R / '.scratch/qwen-native-assembly-20261022/apple/revision3-plan.json').read_bytes())['source']
    assert adapter['sha256'] == prior_adapter['sha256']
    files = []
    frozen = S / 'apple' / ('attempt' + str(attempt) + '-source')
    for path in m.include_closure([mature, test], [command, test_command]):
        rel = path.relative_to(R).as_posix()
        entry = m.ident(path)
        copy = frozen / rel
        copy.parent.mkdir(parents=True, exist_ok=True)
        copy.write_bytes(path.read_bytes())
        entry.update(path=rel, frozen=str(copy))
        files.append(entry)
    native_inputs = list(dict.fromkeys(x for x in link if x.endswith(('.o', '.a', '.dylib'))
                                      and not x.startswith(m.REMOTE + '/')))
    value = dict(remote=m.REMOTE, sdk=m.SDK, hardware='Mac16,12', host=m.HOST,
        jobs=[dict(tag='mature', argv=command), dict(tag='test', argv=test_command)],
        link=link, native_inputs=native_inputs, files=files, image=image,
        metallib=baseline['metallib'], expected_tests=2,
        filter='Float8QuantizeOutput.*', interface_facts=interface_facts,
        adapter=dict(source=adapter, matches_retained_revision3=True),
        source_scope='Two current TUs plus their header closure; zero SDK/source archive copy',
        helper=m.ident(HELPER), base_plan=m.ident(baseline_path), cache=m.ident(cache_path))
    save(target, value)
    print(json.dumps(dict(plan=str(target), remote=m.REMOTE, TUs=2,
        overlay_files=len(files), overlay_bytes=sum(x['bytes'] for x in files))))


REMOTE = r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as E
p=json.load(sys.stdin);root=Path(p['remote']);action=p['action']
def ident(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb')as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
def save(name,data):
 (root/name).write_text(json.dumps(data,indent=2)+'\n')
if action=='prepare':
 root.mkdir(parents=True);source=root/'source';source.mkdir()
 model=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()
 assert model==p['hardware'],model
 tools={}
 for tag,argv in [('compiler',['/usr/bin/c++','--version']),('metal',['/usr/bin/xcrun','metal','-v'])]:
  r=subprocess.run(argv,capture_output=True,text=True)
  tools[tag]=dict(argv=argv,exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
 assert tools['compiler']['exit']==0
 for item in p['files']:
  path=source/item['path'];assert path.is_relative_to(source)
  path.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(item['data'])
  assert len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256'];path.write_bytes(raw)
 inputs=[ident(x)for x in p['native_inputs']];metal=ident(p['metallib'])
 os.link(p['metallib'],root/'mlx.metallib')
 result=dict(hardware=model,tools=tools,inputs=inputs,metallib=metal,files=len(p['files']),SDK_builds=0)
 save('prepare.json',result);print(json.dumps(result));sys.exit(0)
assert root.is_dir()
if action=='poll':
 record=json.loads((root/'live.json').read_text())
 try:os.kill(record['pid'],0);record['pid_exists']=True
 except ProcessLookupError:record['pid_exists']=False
 print(json.dumps(record));sys.exit(0)
actions=[]
if action=='compile':actions=[(j['tag']+'-compile',j['argv'])for j in p['jobs']if not p.get('job')or j['tag']==p['job']]
elif action=='link':actions=[('link',p['link'])]
elif action=='run':actions=[('run',[p['image'],'--gtest_filter='+p['filter'],'--gtest_output=xml:'+str(root/'tests.xml')])]
else:raise RuntimeError(action)
records=[]
for tag,argv in actions:
 assert not(root/(tag+'.result.json')).exists(),'Action already completed; inspect receipt before retrying'
 record=dict(tag=tag,argv=argv,cwd=p['sdk']+'/build',started=time.time())
 env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_LIBRARY_PATH=p['sdk']+'/relocated/sdk/lib')
 with(root/(tag+'.stdout.log')).open('wb')as so,(root/(tag+'.stderr.log')).open('wb')as se:
  child=subprocess.Popen(argv,cwd=record['cwd'],env=env,stdout=so,stderr=se)
  record.update(pid=child.pid,state='running');save(tag+'.command.json',record);save('live.json',record)
  code=child.wait()
 record.update(exit=code,state='terminal',seconds=time.time()-record['started']);save(tag+'.result.json',record);save('live.json',record)
 records.append(record)
 if code:break
result=dict(records=records,all_exit_zero=len(records)==len(actions)and all(x['exit']==0 for x in records))
if action=='link'and result['all_exit_zero']:result['image']=ident(p['image'])
if action=='run'and(root/'tests.xml').is_file():
 tree=E.parse(root/'tests.xml');cases=tree.findall('.//testcase')
 result['tests']=len(cases);result['failed']=[x.attrib for x in cases if x.findall('failure')or x.findall('error')]
 result['skipped']=[x.attrib for x in cases if x.findall('skipped')or x.get('status')=='notrun']
 result['passed']=result['all_exit_zero']and len(cases)==p['expected_tests']and not result['failed']and not result['skipped']
 result['stdout']=(root/'run.stdout.log').read_text(errors='replace')
if not result['all_exit_zero']:result['stderr']=(root/(records[-1]['tag']+'.stderr.log')).read_text(errors='replace')
save(action+'-receipt.json',result);print(json.dumps(result))
'''


def invoke(action, attempt, job=None):
    value = json.loads(plan_path(attempt).read_bytes())
    value.update(action=action, job=job)
    if action == 'prepare':
        for item in value['files']:
            path = Path(item['frozen'])
            actual = m.ident(path)
            assert actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes']
            item['data'] = base64.b64encode(path.read_bytes()).decode()
    result = m.ssh(REMOTE, value, timeout=600)
    name = action + ('-' + job if job else '')
    save(S / 'apple' / ('attempt' + str(attempt) + '-' + name + '.json'), result)
    print(json.dumps(result, ensure_ascii=False))
    if result.get('all_exit_zero') is False or result.get('passed') is False:
        raise SystemExit(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['plan', 'prepare', 'compile', 'link', 'run', 'poll'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--job', choices=['mature', 'test'])
    args = parser.parse_args()
    if args.attempt < 1:
        parser.error('--attempt must be positive')
    plan(args.attempt) if args.action == 'plan' else invoke(args.action, args.attempt, args.job)
