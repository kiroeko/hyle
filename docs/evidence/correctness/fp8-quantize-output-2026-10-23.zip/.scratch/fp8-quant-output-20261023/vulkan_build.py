"""Focused Vulkan FP8-output host increment; root executes all native work."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
V = S / 'vulkan-build'
A = R / '.scratch/architecture-refactor-2026-10-18'
Q = A / 'quark-block128-scale-2026-10-21'
BASE = R / '.scratch/qwen-retained-budget-20261022/vulkan-build/link3'
spec = importlib.util.spec_from_file_location(
    'fp8_vulkan_cached_host', R / '.scratch/native-paged-effects-20261022/build_windows.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
h.S = V
RECIPES = {
    **{tag: Q / f'vulkan/windows/checks/attempt1/{tag}/identity.json'
       for tag in ('native-program', 'embedded', 'iree', 'official')},
    'program': R / '.scratch/qwen-retained-budget-20261022/vulkan-build/compile1/program/identity.json',
    'region': R / '.scratch/qwen-retained-budget-20261022/vulkan-build/compile1/region/identity.json',
    'vulkan-run': A / 'mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_run-identity.json',
    'test': Q / 'windows/checks/attempt3/vulkan-scale-policy-test/identity.json',
}
SOURCES = {
    'native-program': R / 'src/compute_provider_iree_vulkan/native_program.cc',
    'embedded': S / 'generated/programs.cc',
    'iree': R / 'src/compute_route_vulkan/vulkan_iree.cc',
    'official': R / 'src/compute_route_vulkan/vulkan_official.cc',
    'program': R / 'src/compute_route_vulkan/vulkan_program.cc',
    'region': R / 'src/compute_route_vulkan/vulkan_region.cc',
    'vulkan-run': R / 'src/compute_route_vulkan/vulkan_run.cc',
    'test': R / 'tests/compute_models/float8_quantize_output_test.cc',
}


def host(tag, attempt):
    recipe = c.read(RECIPES[tag])
    # These original IREE recipes spell the same dynamic CRT option as -MD;
    # the shared incremental helper verifies its canonical /MD spelling.
    recipe['command'] = ['/MD' if arg == '-MD' else arg for arg in recipe['command']]
    if tag == 'test':
        # Reuse the actual Vulkan/gtest host toolchain; the new TU selects only
        # its shared contract and Vulkan case, not the old scale-policy macros.
        recipe['command'] = [x for x in recipe['command']
            if not x.startswith(('/DHYLE_TEST_', '-DHYLE_TEST_',
                                 '/DHYLE_VULKAN_TEST_SHADER=', '-DHYLE_VULKAN_TEST_SHADER='))]
        recipe['command'] += ['/DHYLE_TEST_FP8_QUANT_VULKAN=1',
            '/I' + str(R / 'src/compute_ggml_runtime')]
    path = V / 'recipes' / (tag + '.json')
    path.parent.mkdir(parents=True, exist_ok=True)
    c.save(path, recipe)
    h.RECIPES[tag], h.SOURCES[tag] = path, SOURCES[tag]
    h.compile_one(tag, attempt)


def latest(tag):
    records = sorted(V.glob(f'compile*/{tag}/identity.json'),
                     key=lambda path: int(path.parents[1].name[7:]))
    if not records:
        raise RuntimeError('missing compiled Vulkan host object: ' + tag)
    path = records[-1]
    row = c.read(path)
    for item in (row['source'], row['object'], *row['dependencies']):
        assert b.identity(item['path']) == item, item
    return path, row


def stage_runtime(out):
    # The retained-output baseline is static and has no adjacent staged DLLs.
    # Preserve its real loader precedence using existing files, with hardlinks
    # only. No SDK copy, binary overwrite or changed runtime candidate is used.
    source = BASE / 'runtime-environment.json'
    runtime = c.read(source)
    seen = set()
    staged = []
    for folder in runtime['runtime']:
        directory = Path(folder)
        if not directory.is_dir():
            continue
        for dll in sorted(directory.glob('*.dll')):
            name = dll.name.casefold()
            if name in seen:
                continue
            seen.add(name)
            target = out / dll.name
            os.link(dll, target)
            staged.append(dict(source=b.identity(dll), target=b.identity(target),
                               method='hardlink'))
    runtime['PATH'] = str(out) + ';' + runtime['PATH']
    runtime['base_runtime'] = b.identity(source)
    runtime['staged_dlls'] = [item['target'] for item in staged]
    runtime['hardlinks'] = staged
    c.save(out / 'runtime-environment.json', runtime)


def link(attempt):
    base_path = BASE / 'link-plan.json'
    base = c.read(base_path)
    replacements, records = {}, []
    for tag in SOURCES:
        path, row = latest(tag)
        records.append(b.identity(path))
        if tag == 'test':
            # The base contains a standalone retained-output consumer, not the
            # historical gtest TU whose command supplies our host recipe.
            old_path = R / '.scratch/qwen-retained-budget-20261022/vulkan-build/compile3/test/identity.json'
        else:
            old_path = RECIPES[tag]
        old = c.read(old_path)
        key = c.key(old['object']['path'])
        assert sum(c.key(item['path']) == key for item in base['inputs']) == 1, key
        replacements[key] = row['object']
    for item in base['inputs']:
        assert b.identity(item['path']) == item, item
    inputs = [replacements.get(c.key(item['path']), item) for item in base['inputs']]
    command = [replacements.get(c.key(arg), {}).get('path', arg)
        for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    # The inspected baseline already has both libraries. Ensure them explicitly
    # without duplicates, also supporting the same closure if its main changes.
    for library in ('gtest_main.lib', 'gtest.lib'):
        path = R / '.scratch/build-compute-v2-dev/lib' / library
        key = c.key(str(path))
        if not any(c.key(item['path']) == key for item in inputs):
            inputs.append(b.identity(path))
        if not any(c.key(arg) == key for arg in command):
            command.append(str(path))
        assert sum(c.key(item['path']) == key for item in inputs) == 1
        assert sum(c.key(arg) == key for arg in command) == 1
    assert len(replacements) == 8
    out = V / f'link{attempt}'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'fp8-quant-vulkan-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=records, base=b.identity(base_path), replacements=replacements,
        product_host_translation_units=7, test_translation_units=1,
        SDK_builds=0, NVCC=0, shader_builds=0,
        official_VMFB='root separately compiled the changed official program; embedded source binds its actual bytes'))
    env, _ = b.environment(command, [item['path'] for item in inputs], out)
    c.execute('link', command, env, out)
    stage_runtime(out)
    c.save(out / 'ready.json', dict(image=b.identity(image),
        link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json')))
    print('LINKED Vulkan FP8 output checks', flush=True)


def run(link_attempt, attempt):
    spec_run = importlib.util.spec_from_file_location(
        'fp8_vulkan_run_helpers', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    q = importlib.util.module_from_spec(spec_run)
    spec_run.loader.exec_module(q)
    folder = V / f'link{link_attempt}'
    image = c.read(folder / 'ready.json')['image']
    assert b.identity(image['path']) == image
    env = os.environ.copy()
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    out = V / f'run{attempt}'
    xml = out / 'results.xml'
    command = [image['path'], '--gtest_filter=Float8QuantizeOutput.*',
               '--gtest_output=xml:' + str(xml)]
    process = q.execute(command, env, out, timeout=600)
    result = dict(process=process, image=image, throughput_evidence=False,
                  physical_memory_evidence=False, whole_original_model=False)
    if xml.is_file():
        root = ET.parse(xml).getroot()
        result.update(tests=int(root.attrib['tests']), failures=int(root.attrib['failures']),
            errors=int(root.attrib['errors']), disabled=int(root.attrib['disabled']),
            skips=sum(case.find('skipped') is not None for case in root.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value']
                for p in case.iter('property')}) for case in root.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == 2, result
    assert not any(result[name] for name in ('failures', 'errors', 'disabled', 'skips')), result
    print('PASS Vulkan shared contract and actual code/scale Graph checks', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('actions', nargs='+', choices=[*SOURCES, 'link', 'run'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    args = parser.parse_args()
    for action in args.actions:
        if action == 'link':
            link(args.attempt)
        elif action == 'run':
            run(args.link_attempt, args.attempt)
        else:
            host(action, args.attempt)
