$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path -LiteralPath '.').Path
$oldParent = (Resolve-Path -LiteralPath '.scratch/glm-mtp-seed-cache-20261022/tests-link8').Path
$scratchPrefix = (Resolve-Path -LiteralPath '.scratch').Path.TrimEnd('\') + '\'
if (-not $oldParent.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Outside repository scratch' }
# Superseded by this round's passing 19-case executable. Retain its objects,
# source, link plan and runtime DLLs for future incremental linking.
$entries = @(
    [pscustomobject]@{ Path = (Join-Path $oldParent 'mtp-seed-cache-checks.exe'); Bytes = 141045760 },
    [pscustomobject]@{ Path = (Join-Path $oldParent 'mtp-seed-cache-checks.map'); Bytes = 59602899 }
)
$protected = @(
    '.scratch/fp8-quant-output-20261023/tests-link1/fp8-quant-output-checks.exe',
    '.scratch/fp8-quant-output-20261023/vulkan-build/link1/fp8-quant-vulkan-checks.exe',
    '.scratch/qwen-mtp-next-20261022/hyle-link4/qwen.exe'
)
foreach ($keep in $protected) {
    if (-not (Test-Path -LiteralPath $keep -PathType Leaf)) { throw "Protected image missing: $keep" }
}
foreach ($entry in $entries) {
    $target = (Resolve-Path -LiteralPath $entry.Path).Path
    if ((Split-Path -Parent $target) -ne $oldParent) { throw "Unexpected target: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.Bytes) { throw "Changed size: $target" }
}
foreach ($entry in $entries) { Remove-Item -LiteralPath $entry.Path -Force }
$result = [pscustomobject]@{
    Removed = $entries
    RemovedPathBytes = ($entries | Measure-Object -Property Bytes -Sum).Sum
    ProtectedImagesRetained = @($protected | ForEach-Object { Test-Path -LiteralPath $_ })
    Retained = 'All compiled objects, runtime hardlinks, source/commands/data; current CPU/CUDA and Vulkan checks and AV performance image'
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $repoRoot '.scratch/fp8-quant-output-20261023/cleanup-result.json') -Encoding utf8
$result | Select-Object RemovedPathBytes, ProtectedImagesRetained
