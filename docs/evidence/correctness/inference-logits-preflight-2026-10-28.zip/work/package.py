"""Offline compact evidence only. No compiler, consumer, SDK or model payload."""
from pathlib import Path
import datetime, difflib, hashlib, json, subprocess, zipfile
W = Path(__file__).resolve().parent; R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-logits-preflight-2026-10-28'
BASE = 'adb2ee9a97301bd443ddd80ed1aba254be93b445'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def data(value): return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def pin(path):
    path = Path(path).resolve(); content = path.read_bytes()
    return dict(path=str(path),bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
def verify(row):
    now = pin(row['path']); assert (now['bytes'],now['sha256']) == (row['bytes'],row['sha256']),row['path']

files = {}
def add(path,name=None):
    path = Path(path).resolve(); assert path.is_file(),path
    assert path.suffix.casefold() not in ('.obj','.exe','.pdb','.dll','.lib','.exp','.bin'),path
    archive = name or 'work/'+path.relative_to(W).as_posix()
    assert archive not in files,archive
    files[archive] = path.read_bytes()

plan = read(W/'build-plan.json'); cpu = read(W/'source-freeze.json')
assert cpu['base'] == BASE and cpu['status'] == 'SOURCE_FROZEN'
for name in ('baseline','inputs','link_recipe','compile_recipe','cpu_source_freeze','source_freeze','project_dependencies'):
    verify(plan[name])
source_rows = read(W/'consumer-source-freeze.json'); assert len(source_rows) == 6
for row in source_rows:
    verify(row['snapshot'])
    relative = Path(row['original']['path']).relative_to(R).as_posix()
    add(row['snapshot']['path'],'source/'+relative)
for row in cpu['sources']:
    owned = next(x for x in source_rows if Path(x['original']['path']).relative_to(R).as_posix() == row['path'])
    assert (owned['snapshot']['bytes'],owned['snapshot']['sha256']) == (row['bytes'],row['sha256'])

ready = {name:read(W/('ready-'+name+'.json')) for name in ('tiny','lifecycle')}
for name,item in ready.items():
    assert item['process']['exit'] == 0 and not item['process']['timed_out']
    compiled = item['compiled']; assert compiled['process']['exit'] == 0 and not compiled['process']['timed_out']
    assert len(read(item['inputs']['path'])) == 228
    for field in ('inputs','recipe','plan'): verify(item[field])
    for field in ('command','dependencies','actual_project_dependencies'): verify(compiled[field])

runs = {}
for name in ('tiny-cpu','tiny-cuda','modifiers'):
    directory = W/('run-'+name); summary = read(directory/'summary.json'); process = read(directory/'process.json')
    assert process == summary['process'] and process['exit'] == 0 and not process['timed_out']
    assert summary['status'] == 'PASS' and summary['report']['status'] == 'PASS'
    assert summary['report']['final_versions'] == 0
    assert read(directory/'report.json') == summary['report']
    raw = [json.loads(line) for line in (directory/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert raw == [summary['report']]
    if name != 'modifiers':
        report = summary['report']
        assert report['preflight_submissions'] == 0 and report['key_slot'] == 1 and report['batch_position'] == 0
        assert all(report[key] for key in ('typed_invalid_argument','original_key','complete_state_unchanged',
            'all_ledger_records_unchanged','old_checkpoints_unchanged','same_key_peer_continued'))
    runs[name] = dict(process=process,report=summary['report'],command=read(directory/'command.json'))
modifier_stderr = (W/'run-modifiers/stderr.log').read_text(encoding='utf-8-sig')
numeric_lines = [line for line in modifier_stderr.splitlines() if line.startswith('modifier_invalid_')]
assert len(numeric_lines) == 2
assert 'participant=0' in numeric_lines[0] and 'retirement_seen=1 retired=1 cleanup=' in numeric_lines[0]
assert 'qualified=1 slot=1 same_A=1 same_B=1 B_boundary=1 outputs=0,0 commits=0,0 active=0 carrier=0' in numeric_lines[1]

for relative in ('base.json','build.py','build-plan.json','source-freeze.json','consumer-source-freeze.json',
        'project-dependencies.json','environment.json','runtime-actual.json','inputs-tiny.json','inputs-lifecycle.json',
        'ready-tiny.json','ready-lifecycle.json','package.py'):
    add(W/relative)
for name in ('tiny','lifecycle'):
    add(W/'recipes'/(name+'.json'))
    for filename in ('dependencies.json','actual-project-dependencies.json','compiled.json'):
        add(W/'compile'/name/filename)
    for stage in ('logs','link'):
        for filename in ('command.json','process.json','stdout.log','stderr.log'):
            add(W/stage/name/filename)
for name in runs:
    for filename in ('command.json','process.json','stdout.log','stderr.log','report.json','summary.json'):
        add(W/('run-'+name)/filename)

changes = []
for row in source_rows:
    relative = Path(row['original']['path']).relative_to(R).as_posix()
    before = subprocess.run(['git','show',BASE+':'+relative],cwd=R,capture_output=True)
    assert before.returncode == 0 or relative == 'tests/tools/qwen_logits_preflight_case.h',relative
    original = before.stdout.decode('utf-8-sig').replace('\r\n','\n').splitlines(keepends=True) if before.returncode == 0 else []
    after = files['source/'+relative].decode('utf-8-sig').replace('\r\n','\n').splitlines(keepends=True)
    changes.extend(difflib.unified_diff(original,after,fromfile='a/'+relative if original else '/dev/null',tofile='b/'+relative))
files['owned-source-changes.patch'] = ''.join(changes).encode('utf-8')
files['source-aliases.json'] = data({row['snapshot']:'source/'+row['path'] for row in cpu['sources']})

starts = [item['compiled']['process']['started'] for item in ready.values()]
ends = [x['process']['started']+x['process']['seconds'] for x in runs.values()]
utc = lambda seconds:datetime.datetime.fromtimestamp(seconds,datetime.timezone.utc).isoformat()
summary = dict(schema='hyle.correctness.logits_preflight.v1',status='PASS',base_commit=BASE,
    source_identity=dict(product=cpu['sources'],consumers=source_rows),
    scope='Ordinary known-request logits metadata preflight and original key attribution; shared RequestLoop/Model/Graph ownership.',
    actual_window_utc=dict(first_compile_started=utc(min(starts)),last_consumer_completed=utc(max(ends))),
    builds={name:dict(compile=item['compiled']['process'],link=item['process'],image=item['image'],
        object=item['compiled']['object'],inputs=item['inputs']) for name,item in ready.items()},
    budgets=dict(actual_CXX=2,actual_links=2,link_inputs_each=228,actual_consumer_processes=3,
        failed_attempts=0,reruns=0,NVCC=0,standalone_Model_TU=0,SDK_rebuild=0,downloads=0),
    runs=runs,original_allfalse_numeric_failure=numeric_lines,
    checked_contracts=[
        'Two registered requests first publish a real R2 prefill; each output is acknowledged through the original delivery owner.',
        'B keeps its valid ready Bool lease but replaces dense [1,V] metadata with [V]. Its original key slot is 1 while its actual next cohort position is 0.',
        'The resulting RequestExecutionFailure preserves InvalidArgument and the complete original B key, without inventing a decoded participant, native error or retirement observation.',
        'No new native submission occurs; both full initialized HostImage payloads, scalar boundaries, head pointers/epochs, RNG cursors, generated outputs and all committed/reserved ledger records remain exact.',
        'The original RequestLoop owner cancels B. A keeps its original key and continues through exactly one original R1 decode; old checkpoints remain exact and final versions/pages/episodes retire.',
        'The separately retained original CPU modifier journey still sends the valid all-false mask to actual Graph execution and gets EvaluationFailure with participant0 and successful true retirement; it is not classified as metadata preflight.',
        'Original dynamic input replacement, StateOnly-without-inputs, same-key ledger restoration and new-request full-prefix own-input sampling remain covered by that finite modifier consumer.'
    ],
    artifact_boundaries=[
        'Untrained cached GA/H64/V64 C16 fixture for CPU/CUDA preflight; original cached A/H64/V64 C16 fixture for CPU modifier regression.',
        'Complete state/checkpoint payloads were compared in-process by the frozen test source; no new raw HostImage payload dumps were emitted or fabricated.',
        'The six owned source snapshots, base commit, patch, actual dependency manifests, retained link-input identities, commands and raw logs support reproduction with the same existing caches.',
        'Archive excludes SDK contents, object files, executables, PDBs, DLL bodies and model weights. Recorded image/object identities identify actual processes; their payloads are retained separately in scratch.',
        'No speed, quality, server, unknown hardware fault, generalized runtime attribution or renewed MTP-function claim.'
    ],quality_claim=False,performance_claim=False)
files['summary.json'] = data(summary)
manifest = {name:dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest()) for name,content in sorted(files.items())}
files['manifest.json'] = data(manifest)
archive = DEST.with_suffix('.zip'); assert not archive.exists(),archive
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,content in sorted(files.items()): output.writestr(name,content)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name,expected in manifest.items():
        actual = check.read(name)
        assert len(actual) == expected['bytes'] and hashlib.sha256(actual).hexdigest() == expected['sha256'],name
summary['archive'] = {**pin(archive), 'members':len(files),'crc':'PASS','all_member_sha256':'PASS',
    'manifest_member':'manifest.json','summary_member':'summary.json'}
destination = DEST.with_suffix('.json'); assert not destination.exists(),destination
destination.write_bytes(data(summary))
assert read(destination)['budgets']['actual_consumer_processes'] == 3
receipt = dict(status='ARCHIVED_AND_READ_BACK',evidence=pin(destination),archive=pin(archive),
    members=len(files),crc='PASS',all_member_sha256='PASS',raw_numeric_failure_lines=numeric_lines)
(W/'packaged.json').write_bytes(data(receipt))
print(json.dumps(receipt,ensure_ascii=False,indent=2))
