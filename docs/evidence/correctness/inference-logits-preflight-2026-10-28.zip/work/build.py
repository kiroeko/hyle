"""Two current consumer TUs, retained 228-input SDK closure; explicit actions only."""
from pathlib import Path
import importlib.util, json, os, re, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
OLD_ENV = t.W / 'environment.json'
t.W = W
BASE = R / '.scratch/inference-append-transactions-20261028/ready-tiny.json'
SOURCES = {'tiny': 'tests/tools/qwen_host_image_test.cc', 'lifecycle': 'tests/tools/qwen_request_lifecycle_test.cc'}
OWNED = ('engine/models/qwen35/main.cc', 'engine/inference/request_execution_failure.h',
    'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_logits_preflight_case.h',
    'tests/tools/qwen_request_lifecycle_test.cc', 'tests/tools/qwen_logits_modifier_case.h')
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
MODIFIER_FIXTURE = R / '.scratch/inference-e4-model-20261025/fixture-preparation/bf16-original'
DLL = R / '.scratch/inference-slot-cohort-refinement-20261028/bin/hyle_ggml_cpu_gdn_scale_v3.dll'

def prepare():
    cpu = t.read(W / 'source-freeze.json')
    for source in cpu['sources']:
        for path in (R / source['path'], R / source['snapshot']):
            now = t.pin(path)
            assert (now['bytes'], now['sha256']) == (source['bytes'], source['sha256']), path
    ready = t.read(BASE); rows = t.read(ready['inputs']['path'])
    assert len(rows) == 228
    old = ready['compiled']['object']
    assert sum(t.key(x['path']) == t.key(old['path']) for x in rows) == 1
    recipe = t.command(ready['compiled']['command']['path'])
    assert sum(a.casefold().endswith(('.cc', '.cpp', '.cxx')) for a in recipe) == 1
    files = {R / p for p in OWNED}
    files.update(p for p in t.dep_paths(Path(ready['compiled']['object']['path']).parent / 'dependencies.json') if t.project(p))
    todo = list(files)
    while todo:
        source = todo.pop()
        for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"', source.read_text(encoding='utf-8-sig'), re.M):
            found = next((candidate.resolve() for parent in (source.parent, R / 'include', R)
                if (candidate := parent / inc).is_file()), None)
            if found is not None and t.project(found) and found not in files:
                files.add(found); todo.append(found)
    project = [t.pin(path) for path in sorted(files)]
    t.save(W / 'project-dependencies.json', project)
    snapshots = []
    for relative in OWNED:
        source = R / relative; target = W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / 'consumer-source-freeze.json', snapshots)
    for name, relative in SOURCES.items():
        out = W / 'compile' / name; command = []
        for index, arg in enumerate(recipe):
            if index and recipe[index - 1].casefold() == '/sourcedependencies': arg = str(out / 'dependencies.json')
            elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
            elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.casefold().endswith(('.cc', '.cpp', '.cxx')): arg = str(R / relative)
            command.append(arg)
        t.save(W / 'recipes' / (name + '.json'), dict(command=command, timeout_seconds=300))
    env = t.read(OLD_ENV); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'build-plan.json', dict(status='PREPARED_FROZEN_NOT_BUILT_OR_RUN',
        baseline=t.pin(BASE), inputs=ready['inputs'], link_recipe=ready['recipe'],
        original_object=old, compile_recipe=ready['compiled']['command'],
        cpu_source_freeze=t.pin(W / 'source-freeze.json'),
        source_freeze=t.pin(W / 'consumer-source-freeze.json'), project_dependencies=t.pin(W / 'project-dependencies.json'),
        sources=SOURCES, recipes={n:t.pin(W/'recipes'/(n+'.json')) for n in SOURCES},
        fixtures=dict(tiny=t.pin(FIXTURE/'weights.tsv'), modifier=t.pin(MODIFIER_FIXTURE/'weights.tsv')),
        runtime_dll=t.pin(DLL), counts=dict(CXX=2, links=2, inputs_per_image=228, Model_TU=0, SDK=0, NVCC=0, downloads=0),
        commands=dict(tiny_cpu=['--cpu',str(FIXTURE),'--logits-preflight'],
            tiny_cuda=['--cuda',str(FIXTURE),'--logits-preflight'],
            modifiers=['--logits-modifiers',str(MODIFIER_FIXTURE)]),
        scope='Current real Model included in each consumer TU. Replace only original tiny object; no standalone Model compile. '
            'Modifier regression is original CPU A fixture and actual lifecycle flag; no stale executable used. '
            'Canonical compile, owned source snapshots and exact project dependencies; external SDK remains in place. '
            'Every process single-use; parser failure never authorizes inference rerun.'))
    print('PREPARED: 2 consumer CXX, 2 links, 228 retained inputs each; zero builds/runs')

def validate():
    plan = t.read(W/'build-plan.json')
    for name in ('baseline','inputs','link_recipe','compile_recipe','cpu_source_freeze','source_freeze','project_dependencies'):
        t.exact(plan[name])
    for source in t.read(plan['source_freeze']['path']):
        t.exact(source['original']); t.exact(source['snapshot'])
    return plan

def compile_one(name):
    plan = validate(); assert name in SOURCES
    pins = t.read(plan['project_dependencies']['path']); allowed = {t.key(p['path']):p for p in pins}
    for row in pins: t.exact(row)
    out = W/'compile'/name; out.mkdir(parents=True, exist_ok=False)
    t.exact(plan['recipes'][name]); recipe = t.read(plan['recipes'][name]['path'])
    process = t.execute(recipe['command'], W/'logs'/name, recipe['timeout_seconds'])
    actual = list(dict.fromkeys(t.dep_paths(out/'dependencies.json')))
    product = []
    for path in actual:
        if t.project(path):
            assert t.key(path) in allowed, ('unexpected live project include',str(path))
            t.exact(allowed[t.key(path)]); product.append(t.pin(path))
    t.save(out/'actual-project-dependencies.json', product)
    t.save(out/'compiled.json', dict(source=t.pin(R/SOURCES[name]), object=t.pin(out/'unit.obj'), process=process,
        command=t.pin(W/'logs'/name/'command.json'), dependencies=t.pin(out/'dependencies.json'),
        actual_project_dependencies=t.pin(out/'actual-project-dependencies.json')))
    print('CXX_PASS', name)

def link(name):
    plan = validate(); assert name in SOURCES
    item = t.read(W/'compile'/name/'compiled.json'); t.exact(item['object'])
    old = plan['original_object']['path']; original = t.read(plan['inputs']['path'])
    assert sum(t.key(x['path']) == t.key(old) for x in original) == 1
    rows = [item['object'] if t.key(x['path']) == t.key(old) else x for x in original]
    assert len(rows) == 228 and len({t.key(x['path']) for x in rows}) == 228
    for row in rows:
        path = Path(row['path']); assert path.is_file() and path.stat().st_size == row['bytes'], path
    image = W/'bin'/(name+'.exe'); image.parent.mkdir(exist_ok=True); assert not image.exists()
    command = []
    for arg in t.command(plan['link_recipe']['path']):
        if t.key(arg) == t.key(old): arg = item['object']['path']
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if arg.upper().startswith(prefix): arg = prefix+str(image.with_suffix(suffix)); break
        command.append(arg)
    t.save(W/('inputs-'+name+'.json'), rows)
    process = t.execute(command,W/'link'/name,240)
    t.save(W/('ready-'+name+'.json'),dict(image=t.pin(image), inputs=t.pin(W/('inputs-'+name+'.json')),
        recipe=t.pin(W/'link'/name/'command.json'), process=process, compiled=item, plan=t.pin(W/'build-plan.json')))
    print('LINK_PASS',name,len(rows))

def parse(name):
    out = W/('run-'+name); process = t.read(out/'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 1, len(reports)
    report = reports[0]; assert report['status'] == 'PASS' and report['final_versions'] == 0
    if name == 'modifiers':
        assert report['allmasked_survivor'] and report['state_only_without_inputs'] and report['same_key_restore']
        stderr = (out/'stderr.log').read_text(encoding='utf-8-sig')
        assert 'modifier_invalid_batch participant=0' in stderr and 'retirement_seen=1 retired=1' in stderr
    else:
        assert report['case'] == 'logits-preflight' and report['preflight_submissions'] == 0
    t.save(out/'report.json',report); t.save(out/'summary.json',dict(status='PASS',process=process,report=report,
        quality_claim=False,performance_claim=False))
    print('FINITE_CONSUMER_PASS',name)

def run(name):
    plan = validate(); assert name in ('tiny-cpu','tiny-cuda','modifiers')
    binary = 'lifecycle' if name == 'modifiers' else 'tiny'
    ready = t.read(W/('ready-'+binary+'.json')); t.exact(ready['image'])
    for row in plan['fixtures'].values(): t.exact(row)
    t.exact(plan['runtime_dll']); target = W/'bin'/DLL.name
    if not target.exists(): os.link(DLL,target)
    assert os.path.samefile(DLL,target)
    if not (W/'runtime-actual.json').exists():
        t.save(W/'runtime-actual.json',dict(kind='existing_cpu_DLL_hardlink_no_payload_copy',source=plan['runtime_dll'],
            target=str(target),same_file=os.path.samefile(DLL,target)))
    args = plan['commands']['modifiers' if name == 'modifiers' else name.replace('-','_')]
    out = W/('run-'+name); assert not out.exists(), 'One attempt only; parse offline if needed'
    t.execute([ready['image']['path'],*args],out,240)
    parse(name)

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'link': link(sys.argv[2])
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
