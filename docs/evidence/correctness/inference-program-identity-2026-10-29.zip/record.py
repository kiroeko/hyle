"""Check the six completed finite cases and preserve small, non-secret receipts."""
from pathlib import Path
import hashlib
import json
import os
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-program-identity-2026-10-29.json'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    p = Path(path).resolve()
    location = p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p)
    return dict(path=location, bytes=p.stat().st_size,
                sha256=hashlib.file_digest(p.open('rb'), 'sha256').hexdigest())

def states(report, count):
    assert len(report['state_checks']) == count
    for item in report['state_checks']:
        assert item['boundary_equal'] and item['payloads_byte_equal'] and item['numerically_equivalent']
        assert item['exact_next'] == item['bucket_next'] and not item['differences']

def terminal(path):
    p = read(path)
    assert p['state'] == 'TERMINAL' and p['exit'] == 0 and not p['timed_out']
    return p

plan = read(W / 'plan.json')
for item in plan['retained']:
    actual = identity(item['path'])
    assert all(actual[k] == item[k] for k in ('bytes', 'sha256'))

builds = {}
for unit, attempt in [('tiny', 'process'), ('ordinary', 'process')]:
    receipt = read(W / 'compile' / unit / 'receipt.json')
    for item in receipt['source_identities']:
        actual = identity(item['path'])
        assert all(actual[k] == item[k] for k in ('bytes', 'sha256'))
    builds[unit] = dict(compile=terminal(W / 'compile' / unit / attempt / 'process.json'),
        link=terminal(W / 'link' / unit / 'process.json'), source=identity(plan['units'][unit]['source']),
        image=identity(W / 'bin' / (unit + '.exe')), object=identity(W / 'compile' / unit / 'unit.obj'),
        project_source_inputs=len(receipt['source_identities']))

reports = {}
for name in plan['cases']:
    r = read(W / 'runs' / name / 'report.json')
    process = terminal(W / 'runs' / name / 'process.json')
    assert r['status'] == 'PASS'
    if name.startswith('program-'):
        assert r['models'] == 0 and r['native_submissions'] == r['carriers'] == 2
        for field in ('cold_failure_atomic', 'independent_fixed_bindings', 'real_completion_retirement',
                      'GraphOutput_pin_preserved', 'typed_io_installation', 'common_slot_inventory',
                      'group_cold_failure_unpublished', 'group_initialization_idempotent', 'group_retirement_original',
                      'unsealed_io_rejected', 'foreign_io_rejected', 'standalone_signature_preserved',
                      'finite_child_signature_preserved', 'finite_child_variant_preserved', 'group_initialization_recipe_lazy',
                      'partial_installation_failed', 'partial_caller_writer_tested', 'partial_caller_writer_recovered',
                      'valid_io_retry_output_checked', 'exact_resource_rejection_atomic',
                      'exact_resource_original_graph_borrowed', 'closed_handle_not_reused', 'teardown_handoff_irreversible'):
            assert r[field] is True, (name, field)
        summary = dict(native_submissions=2, models=0, complete_original_group_checks=True)
    elif name.startswith('controls-'):
        assert r['case'] == 'natural-logits-control' and r['models'] == r['configurations'] == 1
        assert r['original_GenerationRequest'] and not r['natural_RequestLoop']
        assert r['synthetic_untrained'] and not r['quality_claim'] and not r['performance_claim']
        assert r['target_submissions'] == 9 and r['final_versions'] == 0
        assert r['terminated_hypothesis_callbacks'] == r['ended_prepare_provider_calls'] == 0
        assert r['stop_provider_calls'] == r['stop_verified_rows'] == 2 and r['stop_reserved_draws'] == 3
        assert r['successful_R2_Verify_submissions'] == r['cancelled_R2_Verify_submissions'] == 1
        assert r['survivor_R1_Verify_submissions'] == 1 and r['real_q_leases_per_R2'] == 4
        assert r['parked_resident_versions'] == 0
        for field in ('extra_stop_first_draft', 'absorbing_bonus_reuses_last_row', 'mixed_R2_dynamic_static',
                      'q_conditional_owners_cleared', 'whole_episode_retired', 'cancelled_heads_ledger_RNG_unchanged',
                      'independent_request_RNG', 'HostImage_same_key_restore', 'old_checkpoints_unchanged'):
            assert r[field] is True, (name, field)
        states(r, 3)
        assert [s['sequence'] for s in r['state_checks']] == [0, 1, 2]
        assert all(s['active_rows'] == s['physical_rows'] == 3 for s in r['state_checks'])
        summary = dict(target_submissions=9, complete_state_byte_checks=3,
            scope='Original K2/R2 GenerationRequest; dynamic/static sampling, stop, cancellation, survivor and HostImage restore.')
    elif name == 'mtp-cuda':
        assert r['case'] == 'mtp-natural-relay' and r['models'] == 1 and r['journeys'] == 2
        assert r['output_limit'] == r['outputs'] == 40 and r['final_versions'] == 0
        assert r['natural_RequestLoop'] and not r['controlled_acceptance']
        assert not r['quality_claim'] and not r['performance_claim']
        for field in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
            assert r[field] is True, field
        for field in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                      'deferred_waves', 'reserved_two_grants'):
            assert r[field] > 0, field
        states(r, 1)
        summary = {k: r[k] for k in ('outputs', 'serial_submissions', 'auto_submissions', 'successor_submissions',
                                   'successor_publications', 'successor_discards', 'accepted_drafts', 'rejected_drafts')}
        summary['complete_state_byte_checks'] = 1
    else:
        assert name == 'ordinary-cuda' and r['control_and_candidate_arms'] == 16
        assert r['fixture'] == 'untrained_GA_H64' and r['in_flight_batches'] == 2
        assert not r['model_quality_claim'] and not r['performance_claim'] and not r['gpu_native_fault_injected']
        for field in ('same_original_executor', 'complete_prefix_state_epoch_rng_equal', 'actual_owner_credit_checked',
                      'all_source_session_page_owners_retired', 'accepted_work_control_exception'):
            assert r[field] is True, field
        candidates = r['candidates']
        assert len(candidates) == 8
        assert [(a['requests'], a['mode']) for a in candidates] == [
            (1, 'normal'), (2, 'normal'), (2, 'credit_exhaustion'), (2, 'member_cancel'),
            (2, 'yield_resume'), (2, 'cancel_then_control_exception'), (1, 'extra_stop'), (2, 'extra_stop')]
        assert all(a['submit_before_observe'] > 0 and a['pending_length27'] for a in candidates)
        assert candidates[2]['credit_drains'] == candidates[3]['cancelled_requests'] == candidates[4]['yield_drains'] == 1
        assert candidates[5]['control_exceptions'] == 1 and candidates[5]['aborted_actual_submissions'] == 2
        assert all(a['extra_stop_accepted_successor'] and a['discarded_batches'] == 1 for a in candidates[6:])
        assert candidates[7]['survivor_r1_steps'] > 0
        summary = dict(control_and_candidate_arms=16, candidates=8, original_complete_prefix_state_epoch_rng_equal=True,
            scope='CUDA R1/R2 continuous pipeline, credit, member cancel, yield, stop and post-submit control failure.')
    reports[name] = dict(status='PASS', process=process, summary=summary,
                         report=identity(W / 'runs' / name / 'report.json'))

archive = OUT.with_suffix('.zip')
members = [W / 'build.py', Path(__file__), W / 'plan.json']
members += list((W / 'compile').glob('*/*.json'))
members += [p for parent in ['compile', 'link', 'runs'] for p in (W / parent).rglob('*')
            if p.is_file() and p.suffix in ('.log', '.json')]
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(set(members)):
        assert p.name != 'environment.json'
        z.write(p, p.relative_to(W).as_posix())

source_paths = [R / p for p in (
    'engine/inference/program_carrier.h', 'engine/inference/program_slots.h', 'engine/models/qwen35/main.cc',
    'tests/tools/inference_program_carrier_case.h')]
result = dict(schema='hyle.correctness.program-identity.v1', date='2026-10-29',
    status='PASS_SIX_FINITE_CURRENT_CONSUMER_CASES',
    change='Remove duplicated model Exact/index/binding installation facts. The original ProgramCarrier checks actual Invocation identity against its already selected concrete executable, including all canonical bindings. ProgramSlots constructs installation facts only for a new valid original Invocation; warm, out-of-range, closing and teardown calls do not evaluate the static recipe.',
    counts=dict(successful_consumer_CXX=2, failed_environment_CXX_attempts=0, links=2,
                retained_SDK_inputs=227, SDK_CXX=0, NVCC=0, native_cases=6, downloads=0,
                standalone_complete_state_byte_checks=7, ordinary_pipeline_arms=16),
    build=builds, sources=[identity(p) for p in source_paths], cases=reports,
    identity_scope='The original CompiledGraph remains the execution authority. Signature comparison does not become a provider/weight cache key. Static Graphs retain no family index; exact family rejection remains in original cold preparation.',
    coverage_boundaries=[
        'Windows MSVC 14.50, RTX 4070 driver 617.14; current consumers linked to 227 retained SDK objects/libraries. No SDK/NVCC rebuild.',
        'All six native processes were run once and passed; original result assertions were retained. No weaker tolerance or regenerated trained weights.',
        'Standalone AddGraph is a second physical-slot consumer, not a second complete inference model family.',
        'The ordinary fixture copies only weights.tsv and prompt.ids to this batch folder; all original shared untrained payloads are reused. A separate 64KiB synthetic stop fixture is generated by the existing consumer.',
        'Apple/Vulkan, unknown native failures, full engine orchestration and new throughput/quality measurements were not checked in this batch.',
        'One/three physical slots and two candidate depths remain distinct. The group invents no queue, Completion, permission or state-publication mechanism.'],
    archive=identity(archive))
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PASS 6 finite cases; 7 standalone byte comparisons; 16 ordinary pipeline arms; archived', archive.stat().st_size, 'bytes')
