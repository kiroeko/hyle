"""R7 source/static/shared consumers, OFF then ON; never samples performance."""
from pathlib import Path
import argparse, ctypes, hashlib, json, os, platform, shutil, subprocess, sys, time, zipfile

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,required=True)
p.add_argument('--archive',type=Path,required=True)
p.add_argument('--sha256',required=True)
a=p.parse_args()
root=a.root.resolve()
root.mkdir(parents=True,exist_ok=False)
logs=root/'logs'; logs.mkdir()
windows=os.name=='nt'
apple=sys.platform=='darwin'
cuda=not apple
vulkan=windows or apple
commit='87ae583407cbb5ed13108c3837b020e6e343a3ca'
if windows: ctypes.windll.kernel32.SetErrorMode(0x8003)
env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='2',CTEST_PARALLEL_LEVEL='1',
         CTEST_INTERACTIVE_DEBUG_MODE='0',VK_LOADER_LAYERS_DISABLE='~implicit~')
if apple:
    env.update(PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH'],
               MACOSX_DEPLOYMENT_TARGET='14.4',DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib')
for key in ('CMAKE_TOOLCHAIN_FILE','CMAKE_PREFIX_PATH','CMAKE_GENERATOR_PLATFORM','CMAKE_GENERATOR_TOOLSET'):
    env.pop(key,None)
record={'candidate':commit,'archive_sha256':a.sha256,'state':'RUNNING','commands':[],
        'host':platform.uname()._asdict(),
        'validation_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':'real ordinary CPU plus platform routes (Windows CUDA/Vulkan, Air Apple/Vulkan, WSL CUDA); complete source and relocated static/shared SDK, trace OFF/ON',
        'executables':{},'compiler_inputs':{},'artifact_inventories':{}}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(): (logs/'identity.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(label,args,timeout=3600,allow_fail=False):
    print(label,flush=True)
    started=time.monotonic()
    with (logs/(label+'.log')).open('w',encoding='utf-8') as stream:
        result=subprocess.run([str(x) for x in args],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
    record['commands'].append({'label':label,'command':[str(x) for x in args],
        'exit_code':result.returncode,'seconds':time.monotonic()-started,'log_sha256':sha(logs/(label+'.log'))})
    save()
    if result.returncode and not allow_fail:
        print((logs/(label+'.log')).read_text(encoding='utf-8',errors='replace')[-6000:],flush=True)
        result.check_returncode()
    return result.returncode
def move(old,new):
    assert old.resolve().is_relative_to(root) and new.resolve().is_relative_to(root)
    assert old.exists() and not new.exists(),(old,new)
    old.rename(new)
def configure(label,source,build,static,trace):
    args=['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
          '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_POSITION_INDEPENDENT_CODE=ON',
          '-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_CPU=ON',
          '-DHYLE_COMPUTE_CUDA='+('ON' if cuda else 'OFF'),
          '-DHYLE_COMPUTE_APPLE='+('ON' if apple else 'OFF'),
          '-DHYLE_COMPUTE_VULKAN='+('ON' if vulkan else 'OFF'),
          '-DHYLE_COMPUTE_ONEDNN='+('ON' if windows else 'OFF'),
          '-DHYLE_STATIC='+('ON' if static else 'OFF'),'-DHYLE_TRACE='+trace,
          '-DHYLE_INSTALL=ON','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF',
          '-DHYLE_WERROR=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON']
    if vulkan:
        args+=['-DHYLE_VULKAN_GLSLANG='+('C:/public/tools/glslang/glslangValidator.exe' if windows else '/opt/homebrew/bin/glslangValidator')]
    if apple: args+=['-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4']
    run(label,args)
def exercise(label,build,names):
    if windows:
        dlls=[Path('C:/Windows/System32')/name for name in ('msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll','vulkan-1.dll')]
        dlls += [Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64')/name for name in ('cudart64_13.dll','cublasLt64_13.dll')]
        for dll in dlls: shutil.copyfile(dll,build/dll.name)
    run(label+'-test',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','--timeout','180'],600)
    shutil.copyfile(build/'Testing/Temporary/LastTest.log',logs/(label+'-LastTest.log'))
    for name in names:
        exe=build/(name+('.exe' if windows else ''))
        record['executables'][label+'/'+name]=sha(exe)
        run(label+'-'+name+'-linkage',['dumpbin','/dependents',exe] if windows else
            (['otool','-L',exe] if apple else ['ldd',exe]),120)
    save()

try:
    save()
    assert sha(a.archive)==a.sha256
    extracted=root/'source'
    with zipfile.ZipFile(a.archive) as z:
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
        z.extractall(extracted)
    tree=extracted/'hyle-0.1.0-source'
    assert commit in (tree/'SOURCE-MANIFEST.txt').read_text(encoding='utf-8')
    consumers=root/'independent-consumers'
    for product in ('compute','graph'):
        shutil.copytree(tree/'samples/package'/product/'cpp',consumers/product/'cpp')
    parent=root/'parent'; parent.mkdir()
    (parent/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(HyleR7Source LANGUAGES CXX)
add_subdirectory("'''+tree.as_posix()+'''" hyle)
enable_testing()
foreach(product IN ITEMS compute graph)
  add_executable(r7_source_${product} "'''+tree.as_posix()+'''/samples/package/${product}/cpp/main.cc")
  target_link_libraries(r7_source_${product} PRIVATE hyle::${product})
  hyle_stage_runtime_dependencies(r7_source_${product})
  if(COMMAND hyle_stage_apple_runtime)
    hyle_stage_apple_runtime(r7_source_${product})
  endif()
  add_test(NAME r7_source_${product} COMMAND r7_source_${product})
endforeach()
''',encoding='utf-8')
    source_build=root/'source-build'
    shared_build=root/'shared-build'
    for trace in ('OFF','ON'):
        key=trace.lower()
        configure(key+'-source-configure',parent,source_build,True,trace)
        run(key+'-source-build',['cmake','--build',source_build,'--parallel','2'])
        exercise(key+'-source',source_build,['r7_source_compute','r7_source_graph'])
        configure(key+'-shared-configure',tree,shared_build,False,trace)
        run(key+'-shared-build',['cmake','--build',shared_build,'--parallel','2'])
        prefixes={}
        for linkage,build in (('static',source_build),('shared',shared_build)):
            prefix=root/(key+'-'+linkage+'-sdk')
            run(key+'-'+linkage+'-install',['cmake','--install',build,'--prefix',prefix])
            relocated=root/(key+'-'+linkage+'-sdk-relocated'); move(prefix,relocated)
            prefixes[linkage]=relocated
            for name in ('CMakeCache.txt','compile_commands.json'):
                shutil.copyfile(build/name,logs/(key+'-'+linkage+'-'+name))
            commands=json.loads((build/'compile_commands.json').read_text(encoding='utf-8'))
            trace_owners=('compute','graph','compute_route_apple','graph_route_apple',
                          'compute_route_vulkan','graph_route_vulkan')
            own=[x for x in commands if any('/src/'+owner+'/' in x['file'].replace('\\','/')
                                           for owner in trace_owners)]
            assert own
            assert all(('HYLE_TRACE_TRACY' in x['command']) == (trace=='ON') for x in own)
            record['compiler_inputs'][key+'-'+linkage]={'source_units':len(own),'compile_commands_sha256':sha(build/'compile_commands.json')}
            artifacts=[p.relative_to(relocated).as_posix() for p in relocated.rglob('*') if p.suffix.lower() in ('.dll','.lib','.a','.so','.dylib')]
            tracer=[n for n in artifacts if 'tracy_client' in n.lower()]
            assert bool(tracer)==(trace=='ON'),tracer
            if trace=='ON':
                if linkage=='static': assert len(tracer)==1,tracer
                else: assert len({(relocated/n).resolve() for n in tracer
                                  if n.endswith(('.dll','.dylib','.so'))})==1,tracer
            record['artifact_inventories'][key+'-'+linkage]={'artifacts':artifacts,'tracy':tracer}
            assert (relocated/'include/hyle/graph/compile_report.h').is_file()
            assert (relocated/'include/hyle/graph/vulkan.h').is_file() == vulkan
            assert (relocated/'include/hyle/graph/apple.h').is_file() == apple
        for build in (source_build,shared_build): move(build,build.with_name(build.name+'-hidden'))
        move(extracted,extracted.with_name(extracted.name+'-hidden'))
        record[key+'_producers_hidden']=True; save()
        for linkage,prefix in prefixes.items():
            for product in ('compute','graph'):
                label=key+'-'+linkage+'-'+product
                build=root/('consumer-'+label)
                args=['cmake','-S',consumers/product/'cpp','-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
                      '-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF',
                      '-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON']
                if apple: args+=['-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4']
                run(label+'-configure',args)
                run(label+'-build',['cmake','--build',build,'--parallel','2'])
                exercise(label,build,['hyle_package_'+product+'_cpp'])
        # Restore validation producers only to reuse unchanged vendor artifacts
        # for the ON configuration. All receipts above retain OFF input hashes.
        move(extracted.with_name(extracted.name+'-hidden'),extracted)
        for build in (source_build,shared_build): move(build.with_name(build.name+'-hidden'),build)
    record['state']='PASS'
except Exception as error:
    record.update(state='FAIL',error=str(error)); raise
finally:
    record['finished']=time.time(); save()
