"""Build retained fixtures and run numeric oracles only; no timing or A/A."""
from pathlib import Path
import argparse,ctypes,hashlib,json,os,platform,shutil,subprocess,time

p=argparse.ArgumentParser();p.add_argument('--delivery-root',type=Path,required=True)
p.add_argument('--peer',type=Path,required=True);a=p.parse_args()
root=a.delivery_root.resolve(); source=root/'source/hyle-0.1.0-source'
build=root/'shared-build'; logs=root/'fixture-checks';logs.mkdir(exist_ok=False)
windows=os.name=='nt'
if windows: ctypes.windll.kernel32.SetErrorMode(0x8003)
delivery=json.loads((root/'logs/identity.json').read_text())
assert delivery['state']=='PASS', 'finish delivery before reconfiguring its validation build'
env={k:v for k,v in os.environ.items() if not k.startswith(('HYLE_PERF_','HYLE_BENCH_'))}
env.update(CMAKE_BUILD_PARALLEL_LEVEL='2',CTEST_PARALLEL_LEVEL='1',HYLE_BENCH_VERIFY_ONLY='1',
           VK_LOADER_LAYERS_DISABLE='~implicit~')
if not windows:
 env.update(PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH'],
            MACOSX_DEPLOYMENT_TARGET='14.4',DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib')
record={'candidate':delivery['candidate'],'archive_sha256':delivery['archive_sha256'],
        'verdict':'RUNNING','commands':[],'performance_samples':0,
        'host':platform.uname()._asdict(),
        'validation_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':'retained primary/placement fixtures compile; primary independent numeric oracles only; retired entry negative checks; no P1 or new ranking'}
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(): (logs/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,cmd,timeout=3600):
 print(label,flush=True);log=logs/(label+'.log');start=time.monotonic()
 with log.open('w') as out:
  r=subprocess.run([str(x) for x in cmd],cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
 record['commands'].append({'label':label,'argv':[str(x) for x in cmd],'exit_code':r.returncode,
                            'seconds':time.monotonic()-start,'log_sha256':sha(log)});save()
 if r.returncode: print(log.read_text(errors='replace')[-8000:],flush=True)
 r.check_returncode()
 return log
try:
 save()
 peers=[('ggml',a.peer,'456172ec733a135778adcd32d00e576a58232e45')]
 if windows:peers.append(('marl',Path('C:/public/project-hyle/marl'),'b8406ab0a82524170ead6dd6c371b579bbc28b3e'))
 record['peers']={}
 for name,path,pin in peers:
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()
  dirty=subprocess.check_output(['git','status','--porcelain'],cwd=path,text=True).strip()
  assert head==pin and not dirty,(name,head,dirty)
  record['peers'][name]={'path':str(path),'commit':head,'dirty':False}
 save()
 owners=['compute_route_vulkan','graph_route_vulkan']
 if windows: owners+=['graph_route_cpu','compute_route_cuda','graph_route_cuda','sched']
 else: owners+=['compute_route_apple','graph_route_apple']
 config=['cmake','-S',source,'-B',build,'-DHYLE_COMPONENTS=',
         '-DHYLE_DEV_FACTORS='+','.join(owners),'-DHYLE_STATIC=ON','-DHYLE_TRACE=OFF',
         '-DHYLE_INSTALL=OFF','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=ON',
         '-DHYLE_BENCH_MARL='+('ON' if windows else 'OFF'),
         '-DHYLE_VULKAN_REFERENCE_SOURCE_DIR='+str(a.peer)]
 if windows:config+=['-DHYLE_MARL_DIR=C:/public/project-hyle/marl']
 run('configure',config)
 targets=['hyle_compute_route_vulkan_bench','hyle_graph_route_vulkan_bench']
 if windows: targets+=['hyle_graph_onednn_region_bench','hyle_compute_route_cuda_bench','hyle_graph_route_cuda_bench']
 else: targets+=['hyle_compute_route_apple_bench','hyle_graph_route_apple_bench']
 compile_targets=targets+[n+'_placement' for n in targets]
 if windows: compile_targets+=['hyle_sched_p1_candidate_bench','hyle_sched_p1_peer_bench']
 run('build',['cmake','--build',build,'--parallel','2','--target',*compile_targets])
 listed=run('target-inventory',['ninja','-C',build,'-t','targets','all']).read_text()
 removed=['hyle_'+scope+'_'+route+'_native_cost_bench' for scope in ('compute','graph') for route in ('cuda','apple','vulkan')]
 assert not any(n in listed for n in removed)
 # Frozen historical contracts keep their bytes; active code no longer emits these rows.
 for path,needles in [('bench/sched/p1_candidate_bench.cc',['structured-spawn-join']),
                      ('bench/sched/p1_peer_bench.cc',['structured-spawn-join']),
                      ('bench/graph_route_cpu/region_p1_bench.cc',['DirectFused','DirectSequential'])]:
  contents=(source/path).read_text();assert not any(n in contents for n in needles),(path,needles)
 record['retired_target_negative_check']='PASS'
 if windows:
  dlls=[Path('C:/Windows/System32')/n for n in ('msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll','vulkan-1.dll')]
  dlls += [Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64')/n for n in ('cudart64_13.dll','cublasLt64_13.dll')]
  for dll in dlls:shutil.copyfile(dll,build/'bin'/dll.name)
 record['artifacts']={n:sha(build/'bin'/(n+('.exe' if windows else ''))) for n in compile_targets}
 for target in targets:
  log=run(target+'-oracle',[build/'bin'/(target+('.exe' if windows else ''))],600)
  output=log.read_text();assert 'ns/op' not in output and 'ms/op' not in output
 record['verdict']='PASS'
except Exception as error:
 record.update(verdict='BLOCKED',error=str(error));raise
finally:
 save()
