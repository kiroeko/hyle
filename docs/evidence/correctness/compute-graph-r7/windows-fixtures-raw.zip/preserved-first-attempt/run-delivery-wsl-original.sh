#!/usr/bin/env bash
set -euo pipefail
export CC=/usr/bin/gcc-14
export CXX=/usr/bin/g++-14
export CUDACXX=/usr/local/cuda-13.3/bin/nvcc
export PATH=/usr/local/cuda-13.3/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda-13.3/lib64:/usr/lib/wsl/lib${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}
export PYTHONUTF8=1
python3 /mnt/c/h7/r7-delivery.py \
  --root /root/hyle-validation/r7-87ae5834 \
  --archive /mnt/c/h7/dist/87ae5834/hyle-0.1.0-source.zip \
  --sha256 4e542af0692906a37fb8bf9048771e06dfe4e578051eb2261057d01f0b0220db
