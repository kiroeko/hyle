$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:PYTHONUTF8 = '1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:/public/project-hyle/.deps'
$env:PATH = 'C:/public/tools/glslang;' + $env:PATH
$receiptPath = 'C:/h7/remaining-serial-02.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Inspect the existing serial receipt before any continuation.' }
$script:serialReceipt = [ordered]@{
    candidate = '87ae583407cbb5ed13108c3837b020e6e343a3ca'
    verdict = 'RUNNING'
    phase = 'resume-air-fixture-after-build-seam-correction'
    previous_receipt = 'C:/h7/remaining-serial.json'
    steps = @()
}
function Save-Receipt {
    [IO.File]::WriteAllText($receiptPath, ($script:serialReceipt | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
}
function Invoke-Phase {
    param([string]$Phase, [string]$Executable, [string[]]$CommandArguments)
    $script:serialReceipt.phase = $Phase
    Save-Receipt
    Write-Output "R7 PHASE $Phase"
    $started = [DateTime]::UtcNow
    & $Executable @CommandArguments
    $phaseExit = $LASTEXITCODE
    $script:serialReceipt.steps += [ordered]@{
        phase = $Phase
        executable = $Executable
        arguments = $CommandArguments
        started_utc = $started.ToString('o')
        finished_utc = [DateTime]::UtcNow.ToString('o')
        exit_code = $phaseExit
    }
    Save-Receipt
    if ($phaseExit -ne 0) { throw "$Phase stopped with exit code $phaseExit" }
}
try {
    Save-Receipt
    $previous = Get-Content -LiteralPath 'C:/h7/remaining-serial.json' -Raw | ConvertFrom-Json
    if ($previous.verdict -ne 'STOPPED_ON_FAILURE' -or $previous.phase -ne 'air-retained-fixture-oracles') {
        throw 'Inspect the prior run before continuing.'
    }
    foreach ($completed in @('archive-windows-coverage','air-host-asan-ubsan','air-off-on-three-delivery')) {
        $matches = @($previous.steps | Where-Object { $_.phase -eq $completed -and $_.exit_code -eq 0 })
        if ($matches.Count -ne 1) { throw "Prior completed phase lacks a successful receipt: $completed" }
    }
    Invoke-Phase 'air-retained-fixture-oracles' 'ssh' @('-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198',
        'python3 /Users/kiro/hyle-verify/r7-e84a7ad3/dist-87ae5834/r7-fixture-checks.py --delivery-root /Users/kiro/hyle-verify/r7-e84a7ad3/delivery --peer /Users/kiro/hyle-verify/r6-vulkan-20260917/peer-ggml-456172ec')
    Invoke-Phase 'windows-off-on-three-delivery' 'python' @('C:/h7/r7-delivery.py','--root','C:/h7/dw7','--archive',
        'C:/h7/dist/87ae5834/hyle-0.1.0-source.zip','--sha256','4e542af0692906a37fb8bf9048771e06dfe4e578051eb2261057d01f0b0220db')
    Invoke-Phase 'windows-retained-fixture-oracles' 'python' @('C:/h7/r7-fixture-checks.py','--delivery-root','C:/h7/dw7',
        '--peer','C:/public/project-hyle/ggml')
    Invoke-Phase 'wsl-off-on-three-delivery' 'wsl' @('-d','Ubuntu-24.04','--','bash','/mnt/c/h7/run-delivery-wsl.sh')
    $script:serialReceipt.verdict = 'PASS'
} catch {
    $script:serialReceipt.verdict = 'STOPPED_ON_FAILURE'
    $script:serialReceipt.error = $_.Exception.Message
    throw
} finally {
    $script:serialReceipt.finished_utc = [DateTime]::UtcNow.ToString('o')
    Save-Receipt
}
