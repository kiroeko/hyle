$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:PYTHONUTF8 = '1'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:/public/project-hyle/.deps'
$env:PATH = 'C:/public/tools/glslang;' + $env:PATH
$receiptPath = 'C:/h7/remaining-serial-04.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Inspect existing receipt before continuing.' }
$script:serialReceipt = [ordered]@{
    candidate = '87ae583407cbb5ed13108c3837b020e6e343a3ca'
    verdict = 'RUNNING'
    phase = 'verify-completed-deliveries'
    previous_receipt = 'C:/h7/remaining-serial-03.json'
    windows_delivery = 'C:/h7/dw7/logs-complete/identity.json'
    steps = @()
}
function Save-Receipt {
    [IO.File]::WriteAllText($receiptPath, ($script:serialReceipt | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
}
function Invoke-Phase {
    param([string]$Phase, [string]$Executable, [string[]]$CommandArguments)
    $script:serialReceipt.phase = $Phase
    Save-Receipt
    Write-Output "R7 PHASE $Phase"
    $started = [DateTime]::UtcNow
    & $Executable @CommandArguments
    $phaseExit = $LASTEXITCODE
    $script:serialReceipt.steps += [ordered]@{
        phase = $Phase
        executable = $Executable
        arguments = $CommandArguments
        started_utc = $started.ToString('o')
        finished_utc = [DateTime]::UtcNow.ToString('o')
        exit_code = $phaseExit
    }
    Save-Receipt
    if ($phaseExit -ne 0) { throw "$Phase stopped with exit code $phaseExit" }
}
try {
    $previous = Get-Content -LiteralPath 'C:/h7/remaining-serial-03.json' -Raw | ConvertFrom-Json
    if ($previous.verdict -ne 'STOPPED_ON_FAILURE' -or $previous.phase -ne 'windows-retained-fixture-oracles') {
        throw 'Unexpected previous serial state.'
    }
    $delivery = Get-Content -LiteralPath $script:serialReceipt.windows_delivery -Raw | ConvertFrom-Json
    if ($delivery.state -ne 'PASS' -or $delivery.commands.Count -ne 50) {
        throw 'Windows continuation must finish successfully first.'
    }
    $script:serialReceipt.windows_delivery_sha256 = (Get-FileHash -LiteralPath $script:serialReceipt.windows_delivery -Algorithm SHA256).Hash.ToLowerInvariant()
    Save-Receipt
    Invoke-Phase 'windows-retained-fixture-oracles' 'python' @('C:/h7/r7-fixture-checks.py',
        '--delivery-root','C:/h7/dw7','--delivery-receipt','C:/h7/dw7/logs-complete/identity.json',
        '--peer','C:/public/project-hyle/ggml','--resume-failed-configure')
    # The Windows cache environment path must not be inherited as a Linux path.
    Remove-Item Env:HYLE_DEP_SOURCE_CACHE
    Invoke-Phase 'wsl-off-on-three-delivery' 'wsl' @('-d','Ubuntu-24.04','--','bash','/mnt/c/h7/run-delivery-wsl.sh')
    $script:serialReceipt.verdict = 'PASS'
} catch {
    $script:serialReceipt.verdict = 'STOPPED_ON_FAILURE'
    $script:serialReceipt.error = $_.Exception.Message
    throw
} finally {
    $script:serialReceipt.finished_utc = [DateTime]::UtcNow.ToString('o')
    Save-Receipt
}
