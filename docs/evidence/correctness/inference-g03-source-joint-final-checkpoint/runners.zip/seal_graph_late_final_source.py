from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root=Path.cwd()
task=root/'.scratch/inference-gaps/g03'
out=root/'evidence/correctness/inference-g03-source-joint-final-checkpoint'
assert not out.exists(), 'Do not overwrite a sealed checkpoint'
cuda=json.loads((task/'graph-late-cuda/result.json').read_bytes())
cl={r['stage']:r for r in cuda['stages']}
assert json.loads((task/'graph-late-cuda/job.json').read_bytes())['state']=='TERMINAL'
for stage in ['full-joint-risk-compile','full-joint-risks','full-joint-compile','full-joint64','graph-risk-compile','graph-risks']:
    assert cl[stage]['exit_code']==0,stage
for stage in ['full-joint-risks','graph-risks']:
    text=(task/'graph-late-cuda'/Path(cl[stage]['log']).name).read_text(encoding='utf-8')
    assert text.count('PASS')==8,(stage,text)
text=(task/'graph-late-cuda'/Path(cl['full-joint64']['log']).name).read_text(encoding='utf-8')
assert text.count('common CPU+CUDA Graph pending PASS:64')==2
receipts=json.loads((task/'graph-late-cuda/source-full-factor-receipts.json').read_bytes())
assert len(receipts['consumer_commands'])==2 and len(receipts['artifacts'])==8
windows=json.loads((task/'graph-late-windows/result.json').read_bytes())
wl={r['stage']:r for r in windows['stages']}
assert json.loads((task/'graph-late-windows/job.json').read_bytes())['state']=='TERMINAL'
assert wl['changed-native-fixture-compile']['exit_code']==0
for item in cuda['inputs']:
    if item['path'].startswith(('include/','src/','tests/')):
        assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
for item in wl['changed-native-fixture-compile']['inputs']:
    assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
out.mkdir()
changed=[n for n in subprocess.check_output(['git','diff','--name-only','2bc71f56a'],text=True).splitlines() if n.startswith(('include/','src/','tests/'))]
for name in ['graph-late-cuda','graph-late-windows']:
    folder=task/name
    with zipfile.ZipFile(out/(name+'-raw.zip'),'w',zipfile.ZIP_DEFLATED) as package:
        for p in folder.iterdir():
            if p.suffix in ['.json','.log','.py']:package.write(p,p.name)
        archives=sorted(folder.glob('source-*.zip'),key=lambda p:int(p.stem.split('-')[-1]))
        if archives:
            with zipfile.ZipFile(archives[-1]) as snapshot:
                paths=set(snapshot.namelist())
                for path in changed:
                    if path in paths:package.writestr('last-canonical-input/'+path,snapshot.read(path))
with zipfile.ZipFile(out/'runners.zip','w',zipfile.ZIP_DEFLATED) as package:
    for name in ['graph_late_cuda.py','run_graph_late_cuda.py','graph_late_windows.py','seal_graph_late_final_source.py']:
        package.write(task/name,name)
result=dict(kind='FINAL_GL_SOURCE_QUALIFICATION_CHECKPOINT',state='AUDITED',whole_g03_completed=False,
    verified=[
        'Original complete CPU+CUDA source dependency closure built. Public hyle::graph source target links the original full factor, no explicit compiler TU/frozen archive; F16/BF16 64-step dual-request/dual-slot independent oracle passes.',
        'Required CPU Neg/Cast -> actual CUDA paged attention -> CPU Cast/Neg eight original source lifecycle cases pass: numeric/old result/recovery, known error, unknown, late error, owner abandonment, CPU foreign-queue refusal, two original Unimplemented native cancel boundaries.',
        'Pure CUDA eight-case pending lifecycle regression on final fixture passes with no new kernel compilation.',
        'Changed native result/joint default fixtures compile and link under MSVC; Windows GPU runtime is not claimed.'
    ],
    red_team=dict(owner='independent user-authorized single_machine_completeness_audit agent',verdict='No new product defect or G03 MUST found. Prior independent-source and true-joint lifecycle evidence gaps resolved. Product change may stop and freeze after final finite ordinary checks.',synchronous_abandon='Joint GPU-to-CPU checked host wait is allowed by original replay and controls require external serialization. Test verifies live producer guards at actual native synchronize checkpoint, then drops returned result/owner after submit. Pure CUDA separately proves pending abandon; no fully async joint claim.'),
    failures='First joint runtime was terminated with -15 after 94.718s: fixture released Gate after submit, while original CPU boundary waits inside submit. Original backtrace, failed log/input, full dependency build and cumulative preserved. Fixture release checkpoint corrected; product unchanged. First artifact receipt rejected an overly broad /root/ object-path assumption; actual direct-TU/frozen archive exclusion checked instead.',
    remaining=['Immutable candidate/state and final scoped seven gates, not another product implementation batch','Original G01/G02 unresolved whole-item gates and G04-G10 remain'],
    limitations=['Native CUDA cancellation remains Unimplemented; refused cancel does not preempt or retire accepted work. Update cancel also closes its slot.',
        'CPU+CUDA source checked host wait is an explicit normal route cost, not zero-host-wait submit. Binding metadata allocations, native cold table waits, four native shape slots, explicit orthogonal host staging/private UNKNOWN retained.',
        'Host sanitizer instrumentation/models are proven in prior checkpoint; source CUDA hooks do not certify device/shader/driver sanitizers. Installed shipping profiles without HYLE_TESTING are separately proven.'],
    cumulative_seconds=dict(cuda_source=cuda['cumulative_seconds'],windows=windows['cumulative_seconds']),
    current_product_inputs=[dict(path=p,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in changed if p.startswith(('include/','src/'))])
(out/'validation-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result['cumulative_seconds']))
