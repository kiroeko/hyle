# Graph batch shared 导出修复的外部 consumer

root 的产品改动仅为 `include/hyle/graph/batch.h:68,88,108` 三个首次 free-function friend 声明补同一个 `HYLE_GRAPH_BATCH_API`，与随后`:72,91,111`的公开声明一致。`visibility.h:227–230`在本模块BUILD分支导出、consumer分支导入；static时宏为空。已有同类惯例为`graph/detail/region_access.h:400`及`io/http.h:228–236`的`friend HYLE_*_API`。该header另外的friend只有detail struct/class，不是相同错位函数声明；无需导出整个类、改数学／布局／owner，`row_cache_node.cc`定义继承头中声明。

旧normal attempt1真实C2375保留在原build日志。修复头22067B、SHA `3fd0558682b4994aad5ced4f9a069c6d899c944b6ae376fc89ae2ac34142fc1d`。

本目录`consumer.cc`仅把三个函数地址存入volatile全局、main实际读并核非空；无Graph构建／执行或模型工作。按root授权只执行唯一一次`cl`：`compile/attempt1/result.json`为exit0，1.11s，object 7645B、SHA `a999782888f09190f6f9ae5e3f3f8749ba4cd8d8b9319f3cad0475e26a566076`。沿正常CMake宏／Release／MSVC／MD，**无HYLE_STATIC、HYLE_GRAPH_BATCH_BUILD**；actual dependencies含本次真实头。command、日志、源码与sourceDependencies完整保留，没有失败重试。

正常attempt2已真实TERMINAL exit0（59.688s），随后按root授权唯一1link、1run及exports/imports两次dumpbin均exit0；`summary.json`为`PASS_EXTERNAL_SHARED_IMPORT_LINK_RUN_THREE_EXPORTS_THREE_IMPORTS`。三个精确decorated导出／实际PE导入分别各一条，main读取三volatile地址返回0。成功normal GraphBatch DLL／importlib、原fixture对象、build/image及环境在`completion-inputs.json`实际封pin，执行后仍exact。

累计本fixture为CXX1／link1／run1／dumpbin2，无自动重试。链接仅用正常`hyle_graph_batch.lib`及普通Windows系统库；输出与TMP/TEMP都在本目录，正常bin是首PATH且run工作目录为正常bin，无SDK DLL复制或原产物覆盖。未采样实际loaded模块路径，不把PE导入＋正常加载环境说成完整loader事件证据；此范围不涉及Graph数值、GPU模型或性能。原首轮产品build失败仍在原目录，未因后续成功覆盖。
