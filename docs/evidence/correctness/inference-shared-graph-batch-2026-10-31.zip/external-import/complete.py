"""Explicit one link/run + exports/imports, only after normal attempt2 PASS."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parent.parent
NORMAL=R/'.scratch/inference-default-product-build-20261031'
BUILD=R/'.scratch/build-compute-v2-dev'
spec=importlib.util.spec_from_file_location('row_cache_import_prepared',W/'prepare.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
n=p.n
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def exact(row):assert n.identity(Path(row['path']))==row,'Changed input: '+row['path']
def ready():
    process=read(NORMAL/'build/attempt2/process.json')
    assert process['state']=='TERMINAL' and process['exit_code']==0,'Normal attempt2 not terminal PASS; stop downstream'
    built=read(NORMAL/'build/attempt2/result.json')
    assert built['state']=='TERMINAL' and built['exit_code']==0
    exact(built['image'])
    return built
def execute(name,command,env,cwd):
    ready()
    folder=W/name/'attempt1';folder.mkdir(parents=True,exist_ok=False)
    n.save(folder/'command.json',dict(command=command,cwd=str(cwd)))
    start=n.now();tick=time.monotonic()
    with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
        child=subprocess.Popen(command,cwd=cwd,env=env,stdout=out,stderr=err)
        n.save(folder/'process.json',dict(state='RUNNING',pid=child.pid,start_utc=start))
        code=child.wait()
    result=dict(state='TERMINAL',pid=child.pid,start_utc=start,end_utc=n.now(),exit_code=code,
                elapsed_seconds=time.monotonic()-tick)
    n.save(folder/'process.json',result)
    print(json.dumps(dict(stage=name,**result)),flush=True)
    if code:raise SystemExit(code)
    return folder,result
def main():
    built=ready();plan=read(W/'plan.json');compiled=read(W/'compile/attempt1/result.json')
    assert compiled['state']=='TERMINAL' and compiled['exit_code']==0
    for key in ('object','dependencies','source','header'):exact(compiled[key])
    for key in ('source','header','environment','compiler'):exact(plan[key])
    dll=BUILD/'bin/hyle_graph_batch.dll';lib=BUILD/'bin/hyle_graph_batch.lib'
    inputs=dict(normal_build=n.identity(NORMAL/'build/attempt2/result.json'),
        normal_image=built['image'],batch_DLL=n.identity(dll),batch_importlib=n.identity(lib),
        consumer_object=compiled['object'],consumer_source=compiled['source'],public_header=compiled['header'],
        environment=plan['environment'],compile_receipt=n.identity(W/'compile/attempt1/result.json'),
        completion_script=n.identity(Path(__file__)))
    assert not (W/'completion-inputs.json').exists(),'Preserve every prior attempt; no automatic retry'
    n.save(W/'completion-inputs.json',inputs)
    env=dict(os.environ);env.update(read(NORMAL/'environment.json'))
    for key in ('CL','_CL_','CFLAGS','CXXFLAGS','LDFLAGS','CUDAFLAGS','CUDAARCHS','CUDACXX','CXX','CC','TORCH_INSTALL_PREFIX','CMAKE_PREFIX_PATH'):
        env.pop(key,None)
    env['PATH']=str(BUILD/'bin')+';'+env['PATH']
    temp=(W/'temp/attempt1').resolve();assert temp.is_relative_to(W.resolve());temp.mkdir(parents=True,exist_ok=False)
    env['TMP']=env['TEMP']=str(temp)
    image=Path(plan['run_command_prepared_only'][0]);image.parent.mkdir(parents=True,exist_ok=True)
    assert not image.exists(),'Do not overwrite an existing image'
    assert not any(image.parent.glob('*.dll')),'No private SDK DLL copy is allowed'
    linkfolder,link=execute('link',plan['link_command_prepared_only'],env,BUILD)
    exports_folder,exports=execute('exports',plan['dump_exports_prepared_only'],env,BUILD)
    imports_folder,imports=execute('imports',plan['dump_imports_prepared_only'],env,BUILD)
    export_text=(exports_folder/'stdout.log').read_text(errors='replace')
    import_text=(imports_folder/'stdout.log').read_text(errors='replace')
    export_lines={s:[line.strip() for line in export_text.splitlines() if s in line] for s in plan['symbols']}
    import_lines={s:[line.strip() for line in import_text.splitlines() if s in line] for s in plan['symbols']}
    assert all(len(lines)==1 for lines in export_lines.values()),export_lines
    assert all(len(lines)==1 for lines in import_lines.values()),import_lines
    assert 'hyle_graph_batch.dll' in import_text.lower()
    # The executable directory contains no DLL copies; normal shared bin is
    # both current directory and first PATH entry. Main only reads 3 addresses.
    runfolder,run=execute('run',plan['run_command_prepared_only'],env,BUILD/'bin')
    for key in ('normal_build','normal_image','batch_DLL','batch_importlib','consumer_object','consumer_source','public_header','environment','compile_receipt','completion_script'):
        exact(inputs[key])
    value=dict(status='PASS_EXTERNAL_SHARED_IMPORT_LINK_RUN_THREE_EXPORTS_THREE_IMPORTS',
        inputs=inputs,image=n.identity(image),link=link,exports=exports,imports=imports,run=run,
        three_export_lines=export_lines,three_import_lines=import_lines,
        normal_batch_import_observed_in_PE=True,
        scope='Three volatile function addresses/IAT loads, no Graph work, GPU model or numerical claim. Loaded-module path sampling was not performed.',
        runtime='No DLL in executable directory; normal bin is cwd and first PATH. Same current normal environment; no SDK copy.',
        total_this_fixture=dict(CXX=1,link=1,run=1,dumpbin=2,automatic_retries=0))
    n.save(W/'summary.json',value)
    print(json.dumps(dict(status=value['status'],exports=3,imports=3,run_exit=run['exit_code'],CXX_total=1,SDK_copies=0)),flush=True)
if __name__=='__main__':main()
