"""Prepare commands only, then explicitly compile exactly once if requested."""
from pathlib import Path
import ctypes
from ctypes import wintypes
import importlib.util
import json
import os
import subprocess
import sys
import time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parent.parent
NORMAL=R/'.scratch/inference-default-product-build-20261031'
BUILD=R/'.scratch/build-compute-v2-dev'
spec=importlib.util.spec_from_file_location('current_normal_build_helpers',NORMAL/'build.py')
n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def exact(p):assert n.identity(Path(p['path']))==p,p['path']
def split(text):
    lib=ctypes.WinDLL('shell32',use_last_error=True)
    lib.CommandLineToArgvW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(ctypes.c_int)]
    lib.CommandLineToArgvW.restype=ctypes.POINTER(wintypes.LPWSTR)
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.LocalFree.argtypes=[ctypes.c_void_p];k.LocalFree.restype=ctypes.c_void_p
    count=ctypes.c_int();a=lib.CommandLineToArgvW('zero '+text,ctypes.byref(count))
    if not a:raise ctypes.WinError(ctypes.get_last_error())
    try:return [a[i] for i in range(1,count.value)]
    finally:k.LocalFree(a)
def prepare():
    original=read(R/'.scratch/inference-default-profile-20261031/source-link-mapping.json')
    cv=dict(x.strip().split(' = ',1) for x in original['original_compile_edge'][1:] if ' = ' in x)
    configured=read(NORMAL/'prepared.json')['configure']
    compiler=next(x.split('=',1)[1] for x in configured if x.startswith('-DCMAKE_CXX_COMPILER:FILEPATH='))
    linker=str(Path(compiler).with_name('link.exe'));dumpbin=str(Path(compiler).with_name('dumpbin.exe'))
    folder=W/'compile/attempt1';obj=folder/'consumer.obj';image=W/'bin/import-consumer.exe'
    flags=split(cv['FLAGS']);defines=split(cv['DEFINES'])
    assert all('HYLE_STATIC' not in d and 'HYLE_GRAPH_BATCH_BUILD' not in d for d in defines)
    command=[compiler,'/nologo','/TP',*defines,*split(cv['INCLUDES']),*flags,
             '/showIncludes','/sourceDependencies',str(folder/'dependencies.json'),
             '/Fo'+str(obj),'/Fd'+str(folder/'consumer.pdb'),'/FS','-c',str(W/'consumer.cc')]
    link=[linker,'/nologo','/machine:x64','/subsystem:console','/INCREMENTAL:NO',
          '/out:'+str(image),'/pdb:'+str(W/'bin/import-consumer.pdb'),str(obj),
          str(BUILD/'bin/hyle_graph_batch.lib'),'kernel32.lib','user32.lib','gdi32.lib',
          'winspool.lib','shell32.lib','ole32.lib','oleaut32.lib','uuid.lib','comdlg32.lib','advapi32.lib']
    plan=dict(status='PREPARED_EXTERNAL_SHARED_IMPORT_ONLY',source=n.identity(W/'consumer.cc'),
        header=n.identity(R/'include/hyle/graph/batch.h'),script=n.identity(Path(__file__)),
        environment=n.identity(NORMAL/'environment.json'),compiler=n.identity(Path(compiler)),
        original_ninja=n.identity(BUILD/'build.ninja'),compile_command=command,
        compile_cwd=str(BUILD),object=str(obj),link_command_prepared_only=link,
        run_command_prepared_only=[str(image)],
        dump_exports_prepared_only=[dumpbin,'/EXPORTS',str(BUILD/'bin/hyle_graph_batch.dll')],
        dump_imports_prepared_only=[dumpbin,'/IMPORTS',str(image)],
        runtime='After normal attempt2 is terminal PASS, use its validated runtime environment and normal bin first in PATH. No DLL copy.',
        symbols=['?add_row_cache_gather@','?add_row_cache_gather_padded@','?add_row_cache_indexer@'],
        native_budget=dict(compile=1,link=0,run=0,dumpbin=0),
        limitation='No DLL/importlib pin or link/run PASS before actual normal build readiness.')
    assert not (W/'plan.json').exists(),'Preserve prior preparation'
    n.save(W/'plan.json',plan)
    print(json.dumps(dict(status=plan['status'],header=plan['header'],source=plan['source'])))
def compile_once():
    plan=read(W/'plan.json')
    for key in ('source','header','script','environment','compiler','original_ninja'):exact(plan[key])
    folder=W/'compile/attempt1';folder.mkdir(parents=True,exist_ok=False)
    n.save(folder/'command.json',dict(command=plan['compile_command'],cwd=plan['compile_cwd']))
    env=dict(os.environ);env.update(read(NORMAL/'environment.json'))
    for key in ('CL','_CL_','CFLAGS','CXXFLAGS','LDFLAGS','CUDAFLAGS','CUDAARCHS','CUDACXX','CXX','CC','TORCH_INSTALL_PREFIX','CMAKE_PREFIX_PATH'):
        env.pop(key,None)
    tick=time.monotonic();start=n.now()
    with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
        child=subprocess.Popen(plan['compile_command'],cwd=BUILD,env=env,stdout=out,stderr=err)
        n.save(folder/'process.json',dict(pid=child.pid,state='RUNNING',start_utc=start))
        print(json.dumps(dict(pid=child.pid,state='RUNNING')),flush=True)
        code=child.wait()
    result=dict(state='TERMINAL',pid=child.pid,start_utc=start,end_utc=n.now(),exit_code=code,
                elapsed_seconds=time.monotonic()-tick,source=plan['source'],header=plan['header'])
    if code==0:result.update(object=n.identity(Path(plan['object'])),dependencies=n.identity(folder/'dependencies.json'))
    n.save(folder/'process.json',result);n.save(folder/'result.json',result)
    print(json.dumps(result),flush=True)
    raise SystemExit(code)
if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='compile':compile_once()
    else:raise ValueError(sys.argv[1])
