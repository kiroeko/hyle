#include "hyle/graph/batch.h"

#if defined(HYLE_STATIC) || defined(HYLE_GRAPH_BATCH_BUILD)
#error This fixture must compile as an external shared-import consumer.
#endif

namespace batch = hyle::graph::batch;
using Gather = decltype(&batch::add_row_cache_gather);
using GatherPadded = decltype(&batch::add_row_cache_gather_padded);
using Indexer = decltype(&batch::add_row_cache_indexer);

// Volatile globals and real loads keep all three imported addresses live.
// No Graph, Queue, allocation, GPU work or model inference is performed.
Gather volatile gather_import = &batch::add_row_cache_gather;
GatherPadded volatile gather_padded_import = &batch::add_row_cache_gather_padded;
Indexer volatile indexer_import = &batch::add_row_cache_indexer;

int main() {
  return gather_import && gather_padded_import && indexer_import ? 0 : 1;
}
