Normal Release shared engine + cpu;cuda correctness evidence.
Reproduction: checkout base commit and apply source/three-friend-export.patch, or verify the current header pin.
Use recorded strict-offline configure command with equivalent locked local assets, then build hyle_engine --parallel 2.
The first historical same-cache build failed; do not rewrite that receipt as PASS. Retry has the same flags plus only the declaration fix.
Historical absolute paths/cache contents are recorded inputs; adapt paths rather than copying a whole SDK.
normal/build.py and normal/inspect-smoke.py preserve attempts and explain actual observation. External import source/commands are under external-import/.
manifest.json hashes every payload member; its own bytes/SHA are pinned in the companion public JSON. Every member was independently read back after ZIP creation.
