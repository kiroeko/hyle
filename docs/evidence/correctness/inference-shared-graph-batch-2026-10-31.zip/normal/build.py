"""Normal product CMake build. Strictly offline; retain every actual attempt."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CACHE = ROOT / '.scratch/build-compute-v2-dev'
CMAKE = Path('C:/Program Files/CMake/bin/cmake.exe')
VCVARS = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Auxiliary/Build/vcvars64.bat')
CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
CUDA = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
SOURCE_PATHS = [
    'engine/models/qwen35/main.cc', 'engine/models/qwen35/cold_sources.cmake',
    'engine/models/qwen35/episode_state.h', 'engine/models/qwen35/auxiliary_programs.h',
    'engine/models/qwen35/auxiliary_programs.cc', 'tests/tools/qwen_host_image_test.cc',
    'tests/tools/qwen_auxiliary_preparation_case.h', 'CMakeLists.txt', 'CMakePresets.json',
    'cmake/HyleComponents.cmake', 'cmake/HyleComputeRoutes.cmake',
    'cmake/HyleCudaDependencies.cmake', 'cmake/HyleDependencyLock.json',
    'src/compute_ggml_runtime/CMakeLists.txt', 'src/compute_ggml_runtime/cpu_program.cmake',
    'engine/CMakeLists.txt', 'engine/models/qwen35/CMakeLists.txt',
]


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def preserve_baseline():
    destination = HERE / 'baseline-libs'
    destination.mkdir(exist_ok=False)
    bases = [ROOT / '.scratch/inference-auxiliary-cold-program-harness-20261030/model-link-base.json',
             ROOT / '.scratch/inference-m2-borrowed-alias-harness-20261030/model-link-base.json']
    selected = []
    for base in bases:
        pins = json.loads(base.read_text(encoding='utf-8'))['retained']
        selected.append({Path(p['path']).name: p for p in pins
                         if Path(p['path']).parent == CACHE / 'bin' and p['path'].lower().endswith('.lib')})
    if selected[0] != selected[1] or len(selected[0]) != 12:
        raise RuntimeError('The exact 12-library aux/M2 baseline sets differ')
    rows = []
    for name, pin in selected[0].items():
        original = Path(pin['path'])
        if identity(original) != pin:
            raise RuntimeError('Original retained library differs: ' + str(original))
        target = destination / name
        shutil.copyfile(original, target)
        copied = identity(target)
        if copied['sha256'] != pin['sha256'] or copied['bytes'] != pin['bytes']:
            raise RuntimeError('Preserved library differs: ' + str(target))
        rows.append(dict(original=pin, preserved=copied))
    dlls = [p for p in (CACHE / 'bin').glob('*.dll') if any(n in p.name.lower() for n in ['dnnl', 'mimalloc'])]
    dll_rows = []
    for p in dlls:
        target = destination / p.name
        shutil.copyfile(p, target)
        original, copied = identity(p), identity(target)
        if original['bytes'] != copied['bytes'] or original['sha256'] != copied['sha256']:
            raise RuntimeError('Preserved runtime differs: ' + str(p))
        dll_rows.append(dict(original=original, preserved=copied))
    save(HERE / 'baseline-libs.json', dict(status='SAVED_EXACT', bases=[identity(p) for p in bases],
        libraries=rows, related_runtime_dlls=dll_rows, total_bytes=sum(r['original']['bytes'] for r in rows),
        note='Only the twelve directly retained libraries; old bases are immutable. No SDK/source copy.'))
    print(json.dumps(dict(status='BASELINE_SAVED', libraries=len(rows), dlls=len(dll_rows),
                          total_bytes=sum(r['original']['bytes'] for r in rows))))


def prepare():
    if (HERE / 'prepared.json').exists():
        raise RuntimeError('Preparation already exists; do not overwrite the historical cache proof')
    if json.loads((HERE / 'baseline-libs.json').read_text(encoding='utf-8'))['status'] != 'SAVED_EXACT':
        raise RuntimeError('Preserve the retained baseline libraries before changing the old cache')
    if not (HERE / 'preconfigure-CMakeCache.txt').exists():
        shutil.copyfile(CACHE / 'CMakeCache.txt', HERE / 'preconfigure-CMakeCache.txt')
    env = dict(os.environ)
    # Old harness PATHs select experimental runtimes. A normal developer shell
    # needs the machine toolchain/SDKs, not those executable/DLL directories.
    env['PATH'] = os.pathsep.join(p for p in env.get('PATH', '').split(os.pathsep)
                                if '/.scratch/' not in p.replace('\\', '/').lower())
    for name in ['CL', '_CL_', 'CFLAGS', 'CXXFLAGS', 'LDFLAGS', 'CUDAFLAGS', 'CUDAARCHS',
                 'CUDACXX', 'CXX', 'CC', 'TORCH_INSTALL_PREFIX', 'CMAKE_PREFIX_PATH']:
        env.pop(name, None)
    capture = subprocess.run(f'cmd.exe /d /s /c ""{VCVARS}" >nul && set"',
                             env=env, cwd=ROOT, capture_output=True, text=True, errors='replace')
    if capture.returncode:
        raise RuntimeError('vcvars failed: ' + capture.stderr + capture.stdout)
    for line in capture.stdout.splitlines():
        if '=' in line and not line.startswith('='):
            key, value = line.split('=', 1)
            env[key.upper()] = value
    selected = {k: v for k, v in env.items() if k.upper() in
                ['PATH', 'INCLUDE', 'LIB', 'LIBPATH', 'VCTOOLSINSTALLDIR', 'VCTOOLSVERSION',
                 'WINDOWSSDKDIR', 'WINDOWSSDKVERSION', 'CUDA_PATH']}
    save(HERE / 'environment.json', selected)
    command = [str(CMAKE), '-S', str(ROOT), '-B', str(CACHE), '-G', 'Ninja',
        '-UHYLE_DEV_FACTORS', '-UFETCHCONTENT_SOURCE_DIR_*', '-UTorch_DIR',
        '-UHYLE_COMPUTE_TORCH_CPU_ROOT', '-UHYLE_COMPUTE_TORCH_CPU_ARCHIVE',
        '-UHYLE_COMPUTE_TORCH_CUDA_ARCHIVE', '-UHYLE_COMPUTE_TORCH_CPU_RESOLVED_ROOT',
        '-DHYLE_COMPONENTS:STRING=engine', '-DHYLE_COMPUTE_ROUTES:STRING=cpu;cuda',
        '-DCMAKE_BUILD_TYPE:STRING=Release', f'-DCMAKE_C_COMPILER:FILEPATH={CL}',
        f'-DCMAKE_CXX_COMPILER:FILEPATH={CL}', f'-DCMAKE_CUDA_COMPILER:FILEPATH={CUDA / "bin/nvcc.exe"}',
        f'-DCUDAToolkit_ROOT:PATH={CUDA}', '-DCMAKE_CUDA_ARCHITECTURES:STRING=80;89-real',
        '-DHYLE_STATIC:BOOL=OFF', '-DHYLE_WERROR:BOOL=OFF', '-DHYLE_INSTALL:BOOL=OFF',
        '-DHYLE_BUILD_TESTS:BOOL=OFF', '-DHYLE_BUILD_BENCH:BOOL=OFF',
        '-DHYLE_TEST_INSTRUMENTATION:BOOL=OFF', '-DHYLE_TRACE:BOOL=OFF',
        '-DHYLE_SANITIZER:STRING=off', '-DHYLE_SIMD_EXACT_TARGET:STRING=',
        '-DHYLE_DEP_SOURCE_CACHE:PATH=C:/public/tools/hyle-dependencies/v1',
        '-DFETCHCONTENT_FULLY_DISCONNECTED:BOOL=ON', '-DFETCHCONTENT_UPDATES_DISCONNECTED:BOOL=ON',
        f'-DFETCHCONTENT_SOURCE_DIR_FLASHINFER:PATH={ROOT / ".scratch/g04-bf16-partials-vendor/upstream"}']
    build = [str(CMAKE), '--build', str(CACHE), '--target', 'hyle_engine', '--parallel', '2']
    objects = list(CACHE.rglob('*.obj'))
    save(HERE / 'prepared.json', dict(prepared_utc=now(), source_head=subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        source_pins=[identity(ROOT / p) for p in SOURCE_PATHS],
        old_cache=identity(HERE / 'preconfigure-CMakeCache.txt'),
        old_build_ninja=identity(CACHE / 'build.ninja'), old_objects=len(objects),
        old_objects_bytes=sum(p.stat().st_size for p in objects),
        configure=command, build=build, downloads='forbidden; fully/updates disconnected ON',
        normal_features='engine; cpu+cuda; Release; shared; ordinary defaults; no test/trace ABI'))
    tools = [[str(CMAKE), '--version'], [shutil.which('ninja'), '--version'], [str(CUDA / 'bin/nvcc.exe'), '--version'],
             [str(CL)], ['nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total', '--format=csv,noheader']]
    facts = dict(platform=platform.platform(), processor=platform.processor(), tools=[])
    for args in tools:
        r = subprocess.run(args, cwd=ROOT, env=env, capture_output=True, text=True, errors='replace')
        facts['tools'].append(dict(command=args, exit_code=r.returncode, stdout=r.stdout, stderr=r.stderr))
    save(HERE / 'hardware-toolchain.json', facts)
    print(json.dumps(dict(status='PREPARED', old_objects=len(objects), cache=str(CACHE))))


def run(stage, attempt):
    plan = json.loads((HERE / 'prepared.json').read_text(encoding='utf-8'))
    pins = list(plan['source_pins'])
    supplement = HERE / ('source-freeze-' + stage + '-' + attempt + '.json')
    if supplement.exists():
        pins.extend(json.loads(supplement.read_text(encoding='utf-8'))['additional_source_pins'])
    for pin in pins:
        if identity(Path(pin['path'])) != pin:
            raise RuntimeError('Source changed since preparation: ' + pin['path'])
    output = HERE / stage / attempt
    output.mkdir(parents=True, exist_ok=False)
    command = plan[stage]
    save(output / 'command.json', dict(command=command, cwd=str(ROOT)))
    env = dict(os.environ)
    env.update(json.loads((HERE / 'environment.json').read_text(encoding='utf-8')))
    for name in ['CL', '_CL_', 'CFLAGS', 'CXXFLAGS', 'LDFLAGS', 'CUDAFLAGS', 'CUDAARCHS',
                 'CUDACXX', 'CXX', 'CC', 'TORCH_INSTALL_PREFIX', 'CMAKE_PREFIX_PATH']:
        env.pop(name, None)
    if stage == 'build' and attempt != 'attempt1':
        temporary = HERE / 'tmp'
        temporary.mkdir(exist_ok=True)
        env['TEMP'] = env['TMP'] = str(temporary)
        save(output / 'environment-overrides.json', dict(TEMP=str(temporary), TMP=str(temporary),
             scope='Root-authorized temporary-directory override only; original environment.json is immutable'))
    start = now()
    t = time.monotonic()
    with (output / 'stdout.log').open('wb') as out, (output / 'stderr.log').open('wb') as err:
        p = subprocess.Popen(command, cwd=ROOT, env=env, stdout=out, stderr=err)
        save(output / 'process.json', dict(command=command, pid=p.pid, start_utc=start, state='RUNNING'))
        print(json.dumps(dict(stage=stage, attempt=attempt, pid=p.pid, state='RUNNING')), flush=True)
        code = p.wait()
    result = dict(command=command, pid=p.pid, start_utc=start, end_utc=now(), exit_code=code,
                  elapsed_seconds=time.monotonic()-t, state='TERMINAL')
    save(output / 'process.json', result)
    if stage == 'configure' and code == 0:
        shutil.copyfile(CACHE / 'CMakeCache.txt', output / 'CMakeCache.txt')
    if stage == 'build' and code == 0:
        image = CACHE / 'bin/hyle.exe'
        result['image'] = identity(image)
        save(output / 'result.json', result)
    print(json.dumps(result), flush=True)
    raise SystemExit(code)


if __name__ == '__main__':
    if sys.argv[1] == 'preserve-baseline':
        preserve_baseline()
    elif sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] in ['configure', 'build']:
        run(sys.argv[1], sys.argv[2])
    else:
        raise RuntimeError('Unknown stage')
