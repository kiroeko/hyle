"""B12/B13 exact-header orchestration; existing B09 parser/HTTP is unchanged.

Only --plan-only is run during preparation. Actual mode remains root-only,
exclusive net-budget transport. No tensor body or inferred offset is fetched.
"""
from pathlib import Path
import argparse
import collections
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
BASE=S/'B09/fetch_headers.py'
BASE_SHA='5651141004eaa025b59fa24f2048a925d934d8678a6abf6e9a18fabeb016786c'
REPO='unsloth/GLM-5.3-Flash-GGUF'
REV='621d456e93e926e4b52f85cff5f634358c1828f9'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def configured(identity):
    assert identity in ('B12','B13') and sha(BASE)==BASE_SHA
    spec=importlib.util.spec_from_file_location('_flash_exact_header_reader',BASE)
    common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
    common.S=S/identity;common.R=R
    common.NEED=common.S/'headers-needed.json';common.SCHEMA=common.S/'roles-schema.json'
    need,schema=read(common.NEED),read(common.SCHEMA)
    common.LIMIT=need['metadata_upper_bound_bytes']
    def checked():
        assert need['id']==schema['id']==identity
        assert (need['repository'],need['revision'])==(schema['repository'],schema['revision'])==(REPO,REV)
        variant='UD-Q4_K_XL' if identity=='B12' else 'Q8_0'
        assert schema['variant']==variant
        assert need['maximum_request_bytes']==common.REQUEST==262144
        assert [f['shard'] for f in need['files']]==([1,2,5,6] if identity=='B12' else [1,2,8])
        assert sum(f['metadata_limit_bytes'] for f in need['files'])==common.LIMIT
        assert common.identity(R/need['evidence']['path'])==need['evidence']==schema['evidence']
        census=read(R/need['evidence']['path'])[schema['audit_key']]
        assert census['complete'] and (census['repo'],census['revision'],census['variant'])==(REPO,REV,variant)
        assert len(census['tensors'])==census['tensor_count']==1412
        rows={x['name']:x for x in census['tensors']};assert len(rows)==1412
        counts=collections.Counter(x['shard'] for x in census['tensors'])
        assert schema['physical_role_count']==len(schema['roles'])==94
        static=[x for x in schema['roles'] if not x['selected_source']]
        assert schema['static_roles']==len(static)==85
        assert schema['static_bytes']==sum(x['bytes'] for x in static)==1892821552
        assert collections.Counter(x['dtype'] for x in static)=={'Q8_0':43,'F32':42}
        for f in need['files']:
            assert f['expected_tensor_count']==counts[f['shard']]
            assert f['url']==f'https://huggingface.co/{REPO}/resolve/{REV}/{f["file"]}'
        for role in schema['roles']:
            row=rows[role['name']]
            assert (row['shard'],row['dtype'],list(map(int,row['shape'])))==(role['source_shard'],role['dtype'],role['gguf_dimensions'])
            dtype,block,size=common.TYPES[role['dtype_code']]
            assert dtype==role['dtype'] and role['gguf_dimensions'][0]%block==0
            import math
            assert role['bytes']==math.prod(role['gguf_dimensions'])//block*size
        for key,(path,pin) in common.PINNED.items():assert common.identity(R/path)['sha256']==pin,key
        return need,schema,census
    common.checked=checked
    return common


def main(identity):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only',action='store_true')
    args=parser.parse_args()
    c=configured(identity);need,schema,census=c.checked()
    if args.plan_only:
        print(json.dumps(dict(identity=identity,network_requests=0,shards=[x['shard'] for x in need['files']],
            maximum_metadata_bytes=c.LIMIT,maximum_request_bytes=c.REQUEST,tensor_payload_bytes=0,
            static_roles=85,static_payload_bytes=1892821552,expert_banks_metadata_only=9,
            offsets_available=False,pins_generated=False)))
        return
    c.require_transport()
    http=c.module('_flash_existing_strict_metadata_http','http');http.MAX_TOTAL=c.LIMIT
    attempt=1
    while (c.S/f'http-requests-attempt{attempt}.json').exists():attempt+=1
    try:
        receipts,actual,config=[],{},{}
        for source in need['files']:
            receipt,rows,metadata=c.one(source,need,census,http)
            assert not (set(actual)&set(rows))
            receipts.append(receipt);actual.update(rows);config[str(source['shard'])]=metadata
    assert config['1'].get('general.architecture')=='glm5next', 'Actual identity is not the Flash hybrid GGUF architecture'
        by_shard={x['shard']:x for x in receipts};roles=[]
        for original in schema['roles']:
            row,shard=actual[original['name']],by_shard[original['source_shard']]
            assert row['bytes']==original['bytes'] and row['shape']==original['gguf_dimensions']
            first=shard['data_base']+row['offset']
            roles.append(dict(original,filename=original['name']+'.bin',
                data_relative_half_open=[row['offset'],row['offset']+row['bytes']],
                absolute_inclusive=[first,first+row['bytes']-1]))
        common=dict(repository=REPO,revision=REV,variant=schema['variant'],source_schema=c.identity(c.SCHEMA),
            shards=receipts,complete_absolute_ranges=True,http_identity_authenticated=True,payload_acquired=False,
            generated_pins=False,metadata_only=True,tensor_payload_bytes=0,whole_shards_downloaded=False)
        c.save(c.S/'roles-plan.json',dict(common,roles=roles,original_roles=94,
            full_expert_banks_acquire=False,actual_metadata=config))
        static=[x for x in roles if not x['selected_source']]
        c.save(c.S/'static-plan.json',dict(common,roles=static,original_roles=85,
            source_bytes=sum(x['bytes'] for x in static),actual_metadata=config))
        c.save(c.S/'summary.json',dict(complete=True,metadata_only=True,tensor_payload_bytes=0,
            maximum_metadata_bytes=c.LIMIT,metadata_limit_is_hard_upper_bound=True,
            actual_header_bytes=sum(x['header']['bytes'] for x in receipts),new_requested_bytes=http.reserved,
            headers=receipts,roles_plan=c.identity(c.S/'roles-plan.json'),static_plan=c.identity(c.S/'static-plan.json')))
        print(json.dumps(dict(identity=identity,complete=True,metadata_only=True,
            actual_header_bytes=sum(x['header']['bytes'] for x in receipts),
            new_requested_bytes=http.reserved,tensor_payload_bytes=0,roles=94,static_roles=85)),flush=True)
    finally:
        c.save(c.S/f'http-requests-attempt{attempt}.json',dict(requests=http.requests,
            reserved_request_bytes=http.reserved,maximum_metadata_bytes=c.LIMIT,
            helpers={key:c.identity(R/path) for key,(path,_) in c.PINNED.items()}))

