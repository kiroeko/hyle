"""B12 one-Flash-TU adapter on the actual parity/tail current closure.

Reuses B10 compile/link utilities and the existing owned supply driver. Only
root invokes actions after the complete real85-role pins exist; no download
or executor is implemented here. The shared utility's output filename is kept.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=S.parents[3]
SHARED=A.parent/'B10/native-integration/build.py'
SHARED_SHA='96f154b81677aeeccf2cfb499818e5b0ab3bb24ff6ef8740cc1207e152a4b2d2'
CURRENT=R/'.scratch/mtp-packed-head-20261024/parity-current-integration/build.py'
CURRENT_SHA='0fc11f36aa9e669ebf3d21876ed4c10fbd863c0ee43ef0c575c07ada96c6cacc'
SOURCE=R/'tests/compute_models/glm_mtp_state_consumer_test.cc'
RECIPE=R/'.scratch/glm-gguf-selected-20261023/flash-consumer-proposal/compile2/flash-state/identity.json'
HEADER=A/'generated/glm_gguf_b12_artifacts.h'
ACQUIRE_SHA='394df60f9336be88cf2e5edc30a0ed8745bced7194732bc4e4a6f57320c43ff6'
CONTRACT=dict(repository='unsloth/GLM-5.3-Flash-GGUF',revision='621d456e93e926e4b52f85cff5f634358c1828f9',
              variant='UD-Q4_K_XL',original_roles=85,source_bytes=1892821552)


def load(name,path,sha=None):
    if sha is not None and hashlib.sha256(path.read_bytes()).hexdigest()!=sha:raise ValueError('Frozen helper changed: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def pins():
    if not HEADER.is_file() or not HEADER.with_suffix('.json').is_file():raise RuntimeError('B12 complete real85-role generated pins are required')
    a=load('_b12_actual_acquisition',A/'acquire.py',ACQUIRE_SHA).configured()
    validator=load('_b12_existing_complete_validator',A.parent/'B09/generate_artifacts.py','c3269d20c925976748f685fcbc290f569c2e7e36eaa5b99a9d8f3e9539608583')
    validator.S,validator.R,validator.acquisition=A,R,lambda:a
    _,record,manifest,expert=validator.validate(A/'original-static')
    proof=a.read(HEADER.with_suffix('.json'))
    if not proof['complete'] or any(proof.get(k)!=v for k,v in CONTRACT.items()):raise ValueError('B12 generated fixture has a different source identity/extent')
    for key,path in [('static_plan',A/'static-plan.json'),('expert_source_plan',A/'expert-source-plan.json'),
        ('fixture_policy',A/'fixture-policy.json'),('acquisition',A/'original-static/acquisition.json'),
        ('manifest',A/'original-static/manifest.json'),('generated_header',HEADER),('generator',A/'generate_artifacts.py'),
        ('common_generator',A.parent/'generate_flash_artifacts.py'),('validator',A.parent/'B09/generate_artifacts.py')]:
        if proof[key]!=a.identity(path):raise ValueError('B12 actual fixture/source receipt changed: '+key)
    if len(expert['roles'])!=9 or expert['typed_catalog']['bytes']!=112:raise ValueError('B12 requires three actual three-leg expert sections')
    return HEADER,HEADER.with_suffix('.json'),dict(**CONTRACT,static_plan=a.identity(A/'static-plan.json'),
        expert_plan=a.identity(A/'expert-source-plan.json'),acquisition=a.identity(A/'original-static/acquisition.json'),
        manifest=a.identity(A/'original-static/manifest.json'),body_rehashed=False)


def configured():
    c=load('_b12_existing_host_lifecycle',SHARED,SHARED_SHA)
    current=load('_b12_actual_parity_closure',CURRENT,CURRENT_SHA)
    c.S,c.DATA,c.SOURCE,c.RECIPE=S,A,SOURCE,S/'prepared-flash-recipe.json'
    c.BASE=c.BASE_IMAGE=CURRENT.parent/'current-link1'
    def source_closure():
        result=current.closure(consumer_replaced=True)
        c.RETIRED_BASE_CONSUMER=result[0]['retired_base_consumer']
        return result
    c.closure=source_closure
    # Keep the original native2 manifest owner; it is independent of this
    # adapter's output directory. The new MMVQ owner is a retained link input.
    c.native_inputs=current.base.native_inputs
    c.pins=pins
    return c


def compile_one(c,attempt):
    pins()
    c.RECIPE=S/f'prepared-flash-recipe{attempt}.json'
    recipe=c.read(RECIPE)
    command=[x for x in recipe['command'] if not x.startswith(('/DHYLE_TEST_GLM_Q30_','/DHYLE_TEST_GLM_B12_','/DHYLE_TEST_GLM_B13_'))]
    command.insert(1,'/DHYLE_TEST_GLM_B12_ARTIFACTS_HEADER="'+HEADER.as_posix()+'"')
    prepared=dict(command=command,source=c.identity(SOURCE),historical_recipe=c.identity(RECIPE),prepared_only=True)
    if c.RECIPE.exists():
        if c.read(c.RECIPE)!=prepared:raise ValueError('B12 immutable prepared recipe differs')
    else:c.save(c.RECIPE,prepared)
    c.compile_one(attempt)
    path=S/f'compile{attempt}/glm-pro/identity.json';record=c.check_record(path)
    record.update(artifact='B12',entry=c.identity(Path(__file__)),shared_helper=c.identity(SHARED),
                  source_scope='Actual B12 Flash fixture; historical shared helper tag glm-pro only names its output directory.')
    c.save(path,record)


def link(c,attempt,compile_attempt):
    c.link(attempt,compile_attempt)
    out=S/f'tests-link{attempt}';plan=c.read(out/'link-plan.json')
    plan.update(artifact='B12',entry=c.identity(Path(__file__)),source_contract=CONTRACT,
        retired_base_consumer=c.RETIRED_BASE_CONSUMER,
        note='Actual B12 Flash consumer on current parity/tail Graph/native closure; one consumer TU replaces Flash compile2.')
    c.save(out/'link-plan.json',plan)
    ready=c.read(out/'ready.json');ready.update(link_plan=c.identity(out/'link-plan.json'),artifact='B12',
        scope='Actual B12 Flash complete85-role source; linked only, native execution is still pending.')
    c.save(out/'ready.json',ready)


def run(c,args):
    pins();out=S/f'checks{args.run_attempt}-{args.backend}';out.mkdir(exist_ok=False)
    image_dir=S/f'tests-link{args.link_attempt}';ready=c.read(image_dir/'ready.json')
    for key in ('image','link_plan','runtime_environment','consumer_record'):c.require(ready[key])
    c.check_record(c.resolve(ready['consumer_record']['path']))
    runtime=c.read(image_dir/'runtime-environment.json')
    for row in runtime['staged_dlls']:c.require(row)
    case='GlmMtpStateConsumer.'+args.backend.title()+'B12OriginalGgufTarget43And44AndNextNFullVocabularyVerifier'
    command=[sys.executable,str(S/'run_with_supply.py'),'--image',ready['image']['path'],
        '--frontier-file',str(out/'frontier.json'),'--','--gtest_filter='+case,'--gtest_throw_on_failure=1',
        '--gtest_output=xml:'+str(out/'results.xml')]
    env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_GLM_')}
    env.update(PATH=runtime['PATH'],HYLE_GLM_B12_ORIGINAL_DIR=str(A/'original-static'),HYLE_GLM_B12_EXPERT_DIR=str(A/'original-experts'),
               OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
    c.save(out/'plan.json',dict(command=command,image=ready['image'],consumer_record=ready['consumer_record'],
        entry=c.identity(Path(__file__)),owned_entry=c.identity(S/'run_with_supply.py'),source_contract=CONTRACT,case=case))
    q=load('_b12_existing_process_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process=q.execute(command,env,out/'run',timeout=args.timeout)
    result=dict(process=process,passed=False,image=ready['image'],consumer_record=ready['consumer_record'],throughput_evidence=False,memory_evidence=False)
    try:
        if process['exit'] or process['timed_out']:raise RuntimeError('B12 owned native/supply process failed')
        driver=c.read(out/'frontier.driver.json')
        if driver['native']['exit'] or driver['native']['stopped_by_driver'] or driver['job_cleanup']['remaining_descendants']!=0:raise ValueError('B12 native tree did not retire successfully')
        if any(row['exit'] or row.get('stopped_by_driver',False) for row in driver['fetches']):raise ValueError('B12 actual expert supply failed')
        if not (R/'.scratch/mtp-download-budget-20261023/PAUSED').is_file():raise ValueError('Budget pause must be restored')
        tree=ET.parse(out/'results.xml').getroot();cases=list(tree.iter('testcase'))
        if len(cases)!=1 or any(int(tree.get(k,'0')) for k in ('failures','errors','disabled')) or list(tree.iter('skipped')) or list(tree.iter('failure')):raise ValueError('Expected exactly one passing B12 case')
        item=cases[0]
        if item.get('classname')+'.'+item.get('name')!=case or item.get('status')!='run' or item.get('result')!='completed':raise ValueError('B12 exact case differs')
        properties={x.get('name'):x.get('value') for x in item.iter('property')}
        expected=dict(artifact_repository=CONTRACT['repository'],artifact_revision=CONTRACT['revision'],artifact_variant=CONTRACT['variant'],
            static_original_roles='85',static_original_bytes='1892821552',expert_domain='288',resident_experts='8',expert_planes='3',
            static_source_plan_sha256=c.identity(A/'static-plan.json')['sha256'],expert_source_plan_sha256=c.identity(A/'expert-source-plan.json')['sha256'])
        if any(properties.get(k)!=v for k,v in expected.items()) or int(properties['actual_submissions'])<=0:raise ValueError('B12 actual static/expert identity or graph count differs')
        c.check_record(c.resolve(ready['consumer_record']['path']))
        result.update(passed=True,case=case,tests=1,failures=0,skips=0,properties=properties,
                      actual_graph_submissions=int(properties['actual_submissions']),driver=c.identity(out/'frontier.driver.json'))
    except Exception as error:result['error']=dict(type=type(error).__name__,message=str(error))
    c.save(out/'summary.json',result)
    if not result['passed']:raise SystemExit(process['exit'] or 1)
    print('PASSED actual B12',args.backend,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=('compile','link','run'))
    parser.add_argument('--compile-attempt',type=int,default=1);parser.add_argument('--link-attempt',type=int,default=1)
    parser.add_argument('--run-attempt',type=int,default=1);parser.add_argument('--backend',choices=('cpu','cuda'),default='cpu')
    parser.add_argument('--timeout',type=int,default=14400);args=parser.parse_args()
    if min(args.compile_attempt,args.link_attempt,args.run_attempt,args.timeout)<=0:raise ValueError('Positive attempts/timeout required')
    c=configured()
    if args.action=='compile':compile_one(c,args.compile_attempt)
    elif args.action=='link':link(c,args.link_attempt,args.compile_attempt)
    else:run(c,args)
