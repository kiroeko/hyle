"""One real B12 frontier -> existing acquire.py bounded budget batch."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=S.parents[3]
ACQUIRE_SHA='394df60f9336be88cf2e5edc30a0ed8745bced7194732bc4e4a6f57320c43ff6'

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--frontier-file',type=Path,required=True)
    parser.add_argument('--plan-only',action='store_true');args=parser.parse_args()
    raw=args.frontier_file.read_bytes()
    if not 0<len(raw)<=65536:raise ValueError('B12 frontier exceeds bounded metadata')
    request=json.loads(raw)
    for key in ('missing_ids','global_ids'):
        values=request[key]
        if not isinstance(values,list) or not 1<=len(values)<=8 or values!=sorted(set(values)) or any(type(n)is not int or not 0<=n<288 for n in values):raise ValueError('B12 requires actual sorted unique1..8 IDs')
    if request['section'] not in ('nextn','target43','target44') or type(request['stage'])is not int or request['stage']!=0 or not set(request['missing_ids'])<=set(request['global_ids']):raise ValueError('B12 actual section/stage/IDs differ')
    script=A/'acquire.py'
    if hashlib.sha256(script.read_bytes()).hexdigest()!=ACQUIRE_SHA:raise ValueError('B12 frozen acquisition adapter changed')
    spec=importlib.util.spec_from_file_location('_b12_existing_frontier_acquisition',script)
    adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter);a=adapter.configured()
    _,expert,_=a.checked();section,ids=request['section'],request['missing_ids']
    if args.plan_only:
        print(json.dumps(dict(section=section,stage=0,global_ids=ids,roles=3*len(ids),typed_catalog_bytes_per_id=112,
            maximum_body_bytes=a.SECTION[section][1]*len(ids),source_plan=a.identity(A/'expert-source-plan.json'),network_requests=0)));return 0
    label=section+'-'+ '-'.join(map(str,ids));attempt=1
    while (A/'frontier-plans'/f'{label}-attempt{attempt}.json').exists() or (A/'batches'/f'{label}-attempt{attempt}').exists():attempt+=1
    plan=A/'frontier-plans'/f'{label}-attempt{attempt}.json'
    command=[sys.executable,str(script),'experts','--section',section,'--ids',*map(str,ids),'--attempt',str(attempt),'--write-batch-plan',str(plan)]
    subprocess.run(command,cwd=R,check=True)
    frozen=a.read(plan)
    if frozen['script_sha256']!=hashlib.sha256(script.read_bytes()).hexdigest():raise ValueError('B12 body adapter changed after plan preparation')
    return subprocess.run([sys.executable,str(R/'.scratch/mtp-download-budget-20261023/run_batch.py'),str(plan)],cwd=R).returncode

if __name__=='__main__':sys.exit(main())
