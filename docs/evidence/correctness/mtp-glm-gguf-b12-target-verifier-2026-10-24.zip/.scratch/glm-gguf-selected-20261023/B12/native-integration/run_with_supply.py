"""B12 configuration of the existing owned Windows process-tree driver."""
from pathlib import Path
import hashlib,importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=S.parents[3]
DRIVER=R/'.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'
DRIVER_SHA='d3e0749a5b565717582ff33f9f02251faae5309c71b693abfd3a6e8b880be50a'

def main():
    if hashlib.sha256(DRIVER.read_bytes()).hexdigest()!=DRIVER_SHA:raise ValueError('Existing owned driver changed')
    spec=importlib.util.spec_from_file_location('_b12_existing_owned_driver',DRIVER)
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    driver.S,driver.R=A,R;driver.DOMAIN,driver.SECTIONS=288,('nextn','target43','target44')
    driver.FETCH_SCRIPT=S/'supply_experts.py'
    driver.WAIT_ENV='HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS'
    driver.FRONTIER_ENV='HYLE_GLM_GGUF_FLASH_FRONTIER_FILE'
    return driver.main()

if __name__=='__main__':sys.exit(main())
