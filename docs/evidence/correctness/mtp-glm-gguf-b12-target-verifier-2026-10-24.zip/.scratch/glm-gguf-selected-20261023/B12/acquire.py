"""Own B12 static85 / selected three-leg entry; no HTTP on import/plan-only."""
from pathlib import Path
import hashlib,importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
COMMON=S.parent/'acquire_flash.py'
COMMON_SHA='f5bd5f31e66e06e936933c0891df6d870bb3e5d2be99a3d139e311ab0e14fee1'
def configured():
    assert hashlib.sha256(COMMON.read_bytes()).hexdigest()==COMMON_SHA,'Frozen common Flash acquisition changed'
    spec=importlib.util.spec_from_file_location('_b12_common_acquisition',COMMON)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m.configured('B12',Path(__file__))
if __name__=='__main__':configured().main()
