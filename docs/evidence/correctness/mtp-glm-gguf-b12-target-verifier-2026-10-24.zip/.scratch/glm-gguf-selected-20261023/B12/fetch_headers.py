from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from fetch_flash_headers import main
if __name__=='__main__':main('B12')
