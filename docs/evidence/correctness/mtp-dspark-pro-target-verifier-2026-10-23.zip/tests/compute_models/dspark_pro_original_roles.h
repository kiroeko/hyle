#pragma once

#include <array>
#include <memory>
#include <optional>
#include <unordered_map>

#include "dspark_original_role_source.h"
#include "dspark_original_target_roles.h"
#include "dspark_target_geometry.h"

namespace dspark_pro_original_roles {
namespace source=dspark_original_role_source;
namespace c=hyle::compute;
namespace m=hyle::mem;
using Leg=dspark_original_target_roles::Leg;
using Matrix=dspark_original_target_roles::Matrix;
using ReadonlyRole=source::ReadonlyRole;
inline constexpr std::string_view kRepository="deepseek-ai/DeepSeek-V4-Pro-0813";
inline constexpr std::string_view kRevision="72e1d3230f6c080a530b0a1d46f8eb4602340597";
inline constexpr auto kGeometry=dspark_target_geometry::kPro;
inline constexpr std::size_t kDenseBytes=6504119672ULL;
// Filled only from root's completed acquisition. Empty pins reject loading.
inline constexpr std::string_view kDenseIndexSha256="f03393f23217b99b25652c29f2b6a4c2c9444925ebe2f5ba83e919bddaa6d3ff";
enum class Section {kTarget,kDraft};
inline std::string layer_name(Section section,std::size_t stage,std::string_view suffix) {
  if(stage>=3)throw std::runtime_error("original Pro stage must be0..2");
  if(section!=Section::kTarget&&section!=Section::kDraft)throw std::runtime_error("original Pro source section differs");
  return (section==Section::kTarget?"layers."+std::to_string(kGeometry.first_target_layer+std::int64_t(stage)):
      "mtp."+std::to_string(stage))+"."+std::string(suffix);
}
struct Selection final {std::vector<std::int32_t> globals,map;};
inline Selection select(std::span<const std::int32_t> actual_ids,std::size_t capacity=6) {
  if(actual_ids.empty()||!capacity||capacity>std::size_t(kGeometry.experts)||actual_ids.size()>capacity)
    throw std::runtime_error("original Pro selection exceeds its actual resident capacity");
  Selection result;result.map.assign(std::size_t(kGeometry.experts),-1);result.globals.reserve(actual_ids.size());
  for(const auto id:actual_ids) {
    if(id<0||id>=kGeometry.experts)throw std::runtime_error("original Pro global expert outside384-domain");
    result.globals.push_back(id);
  }
  std::ranges::sort(result.globals);
  result.globals.erase(std::unique(result.globals.begin(),result.globals.end()),result.globals.end());
  for(std::size_t i=0;i<result.globals.size();++i)result.map[std::size_t(result.globals[i])]=std::int32_t(i);
  return result;
}
} // namespace dspark_pro_original_roles

#include "dspark_pro_dense_specs.h"

namespace dspark_pro_original_roles {
inline std::string expert_name(Section section,std::size_t stage,Leg leg,std::int32_t global,bool scales) {
  if(global<0||global>=kGeometry.experts)throw std::runtime_error("original Pro global expert outside384-domain");
  const char *which=nullptr;
  switch(leg) {case Leg::kGate:which="w1";break;case Leg::kUp:which="w3";break;case Leg::kDown:which="w2";break;
    default:throw std::runtime_error("unknown original Pro expert leg");}
  return layer_name(section,stage,"ffn.experts."+std::to_string(global)+"."+which+(scales?".scale":".weight"));
}
// A selected bundle contains complete original code/SF pairs for all three
// legs of each listed global expert. It is authenticated independently from
// the immutable dense bundle and never fetches or synthesizes missing roles.
class ExpertSet final {
 public:
  ExpertSet(const ExpertSet&)=delete;
  ExpertSet& operator=(const ExpertSet&)=delete;
  ExpertSet(ExpertSet&&) noexcept=default;
  ExpertSet& operator=(ExpertSet&&)=delete;
  static ExpertSet load(const std::filesystem::path &directory,std::string_view pin,
      Section section,std::size_t stage,std::span<const std::int32_t> sorted_globals) {
    (void)layer_name(section,stage,"");
    if(sorted_globals.empty()||sorted_globals.size()>std::size_t(kGeometry.experts))
      throw std::runtime_error("original Pro expert set needs a nonempty bounded selection");
    for(std::size_t i=0;i<sorted_globals.size();++i)
      if(sorted_globals[i]<0||sorted_globals[i]>=kGeometry.experts||(i&&sorted_globals[i-1]>=sorted_globals[i]))
        throw std::runtime_error("original Pro expert set IDs must be sorted, unique and within384-domain");
    std::vector<std::string> names;names.reserve(sorted_globals.size()*6);
    for(const auto global:sorted_globals)for(const auto leg:{Leg::kGate,Leg::kUp,Leg::kDown})
      for(const bool scale:{false,true})names.push_back(expert_name(section,stage,leg,global,scale));
    std::vector<source::Spec> specs;specs.reserve(names.size());std::size_t bytes=0,ordinal=0;
    for(const auto global:sorted_globals) {
      (void)global;
      for(const auto leg:{Leg::kGate,Leg::kUp,Leg::kDown})for(const bool scale:{false,true}) {
        const auto n=leg==Leg::kDown?kGeometry.hidden:kGeometry.intermediate;
        const auto k=leg==Leg::kDown?kGeometry.intermediate:kGeometry.hidden;
        source::Spec spec{names[ordinal++],c::DataType::kUInt8,n,k/(scale?32:2)};
        const auto extent=source::take(spec.description().required_bytes(),"original Pro selected expert extent");
        if(extent>std::numeric_limits<std::size_t>::max()-bytes)
          throw std::runtime_error("original Pro expert set extent exceeds size_t");
        bytes+=extent;specs.push_back(spec);
      }
    }
    ExpertSet result(section,stage,std::vector<std::int32_t>(sorted_globals.begin(),sorted_globals.end()),
        source::Bundle::load(directory,pin,specs,bytes));
    for(const auto global:sorted_globals)for(const auto leg:{Leg::kGate,Leg::kUp,Leg::kDown})
      for(const auto scale:result.raw(leg,global,true))if(scale==std::byte{255})
        throw std::runtime_error("original Pro selected expert UE8M0 scale is nonfinite");
    return result;
  }
  Section section() const noexcept{return section_;}
  std::size_t stage() const noexcept{return stage_;}
  std::span<const std::int32_t> globals() const noexcept{return globals_;}
  std::span<const std::byte> raw(Leg leg,std::int32_t global,bool scales) const {
    return bundle_.raw(expert_name(section_,stage_,leg,global,scales));
  }
  m::ConstBufferView view(Leg leg,std::int32_t global,bool scales) const {
    return bundle_.view(expert_name(section_,stage_,leg,global,scales));
  }
 private:
  ExpertSet(Section section,std::size_t stage,std::vector<std::int32_t> globals,source::Bundle &&bundle)
      :section_(section),stage_(stage),globals_(std::move(globals)),bundle_(std::move(bundle)) {}
  Section section_;
  std::size_t stage_;
  std::vector<std::int32_t> globals_;
  source::Bundle bundle_;
};
class Data final {
 public:
  Data()=default;
  Data(const Data&)=delete;
  Data& operator=(const Data&)=delete;
  Data(Data&&) noexcept=default;
  Data& operator=(Data&&)=delete;
  static Data load(const std::filesystem::path &directory,std::string_view pin=kDenseIndexSha256) {
    Data result(source::Bundle::load(directory,pin,kDenseSpecs,kDenseBytes));
    for(const auto &spec:result.bundle_.specs()) {
      if(spec.type==c::DataType::kUInt8)continue; // raw UE8 only, part of its E4 carrier.
      auto prepared=std::make_unique<Prepared>();prepared->description=spec.description();
      if(spec.type==c::DataType::kFloat8E4M3FN) {
        const auto scale_name=scale_of(spec.name);const auto &scale_spec=result.bundle_.spec(scale_name);
        prepared->matrix=std::make_unique<source::Float8Matrix>(source::prepare_float8(
            spec.description(),result.bundle_.view(spec.name),result.bundle_.raw(spec.name),
            scale_spec.description(),result.bundle_.view(scale_name),result.bundle_.raw(scale_name)));
        prepared->description=prepared->matrix->description;
      } else if(cold_widen(spec.name)) {
        if(spec.type!=c::DataType::kBFloat16||spec.columns<=0)
          throw std::runtime_error("original Pro compressor storage differs");
        prepared->floats=source::widen_bfloat(result.bundle_.raw(spec.name));
        prepared->description=source::take(c::TensorDesc::dense(c::DataType::kFloat32,
            std::array{spec.rows,spec.columns}),"original Pro F32 compressor");
      } else if(spec.type==c::DataType::kFloat32)prepared->floats=source::decode_f32(result.bundle_.raw(spec.name));
      else if(spec.type==c::DataType::kBFloat16&&spec.columns==0)prepared->norm=source::decode_bfloat(result.bundle_.raw(spec.name));
      result.prepared_.emplace(spec.name,std::move(prepared));
    }
    return result;
  }
  const source::Spec &spec(std::string_view name) const{return bundle_.spec(name);}
  std::span<const source::Spec> specs() const noexcept{return bundle_.specs();}
  std::span<const std::byte> raw(std::string_view name) const{return bundle_.raw(name);}
  m::ConstBufferView view(std::string_view name) const{return bundle_.view(name);}
  const c::TensorDesc &description(std::string_view name) const{return ready(name).description;}
  std::span<const std::byte> payload(std::string_view name) const {
    const auto &value=ready(name);
    if(value.matrix)return value.matrix->payload();
    if(cold_widen(name))return std::as_bytes(std::span(value.floats));
    return raw(name);
  }
  Matrix matrix(std::string_view name) const {
    const auto &value=ready(name);const auto &original=spec(name);
    if(!value.matrix)throw std::runtime_error("original Pro matrix is not E4+UE8");
    return {raw(name),value.matrix->scales,original.rows,original.columns};
  }
  std::span<const std::uint16_t> norm(std::string_view name) const {
    const auto &original=spec(name);
    if(original.type!=c::DataType::kBFloat16||original.columns!=0)
      throw std::runtime_error("original Pro norm must remain a BF16 vector");
    return ready(name).norm;
  }
  std::span<const float> floats(std::string_view name) const {
    if(spec(name).type!=c::DataType::kFloat32&&!cold_widen(name))
      throw std::runtime_error("original Pro requested F32 view of another storage type");
    return ready(name).floats;
  }
  // Explicit cold mutation: the consumer calls this only after a completed
  // router frontier and before supplying/submitting the next ordinary phase.
  // Existing mappings are immutable and never replaced or retired here.
  void attach_experts(std::shared_ptr<const ExpertSet> set) {
    if(!set)throw std::runtime_error("original Pro expert attachment has no authenticated owner");
    auto &current=expert_sets_[section_index(set->section())].at(set->stage());
    auto next=current;
    for(const auto global:set->globals())
      if(!next.emplace(global,set).second)throw std::runtime_error("original Pro expert attachment would rebind an existing global ID");
    current.swap(next);
  }
  bool has_expert(Section section,std::size_t stage,std::int32_t global) const {
    (void)expert_name(section,stage,Leg::kGate,global,false);
    return expert_sets_[section_index(section)][stage].contains(global);
  }
  c::TensorDesc expert_description(Section section,std::size_t stage,Leg leg) const {
    (void)layer_name(section,stage,"");
    const bool down=leg==Leg::kDown;
    if(leg!=Leg::kGate&&leg!=Leg::kUp&&!down)throw std::runtime_error("unknown original Pro expert leg");
    return source::take(c::float4_grouped_weight_description(kGeometry.experts,
        down?kGeometry.hidden:kGeometry.intermediate,down?kGeometry.intermediate:kGeometry.hidden),
        "original Pro full FP4 source geometry");
  }
  std::span<const std::byte> expert_codes(Section section,std::size_t stage,Leg leg,std::int32_t global) const {
    return expert_set(section,stage,global).raw(leg,global,false);
  }
  std::span<const std::byte> expert_scales(Section section,std::size_t stage,Leg leg,std::int32_t global) const {
    return expert_set(section,stage,global).raw(leg,global,true);
  }
  m::ConstBufferView expert_view(Section section,std::size_t stage,Leg leg,std::int32_t global,bool scales) const {
    return expert_set(section,stage,global).view(leg,global,scales);
  }
 private:
  explicit Data(source::Bundle &&bundle):bundle_(std::move(bundle)) {}
  struct Prepared final {
    c::TensorDesc description;
    std::unique_ptr<source::Float8Matrix> matrix;
    std::vector<float> floats;
    std::vector<std::uint16_t> norm;
  };
  // Prepared maps and borrowed raw payloads retire before this strong mapping.
  source::Bundle bundle_;
  std::unordered_map<std::string_view,std::unique_ptr<Prepared>> prepared_;
  std::array<std::array<std::unordered_map<std::int32_t,std::shared_ptr<const ExpertSet>>,3>,2> expert_sets_;
  static std::size_t section_index(Section section) {
    switch(section) {case Section::kTarget:return 0;case Section::kDraft:return 1;
      default:throw std::runtime_error("original Pro expert source section differs");}
  }
  const ExpertSet &expert_set(Section section,std::size_t stage,std::int32_t global) const {
    (void)expert_name(section,stage,Leg::kGate,global,false);
    const auto &sets=expert_sets_[section_index(section)][stage];const auto found=sets.find(global);
    if(found==sets.end())throw std::runtime_error("original Pro expert not acquired: "+expert_name(section,stage,Leg::kGate,global,false));
    return *found->second;
  }
  const Prepared &ready(std::string_view name) const {
    const auto found=prepared_.find(name);
    if(found==prepared_.end())throw std::runtime_error("original Pro runtime role not prepared: "+std::string(name));
    return *found->second;
  }
  static bool cold_widen(std::string_view name) {
    return name.ends_with("compressor.wkv.weight")||name.ends_with("compressor.wgate.weight");
  }
  static std::string scale_of(std::string_view name) {
    if(!name.ends_with(".weight"))throw std::runtime_error("original Pro E4 role has no weight suffix");
    return std::string(name.substr(0,name.size()-7))+".scale";
  }
};
struct SourceView final {
  std::shared_ptr<const Data> source;
  Section section;
  Matrix matrix(std::size_t stage,dspark_original_target_roles::Role role) const {
    return checked().matrix(role_name(stage,role));
  }
  std::span<const std::uint16_t> norm(std::size_t stage,dspark_original_target_roles::Role role) const {
    return checked().norm(role_name(stage,role));
  }
  std::span<const float> floats(std::size_t stage,dspark_original_target_roles::Role role) const {
    return checked().floats(role_name(stage,role));
  }
  std::span<const std::byte> raw(std::size_t stage,dspark_original_target_roles::RawRole role) const {
    const auto suffix=dspark_original_target_roles::kRawSpecs[dspark_original_target_roles::index(role)].suffix;
    return checked().raw(layer_name(section,stage,suffix));
  }
  std::span<const float> floats(dspark_original_target_roles::FinalRole role) const {
    require_target();return checked().floats(dspark_original_target_roles::final_spec(role).suffix);
  }
  std::span<const std::uint16_t> norm() const {
    require_target();return checked().norm("norm.weight");
  }
  c::TensorDesc expert_description(std::size_t stage,Leg leg) const {
    if(!source)throw std::runtime_error("original Pro source view has no owner");
    return source->expert_description(section,stage,leg);
  }
  std::span<const std::byte> expert_codes(std::size_t stage,Leg leg,std::int32_t global) const {
    if(!source)throw std::runtime_error("original Pro source view has no owner");
    return source->expert_codes(section,stage,leg,global);
  }
  std::span<const std::byte> expert_scales(std::size_t stage,Leg leg,std::int32_t global) const {
    if(!source)throw std::runtime_error("original Pro source view has no owner");
    return source->expert_scales(section,stage,leg,global);
  }
  m::ConstBufferView expert_view(std::size_t stage,Leg leg,std::int32_t global,bool scales) const {
    if(!source)throw std::runtime_error("original Pro source view has no owner");
    return source->expert_view(section,stage,leg,global,scales);
  }
 private:
  const Data &checked() const {
    if(!source)throw std::runtime_error("original Pro source view has no owner");
    return *source;
  }
  std::string role_name(std::size_t stage,dspark_original_target_roles::Role role) const {
    const auto raw_role=dspark_original_target_roles::raw_role(role);
    const auto suffix=dspark_original_target_roles::kRawSpecs[dspark_original_target_roles::index(raw_role)].suffix;
    return layer_name(section,stage,suffix);
  }
  void require_target() const {
    if(section!=Section::kTarget)throw std::runtime_error("original Pro target final role requested from draft source");
  }
};
inline SourceView source_view(std::shared_ptr<const Data> source,Section section) {
  if(!source)throw std::runtime_error("original Pro source view needs its owner");
  (void)layer_name(section,0,"");return {std::move(source),section};
}
struct Bound final {
  std::shared_ptr<const Data> source;
  std::unordered_map<std::string_view,ReadonlyRole> roles;
  const ReadonlyRole &at(std::string_view name) const {
    const auto found=roles.find(name);
    if(found==roles.end())throw std::runtime_error("original Pro immutable role not bound: "+std::string(name));
    return found->second;
  }
  const ReadonlyRole &at(Section section,std::size_t stage,std::string_view suffix) const {
    return at(layer_name(section,stage,suffix));
  }
};
inline Bound bind(std::shared_ptr<const Data> source_data,const c::StorageOwner &owner) {
  if(!source_data||!owner)throw std::runtime_error("original Pro bind needs original data and actual Graph owner");
  Bound result;result.source=std::move(source_data);
  for(const auto &spec:result.source->specs()) {
    if(spec.type==c::DataType::kUInt8)continue;
    result.roles.emplace(spec.name,source::bind(spec.name,result.source->description(spec.name),
        result.source->payload(spec.name),owner));
  }
  return result;
}
// Typed view of the same immutable target leases. Only the role suffixes are
// shared with Flash; every description and payload remains the Pro source's.
inline dspark_original_target_roles::TargetBindings<Data> target_bindings(const Bound &named) {
  namespace target=dspark_original_target_roles;
  if(!named.source)throw std::runtime_error("original Pro target bindings need their source owner");
  target::TargetBindings<Data> result;result.source=named.source;
  for(std::size_t stage=0;stage<target::kStages;++stage)
    for(std::size_t slot=0;slot<target::kRoles;++slot) {
      const auto role=static_cast<target::Role>(slot);
      if(!target::present(stage,role))continue;
      const auto suffix=target::kRawSpecs[target::index(target::raw_role(role))].suffix;
      result.roles[stage][slot]=named.at(Section::kTarget,stage,suffix);
    }
  for(std::size_t slot=0;slot<target::kFinalRoles;++slot) {
    const auto role=static_cast<target::FinalRole>(slot);
    // These top-level final-HC/norm roles are distinct from mtp.2's head.
    result.final[slot]=named.at(target::final_spec(role).suffix);
  }
  return result;
}
} // namespace dspark_pro_original_roles
