#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_target_weights.h"
#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_target_program.h"
#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_target_reference.h"
namespace t=dspark_original_target_weights;
namespace g=dspark_target_geometry;
namespace f=dspark_original_target_fragment;
void instantiate(t::CpuSupply &cpu,t::CudaSupply &gpu,const t::original::Selection &selection,const t::original::Data &source,hyle::compute::Queue &queue){(void)cpu.upload(0,selection,source);(void)gpu.upload(0,0,selection,source,queue);}
void pro_cold_geometry(){(void)f::Plan::make(2173,2184,g::kPro);(void)f::descriptions(4,2184,g::kPro);using hyle::compute::float4_grouped_weight_description;const auto gate=float4_grouped_weight_description(384,3072,7168).value();const auto down=float4_grouped_weight_description(384,7168,3072).value();(void)t::Layout::create({gate,gate,down},6);(void)t::Layout::create({gate,gate,down},30);}
