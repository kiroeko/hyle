#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_target_program.h"
#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_target_reference.h"
#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_draft_program.h"
#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_target_weights.h"
namespace pro=dspark_pro_original_roles;
namespace target=dspark_original_target_program;
namespace draft=dspark_original_draft_program;
namespace weights=dspark_original_target_weights;
void instantiate_pro(const pro::Bound &named,const std::array<pro::ReadonlyRole,3> &oa,
    weights::CpuSupply &cpu,weights::CudaSupply &gpu,const pro::Selection &selection,
    const pro::SourceView &source,hyle::compute::Queue &queue) {
  const auto target_bound=pro::target_bindings(named);
  (void)target::prepare_output_a(target_bound,0x0ca20001,pro::kGeometry,&cpu_c4_model_branches::pro_profile);
  (void)target::build(target_bound,oa,dspark_original_target_fragment::Plan::make(4351,4368,pro::kGeometry),
      0x0ca20100,&cpu_c4_model_branches::pro_profile);
  (void)draft::prepare_output_a(named);
  (void)draft::build(named,oa);
  (void)cpu.upload(0,selection,source);
  (void)gpu.upload(0,0,selection,source,queue);
}
