"""Publish completed Pro CPU/CUDA and affected Flash regression evidence only.

Root invocation, after all four cases pass: python publish.py --runs N [N ...]
Each checksN chooses its actual linked image; failed earlier attempts are retained
as history and are never counted as passing tests. No build/network/body hash pass.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
REPO = 'deepseek-ai/DeepSeek-V4-Pro-0813'
REV = '72e1d3230f6c080a530b0a1d46f8eb4602340597'
PRO = 'OriginalTargetTailAndFormalDraftPublishesBlock5Prefix'
FLASH = 'OriginalTargetTailAndFullVocabularyVerifierPublishesBlock5Prefix'
EXPECTED = {(suite, backend + suffix) for suite, suffix in
            [('DSparkProOriginalState', PRO), ('DSparkOriginalState', FLASH)]
            for backend in ('Cpu', 'Cuda')}
TEXT = {'.h', '.hh', '.hpp', '.c', '.cc', '.cpp', '.py', '.json', '.txt',
        '.log', '.xml', '.ps1', '.diff', '.rsp', '.cmd', '.md'}
ANCHOR = dict(path='docs/evidence/correctness/mtp-dspark-target-verifier-2026-10-23.json',
              bytes=79406, sha256='a175d76b116890529659e462495d8b23a3647f24c4d25c2657fb7d4272e2ac30')
files, hashes = set(), {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def identity(path):
    path = resolve(path)
    assert path.name != 'roles.bin', 'Never hash a weight body in the publisher'
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path),
                bytes=path.stat().st_size, sha256=digest)


def verify(row):
    path = resolve(row['path'])
    if path not in hashes:
        hashes[path] = identity(path)
    assert (hashes[path]['bytes'], hashes[path]['sha256']) == (row['bytes'], row['sha256']), str(path)
    return path


def add(path):
    path = resolve(path)
    assert path.is_relative_to(R) and path.is_file(), str(path)
    assert path.stat().st_size < 10_000_000, str(path)
    assert path.suffix.lower() in TEXT or path.name == 'catalog.bin', str(path)
    assert path.name != 'roles.bin'
    files.add(path)
    return path


def number(props, key):
    value = int(props[key])
    assert value >= 0, (key, value)
    return value


def successful(path):
    result = read(add(path))
    assert result['exit'] == 0 and result.get('terminal', True) and not result.get('timed_out', False), str(path)
    return result


def protect():
    anchor = read(add(verify(ANCHOR)))
    image = anchor['protected_qwen_image']
    verify(image.get('image', image))
    text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    tail = text[text.index('## 最新完整性能对比'):]
    digest = hashlib.sha256(tail.encode('utf-8')).hexdigest()
    assert digest == anchor['latest_full_performance_unchanged']
    return dict(performance_tail_sha256=digest, qwen_image=image, previous_evidence=ANCHOR)


def check_headers(plan):
    if 'header_receipt' in plan:
        add(verify(plan['header_receipt']))
    for shard_number, shard in enumerate(plan['shards']):
        raw = add(verify(shard['header'])).read_bytes()
        assert shard['data_base'] == len(raw) + 8
        header = json.loads(raw)
        assert f'/{REV}/' in shard['url'] and REPO in shard['url']
        for role in plan['roles']:
            if role['source_shard'] != shard_number:
                continue
            actual = header[role['name']]
            assert (actual['dtype'], actual['shape'], actual['data_offsets']) == (
                role['dtype'], role['shape'], role['data_relative_half_open'])
            first, end = actual['data_offsets']
            assert end - first == role['bytes'] > 0
            assert role['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
            assert role['absolute_inclusive'][1] < shard['whole_file_bytes']


def acquisition(directory, count, size):
    """Read metadata and stat bodies; native authenticated the original bodies."""
    receipt_path = add(directory / 'acquisition.json')
    receipt = read(receipt_path)
    assert receipt['complete'] is True
    assert (receipt['repository'], receipt['revision'], receipt['original_roles']) == (REPO, REV, count)
    assert receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == size
    assert receipt['unrequested_bytes'] == 0 and receipt['whole_shards_downloaded'] is False
    plan_path = add(receipt['source_plan'])
    assert identity(plan_path)['sha256'] == receipt['source_plan_sha256']
    plan = read(plan_path)
    assert (plan['repository'], plan['revision'], plan['original_roles'], plan['bundle_bytes']) == (REPO, REV, count, size)
    assert len(plan['roles']) == count and sum(row['bytes'] for row in plan['roles']) == size
    check_headers(plan)
    body = receipt['bundle']
    assert body['bytes'] == size and resolve(body['path']).stat().st_size == size
    assert re.fullmatch('[0-9a-f]{64}', body['sha256'])
    catalog_path, typed_path = add(verify(receipt['catalog'])), add(verify(receipt['typed_catalog']))
    catalog, raw = read(catalog_path), typed_path.read_bytes()
    assert (catalog['repository'], catalog['revision'], catalog['original_roles']) == (REPO, REV, count)
    assert resolve(body['path']) == (directory / catalog['bundle']['file']).resolve()
    assert all(catalog['bundle'][key] == body[key] for key in ('bytes', 'sha256'))
    assert len(catalog['roles']) == count
    magic, version, n, extent, reserved, digest = struct.unpack('<8sIIQQ32s', raw[:64])
    assert (magic, version, n, extent, reserved) == (b'HYDSPT01', 1, count, size, 0)
    assert len(raw) == 64 + 16 * count and digest.hex() == body['sha256']
    spans = []
    for index, (expected, actual) in enumerate(zip(plan['roles'], catalog['roles'])):
        for key in ('index', 'name', 'dtype', 'shape', 'bytes', 'source_shard',
                    'data_relative_half_open', 'absolute_inclusive', 'bundle_offset'):
            assert actual[key] == expected[key], (directory, index, key)
        assert actual['index'] == index and re.fullmatch('[0-9a-f]{64}', actual['sha256'])
        assert struct.unpack_from('<QQ', raw, 64 + 16 * index) == (actual['bundle_offset'], actual['bytes'])
        spans.append((actual['bundle_offset'], actual['bundle_offset'] + actual['bytes']))
    spans.sort()
    assert spans[0][0] == 0 and spans[-1][1] == size
    assert all(first[1] == second[0] for first, second in zip(spans, spans[1:]))
    for request in receipt['requests']:
        if not request.get('complete'):
            continue  # Retried failed requests remain visible in the full receipt.
        assert request['http_status'] == 206 and request['bytes'] == request['requested_bytes']
        assert request['bytes'] == request['last'] - request['first'] + 1
        assert request['content_range'].startswith(f"bytes {request['first']}-{request['last']}/")
    return dict(receipt=identity(receipt_path), plan=identity(plan_path), catalog=identity(catalog_path),
                typed_catalog=identity(typed_path), body=body, roles=count, bytes=size,
                body_rehashed=False, body_archived=False), plan, receipt


def artifacts():
    dense, plan, receipt = acquisition(S / 'original-dense', 216, 6504119672)
    supplier = add(R / 'tests/compute_models/dspark_pro_original_roles.h').read_text(encoding='utf-8-sig')
    pin = re.search(r'kDenseIndexSha256\s*=\s*"([0-9a-f]{64})"', supplier).group(1)
    assert pin == dense['typed_catalog']['sha256']
    assert plan['counts'] == dict(target_static=dict(roles=113, bytes=1246450760),
                                  target_final=dict(roles=4, bytes=473108),
                                  draft_static=dict(roles=97, bytes=1550479644),
                                  vocabulary=dict(roles=2, bytes=3706716160))
    sparse = {}
    for path in sorted((S / 'original-experts').glob('*/stage*/expert*/acquisition.json')):
        row = read(path)
        if row.get('complete') is not True:
            continue
        section, stage, ids = row['section'], row['stage'], row['global_ids']
        assert section in ('target', 'draft') and stage in range(3) and len(ids) == 1 and ids[0] in range(384)
        key = (section, stage, ids[0])
        assert path.parent == S / 'original-experts' / section / f'stage{stage}' / f'expert{ids[0]:03d}'
        item, planned, acquired = acquisition(path.parent, 6, 35094528)
        assert all(planned[k] == acquired[k] == row[k] for k in ('section', 'stage', 'global_ids'))
        prefix = f'layers.{58 + stage}' if section == 'target' else f'mtp.{stage}'
        expected = [f'{prefix}.ffn.experts.{ids[0]}.{leg}.{kind}'
                    for leg in ('w1', 'w3', 'w2') for kind in ('weight', 'scale')]
        assert [role['name'] for role in planned['roles']] == expected
        assert [role['dtype'] for role in planned['roles']] == ['I8', 'F8_E8M0'] * 3
        sparse[key] = dict(section=section, stage=stage, global_id=ids[0], **item)
    assert sparse, 'No authenticated selected expert cache'
    return dict(repository=REPO, revision=REV, hf=f'https://huggingface.co/{REPO}/tree/{REV}',
                dense=dense, dense_partition=plan['counts'], selected_expert_cache=list(sparse.values()),
                selected_cache_scope='Authenticated available cache, including prior failed attempts; not an assertion that every cached expert was executed in each passing case.',
                expert_format='Original I8 packed E2M1 plus original UE8M0 per32 scale bytes. Supply widens only selected scales; no GGUF surrogate or full F32 weight shadow.'), sparse


def linked_image(image):
    path = verify(image)
    assert path.parent.parent == S and re.fullmatch(r'tests-link\d+', path.parent.name)
    folder = path.parent
    assert read(add(folder / 'ready.json'))['image'] == image
    successful(folder / 'link.result.json')
    link = read(add(folder / 'link-plan.json'))
    runtime = read(add(folder / 'runtime-environment.json'))
    assert all(link[key] == 0 for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
    inputs = {verify(row) for row in link['inputs']}
    hosts, records = [], []
    for item in link['compiled_records']:
        source_record = add(verify(item))
        compiled = read(source_record)
        assert verify(compiled['object']) in inputs
        records.append(identity(source_record))
        if not source_record.is_relative_to(S):
            continue
        assert source_record.parent.name in ('dspark-state', 'dspark-pro')
        successful(source_record.with_name('compile.result.json'))
        own_sources = []
        for dependency in [compiled['source'], *compiled['dependencies']]:
            actual = verify(dependency)
            if actual.is_relative_to(R):
                add(actual)
                own_sources.append(dependency)
        hosts.append(dict(record=identity(source_record), source=compiled['source'],
                          object=compiled['object'], current_sources=own_sources))
    assert {item['source']['path'].replace('\\', '/').rsplit('/', 1)[-1] for item in hosts} == {
        'dspark_original_state_consumer_test.cc', 'dspark_pro_mtp_state_consumer_test.cc'}
    for item in runtime['staged_dlls']:
        verify(item)
    return dict(image=image, link_plan=identity(folder / 'link-plan.json'),
                runtime=identity(folder / 'runtime-environment.json'), hosts=hosts,
                compiled_records=records, SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0)


def completed_run(attempt, sparse):
    folder = S / f'checks{attempt}'
    summary = read(add(folder / 'summary.json'))
    process = summary['process']
    assert process['exit'] == 0 and not process['timed_out']
    assert summary['tests'] == len(summary['cases']) > 0
    assert not any(summary[k] for k in ('failures', 'errors', 'disabled', 'skips'))
    assert all(summary.get(k) is False for k in ('throughput_evidence', 'physical_memory_evidence', 'whole_original_model'))
    linked = linked_image(summary['image'])
    command = process['command']
    assert resolve(command[1]) == S / 'run_with_supply.py'
    assert resolve(command[command.index('--image') + 1]) == resolve(summary['image']['path'])
    frontier = resolve(command[command.index('--frontier-file') + 1])
    assert frontier.parent == folder
    driver_path = add(frontier.with_name(frontier.stem + '.driver.json'))
    driver = read(driver_path)
    assert driver['exit'] == driver['native']['exit'] == 0 and not driver['native'].get('stopped_by_driver', False)
    assert driver['native']['pid'] > 0 and driver['driver_pid'] == process['pid']
    assert resolve(driver['native']['command'][0]) == resolve(summary['image']['path'])
    assert driver['native']['command'][1:] == command[command.index('--') + 1:]
    for fetch in driver['fetches']:
        assert fetch['exit'] == 0 and not fetch.get('stopped_by_driver', False)
        request = fetch['request']
        assert set(request['missing_ids']) <= set(request['global_ids'])
        assert all((request['section'], request['stage'], global_id) in sparse for global_id in request['missing_ids'])
    xml_path = add(folder / 'results.xml')
    xml = ET.parse(xml_path).getroot()
    actual = [dict(attributes=case.attrib, properties={p.attrib['name']:p.attrib['value']
              for p in case.iter('property')}) for case in xml.iter('testcase')]
    assert actual == summary['cases'], 'Actual XML and recorded summary differ'
    counts = {}
    for case in actual:
        a, p = case['attributes'], case['properties']
        key = (a['classname'], a['name'])
        assert key in EXPECTED and a['status'] == 'run' and a['result'] == 'completed'
        assert number(p, 'actual_submissions') > 0
        assert number(p, 'state_backing_peak') <= number(p, 'state_backing_budget')
        assert number(p, 'natural_accepted_drafts') <= 5
        if a['classname'] == 'DSparkProOriginalState':
            expected = dict(dense_original_roles=216, dense_original_source_bytes=6504119672,
                            state_members=30, first_target_fullV_values=6*129280,
                            first_draft_fullV_values=5*129280)
            for k, v in expected.items():
                assert number(p, k) == v, (key, k, p.get(k))
            for k in ('actual_draft_episodes', 'actual_target_rows', 'actual_main_projection_submissions',
                      'actual_main_history_submissions', 'actual_verifier_submissions', 'actual_pending_feedback',
                      'target_resident_slot_bytes', 'draft_resident_slot_bytes'):
                assert number(p, k) > 0
            assert number(p, 'actual_expert_attachments') <= len(sparse)
            assert p['controlled_prefixes'] == '0,2,5; prefix policy only, not natural acceptance'
            assert number(p, 'actual_pending_feedback') == number(p, 'actual_draft_episodes')
            assert number(p, 'natural_proposal1') < 129280 and number(p, 'natural_target0') < 129280
        else:
            expected = dict(original_role_count=83, original_role_bytes=13008927644,
                            original_target_roles=4725, original_target_source_bytes=10748569116,
                            target_state_resources=21, complete_state_members=30,
                            target_full_vocabulary_values_checked=6*129280,
                            target_expert_domain=256, target_resident_experts=6, natural_block5_trials=1)
            for k, v in expected.items():
                assert number(p, k) == v, (key, k, p.get(k))
            for k in ('actual_target_rows', 'actual_target_phase_submissions', 'actual_target_verifier_submissions',
                      'actual_main_projection_submissions', 'actual_main_history_catchup_submissions',
                      'actual_pending_embedding_feedback_checks', 'whole_state_publications',
                      'continued_prefix_branches', 'cancelled_unpublished_drafts', 'rejected_stale_publishes'):
                assert number(p, k) > 0
            assert p['target_compression_ratios'] == '4,128,4'
        counts['.'.join(key)] = number(p, 'actual_submissions')
    return dict(summary=identity(folder / 'summary.json'), process=process,
                driver=identity(driver_path), driver_processes=driver,
                cases=actual, graph_submissions_by_case=counts, linked=linked)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=int, nargs='+', required=True)
    args = parser.parse_args()
    assert args.runs == sorted(set(args.runs)) and min(args.runs) > 0
    protected = protect()
    artifact, sparse = artifacts()
    runs = [completed_run(n, sparse) for n in args.runs]
    seen = [(c['attributes']['classname'], c['attributes']['name']) for run in runs for c in run['cases']]
    assert len(seen) == 4 and set(seen) == EXPECTED, 'Require exactly Pro CPU/CUDA and Flash CPU/CUDA, each once'
    graphs = {name: count for run in runs for name, count in run['graph_submissions_by_case'].items()}
    history = []
    for path in sorted(S.glob('checks*/summary.json')):
        item = read(path)
        if path.parent.name in {f'checks{n}' for n in args.runs}:
            continue
        assert 'exit' in item['process'], 'Do not publish while another native attempt is live'
        history.append(dict(summary=identity(add(path)), process=item['process'],
                            passed=item['process']['exit'] == 0 and not item['process']['timed_out'],
                            counted_in_this_publication=False))
    # Small failed attempts, commands and original receipts retain provenance.
    # The strict suffix/size allowlist excludes body/native/SDK files entirely.
    for path in S.rglob('*'):
        # Later Flash formal-source preparation and Qwen BF16 compilation are
        # separate work. They are not provenance for these four native cases.
        if path.is_relative_to(S / 'formal-flash') or any('qwen' in part for part in path.relative_to(S).parts):
            continue
        if path.is_file() and path.suffix.lower() in TEXT and path.name != 'publication.json':
            add(path)
    for path in S.rglob('catalog.bin'):
        if path.is_relative_to(S / 'formal-flash'):
            continue
        add(path)
    assert protect() == protected
    destination = D / 'mtp-dspark-pro-target-verifier-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(files):
            zipped.write(path, path.relative_to(R).as_posix())
    record = dict(date='2026-10-23', stage='CA', goal_complete=False,
        conclusion='Actual original Pro target58/59/60 and formal three-stage draft/full-vocabulary K5 state consumer passed on Windows CPU/CUDA; affected Flash target-tail consumers passed.',
        artifact=artifact,
        implementation=dict(
            target='Distinct original target58/59/60 E4+UE8/A128 and FP4 E2M1+UE8 per32, 4/128/4 compressors, complete21 cache resources, distinct final HC/norm.',
            draft='Original formal mtp.0/1/2 dense, shared BF16 vocabulary/Markov/confidence and actual selected original expert bytes; no reuse of the Flash GGUF Q8/MXFP4 arithmetic as Pro evidence.',
            state='One30-member StateStore/StateHead. Mandatory current plus accepted0..5 selects complete target/cache/main-history tuple and the actual verifier-row I32 lease. Natural once and controlled0/2/5 prefix policies are distinct; pending continuation, cancel/stale publication and immutable readers are checked by the passing consumers.',
            experts='Original384-ID router domain, bounded selected residency. Explicit external artifact acquisition waits retain one native process; body hashes are authenticated by native loaders, not rerun by this publisher. Cache inventory and missing-frontier requests are not per-case executed-ID traces.',
            numerics='Independent original-byte/actual-predecessor local certificates and stored-BF16 interval gates; first full draft646400 and target775680 vocabulary scores, actual stable greedy and pending feedback. No threshold widening or extra reference executor.',
            build='Two related host TUs incrementally compiled against existing product/native/SDK/runtime cache. Each run retains its actual linked image and source/dependency identity; no SDK/CPUworker/NVCC/shader rebuild in CA.'),
        validation=dict(tests=4, failures=0, errors=0, skips=0, graph_submissions=sum(graphs.values()),
                        graph_submissions_by_case=graphs, runs=runs,
                        failed_and_other_attempts=history, failures_are_not_relabelled_success=True),
        limitations=['Layer57 upstream four-stream inputs and initial valid history/cache prefix are explicit finite fixtures. This is not a complete61-layer prompt-to-output model.',
                     'One natural fixture and separately controlled prefix policies do not establish model quality or natural acceptance rate.',
                     'Only actually required sparse original experts are acquired; complete384-expert model weight coverage is not claimed.',
                     'No new loading, prefill/decode/TPS comparison or measured physical memory/VRAM peak. State backing counters are declared-resource accounting.',
                     'No new public executor or operation is introduced and overall MTP completion is not asserted.'],
        protection=protected, archive=identity(archive), archive_items=len(files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert protect() == protected
    print(json.dumps(dict(**publication, tests=4, graphs=record['validation']['graph_submissions'])))


if __name__ == '__main__':
    main()
