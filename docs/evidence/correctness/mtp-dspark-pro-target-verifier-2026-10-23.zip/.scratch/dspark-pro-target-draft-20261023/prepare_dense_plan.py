"""Build exact dense-role ranges; never fetch or reserve whole expert banks."""
from pathlib import Path
import hashlib
import json
import math

S = Path(__file__).resolve().parent
R = S.parents[1]
REPOSITORY = 'deepseek-ai/DeepSeek-V4-Pro-0813'
REVISION = '72e1d3230f6c080a530b0a1d46f8eb4602340597'
SHARDS = (1, 60, 61, 62, 63, 64, 65, 66)
WIDTH = {'I8': 1, 'F8_E4M3': 1, 'F8_E8M0': 1, 'BF16': 2, 'F32': 4}


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    summary = read(S / 'headers/summary.json')
    assert summary['complete'] and summary['repository'] == REPOSITORY
    assert summary['revision'] == REVISION and not summary['whole_shards_downloaded']
    records = {row['file']: row for row in summary['shards']}
    assert set(records) == {f'model-{n:05d}-of-00066.safetensors' for n in SHARDS}
    roles, shards, experts = [], [], []
    for shard, number in enumerate(SHARDS):
        file = f'model-{number:05d}-of-00066.safetensors'
        record = records[file]
        raw = (R / record['header']['path']).read_bytes()
        assert len(raw) == record['header']['bytes']
        assert hashlib.sha256(raw).hexdigest() == record['header']['sha256']
        header = json.loads(raw)
        shards.append({key: record[key] for key in
                       ('file', 'url', 'whole_file_bytes', 'etag', 'data_base', 'header')})
        expert_roles = expert_bytes = 0
        for name, value in header.items():
            if name == '__metadata__':
                continue
            start, end = value['data_offsets']
            extent = math.prod(value['shape']) * WIDTH[value['dtype']]
            assert 0 < extent == end - start
            first = record['data_base'] + start
            assert first + extent <= record['whole_file_bytes']
            if '.experts.' in name:
                expert_roles += 1
                expert_bytes += extent
                continue
            if number == 1:
                assert name == 'embed.weight'
                kind = 'vocabulary'
            elif number == 63:
                assert name in {'hc_head_base', 'hc_head_fn', 'hc_head_scale', 'norm.weight', 'head.weight'}
                kind = 'vocabulary' if name == 'head.weight' else 'target_final'
            elif number < 63:
                assert name.startswith(f'layers.{number - 2}.')
                kind = 'target_static'
            else:
                assert name.startswith(f'mtp.{number - 64}.')
                kind = 'draft_static'
            roles.append(dict(index=len(roles), name=name, kind=kind,
                              dtype=value['dtype'], shape=value['shape'], bytes=extent,
                              source_shard=shard, data_relative_half_open=[start, end],
                              absolute_inclusive=[first, first + extent - 1]))
        if expert_roles:
            assert expert_roles == 384 * 3 * 2
            assert expert_bytes == 13476298752
            experts.append(dict(source_shard=shard, file=file, roles=expert_roles,
                                payload_bytes=expert_bytes, acquired=False,
                                selection='actual global IDs only; absent original bytes must fail',
                                source_prefix=f'layers.{number-2}.' if number < 63 else f'mtp.{number-64}.',
                                domain=384, hidden=7168, intermediate=3072,
                                source_format='I8 adjacent E2M1 code pairs plus separate UE8M0 group32 scale bytes'))
    counts = {kind: dict(roles=sum(row['kind'] == kind for row in roles),
                        bytes=sum(row['bytes'] for row in roles if row['kind'] == kind))
              for kind in ('target_static', 'target_final', 'draft_static', 'vocabulary')}
    assert counts == {'target_static': {'roles': 113, 'bytes': 1246450760},
                      'target_final': {'roles': 4, 'bytes': 473108},
                      'draft_static': {'roles': 97, 'bytes': 1550479644},
                      'vocabulary': {'roles': 2, 'bytes': 3706716160}}
    groups, offset = [], 0
    for shard in range(len(shards)):
        previous = None
        selected = sorted((row for row in roles if row['source_shard'] == shard),
                          key=lambda row: row['absolute_inclusive'][0])
        for row in selected:
            first, last = row['absolute_inclusive']
            if previous is None or first != previous['last'] + 1:
                previous = dict(index=len(groups), source_shard=shard, first=first, last=last,
                                bundle_offset=offset, bytes=row['bytes'])
                groups.append(previous)
            else:
                previous['last'] = last
                previous['bytes'] += row['bytes']
            row['bundle_offset'] = offset
            offset += row['bytes']
    assert len(roles) == 216 and offset == 6504119672
    # Exact concatenation only: no gap padding, unselected expert or whole shard.
    ordered = sorted(roles, key=lambda row: row['bundle_offset'])
    assert all(row['bundle_offset'] == sum(x['bytes'] for x in ordered[:i])
               for i, row in enumerate(ordered))
    plan = dict(repository=REPOSITORY, revision=REVISION, original_roles=len(roles),
                bundle_bytes=offset, whole_shards_downloaded=False,
                expert_payloads_included=False, counts=counts,
                shards=shards, roles=roles, groups=groups,
                deferred_experts=experts,
                scope='Dense target58/59/60 plus distinct final HC/norm, actual mtp0/1/2 and two untied vocabulary banks. Source acquisition plan only; no execution claim.')
    (S / 'dense-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(roles=len(roles), bytes=offset, groups=len(groups), counts=counts)), flush=True)


if __name__ == '__main__':
    main()
