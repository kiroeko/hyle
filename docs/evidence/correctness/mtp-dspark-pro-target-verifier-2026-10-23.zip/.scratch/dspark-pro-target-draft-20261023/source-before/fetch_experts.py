"""Fetch only actual Pro router-frontier experts; --plan-only never uses the network.

Each immutable cache directory contains one expert's six original code/SF roles.
The runtime explicitly attaches each completed catalog pin; this script does not
load models, select experts, execute Graphs, or infer missing IDs from a fixture.
"""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import struct
import sys

import fetch_dense

S = Path(__file__).resolve().parent
R = S.parents[1]
REPOSITORY = 'deepseek-ai/DeepSeek-V4-Pro-0813'
REVISION = '72e1d3230f6c080a530b0a1d46f8eb4602340597'
ROLE_COUNT, EXPERT_BYTES, DOMAIN = 6, 35094528, 384


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def emit(event, **fields):
    print(json.dumps(dict(event=event, **fields), separators=(',', ':')), flush=True)


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def fixed_headers():
    summary_path = S / 'headers' / 'summary.json'
    summary = read(summary_path)
    if (summary.get('repository') != REPOSITORY or summary.get('revision') != REVISION
            or summary.get('complete') is not True or summary.get('whole_shards_downloaded') is not False
            or len(summary.get('shards', [])) != 8):
        raise ValueError('Expected the complete fixed eight-header Pro receipt')
    result = {}
    for shard in summary['shards']:
        if (shard.get('repository') != REPOSITORY or shard.get('revision') != REVISION
                or shard.get('complete') is not True or shard.get('whole_shard_downloaded') is not False):
            raise ValueError('Cached shard identity differs from the fixed Pro receipt')
        proof = shard['header']
        header_path = R / proof['path']
        raw = header_path.read_bytes()
        if len(raw) != proof['bytes'] or hashlib.sha256(raw).hexdigest() != proof['sha256']:
            raise ValueError('Cached header authentication failed: ' + str(header_path))
        if shard['data_base'] != 8 + len(raw) or not shard['etag']:
            raise ValueError('Invalid cached data base or ETag')
        expected_url = f'https://huggingface.co/{REPOSITORY}/resolve/{REVISION}/{shard["file"]}'
        if shard['url'] != expected_url or shard['file'] in result:
            raise ValueError('Unexpected or duplicate cached shard URL')
        result[shard['file']] = (shard, json.loads(raw))
    return result, identity(summary_path)


def make_plan(headers, summary_identity, section, stage, global_id):
    shard_number = (60 if section == 'target' else 64) + stage
    file = f'model-{shard_number:05d}-of-00066.safetensors'
    cached, header = headers[file]
    shard = {key: cached[key] for key in ('file', 'url', 'whole_file_bytes', 'etag', 'data_base', 'header')}
    prefix = f'layers.{58 + stage}' if section == 'target' else f'mtp.{stage}'
    rows, groups, offset = [], [], 0
    for leg in ('w1', 'w3', 'w2'):
        n, k = (7168, 3072) if leg == 'w2' else (3072, 7168)
        for scales in (False, True):
            name = f'{prefix}.ffn.experts.{global_id}.{leg}.{"scale" if scales else "weight"}'
            actual = header[name]
            dtype, shape = ('F8_E8M0', [n, k // 32]) if scales else ('I8', [n, k // 2])
            extent = n * shape[1]
            if actual['dtype'] != dtype or actual['shape'] != shape:
                raise ValueError('Original expert dtype/shape differs: ' + name)
            first_relative, end_relative = actual['data_offsets']
            if (type(first_relative) is not int or type(end_relative) is not int
                    or first_relative < 0 or end_relative - first_relative != extent):
                raise ValueError('Invalid original expert byte range: ' + name)
            first = cached['data_base'] + first_relative
            last = first + extent - 1
            if last >= cached['whole_file_bytes']:
                raise ValueError('Original expert range exceeds authenticated shard: ' + name)
            ordinal = len(rows)
            rows.append(dict(index=ordinal, name=name, kind='selected_original_expert',
                             section=section, stage=stage, global_id=global_id,
                             dtype=dtype, shape=shape, bytes=extent, source_shard=0,
                             data_relative_half_open=[first_relative, end_relative],
                             absolute_inclusive=[first, last], bundle_offset=offset))
            # Never merge across an unrequested gap, even when one shard owns all roles.
            groups.append(dict(index=ordinal, source_shard=0, first=first, last=last,
                               bundle_offset=offset, bytes=extent))
            offset += extent
    if len(rows) != ROLE_COUNT or offset != EXPERT_BYTES:
        raise ValueError('Single-expert six-role byte extent differs')
    source_ranges = sorted(row['data_relative_half_open'] for row in rows)
    if any(a[1] > b[0] for a, b in zip(source_ranges, source_ranges[1:])):
        raise ValueError('Original expert roles overlap in the authenticated header')
    return dict(repository=REPOSITORY, revision=REVISION, section=section, stage=stage,
                global_ids=[global_id], original_roles=ROLE_COUNT, bundle_bytes=EXPERT_BYTES,
                whole_shards_downloaded=False, unrequested_bytes=0,
                expert_payloads_included=True, header_receipt=summary_identity,
                typed_order='one global ID: w1.weight,w1.scale,w3.weight,w3.scale,w2.weight,w2.scale',
                format='original I8 packed E2M1 nibbles and F8_E8M0 per32 scale bytes; no conversion',
                shards=[shard], roles=rows, groups=groups)


def retain_plan(path, plan):
    if path.exists():
        if read(path) != plan:
            raise ValueError('Existing expert plan has another identity: ' + str(path))
        return
    temporary = path.with_name(f'.plan.{os.getpid()}.next')
    temporary.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    os.replace(temporary, path)


@contextmanager
def cache_lock(directory):
    # OS-owned byte lock releases on process termination; a stale lockfile does
    # not prevent resuming an interrupted download. It owns no payload bytes.
    with (directory / '.fetch.lock').open('a+b') as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b'\0')
            stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def selection(args):
    if args.frontier_file is not None:
        if args.section is not None or args.stage is not None or args.ids is not None:
            raise ValueError('--frontier-file cannot be combined with --section/--stage/--ids')
        frontier = read(args.frontier_file)
        section, stage, ids = frontier['section'], frontier['stage'], frontier['missing_ids']
    else:
        section, stage, ids = args.section, args.stage, args.ids
    if section not in ('target', 'draft') or type(stage) is not int or not 0 <= stage < 3:
        raise ValueError('A frontier requires section target|draft and stage0..2')
    if not isinstance(ids, list) or any(type(value) is not int or not 0 <= value < DOMAIN for value in ids):
        raise ValueError('Expert IDs must be integer global IDs in0..383')
    return section, stage, sorted(set(ids))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--section', choices=('target', 'draft'))
    parser.add_argument('--stage', type=int, choices=range(3))
    parser.add_argument('--ids', type=int, nargs='+')
    parser.add_argument('--frontier-file', type=Path)
    parser.add_argument('--plan-only', action='store_true', help='Validate fixed metadata and write plans; no network or bundle allocation')
    args = parser.parse_args()
    section, stage, ids = selection(args)
    headers, proof = fixed_headers()
    fetch_dense.COUNT, fetch_dense.BODY_BYTES = ROLE_COUNT, EXPERT_BYTES
    completed = []
    for global_id in ids:
        directory = S / 'original-experts' / section / f'stage{stage}' / f'expert{global_id:03d}'
        directory.mkdir(parents=True, exist_ok=True)
        plan_path = directory / 'plan.json'
        plan = make_plan(headers, proof, section, stage, global_id)
        with cache_lock(directory):
            retain_plan(plan_path, plan)
            common = dict(section=section, stage=stage, global_ids=[global_id],
                          directory=directory.relative_to(R).as_posix(),
                          plan=identity(plan_path), original_roles=ROLE_COUNT, bundle_bytes=EXPERT_BYTES)
            if args.plan_only:
                item = dict(**common, complete=False, plan_only=True, network_used=False)
                emit('expert_cache_planned', **item)
            else:
                reused = (directory / 'acquisition.json').exists() and read(directory / 'acquisition.json').get('complete') is True
                record = fetch_dense.main(plan_path=plan_path, out=directory)
                if record.get('complete') is not True:
                    raise RuntimeError('Acquisition returned without a complete authenticated expert cache')
                typed = (directory / 'catalog.bin').read_bytes()
                magic, version, count, size, reserved, body_sha = struct.unpack('<8sIIQQ32s', typed[:64])
                if (magic != b'HYDSPT01' or version != 1 or count != ROLE_COUNT
                        or size != EXPERT_BYTES or reserved != 0 or len(typed) != 64 + 16 * ROLE_COUNT
                        or body_sha.hex() != record['bundle']['sha256']):
                    raise ValueError('Completed typed catalog does not match ExpertSet single-ID contract')
                item = dict(**common, complete=True, plan_only=False, reused=reused,
                            repository=REPOSITORY, revision=REVISION,
                            catalog_sha256=record['typed_catalog']['sha256'],
                            typed_catalog=record['typed_catalog'], acquisition=identity(directory / 'acquisition.json'),
                            bundle_sha256=record['bundle']['sha256'])
                emit('expert_cache_complete', **item)
            completed.append(item)
    emit('expert_frontier_planned' if args.plan_only else 'expert_frontier_complete',
         section=section, stage=stage, global_ids=ids, caches=completed,
         complete=not args.plan_only, plan_only=args.plan_only,
         original_roles=len(ids) * ROLE_COUNT, bundle_bytes=len(ids) * EXPERT_BYTES)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(json.dumps(dict(event='expert_cache_error', type=type(error).__name__, error=str(error))), file=sys.stderr, flush=True)
        raise
