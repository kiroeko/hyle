"""Preserve the view-parent correction and actual safe red/green evidence."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def identity(p):
    data = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def main():
    final = read(S/'final-validation.json')
    assert final['status'] == 'passed_scope_only'
    for directory, count, failed in [('reproduction-final', 3, 3), ('checks', 5, 0)]:
        cases = ET.parse(S/directory/'tests.xml').findall('.//testcase')
        assert len(cases) == count
        assert sum(bool(c.findall('failure')) for c in cases) == failed
        assert not any(c.findall('skipped') for c in cases)
    for row in read(S/'source-freeze.json')['files']:
        proof = identity(ROOT/row['path'])
        assert proof['bytes'] == row['bytes'] and proof['sha256'] == row['sha256']
    for row in read(S/'checks/link-plan.json')['inputs']:
        assert identity(Path(row['path'])) == row, row['path']
    docs = ['docs/architecture/compute-design.md', 'docs/developer/current-work.md']
    for rel in docs:
        p = S/'snapshot'/rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((ROOT/rel).read_bytes())
    files = sorted((p for p in S.rglob('*') if p.is_file() and
        p.suffix in {'.cc','.h','.py','.json','.log','.xml','.diff','.md'} and
        not set(p.relative_to(S).parts) & {'tmp','__pycache__'} and
        p.name not in {'publication.json','payload-sha256.json'}),
        key=lambda p: p.relative_to(S).as_posix())
    dest = ROOT/'docs/evidence/correctness/vulkan-view-root-owner-2026-10-20.zip'
    payloads = []
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            row = dict(**identity(path), member=path.relative_to(S).as_posix())
            archive.writestr(row['member'], path.read_bytes())
            payloads.append(row)
        archive.writestr('payload-sha256.json', json.dumps(payloads).encode())
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        assert all(hashlib.sha256(archive.read(row['member'])).hexdigest() == row['sha256'] for row in payloads)
    report = dict(date='2026-10-20', status='executed',
        problem='Four native is_view buffers stored opaque permission owners where the existing storage report expects a typed Buffer parent; following them can read the wrong object type.',
        fix='Aliasing shared_ptr retains the existing lease/page/weight control block while exposing the original Buffer parent pointer. No payload, permissions, reference-count policy or object layout changed.',
        scope=['MemoryAccess::lease_tensor', 'paged_binding template', 'WeightAccess::binding', 'WeightBatch::binding'],
        actual=final, source_freeze=identity(S/'source-freeze.json'),
        independent_review=identity(S/'independent-review.json'),
        limits=final['limits'],
        archive=dict(**identity(dest), payloads=len(payloads), CRC_checked=True, all_payload_SHA256_checked=True))
    save(dest.with_suffix('.json'), report)
    save(S/'publication.json', dict(passed=True, report=identity(dest.with_suffix('.json')), archive=identity(dest)))
    print('VIEW_OWNER_EVIDENCE_PUBLISHED', len(payloads), dest.stat().st_size, flush=True)


if __name__ == '__main__':
    main()
