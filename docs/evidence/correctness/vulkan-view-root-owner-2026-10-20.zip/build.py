from pathlib import Path
import importlib.util,sys,json,hashlib,os
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1];mode=sys.argv[1];out=S/mode;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('owner_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'mlx-moe-typed-inputs/vulkan/checks/link-plan.json';base=c.read(basepath);metadata=h.metadata({'vulkan':base})
for row in base['inputs']:assert h.same_identity(row),row['path']
source=ROOT/'tests/graph_route_vulkan/weight_binding_test.cc'
original=next(r for r in c.read(A/'vulkan-weight-input/commands.json')if r['tag']=='weight-test-compile')
env,runtime=b.environment(base['command'],[r['path']for r in base['inputs']],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
def compile_one(source,template,tag,recipe):
 command=b.host_command(template,source,tag,out);before=b.identity(source);c.save(out/(tag+'-plan.json'),dict(source=before,command=command,recipe=recipe));c.execute(tag+'-compile',command,env,out);assert h.same_identity(before)
 dep=out/(tag+'-deps.json');d=c.read(dep)['Data'];r=dict(source=before,command=command,object=b.identity(out/(tag+'.obj')),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=recipe);c.save(out/(tag+'-identity.json'),r);return r
if mode.startswith('reproduction'):test=compile_one(source,original['command'],'weight-test',str(A/'vulkan-weight-input/commands.json'))
else:
 test=c.read(S/'reproduction-final/weight-test-identity.json');assert h.same_identity(test['source'])and h.same_identity(test['object'])and all(h.same_identity(d)for d in test['dependencies'])
replacements={};products=[]
if not mode.startswith('reproduction'):
 for obj in base['inputs']:
  rec=metadata.get(c.key(obj['path']))
  if rec and Path(rec['source_path']).name in ['vulkan_memory.cc','vulkan_weights.cc']:
   r=compile_one(Path(rec['source_path']),rec['command'],Path(rec['source_path']).stem,rec['recipe']);replacements[c.key(obj['path'])]=r['object'];products.append(r)
 assert len(products)==2
command=[replacements.get(c.key(arg),dict(path=arg))['path']for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
# The retained base has no weight_binding_test owner.
assert not any(c.key(rec['source_path'])==c.key(source)for rec in metadata.values())
command.append(test['object']['path']);image=out/'vulkan.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
lookup={c.key(r['path']):r for r in [*base['inputs'],test['object'],*replacements.values()]};inputs=[lookup[c.key(arg)]for arg in command if Path(arg).is_absolute()and Path(arg).suffix.lower()in('.obj','.lib')]
for row in inputs:assert h.same_identity(row)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath)));c.execute('vulkan-link',command,env,out);c.save(out/'image.json',b.identity(image));c.save(out/'host-summary.json',dict(CXX=len(products)+mode.startswith('reproduction'),links=1,new_SDK=0,source=b.identity(source),products=[r['source']for r in products],image=b.identity(image)))
filter='VulkanWeightBinding.LeaseViewExposesBufferParentAndKeepsOriginalLease:VulkanWeightBinding.PagedViewExposesBufferParentAndRetainsExactPage:VulkanWeightBinding.WeightViewsExposeBufferParentAndRetainSelection'if mode.startswith('reproduction')else'VulkanWeightBinding.*'
cmd=[str(image),'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')]
try:c.execute('tests',cmd,env,out)
except Exception as e:
 if not mode.startswith('reproduction'):raise
 print('OLD_RED_PRESERVED',repr(e),flush=True)
print('FINISHED',mode,flush=True)
