from pathlib import Path
p=Path('docs/developer/current-work.md');s=p.read_text(encoding='utf-8')
a=s.index('**当前正在做：');b=s.index('\n当前每进程',a)
s=s[:a]+'**当前正在做：CUDA单会话K1 MTP已接通真实prefill、同图草拟→验证及完整状态提交，继续补取消／质量与可比性能。** [本批实跑](../evidence/correctness/qwen-mtp-round-2026-10-22.json)覆盖自然接受、拒绝、lag1追赶、旧快照分支、quota1 T1及EOS；普通无MTP的90份向量仍逐字节同原基线。其它系统原生路径、已选模型完整覆盖和图片范围保持。普通双路decode最近完整窗口仍168.15对186.50tok/s，本批不是完整性能对照。'+s[b:]
a=s.index('| 3 | MTP真实消费者');b=s.index('\n| 4 |',a)
s=s[:a]+'| 3 | MTP真实消费者 | **CUDA单会话K1已接通并实跑，整体未完成**。[真实335权重、同图prefill／draft→verify及14份KV事务](../evidence/correctness/qwen-mtp-round-2026-10-22.json)覆盖自然接受／拒绝、追赶、旧前缀分支、quota1和EOS。完整MTP的原生取消／故障、数值质量、multi-session入口及性能仍待处理；普通peer GGUF为no-mtp，须另备可比MTP制品 |'+s[b:]
a=s.index('- **MTP**：');b=s.index('\n- **图片投影**',a)
s=s[:a]+'- **MTP**：本地15个`mtp.*`张量与320个目标张量共用加载器；测试CLI的`--mtp on`现可执行CUDA单会话greedy K1。目标T2与草拟缓存沿同一次Graph／Completion，接受选择后一次发布完整快照；多会话入口、质量、取消故障及可比性能仍未完成。'+s[b:]
a=s.index('MTP本批实际进展见');b=s.index('\n## 架构审查',a)
s=s[:a]+'''MTP当前实际结果见[完整轮次证据](../evidence/correctness/qwen-mtp-round-2026-10-22.json)，单层数学和指定接受边界的[前批证据](../evidence/correctness/qwen-mtp-target-2026-10-22.json)保留：

- Snapshot增加独立draft K/V、frontier、lag、catch-up token及owned target carry／prior；14份KV arena、N＋2R份候选状态和2(N＋R)份hidden均显式计费。草拟prefill只算所需K/V，不执行无用attention／FFN。
- 普通Graph现支持没有attention读者的真实分页写effect，仍走原页权限、Queue、Completion和whole-Graph成功门。原CPU回归及无MTP的90份向量结果随证据保留。
- 真实首15个prompt ID的有限流中，自然accept2后target17／draft16、lag1；追赶再拒绝后两者18、lag0。旧head重新分支得到同样T2输出；quota1用T1并维护完整draft。另一个完整23token prompt遇EOS仅提交1行。这里只得到2个自然轮次，不能据此推普遍接受率。
- T1与T2行0保留真实数值差异，不能因greedy相同签质量。探针的capture已实际录制，尚未证明本批热复用或MTP提速。

下一批检查14份写事务的原生取消／失败退休，再核独立完整MTP参考与同权重peer制品，按prefill、decode、显存与总速度做完整对照。multi-session MTP与其它系统原生消费者、图片仍保留为必要实现；本批不重复普通TopK1完整性能窗。
'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/developer/performance/decode.md');s=p.read_text(encoding='utf-8');s=s.replace('真实15个MTP权重、单层图及target接受边界已执行，完整同图draft／verify／组合状态仍待接入，不为追逐TPS重复当前窗口。','真实335权重、prefill、同图draft／verify及完整状态已在CUDA实跑自然接受／拒绝和追赶，见[本批证据](../../evidence/correctness/qwen-mtp-round-2026-10-22.json)。MTP质量、原生取消与可比peer性能仍待处理；不为追逐TPS重复当前普通窗口。');p.write_text(s,encoding='utf-8',newline='\n')
