from pathlib import Path
import json,hashlib
R=Path.cwd();S=R/'.scratch/qwen-mtp-round-20261022'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
ready=read(S/'qwen-ready-attempt4.json');terminal=read(S/'cli-run3/run.result.json');identity=read(S/'cli-run3/identity.json');v=read(S/'cli-run3/run.stdout.log')
assert terminal['exit']==0 and terminal['terminal'] is True
assert identity['image']==ready['image'] and identity['main']==ready['main']
assert terminal['command'][0]==ready['image']['path']
a=terminal['command'];inputdir=Path(a[a.index('--inputs')+1]);prompt=[int(x) for x in (inputdir/'prompt.ids').read_text().split()]
prefill=read(S/'cli-run3/trace/prefill/kv-layout.json');assert len(prompt)==prefill['visible_tokens']==23
assert v['mtp'] is True and (v['text_tensors'],v['mtp_tensors'])==(320,15)
assert v['generated_ids']==[20,248046] and v['generated_decode_tokens']==1
assert len(v['rounds'])==1
b=v['rounds'][0]
assert b=={'pending':20,'draft':248046,'target_first':248046,'target_second':198,'accepted_draft':False,'committed_target_rows':1,'draft_rows':1}
assert v['agreements']==1 and v['accepted_drafts']==0
assert v['visible_tokens']==23+b['committed_target_rows']==24
assert v['draft_frontier']==23+b['draft_rows']==24 and v['draft_lag']==0
assert v['verified_target_rows']==2 and v['draft_rounds']==1 and v['draft_rows']==1
stderr=(S/'cli-run3/run.stderr.log').read_text();assert 'prepared T=2 visible=24' in stderr and 'next=248046' in stderr
report={'status':'PASS finite actual CLI EOS agreement commit-boundary check','run':'cli-run3','ready':'qwen-ready-attempt4.json','image':ready['image'],'main':ready['main'],'native_exit':0,'prompt_rows':23,'generated_ids':v['generated_ids'],'actual_round':b,'verified_target_rows':2,'committed_target_rows':1,'final_target_length':24,'final_draft_frontier':24,'final_lag':0,'EOS_id':248046,'scope':['Actual trained proposal and target row0 agree on EOS. EOS suppresses a2, so only one target row is committed; target and draft both end at24.','Only this EOS-agreement case ran here. Natural agreement1/1 and accepted_drafts0 are observations, not acceptance-rate or quality validation.','T2 verified two rows but its second candidate198 is not emitted or committed.','Post-round fields derive from actual exit0 JSON plus original stderr; physical postprocess owners are not available for offline reinspection.'],'activity':{'GPU_runs':0,'builds':0,'product_edits':0}}
o=S/'review/cli-eos-review.json';o.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({'report':str(o.relative_to(R)),'final_target_length':24,'draft_frontier':24,'committed_rows':1,'sha256':hashlib.sha256(o.read_bytes()).hexdigest()}))
