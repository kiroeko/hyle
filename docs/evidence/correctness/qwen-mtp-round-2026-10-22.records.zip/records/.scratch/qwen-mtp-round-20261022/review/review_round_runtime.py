"""Offline ledger/vector review of the one recorded real MTP round probe."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


STAGE = Path(__file__).resolve().parents[1]


def unique_object(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=unique_object)


def identity(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while data := stream.read(1024 * 1024):
            digest.update(data)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest.hexdigest())


def decode(data, bf16):
    if bf16:
        return (np.frombuffer(data, "<u2").astype(np.uint32) << 16).view(np.float32).astype(np.float64)
    return np.frombuffer(data, "<f4").astype(np.float64)


def comparison(a, r, bf16):
    av, rv = decode(a, bf16), decode(r, bf16)
    assert av.shape == rv.shape and np.isfinite(av).all() and np.isfinite(rv).all()
    delta, an, rn = av - rv, np.linalg.norm(av), np.linalg.norm(rv)
    return dict(elements=int(av.size), byte_equal=a == r,
                different_numeric_elements=int(np.count_nonzero(av != rv)),
                all_finite=True, max_absolute_error=float(np.abs(delta).max()),
                relative_l2=float(np.linalg.norm(delta) / rn) if rn else None,
                cosine=float(np.dot(av, rv) / (an * rn)) if an and rn else None)


def main():
    run = STAGE / "round-run1"
    output = STAGE / "round-output1"
    trace = output / "trace"
    ready_path = STAGE / "round-ready-attempt1.json"
    ready = load(ready_path)
    terminal_path = run / "run.result.json"
    terminal = load(terminal_path)
    stdout = load(run / "run.stdout.log")
    observation_path = output / "observation.json"
    observation = load(observation_path)
    record_path = STAGE / "compile1/round/identity.json"
    record = load(record_path)
    assert terminal["terminal"] and terminal["exit"] == 0
    assert Path(terminal["command"][0]).resolve() == Path(ready["image"]["path"]).resolve()
    assert Path(terminal["command"][2]).resolve() == output.resolve()
    assert Path(terminal["command"][1]).resolve() == Path(observation["inputs"]).resolve()
    assert observation["error"] == "" and observation["status"].startswith("COMPLETE")
    assert record["main"] == ready["main"] and identity(Path(record["source"]["path"])) == record["source"]
    assert identity(Path(ready["main"]["path"])) == ready["main"]
    linked = load(Path(ready["link_plan"]["path"]))
    assert any(row == record["object"] for row in linked["inputs"])
    assert identity(Path(ready["link_plan"]["path"])) == ready["link_plan"]
    assert any(row == identity(record_path) for row in linked["compiled_records"])
    image_path = Path(ready["image"]["path"])
    image_rehashed = image_path.exists()
    if image_rehashed:
        assert identity(image_path) == ready["image"]
    frozen_probe = load(STAGE / "review/round-probe-source-freeze.json")
    assert frozen_probe["source"] == record["source"]

    events = observation["events"]
    assert [e["name"] for e in events] == ["prefill15", "natural0", "natural1", "fork_catchup_round", "quota1_catchup", "quota1_single"]
    assert observation["capacity"] == 64 and observation["resident_snapshot_limit"] == 8
    assert observation["active_sequences"] == 1 and observation["single_original_Model"]
    assert observation["loaded_weight_tensors"] == 335 and not observation["injected_lag1_seed"]
    assert not any(e["injected_boundary"] for e in events)
    assert observation["prompt_ids"] == [int(v) for v in (Path(observation["inputs"]) / "prompt.ids").read_text().split()][:15]
    cache_bytes = (33 * 16 * 1024 + 1) * 14 + (18 * (3 * 6144 * 2 + 16 * 128 * 128 * 4)) * 10 + 36 + 18 * 4096 + 1
    assert cache_bytes == 203022387
    rows, raw, data = [], [], {}
    for e in events:
        name, count = e["name"], 2 if e["target_query_rows"] == 2 else 1
        assert e["length"] == e["base_length"] + e["committed_target_rows"]
        assert e["draft_frontier"] == e["old_draft_frontier"] + e["draft_query_rows"]
        assert e["processed_draft_rows"] == e["draft_query_rows"]
        assert e["lag"] in (0, 1) and e["draft_frontier"] == e["length"] - e["lag"]
        assert e["next_id"] == e["emitted"][-1]
        assert e["snapshot_versions_candidate"] == e["snapshot_versions_before"] + 1
        assert e["snapshot_versions_after"] <= 9 and e["managed_cache_live_bytes"] == cache_bytes
        assert e["old_head_stable_during_prepare"] and e["old_snapshot_all_bytes_unchanged"]
        assert len(e["target_pages"]) == (e["length"] + 15) // 16
        assert len(e["draft_pages"]) == (e["draft_frontier"] + 15) // 16
        if name != "prefill15":
            assert len(e["emitted"]) == e["committed_target_rows"]
            assert e["pending"] >= 0
            if e["accepted_draft"]:
                assert e["agreed"] and e["draft"] == e["target_first"]
                assert e["emitted"] == [e["draft"], e["target_second"]] and e["lag"] == 1
            else:
                assert e["emitted"] == [e["target_first"]] and e["lag"] == 0
        directory = trace / name
        hidden = (directory / "all-hidden.bf16").read_bytes()
        logits = (directory / "all-logits.f32").read_bytes()
        carry = (directory / "carry.bf16").read_bytes()
        ids_bytes = (directory / "target-ids.i32").read_bytes()
        ids = np.frombuffer(ids_bytes, "<i4")
        assert len(hidden) == count * 4096 and len(logits) == count * 248320 * 4
        assert len(ids) == count and len(carry) == 4096
        assert np.isfinite(decode(hidden, True)).all() and np.isfinite(decode(logits, False)).all()
        logits_rows = np.frombuffer(logits, "<f4").reshape(count, 248320)
        assert np.array_equal(np.argmax(logits_rows, axis=1), ids)
        assert int(ids[0]) == e["target_first"]
        if count == 2:
            assert int(ids[1]) == e["target_second"]
        selected = e["committed_target_rows"] - 1 if count == 2 else 0
        assert carry == hidden[selected * 4096:(selected + 1) * 4096]
        assert e["next_id"] == int(ids[selected])
        prior_path = directory / "prior.bf16"
        if e["lag"]:
            assert e["catchup_token"] == e["draft"] and prior_path.read_bytes() == hidden[:4096]
        else:
            assert e["catchup_token"] == -1 and not prior_path.exists()
        for p in sorted(directory.iterdir()):
            raw.append(identity(p))
        data[name] = dict(hidden=hidden, logits=logits, carry=carry, ids=ids_bytes)
        rows.append({k: e[k] for k in ("name", "role", "base_length", "old_draft_frontier", "target_query_rows", "draft_query_rows", "committed_target_rows", "length", "draft_frontier", "lag", "pending", "draft", "target_first", "target_second", "next_id", "emitted", "capture_recorded", "capture_reused", "target_pages", "draft_pages")})
    sums = {"actual_graph_calls": len(events), "target_query_rows": sum(e["target_query_rows"] for e in events),
            "draft_written_rows": sum(e["draft_query_rows"] for e in events),
            "committed_target_rows": sum(e["committed_target_rows"] for e in events)}
    assert all(observation[k] == v for k, v in sums.items()) and stdout["actual_graph_calls"] == len(events)
    natural = [e for e in events if e["stream"] == "natural"]
    assert len(natural) == 2 and sum(e["accepted_draft"] for e in natural) == 1
    same = []
    for k in ("hidden", "logits", "carry", "ids"):
        a, b = data["natural1"][k], data["fork_catchup_round"][k]
        assert a == b
        same.append(dict(boundary=k, bytes=len(a), byte_equal=True))
    mismatch = []
    for k, bf in (("hidden", True), ("logits", False)):
        a, b = data["quota1_catchup"][k], data["natural1"][k]
        mismatch.append(dict(boundary=k, reference_selection="natural1 T2 row0", **comparison(a, b[:len(b) // 2], bf)))
    assert data["quota1_catchup"]["ids"] == data["natural1"]["ids"][:4]
    report = dict(
        status="Recorded finite round journey and offline ledgers/raw comparisons verified; no quality threshold assigned",
        identities=dict(terminal=identity(terminal_path), ready=identity(ready_path), image=ready["image"],
                        actual_image_rehashed=image_rehashed, compile_record=identity(record_path),
                        probe_source=record["source"], compiled_main=ready["main"],
                        observation=identity(observation_path), checker=identity(Path(__file__))),
        source_and_terminal=dict(exit=0, original_probe_source_matches_freeze=True,
                                 compiled_main_matches_observed_current=True, linked_object_matches_compile_record=True),
        ledger=dict(**sums, all_event_arithmetic_verified=True, duplicate_JSON_keys=False,
                    cache_live_bytes=cache_bytes, cache_bytes_scope="managed cache backings, not total GPU or driver memory",
                    peak_observed_committed_or_retained_versions=max(e["snapshot_versions_after"] for e in events),
                    peak_observed_candidate_versions=max(e["snapshot_versions_candidate"] for e in events),
                    all_versions_within_N_plus_R9=True, note="Row/commit sums include independent forks, not one Session final length."),
        capture=dict(recorded_ranges=sum(e["capture_recorded"] for e in events),
                     reused_ranges=sum(e["capture_reused"] for e in events),
                     scope="Actual per-prepare host replay-report counts; no native GraphLaunch count or hot-capture reuse proof. Prefill is commands; each exercised role/slot is cold in this finite journey."),
        natural=dict(rounds=2, agreed_drafts=1, accepted_drafts=1, rejected_drafts=1,
                     injected_boundaries=0, main_stream_generated_ids=[v for e in events if e["stream"] in ("prefill", "natural") for v in e["emitted"]],
                     limitation="Only these two actual rounds; do not describe a generally applicable50% acceptance rate."),
        events=rows,
        finite_and_carry=dict(all_published_BF16_hidden_and_F32_logits_finite=True,
                              all_IDs_equal_own_first_argmax=True, all_carry_bytes_equal_actual_selected_row=True,
                              lag1_prior_equals_actual_row0=True, all_old_snapshot_preservation_assertions=True,
                              actual_owned_disjoint_carry_assertions_passed=True,
                              provenance="Ownership/disjointness and old device page/state preservation are actual compiled probe assertions verified by exit0; offline raw independently verifies row bytes and finiteness, not device allocation ownership."),
        same_complete_prefix_fork=dict(reference="natural1", actual="fork_catchup_round", boundaries=same,
                                       logical_inputs_and_lengths_equal=True,
                                       actual_target_physical_pages_differ=events[2]["target_pages"] != events[3]["target_pages"],
                                       actual_draft_physical_pages_differ=events[2]["draft_pages"] != events[3]["draft_pages"]),
        quota1_T1_vs_T2_row0=dict(boundaries=mismatch, candidate="quota1_catchup", reference="natural1 row0",
                                 candidate_greedy=271, reference_greedy=271, greedy_equal=True,
                                 interpretation="The same complete prefix legally uses different T1/T2 math trees. These finite outputs are not byte-identical; no post-hoc error tolerance or quality PASS is assigned."),
        formulas=dict(relative_l2="F64 norm(actual-reference)/norm(reference)",
                      cosine="F64 dot(actual,reference)/(norm(actual)*norm(reference))"),
        raw_files=raw,
        limits=["The source prompt is the explicitly truncated first15 original prompt IDs, not a broad prompt distribution.",
                "No arbitrary quality, global acceptance rate, speed, all-EOS, capacity-only fallback or14-bank cancellation/failure proof.",
                "No native process, build, GPU run, product or probe edit was performed by this checker."],
        activity=dict(native_runs=0, GPU_runs=0, builds=0, product_edits=0, probe_edits=0))
    destination = STAGE / "review/round-runtime-review.json"
    destination.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(dict(report=identity(destination), ledger=sums, same_prefix_all_byte_equal=True,
                          quota1_vs_T2=mismatch, natural_rounds=2, accepted_drafts=1)))


if __name__ == "__main__":
    main()
