"""Bounded arithmetic and source-layout checks, without compiling or native use."""
from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
current = R / "tools/qwen35_text/session_state.h"
before = S / "before/tools/qwen35_text/session_state.h"
old, new = before.read_text(encoding="utf-8"), current.read_text(encoding="utf-8")
assert "bool draft_cache = false" in new
assert "(draft_cache && candidate_boundaries != 2)" in new
assert "draft_cache ? 14 : 12" in new
assert "void prepare(std::uint32_t pages, std::size_t layers = 6)" in new
assert "i < active_layers && status.ok()" in new
assert "layers != 1 && layers != 6" in new
assert "std::optional<DraftState> draft;" in new
draft = new.split("struct DraftState final {", 1)[1].split("};", 1)[0]
assert draft.index("std::vector<PageRef> pages;") < draft.index("c::PagedArenaRead key, value;")
assert "std::uint32_t lag = 0;" in draft and "std::int32_t catchup_token = -1;" in draft
assert new.index("VersionRef version;") < new.index("std::optional<DraftState> draft;")

payload = 19537920
cases = []
for context, n, r in ((64, 8, 1), (256, 1, 1), (1024, 2, 2), (17, 4, 1)):
    bank = ((context + 15) // 16 * n + r) * 16 * 1024 + 1
    for boundaries in (1, 2):
        snapshots = n + r
        states = n + boundaries * r
        hidden = 2 * snapshots if boundaries == 2 else 0
        hidden_bytes = hidden * 4096 + 1 if hidden else 0
        previous = bank * 12 + states * payload + 36 + hidden_bytes
        unchanged = bank * 12 + payload * states + 36 + hidden_bytes
        assert previous == unchanged
        row = dict(context=context, residents=n, active_sequences=r,
                   boundaries=boundaries, snapshot_slots=snapshots, state_slots=states,
                   hidden_slots=hidden, hidden_bytes=hidden_bytes, bank_bytes=bank,
                   draft_off_backing_bytes=unchanged,
                   draft_on_backing_bytes=(previous + 2 * bank) if boundaries == 2 else None,
                   draft_requires_two_boundaries=True)
        if context == 64 and boundaries == 2:
            assert previous == 201941041 and previous + 2 * bank == 203022387
        if context == 256 and boundaries == 1:
            assert previous == 42418224
        if context == 1024 and boundaries == 1:
            assert previous == 103710768
        cases.append(row)


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


snapshot = S / "current/tools/qwen35_text/session_state.h"
snapshot.parent.mkdir(parents=True, exist_ok=True)
snapshot.write_bytes(current.read_bytes())
diff = S / "session-state.diff"
diff.write_text("".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                   fromfile="before/tools/qwen35_text/session_state.h",
                   tofile="tools/qwen35_text/session_state.h")), encoding="utf-8")
report = dict(status="PASS bounded Python arithmetic/source checks; no C++ build/native run",
              default_backing_unchanged=True, examples=cases,
              acquired_layer_indices={str(k): list(range(k)) for k in (1, 6)},
              empty_unused_reservation_slots=True,
              note="acquire retains the original real arena.acquire and typed writer failure/retirement gates; source restricts layer domain to1/6. Python does not execute these C++ leases.",
              draft_contract="Optional absence is text-only; a committed complete MTP head must validate key/value ready frames, frontier=length-lag, lag0/no catchup, lag1/valid catchup token and prior_hidden. Root owns Model publication/adoption checks.")
out = S / "state-plan-selfcheck.json"
out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
freeze = dict(source=identity(current), before=identity(before), current=identity(snapshot),
              diff=identity(diff), selfcheck=identity(out),
              product_scope="tools/qwen35_text/session_state.h only",
              interface="plan(C,N,maxT,payload,R=1,boundaries=1,draft_cache=false); PageInventory.prepare(pages,layers=6); Snapshot.draft optional<DraftState>",
              limitations=["Root must allocate two independent draft arenas and initialize draft_inventory.prepare(max_pages,1).",
                           "Draft reservation arrays retain six slots; only index0 is valid in active_layers1 mode. Consumer transfer loops must use the actual layer count.",
                           "No public core API, executor, MTP math, actual lease tests or GPU execution introduced."],
              build=False, GPU=False, stopped_writing=True)
(S / "state-source-freeze.json").write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
print(json.dumps(freeze, indent=2))
