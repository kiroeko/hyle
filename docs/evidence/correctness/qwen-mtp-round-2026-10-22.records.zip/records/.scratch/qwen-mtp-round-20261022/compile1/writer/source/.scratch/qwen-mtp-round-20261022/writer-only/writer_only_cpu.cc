// Scratch standalone proof: original typed Graph append without a page reader.
#include <hyle/compute/backends/cpu.h>
#include <hyle/compute/custom_kernel.h>
#include <hyle/compute/providers/ggml_cpu.h>
#include <hyle/graph/batch.h>
#include <hyle/simd/dtype.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <span>
#include <string_view>
#include <utility>
#include <vector>

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace gb = g::batch;
using hyle::Result;
using hyle::Status;

Status require(bool value, const char *message) {
  return value ? Status::Ok() : Status::Internal(message);
}
std::uint16_t bf16(float value) { return hyle::simd::f32_to_bf16(value).bits; }

constexpr c::ProviderRuntimeProperties runtime{
    .mode = c::ProviderRuntimeMode::kSharedQueue,
    .workspace_owner = c::ProviderWorkspaceOwner::kCaller,
    .replay_class = c::ProviderReplayClass::kPrepared};
struct Reject final {
  static constexpr c::OperationId operation_id{0x48594c4554455354ULL, 0x574f4641494c0001ULL};
  static constexpr std::string_view operation_name = "writer-only-reject-after-append";
  constexpr c::OperationTraits operation_traits() const noexcept {
    return {{0, 0}, 0, c::AliasPolicy::kNone, c::EffectKind::kExternalSideEffect};
  }
  Status infer_output_descriptions(std::span<const c::TensorDesc> inputs,
                                   std::span<c::TensorDesc> outputs) const noexcept {
    return inputs.empty() && outputs.empty() ? Status::Ok()
        : Status::InvalidArgument("scratch reject has no tensor ports");
  }
};
struct RejectKernel final {
  struct Invocation final {};
  Result<Invocation> create_invocation(hyle::mem::BufferView,
                                      hyle::mem::AllocatorRef) const noexcept { return Invocation{}; }
  c::KernelCommandResult enqueue(Invocation &, c::detail::QueueSequence &,
      std::span<const c::ConstTensorView>, std::span<const c::TensorView>) const noexcept {
    return c::KernelCommandResult::rejected(
        Status::Internal("intentional failure after real writer-only append"));
  }
};
struct RejectFactory final {
  Result<c::KernelProposal> propose(const c::KernelRequest &request,
      std::span<c::ResourceRequirement>, std::span<c::ResourceRequirement>) const noexcept {
    if (!request.operation.custom_as<Reject>())
      return std::unexpected(Status::Unimplemented("not scratch rejection"));
    return c::KernelProposal{.runtime = runtime};
  }
  c::KernelPreparation prepare(const c::KernelPrepareRequest &request,
                                hyle::mem::AllocatorRef allocator) const noexcept {
    if (!request.operation.custom_as<Reject>())
      return c::KernelPreparation::unsupported(Status::Unimplemented("not scratch rejection"));
    auto kernel = c::make_custom_kernel(RejectKernel{},
        {.workspace = {0, 1}, .runtime = runtime, .persistent_bytes = 0,
         .invocation_private_bytes = 0}, allocator);
    return kernel ? c::KernelPreparation::prepared(std::move(*kernel))
                  : c::KernelPreparation::error(kernel.error());
  }
};

Status old_unchanged(const std::array<c::ReadLease, 2> &guards,
                     const std::array<std::vector<std::uint16_t>, 2> &original) {
  for (std::size_t i = 0; i < guards.size(); ++i) {
    std::vector<std::uint16_t> bytes(128);
    HYLE_RETURN_IF_ERROR(guards[i].view()->read(std::as_writable_bytes(std::span(bytes))));
    HYLE_RETURN_IF_ERROR(require(bytes == original[i], "retained old page changed, including its NaN tail"));
  }
  return Status::Ok();
}

Status journey(bool fail_after_append) {
  const auto memory = hyle::mem::system_resource();
  HYLE_ASSIGN_OR_RETURN(auto reject, c::make_custom_provider(
      {{0x48594c45, 0x574f4641}, "writer-only-rejection", "1"},
      c::cpu::kBackendId, RejectFactory{}));
  const std::array providers{c::ProviderBinding{c::ggml_cpu::provider(), 0},
                             c::ProviderBinding{reject, 0}};
  HYLE_ASSIGN_OR_RETURN(auto context, c::Context::create(c::cpu::device(), {.providers = providers}));
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  struct Drain final { c::Context &context; ~Drain() { context.drain().IgnoreError(); } } drain{context};
  HYLE_ASSIGN_OR_RETURN(auto plain, c::CacheStorage::plain(c::DataType::kBFloat16));
  const c::BatchCapacity capacity{
      .query_type = c::DataType::kBFloat16, .output_type = c::DataType::kBFloat16,
      .key_storage = plain, .value_storage = plain, .max_requests = 1,
      .max_query_rows = 2, .max_kv_rows = 8, .max_pages = 6, .max_page_refs = 4,
      .query_heads = 2, .kv_heads = 1, .qk_head_dim = 64, .value_head_dim = 64, .page_size = 2};
  HYLE_ASSIGN_OR_RETURN(auto schema, c::BatchSchema::create(capacity));
  const std::array<std::int32_t, 2> old_query{0, 1}, query{0, 2}, old_refs{0, 2}, refs{0, 3}, old_ids{0, 1};
  const std::array<std::int32_t, 3> ids{0, 2, 3};
  const std::array<std::int32_t, 1> last{1};
  HYLE_ASSIGN_OR_RETURN(auto old_layout, schema.version({old_query, old_refs, old_ids, last}));
  HYLE_ASSIGN_OR_RETURN(auto layout, schema.version({query, refs, ids, last}));
  HYLE_ASSIGN_OR_RETURN(auto arena, c::PagedArena::create(schema, c::BatchCacheRole::kValue,
      memory, {.max_backing_bytes = 4096}));
  std::array<c::ReadLease, 2> guards;
  std::array<std::vector<std::uint16_t>, 2> original{
      std::vector<std::uint16_t>(128), std::vector<std::uint16_t>(128, 0x7fc1)};
  std::fill_n(original[0].begin(), 64, bf16(.125F));
  std::fill(original[0].begin() + 64, original[0].end(), bf16(.25F));
  std::fill_n(original[1].begin(), 64, bf16(.375F));
  for (std::size_t i = 0; i < guards.size(); ++i) {
    HYLE_ASSIGN_OR_RETURN(auto writer, arena.acquire(static_cast<std::uint32_t>(i)));
    HYLE_RETURN_IF_ERROR(writer.lease().view()->write(std::as_bytes(std::span(original[i]))));
    HYLE_ASSIGN_OR_RETURN(guards[i], writer.publish(i == 0 ? 2 : 1));
  }
  HYLE_ASSIGN_OR_RETURN(auto previous, arena.read(old_layout, guards));
  std::array<c::PagedPageWriter, 2> dirty;
  HYLE_ASSIGN_OR_RETURN(dirty[0], arena.acquire(2));
  HYLE_ASSIGN_OR_RETURN(dirty[1], arena.acquire(3));
  HYLE_ASSIGN_OR_RETURN(auto append, gb::PagedAppendPages::create(arena, layout, previous, dirty));
  HYLE_ASSIGN_OR_RETURN(auto rows, c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t, 3>{2, 1, 64}));
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto input, builder.input(rows));
  HYLE_ASSIGN_OR_RETURN(auto effect, gb::paged_append(schema, c::BatchCacheRole::kValue));
  HYLE_ASSIGN_OR_RETURN(auto node, builder.add_node(c::Operation::custom(effect), std::array{input}));
  if (fail_after_append) {
    HYLE_ASSIGN_OR_RETURN(auto failure, builder.add_node(c::Operation::custom(Reject{}), {}));
    HYLE_RETURN_IF_ERROR(builder.depends_on(failure, node));
  }
  // No whole-bank input, reader, attention, publication or fake reader proof.
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  const std::array domains{g::StorageDomain{memory}};
  HYLE_ASSIGN_OR_RETURN(auto execution, g::ExecutionSource::acquire(context));
  const std::array targets{g::ExecutionTarget{execution, g::StorageDomainId{0}}};
  HYLE_ASSIGN_OR_RETURN(auto compiled, gb::compile(graph, {.storage_domains = domains, .targets = targets}));
  HYLE_ASSIGN_OR_RETURN(auto run, compiled.executable.create_invocation({.resources = g::ResourceOptions{}}));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  const auto unprepared = gb::bind_append(run, graph, node, std::move(append));
  HYLE_RETURN_IF_ERROR(require(!unprepared.ok() && append.valid(), "writer-only bind before prepare accepted or consumed owner"));
  HYLE_ASSIGN_OR_RETURN(auto &still_owned, append.page(0));
  HYLE_RETURN_IF_ERROR(require(still_owned.lease().valid(), "unprepared bind consumed dirty writer"));
  HYLE_RETURN_IF_ERROR(gb::prepare(run, queues, std::span<const gb::NodeLayout>{}));
  HYLE_RETURN_IF_ERROR(gb::bind_append(run, graph, node, std::move(append)));
  HYLE_RETURN_IF_ERROR(require(!append.valid(), "successful writer-only bind did not transfer owner"));
  HYLE_ASSIGN_OR_RETURN(auto pool, c::LeasePool::create(memory, 4096, {.max_blocks = 2}));
  HYLE_ASSIGN_OR_RETURN(auto source, pool.allocate(256, 64));
  std::array<std::uint16_t, 128> incoming;
  std::fill_n(incoming.begin(), 64, bf16(.5F));
  std::fill(incoming.begin() + 64, incoming.end(), bf16(.75F));
  HYLE_RETURN_IF_ERROR(source.view()->write(std::as_bytes(std::span(incoming))));
  HYLE_ASSIGN_OR_RETURN(auto ready_source, source.publish());
  HYLE_RETURN_IF_ERROR(run.bind(input, rows, ready_source));
  HYLE_RETURN_IF_ERROR(run.prepare_replay(queues));
  HYLE_ASSIGN_OR_RETURN(auto done, run.submit(queues));
  const auto terminal = done.wait();
  done = {};
  HYLE_RETURN_IF_ERROR(require(fail_after_append ? !terminal.ok() : terminal.ok(), "writer-only Graph terminal differs"));
  HYLE_ASSIGN_OR_RETURN(auto returned, gb::take_append(run, node));
  auto stale = run.submit(queues);
  if (stale) {
    stale->wait().IgnoreError();
    return Status::Internal("taken writer-only episode was resubmitted without rebind");
  }
  HYLE_RETURN_IF_ERROR(require(stale.error().IsFailedPrecondition(), "taken writer-only episode returned an unexpected rejection"));
  HYLE_RETURN_IF_ERROR(old_unchanged(guards, original));
  HYLE_RETURN_IF_ERROR(require(previous.layout() == old_layout && previous.page_count() == 2,
                                "old frame lost its original layout/guards"));
  if (fail_after_append) {
    auto refused = returned.ready();
    HYLE_RETURN_IF_ERROR(require(!refused, "failed whole Graph published a writer-only ready frame"));
    for (std::size_t i = 0; i < returned.page_count(); ++i) {
      HYLE_ASSIGN_OR_RETURN(auto &writer, returned.page(i));
      writer.lease().reset();
      HYLE_RETURN_IF_ERROR(writer.discard());
    }
    std::puts("writer-only accepted append prefix + failed whole Graph: no publish, old snapshot preserved PASS");
    return Status::Ok();
  }
  for (std::size_t page = 0; page < returned.page_count(); ++page) {
    HYLE_ASSIGN_OR_RETURN(auto &writer, returned.page(page));
    HYLE_RETURN_IF_ERROR(require(writer.page() == page + 2, "original writer ordinal changed"));
    std::array<std::uint16_t, 128> actual{};
    HYLE_RETURN_IF_ERROR(writer.lease().view()->read(std::as_writable_bytes(std::span(actual))));
    const auto count = page == 0 ? 128u : 64u;
    for (std::size_t i = 0; i < count; ++i) {
      const auto expected = page == 0 ? (i < 64 ? bf16(.375F) : bf16(.5F)) : bf16(.75F);
      HYLE_RETURN_IF_ERROR(require(actual[i] == expected, "writer-only COW prefix or appended value differs"));
    }
  }
  HYLE_ASSIGN_OR_RETURN(auto ready, returned.ready());
  HYLE_RETURN_IF_ERROR(require(ready.layout() == layout && ready.page_count() == 3,
                                "writer-only ready frame has wrong exact layout/footprint"));
  HYLE_RETURN_IF_ERROR(require(!arena.acquire(2) && !arena.acquire(3), "ready frame lost actual page permissions"));
  HYLE_RETURN_IF_ERROR(old_unchanged(guards, original));
  std::puts("writer-only prepare/bind/Graph/take/ready: COW values, stale-submit rejection, old snapshot preserved PASS");
  return Status::Ok();
}
} // namespace

int main() {
  std::setvbuf(stdout, nullptr, _IONBF, 0);
  auto status = journey(false);
  if (status.ok()) status = journey(true);
  if (status.ok()) return 0;
  char text[1024]{};
  status.ToString(text, sizeof(text));
  std::fprintf(stderr, "%s\n", text);
  return 1;
}
