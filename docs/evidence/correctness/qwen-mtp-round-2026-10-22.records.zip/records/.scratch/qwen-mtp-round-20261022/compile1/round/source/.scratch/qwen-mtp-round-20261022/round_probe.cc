// Finite real-weight consumer probe. It uses only the original Model episode.
#define main hyle_qwen35_text_consumer_main
#include "../../tools/qwen35_text/main.cc"
#undef main

#include "hyle/compute/detail/paged_arena_access.h"
#include <cstring>

namespace {
namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;

void require(bool condition, const char *message) {
  if (!condition) throw std::runtime_error(message);
}
std::string quoted(std::string_view value) {
  std::ostringstream stream; stream << '"';
  for (const auto ch : value) {
    if (ch == '"' || ch == '\\') stream << '\\';
    if (ch == '\n') stream << "\\n";
    else if (ch == '\r') stream << "\\r";
    else if (static_cast<unsigned char>(ch) < 32) stream << '?';
    else stream << ch;
  }
  stream << '"'; return stream.str();
}
Bytes bytes(c::ReadLease const &lease) {
  Bytes result(lease.size()); q::check(q::take(lease.view()).read(result)); return result;
}
Bytes bytes(q::mem::ConstBufferView view) {
  Bytes result(view.size()); q::check(view.read(result)); return result;
}
void write_file(const std::filesystem::path &path, const Bytes &data) {
  std::ofstream stream(path, std::ios::binary);
  stream.write(reinterpret_cast<const char *>(data.data()), static_cast<std::streamsize>(data.size()));
  require(static_cast<bool>(stream), "cannot write finite round-probe vector");
}
void finite(const Bytes &data, bool bf16) {
  const auto width = bf16 ? 2u : 4u;
  require(data.size() % width == 0, "probe output is not scalar aligned");
  for (std::size_t i = 0; i < data.size(); i += width) {
    if (bf16) {
      std::uint16_t word = 0; std::memcpy(&word, data.data() + i, sizeof(word));
      require((word & 0x7f80u) != 0x7f80u, "nonfinite BF16 round output");
    } else {
      std::uint32_t word = 0; std::memcpy(&word, data.data() + i, sizeof(word));
      require((word & 0x7f800000u) != 0x7f800000u, "nonfinite F32 round output");
    }
  }
}
bool disjoint(c::ReadLease const &lease, q::mem::ConstBufferView other) {
  const auto view = q::take(lease.view());
  return view.resource() != other.resource() || view.native_handle() != other.native_handle() ||
      q::cache::add(view.offset(), view.size()) <= other.offset() ||
      q::cache::add(other.offset(), other.size()) <= view.offset();
}

struct Saved final {
  q::cache::SnapshotRef head;
  std::vector<Bytes> target_pages, draft_pages, states;
  Bytes carry, prior;
  std::size_t length = 0, frontier = 0;
  std::uint32_t lag = 0;
  std::int32_t next = -1, catchup = -1;
};
Saved save(q::cache::SnapshotRef head) {
  require(head && head->draft, "probe requires a complete target/draft snapshot");
  Saved result; result.head = std::move(head);
  result.length = result.head->length; result.next = result.head->next_id;
  result.frontier = result.head->draft->frontier; result.lag = result.head->draft->lag;
  result.catchup = result.head->draft->catchup_token;
  for (std::size_t layer = 0; layer < result.head->keys.size(); ++layer)
    for (const auto *frame : {&result.head->keys[layer], &result.head->values[layer]})
      for (const auto &lease : c::detail::PagedArenaAccess::pages(*frame)) result.target_pages.push_back(bytes(lease));
  for (const auto *frame : {&result.head->draft->key, &result.head->draft->value})
    for (const auto &lease : c::detail::PagedArenaAccess::pages(*frame)) result.draft_pages.push_back(bytes(lease));
  for (const auto &state : result.head->state)
    for (const auto *lease : {&state.history, &state.recurrent}) if (lease->valid()) result.states.push_back(bytes(*lease));
  require(result.states.size() == 36, "complete old snapshot lacks recurrent state");
  result.carry = bytes(result.head->carry_hidden);
  if (result.head->prior_hidden.valid()) result.prior = bytes(result.head->prior_hidden);
  return result;
}
void unchanged(const Saved &old) {
  const auto now = save(old.head);
  require(now.length == old.length && now.frontier == old.frontier && now.lag == old.lag &&
      now.next == old.next && now.catchup == old.catchup && now.target_pages == old.target_pages &&
      now.draft_pages == old.draft_pages && now.states == old.states &&
      now.carry == old.carry && now.prior == old.prior, "an older complete snapshot changed after a later episode");
}
void frame_length(const c::PagedArenaRead &frame, std::size_t length,
                  const std::vector<q::cache::PageRef> &pages) {
  const auto host = frame.layout().host();
  const auto count = (length + q::cache::Plan::page_rows - 1) / q::cache::Plan::page_rows;
  require(frame.valid() && frame.layout().facts().requests == 1 && frame.page_count() == count &&
      pages.size() == count && host.page_indices.size() == count && host.last_page_lengths.size() == 1,
      "ready frame/policy footprint disagrees with committed frontier");
  require(count && (count - 1) * q::cache::Plan::page_rows +
      static_cast<std::size_t>(host.last_page_lengths[0]) == length,
      "ready frame exposes a missing or extra logical row");
  for (std::size_t i = 0; i < pages.size(); ++i)
    require(host.page_indices[i] == static_cast<std::int32_t>(pages[i].page()), "ready frame uses another physical page inventory");
}
void complete(q::Model &model, const q::Session &session) {
  model.validate_mtp_snapshot(*session.head);
  const auto &head = *session.head; const auto &draft = *head.draft;
  require(head.length && draft.frontier == head.length - draft.lag && draft.lag <= 1,
      "draft frontier is not target length minus lag");
  require(head.carry_hidden.size() == 4096, "target carry is not one independent BF16 row");
  if (draft.lag)
    require(head.prior_hidden.valid() && head.prior_hidden.size() == 4096 &&
        draft.catchup_token >= 0 && draft.catchup_token < q::vocabulary,
        "lag1 omitted its known token/target prior hidden");
  else require(draft.catchup_token == -1 && !head.prior_hidden.valid(), "lag0 retained stale catchup state");
  for (std::size_t i = 0; i < head.keys.size(); ++i) {
    frame_length(head.keys[i], head.length, head.pages);
    frame_length(head.values[i], head.length, head.pages);
  }
  frame_length(draft.key, draft.frontier, draft.pages);
  frame_length(draft.value, draft.frontier, draft.pages);
}

struct Event final {
  std::string name, stream, role;
  bool injected = false, original_head_stable_during_prepare = false, all_old_bytes_preserved = false;
  std::size_t base_length = 0, old_frontier = 0, target_query_rows = 0, draft_query_rows = 0;
  std::size_t new_length = 0, frontier = 0, lag = 0, recorded = 0, reused = 0;
  std::size_t versions_before = 0, versions_candidate = 0, versions_after = 0;
  std::size_t managed_cache_live_bytes = 0, graph_steps = 0;
  std::vector<std::uint32_t> target_pages, draft_pages;
  std::int32_t catchup = -1;
  q::MtpRoundResult result;
};
const char *role_name(q::GraphRole role) {
  switch (role) {
  case q::GraphRole::kMtpPrefill: return "MtpPrefill";
  case q::GraphRole::kMtpRound: return "MtpRound";
  case q::GraphRole::kMtpCatchupRound: return "MtpCatchupRound";
  case q::GraphRole::kMtpSingle: return "MtpSingle";
  case q::GraphRole::kMtpCatchupSingle: return "MtpCatchupSingle";
  default: return "not-mtp";
  }
}
struct Observation final {
  std::filesystem::path output, inputs;
  std::vector<std::int32_t> prompt;
  std::vector<Event> events;
  bool natural_accept = false, natural_reject = false, injected_lag1_seed = false;
  bool old_prefix_reused = false;
  void write(const char *status, std::string_view error = {}) const {
    std::ofstream out(output / "observation.json");
    require(static_cast<bool>(out), "cannot write MTP round observation");
    std::size_t target_rows = 0, draft_rows = 0, commits = 0, natural_rounds = 0, natural_accepts = 0, natural_agreements = 0;
    for (const auto &event : events) {
      target_rows += event.target_query_rows; draft_rows += event.draft_query_rows;
      commits += event.result.processed_target;
      if (event.stream == "natural" && event.target_query_rows == 2) {
        ++natural_rounds; natural_accepts += event.result.accepted_draft; natural_agreements += event.result.agreed;
      }
    }
    out << "{\"status\":" << quoted(status) << ",\"error\":" << quoted(error)
        << ",\"inputs\":" << quoted(inputs.string()) << ",\"prompt_ids\":[";
    for (std::size_t i = 0; i < prompt.size(); ++i) out << (i ? "," : "") << prompt[i];
    out << "],\"prompt_scope\":\"first15 IDs of the supplied original prompt, finite truncation\""
        << ",\"capacity\":64,\"resident_snapshot_limit\":8,\"active_sequences\":1"
        << ",\"loaded_weight_tensors\":335,\"single_original_Model\":true,\"actual_graph_calls\":" << events.size()
        << ",\"target_query_rows\":" << target_rows << ",\"draft_written_rows\":" << draft_rows
        << ",\"committed_target_rows\":" << commits << ",\"natural_rounds\":" << natural_rounds
        << ",\"natural_accepted_drafts\":" << natural_accepts
        << ",\"natural_agreements\":" << natural_agreements << ",\"eos_ids\":[248044,248046]"
        << ",\"natural_accept_seen\":" << (natural_accept ? "true" : "false")
        << ",\"natural_reject_seen\":" << (natural_reject ? "true" : "false")
        << ",\"injected_lag1_seed\":" << (injected_lag1_seed ? "true" : "false")
        << ",\"old_complete_prefix_reused\":" << (old_prefix_reused ? "true" : "false")
        << ",\"quality_tolerance\":null,\"throughput_measurement\":false,\"events\":[";
    for (std::size_t i = 0; i < events.size(); ++i) {
      const auto &e = events[i]; const auto &r = e.result;
      out << (i ? "," : "") << "{\"name\":" << quoted(e.name) << ",\"stream\":" << quoted(e.stream)
          << ",\"role\":" << quoted(e.role) << ",\"injected_boundary\":" << (e.injected ? "true" : "false")
          << ",\"selection_mode\":" << quoted(e.injected ? "forced boundary; greedy/EOS selection bypassed" : "ordinary Model policy")
          << ",\"base_length\":" << e.base_length << ",\"old_draft_frontier\":" << e.old_frontier
          << ",\"target_query_rows\":" << e.target_query_rows << ",\"draft_query_rows\":" << e.draft_query_rows
          << ",\"committed_target_rows\":" << r.processed_target << ",\"processed_draft_rows\":" << r.processed_draft
          << ",\"pending\":" << r.pending << ",\"draft\":" << r.draft << ",\"target_first\":" << r.target_first
          << ",\"target_second\":" << r.target_second << ",\"next_id\":" << r.next_id
          << ",\"agreed\":" << (r.agreed ? "true" : "false")
          << ",\"accepted_draft\":" << (r.accepted_draft ? "true" : "false")
          << ",\"stopped\":" << (r.stopped ? "true" : "false") << ",\"emitted\":[";
      for (std::size_t j = 0; j < r.emitted.size(); ++j) out << (j ? "," : "") << r.emitted[j];
      out << "],\"length\":" << e.new_length << ",\"draft_frontier\":" << e.frontier << ",\"lag\":" << e.lag
          << ",\"catchup_token\":" << e.catchup << ",\"capture_recorded\":" << e.recorded << ",\"capture_reused\":" << e.reused
          << ",\"snapshot_versions_before\":" << e.versions_before << ",\"snapshot_versions_candidate\":" << e.versions_candidate
          << ",\"snapshot_versions_after\":" << e.versions_after << ",\"managed_cache_live_bytes\":" << e.managed_cache_live_bytes
          << ",\"selected_graph_steps\":" << e.graph_steps << ",\"target_pages\":[";
      for (std::size_t j = 0; j < e.target_pages.size(); ++j) out << (j ? "," : "") << e.target_pages[j];
      out << "],\"draft_pages\":[";
      for (std::size_t j = 0; j < e.draft_pages.size(); ++j) out << (j ? "," : "") << e.draft_pages[j];
      out << ']'
          << ",\"old_head_stable_during_prepare\":" << (e.original_head_stable_during_prepare ? "true" : "false")
          << ",\"old_snapshot_all_bytes_unchanged\":" << (e.all_old_bytes_preserved ? "true" : "false") << '}';
    }
    out << "],\"limits\":[\"Finite real prompt/carry branch exercise, not an all-domain quality or speed result.\","
        << "\"Forced accepted-boundary cases are conditional teacher-forced states and excluded from natural counts.\","
        << "\"Natural EOS stops the original stream even before both outcomes/eight rounds; a matching EOS is not normal accepted draft.\","
        << "\"C64 bounded run does not exercise the capacity-one-slot fallback or every EOS outcome.\"]}\n";
    require(static_cast<bool>(out), "cannot finish MTP round observation");
  }
};

void record(q::Model &model, Observation &observation, Event event,
            const std::shared_ptr<q::Session> &session, q::Phase &phase, const Saved &old) {
  complete(model, *session); unchanged(old);
  require(session->length() == old.length + event.result.processed_target &&
      session->head->draft->frontier == old.frontier + event.draft_query_rows &&
      session->head->next_id == event.result.next_id, "committed target/draft/next ID accounting differs");
  const auto hidden = bytes(q::mem::ConstBufferView(phase.final_hidden.buffer.view()));
  const auto logits = bytes(q::mem::ConstBufferView(phase.logits.buffer.view()));
  finite(hidden, true); finite(logits, false);
  const auto published_rows = q::verifies_two(phase.family->role) ? 2u : 1u;
  require(hidden.size() == published_rows * 4096 && logits.size() == published_rows * std::size_t(q::vocabulary) * 4,
      "target publication has unexpected complete rows");
  const auto selected = q::verifies_two(phase.family->role) ? event.result.processed_target - 1 : 0;
  const auto target_ids = bytes(q::mem::ConstBufferView(phase.next_id.buffer.view()));
  require(target_ids.size() == published_rows * sizeof(std::int32_t), "target ID row count differs from original logits");
  for (std::size_t row = 0; row < published_rows; ++row) {
    float best = -std::numeric_limits<float>::infinity(); std::int32_t best_id = 0, actual_id = -1;
    for (std::int32_t id = 0; id < q::vocabulary; ++id) {
      float value = 0;
      std::memcpy(&value, logits.data() + (row * std::size_t(q::vocabulary) + std::size_t(id)) * sizeof(value), sizeof(value));
      if (value > best) { best = value; best_id = id; }
    }
    std::memcpy(&actual_id, target_ids.data() + row * sizeof(actual_id), sizeof(actual_id));
    require(actual_id == best_id, "original target ID differs from its actual first-index logits argmax");
    require(row == 0 ? event.result.target_first == actual_id : event.result.target_second == actual_id,
        "MTP result decision differs from its original target row");
  }
  const Bytes expected_carry(hidden.begin() + static_cast<std::ptrdiff_t>(selected * 4096),
      hidden.begin() + static_cast<std::ptrdiff_t>((selected + 1) * 4096));
  require(bytes(session->head->carry_hidden) == expected_carry &&
      disjoint(session->head->carry_hidden, q::mem::ConstBufferView(phase.final_hidden.buffer.view())),
      "selected actual carry differs or aliases reusable target output");
  if (session->head->draft->lag) {
    require(event.result.processed_target == 2 && session->head->draft->catchup_token == event.result.draft &&
        bytes(session->head->prior_hidden) == Bytes(hidden.begin(), hidden.begin() + 4096),
        "lag1 did not retain draft input token and actual target row0 hidden");
  }
  const auto directory = observation.output / "trace" / event.name;
  std::filesystem::create_directories(directory);
  write_file(directory / "all-hidden.bf16", hidden);
  write_file(directory / "all-logits.f32", logits);
  write_file(directory / "carry.bf16", bytes(session->head->carry_hidden));
  if (session->head->prior_hidden.valid()) write_file(directory / "prior.bf16", bytes(session->head->prior_hidden));
  write_file(directory / "target-ids.i32", target_ids);
  event.new_length = session->length(); event.frontier = session->head->draft->frontier;
  event.lag = session->head->draft->lag; event.catchup = session->head->draft->catchup_token;
  event.versions_after = model.snapshot_versions.live;
  event.managed_cache_live_bytes = q::take(model.cache_budget.usage(model.memory.ref())).live_bytes;
  event.graph_steps = phase.child->compiled.report.step_count();
  for (const auto &page : session->head->pages) event.target_pages.push_back(page.page());
  for (const auto &page : session->head->draft->pages) event.draft_pages.push_back(page.page());
  event.all_old_bytes_preserved = true;
  observation.events.push_back(std::move(event)); observation.write("RUNNING");
}

Event prepared(q::Model &model, const Saved &old, q::GraphRole role,
               std::string name, std::string stream, const std::shared_ptr<q::Session> &session,
               std::span<const std::int32_t> ids) {
  Event event; event.name = std::move(name); event.stream = std::move(stream); event.role = role_name(role);
  event.base_length = old.length; event.old_frontier = old.frontier;
  event.versions_before = model.snapshot_versions.live;
  model.prepare_evaluation(*session, ids, nullptr, role);
  require(session->head == old.head && session->pending && model.carrier_borrowed,
      "prepare published a candidate or lost original episode admission");
  event.original_head_stable_during_prepare = true;
  event.versions_candidate = model.snapshot_versions.live;
  event.target_query_rows = model.active_step->input_tokens;
  event.draft_query_rows = role == q::GraphRole::kMtpPrefill ? ids.size() : old.lag + 1;
  event.recorded = model.active_step->capture_recorded; event.reused = model.active_step->capture_reused;
  return event;
}

q::MtpRoundResult generation(q::Model &model, Observation &observation,
    const std::shared_ptr<q::Session> &session, std::size_t quota, std::string name,
    std::string stream = "natural") {
  const auto old = save(session->head);
  const auto role = quota == 1
      ? (old.lag ? q::GraphRole::kMtpCatchupSingle : q::GraphRole::kMtpSingle)
      : (old.lag ? q::GraphRole::kMtpCatchupRound : q::GraphRole::kMtpRound);
  const std::array ids{old.next};
  auto event = prepared(model, old, role, std::move(name), std::move(stream), session, ids);
  auto *phase = model.active_step->phase;
  model.submit_evaluation(*session);
  const std::array<std::int32_t, 2> eos{248044, 248046};
  event.result = model.finish_mtp_round(*session, quota, eos);
  require(event.result.pending == old.next && event.result.processed_draft == event.draft_query_rows &&
      event.result.processed_target >= 1 && event.result.processed_target <= event.target_query_rows,
      "MTP result uses inconsistent input/commit counters");
  require(event.result.emitted.size() == event.result.processed_target && !event.result.emitted.empty() &&
      event.result.emitted.back() == event.result.next_id, "MTP pending/emitted result accounting differs");
  if (event.stream == "natural" && quota >= 2) {
    observation.natural_accept = observation.natural_accept || event.result.accepted_draft;
    observation.natural_reject = observation.natural_reject || !event.result.agreed;
  }
  auto result = event.result;
  record(model, observation, std::move(event), session, *phase, old);
  return result;
}

void forced_boundary(q::Model &model, Observation &observation,
    const std::shared_ptr<q::Session> &session, std::size_t accepted, std::string name) {
  require(accepted == 1 || accepted == 2, "injected boundary must be actual verify row0 or row1");
  const auto old = save(session->head);
  const auto role = old.lag ? q::GraphRole::kMtpCatchupRound : q::GraphRole::kMtpRound;
  const std::array input{old.next};
  auto event = prepared(model, old, role, std::move(name), "injected_branch", session, input);
  event.injected = true; auto *phase = model.active_step->phase;
  model.submit_evaluation(*session);
  const std::array outputs{q::EvaluationOutput{.session = session, .name = event.name}};
  std::array<std::int32_t, 1> next{-1};
  model.finish_selected_evaluations(outputs, next,
      [&](std::span<const std::int32_t> ids, q::StepState &step, std::span<std::int32_t> selected) {
        require(ids.size() == 2 && step.members.size() == 1, "injected selector lacks actual two-row decisions");
        require(step.draft_token >= 0 && step.draft_token < q::vocabulary, "injected selector lacks an actual valid device draft ID");
        event.result.pending = old.next; event.result.draft = step.draft_token;
        event.result.target_first = ids[0]; event.result.target_second = ids[1];
        event.result.agreed = step.draft_token == ids[0]; event.result.accepted_draft = accepted == 2;
        event.result.next_id = selected[0] = ids[accepted - 1];
        event.result.processed_target = accepted; event.result.processed_draft = old.lag + 1;
        // a2 intentionally follows the actual proposed token even on mismatch.
        // It is a valid conditional prefix, never a claimed natural acceptance.
        event.result.emitted = accepted == 2 ? std::vector<std::int32_t>{step.draft_token, ids[1]}
                                              : std::vector<std::int32_t>{ids[0]};
        step.members[0].accepted_tokens = accepted;
      });
  record(model, observation, std::move(event), session, *phase, old);
}

void run(const std::filesystem::path &inputs, const std::filesystem::path &output) {
  require(!std::filesystem::exists(output), "round probe output must be new");
  std::filesystem::create_directories(output);
  Observation observation; observation.output = output; observation.inputs = inputs;
  try {
    auto prompt = q::read_ids(inputs / "prompt.ids");
    require(prompt.size() >= 15, "round probe requires at least15 original prompt IDs");
    prompt.resize(15);
    observation.prompt = prompt;
    constexpr std::size_t capacity = 64, residents = 8;
    const auto plan = q::cache::plan(capacity, residents, 15,
        q::recurrent_bytes(q::state_schema_for(capacity)), 1, 2, true);
    q::Model model(inputs / "weights.tsv", capacity, plan, {}, false, q::ReplayPolicy::kAuto, plan.backing_bytes);
    const std::array<std::size_t, 1> fifteen{15}, two{2}, one{1};
    model.prepare_family(fifteen, false, 1, q::GraphRole::kMtpPrefill);
    for (const auto role : {q::GraphRole::kMtpRound, q::GraphRole::kMtpCatchupRound})
      model.prepare_family(two, false, 1, role);
    for (const auto role : {q::GraphRole::kMtpSingle, q::GraphRole::kMtpCatchupSingle})
      model.prepare_family(one, false, 1, role);
    model.plan_replay_uses(15, 1, 1, q::GraphRole::kMtpPrefill);
    for (const auto role : {q::GraphRole::kMtpRound, q::GraphRole::kMtpCatchupRound}) model.plan_replay_uses(2, 1, 12, role);
    for (const auto role : {q::GraphRole::kMtpSingle, q::GraphRole::kMtpCatchupSingle}) model.plan_replay_uses(1, 1, 6, role);
    auto session = model.create_session(fifteen, {}, q::GraphRole::kMtpPrefill);
    {
      const auto old = save(session->head);
      auto event = prepared(model, old, q::GraphRole::kMtpPrefill, "prefill15", "prefill", session, prompt);
      auto *phase = model.active_step->phase; model.submit_evaluation(*session);
      event.result.next_id = model.finish_evaluation(*session, "prefill15");
      event.result.target_first = event.result.next_id; event.result.processed_target = 15;
      event.result.processed_draft = 15; event.result.emitted.push_back(event.result.next_id);
      record(model, observation, std::move(event), session, *phase, old);
    }
    const auto seed = save(session->head);
    q::cache::SnapshotRef lag1_seed;
    for (std::size_t round = 0; round < 8 && !q::is_end_of_generation(session->head->next_id); ++round) {
      const auto result = generation(model, observation, session, 2, "natural" + std::to_string(round));
      if (session->head->draft->lag && !lag1_seed) lag1_seed = session->head;
      unchanged(seed);
      if (result.stopped || (observation.natural_accept && observation.natural_reject)) break;
    }
    if (!lag1_seed && !q::is_end_of_generation(seed.next)) {
      auto forced = model.create_session(two, seed.head, q::GraphRole::kMtpRound);
      forced_boundary(model, observation, forced, 2, "injected_a2_for_lag1");
      lag1_seed = forced->head; observation.injected_lag1_seed = true;
    }
    if (lag1_seed && !q::is_end_of_generation(lag1_seed->next_id)) {
      const auto held = save(lag1_seed);
      const auto branch = observation.injected_lag1_seed ? "injected_branch_continuation" : "forked_old_prefix";
      auto catchup = model.create_session(two, lag1_seed, q::GraphRole::kMtpCatchupRound);
      generation(model, observation, catchup, 2, "fork_catchup_round", branch);
      unchanged(held); observation.old_prefix_reused = true;
      const std::array<std::size_t, 2> singles{1, 1};
      auto quota = model.create_session(singles, lag1_seed, q::GraphRole::kMtpCatchupSingle);
      generation(model, observation, quota, 1, "quota1_catchup", branch);
      require(quota->head->draft->lag == 0, "catchup single did not restore an equal draft frontier");
      if (!q::is_end_of_generation(quota->head->next_id)) generation(model, observation, quota, 1, "quota1_single", branch);
      unchanged(held);
    }
    if (!observation.natural_reject && !q::is_end_of_generation(seed.next)) {
      auto forced = model.create_session(two, seed.head, q::GraphRole::kMtpRound);
      forced_boundary(model, observation, forced, 1, "injected_a1_selection");
      if (!q::is_end_of_generation(forced->head->next_id)) generation(model, observation, forced, 1, "after_injected_a1", "injected_branch");
    }
    unchanged(seed); complete(model, *session);
    q::check(model.context.drain());
    observation.write("COMPLETE finite MTP round/state exercise; no quality or speed threshold");
    std::cout << "{\"status\":\"finite real MTP rounds completed\",\"actual_graph_calls\":" << observation.events.size()
              << ",\"natural_accept_seen\":" << (observation.natural_accept ? "true" : "false")
              << ",\"natural_reject_seen\":" << (observation.natural_reject ? "true" : "false")
              << ",\"injected_lag1_seed\":" << (observation.injected_lag1_seed ? "true" : "false")
              << ",\"quality_validation\":false,\"throughput_measurement\":false}\n";
  } catch (const std::exception &error) { observation.write("FAILED", error.what()); throw; }
}
} // namespace

int main(int argc, char **argv) {
  try {
    if (argc != 3) throw std::runtime_error("round_probe INPUT_DIR_WITH_MTP_MANIFEST NEW_OUTPUT_DIR");
    run(argv[1], argv[2]); return 0;
  } catch (const std::exception &error) {
    std::cerr << "MTP round probe failed: " << error.what() << '\n'; return 1;
  }
}
