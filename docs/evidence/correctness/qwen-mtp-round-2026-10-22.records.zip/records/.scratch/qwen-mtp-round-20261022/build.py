"""Incremental original Graph/Batch owners and actual consumers; no SDK/NVCC."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode = True
T = Path(__file__).resolve().parent
R = T.parents[1]
S = R / '.scratch/qwen-topone-prepared-20261022'
F = R / '.scratch/paged-host-prepare-20261021'
sp = importlib.util.spec_from_file_location('prior', R / '.scratch/qwen-mtp-graph-20261022/build.py')
h = importlib.util.module_from_spec(sp); sp.loader.exec_module(h)
b, c = h.b, h.c
recipes = {
 'qwen': R / '.scratch/qwen-cli-batch-20261022/compile4/qwen/identity.json',
 'round': R / '.scratch/qwen-cli-batch-20261022/compile4/qwen/identity.json',
 'resources': R / '.scratch/paged-exclusive-20261021/compile1/resources/identity.json',
 'batch': R / '.scratch/paged-capture-20261021/host/checks1/batch/identity.json',
 'append': F / 'compile1/append/identity.json',
 'writer': R / '.scratch/paged-prepare-20261021/checks/attempt1/graph_batch--paged_append_graph_test/identity.json',
 'tests': R / '.scratch/paged-exclusive-20261021/compile1/cpu-test/identity.json',
}
sources = {'qwen': R/'tools/qwen35_text/main.cc', 'round': T/'round_probe.cc',
 'writer': T/'writer-only/writer_only_cpu.cc'}

def same(rec): return b.identity(rec['path']) == rec

def compile_owner(tag, attempt):
 prior = c.read(recipes[tag]); source = sources.get(tag, Path(prior['source']['path']))
 out = T/f'compile{attempt}'/tag; out.mkdir(parents=True, exist_ok=False); (out/'tmp').mkdir()
 command = b.host_command(prior['command'], source, tag, out)
 assert all(x in command for x in ('/W4','/WX','/O2','/MD'))
 frozen = b.identity(source); main = b.identity(R/'tools/qwen35_text/main.cc')
 snap = out/'source'/source.relative_to(R); snap.parent.mkdir(parents=True,exist_ok=True); snap.write_bytes(source.read_bytes())
 c.save(out/'plan.json',dict(command=command,source=frozen,recipe=b.identity(recipes[tag]),SDK_builds=0,native_rebuilds=0))
 env,_ = b.environment(command,[],out); c.execute('compile',command,env,out)
 data=c.read(out/f'{tag}-deps.json')['Data']; deps=list(dict.fromkeys([data['Source'],*data['Includes']]))
 assert same(frozen) and same(main)
 c.save(out/'identity.json',dict(source=frozen,main=main,object=b.identity(out/f'{tag}.obj'),command=command,dependencies=[b.identity(x)for x in deps]))
 print('COMPILED',tag,flush=True)

def link(tag, attempt, lib_attempt, link_attempt=0):
 link_attempt=link_attempt or attempt
 base_dir = F/'cpu-link1' if tag in ('writer','tests') else S/'qwen-link1'
 base_path = base_dir/'link-plan.json'; base=c.read(base_path)
 replacements={}; records=[]
 for owner, at in [(tag,attempt),*[(x,lib_attempt)for x in ('resources','batch','append')]]:
  path=T/f'compile{at}'/owner/'identity.json'; record=c.read(path); records.append(b.identity(path))
  assert all(same(x)for x in(record['source'],record['object'],*record['dependencies']))
  old_recipe = recipes['tests' if tag in ('writer','tests') else 'qwen'] if owner==tag else recipes[owner]
  old_object = c.read(old_recipe)['object']['path']
  replacements[c.key(old_object)]=record['object']
 if tag=='tests':
  # The retained CPU closure predates reframe; reuse the exact newer arena
  # object already used by the ordinary current CUDA consumer closure.
  arena=R/'.scratch/multisequence-batch-20261021/compile2/arena/identity.json'
  rec=c.read(arena)
  assert all(same(x)for x in(rec['source'],rec['object'],*rec['dependencies']))
  replacements[c.key(R/'.scratch/paged-exclusive-20261021/compile1/arena/arena.obj')]=rec['object']
  records.append(b.identity(arena))
 assert all(same(x)for x in base['inputs'])
 assert all(sum(c.key(x['path'])==key for x in base['inputs'])==1 for key in replacements)
 inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]
 command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 out=T/f'{tag}-link{link_attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir(); image=out/f'{tag}.exe'
 command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),compiled_records=records,SDK_builds=0,native_rebuilds=0))
 env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
 for dll in base_dir.glob('*.dll'): os.link(dll,out/dll.name)
 runtime=c.read(base_dir/'runtime-environment.json');runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
 if tag in ('writer','tests') and 'CPU_native_overlay' in runtime: runtime['CPU_native_overlay']['destination']=b.identity(out/'hyle_ggml_cpu_append_hyca.dll')
 c.save(out/'runtime-environment.json',runtime)
 c.save(T/f'{tag}-ready-attempt{link_attempt}.json',dict(image=b.identity(image),main=b.identity(R/'tools/qwen35_text/main.cc'),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0,native_rebuilds=0))
 print('READY',tag,flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=tuple(recipes));p.add_argument('--attempt',type=int,default=1);p.add_argument('--lib-attempt',type=int,default=1);p.add_argument('--link-attempt',type=int,default=0);p.add_argument('--link',action='store_true');a=p.parse_args()
 if a.link:link(a.mode,a.attempt,a.lib_attempt,a.link_attempt)
 else:compile_owner(a.mode,a.attempt)
