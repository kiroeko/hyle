"""Freeze actual finite results and archive only reproducibility sources/data."""
from pathlib import Path
import difflib, hashlib, json, subprocess, zipfile

T=Path(__file__).resolve().parent; R=T.parents[1]
O=R/'docs/evidence/correctness'
NAME='qwen-mtp-round-2026-10-22'

def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d): p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(p):
 h=hashlib.sha256()
 with p.open('rb')as stream:
  for block in iter(lambda:stream.read(8<<20),b''):h.update(block)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())

products=['include/hyle/graph/batch.h','include/hyle/graph/detail/region_access.h',
 'src/graph/resources.cc','src/graph_batch/batch.cc','src/graph_batch/paged_append.h','src/graph_batch/paged_append.cc',
 'tests/graph_batch/paged_append_graph_test.cc','tools/qwen35_text/session_state.h','tools/qwen35_text/main.cc',
 'tools/qwen35_text/mtp_graph.h','tools/qwen35_text/README.md','docs/developer/current-work.md',
 'docs/developer/performance/decode.md','docs/architecture/graph-design.md']
frozen=[];checks=[]
for name in products:
 p=R/name; snap=T/'current'/name;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 entry=dict(source=identity(p),snapshot=identity(snap));before=T/'before'/name
 if before.exists():
  diff=T/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
  diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
  result=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
  assert result.returncode in (0,1) and not result.stdout.strip() and not result.stderr.strip(),(name,result.stdout,result.stderr)
  checks.append(dict(path=name,exit=result.returncode,whitespace_diagnostics=[]));entry.update(before=identity(before),diff=identity(diff))
 frozen.append(entry)
save(T/'product-freeze.json',dict(products=frozen,diff_checks=checks))

runs={}
for name in ('writer-run1','tests-run3','cli-run3','r1-run1','batch-run1','round-run1'):
 d=read(T/name/'run.result.json');assert d['exit']==0 and d['terminal']is True
 runs[name]=dict(terminal=identity(T/name/'run.result.json'),stdout=identity(T/name/'run.stdout.log'),stderr=identity(T/name/'run.stderr.log'),command=d['command'])
reports={name:read(T/'review'/name)for name in ('writer-only-implementation.json','mtp-transaction-review.json','ordinary-regression.json','cli-eos-review.json','round-runtime-review.json')}
assert reports['ordinary-regression.json']['total_vector_pairs']==90
actual=read(T/'round-output1/observation.json'); assert actual['actual_graph_calls']==6 and actual['natural_accept_seen']and actual['natural_reject_seen']and not actual['injected_lag1_seed']
passed=[s for s in (T/'tests-run3/run.stdout.log').read_text().splitlines()if s.endswith('PASS')];assert len(passed)==13
summary=dict(status='Finite CUDA K1 MTP consumer and original writer-only Graph implementation exercised; broad goal remains open',
 public_api='batch::prepare(original queues,layouts) then bind_append(invocation,graph,node,Pages&&) for writer-only; existing reader overload retained',
 product_freeze=identity(T/'product-freeze.json'),runs=runs,permanent_CPU_regression=dict(passed_lines=passed,count=13),
 actual_rounds=actual,reports=reports,
 numerical_scope=['Independent one-block CPU/CUDA math remains the preceding qwen-mtp-target evidence; this batch does not rerun that reference.',
 'Natural stream is the first15 original prompt IDs, two rounds only: one normal acceptance and one rejection. No forced state was needed in this run.',
 'Target T2 consumes real device-generated draft ID within the original Graph, one original Completion and atomic complete target/draft head publication.',
 'Quota1 T1 versus T2 row0 differs: hidden relativeL2 .0210089264, logits .0176965488; both greedy271. No quality tolerance/PASS is invented.',
 '90 same-B ordinary vectors remain byte-identical to original archived CLI baseline; cross-B or cross-T math equality is not claimed.',
 '8 capture ranges recorded/0 reused in the finite branch probe; no hot reuse or speedup claim.'],
 remaining=['Actual fourteen-bank native cancellation/failure/retirement injection.',
 'Complete independent MTP protocol/reference and finite quality assessment beyond matching greedy IDs.',
 'Matched MTP peer artifact/strategy and full prefill/decode/VRAM/overall comparison.',
 'Multi-session MTP entry, other systems/native backends, selected-model/quant coverage, image chain and broad architecture scope.'],
 failures_preserved=['writer first link plan used a historical standalone object identity absent from CPU closure; corrected to actual cpu-test object before link.',
 'cli-run1: T1 symbolic token dimension differed from the actual fixed1 MTP hidden contract; fixed token input dimension.',
 'cli-run2: writer-only draft and target external effects lacked a control path; added real draft-value append -> first target-key append edge.',
 'tests-link1: retained CPU closure predates PagedArena::reframe; reused already-current cached arena object, no SDK rebuild.',
 'tests-run2: new test retained the recovered PageWriter in returned Pages after discard; fixed test owner scope, core unchanged.',
 'tests-run1 contains only a failed runner lookup after the unsuccessful link; it is not an executed test.'],
 build_scope=dict(fresh_library_TUs=['src/graph/resources.cc','src/graph_batch/batch.cc','src/graph_batch/paged_append.cc'],
 SDK_builds=0,NVCC_builds=0,full_configures=0,flags='/W4 /WX /O2 /MD; existing original CPU/CUDA closures',
 reused_arena=identity(R/'.scratch/multisequence-batch-20261021/compile2/arena/identity.json')))
save(T/'actual-summary.json',summary)

excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in T.rglob('*')if p.is_file() and p.suffix.lower()not in excluded
 and not any(x in ('tmp','__pycache__')for x in p.relative_to(T).parts)
 and p.name not in ('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1'))
archive=O/(NAME+'.data.zip'); assert not archive.exists()
entries=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  rec=identity(p);rec['entry']=p.relative_to(R).as_posix();z.write(p,rec['entry']);entries.append(rec)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 assert z.namelist()==[e['entry']for e in entries]
 for e in entries:
  data=z.read(e['entry']);assert len(data)==e['bytes']and hashlib.sha256(data).hexdigest()==e['sha256']
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,
 archive_verified=dict(CRC=True,all_entry_SHA256=True,entries=len(entries),original_bytes=sum(x['bytes']for x in entries)),
 previous_evidence=['docs/evidence/correctness/qwen-mtp-target-2026-10-22.json','docs/evidence/correctness/qwen-mtp-weights-2026-10-22.json']))
save(T/'published.json',dict(manifest=identity(manifest),archives=[identity(archive)]))
print(json.dumps(dict(manifest=identity(manifest),archives=[identity(archive)],files=len(entries),raw_bytes=sum(e['bytes']for e in entries)),indent=2))
