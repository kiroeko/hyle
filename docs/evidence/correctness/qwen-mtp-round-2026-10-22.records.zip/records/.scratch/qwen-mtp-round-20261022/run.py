from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent; R=T.parents[1]
sp=importlib.util.spec_from_file_location('build',T/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('mode',choices=('writer','tests','cli','r1','batch','round'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--image-attempt',type=int,default=1);a=p.parse_args()
out=T/f'{a.mode}-run{a.attempt}';out.mkdir(exist_ok=False)
tag=a.mode if a.mode in ('writer','tests','round')else'qwen';ready=c.read(T/f'{tag}-ready-attempt{a.image_attempt}.json')
assert h.same(ready['image']) and h.same(ready['main'])
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
command=[ready['image']['path']]
if a.mode=='cli':
 command+=['--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),'--steps','16','--capacity','64','--mtp','on','--replay','commands','--trace',str(out/'trace')]
elif a.mode=='round':
 command+=[str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),str(T/f'round-output{a.attempt}')]
elif a.mode in ('r1','batch'):
 old=c.read(R/'.scratch/qwen-topone-prepared-20261022'/f'{a.mode}-run1/run.command.json');command=old['command'].copy();command[0]=ready['image']['path'];command[command.index('--trace')+1]=str(out/'trace')
c.save(out/'identity.json',ready);c.save(out/'plan.json',dict(command=command,throughput_evidence=False,SDK_builds=0,native_rebuilds=0))
c.execute('run',command,env,out)
