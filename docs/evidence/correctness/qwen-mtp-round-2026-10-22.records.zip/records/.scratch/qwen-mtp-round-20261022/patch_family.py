from pathlib import Path
p=Path('tools/qwen35_text/main.cc')
s=p.read_text(encoding='utf-8')
a=s.index('    g::NodeId prior_append;');b=s.index('    if (diagnostic)',a)
x=s[a:b];x=x.replace('role == GraphRole::kVerify', 'verifies_two(role)');s=s[:a]+x+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
