from pathlib import Path
p=Path('tools/qwen35_text/main.cc');s=p.read_text(encoding='utf-8')
a=s.index('    const auto &route_directory');b=s.index('    const auto storage = phase.child',a)
x=s[a:b];x=x.replace('const auto label = diagnostic ? "published" : "default";', 'const auto label = std::string(diagnostic ? "published" : "default") + (has_mtp(role) ? "-role" + std::to_string(static_cast<int>(role)) : "");');s=s[:a]+x+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
