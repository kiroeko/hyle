"""Freeze only the two owned private Graph bridge files; no compilation/native work."""
from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[2]
stage = S.parent
files = ("include/hyle/graph/detail/region_access.h", "src/graph/resources.cc")


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


entries = []
for name in files:
    source, before, current = R / name, stage / "before" / name, S / "current" / name
    current.parent.mkdir(parents=True, exist_ok=True)
    current.write_bytes(source.read_bytes())
    diff = S / (Path(name).name + ".diff")
    diff.write_text("".join(difflib.unified_diff(
        before.read_text(encoding="utf-8").splitlines(keepends=True),
        current.read_text(encoding="utf-8").splitlines(keepends=True),
        fromfile="before/" + name, tofile=name)), encoding="utf-8")
    entries.append(dict(source=identity(source), before=identity(before),
                        snapshot=identity(current), diff=identity(diff)))
source = (R / files[1]).read_text(encoding="utf-8")
for token in ("BindingScope::kWriteEffect", "Status RegionAccess::bind_write_effect(",
              "Status RegionAccess::release_write_effect(", "validate_projected_writer(",
              "validate_write_ranges(", "validate_write_conflicts(", "release_writer_preparation("):
    assert token in source
new_bind = source.split("Status RegionAccess::bind_write_effect(", 1)[1].split("bool RegionAccess::successful_outcome", 1)[0]
assert "invocation.bind(" not in new_bind
assert "reserve_reads(" in new_bind and "revoke_preparation(" in new_bind
assert ".projection=" not in new_bind and ".value=" not in new_bind
release = source.split("Status RegionAccess::release_write_effect(", 1)[1].split("Status RegionAccess::release_written_projection", 1)[0]
assert "outcome_available(" in release and "resource_control_ready(" not in release

report = dict(
    status="Source implementation frozen; actual compile and CPU/CUDA proof owned by root, not run here",
    files=entries,
    exact_interface=[
        "RegionAccess::bind_write_effect(Invocation&,const Graph&,compute::ConstTensorView capacity,span<const ReadLease> pages,span<const WriteLease*const> writers,span<const detail::AppendLease*const> appenders,ProjectedWriter,span<const ReadLease> controls,ResourceOptions)",
        "RegionAccess::release_write_effect(Invocation&,NodeId)",
    ],
    ownership_and_validation=[
        "No public InvocationState/ResourceBinding ABI field added. BindingScope is private to resources.cc; each effect use is anonymous, owns its original ReadLease or borrows the typed Slot's stable original WriteLease/AppendLease pointer, and stores the actual selected writer_step.",
        "Cold original resource_control_ready and existing ResourceEpisode required. Validate original Graph generation/node/effect, exact selected singleton region node set, live actual invocation slot, SharedQueue mode, selected vtable/prepared artifact. Different Graph/provider-family-only or unselected node proofs reject.",
        "Common page writer/append range and root checks remain shared with written_projection. Append authority must have reserved bytes and original ready-prefix page proof; ordinary writer/read mixtures and duplicate mutable roots within one bind reject. Program controls are real ReadLeases, not write authority.",
        "Writer-only additionally validates every ready page's actual range in the capacity span. Capacity is a borrowed size/range bound only; no fake ValueId, external input binding, writable whole-bank view or output-ready token is installed.",
        "Cold checks compare mixed existing/new mutable roots, rejecting ordinary read/write or ordinary write/append conflicts and qualifying all same-root append prefixes. Same actual ordinary write root and same actual append authority may still be deduplicated by the original LeasePermissionSet; a different same-root append authority rejects.",
        "Original same-node bind cannot be duplicated across either written-projection or writer-only route until take/release. All validation/allocation precedes revoke and fixed-capacity anonymous record commit. Rejection does not transfer page owners or admit native work.",
        "Original begin_submission iterates these records unchanged and performs real LeasePermissionSet/LeaseUseBatch read/write/append admission. No enqueue, Completion, executor, second permission system or native wait added.",
        "Take/release requires original outcome_available, independently of status/closed. Common writer withdrawal only preserves commands when actual backend stable_binding_identity and exact selected artifact callback prove current carriers survive, under normal Idle&&!closed. Otherwise invalidate the writer's covering recording before owner withdrawal; original written_projection still separately checks its readers.",
        "Writer-only release erases only kWriteEffect anonymous records with this exact selected writer_step, clears stale read lookup ordinals, and leaves all unrelated caller, projection and other-node effect uses intact. Failed/closed actual-retired cleanup remains available.",
        "Configuration reset marks effect-bearing permission spans nonreusable. The typed module must continue requiring take/withdraw of a live transaction in its existing payload reset; this bridge does not invent readiness when anonymous permissions are removed.",
    ],
    complexity="Cold conflict validation compares old reads only with new mutable roots and old mutable roots only with new reads: O(B*(W+A)+M*(P+C)); it does not compare read/read page pairs, add a root registry or allocate hot-path scratch. Existing LeasePermissionSet admission still sorts/deduplicates original roots at submission.",
    actual_validation=dict(source_static_checks="passed", git_diff_check_owned_paths="passed", compile="not run", CPU="not run", CUDA="not run"),
    minimum_root_proof="Original CPU/CUDA reader path plus writer-only CPU/CUDA typed append numerical/permission/failure journeys; standalone zero-reader graph; retained Completion blocks take; duplicate writer bind rejects without losing owner; metadata capture reuse remains exact. Root/vulkan fixtures are separately owned, not declared passed here.",
    stopped_writing=True,
)
out = S / "report.json"
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
freeze = dict(sources=[e["source"] for e in entries], report=identity(out),
              compile=False, GPU=False, stopped_writing=True)
(S / "source-freeze.json").write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
print(json.dumps(freeze, indent=2))
