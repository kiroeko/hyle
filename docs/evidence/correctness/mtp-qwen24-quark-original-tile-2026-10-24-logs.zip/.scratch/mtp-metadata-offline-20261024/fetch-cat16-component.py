"""Separate tiny original Quark followup. Default check has zero HTTP."""
from pathlib import Path
import argparse,importlib.util,inspect,json,math,sys,urllib.request
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];SCRIPT=Path(__file__).resolve().relative_to(R).as_posix();BUDGET=R/'.scratch/mtp-download-budget-20261023/budget.py'
spec=importlib.util.spec_from_file_location('fixed_source_component_transport',S/'fetch-source-components.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);h=old.h;h.SCRIPT=SCRIPT
def identity(p):return old.identity(p)
def check():
 p=h.parse_json((S/'cat16-component-plan.json').read_bytes())
 if len(p['components'])!=1 or p['maximum_HTTP_requests']!=2 or p['total_new_tensor_payload_bytes']!=3264 or p['full_models_or_expert_libraries']:raise ValueError('Exact independent followup bound changed')
 for x in p['helpers']:
  if identity(R/x['path'])!=x:raise ValueError('Reviewed transport changed')
 c=p['components'][0];source=c['source'];folder=S/'indexes/cat16'
 if c['catalog_index']!=16 or c['revision']!='13dc9676cdd9e2374c3efb50389d3392b975acae' or c['id']!='q24-quark-mxfp4-original' or c['full_reduction_K']!=2048 or c['selected_N']!=3:raise ValueError('Exact reviewed source/geometry changed')
 row=dict(repository=c['repository'],revision=c['revision'],file=source['file'],uri=c['uri'])
 if c['uri']!=f'https://hf-mirror.net/{c["repository"]}/resolve/{c["revision"]}/{source["file"]}' or h.crosscheck_tree_identity(row,(folder/'expanded-api.json').read_bytes(),(folder/'tree-api.json').read_bytes())!=source:raise ValueError('Original independent source identity changed')
 for key in ['header','header_acquisition']:
  if identity(R/c[key]['path'])!=c[key]:raise ValueError('Original header proof changed')
 raw=(R/c['header']['path']).read_bytes();schema=h.parse_header(raw,source['size'])['all_physical_tensors'];a=h.parse_json((R/c['header_acquisition']['path']).read_bytes())
 if a['source']!=source or a['header_sha256']!=h.digest(raw):raise ValueError('Original acquisition mismatch')
 if len(c['ranges'])!=2 or {x['kind']for x in c['ranges']}!={'codes','scales'}:raise ValueError('Exactly two original ranges required')
 total=0
 for x in c['ranges']:
  original=schema[x['name']]
  if original!=x['original'] or original['dtype']!='U8' or len(original['shape'])!=2 or math.prod(original['shape'])!=original['data_offsets'][1]-original['data_offsets'][0]:raise ValueError('Original codec/shape changed')
  n=3*original['shape'][1];first=8+len(raw)+original['data_offsets'][0]
  if x['selection']!=dict(axis0_first=0,axis0_count=3,axis1_full=True) or x['selected_shape']!=[3,original['shape'][1]] or x['bytes']!=n or x['absolute_inclusive']!=[first,first+n-1] or (R/x['output']).resolve()!=(S/'components'/c['id']/(x['kind']+'.bin')).resolve():raise ValueError('Exact first3-row/fullK range changed')
  total+=n
 if total!=3264:raise ValueError('Exact byte limit changed')
 return p
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',nargs='?',choices=['check','fetch'],default='check');parser.add_argument('--owner-marker');args=parser.parse_args();p=check()
 if args.action=='check':print(json.dumps(dict(state='offline_cat16_original_tile_valid',bytes=3264,requests=2,HTTP=0)));return
 if args.owner_marker!=p['required_owner_marker']:parser.error('Exact root owner marker required')
 owner=BUDGET.parent/args.owner_marker
 if not owner.is_file()or(BUDGET.parent/'PAUSED').exists():raise RuntimeError('Root does not hold enabled acquisition; zeroHTTP')
 fn=urllib.request.urlopen
 if not inspect.isfunction(fn)or Path(fn.__code__.co_filename).resolve()!=BUDGET.resolve()or inspect.getclosurevars(fn).nonlocals.get('script')!=SCRIPT:raise RuntimeError('Only existing budget.py run may execute HTTP')
 result=old.acquire(h.module(),p['components'][0],owner);h.save(S/'cat16-component-results.json',dict(complete=True,results=[result],original_tensor_bytes=3264));print(json.dumps(dict(complete=True,bytes=3264)))
if __name__=='__main__':main()
