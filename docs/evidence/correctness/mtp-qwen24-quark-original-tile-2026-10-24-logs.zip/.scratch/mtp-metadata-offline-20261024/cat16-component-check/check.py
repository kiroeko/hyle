"""One fresh consumer TU, two original source profiles, no HTTP/SDK build."""
from pathlib import Path
import importlib.util,json,os,sys
O=Path(__file__).resolve().parent;R=O.parents[2];S=O.parent
spec=importlib.util.spec_from_file_location('retained_original_source_builder',S/'source-components/check.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);old.O=O;b=old.b
def preflight():
 p=b.read(S/'cat16-component-plan.json');a=b.read(S/'cat16-component-results.json')
 if not a['complete']or len(a['results'])!=1:raise ValueError('Actual complete original source acquisition missing')
 source=p['components'][0];actual=a['results'][0]
 if actual['source']!=source['source']:raise ValueError('Original identity changed')
 for row in source['ranges']:
  f=next(x for x in actual['ranges']if x['kind']==row['kind'])['file'];now=b.identity(R/row['output'])
  if any(f[k]!=now[k]for k in ['bytes','sha256'])or now['bytes']!=row['bytes']:raise ValueError('Original exact source values changed')
 b.save(O/'preflight.json',dict(plan=b.identity(S/'cat16-component-plan.json'),actual_acquisition=b.identity(S/'cat16-component-results.json'),bytes=3264,HTTP=0,reader_correction='Acquisition description had kBFloat16 typo. Actual intended fixed Quark W4A4 operation is kFloat4Group32, independently checked here; original receipts retained unchanged.'))
def run(backend='*'):
 preflight();ready=b.read(O/'ready.json');b.require(ready['image']);name='run'if backend=='*'else'run-'+backend.lower();test='tests.json'if backend=='*'else'tests-'+backend.lower()+'.json';old.execute([ready['image']['path'],str(S/'components'),'--gtest_filter=Cat16OriginalSource.'+backend,'--gtest_output=json:'+str(O/test)],dict(os.environ,PATH=ready['PATH']),name,120);print((O/name/'stdout.log').read_text())
if __name__=='__main__':
 if sys.argv[1]in('build','all'):old.build()
 if sys.argv[1]in('run','all'):run()
 if sys.argv[1]in('cpu','cuda'):run(sys.argv[1].capitalize())
