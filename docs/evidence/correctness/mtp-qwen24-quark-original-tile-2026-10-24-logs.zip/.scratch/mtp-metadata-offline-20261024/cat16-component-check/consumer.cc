// Reuse the already checked cold Graph fixture and original backend adapters;
// only Cat16OriginalSource.* is run, never the previous eight-source matrix.
#include "tests/compute_models/mxfp4_reference_fixture.h"
#define main retained_eight_source_fixture_main
#include "../source-components/consumer.cc"
#undef main
namespace {
template<class Backend> void original_quark() {
 constexpr std::int64_t k=2048,rows=3;
 const auto root=source_root/"q24-quark-mxfp4-original";
 const auto code=load(root/"codes.bin",3*k/2),sf=load(root/"scales.bin",3*k/32);
 for(auto x:sf)ASSERT_NE(x,std::byte{255});
 auto context=Backend::context();auto owner=Backend::owner(context);auto queue=f::take(context.create_queue(),"queue");
 auto builder=f::take(g::GraphBuilder::create(),"builder");
 const auto ad=f::dense(Type::kBFloat16,{rows,1,k}),wd=f::dense(Type::kUInt8,{1,3,k/2}),sd=f::dense(Type::kUInt8,{1,3,k/32}),idsd=f::dense(Type::kInt32,{rows,2});
 const auto a=f::take(builder.input(ad),"activation"),w=f::take(builder.constant(wd),"original packed"),scale=f::take(builder.constant(sd),"original E8"),ids=f::take(builder.input(idsd),"duplicate source0 IDs");
 const auto wl=f::upload(owner,code),sl=f::upload(owner,sf);
 const std::array bindings{g::ConstantBinding{w,f::take(wl.tensor(wd),"packed tensor"),g::ConstantPolicy::kBorrow,owner,wl},g::ConstantBinding{scale,f::take(sl.tensor(sd),"SF tensor"),g::ConstantPolicy::kBorrow,owner,sl}};
 const auto y=f::take(builder.add(c::model_ops::grouped_mxfp4_linear(c::model_ops::Mxfp4ActivationMode::kFloat4Group32),a,w,scale,ids),"Quark W4A4");
 f::check(builder.publish(y),"publish");auto graph=f::take(std::move(builder).finish(),"finish");const auto yd=f::take(graph.value_description(y),"output");
 auto program=f::take(Backend::compile(graph,context,owner,{.constants=bindings}),"cold original Graph");auto run=f::invocation(program.executable);
 const std::array<std::int64_t,3> positions{0,33,2047};const std::array<float,3> amplitudes{1.25F,6.5F,-1.25F};
 std::vector<double> av(rows*k);for(std::int64_t t=0;t<rows;++t)av[static_cast<std::size_t>(t*k+positions[static_cast<std::size_t>(t)])]=amplitudes[static_cast<std::size_t>(t)];
 const auto al=f::upload(owner,f::floating(Type::kBFloat16,av));const std::array<std::int32_t,6> idv{};const auto il=f::upload(owner,std::as_bytes(std::span(idv)));
 f::check(run.bind(a,ad,al),"bind A");f::check(run.bind(ids,idsd,il),"bind IDs");
 auto pool=f::take(c::LeasePool::create(owner.ref(),f::take(yd.required_bytes(),"Y bytes"),{.max_blocks=1,.backing_alignment=256}),"pool");
 f::check(run.bind(y,yd,f::take(pool.allocate(f::take(yd.required_bytes(),"Y bytes"),256),"writer")),"bind Y");f::submit<Backend>(run,queue,false);
 const auto actual=f::read(f::output(run,y));ASSERT_EQ(actual.size(),18U);std::size_t witness=0;
 for(std::int64_t t=0;t<rows;++t)for(std::int64_t slot=0;slot<2;++slot)for(std::int64_t row=0;row<3;++row) {
  const auto pos=positions[static_cast<std::size_t>(t)];const auto packed=std::to_integer<unsigned>(code[static_cast<std::size_t>(row*(k/2)+pos/2)]);const auto nibble=(packed>>((pos%2)*4))&15U;
  const auto ws=std::to_integer<std::uint8_t>(sf[static_cast<std::size_t>(row*(k/32)+pos/32)]);
  const auto weight=mxfp4_reference_test::weight(nibble,ws),value=amplitudes[static_cast<std::size_t>(t)];
  const auto qa=mxfp4_reference_test::activation(value,std::fabs(value));
  const auto expected=s::rounded_bf16(s::multiply(qa,weight)),wrong=s::rounded_bf16(s::multiply(value,weight));
  EXPECT_EQ(actual[static_cast<std::size_t>((t*2+slot)*3+row)],expected)<<"t="<<t<<" row="<<row;
  if(expected!=wrong)++witness;
 }
 EXPECT_GT(witness,0U);std::cout<<"CAT16 original_codes="<<code.size()<<" original_scales="<<sf.size()<<" K="<<k<<" N=3 checked_outputs="<<actual.size()<<" wrong_W4A16_output_witnesses="<<witness<<"\n";
}
TEST(Cat16OriginalSource,Cpu){original_quark<Cpu>();}
TEST(Cat16OriginalSource,Cuda){original_quark<Cuda>();}
}
int main(int argc,char**argv){return retained_eight_source_fixture_main(argc,argv);}
