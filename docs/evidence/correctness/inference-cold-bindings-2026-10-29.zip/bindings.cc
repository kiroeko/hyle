#include "tests/tools/inference_graph_bindings_case.h"
#include <iostream>
int main() {
  auto result = hyle::inference::test::graph_bindings_case();
  if (!result) { std::cerr << result.error().message() << '\n'; return 2; }
  const auto &f = *result;
  if (f.native_submissions != 4 || f.compared_values != 102 || f.retired_scopes != 2 ||
      f.conflicting_external_rejections != 1 || f.materialized_bytes != 68) return 3;
  std::cout << "{\"status\":\"PASS\",\"native_submissions\":" << f.native_submissions
      << ",\"compared_values\":" << f.compared_values << ",\"retired_scopes\":" << f.retired_scopes
      << ",\"conflicting_external_rejections\":" << f.conflicting_external_rejections
      << ",\"materialized_bytes\":" << f.materialized_bytes << "}\n";
}
