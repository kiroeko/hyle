"""Current real consumers, one refreshed weights TU, retained native SDK."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('original_process',R/'.scratch/inference-program-identity-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
BASE=R/'.scratch/inference-commit-observation-20261029/model-link-base.json'

def prepare():
    base=read(BASE)
    for item in base['retained']: exact(item)
    exact(base['runtime'])
    sdk=read(base['sdk_engine_dependencies']['path'])
    weights=next(u for u in sdk['engine_consumers'] if any(
        key(p['path'])==key(R/'engine/models/qwen35/weights.cc') for p in u['source_identities']))
    changed=[]
    for u in sdk['engine_consumers']:
        for item in u['source_identities']:
            if key(item['path'])==key(R/'engine/inference/backend.h'):
                changed.append(dict(unit=u['object'],before=item,after=pin(item['path'])))
            else: exact(item)
    assert len(changed)==1
    sources=[('qwen',R/'tests/tools/qwen_host_image_test.cc'),
             ('ordinary',R/'tests/tools/qwen_generation_batch_relay_probe.cc'),
             ('glm',R/'tests/compute_models/glm_pro_original_early_history_test.cc'),
             ('slots',R/'tests/tools/inference_slot_transactions_test.cc'),
             ('bindings',W/'bindings.cc'),('weights',R/'engine/models/qwen35/weights.cc')]
    old_source=base['consumer_source']['path']
    old_object=read(base['previous_consumer']['path'])['object']['path']
    template=read(R/'.scratch/inference-system-review-20261025/glm-pro-early-history/attempt7/compile/command.json')['command']
    units={}
    for name,source in sources:
        folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
        args=[]
        for index,arg in enumerate(base['compile']):
            if index and base['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            elif key(arg)==key(old_source):arg=str(source)
            args.append(arg)
        if name in ('glm','slots'):
            args += [a for a in template if (a.startswith('/external:I') and 'googletest' in a) or
                     (name=='glm' and a=='/DHYLE_TEST_GLM_STATE_CUDA=1')]
        units[name]=dict(source=str(source),compile=args)
        if name=='weights':continue
        link=[]
        for arg in base['link']:
            if key(arg)==key(old_object):arg=str(folder/'unit.obj')
            elif key(arg)==key(weights['object']):arg=str(W/'compile/weights/unit.obj')
            for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
                if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
            link.append(arg)
        if name in ('glm','slots'):
            link += [str(R/'.scratch/build-compute-v2-dev/lib'/lib) for lib in ('gtest_main.lib','gtest.lib')]
        assert sum(key(a)==key(source) for a in args)==1
        assert sum(key(a)==key(folder/'unit.obj') for a in link)==1
        units[name]['link']=link
    (W/'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    fixtures=read(R/'.scratch/inference-episode-release-20261029/plan.json')['fixtures']
    ordinary=W/'ordinary-input';ordinary.mkdir(exist_ok=True)
    for f in ('weights.tsv','prompt.ids'):
        shutil.copyfile(R/'.scratch/inference-episode-release-20261029/ordinary-input'/f,ordinary/f)
    glm_env=read(R/'.scratch/inference-system-review-20261025/glm-pro-early-history/attempt7/actual-inputs.json')
    for k,p in glm_env.items():
        if k.startswith('HYLE_GLM_'):assert Path(p).exists(),k
    cases={
      'slots-cpu':['slots','--gtest_color=no','--gtest_filter=InferenceSlotTransactions.*'],
      'bindings-cpu-cuda':['bindings'],
      'controls-cpu':['qwen','--cpu',fixtures['conditional']['directory'],'--natural-logits-control'],
      'mtp-cuda':['qwen','--cuda',fixtures['natural']['directory'],'--mtp-natural-relay'],
      'ordinary-cuda':['ordinary','--cuda-continuous',str(ordinary)],
      'glm-cuda':['glm','--gtest_color=no','--gtest_filter=GlmProOrdinaryEarlyHistoryPlan.*:GlmProOrdinaryEarlyHistory.*']}
    save(W/'plan.json',dict(base=pin(BASE),units=units,retained=base['retained'],runtime=base['runtime'],
         sdk=base['sdk_engine_dependencies'],original_weights=weights['object'],changed_SDK_source=changed,
         fixtures=fixtures,glm_environment=glm_env,cases=cases,
         counts=dict(consumer_CXX=5,refreshed_weights_CXX=1,links=5,native_cases=6,unchanged_SDK_inputs=226,NVCC=0,downloads=0)))
    print('Prepared 5 consumers + 1 refreshed weights TU, 226 unchanged SDK inputs, 6 finite cases; no compile/run started.')

def receipt(name):
    r=read(W/'compile'/name/'receipt.json');exact(r['object'])
    for p in r['source_identities']:exact(p)
    return r

def main():
    action=sys.argv[1]
    if action=='prepare':prepare();return
    plan=read(W/'plan.json');name=sys.argv[2]
    suffix=None if len(sys.argv)<4 else sys.argv[3]
    if action=='compile':
        folder=W/'compile'/name/('process' if suffix is None else 'process-'+suffix)
        if (W/'compile'/name/'receipt.json').exists():
            shutil.copyfile(W/'compile'/name/'receipt.json',W/'compile'/name/('receipt-before-'+str(suffix)+'.json'))
            shutil.copyfile(W/'compile'/name/'dependencies.json',W/'compile'/name/('dependencies-before-'+str(suffix)+'.json'))
        b.execute(plan['units'][name]['compile'],folder,240)
        deps=read(W/'compile'/name/'dependencies.json')['Data']
        paths=sorted({Path(p).resolve() for p in [deps['Source'],*deps['Includes']] if Path(p).is_relative_to(R)})
        save(W/'compile'/name/'receipt.json',dict(object=pin(W/'compile'/name/'unit.obj'),process=pin(folder/'process.json'),source_identities=[pin(p) for p in paths]))
    elif action=='link':
        receipt(name);receipt('weights')
        for p in plan['retained']:
            if key(p['path'])!=key(plan['original_weights']):exact(p)
        folder=W/'link'/name
        if suffix:folder/=suffix
        b.execute(plan['units'][name]['link'],folder,180)
        save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
    elif action=='run':
        unit,*args=plan['cases'][name];receipt(unit)
        image=read(W/('ready-'+unit+'.json'));exact(image)
        folder=W/'runs'/name
        if suffix:folder/=suffix
        if unit in ('slots','glm'):
            args+=['--gtest_output=xml:'+str(folder/'results.xml')]
        if unit=='glm':os.environ.update(plan['glm_environment'])
        b.execute([image['path'],*args],folder,600 if unit=='glm' else 300)
        if unit in ('slots','glm'):
            import xml.etree.ElementTree as ET
            root=ET.parse(folder/'results.xml').getroot()
            assert int(root.get('tests'))>0 and root.get('failures')=='0' and not root.findall('.//skipped')
            print('PASS',name,root.get('tests'),'real tests')
        else:
            result=read(folder/'stdout.log');assert result['status']=='PASS'
            save(folder/'report.json',result);print('PASS',name)
    else:raise ValueError(action)
if __name__=='__main__':main()
