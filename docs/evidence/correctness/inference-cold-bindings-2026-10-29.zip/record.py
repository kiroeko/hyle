from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('current_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
plan=read(W/'plan.json')
cases={}
for name in plan['cases']:
    folder=W/'runs'/name
    if name=='bindings-cpu-cuda':folder/='pinned'
    process=read(folder/'process.json')
    assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
    if name in ('slots-cpu','glm-cuda'):
        root=ET.parse(folder/'results.xml').getroot()
        assert root.get('failures')=='0' and not root.findall('.//skipped')
        expected=4 if name=='slots-cpu' else 3
        assert int(root.get('tests'))==expected
        report=dict(tests=expected,properties={p.get('name'):p.get('value') for p in root.findall('.//property')})
    else:
        report=read(folder/'report.json');assert report['status']=='PASS'
    cases[name]=dict(process=process,report=report)
assert cases['bindings-cpu-cuda']['report']['native_submissions']==4
assert cases['bindings-cpu-cuda']['report']['compared_values']==102
assert cases['controls-cpu']['report']['target_submissions']==9
assert all(r['payloads_byte_equal'] for r in cases['controls-cpu']['report']['state_checks'])
assert cases['mtp-cuda']['report']['original_ledger_equal'] and cases['mtp-cuda']['report']['generated_ids_equal']
assert all(r['payloads_byte_equal'] for r in cases['mtp-cuda']['report']['state_checks'])
assert cases['ordinary-cuda']['report']['control_and_candidate_arms']==16
assert cases['ordinary-cuda']['report']['complete_prefix_state_epoch_rng_equal']
assert cases['glm-cuda']['report']['properties']['actual_selected_widths']=='1,2,3,4'
failed=read(W/'runs/bindings-cpu-cuda/process.json')
assert failed['state']=='TERMINAL' and failed['exit']==2 and not failed['timed_out']
assert 'no configured target can materialize' in (W/'runs/bindings-cpu-cuda/stderr.log').read_text()
builds={}
for name in plan['units']:
    receipt=b.receipt(name)
    processes=[read(p) for p in sorted((W/'compile'/name).glob('process*/process.json'))]
    links=[read(p) for p in sorted((W/'link'/name).rglob('process.json'))] if name!='weights' else []
    assert all(p['state']=='TERMINAL' and p['exit']==0 and not p['timed_out'] for p in processes+links)
    builds[name]=dict(compiles=processes,links=links,object=receipt['object'],source_inputs=len(receipt['source_identities']))
retained=[pin(W/'compile/weights/unit.obj') if key(p['path'])==key(plan['original_weights']) else p for p in plan['retained']]
for p in retained:exact(p)
assert len(retained)==227
sdk=read(plan['sdk']['path'])
weights_receipt=read(W/'compile/weights/receipt.json')
for unit in sdk['engine_consumers']:
    if key(unit['object'])==key(plan['original_weights']):
        unit.update(object=str(W/'compile/weights/unit.obj'),source_identities=weights_receipt['source_identities'],
                    dependencies=pin(W/'compile/weights/dependencies.json'))
save(W/'sdk-engine-dependencies.json',sdk)
base=read(plan['base']['path'])
base.update(schema='hyle.cold-bindings.current-link-base.v1',base=plan['base'],
    compile=plan['units']['qwen']['compile'],link=plan['units']['qwen']['link'],retained=retained,
    consumer_source=pin(R/'tests/tools/qwen_host_image_test.cc'),previous_consumer=pin(W/'compile/qwen/receipt.json'),
    source_freeze=pin(W/'compile/qwen/receipt.json'),sdk_engine_dependencies=pin(W/'sdk-engine-dependencies.json'),
    reuse_note='Actual current qwen_host_image consumer compile/link. Replace consumer source and object for a different consumer. 226 original SDK inputs plus one refreshed weights TU for the Backend readonly storage-domain getter.')
save(W/'model-link-base.json',base)
source_names=['engine/inference/graph_bindings.h','engine/inference/backend.h','engine/inference/slot_transactions.h',
    'engine/models/qwen35/main.cc','tests/compute_models/glm_pro_original_early_history_test.cc',
    'tests/tools/inference_graph_bindings_case.h','tests/tools/inference_slot_transactions_test.cc',
    'tests/tools/qwen_backend_cpu_cuda_test.cc','tests/tools/inference_history_math_case.h',
    'tests/tools/inference_mtp_packet_case.h','tests/tools/qwen_logits_modifier_case.h',
    'tests/tools/qwen_mtp_logits_case.h','tests/tools/qwen_mtp_projection_width_probe.cc']
source_pins=[pin(R/p) for p in source_names]
prior=read(W/'compile/bindings/receipt-before-pinned.json')
old_header=next(p for p in prior['source_identities'] if p['path'].endswith('inference_graph_bindings_case.h'))
snapshot=pin(W/'source-before/inference_graph_bindings_case.h')
assert all(snapshot[k]==old_header[k] for k in ('bytes','sha256'))
archive=R/'docs/evidence/correctness/inference-cold-bindings-2026-10-29.zip'
files=[]
for pattern in ('*.py','*.cc','plan.json','sdk-engine-dependencies.json','model-link-base.json',
                'compile/**/*.json','compile/**/*.log','link/**/*.json','link/**/*.log',
                'runs/**/*.json','runs/**/*.log','runs/**/*.xml','source-before/*.h'):
    files.extend(W.glob(pattern))
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(set(files)):z.write(path,str(path.relative_to(W)).replace('\\','/'))
    for name in source_names:z.write(R/name,'source/'+name)
report=dict(schema='hyle.correctness.cold-bindings.v1',date='2026-10-29',status='PASS_WITH_PRESERVED_QUALIFICATION_FAILURE',
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    change='Share actual cold constant/domain/placement assembly across Qwen and original GLM early-history components; use immutable physical layout item bytes and per-Invocation batch-planning arrays without keeping extra layout aliases.',
    counts=dict(CXX_attempts=7,consumer_CXX_final=5,refreshed_engine_weights_CXX=1,links=6,
        unchanged_SDK_inputs=226,current_SDK_inputs=227,NVCC=0,full_SDK_builds=0,
        native_processes=7,passed_finite_cases=6,preserved_materialization_qualification_failures=1,downloads=0),
    builds=builds,cases=cases,source_inputs=source_pins,archive=pin(archive),
    correction='First binding process completed its Borrow phase, then original Graph rejected materializing ordinary CPU memory into CUDA because no configured target qualified both resources. Corrected helper source to original CUDA pinned-host staging owner/lease; no Graph check, source qualification or transfer route was changed. Source snapshot and failure logs are preserved.',
    boundaries=[
      'GraphBindings only assembles original cold metadata. Exact source-resource matches can infer a domain; explicit nomination and nonexact native readonly imports retain original Graph validation.',
      'Materialize names the destination, not the source domain. Final helper performs 4 explicit Graph submissions plus original Graph cold materialization; cold-copy submission is not included in its Graph counter.',
      'Native Apple readonly-import capability was source-reviewed at executable.cc and apple_memory.mm, not run on Apple this turn; Vulkan not run.',
      'Qwen K2 control and ordinary 16 arms use finite untrained GA/H64 fixtures; trained Qwen CUDA natural K1 uses cached 2B weights, P154/O40, full ledger/IDs/state match without throughput measurement.',
      'GLM actual index74, short target77/MoE and full vocabulary at positions0..3 use fixtures for intervening upstream computation; not complete78-layer GLM, model quality or throughput.',
      'Existing GTest wrapper and projection-width probe migration are source-reviewed; binding helper body and current Qwen consumer including changed math/packet helpers were compiled. Only the 6 listed finite cases ran.',
      'No claim that complete model-independent orchestration, MTP member withdrawal, all model combinations, multiple GPUs or distributed execution are finished.'])
save(R/'docs/evidence/correctness/inference-cold-bindings-2026-10-29.json',report)
print('Recorded 6 passed finite cases, 7 native processes, 4 original Slot tests and actual GLM component; archive',archive.stat().st_size,'bytes.')
