from pathlib import Path
import re
R = Path(__file__).resolve().parents[2]
paths = ['engine/models/qwen35/main.cc','tests/tools/inference_mtp_packet_case.h',
         'tests/tools/inference_history_math_case.h','tests/tools/qwen_mtp_projection_width_probe.cc',
         'tests/tools/qwen_logits_modifier_case.h','tests/tools/qwen_mtp_logits_case.h']
for relative in paths:
    path = R/relative
    source = path.read_text(encoding='utf-8')
    updated, count = re.subn(r'assembly\.constants\b(?!\s*\()', 'assembly.constants()', source)
    assert count, relative
    path.write_text(updated, encoding='utf-8', newline='\n')
    print(relative, count)
