"""Preserve the original refusal, corrected real execution and reusable SDK closure."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-backend-budget-2026-10-29.json'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def absolute_pin(path):
    p = Path(path).resolve()
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.file_digest(p.open('rb'), 'sha256').hexdigest())

def pin(path):
    item = absolute_pin(path)
    p = Path(item['path'])
    if p.is_relative_to(R):
        item['path'] = p.relative_to(R).as_posix()
    return item

plan = read(W / 'plan.json')
baseline = read(W / 'runs/baseline/process.json')
candidate = read(W / 'runs/candidate/process.json')
assert baseline['state'] == candidate['state'] == 'TERMINAL'
assert not baseline['timed_out'] and not candidate['timed_out']
assert baseline['exit'] == 2 and candidate['exit'] == 0
assert 'resource is absent from budget' in (W / 'runs/baseline/stderr.log').read_text()
report = read(W / 'runs/candidate/report.json')
assert report == dict(status='PASS', host_submissions=2, cuda_submissions=2, compared_values=68,
                      missing_resource_rejections=1, retired_scopes=3, cuda_workspace_bytes=68)
builds = {}
for name in plan['units']:
    process = read(W / 'compile' / name / 'process/process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    receipt = read(W / 'compile' / name / 'receipt.json')
    actual = absolute_pin(receipt['object']['path'])
    assert actual == receipt['object']
    if name != 'baseline':
        for item in receipt['source_identities']:
            assert absolute_pin(item['path']) == item
    builds[name] = dict(process=process, object=pin(receipt['object']['path']),
                        source_inputs=len(receipt['source_identities']))

snapshots = W / 'source'
snapshots.mkdir(exist_ok=True)
before = subprocess.check_output(['git', 'show', '22d6735cf:engine/inference/backend.h'], cwd=R)
(snapshots / 'backend-before.h').write_bytes(before)
(snapshots / 'backend-after.h').write_bytes((R / 'engine/inference/backend.h').read_bytes())
(snapshots / 'budget-case.h').write_bytes((R / 'tests/tools/inference_backend_budget_case.h').read_bytes())
baseline_header = next(p for p in read(W / 'compile/baseline/receipt.json')['source_identities']
                       if Path(p['path']) == R / 'engine/inference/backend.h')
assert baseline_header['sha256'] == hashlib.sha256(before).hexdigest()

# This is the actual new linked closure, not a rewritten claim about the old
# consumer: candidate main is the small budget helper and its own OBJ remains.
sdk = plan['sdk']
weights_receipt = read(W / 'compile/weights/receipt.json')
for item in sdk['engine_consumers']:
    if Path(item['object']) == Path(plan['original_weights']):
        item['object'] = weights_receipt['object']['path']
        item['original_receipt'] = absolute_pin(W / 'compile/weights/receipt.json')
        item['source_identities'] = weights_receipt['source_identities']
        item['engine_dependencies'] = [p['path'] for p in weights_receipt['source_identities']
                                       if Path(p['path']).is_relative_to(R / 'engine')]
    else:
        for source in item['source_identities']:
            actual = absolute_pin(source['path'])
            assert Path(actual['path']) == Path(source['path']) and all(
                actual[key] == source[key] for key in ('bytes', 'sha256'))
save(W / 'sdk-engine-dependencies.json', sdk)
retained = [weights_receipt['object'] if Path(p['path']) == Path(plan['original_weights']) else p
            for p in plan['retained']]
assert len(retained) == 227
for item in retained:
    assert absolute_pin(item['path']) == item
consumer = read(W / 'compile/candidate/receipt.json')
save(W / 'source-freeze.json', consumer['source_identities'])
old = read(plan['base']['path'])
base = dict(schema='hyle.backend-budget.current-link-base.v1', base=plan['base'],
    compile=plan['units']['candidate']['compile'], link=plan['units']['candidate']['link'],
    consumer_source=absolute_pin(W / 'main.cc'), previous_consumer=absolute_pin(W / 'compile/candidate/receipt.json'),
    retained=retained, runtime=plan['runtime'], source_freeze=absolute_pin(W / 'source-freeze.json'),
    sdk_engine_dependencies=absolute_pin(W / 'sdk-engine-dependencies.json'),
    reuse_note='Actual current budget-helper compile/link and 227 SDK inputs, including one refreshed engine weights TU. Future model consumers must explicitly replace consumer_source and consumer OBJ; no trained Model was compiled here.')
for key in ('fixture', 'prompt', 'local_weight_sources'):
    base[key] = old[key]
save(W / 'model-link-base.json', base)

archive = OUT.with_suffix('.zip')
members = {W / name for name in ('main.cc', 'build.py', 'record.py', 'plan.json',
    'sdk-engine-dependencies.json', 'source-freeze.json', 'model-link-base.json')}
for parent in ('compile', 'link', 'runs', 'source'):
    members.update(p for p in (W / parent).rglob('*') if p.is_file() and p.suffix in ('.cc', '.h', '.json', '.log'))
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(members):
        assert path.name != 'environment.json'
        z.write(path, path.relative_to(W).as_posix())
result = dict(schema='hyle.correctness.backend-budget.v1', date='2026-10-29',
    status='CONFIRMED_ORIGINAL_REFUSAL_AND_CORRECTED_NATIVE_BUDGET_COMBINATIONS',
    change='Remove mixed-Backend all-configured-domain usage precheck. Original Graph admission remains responsible for actual compile/workspace/output resource charges; idle domains need no budget row.',
    counts=dict(helper_CXX=2, refreshed_engine_weights_CXX=1, links=2, original_SDK_inputs=227,
                unchanged_SDK_inputs=226, NVCC=0, full_SDK_builds=0, native_processes=2,
                expected_baseline_refusals=1, unexpected_native_failures=0, graph_submissions_after_fix=4,
                compared_values=68, missing_used_resource_rejections=1, retired_budget_scopes=3, downloads=0),
    baseline=dict(source_commit='22d6735cf', process=baseline, graph_submissions=0,
                  result='Original CPU+CUDA Backend rejects a legal required-CPU/host-only graph: resource is absent from budget.'),
    candidate=dict(process=candidate, report=report,
        result='CPU and CUDA each replay twice with only actual managed resource rows; actual missing GPU workspace still rejects without submission.'),
    builds=builds,
    sources=[pin(R / p) for p in ('engine/inference/backend.h', 'tests/tools/inference_backend_budget_case.h',
                                  'tests/tools/qwen_backend_cpu_cuda_test.cc')],
    reuse_base=pin(W / 'model-link-base.json'), archive=pin(archive),
    boundaries=[
        'The exact permanent helper body was compiled/run via a small standalone main. Its added GTest wrapper was not separately built/run.',
        'Actual native CPU/CUDA endpoints and original Graph Invocation/Queue/Completion are used; no model weights or fake completion.',
        'ResourceBudget has allow_unattributed=true as the existing provider-private contract requires. Known resource rows still reject missing actual GPU workspace.',
        'The input buffer is caller-owned outside the measured graph budget. This is scoped managed admission, not a total-VRAM guarantee.',
        'Region selection is disabled to retain a real intermediate workspace. Reported GPU workspace is 68 requested bytes; physical driver allocation size is not inferred.',
        'Budget rows and opaque counters return to each pre-graph baseline after original retirement.',
        'Only the engine weights TU whose dependencies contain Backend was refreshed; SDK core objects remain unchanged. No inference throughput/quality conclusion.',
        'The four Source/MTP/pipeline checks recorded in inference-episode-release preceded this separate cold-budget correction; they were not silently relabeled as rerun.'])
save(OUT, result)
print('Recorded original refusal, corrected 4 submissions/68 values, real missing-resource rejection; archive', archive.stat().st_size, 'bytes')

