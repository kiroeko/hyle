#include "../../tests/tools/inference_backend_budget_case.h"
#include <cstdio>
int main() {
  const auto result = hyle::inference::test::backend_budget_case();
  if (!result) {
    const auto message = result.error().message();
    std::fprintf(stderr, "%.*s\n", static_cast<int>(message.size()), message.data());
    return 2;
  }
  const auto &r = *result;
  std::printf("{\"status\":\"PASS\",\"host_submissions\":%zu,\"cuda_submissions\":%zu,\"compared_values\":%zu,\"missing_resource_rejections\":%zu,\"retired_scopes\":%zu,\"cuda_workspace_bytes\":%zu}\n", r.host_submissions, r.cuda_submissions, r.compared_values, r.missing_resource_rejections, r.retired_scopes, r.cuda_workspace_bytes);
  return 0;
}
