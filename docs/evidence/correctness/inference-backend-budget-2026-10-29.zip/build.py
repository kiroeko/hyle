"""One real budget helper before/after; retain SDK except its refreshed weights TU."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('budget_process', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = W
read, save, pin, key, exact = b.read, b.save, b.pin, b.key, b.exact

def prepare():
    base = read(b.BASE)
    for item in base['retained']:
        exact(item)
    exact(base['runtime'])
    sdk = read(base['sdk_engine_dependencies']['path'])
    for unit in sdk['engine_consumers']:
        for item in unit['source_identities']:
            exact(item)
    old_source = R / 'tests/tools/qwen_host_image_test.cc'
    old_object = read(base['previous_consumer']['path'])['object']['path']
    weights = next(u for u in sdk['engine_consumers'] if any(
        key(p['path']) == key(R / 'engine/models/qwen35/weights.cc') for p in u['source_identities']))
    units = {}
    for name, source in [('baseline', W / 'main.cc'), ('candidate', W / 'main.cc'),
                         ('weights', R / 'engine/models/qwen35/weights.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index - 1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(old_source):
                arg = str(source)
            args.append(arg)
        units[name] = dict(source=str(source), compile=args)
        if name == 'weights':
            continue
        link = []
        for arg in base['link']:
            if key(arg) == key(old_object):
                arg = str(folder / 'unit.obj')
            elif name == 'candidate' and key(arg) == key(weights['object']):
                arg = str(W / 'compile/weights/unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link.append(arg)
        units[name]['link'] = link
    import shutil
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    save(W / 'plan.json', dict(base=pin(b.BASE), units=units, retained=base['retained'],
        runtime=base['runtime'], sdk=sdk, original_weights=weights['object']))
    print('Prepared standalone helper baseline/candidate and one refreshed engine weights TU; no SDK/NVCC build or model download.')

def verify_receipt(name):
    receipt = read(W / 'compile' / name / 'receipt.json')
    exact(receipt['object'])
    for item in receipt['source_identities']:
        exact(item)
    return receipt

def main():
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
        return
    plan = read(W / 'plan.json')
    name = sys.argv[2]
    if action == 'compile':
        b.execute(plan['units'][name]['compile'], W / 'compile' / name / 'process', 240)
        deps = read(W / 'compile' / name / 'dependencies.json')['Data']
        paths = sorted({Path(p).resolve() for p in [deps['Source'], *deps['Includes']]
                        if Path(p).is_relative_to(R)})
        save(W / 'compile' / name / 'receipt.json', dict(object=pin(W / 'compile' / name / 'unit.obj'),
            source_identities=[pin(p) for p in paths]))
    elif action == 'link':
        verify_receipt(name)
        if name == 'candidate':
            verify_receipt('weights')
        for item in plan['retained']:
            if name != 'candidate' or key(item['path']) != key(plan['original_weights']):
                exact(item)
        b.execute(plan['units'][name]['link'], W / 'link' / name, 180)
        save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))
    elif action == 'run':
        image = read(W / ('ready-' + name + '.json'))
        exact(image)
        try:
            b.execute([image['path']], W / 'runs' / name, 120)
        except SystemExit:
            if name != 'baseline':
                raise
        process = read(W / 'runs' / name / 'process.json')
        assert process['state'] == 'TERMINAL' and not process['timed_out']
        if name == 'baseline':
            assert process['exit'] == 2
            assert 'resource is absent from budget' in (W / 'runs' / name / 'stderr.log').read_text()
            print('CONFIRMED original Backend refuses the legal CPU-only graph before any native submission.')
        else:
            assert process['exit'] == 0
            report = read(W / 'runs' / name / 'stdout.log')
            assert report['status'] == 'PASS'
            assert report['host_submissions'] == report['cuda_submissions'] == 2
            assert report['compared_values'] == 68 and report['retired_scopes'] == 3
            assert report['missing_resource_rejections'] == 1 and report['cuda_workspace_bytes'] > 0
            save(W / 'runs' / name / 'report.json', report)
            print('PASS actual endpoint budgets, 68 outputs, original retirement and missing-used-resource rejection.')
    else:
        raise ValueError(action)

if __name__ == '__main__':
    main()
