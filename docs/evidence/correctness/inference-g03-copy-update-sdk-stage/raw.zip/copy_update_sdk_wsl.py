from pathlib import Path
import json,hashlib,os,subprocess,time
base=Path('/root/hyle-scratch/compute-unified');canonical=Path('/mnt/c/public/project-hyle/hyle')
source=base/'source-7a7b4c3b';out=canonical/'.scratch/inference-gaps/g03/copy-update-sdk-wsl';out.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
record=out/'result.json';rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
def run(mode,stage,args):
 attempt=1+sum(r['mode']==mode and r['stage']==stage for r in rows);log=out/f'{mode}-{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as stream:
  process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps({'state':'RUNNING','mode':mode,'stage':stage,'pid':process.pid,'log':str(log)}))
  print('RUN',mode,stage,'PID',process.pid,flush=True);code=process.wait()
 rows.append({'mode':mode,'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)})
 record.write_text(json.dumps({'candidate':'bcaec010b528e372671f737f40b4aa53eb076aaf','stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n')
 if code:
  print(log.read_text(errors='replace')[-6500:],flush=True)
  (out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code}));raise SystemExit(code)
def done(mode,stage):return next((r for r in reversed(rows) if r['mode']==mode and r['stage']==stage),{}).get('exit_code')==0
for mode in ['static','shared']:
 producer=base/f'l-cpu-cuda/selected-graph/{mode}-sdk-build'
 work=base/f'g03-copy-update-cuda-{mode}-sdk';work.mkdir(exist_ok=True)
 stage=work/'staging';prefix=work/'relocated';parent=work/'consumer';parent.mkdir(exist_ok=True);build=work/'consumer-build'
 if not done(mode,'producer-build'):run(mode,'producer-build',['cmake','--build',str(producer),'--target','hyle_compute','hyle_compute_batch','hyle_compute_backend_cuda','--parallel','4'])
 if not done(mode,'install'):
  assert not prefix.exists();run(mode,'install',['cmake','--install',str(producer),'--prefix',str(stage)])
 if stage.exists():assert not prefix.exists();stage.rename(prefix)
 data=(canonical/'tests/compute_batch/copy_update_public_consumer.cc').read_bytes();(parent/'main.cc').write_bytes(data)
 (out/(mode+'-consumer-input.json')).write_text(json.dumps({'sha256':hashlib.sha256(data).hexdigest(),'unmodified':True})+'\n')
 for header in ['batch_transfer.h','resource_leases.h','backends/cuda.h']:
  assert (prefix/'include/hyle/compute'/header).read_bytes()==(canonical/'include/hyle/compute'/header).read_bytes(),header
 for i,name in enumerate(['batch_transfer.h','resource_leases.h','backends/cuda.h']):(parent/f'header-{i}.cc').write_text(f'#include <hyle/compute/{name}>\n')
 (parent/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g03_cuda_public_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(consumer main.cc)
add_executable(cpu main.cc)
target_compile_definitions(consumer PRIVATE HYLE_COPY_UPDATE_CUDA=1)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc)
foreach(t consumer cpu headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${t} PRIVATE hyle::compute)
endforeach()
hyle_stage_runtime(consumer)
hyle_stage_runtime(cpu)
''')
 run(mode,'consumer-configure',['cmake','-S',str(parent),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 run(mode,'consumer-build',['cmake','--build',str(build),'--target','consumer','cpu','headers','--parallel','4'])
 commands=json.loads((build/'compile_commands.json').read_bytes())
 assert len(commands)==5 and all(str(prefix/'include') in c['command'] and str(source) not in c['command'] for c in commands)
 (out/(mode+'-public-compile-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
 run(mode,'tiny-public-cuda',[str(build/'consumer')])
 run(mode,'public-cpu',[str(build/'cpu')])
 print('PASS',mode,'relocated public compute CPU/CUDA65',flush=True)
(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':0}))
