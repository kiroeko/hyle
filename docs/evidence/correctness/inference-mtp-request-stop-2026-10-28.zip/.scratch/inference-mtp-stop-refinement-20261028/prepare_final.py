"""Compose independent final recipes from the preserved diagnostic helper."""
from pathlib import Path
import ast
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
F = W / 'final'
OLD_SHA = 'bdebe48a57e464b3046fdfaa4d8a91d12149b95748d6a0a3fa3d280e7b50d8e9'
SHA = 'aa8bea3bc5dde060536268d82abd11cd2baffc998596dc53af4220a49e64cc9c'
if F.exists():
    raise RuntimeError('final directory exists; do not overwrite')
assert hashlib.sha256((R / 'tests/tools/qwen_mtp_stop_case.h').read_bytes()).hexdigest() == SHA
original = W / 'diagnostic/build.py'
build = original.read_text(encoding='utf-8')
assert build.count(OLD_SHA) == 1
build = build.replace(OLD_SHA, SHA)
build = build.replace("BASE = R / '.scratch/inference-mtp-stop-policy-20261028'",
    "BASE = R / '.scratch/inference-mtp-stop-policy-20261028'\nCURRENT = R / '.scratch/inference-mtp-stop-refinement-20261028/diagnostic'")
build = build.replace("ready = t.read(BASE / 'ready-tiny.json')", "ready = t.read(CURRENT / 'ready-tiny.json')")
build = build.replace("baseline=t.pin(BASE / 'ready-tiny.json')", "baseline=t.pin(CURRENT / 'ready-tiny.json')")
build = build.replace('diagnostic_only=True', 'diagnostic_only=False')
build = build.replace('DIAGNOSTIC', 'FINAL')
build = build.replace("run_contract='Real CPU diagnostic retains original strict require; exit1 is a preserved failure, not PASS.'",
    "run_contract='Final CPU/CUDA consumer; explicit wrapper restoration oracle plus full state checks. Any failure preserved; no retry.'")
# Run only through the explicit final CPU/CUDA parser; remove the diagnostic
# action so its deliberately non-PASS handling cannot be mistaken for final.
start = build.index('\ndef run_cpu():')
end = build.index("\n\nif __name__ == '__main__':", start)
build = build[:start] + build[end:]
build = build.replace("    elif action == 'run-cpu': run_cpu()\n", '')
run_source = R / '.scratch/inference-mtp-stop-policy-20261028/run.py'
run = run_source.read_text(encoding='utf-8')
assert run.count('7591ddb22ad2611a7f3802f5d6245440c62020bc154d5c5ed93e1c899926d451') == 1
run = run.replace('7591ddb22ad2611a7f3802f5d6245440c62020bc154d5c5ed93e1c899926d451', SHA)
run = run.replace("b.validate('tiny')", 'b.validate()')
run = run.replace("    checks = report['state_checks']", "    assert report['rebuild_sampling_wrapper'] is True\n    checks = report['state_checks']")
ast.parse(build); ast.parse(run)
F.mkdir()
(F / 'build.py').write_text(build, encoding='utf-8')
(F / 'run.py').write_text(run, encoding='utf-8')
proof = dict(status='FINAL_HELPERS_PREPARED_ONLY', header_sha256=SHA,
    baseline='diagnostic/ready-tiny.json with the same original 228 SDK closure',
    original_diagnostic_helper_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    final_build_sha256=hashlib.sha256((F / 'build.py').read_bytes()).hexdigest(),
    final_run_sha256=hashlib.sha256((F / 'run.py').read_bytes()).hexdigest(),
    CXX=1, links=1, planned_runs=['cpu', 'cuda'], Host_recompile=0, SDK_recompile=0,
    parser='Five p::compare entries plus bonus strict same_image; require rebuild_sampling_wrapper=true.',
    preserves=['original CPU failure PID19396', 'diagnostic CPU failure PID48484', 'all original images/objects/source/logs'])
(F / 'helper-derivation.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
