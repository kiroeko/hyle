"""Explicit single-use CPU/CUDA MTP stop journey; parse separately, never rerun."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('mtp_stop_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
SOURCES = {
    'tests/tools/qwen_host_image_test.cc': 'f646dd99fff3207f94af5d4a5c5a0b0f8eb8dcb7f572377902a36b6203658b5d',
    'tests/tools/qwen_mtp_stop_case.h': 'aa8bea3bc5dde060536268d82abd11cd2baffc998596dc53af4220a49e64cc9c',
}


def parse(backend):
    assert backend in ('cpu', 'cuda')
    out = W / 'runs' / ('tiny-' + backend)
    process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    assert len(reports) == 1, len(reports)
    report = reports[0]
    assert report['status'] == 'PASS' and report['case'] == 'mtp-stop-policy' and report['backend'] == backend
    for field in ('actual_B2', 'accepted_extra_stop_pending', 'native_rejected_draft_stop', 'fused_K1_stop',
                  'actual_bonus_stop', 'new_request_prefix_policy', 'same_key_rebuild_policy',
                  'old_checkpoints_byte_unchanged', 'full_state_numerically_equivalent',
                  'controlled_target_matching_candidate'):
        assert report[field] is True, field
    assert report['final_versions'] == 0 and report['greedy_rng_draws'] == 0
    assert report['real_model_EOS_checked'] is False and report['ignoreEOS_host_only'] is True
    assert report['rebuild_sampling_wrapper'] is True
    checks = report['state_checks']
    # Five numerical report entries; the bonus journey additionally uses a
    # strict same_image assertion in the real consumer before PASS is emitted.
    assert len(checks) == 5, len(checks)
    assert all(x['boundary_equal'] and x['numerically_equivalent'] for x in checks)
    # The consumer already enforces GDN-only finite 3e-6 tolerance; every
    # other state role remains byte-exact. Never relabel this as all-bit-equal.
    for name, value in [('report.json', report), ('summary.json', dict(status='PASS', process=process,
        backend=backend, state_checks=len(checks), full_state_numerically_equivalent=True,
        all_state_bytes_equal=all(x['payloads_byte_equal'] for x in checks),
        source_pins=SOURCES, report=report, quality_claim=False, performance_claim=False))]:
        t.save(out / name, value)
    print('MTP_STOP_PASS', backend, 'PID', process['pid'], 'state_checks', len(checks))


def run(backend):
    assert backend in ('cpu', 'cuda')
    b.validate()
    for relative, expected in SOURCES.items():
        assert t.pin(R / relative)['sha256'] == expected, relative
    ready = t.read(W / 'ready-tiny.json')
    t.exact(ready['image'])
    runtime = t.read(W / 'runtime-plan.json')
    t.exact(runtime['native'])
    native = Path(runtime['native']['path'])
    target = W / 'bin' / native.name
    if not target.exists():
        os.link(native, target)
    assert os.path.samefile(native, target), 'runtime must remain an original same-file DLL hardlink'
    if not (W / 'runtime-actual.json').exists():
        t.save(W / 'runtime-actual.json', dict(source=runtime['native'], target=str(target),
            same_file=True, method='Hardlink existing original CPU DLL; no SDK/DLL payload copy'))
    out = W / 'runs' / ('tiny-' + backend)
    assert not out.exists(), 'Actual run already exists; parse offline, do not rerun successful inference'
    args = [ready['image']['path'], '--' + backend, str(FIXTURE), '--mtp-stop']
    process = t.execute(args, out, 300)
    t.save(out / 'as-run.json', dict(image=ready['image'], inputs=ready['inputs'], ready=t.pin(W / 'ready-tiny.json'),
        source_pins=SOURCES, fixture_manifest=t.pin(FIXTURE / 'weights.tsv'), runtime=t.pin(W / 'runtime-actual.json'),
        environment=t.pin(W / 'environment.json'), process=process))
    parse(backend)


if __name__ == '__main__':
    action, backend = sys.argv[1:]
    if action == 'run': run(backend)
    elif action == 'parse': parse(backend)
    else: raise ValueError(action)
