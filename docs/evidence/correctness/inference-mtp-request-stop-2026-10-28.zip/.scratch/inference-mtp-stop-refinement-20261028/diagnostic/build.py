"""One diagnostic Tiny CXX/link/CPU run; original failed window preserved."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
BASE = R / '.scratch/inference-mtp-stop-policy-20261028'
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
t.W = W
EXPECTED = {
    'tests/tools/qwen_mtp_stop_case.h': 'bdebe48a57e464b3046fdfaa4d8a91d12149b95748d6a0a3fa3d280e7b50d8e9',
    'tests/tools/qwen_host_image_test.cc': 'f646dd99fff3207f94af5d4a5c5a0b0f8eb8dcb7f572377902a36b6203658b5d',
}


def prepare():
    ready = t.read(BASE / 'ready-tiny.json')
    rows = t.read(ready['inputs']['path'])
    assert len(rows) == 228
    old = ready['compiled']['object']
    assert sum(t.key(x['path']) == t.key(old['path']) for x in rows) == 1
    dependency = ready['compiled']['dependencies']['path']
    assert t.key(t.read(dependency)['Data']['Source']) == t.key(R / 'tests/tools/qwen_host_image_test.cc')
    for relative, sha in EXPECTED.items():
        assert t.pin(R / relative)['sha256'] == sha, relative
    product = t.read(BASE / 'product-freeze.json')
    for item in product['sources']:
        now = t.pin(R / item['path'])
        assert (now['bytes'], now['sha256']) == (item['bytes'], item['sha256']), item['path']
    # Canonical compilation preserves all original quoted-fixture lookup.
    # Pin the prior actual project include list, changing only the diagnostic
    # header; no SDK tree or independent Model object is copied or compiled.
    project = [t.pin(p) for p in dict.fromkeys(t.dep_paths(dependency)) if t.project(p)]
    t.save(W / 'project-dependencies.json', project)
    snapshots = []
    for relative in EXPECTED:
        source = R / relative; target = W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / 'source-freeze.json', dict(expected=EXPECTED, snapshots=snapshots,
        product_freeze=t.pin(BASE / 'product-freeze.json'), diagnostic_only=True))
    original = t.command(ready['compiled']['command']['path'])
    command = []
    for at, arg in enumerate(original):
        if at and original[at - 1].casefold() == '/sourcedependencies': arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        command.append(arg)
    t.save(W / 'recipe.json', dict(command=command, timeout_seconds=300))
    link = []
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg) == t.key(old['path']): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/MAP:', '.map'), ('/IMPLIB:', '.lib')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    t.save(W / 'link-recipe.json', dict(command=link, timeout_seconds=240))
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime-plan.json', t.read(BASE / 'runtime-plan.json'))
    t.save(W / 'plan.json', dict(status='DIAGNOSTIC_SOURCE_FROZEN_NOT_BUILT', baseline=t.pin(BASE / 'ready-tiny.json'),
        original_image=ready['image'], inputs=ready['inputs'], original_object=old,
        source_freeze=t.pin(W / 'source-freeze.json'), project_dependencies=t.pin(W / 'project-dependencies.json'),
        recipe=t.pin(W / 'recipe.json'), link_recipe=t.pin(W / 'link-recipe.json'),
        CXX=1, links=1, CPU_processes=1, CUDA_processes=0, SDK_CXX=0,
        run_contract='Real CPU diagnostic retains original strict require; exit1 is a preserved failure, not PASS.'))
    print('DIAGNOSTIC PREPARED: 1 Tiny TU/link/CPU only; no actual build/run')


def validate():
    plan = t.read(W / 'plan.json')
    for field in ('baseline', 'inputs', 'source_freeze', 'project_dependencies', 'recipe', 'link_recipe'):
        t.exact(plan[field])
    freeze = t.read(plan['source_freeze']['path'])
    t.exact(freeze['product_freeze'])
    for source in freeze['snapshots']:
        t.exact(source['original']); t.exact(source['snapshot'])
    return plan


def compile_one():
    plan = validate()
    allowed = {t.key(x['path']): x for x in t.read(plan['project_dependencies']['path'])}
    for item in allowed.values(): t.exact(item)
    out = W / 'compile/tiny'; out.mkdir(parents=True, exist_ok=False)
    process = t.execute(t.command(plan['recipe']['path']), W / 'logs/tiny', 300)
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('unexpected project include', str(path))
            t.exact(allowed[t.key(path)]); actual.append(t.pin(path))
    t.save(out / 'actual-project-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / 'tests/tools/qwen_host_image_test.cc'),
        object=t.pin(out / 'unit.obj'), process=process, command=t.pin(W / 'logs/tiny/command.json'),
        dependencies=t.pin(out / 'dependencies.json')))
    print('DIAGNOSTIC CXX PASS')


def link():
    plan = validate(); compiled = t.read(W / 'compile/tiny/compiled.json'); t.exact(compiled['object'])
    rows = [compiled['object'] if t.key(x['path']) == t.key(plan['original_object']['path']) else x
            for x in t.read(plan['inputs']['path'])]
    assert len(rows) == 228
    for item in rows:
        path = Path(item['path']); assert path.is_file() and path.stat().st_size == item['bytes'], path
    (W / 'bin').mkdir(exist_ok=True)
    assert not (W / 'bin/tiny.exe').exists()
    t.save(W / 'inputs-tiny.json', rows)
    process = t.execute(t.command(plan['link_recipe']['path']), W / 'link/tiny', 240)
    t.save(W / 'ready-tiny.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=t.pin(W / 'inputs-tiny.json'),
        recipe=t.pin(W / 'link/tiny/command.json'), compiled=compiled, process=process, plan=t.pin(W / 'plan.json')))
    print('DIAGNOSTIC LINK PASS')


def run_cpu():
    validate(); ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    native = t.read(W / 'runtime-plan.json')['native']; t.exact(native)
    source = Path(native['path']); target = W / 'bin' / source.name
    if not target.exists(): os.link(source, target)
    assert os.path.samefile(source, target)
    t.save(W / 'runtime-actual.json', dict(source=native, target=str(target), same_file=True))
    args = [ready['image']['path'], '--cpu', str(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'), '--mtp-stop']
    # execute writes actual command/stdout/stderr/process before raising on
    # failure. No parse, retry or synthetic success is attached to this probe.
    process = t.execute(args, W / 'runs/tiny-cpu', 300)
    t.save(W / 'runs/tiny-cpu/diagnostic-result.json', dict(actual_exit=process['exit'], process=process,
        status='ACTUAL_EXIT0_DIAGNOSTIC_ONLY', no_PASS_substitution=True))


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': compile_one()
    elif action == 'link': link()
    elif action == 'run-cpu': run_cpu()
    else: raise ValueError(action)
