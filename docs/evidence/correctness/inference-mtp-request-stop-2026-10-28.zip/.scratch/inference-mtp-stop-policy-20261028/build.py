"""Two consumer TUs/two links only. Inventory does not freeze live tests."""
from pathlib import Path
import importlib.util
import json
import os
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
t.W = W
SOURCES = dict(tiny='tests/tools/qwen_host_image_test.cc', host='tests/tools/qwen_prefix_cache_test.cc')
BASES = dict(tiny=R / '.scratch/inference-logits-preflight-20261028/ready-tiny.json',
             host=R / '.scratch/inference-append-transactions-refinement-20261028/ready-test.json')


def inventory():
    units = {}
    for name, path in BASES.items():
        ready = t.read(path)
        rows = t.read(ready['inputs']['path'])
        assert len(rows) == (228 if name == 'tiny' else 237)
        if name == 'tiny':
            compiled = ready['compiled']
            dependency_path = Path(compiled['dependencies']['path'])
        else:
            # The 237-input image has no existing prefix-cache TU. Replace
            # its original final AppendTransactions test slot, keeping all
            # other 236 objects and original GTest entry/library inputs.
            directory = R / '.scratch/inference-append-transactions-refinement-20261028/compile/test'
            compiled = t.read(directory / 'compiled.json')
            dependency_path = directory / 'dependencies.json'
        source = t.read(dependency_path)['Data']['Source']
        expected = R / (SOURCES['tiny'] if name == 'tiny' else 'tests/tools/inference_append_transactions_test.cc')
        assert t.key(source) == t.key(expected), (source, expected)
        old_object = compiled['object']
        assert sum(t.key(x['path']) == t.key(old_object['path']) for x in rows) == 1
        original = t.command(compiled['command']['path'])
        assert not any('HYLE_PREFIX_CACHE_STANDALONE' in x for x in original)
        command = []
        for at, arg in enumerate(original):
            if at and original[at - 1].casefold() == '/sourcedependencies':
                arg = str(W / 'compile' / name / 'dependencies.json')
            elif arg.casefold().startswith('/fo'):
                arg = '/Fo' + str(W / 'compile' / name / 'unit.obj')
            elif arg.casefold().startswith('/fd'):
                arg = '/Fd' + str(W / 'compile' / name / 'unit.pdb')
            elif arg.casefold().endswith(('.cc', '.cpp', '.cxx')):
                arg = str(R / SOURCES[name])
            command.append(arg)
        t.save(W / 'recipes' / (name + '.json'), dict(command=command, timeout_seconds=300))
        link = []
        for arg in t.command(ready['recipe']['path']):
            if t.key(arg) == t.key(old_object['path']):
                arg = str(W / 'compile' / name / 'unit.obj')
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/MAP:', '.map'), ('/IMPLIB:', '.lib')):
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link.append(arg)
        t.save(W / 'recipes' / ('link-' + name + '.json'), dict(command=link, timeout_seconds=240))
        units[name] = dict(source=SOURCES[name], baseline=t.pin(path), inputs=ready['inputs'],
            input_count=len(rows), original_object=old_object, actual_original_source=source,
            original_CXX=compiled['command'], original_dependencies=t.pin(dependency_path),
            original_link=ready['recipe'], recipe=t.pin(W / 'recipes' / (name + '.json')),
            link_recipe=t.pin(W / 'recipes' / ('link-' + name + '.json')))
    env = t.read(R / '.scratch/inference-logits-preflight-20261028/environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    runtime = t.read(R / '.scratch/inference-logits-preflight-20261028/runtime-actual.json')
    t.save(W / 'runtime-plan.json', dict(native=runtime['source'], method='same-file hardlink on explicit run; no DLL/SDK payload copy'))
    t.save(W / 'build-inventory.json', dict(status='METADATA_PREPARED_TESTS_NOT_FROZEN',
        product_freeze=t.pin(W / 'product-freeze.json'), units=units,
        compiler='Original MSVC 14.50.35717 Hostx64/x64; C++latest O2 Ob2 MD static ABI; original CPU/CUDA macros retained.',
        planned=dict(CXX=2, links=2, standalone_Model_CXX=0, SDK_CXX=0, NVCC=0, downloads=0),
        consumer_freeze='Root invokes freeze only after author finishes live tests.',
        host_filter='QwenMtpPrefix.*', tiny_run='New stop flag and fixture arguments await consumer freeze.'))
    print('INVENTORY PREPARED: canonical Tiny + GTest prefix-cache replacement, 228/237 inputs; zero freeze/build/run')


def freeze(name):
    plan = t.read(W / 'build-inventory.json')
    assert name in plan['units'], name
    unit = plan['units'][name]
    t.exact(plan['product_freeze'])
    product = t.read(W / 'product-freeze.json')
    owned = set()
    for item in product['sources']:
        if name == 'host' and item['path'] == 'engine/models/qwen35/main.cc':
            continue
        current = t.pin(R / item['path'])
        assert (current['bytes'], current['sha256']) == (item['bytes'], item['sha256']), item['path']
        owned.add(R / item['path'])
    owned.add(R / unit['source'])
    files = set(owned)
    files.update(t.canonical(p) for p in t.dep_paths(unit['original_dependencies']['path']) if t.project(t.canonical(p)))
    pending = list(files)
    while pending:
        source = pending.pop()
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"', source.read_text(encoding='utf-8-sig'), re.M):
            found = next((candidate.resolve() for parent in (source.parent, R / 'include', R)
                if (candidate := parent / include).is_file()), None)
            if found is not None and t.project(found) and found not in files:
                files.add(found)
                pending.append(found)
    snapshots = []
    # Preserve all currently included diagnostic helpers, not an entire SDK.
    selected = owned | {p for p in files if p.is_relative_to(R / 'tests/tools')}
    for source in sorted(selected):
        target = W / 'consumer-source' / name / source.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / ('consumer-source-freeze-' + name + '.json'), snapshots)
    t.save(W / ('project-dependencies-' + name + '.json'), [t.pin(p) for p in sorted(files)])
    t.save(W / ('build-frozen-' + name + '.json'), dict(status='ONE_TU_FROZEN_NOT_BUILT', unit=name,
        inventory=t.pin(W / 'build-inventory.json'),
        consumer_sources=t.pin(W / ('consumer-source-freeze-' + name + '.json')),
        project_dependencies=t.pin(W / ('project-dependencies-' + name + '.json'))))
    print('FROZEN', name, ': one canonical consumer TU; no compiler/link/run invoked')


def validate(name):
    frozen = t.read(W / ('build-frozen-' + name + '.json'))
    assert frozen['unit'] == name
    for field in ('inventory', 'consumer_sources', 'project_dependencies'):
        t.exact(frozen[field])
    plan = t.read(frozen['inventory']['path'])
    t.exact(plan['product_freeze'])
    for source in t.read(frozen['consumer_sources']['path']):
        t.exact(source['original']); t.exact(source['snapshot'])
    unit = plan['units'][name]
    for field in ('baseline', 'inputs', 'recipe', 'link_recipe', 'original_CXX', 'original_link'):
        t.exact(unit[field])
    return plan


def compile_one(name):
    plan = validate(name); unit = plan['units'][name]
    allowed = {t.key(x['path']): x for x in t.read(W / ('project-dependencies-' + name + '.json'))}
    for item in allowed.values():
        t.exact(item)
    out = W / 'compile' / name
    out.mkdir(parents=True, exist_ok=False)
    process = t.execute(t.command(unit['recipe']['path']), W / 'logs' / name, 300)
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('unexpected live project include', str(path))
            t.exact(allowed[t.key(path)])
            actual.append(t.pin(path))
    t.save(out / 'actual-project-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / unit['source']), object=t.pin(out / 'unit.obj'),
        process=process, command=t.pin(W / 'logs' / name / 'command.json'),
        dependencies=t.pin(out / 'dependencies.json'), actual_project_dependencies=t.pin(out / 'actual-project-dependencies.json')))
    print('CXX_PASS', name)


def link(name):
    plan = validate(name); unit = plan['units'][name]
    compiled = t.read(W / 'compile' / name / 'compiled.json'); t.exact(compiled['object'])
    rows = [compiled['object'] if t.key(x['path']) == t.key(unit['original_object']['path']) else x
            for x in t.read(unit['inputs']['path'])]
    assert len(rows) == unit['input_count'] and len({t.key(x['path']) for x in rows}) == len(rows)
    for item in rows:
        path = Path(item['path']); assert path.is_file() and path.stat().st_size == item['bytes'], path
    (W / 'bin').mkdir(exist_ok=True)
    assert not (W / 'bin' / (name + '.exe')).exists()
    t.save(W / ('inputs-' + name + '.json'), rows)
    process = t.execute(t.command(unit['link_recipe']['path']), W / 'link' / name, 240)
    t.save(W / ('ready-' + name + '.json'), dict(image=t.pin(W / 'bin' / (name + '.exe')),
        inputs=t.pin(W / ('inputs-' + name + '.json')), recipe=t.pin(W / 'link' / name / 'command.json'),
        process=process, compiled=compiled, plan=t.pin(W / ('build-frozen-' + name + '.json'))))
    print('LINK_PASS', name, len(rows))


def run_host():
    validate('host')
    ready = t.read(W / 'ready-host.json'); t.exact(ready['image'])
    out = W / 'runs/host'
    args = [ready['image']['path'], '--gtest_filter=QwenMtpPrefix.*', '--gtest_fail_fast',
            '--gtest_output=xml:' + str(out / 'results.xml')]
    process = t.execute(args, out, 180)
    xml = ET.parse(out / 'results.xml').getroot()
    assert int(xml.attrib['tests']) > 0 and all(int(xml.attrib.get(field, 0)) == 0
        for field in ('failures', 'errors', 'disabled', 'skipped'))
    t.save(out / 'summary.json', dict(status='PASS', process=process, filter='QwenMtpPrefix.*',
        tests=int(xml.attrib['tests']), failures=int(xml.attrib.get('failures', 0))))
    print('HOST_FILTER_PASS', xml.attrib['tests'])


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'inventory': inventory()
    elif action == 'freeze': freeze(sys.argv[2])
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'link': link(sys.argv[2])
    elif action == 'run-host': run_host()
    else: raise ValueError(action)
