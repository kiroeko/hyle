"""Offline bounded MTP request-stop evidence; no build/model execution."""
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
REF = R / '.scratch/inference-mtp-stop-refinement-20261028'
D, F = REF / 'diagnostic', REF / 'final'
DEST = R / 'docs/evidence/correctness/inference-mtp-request-stop-2026-10-28'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def data(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def pin(path):
    path = Path(path)
    value = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(value), sha256=hashlib.sha256(value).hexdigest())


def require(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    require(not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'evidence exists')
    product = read(W / 'product-freeze.json')
    for item in product['sources']:
        actual = pin(R / item['snapshot'])
        require((actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256']), 'frozen product drift')
    sources = {
        'initial': W / 'consumer-source/tiny/tests/tools/qwen_mtp_stop_case.h',
        'diagnostic': D / 'source/tests/tools/qwen_mtp_stop_case.h',
        'final': F / 'source/tests/tools/qwen_mtp_stop_case.h',
    }
    expected = dict(initial='7591ddb22ad2611a7f3802f5d6245440c62020bc154d5c5ed93e1c899926d451',
        diagnostic='bdebe48a57e464b3046fdfaa4d8a91d12149b95748d6a0a3fa3d280e7b50d8e9',
        final='aa8bea3bc5dde060536268d82abd11cd2baffc998596dc53af4220a49e64cc9c')
    for kind, path in sources.items():
        require(pin(path)['sha256'] == expected[kind], 'test revision mismatch: ' + kind)
    driver = F / 'source/tests/tools/qwen_host_image_test.cc'
    require(pin(driver)['sha256'] == 'f646dd99fff3207f94af5d4a5c5a0b0f8eb8dcb7f572377902a36b6203658b5d', 'driver mismatch')
    builds = []
    for label, root, name, count in [('host', W, 'host', 237), ('initial', W, 'tiny', 228),
                                     ('diagnostic', D, 'tiny', 228), ('final', F, 'tiny', 228)]:
        ready = read(root / ('ready-' + name + '.json'))
        compiled = ready['compiled']
        require(compiled['process']['exit'] == ready['process']['exit'] == 0, 'actual compile/link failed')
        rows = read(ready['inputs']['path'])
        require(len(rows) == count, 'closure count mismatch')
        require(sum(x['path'].casefold() == compiled['object']['path'].casefold() for x in rows) == 1,
                'exact consumer object missing/duplicated')
        builds.append(dict(arm=label, CXX_pid=compiled['process']['pid'], CXX_exit=0,
            link_pid=ready['process']['pid'], link_exit=0, inputs=count, image=ready['image']))
    host = read(W / 'runs/host/summary.json')
    require(host['status'] == 'PASS' and host['tests'] == 4 and host['failures'] == 0, 'host groups failed')
    failures = []
    for label, root in [('initial', W), ('diagnostic', D)]:
        process = read(root / 'runs/tiny-cpu/process.json')
        require(process['exit'] == 1 and not process['timed_out'], 'missing preserved CPU oracle failure')
        failures.append(dict(arm=label, pid=process['pid'], exit=1,
            kind='Test oracle representation mismatch; product unchanged.'))
    stderr = (D / 'runs/tiny-cpu/stderr.log').read_text(encoding='utf-8-sig')
    require('boundary_equal=0 payloads_byte_equal=1 numerically_equivalent=0' in stderr and
            'side=expected length=4 evaluated_next=0 next=0 sampling_wrapper=0' in stderr and
            'side=actual length=4 evaluated_next=0 next=0 sampling_wrapper=1' in stderr,
            'missing exact wrapper-only diagnostic')
    runs = []
    for backend in ('cpu', 'cuda'):
        directory = F / 'runs' / ('tiny-' + backend)
        process = read(directory / 'process.json')
        require(process['exit'] == 0 and not process['timed_out'], 'final actual consumer failed')
        report = json.loads((directory / 'stdout.log').read_text(encoding='utf-8-sig'))
        require(report['status'] == 'PASS' and report['backend'] == backend and report['case'] == 'mtp-stop-policy',
                'wrong final report')
        for field in ('actual_B2', 'accepted_extra_stop_pending', 'native_rejected_draft_stop', 'fused_K1_stop',
                      'actual_bonus_stop', 'new_request_prefix_policy', 'same_key_rebuild_policy',
                      'rebuild_sampling_wrapper', 'old_checkpoints_byte_unchanged', 'full_state_numerically_equivalent'):
            require(report[field] is True, 'missing final fact: ' + field)
        checks = report['state_checks']
        require(len(checks) == 5 and all(x['boundary_equal'] and x['numerically_equivalent'] for x in checks),
                'final state comparisons differ')
        # HostPayloadRole::kGdnState is 3 in the frozen model helper. Actual
        # equality covers every initialized payload; no padded bytes compared.
        differences = [part for check in checks for part in check['differences']]
        require(all(part['role'] == 3 and part['maximum_absolute'] <= 3e-6 and
                    part['nonfinite_differences'] == 0 for part in differences), 'non-GDN/tolerance difference')
        exact = all(check['payloads_byte_equal'] for check in checks)
        require(report['final_versions'] == 0 and report['greedy_rng_draws'] == 0 and
                not report['real_model_EOS_checked'] and report['ignoreEOS_host_only'], 'scope/resource mismatch')
        runs.append(dict(backend=backend, pid=process['pid'], exit=0, calibration_attempts=report['calibration_attempts'],
            actual_ids=dict(pending=report['pending'], target=report['target'], bonus=report['bonus'], native_draft=report['native_draft']),
            reported_state_comparisons=5, additional_bonus_comparison='Strict same_image before PASS.',
            all_initialized_payloads_byte_equal=exact, max_GDN_absolute_difference=max([0.0] + [x['maximum_absolute'] for x in differences]),
            other_payloads_exact=True, old_checkpoints_byte_unchanged=True, rebuild_sampling_wrapper=True,
            original_key_peer_continued=True, new_request_full_hit_uses_own_policy=True,
            greedy_rng_draws=0, engine_live_versions=0,
            target_and_draft_page_inventories_fully_free=True, host_images_live=0))

    members = {}

    def add(path, name=None):
        path = Path(path)
        require(path.is_file(), 'missing evidence: ' + str(path))
        require(path.suffix.lower() in {'.py', '.json', '.log', '.xml', '.cc', '.h', '.diff'}, 'binary/payload excluded')
        archive_name = name or path.relative_to(R).as_posix()
        require(archive_name not in members, 'duplicate member')
        members[archive_name] = path.read_bytes()

    def tree(directory):
        for path in sorted(Path(directory).rglob('*')):
            if path.is_file() and path.suffix.lower() in {'.py', '.json', '.log', '.xml', '.diff'}:
                add(path)

    # Explicit roots only: no current unrelated docs, license trees, artifacts,
    # binaries, model payload or SDK source/header directory is traversed.
    for root in (W, D, F):
        for path in sorted(root.iterdir()):
            if path.is_file() and path.suffix.lower() in {'.py', '.json', '.diff'}:
                add(path)
        for relative in ('recipes', 'logs', 'compile', 'link', 'runs'):
            if (root / relative).exists(): tree(root / relative)
    add(REF / 'prepare_final.py')
    for item in product['sources']:
        add(R / item['snapshot'], 'product/' + item['path'])
    host_source = W / 'consumer-source/host/tests/tools/qwen_prefix_cache_test.cc'
    add(host_source, 'consumer/tests/tools/qwen_prefix_cache_test.cc')
    add(driver, 'consumer/tests/tools/qwen_host_image_test.cc')
    for kind, path in sources.items():
        add(path, 'consumer-revisions/' + kind + '/qwen_mtp_stop_case.h')
    # Shared existing byte/numeric oracle sources are small, actual included
    # test helpers. Preserve them; do not recopy all project dependencies.
    for path in sorted((W / 'consumer-source/tiny/tests/tools').iterdir()):
        if path.name not in ('qwen_host_image_test.cc', 'qwen_mtp_stop_case.h'):
            add(path, 'consumer/tests/tools/' + path.name)
    for path in sorted((W / 'consumer-source/host/tests/tools').iterdir()):
        name = 'consumer/tests/tools/' + path.name
        if name not in members: add(path, name)
    for a, z in [('initial', 'diagnostic'), ('diagnostic', 'final')]:
        difference = ''.join(difflib.unified_diff(sources[a].read_text().splitlines(True),
            sources[z].read_text().splitlines(True), fromfile=a + '/qwen_mtp_stop_case.h', tofile=z + '/qwen_mtp_stop_case.h'))
        members['patches/' + a + '-to-' + z + '.diff'] = difference.encode()
    old_host = subprocess.run(['git', 'show', product['base'] + ':tests/tools/qwen_prefix_cache_test.cc'],
        cwd=R, capture_output=True, check=True).stdout.decode('utf-8-sig')
    members['patches/host-test.diff'] = ''.join(difflib.unified_diff(old_host.splitlines(True),
        host_source.read_text().splitlines(True), fromfile='4974345de/qwen_prefix_cache_test.cc',
        tofile='frozen/qwen_prefix_cache_test.cc')).encode()
    references = []
    for name in ['inference-logits-preflight-2026-10-28.json', 'inference-native-state-only-2026-10-28.json',
                 'inference-append-transactions-2026-10-28.json']:
        path = R / 'docs/evidence/correctness' / name
        references.append(pin(path))
        add(path, 'references/' + name)
    report = dict(status='PASS_BOUNDED_MTP_REQUEST_STOP', created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        base_commit=product['base'], product_sources=[dict(path=x['path'], bytes=x['bytes'], sha256=x['sha256']) for x in product['sources']],
        final_test_sources=dict(driver=pin(driver), case=pin(sources['final']), host=pin(host_source)),
        counts=dict(actual_CXX=4, successful_CXX=4, actual_links=4, successful_links=4,
            actual_processes=5, passed_processes=3, preserved_oracle_failures=2,
            host_groups=4, final_model_backends=2, standalone_Model_CXX=0, SDK_CXX=0, NVCC=0, downloads=0),
        builds=builds, host=dict(pid=host['process']['pid'], exit=0, filter=host['filter'], groups=4,
            scope='Host greedy/sampled acceptance, extra-stop/ignoreEOS, default EOS/quota and actual-width RNG policy.'),
        preserved_failures=failures,
        diagnostic=dict(only_difference='Committed-token rebuild creates the documented explicit historical-pending sampling wrapper: false to true.',
            initialized_payloads_byte_equal=True, product_changes_after_first_build=0,
            final_fix='Only the rebuild-stage expected wrapper bit is changed after asserting original false / restored true; all other boundary and payload checks remain.'),
        final_runs=runs,
        functional_coverage=['K1 rejected native draft stop, accepted verifier extra-stop pending, accepted-prefix bonus stop.',
            'Real B2 verifier shares one math cohort across different policies; stopped A and same-key B remain independent.',
            'New-request full-hit uses its own policy; committed-token rebuild and one same-key peer continuation preserve policy, old checkpoint bytes and RNG.',
            'Final owner explicitly retires B after the finite check; it does not claim B exhausted its remaining quota.'],
        numeric_policy='Inherited GDN absolute tolerance 3e-6 only; other initialized state roles exact. Both final runs actually reported all payload bytes exact (GDN max difference 0). Bonus is separately strict.',
        metadata_amendment=dict(path=pin(F / 'run-plan.json'),
            note='Final plan inherited CUDA_processes=0 from diagnostic metadata; independent run-plan corrects to CPU1+CUDA1, frozen plan preserved. All totals above use actual process receipts.'),
        limits=['Cached untrained V64 GA/H64/C16 fixture; no quality or acceptance-rate claim.',
            'A matching verifier candidate is an actual target-control result, not a naturally accepted NextN proposal; no forced accepted/state-selection callback.',
            'Real Model EOS is not present in this fixture. ignoreEOS is tested by shared host policy only.',
            'Only greedy real-model RNG was exercised; sampled shared selectors are host-tested, not a new random-model journey.',
            'Engine versions, page inventories and host images are checked; native allocator live-zero/hardware fault/unknown-pending are not claimed.',
            'No performance window, TPS claim, new platform matrix, SDK/NVCC compilation or download.'],
        references=references, raw_manifest='manifest.json')
    members['evidence-core.json'] = data(report)
    manifest = [dict(path=name, bytes=len(value), sha256=hashlib.sha256(value).hexdigest())
                for name, value in sorted(members.items())]
    members['manifest.json'] = data(dict(files=manifest,
        excluded=['EXE', 'OBJ', 'PDB', 'DLL', 'LIB', 'SDK', 'model/weights payload', 'unrelated docs/license']))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, value in sorted(members.items()): archive.writestr(name, value)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        require(archive.testzip() is None and set(archive.namelist()) == set(members), 'ZIP CRC/member failure')
        for name, expected_value in members.items():
            require(archive.read(name) == expected_value, 'ZIP readback mismatch: ' + name)
    report['archive'] = dict(pin(DEST.with_suffix('.zip')), files=len(members), verified_readback=True)
    DEST.with_suffix('.json').write_bytes(data(report))
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')), archive=report['archive'], counts=report['counts']), indent=2))


if __name__ == '__main__':
    main()
