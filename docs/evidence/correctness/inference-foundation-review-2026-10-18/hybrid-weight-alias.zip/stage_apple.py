from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re,base64,sys
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/hybrid-weight-alias'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-foundation-review-20261018-hybrid-weight-alias'
files={};queue=[R/x for x in ['src/graph_route_cpu_apple/compile.cc','src/graph_route_cpu_apple/invocation.cc','tests/graph/cpu_apple_contracts.cc']]
while queue:
 p=queue.pop()
 key=p.relative_to(R).as_posix()
 if key in files:continue
 files[key]=p
 for angled,quoted in re.findall(r'^\s*#\s*include\s*(?:<([^>]+)>|"([^"]+)")',p.read_text(encoding='utf-8'),re.M):
  options=([R/'include'/angled] if angled else [p.parent/quoted,R/'include'/quoted,R/quoted])
  for x in options:
   x=x.resolve()
   if x.is_file() and x.is_relative_to(R):queue.append(x);break
for n in ['run_apple_remote.py','apple-invocation.before.cc']:files[n]=O/n
s=(R/'tests/graph/cpu_apple_contracts.cc').read_text(encoding='utf-8');a=s.index('Status leased_contracts()');b=s.index('Status contracts()',a)
s=s[:a]+s[b:];s=s.replace('  HYLE_RETURN_IF_ERROR(leased_contracts());\n','')
(O/'apple-contracts.narrow.cc').write_text(s,newline='\n');files['apple-contracts.narrow.cc']=O/'apple-contracts.narrow.cc'
items=[dict(path=k,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for k,p in sorted(files.items())]
(O/'apple-staged-sources.json').write_text(json.dumps(items,indent=2)+'\n')
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w:gz') as t:
 for k,p in sorted(files.items()):t.add(p,arcname=k)
(O/'apple-staged-sources.tar.gz').write_bytes(data.getvalue())
code=f"""
import pathlib,sys,tarfile,io
r=pathlib.Path({REMOTE!r});assert not r.exists();r.mkdir()
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and m.isfile()
 t.extractall(r)
print(r)
"""
def ssh(code,input=None):
 cmd='python3 -c '+repr('import base64;exec(base64.b64decode('+repr(base64.b64encode(code.encode()).decode())+'))')
 return subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=input,capture_output=True)
p=ssh(code,data.getvalue());(O/'apple-stage.stdout.log').write_bytes(p.stdout);(O/'apple-stage.stderr.log').write_bytes(p.stderr)
print('stage',p.returncode,'files',len(items),'bytes',sum(x['bytes']for x in items),'compressed',len(data.getvalue()));print(p.stdout.decode(),p.stderr.decode());p.check_returncode()
