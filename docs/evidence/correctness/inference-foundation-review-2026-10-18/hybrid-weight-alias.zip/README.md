# Ready immutable weight aliases in joint routes

CPU+Apple and CPU+Vulkan prepare a WeightBatch native alias only when `value.weight && !value.native_input`. Activation-only rebinds reuse the ready immutable alias. Explicit weight binds and reset keep their original invalidation rules. Coarse checked native completion waits remain.

Apple Air Mac16,12: complete canonical contract passes. Both routes reject a new alias allocation with the dedicated WeightSlots allocator under the old implementation; the candidate performs two activation-only replays without new weight alias metadata, preserves numerical results, and successfully retries an explicitly rebound weight after OOM. Batch/ID changes, old-result guards, reset, cancellation, abandonment, and late refusal retain their checks.

The first Windows full-contract run crashed before the weight fixture. Its trace reached the stopped-pool pure-CPU control, then CPU provider recipe compilation. The cached Graph adapter copied a four-vector private Recipe, while the current CPU provider read a fifth constants vector. The real fault was its first constants element load, address -1. Recompiling only current `src/graph_route_cpu/ggml_region.cc` corrected the closure. The original uninstrumented full canonical consumer then passed (exit0, 0.75s), including every waiter and leased case. No product fix or SDK/native rebuild was needed for that crash.

The original failure, the limited narrow success, and all later diagnosis remain. `summary.initial.json` records the earlier limited conclusion; `summary.json` records the final full result. `source-results.initial.zip` is kept beside this package with its original SHA, and is not overwritten.

No latency or throughput experiment was performed. WeightSlots-specific allocation rejection proves reuse of alias metadata; it does not prove every graph allocation vanished. Reset followed by a new batch/ID is tested; reset alone is not claimed to retire all internal vendor bindings immediately.
