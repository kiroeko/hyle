from pathlib import Path
import json,os,subprocess,sys,time
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent;BASE=R/'.scratch/build-compute-v2-dev'
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
old=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-vulkan-graph/commands.json').read_text())
c=next(x['command'] for x in old if x['tag']=='tests-compile');CL=c[0];LINK=Path(CL).with_name('link.exe');flags=c[1:-2]+['/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_GGML_CPU=1','/DHYLE_COMPUTE_ONEDNN=1','/DHYLE_GRAPH_ONEDNN=1','/I'+str(R),'/I'+str(R/'src/graph_route_cpu_vulkan'),'/I'+str(R/'tests/graph')]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':CL,'CMAKE_C_COMPILER':CL});env.update(VSLANG='1033',DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~');env['PATH']=str(BASE/'bin')+os.pathsep+env['PATH']
closure=[x for x in next(x['command'] for x in reversed(old) if x['tag']=='link')[1:] if not x.startswith(('/OUT:','/MAP:')) and not x.endswith('batched-sink-vulkan-graph\\tests.obj')]
closure += [str(R/x) for x in ['.scratch/inference-foundation-review-2026-10-18/hybrid-weight-dependencies/graph-cpu-context.obj','.scratch/inference-foundation-review-2026-10-18/hybrid-weight-dependencies/cpu-policy.obj','.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj','.scratch/inference-foundation-review-2026-10-18/cpu-mla/native-batch.obj','.scratch/mtp-gdn-2026-10-18/mixed/selector-baseline.obj','.scratch/mtp-gdn-2026-10-18/mixed/allocator.obj','.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj','.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-cpu.lib']]
closure = [x for x in closure if not x.endswith('vulkan-dense-constant\\program.obj')]
closure += [str(BASE/'bin'/(n+'.lib')) for n in ['hyle_simd','hyle_compute_ggml_runtime','hyle_sched','hyle_compute_backend_cpu','hyle_compute_provider_ggml','hyle_compute_provider_native','hyle_compute_provider_onednn','hyle_graph_provider_onednn','hyle_graph_route_cpu','dnnl']]
closure.insert(0, str(R/'.scratch/perf-review-2026-10-18/blocking-pool/candidate.obj'))
for x in closure:
 if x.endswith(('.obj','.lib')) and Path(x).is_absolute():
  assert Path(x).is_file(),x
  env['PATH']=str(Path(x).parent)+os.pathsep+env['PATH']
# CPU ATen library locations, not SDK staging.
for line in (BASE/'CMakeCache.txt').read_text().splitlines():
 if line.startswith('TORCH_LIBRARY:'):
  t=Path(line.split('=',1)[1]).parent;closure += [str(t/(n+'.lib')) for n in ['torch','torch_cpu','c10']];env['PATH']=str(t)+os.pathsep+env['PATH']
records=json.loads((O/'vulkan-commands.json').read_text()) if (O/'vulkan-commands.json').exists() else []
def run(tag,cmd,expect=0):
 cmd=list(map(str,cmd));i=len(records);stem=f'vk-{i+1:02d}-{tag}';st=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,timeout=150)
 (O/(stem+'.stdout.log')).write_bytes(p.stdout);(O/(stem+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-st,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'));(O/'vulkan-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(stem,p.returncode,round(time.monotonic()-st,2),flush=True)
 if p.returncode!=expect:
  print(p.stdout.decode(errors='replace')[-7000:]);print(p.stderr.decode(errors='replace')[-1200:]);raise SystemExit(p.returncode or 1)
 return p

def comp(file,name):run(name+'-compile',[CL,*flags,'/Tp'+str(file),'/Fo'+str(O/(name+'.obj'))])
def link(rev):run(rev+'-link',[LINK,O/('vk-'+rev+'.obj'),O/'vk-compile.obj',O/'vk-tests.obj',O/'vk-program.obj',O/'batch-layout.obj',*closure,'/OUT:'+str(O/('vulkan-'+rev+'.exe')),'/MAP:'+str(O/('vulkan-'+rev+'.map'))])
if __name__=='__main__':
 action=sys.argv[1]
 if action=='build':
  comp(R/'tests/graph/cpu_vulkan_contracts.cc','vk-tests')
  comp(R/'src/graph_route_cpu_vulkan/compile.cc','vk-compile')
  comp(O/'vulkan-invocation.before.cc','vk-before')
  comp(R/'src/graph_route_cpu_vulkan/invocation.cc','vk-after')
  link('before');link('after')
 elif action=='extra':
  comp(R/'src/compute_route_vulkan/vulkan_program.cc','vk-program')
  comp(R/'src/compute_batch/batch_layout.cc','batch-layout')
  link('before');link('after')
 elif action=='trace':
  comp(O/'vulkan-contracts.trace.cc','vk-trace')
  run('trace-link',[LINK,O/'vk-before.obj',O/'vk-compile.obj',O/'vk-trace.obj',O/'vk-program.obj',O/'batch-layout.obj',*closure,'/OUT:'+str(O/'vulkan-trace.exe')])
  p=run('trace',[O/'vulkan-trace.exe'],expect=3221225477);print(p.stderr.decode(errors='replace'))
 elif action=='narrow':
  comp(O/'vulkan-contracts.narrow.cc','vk-narrow')
  for rev,expected in [('before',1),('after',0)]:
   run('narrow-'+rev+'-link',[LINK,O/('vk-'+rev+'.obj'),O/'vk-compile.obj',O/'vk-narrow.obj',O/'vk-program.obj',O/'batch-layout.obj',*closure,'/OUT:'+str(O/('vulkan-narrow-'+rev+'.exe')),'/MAP:'+str(O/('vulkan-narrow-'+rev+'.map'))])
   p=run('narrow-'+rev,[O/('vulkan-narrow-'+rev+'.exe')],expect=expected)
   print(p.stdout.decode(errors='replace')[-5000:]+p.stderr.decode(errors='replace')[-1200:])
 elif action=='link':link('before');link('after')
 elif action=='test':
  p=run('before',[O/'vulkan-before.exe'],expect=1);print(p.stdout.decode(errors='replace')[-1200:]+p.stderr.decode(errors='replace')[-1200:])
  p=run('after',[O/'vulkan-after.exe']);print(p.stdout.decode(errors='replace')[-5000:]+p.stderr.decode(errors='replace')[-1200:])
