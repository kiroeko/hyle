from pathlib import Path
import json,subprocess,time,hashlib,sys,os
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'inference-foundation-review-20261018-mla'
COLD=ROOT.parent/'inference-foundation-review-20261018-apple-prepare-placeholder'
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
old=json.loads((BASE/'commands.json').read_text())
base_compile=next(x['command'] for x in old if x['tag']=='joint-invocation-compile')
base_link=next(x['command'] for x in reversed(old) if x['tag']=='link')
records=json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,cmd,expected=0):
 cmd=list(map(str,cmd));stem=f'{len(records)+1:02d}-{tag}';t=time.monotonic()
 p=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=150)
 (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-t,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
 (ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,round(time.monotonic()-t,2),flush=True)
 if p.returncode!=expected:
  print(p.stdout.decode(errors='replace')[-6000:]+p.stderr.decode(errors='replace')[-6000:]);raise SystemExit(1)
 print(p.stdout.decode(errors='replace')[-2500:]+p.stderr.decode(errors='replace')[-1000:],flush=True)
 return p
flags=base_compile[1:base_compile.index('-c')]
flags[:0]=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/graph_route_cpu_apple'),'-I'+str(ROOT/'tests/graph')]
flags+=['-DHYLE_COMPUTE_CPU=1','-DHYLE_COMPUTE_GGML_CPU=1']
def compile(source,name):run(name+'-compile',['/usr/bin/clang++',*flags,'-c',ROOT/source,'-o',ROOT/(name+'.o')])
def link(rev,narrow=False):
 cmd=[]
 remove={str(BASE/(x+'.o')) for x in ['consumer','joint-invocation','joint-compile']}
 for x in base_link:
  if x in remove:continue
  if x==str(BASE/'public-mla'):cmd.append(str(ROOT/('apple-'+rev+('-narrow' if narrow else ''))))
  elif x.endswith('/apple_context.o'):cmd.append(str(COLD/'context.o'))
  elif x.startswith('-Wl,-map,'):cmd.append('-Wl,-map,'+str(ROOT/('apple-'+rev+('-narrow' if narrow else '')+'.map')))
  else:cmd.append(x)
 idx=cmd.index('-o')+2
 cmd[idx:idx]=[str(ROOT/(rev+'.o')),str(ROOT/'joint-compile.o'),str(ROOT/('test-narrow.o' if narrow else 'test.o'))]
 p=SDK/'lib/libggml-cpu.a'
 if p.exists():cmd.insert(cmd.index(str(SDK/'lib/libggml.a')),str(p))
 idx=cmd.index(str(SDK/'lib/libmlx.a'));cmd.insert(idx,str(COLD/'common.o'))
 # CPU graph/default provider archives, no alternate ggml pin.
 for n in ['hyle_graph_route_cpu','hyle_compute_route_cpu','hyle_compute_provider_ggml','hyle_compute_provider_onednn','hyle_graph_provider_onednn','hyle_compute_native_baseline']:
  p=SDK/'lib'/('lib'+n+'.a')
  if p.is_file():cmd.insert(cmd.index(str(SDK/'lib/libhyle_compute_backend_cpu.a')),str(p))
 for x in cmd:
  if x.endswith(('.o','.a','.dylib')):assert Path(x).is_file(),x
 run(rev+('-narrow' if narrow else '')+'-link',cmd)
 (ROOT/('identities-'+rev+('-narrow' if narrow else '')+'.json')).write_text(json.dumps([ident(Path(x)) for x in cmd if x.endswith(('.o','.a','.dylib'))],indent=2)+'\n')
model=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip();assert model=='Mac16,12'
if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
assert(ROOT/'mlx.metallib').resolve()==(SDK/'lib/mlx.metallib').resolve()
(ROOT/'machine.json').write_text(json.dumps(dict(model=model,hardware=subprocess.check_output(['/usr/sbin/sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True),toolchain=subprocess.check_output(['/usr/bin/clang++','--version'],text=True),metallib=str((ROOT/'mlx.metallib').resolve()),sdk_copied=False,native_recompiled=False),indent=2)+'\n')
action=sys.argv[1]
if action=='build':
 compile('src/graph_route_cpu_apple/compile.cc','joint-compile')
 compile('apple-invocation.before.cc','before')
 compile('src/graph_route_cpu_apple/invocation.cc','after')
 compile('tests/graph/cpu_apple_contracts.cc','test')
 link('before');link('after')
elif action=='resume':
 compile('tests/graph/cpu_apple_contracts.cc','test')
 link('before');link('after')
elif action=='link':link('before');link('after')
elif action=='test':
 run('before',[ROOT/'apple-before'],1)
 run('after',[ROOT/'apple-after'])
elif action=='narrow':
 compile('apple-contracts.narrow.cc','test-narrow')
 for rev,e in [('before',1),('after',0)]:
  link(rev,True);run(rev+'-narrow',[ROOT/('apple-'+rev+'-narrow')],e)
