from pathlib import Path
import importlib.util,json,sys
R=Path.cwd();O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('alias',R/'.scratch/inference-foundation-review-2026-10-18/hybrid-weight-alias/run_vulkan.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.O=O;m.records=json.loads((O/'vulkan-commands.json').read_text()) if(O/'vulkan-commands.json').exists()else[]
m.flags+=['/I'+str(O),'/Zi']
A=R/'.scratch/inference-foundation-review-2026-10-18/hybrid-weight-alias'
action=sys.argv[1] if len(sys.argv)>1 else 'trace'
if action=='trace':
 m.comp(O/'contracts.trace.cc','trace')
 m.run('trace-link',[m.LINK,A/'vk-after.obj',A/'vk-compile.obj',O/'trace.obj',A/'vk-program.obj',A/'batch-layout.obj',*m.closure,'/OUT:'+str(O/'trace.exe'),'/MAP:'+str(O/'trace.map'),'/DEBUG','/PDB:'+str(O/'trace.pdb')])
 p=m.run('trace',[O/'trace.exe'],expect=3221225477);print(p.stderr.decode(errors='replace'))
elif action=='region':
 m.flags+=['/I'+str(R/'src/compute_provider_ggml'),'/I'+str(R/'src/graph_route_cpu')]
 m.comp(R/'src/graph_route_cpu/ggml_region.cc','ggml-region')
 m.run('region-link',[m.LINK,A/'vk-after.obj',A/'vk-compile.obj',O/'trace.obj',O/'ggml-region.obj',A/'vk-program.obj',A/'batch-layout.obj',*m.closure,'/OUT:'+str(O/'region.exe'),'/MAP:'+str(O/'region.map'),'/DEBUG','/PDB:'+str(O/'region.pdb')])
 p=m.run('region',[O/'region.exe']);print(p.stdout.decode(errors='replace')+p.stderr.decode(errors='replace'))
elif action=='assembly':
 p=m.run('provider-disasm',[Path(m.CL).with_name('dumpbin.exe'),'/DISASM:NOBYTES',R/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj'])
 data=p.stdout.decode(errors='replace');name='?compile@internal@ggml_cpu@compute@hyle@@';pos=data.index(name)
 (O/'provider-compile.asm.txt').write_text(data[pos:pos+27000])
 print(data[pos:pos+6500])

elif action=='canonical':
 m.run('canonical-link',[m.LINK,A/'vk-after.obj',A/'vk-compile.obj',A/'vk-tests.obj',O/'ggml-region.obj',A/'vk-program.obj',A/'batch-layout.obj',*m.closure,'/OUT:'+str(O/'canonical.exe'),'/MAP:'+str(O/'canonical.map')])
 p=m.run('canonical',[O/'canonical.exe']);print(p.stdout.decode(errors='replace')+p.stderr.decode(errors='replace'))
elif action=='archive':
 import re
 archive=R/'.scratch/build-compute-v2-dev/bin/hyle_graph_route_cpu.lib'
 p=m.run('archive-list',[Path(m.CL).with_name('lib.exe'),'/nologo','/LIST',archive])
 members=[x.strip()for x in p.stdout.decode(errors='replace').splitlines()if x.strip().endswith('ggml_region.cc.obj')];assert len(members)==1,members
 m.run('archive-extract',[Path(m.CL).with_name('lib.exe'),'/nologo','/EXTRACT:'+members[0],'/OUT:'+str(O/'cached-ggml-region.obj'),archive])
 p=m.run('cached-region-disasm',[Path(m.CL).with_name('dumpbin.exe'),'/DISASM:NOBYTES',O/'cached-ggml-region.obj'])
 print('old adapter member',members[0])

elif action=='fault':
 p=m.run('fault-disasm',[Path(m.CL).with_name('dumpbin.exe'),'/DISASM:NOBYTES','/RANGE:0x140269CA0,0x140269F60',O/'trace.exe'])
 print(p.stdout.decode(errors='replace'))
