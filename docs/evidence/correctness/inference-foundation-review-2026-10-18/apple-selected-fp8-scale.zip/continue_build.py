from pathlib import Path
import subprocess,base64
O=Path('.scratch/inference-fusion-quantization-2026-10-18/apple-selected-fp8-scale');remote='/Users/kiro/hyle-scratch/compute-unified/inference-fusion-quantization-20261018-apple-selected-fp8-scale'
for name in ['probe.cc','run_remote.py']:
 data=(O/name).read_bytes();code='from pathlib import Path;import sys;Path('+repr(remote+'/'+name)+').write_bytes(sys.stdin.buffer.read())';cmd="python3 -c \"import base64;exec(base64.b64decode('"+base64.b64encode(code.encode()).decode()+"'))\"";p=subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=data,capture_output=True,timeout=20);p.check_returncode()
p=subprocess.run(['ssh','kiro@172.22.10.198','cd '+remote+' && python3 run_remote.py build'],capture_output=True,timeout=120);attempt=2+len(list(O.glob('build-attempt-*.stdout.log')));(O/('build-attempt-'+str(attempt)+'.stdout.log')).write_bytes(p.stdout);(O/('build-attempt-'+str(attempt)+'.stderr.log')).write_bytes(p.stderr);print(p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-2500:]);p.check_returncode()
