from pathlib import Path
import tarfile,io,re,subprocess,base64,json,hashlib
R=Path.cwd();O=R/'.scratch/inference-fusion-quantization-2026-10-18/apple-selected-fp8-scale';remote='/Users/kiro/hyle-scratch/compute-unified/inference-fusion-quantization-20261018-apple-selected-fp8-scale'
files={'probe.cc':O/'probe.cc','run_remote.py':O/'run_remote.py','apple_mature_float.before.cc':O/'apple_mature_float.before.cc','src/compute_route_apple/apple_mature_float.cc':R/'src/compute_route_apple/apple_mature_float.cc'}
seen=set()
def add(p):
 p=p.resolve()
 if p in seen:return
 seen.add(p)
 if p.is_relative_to(R) and '.scratch' not in p.relative_to(R).parts:files[p.relative_to(R).as_posix()]=p
 for rel in re.findall(r'^\s*#\s*include\s*"([^\"]+)"',p.read_text(encoding='utf-8-sig'),re.M):
  for q in [p.parent/rel,R/rel,R/'include'/rel,R/'src/compute_route_apple'/rel]:
   if q.is_file():add(q);break
for p in list(files.values()):add(p)
items=[dict(path=k,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for k,p in sorted(files.items())];(O/'staged-sources.json').write_text(json.dumps(items,indent=2)+'\n')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz')as t:
 for k,p in files.items():t.add(p,arcname=k)
(O/'minimal-sources.tar.gz').write_bytes(b.getvalue())
code='from pathlib import Path;import tarfile,io,sys;r=Path('+repr(remote)+');assert not r.exists();r.mkdir();t=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in t.getmembers());t.extractall(r);print(r)'
cmd="python3 -c \"import base64;exec(base64.b64decode('"+base64.b64encode(code.encode()).decode()+"'))\""
p=subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=b.getvalue(),capture_output=True,timeout=30);(O/'stage.stdout.log').write_bytes(p.stdout);(O/'stage.stderr.log').write_bytes(p.stderr);print('stage',p.returncode,len(files),len(b.getvalue()),p.stdout.decode(),p.stderr.decode());p.check_returncode()
cmd='cd '+remote+' && python3 run_remote.py build'
p=subprocess.run(['ssh','kiro@172.22.10.198',cmd],capture_output=True,timeout=180);(O/'build.stdout.log').write_bytes(p.stdout);(O/'build.stderr.log').write_bytes(p.stderr);print('build',p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-2000:]);p.check_returncode()
