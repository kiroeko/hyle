from pathlib import Path
import json,hashlib,subprocess,time,re,sys
ROOT=Path(__file__).resolve().parent
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
HIGH=ROOT.parent/'inference-feature-completion-20261018-apple-highdim';MTP=ROOT.parent/'mtp-gdn-snapshots-20261018'
GE=ROOT.parent/'inference-foundation-review-20261018-gather-elements'
STRIDE=ROOT.parent/'library-review-20261018-apple-native-mask-strides/candidate/steel_attention.o'
FLAGS=['-O3','-DNDEBUG','-std=c++23','-arch','arm64','-DHYLE_STATIC','-DMLX_STATIC','-DHYLE_COMPUTE_APPLE=1','-Wall','-Wextra','-Wpedantic','-Werror']
macros=set().union(*(set(re.findall(r'\bHYLE_[A-Z0-9_]+_API\b',p.read_text()))for p in (ROOT/'include').rglob('*.h')))
FLAGS+=['-D'+m+'='for m in sorted(macros)]
INC=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(HIGH/'src/compute'),'-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp'),'-isystem','/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include']
records=json.loads((ROOT/'commands.json').read_text())if(ROOT/'commands.json').exists()else[]
def run(tag,cmd):
 cmd=list(map(str,cmd));prefix=tag+'-'+str(1+sum(x['tag']==tag for x in records));start=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=120)
 (ROOT/(prefix+'.stdout.log')).write_bytes(p.stdout);(ROOT/(prefix+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=cmd,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start));(ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(prefix,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-2500:],p.stderr.decode(errors='replace')[-6500:]);raise SystemExit(p.returncode)
 return p.stdout
retained=[GE/(n+'.o')for n in ['tensor','indexing']]+[HIGH/(n+'.o')for n in ['apple_context','apple_operations','fast','native-host']]+[MTP/(n+'.o')for n in ['recurrent','native','ops','ops-tensor_desc.cc','ops-low_precision.cc','ops-weight_decode.cc','ops-sampling_ops.cc']]+[STRIDE]
LIBS=[SDK/'lib'/('lib'+n+'.a')for n in ['hyle_graph_route_cpu_apple','hyle_graph','hyle_compute_route_apple','hyle_graph_route_apple','hyle_compute_backend_cpu','hyle_compute_provider_native','hyle_compute_stream','hyle_compute_state','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_simd','hyle_sched','hyle_container','hyle_mem_vm','hyle_mem','mimalloc_static','hyle_platform_thread','hyle_time','hyle_platform','hyle_error','hyle_compute_provider_ggml_metal','hyle_compute_ggml_runtime','ggml','ggml-metal','ggml-base','mlx']]
TORCH=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sdks/torch-cpu/Darwin-be0642231d2008c7b90071fc0898d82a0c002d47f38350ebf3ed779fc01972d7/libtorch/lib');LIBS +=[TORCH/n for n in ['libtorch.dylib','libtorch_cpu.dylib','libc10.dylib']]
CORE=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build');LIBS +=[CORE/'lib/libgtest.a']
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def build():
 assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
 if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
 for file,name in [('apple_mature_float.before.cc','old-mature'),('src/compute_route_apple/apple_mature_float.cc','new-mature'),('probe.cc','probe')]:
  if not(ROOT/(name+'.o')).exists() or (ROOT/file).stat().st_mtime>(ROOT/(name+'.o')).stat().st_mtime:run(name+'-compile',['clang++',*FLAGS,*INC,'-c',ROOT/file,'-o',ROOT/(name+'.o')])
 for arm in ['old','new']:
  exe=ROOT/(arm+'-compare');objs=[ROOT/'probe.o',ROOT/(arm+'-mature.o'),*retained]
  for p in [*objs,*LIBS]:assert p.is_file(),p
  run(arm+'-link',['clang++','-O3','-std=c++23','-arch','arm64','-o',exe,*objs,*LIBS,'-Wl,-rpath,'+str(TORCH),'-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore','-Wl,-map,'+str(ROOT/(arm+'.map'))])
 (ROOT/'identities.json').write_text(json.dumps([identity(p)for p in [*retained,*[ROOT/(x+'.o')for x in ['old-mature','new-mature','probe']],ROOT/'old-compare',ROOT/'new-compare']],indent=2)+'\n')
def test():
 for arm in ['old','new']:
  run(arm+'-test',[ROOT/(arm+'-compare')]);(ROOT/'output.f32').rename(ROOT/(arm+'-output.f32'))
 old=(ROOT/'old-output.f32').read_bytes();new=(ROOT/'new-output.f32').read_bytes();assert old==new
 (ROOT/'comparison.json').write_text(json.dumps(dict(bytes=len(old),float_outputs=len(old)//4,all_bits_equal=True,old_sha256=hashlib.sha256(old).hexdigest(),new_sha256=hashlib.sha256(new).hexdigest()),indent=2)+'\n')
if __name__=='__main__':{'build':build,'test':test}[sys.argv[1]]()
