from pathlib import Path
import importlib.util,json,subprocess,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cached_cpu',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
cfg=dict(c.PINS['mixed'],folder=Path('mixed'));records=[]
def run(tag,args):
    start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=ROOT,env=c.ENV,capture_output=True,timeout=90)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=list(map(str,args)),exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'schema-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-2500:],p.stderr.decode(errors='replace')[-1000:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
obj=OUT/'schema-test.obj';exe=OUT/'schema-test.exe'
flags=c.hyle_flags(cfg)+['/I'+str(c.BASE/'_deps/googletest-src/googletest/include')]
run('schema-compile',[c.CL,*flags,ROOT/'tests/compute_ops/operation_test.cc','/Fo'+str(obj)])
libs=[c.BASE/'bin'/(n+'.lib') for n in ['hyle_compute_ops','hyle_compute','hyle_container','hyle_mem','mimalloc_static','hyle_error','hyle_simd','hyle_platform_thread','hyle_platform','hyle_time']]
run('schema-link',[c.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),obj,*libs,c.BASE/'lib/gtest_main.lib',c.BASE/'lib/gtest.lib',*c.SYSTEM])
run('schema-run',[exe,'--gtest_color=no','--gtest_filter=GatherElements.*'])
