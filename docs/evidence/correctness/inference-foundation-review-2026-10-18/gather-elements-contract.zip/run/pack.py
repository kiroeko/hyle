from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sources=['include/hyle/compute/model_ops.h','tests/compute_models/gather_elements_fixture.h',
    'tests/compute_models/d5_moe_execution_fragments.h','tests/compute_ops/operation_test.cc',
    'docs/user/compute.md']
record={'schema':'same rank, dense floating source, I32 indices, equal non-axis dimensions; output shape follows indices',
 'model_change':'TopK per-row IDs -> GatherElements instead of Cartesian Gather [T,T,K] + diagonal; only [T,K] selected scores',
 'schema_tests':'2 canonical GatherElements tests PASS; independent native/runtime packages linked from main report',
 'source':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in sources]}
(OUT/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
archive=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/gather-elements-contract.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sources:z.write(ROOT/p,'source/'+p)
    for p in OUT.iterdir():
        if p.is_file() and p.suffix in ('.py','.json','.log'):z.write(p,'run/'+p.name)
print(archive.name,archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest())
