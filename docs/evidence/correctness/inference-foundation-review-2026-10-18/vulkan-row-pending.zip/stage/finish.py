from pathlib import Path
import hashlib,json,zipfile
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];DEST=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
summary=read(OUT/'summary.json');assert summary['tests']['windows_passed']==9
sources=read(OUT/'final-source-identities.json')
for row in sources:assert ident(row['path'])==row
retained=[read(p)['object'] for p in sorted(OUT.glob('src--*.cc.json'))+sorted(OUT.glob('tests--*.cc.json'))]
assert len(retained)==8
for row in retained:assert ident(row['path'])==row
native=[r for r in read(OUT/'current-link.json')['objects'] if Path(r['path']).name in {'native-host.obj','shaders.obj'}]
assert len(native)==2
for row in native:assert ident(row['path'])==row
images=[p for p in OUT.iterdir() if p.suffix.lower() in {'.exe','.map','.lib','.exp'}];assert len(images)==12
plan=dict(files=[ident(p) for p in images],retained_objects=retained,retained_native=native,
 remote_manifest=ident(OUT/'apple/cleanup-mac.json'),remote_retained_math=read(OUT/'apple/summary.json')['retained_math'])
save(OUT/'cleanup-plan.json',plan)
(OUT/'previous-test.ps1').write_bytes((ROOT/'test.ps1').read_bytes())
archive=DEST/'vulkan-row-pending.zip';assert not archive.exists()
exclude={p.resolve() for p in images}|{Path(r['path']).resolve() for r in retained}
files=[p for p in OUT.rglob('*') if p.is_file() and p.resolve() not in exclude and '__pycache__' not in p.parts and p.name not in {'archive-receipt.json','cleanup-result.json'}]
assert not any(p.suffix.lower() in {'.o','.obj','.exe','.map','.lib','.exp','.spv','.metallib','.a','.dylib'} for p in files)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,'stage/'+p.relative_to(OUT).as_posix())
 for row in sources:
  p=Path(row['path']);z.write(p,'current/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in files:assert hashlib.sha256(z.read('stage/'+p.relative_to(OUT).as_posix())).hexdigest()==ident(p)['sha256']
 entries=len(z.namelist())
receipt=dict(archive=ident(archive),entries=entries,windows_cleanup_files=12,windows_cleanup_bytes=sum(r['bytes'] for r in plan['files']),apple_cleanup=read(OUT/'apple/cleanup-mac.json')['files'])
save(OUT/'archive-receipt.json',receipt);save(DEST/'vulkan-row-pending-results.json',dict(**summary,archive=receipt['archive']))
print(json.dumps(receipt,indent=2))
