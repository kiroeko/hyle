from pathlib import Path
import difflib,hashlib,json
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,j):(OUT/n).write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
commands=read(OUT/'commands.json');assert all(c['exit'] is not None for c in commands)
current=read(OUT/'current-results.json');control=read(OUT/'control-results.json')
assert current['tests']==9 and current['failures']==0 and control['tests']==9 and control['failures']==3
for tag in ['current-run','paged-run']:
 assert next(c for c in reversed(commands) if c['tag']==tag)['exit']==0
links={name:read(OUT/(name+'-link.json')) for name in ['current','paged','control']}
for name,link in links.items():
 assert next(c for c in reversed(commands) if c['tag']==name+'-link')['command']==link['command']
 for row in link['objects']:assert ident(row['path'])==row
records=[read(p) for p in sorted(OUT.glob('src--*.cc.json'))+sorted(OUT.glob('tests--*.cc.json'))]
assert len(records)==8
owners={}
for row in records:
 assert row['exit']==0 and ident(row['source']['path'])==row['source'] and ident(row['object']['path'])==row['object']
 name='paged' if row['source']['path'].endswith('pending_paged_receiver_native_consumer.cc') else 'current'
 assert links[name]['command'].count(row['object']['path'])==1
 assert links[name]['selected_sources'][Path(row['source']['path']).relative_to(ROOT).as_posix()]==row['object']['path']
 text=(OUT/(name+'.map')).read_text(errors='replace');obj=Path(row['object']['path']).name
 hits=[x for x in text.splitlines() if x.rstrip().endswith(obj)];assert hits,obj;owners[obj]=hits[:5]
text=(OUT/'current.map').read_text(errors='replace');native=[x for x in text.splitlines() if 'ggml_backend_vk_device_supports_op' in x or 'ggml_backend_vk_init' in x]
assert native and all('native-host' in x for x in native)
save('selected-map-owners.json',dict(fresh=owners,retained_native=native))
air=read(OUT/'apple/summary.json');assert air['status']=='passed' and air['source_drift']==[]
for row in read(OUT/'apple/critical-source-identities.json'):
 actual=ident(ROOT/row['path']);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']
files=[Path(r['source']['path']) for r in records]
files += [ROOT/p for p in ['src/graph_batch/native_pending_regions.h','src/graph_batch/native_paged_regions.h',
 'src/graph_batch/CMakeLists.txt','src/graph_route_vulkan/native_paged_pending.h','src/graph_route_apple/native_paged_region.cc',
 'tests/graph_route_vulkan/CMakeLists.txt','docs/architecture/compute-design.md','docs/developer/current-work.md','docs/user/batch-attention.md']]
files=list(dict.fromkeys(files));save('final-source-identities.json',[ident(p) for p in files])
diff=[]
for p in files:
 old=OUT/'before'/p.relative_to(ROOT)
 before=old.read_text(encoding='utf-8-sig').splitlines(True) if old.exists() else []
 diff.extend(difflib.unified_diff(before,p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+p.relative_to(ROOT).as_posix(),tofile='current/'+p.relative_to(ROOT).as_posix()))
(OUT/'final-source.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
summary=dict(status='native-pending-input-capability-extracted-and-vulkan-row-pending-implemented',
 tests=dict(windows_passed=9,windows_total=9,new_vulkan_pending=3,existing_vulkan_ready=4,existing_cpu_ready_pending=2),
 original_control=dict(total=9,failed=3,reason='actual selected projected reader has no pending source admission',same_final_test_object=True),
 windows_native_page_control='passed; active Q2/18, two slots each, two page nodes share one native Update; original 64-step F16 receiver checks',
 apple_control=air,source_files=len(files),fresh_windows_cpp_tus=8,fresh_apple_cpp_tus=8,native_sdk_shader_math_rebuild=False,
 selected_owners=ident(OUT/'selected-map-owners.json'),
 changes=[
 'Extracted private native pending input/source capability from Q/K/V-specific NativePagedRegionVTable; old pending fields and overloads removed, no compatibility alias.',
 'Original Apple/Vulkan native page adapters and Vulkan checked row readers share exact physical input/source validation and commit; common Graph core unchanged.',
 'Only BatchResources owns CopyOutcomeSource and DependentCompletion; row slot borrows actual pending frame/source and original Run retires precise LeaseUseBatch guards.',
 'Shared/native submit reject incompatible input protocols before taking the Update; exact reader proof replaces prior lane-only admission check.',
 'Successful source recovery does not grant ready permissions or replay a consumed frame; original reset begins the next episode.'
 ],
 verified_scope=[
 'RTX4070, real kDevice bank/metadata; FP8 D512 original Map/Decode/Cast/View/Sink/Neg with independent existing FP64 budget, fused and split artifacts.',
 'FP4 D128 exact decoded BF16 rows, F32 mask and Cast/Neg in its actual supported dimension; no unsupported D512 Sink claim.',
 'Insufficient new-row copy coverage rejects and restores original native Update; full copy source and Graph actually observe Pending, no results/recovery before retirement.',
 'Unused physical page writer remains held, two old GraphOutput owners prevent recovery; actual original fence retirement then returns exact page writer and CopyBatchInvocation.',
 'Prior ready/permuted/empty/reader-rejection and CPU pending controls remain correct; migrated original native-page consumers pass on Windows and Air.'
 ],
 limits=[
 'No new whole-model accuracy, sustained throughput, peak-memory or Linux runtime measurement; full eight-model/22-profile goal remains active.',
 'Pending observation fixture queries the actual native fence and temporarily retains successful observation at NOT_READY; it proves original Completion/permission lifetime, not physical GPU blocking.',
 'No new native failure/cancel/close injection matrix; prior page risk evidence is not newly rerun by these consumer controls.',
 'Apple projected row Graph and Apple/Vulkan five-port paged scorer remain unfinished.',
 'Cold owned metadata transfers still have real allocation/wait costs; pending bind reserves original guard controls, no end-to-end zero-allocation claim.',
 'First test fixture erroneously attached D128 FP4 to D512-only Sink and was corrected; a test report field typo caused one strict compile failure. Product math/API/precision was not relaxed.',
 'Existing native page reset is not claimed to roll back all native program mutations after a later cold prepare failure.'
 ],goal='active; full model numerical acceptance/performance and remaining multi-platform functional journeys are incomplete')
save('summary.json',summary);print(json.dumps(dict(windows='9/9',control='3/9 expected failures',apple='passed',fresh_windows_tus=8,fresh_apple_tus=8,source_files=len(files)),indent=2))
