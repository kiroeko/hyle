param([switch]$ReclaimVulkanRowPending)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/vulkan-row-pending'))
$receipt = Get-Content -Raw -LiteralPath (Join-Path $stage 'archive-receipt.json') | ConvertFrom-Json
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $cursor = $item
    while ($null -ne $cursor -and $cursor.FullName.Length -ge $workspace.Length) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Identity changed: $path" }
}
Assert-Identity $receipt.archive
foreach ($entry in $plan.files) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if ([IO.Path]::GetDirectoryName($path) -ne $stage -or [IO.Path]::GetExtension($path) -notin '.exe','.map','.exp','.lib') { throw "Unexpected cleanup target: $path" }
    Assert-Identity $entry
}
foreach ($entry in @($plan.retained_objects) + @($plan.retained_native)) { Assert-Identity $entry }
Assert-Identity $plan.remote_manifest
$remote = Get-Content -Raw -LiteralPath $plan.remote_manifest.path | ConvertFrom-Json
$remote | Add-Member -MemberType NoteProperty -Name retained_math -Value $plan.remote_retained_math
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($remote | ConvertTo-Json -Depth 12 -Compress)))
$program = @'
import base64,hashlib,json,sys
from pathlib import Path
manifest=json.loads(base64.b64decode(sys.argv[1]));root=Path(manifest['root'])
expected=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/vulkan-row-pending/apple')
assert root==expected and root.resolve()==root and root.is_dir()
assert manifest['host']=='kiro@172.22.10.198'
assert len(manifest['files'])==2 and {Path(r['path']).name for r in manifest['files']}=={'pending-page','pending-page.map'}
def verify(row,child=False):
 p=Path(row['path']);assert p.is_absolute() and p.is_file() and p.resolve()==p and not p.is_symlink()
 if child:assert p.parent==root
 b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],str(p)
for row in manifest['files']:verify(row,True)
for row in manifest['retain']:verify(row,True)
for row in manifest['retained_math']:verify(row)
if sys.argv[2]=='reclaim':
 for row in manifest['files']:Path(row['path']).unlink()
for row in manifest['retain']:verify(row,True)
for row in manifest['retained_math']:verify(row)
print(json.dumps(dict(verified=True,deleted=sys.argv[2]=='reclaim',files=len(manifest['files']),bytes=sum(r['bytes'] for r in manifest['files']),retained_objects=len(manifest['retain']),retained_math=len(manifest['retained_math']))))
'@
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($program))
$mode = if ($ReclaimVulkanRowPending) { 'reclaim' } else { 'verify' }
$remoteCommand = "python3 -c 'import base64;exec(base64.b64decode(" + '"' + $encoded + '"' + "))' " + $payload + ' ' + $mode
$remoteOutput = & ssh -o BatchMode=yes -o ConnectTimeout=15 'kiro@172.22.10.198' $remoteCommand
if ($LASTEXITCODE -ne 0) { throw 'Remote exact cleanup verification/execution failed' }
$remoteResult = $remoteOutput | ConvertFrom-Json
if (-not $ReclaimVulkanRowPending) { Write-Output "Verified $($plan.files.Count) Windows and $($remoteResult.files) Air images/maps. Use -ReclaimVulkanRowPending to reclaim."; return }
foreach ($entry in $plan.files) { Remove-Item -LiteralPath $entry.path -Force }
foreach ($entry in @($plan.retained_objects) + @($plan.retained_native)) { Assert-Identity $entry }
$result = [ordered]@{archive_verified=$true;windows_files=$plan.files.Count;windows_bytes=($plan.files | Measure-Object bytes -Sum).Sum;retained_windows_objects=$plan.retained_objects.Count;retained_native=$plan.retained_native.Count;apple=$remoteResult;other_cache_retained=$true}
$result | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $stage 'cleanup-result.json')
$result | ConvertTo-Json -Depth 8
