from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent;PREVIOUS=ARCH/'row-cache-region-projection'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,j):(OUT/p).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
BASE=read(PREVIOUS/'current-link.json');LINK=BASE['command']
RECIPES={r['source']:r['command'] for r in read(ARCH/'native-ready-pages/windows/compile-plan.json')}
for p in PREVIOUS.glob('*.cc.json'):
 r=read(p)
 if r.get('exit')==0:RECIPES[Path(r['source']['path']).relative_to(ROOT).as_posix()]=r['command']
RECIPES['src/graph_batch/native_pending_regions.cc']=RECIPES['src/graph_batch/batch.cc']
RECIPES['src/graph_route_vulkan/native_paged_pending.cc']=RECIPES['src/graph_route_vulkan/native_paged_region.cc']
RECIPES['tests/graph_route_vulkan/row_cache_pending_projection_test.cc']=RECIPES['tests/graph_route_vulkan/row_cache_projection_test.cc']
PENDING=read(ARCH/'native-pending-pages/windows/commands.json')
RECIPES['tests/compute_batch/pending_paged_receiver_native_consumer.cc']=next(r['command'] for r in reversed(PENDING) if r['tag']=='tests--compute_batch--pending_paged_receiver_native_consumer-compile' and r['exit']==0)
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':LINK[0].replace('link.exe','cl.exe'),'CMAKE_C_COMPILER':LINK[0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in LINK if Path(x).suffix.lower()=='.lib' and Path(x).is_absolute()))+os.pathsep+env['PATH']
env.update(DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~',VSLANG='1033')
def run(tag,command,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';row=dict(tag=tag,command=list(map(str,command)),cwd=str(ROOT),stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
 rows.append(row);save('commands.json',rows);print('START',stem,flush=True);start=time.monotonic()
 with (OUT/row['stdout']).open('wb') as a,(OUT/row['stderr']).open('wb') as b:
  p=subprocess.Popen(row['command'],cwd=ROOT,env=env,stdout=a,stderr=b,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=p.pid;save('commands.json',rows);row['exit']=p.wait(timeout=timeout)
 row['seconds']=time.monotonic()-start;save('commands.json',rows)
 print('END',stem,row['exit'],flush=True);print((OUT/row['stdout']).read_text(errors='replace')[-7500:],flush=True);print((OUT/row['stderr']).read_text(errors='replace')[-4500:],flush=True)
 return row['exit']
def object_path(source):return OUT/(source.replace('/','--').replace('.cc','.obj'))
def compile_one(source):
 original=RECIPES[source];args=[x for x in original if not x.lower().endswith(('.cc','.cpp')) and not x.lower().startswith(('/fo','/fd'))]
 if '/W4' not in args:args.append('/W4')
 if '/WX' not in args:args.append('/WX')
 args += [str(ROOT/source),'/Fo'+str(object_path(source))];before=ident(ROOT/source);code=run('compile-'+Path(source).stem,args);assert ident(ROOT/source)==before
 result=dict(source=before,command=args,exit=code)
 if code==0:result['object']=ident(object_path(source))
 save(source.replace('/','--')+'.json',result);return code
def link(mode):
 objects=[x for x in LINK if x.lower().endswith('.obj')];selected=BASE['selected_sources'].copy();replacements={};extras=[]
 if mode!='control':
  for p in OUT.glob('src--*.cc.json'):
   r=read(p);assert r['exit']==0 and ident(r['source']['path'])==r['source'] and ident(r['object']['path'])==r['object'];source=Path(r['source']['path']).relative_to(ROOT).as_posix()
   if source in selected:replacements[selected[source]]=r['object']['path']
   elif source=='src/graph_route_vulkan/native_paged_pending.cc':
    original=next(x for x in objects if x.endswith('paging-risks\\native-pending.obj'));replacements[original]=r['object']['path']
   else:assert source=='src/graph_batch/native_pending_regions.cc',source;extras.append(r['object']['path'])
   selected[source]=r['object']['path']
 objects=[replacements.get(x,x) for x in objects]+extras
 if mode=='paged':
  oldtests={str(PREVIOUS/(s.replace('/','--').replace('.cc','.obj'))) for s in ['tests/graph_route_vulkan/row_cache_projection_test.cc','tests/compute_route_vulkan/row_cache_padded_test.cc','tests/graph_batch/row_cache_graph_test.cc','tests/graph_batch/row_cache_pending_graph_test.cc']}
  objects=[x for x in objects if x not in oldtests]+[str(object_path('tests/compute_batch/pending_paged_receiver_native_consumer.cc'))]
 else:objects.append(str(object_path('tests/graph_route_vulkan/row_cache_pending_projection_test.cc')))
 assert len(objects)==len(set(objects))
 # Every reused object must retain the exact previous tested identity.
 prior={x['path']:x for x in BASE['objects']}
 for x in objects:
  if x in prior:assert ident(x)==prior[x]
 flags=[x for x in LINK[1:] if not x.lower().endswith(('.obj','.lib')) and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 libs=[x for x in LINK if x.lower().endswith('.lib')]
 args=[LINK[0],*flags,*objects,*libs,'/OUT:'+str(OUT/(mode+'.exe')),'/MAP:'+str(OUT/(mode+'.map')),'/IMPLIB:'+str(OUT/(mode+'.lib'))]
 selected={k:v for k,v in selected.items() if v in objects}
 for source in ['tests/graph_route_vulkan/row_cache_projection_test.cc','tests/compute_route_vulkan/row_cache_padded_test.cc','tests/graph_batch/row_cache_graph_test.cc','tests/graph_batch/row_cache_pending_graph_test.cc']:
  path=str(PREVIOUS/(source.replace('/','--').replace('.cc','.obj')))
  if path in objects:selected[source]=path
 for source in ['tests/graph_route_vulkan/row_cache_pending_projection_test.cc','tests/compute_batch/pending_paged_receiver_native_consumer.cc']:
  path=str(object_path(source))
  if path in objects:selected[source]=path
 save(mode+'-link.json',dict(command=args,selected_sources=selected,objects=[ident(x) for x in objects],libraries=BASE['libraries'],replacements=replacements))
 return run(mode+'-link',args)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='compile':
  for source in sys.argv[2:]:
   code=compile_one(source)
   if code:raise SystemExit(code)
 elif action=='link':raise SystemExit(link(sys.argv[2]))
 elif action=='run':
  mode=sys.argv[2];args=[OUT/(mode+'.exe')]
  if mode!='paged':args+=['--gtest_filter=VulkanProjectedRowPending.*:VulkanProjectedRowGraph.*:VulkanRowCachePadded.TypedFirstPrefillConsumesMaskAndEmptyHistoryHoldsAllWriters:CpuPagedRowCacheGraph.*','--gtest_color=no','--gtest_output=json:'+str(OUT/(mode+'-results.json'))]
  raise SystemExit(run(mode+'-run',args,timeout=180))
 else:raise ValueError(action)
