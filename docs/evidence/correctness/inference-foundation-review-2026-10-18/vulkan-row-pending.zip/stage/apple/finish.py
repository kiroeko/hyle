from pathlib import Path
import importlib.util, json, re, shutil, sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner',OUT/'run.py')
run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
ROOT=run.ROOT

code=r'''
from pathlib import Path
import hashlib,json,re,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root']);base=Path(p['base'])
def identity(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
def save(name,data):(r/name).write_text(json.dumps(data,indent=2)+'\n')
link=json.loads((r/'010-link.command.json').read_text())
inputs=[identity(x) for x in link['argv'] if x.startswith('/') and x.endswith(('.o','.a','.dylib'))]
assert len({x['path'] for x in inputs})==len(inputs)
save('link-input-identities.json',inputs)
fresh=[identity(r/(x[4:].replace('/','--').replace('.cc','.o'))) for x in p['sources']]
assert len(fresh)==8
text=(r/'pending-page.map').read_text()
objects=text.split('# Object files:\n',1)[1].split('# Sections:',1)[0]
owner_rows=[]
for row in fresh:
 matches=[line for line in objects.splitlines() if line.endswith(row['path'])]
 assert len(matches)==1,(row['path'],matches)
 owner_rows.append(dict(object=row,selected=matches[0]))
save('selected-owners.json',owner_rows)
dependencies={}
staged={x['path']:x for x in json.loads((r/'source-identities.json').read_text())}
for source in p['sources']:
 obj=r/(source[4:].replace('/','--').replace('.cc','.o'))
 raw=Path(str(obj)+'.d').read_text().replace('\\\n',' ')
 for path in raw.split(': ',1)[1].split():
  q=Path(path).resolve()
  if not q.is_file():continue
  if q.is_relative_to(r):
   logical=q.relative_to(r).as_posix();row=identity(q)
   assert logical in staged,(logical,'not staged')
   assert (row['bytes'],row['sha256'])==(staged[logical]['bytes'],staged[logical]['sha256'])
   dependencies[logical]=dict(**row,logical=logical,staged=True)
  elif q.is_relative_to(base):
   logical=q.relative_to(base).as_posix()
   if logical.startswith(('include/','src/','third_party/')):
    row=identity(q);dependencies[str(q)]=dict(**row,logical=logical,staged=False)
save('dependency-identities.json',list(dependencies.values()))
cleanup=dict(host='kiro@172.22.10.198',root=str(r),files=[identity(r/'pending-page'),identity(r/'pending-page.map')],retain=fresh)
assert not {x['path'] for x in cleanup['files']} & {x['path'] for x in fresh}
save('cleanup-mac.json',cleanup)
hardware={key:subprocess.check_output(argv,text=True).strip() for key,argv in {
 'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],
 'memory':['sysctl','-n','hw.memsize'],'system':['sw_vers'],'compiler':['/usr/bin/clang++','--version']}.items()}
live=json.loads((r/'live.json').read_text());assert live['terminal'] and live['exit']==0
ps=subprocess.run(['ps','-p',str(live['pid']),'-o','command='],capture_output=True,text=True)
assert ps.returncode!=0 or str(r/'pending-page') not in ps.stdout
save('final-verification.json',dict(hardware=hardware,final=live,live_process=False,
 map_selected_owners=len(owner_rows),link_inputs=len(inputs),dependencies=len(dependencies),
 staged_dependencies=sum(x['staged'] for x in dependencies.values()),
 cleanup_count=len(cleanup['files']),cleanup_bytes=sum(x['bytes'] for x in cleanup['files']),retained_objects=len(fresh)))
print(json.dumps(dict(link_inputs=len(inputs),fresh=len(fresh),dependencies=len(dependencies),cleanup_bytes=sum(x['bytes'] for x in cleanup['files']),hardware=hardware)))
'''
result=run.air.ssh(code,json.dumps(dict(root=run.REMOTE,base=run.air.REMOTE,sources=run.SOURCES)).encode(),timeout=35)
(OUT/'013-verify.stdout.log').write_bytes(result.stdout)
(OUT/'013-verify.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0
run.collect()

staged=json.loads((OUT/'source-identities.json').read_text())
drift=[x['path'] for x in staged if run.identity(ROOT/x['path'])!=x]
assert not drift,drift
dependencies=json.loads((OUT/'results/dependency-identities.json').read_text())
for row in dependencies:
 path=ROOT/row['logical']
 if path.is_file():
  actual=run.identity(path)
  assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),(row,actual)
critical=run.SOURCES+['src/graph_batch/native_pending_regions.h','src/graph_batch/native_paged_regions.h',
 'include/hyle/graph/detail/region_access.h','src/graph/execution_source_internal.h']
for source in critical:
 target=OUT/'candidate'/source;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/source,target)
shutil.copyfile(OUT/'results/cleanup-mac.json',OUT/'cleanup-mac.json')
final=json.loads((OUT/'results/final-verification.json').read_text())
summary=dict(status='passed',scope='Apple existing native page pending control after common capability extraction; no Apple projected-row pending claim',
 hardware=final['hardware'],compile_commands=[f'{i:03}-compile' for i in range(2,10)],link='010-link',run='011-run',
 checks=['64 steps each F16 and BF16','active Q rows 2 and 18; two original slots each',
 'two page nodes share one native CopyBatchUpdate','CPU Abs/Cast and Cast/Neg fragments',
 'both published outputs / exact page frame / untouched history / same generation',
 '196608 dirty bytes each dtype; no source wait before attention'],
 source_drift=drift,actual_dependencies=len(dependencies),link_inputs=final['link_inputs'],fresh_host_tus=8,
 no_sdk_shader_or_math_rebuild=True,retained_math=json.loads((OUT/'results/retained-math.json').read_text()),
 cleanup=dict(manifest='cleanup-mac.json',files=final['cleanup_count'],bytes=final['cleanup_bytes']),
 retained_stage_objects=8,live_process=False,
 caveat='Original pending main object reused; mathematical implementation and colocated metallib reused. No additional matrix or performance claim.')
run.save('summary.json',summary)
run.save('critical-source-identities.json',[run.identity(ROOT/source) for source in critical])
run.save('receipt.json',dict(summary=run.identity(OUT/'summary.json'),cleanup=run.identity(OUT/'cleanup-mac.json'),
 critical_sources=run.identity(OUT/'critical-source-identities.json')))
print(json.dumps(summary,indent=2))
