from pathlib import Path
import base64, hashlib, importlib.util, json, re, sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
spec = importlib.util.spec_from_file_location('air', OUT.parents[1] / 'apple-page-invocation/air.py')
air = importlib.util.module_from_spec(spec)
spec.loader.exec_module(air)
REMOTE = air.REMOTE + '/vulkan-row-pending/apple'
BASELINE = json.loads((OUT / '000-inspect.json').read_text())
SOURCES = ['src/graph_batch/batch.cc', 'src/graph_batch/native_paged_regions.cc',
           'src/graph_batch/native_pending_regions.cc', 'src/graph_route_apple/native_paged_region.cc',
           'src/graph/region_access.cc', 'src/graph/resources.cc',
           'src/graph_batch/row_cache_node.cc', 'src/graph_route_cpu/ggml_region.cc']

def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')

def identity(path):
    data = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

RUN = r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.loads(sys.stdin.buffer.read()); r=Path(p['root']);r.mkdir(parents=True,exist_ok=True)
def identity(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
tag=p['tag'];row=dict(tag=tag,argv=p['argv'],cwd=str(r),started=time.time(),exit=None)
(r/(tag+'.command.json')).write_text(json.dumps(row,indent=2)+'\n')
with (r/(tag+'.stdout.log')).open('wb') as so,(r/(tag+'.stderr.log')).open('wb') as se:
 child=subprocess.Popen(row['argv'],cwd=r,stdout=so,stderr=se)
 row['pid']=child.pid;(r/'live.json').write_text(json.dumps(row,indent=2)+'\n')
 row['exit']=child.wait(timeout=55)
row.update(terminal=True,finished=time.time(),outputs=[identity(x) for x in p.get('outputs',[]) if Path(x).is_file()])
(r/(tag+'.result.json')).write_text(json.dumps(row,indent=2)+'\n');(r/'live.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(dict(tag=tag,exit=row['exit'],seconds=row['finished']-row['started'],outputs=row['outputs'])));print((r/(tag+'.stdout.log')).read_text(errors='replace')[-8000:]);print((r/(tag+'.stderr.log')).read_text(errors='replace')[-8000:]);sys.exit(row['exit'])
'''

def invoke(tag, argv, outputs=()):
    save(tag+'.planned.json', dict(argv=argv, outputs=list(outputs)))
    result=air.ssh(RUN,json.dumps(dict(root=REMOTE,tag=tag,argv=argv,outputs=list(outputs))).encode(),timeout=65)
    (OUT/(tag+'.transport.stdout.log')).write_bytes(result.stdout)
    (OUT/(tag+'.transport.stderr.log')).write_bytes(result.stderr)
    print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'))
    if result.returncode:raise SystemExit(result.returncode)

def stage():
    files={}
    def add(path):
        path=path.resolve()
        if path in files or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:return
        files[path]=path.relative_to(ROOT).as_posix()
        for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
            candidates=[path.parent/name,ROOT/name,ROOT/'include'/name]
            candidates += [ROOT/folder/name for folder in ['src/graph','src/compute','src/compute_route_apple',
                'src/compute_provider_ggml','src/compute_ggml_runtime','third_party/ds4_quantization',
                'third_party/torchao_cpu','third_party/bitsandbytes_cpu','third_party/awq_cpu',
                'third_party/compressed_tensors_cpu','third_party/mlx_cpu_quant']]
            for candidate in candidates:
                if candidate.is_file():add(candidate);break
    for source in SOURCES:add(ROOT/source)
    rows=[dict(**identity(p), data=base64.b64encode(p.read_bytes()).decode()) for p in sorted(files)]
    save('source-identities.json',[{k:v for k,v in row.items() if k!='data'} for row in rows])
    code=r'''
from pathlib import Path
import base64,hashlib,json,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root']).resolve();r.mkdir(parents=True,exist_ok=True)
for row in p['files']:
 q=(r/row['path']).resolve();assert q.is_relative_to(r)
 b=base64.b64decode(row['data']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/'source-identities.json').write_text(json.dumps([{k:v for k,v in row.items() if k!='data'} for row in p['files']],indent=2)+'\n')
print(json.dumps(dict(files=len(p['files']),bytes=sum(row['bytes'] for row in p['files']))))
'''
    result=air.ssh(code,json.dumps(dict(root=REMOTE,files=rows)).encode(),timeout=30)
    (OUT/'001-stage.stdout.log').write_bytes(result.stdout);(OUT/'001-stage.stderr.log').write_bytes(result.stderr)
    print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0

def build(index):
    source=SOURCES[index]
    template='src/graph_batch/native_paged_regions.cc' if 'native_pending_regions' in source else source
    original=next(x['row']['command'] for x in BASELINE['compile'] if x['source']==template)
    argv=original.copy()
    old_source=next(x for x in argv if x.endswith('/'+template))
    argv[argv.index(old_source)]=REMOTE+'/'+source
    obj=REMOTE+'/'+source[4:].replace('/','--').replace('.cc','.o')
    argv[argv.index('-o')+1]=obj
    argv[1:1]=['-I'+REMOTE+'/include','-I'+REMOTE,'-I'+REMOTE+'/src/graph',
               '-I'+REMOTE+'/src/compute','-I'+REMOTE+'/src/graph_batch',
               '-I'+REMOTE+'/src/compute_route_apple','-I'+REMOTE+'/src/graph_route_apple']
    argv+=['-MMD','-MF',obj+'.d']
    invoke(f'{index+2:03}-compile',argv,[obj,obj+'.d'])

def link():
    argv=json.loads((OUT.parents[1]/'apple-cross-runtime/link-plan.json').read_text())['argv']
    old_main=next(x for x in argv if x.endswith('/cross-runtime/test.o'))
    argv[argv.index(old_main)]=BASELINE['pending_object']['path']
    for source in SOURCES:
        suffix='/src--'+source[4:].replace('/','--').replace('.cc','.o')
        if 'native_pending_regions' in source:
            argv.insert(1,REMOTE+'/'+source[4:].replace('/','--').replace('.cc','.o'));continue
        found=[x for x in argv if x.endswith(suffix)]
        assert len(found)==1,(source,found)
        argv[argv.index(found[0])]=REMOTE+'/'+source[4:].replace('/','--').replace('.cc','.o')
    argv[argv.index('-o')+1]=REMOTE+'/pending-page'
    argv=[('-Wl,-map,'+REMOTE+'/pending-page.map') if x.startswith('-Wl,-map,') else x for x in argv]
    save('link-plan.json',dict(argv=argv))
    invoke('010-link',argv,[REMOTE+'/pending-page',REMOTE+'/pending-page.map'])

def collect():
    code='from pathlib import Path;import base64,json;r=Path('+repr(REMOTE)+');print(json.dumps([dict(path=p.name,data=base64.b64encode(p.read_bytes()).decode()) for p in r.iterdir() if p.is_file() and p.suffix in {".json",".log",".d"}]))'
    result=air.ssh(code,timeout=30);assert result.returncode==0,result.stderr
    dest=OUT/'results';dest.mkdir(exist_ok=True)
    for row in json.loads(result.stdout):(dest/row['path']).write_bytes(base64.b64decode(row['data']))
    print('collected',len(json.loads(result.stdout)))

if __name__=='__main__':
    action=sys.argv[1]
    if action=='stage':stage()
    elif action=='compile':build(int(sys.argv[2]))
    elif action=='link':link()
    elif action=='run':invoke('011-run',[REMOTE+'/pending-page'])
    elif action=='collect':collect()
    else:raise ValueError(action)
