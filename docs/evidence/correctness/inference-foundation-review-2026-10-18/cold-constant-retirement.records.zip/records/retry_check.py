"""Recompile only the strengthened same-cache fault case against passed objects."""
from pathlib import Path
import sys
import cold_check as check

passed = check.STAGE / 'checks/20261019T051232-8e1188d0'
base = check.read(passed / 'plan.json')
assert check.read(passed / 'tests-summary.json')['failures'] == 0
arguments = base['link']
inputs = [check.snapshot(arg, True) for arg in arguments
          if not arg.startswith('/') and Path(arg).is_absolute()
          and Path(arg).suffix.lower() in ('.obj', '.lib')]
assert all(row['exists'] for row in inputs)
base_path = check.STAGE / 'retry-base-link.json'
check.save(base_path, {'command': arguments, 'inputs': inputs})
check.LINK_PLAN = base_path
source = 'tests/graph/region_provider_test.cc'
stem = 'tests--graph--region_provider_test'
check.RECIPES = {source: (str(passed / (stem + '-identity.json')), None,
                          str(passed / (stem + '.obj')))}
sys.argv = [__file__, '--source', source, '--target-test',
            'GraphPacking.UnknownPreparationObservationRetainsOwnersUntilNativeRetirement',
            '--test']
check.main()
