﻿param([switch]$ReclaimColdConstantRetirement)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimColdConstantRetirement) { throw 'Use -ReclaimColdConstantRetirement for the reviewed exact targets.' }
$repoRoot = $PSScriptRoot
$taskRoot = [IO.Path]::GetFullPath((Join-Path $repoRoot '.scratch/architecture-refactor-2026-10-18/cold-constant-retirement'))
$receiptPath = Join-Path $taskRoot 'reclaim-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Reclaim already recorded; do not replay.' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'archive-verification.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $proof.path -Algorithm SHA256).Hash -ne $proof.sha256) { throw 'Evidence archive changed.' }
$targets = @(Get-Content -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task directory: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe', '.map', '.lib', '.exp')) { throw "Unexpected target: $resolved" }
  if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
$bytes = 0L
foreach ($entry in $targets) {
  Remove-Item -LiteralPath $entry.path
  $bytes += $entry.bytes
}
$receipt = [ordered]@{deleted_files=$targets.Count; reclaimed_bytes=$bytes; recursive=$false; archive=$proof; targets=$targets; objects_retained=$true; native_SDK_retained=$true; raw_vectors_retained=$true}
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "Reclaimed $bytes bytes from $($targets.Count) exact files; retained objects, SDKs and raw vectors."
