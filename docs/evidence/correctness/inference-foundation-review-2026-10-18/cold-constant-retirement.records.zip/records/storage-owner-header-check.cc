#include "hyle/compute/storage_owner.h"

#include <concepts>
#include <memory>
#include <utility>

namespace c = hyle::compute;
namespace m = hyle::mem;

struct Resource final {
  Resource() = default;
  Resource(const Resource &) = delete;
  Resource &operator=(const Resource &) = delete;
  Resource(Resource &&) noexcept = default;
  Resource &operator=(Resource &&) noexcept = default;
  m::MemoryResourceRef ref() const noexcept { return m::system_resource(); }
};
struct Allocator final {
  m::AllocatorRef ref() noexcept { return m::system_allocator(); }
};
struct ThrowingMove final {
  ThrowingMove() = default;
  ThrowingMove(ThrowingMove &&) noexcept(false) {}
  ThrowingMove &operator=(ThrowingMove &&) noexcept = default;
  m::MemoryResourceRef ref() const noexcept { return m::system_resource(); }
};
struct ThrowingRef final {
  m::MemoryResourceRef ref() const noexcept(false) { return m::system_resource(); }
};
template<class T>
concept CanAdopt = requires(const c::Context &context, T &&value) {
  c::StorageOwner::adopt(context, std::forward<T>(value));
};
static_assert(CanAdopt<Resource>);
static_assert(!CanAdopt<Resource &>);
static_assert(!CanAdopt<const Resource>);
static_assert(!CanAdopt<ThrowingMove>);
static_assert(!CanAdopt<ThrowingRef>);
static_assert(std::copyable<c::StorageOwner>);
static_assert(std::movable<c::StorageOwner>);

// Instantiate both typed factories and the existing lease handoff; this file
// is syntax-checked only and is never linked or executed.
void instantiate(const c::Context &context, m::Buffer &&buffer) {
  auto first = c::StorageOwner::adopt(context, Resource{});
  auto second = c::StorageOwner::adopt(
      context, Resource{}, std::make_shared<Allocator>());
  if (first) {
    (void)first->valid();
    (void)first->ref();
    (void)first->allocator();
    (void)first->owns_allocator(context.metadata_allocator());
    (void)first->context_identity();
    (void)first->adopt_buffer(std::move(buffer));
  }
  (void)second;
}
