"""Compile two frozen CUDA fixture TUs and link only. Never runs a GPU test."""
from pathlib import Path
import argparse
import datetime as dt
import sys
import uuid

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cold_check as c
import cuda_check as product

BASE = c.ARCH / "cuda-reshape-reuse/cuda-tests-link-plan.json"
TESTS = {
    "region-test": ("tests/graph_provider_ggml_cuda/region_test.cc",
        "cuda-bf16-chain-fusion/region-test-identity.json"),
    "route-test": ("tests/graph_route_cuda/ggml_test.cc",
        "cuda-dense-projection/route-test-identity.json"),
}
REMOVE = [c.ARCH / name for name in ("cuda-stable-silu/tensor-test.obj",
    "cuda-stable-silu/projection-test.obj", "cuda-reshape-reuse/stable-test.obj")]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--product-plan", required=True)
    parser.add_argument("--build", action="store_true", help="Compile/link only; default prepares")
    args = parser.parse_args()
    source_plan = Path(args.product_plan).resolve()
    p = c.read(source_plan)
    image_receipt = c.read(source_plan.parent / "candidate-image.json")
    if c.snapshot(image_receipt["image"]["path"], True)["sha256"] != image_receipt["image"]["sha256"]:
        raise ValueError("Completed product image drift")
    original = c.read(BASE)
    command = original["command"]
    session = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    out = c.STAGE / "cuda-test-checks" / session
    out.mkdir(parents=True, exist_ok=False)
    replacements, extras, retained, frozen = {}, [], [], set()
    for item in p["reused_cpu"]:
        old = item["old_object"]
        if old and command.count(old) == 1:
            replacements[c.key(old)] = item["object"]["path"]
        elif item["action"] == "add":
            extras.append(item["object"]["path"])
        else:
            raise ValueError("Missing shared CPU owner in test closure: " + str(old))
        retained.append(item["object"])
    for item in p["compile"]:
        old = item["old_object"]["path"]
        # The Qwen main is intentionally absent from a gtest executable.
        if command.count(old) == 0 and item["tag"] == "consumer":
            continue
        if command.count(old) != 1:
            raise ValueError("Missing product owner in test closure: " + old)
        identity = c.read(source_plan.parent / (item["tag"] + "-identity.json"))
        replacements[c.key(old)] = identity["object"]["path"]
        retained.append(identity["object"])
    compiles = []
    for tag, (name, receipt) in TESTS.items():
        recipe_path = c.ARCH / receipt
        recipe = c.read(recipe_path)
        command_receipt = recipe_path
        if "command" not in recipe:
            command_receipt = recipe_path.with_name(
                recipe_path.name.replace("-identity.json", "-compile.command.json"))
            recipe["command"] = c.read(command_receipt)["command"]
        old = recipe["object"]["path"]
        if command.count(old) != 1:
            raise ValueError("Expected exact old test object: " + old)
        source = c.ROOT / name
        fresh = str(out / (tag + ".obj"))
        replacements[c.key(old)] = fresh
        argv = c.compile_command(recipe["command"], source, tag, out)
        compiles.append({"tag": tag, "source": c.snapshot(source, True),
            "recipe": c.snapshot(recipe_path, True),
            "command_receipt": c.snapshot(command_receipt, True),
            "command": argv, "object": fresh})
        frozen.add(source)
        frozen.update(product.product_dependencies(recipe["command"]))
    frozen.update(c.ROOT / name for name in ("tests/graph_ggml_constant_test.h",
        "tests/graph_ggml_constant_cast_test.h"))
    removed = {c.key(path) for path in REMOVE}
    linked = [replacements.get(c.key(arg), arg) if not arg.startswith("/") else arg for arg in command
        if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))
        and (arg.startswith("/") or c.key(arg) not in removed)]
    linked += extras + ["/OUT:" + str(out / "fusion-tests.exe"),
        "/MAP:" + str(out / "fusion-tests.map"), "/IMPLIB:" + str(out / "fusion-tests.lib")]
    for row in original["inputs"]:
        if c.key(row["path"]) in replacements or c.key(row["path"]) in removed:
            continue
        actual = c.snapshot(row["path"], True)
        if actual.get("sha256") != row["sha256"]:
            raise ValueError("Cached test-closure input drift: " + row["path"])
        retained.append(actual)
    for row in retained:
        if c.snapshot(row["path"], True).get("sha256") != row["sha256"]:
            raise ValueError("Retained input drift: " + row["path"])
    source_contract = [c.snapshot(path, True) for path in sorted(frozen, key=str)]
    inputs = [arg for arg in linked if not arg.startswith("/") and Path(arg).is_absolute()
              and Path(arg).suffix.lower() in (".obj", ".lib")]
    env, runtime = c.environment(linked, inputs, out)
    plan = {"base": c.snapshot(BASE, True), "product_plan": c.snapshot(source_plan, True),
        "product_image": image_receipt["image"], "compile": compiles, "link": linked,
        "source_contract": source_contract, "retained_inputs": retained,
        "excluded_unrelated_test_objects": [str(path) for path in REMOVE],
        "runtime_path_directories": runtime, "GPU_run": False,
        "SDK_rebuild": False, "object_copy": False}
    c.save(out / "plan.json", plan)
    print("PLAN", str(out / "plan.json"), flush=True)
    if not args.build:
        return
    (out / "tmp").mkdir()
    for item in compiles:
        c.execute(item["tag"] + "-compile", item["command"], env, out)
        c.save(out / (item["tag"] + "-identity.json"), {"source": item["source"],
            "object": c.snapshot(item["object"], True), "command": item["command"]})
    for row in source_contract + p["source_contract"]:
        if c.snapshot(row["path"], True).get("sha256") != row["sha256"]:
            raise ValueError("Frozen source/header changed during test compilation: " + row["path"])
    c.save(out / "fusion-tests-link-plan.json", {"command": linked,
        "inputs": [product.identity(path) for path in inputs], "GPU_run": False,
        "SDK_rebuild": False, "object_copy": False})
    c.execute("fusion-tests-link", linked, env, out)
    c.save(out / "fusion-tests-image.json", {"image": product.identity(out / "fusion-tests.exe"),
        "link_plan": product.identity(out / "fusion-tests-link-plan.json")})
    print("READY", str(out / "fusion-tests-image.json"), flush=True)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, StopIteration) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
