"""Six CUDA host TUs plus the final CPU-owned Graph closure. No GPU runs.

Default/--dry-run writes an immutable plan. --build --plan PATH executes only
that plan's six cl commands and link command. SDK, native CUDA kernels and
tensor_program are reused in place; no dependency/object copy is performed.
"""
from pathlib import Path
import argparse
import datetime as dt
import json
import sys
import uuid

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cold_check as c

STAGE, ARCH, ROOT = c.STAGE, c.ARCH, c.ROOT
BASE = ARCH / "cuda-reshape-reuse/candidate-link-plan.json"
CPU = STAGE / "checks/20261019T051232-8e1188d0"
HOST = {
    "provider": ("src/compute_provider_ggml_cuda/ggml_cuda_provider.cc",
        "cuda-capture-reuse/validation/binding-reuse/ggml-provider-identity.json", None,
        "cuda-capture-reuse/validation/binding-reuse/ggml-provider.obj"),
    "region": ("src/graph_provider_ggml_cuda/ggml_cuda_region.cc",
        "cuda-stable-silu/region-identity.json", None, "cuda-stable-silu/region.obj"),
    "graph-cuda-context": ("src/graph_route_cuda/cuda_context.cc",
        "qwen-progress-journey/compile-recipes.json", "graph-cuda-context",
        "qwen-progress-journey/graph-cuda-context.obj"),
    "consumer": ("tools/qwen35_text/main.cc", "cuda-capture-reuse/qwen-consumer-identity.json", None,
        "cuda-capture-reuse/qwen-consumer.obj"),
    "batch": ("src/graph_batch/batch.cc", "cuda-capture-reuse/graph_batch--batch-identity.json", None,
        "cuda-capture-reuse/graph_batch--batch.obj"),
    "materialized-invocation": ("src/graph_batch/materialized_invocation.cc",
        "legacy-native-retirement/public-mla/windows-current-owners/src--graph_batch--materialized_invocation-receipt.json", None,
        "legacy-native-retirement/public-mla/windows-current-owners/src--graph_batch--materialized_invocation.obj"),
}


def identity(path):
    row = c.snapshot(path, True)
    return {name: row[name] for name in ("path", "bytes", "sha256")}


def product_dependencies(command):
    paths = set()
    for index, arg in enumerate(command):
        if arg.lower() == "/sourcedependencies":
            dep = Path(command[index + 1])
            if dep.is_file():
                data = c.read(dep).get("Data", {})
                for value in data.get("Includes", []):
                    path = Path(value).resolve()
                    if any(path.is_relative_to(ROOT / name) for name in ("include", "src")):
                        paths.add(path)
        elif arg.lower().startswith("/fi"):
            path = Path(arg[3:]).resolve()
            if path.is_file():
                paths.add(path)
    return paths


def include_paths(command):
    rows = []
    for arg in command:
        value = arg[len("/external:I"):] if arg.lower().startswith("/external:i") else \
                arg[2:] if arg.lower().startswith("/i") else None
        if value:
            rows.append({"argument": arg, "path": value, "exists": Path(value).is_dir()})
    return rows


def prepare(cpu):
    cpu = Path(cpu).resolve()
    passed = c.read(cpu / "tests-summary.json")
    if len(passed["cases"]) != 8 or passed["failures"] or passed["skipped"]:
        raise ValueError("Final CPU proof is not the expected eight passing cases")
    base, cpu_plan = c.read(BASE), c.read(cpu / "plan.json")
    command = base["command"]
    session = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    output = STAGE / "cuda-checks" / session
    output.mkdir(parents=True, exist_ok=False)
    replacements, reuse, extras, frozen = {}, [], [], set()
    cpu_inventory = {c.key(row["source"]["path"]): row for row in cpu_plan["source_inventory"]}
    for row in cpu_plan["compile"]:
        name = row["source_name"]
        if name.startswith("tests/"):
            continue
        old = (cpu_inventory[c.key(row["source"]["path"])].get("cached_object") or {}).get("path")
        relevant = old and command.count(old) == 1
        if not relevant and name != "src/compute/resource_budget.cc":
            continue
        identity = c.read(cpu / (row["stem"] + "-identity.json"))
        actual = c.snapshot(identity["object"]["path"], True)
        if actual.get("sha256") != identity["object"]["sha256"]:
            raise ValueError("Fresh CPU object drift: " + name)
        source = c.snapshot(identity["source"]["path"], True)
        if source["sha256"] != identity["source"]["sha256"]:
            raise ValueError("Fresh CPU source drift: " + name)
        frozen.add(Path(source["path"]))
        frozen.update(product_dependencies(identity["command"]))
        if relevant:
            replacements[c.key(old)] = actual["path"]
        else:
            extras.append(actual["path"])
        reuse.append({"source": source, "object": actual, "old_object": old,
                      "identity": c.snapshot(cpu / (row["stem"] + "-identity.json"), True),
                      "action": "replace" if relevant else "add"})
    if len(reuse) != 9 or len(extras) != 1:
        raise ValueError("Expected eight shared Graph/Progress objects plus ResourceBudget")
    compiles = []
    for tag, (name, receipt, wanted, old) in HOST.items():
        path = ARCH / receipt
        recipe = c.read(path)
        if wanted:
            recipe = next(row for row in recipe if row["tag"] == wanted)
        source = ROOT / name
        if [c.key(x) for x in recipe["command"] if x.lower().endswith(".cc")] != [c.key(source)]:
            raise ValueError("Host recipe source mismatch: " + name)
        old = str(ARCH / old)
        if command.count(old) != 1:
            raise ValueError("Host owner must occur exactly once: " + old)
        # An absent legacy /I directory contributes no header candidates.
        # Remove only such stale include flags, keeping all real include order.
        includes = include_paths(recipe["command"])
        removed = [row["argument"] for row in includes if not row["exists"]]
        template = [arg for arg in recipe["command"] if arg not in removed]
        argv = c.compile_command(template, source, tag, output)
        if "/W4" not in argv or "/WX" not in argv or Path(argv[0]).name.lower() != "cl.exe":
            raise ValueError("Strict host compiler recipe required: " + name)
        frozen.add(source)
        frozen.update(product_dependencies(recipe["command"]))
        fresh = str(output / (tag + ".obj"))
        replacements[c.key(old)] = fresh
        compiles.append({"tag": tag, "source": c.snapshot(source, True),
            "recipe": c.snapshot(path, True), "command": argv,
            "old_object": c.snapshot(old, True), "object": fresh,
            "include_paths": includes, "removed_absent_include_flags": removed})
    linked = [replacements.get(c.key(arg), arg) if not arg.startswith("/") else arg for arg in command
              if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    linked += extras + ["/OUT:" + str(output / "candidate.exe"),
                       "/MAP:" + str(output / "candidate.map"),
                       "/IMPLIB:" + str(output / "candidate.lib")]
    closure = []
    for row in base["inputs"]:
        actual = c.snapshot(row["path"], True)
        actual["matches_base_hash"] = actual.get("sha256") == row["sha256"]
        actual["replaced"] = c.key(row["path"]) in replacements
        if not actual["exists"] or (not actual["replaced"] and not actual["matches_base_hash"]):
            raise ValueError("Missing or changed retained base input: " + row["path"])
        closure.append(actual)
    inputs = [arg for arg in linked if not arg.startswith("/") and Path(arg).is_absolute()
              and Path(arg).suffix.lower() in (".obj", ".lib")]
    if len(inputs) != 120 or any("tests--graph" in path for path in inputs):
        raise ValueError("Unexpected Qwen link closure size or test TU")
    env, runtime = c.environment(linked, inputs, output)
    sdk = c.sdk_libraries(linked, env)
    if any(row["resolved"] is None for row in sdk):
        raise ValueError("Named SDK link library is missing")
    plan = {"base_link_plan": c.snapshot(BASE, True), "base_inputs": closure,
        "cpu_plan": c.snapshot(cpu / "plan.json", True),
        "cpu_proof": c.snapshot(cpu / "tests-summary.json", True),
        "reused_cpu": reuse, "compile": compiles, "link": linked,
        "source_contract": [c.snapshot(path, True) for path in sorted(frozen, key=str)],
        "named_sdk_libraries": sdk, "runtime_path_directories": runtime,
        "absolute_link_input_count": len(inputs), "native_SDK_rebuild": False,
        "tensor_program_rebuild": False, "dependency_copy": False, "GPU_run": False}
    c.save(output / "plan.json", plan)
    print(json.dumps({"plan": str(output / "plan.json"), "host_TUs": len(compiles),
        "CPU_reused": len(reuse), "link_inputs": len(inputs),
        "frozen_source_files": len(frozen)}), flush=True)
    return output / "plan.json"


def build(path):
    path = Path(path).resolve()
    if not path.is_relative_to(STAGE / "cuda-checks"):
        raise ValueError("Plan must belong to this task's cuda-checks directory")
    output, plan = path.parent, c.read(path)
    if (output / "provider-compile.command.json").exists():
        raise ValueError("Preserve the actual build attempt; prepare a new plan to retry")
    for row in plan["source_contract"] + [item["object"] for item in plan["reused_cpu"]]:
        if c.snapshot(row["path"], True).get("sha256") != row["sha256"]:
            raise ValueError("Frozen source/CPU object drift: " + row["path"])
    for row in plan["base_inputs"]:
        if not row["replaced"] and c.snapshot(row["path"], True).get("sha256") != row["sha256"]:
            raise ValueError("Retained cached input drift: " + row["path"])
    inputs = [arg for arg in plan["link"] if not arg.startswith("/") and Path(arg).is_absolute()
              and Path(arg).suffix.lower() in (".obj", ".lib")]
    env, _ = c.environment(plan["link"], inputs, output)
    (output / "tmp").mkdir(exist_ok=True)
    for item in plan["compile"]:
        c.execute(item["tag"] + "-compile", item["command"], env, output)
        if c.snapshot(item["source"]["path"], True)["sha256"] != item["source"]["sha256"]:
            raise ValueError("Source changed during compile: " + item["source"]["path"])
        c.save(output / (item["tag"] + "-identity.json"),
               {"source": item["source"], "object": c.snapshot(item["object"], True),
                "command": item["command"]})
    for row in plan["source_contract"]:
        if c.snapshot(row["path"], True).get("sha256") != row["sha256"]:
            raise ValueError("Source contract changed while compiling: " + row["path"])
    c.save(output / "candidate-link-plan.json", {"command": plan["link"],
        "inputs": [identity(arg) for arg in inputs],
        "source_contract": c.snapshot(path, True), "native_SDK_rebuild": False,
        "tensor_program_rebuild": False, "object_copy": False})
    c.execute("candidate-link", plan["link"], env, output)
    c.save(output / "candidate-image.json", {"image": identity(output / "candidate.exe"),
        "link_plan": identity(output / "candidate-link-plan.json")})
    print("READY", str(output / "candidate-image.json"), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--dry-run", action="store_true", help="Prepare only (default)")
    group.add_argument("--build", action="store_true", help="Compile/link only; never run image")
    parser.add_argument("--plan", help="Build this existing prepared plan")
    parser.add_argument("--cpu-check", default=str(CPU), help="Final eight-case CPU receipt directory")
    args = parser.parse_args()
    if args.plan and not args.build:
        parser.error("--plan requires --build")
    path = Path(args.plan) if args.plan else prepare(args.cpu_check)
    if args.build:
        build(path)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, StopIteration) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
