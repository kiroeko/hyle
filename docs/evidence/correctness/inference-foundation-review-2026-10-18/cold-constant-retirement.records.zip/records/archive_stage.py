"""Archive this task's evidence and write the exact, nonrecursive reclaim script."""
from pathlib import Path
import hashlib
import json
import zipfile
import cold_check as c

stage, root = c.STAGE, c.ROOT
docs = root / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'
archive = docs / 'cold-constant-retirement.zip'
files = [
    'include/hyle/compute/storage_owner.h',
    'include/hyle/compute/detail/resource_budget_access.h',
    'include/hyle/compute/resource_budget.h', 'src/compute/resource_budget.cc',
    'include/hyle/graph/executable.h', 'include/hyle/graph/region_provider.h',
    'include/hyle/graph/cuda.h', 'src/graph/constant_artifact.h',
    'src/graph/constant_artifact.cc', 'src/graph/plan_state.h',
    'src/graph/storage_budget.h', 'src/graph/executable.cc',
    'src/graph_route_cuda/cuda_context.cc', 'src/graph_ggml_shared/constant_packing.h',
    'src/compute_provider_ggml_cuda/program.h',
    'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'tools/qwen35_text/main.cc', 'tests/graph/constant_artifact_cache_test.cc',
    'tests/graph/region_provider_test.cc', 'tests/graph_ggml_constant_test.h',
    'tests/graph_ggml_constant_cast_test.h',
    'tests/graph_provider_ggml_cuda/region_test.cc', 'tests/graph_route_cuda/ggml_test.cc']
c.save(stage / 'source-freeze.json', [c.snapshot(root / name, True) for name in files])
cpu = c.read(stage / 'checks/20261019T051232-8e1188d0/tests-summary.json')
retry = c.read(stage / 'checks/20261019T051551-0faed8bc/tests-summary.json')
native = c.read(stage / 'native-packing-summary.json')
qwen = c.read(stage / 'qwen-owned-correctness.json')
assert cpu['failures'] == retry['failures'] == native['failures'] == 0
assert len(cpu['cases']) == 8 and len(native['cases']) == 5
assert qwen['equal_vectors'] == 64
c.save(stage / 'summary.json', {
    'CPU': cpu, 'same_cache_retry': retry, 'CUDA': native,
    'Qwen': {'equal_vectors': 64, 'equal_token_ids': 32,
             'capture_counts_equal': qwen['capture_counts_equal']},
    'implementation': 'Original QueueSequence/Completion; actual typed storage and allocator owners; native packing episode retired before cache publication.',
    'scope': 'Packing migration plus ready constant ownership. Other cold-copy Status paths still require retirement migration.',
    'retention_cost': 'A pending packing episode currently retains the unpublished plan, including its ready canonical allocations/leases, until actual retirement.',
    'not_claimed': ['All model/operator coverage complete', 'all cold copies fixed',
                    'cross-platform runtime validation', 'new performance/memory/quality comparison'],
    'native_SDK_rebuild': False, 'native_kernel_rebuild': False,
    'tensor_program_rebuild': False})
targets = [c.snapshot(path, True) for path in sorted(stage.rglob('*'))
           if path.is_file() and path.suffix.lower() in ('.exe', '.map', '.lib', '.exp')]
manifest = stage / 'reclaim-targets.json'
c.save(manifest, targets)
script = r'''param([switch]$ReclaimColdConstantRetirement)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimColdConstantRetirement) { throw 'Use -ReclaimColdConstantRetirement for the reviewed exact targets.' }
$repoRoot = $PSScriptRoot
$taskRoot = [IO.Path]::GetFullPath((Join-Path $repoRoot '.scratch/architecture-refactor-2026-10-18/cold-constant-retirement'))
$receiptPath = Join-Path $taskRoot 'reclaim-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Reclaim already recorded; do not replay.' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'archive-verification.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $proof.path -Algorithm SHA256).Hash -ne $proof.sha256) { throw 'Evidence archive changed.' }
$targets = @(Get-Content -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task directory: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe', '.map', '.lib', '.exp')) { throw "Unexpected target: $resolved" }
  if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
$bytes = 0L
foreach ($entry in $targets) {
  Remove-Item -LiteralPath $entry.path
  $bytes += $entry.bytes
}
$receipt = [ordered]@{deleted_files=$targets.Count; reclaimed_bytes=$bytes; recursive=$false; archive=$proof; targets=$targets; objects_retained=$true; native_SDK_retained=$true; raw_vectors_retained=$true}
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "Reclaimed $bytes bytes from $($targets.Count) exact files; retained objects, SDKs and raw vectors."
'''
(root / 'test.ps1').write_text(script, encoding='utf-8-sig')
(stage / 'reclaim-script.ps1').write_text(script, encoding='utf-8-sig')
allowed = {'.json', '.log', '.py', '.ps1', '.h', '.cc', '.diff', '.xml', '.tsv', '.bf16', '.f32'}
payload = [path for path in sorted(stage.rglob('*')) if path.is_file()
           and path.suffix.lower() in allowed and 'tmp' not in path.relative_to(stage).parts
           and path.name != 'archive-verification.json']
records = {path.relative_to(stage).as_posix(): {'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in payload}
for name in files:
    data = (root / name).read_bytes()
    records['source-current/' + name] = {'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in payload: z.write(path, path.relative_to(stage).as_posix())
    for name in files: z.write(root / name, 'source-current/' + name)
    z.writestr('_manifest.json', json.dumps(records, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, row in records.items():
        data = z.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
proof = c.snapshot(archive, True)
proof.update(payload_files=len(records), CRC_and_SHA256_verified=True)
c.save(stage / 'archive-verification.json', proof)
print(json.dumps({'archive': proof, 'reclaim_files': len(targets),
                  'reclaim_bytes': sum(row['bytes'] for row in targets)}, indent=2))
