"""Prepare the bounded ragged-Graph evidence zip; use --write after validation.

The default invocation prints an inventory only. No build, test, cleanup,
dependency traversal or model/SDK copy is performed.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
from typing import NamedTuple
import zipfile


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
DESTINATION = ROOT / "docs/evidence/correctness/inference-foundation-review-2026-10-18/native-ragged-graph.zip"
STAGES = tuple(ARCH / name for name in (
    "native-ragged-graph", "native-ragged-graph-apple",
    "native-ragged-graph-vulkan", "native-ragged-graph-common",
    "cold-configuration-input", "host-address-identity",
))
TEXT_SUFFIXES = frozenset({
    ".cc", ".cpp", ".c", ".cxx", ".h", ".hpp", ".hh", ".hxx",
    ".mm", ".m", ".cu", ".cuh", ".inc", ".inl", ".cmake", ".txt",
    ".py", ".ps1", ".sh", ".bat", ".cmd", ".json", ".jsonl",
    ".log", ".diff", ".patch", ".md", ".csv", ".tsv", ".xml",
    ".d", ".deps", ".rsp", ".yaml", ".yml", ".text",
})
BINARY_SUFFIXES = frozenset({
    ".o", ".obj", ".exe", ".map", ".lib", ".exp", ".a", ".dll",
    ".pdb", ".so", ".dylib", ".spv", ".air", ".metallib", ".zip",
    ".tar", ".gz", ".tgz", ".part", ".safetensors", ".gguf", ".pt",
    ".pth", ".onnx", ".bin", ".bf16", ".f32", ".f16", ".npy", ".npz",
})
SKIP_DIRECTORIES = frozenset({".git", "__pycache__", "sdk", "sdks", "models", "weights"})
RECEIPTS = frozenset({"archive-receipt.json"})
RENAMED_SOURCES = {
    "src/graph_batch/native_paged_regions.h": "src/graph_batch/native_batch_regions.h",
    "src/graph_batch/native_paged_regions.cc": "src/graph_batch/native_batch_regions.cc",
}
SOURCE_PATHS = (
    "include/hyle/compute/detail/apple_batch_access.h",
    "include/hyle/compute/detail/vulkan_batch_access.h",
    "include/hyle/compute/detail/batch_graph_access.h",
    "include/hyle/graph/detail/region_access.h",
    "include/hyle/mem/resource.h",
    "src/compute_batch/batch_execution.cc",
    "src/compute/batch_transfer.cc",
    "src/mem/resource.cc",
    "src/compute_route_apple/apple_batch.cc",
    "src/compute_route_vulkan/vulkan_batch.cc",
    "src/compute_route_vulkan/vulkan_program.cc",
    "src/graph_route_apple/native_region.cc",
    "src/graph_route_apple/native_ragged_region.cc",
    "src/graph_route_apple/native_ragged_region.h",
    "src/graph_route_apple/native_paged_region.cc",
    "src/graph_route_apple/CMakeLists.txt",
    "src/graph_route_vulkan/native_region.cc",
    "src/graph_route_vulkan/native_ragged_region.cc",
    "src/graph_route_vulkan/native_ragged_region.h",
    "src/graph_route_vulkan/native_paged_region.cc",
    "src/graph_batch/batch.cc",
    "src/graph_batch/native_batch_regions.h",
    "src/graph_batch/native_batch_regions.cc",
    "src/graph_batch/CMakeLists.txt",
    "src/graph/resource_episode.h",
    "src/graph/executable.cc",
    "src/graph/input_sources.cc",
    "src/graph/resources.cc",
    "src/graph/region_access.cc",
    "tests/graph/configuration_input_test.cc",
    "tests/graph/CMakeLists.txt",
    "tests/graph_batch/native_ragged_attention_test.cc",
    "tests/graph_batch/typed_capability_graph_test.cc",
    "tests/graph_batch/CMakeLists.txt",
    "tests/compute_backend_cpu/copy_program_test.cc",
    "tests/graph_route_apple/CMakeLists.txt",
    "tests/graph_route_vulkan/CMakeLists.txt",
    "docs/architecture/graph-design.md",
    "docs/user/batch-attention.md",
    "docs/user/mem.md",
    "docs/developer/current-work.md",
    "docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md",
)
ADDED_PATHS = frozenset({
    "src/graph_route_apple/native_ragged_region.cc",
    "src/graph_route_apple/native_ragged_region.h",
    "src/graph_route_vulkan/native_ragged_region.cc",
    "src/graph_route_vulkan/native_ragged_region.h",
    "tests/graph/configuration_input_test.cc",
    "tests/graph_batch/native_ragged_attention_test.cc",
    "tests/graph_batch/typed_capability_graph_test.cc",
})
SUPPORT_PATHS = (
    "tests/compute_provider_native/half_test_support.h",
    "tests/compute_batch/native_ragged_layout_test.h",
)


class Entry(NamedTuple):
    archive_path: str
    data: bytes
    source_path: str | None
    kind: str


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def relative(path: Path) -> str:
    return path.resolve().relative_to(ROOT).as_posix()


def read_stable(path: Path) -> bytes:
    if path.is_symlink():
        raise ValueError(f"Do not archive a symlink: {path}")
    relative(path)  # Every input remains inside this repository.
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError(f"Input changed while reading; wait for final validation: {path}")
    return data


def source_file(path: Path) -> bool:
    return path.suffix.lower() in TEXT_SUFFIXES and path.suffix.lower() not in BINARY_SUFFIXES


def diff_bytes(old: bytes, new: bytes, old_path: str, new_path: str) -> bytes:
    # Keep the actual source payloads byte-exact in their own entries. Diffs
    # are normalized UTF-8 text and explicitly name before/final source paths.
    before = [line + "\n" for line in old.decode("utf-8-sig").splitlines()]
    after = [line + "\n" for line in new.decode("utf-8-sig").splitlines()]
    return "".join(difflib.unified_diff(before, after,
        fromfile=old_path, tofile=new_path)).encode("utf-8")


def collect() -> tuple[list[Entry], dict]:
    entries: dict[str, Entry] = {}
    excluded = []
    before_sources: list[tuple[Path, str, str]] = []
    sources = set(SOURCE_PATHS)

    def add(name: str, data: bytes, origin: str | None, kind: str) -> None:
        if name.startswith("/") or ".." in Path(name).parts or name in entries:
            raise ValueError(f"Unsafe or repeated archive entry: {name}")
        entries[name] = Entry(name, data, origin, kind)

    for stage in STAGES:
        if not stage.is_dir():
            raise FileNotFoundError(f"Missing task evidence stage: {stage}")
        for path in sorted(stage.rglob("*")):
            if not path.is_file():
                continue
            local = path.relative_to(stage)
            if (any(part.lower() in SKIP_DIRECTORIES for part in local.parts[:-1])
                    or path.name in RECEIPTS or not source_file(path)):
                excluded.append({"path": relative(path), "bytes": path.stat().st_size})
                continue
            data = read_stable(path)
            add(f"stages/{stage.name}/{local.as_posix()}", data, relative(path), "retained-stage")
            if "before" in local.parts[:-1]:
                before_at = local.parts.index("before")
                original = Path(*local.parts[before_at + 1:]).as_posix()
                current = RENAMED_SOURCES.get(original, original)
                if current.startswith(("src/", "include/", "tests/", "docs/")) and (ROOT/current).is_file():
                    sources.add(current)
                    before_sources.append((path, original, current))

    final_sources = {}
    for name in sorted(sources):
        path = ROOT/name
        if not path.is_file():
            raise FileNotFoundError(f"Missing final source: {name}")
        data = read_stable(path)
        final_sources[name] = data
        add(f"candidate/{name}", data, name, "authoritative-final-source")
    for name in SUPPORT_PATHS:
        add(f"support/{name}", read_stable(ROOT/name), name, "independent-numerical-support")
    add("workspace/test.ps1", read_stable(ROOT/"test.ps1"), "test.ps1", "root-cleanup-script-not-executed")

    before_covered = set()
    for path, old_name, new_name in before_sources:
        before_covered.add(new_name)
        # The nested location preserves distinct before snapshots from the
        # original platform and later test-registration slices.
        group = path.relative_to(ARCH).as_posix()
        diff = diff_bytes(read_stable(path), final_sources[new_name],
            f"before/{old_name}", f"candidate/{new_name}")
        add(f"diffs/{group}.diff", diff, None, "before-to-authoritative-final-diff")
    for name in sorted(ADDED_PATHS - before_covered):
        add(f"diffs/added/{name}.diff", diff_bytes(b"", final_sources[name],
            "/dev/null", f"candidate/{name}"), None, "added-source-diff")

    payloads = sorted(entries.values(), key=lambda item: item.archive_path)
    manifest = {
        "kind": "native-ragged-graph-source-and-validation-evidence",
        "repository": str(ROOT),
        "destination": relative(DESTINATION),
        "source_policy": "candidate/ reads the authoritative workspace at archive time; stage freezes and failed attempts remain verbatim provenance",
        "validation_policy": "Commands, results, logs, dependency text and source identities are retained verbatim; this script does not classify or rerun tests",
        "dependency_policy": "Only these six bounded task stages are traversed; referenced baseline objects, archives, models and SDK content are never followed",
        "cleanup_policy": "Includes current root test.ps1 and existing plans/receipts only; the script performs no cleanup and claims no later cleanup result",
        "numerical_support": {
            "graph_test": "candidate/tests/graph_batch/native_ragged_attention_test.cc",
            "shared_capability_test": "candidate/tests/graph_batch/typed_capability_graph_test.cc",
            "independent_half_codec": f"support/{SUPPORT_PATHS[0]}",
            "original_ragged_budget": f"support/{SUPPORT_PATHS[1]}",
        },
        "files": [{"path": row.archive_path, "source_path": row.source_path,
            "kind": row.kind, "bytes": len(row.data), "sha256": sha(row.data)} for row in payloads],
        "excluded": excluded,
    }
    return payloads, manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true", help="write and verify the final evidence zip; default is inventory only")
    args = parser.parse_args()
    entries, manifest = collect()
    summary = {"destination": str(DESTINATION), "files": len(entries),
        "payload_bytes": sum(len(row.data) for row in entries),
        "excluded_files": len(manifest["excluded"]),
        "excluded_bytes": sum(row["bytes"] for row in manifest["excluded"]),
        "writes_requested": args.write}
    if not args.write:
        print(json.dumps(summary, indent=2))
        return
    if DESTINATION.exists():
        raise FileExistsError(f"Evidence zip already exists; preserve it before choosing a new final archive: {DESTINATION}")
    temporary = OUT/f"native-ragged-graph.{os.getpid()}.zip.part"
    with zipfile.ZipFile(temporary, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for entry in entries:
            archive.writestr(entry.archive_path, entry.data)
        archive.writestr("manifest.json", json.dumps(manifest, indent=2).encode("utf-8") + b"\n")
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:
            raise ValueError("Archive CRC verification failed")
        for entry in entries:
            if sha(archive.read(entry.archive_path)) != sha(entry.data):
                raise ValueError(f"Archived payload hash mismatch: {entry.archive_path}")
    # Final sources must still describe this exact snapshot. Dependency paths
    # inside command/identity JSON are deliberately not opened or copied.
    for entry in entries:
        if entry.kind == "authoritative-final-source" and sha(read_stable(ROOT/entry.source_path)) != sha(entry.data):
            raise ValueError(f"Final source drifted before publication: {entry.source_path}")
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    temporary.replace(DESTINATION)
    receipt = {**summary, "archive_bytes": DESTINATION.stat().st_size,
        "archive_sha256": sha(DESTINATION.read_bytes()), "payloads_sha256_verified": True,
        "archive_crc_verified": True, "tests_executed_by_archiver": False,
        "cleanup_performed": False}
    (OUT/"archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
