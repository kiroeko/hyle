$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$records = @(
    @{old='src/graph_batch/native_paged_regions.h';new='src/graph_batch/native_batch_regions.h'},
    @{old='src/graph_batch/native_paged_regions.cc';new='src/graph_batch/native_batch_regions.cc'}
)
foreach ($record in $records) {
    $source = [IO.Path]::GetFullPath((Join-Path $workspace $record.old))
    $target = [IO.Path]::GetFullPath((Join-Path $workspace $record.new))
    if (-not $source.StartsWith($workspace + '\') -or -not $target.StartsWith($workspace + '\')) { throw 'Rename leaves workspace' }
    if (Test-Path -LiteralPath $target) { throw "Target exists: $target" }
    $item = Get-Item -LiteralPath $source
    $cursor = $item
    while ($null -ne $cursor -and $cursor.FullName.Length -ge $workspace.Length) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $source" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    $record.source=$source; $record.target=$target
}
foreach ($record in $records) { Move-Item -LiteralPath $record.source -Destination $record.target }
Write-Output 'Renamed only the two selected-layout implementation files.'
