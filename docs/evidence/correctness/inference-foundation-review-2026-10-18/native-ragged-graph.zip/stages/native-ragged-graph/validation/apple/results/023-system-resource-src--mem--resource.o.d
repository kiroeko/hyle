/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/023-system-resource-src--mem--resource.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/src/mem/resource.cc \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/mem/resource.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/core/compiler.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/core/detail/compiler_attributes.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/core/environment.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/core/assert.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/error/result.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/core/detail/preprocessor.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/error/status.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/mem/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/src/mem/system_internal.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/mem/allocator.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/mem/stats.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation/include/hyle/obs/trace.h
