from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[4]
BASE=ROOT/'.scratch/architecture-refactor-2026-10-18/paged-row-scorer/validation/apple'
spec=importlib.util.spec_from_file_location('original_air_transport',ROOT/'.scratch/architecture-refactor-2026-10-18/apple-row-projection/validation/run.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
REMOTE=prior.air.REMOTE+'/native-ragged-graph/validation';prior.OUT=OUT;prior.REMOTE=REMOTE
SOURCES=['src/compute_route_apple/apple_batch.cc','src/graph_route_apple/native_region.cc','src/graph_route_apple/native_paged_region.cc','src/graph_route_apple/native_ragged_region.cc','src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc','src/graph/executable.cc','src/graph/resources.cc','src/graph/region_access.cc','src/graph/input_sources.cc']
TEMPLATES={'src/graph_route_apple/native_ragged_region.cc':'src/graph_route_apple/native_region.cc','src/graph_batch/native_batch_regions.cc':'src/graph_batch/batch.cc','src/graph/input_sources.cc':'src/graph/resources.cc'}
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,v):prior.save(n,v)
def inventory():
 old=read(BASE/'results/026-current-link.result.json');owners=read(BASE/'baseline-objects.json');owners.update(read(BASE/'objects-current.json'));owners['src/graph/executable.cc']=next(x for x in old['argv']if x.endswith('/cross-runtime/executable.o'));owners['src/graph/input_sources.cc']=next(x for x in old['argv']if x.endswith('/cross-runtime/input_sources.o'))
 save('baseline-link.json',old);save('baseline-objects.json',owners)
 code=r"""
from pathlib import Path
import hashlib,json,shlex,subprocess,sys
p=json.loads(sys.stdin.buffer.read());root=Path(p['root']);root.mkdir(parents=True,exist_ok=True)
def ident(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
for row in p['inputs']:assert ident(row['path'])==row,(row,ident(row['path']))
hardware={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'system':['sw_vers'],'compiler':['clang++','--version']}.items()};assert hardware['model']=='Mac16,12'
history=json.loads((Path(p['base'])/'commands.json').read_text());dbpath=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/compile_commands.json');db=json.loads(dbpath.read_text());recipes={}
for source in p['sources']:
 template=p['templates'].get(source,source)
 rows=[x for x in history if x.get('exit')==0 and '-c'in x.get('command',[])and any(str(v).endswith('/'+template)for v in x['command'])]
 if rows:recipes[source]=dict(argv=rows[-1]['command'],template=template,record=str(Path(p['base'])/'commands.json'),tag=rows[-1]['tag'])
 else:
  rows=[x for x in db if x['file'].endswith('/'+template)];assert len(rows)==1,(source,template)
  argv=shlex.split(rows[0]['command']);argv[1:1]=['-DHYLE_STATIC','-Werror'];recipes[source]=dict(argv=argv,template=template,record=str(dbpath),entry=rows[0])
print(json.dumps(dict(hardware=hardware,inputs=p['inputs'],recipes=recipes)))
"""
 templates=TEMPLATES.copy();payload=dict(root=REMOTE,base=prior.air.REMOTE,inputs=old['inputs_before'],sources=SOURCES,templates=templates)
 r=prior.air.ssh(code,json.dumps(payload).encode(),timeout=45);(OUT/'000-inventory.stdout.json').write_bytes(r.stdout);(OUT/'000-inventory.stderr.log').write_bytes(r.stderr);assert r.returncode==0,r.stderr
 got=json.loads(r.stdout);recipes=got['recipes'];cached=read(BASE/'recipes.json')
 for s in SOURCES:
  if s in cached:recipes[s]=cached[s]
 save('recipes.json',recipes);save('baseline-identities.json',dict(hardware=got['hardware'],inputs=got['inputs'],unique_inputs=len(got['inputs'])));print(json.dumps(dict(hardware=got['hardware'],sources=len(recipes),inputs=len(got['inputs']))))
def compile_one(tag,source):
 recipes=read(OUT/'recipes.json');template=recipes[source]['argv'].copy()
 if '-MF'in template:
  i=template.index('-MF');del template[i:i+2]
 template=[x for x in template if x!='-MMD'];template[template.index('-c')+1]=REMOTE+'/'+source
 obj=REMOTE+'/'+tag+'-'+source.replace('/','--').replace('.cc','.o');template[template.index('-o')+1]=obj
 template[1:1]=['-I'+REMOTE+'/include','-I'+REMOTE,'-I'+REMOTE+'/src/graph','-I'+REMOTE+'/src/compute','-I'+REMOTE+'/src/graph_route_apple','-I'+REMOTE+'/src/compute_route_apple'];template+=['-MMD','-MF',obj+'.d']
 status=prior.call(tag,template,source=REMOTE+'/'+source,dependency=obj+'.d',outputs=[obj,obj+'.d'])
 if status==0:
  reg=read(OUT/'objects.json')if(OUT/'objects.json').exists()else{};reg[source]=obj;save('objects.json',reg)
 return status
if __name__=='__main__':
 action=sys.argv[1];status=0
 if action=='inventory':inventory()
 elif action=='sync':prior.sync('001-current-source',SOURCES+['src/graph/resource_episode.h','include/hyle/graph/detail/region_access.h'])
 elif action=='compile-products':
  for i,s in enumerate(SOURCES,2):
   status=compile_one('%03d-%s'%(i,Path(s).stem),s)
   if status:break
 elif action=='compile-one':status=compile_one(sys.argv[2],sys.argv[3])
 elif action=='sync-selected':prior.sync(sys.argv[2],sys.argv[3:])
 elif action=='link':
  old=read(OUT/'baseline-link.json');argv=old['argv'].copy();owners=read(OUT/'baseline-objects.json');objects=read(OUT/'objects.json');replacements=[]
  for source,obj in objects.items():
   key='src/graph_batch/native_paged_regions.cc' if source=='src/graph_batch/native_batch_regions.cc' else source
   previous=owners.get(key)
   if previous is not None and previous in argv:
    assert argv.count(previous)==1,(source,previous);argv[argv.index(previous)]=obj;replacements.append(dict(source=source,old=previous,new=obj))
   else:
    assert source in ['src/graph_route_apple/native_ragged_region.cc','tests/graph_batch/native_ragged_attention_test.cc','tests/graph/configuration_input_test.cc'] or source=='src/compute_batch/batch_execution.cc',(source,previous)
    argv.insert(1,obj);replacements.append(dict(source=source,old=None,new=obj))
  image=REMOTE+'/ragged-current-tests';argv[argv.index('-o')+1]=image;argv=[('-Wl,-map,'+image+'.map')if x.startswith('-Wl,-map,')else x for x in argv]
  save('matched-link-plan.json',dict(argv=argv,replacements=replacements,baseline=str(BASE/'026-current-link.planned.json')))
  math=read(BASE/'baseline-identities.json')['math'][0]['path'];code='from pathlib import Path;r=Path('+repr(REMOTE)+');p=r/"mlx.metallib";t=Path('+repr(math)+');assert t.is_file();assert not p.exists() or p.resolve()==t.resolve();p.symlink_to(t) if not p.exists() else None'
  r=prior.air.ssh(code,timeout=30);assert r.returncode==0,r.stderr
  status=prior.call('019-current-link',argv,map=image+'.map',outputs=[image,image+'.map'])
 elif action=='run':
  report=REMOTE+'/020-current-tests.json';pattern='NativeRaggedAttentionGraph.*:ConfigurationInput.*:NativePagedRowIndexer.*'
  status=prior.call('020-current-run',[REMOTE+'/ragged-current-tests','--gtest_filter='+pattern,'--gtest_output=json:'+report],outputs=[report])
 elif action=='collect':prior.collect()
 else:raise ValueError(action)
 raise SystemExit(status)
