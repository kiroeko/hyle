from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent/'windows';OUT.mkdir(exist_ok=True)
ROOT=Path(__file__).resolve().parents[4]
PRIOR=ROOT/'.scratch/architecture-refactor-2026-10-18/paged-row-scorer/validation'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);d=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
BASE=read(PRIOR/'windows-current/matched-link-plan.json')
RECIPES=read(PRIOR/'windows/recipes.json')
RECIPES['src/mem/resource.cc']={'argv':[x.strip('"') for x in re.findall(r'"[^"]*"|\S+',read(OUT/'memory-recipe.json')['recipe']['command'])]+['/DHYLE_STATIC']}
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':BASE['command'][0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in BASE['command'] if x.endswith('.lib')))+os.pathsep+env['PATH']
env.update(DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~',VSLANG='1033')
SOURCES=['src/graph/executable.cc','src/graph/resources.cc','src/graph/region_access.cc','src/graph/input_sources.cc',
 'src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc','src/compute_route_vulkan/vulkan_batch.cc',
 'src/compute_route_vulkan/vulkan_program.cc','src/graph_route_vulkan/native_region.cc',
 'src/graph_route_vulkan/native_paged_region.cc','src/graph_route_vulkan/native_ragged_region.cc','src/compute_batch/batch_execution.cc',
 'src/mem/resource.cc','src/compute/batch_transfer.cc']
def obj(s):return OUT/(s.replace('/','--').removesuffix('.cc')+'.obj')
def call(tag,argv,sources=(),outputs=()):
 assert not (OUT/(tag+'.result.json')).exists(),tag
 row=dict(argv=list(map(str,argv)),started=time.time(),sources_before=[ident(ROOT/s) for s in sources])
 save(OUT/(tag+'.command.json'),row)
 with (OUT/(tag+'.stdout.log')).open('wb')as so,(OUT/(tag+'.stderr.log')).open('wb')as se:
  p=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=p.pid;save(OUT/'live.json',row)
  try:row['exit']=p.wait(timeout=55)
  except subprocess.TimeoutExpired:p.kill();p.wait();row['exit']='timeout55'
 row.update(terminal=True,finished=time.time(),sources_after=[ident(ROOT/s) for s in sources],outputs=[ident(x) for x in outputs if Path(x).is_file()])
 save(OUT/(tag+'.result.json'),row);save(OUT/'live.json',row)
 print(tag,row['exit'],round(row['finished']-row['started'],2),flush=True)
 assert row['sources_before']==row['sources_after'],'source drift'
 if row['exit']!=0:
  for suffix in ['stdout','stderr']:print((OUT/(tag+'.'+suffix+'.log')).read_text(errors='replace')[-14000:])
  raise SystemExit(1)
def compile(s,tag=None):
 recipe=s
 if s=='src/graph_batch/native_batch_regions.cc':recipe='src/graph_batch/native_paged_regions.cc'
 if s=='src/graph_route_vulkan/native_ragged_region.cc':recipe='src/graph_route_vulkan/native_paged_region.cc'
 if s.startswith('tests/'):recipe='tests/graph_route_vulkan/row_cache_projection_test.cc'
 argv=[x for x in RECIPES[recipe]['argv'] if not x.lower().startswith(('/fo','/fd','/sourcedependencies')) and not x.lower().endswith(('.cc','.cpp'))]
 argv.insert(1,'/I'+str(PRIOR/'windows-current/shaders'))
 if s.endswith('native_ragged_attention_test.cc'):argv+=['/DHYLE_NATIVE_RAGGED_VULKAN=1']
 for f in ['/W4','/WX']:
  if f not in argv:argv.append(f)
 argv+=[str(ROOT/s),'/Fo'+str(obj(s)),'/sourceDependencies',str(obj(s).with_suffix('.deps.json'))]
 call(tag or 'compile-'+Path(s).stem,argv,[s],[obj(s),obj(s).with_suffix('.deps.json')])
def link(tag):
 selected=BASE['selected_sources'].copy();argv=BASE['command'].copy()
 for s in SOURCES:
  old=s.replace('native_batch_regions.cc','native_paged_regions.cc')
  if old in selected:
   previous=selected.pop(old);assert argv.count(previous)==1;argv[argv.index(previous)]=str(obj(s))
  else:argv.append(str(obj(s)))
  selected[s]=str(obj(s))
 for s in ['tests/graph/configuration_input_test.cc','tests/graph_batch/native_ragged_attention_test.cc','tests/graph_batch/typed_capability_graph_test.cc','tests/compute_backend_cpu/copy_program_test.cc']:
  argv.append(str(obj(s)));selected[s]=str(obj(s))
 argv=[x for x in argv if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 stem=OUT/'ragged-tests';argv+=['/OUT:'+str(stem.with_suffix('.exe')),'/MAP:'+str(stem.with_suffix('.map')),'/IMPLIB:'+str(stem.with_suffix('.lib'))]
 save(OUT/'matched-link-plan.json',dict(command=argv,selected_sources=selected,objects=[ident(x) for x in argv if x.endswith('.obj')]))
 call(tag,argv,outputs=[stem.with_suffix(x) for x in ['.exe','.map','.lib','.exp']])
if __name__=='__main__':
 action=sys.argv[1]
 if action=='hosts':
  for s in SOURCES:compile(s)
 elif action=='one':compile(sys.argv[2],sys.argv[3] if len(sys.argv)>3 else None)
 elif action=='tests':
  for s in ['tests/graph/configuration_input_test.cc','tests/graph_batch/native_ragged_attention_test.cc']:compile(s)
 elif action=='link':link(sys.argv[2] if len(sys.argv)>2 else 'link')
 elif action=='run':
  tag=sys.argv[2] if len(sys.argv)>2 else 'run';report=OUT/(tag+'-tests.json')
  pattern=sys.argv[3] if len(sys.argv)>3 else 'ConfigurationInput.*:NativeRaggedAttentionGraph.*:TypedCapabilityGraph.*:CpuCopyProgram.HostAddressCapabilityRejectsUnprovenMappingsAndDetectsWrapperAliases:NativePagedRowIndexer.*:VulkanProjectedRowGraph.*'
  call(tag,[OUT/'ragged-tests.exe','--gtest_filter='+pattern,'--gtest_color=no','--gtest_output=json:'+str(report)],outputs=[report])
  print(json.dumps(read(report)),flush=True)
 else:raise ValueError(action)
