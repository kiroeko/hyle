from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("ragged_air_current",OUT/"run.py")
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
SOURCES=["src/mem/resource.cc","src/compute/batch_transfer.cc"]
def read(name):return json.loads((OUT/name).read_text(encoding="utf-8-sig"))
def save(name,value):m.save(name,value)
if __name__=="__main__":
 action=sys.argv[1];status=0
 if action=="sync":m.prior.sync("022-host-address-source",SOURCES+["include/hyle/mem/resource.h"])
 elif action=="compile":
  for tag,source in zip(["023-system-resource","024-batch-transfer"],SOURCES):
   status=m.compile_one(tag,source)
   if status:break
 elif action=="link":
  plan=read("matched-link-plan.json");argv=plan["argv"].copy();objects=read("objects.json")
  old=read("baseline-objects.json")["src/compute/batch_transfer.cc"]
  assert argv.count(old)==1,(old,argv.count(old))
  argv[argv.index(old)]=objects["src/compute/batch_transfer.cc"]
  argv.insert(1,objects["src/mem/resource.cc"])
  image=m.REMOTE+"/ragged-host-address-tests"
  argv[argv.index("-o")+1]=image
  argv=[("-Wl,-map,"+image+".map")if x.startswith("-Wl,-map,")else x for x in argv]
  save("host-address-link-plan.json",dict(argv=argv,replaces=[dict(source=SOURCES[1],old=old,new=objects[SOURCES[1]])],explicit_archive_override=dict(source=SOURCES[0],object=objects[SOURCES[0]],old_archive_member="libhyle_mem.a(resource.cc.o)")))
  status=m.prior.call("025-host-address-link",argv,map=image+".map",outputs=[image,image+".map"])
 elif action=="run":
  report=m.REMOTE+"/026-host-address-tests.json"
  status=m.prior.call("026-host-address-run",[m.REMOTE+"/ragged-host-address-tests","--gtest_filter=NativeRaggedAttentionGraph.*:ConfigurationInput.*:NativePagedRowIndexer.*","--gtest_output=json:"+report],outputs=[report])
 elif action=="collect":m.prior.collect()
 else:raise ValueError(action)
 raise SystemExit(status)
