#pragma once

#include "hyle/graph/batch.h"
#include "hyle/graph/detail/region_access.h"
#include "hyle/graph/region_provider.h"
#include "native_pending_regions.h"
#include "hyle/mem/std_allocator.h"

#include <utility>
#include <vector>

namespace hyle::graph::batch::detail {
// Cold capability of one exact selected prepared implementation. These ports
// describe Q/K/V (or Q/compact-cache), excluding its owned hidden metadata.
// The physical input indices are the original region boundary port indices.
inline constexpr compute::ProviderExtensionId kNativePagedRegionExtensionId{
    0x48594c454e415450ULL, 0x414745445245474eULL, 3};
struct NativePagedRegionFacts final {
  NodeId node;
  const compute::NativePagedBatchProgram *program = nullptr;
  std::span<const ValueId> inputs;
  std::span<const std::uint32_t> input_ports;
  compute::BatchLayoutVersion layout;
};
struct NativePagedRegionVTable final {
  Result<NativePagedRegionFacts> (*inspect)(void *prepared,
                                           void *invocation) noexcept = nullptr;
  Status (*prepare)(void *prepared, void *invocation,
                    compute::BatchLayoutVersion) noexcept = nullptr;
  Status (*validate_frame)(void *prepared, void *invocation, ValueId,
                           const compute::PagedArenaRead &) noexcept = nullptr;
  // Only called after every real reader and the original Graph binding have
  // accepted the exact frame. It cannot fail or manufacture ready permission.
  void (*commit_frame)(void *prepared, void *invocation, ValueId,
                        compute::PagedArenaRead) noexcept = nullptr;
  Status (*reset)(void *prepared, void *invocation) noexcept = nullptr;
  compute::NativePagedBatchReport (*report)(void *prepared,
                                           void *invocation) noexcept = nullptr;

};
// Borrowed original slot references, retained only by its existing resource
// payload for cold reset. Destruction never dereferences these pointers.
struct NativePagedRegionRef final {
  const NativePagedRegionVTable *table = nullptr;
  const ProviderRegionPreparedVTable *implementation = nullptr;
  void *prepared = nullptr;
  void *invocation = nullptr;
  std::uint32_t step = 0;
  ExecutionLaneId lane;
  NodeId node;
  const compute::NativePagedBatchProgram *program = nullptr;
  std::span<const ValueId> inputs;
  std::span<const std::uint32_t> input_ports;
};
using NativePagedRegions = std::vector<NativePagedRegionRef,
    mem::StdAllocator<NativePagedRegionRef>>;
using NodeLayouts = std::vector<NodeLayout, mem::StdAllocator<NodeLayout>>;
using ProjectedReaders = std::vector<graph::detail::ProjectedReader,
    mem::StdAllocator<graph::detail::ProjectedReader>>;
Status collect_native_paged_regions(Invocation &, NativePagedRegions &) noexcept;
Status split_native_paged_layouts(std::span<const NativePagedRegionRef>,
    std::span<const NodeLayout>, NodeLayouts &shared) noexcept;
Status prepare_native_paged_regions(std::span<const NativePagedRegionRef>,
    std::span<const NodeLayout>) noexcept;
Status reset_native_paged_regions(std::span<const NativePagedRegionRef>) noexcept;
Result<std::uint64_t> native_paged_read_capacity(
    std::span<const NativePagedRegionRef>) noexcept;
Status native_paged_frame(std::span<const NativePagedRegionRef>, ValueId,
    const compute::PagedArenaRead &, ProjectedReaders &) noexcept;
void commit_native_paged_frame(std::span<const NativePagedRegionRef>, ValueId,
    compute::PagedArenaRead) noexcept;
Result<compute::NativePagedBatchReport> native_paged_report(
    Invocation &, NodeId) noexcept;
} // namespace hyle::graph::batch::detail
