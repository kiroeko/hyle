from pathlib import Path
root=Path.cwd()
def edit(rel, replacements):
 p=root/rel;raw=p.read_bytes();crlf=b'\r\n' in raw;text=raw.decode().replace('\r\n','\n')
 for before,after in replacements:
  assert text.count(before)==1,(rel,before[:100],text.count(before))
  text=text.replace(before,after)
 p.write_bytes(text.replace('\n','\r\n').encode() if crlf else text.encode())
edit('src/graph/resource_episode.h',[(
'HYLE_GRAPH_API void reset_resource_bindings(InvocationState &) noexcept;\n',
'HYLE_GRAPH_API void reset_resource_bindings(InvocationState &) noexcept;\n// Ordinary replacement must not detach immutable metadata from the selected\n// cold configuration. This check precedes all binding/cache/source mutation.\nHYLE_GRAPH_API Status check_binding_replacement(\n    const InvocationState &, ValueId) noexcept;\n')])
edit('include/hyle/graph/detail/region_access.h',[(
'  // Trusted adapters supply the exact footprint and qualify every reader.\n',
'  // Owns immutable input metadata of the selected cold configuration. Only\n  // this idle/result-gated path may replace it until the original reset.\n  // Rejection preserves the previous binding and prepared replay.\n  HYLE_GRAPH_API static Status bind_configuration(Invocation &, ValueId,\n      compute::TensorDesc, compute::ReadLease) noexcept;\n  // Trusted adapters supply the exact footprint and qualify every reader.\n')])
edit('src/graph/resources.cc',[(
'  bool borrowed = true;\n};\n',
'  bool borrowed = true;\n  bool configuration = false;\n};\n'),(
'void reset_resource_bindings(InvocationState &state) noexcept {\n',
'Status check_binding_replacement(const InvocationState &state, ValueId value) noexcept {\n  if (state.resources) {\n    for (const auto &binding : state.resources.get()->bindings)\n      if (binding.value == value && binding.configuration)\n        return Status::FailedPrecondition(\n            "graph input belongs to its cold configuration; reset before ordinary rebinding");\n  }\n  return Status::Ok();\n}\nvoid reset_resource_bindings(InvocationState &state) noexcept {\n'),(
'    binding.exclusive = false; binding.permissionless = false; binding.borrowed = true;\n',
'    binding.exclusive = false; binding.permissionless = false; binding.borrowed = true;\n    binding.configuration = false;\n'),(
'    binding->exclusive = false; binding->permissionless = false; binding->borrowed = true;\n',
'    binding->exclusive = false; binding->permissionless = false; binding->borrowed = true;\n    binding->configuration = false;\n'),(
'Status RegionAccess::reserve_reads(Invocation &invocation, std::uint32_t extra,\n',
'Status RegionAccess::bind_configuration(Invocation &invocation, ValueId value,\n    compute::TensorDesc description, compute::ReadLease lease) noexcept {\n  auto *state = InvocationAccess::state(invocation);\n  HYLE_ASSIGN_OR_RETURN(auto *episode, require_resources(state));\n  (void)episode;\n  auto *binding = find_binding(state, value);\n  if (!binding || !binding->input)\n    return Status::InvalidArgument("cold configuration must bind a graph input");\n  HYLE_ASSIGN_OR_RETURN(auto tensor, lease.tensor(description));\n  // Reuse the original binding validation/commit. Only this synchronized cold\n  // call suspends the replacement guard; a rejecting bind has not invalidated\n  // replay or released the old resource owner.\n  const bool previous = std::exchange(binding->configuration, false);\n  const auto status = invocation.bind(value, tensor);\n  binding = find_binding(state, value);\n  if (!status.ok()) {\n    binding->configuration = previous;\n    return status;\n  }\n  binding->read = std::move(lease); binding->description = description;\n  binding->exclusive = false; binding->permissionless = false; binding->borrowed = false;\n  binding->configuration = true;\n  return Status::Ok();\n}\n\nStatus RegionAccess::reserve_reads(Invocation &invocation, std::uint32_t extra,\n'),(
'  auto *binding = detail::find_binding(state_, value);\n  if (!binding || !binding->input) return Status::InvalidArgument("read lease must bind a graph input");\n',
'  HYLE_RETURN_IF_ERROR(detail::check_binding_replacement(*state_, value));\n  auto *binding = detail::find_binding(state_, value);\n  if (!binding || !binding->input) return Status::InvalidArgument("read lease must bind a graph input");\n'),(
'  HYLE_RETURN_IF_ERROR(bind(value, tensor));\n  binding->read = std::move(lease); binding->description = description;\n',
'  HYLE_RETURN_IF_ERROR(bind(value, tensor));\n  binding = detail::find_binding(state_, value);\n  binding->read = std::move(lease); binding->description = description;\n'),(
'  auto *binding = detail::find_binding(state_, value);\n  if (!binding) return Status::InvalidArgument("write lease must bind an external graph value");\n',
'  HYLE_RETURN_IF_ERROR(detail::check_binding_replacement(*state_, value));\n  auto *binding = detail::find_binding(state_, value);\n  if (!binding) return Status::InvalidArgument("write lease must bind an external graph value");\n'),(
'  HYLE_RETURN_IF_ERROR(bind(value, tensor));\n  binding->write = std::move(lease); binding->description = description;\n',
'  HYLE_RETURN_IF_ERROR(bind(value, tensor));\n  binding = detail::find_binding(state_, value);\n  binding->write = std::move(lease); binding->description = description;\n')])
edit('src/graph/executable.cc',[(
'  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state_));\n  if (!tensor.valid())\n    return Status::InvalidArgument("tensor binding is invalid");\n  const detail::PlanState &plan = *state_->plan;\n',
'  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state_));\n  HYLE_RETURN_IF_ERROR(detail::check_binding_replacement(*state_, value));\n  if (!tensor.valid())\n    return Status::InvalidArgument("tensor binding is invalid");\n  const detail::PlanState &plan = *state_->plan;\n')])
