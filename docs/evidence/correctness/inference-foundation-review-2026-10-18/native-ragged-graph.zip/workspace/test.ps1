param([switch]$Archive, [switch]$ReclaimNativeRaggedGraph)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/native-ragged-graph'
if ($Archive) {
    & python (Join-Path $stage 'archive.py') '--write'
    if ($LASTEXITCODE -ne 0) { throw 'Archive failed; no cleanup allowed' }
    return
}
$receipt = Get-Content -Raw -LiteralPath (Join-Path $stage 'archive-receipt.json') | ConvertFrom-Json
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
function Assert-Identity($entry, [string]$within = $workspace) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($within.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside exact stage: $path" }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $cursor = $item
    while ($null -ne $cursor -and $cursor.FullName.Length -ge $workspace.Length) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Identity changed: $path" }
}
Assert-Identity ([pscustomobject]@{path=$receipt.destination;bytes=$receipt.archive_bytes;sha256=$receipt.archive_sha256})
Assert-Identity $plan.summary
Assert-Identity $plan.windows_manifest
Assert-Identity $plan.apple_manifest
$windows = Get-Content -Raw -LiteralPath $plan.windows_manifest.path | ConvertFrom-Json
$apple = Get-Content -Raw -LiteralPath $plan.apple_manifest.path | ConvertFrom-Json
if ([IO.Path]::GetFullPath([string]$windows.root) -ne [IO.Path]::GetFullPath((Join-Path $stage 'validation/windows'))) { throw 'Unexpected Windows cleanup root' }
foreach ($entry in $windows.files) {
    if ([IO.Path]::GetExtension([string]$entry.path) -notin @('.exe', '.map', '.lib', '.exp', '.pdb')) { throw 'Only redundant linked images and maps may be reclaimed' }
    Assert-Identity $entry $windows.root
}
foreach ($entry in $windows.retain) { Assert-Identity $entry }
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($apple | ConvertTo-Json -Depth 16 -Compress)))
$program = @'
import base64,hashlib,json,sys
from pathlib import Path
m=json.loads(base64.b64decode(sys.argv[1]))
root=Path(m['root']); expected=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation')
assert root==expected and root.resolve()==root and root.is_dir()
assert m['files'] and not {r['path'] for r in m['files']} & {r['path'] for r in m['retain']}
def verify(row,child=False):
 p=Path(row['path']); assert p.is_absolute() and p.is_file() and p.resolve()==p and not p.is_symlink(),str(p)
 if child: assert p.parent==root and (p.name in {'ragged-current-tests','ragged-host-address-tests'} or p.suffix=='.map'),str(p)
 data=p.read_bytes(); assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],str(p)
for r in m['files']:verify(r,True)
for r in m['retain']:verify(r)
if sys.argv[2]=='reclaim':
 for r in m['files']:Path(r['path']).unlink()
for r in m['retain']:verify(r)
print(json.dumps(dict(verified=True,deleted=sys.argv[2]=='reclaim',files=len(m['files']),bytes=sum(r['bytes'] for r in m['files']),retained=len(m['retain']))))
'@
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($program))
$mode = if ($ReclaimNativeRaggedGraph) { 'reclaim' } else { 'verify' }
$command = "python3 -c 'import base64;exec(base64.b64decode(" + '"' + $encoded + '"' + "))' " + $payload + ' ' + $mode
$remoteOutput = & ssh -o BatchMode=yes -o ConnectTimeout=15 'kiro@172.22.10.198' $command
if ($LASTEXITCODE -ne 0) { throw 'Remote exact cleanup verification/execution failed' }
$remote = $remoteOutput | ConvertFrom-Json
if (-not $ReclaimNativeRaggedGraph) { Write-Output "Verified $($windows.files.Count) Windows and $($remote.files) Air linked images/maps. Use -ReclaimNativeRaggedGraph to reclaim."; return }
foreach ($entry in $windows.files) { Assert-Identity $entry $windows.root; Remove-Item -LiteralPath $entry.path }
foreach ($entry in $windows.retain) { Assert-Identity $entry }
$bytes = ($windows.files | Measure-Object -Property bytes -Sum).Sum
$result = [ordered]@{archive_verified=$true;summary_verified=$true;windows=@{files=$windows.files.Count;bytes=$bytes;retained=$windows.retain.Count};apple=$remote;other_cache_retained=$true}
$result | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $stage 'cleanup-result.json')
$result | ConvertTo-Json -Depth 8
