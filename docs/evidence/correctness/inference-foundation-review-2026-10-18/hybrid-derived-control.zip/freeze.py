from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DOC = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def digest(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


cases = [
    ('cuda-ragged-mla', 'cuda-ragged-mla.zip', 277932,
     '03ae035521dfa30c151eb815d1ee5788a9b2ac8ebe2b073687deb68981eba59d'),
    ('apple-recurrent-metadata', 'apple-recurrent-metadata.zip', 64608,
     '3326ec89b28e40ee5c7f34572ee62bf930ea0c3bd4f5f0332fed329d6b9c27ef'),
]
for stage, name, size, sha in cases:
    parent = OUT.parent / stage
    source = parent / 'source-results.zip'
    assert source.stat().st_size == size and digest(source) == sha, source
    if stage == 'cuda-ragged-mla':
        identities = json.loads((parent / 'source-identities.json').read_text())
        for item in identities:
            # Shared CMake files can subsequently receive other independent
            # route additions; all math/wrapper/test sources must still match.
            if item['path'].startswith(('src/', 'tests/', 'third_party/')):
                assert digest(ROOT / item['path']) == item['after_sha256'], item['path']
    else:
        for item in json.loads((parent / 'source-sha.json').read_text()):
            assert digest(ROOT / item['path']) == item['sha256'], item['path']
    target = DOC / name
    if target.exists():
        assert digest(target) == sha, target
    else:
        shutil.copyfile(source, target)

source = ROOT / 'tests/graph/cpu_cuda_contracts.cc'
before = OUT / 'before/tests/graph/cpu_cuda_contracts.cc'
applied = OUT / 'applied/tests/graph/cpu_cuda_contracts.cc'
applied.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(source, applied)
(OUT / 'source.diff').write_text(''.join(difflib.unified_diff(
    before.read_text(encoding='utf-8').splitlines(True),
    source.read_text(encoding='utf-8').splitlines(True),
    fromfile='before/tests/graph/cpu_cuda_contracts.cc',
    tofile='applied/tests/graph/cpu_cuda_contracts.cc')), encoding='utf-8')
commands = json.loads((OUT / 'commands.json').read_text())
last = next(x for x in reversed(commands) if x['tag'] == 'mixed-contracts')
assert last['exit'] == 0
summary = {
    'status': 'Actual CPU+CUDA canonical contracts PASS; added consumer coverage, no new product repair',
    'test': 'CPU TopK -> control -> CUDA immutable BF16 Cast in original ggml region -> D2H -> CPU TopK; independent changing CUDA Neg shares that region.',
    'proof': ['Exactly one prepared constant artifact',
              'Actual report has separate CPU predecessor/successor segments and transitive predecessor-to-region-to-consumer dependency edges',
              'Two original bridge Invocation slots, two payload phases on each, prepare_replay/run, exact all output values',
              'Retained result rejects bind; existing weight dependency/reset/alias/quota/OOM/cancel/accepted-prefix/drain contracts also pass'],
    'build': 'Fresh current src/graph_route_cpu_cuda/invocation.cc and consumer TU only; all six private PlanState consumers use current matching layout. Existing single mixed ggml pin and CUDA/native caches reused.',
    'comparison': 'Pre-control-fix generic executable object also passes this cross-storage journey. This extra test does not isolate the original missing prepared-output edge; the existing ordinary CPU/CUDA regression remains its reproducer. No new defect/count inferred.',
    'failures': ['First link missed the already-built CUDA index-guard object required by the current provider; added that exact cache object without source workaround.',
                 'Scratch comparison initially asserted the pre-fix core must fail; actual pass disproved that test-harness expectation. Preserved command/log, removed the unsupported assertion.'],
    'limits': 'Targeted mixed journey, not all 22 profiles/full models or all dynamic lengths. No throughput/peak-memory/no-allocation claim for the new journey.',
    'source_sha256': digest(source),
}
write('summary.json', summary)
write('current-plan-state-objects.json', [
    {'path': x, 'bytes': Path(x).stat().st_size, 'sha256': digest(Path(x))}
    for x in next(x['command'] for x in reversed(commands) if x['tag'] == 'contracts-link')
    if x.endswith('.obj') and ('/derived-constant-implementation/' in x.replace('\\', '/') or
                              x.endswith(('joint.obj', 'leased.obj')))
])
archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p.suffix in ('.py', '.cc', '.json', '.log', '.diff'):
            z.write(p, p.relative_to(OUT).as_posix())
target = DOC / 'hybrid-derived-control.zip'
shutil.copyfile(archive, target)
print(json.dumps({'archive': str(target), 'bytes': archive.stat().st_size,
                  'sha256': digest(archive), 'integrated': [x[1] for x in cases]}, indent=2))
