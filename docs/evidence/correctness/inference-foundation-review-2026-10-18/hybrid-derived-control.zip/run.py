from pathlib import Path
import importlib.util
import json
import os
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PREVIOUS = ROOT / '.scratch/inference-foundation-review-2026-10-18/hybrid-weight-dependencies'
spec = importlib.util.spec_from_file_location('mixed_build', PREVIOUS / 'run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
b.records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def link(before=False):
    old = next(x['command'] for x in reversed(json.loads((PREVIOUS / 'commands.json').read_text()))
               if x['tag'] == 'contracts-link' and x['exit'] == 0)
    # Explicit objects override the matching archive members. All six users of
    # private PlanState are current: five generic TUs plus the fresh joint TU.
    omit = {
        *(str(PREVIOUS / n) for n in ('joint-after.obj', 'contracts.obj')),
        str(ROOT / '.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj'),
        str(ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj'),
        *(str(ROOT / '.scratch/mtp-completion' / n) for n in ('provider.obj', 'tensor.obj', 'region.obj')),
    }
    args = [x for x in old[1:] if x not in omit and not x.startswith(('/OUT:', '/MAP:'))]
    derived = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/derived-constant-implementation'
    current = [
        OUT / 'joint.obj', OUT / 'contracts.obj',
        *(derived / ('graph-' + n + '.obj') for n in
          ('executable', 'constant_artifact', 'lease_submission', 'region_access')),
        ROOT / '.scratch/inference-foundation-review-2026-10-18/row-cache-pending-graph/leased.obj',
        *(derived / n for n in ('cpu-provider.obj', 'cpu-region.obj', 'cuda-provider.obj', 'cuda-region.obj')),
        ROOT / '.scratch/inference-foundation-review-2026-10-18/cpu-sink-denominator-debug/native-after.obj',
        ROOT / '.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cuda-tensor.obj',
        ROOT / '.scratch/inference-fusion-quantization-2026-10-18/cuda-precise-unary/unary-precise.obj',
        ROOT / '.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices/guard.obj',
    ]
    if before:
        current[2] = derived / 'control-fix/graph-executable.before.obj'
    for p in current:
        assert p.is_file(), p
    name = 'before-scheduling' if before else 'contracts'
    b.run(name + '-link', [b.LINK, *current, *args, '/OUT:' + str(OUT / (name + '.exe')),
                          '/MAP:' + str(OUT / (name + '.map'))])


if __name__ == '__main__':
    for action in sys.argv[1:]:
        if action == 'build':
            b.comp(ROOT / 'src/graph_route_cpu_cuda/invocation.cc', 'joint')
            b.comp(ROOT / 'tests/graph/cpu_cuda_contracts.cc', 'contracts')
        elif action == 'consumer':
            b.comp(ROOT / 'tests/graph/cpu_cuda_contracts.cc', 'contracts')
        elif action == 'link':
            link()
        elif action == 'before-link':
            link(True)
        elif action == 'before':
            # This cross-storage journey also passed with the pre-fix core.
            # It is extra coverage, not an isolated regression reproducer.
            print(b.run('before-scheduling-contracts', [OUT / 'before-scheduling.exe'], 180))
        elif action == 'test':
            print(b.run('mixed-contracts', [OUT / 'contracts.exe'], 180))
        else:
            raise ValueError(action)
