#include <gtest/gtest.h>
#include <array>
#include <vector>
#include "tests/compute_route_apple/tensor_test_support.h"
#include "tests/compute_models/batched_sink_fixture.h"
#include "hyle/graph/apple.h"
#include "hyle/compute/detail/apple_plan.h"
using namespace apple_tensor_test;
namespace g=hyle::graph;namespace ga=g::apple;
namespace {
TEST(AppleSinkGraph, DiagnosticBatchedTailPreservesMaskQueryAxis) {
  namespace bs = batched_sink_test;
  for (const int heads : {64})
    for (const bool batched_mask : {true})
      for (const int queries : {129}) {
        SCOPED_TRACE(::testing::Message() << "H=" << heads
            << " mask3=" << batched_mask << " Q=" << queries);
        bs::Fixture fixture(heads, batched_mask, queries, 2, 17);
        ASSERT_TRUE(c::apple::detail::is_mlx_attention_blocks(fixture.operation, fixture.descriptions));
        auto builder = g::GraphBuilder::create().value();
        std::array<g::ValueId, 5> ports;
        for (std::size_t i = 0; i < ports.size(); ++i)
          ports[i] = builder.input(fixture.descriptions[i]).value();
        const auto sink = builder.add(fixture.operation,
            ports[0], ports[1], ports[2], ports[3], ports[4]).value();
        const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, sink).value();
        ASSERT_TRUE(builder.publish(sink).ok());
        ASSERT_TRUE(builder.publish(negative).ok());
        auto graph = std::move(builder).finish().value();
        auto context = a::Context::create().value();
        auto program = ga::compile(context, graph, {});
        ASSERT_TRUE(program) << program.error().message();
        auto invocation = program->create_invocation().value();
        std::vector<mx::array> retained;
        std::vector<std::vector<std::uint64_t>> retained_bits;
        for (int phase = 0; phase < 2; ++phase) {
          fixture.update(phase);
          std::vector<mx::array> inputs;
          for (std::size_t i = 0; i < ports.size(); ++i) {
            const auto spec = a::input_spec(fixture.descriptions[i]).value();
            inputs.push_back(ready(mx::array(fixture.payloads[i].data(),
                spec.shape, mx::float32)));
          }
          ASSERT_TRUE(invocation.bind(inputs).ok());
          auto accepted = invocation.submit();
          ASSERT_TRUE(accepted) << accepted.error().message();
          auto finished = accepted->wait();
          ASSERT_TRUE(finished) << finished.error().message();
          const auto outputs = finished->get()->arrays();
          ASSERT_EQ(outputs.size(), 2U);
          auto expected = fixture.expected();
          for (std::size_t i = 0; i < outputs.size(); ++i) {
            EXPECT_EQ(outputs[i].shape(), inputs[0].shape());
            auto contiguous = ready(mx::contiguous(outputs[i], false, stream()));
            bs::check(std::span(contiguous.data<float>(), contiguous.size()), expected);
            ASSERT_FALSE(::testing::Test::HasFailure());
            if (phase == 0) {
              retained.push_back(outputs[i]);
              retained_bits.push_back(bits(outputs[i]));
            }
            for (auto &value : expected) value = -value;
          }
        }
        invocation = {};
        *program = {};
        ASSERT_TRUE(context.close().ok());
        for (std::size_t i = 0; i < retained.size(); ++i)
          EXPECT_EQ(bits(retained[i]), retained_bits[i]);
      }
}
} // namespace
