from pathlib import Path
import importlib.util,json,subprocess,time,re,sys,hashlib
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'inference-fusion-quantization-20261018-apple-indexed-fp4'
spec=importlib.util.spec_from_file_location('prior',OLD/'run_remote.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior);cache=prior.cache;SDK=cache.SDK
FLAGS=cache.FLAGS+['-D'+m+'='for m in sorted(set().union(*(set(re.findall(r'\bHYLE_[A-Z0-9_]+_API\b',p.read_text()))for p in (ROOT/'include').rglob('*.h'))))if '-D'+m+'='not in cache.FLAGS]
INC=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(ROOT/'src/compute'),*cache.INC]
records=json.loads((ROOT/'commands.json').read_text())if(ROOT/'commands.json').exists()else[]
def run(tag,command):
 command=list(map(str,command));stem=tag+'-'+str(1+sum(x['tag']==tag for x in records));start=time.monotonic();p=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=180)
 (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=command,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start));(ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-8000:]);raise SystemExit(p.returncode)
 return p.stdout
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
retained=[p for p in cache.retained if p.name not in ['tensor.o','apple_context.o','apple_operations.o']]+[OLD/'mature.o']
LIBS=cache.LIBS+[cache.CORE/'lib/libgtest_main.a']
def build():
 assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
 (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
 if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
 for file,name in [('src/compute_route_apple/apple_tensor.cc','tensor'),('src/compute_route_apple/apple_context.cc','context'),('src/compute_route_apple/apple_operations.cc','operations'),('tests/graph_route_apple/tensor_test.cc','graph-test'),('apple_operations.force-small-blocks.cc','forced-operations'),('forced-test.cc','forced-test')]:
  if not(ROOT/(name+'.o')).exists()or(ROOT/file).stat().st_mtime>(ROOT/(name+'.o')).stat().st_mtime:run(name+'-compile',['clang++',*FLAGS,*INC,'-c',ROOT/file,'-o',ROOT/(name+'.o')])
 for name,ops,test in [('batched-sink','operations','graph-test'),('forced-small-blocks','forced-operations','forced-test')]:
  run(name+'-link',['clang++','-O3','-std=c++23','-arch','arm64','-o',ROOT/name,*[ROOT/(x+'.o')for x in ['tensor','context',ops,test]],*retained,*LIBS,'-Wl,-rpath,'+str(cache.TORCH),'-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore','-Wl,-map,'+str(ROOT/(name+'.map'))])
 (ROOT/'identities.json').write_text(json.dumps([identity(p)for p in [*[ROOT/(x+'.o')for x in ['tensor','context','operations','graph-test','forced-operations','forced-test']],*retained,ROOT/'batched-sink',ROOT/'forced-small-blocks']],indent=2)+'\n')
def test():
 run('canonical-test',[ROOT/'batched-sink','--gtest_filter=AppleSinkGraph.BatchedSharedAndPerRequestMasksRetainReboundOutputs'])
 run('forced-tail-test',[ROOT/'forced-small-blocks','--gtest_filter=AppleSinkGraph.DiagnosticBatchedTailPreservesMaskQueryAxis'])
if __name__=='__main__':{'build':build,'test':test}[sys.argv[1]]()
