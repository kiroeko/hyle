from pathlib import Path
import importlib.util, json, subprocess, sys, time

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cpu_cache',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
cfg=dict(c.PINS['mixed'],folder=Path('mixed'))
flags=c.hyle_flags(cfg)+['/I'+str(ROOT)]
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command):
    command=list(map(str,command));start=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=c.ENV,capture_output=True,timeout=150)
    tag=str(len(records)+1)+'-'+tag
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-4500:],p.stderr.decode(errors='replace')[-1500:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
def compile(path,name):
    obj=OUT/(name+'.obj');run(name+'-compile',[c.CL,*flags,path,'/Fo'+str(obj)]);return obj

objects=([OUT/'native-batch.obj',OUT/'provider.obj'] if '--reuse-products' in sys.argv else
         [compile(ROOT/'src/compute_provider_ggml/native_batch.cc','native-batch'),
          compile(ROOT/'src/compute_provider_ggml/ggml_cpu_provider.cc','provider')])
if '--regression' in sys.argv:
    objects += [compile(ROOT/'tests/compute_provider_ggml/native_paged_test.cc','native-paged-tests')]
else:
    objects+=([OUT/'consumer.obj',OUT/'graph-batch.obj'] if '--link-only' in sys.argv else
              [compile(ROOT/'tests/compute_batch/public_mla_cpu_consumer.cc','consumer'),
               compile(ROOT/'src/graph_batch/batch.cc','graph-batch')])
generic=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla'
objects += [generic/(name+'.obj') for name in ('batch-layout','batch-execution','paged-arena')]
objects += [ROOT/'.scratch/mtp-gdn-2026-10-18'/name for name in
            ('ffa4/operation.obj','mixed/selector-baseline.obj','mixed/allocator.obj')]
objects += [ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj']
libraries=[c.BASE/'bin'/(name+'.lib') for name in ('hyle_graph_batch','hyle_graph','hyle_compute_route_cpu','hyle_compute_provider_native')]
libraries+=c.common_libs(cfg)
libraries += [c.BASE/'bin/hyle_compute_provider_onednn.lib',c.BASE/'bin/dnnl.lib']
cache=(c.BASE/'CMakeCache.txt').read_text()
torch=Path(next(line.split('=',1)[1] for line in cache.splitlines() if line.startswith('TORCH_LIBRARY:'))).parent
libraries += [torch/(name+'.lib') for name in ('torch','torch_cpu','c10')]
if '--regression' in sys.argv:
    libraries += [c.BASE/'lib/gtest_main.lib',c.BASE/'lib/gtest.lib']
exe=OUT/('native-paged-tests.exe' if '--regression' in sys.argv else 'consumer.exe')
run('link',[c.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),*objects,*libraries,*c.SYSTEM])
run('native-paged-tests' if '--regression' in sys.argv else 'consumer',
    [exe,'--gtest_color=no','--gtest_filter=GgmlCpuPaged.RuntimeQ1UsesOriginalDecodeSlotAcrossPagesAndTails:GgmlCpuPaged.OriginalFlashReadsExactPhysicalPagesAndTail:GgmlCpuBoxed.PlainHighdimMixedContinuationUsesOriginalPagesAndRaggedRoots']
    if '--regression' in sys.argv else [exe])
