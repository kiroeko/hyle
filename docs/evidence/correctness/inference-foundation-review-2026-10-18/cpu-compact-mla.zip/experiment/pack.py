from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
DEST=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/cpu-compact-mla.zip'
sources=[
    'src/compute_provider_ggml/native_batch.cc','src/compute_provider_ggml/native_batch.h',
    'src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml/program.h',
    'src/graph_batch/batch.cc','include/hyle/compute/batch_layout.h',
    'include/hyle/compute/batch_ops.h','include/hyle/compute/batch_execution.h',
    'include/hyle/compute/detail/batch_provider.h',
    'tests/compute_batch/public_mla_cpu_consumer.cc','tests/compute_batch/mla_test_support.h',
    'tests/graph_batch/CMakeLists.txt','tests/compute_provider_ggml/native_paged_test.cc',
]
summary={
    'fix':'CPU typed two-payload compact MLA. Native V is a readonly strided prefix of original CKV rows, preserving 512/576 row stride, no independent V backing/copy.',
    'validation':'8 public-consumer combinations PASS: F16/H96 and BF16/H64, CKV512 and CKV512/KPE64, paged and ragged; default CPU Context extension discovery, Direct mixed Q1+Q3, transition to Q1, Q1 plan reuse, 3-port Graph; full all-output FP64 oracle.',
    'max_abs':0.000243380278,
    'budget':0.007,
    'legacy':'Fresh canonical native_paged_test.cc: original Q1 dynamic pages/tails, physical page/tail reads, independent high-dimensional Q/K/V paged+ragged all PASS, 3/3, 49.033 seconds. No further repeats.',
    'build':'Fresh CPU provider/native_batch, consumer, Graphbatch host TU, canonical legacy test TU. Shared schema/arena/execution from fresh parent CUDA closure, native CPU ops/runtime and foundation libraries reused. No SDK/native kernel build.',
    'limits':'No total RSS/VRAM/throughput claim. CPU native temporary metadata remains reported unknown. Other host/nonMLA ops in source snapshots include pre-existing and concurrent agent changes.',
    'setup_failures':'Initial new consumer assumed nonexistent RaggedMlaAttention/overloads and used a conditional Result expression; corrected consumer, added common typed ragged op. Initial default-context link omitted oneDNN; reused cached provider/native lib. All attempt logs/commands retained.',
}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
identity=[]
for name in sources:
    p=ROOT/name;identity.append(dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
for p in (OUT/'provider.obj',OUT/'native-batch.obj',
          ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj'):
    identity.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(OUT/'identities.json').write_text(json.dumps(identity,indent=2)+'\n')
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name in sources:archive.write(ROOT/name,'source/'+name)
    for p in sorted(OUT.iterdir()):
        if p.suffix in ('.py','.json','.log'):archive.write(p,'experiment/'+p.name)
    archive.writestr('source/worktree.diff',subprocess.check_output(['git','diff','--',*sources],cwd=ROOT))
    wiring=OUT.parent/'test-wiring'
    for p in wiring.iterdir():
        if p.is_file() and p.suffix in ('.py','.json','.log','.txt'):
            archive.write(p,'test-wiring/'+p.name)
print(DEST.name,DEST.stat().st_size,hashlib.sha256(DEST.read_bytes()).hexdigest())
