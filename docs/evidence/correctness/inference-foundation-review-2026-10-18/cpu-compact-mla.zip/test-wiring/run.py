from pathlib import Path
import subprocess, sys

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
source=(ROOT/'.scratch/inference-feature-completion-2026-10-18/batch-test-wiring/verify.py').read_text()
source=source.replace('set(_HYLE_COMPUTE_HAVE_CPU ${FIXTURE_CPU})',
    'set(_HYLE_COMPUTE_HAVE_CPU ${FIXTURE_CPU})\nset(HYLE_GGML_CPU_ENABLED ${FIXTURE_CPU})')
source=source.replace('add_library(hyle_graph_route_cpu INTERFACE)',
    'add_library(hyle_graph_route_cpu INTERFACE)\n  add_library(hyle_compute_route_cpu INTERFACE)')
source=source.replace('IN ITEMS cpu_materialized cuda_public_native',
    'IN ITEMS cpu_materialized cpu_public_mla cuda_public_native cuda_public_mla')
source=source.replace('kind STREQUAL "cpu_materialized"','kind MATCHES "^cpu_"')
source=source.replace('kind STREQUAL "cuda_public_native"','kind MATCHES "^cuda_"')
generated=OUT/'verify.py';generated.write_text(source)
raise SystemExit(subprocess.call([sys.executable,'-X','utf8',str(generated)],cwd=ROOT))
