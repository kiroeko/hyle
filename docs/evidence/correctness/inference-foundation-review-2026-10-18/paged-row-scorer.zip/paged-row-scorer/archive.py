from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

summary = read(STAGE / 'summary.json')
assert summary['status'] == 'validated', summary
assert summary['broader_goal'] == 'active and incomplete'
save(DEST / 'paged-row-scorer-results.json', summary)

entries = {}
allowed = {'.json', '.py', '.log', '.diff', '.h', '.cc', '.cpp', '.inc', '.txt', '.d', '.comp', '.ps1'}
for folder in [STAGE, STAGE.parent / 'paged-row-scorer-apple', STAGE.parent / 'paged-row-scorer-vulkan']:
    for path in folder.rglob('*'):
        if not path.is_file() or path.suffix not in allowed:
            continue
        if path.name in {'archive-receipt.json', 'cleanup-result.json', 'live.json'}:
            continue
        assert not path.is_symlink()
        name = path.relative_to(STAGE.parent).as_posix()
        assert name not in entries
        entries[name] = path
entries['test.ps1'] = ROOT / 'test.ps1'
entries['results.json'] = DEST / 'paged-row-scorer-results.json'
manifest = [dict(entry=name, bytes=identity(path)['bytes'], sha256=identity(path)['sha256'])
            for name, path in sorted(entries.items())]
archive = DEST / 'paged-row-scorer.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as package:
    for name, path in sorted(entries.items()):
        package.write(path, name)
    package.writestr('archive-content-identities.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for row in manifest:
        data = package.read(row['entry'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = dict(archive=identity(archive), results=identity(DEST / 'paged-row-scorer-results.json'),
               entries=len(manifest)+1, no_objects_executables_sdk_or_spv_in_archive=True)
save(STAGE / 'archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
