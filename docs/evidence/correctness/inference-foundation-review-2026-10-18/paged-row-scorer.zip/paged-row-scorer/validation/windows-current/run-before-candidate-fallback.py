from pathlib import Path
import hashlib,json,os,struct,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent; ROOT=OUT.parents[4]; OLD=OUT.parent/'windows'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def ident(p):
 p=Path(p).resolve(); d=p.read_bytes(); return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
PLAN=read(OLD/'command-plan.json');BASE=read(OLD/'baseline-link.json');RECIPES=read(OLD/'recipes.json')
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':PLAN['compile_test'][0],'CMAKE_C_COMPILER':PLAN['compile_test'][0]})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x['path']).parent) for x in BASE['libraries'] if 'path'in x))+os.pathsep+env['PATH']
env.update(DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~',VSLANG='1033')
SOURCES=['src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/vulkan_row_cache_indexer.cc','src/compute_route_vulkan/vulkan_row_cache.cc','src/graph_route_vulkan/native_region.cc','src/graph_route_vulkan/vulkan_lowering.cc']
SHADERS=OUT/'shaders';SHADERS.mkdir(exist_ok=True)
def obj(s):return OUT/(s.replace('/','--').removesuffix('.cc')+('-ownedlayout' if s=='tests/graph_batch/native_row_cache_indexer_test.cc' else '')+'.obj')
def call(tag,argv,sources=(),outputs=(),allowed_exit=(0,)):
 assert not (OUT/(tag+'.command.json')).exists(),tag
 row=dict(tag=tag,argv=list(map(str,argv)),cwd=str(ROOT),exit=None,started=time.time(),sources_before=[ident(ROOT/s) for s in sources])
 row['inputs_before']=[ident(x) for x in row['argv'] if Path(x).is_absolute() and Path(x).is_file() and Path(x).suffix.lower()in{'.obj','.lib'}]
 save(OUT/(tag+'.command.json'),row)
 with (OUT/(tag+'.stdout.log')).open('wb')as so,(OUT/(tag+'.stderr.log')).open('wb')as se:
  child=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=child.pid;save(OUT/'live.json',row)
  try:row['exit']=child.wait(timeout=55)
  except subprocess.TimeoutExpired:
   child.kill();child.wait();row['exit']='timeout55';row['timed_out']=True
 row.update(terminal=True,finished=time.time(),sources_after=[ident(ROOT/s)for s in sources],outputs=[ident(x)for x in outputs if Path(x).is_file()])
 assert row['sources_before']==row['sources_after'],'source drift'
 save(OUT/(tag+'.result.json'),row);save(OUT/'live.json',row)
 print(json.dumps(dict(tag=tag,exit=row['exit'],outputs=row['outputs'])),flush=True)
 for suffix in ['stdout','stderr']:
  t=(OUT/(tag+'.'+suffix+'.log')).read_text(errors='replace')
  if t:print(t[-13000:],flush=True)
 if row['exit']not in allowed_exit:raise SystemExit(1)
 return row

def compile_argv(original,source,output,dependency=True):
 argv=[str(x)for x in original if not str(x).lower().startswith('/fo')]
 argv=[str(ROOT/source)if x.lower().endswith('.cc')else x for x in argv]
 argv.insert(1,'/I'+str(SHADERS))
 argv.append('/Fo'+str(output))
 if dependency:argv+=['/sourceDependencies',str(output.with_suffix('.deps.json'))]
 return argv

def shader():
 old=ROOT/'.scratch/inference-foundation-review-2026-10-18/native-row-cache-padded/shaders/vulkan_shaders.h'
 h=old.read_text(); h=h.replace('std::span<const std::uint32_t> row_cache_padded_map()', 'std::span<const std::uint32_t> row_cache_paged_indexer() noexcept;\nstd::span<const std::uint32_t> row_cache_padded_map()')
 (SHADERS/'vulkan_shaders.h').write_text(h,encoding='utf-8',newline='\n')
 argv=PLAN['shader_one_variant'].copy();argv[argv.index('-o')+1]=str(SHADERS/'row_cache_paged_indexer.spv')
 call('001-paged-shader',argv,sources=['src/compute_route_vulkan/shaders/row_cache_indexer.comp'],outputs=[SHADERS/'row_cache_paged_indexer.spv'])
 d=(SHADERS/'row_cache_paged_indexer.spv').read_bytes();assert len(d)>=20 and len(d)%4==0
 words=struct.unpack('<'+'I'*(len(d)//4),d);assert words[0]==0x07230203 and words[1]<=0x00010500
 i=5;cap=[]
 while i<len(words):
  n=words[i]>>16;opcode=words[i]&65535;assert n>0 and i+n<=len(words)
  if opcode==17:assert n==2 and words[i+1]==1;cap.append(words[i+1])
  i+=n
 assert i==len(words)
 text='#include "vulkan_shaders.h"\nnamespace hyle::compute::vulkan::detail::shaders {\nnamespace { constexpr std::uint32_t row_cache_paged_indexer_words[] = {\n'
 text+='\n'.join('  '+','.join('0x%08xu'%w for w in words[j:j+8])+','for j in range(0,len(words),8))
 text+='\n}; }\nstd::span<const std::uint32_t> row_cache_paged_indexer() noexcept { return row_cache_paged_indexer_words; }\n}\n'
 (SHADERS/'vulkan_shaders.cc').write_text(text,encoding='utf-8',newline='\n')
 save(OUT/'shader-receipt.json',dict(tool=ident(argv[0]),header_original=ident(old),generated=[ident(SHADERS/x)for x in ['vulkan_shaders.h','vulkan_shaders.cc','row_cache_paged_indexer.spv']],capabilities=cap,version=hex(words[1]),reused_original_shader=ident(ROOT/'.scratch/inference-foundation-review-2026-10-18/native-row-cache-padded/shaders.obj')))

def hosts():
 for i,s in enumerate(SOURCES,2):
  out=obj(s);call('%03d-host-%s'%(i,Path(s).stem),compile_argv(RECIPES[s]['argv'],s,out),sources=[s],outputs=[out,out.with_suffix('.deps.json')])
 s=str((SHADERS/'vulkan_shaders.cc').relative_to(ROOT));out=OUT/'row-cache-paged-shader.obj'
 call('008-paged-embedding',compile_argv(RECIPES['generated/vulkan_shaders.cc']['argv'],s,out),sources=[s],outputs=[out,out.with_suffix('.deps.json')])

def tests():
 s='tests/graph_batch/native_row_cache_indexer_test.cc';inc='tests/graph_batch/native_row_cache_indexer_pending.inc';out=obj(s)
 assert ident(ROOT/s)['sha256']=='6a2179ab67cc3dfbe143835db3ed5042eafccf171fbbd4ab39003dabe9e85f9a'
 assert ident(ROOT/inc)['sha256']=='aa98022bc65b6b1f78d66c8ad0fd3d8034b0ea806f71088b20a7ea3129e1de3f'
 call('009-final6-test',compile_argv(PLAN['compile_test'],s,out),sources=[s,inc],outputs=[out,out.with_suffix('.deps.json')])
 s='tests/compute_route_vulkan/row_cache_indexer_test.cc';out=obj(s)
 call('010-original-indexer3-test',compile_argv(PLAN['adjacent_compile'],s,out),sources=[s],outputs=[out,out.with_suffix('.deps.json')])

def link():
 for row in BASE['objects']+BASE['libraries']:
  if 'path'in row:assert ident(row['path'])==row,row
 replacement={str(Path(BASE['selected_sources'][s])).lower():str(obj(s))for s in SOURCES}
 argv=[replacement.get(x.lower(),x)for x in BASE['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 extra=[OUT/'row-cache-paged-shader.obj',obj('tests/graph_batch/native_row_cache_indexer_test.cc'),obj('tests/compute_route_vulkan/row_cache_indexer_test.cc')]
 argv+=list(map(str,extra));stem=OUT/'current-scorer-tests';argv+=['/OUT:'+str(stem.with_suffix('.exe')),'/MAP:'+str(stem.with_suffix('.map')),'/IMPLIB:'+str(stem.with_suffix('.lib'))]
 selected=BASE['selected_sources'].copy();selected.update({s:str(obj(s))for s in SOURCES});selected.update({s:str(obj(s))for s in ['tests/graph_batch/native_row_cache_indexer_test.cc','tests/compute_route_vulkan/row_cache_indexer_test.cc']});selected['generated/row_cache_paged_indexer_shaders.cc']=str(extra[0])
 sources=[dict(source=s,object=ident(o),current_source=ident(ROOT/s)if(ROOT/s).is_file()else None)for s,o in selected.items()]
 save(OUT/'matched-link-plan.json',dict(command=argv,selected_sources=selected,source_object_identities=sources,replacement_sources=SOURCES,unchanged_base_receipt=ident(OLD/'baseline-link.json')))
 call('015-current-link',argv,outputs=[stem.with_suffix(x)for x in ['.exe','.map','.lib','.exp']])

def run():
 exe=OUT/'current-scorer-tests.exe'; report=OUT/'016-current-tests.json'
 call('016-current-run',[exe,'--gtest_filter=NativePagedRowIndexer.*:VulkanRowCacheIndexer.*:VulkanProjectedRowGraph.*:VulkanRowCachePadded.*','--gtest_color=no','--gtest_output=json:'+str(report)],outputs=[report])
 r=read(report);assert r['tests']==18 and r['failures']==0,r

if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':
  freeze=read(ROOT/'.scratch/architecture-refactor-2026-10-18/paged-row-scorer-vulkan/product-freeze.json')
  for x in freeze['files']:
   a=ident(ROOT/x['path']);assert (a['bytes'],a['sha256'])==(x['bytes'],x['sha256']),x
  save(OUT/'initial-source-identities.json',[ident(ROOT/x['path'])for x in freeze['files']]+[ident(ROOT/s)for s in SOURCES])
 elif action=='shader':shader()
 elif action=='hosts':hosts()
 elif action=='tests':tests()
 elif action=='finaltest':
  s='tests/graph_batch/native_row_cache_indexer_test.cc';inc='tests/graph_batch/native_row_cache_indexer_pending.inc';out=obj(s)
  assert ident(ROOT/s)['sha256']=='ea43cd3ab7f5c212450f936f21171076abb635449adb471e2a4445cbadada334'
  assert ident(ROOT/inc)['sha256']=='9fd941d18eca2d870e3eb1bcc9e3f604ac390949cd9a92bc5e183337f190ec28'
  call('014-final6-ownedlayout-test',compile_argv(PLAN['compile_test'],s,out),sources=[s,inc],outputs=[out,out.with_suffix('.deps.json')])
 elif action=='link':link()
 elif action=='run':run()
 elif action=='oldcontrol-link':
  current=read(OUT/'016-current-tests.json');assert current['tests']==18 and current['failures']==0
  for x in BASE['objects']+BASE['libraries']:
   if 'path'in x:assert ident(x['path'])==x
  stem=OUT/'old-product-final6-control'
  argv=[x for x in BASE['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
  argv+=[str(obj('tests/graph_batch/native_row_cache_indexer_test.cc')),'/OUT:'+str(stem.with_suffix('.exe')),'/MAP:'+str(stem.with_suffix('.map')),'/IMPLIB:'+str(stem.with_suffix('.lib'))]
  save(OUT/'old-product-final6-plan.json',dict(command=argv,selected_sources=BASE['selected_sources'],test=ident(obj('tests/graph_batch/native_row_cache_indexer_test.cc')),new_paged_shader=False))
  call('020-old-product-final6-link',argv,outputs=[stem.with_suffix(x)for x in ['.exe','.map','.lib','.exp']])
 elif action=='oldcontrol-run':
  report=OUT/'021-old-product-final6-tests.json'
  call('021-old-product-final6-run',[OUT/'old-product-final6-control.exe','--gtest_filter=NativePagedRowIndexer.*','--gtest_color=no','--gtest_output=json:'+str(report)],outputs=[report],allowed_exit=(1,))
  r=read(report);assert r['tests']==6 and r['failures']==6,r
 else:raise ValueError(action)
