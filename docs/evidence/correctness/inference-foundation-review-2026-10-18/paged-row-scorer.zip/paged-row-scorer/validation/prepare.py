"""Write narrow command plans only. Never compile, link, or run a test."""
from pathlib import Path
import hashlib,json

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];ARCH=OUT.parents[1]
TEST='tests/graph_batch/native_row_cache_indexer_test.cc'
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def ident(path):
    path=Path(path);data=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

recipes=read(OUT/'windows/recipes.json')
source='tests/graph_route_vulkan/row_cache_projection_test.cc'
argv=recipes[source]['argv']
args=[x for x in argv if not x.lower().endswith(('.cc','.cpp')) and not x.lower().startswith(('/fo','/fd'))]
for flag in ['/W4','/WX']:
    if flag not in args:args.append(flag)
args+=['/DHYLE_NATIVE_ROW_INDEXER_VULKAN=1',str(ROOT/TEST),'/Fo'+str(OUT/'native-row-scorer-test.obj')]
old=read(OUT/'windows/baseline-link.json')['command']
link=[x for x in old if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
link+=[str(OUT/'native-row-scorer-test.obj'),'/OUT:'+str(OUT/'old-scorer-tests.exe'),
       '/MAP:'+str(OUT/'old-scorer-tests.map'),'/IMPLIB:'+str(OUT/'old-scorer-tests.lib')]
history=read(ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-indexer-native/vulkan-commands.json')
original=next(row['command'] for row in reversed(history) if row['tag']=='vulkan-test-compile' and row['exit']==0)
adjacent=[x for x in original if not x.lower().endswith(('.cc','.cpp')) and not x.lower().startswith(('/fo','/fd'))]
for flag in ['/W4','/WX']:
    if flag not in adjacent:adjacent.append(flag)
adjacent+=[str(ROOT/'tests/compute_route_vulkan/row_cache_indexer_test.cc'),'/Fo'+str(OUT/'ordinary-indexer-test.obj')]
summary=read(OUT/'windows/summary.json')
shader=summary['shader_increment']['argv_template'].copy()
shader[shader.index('<new-one.spv>')]=str(OUT/'shaders/row_cache_paged_indexer.spv')
shader[shader.index('<new-one.comp>')]=str(ROOT/'src/compute_route_vulkan/shaders/row_cache_indexer.comp')
shader.insert(shader.index('-o'),'-DHYLE_ROW_INDEXER_PAGED=1')
save('windows/command-plan.json',dict(status='not_executed_waiting_for_frozen_source',
    compile_test=args,test_recipe=recipes[source]['record'],old_link=link,
    adjacent_compile=adjacent,adjacent_filter='VulkanRowCacheIndexer.*',
    shader_one_variant=shader,shader_format='Use existing build_shaders.py SPIR-V word/capability checks and uint32_t/span source format; define only row_cache_paged_indexer, keep old shaders.obj.',
    current_link='replace only frozen changed selected_sources owners; add new one-shader embedding object; use same frozen test object',
    old_filter='Root to provide exact new suite/case names after test freeze'))

data=read(OUT/'apple/summary.json');remote=data['remote']
recipes=read(OUT/'apple/recipes.json')
source='tests/graph_route_apple/row_cache_pending_projection_test.cc'
argv=recipes[source]['argv'].copy()
argv[argv.index('-c')+1]=remote+'/'+TEST
obj=remote+'/native-row-scorer-test.o';argv[argv.index('-o')+1]=obj
if '-MF' in argv:
    at=argv.index('-MF');del argv[at:at+2]
argv=[x for x in argv if x!='-MMD']
argv[1:1]=['-DHYLE_NATIVE_ROW_INDEXER_APPLE=1','-I'+remote+'/include','-I'+remote,
           '-I'+remote+'/src/graph','-I'+remote+'/src/compute','-I'+remote+'/src/compute_route_apple','-I'+remote+'/src/graph_route_apple']
argv+=['-MMD','-MF',obj+'.d']
link=read(OUT/'apple/baseline-links.json')['gtest']['argv'].copy();link.insert(1,obj)
image=remote+'/old-scorer-tests';link[link.index('-o')+1]=image
link=[('-Wl,-map,'+image+'.map') if x.startswith('-Wl,-map,') else x for x in link]
save('apple/command-plan.json',dict(status='not_executed_waiting_for_frozen_source',
    compile_test=argv,test_recipe=recipes[source]['record'],old_link=link,
    adjacent_filter='AppleRowCacheIndexer.*',adjacent_object=read(OUT/'apple/baseline-objects.json')['tests/compute_route_vulkan/row_cache_indexer_test.cc'],
    current_link='replace only frozen changed selected_sources owners; retain source-preflight context/copy/leased/materialized owners; use same frozen test object',
    old_filter='Root to provide exact new suite/case names after test freeze',metallib='Keep unchanged f32-partials/mlx.metallib and native-host.f32.o identities'))
save('preparation-receipt.json',{name:ident(OUT/name) for name in [
    'inventory.py','prepare.py','windows/summary.json','windows/command-plan.json',
    'windows/shader-identities.json','windows/shader-compatibility.json','windows/glslang-version.json',
    'apple/summary.json','apple/command-plan.json','apple/baseline-proof.json']})
print('command plans written; no compile/link/test executed')
