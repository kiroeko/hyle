from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];ARCH=OUT.parents[1]
BASE=ARCH/'vulkan-row-pending';AIR=ARCH/'apple-source-preflight/validation'

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):
    path=OUT/path;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def identity(path):
    path=Path(path).resolve();h=hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1024*1024),b''):h.update(part)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=h.hexdigest())


def windows():
    link=read(BASE/'current-link.json')
    for row in link['objects']+link['libraries']:
        if 'system_library' in row:continue
        assert identity(row['path'])==row,('baseline artifact drift',row)
    save('windows/baseline-link.json',link)
    recipes={row['source']:dict(argv=row['command'],record=str(ARCH/'native-ready-pages/windows/compile-plan.json'))
             for row in read(ARCH/'native-ready-pages/windows/compile-plan.json')}
    for folder in [ARCH/'row-cache-region-projection',BASE]:
        for path in folder.glob('*.cc.json'):
            row=read(path)
            if row.get('exit')==0:
                source=Path(row['source']['path']).relative_to(ROOT).as_posix()
                recipes[source]=dict(argv=row['command'],record=str(path))
    padded=ROOT/'.scratch/inference-foundation-review-2026-10-18/native-row-cache-padded'
    shader_rows=read(padded/'vulkan-commands.json')
    generated=next(row for row in shader_rows if row['tag']=='shaders-compile' and row['exit']==0)
    recipes['generated/vulkan_shaders.cc']=dict(argv=generated['command'],record=str(padded/'vulkan-commands.json'))
    save('windows/recipes.json',recipes)
    tool=Path('C:/public/tools/glslang/glslangValidator.exe')
    version=subprocess.run([str(tool),'--version'],capture_output=True,text=True,timeout=10)
    assert version.returncode==0,version.stderr
    save('windows/glslang-version.json',dict(command=[str(tool),'--version'],exit=version.returncode,
         stdout=version.stdout,stderr=version.stderr,identity=identity(tool)))
    shader_dir=padded/'shaders'
    shader_files=[ROOT/'src/compute_route_vulkan/build_shaders.py',
                 *sorted((ROOT/'src/compute_route_vulkan/shaders').glob('*.comp')),
                 shader_dir/'vulkan_shaders.h',shader_dir/'vulkan_shaders.cc',
                 shader_dir/'row_cache_indexer.spv',padded/'shaders.obj']
    fingerprints=[identity(path) for path in shader_files]
    save('windows/shader-identities.json',fingerprints)
    relevant={source:obj for source,obj in link['selected_sources'].items() if
              source.startswith(('src/graph_batch/','src/graph_route_vulkan/')) or
              'row_cache' in source or source in ['src/graph/region_access.cc','src/graph/resources.cc']}
    summary=dict(status='inventory_only_no_compile_or_tests',objects=len(link['objects']),libraries=len(link['libraries']),
       file_libraries=sum('path' in row for row in link['libraries']),
       system_libraries=[row['system_library'] for row in link['libraries'] if 'system_library' in row],
       selected_sources=len(link['selected_sources']),recipes=len(recipes),relevant_selected_sources=relevant,
       previous_tests=dict(total=9,failed=0,record=str(BASE/'current-results.json')),
       shader_owner=identity(padded/'shaders.obj'),
       shader_increment=dict(compiler=str(tool),target='vulkan1.2 / SPIR-V <=1.5 / capability Shader only',
          argv_template=[str(tool),'-V','--target-env','vulkan1.2','--preamble-text',
             '#extension GL_GOOGLE_include_directive : require\n',
             '-I'+str(ROOT/'third_party/ggml_vulkan_shaders/shaders'),'-S','comp','-o','<new-one.spv>','<new-one.comp>'],
          embedding='little-endian uint32_t constexpr words; namespace hyle::compute::vulkan::detail::shaders; std::span<const uint32_t> function() noexcept',
          plan='If the new shader has its own symbol, add one small generated C++ object and retain prior shaders.obj. Do not execute full build_shaders.py (11 variants).',
          source_status='Current shader fingerprints captured before final implementation freeze; changed/new source must be re-identified before compiling.'),
       cl=identity(link['command'][0].replace('link.exe','cl.exe')),linker=identity(link['command'][0]),
       no_sdk_kernel_or_metallib_build=True)
    save('windows/summary.json',summary)
    print(json.dumps({key:summary[key] for key in ['status','objects','libraries','selected_sources','recipes']}))


def apple():
    spec=importlib.util.spec_from_file_location('air_runner',AIR/'run.py')
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    links={name:read(AIR/('results/'+tag+'.result.json')) for name,tag in
           [('gtest','012-current-link'),('native','014-native-link')]}
    owners=read(AIR/'baseline-objects.json');owners.update(read(AIR/'objects.json'))
    save('apple/baseline-links.json',{name:dict(argv=row['argv'],inputs=row['inputs_before']) for name,row in links.items()})
    save('apple/baseline-objects.json',owners)
    save('apple/baseline-proof.json',{name:identity(AIR/name) for name in
         ['receipt.json','summary.json','final-source-identities.json','dependency-check.json']})
    code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root']);r.mkdir(parents=True,exist_ok=True)
def identity(q):
 q=Path(q);h=hashlib.sha256()
 with q.open('rb') as stream:
  for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
inputs={x['path']:x for rows in p['links'].values() for x in rows}
for row in list(inputs.values())+p['math']:
 assert identity(row['path'])==row,(row,identity(row['path']))
history=json.loads((Path(p['base'])/'commands.json').read_text());recipes={}
for source in p['sources']:
 found=[row for row in history if row.get('exit')==0 and row['tag'].endswith('-compile') and any(str(x).endswith('/'+source) for x in row.get('command',[]))]
 assert found,source
 recipes[source]=dict(argv=found[-1]['command'],record=str(Path(p['base'])/'commands.json'),record_tag=found[-1]['tag'])
hardware={key:subprocess.check_output(argv,text=True).strip() for key,argv in {
 'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],
 'memory':['sysctl','-n','hw.memsize'],'system':['sw_vers'],'compiler':['/usr/bin/clang++','--version']}.items()}
assert hardware['model']=='Mac16,12'
result=dict(status='inventory_only_no_compile_or_tests',hardware=hardware,link_counts={k:len(v) for k,v in p['links'].items()},
 matched_unique_inputs=len(inputs),math=p['math'],recipes=recipes)
(r/'baseline-identities.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
    sources=['src/compute_route_apple/apple_row_cache_indexer.cc']
    math=read(AIR/'baseline-identities.json')['math']
    remote=runner.AIR_BASE+'/paged-row-scorer/validation'
    result=runner.prior.air.ssh(code,json.dumps(dict(root=remote,base=runner.AIR_BASE,
       links={key:row['inputs_before'] for key,row in links.items()},math=math,sources=sources)).encode(),timeout=45)
    (OUT/'apple').mkdir(exist_ok=True)
    (OUT/'apple/inventory.stdout.log').write_bytes(result.stdout)
    (OUT/'apple/inventory.stderr.log').write_bytes(result.stderr)
    assert result.returncode==0,result.stderr
    data=json.loads(result.stdout);save('apple/baseline-identities.json',data)
    recipes=data.pop('recipes')
    # Latest current-source recipes take precedence over the fixed-root history.
    latest={source:record for source,record in read(AIR/'recipes.json').items()}
    for source,tag in [('src/compute_route_apple/apple_mature_float.cc','007-mature'),
                       ('src/compute_route_apple/apple_operations.cc','008-operations'),
                       ('src/compute_route_apple/apple_row_cache_paged.cc','009-row-paged'),
                       ('src/graph_route_apple/apple_lowering.cc','010-lowering')]:
        record=ARCH/'apple-row-pending/validation/results'/(tag+'.command.json')
        latest[source]=dict(argv=read(record)['argv'],record=str(record))
    for source,tag in [('src/compute_route_apple/apple_context.cc','006-context'),
                       ('src/compute_route_apple/apple_copy_program.cc','007-copy-program'),
                       ('src/compute_route_apple/apple_leased_invocation.cc','008-leased'),
                       ('src/compute_route_apple/apple_materialized_invocation.cc','009-materialized'),
                       ('src/graph_route_apple/native_paged_region.cc','010-page-region'),
                       ('src/graph_route_apple/native_region.cc','011-region')]:
        latest[source]=dict(argv=read(AIR/('results/'+tag+'.command.json'))['argv'],record=str(AIR/('results/'+tag+'.command.json')))
    recipes.update(latest);save('apple/recipes.json',recipes)
    data.update(remote=remote,recipes=len(recipes),no_sdk_kernel_or_metallib_build=True)
    save('apple/summary.json',data)
    print(json.dumps(data))


if __name__=='__main__':
    action=sys.argv[1]
    if action=='windows':windows()
    elif action=='apple':apple()
    else:raise ValueError(action)
