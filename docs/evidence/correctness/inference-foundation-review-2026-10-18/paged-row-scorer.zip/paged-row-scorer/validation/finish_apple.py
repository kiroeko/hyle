from pathlib import Path
import importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;LOCAL=OUT/'apple'
spec=importlib.util.spec_from_file_location('runner',OUT/'run_apple.py')
run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root'])
def ident(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
compiled=[json.loads(path.read_text()) for path in sorted(r.glob('*.result.json')) if path.name in p['compiled']]
retained=[]
for row in compiled:
 assert row['exit']==0 and row['source_before']==row['source_after']
 for item in row['outputs']:
  if item['path'].endswith('.o'):assert ident(item['path'])==item;retained.append(item)
assert len(retained)==8 and len({x['path'] for x in retained})==8
links={tag:json.loads((r/(tag+'.result.json')).read_text()) for tag in ['026-current-link','028-old-final-link']}
for row in links.values():
 assert row['exit']==0
 for item in row['inputs_before']+row['outputs']:assert ident(item['path'])==item
current=links['026-current-link'];old=links['028-old-final-link']
selected=[]
for tag in ['017-indexer-helper-fixed','011-mature','025-region-split-fixed','021-layout-fixed-test']:
 row=json.loads((r/(tag+'.result.json')).read_text());obj=next(x for x in row['outputs'] if x['path'].endswith('.o'))
 text=Path(current['outputs'][1]['path']).read_text().split('# Object files:\n',1)[1].split('# Sections:',1)[0]
 found=[line for line in text.splitlines() if line.endswith(obj['path'])];assert len(found)==1,(tag,found)
 selected.append(dict(source=row['source_before'],object=obj,map_entry=found[0]))
test=next(x for x in selected if x['source']['path'].endswith('native_row_cache_indexer_test.cc'))['object']
assert test in current['inputs_before'] and test in old['inputs_before']
for item in old['inputs_before']:
 assert not item['path'].startswith(str(r)+'/') or item==test,('old control contains new products',item)
for item in p['math']:assert ident(item['path'])==item
assert (r/'mlx.metallib').resolve()==Path(p['math'][0]['path']).resolve()
for tag,expected in [('008-old-run',1),('015-current-run',1),('019-current-run',1),('023-current-run',1),('027-current-run',0),('029-old-final-run',1)]:
 row=json.loads((r/(tag+'.result.json')).read_text());assert row['terminal'] and row['exit']==expected
 ps=subprocess.run(['ps','-p',str(row['pid']),'-o','command='],capture_output=True,text=True)
 assert ps.returncode!=0 or str(r) not in ps.stdout
cleanup=dict(host='kiro@172.22.10.198',root=str(r),files=current['outputs']+old['outputs'],retain=retained+p['math'])
assert len({x['path'] for x in cleanup['files']})==4
assert not {x['path'] for x in cleanup['files']} & {x['path'] for x in cleanup['retain']}
save('cleanup-mac.json',cleanup);save('selected-current-owners.json',selected)
save('final-link-input-identities.json',{key:row['inputs_before'] for key,row in links.items()})
result=dict(live_process=False,retained_objects=8,retained_original_math=2,cleanup_files=4,
 cleanup_bytes=sum(x['bytes'] for x in cleanup['files']),current_inputs=len(current['inputs_before']),old_inputs=len(old['inputs_before']),same_test_object=test)
save('final-verification.json',result);print(json.dumps(result))
'''
tags=['006-test-builtin-fixed-compile','010-indexer','011-mature','012-region','013-final-test',
      '017-indexer-helper-fixed','021-layout-fixed-test','025-region-split-fixed']
math=json.loads((LOCAL/'baseline-identities.json').read_text())['math']
result=run.prior.air.ssh(code,json.dumps(dict(root=run.REMOTE,compiled=[tag+'.result.json' for tag in tags],math=math)).encode(),timeout=45)
(LOCAL/'030-verify.stdout.log').write_bytes(result.stdout);(LOCAL/'030-verify.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0
run.prior.collect()
def read(name):return json.loads((LOCAL/'results'/name).read_text())
sources={}
for name in ['009-current-source-sources.json','016-helper-fix-source-sources.json',
             '020-layout-fixed-test-source-sources.json','024-split-fix-source-sources.json']:
    for row in json.loads((LOCAL/name).read_text()):sources[row['path']]=row
for path,row in sources.items():
    assert run.prior.identify(run.ROOT/path)==row,(path,'source drift')
    target=LOCAL/'final-source'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(run.ROOT/path,target)
deps={}
for tag in ['017-indexer-helper-fixed','011-mature','025-region-split-fixed','021-layout-fixed-test']:
    for row in read(tag+'.result.json')['dependencies']:
        assert row['path'].startswith(run.REMOTE+'/'),row
        logical=row['path'][len(run.REMOTE)+1:];actual=sources[logical]
        assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),(row,actual)
        deps[logical]=actual
run.save('final-source-identities.json',list(sources.values()))
run.save('dependency-check.json',dict(matched_current=len(deps),drift=[],unmapped=[]))
shutil.copyfile(LOCAL/'results/cleanup-mac.json',LOCAL/'cleanup-mac.json')
assert read('027-current-run-tests.json')['tests']==6 and read('027-current-run-tests.json')['failures']==0
assert read('029-old-final-tests.json')['tests']==6 and read('029-old-final-tests.json')['failures']==6
prior=read('015-current-tests.json');assert prior['tests']==25 and prior['failures']==6
verified=read('final-verification.json')
summary=dict(status='current_scorer_6_pass_old_same_fixture_6_fail',hardware=json.loads((LOCAL/'baseline-identities.json').read_text())['hardware'],
 current=dict(link='026-current-link',run='027-current-run',tests=6,passed=6,failed=0),
 adjacent=dict(run='015-current-run',passed=19,total=19,
    note='Earlier bounded run; its six new scorer cases failed cold Metal compilation. The 19 adjacent controls passed before the new-scorer-only helper and constrained proposal fixes. Not a final single 25/25 run.'),
 old_same_fixture=dict(link='028-old-final-link',run='029-old-final-run',tests=6,passed=0,failed=6,
    same_object=verified['same_test_object'],reason='three complete/empty chains exhaust placement attempts; three standalone scorer routes have no admitted MLX lowering'),
 original_old5=dict(run='008-old-run',passed=0,total=5),
 failures_retained=[dict(tags=['002-test-v1-compile','004-test-api-fixed-compile'],reason='TopK fixture API conversion errors'),
   dict(run='015-current-run',reason='Metal helper incorrectly referenced function template Q_OFFSET from global header'),
   dict(run='019-current-run',reason='Fixture created different owned LayoutVersion for prepare and bind'),
   dict(run='023-current-run',reason='Overlapping maximal proposals omitted a feasible constrained native cut')],
 fresh_products=['apple_row_cache_indexer.cc','apple_mature_float.cc','graph_route_apple/native_region.cc'],
 final_selected_owners='results/selected-current-owners.json',source_count=len(sources),dependencies=len(deps),drift=[],
 no_sdk_air_or_prebuilt_metallib_rebuild=True,original_math_artifacts=math,
 runtime_metal='New MLX metal_kernel source compiled naturally during cold preparation; no SDK/metallib replacement.',
 cleanup=dict(manifest='cleanup-mac.json',files=4,bytes=verified['cleanup_bytes']),
 retained_stage_objects=8,retained_original_math_artifacts=2,live_process=False,
 not_claimed=['native page 64-step consumer rerun in this slice','full-model accuracy/performance','zero warm allocation','final one-run 25/25'])
run.save('summary.json',summary)
run.save('runner-source-identities.json',[run.prior.identify(OUT/'run_apple.py'),run.prior.identify(OUT/'finish_apple.py'),
                                       run.prior.identify(run.BASE/'run.py')])
run.save('receipt.json',{key:run.prior.identify(LOCAL/name) for key,name in
    [('summary','summary.json'),('cleanup','cleanup-mac.json'),('sources','final-source-identities.json'),('dependencies','dependency-check.json')]})
print(json.dumps(summary,indent=2))
