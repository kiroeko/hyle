from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3]
LOG=OUT/'windows';TEST=ROOT/'tests/graph_batch/native_row_cache_indexer_test.cc'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def ident(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(name,value):(LOG/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
PLAN=read(LOG/'command-plan.json');BASE=read(LOG/'baseline-link.json')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':PLAN['compile_test'][0],
                                 'CMAKE_C_COMPILER':PLAN['compile_test'][0]})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(row['path']).parent) for row in BASE['libraries'] if 'path' in row))+os.pathsep+env['PATH']
env.update(DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~',VSLANG='1033')
def call(tag,argv,source=None,outputs=()):
    assert not (LOG/(tag+'.command.json')).exists(),tag
    row=dict(tag=tag,argv=list(map(str,argv)),cwd=str(ROOT),exit=None,started=time.time())
    if source:row['source_before']=ident(source)
    row['inputs_before']=[ident(x) for x in row['argv'] if Path(x).is_absolute() and Path(x).is_file() and Path(x).suffix.lower() in {'.obj','.lib'}]
    save(tag+'.command.json',row)
    with (LOG/(tag+'.stdout.log')).open('wb') as so,(LOG/(tag+'.stderr.log')).open('wb') as se:
        child=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=child.pid;save('live.json',row);row['exit']=child.wait(timeout=55)
    if source:
        row['source_after']=ident(source);assert row['source_before']==row['source_after']
    row.update(terminal=True,finished=time.time(),outputs=[ident(x) for x in outputs if Path(x).is_file()])
    save(tag+'.result.json',row);save('live.json',row)
    print(json.dumps(dict(tag=tag,exit=row['exit'],outputs=row['outputs'])))
    print((LOG/(tag+'.stdout.log')).read_text(errors='replace')[-14000:])
    print((LOG/(tag+'.stderr.log')).read_text(errors='replace')[-10000:])
    return row['exit']
if __name__=='__main__':
    action=sys.argv[1]
    if action=='compile-test':status=call(sys.argv[2] if len(sys.argv)>2 else '001-test-v1-compile',PLAN['compile_test'],source=TEST,outputs=[OUT/'native-row-scorer-test.obj'])
    elif action=='old-link':
        for row in BASE['objects']+BASE['libraries']:
            if 'path' in row:assert ident(row['path'])==row,row
        status=call('004-old-link',PLAN['old_link'],outputs=[OUT/'old-scorer-tests.exe',OUT/'old-scorer-tests.map',OUT/'old-scorer-tests.lib',OUT/'old-scorer-tests.exp'])
    elif action=='old-run':status=call('005-old-run',[OUT/'old-scorer-tests.exe','--gtest_filter=NativePagedRowIndexer.*','--gtest_color=no','--gtest_output=json:'+str(LOG/'005-old-tests.json')],outputs=[LOG/'005-old-tests.json'])
    else:raise ValueError(action)
    raise SystemExit(status)
