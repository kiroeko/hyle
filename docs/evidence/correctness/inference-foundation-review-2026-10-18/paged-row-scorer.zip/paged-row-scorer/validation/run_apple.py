from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3]
BASE=OUT.parents[1]/'apple-source-preflight/validation'
spec=importlib.util.spec_from_file_location('last_air',BASE/'run.py')
last=importlib.util.module_from_spec(spec);spec.loader.exec_module(last)
prior=last.prior;prior.OUT=OUT/'apple'
REMOTE=last.AIR_BASE+'/paged-row-scorer/validation';prior.REMOTE=REMOTE
TEST='tests/graph_batch/native_row_cache_indexer_test.cc'
plan=json.loads((OUT/'apple/command-plan.json').read_text())
def save(name,value):prior.save(name,value)
def compile_current(tag,source):
    recipes=json.loads((OUT/'apple/recipes.json').read_text())
    argv=plan['compile_test'].copy() if source==TEST else recipes[source]['argv'].copy()
    argv[argv.index('-c')+1]=REMOTE+'/'+source
    obj=REMOTE+'/'+tag+'.o';argv[argv.index('-o')+1]=obj
    if '-MF' in argv:
        i=argv.index('-MF');del argv[i:i+2]
    argv=[x for x in argv if x!='-MMD']
    argv[1:1]=['-I'+REMOTE+'/include','-I'+REMOTE,'-I'+REMOTE+'/src/graph',
               '-I'+REMOTE+'/src/compute','-I'+REMOTE+'/src/compute_route_apple','-I'+REMOTE+'/src/graph_route_apple']
    argv+=['-MMD','-MF',obj+'.d']
    status=prior.call(tag,argv,source=REMOTE+'/'+source,dependency=obj+'.d',outputs=[obj,obj+'.d'])
    if status==0:
        rows=json.loads((OUT/'apple/objects-current.json').read_text()) if (OUT/'apple/objects-current.json').exists() else {}
        rows[source]=obj;save('objects-current.json',rows)
    return status
if __name__=='__main__':
    action=sys.argv[1];status=0
    if action=='sync-test':prior.sync(sys.argv[2] if len(sys.argv)>2 else '001-test-v1-source',[TEST])
    elif action=='compile-test':
        obj=plan['compile_test'][plan['compile_test'].index('-o')+1]
        status=prior.call(sys.argv[2] if len(sys.argv)>2 else '002-test-v1-compile',plan['compile_test'],source=REMOTE+'/'+TEST,dependency=obj+'.d',outputs=[obj,obj+'.d'])
    elif action=='old-link':
        math=json.loads((OUT/'apple/summary.json').read_text())['math'][0]['path']
        code='from pathlib import Path;r=Path('+repr(REMOTE)+');p=r/"mlx.metallib";t=Path('+repr(math)+');assert t.is_file();assert not p.exists() or p.resolve()==t.resolve();p.symlink_to(t) if not p.exists() else None'
        result=prior.air.ssh(code,timeout=30);assert result.returncode==0,result.stderr
        image=REMOTE+'/old-scorer-tests';status=prior.call('007-old-link',plan['old_link'],map=image+'.map',outputs=[image,image+'.map'])
    elif action=='old-run':
        result=REMOTE+'/008-old-tests.json'
        status=prior.call('008-old-run',[REMOTE+'/old-scorer-tests','--gtest_filter=NativePagedRowIndexer.*','--gtest_output=json:'+result],outputs=[result])
    elif action=='sync-current':
        rows=json.loads((OUT.parents[1]/'paged-row-scorer-apple/source-identities.json').read_text())
        for row in rows:assert prior.identify(ROOT/row['path'])==row,row
        prior.sync('009-current-source',[TEST,'tests/graph_batch/native_row_cache_indexer_pending.inc',*[row['path'] for row in rows]])
    elif action=='compile-products':
        for tag,source in [('010-indexer','src/compute_route_apple/apple_row_cache_indexer.cc'),
                           ('011-mature','src/compute_route_apple/apple_mature_float.cc'),
                           ('012-region','src/graph_route_apple/native_region.cc')]:
            status=compile_current(tag,source)
            if status:break
    elif action=='compile-current-test':status=compile_current(sys.argv[2] if len(sys.argv)>2 else '013-final-test',TEST)
    elif action=='sync-tests':prior.sync(sys.argv[2],[TEST,'tests/graph_batch/native_row_cache_indexer_pending.inc'])
    elif action=='sync-one':prior.sync(sys.argv[2],[sys.argv[3]])
    elif action=='compile-one':status=compile_current(sys.argv[2],sys.argv[3])
    elif action=='current-link':
        argv=json.loads((OUT/'apple/baseline-links.json').read_text())['gtest']['argv'].copy()
        owners=json.loads((OUT/'apple/baseline-objects.json').read_text())
        objects=json.loads((OUT/'apple/objects-current.json').read_text())
        argv.insert(1,objects[TEST])
        for source,obj in objects.items():
            if not source.startswith('src/'):continue
            old=owners[source];assert argv.count(old)==1;argv[argv.index(old)]=obj
        image=REMOTE+'/current-scorer-tests';argv[argv.index('-o')+1]=image
        argv=[('-Wl,-map,'+image+'.map') if x.startswith('-Wl,-map,') else x for x in argv]
        status=prior.call(sys.argv[2] if len(sys.argv)>2 else '014-current-link',argv,map=image+'.map',outputs=[image,image+'.map'])
    elif action=='current-run':
        tag=sys.argv[2] if len(sys.argv)>2 else '015-current-run';result=REMOTE+'/'+tag+'-tests.json'
        pattern=sys.argv[3] if len(sys.argv)>3 else 'NativePagedRowIndexer.*:AppleProjectedRowGraph.*:AppleRowCache.*:ApplePagedRowCache.*:AppleRowCacheIndexer.*'
        status=prior.call(tag,[REMOTE+'/current-scorer-tests',
            '--gtest_filter='+pattern,
            '--gtest_output=json:'+result],outputs=[result])
    elif action=='old-final-link':
        argv=plan['old_link'].copy();old=REMOTE+'/native-row-scorer-test.o'
        test=json.loads((OUT/'apple/objects-current.json').read_text())[TEST]
        assert argv.count(old)==1;argv[argv.index(old)]=test
        image=REMOTE+'/old-scorer-tests'
        status=prior.call('028-old-final-link',argv,map=image+'.map',outputs=[image,image+'.map'])
    elif action=='old-final-run':
        result=REMOTE+'/029-old-final-tests.json'
        status=prior.call('029-old-final-run',[REMOTE+'/old-scorer-tests','--gtest_filter=NativePagedRowIndexer.*',
            '--gtest_output=json:'+result],outputs=[result])
    elif action=='collect':prior.collect()
    else:raise ValueError(action)
    raise SystemExit(status)
