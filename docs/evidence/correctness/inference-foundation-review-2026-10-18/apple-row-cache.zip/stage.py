from pathlib import Path
import base64, hashlib, io, json, re, subprocess, sys, tarfile

REPO = Path.cwd()
OUT = REPO / '.scratch/inference-foundation-review-2026-10-18/apple-row-cache'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-foundation-review-20261018-apple-row-cache'

def ssh(code, payload=None):
    cmd = 'python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
    return subprocess.run(['ssh', 'kiro@172.22.10.198', cmd], input=payload, capture_output=True, timeout=60)

def stage():
    files = {'run_remote.py': OUT/'run_remote.py'}
    visited = set()
    def add(path):
        path = path.resolve()
        if path in visited:
            return
        visited.add(path)
        if path.is_relative_to(REPO) and '.scratch' not in path.relative_to(REPO).parts:
            files[path.relative_to(REPO).as_posix()] = path
        for name in re.findall(r'^\s*#\s*include\s*"([^\"]+)"', path.read_text(encoding='utf-8-sig'), re.M):
            for candidate in [path.parent/name, REPO/name, REPO/'include'/name,
                              REPO/'src/compute_route_apple'/name, REPO/'src/compute'/name]:
                if candidate.is_file():
                    add(candidate)
                    break
    for name in ['src/compute_route_apple/apple_row_cache.cc', 'src/compute_route_apple/apple_mature_float.cc',
                 'src/compute_ops/low_precision.cc', 'tests/compute_route_apple/row_cache_test.cc']:
        add(REPO/name)
    (OUT/'staged-sources.json').write_text(json.dumps([
        dict(path=name, bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        for name, path in sorted(files.items())], indent=2)+'\n')
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name)
    (OUT/'minimal-sources.tar.gz').write_bytes(buffer.getvalue())
    code = 'from pathlib import Path;import tarfile,io,sys;r=Path('+repr(REMOTE)+');assert not r.exists();r.mkdir();t=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in t.getmembers());t.extractall(r);print(r)'
    result = ssh(code, buffer.getvalue())
    (OUT/'stage.stdout.log').write_bytes(result.stdout)
    (OUT/'stage.stderr.log').write_bytes(result.stderr)
    print(result.returncode, len(files), len(buffer.getvalue()), result.stdout.decode(), result.stderr.decode())
    result.check_returncode()

def action(name):
    result = subprocess.run(['ssh', 'kiro@172.22.10.198', 'cd '+REMOTE+' && python3 run_remote.py '+name],
                            capture_output=True, timeout=300)
    (OUT/(name+'.stdout.log')).write_bytes(result.stdout)
    (OUT/(name+'.stderr.log')).write_bytes(result.stderr)
    print(result.returncode, result.stdout.decode(errors='replace')[-15000:], result.stderr.decode(errors='replace')[-3000:])
    result.check_returncode()

def collect():
    code = 'from pathlib import Path;import tarfile,io,sys;r=Path('+repr(REMOTE)+');b=io.BytesIO();t=tarfile.open(fileobj=b,mode="w:gz");[t.add(p,arcname=p.name)for p in r.iterdir()if p.is_file()and p.suffix in [".json",".log",".txt"]];t.close();sys.stdout.buffer.write(b.getvalue())'
    result = ssh(code)
    result.check_returncode()
    (OUT/'remote-results.tar.gz').write_bytes(result.stdout)
    with tarfile.open(fileobj=io.BytesIO(result.stdout), mode='r:gz') as archive:
        assert all(m.isfile() and len(Path(m.name).parts) == 1 for m in archive.getmembers())
        archive.extractall(OUT)
    print('collected', len(result.stdout))

if __name__ == '__main__':
    {'stage': stage, 'build': lambda: action('build'), 'link': lambda: action('link'), 'test': lambda: action('test'), 'collect': collect}[sys.argv[1]]()
