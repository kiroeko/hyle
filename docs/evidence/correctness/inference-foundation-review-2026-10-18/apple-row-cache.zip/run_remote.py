from pathlib import Path
import hashlib, json, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'inference-foundation-review-20261018-apple-prepare-scale-view'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
previous = json.loads((OLD / 'commands.json').read_text())
base_compile = next(x['command'] for x in previous if x['tag'] == 'mature.o-compile')
base_link = next(x['command'] for x in previous if x['tag'] == 'canonical-link')
records = json.loads((ROOT / 'commands.json').read_text()) if (ROOT / 'commands.json').exists() else []

def identity(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def run(tag, command):
    command = list(map(str, command))
    stem = f'{len(records)+1:02d}-{tag}'
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=180)
    (ROOT / (stem + '.stdout.log')).write_bytes(result.stdout)
    (ROOT / (stem + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag, command=command, cwd=str(ROOT), exit=result.returncode,
                        seconds=time.monotonic()-start,
                        stdout=stem+'.stdout.log', stderr=stem+'.stderr.log'))
    (ROOT / 'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(stem, result.returncode, flush=True)
    print(result.stdout.decode(errors='replace')[-5000:] + result.stderr.decode(errors='replace')[-6000:], flush=True)
    if result.returncode:
        raise SystemExit(1)

def build():
    assert subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True).strip() == 'Mac16,12'
    machine = subprocess.check_output(['sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'], text=True)
    machine += subprocess.check_output(['xcrun', 'clang++', '--version'], text=True)
    (ROOT / 'machine.txt').write_text(machine)
    if not (ROOT / 'mlx.metallib').exists():
        (ROOT / 'mlx.metallib').symlink_to(SDK / 'lib/mlx.metallib')
    assert (ROOT / 'mlx.metallib').resolve() == (SDK / 'lib/mlx.metallib').resolve()
    prefix = base_compile[:base_compile.index('-c')]
    prefix[1:1] = ['-I'+str(ROOT/'include'), '-I'+str(ROOT),
                   '-I'+str(ROOT/'src/compute_route_apple'), '-I'+str(ROOT/'src/compute')]
    for source, obj in [('src/compute_route_apple/apple_row_cache.cc', 'row-cache.o'),
                        ('src/compute_route_apple/apple_mature_float.cc', 'mature.o'),
                        ('src/compute_ops/low_precision.cc', 'low-precision.o'),
                        ('tests/compute_route_apple/row_cache_test.cc', 'test.o')]:
        run(obj+'-compile', prefix+['-c', ROOT/source, '-o', ROOT/obj])
    link()

def link():
    command = []
    for item in base_link:
        if item == str(OLD/'canonical'):
            command.append(str(ROOT/'row-cache-test'))
        elif item == str(OLD/'canonical.o'):
            command.append(str(ROOT/'test.o'))
        elif item == str(OLD/'mature.o'):
            command.extend([str(ROOT/'mature.o'), str(ROOT/'row-cache.o')])
        elif item.endswith('/ops-low_precision.cc.o'):
            command.append(str(ROOT/'low-precision.o'))
        elif item.startswith('-Wl,-map,'):
            command.append('-Wl,-map,'+str(ROOT/'tests.map'))
        else:
            command.append(item)
    run('tests-link', command)
    identities = [identity(x) for x in command if x.endswith(('.o', '.a', '.dylib'))]
    identities.append(identity(ROOT/'row-cache-test'))
    (ROOT/'identities.json').write_text(json.dumps(identities, indent=2)+'\n')

def test():
    run('tests', [ROOT/'row-cache-test', '--gtest_filter=AppleRowCache.*'])

if __name__ == '__main__':
    {'build': build, 'link': link, 'test': test}[sys.argv[1]]()
