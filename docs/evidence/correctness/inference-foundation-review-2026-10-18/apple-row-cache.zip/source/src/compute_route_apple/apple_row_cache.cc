#include "apple_row_cache.h"

#include <array>
#include <cstdint>

#include <mlx/ops.h>

#include "apple_checks.h"

namespace hyle::compute::apple::detail {
namespace mx = mlx::core;
namespace {
mx::array u(std::uint32_t value) { return mx::array(value); }

// BF16 max is ordered by its unsigned magnitude bits. Comparing the short
// significand against 448/2 or 6*32 computes ceil(log2(max/code_max)) exactly,
// including the original scale floors, without subnormal floating arithmetic.
mx::array scale_exponents(const mx::array &magnitude, bool four, mx::Stream s) {
  auto maximum = mx::max(magnitude, -1, true, s);
  auto exponent = mx::astype(mx::right_shift(maximum, u(7), s), mx::int32, s);
  auto significand = mx::bitwise_or(mx::bitwise_and(maximum, u(127), s), u(128), s);
  auto increment = mx::astype(mx::greater(significand, u(four ? 192 : 224), s), mx::int32, s);
  auto result = mx::maximum(mx::add(mx::subtract(exponent, mx::array(four ? 2 : 8), s),
      increment, s), mx::array(four ? 1 : 105), s);
  return mx::astype(result, mx::uint32, s);
}

mx::array quantized_codes(const mx::array &bits, const mx::array &magnitude,
                         const mx::array &exponent, bool four, mx::Stream s) {
  auto scale = mx::view(mx::left_shift(exponent, u(23), s), mx::float32, s);
  auto value = mx::view(mx::left_shift(magnitude, u(16), s), mx::float32, s);
  auto normalized = mx::divide(value, scale, s);
  mx::array codes = mx::zeros(bits.shape(), mx::uint32, s);
  if (four) {
    // Metal may flush BF16 subnormal values after conversion to F32. In the
    // only affected scale domain, exact integer significands stay small.
    auto source_exp = mx::right_shift(magnitude, u(7), s);
    auto significand = mx::bitwise_or(mx::bitwise_and(magnitude, u(127), s),
        mx::where(mx::equal(source_exp, u(0), s), u(0), u(128), s), s);
    auto shift = mx::subtract(mx::minimum(mx::maximum(source_exp, u(1), s), u(4), s), u(1), s);
    auto low = mx::multiply(mx::astype(mx::left_shift(significand, shift, s), mx::float32, s),
        mx::where(mx::equal(exponent, u(1), s), mx::array(1.F / 128),
            mx::array(1.F / 256), s), s);
    normalized = mx::minimum(mx::where(mx::less_equal(exponent, u(2), s),
        low, normalized, s), mx::array(6.F), s);
    constexpr std::array<float, 8> values{0, .5F, 1, 1.5F, 2, 3, 4, 6};
    auto distance = normalized;
    for (std::uint32_t code = 1; code < values.size(); ++code) {
      auto difference = mx::abs(mx::subtract(normalized, mx::array(values[code]), s), s);
      auto choose = mx::less(difference, distance, s);
      if ((code & 1) == 0)
        choose = mx::logical_or(choose, mx::logical_and(mx::equal(difference, distance, s),
            mx::not_equal(mx::bitwise_and(codes, u(1), s), u(0), s), s), s);
      codes = mx::where(choose, u(code), codes, s);
      distance = mx::where(choose, difference, distance, s);
    }
  } else {
    // The locked native converter uses saturated nearest-even E4M3FN.
    codes = mx::astype(mx::to_fp8(mx::minimum(normalized, mx::array(448.F), s), s), mx::uint32, s);
  }
  auto sign = mx::right_shift(mx::bitwise_and(bits, u(0x8000), s), u(four ? 12 : 8), s);
  return mx::astype(mx::bitwise_or(codes, sign, s), mx::uint8, s);
}

// All nonzero code magnitudes are normal F32 and exactly BF16-representable.
// Apply the UE8 exponent and RNE in integers so UE8=0 and small BF16 outputs
// never pass through Metal's floating subnormal/FTZ path.
mx::array decoded_bits(const mx::array &codes, const mx::array &exponents,
                       bool four, mx::Stream s) {
  const auto raw = mx::astype(codes, mx::uint32, s);
  auto magnitude = mx::bitwise_and(raw, u(four ? 7 : 127), s);
  mx::array value = mx::zeros(codes.shape(), mx::float32, s);
  if (four) {
    constexpr std::array<float, 8> values{0, .5F, 1, 1.5F, 2, 3, 4, 6};
    value = mx::take(mx::array(values.data(), {8}, mx::float32), magnitude, 0, s);
  } else {
    value = mx::from_fp8(mx::astype(magnitude, mx::uint8, s), mx::float32, s);
  }
  auto bits = mx::view(value, mx::uint32, s);
  auto exponent = mx::subtract(mx::add(
      mx::astype(mx::right_shift(bits, u(23), s), mx::int32, s),
      mx::astype(exponents, mx::int32, s), s), mx::array(127), s);
  auto normal_exp = mx::astype(mx::clip(exponent, mx::array(1), mx::array(254), s), mx::uint32, s);
  auto normal = mx::bitwise_or(mx::left_shift(normal_exp, u(7), s),
      mx::bitwise_and(mx::right_shift(bits, u(16), s), u(127), s), s);
  auto significand = mx::bitwise_or(mx::bitwise_and(bits, u(0x7fffff), s), u(0x800000), s);
  // Both where branches may be evaluated: every shift must remain defined.
  auto shift = mx::astype(mx::clip(mx::subtract(mx::array(17), exponent, s),
      mx::array(1), mx::array(31), s), mx::uint32, s);
  auto base = mx::right_shift(significand, shift, s);
  auto halfway = mx::left_shift(u(1), mx::subtract(shift, u(1), s), s);
  auto remainder = mx::bitwise_and(significand,
      mx::subtract(mx::left_shift(u(1), shift, s), u(1), s), s);
  auto increment = mx::logical_or(mx::greater(remainder, halfway, s),
      mx::logical_and(mx::equal(remainder, halfway, s),
          mx::not_equal(mx::bitwise_and(base, u(1), s), u(0), s), s), s);
  auto subnormal = mx::add(base, mx::astype(increment, mx::uint32, s), s);
  auto result = mx::where(mx::less_equal(exponent, mx::array(0), s), subnormal, normal, s);
  result = mx::where(mx::greater_equal(exponent, mx::array(255), s), u(0x7f80), result, s);
  result = mx::where(mx::equal(magnitude, u(0), s), u(0), result, s);
  auto sign = mx::left_shift(mx::bitwise_and(raw, u(four ? 8 : 128), s), u(four ? 12 : 8), s);
  result = mx::bitwise_or(result, sign, s);
  auto invalid = mx::equal(exponents, u(255), s);
  if (!four)
    invalid = mx::logical_or(invalid, mx::equal(magnitude, u(127), s), s);
  return mx::astype(mx::where(invalid, u(0x7fc0), result, s), mx::uint16, s);
}
} // namespace

Result<mx::array> encode_row_cache(RowCacheEncoding encoding,
                                  const mx::array &input, mx::Stream s) {
  const bool four = encoding.format() == RowCacheFormat::kFloat4Block32;
  const int rows = input.shape(0), width = static_cast<int>(encoding.row_bytes());
  if (rows == 0) return mx::zeros({0, width}, mx::uint8, s);
  const int channels = four ? 128 : 448, group = four ? 32 : 64;
  auto raw = mx::astype(mx::view(input, mx::uint16, s), mx::uint32, s);
  auto finite = mx::not_equal(mx::bitwise_and(raw, u(0x7f80), s), u(0x7f80), s);
  auto safe = mx::where(finite, raw, u(0), s);
  auto bits = mx::reshape(mx::slice(safe, {0, 0}, {rows, channels}, s),
      {rows, channels / group, group}, s);
  auto magnitude = mx::bitwise_and(bits, u(0x7fff), s);
  auto exponents = scale_exponents(magnitude, four, s);
  auto codes = quantized_codes(bits, magnitude, exponents, four, s);
  mx::array payload = mx::reshape(codes, {rows, channels}, s);
  if (four) {
    auto pairs = mx::reshape(payload, {rows, 64, 2}, s);
    auto low = mx::reshape(mx::slice(pairs, {0, 0, 0}, {rows, 64, 1}, s), {rows, 64}, s);
    auto high = mx::reshape(mx::slice(pairs, {0, 0, 1}, {rows, 64, 2}, s), {rows, 64}, s);
    payload = mx::bitwise_or(low, mx::left_shift(high, mx::array(std::uint8_t{4}), s), s);
  }
  auto scales = mx::astype(mx::reshape(exponents, {rows, channels / group}, s), mx::uint8, s);
  mx::array packed = four ? mx::concatenate({payload, scales}, -1, s)
      : mx::concatenate({payload,
          mx::view(mx::slice(input, {0, 448}, {rows, 512}, s), mx::uint8, s),
          scales, mx::zeros({rows, 1}, mx::uint8, s)}, -1, s);
  auto status = mx::where(mx::all(finite, false, s), mx::array(0),
      mx::array(kInvalidNumericInput), s);
  return with_device_status(std::move(packed), std::move(status), s);
}

Result<mx::array> gather_decode_row_cache(
    const model_ops::RowCacheGatherDecode &operation, const mx::array &bank,
    const mx::array &indices, mx::Stream s) {
  const auto encoding = operation.encoding;
  const bool four = encoding.format() == RowCacheFormat::kFloat4Block32;
  auto output_shape = indices.shape();
  output_shape.push_back(static_cast<int>(encoding.depth()));
  if (indices.size() == 0) return mx::zeros(output_shape, mx::bfloat16, s);
  const int count = static_cast<int>(indices.size());
  auto ids = mx::reshape(indices, {count}, s);
  auto invalid = mx::logical_or(mx::less(ids, mx::array(0), s),
      mx::greater_equal(ids, mx::array(bank.shape(0)), s), s);
  // A checked failure still uses safe addresses while its private status is
  // evaluated. Only the requested encoded rows are gathered or decoded.
  if (operation.bounds == IndexBoundsPolicy::kChecked)
    ids = mx::where(invalid, mx::array(0), ids, s);
  auto selected = mx::take(bank, ids, 0, s);
  const int channels = four ? 128 : 448, group = four ? 32 : 64;
  auto payload = mx::slice(selected, {0, 0}, {count, four ? 64 : 448}, s);
  mx::array codes = mx::reshape(payload, {count, channels / group, four ? 16 : 64}, s);
  if (four) {
    auto low = mx::bitwise_and(codes, mx::array(std::uint8_t{7 | 8}), s);
    auto high = mx::right_shift(codes, mx::array(std::uint8_t{4}), s);
    codes = mx::reshape(mx::stack({low, high}, -1, s), {count, 4, 32}, s);
  }
  auto scales = mx::astype(mx::reshape(mx::slice(selected, {0, four ? 64 : 576},
      {count, four ? 68 : 583}, s), {count, channels / group, 1}, s), mx::uint32, s);
  auto bits = mx::reshape(decoded_bits(codes, scales, four, s), {count, channels}, s);
  if (!four) {
    // Byte loads retain the public U8 bank's valid odd byte origins.
    auto tail = mx::reshape(mx::slice(selected, {0, 448}, {count, 576}, s), {count, 64, 2}, s);
    auto low = mx::astype(mx::reshape(mx::slice(tail, {0, 0, 0}, {count, 64, 1}, s),
        {count, 64}, s), mx::uint16, s);
    auto high = mx::astype(mx::reshape(mx::slice(tail, {0, 0, 1}, {count, 64, 2}, s),
        {count, 64}, s), mx::uint16, s);
    bits = mx::concatenate({bits, mx::bitwise_or(low,
        mx::left_shift(high, mx::array(std::uint16_t{8}), s), s)}, -1, s);
  }
  auto result = mx::view(mx::reshape(bits, output_shape, s), mx::bfloat16, s);
  if (operation.bounds == IndexBoundsPolicy::kUnchecked) return result;
  auto status = mx::where(mx::any(invalid, s), mx::array(kIndexOutOfRange), mx::array(0), s);
  return with_device_status(std::move(result), std::move(status), s);
}
} // namespace hyle::compute::apple::detail
