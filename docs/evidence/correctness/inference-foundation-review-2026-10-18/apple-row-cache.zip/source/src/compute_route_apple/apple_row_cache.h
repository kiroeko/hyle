#pragma once

#include "hyle/compute/apple.h"
#include "hyle/compute/model_ops.h"

namespace hyle::compute::apple::detail {
Result<mlx::core::array> encode_row_cache(
    RowCacheEncoding encoding, const mlx::core::array &input,
    mlx::core::Stream stream);
Result<mlx::core::array> gather_decode_row_cache(
    const model_ops::RowCacheGatherDecode &operation,
    const mlx::core::array &bank, const mlx::core::array &indices,
    mlx::core::Stream stream);
} // namespace hyle::compute::apple::detail
