"""Four explicit CPU owners and five exact tests; dry-run by default.

--build compiles/links only. --test compiles/links and runs the five cases.
No CMake, SDK build, dependency/object copy, deletion or GPU is performed.
"""
from pathlib import Path
import ctypes
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
PRIOR = ARCH / "cold-constant-retirement"
sys.path.insert(0, str(PRIOR))
import cold_check as check

BASE = PRIOR / "checks/20261019T051551-0faed8bc/plan.json"
CORE = PRIOR / "checks/20261019T051232-8e1188d0"
LAST = BASE.parent
SOURCES = ["src/graph/executable.cc", "src/compute/resource_budget.cc",
           "src/compute/resource_leases.cc", "tests/graph/region_provider_test.cc"]
TESTS = [
    "GraphRegions.UnknownMaterializationObservationRetainsOwnersUntilNativeRetirement",
    "GraphRegions.QueuedMaterializationRejectsRawSourceBeforeCopy",
    "GraphRegions.ConstantCopiesWaitForAcceptedFailuresWithoutRetryingThem",
    "GraphPacking.UnknownPreparationObservationRetainsOwnersUntilNativeRetirement",
    "CanonicalConstantCache.ReadyOwnersKeepExactResourcesAndDescriptions",
]


def split_windows(command):
    count = ctypes.c_int()
    parse = ctypes.windll.shell32.CommandLineToArgvW
    parse.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    parse.restype = ctypes.POINTER(ctypes.c_wchar_p)
    pointer = parse(command, ctypes.byref(count))
    if not pointer:
        raise OSError("CommandLineToArgvW failed")
    try:
        return [pointer[index] for index in range(count.value)]
    finally:
        release = ctypes.windll.kernel32.LocalFree
        release.argtypes = [ctypes.c_void_p]
        release.restype = ctypes.c_void_p
        release(pointer)


def prepare_recipes():
    latest = check.read(BASE)
    command = latest["link"]
    inputs = [check.snapshot(arg, True) for arg in command
              if not arg.startswith("/") and Path(arg).is_absolute()
              and Path(arg).suffix.lower() in (".obj", ".lib")]
    if len(inputs) != 149 or any(not row["exists"] for row in inputs):
        raise ValueError("Final CPU cached closure is incomplete")
    base = STAGE / "cpu-base-link.json"
    if not base.exists():
        check.save(base, {"command": command, "inputs": inputs,
                          "from_actual_final_plan": check.snapshot(BASE, True),
                          "old_executable_exists": (LAST / "cold-tests.exe").is_file()})
    elif check.read(base)["command"] != command:
        raise ValueError("Preserve the established final CPU baseline")
    # An actual static MSVC recipe exists for this exact source and component.
    # Add strict /WX; the generic helper supplies current sourceDependencies and
    # task-local output paths. No SDK or Vulkan source is compiled by this recipe.
    database = ROOT / ".scratch/bench-api-runtime/vulkan/build/compile_commands.json"
    row = next(item for item in check.read(database)
               if check.key(item["file"]) == check.key(ROOT / SOURCES[2]))
    argv = split_windows(row["command"])
    if "-DHYLE_STATIC" not in argv or "-MD" not in argv:
        raise ValueError("Expected the cached static /MD Compute recipe")
    if "/WX" not in argv:
        argv.append("/WX")
    lease_recipe = STAGE / "resource-leases-compile-recipe.json"
    if not lease_recipe.exists():
        check.save(lease_recipe, {"command": argv,
            "original_compile_database": check.snapshot(database, True),
            "original_entry": row, "compiled_by_this_task": False,
            "adaptation": "Exact source/static MSVC component recipe; add /WX and replace outputs/dependency report only."})
    check.STAGE = STAGE
    check.LINK_PLAN = base
    check.RECIPES = {
        SOURCES[0]: (str(CORE / "src--graph--executable-identity.json"), None,
                     str(CORE / "src--graph--executable.obj")),
        SOURCES[1]: (str(CORE / "src--compute--resource_budget-identity.json"), None,
                     str(CORE / "src--compute--resource_budget.obj")),
        SOURCES[2]: (str(lease_recipe), None, None),
        SOURCES[3]: (str(LAST / "tests--graph--region_provider_test-identity.json"), None,
                     str(LAST / "tests--graph--region_provider_test.obj")),
    }


def main():
    modes = sys.argv[1:]
    if len(modes) > 1 or any(value not in ("--dry-run", "--build", "--test") for value in modes):
        raise ValueError("Choose only --dry-run (default), --build or --test")
    prepare_recipes()
    sys.argv = [__file__]
    for source in SOURCES:
        sys.argv += ["--source", source]
    for name in TESTS:
        sys.argv += ["--target-test", name]
    sys.argv += modes or ["--dry-run"]
    check.main()


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, StopIteration) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
