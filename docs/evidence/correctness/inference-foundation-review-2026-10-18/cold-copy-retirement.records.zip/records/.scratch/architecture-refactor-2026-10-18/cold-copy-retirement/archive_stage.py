"""Run only after final summary/proofs freeze; archive, verify, then write test.ps1.

summary.json supplies proofs:{CPU:path,CUDA:path,Qwen:path} and source_files.
This script never deletes files or runs builds/tests. Root reviews/runs test.ps1.
"""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ARCHIVE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/cold-copy-retirement.zip'
IMAGES = {'.exe', '.map', '.lib', '.exp'}
TEXT = {'.json', '.log', '.txt', '.py', '.ps1', '.cmd', '.rsp', '.h', '.cc', '.cpp', '.mm', '.md', '.diff', '.xml', '.tsv', '.csv'}
ALLOWED = TEXT | {'.bf16', '.f32', '.nsys-rep', '.sqlite'}
EXCLUDED = {'tmp', 'sdk', '_deps', 'objects', '__pycache__'}

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def digest(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
        value.update(block)
    return value.hexdigest()

def identity(path):
    with path.open('rb') as stream:
        return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(stream)}

def local(value, base):
    path = (base / value).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        raise ValueError(f'Missing/outside repository: {path}')
    return path

def main():
    summary = read(STAGE / 'summary.json')
    proofs = {name: local(summary['proofs'][name], STAGE) for name in ('CPU', 'CUDA', 'Qwen')}
    cpu, cuda, qwen = (read(proofs[name]) for name in ('CPU', 'CUDA', 'Qwen'))
    for proof in (cpu, cuda):
        if len(set(proof['cases'])) != 5 or len(proof['cases']) != 5 or proof['failures'] != 0 or proof.get('skipped', 0) != 0:
            raise ValueError('Final CPU/CUDA proof must contain five passed, unskipped cases')
    if qwen['equal_vectors'] != 64 or qwen['equal_token_ids'] != 32 or not qwen['capture_counts_equal']:
        raise ValueError('Final Qwen proof is incomplete or failed')
    sources = [local(name, ROOT) for name in summary['source_files']]
    if not sources or len(set(sources)) != len(sources):
        raise ValueError('Source list is empty or duplicated')
    for path in sources:
        if path.suffix.lower() not in TEXT:
            raise ValueError(f'Not a text source: {path}')
        path.read_text(encoding='utf-8-sig')
    frozen = [identity(path) for path in sources]
    freeze = STAGE / 'source-freeze.json'
    if freeze.exists() and read(freeze) != frozen:
        raise ValueError('Frozen source identity drifted')
    save(freeze, frozen)
    targets = [identity(path.resolve()) for path in sorted(STAGE.rglob('*'))
               if path.is_file() and path.suffix.lower() in IMAGES
               and path.resolve().is_relative_to(STAGE)
               and not EXCLUDED.intersection(part.lower() for part in path.relative_to(STAGE).parts)]
    save(STAGE / 'reclaim-targets.json', targets)
    script = r'''param([switch]$ReclaimColdCopyRetirement)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimColdCopyRetirement) { throw 'Use -ReclaimColdCopyRetirement for reviewed exact targets.' }
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch/architecture-refactor-2026-10-18/cold-copy-retirement'))
$receipt = Join-Path $taskRoot 'reclaim-receipt.json'
if (Test-Path -LiteralPath $receipt) { throw 'Reclaim already recorded.' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'archive-verification.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $proof.path -Algorithm SHA256).Hash -ne $proof.sha256) { throw 'Archive changed.' }
if ((Get-FileHash -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Algorithm SHA256).Hash -ne $proof.reclaim_manifest.sha256) { throw 'Reclaim plan changed.' }
$targets = @(Get-Content -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe','.map','.lib','.exp') -or $item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path }
@{targets=$targets;archive=$proof;recursive=$false;objects_retained=$true;raw_trace_retained=$true} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receipt -Encoding utf8
'''
    (STAGE / 'reclaim-script.ps1').write_text(script, encoding='utf-8-sig')
    payload = {}
    for directory in {STAGE, *(path.parent for path in proofs.values())}:
        if directory != STAGE and directory in STAGE.parents:
            raise ValueError('A proof directory would include unrelated stages')
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix.lower() in ALLOWED and path.name != 'archive-verification.json' and not EXCLUDED.intersection(part.lower() for part in path.relative_to(directory).parts):
                path = local(str(path), ROOT)
                payload[path.relative_to(ROOT).as_posix()] = path
    payload.update({'source-current/' + path.relative_to(ROOT).as_posix(): path for path in sources})
    records = {name: identity(path) for name, path in sorted(payload.items())}
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(payload.items()):
            archive.write(path, name)
        archive.writestr('_manifest.json', json.dumps(records, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC verification failed')
        for name, row in records.items():
            with archive.open(name) as stream:
                if archive.getinfo(name).file_size != row['bytes'] or digest(stream) != row['sha256']:
                    raise ValueError(f'ZIP payload verification failed: {name}')
    if [identity(path) for path in sources] != frozen:
        raise ValueError('Source changed while archiving')
    proof = dict(identity(ARCHIVE), payload_files=len(records), CRC_and_SHA256_verified=True,
                 reclaim_manifest=identity(STAGE / 'reclaim-targets.json'))
    save(STAGE / 'archive-verification.json', proof)
    (ROOT / 'test.ps1').write_text(script, encoding='utf-8-sig')
    print(json.dumps({'archive': proof, 'reclaim_files': len(targets), 'reclaim_bytes': sum(row['bytes'] for row in targets)}, indent=2))

if __name__ == '__main__':
    main()
