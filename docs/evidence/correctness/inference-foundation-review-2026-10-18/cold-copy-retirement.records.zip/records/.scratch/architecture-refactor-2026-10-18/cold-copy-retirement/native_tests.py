"""Five exact native cold-packing cases, with retained cached CUDA kernels."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cold_native_build', OUT.parent / 'cuda-bf16-chain-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
image = Path(sys.argv[1]).resolve()
receipt = b.read(image.parent / 'cuda-tests-image.json')['image']
assert b.ident(image)['sha256'] == receipt['sha256']
cases = [
    'GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs',
    'GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable',
    'GgmlCudaGraph.SingleBfloatExpertConstantPacksOnceAndDynamicWeightRemainsRebindable',
    'CudaDefaultGraph.ImmutableBfloatCastFeedsOriginalGemmRoute',
    'CudaDefaultGraph.PreparedCastKeepsIncomingControlForDataOnlyConsumer']
xml = OUT / 'native-packing.xml'
b.execute('native-packing', [image, '--gtest_color=no', '--gtest_filter=' + ':'.join(cases),
                             '--gtest_output=xml:' + str(xml)])
root = ET.parse(xml).getroot()
actual = [item.attrib['classname'] + '.' + item.attrib['name'] for item in root.findall('.//testcase')]
assert sorted(actual) == sorted(cases)
assert not root.findall('.//failure') and not root.findall('.//skipped')
b.save('native-packing-summary.json', {'cases': actual, 'failures': 0, 'skipped': 0,
    'image_sha256': receipt['sha256'], 'SDK_rebuild': False, 'native_kernel_rebuild': False,
    'limits': 'Real CUDA successful packing; unknown-retirement failure is covered by the CPU mock.'})
