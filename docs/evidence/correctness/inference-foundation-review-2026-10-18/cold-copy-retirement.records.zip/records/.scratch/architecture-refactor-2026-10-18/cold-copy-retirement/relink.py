"""Plan or execute two cached CUDA links. No compiler, SDK build or GPU run.

Requires the final five-case CPU proof. Replace only executable/resource_budget
objects and add resource_leases; reuse every other object/library in place.
"""
from pathlib import Path
import argparse
import datetime as dt
import sys
import uuid

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
PRIOR = ARCH / "cold-constant-retirement"
sys.path.insert(0, str(PRIOR))
import cold_check as c

CPU = STAGE / "checks/20261019T053001-df70e294"
OLD_CORE = PRIOR / "checks/20261019T051232-8e1188d0"
BASES = {
    "qwen": PRIOR / "cuda-checks/20261019T051553-817e50eb/candidate-link-plan.json",
    "cuda-tests": PRIOR / "cuda-test-checks/20261019T051728-35c9113e/fusion-tests-link-plan.json",
}
EXPECTED_TESTS = {
    "GraphRegions.UnknownMaterializationObservationRetainsOwnersUntilNativeRetirement",
    "GraphRegions.QueuedMaterializationRejectsRawSourceBeforeCopy",
    "GraphRegions.ConstantCopiesWaitForAcceptedFailuresWithoutRetryingThem",
    "GraphPacking.UnknownPreparationObservationRetainsOwnersUntilNativeRetirement",
    "CanonicalConstantCache.ReadyOwnersKeepExactResourcesAndDescriptions",
}


def identity(path):
    row = c.snapshot(path, True)
    return {name: row[name] for name in ("path", "bytes", "sha256")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--plan", action="store_true", help="Write link plans only (default)")
    mode.add_argument("--build", action="store_true", help="Execute the two links only")
    parser.add_argument("--cpu-check", default=str(CPU))
    args = parser.parse_args()
    cpu = Path(args.cpu_check).resolve()
    proof_path = cpu / "tests-summary.json"
    if not proof_path.is_file():
        raise ValueError("Final CPU tests-summary.json is not available yet")
    proof = c.read(proof_path)
    if set(proof["cases"]) != EXPECTED_TESTS or proof["failures"] or proof["skipped"]:
        raise ValueError("The five exact CPU tests have not all passed")
    owners = {}
    for stem in ("src--graph--executable", "src--compute--resource_budget", "src--compute--resource_leases"):
        receipt = cpu / (stem + "-identity.json")
        row = c.read(receipt)
        for part in ("source", "object"):
            if identity(row[part]["path"])["sha256"] != row[part]["sha256"]:
                raise ValueError("Final CPU " + part + " drift: " + row[part]["path"])
        owners[stem] = {"receipt": identity(receipt), "source": identity(row["source"]["path"]),
                        "object": identity(row["object"]["path"])}
    session = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    out = STAGE / "relinks" / session
    out.mkdir(parents=True, exist_ok=False)
    replacements = {c.key(OLD_CORE / (stem + ".obj")): row["object"]["path"]
                    for stem, row in owners.items() if stem != "src--compute--resource_leases"}
    added = owners["src--compute--resource_leases"]["object"]["path"]
    plans = {}
    for name, base in BASES.items():
        original = c.read(base)
        if len(original["inputs"]) != (120 if name == "qwen" else 123):
            raise ValueError("Unexpected retained CUDA baseline closure: " + name)
        for old in replacements:
            if sum(not arg.startswith("/") and c.key(arg) == old for arg in original["command"]) != 1:
                raise ValueError("Expected exactly one old owner in " + name + ": " + old)
        if any(Path(arg).name.lower().endswith("resource_leases.obj") for arg in original["command"]):
            raise ValueError("The lease source already has an explicit owner in " + name)
        rows = []
        for row in original["inputs"]:
            if c.key(row["path"]) in replacements:
                continue
            actual = identity(row["path"])
            if actual["sha256"] != row["sha256"]:
                raise ValueError("Retained CUDA input drift: " + row["path"])
            rows.append(actual)
        command = [replacements.get(c.key(arg), arg) if not arg.startswith("/") else arg
                   for arg in original["command"]
                   if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
        image = out / ("candidate.exe" if name == "qwen" else "fusion-tests.exe")
        command += [added, "/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                    "/IMPLIB:" + str(image.with_suffix(".lib"))]
        inputs = [identity(arg) for arg in command if not arg.startswith("/")
                  and Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj", ".lib")]
        if len(inputs) != len(original["inputs"]) + 1:
            raise ValueError("Unexpected relink input count")
        env, runtime = c.environment(command, [row["path"] for row in inputs], out)
        sdk = c.sdk_libraries(command, env)
        if any(row["resolved"] is None for row in sdk):
            raise ValueError("Named SDK library missing")
        plan = {"command": command, "inputs": inputs, "base_plan": identity(base),
            "CPU_proof": identity(proof_path), "fresh_owners": owners,
            "runtime_path_directories": runtime, "named_sdk_libraries": sdk,
            "compiler_run": False, "SDK_build": False, "GPU_run": False,
            "object_or_dependency_copy": False, "output_image_exists": image.is_file()}
        c.save(out / (name + "-link-plan.json"), plan)
        plans[name] = (plan, image, env)
    c.save(out / "plan-summary.json", {"mode": "build" if args.build else "plan",
        "CPU_proof": identity(proof_path), "closures": {
            name: {"plan": str(out / (name + "-link-plan.json")), "inputs": len(row[0]["inputs"])}
            for name, row in plans.items()}, "images_ready": False})
    print("PLAN", str(out / "plan-summary.json"), flush=True)
    if not args.build:
        return
    (out / "tmp").mkdir()
    for name, (plan, image, env) in plans.items():
        # Recheck right before link. No compile or test process is launched.
        for row in plan["inputs"]:
            if identity(row["path"])["sha256"] != row["sha256"]:
                raise ValueError("Input changed after planning: " + row["path"])
        c.execute(name + "-link", plan["command"], env, out)
        c.save(out / (name + "-image.json"), {"image": identity(image),
            "link_plan": identity(out / (name + "-link-plan.json"))})
        print("LINKED", name, str(image), flush=True)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
