"""One fixed real-model correctness run; no benchmark/profile/server/download."""
from pathlib import Path
import importlib.util
import hashlib
import json
import re
import shutil
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
spec = importlib.util.spec_from_file_location('cold_run_build', ARCH / 'cuda-bf16-chain-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
IMAGE = Path(sys.argv[1]).resolve()
receipt = b.read(IMAGE.parent / 'qwen-image.json')['image']
assert b.ident(IMAGE)['sha256'] == receipt['sha256']
prior = ARCH / 'cuda-reshape-reuse'
trace = OUT / 'qwen-owned/trace'
trace.parent.mkdir(exist_ok=False)
argv = b.read(prior / 'correctness-candidate.command.json')['command']
argv[0] = str(IMAGE)
argv[argv.index('--trace') + 1] = str(trace)
b.save('qwen-owned-inputs.json', {'image': receipt,
    'prior_image': b.read(prior / 'candidate-image.json')['image'],
    'comparison': 'one fixed128 prompt/31 decode;64 retained hidden/logit vectors',
    'benchmark': False, 'profiler': False, 'memory_monitor': False})
b.execute('hardware', [shutil.which('nvidia-smi'),
    '--query-gpu=name,driver_version,memory.total', '--format=csv,noheader'])
b.execute('qwen-owned', argv)
before = prior / 'correctness-candidate/trace'
paths = sorted(p.relative_to(before) for p in before.rglob('*') if p.suffix in ('.bf16', '.f32'))
actual_paths = sorted(p.relative_to(trace) for p in trace.rglob('*') if p.suffix in ('.bf16', '.f32'))
assert len(paths) == 64 and paths == actual_paths
vectors = []
for path in paths:
    expected, actual = b.ident(before / path), b.ident(trace / path)
    assert expected['bytes'] == actual['bytes'] and expected['sha256'] == actual['sha256'], path
    vectors.append({'path': path.as_posix(), 'bytes': actual['bytes'], 'sha256': actual['sha256']})
old_output = json.loads((prior / 'correctness-candidate.stdout.log').read_text().splitlines()[-1])
new_output = json.loads((OUT / 'qwen-owned.stdout.log').read_text().splitlines()[-1])
assert len(new_output['generated_ids']) == 32
assert old_output['generated_ids'] == new_output['generated_ids']
assert old_output['decode_input_ids'] == new_output['decode_input_ids']
capture = lambda path: re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)', path.read_text())
old_capture = capture(prior / 'correctness-candidate.stderr.log')
new_capture = capture(OUT / 'qwen-owned.stderr.log')
assert old_capture == new_capture
b.save('qwen-owned-correctness.json', {'vectors': vectors,
    'equal_vectors': 64, 'equal_token_ids': 32, 'generated_ids': new_output['generated_ids'],
    'capture_counts': new_capture, 'capture_counts_equal': True,
    'image_sha256': receipt['sha256'],
    'limits': 'One correctness replay; no new throughput/memory/quality comparison or llama.cpp run.'})
print('PASS64 vectors,32 tokenIDs,capture counts; no performance claim.', flush=True)
