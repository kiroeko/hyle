from pathlib import Path
import json,sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import build_host as b
import link_run as original
OLD=b.OUT
b.OUT=OUT;b.records=[]
action=sys.argv[1]
if action=='before':
 (OUT/'provider.before.cc').write_bytes((ROOT/'src/compute_provider_flashinfer/flashinfer_provider.cc').read_bytes())
 record=b.comp((OUT/'probe.cc').relative_to(ROOT),'probe')
 (OUT/'probe-identity.json').write_text(json.dumps(record,indent=2)+'\n')
provider=OLD/'highdim-provider-final.obj' if action=='before' else OUT/'attention-scale-provider.obj'
if action=='after':
 b.comp('src/compute_provider_flashinfer/flashinfer_provider.cc','attention-scale-provider')
 provider=OUT/'attention-scale-provider.obj'
objects=[OUT/'probe.obj' if p==OLD/'public-consumer.obj' else provider if p==OLD/'flashinfer-provider.obj' else p for p in original.objects]
objects.append(OLD/'highdim-review/native_highdim.obj')
if action=='tests':
 b.flags.append('/external:I'+str(Path('C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')))
 b.comp('tests/compute_provider_flashinfer/failure_test.cc','failure-test')
 objects=[OUT/'failure-test.obj' if p==OUT/'probe.obj' else p for p in objects]
 original.libs += [b.BASE/'lib/gtest_main.lib',b.BASE/'lib/gtest.lib']
exe=OUT/(action+'.exe')
b.run(action+'-link',[b.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/(action+'.map')),*objects,*original.libs,*original.system])
b.run(action+'-run',[exe,*(['--gtest_filter=Flashinfer.NonPositiveQkScalesDeclineBeforeNativeSoftmax'] if action=='tests' else [])])
(OUT/(action+'-identities.json')).write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=b.sha(p)) for p in [provider,OUT/'probe.obj',exe]],indent=2)+'\n')
