from pathlib import Path
import difflib,hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[3]
sys.path.insert(0,str(REPO/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import build_host as b
import link_run as previous
def record(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=b.sha(p))
def save(n,x):(ROOT/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not (ROOT/'source-results.zip').exists()
product=['src/compute_provider_flashinfer/flashinfer_provider.cc','tests/compute_provider_flashinfer/failure_test.cc','tests/compute_provider_flashinfer/attention_test_support.h']
diff=''
for rel in product:
 p=ROOT/'frozen'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((REPO/rel).read_bytes())
 before=(ROOT/'provider.before.cc').read_bytes() if rel==product[0] else subprocess.check_output(['git','show','HEAD:'+rel],cwd=REPO)
 diff+=''.join(difflib.unified_diff(before.decode().splitlines(True),p.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
(ROOT/'product.diff').write_text(diff,encoding='utf-8',newline='\n')
files=[ROOT/n for n in ['before.exe','after.exe','tests.exe','probe.obj','attention-scale-provider.obj','failure-test.obj']]
save('cleanup-candidates.json',dict(files=[record(p) for p in files],count=len(files),logical_bytes=sum(p.stat().st_size for p in files),performed_cleanup=False,preserve='All source, logs, maps, JSON, archives, prior native/current provider/Foundation/SDK caches.'))
baseline=b.OUT/'highdim-provider-final.obj'
save('identity.json',dict(baseline_provider=record(baseline),before_source=record(ROOT/'provider.before.cc'),candidate_provider=record(ROOT/'attention-scale-provider.obj'),native_objects=[record(p) for p in previous.native_objects+[b.OUT/'highdim-review/native_highdim.obj']],sources=[record(ROOT/'frozen'/p) for p in product]))
commands=[]
for arm,provider,main in [('before',baseline,ROOT/'probe.obj'),('after',ROOT/'attention-scale-provider.obj',ROOT/'probe.obj'),('tests',ROOT/'attention-scale-provider.obj',ROOT/'failure-test.obj')]:
 objects=[main if p==b.OUT/'public-consumer.obj' else provider if p==b.OUT/'flashinfer-provider.obj' else p for p in previous.objects]+[b.OUT/'highdim-review/native_highdim.obj']
 libs=previous.libs+([b.BASE/'lib/gtest_main.lib',b.BASE/'lib/gtest.lib'] if arm=='tests' else [])
 commands.append(dict(arm=arm,link=list(map(str,[b.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(ROOT/(arm+'.exe')),'/MAP:'+str(ROOT/(arm+'.map')),*objects,*libs,*previous.system])),run=[str(ROOT/(arm+'.exe')),*(['--gtest_filter=Flashinfer.NonPositiveQkScalesDeclineBeforeNativeSoftmax'] if arm=='tests' else [])]))
save('command-derivation.json',dict(note='Reconstructed mechanically from the unchanged runner/current cached closure, not fabricated per-command execution records. The initial runner reset host-commands.json between actions; all stdout/stderr, map, source/object identities are preserved.',compiler=str(b.cl),compile_flags=b.flags,consumer_source=str(ROOT/'probe.cc'),provider_source=str(REPO/product[0]),actions=commands))
save('summary.json',dict(status='actual_baseline_wrong_result_fixed_by_cold_native_domain_rejection',numerical_baseline=dict(shape='F16 causal ragged Q2/KV3/H1/KVH1/D64',scale_zero=dict(actual_first=0.0454407,expected=[.3125,.5],finite_max_abs=.454559326),scale_negative=dict(scale=-.5,nonfinite=128,elements=128),positive_control=dict(scale=.5,finite_max_abs=.0000584370638)),candidate=dict(zero_and_negative='BatchProgram prepare rejects Unimplemented; no automatic ordinary-SDPA fallback in three-port Batch API',ordinary='FlashInfer-specific ordinary prepare rejects nonpositive QK scale; default route can consider existing generic math providers',positive_control='Same complete 128-element output oracle/maxAbs as baseline',guard='All batch effectiveScale >0; ordinary scale >0 and log2 conversion representable'),regression=dict(name='Flashinfer.NonPositiveQkScalesDeclineBeforeNativeSoftmax',run='Windows fresh failure_test TU + 1 filtered gtest PASS, both ordinary and Batch cold checks'),additional_wiring_fix='Remove obsolete Linux-only public provider include gate from the FlashInfer test helper, necessary for current Windows-enabled tests.',hardware='Existing RTX4070 SM89, MSVC14.50/CUDA13.3 cache reused',native_recompiled=False,SDK_copied=False,performance_measured=False,model_scope='All selected model attention scales are positive; this is an independent correctness-domain fix, not completion of shared MLA or Sink batch support.',limits=['No enormous memory/pointer-bound runtime test','No FLT_MAX ordinary numerical run; new log2 representability rejection is source-based','No blanket all-domain numerical guarantee'],source=[record(ROOT/'frozen'/p) for p in product]))
with zipfile.ZipFile(ROOT/'source-results.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file() and p.suffix not in ['.obj','.exe','.zip']:z.write(p,p.relative_to(ROOT).as_posix())
save('archive-identity.json',record(ROOT/'source-results.zip'))
print(json.dumps(record(ROOT/'source-results.zip'),indent=2))
