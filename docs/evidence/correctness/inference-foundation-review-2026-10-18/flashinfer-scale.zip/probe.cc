#include <hyle/compute/batch_execution.h>
#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/providers/flashinfer.h>
#include <hyle/simd/dtype.h>
#include <array>
#include <cmath>
#include <cstdio>
#include <vector>

namespace c=hyle::compute;
hyle::Status exercise(float scale) {
  const auto type=c::DataType::kFloat16;
  const c::BatchCapacity cap{.storage=c::BatchStorage::kRagged,
      .query_type=type,.output_type=type,.key_storage=c::CacheStorage::plain(type).value(),
      .value_storage=c::CacheStorage::plain(type).value(),.max_requests=1,
      .max_query_rows=2,.max_kv_rows=3,.max_pages=0,.max_page_refs=0,
      .query_heads=1,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=1};
  HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(cap));
  const std::array<std::int32_t,2> qp{0,2},kp{0,3};
  HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({qp,kp,{},{}}));
  HYLE_ASSIGN_OR_RETURN(auto context,c::Context::create(c::cuda::device(0).value(),c::flashinfer::provider()));
  HYLE_ASSIGN_OR_RETURN(auto device,c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto host,c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
  HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
  auto made=c::BatchProgram::prepare(context,schema,{.resource=device.ref(),.host_workspace=host.ref(),
      .max_float_workspace_bytes=1u<<20,.max_int_workspace_bytes=16384,.scale=scale});
  if(!made){std::printf("scale=%g prepare_rejected=%u code=%d\n",scale,unsigned(made.error().IsUnimplemented()),int(made.error().code()));return hyle::Status::Ok();}
  HYLE_ASSIGN_OR_RETURN(auto slot,c::BatchInvocation::create(*made,queue));
  std::array<std::vector<hyle::simd::float16_t>,3> words;
  words[0].resize(2*64);words[1].resize(3*64);words[2].resize(3*64);
  for(unsigned r=0;r<2;++r)words[0][r*64]=hyle::simd::f32_to_f16(1.F);
  for(unsigned r=0;r<3;++r){words[1][r*64]=hyle::simd::f32_to_f16(float(r));for(unsigned d=0;d<64;++d)words[2][r*64+d]=hyle::simd::f32_to_f16(.125F+.375F*r);}
  HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(device.ref(),4096));
  std::array<c::ReadLease,3> inputs;
  for(unsigned i=0;i<3;++i){HYLE_ASSIGN_OR_RETURN(auto writer,pool.allocate(words[i].size()*2));HYLE_RETURN_IF_ERROR(writer.view()->write(std::as_bytes(std::span(words[i]))));HYLE_ASSIGN_OR_RETURN(inputs[i],writer.publish());}
  HYLE_ASSIGN_OR_RETURN(auto ready,slot.prepare_batch(layout));
  HYLE_ASSIGN_OR_RETURN(auto work,ready.run(inputs));HYLE_RETURN_IF_ERROR(work.wait());
  HYLE_ASSIGN_OR_RETURN(auto result,slot.output());
  std::array<hyle::simd::float16_t,128> output;
  HYLE_RETURN_IF_ERROR(result.view()->read(std::as_writable_bytes(std::span(output))));
  unsigned nonfinite=0;double maximum=0;
  for(unsigned r=0;r<2;++r){double numerator=0,denominator=0;
    for(unsigned j=0;j<r+2;++j){const double weight=std::exp(double(j)*scale);numerator+=weight*(.125+.375*j);denominator+=weight;}
    for(unsigned d=0;d<64;++d){const double actual=hyle::simd::f16_to_f32(output[r*64+d]);if(!std::isfinite(actual))++nonfinite;else maximum=std::max(maximum,std::abs(actual-numerator/denominator));}
    std::printf("scale=%g row=%u actual=%g expected=%.17g\n",scale,r,double(hyle::simd::f16_to_f32(output[r*64])),numerator/denominator);
  }
  std::printf("scale=%g complete=1 nonfinite=%u total=128 finite_max_abs=%.9g\n",scale,nonfinite,maximum);
  result.reset();work={};ready={};HYLE_RETURN_IF_ERROR(slot.close());return context.drain();
}
int main(){std::setvbuf(stdout,nullptr,_IONBF,0);for(float scale:{0.F,-.5F,.5F}){const auto status=exercise(scale);if(!status.ok()){std::fprintf(stderr,"%.*s\n",int(status.message().size()),status.message().data());return 1;}}}
