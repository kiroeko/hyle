from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cpu_cache', ROOT / '.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
cfg = dict(c.PINS['mixed'], folder=Path('mixed'))
flags = c.hyle_flags(cfg) + ['/I' + str(ROOT / 'src/graph')]
records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []

def run(tag, args):
    args = list(map(str, args))
    start = time.monotonic()
    p = subprocess.run(args, cwd=ROOT, env=c.ENV, capture_output=True, timeout=180)
    (OUT / (tag + '.stdout.log')).write_bytes(p.stdout)
    (OUT / (tag + '.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag, command=args, exit=p.returncode, seconds=time.monotonic()-start))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(tag, p.returncode, p.stdout.decode(errors='replace')[-2700:], p.stderr.decode(errors='replace')[-1000:], flush=True)
    if p.returncode:
        raise SystemExit(p.returncode)

def compile(source, stem):
    obj = OUT / (stem + '.obj')
    run(stem + '-compile', [c.CL, *flags, source, '/Fo'+str(obj)])
    return obj

objects = ([OUT / 'executable.obj', OUT / 'tests.obj'] if '--link-only' in sys.argv else
           [compile(ROOT / 'src/graph/executable.cc', 'executable'),
            compile(ROOT / 'tests/graph/executable_test.cc', 'tests')])
# Use the already-matched baseline CPU closure rather than loading an AVX2
# module relative to this scratch executable. No SDK/module is copied here.
objects += [ROOT / '.scratch/mtp-gdn-2026-10-18/mixed' / (name + '.obj')
            for name in ('provider', 'selector-baseline', 'allocator')]
objects += [ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj']
libraries = [c.BASE / 'bin/hyle_graph.lib', c.BASE / 'bin/hyle_compute_provider_native.lib',
             c.BASE / 'bin/hyle_compute_provider_native_test.lib',
             *c.common_libs(cfg), c.BASE / 'lib/gtest_main.lib', c.BASE / 'lib/gtest.lib']
cache = (c.BASE / 'CMakeCache.txt').read_text()
torch = Path(next(line.split('=', 1)[1] for line in cache.splitlines()
                  if line.startswith('TORCH_LIBRARY:'))).parent
libraries += [torch / (name + '.lib') for name in ('torch', 'torch_cpu', 'c10')]
exe = OUT / 'tests.exe'
run('link', [c.LINK, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
            '/NODEFAULTLIB:LIBCMT', '/OUT:'+str(exe), *objects, *libraries, *c.SYSTEM])
run('test', [exe, '--gtest_color=no', '--gtest_filter=Invocation.*:GraphViews.*'])
