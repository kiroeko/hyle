from pathlib import Path
import importlib.util,json,subprocess,sys,time,hashlib
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
P=ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/build.py'
spec=importlib.util.spec_from_file_location('cache',P);cache=importlib.util.module_from_spec(spec);spec.loader.exec_module(cache)
base=json.loads((P.parent/'commands.json').read_text())
compile_cache=next(x['command']for x in reversed(base)if x['tag']=='cuda-provider-compile')
link_cache=next(x['command']for x in reversed(base)if x['tag']=='cuda-link')
flags=[x for x in compile_cache if not x.lower().startswith(('/fo','/fp'))and not x.endswith(('.cc','.cpp'))]
records=json.loads((OUT/'commands.json').read_text())if(OUT/'commands.json').exists()else[]
def run(tag,command):
 command=list(map(str,command));attempt=1+sum(x['tag']==tag for x in records);stem=tag+'-'+str(attempt);p=subprocess.run(command,cwd=ROOT,env=cache.env,capture_output=True,timeout=180)
 (OUT/(stem+'.stdout.log')).write_bytes(p.stdout);(OUT/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=command,exit=p.returncode));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-8000:],p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
 return p.stdout
def build():
 for file,name in [('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','provider'),(str(OUT/'provider.forced.cc'),'provider-forced'),('tests/graph_provider_ggml_cuda/attention_region_test.cc','test'),('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','region')]:run(name+'-compile',[*flags,ROOT/file,'/Fo'+str(OUT/(name+'.obj'))])
 omit={str(P.parent/(n+'.obj'))for n in['cuda-provider','cuda-canonical']}|{str(ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-region.after.obj')}
 for name,provider in [('canonical','provider'),('forced','provider-forced')]:
  command=[x for x in link_cache if x not in omit and not x.startswith(('/OUT:','/MAP:'))]
  run(name+'-link',[*command,OUT/(provider+'.obj'),OUT/'test.obj',OUT/'region.obj','/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map'))])
def relink():
 for file,name in [('tests/graph_provider_ggml_cuda/attention_region_test.cc','test'),('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','region')]:run(name+'-compile',[*flags,ROOT/file,'/Fo'+str(OUT/(name+'.obj'))])
 omit={str(P.parent/(n+'.obj'))for n in['cuda-provider','cuda-canonical']}|{str(ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-region.after.obj')}
 for name,provider in [('canonical','provider'),('forced','provider-forced')]:
  command=[x for x in link_cache if x not in omit and not x.startswith(('/OUT:','/MAP:'))]
  run(name+'-link',[*command,OUT/(provider+'.obj'),OUT/'test.obj',OUT/'region.obj','/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map'))])
def test():
 run('canonical-tests',[OUT/'canonical.exe','--gtest_filter=GgmlCudaAttentionRegion.*','--gtest_color=no'])
 run('forced-tests',[OUT/'forced.exe','--gtest_filter=GgmlCudaAttentionRegion.ColdScalarsDenseConstantsAndDifferentQueriesReplay:GgmlCudaAttentionRegion.CheckedIdsKeepEveryOutputPrivateAcrossAttention','--gtest_color=no'])
if __name__=='__main__':{'build':build,'relink':relink,'test':test}[sys.argv[1]]()
