#include <bit>
#include <cmath>
#include <numeric>
#include "region_test_support.h"
#include "tensor_test_support.h"
#include "../compute_models/batched_sink_fixture.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/providers/ggml_cuda.h"

namespace {
using namespace ggml_cuda_graph_test;
using namespace ggml_cuda_tensor_test;
namespace c = hyle::compute;
namespace g = hyle::graph;
using hyle::mem::Buffer;

void near(std::span<const float> actual, std::span<const float> expected) {
  ASSERT_EQ(actual.size(), expected.size());
  for (std::size_t i = 0; i < actual.size(); ++i)
    ASSERT_NEAR(actual[i], expected[i], 1e-5F) << i;
}
std::vector<float> attention_reference(std::span<const float> q,
    std::span<const float> k, std::span<const float> v, int rows, float scale) {
  constexpr int batch=2, heads=4, kv_heads=2, keys=11, depth=8;
  std::vector<float> out(batch*rows*heads*depth);
  for(int b=0;b<batch;++b)for(int t=0;t<rows;++t)for(int h=0;h<heads;++h){
    std::array<double,keys> weights{};double maximum=-INFINITY,denominator=0;
    const int qbase=((b*rows+t)*heads+h)*depth,kh=h/(heads/kv_heads);
    for(int s=0;s<keys;++s){double dot=0;for(int d=0;d<depth;++d)
      dot+=double(q[qbase+d])*k[((b*keys+s)*kv_heads+kh)*depth+d];
      weights[s]=dot*scale;maximum=std::max(maximum,weights[s]);}
    for(auto&w:weights){w=std::exp(w-maximum);denominator+=w;}
    for(int d=0;d<depth;++d){double sum=0;for(int s=0;s<keys;++s)
      sum+=weights[s]*v[((b*keys+s)*kv_heads+kh)*depth+d];out[qbase+d]=float(sum/denominator);}
  }
  return out;
}

// The diagnostic build changes only the private tile selector to two rows.
// This keeps scalar/dense/checked-leaf tests small while running the real
// native CONCAT and gallocr lifecycle, not a mock allocator or kernel.
void small_regions(bool checked) {
  constexpr int batch=2, queries=7, other_queries=5, heads=4, depth=8;
  auto context=c::Context::create(c::cuda::device(0).value(),g::ggml_cuda::provider()).value();
  auto memory=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice).value();
  const auto qdesc=dense(c::DataType::kFloat32,{batch,queries,heads,depth});
  const auto q2desc=dense(c::DataType::kFloat32,{batch,other_queries,heads,depth});
  const auto kvdesc=dense(c::DataType::kFloat32,{batch,11,2,depth});
  const auto flat=dense(c::DataType::kFloat32,{batch*queries*heads,depth});
  const auto idesc=dense(c::DataType::kInt32,{batch*queries*heads,depth});
  auto builder=g::GraphBuilder::create().value();
  std::vector<c::TensorDesc> descriptions{checked?flat:qdesc,kvdesc,kvdesc,q2desc};
  if(checked)descriptions.push_back(idesc);
  std::vector<g::ValueId> ports;for(const auto&d:descriptions)ports.push_back(builder.input(d).value());
  auto q=ports[0];
  if(checked){auto selected=builder.add(c::model_ops::gather_elements(-1,c::IndexBoundsPolicy::kChecked),q,ports[4]).value();
    q=builder.add(c::View::reshape(c::TensorShape::create(qdesc.dimensions()).value()).value(),selected).value();}
  q=builder.add(c::Unary{c::UnaryKind::kRsqrt},q).value();
  q=builder.add(c::Hadamard{},q).value();
  const auto first=builder.add(c::ScaledDotProductAttention{.scale=.25F,.causal=false},q,ports[1],ports[2]).value();
  const auto second=builder.add(c::ScaledDotProductAttention{.scale=-.125F,.causal=false},ports[3],ports[1],ports[2]).value();
  const auto neg1=builder.add(c::Unary{c::UnaryKind::kNeg},first).value();
  const auto neg2=builder.add(c::Unary{c::UnaryKind::kNeg},second).value();
  const std::array result_ids{first,neg1,second,neg2};
  for(auto id:result_ids)ASSERT_TRUE(builder.publish(id).ok());
  auto logical=std::move(builder).finish().value();
  const std::array domains{g::StorageDomain{.resource=memory.ref()}};
  const std::array targets{g::ExecutionTarget{.context=&context,.default_storage=g::StorageDomainId{0}}};
  const std::array lanes{g::ExecutionLane{.target=g::ExecutionTargetId{0}}};
  auto compiled=g::compile(logical,{.storage_domains=domains,.targets=targets,.lanes=lanes});
  ASSERT_TRUE(compiled)<<compiled.error().message();
  ASSERT_EQ(compiled->report.step_count(),1U);
  EXPECT_EQ(compiled->report.step(0)->provider.id,c::ggml_cuda::kProviderId);
  std::array calls{compiled->executable.create_invocation().value(),compiled->executable.create_invocation().value()};
  std::array queues{context.create_queue().value(),context.create_queue().value()};
  std::vector<Buffer> inputs;for(const auto&d:descriptions)inputs.push_back(output_buffer(memory.ref(),d));
  std::vector<Buffer> outputs;for(int slot=0;slot<2;++slot)for(int i=0;i<4;++i)
    outputs.push_back(output_buffer(memory.ref(),i<2?qdesc:q2desc));
  for(int slot=0;slot<2;++slot){for(std::size_t i=0;i<ports.size();++i)
    ASSERT_TRUE(calls[slot].bind(ports[i],c::ConstTensorView::create(descriptions[i],inputs[i].view()).value()).ok());
    for(int i=0;i<4;++i)ASSERT_TRUE(calls[slot].bind(result_ids[i],c::TensorView::create(i<2?qdesc:q2desc,outputs[slot*4+i].view()).value()).ok());}
  for(int phase=0;phase<2;++phase){
    std::vector<std::vector<float>> data;
    for(int i=0;i<4;++i){data.emplace_back(descriptions[i].element_count().value());
      for(std::size_t j=0;j<data.back().size();++j)data.back()[j]=i==0?1.F+float((j+phase*7)%19)/16.F:float(int((j*7+phase*11+i)%23)-11)/32.F;
      ASSERT_TRUE(inputs[i].view().write(std::as_bytes(std::span(data.back()))).ok());}
    std::vector<std::int32_t> ids(batch*queries*heads*depth);
    for(std::size_t j=0;j<ids.size();++j)ids[j]=int((j+phase*3)%depth);
    if(checked)ASSERT_TRUE(inputs[4].view().write(std::as_bytes(std::span(ids))).ok());
    auto query=data[0];if(checked)for(std::size_t j=0;j<query.size();++j)query[j]=data[0][(j/depth)*depth+ids[j]];
    for(auto&v:query)v=1.F/std::sqrt(v);
    const auto untransformed=query;const float scale=1.F/std::sqrt(float(depth));
    for(std::size_t row=0;row<query.size()/depth;++row)for(int col=0;col<depth;++col){double sum=0;
      for(int d=0;d<depth;++d)sum+=double(untransformed[row*depth+d])*(std::popcount(unsigned(col&d))%2?-scale:scale);
      query[row*depth+col]=float(sum);}
    const auto a=attention_reference(query,data[1],data[2],queries,.25F);
    const auto b=attention_reference(data[3],data[1],data[2],other_queries,-.125F);
    std::array expected{a,a,b,b};for(int i:{1,3})for(auto&v:expected[i])v=-v;
    for(int slot=0;slot<2;++slot){auto accepted=calls[slot].submit(queues[slot]);ASSERT_TRUE(accepted)<<accepted.error().message();ASSERT_TRUE(accepted->wait().ok());
      for(int i=0;i<4;++i)near(half_test::read<float>(outputs[slot*4+i]),expected[i]);
      ASSERT_FALSE(::testing::Test::HasFailure());}
    if(checked&&phase==1){std::vector<std::vector<float>> before;for(const auto&v:outputs)before.push_back(half_test::read<float>(v));
      ids.back()=depth;ASSERT_TRUE(inputs[4].view().write(std::as_bytes(std::span(ids))).ok());
      auto bad=calls[1].submit(queues[1]);ASSERT_TRUE(bad)<<bad.error().message();EXPECT_TRUE(bad->wait().IsOutOfRange());
      for(std::size_t i=0;i<outputs.size();++i)EXPECT_EQ(half_test::read<float>(outputs[i]),before[i]);
      EXPECT_EQ(half_test::read<std::int32_t>(inputs[4]),ids);}
  }
}
}

TEST(GgmlCudaAttentionRegion, RealBatchedSinkTilesFeedPublishedNegative) {
  namespace bs=batched_sink_test;
  using namespace ggml_cuda_graph_test;
  using namespace ggml_cuda_tensor_test;
  auto context=c::Context::create(c::cuda::device(0).value(),g::ggml_cuda::provider()).value();
  auto memory=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice).value();
  bs::Fixture f(128,true,3,8,2049);
  auto builder=g::GraphBuilder::create().value();std::array<g::ValueId,5> ports;
  for(std::size_t i=0;i<ports.size();++i)ports[i]=builder.input(f.descriptions[i]).value();
  auto y=builder.add(f.operation,ports[0],ports[1],ports[2],ports[3],ports[4]).value();
  auto neg=builder.add(c::Unary{c::UnaryKind::kNeg},y).value();
  ASSERT_TRUE(builder.publish(y).ok());ASSERT_TRUE(builder.publish(neg).ok());
  auto graph=std::move(builder).finish().value();const std::array domains{g::StorageDomain{.resource=memory.ref()}};
  const std::array targets{g::ExecutionTarget{.context=&context,.default_storage=g::StorageDomainId{0}}};
  const std::array lanes{g::ExecutionLane{.target=g::ExecutionTargetId{0}}};
  auto compiled=g::compile(graph,{.storage_domains=domains,.targets=targets,.lanes=lanes});
  ASSERT_TRUE(compiled)<<compiled.error().message();ASSERT_EQ(compiled->report.step_count(),1U);
  EXPECT_EQ(compiled->report.step(0)->provider.id,c::ggml_cuda::kProviderId);
  auto call=compiled->executable.create_invocation().value();auto queue=context.create_queue().value();
  std::array<Buffer,5> inputs;for(std::size_t i=0;i<inputs.size();++i){inputs[i]=output_buffer(memory.ref(),f.descriptions[i]);
    ASSERT_TRUE(call.bind(ports[i],c::ConstTensorView::create(f.descriptions[i],inputs[i].view()).value()).ok());}
  auto first=output_buffer(memory.ref(),f.descriptions[0]),second=output_buffer(memory.ref(),f.descriptions[0]);
  ASSERT_TRUE(call.bind(y,c::TensorView::create(f.descriptions[0],first.view()).value()).ok());
  ASSERT_TRUE(call.bind(neg,c::TensorView::create(f.descriptions[0],second.view()).value()).ok());
  for(int phase=0;phase<2;++phase){f.update(phase);for(std::size_t i=0;i<inputs.size();++i)
    ASSERT_TRUE(inputs[i].view().write(std::as_bytes(std::span(f.payloads[i]))).ok());
    auto accepted=call.submit(queue);ASSERT_TRUE(accepted)<<accepted.error().message();ASSERT_TRUE(accepted->wait().ok());
    auto expected=f.expected();bs::check(half_test::read<float>(first),expected);for(auto&v:expected)v=-v;
    bs::check(half_test::read<float>(second),expected);ASSERT_FALSE(::testing::Test::HasFailure());}
}

TEST(GgmlCudaAttentionRegion, ColdScalarsDenseConstantsAndDifferentQueriesReplay) { small_regions(false); }
TEST(GgmlCudaAttentionRegion, CheckedIdsKeepEveryOutputPrivateAcrossAttention) { small_regions(true); }
