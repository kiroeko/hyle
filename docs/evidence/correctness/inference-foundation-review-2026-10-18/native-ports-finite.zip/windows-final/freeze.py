from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-ports-finite.zip'
PHASES = ['finite-exact', 'readonly-resource', 'exact-native-shape',
          'apple-native-region', 'apple-finite-native', 'cuda-finite-consumer',
          'cuda-finite-runtime']
SOURCES = '''
include/hyle/graph/executable.h
include/hyle/graph/native_variants.h
include/hyle/graph/region_provider.h
include/hyle/graph/execution_source.h
include/hyle/graph/resources.h
include/hyle/graph/result.h
include/hyle/graph/apple.h
include/hyle/graph/vulkan.h
include/hyle/graph/cpu_apple.h
include/hyle/graph/cpu_vulkan.h
include/hyle/graph/cpu_cuda.h
src/graph/executable.cc
src/graph/resources.cc
src/graph/execution_source.cc
src/graph/execution_source_internal.h
src/graph/plan_state.h
src/graph/resource_episode.h
src/graph_route_apple/native_region.cc
src/graph_route_apple/native_region.h
src/graph_route_apple/execution_source.cc
src/graph_route_apple/apple_lowering.cc
src/graph_route_apple/apple_lowering_internal.h
src/graph_route_vulkan/native_region.cc
src/graph_route_vulkan/execution_source.cc
src/compute_route_apple/apple_context.cc
src/compute_route_apple/apple_carrier.h
src/compute_route_apple/apple_copy_internal.h
src/compute_route_apple/apple_memory.mm
include/hyle/compute/detail/apple_plan.h
tests/graph/route_symmetry_apple.cc
tests/graph/route_symmetry_vulkan.cc
tests/graph/route_symmetry_cuda.cc
tests/graph/region_provider_test.cc
tests/graph/executable_test.cc
tests/graph_route_apple/native_region_test.cc
tests/compute_route_apple/late_input_test.cc
tests/graph_route_apple/CMakeLists.txt
tests/graph_route_vulkan/CMakeLists.txt
tests/graph_route_cpu_cuda/CMakeLists.txt
tests/compute_route_apple/CMakeLists.txt
test.ps1
docs/developer/current-work.md
docs/architecture/compute-design.md
docs/user/graph.md
docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md
'''.split()

def identity(path):
    path = path.resolve()
    try:
        label = path.relative_to(ROOT).as_posix()
    except ValueError:
        label = str(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return {'path': label, 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main():
    if DEST.exists():
        raise SystemExit('Frozen evidence already exists; do not overwrite it')
    packages = [ARCH / name / 'source-results.zip' for name in PHASES]
    for package in packages:
        with zipfile.ZipFile(package) as archive:
            if archive.testzip() is not None:
                raise SystemExit('Invalid phase archive: ' + str(package))
    commands = json.loads((OUT / 'commands.json').read_text())
    for tag in ['vulkan-consumer-run', 'resource-controls-run']:
        last = next(row for row in reversed(commands) if row['tag'] == tag)
        if last['exit'] != 0:
            raise SystemExit('Latest required actual result failed: ' + tag)
    selected_links = [next(row for row in reversed(commands) if row['tag'] == tag)
                      for tag in ['vulkan-consumer-link', 'controls-link']]
    used = set()
    for row in selected_links:
        for arg in row['command']:
            path = Path(arg)
            if path.is_file() and path.suffix.lower() in {'.obj', '.lib', '.exe'}:
                used.add(path.resolve())
    dump('identities.json', {
        'sources': [identity(ROOT / source) for source in SOURCES],
        'phase_packages': [identity(path) for path in packages],
        'actual_windows_closure': [identity(path) for path in sorted(used)],
    })
    dump('summary.json', {
        'scope': 'Common finite-exact cold families and original native late output ports; partial architecture migration',
        'actual_validation': [
            'Windows final readonly/exclusive/deferred controls 3/3 with c343 resources and final exact executable',
            'Actual RTX 4070 Vulkan common finite points 1 and 4, two slots, old GraphOutput, signed zero and checked control failure/success',
            'Actual RTX 4070 CPU+CUDA finite points 1 and 4, cross-device output, old result gate and cumulative quota',
            'Actual MacBook Air Apple original four Graph/native late-input tests, then finite/control consumer and final 3 Graph tests',
            'Same Apple owned-view feedback test before/after: 64 rounds, exact 16B subrange and original lease owner, final teardown',
            'Phase archives retain initial finite 4/4, original controls 31/31, readonly 33/33 and exact/domain 11/11 with their exact source identities',
        ],
        'fixes': [
            'Original prepared producer port references, no fake handle, duplicate execution slot, shadow workspace or generic host wait',
            'Native source read pins protect pending consumer inputs; checked failure and epochs preserve original Job semantics',
            'Actual Source readonly resource-family authority for input, borrowed constant and generated readonly observation',
            'Exclusive input reader is not captured before next writer upgrade',
            'Exact cold snapshots omit resolved shape programs; declared-domain proof remains on original logical domain',
            'Control-only native fragments keep private terminal arrays, no extra public Graph output',
            'Owned input/view output reuses exact ReadLease subview instead of growing array/lease metadata lineage',
            'Deleted native Apple/Vulkan and CPU+CUDA finite wrapper APIs; migrated actual consumers; registered small CMake test entries',
        ],
        'owner_feedback_bytes': {'before_warm': 51152, 'before_round64': 245712,
                                 'after_warm': 45280, 'after_round64': 45280,
                                 'payload_subrange': 16},
        'limits': [
            'Goal remains active; fixed pure native vertical paths and one CPU+CUDA consumer do not prove all inference modes',
            'Cross-Runtime deferred handoff, other hybrid consumers, custom lowering, paged/pending migration and old native Graph entry removal remain',
            'Canonical constant locality/owner sharing, candidate alignment reset and inherited model feature review require further work',
            'No complete Qwen rerun, numerical acceptance, llama.cpp tokens/s comparison, new Linux build or full CMake configure/build here',
            'No throughput claim, no payload copy reduction claim and no zero-allocation claim from metadata counter result',
            'Existing caches and SDK used; source, logs, data and object identities only in this artifact',
        ],
    })
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for package in packages:
            archive.write(package, 'phases/' + package.parent.name + '.zip')
        for source in SOURCES:
            archive.write(ROOT / source, 'final-source/' + source)
        for path in sorted(OUT.iterdir()):
            if path.suffix.lower() in {'.json', '.log', '.py'} and path.name not in {'cleanup.json', 'archive.json'}:
                archive.write(path, 'windows-final/' + path.name)
        extra = ARCH / 'exclusive-native-input' / 'compile.json'
        archive.write(extra, 'windows-final/exclusive-test-compile.json')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise SystemExit('Invalid final evidence archive')
    receipt = identity(DEST)
    dump('archive.json', receipt)
    allowed = [ARCH / name for name in
               ['finite-exact', 'readonly-resource', 'exact-native-shape',
                'finite-native-migration', 'cuda-finite-runtime']]
    files = [identity(path) for folder in allowed for path in sorted(folder.iterdir())
             if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.lib', '.exp'}]
    dump('cleanup.json', {'evidence': receipt['path'],
         'allowed': [str(path.relative_to(ROOT).as_posix()) for path in allowed], 'files': files})
    print(json.dumps({'archive': receipt, 'reclaim_files': len(files),
          'reclaim_bytes': sum(row['bytes'] for row in files)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
