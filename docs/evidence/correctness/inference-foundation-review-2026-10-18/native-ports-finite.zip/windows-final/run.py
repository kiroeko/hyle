from pathlib import Path
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('driver',
    ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
history = json.loads((ROOT / '.scratch/architecture-refactor-2026-10-18/vulkan-constant-copy/commands.json').read_text())
cc = next(row['command'] for row in history if row['tag'] == 'source-compile')
flags = [arg for arg in cc[1:] if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]

def compile_sources():
    for source, name in [
        ('src/graph_route_vulkan/execution_source.cc', 'vulkan-source'),
        ('src/graph_route_vulkan/native_region.cc', 'vulkan-region'),
        ('src/graph/resources.cc', 'resources'),
        ('tests/graph/route_symmetry_vulkan.cc', 'vulkan-consumer'),
    ]:
        b.run(name + '-compile', [cc[0], *flags, ROOT / source, '/Fo' + str(OUT / (name + '.obj'))])

def link_and_run(core):
    previous = next(row['command'] for row in reversed(history) if row['tag'] == 'native-tests-link')
    skip = {'region.obj', 'constant_artifact.obj', 'region_access.obj', 'resources.obj',
            'source.obj', 'tests.obj', 'execution_source.obj', 'executable.obj'}
    command = [previous[0]]
    for arg in previous[1:]:
        path = Path(arg)
        if arg.startswith(('/OUT:', '/MAP:')):
            continue
        if path.suffix == '.obj' and path.name in skip:
            continue
        if path.name in {'gtest_main.lib', 'gtest.lib'}:
            continue
        command.append(arg)
    command += [str(OUT / (name + '.obj')) for name in
                ['vulkan-source', 'vulkan-region', 'resources', 'vulkan-consumer']]
    readonly = ROOT / '.scratch/architecture-refactor-2026-10-18/readonly-resource'
    command += [str((core if (core / (name + '.obj')).exists() else readonly) / (name + '.obj'))
                for name in ['execution_source', 'executable']]
    finite = ROOT / '.scratch/architecture-refactor-2026-10-18/finite-exact'
    command += [str(finite / (name + '.obj')) for name in ['constant_artifact', 'region_access']]
    command += ['/OUT:' + str(OUT / 'vulkan-consumer.exe'), '/MAP:' + str(OUT / 'vulkan-consumer.map')]
    b.run('vulkan-consumer-link', command)
    b.run('vulkan-consumer-run', [OUT / 'vulkan-consumer.exe'])

if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        compile_sources()
    else:
        link_and_run(Path(sys.argv[1]).resolve())
