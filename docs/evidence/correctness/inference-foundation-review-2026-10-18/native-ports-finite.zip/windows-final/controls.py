from pathlib import Path
import json
import os
import sys
import run

ROOT, OUT = run.ROOT, run.OUT
readonly = ROOT / '.scratch/architecture-refactor-2026-10-18/readonly-resource'
history = json.loads((readonly / 'commands.json').read_text())
previous = next(row['command'] for row in history if row['tag'] == 'controls-link')
replacements = {
    'executable.obj': Path(sys.argv[1]).resolve() / 'executable.obj',
    'resources.obj': OUT / 'resources.obj',
    'region_provider_test.obj': ROOT / '.scratch/architecture-refactor-2026-10-18/exclusive-native-input/region_provider_test.obj',
}
command = []
for arg in previous:
    if arg.upper().startswith('/OUT:'):
        command.append('/OUT:' + str(OUT / 'controls.exe'))
    elif arg.upper().startswith('/MAP:'):
        command.append('/MAP:' + str(OUT / 'controls.map'))
    else:
        command.append(str(replacements.get(Path(arg).name.lower(), arg)))
run.b.run('controls-link', command)
torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
selected = ':'.join([
    'GraphCompile.ReadonlyResourceFamilyRequiresActualSourceAuthority',
    'GraphRegions.DeferredPortsBindOriginalSourcesAndProjectOnlyAfterSuccess',
    'GraphRegions.ExclusiveDeferredInputDoesNotCaptureItsUpgradeableReader',
])
run.b.run('resource-controls-run', [OUT / 'controls.exe', '--gtest_color=no',
    '--gtest_filter=' + selected, '--gtest_output=json:' + str(OUT / 'resource-results.json')])
