from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['src/compute_provider_native/native_plan.h','src/compute_provider_native/native_provider.cc','src/compute_provider_native/CMakeLists.txt','src/compute_provider_native/row_cache.cc','tests/compute_route_cpu/CMakeLists.txt','tests/compute_route_cpu/row_cache_test.cc','tests/compute_models/row_cache_fixture.h']
summary={
 'status':'CPU codec slice implemented, targeted actual Windows Direct and ordinary Graph PASS; broader StateStore/Sink journey remains root-owned',
 'format':{'main':'Hyle row-inline584B for BF16D512:448E4M3FN codes,64raw BF16 tail(128B),7UE8M0 scales,pad0','index':'Hyle row-inline68B for BF16D128:64packed E2M1 bytes(low-even/high-odd),4UE8M0 scales','identity':'New Hyle bytes; not official model cache ABI or native page-footer layout. Hadamard remains an explicit upstream operation.'},
 'product_files':files,
 'source_sha256':{n:sha(R/n)for n in files},
 'implementation':'NativePlan layout unchanged; two prepared custom routes use existing3parameter slots/row_output_stride. RowCacheEncode checks all BF16 input bits for NaN/Inf before output write and uses original DS4 nearest-even helpers plus identical F32floor/absmax/log2ceil power2 scale. Codes retain original BF16 signbit incl-0. GatherDecode first checks every checked ID, then maps source/output and reads only indexed rows; no whole-history conversion or hot heap. Mapping failure/close/flush status follows original native route and accepted-command semantics.',
 'numeric_contract':'Finite source may decode/round to BF16 Inf. Source NaN/Inf is InvalidArgument. IEEE reserved E4M3FN codes/UE8M0255 decodeNaN. FP8tail is copied bitwise. No negative-ID wrapping; unchecked IDs are caller-valid precondition.',
 'canonical':{'test_source':'tests/compute_route_cpu/row_cache_test.cc','passed':2,'scope':'Both formats;5bankrows,rank2 IDs[2,3]with repeats/high4,checked+unchecked,two changed source/ID phases; complete encoded bytes and selectedBF16bits match independent FP64table/distance/BF16RNE oracle. Covers±0/minsubnormal/negative tiny,ties,finite max/Inf boundary,rawtailbits. Last invalid ID{-1,5,INT32_MAX} and late NaN/+Inf/-Inf source retain sentinel output. Scalar IDs,empty encoder/empty bank+IDs and reservedpayloadNaN allPASS.','metadata_allocator':'8encode+decode episodes /16Direct submit calls,each measured metadata total_allocs delta0; nativecode also has no dynamic allocation. Not a complete process-heap measurement.'},
 'graph':{'source':'graph_probe.cc','entry':'actual hyle::graph::cpu::create_context default roster','chain':'RowCacheEncode->RowCacheGatherDecode->CastF32; encoded U8bank+selectedBF16+F32threepublish','cases':'D512andD128,twochangedphases,repeat highID4;fullbyte/bit oracle PASS','plan':'3steps/0regions; no fused-kernel claim'},
 'fixture':'tests/compute_models/row_cache_fixture.h namespace row_cache_test; pure data with mathematical BF16 neighbor search and independent FP64format table; shared with CUDA/root consumer. No productcodec or gtest dependency.',
 'build':'MSVC14.50.35717 /W4 /WX; fresh row_cache.cc/native_provider.cc/canonical test host TUs; root fresh row-cache-contracts/low-precision.obj plus existing default CPU/Graph/native libraries. One additional scratch GraphhostTU. No configure/fullSDK/native rebuild/download. Native row source/CMake admission are unconditional and do not require Torch; actual reused validation SDK includes Torch, so a fresh standalone no-Torch SDK run is not claimed.',
 'warning_boundary':'MSVC4505 suppressed only around unchanged upstream ds4_roundtrip.h because this new TU reuses its value/dequant helpers rather than whole-row entry functions. All other /W4 /WX checks retained.',
 'validation':'Canonical and scratchGraph numeric/failure runs PASS; touched product/test diff check PASS. CMake source registrations reviewed, not a full CMakeconfigure/build.',
 'remaining':'Root-owned StateStore clone/write complete row->selecteddecode->BF16CastF32->Sink/prefix journey not yet executed in this slice. No F2/CacheStorage8B/arena changes, jointpaged native carrier,fullmodel or throughput claim.',
 'commands':'build.py and run_graph.py use only recorded cached command JSON and safe environment helper. recovered-original-compile-commands.json explicitly identifies reconstructed first compile argv after initial command-ledger overwrite; original compiler stdout/stderr retained. Subsequent ledger appends fixed.',
 'reproduce':['python .scratch/inference-foundation-review-2026-10-18/row-cache-cpu/build.py','python .scratch/inference-foundation-review-2026-10-18/row-cache-cpu/run_graph.py'],
 'archive':'Product/test/publiccontract/shared fixture/DS4source-license plus commands/logs/identities only. No obj/exe/lib/SDK.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
artifacts=[p for p in O.iterdir()if p.is_file()and p.suffix in ['.exe','.lib','.exp']]
cleanup=dict(intent='Candidates only; no deletion. Root owns test.ps1.',candidates=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in artifacts],total_candidate_bytes=sum(p.stat().st_size for p in artifacts),retain_objects=[str(p)for p in O.glob('*.obj')],retain_source_logs=True)
(O/'cleanup-candidates.json').write_text(json.dumps(cleanup,indent=2)+'\n')
extra=['include/hyle/compute/low_precision.h','include/hyle/compute/model_ops.h','src/compute_ops/low_precision.cc','src/compute_provider_native/numeric.h','tests/compute_provider_native/half_test_support.h','third_party/ds4_quantization/ds4_roundtrip.h','third_party/ds4_quantization/LICENSE','third_party/ds4_quantization/source.json']
with zipfile.ZipFile(O/'source-results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in O.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.log','.cc','.diff']:z.write(p,p.name)
 for n in [*files,*extra]:z.write(R/n,'source/'+n)
 for p in (O/'before').rglob('*'):
  if p.is_file():z.write(p,'before/'+p.relative_to(O/'before').as_posix())
p=O/'source-results.zip';print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)),indent=2))
