from pathlib import Path
import json,subprocess,sys,os,time,hashlib
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
cached=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/commands.json').read_text())
host=next(x['command']for x in reversed(cached)if x['tag']=='cpu-canonical-compile'and x['exit']==0)
flags=[s for s in host if not s.endswith('.cc')and not s.lower().startswith('/fo')]
flags+=['/I'+str(R/'src/compute_provider_native'),'/I'+str(R/'third_party/ds4_quantization')]
link=next(x['command']for x in reversed(cached)if x['tag']=='cpu-link'and x['exit']==0)
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]})
env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
runtime=[str(R/'.scratch/build-compute-v2-dev/bin')]+[str(Path(p).parent)for p in link if p.endswith('.lib')and Path(p).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
records=json.loads((O/'commands.json').read_text()) if (O/'commands.json').exists() else []
def run(tag,cmd):
 start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(tag+'.stdout.log')).write_bytes(p.stdout);(O/(tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=list(map(str,cmd)),cwd=str(R),exit=p.returncode,seconds=time.monotonic()-start));(O/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-3000:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
def compile(file,obj):
 if not (O/obj).exists() or (O/obj).stat().st_mtime < (R/file).stat().st_mtime:
  run(obj+'-compile',[*flags,R/file,'/Fo'+str(O/obj)])
compile('src/compute_provider_native/row_cache.cc','row-cache.obj')
compile('src/compute_provider_native/native_provider.cc','native-provider.obj')
compile('tests/compute_route_cpu/row_cache_test.cc','canonical.obj')
omit={str(R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cpu-canonical.obj')}
cmd=[s for s in link if s not in omit and not s.startswith(('/OUT:','/MAP:'))]
cmd+=[O/'row-cache.obj',O/'native-provider.obj',O/'canonical.obj',R/'.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj','/OUT:'+str(O/'tests.exe')]
run('link',cmd);run('tests',[O/'tests.exe','--gtest_filter=CpuRowCache.*','--gtest_color=no'])
paths=[Path(s)for s in cmd if str(s).endswith(('.obj','.lib'))and Path(s).is_file()]
(O/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
