from pathlib import Path
import json,sys,os,subprocess,time
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
cached=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/commands.json').read_text())
host=next(x['command']for x in reversed(cached)if x['tag']=='cpu-canonical-compile'and x['exit']==0)
flags=[s for s in host if not s.endswith('.cc')and not s.lower().startswith('/fo')]
current=json.loads((O/'commands.json').read_text());link=next(x['command']for x in reversed(current)if x['tag']=='link'and x['exit']==0)
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]})
runtime=[str(R/'.scratch/build-compute-v2-dev/bin')]+[str(Path(p).parent)for p in link if p.endswith('.lib')and Path(p).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH'];env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2';env['VSLANG']='1033'
records=[]
def run(tag,cmd):
 start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(tag+'.stdout.log')).write_bytes(p.stdout);(O/(tag+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'graph-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-3000:],flush=True);p.check_returncode()
run('graph-compile',[*flags,O/'graph_probe.cc','/Fo'+str(O/'graph.obj')])
cmd=[s for s in link if s!=str(O/'canonical.obj')and not s.startswith(('/OUT:','/MAP:'))]
run('graph-link',[*cmd,O/'graph.obj','/OUT:'+str(O/'graph.exe')]);run('graph',[O/'graph.exe'])
