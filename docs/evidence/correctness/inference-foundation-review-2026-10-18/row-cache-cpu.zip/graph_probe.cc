#include "hyle/graph/cpu.h"
#include "hyle/compute/model_ops.h"
#include "tests/compute_models/row_cache_fixture.h"
#include <bit>
#include <cstdio>
namespace c=hyle::compute;namespace g=hyle::graph;namespace m=hyle::mem;
hyle::Status run(c::RowCacheEncoding encoding){
  HYLE_ASSIGN_OR_RETURN(auto context,g::cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto sd,c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{5,encoding.depth()}));
  HYLE_ASSIGN_OR_RETURN(auto bd,c::row_cache_carrier_description(encoding,5));
  HYLE_ASSIGN_OR_RETURN(auto id,c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,2>{2,3}));
  const std::array decode_inputs{bd,id};auto gather=c::model_ops::row_cache_gather_decode(encoding);
  HYLE_ASSIGN_OR_RETURN(auto dd,c::infer_single_output(gather,decode_inputs));
  HYLE_ASSIGN_OR_RETURN(auto fd,c::TensorDesc::dense(c::DataType::kFloat32,dd.dimensions()));
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto source,builder.input(sd));HYLE_ASSIGN_OR_RETURN(auto ids,builder.input(id));
  HYLE_ASSIGN_OR_RETURN(auto bank,builder.add(c::model_ops::row_cache_encode(encoding),source));
  const std::array selected_inputs{bank,ids};
  HYLE_ASSIGN_OR_RETURN(auto selected_node,builder.add_node(gather,selected_inputs));
  HYLE_ASSIGN_OR_RETURN(auto selected,builder.result(selected_node));
  HYLE_ASSIGN_OR_RETURN(auto output,builder.add(c::Cast{c::DataType::kFloat32},selected));
  for(auto value:{bank,selected,output})HYLE_RETURN_IF_ERROR(builder.publish(value));
  HYLE_ASSIGN_OR_RETURN(auto logical,std::move(builder).finish());
  HYLE_ASSIGN_OR_RETURN(auto compiled,g::compile(logical,context));
  HYLE_ASSIGN_OR_RETURN(auto invocation,compiled.executable.create_invocation());
  HYLE_ASSIGN_OR_RETURN(auto sb,m::Buffer::create(m::system_resource(),*sd.required_bytes(),64));
  HYLE_ASSIGN_OR_RETURN(auto ib,m::Buffer::create(m::system_resource(),*id.required_bytes(),64));
  HYLE_ASSIGN_OR_RETURN(auto bb,m::Buffer::create(m::system_resource(),*bd.required_bytes(),64));
  HYLE_ASSIGN_OR_RETURN(auto db,m::Buffer::create(m::system_resource(),*dd.required_bytes(),64));
  HYLE_ASSIGN_OR_RETURN(auto fb,m::Buffer::create(m::system_resource(),*fd.required_bytes(),64));
  HYLE_RETURN_IF_ERROR(invocation.bind(source,*c::ConstTensorView::create(sd,sb.view())));
  HYLE_RETURN_IF_ERROR(invocation.bind(ids,*c::ConstTensorView::create(id,ib.view())));
  HYLE_RETURN_IF_ERROR(invocation.bind(bank,*c::TensorView::create(bd,bb.view())));
  HYLE_RETURN_IF_ERROR(invocation.bind(selected,*c::TensorView::create(dd,db.view())));
  HYLE_RETURN_IF_ERROR(invocation.bind(output,*c::TensorView::create(fd,fb.view())));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
  HYLE_RETURN_IF_ERROR(invocation.prepare_replay(queues));
  for(int phase:{0,1}){
    const auto data=row_cache_test::input_values(encoding,phase);
    const auto expected=row_cache_test::reference(encoding,data);
    const std::array<std::int32_t,6> indices=phase?std::array<std::int32_t,6>{3,4,1,2,0,4}:std::array<std::int32_t,6>{4,1,4,0,3,2};
    HYLE_RETURN_IF_ERROR(sb.view().write(std::as_bytes(std::span(data))));HYLE_RETURN_IF_ERROR(ib.view().write(std::as_bytes(std::span(indices))));
    HYLE_ASSIGN_OR_RETURN(auto done,invocation.submit(queue));HYLE_RETURN_IF_ERROR(done.wait());
    std::vector<std::uint8_t> bytes(bb.size());std::vector<std::uint16_t> bfloat(db.size()/2);std::vector<float> floats(fb.size()/4);
    HYLE_RETURN_IF_ERROR(bb.view().read(std::as_writable_bytes(std::span(bytes))));HYLE_RETURN_IF_ERROR(db.view().read(std::as_writable_bytes(std::span(bfloat))));HYLE_RETURN_IF_ERROR(fb.view().read(std::as_writable_bytes(std::span(floats))));
    if(bytes!=expected.bytes)return hyle::Status::DataLoss("Graph encoded bank oracle");
    for(std::size_t i=0;i<indices.size();++i)for(std::size_t d=0;d<encoding.depth();++d){
      const auto at=i*encoding.depth()+d;const auto bits=expected.decoded[std::size_t(indices[i])*encoding.depth()+d];
      if(bfloat[at]!=bits||std::bit_cast<std::uint32_t>(floats[at])!=(std::uint32_t(bits)<<16))return hyle::Status::DataLoss("Graph selected BF16/F32 oracle");
    }
    std::printf("Graph depth=%u phase=%d Encode->GatherDecode->CastF32 three published outputs PASS steps=%zu regions=%zu\n",encoding.depth(),phase,compiled.report.step_count(),compiled.report.region_count());
  }
  return hyle::Status::Ok();
}
int main(){for(auto encoding:{c::RowCacheEncoding::float8_block64_tail64(),c::RowCacheEncoding::float4_block32()}){auto status=run(encoding);if(!status.ok()){char text[512]{};status.ToString(text,sizeof(text));std::fprintf(stderr,"%s\n",text);return 1;}}return 0;}
