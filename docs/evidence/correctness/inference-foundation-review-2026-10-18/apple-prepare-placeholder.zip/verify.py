from pathlib import Path
import json, hashlib, tarfile, subprocess, difflib
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((R/'third_party/mlx_cast/patches.json').read_text(encoding='utf-8'))
records=[]
with tarfile.open(R/'.scratch/inference-gaps/g04-g05/metal-lifetime/mlx-1f8e74e3f12f31365464a6867c6579f0e9b29d85.tar.gz','r:gz')as z:
 for f in manifest['files']:
  raw=z.extractfile(next(m for m in z.getmembers()if m.name.endswith('/'+f['path']))).read()
  assert sha(raw)==f['before_sha256'],f['path'];s=raw.decode()
  for i,e in enumerate(f['edits']):
   assert s.count(e['before'])==1,(f['path'],i,s.count(e['before']))
   s=s.replace(e['before'],e['after'],1)
  assert sha(s.encode())==f['after_sha256'],f['path']
  records.append(dict(path=f['path'],before_sha256=sha(raw),after_sha256=sha(s.encode()),exact_edits=len(f['edits'])))
(O/'final-manifest-authentication.json').write_text(json.dumps(records,indent=2)+'\n')
files=['src/compute_route_apple/apple_context.cc','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md','cmake/HyleDependencyLock.json','tests/compute_route_apple/context_test.cc']
diff=''
for name in files:
 a=(O/'before'/name).read_text(encoding='utf-8').splitlines(True);b=(R/name).read_text(encoding='utf-8').splitlines(True)
 diff+=''.join(difflib.unified_diff(a,b,fromfile='a/'+name,tofile='b/'+name))
(O/'task.diff').write_text(diff,encoding='utf-8')
before=json.loads((O/'before/cmake/HyleDependencyLock.json').read_text(encoding='utf-8'));current=json.loads((R/'cmake/HyleDependencyLock.json').read_text(encoding='utf-8'))
entry=next(x for x in current['dependencies']if x['name']=='mlx_cast_patches')
notice=next(x for x in entry['license']['files']if x['path'].endswith('/NOTICE.md'))
final=dict(tree=entry['vendored']['tree_sha256'],notice=notice['sha256'])
for old in before['dependencies']:
 now=next(x for x in current['dependencies']if x['name']==old['name'])
 if old['name']=='mlx_cast_patches':
  now['vendored']['tree_sha256']=old['vendored']['tree_sha256']
  for license in old['license']['files']:
   if license['path'].endswith('/NOTICE.md'):next(x for x in now['license']['files']if x['path']==license['path'])['sha256']=license['sha256']
 assert old==now,old['name']
(O/'final-lock-identity.json').write_text(json.dumps(final,indent=2)+'\n')
commands=[('selected-dependency-audit',['cmake','-P',str(O/'audit.cmake')]),('diff-check',['git','diff','--check','--',*files])]
results=[]
for tag,cmd in commands:
 p=subprocess.run(cmd,cwd=R,capture_output=True);(O/(tag+'.stdout.log')).write_bytes(p.stdout);(O/(tag+'.stderr.log')).write_bytes(p.stderr)
 results.append(dict(tag=tag,command=cmd,cwd=str(R),exit=p.returncode));p.check_returncode()
(O/'verification-commands.json').write_text(json.dumps(results,indent=2)+'\n')
print('all19 native files: original SHA, exact edits and after SHA PASS; only two mlx lock hashes changed; selected CMake identity audit and diff check PASS')
