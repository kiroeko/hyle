#include <mlx/mlx.h>
#include <mlx/memory.h>
#include <array>
#include <cstdio>
#include <stdexcept>
#include "hyle/compute/apple.h"
#include "hyle/compute/model_ops.h"
namespace c=hyle::compute; namespace a=c::apple; namespace mx=mlx::core;
template<class T>T take(hyle::Result<T>&&r){if(!r)throw std::runtime_error(std::string(r.error().message()));return std::move(*r);}
int main(){try{
  auto context=take(a::Context::create());
  const auto w=take(c::float8_grouped_weight_description(256,2048,6144));
  const auto x=take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,3>{1,1,6144}));
  const auto ids=take(c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,2>{1,8}));
  const std::array specs{take(a::input_spec(w)),take(a::input_spec(x)),take(a::input_spec(ids))};
  mx::clear_cache();mx::reset_peak_memory();
  // Fail boundedly if a logical code-bank copy is accidentally reintroduced.
  const auto prior_limit=mx::set_memory_limit(128u*1024u*1024u);
  const auto before=mx::get_active_memory(),cache_before=mx::get_cache_memory();
  auto program=take(context.prepare(c::model_ops::grouped_float8_linear(),specs));
  const auto active=mx::get_active_memory(),cache=mx::get_cache_memory(),peak=mx::get_peak_memory();
  std::printf("{\"phase\":\"prepare_only\",\"E\":256,\"N\":2048,\"K\":6144,\"carrier_bytes\":%zu,\"active_before\":%zu,\"cache_before\":%zu,\"active\":%zu,\"cache\":%zu,\"peak\":%zu,\"limit\":134217728,\"real_bank_allocated\":false}\n",*w.required_bytes(),before,cache_before,active,cache,peak);
  if(peak>=128u*1024u*1024u)throw std::runtime_error("unexpected prepare memory");
  mx::set_memory_limit(prior_limit);
  return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
