from pathlib import Path
import tarfile,io,re,json,subprocess,base64,hashlib,sys
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/apple-prepare-placeholder'
remote='/Users/kiro/hyle-scratch/compute-unified/inference-foundation-review-20261018-apple-prepare-placeholder'
def ssh(code,data=None,timeout=30):
 cmd="python3 -c \"import base64;exec(base64.b64decode('"+base64.b64encode(code.encode()).decode()+"'))\""
 return subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=data,capture_output=True,timeout=timeout)
def stage():
 files={n:O/n for n in ['common.before.cpp','common.after.cpp','native-edit.json','run_remote.py','large_prepare.cc','reshape_controls.cc']};seen=set()
 def add(p):
  p=p.resolve()
  if p in seen:return
  seen.add(p)
  if p.is_relative_to(R)and'.scratch'not in p.relative_to(R).parts:files[p.relative_to(R).as_posix()]=p
  for rel in re.findall(r'^\s*#\s*include\s*"([^\"]+)"',p.read_text(encoding='utf-8-sig'),re.M):
   for q in [p.parent/rel,R/rel,R/'include'/rel,R/'src/compute_route_apple'/rel,R/'src/compute'/rel]:
    if q.is_file():add(q);break
 for p in [R/'src/compute_route_apple/apple_context.cc',R/'tests/compute_route_apple/context_test.cc',O/'large_prepare.cc',O/'reshape_controls.cc']:add(p)
 (O/'staged-sources.json').write_text(json.dumps([dict(path=k,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for k,p in sorted(files.items())],indent=2)+'\n')
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w:gz')as t:
  for k,p in sorted(files.items()):t.add(p,arcname=k)
 (O/'minimal-sources.tar.gz').write_bytes(b.getvalue())
 code='from pathlib import Path;import tarfile,io,sys;r=Path('+repr(remote)+');assert not r.exists();r.mkdir();t=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in t.getmembers());t.extractall(r);print(r)'
 p=ssh(code,b.getvalue());(O/'stage.stdout.log').write_bytes(p.stdout);(O/'stage.stderr.log').write_bytes(p.stderr);print(p.returncode,len(files),len(b.getvalue()),p.stdout.decode(),p.stderr.decode());p.check_returncode()
def action(name):
 p=subprocess.run(['ssh','kiro@172.22.10.198','cd '+remote+' && python3 run_remote.py '+name],capture_output=True,timeout=300)
 (O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr);print(p.returncode,p.stdout.decode(errors='replace')[-10000:],p.stderr.decode(errors='replace')[-4000:]);p.check_returncode()
def collect():
 code='''from pathlib import Path
import tarfile,io,sys
r=Path('''+repr(remote)+''');b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz')as t:
 for p in r.iterdir():
  if p.is_file() and p.suffix in ['.json','.log','.txt']:
   t.add(p,arcname=p.name)
sys.stdout.buffer.write(b.getvalue())
'''
 p=ssh(code);p.check_returncode();(O/'remote-results.tar.gz').write_bytes(p.stdout)
 with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:gz')as t:
  assert all(m.isfile()and len(Path(m.name).parts)==1 for m in t.getmembers())
  t.extractall(O)
 print('collected',len(p.stdout))
if __name__=='__main__':{'stage':stage,'build':lambda:action('build'),'test':lambda:action('test'),'collect':collect}[sys.argv[1]]()
