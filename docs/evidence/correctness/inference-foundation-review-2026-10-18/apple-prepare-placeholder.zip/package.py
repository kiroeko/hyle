from pathlib import Path
import json, hashlib, zipfile,tarfile,io
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=R/'.scratch/inference-fusion-quantization-2026-10-18/apple-full-fp8-carrier/full-bank-test-1.stdout.log'
identity=json.loads((O/'final-lock-identity.json').read_text())
files=['src/compute_route_apple/apple_context.cc','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md','cmake/HyleDependencyLock.json','tests/compute_route_apple/context_test.cc']
summary={
 'status':'implemented and frozen; actual Mac16,12 controls PASS',
 'changes':[
  {'name':'Apple grouped preparation storage','scope':'Only prepare_mlx: official grouped FP8/FP4 U8 InputSpec dummy is scalar0 broadcast to the unchanged carrier shape. Ordinary inputs keep zeros; real bind capacity checks, numeric kernels and explicit scale CONT unchanged.'},
  {'name':'Native scalar-broadcast reshape','scope':'Only common.cpp: retain original empty/row-contiguous first branch; replace ndim0 special case with nonempty data_size1, preserving zero strides and backing instead of INT_MAX collapse forcing a full logical copy.'},
  {'name':'Independent manifest match-text repair','scope':'Two whole-file edit pairs in scaled_dot_product_attention.cpp and two in sdpa_vector.h had copyright U+6F0F rather than original U+00A9 in both before/after. Eight exact character replacements restore source matching. The two existing final native hashes already matched the repaired output; all native bodies remain identical.'}],
 'upstream':{'revision':'1f8e74e3f12f31365464a6867c6579f0e9b29d85','version':'MLX0.32.2','common_before_sha256':sha(O/'common.before.cpp'),'common_after_sha256':sha(O/'common.after.cpp')},
 'lock':identity,
 'source_sha256':{n:sha(R/n)for n in files},
 'build':{'native_fresh':['common.after.cpp'],'host_fresh':['src/compute_route_apple/apple_context.cc','tests/compute_route_apple/context_test.cc','large_prepare.cc','reshape_controls.cc'],'cached':'Existing Air SDK and current batched-Sink tensor/operations, recurrent/MLX Metal host patches, mature FP4/FP8 carrier, numeric probe objects and native libraries reused. No SDK/source checkout modified or rebuilt. Link-map proof confirms old SDK common object vs new common.o.'},
 'canonical':{'passed':5,'new_tests':['BroadcastScalarReshapeKeepsOneStoredElementAcrossWideAxes','GroupedWeightPreparationDoesNotFreezeBroadcastStrides'],'old_control':'With original SDK common, wide planner returns copy=true and the controlled gtest fails before evaluation. No old multi-GB reshape is evaluated. With new common, [805306368,4]->[96,4096,64,128] shares1 stored U8 element.'},
 'reshape_controls':'Original and candidate both PASS same planner decision and values for ordinary row-contiguous, transpose with nonzero strides, reversed negative-stride, singleton nonzero-stride and empty arrays.',
 'large_prepare':{'operation':'Public Context.prepare(grouped_float8_linear) only','E':256,'N':2048,'K':6144,'carrier_bytes':3222011904,'actual_new':{'active_before':0,'cache_before':0,'active':24,'cache':956693,'peak':956713,'native_memory_limit':134217728},'earlier_before':{'active':24,'cache':3326810389,'source':str(old.relative_to(R)),'source_sha256':sha(old),'same_scope':'Prepared-phase record from previous frozen large-capacity execution; old large prepare was not rerun. This is allocation evidence, not a fresh paired timing experiment.'},'cache_difference_bytes':3326810389-956693,'real_bank_allocated_this_stage':False},
 'small_numeric':{'fp4':'Original reused probe.o: E64/N257/K256/T3/S8/A1,8;24672 BF16 bits checked against independent FP64+original rounding, two phases;6 original tiny checks,6 invalid-ID cases and old native output retention. All output bits match prior frozen output.','fp8':'Original reused probe.o:12336 grouped and12288 ordinary linear F32 outputs, two phases, maxabs0 and original2e-6+rel2e-6 budget; invalid-ID and output-retention checks PASS. All bits match prior frozen output.'},
 'remaining_boundary':'This removes whole-code-bank preparation storage, not all preparation work. Explicit contiguous scale-byte views remain: FP8 example786432B; Pro FP4 scales1056964608B would still materialize. No5GB Pro prepare or real full bank allocation/run was attempted this stage.',
 'validation':'Full exact19-file current manifest replay from original1f8 tar PASS: every before SHA, every unique edit and final after SHA. Selected CMake mlx_cast_patches identity audit and touched-file diff check PASS. Only two mlx lock hashes changed; upstream/version and other dependency entries unchanged.',
 'not_claimed':['All-platform/native SDK rebuild','Full8model22profile run','Throughput improvement','Elimination of explicit scale materialization'],
 'reproduce':['python .scratch/inference-foundation-review-2026-10-18/apple-prepare-placeholder/stage.py stage','python .scratch/inference-foundation-review-2026-10-18/apple-prepare-placeholder/stage.py build','python .scratch/inference-foundation-review-2026-10-18/apple-prepare-placeholder/stage.py test','python .scratch/inference-foundation-review-2026-10-18/apple-prepare-placeholder/verify.py'],
 'archive':'Sources, exact task diff, original manifests, native original/edited TU, command/log/result/identity proof only. No object, executable, map, SDK or dependency tree.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(O/'source-results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in O.iterdir():
  if p.is_file()and p.suffix in ['.json','.log','.txt','.py','.cc','.cpp','.cmake','.diff']:
   z.write(p,p.name)
 for n in files:z.write(R/n,'product/'+n)
 for p in (O/'before').rglob('*'):
  if p.is_file():z.write(p,'before/'+p.relative_to(O/'before').as_posix())
 with tarfile.open(O/'minimal-sources.tar.gz','r:gz')as t:
  for m in t.getmembers():
   assert m.isfile()and not Path(m.name).is_absolute()and'..'not in Path(m.name).parts
   z.writestr('validation-source/'+m.name,t.extractfile(m).read())
 for case in ['fp4','fp8']:
  base=R/('.scratch/inference-fusion-quantization-2026-10-18/apple-indexed-'+case)
  z.write(base/'probe.cc','reused-probe-source/'+case+'.cc')
  z.write(base/'summary.json','reused-probe-source/'+case+'-original-summary.json')
 z.write(old,'earlier-large-prepare/original.stdout.log')
 z.write(old.parent/'full_probe.cc','earlier-large-prepare/original-source.cc')
 z.write(R/'third_party/mlx_cast/LICENSE','licenses/MLX-LICENSE')
p=O/'source-results.zip';print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)),indent=2))
