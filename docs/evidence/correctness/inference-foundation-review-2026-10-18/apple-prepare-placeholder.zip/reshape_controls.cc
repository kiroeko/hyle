#include <mlx/mlx.h>
#include <mlx/backend/common/utils.h>
#include <cstdio>
#include <stdexcept>
namespace mx=mlx::core;
mx::array ready(mx::array x){mx::eval(x);return x;}
void check(bool b){if(!b)throw std::runtime_error("reshape control");}
void control(const char*name,mx::array input,const mx::Shape&shape,const std::vector<float>&expect){
  input=ready(input);mx::array desc(shape,input.dtype(),nullptr,{});
  auto [copy,strides]=mx::prepare_reshape(input,desc);
  auto output=ready(mx::contiguous(mx::reshape(input,shape),false));
  check(output.size()==expect.size());
  for(std::size_t i=0;i<expect.size();++i)check(output.data<float>()[i]==expect[i]);
  std::printf("{\"control\":\"%s\",\"input_data_size\":%zu,\"copy\":%s,\"values_checked\":%zu}\n",name,input.data_size(),copy?"true":"false",expect.size());
}
int main(){try{
  auto values=ready(mx::array({1.f,2.f,3.f,4.f,5.f,6.f},{2,3}));
  control("row_contiguous",values,{3,2},{1,2,3,4,5,6});
  control("transpose_nonzero_strides",mx::transpose(values),{6},{1,4,2,5,3,6});
  auto flat=ready(mx::reshape(values,{6}));
  control("negative_stride",mx::as_strided(flat,{6},{-1},5),{2,3},{6,5,4,3,2,1});
  control("singleton_nonzero_strides",mx::as_strided(flat,{1,1},{4,2},3),{}, {4});
  control("empty",mx::zeros({0,3}),{3,0},{});
  return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
