from pathlib import Path
import json, subprocess, sys, time, hashlib
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'inference-fusion-quantization-20261018-apple-batched-sink'
FP4=ROOT.parent/'inference-fusion-quantization-20261018-apple-indexed-fp4'
FP8=ROOT.parent/'inference-fusion-quantization-20261018-apple-indexed-fp8'
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
old=json.loads((OLD/'commands.json').read_text())
base_compile=next(x['command']for x in old if x['tag']=='context-compile')
base_link=next(x['command']for x in old if x['tag']=='batched-sink-link')
records=json.loads((ROOT/'commands.json').read_text())if(ROOT/'commands.json').exists()else[]
def run(tag,cmd,expected=0):
  start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=ROOT,capture_output=True,timeout=150)
  (ROOT/(tag+'.stdout.log')).write_bytes(p.stdout);(ROOT/(tag+'.stderr.log')).write_bytes(p.stderr)
  records.append(dict(tag=tag,command=list(map(str,cmd)),cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start))
  (ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,flush=True)
  if (expected==0 and p.returncode!=0)or(expected=='failure'and p.returncode==0):
    print(p.stdout.decode(errors='replace')[-4000:],p.stderr.decode(errors='replace')[-7000:]);raise SystemExit(1)
  return p
def compile(file,obj,native=False):
  if native:
    cmd=['clang++','-O3','-DNDEBUG','-std=c++17','-arch','arm64','-DMLX_STATIC','-I'+str(SDK/'include'),'-c',ROOT/file,'-o',ROOT/obj]
  else:
    cmd=base_compile[:base_compile.index('-c')]
    cmd[1:1]=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(ROOT/'src/compute')]
    cmd+=['-c',ROOT/file,'-o',ROOT/obj]
  run(obj+'-compile',cmd)
def link(name,probe,patched=True,gtest=False):
  cmd=[]
  for x in base_link:
    if x==str(OLD/'batched-sink'):cmd.append(str(ROOT/name))
    elif x==str(OLD/'context.o'):cmd.append(str(ROOT/'context.o'))
    elif x==str(OLD/'graph-test.o'):cmd.append(str(probe))
    elif x.startswith('-Wl,-map,'):cmd.append('-Wl,-map,'+str(ROOT/(name+'.map')))
    elif not gtest and x.endswith(('libgtest.a','libgtest_main.a')):continue
    else:cmd.append(x)
  if patched:cmd.insert(cmd.index(str(SDK/'lib/libmlx.a')),str(ROOT/'common.o'))
  run(name+'-link',cmd)
def build():
  assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
  (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
  if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
  compile('common.after.cpp','common.o',True)
  compile('src/compute_route_apple/apple_context.cc','context.o')
  compile('tests/compute_route_apple/context_test.cc','canonical.o')
  compile('large_prepare.cc','large.o');compile('reshape_controls.cc','controls.o')
  link('before-planner',ROOT/'canonical.o',False,True)
  link('canonical',ROOT/'canonical.o',True,True)
  link('before-controls',ROOT/'controls.o',False)
  link('controls',ROOT/'controls.o')
  link('large-prepare',ROOT/'large.o')
  link('small-fp4',FP4/'probe.o');link('small-fp8',FP8/'probe.o')
  paths=[ROOT/'context.o',ROOT/'common.o',ROOT/'canonical.o',FP4/'probe.o',FP8/'probe.o',SDK/'lib/libmlx.a']
  (ROOT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
def test():
  p=run('before-planner-test',[ROOT/'before-planner','--gtest_filter=AppleRegion.BroadcastScalarReshapeKeepsOneStoredElementAcrossWideAxes'],'failure')
  assert b'Value of: copy' in p.stdout and b'Actual: true' in p.stdout
  run('before-controls-test',[ROOT/'before-controls'])
  run('canonical-test',[ROOT/'canonical','--gtest_filter=AppleRegion.*'])
  run('controls-test',[ROOT/'controls'])
  run('large-prepare-test',[ROOT/'large-prepare'])
  run('small-fp4-test',[ROOT/'small-fp4'])
  assert (ROOT/'output.bf16').read_bytes()==(FP4/'new-output.bf16').read_bytes()
  run('small-fp8-test',[ROOT/'small-fp8'])
  assert (ROOT/'output.f32').read_bytes()==(FP8/'new-output.f32').read_bytes()
  (ROOT/'comparison.json').write_text(json.dumps(dict(fp4_bits_equal=True,fp8_bits_equal=True),indent=2)+'\n')
if __name__=='__main__':{'build':build,'test':test}[sys.argv[1]]()
