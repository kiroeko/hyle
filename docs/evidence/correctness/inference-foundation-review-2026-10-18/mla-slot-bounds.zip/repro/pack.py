from pathlib import Path
import difflib,zipfile,hashlib,json
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
changed={'src/graph_batch/native_paged_slots.h':'slots.before.h','tests/graph_batch/native_paged_node_test.cc':'node-test.before.cc'}
diff=''.join(''.join(difflib.unified_diff((OUT/old).read_text().splitlines(True),(ROOT/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p))for p,old in changed.items())
(OUT/'product-tests.diff').write_text(diff)
(OUT/'summary.txt').write_text('''MLA NativePagedSlots input bounds, Windows MSVC 14.50.35717 x64 host only.
Fix: validate_layouts now bounds each nested cache-input loop by that slot's
actual inputs.size(), preserving both ordinary 3-input and MLA 2-input slots.
No provider, controller, layout, native SDK, or queue change.
Canonical native_paged_node_test.cc adds a type-only native trait to exercise
the actual private NativePagedSlots validator without initializing native work.
Schemas, owned layouts, native MLA recipes and Graph node identities are real.
Same shared cache + same owned layout succeeds; a changed owned layout rejects
in both node orders. Independent cache inputs ignore equal trailing array
storage outside each 2-element span. This last case fails twice with the exact
before header (exit 1); after header complete canonical test TU is 5/5 PASS.
Fresh only batch_paged_native.cc, native_paged_node.cc and test TU; reuse the
already validated current batch_layout host object and original CPU base libs.
No hardware/native/model execution or numerical claim. commands.json and
identities.json record exact commands and source/library SHA256.
Repro: python .scratch/inference-lifecycle-2026-10-18/mla-slot-bounds/run.py
Archive excludes obj, exe and SDK.
''')
files={'source/'+p:ROOT/p for p in changed}
for p in ['src/graph_batch/native_paged_node.cc','src/compute_batch/batch_paged_native.cc','src/compute_batch/batch_layout.cc']:
    files['source/'+p]=ROOT/p
for p in OUT.iterdir():
    if p.suffix in ['.py','.h','.cc','.json','.log','.diff','.txt']:files['repro/'+p.name]=p
out=OUT/'source-results.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
    for name,p in sorted(files.items()):z.write(p,name)
print(json.dumps(dict(path=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest())))
