from pathlib import Path
import importlib.util,json,subprocess,time,hashlib
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cached_cpu',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(cpu)
flags=cpu.hyle_flags(dict(cpu.PINS['mixed'],folder=Path('mixed')))+['/I'+str(ROOT)]
records=[]
def run(tag,command,reject=False):
    command=list(map(str,command));start=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=cpu.ENV,capture_output=True,timeout=120)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,expected_nonzero=reject,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-1200:],flush=True)
    if (p.returncode!=0)!=reject:raise SystemExit(p.returncode or 2)
def compile(source,name):
    obj=OUT/(name+'.obj');run(name+'-compile',[cpu.CL,*flags,source,'/Fo'+str(obj)]);return obj
canonical=ROOT/'tests/graph_batch/native_paged_node_test.cc'
before=OUT/'node-tests-before.cc'
before.write_text(canonical.read_text().replace('"../../src/graph_batch/native_paged_slots.h"','"slots.before.h"'))
program=compile(ROOT/'src/compute_batch/batch_paged_native.cc','program')
node=compile(ROOT/'src/graph_batch/native_paged_node.cc','node')
layout=ROOT/'.scratch/inference-lifecycle-2026-10-18/paged-footprint/layout-after.obj'
libs=[cpu.BASE/'bin/hyle_graph_batch.lib',cpu.BASE/'bin/hyle_graph.lib',*cpu.common_libs(),cpu.BASE/'lib/gtest.lib',cpu.BASE/'lib/gtest_main.lib']
for mode,source in [('before',before),('after',canonical)]:
    tests=compile(source,'tests-'+mode);exe=OUT/(mode+'.exe')
    run(mode+'-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),tests,program,node,layout,*libs,*cpu.SYSTEM])
    run(mode+'-tests',[exe]+(['--gtest_filter=NativePagedGraphNode.DistinctMlaCacheInputsIgnoreStorageOutsideTheirPortSpans']if mode=='before'else[]),reject=mode=='before')
paths=[canonical,ROOT/'src/graph_batch/native_paged_slots.h',ROOT/'src/graph_batch/native_paged_node.cc',ROOT/'src/compute_batch/batch_paged_native.cc',ROOT/'src/compute_batch/batch_layout.cc',layout,*libs]
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
