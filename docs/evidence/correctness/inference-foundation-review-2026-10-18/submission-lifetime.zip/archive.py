"""Freeze current private lifetime sources and the bounded host validation."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

stage = Path(__file__).resolve().parent
root = stage.parents[2]
sources = ["src/graph/plan_state.h", "src/graph/submission.cc", "src/graph/resources.cc",
           "src/graph/resource_episode.h", "src/graph/submission_lifetime.h",
           "tests/graph/region_provider_test.cc"]
docs = ["docs/architecture/compute-design.md", "docs/developer/current-work.md",
        "docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md", "test.ps1"]

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

commands = json.loads((stage / "commands.json").read_text(encoding="utf-8-sig"))
compiled = [row for row in commands if row["tag"].endswith("-compile")]
assert len(compiled) == 8
for row in compiled:
    assert row["exit"] == 0 and row["before"] == row["after"]
    for entry in row["after"]:
        assert identity(entry["path"]) == entry
for name in sources + docs:
    path = stage / "candidate" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, path)
diff = []
for name in sources:
    before = stage / "before" / name
    old = before.read_text(encoding="utf-8").splitlines(keepends=True) if before.exists() else []
    new = (root / name).read_text(encoding="utf-8").splitlines(keepends=True)
    diff.extend(difflib.unified_diff(old, new, fromfile="before/"+name, tofile=name))
(stage / "final-source.diff").write_text("".join(diff), encoding="utf-8")
record = {"files": [identity(root / name) for name in sources],
          "compiled_host_tus": 8, "tests": 73, "failures": 0,
          "cold_cost": "resource preparation adds one owner allocation; ordinary no-resource path adds no allocation",
          "scope": "same original synchronous resource path and common private lifetime; generic Graph async remains pending",
          "not_run": "macOS/Linux, actual native GPU, full model, performance",
          "cache_records": ["submission-frontier.zip", "completion-handoff.zip"]}
(stage / "final-source-identities.json").write_text(json.dumps(record, indent=2)+"\n", encoding="utf-8")
archive = root / "docs/evidence/correctness/inference-foundation-review-2026-10-18/submission-lifetime.zip"
excluded = {".obj", ".exe", ".map", ".lib", ".exp", ".pdb", ".zip", ".pyc"}
entries = []
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(stage.rglob("*")):
        if not path.is_file() or path.suffix.lower() in excluded or "__pycache__" in path.parts or path.name == "archive-receipt.json":
            continue
        name = path.relative_to(stage).as_posix()
        output.write(path, name)
        entries.append(name)
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for name in sources:
        assert saved.read("candidate/"+name) == (root / name).read_bytes()
data = archive.read_bytes()
receipt = {"path": str(archive.relative_to(root)), "bytes": len(data), "entries": len(entries),
           "sha256": hashlib.sha256(data).hexdigest()}
(stage / "archive-receipt.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
