"""Reuse the matched host validation closure for the private lifetime move."""
from pathlib import Path
import importlib.util
import json
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRIOR = OUT.parent / "submission-frontier/windows"
spec = importlib.util.spec_from_file_location("frontier_validation", PRIOR / "run.py")
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.OUT = OUT
rows = driver.read(PRIOR / "commands.json")
driver.BASE = next(row["command"] for row in reversed(rows)
                   if row["tag"] == "controls-link" and row["exit"] == 0)
retained = OUT.parent / "async-progress/retained/retained_completion.obj"
driver.BASE = [driver.BASE[0], str(retained), *driver.BASE[1:]]
driver.ABI_HEADERS = (*driver.ABI_HEADERS, "src/graph/submission_lifetime.h")

def run_tests():
    selected = driver.read(PRIOR / "summary.json")["filter"] + ":SubmissionLifetime.*"
    driver.run("controls-run", [OUT / "controls.exe", "--gtest_color=no",
        "--gtest_filter=" + selected, "--gtest_output=json:" + str(OUT / "results.json")])
    result = driver.read(OUT / "results.json")
    assert not result["failures"] and not result["errors"]
    driver.save("summary.json", {"tests": result["tests"], "failures": result["failures"],
        "errors": result["errors"], "filter": selected, "fresh_host_tus": 8,
        "sdk_rebuilt": False, "scope": "host private core and original frontier/resource regressions; no Graph async integration",
        "not_run": "macOS/Linux, actual native GPU, full model and performance comparison"})
    print(result["tests"], "tests passed", flush=True)

if __name__ == "__main__":
    {"core": driver.core, "tests": driver.tests, "link": driver.link,
     "run": run_tests,
     "resources": lambda: driver.compile_one("src/graph/resources.cc", "resources", driver.prior("resources-compile")),
     "region-test": lambda: driver.compile_one("tests/graph/region_provider_test.cc", "region_provider_test", driver.prior("region_provider_test-compile"))}[sys.argv[1]]()
