#include "hyle/graph/batch.h"
#include "../../src/graph_batch/native_paged_slots.h"
#include <gtest/gtest.h>
#include <algorithm>
#include <array>

namespace {
namespace c=hyle::compute;namespace g=hyle::graph;
template<std::size_t N>hyle::Result<std::array<c::TensorDesc,N>> input_descriptions(
    const c::NativePagedBatchProgram&program,const c::BatchLayoutVersion&layout){
  std::array<c::TensorDesc,N> result;
  for(std::size_t port=0;port<N;++port){
    HYLE_ASSIGN_OR_RETURN(result[port],program.input_description(layout,port));
  }
  return result;
}
// validate_layouts only inspects owned schemas/layouts and input IDs. These
// type-only native placeholders ensure the test cannot initialize native work.
struct LayoutOnlyTraits final {
  using Context=int;using Memory=int;using Invocation=int;using Program=int;
  using View=c::ConstTensorView;using Submission=c::Completion;
  using CopyInvocation=c::CopyBatchInvocation;using CopyUpdate=c::CopyBatchUpdate;
  using CopyAccess=c::detail::CopyStreamAccess;
};
using LayoutSlots=g::batch::detail::NativePagedSlots<LayoutOnlyTraits>;
void add_layout_slot(LayoutSlots&slots,const g::batch::NativePagedNodeBinding&binding,
                     std::span<const std::size_t> inputs){
  auto*slot=slots.allocator.construct<LayoutSlots::Slot>(slots.allocator,0,binding,slots.slots.size(),inputs);
  ASSERT_NE(slot,nullptr);slots.slots.emplace_back(slot,LayoutSlots::Delete{slots.allocator});
}
struct MlaLayouts final {
  c::BatchSchema schema=c::BatchSchema::create_mla({.max_kv_rows=16,.max_pages=2,.max_page_refs=2,.query_heads=64}).value();
  c::NativePagedBatchProgram recipe=c::NativePagedBatchProgram::prepare(schema,{.max_host_metadata_bytes=8}).value();
  g::Graph graph;std::array<g::NodeId,2> nodes;
  explicit MlaLayouts(bool shared=true){
    const auto selected=layout();const auto descriptions=input_descriptions<2>(recipe,selected).value();
    auto builder=g::GraphBuilder::create().value();auto query=builder.input(descriptions[0]).value();
    auto cache=builder.input(descriptions[1]).value();
    auto descriptor=g::batch::native_paged_mla_attention(recipe,selected).value();
    for(unsigned i=0;i<2;++i){
      if(i && !shared)cache=builder.input(descriptions[1]).value();
      const std::array ports{query,cache};nodes[i]=builder.add_node(c::Operation::custom(descriptor),ports).value();
      builder.publish(builder.result(nodes[i]).value()).IgnoreError();
    }
    graph=std::move(builder).finish().value();
  }
  c::BatchLayoutVersion layout(int tail=1)const{
    const std::array<std::int32_t,2> ptr{0,1};const std::array<std::int32_t,1> pages{0},tails{tail};
    return schema.version({ptr,ptr,pages,tails}).value();
  }
};
TEST(NativePagedGraphNode, SharedMlaCacheInputsNeedTheSameOwnedLayout){
  MlaLayouts data;auto old=data.layout(),next=data.layout(2);
  const std::array bindings{g::batch::NativePagedNodeBinding{data.nodes[0],data.recipe,old,{}},
                            g::batch::NativePagedNodeBinding{data.nodes[1],data.recipe,old,{}}};
  const std::array<std::size_t,2> first{0,7},second{1,7};
  LayoutSlots slots(hyle::mem::system_allocator());add_layout_slot(slots,bindings[0],first);add_layout_slot(slots,bindings[1],second);
  EXPECT_TRUE(slots.validate_layouts(std::array{g::batch::NodeLayout{bindings[0].node,old},g::batch::NodeLayout{bindings[1].node,old}}).ok());
  EXPECT_TRUE(slots.validate_layouts(std::array{g::batch::NodeLayout{bindings[0].node,old},g::batch::NodeLayout{bindings[1].node,next}}).IsInvalidArgument());
  EXPECT_TRUE(slots.validate_layouts(std::array{g::batch::NodeLayout{bindings[1].node,next},g::batch::NodeLayout{bindings[0].node,old}}).IsInvalidArgument());
}
TEST(NativePagedGraphNode, DistinctMlaCacheInputsIgnoreStorageOutsideTheirPortSpans){
  MlaLayouts data(false);auto old=data.layout(),next=data.layout(2);
  const std::array bindings{g::batch::NativePagedNodeBinding{data.nodes[0],data.recipe,old,{}},
                            g::batch::NativePagedNodeBinding{data.nodes[1],data.recipe,old,{}}};
  // The third storage word is deliberately equal, but it is not a port of
  // either two-input MLA node and must never participate in alias checking.
  const std::array<std::size_t,3> first{0,7,99},second{1,8,99};
  LayoutSlots slots(hyle::mem::system_allocator());
  add_layout_slot(slots,bindings[0],std::span(first).first(2));add_layout_slot(slots,bindings[1],std::span(second).first(2));
  EXPECT_TRUE(slots.validate_layouts(std::array{g::batch::NodeLayout{bindings[0].node,old},g::batch::NodeLayout{bindings[1].node,next}}).ok());
  EXPECT_TRUE(slots.validate_layouts(std::array{g::batch::NodeLayout{bindings[1].node,next},g::batch::NodeLayout{bindings[0].node,old}}).ok());
}
TEST(NativePagedGraphNode, EncodedUnequalValueOutputKeepsScaleAndWindowRecipe){
  c::BatchCapacity cap{.max_query_rows=2,.max_kv_rows=2,.query_heads=2,.kv_heads=1,
      .qk_head_dim=64,.value_head_dim=128};
  cap.output_type=c::DataType::kBFloat16;cap.key_storage=cap.value_storage=c::CacheStorage::q8_0().value();
  auto schema=c::BatchSchema::create(cap);ASSERT_TRUE(schema);
  const std::array<std::int32_t,2> q{0,2},k{0,1};const std::array<std::int32_t,1> ids{0},tail{2};
  auto layout=schema->version({q,k,ids,tail});ASSERT_TRUE(layout);
  auto recipe=c::NativePagedBatchProgram::prepare(*schema,{.max_host_metadata_bytes=4,.scale=.125F,.window_left=0});ASSERT_TRUE(recipe);
  auto descriptor=g::batch::native_paged_attention(*recipe,*layout);ASSERT_TRUE(descriptor);
  EXPECT_EQ(descriptor->program.window_left(),0);EXPECT_EQ(descriptor->program.schema().capacity().key_storage,*c::CacheStorage::q8_0());
  auto descriptions=input_descriptions<3>(*recipe,*layout);ASSERT_TRUE(descriptions);
  std::array<c::TensorDesc,1> output;
  ASSERT_TRUE(descriptor->infer_output_descriptions(*descriptions,output).ok());
  EXPECT_EQ(output[0].data_type(),c::DataType::kBFloat16);EXPECT_EQ(output[0].dimensions()[2],128);
  auto altered=(*descriptions)[1];std::array inputs{(*descriptions)[0],altered,altered};
  EXPECT_FALSE(descriptor->infer_output_descriptions(inputs,output).ok());
}
TEST(NativePagedGraphNode, TruthfulPhysicalRootsAndActivePackedOutput) {
  const c::BatchCapacity cap{.max_requests=2,.max_query_rows=11,.max_kv_rows=95,
      .max_pages=4,.max_page_refs=8,.query_heads=8,.kv_heads=2,.qk_head_dim=256,.value_head_dim=256};
  auto schema=c::BatchSchema::create(cap);ASSERT_TRUE(schema);
  const std::array<std::int32_t,3> q{0,1,5},k{0,3,6};
  const std::array<std::int32_t,6> pages{2,0,2,1,3,1};
  const std::array<std::int32_t,2> tails{15,16};
  auto layout=schema->version({q,k,pages,tails});ASSERT_TRUE(layout);
  auto recipe=c::NativePagedBatchProgram::prepare(*schema,{.max_host_metadata_bytes=32});ASSERT_TRUE(recipe);
  auto descriptor=g::batch::native_paged_attention(*recipe,*layout);ASSERT_TRUE(descriptor);
  EXPECT_EQ(layout->facts().kv_rows,95U); // Logical rows exceed physical64.
  auto descriptions=input_descriptions<3>(*recipe,*layout);ASSERT_TRUE(descriptions);
  EXPECT_EQ((*descriptions)[0].dimensions()[0],5);
  std::array<c::TensorDesc,1> output;
  ASSERT_TRUE(descriptor->infer_output_descriptions(*descriptions,output).ok());
  auto padded=*descriptions;padded[0]=c::batch_query_description(cap).value();
  EXPECT_TRUE(descriptor->infer_output_descriptions(padded,output).IsInvalidArgument());
  const std::array<std::int64_t,3> expected{5,8,256};ASSERT_EQ(output[0].dimensions().size(),expected.size());
  EXPECT_TRUE(std::equal(expected.begin(),expected.end(),output[0].dimensions().begin()));
  auto builder=g::GraphBuilder::create();ASSERT_TRUE(builder);
  std::array<g::ValueId,3> inputs;
  for(unsigned i=0;i<3;++i){auto id=builder->input((*descriptions)[i]);ASSERT_TRUE(id);inputs[i]=*id;}
  auto node=builder->add_node(c::Operation::custom(*descriptor),inputs);ASSERT_TRUE(node);
  auto value=builder->result(*node);ASSERT_TRUE(value);ASSERT_TRUE(builder->publish(*value).ok());
  auto graph=std::move(*builder).finish();ASSERT_TRUE(graph);EXPECT_EQ(graph->input_count(),3U);
  auto description=graph->value_spec(*value);ASSERT_TRUE(description);auto concrete=description->concrete_description();ASSERT_TRUE(concrete);EXPECT_EQ(*concrete,output[0]);
  auto foreign=c::BatchSchema::create(cap);ASSERT_TRUE(foreign);auto foreign_layout=foreign->version({q,k,pages,tails});ASSERT_TRUE(foreign_layout);
  EXPECT_FALSE(g::batch::native_paged_attention(*recipe,*foreign_layout));
}
TEST(NativePagedGraphNode, EmptyQueryKeepsTrueCacheCapacityAndRejectsForgedRoots) {
  auto schema=c::BatchSchema::create({.max_query_rows=4,.max_pages=3,.max_page_refs=3,.query_heads=8,.kv_heads=2,.qk_head_dim=64,.value_head_dim=64});ASSERT_TRUE(schema);
  const std::array<std::int32_t,2> empty{0,0};const std::array<std::int32_t,1> tail{0};
  auto layout=schema->version({empty,empty,{},tail});ASSERT_TRUE(layout);
  auto recipe=c::NativePagedBatchProgram::prepare(*schema,{.max_host_metadata_bytes=12});ASSERT_TRUE(recipe);
  auto descriptor=g::batch::native_paged_attention(*recipe,*layout);ASSERT_TRUE(descriptor);
  auto descriptions=input_descriptions<3>(*recipe,*layout);ASSERT_TRUE(descriptions);
  EXPECT_EQ((*descriptions)[0].dimensions()[0],0);
  EXPECT_EQ((*descriptions)[1],c::batch_cache_description(*schema,c::BatchCacheRole::kKey).value());
  std::array<c::TensorDesc,1> output;ASSERT_TRUE(descriptor->infer_output_descriptions(*descriptions,output).ok());
  EXPECT_EQ(output[0].dimensions()[0],0);
  auto forged=*descriptions;
  auto expanded=c::TensorDesc::dense(c::DataType::kFloat16,std::array<std::int64_t,4>{4,16,2,64});ASSERT_TRUE(expanded);forged[1]=*expanded;
  EXPECT_FALSE(descriptor->infer_output_descriptions(forged,output).ok());
}
TEST(NativePagedGraphNode, GraphOwnsRecipeAndLayoutAfterBuilderInputsDie) {
  g::Graph graph;g::NodeId node;
  {
    auto schema=c::BatchSchema::create({.max_query_rows=1,.max_kv_rows=16,
        .max_pages=1,.max_page_refs=1,.query_heads=2,.kv_heads=1,
        .qk_head_dim=64,.value_head_dim=64}).value();
    const std::array<std::int32_t,2> ptr{0,1};
    const std::array<std::int32_t,1> page{0},tail{16};
    auto layout=schema.version({ptr,ptr,page,tail}).value();
    auto recipe=c::NativePagedBatchProgram::prepare(schema,
        {.max_host_metadata_bytes=4,.scale=.125F}).value();
    auto descriptor=g::batch::native_paged_attention(recipe,layout).value();
    const auto descriptions=input_descriptions<3>(recipe,layout).value();
    auto builder=g::GraphBuilder::create().value();std::array<g::ValueId,3> inputs;
    for(unsigned i=0;i<3;++i)inputs[i]=builder.input(descriptions[i]).value();
    node=builder.add_node(c::Operation::custom(descriptor),inputs).value();
    ASSERT_TRUE(builder.publish(builder.result(node).value()).ok());
    graph=std::move(builder).finish().value();
  }
  auto copy=graph;graph={};
  const auto operation=copy.operation(node);ASSERT_TRUE(operation);
  const auto descriptor=operation->custom_as<g::batch::NativePagedAttention>();
  ASSERT_TRUE(descriptor);EXPECT_TRUE(descriptor->program.schema().owns(descriptor->layout));
  auto descriptions=input_descriptions<3>(descriptor->program,descriptor->layout);ASSERT_TRUE(descriptions);
  std::array<c::TensorDesc,1> output;
  ASSERT_TRUE(descriptor->infer_output_descriptions(*descriptions,output).ok());
  EXPECT_EQ(output[0].dimensions()[0],1);EXPECT_EQ(descriptor->program.scale(),.125F);
}
} // namespace
