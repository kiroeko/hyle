from pathlib import Path
import difflib,hashlib,json,shutil
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
before=json.loads((OUT/'before-identities.json').read_text(encoding='utf-8-sig'))
paths=[row['path'] for row in before]+['tests/graph_batch/paged_semantics_consumer.cc']
identities=[];diff=[]
for source in paths:
 path=ROOT/source;data=path.read_bytes();candidate=OUT/'candidate'/source
 candidate.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,candidate)
 identities.append(dict(path=source,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 original=OUT/'before'/source
 diff.extend(difflib.unified_diff(original.read_text(encoding='utf-8').splitlines(True) if original.exists() else [],
  path.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+source,tofile='candidate/'+source))
(OUT/'source.diff').write_text(''.join(diff),encoding='utf-8')
(OUT/'candidate-identities.json').write_text(json.dumps(identities,indent=2)+'\n',encoding='utf-8')
summary=dict(status='source_ready_not_compiled',
 consumer='tests/graph_batch/paged_semantics_consumer.cc',
 invariant='One immutable Graph object compiled twice using graph::batch::compile. No backend macro changes its math operation, options or payload ports.',
 geometry=dict(dtype='F16',encoding='Q8_0',depth=64,heads=8,kv_heads=2,page_size=16,
  requests=2,capacity_query_rows=24,active_query_rows=[18,2,0],slots_per_endpoint=2),
 preserved=['Q/K/V only; metadata prepared by selected implementation.',
  'Actual typed initial and updated layout from the same original schema; exact frames and wrong-layout rejection.',
  'CPU Abs/Cast -> page -> CPU Cast/Neg. Native and shared page runtime mode plus blocks_host assertions.',
  'Independent FP64 oracle decodes the uploaded Q8_0 bytes. F16 absolute tolerance0.002.',
  'Two slots retain old outputs across the other slot execution; old output rejects prepare/replay.',
  'Release observations then strict original same-bindings replay without bind/prepare.',
  'After output retirement cold layout update and reuse of the original first slot.',
  'Nonempty frames exactly three physical pages; unused page4 writer held. Q0/ref0 holds every arena page writer.',
  'Old Direct/expert recipe comparisons and legacy joint controls retained; Graph descriptor stores only layout and math options.'],
 fresh_test_tus=['tests/graph_batch/native_paged_node_test.cc','tests/graph_batch/native_paged_joint_consumer.cc',
  'tests/compute_batch/pending_paged_receiver_native_consumer.cc','tests/compute_batch/encoded_page_native_consumer.cc',
  'tests/compute_batch/public_mla_native_consumer.cc','tests/graph_batch/native_paged_joint_risks.cc',
  'tests/graph_batch/paged_semantics_consumer.cc'],
 command_driver='.scratch/architecture-refactor-2026-10-18/native-page-semantics/windows/run.py',
 command_plan=['python <driver> compile <fresh_test_tus>',
  'python <driver> link schema ready pending same-graph',
  'python <driver> run schema same-graph ready pending empty'],
 baseline='.scratch/architecture-refactor-2026-10-18/native-active-queries/windows/matched-link-base.json',
 limitations=['No compilation or runtime executed by this agent in this source migration step.',
  'Root must use the final matching new public/BatchProvider/private bridge objects before linking.',
  'Legacy NativePagedNodeBinding is preserved only for remaining original joint/Direct controls; not added as compatibility to the new math descriptor.'])
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(identities),summary_sha256=hashlib.sha256((OUT/'summary.json').read_bytes()).hexdigest())))
