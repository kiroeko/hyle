"""Incremental host-only overlays over the retained active-query closure."""
from pathlib import Path
import importlib.util
import json
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/native-active-queries/windows'
spec = importlib.util.spec_from_file_location('active_query_driver', BASE / 'run.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
recipes = driver.recipes()
for row in json.loads((ROOT / '.scratch/architecture-refactor-2026-10-18/admitted-queue-sequence/cuda/compile-recipes.json').read_text(encoding='utf-8')):
    recipes.setdefault(row['source'], row['command'])
# Include exact flags from the latest retained owner where available.
for row in json.loads((BASE / 'commands.json').read_text()):
    if row.get('exit') or not row.get('tag', '').endswith('-compile'):
        continue
    source = next((x for x in row['command'] if x.lower().endswith('.cc')), None)
    if source:
        recipes[Path(source).relative_to(ROOT).as_posix()] = row['command']
recipes.setdefault('src/graph_route_cpu_cuda/compile.cc', recipes['src/graph_route_cuda/cuda_context.cc'])
recipes.setdefault('src/graph_route_cpu_vulkan/compile.cc', recipes['src/graph_route_vulkan/native_paged_region.cc'])
driver.OUT = OUT
driver.BASE = BASE

def register(source, template=None):
    if source not in recipes:
        recipes[source] = recipes[template or 'tests/graph_batch/native_paged_joint_consumer.cc']

driver.recipes = lambda: recipes

def matched_base():
    baseline = driver.read(BASE / 'matched-link-base.json')
    selected = dict(baseline['selected_sources'])
    compiled = dict(baseline['compiled_source_sha256'])
    for receipt in OUT.glob('*-identity.json'):
        row = driver.read(receipt)
        if row.get('exit') or not row.get('source_unchanged') or 'object' not in row:
            continue
        source = Path(row['source']['path']).relative_to(ROOT).as_posix()
        # CUDA and legacy-wrapper syntax checks are compile-only in this
        # CPU/Vulkan link. Never pull unrelated providers into the image.
        if source not in selected and not source.startswith('tests/'):
            continue
        assert driver.identity(ROOT / source) == row['source'], source
        assert driver.identity(row['object']['path']) == row['object'], source
        selected[source] = row['object']['path']
        compiled[source] = row['source']['sha256']
    for source in selected:
        assert driver.identity(ROOT / source)['sha256'] == compiled[source], source + ' needs fresh owner'
    canonical = {p: s for s, p in baseline['selected_sources'].items()}
    objects = []
    for old in baseline['objects']:
        source = canonical.get(old['path'])
        if source:
            if not source.startswith('tests/'):
                objects.append(selected[source])
        else:
            assert driver.identity(old['path']) == old
            objects.append(old['path'])
    objects = list(dict.fromkeys(objects))
    libs = [x for x in baseline['command'] if x.lower().endswith('.lib')]
    flags = [x for x in baseline['command'][1:] if not x.lower().endswith(('.obj', '.lib'))
             and not x.upper().startswith(('/OUT:', '/MAP:'))]
    command = [baseline['command'][0], *flags, *objects, *libs]
    driver.write('matched-link-base.json', dict(command=command, selected_sources=selected,
        compiled_source_sha256=compiled, objects=[driver.identity(x) for x in objects],
        baseline=driver.identity(BASE / 'matched-link-base.json')))
    return command, selected

driver.matched_base = matched_base

def link(which):
    if which != 'same-graph':
        return driver.link(which)
    source = 'tests/graph_batch/paged_semantics_consumer.cc'
    command, selected = driver.matched_base()
    command = [command[0], '/OUT:' + str(OUT / (which + '.exe')),
               '/MAP:' + str(OUT / (which + '.map')), selected[source], *command[1:]]
    return driver.run(which + '-link', command)

if __name__ == '__main__':
    action, *items = sys.argv[1:]
    for item in items:
        if action == 'compile':
            register(item)
            code = driver.compile_one(item)
        elif action == 'link':
            code = link(item)
        elif action == 'run':
            if item == 'schema':
                code = driver.run('schema-run', [OUT / 'schema.exe', '--gtest_color=no',
                    '--gtest_filter=NativePagedGraphNode.*:PagedGraphNode.*:NativePagedMetadata.InputDescriptionsUseActiveQueriesWithoutAllocatingOrShrinkingCache',
                    '--gtest_output=json:' + str(OUT / 'schema-results.json')])
            elif item == 'same-graph':
                code = driver.run('same-graph-run', [OUT / 'same-graph.exe'], timeout=60)
            else:
                code = driver.execute(item)
        else:
            raise SystemExit('compile <sources> / link <images> / run <cases>')
        if code:
            raise SystemExit(code)
