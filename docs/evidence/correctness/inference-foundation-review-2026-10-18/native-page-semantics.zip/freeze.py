"""Keep small reproducible records and reclaimable-image identities only."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
WINDOWS = STAGE / 'windows'

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def write(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')

commands = json.loads((WINDOWS / 'commands.json').read_text(encoding='utf-8'))
assert len(commands) == 33 and commands[-1]['tag'] == 'same-graph-run'
assert commands[-1]['exit'] == 0
summary = dict(
    status='same_owned_layout_graph_passed_actual_cpu_and_vulkan',
    same_graph=dict(command=33, source='tests/graph_batch/paged_semantics_consumer.cc',
        query_rows=[18,2,0], original_schema_max_query_rows=24,
        data_type='F16', cache='Q8_0', heads=8, kv_heads=2, qk_depth=64, value_depth=64,
        requests=2, slots_per_endpoint=2, cold_variants=3,
        public_compile='graph::batch::compile', payload_ports=3,
        source_graph_is_same_object_for_both_endpoint_compilations=True,
        oracle='Independent FP64 decode/attention over exact cache bytes; unchanged abs budget 0.002',
        observed_max_abs=6.48183836e-5,
        cpu_query_copy_bytes=[0,0,0], vulkan_total_query_copy_bytes=[36864,4096,0],
        physical_query_copy_edges='Host to Staging and Staging to Device; exactly one upload to Device',
        checked=['layout/schema identity', 'actual active Q/output', 'same-bindings strict replay',
            'two slots', 'old GraphOutput gates', 'layout/request repartition update',
            'foreign-layout frame rejection', 'unreferenced-page writer retention',
            'all 10 page writers held at Q0/ref0', 'actual CPU blocking / native nonblocking runtime']),
    regressions=dict(schema=dict(command=27, tests=7, failures=0),
        ready=dict(command=28, episodes=64), pending=dict(command=29, steps=64),
        empty=dict(command=30, graph_and_direct_zero_lease_control=True)),
    corrected_failures=[
        dict(command=14, kind='MSVC /WX local-name shadowing', fix='rename two expert branch locals'),
        dict(command=18, kind='compile-only driver missing CUDA include flags', fix='reuse actual CUDA route flags'),
        dict(command=26, kind='fixture duplicated the same CPU execution source',
            fix='one CPU target; two actual targets only for CPU+Vulkan; product admission unchanged')],
    retained_limits=[
        'No new full-model numerical or tokens/s result; existing Qwen discrepancy remains unresolved.',
        'CUDA FlashInfer and route wrappers compile-only this batch; no CUDA numerical run.',
        'No new Apple/Linux compile or numerical run this batch.',
        'Same-layout metadata sharing saves uploads; per-node mirror/staging capacity remains reserved.',
        'Original Queue wrapper cold-planning/copy borrow still requires a stable address.',
        'FlashInfer has no empty-cache opt-in in this batch; absence remains a truthful decline.',
        'Apple plain BF16 two-pass partial precision remains a source-review boundary, not a new verified guarantee.',
        'Legacy Apple/Vulkan joint execution drivers remain pending migration/deletion.',
        'No new mixed ready/pending per-port numerical test or full accepted-failure injection matrix.'],
    native_sdk_shader_kernel_rebuilt=False,
    contract_versions=dict(batch_planning=6, mla_batch_planning=4, provider_contract=16, region_spi=26),
)
write(WINDOWS / 'summary.json', summary)

root_files = ['src/graph_batch/native_paged_nodes.h',
    'include/hyle/compute/detail/batch_provider.h', 'src/compute_provider_ggml/native_batch.cc',
    'src/compute_provider_flashinfer/flashinfer_provider.cc', 'src/graph_batch/region_adapter.h']
diff = []
for source in root_files:
    before = STAGE / 'root/before' / source
    after = ROOT / source
    if after.exists():
        target = STAGE / 'root/candidate' / source
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(after, target)
    diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
        after.read_text(encoding='utf-8').splitlines(True) if after.exists() else [],
        fromfile='before/' + source, tofile='candidate/' + source))
(STAGE / 'root/source.diff').write_text(''.join(diff), encoding='utf-8')

sources = set(root_files)
for scope in ['common-design', 'native-design', 'consumer-design']:
    base = STAGE / scope / 'candidate'
    if base.exists():
        sources.update(p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file())
sources.update(['docs/architecture/compute-design.md', 'docs/developer/current-work.md',
    'docs/user/batch-attention.md', 'test.ps1'])
for source in sources:
    path = ROOT / source
    if path.exists() and (source.startswith('docs/') or source == 'test.ps1'):
        target = STAGE / 'root/candidate' / source
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
write(STAGE / 'final-source-identities.json', [identity(ROOT / p) for p in sorted(sources) if (ROOT / p).exists()])

maps = {}
patterns = [r'\?native_paged_attention@batch@graph@hyle@@',
    r'\?native_paged_mla_attention@batch@graph@hyle@@',
    r'\?compile@detail@batch@graph@hyle@@', r'descriptions@NativePagedBatchProgram']
for name in ['same-graph', 'schema', 'ready', 'pending']:
    text = (WINDOWS / (name + '.map')).read_text(encoding='utf-8', errors='replace')
    matches = [line for line in text.splitlines() if any(re.search(p, line) for p in patterns)]
    assert not matches, name
    maps[name] = dict(map=identity(WINDOWS / (name + '.map')), forbidden_patterns=patterns, matches=matches)
write(WINDOWS / 'removed-api-map-check.json', maps)
write(WINDOWS / 'final-image-identities.json', [identity(p) for p in WINDOWS.iterdir() if p.suffix in ['.exe','.map','.exp','.lib']])
write(WINDOWS / 'retained-objects.json', [identity(p) for p in WINDOWS.glob('*.obj')])
write(STAGE / 'cleanup.json', dict(files=[identity(p) for p in sorted(WINDOWS.iterdir())
    if p.suffix in ['.exe','.map','.exp','.lib']]))

destination = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-page-semantics.zip'
entries = []
for path in sorted(STAGE.rglob('*')):
    if not path.is_file() or path.suffix in ['.obj','.exe','.map','.exp','.lib','.pyc'] or '__pycache__' in path.parts:
        continue
    if path.name in ['archive-receipt.json','cleanup-result.json','archive-entries.json']:
        continue
    entries.append(path)
write(STAGE / 'archive-entries.json', [dict(identity(p), entry=p.relative_to(STAGE).as_posix()) for p in entries])
entries.append(STAGE / 'archive-entries.json')
with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in entries:
        archive.write(path, path.relative_to(STAGE).as_posix())
receipt = identity(destination)
receipt['path'] = destination.relative_to(ROOT).as_posix()
receipt['entries'] = len(entries)
write(STAGE / 'archive-receipt.json', receipt)
print(json.dumps(receipt))
