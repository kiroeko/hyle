# Native page semantics and selected implementation boundary

This stage implements the agreed ordinary Graph descriptor change. It does not add a runtime, executor, slot, compatibility alias, neutral recipe owner, or numerical kernel. Compilation and actual consumers belong to the parent/configuration stage; this stage ran only source checks and an in-memory MLX manifest replay.

## Public mathematical description

`graph::batch::PagedAttentionOptions` contains `scale`, `causal`, `window_left`, and `allow_bf16_partials`. `PagedAttention` / `PagedMlaAttention` hold only an owned initial `BatchLayoutVersion` and those mathematical options. The layout already retains its exact `BatchSchema`; another recipe owner would duplicate that ownership. Payload ports are Q/K/V and Q/compact-cache, respectively. Q/output use active query rows. Cache descriptors remain truthful physical capacity. Typed ready/pending page permissions remain separate from shape/layout ownership.

The old Graph `NativePagedOptions`, `NativePagedAttention`, `NativePagedMlaAttention` and factories are removed, with new IDs. No aliases remain. `NativePagedNodeBinding` is deliberately still present for the old driver audit being migrated by the parent. The low-level Compute descriptors and expert Direct native recipe are not renamed in this change: their explicit metadata/resource contracts are real expert capabilities, not a second ordinary Graph coordinator.

Inference validates actual owned layout/cache role, arity, exact active-Q/cache descriptions, finite scale, causal/window consistency and output extent. It does not add page16 or an implementation dtype/head-domain gate. `BatchSchema` currently admits F16/BF16 Q/output itself; this change does not claim new F32 schema support.

## Why the old recipe restriction was in the wrong ordinary boundary

`NativePagedBatchProgram::prepare` currently requires paged/page16/F16-or-BF16 before constructing only immutable schema/options/three fixed descriptors and an index-byte count. It performs no device query or native preparation. `version()` validates an exact same-schema owned layout; `indices()` lazily exports compact page IDs. The page16 restriction is therefore an expert carrier limitation, not the general page mathematics. General `BatchCapacity` already allows any valid nonzero page size; CPU plans carry the actual page size. Apple/Vulkan kernels still have real hardcoded page16 addressing and must retain their qualification.

The ordinary Graph no longer requires constructing that expert recipe. Vulkan discovery/resource qualification reads only layout/options and its real finite cache/geometry domain. Exact compilation derives one native recipe per artifact from the original schema/math, allocator and Graph resource budget. Its compact table cap is the checked schema page-reference byte count. Slot metadata uses the original Graph allocation scope, without a second public per-node cap. No recipe is prepared during discovery or replay. Original controllers/metadata/page guards/generated output/completion retention remain unchanged.

## Mathematical policy and implementation differences

| Fact | Common CPU implementation | CUDA FlashInfer | Apple native page | Vulkan native page |
|---|---|---|---|---|
| Q/output type | F16/BF16, same type required by handler | F16/BF16, same type | F16/BF16, same type | F16 only |
| KV storage | matching plain Q type or matching Q8_0 | matching plain Q type or FP8 E4M3 with schema-owned positive finite scales | matching plain Q type or matching Q8_0 | matching plain F16 or matching Q8_0 |
| Page size | request PagedRead carries actual schema page size | native spec carries actual page size; final handler qualification remains authoritative | actual page16 address math | actual page16 address math |
| Geometry | D64/128/256, Dq64/Dv128, plain Dq512/576 with Dv512 | D64/128/256 plus finite GQA groups; plain D512 branch; MLA separate | D64/128/256, Dq64/Dv128, plain Dq512/576 Dv512 | same finite depths, F16 domain |
| Scale | mathematical finite scale passed through | positive effective QK scale only; otherwise real decline | finite scale passed through | finite scale passed through |
| Window | causal left window or full noncausal | general batch supports window; MLA rejects non-default window | causal window wired into native primitive | causal window wired into native op parameters |
| MLA | single CKV512/[CKV512,KPE64] physical root; V prefix alias | same packed root; no independent V; window and BF16-partial options currently rejected | same physical row, V is a strided CKV prefix | same physical row, V is an exact CKV prefix view |

The schema keeps separate query/output types, separate K/V `CacheStorage` including FP8 scale, GQA heads/depths, storage geometry, and MLA cache role. A platform cannot reinterpret Q8_0 as FP8 or row-inline codec bytes, infer MLA merely from dimensions, or materialize the full history as a silent replacement for a native page reader. Unsupported combinations decline at the selected handler.

`allow_bf16_partials` is permission, not a requirement. Local accumulation remains F32; the default preserves residuals across split-KV intermediate storage. CUDA actually enables BF16 partials only in its admitted BF16-query/FP8-KV/page16/causal/full-window/D256 branch with CTA tile64 and split-KV. Other implementations may fulfill true permission with their stricter default. It must not be dropped while migrating the ordinary graph description. Vulkan explicitly requests its original FullF32 flash math plus F32 accumulation, so the new flag needs no expert Direct option there. CUDA MLA currently rejects true; this remains an actual implementation boundary rather than silently changing math.

## Apple source precision risk, not a newly measured defect

The exact current MLX patched SDPA source allocates vector two-pass intermediate payload in `q.dtype()` while sums/maxima are F32. Its page Q8 path explicitly promotes query/output computation to F32 before the final cast; plain BF16 does not. The vector dispatch chooses two-pass for certain architecture/long-history or GQA/long-history cases. Consequently ordinary F32 accumulation alone does not prove F32 split partials for every Apple plain-BF16 page decode. This change adds no Apple Graph page leaf or kernel modification and does not claim that domain satisfies the stricter new policy. A later Apple adapter must prove its chosen branch, decline an unsupported default, or add a narrowly justified native precision path. No tolerance was changed and no new numerical run was made.

`mlx-replay.py` reads the existing pinned archive and the current patch manifest explicitly as UTF-8, applies every unique edit in memory, and verifies every final file SHA. Result: 20 files / 220 edits PASS, pin `1f8e74e3f12f31365464a6867c6579f0e9b29d85`, archive SHA `cb988a5bdc38c798918d042b9b1c6edda3ccc5f23a2155138d3aa5c1b2acc301`, manifest SHA `eb9287cab72e04b233ff301a7256953f498a9e80815e8d36078db8e750800525`. SDPA final SHA `201303cdb8152a414913bf01d543e2226c2ca7c3bf7b295639d7e7ef83e80b9c`.

An earlier investigation script omitted `encoding='utf-8'`, so Windows CP936 decoded the UTF-8 copyright symbol as another character and falsely reported edit59 mismatch. This was an audit-script error, not a product manifest defect. Explicit UTF-8 exact replay above passes without normalization or product edits. `third_party/mlx_cast/patches.json` remains unchanged; no SDK rebuild or dependency-lock update is needed.

## Migration and validation boundary

Affected owners here: `include/hyle/graph/batch.h`, `src/graph_batch/native_paged_node.cc`, `src/graph_route_vulkan/native_paged_region.cc`. `batch.h` also declares the agreed neutral `batch::compile(Graph,CompileEnvironment,CompileOptions)->CompiledGraph`; the common implementation is owned by the other agent. Root/common work must hide shared provider metadata, use the same owned layout/active descriptions, and migrate existing ordinary consumers. Backend plans, Direct native API and native kernel cache remain real adapters.

Keep existing ready/pending, empty-Q0, exact page generations, initialized-prefix, window, encoded cache, compact MLA, old-output and accepted-prefix error controls. Last batch's ready64/pending64/empty+Direct0 success does not by itself validate these new descriptors. Current source checks: old Graph names absent in these three owners; `git diff --check` PASS. Parent owns matched compile/runtime verification. No SDK, kernel, benchmark or model run was started by this agent.
