#include "hyle/graph/batch.h"

#include <array>
#include <cmath>

namespace hyle::graph::batch {
namespace c=compute;
Status NativePagedAttention::infer_output_descriptions(
    std::span<const c::TensorDesc> inputs,std::span<c::TensorDesc> outputs) const noexcept {
  if(!program.valid() || !program.schema().owns(layout) ||
      program.schema().mla_layout()!=c::MlaCacheLayout::kNone)
    return Status::InvalidArgument("native page Graph needs its owned recipe/layout");
  const auto capacity=program.schema().capacity();
  const auto active_query_rows=layout.facts().query_rows;
  HYLE_RETURN_IF_ERROR(c::validate_batch_capacity(capacity));
  if(capacity.storage!=c::BatchStorage::kPaged || capacity.page_size!=16 ||
     (capacity.query_type!=c::DataType::kFloat16 && capacity.query_type!=c::DataType::kBFloat16))
    return Status::Unimplemented("native page Graph schema requires F16/BF16 page16");
  if(inputs.size()!=3 || outputs.size()!=1 || active_query_rows>capacity.max_query_rows ||
     !std::isfinite(program.scale()))
    return Status::InvalidArgument("native page Graph arity/active output/scale differs");
  HYLE_RETURN_IF_ERROR(c::validate_batch_attention_layout(layout,program.causal(),program.window_left()));
  HYLE_ASSIGN_OR_RETURN(auto query,program.input_description(layout,0));
  HYLE_ASSIGN_OR_RETURN(auto keys,program.input_description(layout,1));
  HYLE_ASSIGN_OR_RETURN(auto values,program.input_description(layout,2));
  if(inputs[0]!=query || inputs[1]!=keys || inputs[2]!=values)
    return Status::InvalidArgument("native page Graph needs truthful recipe Q/K/V descriptions");
  HYLE_ASSIGN_OR_RETURN(outputs[0],c::batch_output_description(capacity,active_query_rows));
  return Status::Ok();
}
Result<NativePagedAttention> native_paged_attention(
    const c::NativePagedBatchProgram& program,c::BatchLayoutVersion layout,
    NativePagedOptions options) noexcept {
  if(!program.valid() || !program.schema().owns(layout))
    return std::unexpected(Status::InvalidArgument("native page Graph recipe/layout identity differs"));
  if(program.schema().mla_layout()!=c::MlaCacheLayout::kNone)
    return std::unexpected(Status::InvalidArgument("MLA requires its two-payload Graph operation"));
  HYLE_RETURN_IF_ERROR(c::validate_batch_attention_layout(layout,program.causal(),program.window_left()));
  NativePagedAttention result{program,std::move(layout),std::move(options)};
  std::array<c::TensorDesc,3> inputs;
  for(std::size_t port=0;port<inputs.size();++port){
    HYLE_ASSIGN_OR_RETURN(inputs[port],program.input_description(result.layout,port));
  }
  std::array<c::TensorDesc,1> output;
  HYLE_RETURN_IF_ERROR(result.infer_output_descriptions(inputs,output));
  return result;
}
Status NativePagedMlaAttention::infer_output_descriptions(
    std::span<const c::TensorDesc>inputs,std::span<c::TensorDesc>outputs)const noexcept{
  if(!program.valid() || !program.schema().owns(layout) ||
      program.schema().mla_layout()==c::MlaCacheLayout::kNone)
    return Status::InvalidArgument("native MLA Graph needs its owned recipe/layout");
  const auto cap=program.schema().capacity();
  const auto active_query_rows=layout.facts().query_rows;
  if(cap.storage!=c::BatchStorage::kPaged || cap.page_size!=16 || inputs.size()!=2 || outputs.size()!=1 ||
      active_query_rows>cap.max_query_rows || !std::isfinite(program.scale()))
    return Status::InvalidArgument("native MLA Graph ports/active output/options differ");
  HYLE_RETURN_IF_ERROR(c::validate_batch_attention_layout(layout,program.causal(),program.window_left()));
  HYLE_ASSIGN_OR_RETURN(auto q,program.input_description(layout,0));
  HYLE_ASSIGN_OR_RETURN(auto cache,program.input_description(layout,1));
  if(inputs[0]!=q || inputs[1]!=cache)return Status::InvalidArgument("native MLA Graph needs active Q and truthful compact cache capacity");
  HYLE_ASSIGN_OR_RETURN(outputs[0],c::batch_output_description(cap,active_query_rows));return Status::Ok();
}
Result<NativePagedMlaAttention> native_paged_mla_attention(
    const c::NativePagedBatchProgram&program,c::BatchLayoutVersion layout,
    NativePagedOptions options)noexcept{
  if(!program.valid() || !program.schema().owns(layout) || program.schema().mla_layout()==c::MlaCacheLayout::kNone)
    return std::unexpected(Status::InvalidArgument("native MLA Graph needs its typed recipe/layout"));
  HYLE_RETURN_IF_ERROR(c::validate_batch_attention_layout(layout,program.causal(),program.window_left()));
  NativePagedMlaAttention result{program,std::move(layout),std::move(options)};
  std::array<c::TensorDesc,2> inputs;
  for(std::size_t port=0;port<inputs.size();++port){
    HYLE_ASSIGN_OR_RETURN(inputs[port],program.input_description(result.layout,port));
  }
  std::array<c::TensorDesc,1>output;HYLE_RETURN_IF_ERROR(result.infer_output_descriptions(inputs,output));return result;
}
} // namespace hyle::graph::batch
