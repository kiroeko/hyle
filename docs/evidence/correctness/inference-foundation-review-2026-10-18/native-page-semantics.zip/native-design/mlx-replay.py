from pathlib import Path
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
manifest = ROOT / 'third_party/mlx_cast/patches.json'
archive = ROOT / '.scratch/inference-gaps/g04-g05/metal-lifetime/mlx-1f8e74e3f12f31365464a6867c6579f0e9b29d85.tar.gz'
patches = json.loads(manifest.read_text(encoding='utf-8'))
results = []
with tarfile.open(archive) as source:
    members = {m.name.split('/', 1)[1]: m for m in source.getmembers() if '/' in m.name}
    for patch in patches['files']:
        data = source.extractfile(members[patch['path']]).read().replace(b'\r\n', b'\n')
        assert hashlib.sha256(data).hexdigest() == patch['before_sha256'], patch['path']
        for index, edit in enumerate(patch['edits']):
            before, after = edit['before'].encode('utf-8'), edit['after'].encode('utf-8')
            assert data.count(before) == 1, (patch['path'], index, data.count(before))
            data = data.replace(before, after, 1)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == patch['after_sha256'], patch['path']
        results.append(dict(path=patch['path'], edits=len(patch['edits']), sha256=digest))
        if patch['path'] == 'mlx/backend/metal/scaled_dot_product_attention.cpp':
            lines = data.decode('utf-8').splitlines()
            selected = {i for i, line in enumerate(lines) if any(term in line for term in (
                'array intermediate(', 'sdpa_vector_2pass(s,', "devc == 'd'", 'const bool highdim_cache'))}
            excerpts = [dict(line=i+1, text=lines[i]) for i in sorted(selected)]
receipt = dict(status='PASS', pin='1f8e74e3f12f31365464a6867c6579f0e9b29d85',
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(), files=results,
    attention_excerpts=excerpts, materialized_files=0, sdk_build=False,
    audit_note='Earlier default-encoding read used Windows CP936, misdecoding UTF-8 copyright text. Explicit UTF-8 replay passes; no manifest product defect or edit.')
(OUT / 'mlx-replay.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(status='PASS', files=len(results), edits=sum(x['edits'] for x in results),
    archive_sha256=receipt['archive_sha256'], manifest_sha256=receipt['manifest_sha256']), indent=2))
