from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
cache=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/commands.json').read_text())
cc=next(x['command'] for x in reversed(cache) if x['tag']=='canonical-compile')
ld=next(x['command'] for x in reversed(cache) if x['tag']=='canonical-link')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':cc[0],'CMAKE_C_COMPILER':cc[0]})
toolkit=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
runtime=[str(ROOT/'.scratch/build-compute-v2-dev/bin'),str(toolkit/'bin'),str(toolkit/'bin/x64')]
runtime += [str(Path(x).parent) for x in ld if x.endswith('.lib') and Path(x).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH'];env['VSLANG']='1033'
flags=[x for x in cc if not x.lower().startswith(('/fo','/fp','/fi')) and not x.endswith(('.cc','.cpp'))]
flags+=['/I'+str(ROOT/'src/compute_provider_cuda'),'/DHYLE_ROW_CACHE_DEFAULT_ROUTE']
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,cmd):
 cmd=list(map(str,cmd));stem=tag+'-'+str(1+sum(x['tag']==tag for x in records));start=time.monotonic()
 p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=180)
 (OUT/(stem+'.stdout.log')).write_bytes(p.stdout);(OUT/(stem+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-start));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-5000:],p.stderr.decode(errors='replace')[-1600:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 return p

def build():
 for source,name in [('src/compute_provider_cuda/row_cache_provider.cc','row-provider'),('src/compute_provider_cuda/cuda_provider.cc','cuda-provider'),('tests/compute_provider_cuda/row_cache_test.cc','tests')]:
  run(name+'-compile',[*flags,ROOT/source,'/Fo'+str(OUT/(name+'.obj'))])
 run('kernel-compile',[toolkit/'bin/nvcc.exe','--std=c++20','--gpu-architecture=sm_89','--compiler-bindir',Path(cc[0]).parent,'-Xcompiler=/MD,/EHsc,/Zc:preprocessor,/utf-8','-O2','-DNDEBUG','-DNOMINMAX','-I'+str(ROOT/'src/compute_backend_cuda'),'-c',ROOT/'src/compute_provider_cuda/row_cache_kernel.cu','-o',OUT/'kernel.obj'])
 link()
def link():
 omit={str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch/cuda-cuda_provider.obj'),str(ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/canonical.obj')}
 cmd=[x for x in ld if x not in omit and not x.startswith(('/OUT:','/MAP:'))]
 objs=[ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj']+[OUT/(x+'.obj')for x in ['row-provider','cuda-provider','kernel','tests']]
 run('link',[*cmd,*objs,'/OUT:'+str(OUT/'row-cache.exe'),'/MAP:'+str(OUT/'row-cache.map')])
def test():
 run('identity',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.free','--format=csv'])
 run('tests',[OUT/'row-cache.exe','--gtest_filter=CudaRowCache.*','--gtest_color=no'])
if __name__=='__main__':
 for action in sys.argv[1:] or ['build','test']:globals()[action]()
