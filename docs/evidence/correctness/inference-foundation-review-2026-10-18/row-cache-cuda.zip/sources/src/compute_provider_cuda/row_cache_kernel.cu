#include "row_cache_kernel.h"

#include <algorithm>
#include <cuda_bf16.h>
#include <cuda_fp4.h>
#include <cuda_fp8.h>

#include "device_status_kernel.h"

namespace hyle::compute::cuda_native::row_cache::native {
namespace {
constexpr unsigned kThreads = 128;
unsigned blocks(std::uint64_t count) {
  return static_cast<unsigned>((std::min)(std::uint64_t{65535},
                                         (count + kThreads - 1) / kThreads));
}
__global__ void check_finite(const __nv_bfloat16 *source,
                              std::uint64_t count, unsigned *status) {
  for (auto i = std::uint64_t(blockIdx.x) * blockDim.x + threadIdx.x;
       i < count; i += std::uint64_t(gridDim.x) * blockDim.x)
    if (!isfinite(__bfloat162float(source[i])))
      atomicCAS(status, 0U, static_cast<unsigned>(
          cuda::detail::DeviceStatusCode::kInvalidNumericInput));
}
__global__ void check_ids(const std::int32_t *ids, std::uint64_t count,
                           std::uint64_t rows, unsigned *status) {
  for (auto i = std::uint64_t(blockIdx.x) * blockDim.x + threadIdx.x;
       i < count; i += std::uint64_t(gridDim.x) * blockDim.x)
    if (ids[i] < 0 || std::uint64_t(ids[i]) >= rows)
      atomicCAS(status, 0U, static_cast<unsigned>(
          cuda::detail::DeviceStatusCode::kIndexOutOfRange));
}
// Same F32 bit-ceil rule and SDK code conversions used by the original
// TileLang QAT program. The exponent byte stores this exact power of two.
__device__ unsigned char scale_exponent(float maximum, bool float4) {
  const float raw = float4 ? fmaxf(maximum, 0x1.8p-124F) * (1.F / 6.F)
                           : fmaxf(maximum, 1.e-4F) * (1.F / 448.F);
  const auto bits = __float_as_uint(raw);
  return static_cast<unsigned char>((bits >> 23) + ((bits & 0x7fffffU) != 0));
}
__device__ float scale_value(unsigned char exponent) {
  if (exponent == 255)
    return __uint_as_float(0x7fc00000U);
  // UE8M0 zero denotes 2^-127, rather than IEEE F32 zero.
  return __uint_as_float(exponent == 0 ? 0x00400000U
                                      : unsigned(exponent) << 23);
}
template <bool Float4>
__global__ void encode(const __nv_bfloat16 *source, unsigned char *output,
                        std::uint64_t rows, const unsigned *status) {
  if (*status != 0)
    return;
  constexpr unsigned depth = Float4 ? 128 : 512;
  constexpr unsigned groups = Float4 ? 4 : 7;
  constexpr unsigned row_bytes = Float4 ? 68 : 584;
  const unsigned lane = threadIdx.x & 31;
  for (auto group = std::uint64_t(blockIdx.x) * (kThreads / 32) +
                    threadIdx.x / 32;
       group < rows * groups;
       group += std::uint64_t(gridDim.x) * (kThreads / 32)) {
    const auto row = group / groups;
    const auto part = unsigned(group % groups);
    const auto *input = source + row * depth + part * (Float4 ? 32 : 64);
    auto *target = output + row * row_bytes;
    const float first = __bfloat162float(input[lane]);
    const float second = Float4 ? 0.F : __bfloat162float(input[lane + 32]);
    float maximum = fmaxf(fabsf(first), fabsf(second));
    for (int offset = 16; offset; offset /= 2)
      maximum = fmaxf(maximum, __shfl_xor_sync(0xffffffffU, maximum, offset));
    const auto exponent = scale_exponent(maximum, Float4);
    const auto scale = scale_value(exponent);
    if constexpr (Float4) {
      const float value = fminf(6.F, fmaxf(-6.F, first / scale));
      const float next = __shfl_down_sync(0xffffffffU, value, 1);
      if ((lane & 1U) == 0)
        target[part * 16 + lane / 2] = __nv_cvt_float2_to_fp4x2(
            make_float2(value, next), __NV_E2M1, cudaRoundNearest);
      if (lane == 0)
        target[64 + part] = exponent;
    } else {
      target[part * 64 + lane] = __nv_cvt_float_to_fp8(
          fminf(448.F, fmaxf(-448.F, first / scale)), __NV_SATFINITE, __NV_E4M3);
      target[part * 64 + lane + 32] = __nv_cvt_float_to_fp8(
          fminf(448.F, fmaxf(-448.F, second / scale)), __NV_SATFINITE, __NV_E4M3);
      if (lane == 0)
        target[576 + part] = exponent;
      if (part == 0) {
        // The public byte carrier may start at an odd address.
        for (unsigned channel = lane; channel < 64; channel += 32) {
          const __nv_bfloat16_raw bits = source[row * depth + 448 + channel];
          target[448 + channel * 2] = static_cast<unsigned char>(bits.x);
          target[449 + channel * 2] = static_cast<unsigned char>(bits.x >> 8);
        }
        if (lane == 0)
          target[583] = 0;
      }
    }
  }
}
template <bool Float4, bool Checked>
__global__ void decode(const unsigned char *source, const std::int32_t *ids,
                        __nv_bfloat16 *output, std::uint64_t rows,
                        std::uint64_t count, const unsigned *status) {
  if constexpr (Checked)
    if (*status != 0)
      return;
  constexpr unsigned depth = Float4 ? 128 : 512;
  constexpr unsigned row_bytes = Float4 ? 68 : 584;
  for (auto i = std::uint64_t(blockIdx.x) * blockDim.x + threadIdx.x;
       i < count * depth; i += std::uint64_t(gridDim.x) * blockDim.x) {
    const auto id = ids[i / depth];
    // Unchecked callers promise valid IDs too; never manufacture an OOB address.
    if (id < 0 || std::uint64_t(id) >= rows)
      continue;
    const unsigned channel = unsigned(i % depth);
    const auto *row = source + std::uint64_t(id) * row_bytes;
    if constexpr (!Float4) {
      if (channel >= 448) {
        const auto offset = 448 + (channel - 448) * 2;
        const __nv_bfloat16_raw bits{
            static_cast<unsigned short>(row[offset] | (unsigned(row[offset + 1]) << 8))};
        output[i] = __nv_bfloat16(bits);
        continue;
      }
    }
    float value;
    if constexpr (Float4) {
      const auto packed = row[channel / 2];
      const auto code = static_cast<__nv_fp4_storage_t>(
          (packed >> (4 * (channel & 1U))) & 15U);
      const auto half = __nv_cvt_fp4_to_halfraw(code, __NV_E2M1);
      value = __half2float(__half(half));
    } else {
      __nv_fp8_e4m3 code;
      code.__x = row[channel];
      value = float(code);
    }
    const auto exponent = row[(Float4 ? 64 : 576) + channel / (Float4 ? 32 : 64)];
    output[i] = __float2bfloat16_rn(value * scale_value(exponent));
  }
}
template <bool Float4>
cudaError_t run(Program program, const void *source, const std::int32_t *ids,
                void *output, unsigned *status, cudaStream_t stream) {
  if (program.encode) {
    const auto count = program.rows * (Float4 ? 128U : 512U);
    if (!count)
      return cudaSuccess;
    check_finite<<<blocks(count), kThreads, 0, stream>>>(
        static_cast<const __nv_bfloat16 *>(source), count, status);
    auto error = cudaGetLastError();
    if (error != cudaSuccess)
      return error;
    const auto groups = program.rows * (Float4 ? 4U : 7U);
    const auto grid = unsigned((std::min)(std::uint64_t{65535}, (groups + 3) / 4));
    encode<Float4><<<grid, kThreads, 0, stream>>>(
        static_cast<const __nv_bfloat16 *>(source), static_cast<unsigned char *>(output),
        program.rows, status);
  } else {
    if (!program.selected)
      return cudaSuccess;
    const auto grid = blocks(program.selected * (Float4 ? 128U : 512U));
    if (program.checked) {
      check_ids<<<blocks(program.selected), kThreads, 0, stream>>>(
          ids, program.selected, program.rows, status);
      auto error = cudaGetLastError();
      if (error != cudaSuccess)
        return error;
      decode<Float4, true><<<grid, kThreads, 0, stream>>>(
          static_cast<const unsigned char *>(source), ids,
          static_cast<__nv_bfloat16 *>(output), program.rows, program.selected, status);
    } else
      decode<Float4, false><<<grid, kThreads, 0, stream>>>(
          static_cast<const unsigned char *>(source), ids,
          static_cast<__nv_bfloat16 *>(output), program.rows, program.selected, nullptr);
  }
  return cudaGetLastError();
}
} // namespace
cudaError_t prepare(Program program) noexcept {
  if (program.encode ? !program.rows : !program.selected)
    return cudaSuccess;
  cudaFuncAttributes attributes{};
  if (program.encode) {
    auto error = cudaFuncGetAttributes(&attributes, check_finite);
    if (error != cudaSuccess) return error;
    return program.float4 ? cudaFuncGetAttributes(&attributes, encode<true>)
                          : cudaFuncGetAttributes(&attributes, encode<false>);
  }
  if (program.checked) {
    auto error = cudaFuncGetAttributes(&attributes, check_ids);
    if (error != cudaSuccess) return error;
    return program.float4 ? cudaFuncGetAttributes(&attributes, decode<true, true>)
                          : cudaFuncGetAttributes(&attributes, decode<false, true>);
  }
  return program.float4 ? cudaFuncGetAttributes(&attributes, decode<true, false>)
                        : cudaFuncGetAttributes(&attributes, decode<false, false>);
}
cudaError_t launch(Program program, const void *source, const std::int32_t *ids,
                   void *output, unsigned *status, cudaStream_t stream) noexcept {
  return program.float4 ? run<true>(program, source, ids, output, status, stream)
                        : run<false>(program, source, ids, output, status, stream);
}
} // namespace hyle::compute::cuda_native::row_cache::native
