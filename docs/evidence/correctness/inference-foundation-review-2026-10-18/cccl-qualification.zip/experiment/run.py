from pathlib import Path
import hashlib, importlib.util, json, subprocess, time

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cuda_cache',ROOT/'.scratch/mtp-completion/run.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
flags=c.flags+['/I'+str(ROOT/'src/compute_provider_cuda')]
records=[]
def run(tag,command,allowed=(0,)):
    command=list(map(str,command));start=time.monotonic()
    result=subprocess.run(command,cwd=ROOT,env=c.env,capture_output=True,timeout=120)
    (OUT/(tag+'.stdout.log')).write_bytes(result.stdout)
    (OUT/(tag+'.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag,command=command,exit=result.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,result.returncode,result.stdout.decode(errors='replace')[-1800:],result.stderr.decode(errors='replace')[-1800:],flush=True)
    assert result.returncode in allowed
def compile(source,name):
    obj=OUT/(name+'.obj');run(name+'-compile',[c.cl,*flags,source,'/Fo'+str(obj)]);return obj

test_objects=[compile(ROOT/'tests/compute_provider_cuda'/name,name.removesuffix('.cc'))
              for name in ('collectives_test.cc','gather_collectives_test.cc')]
old=subprocess.check_output(['git','show','HEAD:src/compute_provider_cuda/collectives_provider.cc'],cwd=ROOT).decode()
current=(ROOT/'src/compute_provider_cuda/collectives_provider.cc').read_text()
needle='  const auto *environment = cuda::detail::borrow_environment(backend);'
replacement='''  const auto *actual_environment = cuda::detail::borrow_environment(backend);
  if (!actual_environment) return Status::FailedPrecondition("missing actual CUDA environment");
  auto reported_environment = *actual_environment;
  reported_environment.runtime_version = 13050;
  reported_environment.build_toolkit_version = 13050;
  const auto *environment = &reported_environment;'''
assert old.count(needle)==current.count(needle)==1
native=ROOT/'.scratch/b-cuda-d5/src/compute_provider_cuda/CMakeFiles/hyle_compute_provider_cuda.dir/collectives.cu.obj'
filters='CudaCccl.ScanAxesByteStridesBroadcastAndHighRanks:CudaCccl.TopKFourTypesStableTiesNaNsAndOriginalBits:CudaCccl.OverflowChecksEveryPrefixAndPreservesEntireOutput:CudaCccl.PendingCompletionRetainsPreparedOwnersWithCallerWorkspace:CudaCcclGather.*'
for name,source,expected in [('before-reported-13050',old.replace(needle,replacement),1),
                             ('after-reported-13050',current.replace(needle,replacement),0),
                             ('after-actual',current,0)]:
    path=OUT/(name+'.cc');path.write_text(source)
    provider=compile(path,name)
    exe=OUT/(name+'.exe')
    run(name+'-link',[c.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(exe),provider,native,*test_objects,c.OUT/'operation.obj',*c.libs,
        c.BASE/'lib/gtest_main.lib',c.BASE/'lib/gtest.lib',*c.system])
    run(name+'-test',[exe,'--gtest_filter='+filters,'--gtest_color=no'],(expected,))
identity=[dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
          for path in [ROOT/'src/compute_provider_cuda/collectives_provider.cc',native,*test_objects]]
(OUT/'identities.json').write_text(json.dumps(identity,indent=2)+'\n')
