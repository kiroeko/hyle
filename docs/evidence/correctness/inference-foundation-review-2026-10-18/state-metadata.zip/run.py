from pathlib import Path
import hashlib, importlib.util, json, subprocess, time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cached_cpu', ROOT / '.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu = importlib.util.module_from_spec(spec); spec.loader.exec_module(cpu)
flags = cpu.hyle_flags(dict(cpu.PINS['mixed'], folder=Path('mixed'))) + ['/I' + str(ROOT), '/I' + str(ROOT/'src/compute_state')]
records = []
def run(tag, command, expected=0):
    command = list(map(str, command)); start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=cpu.ENV, capture_output=True, timeout=120)
    (OUT / (tag + '.stdout.log')).write_bytes(p.stdout); (OUT / (tag + '.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag, command=command, exit=p.returncode, seconds=time.monotonic()-start))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-6500:],p.stderr.decode(errors='replace')[-1200:],flush=True)
    if p.returncode != expected: raise SystemExit(p.returncode or 2)
def compile(source, name):
    obj=OUT/(name+'.obj');run(name+'-compile',[cpu.CL,*flags,source,'/Fo'+str(obj)]);return obj

leases=compile(ROOT/'src/compute/resource_leases.cc','leases')
state=compile(ROOT/'src/compute_state/state_versions.cc','state')
tests=compile(ROOT/'tests/compute_state/state_versions_test.cc','versions-tests')
clones=compile(ROOT/'tests/compute_state/state_clone_test.cc','clone-tests')
baseline=OUT/'state.before.cc'
if not baseline.exists():
    baseline.write_bytes(subprocess.check_output(['git','show','HEAD:src/compute_state/state_versions.cc'],cwd=ROOT))
before=compile(baseline,'state-before')
libs=[cpu.BASE/'bin/hyle_compute_state.lib',*cpu.common_libs(),cpu.BASE/'lib/gtest.lib',cpu.BASE/'lib/gtest_main.lib']
for mode,obj in [('before',before),('after',state)]:
    exe=OUT/(mode+'.exe')
    run(mode+'-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(exe),'/MAP:'+str(exe.with_suffix('.map')),obj,leases,tests,clones,*libs,*cpu.SYSTEM])
    if mode=='before':run('before-test',[exe,'--gtest_filter=StateVersions.HostSnapshotsReuseOnlyRetiredExactBlocksWithoutWarmAllocations'],1)
    else:run('after-tests',[exe])
paths=[ROOT/p for p in ['src/compute_state/state_versions.cc','src/compute_state/state_internal.h',
    'src/compute/resource_leases.cc','include/hyle/compute/detail/lease_access.h','tests/compute_state/state_versions_test.cc',
    'tests/compute_state/state_clone_test.cc']]+libs
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
