from pathlib import Path
import hashlib, json, os, platform, subprocess, zipfile

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
paths=['include/hyle/compute/detail/lease_access.h','src/compute/resource_leases.cc',
       'src/compute_state/state_internal.h','src/compute_state/state_versions.cc',
       'tests/compute_state/state_versions_test.cc']
summary={
 'change':'Lazily reuse exact-size one-block host metadata snapshots after real lease retirement; keep immutable versions and escaped/native readers.',
 'bounds':'Idle snapshots remain in retained_blocks, host_snapshot_bytes and backing_bytes. Explicit collect/close and admission pressure reclaim idle blocks. No maximum-sized metadata arena or public object-layout change.',
 'permission':'unique_read_owner is only a precheck; try_write makes the actual permission transfer. Exported readers and admitted uses prevent reuse. On final pool retirement an exact one-block system-owned ready block is frozen readonly, then its root is detached without closing native read admission.',
 'failure':'Import retains local pool ownership until complete preflight. Failed allocation/replacement leaves the base and publication unchanged; only idle reusable storage can be discarded.',
 'validation':{'fresh_host_tus':['resource_leases.cc','state_versions.cc','state_versions_test.cc','state_clone_test.cc'],
    'after':'31/31 canonical tests PASS: 20 StateVersions + 11 StateClone',
    'new_regressions':5,'warm_updates':32,'warmup_updates':2,'subsequent_updates_with_allocator_denied':30,
    'new_warm_control_allocations':0,
    'before':'Original state_versions.cc fails the same warm test once allocations are denied after warmup.',
    'native_use_boundary':'LeaseUseBatch admitted-use/read-admission contract exercised locally; no new GPU model or platform-native replay was run.'},
 'host':{'platform':platform.platform(),'processor':os.environ.get('PROCESSOR_IDENTIFIER'),
    'logical_processors':os.environ.get('NUMBER_OF_PROCESSORS'),'compiler':str(Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'))},
 'remaining_audit_boundaries':[
    'PagedArena::read allocates immutable frame/guards/required arrays and sorts page IDs (paged_arena.cc173-181).',
    'BatchSchema::version allocates and copies all active metadata (batch_layout.cc195-209).',
    'Common native-batch metadata deltas still synchronize their F2 upload (batch_execution.cc379); native-plan reuse does not remove that wait.',
    'CPU changing multi-token KV layouts may rebuild per-request native recipes (native_batch.cc114-136).',
    'Current model StateFeedback uses host byte arrays (d5_qwen38_24t_semantic_fragments.h137-169); the B1 public MTP consumer does not establish all 8 models / 22 configurations as a pure-device compressed/index/KV accepted-prefix journey.'
 ]}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'product.diff').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=ROOT))
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ['run.py','pack.py','state.before.cc','summary.json','product.diff','commands.json','identities.json']:
  z.write(OUT/name,name)
 for p in sorted(OUT.glob('*.log')):z.write(p,p.name)
 for p in paths+['tests/compute_state/state_clone_test.cc']:z.write(ROOT/p,p)
with zipfile.ZipFile(archive) as z:assert all(not n.endswith(('.obj','.exe','.dll','.lib')) for n in z.namelist())
print(str(archive),archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest())
