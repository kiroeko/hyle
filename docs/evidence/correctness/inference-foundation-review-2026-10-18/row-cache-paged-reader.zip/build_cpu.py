from pathlib import Path
import json,sys,subprocess,os,time
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-reader';sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
old=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/commands.json').read_text())
host=next(x['command']for x in old if x['tag']=='cpu-canonical-compile'and x['exit']==0)
flags=[x for x in host if not x.endswith('.cc')and not x.lower().startswith('/fo')]+['/I'+str(R/'src/compute_provider_native'),'/I'+str(R/'third_party/ds4_quantization')]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]});env['VSLANG']='1033'
records=json.loads((O/'cpu-commands.json').read_text())if(O/'cpu-commands.json').exists()else[]
def run(tag,cmd):
 n=1+sum(x['tag']==tag for x in records);stem=tag+'-'+str(n);start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(stem+'.stdout.log')).write_bytes(p.stdout);(O/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'cpu-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-5000:],p.stderr.decode(errors='replace')[-2000:],flush=True);p.check_returncode()
def compile(source,name):run(name+'-compile',[*flags,R/source,'/Fo'+str(O/(name+'.obj'))])
if __name__=='__main__':
 for source,name in [('src/compute_provider_native/row_cache.cc','cpu-codec'),('src/compute_provider_native/native_provider.cc','cpu-native-provider'),('src/compute_batch/row_cache_paged_reader.cc','reader')]:compile(source,name)
