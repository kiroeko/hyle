from pathlib import Path
import json,sys,subprocess,os,time
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-reader';sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
cache=R/'.scratch/inference-fusion-quantization-2026-10-18/deepseek-packed-history/cuda';old=json.loads((cache/'commands.json').read_text())
host=next(x['command']for x in reversed(old)if x['tag']=='row-provider-compile'and x['exit']==0)
flags=[x for x in host if not x.endswith('.cc')and not x.lower().startswith('/fo')]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]});env['VSLANG']='1033'
records=json.loads((O/'cuda-commands.json').read_text())if(O/'cuda-commands.json').exists()else[]
def run(tag,cmd):
 n=1+sum(x['tag']==tag for x in records);stem=tag+'-'+str(n);start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(stem+'.stdout.log')).write_bytes(p.stdout);(O/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'cuda-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-5000:],p.stderr.decode(errors='replace')[-2000:],flush=True);p.check_returncode()
if __name__=='__main__':
 for source,name in [('src/compute_provider_cuda/row_cache_provider.cc','cuda-row-provider'),('src/compute_provider_cuda/cuda_provider.cc','cuda-provider')]:run(name+'-compile',[*flags,R/source,'/Fo'+str(O/(name+'.obj'))])
 cmd=next(x['command']for x in reversed(old)if x['tag']=='kernel-compile'and x['exit']==0)
 cmd=[str(O/'cuda-kernel.obj')if x.endswith('kernel.obj')else x for x in cmd]
 run('cuda-kernel-compile',cmd)
