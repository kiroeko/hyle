#pragma once

#include "hyle/compute/operation.h"
#include <array>
#include <limits>

namespace hyle::compute::detail {
// Private address translation, not a new public tensor/catalog operation.
// Only the typed reader supplies owned, validated layout bytes. Invalid
// logical IDs become -1 for the original checked codec to reject atomically.
struct RowCacheMap final {
  std::uint64_t query_offset=0,kv_offset=0,page_offset=0,tail_offset=0,metadata_bytes=0;
  std::uint32_t page_size=0,max_pages=0;
  static constexpr OperationId operation_id{0x48594c45524f5743ULL,0x504147454d415001ULL};
  static constexpr std::string_view operation_name="private-row-cache-page-map";
  constexpr OperationTraits operation_traits()const noexcept{
    return {{2,2},1,AliasPolicy::kNone,EffectKind::kPure,PrecisionPolicy::kExact};
  }
  std::uint32_t max_requests()const noexcept{return std::uint32_t((kv_offset-query_offset)/4-1);}
  std::uint32_t max_refs()const noexcept{return std::uint32_t((tail_offset-page_offset)/4);}
  Status infer_output_descriptions(std::span<const TensorDesc> in,std::span<TensorDesc> out)const noexcept{
    if(in.size()!=2 || out.size()!=1 || !in[0].valid() || !in[1].valid() ||
       !in[0].is_plain() || !in[0].is_dense() || in[0].rank()!=2 || in[0].data_type()!=DataType::kInt32 ||
       !in[1].is_plain() || !in[1].is_dense() || in[1].rank()!=1 || in[1].data_type()!=DataType::kUInt8 ||
       !page_size || !max_pages || std::uint64_t(max_pages)*page_size>std::uint64_t(INT32_MAX)+1 ||
       query_offset!=32 || kv_offset<=query_offset+4 || (kv_offset-query_offset)%4 ||
       (kv_offset-query_offset)/4-1>std::uint32_t(INT32_MAX) ||
       page_offset<kv_offset || page_offset-kv_offset!=kv_offset-query_offset ||
       tail_offset<page_offset || (tail_offset-page_offset)%4 || (tail_offset-page_offset)/4>std::uint32_t(INT32_MAX) ||
       tail_offset>metadata_bytes || std::uint64_t(max_requests())*4!=metadata_bytes-tail_offset ||
       metadata_bytes>std::uint64_t(INT64_MAX) || in[1].dimensions()[0]!=std::int64_t(metadata_bytes))
      return Status::InvalidArgument("private row cache mapping geometry differs");
    out[0]=in[0];return Status::Ok();
  }
};
static_assert(InlineCustomOperationDescriptor<RowCacheMap>);
} // namespace hyle::compute::detail
