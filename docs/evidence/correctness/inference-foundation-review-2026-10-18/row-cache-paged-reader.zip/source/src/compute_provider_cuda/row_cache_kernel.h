#pragma once

#include <cstdint>
#include <cuda_runtime_api.h>

namespace hyle::compute::cuda_native::row_cache::native {
struct Program final {
  std::uint64_t rows = 0, selected = 0;
  bool encode = false, float4 = false, checked = false;
};
struct MapProgram final {
  std::uint64_t rows=0,selected=0,query_offset=0,kv_offset=0,page_offset=0,tail_offset=0;
  std::uint32_t page_size=0,max_pages=0,max_requests=0,max_refs=0;
};
cudaError_t launch_map(MapProgram,const std::int32_t*,const void*,std::int32_t*,cudaStream_t)noexcept;
cudaError_t prepare(Program) noexcept;
cudaError_t launch(Program, const void *source, const std::int32_t *indices,
                   void *output, unsigned *status, cudaStream_t) noexcept;
} // namespace hyle::compute::cuda_native::row_cache::native
