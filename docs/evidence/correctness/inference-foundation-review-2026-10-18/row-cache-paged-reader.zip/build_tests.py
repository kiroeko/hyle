from pathlib import Path
import json,sys,subprocess,os,time
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-reader';sys.path.insert(0,str(O));sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
backend=sys.argv[1]; records=json.loads((O/(backend+'-test-commands.json')).read_text())if(O/(backend+'-test-commands.json')).exists()else[]
def successful(path,tag):return next(x['command']for x in reversed(json.loads(path.read_text()))if x['tag']==tag and x['exit']==0)
if backend=='cpu':
 host=successful(R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/commands.json','cpu-canonical-compile')
 link=successful(R/'.scratch/inference-foundation-review-2026-10-18/row-cache-cpu/graph-commands.json','graph-link')
else:
 cache=R/'.scratch/inference-fusion-quantization-2026-10-18/deepseek-packed-history/cuda';host=successful(cache/'commands.json','tests-compile');link=successful(cache/'commands.json','link')
flags=[x for x in host if not x.endswith('.cc')and not x.lower().startswith('/fo')]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]});env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
runtime=[str(R/'.scratch/build-compute-v2-dev/bin'),'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64']+[str(Path(p).parent)for p in link if p.endswith('.lib')and Path(p).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
def run(tag,cmd):
 n=1+sum(x['tag']==tag for x in records);stem=backend+'-'+tag+'-'+str(n);start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(stem+'.stdout.log')).write_bytes(p.stdout);(O/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/(backend+'-test-commands.json')).write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-10000:],p.stderr.decode(errors='replace')[-3000:],flush=True);p.check_returncode()
if __name__=='__main__':
 source='tests/compute_route_cpu/row_cache_paged_test.cc'if backend=='cpu'else'tests/compute_provider_cuda/row_cache_paged_test.cc'
 run('test-compile',[*flags,R/source,'/Fo'+str(O/(backend+'-test.obj'))])
 replacements={}
 if backend=='cpu':
  replacements[str(R/'.scratch/inference-foundation-review-2026-10-18/row-cache-cpu/row-cache.obj')]=str(O/'cpu-codec.obj')
  replacements[str(R/'.scratch/inference-foundation-review-2026-10-18/row-cache-cpu/native-provider.obj')]=str(O/'cpu-native-provider.obj')
 else:
  for src,dst in [('row-provider.obj','cuda-row-provider.obj'),('cuda-provider.obj','cuda-provider.obj'),('kernel.obj','cuda-kernel.obj')]:replacements[str(cache/src)]=str(O/dst)
  replacements[str(R/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/provider.obj')]=str(R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cuda-provider.obj')
  replacements[str(R/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/tensor-after.obj')]=str(R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cuda-tensor.obj')
 omit_names={'graph.obj','tests.obj','graph-batch.obj','batch-layout.obj','batch-execution.obj','paged-arena.obj'}
 cmd=[replacements.get(x,x)for x in link if Path(x).name not in omit_names and not x.startswith(('/OUT:','/MAP:'))]
 run('link',[*cmd,O/(backend+'-test.obj'),O/'reader.obj',R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages/batch_layout.obj',R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages/paged_arena.obj',R/'.scratch/build-compute-v2-dev/bin/hyle_compute_batch.lib','/OUT:'+str(O/(backend+'-test.exe'))])
 run('test',[O/(backend+'-test.exe')])

