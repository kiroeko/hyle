#include "hyle/compute/row_cache_paged.h"
static_assert(sizeof(hyle::compute::PagedRowCacheGatherInvocation)==sizeof(void*));
