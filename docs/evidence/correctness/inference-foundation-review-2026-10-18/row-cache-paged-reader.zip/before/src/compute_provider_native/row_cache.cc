#include "native_plan.h"

#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <span>
#include <utility>

#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable : 4505) // The original header also defines unused whole-row entry points.
#endif
#include "ds4_roundtrip.h"
#if defined(_MSC_VER)
#pragma warning(pop)
#endif
#include "hyle/compute/model_ops.h"
#include "hyle/mem/resource.h"
#include "numeric.h"

namespace hyle::compute::native::internal {
namespace {

Result<mem::HostMapping> read_mapping(mem::ConstBufferView storage) noexcept {
  if (!storage.resource().properties().has(mem::MemoryProperty::kHostDeviceCoherent)) {
    HYLE_RETURN_IF_ERROR(storage.invalidate());
  }
  return storage.map_host();
}

std::uint16_t bf16_bits(const std::byte *source) noexcept {
  std::uint16_t bits;
  std::memcpy(&bits, source, sizeof(bits));
  return bits;
}

// Only encode an already rounded positive format value. Rounding and ties are
// selected by the original DS4 helpers, while the source sign is kept in bytes.
std::uint8_t fp8_magnitude(float value) noexcept {
  if (value < 0.015625F)
    return static_cast<std::uint8_t>(value * 512.0F);
  const auto bits = std::bit_cast<std::uint32_t>(value);
  return static_cast<std::uint8_t>((((bits >> 23) - 120) << 3) |
                                   ((bits >> 20) & 7));
}

template <bool Four>
void encode_row(const std::byte *source, std::byte *output) noexcept {
  constexpr std::size_t count = Four ? 128 : 448;
  constexpr std::size_t group = Four ? 32 : 64;
  constexpr std::size_t scales = Four ? 64 : 576;
  constexpr float cap = Four ? 6.0F : 448.0F;
  constexpr float floor = Four ? 7.052966104933725e-38F : 1.0e-4F;
  for (std::size_t base = 0; base < count; base += group) {
    float maximum = 0;
    for (std::size_t i = 0; i < group; ++i) {
      const auto value = numeric::load<simd::bfloat16_t>(source + (base + i) * 2);
      maximum = (std::max)(maximum, std::abs(value));
    }
    if (maximum < floor) maximum = floor;
    const float scale = std::ldexp(1.0F,
        static_cast<int>(std::ceil(std::log2(maximum / cap))));
    output[scales + base / group] =
        std::byte((std::bit_cast<std::uint32_t>(scale) >> 23) & 255);
    for (std::size_t i = 0; i < group; ++i) {
      const auto offset = base + i;
      const auto raw = bf16_bits(source + offset * 2);
      const float value = std::abs(numeric::load<simd::bfloat16_t>(source + offset * 2) / scale);
      std::uint8_t code;
      if constexpr (Four) {
        const float rounded = ds4_quantization::dsv4_e2m1fn_dequant_cpu(value);
        code = 0;
        while (ds4_quantization::dsv4_e2m1fn_value_cpu(code) != rounded) ++code;
        code |= static_cast<std::uint8_t>((raw >> 12) & 8);
        if ((offset & 1) == 0) output[offset / 2] = std::byte(code);
        else output[offset / 2] |= std::byte(code << 4);
      } else {
        code = fp8_magnitude(ds4_quantization::dsv4_e4m3fn_dequant_cpu(value));
        code |= static_cast<std::uint8_t>((raw >> 8) & 128);
        output[offset] = std::byte(code);
      }
    }
  }
  if constexpr (!Four) {
    std::memcpy(output + 448, source + 448 * 2, 64 * 2);
    output[583] = std::byte{0};
  }
}

float scale_value(std::byte encoded) noexcept {
  const auto exponent = std::to_integer<unsigned>(encoded);
  return exponent == 255 ? std::numeric_limits<float>::quiet_NaN()
                         : std::ldexp(1.0F, static_cast<int>(exponent) - 127);
}

template <bool Four>
void decode_row(const std::byte *source, std::byte *output) noexcept {
  constexpr std::size_t count = Four ? 128 : 448;
  constexpr std::size_t group = Four ? 32 : 64;
  constexpr std::size_t scales = Four ? 64 : 576;
  for (std::size_t base = 0; base < count; base += group) {
    const float scale = scale_value(source[scales + base / group]);
    for (std::size_t i = 0; i < group; ++i) {
      const auto index = base + i;
      unsigned code = std::to_integer<unsigned>(source[Four ? index / 2 : index]);
      if constexpr (Four) code = (code >> ((index & 1) * 4)) & 15;
      const unsigned magnitude = code & (Four ? 7 : 127);
      float value;
      if constexpr (Four) value = ds4_quantization::dsv4_e2m1fn_value_cpu(magnitude);
      else value = magnitude == 127 ? std::numeric_limits<float>::quiet_NaN()
                                    : ds4_quantization::dsv4_e4m3fn_value_cpu(magnitude);
      if (code & (Four ? 8 : 128)) value = -value;
      numeric::store<simd::bfloat16_t>(output + index * 2, value * scale);
    }
  }
  if constexpr (!Four) std::memcpy(output + 448 * 2, source + 448, 64 * 2);
}

Status finish_output(mem::HostMapping &mapping, mem::BufferView output) noexcept {
  Status terminal;
  if (!output.resource().properties().has(mem::MemoryProperty::kHostDeviceCoherent))
    terminal = mapping.flush();
  preserve_first_error(terminal, mapping.close());
  return terminal;
}

template <bool Four>
detail::EnqueueResult submit_encode(const NativePlan &plan,
    std::span<const ConstTensorView> inputs, std::span<const TensorView> outputs) noexcept {
  if (inputs.size() != 1 || outputs.size() != 1)
    return completed(Status::Internal("row cache encode binding count differs"));
  const auto rows = plan.parameters[0], depth = plan.parameters[1], width = plan.parameters[2];
  if (rows == 0) return completed(Status::Ok());
  auto input = read_mapping(inputs[0].storage());
  if (!input) return completed(std::move(input).error());
  const auto *source = input->bytes().data();
  // Validate every input, including the bitwise tail, before opening output.
  for (std::size_t i = 0; i < rows * depth; ++i) {
    if ((bf16_bits(source + i * 2) & 0x7f80) == 0x7f80) {
      input->close().IgnoreError();
      return completed(Status::InvalidArgument("row cache encoder requires finite BF16"));
    }
  }
  auto output = outputs[0].storage().map_host(mem::HostAccess::kWrite);
  if (!output) { input->close().IgnoreError(); return completed(std::move(output).error()); }
  auto writable = output->writable_bytes();
  if (!writable) {
    output->close().IgnoreError(); input->close().IgnoreError();
    return completed(std::move(writable).error());
  }
  for (std::size_t row = 0; row < rows; ++row)
    encode_row<Four>(source + row * depth * 2, writable->data() + row * width);
  auto terminal = finish_output(*output, outputs[0].storage());
  preserve_first_error(terminal, input->close());
  return completed(std::move(terminal));
}

std::int32_t index_value(const std::byte *source, std::size_t index) noexcept {
  std::int32_t result;
  std::memcpy(&result, source + index * sizeof(result), sizeof(result));
  return result;
}

template <bool Four>
detail::EnqueueResult submit_gather(const NativePlan &plan,
    std::span<const ConstTensorView> inputs, std::span<const TensorView> outputs) noexcept {
  if (inputs.size() != 2 || outputs.size() != 1)
    return completed(Status::Internal("row cache gather binding count differs"));
  const auto count = plan.parameters[0], rows = plan.parameters[1], width = plan.parameters[2];
  if (count == 0) return completed(Status::Ok());
  auto ids = read_mapping(inputs[1].storage());
  if (!ids) return completed(std::move(ids).error());
  const auto *indices = ids->bytes().data();
  if (plan.index_bounds == IndexBoundsPolicy::kChecked) {
    for (std::size_t i = 0; i < count; ++i) {
      const auto index = index_value(indices, i);
      if (index < 0 || static_cast<std::uint64_t>(index) >= rows) {
        ids->close().IgnoreError();
        return completed(Status::OutOfRange("row cache ID is outside the bank"));
      }
    }
  }
  auto source = read_mapping(inputs[0].storage());
  if (!source) { ids->close().IgnoreError(); return completed(std::move(source).error()); }
  auto output = outputs[0].storage().map_host(mem::HostAccess::kWrite);
  if (!output) {
    source->close().IgnoreError(); ids->close().IgnoreError();
    return completed(std::move(output).error());
  }
  auto writable = output->writable_bytes();
  if (!writable) {
    output->close().IgnoreError(); source->close().IgnoreError(); ids->close().IgnoreError();
    return completed(std::move(writable).error());
  }
  for (std::size_t i = 0; i < count; ++i)
    decode_row<Four>(source->bytes().data() + static_cast<std::size_t>(index_value(indices, i)) * width,
                    writable->data() + i * plan.row_output_stride * 2);
  auto terminal = finish_output(*output, outputs[0].storage());
  preserve_first_error(terminal, source->close());
  preserve_first_error(terminal, ids->close());
  return completed(std::move(terminal));
}
} // namespace

Status prepare_row_cache(Operation operation, std::span<const TensorDesc> inputs,
    std::span<const TensorDesc> outputs, NativePlan &plan) noexcept {
  if (outputs.size() != 1) return Status::InvalidArgument("row cache output count differs");
  std::array<TensorDesc, 1> inferred;
  if (const auto encode = operation.custom_as<model_ops::RowCacheEncode>()) {
    HYLE_RETURN_IF_ERROR(encode->infer_output_descriptions(inputs, inferred));
    if (outputs[0] != inferred[0]) return Status::InvalidArgument("row cache encode output differs");
    plan.parameters = {static_cast<std::size_t>(inputs[0].dimensions()[0]),
                       encode->encoding.depth(), encode->encoding.row_bytes()};
    plan.submit_route = encode->encoding.format() == RowCacheFormat::kFloat4Block32
        ? &submit_encode<true> : &submit_encode<false>;
    return Status::Ok();
  }
  if (const auto gather = operation.custom_as<model_ops::RowCacheGatherDecode>()) {
    HYLE_RETURN_IF_ERROR(gather->infer_output_descriptions(inputs, inferred));
    if (outputs[0] != inferred[0]) return Status::InvalidArgument("row cache gather output differs");
    HYLE_ASSIGN_OR_RETURN(auto count, inputs[1].element_count());
    plan.parameters = {count, static_cast<std::size_t>(inputs[0].dimensions()[0]),
                       gather->encoding.row_bytes()};
    plan.row_output_stride = gather->encoding.depth();
    plan.index_bounds = gather->bounds;
    plan.submit_route = gather->encoding.format() == RowCacheFormat::kFloat4Block32
        ? &submit_gather<true> : &submit_gather<false>;
    return Status::Ok();
  }
  return Status::Unimplemented("operation is not a row cache codec");
}
} // namespace hyle::compute::native::internal
