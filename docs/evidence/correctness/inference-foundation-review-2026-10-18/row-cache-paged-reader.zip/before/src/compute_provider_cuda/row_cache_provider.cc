#include "row_cache_provider.h"

#include <array>
#include "hyle/compute/model_ops.h"
#include "native_context.h"
#include "row_cache_kernel.h"

namespace hyle::compute::cuda_native::row_cache {
namespace {
constexpr ProviderRuntimeProperties kRuntime{
    .mode = ProviderRuntimeMode::kSharedQueue,
    .workspace_owner = ProviderWorkspaceOwner::kCaller,
    .replay_class = ProviderReplayClass::kPrepared,
    .blocks_host = false, .uses_private_threads = false,
    .supports_concurrent_invocations = true, .capture_compatible = true};
struct Prepared final { CUcontext primary; native::Program program; };
Result<native::Program> select(Operation operation,
    std::span<const TensorDesc> inputs, std::span<const TensorDesc> outputs) noexcept {
  native::Program program;
  RowCacheEncoding encoding;
  if (const auto encode = operation.custom_as<model_ops::RowCacheEncode>()) {
    encoding = encode->encoding;
    program.encode = true;
  } else if (const auto decode = operation.custom_as<model_ops::RowCacheGatherDecode>()) {
    encoding = decode->encoding;
    program.checked = decode->bounds == IndexBoundsPolicy::kChecked;
  } else
    return std::unexpected(Status::Unimplemented("CUDA row cache operation differs"));
  std::array<TensorDesc, 1> inferred;
  HYLE_RETURN_IF_ERROR(infer_output_descriptions(operation, inputs, inferred));
  if (outputs.size() != 1 || outputs[0] != inferred[0])
    return std::unexpected(Status::InvalidArgument("CUDA row cache output differs"));
  program.rows = static_cast<std::uint64_t>(inputs[0].dimensions()[0]);
  program.float4 = encoding.format() == RowCacheFormat::kFloat4Block32;
  if (!program.encode) {
    HYLE_ASSIGN_OR_RETURN(program.selected, inputs[1].element_count());
  }
  return program;
}
void destroy(void *state, mem::AllocatorRef allocator) noexcept {
  allocator.destroy(static_cast<Prepared *>(state));
}
AliasSupport alias(void *, std::size_t, std::size_t) noexcept { return {}; }
Status create_invocation(void *, mem::AllocatorRef, mem::BufferView,
                         void **output) noexcept {
  if (!output) return Status::InvalidArgument("CUDA row cache invocation output is null");
  *output = nullptr;
  return Status::Ok();
}
void destroy_invocation(void *, mem::AllocatorRef) noexcept {}
detail::EnqueueResult submit(void *state, void *, Queue &queue,
    std::span<const ConstTensorView> inputs, std::span<const TensorView> outputs) noexcept {
  const auto &prepared = *static_cast<const Prepared *>(state);
  const auto &program = prepared.program;
  if (program.encode ? program.rows == 0 : program.selected == 0)
    return detail::EnqueueResult::no_op();
  auto stream = cuda::stream(queue);
  if (!stream) return detail::EnqueueResult::rejected(std::move(stream).error());
  auto source = cuda::detail::const_pointer(inputs[0].storage(), program.encode ? 2 : 1, 1);
  if (!source) return detail::EnqueueResult::rejected(std::move(source).error());
  const std::int32_t *ids = nullptr;
  if (!program.encode) {
    auto pointer = cuda::detail::const_pointer(inputs[1].storage(), 4, 1);
    if (!pointer) return detail::EnqueueResult::rejected(std::move(pointer).error());
    ids = static_cast<const std::int32_t *>(*pointer);
  }
  auto output = cuda::detail::mutable_pointer(outputs[0].storage(), program.encode ? 1 : 2, 1);
  if (!output) return detail::EnqueueResult::rejected(std::move(output).error());
  cuda::detail::ScopedPrimaryContext scope(prepared.primary);
  if (!scope) return detail::EnqueueResult::rejected(scope.status());
  unsigned *word = nullptr;
  if (program.encode || program.checked) {
    auto initialized = cuda::detail::acquire_device_status(queue, &word);
    if (!initialized.status.ok()) return initialized;
  }
  // acquire_device_status may already enqueue a reset. A later launch failure
  // is therefore an accepted prefix, retained by the original Queue completion.
  return detail::EnqueueResult::accepted_command(cuda::status(
      native::launch(program, *source, ids, *output, word, *stream)));
}
const detail::ProviderPreparedVTable kPrepared{
    .destroy_prepared = &destroy, .alias_support = &alias,
    .create_invocation = &create_invocation, .destroy_invocation = &destroy_invocation,
    .shared_submit = &submit};
} // namespace
Status propose(const detail::ProviderOperationRequest &request,
    std::span<detail::ResourceBindingRequirement> inputs,
    std::span<detail::ResourceBindingRequirement> outputs,
    detail::ProviderOperationProposal *proposal) noexcept {
  if (!request.shape.exact()) return Status::Unimplemented("CUDA row cache needs exact shapes");
  HYLE_ASSIGN_OR_RETURN(const auto program, select(request.operation, request.inputs, request.outputs));
  if (!proposal || inputs.size() != request.inputs.size() || outputs.size() != 1)
    return Status::InvalidArgument("CUDA row cache binding counts differ");
  for (std::size_t i = 0; i < inputs.size(); ++i)
    inputs[i] = {.required_properties = mem::MemoryProperty::kDeviceAccessible,
                 .minimum_alignment = i == 1 ? 4U : program.encode ? 2U : 1U};
  outputs[0] = {.required_properties = mem::MemoryProperty::kDeviceAccessible,
                .minimum_alignment = program.encode ? 1U : 2U};
  const bool empty = program.encode ? !program.rows : !program.selected;
  *proposal = {.route = kRoute, .runtime = kRuntime,
      .cost = {.workspace = WorkspaceRequirement{}, .persistent_bytes = sizeof(Prepared),
          .copy_bytes = 0,
          .repack_bytes = program.encode ? *request.outputs[0].required_bytes() : 0,
          .synchronization_count = 0,
          // A fresh sequence also resets its status word. A later operation
          // in that same sequence may share the already initialized word.
          .dispatch_count = empty ? std::nullopt : std::optional<std::uint32_t>{
              program.encode || program.checked ? 3U : 1U}},
      .implementation = ProviderImplementationId{kRoute}};
  return Status::Ok();
}
ProviderPrepareOutcome prepare(void *state, const detail::ProviderPrepareRequest &request,
    mem::AllocatorRef allocator, detail::ProviderPrepared *output) noexcept {
  if (!output) return ProviderPrepareOutcome::error(Status::InvalidArgument("CUDA row cache prepared output is null"));
  *output = {};
  auto program = select(request.operation, request.inputs, request.outputs);
  if (!program) return ProviderPrepareOutcome::error(std::move(program).error());
  cuda::detail::ScopedPrimaryContext scope(static_cast<CUcontext>(state));
  if (!scope) return ProviderPrepareOutcome::error(scope.status());
  const auto configured = native::prepare(*program);
  if (configured != cudaSuccess)
    return ProviderPrepareOutcome::error(cuda::status(configured));
  auto *prepared = allocator.construct<Prepared>(static_cast<CUcontext>(state), *program);
  if (!prepared) return ProviderPrepareOutcome::resource_declined(Status::ResourceExhausted("CUDA row cache program allocation"));
  *output = {.vtable = &kPrepared, .state = prepared, .workspace = {}, .runtime = kRuntime,
             .persistent_bytes = sizeof(Prepared), .invocation_private_bytes = 0};
  return ProviderPrepareOutcome::prepared();
}
} // namespace hyle::compute::cuda_native::row_cache
