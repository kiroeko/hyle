#pragma once

#include <cstdint>
#include <cuda_runtime_api.h>

namespace hyle::compute::cuda_native::row_cache::native {
struct Program final {
  std::uint64_t rows = 0, selected = 0;
  bool encode = false, float4 = false, checked = false;
};
cudaError_t prepare(Program) noexcept;
cudaError_t launch(Program, const void *source, const std::int32_t *indices,
                   void *output, unsigned *status, cudaStream_t) noexcept;
} // namespace hyle::compute::cuda_native::row_cache::native
