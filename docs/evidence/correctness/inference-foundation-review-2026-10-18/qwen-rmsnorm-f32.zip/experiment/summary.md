Only one actual weighted RMSNorm and BF16 Cast ran on the original residual and original norm weight.

- 47,104 / 47,104 BF16 points exactly reproduce the executed Hyle record.
- token21/channel619: native F32 **0x3f568001** (0.8378906846046448), then BF16 **0x3f57**. Previous actual Torch F32 was the midpoint **0x3f568000**.
- Every saved native F32 value casts to the saved BF16 with ordinary round-to-nearest-even. The discrepancy already exists before BF16 conversion in this fully reproducing paired path.
- Nsight Compute actually identified **rms_norm_f32<1024,true,false>**, grid23, block1024, dynamic shared128B. Profiled F32/BF16 outputs remain byte-identical. This is launch identification, not a timing claim.
- Only the small consumer and four required current-ABI Hyle host owners compiled. Existing numerical SDK, CUDA kernels and original ggml libraries/overlays were reused; no Graph or model execution.
- Native reduction/mean/rsqrt intermediates remain unobserved. No telemetry norm.cu was built; this result does not identify which F32 arithmetic stage differs.

Evidence: commands.json, comparison.json, actual/weighted-native.{f32,bf16}, 008-probe-run logs, 010-ncu-rmsnorm logs, input-identities.json, link-identities.json, map-selected-owners.txt. Image/map cleanup candidates are exact in cleanup-identities.json; objects and source are retained. No deletion performed.
