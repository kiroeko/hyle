from pathlib import Path
import argparse, hashlib, json, os, struct, subprocess, sys, time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
QWEN=ARCH/'generic-progress/qwen'
META=ARCH/'native-runtime-retirement/metadata-oom-review'
BASE=ARCH/'retire-native-runtime/paging-risks/matched-link-base.json'
REF=ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows'
PROBE=QWEN/'layer0-probe-01/prefill'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(p):
 p=Path(p); return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def save(name,d): (OUT/name).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def env():
 sys.path.insert(0,str(ROOT/'scripts'))
 from hyle_environment import windows_compiler_environment
 from hyle_support import read_cache
 e=windows_compiler_environment(read_cache(ROOT/'.scratch/build-compute-v2-dev'))
 old=json.loads((QWEN/'link-plan.json').read_text())['command']
 dirs=[str(Path(v).parent) for v in old if v.lower().endswith('.lib') and Path(v).is_absolute()]
 dirs+=['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',str(ROOT/'.scratch/build-compute-v2-dev/bin')]
 e['PATH']=os.pathsep.join(dict.fromkeys(dirs))+os.pathsep+e['PATH'];e['VSLANG']='1033'
 return e
def run(tag,cmd,timeout=180,allow_failure=False):
 history=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
 stem=f'{len(history)+1:03d}-{tag}';print('START',stem,flush=True);start=time.monotonic()
 with (OUT/(stem+'.stdout.log')).open('wb') as so,(OUT/(stem+'.stderr.log')).open('wb') as se:
  p=subprocess.run(list(map(str,cmd)),cwd=ROOT,env=env(),stdout=so,stderr=se,timeout=timeout)
 row=dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log')
 history.append(row);save('commands.json',history);print('END',stem,p.returncode,flush=True)
 if p.returncode and not allow_failure:
  print((OUT/row['stdout']).read_text(errors='replace')[-10000:]);print((OUT/row['stderr']).read_text(errors='replace')[-10000:]);raise SystemExit(p.returncode)
 return row
def inputs():
 manifest=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2/weights.tsv'
 lines=manifest.read_text().splitlines();shard=Path(lines[1])
 name='model.language_model.layers.0.post_attention_layernorm.weight'
 f=next(x.split('\t') for x in lines[3:] if x.split('\t')[0]==name);rank=int(f[2]);offset=int(f[3+rank]);size=int(f[4+rank])
 assert f[1]=='BF16' and size==4096
 with shard.open('rb') as stream:stream.seek(offset);raw=stream.read(size)
 assert hashlib.sha256(raw).hexdigest()=='f17354499a755348654fb5b053a80613eedb97c3335a7a05c9272d944fd1957d'
 (OUT/'weight.bf16').write_bytes(raw)
 save('input-identities.json',dict(residual=identity(PROBE/'06-post-attn-residual.bf16'),expected=identity(PROBE/'07-post-attn-norm.bf16'),weight=identity(OUT/'weight.bf16'),manifest=identity(manifest),weight_origin=dict(shard=str(shard),offset=offset,size=size,source_id=lines[2],name=name)))
def recipes():
 src=OUT/'probe.cc';q=json.loads((QWEN/'compile-recipes.json').read_text())
 r=next(r for r in q if r['tag']=='consumer');cmd=[]
 for v in r['command']:
  if v.lower().endswith('main.cc'):v=str(src)
  elif v.lower().startswith('/fo'):v='/Fo'+str(OUT/'probe.obj')
  cmd.append(v)
 # Current ggml tensor helper has by-value Operation ABI and must match Provider16.
 r=next(r for r in q if r['tag']=='ggml-tensor');tc=[]
 for v in r['command']:
  if v.lower().startswith('/fo'):v='/Fo'+str(OUT/'tensor-current.obj')
  tc.append(v)
 rows=[dict(source=str(src),sha256=sha(src),object=str(OUT/'probe.obj'),command=cmd),dict(source=str(ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc'),sha256=sha(ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc'),object=str(OUT/'tensor-current.obj'),command=tc)]
 admitted=json.loads((ARCH/'admitted-queue-sequence/cuda/compile-recipes.json').read_text())
 for name in ['default_policy','best_of','cuda_context']:
  source='src/compute_route_cuda/'+name+'.cc'
  recipe=next(r for r in admitted if r['source']==source)
  command=[('/Fo'+str(OUT/(name+'-current.obj'))) if v.lower().startswith('/fo') else v for v in recipe['command']]
  rows.append(dict(source=str(ROOT/source),sha256=sha(ROOT/source),object=str(OUT/(name+'-current.obj')),command=command))
 save('compile-recipes.json',rows);return rows
def compile_():
 for r in recipes():
  if Path(r['object']).is_file():continue
  run(Path(r['source']).stem+'-compile',r['command'])
  assert sha(r['source'])==r['sha256']
 save('fresh-object-identities.json',[dict(source=r['source'],source_sha256=r['sha256'],object=identity(r['object'])) for r in recipes()])
def link():
 old=json.loads((QWEN/'link-plan.json').read_text())['command'];base=json.loads(BASE.read_text());meta=json.loads((META/'commands.json').read_text())
 replacements={}
 for r in meta:
  src=Path(r['source']['path']); assert sha(src)==r['source']['sha256'],src
  obj=next(v[3:] for v in r['command'] if v.lower().startswith('/fo'))
  replacements[src.stem+'.obj']=obj
 # Preserve the actual default CUDA roster and original numerical kernel libraries.
 chosen=[];dropped=[]
 for v in old[1:]:
  low=v.lower();name=Path(v).name.lower()
  if low.startswith(('/out:','/map:')):continue
  if low.endswith('.obj'):
   keep=('compute_provider' in low or 'compute_backend_cuda' in low or
         'windows-batch' in low or 'cccl-device-gather' in low or
         'cuda-device-indices' in low or 'cuda-ragged-mla' in low or
         'cuda-paged-indexer' in low or 'generic-progress\\ggml-cache' in low or
         'compute_route_cuda--' in low)
   if not keep:dropped.append(v);continue
   for key,obj in replacements.items():
    if name.endswith('--'+key):v=obj;break
   for name2 in ['default_policy','best_of','cuda_context']:
    if name.endswith('compute_route_cuda--'+name2+'.obj'):v=str(OUT/(name2+'-current.obj'))
  if low.endswith('ggml-tensor.obj'):continue
  if name in {'hyle_graph.lib','hyle_graph_batch.lib'}:dropped.append(v);continue
  chosen.append(v)
 # Only Compute readers are needed. No Graph Plan or Graph Invocation enters this executable.
 sources={k:v for k,v in base['selected_sources'].items() if k.startswith('src/compute/') or k.startswith('src/compute_ops/')}
 selected_hashes=base['compiled_source_sha256']
 for src,obj in sources.items():
  assert sha(ROOT/src)==selected_hashes[src],src
  chosen.append(obj)
 for r in meta:
  if 'graph_provider' not in r['source']['path']:
   chosen.append(next(v[3:] for v in r['command'] if v.lower().startswith('/fo')))
 chosen += [str(OUT/'probe.obj'),str(OUT/'tensor-current.obj')]
 # Explicit objects must precede libraries for predictable archive owner selection.
 chosen=list(dict.fromkeys(chosen));objects=[v for v in chosen if v.lower().endswith('.obj')];rest=[v for v in chosen if not v.lower().endswith('.obj')]
 command=[old[0]]+objects+rest+['/OUT:'+str(OUT/'probe.exe'),'/MAP:'+str(OUT/'probe.map')]
 for v in objects+rest:
  if Path(v).is_absolute() and Path(v).suffix.lower() in {'.obj','.lib'}:assert Path(v).is_file(),v
 save('link-plan.json',dict(command=command,dropped=dropped,selected_compute_sources=sources,abi='Current owned Operation / Provider16 direct Compute; no Graph objects. CUDA metadata20 current source checks; original numerical native archives reused.'))
 save('link-identities.json',[identity(v) for v in command if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}])
 run('probe-link',command)
def execute():
 run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
 run('probe-run',[OUT/'probe.exe',PROBE/'06-post-attn-residual.bf16',OUT/'weight.bf16',OUT/'actual'])
def compare():
 expected=(PROBE/'07-post-attn-norm.bf16').read_bytes();actual=(OUT/'actual/weighted-native.bf16').read_bytes();raw=(OUT/'actual/weighted-native.f32').read_bytes()
 a=struct.unpack('<47104H',actual);b=struct.unpack('<47104H',expected);f=struct.unpack('<47104f',raw);bits=struct.unpack('<47104I',raw)
 changes=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y];i=21*2048+619
 result=dict(elements=len(a),bf16_equal_elements=len(a)-len(changes),bf16_bitwise_equal=not changes,first_changes=[dict(index=j,token=j//2048,channel=j%2048,native_hex=f'0x{a[j]:04x}',recorded_hex=f'0x{b[j]:04x}',native_f32=f[j],native_f32_bits=f'0x{bits[j]:08x}') for j in changes[:20]],coordinate=dict(token=21,channel=619,native_f32=f[i],native_f32_bits=f'0x{bits[i]:08x}',native_bf16=f'0x{a[i]:04x}',recorded_bf16=f'0x{b[i]:04x}',torch_previous_f32=0.837890625,torch_previous_f32_bits='0x3f568000'),outputs=[identity(p) for p in sorted((OUT/'actual').iterdir())])
 save('comparison.json',result);print(json.dumps(result,indent=2));assert not changes,'Direct paired path did not reproduce the executed original BF16; do not infer norm internals yet'

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['inputs','compile','link','run','compare']);a=p.parse_args()
 dict(inputs=inputs,compile=compile_,link=link,run=execute,compare=compare)[a.action]()
