from pathlib import Path
import importlib.util, json, re, struct

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('probe_run',OUT/'run.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
comparison=json.loads((OUT/'comparison.json').read_text())
raw=(OUT/'actual/weighted-native.f32').read_bytes()
bits=struct.unpack('<47104I',raw)
bf16=struct.unpack('<47104H',(OUT/'actual/weighted-native.bf16').read_bytes())
rne=[((v+0x7fff+((v>>16)&1))>>16)&0xffff for v in bits]
assert all((v&0x7f800000)!=0x7f800000 for v in bits)
assert list(bf16)==rne
profile_equal={}
for name in ['input.f32','gamma.f32','weighted-native.f32','weighted-native.bf16']:
 profile_equal[name]=(OUT/'actual'/name).read_bytes()==(OUT/'ncu-actual'/name).read_bytes()
assert all(profile_equal.values())
sources=['src/compute/device.cc','src/compute/operation.cc',
 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/compute_provider_ggml_cuda/tensor_program.cc',
 'src/compute_route_cuda/default_policy.cc','src/compute_route_cuda/best_of.cc','src/compute_route_cuda/cuda_context.cc',
 'src/compute_provider_ggml_cuda/program.h','src/compute/provider_internal.h',
 'include/hyle/compute/operation.h','include/hyle/compute/detail/queue_sequence.h',
 'include/hyle/compute/detail/provider_extension.h']
native=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml-cuda')
original_sources=[native/'norm.cu',native/'common.cuh',native/'ggml-cuda.cu',native/'cpy.cu']
b.save('source-identities.json',[b.identity(b.ROOT/p) for p in sources]+[b.identity(p) for p in original_sources]+[b.identity(OUT/p) for p in ['probe.cc','run.py','finalize.py']])
commands=json.loads((OUT/'commands.json').read_text())
link=json.loads((OUT/'link-plan.json').read_text())
maplines=(OUT/'probe.map').read_text(errors='replace').splitlines()
selected=[x.strip() for x in maplines if any(s in x for s in ['ggml_cuda_op_rms_norm','ggml-cuda:norm.cu.obj','tensor_operation_supports'])]
(OUT/'map-selected-owners.txt').write_text('\n'.join(selected)+'\n')
images=[b.identity(p) for p in sorted(OUT.iterdir()) if p.suffix.lower() in {'.exe','.map','.exp','.lib'}]
b.save('cleanup-identities.json',images)
b.save('retained-object-identities.json',[b.identity(p) for p in sorted(OUT.glob('*.obj'))])
summary=dict(
 scope='One true weighted RMSNorm(23x2048,F32,F32scale,eps=1e-6) followed by the original BF16 Cast; default CUDA Compute Direct; no full-model run, Graph, telemetry CU, native kernel or SDK rebuild.',
 candidate_inputs='Only recorded original Hyle BF16 residual and exact original BF16 norm weight. BF16 widening is exact; scale is original F32(1+weight). Expected Hyle output is read only by the separate Python comparison, never by the candidate.',
 result=comparison,
 bf16_cast=dict(all_elements_round_to_nearest_even_of_saved_native_f32=True,elements=47104),
 actual_kernel=dict(name='rms_norm_f32<1024,true,false>',meaning='actual fused RMSNorm+multiply, no add',grid=[23,1,1],block=[1024,1,1],dynamic_shared_bytes=128,registers_per_thread=40,evidence='010-ncu-rmsnorm.stdout.log',archive_owner='ggml-cuda:norm.cu.obj',scope='Observed paired Direct execution; the original full-model run had no native F32/kernel trace.'),
 ncu=dict(exit=0,permission_problem=False,profiled_one_launch=True,sections=['LaunchStats'],clock_control='none',cache_control='none',performance_claim=False,profiled_outputs_bitwise_identical=profile_equal),
 build=dict(fresh_host_tus=5,consumer='probe.cc',necessary_current_abi_hosts=['tensor_program.cc','default_policy.cc','best_of.cc','cuda_context.cc'],reason='Current by-value/nontrivial owned Operation and Provider16 configured tables; historical full-Qwen closure is a locator, not a current ABI claim.',compute_current_sources=link['selected_compute_sources'],cuda_current_providers='metadata-oom-review compiled current host sources, actual hashes checked before link',native='Original matched ggml CUDA/reference libraries and existing overlays; all link input bytes/SHA in link-identities.json',provider_version_label='Printed provider version retains its historical source-4e1 string; actual native archive/overlay identity is established by link-identities.json and map, not that label.'),
 hardware='NVIDIA RTX 4070 / CC8.9 / driver617.14 / build CUDA13.3, exact hardware log007',
 conclusion='The fully reproducing paired execution is already one F32 ULP above the previous Torch midpoint before BF16 Cast. Native BF16 conversion exactly matches RNE for every saved F32 value. This rules out the BF16 conversion as the origin in this paired execution; it does not yet separate reduction, rsqrt or multiplication.',
 unverified=['No actual native mean/reduction/rsqrt registers were captured.','No telemetry norm.cu was compiled.','No numerical acceptance for the full Qwen hidden/logit discrepancy follows from this isolated reproduction.'],
 commands='commands.json',closure='link-plan.json / link-identities.json / map-selected-owners.txt',
 cleanup_candidates='cleanup-identities.json: root test.ps1 only; no files deleted',objects_retained='retained-object-identities.json')
b.save('summary.json',summary)
(OUT/'summary.md').write_text('''Only one actual weighted RMSNorm and BF16 Cast ran on the original residual and original norm weight.

- 47,104 / 47,104 BF16 points exactly reproduce the executed Hyle record.
- token21/channel619: native F32 **0x3f568001** (0.8378906846046448), then BF16 **0x3f57**. Previous actual Torch F32 was the midpoint **0x3f568000**.
- Every saved native F32 value casts to the saved BF16 with ordinary round-to-nearest-even. The discrepancy already exists before BF16 conversion in this fully reproducing paired path.
- Nsight Compute actually identified **rms_norm_f32<1024,true,false>**, grid23, block1024, dynamic shared128B. Profiled F32/BF16 outputs remain byte-identical. This is launch identification, not a timing claim.
- Only the small consumer and four required current-ABI Hyle host owners compiled. Existing numerical SDK, CUDA kernels and original ggml libraries/overlays were reused; no Graph or model execution.
- Native reduction/mean/rsqrt intermediates remain unobserved. No telemetry norm.cu was built; this result does not identify which F32 arithmetic stage differs.

Evidence: commands.json, comparison.json, actual/weighted-native.{f32,bf16}, 008-probe-run logs, 010-ncu-rmsnorm logs, input-identities.json, link-identities.json, map-selected-owners.txt. Image/map cleanup candidates are exact in cleanup-identities.json; objects and source are retained. No deletion performed.
''',encoding='utf-8')
print(json.dumps(dict(summary=b.identity(OUT/'summary.json'),cleanup=b.identity(OUT/'cleanup-identities.json'),images=images),indent=2))
