from pathlib import Path
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
NORM = ROOT / '.scratch/architecture-refactor-2026-10-18/qwen-numerical-localization/actual-f32-probe'
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path),
                bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


service = EVIDENCE / 'optional-file-stream.zip'
with zipfile.ZipFile(service) as z:
    # Service freeze completed before the separate numerical stage encountered external source paths.
    assert z.read('cleanup-plan.json') == (OUT / 'cleanup-plan.json').read_bytes()
    for row in json.loads(z.read('archive-manifest.json')):
        raw = z.read(row['entry'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']

files = {}
for path in NORM.rglob('*'):
    if path.is_file() and path.suffix in {'.json', '.log', '.txt', '.md', '.py', '.cc', '.h', '.f32', '.bf16'}:
        files['experiment/' + path.relative_to(NORM).as_posix()] = path
for row in json.loads((NORM / 'source-identities.json').read_text()):
    path = Path(row['path'])
    now = identity(path)
    assert now['bytes'] == row['bytes'] and now['sha256'] == row['sha256']
    if path.is_relative_to(ROOT):
        files['source/' + path.relative_to(ROOT).as_posix()] = path
    else:
        assert 'ggml-cuda' == path.parent.name
        files['dependency-source/ggml-cuda/' + path.name] = path
files['finish_numerical_archive.py'] = Path(__file__)
target = EVIDENCE / 'qwen-rmsnorm-f32.zip'
assert not target.exists()
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.writestr('archive-manifest.json', json.dumps([
        dict(entry=name, **identity(path)) for name, path in sorted(files.items())], indent=2) + '\n')
receipts = dict(service=identity(service), numerical=identity(target))
(OUT / 'archive-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
print(json.dumps(receipts))
