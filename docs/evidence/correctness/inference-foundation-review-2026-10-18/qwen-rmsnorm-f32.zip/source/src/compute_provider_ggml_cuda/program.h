#pragma once

#include <cstdint>
#include <vector>

#include "hyle/compute/providers/ggml_cuda.h"
#include "provider_internal.h"

namespace hyle::compute::ggml_cuda::internal {

inline constexpr ProviderRuntimeProperties kRuntime{
    .mode = ProviderRuntimeMode::kSharedQueue,
    .workspace_owner = ProviderWorkspaceOwner::kProvider,
    .replay_class = ProviderReplayClass::kManaged,
    .blocks_host = true,
    .uses_private_threads = false,
    .supports_concurrent_invocations = true,
    .capture_compatible = false};
inline constexpr detail::ResourceBindingRequirement kBinding{
    .required_properties = mem::MemoryProperty::kDeviceAccessible,
    .minimum_alignment = 256};

inline std::size_t boundary_alignment(Operation operation,
                                      DataType type) noexcept {
  // Original scalar copy/conversion kernels accept typed subviews. Other
  // native programs keep the alignment of their qualified vectorized paths.
  // GDN's F32 scalar loads also accept per-token gate subviews (a token's
  // scalar decay/beta is often only four bytes past the preceding token).
  return operation.get_if<Copy>() || operation.get_if<Cast>() ||
                 operation.get_if<Concat>() || operation.get_if<GatedDeltaNet>()
             ? data_type_size(type)
             : kBinding.minimum_alignment;
}

// Private value identities are recipe-local. No Graph types, borrowed graph
// spans or caller tensor addresses are retained by the immutable program.
struct Node final {
  Operation operation;
  std::vector<std::uint32_t> inputs;
  std::vector<std::uint32_t> outputs;
};
struct Recipe final {
  struct Constant final {
    std::uint32_t value;
    ConstTensorView binding;
  };
  std::vector<TensorDesc> values;
  std::vector<Node> nodes;
  std::vector<std::uint32_t> inputs;
  std::vector<std::uint32_t> outputs;
  // Graph's immutable artifact owns these bindings through region teardown.
  // Ordinary Compute inputs remain rebindable and never enter this list.
  std::vector<Constant> constants;
};

// Cold Graph constant preparation using the same native Cast graph and checked
// drain as ordinary execution. The caller owns destination and its budget.
HYLE_COMPUTE_PROVIDER_GGML_CUDA_API Status
widen_bfloat_constant(void *context, ConstTensorView source,
                      TensorView destination, mem::AllocatorRef) noexcept;
HYLE_COMPUTE_PROVIDER_GGML_CUDA_API Status
pack_matrix_constant(void *context, ConstTensorView source,
                     TensorView destination, mem::AllocatorRef) noexcept;

HYLE_COMPUTE_PROVIDER_GGML_CUDA_API bool
supports(void *context, Operation, std::span<const TensorDesc>,
         std::span<const TensorDesc>) noexcept;
HYLE_COMPUTE_PROVIDER_GGML_CUDA_API ProviderPrepareOutcome
compile(void *context, Recipe recipe, mem::AllocatorRef,
        detail::ProviderPrepared *) noexcept;
// Same-build Graph adapter supplies its static extension table. It reuses
// the identical Compute context, compiler and per-invocation lifecycle.
HYLE_COMPUTE_PROVIDER_GGML_CUDA_API Provider
with_extension(ProviderExtensionId id, const void *table) noexcept;

} // namespace hyle::compute::ggml_cuda::internal
