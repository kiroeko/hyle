# Compact scale views for Apple grouped preparation

Scale-byte CONT is removed. Real dense views can share their bank and offset. The new GPU case accepts only a single stored U8 byte broadcast as complete words, builds one aligned4B word with the original scalar-copy kernel, and shares it with zero strides. General strided reinterpretation remains unchanged. Global1B preparation is retained.

Air Mac16,12: old metadata control fails as expected; candidate canonical6/6 passes. Original/new ordinary, transpose, reversed and empty exact-bit controls pass. Public Pro FP4 geometry384x3072x7168 prepares its5,284,823,040B logical carrier under128MiB limit with268,509B actual peak, without allocating the real bank. Existing small FP4/FP8 numeric, invalid-ID and output-lifetime probes pass with unchanged historical bytes. No full Pro inference or throughput result is claimed.

All20 files replay exactly from locked MLX1f8. Only one native host TU and necessary wrapper/test/consumer TUs were compiled. SDK/context/common/native/metallib caches reused. All initial mechanical failures remain. No files were deleted. Exact candidates and3 retained objects are in cleanup-candidates.json.
