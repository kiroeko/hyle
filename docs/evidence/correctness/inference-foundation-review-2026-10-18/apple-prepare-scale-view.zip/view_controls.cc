#include <mlx/mlx.h>
#include <array>
#include <cstdint>
#include <cstdio>
#include <stdexcept>
#include <vector>
namespace mx = mlx::core;
void check(const char *name, mx::array input, const std::vector<std::uint32_t>& expected) {
  auto output = mx::contiguous(mx::view(mx::view(input, mx::float32), mx::uint32), false);
  mx::eval(output);
  if (output.size() != expected.size()) throw std::runtime_error("extent");
  for (std::size_t i=0;i<expected.size();++i)
    if(output.data<std::uint32_t>()[i]!=expected[i])throw std::runtime_error(name);
  std::printf("%s: %zu exact words PASS\n",name,expected.size());
}
int main(){try {
  const std::array<std::uint8_t,16> bytes{0,0,160,63,0,0,32,192,0,0,64,64,0,0,128,64};
  auto dense=mx::array(bytes.data(),{4,4},mx::uint8);mx::eval(dense);
  check("ordinary",dense,{0x3fa00000,0xc0200000,0x40400000,0x40800000});
  check("transpose",mx::transpose(dense),{0,0,0x804020a0,0x4040c03f});
  check("reversed",mx::as_strided(mx::reshape(dense,{16}),{4,4},{-4,1},12),
        {0x40800000,0x40400000,0xc0200000,0x3fa00000});
  check("empty",mx::zeros({0,4},mx::uint8),{});
  return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
