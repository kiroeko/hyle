get_filename_component(hyle_root "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
include("${hyle_root}/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(mlx_cast_patches)
message(STATUS "Apple repeated-byte scale view selected dependency identity PASS")
