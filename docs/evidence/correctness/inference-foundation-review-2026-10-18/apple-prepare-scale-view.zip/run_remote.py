from pathlib import Path
import json,subprocess,time,hashlib,sys
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'inference-foundation-review-20261018-apple-prepare-placeholder'
FP4=ROOT.parent/'inference-fusion-quantization-20261018-apple-indexed-fp4'
FP8=ROOT.parent/'inference-fusion-quantization-20261018-apple-indexed-fp8'
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
old=json.loads((OLD/'commands.json').read_text());base_compile=next(x['command']for x in old if x['tag']=='context.o-compile');base_link=next(x['command']for x in old if x['tag']=='canonical-link')
records=json.loads((ROOT/'commands.json').read_text())if(ROOT/'commands.json').exists()else[]
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,cmd,expected=0):
 cmd=list(map(str,cmd));stem=f'{len(records)+1:02d}-'+tag;t=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=150)
 (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-t,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
 (ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,flush=True)
 if p.returncode!=expected:print(p.stdout.decode(errors='replace')[-6000:]+p.stderr.decode(errors='replace')[-6000:]);raise SystemExit(1)
 print(p.stdout.decode(errors='replace')[-2300:]+p.stderr.decode(errors='replace')[-1000:],flush=True);return p
def compile(src,obj,native=False):
 if native:cmd=['/usr/bin/clang++','-O3','-DNDEBUG','-std=c++17','-arch','arm64','-DMLX_STATIC','-isystem',str(SDK/'include'),'-c',ROOT/src,'-o',ROOT/obj]
 else:
  cmd=base_compile[:base_compile.index('-c')];cmd[1:1]=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(ROOT/'src/compute')];cmd+=['-c',ROOT/src,'-o',ROOT/obj]
 run(obj+'-compile',cmd)
def link(name,probe,patched=True,gtest=False):
 cmd=[]
 for x in base_link:
  if x==str(OLD/'canonical'):cmd.append(str(ROOT/name))
  elif x==str(OLD/'canonical.o'):cmd.append(str(probe))
  elif x==str(FP4/'mature.o'):cmd.append(str(ROOT/'mature.o'))
  elif x.startswith('-Wl,-map,'):cmd.append('-Wl,-map,'+str(ROOT/(name+'.map')))
  elif not gtest and x.endswith(('libgtest.a','libgtest_main.a')):continue
  else:cmd.append(x)
 if patched:cmd.insert(cmd.index(str(SDK/'lib/libmlx.a')),str(ROOT/'primitives.o'))
 run(name+'-link',cmd)
 (ROOT/('identities-'+name+'.json')).write_text(json.dumps([identity(Path(x))for x in cmd if x.endswith(('.o','.a','.dylib'))],indent=2)+'\n')
def build():
 assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
 (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
 if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
 assert(ROOT/'mlx.metallib').resolve()==(SDK/'lib/mlx.metallib').resolve()
 compile('primitives.after.cpp','primitives.o',True)
 compile('src/compute_route_apple/apple_mature_float.cc','mature.o')
 compile('tests/compute_route_apple/context_test.cc','canonical.o')
 compile('view_controls.cc','controls.o');compile('pro_prepare.cc','pro.o')
 link('old-view',ROOT/'canonical.o',False,True);link('canonical',ROOT/'canonical.o',True,True)
 link('old-controls',ROOT/'controls.o',False);link('controls',ROOT/'controls.o')
 link('pro-prepare',ROOT/'pro.o');link('small-fp4',FP4/'probe.o');link('small-fp8',FP8/'probe.o')
def test():
 p=run('old-view-test',[ROOT/'old-view','--gtest_filter=AppleRegion.BroadcastByteViewMaterializesOnlyOneWord'],1)
 assert b'Value of: viewed.data_size()'in p.stdout or b'viewed.data_size()'in p.stdout
 run('old-controls-test',[ROOT/'old-controls']);run('controls-test',[ROOT/'controls'])
 run('canonical-test',[ROOT/'canonical','--gtest_filter=AppleRegion.*'])
 run('pro-prepare-test',[ROOT/'pro-prepare'])
 run('small-fp4-test',[ROOT/'small-fp4']);assert(ROOT/'output.bf16').read_bytes()==(FP4/'new-output.bf16').read_bytes()
 run('small-fp8-test',[ROOT/'small-fp8']);assert(ROOT/'output.f32').read_bytes()==(FP8/'new-output.f32').read_bytes()
 (ROOT/'comparison.json').write_text(json.dumps(dict(fp4_bits_equal=True,fp8_bits_equal=True))+'\n')
def finish():
 assert(ROOT/'output.bf16').read_bytes()==(FP4/'new-output.bf16').read_bytes()
 run('small-fp8-test',[ROOT/'small-fp8']);assert(ROOT/'output.f32').read_bytes()==(FP8/'new-output.f32').read_bytes()
 (ROOT/'comparison.json').write_text(json.dumps(dict(fp4_bits_equal=True,fp8_bits_equal=True))+'\n')
if __name__=='__main__':{'build':build,'test':test,'finish':finish}[sys.argv[1]]()
