from pathlib import Path
import json, hashlib, zipfile

R = Path.cwd()
O = Path(__file__).resolve().parent

def identity(p):
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

for measured in json.loads((O/'measured-sources.json').read_text()):
    rel = measured['path'].split('inference-foundation-review-20261018-apple-prepare-scale-view/', 1)[-1]
    p = R/rel if rel.startswith(('src/', 'tests/')) else O/rel
    assert identity(p)['sha256'] == measured['sha256'], rel

cleanup = json.loads((O/'cleanup-candidates.json').read_text())
for name, key in [('files', 'delete'), ('retained', 'retain')]:
    cleanup[key+'_count'] = len(cleanup[name])
    cleanup[key+'_logical_bytes'] = sum(x['bytes'] for x in cleanup[name])
assert not ({x['path'] for x in cleanup['files']} & {x['path'] for x in cleanup['retained']})
(O/'cleanup-candidates.json').write_text(json.dumps(cleanup, indent=2)+'\n')

summary = dict(
    status='implemented, tested and frozen',
    changes=[
        'Remove only scale CONT in weight/weight4; global one-byte placeholder and common reshape patch unchanged.',
        'GPU View only: U8->F32, nonempty output, last dimension4, data_size1, nonnegative offset, zero strides on all nonsingleton axes, readable byte in original allocation.',
        'Original Scalar copy builds exactly one aligned4B word. Output shares that word with zero strides. No general strided reinterpretation is opened.',
        'Real row-contiguous scale views use the existing shared-root/offset path; kernels consume actual ws_strides and ensure_row_contiguous=false.'
    ],
    upstream=dict(revision='1f8e74e3f12f31365464a6867c6579f0e9b29d85', version='MLX0.32.2',
                  replay='All20 native original SHAs, unique edits and after SHAs PASS'),
    actual=dict(
        machine='Air Mac16,12; machine.txt', canonical='6/6 PASS',
        old_control='Expected FAIL: data_size6 and dense strides rather than1/zero',
        controls='Original and candidate ordinary, transpose, reversed, empty: exact U32 words PASS',
        pro_prepare=dict(E=384,N=3072,K=7168,carrier_bytes=5284823040,
                         scale_bytes=1056964608,active_before=0,cache_before=0,
                         active=40,cache=268471,peak=268509,native_limit=134217728,
                         real_bank_allocated=False,mode='Public prepare only'),
        fp4='24672 exact BF16 outputs, two phases,6 tiny/6 invalid, retained output PASS; frozen historical bytes equal',
        fp8='12336 grouped +12288 linear outputs, maxAbs0, original2e-6+rel2e-6 budget, invalid/retained PASS; historical bytes equal'),
    build=dict(fresh_native=['primitives.after.cpp'],
               fresh_host=['apple_mature_float.cc','context_test.cc','view_controls.cc','pro_prepare.cc'],
               reused='Previous coldprepare context.o/common.o, existing FP4/FP8 probe objects, SDK/native kernels/metallib'),
    failures_retained=[
        'Initial diagnostic native -Wextra/-Werror exposed vendor header warnings, then upstream sign comparison and a new loop comparison. New loop uses size_t; final native command follows original prior-overlay flags. Numeric/general View paths were not edited to quiet warnings.',
        'After successful FP4 oracle, script referenced retired output.bf16. Corrected to frozen new-output.bf16, compared existing output without rerunning FP4, then ran only outstanding FP8.'
    ],
    rejected_design='Global4B placeholder rejected before execution because code reshape could require full bank; original1B retained.',
    not_claimed=['Real5.28GB Pro bank allocation/execution','Full model','Throughput or latency','Measured full real-bank runtime peak saving','Zero allocations: one4B word is intentional','CPU View change'],
    identity=dict(resource='resource-identity.json',source='measured-sources.json',
                  lock='mlx-lock-entry.after.json',audit='selected-dependency-audit.stdout.log',
                  link_maps='link-map-proof.json',cleanup='cleanup-candidates.json'))
(O/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
(O/'README.md').write_text(
    '# Compact scale views for Apple grouped preparation\n\n'
    'Scale-byte CONT is removed. Real dense views can share their bank and offset. '
    'The new GPU case accepts only a single stored U8 byte broadcast as complete words, '
    'builds one aligned4B word with the original scalar-copy kernel, and shares it with zero strides. '
    'General strided reinterpretation remains unchanged. Global1B preparation is retained.\n\n'
    'Air Mac16,12: old metadata control fails as expected; candidate canonical6/6 passes. '
    'Original/new ordinary, transpose, reversed and empty exact-bit controls pass. '
    'Public Pro FP4 geometry384x3072x7168 prepares its5,284,823,040B logical carrier '
    'under128MiB limit with268,509B actual peak, without allocating the real bank. '
    'Existing small FP4/FP8 numeric, invalid-ID and output-lifetime probes pass with unchanged historical bytes. '
    'No full Pro inference or throughput result is claimed.\n\n'
    'All20 files replay exactly from locked MLX1f8. Only one native host TU and necessary '
    'wrapper/test/consumer TUs were compiled. SDK/context/common/native/metallib caches reused. '
    'All initial mechanical failures remain. No files were deleted. Exact candidates and3 retained '
    'objects are in cleanup-candidates.json.\n', newline='\n')

allowed={'.json','.py','.cc','.cpp','.h','.md','.diff','.log','.txt','.cmake'}
files=[p for p in O.rglob('*') if p.is_file() and p.suffix in allowed and '__pycache__' not in p.parts]
z=O/'source-results.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as out:
    for p in sorted(files,key=lambda p:p.relative_to(O).as_posix()):
        out.write(p,p.relative_to(O).as_posix())
print(json.dumps(dict(archive=identity(z),members=len(files),
                     cleanup=(cleanup['delete_count'],cleanup['delete_logical_bytes']),
                     retained=cleanup['retained']),indent=2))
