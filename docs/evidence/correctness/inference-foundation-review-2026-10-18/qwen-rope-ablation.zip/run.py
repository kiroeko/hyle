from pathlib import Path
import hashlib,json,os,subprocess,sys,time
s=Path(__file__).resolve().parent
source=s/'ablate.py'; b=source.read_bytes()
record=dict(command=[sys.executable,str(source)],cwd=str(s),source=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()),exit=None,performance_measurement=False)
assert not (s/'run.json').exists()
(s/'run.json').write_text(json.dumps(record,indent=2)+'\n')
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
start=time.perf_counter()
with (s/'stdout.log').open('wb') as out,(s/'stderr.log').open('wb') as err:
 process=subprocess.Popen(record['command'],cwd=s,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 record['pid']=process.pid;(s/'run.json').write_text(json.dumps(record,indent=2)+'\n')
 print('STARTED',process.pid,flush=True)
 record['exit']=process.wait(timeout=180)
record['seconds']=time.perf_counter()-start
(s/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print('FINISHED',record['exit'],record['seconds'],flush=True)
print((s/'stdout.log').read_text(errors='replace')[-8000:],flush=True)
print((s/'stderr.log').read_text(errors='replace')[-3000:],flush=True)
raise SystemExit(record['exit'])
