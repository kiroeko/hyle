"""Archive this completed diagnosis; never executes model or build commands."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
TARGET = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-rope-ablation.zip'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


assert not TARGET.exists(), 'Never overwrite an evidence archive'
results = read(STAGE / 'results.json')
guard = read(STAGE / 'baseline/byte-guard.json')
environment = read(STAGE / 'environment.json')
run = read(STAGE / 'run.json')
assert run['exit'] == 0 and not run['performance_measurement']
assert guard['passed'] and len(guard['files']) == 150
assert all(row['byte_equal'] for row in guard['files'])
assert results['baseline_byte_matches'] == 150
assert not results['product_changed'] and not results['candidate_input_used']
assert not results['weights_copied']
assert identity(STAGE / 'ablate.py')['sha256'] == run['source']['sha256']
assert identity(ROOT / 'tools/qwen35_text/reference.py')['sha256'] == environment['reference']['sha256']

names = ['ablate.py', 'run.py', 'run.json', 'environment.json', 'results.json',
         'stdout.log', 'stderr.log', 'baseline/byte-guard.json',
         'baseline/results.json', 'f32-rope/results.json',
         'docs.diff', 'docs-identities.json', 'freeze.py']
payload_count = 0
for mode in ['baseline', 'f32-rope']:
    actual = read(STAGE / mode / 'results.json')
    expected = {(row['phase'], row['file']): row for row in actual['files']}
    for phase in ['prefill', 'continuation', 'decode1']:
        for name in ['logits.f32', 'hidden.bf16']:
            relative = f'{mode}/{phase}/{name}'
            found = identity(STAGE / relative)
            claimed = expected[phase, name]
            assert (found['bytes'], found['sha256']) == (claimed['bytes'], claimed['sha256'])
            names.append(relative)
            payload_count += 1

members = {name: STAGE / name for name in names}
members['source/reference.py'] = ROOT / 'tools/qwen35_text/reference.py'
identities = [dict(member=name, **identity(path)) for name, path in sorted(members.items())]
manifest = dict(status='single_factor_diagnosis_not_numerical_acceptance',
                baseline_payloads=150, baseline_bytes=sum(x['bytes'] for x in guard['files']),
                archived_decision_payloads=payload_count, performance_measurement=False,
                product_math_changed=False, files=identities)
manifest_path = STAGE / 'archive-identities.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
members['archive-identities.json'] = manifest_path

allowed = {'.py', '.json', '.log', '.diff', '.f32', '.bf16'}
with zipfile.ZipFile(TARGET, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(members.items()):
        assert PurePosixPath(name).suffix in allowed
        assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        assert path.is_file() and not path.is_symlink()
        archive.write(path, name)

with zipfile.ZipFile(TARGET) as archive:
    assert set(archive.namelist()) == set(members)
    for name, path in members.items():
        data = archive.read(name)
        current = path.read_bytes()
        assert data == current, name
    assert archive.testzip() is None

receipt = dict(archive=identity(TARGET), entries=len(members),
               uncompressed_bytes=sum(path.stat().st_size for path in members.values()),
               baseline_payloads_verified=150, archived_decision_payloads=payload_count,
               source_and_every_zip_entry_verified=True,
               excluded=['model', 'weights', 'SDK', 'complete trace', 'objects', 'executables', 'pycache'],
               conclusion='RoPE intermediate precision contributes partly on this fixed journey; no product fix, numerical acceptance or performance claim.')
(STAGE / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
