"""Whole-model single-factor RoPE diagnosis, never a Hyle numerical oracle.

First reproduce every byte of the saved official eager three-phase reference.
Then reuse the weights and fixed input tokens, reset the independent cache,
and change only rotary intermediate storage to F32 with final BF16 Q/K.
No candidate input/state, tolerance change, SDK build or weight copy.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import time
import types

os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
                  HF_HUB_DISABLE_TELEMETRY='1', TOKENIZERS_PARALLELISM='false',
                  OMP_NUM_THREADS='2', MKL_NUM_THREADS='2')

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
BASE = ROOT / '.scratch/inference-execution-refactor-2026-10-18/qwen35-text'
ORIGINAL = BASE / 'reference'
INPUTS = BASE / 'inputs-v2'
CANDIDATE = ROOT / '.scratch/architecture-refactor-2026-10-18/generic-progress/qwen/trace-01'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


receipt = read(ORIGINAL / 'reference.json')
reference = ROOT / 'tools/qwen35_text/reference.py'
assert identity(reference)['sha256'] == receipt['reference_sha256']
assert [r['name'] for r in receipt['steps']] == ['prefill', 'continuation', 'decode1']
assert [len(r['input_ids']) for r in receipt['steps']] == [23, 4, 1]
assert receipt['steps'][2]['input_ids'] == [receipt['steps'][1]['next_id']]
assert list(map(int, (INPUTS / 'prompt.ids').read_text().split())) == receipt['steps'][0]['input_ids']
manifest = (INPUTS / 'weights.tsv').read_text().splitlines()
assert manifest[2] == receipt['source_id']
shard = Path(manifest[1])
assert shard.is_file()

import numpy as np
import torch
from safetensors import safe_open
from transformers.models.qwen3_5 import modeling_qwen3_5 as impl
from transformers.models.qwen3_5.configuration_qwen3_5 import Qwen3_5TextConfig

assert identity(Path(impl.__file__))['sha256'] == receipt['model_source_sha256']
assert torch.__version__ == receipt['torch']
assert torch.cuda.get_device_name() == receipt['gpu']
torch.set_num_threads(2)
torch.set_num_interop_threads(1)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
spec = importlib.util.spec_from_file_location('original_qwen_reference', reference)
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
config = Qwen3_5TextConfig(**read(shard.parent / 'config.json')['text_config'])
config._attn_implementation = 'eager'
assert config.rope_parameters['rope_type'] == 'default'
assert config.rope_parameters['rope_theta'] == 10000000
assert config.head_dim == 256
start = time.perf_counter()
with torch.device('meta'):
    model = impl.Qwen3_5ForCausalLM(config)
model.model.rotary_emb = impl.Qwen3_5TextRotaryEmbedding(config, device='cpu')
parameters = {}
with safe_open(shard, framework='pt', device='cpu') as source:
    for name in source.keys():
        if name.startswith('model.language_model.'):
            parameters[name.replace('model.language_model.', 'model.', 1)] = source.get_tensor(name)
assert len(parameters) == receipt['text_tensors'] == 320
parameters['lm_head.weight'] = parameters['model.embed_tokens.weight']
model.load_state_dict(parameters, strict=True, assign=True)
model.lm_head.weight = model.model.embed_tokens.weight
del parameters
model.eval().to('cuda')
for layer in model.model.layers:
    if hasattr(layer, 'linear_attn'):
        layer.linear_attn.forward = types.MethodType(original.fixed_recurrent_forward, layer.linear_attn)
captured = []
model.model.norm.register_forward_hook(lambda module, inputs, output: captured.append(output[:, -1:].detach()))
torch.cuda.synchronize()
save(STAGE / 'environment.json', dict(torch=torch.__version__, gpu=torch.cuda.get_device_name(),
    cuda=torch.version.cuda, model_load_seconds=time.perf_counter()-start,
    text_weight_bytes=sum(t.numel()*t.element_size() for t in model.parameters()),
    reference=identity(reference), official=identity(Path(impl.__file__)),
    input_manifest=identity(INPUTS/'weights.tsv'), fixed_input_steps=receipt['steps'],
    script=identity(Path(__file__)), performance_measurement=False))


def raw(tensor):
    return tensor.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()


def metric(actual, expected):
    a = np.asarray(actual, dtype=np.float64).reshape(-1)
    b = np.asarray(expected, dtype=np.float64).reshape(-1)
    assert a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all()
    delta = a-b
    result = dict(elements=a.size, equal=int(np.count_nonzero(a==b)),
        max_abs=float(np.max(np.abs(delta))), relative_l2=float(np.linalg.norm(delta)/np.linalg.norm(b)),
        cosine=float(a@b/(np.linalg.norm(a)*np.linalg.norm(b))))
    if a.size == config.vocab_size:
        def logs(x):
            z=x-x.max()
            return z-np.log(np.exp(z).sum())
        la,lb=logs(a),logs(b)
        topa=np.argsort(-a,kind='stable')[:10];topb=np.argsort(-b,kind='stable')[:10]
        result.update(kl_expected_to_actual=float(np.sum(np.exp(lb)*(lb-la))),
            top1_actual=int(topa[0]),top1_expected=int(topb[0]),
            top5_overlap=len(set(topa[:5])&set(topb[:5])),top10_overlap=len(set(topa)&set(topb)))
    return result


def run(mode):
    cache = None
    rows = []
    matched = []
    target = STAGE / mode
    target.mkdir(exist_ok=False)
    for step in receipt['steps']:
        name=step['name']; directory=target/name; directory.mkdir()
        torch.cuda.synchronize(); start=time.perf_counter()
        with torch.inference_mode():
            out=model(input_ids=torch.tensor([step['input_ids']],dtype=torch.long,device='cuda'),
                past_key_values=cache,use_cache=True,logits_to_keep=1)
        cache=out.past_key_values
        logits=out.logits[0,-1].float()
        payloads={'logits.f32':logits,'hidden.bf16':captured.pop()}
        for layer in range(24):
            if layer%4==3:
                payloads[f'layer{layer}.key.bf16']=cache.key_cache[layer][0].transpose(0,1)
                payloads[f'layer{layer}.value.bf16']=cache.value_cache[layer][0].transpose(0,1)
            else:
                payloads[f'layer{layer}.conv.bf16']=cache.conv_states[layer][:,:,-3:].transpose(1,2)
                payloads[f'layer{layer}.gdn.f32']=cache.recurrent_states[layer].transpose(-1,-2)
        assert len(payloads)==50
        guard=[]
        for file,tensor in payloads.items():
            data=raw(tensor); origin=ORIGINAL/name/file
            row=dict(phase=name,file=file,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
                     reference=identity(origin),byte_equal=data==origin.read_bytes())
            guard.append(row)
            invariant = file in {f'layer{i}.{suffix}' for i in range(3) for suffix in ['conv.bf16','gdn.f32']}
            invariant |= file=='layer3.value.bf16'
            if mode!='baseline' and invariant:
                assert row['byte_equal'],('RoPE-only invariant changed',name,file)
            if mode!='baseline' and file=='layer3.key.bf16':
                a=np.frombuffer(data,dtype='<u2').reshape(-1,2,256)
                b=np.frombuffer(origin.read_bytes(),dtype='<u2').reshape(-1,2,256)
                assert np.array_equal(a[...,64:],b[...,64:]),'RoPE-only K tail changed'
            # Keep decision vectors; the authenticated original represents
            # matching state bytes. Other states remain counted/hash-checked.
            if (mode=='baseline' and not row['byte_equal']) or file in {'logits.f32','hidden.bf16'}:
                (directory/file).write_bytes(data)
        matched.extend(guard)
        if mode=='baseline':
            save(target/'byte-guard.json',dict(files=matched,passed=all(r['byte_equal'] for r in matched)))
            assert all(r['byte_equal'] for r in guard),'Fresh baseline differs: stop before RoPE intervention'
        current=np.fromfile(CANDIDATE/name/'logits.f32',dtype='<f4')
        expected=np.fromfile(ORIGINAL/name/'logits.f32',dtype='<f4')
        actual=logits.detach().cpu().numpy()
        rows.append(dict(phase=name,input_ids=step['input_ids'],next_id=int(logits.argmax().item()),
            actual_vs_original=metric(actual,expected),candidate_vs_actual=metric(current,actual),
            candidate_vs_original=metric(current,expected),diagnostic_seconds=time.perf_counter()-start))
        save(target/'results.json',dict(mode=mode,rows=rows,files=matched))
        print(mode,name,json.dumps(rows[-1]),flush=True)
        del payloads,logits,out
    del cache
    torch.cuda.synchronize()
    return rows


baseline=run('baseline')
assert read(STAGE/'baseline/byte-guard.json')['passed']
assert len(read(STAGE/'baseline/byte-guard.json')['files'])==150
old_rotary=impl.Qwen3_5TextRotaryEmbedding.forward
old_apply=impl.apply_rotary_pos_emb
rotations=[]


def f32_angles(self,x,position_ids):
    # Original frequency generation, MRoPE layout, trigonometry and scaling.
    # x is used there for device/dtype only; the final trig cast becomes F32.
    return old_rotary(self,x.float(),position_ids)


def f32_rotation(q,k,cos,sin,unsqueeze_dim=1):
    assert q.dtype==k.dtype==torch.bfloat16
    assert cos.dtype==sin.dtype==torch.float32 and cos.shape[-1]==64
    cos=cos.unsqueeze(unsqueeze_dim);sin=sin.unsqueeze(unsqueeze_dim)
    def rotate(t):
        prefix=t[...,:64].float()
        rotated=(prefix*cos+impl.rotate_half(prefix)*sin).to(t.dtype)
        result=torch.cat((rotated,t[...,64:]),dim=-1)
        assert result.dtype==t.dtype and torch.equal(result[...,64:].view(torch.int16),t[...,64:].view(torch.int16))
        return result
    result=rotate(q),rotate(k)
    rotations.append(dict(q_shape=list(q.shape),k_shape=list(k.shape),rotary_dimensions=64,
                          input_dtype=str(q.dtype),output_dtype=str(result[0].dtype)))
    return result


impl.Qwen3_5TextRotaryEmbedding.forward=f32_angles
impl.apply_rotary_pos_emb=f32_rotation
try:
    variant=run('f32-rope')
finally:
    impl.Qwen3_5TextRotaryEmbedding.forward=old_rotary
    impl.apply_rotary_pos_emb=old_apply
assert len(rotations)==18
contribution=[]
for step in receipt['steps']:
    name=step['name']
    base=np.fromfile(STAGE/'baseline'/name/'logits.f32',dtype='<f4').astype(np.float64)
    rotated=np.fromfile(STAGE/'f32-rope'/name/'logits.f32',dtype='<f4').astype(np.float64)
    candidate=np.fromfile(CANDIDATE/name/'logits.f32',dtype='<f4').astype(np.float64)
    delta=candidate-base;intervention=rotated-base
    contribution.append(dict(phase=name,original_gap_l2=float(np.linalg.norm(delta)),
        intervention_l2=float(np.linalg.norm(intervention)),remaining_gap_l2=float(np.linalg.norm(delta-intervention)),
        cosine_gap_intervention=float(delta@intervention/(np.linalg.norm(delta)*np.linalg.norm(intervention))),
        squared_gap_fraction_explained=float(1-np.dot(delta-intervention,delta-intervention)/np.dot(delta,delta))))
save(STAGE/'results.json',dict(status='completed_single_factor_diagnosis_not_numerical_acceptance',
    baseline=baseline,variant=variant,rotations=rotations,baseline_byte_matches=150,contribution=contribution,
    candidate_input_used=False,product_changed=False,weights_copied=False,
    controlled_change='Only RoPE trig/product intermediate precision; BF16 Q/K outputs and untouched tail. Original eager attention and all other math preserved.',
    fixed_input_ids=True,independent_caches=True,
    limits=['One prompt and two cached phases; only last-position logits each phase.',
            'Not a full F32 model or native attention instruction-order emulator.',
            'No numerical budget or precision-policy change, throughput comparison, or model accuracy acceptance.']))
print('COMPLETED_SINGLE_FACTOR_DIAGNOSIS',flush=True)
