param([switch]$Mac)
# Reclaim frozen probe images; retain source, logs, data, all objects and SDKs.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$stage = Join-Path $workspace '.scratch/inference-foundation-review-2026-10-18'
$plan = Get-Content -LiteralPath (Join-Path $stage 'archive-cleanup/pending-followup-binaries.json') -Raw | ConvertFrom-Json
$allowed = @(
    (Join-Path $stage 'row-cache-paged-graph'),
    (Join-Path $stage 'row-cache-pending-graph'),
    (Join-Path $workspace '.scratch/inference-fusion-quantization-2026-10-18/cpu-dense-fp8-block'),
    (Join-Path $stage 'kda-prefix'),
    (Join-Path $stage 'row-cache-paged-reader'),
    (Join-Path $stage 'mla-graph-window')
) | ForEach-Object { (Resolve-Path -LiteralPath $_).Path }
foreach ($directory in $allowed) {
    if (-not $directory.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Stage outside workspace' }
    if ((Get-Item -LiteralPath $directory).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected stage link' }
}
foreach ($archive in $plan.archives) {
    $path = Join-Path $workspace ('docs/evidence/correctness/inference-foundation-review-2026-10-18/' + $archive.name)
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $archive.sha256) { throw 'Archive identity mismatch' }
}
$targets = foreach ($entry in $plan.files) {
    $path = [IO.Path]::GetFullPath($entry.path)
    $parent = [IO.Path]::GetDirectoryName($path)
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($parent -notin $allowed -or $extension -notin @('.exe','.lib','.exp','.pdb')) { throw "Unexpected target: $path" }
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside workspace' }
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $item = Get-Item -LiteralPath $path
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected file link: $path" }
        if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Changed artifact: $path" }
        $item
    }
}
$freed = 0L
foreach ($item in $targets) {
    $freed += $item.Length
    Remove-Item -LiteralPath $item.FullName
}
Write-Output "Removed $($targets.Count) frozen probe binaries: $freed bytes. All objects, SDKs and source/results retained."
if ($Mac) {
    $manifestPath = Join-Path $stage 'archive-cleanup/mac-row-binaries.json'
    $encoded = [Convert]::ToBase64String([IO.File]::ReadAllBytes($manifestPath))
    $remoteScript = @'
import base64, hashlib, json
from pathlib import Path
plan = json.loads(base64.b64decode('__MANIFEST__'))
base = Path('/Users/kiro/hyle-scratch/compute-unified').resolve(strict=True)
roots = {Path(p).resolve(strict=True) for p in plan['roots']}
assert all(p.parent == base for p in roots)
targets = []
for record in plan['files']:
    path = Path(record['path'])
    assert path.parent.resolve(strict=True) in roots
    assert path.suffix == '' and not path.is_symlink()
    if not path.exists():
        continue
    assert path.is_file() and path.resolve(strict=True).parent in roots
    assert path.stat().st_size == record['bytes'], str(path)
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == record['sha256'], str(path)
    assert data[:4] in (bytes.fromhex('cffaedfe'), bytes.fromhex('feedfacf')), str(path)
    targets.append((path, record['bytes']))
for record in plan['retain']:
    path = Path(record['path'])
    assert path.is_file() and path.stat().st_size == record['bytes'], str(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256'], str(path)
for path, size in targets:
    path.unlink()
print(json.dumps({'removed': len(targets), 'bytes': sum(size for path,size in targets),
    'retained_product_and_test_objects': len(plan['retain']), 'retained_source_logs_maps_sdk': True}))
'@
    $remoteScript.Replace('__MANIFEST__', $encoded) | & ssh -o BatchMode=yes -o ConnectTimeout=10 kiro@172.22.10.198 'python3 -'
    if ($LASTEXITCODE -ne 0) { throw 'Mac cleanup verification failed' }
}
