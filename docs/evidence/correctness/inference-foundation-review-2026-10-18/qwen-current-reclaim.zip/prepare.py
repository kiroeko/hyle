from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
def ident(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
assert not(OUT/'cleanup-plan.json').exists()
(OUT/'previous-test.ps1').write_bytes((ROOT/'test.ps1').read_bytes())
stages=['qwen38-gqa16-current','qwen-fixed-decode','qwen-capture-current','qwen-timing-boundary']
archives=[];targets=[];objects=[]
for name in stages:
    stage=ARCH/name;entry=read(stage/'archive-receipt.json')['archive']
    assert ident(Path(entry['path']))==entry
    archives.append(entry)
    if name in stages[:2]:rows=read(stage/'linked-image-cleanup.json')['targets']
    else:rows=[ident(p)for stem in (['qwen-capture','qwen-facts']if name==stages[2]else['qwen-timed'])for suffix in ['.exe','.map','.lib','.exp']if(p:=stage/(stem+suffix)).is_file()]
    assert len(rows)==(8 if name in [stages[0],stages[2]]else 4)
    for row in rows:
        p=Path(row['path']);assert p.parent.resolve()==stage.resolve()and p.suffix in {'.exe','.map','.lib','.exp'}
        assert ident(p)==row;targets.append(row)
    objects.extend(ident(p)for p in sorted(stage.glob('*.obj')))
save(OUT/'cleanup-plan.json',dict(archives=archives,targets=targets,retained_objects=objects,bytes=sum(x['bytes']for x in targets),files=len(targets),all_model_sdk_raw_data_and_logs_retained=True))
print(json.dumps(dict(files=len(targets),bytes=sum(x['bytes']for x in targets),retained_objects=len(objects))))
