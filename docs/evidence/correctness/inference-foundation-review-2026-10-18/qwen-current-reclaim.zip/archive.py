from pathlib import Path
import hashlib,json,zipfile
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def ident(p):
    b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
receipt=json.loads((OUT/'cleanup-receipt.json').read_text(encoding='utf-8-sig'))
assert receipt['complete']and receipt['files']==24 and receipt['bytes']==897306207
assert ident(ROOT/'test.ps1')['sha256']==receipt['script_sha256']
(OUT/'executed-root-test.ps1').write_bytes((ROOT/'test.ps1').read_bytes())
files=[p for p in sorted(OUT.iterdir())if p.is_file()and p.name!='archive-receipt.json']
assert all(p.suffix in {'.json','.py','.ps1'}and not p.is_symlink()for p in files)
entries=[dict(relative=p.name,**ident(p))for p in files]
dest=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-current-reclaim.zip'
assert not dest.exists()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for p in files:z.write(p,p.name)
    z.writestr('archive-manifest.json',json.dumps(entries,indent=2)+'\n')
with zipfile.ZipFile(dest)as z:
    assert z.testzip()is None
    for e in entries:assert hashlib.sha256(z.read(e['relative'])).hexdigest()==e['sha256']
result=dict(archive=ident(dest),entries=len(entries)+1,all_payloads_verified=True,reclaimed_bytes=receipt['bytes'],retained_objects=len(receipt['retained_objects']))
(OUT/'archive-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
