param([switch]$ReclaimQwenCurrent)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/qwen-current-reclaim'
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
$allowedStages = @('qwen38-gqa16-current', 'qwen-fixed-decode', 'qwen-capture-current', 'qwen-timing-boundary') | ForEach-Object {
    [IO.Path]::GetFullPath((Join-Path $workspace ('.scratch/architecture-refactor-2026-10-18/' + $_)))
}
function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $cursor = $item
    while ($null -ne $cursor -and $cursor.FullName.Length -ge $workspace.Length) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
        throw "Identity changed: $path"
    }
}
foreach ($archive in $plan.archives) { Assert-Identity $archive }
foreach ($object in $plan.retained_objects) { Assert-Identity $object }
foreach ($entry in $plan.targets) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if ($allowedStages -notcontains [IO.Path]::GetDirectoryName($path)) { throw "Outside exact completed stages: $path" }
    if (@('.exe', '.map', '.lib', '.exp') -notcontains [IO.Path]::GetExtension($path)) { throw "Not an approved linked image: $path" }
    Assert-Identity $entry
}
if (-not $ReclaimQwenCurrent) {
    [pscustomobject]@{ files = $plan.files; bytes = $plan.bytes; archived = $plan.archives.Count; retained_objects = $plan.retained_objects.Count }
    return
}
$receiptPath = Join-Path $stage 'cleanup-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup receipt already exists; do not replay deletions' }
$deleted = [Collections.Generic.List[object]]::new()
foreach ($entry in $plan.targets) {
    Remove-Item -LiteralPath ([string]$entry.path)
    if (Test-Path -LiteralPath ([string]$entry.path)) { throw "Still exists: $($entry.path)" }
    $deleted.Add($entry)
    [pscustomobject]@{
        deleted = $deleted.ToArray(); files = $deleted.Count; bytes = ($deleted | Measure-Object -Property bytes -Sum).Sum
        archives_verified = $true; retained_objects = $plan.retained_objects; complete = ($deleted.Count -eq $plan.targets.Count)
        script_sha256 = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
    } | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
foreach ($object in $plan.retained_objects) { Assert-Identity $object }
[pscustomobject]@{ deleted_files = $deleted.Count; reclaimed_bytes = $plan.bytes; retained_objects = $plan.retained_objects.Count }
