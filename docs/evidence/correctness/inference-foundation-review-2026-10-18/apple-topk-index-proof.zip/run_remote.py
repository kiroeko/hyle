from pathlib import Path
import hashlib, json, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent/'inference-foundation-review-20261018-apple-row-cache-cold'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
old = json.loads((OLD/'commands.json').read_text())
compile_base = next(x['command'] for x in old if x['tag']=='context.o-compile' and x['exit']==0)
link_base = next(x['command'] for x in old if x['tag']=='row-cache-test-link' and x['exit']==0)
records = json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []

def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def run(tag, command):
    command = list(map(str, command)); stem = f'{len(records)+1:02d}-{tag}'; start=time.monotonic()
    p = subprocess.run(command,cwd=ROOT,capture_output=True,timeout=150)
    (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout); (ROOT/(stem+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start,
                        stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
    (ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(stem,p.returncode,flush=True)
    print(p.stdout.decode(errors='replace')[-6000:]+p.stderr.decode(errors='replace')[-6000:],flush=True)
    if p.returncode: raise SystemExit(1)

def compile(source,obj):
    command=compile_base[:compile_base.index('-c')]
    command[1:1]=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),
                   '-I'+str(ROOT/'src/compute'),'-I'+str(ROOT/'src/compute_ggml_runtime'),
                   '-I'+str(ROOT/'src/compute_provider_ggml_metal'),
                   '-isystem','/Users/kiro/hyle-scratch/compute-unified/a-apple/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-da5abe30b13e6512/include']
    run(obj+'-compile',command+['-c',ROOT/source,'-o',ROOT/obj])

def link(name,native):
    command=[];replaced=dict(context=0,operations=0,recurrent=0,native=0,test=0,graph=0)
    for arg in link_base:
        if arg==str(OLD/'row-cache-test'):command.append(str(ROOT/name))
        elif arg.endswith('/context.o'):command.append(str(ROOT/'context.o'));replaced['context']+=1
        elif arg.endswith('/operations.o'):command.append(str(ROOT/'operations.o'));replaced['operations']+=1
        elif arg.endswith('/recurrent.o'):command.append(str(ROOT/'recurrent.o'));replaced['recurrent']+=1
        elif arg.endswith('/native.o'):command.append(str(ROOT/native));replaced['native']+=1
        elif arg.endswith('/test.o'):command.append(str(ROOT/'test.o'));replaced['test']+=1
        elif arg==str(SDK/'lib/libhyle_graph_route_apple.a'):
            command.extend([str(ROOT/'graph.o'),arg]);replaced['graph']+=1
        elif arg.startswith('-Wl,-map,'):command.append('-Wl,-map,'+str(ROOT/(name+'.map')))
        else:command.append(arg)
    assert all(n==1 for n in replaced.values()),replaced
    run(name+'-link',command)
    identities=[identity(p)for p in command if p.endswith(('.o','.a','.dylib'))];identities.append(identity(ROOT/name))
    (ROOT/('identities-'+name+'.json')).write_text(json.dumps(identities,indent=2)+'\n')

def build():
    assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
    (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)
        +subprocess.check_output(['xcrun','clang++','--version'],text=True))
    if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
    assert(ROOT/'mlx.metallib').resolve()==(SDK/'lib/mlx.metallib').resolve()
    for source,obj in [('src/compute_route_apple/apple_context.cc','context.o'),
                       ('src/compute_route_apple/apple_operations.cc','operations.o'),
                       ('src/compute_route_apple/apple_recurrent.cc','recurrent.o'),
                       ('src/compute_provider_ggml_metal/native_program.cc','native.o'),
                       ('src/graph_route_apple/apple_lowering.cc','graph.o'),
                       ('tests/graph_route_apple/topk_experts_test.cc','test.o')]:compile(source,obj)
    link('canonical','native.o')

def resume():
    for source,obj in [('src/compute_provider_ggml_metal/native_program.cc','native.o'),
                       ('src/graph_route_apple/apple_lowering.cc','graph.o'),
                       ('tests/graph_route_apple/topk_experts_test.cc','test.o')]:compile(source,obj)
    link('canonical','native.o')

def diagnostics():
    source=(ROOT/'src/compute_provider_ggml_metal/native_program.cc').read_text()
    source=source.replace('#include <cstdint>','#include <cstdint>\n#include <cstdio>')
    anchor='namespace hyle::compute::ggml_metal {'
    source=source.replace(anchor,anchor+'\nnamespace { std::uint64_t scans=0, visits=0, proofs=0; struct Dump { ~Dump(){std::fprintf(stderr,"IDCOUNTS scans=%llu visits=%llu proofs=%llu\\n",(unsigned long long)scans,(unsigned long long)visits,(unsigned long long)proofs);} } dump; }',1)
    source=source.replace('return run_impl(ports, true);','++proofs;\n  return run_impl(ports, true);',1)
    old_loop='''        for (std::size_t index = 0; index < s.checked_index_count; ++index)
          if (indices[index] < 0 || indices[index] >= s.checked_index_extent)
            return Status::OutOfRange(
                "ggml Metal index out of range; output unchanged");'''
    new_loop='''        ++scans;
        for (std::size_t index = 0; index < s.checked_index_count; ++index) {
          ++visits;
          if (indices[index] < 0 || indices[index] >= s.checked_index_extent)
            return Status::OutOfRange(
                "ggml Metal index out of range; output unchanged");
        }'''
    assert source.count(old_loop)==1
    source=source.replace(old_loop,new_loop)
    (ROOT/'native-counted.cc').write_text(source)
    before=source.replace('  auto &s = *state_;\n  if (s.failed)',
                          '  proven_indices = false; // Counterfactual: original CPU validation work.\n  auto &s = *state_;\n  if (s.failed)',1)
    assert before!=source
    (ROOT/'native-force-scan.cc').write_text(before)
    # Relative native_program.h is an explicit include location for these two overlays.
    for name in ['native-counted','native-force-scan']:compile(name+'.cc',name+'.o')
    link('counted','native-counted.o');link('force-scan','native-force-scan.o')

def test():
    run('force-scan-test',[ROOT/'force-scan','--gtest_filter=AppleTopKExperts.*'])
    run('counted-test',[ROOT/'counted','--gtest_filter=AppleTopKExperts.*'])
    run('canonical-test',[ROOT/'canonical','--gtest_filter=AppleTopKExperts.*'])

if __name__=='__main__':{'build':build,'resume':resume,'diagnostics':diagnostics,'test':test}[sys.argv[1]]()
