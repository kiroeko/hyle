#include "hyle/compute/batch_paged_native.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <mutex>
#include <utility>

#include "hyle/compute/detail/lease_access.h"
#include "hyle/util/ref_counted.h"

namespace hyle::compute {
namespace detail {
struct NativePagedBatchProgramData final : util::RefCounted<NativePagedBatchProgramData> {
  NativePagedBatchProgramData(BatchSchema selected, NativePagedBatchOptions settings, mem::AllocatorRef a)
      : schema(std::move(selected)), options(std::move(settings)), allocator(a) {}
  void destroy() noexcept {
    const auto selected = allocator;
    this->~NativePagedBatchProgramData();
    selected.deallocate(this, sizeof(*this), alignof(NativePagedBatchProgramData));
  }
  BatchSchema schema;
  NativePagedBatchOptions options;
  mem::AllocatorRef allocator;
  std::array<TensorDesc, 4> descriptions;
  NativePagedBatchCosts costs;
};
struct NativePagedBatchVersionOwner final {
  NativePagedBatchProgram program;
  BatchLayoutVersion layout;
  mem::AllocatorRef allocator;
};
struct NativePagedBatchVersionData final:util::RefCounted<NativePagedBatchVersionData> {
  NativePagedBatchVersionData(NativePagedBatchProgram p,BatchLayoutVersion l,mem::AllocatorRef a,ResourceBudget b)
      :program(std::move(p)),layout(std::move(l)),allocator(a),budget(std::move(b)){}
  void destroy()noexcept{const auto a=allocator;this->~NativePagedBatchVersionData();a.deallocate(this,sizeof(*this),alignof(NativePagedBatchVersionData));}
  NativePagedBatchProgram program;BatchLayoutVersion layout;mem::AllocatorRef allocator;ResourceBudget budget;
  mutable std::mutex export_lock;mutable ReadLease indices;
};
} // namespace detail
namespace {
void release_version_owner(void *opaque) noexcept {
  auto *owner = static_cast<detail::NativePagedBatchVersionOwner *>(opaque);
  const auto allocator = owner->allocator;
  allocator.destroy(owner);
}
} // namespace

NativePagedBatchProgram::NativePagedBatchProgram(const NativePagedBatchProgram &other) noexcept
    : data_(other.data_) { if (data_) data_->incref(); }
NativePagedBatchProgram &NativePagedBatchProgram::operator=(const NativePagedBatchProgram &other) noexcept {
  if (this != &other) { NativePagedBatchProgram copy(other); std::swap(data_, copy.data_); }
  return *this;
}
NativePagedBatchProgram::NativePagedBatchProgram(NativePagedBatchProgram &&other) noexcept
    : data_(std::exchange(other.data_, nullptr)) {}
NativePagedBatchProgram &NativePagedBatchProgram::operator=(NativePagedBatchProgram &&other) noexcept {
  if (this != &other) { NativePagedBatchProgram moved(std::move(other)); std::swap(data_, moved.data_); }
  return *this;
}
NativePagedBatchProgram::~NativePagedBatchProgram() { if (data_) data_->decref(); }
Result<NativePagedBatchProgram> NativePagedBatchProgram::prepare(
    BatchSchema schema, NativePagedBatchOptions options) noexcept {
  if (!schema.valid() || !options.allocator.valid() || !options.max_host_metadata_bytes ||
      !std::isfinite(options.scale))
    return std::unexpected(Status::InvalidArgument("native page recipe needs schema/allocator/finite budget/scale"));
  HYLE_RETURN_IF_ERROR(validate_batch_attention_options(options.causal,options.window_left));
  const auto capacity = schema.capacity();
  if (capacity.storage != BatchStorage::kPaged || capacity.page_size != 16 ||
      (capacity.query_type != DataType::kFloat16 && capacity.query_type != DataType::kBFloat16))
    return std::unexpected(Status::Unimplemented("native page recipe requires F16/BF16 page16 schema"));
  const std::uint64_t refs = capacity.max_page_refs;
  if (refs > std::uint32_t(INT32_MAX) || refs > SIZE_MAX / sizeof(std::int32_t))
    return std::unexpected(Status::OutOfRange("native page table extent overflow"));
  const auto bytes = std::size_t(capacity.max_page_refs) * sizeof(std::int32_t);
  if (bytes > options.max_host_metadata_bytes)
    return std::unexpected(Status::ResourceExhausted("native page table host byte capacity"));
  auto allocator = options.allocator;
  if (options.resource_budget.valid()) {
    HYLE_ASSIGN_OR_RETURN(allocator, options.resource_budget.metadata_allocator());
  }
  auto *data = allocator.construct<detail::NativePagedBatchProgramData>(schema, std::move(options), allocator);
  if (!data) return std::unexpected(Status::ResourceExhausted("native page recipe metadata"));
  NativePagedBatchProgram result(data);
  HYLE_ASSIGN_OR_RETURN(data->descriptions[0],batch_query_description(capacity));
  const bool mla=schema.mla_layout()!=MlaCacheLayout::kNone;
  HYLE_ASSIGN_OR_RETURN(data->descriptions[1],batch_cache_description(schema,mla?BatchCacheRole::kMla:BatchCacheRole::kKey));
  if(!mla){HYLE_ASSIGN_OR_RETURN(data->descriptions[2],batch_cache_description(schema,BatchCacheRole::kValue));}
  HYLE_ASSIGN_OR_RETURN(data->descriptions[mla?2:3], TensorDesc::dense(DataType::kInt32,
      std::array<std::int64_t, 1>{capacity.max_page_refs}));
  data->costs.index_bytes = bytes;
  return result;
}
BatchSchema NativePagedBatchProgram::schema() const noexcept { return data_ ? data_->schema : BatchSchema{}; }
float NativePagedBatchProgram::scale() const noexcept { return data_ ? data_->options.scale : 1.0F; }
bool NativePagedBatchProgram::causal() const noexcept { return data_ ? data_->options.causal : true; }
std::int32_t NativePagedBatchProgram::window_left() const noexcept { return data_ ? data_->options.window_left : -1; }
std::span<const TensorDesc> NativePagedBatchProgram::descriptions() const noexcept {
  return data_ ? std::span<const TensorDesc>(data_->descriptions).first(data_->schema.mla_layout()==MlaCacheLayout::kNone?4:3) : std::span<const TensorDesc>{};
}
NativePagedBatchCosts NativePagedBatchProgram::costs() const noexcept { return data_ ? data_->costs : NativePagedBatchCosts{}; }
Result<NativePagedBatchVersion> NativePagedBatchProgram::version(BatchLayoutVersion layout) const noexcept {
  if (!data_) return std::unexpected(Status::FailedPrecondition("native page recipe is empty"));
  if (!data_->schema.owns(layout))
    return std::unexpected(Status::InvalidArgument("native page version schema differs"));
  HYLE_RETURN_IF_ERROR(validate_batch_attention_layout(layout,causal(),window_left()));
  auto*p=data_->allocator.construct<detail::NativePagedBatchVersionData>(*this,std::move(layout),data_->allocator,data_->options.resource_budget);
  if(!p)return std::unexpected(Status::ResourceExhausted("native page active version owner"));
  return NativePagedBatchVersion(p);
}
NativePagedBatchVersion::NativePagedBatchVersion(const NativePagedBatchVersion&v)noexcept:data_(v.data_){if(data_)data_->incref();}
NativePagedBatchVersion&NativePagedBatchVersion::operator=(const NativePagedBatchVersion&v)noexcept{if(this!=&v){NativePagedBatchVersion next(v);std::swap(data_,next.data_);}return *this;}
NativePagedBatchVersion::NativePagedBatchVersion(NativePagedBatchVersion&&v)noexcept:data_(std::exchange(v.data_,nullptr)){}
NativePagedBatchVersion&NativePagedBatchVersion::operator=(NativePagedBatchVersion&&v)noexcept{if(this!=&v){NativePagedBatchVersion next(std::move(v));std::swap(data_,next.data_);}return *this;}
NativePagedBatchVersion::~NativePagedBatchVersion(){if(data_)data_->decref();}
BatchLayoutVersion NativePagedBatchVersion::layout() const noexcept { return data_?data_->layout:BatchLayoutVersion{}; }
NativePagedBatchProgram NativePagedBatchVersion::program() const noexcept { return data_?data_->program:NativePagedBatchProgram{}; }
Result<ReadLease> NativePagedBatchVersion::indices() const noexcept {
  if(!data_)return std::unexpected(Status::FailedPrecondition("native page version is empty"));
  std::lock_guard guard(data_->export_lock);if(data_->indices.valid())return data_->indices;
  HYLE_ASSIGN_OR_RETURN(auto buffer, mem::Buffer::create(mem::system_resource(), data_->program.costs().index_bytes, 64));
  {
    HYLE_ASSIGN_OR_RETURN(auto mapping, buffer.view().map_host());
    HYLE_ASSIGN_OR_RETURN(auto writable, mapping.writable_bytes());
    auto *indices = reinterpret_cast<std::int32_t *>(writable.data());
    std::fill_n(indices, data_->program.schema().capacity().max_page_refs, 0);
    const auto pages = data_->layout.host().page_indices;
    std::copy(pages.begin(), pages.end(), indices);
    HYLE_RETURN_IF_ERROR(mapping.close());
  }
  HYLE_ASSIGN_OR_RETURN(auto ready, ReadLease::adopt(std::move(buffer),
      {.allocator = data_->allocator, .resource_budget = data_->budget}));
  // The export retains independent owners, never this cache-containing state.
  // Otherwise cached lease -> version -> cached lease would form a cycle.
  auto *owner = data_->allocator.construct<detail::NativePagedBatchVersionOwner>(data_->program,data_->layout,data_->allocator);
  if (!owner) return std::unexpected(Status::ResourceExhausted("native page version owner"));
  detail::LeaseAccess::retain_resource_owner(ready, owner, &release_version_owner);
  data_->indices=std::move(ready);return data_->indices;
}
} // namespace hyle::compute
