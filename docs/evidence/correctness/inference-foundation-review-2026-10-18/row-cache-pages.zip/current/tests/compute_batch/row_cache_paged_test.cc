#include <hyle/compute/backends/cpu.h>
#include <hyle/compute/batch_execution.h>
#include <hyle/compute/batch_materialize.h>
#include <hyle/compute/batch_paged_native.h>
#include <hyle/compute/detail/paged_arena_access.h>
#include <hyle/compute/detail/batch_provider.h>
#include "allocation_fault_fixture.h"
#include <gtest/gtest.h>
#include <array>
#include <cstring>
#include <type_traits>

namespace {
namespace c=hyle::compute;namespace m=hyle::mem;
static_assert(!std::is_convertible_v<c::RowCacheBatchSchema,c::BatchSchema>);
static_assert(!std::is_convertible_v<c::RowCacheLayoutVersion,c::BatchLayoutVersion>);
static_assert(!std::is_convertible_v<c::PagedRowCacheRead,c::PagedArenaRead>);
static_assert(sizeof(c::RowCacheBatchSchema)==sizeof(c::BatchSchema));
static_assert(sizeof(c::RowCacheLayoutVersion)==sizeof(c::BatchLayoutVersion));
static_assert(sizeof(c::PagedRowCacheRead)==sizeof(c::PagedArenaRead));
c::RowCacheBatchCapacity capacity(c::RowCacheEncoding encoding){
  return {.encoding=encoding,.max_requests=2,.max_query_rows=3,.max_kv_rows=8,
          .max_pages=3,.max_page_refs=4,.page_size=2};
}
c::RowCacheLayoutVersion layout(const c::RowCacheBatchSchema&s,std::span<const std::int32_t> pages,int tail=2){
  const std::array<std::int32_t,2> q{0,3},kv{0,std::int32_t(pages.size())};
  const std::array<std::int32_t,1> tails{tail};return s.version({q,kv,pages,tails}).value();
}
c::ReadLease fill(c::PagedArena&a,unsigned page,std::byte value,unsigned rows=2){
  auto writer=a.acquire(page).value();EXPECT_TRUE(writer.lease().view()->fill(value).ok());return writer.publish(rows).value();
}
TEST(RowCachePaged, TypedGeometryExactPageGuardsAndInitializedPrefixes){
  for(auto encoding:{c::RowCacheEncoding::float8_block64_tail64(),c::RowCacheEncoding::float4_block32()}){
    auto schema=c::RowCacheBatchSchema::create(capacity(encoding)).value();
    EXPECT_EQ(schema.capacity(),capacity(encoding));
    auto arena=c::PagedArena::create(schema,m::system_resource(),{.max_backing_bytes=4096}).value();
    EXPECT_EQ(arena.page_bytes(),2u*encoding.row_bytes());
    auto zero=fill(arena,0,std::byte{11}),two=fill(arena,2,std::byte{29},1);
    auto version=layout(schema,std::array<std::int32_t,2>{0,2},1);
    auto frame=arena.read(version,std::array{two,zero}).value();
    EXPECT_EQ(frame.layout(),version);EXPECT_EQ(frame.layout().schema().capacity(),schema.capacity());EXPECT_EQ(frame.page_count(),2u);
    const auto tensor=c::detail::PagedArenaAccess::tensor(frame).value();
    EXPECT_EQ(tensor.description(),c::row_cache_paged_description(schema.capacity()).value());
    EXPECT_EQ(tensor.storage().size(),6u*encoding.row_bytes());
    EXPECT_TRUE(c::detail::PagedArenaAccess::validate_storage(frame,encoding).ok());
    const auto other=encoding==c::RowCacheEncoding::float4_block32()?c::RowCacheEncoding::float8_block64_tail64():c::RowCacheEncoding::float4_block32();
    EXPECT_TRUE(c::detail::PagedArenaAccess::validate_storage(frame,other).IsInvalidArgument());
    EXPECT_TRUE(arena.read(layout(schema,std::array<std::int32_t,2>{0,2}),std::array{zero,two}).error().IsFailedPrecondition());
    EXPECT_TRUE(arena.read(version,std::array{zero}).error().IsInvalidArgument());
    auto free=fill(arena,1,std::byte{37});
    EXPECT_TRUE(arena.read(version,std::array{zero,two,free}).error().IsInvalidArgument());
    EXPECT_TRUE(arena.read(version,std::array{zero,two.subview(0,encoding.row_bytes()).value()}).error().IsInvalidArgument());
    auto foreign=c::RowCacheBatchSchema::create(schema.capacity()).value();
    EXPECT_TRUE(arena.read(layout(foreign,std::array<std::int32_t,2>{0,2},1),std::array{zero,two}).error().IsInvalidArgument());
    auto other_arena=c::PagedArena::create(schema,m::system_resource(),{.max_backing_bytes=4096}).value();
    auto foreign_page=fill(other_arena,0,std::byte{41});
    EXPECT_TRUE(arena.read(version,std::array{foreign_page,two}).error().IsInvalidArgument());
    auto repeated=arena.read(layout(schema,std::array<std::int32_t,2>{0,0}),std::array{zero,zero}).value();EXPECT_EQ(repeated.page_count(),1u);
    auto uses=c::LeaseUsePool::create().value();auto use=uses.begin().value();
    for(const auto&page:c::detail::PagedArenaAccess::pages(frame))ASSERT_TRUE(use.read(page).ok());
    frame={};repeated={};zero.reset();two.reset();EXPECT_FALSE(arena.acquire(0));EXPECT_FALSE(arena.acquire(2));
    use={};EXPECT_TRUE(arena.acquire(0));EXPECT_TRUE(arena.acquire(2));
  }
}
TEST(RowCachePaged, EmptyHistoryPreservesRowGroupsAndHasNoPagePermission){
  auto schema=c::RowCacheBatchSchema::create(capacity(c::RowCacheEncoding::float8_block64_tail64())).value();
  const std::array<std::int32_t,3> q{0,2,3},kv{0,0,0};const std::array<std::int32_t,2> tails{};
  auto version=schema.version({q,kv,{},tails}).value();
  EXPECT_EQ(version.facts().query_rows,3u);EXPECT_EQ(version.facts().kv_rows,0u);EXPECT_EQ(version.facts().page_refs,0u);
  auto arena=c::PagedArena::create(schema,m::system_resource(),{.max_backing_bytes=4096}).value();
  auto empty=arena.read(version,{}).value();EXPECT_TRUE(empty.valid());EXPECT_EQ(empty.page_count(),0u);EXPECT_TRUE(c::detail::PagedArenaAccess::pages(empty).empty());
  auto metadata=version.metadata().value();EXPECT_EQ(metadata.size(),schema.metadata_offsets().bytes);
  auto next=schema.version({q,kv,{},tails}).value();EXPECT_NE(version,next);EXPECT_GT(next.generation(),version.generation());
  auto page=fill(arena,0,std::byte{43});EXPECT_TRUE(arena.read(version,std::array{page}).error().IsInvalidArgument());
  EXPECT_TRUE(arena.acquire(page));
  // Escaped metadata remains its original independent readonly F1 owner.
  empty={};version={};next={};schema={};arena={};auto uses=c::LeaseUsePool::create().value();auto use=uses.begin().value();EXPECT_TRUE(use.read(metadata).ok());
}
TEST(RowCachePaged, OriginalF2WholePageWriterAndOldBranchRemainIndependent){
  auto schema=c::RowCacheBatchSchema::create(capacity(c::RowCacheEncoding::float4_block32())).value();
  auto arena=c::PagedArena::create(schema,m::system_resource(),{.max_backing_bytes=4096}).value();
  auto old=fill(arena,0,std::byte{17});auto old_version=layout(schema,std::array<std::int32_t,1>{0});auto old_frame=arena.read(old_version,std::array{old}).value();
  auto writer=arena.acquire(1).value();const auto generation=writer.lease().generation();
  auto context=c::Context::create(c::cpu::device()).value();auto queue=context.create_queue().value();
  auto program=c::CopyBatchProgram::prepare(context,std::array{c::CopyResourceSpec{m::system_resource(),arena.page_bytes()},c::CopyResourceSpec{m::system_resource(),arena.page_bytes()}}).value();
  auto copy=c::CopyBatchInvocation::create(program,queue).value();ASSERT_TRUE(copy.bind_source({0},old).ok());ASSERT_TRUE(copy.bind_mutable({1},std::move(writer.lease())).ok());
  const std::array<c::CopyPhase,1> phases{{{}}};const std::array<c::CopyRange,1> ranges{{{{0},{1},{0},0,0,arena.page_bytes()}}};ASSERT_TRUE(copy.prepare_replay(phases,ranges).ok());
  {auto submitted=copy.submit().value();ASSERT_TRUE(submitted.wait().ok());EXPECT_FALSE(copy.unbind_mutable({1}));}
  writer.lease()=copy.unbind_mutable({1}).value();EXPECT_EQ(writer.lease().generation(),generation);
  auto next=writer.publish(2).value();auto next_version=layout(schema,std::array<std::int32_t,1>{1});
  EXPECT_TRUE(arena.read(next_version,std::array{next}));EXPECT_EQ(old_frame.layout(),old_version);
  std::array<std::byte,136> before{},after{};ASSERT_TRUE(old.view()->read(before).ok());ASSERT_TRUE(next.view()->read(after).ok());EXPECT_EQ(before,after);
  EXPECT_FALSE(arena.acquire(old));ASSERT_TRUE(copy.reset().ok());
}
TEST(RowCachePaged, ColdAllocationFailureAndWrongAttentionDomainsRemainRejected){
  hyle_f5_fault_fixture::Allocator allocator;
  {auto schema=c::RowCacheBatchSchema::create(capacity(c::RowCacheEncoding::float8_block64_tail64()),{.allocator=allocator.ref()}).value();
    allocator.fail=allocator.attempts;EXPECT_TRUE(schema.version({}).error().IsInvalidArgument());
    const std::array<std::int32_t,2> q{0,3},kv{0,0};const std::array<std::int32_t,1> tail{0};
    EXPECT_TRUE(schema.version({q,kv,{},tail}).error().IsResourceExhausted());allocator.fail=SIZE_MAX;
    auto version=schema.version({q,kv,{},tail}).value();
    auto arena=c::PagedArena::create(schema,m::system_resource(),{.max_backing_bytes=4096,.allocator=allocator.ref()}).value();
    allocator.fail=allocator.attempts;EXPECT_TRUE(arena.read(version,{}).error().IsResourceExhausted());allocator.fail=SIZE_MAX;EXPECT_TRUE(arena.read(version,{}));
    // Trusted adapters cannot accidentally send the hidden common owner to an
    // old attention entry point. Public row handles have no such conversion.
    const auto &hidden=c::detail::BatchLayoutAccess::owner(schema);const auto &hidden_version=c::detail::BatchLayoutAccess::owner(version);
    EXPECT_FALSE(c::validate_batch_capacity(hidden.capacity()).ok());
    EXPECT_TRUE(c::validate_batch_attention_layout(hidden_version,false).IsInvalidArgument());
    EXPECT_TRUE(c::batch_cache_description(hidden,c::BatchCacheRole::kKey).error().IsInvalidArgument());
    EXPECT_TRUE(c::NativePagedBatchProgram::prepare(hidden,{}).error().IsInvalidArgument());
    EXPECT_TRUE(c::MaterializedBatchProgram::prepare(hidden,{}).error().IsInvalidArgument());
    auto context=c::Context::create(c::cpu::device()).value();EXPECT_TRUE(c::BatchProgram::prepare(context,hidden,{}).error().IsInvalidArgument());
    EXPECT_TRUE(c::PagedArena::create(hidden,c::BatchCacheRole::kKey,m::system_resource(),{.max_backing_bytes=4096}).error().IsInvalidArgument());
    EXPECT_TRUE(arena.read(hidden_version,{}).error().IsInvalidArgument());
    EXPECT_TRUE(arena.pending_read(hidden_version,{},{}).error().IsInvalidArgument());
  }EXPECT_EQ(allocator.live,0u);
  auto cap=capacity(c::RowCacheEncoding::float4_block32());cap.page_size=0;EXPECT_FALSE(c::RowCacheBatchSchema::create(cap));
  cap=capacity(c::RowCacheEncoding::float4_block32());cap.max_pages=UINT32_MAX;EXPECT_TRUE(c::RowCacheBatchSchema::create(cap).error().IsOutOfRange());
  auto schema=c::RowCacheBatchSchema::create(capacity(c::RowCacheEncoding::float4_block32())).value();
  EXPECT_TRUE(c::PagedArena::create(schema,m::system_resource(),{.max_backing_bytes=408}).error().IsResourceExhausted());
}
} // namespace
