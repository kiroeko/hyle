from pathlib import Path
import json,hashlib,difflib,zipfile,subprocess
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages'
paths=json.loads((O/'paths.json').read_text());paths.append('tests/compute_batch/row_cache_paged_test.cc')
diff='';changed=[]
for p in paths:
 old=O/'before'/p;before=old.read_text(encoding='utf-8').splitlines(True)if old.exists()else[]
 after=(R/p).read_text(encoding='utf-8').splitlines(True)
 if before!=after:
  changed.append(p);diff+=''.join(difflib.unified_diff(before,after,fromfile='before/'+p,tofile='current/'+p))
(O/'task.diff').write_text(diff,encoding='utf-8')
checks=['tests/compute_batch/batch_layout_test.cc','tests/compute_batch/paged_arena_test.cc','tests/compute_batch/native_paged_metadata_test.cc','tests/compute_batch/batch_materialize_test.cc','tests/compute_batch/allocation_fault_fixture.h','src/compute_batch/materialized_invocation.cc']
commands=json.loads((O/'commands.json').read_text());objects=sorted(O.glob('*.obj'))
libs=[Path(x)for a in reversed(commands)if a['tag']=='tests-link'for x in a['command']if x.endswith('.lib')]
compiler=Path(commands[0]['command'][0])
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
identities=[identity(p)for p in dict.fromkeys([*[R/p for p in changed+checks],compiler,*objects,*libs,R/'.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj',R/'.scratch/inference-lifecycle-2026-10-18/state-metadata/leases.obj',R/'.scratch/inference-lifecycle-2026-10-18/state-metadata/state.obj'])if p.exists()]
(O/'identities.json').write_text(json.dumps(identities,indent=2)+'\n')
(O/'cleanup-candidates.json').write_text(json.dumps({'delete_only_after_root_test_ps1_review':[identity(p)for p in O.iterdir()if p.suffix in ['.exe','.lib','.exp']],'keep_reusable_objects':[str(p)for p in objects]},indent=2)+'\n')
summary={
 'status':'PASS: foundation only; no paged decoder implementation',
 'api':['RowCacheBatchCapacity: encoding + max_requests/max_query_rows/max_kv_rows/max_pages/max_page_refs/page_size','RowCacheBatchSchema::create/capacity/version/owns/metadata_offsets/metadata_description','RowCacheLayoutVersion::schema/generation/facts/host/metadata/equality','PagedArena::create(RowCacheBatchSchema,resource,options)','PagedArena::read(RowCacheLayoutVersion,span<ReadLease>)->PagedRowCacheRead','BatchCacheRole::kRow; truthful U8[P,page_size,row_bytes]'],
 'ownership':'Typed one-handle wrappers privately own original BatchSchema/BatchLayoutVersion/PagedArenaRead. No public attention conversion or whole-arena ReadLease. Shared immutable owner/geometry/metadata exports, original F1 page blocks and F2 remain in use. Row capacity adds cold schema data within original allocator/budget, no extra wrapper allocation.',
 'validation':'71/71 from five canonical test TUs: batch_layout, paged_arena, native_paged_metadata, batch_materialize, row_cache_paged. Four new row tests exercise both encoding widths, exact ready guards, initialized tail, foreign/missing/excess/subview pages, repeated refs, F1 actual use retirement, real F2 single-page clone/old branch, empty KV/nonzero selection grouping and empty frame, escaped metadata admission, OOM retry, overflow/backing budget and old attention entry rejection.',
 'host_closure':'MSVC14.50.35717 /O2 /MD /W4 /WX: fresh batch_layout.cc,paged_arena.cc,batch_execution.cc,batch_materialize.cc,batch_paged_native.cc,materialized_invocation.cc,graph_batch/batch.cc; five test TUs; four independent header self-contained compiles. Final arena typed-domain guard refreshed separately and all71 rerun.',
 'graph_boundary':'graph_batch/batch.cc contains only wrong-domain rejection and was compile-checked, not linked/run here; Graph core was not edited. No new native SDK, CUDA kernel, cross-page decoder, pending row reader, Sink or full-model execution claim. Original workspace_test TU/full CMake target not rerun.',
 'permission_boundary':'Empty row layout/frame grants no permission for nonempty IDs. Future reader must validate logical per-request IDs and retain exact frame guards through actual completion; query causal masks remain engine policy. Existing attention/native/materialized/paged factories reject hidden row owner.',
 'initial_compile_correction':'A private page_footprint overload made an existing {} negative test ambiguous. Renamed row-specific detail helpers row_segments/row_page_footprint; all old sources remained unchanged. Initial exit2 retained in command ledger; final compile logs replace same tag logs.',
 'changed_files':changed,
 'reusable_objects':[str(p)for p in objects],
 'cleanup':'Nothing deleted. cleanup-candidates.json only lists this stage artifacts for root test.ps1; keep all objects.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
check=subprocess.run(['git','diff','--check','--',*changed],capture_output=True,cwd=R)
(O/'diff-check.stdout.log').write_bytes(check.stdout);(O/'diff-check.stderr.log').write_bytes(check.stderr)
assert check.returncode==0
with zipfile.ZipFile(O/'source-results.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in changed+checks:z.write(R/p,'current/'+p)
 for p in (O/'before').rglob('*'):
  if p.is_file():z.write(p,p.relative_to(O))
 for p in O.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.log','.diff','.cc']:
   z.write(p,p.name)
p=O/'source-results.zip';print(json.dumps({'archive':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'changed_files':changed,'objects':len(objects)},indent=2))
