from pathlib import Path
import json,sys,subprocess,time,os
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages';sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
old=json.loads((R/'.scratch/inference-lifecycle-2026-10-18/paged-footprint/commands.json').read_text())
host=next(x['command']for x in old if x['tag']=='layout-after-compile')
flags=[x for x in host if not x.endswith('.cc') and not x.lower().startswith('/fo')]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]});env['VSLANG']='1033'
records=json.loads((O/"commands.json").read_text())if(O/"commands.json").exists()else[]
def run(tag,cmd):
 start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(tag+'.stdout.log')).write_bytes(p.stdout);(O/(tag+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-1500:],flush=True);p.check_returncode()
def compile(source,name):
 obj=O/(name+'.obj');run(name+'-compile',[*flags,R/source,'/Fo'+str(obj)]);return obj
if __name__=='__main__':
 compile('src/compute_batch/paged_arena.cc','paged_arena')
 tests=[O/(name+'-tests.obj')for name in ['batch_layout_test','paged_arena_test','native_paged_metadata_test','batch_materialize_test','row_cache_paged_test']]
 oldlink=next(x['command']for x in old if x['tag']=='tests-link')
 libraries=[x for x in oldlink if x.endswith('.lib')]
 objs=[O/(name+'.obj')for name in ['batch_layout','paged_arena','batch_execution','batch_materialize','batch_paged_native','materialized_invocation']]
 current=R/'.scratch/inference-lifecycle-2026-10-18/state-metadata'
 low=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj'
 link=oldlink[0];exe=O/'tests.exe'
 run('tests-link',[link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),*tests,*objs,current/'leases.obj',current/'state.obj',low,*libraries])
 run('tests',[exe])
