#include "hyle/compute/detail/batch_provider.h"
