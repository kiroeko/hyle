"""Independent fixed-token full-model diagnosis. No Hyle values enter Torch."""
from pathlib import Path
import hashlib,importlib.util,json,os,time,types
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false')
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
ORIGINAL=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/reference'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);d=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
receipt=read(ORIGINAL/'reference.json');fixed=read(OUT/'fixed-inputs.json')
import torch
from safetensors import safe_open
from transformers.models.qwen3_5 import modeling_qwen3_5 as impl
from transformers.models.qwen3_5.configuration_qwen3_5 import Qwen3_5TextConfig
assert torch.__version__==receipt['torch'] and torch.cuda.get_device_name()==receipt['gpu']
assert identity(impl.__file__)['sha256']==receipt['model_source_sha256']
source=ROOT/'tools/qwen35_text/reference.py';assert identity(source)['sha256']==receipt['reference_sha256']
spec=importlib.util.spec_from_file_location('original_reference',source);original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
torch.set_num_threads(2);torch.set_num_interop_threads(1)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=False
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction=False
manifest=(OUT/'science-inputs/weights.tsv').read_text().splitlines();shard=Path(manifest[1]);assert manifest[2]==receipt['source_id']
config=Qwen3_5TextConfig(**read(shard.parent/'config.json')['text_config']);config._attn_implementation='eager'
start=time.perf_counter()
with torch.device('meta'):model=impl.Qwen3_5ForCausalLM(config)
model.model.rotary_emb=impl.Qwen3_5TextRotaryEmbedding(config,device='cpu')
parameters={}
with safe_open(shard,framework='pt',device='cpu')as checkpoint:
 for name in checkpoint.keys():
  if name.startswith('model.language_model.'):parameters[name.replace('model.language_model.','model.',1)]=checkpoint.get_tensor(name)
assert len(parameters)==320
parameters['lm_head.weight']=parameters['model.embed_tokens.weight'];model.load_state_dict(parameters,strict=True,assign=True);model.lm_head.weight=model.model.embed_tokens.weight
del parameters
model.eval().to('cuda')
for layer in model.model.layers:
 if hasattr(layer,'linear_attn'):layer.linear_attn.forward=types.MethodType(original.fixed_recurrent_forward,layer.linear_attn)
hidden=[];model.model.norm.register_forward_hook(lambda module,args,output:hidden.append(output[:,-1:].detach()))
def raw(t):return t.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()
def forward(ids,cache):
 with torch.inference_mode():return model(input_ids=torch.tensor([ids],device='cuda',dtype=torch.long),past_key_values=cache,use_cache=True,logits_to_keep=1)
guards=[];cache=None
for phase in receipt['steps']:
 result=forward(phase['input_ids'],cache);cache=result.past_key_values
 payload={'logits.f32':result.logits[0,-1].float(),'hidden.bf16':hidden.pop()}
 for layer in range(24):
  if layer%4==3:
   payload[f'layer{layer}.key.bf16']=cache.key_cache[layer][0].transpose(0,1);payload[f'layer{layer}.value.bf16']=cache.value_cache[layer][0].transpose(0,1)
  else:
   payload[f'layer{layer}.conv.bf16']=cache.conv_states[layer][:,:,-3:].transpose(1,2);payload[f'layer{layer}.gdn.f32']=cache.recurrent_states[layer].transpose(-1,-2)
 for name,tensor in payload.items():
  data=raw(tensor);old=ORIGINAL/phase['name']/name;assert data==old.read_bytes(),(phase['name'],name)
  guards.append(dict(phase=phase['name'],file=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),bit_equal=True))
assert len(guards)==150
save(OUT/'reference-original-guard.json',dict(passed=True,files=guards))
del payload,cache,result
torch.cuda.synchronize()
save(OUT/'reference-environment.json',dict(torch=torch.__version__,cuda=torch.version.cuda,gpu=torch.cuda.get_device_name(),model_source=identity(impl.__file__),reference=identity(source),script=identity(__file__),fixed_inputs=identity(OUT/'fixed-inputs.json'),text_weight_bytes=sum(t.numel()*t.element_size()for t in model.parameters()),load_and_baseline_seconds=time.perf_counter()-start,no_candidate_values_used=True,no_weights_copied=True))
steps=[('prefill',fixed['prompt_ids'])]+[(f'decode{i+1}',[token])for i,token in enumerate(fixed['decode_input_ids'])]
def journey(mode):
 directory=OUT/mode;directory.mkdir(exist_ok=False);cache=None;rows=[]
 for index,(name,ids)in enumerate(steps):
  result=forward(ids,cache);cache=result.past_key_values;logits=result.logits[0,-1].float();last=hidden.pop()
  phase=directory/name;phase.mkdir()
  for file,tensor in [('logits.f32',logits),('hidden.bf16',last)]: (phase/file).write_bytes(raw(tensor))
  logprobs=torch.log_softmax(logits.double(),dim=-1);target=fixed['target_ids'][index]
  rows.append(dict(name=name,input_ids=ids,next_id=int(logits.argmax()),target_id=target,target_nll=float(-logprobs[target]),logits=identity(phase/'logits.f32'),hidden=identity(phase/'hidden.bf16')))
 assert len(rows)==32
 save(directory/'steps.json',rows);return rows
baseline=journey('eager-reference')
old_rotary=impl.Qwen3_5TextRotaryEmbedding.forward;old_apply=impl.apply_rotary_pos_emb
rotations=[]
def angles(self,x,position_ids):return old_rotary(self,x.float(),position_ids)
def rotate(q,k,cos,sin,unsqueeze_dim=1):
 assert q.dtype==k.dtype==torch.bfloat16 and cos.dtype==sin.dtype==torch.float32 and cos.shape[-1]==64
 cos=cos.unsqueeze(unsqueeze_dim);sin=sin.unsqueeze(unsqueeze_dim)
 def one(t):
  prefix=t[...,:64].float();r=(prefix*cos+impl.rotate_half(prefix)*sin).to(t.dtype)
  return torch.cat((r,t[...,64:]),dim=-1)
 rotations.append(dict(q_shape=list(q.shape),k_shape=list(k.shape)))
 return one(q),one(k)
impl.Qwen3_5TextRotaryEmbedding.forward=angles;impl.apply_rotary_pos_emb=rotate
try:variant=journey('f32-rope-reference')
finally:impl.Qwen3_5TextRotaryEmbedding.forward=old_rotary;impl.apply_rotary_pos_emb=old_apply
assert len(rotations)==192
save(OUT/'reference-summary.json',dict(status='completed_fixed_token_diagnosis',baseline_phases=len(baseline),variant_phases=len(variant),baseline_150_original_payloads_equal=True,rotations=len(rotations),all_inputs_fixed=True,caches_independent=True,candidate_values_used=False,weights_copied=False,product_math_changed=False,quality_evaluation=False,performance_measurement=False))
print('independent fixed-token science reference complete: baseline32 + RoPE-only32',flush=True)
