from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
BASE=read(ARCH/'cuda-admitted-ggml-stream-implementation/qwen-link.json')
NEW=ARCH/'native-ragged-graph/validation/windows'
source='tools/qwen35_text/main.cc'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':BASE['command'][0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent)for x in BASE['command']if x.endswith('.lib')))+os.pathsep+env['PATH']
def call(tag,argv,sources=(),outputs=(),allowed=(0,)):
 assert not(OUT/(tag+'.result.json')).exists(),tag
 row=dict(argv=list(map(str,argv)),started=time.time(),sources_before=[ident(ROOT/s)for s in sources])
 save(OUT/(tag+'.command.json'),row)
 with(OUT/(tag+'.stdout.log')).open('wb')as so,(OUT/(tag+'.stderr.log')).open('wb')as se:
  p=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=p.pid;save(OUT/'live.json',row)
  try:row['exit']=p.wait(timeout=55)
  except subprocess.TimeoutExpired:p.kill();p.wait();row['exit']='timeout55'
 row.update(terminal=True,finished=time.time(),sources_after=[ident(ROOT/s)for s in sources],outputs=[ident(x)for x in outputs if Path(x).is_file()])
 save(OUT/(tag+'.result.json'),row);save(OUT/'live.json',row)
 print(tag,row['exit'],round(row['finished']-row['started'],3),flush=True)
 assert row['sources_before']==row['sources_after']
 if row['exit']not in allowed:
  for suffix in ['stdout','stderr']:print((OUT/(tag+'.'+suffix+'.log')).read_text(errors='replace')[-9000:])
  raise SystemExit(1)
def prepare():
 argv=BASE['command'].copy();changes=[]
 replacements={
 'input-source-scratch/input-sources.obj':'src/graph/input_sources.cc',
 'legacy-native-retirement/contracts/windows/resources-fce1fdc7ad0f.obj':'src/graph/resources.cc',
 'retire-native-runtime/paging-risks/batch.obj':'src/graph_batch/batch.cc',
 'graph-lifecycle-review/alias-liveness/graph-executable.obj':'src/graph/executable.cc',
 'native-ready-pages/windows/graph--region_access.obj':'src/graph/region_access.cc',
 'native-page-semantics/windows/src--compute_batch--batch_execution.obj':'src/compute_batch/batch_execution.cc',
 'native-pending-pages/windows/src--graph_batch--native_paged_regions.obj':'src/graph_batch/native_batch_regions.cc',
 'optional-file-stream/cuda/batch-transfer-final.obj':'src/compute/batch_transfer.cc'}
 for suffix,s in replacements.items():
  hits=[i for i,v in enumerate(argv)if v.replace(chr(92),'/').endswith(suffix)];assert len(hits)==1,(suffix,hits)
  obj=NEW/(s.replace('/','--').removesuffix('.cc')+'.obj');assert obj.is_file();i=hits[0];changes.append(dict(source=s,old=argv[i],new=str(obj)));argv[i]=str(obj)
 old=[i for i,v in enumerate(argv)if v.replace(chr(92),'/').endswith('strided-reshape/consumer.obj')];assert len(old)==1
 argv[old[0]]=str(OUT/'consumer.obj')
 prior=read(ARCH/'paged-row-scorer/validation/windows-current/matched-link-plan.json')['selected_sources']
 for s in ['src/graph_batch/row_cache_node.cc']:
  hits=[i for i,v in enumerate(argv)if v.replace(chr(92),'/').endswith('native-ready-pages/windows/graph_batch--row_cache_node.obj')];assert len(hits)==1
  i=hits[0];changes.append(dict(source=s,old=argv[i],new=prior[s]));argv[i]=prior[s]
 for s,obj in [('src/mem/resource.cc',str(NEW/'src--mem--resource.obj')),('src/graph_batch/native_pending_regions.cc',prior['src/graph_batch/native_pending_regions.cc'])]:
  assert obj not in argv;argv.append(obj);changes.append(dict(source=s,old=None,new=obj))
 argv=[v for v in argv if not v.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 save(OUT/'current-base-link.json',dict(command=argv,replacements=changes,origin=str(ARCH/'cuda-admitted-ggml-stream-implementation/qwen-link.json'),changed_objects=[ident(c['new'])for c in changes]))
 inputs=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
 science=OUT/'science-inputs';science.mkdir(exist_ok=False)
 receipt=read(ROOT/'.scratch/qwen35-cli-preflight/reference-generation-32.json')
 (science/'weights.tsv').write_bytes((inputs/'weights.tsv').read_bytes())
 (science/'prompt.ids').write_text(' '.join(map(str,receipt['prompt_ids']))+'\n',encoding='ascii')
 tape=receipt['generated_ids'][:31];(OUT/'science-decode.ids').write_text(' '.join(map(str,tape))+'\n',encoding='ascii')
 save(OUT/'fixed-inputs.json',dict(prompt=receipt['prompt'],prompt_ids=receipt['prompt_ids'],decode_input_ids=tape,target_ids=receipt['generated_ids'],selection_before_candidate_execution=True,selection_source=ident(ROOT/'.scratch/qwen35-cli-preflight/reference-generation-32.json'),manifest=ident(science/'weights.tsv'),no_weights_copied=True,not_a_model_quality_evaluation_set=True))
 print('resolved current base and fixed inputs; no build/run',flush=True)
def compile():
 recipes=read(ARCH/'generic-progress/qwen/compile-recipes.json');cmd=next(x['command']for x in recipes if x['source']==source)
 argv=[x for x in cmd if not x.lower().startswith('/fo') and not x.lower().endswith('.cc')]
 argv +=[str(ROOT/source),'/Fo'+str(OUT/'consumer.obj'),'/sourceDependencies',str(OUT/'consumer.deps.json')]
 call('compile-consumer',argv,[source],[OUT/'consumer.obj',OUT/'consumer.deps.json'])
def refresh():
 records=[('cuda-copy',read(ARCH/'cuda-admitted-ggml-stream-implementation/cuda_batch_transfer-identity.json')),
          ('flashinfer',read(ARCH/'qwen38-gqa16-current/current-identity.json'))]
 plan=read(OUT/'current-base-link.json')
 for name,record in records:
  src='src/compute_backend_cuda/cuda_batch_transfer.cc' if name=='cuda-copy' else 'src/compute_provider_flashinfer/flashinfer_provider.cc'
  command=[v for v in record['command']if not v.lower().startswith('/fo')]
  obj=OUT/(name+'.obj');command+=['/Fo'+str(obj),'/sourceDependencies',str(obj.with_suffix('.deps.json'))]
  call('compile-final-'+name,command,[src],[obj,obj.with_suffix('.deps.json')])
  suffix='cuda-admitted-ggml-stream-implementation/cuda_batch_transfer.obj' if name=='cuda-copy' else 'native-runtime-retirement/metadata-oom-review/compute_provider_flashinfer--flashinfer_provider.obj'
  hits=[i for i,v in enumerate(plan['command'])if v.replace(chr(92),'/').endswith(suffix)];assert len(hits)==1
  i=hits[0];plan['replacements'].append(dict(source=src,old=plan['command'][i],new=str(obj)));plan['command'][i]=str(obj)
 save(OUT/'current-base-link.json',plan)
def link(tag='link-current'):
 plan=read(OUT/'current-base-link.json');argv=plan['command'].copy();stem=OUT/'qwen-current'
 argv+=['/OUT:'+str(stem.with_suffix('.exe')),'/MAP:'+str(stem.with_suffix('.map')),'/IMPLIB:'+str(stem.with_suffix('.lib'))]
 save(OUT/'matched-link-plan.json',dict(command=argv,inputs=[ident(x)for x in argv if Path(x).suffix.lower()in{'.obj','.lib'} and Path(x).is_file()]))
 call(tag,argv,outputs=[stem.with_suffix(x)for x in ['.exe','.map','.lib','.exp']])
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='compile':compile()
 elif action=='link':link()
 elif action=='refresh':refresh()
 elif action=='final-link':link('link-final-current')
 elif action=='smoke':
  inputs=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
  call('run-original-journey',[OUT/'qwen-current.exe','--inputs',inputs,'--continuation',inputs/'continuation.ids','--steps','2','--capacity','32','--trace',OUT/'original-decisions','--trace-level','decisions'])
 elif action=='science':
  call('run-fixed-science',[OUT/'qwen-current.exe','--inputs',OUT/'science-inputs','--decode-ids',OUT/'science-decode.ids','--capacity','64','--trace',OUT/'science-decisions','--trace-level','decisions'])
 elif action=='oracle':call('run-independent-reference',['C:/Program Files/Python312/python.exe',OUT/'reference.py'],sources=[str((OUT/'reference.py').relative_to(ROOT))])
 elif action=='scheduler':
  call('run-science-scheduler',[OUT/'qwen-current.exe','--inputs',OUT/'science-inputs','--decode-ids',OUT/'science-decode.ids','--capacity','64','--progress','scheduler','--trace',OUT/'science-scheduler-decisions','--trace-level','decisions'])
 elif action=='final-science':
  call('run-final-science',[OUT/'qwen-current.exe','--inputs',OUT/'science-inputs','--decode-ids',OUT/'science-decode.ids','--capacity','64','--trace',OUT/'science-final-decisions','--trace-level','decisions'])
 else:raise ValueError(action)
