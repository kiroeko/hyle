"""Freeze recorded commands, source identities and existing raw-data checks only."""
from pathlib import Path
import array, difflib, hashlib, json, sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TOOLS = ('tools/qwen35_text/main.cc', 'tools/qwen35_text/README.md')

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def save(name, value):
    target = OUT/name
    if target.exists(): raise FileExistsError(f'Do not replace frozen evidence: {target}')
    target.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')

records = []
for path in sorted(OUT.glob('*.result.json')):
    row = read(path)
    assert row['terminal'] and row['exit'] == 0, path
    assert row['sources_before'] == row['sources_after'], path
    records.append(dict(receipt=identity(path), exit=row['exit'], terminal=row['terminal'],
        sources=row['sources_after'], outputs=row['outputs']))
assert len(records) == 10
assert all((ROOT/name).is_file() and (OUT/'before'/name).is_file() for name in TOOLS)
main = identity(ROOT/TOOLS[0])
consumer = read(OUT/'compile-consumer.result.json')
assert consumer['sources_after'] == [main]
source_manifest = dict(
    authoritative_tools=[identity(ROOT/name) for name in TOOLS],
    exact_before=[identity(OUT/'before'/name) for name in TOOLS],
    stage_scripts=[identity(path) for path in sorted(OUT.glob('*.py'))],
    input_files=[identity(OUT/name) for name in ['fixed-inputs.json', 'science-decode.ids',
        'science-inputs/prompt.ids', 'science-inputs/weights.tsv']],
    recorded_compile_sources=[row for item in records for row in item['sources']],
    native_dependencies='Actual selected inputs are identified in matched-link-plan.json; external object/library/model paths are not copied or traversed by this evidence freeze.',
    no_build_inference_or_cleanup=True)
save('source-manifest.json', source_manifest)
delta = ''
for name in TOOLS:
    lines = lambda path: [line+'\n' for line in path.read_text(encoding='utf-8-sig').splitlines()]
    delta += ''.join(difflib.unified_diff(lines(OUT/'before'/name), lines(ROOT/name),
        fromfile='before/'+name, tofile='candidate/'+name))
(OUT/'source.diff').write_text(delta, encoding='utf-8', newline='\n')

fixed = read(OUT/'fixed-inputs.json')
old = read(OUT/'original-parity.json')
parity = read(OUT/'science-progress-parity.json')
refresh = read(OUT/'final-provider-refresh-parity.json')
guard = read(OUT/'reference-original-guard.json')
reference = read(OUT/'reference-summary.json')
comparison = read(OUT/'numerical-comparison.json')['summary']
assert old['passed'] and len(old['files']) == 6
assert parity['passed'] and parity['vectors'] == 64
assert refresh['passed'] and refresh['vectors'] == 64
assert guard['passed'] and len(guard['files']) == 150
for directory, rows in [('original-decisions', old['files']),
    ('science-decisions', parity['files']), ('science-scheduler-decisions', parity['files']),
    ('science-final-decisions', refresh['files'])]:
    for row in rows:
        observed = identity(OUT/directory/row['phase']/row['file'])
        assert observed['bytes'] == row['bytes'] and observed['sha256'] == row['sha256']

values = array.array('f', (OUT/'eager-reference/decode24/logits.f32').read_bytes())
if sys.byteorder != 'little': values.byteswap()
highest = max(values)
ties = [index for index, value in enumerate(values) if value == highest]
assert highest == 20.25 and ties == [2302, 11615]
payloads = [path for path in OUT.rglob('*') if path.name in {'logits.f32', 'hidden.bf16'}]
assert len(payloads) == 326
save('results.json', dict(
    kind='Actual recorded commands and existing-payload consistency, not a new execution',
    commands=records, original_decision_vectors_equal=6, direct_scheduler_vectors_equal=64,
    latest_wrapper_refresh_vectors_equal=64, original_independent_reference_payloads_equal=150,
    decision_payload_files=326, decision_payload_bytes=sum(path.stat().st_size for path in payloads),
    raw_eager_maximum_tie=dict(phase='decode24', visible_tokens=45, value=highest, token_ids=ties),
    numerical_comparison=identity(OUT/'numerical-comparison.json'),
    builds_or_inference_executed_by_this_script=False))
save('summary.json', dict(
    status='Fixed-input full-model and state-feedback diagnosis completed; quality/performance acceptance remains open',
    consumer='Full24-layer CUDA Qwen3.5-2B text-only, no MTP/vision; fixed IDs and decisions-only trace through original Invocation',
    tools=source_manifest['authoritative_tools'],
    fixed_input=dict(prompt=fixed['prompt'], prompt_tokens=len(fixed['prompt_ids']),
        decode_inputs=len(fixed['decode_input_ids']), phases=32, final_visible_tokens=52,
        selected_before_candidate=fixed['selection_before_candidate_execution'],
        selection_source=fixed['selection_source']),
    parity=dict(original_decision_vectors=6, direct_scheduler_decision_vectors=64,
        latest_wrapper_refresh_decision_vectors=64, independent_reference_original_payloads=150),
    reference=dict(eager_phases=reference['baseline_phases'], f32_rope_only_phases=reference['variant_phases'],
        caches_independent=reference['caches_independent'], no_candidate_values_used=not reference['candidate_values_used']),
    numerical=comparison,
    eager_top1_boundary=dict(phase='decode24', eager_top_tokens=ties, eager_tied_logit=highest,
        hyle_top1=11615, f32_rope_reference_top1=11615),
    final_source_wrapper_scope=refresh['scope'],
    limitations=['One science prompt; targets were chosen by a pre-existing reference, not an independent quality corpus',
        'Direct/Scheduler and final-wrapper parity cover logits and last hidden; decisions mode does not export full state arrays',
        'Each independent reference starts its own cache; reference-only F32 RoPE is an ablation, not a product change',
        '31/32 eager top1 and 32/32 F32-RoPE top1, KL/relative errors and mean eager-target NLL delta -0.004980991 are diagnostic observations, not model-quality acceptance',
        'Diagnostic timings are not a fair sustained tokens/s or llama.cpp comparison',
        'Existing native math, weights and SDK reused; no new complete-model quality or other-platform claim'],
    cleanup_performed=False, new_build_or_inference_performed_by_freezer=False))
images = [identity(path) for path in sorted(OUT.iterdir())
    if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.lib', '.exp'}]
assert len(images) == 4
save('linked-image-cleanup.json', dict(targets=images, bytes=sum(row['bytes'] for row in images),
    cleanup_performed=False, executor='Root test.ps1 after archive verification',
    retained_objects=[identity(path) for path in sorted(OUT.glob('*.obj'))],
    retain_all_raw_data=True))
print(json.dumps(dict(recorded_commands=len(records), decision_files=len(payloads),
    linked_images=len(images), cleanup_candidate_bytes=sum(row['bytes'] for row in images)), indent=2))
