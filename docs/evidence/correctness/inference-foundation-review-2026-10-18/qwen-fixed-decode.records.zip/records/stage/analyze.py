from pathlib import Path
import hashlib,json
import numpy as np
OUT=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def logs(x):
 z=x-x.max();return z-np.log(np.exp(z).sum())
def metric(a,b,target):
 a=a.astype(np.float64);b=b.astype(np.float64);assert a.shape==b.shape and np.isfinite(a).all()and np.isfinite(b).all()
 la,lb=logs(a),logs(b);ia=np.argsort(-a,kind='stable')[:10];ib=np.argsort(-b,kind='stable')[:10]
 return dict(relative_l2=float(np.linalg.norm(a-b)/np.linalg.norm(b)),max_abs=float(np.abs(a-b).max()),cosine=float(a@b/np.linalg.norm(a)/np.linalg.norm(b)),kl_expected_to_actual=float(np.sum(np.exp(lb)*(lb-la))),top1_actual=int(ia[0]),top1_expected=int(ib[0]),top5_overlap=len(set(ia[:5])&set(ib[:5])),top10_overlap=len(set(ia)&set(ib)),target_id=target,target_nll_actual=float(-la[target]),target_nll_expected=float(-lb[target]),target_nll_delta=float(lb[target]-la[target]))
fixed=read(OUT/'fixed-inputs.json');phases=['prefill']+[f'decode{i}'for i in range(1,32)]
actual=read(OUT/'run-fixed-science.stdout.log');scheduled=read(OUT/'run-science-scheduler.stdout.log')
assert actual==scheduled and actual['fixed_decode']and actual['decode_input_ids']==fixed['decode_input_ids']and actual['visible_tokens']==52
rows=[];parity=[]
for i,phase in enumerate(phases):
 payload=[]
 for name in ['logits.f32','hidden.bf16']:
  a=(OUT/'science-decisions'/phase/name).read_bytes();b=(OUT/'science-scheduler-decisions'/phase/name).read_bytes();assert a==b,(phase,name)
  parity.append(dict(phase=phase,file=name,bytes=len(a),sha256=hashlib.sha256(a).hexdigest(),byte_equal=True))
 logits=lambda mode:np.fromfile(OUT/mode/phase/'logits.f32',dtype='<f4')
 c,e,r=map(logits,['science-decisions','eager-reference','f32-rope-reference']);target=fixed['target_ids'][i]
 rows.append(dict(phase=phase,visible_tokens=len(fixed['prompt_ids'])+i,hyle_vs_eager=metric(c,e,target),hyle_vs_f32_rope=metric(c,r,target),f32_rope_vs_eager=metric(r,e,target)))
def summarize(key):
 result=dict(phases=len(rows),top1_agreements=sum(x[key]['top1_actual']==x[key]['top1_expected']for x in rows))
 for k in ['relative_l2','max_abs','kl_expected_to_actual','target_nll_delta','target_nll_actual','target_nll_expected','top5_overlap','top10_overlap']:
  a=np.array([x[key][k]for x in rows]);result[k]=dict(mean=float(a.mean()),min=float(a.min()),p95=float(np.percentile(a,95)),max=float(a.max()))
 return result
save(OUT/'science-progress-parity.json',dict(passed=True,vectors=64,files=parity,scope='decision logits/hidden only; full state arrays not exported in this mode'))
summary=dict(status='actual_full_model_fixed_token_diagnosis_completed_not_acceptance',hyle_phases=32,visible_tokens=52,direct_scheduler_decision_vectors_equal=64,old_decision_vectors_equal=6,original_reference_payloads_equal=150,hyle_vs_eager=summarize('hyle_vs_eager'),hyle_vs_f32_rope=summarize('hyle_vs_f32_rope'),f32_rope_vs_eager=summarize('f32_rope_vs_eager'),target_token_agreements=sum(a==b for a,b in zip(actual['generated_ids'],fixed['target_ids'])),product_math_changed=False,limits=['One science prompt with targets chosen by a pre-existing reference; not an independent language-model quality corpus','Both candidate and reference feed back their own KV/conv/GDN state; only input IDs are shared','Top1 agreement and NLL/KL on this tape do not accept whole-model precision or quality against llama.cpp','Logged timings include diagnostic context and are not fair sustained tokens/s comparison','Only independent reference changes RoPE intermediate precision; Hyle remains original native math'])
save(OUT/'numerical-comparison.json',dict(summary=summary,per_phase=rows));print(json.dumps(summary,indent=2))
