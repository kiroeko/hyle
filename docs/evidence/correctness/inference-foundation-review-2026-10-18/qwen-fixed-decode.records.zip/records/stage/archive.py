"""Inventory fixed-decode evidence; --write publishes it after root's final freeze.

No build, inference, cleanup, moving, SDK/model copy or dependency traversal.
"""
from pathlib import Path
import argparse, difflib, hashlib, json, zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-fixed-decode.zip'
SOURCES = ('tools/qwen35_text/main.cc', 'tools/qwen35_text/README.md')
TEXT = {'.py', '.cc', '.h', '.md', '.json', '.jsonl', '.log', '.txt', '.tsv', '.csv',
        '.ids', '.diff', '.patch', '.xml', '.d', '.cmake', '.ps1', '.sh', '.cmd', '.rsp'}
DECISION_BYTES = {'logits.f32': 248320 * 4, 'hidden.bf16': 2048 * 2}
SKIP_DIRS = {'.git', '__pycache__', 'sdk', 'sdks', 'models', 'weights', 'objects'}
SKIP_NAMES = {'archive-receipt.json'}

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def stable(path):
    if path.is_symlink(): raise ValueError(f'Symlink is not an evidence input: {path}')
    path.resolve().relative_to(ROOT)
    a = path.stat(); data = path.read_bytes(); b = path.stat()
    if (a.st_size, a.st_mtime_ns) != (b.st_size, b.st_mtime_ns):
        raise ValueError(f'Input changed while reading; wait for final freeze: {path}')
    return data
def identity(path, data=None):
    if data is None: data = stable(path)
    return dict(path=str(path.resolve()), bytes=len(data), sha256=sha(data))
def unified(old, new, before, after):
    lines = lambda value: [row+'\n' for row in value.decode('utf-8-sig').splitlines()]
    return ''.join(difflib.unified_diff(lines(old), lines(new), fromfile=before, tofile=after)).encode('utf-8')

def collect():
    payloads, excluded, sources = {}, [], {}
    def add(name, data, origin, kind):
        if name in payloads or '..' in Path(name).parts or name.startswith('/'):
            raise ValueError(f'Unsafe or repeated archive entry: {name}')
        payloads[name] = dict(data=data, source_path=origin, kind=kind)
    for path in sorted(OUT.rglob('*')):
        if not path.is_file(): continue
        local = path.relative_to(OUT)
        if (any(part.lower() in SKIP_DIRS for part in local.parts[:-1])
            or path.name in SKIP_NAMES or
            (path.suffix.lower() not in TEXT and path.name not in DECISION_BYTES)):
            excluded.append(dict(path=local.as_posix(), bytes=path.stat().st_size)); continue
        data = stable(path)
        decision = path.name in DECISION_BYTES
        if decision and len(data) != DECISION_BYTES[path.name]:
            raise ValueError(f'Unexpected decision shape, not a whole-state/model dump: {path}')
        add('stage/'+local.as_posix(), data, str(path.resolve()), 'decision-payload' if decision else 'stage-text')
    for name in SOURCES:
        data = stable(ROOT/name); sources[name] = identity(ROOT/name, data)
        add('candidate/'+name, data, str(ROOT/name), 'authoritative-tool-source')
        before = OUT/'before'/name
        if not before.is_file(): raise FileNotFoundError(f'Missing exact before source: {before}')
        add('diff/'+name+'.diff', unified(stable(before), data, 'before/'+name, 'candidate/'+name), None, 'source-diff')

    fixed = read(OUT/'fixed-inputs.json')
    parity = read(OUT/'science-progress-parity.json')
    old = read(OUT/'original-parity.json')
    guard = read(OUT/'reference-original-guard.json')
    numerical = read(OUT/'numerical-comparison.json')
    reference = read(OUT/'reference-summary.json')
    refresh = read(OUT/'final-provider-refresh-parity.json')
    # Artifact consistency only. These checks do not run the model or turn
    # top1/NLL/relative errors into numerical, quality or performance acceptance.
    assert fixed['selection_before_candidate_execution'] and fixed['not_a_model_quality_evaluation_set']
    assert len(fixed['decode_input_ids']) == 31 and len(fixed['target_ids']) == 32
    assert parity['passed'] and parity['vectors'] == 64 and len(parity['files']) == 64
    assert old['passed'] and len(old['files']) == 6
    assert guard['passed'] and len(guard['files']) == 150 and all(row['bit_equal'] for row in guard['files'])
    assert reference['caches_independent'] and not reference['candidate_values_used']
    assert refresh['passed'] and refresh['vectors'] == 64 and len(refresh['files']) == 64
    for root, rows in [('science-decisions', parity['files']),
                       ('science-scheduler-decisions', parity['files']),
                       ('science-final-decisions', refresh['files']), ('original-decisions', old['files'])]:
        for row in rows:
            item = payloads['stage/'+root+'/'+row['phase']+'/'+row['file']]['data']
            assert len(item) == row['bytes'] and sha(item) == row['sha256']
    compiled = read(OUT/'compile-consumer.result.json')
    main = str((ROOT/SOURCES[0]).resolve())
    compiled_source = next(row for row in compiled['sources_after'] if row['path'] == main)
    assert compiled_source == sources[SOURCES[0]], 'Tool changed after the recorded consumer compile'
    if (OUT/'live.json').exists(): assert read(OUT/'live.json').get('terminal'), 'A stage command is still live'

    manifest = dict(
        kind='fixed-input full-model diagnosis, source and raw decision evidence',
        source_policy='candidate/ reads authoritative main.cc and README at archive execution; exact before sources and commands/results remain under stage/. The script follows no path inside weights.tsv, link plans, dependency JSON or receipts.',
        payload_policy='All original logits/hidden paths are retained, including both Direct and Scheduler copies. No content reconstruction step is required to reuse the stage analyzer.',
        scope='One fixed science prompt and 31 preselected decode inputs; each native/independent reference journey feeds back its own state. RoPE F32 is a reference-only diagnostic.',
        interpretation='Top1 agreement, KL, NLL and relative errors are diagnostic measurements, not model accuracy/quality acceptance. Targets came from the pre-existing reference; a negative target-NLL delta is not evidence of better quality. Logged times are not a fair sustained-throughput comparison.',
        observed_numerical_summary=numerical['summary'], independent_reference_summary=reference,
        exact_sources=sources, cleanup_performed=False, files_moved=False,
        excluded=excluded,
        files=[dict(path=name, source_path=row['source_path'], kind=row['kind'],
                    bytes=len(row['data']), sha256=sha(row['data'])) for name, row in sorted(payloads.items())])
    return payloads, manifest

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true', help='publish once after root confirms final validation; default is inventory only')
    args = parser.parse_args()
    if args.write and DEST.exists(): raise FileExistsError(f'Existing evidence will not be overwritten: {DEST}')
    payloads, manifest = collect()
    summary = dict(destination=str(DEST), files=len(payloads),
        payload_bytes=sum(len(row['data']) for row in payloads.values()),
        decision_files=sum(row['kind'] == 'decision-payload' for row in payloads.values()),
        excluded_files=len(manifest['excluded']), excluded_bytes=sum(row['bytes'] for row in manifest['excluded']),
        writes_requested=args.write)
    if not args.write:
        print(json.dumps(summary, indent=2)); return
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, row in sorted(payloads.items()): archive.writestr(name, row['data'])
        archive.writestr('manifest.json', json.dumps(manifest, indent=2).encode('utf-8')+b'\n')
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
        for name, row in payloads.items(): assert sha(archive.read(name)) == sha(row['data']), name
    for name in SOURCES: assert identity(ROOT/name) == manifest['exact_sources'][name], name
    receipt = dict(**summary, archive=identity(DEST), crc_verified=True, payload_sha256_verified=True,
        final_tool_source_drift=False, build_or_inference_executed=False, cleanup_performed=False,
        files_moved=False, copied_sdk_models_or_objects=False)
    (OUT/'archive-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt, indent=2))

if __name__ == '__main__': main()
