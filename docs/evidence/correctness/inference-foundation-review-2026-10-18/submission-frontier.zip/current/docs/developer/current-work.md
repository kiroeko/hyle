# 当前工作主线

2026-10-17，用户明确以下八项工作；后续按用户选择推进。
本页记录任务与范围，不引入状态机、审批、预算或新的开发门禁。

1. 已删除旧治理工具、状态源、审批与资格流程，精简相关说明；保留实际构建、数值、资源寿命和并发回归。
2. 删除、合并、简化文档，减少重复和失效规则，保留有用的设计依据与历史源码、日志、数据。
   已按“首次构建→接入 C++→按任务查模块”重排入口，保留四层分工；共用合同集中说明，
   复杂边界保留示例与反例，过程卡与过时规则已清理。入口见[文档导航](../README.md)。
3. 提供统一初始化入口，在受支持系统上用简单参数配置编译环境，复用工具链与依赖缓存。
   2026-10-18 已统一为 `scripts/init.py`、`build.py`、`test.py`：自动发现工具链，按后端与产品
   准备依赖，支持配置切换、增量构建和安装；基础系统工具仍按平台正常安装。用法见[初始化指南](setup/README.md)。
4. 检查 Compute/Graph 的公共 C++ 接口是否符合推理引擎调用需要，包括易用性、一致性、布局
   转换及暴露给用户的内部 CMake 变量和宏。不按旧六问重新审核全项目。
   构建系统已完成路线、依赖、target 宏与资源装配的统一，见[构建设计](../architecture/build-system.md)。
   2026-10-18 已静态核对四条后端路线及三种 CPU＋GPU 桥接的公开头、所属 target、能力宏和安装闭包，
   普通消费者仍只链接产品 target；本轮未重跑跨平台交付构建。已移除 direct submit 的双输出位置歧义，
   多输出改用既有 span 入口；禁止租约绑定借用临时 writer，并明确各 owner 的 drain 是否永久关闭接纳。
   同步修正独立 runtime 的公开 prepare 入口及初始化后端选择说明。
5. 狩猎剩余性能输项；只要确认超出仪器分辨率与测量噪声，即使差距小也继续调查。
   2026-10-18 全模块首轮调研及当前优化见[性能清单](../evidence/performance/library-review-2026-10-18/README.md)。
   先排除不同工作与过期实现，再处理真实复杂度问题；历史小输与当前待测项分开记录。
6. 尽快完成独立的 Qwen3.5-2B 纯文本、无 MTP、无多模态、完整 CUDA C++ 推理消费者，
   在同系统、同设备、同源权重与匹配精度/输入条件下对比 llama.cpp 的 prefill/decode tokens/s。
   通过实际调用发现接口、布局、状态管理和执行成本问题，不把外部参考或片段算作完整引擎。
7. 补全 MTP 所需的底座能力与真实消费者验证。
   2026-10-18 本轮补全 GDN 接受前缀快照、融合 recurrent 多 token 输入、页失败后的安全重试，
   并扩展公共状态消费者；用法与引擎边界见[状态版本](../user/state-versions.md#mtp-接受前缀并继续计算)。
8. 补全多模态所需的底座能力与真实消费者验证，优先图像 encoder/projector（mmproj）链路。

## 当前重构主线

2026-10-18，当前主线调整为 Compute/Graph 推理执行架构的设计与全量重构。
先把整体调用链和所有权设计清楚，再纵向迁移实现；目标同时包括算子自然扩展、推理全过程衔接和性能。
目标架构、动态变化边界、迁移次序与完成条件集中在[推理执行体系的重构形状](../architecture/compute-design.md#推理执行体系的重构形状)，
本页不另复制一套设计。

- 统一模型语义图、冷编译、不可变计划、独立执行槽、prepare/layout 更新与严格 submit；普通引擎中间层
  不判断平台、Provider 或原生算子，同一后端的承载事实供 Direct/Graph 共用。
- 纳入原生生成结果的真实所有权，收拢计划、执行槽和退休；保留 caller-buffer 快路径、原生融合与异步进度。
- 贯通 prefill、cached continuation、decode、多请求、页与状态反馈，以及已有分支/接受前缀、失败/重试/关闭能力；
  同时消除具体 op/Provider 在共同资源核心中的特殊判断。
- 以性能约束架构：路由和规划冷生成，动态变化有明确准备边界；追查重复分配、转换、上传、搬运、host 等待及
  时间/空间复杂度问题。单 GPU 不强制 CPU 数学 Context 或额外调度运行时，必要原生开销如实保留并报告。
- 独立 Qwen3.5-2B 文本 CUDA 消费者尽早贯穿新主链，作为实际接口与性能反馈；多模态模型接线和完整 MTP 引擎
  政策不在本 goal 内，其已有底座能力不得退化。普通 API、构建依赖与文档随迁移收拢，不增加治理或繁复验证。
  该引擎是架构测试产物，用真实模型推理发现并回修底座 gap，不作为正式推理引擎产品扩张。

当前先冻结按旧结构继续扩专用接口的做法。共同 Invocation 与资源控制已统一，Vulkan 固定纯图已接通
普通编译入口、原生生成结果、独立槽及 GraphOutput；整体端点统一和旧路径删除尚未完成。
CPU＋Apple 的 dense 固定／有限形状数据链已接通共同入口：输入引用能力、输出表示与可用时机按端口冷声明，
真实原生输出由原 FIFO Copy Job 搬到固定目标；同 storage 的不同 carrier 也明确准备。指定 Air 默认 CPU 组合的
CPU→Apple→CPU 双槽、重复严格提交与失败保护通过，原生／晚端口共11/11。统一异步进度、旧执行链删除仍未完成。
已修复 Apple 只读结果的主机写映射与 Metal copy 目标权限，指定 Air 相关8/8通过；这项修复不代表混合链已迁完。
本轮也明确维护性剩余项：默认 Context 与 batch／搬运装配仍耦合，共同编译／执行实现偏大；
后续收敛依赖、删除重复状态并按职责整理，不继续叠专用包装。
提交／聚合完成／实际退休已移到同一 `submission.cc`，仍使用原 PlanState、InvocationState 和游标；
默认 CPU Context 的 Provider 装配与 batch 编译分开 TU。最后 CPU＋Apple finite 消费者已迁共同 family，
原生专属形状表模板和薄包装删除；Windows 相关24/24、指定 Air 22/22及实际 finite 消费者通过。
Queue 的真实状态寿命与已接纳回调已贯通：Graph 冷绑定持有原 QueueState，热回调沿同一 QueueSequence；
公开句柄移动不改变身份，close 拒绝下一次接纳，已接纳序列仍能完成。旧 Queue 回调直接替换并升级内部 ABI。
Windows 相关69/69、指定 Air 24/24和 Apple finite 消费者通过。独立 batch/copy 和旧协调器仍有句柄借用，
不能由此宣称全仓已取消借用。后续只读审查发现线性游标的 HostWait 会挡住独立后段；旧 CPU＋CUDA 的
并行路径还有 CPU/GPU 重叠，不能直接移成单个串行 Job。共同游标现已用原依赖表的冷后继索引和原槽预留
队列推进就绪前沿；CPU＋CUDA 删除自己的依赖计划／frontier 副本并复用它。共享实际 Queue 的逻辑 lane
使用同一 producer group，最终 prefix 按真实接纳顺序选择。统一异步进度仍保持一个 owner，必要粗粒度 CPU
工作沿现有调度设施异步承载，避免同 pool 等待自身排队任务。真实 Completion 移交、栈上 admission 参数和
回调尾部寿命仍待收进原槽；当前显式 host wait 仍不等于完整非阻塞支持。
本批 Windows 72/72、指定 Air 27/27与原Apple finite消费者通过；真实CUDA的受控CPU-first旅程确认
CPU gate持住期间GPU仍能录入并完成，后续数学、双槽旧结果和取消／退休通过；没有吞吐或整模型结论。
CUDA 相关28个 host TU源码编译、真实 native Provider 的 finite 消费者和两项 checked Gather 通过；
当前默认 ggml CUDA 缺匹配 native 缓存，未用旧库或原始参考库代签运行，具体边界见
[本轮证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。
CPU→Vulkan 常量物化已接入相同冷编译路径，一批权重复用 staging／命令资源，计入编译峰值，真实失败不换路重试。
共同编译已删除同设备总门及 CPU/GPU 后端 ID 专用准入，逐项按实际资源、计算、copy 和完成能力选择路线。
有限精确形状表已进入共同冷编译：不需要伪造通用路线，运行时只选择已编译的原入口，共用累计预算与槽配额。
共同层已验证执行后才生成句柄的端口引用与成功后投影；Apple 同一 Runtime 的原生接线、源槽寿命保护、
借用／拥有式输入及失败传播已在指定 MacBook Air 的四项用例实测通过。
真实 Vulkan 有限形状与控制消费者也已迁到共同入口；独占输入的重复冷绑定权限冲突已修并通过相关回归。
CPU＋CUDA 的有限形状消费者已走相同 family；Apple、Vulkan 与 CPU＋CUDA 的旧形状表薄包装已删除。
Apple 控制片段的私有终点和拥有式 View 输出反馈已接通，原租约精确子范围复用避免逐轮增加元数据 owner。
canonical 常量已逐项持有真实分配，按描述、实际目标资源和足够对齐在 family 内共享 ready owner，
候选重试恢复原始来源并释放不兼容副本；并行实例的对齐记录、实际动态 View 偏移检查已修。
跨运行时前沿、其余混合运行时、custom lowering、分页／pending 接线和旧 native 入口删除仍须继续，
同一计划的跨存储常量根已改为冷准备，按物理实例关联 owner；metadata View 共享完整根，packing 使用本地副本。
Apple 原生源已接通主机／共享 Metal 的冷常量复制，单 GPU 不再为物化权重要求 CPU Context；
Vulkan 冷搬运已覆盖上传、下载和对齐 D2D，保留真实源/目标及 padding 范围校验。
CPU＋Vulkan 的双向动态搬运、按放置边界发现子 region
及纯控制片段完成终点已接入共同计划；真实有限形状消费者已迁移，旧形状表薄包装已删除。
冷发现同时避免让独立的早期片段继承后继新增的外部等待；原生 Copy 冷录制后同槽可直接重放。
其余专用／跨 Runtime／分页消费者尚未迁移，不能以局部纵向代替全量重构。
原功能审查未完成的范围一并承接：此前约 75% 是粗略进度，仍有功能未补齐。新架构落地后继续按既定模型/制品补查、补完功能与完整旅程，不能只做既有功能的等价迁移，也不因换架构重算为完成。
用户明确不保留兼容：直接迁移当前消费者、测试与文档，删除旧接口/薄包装/alias及重复执行体系。

## 已确认范围

- 用户决定 G04/G05 先视为解决；公平实测与边界见
  [同 FP8 输入报告](../evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8/README.md)。
- 用户澄清“多机器”指多系统上的**单机器推理**，不是多台机器协同推理。
- 底座应在受支持系统上覆盖 CPU、CPU＋一张 GPU、单 GPU 三种模式；硬件后端按实际系统支持。
- 除 MTP、多模态外，底座的稳定性和功能完整性仍是核心要求。不能仅用 Qwen3.5-2B
  单请求成功或若干算子片段推导三种模式均完整。
- Windows/Linux/macOS 平台能力、构建后端集合、CPU/GPU/混合执行模式和静态/动态交付应分开表达，
  合法组合由依赖图组装；混合执行所需桥接模块复用相应 CPU/GPU 后端。
- 普通用户无需决定算子分配到哪个 Provider 或启用哪些第三方库。后端选择带出完整实现依赖，
  运行时按请求与设备能力绑定实现；精度、设备放置和资源预算仍由引擎控制。
- 独立 Qwen3.5-2B CUDA 架构测试消费者已执行完整 prefill→续算→decode；数值接受、稳态性能对照与
  其余模型/系统的旅程仍未完成。该消费者不作为基础库交付的正式推理引擎。
- 模型格式、tokenizer、生成/接受策略与请求政策留在独立引擎；可复用计算、存储、
  状态、执行、搬运和图能力在 Compute/Graph 及相应基础模块解决。
- 后续融合和量化接线以既定 8 个文本模型、22 个官方/GGUF 制品配置为范围，
  使用实际 dtype、格式、形状与数值合同核对普通 Provider 路由；历史覆盖表仅提供模型事实，
  其中的旧通过、拒绝与流程状态不直接代表当前支持。
  2026-10-18 的接线补全、实际检查及剩余边界见[本轮报告](../evidence/correctness/model-route-completion-2026-10-18/README.md)。
  继续按 prefill、缓存接续、decode、多请求和接受前缀核对完整调用链；已扩充 CUDA/Vulkan
  量化 embedding，修复 Graph 非对称 attention 输出绑定，并补接四后端的部分高维原生批次。
  可组合的数学、原生分页承载和整模型执行分别记录，不能用当前白名单缩小功能需求。
  用户随后启动[非多模态底座全量审查](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)：
  在以上模型范围内持续review融合、量化接线及Compute/Graph完整推理行为，包括资源调度、
  重复分配/转换/搬运、状态与失败寿命；先查证再修复，不将局部修复视为全量完成。

## 讨论起点

并行准备最小开发入口与真实文本引擎，用实际引擎旅程核对三种执行模式的底座能力。
重点检查驻留与增量状态、布局与 dtype 承载、动态形状与重放、异步搬运与 CPU 预算、
取消/失败/关闭、可观测性、安装包最小消费者，以及正常规模下的性能与显存。
后续实施顺序和具体改动继续按用户讨论推进，不将本页扩展为新的治理流程。

后续接口检查线索：锁定 ggml 的 CUDA GDN/causal conv 原实现要求 F32；这不是已证实的
BF16/FP8 接入遗漏。本轮已接通锁定 ggml 的多 token recurrent snapshot；
默认仍只输出最终状态，MTP 验证块显式请求快照，并按接受前缀恢复。

首个完整消费者重点确认：prepare/repack 是否留在冷路径；KV 有效长度变化是否导致重编译或多余绑定；
GDN、conv、attention 之间是否出现实体转置、dtype 转换或 host 同步；常量与状态能否按真实寿命复用。
`TensorDesc::transposed()` 仅改变描述，不搬运 payload。静态合同无误不代表实际转换次数或热路径成本合理，
不提前规定新的统一布局或合并各原生 runtime。

## 首个 Qwen3.5-2B 消费者的复用材料

模型输入身份见[本地输入清单](../implementation/tasks/compute/qwen35-2b-local-input.json)，
独立公式与中间结果生成见[文本参考](../../tests/compute_models/qwen35_reference.py)，
原运行条件见[参考预检数据](../evidence/correctness/qwen35-cli-preflight/README.md)。
这些材料不代表 Hyle 已整模型执行；加载、tokenizer、chat template、生成循环属于独立引擎。

接线时保留模型特有的数值边界，而不是仅匹配算子名字：

- 普通 RMS 的 scale 为模型规定的 `1+weight`；GDN gated RMS 是另一公式。
- linear Q/K 的 L2 使用 `sum(x*x)+eps`，不是 mean RMS；不要重复施加 GDN 已包含的 `1/sqrt(Dk)`。
- full-attention 的 Q/gate 按 head 拆分；partial RoPE 旋转 64 维并使用实际绝对位置。
- conv history 和 F32 recurrent state 逐层、逐步真实反馈；KV active 长度与 capacity 分开，新请求重置状态。
- 首次 prefill、多 token cached continuation 和单 token decode 分别核对。旧参考依赖的 cached 分支
  曾重置初始 state，不能把该行为复制为数学标准，也不能每轮把候选 state 换成 oracle state 来掩盖累计误差。

完整 CUDA 首版仍按第六项约定关闭 MTP/视觉，并从同源权重、相同精度和完整生命周期与 llama.cpp 比较。
