"""Freeze source/object metadata for the completed focused host run."""
from pathlib import Path
import hashlib
import json


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
PRIOR = OUT.parents[1] / "admitted-queue-sequence"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    commands = read(OUT / "commands.json")
    sources = {row["path"]: dict(row, origin="reused final admitted-queue-sequence host closure")
               for row in read(PRIOR / "cpu-source-identities.json")}
    fresh_objects = []
    for command in commands:
        if command["exit"] or not command["unchanged"]:
            raise RuntimeError("Non-passing command or compile-source drift; preserve evidence for diagnosis")
        for row in command["before"]:
            sources[row["path"]] = dict(row, origin=command["tag"])
        fresh_objects.extend(command.get("objects", []))
    drift = [row for row in sources.values()
             if identity(row["path"])["sha256"] != row["sha256"]]
    if drift:
        save("source-drift.json", drift)
        raise RuntimeError("Current sources differ from final compiled-source metadata")
    objects = read(OUT / "link-object-identities.json")
    for row in objects:
        if identity(row["path"]) != row:
            raise RuntimeError("An explicit link object changed")
    save("source-identities.json", sorted(sources.values(), key=lambda row: row["path"]))
    save("object-identities.json", objects)
    save("fresh-object-identities.json", fresh_objects)
    images = [identity(OUT / ("controls" + suffix)) for suffix in (".exe", ".map", ".exp", ".lib")]
    save("image-identities.json", images)
    result = read(OUT / "results.json")
    summary = read(OUT / "summary.json")
    summary.update({"tests": result["tests"], "suites": len(result["testsuites"]),
        "fresh_hyle_host_tus": len(fresh_objects), "fresh_numerical_sdk_tus": 0,
        "final_compile_record": 8, "final_link_record": 9, "final_run_record": 10,
        "base_link": str(PRIOR / "commands.json") + "#42 cpu-controls-link",
        "actual_explicit_link_objects": len(objects), "compiled_source_drift": 0,
        "fresh_sources": [str(Path(row["path"]).relative_to(ROOT)) for command in commands
                          for row in command["before"][:1]],
        "submission_frontier": [case["name"] for suite in result["testsuites"] if suite["name"] == "SubmissionFrontier"
                                for case in suite["testsuite"]],
        "failures_this_validation": [], "no_product_or_test_edits": True,
        "images_not_deleted": True, "source_snapshots": "source-snapshots/<SHA256>/<filename>",
        "boundaries": "Private/current Plan host behavior only. No throughput claim, no full library or shape matrix, no new CUDA-only aggregate execution."})
    # Compile records alone contribute a source; link/run before[] are empty.
    save("summary.json", summary)
    print(json.dumps({"tests": result["tests"], "failures": result["failures"],
        "fresh_tus": len(fresh_objects), "explicit_objects": len(objects), "compiled_source_drift": 0}, indent=2))


if __name__ == "__main__":
    main()
