"""Prepare by default. Archive only after root's explicit final signal.

No builds, tests, remote calls or deletion are performed.
  python -B freeze_evidence.py --prepare
  python -B freeze_evidence.py --freeze --final-signal
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import zipfile


STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
TARGET = ROOT / "docs/evidence/correctness/inference-foundation-review-2026-10-18/submission-frontier.zip"
COMPONENTS = ("hot", "cold", "tests", "cuda-route")
PREFIXES = ("include/", "src/", "tests/", "scripts/", "samples/", "bench/", "cmake/", "docs/")
TEXT = {".py", ".ps1", ".json", ".log", ".diff", ".patch", ".txt", ".md", ".cc", ".c", ".cpp", ".h", ".hpp", ".cu", ".cuh", ".mm", ".cmake"}
EXCLUDED = {".obj", ".o", ".exe", ".map", ".lib", ".exp", ".dll", ".a", ".pdb", ".so", ".dylib", ".bin", ".metallib", ".cubin", ".fatbin", ".spv", ".bc", ".air", ".pyc", ".zip", ".tar", ".gz", ".7z"}
GENERATED = {"cleanup.json", "cleanup-mac.json", "evidence-candidate.json", "source-candidate.json",
             "prepare-summary.json", "archive-receipt.json", "frozen-summary.json", "archive-entries.json"}
EXTRA = ("src/graph/plan_state.h", "src/graph/executable.cc", "src/graph/submission.cc",
         "src/graph/submission_internal.h", "src/graph/joint_pipeline.h", "src/graph_route_cpu_cuda/invocation.cc",
         "src/graph_route_cpu_cuda/progress.cc", "tests/graph/region_provider_test.cc",
         "docs/architecture/compute-design.md", "docs/developer/current-work.md",
         "docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md", "test.ps1")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(name, value):
    (STAGE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": sha(data)}


def safe_name(name):
    name = name.replace("\\", "/")
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or re.match(r"^[A-Za-z]:", name):
        raise ValueError(f"Unsafe archive member: {name}")
    return p.as_posix()


def source_path(value):
    value = value.replace("\\", "/")
    prefix = ROOT.as_posix() + "/"
    if value.casefold().startswith(prefix.casefold()):
        value = value[len(prefix):]
    if value == "test.ps1":
        return value
    if not value.startswith(PREFIXES):
        hits = [value.find("/" + prefix) for prefix in PREFIXES if "/" + prefix in value]
        if not hits:
            return None
        value = value[min(hits)+1:]
    if ".." in PurePosixPath(value).parts or not value.startswith(PREFIXES):
        return None
    return value if (ROOT / value).is_file() else None


def source_rows(value):
    if isinstance(value, list):
        for row in value:
            yield from source_rows(row)
    elif isinstance(value, dict):
        path = value.get("source") or value.get("path")
        digest = value.get("source_sha256") or value.get("sha256")
        if isinstance(path, str) and isinstance(digest, str):
            relative = source_path(path)
            if relative:
                yield relative, digest
        for key, row in value.items():
            if key not in ("command",) and isinstance(row, (list, dict)):
                yield from source_rows(row)


def text_file(path):
    return path.is_file() and path.suffix.lower() in TEXT and not any(
        part.lower() in {"sdk", "vendor", "__pycache__", "node_modules", "source-snapshots", "candidate"}
        for part in path.relative_to(STAGE).parts)


class Evidence:
    def __init__(self):
        self.items = {}
        self.sources = {}
        self.strict_drift = []
        self.historical_drift = []
        self.derived_checks = []
        self.mac_sources = 0
        self.mac_bundle = STAGE / "mac/mac-results.tar.gz"

    def add(self, name, data, origin):
        name = safe_name(name)
        if Path(name).suffix.lower() in EXCLUDED:
            raise ValueError(f"Forbidden artifact entered archive: {name}")
        if data.startswith((b"MZ", bytes.fromhex("7f454c46"), bytes.fromhex("cffaedfe"), bytes.fromhex("feedfacf"))):
            raise ValueError(f"Native binary magic entered archive: {name}")
        if name in self.items:
            if self.items[name]["data"] != data:
                raise ValueError(f"Conflicting archive entry: {name}")
            self.items[name]["origins"].append(origin)
        else:
            self.items[name] = {"data": data, "origins": [origin]}

    def file(self, name, path):
        self.add(name, path.read_bytes(), str(path))

    def source(self, relative, origin, expected=None, strict=False, payload=None):
        actual = (ROOT / relative).read_bytes()
        mismatch = expected is not None and expected != sha(actual)
        if payload is not None and payload != actual:
            expected, mismatch, strict = sha(payload), True, True
        if mismatch:
            row = {"path": relative, "expected": expected, "actual": sha(actual), "origin": origin}
            (self.strict_drift if strict else self.historical_drift).append(row)
        self.sources.setdefault(relative, set()).add(origin)
        self.add("current/" + relative, actual, origin)

    def mac(self):
        if self.mac_bundle.exists():
            with tarfile.open(self.mac_bundle) as archive:
                for member in archive.getmembers():
                    if not member.isfile():
                        raise ValueError(f"Non-regular Mac member: {member.name}")
                    name = safe_name(member.name)
                    data = archive.extractfile(member).read()
                    if name == "final-sources.tar.gz":
                        with tarfile.open(fileobj=io.BytesIO(data)) as sources:
                            for entry in sources.getmembers():
                                if not entry.isfile():
                                    raise ValueError(f"Non-regular Mac source: {entry.name}")
                                relative = source_path(safe_name(entry.name))
                                payload = sources.extractfile(entry).read()
                                if relative:
                                    self.source(relative, "mac/final-sources/" + entry.name, payload=payload)
                                else:
                                    self.add("mac/source-helpers/" + safe_name(entry.name), payload, str(self.mac_bundle))
                                self.mac_sources += 1
                    elif name.startswith("source/"):
                        relative = source_path(name.removeprefix("source/"))
                        if relative:
                            self.source(relative, "mac/" + name, payload=data)
                        else:
                            self.add("mac/source-helpers/" + name.removeprefix("source/"), data, str(self.mac_bundle))
                        self.mac_sources += 1
                    else:
                        self.add("mac/" + name, data, str(self.mac_bundle) + "!" + name)
        mac = STAGE / "mac"
        if mac.is_dir():
            for path in sorted(mac.iterdir()):
                if text_file(path) and path.name not in {"cleanup-mac.json", "baseline-source-identities.json"}:
                    self.file("mac/local/" + path.name, path)

    def collect(self):
        self.mac()
        for name in ("windows", "cuda"):
            base = STAGE / name
            if base.is_dir():
                for path in sorted(base.rglob("*")):
                    if text_file(path) and path.name not in GENERATED:
                        self.file(name + "/" + path.relative_to(base).as_posix(), path)
        for name in COMPONENTS:
            base = STAGE / name
            for path in sorted(base.rglob("*")):
                relative = path.relative_to(base)
                if text_file(path) and (relative.parts[0] == "before" or
                        path.name in {"source.diff", "source-identities.json", "before-identities.json", "before-sha.json", "summary.json"}):
                    self.file("components/" + name + "/" + relative.as_posix(), path)
        # Reused baseline source identities stay in the raw evidence manifests;
        # snapshot only sources/headers actually compiled or changed this round.
        manifests = {path for path in STAGE.rglob("*source-identit*.json") if "mac" not in path.relative_to(STAGE).parts}
        manifests.update(STAGE / name / "commands.json" for name in ("windows", "cuda"))
        for path in sorted(manifests):
            if path.is_file():
                value = read(path)
                if path == STAGE / "windows/source-identities.json":
                    value = [row for row in value if not row.get("origin", "").startswith("reused final")]
                for relative, expected in source_rows(value):
                    self.source(relative, path.relative_to(ROOT).as_posix(), expected)
        # Final compile records take precedence over earlier attempts for each
        # source/header; old attempts remain intact in their original logs.
        for name in ("windows", "cuda"):
            path = STAGE / name / "commands.json"
            latest = {}
            if path.exists():
                for row in read(path):
                    if row.get("exit") == 0:
                        for relative, expected in source_rows(row.get("after", [])):
                            latest[relative] = expected
                for relative, expected in latest.items():
                    self.source(relative, name + "/final-compiled", expected, strict=True)
        for relative in EXTRA:
            self.source(relative, "explicit current product/docs scope")
        self.file("helpers/scripts/hyle_environment.py", ROOT / "scripts/hyle_environment.py")
        self.file("windows/freeze_evidence.py", Path(__file__))
        self.file("references/admitted-queue-sequence-receipt.json", STAGE.parent / "admitted-queue-sequence/archive-receipt.json")
        for name in ("counted-backend-identity.json", "gated-source-identity.json", "gpu-first-identity.json", "route-identity.json"):
            path = STAGE / "cuda" / name
            if not path.exists():
                continue
            row = read(path)
            for key, hash_key in (("original", "original_sha256"), ("scratch", "scratch_sha256"),
                                  ("source", "source_sha256" if "source_sha256" in row else "sha256")):
                if key not in row or hash_key not in row:
                    continue
                actual_path = Path(row[key])
                if not actual_path.is_absolute():
                    actual_path = ROOT / actual_path
                actual_path = actual_path.resolve()
                if not actual_path.is_relative_to(ROOT):
                    raise ValueError(f"Derived source is outside workspace: {actual_path}")
                canonical = source_path(str(actual_path))
                if canonical:
                    self.source(canonical, "cuda/" + name, row[hash_key], strict=True)
                else:
                    archived = actual_path.relative_to(STAGE).as_posix()
                    payload = self.items[archived]["data"]
                    check = {"path": str(actual_path), "expected": row[hash_key], "actual": sha(payload), "origin": "cuda/" + name}
                    self.derived_checks.append(check)
                    if sha(payload) != row[hash_key]:
                        self.strict_drift.append(check)
        final_cuda_sources = STAGE / "cuda/source-identities.json"
        if final_cuda_sources.exists():
            for row in read(final_cuda_sources):
                path = Path(row["path"]).resolve()
                if path.is_relative_to(STAGE / "cuda"):
                    archived = path.relative_to(STAGE).as_posix()
                    payload = self.items[archived]["data"]
                    check = {"path": str(path), "expected": row["sha256"], "actual": sha(payload),
                             "origin": "cuda/final-source-identities"}
                    self.derived_checks.append(check)
                    if len(payload) != row["bytes"] or sha(payload) != row["sha256"]:
                        self.strict_drift.append(check)
                else:
                    canonical = source_path(str(path))
                    if canonical:
                        self.source(canonical, "cuda/final-source-identities", row["sha256"], strict=True)
        return self

    def manifest(self):
        return [{"path": name, "bytes": len(row["data"]), "sha256": sha(row["data"]), "origins": row["origins"]}
                for name, row in sorted(self.items.items())]

    def source_manifest(self):
        return [{"path": relative, "bytes": len(self.items["current/" + relative]["data"]),
                 "sha256": sha(self.items["current/" + relative]["data"]), "origins": sorted(origins)}
                for relative, origins in sorted(self.sources.items())]


def cleanup():
    files, retained = [], []
    for directory, stems in (("windows", {"controls"}), ("cuda", {"native-consumer", "gated-pipeline"})):
        base = STAGE / directory
        commands_path = base / "commands.json"
        commands = json.dumps(read(commands_path)).replace("\\\\", "/").replace("\\", "/").casefold() if commands_path.exists() else ""
        if not base.is_dir():
            continue
        for path in sorted(base.iterdir()):
            if path.suffix.lower() in {".obj", ".o"}:
                retained.append(identity(path))
            elif path.suffix.lower() in {".exe", ".map", ".exp", ".lib"}:
                executable = path.with_suffix(".exe")
                if path.stem not in stems or not executable.is_file() or executable.resolve().as_posix().casefold() not in commands:
                    raise ValueError(f"Unexpected cleanup candidate: {path}")
                files.append(identity(path))
    plan = {"root": str(STAGE.resolve()), "files": files, "retained_stage_objects": retained,
            "note": "Only stage-local objects retained here; actual link closure identities also list reused external objects. Root test.ps1 alone may delete verified images after archive receipt."}
    if {row["path"] for row in files} & {row["path"] for row in retained}:
        raise ValueError("Cleanup intersects retained objects")
    cuda_plan = STAGE / "cuda/cleanup-candidates.json"
    if cuda_plan.exists():
        actual = [row for row in files if Path(row["path"]).parent == STAGE / "cuda"]
        if sorted(actual, key=lambda row: row["path"]) != sorted(read(cuda_plan)["files"], key=lambda row: row["path"]):
            raise ValueError("Final CUDA cleanup manifest differs from actual image identities")
    save("cleanup.json", plan)
    mac = STAGE / "mac/cleanup-mac.json"
    if mac.exists():
        (STAGE / "cleanup-mac.json").write_bytes(mac.read_bytes())
    return plan, mac.exists()


def result_status():
    missing = []
    windows = read(STAGE / "windows/results.json")
    if windows["tests"] != 72 or windows["failures"] or windows["errors"]:
        missing.append("Windows final 72/72 result")
    summaries = {}
    for name in ("mac", "cuda"):
        candidates = (STAGE / name / "summary.json", STAGE / name / (name + "-summary.json"))
        path = next((path for path in candidates if path.exists()), None)
        if path:
            summaries[name] = read(path)
        else:
            missing.append(name + " final summary")
    if not (STAGE / "mac/mac-results.tar.gz").exists():
        missing.append("Mac final source/result bundle")
    if not (STAGE / "mac/cleanup-mac.json").exists():
        missing.append("Mac exact cleanup manifest")
    if "mac" in summaries:
        mac = summaries["mac"]
        if mac.get("tests") != 27 or mac.get("failures") != 0 or mac.get("errors") != 0 or mac.get("finite_consumer_exit") != 0:
            missing.append("Mac final 27/27 plus finite consumer")
    if "cuda" in summaries and summaries["cuda"].get("gated_consumer", {}).get("cpu_first") is not True:
        missing.append("CUDA CPU-entered-before-native-gate correction")
    return {"windows": {"tests": windows["tests"], "failures": windows["failures"], "errors": windows["errors"]},
            "platform_summaries": summaries, "pending": missing}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--freeze", action="store_true")
    parser.add_argument("--final-signal", action="store_true")
    args = parser.parse_args()
    if args.freeze and not args.final_signal:
        parser.error("Freeze requires root's explicit final signal and --final-signal")
    if args.freeze and TARGET.exists():
        raise FileExistsError(f"Refusing to overwrite {TARGET}")
    evidence = Evidence().collect()
    plan, has_mac_cleanup = cleanup()
    status = result_status()
    summary = {"mode": "prepared, not frozen", "target": str(TARGET), "entries": len(evidence.items),
               "unique_current_sources": len(evidence.sources), "mac_final_source_entries": evidence.mac_sources,
               "strict_compiled_source_drift": evidence.strict_drift, "historical_identity_drift": evidence.historical_drift,
               "derived_source_checks": evidence.derived_checks,
               "windows_cuda_cleanup_files": len(plan["files"]), "cleanup_bytes": sum(row["bytes"] for row in plan["files"]),
               "retained_stage_objects": len(plan["retained_stage_objects"]), "has_mac_cleanup": has_mac_cleanup,
               "results": status, "built_or_tested_by_archive_script": False, "deleted_files": 0,
               "exclusions": "SDK/vendor, all objects/images/maps/libraries, pycache, nested archives, duplicate current candidate/source snapshots, repository-wide dirty diffs"}
    save("evidence-candidate.json", evidence.manifest())
    save("source-candidate.json", evidence.source_manifest())
    save("prepare-summary.json", summary)
    if not args.freeze:
        print(json.dumps({key: summary[key] for key in ("mode", "entries", "unique_current_sources", "windows_cuda_cleanup_files", "retained_stage_objects")}, indent=2))
        print("Pending:", status["pending"], "; strict source drift:", len(evidence.strict_drift))
        return
    if status["pending"] or evidence.strict_drift:
        raise RuntimeError("Final evidence is pending or compiled sources changed; no archive created")
    summary["mode"] = "frozen after root final signal"
    evidence.add("summary.json", (json.dumps(summary, indent=2, ensure_ascii=False) + "\n").encode(), "freeze metadata")
    evidence.add("source-identities.json", (json.dumps(evidence.source_manifest(), indent=2) + "\n").encode(), "freeze metadata")
    evidence.file("windows/cleanup.json", STAGE / "cleanup.json")
    evidence.file("windows/cleanup-mac.json", STAGE / "cleanup-mac.json")
    entries = evidence.manifest()
    evidence.add("manifest.json", (json.dumps(entries, indent=2, ensure_ascii=False) + "\n").encode(), "freeze metadata")
    with zipfile.ZipFile(TARGET, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, row in sorted(evidence.items.items()):
            archive.writestr(name, row["data"])
    with zipfile.ZipFile(TARGET) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(evidence.items):
            raise RuntimeError("Archive validation failed")
        for name, row in evidence.items.items():
            if archive.read(name) != row["data"]:
                raise RuntimeError(f"Archive payload changed: {name}")
    save("frozen-summary.json", summary)
    save("archive-entries.json", evidence.manifest())
    receipt = {**identity(TARGET), "entries": len(evidence.items), "verified_uncompressed_entries": True,
               "deleted_files": 0, "cleanup_windows": str(STAGE / "cleanup.json"), "cleanup_mac": str(STAGE / "cleanup-mac.json")}
    save("archive-receipt.json", receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
