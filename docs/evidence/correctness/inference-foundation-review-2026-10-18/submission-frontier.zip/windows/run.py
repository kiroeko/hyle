"""Matched CPU-only host validation; uses existing numerical libraries."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = OUT.parents[1]
PRIOR = ARCH / "admitted-queue-sequence"
sys.path.insert(0, str(ROOT / "scripts"))
from hyle_environment import windows_compiler_environment


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def prior(tag):
    return next(row["command"] for row in reversed(read(PRIOR / "commands.json"))
                if row["tag"] == tag and row["exit"] == 0)


BASE = prior("cpu-controls-link")
CORE = prior("executable-compile")
TEST = prior("region_provider_test-compile")
LEASE = next(row["command"] for row in reversed(read(ARCH / "execution-source-core/commands.json"))
             if row["exit"] == 0 and any(str(arg).endswith("lease_submission.cc") for arg in row["command"]))
ENV = windows_compiler_environment({"CMAKE_CXX_COMPILER": CORE[0], "CMAKE_C_COMPILER": CORE[0]})
ENV["VSLANG"] = "1033"
TORCH = next(Path(arg) for arg in BASE if Path(arg).name.lower() == "torch_cpu.lib")
ENV["PATH"] = str(TORCH.parent) + os.pathsep + ENV["PATH"]
ABI_HEADERS = ("src/graph/plan_state.h", "src/graph/submission_internal.h",
               "include/hyle/compute/detail/queue_ref.h", "include/hyle/compute/detail/queue_sequence.h",
               "src/compute/provider_internal.h", "include/hyle/graph/region_provider.h")


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


def run(tag, command, sources=()):
    history = OUT / "commands.json"
    rows = read(history) if history.exists() else []
    stem = f"{len(rows)+1:02d}-{tag}"
    command = list(map(str, command))
    before = [identity(path) for path in sources]
    for row in before:
        source = Path(row["path"])
        snapshot = OUT / "source-snapshots" / row["sha256"] / source.name
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        if not snapshot.exists():
            snapshot.write_bytes(source.read_bytes())
    print("starting", stem, "driver_pid", os.getpid(), flush=True)
    started = time.monotonic()
    try:
        completed = subprocess.run(command, cwd=ROOT, env=ENV, capture_output=True, timeout=55,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        code, stdout, stderr = completed.returncode, completed.stdout, completed.stderr
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr = 124, error.stdout or b"", error.stderr or b""
    (OUT / (stem + ".stdout.log")).write_bytes(stdout)
    (OUT / (stem + ".stderr.log")).write_bytes(stderr)
    after = [identity(path) for path in sources]
    row = {"tag": tag, "command": command, "exit": code, "seconds": time.monotonic()-started,
           "stdout": stem + ".stdout.log", "stderr": stem + ".stderr.log",
           "before": before, "after": after, "unchanged": before == after}
    if code == 0:
        row["objects"] = [identity(arg[3:]) for arg in command if arg.lower().startswith("/fo")]
    rows.append(row)
    save("commands.json", rows)
    print(stem, code, flush=True)
    if code:
        print(stdout.decode(errors="replace")[-10000:])
        print(stderr.decode(errors="replace")[-4000:])
    if before != after:
        raise SystemExit("Source changed during command; retained both identities")
    if code:
        raise SystemExit(code)


def compile_one(source, name, recipe):
    flags = [arg for arg in recipe[1:] if not arg.lower().startswith(("/fo", "/tp"))
             and not arg.lower().endswith((".cc", ".cpp", ".c"))]
    run(name + "-compile", [recipe[0], *flags, ROOT / source, "/Fo" + str(OUT / (name + ".obj"))],
        [ROOT / source, *(ROOT / header for header in ABI_HEADERS)])


def core():
    for name in ("executable", "submission", "resources", "region_access", "constant_artifact"):
        compile_one("src/graph/" + name + ".cc", name, prior(name + "-compile"))
    compile_one("src/graph/lease_submission.cc", "lease_submission", LEASE)


def tests():
    for name in ("region_provider_test", "constant_artifact_cache_test"):
        compile_one("tests/graph/" + name + ".cc", name, prior(name + "-compile"))


def link():
    replacements = {name + ".obj" for name in ("executable", "submission", "resources", "region_access",
                     "constant_artifact", "lease_submission", "region_provider_test", "constant_artifact_cache_test")}
    command, replaced = [], set()
    for arg in BASE:
        name = Path(arg).name
        if name in replacements:
            command.append(str(OUT / name))
            replaced.add(name)
        elif arg.upper().startswith("/OUT:"):
            command.append("/OUT:" + str(OUT / "controls.exe"))
        elif arg.upper().startswith("/MAP:"):
            command.append("/MAP:" + str(OUT / "controls.map"))
        elif arg.upper().startswith("/IMPLIB:"):
            command.append("/IMPLIB:" + str(OUT / "controls.lib"))
        else:
            command.append(arg)
    if replaced != replacements:
        raise RuntimeError(f"Missing explicit old object in matched closure: {replacements-replaced}")
    objects = [arg for arg in command if arg.lower().endswith(".obj")]
    if len({str(Path(arg).resolve()).casefold() for arg in objects}) != len(objects):
        raise RuntimeError("Duplicate explicit object in link")
    save("link-object-identities.json", [identity(path) for path in objects])
    run("controls-link", command)


def test():
    selected = read(PRIOR / "cpu-summary.json")["filter"] + ":SubmissionFrontier.*"
    run("controls-run", [OUT / "controls.exe", "--gtest_color=no", "--gtest_filter=" + selected,
        "--gtest_output=json:" + str(OUT / "results.json")])
    result = read(OUT / "results.json")
    if result["failures"] or result["errors"]:
        raise SystemExit("Focused regression failed")
    save("summary.json", {"tests": result["tests"], "failures": result["failures"], "errors": result["errors"],
        "filter": selected, "vendor_rebuilt": False, "scope": "Matched CPU host core and 69 prior regressions plus SubmissionFrontier tests",
        "not_run": "CUDA-only aggregate_native_retirement_test and full library/shape matrices; root owns separate actual CUDA scope"})


if __name__ == "__main__":
    {"core": core, "tests": tests, "link": link, "run": test,
     "cache-test": lambda: compile_one("tests/graph/constant_artifact_cache_test.cc",
                                       "constant_artifact_cache_test", prior("constant_artifact_cache_test-compile")),
     "region-test": lambda: compile_one("tests/graph/region_provider_test.cc",
                                        "region_provider_test", prior("region_provider_test-compile"))}[sys.argv[1]]()
