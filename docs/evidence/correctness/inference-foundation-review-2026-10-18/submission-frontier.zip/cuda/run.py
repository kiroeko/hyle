from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
ARCH=OUT.parents[1]
PREVIOUS=ARCH/'admitted-queue-sequence/cuda'
spec=importlib.util.spec_from_file_location('previous_cuda_queue',PREVIOUS/'run.py')
previous=importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
b=previous.b
b.OUT=OUT
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def old(stage,tag):
    return next(row['command']for row in reversed(json.loads((stage/'commands.json').read_text()))if row['tag']==tag and row['exit']==0)
def route():
    source=ROOT/'src/graph_route_cpu_cuda/invocation.cc'
    command=old(PREVIOUS,'joint-invocation.obj-compile')
    command=[('/Fo'+str(OUT/'joint-invocation.obj'))if value.lower().startswith('/fo')else value for value in command]
    before=sha(source)
    b.run('joint-invocation-frontier-compile',command)
    assert before==sha(source)
    save('route-identity.json',dict(source=str(source),source_sha256=before,
        object=str(OUT/'joint-invocation.obj'),object_sha256=sha(OUT/'joint-invocation.obj')))

def replace_once(text,before,after):
    assert text.count(before)==1,before[:80]
    return text.replace(before,after,1)

def gated():
    original=ROOT/'tests/graph/cpu_cuda_pipeline.cc'
    text=original.read_text()
    text=replace_once(text,'#include <hyle/graph/cuda.h>',
        '#include <hyle/graph/cuda.h>\n#include <hyle/compute/providers/cuda.h>\n#include <chrono>\n#include <thread>')
    text=replace_once(text,'  std::atomic<unsigned> phase{0};','''  std::atomic<unsigned> phase{0};
  std::atomic<bool> gate_armed{false}, cpu_entered{false}, cpu_released{false}, cpu_timeout{false};
  std::atomic<bool> begin_control{false}, begin_observed{false}, begin_timeout{false};
  std::atomic<cudaStream_t> watched_stream{nullptr};
  std::atomic<cudaEvent_t> native_event{nullptr};''')
    text=replace_once(text,'  const auto phase = trace.phase.load(std::memory_order_acquire);','''  if (trace.gate_armed.exchange(false, std::memory_order_acq_rel)) {
    trace.cpu_entered.store(true, std::memory_order_release);
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    while (!trace.cpu_released.load(std::memory_order_acquire)) {
      if (std::chrono::steady_clock::now() >= deadline) {
        trace.cpu_timeout.store(true, std::memory_order_release);
        break;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
  }
  const auto phase = trace.phase.load(std::memory_order_acquire);''')
    text=replace_once(text,'HYLE_ASSIGN_OR_RETURN(auto cuda, g::cuda::create_context());','''HYLE_ASSIGN_OR_RETURN(auto selected, c::cuda::device(0));
  const std::array providers{c::ProviderBinding{c::cuda_native::provider()}};
  HYLE_ASSIGN_OR_RETURN(auto cuda, c::Context::create(selected, {.providers = providers}));''')
    text=replace_once(text,'constexpr std::size_t elements = 4 * 1024 * 1024;','constexpr std::size_t elements = 4096;')
    text=replace_once(text,'for (unsigned step = 0; step < 8; ++step)', 'for (unsigned step = 0; step < 1; ++step)')
    needle='''    { HYLE_ASSIGN_OR_RETURN(auto result, slots[0].run()); }
    trace.phase.store(0, std::memory_order_release);'''
    text=replace_once(text,needle,'''    trace.cpu_entered.store(false, std::memory_order_relaxed);
    trace.cpu_released.store(false, std::memory_order_relaxed);
    trace.cpu_timeout.store(false, std::memory_order_relaxed);
    trace.native_event.store(nullptr, std::memory_order_relaxed);
    trace.begin_observed.store(false, std::memory_order_relaxed);
    trace.begin_timeout.store(false, std::memory_order_relaxed);
    HYLE_ASSIGN_OR_RETURN(auto stream, c::cuda::stream(gq[0]));
    trace.watched_stream.store(stream, std::memory_order_release);
    trace.gate_armed.store(true, std::memory_order_release);
    trace.begin_control.store(true, std::memory_order_release);
    struct Release {
      ~Release() {
        trace.begin_control.store(false, std::memory_order_release);
        trace.cpu_released.store(true, std::memory_order_release);
      }
    } release;
    HYLE_ASSIGN_OR_RETURN(auto pending, slots[0].submit());
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
    while (!trace.cpu_entered.load(std::memory_order_acquire) && std::chrono::steady_clock::now() < deadline)
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    HYLE_RETURN_IF_ERROR(require(trace.cpu_entered.load(), "actual CPU executor did not enter its gate"));
    cudaEvent_t event = nullptr;
    cudaError_t observed = cudaErrorNotReady;
    while (std::chrono::steady_clock::now() < deadline) {
      event = trace.native_event.load(std::memory_order_acquire);
      if (event != nullptr) {
        observed = cudaEventQuery(event);
        if (observed == cudaSuccess) break;
        HYLE_RETURN_IF_ERROR(require(observed == cudaErrorNotReady, "native recorded event query failed"));
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    HYLE_RETURN_IF_ERROR(require(event != nullptr && observed == cudaSuccess && !trace.cpu_timeout.load() &&
        trace.begin_observed.load(std::memory_order_acquire) && !trace.begin_timeout.load(),
        "GPU completion did not retire while CPU branch remained held"));
    HYLE_RETURN_IF_ERROR(require(!pending.result(), "held CPU work published its result"));
    std::puts("controlled CUDA begin followed actual CPU gate entry; real GPU event completed before CPU release");
    trace.begin_control.store(false, std::memory_order_release);
    trace.watched_stream.store(nullptr, std::memory_order_release);
    trace.cpu_released.store(true, std::memory_order_release);
    { HYLE_ASSIGN_OR_RETURN(auto result, pending.wait()); }
    trace.phase.store(0, std::memory_order_release);''')
    text=replace_once(text,'for (unsigned step = 0; step < 65; ++step)', 'for (unsigned step = 0; step < 2; ++step)')
    text=text.replace('single_episodes\\\":8','single_episodes\\\":1').replace('changed_steps\\\":65','changed_steps\\\":2')
    main=text.index('int main(int argc, char **argv) {')
    text=text[:main]+'''extern "C" bool hyle_wait_for_cpu_gate(cudaStream_t stream) noexcept {
  if (!trace.begin_control.load(std::memory_order_acquire) ||
      stream != trace.watched_stream.load(std::memory_order_acquire))
    return true;
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
  while (!trace.cpu_entered.load(std::memory_order_acquire)) {
    if (std::chrono::steady_clock::now() >= deadline) {
      trace.begin_timeout.store(true, std::memory_order_release);
      return false;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  if (trace.cpu_released.load(std::memory_order_acquire)) return false;
  trace.begin_observed.store(true, std::memory_order_release);
  return true;
}

extern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t event, cudaStream_t stream) {
  const auto recorded = cudaEventRecord(event, stream);
  if (recorded == cudaSuccess && stream == trace.watched_stream.load(std::memory_order_acquire)) {
    cudaEvent_t empty = nullptr;
    trace.native_event.compare_exchange_strong(empty, event, std::memory_order_release);
  }
  return recorded;
}

int main() {
  const auto status = branches(true, false, 2);
  if (!status.ok()) {
    std::fprintf(stderr, "%.*s\\n", int(status.message().size()), status.message().data());
    return 1;
  }
  return 0;
}
'''
    target=OUT/'gated-pipeline.cc'
    target.write_text(text,encoding='utf-8',newline='\n')
    command=old(PREVIOUS,'consumer.obj-compile')
    command=[value for value in command if not value.endswith('.cc')and not value.lower().startswith('/fo')]
    b.run('gated-pipeline-controlled-compile',[*command,str(target),'/Fo'+str(OUT/'gated-pipeline-controlled.obj')])
    save('gated-source-identity.json',dict(original=str(original),original_sha256=sha(original),
        scratch=str(target),scratch_sha256=sha(target),scope='Original branch/join oracle, actual native CUDA assembly; CPU-first 4096 elements, controlled CUDA begin waits actual CPU gate entry during one gated phase only; two changed two-slot episodes and original cancellation/abandon'))

def counted_backend():
    source=ROOT/'src/compute_backend_cuda/cuda_backend.cc'
    text=source.read_text()
    count=text.count('cudaEventRecord(')
    assert count==1,count
    text=text.replace('cudaEventRecord(','hyle_counted_record(')
    text=replace_once(text,'  auto *selected = static_cast<cuda::detail::QueueState *>(queue);\n  if (selected->active_sequence != nullptr)',
        '  auto *selected = static_cast<cuda::detail::QueueState *>(queue);\n  if (!hyle_wait_for_cpu_gate(selected->stream))\n    return Status::Unavailable("bounded test CPU gate did not enter before CUDA begin");\n  if (selected->active_sequence != nullptr)')
    first=text.index('\n')+1
    text=text[:first]+'\nextern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t, cudaStream_t);\nextern "C" bool hyle_wait_for_cpu_gate(cudaStream_t) noexcept;\n'+text[first:]
    target=OUT/'cuda_backend.counted.cc'
    target.write_text(text,encoding='utf-8',newline='\n')
    command=next(row['command']for row in json.loads((PREVIOUS/'compile-recipes.json').read_text())if row['source']=='src/compute_backend_cuda/cuda_backend.cc')
    command=[str(target)if value==str(source)else('/Fo'+str(OUT/'cuda-backend-controlled.obj'))if value.lower().startswith('/fo')else value for value in command]
    b.run('cuda-backend-controlled-compile',command)
    save('counted-backend-identity.json',dict(original=str(source),original_sha256=sha(source),
        scratch=str(target),scratch_sha256=sha(target),object=str(OUT/'cuda-backend-controlled.obj'),object_sha256=sha(OUT/'cuda-backend-controlled.obj'),
        difference='One cudaEventRecord forwards to actual API observer; begin_sequence_impl additionally calls bounded test-only wait_for_cpu_gate before actual CUDA sequence acquire, enabled only for selected stream in gated phase. No math, event or Completion is simulated.'))

def link(gated=False):
    command=old(PREVIOUS,'native-consumer-link')
    windows=OUT.parent/'windows'
    replacements={name:windows/name for name in ['executable.obj','submission.obj','resources.obj',
        'region_access.obj','constant_artifact.obj','lease_submission.obj']}
    replacements['joint-invocation.obj']=OUT/'joint-invocation.obj'
    if gated:
        replacements['expert-consumer.obj']=OUT/'gated-pipeline-controlled.obj'
        replacements['compute_backend_cuda--cuda_backend.obj']=OUT/'cuda-backend-controlled.obj'
    args=[];changed=[]
    for value in command:
        if value.upper().startswith(('/OUT:','/MAP:')):continue
        path=Path(value)
        if path.name in replacements:
            changed.append(dict(before=value,after=str(replacements[path.name])))
            value=str(replacements[path.name])
        args.append(value)
    for name,path in replacements.items():
        assert path.is_file(),path
        assert any(Path(value).name==name for value in command),name
    name='gated-pipeline'if gated else'native-consumer'
    args+=['/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map'))]
    save(name+'-closure.json',dict(base=str(PREVIOUS/'commands.json'),replacements=changed,
        inputs=[dict(path=value,bytes=Path(value).stat().st_size,sha256=sha(value))for value in args
            if Path(value).suffix.lower()in['.obj','.lib']and Path(value).is_file()]))
    b.run(name+'-link',args)

def run(gated=False):
    name='gated-pipeline'if gated else'native-consumer'
    command=old(OUT,name+'-link')
    directories=[str(Path(value).parent)for value in command if value.endswith('.lib')and Path(value).is_absolute()]
    directories+=['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64',
        'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',str(ROOT/'.scratch/build-compute-v2-dev/bin')]
    os.environ['PATH']=os.pathsep.join(dict.fromkeys(directories))+os.pathsep+os.environ['PATH']
    b.run(name+'-run',[str(OUT/(name+'.exe'))],timeout=30)
if __name__=='__main__':
    if sys.argv[1]=='route':route()
    elif sys.argv[1]=='gated':gated()
    elif sys.argv[1]=='counted-backend':counted_backend()
    elif sys.argv[1]=='link':link()
    elif sys.argv[1]=='gated-link':link(True)
    elif sys.argv[1]=='run':run()
    elif sys.argv[1]=='gated-run':run(True)
    else:raise ValueError(sys.argv[1])
