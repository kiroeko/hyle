from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
def identity(path):
    path=Path(path)
    return dict(path=str(path.resolve()),bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
commands=json.loads((OUT/'commands.json').read_text())
runs=[dict(tag=row['tag'],exit=row['exit'],seconds=row['seconds'],stdout=row['stdout'],stderr=row['stderr'])
    for row in commands if row['tag'].endswith('-run')]
files=[ROOT/'src/graph_route_cpu_cuda/invocation.cc',ROOT/'src/compute_backend_cuda/cuda_backend.cc',
    ROOT/'src/graph/plan_state.h',ROOT/'src/graph/submission_internal.h',ROOT/'src/graph/submission.cc',
    ROOT/'tests/graph/cpu_cuda_pipeline.cc']
source=[]
for path in files:
    target=OUT/'candidate'/path.relative_to(ROOT)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(path.read_bytes())
    source.append(identity(path))
source += [identity(path)for path in sorted(OUT.glob('*.cc'))]
save('source-identities.json',source)
save('retained-objects.json',[identity(path)for path in sorted(OUT.glob('*.obj'))])
images=[identity(path)for path in sorted(OUT.iterdir())if path.suffix.lower()in['.exe','.map','.exp','.lib']]
save('cleanup-candidates.json',dict(scope='Exact stage images only; no deletion performed. All objects/source/logs retained.',files=images))
cpu_first='branches(true, false, 2)'in(OUT/'gated-pipeline.cc').read_text()
save('summary.json',dict(scope='Original SubmissionCursor frontier integration into CPU+CUDA invocation; real GPU verification, no numerical SDK or CU rebuild',
    hardware='Existing NVIDIA GeForce RTX4070 SM8.9 / CUDA13.3 / driver617.14; same local device as prior stage',
    host_compilation=['Current cpuCUDA invocation with new private Plan/Cursor layout',
        'Scratch original pipeline consumer, 4096 elements and two scheduler workers',
        'One current CUDA backend host copy forwarding its one cudaEventRecord to test observer'],
    common_core='Matched submission-frontier/windows/{executable,submission,resources,region_access,constant_artifact,lease_submission}.obj; provider15 and numerical kernel objects retained from previous actual GPU closure',
    runs=runs,
    finite_consumer='Original expert cuda_native Context finite exact shapes1/4 and math/control/quota/old-result oracle unchanged; original product backend object uninstrumented',
    gated_consumer=dict(cpu_first=cpu_first,elements=4096,workers=2,
        episode='One gated independent CPU Abs / native CUDA Neg -> CPU Add; two slots by two changed steps, held result, cancellation, abandonment and drain retained',
        observer='Current scratch backend forwards actual cudaEventRecord and returns original result; test queries that actual event. No Completion/status/math is simulated',
        ordered_begin_control='Run11 only: original begin_sequence_impl calls a bounded test-only wait for the actual CPU executor gate before acquiring the native sequence; watch-stream/phase disabled for all initialization and warmup. Actual CUDA API/kernel/event follows that established gate entry. Main observes completed native event while CPU remains held, then releases CPU and checks complete math.',
        controlled_run='11-gated-pipeline-run.stdout.log',
        bounded_failure='CPU gate times out after5s; main control/event waits are bounded3s and RAII releases CPU on every return. Backend wait has3s bound and rejects rather than fabricating acceptance if CPU gate never enters.',
        gpu_first_caution='Historical run07 gpu-first passed math/gate observation but cannot by itself exclude native completion preceding CPU gate entry; source and raw log preserved separately',
        no_hardware_interval_or_performance_claim=True),
    boundaries=['Actual expert native CUDA assembly, not default ggmlCUDA runtime validation',
        'Default CUDA product ggml resource-bridge IQ1 native cache remains unavailable as documented in preceding stage',
        'Original CPU native runtime and current provider15 host adapters reused; no second CPU ggml/base loaded',
        'Only one existing CPU child is retained; this phase does not implement general CPU blocking offload'],
    provenance=['run.py','route-identity.json','counted-backend-identity.json','gated-source-identity.json',
        'gpu-first-identity.json','native-consumer-closure.json','gated-pipeline-closure.json'],
    cleanup='cleanup-candidates.json',objects='retained-objects.json',git_diff_check='PASS'))
print(json.dumps(dict(summary=str(OUT/'summary.json'),images=len(images),objects=len(list(OUT.glob('*.obj'))),cpu_first=cpu_first),indent=2))
