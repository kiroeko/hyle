from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'architecture-refactor-20261018-admitted-queue-sequence'
PLAN=json.loads((BASE/'compile-plan.json').read_text())
HISTORY=json.loads((BASE/'commands.json').read_text())
RECORDS=json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
SOURCES=[
    ('src/graph/executable.cc','executable','executable'),
    ('src/graph/submission.cc','submission','submission'),
    ('src/graph/resources.cc','resources','resources'),
    ('src/graph/region_access.cc','region-access','region-access'),
    ('src/graph/constant_artifact.cc','constant-artifact','constant-artifact'),
    ('src/graph/lease_submission.cc','lease-submission','executable'),
    ('tests/graph/region_provider_test.cc','region-test','native-test'),
    ('tests/graph/constant_artifact_cache_test.cc','cache-test','native-test')]


def identity(path):
    path=Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def run(tag,command):
    command=list(map(str,command))
    if '--resume' in sys.argv:
        old=next((row for row in reversed(RECORDS) if row['tag']==tag),None)
        if old and old['exit']==0:
            print('retained-command',tag,flush=True)
            return
    stem=f'{len(RECORDS)+1:02d}-{tag}'
    started=time.monotonic()
    with (ROOT/(stem+'.stdout.log')).open('wb') as out,(ROOT/(stem+'.stderr.log')).open('wb') as err:
        process=subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err)
        (ROOT/'live.json').write_text(json.dumps(dict(tag=tag,pid=process.pid))+'\n')
        code=process.wait()
    RECORDS.append(dict(tag=tag,command=command,exit=code,seconds=time.monotonic()-started,
        stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
    (ROOT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
    (ROOT/'live.json').write_text(json.dumps(dict(terminal=True,tag=tag,exit=code))+'\n')
    print(stem,code,flush=True)
    if code:
        print((ROOT/(stem+'.stdout.log')).read_text(errors='replace')[-4500:])
        print((ROOT/(stem+'.stderr.log')).read_text(errors='replace')[-9000:])
        raise SystemExit(code)


def compile_command(source,name,template):
    original=next(row for row in PLAN['sources'] if Path(row['object']).stem==template)['command']
    args=[]
    skip=False
    for arg in original:
        if skip:skip=False;continue
        if arg in {'-c','-o'}:skip=True;continue
        args.append(arg)
    # New private headers must precede every original source-tree include.
    # Unchanged repo headers come from the exact retained source overlay.
    includes=[ROOT/'include',ROOT,ROOT/'src/graph',ROOT/'src/compute',ROOT/'tests/graph',
        BASE/'include',BASE,BASE/'src/graph',BASE/'src/compute',BASE/'tests/graph']
    args[1:1]=['-I'+str(path) for path in includes]
    return args+['-c',str(ROOT/source),'-o',str(ROOT/(name+'.o'))]


def main():
    assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
    (ROOT/'machine.txt').write_text(subprocess.check_output(
        ['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)
        +subprocess.check_output(['xcrun','clang++','--version'],text=True))
    manifest=json.loads((ROOT/'overlay-sources.json').read_text())
    assert identity(BASE/'staged-sources.json')['sha256']==manifest['base_manifest_sha256']
    assert identity(BASE/'compile-plan.json')['sha256']==manifest['base_compile_plan_sha256']
    assert identity(BASE/'native-tests-identities.json')['sha256']==manifest['base_link_manifest_sha256']
    for row in manifest['overlay']:
        assert identity(ROOT/row['path'])['sha256']==row['sha256'],row['path']
    for row in manifest['retained_source_files']:
        assert identity(BASE/row['path'])['sha256']==row['sha256'],row['path']
    baseline=next(row['command'] for row in reversed(HISTORY) if row['tag']=='native-tests-link' and row['exit']==0)
    replace={str(BASE/(name+'.o')):name for name in ['executable','submission','resources','region-access','constant-artifact']}
    old_lease=next(arg for arg in baseline if arg.endswith('/lease-submission.o'))
    replace[old_lease]='lease-submission'
    assert set(replace).issubset(set(baseline)),set(replace)-set(baseline)
    retained=[row for row in json.loads((BASE/'native-tests-identities.json').read_text())
        if Path(row['path']).suffix in {'.o','.a','.dylib'} and row['path'] not in replace]
    for row in retained:
        assert identity(row['path'])['sha256']==row['sha256'],row['path']
    (ROOT/'retained-identities.json').write_text(json.dumps(retained,indent=2)+'\n')
    plan=[dict(source=source,object=str(ROOT/(name+'.o')),template=template,
        command=compile_command(source,name,template)) for source,name,template in SOURCES]
    (ROOT/'compile-plan.json').write_text(json.dumps(dict(base_compile_plan=identity(BASE/'compile-plan.json'),
        provider_contract=15,region_spi=24,batch_spi=5,mla_spi=3,sources=plan),indent=2)+'\n')
    if '--plan-only' in sys.argv:
        print('compile-plan-ready',len(plan),'Hyle host TUs',flush=True)
        return
    metal=(BASE/'mlx.metallib').resolve(strict=True)
    if not (ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(metal)
    for row in plan:run(Path(row['object']).stem+'-compile',row['command'])
    command=[baseline[0],str(ROOT/'region-test.o'),str(ROOT/'cache-test.o')]
    skip=False
    for arg in baseline[1:]:
        if skip:skip=False;continue
        if arg=='-o':command+=['-o',str(ROOT/'native-tests')];skip=True;continue
        if arg.startswith('-Wl,-map,'):arg='-Wl,-map,'+str(ROOT/'native-tests.map')
        if arg in replace:arg=str(ROOT/(replace[arg]+'.o'))
        command.append(arg)
    run('native-tests-link',command)
    (ROOT/'native-tests-identities.json').write_text(json.dumps(
        [identity(arg) for arg in command if str(arg).endswith(('.o','.a','.dylib'))]
        +[identity(ROOT/'native-tests'),identity(ROOT/'native-tests.map')],indent=2)+'\n')
    selected=('AppleNativeRegion.*:AppleLateInput.*:AppleMixedRegion.*:ExactGraphSpecialization.*:'
        'NativeReachability.*:NativePartition.*:'
        'Queue.AdmittedSequenceKeepsItsActualOwnerAfterPublicHandlesClose:'
        'Invocation.PreparedReplayFollowsQueueIdentityAcrossPublicHandleMoves:SubmissionFrontier.*')
    run('native-tests',[ROOT/'native-tests','--gtest_filter='+selected,'--gtest_color=no',
        '--gtest_output=json:'+str(ROOT/'test-results.json')])
    tests={str(ROOT/'region-test.o'),str(ROOT/'cache-test.o')}
    tests.update(str(BASE/(name+'.o')) for name in ['device-test','executable-test','analysis-test','native-test','mixed-test','late-test'])
    consumer=[]
    skip=False
    for arg in command:
        if skip:skip=False;continue
        if arg in tests:continue
        if arg=='-o':consumer+=['-o',str(ROOT/'finite-consumer')];skip=True;continue
        if arg.startswith('-Wl,-map,'):arg='-Wl,-map,'+str(ROOT/'finite-consumer.map')
        consumer.append(arg)
    consumer[1:1]=[str(BASE/'finite-consumer.o')]
    run('finite-consumer-link',consumer)
    run('finite-consumer',[ROOT/'finite-consumer'])
    (ROOT/'new-object-identities.json').write_text(json.dumps([identity(row['object']) for row in plan],indent=2)+'\n')
    (ROOT/'final-source-identities.json').write_text(json.dumps(
        [identity(ROOT/source) for source,name,template in SOURCES]
        +[identity(ROOT/'src/graph/plan_state.h'),identity(ROOT/'src/graph/submission_internal.h')],indent=2)+'\n')


if __name__=='__main__':main()
