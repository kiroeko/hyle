from pathlib import Path
import hashlib
import io
import json
import tarfile
import stage

manifest_path=stage.OUT/'overlay-sources.json'
old_manifest=manifest_path.read_bytes()
manifest=json.loads(old_manifest)
known={row['path']:row for row in manifest['overlay']}
files={'run_remote.py':stage.OUT/'run_remote.py'}
for source in stage.SEEDS:
    if source not in known:files[source]=stage.ROOT/source
new_rows=[]
for name,path in sorted(files.items()):
    row=dict(path=name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    if name in known:known[name].update(row)
    else:
        manifest['overlay'].append(row)
        new_rows.append(name)
manifest['retained_source_files']=[row for row in manifest['retained_source_files'] if row['path'] not in new_rows]
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w:gz') as a:
    for name,path in sorted(files.items()):a.add(path,arcname=name)
    payload=(json.dumps(manifest,indent=2)+'\n').encode()
    item=tarfile.TarInfo('overlay-sources.json');item.size=len(payload)
    a.addfile(item,io.BytesIO(payload))
(stage.OUT/'delta-overlay.tar.gz').write_bytes(data.getvalue())
code='''from pathlib import Path
import hashlib,io,json,sys,tarfile
r=Path('''+repr(stage.REMOTE)+''')
assert hashlib.sha256((r/'overlay-sources.json').read_bytes()).hexdigest()=='''+repr(hashlib.sha256(old_manifest).hexdigest())+'''
(r/'before-driver-1.py').write_bytes((r/'run_remote.py').read_bytes())
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as a:
 assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in a.getmembers())
 a.extractall(r)
manifest=json.loads((r/'overlay-sources.json').read_text())
for row in manifest['overlay']:
 assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
print(len(manifest['overlay']))
'''
print(stage.ssh(code,data.getvalue()).decode().strip())
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
