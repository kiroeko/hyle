from pathlib import Path
import hashlib
import io
import json
import tarfile
import stage

code='''from pathlib import Path
import hashlib,io,json,sys,tarfile
r=Path('''+repr(stage.REMOTE)+''')
def identity(p):
 data=p.read_bytes()
 return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
tests=json.loads((r/'test-results.json').read_text())
commands=json.loads((r/'commands.json').read_text())
assert tests['tests']==27 and tests['failures']==tests['errors']==tests['disabled']==0,tests
assert commands[-1]['tag']=='finite-consumer' and commands[-1]['exit']==0
cleanup=dict(root=str(r),files=[identity(r/name) for name in
 ['native-tests','native-tests.map','finite-consumer','finite-consumer.map']],
 retain=[identity(p) for p in sorted(r.glob('*.o'))])
assert len(cleanup['retain'])==8
(r/'cleanup-mac.json').write_text(json.dumps(cleanup,indent=2)+'\\n')
manifest=json.loads((r/'overlay-sources.json').read_text())
out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w:gz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and not p.is_symlink() and p.suffix in {'.json','.log','.txt','.py'}:
   a.add(p,arcname=p.name)
 for row in manifest['overlay']:
  p=r/row['path']
  assert identity(p)['sha256']==row['sha256'],row['path']
  a.add(p,arcname='source/'+row['path'])
sys.stdout.buffer.write(out.getvalue())
'''
data=stage.ssh(code)
archive=stage.OUT/'mac-results.tar.gz'
archive.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as a:
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in a.getmembers())
    a.extractall(stage.OUT/'results',filter='data')
results=stage.OUT/'results'
manifest=json.loads((results/'overlay-sources.json').read_text())
for row in manifest['overlay']:
    path=stage.OUT/'run_remote.py' if row['path']=='run_remote.py' else stage.ROOT/row['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],row['path']
for row in manifest['retained_source_files']:
    assert hashlib.sha256((stage.ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
summary=dict(machine='Mac16,12',tests=27,failures=0,errors=0,disabled=0,
    finite_consumer_exit=0,fresh_host_tus=8,retained_new_objects=8,
    source_overlay_files=len(manifest['overlay']),retained_source_dependencies=len(manifest['retained_source_files']),
    baseline=stage.BASE,baseline_source_manifest_sha256=manifest['base_manifest_sha256'],
    baseline_compile_plan_sha256=manifest['base_compile_plan_sha256'],
    baseline_object_manifest_sha256=manifest['base_link_manifest_sha256'],
    commands=13,final_run_record=11,finite_consumer_record=13,
    compiler_checks=['-Wall','-Wextra','-Wpedantic','-Werror'],
    initial_failure='03 resources compilation: overlay source path absent; three unchanged reader sources then mirrored into new overlay; no product change',
    vendor_or_kernel_tus_rebuilt=0,products_edited_by_validation_agent=False,
    files_deleted=False,cleanup_manifest='cleanup-mac.json')
(stage.OUT/'mac-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(stage.OUT/'cleanup-mac.json').write_bytes((results/'cleanup-mac.json').read_bytes())
receipt=dict(path=str(archive.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
(stage.OUT/'mac-results-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps(receipt))
