from pathlib import Path
import hashlib
import importlib.util
import io
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-submission-frontier'
BASE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-admitted-queue-sequence'
spec = importlib.util.spec_from_file_location('transport',
    OUT.parents[1]/'apple-readonly-ports/stage.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
ssh = b.ssh
SEEDS = [
    'src/graph/executable.cc', 'src/graph/submission.cc',
    'src/graph/resources.cc', 'src/graph/region_access.cc',
    'src/graph/constant_artifact.cc', 'src/graph/lease_submission.cc',
    'tests/graph/region_provider_test.cc',
    'tests/graph/constant_artifact_cache_test.cc']


def main():
    raw = ssh('''from pathlib import Path
import hashlib,json,subprocess
r=Path('''+repr(BASE)+''')
p=r/'staged-sources.json'
print(json.dumps(dict(machine=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),
 root=str(r),manifest_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
 sources=json.loads(p.read_text()),
 compile_plan_sha256=hashlib.sha256((r/'compile-plan.json').read_bytes()).hexdigest(),
 compile_plan=json.loads((r/'compile-plan.json').read_text()),
 native_link_manifest_sha256=hashlib.sha256((r/'native-tests-identities.json').read_bytes()).hexdigest())))
''')
    baseline = json.loads(raw)
    assert baseline['machine'] == 'Mac16,12'
    (OUT/'baseline-source-identities.json').write_bytes(raw)
    known = {row['path']:row for row in baseline['sources']}
    files = {'run_remote.py':OUT/'run_remote.py'}
    base_required = []
    seen = set()

    def add(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT):
            return
        seen.add(path)
        name = path.relative_to(ROOT).as_posix()
        if '.scratch' in path.relative_to(ROOT).parts:
            return
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if name not in SEEDS and name in known and digest == known[name]['sha256']:
            base_required.append(known[name])
        else:
            files[name] = path
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
            for directory in [path.parent,ROOT,ROOT/'include',ROOT/'src/graph',ROOT/'src/compute']:
                candidate=directory/include
                if candidate.is_file():
                    add(candidate)
                    break

    for source in SEEDS:
        add(ROOT/source)
    rows = [dict(path=name,bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in sorted(files.items())]
    manifest = dict(root=REMOTE,base_root=BASE,base_manifest_sha256=baseline['manifest_sha256'],
        base_compile_plan_sha256=baseline['compile_plan_sha256'],
        base_link_manifest_sha256=baseline['native_link_manifest_sha256'],
        overlay=rows,retained_source_files=sorted(base_required,key=lambda row:row['path']))
    (OUT/'overlay-sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
    files['overlay-sources.json']=OUT/'overlay-sources.json'
    data=io.BytesIO()
    with tarfile.open(fileobj=data,mode='w:gz') as a:
        for name,path in sorted(files.items()):
            a.add(path,arcname=name)
    (OUT/'source-overlay.tar.gz').write_bytes(data.getvalue())
    code='''from pathlib import Path
import io,sys,tarfile
r=Path('''+repr(REMOTE)+''')
assert not r.exists(),r
r.mkdir()
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as a:
 assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in a.getmembers())
 a.extractall(r)
print(r)
'''
    result=ssh(code,data.getvalue())
    (OUT/'stage.log').write_bytes(result)
    print(result.decode().strip(),len(rows),'overlay files',len(base_required),'retained sources',len(data.getvalue()),'bytes')


if __name__=='__main__':main()
