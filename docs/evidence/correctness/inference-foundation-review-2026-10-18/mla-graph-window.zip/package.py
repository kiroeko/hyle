from pathlib import Path
import difflib
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent

def identity(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def main():
    files=['include/hyle/compute/batch_ops.h','src/graph_batch/batch.cc',
           'tests/compute_batch/public_mla_cpu_consumer.cc','tests/compute_batch/mla_test_support.h']
    diff=[]
    for name in files:
        diff.extend(difflib.unified_diff((OUT/'before'/name).read_text('utf-8').splitlines(True),
            (ROOT/name).read_text('utf-8').splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (OUT/'task.diff').write_text(''.join(diff),encoding='utf-8')
    commands=json.loads((OUT/'commands.json').read_text())
    link=next(x['command'] for x in reversed(commands) if x['tag']=='link' and x['exit']==0)
    reused=[Path(x) for x in link if x.endswith(('.obj','.lib')) and Path(x).is_absolute()]
    (OUT/'identities.json').write_text(json.dumps({'sources':[identity(ROOT/n) for n in files],
        'linked_objects_libraries':[identity(p) for p in reused]},indent=2)+'\n')
    summary={
        'problem':'CPU compact MLA Direct already supports causal sliding window; common Paged/RaggedMlaAttention descriptor had no window and Graph wrapper unconditionally rejected any program window!=-1.',
        'fix':'Add same window_left=-1 contract and common option validation to both typed descriptors (operation IDs v2 for changed payload); compare exact configured window in original Graph region admission. No native math/provider routing or precision change. Independent oracle applies bottom-right window start.',
        'actual':'Existing public CPU consumer --window: BF16/H64 paged CKV512+KPE64 window0 and F16/H96 ragged CKV512 window7, two requests Q1+Q3 then Q1+Q1 and page permutation; each three Direct episodes and one ordinary public Graph execution.',
        'numeric':'Independent complete FP64 softmax/value oracle, V aliases same CKV first512; BF16 maxAbs0, F16 maxAbs6.07570899e-5, original .007 absolute budget unchanged. Query1 native plan reuse still asserted. Actual source rounded F16/BF16 input bits.',
        'build':'Only Graph batch wrapper and public CPU consumer fresh host TUs, MSVC14.50.35717 /W4/WX, 4.28s total compile. Reused current matched five generic Graph PlanState consumers, CPU ggml provider/adapter, current typed row BatchSchema/PagedArena objects and current CPU native ops; native SDK reused.',
        'failures_retained':['Initial standalone link included both old native-baseline and current native-after implementation objects plus omitted new row schema helper. Removed the old override and included existing low-precision object; relink only, no product change.'],
        'limits':['No new GPU MLA window/ragged math qualification','No entire model, throughput or full CMake/SDK build claim','Only new two window cases executed; original eight full-window cases not repeated','Default test now includes the two window cases in addition to original eight'],
        'reproduce':'run.py build/test, or link/test; final window-1.stdout.log.',
    }
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (OUT/'cleanup-candidates.json').write_text(json.dumps({'files':[identity(p) for p in OUT.iterdir()
        if p.is_file() and p.suffix in {'.exe','.lib','.exp'}],
        'retain_objects':[str(p) for p in OUT.glob('*.obj')]},indent=2)+'\n')
    entries=[(p,p.name) for p in OUT.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.diff'}]
    entries += [(p,p.relative_to(OUT).as_posix()) for p in (OUT/'before').rglob('*') if p.is_file()]
    entries += [(ROOT/n,'source/'+n) for n in files]
    target=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/mla-graph-window.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,name in entries:z.writestr(name,p.read_bytes())
    print(json.dumps(identity(target)))

if __name__=='__main__':main()
