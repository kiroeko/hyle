from pathlib import Path
import json
import os
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
CACHE=ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla'
OLD=json.loads((CACHE/'commands.json').read_text())
CC=next(x['command'] for x in OLD if x['tag']=='4-consumer-compile')
FLAGS=[x for x in CC[1:] if not x.endswith('.cc') and not x.startswith('/Fo')]
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
ENV=windows_compiler_environment({'CMAKE_CXX_COMPILER':CC[0],'CMAKE_C_COMPILER':CC[0]})
ENV['VSLANG']='1033'
RECORDS=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []

def run(tag,args):
    args=list(map(str,args));start=time.monotonic()
    result=subprocess.run(args,cwd=ROOT,env=ENV,capture_output=True,timeout=180)
    stem=tag+'-'+str(1+sum(x['tag']==tag for x in RECORDS))
    for stream in ['stdout','stderr']:(OUT/(stem+'.'+stream+'.log')).write_bytes(getattr(result,stream))
    RECORDS.append(dict(tag=tag,command=args,exit=result.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
    print(tag,result.returncode,round(RECORDS[-1]['seconds'],2),flush=True)
    print(result.stdout.decode(errors='replace')[-5000:]+result.stderr.decode(errors='replace')[-2000:],flush=True)
    if result.returncode:raise SystemExit(result.returncode)

def build():
    for source,stem in [('src/graph_batch/batch.cc','graph-batch'),
                        ('tests/compute_batch/public_mla_cpu_consumer.cc','consumer')]:
        run(stem+'-compile',[CC[0],*FLAGS,ROOT/source,'/Fo'+str(OUT/(stem+'.obj'))])
    link()

def link():
    old=next(x['command'] for x in OLD if x['tag']=='7-link')
    omit={str(CACHE/(s+'.obj')) for s in ['provider','consumer','graph-batch']}
    args=[x for x in old if x not in omit and not x.startswith(('/OUT:','/MAP:'))
          and not (x.endswith('.obj') and Path(x).name in ['batch-layout.obj','batch-execution.obj','paged-arena.obj','native-baseline.obj'])]
    foundation=ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages'
    derived=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/derived-constant-implementation'
    args += [foundation/(n+'.obj') for n in ['batch_layout','batch_execution','paged_arena']]
    args += [derived/(n+'.obj') for n in ['cpu-provider','cpu-region','graph-executable',
        'graph-constant_artifact','graph-leased_invocation','graph-lease_submission','graph-region_access']]
    args += [ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-sink-denominator-debug/native-after.obj']
    args += [ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj']
    args += [OUT/(n+'.obj') for n in ['graph-batch','consumer']]
    args += ['/OUT:'+str(OUT/'consumer.exe')]
    for a in args:
        if str(a).endswith(('.obj','.lib')) and Path(a).is_absolute():assert Path(a).is_file(),a
    run('link',args)

def test():
    libs=[str(Path(a).parent) for record in RECORDS if record['tag']=='link'
          for a in record['command'] if a.endswith('.lib') and Path(a).is_absolute()]
    ENV['PATH']=os.pathsep.join(dict.fromkeys([str(ROOT/'.scratch/build-compute-v2-dev/bin'),*libs]))+os.pathsep+ENV['PATH']
    run('window',[OUT/'consumer.exe','--window'])

if __name__=='__main__':
    for action in sys.argv[1:] or ['build','test']:globals()[action]()
