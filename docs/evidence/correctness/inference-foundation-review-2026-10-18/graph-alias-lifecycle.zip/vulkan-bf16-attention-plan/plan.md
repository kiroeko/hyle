# Vulkan typed BF16 attention：待实施的最小纵切

本阶段只读产品并澄清两处文档；未修改数学、准入或执行代码，未编译/运行。不能将以下方案写成已支持。

现状

- 普通 Direct `vulkan::prepare` 和 Graph native region 最终共用 `prepare_plan`。`vulkan_program.cc` 的顺序是实际 IREE operation、`bfloat_region_operation`、普通 managed region；不存在须另添的 BF16 Provider 或 executor。
- 普通三输入、dense BSHD、MaskKind::kNone BF16 SDPA 已走 `vulkan_region.cc::lower_bfloat_region`：逐输入 F32 Cast，原 ggml SDPA，F32结果，再 `lower_native_cast`→现 IREE RNE BF16转换。BF16 strided ports不自动符合该dense宽化资格。
- typed page/ragged 的三个相接门仍限 F16：`vulkan_batch.cc::PagedBatchAccess::cache_domain`；`region.cc::PagedAttentionRead::infer_output_descriptions`；锁定 `ggml-vulkan.cpp::supports_op` 中 HYLE_PAGED / HYLE_FULL_F32。Graph page `qualify` 已复用第一门，不需要新平台选择。
- 原 shader 已有 `flash_attn_dequant.glsl` 的 `K/V_PACKED_BF16` 和 `bf16_to_fp32`。`flash_attn_base.glsl` 的 FaTypeK/V specialization=12/13，非F16类型走decode。FullF32明确选择现 `flash_attn_f32_f16_fp32`模块、禁止MMQ和整KV解到F16；名字含f16不代表只能F16。现有SPIR-V可望复用，须以实际小测试证明，不能只删门。
- IREE ProgramKind没有attention；它在此只提供已有的精确最终BF16 Cast，不能误称现成IREE flash实现。

当前空间/精度合同

- 普通SDPA Dk=Dv=64/128/256用原FullF32 fused flash，无全局Q×KV scores/causal mask。仍有query转换、F32 shared tile和可能split-KV scratch；原native公式为 `4*(Dv+2)*B*Q*Hq*split_k`（split_k>1时），并保原shared/storage-buffer限制。
- 普通其他合格depth/吸收MLA及Sink走MatMul→Scale/Mask→Softmax→MatMul；score大小与 `B*Hq*Q*KV` 成正比。`attention_query_block` 以8MiB触发/64MiB目标及对齐、线性输出frontier启发式分块；这不是严格64MiB cap，不能声称全部宽维均fused或零workspace。
- 普通BF16宽化另有完整Q/K/V的F32载荷和F32结果，再存最终BF16；实际峰值仍由原native liveness、对齐和IREE边界确定。typed直接读BF16 cache的目标是保cache物理载荷、只解当前tile，不把全cache变F32影子。
- `region_supports(Cast)`现明确不接F32→BF16，route通过IREE保RNE/NaN/±0。新页路线不能把无验证的内部ggml_cast(BF16)当作同等合同。

最小产品改动（后续授权后实施）

1. `src/compute_route_vulkan/vulkan_batch.cc`：`cache_domain`增plain BF16 Q/cache/output，保现深度、page16、同K/V及设备限制。GQA/MLA容量/activeQ/metadata保持原schema。paged/ragged两个原plan builder对BF16 private attention结果追加已有 `Cast{BF16}`，最终仍原Program输出；F16/Q8路线保持原样。
2. `src/compute_provider_ggml_vulkan/region.cc`：private PagedAttentionRead接受匹配plain BF16。它在BF16分支声明内部F32输出，lower仅将Q变F32，K/V保BF16原view，仍用原flash与页table/window参数；末尾只按真实内部输出dtype转换，F16旧分支不改。route builder的显式BF16 Cast接回原IREE，无新公开端口或结果系统。
3. `third_party/ggml_vulkan_runtime/patches.json`：在同pin原host扩大HYLE_PAGED/FULL_F32类型门，低维BF16及plain高维512/512、576/512保原同类型/geometry/shmem核验；保F32 query/output、精确table bounds、cache window及GQA寻址。按既有patch机制更新afterSHA、NOTICE/锁定tree身份。仅鲜编锁定ggml-vulkan.cpp这个host TU，原库与已含BF16 decode的SPIR-V只读复用；若实际shader身份/实例不匹配即停，不混旧头/库。
4. `graph_route_vulkan/native_paged_region.cc`资格已调用上述cache_domain，普通Graph输出从capacity推导，无需新增Source/Region SPI字段。共同controller、arena权限、pending update/DependentCompletion、InputSources不改。已有私有头签名不必变；页seal若并行修，实际闭包采用其最终当前owner。

首批最小验证（暂未执行）

- 复用 `tests/compute_route_vulkan/native_cache_test.cc::boxed_case<T>`，新增明确BF16实例：一个低维页/ragged和一个模型576→512紧凑MLA；用实际BF16输入的独立FP64 oracle、两phase、causal/window、原页权限和所有输出。增加大正/负值相消且最终结果可表示的情况，不能将F16/BF16窄化差异隐藏在宽松阈值中。
- 复用现Graph page测试环境，在 `tests/graph_route_vulkan/native_region_test.cc` 增一个同普通batch::compile/Invocation的BF16页case，保两槽、旧GraphOutput阻复用、放弃旧观察后重放。使用真实只授权页frame，不使用wholearena假lease；最终BF16 Cast须出现在原native计划并经过现IREE精度资格。
- 保原F16/Q8低维与高维正控、非法layout/cache/设备准入负控。pending/empty/其他深度若未在本窄验证运行，明确未测，不由ready成功代签。
- 不跑8完整模型/吞吐矩阵，不重建SDK或shader集合。native host+两个产品TU及两个小test TU为主要增量；Graph若只复用cache_domain无需重编leaf。当前Hyle privateABI owner必须来自最终matched闭包，不直接从旧SDK抽旧Operation生命周期成员。

8模型事实（源码接线，不是8模型实跑）

- Qwen3.5-2B、Qwen3.8-27B、Qwen3.8-2.4T：现fixture的普通BF16 D256 GQA使用上述F32宽化；GGUF权重dtype不等于attention dtype。typed BF16缓存仍拒。
- Kimi-K3：现吸收MLA fixture由默认F32 dense构成，H96、576→512，BF16投影/舍入边界另外表达；普通路径走组合，不是typed BF16 cache证据。
- GLM-5.3/Flash：现普通MLA fixture H64，分别576→512/512→512，默认F32计算并有独立存储舍入边界；typed BF16 compact cache仍缺。不能因官方FP8/BF16权重标签认定cache已有BF16 native承载。
- DeepSeek-V4-Pro/Flash：当前Sink为实际五输入F32（mask+sinks）且前后显式BF16边界；不能替换为三输入paged或靠上述改动签Sink页融合。

可复用配方/身份

- native host recipe：`.scratch/inference-feature-completion-2026-10-18/vulkan-highdim/build.py`及commands.json；从原cached compile DB取ggml-vulkan.cpp的精确flags，显式host.obj置原ggml-vulkan.lib前，原SPIR-V/archive不改。
- actual SDK/source：`.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e`；原host candidate SHA `eba530dd...`，shader主文件SHA `6286c022...`，与当前manifest afterSHA相符。
- 当前完整功能基线：`.scratch/architecture-refactor-2026-10-18/retire-native-runtime/paging-risks/matched-link-base.json`，含真实当前CPU/原生owner；其Math host仍为上述highdim native-host.obj。common executable需接后续cold-placement-facts已验证current owner；不要以旧matched文件宣称后续源码自动匹配。
- 现F16/Q8 ready/pending64+empty、分页风险及compact MLA证据可作原路线回归参照，不是BF16通过。具体command/identity引用见本stage inventory.json。
