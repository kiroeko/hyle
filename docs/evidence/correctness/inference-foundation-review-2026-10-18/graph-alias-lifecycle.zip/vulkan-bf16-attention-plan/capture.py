"""Read-only source/cache inventory; no imports of build drivers or processes."""
from pathlib import Path
import hashlib,json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
paths=[
 'src/compute_route_vulkan/vulkan_batch.cc',
 'src/compute_route_vulkan/vulkan_region.cc',
 'src/compute_route_vulkan/vulkan_program.cc',
 'src/compute_route_vulkan/vulkan_iree.cc',
 'src/compute_provider_ggml_vulkan/region.cc',
 'src/graph_route_vulkan/native_paged_region.cc',
 'third_party/ggml_vulkan_runtime/patches.json',
 'tests/compute_route_vulkan/native_cache_test.cc',
 'tests/graph_route_vulkan/native_region_test.cc',
 '.scratch/inference-feature-completion-2026-10-18/vulkan-highdim/build.py',
 '.scratch/inference-feature-completion-2026-10-18/vulkan-highdim/identity.json',
 '.scratch/inference-feature-completion-2026-10-18/vulkan-highdim/ggml-vulkan.candidate.cpp',
 '.scratch/inference-feature-completion-2026-10-18/vulkan-highdim/native-host.obj',
 '.scratch/architecture-refactor-2026-10-18/retire-native-runtime/paging-risks/matched-link-base.json',
 '.scratch/architecture-refactor-2026-10-18/native-ready-pages/windows/final-library-identities.json',
 '.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e/src/ggml-vulkan/vulkan-shaders/flash_attn.comp',
 '.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e/src/ggml-vulkan/vulkan-shaders/flash_attn_base.glsl',
 '.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e/src/ggml-vulkan/vulkan-shaders/flash_attn_dequant.glsl',
 'docs/user/vulkan-compute.md',
 'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md',
]
rows=[]
for name in paths:
 path=ROOT/name
 rows.append(dict(path=name,exists=path.is_file(),**(dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) if path.is_file() else {})))
commands=json.loads((ROOT/'.scratch/inference-feature-completion-2026-10-18/vulkan-highdim/commands.json').read_text())
native=[x for x in commands if 'native-host' in x.get('label','')]
record=dict(status='read_only_plan_no_product_math_edits_no_build_or_test',files=rows,
            historical_native_host_commands=native,
            original_shader_rebuild_needed=False,
            caveat='Existing BF16 decode is source-verified, not a new BF16 runtime PASS; actual future host/source/private-ABI closure must be freshly matched.')
(OUT/'inventory.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(len(rows),'read-only source/cache identities;',len(native),'historical host commands retained')
