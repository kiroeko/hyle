from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = ROOT / '.scratch/architecture-refactor-2026-10-18'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

RECIPES = read(ARCH / 'cold-placement-facts/fresh-identities.json')
EXE = next(r for r in RECIPES if r['source']['path'].endswith('executable.cc'))
TEST = next(r for r in RECIPES if r['source']['path'].endswith('region_provider_test.cc'))
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': EXE['command'][0],
                                    'CMAKE_C_COMPILER': EXE['command'][0]})
BASE = read(ARCH / 'cold-placement-facts/link-plan.json')['command']
env['PATH'] = os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in BASE
    if Path(v).is_file() and Path(v).suffix.lower() == '.lib')) + os.pathsep + env['PATH']
env['VSLANG'] = '1033'

def run(tag, command, expected=0):
    rows = read(OUT / 'commands.json') if (OUT / 'commands.json').exists() else []
    stem = f'{len(rows)+1:03d}-{tag}'
    row = dict(tag=tag, command=list(map(str, command)), cwd=str(OUT), exit=None,
               stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    rows.append(row)
    save('commands.json', rows)
    print('START', stem, flush=True)
    start = time.monotonic()
    with (OUT / row['stdout']).open('wb') as out, (OUT / row['stderr']).open('wb') as err:
        child = subprocess.Popen(row['command'], cwd=OUT, env=env, stdout=out, stderr=err,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = child.pid
        save('commands.json', rows)
        row['exit'] = child.wait(timeout=180)
    row['seconds'] = time.monotonic()-start
    save('commands.json', rows)
    print('END', stem, row['exit'], flush=True)
    print((OUT / row['stdout']).read_text(errors='replace')[-6500:], flush=True)
    print((OUT / row['stderr']).read_text(errors='replace')[-2000:], flush=True)
    if row['exit'] != expected:
        raise SystemExit(row['exit'] or 99)

def compile_source(source, recipe, object_name):
    command = [recipe['command'][0]] + [v for v in recipe['command'][1:]
        if not v.lower().startswith(('/fo', '/fd')) and not v.lower().endswith('.cc')]
    assert '/W4' in command and '/WX' in command
    command += [str(ROOT/source), '/Fo'+str(OUT/object_name)]
    before = identity(ROOT/source)
    run(object_name+'-compile', command)
    assert identity(ROOT/source) == before
    save(object_name+'.json', dict(source=before, object=identity(OUT/object_name), command=command))

def link(mode):
    old_test = str(ARCH/'cold-placement-facts/region-test.obj')
    old_graph = str(ARCH/'cold-placement-facts/graph-executable.obj')
    assert old_test in BASE and old_graph in BASE
    replacements = {old_test: str(OUT/'alias-test.obj')}
    if mode == 'candidate': replacements[old_graph] = str(OUT/'graph-executable.obj')
    if mode == 'alias-v1': replacements[old_graph] = str(OUT/'graph-alias-v1.obj')
    command = [replacements.get(v,v) for v in BASE if not v.upper().startswith(('/OUT:', '/MAP:'))]
    if mode == 'candidate':
        assert identity(TEST['source']['path']) == TEST['source']
        assert identity(TEST['object']['path']) == TEST['object']
        command.append(TEST['object']['path'])
    command += ['/OUT:'+str(OUT/(mode+'.exe')), '/MAP:'+str(OUT/(mode+'.map'))]
    save(mode+'-link.json', dict(command=command, inputs=[identity(v) for v in command
        if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}]))
    run(mode+'-link', command)

mode = sys.argv[1]
if mode == 'control':
    assert identity(ROOT/'src/graph/executable.cc') == EXE['source']
    assert identity(EXE['object']['path']) == EXE['object']
    compile_source('tests/graph/alias_liveness_test.cc', TEST, 'alias-test.obj')
    link(mode)
    run('control-run', [OUT/'control.exe', '--gtest_filter=GraphAliasLiveness.*',
        '--gtest_color=no', '--gtest_output=xml:'+str(OUT/'control.xml')], expected=1)
elif mode == 'candidate':
    compile_source('src/graph/executable.cc', EXE, 'graph-executable.obj')
    link(mode)
    controls = ['GraphRegions.AllRejectedRegionsTerminateWithoutRediscoveryOrLeafWork',
        'GraphRegions.RegionRetryCanChangeTargetButHonorsRequiredPlacement',
        'GraphRegions.FinalWorkspaceRetryKeepsHardConstraintsAndBudgets',
        'GraphRegions.EveryAllocationFailureInRegionReselectionRollsBack']
    run('candidate-run', [OUT/'candidate.exe', '--gtest_filter='+':'.join(['GraphAliasLiveness.*',*controls]),
        '--gtest_color=no', '--gtest_output=xml:'+str(OUT/'candidate.xml')])
elif mode == 'alias-v1':
    compile_source('tests/graph/alias_liveness_test.cc', TEST, 'alias-test.obj')
    link(mode)
    run('alias-v1-run', [OUT/'alias-v1.exe', '--gtest_filter=GraphAliasLiveness.*',
        '--gtest_color=no', '--gtest_output=xml:'+str(OUT/'alias-v1.xml')], expected=1)
elif mode == 'paged':
    base = read(OUT.parent/'vulkan-page-seal/semantic-final-link-inputs.json')
    core = read(OUT/'graph-executable.obj.json')
    assert identity(core['source']['path']) == core['source']
    assert identity(core['object']['path']) == core['object']
    source = 'src/graph/executable.cc'
    previous = base['selected_sources'][source]
    command = [core['object']['path'] if v == previous else v for v in base['command']
        if not v.lower().startswith(('/out:', '/map:', '/implib:'))]
    assert core['object']['path'] in command and previous not in command
    command += ['/OUT:'+str(OUT/'paged-final.exe'), '/MAP:'+str(OUT/'paged-final.map'),
        '/IMPLIB:'+str(OUT/'paged-final.lib')]
    base['selected_sources'][source] = core['object']['path']
    base['compiled_source_sha256'][source] = core['source']['sha256']
    for selected_source in base['selected_sources']:
        assert identity(ROOT/selected_source)['sha256'] == base['compiled_source_sha256'][selected_source], selected_source
    save('paged-final-link.json', dict(command=command,
        selected_sources=base['selected_sources'],
        compiled_source_sha256=base['compiled_source_sha256'],
        cached_objects_verified_by='vulkan-page-seal/semantic-final-link-inputs.json',
        replacement=core))
    run('paged-final-link', command)
    run('paged-final-run', [OUT/'paged-final.exe'])
else:
    raise SystemExit('control or candidate required')
