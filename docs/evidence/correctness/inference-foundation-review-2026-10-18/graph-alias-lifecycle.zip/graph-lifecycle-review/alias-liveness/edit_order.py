from pathlib import Path

path = Path(__file__).resolve().parents[4] / 'src/graph/executable.cc'
text = path.read_bytes().decode('utf-8').replace('\r\n', '\n')
start = text.index('  const std::size_t segment_count = plan.segments.size();', text.index('Status plan_workspace('))
end = text.index('  auto group_uses = ', start)
clocks = text[start:end]
clocks = clocks.replace('  Words clocks(plan.allocator);',
    '  container::SmallVector<std::uint64_t, 32, mem::AllocatorRef> clocks(plan.allocator);')
clocks += '''  const auto segment_before = [&](std::uint32_t source,
                                  std::uint32_t destination) noexcept {
    if (source == destination)
      return true;
    if (source >= segment_count || destination >= segment_count)
      return false;
    const auto source_lane = plan.segments[source].lane.ordinal();
    const auto destination_lane = plan.segments[destination].lane.ordinal();
    if (source_lane == destination_lane)
      return segment_sequence[source] < segment_sequence[destination];
    return precise_happens_before && segment_sequence[source] <=
        clocks[static_cast<std::size_t>(destination) * lane_count + source_lane];
  };

'''
text = text[:start] + text[end:]
marker = '  // Establish all required aliases before choosing destructive aliases. A\n'
assert text.count(marker) == 1
text = text.replace(marker, clocks + marker)
begin = text.index('    auto segment_before = ', text.index('Status plan_workspace('))
end = text.index('    auto command_identity = ', begin)
text = text[:begin] + text[end:]
marker = '  // The schema grants broad permission; the selected provider narrows it.\n'
readers = '''  // A scalar last use is sufficient on one ordered lane. With several
  // lanes, earlier independent readers must also precede the destructive
  // write in the actual segment DAG. Reuse its existing bounded clocks.
  // Compact read lists exist only in cold multi-lane planning. On a successful
  // merge the old input readers are consumed, so a long in-place chain does
  // not repeatedly visit its complete history.
  detail::ValueOrdinals alias_read_heads(plan.allocator);
  detail::ValueOrdinals alias_read_next(plan.allocator);
  detail::ValueOrdinals alias_read_segments(plan.allocator);
  if (lane_count > 1) {
    if (!alias_read_heads.try_resize(plan.instance_values.size()) ||
        !alias_read_next.try_resize(plan.node_inputs.size()) ||
        !alias_read_segments.try_resize(plan.node_inputs.size()))
      return plan_allocation_failure();
    std::fill(alias_read_heads.begin(), alias_read_heads.end(), detail::kNoNode);
    for (std::size_t step_index = 0; step_index < plan.steps.size(); ++step_index) {
      const auto &step = plan.steps[step_index];
      if (!step.emits_command())
        continue;
      const auto segment = plan.step_segments[step_index];
      if (segment >= segment_count)
        return Status::Internal("graph alias reader has no segment");
      for (std::size_t port = 0; port < step.input_count; ++port) {
        const auto use = step.input_begin + port;
        if (use >= detail::kNoNode)
          return Status::ResourceExhausted("graph alias reader identity space is exhausted");
        const auto root = group_root(plan.node_inputs[use]);
        alias_read_next[use] = alias_read_heads[root];
        alias_read_segments[use] = segment;
        alias_read_heads[root] = static_cast<std::uint32_t>(use);
      }
    }
  }
  const auto readers_before_write = [&](std::uint32_t root,
                                        std::size_t step) noexcept {
    if (lane_count <= 1)
      return true;
    for (auto use = alias_read_heads[root]; use != detail::kNoNode;
         use = alias_read_next[use])
      if (!segment_before(alias_read_segments[use], plan.step_segments[step]))
        return false;
    return true;
  };

'''
assert text.count(marker) == 1
text = text.replace(marker, readers + marker)
old = '''        if ((internal_pair || external_pair) &&
            plan.instance_descriptions[input] == plan.instance_descriptions[output]) {
'''
new = '''        if ((internal_pair || external_pair) &&
            plan.instance_descriptions[input] == plan.instance_descriptions[output] &&
            readers_before_write(input_root, step_index)) {
'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''          alias_groups[output_root] = input_root;
          last_uses[input_root] = (std::max)(last_uses[input_root], last_uses[output_root]);
'''
new = old + '''          if (lane_count > 1) {
            alias_read_heads[input_root] = alias_read_heads[output_root];
            alias_read_heads[output_root] = detail::kNoNode;
          }
'''
assert text.count(old) == 1
text = text.replace(old, new)
path.write_bytes(text.encode('utf-8'))
