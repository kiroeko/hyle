from pathlib import Path

root = Path(__file__).resolve().parents[4]
path = root / 'src/graph/executable.cc'
data = path.read_bytes()
text = data.decode('utf-8').replace('\r\n', '\n')
begin = text.index('  // The schema supplies only a broad permission. A prepared provider narrows\n', text.index('Status plan_workspace('))
end = text.index('  // The selected provider\'s port requirement applies to the physical bytes,\n', begin)
replacement = '''  // Establish all required aliases before choosing destructive aliases. A
  // later View is another reader of the same storage even when its own node
  // has not been visited at the candidate write's position.
  for (const auto &step : plan.steps) {
    if (step.kind != detail::PlanStepKind::kOperation &&
        step.kind != detail::PlanStepKind::kView)
      continue;
    const auto &node = graph.nodes[step.node_begin];
    if (node.traits().alias != compute::AliasPolicy::kMustAliasInput0 ||
        node.input_count == 0)
      continue;
    for (std::size_t output_index = 0; output_index < node.output_count;
         ++output_index) {
      const auto output = plan.node_outputs[step.output_begin + output_index];
      const auto support = step.kind == detail::PlanStepKind::kView
          ? Result<compute::AliasSupport>(compute::AliasSupport{
                .supported = true, .byte_offset = step.view_offset})
          : step.operation.alias_support(output_index, 0);
      if (!support || !support->supported)
        return Status::Internal("prepared provider omitted a required graph alias");
      const auto input = plan.node_inputs[step.input_begin];
      plan.alias_sources[output] = input;
      plan.alias_offsets[output] = support->byte_offset;
      if ((plan.instance_roles[output] & detail::kExternalOutput) != 0) {
        const auto logical_output = plan.instance_values[output];
        if (has_external_storage_root(plan, input)) {
          plan.binding_roles[logical_output] |= detail::kSourceAliasedOutput;
        } else {
          plan.binding_roles[logical_output] |= detail::kInvocationOwnedOutput;
          plan.instance_roles[output] |= detail::kInvocationOwnedOutput;
          plan.instance_roles[alias_root(plan, input)] |= detail::kRetainedOutputRoot;
        }
      }
    }
  }

  // Liveness belongs to shared physical storage, not just one SSA value.
  // Required aliases are producer-first; optional aliases merge these groups
  // as they are selected. Path compression keeps the cold scratch near-linear
  // without changing the plan's immediate parent/offset or warm path.
  detail::ValueOrdinals alias_groups(plan.allocator);
  if (!alias_groups.try_resize(plan.instance_values.size()))
    return plan_allocation_failure();
  for (std::uint32_t instance = 0; instance < plan.instance_values.size(); ++instance) {
    const auto source = plan.alias_sources[instance];
    if (source != detail::kNoInPlaceSource && source >= instance)
      return Status::Internal("graph physical alias chain is invalid");
    const auto root = source == detail::kNoInPlaceSource
        ? instance : alias_groups[source];
    alias_groups[instance] = root;
    // A published value is read after commands finish, including when only a
    // View of a private workspace root is published.
    if ((plan.instance_roles[instance] & detail::kExternalOutput) != 0)
      last_uses[instance] = plan.steps.size() + 1;
    last_uses[root] = (std::max)(last_uses[root], last_uses[instance]);
  }
  const auto group_root = [&](std::uint32_t instance) noexcept {
    auto root = instance;
    while (alias_groups[root] != root)
      root = alias_groups[root];
    while (alias_groups[instance] != instance) {
      const auto parent = alias_groups[instance];
      alias_groups[instance] = root;
      instance = parent;
    }
    return root;
  };

  // The schema grants broad permission; the selected provider narrows it.
  // An optional alias may consume storage only after every alias reader.
  for (std::size_t step_index = 0; step_index < plan.steps.size(); ++step_index) {
    const auto &step = plan.steps[step_index];
    // Region aliases need a complete boundary-port contract before selection.
    if (step.kind != detail::PlanStepKind::kOperation)
      continue;
    const auto &node = graph.nodes[step.node_begin];
    const auto alias = node.traits().alias;
    if (alias == compute::AliasPolicy::kNone ||
        alias == compute::AliasPolicy::kMustAliasInput0 || node.input_count == 0)
      continue;
    for (std::size_t output_index = 0; output_index < node.output_count; ++output_index) {
      const auto output = plan.node_outputs[step.output_begin + output_index];
      const auto output_root = group_root(output);
      const bool output_is_external =
          (plan.instance_roles[output] & detail::kExternalOutput) != 0;
      const auto candidate_count = alias == compute::AliasPolicy::kMayAliasAnyInput
          ? node.input_count : std::size_t{1};
      for (std::size_t input_index = 0; input_index < candidate_count; ++input_index) {
        const auto input = plan.node_inputs[step.input_begin + input_index];
        if (plan.instance_storage[input] != plan.instance_storage[output])
          continue;
        const auto input_root = group_root(input);
        if (input_root == output_root || last_uses[input_root] != step_index + 1)
          continue;
        // Constants and their metadata Views stay immutable across replays.
        if ((plan.instance_roles[alias_root(plan, input)] & detail::kConstant) != 0)
          continue;
        HYLE_ASSIGN_OR_RETURN(auto support,
                              step.operation.alias_support(output_index, input_index));
        if (!support.supported || support.byte_offset != 0)
          continue;
        const bool input_is_external = (plan.instance_roles[input] &
            (detail::kExternalInput | detail::kConstant)) != 0;
        const bool internal_pair = !output_is_external && !input_is_external &&
            (plan.instance_roles[input] & detail::kExternalOutput) == 0 &&
            !has_external_storage_root(plan, input);
        const bool external_pair = output_is_external && input_is_external;
        if ((internal_pair || external_pair) &&
            plan.instance_descriptions[input] == plan.instance_descriptions[output]) {
          plan.alias_sources[output] = input;
          plan.alias_offsets[output] = 0;
          alias_groups[output_root] = input_root;
          last_uses[input_root] = (std::max)(last_uses[input_root], last_uses[output_root]);
          break;
        }
      }
    }
  }

'''
text = text[:begin] + replacement + text[end:]
old = '''    std::uint32_t root = index;
    std::size_t depth = 0;
    while (requests[root].alias_of != mem::kNoLifetimeAlias) {
      root = requests[root].alias_of;
      if (root >= request_count || ++depth > request_count)
        return Status::Internal("graph workspace alias graph is invalid");
    }
'''
new = '''    const auto parent = requests[index].alias_of;
    if (parent != mem::kNoLifetimeAlias && parent >= index)
      return Status::Internal("graph workspace alias graph is invalid");
    // Requests are emitted producer-first, so each parent's root is ready.
    const auto root = parent == mem::kNoLifetimeAlias ? index : request_roots[parent];
'''
assert text.count(old) == 1
text = text.replace(old, new)
path.write_bytes(text.encode('utf-8'))
