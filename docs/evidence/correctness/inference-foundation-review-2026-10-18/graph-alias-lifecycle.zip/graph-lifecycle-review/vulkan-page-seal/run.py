from pathlib import Path
import difflib,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,j):(OUT/n).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
def ident(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
base=read(ARCH/'retire-native-runtime/paging-risks/matched-link-base.json')
rows=read(ARCH/'native-page-semantics/windows/commands.json')
TEST='tests/graph_batch/paged_semantics_consumer.cc';LEAF='src/graph_route_vulkan/native_paged_region.cc'
def template(source,history):return next(r['command'] for r in reversed(history) if r.get('exit')==0 and any(x.replace('\\','/').endswith(source) for x in r['command']))
test_cmd=template(TEST,rows);leaf_cmd=template(LEAF,read(ARCH/'retire-native-runtime/paging-risks/commands.json'))
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':test_cmd[0],'CMAKE_C_COMPILER':test_cmd[0]})
env['VSLANG']='1033'
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in base['command'] if x.lower().endswith('.lib') and Path(x).is_absolute()))+os.pathsep+env['PATH']
def run(tag,cmd,expected=0,timeout=180):
 r=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(r)+1:03d}-{tag}';row=dict(tag=tag,command=list(map(str,cmd)),stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',expected=expected,exit=None);r.append(row);save('commands.json',r)
 print('START',stem,flush=True);t=time.monotonic()
 with (OUT/row['stdout']).open('wb') as so,(OUT/row['stderr']).open('wb') as se:
  done=subprocess.run(row['command'],cwd=ROOT,env=env,stdout=so,stderr=se,timeout=timeout)
 row.update(exit=done.returncode,seconds=time.monotonic()-t);save('commands.json',r);print('END',stem,done.returncode,flush=True)
 if done.returncode!=expected:
  print((OUT/row['stdout']).read_text(errors='replace')[-5000:]);print((OUT/row['stderr']).read_text(errors='replace')[-5000:]);raise SystemExit(1)
 return row
def compile_one(source,template,stem):
 cmd=[x for x in template if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]+[str(ROOT/source),'/Fo'+str(OUT/(stem+'.obj'))]
 before=ident(ROOT/source);run(stem+'-compile',cmd);assert ident(ROOT/source)==before
 save(stem+'-identity.json',dict(source=before,object=ident(OUT/(stem+'.obj')),command=cmd))
def overlay(final):
 selected=dict(base['selected_sources']);hashes=dict(base['compiled_source_sha256']);replacements={}
 receipts=read(ARCH/'cpu-context-assembly/fresh-identities.json')+read(ARCH/'cold-placement-facts/fresh-identities.json')+[read(ARCH/'optional-file-stream/cuda/batch-transfer-final-identity.json')]
 receipts += [read(OUT/'semantic-test-identity.json')]
 if final:receipts += [read(OUT/'leaf-final-identity.json')]
 for row in receipts:
  source=Path(row['source']['path']).relative_to(ROOT).as_posix()
  if source.startswith('tests/') and source!=TEST:continue
  assert ident(row['source']['path'])==row['source'],source
  assert ident(row['object']['path'])==row['object'],source
  if source in selected:replacements[selected[source]]=row['object']['path']
  selected[source]=row['object']['path'];hashes[source]=row['source']['sha256']
 test_objects={v for s,v in selected.items() if s.startswith('tests/')}
 args=[]
 for x in base['command']:
  x=replacements.get(x,x)
  if x in test_objects or x.lower().startswith(('/out:','/map:','/pdb:','/implib:')):continue
  args.append(x)
 for s in ['src/compute_route_cpu/cpu_context.cc',TEST]:
  if selected[s] not in args:args.append(selected[s])
 actual={s:v for s,v in selected.items() if v in args}
 drift=[]
 for s in actual:
  if ident(ROOT/s)['sha256']!=hashes[s]:drift.append(s)
 assert not drift,drift
 # All retained cached object hashes are checked against the already verified base.
 cached={r['path']:r for r in base['objects']}
 for x in args:
  if x in cached and x not in replacements.values():assert ident(x)==cached[x],x
 stem='semantic-final' if final else 'semantic-before'
 args += ['/OUT:'+str(OUT/(stem+'.exe')),'/MAP:'+str(OUT/(stem+'.map')),'/IMPLIB:'+str(OUT/(stem+'.lib'))]
 save(stem+'-link-inputs.json',dict(command=args,selected_sources=actual,compiled_source_sha256={s:hashes[s] for s in actual},objects=[ident(x) for x in args if x.lower().endswith(('.obj','.lib')) and Path(x).exists()]))
 run(stem+'-link',args)
if sys.argv[1]=='before':
 compile_one(TEST,test_cmd,'semantic-test');overlay(False);run('semantic-before-run',[OUT/'semantic-before.exe'],expected=1)
elif sys.argv[1]=='after':
 compile_one(LEAF,leaf_cmd,'leaf-final');overlay(True);run('semantic-final-run',[OUT/'semantic-final.exe'])
