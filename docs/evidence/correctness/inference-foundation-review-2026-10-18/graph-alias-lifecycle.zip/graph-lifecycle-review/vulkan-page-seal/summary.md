Vk page unchanged-binding replay fix

003 before: CPU math passes; Vulkan math and strict submit pass, then explicit prepare_replay rejects the internally retained result.
006 final: same consumer passes CPU/Vulkan Q18/2/0, two slots, exact pages/window16, original FP64 .002 budget, public old-output refusal, strict submit and explicit re-prepare.
Only test and page leaf host TUs compiled (/W4 /WX). No SDK/kernel rebuild, no timing claim.

cleanup-identities.json lists exact local images/maps for root test.ps1. Objects, before/candidate sources and failed control logs retained.
