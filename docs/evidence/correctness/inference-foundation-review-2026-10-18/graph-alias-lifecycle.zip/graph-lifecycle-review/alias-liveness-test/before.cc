#include <gtest/gtest.h>

#include <array>
#include <span>

#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/executable.h"
#include "hyle/mem/buffer.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;

c::TensorDesc description(std::int64_t count) {
  return c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 5>{1, 1, 1, 1, count}).value();
}

struct Tensor {
  hyle::mem::Buffer buffer;
  c::TensorView view;
  explicit Tensor(c::TensorDesc desc)
      : buffer(hyle::mem::Buffer::create(hyle::mem::system_resource(),
            desc.required_bytes().value(), 64).value()),
        view(c::TensorView::create(desc, buffer.view()).value()) {}
};

c::Context context() {
  const std::array providers{
      c::ProviderBinding{c::aten_cpu::provider(), 100}};
  return c::Context::create(c::cpu::device(), {.providers = providers}).value();
}

std::array<float, 2> read_pair(c::ConstTensorView tensor) {
  std::array<float, 2> values{};
  EXPECT_TRUE(tensor.storage().read(std::as_writable_bytes(std::span(values))).ok());
  return values;
}

TEST(GraphAliasLiveness, LaterOverlappingViewKeepsItsOriginalValues) {
  auto ctx = context();
  auto prepared = c::prepare(ctx, c::Unary{c::UnaryKind::kNeg}, description(2));
  ASSERT_TRUE(prepared) << prepared.error().message();
  ASSERT_TRUE(prepared->alias_support(0, 0).value().supported);
  for (bool view_before_write : {false, true}) {
    SCOPED_TRACE(view_before_write);
    auto builder = g::GraphBuilder::create().value();
    const auto input = builder.input(description(4)).value();
    const auto root = builder.add(c::Unary{c::UnaryKind::kNeg}, input).value();
    const auto first = builder.add(c::View::slice(4, 0, 4).value(), root).value();
    g::ValueId later;
    if (view_before_write)
      later = builder.add(c::View::slice(4, 0, 2).value(), root).value();
    const auto changed = builder.add(c::Unary{c::UnaryKind::kNeg}, first).value();
    if (!view_before_write)
      later = builder.add(c::View::slice(4, 0, 2).value(), root).value();
    const auto changed_part = builder.add(c::View::slice(4, 1, 2).value(), changed).value();
    const auto output = builder.add(c::Binary{c::BinaryKind::kAdd}, changed_part, later).value();
    ASSERT_TRUE(builder.publish(output).ok());
    const auto graph = std::move(builder).finish().value();
    auto compiled = g::compile(graph, ctx);
    ASSERT_TRUE(compiled) << compiled.error().message();
    auto run = compiled->executable.create_invocation().value();
    Tensor source(description(4)), destination(description(2));
    const std::array values{1.F, 2.F, 3.F, 4.F};
    ASSERT_TRUE(source.buffer.view().write(std::as_bytes(std::span(values))).ok());
    ASSERT_TRUE(run.bind(input, source.view).ok());
    ASSERT_TRUE(run.bind(output, destination.view).ok());
    auto queue = ctx.create_queue().value();
    for (int replay = 0; replay < 2; ++replay) {
      auto completion = run.submit(queue);
      ASSERT_TRUE(completion) << completion.error().message();
      ASSERT_TRUE(completion->wait().ok());
      EXPECT_EQ(read_pair(destination.view.as_const()), (std::array{1.F, 1.F}));
    }
  }
}

TEST(GraphAliasLiveness, PublishedPrivateViewSurvivesLaterDestructiveCandidates) {
  auto ctx = context();
  auto builder = g::GraphBuilder::create().value();
  const auto input = builder.input(description(4)).value();
  const auto root = builder.add(c::Unary{c::UnaryKind::kNeg}, input).value();
  const auto kept = builder.add(c::View::slice(4, 1, 2).value(), root).value();
  const auto changed = builder.add(c::Unary{c::UnaryKind::kNeg}, root).value();
  const auto output = builder.add(c::Unary{c::UnaryKind::kNeg}, changed).value();
  ASSERT_TRUE(builder.publish(kept).ok());
  ASSERT_TRUE(builder.publish(output).ok());
  auto graph = std::move(builder).finish().value();
  auto compiled = g::compile(graph, ctx);
  ASSERT_TRUE(compiled) << compiled.error().message();
  auto run = compiled->executable.create_invocation().value();
  Tensor source(description(4)), destination(description(4));
  const std::array values{1.F, 2.F, 3.F, 4.F};
  ASSERT_TRUE(source.buffer.view().write(std::as_bytes(std::span(values))).ok());
  ASSERT_TRUE(run.bind(input, source.view).ok());
  ASSERT_TRUE(run.bind(output, destination.view).ok());
  auto queue = ctx.create_queue().value();
  auto completion = run.submit(queue);
  ASSERT_TRUE(completion) << completion.error().message();
  ASSERT_TRUE(completion->wait().ok());
  auto result = run.output(kept);
  ASSERT_TRUE(result) << result.error().message();
  EXPECT_EQ(read_pair(*result), (std::array{-2.F, -3.F}));
}

TEST(GraphAliasLiveness, LastReaderStillAllowsInternalInPlaceReuse) {
  auto ctx = context();
  auto builder = g::GraphBuilder::create().value();
  const auto input = builder.input(description(4)).value();
  const auto first = builder.add(c::Unary{c::UnaryKind::kNeg}, input).value();
  const auto second = builder.add(c::Unary{c::UnaryKind::kNeg}, first).value();
  const auto output = builder.add(c::Unary{c::UnaryKind::kNeg}, second).value();
  ASSERT_TRUE(builder.publish(output).ok());
  auto graph = std::move(builder).finish().value();
  auto compiled = g::compile(graph, ctx);
  ASSERT_TRUE(compiled) << compiled.error().message();
  EXPECT_EQ(compiled->report.workspace_bytes(), description(4).required_bytes().value());
  auto run = compiled->executable.create_invocation().value();
  Tensor source(description(4)), destination(description(4));
  const std::array values{1.F, 2.F, 3.F, 4.F};
  ASSERT_TRUE(source.buffer.view().write(std::as_bytes(std::span(values))).ok());
  ASSERT_TRUE(run.bind(input, source.view).ok());
  ASSERT_TRUE(run.bind(output, destination.view).ok());
  auto queue = ctx.create_queue().value();
  ASSERT_TRUE(run.submit(queue)->wait().ok());
  std::array<float, 4> actual{};
  ASSERT_TRUE(destination.buffer.view().read(std::as_writable_bytes(std::span(actual))).ok());
  EXPECT_EQ(actual, (std::array{-1.F, -2.F, -3.F, -4.F}));
}
} // namespace
