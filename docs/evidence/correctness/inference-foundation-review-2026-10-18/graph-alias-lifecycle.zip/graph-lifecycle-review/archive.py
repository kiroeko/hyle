from pathlib import Path
import difflib
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/graph-alias-lifecycle.zip'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
def ident(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

alias = OUT/'alias-liveness'
page = OUT/'vulkan-page-seal'
compiled = [read(alias/'graph-executable.obj.json'), read(alias/'alias-test.obj.json'),
            read(page/'leaf-final-identity.json'), read(page/'semantic-test-identity.json')]
for row in compiled:
    assert ident(row['source']['path']) == row['source']
    assert ident(row['object']['path']) == row['object']
suite = ET.parse(alias/'candidate.xml').getroot()
assert int(suite.attrib['tests']) == 8 and int(suite.attrib['failures']) == 0
commands = read(alias/'commands.json')
assert commands[-1]['tag'] == 'paged-final-run' and commands[-1]['exit'] == 0
semantic_log = '\n'.join((alias/commands[-1][stream]).read_text()
                         for stream in ['stdout', 'stderr'])
assert sum('same Graph semantic PASS' in line for line in semantic_log.splitlines()) == 6
assert [r['exit'] for r in commands if r['tag'] == 'control-run'] == [1, 1]
assert next(r for r in commands if r['tag'] == 'alias-v1-run')['exit'] == 1
save('compiled-identities.json', compiled)

sources = ['src/graph/executable.cc', 'src/graph_route_vulkan/native_paged_region.cc',
    'tests/graph/alias_liveness_test.cc', 'tests/graph/CMakeLists.txt',
    'tests/graph_batch/paged_semantics_consumer.cc', 'docs/architecture/compute-design.md',
    'docs/developer/current-work.md', 'docs/user/vulkan-compute.md',
    'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md', 'test.ps1']
snapshot = OUT/'current'
for source in sources:
    path = snapshot/source; path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((ROOT/source).read_bytes())
save('final-source-identities.json', [ident(ROOT/source) for source in sources])
(OUT/'core-source.diff').write_text(''.join(difflib.unified_diff(
    (alias/'executable.before.cc').read_text().splitlines(keepends=True),
    (ROOT/'src/graph/executable.cc').read_text().splitlines(keepends=True),
    fromfile='before/src/graph/executable.cc', tofile='current/src/graph/executable.cc')),
    encoding='utf-8')
selected = []
for name in ['candidate.map', 'paged-final.map']:
    path = alias/name
    rows = [line.rstrip() for line in path.read_text(errors='replace').splitlines()
        if line.rstrip().endswith(('graph-executable.obj', 'alias-test.obj', 'leaf-final.obj', 'semantic-test.obj'))]
    assert any(line.endswith('graph-executable.obj') for line in rows)
    if name == 'paged-final.map': assert any(line.endswith('leaf-final.obj') for line in rows)
    selected += [name, *rows, '']
(OUT/'selected-map-owners.txt').write_text('\n'.join(selected), encoding='utf-8')

files = [ident(stage/(stem+suffix))
    for stage, stems in [(alias, ['control','alias-v1','candidate','paged-final']),
                         (page, ['semantic-before','semantic-final'])]
    for stem in stems for suffix in ['.exe','.map','.exp','.lib']]
retained = [ident(alias/name) for name in ['graph-executable.obj','graph-alias-v1.obj','alias-test.obj']]
retained += [ident(page/name) for name in ['leaf-final.obj','semantic-test.obj']]
save('cleanup-plan.json', dict(files=files, retained=retained, other_cache_retained=True))
save('summary.json', dict(status='focused fixes passed; broader goal active',
    checks=dict(alias_and_original_cold_controls='8/8 PASS',
        original_alias_control='2 numerical failures',
        intermediate_alias_v1_control='cross-lane proof fails without HB admission',
        original_vulkan_page_control='explicit unchanged prepare_replay wrongly rejects',
        combined_current_core_and_page='CPU/Vulkan Q18/Q2/Q0, two slots and old-result controls PASS'),
    changes=['Storage-group liveness for required and optional aliases, including published Views',
        'Actual reader happens-before proof using the existing bounded segment clocks before destructive alias selection',
        'Producer-first workspace request roots in linear time',
        'Vulkan paged seal drops only its completed internal result owner'],
    limits=['No new full-model numerical acceptance or fair throughput result',
        'No new Apple/Linux execution in this round',
        'Cold group/read-list metadata has a real allocation cost; warm path and Plan/Invocation ABI unchanged',
        'Typed BF16 Vulkan page/ragged/MLA is investigated and documented, not implemented here'],
    cleanup=dict(files=len(files), bytes=sum(r['bytes'] for r in files), retained_objects=len(retained))))
assert not DEST.exists(), 'archive already exists; do not overwrite evidence'
excluded = {'.obj','.exe','.lib','.exp','.map','.zip','.pyc'}
paths = [path for path in sorted(OUT.rglob('*')) if path.is_file() and path.suffix.lower() not in excluded]
paths += [path for path in sorted((OUT.parent/'vulkan-bf16-attention-plan').rglob('*')) if path.is_file()]
with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in paths:
        archive.write(path, path.relative_to(OUT.parent).as_posix())
receipt = dict(archive=ident(DEST), source_entries=len(paths), files=len(files),
    bytes=sum(r['bytes'] for r in files), retained_objects=len(retained))
save('archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
