from pathlib import Path
import importlib.util
import json
import os
import sys

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
OLD=ROOT/'.scratch/inference-foundation-review-2026-10-18/cuda-row-cache-indexer'
spec=importlib.util.spec_from_file_location('indexer_build',OLD/'run.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.OUT=OUT
b.records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []

def link():
    previous=json.loads((OLD/'commands.json').read_text())
    command=next(x['command'] for x in reversed(previous) if x['tag']=='link' and x['exit']==0)
    mapping={str(OLD/'delegate.obj'):str(OUT/'delegate.obj'),str(OLD/'row-codec.obj'):str(OUT/'row-codec.obj'),
             str(ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-reader/cuda-row-provider.obj'):str(OUT/'row-provider.obj')}
    fresh=ROOT/'.scratch/inference-foundation-review-2026-10-18/paged-indexer'
    mapping.update({str(ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-pending-graph/leased.obj'):str(fresh/'leased.obj'),
                    str(ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-pending-graph/batch.obj'):str(fresh/'batch.obj'),
                    str(ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-graph/node.obj'):str(fresh/'node.obj')})
    command=[mapping.get(x,x) for x in command if not x.startswith(('/OUT:','/MAP:'))]
    command += [str(OUT/'padded-tests.obj'),'/OUT:'+str(OUT/'padded-tests.exe'),'/MAP:'+str(OUT/'padded-tests.map')]
    b.run('link',command)
    inputs=[Path(x) for x in command if Path(x).suffix in ['.obj','.lib'] and Path(x).is_file()]
    (OUT/'link-identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=b.sha(p)) for p in inputs],indent=2)+'\n')

if __name__=='__main__':
    action=sys.argv[1]
    if action=='host':
        b.host('src/compute_provider_cuda/row_cache_provider.cc','row-provider')
        b.host('src/compute_provider_cuda/cuda_provider.cc','delegate')
        b.host('tests/compute_provider_cuda/row_cache_padded_test.cc','padded-tests')
    elif action=='kernel':b.kernel('src/compute_provider_cuda/row_cache_kernel.cu','row-codec')
    elif action=='test-tu':b.host('tests/compute_provider_cuda/row_cache_padded_test.cc','padded-tests')
    elif action=='row-host':b.host('src/compute_provider_cuda/row_cache_provider.cc','row-provider')
    elif action=='link':link()
    elif action=='test':
        command=next(x['command'] for x in reversed(b.records) if x['tag']=='link' and x['exit']==0)
        runtime=[str(Path(x).parent) for x in command if x.endswith('.lib') and Path(x).is_absolute()]
        runtime += [str(b.base.TOOLKIT/'bin'),str(b.base.TOOLKIT/'bin/x64'),str(b.base.BASE/'bin')]
        b.base.env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+b.base.env['PATH']
        (OUT/'runtime-paths.json').write_text(json.dumps(list(dict.fromkeys(runtime)),indent=2)+'\n')
        b.run('test',[OUT/'padded-tests.exe','--gtest_filter=CudaPaddedRowCache.*:CudaRowCache.EncodesAndSelectsCanonicalRowsAcrossSlots:CudaRowCache.ScalarEmptyUncheckedAndIeeePayloadsKeepTheirContract','--gtest_break_on_failure=0'],120)
    else:raise ValueError(action)
