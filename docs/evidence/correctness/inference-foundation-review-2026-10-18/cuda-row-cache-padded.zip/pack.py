from pathlib import Path
import difflib
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
SOURCES=['src/compute_provider_cuda/row_cache_provider.cc','src/compute_provider_cuda/row_cache_kernel.cu',
         'src/compute_provider_cuda/row_cache_kernel.h','src/compute_provider_cuda/cuda_provider.cc',
         'tests/compute_provider_cuda/row_cache_padded_test.cc','tests/compute_provider_cuda/CMakeLists.txt']
SUPPORT=['include/hyle/compute/model_ops.h','src/compute_batch/row_cache_map.h',
         'tests/compute_models/row_cache_fixture.h','tests/compute_models/row_cache_paged_indexer_fixture.h',
         'tests/compute_models/row_cache_indexer_fixture.h','tests/compute_models/row_cache_graph_fixture.h',
         'tests/compute_models/row_cache_paged_fixture.h']

def main():
    changes=[];identities=[]
    for name in SOURCES+SUPPORT:
        p=ROOT/name;t=OUT/'applied'/name;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
        identities.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
        if name in SOURCES:
            before=OUT/'before'/name
            changes+=list(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],p.read_text().splitlines(True),fromfile='before/'+name,tofile='applied/'+name))
    (OUT/'source-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
    (OUT/'source.diff').write_text(''.join(changes))
    summary=dict(status='Implemented; focused CUDA tests 7/7 PASS; no commit/deletion',
        public_operation='Independent RowCacheGatherDecodePadded; original checked/unchecked decode unchanged. Only -1 -> BF16 +0 with no bank address/read; all other invalid IDs rejected before any decoded output write. Empty bank/all -1 and empty IDs supported.',
        private_map='RowCachePaddedMap IDs/ranges/owned metadata -> physical IDs and F32 0/-Inf mask. Legal score columns outside visible interval become padding; invalid columns/ranges/metadata -> -2/-Inf; downstream checked padded codec rejects -2.',
        runtime='Original SharedQueue and device status reset/complete check. No D2H ID/range reads, per-tile host synchronization, public option, executor, SDK, or numerical kernel. Original Program/MapProgram native ABI unchanged; independent padded entry points use original decode_value codec.',
        error_contract='Decoded BF16 caller output is wholly preserved for invalid IDs/ranges. The private map writes error sentinels; a failed typed Graph mask/downstream output is terminal-unreadable, not an atomic unchanged-output promise for the entire Graph. Accepted prefixes retain original owners until native completion.',
        tests=dict(total=7,passed=7,new=5,original_codec_regressions=2,stdout='15-test.stdout.log',stderr='15-test.stderr.log',
            controls=['Default Direct+Graph: two encodings, odd-byte bank origin, two phases/two slots and old output retention, original checked decode still rejects -1',
                      'Invalid last -2 and >=rows IDs preserve complete decoded output; empty bank with nonempty all-padding IDs, poisoned unused bank, empty IDs',
                      'Actual owned RowCacheBatchSchema metadata maps request-local windows/noncontiguous physical pages; malformed last ID/range -> -2 and unchanged decoded output',
                      'Typed default Graph T3/K3/C4 first-prefill visible0/1<K; two encodings; actual request-page mapping',
                      'Fresh empty-history arena: zero page ReadLease footprint, all four actual page writers held while Graph completes, decoded +0 and mask -Inf']),
        precision='Original codecs and independent row_cache_fixture raw BF16-bit references unchanged; output/cast raw bits checked (NaN cast classification); no tolerance/input weakening.',
        resources=dict(caller_workspace_bytes=0,codec_invocation_private_bytes=0,
                       note='Prepared host metadata reported by sizeof. Typed empty history proves zero page ReadLease footprint and no bank payload read, not zero arena VRAM; existing arena allocates backing at creation.'),
        build='Only row_cache_provider.cc, cuda_provider.cc, row_cache_kernel.cu and new test TU compiled. Reused current native/SDK/default roster and author-frozen paged-indexer leased.obj/batch.obj/node.obj; exact command/input-object SHA in commands.json/link-identities.json. Original CUDA indexer cached objects unaffected.',
        failures_retained=['First host compile used pointer-style custom_as instead of optional; corrected',
                           'First typed test compile assigned {} to Result<Completion>; removed redundant assignment'],
        applied_difference='Row provider final small optional.has_value formatting is whitespace-only relative to compiled body; all tested semantic source is retained. Shared fixture later additions owned by CPU author are not claimed separately exercised.',
        limits=['Windows RTX4070 SM89/CUDA13.3 only; no throughput/latency/peak measurement or full model run',
                'Raw padded decoder accepts empty selected axes. Private PaddedMap rejects nonempty T with K0 so invalid ranges can propagate a sentinel.',
                'Contiguous indexer still emits GEMM for every full-L tile, including empty ranges; activity gates bank decode only. Dense T*L output requires O(TL) writes.',
                'Typed paged CUDA scorer not implemented in this stage. Further design must share request key tile and use only actual request Q span; max_requests times full-T GEMM was rejected.'])
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    artifacts=[]
    for p in OUT.iterdir():
        if p.is_file() and p.suffix in ['.obj','.exe','.lib','.exp']:
            artifacts.append(dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p),suggested_action='retain small matched object cache' if p.suffix=='.obj' else 'rebuildable; parent decides exact cleanup'))
    (OUT/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    p=OUT/'padded-tests.map'
    (OUT/'map-identity.json').write_text(json.dumps(dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p)),indent=2)+'\n')
    (OUT/'map-symbols.txt').write_text('\n'.join(x for x in p.read_text(errors='replace').splitlines() if 'padded' in x.lower() or 'row_cache' in x.lower())+'\n')
    paths=[p for p in OUT.rglob('*') if p.is_file() and p.suffix not in ['.obj','.exe','.lib','.exp','.map','.zip'] and p.name!='package.json']
    package=OUT/'source-results.zip'
    with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(paths):z.write(p,p.relative_to(OUT))
    identity=dict(path=str(package.resolve()),bytes=package.stat().st_size,sha256=sha(package),members=len(paths))
    (OUT/'package.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity,indent=2))

if __name__=='__main__':main()
