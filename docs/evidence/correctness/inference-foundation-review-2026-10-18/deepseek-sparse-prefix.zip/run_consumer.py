from pathlib import Path
import json,subprocess,os,time,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
plan=json.loads((OUT/'run-plan.json').read_text());records=json.loads((OUT/'commands.json').read_text());attempt=sum(x['tag']=='consumer-run' for x in records)
env=os.environ.copy();env['PATH']=plan['env_path']+os.pathsep+str(ROOT/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
limits=dict(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env.update(limits)
t=time.monotonic();p=subprocess.run(plan['command'],cwd=ROOT,env=env,capture_output=True,timeout=180)
(OUT/(f'attempt{attempt}-consumer.stdout.log')).write_bytes(p.stdout);(OUT/(f'attempt{attempt}-consumer.stderr.log')).write_bytes(p.stderr)
records.append(dict(tag='consumer-run',command=plan['command'],cwd=str(ROOT),environment=limits,exit=p.returncode,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'),'EXIT',p.returncode);sys.exit(p.returncode)
