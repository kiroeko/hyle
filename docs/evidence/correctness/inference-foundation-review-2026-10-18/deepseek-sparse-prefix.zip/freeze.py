from pathlib import Path
import json,hashlib,re,zipfile,shutil,subprocess
root=Path.cwd();out=root/'.scratch/inference-foundation-review-2026-10-18/deepseek-sparse-prefix'
def ident(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
source=root/'tests/compute_state/deepseek_sparse_prefix_consumer.cc'
seen=set();queue=[source]
while queue:
 p=queue.pop().resolve()
 if p in seen or not p.is_file() or not p.is_relative_to(root):continue
 seen.add(p)
 for delim,name in re.findall(r'#\s*include\s*([<"])([^>"\r\n]+)[>"]',p.read_text(errors='replace')):
  choices=([p.parent/name,root/name,root/'include'/name] if delim=='"' else [root/'include'/name])
  for q in choices:
   if q.is_file():queue.append(q);break
for p in seen|{root/'tests/compute_state/CMakeLists.txt'}:
 dst=out/'source'/p.relative_to(root);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
shutil.copyfile(root/'.scratch/inference-foundation-review-2026-10-18/deepseek-sparse-prefix-build.py',out/'build.py')
plan=json.loads((out/'run-plan.json').read_text());records=json.loads((out/'commands.json').read_text())
paths=[Path(x) for x in plan['objects']+plan['libraries'] if Path(x).is_file()]
paths += [Path(records[0]['command'][0]),source,root/'tests/compute_state/CMakeLists.txt']
identity=[ident(p) for p in dict.fromkeys(paths)]
(out/'identities.json').write_text(json.dumps(identity,indent=2)+'\n')
hardware=subprocess.run(['powershell','-NoProfile','-Command','Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json -Compress'],capture_output=True,text=True,check=True).stdout.strip()
summary=dict(scope='DeepSeek-Flash projected attention boundary, original compressor/indexer/Sink math with dense F32 state, public CPU Graph/LeasedInvocation/StateStore',result='PASS',geometry=dict(heads=64,depth=512,index_heads=64,index_depth=128,topk=512,cache_capacity=516,initial_visible=512,ratio=4,verify_tokens=8,base_position=2048,completion_positions=[2051,2055],accepted=list(range(9)),continuation_tokens=1),data_contract='Projected main KV/gate, index KV/gate, query/index-query/weights and raw KV are deterministic F32 boundary inputs. Existing explicit BF16, FP8 block64 and F4 block32 roundtrip helpers are reused. This does not prove checkpoint projection, packed low-dtype historical storage, FFN or LM-head.',evidence=dict(distinct_topk_sets=3,ids='Every row has 512 unique in-range IDs below its own visible count; block/reference IDs agree elementwise',state='All 11 resources and cursor compared for k0..8; continued resource+metadata committed to StateStore and compared byte-for-byte; base unchanged',paired_max_absolute_error=0,independent_sink_max_absolute_error=6.10351562e-5,sink_oracle='Existing FP64 softmax+PV formula given actual per-query selected cache predecessor, then explicit BF16 boundary; all 8*64*512 outputs checked',sink_budget='Original BF16 chain abs2e-5 + rel0.025; original F32 pair/state budget abs8e-5 + rel4e-5; neither widened',execution='One public Graph verifies8 and publishes every prefix state; a separate branch executes only accepted0..k tokens from base using single-token public Graph calls, then both continue1 token; no payload observer is fed back to execution'),allocation=dict(lease_pool_bytes=256<<20,state_backing_budget=(256<<20)+(64<<10),host_snapshots='default1MiB limit, explicit cursor12B/version',note='Explicit capacities, not measured process peak. Entire LeasePool backing is correctly charged plus separate metadata; prefix copies and per-query launches are fixture composition, no fused/native paging claim'),hardware=hardware,toolchain='MSVC14.50.35717 /O2 /MD /std:c++latest, existing matched ggml456172 mixed pin native archives/host overlay, baseline CPU program selector; OMP/MKL/OPENBLAS thread limits1 for correctness reproducibility',build='Only new consumer TU, reuse current matched CPU provider/native_batch, fresh ATen GatherElements host object, operation/allocator/selector/native CPU objects and existing foundation. No configure, SDK, native kernel or full library build.',registration='New conditional compute_state/deepseek_sparse_prefix CTest target requires CPU+ggml+native torch_cpu capability; CMake source only, not configured by this experiment',failures_retained=['Initial link lacked existing new BatchSchema::mla_layout object; added retained batch-layout.obj without rebuilding native','Initial StateStore import rejected max_backing exactly256MiB because full shared pool consumed it before cursor metadata; added64KiB metadata headroom, all inputs/math/accuracy unchanged'],limitations=['CPU Graph dense composition only; no Direct/otherGPU/ratio128 evidence in this consumer','No PagedArenaRead raw span/private bypass; selected rows still materialized and per-query Sink calls remain','No timing or memory-peak claim','Independent Sink oracle validates math against actual selected predecessor; compressor math reused existing helper/unit-covered path, not a new full FP64 checkpoint/model oracle'],commands='commands.json',sources=[ident(source),ident(root/'tests/compute_state/CMakeLists.txt')],cleanup_performed=False)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
cleanup=dict(performed=False,root=str(out),files=[ident(p) for p in out.iterdir() if p.is_file() and p.suffix.lower() in {'.exe','.obj','.lib','.exp'}],retain='All source/headers/commands/logs/maps/identities/summary/archive and every reused SDK/foundation/provider/native cache')
(out/'cleanup-candidates.json').write_text(json.dumps(cleanup,indent=2)+'\n')
files=[p for p in out.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.py','.log','.cc','.h','.txt','.map'}]
with zipfile.ZipFile(out/'source-results.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files,key=lambda p:p.relative_to(out).as_posix()):z.write(p,p.relative_to(out).as_posix())
print(json.dumps(ident(out/'source-results.zip')));print('source files',len(seen),'cleanup',len(cleanup['files']),sum(x['bytes'] for x in cleanup['files']));print('source',ident(source))
