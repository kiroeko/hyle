from pathlib import Path
import importlib.util,json,subprocess,time,os,sys
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-foundation-review-2026-10-18/deepseek-sparse-prefix';OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('cached_cpu',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py');cpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(cpu)
cfg=dict(cpu.PINS['mixed'],folder=Path('mixed'));flags=cpu.hyle_flags(cfg)+['/I'+str(ROOT)]
TORCH=Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch');env=cpu.ENV.copy();env['PATH']=str(TORCH/'lib')+os.pathsep+env['PATH']
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command,timeout=180):
 command=list(map(str,command));attempt=sum(x['tag']==tag for x in records);stem=(f'attempt{attempt}-' if attempt else '')+tag;t=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout);(OUT/(stem+'.stdout.log')).write_bytes(p.stdout);(OUT/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=command,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-1500:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
obj=OUT/'consumer.obj'
if '--reuse-consumer' not in sys.argv:run('consumer-compile',[cpu.CL,*flags,ROOT/'tests/compute_state/deepseek_sparse_prefix_consumer.cc','/Fo'+str(obj)])
objects=[obj,ROOT/'.scratch/inference-feature-completion-2026-10-18/mla/batch-layout.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/native-batch.obj',ROOT/'.scratch/inference-feature-completion-2026-10-18/gather-elements-cpu/aten.obj',ROOT/'.scratch/mtp-gdn-2026-10-18/mixed/selector-baseline.obj',ROOT/'.scratch/mtp-gdn-2026-10-18/mixed/allocator.obj',ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj',ROOT/'.scratch/mtp-gdn-2026-10-18/ffa4/operation.obj']
libs=[cpu.BASE/'bin'/(n+'.lib') for n in ['hyle_graph_route_cpu','hyle_graph_provider_onednn','hyle_graph','hyle_compute_route_cpu','hyle_compute_provider_native','hyle_compute_provider_onednn','hyle_compute_state','hyle_compute_stream','hyle_mem_vm','hyle_sched','dnnl']]+cpu.common_libs(cfg)+[TORCH/'lib'/(n+'.lib')for n in ['torch','torch_cpu','c10']]+[cpu.BASE/'lib/gtest.lib']
exe=OUT/'consumer.exe';run('link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/'consumer.map'),*objects,*libs,*cpu.SYSTEM])
(OUT/'run-plan.json').write_text(json.dumps(dict(command=[str(exe)],objects=list(map(str,objects)),libraries=list(map(str,libs)),env_path=str(TORCH/'lib')),indent=2)+'\n')
