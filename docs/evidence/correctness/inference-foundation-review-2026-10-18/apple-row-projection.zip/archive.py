from pathlib import Path
import difflib
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
VALIDATION = STAGE / 'validation'
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

sources = json.loads((VALIDATION / 'final-source-identities.json').read_text())
for entry in sources:
    current = identity(ROOT / entry['path'])
    frozen = identity(VALIDATION / 'final-source' / entry['path'])
    assert (current['bytes'], current['sha256']) == (entry['bytes'], entry['sha256'])
    assert (frozen['bytes'], frozen['sha256']) == (entry['bytes'], entry['sha256'])

summary = json.loads((VALIDATION / 'summary.json').read_text())
assert summary['current']['passed'] == 6 and not summary['source_drift']
assert json.loads((VALIDATION / 'dependency-check.json').read_text()) == dict(matched_current_and_derived=118, drift=[], unmapped=[])
plan = dict(remote_manifest=identity(VALIDATION / 'cleanup-mac.json'),
            retained_math=summary['retained_original_mlx_math'])
save(STAGE / 'cleanup-plan.json', plan)

backend = json.loads((STAGE / 'backend-source-identities.json').read_text())
changed = [entry['path'] for entry in backend] + [
    'src/graph_route_apple/native_region.cc',
    'tests/graph_route_apple/CMakeLists.txt',
    'tests/graph_route_apple/row_cache_projection_test.cc',
    'docs/architecture/compute-design.md',
    'docs/developer/current-work.md',
    'docs/user/batch-attention.md',
]
patch = []
for logical in changed:
    before = STAGE / 'before' / logical
    old = before.read_text(encoding='utf-8-sig') if before.is_file() else ''
    new = (ROOT / logical).read_text(encoding='utf-8-sig')
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                    fromfile='before/' + logical, tofile='current/' + logical))
(STAGE / 'changes.diff').write_text(''.join(patch), encoding='utf-8', newline='\n')
save(STAGE / 'changed-source-identities.json', [dict(logical=p, **identity(ROOT / p)) for p in changed])

result = dict(summary)
result.update(
    archive='apple-row-projection.zip',
    scope='Apple ordinary Graph projected ready row cache; original Invocation, no common Graph core change',
    responsibilities={
        'compute': 'Actual lowerer owns checked selection/status and cold geometry facts; padded Metal kernel source identity reused.',
        'graph_lowering': 'Retains fusion and maps original logical nodes and bank to actual selected boundary ports; unique reader/alias proof.',
        'adapter': 'Imports original buffer address, configures original slot, releases old input read owners after reuse gate.',
        'resource_episode': 'Original exact page guards and actual native retirement; descriptor addressability grants no payload access.'},
    coverage=[
        'FP8 D512 actual fused and required split Map/Decode/Cast/View/Sink/Neg; original independent FP64 budget 2e-5+2e-5|expected|',
        'FP4 D128 exact decoded rows, mask and Cast; no unsupported D512 Sink',
        'Two original slots, changed request grouping/page order in one slot, retained GraphOutput and separately exported original readonly MLX array',
        'Nonempty Q with true empty history while all bank page writers are held',
        'Extra bank reader and private physical-ID publication rejected in cold prepare',
        'Plain checked FP8/FP4 ready pages 1/3 while pages 0/2 remain writer-held; negative ID fails with no published result',
        'Fused prepare-only 2449473536B logical bank, no actual arena/bank or Invocation; configured MLX limit 128MiB; cold peak 3900296B'],
    limits=[
        'No Apple row-page pending, five-port paged scorer, complete-model precision or throughput acceptance.',
        'Bank read avoidance follows the actual kernel body and all-valid dependency; tests do not hardware-trace individual memory loads.',
        'Original Direct lifetime/zero-selection fixture not rerun this slice; Graph tests exercise the shared checked Map/Decode math.',
        '2.45GB old control fails total-byte native index guard, not OOM; derived 1.22GB old control allocates and exceeds the configured limit.',
        'The MLX configured memory limit was not a hard allocation cap in the old control. Different bank capacities are not a matched peak-speed benchmark.',
        'Original SDK/native host/metallib reused; MLX still performs original cold tracing/JIT. No zero-allocation or shader-build claim.',
        'Initial 002 harness failed while hashing its not-yet-created output before spawning clang; corrected 003 compiled successfully. Raw failure retained.'
    ],
    cleanup=dict(manifest='validation/cleanup-mac.json', files=4, bytes=37296697, retained_objects=10, execution='See stage cleanup-result.json after running root test.ps1'),
    broader_goal='active and incomplete; this archive only establishes the listed Apple ready row-cache slice')
save(DEST / 'apple-row-projection-results.json', result)

entries = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink()
    assert name not in entries
    entries[name] = path

for name in ['archive.py', 'backend-before-identities.json', 'backend-source-identities.json',
             'backend-source.diff', 'backend-summary.json', 'changed-source-identities.json',
             'changes.diff', 'cleanup-plan.json']:
    add(STAGE / name, name)
for path in (STAGE / 'before').rglob('*'):
    if path.is_file() and 'docs' not in path.relative_to(STAGE / 'before').parts:
        add(path, path.relative_to(STAGE).as_posix())
for path in VALIDATION.iterdir():
    if path.is_file() and path.suffix in {'.json', '.log', '.py', '.cc'}:
        add(path, path.relative_to(STAGE).as_posix())
for name in ['results', 'final-source']:
    for path in (VALIDATION / name).rglob('*'):
        if path.is_file():
            assert path.suffix in {'.json', '.log', '.py', '.cc', '.h', '.d'}
            add(path, path.relative_to(STAGE).as_posix())
for name in ['001-control-source', '006-final-test-source']:
    path = VALIDATION / name / 'tests/graph_route_apple/row_cache_projection_test.cc'
    add(path, path.relative_to(STAGE).as_posix())
add(ROOT / 'tests/graph_route_apple/CMakeLists.txt', 'current/tests/graph_route_apple/CMakeLists.txt')
add(ROOT / 'test.ps1', 'test.ps1')
add(STAGE.parent / 'apple-page-invocation/air.py', 'transport/air.py')
add(DEST / 'apple-row-projection-results.json', 'results.json')
manifest = [dict(entry=name, bytes=identity(path)['bytes'], sha256=identity(path)['sha256'])
            for name, path in sorted(entries.items())]
archive = DEST / 'apple-row-projection.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as package:
    for name, path in sorted(entries.items()):
        package.write(path, name)
    package.writestr('archive-content-identities.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for entry in manifest:
        data = package.read(entry['entry'])
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
receipt = dict(archive=identity(archive), entries=len(manifest) + 1,
               results=identity(DEST / 'apple-row-projection-results.json'),
               remote_cleanup_files=4, remote_cleanup_bytes=37296697,
               no_binaries_objects_or_sdk_in_archive=True)
save(STAGE / 'archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
