from pathlib import Path
import base64
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation'

def ssh(code,payload=None,timeout=120):
    encoded=base64.b64encode(code.encode()).decode()
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','kiro@172.22.10.198',
             'python3 -c "import base64;exec(base64.b64decode(\''+encoded+'\'))"']
    return subprocess.run(command,input=payload,capture_output=True,timeout=timeout)

def inspect():
    code=r'''from pathlib import Path
import json
p=Path('/Users/kiro/hyle-scratch/compute-unified')
print('\n'.join(x.name for x in p.iterdir() if x.is_dir() and ('architecture-refactor' in x.name or x.name=='a-cpu-apple')))
for name in ['architecture-refactor-20261018-apple-carrier-copy','architecture-refactor-20261018-apple-readonly-ports']:
 r=p/name
 print(name, 'objects',len(list(r.rglob('*.o'))))
 if (r/'commands.json').exists():
  rows=json.loads((r/'commands.json').read_text())
  print([(x['tag'],x['exit']) for x in rows[-8:]])
for name in ['architecture-refactor-20261019-native-inputs-apple','architecture-refactor-20261019-native-ready-pages-apple']:
 r=p/name
 print(name,'files',[x.name for x in r.iterdir() if x.is_file() and x.suffix in {'.json','.py'}])
 if (r/'commands.json').exists():
  rows=json.loads((r/'commands.json').read_text())
  print([(x['tag'],x['exit']) for x in rows[-6:]])
r=p/'architecture-refactor-20261018-apple-carrier-copy'
rows=json.loads((r/'native-tests-identities.json').read_text())
print('retained object names', [x['path'] for x in rows if x['path'].endswith('.o')])
'''
    result=ssh(code)
    (OUT/'air-inspect.stdout.log').write_bytes(result.stdout)
    (OUT/'air-inspect.stderr.log').write_bytes(result.stderr)
    print(result.stdout.decode(errors='replace'),result.stderr.decode(errors='replace'))
    raise SystemExit(result.returncode)

def stage(sources):
    files={'air_remote.py':OUT/'air_remote.py'}
    if (OUT/'host-sources.json').exists():files['host-sources.json']=OUT/'host-sources.json'
    seen=set()
    def add(path):
        path=path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:return
        seen.add(path);files[path.relative_to(ROOT).as_posix()]=path
        for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
            for candidate in [path.parent/name,ROOT/name,ROOT/'include'/name,ROOT/'src/compute'/name,
                    ROOT/'src/graph'/name,ROOT/'src/compute_route_apple'/name,
                    ROOT/'src/compute_provider_ggml'/name,ROOT/'src/compute_ggml_runtime'/name,
                    ROOT/'third_party/ds4_quantization'/name,
                    *[ROOT/'third_party'/part/name for part in
                      ['torchao_cpu','bitsandbytes_cpu','awq_cpu','compressed_tensors_cpu','mlx_cpu_quant']]]:
                if candidate.is_file():add(candidate);break
    for source in sources:add(ROOT/source)
    rows=[dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for name,p in sorted(files.items())]
    manifest=OUT/'staged-sources.json';manifest.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    files['staged-sources.json']=manifest
    stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for name,path in sorted(files.items()):archive.add(path,arcname=name)
    code=('from pathlib import Path;import io,sys,tarfile;r=Path('+repr(REMOTE)+');r.mkdir(exist_ok=True);'
          'a=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");'
          'assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in a.getmembers());'
          'a.extractall(r);print(r)')
    result=ssh(code,stream.getvalue())
    (OUT/'air-stage.stdout.log').write_bytes(result.stdout);(OUT/'air-stage.stderr.log').write_bytes(result.stderr)
    print(result.stdout.decode(errors='replace'),result.stderr.decode(errors='replace'),len(rows),'files',len(stream.getvalue()),'bytes')
    raise SystemExit(result.returncode)

def run(arguments):
    import shlex
    command=['ssh','kiro@172.22.10.198','python3 '+REMOTE+'/air_remote.py '+shlex.join(arguments)]
    with (OUT/'air-run.stdout.log').open('ab') as log:
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        for line in process.stdout:
            log.write(line);log.flush();print(line.decode(errors='replace'),end='',flush=True)
        code=process.wait()
    raise SystemExit(code)

def collect():
    code=('from pathlib import Path;import io,sys,tarfile;r=Path('+repr(REMOTE)+');b=io.BytesIO();'
          'a=tarfile.open(fileobj=b,mode="w:gz");'
          '[a.add(p,arcname=p.name) for p in r.iterdir() if p.is_file() and p.suffix in {".json",".log",".txt"}];'
          'a.close();sys.stdout.buffer.write(b.getvalue())')
    result=ssh(code)
    if result.returncode:raise SystemExit(result.stderr.decode(errors='replace'))
    target=OUT/'air-results';target.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(result.stdout),mode='r:gz') as archive:
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in archive.getmembers())
        archive.extractall(target)
    print('collected',len(result.stdout),'bytes')

if __name__=='__main__':
    action,*arguments=sys.argv[1:]
    {'inspect':lambda:inspect(),'stage':lambda:stage(arguments),'run':lambda:run(arguments),'collect':collect}[action]()
