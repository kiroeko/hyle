#pragma once
#include "hyle/compute/apple.h"
namespace hyle::compute::apple::detail {
Result<mlx::core::array> row_cache_indexer_scores(
    std::span<const mlx::core::array> inputs, mlx::core::Stream stream);
}
