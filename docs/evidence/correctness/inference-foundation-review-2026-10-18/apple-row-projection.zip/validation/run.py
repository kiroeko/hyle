from pathlib import Path
import base64, hashlib, importlib.util, json, re, sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
spec=importlib.util.spec_from_file_location('air',OUT.parents[1]/'apple-page-invocation/air.py')
air=importlib.util.module_from_spec(spec);spec.loader.exec_module(air)
REMOTE=air.REMOTE+'/apple-row-projection/validation'
BASE=OUT.parents[1]/'vulkan-row-pending/apple'
TEST='tests/graph_route_apple/row_cache_projection_test.cc'
PROBE='tests/graph_route_apple/row_cache_projection_1g_probe.cc'

def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

def identify(path):
    data=path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

REMOTE_RUN=r'''
from pathlib import Path
import hashlib,json,subprocess,sys,time
p=json.loads(sys.stdin.buffer.read());r=Path(p['root']);r.mkdir(parents=True,exist_ok=True)
def identity(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
tag=p['tag'];argv=p['argv'];row=dict(tag=tag,argv=argv,cwd=str(r),started=time.time(),exit=None)
if p.get('source'):row['source_before']=identity(p['source'])
row['inputs_before']=[identity(x) for x in argv if x.startswith('/') and x.endswith(('.o','.a','.dylib')) and Path(x).is_file() and x not in p.get('outputs',[])]
(r/(tag+'.command.json')).write_text(json.dumps(row,indent=2)+'\n')
with (r/(tag+'.stdout.log')).open('wb') as so,(r/(tag+'.stderr.log')).open('wb') as se:
 child=subprocess.Popen(argv,cwd=r,stdout=so,stderr=se);row['pid']=child.pid
 (r/'live.json').write_text(json.dumps(row,indent=2)+'\n');row['exit']=child.wait(timeout=55)
row.update(terminal=True,finished=time.time(),outputs=[identity(x) for x in p.get('outputs',[]) if Path(x).is_file()])
if p.get('source'):
 row['source_after']=identity(p['source']);assert row['source_before']==row['source_after']
if p.get('map') and row['exit']==0:
 text=Path(p['map']).read_text();section=text.split('# Object files:\n',1)[1].split('# Sections:',1)[0]
 row['map_owners']=[]
 for obj in [x for x in argv if x.endswith('.o')]:
  found=[x for x in section.splitlines() if x.endswith(obj)];assert len(found)==1,(obj,found)
  row['map_owners'].append(found[0])
if p.get('dependency') and row['exit']==0:
 raw=Path(p['dependency']).read_text().replace('\\\n',' ')
 paths={str(Path(x).resolve()) for x in raw.split(': ',1)[1].split() if Path(x).is_file()}
 row['dependencies']=[identity(x) for x in sorted(paths) if x.startswith(p['base']+'/') or x.startswith(str(r)+'/')]
(r/(tag+'.result.json')).write_text(json.dumps(row,indent=2)+'\n');(r/'live.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(dict(tag=tag,exit=row['exit'],seconds=row['finished']-row['started'],outputs=row['outputs'])));print((r/(tag+'.stdout.log')).read_text(errors='replace')[-14000:]);print((r/(tag+'.stderr.log')).read_text(errors='replace')[-10000:]);sys.exit(row['exit'])
'''

def call(tag,argv,**other):
    assert not (OUT/(tag+'.planned.json')).exists(),tag
    save(tag+'.planned.json',dict(argv=argv,**other))
    p=dict(root=REMOTE,base=air.REMOTE,tag=tag,argv=argv,**other)
    result=air.ssh(REMOTE_RUN,json.dumps(p).encode(),timeout=65)
    (OUT/(tag+'.transport.stdout.log')).write_bytes(result.stdout)
    (OUT/(tag+'.transport.stderr.log')).write_bytes(result.stderr)
    print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'))
    return result.returncode

def inspect():
    inputs=json.loads((BASE/'results/link-input-identities.json').read_text())
    math=json.loads((BASE/'results/retained-math.json').read_text())
    code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root']);r.mkdir(parents=True,exist_ok=True)
def check(row):
 q=Path(row['path']);data=q.read_bytes();actual=dict(path=str(q),bytes=len(data),sha256=hashlib.sha256(data).hexdigest());assert actual==row,(actual,row);return actual
rows=[check(x) for x in p['inputs']];math=[check(x) for x in p['math']]
link=r/'mlx.metallib';target=Path(math[0]['path'])
if link.is_symlink():assert link.resolve()==target.resolve()
else:assert not link.exists();link.symlink_to(target)
hardware={k:subprocess.check_output(v,text=True).strip() for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'system':['sw_vers'],'compiler':['/usr/bin/clang++','--version']}.items()}
out=dict(hardware=hardware,link_inputs=rows,math=math)
(r/'baseline-identities.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
'''
    result=air.ssh(code,json.dumps(dict(root=REMOTE,inputs=inputs,math=math)).encode(),timeout=30)
    (OUT/'000-inspect.stderr.log').write_bytes(result.stderr)
    assert result.returncode==0,result.stderr
    data=json.loads(result.stdout);save('000-baseline-identities.json',data)
    print(json.dumps(dict(hardware=data['hardware'],matched_inputs=len(data['link_inputs']),math=data['math'])))

def sync(tag,sources):
    files={}
    def add(path):
        path=path.resolve()
        if path in files or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:return
        files[path]=path.relative_to(ROOT).as_posix()
        for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
            candidates=[path.parent/name,ROOT/name,ROOT/'include'/name]
            candidates += [ROOT/folder/name for folder in ['src/graph','src/compute','src/compute_route_apple','src/compute_provider_ggml','src/compute_ggml_runtime','third_party/ds4_quantization','third_party/torchao_cpu','third_party/bitsandbytes_cpu','third_party/awq_cpu','third_party/compressed_tensors_cpu','third_party/mlx_cpu_quant']]
            for candidate in candidates:
                if candidate.is_file():add(candidate);break
    for source in sources:add(ROOT/source)
    rows=[dict(**identify(p),data=base64.b64encode(p.read_bytes()).decode()) for p in sorted(files)]
    save(tag+'-sources.json',[{k:v for k,v in row.items() if k!='data'} for row in rows])
    for source in sources:
        target=OUT/tag/source;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/source).read_bytes())
    code=r'''
from pathlib import Path
import base64,hashlib,json,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root']).resolve();r.mkdir(parents=True,exist_ok=True)
for row in p['files']:
 q=(r/row['path']).resolve();assert q.is_relative_to(r);b=base64.b64decode(row['data']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/(p['tag']+'-sources.json')).write_text(json.dumps([{k:v for k,v in row.items() if k!='data'} for row in p['files']],indent=2)+'\n');print(json.dumps(dict(files=len(p['files']),bytes=sum(x['bytes'] for x in p['files']))))
'''
    result=air.ssh(code,json.dumps(dict(root=REMOTE,tag=tag,files=rows)).encode(),timeout=30)
    (OUT/(tag+'.stdout.log')).write_bytes(result.stdout);(OUT/(tag+'.stderr.log')).write_bytes(result.stderr)
    print(result.stdout.decode());assert result.returncode==0,result.stderr

def compile(tag,source):
    if source in {TEST,PROBE}:
        argv=json.loads((OUT.parents[1]/'apple-f32-partials-runtime/validation/results/validation/012-final-test-compile.command.json').read_text())['argv']
    else:
        template='src/compute_route_apple/apple_row_cache.cc' if source=='src/compute_route_apple/apple_row_cache_paged.cc' else source
        code='from pathlib import Path;import json;r=Path('+repr(air.REMOTE)+');rows=json.loads((r/"commands.json").read_text());source='+repr(template)+';print(json.dumps(next(x["command"] for x in reversed(rows) if x.get("exit")==0 and x["tag"].endswith("-compile") and any(str(z).endswith("/"+source) for z in x["command"]))))'
        result=air.ssh(code,timeout=30);assert result.returncode==0,result.stderr;argv=json.loads(result.stdout)
        save(tag+'-recipe.json',dict(source=source,flags_source=template,reason='same actual compute_route_apple module' if template!=source else 'exact cached successful source command',cached_argv=argv))
    argv=argv.copy();old=argv[argv.index('-c')+1];argv[argv.index(old)]=REMOTE+'/'+source
    obj=REMOTE+'/'+tag+'-'+source.replace('/','--').replace('.cc','.o')
    argv[argv.index('-o')+1]=obj
    argv[1:1]=['-I'+REMOTE+'/include','-I'+REMOTE,'-I'+REMOTE+'/src/graph','-I'+REMOTE+'/src/compute','-I'+REMOTE+'/src/graph_route_apple','-I'+REMOTE+'/src/compute_route_apple']
    argv+=['-MMD','-MF',obj+'.d']
    status=call(tag,argv,source=REMOTE+'/'+source,dependency=obj+'.d',outputs=[obj,obj+'.d'])
    if status==0:
        registry=json.loads((OUT/'objects.json').read_text()) if (OUT/'objects.json').exists() else {}
        registry[source]=obj;save('objects.json',registry)
    return status

def link(tag,phase,test_source=TEST):
    argv=json.loads((BASE/'link-plan.json').read_text())['argv'].copy();registry=json.loads((OUT/'objects.json').read_text())
    old_main=next(x for x in argv if '/tests--compute_batch--pending_paged_receiver_native_consumer.o' in x)
    argv[argv.index(old_main)]=registry[test_source]
    if phase=='current':
        for source,obj in registry.items():
            if not source.startswith('src/'):continue
            suffix=source[4:].replace('/','--').replace('.cc','.o')
            old=[x for x in argv if x.endswith(suffix)]
            assert len(old)<=1,(source,old)
            if old:argv[argv.index(old[0])]=obj
            else:argv.insert(1,obj)
    image=REMOTE+'/'+phase+'-tests';map_path=image+'.map'
    argv[argv.index('-o')+1]=image
    argv=[('-Wl,-map,'+map_path) if x.startswith('-Wl,-map,') else x for x in argv]
    return call(tag,argv,map=map_path,outputs=[image,map_path])

def collect():
    code='from pathlib import Path;import base64,json;r=Path('+repr(REMOTE)+');print(json.dumps([dict(path=p.name,data=base64.b64encode(p.read_bytes()).decode()) for p in r.iterdir() if p.is_file() and p.suffix in {".json",".log",".d"}]))'
    result=air.ssh(code,timeout=30);assert result.returncode==0,result.stderr
    target=OUT/'results';target.mkdir(exist_ok=True)
    for row in json.loads(result.stdout):(target/row['path']).write_bytes(base64.b64decode(row['data']))
    print('collected',len(json.loads(result.stdout)))

if __name__=='__main__':
    action,*args=sys.argv[1:];status=0
    if action=='inspect':inspect()
    elif action=='sync':sync(args[0],args[1:])
    elif action=='compile':status=compile(*args)
    elif action=='link':status=link(*args)
    elif action=='run':
        tag,phase,*filters=args;result=REMOTE+'/'+tag+'-tests.json'
        selected=filters[0] if filters else 'AppleProjectedRowGraph.*'
        status=call(tag,[REMOTE+'/'+phase+'-tests','--gtest_filter='+selected,'--gtest_output=json:'+result],outputs=[result])
    elif action=='collect':collect()
    else:raise ValueError(action)
    raise SystemExit(status)
