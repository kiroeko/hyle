from pathlib import Path
import importlib.util, json, shutil, sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('run',OUT/'run.py')
run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
TAGS=['003-control-test','007-final-test','012-context','013-mature','014-row',
      '015-row-paged','016-operations','017-lowering','018-region','022-probe-test']

code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root'])
def identity(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
def save(name,data):(r/name).write_text(json.dumps(data,indent=2)+'\n')
compiles=[];retained=[]
for tag in p['tags']:
 row=json.loads((r/(tag+'.result.json')).read_text());assert row['exit']==0
 for obj in row['outputs']:
  assert identity(obj['path'])==obj
  if obj['path'].endswith('.o'):retained.append(obj)
 compiles.append(row)
assert len(retained)==10
links={tag:json.loads((r/(tag+'.result.json')).read_text()) for tag in ['004-control-link','008-cold-control-link','019-current-link','023-probe-control-link']}
for tag in ['019-current-link','023-probe-control-link']:
 for row in links[tag]['outputs']:assert identity(row['path'])==row
current=links['019-current-link'];section=(r/'current-tests.map').read_text().split('# Object files:\n',1)[1].split('# Sections:',1)[0]
selected=[]
for obj in [x for row in compiles if row['tag'] not in ['003-control-test','022-probe-test'] for x in row['outputs'] if x['path'].endswith('.o')]:
 found=[line for line in section.splitlines() if line.endswith(obj['path'])];assert len(found)==1,(obj,found)
 selected.append(dict(identity=obj,map_entry=found[0]))
for stem in ['apple_context.cc.o','apple_mature_float.cc.o','apple_row_cache.cc.o','apple_row_cache_paged.cc.o','apple_operations.cc.o','apple_lowering.cc.o','native_region.cc.o']:
 assert not any(stem in line and '.a(' in line for line in section.splitlines()),stem
save('selected-current-owners.json',selected)
for tag,row in links.items():
 for item in row['inputs_before']:assert identity(item['path'])==item
save('final-link-input-identities.json',current['inputs_before'])
math=[identity(x['path']) for x in p['math']];assert math==p['math']
assert (r/'mlx.metallib').is_symlink() and (r/'mlx.metallib').resolve()==Path(math[0]['path']).resolve()
cleanup=dict(host='kiro@172.22.10.198',root=str(r),files=links['023-probe-control-link']['outputs']+current['outputs'],retain=retained)
assert len({x['path'] for x in cleanup['files']})==4
assert not {x['path'] for x in cleanup['files']} & {x['path'] for x in retained}
save('cleanup-mac.json',cleanup)
live=json.loads((r/'live.json').read_text());assert live['terminal'] and live['tag']=='024-probe-control-run' and live['exit']==1
ps=subprocess.run(['ps','-p',str(live['pid']),'-o','command='],capture_output=True,text=True)
assert ps.returncode!=0 or str(r/'control-tests') not in ps.stdout
final=dict(current_exit=json.loads((r/'020-current-run.result.json').read_text())['exit'],live_process=False,
 retained_stage_objects=len(retained),selected_current_owners=len(selected),current_link_inputs=len(current['inputs_before']),
 cleanup_files=len(cleanup['files']),cleanup_bytes=sum(x['bytes'] for x in cleanup['files']),math=math)
assert final['current_exit']==0
save('final-verification.json',final);print(json.dumps(final))
'''
math=json.loads((OUT/'000-baseline-identities.json').read_text())['math']
result=run.air.ssh(code,json.dumps(dict(root=run.REMOTE,tags=TAGS,math=math)).encode(),timeout=40)
(OUT/'025-verify.stdout.log').write_bytes(result.stdout);(OUT/'025-verify.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0
run.collect()

def read(name):return json.loads((OUT/'results'/name).read_text())
snapshots={}
for manifest in ['006-final-test-source-sources.json','011-final-product-source-sources.json']:
 for row in json.loads((OUT/manifest).read_text()):snapshots[row['path']]=row
for logical,row in snapshots.items():
 assert run.identify(run.ROOT/logical)==row,(logical,'current source drift')
 target=OUT/'final-source'/logical;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(run.ROOT/logical,target)
run.save('final-source-identities.json',list(snapshots.values()))
deps={};unmapped=[]
for tag in [x for x in TAGS if x!='003-control-test']:
 for row in read(tag+'.result.json')['dependencies']:
  path=row['path'];logical=None
  if path.startswith(run.REMOTE+'/'):logical=path[len(run.REMOTE)+1:]
  elif path.startswith(run.air.REMOTE+'/'):logical=path[len(run.air.REMOTE)+1:]
  if logical==run.PROBE:
   actual=run.identify(OUT/'old-1g-probe.cc')
  elif logical and (run.ROOT/logical).is_file():actual=run.identify(run.ROOT/logical)
  else:unmapped.append(row);continue
  assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),(tag,row,actual)
  deps[(logical,row['sha256'])]=dict(logical=logical,bytes=row['bytes'],sha256=row['sha256'])
run.save('dependency-check.json',dict(matched_current_and_derived=len(deps),drift=[],unmapped=unmapped))
shutil.copyfile(OUT/'results/cleanup-mac.json',OUT/'cleanup-mac.json')

def test_properties(name):
 for suite in read(name)['testsuites']:
  for test in suite['testsuite']:
   if test['name']=='FusedColdPreparationDoesNotAllocateTheLogicalBank':return test
current=test_properties('020-current-run-tests.json');old=test_properties('024-probe-control-run-tests.json')
verified=read('final-verification.json')
summary=dict(status='passed_current_6_tests',hardware=json.loads((OUT/'000-baseline-identities.json').read_text())['hardware'],
 current=dict(compile_products=TAGS[2:-1],compile_test='007-final-test',link='019-current-link',run='020-current-run',tests=6,passed=6,failed=0,
 logical_bank_bytes=int(current['logical_bank_bytes']),cold_peak_bytes=int(current['cold_peak_bytes']),configured_native_memory_limit=int(current['native_memory_limit'])),
 controls=[dict(run='005-control-run',source='001-control-source',tests=4,passed=1,failed=3,reason='selected region has no logical access inspector'),
 dict(run='009-cold-control-run',source='006-final-test-source',tests=1,passed=0,failed=1,logical_bank_bytes=2449473536,reason='Apple FP8 input exceeds native index range; no OOM claim'),
 dict(run='024-probe-control-run',source='old-1g-probe.cc',tests=1,passed=0,failed=1,logical_bank_bytes=int(old['logical_bank_bytes']),cold_peak_bytes=int(old['cold_peak_bytes']),configured_native_memory_limit=int(old['native_memory_limit']),reason='cold peak exceeded configured limit; native allocation was not rejected as OOM')],
 no_performance_claim=True,no_sdk_air_or_metallib_build=True,retained_original_mlx_math=math,
 fresh_product_host_tus=7,additional_new_explicit_owner='apple_row_cache_paged.cc',
 source_count=len(snapshots),source_drift=[],dependency_check='dependency-check.json',
 source_snapshots='final-source/',cleanup=dict(manifest='cleanup-mac.json',files=verified['cleanup_files'],bytes=verified['cleanup_bytes']),
 retained_stage_objects=verified['retained_stage_objects'],live_process=False,
 not_claimed=['Apple projected row pending permission','FP8/FP4 codec changes','timing or paired peak speedup','native set_memory_limit as a hard allocation cap'])
run.save('summary.json',summary)
run.save('receipt.json',dict(summary=run.identify(OUT/'summary.json'),cleanup=run.identify(OUT/'cleanup-mac.json'),
 sources=run.identify(OUT/'final-source-identities.json'),dependencies=run.identify(OUT/'dependency-check.json')))
print(json.dumps(summary,indent=2))
