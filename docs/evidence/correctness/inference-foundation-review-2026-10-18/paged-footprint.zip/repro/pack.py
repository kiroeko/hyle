from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
product=['include/hyle/compute/detail/batch_provider.h','src/compute_batch/batch_layout.cc','src/compute_batch/paged_arena.cc']
tests=['tests/compute_batch/batch_layout_test.cc','tests/compute_batch/paged_arena_test.cc']
header=(ROOT/product[0]).read_text()
added='''  // Lazy sorted unique physical page IDs. The immutable span borrows the
  // version; it carries no page permissions and never changes after success.
  HYLE_COMPUTE_BATCH_API static Result<std::span<const std::int32_t>> page_footprint(const BatchLayoutVersion&) noexcept;
'''
assert header.count(added)==1
(OUT/'provider.before.h').write_text(header.replace(added,''))
before={product[0]:(OUT/'provider.before.h').read_text(),product[1]:(OUT/'layout.before.cc').read_text(),product[2]:(OUT/'arena.before.cc').read_text()}
for path in tests:before[path]=subprocess.check_output(['git','show','HEAD:'+path],cwd=ROOT).decode()
diff=''.join(''.join(difflib.unified_diff(before[p].splitlines(True),(ROOT/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p))for p in product+tests)
(OUT/'product-tests.diff').write_text(diff)
summary='''Paged layout immutable footprint reuse -- 2026-10-18

Change: lazy sorted/unique page-ID footprint in the existing private
BatchLayoutData, under its existing export_lock. It uses the original metadata
allocator (including ResourceBudget), exact active reference capacity, and is
never mutated after success. A detail-only borrowed span requires a live version.
No page permission is cached. Every PagedArena::read still validates original
ready pages and initialized row prefixes and independently allocates/owns its
frame and ReadLease guards. No public object layout or native SDK change.
Existing MLA additions are preserved in the source snapshot; scoped diff uses
the exact source captured immediately before this change, rather than HEAD,
for the two already-dirty product TUs and the detail header.

Actual allocator count probe: requests=1, Q=1, 32 permuted physical page IDs,
page_size=16, two independent K/V arenas, all original published page guards.
                                               before  after
first K/V read pair metadata allocations             6      5
8 warm same-version K/V pairs                       48     32
8 changed-tail versions, K/V reads only              48     40
8 changed-tail versions, creation metadata calls     64     64
An active immutable layout payload is 180 bytes. The original layout buffer
creation/copy remains; the count uses the supplied metadata allocator, and
does not count system_resource's own payload allocation as metadata calls.
The sorted required-ID copy/sort changes from twice per K/V pair to once per
new layout's first use, and zero for later reads of that same version.
Guard sorting remains once per read. A cached layout retains 4*active_refs
bytes of vector capacity (128 here), plus its private vector member, until
the layout dies. It never scales to max_page_refs merely because capacity is
large. pending_read's row-aware temporary footprint is unchanged.

Validation: MSVC 14.50.35717, /O2 /MD /W4 /WX, Windows x64 i9-13900K.
Fresh host TUs: batch_layout.cc, paged_arena.cc, two complete canonical test
TUs. Reused current metadata/F1 host objects and existing CPU base libraries;
no configure, full build, native SDK rebuild, model or GPU execution.
49 canonical tests in BatchLayout/PagedArena/PagedAdmission all PASS.
New cases cover exact active-size allocation, quota/ResourceBudget pressure
and retry, release with version, empty layouts, concurrent first cache/export,
old immutable versions, repeated shared references, and absence of permission
retention. Existing native-use, failed/cancelled write, F2 clone/append/F4
publish, reader hold, original writer and close tests were run unchanged.
Before/after probes both succeed; allocation counts are not a latency claim.

Additional actual common BatchInvocation metadata count (unchanged product):
The existing batch-only CPU mock provider reuses every update plan; actual
common F2 preparation/upload is used, no native kernel or model is run.
                                  copied/staged bytes  host waits
cold prepare                                    168          2
same immutable version update                      0          0
new version, identical host values                 4          1
new version, one tail append                      24          1
The new version's generation changes even if arrays match. Tail append also
changes kv_rows in the header: one 20-byte header interval plus 4 tail bytes.
Source boundary: unshared common prepare still scans all 45 active 32-bit
words for this shape, even same-version reuse (batch_execution.cc:346-357).
The changed mirror upload still waits before retaking/publishing its original
writer (381-391); skipping that wait needs a real ordered lifetime design,
not deleting the wait. No such change is included.
The separate native materialized controller already avoids H2D when page IDs
do not change, including tail-only updates. Its equal-page check at
materialized_native_controller.h:142 is followed by the same-table delta
scan at 145 (32+32 page comparisons for this shape). This remains source-only
follow-up; controller/MLA ownership was not touched.

Reproduction: python .scratch/inference-lifecycle-2026-10-18/paged-footprint/run.py
run.py records exact compiler/linker commands and exit codes in commands.json.
Cached library paths/SHA256 are recorded in identities.json. Scoped source
diff, before source, canonical test sources, tiny count probes and logs are
included. No obj/exe/SDK in this archive.
'''
(OUT/'summary.txt').write_text(summary)
files={}
for path in product+tests+['tests/compute_batch/allocation_fault_fixture.h','tests/compute_batch/workspace_test.cc','src/compute_batch/batch_execution.cc']:
    files['source/'+path]=ROOT/path
for p in OUT.iterdir():
    if p.suffix in ['.py','.cc','.h','.json','.log','.diff','.txt']:files['repro/'+p.name]=p
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
    for name,path in sorted(files.items()):z.write(path,name)
print(json.dumps(dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(files))))
