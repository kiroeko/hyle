#include <hyle/compute/paged_arena.h>
#include <hyle/compute/detail/batch_provider.h>
#include "tests/compute_batch/allocation_fault_fixture.h"
#include <array>
#include <cstdio>

namespace c=hyle::compute;
int main(){
  hyle_f5_fault_fixture::Allocator layout_alloc,arena_alloc;
  c::BatchCapacity cap{.max_requests=1,.max_query_rows=1,.max_kv_rows=512,
      .max_pages=40,.max_page_refs=32,.query_heads=2,.kv_heads=2,
      .qk_head_dim=64,.value_head_dim=64,.page_size=16};
  auto schema=c::BatchSchema::create(cap,{.allocator=layout_alloc.ref()}).value();
  auto keys=c::PagedArena::create(schema,c::BatchCacheRole::kKey,hyle::mem::system_resource(),{.max_backing_bytes=1u<<20,.allocator=arena_alloc.ref()}).value();
  auto values=c::PagedArena::create(schema,c::BatchCacheRole::kValue,hyle::mem::system_resource(),{.max_backing_bytes=1u<<20,.allocator=arena_alloc.ref()}).value();
  std::array<c::ReadLease,32> k,v;
  std::array<std::int32_t,32> ids;const std::array<std::int32_t,2> q{0,1},kv{0,32};std::array<std::int32_t,1> tail{1};
  for(unsigned i=0;i<32;++i){ids[i]=std::int32_t((i*7)%32);
    for(auto pair:{std::pair{&keys,&k},std::pair{&values,&v}}){auto writer=pair.first->acquire(i).value();
      if(!writer.lease().view()->fill(std::byte(i+1)).ok())return 2;
      (*pair.second)[i]=writer.publish(16).value();}}
  const auto one=[&](const c::BatchLayoutVersion&layout){
    auto kr=keys.read(layout,k),vr=values.read(layout,v);if(!kr||!vr)return false;
    return kr->page_count()==32 && vr->page_count()==32 && kr->layout()==layout && vr->layout()==layout;};
  const auto report=[&](const char*label,std::size_t la,std::size_t aa,unsigned pairs){
    std::printf("%s pairs=%u layout_metadata_allocations=%zu arena_metadata_allocations=%zu total=%zu\n",
      label,pairs,layout_alloc.attempts-la,arena_alloc.attempts-aa,
      layout_alloc.attempts-la+arena_alloc.attempts-aa);};
  auto layout=schema.version({q,kv,ids,tail}).value();
  auto la=layout_alloc.attempts,aa=arena_alloc.attempts;if(!one(layout))return 3;report("first_same_version_pair",la,aa,1);
  la=layout_alloc.attempts;aa=arena_alloc.attempts;
  for(unsigned i=0;i<8;++i)if(!one(layout))return 4;
  report("warm_same_version",la,aa,8);
  std::size_t version_allocations=0,read_layout_allocations=0,read_arena_allocations=0;
  for(unsigned i=0;i<8;++i){tail[0]=std::int32_t(i+2);la=layout_alloc.attempts;
    auto next=schema.version({q,kv,ids,tail}).value();version_allocations+=layout_alloc.attempts-la;
    la=layout_alloc.attempts;aa=arena_alloc.attempts;if(!one(next))return 5;
    read_layout_allocations+=layout_alloc.attempts-la;read_arena_allocations+=arena_alloc.attempts-aa;}
  std::printf("changed_tail_versions pairs=8 version_metadata_allocations=%zu read_layout_metadata_allocations=%zu read_arena_metadata_allocations=%zu read_total=%zu\n",
      version_allocations,read_layout_allocations,read_arena_allocations,read_layout_allocations+read_arena_allocations);
  std::size_t active=0;for(const auto&segment:c::detail::BatchLayoutAccess::segments(layout))active+=segment.bytes.size();
  std::printf("geometry requests=1 query_rows=1 refs=32 physical_order=permuted page_size=16 active_snapshot_bytes=%zu immutable_version_payload_is_copied_once_per_new_version\n",active);
}
