from pathlib import Path
import importlib.util, json, subprocess, time, hashlib
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cached_cpu',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(cpu)
flags=cpu.hyle_flags(dict(cpu.PINS['mixed'],folder=Path('mixed')))+['/I'+str(ROOT)]
records=[]
def run(tag,command):
    command=list(map(str,command));start=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=cpu.ENV,capture_output=True,timeout=120)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-1200:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
def compile(source,name):
    obj=OUT/(name+'.obj');run(name+'-compile',[cpu.CL,*flags,source,'/Fo'+str(obj)]);return obj
libs=[cpu.BASE/'bin/hyle_compute_state.lib',*cpu.common_libs(),cpu.BASE/'lib/gtest.lib',cpu.BASE/'lib/gtest_main.lib']
probe=compile(OUT/'decode_count.cc','count')
objects={}
for mode in ['before','after']:
    layout=compile(OUT/'layout.before.cc' if mode=='before' else ROOT/'src/compute_batch/batch_layout.cc','layout-'+mode)
    arena=compile(OUT/'arena.before.cc' if mode=='before' else ROOT/'src/compute_batch/paged_arena.cc','arena-'+mode)
    objects[mode]=[layout,arena]
    exe=OUT/('count-'+mode+'.exe')
    run(mode+'-count-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),probe,layout,arena,*libs,*cpu.SYSTEM])
    run(mode+'-count',[exe])
tests=[compile(ROOT/'tests/compute_batch/batch_layout_test.cc','layout-tests'),compile(ROOT/'tests/compute_batch/paged_arena_test.cc','arena-tests')]
# State/F1 objects are current from the already validated metadata closure;
# the old SDK static libraries only supply the otherwise unchanged base.
leases=ROOT/'.scratch/inference-lifecycle-2026-10-18/state-metadata/leases.obj'
state=ROOT/'.scratch/inference-lifecycle-2026-10-18/state-metadata/state.obj'
exe=OUT/'tests.exe'
run('tests-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),*tests,*objects['after'],leases,state,*libs,*cpu.SYSTEM])
run('tests',[exe])
execution=compile(ROOT/'src/compute_batch/batch_execution.cc','execution')
metadata=compile(OUT/'metadata_count.cc','metadata-count')
exe=OUT/'metadata-count.exe'
run('metadata-count-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),metadata,execution,*objects['after'],leases,state,*libs,*cpu.SYSTEM])
run('metadata-count',[exe])
paths=[ROOT/p for p in ['src/compute_batch/batch_layout.cc','src/compute_batch/paged_arena.cc','include/hyle/compute/detail/batch_provider.h','tests/compute_batch/batch_layout_test.cc','tests/compute_batch/paged_arena_test.cc']]+libs+[leases,state]
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
