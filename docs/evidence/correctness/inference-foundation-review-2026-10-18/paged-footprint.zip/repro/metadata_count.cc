// Reuse the existing batch-only mock provider; the measured path below is the
// actual common BatchInvocation metadata preparation/F2 upload implementation.
#include "tests/compute_batch/workspace_test.cc"
int main(){
  Mock mock;mock.batch.uses_caller_workspace=false;
  mock.batch.update=[](void*,const c::BatchLayoutVersion&,c::BatchPlanReport*)noexcept->hyle::Result<bool>{return true;};
  c::BatchCapacity cap{.max_requests=1,.max_query_rows=1,.max_kv_rows=512,
      .max_pages=40,.max_page_refs=32,.query_heads=2,.kv_heads=2,
      .qk_head_dim=64,.value_head_dim=64,.page_size=16};
  auto schema=c::BatchSchema::create(cap).value();
  auto context=c::Context::create(c::cpu::device(),mock.provider()).value();auto queue=context.create_queue().value();
  auto program=c::BatchProgram::prepare(context,schema,{.resource=m::system_resource(),.host_workspace=m::system_resource(),
      .max_float_workspace_bytes=4096,.max_int_workspace_bytes=4096}).value();
  auto slot=c::BatchInvocation::create(program,queue).value();
  const std::array<std::int32_t,2> q{0,1},kv{0,32};std::array<std::int32_t,32> pages;
  for(unsigned i=0;i<32;++i)pages[i]=std::int32_t((i*7)%32);
  std::array<std::int32_t,1> tail{1};auto first=schema.version({q,kv,pages,tail}).value();
  const auto one=[&](const char*label,const c::BatchLayoutVersion&layout,bool update){
    auto ready=update?slot.update_batch(layout):slot.prepare_batch(layout);
    if(!ready){std::fprintf(stderr,"%s: %.*s\n",label,int(ready.error().message().size()),ready.error().message().data());return false;}
    const auto report=slot.report();
    std::printf("%s copied_metadata_bytes=%zu staging_bytes=%zu host_waits=%u reused_native_plan=%u\n",
        label,report.metadata_upload.logical_bytes,report.metadata_staging_bytes,report.host_waits,unsigned(report.reused_native_plan));
    return true;};
  if(!one("cold_prepare",first,false))return 2;
  if(!one("same_version_update",first,true))return 3;
  auto same_values=schema.version({q,kv,pages,tail}).value();
  if(!one("new_version_identical_values",same_values,true))return 4;
  tail[0]=2;auto append=schema.version({q,kv,pages,tail}).value();
  if(!one("new_version_tail_append",append,true))return 5;
  std::printf("native_plans=%u native_runs=%u mock_update_reuses_plan=1 no_gpu_timing_claim\n",mock.plans,mock.runs);
}
