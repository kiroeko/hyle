"""Freeze this bounded validation's text evidence; no binaries or cleanup."""
from pathlib import Path
import hashlib
import json
import zipfile
import zlib

ROOT=Path(__file__).resolve().parents[3]
STAGE=Path(__file__).resolve().parent
TARGET=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/linux-current-graph.zip'
ALLOWED={'.json','.py','.log','.txt','.h','.cc','.cpp','.cu','.c','.cuh','.s','.cmake','.diff'}
EXCLUDED={'archive-receipt.json','archive-manifest.json'}
FORBIDDEN={'.o','.obj','.a','.lib','.so','.dll','.exe','.map','.exp','.pdb','.ilk','.pyc','.zip','.tar','.gz'}
MAGIC=(b'\x7fELF',b'MZ',b'!<arch>\n',b'PK\x03\x04',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf')

def sha(data):return hashlib.sha256(data).hexdigest()
def payload(path):
    data=path.read_bytes()
    assert not any(data.startswith(m) for m in MAGIC),path
    assert b'\0' not in data,path
    data.decode('utf-8-sig')
    return data

def main():
    assert not TARGET.exists(),'Do not overwrite prior evidence archive'
    summary=json.loads((STAGE/'summary.json').read_text())
    assert summary['status']=='passed' and summary['run']['exit_code']==0
    assert summary['retained_objects']==190 and not summary['canonical_drift']
    deps=json.loads((STAGE/'dependency-check.json').read_text())
    assert not deps['old_hyle_sdk_headers'] and not deps['canonical_drift']
    selected=json.loads((STAGE/'selected-owners.json').read_text())
    assert not selected['prohibited_old_hyle_host_members'] and not selected['old_allocator_member_selected']
    content={}
    for path in sorted(STAGE.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.name in EXCLUDED:
            continue
        if path.suffix.lower() not in ALLOWED:
            assert path.suffix.lower() in FORBIDDEN,path
            continue
        name=path.relative_to(STAGE).as_posix()
        assert path.suffix.lower() not in FORBIDDEN and not any(p in ('SDK','objects','bin') for p in Path(name).parts)
        content[name]=payload(path)
    provenance={
        'linux-graph-inventory':['summary.json','recipes.json','cached-libraries.json'],
        'linux-native-abi-review':['review.json','actual-symbols.stdout.json','cuda-source.stdout.json',
            'ninja-native.stdout.json','native-deps.stdout.json','nine-cu-recipes.json',
            'f993-cpu-composition-evidence.json','cpu-avx2-sixteen-recipes.json',
            'cpu-program-original-link.json','index-guard-symbols.json']}
    for folder,names in provenance.items():
        for name in names:
            path=STAGE.parent/folder/name
            if path.exists():
                content['provenance/'+folder+'/'+name]=payload(path)
    entries=[dict(path=name,bytes=len(data),sha256=sha(data),crc32=f'{zlib.crc32(data)&0xffffffff:08x}')
             for name,data in sorted(content.items())]
    manifest=dict(scope='Current Linux default CPU+CUDA ordinary Graph finite-family validation. Text only; no SDK, objects, library/image/map, model or weights.',
        self_hash='Manifest excludes its own recursive identity; archive receipt records its SHA256.',
        result=summary['run'],retained_object_count=190,entries=entries)
    manifest_data=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode()
    (STAGE/'archive-manifest.json').write_bytes(manifest_data)
    TARGET.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(TARGET,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(content.items()):
            archive.writestr(name,data)
        archive.writestr('manifest.json',manifest_data)
    with zipfile.ZipFile(TARGET) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist())==len(set(archive.namelist()))==len(entries)+1
        for row in entries:
            data=archive.read(row['path'])
            assert len(data)==row['bytes'] and sha(data)==row['sha256']
            assert f'{zlib.crc32(data)&0xffffffff:08x}'==row['crc32']
        assert archive.read('manifest.json')==manifest_data
    receipt=dict(path=str(TARGET.resolve()),bytes=TARGET.stat().st_size,sha256=sha(TARGET.read_bytes()),
        payload_entries=len(entries),zip_entries=len(entries)+1,payload_bytes=sum(r['bytes'] for r in entries),
        manifest_sha256=sha(manifest_data),per_entry_sha256_checked=True,per_entry_crc32_checked=True,
        zip_testzip_passed=True,no_binary_sdk_objects_images_maps_or_nested_archives=True,
        actual_run=summary['run'],retained_objects=190,cleanup_files=summary['cleanup'])
    (STAGE/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
