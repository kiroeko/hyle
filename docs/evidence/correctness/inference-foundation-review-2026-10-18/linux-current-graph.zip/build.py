#!/usr/bin/env python3
"""Explicit current Hyle host overlay; never invokes an SDK build or cache cleanup."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time

REPO = Path('/mnt/c/public/project-hyle/hyle')
LOCAL = REPO / '.scratch/architecture-refactor-2026-10-18/linux-current-graph'
BASE = Path('/root/hyle-scratch/compute-unified')
ROOT = BASE / 'linux-current-graph'
SOURCE = ROOT / 'source'
SDK = BASE / 'l-cpu-cuda/selected-graph/static-sdk-relocated'
GGML = BASE / 'l-cuda/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-f99368c68335266b'
TORCH = Path('/root/.cache/hyle/dependencies/v1/sdks/torch-cpu/Linux-8dea5bcfed4b53ca0f6852517bea4b4d1f3ff1cc0c21da662e834d34af1ec824/libtorch')
TORCH_CUDA = Path('/root/.cache/hyle/dependencies/v1/sdks/torch-cuda-leaf/Linux-02c7258e917f3043c978b53acf6f02b818db0d0d85db0e58ae578af333b9b4e2-fab2a30375b0b92c/torch')
CUDA = Path('/usr/local/cuda-13.3/targets/x86_64-linux')

def digest(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def save(name, value):
    data = json.dumps(value, indent=2, ensure_ascii=False) + '\n'
    (ROOT / name).parent.mkdir(parents=True, exist_ok=True)
    (ROOT / name).write_text(data)
    (LOCAL / name).parent.mkdir(parents=True, exist_ok=True)
    (LOCAL / name).write_text(data)

def prepare():
    ROOT.mkdir(parents=True, exist_ok=True)
    initial = json.loads((LOCAL / 'closure-initial.json').read_text())
    rows = [r for r in initial['host_sources'] if r['source'] != 'src/container/bitset_ops_neon.cc']
    paths = set(p.relative_to(REPO).as_posix() for p in (REPO / 'include/hyle').rglob('*') if p.is_file())
    for module in initial['modules']:
        folder = REPO / 'src' / module
        if folder.is_dir():
            paths.update(p.relative_to(REPO).as_posix() for p in folder.rglob('*.h'))
            if (folder / 'CMakeLists.txt').exists():
                paths.add(f'src/{module}/CMakeLists.txt')
    paths.update(r['source'] for r in rows)
    asm = [f'third_party/fcontext/asm/{k}_x86_64_sysv_elf_gas.S' for k in ('jump', 'make', 'ontop')]
    paths.update(asm)
    paths.update(('cmake/HyleComponents.cmake', 'cmake/HyleWarnings.cmake'))
    identities = []
    for rel in sorted(paths):
        src, dst = REPO / rel, SOURCE / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        data = src.read_bytes()
        if dst.exists() and dst.read_bytes() != data:
            raise RuntimeError('frozen snapshot would change: ' + rel)
        dst.write_bytes(data)
        identities.append(dict(relative=rel, **digest(src)))
    save('source-identities.json', identities)
    common = ['-O3', '-DNDEBUG', '-std=c++23', '-Wall', '-Wextra', '-Wpedantic', '-Werror',
              '-fPIC', '-fvisibility=hidden', '-fvisibility-inlines-hidden', '-pthread',
              '-DHYLE_STATIC', '-DHYLE_COMPUTE_CPU=1', '-DHYLE_COMPUTE_CUDA=1',
              '-DHYLE_COMPUTE_FLASHINFER=1', '-DHYLE_COMPUTE_GGML_CPU=1',
              '-DHYLE_COMPUTE_TORCH_CPU=1', '-DHYLE_COMPUTE_TORCH_CUDA=1',
              '-DHYLE_COMPUTE_ONEDNN=1', '-DHYLE_GRAPH_ONEDNN=1',
              '-DHYLE_GGML_CPU_IQ1_EXTENSIONS=1', '-DHYLE_GGML_CUDA_IQ1_EXTENSIONS=1']
    includes = [SOURCE / 'include', SOURCE, GGML / 'include', GGML / 'src', GGML / 'src/ggml-cpu', REPO]
    includes.extend(SOURCE / 'src' / m for m in initial['modules'])
    for name in ('mimalloc/include', 'ds4_quantization', 'torchao_cpu', 'bitsandbytes_cpu',
                 'awq_cpu', 'compressed_tensors_cpu', 'mlx_cpu_quant', 'bitsandbytes_cuda',
                 'awq_cuda', 'compressed_tensors_cuda', 'mlx_cuda_quant', 'random123_counter',
                 'xxhash', 'wyhash', 'sglang_activation', 'deepseek_fp8', 'deepseek_quantization'):
        includes.append(REPO / 'third_party' / name)
    for p in includes:
        common.extend(('-I', str(p)))
    for p in (TORCH / 'include', TORCH / 'include/torch/csrc/api/include', TORCH_CUDA / 'include',
              CUDA / 'include', SDK / 'include'):
        if not p.exists():
            raise RuntimeError('missing cached include: ' + str(p))
        common.extend(('-isystem', str(p)))
    plan = []
    for row in rows:
        rel, module = row['source'], row['module']
        obj = ROOT / 'objects' / (rel.replace('/', '--') + '.o')
        flags = common.copy()
        flags.append('-DHYLE_' + module.upper() + '_BUILD')
        if module == 'mem':
            flags.append('-DHYLE_USE_MIMALLOC')
        if rel.endswith('hash_xxh3_avx2.cc'):
            flags.extend(('-mavx2',))
        if module == 'compute_ggml_runtime' and rel.endswith('cpu_program.cc'):
            flags.extend(('-DHYLE_GGML_CPU_AVX2_PROGRAM=1',
                          '-DHYLE_GGML_CPU_PROGRAM_LIBRARY="libhyle_ggml_cpu_avx2_linux_current.so"'))
        if module == 'compute_provider_ggml':
            flags.append('-DHYLE_GGML_CPU_PROVIDER_VERSION="456172ec+hyle-resource-iq1-f99368c68335266b+current-interface-overlay"')
        if module == 'compute_provider_ggml_cuda':
            flags.append('-DHYLE_GGML_CUDA_PROVIDER_VERSION="456172ec+iq1-46cbf0e9-resource-f99368c68335266b+current-interface-overlay"')
        cmd = ['/usr/bin/g++-14', *flags, '-MMD', '-MF', str(obj) + '.d', '-c', str(SOURCE / rel), '-o', str(obj)]
        plan.append(dict(**row, object=str(obj), command=cmd))
    for rel in asm:
        obj = ROOT / 'objects' / (rel.replace('/', '--') + '.o')
        plan.append(dict(module='sched', source=rel, object=str(obj), command=['/usr/bin/gcc-14', '-fPIC', '-c', str(SOURCE / rel), '-o', str(obj)]))
    save('compile-plan.json', dict(provenance=['current module CMakeLists', 'cmake/HyleWarnings.cmake',
         'linux-graph-inventory/recipes.json l-cpu-cuda/static-consumer Release flags'],
         scope='Current Hyle host only. No CMake, SDK build, download or numerical kernel build.', entries=plan))
    save('environment.json', dict(uname=subprocess.check_output(['uname', '-a'], text=True),
         compiler=subprocess.check_output(['/usr/bin/g++-14', '--version'], text=True),
         device=subprocess.check_output(['nvidia-smi', '--query-gpu=name,driver_version,memory.total', '--format=csv,noheader'], text=True),
         free_bytes=os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize))
    print('PREPARED', len(plan), 'commands;', len(identities), 'source snapshots', flush=True)

def compile_all(args):
    plan = json.loads((ROOT / 'compile-plan.json').read_text())['entries']
    if args.only:
        plan = [r for r in plan if any(s in r['source'] for s in args.only)]
    (ROOT / 'objects').mkdir(exist_ok=True)
    (ROOT / 'logs').mkdir(exist_ok=True)
    existing = json.loads((ROOT / 'compile-results.json').read_text()) if (ROOT / 'compile-results.json').exists() else []
    ok = set() if args.force else {r['source'] for r in existing if r['exit_code'] == 0}
    plan = [r for r in plan if r['source'] not in ok]
    lock = threading.Lock()
    stop = threading.Event()
    results = existing.copy()
    def one(row):
        if stop.is_set():
            return
        key = row['source'].replace('/', '--')
        before = digest(SOURCE / row['source'])
        stem = ROOT / 'logs' / (str(time.time_ns()) + '-' + key)
        (stem.with_suffix('.command.json')).write_text(json.dumps(row, indent=2) + '\n')
        start = time.monotonic()
        with open(str(stem) + '.stdout.log', 'wb') as out, open(str(stem) + '.stderr.log', 'wb') as err:
            process = subprocess.Popen(row['command'], cwd=SOURCE, stdout=out, stderr=err)
            rc = process.wait()
        result = dict(source=row['source'], module=row['module'], command=row['command'], exit_code=rc,
                      seconds=time.monotonic() - start, source_before=before, source_after=digest(SOURCE / row['source']),
                      stdout=str(stem) + '.stdout.log', stderr=str(stem) + '.stderr.log')
        if rc == 0:
            result['object'] = digest(row['object'])
        else:
            stop.set()
        with lock:
            results.append(result)
            save('compile-results.json', results)
            print('PASS' if rc == 0 else 'FAIL', row['source'], round(result['seconds'], 2), flush=True)
            if rc:
                print(Path(result['stderr']).read_text()[-7000:], flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        pending = iter(plan)
        running = set()
        while True:
            while len(running) < args.jobs and not stop.is_set():
                row = next(pending, None)
                if row is None:
                    break
                running.add(pool.submit(one, row))
            if not running:
                break
            done, running = concurrent.futures.wait(running, return_when=concurrent.futures.FIRST_COMPLETED)
            for task in done:
                task.result()
    failures = [r for r in results if r['exit_code']]
    print('RESULTS', len(results), 'recorded;', len(failures), 'failures (including retained earlier attempts)', flush=True)
    return int(stop.is_set())

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'compile'])
    parser.add_argument('--jobs', type=int, default=4)
    parser.add_argument('--only', action='append')
    parser.add_argument('--force', action='store_true')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        raise SystemExit(compile_all(args))

if __name__ == '__main__':
    main()
