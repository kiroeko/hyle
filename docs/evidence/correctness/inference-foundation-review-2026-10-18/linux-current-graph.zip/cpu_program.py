#!/usr/bin/env python3
"""Build only the absent, exact f993 AVX2 companion target; keep old SDK intact."""
import argparse
import concurrent.futures
import json
from pathlib import Path
import subprocess
import threading
import time
import build

OUT = build.ROOT / 'native/avx2'

def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'objects').mkdir(exist_ok=True)
    plan = json.loads((build.LOCAL.parent / 'linux-native-abi-review/cpu-avx2-sixteen-recipes.json').read_text())
    export = 'src/compute_ggml_runtime/cpu_program_export.cc'
    (build.SOURCE / export).write_bytes((build.REPO / export).read_bytes())
    identities = []
    for row in plan['entries']:
        assert Path(row['source']).is_file(), row['source']
        row['command'][1:1] = ['-MMD', '-MF', row['object'] + '.d']
        identities.append(dict(logical_source=row['logical_source'], **build.digest(row['source'])))
    build.save('native/avx2/source-identities.json', identities)
    build.save('native/avx2/compile-plan.json', plan)
    print('PREPARED exact CPU target', len(plan['entries']), 'owners', flush=True)

def compile_all(jobs):
    plan = json.loads((OUT / 'compile-plan.json').read_text())
    results = json.loads((OUT / 'results.json').read_text()) if (OUT / 'results.json').exists() else []
    ok = {r['logical_source'] for r in results if r['exit_code'] == 0}
    rows = [row for row in plan['entries'] if row['logical_source'] not in ok]
    lock = threading.Lock()
    def one(row):
        stem = OUT / (str(time.time_ns()) + '-' + Path(row['object']).stem)
        start = time.monotonic()
        print('START', row['logical_source'], flush=True)
        with open(str(stem)+'.stdout.log', 'wb') as out, open(str(stem)+'.stderr.log', 'wb') as err:
            process = subprocess.Popen(row['command'], cwd=build.SOURCE, stdout=out, stderr=err)
            rc = process.wait()
        result = dict(**row, exit_code=rc, seconds=time.monotonic()-start,
                      stdout=str(stem)+'.stdout.log', stderr=str(stem)+'.stderr.log')
        if rc == 0:
            result['object_identity'] = build.digest(row['object'])
        with lock:
            results.append(result)
            build.save('native/avx2/results.json', results)
            print('END', row['logical_source'], rc, round(result['seconds'],2), flush=True)
            if rc:
                print(Path(result['stderr']).read_text()[-6000:], flush=True)
        return rc
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as pool:
        statuses = list(pool.map(one, rows))
    if any(statuses):
        raise SystemExit(1)

def link():
    plan = json.loads((OUT / 'compile-plan.json').read_text())
    command = plan['link_command']
    start = time.monotonic()
    result = subprocess.run(command, cwd=build.SOURCE, capture_output=True)
    (OUT/'link.stdout.log').write_bytes(result.stdout)
    (OUT/'link.stderr.log').write_bytes(result.stderr)
    record = dict(command=command, exit_code=result.returncode, seconds=time.monotonic()-start)
    if result.returncode == 0:
        target = OUT/'libhyle_ggml_cpu_avx2_linux_current.so'
        record['image'] = build.digest(target)
        exports = subprocess.check_output(['nm','-D','--defined-only',str(target)], text=True)
        (OUT/'exports.txt').write_text(exports)
        record['exports_v2'] = 'hyle_ggml_cpu_program_v2' in exports
        record['exports_v1'] = 'hyle_ggml_cpu_program_v1' in exports
        assert record['exports_v2'] and not record['exports_v1']
        linkmap = (OUT/'libhyle_ggml_cpu_avx2_linux_current.map').read_text()
        record['old_allocator_member_selected'] = 'libggml-base.a(ggml-alloc.c.o)' in linkmap
        assert not record['old_allocator_member_selected'], 'need explicit current allocator before base'
    build.save('native/avx2/link-result.json', record)
    print('LINK', result.returncode, record, flush=True)
    if result.returncode:
        print(result.stderr.decode(errors='replace')[-8000:])
        raise SystemExit(result.returncode)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare','compile','link'])
    parser.add_argument('--jobs', type=int, default=4)
    args = parser.parse_args()
    {'prepare':prepare, 'compile':lambda:compile_all(args.jobs), 'link':link}[args.action]()
