"""Collect text-only proof and exact retained/cleanup identities. Never delete."""
import hashlib
import json
from pathlib import Path
import shlex
import build

def copy_text_logs(folder):
    for pattern in ('*stdout.log','*stderr.log'):
        for src in folder.rglob(pattern):
            dst=build.LOCAL/src.relative_to(build.ROOT)
            dst.parent.mkdir(parents=True,exist_ok=True)
            dst.write_bytes(src.read_bytes())

def main():
    results=json.loads((build.ROOT/'compile-results.json').read_text())
    latest={row['source']:row for row in results if row['exit_code']==0}
    plan=json.loads((build.ROOT/'compile-plan.json').read_text())['entries']
    assert len(latest)==len(plan)==159
    canonical=[]
    drift=[]
    source_rows=json.loads((build.ROOT/'source-identities.json').read_text())
    source_rows+=json.loads((build.ROOT/'hyle-cuda/source-identities.json').read_text())
    by_relative={r['relative']:r for r in source_rows}
    for row in by_relative.values():
        rel=row['relative'];snapshot=build.SOURCE/rel;actual=build.digest(snapshot)
        current=build.digest(build.REPO/rel)
        if actual['sha256']!=current['sha256']:
            drift.append(rel)
        dst=build.LOCAL/'current-source'/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(snapshot.read_bytes())
        canonical.append(dict(relative=rel,compiled_snapshot=actual,current=current))
    for rel in ('src/compute_ggml_runtime/cpu_program_export.cc',):
        src=build.SOURCE/rel;dst=build.LOCAL/'current-source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
    headers={}
    old_hyle=[]
    for dep in sorted((build.ROOT/'objects').glob('*.o.d')):
        text=dep.read_text().replace('\\\n',' ')
        for item in shlex.split(text.split(':',1)[1]):
            p=Path(item)
            if not p.is_file():
                continue
            p=p.resolve()
            if '/static-sdk-relocated/include/hyle/' in str(p):
                old_hyle.append(str(p))
            if p.is_relative_to(build.SOURCE) or p.is_relative_to(build.REPO/'third_party') or p.is_relative_to(build.ROOT/'flashinfer-current') or p.is_relative_to(build.GGML):
                headers[str(p)]=build.digest(p)
    build.save('dependency-check.json',dict(recorded_files=list(headers.values()),
               old_hyle_sdk_headers=sorted(set(old_hyle)),canonical_drift=drift,
               scope='Compiler .d for current Hyle CXX and CU. Native allocator/main/baselineops use exact original recipes without .d; their full source/patch/cache-header provenance is recorded separately.'))
    build.save('final-source-identities.json',canonical)
    assert not old_hyle and not drift
    native=json.loads((build.ROOT/'native/results.json').read_text())
    cu=json.loads((build.ROOT/'hyle-cuda/results.json').read_text())
    avx=json.loads((build.ROOT/'native/avx2/results.json').read_text())
    objects={row['object']['path']:row['object'] for row in latest.values()}
    for row in native+cu+avx:
        if row['exit_code']==0:
            ident=row['object_identity'];objects[ident['path']]=ident
    for path,ident in objects.items():
        assert build.digest(path)==ident,path
    build.save('retained-objects.json',list(objects.values()))
    companion=build.ROOT/'native/avx2/libhyle_ggml_cpu_avx2_linux_current.so'
    retain=[*objects.values(),build.digest(companion)]
    files=[build.digest(build.ROOT/name) for name in ('route-symmetry','route-symmetry.map')]
    build.save('cleanup-linux.json',dict(distribution='Ubuntu-24.04',root=str(build.ROOT),files=files,retain=retain,
               policy='Exact files only; keep build/source/logs/all objects and the new reusable f993 AVX2v2 companion. No delete performed.'))
    build.save('cleanup-windows.json',dict(root=str(build.LOCAL),files=[],retain=[]))
    copy_text_logs(build.ROOT/'logs')
    copy_text_logs(build.ROOT/'native')
    copy_text_logs(build.ROOT/'hyle-cuda')
    copy_text_logs(build.ROOT/'extra-cuda')
    for name in ('src/ggml-alloc.c','src/ggml-cpu/ops.cpp','src/ggml-cuda/ggml-cuda.cu'):
        src=build.ROOT/'native/source'/name;dst=build.LOCAL/'native/source'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
    commands=json.loads((build.ROOT/'commands.json').read_text())
    runs=[r for r in commands if r['tag']=='route-symmetry-run']
    summary=dict(status=('passed' if runs[-1]['exit_code']==0 else 'failed') if runs else 'compiled_linked_gpu_run_deferred',
          target='tests/graph/route_symmetry_cuda.cc current default CPU+CUDA ordinary Invocation/progress finite family',
          current_host_cxx=156,fcontext_asm=3,ggml_interface_overlays=3,hyle_cuda_owners=12,
          missing_cpu_avx2_companion=dict(native_tus=15,hyle_export_tus=1,explicit_current_allocator=True,image=build.digest(companion)),
          retained_objects=len(objects),run=runs[-1] if runs else None,
          canonical_drift=drift,old_hyle_host_archive_members=json.loads((build.ROOT/'selected-owners.json').read_text())['prohibited_old_hyle_host_members'],
          cleanup=dict(files=len(files),bytes=sum(r['bytes'] for r in files)),
          limits=['One existing finite-family route; not a model, attention, capture, performance or all-provider math acceptance.',
                  'CUDA math cache remains f993; selected Neg unary does not use the later diagmask patch or explicit-frequency RoPE precision change.',
                  'Rebuilt one missing 16-TU original AVX2 CPU program plus current allocator; not zero native compilation, and no ggml-base/CUDA/Torch/oneDNN SDK build.',
                  'Six earliest failed stderr files were superseded by initial source-named logging; exact observed diagnostics and limitation preserved in early-failure-observations.json. Later logs are unique per attempt.'])
    build.save('summary.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    main()
