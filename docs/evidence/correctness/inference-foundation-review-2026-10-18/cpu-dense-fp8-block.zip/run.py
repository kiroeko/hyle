from pathlib import Path
import importlib.util, json, subprocess, time, hashlib, os
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cached_cpu', ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cpu)
TORCH = Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
flags = cpu.hyle_flags(dict(cpu.PINS['mixed'], folder=Path('mixed'))) + [
    '/I'+str(ROOT), '/I'+str(ROOT/'src/compute_provider_native'), '/DHYLE_COMPUTE_TORCH_CPU=1',
    '/external:I'+str(TORCH/'include'), '/external:I'+str(TORCH/'include/torch/csrc/api/include')]
flags += ['/I'+str(ROOT/'third_party'/d) for d in ['torchao_cpu','bitsandbytes_cpu','awq_cpu','compressed_tensors_cpu','mlx_cpu_quant']]
env = cpu.ENV.copy()
env['PATH'] = str(TORCH/'lib')+os.pathsep+env['PATH']
env['OMP_NUM_THREADS'] = env['MKL_NUM_THREADS'] = '2'
records = []

def run(tag, command):
    command = list(map(str, command))
    start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=180)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout)
    (OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag, command=command, exit=p.returncode, seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(tag, p.returncode, p.stdout.decode(errors='replace')[-7500:], p.stderr.decode(errors='replace')[-2500:], flush=True)
    if p.returncode: raise SystemExit(p.returncode)

def compile(source, name):
    obj = OUT/(name+'.obj')
    run(name+'-compile', [cpu.CL,*flags,'/Tp'+str(source),'/Fo'+str(obj)])
    return obj

libs = [cpu.BASE/'bin'/name for name in ['hyle_compute_route_cpu.lib','hyle_compute_provider_native.lib','hyle_compute_provider_onednn.lib','dnnl.lib']] + cpu.common_libs() + [TORCH/'lib'/name for name in ['torch.lib','torch_cpu.lib','c10.lib']] + [cpu.BASE/'lib/gtest.lib',cpu.BASE/'lib/gtest_main.lib']

def link(name, objects):
    exe = OUT/(name+'.exe')
    run(name+'-link', [cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/(name+'.map')),*objects,*libs,*cpu.SYSTEM])
    return exe

def main():
    tests = compile(ROOT/'tests/compute_provider_native/torch_cpu_test.cc', 'tests')
    product = compile(ROOT/'src/compute_provider_native/torch_cpu_program.cc', 'product')
    exe = link('canonical', [tests, product])
    run('canonical-tests', [exe, '--gtest_filter=NativeTorchCpu.*'])
    for arm in ['before', 'after']:
        path = OUT/'torch_cpu_program.before.cc' if arm == 'before' else ROOT/'src/compute_provider_native/torch_cpu_program.cc'
        source = '#include <cstdio>\n'+path.read_text()
        marker = '    auto dots = at::matmul(lhs.select(1, block), decoded.transpose(1, 2));'
        assert source.count(marker) == 1
        source = source.replace(marker, '''    if (!w.ids.defined())
      std::fprintf(stderr, "DENSE_BLOCK tokens=%lld block=%lld encoded=%lld decoded=%lld\\n",
          static_cast<long long>(s.tokens), static_cast<long long>(block),
          static_cast<long long>(encoded.numel()), static_cast<long long>(decoded.numel()));
'''+marker)
        instrumented = OUT/('instrumented-'+arm+'.cc')
        instrumented.write_text(source)
        obj = compile(instrumented, 'instrumented-'+arm)
        exe = link('instrumented-'+arm, [tests, obj])
        run(arm+'-census-and-numerics', [exe, '--gtest_filter=NativeTorchCpu.DenseFloat8BlocksShareWeightsAcrossTokensAndRebindBothSlots'])
    paths = [ROOT/'src/compute_provider_native/torch_cpu_program.cc',ROOT/'tests/compute_provider_native/torch_cpu_test.cc',TORCH/'lib/torch_cpu.dll',cpu.CL]+libs
    (OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths],indent=2)+'\n')
    (OUT/'runtime-environment.json').write_text(json.dumps({key:env[key] for key in ['PATH','OMP_NUM_THREADS','MKL_NUM_THREADS']},indent=2)+'\n')

if __name__ == '__main__': main()
