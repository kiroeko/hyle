from pathlib import Path
import base64, difflib, hashlib, json, re, shutil, subprocess, zipfile
R = Path(__file__).resolve().parents[3]
O = Path(__file__).resolve().parent

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, data): (O/name).write_text(json.dumps(data, indent=2)+'\n')

sources = ['src/compute_provider_native/torch_cpu_program.cc','tests/compute_provider_native/torch_cpu_test.cc']
patch = ''
for source, before in zip(sources, ['torch_cpu_program.before.cc','torch_cpu_test.before.cc']):
    target = O/'source'/source
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(R/source, target)
    patch += ''.join(difflib.unified_diff((O/before).read_text().splitlines(True), target.read_text().splitlines(True), fromfile='before/'+source, tofile='after/'+source))
(O/'source.diff').write_text(patch)
save('source-sha.json', [dict(path=s, bytes=(R/s).stat().st_size, sha256=sha(R/s)) for s in sources])
census = {}
for arm in ['before','after']:
    raw = (O/(arm+'-census-and-numerics.stderr.log')).read_text()
    counts = [tuple(map(int, x)) for x in re.findall(r'DENSE_BLOCK tokens=(\d+) block=(\d+) encoded=(\d+) decoded=(\d+)', raw)]
    assert len(counts) == 24 and all(x[0] == 3 for x in counts)
    census[arm] = dict(block_observations=len(counts), encoded_numel=sorted({x[2] for x in counts}), decoded_numel=sorted({x[3] for x in counts}), decoded_float32_bytes=sorted({4*x[3] for x in counts}))
assert census['before']['decoded_numel'] == [49536] and census['after']['decoded_numel'] == [16512]
save('census.json', census)

catalog = json.loads((R/'docs/implementation/tasks/compute/llm-moe-provider-demand-matrix.json').read_text())['profile_catalog']
manifest = json.loads((R/'third_party/iree_vulkan_runtime/programs/manifest.json').read_text())
entries = manifest if isinstance(manifest,list) else next(v for v in manifest.values() if isinstance(v,list) and v and isinstance(v[0],dict) and 'name' in v[0])
entry = next(e for e in entries if e['name'] == 'official')
programs = R/'third_party/iree_vulkan_runtime/programs'
recipe_sha = hashlib.sha256((programs/'official.mlir').read_bytes().replace(b'\r\n',b'\n')).hexdigest()
vmfb = base64.b64decode((programs/'official.vmfb.b64').read_bytes())
assert recipe_sha == entry['recipe_sha256']
assert hashlib.sha256(vmfb).hexdigest() == entry['sha256']
proof = dict(
    scope='8 model / 22 profile format requirements, source-level default route review; no complete model execution in this batch',
    profile_catalog=catalog,
    findings=[
      dict(route='CPU native ATen official dense FP8 / encoded MatMul', state='fixed and component-tested',
           anchors=['src/compute_provider_native/torch_cpu_program.cc:168 weight retains encoded views','src/compute_provider_native/torch_cpu_program.cc:180 block_dot explicit per-K128 contiguous/decode','src/compute_provider_native/torch_cpu_program.cc:307 dense branch now retains batch1 weights','src/compute_provider_native/torch_cpu_program.cc:346 submit invokes p.run on actual current bindings','src/compute_provider_native/torch_cpu_program.cc:434 prepare warms isolated tensors only, no user weights'],
           mechanism='Old dense token expand caused encoded contiguous and F32 conversion of T identical current K128 blocks. Keep batch1 weight and broadcast original matmul/scales. No constant caching; mutable/rebound weights remain live.'),
      dict(route='CPU native ATen grouped FP8/FP4 and MLX quantization', state='source-reviewed; bounded selected-current-block work',
           anchors=['src/compute_provider_native/torch_cpu_program.cc:192 slice current K block before expert index_select','third_party/mlx_cpu_quant/mlx_cpu_quant.h:41 slice packed current group before selected expert rows','third_party/mlx_cpu_quant/mlx_cpu_quant.h:73 embedding selects rows before unpack'],
           boundary='Repeated submits still decode selected blocks/rows; duplicate expert IDs may repeat block data. This is not whole-bank materialization.'),
      dict(route='CUDA SGLang official FP8 dense/grouped and DeepSeek grouped FP4', state='source-reviewed direct packed weights',
           anchors=['src/compute_provider_cuda/fp8_provider.cc:146 submit original encoded input B and scale pointer; quantization is A only','src/compute_provider_cuda/grouped_fp8_provider.cc:123 submit original W bank, route IDs and A quantization','src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc:100 scales_b offset and original bank passed to indexed GEMM','src/compute_route_cuda/default_policy.cc:14 baseline plus provider admission/rank'],
           boundary='No full-bank decode/repack/copy found in these submits. Cold module loading is distinct from repeat-submit numerical kernels. No new CUDA run in this batch.'),
      dict(route='Explicit Float8WeightDecode', state='intentional operation; selected fragments already separate cold preparation',
           anchors=['src/compute_provider_cuda/deepseek_fp8_provider.cc:124 explicit requested decode launch','tests/compute_models/d5_deepseek_official_attention.h:348 cold->one decode','tests/compute_models/d5_glm_remaining_fragments.h:327 cold->one decode','tests/compute_models/d5_fp8_weight_preparation.h:53 standalone decode fixture'],
           boundary='Explicit output materialization cannot be classified as hidden hot bank decode merely from function name.'),
      dict(route='Vulkan IREE immutable transfer', state='source-reviewed already cold per invocation / eligible borrow',
           anchors=['src/compute_route_vulkan/vulkan_iree.cc:413 eligible owned device-local immutable grouped bank is borrowed','src/compute_route_vulkan/vulkan_iree.cc:472 constant input classification','src/compute_route_vulkan/vulkan_iree.cc:519 constants_submitted skips repeat copies','src/compute_route_vulkan/vulkan_iree.cc:598 first constant-copy submission only'],
           boundary='Each distinct invocation may own its own one-time input copy; dynamic inputs still copy. No repeated immutable upload was established.'),
      dict(route='Vulkan IREE official dense FP8 / encoded MatMul', state='unfixed source-defined repeated per-token current-block decode',
           anchors=['third_party/iree_vulkan_runtime/programs/official.mlir:556 linear_normal wx[R,N,128], expert=0 independent of row','third_party/iree_vulkan_runtime/programs/official.mlir:578 optimization_barrier then batch_matmul','third_party/iree_vulkan_runtime/programs/official.mlir:646 linear_power same structure','third_party/iree_vulkan_runtime/programs/official.mlir:948 encoded_block128 same structure','src/compute_route_vulkan/vulkan_official.cc:43 scratch admission accounts current R*N*group tensor'],
           smallest_next='Decode one [N,128] current block, then original F32 dot/scales/K-order; update generator and regenerate same-pin official VMFB with existing offline compiler. Do not edit recipe alone and reuse old VMFB.',
           boundary='Not a whole K/expert bank. No actual Vulkan heap/latency census or shader run this batch; source materialization includes an optimization barrier. Compiler availability not re-probed here.'),
      dict(route='GGUF embedding/projection/LM-head/expert', state='existing packed-native route, source-reviewed scope',
           anchors=['src/compute_provider_ggml/ggml_cpu_provider.cc:1020 native GET_ROWS','src/compute_provider_ggml/ggml_cpu_provider.cc:1068 native MUL_MAT_ID','src/compute_provider_ggml_cuda/tensor_program.cc:735 GET_ROWS','src/compute_provider_ggml_cuda/tensor_program.cc:756 MUL_MAT_ID','src/compute_provider_ggml_vulkan/region.cc native quantized Gather/MatMul/GroupedMatMul lowering'],
           boundary='Packed native operations are not explicit full decoded weight tensor nodes. Native kernel per-block codec work is mathematical consumption. Do not infer absence of backend-private packing from this review. Narrow new IQ1 GET_ROWS GPU limitations remain separate.'),
      dict(route='Kimi official FP4 profile', state='existing lossless cold repack to native GGUF MXFP4',
           anchors=['tests/compute_models/d5_official_fp4_storage.h:16 model conversion/base.py repack contract','tests/compute_models/d5_official_fp4_storage.h:89 weight construction repack'],
           boundary='Does not demand the A8 activation DeepSeek FP4 custom. Do not revive that prior false missing-AOT report.')
    ],
    iree_source_artifact_identity=dict(recipe_normalized_sha256=recipe_sha, decoded_vmfb_sha256=hashlib.sha256(vmfb).hexdigest(), matches_current_manifest=True),
    limitations=['Default route selection traced from current admission and policy; numeric run this batch is the component native Context, not 22 model fragments or full default-roster runs.','No throughput/PMU/native internal BLAS packing claim.','This fix eliminates token-repeated explicit dense block decoding, not all repeat-submit codec cost or all persistent conversions.'])
save('route-source-review.json', proof)
save('summary.json', dict(status='applied_not_committed', change='Keep one dense encoded FP8 weight matrix across token batch; original ATen matmul/scales broadcast it.',
    product_sources=sources, tests=dict(canonical='6/6 PASS', instrumented_before='1/1 PASS', instrumented_after='1/1 PASS',
    new_case='T3 N129 K256, encoded / normal dynamic / power2 dynamic, two phases, two invocation slots, mutable weights and activations; sparse dyadic independent FP64 exact full-output oracle.', scalar_checks_per_arm=4644),
    census=census, decoded_block_reduction='3x for T3: 198144 -> 66048 F32 bytes per K128 block; encoded bytes 49536 -> 16512.',
    build='Fresh canonical Torch host and existing canonical test TU; two additional diagnostic-only same-source host variants print actual numel. Existing MSVC/Torch CPU 2.8 / Hyle static closure, no native SDK rebuild.',
    performance='Not measured; gtest and compile durations are not rankings.', default_route='Source-level admission/policy mapping in route-source-review.json; only component functional execution this batch.',
    failure='No compile/link/test failures in this batch.', remaining='Vulkan dense IREE has source-defined R copies of a shared current weight group; requires exact offline VMFB regeneration and focused validation.',
    compatibility='No public API/ABI/admission/provider choice changes; no user weight cache; K-block order and scale arithmetic retained.',
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()))
products = [p for p in O.iterdir() if p.suffix.lower() in ['.obj','.exe','.exp','.lib']]
save('artifacts.json', [dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p),role='rebuildable; not deleted') for p in products])
archive = O/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(O.rglob('*')):
        if p.is_file() and p != archive and p.suffix.lower() not in ['.obj','.exe','.lib','.exp','.zip','.pyc']:
            z.write(p,p.relative_to(O))
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
print(json.dumps(dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),indent=2))
