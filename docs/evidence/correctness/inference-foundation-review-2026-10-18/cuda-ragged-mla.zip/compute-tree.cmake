get_filename_component(_root "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
include("${_root}/cmake/HyleDependencyVersions.cmake")
_hyle_dependency_tree_sha256("${_root}/third_party/flashinfer_cache" _hash)
file(WRITE "${CMAKE_CURRENT_LIST_DIR}/computed-tree.txt" "${_hash}")
