from pathlib import Path
import json,hashlib,difflib,re,zipfile
r=Path.cwd();o=r/'.scratch/inference-foundation-review-2026-10-18/cuda-ragged-mla';sha=lambda b:hashlib.sha256(b).hexdigest()
files=['src/compute_provider_flashinfer/flashinfer_provider.cc','src/compute_provider_flashinfer/native_mla.cu','third_party/flashinfer_cache/patches.json','third_party/flashinfer_cache/NOTICE.md','cmake/HyleDependencyLock.json','cmake/HyleComponents.cmake','tests/compute_provider_flashinfer/CMakeLists.txt','tests/compute_provider_flashinfer/ragged_mla_test.cc']
ident=[];diff=''
for f in files:
 p=r/f;q=o/'applied'/f;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());before=o/'before'/f;a=before.read_bytes()if before.exists()else b''
 ident.append({'path':f,'before_sha256':sha(a)if before.exists()else None,'after_sha256':sha(p.read_bytes())})
 diff+=''.join(difflib.unified_diff(a.decode().splitlines(True),p.read_text().splitlines(True),fromfile='before/'+f,tofile='applied/'+f))
(o/'source.diff').write_text(diff);(o/'source-identities.json').write_text(json.dumps(ident,indent=2)+'\n')
# Ensure concurrent IREE and every non-FlashInfer lock entry are byte-semantically preserved.
before=json.loads((o/'before/cmake/HyleDependencyLock.json').read_text());after=json.loads((r/'cmake/HyleDependencyLock.json').read_text())
assert [x for x in before['dependencies']if x['name']!='flashinfer_cache_patches']==[x for x in after['dependencies']if x['name']!='flashinfer_cache_patches']
ndiff=''
for name in ['mla.cuh','mla_params.cuh']:
 f='include/flashinfer/attention/'+name;a=(o/'native-before'/f).read_text();b=(o/'verified-headers'/f).read_text();ndiff+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='native-before/'+f,tofile='native-applied/'+f))
(o/'native.diff').write_text(ndiff)
# Keep narrow symbol provenance; full maps remain reproducible scratch diagnostics.
excerpts=[]
for name in ['tests.map','paged.map']:
 p=o/name;lines=p.read_text(errors='replace').splitlines();excerpts.append(name+':\n'+'\n'.join(x for x in lines if 'native_mla.obj' in x or 'ragged_mla_case' in x)+'\n')
(o/'link-map-excerpt.txt').write_text('\n'.join(excerpts))
art=[]
for p in sorted(o.iterdir()):
 if p.is_file()and p.suffix in ['.obj','.exe','.lib','.exp']:
  art.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'disposition':'retain matched native/provider/test object cache; executable/linker outputs are exact cleanup candidates, no deletion performed'if p.suffix in ['.exe','.lib','.exp']else 'retain small matched cache'})
(o/'artifacts.json').write_text(json.dumps(art,indent=2)+'\n')
commands=json.loads((o/'host-commands.json').read_text());functional=(o/'16-functional.stdout.log').read_text();assert '[  PASSED  ] 1 test.'in functional
errs=[float(x)for x in re.findall(r'maxAbs=([0-9.e+-]+) PASS',functional)]
assert len(errs)==32
summary={'result':'PASS: typed CUDA ragged MLA CKV512 or CKV512+KPE64, one physical cache; not a performance measurement','source_files':files,'hardware':'Windows RTX4070 SM89, CUDA13.3, driver617.14, MSVC14.50.35717','implementation':{'planner':'Original MLAPlan/MLAPlanInfo, per-request query indptr and packed KV indptr; ragged KV lengths are adjacent indptr differences.','physical':'F16/BF16 packed rows [KV,1,512|576]; q_nope/CKV prefix512 and optional KPE64 use actual row strides; V directly aliases CKV prefix. No identity table, K/V expansion or host cache materialization.','address':'Original block_iter_base = per-request global kv_indptr*block_size + local kv_start. Ragged block_size=1 and four 16-bit KV loads map q directly to this global row. Paged nonnull indices lookup remains.','null_table':'Private MLAParams.linear_kv defaults false. Original launcher rejects null table unless explicitly linear, 16-bit KV and unit block size; linear plus nonnull table is also rejected. Hyle qualifies only plain same-type F16/BF16, KVheads1, QK512/576, V512.','math':'Original QK/probability/final cast, F32 split partials and F32 merge, causal mask and all shared-memory configurations unchanged. No new template configurations:2dtype*2KPE*2mask*3existing shared configs=24.','safety':'Additional ragged maxKV*depth<=UINT32_MAX bound, original query/grid/scheduler bounds, positive finite scale, no-window contract retained. Same Queue/accepted-prefix ownership and managed Graph batch permissions.','private_abi':'Only native_mla.cu instantiates/includes changed MLAParams. BatchSpec/common public ABI unchanged; native SDK and all other native objects reused.'},'validation':{'new_test':'FlashInferRaggedMla.Compact512And576KeepGlobalRowsDirectGraphAndOwners','result':'1/1 PASS; 8 dtype/head/depth combinations, 2 episodes each, Direct and configured Graph =32 full independent FP64 all-output oracles','dtype':['F16','BF16'],'heads':[64,128],'depths':[512,576],'request_query_indptr':[[0,1,4],[0,1,2]],'request_kv_indptr':[[0,17,64],[0,21,64]],'budget':'Original MLA strict abs error <0.007, unchanged','max_abs_f16':max(errs[:16]),'max_abs_bf16':max(errs[16:]),'split':'All16 Direct episodes assert actual split_kv; original16-byte workspace negative control returns ResourceExhausted before native plan upload.','ownership':'Independent Direct and Graph slots preserve old phase0 output bytes while phase1 changes actual inputs/layout.','default_route':'Eight real cuda::create_context BatchProgram prepare checks discover the MLA capability. Graph uses the existing explicitly configured graph::batch::provider and actual GPU storage/host workspace; not a claim that arbitrary unconfigured Graph nodes auto-discover batch recipes.','paged_regression':'Original public_mla_cuda_consumer unchanged: four paged cases Direct/Graph/capture/page-ID rebind plus BF16 Q1/KV8192 split cancellation exact maxAbs0, exit0.','canonical_warnings':'Fresh test TU-only /W4 /WX /wd4324 compile PASS, matching HyleWarnings.cmake. Separately retained strict object was not substituted into the already-tested executable.','resource_audit':'Current pin plus complete9-file manifest exact before/after replay PASS; CMake-P FlashInfer tree/NOTICE PASS; every other lock entry including IREE verified unchanged.','no_claims':['No throughput/latency/actual peak-memory experiment','No other GPU architecture or Linux execution tested','No arbitrary masks, learned sinks, FP8 MLA or window support added','Ragged Queue capture was not separately requested/tested; original paged capture regression passed']},'build':{'native':'One native_mla.cu, 33.844s, exit0; same CUDA17/sm89 flags and existing native header/source caches','host':'Fresh flashinfer_provider.cc, new registered test TU and original paged consumer TU only. Other matched Graph/backend/provider/native caches reused from root pending-row closure.','native_object':next(x for x in art if x['path'].endswith('native_mla.obj')),'reconstruction':['python -B build_native.py (requires complete manifest projection in verified-headers; all exact hashes recorded)','python -B build_host.py compile; python -B build_host.py link; python -B build_host.py run','python -B build_host.py paged','cmake -P check-lock.cmake']},'failures_retained':['Test initial compile lacked explicit backends/cuda.h; added that public include, no numerical change.','First functional test used Graph default CPU storage and a device resource as host workspace: FailedPrecondition CUDA resource mismatch. GoogleTest break_on_failure terminated via breakpoint, not native kernel crash; corrected explicit GPU StorageDomain/ExecutionTarget and pinned host LaneBinding, same inputs/budget.','Initial raw /W4/WX-only compile hit existing intentional alignas C4324; exact canonical /wd4324 policy applied and clean compile passed.','Initial resource hash calculation used the wrong directory algorithm; final lock uses the actual canonical CMake computation and its audit passes.'], 'artifacts':'artifacts.json lists exact local generated objects and cleanup candidates; no binaries in archive, no deletion/commit performed.'}
(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Evidence only: exact sources, commands, logs, hash metadata, small projected native headers.
selected=[]
for p in o.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(o)
 if rel.parts[0] in ['before','applied','native-before']:selected.append(p)
 elif rel.parts[0]=='verified-headers' and p.name in ['mla.cuh','mla_params.cuh']:selected.append(p)
 elif len(rel.parts)==1 and p.suffix in ['.py','.json','.log','.diff','.cmake'] and p.name not in ['package-identity.json']:selected.append(p)
selected += [o/'link-map-excerpt.txt']
z=o/'source-results.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as f:
 for p in selected:f.write(p,p.relative_to(o).as_posix())
with zipfile.ZipFile(z)as f:
 for p in selected:assert f.read(p.relative_to(o).as_posix())==p.read_bytes()
 assert not any(i.filename.endswith(('.obj','.exe','.lib','.exp'))for i in f.infolist())
a={'path':str(z.relative_to(r)),'bytes':z.stat().st_size,'sha256':sha(z.read_bytes()),'members':len(selected)};(o/'package-identity.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))
