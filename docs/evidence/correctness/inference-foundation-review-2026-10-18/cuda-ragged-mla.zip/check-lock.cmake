get_filename_component(_root "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
include("${_root}/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(flashinfer_cache_patches)
message(STATUS "FlashInfer ragged MLA resource tree/NOTICE PASS")
