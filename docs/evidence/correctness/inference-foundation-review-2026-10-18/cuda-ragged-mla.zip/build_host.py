from pathlib import Path
import json,sys,os,subprocess,time,hashlib
r=Path.cwd();o=r/'.scratch/inference-foundation-review-2026-10-18/cuda-ragged-mla'
sys.path.insert(0,str(r/'.scratch/inference-feature-completion-2026-10-18/windows-batch'));import build_host as b
records=json.loads((o/'host-commands.json').read_text())if(o/'host-commands.json').exists()else[]
def run(tag,args):
 args=list(map(str,args));stem=str(len(records)+1)+'-'+tag;t=time.monotonic();p=subprocess.run(args,cwd=r,env=b.env,capture_output=True,timeout=180)
 (o/(stem+'.stdout.log')).write_bytes(p.stdout);(o/(stem+'.stderr.log')).write_bytes(p.stderr);records.append({'tag':tag,'command':args,'cwd':str(r),'exit':p.returncode,'seconds':time.monotonic()-t});(o/'host-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-1500:],flush=True);p.check_returncode()
if sys.argv[1]=='compile':
 files=json.loads((r/'.scratch/inference-foundation-review-2026-10-18/row-cache-pending-graph/commands.json').read_text())
 old=next(x['command']for x in reversed(files)if x['tag']=='cuda-pending-compile')
 includes=[x for x in old if 'googletest' in x and x.startswith(('/external:I','/I'))]
 for src,name in [('src/compute_provider_flashinfer/flashinfer_provider.cc','provider'),('tests/compute_provider_flashinfer/ragged_mla_test.cc','tests')]:
  if len(sys.argv)>2 and name not in sys.argv[2:]:continue
  run(name+'-compile',[b.cl,*b.flags,*includes,'/I'+str(r),r/src,'/Fo'+str(o/(name+'.obj'))])
elif sys.argv[1]=='link':
 old=json.loads((r/'.scratch/inference-foundation-review-2026-10-18/row-cache-pending-graph/commands.json').read_text())
 args=next(x['command']for x in reversed(old)if x['tag']=='cuda-pending-link')
 new=[]
 for x in args:
  if x.startswith(('/OUT:','/MAP:')):continue
  p=Path(x)
  if p.name in ['cuda-pending.obj','cuda-test.obj']:continue
  if p.name=='flashinfer-provider.obj':x=str(o/'provider.obj')
  if p.name=='native_mla.obj':x=str(o/'native_mla.obj')
  new.append(x)
 new += [str(o/'tests.obj'),'/OUT:'+str(o/'tests.exe'),'/MAP:'+str(o/'tests.map')]
 for x in new:
  if x.endswith('.lib')and Path(x).is_absolute():b.env['PATH']=str(Path(x).parent)+os.pathsep+b.env['PATH']
 missing=[x for x in new if x.endswith(('.obj','.lib'))and Path(x).is_absolute()and not Path(x).is_file()];assert not missing,missing
 run('link',new)
 (o/'link-identities.json').write_text(json.dumps([{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for x in new if x.endswith(('.obj','.lib'))and(p:=Path(x)).is_file()],indent=2)+'\n')
elif sys.argv[1]=='paged':
 prev=next(x['command']for x in reversed(records)if x['tag']=='tests-compile')
 cmd=[x.replace(str(r/'tests/compute_provider_flashinfer/ragged_mla_test.cc'),str(r/'tests/compute_batch/public_mla_cuda_consumer.cc')).replace('/Fo'+str(o/'tests.obj'),'/Fo'+str(o/'paged.obj'))for x in prev]
 run('paged-compile',cmd)
 args=next(x['command']for x in reversed(records)if x['tag']=='link')
 args=[x.replace(str(o/'tests.obj'),str(o/'paged.obj')).replace('/OUT:'+str(o/'tests.exe'),'/OUT:'+str(o/'paged.exe')).replace('/MAP:'+str(o/'tests.map'),'/MAP:'+str(o/'paged.map'))for x in args]
 for x in args:
  if x.endswith('.lib')and Path(x).is_absolute():b.env['PATH']=str(Path(x).parent)+os.pathsep+b.env['PATH']
 run('paged-link',args);run('paged-regression',[o/'paged.exe'])
elif sys.argv[1]=='run':
 args=next(x['command']for x in reversed(records)if x['tag']=='link')
 for x in args:
  if x.endswith('.lib')and Path(x).is_absolute():b.env['PATH']=str(Path(x).parent)+os.pathsep+b.env['PATH']
 run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total,memory.free','--format=csv'])
 run('functional',[o/'tests.exe','--gtest_filter=FlashInferRaggedMla.*','--gtest_break_on_failure'])
