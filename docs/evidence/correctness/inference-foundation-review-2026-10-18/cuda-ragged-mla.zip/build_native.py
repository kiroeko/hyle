from pathlib import Path
import json,sys,subprocess,os,time,hashlib
r=Path.cwd();o=r/'.scratch/inference-foundation-review-2026-10-18/cuda-ragged-mla';old=r/'.scratch/inference-feature-completion-2026-10-18/mla';active=r/'.scratch/inference-foundation-review-2026-10-18/mla-active-workspace'
sys.path.insert(0,str(r/'scripts'));from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
env=windows_compiler_environment(read_cache(r/'.scratch/build-compute-v2-dev'));env['VSLANG']='1033'
a=json.loads((active/'native-command.json').read_text())['command']
a=[x.replace(str(active/'verified-headers'),str(o/'verified-headers')).replace(str(active/'native_mla.obj'),str(o/'native_mla.obj'))for x in a]
start=time.monotonic();p=subprocess.run(a,cwd=o,env=env,capture_output=True,timeout=180)
(o/'native.stdout.log').write_bytes(p.stdout);(o/'native.stderr.log').write_bytes(p.stderr)
(o/'native-command.json').write_text(json.dumps({'command':a,'cwd':str(o),'exit':p.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
print('native compile',p.returncode,'seconds',time.monotonic()-start,flush=True)
if p.returncode:print((p.stdout+p.stderr).decode(errors='replace')[-7000:])
else:
 obj=o/'native_mla.obj';print('obj',obj.stat().st_size,hashlib.sha256(obj.read_bytes()).hexdigest())
raise SystemExit(p.returncode)
