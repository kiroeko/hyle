from pathlib import Path
import json,hashlib
r=Path.cwd();o=r/'.scratch/inference-foundation-review-2026-10-18/cuda-ragged-mla';raw=r/'.scratch/g04-bf16-partials-vendor/upstream';p=r/'third_party/flashinfer_cache/patches.json'
text=p.read_bytes().decode();m=json.loads(text);sha=lambda x:hashlib.sha256(x).hexdigest();materialized={}
for e in m['files']:
 b=(raw/e['path']).read_bytes().replace(b'\r\n',b'\n');assert sha(b)==e['before_sha256']
 for ed in e['edits']:
  a,z=ed['before'].encode(),ed['after'].encode();assert b.count(a)==1;b=b.replace(a,z,1)
 assert sha(b)==e['after_sha256'];materialized[e['path']]=b
new_edits={'include/flashinfer/attention/mla_params.cuh':[{'before':'  IdType* kv_indices;','after':'  IdType* kv_indices;\n  // Private linear CKV rows; only the qualified ragged adapter sets this.\n  bool linear_kv = false;'}]}
name='include/flashinfer/attention/mla.cuh';b=materialized[name].decode();edits=[]
for comment in ['      // Cast page index to int64_t before multiplying to avoid overflow.','      // See comment above: widen to int64_t to avoid 32-bit overflow when indices[q] is large.']:
 begin=b.index(comment);end=b.index('\n#pragma unroll',begin);a=b[begin:end]
 needle='packed_block_iter < packed_kv_bound ? indices[q] : 0';assert a.count(needle)==2
 z=a.replace(needle,'packed_block_iter < packed_kv_bound\n                  ? (indices ? indices[q] : static_cast<typename KTraits::IdType>(q)) : 0')
 edits.append({'before':a,'after':z})
a='  constexpr bool CAUSAL = MASK_MODE == MaskMode::kCausal;\n\n  dim3 nblks(num_blks_x, num_blks_y);'
z='''  constexpr bool CAUSAL = MASK_MODE == MaskMode::kCausal;

  // A missing page table is legal only for explicit 16-bit linear rows.
  // Keep accidental null tables invalid for every original paged caller.
  if (params.linear_kv) {
    if (params.kv_indices || unsigned(params.block_size) != 1 || sizeof(DTypeKV) != 2)
      return cudaErrorInvalidValue;
  } else if (!params.kv_indices) {
    return cudaErrorInvalidValue;
  }

  dim3 nblks(num_blks_x, num_blks_y);'''
edits.append({'before':a,'after':z});new_edits[name]=edits
for e in m['files']:
 name=e['path']
 if name not in new_edits:continue
 old_sha=e['after_sha256'];b=materialized[name]
 q=o/'native-before'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 for ed in new_edits[name]:
  a,z=ed['before'].encode(),ed['after'].encode();assert b.count(a)==1;b=b.replace(a,z,1)
 e['edits']+=new_edits[name];e['after_sha256']=sha(b)
 begin=text.index('"path": '+json.dumps(name));end=text.index('\n      ]',begin)
 rendered=['        {\n          "before": '+json.dumps(ed['before'],ensure_ascii=True)+',\n          "after": '+json.dumps(ed['after'],ensure_ascii=True)+'\n        }'for ed in new_edits[name]]
 text=text[:end]+',\n'+',\n'.join(rendered)+text[end:]
 assert text.count(old_sha)==1;text=text.replace(old_sha,e['after_sha256'],1)
assert json.loads(text)==m;p.write_bytes(text.encode())
for e in m['files']:
 b=(raw/e['path']).read_bytes().replace(b'\r\n',b'\n');assert sha(b)==e['before_sha256']
 for ed in e['edits']:
  a,z=ed['before'].encode(),ed['after'].encode();assert b.count(a)==1;b=b.replace(a,z,1)
 assert sha(b)==e['after_sha256'];q=o/'verified-headers'/e['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(o/'manifest-replay.json').write_text(json.dumps({'upstream_revision':m['upstream_revision'],'files':[{'path':e['path'],'before_sha256':e['before_sha256'],'after_sha256':e['after_sha256']}for e in m['files']]},indent=2)+'\n')
print('replay PASS',len(m['files']),'headers')
