from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
BASE=R.parent/'inference-foundation-review-20261018-row-cache-indexer-native'
prior=json.loads((BASE/'apple-commands.json').read_text())
cc=next(x['command']for x in reversed(prior)if x['tag'].endswith('-indexer-compile'))
flags=cc[:cc.index('-c')]
flags[1:1]=['-I'+str(R/'include'),'-I'+str(R)]
link=next(x['command']for x in reversed(prior)if x['tag'].endswith('-link'))
records=json.loads((R/'commands.json').read_text())if(R/'commands.json').exists()else[]
def run(tag,cmd):
  tag=f'{len(records)+1:02d}-'+tag;start=time.monotonic()
  p=subprocess.run(list(map(str,cmd)),cwd=R,capture_output=True,timeout=180)
  (R/(tag+'.stdout.log')).write_bytes(p.stdout);(R/(tag+'.stderr.log')).write_bytes(p.stderr)
  records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start))
  (R/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(tag,p.returncode,p.stdout.decode(errors='replace')[-8000:],p.stderr.decode(errors='replace')[-4000:],flush=True)
  p.check_returncode()
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
(R/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
if not(R/'mlx.metallib').exists():(R/'mlx.metallib').symlink_to(BASE/'mlx.metallib')
run('indexer-compile',[*flags,'-c',R/'src/compute_route_apple/apple_row_cache_indexer.cc','-o',R/'indexer.o'])
cmd=[str(R/'indexer.o')if x==str(BASE/'indexer.o')else str(R/'indexer-test')if x==str(BASE/'indexer-test')else x for x in link]
run('canonical-link',cmd);run('canonical-test',[R/'indexer-test','--gtest_filter=AppleRowCacheIndexer.*:AppleRowCache.*'])
run('perf-compile',[*flags,'-c',R/'perf.cc','-o',R/'perf.o'])
perf=[str(R/'perf.o')if x==str(BASE/'test.o')else str(R/'perf')if x==str(R/'indexer-test')else x for x in cmd]
run('perf-link',perf);run('perf',[R/'perf'])
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(R/'identities.json').write_text(json.dumps([ident(Path(p))for p in cmd if Path(p).is_file()and Path(p).suffix in{'.o','.a','.dylib'}],indent=2)+'\n')
(R/'retain-objects.json').write_text(json.dumps([ident(p)for p in R.glob('*.o')],indent=2)+'\n')
(R/'deletable-artifacts.json').write_text(json.dumps([ident(R/n)for n in['indexer-test','perf']],indent=2)+'\n')
