#include "mla_test_support.h"
#include <hyle/compute/backends/cpu.h>
#include <hyle/compute/providers/native.h>
#include <hyle/graph/batch.h>
#include <hyle/sched/scheduler.h>
#if defined(HYLE_TEST_MLA_APPLE)
#include <hyle/compute/apple_batch.h>
#include <hyle/graph/cpu_apple.h>
#else
#include <hyle/compute/vulkan_batch.h>
#include <hyle/graph/vulkan.h>
#include <hyle/graph/progress.h>
#include <hyle/graph/result.h>
#include <hyle/sched/blocking.h>
#endif

namespace {
namespace c=hyle::compute;namespace g=hyle::graph;
#if defined(HYLE_TEST_MLA_APPLE)
namespace n=c::apple;namespace joint=g::cpu_apple;
#else
namespace n=c::vulkan;
#endif
using hyle::Status;using hyle::Result;
using mla_test::check;using mla_test::encode;
Status oracle_words(c::BatchCapacity cap,c::BatchLayoutVersion layout,
    const std::vector<std::uint16_t>&q,const std::vector<std::uint16_t>&cache,
    const std::vector<std::uint16_t>&words,bool bf){
  HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(hyle::mem::system_resource(),words.size()*2+64));
  HYLE_ASSIGN_OR_RETURN(auto w,pool.allocate(words.size()*2));
  HYLE_RETURN_IF_ERROR(w.view()->write(std::as_bytes(std::span(words))));
  HYLE_ASSIGN_OR_RETURN(auto read,w.publish());return mla_test::oracle(cap,layout,q,cache,read,bf);
}
Status exercise(bool bf,unsigned depth){
  const unsigned heads=depth==576?96:64;
  const c::MlaBatchCapacity mc{.data_type=bf?c::DataType::kBFloat16:c::DataType::kFloat16,
      .layout=depth==576?c::MlaCacheLayout::kCkv512Rope64:c::MlaCacheLayout::kCkv512,
      .max_requests=2,.max_query_rows=4,.max_kv_rows=64,.max_pages=4,.max_page_refs=5,
      .query_heads=heads,.page_size=16};
  HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create_mla(mc));const auto cap=schema.capacity();
  const std::array<std::int32_t,3> qp{0,1,4},kp{0,2,5};
  const std::array<std::int32_t,5> ids{3,1,0,2,1};const std::array<std::int32_t,2> tails{15,1};
  HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({qp,kp,ids,tails}));
  HYLE_ASSIGN_OR_RETURN(auto recipe,c::NativePagedBatchProgram::prepare(schema,{.max_host_metadata_bytes=64,.scale=1.F/16}));
  HYLE_RETURN_IF_ERROR(check(recipe.input_count()==3,"MLA recipe materialized an independent V port"));
  HYLE_ASSIGN_OR_RETURN(auto query_description,recipe.input_description(layout,0));
  HYLE_ASSIGN_OR_RETURN(auto cache_description,recipe.input_description(layout,1));
  HYLE_ASSIGN_OR_RETURN(auto native,n::Context::create());
#if defined(HYLE_TEST_MLA_APPLE)
  HYLE_ASSIGN_OR_RETURN(auto device,n::MemoryResource::create(native));
  HYLE_ASSIGN_OR_RETURN(auto staging,n::MemoryResource::create(native));
#else
  HYLE_ASSIGN_OR_RETURN(auto device,n::MemoryResource::create(native,n::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto staging,n::MemoryResource::create(native,n::MemoryKind::kStaging));
#endif
  struct Close{n::Context&c;~Close(){c.close().IgnoreError();}}close{native};
  std::vector<std::uint16_t> q(std::size_t(4)*heads*depth),cache(64*depth);
  for(std::size_t i=0;i<q.size();++i)q[i]=encode(float(int(i%29)-14)/64,bf);
  for(std::size_t i=0;i<cache.size();++i)cache[i]=encode(float(int((i*13+i/depth)%37)-18)/32,bf);
  HYLE_ASSIGN_OR_RETURN(auto arena,c::PagedArena::create(schema,c::BatchCacheRole::kMla,device.ref(),{.max_backing_bytes=cache.size()*2+1}));
  const auto maximum=std::max(q.size()*2,arena.page_bytes());
  HYLE_ASSIGN_OR_RETURN(auto host_pool,c::LeasePool::create(staging.ref(),maximum+64));
  HYLE_ASSIGN_OR_RETURN(auto device_pool,c::LeasePool::create(device.ref(),q.size()*2+64));
  const std::array specs{c::CopyResourceSpec{staging.ref(),maximum},c::CopyResourceSpec{device.ref(),maximum}};
  HYLE_ASSIGN_OR_RETURN(auto copy_program,n::CopyBatchProgram::prepare(native,specs));
  HYLE_ASSIGN_OR_RETURN(auto copy,n::CopyBatchInvocation::create(copy_program));
  const auto upload=[&](c::WriteLease&&writer,std::span<const std::uint16_t>words)->Result<c::ReadLease>{
    HYLE_RETURN_IF_ERROR(copy.reset());
    HYLE_ASSIGN_OR_RETURN(auto hw,host_pool.allocate(words.size_bytes(),64));
    HYLE_RETURN_IF_ERROR(hw.view()->write(std::as_bytes(words)));HYLE_ASSIGN_OR_RETURN(auto ready,hw.publish());
    HYLE_RETURN_IF_ERROR(copy.bind_source({0},ready));HYLE_RETURN_IF_ERROR(copy.bind_mutable({1},std::move(writer)));
    const std::array<c::CopyPhase,1>phases{{{}}};
    const std::array<c::CopyRange,1>ranges{{{{0},{1},{0},0,0,words.size_bytes()}}};
    HYLE_RETURN_IF_ERROR(copy.prepare_replay(phases,ranges));HYLE_ASSIGN_OR_RETURN(auto done,copy.submit());HYLE_RETURN_IF_ERROR(done.wait());
    return done.output({0},{1},0,words.size_bytes());
  };
  HYLE_ASSIGN_OR_RETURN(auto qw,device_pool.allocate(q.size()*2,64));
  HYLE_ASSIGN_OR_RETURN(auto query,upload(std::move(qw),q));
  std::array<c::ReadLease,4> ready;
  for(unsigned page=0;page<4;++page){
    HYLE_ASSIGN_OR_RETURN(auto writer,arena.acquire(page));
    HYLE_ASSIGN_OR_RETURN(ready[page],upload(std::move(writer.lease()),std::span(cache).subspan(page*16*depth,16*depth)));
    HYLE_RETURN_IF_ERROR(writer.complete(ready[page],16));
  }
  HYLE_ASSIGN_OR_RETURN(auto frame,arena.read(layout,ready));
  HYLE_ASSIGN_OR_RETURN(auto direct,n::PagedBatchInvocation::create(native,recipe,device,staging,{.max_metadata_backing_bytes=4096}));
  HYLE_RETURN_IF_ERROR(direct.prepare_batch(layout));HYLE_RETURN_IF_ERROR(direct.bind(query,frame));
  HYLE_ASSIGN_OR_RETURN(auto done,direct.submit());HYLE_ASSIGN_OR_RETURN(auto result,done.wait());
  std::vector<std::uint16_t> words(std::size_t(4)*heads*512);
#if defined(HYLE_TEST_MLA_APPLE)
  HYLE_ASSIGN_OR_RETURN(auto desc,c::batch_output_description(cap,4));
  HYLE_ASSIGN_OR_RETURN(auto read,device.import_readonly(result->arrays()[0],desc));
  HYLE_RETURN_IF_ERROR(read.view()->read(std::as_writable_bytes(std::span(words))));read={};
#else
  HYLE_RETURN_IF_ERROR(native.download(result->tensors()[0],std::as_writable_bytes(std::span(words))));
#endif
  HYLE_RETURN_IF_ERROR(oracle_words(cap,layout,q,cache,words,bf));result={};done={};
  std::printf("Native MLA D%u H%u %s Direct single cache %zu bytes PASS\n",depth,heads,bf?"BF16":"F16",cache.size()*2);
  HYLE_ASSIGN_OR_RETURN(auto cpu,c::Context::create(c::cpu::device(),c::native::provider()));
  HYLE_ASSIGN_OR_RETURN(auto cpu_queue,cpu.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto qi,builder.input(query_description));
  HYLE_ASSIGN_OR_RETURN(auto ci,builder.input(cache_description));
  HYLE_ASSIGN_OR_RETURN(auto op,g::batch::paged_mla_attention(layout,
      {.scale=recipe.scale(),.causal=recipe.causal(),.window_left=recipe.window_left()}));
  HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(c::Operation::custom(op),std::array{qi,ci}));
  HYLE_ASSIGN_OR_RETURN(auto attention,builder.result(node));
  HYLE_ASSIGN_OR_RETURN(auto neg,builder.add(c::Unary{c::UnaryKind::kNeg},attention));
  HYLE_RETURN_IF_ERROR(builder.publish(attention));HYLE_RETURN_IF_ERROR(builder.publish(neg));
  HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
#if defined(HYLE_TEST_MLA_APPLE)
  const std::array bindings{g::batch::NativePagedNodeBinding{node,recipe,layout,{.max_metadata_backing_bytes=4096}}};
  const joint::Environment env{.cpu=&cpu,.apple=&native,.native=&device};
  HYLE_ASSIGN_OR_RETURN(auto program,joint::compile(graph,env,{.paged_nodes=bindings}));
#else
  constexpr g::ExecutionTargetId native_target{0},cpu_target{1};
  constexpr g::StorageDomainId device_storage{0},host_storage{1};
  HYLE_ASSIGN_OR_RETURN(auto native_source,g::vulkan::execution_source(native));
  HYLE_ASSIGN_OR_RETURN(auto cpu_source,g::ExecutionSource::acquire(cpu));
  const std::array domains{g::StorageDomain{device.ref()},g::StorageDomain{hyle::mem::system_resource()},g::StorageDomain{staging.ref()}};
  const std::array targets{g::ExecutionTarget{native_source,device_storage},g::ExecutionTarget{cpu_source,host_storage}};
  HYLE_ASSIGN_OR_RETURN(auto neg_node,graph.node_id(1));
  const std::array placements{g::NodePlacement{node,native_target,g::PlacementStrength::kRequired},
      g::NodePlacement{neg_node,native_target,g::PlacementStrength::kRequired}};
  const std::array external{g::ExternalResourceContract{qi,device_storage},g::ExternalResourceContract{ci,device_storage},
      g::ExternalResourceContract{attention,device_storage},g::ExternalResourceContract{neg,device_storage}};
  HYLE_ASSIGN_OR_RETURN(auto program,g::batch::compile(graph,{.storage_domains=domains,.targets=targets},
      {.node_placements=placements,.external_resources=external}));
  std::vector<g::QueueBinding> queues;
  for(std::size_t i=0;i<program.report.lane_count();++i){
    HYLE_ASSIGN_OR_RETURN(auto lane,program.report.lane(i));
    if(!lane.queue_required)continue;
    HYLE_RETURN_IF_ERROR(check(lane.target==cpu_target && lane.runtime_mode==c::ProviderRuntimeMode::kSharedQueue,
        "native MLA unexpectedly requires a Compute Queue"));
    queues.push_back({lane.lane,&cpu_queue});
  }
#endif
  hyle::sched::Scheduler scheduler(1,hyle::mem::system_allocator(),32);
#if !defined(HYLE_TEST_MLA_APPLE)
  hyle::sched::BlockingPool waiters(hyle::mem::system_allocator(),1);
#endif
  struct Drain{hyle::sched::Scheduler&s;~Drain(){s.drain();}}drain{scheduler};
#if defined(HYLE_TEST_MLA_APPLE)
  HYLE_ASSIGN_OR_RETURN(auto slot,program.create_invocation(scheduler,cpu_queue));
#else
  HYLE_ASSIGN_OR_RETURN(auto slot,program.executable.create_invocation({.resources=g::ResourceOptions{}}));
  HYLE_RETURN_IF_ERROR(g::prepare_progress(slot,scheduler,waiters));
  const std::array layouts{g::batch::NodeLayout{node,layout}};
  HYLE_RETURN_IF_ERROR(g::batch::prepare(slot,queues,layouts));
#endif
#if defined(HYLE_TEST_MLA_APPLE)
  HYLE_RETURN_IF_ERROR(slot.prepare_batch(std::array{g::batch::NodeLayout{node,layout}}));
  HYLE_RETURN_IF_ERROR(slot.bind(qi,query_description,query));HYLE_RETURN_IF_ERROR(slot.bind(ci,frame));
  HYLE_RETURN_IF_ERROR(slot.prepare_replay());
  HYLE_ASSIGN_OR_RETURN(auto graph_result,slot.run());
#else
  HYLE_RETURN_IF_ERROR(slot.bind(qi,query_description,query));HYLE_RETURN_IF_ERROR(g::batch::bind(slot,ci,frame));
  HYLE_RETURN_IF_ERROR(slot.prepare_replay(queues));
  HYLE_ASSIGN_OR_RETURN(auto graph_done,slot.submit(queues));HYLE_RETURN_IF_ERROR(graph_done.wait());
  HYLE_ASSIGN_OR_RETURN(auto graph_result,slot.result(attention));HYLE_ASSIGN_OR_RETURN(auto negative_result,slot.result(neg));
#endif
  std::vector<std::uint16_t> negative(words.size());
#if defined(HYLE_TEST_MLA_APPLE)
  HYLE_ASSIGN_OR_RETURN(auto output,graph_result->array(attention));
  HYLE_ASSIGN_OR_RETURN(auto graph_read,device.import_readonly(output,desc));
  HYLE_RETURN_IF_ERROR(graph_read.view()->read(std::as_writable_bytes(std::span(words))));
  HYLE_ASSIGN_OR_RETURN(auto negative_array,graph_result->array(neg));
  HYLE_ASSIGN_OR_RETURN(auto neg_read,device.import_readonly(negative_array,desc));
  HYLE_RETURN_IF_ERROR(neg_read.view()->read(std::as_writable_bytes(std::span(negative))));
#else
  HYLE_ASSIGN_OR_RETURN(auto output_lease,graph_result.storage_lease());
  HYLE_ASSIGN_OR_RETURN(auto output_description,graph_result.description());
  HYLE_ASSIGN_OR_RETURN(auto output,device.binding(std::move(output_lease),output_description));
  HYLE_RETURN_IF_ERROR(native.download(output,std::as_writable_bytes(std::span(words))));
  HYLE_ASSIGN_OR_RETURN(auto negative_lease,negative_result.storage_lease());
  HYLE_ASSIGN_OR_RETURN(auto negative_description,negative_result.description());
  HYLE_ASSIGN_OR_RETURN(auto negative_tensor,device.binding(std::move(negative_lease),negative_description));
  HYLE_RETURN_IF_ERROR(native.download(negative_tensor,std::as_writable_bytes(std::span(negative))));
#endif
  HYLE_RETURN_IF_ERROR(oracle_words(cap,layout,q,cache,words,bf));
#if !defined(HYLE_TEST_MLA_APPLE)
  // Both a live Graph result and an escaped native tensor block cold resealing.
  HYLE_RETURN_IF_ERROR(check(!g::batch::prepare(slot,queues,layouts).ok(),"retained Graph result allowed owner resealing"));
  graph_result={};negative_result={};graph_done={};
  HYLE_RETURN_IF_ERROR(check(!g::batch::prepare(slot,queues,layouts).ok(),"escaped native output allowed owner resealing"));
  output={};negative_tensor={};
  HYLE_RETURN_IF_ERROR(g::batch::prepare(slot,queues,layouts));
  HYLE_RETURN_IF_ERROR(slot.bind(qi,query_description,query));
  HYLE_RETURN_IF_ERROR(g::batch::bind(slot,ci,frame));
  HYLE_RETURN_IF_ERROR(slot.prepare_replay(queues));HYLE_RETURN_IF_ERROR(slot.close());
#endif
  for(std::size_t i=0;i<words.size();++i)HYLE_RETURN_IF_ERROR(check(mla_test::decode(negative[i],bf)==-mla_test::decode(words[i],bf),"MLA published intermediate/downstream Neg differs"));
  std::puts("Native MLA two-port Graph + downstream/published intermediate PASS");return Status::Ok();
}
Status run(){
  for(unsigned depth:{512u,576u}){
    HYLE_RETURN_IF_ERROR(exercise(false,depth));
#if defined(HYLE_TEST_MLA_APPLE)
    HYLE_RETURN_IF_ERROR(exercise(true,depth));
#endif
  }return Status::Ok();
}
}
int main(){std::setvbuf(stdout,nullptr,_IONBF,0);const auto status=run();if(status.ok())return 0;char message[768]{};status.ToString(message,sizeof(message));std::fprintf(stderr,"native MLA: %s\n",message);return 1;}
