"""Two current Hyle host owners over the retained MLA 99-object image."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[4]
BASE=ROOT/'.scratch/architecture-refactor-2026-10-18/native-page-semantics/windows'
MLA=OUT.parent/'windows'
OWNERS=['src/graph_batch/materialized_invocation.cc','src/graph_route_vulkan/native_paged_region.cc']
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def identity(path):
    path=Path(path);data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def recipes():
    rows=read(ROOT/'.scratch/architecture-refactor-2026-10-18/native-ready-pages/windows/compile-plan.json')
    result={r['source']:r['command'] for r in rows}
    for row in read(BASE/'commands.json'):
        if row.get('exit')!=0 or not row['tag'].endswith('-compile'):continue
        source=next((p for p in row['command'] if p.lower().endswith('.cc')),None)
        if source:result[Path(source).relative_to(ROOT).as_posix()]=row['command']
    return result
def run(tag,command,timeout=90):
    rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
    stem=f'{len(rows)+1:03d}-{tag}';command=list(map(str,command))
    row=dict(tag=tag,command=command,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
    rows.append(row);write('commands.json',rows)
    compiler=recipes()[OWNERS[0]][0]
    env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler,'CMAKE_C_COMPILER':compiler})
    torch=next(str(Path(p).parent) for p in read(BASE/'matched-link-base.json')['command'] if p.lower().endswith('torch_cpu.lib'))
    env['PATH']=torch+os.pathsep+env.get('PATH','');env['VSLANG']='1033'
    start=time.monotonic();result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout,
        creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT/row['stdout']).write_bytes(result.stdout);(OUT/row['stderr']).write_bytes(result.stderr)
    row.update(exit=result.returncode,seconds=time.monotonic()-start);write('commands.json',rows)
    print(stem,result.returncode,flush=True)
    print(result.stdout.decode(errors='replace')[-7000:]+result.stderr.decode(errors='replace')[-7000:],flush=True)
    return result.returncode
def compile_one(source):
    stem=source.replace('/','--').removesuffix('.cc')
    original=recipes()[source]
    command=[p for p in original if not p.lower().startswith(('/fo','/fd')) and not p.lower().endswith('.cc')
        and 'src\\graph_route_cpu_vulkan' not in p.lower()]
    command.extend([str(ROOT/source),'/Fo'+str(OUT/(stem+'.obj'))])
    before=identity(ROOT/source)
    headers=[identity(ROOT/p) for p in ['include/hyle/compute/operation.h','include/hyle/graph/batch.h',
        'include/hyle/graph/region_provider.h','include/hyle/compute/detail/materialized_native_controller.h',
        'include/hyle/graph/detail/region_access.h','src/graph_batch/native_paged_regions.h']]
    destination=OUT/'sources'/source;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/source,destination)
    code=run(stem+'-compile',command)
    unchanged=identity(ROOT/source)==before and all(identity(h['path'])==h for h in headers)
    receipt=dict(source=before,headers=headers,sources_unchanged=unchanged,command=command,exit=code)
    if not code:receipt['object']=identity(OUT/(stem+'.obj'))
    write(stem+'-receipt.json',receipt)
    return code if code else (0 if unchanged else 1)
def link():
    original=read(MLA/'matched-link-receipt.json')
    baseline=read(BASE/'matched-link-base.json')
    replacements={}
    current={}
    for source in OWNERS:
        row=read(OUT/(source.replace('/','--').removesuffix('.cc')+'-receipt.json'))
        assert row['exit']==0 and row['sources_unchanged'] and identity(ROOT/source)==row['source']
        assert identity(row['object']['path'])==row['object']
        replacements[baseline['selected_sources'][source]]=row['object']['path'];current[source]=row
    # Validate current product .cc identities. Three older inherited header
    # metadata rows were already superseded before the preceding final closure.
    for source,sha in baseline['compiled_source_sha256'].items():
        if source.startswith('tests/') or not source.endswith('.cc') or source in OWNERS:continue
        assert identity(ROOT/source)['sha256']==sha,source+' needs a fresh owner'
    consumer=read(MLA/'compile-receipt.json')
    assert identity(consumer['source']['path'])==consumer['source']
    assert identity(consumer['object']['path'])==consumer['object']
    objects=[]
    for previous in original['inherited_product_objects']:
        assert identity(previous['path'])==previous
        path=replacements.get(previous['path'],previous['path'])
        assert 'graph_route_cpu_vulkan' not in path.lower() and 'graph_route_cpu_apple' not in path.lower()
        objects.append(identity(path))
    assert len(objects)==99 and len(replacements)==2
    flags=[p for p in original['command'][1:] if not p.lower().endswith(('.obj','.lib'))
        and not p.upper().startswith(('/OUT:','/MAP:'))]
    libs=[p for p in original['command'] if p.lower().endswith('.lib')]
    for previous in original['library_identities']:assert identity(previous['path'])==previous
    command=[original['command'][0],'/OUT:'+str(OUT/'public-mla.exe'),'/MAP:'+str(OUT/'public-mla.map'),
        *flags,consumer['object']['path'],*[p['path'] for p in objects],*libs]
    write('matched-link-receipt.json',dict(previous_mla=identity(MLA/'matched-link-receipt.json'),
        inherited_baseline=identity(BASE/'matched-link-base.json'),current_owners=current,
        consumer=consumer,inherited_product_objects=objects,library_identities=original['library_identities'],command=command))
    code=run('public-mla-link',command)
    if not code:
        data=(OUT/'public-mla.map').read_text(encoding='utf-8',errors='replace')
        markers=['@cpu_vulkan@graph@hyle','@cpu_apple@graph@hyle','graph_route_cpu_vulkan.lib','graph_route_cpu_apple.lib']
        hits=[line for line in data.splitlines() if any(marker in line for marker in markers)]
        write('removed-runtime-map-check.json',dict(markers=markers,matches=hits));assert not hits
        write('image-identities.json',[identity(OUT/('public-mla'+suffix)) for suffix in ('.exe','.map','.exp','.lib')])
    return code

if __name__=='__main__':
    action=sys.argv[1]
    if action=='compile':
        for source in OWNERS:
            code=compile_one(source)
            if code:raise SystemExit(code)
    elif action=='link':code=link()
    elif action=='run':code=run('public-mla-run',[OUT/'public-mla.exe'],timeout=180)
    else:raise SystemExit('compile / link / run')
    raise SystemExit(code)
