from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
BUILD=BASE/'a-cpu-apple/selected-graph/source-build'
DATABASE=json.loads((BUILD/'compile_commands.json').read_text())
CARRIER=BASE/'architecture-refactor-20261018-apple-carrier-copy'
OLD=json.loads((CARRIER/'commands.json').read_text())
LINK=next(r['command'] for r in reversed(OLD) if r['tag']=='native-tests-link' and r['exit']==0)

def identity(path):
    path=Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def write(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2)+'\n')

def run(tag,command):
    rows=json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
    stem=f'{len(rows)+1:03d}-{tag}'
    command=list(map(str,command));started=time.monotonic()
    row=dict(tag=tag,command=command,exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log')
    rows.append(row);write('commands.json',rows)
    with (ROOT/row['stdout']).open('wb') as out,(ROOT/row['stderr']).open('wb') as err:
        process=subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err)
        write('live.json',dict(pid=process.pid,tag=tag))
        code=process.wait()
    rows[-1].update(exit=code,seconds=time.monotonic()-started);write('commands.json',rows)
    write('live.json',dict(terminal=True,tag=tag,exit=code))
    print(stem,code,flush=True)
    if code:
        print((ROOT/row['stderr']).read_text(errors='replace')[-9000:],flush=True)
        raise SystemExit(code)

def command(source):
    inherited=None
    if (ROOT/'link-plan.json').exists():
        for row in json.loads((ROOT/'link-plan.json').read_text())['objects']:
            if row['owner'] and row['owner']['logical']==source:
                inherited=row['owner']['command'];break
    candidates=[r for r in DATABASE if r['file'].endswith('/'+source)]
    if not inherited and not candidates and source.startswith('tests/'):
        for row in json.loads((ROOT/'link-plan.json').read_text())['objects']:
            if row['owner'] and row['owner']['logical']=='tests/graph_route_apple/native_region_test.cc':
                inherited=row['owner']['command'];break
    if not candidates:
        template=('tests/graph_route_apple/native_region_test.cc' if source.startswith('tests/') else
                  'src/graph_route_apple/native_region.cc' if 'graph_route_apple' in source else
                  'src/compute_route_apple/apple_context.cc' if 'compute_route_apple' in source or 'compute_stream_apple' in source or source.startswith('samples/') else
                  'src/graph_batch/batch.cc')
        candidates=[r for r in DATABASE if r['file'].endswith('/'+template)]
    if not candidates:
        candidates=[r for r in DATABASE if r['file'].endswith('/src/compute_route_apple/apple_context.cc')]
    assert candidates,source
    original=inherited or candidates[0].get('arguments') or shlex.split(candidates[0]['command'])
    result=[];skip=False
    for arg in original:
        if skip:skip=False;continue
        if arg in {'-c','-o','-MF','-MT','-MQ'}:skip=True;continue
        if arg in {'-MD','-MMD','-MP'}:continue
        result.append(arg)
    result[1:1]=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/graph'),
        '-I'+str(ROOT/'src/compute'),'-I'+str(ROOT/'src/compute_route_apple'),
        '-I'+str(ROOT/'src/compute_provider_ggml'),'-I'+str(ROOT/'src/compute_ggml_runtime'),
        '-I'+str(ROOT/'src/graph_route_apple'),
        '-I'+str(ROOT/'third_party/ds4_quantization'),'-DHYLE_STATIC','-Werror',
        *['-I'+str(ROOT/'third_party'/part) for part in
          ['torchao_cpu','bitsandbytes_cpu','awq_cpu','compressed_tensors_cpu','mlx_cpu_quant']]]
    return result

def compile_one(source):
    name=source.replace('/','--').rsplit('.',1)[0]+'.o'
    flags=['-DHYLE_ENCODED_APPLE=1'] if source=='tests/compute_batch/encoded_page_native_consumer.cc' else []
    if source=='tests/compute_batch/public_mla_native_consumer.cc':flags+=['-DHYLE_TEST_MLA_APPLE=1']
    if source=='tests/graph_batch/native_paged_joint_consumer.cc':flags+=['-DHYLE_JOINT_PAGE_APPLE=1']
    if source=='tests/compute_batch/pending_paged_receiver_native_consumer.cc':
        flags+=['-DHYLE_PENDING_RECEIVER_APPLE=1','-DHYLE_PENDING_NATIVE_JOINT_GRAPH=1']
    if source in {'tests/graph/native_joint_pipeline.cc','tests/graph/pipeline_selected.cc'}:flags+=['-DHYLE_G09_APPLE=1']
    if source=='tests/graph/cpu_completion_publication.cc':flags+=['-DHYLE_COMPLETION_PUBLICATION_APPLE=1']
    if source in {'tests/graph_batch/native_paged_joint_risks.cc','tests/graph_batch/native_pending_joint_risks.cc',
                  'tests/graph_batch/native_multi_pending_risks.cc'}:flags+=['-DHYLE_JOINT_PAGE_APPLE=1']
    run(name+'-compile',command(source)+flags+['-c',ROOT/source,'-o',ROOT/name])
    write(name+'.json',dict(source=identity(ROOT/source),object=identity(ROOT/name)))

def plan():
    rows=[]
    for obj in LINK:
        if not obj.endswith('.o'):continue
        path=Path(obj);found=None
        for directory in [path.parent,*list(path.parents)[1:4]]:
            commands=directory/'commands.json'
            if not commands.exists():continue
            records=json.loads(commands.read_text())
            for row in reversed(records):
                cmd=row.get('command',[])
                if row.get('exit')==0 and obj in cmd and '-c' in cmd:
                    old_source=cmd[cmd.index('-c')+1]
                    logical='src/'+old_source.split('/src/',1)[1] if '/src/' in old_source else 'tests/'+old_source.split('/tests/',1)[1] if '/tests/' in old_source else None
                    found=dict(source=old_source,logical=logical,command=cmd,flags_source=str(commands));break
            if found:break
        rows.append(dict(object=identity(obj),owner=found))
    write('link-plan.json',dict(command=LINK,objects=rows))
    print('link objects',len(rows),'recognized owners',sum(bool(r['owner']) for r in rows),flush=True)

def link(kind):
    selections={
      'native-tests':['tests/compute_route_apple/late_input_test.cc',
          'tests/graph_route_apple/mixed_region_test.cc','tests/graph_route_apple/native_region_test.cc'],
      'source-tests':['tests/graph_route_apple/configured_source_test.cc','tests/graph_route_apple/weight_binding_test.cc'],
      'frontier-tests':['tests/graph/input_source_frontier_test.cc'],
      'page-consumer':['tests/graph_route_apple/paged_region_consumer.cc'],
      'encoded-tests':['tests/compute_batch/encoded_page_native_consumer.cc'],
      'mixed-sampling':['tests/graph_route_cpu_apple/sampling_consumer.cc'],
      'package-sample':['samples/package/graph/cpu_apple/main.cc'],
      'public-mla':['tests/compute_batch/public_mla_native_consumer.cc'],
      'ready-page':['tests/graph_batch/native_paged_joint_consumer.cc'],
      'pending-page':['tests/compute_batch/pending_paged_receiver_native_consumer.cc'],
      'pipeline-selected':['tests/graph/pipeline_selected.cc'],
      'apple-contracts':['tests/graph/cpu_apple_contracts.cc'],
      'completion-publication':['tests/graph/cpu_completion_publication.cc'],
      'node-descriptor-tests':['tests/graph_batch/native_paged_node_test.cc'],
      'ready-risks':['tests/graph_batch/native_paged_joint_risks.cc'],
      'pending-risks':['tests/graph_batch/native_pending_joint_risks.cc'],
      'multi-pending-risks':['tests/graph_batch/native_multi_pending_risks.cc'],
      'packed-weights':['tests/graph_route_cpu_apple/packed_weight_test.cc'],
      'file-stream':['tests/compute_route_apple/file_stream_test.cc'],
      'stream-sample':['samples/package/compute_stream/cpp/main.cc'],
      'route-effects':['tests/graph/route_effects_test.cc'],
      'public-effects':['tests/graph/public_effect_consumer.cc']}
    selected=selections[kind]
    products=[];tests=[]
    for receipt in sorted(ROOT.glob('*.o.json')):
        row=json.loads(receipt.read_text());source=Path(row['source']['path'])
        assert row['source']==identity(source),str(source)+' changed'
        assert row['object']==identity(row['object']['path']),str(receipt)+' object changed'
        logical=source.relative_to(ROOT).as_posix()
        if logical.startswith('src/'):
            products.append(row['object']['path'])
        elif logical in selected:
            tests.append(row['object']['path'])
    assert len(tests)==len(selected),tests
    inherited=json.loads((ROOT/'link-plan.json').read_text())
    sdk=[]
    for row in inherited['objects']:
        owner=row['owner'];path=Path(row['object']['path'])
        logical=owner['logical'] if owner else None
        # All Hyle product/test owners were refreshed. The remaining objects
        # are the original pinned ggml/MLX host wrappers, never a joint Graph.
        if logical and (ROOT/logical).is_file():continue
        if not owner and path.name.startswith('ops'):continue
        assert row['object']==identity(path),str(path)+' retained object changed'
        sdk.append(str(path))
    command=[LINK[0],*products,*tests,*sdk]
    skip=False
    for arg in LINK[1:]:
        if skip:skip=False;continue
        if arg=='-o':skip=True;continue
        if arg.endswith('.o') or arg.startswith('-Wl,-map,'):continue
        if arg.endswith('/libhyle_graph_route_cpu_apple.a'):continue
        if kind not in {'native-tests','source-tests','encoded-tests','frontier-tests','packed-weights','route-effects','node-descriptor-tests','file-stream'} and ('/libgtest.a' in arg or '/libgtest_main.a' in arg):continue
        command.append(arg)
    if kind in {'file-stream','stream-sample'}:
        stream_lib_directory=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib')
        for name in ['libhyle_io_core.a','libhyle_platform_fs.a']:
            if str(stream_lib_directory/name) not in command:command.append(str(stream_lib_directory/name))
    command+=['-o',str(ROOT/kind),'-Wl,-map,'+str(ROOT/(kind+'.map'))]
    write(kind+'-link-inputs.json',dict(fresh_products=[identity(p) for p in products],
          fresh_tests=[identity(p) for p in tests],retained_sdk=[identity(p) for p in sdk]))
    run(kind+'-link',command)
    map_text=(ROOT/(kind+'.map')).read_text()
    assert 'libhyle_graph_route_cpu_apple.a(' not in map_text,'old joint Graph appeared in link map'
    write(kind+'-identities.json',[identity(ROOT/kind),identity(ROOT/(kind+'.map'))])

def execute(kind):
    sdk=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
    resource=ROOT/'mlx.metallib'
    if not resource.exists():resource.symlink_to(sdk/'lib/mlx.metallib')
    command=[ROOT/kind]
    if kind=='native-tests':command+=['--gtest_filter=AppleNativeRegion.*:AppleLateInput.*:AppleMixedRegion.*']
    if kind=='route-effects':command+=['--gtest_filter=FoundationEffects.*']
    if kind=='ready-page':command+=['64','1']
    run(kind+'-run',command)

def old_copy_key():
    source=ROOT/'src/graph_route_apple/execution_source.cc'
    original=source.read_bytes()
    old='ca::detail::copy_recording_matches_source(*slot.recording, source)'
    new=('slot.reference.vtable == inputs[0].reference.vtable && '
         'slot.reference.prepared == inputs[0].reference.prepared && '
         'slot.reference.invocation == inputs[0].reference.invocation && '
         'slot.reference.port == inputs[0].reference.port')
    text=original.decode();assert text.count(old)==1
    try:
        source.write_text(text.replace(old,new))
        (ROOT/'old-copy-key-source.txt').write_bytes(source.read_bytes())
        compile_one('src/graph_route_apple/execution_source.cc')
        link('page-consumer')
        run('old-copy-key-negative-control',[ROOT/'page-consumer'])
    finally:source.write_bytes(original)

def freeze():
    objects=[json.loads(p.read_text()) for p in sorted(ROOT.glob('*.o.json'))]
    for row in objects:
        assert row['source']==identity(row['source']['path'])
        assert row['object']==identity(row['object']['path'])
    headers=[identity(p) for top in ['include','src','third_party']
             for p in sorted((ROOT/top).rglob('*.h'))]
    # Images from earlier frozen rounds were reclaimed. Keep one fixed cache
    # of objects and freeze only this round's actual remaining linked images.
    kinds=sorted(p.stem for p in ROOT.glob('*.map') if (ROOT/p.stem).is_file())
    commands=json.loads((ROOT/'commands.json').read_text())
    final_links=[next(row for row in reversed(commands) if row['tag']==name+'-link' and row['exit']==0)
                 for name in kinds]
    libraries=sorted({p for row in final_links for p in row['command'] if p.endswith(('.a','.dylib'))})
    write('final-source-identities.json',dict(compiled_owners=objects,headers=headers,
          actual_reused_libraries=[identity(p) for p in libraries]))
    files=[];maps={}
    for name in kinds:
        text=(ROOT/(name+'.map')).read_text()
        objects_text=text.split('# Object files:',1)[1].split('# Sections:',1)[0]
        (ROOT/(name+'-map-objects.txt')).write_text(objects_text)
        maps[name]=dict(old_joint_present='libhyle_graph_route_cpu_apple.a(' in text,
            loaded_old_graph_members=[line for line in objects_text.splitlines()
              if 'libhyle_graph.a(' in line or 'libhyle_graph_route_apple.a(' in line])
        assert not maps[name]['old_joint_present']
        assert not maps[name]['loaded_old_graph_members'],maps[name]
        files += [identity(ROOT/name),identity(ROOT/(name+'.map'))]
    write('map-check.json',maps)
    write('cleanup.json',dict(root=str(ROOT),files=files,
          retain=[row['object'] for row in objects]))
    print('frozen',len(objects),'compiled owners;',len(headers),'headers;',
          sum(row['bytes'] for row in files),'reproducible image/map bytes',flush=True)

assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
(ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
if __name__=='__main__':
    action,*items=sys.argv[1:]
    if action=='compile':
        for source in items:compile_one(source)
    elif action=='plan':plan()
    elif action=='link':link(*items)
    elif action=='run':execute(*items)
    elif action=='old-copy-key':old_copy_key()
    elif action=='freeze':freeze()
    elif action=='host':
        for source in json.loads((ROOT/'host-sources.json').read_text()):
            if source.startswith('src/graph_route_apple/'):continue
            name=source.replace('/','--').rsplit('.',1)[0]+'.o.json'
            if (ROOT/name).exists() and json.loads((ROOT/name).read_text())['source']==identity(ROOT/source):continue
            compile_one(source)
    else:raise SystemExit('compile <sources> / plan')
