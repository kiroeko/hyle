#define HYLE_PENDING_MULTI_NATIVE_PRODUCERS 1
#include "native_pending_joint_risks.cc"
