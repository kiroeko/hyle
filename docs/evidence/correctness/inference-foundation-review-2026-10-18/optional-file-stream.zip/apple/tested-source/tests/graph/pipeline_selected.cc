// Run original heavy cases individually; geometry and iteration counts are
// exactly those in native_joint_pipeline.cc::contracts, without its full matrix.
#define main original_pipeline_matrix_main
#include "tests/graph/native_joint_pipeline.cc"
#undef main
#include <string_view>

int main(int argc,char**argv){
  if(argc!=2)return 2;
  const auto run=[&]()->Status{
    HYLE_ASSIGN_OR_RETURN(auto cpu,g::cpu::create_context());
    HYLE_ASSIGN_OR_RETURN(auto native,n::Context::create());
    HYLE_ASSIGN_OR_RETURN(auto memory,n::MemoryResource::create(native));
    const PipelineResources resources{cpu,native,memory};
    const std::string_view selected=argv[1];
    if(selected=="cpu-first-1")return branches(resources,true,1,false);
    if(selected=="resident-two-native")return branches(resources,false,1,true,8,2,nullptr,false,true);
    return Status::InvalidArgument("unknown original pipeline case");
  };
  const auto status=run();
  if(status.ok())return 0;
  std::fprintf(stderr,"pipeline selected: %.*s\n",int(status.message().size()),status.message().data());return 1;
}
