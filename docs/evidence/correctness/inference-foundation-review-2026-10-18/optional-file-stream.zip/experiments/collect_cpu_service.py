from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
BUILD = STAGE / 'cpu-service-build'
PREFIX = STAGE / 'cpu-service-prefix'
CONSUMER = STAGE / 'cpu-service-consumer'


def identity(path):
    path = path.resolve()
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(name, value):
    (STAGE / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


commands = json.loads((STAGE / 'cpu-service-commands.json').read_text())
runs = [row for row in commands if row['label'].endswith('consumer-run')]
assert [row['exit_code'] for row in runs] == [1, 1, 1, 0, 0]
assert '512 bytes each, 128 staging bytes' in (STAGE / runs[-1]['stdout']).read_text()
assert 'create_file_pipeline@cpu@compute' in (STAGE / '17-cpu-service-bridge-exports.stdout.log').read_text()
assert 'create_file_pipeline' not in (STAGE / '18-cpu-service-common-exports.stdout.log').read_text()

compile_rows = json.loads((BUILD / 'compile_commands.json').read_text())
consumer_rows = json.loads((CONSUMER / 'compile_commands.json').read_text())
source_rows = []
objects = []
for row in compile_rows + consumer_rows:
    source_rows.append(identity(Path(row['file'])))
    objects.append({'source': str(Path(row['file']).resolve()), **identity(Path(row['output']))})
write('cpu-service-source-identities.json', source_rows)
write('cpu-service-retained-objects.json', objects)

key_sources = [
    'cmake/HyleComponents.cmake', 'cmake/HyleComputeRoutes.cmake',
    'cmake/HylePackage.cmake', 'cmake/HyleConfig.cmake.in',
    'include/hyle/compute/cpu_file_stream.h', 'include/hyle/compute/file_stream.h',
    'include/hyle/compute/detail/file_stream_copy.h',
    'src/compute_stream_cpu/file_stream.cc', 'src/compute_stream_cpu/CMakeLists.txt',
    'src/compute_stream/file_stream.cc', 'src/compute_stream/CMakeLists.txt',
    'src/compute/batch_transfer.cc',
    'samples/package/compute_stream/cpp/main.cc',
    'samples/package/compute_stream/cpp/CMakeLists.txt',
]
snapshots = []
for name in key_sources:
    path = ROOT / name
    data = path.read_bytes()
    output = STAGE / 'cpu-service-source' / name
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(data)
    snapshots.append({'relative': name, **identity(path)})
write('cpu-service-key-source-identities.json', snapshots)

libraries = [identity(path) for path in sorted((BUILD / 'bin').glob('hyle_*.dll'))]
assert len(libraries) == 15
assert not any(any(token in row['path'] for token in ('provider_', 'graph', 'route_')) for row in libraries)
for path in CONSUMER.glob('*.dll'):
    assert path.read_bytes() == (PREFIX / 'bin' / path.name).read_bytes()
assert not (PREFIX / 'include/hyle/compute/cpu.h').exists()
assert not (PREFIX / 'include/hyle/graph').exists()
assert (PREFIX / 'include/hyle/compute/cpu_file_stream.h').exists()
write('cpu-service-libraries.json', libraries)

installed = [path.resolve() for path in PREFIX.rglob('*') if path.is_file()]
manifest = [Path(line).resolve() for line in (BUILD / 'install_manifest.txt').read_text().splitlines()]
assert set(installed) == set(manifest)
images = [path.resolve() for path in CONSUMER.iterdir()
          if path.is_file() and path.suffix.lower() in {'.exe', '.dll', '.map', '.exp', '.lib', '.pdb'}]
cleanup_files = sorted(set(installed + images))
assert all(path.is_relative_to(PREFIX) or path.parent == CONSUMER for path in cleanup_files)
assert not set(cleanup_files).intersection(Path(row['path']) for row in objects)
cleanup = {
    'stage': str(STAGE), 'files': [identity(path) for path in cleanup_files],
    'count': len(cleanup_files), 'bytes': sum(path.stat().st_size for path in cleanup_files),
    'installed_copy_count': len(installed), 'consumer_image_count': len(images),
    'retain_build_cache': str(BUILD), 'retained_object_count': len(objects),
    'delete_executed': False,
}
write('cpu-service-cleanup-candidates.json', cleanup)
summary = {
    'status': 'shared_cpu_service_installed_consumer_passed',
    'requested_product': 'compute_stream', 'routes': ['cpu'], 'linkage': 'shared',
    'offline': True, 'sdk_or_numerical_kernel_build': False,
    'graph_default_route_or_math_provider': False,
    'initial_build_seconds': commands[1]['seconds'],
    'collection_fix_incremental_build_seconds': next(row['seconds'] for row in commands if row['label'] == '13-cpu-service-build'),
    'producer_settle_fix_incremental_build_seconds': next(row['seconds'] for row in commands if row['label'] == '19-cpu-service-build'),
    'final_batch_transfer_source_sha256': identity(ROOT / 'src/compute/batch_transfer.cc')['sha256'],
    'service_compile_units': len(compile_rows), 'consumer_compile_units': len(consumer_rows),
    'final_run': runs[-1]['label'], 'final_stdout': runs[-1]['stdout'],
    'raw_result': 'CPU: file + mapping roundtrips verified, 512 bytes each, 128 staging bytes',
    'factory_export_owner': 'hyle_compute_stream_cpu.dll',
    'common_dll_does_not_export_factory': True,
    'failure_history': [
        {'run': runs[0]['label'], 'cause': '4096-byte target backing plus 128-byte staging exceeds unchanged 4096-byte total budget'},
        {'run': runs[1]['label'], 'cause': 'after pool reduced to 512 bytes, single-pass collect left completed read retained by write request'},
        {'run': runs[2]['label'], 'cause': 'diagnostic confirms 512/512 lease bytes, one block, zero uses, one request, zero slots, 640 backing bytes'},
    ],
    'repair': 'original budget retained; root changed reclamation to gated write pass then read pass, no fixed-point loop or allocation',
    'final_core_refresh': '19 rebuilt only batch_transfer.cc and hyle_compute.dll; 20 installed the new core DLL',
    'last_consumer_build': '21 copied the updated installed core DLL; unchanged source/object reused after 11 fresh diagnostic compile',
    'cleanup_candidate': 'cpu-service-cleanup-candidates.json',
    'cleanup_count': cleanup['count'], 'cleanup_bytes': cleanup['bytes'],
    'retained_build_cache': str(BUILD), 'retained_objects': len(objects),
    'limits': 'CPU shared service only; no static/native-backend delivery or performance claim; no deletion performed',
}
write('cpu-service-summary.json', summary)
write('cpu-service-receipt.json', {name: identity(STAGE / name) for name in [
    'cpu-service-summary.json', 'cpu-service-commands.json', 'cpu-service-closure.json',
    'cpu-service-libraries.json', 'cpu-service-retained-objects.json',
    'cpu-service-source-identities.json', 'cpu-service-key-source-identities.json',
    'cpu-service-cleanup-candidates.json']})
print(json.dumps(summary, indent=2))
