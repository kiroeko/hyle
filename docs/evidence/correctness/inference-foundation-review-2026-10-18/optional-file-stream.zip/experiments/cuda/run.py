from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys, time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
PROBE=ARCH/'qwen-numerical-localization/actual-f32-probe'
WINDOWS=ARCH/'optional-file-stream/windows'
spec=importlib.util.spec_from_file_location('probe_environment',PROBE/'run.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):
 path=Path(path);return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
def run(tag,command,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';cmd=list(map(str,command));print('START',stem,flush=True)
 row=dict(tag=tag,command=cmd,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
 rows.append(row);save('commands.json',rows);start=time.monotonic()
 with (OUT/row['stdout']).open('wb') as so,(OUT/row['stderr']).open('wb') as se:
  result=subprocess.run(cmd,cwd=OUT,env=p.env(),stdout=so,stderr=se,timeout=timeout)
 row.update(exit=result.returncode,seconds=time.monotonic()-start);save('commands.json',rows)
 print('END',stem,result.returncode,flush=True)
 if result.returncode:
  print((OUT/row['stdout']).read_text(errors='replace')[-12000:]);print((OUT/row['stderr']).read_text(errors='replace')[-12000:]);raise SystemExit(result.returncode)
 return row

SOURCES=dict(factory='src/compute_stream_cuda/file_stream.cc',
 common='src/compute_stream/file_stream.cc',sources='src/compute_stream/stream_sources.cc',
 tests='tests/compute_route_cuda/file_stream_test.cc')
def compile_():
 template=read(PROBE/'compile-recipes.json')[0]['command']
 flags=[v for v in template[1:] if not v.lower().startswith(('/fo','/fd')) and not v.lower().endswith('.cc')]
 rows=[]
 for name,source in SOURCES.items():
  obj=OUT/(name+'.obj');before=identity(ROOT/source)
  snapshot=OUT/'source'/source;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes((ROOT/source).read_bytes())
  cmd=[template[0],*flags,str(ROOT/source),'/Fo'+str(obj)]
  run(name+'-compile',cmd)
  assert identity(ROOT/source)==before
  rows.append(dict(source=before,object=identity(obj),command=cmd))
  save('fresh-identities.json',rows)
def compile_fix():
 history=read(ARCH/'native-ready-pages/windows/commands.json')
 old=next(r['command'] for r in reversed(history) if r['exit']==0 and
          any(Path(v).name.lower()=='batch_transfer.cc' for v in r['command']))
 source=ROOT/'src/compute/batch_transfer.cc';before=identity(source)
 command=[('/Fo'+str(OUT/'batch-transfer-final.obj')) if v.lower().startswith('/fo') else v for v in old]
 run('batch-transfer-final-compile',command)
 assert identity(source)==before
 target=OUT/'source/src/compute/batch_transfer.cc';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
 save('batch-transfer-final-identity.json',dict(source=before,object=identity(OUT/'batch-transfer-final.obj'),command=command))
def link():
 direct=read(PROBE/'link-plan.json')['command'];expected={r['path']:r for r in read(PROBE/'link-identities.json')}
 for arg in direct:
  if arg in expected:assert identity(arg)==expected[arg],arg
 args=[]
 for v in direct[1:]:
  if v.upper().startswith(('/OUT:','/MAP:')) or v==str(PROBE/'probe.obj'):continue
  # Existing mathematics/kernel cache is unchanged. No legacy file-stream
  # factory archive is linked; the new factor's explicit object owns it.
  if Path(v).name.lower()=='hyle_compute_route_cuda.lib':raise AssertionError('legacy route archive unexpectedly requested')
  if Path(v).name.lower()=='compute--batch_transfer.obj' and (OUT/'batch-transfer-final.obj').exists():v=str(OUT/'batch-transfer-final.obj')
  args.append(v)
 extra=[str(OUT/(n+'.obj')) for n in SOURCES]
 extra.append(str(ARCH/'../perf-review-2026-10-18/blocking-pool/candidate.obj'))
 # These are the exact Scheduler/IO/file-system libraries already used by the
 # successful current CPU/Vulkan file-stream tests, not another SDK build.
 old=next(r['command'] for r in reversed(read(WINDOWS/'commands.json')) if r['tag']=='cpu_tests-link' and r['exit']==0)
 names={'hyle_io_core.lib','hyle_sched.lib','hyle_mem_vm.lib','hyle_platform_fs.lib','gtest_main.lib','gtest.lib','mswsock.lib','kernel32.lib'}
 extra += [v for v in old if Path(v).name.lower() in names]
 args=list(dict.fromkeys(extra+args))
 objects=[v for v in args if v.lower().endswith('.obj')];rest=[v for v in args if not v.lower().endswith('.obj')]
 cmd=[direct[0],*objects,*rest,'/OUT:'+str(OUT/'cuda-tests.exe'),'/MAP:'+str(OUT/'cuda-tests.map')]
 save('link-plan.json',dict(command=cmd,base=str(PROBE/'link-plan.json'),io_source=str(WINDOWS/'commands.json')+': last cpu_tests-link exit0'))
 save('link-identities.json',[identity(v) for v in cmd if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}])
 run('cuda-tests-link',cmd)
 audit()
def audit():
 text=(OUT/'cuda-tests.map').read_text(errors='replace')
 factory=[x.strip() for x in text.splitlines() if '?create_file_pipeline@cuda@compute@hyle@@' in x and '$unwind$' not in x]
 assert len(factory)==1 and factory[0].endswith('factory.obj'),factory
 assert 'file_stream.cc.obj' not in '\n'.join(factory)
 save('factory-owner.json',dict(symbols=factory,object=identity(OUT/'factory.obj'),source=identity(ROOT/SOURCES['factory']),legacy_route_factory_selected=False))
def execute():
 run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
 run('cuda-tests-run',[OUT/'cuda-tests.exe','--gtest_filter=CudaFileStream.*','--gtest_color=no','--gtest_output=xml:'+str(OUT/'tests.xml')],timeout=120)
def freeze():
 rows=read(OUT/'fresh-identities.json')
 for row in rows:assert identity(row['source']['path'])==row['source'];assert identity(row['object']['path'])==row['object']
 headers=['include/hyle/compute/cuda_file_stream.h','include/hyle/compute/file_stream.h',
 'include/hyle/compute/detail/file_stream_access.h','include/hyle/compute/detail/file_stream_copy.h',
 'include/hyle/compute/detail/copy_stream_access.h','tests/compute_stream/native_journey.h',
 'include/hyle/compute/batch_transfer.h','include/hyle/compute/detail/queue_sequence.h']
 save('header-identities.json',[identity(ROOT/h) for h in headers])
 fixed=read(OUT/'batch-transfer-final-identity.json')
 assert identity(fixed['source']['path'])==fixed['source'];assert identity(fixed['object']['path'])==fixed['object']
 images=[identity(v) for v in sorted(OUT.iterdir()) if v.suffix.lower() in {'.exe','.map','.exp','.lib'}]
 save('cleanup-identities.json',images)
 save('retained-object-identities.json',[identity(v) for v in sorted(OUT.glob('*.obj'))])
 import xml.etree.ElementTree as ET
 suites=ET.parse(OUT/'tests.xml').getroot();assert int(suites.attrib['tests'])==7 and int(suites.attrib['failures'])==0
 summary=dict(result='PASS',tests=7,failed=0,scope='Original CudaFileStream.*: original GPU read/write 2groups/2slots/3replays, later EOF, pending producer order, cancellation, abandonment, failed normal/empty producers, failed prefix plus unstarted suffix retirement.',
 fresh_host_tus=list(SOURCES.values())+['src/compute/batch_transfer.cc'],math='No SDK/CUDA kernel rebuild. Reused the frozen actual-f32-probe Direct CUDA owned-Operation/Provider16 host and numerical native closure; no math provider was selected by these bare-backend copy tests.',
 corrected_source=fixed,
 failure_history=dict(original='007-cuda-tests-run:6/7, pending successful producer returned error',status='010-pending-diagnostic-run:lease has admitted native uses',exact_location='013-factory-diagnostic-run:stream mutable source take_mutable:lease has admitted native uses',cause='Original GPU producer Completion still retained its write-use guard after the dependent copy prefix completed. Device waits do not settle the original host Completion. Recovery is now permitted only after a nonblocking poll of the actual producer referenced by an accepted phase, with pending/errors retaining the original binding.',diagnostics='Scratch-only assertion Status context and scratch-only factory error context; originals never modified.'),
 common_reclamation='Current shared file_stream.cc includes the two fixed write-first/read-second reclaim passes.',factory=read(OUT/'factory-owner.json'),
 evidence=['commands.json','tests.xml','fresh-identities.json','header-identities.json','link-plan.json','link-identities.json'],
 cleanup_candidates='cleanup-identities.json; root test.ps1 only; no deletion performed',objects_retained='retained-object-identities.json',
 unchanged_probe_stage=str(PROBE),run=next(r for r in reversed(read(OUT/'commands.json')) if r['tag']=='cuda-tests-run'))
 save('summary.json',summary)
 (OUT/'summary.md').write_text('CUDA file bridge: original **7/7 CudaFileStream tests PASS** on the actual RTX4070 (017 run, 015 link). Four specified Hyle host TUs freshly compiled with /W4 /WX, plus the root-fixed batch_transfer.cc (014). Existing Compute host and native numerical caches reused. The linked factory is explicitly `factory.obj` from `src/compute_stream_cuda/file_stream.cc`, verified in `factory-owner.json`; no legacy route factory is selected. Current shared source contains the two-pass reclaim fix.\n\nThe first original run (007) was 6/7. Scratch-only diagnostics (010/013) identified the exact source writer recovery failure: the original GPU producer Completion retained its lease-use guard after the dependent copy prefix retired. Root fixed recovery to nonblockingly poll only the actual current producer referenced by the accepted phase prefix before checking writer uniqueness. Pending/error paths retain the binding. Original product/test source was not edited by this agent, no sleeps/assertion relaxation were introduced, and all initial failures remain in the logs.\n\nNo kernel/SDK rebuild or deletion. Exact commands, sources, header/object/library identities, original gtest XML and image/map cleanup candidates are retained. The original numerical probe stage was not modified.\n',encoding='utf-8')
 print(json.dumps(dict(summary=identity(OUT/'summary.json'),cleanup=identity(OUT/'cleanup-identities.json'),images=images),indent=2))

if __name__=='__main__':
 OUT.mkdir(parents=True,exist_ok=True)
 {'compile':compile_,'fix':compile_fix,'link':link,'audit':audit,'run':execute,'freeze':freeze}[sys.argv[1]]()
