import run as m

header=m.OUT/'diagnostic-include/hyle/compute/detail/file_stream_copy.h'
header.parent.mkdir(parents=True,exist_ok=True)
raw=(m.ROOT/'include/hyle/compute/detail/file_stream_copy.h').read_text()
raw=raw.replace('HYLE_ASSIGN_OR_RETURN(destination, Access::take_mutable(slot.invocation, destination_id));',
 'auto dst_result = Access::take_mutable(slot.invocation, destination_id); if (!dst_result) return dst_result.error().WithContext("stream destination take_mutable"); destination = std::move(*dst_result);')
raw=raw.replace('HYLE_ASSIGN_OR_RETURN(*mutable_source, Access::take_mutable(slot.invocation, source_id));',
 'auto src_result = Access::take_mutable(slot.invocation, source_id); if (!src_result) return src_result.error().WithContext("stream mutable source take_mutable"); *mutable_source = std::move(*src_result);')
header.write_text(raw)
r=next(x for x in m.read(m.OUT/'fresh-identities.json') if 'compute_stream_cuda' in x['source']['path'])
cmd=[r['command'][0],'/I'+str(m.OUT/'diagnostic-include'),
 *[('/Fo'+str(m.OUT/'factory-diagnostic.obj')) if x.lower().startswith('/fo') else x for x in r['command'][1:]]]
m.run('factory-diagnostic-compile',cmd)
m.save('diagnostic-factory-source.json',dict(original=m.identity(m.ROOT/'include/hyle/compute/detail/file_stream_copy.h'),scratch=m.identity(header),
 delta='only contextualize original source/destination take_mutable error; no lease/order behavior changed',command=cmd))
cmd=m.read(m.OUT/'diagnostic-link.json')['command']
cmd=[str(m.OUT/'factory-diagnostic.obj') if x==str(m.OUT/'factory.obj') else x for x in cmd]
m.run('factory-diagnostic-link',cmd)
m.run('factory-diagnostic-run',[m.OUT/'pending-diagnostic.exe',
 '--gtest_filter=CudaFileStream.PendingOriginalProducerOrdersReadbackBeforeAnyFileWrite','--gtest_color=no'])
