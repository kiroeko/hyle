from pathlib import Path
import importlib.util
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
path = ROOT / '.scratch/architecture-refactor-2026-10-18/apple-page-invocation/air.py'
spec = importlib.util.spec_from_file_location('air', path)
air = importlib.util.module_from_spec(spec)
spec.loader.exec_module(air)
code = '''from pathlib import Path
import json
root=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
sdk=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib')
print(json.dumps([str(p) for base in [root,sdk] for p in base.rglob('*.a')
    if p.name in {'libhyle_io_core.a','libhyle_platform_fs.a','libhyle_container_queue.a'}]))
'''
result = air.ssh(code)
(OUT / 'air-libraries.stdout.log').write_bytes(result.stdout)
(OUT / 'air-libraries.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'))
sys.exit(result.returncode)
