param([switch]$ReclaimInferenceRound)
# Exact temporary images only. Previous helpers are preserved with the source/results archive.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not $ReclaimInferenceRound) { throw 'Specify -ReclaimInferenceRound; no default deletion.' }
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/optional-file-stream/root'
function Get-CheckedFile($entry) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $entry.path))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $ancestor = [IO.Path]::GetDirectoryName($path)
    while ($ancestor -eq $workspace -or $ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        if ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked ancestor: $ancestor" }
        $ancestor = [IO.Path]::GetDirectoryName($ancestor)
    }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        $item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) {
        throw "File changed: $path"
    }
    return $item
}
$receipts = Get-Content -LiteralPath (Join-Path $stage 'archive-receipts.json') -Raw | ConvertFrom-Json
$evidence = Get-CheckedFile $receipts.service
$null = Get-CheckedFile $receipts.numerical
$planPath = Join-Path $stage 'cleanup-plan.json'
$zip = [IO.Compression.ZipFile]::OpenRead($evidence.FullName)
try {
    $entry = $zip.GetEntry('cleanup-plan.json')
    if (-not $entry) { throw 'Missing preserved cleanup plan' }
    $reader = [IO.StreamReader]::new($entry.Open())
    try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if ($frozen -cne [IO.File]::ReadAllText($planPath)) { throw 'Cleanup differs from archive' }
} finally { $zip.Dispose() }
$plan = $frozen | ConvertFrom-Json
$base = '.scratch/architecture-refactor-2026-10-18/'
$imageDirs = @('optional-file-stream/windows', 'optional-file-stream/cuda', 'qwen-numerical-localization/actual-f32-probe') |
    ForEach-Object { [IO.Path]::GetFullPath((Join-Path $workspace ($base + $_))) }
$installDir = [IO.Path]::GetFullPath((Join-Path $workspace ($base + 'optional-file-stream/cpu-service-prefix'))) + [IO.Path]::DirectorySeparatorChar
$consumerDir = [IO.Path]::GetFullPath((Join-Path $workspace ($base + 'optional-file-stream/cpu-service-consumer')))
$buildDir = [IO.Path]::GetFullPath((Join-Path $workspace ($base + 'optional-file-stream/cpu-service-build'))) + [IO.Path]::DirectorySeparatorChar
$targets = @()
foreach ($row in $plan.windows.files) {
    $item = Get-CheckedFile $row
    $image = $item.DirectoryName -in $imageDirs -and $item.Extension -in @('.exe', '.map', '.exp', '.lib')
    $installed = $item.FullName.StartsWith($installDir, [StringComparison]::OrdinalIgnoreCase)
    $consumer = $item.DirectoryName -eq $consumerDir -and $item.Extension -in @('.exe', '.dll')
    if (-not ($image -or $installed -or $consumer)) { throw "Unexpected cleanup target: $item" }
    $targets += $item
}
foreach ($row in $plan.windows.retain) {
    $item = Get-CheckedFile $row
    if ($item.Extension -ne '.obj' -or -not ($item.DirectoryName -in $imageDirs -or
            $item.FullName.StartsWith($buildDir, [StringComparison]::OrdinalIgnoreCase) -or
            $item.FullName.StartsWith($consumerDir + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase))) {
        throw "Unexpected retained object: $item"
    }
}
if (@($targets.FullName | Select-Object -Unique).Count -ne $targets.Count) { throw 'Duplicate cleanup target' }
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($plan.mac | ConvertTo-Json -Depth 12 -Compress)))
$remoteScript = @'
from pathlib import Path
import base64,hashlib,json,subprocess
plan=json.loads(base64.b64decode('__MANIFEST__'))
root=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation')
assert Path(plan['root'])==root and root.resolve(strict=True)==root
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
assert json.loads((root/'live.json').read_text())['terminal']
targets=[]
for row in plan['files']+plan['retain']:
 p=Path(row['path'])
 assert p.parent==root and not p.is_symlink() and p.resolve(strict=True).parent==root
 assert p.is_file() and p.stat().st_size==row['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
 if row in plan['files']:
  assert p.name in {'file-stream','file-stream.map','stream-sample','stream-sample.map'}
  targets.append(p)
 else:assert p.suffix=='.o'
assert len(targets)==4 and len(set(targets))==4
for p in targets:p.unlink()
result=dict(files=len(targets),bytes=sum(row['bytes'] for row in plan['files']),retained_objects=len(plan['retain']))
(root/'file-stream-cleanup-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
'@
$remoteScript = $remoteScript.Replace('__MANIFEST__', $encoded)
$transport = [Diagnostics.ProcessStartInfo]::new((Get-Command ssh).Source)
$transport.UseShellExecute = $false
$transport.CreateNoWindow = $true
$transport.RedirectStandardOutput = $true
$transport.RedirectStandardError = $true
$transport.RedirectStandardInput = $true
foreach ($argument in @('-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'kiro@172.22.10.198', 'python3 -')) {
    $transport.ArgumentList.Add($argument)
}
$process = [Diagnostics.Process]::Start($transport)
try {
    $outputTask = $process.StandardOutput.ReadToEndAsync()
    $errorTask = $process.StandardError.ReadToEndAsync()
    $process.StandardInput.Write($remoteScript)
    $process.StandardInput.Close()
    $process.WaitForExit()
    $remoteOutput = $outputTask.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) { throw ('Mac cleanup failed; Windows files retained: ' + $errorTask.GetAwaiter().GetResult()) }
} finally { $process.Dispose() }
foreach ($item in $targets) { Remove-Item -LiteralPath $item.FullName -Force }
$result = [pscustomobject]@{
    windows = @{ files = $targets.Count; bytes = ($targets | Measure-Object Length -Sum).Sum; retained_objects = @($plan.windows.retain).Count }
    mac = ($remoteOutput | ConvertFrom-Json)
    archive_verified = $true
    retained_build_cache = $plan.windows.retain_build_cache
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stage 'cleanup-result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 8
