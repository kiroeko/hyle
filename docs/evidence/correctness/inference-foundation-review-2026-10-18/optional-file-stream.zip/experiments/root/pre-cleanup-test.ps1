param([switch]$RetireNativeRuntime, [switch]$ReclaimNativeRuntimeRound, [switch]$MoveFileStreamBridges)
# Exact, frozen targets only. Historical cleanup actions are archived with retired source.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/native-runtime-retirement/root'
if (-not $MoveFileStreamBridges -and $RetireNativeRuntime.IsPresent -eq $ReclaimNativeRuntimeRound.IsPresent) {
    throw 'Select -RetireNativeRuntime or -ReclaimNativeRuntimeRound; no default deletion.'
}
function Get-CheckedFile($entry) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $entry.path))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $ancestor = [IO.Path]::GetDirectoryName($path)
    while ($ancestor -eq $workspace -or $ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        if ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked ancestor: $ancestor" }
        $ancestor = [IO.Path]::GetDirectoryName($ancestor)
    }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        $item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) {
        throw "File changed: $path"
    }
    return $item
}
function Read-FrozenPlan($receiptName, $planName, $zipEntry) {
    $receipt = Get-Content -LiteralPath (Join-Path $stage $receiptName) -Raw | ConvertFrom-Json
    $evidence = Get-CheckedFile $receipt
    $planPath = Join-Path $stage $planName
    $zip = [IO.Compression.ZipFile]::OpenRead($evidence.FullName)
    try {
        $entry = $zip.GetEntry($zipEntry)
        if (-not $entry) { throw 'Missing archived plan' }
        $reader = [IO.StreamReader]::new($entry.Open())
        try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
        if ($frozen -cne [IO.File]::ReadAllText($planPath)) { throw 'Cleanup plan differs from preserved archive' }
    } finally { $zip.Dispose() }
    return $frozen | ConvertFrom-Json
}
if ($MoveFileStreamBridges) {
    if ($RetireNativeRuntime -or $ReclaimNativeRuntimeRound) { throw 'Select one exact action' }
    $moveStage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/optional-file-stream/root'
    $plan = Get-Content -LiteralPath (Join-Path $moveStage 'move-plan.json') -Raw | ConvertFrom-Json
    if (@($plan).Count -ne 4) { throw 'Unexpected stream bridge move count' }
    $moves = @()
    foreach ($route in @('cpu', 'cuda', 'apple', 'vulkan')) {
        $entry = @($plan | Where-Object path -EQ "src/compute_route_$route/file_stream.cc")
        if ($entry.Count -ne 1 -or $entry[0].destination -ne "src/compute_stream_$route/file_stream.cc") { throw 'Unexpected stream bridge path' }
        $source = Get-CheckedFile $entry[0]
        $target = [IO.Path]::GetFullPath((Join-Path $workspace $entry[0].destination))
        if (-not $target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $target)) { throw 'Invalid stream bridge destination' }
        $parent = [IO.Path]::GetDirectoryName($target)
        if (Test-Path -LiteralPath $parent) {
            if ((Get-Item -LiteralPath $parent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked stream bridge destination' }
        }
        $moves += [pscustomobject]@{ source = $source.FullName; target = $target; parent = $parent }
    }
    foreach ($move in $moves) {
        [IO.Directory]::CreateDirectory($move.parent) | Out-Null
        Move-Item -LiteralPath $move.source -Destination $move.target
    }
    $moves | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $moveStage 'move-result.json') -Encoding utf8
    Write-Output ('Moved exact stream bridges: ' + $moves.Count)
    exit 0
}
if ($RetireNativeRuntime) {
    $plan = Read-FrozenPlan 'retirement-archive-receipt.json' 'retirement-plan.json' 'retirement-plan.json'
    $expected = @('include/hyle/graph/cpu_apple.h', 'include/hyle/graph/cpu_vulkan.h',
        'src/graph_native_shared/compile.h', 'src/graph_native_shared/plan.h',
        'src/graph_batch/native_paged_nodes.h', 'src/graph_batch/native_paged_slots.h',
        'src/graph/joint_pipeline.h', 'tests/graph/joint_pipeline_test.cc',
        'tests/graph_route_cpu_apple/CMakeLists.txt', 'tests/graph_route_cpu_vulkan/CMakeLists.txt')
    foreach ($api in @('apple', 'vulkan')) {
        foreach ($name in @('CMakeLists.txt', 'compile.cc', 'invocation.cc', 'paged.h', 'plan.h')) {
            $expected += "src/graph_route_cpu_$api/$name"
        }
    }
    if (@($plan.files).Count -ne 20 -or (Compare-Object $expected @($plan.files.path))) { throw 'Unexpected source retirement set' }
    $targets = @($plan.files | ForEach-Object { Get-CheckedFile $_ })
    foreach ($item in $targets) { Remove-Item -LiteralPath $item.FullName -Force }
    $result = [pscustomobject]@{ files = $targets.Count; bytes = ($targets | Measure-Object Length -Sum).Sum; source_archive_verified = $true }
    $result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stage 'retirement-result.json') -Encoding utf8
    $result | ConvertTo-Json
    exit 0
}
$plan = Read-FrozenPlan 'round-archive-receipt.json' 'cleanup-plan.json' 'cleanup-plan.json'
$allowed = @('legacy-native-retirement/pipeline/windows', 'effects-common-invocation/windows',
    'legacy-native-retirement/contracts/windows', 'retire-native-runtime/vulkan-contracts', 'retire-native-runtime/paging-risks') |
    ForEach-Object { [IO.Path]::GetFullPath((Join-Path $workspace ('.scratch/architecture-refactor-2026-10-18/' + $_))) }
$targets = @()
foreach ($entry in $plan.windows.files) {
    $item = Get-CheckedFile $entry
    if ($item.DirectoryName -notin $allowed -or $item.Extension -notin @('.exe', '.map', '.exp', '.lib')) { throw 'Unexpected Windows image' }
    $targets += $item
}
foreach ($entry in $plan.windows.retain) {
    $item = Get-CheckedFile $entry
    if ($item.DirectoryName -notin $allowed -or $item.Extension -ne '.obj') { throw 'Unexpected retained Windows object' }
}
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($plan.mac | ConvertTo-Json -Depth 12 -Compress)))
$remoteScript = @'
from pathlib import Path
import base64,hashlib,json,subprocess
plan=json.loads(base64.b64decode('__MANIFEST__'))
root=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation')
assert Path(plan['root'])==root and root.resolve(strict=True)==root
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
assert json.loads((root/'live.json').read_text())['terminal']
kinds={'public-mla','ready-page','pending-page','pipeline-selected','apple-contracts',
       'completion-publication','node-descriptor-tests','ready-risks','pending-risks',
       'multi-pending-risks','packed-weights','route-effects','public-effects'}
allowed=kinds|{name+'.map' for name in kinds}
targets=[]
for row in plan['files']+plan['retain']:
 p=Path(row['path'])
 assert p.parent==root and not p.is_symlink() and p.resolve(strict=True).parent==root
 assert p.is_file() and p.stat().st_size==row['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
 if row in plan['files']:
  assert p.name in allowed
  targets.append(p)
 else:assert p.suffix=='.o'
assert len(targets)==len(set(targets))
for p in targets:p.unlink()
result=dict(files=len(targets),bytes=sum(row['bytes'] for row in plan['files']),retained_objects=len(plan['retain']))
(root/'retirement-cleanup-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
'@
$remoteScript = $remoteScript.Replace('__MANIFEST__', $encoded)
$transport = [Diagnostics.ProcessStartInfo]::new((Get-Command ssh).Source)
$transport.UseShellExecute = $false
$transport.CreateNoWindow = $true
$transport.RedirectStandardOutput = $true
$transport.RedirectStandardError = $true
$transport.RedirectStandardInput = $true
foreach ($argument in @('-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'kiro@172.22.10.198', 'python3 -')) {
    $transport.ArgumentList.Add($argument)
}
$process = [Diagnostics.Process]::Start($transport)
try {
    $outputTask = $process.StandardOutput.ReadToEndAsync()
    $errorTask = $process.StandardError.ReadToEndAsync()
    $process.StandardInput.Write($remoteScript)
    $process.StandardInput.Close()
    $process.WaitForExit()
    $remoteOutput = $outputTask.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) { throw ('Mac exact cleanup failed; Windows files retained: ' + $errorTask.GetAwaiter().GetResult()) }
} finally { $process.Dispose() }
foreach ($item in $targets) { Remove-Item -LiteralPath $item.FullName -Force }
$result = [pscustomobject]@{
    windows = @{ files = $targets.Count; bytes = ($targets | Measure-Object Length -Sum).Sum; retained_objects = @($plan.windows.retain).Count }
    mac = ($remoteOutput | ConvertFrom-Json)
    archive_verified = $true
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stage 'cleanup-result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 8
