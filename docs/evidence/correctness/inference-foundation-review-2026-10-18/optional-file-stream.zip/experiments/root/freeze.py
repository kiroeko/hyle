from pathlib import Path
import concurrent.futures
import hashlib
import json
import re
import subprocess
import sys
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18'
SERVICE = OUT.parent
AIR = BASE / 'apple-page-invocation'
NORM = BASE / 'qwen-numerical-localization/actual-f32-probe'
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def checked(row):
    path = Path(row['path'])
    if not path.is_absolute():
        path = ROOT / path
    now = identity(path)
    assert (now['bytes'], now['sha256']) == (row['bytes'], row['sha256']), str(path)
    return now


def metadata_check(item):
    name, command = item
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (OUT / (name + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (name + '.stderr.log')).write_bytes(result.stderr)
    return dict(name=name, command=command, exit=result.returncode)


if '--metadata' in sys.argv:
    commands = [('routes', [sys.executable, 'tests/tooling/compute_routes_test.py']),
                ('scripts', [sys.executable, 'tests/tooling/development_scripts_test.py']),
                ('macros', [sys.executable, 'tests/tooling/product_macro_contract_test.py']),
                ('visibility', [sys.executable, 'scripts/generate-visibility.py', '--check'])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(metadata_check, commands))
    write(OUT / 'metadata-checks.json', results)
    print(json.dumps(results))
    assert all(item['exit'] == 0 for item in results)
    sys.exit(0)

commands = read(SERVICE / 'windows/commands.json')
for tag in ['cpu_tests-run', 'vulkan_tests-run', 'sample-run']:
    last = next(row for row in reversed(commands) if row['tag'] == tag)
    assert last['exit'] == 0
for name, count in [('033-cpu_tests', 14), ('034-vulkan_tests', 5)]:
    assert f'[  PASSED  ] {count} tests.' in (SERVICE / f'windows/{name}-run.stdout.log').read_text()
assert read(SERVICE / 'cpu-service-summary.json')['final_run'] == '22-cpu-service-consumer-run'
assert all(row['exit'] == 0 for row in read(OUT / 'metadata-checks.json'))

windows = SERVICE / 'windows'
files = []
retain = []
for directory, manifest in [(SERVICE / 'cuda', 'cleanup-identities.json'),
                            (NORM, 'cleanup-identities.json')]:
    rows = read(directory / manifest)
    expected = sorted(directory.glob('*.exe')) + sorted(directory.glob('*.map'))
    assert {str(p) for p in expected} == {r['path'] for r in rows if Path(r['path']).suffix in {'.exe', '.map'}}
    files.extend(checked(row) for row in rows)
    retain.extend(identity(p) for p in sorted(directory.glob('*.obj')))
for stem in ['cpu_tests', 'vulkan_tests', 'sample']:
    for suffix in ['.exe', '.map', '.exp', '.lib']:
        files.append(identity(windows / (stem + suffix)))
    text = (windows / (stem + '.map')).read_text(errors='replace')
    members = sorted(set(line.split()[-1] for line in text.splitlines()
                         if re.match(r'\s*[0-9A-Fa-f]{4}:[0-9A-Fa-f]+\s+\S+\s+[0-9A-Fa-f]{8,}\s+', line)))
    (windows / (stem + '-map-members.txt')).write_text('\n'.join(members) + '\n')
    write(windows / (stem + '-map-check.json'), dict(map=identity(windows / (stem + '.map')),
         members=len(members), factory_map_lines=read(windows / (stem + '-link-inputs.json'))['factory_map_lines']))
retain.extend(identity(p) for p in sorted(windows.glob('*.obj')))
cpu_cleanup = read(SERVICE / 'cpu-service-cleanup-candidates.json')
files.extend(checked(row) for row in cpu_cleanup['files'])
retain.extend(checked(row) for row in read(SERVICE / 'cpu-service-retained-objects.json'))
assert len(files) == len(set(row['path'] for row in files))
mac = read(AIR / 'air-results/cleanup.json')
assert len(mac['files']) == 4 and len(mac['retain']) == 124
plan = dict(windows=dict(files=files, retain=retain,
                         retain_build_cache=str(SERVICE / 'cpu-service-build')), mac=mac)
write(OUT / 'cleanup-plan.json', plan)
write(windows / 'summary.json', dict(cpu_tests=14, vulkan_tests=5,
      vulkan_sample='file+mapping 512B each, staging128B', shared_owner_compile='CPU/Vulkan/native copy exports only',
      source_copy='current batch-transfer-final.obj', kernel_sdk_rebuild=False,
      limits='Static object reuse verifies current service owners, not a newly built Vulkan DLL package.'))

archive_files = {}


def add(path, name):
    assert path.is_file() and not path.is_symlink()
    assert name not in archive_files or archive_files[name] == path
    archive_files[name] = path


def source(row):
    now = checked(row)
    add(ROOT / now['path'], 'source/' + now['path'])


def archive(name):
    target = EVIDENCE / name
    assert not target.exists(), 'Do not overwrite frozen evidence'
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for entry, path in sorted(archive_files.items()):
            z.write(path, entry)
        z.writestr('archive-manifest.json', json.dumps([
            dict(entry=entry, **identity(path)) for entry, path in sorted(archive_files.items())], indent=2) + '\n')
    return identity(target)


extensions = {'.json', '.log', '.txt', '.md', '.py', '.ps1', '.cc', '.h', '.mm', '.diff', '.cmake'}
excluded_dirs = {'cpu-service-build', 'cpu-service-prefix', 'cpu-service-consumer', 'component-selection', '__pycache__'}
for path in sorted(SERVICE.rglob('*')):
    if (path.is_file() and not path.is_symlink() and path.suffix in extensions
            and not set(path.relative_to(SERVICE).parts) & excluded_dirs
            and path.name not in {'archive-receipts.json', 'cleanup-result.json'}):
        add(path, 'experiments/' + path.relative_to(SERVICE).as_posix())
for name in ['air.py', 'air_remote.py']:
    add(AIR / name, 'apple/' + name)
for path in sorted((AIR / 'air-results').iterdir()):
    if path.is_file() and path.suffix in {'.json', '.log', '.txt'}:
        add(path, 'apple/results/' + path.name)
final_air = read(AIR / 'air-results/final-source-identities.json')
for row in [r['source'] for r in final_air['compiled_owners']] + final_air['headers']:
    logical = row['path'].removeprefix(mac['root'] + '/')
    if (ROOT / logical).is_file() and identity(ROOT / logical)['sha256'] == row['sha256']:
        source(dict(row, path=logical))
    else:
        probe = OUT / 'air-probe-sources' / logical
        assert identity(probe)['sha256'] == row['sha256']
        add(probe, 'apple/tested-source/' + logical)
for path in windows.glob('*-identity.json'):
    data = read(path)
    if 'source' in data:
        source(data['source'])
for row in read(SERVICE / 'cpu-service-source-identities.json'):
    source(row)
for row in read(SERVICE / 'cpu-service-key-source-identities.json'):
    source(row)
extras = ['cmake/HyleComponents.cmake', 'cmake/HyleComputeRoutes.cmake', 'cmake/HylePackage.cmake',
          'cmake/HyleCiSelectedComponentSmoke.cmake', 'scripts/hyle_support.py',
          'tests/tooling/compute_routes_test.py', 'tests/tooling/development_scripts_test.py',
          'tests/build_system/component_selection/CMakeLists.txt',
          'docs/architecture/build-system.md', 'docs/architecture/compute-design.md',
          'docs/developer/current-work.md', 'docs/user/compute.md', 'test.ps1',
          'samples/package/graph/file_streaming/CMakeLists.txt',
          'samples/package/graph/file_streaming/README.md',
          'samples/package/graph/file_streaming/main.cc', 'samples/package/graph/file_streaming/qwen_main.cc',
          'samples/package/compute_stream/cpp/CMakeLists.txt', 'samples/package/compute_stream/cpp/main.cc']
for route in ['cpu', 'cuda', 'apple', 'vulkan']:
    extras += [f'src/compute_stream_{route}/file_stream.cc', f'src/compute_stream_{route}/CMakeLists.txt',
               f'tests/compute_stream_{route}/CMakeLists.txt', f'include/hyle/compute/{route}_file_stream.h',
               f'include/hyle/compute/{route}.h', f'src/compute_route_{route}/CMakeLists.txt',
               f'tests/compute_route_{route}/CMakeLists.txt']
extras += ['src/compute/batch_transfer.cc', 'src/compute_stream/file_stream.cc', 'tests/compute_stream/file_stream_test.cc',
           'tests/compute_stream/CMakeLists.txt', 'src/compute_route_apple/apple_file_stream_access.h',
           'src/compute_route_vulkan/vulkan_file_stream_access.h', 'include/hyle/visibility.h']
for name in extras:
    add(ROOT / name, 'source/' + name)
(OUT / 'product-and-docs.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', *extras], cwd=ROOT))
add(OUT / 'product-and-docs.diff', 'product-and-docs.diff')
add(OUT / 'cleanup-plan.json', 'cleanup-plan.json')
receipt_service = archive('optional-file-stream.zip')

archive_files = {}
for path in sorted(NORM.rglob('*')):
    if path.is_file() and path.suffix in extensions | {'.f32', '.bf16'}:
        add(path, 'experiment/' + path.relative_to(NORM).as_posix())
for row in read(NORM / 'source-identities.json'):
    source(row)
receipt_norm = archive('qwen-rmsnorm-f32.zip')
write(OUT / 'archive-receipts.json', dict(service=receipt_service, numerical=receipt_norm))
print(json.dumps(dict(archives=[receipt_service, receipt_norm],
      windows_files=len(files), windows_bytes=sum(r['bytes'] for r in files), retained_windows_objects=len(retain),
      mac_files=len(mac['files']), mac_bytes=sum(r['bytes'] for r in mac['files']), retained_mac_objects=len(mac['retain']))))
