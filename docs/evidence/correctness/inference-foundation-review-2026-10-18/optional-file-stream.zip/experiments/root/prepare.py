from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
owned = ['cmake/HyleComponents.cmake', 'cmake/HyleComputeRoutes.cmake', 'cmake/HylePackage.cmake',
         'cmake/HyleCiSelectedComponentSmoke.cmake', 'scripts/hyle_support.py',
         'include/hyle/visibility.h', 'src/compute_route_apple/apple_file_stream_access.h',
         'src/compute_route_vulkan/vulkan_file_stream_access.h', 'test.ps1']
for route in ['cpu', 'cuda', 'apple', 'vulkan']:
    owned += [f'src/compute_route_{route}/file_stream.cc', f'src/compute_route_{route}/CMakeLists.txt',
              f'tests/compute_route_{route}/CMakeLists.txt']
for relative in owned:
    path = ROOT / relative
    dest = OUT / 'before' / relative
    assert not dest.exists(), 'Do not overwrite before state'
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(path.read_bytes())
rows = []
for route in ['cpu', 'cuda', 'apple', 'vulkan']:
    source = ROOT / f'src/compute_route_{route}/file_stream.cc'
    rows.append(dict(path=source.relative_to(ROOT).as_posix(), bytes=source.stat().st_size,
                     sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                     destination=f'src/compute_stream_{route}/file_stream.cc'))
(OUT / 'move-plan.json').write_text(json.dumps(rows, indent=2) + '\n')
print('saved', len(owned), 'before files; exact bridge moves', len(rows))
