#pragma once

// Symbol visibility: tri-state export/import, used by per-module HYLE_<MOD>_API.
// Fallback to empty on unknown compilers (degrade safe, never fail to compile).

#if defined(_WIN32) || defined(__CYGWIN__)
#  define HYLE_EXPORT __declspec(dllexport)
#  define HYLE_IMPORT __declspec(dllimport)
#  define HYLE_HIDDEN
#elif defined(__GNUC__) || defined(__clang__)
#  define HYLE_EXPORT __attribute__((visibility("default")))
#  define HYLE_IMPORT __attribute__((visibility("default")))
#  define HYLE_HIDDEN __attribute__((visibility("hidden")))
#else
#  define HYLE_EXPORT
#  define HYLE_IMPORT
#  define HYLE_HIDDEN
#endif

// BEGIN GENERATED API VISIBILITY -- scripts/generate-visibility.py
// API names come from public headers; BUILD owners come from the factor catalog.
// HYLE_STATIC and each target's private *_BUILD definition are set before includes.
#if defined(HYLE_STATIC)
#  define HYLE_COMPUTE_API
#  define HYLE_COMPUTE_BACKEND_CPU_API
#  define HYLE_COMPUTE_BACKEND_CUDA_API
#  define HYLE_COMPUTE_BATCH_API
#  define HYLE_COMPUTE_OPS_API
#  define HYLE_COMPUTE_PROVIDER_CUBLAS_API
#  define HYLE_COMPUTE_PROVIDER_CUDA_API
#  define HYLE_COMPUTE_PROVIDER_FLASHINFER_API
#  define HYLE_COMPUTE_PROVIDER_GGML_API
#  define HYLE_COMPUTE_PROVIDER_GGML_CUDA_API
#  define HYLE_COMPUTE_PROVIDER_NATIVE_API
#  define HYLE_COMPUTE_PROVIDER_ONEDNN_API
#  define HYLE_COMPUTE_PROVIDER_TORCH_CUDA_API
#  define HYLE_COMPUTE_ROUTE_APPLE_API
#  define HYLE_COMPUTE_ROUTE_CPU_API
#  define HYLE_COMPUTE_ROUTE_CUDA_API
#  define HYLE_COMPUTE_ROUTE_VULKAN_API
#  define HYLE_COMPUTE_STATE_API
#  define HYLE_COMPUTE_STREAM_API
#  define HYLE_CONTAINER_API
#  define HYLE_CONTAINER_CONCURRENT_API
#  define HYLE_CONTAINER_QUEUE_API
#  define HYLE_CONTAINER_TEXT_API
#  define HYLE_ERROR_API
#  define HYLE_GRAPH_API
#  define HYLE_GRAPH_BATCH_API
#  define HYLE_GRAPH_PROGRESS_API
#  define HYLE_GRAPH_PROVIDER_GGML_CUDA_API
#  define HYLE_GRAPH_PROVIDER_ONEDNN_API
#  define HYLE_GRAPH_ROUTE_APPLE_API
#  define HYLE_GRAPH_ROUTE_CPU_API
#  define HYLE_GRAPH_ROUTE_CPU_CUDA_API
#  define HYLE_GRAPH_ROUTE_CUDA_API
#  define HYLE_GRAPH_ROUTE_VULKAN_API
#  define HYLE_IO_API
#  define HYLE_IO_HTTP2_API
#  define HYLE_IO_HTTP_API
#  define HYLE_IO_TLS_API
#  define HYLE_IO_TRANSFER_API
#  define HYLE_IO_WATCH_API
#  define HYLE_IO_WEBSOCKET_API
#  define HYLE_MEM_API
#  define HYLE_MEM_RECLAIM_API
#  define HYLE_MEM_VM_API
#  define HYLE_OBS_API
#  define HYLE_PLATFORM_API
#  define HYLE_PLATFORM_FS_API
#  define HYLE_PLATFORM_THREAD_API
#  define HYLE_PROCESS_API
#  define HYLE_SCHED_API
#  define HYLE_SIMD_API
#  define HYLE_TIME_API
#  define HYLE_UTIL_RUNTIME_API
#else
#  if defined(HYLE_COMPUTE_BUILD)
#    define HYLE_COMPUTE_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_BACKEND_CPU_BUILD)
#    define HYLE_COMPUTE_BACKEND_CPU_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_BACKEND_CPU_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_BACKEND_CUDA_BUILD)
#    define HYLE_COMPUTE_BACKEND_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_BACKEND_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_BATCH_BUILD)
#    define HYLE_COMPUTE_BATCH_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_BATCH_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_OPS_BUILD)
#    define HYLE_COMPUTE_OPS_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_OPS_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_CUBLAS_BUILD)
#    define HYLE_COMPUTE_PROVIDER_CUBLAS_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_CUBLAS_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_CUDA_BUILD)
#    define HYLE_COMPUTE_PROVIDER_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_FLASHINFER_BUILD)
#    define HYLE_COMPUTE_PROVIDER_FLASHINFER_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_FLASHINFER_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_GGML_BUILD)
#    define HYLE_COMPUTE_PROVIDER_GGML_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_GGML_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_GGML_CUDA_BUILD)
#    define HYLE_COMPUTE_PROVIDER_GGML_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_GGML_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_NATIVE_BUILD)
#    define HYLE_COMPUTE_PROVIDER_NATIVE_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_NATIVE_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_ONEDNN_BUILD)
#    define HYLE_COMPUTE_PROVIDER_ONEDNN_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_ONEDNN_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_PROVIDER_TORCH_CUDA_BUILD)
#    define HYLE_COMPUTE_PROVIDER_TORCH_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_PROVIDER_TORCH_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_ROUTE_APPLE_BUILD)
#    define HYLE_COMPUTE_ROUTE_APPLE_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_ROUTE_APPLE_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_ROUTE_CPU_BUILD)
#    define HYLE_COMPUTE_ROUTE_CPU_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_ROUTE_CPU_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_ROUTE_CUDA_BUILD)
#    define HYLE_COMPUTE_ROUTE_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_ROUTE_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_ROUTE_VULKAN_BUILD)
#    define HYLE_COMPUTE_ROUTE_VULKAN_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_ROUTE_VULKAN_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_STATE_BUILD)
#    define HYLE_COMPUTE_STATE_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_STATE_API HYLE_IMPORT
#  endif
#  if defined(HYLE_COMPUTE_STREAM_BUILD)
#    define HYLE_COMPUTE_STREAM_API HYLE_EXPORT
#  else
#    define HYLE_COMPUTE_STREAM_API HYLE_IMPORT
#  endif
#  if defined(HYLE_CONTAINER_BUILD)
#    define HYLE_CONTAINER_API HYLE_EXPORT
#  else
#    define HYLE_CONTAINER_API HYLE_IMPORT
#  endif
#  if defined(HYLE_CONTAINER_CONCURRENT_BUILD)
#    define HYLE_CONTAINER_CONCURRENT_API HYLE_EXPORT
#  else
#    define HYLE_CONTAINER_CONCURRENT_API HYLE_IMPORT
#  endif
#  if defined(HYLE_CONTAINER_QUEUE_BUILD)
#    define HYLE_CONTAINER_QUEUE_API HYLE_EXPORT
#  else
#    define HYLE_CONTAINER_QUEUE_API HYLE_IMPORT
#  endif
#  if defined(HYLE_CONTAINER_TEXT_BUILD)
#    define HYLE_CONTAINER_TEXT_API HYLE_EXPORT
#  else
#    define HYLE_CONTAINER_TEXT_API HYLE_IMPORT
#  endif
#  if defined(HYLE_ERROR_BUILD)
#    define HYLE_ERROR_API HYLE_EXPORT
#  else
#    define HYLE_ERROR_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_BUILD)
#    define HYLE_GRAPH_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_BATCH_BUILD)
#    define HYLE_GRAPH_BATCH_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_BATCH_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_PROGRESS_BUILD)
#    define HYLE_GRAPH_PROGRESS_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_PROGRESS_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_PROVIDER_GGML_CUDA_BUILD)
#    define HYLE_GRAPH_PROVIDER_GGML_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_PROVIDER_GGML_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_PROVIDER_ONEDNN_BUILD)
#    define HYLE_GRAPH_PROVIDER_ONEDNN_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_PROVIDER_ONEDNN_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_ROUTE_APPLE_BUILD)
#    define HYLE_GRAPH_ROUTE_APPLE_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_ROUTE_APPLE_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_ROUTE_CPU_BUILD)
#    define HYLE_GRAPH_ROUTE_CPU_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_ROUTE_CPU_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_ROUTE_CPU_CUDA_BUILD)
#    define HYLE_GRAPH_ROUTE_CPU_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_ROUTE_CPU_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_ROUTE_CUDA_BUILD)
#    define HYLE_GRAPH_ROUTE_CUDA_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_ROUTE_CUDA_API HYLE_IMPORT
#  endif
#  if defined(HYLE_GRAPH_ROUTE_VULKAN_BUILD)
#    define HYLE_GRAPH_ROUTE_VULKAN_API HYLE_EXPORT
#  else
#    define HYLE_GRAPH_ROUTE_VULKAN_API HYLE_IMPORT
#  endif
#  if defined(HYLE_IO_CORE_BUILD)
#    define HYLE_IO_API HYLE_EXPORT
#  else
#    define HYLE_IO_API HYLE_IMPORT
#  endif
#  if defined(HYLE_IO_HTTP2_BUILD)
#    define HYLE_IO_HTTP2_API HYLE_EXPORT
#  else
#    define HYLE_IO_HTTP2_API HYLE_IMPORT
#  endif
#  if defined(HYLE_IO_HTTP_BUILD)
#    define HYLE_IO_HTTP_API HYLE_EXPORT
#  else
#    define HYLE_IO_HTTP_API HYLE_IMPORT
#  endif
#  if defined(HYLE_IO_TLS_BUILD)
#    define HYLE_IO_TLS_API HYLE_EXPORT
#  else
#    define HYLE_IO_TLS_API HYLE_IMPORT
#  endif
#  if defined(HYLE_IO_TRANSFER_BUILD)
#    define HYLE_IO_TRANSFER_API HYLE_EXPORT
#  else
#    define HYLE_IO_TRANSFER_API HYLE_IMPORT
#  endif
#  if defined(HYLE_IO_WATCH_BUILD)
#    define HYLE_IO_WATCH_API HYLE_EXPORT
#  else
#    define HYLE_IO_WATCH_API HYLE_IMPORT
#  endif
#  if defined(HYLE_IO_WEBSOCKET_BUILD)
#    define HYLE_IO_WEBSOCKET_API HYLE_EXPORT
#  else
#    define HYLE_IO_WEBSOCKET_API HYLE_IMPORT
#  endif
#  if defined(HYLE_MEM_BUILD)
#    define HYLE_MEM_API HYLE_EXPORT
#  else
#    define HYLE_MEM_API HYLE_IMPORT
#  endif
#  if defined(HYLE_MEM_RECLAIM_BUILD)
#    define HYLE_MEM_RECLAIM_API HYLE_EXPORT
#  else
#    define HYLE_MEM_RECLAIM_API HYLE_IMPORT
#  endif
#  if defined(HYLE_MEM_VM_BUILD)
#    define HYLE_MEM_VM_API HYLE_EXPORT
#  else
#    define HYLE_MEM_VM_API HYLE_IMPORT
#  endif
#  if defined(HYLE_OBS_BUILD)
#    define HYLE_OBS_API HYLE_EXPORT
#  else
#    define HYLE_OBS_API HYLE_IMPORT
#  endif
#  if defined(HYLE_PLATFORM_BUILD)
#    define HYLE_PLATFORM_API HYLE_EXPORT
#  else
#    define HYLE_PLATFORM_API HYLE_IMPORT
#  endif
#  if defined(HYLE_PLATFORM_FS_BUILD)
#    define HYLE_PLATFORM_FS_API HYLE_EXPORT
#  else
#    define HYLE_PLATFORM_FS_API HYLE_IMPORT
#  endif
#  if defined(HYLE_PLATFORM_THREAD_BUILD)
#    define HYLE_PLATFORM_THREAD_API HYLE_EXPORT
#  else
#    define HYLE_PLATFORM_THREAD_API HYLE_IMPORT
#  endif
#  if defined(HYLE_PROCESS_BUILD)
#    define HYLE_PROCESS_API HYLE_EXPORT
#  else
#    define HYLE_PROCESS_API HYLE_IMPORT
#  endif
#  if defined(HYLE_SCHED_BUILD)
#    define HYLE_SCHED_API HYLE_EXPORT
#  else
#    define HYLE_SCHED_API HYLE_IMPORT
#  endif
#  if defined(HYLE_SIMD_BUILD)
#    define HYLE_SIMD_API HYLE_EXPORT
#  else
#    define HYLE_SIMD_API HYLE_IMPORT
#  endif
#  if defined(HYLE_TIME_BUILD)
#    define HYLE_TIME_API HYLE_EXPORT
#  else
#    define HYLE_TIME_API HYLE_IMPORT
#  endif
#  if defined(HYLE_UTIL_RUNTIME_BUILD)
#    define HYLE_UTIL_RUNTIME_API HYLE_EXPORT
#  else
#    define HYLE_UTIL_RUNTIME_API HYLE_IMPORT
#  endif
#endif
// END GENERATED API VISIBILITY
