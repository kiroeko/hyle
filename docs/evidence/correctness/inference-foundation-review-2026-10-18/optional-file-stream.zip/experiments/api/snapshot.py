from pathlib import Path
import difflib
import hashlib
import json
import shutil
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
FILES = ["include/hyle/compute/" + route + suffix + ".h"
    for suffix in ["", "_file_stream"] for route in ["cpu", "cuda", "apple", "vulkan"]]
FILES += ["tests/compute_stream/file_stream_test.cc", "tests/compute_route_cuda/file_stream_test.cc",
    "tests/compute_route_apple/file_stream_test.cc", "tests/compute_route_vulkan/file_stream_test.cc",
    "samples/package/graph/file_streaming/main.cc", "samples/package/graph/file_streaming/qwen_main.cc",
    "samples/package/graph/file_streaming/CMakeLists.txt"]
phase = sys.argv[1]
identities = []
for relative in FILES:
    source = ROOT / relative
    target = OUT / phase / relative
    if phase == "before" and target.exists():
        raise SystemExit("before snapshot already exists: " + relative)
    if source.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        data = source.read_bytes()
        identities.append(dict(path=relative, exists=True, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    else:
        identities.append(dict(path=relative, exists=False))
(OUT / (phase + "-identities.json")).write_text(json.dumps(identities, indent=2) + "\n", encoding="utf-8")
if phase == "candidate":
    diff = []
    for relative in FILES:
        original = OUT / "before" / relative
        source = ROOT / relative
        old = original.read_text(encoding="utf-8") if original.exists() else ""
        new = source.read_text(encoding="utf-8") if source.exists() else ""
        diff.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
            fromfile="before/" + relative, tofile="candidate/" + relative))
    (OUT / "source.diff").write_text("".join(diff), encoding="utf-8")
print(json.dumps(identities, indent=2))
