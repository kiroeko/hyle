from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
BUILD = STAGE / 'cpu-service-build'
PREFIX = STAGE / 'cpu-service-prefix'
CONSUMER = STAGE / 'cpu-service-consumer'
SAMPLE = ROOT / 'samples/package/compute_stream/cpp'
sys.path.insert(0, str(ROOT / 'scripts'))
sys.dont_write_bytecode = True
from hyle_environment import windows_compiler_environment


def cache(path):
    result = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        match = re.match(r'^([^/#][^:=]*):[^=]*=(.*)$', line)
        if match:
            result[match[1]] = match[2]
    return result


BASE = cache(ROOT / '.scratch/build-compute-v2-dev/CMakeCache.txt')
ENV = windows_compiler_environment(BASE)
CMAKE = shutil.which('cmake', path=ENV['PATH'])
assert CMAKE


def write(name, value):
    (STAGE / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def run(label, argv, cwd=ROOT, timeout=180):
    records_path = STAGE / 'cpu-service-commands.json'
    records = json.loads(records_path.read_text()) if records_path.exists() else []
    tag = f'{len(records) + 1:02d}-{label}'
    row = {'label': tag, 'command': list(map(str, argv)), 'cwd': str(cwd),
           'stdout': f'{tag}.stdout.log', 'stderr': f'{tag}.stderr.log',
           'started': time.strftime('%Y-%m-%dT%H:%M:%S%z')}
    records.append(row)
    write('cpu-service-commands.json', records)
    print('START', tag, flush=True)
    started = time.monotonic()
    with (STAGE / row['stdout']).open('wb') as out, (STAGE / row['stderr']).open('wb') as err:
        child = subprocess.Popen(row['command'], cwd=cwd, env=ENV, stdout=out, stderr=err,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = child.pid
        write('cpu-service-commands.json', records)
        try:
            row['exit_code'] = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            row['timeout'] = timeout
            write('cpu-service-commands.json', records)
            raise
    row['seconds'] = round(time.monotonic() - started, 3)
    write('cpu-service-commands.json', records)
    print('END', tag, 'exit', row['exit_code'], 'seconds', row['seconds'], flush=True)
    for key in ('stdout', 'stderr'):
        lines = (STAGE / row[key]).read_text(encoding='utf-8', errors='replace').splitlines()
        print('\n'.join(lines[-18:]), flush=True)
    if row['exit_code']:
        raise SystemExit(row['exit_code'])


def inspect():
    values = cache(BUILD / 'CMakeCache.txt')
    assert values['HYLE_COMPONENTS'] == 'compute_stream'
    assert values['HYLE_COMPUTE_ROUTES'] == 'cpu'
    assert values['HYLE_STATIC'] == 'OFF' and values['HYLE_BUILD_TESTS'] == 'OFF'
    assert values['FETCHCONTENT_FULLY_DISCONNECTED'] == 'ON'
    rows = json.loads((BUILD / 'compile_commands.json').read_text(encoding='utf-8'))
    sources = sorted({str(Path(row['file']).resolve()) for row in rows})
    owners = sorted({Path(name).relative_to(ROOT).parts[1] for name in sources
                     if Path(name).is_relative_to(ROOT / 'src')})
    forbidden = [name for name in owners if name.startswith(('compute_provider_', 'graph', 'compute_route_'))]
    assert not forbidden, forbidden
    assert 'compute_stream_cpu' in owners and 'compute_backend_cpu' in owners
    assert not any(any(token in name.lower() for token in ('ggml', 'torch', 'onednn', 'flashinfer', '/mlx/'))
                   for name in sources)
    result = {'status': 'configured_cpu_service_only', 'translation_units': len(rows),
              'hyle_owners': owners, 'sources': sources,
              'cache': identity(BUILD / 'CMakeCache.txt'),
              'compile_commands': identity(BUILD / 'compile_commands.json')}
    write('cpu-service-closure.json', result)
    print(json.dumps({key: result[key] for key in ('status', 'translation_units', 'hyle_owners')}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['configure', 'inspect', 'build', 'install',
                                         'consumer-configure', 'consumer-build', 'consumer-run', 'exports'])
    action = parser.parse_args().action
    common = ['-G', 'Ninja', f'-DCMAKE_C_COMPILER={BASE["CMAKE_C_COMPILER"]}',
              f'-DCMAKE_CXX_COMPILER={BASE["CMAKE_CXX_COMPILER"]}',
              f'-DCMAKE_MAKE_PROGRAM={BASE["CMAKE_MAKE_PROGRAM"]}', '-DCMAKE_BUILD_TYPE=Release']
    if action == 'configure':
        run('cpu-service-configure', [CMAKE, '-S', ROOT, '-B', BUILD, *common,
            '-DHYLE_COMPONENTS=compute_stream', '-DHYLE_COMPUTE_ROUTES=cpu',
            '-DHYLE_STATIC=OFF', '-DHYLE_BUILD_TESTS=OFF', '-DHYLE_BUILD_BENCH=OFF',
            '-DHYLE_TRACE=OFF', '-DHYLE_INSTALL=ON', f'-DCMAKE_INSTALL_PREFIX={PREFIX}',
            f'-DHYLE_DEP_SOURCE_CACHE={BASE["HYLE_DEP_SOURCE_CACHE"]}',
            '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DFETCHCONTENT_UPDATES_DISCONNECTED=ON',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
        inspect()
    elif action == 'inspect':
        inspect()
    elif action == 'build':
        inspect()
        run('cpu-service-build', [CMAKE, '--build', BUILD, '--parallel', '2'], timeout=600)
    elif action == 'install':
        run('cpu-service-install', [CMAKE, '--install', BUILD])
    elif action == 'consumer-configure':
        run('cpu-service-consumer-configure', [CMAKE, '-S', SAMPLE, '-B', CONSUMER, *common,
            f'-DCMAKE_PREFIX_PATH={PREFIX}', '-DHYLE_COMPUTE_ROUTES=cpu',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
    elif action == 'consumer-build':
        run('cpu-service-consumer-build', [CMAKE, '--build', CONSUMER, '--parallel', '2'])
    elif action == 'consumer-run':
        run('cpu-service-consumer-run', [CONSUMER / 'hyle_compute_stream_sample.exe'],
            cwd=CONSUMER, timeout=60)
    elif action == 'exports':
        dumpbin = shutil.which('dumpbin', path=ENV['PATH'])
        assert dumpbin
        run('cpu-service-bridge-exports', [dumpbin, '/exports', BUILD / 'bin/hyle_compute_stream_cpu.dll'])
        run('cpu-service-common-exports', [dumpbin, '/exports', BUILD / 'bin/hyle_compute_stream.dll'])


if __name__ == '__main__':
    main()
