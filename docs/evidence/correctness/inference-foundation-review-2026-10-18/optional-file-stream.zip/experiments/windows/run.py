from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/retire-native-runtime/paging-risks'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n')


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def library_identity(argument):
    path = Path(argument)
    if not path.is_file():
        path = next(Path(directory)/argument for directory in env.get('LIB', '').split(os.pathsep)
                    if (Path(directory)/argument).is_file())
    return dict(argument=argument, **identity(path))


template = read(BASE / 'ready-risks-identity.json')['command']
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': template[0], 'CMAKE_C_COMPILER': template[0]})
env['VSLANG'] = '1033'
base = read(BASE / 'matched-link-base.json')
torch = next(str(Path(arg).parent) for arg in base['command'] if arg.lower().endswith('torch_cpu.lib'))
env['PATH'] = torch + os.pathsep + env.get('PATH', '')


def run(tag, command, timeout=180):
    rows = read(OUT / 'commands.json') if (OUT / 'commands.json').exists() else []
    stem = f'{len(rows)+1:03d}-{tag}'
    command = list(map(str, command))
    row = dict(tag=tag, command=command, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log', exit=None)
    rows.append(row)
    write(OUT / 'commands.json', rows)
    start = time.monotonic()
    result = subprocess.run(command, cwd=OUT, env=env, capture_output=True, timeout=timeout,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / row['stdout']).write_bytes(result.stdout)
    (OUT / row['stderr']).write_bytes(result.stderr)
    row.update(exit=result.returncode, seconds=time.monotonic()-start)
    write(OUT / 'commands.json', rows)
    print(stem, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:] + result.stderr.decode(errors='replace')[-6000:], flush=True)
    return result.returncode


sources = dict(cpu='src/compute_stream_cpu/file_stream.cc', vulkan='src/compute_stream_vulkan/file_stream.cc',
               common='src/compute_stream/file_stream.cc', sources='src/compute_stream/stream_sources.cc',
               cpu_tests='tests/compute_stream/file_stream_test.cc',
               vulkan_tests='tests/compute_route_vulkan/file_stream_test.cc',
               sample='samples/package/compute_stream/cpp/main.cc',
               native_exports='src/compute_route_vulkan/vulkan_copy_program.cc')


def compile_one(name, shared=False):
    source = sources[name]
    flags = [arg for arg in template[1:] if not arg.lower().startswith(('/fo', '/fd'))
             and not arg.lower().endswith('.cc')]
    flags += ['/I'+str(ROOT / 'src/compute_route_vulkan'),
              '/I'+str(ROOT / '.scratch/build-compute-v2-dev/_deps/googletest-src/googletest/include')]
    if shared:
        flags = [arg for arg in flags if not arg.startswith('/DHYLE_STATIC') and not
                 (arg.startswith('/DHYLE_') and '_BUILD=' in arg)]
        owner = 'COMPUTE_ROUTE_VULKAN' if name == 'native_exports' else 'COMPUTE_STREAM_' + name.upper()
        flags += ['/DHYLE_' + owner + '_BUILD=1']
    output = OUT / (name + ('-shared' if shared else '') + '.obj')
    command = [template[0], *flags, str(ROOT / source), '/Fo'+str(output)]
    code = run(output.stem+'-compile', command)
    if not code:
        write(OUT / (output.stem+'-identity.json'), dict(source=identity(ROOT/source), object=identity(output), command=command))
    return code


def link(name):
    reverse = {obj: source for source, obj in base['selected_sources'].items()}
    objects = []
    for row in base['objects']:
        source = reverse.get(row['path'])
        if source == 'src/compute/batch_transfer.cc':
            current = read(OUT.parent/'cuda/summary.json')['corrected_source']
            assert identity(ROOT/source) == current['source']
            assert identity(current['object']['path']) == current['object']
            objects.append(current['object']['path'])
            continue
        if source:
            if source.startswith('tests/') or (source.startswith('src/compute_route_') and source.endswith('/file_stream.cc')):
                continue
            assert identity(ROOT/source)['sha256'] == base['compiled_source_sha256'][source], source+' is stale'
        assert identity(row['path']) == row
        objects.append(row['path'])
    flags = [arg for arg in base['command'][1:] if not arg.lower().endswith(('.obj', '.lib')) and
             not arg.upper().startswith(('/OUT:', '/MAP:'))]
    libraries = [arg for arg in base['command'] if arg.lower().endswith('.lib')]
    if name.endswith('_tests'):
        libraries += [str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),
                      str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
    bridge = name.removesuffix('_tests') if name != 'sample' else None
    added = [str(OUT/(route+'.obj')) for route in ([bridge] if bridge else ['cpu', 'vulkan'])]
    added += [str(OUT/(part+'.obj')) for part in ['common', 'sources']]
    command = [base['command'][0], *flags, '/OUT:'+str(OUT/(name+'.exe')), '/MAP:'+str(OUT/(name+'.map')),
               str(OUT/(name+'.obj')), *added, *objects, *libraries]
    code = run(name+'-link', command)
    if not code:
        text = (OUT/(name+'.map')).read_text(errors='replace')
        factory_lines = [line for line in text.splitlines() if '?create_file_pipeline@' in line]
        for line in factory_lines:
            assert 'compute_route_' not in line, line
        write(OUT/(name+'-link-inputs.json'), dict(command=command,
              objects=[identity(p) for p in [OUT/(name+'.obj'), *added, *objects]],
              libraries=[library_identity(p) for p in libraries], factory_map_lines=factory_lines))
    return code


def exports(name):
    program = Path(template[0]).with_name('dumpbin.exe')
    return run(name+'-exports', [program, '/nologo', '/directives', OUT/(name+'-shared.obj')])


if __name__ == '__main__':
    action, *names = sys.argv[1:]
    for name in names:
        code = compile_one(name, action=='shared') if action in {'compile', 'shared'} else link(name) if action=='link' else \
               exports(name) if action=='exports' else run(name+'-run', [OUT/(name+'.exe')])
        if code:
            raise SystemExit(code)
