#pragma once
#include "hyle/graph/executable.h"
#include "hyle/compute/detail/provider_extension.h"
#include "hyle/compute/detail/queue_sequence.h"
#include "hyle/compute/detail/operation_access.h"
namespace hyle::graph { struct ProviderRegionPreparedVTable; struct ProviderRegionPrepared; }
namespace hyle::graph::detail {
// Optional cold interface of the exact selected prepared artifact. It inspects the real
// compiled region, including private imports/lowering, rather than Graph math.
inline constexpr compute::ProviderExtensionId kRegionProjectedReadExtensionId{
    0x48594c4550524f4aULL, 0x524541445245474eULL, 2};
struct RegionProjectedReadVTable final {
  // Exact original slot, borrowed only through this cold inspection. An empty
  // footprint must be true of its actual configured computation, not merely
  // supported by the schema or possible in another layout.
  Status (*inspect)(const ProviderRegionPrepared &, void *invocation,
                    std::uint32_t input_port,
                    compute::detail::OperationPreparedAccess *) noexcept = nullptr;
};
struct ReadProjection final {
  ValueId capacity;
  std::span<const ValueId> aliases;
  std::span<const NodeId> readers;
};
struct RegionAccessView final {
  std::uint32_t step=0;
  std::uint64_t graph_generation=0;
  std::span<const std::uint32_t> node_ordinals;
  const compute::detail::ProviderExtensionRef*owner=nullptr;
  void*prepared=nullptr;
  void*invocation=nullptr;
  ExecutionLaneId lane{};
  // Only visit_bound supplies these original prepared port arrays. Borrowed
  // for this cold callback; no tensor execution or ready permission is implied.
  std::span<const compute::ConstTensorView> inputs{};
  std::span<const compute::TensorView> outputs{};
  // Object-local implementation identity for trusted cold configuration.
  // A source capability/provider family alone never authorizes casting a
  // prepared artifact or configuring a sibling implementation's slot.
  const ProviderRegionPreparedVTable *prepared_vtable = nullptr;
};
using RegionAccessFn=Status(*)(void*,const RegionAccessView&) noexcept;
// Borrowed cold proof from the exact selected prepared implementation. The
// typed module qualifies its mathematical reader and actual physical port;
// core independently verifies every real consumer against this artifact.
// Neither a provider family nor a source capability alone grants page access.
struct ProjectedReader final {
  std::uint32_t step = 0;
  const ProviderRegionPreparedVTable *implementation = nullptr;
  const void *prepared = nullptr;
  std::uint32_t input_port = 0;
};
// A typed module validates the logical access chain. Core independently checks
// these exact selected implementations and their physical prepared input port.
struct ResourceProjection final {
  ValueId capacity, metadata;
  NodeId reader;
  std::span<const NodeId> access_nodes;
  compute::ProviderExtensionId capability;
};
struct OrderedGraphSubmission final {
  // Optional shared-Queue admission, before any consumer command. A delegated
  // native implementation admits its own exact pending reads and real source
  // ordering in its original guarded submit, without inventing a Queue.
  Status (*admit)(void*,ExecutionLaneId,compute::detail::QueueSequence&,
                  compute::LeaseUseBatch&) noexcept = nullptr;
  // Infallible after cold capacity/lifetime qualification. Maps the actual
  // accepted suffix in the same original public observation slot.
  compute::Completion (*map)(void*,compute::Completion&&) noexcept = nullptr;
  void* owner = nullptr;
  // Only these exact inputs defer their missing ready permission to admit.
  // Every other binding still goes through the ordinary lease checks.
  bool (*pending_input)(void*,ValueId) noexcept = nullptr;
  bool valid() const noexcept {
    const bool mapped = map && pending_input && owner;
    return mapped || (!admit && !map && !pending_input && !owner);
  }
};
// One optional typed resource owner, destroyed after borrowing native slots.
// This carries layouts/frames/source controls, never another execution slot.
struct ResourcePayloadVTable final {
  Status (*reset)(void *) noexcept = nullptr;
  void (*destroy)(void *) noexcept = nullptr;
};
// Explicit cold/idle opt-in only. Views borrow the callback scope, never a
// different execution slot. Ordinary compile/submit do not call this visitor.
struct RegionAccess final {
  // Private cold bridge. Selects exactly one ordinary prepared node;
  // it never exposes its provider state or changes public graph topology.
  HYLE_GRAPH_API static Result<bool> configure_operation(
      Invocation &, NodeId,
      compute::ProviderExtensionId, const void *) noexcept;
  // Cold adapter check against the retained target Context, independent of
  // tensor bindings. Replay preparation still owns the complete topology.
  HYLE_GRAPH_API static Status validate_queue(const Executable&,ExecutionLaneId,
      const compute::Queue&) noexcept;
  HYLE_GRAPH_API static Status visit(const Executable&,RegionAccessFn,void*) noexcept;
  HYLE_GRAPH_API static Status visit(Invocation&,RegionAccessFn,void*) noexcept;
  // Requires complete current bindings and the same original idle/result gate.
  // Uses the invocation's existing preallocated port arrays, without copying.
  HYLE_GRAPH_API static Status visit_bound(Invocation&,RegionAccessFn,void*) noexcept;
  HYLE_GRAPH_API static Result<void *> resource_payload(
      Invocation &, const ResourcePayloadVTable *) noexcept;
  // Takes payload ownership only after successful cold admission.
  HYLE_GRAPH_API static Status attach_resource_payload(
      Invocation &, const ResourcePayloadVTable *, void *) noexcept;
  // Cold opt-in capacity; ordinary borrowed invocations need no lease table.
  HYLE_GRAPH_API static Status reserve_reads(Invocation&,std::uint32_t,
      ResourceOptions) noexcept;
  // Trusted adapters supply the exact footprint and qualify every reader.
  // Rejects copies, ordinary operations, aliases and published capacity views.
  HYLE_GRAPH_API static Status bind_projected(Invocation&,ValueId,
      compute::ConstTensorView,std::span<const compute::ReadLease>,
      std::span<const ProjectedReader>) noexcept;
  // No ready permission is manufactured. The trusted adapter owns the typed
  // pending frame and supplies all exact guards in OrderedGraphSubmission.
  HYLE_GRAPH_API static Status bind_pending_projected(Invocation&,ValueId,
      compute::ConstTensorView,std::span<const ProjectedReader>) noexcept;
  HYLE_GRAPH_API static Result<compute::Completion> submit(Invocation&,
      std::span<const QueueBinding>,OrderedGraphSubmission) noexcept;
  // Observation/result gate only; failed or closed episodes may still return
  // their original source controls after actual retirement.
  HYLE_GRAPH_API static bool outcome_available(const Invocation&) noexcept;
  // Typed modules prove the logical access chain. Core checks this same plan,
  // each selected implementation/physical port, transparent aliases and bytes.
  HYLE_GRAPH_API static Status bind_read_projection(Invocation&,ReadProjection,
      compute::ConstTensorView,std::span<const compute::ReadLease>) noexcept;
  // No whole-capacity lease is minted. Only the actual selected prepared
  // implementation may authorize its projected physical input/empty footprint.
  HYLE_GRAPH_API static Result<mem::MemoryResourceRef> projection_resource(
      const Executable&,ResourceProjection,
      ExecutionLaneId* reader_lane=nullptr)noexcept;
  HYLE_GRAPH_API static Status bind_projection(Invocation&,
      ResourceProjection,
      compute::ConstTensorView,std::span<const compute::ReadLease>,bool pending=false)noexcept;
  // Cold successful idle caller output only; empty after readonly publication.
  HYLE_GRAPH_API static Result<compute::WriteLease> take_write(
      Invocation&,ValueId caller_output) noexcept;
private:
  static Status bind_projected_impl(Invocation&,ValueId,
      compute::ConstTensorView,std::span<const compute::ReadLease>,
      std::span<const ProjectedReader>,bool pending) noexcept;
};
} // namespace hyle::graph::detail
