#include "native_plan.h"
#include "numeric.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <span>
#include <type_traits>
#include <utility>

#include "hyle/math/scalar.h"
#include "hyle/mem/resource.h"
#include "hyle/simd/ops.h"
#include "hyle/simd/search.h"

namespace hyle::compute::native::internal {
namespace {

float reduction_identity(ReductionKind kind) noexcept {
  switch (kind) {
  case ReductionKind::kMinimum:
    return std::numeric_limits<float>::infinity();
  case ReductionKind::kMaximum:
    return -std::numeric_limits<float>::infinity();
  default:
    return std::numeric_limits<float>::quiet_NaN();
  }
}

void accumulate(ReductionKind kind, float value, float &result) noexcept {
  switch (kind) {
  case ReductionKind::kMinimum:
    if (!std::isnan(result))
      result = std::isnan(value) ? value : std::fmin(result, value);
    return;
  case ReductionKind::kMaximum:
    if (!std::isnan(result))
      result = std::isnan(value) ? value : std::fmax(result, value);
    return;
  default:
    return;
  }
}

float reduce_dense(ReductionKind kind, const float *input,
                   std::size_t count) noexcept {
  switch (kind) {
  case ReductionKind::kMinimum:
    return simd::min_value(input, count);
  case ReductionKind::kMaximum:
    return simd::max_value(input, count);
  default:
    return std::numeric_limits<float>::quiet_NaN();
  }
}

template <class Value>
void reduce_narrow(const NativePlan &plan, const TensorDesc &description,
                   const std::byte *input, Value *output) noexcept {
  const std::size_t count = plan.parameters[2];
  const auto dimensions = description.dimensions();
  const auto strides = description.byte_strides();
  std::array<float, 128> tile;
  for (std::size_t result = 0; result < plan.parameters[1]; ++result) {
    float accumulator = reduction_identity(plan.reduction_kind);
    if (plan.reduction_route != ReductionRoute::kGeneral) {
      for (std::size_t begin = 0; begin < count; begin += tile.size()) {
        const std::size_t size = (std::min)(tile.size(), count - begin);
        numeric::load_tile<Value>(input, result * count + begin, tile.data(),
                                  size);
        accumulate(plan.reduction_kind,
                   reduce_dense(plan.reduction_kind, tile.data(), size),
                   accumulator);
      }
    } else {
      // Decode the unreduced coordinates once per output. Every input is
      // visited once overall; no full-input scan for each output tile.
      std::size_t remaining = result;
      std::size_t base = 0;
      for (std::size_t reverse = 0; reverse < dimensions.size(); ++reverse) {
        const std::size_t axis = dimensions.size() - 1 - reverse;
        if ((plan.reduction_axes_mask & (std::uint8_t{1} << axis)) != 0)
          continue;
        const auto extent = static_cast<std::size_t>(dimensions[axis]);
        base += (remaining % extent) * static_cast<std::size_t>(strides[axis]);
        remaining /= extent;
      }
      for (std::size_t reduced = 0; reduced < count; ++reduced) {
        remaining = reduced;
        std::size_t offset = base;
        for (std::size_t reverse = 0; reverse < dimensions.size(); ++reverse) {
          const std::size_t axis = dimensions.size() - 1 - reverse;
          if ((plan.reduction_axes_mask & (std::uint8_t{1} << axis)) == 0)
            continue;
          const auto extent = static_cast<std::size_t>(dimensions[axis]);
          offset +=
              (remaining % extent) * static_cast<std::size_t>(strides[axis]);
          remaining /= extent;
        }
        accumulate(plan.reduction_kind, numeric::load<Value>(input + offset),
                   accumulator);
      }
    }
    output[result] = numeric::encode<Value>(accumulator);
  }
}

template <class Value>
detail::EnqueueResult
submit_reduction(const NativePlan &plan,
                 std::span<const ConstTensorView> inputs,
                 std::span<const TensorView> outputs) noexcept {
  if (inputs.size() != 1 || outputs.size() != 1)
    return completed(Status::Internal("native reduction plan is invalid"));
  const std::size_t input_elements = plan.parameters[0];
  const std::size_t output_elements = plan.parameters[1];
  if (output_elements == 0)
    return completed(Status::Ok());

  const mem::ConstBufferView input_storage = inputs[0].storage();
  const mem::BufferView output_storage = outputs[0].storage();
  if (input_elements != 0 && !input_storage.resource().properties().has(
                                 mem::MemoryProperty::kHostDeviceCoherent)) {
    Status status = input_storage.invalidate();
    if (!status.ok())
      return completed(std::move(status));
  }

  mem::HostMapping input_mapping;
  const std::byte *input_data = nullptr;
  if (input_elements != 0) {
    auto mapping = input_storage.map_host();
    if (!mapping)
      return completed(std::move(mapping).error());
    input_mapping = std::move(*mapping);
    input_data = input_mapping.bytes().data();
  }
  auto output_result = output_storage.map_host(mem::HostAccess::kWrite);
  if (!output_result) {
    input_mapping.close().IgnoreError();
    return completed(std::move(output_result).error());
  }
  mem::HostMapping output_mapping = std::move(*output_result);
  auto writable = output_mapping.writable_bytes();
  if (!writable) {
    output_mapping.close().IgnoreError();
    input_mapping.close().IgnoreError();
    return completed(std::move(writable).error());
  }
  auto *output_data = reinterpret_cast<Value *>(writable->data());
  if (!aligned_for_storage(output_data,
                           outputs[0].description().required_alignment()) ||
      (input_elements != 0 &&
       !aligned_for_storage(input_data,
                            inputs[0].description().required_alignment()))) {
    output_mapping.close().IgnoreError();
    input_mapping.close().IgnoreError();
    return completed(Status::FailedPrecondition(
        "CPU reduction mapping does not satisfy tensor alignment"));
  }


    reduce_narrow(plan, inputs[0].description(), input_data, output_data);


  Status terminal = Status::Ok();
  if (!output_storage.resource().properties().has(
          mem::MemoryProperty::kHostDeviceCoherent)) {
    preserve_first_error(terminal, output_mapping.flush());
  }
  preserve_first_error(terminal, output_mapping.close());
  preserve_first_error(terminal, input_mapping.close());
  return completed(std::move(terminal));
}

std::uint8_t reduction_axes_mask(const Reduce &reduce,
                                 std::size_t rank) noexcept {
  if (reduce.axes.is_all()) {
    return rank == kMaxTensorRank
               ? std::numeric_limits<std::uint8_t>::max()
               : static_cast<std::uint8_t>((std::uint16_t{1} << rank) - 1);
  }
  std::uint8_t result = 0;
  for (const std::int8_t requested : reduce.axes.values()) {
    const std::int32_t axis =
        requested < 0 ? static_cast<std::int32_t>(rank) + requested : requested;
    result = static_cast<std::uint8_t>(result | (std::uint8_t{1} << axis));
  }
  return result;
}

std::uint8_t all_axes_mask(std::size_t rank) noexcept {
  return rank == kMaxTensorRank
             ? std::numeric_limits<std::uint8_t>::max()
             : static_cast<std::uint8_t>((std::uint16_t{1} << rank) - 1);
}

} // namespace

Status prepare_reduction(Operation operation,
                         std::span<const TensorDesc> inputs,
                         std::span<const TensorDesc> outputs,
                         NativePlan &plan) noexcept {
  if (inputs.size() != 1 || outputs.size() != 1)
    return Status::Internal("native Reduce arity is invalid");
  const DataType type = inputs[0].data_type();
  if ((type != DataType::kFloat32 && type != DataType::kFloat16 &&
       type != DataType::kBFloat16) ||
      outputs[0].data_type() != type || !inputs[0].is_plain() ||
      !outputs[0].is_plain() || !outputs[0].is_dense()) {
    return Status::Unimplemented("native Reduce requires plain "
                                 "float32/float16/bfloat16 and dense output");
  }
  const Reduce *reduce = operation.get_if<Reduce>();
  if (reduce == nullptr ||
      (reduce->kind != ReductionKind::kMinimum && reduce->kind != ReductionKind::kMaximum) ||
      (inputs[0].data_type() != DataType::kFloat16 &&
       !(inputs[0].data_type() == DataType::kBFloat16 && reduce->kind == ReductionKind::kMaximum)))
    return Status::Unimplemented("native Reduce retains qualified narrow Min/Max only");
  if (reduce == nullptr)
    return Status::Internal("native Reduce descriptor is missing");
  if (reduce->accumulation_type != DataType::kUnknown &&
      reduce->accumulation_type != DataType::kFloat32) {
    return Status::Unimplemented(
        "native Reduce currently supports float32 accumulation");
  }
  if (type != DataType::kFloat32 &&
      reduce->accumulation_type != DataType::kFloat32) {
    return Status::Unimplemented(
        "native half Reduce requires explicit float32 accumulation");
  }

  auto input_elements = inputs[0].element_count();
  if (!input_elements)
    return std::move(input_elements).error();
  auto output_elements = outputs[0].element_count();
  if (!output_elements)
    return std::move(output_elements).error();
  const std::uint8_t axes = reduction_axes_mask(*reduce, inputs[0].rank());
  std::size_t reduced_elements = 1;
  for (std::size_t axis = 0; axis < inputs[0].rank(); ++axis) {
    if ((axes & (std::uint8_t{1} << axis)) == 0)
      continue;
    auto extent =
        math::try_integer_cast<std::size_t>(inputs[0].dimensions()[axis]);
    if (!extent)
      return Status::OutOfRange("reduction extent exceeds size_t");
    auto next = math::try_multiply(reduced_elements, *extent);
    if (!next)
      return Status::OutOfRange("reduction extent product overflows size_t");
    reduced_elements = *next;
  }

  ReductionRoute route = ReductionRoute::kGeneral;
  if (inputs[0].is_dense()) {
    const std::uint8_t all_axes = all_axes_mask(inputs[0].rank());
    if (axes == all_axes) {
      route = ReductionRoute::kAllDense;
    } else if (inputs[0].rank() != 0 &&
               axes == (std::uint8_t{1} << (inputs[0].rank() - 1))) {
      route = ReductionRoute::kLastAxisDense;
    }
  }

  plan.parameters = {*input_elements, *output_elements, reduced_elements};
  plan.reduction_kind = reduce->kind;
  plan.reduction_route = route;
  plan.reduction_axes_mask = axes;
  plan.submit_route = type == DataType::kFloat16
                          ? &submit_reduction<simd::float16_t>
                          : &submit_reduction<simd::bfloat16_t>;
  return Status::Ok();
}

} // namespace hyle::compute::native::internal
