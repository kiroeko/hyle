from pathlib import Path
import hashlib, json, os, subprocess, sys, time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
OLD = ROOT / '.scratch/inference-feature-completion-2026-10-18/mla'
BASE = ROOT / '.scratch/build-compute-v2-dev'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
env = windows_compiler_environment(read_cache(BASE)); env['VSLANG'] = '1033'
env['PATH'] = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64' + os.pathsep + str(BASE / 'bin') + os.pathsep + env['PATH']
old = json.loads((OLD / 'host-commands.json').read_text())
template = next(x['command'] for x in old if x['tag'] == 'batch-layout-compile')
flags = template[1:-2] + ['/I' + str(ROOT / 'src/compute_route_cuda'), '/DHYLE_TESTING']
gtest = Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
flags += ['/external:I' + str(gtest)]
cl = Path(template[0])
history = []

def run(tag, command, expected=0):
    command = list(map(str, command)); start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=180)
    (OUT / (tag + '.stdout.log')).write_bytes(p.stdout)
    (OUT / (tag + '.stderr.log')).write_bytes(p.stderr)
    history.append(dict(tag=tag, command=command, exit=p.returncode, seconds=time.monotonic()-start))
    (OUT / 'commands.json').write_text(json.dumps(history, indent=2) + '\n')
    print(tag, p.returncode, round(time.monotonic()-start, 3), p.stdout.decode(errors='replace')[-2200:], p.stderr.decode(errors='replace')[-1000:], flush=True)
    if p.returncode != expected: raise SystemExit(p.returncode or 1)

def compile(source, stem, extra=()):
    run(stem + '-compile', [cl, *flags, *extra, '/Tp' + str(source), '/Fo' + str(OUT / (stem + '.obj'))])

compile(OUT / 'weights.cc.before', 'weights-before')
compile(ROOT / 'src/compute_route_cuda/weights.cc', 'weights-after')
compile(ROOT / 'src/compute_backend_cuda/cuda_backend.cc', 'backend-counted', ['/FI' + str(OUT / 'count_native.h')])
compile(OUT / 'probe.cc', 'probe')
compile(ROOT / 'tests/compute_route_cuda/context_test.cc', 'canonical-test')
link_template = next(x['command'] for x in reversed(old) if x['tag'] == 'mla-link')
for p in link_template:
    if p.endswith('.lib') and Path(p).is_absolute():
        env['PATH'] = str(Path(p).parent) + os.pathsep + env['PATH']

def link(stem, test_obj, weight_obj, gtest=False):
    command = [arg for arg in link_template if arg != str(OLD / 'consumer.obj')]
    command = [arg.replace(str(OLD / 'public-mla.exe'), str(OUT / (stem + '.exe')))
               .replace(str(OLD / 'public-mla.map'), str(OUT / (stem + '.map'))) for arg in command]
    command[1:1] = [str(OUT / (test_obj + '.obj')), str(OUT / (weight_obj + '.obj')), str(OUT / 'backend-counted.obj')]
    if gtest:
        command += [str(BASE / 'lib/gtest.lib'), str(BASE / 'lib/gtest_main.lib'), str(OUT / 'counter-forward.obj')]
    run(stem + '-link', command)
    return OUT / (stem + '.exe')

before = link('before', 'probe', 'weights-before')
after = link('after', 'probe', 'weights-after')
run('hardware', ['nvidia-smi', '--query-gpu=name,compute_cap,driver_version,memory.total', '--format=csv'])
run('before', [before, 'before'])
run('after', [after])
compile(OUT / 'counter_forward.cc', 'counter-forward')
canonical = link('canonical', 'canonical-test', 'weights-after', gtest=True)
run('canonical', [canonical, '--gtest_filter=CudaRoute.WeightOrder*'])
paths = [ROOT / 'src/compute_route_cuda/weights.cc', ROOT / 'tests/compute_route_cuda/context_test.cc',
         ROOT / 'src/compute_backend_cuda/cuda_backend.cc']
paths += [Path(p) for p in link_template if p.endswith(('.obj', '.lib')) and Path(p).is_file()]
(OUT / 'identities.json').write_text(json.dumps([dict(path=str(p), bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths], indent=2) + '\n')
