from pathlib import Path
import hashlib, json, os, subprocess, sys, time
ROOT = Path(__file__).resolve().parents[3]; OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
env = windows_compiler_environment(read_cache(ROOT / '.scratch/build-compute-v2-dev'))
env['VSLANG'] = '1033'
env['PATH'] = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64' + os.pathsep + str(ROOT / '.scratch/build-compute-v2-dev/bin') + os.pathsep + env['PATH']
rows = json.loads((OUT / 'commands.json').read_text())
commands = [(tag, next(r['command'] for r in rows if r['tag'] == tag))
            for tag in ['canonical-test-compile', 'canonical-link', 'canonical']]
for _, command in commands:
    for arg in command:
        if arg.endswith('.lib') and Path(arg).is_absolute():
            env['PATH'] = str(Path(arg).parent) + os.pathsep + env['PATH']
for tag, command in commands:
    tag = 'final-' + tag; start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=60)
    (OUT / (tag + '.stdout.log')).write_bytes(p.stdout); (OUT / (tag + '.stderr.log')).write_bytes(p.stderr)
    rows.append(dict(tag=tag, command=command, exit=p.returncode, seconds=time.monotonic()-start))
    (OUT / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(tag, p.returncode, p.stdout.decode(errors='replace')[-1600:], flush=True)
    if p.returncode: raise SystemExit(p.returncode)
identities = json.loads((OUT / 'identities.json').read_text())
for row in identities:
    path = Path(row['path'])
    if path == ROOT / 'tests/compute_route_cuda/context_test.cc':
        row.update(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(OUT / 'identities.json').write_text(json.dumps(identities, indent=2) + '\n')
