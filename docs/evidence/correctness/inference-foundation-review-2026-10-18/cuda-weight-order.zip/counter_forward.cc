#include <cuda_runtime_api.h>
extern "C" cudaError_t CUDARTAPI hyle_counted_wait(cudaStream_t stream, cudaEvent_t event, unsigned flags) {
  return cudaStreamWaitEvent(stream, event, flags);
}
extern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t event, cudaStream_t stream) {
  return cudaEventRecord(event, stream);
}
