#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/cuda_weights.h>
#include <hyle/compute/detail/completion_access.h>
#include <hyle/compute/detail/queue_sequence.h>
#include "cuda_internal.h"
#include <array>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace c = hyle::compute;
namespace n = c::cuda;
namespace d = n::detail;
namespace m = hyle::mem;
static unsigned waits = 0, records = 0;
extern "C" cudaError_t CUDARTAPI hyle_counted_wait(cudaStream_t stream, cudaEvent_t event, unsigned flags) {
  ++waits; return cudaStreamWaitEvent(stream, event, flags);
}
extern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t event, cudaStream_t stream) {
  ++records; return cudaEventRecord(event, stream);
}
static void require(bool valid, const char *message) {
  if (!valid) { std::fprintf(stderr, "FAIL %s\n", message); std::exit(1); }
}
static bool fail_query = false;
static cudaError_t observed_query(cudaEvent_t event) noexcept {
  const auto actual = cudaEventQuery(event);
  if (std::exchange(fail_query, false)) {
    require(actual == cudaSuccess, "late-error fixture event must actually be complete");
    return cudaErrorInvalidValue;
  }
  return actual;
}
struct Gate {
  std::atomic<bool> open{false};
  static void CUDART_CB block(void *opaque) noexcept {
    static_cast<Gate *>(opaque)->open.wait(false, std::memory_order_acquire);
  }
  void release() noexcept { open.store(true, std::memory_order_release); open.notify_all(); }
  ~Gate() { release(); }
};
int main(int argc, char **argv) {
  const bool baseline = argc > 1 && std::strcmp(argv[1], "before") == 0;
  auto context = c::Context::create(n::device(0).value()).value();
  auto host = n::MemoryResource::create(context, n::MemoryKind::kPinnedHost).value();
  auto device = n::MemoryResource::create(context, n::MemoryKind::kDevice).value();
  auto copy = context.create_queue().value(), work = context.create_queue().value();
  require(copy.reserve_completions(16).ok() && work.reserve_completions(16).ok(), "cold completion reserve");
  const auto desc = c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t, 1>{4}).value();
  auto source = m::Buffer::create(m::system_resource(), 16, 256).value();
  const std::array<float, 4> expected{1, -2, 3, 4};
  require(source.view().write(std::as_bytes(std::span(expected))).ok(), "source write");
  const std::array catalog{n::WeightSpec{7, desc}};
  auto slots = n::WeightSlots::create(context, host, device, catalog, 16).value();
  const std::array selected{n::WeightFragment{7, c::ConstTensorView::create(desc, source.view()).value()}};
  auto batch = slots.upload(0, selected, copy).value();
  require(cudaStreamSynchronize(n::stream(copy).value()) == cudaSuccess, "native upload readiness");
  // Do not poll/wait the upload Completion. This is precisely the warm Graph
  // driver's state after previous destination prefixes completed.
  waits = records = 0;
  for (unsigned i = 0; i < 8; ++i) {
    auto prefix = batch.order(work);
    require(bool(prefix), "order ready upload");
    require(prefix->wait().ok(), "retire destination prefix");
  }
  std::printf("%s native-ready/upload-unobserved: episodes=8 WaitEvent=%u EventRecord=%u\n", baseline ? "before" : "after", waits, records);
  require(waits == (baseline ? 8U : 0U) && records == (baseline ? 8U : 0U), "warm native call counts");
  std::array<float, 4> actual{};
  require(batch.binding(7)->storage().read(std::as_writable_bytes(std::span(actual))).ok() && actual == expected, "weight payload equality");
  {
    auto occupied = c::detail::QueueSequence::begin(work).value();
    auto result = batch.order(work);
    require(!result && result.error().IsFailedPrecondition(), "busy admission preserved");
    require(bool(occupied.finish()), "empty occupied sequence retirement");
  }
  auto other = c::Context::create(n::device(0).value()).value();
  auto foreign = other.create_queue().value();
  auto wrong = batch.order(foreign);
  require(!wrong && wrong.error().IsInvalidArgument(), "foreign owner preserved");
  auto closed = context.create_queue().value(); require(closed.close().ok(), "close queue");
  auto rejected = batch.order(closed);
  require(!rejected && rejected.error().IsFailedPrecondition(), "closed admission preserved");
  std::puts("busy / foreign / closed admission PASS");
  batch = {};
  {
    Gate gate;
    auto blocked = n::submit(copy, [&gate](cudaStream_t s) noexcept { return cudaLaunchHostFunc(s, &Gate::block, &gate); }).value();
    batch = slots.upload(0, selected, copy).value();
    waits = records = 0;
    auto prefix = batch.order(work);
    require(bool(prefix), "pending upload admission");
    auto pending = prefix->poll();
    const auto count_wait = waits, count_record = records;
    gate.release();
    require(pending && *pending == c::CompletionPoll::kPending, "pending source remains asynchronous");
    require(prefix->wait().ok() && blocked.wait().ok(), "pending source completion");
    require(count_wait == 1 && count_record == 1, "pending native path preserved");
    std::printf("pending upload: WaitEvent=%u EventRecord=%u PASS\n", count_wait, count_record);
  }
  batch = {};
  if (!baseline) {
    batch = slots.upload(0, selected, copy).value();
    require(cudaStreamSynchronize(n::stream(copy).value()) == cudaSuccess, "late-error native readiness");
    const auto previous = d::set_completion_observation_hooks({&observed_query, nullptr});
    fail_query = true; waits = records = 0;
    auto error = batch.order(work);
    d::set_completion_observation_hooks(previous);
    require(!error && error.error().IsInvalidArgument(), "source late error propagated");
    require(waits == 0 && records == 0, "source error admits no dependent command");
    auto error_again = batch.order(work);
    require(!error_again && error_again.error().IsInvalidArgument(), "settled source error sticky");
    auto empty = c::detail::QueueSequence::begin(work);
    require(bool(empty) && bool(empty->finish()), "error releases destination admission");
    std::puts("late observation error propagates/sticks; no dependent commands; admission rollback PASS");
  }
  std::puts("PASS weight-order bounded real CUDA probe");
}
