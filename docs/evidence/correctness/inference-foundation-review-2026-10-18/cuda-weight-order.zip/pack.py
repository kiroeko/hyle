from pathlib import Path
import difflib, hashlib, json, zipfile
ROOT = Path(__file__).resolve().parents[3]; OUT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
diff = ''
for name in ['src/compute_route_cuda/weights.cc', 'tests/compute_route_cuda/context_test.cc']:
    path = ROOT / name
    diff += ''.join(difflib.unified_diff(
        (OUT / (path.name + '.before')).read_text().splitlines(keepends=True),
        path.read_text().splitlines(keepends=True), fromfile='before/' + name, tofile='after/' + name))
(OUT / 'product.diff').write_text(diff, encoding='utf-8', newline='\n')
fresh = [dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for p in sorted(OUT.glob('*.obj'))]
(OUT / 'fresh-object-identities.json').write_text(json.dumps(fresh, indent=2) + '\n')
files = {p.name:p for p in OUT.iterdir() if p.is_file() and
    (p.suffix in {'.py', '.cc', '.h', '.json', '.log', '.txt', '.diff', '.before'})}
for name in ['src/compute_route_cuda/weights.cc', 'tests/compute_route_cuda/context_test.cc',
             'src/compute_backend_cuda/cuda_backend.cc', 'src/compute_backend_cuda/cuda_internal.h']:
    files['source/' + name] = ROOT / name
identities = [dict(path=n, bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for n,p in sorted(files.items())]
(OUT / 'package-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
files['package-identities.json'] = OUT / 'package-identities.json'
archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name,path in sorted(files.items()): z.write(path, name)
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
print(json.dumps(dict(path=str(archive), files=len(files), bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())), indent=2))
