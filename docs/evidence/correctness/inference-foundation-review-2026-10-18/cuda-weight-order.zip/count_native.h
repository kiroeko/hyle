#pragma once
#include <cuda_runtime_api.h>
extern "C" cudaError_t CUDARTAPI hyle_counted_wait(cudaStream_t, cudaEvent_t, unsigned);
extern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t, cudaStream_t);
#define cudaStreamWaitEvent hyle_counted_wait
#define cudaEventRecord hyle_counted_record
