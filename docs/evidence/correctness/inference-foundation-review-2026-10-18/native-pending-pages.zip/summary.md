# Native pending pages and genuine empty footprint

2026-10-19. This is one completed vertical of the active architecture refactor,
not completion of the full goal or qualification of every backend/model.

The original Graph Invocation, resource payload, cursor, output observations and
DependentCompletion carry the actual native CopyBatchUpdate. The selected leaf
cold-creates its one typed source owner and admits the original ready/ordered
page permissions on its actual guarded submit. There is no second Graph Plan,
Invocation, executor, fake Queue or whole-capacity lease.

Empty ready frames retain the original capacity and generation without a page
ReadLease. Core admits an empty projection only when the exact selected prepared
slot proves its actual configured program has no cache reads. An ordinary Neg
reader cannot claim this permission.

| Actual check | Result and boundary |
|---|---|
| `034-pending-run` | PASS; real non-software Vulkan, F16 GQA8/2 D256, 64 steps, two requests growing17..80/17..48, Q2/Q18 variants with two original slots each, two native page nodes sharing one Update, CPU Abs/Cast and Cast/Neg. Both outputs exactly agree and independently satisfy the unchanged FP64 .002 budget. Only196,608 bytes of new rows copied; original generation, unused page9, output/completion reuse gates and Update recovery checked. |
| `036-empty-run` | PASS with final Source; real Q0/ref0 CPU/native/CPU chain, exact empty frames and both capacity writers held, zero output and original result gate. |
| `015-controls-run` |2/2 PASS before the later Source-only fix: typed empty arena capacity/permissions and selected prepared artifact/physical-port/ordinary-reader empty rejection. The Source code is not exercised by these controls. |
| Incremental compile | Changed host TUs and the two controls only, using the previous matching99-object closure plus focused replacements. Original SDK, kernels, shaders and vendor objects reused. No broad rebuild or performance claim. |

The two-node consumer exposed a real ABA bug after twelve successful episodes.
The first output was correct while the second read an old zero buffer. The old
cold-copy cache compared a borrowed AllocationToken address; replacing the native
program could free that token and allocate a new token at the same address, while
the original recording still pinned the old VkBuffer. `031-pending-run` retained
the old fast path and logged one token whose actual VkBuffer key changed from
2607062931408 to2607048813648 before reproducing the same numerical failure.
The final Source compares actual canonical physical spans at cold binding,
retains valid recording reuse, updates current wrapper checks, and adds no hot
physical resolution or allocation. The unchanged64-step consumer then passed.

Original failed compilation/fixture attempts, the missing empty recipe budget,
the insufficient two-output fixture backing, failed numerical runs, diagnostic
and final source/object identities are retained separately in the logs.

Remaining limits: mixed ready/pending ports and accepted failure/unknown-retirement
injection are source-reviewed, not newly numerically qualified by the successful
all-pending consumer. Native pending requires the same actual Runtime and its
existing fixed queue-prefix import; async/IREE source seams remain unsupported.
Apple and remaining legacy consumers still need migration; old runtimes remain.

Actual inference review also confirmed an unfixed Q interface gap: capacity18 /
decode2 currently makes upstream Abs/Cast and Q transfer process18 rows, while
attention consumes only2. `graph-batch/active-query-review.txt` records the real
call chain and the minimal layout-aware Direct/Graph/native descriptor change.
This is an element/byte count, not a measured9x latency. CUDA Qwen currently uses
actual-T ragged graphs and is not affected by this specific seam. Its independent
numerical acceptance and fair whole-model performance comparison remain open.
