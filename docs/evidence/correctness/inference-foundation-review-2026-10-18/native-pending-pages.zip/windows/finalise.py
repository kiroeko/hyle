"""Freeze current pending/empty consumer results. No compile/run/archive/delete."""
from pathlib import Path
import difflib,hashlib,json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
BASE=ARCH/'native-ready-pages/windows'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

commands=read(OUT/'commands.json')
assert len(commands)==36
assert all(commands[i-1]['exit']==0 for i in [15,21,32,33,34,35,36])
assert read(OUT/'controls-results.json')['tests']==2
assert read(OUT/'controls-results.json')['failures']==0
base=read(OUT/'matched-link-base.json')
assert all(identity(x['path'])==x for x in base['objects'])
assert all(identity(ROOT/s)['sha256']==base['compiled_source_sha256'][s] for s in base['selected_sources'])
old={r['relative']:r for r in read(BASE/'final-source-identities.json')}
extra={
 'tests/compute_batch/pending_paged_receiver_native_consumer.cc','tests/compute_batch/paged_arena_test.cc',
 'tests/graph/region_provider_test.cc','tests/graph_batch/CMakeLists.txt',
 'include/hyle/graph/vulkan.h','include/hyle/compute/detail/paged_arena_access.h',
 'src/compute_route_vulkan/vulkan_memory_internal.h','src/graph_batch/native_paged_regions.h',
 'src/graph_route_vulkan/native_paged_region.h','src/graph_route_vulkan/native_paged_pending.h',
 'src/graph_route_vulkan/native_paged_pending.cc'}
delta={s for s,row in old.items() if identity(ROOT/s)['sha256']!=row['sha256']}
delta|=extra
source_rows=[]
for source in sorted(set(base['selected_sources'])|delta):
 row=dict(relative=source,**identity(ROOT/source))
 if source in base['selected_sources']:row['compiled_object']=base['selected_sources'][source]
 row['current_snapshot']=source in delta;source_rows.append(row)
 if source in delta:
  target=OUT/'candidate'/source;target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes((ROOT/source).read_bytes())
write('final-source-identities.json',source_rows)
write('final-object-identities.json',base['objects'])
write('final-library-identities.json',[identity(x) for x in base['command'] if x.lower().endswith('.lib') and Path(x).is_file()])

for source in [r['path'] for r in read(OUT/'before-identities.json')]:
 before=OUT/'before'/source;after=ROOT/source
 (OUT/(Path(source).name+'.diff')).write_text(''.join(difflib.unified_diff(
  before.read_text(encoding='utf-8').splitlines(True),after.read_text(encoding='utf-8').splitlines(True),
  fromfile='before/'+source,tofile=source)),encoding='utf-8')

actual_images={}
for which,index in [('controls',13),('pending',33),('empty',35)]:
 row=commands[index-1];assert row['tag']==which+'-link' and row['exit']==0
 objects=[identity(x) for x in row['command'] if x.lower().endswith('.obj')]
 actual_images[which]=dict(link_command=index,objects=objects,
  images=[identity(OUT/(which+suffix)) for suffix in ['.exe','.map']])
write('actual-image-inputs.json',actual_images)
retained=[identity(p) for p in sorted(OUT.glob('*.obj'))]
retained += [identity(p) for p in sorted((ARCH/'native-pending-pages/vulkan-leaf').glob('*.obj'))]
write('retained-objects.json',retained)
files=[identity(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix.lower() in ['.exe','.map','.exp','.lib']]
write('cleanup-candidates.json',dict(files=files,bytes=sum(x['bytes'] for x in files),
  retained_objects=retained,no_deletion=True))

summary=dict(status='actual_native_pending_and_empty_passed',
 final_source=dict(path='src/graph_route_vulkan/execution_source.cc',sha256=identity(ROOT/'src/graph_route_vulkan/execution_source.cc')['sha256']),
 pending=dict(run_command=34,log=commands[33]['stderr'],exit=0,steps=64,query_type='F16',depth=256,
  query_heads=8,kv_heads=2,requests=2,history_rows=['17..80','17..48'],active_query_shapes=[2,18],
  original_graph_slots_per_shape=2,total_original_graph_slots=4,page_nodes=2,dirty_bytes=196608,
  oracle='Original independent FP64 attention, exact equality of both published CPU outputs, unchanged absolute tolerance 0.002.',
  preserved=['Original native CopyBatchUpdate with two dependent phases and mutable page controls',
   'CPU Abs/Cast -> two native page attention readers of one Update -> CPU Cast/Neg',
   'Mixed decode/prefill query spans, continuous append and physical page transitions',
   'Only new row bytes copied, untouched history and original page generations checked',
   'Untouched page9 remains independently writable while the receiver owns other page inputs',
   'Completion/result observers deny prepare/control recovery; only after release does take_update return original writers/invocation',
   'Both caller outputs have independent nonoverlapping WriteLease ranges in an original per-slot LeasePool']),
 empty=dict(run_command=36,log=commands[35]['stderr'],exit=0,query_rows=0,page_refs=0,depth=64,
  scenario='Original CPU Abs/Cast -> actual Q-only native page Program -> CPU Cast/Neg; true keys.read(empty,{})/values frames, actual page writers stay held.',
  assertions=['Both typed empty frames valid with zero page_count','Actual public output description requires zero bytes',
   'Actual native table uploaded_bytes==0','Query active uses retire; page writers stay valid',
   'Empty GraphOutput rejects prepare/reset, then original reset/close succeeds'],final_source_relinked=True),
 controls=dict(run_command=15,tests=2,failures=0,log=commands[14]['stdout'],
  exact_filter='PagedArena.TrueEmptyAttentionFrameRetainsCapacityWithoutPagePermissions:GraphRouteBoundary.ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort',
  note='Run before the later Vulkan-only physical copy ABA fix; not rerun, as requested. Shared core/Arena/proof sources unchanged afterwards.'),
 source_copy_aba=dict(before_failures=[25,28],diagnostic_run=31,final_run=34,
  actual_diagnostic='Same AllocationToken address but source VkBuffer key changed 2607062931408 -> 2607048813648; destination key unchanged; range73728 bytes.',
  failed_step=12,first_oracle_error=2.5237895648524966e-05,second_oracle_error=.14158155266683164,
  source_fix='Cold canonical PhysicalCopyResource cache replaces borrowed token-address cache; no added hot span resolution/allocation.',
  diagnostic_source_object='source-aba-diagnostic.json',diagnostic_image='pending-diagnostic-image.json'),
 retained_failures=[dict(command=1,cause='Product free helper accessed private prepared/slot fields; root moved the helper into existing RegionAccess friend.'),
  dict(command=14,cause='New empty fixture omitted required finite nonzero metadata budget; fixed to32 bytes.'),
  dict(commands=[16,22],cause='Migrated caller pool had capacity for one output although two output blocks were required; corrected exact backing geometry.'),
  dict(commands=[25,28,31],cause='Actual native copy token ABA; hard same-output/oracle checks retained and final Source fixed.')],
 compile_scope=dict(baseline='native-ready-pages/windows matched99 objects/current owned Operation+Provider16/Region26',
  operation_header_sha256=identity(ROOT/'include/hyle/compute/operation.h')['sha256'],provider_contract=16,region_spi=26,
  projected_read_private_extension=2,native_page_private_extension=2,
  current_stage_objects=len(list(OUT.glob('*.obj'))),backend_objects=3,
  numerical_sdk_kernel_shader_build=False),
 remaining=['This positive journey does not run cancellation, abandonment, late/unknown errors, capacity/OOM or foreign Update risk modes.',
  'The pipeline uses two pending cache frames; ready/pending mixed K/V ports were implemented but are not exercised here.',
  'The native query capacity remains18 even for active decode2; CPU prefix/copy can still process the full declared capacity.',
  'Apple legacy conditional paths and other old native risk/MLA/encoded consumers remain to migrate.',
  'No BF16/new geometry matrix or throughput benchmark was run.'],
 hardware_query='hardware-query.json (read-only physical-machine identity; native consumer separately rejects software Vulkan)',
 no_live_process=True,no_archive=True,no_deletion=True)
write('summary.json',summary)
print(json.dumps(dict(summary=identity(OUT/'summary.json'),sources=len(source_rows),delta_sources=len(delta),
 objects=len(base['objects']),retained_objects=len(retained),cleanup_files=len(files),cleanup_bytes=sum(x['bytes'] for x in files))))
