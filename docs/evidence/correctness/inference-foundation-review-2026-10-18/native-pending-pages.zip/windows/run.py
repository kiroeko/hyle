"""Incremental native pending/empty consumers over the frozen ready closure."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
BASE=ARCH/'native-ready-pages/windows'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def source_key(p):return Path(p).relative_to(ROOT).as_posix()
def recipes():
 rows={r['source']:r['command'] for r in read(BASE/'compile-plan.json')}
 # Both test consumers use the same existing Vulkan Graph test module flags.
 source='tests/compute_batch/pending_paged_receiver_native_consumer.cc'
 original=rows['tests/graph_batch/native_paged_joint_consumer.cc']
 rows[source]=[x for x in original if not x.lower().endswith('.cc') and not x.lower().startswith('/fo')]+[
  '/DHYLE_PENDING_NATIVE_JOINT_GRAPH=1',str(ROOT/source)]
 # Reuse actual successful gtest compile flags, not consumer-only macros.
 commands=read(ARCH/'native-inputs/windows/commands.json')
 for source in ['tests/graph/region_provider_test.cc','tests/compute_batch/paged_arena_test.cc']:
  match=next((r['command'] for r in reversed(commands) if r.get('exit')==0 and any(
   str(x).replace('\\','/').endswith('tests/graph/region_provider_test.cc') for x in r.get('command',[]))),None)
  assert match,'real Graph gtest recipe must be available'
  rows[source]=[x for x in match if not x.lower().endswith('.cc') and not x.lower().startswith('/fo')]+[str(ROOT/source)]
 return rows
def command_for(source):
 rows=recipes();original=rows[source]
 stem=source.replace('/','--').removesuffix('.cc')
 command=[x for x in original if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]
 return stem,[*command,str(ROOT/source),'/Fo'+str(OUT/(stem+'.obj'))]
def run(tag,command,timeout=60):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';command=list(map(str,command))
 row=dict(tag=tag,command=command,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
 rows.append(row);write('commands.json',rows)
 compiler=recipes()['src/graph/executable.cc'][0]
 env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler,'CMAKE_C_COMPILER':compiler})
 torch=next(str(Path(x).parent) for x in read(BASE/'matched-link-base.json')['command'] if x.lower().endswith('torch_cpu.lib'))
 env['PATH']=torch+os.pathsep+env.get('PATH','');env['VSLANG']='1033'
 start=time.monotonic()
 result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
 (OUT/row['stdout']).write_bytes(result.stdout);(OUT/row['stderr']).write_bytes(result.stderr)
 rows[-1].update(exit=result.returncode,seconds=time.monotonic()-start);write('commands.json',rows)
 print(stem,result.returncode,flush=True)
 if result.returncode:print(result.stdout.decode(errors='replace')[-5000:]+result.stderr.decode(errors='replace')[-5000:],flush=True)
 return result.returncode
def compile_one(source):
 stem,command=command_for(source);before=identity(ROOT/source)
 code=run(stem+'-compile',command)
 receipt=dict(source=before,source_unchanged=identity(ROOT/source)==before,command=command,exit=code)
 if code==0:receipt['object']=identity(OUT/(stem+'.obj'))
 write(stem+'-identity.json',receipt)
 return code if code else (0 if receipt['source_unchanged'] else 1)
def prepare():
 old={r['relative']:r for r in read(BASE/'final-source-identities.json')}
 changed=[dict(source=s,before_sha256=row['sha256'],current=identity(ROOT/s))
  for s,row in old.items() if identity(ROOT/s)['sha256']!=row['sha256']]
 write('baseline.json',dict(base=identity(BASE/'matched-link-base.json'),objects=read(BASE/'matched-link-base.json')['objects'],
  source_identities=identity(BASE/'final-source-identities.json'),changed=changed,
  no_sdk_kernel_or_shader_build=True))
 print('baseline99objects; current source/header changes',len(changed))
def matched_base():
 baseline=read(BASE/'matched-link-base.json');selected=dict(baseline['selected_sources'])
 compiled={r['relative']:r['sha256'] for r in read(BASE/'final-source-identities.json')}
 for receipt in OUT.glob('*-identity.json'):
  row=read(receipt)
  if row.get('exit')!=0 or not row.get('source_unchanged') or 'object' not in row:continue
  source=source_key(row['source']['path']);assert identity(row['source']['path'])==row['source'],source
  assert identity(row['object']['path'])==row['object']
  selected[source]=row['object']['path'];compiled[source]=row['source']['sha256']
 for receipt in sorted((ARCH/'native-pending-pages/vulkan-leaf').glob('*-identity.json')):
  row=read(receipt);source=source_key(row['source'])
  assert identity(ROOT/source)['sha256']==row['source_sha256'],source
  assert identity(row['object'])['sha256']==row['object_sha256']
  selected[source]=row['object'];compiled[source]=row['source_sha256']
 for source in selected:assert identity(ROOT/source)['sha256']==compiled[source],source+' needs current owner'
 canonical={path:source for source,path in baseline['selected_sources'].items()}
 objects=[]
 for old in baseline['objects']:
  source=canonical.get(old['path'])
  if source:
   if not source.startswith('tests/'):objects.append(selected[source])
  else:
   assert identity(old['path'])==old;objects.append(old['path'])
 objects.extend(path for source,path in selected.items() if not source.startswith('tests/'))
 objects=list(dict.fromkeys(objects));libs=[x for x in baseline['command'] if x.lower().endswith('.lib')]
 flags=[x for x in baseline['command'][1:] if not x.lower().endswith(('.obj','.lib'))
        and not x.upper().startswith(('/OUT:','/MAP:'))]
 command=[baseline['command'][0],*flags,*objects,*libs]
 write('matched-link-base.json',dict(command=command,selected_sources=selected,
  compiled_source_sha256=compiled,objects=[identity(x) for x in objects],
  baseline=identity(BASE/'matched-link-base.json'),no_old_mixed_runtime=True))
 return command,selected
def link(which):
 base,selected=matched_base()
 if which=='pending':sources=['tests/compute_batch/pending_paged_receiver_native_consumer.cc'];libs=[]
 elif which=='empty':sources=['tests/graph_batch/native_paged_joint_consumer.cc'];libs=[]
 elif which=='controls':
  sources=['tests/graph/region_provider_test.cc','tests/compute_batch/paged_arena_test.cc']
  libs=[ROOT/'.scratch/build-compute-v2-dev/lib/gtest_main.lib',ROOT/'.scratch/build-compute-v2-dev/lib/gtest.lib']
 else:raise SystemExit('pending/empty/controls')
 command=[base[0],'/OUT:'+str(OUT/(which+'.exe')),'/MAP:'+str(OUT/(which+'.map')),
  *[selected[s] for s in sources],*base[1:],*map(str,libs)]
 code=run(which+'-link',command)
 if code==0:write(which+'-image-identities.json',[identity(OUT/(which+x)) for x in ['.exe','.map']])
 return code
def execute(which):
 command=[OUT/(which+'.exe')]
 if which=='empty':command+=['empty']
 elif which=='controls':command+=['--gtest_color=no',
  '--gtest_filter=PagedArena.TrueEmptyAttentionFrameRetainsCapacityWithoutPagePermissions:GraphRouteBoundary.ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort',
  '--gtest_output=json:'+str(OUT/'controls-results.json')]
 elif which!='pending':raise SystemExit('pending/empty/controls')
 return run(which+'-run',command,60)
if __name__=='__main__':
 if sys.argv[1:2]==['prepare']:prepare()
 elif sys.argv[1:2]==['compile']:
  for source in sys.argv[2:]:
   code=compile_one(source)
   if code:raise SystemExit(code)
 elif sys.argv[1:2]==['link']:
  for which in sys.argv[2:]:
   code=link(which)
   if code:raise SystemExit(code)
 elif sys.argv[1:2]==['run']:
  for which in sys.argv[2:]:
   code=execute(which)
   if code:raise SystemExit(code)
 else:raise SystemExit('prepare or explicit compile <canonical sources>; linking waits for final native protocol')
