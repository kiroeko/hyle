#pragma once

#include "hyle/graph/batch.h"
#include "hyle/graph/detail/region_access.h"
#include "hyle/graph/region_provider.h"
#include "hyle/compute/detail/dependent_completion.h"
#include "hyle/mem/std_allocator.h"

#include <utility>
#include <vector>

namespace hyle::graph::batch::detail {
// Cold capability of one exact selected prepared implementation. These ports
// describe Q/K/V (or Q/compact-cache), excluding its owned hidden metadata.
// The physical input indices are the original region boundary port indices.
inline constexpr compute::ProviderExtensionId kNativePagedRegionExtensionId{
    0x48594c454e415450ULL, 0x414745445245474eULL, 2};
struct NativePagedRegionFacts final {
  NodeId node;
  const compute::NativePagedBatchProgram *program = nullptr;
  std::span<const ValueId> inputs;
  std::span<const std::uint32_t> input_ports;
  compute::BatchLayoutVersion layout;
};
// One original typed CopyOutcomeSource, cold-created by the actual selected
// implementation. The shared batch payload owns it; it owns no Invocation,
// executor, result slot or second DependentCompletion.
struct NativePendingSourceVTable final {
  void (*destroy)(void *) noexcept = nullptr;
  Status (*reusable)(void *) noexcept = nullptr;
};
struct NativePendingSourceOwner final {
  const NativePendingSourceVTable *table = nullptr;
  void *state = nullptr;
  const void *identity = nullptr;
  NativePendingSourceOwner() noexcept = default;
  NativePendingSourceOwner(const NativePendingSourceOwner &) = delete;
  NativePendingSourceOwner &operator=(const NativePendingSourceOwner &) = delete;
  NativePendingSourceOwner(NativePendingSourceOwner &&other) noexcept { *this = std::move(other); }
  NativePendingSourceOwner &operator=(NativePendingSourceOwner &&other) noexcept {
    if (this != &other) {
      reset(); table = std::exchange(other.table, nullptr);
      state = std::exchange(other.state, nullptr);
      identity = std::exchange(other.identity, nullptr);
    }
    return *this;
  }
  ~NativePendingSourceOwner() { reset(); }
  void reset() noexcept {
    if (state) table->destroy(state);
    state = nullptr; table = nullptr; identity = nullptr;
  }
};
struct NativePendingSourceFactory final {
  const NativePendingSourceVTable *table = nullptr;
  const void *identity = nullptr;
  Result<void *> (*create)(void *prepared, std::size_t capacity,
      mem::AllocatorRef, compute::ResourceBudget) noexcept = nullptr;
};
struct NativePagedRegionVTable final {
  Result<NativePagedRegionFacts> (*inspect)(void *prepared,
                                           void *invocation) noexcept = nullptr;
  Status (*prepare)(void *prepared, void *invocation,
                    compute::BatchLayoutVersion) noexcept = nullptr;
  Status (*validate_frame)(void *prepared, void *invocation, ValueId,
                           const compute::PagedArenaRead &) noexcept = nullptr;
  // Only called after every real reader and the original Graph binding have
  // accepted the exact frame. It cannot fail or manufacture ready permission.
  void (*commit_frame)(void *prepared, void *invocation, ValueId,
                        compute::PagedArenaRead) noexcept = nullptr;
  Status (*reset)(void *prepared, void *invocation) noexcept = nullptr;
  compute::NativePagedBatchReport (*report)(void *prepared,
                                           void *invocation) noexcept = nullptr;
  Status (*validate_pending_frame)(void *prepared, void *invocation, ValueId,
      const compute::PagedArenaPendingRead &, const NativePendingSourceOwner &) noexcept = nullptr;
  void (*commit_pending_frame)(void *prepared, void *invocation, ValueId,
      compute::PagedArenaPendingRead, const NativePendingSourceOwner &) noexcept = nullptr;
  NativePendingSourceFactory (*pending_source)(void *prepared) noexcept = nullptr;
};
// Borrowed original slot references, retained only by its existing resource
// payload for cold reset. Destruction never dereferences these pointers.
struct NativePagedRegionRef final {
  const NativePagedRegionVTable *table = nullptr;
  const ProviderRegionPreparedVTable *implementation = nullptr;
  void *prepared = nullptr;
  void *invocation = nullptr;
  std::uint32_t step = 0;
  ExecutionLaneId lane;
  NodeId node;
  const compute::NativePagedBatchProgram *program = nullptr;
  std::span<const ValueId> inputs;
  std::span<const std::uint32_t> input_ports;
};
using NativePagedRegions = std::vector<NativePagedRegionRef,
    mem::StdAllocator<NativePagedRegionRef>>;
using NodeLayouts = std::vector<NodeLayout, mem::StdAllocator<NodeLayout>>;
using ProjectedReaders = std::vector<graph::detail::ProjectedReader,
    mem::StdAllocator<graph::detail::ProjectedReader>>;
struct PendingPageInput final {
  ValueId value;
  compute::PagedArenaPendingRead frame;
  std::vector<ExecutionLaneId, mem::StdAllocator<ExecutionLaneId>> lanes;
};
struct NativePendingAccess final {
  void *source = nullptr;
  std::span<const PendingPageInput> inputs;
  std::span<const NativePagedRegionRef> regions;
};

Status collect_native_paged_regions(Invocation &, NativePagedRegions &) noexcept;
Status split_native_paged_layouts(std::span<const NativePagedRegionRef>,
    std::span<const NodeLayout>, NodeLayouts &shared) noexcept;
Status prepare_native_paged_regions(std::span<const NativePagedRegionRef>,
    std::span<const NodeLayout>) noexcept;
Status reset_native_paged_regions(std::span<const NativePagedRegionRef>) noexcept;
Result<std::uint64_t> native_paged_read_capacity(
    std::span<const NativePagedRegionRef>) noexcept;
Status native_paged_frame(std::span<const NativePagedRegionRef>, ValueId,
    const compute::PagedArenaRead &, ProjectedReaders &) noexcept;
Status native_paged_frame(std::span<const NativePagedRegionRef>, ValueId,
    const compute::PagedArenaPendingRead &, const NativePendingSourceOwner &,
    ProjectedReaders &) noexcept;
void commit_native_paged_frame(std::span<const NativePagedRegionRef>, ValueId,
    compute::PagedArenaRead) noexcept;
void commit_native_paged_frame(std::span<const NativePagedRegionRef>, ValueId,
    compute::PagedArenaPendingRead, const NativePendingSourceOwner &) noexcept;
// Borrowed only during the typed public entry. No erased Update is registered
// here: its concrete source module validates/takes/restores the original type.
HYLE_GRAPH_BATCH_API Result<NativePendingAccess> native_pending_access(
    Invocation &, const NativePendingSourceVTable *) noexcept;
// A returned Completion consumes sources; an unexpected result leaves that
// reference with the typed caller for source restoration and release.
HYLE_GRAPH_BATCH_API Result<compute::Completion> submit_native_pending(
    Invocation &, std::span<const QueueBinding>, const NativePendingSourceVTable *,
    compute::detail::OutcomeSources) noexcept;
HYLE_GRAPH_BATCH_API Result<void *> native_pending_recovery(
    Invocation &, const NativePendingSourceVTable *) noexcept;
HYLE_GRAPH_BATCH_API void finish_native_pending_recovery(Invocation &) noexcept;
Result<compute::NativePagedBatchReport> native_paged_report(
    Invocation &, NodeId) noexcept;
} // namespace hyle::graph::batch::detail
