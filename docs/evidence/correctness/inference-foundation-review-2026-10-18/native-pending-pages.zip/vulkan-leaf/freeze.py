from pathlib import Path
import hashlib
import json
import shutil
import difflib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
PRODUCTS = [
    'src/graph_route_vulkan/native_paged_region.h',
    'src/graph_route_vulkan/native_paged_region.cc',
    'src/graph_route_vulkan/native_paged_pending.h',
    'src/graph_route_vulkan/native_paged_pending.cc',
    'src/graph_route_vulkan/CMakeLists.txt',
    'src/graph_route_vulkan/execution_source.cc',
    'include/hyle/graph/vulkan.h',
    'src/compute_route_vulkan/vulkan_memory.cc',
    'src/compute_route_vulkan/vulkan_memory_internal.h',
    'include/hyle/compute/detail/materialized_native_controller.h',
]
HEADERS = [
    'src/graph_batch/native_paged_regions.h',
    'include/hyle/graph/detail/region_access.h',
    'include/hyle/graph/region_provider.h',
    'include/hyle/graph/batch.h',
    'include/hyle/compute/operation.h',
]

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

if __name__ == '__main__':
    for rel in PRODUCTS:
        dest = OUT / 'candidate' / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / rel, dest)
    for name, paths in [('source-identities.json', PRODUCTS),
                        ('shared-header-identities.json', HEADERS)]:
        (OUT / name).write_text(json.dumps([identity(ROOT / rel) for rel in paths], indent=2) + '\n')
    objects = [identity(OUT / (name + '.obj')) for name in ['page-region', 'page-pending', 'memory']]
    for stem in ['src--graph_route_vulkan--execution_source', 'source-aba-diagnostic']:
        path = OUT.parent / 'windows' / (stem + '.obj')
        if path.exists(): objects.append(identity(path))
    (OUT / 'retained-objects.json').write_text(json.dumps(objects, indent=2) + '\n')
    changes = []
    for rel in PRODUCTS:
        before = OUT / 'before' / rel
        old = before.read_text(encoding='utf-8').splitlines(keepends=True) if before.exists() else []
        new = (ROOT / rel).read_text(encoding='utf-8').splitlines(keepends=True)
        changes.extend(difflib.unified_diff(old, new,
            fromfile='before/' + rel if before.exists() else '/dev/null', tofile='candidate/' + rel))
    (OUT / 'source.diff').write_text(''.join(changes), encoding='utf-8')
