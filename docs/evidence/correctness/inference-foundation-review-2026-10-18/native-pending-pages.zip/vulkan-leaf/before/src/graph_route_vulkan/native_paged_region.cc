#include "native_paged_region.h"
#include "native_region.h"
#include "vulkan_source.h"

#include <algorithm>
#include <array>
#include <mutex>
#include <new>

#include "../compute_route_vulkan/vulkan_composition_access.h"
#include "../compute_route_vulkan/vulkan_file_stream_access.h"
#include "../compute_route_vulkan/vulkan_memory_internal.h"
#include "../compute_route_vulkan/vulkan_program_internal.h"
#include "../graph_batch/native_paged_regions.h"
#include "hyle/compute/detail/materialized_native_controller.h"
#include "hyle/compute/detail/vulkan_batch_access.h"

namespace hyle::graph::vulkan::detail {
namespace {
namespace cv = compute::vulkan;
namespace vn = cv::detail;
namespace cd = compute::detail;
namespace bd = graph::batch::detail;
constexpr std::uint64_t kPagedRoute = 2;
const unsigned tensor_type = 0, observed_endpoint = 0;
constexpr compute::ProviderRuntimeProperties runtime_properties{
    .mode = compute::ProviderRuntimeMode::kDelegated,
    .workspace_owner = compute::ProviderWorkspaceOwner::kProvider,
    .replay_class = compute::ProviderReplayClass::kManaged};

struct Recipe final {
  compute::NativePagedBatchProgram program;
  compute::BatchLayoutVersion layout;
  batch::NativePagedOptions options;
};
Result<Recipe> recipe(const compute::Operation &operation) noexcept {
  if (const auto d = operation.custom_as<batch::NativePagedAttention>())
    return Recipe{d->program, d->layout, d->options};
  if (const auto d = operation.custom_as<batch::NativePagedMlaAttention>())
    return Recipe{d->program, d->layout, d->options};
  return std::unexpected(Status::Unimplemented("not native paged attention"));
}
Status qualify(const Recipe &value) noexcept {
  if (!value.program.valid() || !value.program.schema().owns(value.layout))
    return Status::InvalidArgument("native Vulkan page recipe/layout identity differs");
  const auto capacity = value.program.schema().capacity();
  if (!vn::PagedBatchAccess::cache_domain(capacity) || capacity.page_size != 16)
    return Status::Unimplemented("native Vulkan page dtype/encoding/geometry is unsupported");
  if (!value.layout.facts().query_rows && !value.layout.facts().page_refs)
    return Status::Unimplemented("empty native page projection has no selected page permissions");
  return compute::validate_batch_attention_layout(value.layout,
      value.program.causal(), value.program.window_left());
}
Result<Recipe> qualify(const RegionCompileRequest &request) noexcept {
  if (!request.graph || request.graph->dimension_count() || request.route != kPagedRoute ||
      request.nodes.size() != 1 || request.outputs.size() > 1 ||
      request.has_unknown_effects || !request.effect_accesses.empty())
    return std::unexpected(Status::Unimplemented("native Vulkan page needs one fixed pure typed node"));
  HYLE_ASSIGN_OR_RETURN(auto operation, request.graph->operation(request.nodes[0]));
  HYLE_ASSIGN_OR_RETURN(auto value, recipe(operation));
  HYLE_RETURN_IF_ERROR(qualify(value));
  return value;
}

// These are actual native owners and borrowed resource refs. They only adapt
// the original controller's static traits; they are not public Context/Queue
// shells and carry no second execution state.
struct Preparation final {
  std::shared_ptr<vn::Runtime> runtime;
  cv::InvocationAllocation allocation;
};
struct Resource final {
  std::shared_ptr<vn::Runtime> runtime;
  mem::MemoryResourceRef resource;
  bool valid() const noexcept { return runtime && resource.valid(); }
  mem::MemoryResourceRef ref() const noexcept { return resource; }
};
struct PreparedProgram final {
  cv::Program native;
  cv::InvocationAllocation allocation;
  bool valid() const noexcept { return native.valid(); }
};
struct Traits final {
  using Context = Preparation; using Memory = Resource;
  using Program = PreparedProgram; using Invocation = cv::Invocation;
  using CopyInvocation = cv::CopyBatchInvocation; using View = cv::Tensor;
  using Submission = compute::OwnedResult<cv::Results>;
  using CopyAccess = vn::CopyStreamAccess;
  static auto invocation(const Program &p, mem::AllocatorRef a) {
    return p.native.create_invocation(a, p.allocation);
  }
  static Result<Program> prepare_program(const Context &c,
      const compute::NativePagedBatchProgram &p, compute::BatchLayoutVersion layout,
      const compute::WorkloadContext &workload) {
    HYLE_ASSIGN_OR_RETURN(auto native, vn::PagedBatchAccess::prepare_program(
        c.runtime, p, std::move(layout), workload));
    return Program{std::move(native), c.allocation};
  }
  static auto copy_program(const Context &c, std::span<const compute::CopyResourceSpec> specs,
      compute::CopyBatchOptions options) {
    return vn::CopyStreamAccess::prepare_program(c.runtime, specs, std::move(options));
  }
  static auto copy_invocation(const cv::CopyBatchProgram &p) { return cv::CopyBatchInvocation::create(p); }
  static auto binding(const Memory &m, compute::ReadLease lease,
      compute::TensorDesc description, compute::LeaseImportOptions options) {
    return vn::MemoryAccess::lease_tensor(m.runtime, m.resource, std::move(lease), description, options);
  }
  static auto submit(Invocation &i, compute::LeaseUseBatch uses) {
    return vn::PagedBatchAccess::submit(i, std::move(uses));
  }
  static auto wait_native(Invocation &i) { return vn::PagedBatchAccess::wait_native(i); }
  static auto reuse_gate(Invocation &i) { return vn::PagedBatchAccess::reuse_gate(i); }
  static auto release_inputs(Invocation &i) { return vn::PagedBatchAccess::release_inputs(i); }
  static auto update_layout(Invocation &i, const compute::BatchLayoutVersion &layout) {
    return vn::PagedBatchAccess::update_layout(i, layout);
  }
};
using Controller = cd::MaterializedNativeState<Traits, cd::PagedMetadataPolicy>;
struct Artifact final {
  Recipe recipe;
  NodeId node;
  std::array<ValueId, 3> inputs{};
  std::array<std::uint32_t, 3> ports{};
  std::size_t count = 0, public_outputs = 0;
  Resource device, staging;
  Preparation preparation;
  PreparedProgram program;
  compute::WorkloadContext workload;
  mem::MemoryResourceRef output_resource;
};
struct Slot final {
  Slot(mem::AllocatorRef a, Preparation p) : allocator(a), preparation(std::move(p)), controller(a) {}
  mem::AllocatorRef allocator;
  Preparation preparation; // Outlives the controller's original cold borrow.
  Controller controller;
  std::array<compute::PagedArenaRead, 2> frames;
  cv::Tensor output;
  mem::Buffer backing;
  cd::ResultStorageOwner result;
  bool sealed = false, needs_seal = false;
};

Status frame(void *prepared, void *invocation, ValueId input,
    const compute::PagedArenaRead &value) noexcept {
  const auto &a = *static_cast<Artifact *>(prepared);
  const auto &s = *static_cast<Slot *>(invocation);
  const auto &layout = s.controller.version.layout();
  if (!s.controller.prepared || s.controller.bound || !value.valid() || value.layout() != layout ||
      !a.recipe.program.schema().owns(value.layout()))
    return Status::InvalidArgument("native Vulkan page frame needs its unbound prepared layout");
  bool selected = false;
  for (std::size_t port = 1; port < a.count; ++port) if (a.inputs[port] == input) {
    selected = true;
    if (s.frames[port-1].valid()) return Status::FailedPrecondition("native page input needs reset before rebind");
    const auto capacity = a.recipe.program.schema().capacity();
    HYLE_RETURN_IF_ERROR(cd::PagedArenaAccess::validate_storage(value,
        port == 1 ? capacity.key_storage : capacity.value_storage));
    HYLE_ASSIGN_OR_RETURN(auto tensor, cd::PagedArenaAccess::tensor(value));
    if (tensor.description() != a.recipe.program.descriptions()[port])
      return Status::InvalidArgument("native Vulkan page frame physical description differs");
    HYLE_RETURN_IF_ERROR(vn::MemoryAccess::validate_resource(s.preparation.runtime,
        tensor.storage().resource()));
    if (tensor.storage().resource().properties().has(mem::MemoryProperty::kHostAccessible))
      return Status::InvalidArgument("native page capacity requires actual device storage");
  }
  return selected ? Status::Ok() : Status::InvalidArgument("input is not this native page reader");
}
Status refresh_output(Artifact &a, Slot &s) noexcept {
  HYLE_ASSIGN_OR_RETURN(s.output, vn::CompositionAccess::output(s.controller.native, 0));
  if (a.public_outputs) {
    HYLE_ASSIGN_OR_RETURN(s.backing, vn::MemoryAccess::export_storage(
        s.preparation.runtime, a.output_resource, s.output, s.allocator));
  }
  return Status::Ok();
}
Status prepare(void *prepared, void *invocation, compute::BatchLayoutVersion layout) noexcept {
  auto &a = *static_cast<Artifact *>(prepared); auto &s = *static_cast<Slot *>(invocation);
  if (!a.recipe.program.schema().owns(layout) ||
      layout.facts().query_rows != a.recipe.layout.facts().query_rows)
    return Status::InvalidArgument("native page schema/active output shape changed");
  s.result.reset();
  HYLE_RETURN_IF_ERROR(s.controller.prepare(std::move(layout)));
  s.frames = {};
  if (!s.controller.report.reused_native_plan) { s.sealed = false; s.output = {}; s.backing = {}; }
  if (!s.output.valid()) {
    HYLE_RETURN_IF_ERROR(refresh_output(a, s));
    // Establish the original controller's own cold bridge baseline before
    // its first input bind. The common final seal includes downstream refs.
    HYLE_RETURN_IF_ERROR(vn::CompositionAccess::seal(s.controller.native));
    s.sealed = true;
  }
  return Status::Ok();
}
Status reset(void *, void *invocation) noexcept {
  auto &s = *static_cast<Slot *>(invocation);
  s.result.reset();
  if (s.controller.native.valid()) HYLE_RETURN_IF_ERROR(vn::PagedBatchAccess::release_inputs(s.controller.native));
  s.frames = {}; s.controller.keys = {}; s.controller.values = {}; s.controller.reads = {};
  s.controller.prepared = false; s.controller.bound = false; s.needs_seal = false;
  return Status::Ok();
}
const bd::NativePagedRegionVTable page_table{
    [](void *prepared, void *invocation) noexcept -> Result<bd::NativePagedRegionFacts> {
      const auto &a = *static_cast<Artifact *>(prepared); const auto &s = *static_cast<Slot *>(invocation);
      return bd::NativePagedRegionFacts{a.node, &a.recipe.program,
          std::span(a.inputs).first(a.count), std::span(a.ports).first(a.count), s.controller.version.layout()};
    }, &prepare, &frame,
    [](void *prepared, void *invocation, ValueId input, compute::PagedArenaRead value) noexcept {
      const auto &a = *static_cast<Artifact *>(prepared); auto &s = *static_cast<Slot *>(invocation);
      for (std::size_t port = 1; port < a.count; ++port)
        if (a.inputs[port] == input) s.frames[port-1] = value;
    }, &reset,
    [](void *, void *invocation) noexcept { return static_cast<Slot *>(invocation)->controller.report; }};

Status create_slot(void *prepared, mem::AllocatorRef allocator, mem::BufferView, void **out) noexcept {
  *out = nullptr; auto &a = *static_cast<Artifact *>(prepared);
  auto *s = allocator.construct<Slot>(allocator, a.preparation);
  if (!s) return Status::ResourceExhausted("native Vulkan page slot metadata");
  *out = s;
  const compute::NativePagedInvocationOptions options{
      .max_metadata_backing_bytes = a.recipe.options.max_metadata_backing_bytes,
      .allocator = allocator, .resource_budget = a.preparation.allocation.resource_budget};
  HYLE_RETURN_IF_ERROR(s->controller.initialize(s->preparation, a.program, a.recipe.program,
      a.device, a.staging, options, a.workload));
  HYLE_ASSIGN_OR_RETURN(s->controller.version, a.recipe.program.version(a.recipe.layout));
  return Status::Ok();
}
Status bind(void *prepared, void *invocation, std::span<const RegionValue> inputs,
    std::span<const compute::TensorView> outputs) noexcept {
  auto &a = *static_cast<Artifact *>(prepared); auto &s = *static_cast<Slot *>(invocation);
  auto &c = s.controller;
  if (!c.prepared || outputs.size() != a.public_outputs)
    return Status::FailedPrecondition("native page layout must be prepared before replay bindings");
  s.result.reset();
  HYLE_RETURN_IF_ERROR(vn::PagedBatchAccess::reuse_gate(c.native));
  const auto descriptions = a.recipe.program.descriptions();
  std::array<cv::Tensor, 4> native;
  for (std::size_t port = 0; port < a.count; ++port) {
    if (a.ports[port] >= inputs.size()) return Status::InvalidArgument("native page boundary port differs");
    const auto &input = inputs[a.ports[port]];
    if (input.description != descriptions[port]) return Status::InvalidArgument("native page physical input description differs");
    if (!port) {
      if (input.lease) {
        HYLE_ASSIGN_OR_RETURN(native[0], vn::MemoryAccess::lease_tensor(s.preparation.runtime,
            input.tensor.storage().resource(), *input.lease, descriptions[0], c.import));
        c.reads[0] = *input.lease;
      } else {
        HYLE_ASSIGN_OR_RETURN(native[0], vn::MemoryAccess::tensor_view(
            s.preparation.runtime, input.tensor, s.allocator));
        c.reads[0] = {};
      }
    } else {
      const auto &permission = s.frames[port-1];
      if (!permission.valid() || permission.layout() != c.version.layout())
        return Status::FailedPrecondition("native page input has no exact ready frame");
      HYLE_ASSIGN_OR_RETURN(auto actual, cd::PagedArenaAccess::tensor(permission));
      const auto x = actual.storage(), y = input.tensor.storage();
      if (x.resource() != y.resource() || x.native_handle() != y.native_handle() ||
          x.offset() != y.offset() || x.size() != y.size())
        return Status::InvalidArgument("native page input differs from its exact bound frame");
      HYLE_ASSIGN_OR_RETURN(native[port], vn::MemoryAccess::paged_tensor(
          s.preparation.runtime, actual.storage().resource(), permission, c.import));
    }
  }
  HYLE_ASSIGN_OR_RETURN(native[a.count], vn::MemoryAccess::lease_tensor(
      s.preparation.runtime, a.device.resource, c.reads[3], descriptions[a.count], c.import));
  HYLE_RETURN_IF_ERROR(c.native.bind(std::span(native).first(a.count+1)));
  c.keys = s.frames[0]; c.values = a.count == 3 ? s.frames[1] : compute::PagedArenaRead{};
  c.native_bank = c.prepared_bank; c.bound = true; s.needs_seal = true;
  return Status::Ok();
}
Status seal(void *, void *invocation) noexcept {
  auto &s = *static_cast<Slot *>(invocation);
  if (s.sealed && !s.needs_seal) return vn::PagedBatchAccess::reuse_gate(s.controller.native);
  HYLE_RETURN_IF_ERROR(s.sealed ? vn::PagedBatchAccess::reseal_composition(s.controller.native)
                               : vn::CompositionAccess::seal(s.controller.native));
  s.sealed = true; s.needs_seal = false; return Status::Ok();
}
Result<RegionValue> value(void *prepared, void *invocation, std::size_t port) noexcept {
  const auto &a = *static_cast<Artifact *>(prepared); auto &s = *static_cast<Slot *>(invocation);
  if (port >= a.public_outputs || !s.output.valid() || !s.backing.valid())
    return std::unexpected(Status::FailedPrecondition("native page output is not cold prepared"));
  HYLE_ASSIGN_OR_RETURN(auto tensor, compute::ConstTensorView::create(s.output.description(), s.backing.view()));
  return RegionValue{s.output.description(), tensor, &tensor_type, &s.output};
}
Result<compute::ReadLease> lease(void *prepared, void *invocation, std::size_t port) noexcept {
  const auto &a = *static_cast<Artifact *>(prepared); auto &s = *static_cast<Slot *>(invocation);
  if (!s.result || port >= a.public_outputs)
    return std::unexpected(Status::FailedPrecondition("native page has no successful output owner"));
  const auto &run = vn::Access::invocation_state(s.controller.native)->run;
  {
    std::lock_guard lock(s.preparation.runtime->mutex);
    if (run->pending || run->retiring || !run->terminal.ok() ||
        !run->observation_error.ok() || !run->submission_failure.ok())
      return std::unexpected(Status::FailedPrecondition("native page output has not retired successfully"));
  }
  HYLE_ASSIGN_OR_RETURN(auto storage, vn::MemoryAccess::export_storage(
      s.preparation.runtime, a.output_resource, s.output, s.allocator));
  return compute::ReadLease::adopt(std::move(storage), {.allocator = s.allocator});
}
cd::CompletionEndpoint endpoint(void *, void *invocation) noexcept {
  const auto &s = *static_cast<Slot *>(invocation);
  const auto &run = *vn::Access::invocation_state(s.controller.native)->run;
  if (run.async || run.needs_drain || std::ranges::any_of(run.stages, [](const auto &stage) { return bool(stage.iree); }))
    return {&observed_endpoint, &run};
  return region_ordered_endpoint(s.preparation.runtime);
}
bool imports(void *, void *invocation, cd::CompletionEndpoint source) noexcept {
  const auto &s = *static_cast<Slot *>(invocation);
  const auto own = endpoint(nullptr, invocation);
  return own.authority != &observed_endpoint && imports_region_ordered_endpoint(s.preparation.runtime, source);
}
Result<compute::Completion> submit(void *, void *invocation,
    std::span<const cd::CompletionDependency> dependencies,
    std::span<const compute::ConstTensorView>, std::span<const compute::TensorView>) noexcept {
  auto &s = *static_cast<Slot *>(invocation);
  for (const auto dependency : dependencies) HYLE_RETURN_IF_ERROR(vn::qualify_copy_dependency(s.preparation.runtime, dependency));
  s.result.reset();
  HYLE_ASSIGN_OR_RETURN(auto accepted, s.controller.replay_ready());
  auto transfer = cd::ResultAccess::take_storage(std::move(accepted));
  s.result = std::move(transfer.owner); return std::move(transfer.completion);
}
const ProviderRegionPreparedVTable prepared_table{
    .destroy_prepared = [](void *p, mem::AllocatorRef a) noexcept { a.destroy(static_cast<Artifact *>(p)); },
    .alias_support = [](void *, std::size_t, std::size_t) noexcept { return compute::AliasSupport{}; },
    .create_invocation = &create_slot,
    .destroy_invocation = [](void *p, mem::AllocatorRef a) noexcept { a.destroy(static_cast<Slot *>(p)); },
    .delegated_submit = &submit, .endpoint = &endpoint, .can_import_endpoint = &imports,
    .output_contract = [](void *, std::size_t) noexcept { return RegionOutputContract{
        .kind = RegionOutputKind::kBoundGenerated, .projection = RegionOutputProjection::kTensorView}; },
    .output_value = &value, .prepare_bindings = &bind, .seal_bindings = &seal, .output_lease = &lease,
    .query_extension = [](void *, compute::ProviderExtensionId id) noexcept -> const void * {
      return id == bd::kNativePagedRegionExtensionId ? &page_table : nullptr;
    }};
} // namespace

bool native_paged_operation(const compute::Operation &operation) noexcept {
  return operation.custom_as<batch::NativePagedAttention>() || operation.custom_as<batch::NativePagedMlaAttention>();
}
Status propose_native_paged(void *, const RegionDiscoveryRequest &request,
    std::span<const std::uint8_t> needed, RegionProposalWriter &writer) noexcept {
  for (std::size_t i = 0; i < request.graph.node_count(); ++i) {
    if (!needed[i] || (!request.allowed_nodes.empty() && !request.allowed_nodes[i])) continue;
    HYLE_ASSIGN_OR_RETURN(auto node, request.graph.node_id(i));
    HYLE_ASSIGN_OR_RETURN(auto operation, request.graph.operation(node));
    if (!native_paged_operation(operation)) continue;
    HYLE_ASSIGN_OR_RETURN(auto value, recipe(operation));
    const auto admitted = qualify(value);
    if (!admitted.ok()) { if (admitted.IsUnimplemented()) continue; return admitted; }
    const std::array nodes{node};
    HYLE_ASSIGN_OR_RETURN(auto added, writer.try_add({.nodes = nodes, .route = kPagedRoute,
        .replay_class = compute::ProviderReplayClass::kManaged,
        .implementation = compute::ProviderImplementationId{0x5041474544564bULL}, .preference = 100}));
    if (!added) break;
  }
  return Status::Ok();
}
Status native_paged_resources(void *context, const RegionCompileRequest &request,
    std::span<RegionInputRequirement> inputs, std::span<RegionOutputRequirement> outputs,
    RegionResourceProposal *proposal) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto value, qualify(request));
  (void)value;
  if (inputs.size() != request.inputs.size() || outputs.size() != request.outputs.size())
    return Status::InvalidArgument("native page resource boundary differs");
  const auto &runtime = static_cast<SourceContext *>(context)->runtime;
  const cd::ResourceBindingRequirement requirement{
      .required_properties = mem::MemoryProperty::kDeviceAccessible,
      .forbidden_properties = mem::MemoryProperty::kHostAccessible, .minimum_alignment = 1,
      .exact_domain = {runtime->device.get(), static_cast<std::uintptr_t>(cv::MemoryKind::kDevice)},
      .requires_exact_domain = true};
  std::ranges::fill(inputs, RegionInputRequirement{.resource = requirement});
  std::ranges::fill(outputs, RegionOutputRequirement{.resource = requirement,
      .value = {.kind = RegionOutputKind::kBoundGenerated, .projection = RegionOutputProjection::kTensorView}});
  *proposal = {.runtime = runtime_properties, .workspace_resource = requirement};
  return Status::Ok();
}
compute::ProviderPrepareOutcome compile_native_paged(void *context,
    const RegionCompileRequest &request, mem::AllocatorRef allocator,
    ProviderRegionPrepared *out) noexcept {
  using Outcome = compute::ProviderPrepareOutcome;
  *out = {};
  auto selected = qualify(request);
  if (!selected) return selected.error().IsUnimplemented() ? Outcome::unsupported(selected.error()) : Outcome::error(selected.error());
  if (request.input_resources.size() != request.inputs.size() ||
      request.output_resources.size() != request.outputs.size())
    return Outcome::error(Status::InvalidArgument("native page physical resource arity differs"));
  auto *a = allocator.construct<Artifact>();
  if (!a) return Outcome::error(Status::ResourceExhausted("native page artifact metadata"));
  *out = {.vtable = &prepared_table, .state = a};
  const auto build = [&]() noexcept -> Status {
    a->recipe = std::move(*selected); a->node = request.nodes[0]; a->workload = request.workload;
    a->count = a->recipe.program.schema().mla_layout() == compute::MlaCacheLayout::kNone ? 3 : 2;
    a->public_outputs = request.outputs.size();
    const auto &runtime = static_cast<SourceContext *>(context)->runtime;
    a->preparation.runtime = runtime; a->preparation.allocation.resource_budget = request.resource_budget;
    const auto consider = [&](mem::MemoryResourceRef resource) {
      if (!vn::MemoryAccess::validate_resource(runtime, resource).ok()) return;
      if (resource.properties().has(mem::MemoryProperty::kHostAccessible)) {
        if (!a->staging.valid()) a->staging = {runtime, resource};
      } else if (!a->device.valid()) a->device = {runtime, resource};
    };
    consider(request.workspace_resource);
    for (const auto &domain : request.available_storage_domains) consider(domain.resource);
    if (!a->device.valid() || !a->staging.valid())
      return Status::Unimplemented("native page metadata requires actual Vulkan device and staging domains");
    a->preparation.allocation.device = a->device.resource;
    a->preparation.allocation.staging = a->staging.resource;
    a->output_resource = a->public_outputs ? request.output_resources[0] : a->device.resource;
    for (std::size_t port = 0; port < a->count; ++port) {
      HYLE_ASSIGN_OR_RETURN(a->inputs[port], request.graph->node_input(a->node, port));
      if (port && a->inputs[port].kind() != ValueKind::kInput)
        return Status::InvalidArgument("native page capacity must have an exact external frame");
      const auto found = std::ranges::find(request.inputs, a->inputs[port]);
      if (found == request.inputs.end()) return Status::InvalidArgument("native page physical input is missing");
      a->ports[port] = static_cast<std::uint32_t>(found-request.inputs.begin());
      HYLE_RETURN_IF_ERROR(vn::MemoryAccess::validate_resource(runtime,
          request.input_resources[a->ports[port]]));
    }
    HYLE_ASSIGN_OR_RETURN(a->program, Traits::prepare_program(a->preparation,
        a->recipe.program, a->recipe.layout, a->workload));
    out->properties = {.persistent_bytes = std::nullopt, .runtime = runtime_properties,
                       .invocation_private_bytes = std::nullopt};
    return Status::Ok();
  };
  const auto status = build();
  if (!status.ok()) return status.IsUnimplemented() ? Outcome::unsupported(status) : Outcome::error(status);
  return Outcome::prepared();
}
} // namespace hyle::graph::vulkan::detail
