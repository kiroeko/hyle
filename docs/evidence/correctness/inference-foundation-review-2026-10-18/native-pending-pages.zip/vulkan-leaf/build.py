from pathlib import Path
import hashlib
import importlib.util
import json
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = OUT.parents[1]
spec = importlib.util.spec_from_file_location('runner', ARCH / 'region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
SOURCES = {
    'page-region': 'src/graph_route_vulkan/native_paged_region.cc',
    'page-pending': 'src/graph_route_vulkan/native_paged_pending.cc',
    'memory': 'src/compute_route_vulkan/vulkan_memory.cc',
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def compile_one(name):
    rows = json.loads((ARCH / 'vulkan-constant-readback/commands.json').read_text())
    original = next(row['command'] for row in reversed(rows)
                    if row['tag'] == 'source-staging-compile' and row['exit'] == 0)
    source = ROOT / SOURCES[name]
    obj = OUT / (name + '.obj')
    command = [str(source) if str(value).endswith('.cc') else
               '/Fo' + str(obj) if str(value).lower().startswith('/fo') else value
               for value in original]
    before = sha(source)
    b.run(name + '-compile', command, timeout=60)
    assert before == sha(source)
    (OUT / (name + '-identity.json')).write_text(json.dumps({
        'source': str(source), 'source_sha256': before,
        'object': str(obj), 'object_bytes': obj.stat().st_size,
        'object_sha256': sha(obj),
        'flags_source': str(ARCH / 'vulkan-constant-readback/commands.json'),
        'flags_tag': 'source-staging-compile',
    }, indent=2) + '\n')

if __name__ == '__main__':
    for name in sys.argv[1:]:
        compile_one(name)
