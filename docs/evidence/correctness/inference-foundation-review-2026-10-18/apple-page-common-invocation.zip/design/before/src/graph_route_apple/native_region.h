#pragma once

#include "hyle/graph/region_provider.h"
#include "../compute_route_apple/apple_carrier.h"

namespace hyle::graph::apple::detail {
const RegionProviderVTable *native_region_provider() noexcept;
compute::detail::CompletionEndpoint region_ordered_endpoint(
    const std::shared_ptr<compute::apple::detail::Runtime> &) noexcept;
bool imports_region_ordered_endpoint(
    const std::shared_ptr<compute::apple::detail::Runtime> &,
    compute::detail::CompletionEndpoint) noexcept;
Result<compute::apple::detail::InputSource> native_output_source(
    const RegionOutputReference &, const std::shared_ptr<compute::apple::detail::Runtime> &,
    const compute::TensorDesc &) noexcept;
}
