Apple ordinary Graph page implementation — source freeze

The ordinary `graph::batch::PagedAttention/PagedMlaAttention` descriptor selects
one actual Apple native region. Cold compile derives the existing expert
NativePagedBatchProgram and original Apple Program under the Graph allocator
and ResourceBudget. The selected slot contains the original
MaterializedNativeState<PagedMetadataPolicy>, metadata upload and page-use
controls. No new Graph Invocation, executor, result system, Queue or payload
output allocation was introduced.

The slot binds ready frames through the existing NativePagedRegionVTable.
Exact selected physical reader proofs and the original common page bindings
still authorize the arena. Empty permission is advertised only after the
actual prepared original Invocation proves Q0/ref0 and one Q-only native port;
cache views are not imported into that program. The native frame still
identifies its real arena capacity. Ready strict replay keeps the original
cold layout/frame bindings and admits fresh real uses on every run.

Q may be a ready raw/owned input or an original same-Runtime InputSource.
The original Runtime FIFO Job resolves a referenced Q only after that source's
successful submitted epoch, with the existing native read pins. Outputs are
DeferredGenerated/NativeOnly; success-only observation accesses the real
Array, and a nonempty readonly byte projection exports its actual owner.
There is no preallocated shadow output. Cross-Runtime late references are
rejected; ordinary CPU destinations use the existing original FIFO copy.

Normal Apple and page slots share only a small private selected-output
capability. It returns the real InputSource and original alias authority.
The alias walker carries RegionOutputReference, validates the actual selected
callback, deduplicates visited references, and never casts a page slot as a
normal slot. Normal identity/views preserve exact original subleases; a
mathematically fresh page output supplies its real owner only for an actually
overlapping ready buffer. Raw/constant aliases remain borrowed; partial owned
overlaps do not gain permission. No new owner->Array->owner feedback chain is
created. Source copy cache reuse now compares the actual retained InputSource
inside the original CopyRecording, so native slot replacement cannot reuse a
stale producer merely because its enclosing RegionOutputReference is stable.

Precision: the pinned MLX code is 1f8e74e3f12f31365464a6867c6579f0e9b29d85,
manifest eb9287cab72e04b233ff301a7256953f498a9e80815e8d36078db8e750800525,
patched SDPA 201303cdb8152a414913bf01d543e2226c2ca7c3bf7b295639d7e7ef83e80b9c.
The prior exact UTF-8 in-memory replay evidence is in
../../native-page-semantics/native-design/mlx-replay.json. Plain F16/BF16
vector two-pass stores partial payload in Q dtype, while normalization state
is F32. For nq<=8, apart from the actual full high-dimensional kernel path,
two-pass is selected when architecture ends in d/s and current request
NK>=1024, or GQA and NK>=4096. allow_bf16_partials=false declines exactly
that native domain at proposal/compile and every owned-layout prepare.
The declared-type permission allows the original branch; Q8 internally
promotes compute/partials to F32 and is not declined for this reason. Window
does not remove the original two-pass selection. The original low-partial
kernel still needs a later precision implementation; this is not a completed
all-domain functionality claim.

The follow-up native-analysis/source.diff moves those native geometry and
dispatch facts into the existing PagedBatchAccess::analyze_paged. Direct native
prepare uses the same analysis without restricting its expert partial policy;
Graph only compares the returned facts against its mathematical permission.

Other limits/costs remain explicit: pending Apple frames/typed native Update
handoff are not implemented in this ready vertical. Original native metadata
staging/two mirrors and cold upload waits remain. Changed KV layout in an
unchanged Q topology still uses the existing native eager MLX graph builder;
this adapter does not add JIT/repacking or claim that cost was removed.
Native MLX allocation sizes remain unknown where the existing original owner
cannot report them, and therefore retain the existing budget admission rules.

Validation in this subtask: source review and `git diff --check` pass. No
compilation, numerical run, GPU allocation or SDK/kernel build was performed
by this agent. The root agent will use its matched Air host closure. Required
actual consumer directions include CPU->Page->CPU, normal Apple->Page->normal
Apple (late Q and late page output), exact empty footprint, original old-output
and replay gates. These are requirements for the next run, not claimed passes.

Affected host owners: graph_route_apple/native_region.cc,
native_paged_region.cc, execution_source.cc. The module CMake adds the new
source. Compute Runtime/Memory/Copy seams belong to the root's separate stage.
