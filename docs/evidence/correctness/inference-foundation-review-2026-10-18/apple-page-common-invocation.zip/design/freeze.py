from pathlib import Path
import difflib
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
paths = [
    'src/graph_route_apple/CMakeLists.txt',
    'src/graph_route_apple/execution_source.cc',
    'src/graph_route_apple/native_region.cc',
    'src/graph_route_apple/native_region.h',
    'src/graph_route_apple/native_output.h',
    'src/graph_route_apple/native_paged_region.h',
    'src/graph_route_apple/native_paged_region.cc',
]
rows = []
diff = []
for path in paths:
    data = (ROOT / path).read_bytes()
    target = OUT / 'candidate' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / path, target)
    before = OUT / 'before' / path
    old = before.read_bytes() if before.exists() else b''
    rows.append(dict(path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
        before_sha256=hashlib.sha256(old).hexdigest() if before.exists() else None,
        changed=old != data))
    diff.extend(difflib.unified_diff(old.decode('utf-8').splitlines(True),
        data.decode('utf-8').splitlines(True), fromfile='before/'+path, tofile='candidate/'+path))
(OUT / 'source-identities.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
(OUT / 'source.diff').write_text(''.join(diff), encoding='utf-8')
print(json.dumps(rows, indent=2))
