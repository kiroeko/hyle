from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
EVIDENCE=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18'

def identity(path):
    path=Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

before=OUT/'compute/before'
diff=[];changed=[]
for path in sorted(before.rglob('*')):
    if not path.is_file():continue
    relative=path.relative_to(before);source=ROOT/relative
    candidate=OUT/'compute/candidate'/relative
    candidate.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,candidate)
    changed.append(identity(source))
    diff+=difflib.unified_diff(path.read_text(encoding='utf-8').splitlines(True),
        source.read_text(encoding='utf-8').splitlines(True),
        'before/'+relative.as_posix(),'candidate/'+relative.as_posix())
(OUT/'compute/source.diff').write_text(''.join(diff),encoding='utf-8')
for relative in ['src/graph_route_apple/native_region.cc','src/graph_route_apple/native_region.h',
        'src/graph_route_apple/native_paged_region.cc','src/graph_route_apple/native_paged_region.h',
        'src/graph_route_apple/native_output.h','src/graph_route_apple/execution_source.cc',
        'src/graph_route_apple/CMakeLists.txt','tests/graph_route_apple/paged_region_consumer.cc',
        'tests/graph_route_apple/CMakeLists.txt']:
    candidate=OUT/'final-candidate'/relative;candidate.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/relative,candidate);changed.append(identity(ROOT/relative))
write('final-product-identities.json',changed)

air=json.loads((OUT/'air-results/cleanup.json').read_text())
windows=[];retain=[]
mla=OUT.parent/'legacy-native-retirement/public-mla'
for folder in ['windows','windows-current-owners']:
    path=mla/folder;plan=json.loads((path/'cleanup.json').read_text())
    frozen={row['path']:row for row in json.loads((path/'final-identities.json').read_text())}
    for name in plan['files']:
        actual=identity(name);assert actual==frozen[name],name
        windows.append(actual)
    retain += [identity(p) for p in plan['retained_stage_objects']]
write('cleanup.json',dict(windows=windows,windows_retain=retain,mac=air))
write('summary.json',dict(status='passed_bounded_real_consumer_and_related_regressions',
    machine='MacBook Air Mac16,12',fresh_compiled_owners=97,
    final_native_test_command=122,final_page_consumer_command=124,
    negative_control_command=112,negative_control_exit=1,
    negative_control_error='Apple copy has no new producer submission',
    layouts=[18,2,0],capacity_query_rows=24,slots=2,
    placements=['CPU','CPU/ApplePage/CPU','Apple ordinary math/Page/ordinary math'],
    dtype='F16 query/output, physical Q8_0 KV; D64 H8/KV2',
    maximum_absolute_error=6.48183836e-5,unchanged_absolute_budget=.002,
    related_tests=11,old_joint_linked=False,
    limits=['Apple pending frames not implemented','Plain native two-pass F32 partials still missing',
        'Changed KV may use existing eager MLX builder','No throughput or full model rerun',
        'CUDA only prior host compile; no new CUDA numerical evidence',
        'Old Apple/Vulkan drivers still used by remaining consumers']))

archive=EVIDENCE/'apple-page-common-invocation.zip'
assert not archive.exists(),archive
entries={}
for folder in ['compute','design','final-candidate','air-results']:
    for path in (OUT/folder).rglob('*'):
        if path.is_file() and path.suffix in {'.h','.cc','.mm','.py','.json','.txt','.log','.diff','.md'}:
            entries[path.relative_to(OUT).as_posix()]=path
for name in ['air.py','air_remote.py','host-sources.json','freeze.py','cleanup.json',
             'summary.json','final-product-identities.json']:
    entries[name]=OUT/name
entries['cleanup-test.ps1']=ROOT/'test.ps1'
entries['windows-mla-first-image-identities.json']=mla/'windows/final-identities.json'
entries['windows-mla-current-image-identities.json']=mla/'windows-current-owners/final-identities.json'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,path in sorted(entries.items()):output.write(path,name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert set(check.namelist())==set(entries)
    for name,path in entries.items():assert check.read(name)==path.read_bytes(),name
receipt=identity(archive);receipt['path']=archive.relative_to(ROOT).as_posix();receipt['entries']=len(entries)
write('archive-receipt.json',receipt)
target=EVIDENCE/'native-mla-common-graph.zip'
assert not target.exists(),target
shutil.copyfile(mla/'windows-current-owners/source-results.zip',target)
write('mla-archive-receipt.json',identity(target))
print(json.dumps(receipt))
print('cleanup bytes',sum(r['bytes'] for r in windows)+sum(r['bytes'] for r in air['files']))
