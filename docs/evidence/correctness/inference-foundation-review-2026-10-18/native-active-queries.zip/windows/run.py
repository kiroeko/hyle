"""Current active-Q Hyle overlays over the exact pending/empty native closure."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
BASE=ARCH/'native-pending-pages/windows'
READY=ARCH/'native-ready-pages/windows'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def recipes():
 rows={r['source']:r['command'] for r in read(READY/'compile-plan.json')}
 for path in [ARCH/'native-ready-pages/schema/commands.json',
              ARCH/'native-paged-region/vulkan/commands.json',
              ARCH/'native-pending-pages/vulkan-leaf/commands.json',BASE/'commands.json']:
  for r in read(path):
   if r.get('exit')!=0 or not r.get('tag','').endswith('-compile'):continue
   source=next((x for x in r['command'] if x.lower().endswith('.cc')),None)
   if source:rows[Path(source).relative_to(ROOT).as_posix()]=r['command']
 main=rows['tests/graph_batch/native_paged_joint_consumer.cc']
 for source in [r['path'] for r in read(OUT/'before-identities.json') if r['path'].endswith('.cc')]:
  if source not in rows:rows[source]=main
 rows['tests/graph_batch/native_paged_joint_risks.cc']=main
 # The CPU encoded consumer includes the public CUDA header even without its
 # CUDA execution branch. Reuse the actual cached SDK include flags only.
 cuda_commands=read(ARCH/'weight-inputs/cuda/commands.json')
 cuda_includes=list(dict.fromkeys(x for r in cuda_commands for x in r['command']
  if x.startswith('/external:I') and 'NVIDIA GPU Computing Toolkit' in x))
 source='tests/compute_batch/encoded_page_common_consumer.cc'
 rows[source]=[*rows[source],*cuda_includes]
 # Exact current gtest flags from the previous successful schema target.
 rows['tests/compute_batch/native_paged_metadata_test.cc']=rows['tests/graph_batch/native_paged_node_test.cc']
 return rows
def command_for(source):
 stem=source.replace('/','--').removesuffix('.cc')
 original=recipes()[source]
 command=[x for x in original if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]
 return stem,[*command,str(ROOT/source),'/Fo'+str(OUT/(stem+'.obj'))]
def run(tag,command,timeout=60):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';command=list(map(str,command))
 row=dict(tag=tag,command=command,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
 rows.append(row);write('commands.json',rows)
 compiler=recipes()['src/graph/executable.cc'][0]
 env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler,'CMAKE_C_COMPILER':compiler})
 torch=next(str(Path(x).parent) for x in read(BASE/'matched-link-base.json')['command'] if x.lower().endswith('torch_cpu.lib'))
 env['PATH']=torch+os.pathsep+env.get('PATH','');env['VSLANG']='1033'
 start=time.monotonic();result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout,
  creationflags=subprocess.CREATE_NO_WINDOW)
 (OUT/row['stdout']).write_bytes(result.stdout);(OUT/row['stderr']).write_bytes(result.stderr)
 rows[-1].update(exit=result.returncode,seconds=time.monotonic()-start);write('commands.json',rows)
 print(stem,result.returncode,flush=True)
 if result.returncode:print(result.stdout.decode(errors='replace')[-5000:]+result.stderr.decode(errors='replace')[-5000:],flush=True)
 return result.returncode
def compile_one(source):
 stem,command=command_for(source);before=identity(ROOT/source)
 headers=[identity(ROOT/p) for p in ['include/hyle/compute/batch_paged_native.h','include/hyle/graph/batch.h',
  'include/hyle/compute/detail/materialized_native_controller.h','src/compute_route_vulkan/vulkan_memory_internal.h']]
 code=run(stem+'-compile',command)
 receipt=dict(source=before,headers=headers,source_unchanged=identity(ROOT/source)==before and
  all(identity(h['path'])==h for h in headers),command=command,exit=code)
 if code==0:receipt['object']=identity(OUT/(stem+'.obj'))
 write(stem+'-identity.json',receipt)
 return code if code else (0 if receipt['source_unchanged'] else 1)
def matched_base():
 baseline=read(BASE/'matched-link-base.json');selected=dict(baseline['selected_sources'])
 compiled=dict(baseline['compiled_source_sha256'])
 for receipt in OUT.glob('*-identity.json'):
  r=read(receipt)
  if r.get('exit')!=0 or not r.get('source_unchanged') or 'object' not in r:continue
  source=Path(r['source']['path']).relative_to(ROOT).as_posix()
  assert identity(r['source']['path'])==r['source'] and identity(r['object']['path'])==r['object'],source
  selected[source]=r['object']['path'];compiled[source]=r['source']['sha256']
 for source in selected:assert identity(ROOT/source)['sha256']==compiled[source],source+' needs fresh owner'
 canonical={p:s for s,p in baseline['selected_sources'].items()};objects=[]
 for old in baseline['objects']:
  source=canonical.get(old['path'])
  if source:
   if not source.startswith('tests/'):objects.append(selected[source])
  else:assert identity(old['path'])==old;objects.append(old['path'])
 objects.extend(p for s,p in selected.items() if not s.startswith('tests/'))
 objects=list(dict.fromkeys(objects));libs=[x for x in baseline['command'] if x.lower().endswith('.lib')]
 flags=[x for x in baseline['command'][1:] if not x.lower().endswith(('.obj','.lib'))
  and not x.upper().startswith(('/OUT:','/MAP:'))]
 command=[baseline['command'][0],*flags,*objects,*libs]
 write('matched-link-base.json',dict(command=command,selected_sources=selected,compiled_source_sha256=compiled,
  objects=[identity(x) for x in objects],baseline=identity(BASE/'matched-link-base.json')))
 return command,selected
def link(which):
 base,selected=matched_base()
 if which=='ready':sources=['tests/graph_batch/native_paged_joint_consumer.cc'];libs=[]
 elif which=='pending':sources=['tests/compute_batch/pending_paged_receiver_native_consumer.cc'];libs=[]
 elif which=='schema':
  sources=['tests/compute_batch/native_paged_metadata_test.cc','tests/graph_batch/native_paged_node_test.cc']
  libs=[ROOT/'.scratch/build-compute-v2-dev/lib/gtest_main.lib',ROOT/'.scratch/build-compute-v2-dev/lib/gtest.lib']
 else:raise SystemExit('ready/pending/schema')
 command=[base[0],'/OUT:'+str(OUT/(which+'.exe')),'/MAP:'+str(OUT/(which+'.map')),
  *[selected[s] for s in sources],*base[1:],*map(str,libs)]
 code=run(which+'-link',command)
 if code==0:
  data=(OUT/(which+'.map')).read_text(encoding='utf-8',errors='replace')
  hits=[x for x in data.splitlines() if 'descriptions@NativePagedBatchProgram' in x]
  write(which+'-removed-api-check.json',dict(forbidden='NativePagedBatchProgram::descriptions',matches=hits))
  assert not hits,'An old archive supplied the deleted versionless NativePaged API'
  write(which+'-image-identities.json',[identity(OUT/(which+x)) for x in ['.exe','.map']])
 return code
def execute(which):
 if which=='ready':command=[OUT/'ready.exe','64','1']
 elif which=='empty':command=[OUT/'ready.exe','empty']
 elif which=='pending':command=[OUT/'pending.exe']
 elif which=='schema':command=[OUT/'schema.exe','--gtest_color=no',
  '--gtest_filter=NativePagedMetadata.InputDescriptionsUseActiveQueriesWithoutAllocatingOrShrinkingCache:NativePagedMetadata.FullNoncausalQGreaterThanKvAndIndependentEncodedRoots:NativePagedGraphNode.TruthfulPhysicalRootsAndActivePackedOutput:NativePagedGraphNode.EmptyQueryKeepsTrueCacheCapacityAndRejectsForgedRoots:NativePagedGraphNode.GraphOwnsRecipeAndLayoutAfterBuilderInputsDie',
  '--gtest_output=json:'+str(OUT/'schema-results.json')]
 else:raise SystemExit('ready/empty/pending/schema')
 return run(which+'-run',command)
if __name__=='__main__':
 if sys.argv[1:2]==['compile']:
  for source in sys.argv[2:]:
   code=compile_one(source)
   if code:raise SystemExit(code)
 elif sys.argv[1:2]==['link']:
  for which in sys.argv[2:]:
   code=link(which)
   if code:raise SystemExit(code)
 elif sys.argv[1:2]==['run']:
  for which in sys.argv[2:]:
   code=execute(which)
   if code:raise SystemExit(code)
 else:raise SystemExit('compile <sources> / link <images> / run <selected existing cases>')
