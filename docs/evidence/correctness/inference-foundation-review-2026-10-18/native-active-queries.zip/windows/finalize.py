"""Freeze this narrow active-query verification's metadata, never delete images."""
from pathlib import Path
import difflib, json, shutil
import run

OUT,ROOT=run.OUT,run.ROOT
def write(name,value):run.write(name,value)
def relative(row):
 row=dict(row);path=Path(row['path'])
 row['path']=path.relative_to(ROOT).as_posix() if path.is_absolute() else path.as_posix()
 return row

commands=run.read(OUT/'commands.json')
assert all(commands[n-1]['exit']==0 for n in [16,22,23,24])
assert [r['exit'] for r in commands if r['tag'].endswith('-run')]==[0,1,0,0,0]
schema=run.read(OUT/'schema-results.json')
assert schema['tests']==5 and schema['failures']==0
for name in ['ready','pending','schema']:
 assert not run.read(OUT/(name+'-removed-api-check.json'))['matches']

base,_=run.matched_base()
matched=run.read(OUT/'matched-link-base.json')
source_paths=set(matched['selected_sources'])
owned=run.read(OUT/'before-identities.json')
source_paths.update(r['path'] for r in owned)
source_paths.update(['include/hyle/compute/batch_paged_native.h','include/hyle/graph/batch.h',
 'include/hyle/compute/detail/materialized_native_controller.h',
 'src/compute_route_vulkan/vulkan_memory_internal.h','include/hyle/compute/operation.h'])
for component,manifest in [('core','candidate-identities.json'),('backend','source-identities.json')]:
 for row in run.read(OUT.parent/component/manifest):
  path=Path(row['path']);path=path if path.is_absolute() else ROOT/path
  assert run.identity(path)['sha256']==row['sha256'],str(path)
  source_paths.add(path.relative_to(ROOT).as_posix())
write('final-source-identities.json',[relative(run.identity(ROOT/p)) for p in sorted(source_paths)])

diffs=[]
for row in owned:
 source=row['path'];before=OUT/'before'/source
 assert run.identity(before)['sha256']==row['sha256']
 candidate=OUT/'candidate'/source;candidate.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(ROOT/source,candidate)
 diffs.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
  candidate.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+source,tofile='candidate/'+source))
(OUT/'source.diff').write_text(''.join(diffs),encoding='utf-8')

receipts=[]
for path in sorted(OUT.glob('*-identity.json')):
 row=run.read(path)
 if row.get('exit')!=0 or 'object' not in row:continue
 assert row['source_unchanged'] and run.identity(row['source']['path'])==row['source']
 assert run.identity(row['object']['path'])==row['object']
 assert all(run.identity(h['path'])==h for h in row['headers'])
 receipts.append(row)
write('retained-objects.json',dict(stage=[r['object'] for r in receipts],
 actual_link_objects=matched['objects'],
 baseline=run.identity(run.BASE/'matched-link-base.json')))
cleanup=[run.identity(OUT/(stem+suffix)) for stem in ['schema','ready','pending']
 for suffix in ['.exe','.map','.exp','.lib']]
write('cleanup-candidates.json',dict(files=cleanup,total_bytes=sum(r['bytes'] for r in cleanup),
 retain_count=len(receipts),note='Candidate list only. Parent test.ps1 owns deletion.'))

write('summary.json',dict(status='actual_active_query_paths_passed',
 schema=dict(command=16,tests=5,failures=0,results='schema-results.json'),
 ready=dict(command=22,log='022-ready-run.stderr.log',exit=0,episodes=64,depth=64,
  query_type='F16',causal=True,active_query_rows=18,capacity_query_rows=24,
  copies=[dict(source=0,destination=2,bytes=18432),dict(source=2,destination=1,bytes=18432)],
  device_upload_count=1,total_query_copy_bytes=36864,
  preserved='Original two slots/three layouts, FP64 attention tolerance0.002, old GraphOutput gates, same-bindings strict replay with no cold reprepare.'),
 pending=dict(command=23,log='023-pending-run.stderr.log',exit=0,steps=64,depth=256,
  query_type='F16',heads=8,kv_heads=2,requests=2,active_query_rows=[2,18],
  device_upload_bytes=[8192,73728],total_query_copy_bytes=[16384,147456],
  copy_path='Host0 -> staging2 -> device1; every edge has the exact active Q description/bytes and exactly one enters Device.',
  graph_slots_per_shape=2,page_nodes_per_graph=2,dirty_bytes=196608,
  preserved='Original CopyBatchUpdate shared by both page nodes; exact equality of both published outputs plus original independent FP64 oracle/tolerance0.002; generation/history/untouched page/control recovery/old results unchanged.'),
 empty=dict(command=24,log='024-empty-run.stderr.log',exit=0,query_rows=0,page_refs=0,
  graph='Original CPU Abs/Cast -> native Q-only page -> CPU Cast/Neg; true empty ArenaRead frames, both page writers stay held; output descriptor0; original GraphOutput reuse gate.',
  direct='Same CLI additionally uploads a real4-byte F16 carrier, imports a ReadLease and subviews it to0 bytes, then original Direct prepare/bind/submit/wait with Q0, no page frame, output0 and old result gate.'),
 compile_scope=dict(product_tus=8,consumer_tus=9,gtest_tus=2,local_objects=len(receipts),
  matched_link_object_count=len(matched['objects']),provider_contract=16,region_spi=26,
  native_page_schema='v3',native_page_input_api='input_count + input_description(layout,port)',
  source_copy_aba_fix='0d95bc44b7812bb20a655d39c4abf2b12aec0c0f7151211dac9ed5026e167f2a',
  compilation='All19 unique Windows Hyle/test TUs fresh /W4 /WX. Vendor/native shader/kernel/SDK binaries unchanged; exact identities retained via matched-link-base.',
  compile_only='Commands025-027,030-033: Direct Vulkan page, MLA, encoded native, encoded common CPU, Vulkan outcome/receiver probes and joint risk fixture instantiation. Not run.'),
 failures=[dict(command='driver-errors.json',cause='Scratch recipe lookup lacked leaf entry; fixed lookup, no compiler/product failure.'),
  dict(command=17,cause='New fixture assumed one total Q copy. Actual legal route uses host->staging->device. Replaced with per-edge active desc/bytes checks and exactly one device entrance; no product change or weakened oracle.'),
  dict(command=28,cause='Compile-only CPU encoded consumer unconditionally includes public CUDA header; inherited fixture recipe lacked cached SDK include flags. Added cached includes only.'),
  dict(command=29,cause='Previously present migration RETURN macro inside void TEST body; changed only to ASSERT on the same ExecutionSource Result. Final030 WX passed.')],
 limits=['No new numerical dtype/depth/causal matrix or benchmarks.',
  'Apple source probes migrated; not compiled or run here. Backend separate AppleBatch/AppleMaterialized two-TU Air syntax2/2 only, no numerical claim.',
  'Two Vulkan reference benchmark sources migrated by backend but not built/run in this Windows scope.',
  'No throughput/performance comparison. Report bytes are actual planned copy geometry, including staging cost.'],
 artifacts=dict(commands='commands.json',sources='final-source-identities.json',
  objects='retained-objects.json',diff='source.diff',cleanup='cleanup-candidates.json',
  deleted_getter_checks=['schema-removed-api-check.json','ready-removed-api-check.json','pending-removed-api-check.json'])))
print(json.dumps(dict(status='frozen',local_objects=len(receipts),matched_objects=len(matched['objects']),
 cleanup_count=len(cleanup),cleanup_bytes=sum(r['bytes'] for r in cleanup))))
