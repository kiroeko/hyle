"""Freeze the focused active-Q sources and logs, retaining object caches."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
TARGET = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-active-queries.zip'


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


sources = {
    'include/hyle/compute/batch_paged_native.h',
    'include/hyle/compute/detail/materialized_native_controller.h',
    'include/hyle/graph/batch.h',
    'src/compute_batch/batch_paged_native.cc',
    'src/compute_route_apple/apple_batch.cc',
    'src/compute_route_vulkan/vulkan_batch.cc',
    'src/compute_route_vulkan/vulkan_memory.cc',
    'src/compute_route_vulkan/vulkan_memory_internal.h',
    'src/graph_batch/native_paged_node.cc',
    'src/graph_batch/native_paged_nodes.h',
    'src/graph_native_shared/compile.h',
    'src/graph_route_vulkan/native_paged_region.cc',
    'src/graph_route_vulkan/native_region.cc',
    'tests/compute_batch/native_paged_metadata_test.cc',
    'tests/compute_batch/native_paged_vulkan_consumer.cc',
    'tests/compute_batch/public_mla_native_consumer.cc',
    'tests/compute_batch/encoded_page_native_consumer.cc',
    'tests/compute_batch/encoded_page_common_consumer.cc',
    'tests/compute_batch/pending_outcome_owner_apple_probe.cc',
    'tests/compute_batch/pending_outcome_owner_vulkan_probe.cc',
    'tests/compute_batch/pending_attention_receiver_probe.cc',
    'tests/compute_batch/pending_attention_receiver_vulkan_probe.cc',
    'tests/compute_batch/pending_paged_receiver_native_consumer.cc',
    'tests/graph_batch/native_paged_node_test.cc',
    'tests/graph_batch/native_paged_joint_risk_fixture.h',
    'tests/graph_batch/native_paged_joint_consumer.cc',
    'bench/inference_resident_sdpa/apple_page_reference.cc',
    'bench/inference_resident_sdpa/apple_encoded_page_reference.cc',
    'bench/inference_resident_sdpa/vulkan_page_reference.cc',
    'bench/inference_resident_sdpa/vulkan_encoded_page_reference.cc',
    'docs/architecture/compute-design.md',
    'docs/developer/current-work.md',
    'docs/user/batch-attention.md',
    'test.ps1',
}
for relative in sorted(sources):
    destination = STAGE / 'final-source' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((ROOT / relative).read_bytes())
(STAGE / 'final-source-identities.json').write_text(json.dumps([
    dict(relative=relative, **identity(ROOT / relative)) for relative in sorted(sources)
], indent=2) + '\n', encoding='utf-8')

files = [identity(path) for path in (STAGE / 'windows').iterdir()
         if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.exp', '.lib'}]
(STAGE / 'cleanup.json').write_text(json.dumps(dict(
    files=files, bytes=sum(row['bytes'] for row in files),
    retained='all objects, dependency/kernel caches, sources, failures, logs and numerical data'
), indent=2) + '\n', encoding='utf-8')

extensions = {'.py', '.ps1', '.json', '.md', '.cc', '.h', '.hpp', '.log',
              '.diff', '.patch', '.txt', '.cmake', '.csv', '.rsp', '.gz'}
entries = {path.relative_to(STAGE).as_posix(): path for path in STAGE.rglob('*')
           if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts
           and path.name not in {'archive-receipt.json', 'cleanup-result.json'}
           and path.suffix.lower() in extensions}
assert not TARGET.exists(), 'Frozen evidence must never be overwritten'
with zipfile.ZipFile(TARGET, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(entries.items()):
        archive.write(path, name)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
receipt = identity(TARGET)
receipt.update(path=TARGET.relative_to(ROOT).as_posix(), entries=len(entries))
(STAGE / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(archive=receipt, cleanup_files=len(files),
                      reclaim_bytes=sum(row['bytes'] for row in files))))
