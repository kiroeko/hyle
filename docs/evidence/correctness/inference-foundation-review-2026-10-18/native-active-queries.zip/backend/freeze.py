from pathlib import Path
import difflib
import hashlib
import json
import shutil

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
PRODUCTS = [
    'src/compute_route_apple/apple_batch.cc',
    'src/compute_route_vulkan/vulkan_batch.cc',
    'src/graph_route_vulkan/native_paged_region.cc',
    'src/compute_route_vulkan/vulkan_memory.cc',
    'src/compute_route_vulkan/vulkan_memory_internal.h',
    'src/graph_route_vulkan/native_region.cc',
    'bench/inference_resident_sdpa/apple_page_reference.cc',
    'bench/inference_resident_sdpa/vulkan_page_reference.cc',
    'bench/inference_resident_sdpa/apple_encoded_page_reference.cc',
    'bench/inference_resident_sdpa/vulkan_encoded_page_reference.cc',
]
HEADERS = [
    'include/hyle/compute/batch_paged_native.h',
    'include/hyle/compute/detail/materialized_native_controller.h',
    'include/hyle/graph/batch.h',
]

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

if __name__ == '__main__':
    changes = []
    for rel in PRODUCTS:
        source = ROOT / rel
        dest = OUT / 'candidate' / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        before = OUT / 'before' / rel
        changes.extend(difflib.unified_diff(
            before.read_text(encoding='utf-8').splitlines(keepends=True),
            source.read_text(encoding='utf-8').splitlines(keepends=True),
            fromfile='before/' + rel, tofile='candidate/' + rel))
    (OUT / 'source.diff').write_text(''.join(changes), encoding='utf-8')
    for name, paths in [('source-identities.json', PRODUCTS), ('shared-header-identities.json', HEADERS)]:
        (OUT / name).write_text(json.dumps([identity(ROOT / rel) for rel in paths], indent=2) + '\n')
