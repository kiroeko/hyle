from pathlib import Path
import base64
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-native-active-queries'
SEEDS = ['src/compute_route_apple/apple_batch.cc',
         'src/compute_route_apple/apple_materialized_invocation.cc']

def ssh(code, payload=None, timeout=60):
    encoded = base64.b64encode(code.encode()).decode()
    command = ['ssh', 'kiro@172.22.10.198',
               'python3 -c "import base64;exec(base64.b64decode(\'' + encoded + '\'))"']
    return subprocess.run(command, input=payload, capture_output=True, timeout=timeout)

def stage():
    files = {'air_syntax_remote.py': OUT / 'air_syntax_remote.py'}
    seen = set()
    def add(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:
            return
        seen.add(path)
        files[path.relative_to(ROOT).as_posix()] = path
        for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',
                               path.read_text(encoding='utf-8-sig'), re.M):
            for candidate in [path.parent / name, ROOT / name, ROOT / 'include' / name,
                              ROOT / 'src/compute' / name, ROOT / 'src/compute_route_apple' / name]:
                if candidate.is_file():
                    add(candidate)
                    break
    for source in SEEDS:
        add(ROOT / source)
    rows = [dict(path=name, bytes=path.stat().st_size,
                 sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            for name, path in sorted(files.items())]
    (OUT / 'air-staged-sources.json').write_text(json.dumps(rows, indent=2) + '\n')
    files['staged-sources.json'] = OUT / 'air-staged-sources.json'
    data = io.BytesIO()
    with tarfile.open(fileobj=data, mode='w:gz') as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name)
    (OUT / 'air-minimal-sources.tar.gz').write_bytes(data.getvalue())
    code = ('from pathlib import Path;import io,sys,tarfile;r=Path(' + repr(REMOTE) + ');'
            'assert not r.exists();r.mkdir();a=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");'
            'assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in a.getmembers());'
            'a.extractall(r);print(r)')
    result = ssh(code, data.getvalue())
    (OUT / 'air-stage.stdout.log').write_bytes(result.stdout)
    (OUT / 'air-stage.stderr.log').write_bytes(result.stderr)
    if result.returncode: raise SystemExit(result.stderr.decode(errors='replace'))
    print(result.stdout.decode().strip(), len(rows), 'files', len(data.getvalue()), 'bytes', flush=True)

def run():
    command = ['ssh', 'kiro@172.22.10.198', 'python3 ' + REMOTE + '/air_syntax_remote.py']
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=150)
    (OUT / 'air-run.stdout.log').write_bytes(result.stdout)
    (OUT / 'air-run.stderr.log').write_bytes(result.stderr)
    (OUT / 'air-run-command.json').write_text(json.dumps(dict(command=command, exit=result.returncode,
        seconds=time.monotonic()-started), indent=2) + '\n')
    print(result.stdout.decode(errors='replace'), end='')
    print(result.stderr.decode(errors='replace'), end='', file=sys.stderr)
    if result.returncode: raise SystemExit(result.returncode)

def collect():
    code = ('from pathlib import Path;import io,sys,tarfile;r=Path(' + repr(REMOTE) + ');b=io.BytesIO();'
            'a=tarfile.open(fileobj=b,mode="w:gz");'
            '[a.add(p,arcname=p.name) for p in sorted(r.iterdir()) if p.is_file() and p.suffix in {".log",".json",".txt"}];'
            'a.close();sys.stdout.buffer.write(b.getvalue())')
    result = ssh(code)
    if result.returncode: raise SystemExit(result.stderr.decode(errors='replace'))
    (OUT / 'air-evidence.tar.gz').write_bytes(result.stdout)
    target = OUT / 'air-results'
    target.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(result.stdout), mode='r:gz') as archive:
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
                   for m in archive.getmembers())
        archive.extractall(target)

if __name__ == '__main__':
    for action in sys.argv[1:]:
        {'stage': stage, 'run': run, 'collect': collect}[action]()
