from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BUILD = ROOT.parent / 'a-cpu-apple/selected-graph/source-build'
DATABASE = json.loads((BUILD / 'compile_commands.json').read_text())
SOURCES = ['src/compute_route_apple/apple_batch.cc',
           'src/compute_route_apple/apple_materialized_invocation.cc']

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def main():
    assert subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True).strip() == 'Mac16,12'
    (ROOT / 'machine.txt').write_text(subprocess.check_output(
        ['sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'], text=True)
        + subprocess.check_output(['xcrun', 'clang++', '--version'], text=True))
    for row in json.loads((ROOT / 'staged-sources.json').read_text()):
        assert identity(ROOT / row['path'])['sha256'] == row['sha256'], row['path']
    records = []
    for number, source in enumerate(SOURCES, 1):
        rows = [row for row in DATABASE if row['file'].endswith('/' + source)]
        assert len(rows) == 1, source
        original = rows[0].get('arguments') or shlex.split(rows[0]['command'])
        command = []
        skip = False
        for arg in original:
            if skip:
                skip = False
                continue
            if arg in {'-c', '-o', '-MF', '-MT', '-MQ'}:
                skip = True
                continue
            if arg in {'-MD', '-MMD', '-MP'}:
                continue
            command.append(arg)
        command[1:1] = ['-I' + str(ROOT / 'include'), '-I' + str(ROOT),
            '-I' + str(ROOT / 'src/compute_route_apple'), '-DHYLE_STATIC', '-Werror']
        command.extend(['-fsyntax-only', str(ROOT / source)])
        stem = f'{number:02d}-' + Path(source).stem + '-syntax'
        started = time.monotonic()
        with (ROOT / (stem + '.stdout.log')).open('wb') as out, (ROOT / (stem + '.stderr.log')).open('wb') as err:
            process = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, timeout=60)
        records.append(dict(tag=stem, command=command, exit=process.returncode,
            seconds=time.monotonic()-started, source=identity(ROOT / source),
            flags_source=str(BUILD / 'compile_commands.json'),
            stdout=stem + '.stdout.log', stderr=stem + '.stderr.log'))
        (ROOT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
        print(stem, process.returncode, flush=True)
        if process.returncode:
            print((ROOT / (stem + '.stderr.log')).read_text(errors='replace'), flush=True)
            raise SystemExit(process.returncode)

if __name__ == '__main__':
    main()
