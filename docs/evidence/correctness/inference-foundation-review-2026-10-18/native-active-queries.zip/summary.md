# Native active queries: one actual input description

2026-10-19. Completed focused correction within the active Compute/Graph
architecture refactor; the full refactor remains incomplete.

Actual consumers showed that a capacity18 / decode2 native page interface made
CPU Abs/Cast and each Q boundary copy process18 rows, even though attention
already consumed only2. The ready consumer similarly processed24 rather than18.
The correction follows this real computation rather than adding shape state.

NativePagedBatchProgram::descriptions() is deleted, with no forwarding overload.
input_count() and the pure input_description(ownedLayout, port) query describe
actual Q rows while preserving physical KV and page-table capacity. Direct,
Graph schema, native controller and both native cold plan builders use it.
Graph schema IDs move directly from02 to03. Materialized/ragged semantics stay
unchanged. Independent native reference builders consume the same descriptions.

| Actual check | Result |
|---|---|
| Windows016 |5/5 targeted metadata/schema/owned-lifetime tests PASS, including pure query allocation controls, active/empty Q and rejection of forged roots. |
| Windows022 | Ready CPU/native/CPU D64/F16/causal,64 episodes/two slots/three layouts plus original strict replay PASS with unchanged FP64 budget. Q18 rather than capacity24: each actual copy edge18,432B. |
| Windows023 | Pending D256/F16/H8:2,64 steps/Q2 and Q18 variants/two slots each/two page nodes sharing one Update PASS; both outputs retain exact equality and independent .002 FP64 bounds. Each copy edge8,192B for Q2 or73,728B for Q18. |
| Windows024 | Same ready image with empty argument: actual Q0/ref0 Graph chain PASS; an additional original Direct zero-lease episode PASS using no KV frames and keeping both arena writers valid. |
| Windows source/link |12 focused initial TUs and7 related compile-only consumers/probes/fixture instantiations PASS under /W4 /WX. All three actual image maps have no removed NativePaged descriptions symbol; SDK/kernel/shader caches are reused. |
| MacBook Air Mac16,12 | apple_batch.cc and apple_materialized_invocation.cc strict syntax PASS using existing SDK and a small252,935B source/header package. No Apple link or numerical run in this batch. |

Copy accounting is by actual physical edge. The configured route is
Host0 -> Staging2 -> Device1; both edges use the active description and exact
active bytes, with one actual device-entry edge. The initial fixture assertion
mistook this two-hop path for one copy and failed017. Its failure and corrected
census are retained; this was not a product capacity regression. No numerical
tolerance changed, and no byte reduction is claimed as a measured latency gain.

Vulkan zero logical imports share an existing adequate aligned backing. When a
zero span has no legal descriptor carrier, the original resource/scope funds a
minimal private carrier; the exact zero lease is retained and Q remains zero.
The four-byte request does not claim four bytes of total driver memory or zero
allocation. Ordinary region constant/bind imports also pass their original scope.

The compile-only migration found an existing void TEST using a returning Result
macro in encoded_page_common_consumer.cc. It now uses an explicit Result plus
ASSERT_TRUE, preserving the test's behavior. Original failure029 and scratch
compile-recipe failures are retained; none required an SDK rebuild.

No standalone benchmark, BF16/new-geometry matrix, new failure injection or full
model throughput run was added. The CUDA Qwen path already uses actual-T ragged
graphs, so it is not changed by this correction; its independent numerical
acceptance and fair performance comparison remain open.

remaining-page-description-seam.txt records the concrete next architecture task:
CPU/CUDA four-port PagedAttention and native three-port NativePagedAttention
still force an engine to change its mathematical construction and metadata
contract. Shared execution and lifetime do not yet satisfy one common semantic
Graph across those routes. Legacy driver migration also remains incomplete.
