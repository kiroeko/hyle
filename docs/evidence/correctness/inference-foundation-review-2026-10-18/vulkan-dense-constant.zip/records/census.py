from pathlib import Path
import importlib.util,json
out=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('local_runner',out/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
s=(r.ROOT/'src/compute_provider_ggml_vulkan/region.cc').read_text()
marker='    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {\n      auto *node = ggml_graph_node(graph, i);'
probe='''    std::size_t copies = 0;
    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {
      const auto *node = ggml_graph_node(graph, i);
      if (node->op == GGML_OP_CONT && node->ne[0] == 37 && node->ne[1] == 7) ++copies;
    }
    std::fprintf(stderr, "MATRIX_CENSUS nodes=%zu RHS_transpose_cont=%zu\\n", recipe.nodes.size(), copies);
'''
assert s.count(marker)==1
source=out/'native-region-census.cc';source.write_bytes(('#include <cstdio>\n'+s.replace(marker,probe+marker)).encode())
obj=out/'native-region-census.obj'
r.run('native-census-compile',[r.cl,*r.flags,source,'/Fo'+str(obj)])
link=next(x['command'] for x in reversed(r.records) if x['tag'].endswith('-link'))
exe=out/'census.exe';command=[]
for arg in link:
 if arg.startswith('/OUT:'):arg='/OUT:'+str(exe)
 elif Path(arg)==out/'native-region.obj':arg=str(obj)
 command.append(arg)
r.run('census-link',command)
r.run('census',[exe,'--gtest_filter=VulkanManaged.DenseConstantRhsPacksOnceAndKeepsOtherConsumersAndDynamicWeights','--gtest_color=no'])
