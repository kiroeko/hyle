from pathlib import Path
import importlib.util
out=Path('.scratch/inference-fusion-quantization-2026-10-18/vulkan-dense-constant').resolve()
spec=importlib.util.spec_from_file_location('local_runner',out/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.run('program-final-compile',[r.cl,*r.flags,r.ROOT/'src/compute_route_vulkan/vulkan_program.cc','/Fo'+str(out/'program.obj')])
r.run('native-final-compile',[r.cl,*r.flags,r.ROOT/'src/compute_provider_ggml_vulkan/region.cc','/Fo'+str(out/'native-region.obj')])
link=next(x['command'] for x in r.records if x['tag']=='6-link')
r.run('final-link',link)
r.run('final-tests',[out/'tests.exe','--gtest_filter=VulkanManaged.DenseConstantRhsPacksOnceAndKeepsOtherConsumersAndDynamicWeights:VulkanManaged.BatchedRopePositionsAndPerTokenFrequenciesReplay','--gtest_color=no'])
