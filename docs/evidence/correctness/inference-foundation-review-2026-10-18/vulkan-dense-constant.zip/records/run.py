from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
old=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-rope/vulkan-commands.json').read_text())
compile_row=next(x['command'] for x in old if x['tag']=='1-vulkan-region-compile')
cl=Path(compile_row[0]);flags=compile_row[1:-2];link=cl.with_name('link.exe')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':str(cl),'CMAKE_C_COMPILER':str(cl)})
env['PATH']=str(ROOT/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
env['DISABLE_VULKAN_OBS_CAPTURE']='1';env['VK_LOADER_LAYERS_DISABLE']='~all~'
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command):
 command=list(map(str,command));p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=180)
 stem=str(len(records)+1)+'-'+tag
 (OUT/(stem+'.stdout.txt')).write_bytes(p.stdout);(OUT/(stem+'.stderr.txt')).write_bytes(p.stderr)
 records.append(dict(tag=stem,command=command,exit=p.returncode));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(stem,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-5000:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
def main():
 objects=[]
 for source,stem in [('src/compute_provider_ggml_vulkan/region.cc','native-region'),('src/compute_route_vulkan/vulkan_program.cc','program'),('src/compute_route_vulkan/vulkan_region.cc','route-region'),('src/graph_route_vulkan/vulkan_lowering.cc','graph'),('tests/compute_route_vulkan/managed_region_test.cc','tests')]:
  obj=OUT/(stem+'.obj');objects.append(obj)
  if '--reuse-products' in sys.argv and stem!='tests':continue
  run(stem+'-compile',[cl,*flags,ROOT/source,'/Fo'+str(obj)])
 oldlink=next(x['command'] for x in old if x['tag']=='3-vulkan-link')
 command=[]
 for arg in oldlink:
  if arg.startswith('/OUT:'):arg='/OUT:'+str(OUT/'tests.exe')
  elif arg.endswith('batched-rope\\vulkan-region.obj'):continue
  elif arg.endswith('batched-rope\\vulkan-tests.obj'):continue
  command.append(arg)
 command += [*objects,ROOT/'.scratch/build-compute-v2-dev/bin/hyle_graph.lib']
 run('link',command)
 run('tests',[OUT/'tests.exe','--gtest_filter=VulkanManaged.DenseConstantRhsPacksOnceAndKeepsOtherConsumersAndDynamicWeights:VulkanManaged.BatchedRopePositionsAndPerTokenFrequenciesReplay','--gtest_color=no'])
if __name__=='__main__':main()
