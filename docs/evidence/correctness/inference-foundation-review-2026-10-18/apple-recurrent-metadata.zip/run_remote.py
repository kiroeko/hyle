from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
OLD=R.parent/'inference-foundation-review-20261018-row-cache-paged-native'
CURRENT=R.parent/'inference-foundation-review-20261018-apple-topk-index-proof'
records=json.loads((R/'commands.json').read_text()) if (R/'commands.json').exists() else []
prior=json.loads((OLD/'commands.json').read_text())
cc=next(x['command'] for x in prior if x['tag']=='row.o-compile')
flags=cc[:cc.index('-c')]
flags[1:1]=['-I'+str(R/'include'),'-I'+str(R),'-I'+str(R/'src/compute_route_apple')]
link=next(x['command'] for x in reversed(prior) if x['tag']=='compatibility-link' and x['exit']==0)
def run(tag,cmd):
 tag=str(len(records)+1)+'-'+tag
 start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,capture_output=True,timeout=180)
 (R/(tag+'.stdout.log')).write_bytes(p.stdout);(R/(tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start))
 (R/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-5000:],p.stderr.decode(errors='replace')[-3500:],flush=True);p.check_returncode()
def compile(source,obj):run(obj+'-compile',[*flags,'-c',R/source,'-o',R/(obj+'.o')])
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
(R/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
if not(R/'mlx.metallib').exists():(R/'mlx.metallib').symlink_to(OLD/'mlx.metallib')
compile('src/compute_route_apple/apple_recurrent.cc','recurrent')
compile('tests/compute_route_apple/recurrent_test.cc','test')
compile('counter.cc','counter')
filter='AppleRecurrent.OrdinaryPreparationInterleavedRequestsAndOldOutputOwner:AppleRecurrent.StridedMlxInputAndPreparationDiagnostics:AppleRecurrent.AbandonedCompletionAndCancelCloseDrain:AppleRecurrent.PerChannelKdaGateUsesOriginalMetalRegion:AppleRecurrent.CheckedNativeFailureAfterContCopyRetiresTheInvocation'
for variant in ['before','after']:
 compile('variants/'+variant+'.cc',variant)
 cmd=[]
 for x in link:
  p=Path(x)
  if p.name=='native-test':cmd.append(str(R/(variant+'-test')))
  elif x.endswith('/mtp-gdn-snapshots-20261018/recurrent.o'):cmd.append(str(R/(variant+'.o')))
  elif x.endswith('/mtp-gdn-snapshots-20261018/native.o'):cmd.append(str(CURRENT/'native.o'))
  elif x.endswith('/inference-foundation-review-20261018-apple-row-cache-cold/context.o'):cmd.append(str(CURRENT/'context.o'))
  elif x.endswith('/inference-foundation-review-20261018-apple-row-cache-cold/operations.o'):cmd.append(str(CURRENT/'operations.o'))
  elif p.name=='test.o':continue
  else:cmd.append(x)
 cmd.extend([str(R/'test.o'),str(R/'counter.o')])
 run(variant+'-link',cmd);run(variant+'-test',[R/(variant+'-test'),'--gtest_filter='+filter])
 if variant=='after':
  deps=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in map(Path,cmd) if p.is_file() and p.suffix in {'.o','.a','.dylib'}]
  (R/'identities.json').write_text(json.dumps(deps,indent=2)+'\n')
