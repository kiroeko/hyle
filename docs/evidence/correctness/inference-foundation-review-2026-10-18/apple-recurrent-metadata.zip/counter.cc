#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <new>
namespace {
thread_local int selected = -1;
std::atomic<unsigned long long> runs{}, counts[2]{};
}
extern "C" void hyle_meta_run() { ++runs; }
extern "C" void hyle_meta_enter(int value) { selected = value; }
extern "C" void hyle_meta_leave() { selected = -1; }
void *operator new(std::size_t bytes) {
  if (selected >= 0) ++counts[selected];
  if (void *p = std::malloc(bytes ? bytes : 1)) return p;
  throw std::bad_alloc();
}
void *operator new[](std::size_t bytes) { return ::operator new(bytes); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }
__attribute__((destructor)) static void report() {
  std::printf("metadata_container_count runs=%llu dense=%llu ports=%llu\n",
      runs.load(), counts[0].load(), counts[1].load());
}
