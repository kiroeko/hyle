from pathlib import Path
import difflib,hashlib,json,re,shutil,subprocess,zipfile
R=Path.cwd();O=Path(__file__).resolve().parent
def write(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
paths=['src/compute_route_apple/apple_recurrent.cc','tests/compute_route_apple/recurrent_test.cc']
diff=[];sha=[]
for name in paths:
 p=R/name;b=O/'before'/p.name
 diff.extend(difflib.unified_diff(b.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 target=O/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 sha.append(dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(O/'source.diff').write_text(''.join(diff),encoding='utf-8');write('source-sha.json',sha)
records=json.loads((O/'commands.json').read_text())
counts={}
for variant in ['before','after']:
 tag=next(x['tag'] for x in reversed(records) if x['tag'].endswith(variant+'-test') and x['exit']==0)
 line=next(x for x in (O/(tag+'.stdout.log')).read_text().splitlines() if x.startswith('metadata_container_count'))
 counts[variant]={k:int(v) for k,v in re.findall(r'(runs|dense|ports)=(\d+)',line)}
assert counts=={'before':{'runs':15,'dense':15,'ports':15},'after':{'runs':15,'dense':0,'ports':0}}
write('summary.json',{
 'status':'implemented/tested/frozen',
 'change':'Remove the two unconditional input-owner/BufferView vector allocations in native Apple Recurrent::run.',
 'files':paths,
 'implementation':[
  'Explicit input-count<=8 guard before fixed arrays, matching NativeProgram inputs+1<=9 capability.',
  'Eight optional array owners stay on stack and hold only actual CONT results; already-row-contiguous inputs retain their original caller owners.',
  'Only when CONT is required, one vector of those copies is passed by move to the same single async_eval. Original MLX synchronize and copied-array wait remain.',
  'Nine stack BufferViews are populated and only inputs+1 active ports passed to the original NativeProgram. Original checked sync/failure/packed output allocation/output views remain.'
 ],
 'actual':{
  'machine':'Mac16,12 Apple M4 arm64 16GiB; clang21; machine.txt',
  'counted_before':'5/5 canonical cases PASS; 15 actual native Recurrent::run calls',
  'counted_after':'5/5 same canonical cases PASS; 15 actual native Recurrent::run calls',
  'canonical_plain':'5/5 same cases PASS with current uninstrumented product recurrent.o, no allocator override or count hooks in executable; canonical-test.stdout.log',
  'counts':counts,
  'count_method':'Scratch-only source hooks immediately bracket only the former dense-vector declaration and ports-vector declaration. Executable operator new counts on that runtime thread only while inside each window. The same windows bracket the replacement stack arrays. No output, CONT, MLX or whole-run allocation claim.',
  'fresh':'One product host TU (apple_recurrent.cc), canonical recurrent_test.cc, and scratch-only counter/before/after variants. Reused all original SDK, MLX/ggml native libraries/metallib and matching current TopK native/context/operations host objects. No SDK/native rebuild.',
  'current_native':'/Users/kiro/hyle-scratch/compute-unified/inference-foundation-review-20261018-apple-topk-index-proof/native.o; 33680B SHA256 93d4a88cf292c73119eede2eac485d7a9bb38481402ca5575b8d3f3020df5c7f',
  'coverage':['Ordinary GDN B2/H16/D128/T1 and T17 with independent FP64 oracle, interleaved invocation/replay and escaped old-output owner.',
              'Per-channel KDA gate and independent FP64 oracle, original 3e-6 tolerance.',
              'Ready strided Q creates a required CONT; original preparation failure/quota controls remain.',
              'Abandoned Completion and cancel/close/drain original regression.',
              'New strided activation CONT prefix followed by checked GroupedMatMul invalid expert ID returns OutOfRange and retires that slot; a sibling slot in the same Context still produces an independent FP64 dot oracle.'],
 },
 'source_review':'source-review.json records synchronization roles and remaining boundaries.',
 'failures_retained':[
  'New test initially used a custom descriptor directly rather than model_ops::grouped_matmul factory; fixed test call. Failed canonical compile retained.',
  'First link reused pre-proof mtp NativeProgram object missing run_with_proven_indices. Replaced only with matching current TopK native/context/operations objects; no product workaround/native rebuild.',
  'New strided example initially called eval without wait and failed the public ready-example admission before native execution. Added explicit wait as required by that existing contract; original 4 tests passed. No kernel numerical failure observed.'
 ],
 'limits':['No throughput claim or whole-run allocation measurement. CONT-owner branch still makes its necessary async_eval argument vector and CONT payload; output views/payload and native/MLX metadata remain.',
           'No host wait, checked status read, output allocation, inter-runtime synchronization, attention-block peak bound, numerical precision or result authority was removed.',
           'No Apple attention/Graph grouping change and no CPU/CUDA/grouped-product or ragged-runtime edits.',
           'Test count varies if cancellation is scheduled differently; the recorded successful before/after both executed exactly15 native calls.'],
 'cleanup':'deletable-artifacts.json exact proposal only; retain every .o listed in retain-objects.json and all original caches. No deletion performed.'
})
write('source-review.json',{
 'scope':'Qwen GDN / GLM-Kimi per-channel KDA / DeepSeek Sink and ordinary same-invocation multi-region replay; source-only scheduling assessment, not a full-model run.',
 'routes':[
  {'source':'tests/compute_models/d5_qwen38_24t_semantic_fragments.h:525,596 and tests/compute_models/d5_kda_full_fragments.h:115,161',
   'chain':'Conv/gates/norm are MLX; GatedDeltaNet/RecurrentGatedDeltaNet are fixed ggml model regions; following norm/gates return to MLX.'},
  {'source':'src/graph_route_apple/apple_lowering.cc:49,264,276',
   'chain':'Only fixed native or attention-block nodes cut maximal compiled MLX regions; no claim that every graph node entails a host wait.'},
  {'source':'src/compute_route_apple/apple_tensor.cc:631 and apple_operations.cc:296',
   'chain':'Sink normalizes BSHD→BHSD and rank3 mask via metadata; long queries choose original128-row AttentionBlocks based on existing peak/work formula.'}
 ],
 'wait_roles':[
  {'source':'src/compute_route_apple/apple_context.cc:338-350',
   'role':'Compiled MLX outputs async_eval→selected-stream synchronize drains its work/errors; array.wait detaches/checks event and changes evaluated→available. Checked status is read only after this. Not two full GPU waits per output.'},
  {'source':'MLX1f8e74e3/mlx/array.cpp:131-152 and mlx/array.h:428-430 (pinned tar)',
   'role':'is_available reads event signaled state; detach_event checks event error. Removing array.wait without an equivalent status/error transition violates later bind/storage available-only contracts.'},
  {'source':'MLX1f8e74e3/mlx/backend/metal/device.cpp:564-573 (pinned tar)',
   'role':'Stream synchronize commits and waits its Metal command buffer and checks encoder error. This is the real host wait, unlike an already-signaled per-array wait.'},
  {'source':'src/compute_route_apple/apple_recurrent.cc CONT branch; src/compute_provider_ggml_metal/native_program.cc:568-595',
   'role':'MLX CONT must complete before independent ggml backend imports its buffer. ggml graph_compute_async→checked_sync both establishes output readiness and drains accepted work before status/owner retirement.'},
  {'source':'src/compute_route_apple/apple_context.cc:483-492,594-607',
   'role':'Each128-query attention block drains before next block, bounding score/intermediate peak; final concatenate must become ready. Exception path synchronizes any accepted prefix before temporary block/page owners retire.'}
 ],
 'do_not_remove':[
  'Graph contiguous_outputs is an explicit caller option; native CONT occurs only for non-row-contiguous inputs. Sink mask reshape/transpose are metadata and pinned full attention accepts four mask strides.',
  'Recurrent packed output cannot simply be overwritten on slot reuse: MemoryResource::import_readonly can export an mx::array owner beyond ResultSlot lifetime (apple_memory.mm:260-300). Fresh output allocation protects escaped arrays/leases.',
  'Coalescing waits across MLX-only control-separated regions is not a local deletion: it must preserve checked-status stopping, original control/data order, accepted-prefix owner retention and current last_use peak behavior. No such broader change made.'
 ],
 'candidate_fixed':'Only unconditional native input/port container allocations were a confirmed small local removable cost in this stage.'
})
p=subprocess.run(['git','diff','--check'],cwd=R,capture_output=True)
(O/'diff-check.stdout.log').write_bytes(p.stdout);(O/'diff-check.stderr.log').write_bytes(p.stderr)
write('diff-check.json',dict(command=['git','diff','--check'],exit=p.returncode));p.check_returncode()
with zipfile.ZipFile(O/'source-results.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(O.rglob('*')):
  rel=p.relative_to(O)
  if not p.is_file() or rel.parts[0]=='__pycache__' or p.name=='source-results.zip' or p.suffix in{'.gz','.o','.obj','.exe','.a','.lib','.exp'}:continue
  z.write(p,rel.as_posix())
with zipfile.ZipFile(O/'source-results.zip')as z:assert z.testzip()is None
print(json.dumps(identity(O/'source-results.zip'),indent=2));print(json.dumps(sha,indent=2));print(json.dumps(counts))
