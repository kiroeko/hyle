import stage
code='''from pathlib import Path
import hashlib,json,subprocess,time
r=Path(%r)
records=json.loads((r/'commands.json').read_text())
cmd=next(x['command'] for x in reversed(records) if x['tag'].endswith('after-link') and x['exit']==0)
cmd=[str(r/'recurrent.o') if x==str(r/'after.o') else str(r/'canonical-test') if x==str(r/'after-test') else x for x in cmd if x!=str(r/'counter.o')]
def run(tag,cmd):
 p=subprocess.run(cmd,cwd=r,capture_output=True,timeout=180)
 (r/(tag+'.stdout.log')).write_bytes(p.stdout);(r/(tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,exit=p.returncode))
 (r/'commands.json').write_text(json.dumps(records,indent=2)+'\\n')
 print(tag,p.returncode,p.stdout.decode()[-3000:],p.stderr.decode()[-1500:]);p.check_returncode()
run('canonical-link',cmd)
test=next(x['command'] for x in reversed(records) if x['tag'].endswith('after-test') and x['exit']==0)
run('canonical-test',[str(r/'canonical-test'),test[1]])
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(r/'identities-canonical.json').write_text(json.dumps([identity(p)for p in map(Path,cmd)if p.is_file()and p.suffix in{'.o','.a','.dylib'}],indent=2)+'\\n')
(r/'retain-objects.json').write_text(json.dumps([identity(p)for p in sorted(r.glob('*.o'))],indent=2)+'\\n')
(r/'deletable-artifacts.json').write_text(json.dumps([identity(r/n)for n in ['before-test','after-test','canonical-test']],indent=2)+'\\n')
''' % stage.REMOTE
p=stage.ssh(code)
(stage.O/'finish.stdout.log').write_bytes(p.stdout)
(stage.O/'finish.stderr.log').write_bytes(p.stderr)
print(p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'))
p.check_returncode();stage.collect()
