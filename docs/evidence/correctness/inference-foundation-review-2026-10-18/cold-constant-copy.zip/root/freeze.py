from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
NATIVE = ROOT / '.scratch/architecture-refactor-2026-10-18/vulkan-constant-copy/source-results.zip'
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/cold-constant-copy.zip'

def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

sources = [
    'src/graph/execution_source_internal.h', 'src/graph/execution_source.cc',
    'src/graph/executable.cc', 'src/graph/compile_internal.h', 'src/graph/storage_budget.h',
    'src/graph_batch/batch.cc', 'src/graph_batch/region_adapter.h',
    'src/graph_route_cpu_cuda/compile.cc', 'src/graph_route_cpu/cpu_context.cc',
    'src/graph_route_cuda/cuda_context.cc',
    'src/graph_route_vulkan/execution_source.cc',
    'src/compute_route_vulkan/vulkan_memory_internal.h',
    'src/compute_route_vulkan/vulkan_memory.cc',
    'src/compute_route_vulkan/vulkan_transfer_internal.h',
    'src/compute_route_vulkan/vulkan_transfer_slot.cc',
    'include/hyle/graph/executable.h', 'include/hyle/graph/cpu_cuda.h',
    'tests/graph/region_provider_test.cc', 'tests/graph/executable_test.cc',
    'tests/graph/execution_source_test.cc', 'tests/graph/test_environment.h',
    'tests/graph_route_vulkan/native_region_test.cc',
    'tests/graph_route_vulkan/CMakeLists.txt',
    'docs/architecture/compute-design.md', 'docs/developer/current-work.md',
    'docs/user/graph.md',
    'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md',
    'test.ps1',
]
controls = json.loads((OUT / 'control-results.json').read_text())
assert controls['tests'] == 26 and controls['failures'] == controls['errors'] == 0
native_results = json.loads((NATIVE.parent / 'test-results.json').read_text())
assert native_results['tests'] == 4 and native_results['failures'] == native_results['errors'] == 0
assert NATIVE.is_file()
assert not DEST.exists(), 'A frozen evidence capsule must not be overwritten'
rows = json.loads((OUT / 'commands.json').read_text())
assert next(row for row in reversed(rows) if row['tag'] == 'materialized-run')['exit'] == 0
summary = dict(
    scope='Native cold constant materialization and actual-capability multi-source admission',
    validation=dict(shared='26/26 current controls', native='4/4 actual Vulkan controls',
                    materialized='Original complete CPU consumer PASS'),
    contracts=[
        'Pure route qualification and Graph-owned allocations precede copied bytes',
        'One native batch per actual source reuses maximum-capacity staging and original commands',
        'Native temporary staging bytes are reserved against compilation peak storage',
        'Original TransferSlot/Run/Completion, no temporary Context or fabricated Queue',
        'Original accepted failure is fatal, no other source/route retry',
        'Host source can be released after successful compilation; replay does not upload again',
        'General compile has no same-Device gate or compile_cpu_gpu BackendId bypass',
        'Selected source owner/resource/copy/endpoint and foreign Queue rejection remain',
    ],
    failures_preserved=[
        'Stale CPU context object referenced the removed batch compile signature; rebuilt actual host callers',
        'Native test budget omitted the required system metadata domain; fixed the fixture',
    ],
    limitations=[
        'Vulkan common native region still qualifies only fixed pure coarse graphs',
        'No Apple late-handle frontier, native subfragment/hybrid transfer, finite-only family or custom lowering migration',
        'No complete model rerun, actual CPU+CUDA runtime rerun, precision acceptance or performance claim',
        'Old public native Graph paths still await genuine consumer migration and deletion',
    ],
    native_capsule=identity(NATIVE), sources=[identity(ROOT / path) for path in sources],
    objects=[identity(path) for path in sorted(OUT.glob('*.obj'))])
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', newline='\n')
with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative in sources:
        archive.write(ROOT / relative, 'source/' + relative)
    archive.write(NATIVE, 'parts/vulkan-constant-copy.zip')
    for path in sorted(OUT.iterdir()):
        if path.suffix in ('.py', '.json', '.log') and path.name not in (
                'archive.json', 'cleanup.json', 'cleanup-result.json'):
            archive.write(path, 'root/' + path.name)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
receipt = identity(DEST)
(OUT / 'archive.json').write_text(json.dumps(receipt, indent=2) + '\n', newline='\n')
stages = [OUT, NATIVE.parent]
cleanup = dict(evidence=receipt['path'], allowed=[path.relative_to(ROOT).as_posix() for path in stages],
               files=[identity(path) for stage in stages for path in sorted(stage.iterdir())
                      if path.suffix in ('.exe', '.map', '.exp', '.lib')])
(OUT / 'cleanup.json').write_text(json.dumps(cleanup, indent=2) + '\n', newline='\n')
print(json.dumps(receipt))
print(json.dumps(dict(cleanup_files=len(cleanup['files']),
                     cleanup_bytes=sum(row['bytes'] for row in cleanup['files']))))
