from pathlib import Path
import json
import os
import sys
import build

ROOT, OUT = build.ROOT, build.OUT
previous = ROOT / '.scratch/architecture-refactor-2026-10-18/native-output-core'
callers = ROOT / '.scratch/architecture-refactor-2026-10-18/execution-source-callers'
rows = json.loads((previous / 'commands.json').read_text())
prior = json.loads((callers / 'commands.json').read_text())

def compile_record(records, tag, name):
    args = next(row['command'] for row in reversed(records)
                if row['tag'] == tag and row['exit'] == 0)
    args = [('/Fo' + str(OUT / name)) if arg.lower().startswith('/fo') else arg for arg in args]
    build.driver.run(name + '-compile', args)

if '--compile-adapters' in sys.argv:
    compile_record(rows, 'graph-batch-compile-current', 'graph-batch.obj')
    compile_record(prior, 'joint-compile-compile', 'joint-compile.obj')
    compile_record(prior, 'cpu-context-compile', 'cpu-context.obj')
    compile_record(prior, 'cuda-context-compile', 'cuda-context.obj')

args = next(row['command'] for row in reversed(rows)
            if row['tag'] == 'controls-link' and row['exit'] == 0)
names = ['executable.obj', 'execution_source.obj', 'graph-batch.obj', 'cpu-context.obj',
         'region_provider_test.obj']
replacements = {name: OUT / name for name in names}
fresh = []
for arg in args:
    if arg.upper().startswith('/OUT:'):
        fresh.append('/OUT:' + str(OUT / 'controls.exe'))
    elif arg.upper().startswith('/MAP:'):
        fresh.append('/MAP:' + str(OUT / 'controls.map'))
    else:
        fresh.append(str(replacements.get(Path(arg).name.lower(), arg)))
fresh.append(str(OUT / 'executable_test.obj'))
build.driver.run('controls-link', fresh)
torch = next(Path(arg) for arg in fresh if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
build.driver.run('constant-controls-run', [OUT / 'controls.exe', '--gtest_color=no',
    '--gtest_output=json:' + str(OUT / 'control-results.json'),
    '--gtest_filter=GraphCompile.*Constant*:GraphVariants.ConstantCopy*:'
    'GraphDomain.Materialized*:GraphCompilationStorage.ConstantReservation*:'
    'GraphCompilationStorage.CanonicalBytes*:GraphExecutionSource.*:'
    'GraphRouteBoundary.CapabilityAdapter*:'
    'GraphRegions.RawBindingsAndOwnedResultsUseTheSameInvocationGate:'
    'GraphRegions.InvocationRetainsItsCompiledRegionAndWorkspaceOwner:'
    'GraphRegions.OrderedSequenceDoesNotHostWaitAndRetainsInvocationUntilTerminal:'
    'GraphRegions.RejectedTailIsReportedAfterTheAcceptedAsyncPrefix:'
    'GraphRegions.AbandonedAggregateRetainsEveryIndependentSink:'
    'GraphRouteBoundary.ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort:'
    'GraphRouteBoundary.ContextRoutesKeepExactOwnersAndResourceChecks:'
    'GraphRouteBoundary.DifferentDevicesUseTheSelectedSourceCapabilities'])

args = next(row['command'] for row in reversed(rows)
            if row['tag'] == 'materialized-final-link' and row['exit'] == 0)
fresh = []
for arg in args:
    if arg.upper().startswith('/OUT:'):
        fresh.append('/OUT:' + str(OUT / 'materialized.exe'))
    elif arg.upper().startswith('/MAP:'):
        fresh.append('/MAP:' + str(OUT / 'materialized.map'))
    else:
        fresh.append(str(replacements.get(Path(arg).name.lower(), arg)))
build.driver.run('materialized-link', fresh)
build.driver.run('materialized-run', [OUT / 'materialized.exe'])
