#include "hyle/graph/cuda.h"
#include "hyle/compute/low_precision.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include "hyle/compute/backends/cuda.h"
#include "tensor_program.h"
#include <ggml.h>
#include <cupti.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace n = c::ggml_cuda::internal;
constexpr int K=128, N=64;
static bool observe=false;
static std::vector<std::string> kernels;
static void require(bool value,const char* message) {
  if(!value){std::fprintf(stderr,"FAIL %s\n",message);std::exit(1);}
}
template<class T>T take(hyle::Result<T>&&r) {
  if(!r){std::fprintf(stderr,"FAIL Status %.*s\n",int(r.error().message().size()),r.error().message().data());std::exit(1);}
  return std::move(*r);
}
static void CUPTIAPI callback(void*,CUpti_CallbackDomain domain,CUpti_CallbackId,
                             const void*data) {
  if(!observe || domain!=CUPTI_CB_DOMAIN_RUNTIME_API)return;
  const auto& call=*static_cast<const CUpti_CallbackData*>(data);
  if(call.callbackSite==CUPTI_API_ENTER && call.symbolName &&
     std::strstr(call.functionName,"LaunchKernel"))kernels.emplace_back(call.symbolName);
}
static c::TensorDesc dense(std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(c::DataType::kFloat32,{shape.begin(),shape.size()}));
}
static std::vector<float> weight(int salt) {
  std::vector<float> data(K*N);
  for(int row=0;row<N;++row)for(int k=0;k<K;++k)
    data[row*K+k]=float(k%32==0?127:((row*19+k*7+salt*11)%127-63))/1024.F;
  return data;
}
static std::vector<std::byte> pack(const std::vector<float>& data,const c::TensorDesc& desc) {
  std::vector<std::byte> result(take(desc.required_bytes()));
  require(ggml_quantize_chunk(GGML_TYPE_Q8_0,data.data(),result.data(),0,N,K,nullptr)==result.size(),"Q8 quantizer byte count");
  std::vector<float> decoded(K*N);
  ggml_get_type_traits(GGML_TYPE_Q8_0)->to_float(result.data(),decoded.data(),K*N);
  require(decoded==data,"Q8 fixture dyadic values must encode exactly");
  return result;
}
static void structure(bool after,const c::TensorDesc& x,const c::TensorDesc& w,
                      const c::TensorDesc& y) {
  auto* arena=ggml_init({1024*1024,nullptr,true});require(arena,"metadata arena");
  n::Recipe recipe;
  recipe.values={x,w,w,y,y,y};recipe.inputs={0,1,2};recipe.outputs={5};
  recipe.nodes={{c::Operation(c::MatMul{}),{0,1},{3}},
                {c::Operation(c::MatMul{}),{0,2},{4}},
                {c::Operation(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate}),{3,4},{5}}};
  std::array<ggml_tensor*,6> values{};
  for(int i=0;i<3;++i)values[i]=n::create_tensor_input(arena,recipe.values[i]);
  std::vector<n::ScalarConstant> scalar;
  std::vector<n::DenseConstant> constants;
  for(const auto&node:recipe.nodes) {
    auto results=n::lower_tensor_operation(arena,recipe,node,values,scalar,constants,{},{});
    require(results.size()==1,"structural lowering arity");values[node.outputs[0]]=results[0];
  }
  auto* graph=ggml_new_graph_custom(arena,64,false);ggml_build_forward_expand(graph,values[5]);
  int reshapes=0;std::vector<ggml_tensor*> mm;
  std::printf("structure %s ops=",after?"after":"before");
  for(int i=0;i<ggml_graph_n_nodes(graph);++i) {
    auto* node=ggml_graph_node(graph,i);std::printf("%s%s",i?",":"",ggml_op_name(node->op));
    reshapes+=node->op==GGML_OP_RESHAPE;
    if(node->op==GGML_OP_MUL_MAT)mm.push_back(node);
  }
  require(mm.size()==2,"two native matmuls");
  const bool shared=mm[0]->src[1]==mm[1]->src[1];
  std::printf(" nodes=%d reshape=%d sharedSrc1=%d\n",ggml_graph_n_nodes(graph),reshapes,int(shared));
  require(reshapes==(after?0:5) && shared==after,"same-shape metadata and input identity");
  ggml_free(arena);
}

int main(int argc,char**argv) {
  const bool after=argc>1&&std::strcmp(argv[1],"after")==0;
  CUpti_SubscriberHandle subscriber{};
  require(cuptiSubscribe(&subscriber,&callback,nullptr)==CUPTI_SUCCESS,"CUPTI subscribe");
  require(cuptiEnableDomain(1,subscriber,CUPTI_CB_DOMAIN_RUNTIME_API)==CUPTI_SUCCESS,"CUPTI runtime domain");
  const auto xdesc=dense({1,K}),ydesc=dense({1,N});
  const auto wdesc=take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,K,N));
  structure(after,xdesc,wdesc,ydesc);
  auto context=take(g::cuda::create_context());
  auto memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
  const auto wg=weight(3),wu=weight(7);
  auto pg=pack(wg,wdesc),pu=pack(wu,wdesc);
  const auto upload=[&](std::span<const std::byte>bytes){
    auto buffer=take(m::Buffer::create(memory.ref(),bytes.size(),256));require(buffer.view().write(bytes).ok(),"native upload");return buffer;
  };
  auto gate_weight=upload(pg),up_weight=upload(pu);
  auto input=take(m::Buffer::create(memory.ref(),K*sizeof(float),256));
  for(bool published:{false,true}) {
    auto builder=take(g::GraphBuilder::create());
    const auto x=take(builder.input(xdesc)),a=take(builder.constant(wdesc)),b=take(builder.constant(wdesc));
    const auto gate=take(builder.add(c::MatMul{},x,a)),up=take(builder.add(c::MatMul{},x,b));
    const auto out=take(builder.add(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate},gate,up));
    if(published){require(builder.publish(gate).ok(),"publish gate");require(builder.publish(up).ok(),"publish up");}
    require(builder.publish(out).ok(),"publish gate result");
    const auto logical=take(std::move(builder).finish());
    const std::array constants{g::ConstantBinding{a,take(c::ConstTensorView::create(wdesc,gate_weight.view()))},
                               g::ConstantBinding{b,take(c::ConstTensorView::create(wdesc,up_weight.view()))}};
    auto compiled=take(g::cuda::compile(logical,context,memory.ref(),{.constants=constants}));
    require(compiled.report.region_count()==1 && compiled.report.step_count()==1,"actual default graph native region");
    require(compiled.report.step(0)->provider.id==c::ggml_cuda::kProviderId,"actual default provider");
    std::printf("default Graph published=%d providers=%zu regions=%zu steps=%zu\n",int(published),context.provider_count(),compiled.report.region_count(),compiled.report.step_count());
    auto queue=take(context.create_queue());
    auto invocation=take(compiled.executable.create_invocation());
    std::array<m::Buffer,3> outputs;
    const std::array ids{gate,up,out};
    const int first=published?0:2;
    for(int port=first;port<3;++port){
      outputs[port]=take(m::Buffer::create(memory.ref(),N*sizeof(float),256));
      require(invocation.bind(ids[port],take(c::TensorView::create(ydesc,outputs[port].view()))).ok(),"output bind");
    }
    require(invocation.bind(x,take(c::ConstTensorView::create(xdesc,input.view()))).ok(),"input bind");
    require(g::cuda::prepare_replay(invocation,queue).ok(),"prepare default replay");
    std::array<float,N> held{};
    for(int phase=0;phase<2;++phase) {
      std::array<float,K> values{};
      for(int k=0;k<K;++k)values[k]=float(k%32==0?127:((k*11+phase*17)%127-63))/128.F;
      require(input.view().write(std::as_bytes(std::span(values))).ok(),"changed input write");
      kernels.clear();observe=true;
      auto done=take(invocation.submit(queue));require(done.wait().ok(),"default Graph completion");
      observe=false;
      unsigned fused=0,plain=0,glu=0;
      for(const auto&name:kernels) {
        std::printf("kernel published=%d phase=%d %s\n",int(published),phase,name.c_str());
        if(name.find("mul_mat_vec_q")!=std::string::npos) {
          if(name.find("ELi1ELb1E")!=std::string::npos)++fused;else ++plain;
        }
        glu+=name.find("unary_gated_op_kernel")!=std::string::npos;
      }
      std::printf("kernel summary published=%d phase=%d total=%zu mmvqFused=%u mmvqPlain=%u swiglu=%u\n",int(published),phase,kernels.size(),fused,plain,glu);
      const bool should_fuse=after&&!published;
      require(kernels.size()==(should_fuse?2:5) && fused==(should_fuse?1U:0U) &&
          plain==(should_fuse?0U:2U) && glu==(should_fuse?0U:1U),
          "actual native fused carrier and published-intermediate guard");
      std::array<std::array<float,N>,3> actual{};double maximum=0;
      for(int port=first;port<3;++port)require(outputs[port].view().read(std::as_writable_bytes(std::span(actual[port]))).ok(),"full result download");
      for(int col=0;col<N;++col) {
        double ga=0,upvalue=0;
        for(int k=0;k<K;++k){ga+=double(values[k])*wg[col*K+k];upvalue+=double(values[k])*wu[col*K+k];}
        const std::array<double,3> expected{ga,upvalue,ga/(1+std::exp(-ga))*upvalue};
        for(int port=first;port<3;++port)maximum=std::max(maximum,std::abs(double(actual[port][col])-expected[port]));
      }
      require(maximum<3e-6,"full output independent FP64 oracle");
      if(phase==0)held=actual[2];
      else require(held!=actual[2],"changed replay must change result while saved prior values remain available");
      std::printf("oracle published=%d phase=%d maxAbs=%.9g PASS\n",int(published),phase,maximum);
    }
  }
  require(cuptiUnsubscribe(subscriber)==CUPTI_SUCCESS,"CUPTI unsubscribe");
  std::puts("PASS native-shape default Graph Q8 gate/up->SwiGLU");
}
