from pathlib import Path
import difflib,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
diff=''
for old,new in [('tensor_program.before.cc','src/compute_provider_ggml_cuda/tensor_program.cc'),
                ('ggml_test.before.cc','tests/graph_route_cuda/ggml_test.cc')]:
  diff+=''.join(difflib.unified_diff((OUT/old).read_text().splitlines(keepends=True),
    (ROOT/new).read_text().splitlines(keepends=True),fromfile='before/'+new,tofile='after/'+new))
(OUT/'product-scoped.diff').write_text(diff,encoding='utf-8',newline='\n')
files={p.name:p for p in OUT.iterdir() if p.is_file() and
  (p.suffix in {'.py','.cc','.json','.txt','.diff'} or
   (p.suffix=='.log' and p.name[0].isdigit()))}
for name in ['src/compute_provider_ggml_cuda/tensor_program.cc',
             'tests/graph_route_cuda/ggml_test.cc','tests/graph_route_cuda/ggml_gate_projection_test.h']:
  files['source/'+name]=ROOT/name
objects=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(OUT.glob('*.obj'))]
(OUT/'fresh-object-identities.json').write_text(json.dumps(objects,indent=2)+'\n')
files['fresh-object-identities.json']=OUT/'fresh-object-identities.json'
identities=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for n,p in sorted(files.items())]
(OUT/'package-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
files['package-identities.json']=OUT/'package-identities.json'
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,path in sorted(files.items()):z.write(path,name)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
print(json.dumps(dict(path=str(archive),files=len(files),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),indent=2))
