from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3]; OUT=Path(__file__).resolve().parent
def load(name,path):
  spec=importlib.util.spec_from_file_location(name,ROOT/path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
cuda=load('fusion_cached_cuda','.scratch/mtp-completion/run.py')
host=load('fusion_cached_host','.scratch/inference-feature-completion-2026-10-18/windows-batch/build_host.py')
old=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/commands.json').read_text())
command=next(r['command'] for r in reversed(old) if r['tag']=='cuda-after-link')
env=host.env.copy()
cupti=host.TOOLKIT/'extras/CUPTI'
runtime=list(dict.fromkeys(str(Path(p).parent) for p in command if p.endswith('.lib') and Path(p).is_absolute()))
env['PATH']=str(cupti/'lib64')+os.pathsep+os.pathsep.join(runtime)+os.pathsep+env['PATH']
flags=cuda.flags+['/I'+str(ROOT),'/external:I'+str(cupti/'include')]
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,args):
  args=list(map(str,args));start=time.monotonic();p=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,timeout=120)
  stem=f'{len(records)+1}-{tag}'
  (OUT/(stem+'.stdout.log')).write_bytes(p.stdout);(OUT/(stem+'.stderr.log')).write_bytes(p.stderr)
  records.append(dict(tag=tag,command=args,exit=p.returncode,seconds=time.monotonic()-start));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(tag,p.returncode,round(time.monotonic()-start,3),p.stdout.decode(errors='replace')[-4400:],p.stderr.decode(errors='replace')[-1400:],flush=True)
  if p.returncode:raise SystemExit(p.returncode)
if '--canonical' in sys.argv:
  run('canonical-compile',[cuda.cl,*flags,ROOT/'tests/graph_route_cuda/ggml_test.cc','/Fo'+str(OUT/'canonical.obj')])
  omit=[ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-test.obj',
        ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/tensor.obj']
  args=[x for x in command if not x.startswith(('/OUT:','/MAP:')) and Path(x)not in omit]
  args += [str(OUT/'canonical.obj'),str(OUT/'tensor-after.obj'),'/OUT:'+str(OUT/'canonical.exe')]
  run('canonical-link',args)
  run('canonical-test',[OUT/'canonical.exe','--gtest_filter=CudaDefaultGraph.SharedQ8GateUpSwiGluPreservesPublishedIntermediates:CudaDefaultGraph.OriginalTensorRegionThroughOrdinaryEntry:CudaDefaultGraph.OriginalSoftmaxRegionThroughOrdinaryEntry','--gtest_color=no'])
  raise SystemExit(0)
run('probe-compile',[cuda.cl,*flags,OUT/'probe.cc','/Fo'+str(OUT/'probe.obj')])
for revision in ['before','after']:
  source=OUT/'tensor_program.before.cc' if revision=='before' else ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc'
  data=source.read_text()
  for codec in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
    old_return='return GGML_TYPE_'+codec+';'
    assert data.count(old_return)==1
    data=data.replace(old_return,'return GGML_TYPE_COUNT; // Validation-only unrelated missing codec in reused native pin.')
  scratch=OUT/('tensor-'+revision+'.cc');scratch.write_text(data)
  obj=OUT/('tensor-'+revision+'.obj')
  if '--reuse-tensors' not in sys.argv:
    run(revision+'-tensor-compile',[cuda.cl,*flags,scratch,'/Fo'+str(obj)])
  exe=OUT/(revision+'.exe')
  omit=[ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-test.obj',
        ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/tensor.obj']
  args=[x for x in command if not x.startswith(('/OUT:','/MAP:')) and Path(x)not in omit]
  args += [str(OUT/'probe.obj'),str(obj),str(cupti/'lib64/cupti.lib'),'/OUT:'+str(exe)]
  run(revision+'-link',args)
  run(revision+'-probe',[exe,revision])
run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
paths=[Path(p) for p in command if p.endswith(('.obj','.lib')) and Path(p).is_file()]
paths += [ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc',cuda.source/'src/ggml-cuda/ggml-cuda.cu',
          ROOT/'.scratch/perf-review-2026-10-18/ggml-attention-provider/ggml-cuda.strict.cu',cupti/'lib64/cupti64_2026.2.1.dll']
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
