from pathlib import Path
import hashlib, json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
HEADER_ROOT = ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch/verified-headers/include/flashinfer'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def evidence(path, needle, context=4):
    lines = path.read_text(encoding='utf-8').splitlines()
    at = next(i for i, line in enumerate(lines) if needle in line)
    lo, hi = max(0, at-context), min(len(lines), at+context+1)
    return dict(identity=identity(path), first_line=lo+1, lines=lines[lo:hi])

review = dict(
    finding='The ratio list was a historical qualification subset, not a native template or numerical restriction.',
    schema=evidence(ROOT/'src/compute_batch/batch_layout.cc', 'c.query_heads%c.kv_heads', 4),
    native_adapter=evidence(ROOT/'src/compute_provider_flashinfer/native_batch.cu', 'p.num_qo_heads=s.query_heads;p.group_size', 2),
    locked_planner_integral_heads=evidence(HEADER_ROOT/'attention/scheduler.cuh', 'num_qo_heads % num_kv_heads', 4),
    locked_planner_packed_length=evidence(HEADER_ROOT/'attention/scheduler.cuh', 'int64_t(qo_indptr_h[i + 1] - qo_indptr_h[i]) * int64_t(gqa_group_size)', 4),
    locked_kernel_load=evidence(HEADER_ROOT/'attention/prefill.cuh', 'group_size.divmod(packed_offset', 5),
    locked_kernel_store=evidence(HEADER_ROOT/'attention/prefill.cuh', 'group_size.divmod(o_packed_idx_base', 5),
    locked_kernel_traits=evidence(HEADER_ROOT/'attention/prefill.cuh', 'dim3 nblks(padded_batch_size, 1, num_kv_heads)', 8),
    limits='Positive divisible heads are validated by the common schema. CTA/MMA/shared-memory traits depend on depth, tile and dtype, not an enumerated GQA ratio. Native uint32 Q/output and ragged offsets are bounded with the complete capacity and max(QK,V) depth; original per-row stride, finite supported depth/dtype, native planning/workspace and CUDA launch checks remain.',
    evidence_limit='Static native integer-ratio contract plus actual ratio16 and original ratio6 consumers; not a claim that every maximum capacity, GPU, encoded/window/split/capture domain was executed.',
    native_input_identity='The original native objects are inherited verbatim from the resolved current CUDA closure; see native-math-owners.json and current-link.json. No header or CUDA object was rebuilt by this slice.')
(OUT/'native-contract-review.json').write_text(json.dumps(review, indent=2)+'\n', encoding='utf-8')

remaining = ROOT/'.scratch/architecture-refactor-2026-10-18/remaining-inference-gap-current'
remaining.mkdir(exist_ok=True)
data = dict(
    scope='8 selected text models / 22 official or GGUF profiles, CPU/CUDA/Apple/Vulkan. Existing current-work, compute/graph architecture, fixed model/catalog facts and current correctness evidence reviewed; historical statuses and the old 75% estimate are not current coverage.',
    confirmed_product_gaps=[dict(
        id='qwen38-gqa16', model='Qwen3.8-2.4T-A95B', profiles=3,
        trigger='Full attention QH64/KVH4/D256 (GQA16), typed CUDA ragged/paged batched inference',
        before='Both ordinary default Direct and Graph reject actual native BatchPlanning qualification; there is no automatic materialized fallback.',
        status='fixed_and_targeted_windows_runtime_pass',
        evidence='../qwen38-gqa16-current/summary.json',
        change='Removed redundant GQA ratio enumeration in the original native qualifier, retained natural integer/geometry/resource constraints; no native math changes.')],
    other_inspected_boundaries=[dict(
        topic='DeepSeek sqrt-softplus/hash routing on CPU/Apple/Vulkan',
        status='not_a_confirmed_missing_model_function',
        facts='The complete custom SqrtSoftplusRouting/HashRouting carrier is CUDA-specific by its public comment. Other routes already compose existing typed operations. The portable hash test recipe still explicitly reduces to one token, but current GatherElements can naturally avoid the old T-by-T intermediate.',
        files=['include/hyle/compute/model_ops.h:566', 'tests/compute_models/d5_moe_execution_fragments.h:69',
            'src/compute_provider_cuda/router_provider.cc:31'],
        next_small_consumer='If prioritized later: portable T=2/17 table Gather -> GatherElements -> stable Softplus/Sqrt -> normalization -> existing expert chain, using device IDs and original budgets. No new operation/executor is established necessary.'),
        dict(topic='Kimi-K3 QK192/V128 typed native batch geometry',
        status='actual_native_domain_limit_not_proven_adapter_only_gap',
        facts='Pinned model facts use qk_nope128+rope64 and V128. Current native GQA batch qualifications on CUDA/Apple/Vulkan do not admit 192->128, while ordinary composed attention is a distinct available expression. This review has not proved the locked native math implements this exact shape, so no qualifier-only patch is justified.',
        files=['docs/implementation/tasks/compute/llm-moe-model-sources.json',
            'src/compute_provider_flashinfer/flashinfer_provider.cc:144',
            'src/compute_route_apple/apple_batch.cc:15', 'src/compute_route_vulkan/vulkan_batch.cc:14'],
        next_small_consumer='First inspect the actual locked native D192/V128 math and resource feasibility; only if supplied, consume two unequal requests via the same Program/Invocation. Do not pad/expand the full history or relabel three independent QKV ports as compact MLA.')],
    excluded_as_already_closed=['paging and projected row cache', 'GDN/KDA feedback', 'ordinary Apple/Vulkan RaggedGraph',
        'Vulkan BF16/mixed native attention', 'CUDA additive-mask SDPA', 'official FP4/FP8 grouped expert routing and canonical bank addressing'],
    limits='This is a focused continuation that found and repaired one real model-triggered hole; it does not establish exhaustion or a new overall completion percentage. No Linux/Apple runtime or complete-model accuracy/throughput acceptance from this slice.')
(remaining/'review.json').write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
print('Saved bounded native contract and remaining-scope review; no native headers copied or rebuilt.')
