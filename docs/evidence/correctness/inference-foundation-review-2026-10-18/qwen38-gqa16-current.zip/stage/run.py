from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
SOURCE = 'src/compute_provider_flashinfer/flashinfer_provider.cc'
TEST = 'tests/compute_provider_flashinfer/gqa16_test.cc'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
def ident(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

PROVIDER_FLAGS = next(row['command'] for row in read(ARCH/'native-runtime-retirement/metadata-oom-review/commands.json')
    if Path(row.get('source', {}).get('path', '')).name == 'flashinfer_provider.cc')
TEST_FLAGS = read(ARCH/'strided-reshape/consumer-identity.json')['command']

def environment():
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': PROVIDER_FLAGS[0], 'CMAKE_C_COMPILER': PROVIDER_FLAGS[0]})
    env['VSLANG'] = '1033'
    paths = [r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\x64',
             r'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin']
    base = OUT/'current-base-link.json'
    if base.exists():
        paths += [str(Path(v).parent) for v in read(base)['command'] if v.lower().endswith('.lib') and Path(v).is_absolute()]
    env['PATH'] = os.pathsep.join(dict.fromkeys(paths)) + os.pathsep + env['PATH']
    return env

def run(tag, command, expected=0):
    rows = read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
    stem = f'{len(rows)+1:03d}-{tag}'
    row = dict(tag=tag, command=list(map(str, command)), cwd=str(ROOT), exit=None,
        stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    rows.append(row); save('commands.json', rows)
    print('START', stem, flush=True); started = time.monotonic()
    with (OUT/row['stdout']).open('wb') as stdout, (OUT/row['stderr']).open('wb') as stderr:
        result = subprocess.run(row['command'], cwd=ROOT, env=environment(), stdout=stdout, stderr=stderr, timeout=240)
    row.update(exit=result.returncode, seconds=time.monotonic()-started); save('commands.json', rows)
    print('END', stem, result.returncode, flush=True)
    print((OUT/row['stdout']).read_text(errors='replace')[-9000:])
    print((OUT/row['stderr']).read_text(errors='replace')[-3000:])
    if result.returncode != expected: raise SystemExit(result.returncode or 99)

def compile_(which):
    source = ROOT/TEST if which == 'test' else OUT/'before'/SOURCE if which == 'old' else ROOT/SOURCE
    template = TEST_FLAGS if which == 'test' else PROVIDER_FLAGS
    flags = [v for v in template if not v.lower().startswith(('/fo', '/fd')) and not v.lower().endswith('.cc')]
    output = OUT/('gqa16-test.obj' if which == 'test' else 'flashinfer-'+which+'.obj')
    command = [*flags, str(source), '/Fo'+str(output)]
    before = ident(source)
    run(which+'-compile', command)
    assert ident(source) == before
    save(which+'-identity.json', dict(source=before, object=ident(output), command=command))

def link(which):
    base = read(OUT/'current-base-link.json')
    command = base['command']
    original = [v for v in command if v.lower().endswith('.obj') and 'flashinfer_provider' in Path(v).name]
    if len(original) != 1: raise ValueError(f'Need one resolved FlashInfer host owner: {original}')
    consumers = [v for v in command if v.lower().endswith('.obj') and Path(v).name in {'consumer.obj', 'main.obj'}]
    if 'consumer_object' in base: consumers += [base['consumer_object']]
    if not consumers: raise ValueError('Need an explicitly identified model consumer to remove')
    object_ = OUT/('flashinfer-'+which+'.obj')
    args = [str(object_) if v == original[0] else v for v in command
        if not v.lower().startswith(('/out:', '/map:', '/implib:', '/pdb:')) and v not in consumers]
    args.insert(1, str(OUT/'gqa16-test.obj'))
    libs = read(ARCH/'cold-placement-facts/link-plan.json')['command']
    args += [next(v for v in libs if Path(v).name.lower() == lib) for lib in ['gtest_main.lib', 'gtest.lib']]
    args = list(dict.fromkeys(args))
    args += ['/OUT:'+str(OUT/(which+'.exe')), '/MAP:'+str(OUT/(which+'.map')), '/IMPLIB:'+str(OUT/(which+'.lib'))]
    inputs = [ident(v) for v in args if Path(v).is_file() and Path(v).suffix.lower() in {'.obj', '.lib'}]
    save(which+'-link.json', dict(command=args, source_base=str(OUT/'current-base-link.json'),
        replaced_flashinfer=original[0], removed_consumer=consumers, inputs=inputs))
    run(which+'-link', args)
    text = (OUT/(which+'.map')).read_text(errors='replace')
    owners = [line for line in text.splitlines() if '?provider@flashinfer@compute@hyle@@' in line]
    assert owners and all(object_.name in line for line in owners), owners
    save(which+'-map-owners.json', dict(flashinfer=owners, object=ident(object_)))

def execute(which):
    filter_ = 'FlashinferGqa16.Default*' if which == 'old' else 'FlashinferGqa16.*'
    run(which+'-tests', [OUT/(which+'.exe'), '--gtest_filter='+filter_, '--gtest_color=no',
        '--gtest_output=xml:'+str(OUT/(which+'-tests.xml'))], expected=1 if which == 'old' else 0)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['test', 'old', 'current', 'link-old', 'link-current', 'run-old', 'run-current', 'hardware'])
    action = parser.parse_args().action
    if action in {'test', 'old', 'current'}: compile_(action)
    elif action.startswith('link-'): link(action.split('-', 1)[1])
    elif action.startswith('run-'): execute(action.split('-', 1)[1])
    else: run('hardware', ['nvidia-smi', '--query-gpu=name,compute_cap,driver_version,memory.total', '--format=csv'])
