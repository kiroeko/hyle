"""Archive this bounded slice once; no builds, tests, deletion or moving."""
from pathlib import Path
import difflib, hashlib, json, zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen38-gqa16-current.zip'
SOURCE = 'src/compute_provider_flashinfer/flashinfer_provider.cc'
FILES = [SOURCE, 'tests/compute_provider_flashinfer/gqa16_test.cc',
    'tests/compute_provider_flashinfer/CMakeLists.txt', 'docs/user/batch-attention.md',
    'docs/developer/current-work.md',
    'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md']
SUPPORT = ['tests/compute_provider_native/half_test_support.h',
    'tests/compute_models/d5_qwen38_24t_fixture.h',
    'src/compute_provider_flashinfer/native_batch.cu',
    'src/compute_provider_flashinfer/native_batch.h',
    'src/compute_provider_flashinfer/native_cache.cu',
    'include/hyle/compute/batch_layout.h', 'include/hyle/compute/batch_ops.h']
TEXT = {'.cc', '.h', '.cu', '.py', '.md', '.json', '.log', '.xml', '.diff', '.txt', '.d', '.cmake'}
IMAGE = {'.exe', '.map', '.lib', '.exp'}

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(name, data): (OUT/name).write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
def stable(path):
    if path.is_symlink(): raise ValueError(f'Symlink is not an evidence input: {path}')
    path.resolve().relative_to(ROOT)
    a = path.stat(); data = path.read_bytes(); b = path.stat()
    if (a.st_size, a.st_mtime_ns) != (b.st_size, b.st_mtime_ns): raise ValueError(f'Source drift while reading: {path}')
    return data
def identity(path):
    data = stable(path)
    return dict(path=str(path.resolve()), bytes=len(data), sha256=sha(data))
def diff(old, new, old_name, new_name):
    lines = lambda data: [row+'\n' for row in data.decode('utf-8-sig').splitlines()]
    return ''.join(difflib.unified_diff(lines(old), lines(new), fromfile=old_name, tofile=new_name)).encode('utf-8')

if DEST.exists(): raise FileExistsError(f'Preserve existing evidence; will not overwrite: {DEST}')
tested = stable(OUT/'candidate'/SOURCE)
canonical = stable(ROOT/SOURCE)
tested_identity = read(OUT/'current-identity.json')['source']
assert sha(tested) == tested_identity['sha256'] == 'ffc147264d7bfd3738101b6941fce3487da852e5c4b9e9da3c86d1c6d40f324b'
before_line = '  if(id==detail::kMlaBatchPlanningExtensionId)return &kMlaVTable;return nullptr;'
after_lines = '  if(id==detail::kMlaBatchPlanningExtensionId)return &kMlaVTable;\n  return nullptr;'
normalized = lambda data: data.decode('utf-8-sig').replace('\r\n', '\n')
assert normalized(tested).count(before_line) == 1
assert normalized(tested).replace(before_line, after_lines) == normalized(canonical)
assert sha(canonical) == '5ee516c31e99f23bab842974fc10049911b48118868f54d77c6eee917f9768fe'
save('canonical-formatting.json', dict(windows_tested=tested_identity, canonical=identity(ROOT/SOURCE),
    change='Only split the existing final return onto its own line to satisfy Linux misleading-indentation diagnostics.',
    exact_replacement_verified=True, windows_math_rerun_after_formatting=False))
(OUT/'canonical-formatting.diff').write_bytes(diff(tested, canonical, 'windows-tested/'+SOURCE, 'candidate/'+SOURCE))

final_diff = b''
for name in FILES:
    data = stable(ROOT/name)
    target = OUT/'final-candidate'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists(): raise FileExistsError(f'Final source snapshot already exists: {target}')
    target.write_bytes(data)
    old = OUT/'before'/name
    final_diff += diff(stable(old) if old.exists() else b'', data,
        'before/'+name if old.exists() else '/dev/null', 'candidate/'+name)
(OUT/'final-source.diff').write_bytes(final_diff)
save('final-source-identities.json', [identity(ROOT/name) for name in FILES])

# These are candidates for the root test.ps1 cleanup after this archive has
# been reviewed. This script does not delete or move any linked image.
images = [identity(path) for path in sorted(OUT.iterdir()) if path.is_file() and path.suffix.lower() in IMAGE]
assert len(images) == 8
save('linked-image-cleanup.json', dict(
    authorized_executor='Root writes exact deletions into repository test.ps1 after successful archival',
    targets=images, bytes=sum(row['bytes'] for row in images), cleanup_performed=False,
    retained=[identity(OUT/name) for name in ['flashinfer-current.obj', 'flashinfer-old.obj', 'gqa16-test.obj']]))

payloads = {}
def add(name, data):
    if name in payloads or '..' in Path(name).parts or name.startswith('/'): raise ValueError(name)
    payloads[name] = data

excluded = []
for path in sorted(OUT.rglob('*')):
    if not path.is_file(): continue
    relative = path.relative_to(OUT)
    if (path.suffix.lower() not in TEXT or path.name == 'archive-receipt.json'
        or any(part == '__pycache__' for part in relative.parts)):
        excluded.append(dict(path=relative.as_posix(), bytes=path.stat().st_size)); continue
    # candidate/ is the Windows-tested freeze, final-candidate/ is canonical.
    # Their distinct names preserve both identities without reclassifying a run.
    add('stage/'+relative.as_posix(), stable(path))
for name in FILES: add('candidate/'+name, stable(OUT/'final-candidate'/name))
for name in SUPPORT: add('support/'+name, stable(ROOT/name))
remaining = ROOT/'.scratch/architecture-refactor-2026-10-18/remaining-inference-gap-current/review.json'
add('remaining-scope-review.json', stable(remaining))
manifest = dict(
    kind='Qwen3.8 GQA native-batch source and numerical evidence',
    canonical_source=identity(ROOT/SOURCE), windows_tested_source=tested_identity,
    source_policy='candidate/ and stage/final-candidate/ are final canonical source; stage/candidate/ is the exact Windows-tested freeze. The only difference is the separately verified equivalent return-line split.',
    validation='Windows final 022: 3/3 pass, 24 GQA16 and 6 GQA6 FP64 checks, original absolute budget .007. Original host final 019: two selected default tests fail qualification. No Windows math rerun after formatting; no model/performance or Linux runtime claim.',
    dependency_policy='Resolved current CUDA link identities and command text are retained. No referenced baseline objects, libraries, native SDK/header trees, models or weights are followed or copied.',
    cleanup_policy='linked-image-cleanup.json records exact candidates only; root test.ps1 performs any later cleanup. This archiver performs no deletion or moving.',
    payloads=[dict(path=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(payloads.items())],
    excluded=excluded)
with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payloads.items()): archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2).encode('utf-8')+b'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for name, data in payloads.items(): assert sha(archive.read(name)) == sha(data), name
for name in FILES: assert stable(ROOT/name) == stable(OUT/'final-candidate'/name), name
receipt = dict(archive=identity(DEST), payloads=len(payloads),
    uncompressed_payload_bytes=sum(map(len, payloads.values())), crc_verified=True, payload_sha256_verified=True,
    final_source_drift=False, excludes_all_objects_linked_images_sdk_models=True,
    windows_tests_rerun=False, cleanup_performed=False, files_moved=False,
    linked_image_cleanup_manifest=identity(OUT/'linked-image-cleanup.json'))
save('archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
