from pathlib import Path
import difflib, hashlib, json, re, xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
FILES = ['src/compute_provider_flashinfer/flashinfer_provider.cc',
         'tests/compute_provider_flashinfer/CMakeLists.txt',
         'tests/compute_provider_flashinfer/gqa16_test.cc']

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
def ident(p):
    p = Path(p).resolve(); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

diff = ''
for name in FILES:
    current = (ROOT/name).read_bytes()
    target = OUT/'candidate'/name
    target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(current)
    before = OUT/'before'/name
    old = before.read_text(encoding='utf-8-sig').splitlines(keepends=True) if before.exists() else []
    diff += ''.join(difflib.unified_diff(old, current.decode('utf-8-sig').replace('\r\n', '\n').splitlines(keepends=True),
        fromfile='before/'+name if before.exists() else '/dev/null', tofile='candidate/'+name))
(OUT/'source.diff').write_text(diff, encoding='utf-8', newline='\n')
save('source-identities.json', [ident(ROOT/name) for name in FILES])
for name in ['test', 'old', 'current']:
    frozen = read(OUT/(name+'-identity.json'))
    assert ident(frozen['source']['path']) == frozen['source']
    assert ident(frozen['object']['path']) == frozen['object']

old = ET.parse(OUT/'old-tests.xml').getroot()
new = ET.parse(OUT/'current-tests.xml').getroot()
assert int(old.attrib['tests']) == 2 and int(old.attrib['failures']) == 2
assert int(new.attrib['tests']) == 3 and int(new.attrib['failures']) == 0
commands = read(OUT/'commands.json')
current_log = OUT/next(r['stdout'] for r in reversed(commands) if r['tag'] == 'current-tests')
checks = re.findall(r'GQA16 (Direct|Graph) (paged|ragged) (F16|BF16) phase=(\d) maxAbs=([\d.e+-]+) budget=0.007', current_log.read_text())
assert len(checks) == 24
max_errors = {dtype: max(float(row[4]) for row in checks if row[2] == dtype) for dtype in ['F16', 'BF16']}
six = re.findall(r'GQA6 (Direct|Graph) (paged|ragged) (F16|BF16) phase=(\d) maxAbs=([\d.e+-]+) budget=0.007', current_log.read_text())
assert len(six) == 6
owners = [line for line in (OUT/'current.map').read_text(errors='replace').splitlines()
          if ('@native@flashinfer@compute@hyle@@' in line and
              any(name in line for name in ['run_batch', 'plan_batch', 'run_cache_batch', 'query_batch_workspace']))]
assert owners, 'Need actual selected native math owners'
save('native-math-owners.json', owners)
save('summary.json', dict(
    finding='Qwen3.8-2.4T QH64/KVH4/D256 batch ratio16 was rejected by the CUDA host qualifier',
    source_facts=['docs/implementation/tasks/compute/llm-moe-model-sources.json',
        'tests/compute_models/d5_qwen38_24t_fixture.h'],
    fallback='BatchProgram selects the original native BatchPlanning extension; its qualification error has no automatic materialized fallback. Ordinary SDPA is a different expression and does not establish typed batch support.',
    change='Remove the historical GQA ratio enumeration. Existing positive/divisible head schema and real dtype/depth/stride/offset/planner/workspace constraints now determine support. Generalize the original uint32 query/ragged tensor bound to lower head depths. No CUDA/native math, public schema or Graph special case changes.',
    before=dict(tests=2, failures=2, direct='Unimplemented: FlashInfer batch domain is not qualified',
        graph='node0 ragged-attention: no available operation or region implementation',
        limitation='Each test stops at its first F16 ragged rejection; other old combinations were not run'),
    current=dict(tests=3, passed=3, independent_numerical_checks=30, ratio16_checks=24, ratio6_controls=6,
        routes=['default CUDA Direct', 'ordinary Graph with OperationFallbackPolicy::kReject'],
        geometry='H64/KV4/D256; two unequal requests; actual Q/K/V payloads',
        phases=['Q1+3/KV17+31', 'Q2+1/KV19+32', 'Q1+1/KV20+33'],
        storage=['ragged', 'paged16 with actual nonsequential physical page IDs and tails'],
        dtypes=['F16', 'BF16'], original_absolute_budget=0.007, max_absolute_errors=max_errors,
        old_output='Two original slots; prior output bytes checked after the other slot runs; first slot reused for decode',
        capacity_bounds='Two descriptor-only excessive lower-depth query/ragged capacities return OutOfRange before payload allocation',
        logical_cache_prefix='Each request retains its old logical K/V values while growing/repacking',
        inactive_cache='Unselected rows and unused final page rows are NaN; active outputs must remain finite'),
    compilation='One permanent test TU and one FlashInfer host TU, incrementally recompiled while finalizing source; no CUDA TU, shader, SDK or dependency rebuild',
    fixture_failure='The first added capacity-bound assertions used default system host_workspace and met earlier CUDA resource rejection. Corrected to the same pinned host resource used by numerical cases; the original failure log remains.',
    limitations=['Windows RTX4070 SM89 only', 'No complete-model weights/logits or throughput result',
        'No new FP8-cache, sliding-window, split/capture or pending/failure-domain acceptance',
        'The exact original native math objects/libraries and source provenance are inherited from the resolved current CUDA closure'],
    final_provider=read(OUT/'current-identity.json'),
    sources=[ident(ROOT/name) for name in FILES], cleanup_performed=False))
print(json.dumps(dict(sources=[ident(ROOT/name) for name in FILES], max_absolute_errors=max_errors), indent=2))
