from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
SOURCES = [
    'src/compute_provider_cuda/row_cache_indexer_provider.h',
    'src/compute_provider_cuda/row_cache_indexer_provider.cc',
    'src/compute_provider_cuda/row_cache_indexer_kernel.h',
    'src/compute_provider_cuda/row_cache_indexer_kernel.cu',
    'src/compute_provider_cuda/row_cache_kernel.h',
    'src/compute_provider_cuda/row_cache_kernel.cu',
    'src/compute_provider_cuda/cuda_provider.cc',
    'src/compute_provider_cuda/CMakeLists.txt',
    'tests/compute_provider_cuda/row_cache_indexer_test.cc',
    'tests/compute_provider_cuda/CMakeLists.txt',
]
SUPPORT = ['include/hyle/compute/model_ops.h','tests/compute_models/row_cache_indexer_fixture.h',
           'tests/compute_models/row_cache_fixture.h','src/compute_provider_cuda/tensor_kernel.h',
           'src/compute_provider_cuda/reduction_kernel.h']

def main():
    applied=OUT/'applied'
    identities=[]
    diff=[]
    for name in SOURCES+SUPPORT:
        source=ROOT/name;target=applied/name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(source.read_bytes())
        identities.append(dict(path=name,bytes=source.stat().st_size,sha256=sha(source)))
        if name in SOURCES:
            before=OUT/'before'/name
            old=before.read_text().splitlines(True) if before.exists() else []
            diff += list(difflib.unified_diff(old,source.read_text().splitlines(True),fromfile='before/'+name,tofile='applied/'+name))
    (OUT/'source-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
    (OUT/'source.diff').write_text(''.join(diff))
    (OUT/'hardware.json').write_text(json.dumps(dict(command=['nvidia-smi','--query-gpu=name,driver_version,memory.free,compute_cap','--format=csv,noheader'],stdout='NVIDIA GeForce RTX 4070, 617.14, 9001 MiB, 8.9\n',note='Read before this functional run; no clocks/power/environment changed.'),indent=2)+'\n')
    records=json.loads((OUT/'commands.json').read_text())
    final=next(x for x in reversed(records) if x['tag']=='test' and x['exit']==0)
    summary=dict(
        status='implemented; focused functional checks passed; not committed',
        operation='model_ops::RowCacheIndexerScores; BF16[T,64,128], U8[L,68], BF16[T,64], I32[T,2] -> F32[T,L]',
        route='Default cuda::create_context -> cuda_native provider kRoute 11; Direct and default Graph scores->Neg',
        algorithm='Union-active 256-key FP4 decode tile; original cuBLASLt BF16 inputs/F32acc/BF16 output; existing BF16 ReLU/Multiply/F32acc head-reduce; gated F32 publish. One public submit and one SharedQueue, no per-tile host wait/D2H or whole-history decode.',
        numerical='F32acc dot -> BF16 -> ReLU -> BF16 product -> F32acc head sum -> BF16 -> F32. Shared independent FP64/BF16-RNE fixture; EXPECT_FLOAT_EQ all output entries, adjacent BF16 results cannot pass. No tolerance/input changes.',
        tests=dict(passed=5,total=5,new_indexer=3,existing_codec_regressions=2,
                   controls=['T3/L513 two phases, tile256+256+1, two invocation slots, same-slot repeat, old-output retention',
                             'Odd-byte packed bank origin; device-resident ranges and status; invalid last range keeps all caller output unchanged and reports OutOfRange',
                             'Default public Graph scores+Neg both published, two slots/phases, independent oracle',
                             'All empty intervals with NaN-coded unused bank; L0 nonempty ranges invalid; T0 no-op'],
                   final_stdout=final['stdout'],final_stderr=final['stderr']),
        resources=dict(keytile=256,caller_workspace_per_slot_bytes=165632,
                       breakdown=dict(decoded_keys=65536,bfloat_dots=98304,bfloat_sums=1536,active_keys=256,lt_workspace_observed=0),
                       workspace_alignment=256,maximum_configured_lt_workspace_bytes=33554432,
                       persistent_bytes=None,invocation_private_bytes=None,
                       notes='Vendor descriptor/handle/internal allocations remain unknown. Output scores T*L is caller-required payload. Workspace grows by T*min(L,256), not full decoded L*128; no private T*L output scratch.'),
        error_contract='All ranges validate on device before any output write. Invalid range preserves complete operation caller output. Other CUDA/vendor failures retain accepted-prefix owners and terminal outputs are unreadable; no added universal atomic-publication promise.',
        bounds='Exact plain dense schema. T<=INT32_MAX/64, L<=INT32_MAX, T*64*min(L,256)<=INT32_MAX for mature tensor/reduce launch fields. Per-address/row offsets use size_t/uint64. Empty T/L supported.',
        build='Two new/rebuilt tiny CU (indexer range/active/publish and factored original row codec), two host TUs (indexer bridge and cuda delegate), one new test TU. Existing Lt/tensor/reduce, full default roster and Graph host objects reused; exact commands and all input binary hashes recorded. No SDK rebuild.',
        failures_retained=['GraphBuilder custom invocation compile misuse corrected without numerical/input changes',
                           'First link replacement matched another cuda-provider.obj basename; corrected to exact source-cache directory',
                           'First executable launch 0xC0000135: DLL runtime PATH incomplete; repaired only runtime library directories',
                           'First EmptyIntervals test threw Bad expected access: caller workspace omitted in test; supplied declared workspace'],
        applied_difference='Five newly written source/test files clang-formatted after successful run. tested-to-applied.json confirms comments/whitespace only; exact tested originals and object hashes retained. No repeated run for formatting.',
        limits=['Only Windows RTX4070 SM89/CUDA13.3/MSVC14.50 exercised; no Linux/other SM performance claim',
                'CUDA capture compatibility follows existing Lt/shared-status contract but separate capture replay not exercised here',
                'No throughput/latency/peak measurement or full model run',
                'Runtime instantiation may decline if Lt has no suitable native algorithm; no scalar GEMM fallback'],
        git_head_at_freeze=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    binary=[]
    for p in OUT.iterdir():
        if p.is_file() and p.suffix.lower() in ['.obj','.exe','.lib','.exp']:
            binary.append(dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p),suggested_action='retain current small object cache' if p.suffix=='.obj' else 'rebuildable; parent decides exact cleanup'))
    (OUT/'artifacts.json').write_text(json.dumps(binary,indent=2)+'\n')
    # Preserve the full map locally; the small archive records relevant symbol ownership.
    mapfile=OUT/'indexer-tests.map'
    lines=mapfile.read_text(errors='replace').splitlines()
    (OUT/'map-symbols.txt').write_text('\n'.join(x for x in lines if 'row_cache_indexer' in x or 'indexer-' in x)+'\n')
    (OUT/'map-identity.json').write_text(json.dumps(dict(path=str(mapfile.resolve()),bytes=mapfile.stat().st_size,sha256=sha(mapfile),note='Full map retained at path; task-symbol excerpt in package.'),indent=2)+'\n')
    archive=OUT/'source-results.zip'
    paths=[p for p in OUT.rglob('*') if p.is_file() and p.suffix.lower() not in ['.obj','.exe','.lib','.exp','.map','.zip'] and p.name!='package.json']
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(paths):z.write(p,p.relative_to(OUT))
    package=dict(path=str(archive.resolve()),bytes=archive.stat().st_size,sha256=sha(archive),members=len(paths))
    (OUT/'package.json').write_text(json.dumps(package,indent=2)+'\n')
    print(json.dumps(package,indent=2))

if __name__=='__main__':main()
