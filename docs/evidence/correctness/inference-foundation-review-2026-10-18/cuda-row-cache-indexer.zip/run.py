from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('hyle_build_env', ROOT / '.scratch/inference-feature-completion-2026-10-18/windows-batch/build_host.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []
def run(tag, command, timeout=180):
    command = list(map(str, command))
    index = len(records)
    start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=base.env, capture_output=True, timeout=timeout)
    stem = f'{index:02d}-{tag}'
    (OUT / (stem + '.stdout.log')).write_bytes(p.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag, command=command, cwd=str(ROOT), exit=p.returncode,
                        seconds=time.monotonic()-start, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log'))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(tag, p.returncode, round(records[-1]['seconds'], 3), flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-9000:])
        print(p.stderr.decode(errors='replace')[-3000:])
        raise SystemExit(p.returncode)
    return p

def host(source, name):
    flags = [*base.flags, '/I'+str(ROOT), '/W4', '/WX', '/wd4324',
             '/external:IC:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include']
    run(name+'-compile', [base.cl, *flags, ROOT/source, '/Fo'+str(OUT/(name+'.obj'))])

def kernel(source, name):
    source_commands = json.loads((ROOT / '.scratch/inference-fusion-quantization-2026-10-18/deepseek-packed-history/cuda/commands.json').read_text())
    old = next(x['command'] for x in reversed(source_commands) if x['tag']=='kernel-compile' and x['exit']==0)
    command = old[:]
    command[command.index('-c')+1] = str(ROOT/source)
    command[command.index('-o')+1] = str(OUT/(name+'.obj'))
    run(name+'-compile', command)

def link():
    all_commands = json.loads((ROOT / '.scratch/inference-foundation-review-2026-10-18/row-cache-pending-graph/commands.json').read_text())
    command = next(x['command'] for x in reversed(all_commands) if x['tag']=='cuda-pending-link' and x['exit']==0)
    replace = {'cuda-provider.obj':'delegate.obj', 'cuda-kernel.obj':'row-codec.obj'}
    old_tests = {'cuda-pending.obj', 'cuda-test.obj'}
    result = []
    for x in command:
        p = Path(x)
        if p.name in old_tests:
            continue
        if p.name in replace and p.parent.name=='row-cache-paged-reader':
            x = str(OUT/replace[p.name])
        if x.lower().startswith('/out:'):
            x = '/OUT:'+str(OUT/'indexer-tests.exe')
        elif x.lower().startswith('/map:'):
            x = '/MAP:'+str(OUT/'indexer-tests.map')
        result.append(x)
    result[1:1] = [str(OUT/(n+'.obj')) for n in ['indexer-provider','indexer-kernel','indexer-tests']]
    result[1:1] = [str(ROOT / '.scratch/inference-fusion-quantization-2026-10-18/deepseek-packed-history/cuda/tests.obj')]
    run('link', result)
    inputs = [Path(x) for x in result if Path(x).suffix in ['.obj','.lib'] and Path(x).is_file()]
    (OUT/'link-identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in inputs],indent=2)+'\n')

if __name__=='__main__':
    action=sys.argv[1]
    if action=='host':
        host('src/compute_provider_cuda/row_cache_indexer_provider.cc','indexer-provider')
        host('src/compute_provider_cuda/cuda_provider.cc','delegate')
        host('tests/compute_provider_cuda/row_cache_indexer_test.cc','indexer-tests')
    elif action=='kernels':
        kernel('src/compute_provider_cuda/row_cache_kernel.cu','row-codec')
        kernel('src/compute_provider_cuda/row_cache_indexer_kernel.cu','indexer-kernel')
    elif action=='test-tu': host('tests/compute_provider_cuda/row_cache_indexer_test.cc','indexer-tests')
    elif action=='link': link()
    elif action=='test':
        linked=next(x['command'] for x in reversed(records) if x['tag']=='link' and x['exit']==0)
        runtime=[str(Path(x).parent) for x in linked if x.endswith('.lib') and Path(x).is_absolute()]
        runtime += [str(base.TOOLKIT/'bin'),str(base.TOOLKIT/'bin/x64'),str(base.BASE/'bin')]
        base.env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+base.env['PATH']
        (OUT/'runtime-paths.json').write_text(json.dumps(list(dict.fromkeys(runtime)),indent=2)+'\n')
        run('test',[OUT/'indexer-tests.exe','--gtest_filter=CudaRowCacheIndexer.*:CudaRowCache.EncodesAndSelectsCanonicalRowsAcrossSlots:CudaRowCache.ScalarEmptyUncheckedAndIeeePayloadsKeepTheirContract','--gtest_break_on_failure=0'],120)
    else: raise ValueError(action)
