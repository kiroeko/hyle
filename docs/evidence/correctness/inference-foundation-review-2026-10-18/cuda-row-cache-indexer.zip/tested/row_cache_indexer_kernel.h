#pragma once
#include <cstdint>
#include <cuda_runtime_api.h>

namespace hyle::compute::cuda_native::row_cache_indexer::native {
cudaError_t prepare() noexcept;
cudaError_t check_ranges(const std::int32_t *, std::uint32_t, std::uint32_t,
    unsigned *, cudaStream_t) noexcept;
cudaError_t active_keys(const std::int32_t *, std::uint32_t, std::uint32_t,
    unsigned, unsigned char *, const unsigned *, cudaStream_t) noexcept;
cudaError_t publish(const void *, const std::int32_t *, std::uint32_t,
    std::uint32_t, std::uint32_t, unsigned, float *, const unsigned *, cudaStream_t) noexcept;
}
