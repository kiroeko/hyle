#include "row_cache_indexer_provider.h"
#include "hyle/compute/model_ops.h"
#include "native_context.h"
#include "row_cache_indexer_kernel.h"
#include "row_cache_kernel.h"
#include "tensor_kernel.h"
#include "reduction_kernel.h"
#include <cublasLt.h>
#include <algorithm>
#include <array>
#include <climits>

namespace hyle::compute::cuda_native::row_cache_indexer {
namespace {
namespace ops = cuda_native::native;
constexpr unsigned kTile = 256;
constexpr std::size_t kAlignment = 256, kLtLimit = 32u << 20;
constexpr ProviderRuntimeProperties kRuntime{
    .mode = ProviderRuntimeMode::kSharedQueue,
    .workspace_owner = ProviderWorkspaceOwner::kCaller,
    .replay_class = ProviderReplayClass::kPrepared,
    .blocks_host = false,
    .uses_private_threads = false,
    .supports_concurrent_invocations = true,
    .capture_compatible = true};
struct Shape final {
  unsigned tokens = 0, rows = 0, width = 0, tail = 0;
};
Status lt_status(cublasStatus_t code) noexcept {
  if (code == CUBLAS_STATUS_SUCCESS)
    return Status::Ok();
  const auto status =
      code == CUBLAS_STATUS_ALLOC_FAILED ? StatusCode::ResourceExhausted
      : code == CUBLAS_STATUS_NOT_SUPPORTED ||
              code == CUBLAS_STATUS_ARCH_MISMATCH
          ? StatusCode::Unimplemented
      : code == CUBLAS_STATUS_INVALID_VALUE ? StatusCode::InvalidArgument
                                            : StatusCode::Internal;
  return Status::FromNative(status,
                            NativeError{NativeErrorDomain::Unknown, code},
                            "row cache indexer cuBLASLt");
}
struct Part final {
  cublasLtMatmulDesc_t operation = nullptr;
  std::array<cublasLtMatrixLayout_t, 3> layouts{};
  cublasLtMatmulAlgo_t algorithm{};
  std::size_t workspace = 0;
  ops::TensorProgram relu{}, multiply{};
  ops::ReductionProgram sum{};
  ~Part() {
    for (auto x : layouts)
      if (x)
        (void)cublasLtMatrixLayoutDestroy(x);
    if (operation)
      (void)cublasLtMatmulDescDestroy(operation);
  }
};
struct Prepared final {
  CUcontext primary = nullptr;
  Shape shape;
  Part full, tail;
  std::size_t dots = 0, sums = 0, active = 0, lt = 0, bytes = 0;
};
struct Invocation final {
  CUcontext primary = nullptr;
  cublasLtHandle_t handle = nullptr;
  void *scratch = nullptr;
};
struct Cold final {
  cublasLtHandle_t handle = nullptr;
  cublasLtMatmulPreference_t preference = nullptr;
  ~Cold() {
    if (preference)
      (void)cublasLtMatmulPreferenceDestroy(preference);
    if (handle)
      (void)cublasLtDestroy(handle);
  }
};
std::size_t aligned(std::size_t n) {
  return (n + kAlignment - 1) & ~(kAlignment - 1);
}
Result<Shape> select(Operation operation, std::span<const TensorDesc> in,
                     std::span<const TensorDesc> out) noexcept {
  if (!operation.custom_as<model_ops::RowCacheIndexerScores>())
    return std::unexpected(
        Status::Unimplemented("CUDA packed indexer operation differs"));
  std::array<TensorDesc, 1> inferred;
  HYLE_RETURN_IF_ERROR(infer_output_descriptions(operation, in, inferred));
  if (out.size() != 1 || out[0] != inferred[0])
    return std::unexpected(
        Status::InvalidArgument("CUDA packed indexer output differs"));
  const auto t = std::uint64_t(in[0].dimensions()[0]),
             l = std::uint64_t(in[1].dimensions()[0]);
  const auto width = (std::min)(l, std::uint64_t{kTile});
  // Match the original GEMM/tensor/reduction launch metadata, not a packed-bank
  // size product.
  if (t > INT32_MAX / 64 || l > INT32_MAX ||
      (width && t > std::uint64_t(INT32_MAX) / (64 * width)))
    return std::unexpected(Status::Unimplemented(
        "CUDA packed indexer tile exceeds native integer fields"));
  return Shape{unsigned(t), unsigned(l), unsigned(width),
               width ? unsigned(l % width) : 0};
}
Status configure(Part &p, Cold &cold, unsigned tokens, unsigned width) {
  HYLE_RETURN_IF_ERROR(lt_status(
      cublasLtMatmulDescCreate(&p.operation, CUBLAS_COMPUTE_32F, CUDA_R_32F)));
  const std::uint64_t m = std::uint64_t(tokens) * 64;
  HYLE_RETURN_IF_ERROR(lt_status(
      cublasLtMatrixLayoutCreate(&p.layouts[0], CUDA_R_16BF, m, 128, 128)));
  const auto row = CUBLASLT_ORDER_ROW;
  HYLE_RETURN_IF_ERROR(lt_status(cublasLtMatrixLayoutSetAttribute(
      p.layouts[0], CUBLASLT_MATRIX_LAYOUT_ORDER, &row, sizeof(row))));
  HYLE_RETURN_IF_ERROR(lt_status(
      cublasLtMatrixLayoutCreate(&p.layouts[1], CUDA_R_16BF, 128, width, 128)));
  HYLE_RETURN_IF_ERROR(lt_status(cublasLtMatrixLayoutCreate(
      &p.layouts[2], CUDA_R_16BF, m, width, std::int64_t(m))));
  cublasLtMatmulHeuristicResult_t result{};
  int count = 0;
  HYLE_RETURN_IF_ERROR(lt_status(cublasLtMatmulAlgoGetHeuristic(
      cold.handle, p.operation, p.layouts[0], p.layouts[1], p.layouts[2],
      p.layouts[2], cold.preference, 1, &result, &count)));
  if (count != 1)
    return Status::Unimplemented("cuBLASLt found no BF16 indexer tile");
  HYLE_RETURN_IF_ERROR(lt_status(result.state));
  p.algorithm = result.algo;
  p.workspace = result.workspaceSize;
  // Column-major GEMM output is physical [key, token, head]. Head reduction
  // is contiguous; no transpose or complete-history decode is introduced.
  ops::TensorLayout layout{};
  layout.elements = tokens * 64 * width;
  layout.rank = 3;
  layout.dimensions[0] = width;
  layout.dimensions[1] = tokens;
  layout.dimensions[2] = 64;
  layout.strides[0][0] = std::size_t(tokens) * 64 * 2;
  layout.strides[0][1] = 64 * 2;
  layout.strides[0][2] = 2;
  HYLE_RETURN_IF_ERROR(cuda::status(ops::tensor_prepare(
      ops::TensorKind::kRelu, ops::ElementType::kBFloat16,
      ops::ElementType::kBFloat16, 2, true, layout, &p.relu)));
  layout.strides[1][0] = 0;
  layout.strides[1][1] = 64 * 2;
  layout.strides[1][2] = 2;
  HYLE_RETURN_IF_ERROR(cuda::status(ops::tensor_prepare(
      ops::TensorKind::kMultiply, ops::ElementType::kBFloat16,
      ops::ElementType::kBFloat16, 2, false, layout, &p.multiply)));
  ops::ReductionLayout reduction{};
  reduction.rows = tokens * width;
  reduction.width = 64;
  reduction.rank = 3;
  reduction.axes = 1u << 2;
  reduction.dimensions[0] = width;
  reduction.dimensions[1] = tokens;
  reduction.dimensions[2] = 64;
  HYLE_RETURN_IF_ERROR(cuda::status(ops::reduction_prepare(
      ops::ElementType::kBFloat16, ops::ReductionKind::kSum,
      ops::ReductionMask::kNone, true, reduction, &p.sum)));
  return Status::Ok();
}
void destroy(void *state, mem::AllocatorRef a) noexcept {
  auto *p = static_cast<Prepared *>(state);
  cuda::detail::ScopedPrimaryContext scope(p->primary);
  a.destroy(p);
}
AliasSupport alias(void *, std::size_t, std::size_t) noexcept { return {}; }
Status create_invocation(void *state, mem::AllocatorRef a,
                         mem::BufferView workspace, void **output) noexcept {
  *output = nullptr;
  const auto &p = *static_cast<const Prepared *>(state);
  auto *slot = a.construct<Invocation>();
  if (!slot)
    return Status::ResourceExhausted("CUDA packed indexer invocation metadata");
  slot->primary = p.primary;
  *output = slot;
  if (!p.shape.tokens || !p.shape.rows)
    return Status::Ok();
  if (workspace.size() < p.bytes)
    return Status::InvalidArgument("CUDA packed indexer workspace too small");
  HYLE_ASSIGN_OR_RETURN(
      slot->scratch, cuda::detail::mutable_pointer(workspace, kAlignment, 1));
  cuda::detail::ScopedPrimaryContext scope(p.primary);
  HYLE_RETURN_IF_ERROR(scope.status());
  return lt_status(cublasLtCreate(&slot->handle));
}
void destroy_invocation(void *state, mem::AllocatorRef a) noexcept {
  auto *p = static_cast<Invocation *>(state);
  if (!p)
    return;
  cuda::detail::ScopedPrimaryContext scope(p->primary);
  if (p->handle)
    (void)cublasLtDestroy(p->handle);
  a.destroy(p);
}
detail::EnqueueResult submit(void *state, void *lane, Queue &queue,
                             std::span<const ConstTensorView> inputs,
                             std::span<const TensorView> outputs) noexcept {
  const auto &p = *static_cast<const Prepared *>(state);
  auto &slot = *static_cast<Invocation *>(lane);
  if (!p.shape.tokens)
    return detail::EnqueueResult::no_op();
  auto stream = cuda::stream(queue);
  if (!stream)
    return detail::EnqueueResult::rejected(stream.error());
  auto ranges = cuda::detail::const_pointer(inputs[3].storage(), 4, 1);
  if (!ranges)
    return detail::EnqueueResult::rejected(ranges.error());
  std::array<const void *, 3> source{};
  void *output = nullptr;
  if (p.shape.rows) {
    for (unsigned i = 0; i < 3; ++i) {
      auto x = cuda::detail::const_pointer(inputs[i].storage(),
                                           i == 0   ? 16
                                           : i == 1 ? 1
                                                    : 2,
                                           1);
      if (!x)
        return detail::EnqueueResult::rejected(x.error());
      source[i] = *x;
    }
    auto x = cuda::detail::mutable_pointer(outputs[0].storage(), 4, 1);
    if (!x)
      return detail::EnqueueResult::rejected(x.error());
    output = *x;
  }
  cuda::detail::ScopedPrimaryContext scope(p.primary);
  if (!scope)
    return detail::EnqueueResult::rejected(scope.status());
  unsigned *status = nullptr;
  auto initialized = cuda::detail::acquire_device_status(queue, &status);
  if (!initialized.status.ok())
    return initialized;
  // From this point even a status reset or failed vendor call may own a prefix.
  auto result = cuda::status(
      native::check_ranges(static_cast<const std::int32_t *>(*ranges),
                           p.shape.tokens, p.shape.rows, status, *stream));
  if (!result.ok() || !p.shape.rows)
    return detail::EnqueueResult::accepted_command(result);
  auto *base = static_cast<char *>(slot.scratch);
  auto *keys = base;
  auto *dots = base + p.dots;
  auto *sums = base + p.sums;
  auto *active = reinterpret_cast<unsigned char *>(base + p.active);
  void *lt = base + p.lt;
  const auto *intervals = static_cast<const std::int32_t *>(*ranges);
  for (unsigned begin = 0; begin < p.shape.rows; begin += p.shape.width) {
    const auto width = (std::min)(p.shape.width, p.shape.rows - begin);
    const auto &part = width == p.shape.width ? p.full : p.tail;
    result = cuda::status(native::active_keys(intervals, p.shape.tokens, begin,
                                              width, active, status, *stream));
    if (result.ok())
      result = cuda::status(row_cache::native::launch_float4_tile(
          static_cast<const char *>(source[1]) + std::size_t(begin) * 68,
          active, keys, width, status, *stream));
    const float alpha = 1, beta = 0;
    if (result.ok())
      result = lt_status(cublasLtMatmul(
          slot.handle, part.operation, &alpha, source[0], part.layouts[0], keys,
          part.layouts[1], &beta, dots, part.layouts[2], dots, part.layouts[2],
          &part.algorithm, lt, part.workspace, *stream));
    if (result.ok())
      result = cuda::status(
          ops::tensor_launch(part.relu, dots, nullptr, nullptr, dots, *stream));
    if (result.ok())
      result = cuda::status(ops::tensor_launch(part.multiply, dots, source[2],
                                               nullptr, dots, *stream));
    if (result.ok())
      result = cuda::status(
          ops::reduction_launch(part.sum, dots, nullptr, sums, *stream));
    if (result.ok())
      result = cuda::status(native::publish(
          sums, intervals, p.shape.tokens, p.shape.rows, begin, width,
          static_cast<float *>(output), status, *stream));
    if (!result.ok())
      return detail::EnqueueResult::accepted_command(result);
  }
  return detail::EnqueueResult::accepted_command(Status::Ok());
}
const detail::ProviderPreparedVTable kPrepared{
    .destroy_prepared = &destroy,
    .alias_support = &alias,
    .create_invocation = &create_invocation,
    .destroy_invocation = &destroy_invocation,
    .shared_submit = &submit};
} // namespace
Status propose(const detail::ProviderOperationRequest &r,
               std::span<detail::ResourceBindingRequirement> inputs,
               std::span<detail::ResourceBindingRequirement> outputs,
               detail::ProviderOperationProposal *out) noexcept {
  if (!r.shape.exact())
    return Status::Unimplemented("CUDA packed indexer needs exact shapes");
  HYLE_ASSIGN_OR_RETURN(auto shape, select(r.operation, r.inputs, r.outputs));
  (void)shape;
  if (!out || inputs.size() != 4 || outputs.size() != 1)
    return Status::InvalidArgument("CUDA packed indexer binding count differs");
  for (unsigned i = 0; i < 4; ++i)
    inputs[i] = {.required_properties = mem::MemoryProperty::kDeviceAccessible,
                 .minimum_alignment = i == 0   ? 16u
                                      : i == 1 ? 1u
                                      : i == 2 ? 2u
                                               : 4u};
  outputs[0] = {.required_properties = mem::MemoryProperty::kDeviceAccessible,
                .minimum_alignment = 4};
  *out = {.route = kRoute,
          .runtime = kRuntime,
          .workspace_resource = {.required_properties =
                                     mem::MemoryProperty::kDeviceAccessible,
                                 .minimum_alignment = kAlignment},
          .cost = {.workspace = std::nullopt,
                   .persistent_bytes = std::nullopt,
                   .copy_bytes = 0,
                   .repack_bytes = 0,
                   .synchronization_count = 0,
                   .dispatch_count = std::nullopt},
          .implementation = ProviderImplementationId{kRoute}};
  return Status::Ok();
}
ProviderPrepareOutcome prepare(void *state,
                               const detail::ProviderPrepareRequest &r,
                               mem::AllocatorRef a,
                               detail::ProviderPrepared *out) noexcept {
  *out = {};
  auto shape = select(r.operation, r.inputs, r.outputs);
  if (!shape)
    return shape.error().IsUnimplemented()
               ? ProviderPrepareOutcome::unsupported(shape.error())
               : ProviderPrepareOutcome::error(shape.error());
  auto *p = a.construct<Prepared>();
  if (!p)
    return ProviderPrepareOutcome::resource_declined(
        Status::ResourceExhausted("CUDA packed indexer metadata"));
  p->primary = static_cast<CUcontext>(state);
  p->shape = *shape;
  const auto setup = [&]() -> Status {
    cuda::detail::ScopedPrimaryContext scope(p->primary);
    HYLE_RETURN_IF_ERROR(scope.status());
    HYLE_RETURN_IF_ERROR(cuda::status(native::prepare()));
    if (!shape->tokens || !shape->rows)
      return Status::Ok();
    HYLE_RETURN_IF_ERROR(
        cuda::status(row_cache::native::prepare_float4_tile()));
    Cold cold;
    HYLE_RETURN_IF_ERROR(lt_status(cublasLtCreate(&cold.handle)));
    HYLE_RETURN_IF_ERROR(
        lt_status(cublasLtMatmulPreferenceCreate(&cold.preference)));
    HYLE_RETURN_IF_ERROR(lt_status(cublasLtMatmulPreferenceSetAttribute(
        cold.preference, CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES, &kLtLimit,
        sizeof(kLtLimit))));
    const std::uint32_t reduction = CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE,
                        alignment = 16;
    HYLE_RETURN_IF_ERROR(lt_status(cublasLtMatmulPreferenceSetAttribute(
        cold.preference, CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK, &reduction,
        sizeof(reduction))));
    for (auto attr : {CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_A_BYTES,
                      CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_B_BYTES,
                      CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_C_BYTES,
                      CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_D_BYTES})
      HYLE_RETURN_IF_ERROR(lt_status(cublasLtMatmulPreferenceSetAttribute(
          cold.preference, attr, &alignment, sizeof(alignment))));
    HYLE_RETURN_IF_ERROR(configure(p->full, cold, shape->tokens, shape->width));
    if (shape->tail)
      HYLE_RETURN_IF_ERROR(
          configure(p->tail, cold, shape->tokens, shape->tail));
    p->dots = aligned(std::size_t(shape->width) * 128 * 2);
    p->sums =
        aligned(p->dots + std::size_t(shape->width) * shape->tokens * 64 * 2);
    p->active =
        aligned(p->sums + std::size_t(shape->width) * shape->tokens * 2);
    p->lt = aligned(p->active + shape->width);
    p->bytes = p->lt + (std::max)(p->full.workspace, p->tail.workspace);
    return Status::Ok();
  }();
  if (!setup.ok()) {
    a.destroy(p);
    return setup.IsUnimplemented() ? ProviderPrepareOutcome::unsupported(setup)
                                   : ProviderPrepareOutcome::error(setup);
  }
  *out = {.vtable = &kPrepared,
          .state = p,
          .workspace = {.size = p->bytes, .alignment = kAlignment},
          .runtime = kRuntime,
          .persistent_bytes = std::nullopt,
          .invocation_private_bytes = std::nullopt};
  return ProviderPrepareOutcome::prepared();
}
} // namespace hyle::compute::cuda_native::row_cache_indexer
