from pathlib import Path
import json,hashlib,difflib,zipfile
R=Path.cwd();O=Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def write(name,x):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sources=[x['path']for x in json.loads((O/'baseline.json').read_text())]+['tests/graph_batch/row_cache_pending_graph_test.cc']
diff=[]
for name in sources:
 p=R/name;q=O/'applied'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
 old=O/'before'/name
 diff.extend(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(True)if old.exists()else[],p.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+name,tofile='applied/'+name))
(O/'source.diff').write_text(''.join(diff),encoding='utf-8')
write('source-sha.json',[dict(path=n,bytes=(R/n).stat().st_size,sha256=sha(R/n))for n in sources])
write('retain-objects.json',[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in O.glob('*.obj')])
write('deletable-artifacts.json',[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in O.iterdir()if p.suffix in {'.exe','.lib','.exp','.pdb'}])
unary=R/'.scratch/inference-fusion-quantization-2026-10-18/cuda-precise-unary'
for name in ['identity.json','compile-command.json','legacy-command.json','compile.stdout.log','compile.stderr.log','neg.sass.txt']:
 p=unary/name
 if p.exists():
  q=O/'precise-unary'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
write('dependency-identities.json',{
 'base_graph_package':'row-cache-paged-graph.zip SHA25612d9d22fada67907e6cb5f951e3f9552adff62d887a5e9db062acc2d320aca8d',
 'closure':'Replace its leased_invocation/batch/arena objects with the fresh three in this stage; reuse its node/test/other four current Graph PlanState consumers, CPU/CUDA Map+codec and original native runtimes. PlanState ABI unchanged. No joint-route TU linked.',
 'precise_unary_object':dict(path=str(unary/'unary-precise.obj'),bytes=(unary/'unary-precise.obj').stat().st_size,sha256=sha(unary/'unary-precise.obj')),
 'precise_unary_note':'Same original native unary source and matched common header; only remove legacy cache use_fast_math as current CMake precise-unary already requires. No product/native mathematical edits. Explicit object overrides original static library member.'})
write('summary.json',{
 'change':'Typed PagedRowCachePendingRead reuses the original pending frame and CopyBatchUpdate protocol. Graph PendingInvocation admits the original audited CPU/CUDA Map+checked codec. No new executor/Queue or whole-capacity lease.',
 'permissions':'Immutable exact physical pages/root/generation/initialized prefix; validate new logical-byte coverage before consuming update and again at lane admission. Reader lane is captured from exact qualified compiled decoder. Enqueue original resolved copy dependency before admitting ordered page reads. Aggregate owns original source/outcome and graph native uses through actual retirement.',
 'tests':{'CPU':'24-cpu-pending-test.stdout.log:7/7 PASS, includes ready TopK->Sink, new pending consumer and original five host pagination compatibility tests.',
 'CUDA':'27-cuda-pending-test.stdout.log:2/2 PASS, ready TopK->Sink and new pending consumer under actual default Graph context on RTX4070.',
 'new_cases':'Both FP8 584B and FP4 68B rows; four episodes for each backend: full2-row physical page4 or one-row tail page1 newly uninitialized. Other ready pages remain exact. Zero-query middle request, noncontiguous refs, original visible bounds. Device producer->F2->Graph decode->CastF32->Neg. Selected BF16, CastF32 and Neg uint32 bits all independently exact from frozen row oracle.',
 'CUDA_gate':'Warm original native kernels, block real producer host callback before H2D source write; submit returns with pending Completion, output/source controls and page reuse unavailable. Unused physical page2 remains reusable. Release gate, whole outputs pass, original producer use pool returns0.',
 'errors':'Different layout, wrong input port, invalid typed frame and rebind rejected. CPU incomplete new row missing final byte rejects OutOfRange before receiver consumption; original Update stays valid, original writer recovered then fully copied retry passes. Full and partial tail initialized prefixes published only after exact original writer recovery.',
 'lifetime':'Retained Graph result and its copy each prevent Update recovery; drop both then return source control, take_mutable original page writer and publish actual required1/2 rows. Ready frame validates afterward. Old pending frames cleared at next prepare. No abandonment/fault-injection claim for this new test.',
 'headers':'Both public paged_arena.h and graph/batch.h standalone MSVC W4/WX compile.',
 'build':'Fresh only three product host TUs, one new test per backend and two header probes; reuse original SDK/static closure. Canonical CMake target source lists updated, no new configure/full SDK build.'},
 'failures_retained':[
 'Test first used ambiguous Result={} reset; corrected to explicit Completion reset.',
 'Adding two ScopedTrace macros on one line collided on gtest __LINE__; split lines.',
 'New pending row initially reused two attention capacity.page_size reads. Row schemas intentionally expose invalid attention capacity(default16); FP4 required bytes truncated and incomplete-tail control exposed it. Both reads now use original BatchLayoutAccess::geometry page_size; not an old exposed product defect.',
 'Old cached native CUDA unary had use_fast_math; BF16 codec and widening were exact but Neg flushed subnormals. Publishing Cast isolated loss. Current canonical CMake already removes fast_math for unary; compiling exactly that original one TU with canonical flags fixed all rawbits. No new numerical product patch or relaxed oracle, no new defect count.'
 ],
 'costs':'Existing synchronous owned metadata mirror preparation and per-pending-bind lane metadata remain explicit cold costs. Selected output materializes only T*K rows. No zero-allocation, capture, total peak or throughput claim.',
 'limits':'CPU/CUDA ordinary carrier only. Native Apple/Vulkan, joint CPU+GPU journey, Direct pending reader, whole model/MTP engine and packed-indexer math remain outside this bounded new evidence.'})
excluded={'.obj','.exe','.dll','.lib','.exp','.pdb','.ilk','.o','.a','.pyc','.zip'}
z=O/'source-results.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED)as a:
 for p in sorted(O.rglob('*')):
  if p.is_file()and p.suffix.lower()not in excluded:a.write(p,p.relative_to(O).as_posix())
with zipfile.ZipFile(z)as a:assert a.testzip()is None
print(z,z.stat().st_size,sha(z))
