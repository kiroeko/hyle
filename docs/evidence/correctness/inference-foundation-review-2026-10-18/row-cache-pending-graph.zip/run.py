from pathlib import Path
import sys,json,os,importlib.util
R=Path.cwd();O=Path(__file__).resolve().parent;G=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-graph'
spec=importlib.util.spec_from_file_location('row_previous_build',G/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.O=O;b.records=json.loads((O/'commands.json').read_text())if(O/'commands.json').exists()else[]
if sys.argv[1]=='build':
 for src,name in [('src/graph/leased_invocation.cc','leased'),('src/graph_batch/batch.cc','batch'),('src/compute_batch/paged_arena.cc','arena')]:
  if len(sys.argv)==2 or name in sys.argv[2:]:b.compile(src,name)
else:
 backend=sys.argv[1]
 flags=[*b.flags]+(['/DHYLE_ROW_CACHE_GRAPH_CUDA=1','/DHYLE_COMPUTE_CUDA=1','/IC:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include']if backend=='cuda'else[])
 b.run(backend+'-pending-compile',[*flags,R/'tests/graph_batch/row_cache_pending_graph_test.cc','/Fo'+str(O/(backend+'-pending.obj'))])
 previous=json.loads((G/'commands.json').read_text());link=next(x['command']for x in reversed(previous)if x['tag']==backend+'-link'and x['exit']==0)
 arena=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages/paged_arena.obj'
 replace={str(G/'leased.obj'):str(O/'leased.obj'),str(G/'batch.obj'):str(O/'batch.obj'),str(arena):str(O/'arena.obj')}
 cmd=[replace.get(x,x)for x in link if not x.startswith(('/OUT:','/MAP:'))]
 if backend=='cuda':cmd.insert(1,str(R/'.scratch/inference-fusion-quantization-2026-10-18/cuda-precise-unary/unary-precise.obj'))
 cmd+=[str(O/(backend+'-pending.obj')),'/OUT:'+str(O/(backend+'-test.exe')),'/MAP:'+str(O/(backend+'-test.map'))]
 runtime=[str(R/'.scratch/build-compute-v2-dev/bin'),'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64']+[str(Path(x).parent)for x in cmd if x.endswith('.lib')and Path(x).is_absolute()]
 env=dict(b.env);env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
 b.run(backend+'-pending-link',cmd,env);b.run(backend+'-pending-test',[O/(backend+'-test.exe')],env)
