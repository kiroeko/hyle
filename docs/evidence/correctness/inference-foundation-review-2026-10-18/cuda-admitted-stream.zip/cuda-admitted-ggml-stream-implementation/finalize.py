from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
from run import OUT,ROOT,ARCH,base,read,save,ident

DEST=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/cuda-admitted-stream.zip'
original=ARCH/'qwen-progress-journey/trace-direct'
old={p.relative_to(original).as_posix():p for p in original.rglob('*') if p.suffix in {'.f32','.bf16'}}
assert len(old)==150
pairs=[]
for trace in ['trace','trace-final']:
 new={p.relative_to(OUT/trace).as_posix():p for p in (OUT/trace).rglob('*') if p.suffix in {'.f32','.bf16'}}
 assert old.keys()==new.keys()
 for name in sorted(old):
  a=ident(old[name]);b=ident(new[name]);assert a['sha256']==b['sha256'] and old[name].read_bytes()==new[name].read_bytes()
  pairs.append(dict(trace=trace,name=name,original=a,candidate=b,byte_equal=True))
save('trace-pairs.json',pairs)
tests=ET.parse(OUT/'tests.xml').getroot();assert tests.attrib['tests']=='10' and tests.attrib['failures']=='0'
compiled=[read(OUT/(name+'-identity.json')) for name in ['native','cuda_backend','cuda_device_status','cuda_memory','cuda_batch_transfer','provider','provider-test','retirement-test']]
for row in compiled:
 assert ident(row['source']['path'])==row['source']
 assert ident(row['object']['path'])==row['object']
 for h in row.get('headers',[]):assert ident(h['path'])==h
save('compiled-identities.json',compiled)
source_names=['src/compute_provider_ggml_cuda/native_bridge.h','src/compute_provider_ggml_cuda/native_bridge_impl.h',
 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/compute_backend_cuda/native_context.h',
 'src/compute_backend_cuda/cuda_internal.h','src/compute_backend_cuda/cuda_backend.cc',
 'src/compute_backend_cuda/cuda_memory.cc','src/compute_backend_cuda/cuda_batch_transfer.cc','src/compute_backend_cuda/cuda_device_status.cc',
 'tests/compute_backend_cuda/native_retirement_test.cc','tests/compute_backend_cuda/CMakeLists.txt',
 'tests/compute_provider_ggml_cuda/provider_test.cc','docs/architecture/compute-design.md','docs/developer/current-work.md',
 'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md','tools/qwen35_text/README.md','test.ps1']
for name in source_names:
 target=OUT/'final-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
save('final-source-identities.json',[ident(ROOT/n) for n in source_names])
maps={}
for name in ['before','qwen','tests']:
 rows=[line.rstrip() for line in (OUT/(name+'.map')).read_text(errors='replace').splitlines() if any(symbol in line for symbol in ['?compute_on_admitted_stream@','?initialize_backend@bridge','?defer_native_retirement@','?poll_slot@','?observe_native_retirement@'])]
 assert rows,name;maps[name]=rows
save('map-owners.json',maps)
for path in (OUT/'trace-final/routes').glob('*.route.tsv'):
 previous=ARCH/'strided-reshape/trace/routes'/path.name
 assert path.read_bytes()==previous.read_bytes(),path
bench=read(OUT/'benchmark.json');assert len(bench['phases'])==4 and all(p['observed_ranges_separate'] for p in bench['phases'])
for row in read(OUT/'benchmark-images.json'):assert ident(row['path'])==row
for name in ['before','qwen','tests']:
 for row in read(OUT/(name+'-link.json'))['inputs']:assert ident(row['path'])==row
images=[ident(p) for p in sorted(OUT.iterdir()) if p.suffix in {'.exe','.map','.exp','.lib'}]
baseline_native=[ident(ARCH/'generic-progress/ggml-cache/ggml-cuda.obj'),ident(ARCH/'cuda-sdpa-mask/diagmask-current.obj')]
save('cleanup-plan.json',dict(files=images+[r['candidate'] for r in pairs],retained_objects=[r['object'] for r in compiled],
 retained_trace=[ident(p) for p in old.values()],retained_native=baseline_native,other_cache_retained=True))
summary=dict(implementation=[
 'Original ggml CUDA invocation borrows the admitted QueueSequence stream; cuBLAS stream/workspace and the native stream table/current index restore on every path.',
 'No per-fragment entry/exit events and no unconditional private root stream creation. Original independent cold packing keeps native lazy stream creation.',
 'Failed auxiliary retirement is observed by one optional probe in the original CUDA EventSlot. Root fence and native prefix must both retire; original reaper retains attachments across wait observation errors, abandonment and close.',
 'Plain caller payload remains borrowed under its existing lifetime contract. Non-success auxiliary observations are conservatively unproved, including terminal device failures requiring process recovery.'
 ],verification=dict(focused_tests=10,failures=0,new_tests=4,final_full_qwen_trace_tensors=150,byte_equal=150,trace_bytes=62785536,
 graph='1878 nodes, 1204 steps; identical route and Graph workspace to the strided-layout baseline.',unique_compiled_tus=8,
 build='One original native main TU plus four affected backend host TUs, provider host and two test TUs. Cached numerical kernels/SDK reused. Native C4819 header warnings preserved under original flags; Hyle host compilation /W4 /WX.',
 native_failure_limit='No real auxiliary drain or cuBLAS-restore fault injection. Deferred retirement ownership is independently tested with actual root fence plus controlled nonretired/observation-error probe; capture and controlled GPU pending are exercised.'),
 benchmark=bench,numerical_next=read(ARCH/'qwen-numerical-next/review.json'),
 limits=['No scheduler rerun or new Linux/Apple/Vulkan full-model journey.',
  'Independent-oracle approximately 2% logits discrepancy remains unaccepted. RoPE/eager-attention BF16 intermediate boundaries differ; next experiment uses candidate real inputs.',
  'Short-request timing stops at ordinary EOS after decode2. No sustained warm-decode, llama.cpp, whole-device memory or power conclusion.'],
 investigation=['First new fixture requested plain MatMul from ggml-only provider, which is outside its actual domain; replaced the fixture with supported F32 SDPA to exercise native cuBLAS. No production capability expanded to satisfy a test.',
  'Initial fixture compilation needed explicit Operation at the general span API and explicit contained Completion reset; diagnostics retained.',
  'Benchmark initially assumed six generated tokens; ordinary EOS correctly stopped both implementations after three IDs. Measurement captions and parser were corrected; no EOS override or model change.'])
save('final-summary.json',summary)
excluded={'.obj','.exe','.map','.lib','.exp','.pdb','.pyc','.f32','.bf16','.zip'}
paths=[p for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix.lower() not in excluded]
paths += [ARCH/'qwen-numerical-next/review.json']
assert not DEST.exists(),'Do not overwrite evidence'
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in paths:z.write(path,path.relative_to(ARCH).as_posix())
with zipfile.ZipFile(DEST) as z:assert z.testzip() is None
receipt=dict(archive=ident(DEST),entries=len(paths),files=len(images)+len(pairs),bytes=sum(r['bytes'] for r in images)+sum(r['candidate']['bytes'] for r in pairs),retained_objects=8,retained_original_trace=150)
save('archive-receipt.json',receipt)
results=dict(archive=dict(path=DEST.relative_to(ROOT).as_posix(),bytes=receipt['archive']['bytes'],sha256=receipt['archive']['sha256']),**summary,
 cleanup_plan=dict(files=receipt['files'],bytes=receipt['bytes'],retained_objects=8,retained_original_trace=150,script='test.ps1 -ReclaimCudaAdmittedStream'))
DEST.with_name('cuda-admitted-stream-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
