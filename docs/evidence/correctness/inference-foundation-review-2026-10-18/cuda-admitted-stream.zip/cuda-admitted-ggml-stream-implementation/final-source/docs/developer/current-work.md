# 当前工作主线

2026-10-17，用户明确以下八项工作；后续按用户选择推进。
本页记录任务与范围，不引入状态机、审批、预算或新的开发门禁。

1. 已删除旧治理工具、状态源、审批与资格流程，精简相关说明；保留实际构建、数值、资源寿命和并发回归。
2. 删除、合并、简化文档，减少重复和失效规则，保留有用的设计依据与历史源码、日志、数据。
   已按“首次构建→接入 C++→按任务查模块”重排入口，保留四层分工；共用合同集中说明，
   复杂边界保留示例与反例，过程卡与过时规则已清理。入口见[文档导航](../README.md)。
3. 提供统一初始化入口，在受支持系统上用简单参数配置编译环境，复用工具链与依赖缓存。
   2026-10-18 已统一为 `scripts/init.py`、`build.py`、`test.py`：自动发现工具链，按后端与产品
   准备依赖，支持配置切换、增量构建和安装；基础系统工具仍按平台正常安装。用法见[初始化指南](setup/README.md)。
4. 检查 Compute/Graph 的公共 C++ 接口是否符合推理引擎调用需要，包括易用性、一致性、布局
   转换及暴露给用户的内部 CMake 变量和宏。不按旧六问重新审核全项目。
   构建系统已完成路线、依赖、target 宏与资源装配的统一，见[构建设计](../architecture/build-system.md)。
   2026-10-18 已静态核对四条后端路线及三种 CPU＋GPU 桥接的公开头、所属 target、能力宏和安装闭包，
   普通消费者仍只链接产品 target；本轮未重跑跨平台交付构建。已移除 direct submit 的双输出位置歧义，
   多输出改用既有 span 入口；禁止租约绑定借用临时 writer，并明确各 owner 的 drain 是否永久关闭接纳。
   同步修正独立 runtime 的公开 prepare 入口及初始化后端选择说明。
5. 狩猎剩余性能输项；只要确认超出仪器分辨率与测量噪声，即使差距小也继续调查。
   2026-10-18 全模块首轮调研及当前优化见[性能清单](../evidence/performance/library-review-2026-10-18/README.md)。
   先排除不同工作与过期实现，再处理真实复杂度问题；历史小输与当前待测项分开记录。
6. 尽快完成独立的 Qwen3.5-2B 纯文本、无 MTP、无多模态、完整 CUDA C++ 推理消费者，
   在同系统、同设备、同源权重与匹配精度/输入条件下对比 llama.cpp 的 prefill/decode tokens/s。
   通过实际调用发现接口、布局、状态管理和执行成本问题，不把外部参考或片段算作完整引擎。
7. 补全 MTP 所需的底座能力与真实消费者验证。
   2026-10-18 本轮补全 GDN 接受前缀快照、融合 recurrent 多 token 输入、页失败后的安全重试，
   并扩展公共状态消费者；用法与引擎边界见[状态版本](../user/state-versions.md#mtp-接受前缀并继续计算)。
8. 补全多模态所需的底座能力与真实消费者验证，优先图像 encoder/projector（mmproj）链路。

## 当前重构主线

2026-10-18，当前主线调整为 Compute/Graph 推理执行架构的设计与全量重构。
先把整体调用链和所有权设计清楚，再纵向迁移实现；目标同时包括算子自然扩展、推理全过程衔接和性能。
目标架构、动态变化边界、迁移次序与完成条件集中在[推理执行体系的重构形状](../architecture/compute-design.md#推理执行体系的重构形状)，
本页不另复制一套设计。

- 统一模型语义图、冷编译、不可变计划、独立执行槽、prepare/layout 更新与严格 submit；普通引擎中间层
  不判断平台、Provider 或原生算子，同一后端的承载事实供 Direct/Graph 共用。
- 纳入原生生成结果的真实所有权，收拢计划、执行槽和退休；保留 caller-buffer 快路径、原生融合与异步进度。
- 贯通 prefill、cached continuation、decode、多请求、页与状态反馈，以及已有分支/接受前缀、失败/重试/关闭能力；
  同时消除具体 op/Provider 在共同资源核心中的特殊判断。
- 以性能约束架构：路由和规划冷生成，动态变化有明确准备边界；追查重复分配、转换、上传、搬运、host 等待及
  时间/空间复杂度问题。单 GPU 不强制 CPU 数学 Context 或额外调度运行时，必要原生开销如实保留并报告。
- 独立 Qwen3.5-2B 文本 CUDA 消费者尽早贯穿新主链，作为实际接口与性能反馈；多模态模型接线和完整 MTP 引擎
  政策不在本 goal 内，其已有底座能力不得退化。普通 API、构建依赖与文档随迁移收拢，不增加治理或繁复验证。
  该引擎是架构测试产物，用真实模型推理发现并回修底座 gap，不作为正式推理引擎产品扩张。

当前普通调用链已回到一份Graph计划与原Invocation：

- Direct/Graph共用实际承载分析；selected prepared说明端口、输出表示、阻塞与资源事实。
  共同核心核依赖、权限、alias和寿命，不再为具体row-cache算子或Provider复制准入名单。
- ExecutionSource保活真实Context/Runtime，QueueRef/QueueSequence负责真实队列身份与本次接纳；
  SubmissionCursor按原依赖的O(S+E)前沿推进。可选prepare_progress只驱动该游标，阻塞粗片段交原BlockingPool。
- caller输出与Apple/Vulkan生成结果共用GraphOutput及退休合同；跨存储搬运使用实际CopyRecording。
  finite family、canonical常量与冷packing共享原制品，可变bindings、workspace、layout与结果代际归独立槽。
- typed WeightBatch、ready/pending分页与状态控制附着原Invocation；owned layout区分Q活动行与KV容量。
  GQA三载荷、MLA两载荷不再要求引擎装配另一套batch Provider或专用协调器。

CPU＋CUDA旧运行时以及CPU＋Apple/Vulkan旧Plan、Invocation、driver均已归档删除，不保兼容入口。
CUDA仅保留冷环境helper；三条混合路线的权重、custom/finite、effects、pipeline和分页消费者复用普通入口。
本批实际Windows/Vulkan与MacBook Air/Apple检查包括64轮页消费、双槽与旧结果、D512/576 MLA、
真实多源pending及取消/关闭/abandon；冷OOM逐点检查没有放宽原数学预算。具体范围见[证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。

真实消费者修出的共同问题包括：ready同布局帧替换缺失、pending冷准备半提交、drain遗漏observer回调尾部，
以及metadata分配失败被误当成可换路由的资源拒绝。已修复并保留对应失败恢复控制。
设备差异继续留在真实适配处：Vulkan固定backing的逃逸结果阻止复用，Apple独立生成Array可跨后续准备保活；
Scheduler空闲不等于GPU退休，取消须显式请求，close只停止接纳，drain等待实际完成。

性能尚未完成收工：Scheduler每轮task/stack仍有原有成本；native metadata镜像容量与必要上传保留，
Apple变KV布局仍可能构建eager数组图，不能宣传零热分配或全部数学域覆盖。
低维vector两pass现沿原MLX统一F32 partial、保最终dtype，删除架构后缀精度预测和默认Graph的低精度拒绝分支；
普通GQA也已修复跨batch KV基址遗漏。Air新4项通过，覆盖Direct/普通Graph、F16溢出与BF16抵消、
两槽旧结果、ragged和one-pass/full邻接及非零Q/K的B2消费。原数学控制明确失败，未放宽原容差。
同一旅程修复了分页Graph封存前遗漏释放内部已完成结果owner的问题，原生读者与公共旧结果gate保留。
F16/BF16 partial载荷从2B变4B，原Q/K/V存储不扩大；未测新吞吐或总显存峰值。
可选IO已收拢为显式 `compute_stream` 服务产品，默认Compute/Graph不带IO；四个薄桥接复用真实copy program，
CPU/CUDA文件搬运不要求数学Provider。已修复写回引用阻止读范围回收及GPU源producer观察问题；
Windows CPU14/14、Vulkan5/5、CUDA7/7及Air6/6通过，纯CPU shared安装/查包与独立file/mapping字节往返样例通过。
可选主机推进也已改为显式`graph_progress`服务产品；普通Graph不因同时安装Scheduler而带入该服务。
安装元数据静态/共享隔离夹具通过，复用原缓存增量13个TU、2个DLL的shared服务安装及独立消费者通过；
这只验证服务交付，不代签完整数学SDK。
CPU默认Direct/Graph已共用原Provider装配，同一ggml实例承载普通操作和region；6项定向回归保原偏好、数值及寿命。
冷编译的静态placement与coverage事实现每compile准备一次，实际资源权限与制品回滚仍逐attempt核对；
4项原重试/预算/OOM控制通过，Air复用原CPU→Apple→CPU双槽64轮消费者通过。
共同冷编译文件的其余职责仍按实际链路收敛，不增加转发层或第二套核心状态。
后续实测修复了可选原地写遗漏同存储View读者、已发布私有View被改写及跨lane只凭节点序号复用的问题。
冷编译先建立必须别名、汇总组寿命，再复用原segment依赖证明所有读者先于写；同lane原地快路径保留。
新4项及原重试/预算/OOM4项共8/8通过，修前数值与偏序反例保留；未新增热路径分析或Plan/Invocation字段。
Vulkan分页seal也已释放内部已完成结果后才过原reuse gate；新core与该修复合跑CPU/Vulkan Q18/Q2/Q0、
双槽和旧结果保护通过。上述均非新整模型数值或性能验收。
不可变输入source重准备现复用原槽的两个整数scratch容器；固定source、轮换普通绑定的4个观测轮次，
原12次metadata分配降为0，仍逐次重核route；连同原pending/失败控制4/4通过，非整次运行零分配声明。
Vulkan typed BF16已接原FullF32 flash逐tile读cache与最终原IREE RNE Cast；D256 plain分页/ragged及Q8、
紧凑MLA576→512的Direct/普通Graph双槽新2项通过，原F16低/高维与Q8三项正控保持。多request保持F32
至拼接完成后只转换一次；随后解耦现有F16/BF16 Q、成对KV与output轴，三种mixed组合及原控制共6/6通过，
含双槽、固定绑定重放和空输出；没有整KV宽化或新shader，未测pending精度、吞吐或整模型。

默认CUDA普通四口SDPA已接通dense F32 additive mask，沿原ggml F32程序与query分块；
同时修正原CUDA因果mask减FLT_MAX无法排除未来正无穷的问题。默认Direct/Graph新4项及原无mask回归共5/5通过，
原CU同用例失败对照保留；没有新增Graph特殊判断或融合/吞吐结论。

完整Qwen3.5-2B CUDA测试消费者已执行24层的23-token prefill→4-token续算→1-token decode，
此前已接现有可选进度驱动：direct与scheduler两模式各完整执行，150个观察tensor彼此及与上一冻结结果均逐字节相同。
别名寿命/InputSources更新后的direct重放仍逐字节相同。随后从实际Q/K/V切片补通用strided零拷贝reshape，
只在无法表达的flatten及caller固定输出保留Copy；当前direct三phase共150个tensor仍逐字节相同，
Copy节点85→25、报告步骤1252→1204，workspace略增；未重跑scheduler或据单次计时接受吞吐。
随后ggml CUDA直接借用本次Queue stream，删除逐片段双event桥及无条件私有root stream；失败辅助工作
在原CUDA EventSlot保留独立退休证明，观察错误/abandon继续由原reaper保活。新4项及原6项定向检查共10/10通过，
最终完整旅程150个tensor仍逐字节相同。同条件旧新各3次短请求，首decode中位33.59→20.27ms，
样本区间不重叠；正常EOS在第二decode结束，尚非持续warm decode或llama.cpp对照。
Model显式drain原槽后才结束runtimes、释放状态；共享tokens/KV/state仍须顺序evaluate，不推导同Model并发。
实际`rms_norm_f32<1024,true,false>`的归约mean与已保存Torch variance在首传播点差2个F32 ULP，
原拓扑重演和后续F32两乘解释该BF16中点分歧；Cast符合RNE，未改产品数学或容差。
单norm诊断另编原CU控制/插桩各一次，保留FFMA观测扰动和Torch中间仅离线推演的限制，不是重建SDK。
这不证明完整24层约2%的logits差异均同源；数值接受、公平tokens/s及Linux新旅程仍未完成。
新只读核对确认Torch eager与当前RoPE/attention的BF16中间舍入边界不同；下一步以首个full-attention
层的候选真实输入做同输入重放，区分精度求值差异与数学接线问题，不改变接受预算。

后续继续按既定8模型/22制品范围补原功能审查遗留，核对融合、量化接线、状态/接受前缀、稀疏分页与连续推理旅程。
架构迁移不等于功能完成，此前约75%仅是旧审查的粗估，不作为当前完成比例。

## 已确认范围

- 用户决定 G04/G05 先视为解决；公平实测与边界见
  [同 FP8 输入报告](../evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8/README.md)。
- 用户澄清“多机器”指多系统上的**单机器推理**，不是多台机器协同推理。
- 底座应在受支持系统上覆盖 CPU、CPU＋一张 GPU、单 GPU 三种模式；硬件后端按实际系统支持。
- 除 MTP、多模态外，底座的稳定性和功能完整性仍是核心要求。不能仅用 Qwen3.5-2B
  单请求成功或若干算子片段推导三种模式均完整。
- Windows/Linux/macOS 平台能力、构建后端集合、CPU/GPU/混合执行模式和静态/动态交付应分开表达，
  合法组合由依赖图组装；混合执行所需桥接模块复用相应 CPU/GPU 后端。
- 普通用户无需决定算子分配到哪个 Provider 或启用哪些第三方库。后端选择带出完整实现依赖，
  运行时按请求与设备能力绑定实现；精度、设备放置和资源预算仍由引擎控制。
- 独立 Qwen3.5-2B CUDA 架构测试消费者已执行完整 prefill→续算→decode；数值接受、稳态性能对照与
  其余模型/系统的旅程仍未完成。该消费者不作为基础库交付的正式推理引擎。
- 模型格式、tokenizer、生成/接受策略与请求政策留在独立引擎；可复用计算、存储、
  状态、执行、搬运和图能力在 Compute/Graph 及相应基础模块解决。
- 后续融合和量化接线以既定 8 个文本模型、22 个官方/GGUF 制品配置为范围，
  使用实际 dtype、格式、形状与数值合同核对普通 Provider 路由；历史覆盖表仅提供模型事实，
  其中的旧通过、拒绝与流程状态不直接代表当前支持。
  2026-10-18 的接线补全、实际检查及剩余边界见[本轮报告](../evidence/correctness/model-route-completion-2026-10-18/README.md)。
  继续按 prefill、缓存接续、decode、多请求和接受前缀核对完整调用链；已扩充 CUDA/Vulkan
  量化 embedding，修复 Graph 非对称 attention 输出绑定，并补接四后端的部分高维原生批次。
  可组合的数学、原生分页承载和整模型执行分别记录，不能用当前白名单缩小功能需求。
  用户随后启动[非多模态底座全量审查](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)：
  在以上模型范围内持续review融合、量化接线及Compute/Graph完整推理行为，包括资源调度、
  重复分配/转换/搬运、状态与失败寿命；先查证再修复，不将局部修复视为全量完成。

## 讨论起点

并行准备最小开发入口与真实文本引擎，用实际引擎旅程核对三种执行模式的底座能力。
重点检查驻留与增量状态、布局与 dtype 承载、动态形状与重放、异步搬运与 CPU 预算、
取消/失败/关闭、可观测性、安装包最小消费者，以及正常规模下的性能与显存。
后续实施顺序和具体改动继续按用户讨论推进，不将本页扩展为新的治理流程。

后续接口检查线索：锁定 ggml 的 CUDA GDN/causal conv 原实现要求 F32；这不是已证实的
BF16/FP8 接入遗漏。本轮已接通锁定 ggml 的多 token recurrent snapshot；
默认仍只输出最终状态，MTP 验证块显式请求快照，并按接受前缀恢复。

首个完整消费者重点确认：prepare/repack 是否留在冷路径；KV 有效长度变化是否导致重编译或多余绑定；
GDN、conv、attention 之间是否出现实体转置、dtype 转换或 host 同步；常量与状态能否按真实寿命复用。
`TensorDesc::transposed()` 仅改变描述，不搬运 payload。静态合同无误不代表实际转换次数或热路径成本合理，
不提前规定新的统一布局或合并各原生 runtime。

## 首个 Qwen3.5-2B 消费者的复用材料

模型输入身份见[本地输入清单](../implementation/tasks/compute/qwen35-2b-local-input.json)，
独立公式与中间结果生成见[文本参考](../../tests/compute_models/qwen35_reference.py)，
原运行条件见[参考预检数据](../evidence/correctness/qwen35-cli-preflight/README.md)。
这些材料不代表 Hyle 已整模型执行；加载、tokenizer、chat template、生成循环属于独立引擎。

接线时保留模型特有的数值边界，而不是仅匹配算子名字：

- 普通 RMS 的 scale 为模型规定的 `1+weight`；GDN gated RMS 是另一公式。
- linear Q/K 的 L2 使用 `sum(x*x)+eps`，不是 mean RMS；不要重复施加 GDN 已包含的 `1/sqrt(Dk)`。
- full-attention 的 Q/gate 按 head 拆分；partial RoPE 旋转 64 维并使用实际绝对位置。
- conv history 和 F32 recurrent state 逐层、逐步真实反馈；KV active 长度与 capacity 分开，新请求重置状态。
- 首次 prefill、多 token cached continuation 和单 token decode 分别核对。旧参考依赖的 cached 分支
  曾重置初始 state，不能把该行为复制为数学标准，也不能每轮把候选 state 换成 oracle state 来掩盖累计误差。

完整 CUDA 首版仍按第六项约定关闭 MTP/视觉，并从同源权重、相同精度和完整生命周期与 llama.cpp 比较。
