import json,re,statistics,sys
from pathlib import Path
from run import OUT,ROOT,ARCH,base,read,save,ident,run

if sys.argv[1]=='link':
 args=[v for v in base['command'] if not v.lower().startswith(('/out:','/map:','/implib:','/pdb:'))]
 for row in base['inputs']:assert ident(row['path'])==row,('baseline input drift',row['path'])
 args += ['/OUT:'+str(OUT/'before.exe'),'/MAP:'+str(OUT/'before.map'),'/IMPLIB:'+str(OUT/'before.lib')]
 save('before-link.json',dict(command=args,origin=str(ARCH/'strided-reshape/qwen-link.json'),inputs=base['inputs']))
 run('before-link',args)
elif sys.argv[1]=='run':
 assert not (OUT/'benchmark.json').exists(),'Never overwrite measurements'
 run('hardware',['nvidia-smi','--query-gpu=name,driver_version,clocks.sm,power.draw,temperature.gpu','--format=csv'])
 inp=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
 save('benchmark-inputs.json',[ident(inp/n) for n in ['weights.tsv','prompt.ids','continuation.ids']])
 save('benchmark-images.json',[ident(OUT/(n+'.exe')) for n in ['before','qwen']])
 rows=[]
 for ordinal,mode in enumerate(['before','qwen','qwen','before','before','qwen']):
  tag='bench-'+str(ordinal)+'-'+mode
  command=next((r for r in read(OUT/'commands.json') if r['tag']==tag and r['exit']==0),None)
  if command is None:
   run(tag,[OUT/(mode+'.exe'),'--inputs',inp,'--continuation',inp/'continuation.ids','--steps','6','--capacity','32','--progress','direct'])
   command=read(OUT/'commands.json')[-1]
  stdout=(OUT/command['stdout']).read_text();stderr=(OUT/command['stderr']).read_text()
  result=json.loads(stdout);phases=[]
  for m in re.finditer(r'^(prefill|continuation|decode\d+) tokens=(\d+) visible=(\d+) seconds=([\d.e+-]+) submit_seconds=([\d.e+-]+)',stderr,re.M):
   phases.append(dict(phase=m[1],tokens=int(m[2]),visible=int(m[3]),seconds=float(m[4]),submit_seconds=float(m[5])))
  assert len(phases)==len(result['generated_ids'])+1,(result,phases)
  rows.append(dict(mode=mode,result=result,phases=phases,command=command))
  save('benchmark-raw.json',rows)
 assert all(r['result']==rows[0]['result'] for r in rows)
 comparison=[]
 for phase in [p['phase'] for p in rows[0]['phases']]:
  a=[p['seconds'] for r in rows if r['mode']=='before' for p in r['phases'] if p['phase']==phase]
  b=[p['seconds'] for r in rows if r['mode']=='qwen' for p in r['phases'] if p['phase']==phase]
  comparison.append(dict(phase=phase,before_seconds=a,after_seconds=b,before_median=statistics.median(a),after_median=statistics.median(b),speed_ratio=statistics.median(a)/statistics.median(b),observed_ranges_separate=min(a)>max(b)))
 save('benchmark.json',dict(scope='Within-Hyle old/new, 3 each in ABBAAB order; identical current consumer/weights/inputs/precision/capacity32/direct/steps6, trace disabled. Normal EOS stops both after decode2; these are short-request first/native-cold slot executions, not sustained warm decode throughput. Embedded phase end-to-end completion+next-token time; process/model load/cold graph compilation excluded. Not llama.cpp comparison or whole-model accuracy acceptance.',result=rows[0]['result'],phases=comparison))
 print(json.dumps(comparison,indent=2))
else:raise SystemExit('link/run')
