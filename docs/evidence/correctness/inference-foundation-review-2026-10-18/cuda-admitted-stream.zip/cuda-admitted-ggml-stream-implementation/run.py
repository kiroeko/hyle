from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,j):(OUT/n).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
base=read(ARCH/'strided-reshape/qwen-link.json')
provider_template=read(ARCH/'cuda-sdpa-mask/fresh-identities.json')[0]['command']
backend_template=read(ARCH/'admitted-queue-sequence/cuda/compile-status.json')[0]['command']
test_template=read(ARCH/'strided-reshape/consumer-identity.json')['command']
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':provider_template[0],'CMAKE_C_COMPILER':provider_template[0]})
env['VSLANG']='1033'
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in base['command'] if Path(v).suffix.lower()=='.lib' and Path(v).is_absolute()))+os.pathsep+env['PATH']
def run(tag,cmd,expected=0,timeout=240):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';r=dict(tag=tag,command=list(map(str,cmd)),cwd=str(OUT),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log');rows.append(r);save('commands.json',rows)
 print('START',stem,flush=True);start=time.monotonic()
 with (OUT/r['stdout']).open('wb') as so,(OUT/r['stderr']).open('wb') as se:
  child=subprocess.Popen(r['command'],cwd=OUT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW);r['pid']=child.pid;save('commands.json',rows);r['exit']=child.wait(timeout=timeout)
 r['seconds']=time.monotonic()-start;save('commands.json',rows);print('END',stem,r['exit'],flush=True)
 print((OUT/r['stdout']).read_text(errors='replace')[-4500:],flush=True);print((OUT/r['stderr']).read_text(errors='replace')[-2000:],flush=True)
 if r['exit']!=expected:raise SystemExit(r['exit'] or 99)
def compile(source,name,flags,headers=()):
 receipt=OUT/(name+'-identity.json');before=ident(ROOT/source);head=[ident(ROOT/p) for p in headers]
 if receipt.exists():
  old=read(receipt)
  if old['source']==before and old.get('headers')==head and ident(old['object']['path'])==old['object']:return
 args=[x for x in flags if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]
 args += [str(ROOT/source),'/Fo'+str(OUT/(name+'.obj'))]
 run(name+'-compile',args);assert ident(ROOT/source)==before
 save(name+'-identity.json',dict(source=before,headers=head,object=ident(OUT/(name+'.obj')),command=args))
def native():
 # Use the existing pure canonical manifest derivation, not its old build task.
 spec=importlib.util.spec_from_file_location('canonical_manifests',ARCH/'generic-progress/ggml-cache/build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 generated,manifest,identity=m.generate(False);src=OUT/'ggml-cuda.cu';data=generated['src/ggml-cuda/ggml-cuda.cu']
 old=ARCH/'generic-progress/ggml-cache/source/ggml-cuda.cu';assert data==old.read_bytes()
 src.write_bytes(data)
 record=read(ARCH/'generic-progress/ggml-cache/compile-recipes.json')[0]
 args=[]
 for x in record['command']:
  if x==str(old):x=str(src)
  elif str(ARCH/'generic-progress/ggml-cache') in x:x=x.replace(str(ARCH/'generic-progress/ggml-cache'),str(OUT))
  args.append(x)
 head=[ident(ROOT/p) for p in ['src/compute_provider_ggml_cuda/native_bridge.h','src/compute_provider_ggml_cuda/native_bridge_impl.h']]
 receipt=OUT/'native-identity.json'
 if receipt.exists():
  prior=read(receipt)
  if prior['source']==ident(src) and prior['headers']==head and ident(prior['object']['path'])==prior['object']:return
 run('native-main-compile',args)
 save('native-identity.json',dict(source=ident(src),headers=head,object=ident(OUT/'ggml-cuda.obj'),command=args,source_id=identity,
 scope='One original main native TU; identical generated source and numerical flags. Unchanged SDK kernel objects reused; no native context layout change.'))
def host():
 head=['src/compute_backend_cuda/cuda_internal.h','src/compute_backend_cuda/native_context.h']
 for name in ['cuda_backend','cuda_device_status','cuda_memory','cuda_batch_transfer']:
  compile('src/compute_backend_cuda/'+name+'.cc',name,backend_template,head)
 compile('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','provider',provider_template,
  ['src/compute_backend_cuda/native_context.h','src/compute_provider_ggml_cuda/native_bridge.h'])
 compile('tests/compute_provider_ggml_cuda/provider_test.cc','provider-test',test_template)
 compile('tests/compute_backend_cuda/native_retirement_test.cc','retirement-test',test_template,['src/compute_backend_cuda/native_context.h'])
def link(which):
 replacements={}
 current={ROOT/'src/compute_backend_cuda/cuda_backend.cc':'cuda_backend',ROOT/'src/compute_backend_cuda/cuda_device_status.cc':'cuda_device_status',ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc':'provider'}
 for row in base['source_objects']:
  name=current.get(Path(row['source']['path']))
  if name:replacements[row['object']['path']]=str(OUT/(name+'.obj'))
 replacements[str(ARCH/'generic-progress/ggml-cache/ggml-cuda.obj')]=str(OUT/'ggml-cuda.obj')
 consumer=read(ARCH/'strided-reshape/consumer-identity.json')['object']['path']
 args=[replacements.get(v,v) for v in base['command'] if not v.lower().startswith(('/out:','/map:','/implib:','/pdb:')) and (which=='qwen' or v!=consumer)]
 args[6:6]=[str(OUT/'cuda_memory.obj'),str(OUT/'cuda_batch_transfer.obj')]
 if which=='tests':
  args[6:6]=[str(OUT/'provider-test.obj'),str(OUT/'retirement-test.obj'),str(ARCH/'cuda-sdpa-mask/attention-test.obj')]
  extra=read(ARCH/'cold-placement-facts/link-plan.json')['command']
  args += [next(v for v in extra if Path(v).name.lower()==lib) for lib in ['gtest_main.lib','gtest.lib']]
 args += ['/OUT:'+str(OUT/(which+'.exe')),'/MAP:'+str(OUT/(which+'.map')),'/IMPLIB:'+str(OUT/(which+'.lib'))]
 save(which+'-link.json',dict(command=args,replacements=replacements,origin=str(ARCH/'strided-reshape/qwen-link.json'),inputs=[ident(v) for v in args if Path(v).suffix.lower() in {'.obj','.lib'} and Path(v).is_file()]))
 run(which+'-link',args)
def execute():
 run('focused-tests',[OUT/'tests.exe','--gtest_filter=GgmlCuda.*:CudaNativeRetirement.*:GgmlCudaMaskedAttention.*:GgmlCudaAttention.OriginalPrefillDecodeAndIndependentReplays','--gtest_color=no','--gtest_output=xml:'+str(OUT/'tests.xml')])
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='native':native()
 elif mode=='host':host()
 elif mode in {'tests-link','qwen-link'}:link(mode.split('-')[0])
 elif mode=='tests':execute()
 elif mode=='qwen':
  trace=OUT/'trace-final';assert not trace.exists();inp=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
  run('qwen-direct',[OUT/'qwen.exe','--inputs',inp,'--continuation',inp/'continuation.ids','--steps','2','--capacity','32','--trace',trace,'--progress','direct'])
 else:raise SystemExit('native/host/tests-link/tests/qwen-link/qwen')
