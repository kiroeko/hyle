#pragma once

// Private C++17 boundary compiled with the pinned ggml CUDA backend. The C++23
// adapter translates these native failures; no vendor types enter the SDK.
#include <cstddef>

#include <cublas_v2.h>
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <ggml.h>

struct ggml_backend;
struct ggml_backend_buffer;

namespace hyle::compute::ggml_cuda::bridge {

template <class Code> struct NativeFailure final {
  Code code;
  const char *operation;
};

template <class Code> [[noreturn]] void fail(Code code, const char *operation) {
  throw NativeFailure<Code>{code, operation};
}

// Maps the HYLE physical device to ggml's possibly virtualized device table.
// A negative result means the physical device is absent from that table.
int device_index(int physical_device);
void initialize_backend(ggml_backend *backend);
cudaError_t drain(ggml_backend *backend) noexcept;
cudaError_t query(ggml_backend *backend) noexcept;

// The caller owns admission and has rejected an already-captured stream.
// Borrow only for this original graph submission; every exit restores the
// backend's owned stream table and current index. Handle/workspace restore
// errors propagate through the native failure boundary. retirement_error is
// required and initialized to success. A failed submission/restore reports the
// all-stream drain result there without replacing its original error/status.
ggml_status compute_on_admitted_stream(ggml_backend *backend,
                                      ggml_cgraph *graph, cudaStream_t stream,
                                      cudaError_t *retirement_error);

// Non-owning wrapper, created cold and rebound only while the invocation is
// idle. Destroying it never frees caller tensor payload. Capacity is fixed.
ggml_backend_buffer *binding_buffer(int device_index, std::size_t capacity);
void bind_buffer(ggml_backend_buffer *buffer, void *pointer) noexcept;

} // namespace hyle::compute::ggml_cuda::bridge
