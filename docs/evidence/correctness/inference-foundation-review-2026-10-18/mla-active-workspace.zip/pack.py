from pathlib import Path
import difflib
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def diff(before, after, name):
    return ''.join(difflib.unified_diff(
        before.read_text(encoding='utf-8').splitlines(keepends=True),
        after.read_text(encoding='utf-8').splitlines(keepends=True),
        fromfile='before/' + name, tofile='after/' + name))

scoped = ''
for old, current in [
    ('patches.before.json', 'third_party/flashinfer_cache/patches.json'),
    ('NOTICE.before.md', 'third_party/flashinfer_cache/NOTICE.md'),
]:
    scoped += diff(OUT / old, ROOT / current, current)
(OUT / 'product-scoped.diff').write_text(scoped, encoding='utf-8', newline='\n')
header = 'include/flashinfer/attention/scheduler.cuh'
old_header = ROOT / '.scratch/inference-feature-completion-2026-10-18/mla/verified-headers' / header
new_header = OUT / 'verified-headers' / header
(OUT / 'scheduler-scoped.diff').write_text(diff(old_header, new_header, header), encoding='utf-8', newline='\n')

files = {}
def add(path, name=None):
    path = Path(path)
    assert path.is_file(), path
    files[name or path.name] = path

for name in [
    'build_native.py', 'run.py', 'make_probe.py', 'patch_manifest.py', 'pack.py',
    'budget_consumer.cc', 'summary.txt', 'product-scoped.diff', 'scheduler-scoped.diff',
    'patches.before.json', 'NOTICE.before.md', 'commands.json', 'native-command.json',
    'identities.json', 'overlay-identities.json',
]:
    add(OUT / name)
for path in sorted(OUT.glob('*.log')):
    add(path)
for relative in [
    'third_party/flashinfer_cache/patches.json',
    'third_party/flashinfer_cache/NOTICE.md',
    'cmake/HyleDependencyLock.json',
    'src/compute_provider_flashinfer/native_mla.cu',
    'src/compute_provider_flashinfer/native_batch.h',
    'tests/compute_batch/public_mla_cuda_consumer.cc',
    'tests/compute_batch/mla_test_support.h',
]:
    add(ROOT / relative, 'source/' + relative)

records = [dict(path=name, bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
           for name, path in sorted(files.items())]
(OUT / 'package-identities.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
add(OUT / 'package-identities.json')
archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(Path(name).suffix.lower() in {'.obj', '.o', '.exe', '.dll', '.lib', '.a', '.exp', '.map'}
                   for name in z.namelist())
print(json.dumps(dict(path=str(archive), bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), files=len(files)), indent=2))
