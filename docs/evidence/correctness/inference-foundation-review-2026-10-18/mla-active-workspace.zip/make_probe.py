from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
source=(ROOT/'tests/compute_batch/public_mla_cuda_consumer.cc').read_text()
source='#include "native_batch.h"\n'+source
source=source.replace('const std::array<std::int32_t,3> qptr{0,1,4},kptr{0,2,5};','const std::array<std::int32_t,3> qptr{0,1,4},kptr{0,2,4};')
source=source.replace('const std::array<std::int32_t,5> pages{3,1,0,2,1};','const std::array<std::int32_t,4> pages{3,1,0,2};')
source=source.replace('const std::array<std::int32_t,2> tails{15,1};','const std::array<std::int32_t,2> tails{15,16};')
helper='''hyle::Result<c::flashinfer::native::BatchFacts> active_workspace(const c::BatchCapacity&cap,const c::BatchLayoutVersion&layout){
  const auto host=layout.host();std::vector<std::int32_t>lengths;
  for(std::size_t r=0;r<layout.facts().requests;++r){const auto count=host.kv_indptr[r+1]-host.kv_indptr[r];lengths.push_back(count?(count-1)*std::int32_t(cap.page_size)+host.last_page_lengths[r]:0);}
  const c::flashinfer::native::BatchSpec spec{.query_heads=cap.query_heads,.kv_heads=1,.qk_head_dim=cap.qk_head_dim,.value_head_dim=512,.page_size=cap.page_size,
      .query_rows=layout.facts().query_rows,.requests=layout.facts().requests,.paged=true,.bfloat16=cap.query_type==c::DataType::kBFloat16,.causal=true};
  c::flashinfer::native::BatchFacts facts;
  HYLE_RETURN_IF_ERROR(c::cuda::status(c::flashinfer::native::query_mla_workspace(spec,host.query_indptr.data(),host.kv_indptr.data(),lengths.data(),nullptr,facts)));
  return facts;
}
'''
source=source.replace('Status exercise(',helper+'Status exercise(',1)
needle='  c::BatchProgramOptions options{.max_float_workspace_bytes=16u<<20,.max_int_workspace_bytes=1u<<20,.scale=1.F/16};'
assert source.count(needle)==1
source=source.replace(needle,'''  HYLE_ASSIGN_OR_RETURN(auto requirement,active_workspace(cap,layout));
  HYLE_RETURN_IF_ERROR(check(requirement.float_bytes==0 && requirement.int_bytes>1 && requirement.int_bytes<=4096,"no-split active workspace differs from small-cap qualification"));
  std::printf("MLA no-split query H%u D%u float=%zu int=%zu explicitCaps=16/4096\\n",heads,depth,requirement.float_bytes,requirement.int_bytes);
  c::BatchProgramOptions options{.max_float_workspace_bytes=16,.max_int_workspace_bytes=4096,.scale=1.F/16};''')
source=source.replace('tiny.max_float_workspace_bytes=16;tiny.max_int_workspace_bytes=16;','tiny.max_float_workspace_bytes=16;tiny.max_int_workspace_bytes=requirement.int_bytes-1;')
needle='  HYLE_ASSIGN_OR_RETURN(auto token,direct.prepare_batch(layout));'
source=source.replace(needle,needle+'''
  HYLE_RETURN_IF_ERROR(check(!direct.report().split_kv && direct.report().float_workspace_bytes==requirement.float_bytes && direct.report().int_workspace_bytes==requirement.int_bytes,"no-split query/materialized counts differ"));''',1)
needle='''  HYLE_ASSIGN_OR_RETURN(auto program,c::BatchProgram::prepare(context,schema,{
      .resource=device.ref(),.host_workspace=host.ref(),.max_float_workspace_bytes=16u<<20,.max_int_workspace_bytes=1u<<20,.scale=1.F/16}));'''
assert source.count(needle)==1
source=source.replace(needle,'''  HYLE_ASSIGN_OR_RETURN(auto requirement,active_workspace(schema.capacity(),layout));
  HYLE_RETURN_IF_ERROR(check(requirement.float_bytes>16 && requirement.int_bytes>1,"true split query has no active partial workspace"));
  std::printf("MLA true-split query float=%zu int=%zu explicitCaps=exact\\n",requirement.float_bytes,requirement.int_bytes);
  for(unsigned limit=0;limit<2;++limit){
    HYLE_ASSIGN_OR_RETURN(auto small,c::BatchProgram::prepare(context,schema,{
        .resource=device.ref(),.host_workspace=host.ref(),.max_float_workspace_bytes=requirement.float_bytes-(limit==0),.max_int_workspace_bytes=requirement.int_bytes-(limit==1),.scale=1.F/16}));
    HYLE_ASSIGN_OR_RETURN(auto limited,c::BatchInvocation::create(small,queue));
    auto rejected=limited.prepare_batch(layout);
    HYLE_RETURN_IF_ERROR(check(!rejected && rejected.error().IsResourceExhausted(),"split active workspace minus one byte was admitted"));
    std::printf("MLA true-split %s requirement minus one byte rejected PASS\\n",limit==0?"float":"int");
  }
  HYLE_ASSIGN_OR_RETURN(auto program,c::BatchProgram::prepare(context,schema,{
      .resource=device.ref(),.host_workspace=host.ref(),.max_float_workspace_bytes=requirement.float_bytes,.max_int_workspace_bytes=requirement.int_bytes,.scale=1.F/16}));''')
needle='  HYLE_RETURN_IF_ERROR(check(invocation.report().split_kv,"long MLA did not actually schedule split partials"));'
source=source.replace(needle,needle+'''
  HYLE_RETURN_IF_ERROR(check(invocation.report().float_workspace_bytes==requirement.float_bytes && invocation.report().int_workspace_bytes==requirement.int_bytes,"split query/materialized active counts differ"));''')
(OUT/'budget_consumer.cc').write_text(source)
