from pathlib import Path
import hashlib,json,subprocess,time,sys,os
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
OLD=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla';RAW=ROOT/'.scratch/g04-bf16-partials-vendor/upstream';OVERLAY=OUT/'verified-headers'
manifest=json.loads((ROOT/'third_party/flashinfer_cache/patches.json').read_text());identities=[]
for e in manifest['files']:
    data=(RAW/e['path']).read_bytes().replace(b'\r\n',b'\n');assert hashlib.sha256(data).hexdigest()==e['before_sha256']
    for edit in e['edits']:
        old,new=edit['before'].encode(),edit['after'].encode();assert data.count(old)==1;data=data.replace(old,new,1)
    assert hashlib.sha256(data).hexdigest()==e['after_sha256']
    p=OVERLAY/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    identities.append(dict(path=e['path'],sha256=hashlib.sha256(data).hexdigest()))
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
env=windows_compiler_environment(read_cache(ROOT/'.scratch/build-compute-v2-dev'));env['VSLANG']='1033'
env['PATH']='C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64'+os.pathsep+env['PATH']
command=json.loads((OLD/'native-command.json').read_text())['command']
command=[arg.replace(str(OLD/'verified-headers'),str(OVERLAY)).replace(str(OLD/'native_mla.obj'),str(OUT/'native_mla.obj'))for arg in command]
start=time.monotonic();p=subprocess.run(command,cwd=OUT,env=env,capture_output=True,timeout=180)
(OUT/'native.stdout.log').write_bytes(p.stdout);(OUT/'native.stderr.log').write_bytes(p.stderr)
(OUT/'native-command.json').write_text(json.dumps(dict(command=command,cwd=str(OUT),exit=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n')
(OUT/'overlay-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
print('native_mla compile',p.returncode,'seconds',time.monotonic()-start,flush=True)
if p.returncode:print(p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-6000:]);raise SystemExit(p.returncode)
