from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
path=ROOT/'third_party/flashinfer_cache/patches.json'
manifest=json.loads(path.read_text());entry=next(x for x in manifest['files']if x['path']=='include/flashinfer/attention/scheduler.cuh')
for name in ['q_indptr','kv_indptr','partial_indptr','q_len','kv_len','q_start','kv_start','kv_end']:
    entry['edits'].append(dict(before='sizeof(IdType) * max_total_num_works, 16, "mla_'+name+'"',after='sizeof(IdType) * size_t(total_num_works), 16, "mla_'+name+'"'))
entry['edits'].append(dict(before='sizeof(IdType) * max_total_num_works, 16, "mla_work_indptr"',after='sizeof(IdType) * size_t(num_clusters + 1), 16, "mla_work_indptr"'))
entry['edits'].append(dict(before='2 * num_clusters * cluster_tile_q * sizeof_dtype_o * head_dim_o, 16, "mla_partial_o"',after='size_t(partial_o_nnz) * head_dim_o * sizeof_dtype_o, 16, "mla_partial_o"'))
entry['edits'].append(dict(before='2 * num_clusters * cluster_tile_q * sizeof(float), 16, "mla_partial_lse"',after='size_t(partial_o_nnz) * sizeof(float), 16, "mla_partial_lse"'))
data=(ROOT/'.scratch/g04-bf16-partials-vendor/upstream'/entry['path']).read_bytes().replace(b'\r\n',b'\n')
assert hashlib.sha256(data).hexdigest()==entry['before_sha256']
for edit in entry['edits']:
    old,new=edit['before'].encode(),edit['after'].encode();assert data.count(old)==1,edit['before'];data=data.replace(old,new,1)
entry['after_sha256']=hashlib.sha256(data).hexdigest()
manifest['scope']+='; MLA workspace storage follows active scheduled work and exact split partial rows, with full num_sm merge arrays and the original 16384 work admission bound retained'
path.write_text(json.dumps(manifest,indent=2)+'\n')
print(entry['after_sha256'])
