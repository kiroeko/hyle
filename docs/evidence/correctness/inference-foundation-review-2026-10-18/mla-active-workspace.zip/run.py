from pathlib import Path
import subprocess,json,time,sys,hashlib,os
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;OLD=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
env=windows_compiler_environment(read_cache(ROOT/'.scratch/build-compute-v2-dev'));env['VSLANG']='1033'
BASE=ROOT/'.scratch/build-compute-v2-dev'
env['PATH']='C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64'+os.pathsep+str(BASE/'bin')+os.pathsep+env['PATH']
records=[]
def run(tag,command):
    command=list(map(str,command));start=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=180)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-6500:],p.stderr.decode(errors='replace')[-1800:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
run('generate-probe',[sys.executable,OUT/'make_probe.py'])
old_commands=json.loads((OLD/'host-commands.json').read_text())
compile_cmd=next(row['command']for row in reversed(old_commands)if row['tag']=='consumer-compile')
compile_cmd=[arg.replace(str(ROOT/'tests/compute_batch/public_mla_cuda_consumer.cc'),str(OUT/'budget_consumer.cc')).replace(str(OLD/'consumer.obj'),str(OUT/'consumer.obj'))for arg in compile_cmd]
compile_cmd.insert(1,'/I'+str(ROOT/'tests/compute_batch'))
run('consumer-compile',compile_cmd)
link_cmd=next(row['command']for row in reversed(old_commands)if row['tag']=='mla-link')
exe=OUT/'budget.exe'
link_cmd=[arg.replace(str(OLD/'consumer.obj'),str(OUT/'consumer.obj')).replace(str(OLD/'native_mla.obj'),str(OUT/'native_mla.obj')).replace(str(OLD/'public-mla.exe'),str(exe)).replace(str(OLD/'public-mla.map'),str(OUT/'budget.map'))for arg in link_cmd]
for path in link_cmd:
    if path.endswith('.lib') and Path(path).is_absolute():env['PATH']=str(Path(path).parent)+os.pathsep+env['PATH']
run('budget-link',link_cmd)
run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
run('budget',[exe])
paths=[Path(p)for p in link_cmd if p.endswith(('.obj','.lib'))and Path(p).is_file()]
paths += [ROOT/p for p in ['third_party/flashinfer_cache/patches.json','third_party/flashinfer_cache/NOTICE.md','src/compute_provider_flashinfer/native_mla.cu','tests/compute_batch/public_mla_cuda_consumer.cc','tests/compute_batch/mla_test_support.h']]
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
