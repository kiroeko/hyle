#include <hyle/graph/apple.h>
#include <hyle/graph/executable.h>
#include <hyle/compute/apple_memory.h>
#if !defined(HYLE_FOUNDATION_A_NATIVE_ONLY)
#include <hyle/graph/cpu.h>
#include <hyle/graph/cpu_apple.h>
#include <hyle/sched/scheduler.h>
#endif

#include <array>
#include <cmath>
#include <cstdio>
#include <mlx/ops.h>

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace a = c::apple;
#if !defined(HYLE_FOUNDATION_A_NATIVE_ONLY)
namespace b = g::cpu_apple;
#endif
namespace mx = mlx::core;
using hyle::Status;
template<class T> using Result = hyle::Result<T>;
Status require(bool condition, const char *message) {
  return condition ? Status::Ok() : Status::Internal(message);
}
template<class T, std::size_t N>
Result<c::ReadLease> upload(const a::MemoryResource &memory,
                            const c::TensorDesc &desc, const std::array<T,N> &values) {
  HYLE_ASSIGN_OR_RETURN(auto native, memory.allocate(desc));
  HYLE_ASSIGN_OR_RETURN(auto host, hyle::mem::Buffer::create(
      hyle::mem::system_resource(), sizeof(values), alignof(T)));
  HYLE_RETURN_IF_ERROR(host.view().write(std::as_bytes(std::span(values))));
  HYLE_ASSIGN_OR_RETURN(auto source, c::ConstTensorView::create(desc, host.view()));
  HYLE_RETURN_IF_ERROR(memory.copy_from_host(native, source));
  return memory.import_readonly(native, desc);
}

Status run() {
  HYLE_ASSIGN_OR_RETURN(auto context, a::Context::create());
  HYLE_ASSIGN_OR_RETURN(auto memory, a::MemoryResource::create(context));
  HYLE_ASSIGN_OR_RETURN(auto source, g::apple::execution_source(context));
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{source,g::StorageDomainId{0}}};
#if !defined(HYLE_FOUNDATION_A_NATIVE_ONLY)
  HYLE_ASSIGN_OR_RETURN(auto cpu, g::cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue, cpu.create_queue());
  const b::Environment environment{.cpu=&cpu, .apple=&context, .native=&memory};
  hyle::sched::Scheduler scheduler(1, hyle::mem::system_allocator(), 32);
  struct Drain { hyle::sched::Scheduler &scheduler; ~Drain(){scheduler.drain();} } drain{scheduler};
#endif
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto rows, builder.dimension({1,4}));
  HYLE_ASSIGN_OR_RETURN(auto spec, g::TensorSpec::dense(c::DataType::kFloat32,
      std::array{g::Dimension(rows), g::Dimension::fixed(8)}));
  HYLE_ASSIGN_OR_RETURN(auto x, builder.input(spec));
  HYLE_ASSIGN_OR_RETURN(auto first, builder.add_node(c::Operation(c::Unary{c::UnaryKind::kAbs}),
      std::array{x}, std::array{spec}));
  // Independent data branch; the first node is live only through control.
  HYLE_ASSIGN_OR_RETURN(auto last, builder.add_node(c::Operation(c::Unary{c::UnaryKind::kNeg}),
      std::array{x}, std::array{spec}));
  HYLE_RETURN_IF_ERROR(builder.depends_on(last, first));
  HYLE_ASSIGN_OR_RETURN(auto output, builder.result(last));
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  const std::array one{g::ShapeBinding{rows,1}}, four{g::ShapeBinding{rows,4}};
  const std::array points{g::ExactShapeVariant{one}, g::ExactShapeVariant{four}};
  HYLE_ASSIGN_OR_RETURN(auto compiled, g::compile(graph, {domains,targets},
      {.shape_policy=g::CompileShapePolicy::kFiniteExact, .exact_variants=points}));
  const auto &family=compiled.executable;
  HYLE_RETURN_IF_ERROR(require(family.exact_variant_count()==2 && !family.has_execution_route(),
      "Apple finite family route contract differs"));
  const std::array missing{g::ShapeBinding{rows,2}};
  auto absent=family.create_invocation({.shape=missing});
  HYLE_RETURN_IF_ERROR(require(!absent && absent.error().IsUnimplemented(), "Apple covered undeclared shape"));
  HYLE_ASSIGN_OR_RETURN(auto first_slot, family.create_invocation({.shape=four}));
  HYLE_ASSIGN_OR_RETURN(auto second_slot, family.create_invocation({.shape=four}));
  HYLE_ASSIGN_OR_RETURN(auto point, g::specialize_exact(graph,four));
  HYLE_ASSIGN_OR_RETURN(auto input_desc, point.graph.input_description());
  std::array<float,32> values, changed;
  for (std::size_t i=0;i<values.size();++i) { values[i]=float(i)-16; changed[i]=2*values[i]; }
  HYLE_ASSIGN_OR_RETURN(auto input, upload(memory,input_desc,values));
  HYLE_ASSIGN_OR_RETURN(auto other, upload(memory,input_desc,changed));
  HYLE_RETURN_IF_ERROR(first_slot.prepare_resources());
  HYLE_RETURN_IF_ERROR(first_slot.bind(x,input_desc,input));
  HYLE_RETURN_IF_ERROR(first_slot.prepare_replay({}));
  {
    HYLE_ASSIGN_OR_RETURN(auto submitted, first_slot.submit());
    HYLE_RETURN_IF_ERROR(submitted.wait());
  }
  HYLE_ASSIGN_OR_RETURN(auto old, first_slot.result(output));
  HYLE_RETURN_IF_ERROR(second_slot.prepare_resources());
  HYLE_RETURN_IF_ERROR(second_slot.bind(x,input_desc,other));
  HYLE_RETURN_IF_ERROR(second_slot.prepare_replay({}));
  {
    HYLE_ASSIGN_OR_RETURN(auto next, second_slot.submit());
    HYLE_RETURN_IF_ERROR(next.wait());
  }
  HYLE_ASSIGN_OR_RETURN(auto fresh, second_slot.result(output));
  HYLE_ASSIGN_OR_RETURN(auto old_tensor, old.tensor());
  HYLE_ASSIGN_OR_RETURN(auto fresh_tensor, fresh.tensor());
  std::array<float,32> before,after;
  HYLE_RETURN_IF_ERROR(old_tensor.storage().read(std::as_writable_bytes(std::span(before))));
  HYLE_RETURN_IF_ERROR(fresh_tensor.storage().read(std::as_writable_bytes(std::span(after))));
  for (std::size_t i=0;i<values.size();++i)
    HYLE_RETURN_IF_ERROR(require(before[i]==-values[i] && after[i]==-changed[i], "Apple slots or controlled math differ"));
  HYLE_RETURN_IF_ERROR(require(!first_slot.bind(x,input_desc,other).ok(),
      "Apple finite result did not guard its original slot"));

#if !defined(HYLE_FOUNDATION_A_NATIVE_ONLY)
  const std::array placement{g::NodePlacement{first,b::kCpuTarget,g::PlacementStrength::kRequired}};
  HYLE_ASSIGN_OR_RETURN(auto hybrids, b::compile_variants(graph,environment,points,{.node_placements=placement}));
  for (const auto &shape : {one,four}) {
    HYLE_ASSIGN_OR_RETURN(auto point,g::specialize_exact(graph,shape));
    HYLE_ASSIGN_OR_RETURN(auto desc,point.graph.input_description());
    HYLE_ASSIGN_OR_RETURN(auto host,hyle::mem::Buffer::create(hyle::mem::system_resource(),*desc.required_bytes(),64));
    std::vector<float> data(*desc.element_count(),3.0f);
    HYLE_RETURN_IF_ERROR(host.view().write(std::as_bytes(std::span(data))));
    HYLE_ASSIGN_OR_RETURN(auto tensor,c::ConstTensorView::create(desc,host.view()));
    HYLE_ASSIGN_OR_RETURN(auto program,hybrids.select(shape));
    HYLE_ASSIGN_OR_RETURN(auto slot,program.create_invocation(scheduler,queue));
    HYLE_RETURN_IF_ERROR(slot.bind(x,tensor));
    auto forbidden=slot.prepare_replay({.host_wait=g::HostWaitPolicy::kReject});
    HYLE_RETURN_IF_ERROR(require(!forbidden.ok(),"Apple hybrid hid control completion waits"));
    HYLE_RETURN_IF_ERROR(slot.prepare_replay());
    HYLE_ASSIGN_OR_RETURN(auto result,slot.run());
    HYLE_ASSIGN_OR_RETURN(auto array,result->array(output));
    for (std::size_t i=0;i<data.size();++i)
      HYLE_RETURN_IF_ERROR(require(array.data<float>()[i]==-3.0f,"Apple hybrid exact/control math differs"));
    HYLE_RETURN_IF_ERROR(require(!slot.reset().ok(),"Apple hybrid old result failed to guard slot"));
  }
#endif

  // The checked predecessor has no tensor consumer. Its accepted failure must
  // still prevent an otherwise valid, independent native successor result.
  HYLE_ASSIGN_OR_RETURN(auto checked, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto table_desc, c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,2>{2,8}));
  HYLE_ASSIGN_OR_RETURN(auto index_desc, c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t,1>{1}));
  HYLE_ASSIGN_OR_RETURN(auto values_desc, c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,1>{8}));
  HYLE_ASSIGN_OR_RETURN(auto table_input, checked.input(table_desc));
  HYLE_ASSIGN_OR_RETURN(auto index_input, checked.input(index_desc));
  HYLE_ASSIGN_OR_RETURN(auto values_input, checked.input(values_desc));
  HYLE_ASSIGN_OR_RETURN(auto predecessor, checked.add_node(
      c::Operation(c::Gather{0,c::IndexBoundsPolicy::kChecked}),
      std::array{table_input,index_input}));
  HYLE_ASSIGN_OR_RETURN(auto successor, checked.add_node(
      c::Operation(c::Unary{c::UnaryKind::kNeg}),std::array{values_input}));
  HYLE_RETURN_IF_ERROR(checked.depends_on(successor,predecessor));
  HYLE_ASSIGN_OR_RETURN(auto controlled_output, checked.result(successor));
  HYLE_RETURN_IF_ERROR(checked.publish(controlled_output));
  HYLE_ASSIGN_OR_RETURN(auto controlled_graph, std::move(checked).finish());
  HYLE_ASSIGN_OR_RETURN(auto controlled, g::compile(controlled_graph,{domains,targets}));
  HYLE_RETURN_IF_ERROR(require(controlled.report.node_count()==2,
      "Apple erased the control-only predecessor"));
  const std::array<float,16> table_values{};
  const std::array<float,8> independent{1,2,3,4,5,6,7,8};
  const std::array<std::int32_t,1> bad{2},good{1};
  HYLE_ASSIGN_OR_RETURN(auto native_table, upload(memory,table_desc,table_values));
  HYLE_ASSIGN_OR_RETURN(auto native_values, upload(memory,values_desc,independent));
  for(const auto &indices : {bad,good}) {
    HYLE_ASSIGN_OR_RETURN(auto native_ids, upload(memory,index_desc,indices));
    HYLE_ASSIGN_OR_RETURN(auto slot, controlled.executable.create_invocation());
    HYLE_RETURN_IF_ERROR(slot.prepare_resources());
    HYLE_RETURN_IF_ERROR(slot.bind(table_input,table_desc,native_table));
    HYLE_RETURN_IF_ERROR(slot.bind(index_input,index_desc,native_ids));
    HYLE_RETURN_IF_ERROR(slot.bind(values_input,values_desc,native_values));
    HYLE_RETURN_IF_ERROR(slot.prepare_replay({}));
    HYLE_ASSIGN_OR_RETURN(auto submitted, slot.submit());
    const auto terminal=submitted.wait();
    if(indices==bad) {
      HYLE_RETURN_IF_ERROR(require(terminal.IsOutOfRange() && !slot.result(controlled_output),
          "Apple erased a failing control-only predecessor"));
    } else {
      HYLE_RETURN_IF_ERROR(terminal);
      HYLE_ASSIGN_OR_RETURN(auto result, slot.result(controlled_output));
      HYLE_ASSIGN_OR_RETURN(auto tensor, result.tensor());
      std::array<float,8> actual;
      HYLE_RETURN_IF_ERROR(tensor.storage().read(std::as_writable_bytes(std::span(actual))));
      for(std::size_t i=0;i<independent.size();++i)
        HYLE_RETURN_IF_ERROR(require(actual[i]==-independent[i],"Apple checked control success differs"));
    }
  }
  return Status::Ok();
}
} // namespace

int main() {
  const auto status=run();
  if(!status.ok()){std::fprintf(stderr,"foundation A Apple: %.*s\n",int(status.message().size()),status.message().data());return 1;}
  std::puts("foundation A Apple exact/control/slot journey PASS");
}
