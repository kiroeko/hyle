from pathlib import Path
import json,subprocess,time
OUT=Path(__file__).resolve().parent
command=['ssh','kiro@172.22.10.198','python3 /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-discovery-spi/run_remote.py build link test finite-build finite-link finite-test']
started=time.monotonic()
with (OUT/'ssh.stderr.log').open('wb') as error,(OUT/'ssh.stdout.log').open('wb') as output:
 p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=error)
 (OUT/'local-live.json').write_text(json.dumps(dict(pid=p.pid,command=command))+'\n')
 for line in iter(p.stdout.readline,b''):
  output.write(line);output.flush();print(line.decode(errors='replace').rstrip(),flush=True)
 p.wait()
(OUT/'ssh-command.json').write_text(json.dumps(dict(command=command,exit=p.returncode,seconds=time.monotonic()-started),indent=2)+'\n')
(OUT/'local-live.json').write_text(json.dumps(dict(terminal=True,exit=p.returncode))+'\n')
raise SystemExit(p.returncode)
