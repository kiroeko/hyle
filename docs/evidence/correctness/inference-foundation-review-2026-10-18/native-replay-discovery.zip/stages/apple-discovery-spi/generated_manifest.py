from pathlib import Path
import base64,json,subprocess
OUT=Path(__file__).resolve().parent
code='''from pathlib import Path
import hashlib,json,stat
r=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-discovery-spi')
binaries=['native-tests','finite-native','native-tests-adapter','native-tests-final','finite-native-final']
objects=['executable.o','resources.o','region-access.o','constant-artifact.o','execution-source.o','source.o','region.o','lowering.o','test.o','finite-consumer.o','test-adapter.o','executable-final.o','test-final.o']
def identity(name):
 p=r/name;assert stat.S_ISREG(p.lstat().st_mode),p
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'cleanup_binary_and_map':[identity(n) for n in binaries]+[identity(n+'.map') for n in binaries],
 'retain_objects':[identity(n) for n in objects]},indent=2))
'''
command='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
p=subprocess.run(['ssh','kiro@172.22.10.198',command],capture_output=True,timeout=60)
if p.returncode:raise RuntimeError(p.stderr.decode())
(OUT/'generated-manifest.json').write_bytes(p.stdout)
d=json.loads(p.stdout);print(len(d['cleanup_binary_and_map']),'cleanup files',sum(x['bytes'] for x in d['cleanup_binary_and_map']),'bytes;',len(d['retain_objects']),'objects retained')
