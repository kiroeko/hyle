from pathlib import Path
import base64,io,json,subprocess,tarfile
OUT=Path(__file__).resolve().parent;REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-discovery-spi'
code='''from pathlib import Path
import io,sys,tarfile
r=Path('''+repr(REMOTE)+''')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in {'.log','.json','.txt','.py','.map'}:a.add(p,arcname=p.name)
sys.stdout.buffer.write(b.getvalue())
'''
command='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
p=subprocess.run(['ssh','kiro@172.22.10.198',command],capture_output=True,timeout=60)
if p.returncode:raise RuntimeError(p.stderr.decode())
(OUT/'remote-evidence.tar.gz').write_bytes(p.stdout)
r=OUT/'remote';r.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:gz') as a:
 assert all(m.isfile() and '/' not in m.name and '..' not in Path(m.name).parts for m in a.getmembers());a.extractall(r)
print(len(p.stdout),'bytes retrieved')
