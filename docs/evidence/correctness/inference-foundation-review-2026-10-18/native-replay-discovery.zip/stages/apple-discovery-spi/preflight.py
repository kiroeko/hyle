from pathlib import Path
import base64,json,subprocess
OUT=Path(__file__).resolve().parent
code='''from pathlib import Path
import json,subprocess
root=Path('/Users/kiro/hyle-scratch/compute-unified')
model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()
assert model=='Mac16,12',model
rows={}
for stage in ['architecture-refactor-20261018-apple-native-region','architecture-refactor-20261018-apple-finite-native']:
 p=root/stage
 assert p.is_dir(),p
 rows[stage]=json.loads((p/'commands.json').read_text())
sdk=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
assert (sdk/'include').is_dir() and (sdk/'lib').is_dir()
print(json.dumps({'model':model,'hardware':subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True),'compiler':subprocess.check_output(['xcrun','clang++','--version'],text=True),'sdk':str(sdk),'commands':rows},indent=2))
'''
command='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
p=subprocess.run(['ssh','kiro@172.22.10.198',command],capture_output=True,timeout=60)
(OUT/'preflight.stdout.json').write_bytes(p.stdout);(OUT/'preflight.stderr.log').write_bytes(p.stderr)
print('preflight exit',p.returncode)
if p.returncode: print(p.stderr.decode());raise SystemExit(p.returncode)
data=json.loads(p.stdout);print(data['hardware']+data['compiler'])
