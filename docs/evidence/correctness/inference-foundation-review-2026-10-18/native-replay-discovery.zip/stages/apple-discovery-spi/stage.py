from pathlib import Path
import base64,hashlib,io,json,re,subprocess,tarfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-discovery-spi'
def ssh(code,payload=None):
 command='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
 p=subprocess.run(['ssh','kiro@172.22.10.198',command],input=payload,capture_output=True,timeout=60)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout
def stage():
 files={'run_remote.py':OUT/'run_remote.py'};seen=set()
 def add(path):
  path=path.resolve()
  if path in seen or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:return
  seen.add(path);files[path.relative_to(ROOT).as_posix()]=path
  for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
   for q in [path.parent/name,ROOT/name,ROOT/'include'/name,ROOT/'src/graph'/name,ROOT/'src/compute'/name,
             ROOT/'src/compute_route_apple'/name,ROOT/'src/graph_route_apple'/name,ROOT/'src/compute_ggml_runtime'/name,
             ROOT/'src/compute_provider_ggml_metal'/name]:
    if q.is_file():add(q);break
 sources=re.findall(r"\('([^']+\.cc)','[^']+'\)",(OUT/'run_remote.py').read_text())
 for name in sources+['tests/graph/route_symmetry_apple.cc']:add(ROOT/name)
 rows=[dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for name,p in sorted(files.items())]
 (OUT/'staged-sources.json').write_text(json.dumps(rows,indent=2)+'\n')
 files['staged-sources.json']=OUT/'staged-sources.json'
 data=io.BytesIO()
 with tarfile.open(fileobj=data,mode='w:gz') as archive:
  for name,path in sorted(files.items()):archive.add(path,arcname=name)
 (OUT/'minimal-sources.tar.gz').write_bytes(data.getvalue())
 code='from pathlib import Path;import io,sys,tarfile;r=Path('+repr(REMOTE)+');assert not r.exists();r.mkdir();a=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in a.getmembers());a.extractall(r);print(r)'
 output=ssh(code,data.getvalue());(OUT/'stage.log').write_bytes(output)
 print(output.decode().strip(),len(rows),'files',len(data.getvalue()),'bytes')
if __name__=='__main__':stage()
