from pathlib import Path
import hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parent
OLD=json.loads((ROOT/'commands.json').read_text())
CC=next(x['command'] for x in OLD if x['tag']=='executable-compile' and x['exit']==0)
LINK=next(x['command'] for x in OLD if x['tag']=='link' and x['exit']==0)
TESTCC=next(x['command'] for x in OLD if x['tag']=='test-compile' and x['exit']==0)
FINITE=next(x['command'] for x in OLD if x['tag']=='finite-link' and x['exit']==0)
ROWS=[]
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,args):
 args=list(map(str,args));stem=f'final-{len(ROWS)+1:02d}-{tag}';start=time.monotonic()
 p=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=180)
 (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr)
 ROWS.append(dict(tag=tag,command=args,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start,
   stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
 (ROOT/'final-commands.json').write_text(json.dumps(ROWS,indent=2)+'\n')
 print(stem,p.returncode,flush=True)
 if p.returncode:
  print(p.stdout.decode(errors='replace')[-4500:]+p.stderr.decode(errors='replace')[-9500:],flush=True)
  raise SystemExit(p.returncode)
def link(base,name):
 output=ROOT/name;args=[];skip=False
 for arg in base:
  if skip:skip=False;continue
  if arg=='-o':args+=['-o',str(output)];skip=True;continue
  if arg.startswith('-Wl,-map,'):arg='-Wl,-map,'+str(output)+'.map'
  if arg==str(ROOT/'executable.o'):arg=str(ROOT/'executable-final.o')
  if arg==str(ROOT/'test.o'):arg=str(ROOT/'test-final.o')
  args.append(arg)
 run(name+'-link',args)
 (ROOT/(name+'-identities.json')).write_text(json.dumps([identity(p) for p in args if p.endswith(('.o','.a','.dylib'))]
  +[identity(output)],indent=2)+'\n')
if __name__=='__main__':
 for row in json.loads((ROOT/'final-update-identities.json').read_text()):
  assert identity(ROOT/row['path'])['sha256']==row['sha256'],row['path']
 source=ROOT/'src/graph/executable.cc'
 run('executable-compile',CC[:CC.index('-c')]+['-c',source,'-o',ROOT/'executable-final.o'])
 run('test-compile',TESTCC[:TESTCC.index('-c')]+['-c',ROOT/'tests/graph_route_apple/native_region_test.cc','-o',ROOT/'test-final.o'])
 link(LINK,'native-tests-final')
 run('tests',[ROOT/'native-tests-final','--gtest_filter=AppleNativeRegion.*:AppleLateInput.*','--gtest_color=no',
   '--gtest_output=json:'+str(ROOT/'final-test-results.json')])
 link(FINITE,'finite-native-final')
 run('finite-tests',[ROOT/'finite-native-final'])
