from pathlib import Path
import hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parent
OLD=json.loads((ROOT/'commands.json').read_text())
CC=next(x['command'] for x in OLD if x['tag']=='test-compile' and x['exit']==0)
LINK=next(x['command'] for x in OLD if x['tag']=='link' and x['exit']==0)
ROWS=[]
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,args):
 args=list(map(str,args));stem=f'adapter-{len(ROWS)+1:02d}-{tag}';started=time.monotonic()
 p=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=180)
 (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr)
 ROWS.append(dict(tag=tag,command=args,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-started,
  stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
 (ROOT/'adapter-commands.json').write_text(json.dumps(ROWS,indent=2)+'\n')
 print(stem,p.returncode,flush=True)
 if p.returncode:
  print(p.stdout.decode(errors='replace')[-3500:]+p.stderr.decode(errors='replace')[-9000:],flush=True)
  raise SystemExit(p.returncode)
if __name__=='__main__':
 source=ROOT/'tests/graph_route_apple/native_region_test.cc';object=ROOT/'test-adapter.o'
 run('test-compile',CC[:CC.index('-c')]+['-c',source,'-o',object])
 output=ROOT/'native-tests-adapter';args=[];skip=False
 for arg in LINK:
  if skip:skip=False;continue
  if arg=='-o':args+=['-o',str(output)];skip=True;continue
  if arg.startswith('-Wl,-map,'):arg='-Wl,-map,'+str(output)+'.map'
  if arg==str(ROOT/'test.o'):arg=str(object)
  args.append(arg)
 run('link',args)
 (ROOT/'adapter-identities.json').write_text(json.dumps([identity(p) for p in args if p.endswith(('.o','.a','.dylib'))]
  +[identity(source),identity(output)],indent=2)+'\n')
 run('tests',[output,'--gtest_filter=AppleNativeRegion.*:AppleLateInput.*','--gtest_color=no',
   '--gtest_output=json:'+str(ROOT/'adapter-test-results.json')])
