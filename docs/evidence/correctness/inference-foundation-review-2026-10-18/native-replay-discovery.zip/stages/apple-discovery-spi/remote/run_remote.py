from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'architecture-refactor-20261018-apple-native-region'
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CACHE=json.loads((OLD/'commands.json').read_text())
CC=next(x['command'] for x in CACHE if x['tag']=='executable-compile' and x['exit']==0)
LINK=next(x['command'] for x in reversed(CACHE) if x['tag']=='link' and x['exit']==0)
SOURCES=[('src/graph/executable.cc','executable'),('src/graph/resources.cc','resources'),
 ('src/graph/region_access.cc','region-access'),('src/graph/constant_artifact.cc','constant-artifact'),
 ('src/graph/execution_source.cc','execution-source'),('src/graph_route_apple/execution_source.cc','source'),
 ('src/graph_route_apple/native_region.cc','region'),('src/graph_route_apple/apple_lowering.cc','lowering'),
 ('tests/graph_route_apple/native_region_test.cc','test')]
RECORDS=json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
def identity(path):
 p=Path(path);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,args):
 args=list(map(str,args));stem=f'{len(RECORDS)+1:02d}-{tag}';started=time.monotonic()
 (ROOT/'live.json').write_text(json.dumps(dict(tag=tag,command=args,pid=None))+'\n')
 p=subprocess.Popen(args,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (ROOT/'live.json').write_text(json.dumps(dict(tag=tag,command=args,pid=p.pid))+'\n')
 try: stdout,stderr=p.communicate(timeout=180)
 except subprocess.TimeoutExpired:
  p.kill();stdout,stderr=p.communicate();p.returncode=124
 (ROOT/(stem+'.stdout.log')).write_bytes(stdout);(ROOT/(stem+'.stderr.log')).write_bytes(stderr)
 RECORDS.append(dict(tag=tag,command=args,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-started,
   stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
 (ROOT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
 (ROOT/'live.json').write_text(json.dumps(dict(terminal=True,tag=tag,exit=p.returncode))+'\n')
 print(stem,p.returncode,flush=True)
 if p.returncode:
  print(stdout.decode(errors='replace')[-4000:]+stderr.decode(errors='replace')[-11000:],flush=True)
  raise SystemExit(p.returncode)
def preflight():
 model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip();assert model=='Mac16,12',model
 for row in json.loads((ROOT/'staged-sources.json').read_text()):
  assert identity(ROOT/row['path'])['sha256']==row['sha256'],row['path']
 assert (SDK/'lib/mlx.metallib').is_file()
 if not (ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to((SDK/'lib/mlx.metallib').resolve())
 (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)
   +subprocess.check_output(['xcrun','clang++','--version'],text=True))
 # All retained link inputs must be real files; no SDK/native source is built.
 retained=[]
 for arg in LINK:
  p=Path(arg)
  if arg.endswith(('.o','.a','.dylib')):
   assert p.is_file(),p
   retained.append(dict(path=str(p),bytes=p.stat().st_size))
 (ROOT/'retained-inputs.json').write_text(json.dumps(retained,indent=2)+'\n')
def compile(source,name,finite=False):
 prefix=CC[:CC.index('-c')]
 prefix[1:1]=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/graph'),
   '-I'+str(ROOT/'src/compute'),'-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(ROOT/'src/graph_route_apple')]
 if finite:prefix.append('-DHYLE_FOUNDATION_A_NATIVE_ONLY=1')
 run(name+'-compile',prefix+['-c',ROOT/source,'-o',ROOT/(name+'.o')])
def link(finite=False):
 replacements={str(OLD/(name+'.o')):str(ROOT/(name+'.o')) for _,name in SOURCES}
 output=ROOT/('finite-native' if finite else 'native-tests');args=[];seen=set();skip=False
 for i,arg in enumerate(LINK):
  if skip:skip=False;continue
  if arg=='-o':args+=['-o',str(output)];skip=True;continue
  if arg.startswith('-Wl,-map,'):args.append('-Wl,-map,'+str(output)+'.map');continue
  if finite and (arg.endswith(('/test.o','/late-test.o','/libgtest.a','/libgtest_main.a'))):continue
  if arg in replacements:seen.add(arg);arg=replacements[arg]
  args.append(arg)
 expected=set(replacements)
 if finite:expected.remove(str(OLD/'test.o'));args.append(str(ROOT/'finite-consumer.o'))
 assert seen==expected,(seen,expected)
 run(('finite-' if finite else '')+'link',args)
 (ROOT/('finite-identities.json' if finite else 'identities.json')).write_text(json.dumps(
   [identity(arg) for arg in args if arg.endswith(('.o','.a','.dylib'))]+[identity(output)],indent=2)+'\n')
if __name__=='__main__':
 for action in sys.argv[1:]:
  if action=='build':
   preflight()
   for source,name in SOURCES:compile(source,name)
  elif action=='link':link()
  elif action=='test':run('tests',[ROOT/'native-tests','--gtest_filter=AppleNativeRegion.*:AppleLateInput.*',
   '--gtest_color=no','--gtest_output=json:'+str(ROOT/'test-results.json')])
  elif action=='finite-build':compile('tests/graph/route_symmetry_apple.cc','finite-consumer',True)
  elif action=='finite-link':link(True)
  elif action=='finite-test':run('finite-tests',[ROOT/'finite-native'])
