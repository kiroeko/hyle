from pathlib import Path
import importlib.util,json,sys
ROOT=Path.cwd(); OUT=ROOT/'.scratch/architecture-refactor-2026-10-18/native-fragment-discovery';OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('driver',ROOT/'.scratch/architecture-refactor-2026-10-18/region-adapter/run.py'); b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.OUT=OUT
history=json.loads((ROOT/'.scratch/architecture-refactor-2026-10-18/finite-native-migration/commands.json').read_text())
cc=next(r['command'] for r in history if r['tag']=='vulkan-region-compile')
flags=[a for a in cc[1:] if not a.lower().startswith('/fo') and not a.endswith('.cc')]
b.run('vulkan-region-compile',[cc[0],*flags,ROOT/'src/graph_route_vulkan/native_region.cc','/Fo'+str(OUT/'vulkan-region.obj')])
