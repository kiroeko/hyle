from pathlib import Path
import hashlib
import json
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-replay-discovery.zip'
STAGES = ['native-replay-bridge', 'native-fragment-discovery', 'region-entry-frontier',
          'region-discovery-spi', 'cpu-vulkan-finite', 'vulkan-replay-copy',
          'vulkan-replay-copy-test', 'apple-discovery-spi']
SOURCES = '''
include/hyle/graph/region_provider.h
include/hyle/graph/detail/region_adapter.h
include/hyle/graph/cpu_vulkan.h
src/graph/executable.cc
src/graph/execution_source.cc
src/graph/execution_source_internal.h
src/graph/plan_state.h
src/graph/native_analysis.h
src/graph/region_discovery.h
src/graph_route_apple/apple_lowering.cc
src/graph_route_apple/native_region.cc
src/graph_route_vulkan/native_region.cc
src/graph_route_vulkan/native_region.h
src/graph_route_vulkan/execution_source.cc
src/compute_route_vulkan/vulkan_copy_internal.h
src/compute_route_vulkan/vulkan_copy_recording.cc
src/graph_route_cpu/ggml_region.cc
src/graph_provider_ggml_cuda/ggml_cuda_region.cc
src/graph_provider_onednn/onednn_region_provider.cc
src/graph_batch/batch.cc
tests/graph/region_provider_test.cc
tests/graph/route_symmetry_vulkan.cc
tests/graph_route_vulkan/native_region_test.cc
tests/compute_route_vulkan/copy_program_test.cc
tests/graph_route_apple/native_region_test.cc
docs/architecture/compute-design.md
docs/developer/current-work.md
docs/user/graph.md
'''.split()


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return {'path': path.relative_to(ROOT).as_posix(),
            'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def latest(rows, tag):
    row = next(row for row in reversed(rows) if row['tag'] == tag)
    assert row['exit'] == 0, (tag, row)
    return row


def main():
    host = json.loads((OUT / 'controls-results.json').read_text())
    native = json.loads((OUT / 'native-results.json').read_text())
    apple_root = ARCH / 'apple-discovery-spi'
    apple = json.loads((apple_root / 'remote/final-test-results.json').read_text())
    for result, count in [(host, 16), (native, 6), (apple, 5)]:
        assert result['tests'] == count and result['failures'] == 0 and result['errors'] == 0
    rows = json.loads((OUT / 'commands.json').read_text())
    selected = [latest(rows, tag) for tag in ['controls-run', 'vulkan-consumer-run', 'native-tests-run']]
    remote_rows = json.loads((apple_root / 'remote/final-commands.json').read_text())
    assert len(remote_rows) == 6 and all(row['exit'] == 0 for row in remote_rows)
    closures = [latest(rows, tag)['command'] for tag in
                ['controls-link', 'vulkan-consumer-link', 'native-tests-link']]
    objects = sorted({Path(arg).resolve() for closure in closures for arg in closure
                      if Path(arg).suffix.lower() == '.obj' and Path(arg).is_file()})
    staged = json.loads((apple_root / 'staged-sources.json').read_text())
    assert [row['path'] for row in staged if not (ROOT / row['path']).is_file()] == ['run_remote.py']
    sources = sorted(set(SOURCES) | {row['path'] for row in staged
                                    if row['path'] != 'run_remote.py'})
    dump('final-identities.json', {
        'sources': [identity(ROOT / name) for name in sources],
        'actual_windows_link_objects': [identity(path) for path in objects],
        'apple_link_identities': [
            'apple-discovery-spi/remote/native-tests-final-identities.json',
            'apple-discovery-spi/remote/finite-native-final-identities.json'],
    })
    dump('summary.json', {
        'scope': 'Real native replay transfers, constrained fragment discovery and shared cold adapters; goal remains active',
        'final_windows_controls': host,
        'final_vulkan_native': native,
        'final_apple_native': apple,
        'final_windows_run_commands': selected,
        'final_apple_commands': remote_rows,
        'changes': [
            'Discovery ABI22 supplies actual target/provider/domain eligibility without a compatibility overload',
            'Shared O(V+E) fragment discovery preserves the external entry frontier and contractibility',
            'Selected native fragments ignore unrelated graph effects; live control-only fragments retain actual terminal work',
            'Actual Vulkan copy artifacts reuse original prepared/Invocation/Completion and compute queue authority',
            'Native spans bind/record cold; strict same-slot replay submits the original Run without record/allocation/host waits',
            'CPU/Vulkan finite consumer uses one common compile/Invocation chain; old thin variant wrapper removed',
            'Cold native adapters retain the actual source capability and admission while carrying compile-local configuration',
        ],
        'actual_consumers': [
            'Windows CPU -> Vulkan -> CPU, exact rows1/4, one cold binding and two strict submits with differing contents',
            'Checked Vulkan Gather failure suppresses control successor and preserves CPU sentinel output',
            'Original one-time CopyProgram and replay CopyRecording pending/settled-completion/close cases',
            'Mac16,12 native real two-fragment deferred outputs, held old lease, checked failure and four rejected invalid adapters',
            'Mac16,12 native-only finite shapes and control failure/success',
        ],
        'retained_failures': [
            'Initial Windows link mixed a superseded ggml object; driver closure corrected, SDK not rebuilt',
            'Initial Vulkan fixture incorrectly expected a settled detached Completion to block later replay',
            'Original Apple fixture expected two regions after legal fusion became possible',
            'First Apple cold adapter was rejected by the previous inconsistent native adapter contract',
        ],
        'limits': [
            'No throughput claim; entry-frontier improvement is structural scheduling evidence',
            'No SDK/shader rebuild, broad test matrix, new Linux run or complete Qwen numerical/performance acceptance',
            'Native Vulkan replay copy currently requires actual same-Runtime backing and four-byte geometry',
            'Driver-private storage remains unknown; managed native maths retains its actual allocation/runtime contract',
            'Same-plan immutable replicas, remaining CPU/Apple/cross-Runtime/page/custom migrations and model functional review remain',
        ],
    })
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sources:
            archive.write(ROOT / name, 'final-source/' + name)
        for name in STAGES:
            for path in sorted((ARCH / name).rglob('*')):
                if not path.is_file() or '__pycache__' in path.parts:
                    continue
                if path.name in {'archive.json', 'cleanup.json', 'cleanup-result.json'}:
                    continue
                if path.suffix.lower() in {'.py', '.json', '.log', '.cc', '.h', '.diff', '.patch', '.txt', '.md'}:
                    archive.write(path, 'stages/' + path.relative_to(ARCH).as_posix())
        # Exact deployed source snapshots contain project code only, never SDKs or objects.
        for name in ['minimal-sources.tar.gz', 'test-update.tar.gz', 'final-update.tar.gz']:
            path = apple_root / name
            with tarfile.open(path) as source_archive:
                assert all(member.isfile() and not Path(member.name).is_absolute()
                           and '..' not in Path(member.name).parts
                           and Path(member.name).suffix in {'.h', '.cc', '.mm', '.py', '.json'}
                           for member in source_archive.getmembers())
            archive.write(path, 'deployed-apple/' + name)
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
    receipt = identity(DEST)
    dump('archive.json', receipt)
    allowed = [ARCH / name for name in STAGES]
    files = [identity(path) for stage in allowed for path in sorted(stage.iterdir())
             if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.lib', '.exp'}]
    dump('cleanup.json', {'evidence': receipt['path'],
        'allowed': [stage.relative_to(ROOT).as_posix() for stage in allowed], 'files': files})
    print(json.dumps({'archive': receipt, 'reclaim_files': len(files),
                      'reclaim_bytes': sum(row['bytes'] for row in files)}))


if __name__ == '__main__':
    main()
