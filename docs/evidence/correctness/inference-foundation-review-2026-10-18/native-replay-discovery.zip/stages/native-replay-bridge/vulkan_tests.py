from pathlib import Path
import json
import os
import build

ROOT, OUT, b = build.ROOT, build.OUT, build.b
ARCH = OUT.parent
history = json.loads((OUT / 'commands.json').read_text())
old = next(row['command'] for row in reversed(history)
           if row['tag'] == 'vulkan-consumer-link' and row['exit'] == 0)
host = next(row['command'] for row in reversed(history)
           if row['tag'] == 'controls-link' and row['exit'] == 0)
command = [arg for arg in old if not arg.startswith(('/OUT:', '/MAP:'))
           and Path(arg).name != 'consumer-replay.obj']
command += [arg for arg in host if Path(arg).name in {'gtest.lib', 'gtest_main.lib'}]
command += [str(ARCH / 'vulkan-replay-copy-test/native-region-detached-test.obj'),
            str(ARCH / 'vulkan-replay-copy-test/copy-program-test.obj'),
            '/OUT:' + str(OUT / 'native-tests.exe'), '/MAP:' + str(OUT / 'native-tests.map')]
b.run('native-tests-link', command)
torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
b.run('native-tests-run', [OUT / 'native-tests.exe', '--gtest_color=no',
    '--gtest_filter=VulkanNativeRegion.*:VulkanCopyProgram.TwoSlotsPhaseReadyOldResultsAndReplayKeepActualMetadataFixed',
    '--gtest_output=json:' + str(OUT / 'native-results.json')])
