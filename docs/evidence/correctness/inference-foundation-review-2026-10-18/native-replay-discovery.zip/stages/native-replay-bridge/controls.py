from pathlib import Path
import json
import os
import sys
import build

ROOT, OUT, b = build.ROOT, build.OUT, build.b
ARCH = OUT.parent
previous = json.loads((ARCH / 'canonical-constants/commands.json').read_text())
old = next(row['command'] for row in reversed(previous) if row['tag'] == 'controls-link')
replacements = {name + '.obj': OUT / (name + '.obj') for name in
                ['executable', 'execution_source', 'resources', 'region_access',
                 'constant_artifact', 'region_provider_test']}
replacements['ggml-region.obj'] = ARCH / 'region-entry-frontier/cpu/ggml_region.obj'
replacements['graph-batch.obj'] = ARCH / 'region-discovery-spi/graph-batch.obj'
command = []
for arg in old:
    if arg.upper().startswith('/OUT:'):
        command.append('/OUT:' + str(OUT / 'controls.exe'))
    elif arg.upper().startswith('/MAP:'):
        command.append('/MAP:' + str(OUT / 'controls.map'))
    else:
        name = Path(arg).name.lower()
        # Prior selected fixture/cache objects have descriptive phase names.
        if name.startswith('region_provider_test') and name.endswith('.obj'):
            command.append(str(ARCH / 'region-entry-frontier/test/region_provider_test.obj'))
        elif name.startswith('constant_artifact') and name.endswith('.obj') and 'cache_test' not in name:
            command.append(str(OUT / 'constant_artifact.obj'))
        else:
            command.append(str(replacements.get(name, arg)))
b.run('controls-link', command)
torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
selected = sys.argv[1]
b.run('controls-run', [OUT / 'controls.exe', '--gtest_color=no',
    '--gtest_filter=' + selected, '--gtest_output=json:' + str(OUT / 'controls-results.json')])
