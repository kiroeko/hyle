from pathlib import Path
import json
import os
import build

ROOT, OUT, b = build.ROOT, build.OUT, build.b
ARCH = OUT.parent
history = json.loads((ARCH / 'finite-native-migration/commands.json').read_text())
base = next(row['command'] for row in reversed(history)
            if row['tag'] == 'vulkan-consumer-link' and row['exit'] == 0)
controls = json.loads((OUT / 'commands.json').read_text())
host = next(row['command'] for row in reversed(controls)
            if row['tag'] == 'controls-link' and row['exit'] == 0)
replacements = {name + '.obj': OUT / (name + '.obj') for name in
                ['executable', 'execution_source', 'resources', 'region_access', 'constant_artifact']}
command, seen = [base[0]], {base[0]}
for arg in base[1:] + host[1:]:
    path = Path(arg)
    name = path.name.lower()
    if arg.startswith(('/OUT:', '/MAP:')) or 'test' in name:
        continue
    if name in replacements:
        arg = str(replacements[name])
    elif name.startswith('constant_artifact') and name.endswith('.obj'):
        arg = str(OUT / 'constant_artifact.obj')
    elif path.parent.name == 'finite-native-migration' and name in {
            'vulkan-source.obj', 'vulkan-region.obj', 'vulkan-consumer.obj'}:
        continue
    if arg not in seen:
        seen.add(arg)
        command.append(arg)
for path in [ARCH / 'vulkan-replay-copy/vulkan-source-final.obj',
             ARCH / 'vulkan-replay-copy/copy-recording.obj',
             ARCH / 'vulkan-replay-copy/copy-program.obj',
             ARCH / 'region-entry-frontier/vulkan/native_region.obj',
             ARCH / 'cpu-vulkan-finite/consumer-replay.obj']:
    command.append(str(path))
command += ['/OUT:' + str(OUT / 'vulkan-consumer.exe'),
            '/MAP:' + str(OUT / 'vulkan-consumer.map')]
b.run('vulkan-consumer-link', command)
torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
b.run('vulkan-consumer-run', [OUT / 'vulkan-consumer.exe'])
