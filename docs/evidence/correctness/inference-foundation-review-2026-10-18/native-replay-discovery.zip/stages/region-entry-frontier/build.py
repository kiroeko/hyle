from pathlib import Path
import hashlib,importlib.util,json,sys
ROOT=Path(__file__).resolve().parents[3]; STAGE=Path(__file__).resolve().parent
name=sys.argv[1];OUT=STAGE/name;OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('driver',ROOT/'.scratch/architecture-refactor-2026-10-18/region-adapter/run.py'); b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.OUT=OUT
cases={
 'test':('tests/graph/region_provider_test.cc','.scratch/architecture-refactor-2026-10-18/retry-instance-alignment/domain-instantiation.json',None),
 'vulkan':('src/graph_route_vulkan/native_region.cc','.scratch/architecture-refactor-2026-10-18/native-fragment-discovery/commands.json','vulkan-region-compile'),
 'cpu':('src/graph_route_cpu/ggml_region.cc','.scratch/architecture-refactor-2026-10-18/region-discovery-spi/commands.json','cpu-ggml-region-compile'),
 'cuda':('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','.scratch/architecture-refactor-2026-10-18/region-discovery-spi/commands.json','cuda-ggml-region-compile')}
source,history,tag=cases[name];rows=json.loads((ROOT/history).read_text());cc=rows['command'] if tag is None else next(row['command'] for row in reversed(rows) if row['tag']==tag)
flags=[arg for arg in cc[1:] if not arg.lower().startswith('/fo') and not arg.endswith('.cc')];obj=OUT/(Path(source).stem+'.obj')
b.run(name+'-compile',[cc[0],*flags,ROOT/source,'/Fo'+str(obj)])
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(OUT/'identities.json').write_text(json.dumps([identity(ROOT/source),identity(ROOT/'src/graph/region_discovery.h'),identity(ROOT/'include/hyle/graph/region_provider.h'),identity(obj)],indent=2)+'\n')
