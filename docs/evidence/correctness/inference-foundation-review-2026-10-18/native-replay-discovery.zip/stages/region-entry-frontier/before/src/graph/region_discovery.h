#pragma once

#include <cstdint>
#include <span>

#include "hyle/container/small_vector.h"
#include "hyle/graph/graph.h"

namespace hyle::graph::detail {

// A native region must not leave and re-enter through another provider.
// Discover maximal legal prefixes in topological order rather than rejecting
// the entire eligible set. Independent interleaved nodes do not split a region.
// Each edge is visited once; epoch marks avoid clearing graph-sized scratch
// after every boundary. The compiler still validates every emitted proposal.
template <class Eligible, class Emit>
Status discover_regions(const Graph &graph, mem::AllocatorRef allocator,
                        Eligible eligible, Emit emit) noexcept {
  container::SmallVector<NodeId, 16, mem::AllocatorRef> nodes(allocator);
  container::SmallVector<std::int64_t, 16, mem::AllocatorRef> marks(allocator);
  if (!nodes.try_resize(graph.node_count()) ||
      !marks.try_resize(graph.node_count()))
    return Status::ResourceExhausted("graph region discovery metadata");
  std::int64_t epoch = 1;
  std::size_t size = 0;
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    HYLE_ASSIGN_OR_RETURN(auto node, graph.node_id(i));
    HYLE_ASSIGN_OR_RETURN(auto selected, eligible(node));
    bool from_inside = false, from_outside = false;
    const auto predecessor = [&](NodeId id) noexcept {
      from_inside |= marks[id.ordinal()] == epoch;
      from_outside |= marks[id.ordinal()] == -epoch;
    };
    HYLE_ASSIGN_OR_RETURN(auto inputs, graph.node_input_count(node));
    for (std::size_t input = 0; input < inputs; ++input) {
      HYLE_ASSIGN_OR_RETURN(auto value, graph.node_input(node, input));
      if (value.kind() == ValueKind::kNodeOutput) {
        HYLE_ASSIGN_OR_RETURN(auto producer, graph.producer(value));
        predecessor(producer);
      }
    }
    HYLE_ASSIGN_OR_RETURN(auto dependencies, graph.node_dependency_count(node));
    for (std::size_t dependency = 0; dependency < dependencies; ++dependency) {
      HYLE_ASSIGN_OR_RETURN(auto before,
                            graph.node_dependency(node, dependency));
      predecessor(before);
    }
    if (selected && from_outside) {
      HYLE_ASSIGN_OR_RETURN(auto more, emit(std::span(nodes).first(size)));
      if (!more)
        return Status::Ok();
      size = 0;
      ++epoch;
    }
    if (selected) {
      nodes[size++] = node;
      marks[i] = epoch;
    } else {
      marks[i] = from_inside || from_outside ? -epoch : 0;
    }
  }
  if (size != 0) {
    HYLE_ASSIGN_OR_RETURN(auto more, emit(std::span(nodes).first(size)));
    (void)more;
  }
  return Status::Ok();
}

} // namespace hyle::graph::detail
