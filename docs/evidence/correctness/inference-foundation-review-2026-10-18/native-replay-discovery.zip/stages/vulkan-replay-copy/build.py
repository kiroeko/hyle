from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('driver',
    ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
history = json.loads((ROOT / '.scratch/architecture-refactor-2026-10-18/vulkan-constant-copy/commands.json').read_text())
cc = next(row['command'] for row in history if row['tag'] == 'source-compile')
flags = [arg for arg in cc[1:] if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]

if __name__ == '__main__':
    for source, name in [
        ('src/compute_route_vulkan/vulkan_copy_recording.cc', 'copy-recording'),
        ('src/graph_route_vulkan/execution_source.cc', 'vulkan-source'),
        ('src/compute_route_vulkan/vulkan_copy_program.cc', 'copy-program'),
    ]:
        b.run(name + '-compile', [cc[0], *flags, ROOT / source, '/Fo' + str(OUT / (name + '.obj'))])
