from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('driver',
    ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT

def cached(path, filename):
    rows = json.loads((ROOT / path).read_text())
    return next(row['command'] for row in reversed(rows)
        if any(str(arg).replace('\\', '/').endswith('/' + filename)
               for arg in row['command']))

def flags(command):
    return [arg for arg in command[1:]
        if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if __name__ == '__main__':
    identities = []
    cases = [
        ('src/graph_route_cpu/ggml_region.cc', 'cpu-ggml-region',
         cached('.scratch/architecture-refactor-2026-10-18/finite-exact/commands.json', 'ggml_region.cc')),
        ('src/graph_batch/batch.cc', 'graph-batch',
         cached('.scratch/architecture-refactor-2026-10-18/finite-exact/commands.json', 'batch.cc')),
        ('src/graph_provider_ggml_cuda/ggml_cuda_region.cc', 'cuda-ggml-region',
         cached('.scratch/architecture-refactor-2026-10-18/cuda-finite-runtime/commands.json', 'ggml_cuda_region.cc')),
    ]
    # This TU uses the existing oneDNN seam headers, not vendor SDK headers.
    # Preserve its cached CMake target definitions/flags/includes exactly.
    ninja = ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-providers/build.ninja'
    lines = ninja.read_text().splitlines()
    start = next(i for i, line in enumerate(lines)
        if line.startswith('build ') and 'onednn_region_provider.cc.obj:' in line)
    target = dict(line.strip().split(' = ', 1) for line in lines[start+1:start+8]
                  if ' = ' in line)
    one_flags = ['/nologo', '/c']
    for field in ['DEFINES', 'FLAGS', 'INCLUDES']:
        one_flags += target[field].split()
    cases += [('src/graph_provider_onednn/onednn_region_provider.cc', 'onednn-region',
               [cases[0][2][0], *one_flags])]
    for source, name, command in cases:
        output = OUT / (name + '.obj')
        row = {'source': source, 'source_sha256': digest(ROOT / source),
               'spi_sha256': digest(ROOT / 'include/hyle/graph/region_provider.h'),
               'discovery_sha256': digest(ROOT / 'src/graph/region_discovery.h')}
        b.run(name + '-compile', [command[0], *flags(command), ROOT / source, '/Fo' + str(output)])
        row.update(object=str(output), object_sha256=digest(output))
        identities.append(row)
        (OUT / 'identities.json').write_text(json.dumps(identities, indent=2)+'\n')
