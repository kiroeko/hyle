from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('driver',
    ROOT / '.scratch/architecture-refactor-2026-10-18/vulkan-replay-copy/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.b.OUT = OUT

if __name__ == '__main__':
    identities = []
    for source, name in [
        ('tests/graph_route_vulkan/native_region_test.cc', 'native-region-test'),
        ('tests/compute_route_vulkan/copy_program_test.cc', 'copy-program-test'),
    ]:
        output = OUT / (name + '.obj')
        source_path = ROOT / source
        digest = hashlib.sha256(source_path.read_bytes()).hexdigest()
        b.b.run(name + '-compile', [b.cc[0], *b.flags, source_path, '/Fo' + str(output)])
        identities.append({'source': source, 'source_sha256': digest,
            'object': str(output), 'object_sha256': hashlib.sha256(output.read_bytes()).hexdigest()})
        (OUT / 'identities.json').write_text(json.dumps(identities, indent=2)+'\n')
