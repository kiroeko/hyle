from pathlib import Path
import importlib.util, json

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base_compile',OUT/'compile.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
if __name__=='__main__':
    source=base.ROOT/'tests/graph/route_symmetry_vulkan.cc'
    before=base.identity(OUT/'consumer.obj')
    base.b.run('hybrid-replay-consumer-compile',[base.cc[0],*base.flags,'/DHYLE_FOUNDATION_A_HYBRID=1',source,
        '/Fo'+str(OUT/'consumer-replay.obj')])
    assert base.identity(OUT/'consumer.obj')==before
    (OUT/'compile-replay-identity.json').write_text(json.dumps(dict(
        result='TU compile only; root owns matched current-core link/run',
        checks=['Existing pure-native/one-way finite/control retained',
            'CPU Abs -> Vulkan Neg -> CPU Neg; shapes 1/4; two changed-payload episodes per original slot',
            'Exactly one cold prepare per slot; no bind/prepare between strict submits; raw float output oracle',
            'Vulkan checked control failure leaves all CPU output bytes at float 99'],
        source=base.identity(source),object=base.identity(OUT/'consumer-replay.obj'),prior_object=before),indent=2)+'\n')
