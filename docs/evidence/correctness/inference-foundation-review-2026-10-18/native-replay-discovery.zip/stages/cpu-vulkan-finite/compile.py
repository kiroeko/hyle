from pathlib import Path
import hashlib, importlib.util, json

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('driver',ROOT/'.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.OUT=OUT
history=json.loads((ROOT/'.scratch/architecture-refactor-2026-10-18/vulkan-constant-copy/commands.json').read_text())
cc=next(row['command'] for row in history if row['tag']=='source-compile')
flags=[arg for arg in cc[1:] if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]

def identity(path):
    p=Path(path)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

if __name__=='__main__':
    source=ROOT/'tests/graph/route_symmetry_vulkan.cc'
    b.run('hybrid-finite-consumer-compile',[cc[0],*flags,'/DHYLE_FOUNDATION_A_HYBRID=1',source,
        '/Fo'+str(OUT/'consumer.obj')])
    (OUT/'compile-identity.json').write_text(json.dumps(dict(
        result='TU compile only; root owns current core/Source link and execution',
        sources=[identity(ROOT/name) for name in ['tests/graph/route_symmetry_vulkan.cc',
            'include/hyle/graph/cpu_vulkan.h','include/hyle/graph/region_provider.h']],
        object=identity(OUT/'consumer.obj')),indent=2)+'\n')
