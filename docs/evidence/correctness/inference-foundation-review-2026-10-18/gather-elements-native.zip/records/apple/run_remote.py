from pathlib import Path
import hashlib,json,subprocess,time,re,sys
ROOT=Path(__file__).resolve().parent
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
HIGH=ROOT.parent/'inference-feature-completion-20261018-apple-highdim'
MTP=ROOT.parent/'mtp-gdn-snapshots-20261018'
STRIDE=ROOT.parent/'library-review-20261018-apple-native-mask-strides/candidate/steel_attention.o'
FLAGS=['-O3','-DNDEBUG','-std=c++23','-arch','arm64','-DHYLE_STATIC','-DMLX_STATIC','-DHYLE_COMPUTE_APPLE=1','-DHYLE_TEST_MLA_APPLE=1','-Wall','-Wextra','-Wpedantic','-Werror']
macros=set().union(*(set(re.findall(r'\bHYLE_[A-Z0-9_]+_API\b',p.read_text())) for p in (ROOT/'include').rglob('*.h')))
FLAGS+=['-D'+m+'=' for m in sorted(macros)]
INC=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute'),'-I'+str(ROOT/'src/compute_route_apple'),'-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp'),'-isystem','/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include']
records=json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
def run(tag,args):
 args=list(map(str,args));attempt=sum(x['tag']==tag for x in records);prefix=('attempt'+str(attempt)+'-') if attempt else ''
 t=time.monotonic();p=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=180)
 (ROOT/(prefix+tag+'.stdout.log')).write_bytes(p.stdout);(ROOT/(prefix+tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=args,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-t));(ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-2500:],p.stderr.decode(errors='replace')[-6500:]);sys.exit(p.returncode)
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
model=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip();assert model=='Mac16,12'
if not (ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
assert (ROOT/'mlx.metallib').resolve()==(SDK/'lib/mlx.metallib').resolve()
(ROOT/'hardware.json').write_text(json.dumps(dict(model=model,hardware=subprocess.check_output(['/usr/sbin/sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True),compiler=subprocess.check_output(['/usr/bin/clang++','--version'],text=True),SDK_copied=False,native_compiled=False,metallib=str((ROOT/'mlx.metallib').resolve())),indent=2)+'\n')
objects=[]
for source,name in [('src/compute_route_apple/apple_tensor.cc','tensor'),('src/compute_route_apple/apple_mature_indexing.cc','indexing'),('tests/compute_route_apple/gather_elements_test.cc','test')]:
 obj=ROOT/(name+'.o')
 if not obj.exists() or obj.stat().st_mtime<(ROOT/source).stat().st_mtime:run(name+'-compile',['/usr/bin/clang++',*FLAGS,*INC,'-c',ROOT/source,'-o',obj])
 objects.append(obj)

retained=[HIGH/(n+'.o') for n in ['apple_context','apple_operations','fast','native-host']]+[MTP/(n+'.o') for n in ['recurrent','native','ops','ops-tensor_desc.cc','ops-low_precision.cc','ops-weight_decode.cc','ops-sampling_ops.cc']]+[STRIDE]
LIBS=[SDK/'lib'/('lib'+n+'.a') for n in ['hyle_graph_route_cpu_apple','hyle_graph','hyle_compute_route_apple','hyle_graph_route_apple','hyle_compute_backend_cpu','hyle_compute_provider_native','hyle_compute_stream','hyle_compute_state','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_simd','hyle_sched','hyle_container','hyle_mem_vm','hyle_mem','mimalloc_static','hyle_platform_thread','hyle_time','hyle_platform','hyle_error','hyle_compute_provider_ggml_metal','hyle_compute_ggml_runtime','ggml','ggml-metal','ggml-base','mlx']]
for p in [*retained,*LIBS]:assert p.is_file(),p
TORCH=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sdks/torch-cpu/Darwin-be0642231d2008c7b90071fc0898d82a0c002d47f38350ebf3ed779fc01972d7/libtorch/lib')
LIBS += [TORCH/n for n in ['libtorch.dylib','libtorch_cpu.dylib','libc10.dylib']]
CORE=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
LIBS += [CORE/'lib/libgtest_main.a',CORE/'lib/libgtest.a']
exe=ROOT/'gather-elements'
run('link',['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64','-o',exe,*objects,*retained,*LIBS,'-Wl,-rpath,'+str(TORCH),'-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore','-Wl,-map,'+str(ROOT/'gather-elements.map')])
(ROOT/'identities.json').write_text(json.dumps([identity(p) for p in [*objects,*retained,*LIBS,exe]],indent=2)+'\n')
run('tests',[exe,'--gtest_filter=AppleGatherElements.*'])
(ROOT/'cleanup-candidates.json').write_text(json.dumps(dict(host='kiro@172.22.10.198',files=[identity(p) for p in [*objects,exe]],performed=False,retain='all sources/logs/maps/data/archives and SDK/shared retained objects'),indent=2)+'\n')
