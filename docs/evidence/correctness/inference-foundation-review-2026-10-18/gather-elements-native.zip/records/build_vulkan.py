from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent/'vulkan';OUT.mkdir(exist_ok=True)
OLD=ROOT/'.scratch/inference-feature-completion-2026-10-18/vulkan-highdim'
cached=json.loads((OLD/'commands.json').read_text())
base=next(x['command'] for x in cached if x['label']=='region-compile')
cl=Path(base[0]);link=cl.with_name('link.exe')
flags=[x for x in base[1:] if not x.startswith('/Fo') and not x.endswith('region.cc')]
flags+=['/I'+str(ROOT),'/I'+str(ROOT/'src/graph_route_cpu_vulkan')]
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':str(cl),'CMAKE_C_COMPILER':str(cl)})
env['PATH']=str(ROOT/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
env['VSLANG']='1033';env['DISABLE_VULKAN_OBS_CAPTURE']='1';env['VK_LOADER_LAYERS_DISABLE']='~all~'
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,cmd):
 cmd=list(map(str,cmd));attempt=sum(x['tag']==tag for x in records);suffix=('attempt'+str(attempt)+'-') if attempt else ''
 start=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=180)
 (OUT/(suffix+tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(suffix+tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-start));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-5000:],p.stderr.decode(errors='replace')[-2000:]);raise SystemExit(p.returncode)
objects=[]
for rel,name in [('src/compute_provider_ggml_vulkan/region.cc','region'),('src/compute_route_vulkan/vulkan_region.cc','route-region'),('src/compute_route_vulkan/vulkan_program.cc','program'),('src/compute_route_vulkan/vulkan_operations.cc','operations'),('src/graph_route_vulkan/vulkan_lowering.cc','graph-lowering'),('tests/compute_route_vulkan/gather_elements_test.cc','test')]:
 obj=OUT/(name+'.obj')
 if not obj.exists() or obj.stat().st_mtime<(ROOT/rel).stat().st_mtime:
  run(name+'-compile',[cl,*flags,ROOT/rel,'/Fo'+str(obj)])
 objects.append(obj)


oldlink=next(x['command'] for x in reversed(cached) if x['label']=='test-link')
libs=[x for x in oldlink if x.endswith('.lib')]
for n in ['hyle_graph','hyle_graph_batch','hyle_compute_backend_cpu','hyle_compute_provider_native','hyle_sched','hyle_compute_stream','hyle_mem_vm','hyle_simd']:
 p=ROOT/'.scratch/build-compute-v2-dev/bin'/(n+'.lib')
 if str(p) not in libs:libs.append(str(p))
libs += ['ws2_32.lib']
torch=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib')
libs += [str(torch/n) for n in ['torch.lib','torch_cpu.lib','c10.lib']]
env['PATH']=str(torch)+os.pathsep+env['PATH']
libs += [str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
exe=OUT/'gather-elements.exe'
run('link',[link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/'gather-elements.map'),*objects,OLD/'native-host.obj',*libs])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in [*objects,OLD/'native-host.obj',exe]],indent=2)+'\n')
run('tests',[exe,'--gtest_filter=VulkanGatherElements.*'])
