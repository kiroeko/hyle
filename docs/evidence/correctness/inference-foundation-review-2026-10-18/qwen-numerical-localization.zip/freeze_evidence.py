"""Archive only the completed small Qwen numerical diagnosis; no model execution."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
TARGET = ROOT / "docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-numerical-localization.zip"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(name):
    return json.loads((STAGE / name).read_text(encoding="utf-8"))


assert not TARGET.exists(), "Never overwrite an existing evidence archive"
assert load("summary.json")["status"] == "diagnosis_complete_numerical_acceptance_still_open"
files = {}


def add(path, member):
    path = Path(path)
    assert path.is_file(), path
    assert not member.startswith("/") and ".." not in Path(member).parts
    assert member not in files, member
    files[member] = path.read_bytes()


# All outputs were frozen before packaging; verify every one against that receipt.
for row in load("result-identities.json"):
    path = ROOT / row["path"]
    raw = path.read_bytes()
    assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], path
    relative = path.relative_to(STAGE).as_posix()
    assert path.suffix in {".py", ".json", ".log", ".csv", ".txt", ".bf16", ".f32"}, path
    if path.suffix in {".bf16", ".f32"}:
        assert path.parent == STAGE / "torch-first-block", path
        assert len(raw) <= 1048576, path
    add(path, "diagnosis/" + relative)
add(STAGE / "result-identities.json", "diagnosis/result-identities.json")
add(Path(__file__), "freeze_evidence.py")

# A small number of exact Hyle sources/input metadata are enough to interpret
# and reproduce these scripts. External SDK/library sources are identified only.
source_rows = load("source-identities.json")
source_by_path = {Path(row["path"]).as_posix(): row for row in source_rows}
for relative in ("tools/qwen35_text/main.cc", "tools/qwen35_text/reference.py",
                 "src/compute_provider_ggml_cuda/tensor_program.cc"):
    path = ROOT / relative
    assert sha(path.read_bytes()) == source_by_path[relative]["sha256"], relative
    add(path, "source/" + relative)
input_base = ROOT / ".scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2"
for name in ("weights.tsv", "input.json", "prompt.ids", "continuation.ids"):
    add(input_base / name, "inputs/" + name)

manifest = {
    "status": "diagnosis_only_numerical_acceptance_open",
    "scope": "Completed small numerical analysis; no product changes, GPU run, compilation or deletion during packaging.",
    "raw_payload": "Only this round's one-block activation/state outputs, not raw weights or complete 24-layer traces.",
    "excluded": ["model/checkpoint/weight payload", "SDK/vendor/library trees", "full150-tensor traces", "objects/executables/maps/libraries", "nested archives"],
    "entries": [{"path": key, "bytes": len(raw), "sha256": sha(raw)}
                for key, raw in sorted(files.items())],
}
files["archive-manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
assert all(Path(name).suffix not in {".obj", ".o", ".exe", ".dll", ".lib", ".a", ".map", ".exp", ".zip", ".gz", ".safetensors", ".gguf"}
           for name in files)
TARGET.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(TARGET, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for member, raw in sorted(files.items()):
        archive.writestr(member, raw)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(files)
    for member, raw in files.items():
        assert archive.read(member) == raw, member
receipt = {
    "archive": str(TARGET.relative_to(ROOT)), "bytes": TARGET.stat().st_size,
    "sha256": sha(TARGET.read_bytes()), "entries": len(files),
    "uncompressed_bytes": sum(map(len, files.values())),
    "entry_bytes_and_sha_verified": True,
    "original_frozen_result_identities_verified": True,
    "product_source_snapshots_verified": True,
    "no_model_sdk_full_trace_object_library_or_nested_archive": True,
    "raw_activation_files": len([x for x in files if Path(x).suffix in {".bf16", ".f32"}]),
    "raw_activation_bytes": sum(len(v) for k, v in files.items() if Path(k).suffix in {".bf16", ".f32"}),
    "numerical_acceptance": "open; neither F32 arithmetic differences nor approximately2% full-model differences marked PASS",
}
(STAGE / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
