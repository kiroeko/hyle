"""One official Torch block, against already executed Hyle boundary probes.

No Hyle product changes, full-model construction, SDK build or large input copy.
"""
from pathlib import Path
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',
 TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
import hashlib,importlib.util,json,time
import numpy as np
import torch
from transformers.models.qwen3_5 import modeling_qwen3_5 as impl
from transformers.models.qwen3_5.configuration_qwen3_5 import Qwen3_5TextConfig

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
BASE=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text'
CURRENT=ROOT/'.scratch/architecture-refactor-2026-10-18/generic-progress/qwen'
reference=json.loads((BASE/'reference/reference.json').read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(impl.__file__)==reference['model_source_sha256']
reference_script=ROOT/'tools/qwen35_text/reference.py'
assert sha(reference_script)==reference['reference_sha256']
spec=importlib.util.spec_from_file_location('original_qwen_reference',reference_script)
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
manifest=BASE/'inputs-v2/weights.tsv';lines=manifest.read_text().splitlines();shard=Path(lines[1])
assert lines[2]==reference['source_id']
rows={}
for line in lines[3:]:
 f=line.split('\t');rank=int(f[2]);rows[f[0]]=(f[1],tuple(map(int,f[3:3+rank])),int(f[3+rank]),int(f[4+rank]))
reads=[]
def weight(name):
 dtype,shape,offset,size=rows['model.language_model.'+name]
 with shard.open('rb') as stream:stream.seek(offset);raw=bytearray(stream.read(size))
 assert len(raw)==size
 reads.append(dict(name=name,dtype=dtype,shape=shape,offset=offset,bytes=size,sha256=hashlib.sha256(raw).hexdigest()))
 return torch.frombuffer(raw,dtype=torch.bfloat16 if dtype=='BF16' else torch.float32).reshape(shape)
torch.set_num_threads(2);torch.set_num_interop_threads(1)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=False
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction=False
config=Qwen3_5TextConfig(**json.loads((shard.parent/'config.json').read_bytes())['text_config'])
config._attn_implementation='eager'
with torch.device('meta'):layer=impl.Qwen3_5DecoderLayer(config,0)
parameters={name.removeprefix('model.language_model.layers.0.'):weight(name.removeprefix('model.language_model.'))
 for name in rows if name.startswith('model.language_model.layers.0.')}
layer.load_state_dict(parameters,strict=True,assign=True);layer.eval().to('cuda');del parameters
layer.linear_attn.forward=__import__('types').MethodType(original.fixed_recurrent_forward,layer.linear_attn)
captured={}
def pre(name):return lambda module,inputs:captured.__setitem__(name,inputs[0].detach())
def post(name):return lambda module,inputs,output:captured.__setitem__(name,output.detach())
layer.linear_attn.in_proj_qkv.register_forward_hook(post('00-qkv'))
layer.linear_attn.out_proj.register_forward_pre_hook(pre('02-out-proj-input'))
layer.linear_attn.out_proj.register_forward_hook(post('03-out-proj-output'))
layer.post_attention_layernorm.register_forward_pre_hook(pre('06-post-attn-residual'))
layer.post_attention_layernorm.register_forward_hook(post('07-post-attn-norm'))
layer.mlp.gate_proj.register_forward_hook(post('08-gate-proj-output'))
layer.mlp.up_proj.register_forward_hook(post('09-up-proj-output'))
layer.mlp.down_proj.register_forward_pre_hook(pre('04-down-proj-input'))
layer.register_forward_hook(post('05-layer-output'))
original_rule=impl.torch_recurrent_gated_delta_rule
def rule(query,key,value,g,beta,initial_state,output_final_state,use_qk_l2norm_in_kernel=False):
 for name,tensor in [('q',query),('k',key),('v',value),('g',g),('beta',beta)]:captured['gdn-input-'+name]=tensor.detach()
 output,state=original_rule(query,key,value,g,beta,initial_state,output_final_state,use_qk_l2norm_in_kernel)
 captured['01-gdn-output']=output.detach();captured['gdn-state']=state.detach().transpose(-1,-2).contiguous()
 return output,state
impl.torch_recurrent_gated_delta_rule=rule
tokens=list(map(int,(BASE/'inputs-v2/prompt.ids').read_text().split()))
assert tokens==reference['steps'][0]['input_ids']
dtype,shape,offset,size=rows['model.language_model.embed_tokens.weight'];assert dtype=='BF16'
embedding=[]
with shard.open('rb') as stream:
 for token in tokens:
  stream.seek(offset+token*shape[1]*2);raw=bytearray(stream.read(shape[1]*2))
  embedding.append(torch.frombuffer(raw,dtype=torch.bfloat16))
hidden=torch.stack(embedding).unsqueeze(0).to('cuda')
directory=OUT/'torch-first-block';directory.mkdir(exist_ok=False)
torch.cuda.synchronize();start=time.perf_counter()
with torch.inference_mode():output=layer(hidden,position_embeddings=None)
torch.cuda.synchronize();seconds=time.perf_counter()-start
with torch.device('meta'):norm=impl.Qwen3_5RMSNorm(config.hidden_size,eps=config.rms_norm_eps)
norm.load_state_dict({'weight':weight('layers.1.input_layernorm.weight')},assign=True)
norm.eval().to('cuda');projection=weight('layers.1.linear_attn.in_proj_qkv.weight').to('cuda')
with torch.inference_mode():projected=torch.nn.functional.linear(norm(output),projection)
torch.cuda.synchronize();captured['layer1-conv']=projected[:,-3:].detach().contiguous()
captured['layer0-conv']=captured['00-qkv'][:,-3:].contiguous()

def numpy(tensor):return tensor.detach().float().cpu().numpy().astype(np.float64).reshape(-1)
def load(path):
 raw=Path(path).read_bytes()
 if Path(path).suffix=='.bf16':return (np.frombuffer(raw,dtype='<u2').astype('<u4')<<16).view('<f4').astype(np.float64)
 return np.frombuffer(raw,dtype='<f4').astype(np.float64)
def compare(actual,expected):
 a=numpy(actual);assert a.size==expected.size;d=a-expected;different=np.flatnonzero(a!=expected)
 result=dict(elements=a.size,equal_elements=int(np.count_nonzero(a==expected)),max_abs=float(np.max(np.abs(d))),
  relative_l2=float(np.linalg.norm(d)/np.linalg.norm(expected)),first_mismatch=int(different[0]) if different.size else None)
 if a.size%23==0:
  aa=a.reshape(23,-1);ee=expected.reshape(23,-1)
  result['by_token']=[dict(position=i,equal_elements=int(np.count_nonzero(aa[i]==ee[i])),elements=aa.shape[1],
   relative_l2=float(np.linalg.norm(aa[i]-ee[i])/np.linalg.norm(ee[i]))) for i in range(23)]
 return result
comparisons={};files=[]
for name,tensor in captured.items():
 tensor=tensor.contiguous();path=directory/(name+('.bf16' if tensor.dtype==torch.bfloat16 else '.f32'))
 path.write_bytes(tensor.view(torch.uint8).cpu().numpy().tobytes())
 files.append(dict(path=path.name,shape=list(tensor.shape),dtype=str(tensor.dtype),bytes=path.stat().st_size,sha256=sha(path)))
 candidate=CURRENT/'layer0-probe-01/prefill'/(name+'.bf16')
 if candidate.exists():comparisons[name]=compare(tensor,load(candidate))
sanity={}
for name,existing in [('layer0-conv','layer0.conv.bf16'),('layer1-conv','layer1.conv.bf16'),('gdn-state','layer0.gdn.f32')]:
 sanity[name]=compare(captured[name],load(BASE/'reference/prefill'/existing))
report=dict(kind='one_official_decoder_block_actual_cuda_against_existing_hyle_nine_probes',
 first_block_seconds=seconds,comparisons= dict(sorted(comparisons.items())),full_reference_sanity=sanity,
 runtime=dict(torch=torch.__version__,cuda=torch.version.cuda,gpu=torch.cuda.get_device_name(),
  tf32=torch.backends.cuda.matmul.allow_tf32,bf16_reduced_reduction=torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,
  f16_reduced_reduction=torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction,
  cudnn_tf32=torch.backends.cudnn.allow_tf32),
 source_id=reference['source_id'],model_source=dict(path=impl.__file__,sha256=sha(impl.__file__)),
 reference_script=dict(path=str(reference_script),sha256=sha(reference_script)),
 weight_reads=reads,weight_read_bytes=sum(row['bytes'] for row in reads),files=files,
 scope='Only original block0 plus norm/QKV projection of block1. No attention or other decoder block, no full-model allocation/build.',
 script_sha256=sha(__file__))
(OUT/'first-block-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
for name,row in report['comparisons'].items():print(name,json.dumps({k:v for k,v in row.items() if k!='by_token'}))
print('sanity',json.dumps(sanity));print('weight_read_bytes',report['weight_read_bytes'],'block_seconds',seconds)
