"""Offline existing-trace measurements only: never starts a model or CUDA."""
from pathlib import Path
import os
os.environ.update(OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',OMP_NUM_THREADS='2')
import csv,hashlib,json,re
import numpy as np

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
CURRENT=ROOT/'.scratch/architecture-refactor-2026-10-18/generic-progress/qwen'
PRIOR=ROOT/'.scratch/compute-execution-refactor-2026-10-18/qwen35-ragged'
INPUT=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text'
REF=INPUT/'reference';reference=json.loads((REF/'reference.json').read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):
 raw=Path(path).read_bytes()
 if Path(path).suffix=='.bf16':return (np.frombuffer(raw,dtype='<u2').astype('<u4')<<16).view('<f4')
 return np.frombuffer(raw,dtype='<f4')
def stats(a,b):
 a=np.asarray(a,dtype=np.float64).ravel();b=np.asarray(b,dtype=np.float64).ravel()
 d=a-b;norm=float(np.linalg.norm(b));mismatch=np.flatnonzero(a!=b)
 result=dict(elements=a.size,equal_elements=int(np.count_nonzero(a==b)),
  finite=bool(np.isfinite(a).all() and np.isfinite(b).all()),
  max_abs=float(np.max(np.abs(d))),mean_abs=float(np.mean(np.abs(d))),
  relative_l2=float(np.linalg.norm(d)/norm) if norm else float(np.linalg.norm(d)),
  first_mismatch=int(mismatch[0]) if mismatch.size else None)
 ab=a.astype(np.float32).view(np.uint32);bb=b.astype(np.float32).view(np.uint32)
 if np.all((ab&65535)==0) and np.all((bb&65535)==0):
  def order(bits):
   bits=(bits>>16).astype(np.int32)
   return np.where(bits&32768,(~bits)&65535,bits|32768)
  result['max_bf16_ulp_distance']=int(np.max(np.abs(order(ab)-order(bb))))
 return result
def key(path):
 match=re.match(r'layer(\d+)\.(.*)',path.name)
 return (int(match[1]),match[2]) if match else (24,path.name)
rows=[]
for phase in (r['name'] for r in reference['steps']):
 for path in sorted((REF/phase).iterdir(),key=key):
  expected=load(path);actual=load(CURRENT/'trace-01'/phase/path.name);old=load(PRIOR/'trace-01'/phase/path.name)
  assert actual.size>=expected.size and old.size>=expected.size
  current_tail=actual[expected.size:];old_tail=old[expected.size:]
  actual=actual[:expected.size];old=old[:expected.size]
  row=dict(phase=phase,tensor=path.name,current_vs_reference=stats(actual,expected),
   old_vs_reference=stats(old,expected),current_vs_old=stats(actual,old),
   current_inactive_tail_zero=bool(np.all(current_tail==0)),old_inactive_tail_zero=bool(np.all(old_tail==0)))
  rows.append(row)
conv_row_checks=[]
end_position=0
for step in reference['steps']:
 end_position+=len(step['input_ids'])
 for layer in [0,1,2]:
  name=f'layer{layer}.conv.bf16';actual=load(CURRENT/'trace-01'/step['name']/name).reshape(3,6144)
  expected=load(REF/step['name']/name).reshape(3,6144)
  conv_row_checks.append(dict(phase=step['name'],layer=layer,rows=[
   dict(position=end_position-3+i,**stats(actual[i],expected[i])) for i in range(3)]))
with (OUT/'per-layer.csv').open('w',newline='') as stream:
 writer=csv.writer(stream);writer.writerow(['phase','tensor','current_ref_relL2','old_ref_relL2','current_old_relL2','current_ref_maxAbs','current_ref_equal','elements'])
 for r in rows:writer.writerow([r['phase'],r['tensor'],r['current_vs_reference']['relative_l2'],r['old_vs_reference']['relative_l2'],
  r['current_vs_old']['relative_l2'],r['current_vs_reference']['max_abs'],r['current_vs_reference']['equal_elements'],r['current_vs_reference']['elements']])

def bf16(x):
 x=np.asarray(x,dtype=np.float32);bits=x.view(np.uint32)
 return ((bits+np.uint32(0x7fff)+((bits>>16)&1))&np.uint32(0xffff0000)).view(np.float32)
probe=CURRENT/'layer0-probe-01/prefill'
p={path.stem:load(path) for path in probe.glob('*.bf16')}
gate=p['08-gate-proj-output'];up=p['09-up-proj-output'];product=p['04-down-proj-input']
# F64 evaluates the isolated scalar formula; stored/rounded boundaries remain
# explicit. This does not stand in for the GPU kernel's exact transcendental.
silu=gate.astype(np.float64)/(1+np.exp(-gate.astype(np.float64)))
algebra=dict(silu_mul_with_bf16_boundary=stats(product,bf16(bf16(silu)*up)),
 silu_mul_without_bf16_boundary=stats(product,bf16(silu*up)),
 probe_sources=[dict(path=str(path.relative_to(ROOT)),sha256=sha(path)) for path in sorted(probe.glob('*.bf16'))])

manifest=(INPUT/'inputs-v2/weights.tsv').read_text().splitlines();shard=Path(manifest[1]);weights={}
for line in manifest[3:]:
 fields=line.split('\t');rank=int(fields[2]);weights[fields[0]]=(fields[1],tuple(map(int,fields[3:3+rank])),int(fields[3+rank]),int(fields[4+rank]))
def weight(name):
 dtype,shape,offset,count=weights['model.language_model.'+name]
 with shard.open('rb') as stream:stream.seek(offset);raw=stream.read(count)
 assert len(raw)==count
 x=np.frombuffer(raw,dtype='<u2' if dtype=='BF16' else '<f4')
 if dtype=='BF16':x=(x.astype('<u4')<<16).view('<f4')
 return x.reshape(shape)
tokens=np.loadtxt(INPUT/'inputs-v2/prompt.ids',dtype=np.int64).reshape(-1)
# Read only the23 actual embedding rows, never the complete1GB embedding.
dtype,shape,offset,count=weights['model.language_model.embed_tokens.weight'];assert dtype=='BF16'
embedding=[]
with shard.open('rb') as stream:
 for token in tokens:
  stream.seek(offset+int(token)*shape[1]*2)
  embedding.append((np.frombuffer(stream.read(shape[1]*2),dtype='<u2').astype('<u4')<<16).view('<f4'))
embedding=np.stack(embedding)
out=p['03-out-proj-output'].reshape(23,2048);residual=p['06-post-attn-residual'].reshape(23,2048)
algebra['post_attention_residual']=stats(residual,bf16(embedding+out))
normal_weight=weight('layers.0.post_attention_layernorm.weight')
x=residual.astype(np.float64)
norm=bf16(x/np.sqrt(np.mean(x*x,axis=-1,keepdims=True)+1e-6)*(1+normal_weight.astype(np.float64)))
algebra['post_attention_norm_fp64']=stats(p['07-post-attn-norm'].reshape(23,2048),norm)
linear_checks={}
for name,input_key,output_key in [
 ('linear_attn.out_proj','02-out-proj-input','03-out-proj-output'),
 ('mlp.gate_proj','07-post-attn-norm','08-gate-proj-output'),
 ('mlp.up_proj','07-post-attn-norm','09-up-proj-output')]:
 w=weight('layers.0.'+name+'.weight');x=p[input_key].reshape(23,-1)
 exact=bf16(x.astype(np.float64)@w.astype(np.float64).T)
 linear_checks[name]=stats(p[output_key].reshape(exact.shape),exact)
w=weight('layers.0.mlp.down_proj.weight')
down=bf16(product.reshape(23,6144).astype(np.float64)@w.astype(np.float64).T)
linear_checks['mlp.down_proj_then_residual']=stats(p['05-layer-output'].reshape(23,2048),bf16(down+residual))
algebra['same_input_bf16_matmul_fp64']=linear_checks

# Verify the first observed layer1 convolution state against its actual
# preceding diagnostic layer output, not against a guessed hidden state.
layer0=p['05-layer-output'].reshape(23,2048).astype(np.float64)
scale=weight('layers.1.input_layernorm.weight').astype(np.float64)
normalized=bf16(layer0/np.sqrt(np.mean(layer0*layer0,axis=-1,keepdims=True)+1e-6)*(1+scale))
w=weight('layers.1.linear_attn.in_proj_qkv.weight')
projected=bf16(normalized[-3:].astype(np.float64)@w.astype(np.float64).T)
algebra['layer1_conv_from_probe_layer0_output']=stats(load(CURRENT/'trace-01/prefill/layer1.conv.bf16'),projected)
reference_conv=load(REF/'prefill/layer1.conv.bf16').reshape(3,6144)
def projection_check(hidden):
 hidden=hidden.astype(np.float64)
 normalized=bf16(hidden/np.sqrt(np.mean(hidden*hidden,axis=-1,keepdims=True)+1e-6)*(1+scale))
 actual=bf16(normalized.astype(np.float64)@w.astype(np.float64).T)
 return dict(reference=stats(actual,reference_conv),
  by_position=[dict(position=20+i,**stats(actual[i],reference_conv[i])) for i in range(3)])
fingerprints={'actual_layer0_output':projection_check(layer0[-3:])}
down_weight=weight('layers.0.mlp.down_proj.weight').astype(np.float64)
fingerprints['same_actual_mlp_input_exact_down']=projection_check(bf16(down[-3:]+residual[-3:]))
gate_weight=weight('layers.0.mlp.gate_proj.weight').astype(np.float64)
up_weight=weight('layers.0.mlp.up_proj.weight').astype(np.float64)
def exact_ffn(residual_input,normalized_input):
 gate=bf16(normalized_input.astype(np.float64)@gate_weight.T).astype(np.float64)
 up=bf16(normalized_input.astype(np.float64)@up_weight.T)
 product=bf16(bf16(gate/(1+np.exp(-gate)))*up)
 down=bf16(product.astype(np.float64)@down_weight.T)
 return bf16(down+residual_input)
fingerprints['same_actual_post_attn_norm_exact_ffn']=projection_check(
 exact_ffn(residual[-3:],p['07-post-attn-norm'].reshape(23,2048)[-3:]))
out_weight=weight('layers.0.linear_attn.out_proj.weight').astype(np.float64)
out_exact=bf16(p['02-out-proj-input'].reshape(23,2048)[-3:].astype(np.float64)@out_weight.T)
residual_exact=bf16(embedding[-3:]+out_exact);x=residual_exact.astype(np.float64)
norm_exact=bf16(x/np.sqrt(np.mean(x*x,axis=-1,keepdims=True)+1e-6)*(1+normal_weight.astype(np.float64)))
fingerprints['same_actual_out_proj_input_exact_tail']=projection_check(exact_ffn(residual_exact,norm_exact))
algebra['last_three_token_rounding_fingerprints']=fingerprints

# A small deterministic head sample checks actual source weight/hidden/output
# agreement without loading the1GB tied embedding or rerunning any layer.
ids=np.unique(np.r_[np.arange(0,248320,997),[20,198,248046,248319]])
dtype,shape,offset,count=weights['model.language_model.embed_tokens.weight'];head_rows=[]
with shard.open('rb') as stream:
 for token in ids:
  stream.seek(offset+int(token)*shape[1]*2)
  head_rows.append((np.frombuffer(stream.read(shape[1]*2),dtype='<u2').astype('<u4')<<16).view('<f4'))
head_rows=np.stack(head_rows).astype(np.float64);head_checks=[]
for step in reference['steps']:
 name=step['name'];row=dict(phase=name,sampled_rows=int(ids.size),ids=ids.tolist())
 for label,directory in [('current',CURRENT/'trace-01'),('reference',REF),('prior',PRIOR/'trace-01')]:
  hidden=load(directory/name/'hidden.bf16');logits=load(directory/name/'logits.f32')
  predicted=bf16(head_rows@hidden.astype(np.float64))
  row[label]=dict(same_hidden_fp64_projection=stats(logits[ids],predicted),
   all_logits_are_bf16_values=bool(np.all((logits.view(np.uint32)&65535)==0)))
 head_checks.append(row)

first_observed={}
for phase in (r['name'] for r in reference['steps']):
 selected=[r for r in rows if r['phase']==phase and r['tensor'].startswith('layer')]
 first_observed[phase]={}
 for threshold in [0.0001,0.001,0.005,0.01]:
  hit=next((r for r in selected if r['current_vs_reference']['relative_l2']>=threshold),None)
  first_observed[phase][str(threshold)]=dict(tensor=hit['tensor'],relative_l2=hit['current_vs_reference']['relative_l2']) if hit else None

data=dict(kind='offline_existing_trace_analysis_no_model_execution_no_tolerance_inferred',
 source_id=reference['source_id'],tensor_count=len(rows),rows=rows,probe_algebra=algebra,
 conv_rows=conv_row_checks,sampled_tied_head=head_checks,
 first_observed_by_descriptive_threshold_not_acceptance=first_observed,
 weight_manifest=dict(path=str((INPUT/'inputs-v2/weights.tsv').relative_to(ROOT)),sha256=sha(INPUT/'inputs-v2/weights.tsv'),
  checkpoint=str(shard),dtypes={dtype:sum(1 for row in weights.values() if row[0]==dtype) for dtype in {'BF16','F32'}},
  no_quantized_weights=True),
 provenance=[dict(path=str(path.relative_to(ROOT)),sha256=sha(path)) for path in [
  CURRENT/'comparison.json',CURRENT/'comparison-prior-trace.json',CURRENT/'trace-identities.json',
  PRIOR/'comparison.json',REF/'reference.json',ROOT/'tools/qwen35_text/reference.py',ROOT/'tools/qwen35_text/main.cc']])
(OUT/'analysis.json').write_text(json.dumps(data,indent=2)+'\n')
for phase in [s['name'] for s in reference['steps']]:
 print(phase)
 for r in rows:
  if r['phase']==phase and (key(Path(r['tensor']))[0]<4 or r['tensor'] in ['hidden.bf16','logits.f32']):
   print(r['tensor'],*[f"{r[k]['relative_l2']:.8g}" for k in ['current_vs_reference','old_vs_reference','current_vs_old']],
    'equal',r['current_vs_reference']['equal_elements'],'/',r['current_vs_reference']['elements'])
print('probe_algebra',json.dumps({k:v for k,v in algebra.items() if k!='probe_sources'},indent=2))
