"""Existing complete vocabulary rows only; no forward or inferred tolerance."""
from pathlib import Path
import hashlib,json
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
BASE=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/reference'
CURRENT=ROOT/'.scratch/architecture-refactor-2026-10-18/generic-progress/qwen/trace-01'
PRIOR=ROOT/'.scratch/compute-execution-refactor-2026-10-18/qwen35-ragged/trace-01'
reference=json.loads((BASE/'reference.json').read_text())
def load(path):return np.fromfile(path,dtype='<f4').astype(np.float64)
def logsoftmax(x):
 maximum=np.max(x);return x-maximum-np.log(np.exp(x-maximum).sum())
def top(x,k):return np.lexsort((np.arange(x.size),-x))[:k]
def measure(a,b,token):
 la,lb=logsoftmax(a),logsoftmax(b);pa,pb=np.exp(la),np.exp(lb);bt=top(b,10);at=top(a,10)
 return dict(cosine=float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b))),
  relative_l2=float(np.linalg.norm(a-b)/np.linalg.norm(b)),
  kl_reference_to_candidate=float(np.sum(pb*(lb-la))),
  kl_candidate_to_reference=float(np.sum(pa*(la-lb))),
  top_overlap={str(k):dict(count=len(set(at[:k])&set(bt[:k])),fraction=len(set(at[:k])&set(bt[:k]))/k) for k in [1,5,10]},
  candidate_top10=at.tolist(),reference_top10=bt.tolist(),
  reference_top1_margin=dict(logit=float(b[bt[0]]-b[bt[1]]),probability=float(pb[bt[0]]-pb[bt[1]]),
   top1=int(bt[0]),top2=int(bt[1])),
  actual_next_token=dict(token=token,reference_logit=float(b[token]),candidate_logit=float(a[token]),
   logit_delta=float(a[token]-b[token]),reference_log_probability=float(lb[token]),candidate_log_probability=float(la[token]),
   reference_rank=int(np.flatnonzero(top(b,b.size)==token)[0])+1,candidate_rank=int(np.flatnonzero(top(a,a.size)==token)[0])+1))
rows=[]
for step in reference['steps']:
 name=step['name'];b=load(BASE/name/'logits.f32');a=load(CURRENT/name/'logits.f32');old=load(PRIOR/name/'logits.f32')
 assert a.size==b.size==248320 and np.isfinite(a).all() and np.isfinite(b).all()
 rows.append(dict(phase=name,sequence_tokens=len(step['input_ids']),vocabulary_rows=a.size,
  is_actual_generated_position=name!='prefill',
  current_vs_reference=measure(a,b,step['next_id']),prior_vs_reference=measure(old,b,step['next_id'])))
aggregates={}
for name,selected in [('all_three_captured_positions',rows),('actual_generated_positions',[r for r in rows if r['is_actual_generated_position']])]:
 m=[r['current_vs_reference'] for r in selected]
 aggregates[name]=dict(positions=len(selected),vocabulary_rows=sum(r['vocabulary_rows'] for r in selected),
  mean_kl_reference_to_candidate=float(np.mean([x['kl_reference_to_candidate'] for x in m])),
  max_kl_reference_to_candidate=max(x['kl_reference_to_candidate'] for x in m),
  top1_agreement_count=sum(x['top_overlap']['1']['count'] for x in m),
  mean_top5_overlap=float(np.mean([x['top_overlap']['5']['fraction'] for x in m])),
  mean_top10_overlap=float(np.mean([x['top_overlap']['10']['fraction'] for x in m])))
report=dict(kind='full_vocabulary_decision_impact_measurements_no_accuracy_or_numerical_pass',rows=rows,aggregates=aggregates,
 scope='The trace contains only the last-position vocabulary vector of each phase, not all23/4/1 sequence-position logits. Prefill next20 is superseded by the supplied continuation; actual generated positions are continuation248046 and decode1=198.',
 kl='Stable F64 log-softmax over all248320 finite vocabulary values; both directions, no truncation/top-k softmax.',
 source_id=reference['source_id'],script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'logit-impact.json').write_text(json.dumps(report,indent=2)+'\n')
for r in rows:
 m=r['current_vs_reference'];print(r['phase'],json.dumps(dict(cosine=m['cosine'],relL2=m['relative_l2'],KL=m['kl_reference_to_candidate'],
  overlap=m['top_overlap'],margin=m['reference_top1_margin'],token=m['actual_next_token'])))
print(json.dumps(aggregates,indent=2))
