"""Actual Torch CUDA operators on already executed Hyle BF16 probe inputs."""
from pathlib import Path
import hashlib,json,os
os.environ.update(OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
import torch
import torch.nn.functional as F
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
BASE=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text'
PROBE=ROOT/'.scratch/architecture-refactor-2026-10-18/generic-progress/qwen/layer0-probe-01/prefill'
lines=(BASE/'inputs-v2/weights.tsv').read_text().splitlines();shard=Path(lines[1]);rows={}
for line in lines[3:]:
 f=line.split('\t');rank=int(f[2]);rows[f[0]]=(f[1],tuple(map(int,f[3:3+rank])),int(f[3+rank]),int(f[4+rank]))
torch.set_num_threads(2);torch.set_num_interop_threads(1)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=False
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction=False
reads=[];loaded={}
def weight(name):
 if name in loaded:return loaded[name]
 dtype,shape,offset,size=rows['model.language_model.'+name]
 with shard.open('rb') as stream:stream.seek(offset);raw=bytearray(stream.read(size))
 reads.append(dict(name=name,bytes=size,sha256=hashlib.sha256(raw).hexdigest()))
 loaded[name]=torch.frombuffer(raw,dtype=torch.bfloat16 if dtype=='BF16' else torch.float32).reshape(shape).to('cuda')
 return loaded[name]
def probe(name,width=2048):return torch.frombuffer(bytearray((PROBE/(name+'.bf16')).read_bytes()),dtype=torch.bfloat16).reshape(23,width).to('cuda')
def stats(a,b):
 a=a.detach().float().cpu().numpy();b=b.detach().float().cpu().numpy();aa=a.astype(np.float64);bb=b.astype(np.float64)
 different=np.flatnonzero(a.reshape(-1)!=b.reshape(-1))
 changes=[]
 for index in different[:20]:
  changes.append(dict(index=int(index),token=int(index//a.shape[-1]),channel=int(index%a.shape[-1]),
   actual=float(a.reshape(-1)[index]),hyle=float(b.reshape(-1)[index])))
 return dict(elements=a.size,equal_elements=int(np.count_nonzero(a==b)),max_abs=float(np.max(np.abs(aa-bb))),
  relative_l2=float(np.linalg.norm(aa-bb)/np.linalg.norm(bb)),first_changes=changes)
result={}
with torch.inference_mode():
 for label,source,target,name,width in [
  ('out_proj','02-out-proj-input','03-out-proj-output','linear_attn.out_proj',2048),
  ('gate_proj','07-post-attn-norm','08-gate-proj-output','mlp.gate_proj',2048),
  ('up_proj','07-post-attn-norm','09-up-proj-output','mlp.up_proj',2048)]:
  expected=probe(target,6144 if 'mlp' in name else 2048)
  result[label]=stats(F.linear(probe(source,width),weight('layers.0.'+name+'.weight')),expected)
 product=probe('04-down-proj-input',6144);residual=probe('06-post-attn-residual')
 result['down_proj_then_residual']=stats(F.linear(product,weight('layers.0.mlp.down_proj.weight'))+residual,probe('05-layer-output'))
 result['silu_then_multiply']=stats(F.silu(probe('08-gate-proj-output',6144))*probe('09-up-proj-output',6144),product)
 # Original gated norm on the actual Hyle GDN output. Rebuild only its Z
 # projection from the immutable true embedding/input norm, not another block.
 tokens=list(map(int,(BASE/'inputs-v2/prompt.ids').read_text().split()))
 dtype,shape,offset,size=rows['model.language_model.embed_tokens.weight'];embedding=[]
 with shard.open('rb') as stream:
  for token in tokens:
   stream.seek(offset+token*shape[1]*2)
   embedding.append(torch.frombuffer(bytearray(stream.read(shape[1]*2)),dtype=torch.bfloat16))
 hidden=torch.stack(embedding).to('cuda');x=hidden.float()
 normalized=(x*torch.rsqrt(x.pow(2).mean(-1,keepdim=True)+1e-6)*(1+weight('layers.0.input_layernorm.weight').float())).bfloat16()
 z=F.linear(normalized,weight('layers.0.linear_attn.in_proj_z.weight')).reshape(23,16,128)
 y=probe('01-gdn-output').reshape(23,16,128);yy=y.float()
 yy=(yy*torch.rsqrt(yy.pow(2).mean(-1,keepdim=True)+1e-6)).bfloat16()
 yy=weight('layers.0.linear_attn.norm.weight')*yy
 gated=(yy*F.silu(z.float())).bfloat16().reshape(23,2048)
 result['gated_norm_same_hyle_gdn_output']=stats(gated,probe('02-out-proj-input'))
 # Causal intervention: change only the official block's GDN output to the
 # existing Hyle output, then use unchanged real Torch CUDA downstream math.
 mixed=F.linear(gated,weight('layers.0.linear_attn.out_proj.weight'))
 tail_residual=hidden+mixed;xx=tail_residual.float()
 variance=xx.pow(2).mean(-1,keepdim=True)
 normalized_float=xx*torch.rsqrt(variance+1e-6)*(1+weight('layers.0.post_attention_layernorm.weight').float())
 normalized_tail=normalized_float.bfloat16()
 result['tail_residual_from_hyle_gdn_output']=stats(tail_residual,probe('06-post-attn-residual'))
 result['post_attention_norm_same_input']=stats(normalized_tail,probe('07-post-attn-norm'))
 tail_gate=F.linear(normalized_tail,weight('layers.0.mlp.gate_proj.weight'))
 tail_up=F.linear(normalized_tail,weight('layers.0.mlp.up_proj.weight'))
 tail=F.linear(F.silu(tail_gate)*tail_up,weight('layers.0.mlp.down_proj.weight'))+tail_residual
 result['whole_tail_from_hyle_gdn_output']=stats(tail,probe('05-layer-output'))
 xx=tail.float();normalized1=(xx*torch.rsqrt(xx.pow(2).mean(-1,keepdim=True)+1e-6)*
     (1+weight('layers.1.input_layernorm.weight').float())).bfloat16()
 qkv1=F.linear(normalized1,weight('layers.1.linear_attn.in_proj_qkv.weight'))[-3:]
 current_path=ROOT/'.scratch/architecture-refactor-2026-10-18/generic-progress/qwen/trace-01/prefill/layer1.conv.bf16'
 current_conv=torch.frombuffer(bytearray(current_path.read_bytes()),dtype=torch.bfloat16).reshape(3,6144).to('cuda')
 result['layer1_conv_after_only_hyle_gdn_intervention']=stats(qkv1,current_conv)
 restored=normalized_tail.clone();restored[21,619]=probe('07-post-attn-norm')[21,619]
 restored_tail=F.linear(F.silu(F.linear(restored,weight('layers.0.mlp.gate_proj.weight')))*
     F.linear(restored,weight('layers.0.mlp.up_proj.weight')),weight('layers.0.mlp.down_proj.weight'))+tail_residual
 result['tail_after_single_norm_coordinate_intervention']=stats(restored_tail,probe('05-layer-output'))
 xx1=restored_tail.float();normalized1=(xx1*torch.rsqrt(xx1.pow(2).mean(-1,keepdim=True)+1e-6)*
     (1+weight('layers.1.input_layernorm.weight').float())).bfloat16()
 restored_qkv=F.linear(normalized1,weight('layers.1.linear_attn.in_proj_qkv.weight'))[-3:]
 result['layer1_conv_after_single_norm_coordinate_intervention']=stats(restored_qkv,current_conv)
 row=tail_residual[21].float().cpu().numpy().astype(np.float64)
 norm_weight=weight('layers.0.post_attention_layernorm.weight').float().cpu().numpy().astype(np.float64)
 exact_variance=float(np.mean(row*row));exact_value=float(row[619]/np.sqrt(exact_variance+1e-6)*(1+norm_weight[619]))
 scalar=dict(token=21,channel=619,torch_variance=float(variance[21,0]),
  fp64_variance=exact_variance,fp32_rounded_exact_variance=float(np.float32(exact_variance)),
  torch_pre_bf16=float(normalized_float[21,619]),fp64_value=exact_value,
  fp32_rounded_exact_value=float(np.float32(exact_value)),bf16_midpoint=(.8359375+.83984375)/2,
  torch_bf16=float(normalized_tail[21,619]),hyle_bf16=float(probe('07-post-attn-norm')[21,619]))
 # Explicitly record the first tiny seed's raw BF16 differences.
 official=torch.frombuffer(bytearray((OUT/'torch-first-block/01-gdn-output.bf16').read_bytes()),dtype=torch.bfloat16).reshape(23,2048).to('cuda')
 result['official_gdn_vs_hyle']=stats(official,probe('01-gdn-output'))
torch.cuda.synchronize()
report=dict(kind='same_input_actual_torch_cuda_operator_replay_not_an_fp64_substitution',comparisons=result,
 norm_rounding_scalar=scalar,
 weight_reads=reads,weight_read_bytes=sum(r['bytes'] for r in reads),source_id=lines[2],
 runtime=dict(torch=torch.__version__,cuda=torch.version.cuda,gpu=torch.cuda.get_device_name()),
 script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'same-input-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
