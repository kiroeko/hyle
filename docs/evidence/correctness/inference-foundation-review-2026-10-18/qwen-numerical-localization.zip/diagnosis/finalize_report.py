"""Freeze the already executed small numerical diagnosis; never executes a model."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent


def load(name):
    return json.loads((STAGE / name).read_text(encoding="utf-8"))


def identity(path):
    path = Path(path)
    return {"path": str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


analysis = load("analysis.json")
first = load("first-block-comparison.json")
same = load("same-input-comparison.json")
impact = load("logit-impact.json")
for name, data in [("first_block.py", first), ("same_input.py", same),
                   ("logit_impact.py", impact)]:
    assert identity(STAGE / name)["sha256"] == data["script_sha256"], name
assert all(v["equal_elements"] == v["elements"]
           for v in first["full_reference_sanity"].values())
comp = same["comparisons"]
assert comp["post_attention_norm_same_input"]["equal_elements"] == 47103
for name in ("tail_after_single_norm_coordinate_intervention",
             "layer1_conv_after_single_norm_coordinate_intervention"):
    assert comp[name]["equal_elements"] == comp[name]["elements"]

summary = {
    "status": "diagnosis_complete_numerical_acceptance_still_open",
    "scope": {
        "product_modified": False, "sdk_or_kernel_rebuilt": False,
        "full_model_rerun": False,
        "existing_data": "150 current/prior/reference tensors and nine executed Hyle layer0 probes",
        "new_gpu_work": "one official decoder block0 plus layer1 norm/QKV; small same-input Torch CUDA operator replays",
        "runtime": first["runtime"],
        "first_block_weight_read_bytes": first["weight_read_bytes"],
        "same_input_weight_read_bytes": same["weight_read_bytes"],
        "no_live_process": True,
    },
    "causal_finding": {
        "location": "prefill token21 channel619, layer0 post-attention RMSNorm -> BF16",
        "same_input_norm": comp["post_attention_norm_same_input"],
        "scalar": same["norm_rounding_scalar"],
        "intervention": "After supplying Hyle's actual GDN output to the original Torch tail, change only the one normalized BF16 coordinate to Hyle's value.",
        "layer0_output": comp["tail_after_single_norm_coordinate_intervention"],
        "layer1_conv": comp["layer1_conv_after_single_norm_coordinate_intervention"],
        "earlier_tiny_gdn_difference": comp["official_gdn_vs_hyle"],
        "limits": "This identifies the first conspicuous prefill propagation cause, not every later-phase/final-logit difference. Native F32 intermediate rounding/order remains unobserved.",
    },
    "oracle_authentication": first["full_reference_sanity"],
    "same_input_exact_operators": {k: comp[k] for k in
        ("out_proj", "gate_proj", "up_proj", "down_proj_then_residual",
         "silu_then_multiply", "gated_norm_same_hyle_gdn_output")},
    "model_contract": {
        "source_id": analysis["source_id"], "weight_manifest": analysis["weight_manifest"],
        "weights": {"tensors": 320, "bytes": 3763655360, "BF16": 284, "F32": 36},
        "activation": "BF16 boundaries with explicit F32 RMSNorm and recurrent-state arithmetic; all stored logits are BF16 values widened to F32.",
        "reference": "Original installed Qwen3.5 decoder with product reference.py's fixed recurrent-state formula, eval, no TF32/BF16 or F16 reduced matmul reduction.",
        "reference_source": first["reference_script"], "model_source": first["model_source"],
    },
    "earliest_captured_by_phase": analysis["first_observed_by_descriptive_threshold_not_acceptance"],
    "full_vocabulary_impact": impact,
    "remaining": [
        "No agreed numerical tolerance or accuracy evaluation; unchanged tokens/top-k do not constitute numerical PASS.",
        "Capture selected native RMSNorm's uncast F32 result/variance/scale on the identical row21 before deciding whether/where primitive arithmetic should be aligned.",
        "Continuation's analogous row24 spread and inherited decode state are localized offline but not causally intervened here.",
        "No claim that this one split explains all later-layer/current-vs-prior differences, or that precise-unary/fast-math is the fix.",
    ],
    "evidence": ["analysis.json", "per-layer.csv", "first-block-comparison.json",
                 "same-input-comparison.json", "logit-impact.json", "report.txt"],
}
(STAGE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

lines = [
"Qwen3.5-2B CUDA numerical diagnosis — final small experiment",
"",
"The first conspicuous prefill spread is causally localized to one RMSNorm -> BF16 rounding boundary, not a demonstrated Graph routing error. On exactly Hyle's post-attention residual, original Torch CUDA differs only at token21/channel619: Torch 0.8359375, Hyle 0.83984375. Torch's pre-cast F32 value is the exact BF16 midpoint 0.837890625. The F64 value is 0.8378906559120657 (F32 RNE 0.8378906846046448), just above that midpoint. Torch variance already equals correctly rounded exact variance; variance reduction alone is not proven responsible.",
"",
"Causal replay: feed Hyle's recorded GDN output through the actual Torch CUDA tail, then change only that one normalized BF16 coordinate to Hyle's value. All 47,104 layer0 outputs and all 18,432 layer1 conv-history elements become bit-identical to executed Hyle. Without that intervention, 317 layer0 outputs and 2,529 layer1 conv-history elements differ, localized to token21. This is a diagnostic intervention, not an oracle-fed candidate run or numerical acceptance test.",
"",
"Authentication and exclusions: an independently executed original official block0 reproduces the old full-reference layer0 conv, layer1 conv and 262,144 F32 recurrent-state elements exactly. Hyle's earlier GDN output differs at three BF16 elements only (max 3.72529e-9); these tiny differences are distinct from the same-input norm split. Actual same-input Torch out/gate/up/down projections, SiLU->multiply and gated norm are all bit-exact to Hyle. The native RMSNorm uses unchanged norm.cu (SHA 8cb872a9633a7c68c5e9fa8c1f7d39afe9e66636c1299b9fc610b1b4217e7307), not unary.cu. Old and current Hyle layer1 conv are also identical. A precise-unary toggle is therefore not an evidenced fix.",
"",
"Existing phase localization: layer0 conv is exact in all phases. First conspicuous captured BF16 spread is layer1 conv in prefill (relL2 0.00118723, only global row21) and continuation (0.00133324, only row24). Decode layer1 conv is exact, while inherited layer1 recurrent-state relL2 is 0.000480103, followed by layer2 conv 0.00373481. The prefill causal experiment does not establish every later-phase/layer source.",
"",
"Model/oracle contract: same source ID 4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155; 320 text tensors / 3,763,655,360 bytes (284 BF16 + 36 F32), no quantized weight tensors. Both paths explicitly round activations to BF16 and store BF16 logits widened to F32. Original reference.py and installed modeling_qwen3_5.py hashes match the original reference receipt. New work used Torch 2.8.0+cu129 / RTX4070 with matmul TF32 and reduced BF16/F16 reduction disabled. Only block0 plus layer1 norm/QKV was executed; no 24-layer rerun, model/SDK copy, native compile, or product edit.",
"",
"Full-vocabulary logit impact (stable F64 softmax, all 248,320 vocabulary entries):",
"phase         cosine           relL2       KL(reference||current)  overlap 1/5/10  reference top1 margin",
]
for row in impact["rows"]:
    x = row["current_vs_reference"]
    overlap = x["top_overlap"]
    lines.append(f'{row["phase"]:<13} {x["cosine"]:.12f}   {x["relative_l2"]:.9f}  '
                 f'{x["kl_reference_to_candidate"]:.12g}  '
                 f'{overlap["1"]["count"]}/1 {overlap["5"]["count"]}/5 {overlap["10"]["count"]}/10  '
                 f'{x["reference_top1_margin"]["logit"]:g}')
lines += [
"",
"The trace stores one last-position vocabulary vector per phase, not logits for all 23/4/1 sequence positions. Prefill prediction20 is superseded by supplied continuation; actual generated positions are continuation248046 and decode1=198. Across all three captured positions, mean KL is 1.07152256554e-4, top1 agrees 3/3, top5 overlap100%, top10 mean96.67%. Across the two actual generated positions, mean KL is 6.69728779483e-5, top1 agrees2/2, top5 overlap100%, top10 mean95%. Both KL directions and token log-probabilities are in logit-impact.json. These quantify this journey's decision impact; they are not an accuracy benchmark or a justified numerical tolerance.",
"",
"Current final hidden/logit relL2 versus reference: prefill 2.206349%/2.151227%, continuation 1.444194%/1.957291%, decode1 2.543714%/2.458940%. Numerical acceptance remains open. Next minimal discriminant, if requested: inspect the selected native RMSNorm's uncast F32 output, variance and scale on identical row21 to distinguish rsqrt/multiply/reduction intermediate rounding. Do not replace the whole reference with FP64 or loosen tolerance.",
"",
"Reproduction / original data locations (relative to repository unless absolute):",
"  scripts: .scratch/architecture-refactor-2026-10-18/qwen-numerics/{analyze.py,first_block.py,same_input.py,logit_impact.py}",
"  executed Hyle probes: .scratch/architecture-refactor-2026-10-18/generic-progress/qwen/layer0-probe-01/prefill",
"  current full trace / original runner: .scratch/architecture-refactor-2026-10-18/generic-progress/qwen/{trace-01,run.py}",
"  prior trace / compare reader: .scratch/compute-execution-refactor-2026-10-18/qwen35-ragged/{trace-01,compare.py}",
"  independent trace / inputs: .scratch/inference-execution-refactor-2026-10-18/qwen35-text/{reference,inputs-v2}",
"  reference generator: tools/qwen35_text/reference.py",
"  weights remain at original C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors; only required slices were read and each hash is reported.",
"",
"No process remains live. No archive or deletion was performed."
]
(STAGE / "report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

commands = []
for script, stdout, stderr, report in [
    ("analyze.py", "analysis.stdout.log", None, "analysis.json"),
    ("first_block.py", "first-block.stdout.log", "first-block.stderr.log", "first-block-comparison.json"),
    ("same_input.py", "same-input.stdout.log", "same-input.stderr.log", "same-input-comparison.json"),
    ("logit_impact.py", "logit-impact.stdout.log", None, "logit-impact.json"),
]:
    commands.append({"command": ["C:/Program Files/Python312/python.exe", str((STAGE / script).relative_to(ROOT))],
                     "working_directory": str(ROOT), "observed_exit_code": 0,
                     "stdout": stdout, "stderr": stderr, "report": report,
                     "note": "Retained last invocation. Earlier successful same-input diagnostic reports are retained separately; no failed experiment is omitted."})
(STAGE / "commands.json").write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")

source_paths = [ROOT / p["path"] for p in analysis["provenance"]]
source_paths += [ROOT / analysis["weight_manifest"]["path"], Path(first["model_source"]["path"])]
source_paths += [ROOT / "src/compute_provider_ggml_cuda/tensor_program.cc",
                Path("C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml-cuda/norm.cu")]
source_rows = [identity(p) for p in dict.fromkeys(source_paths)]
for saved in analysis["provenance"]:
    actual = identity(ROOT / saved["path"])
    assert saved["sha256"] == actual["sha256"], saved["path"]
(STAGE / "source-identities.json").write_text(json.dumps(source_rows, indent=2) + "\n", encoding="utf-8")

results = [identity(p) for p in sorted(STAGE.rglob("*")) if p.is_file()
           and p.name != "result-identities.json" and "__pycache__" not in p.parts]
(STAGE / "result-identities.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": summary["status"], "files": len(results),
                  "summary": identity(STAGE / "summary.json"),
                  "report": identity(STAGE / "report.txt"),
                  "identities": identity(STAGE / "result-identities.json")}, indent=2))
