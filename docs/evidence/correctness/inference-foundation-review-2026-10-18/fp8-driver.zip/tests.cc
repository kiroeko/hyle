#include <gtest/gtest.h>
#include <array>
#include <cstring>
#include <span>
#include <vector>
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/providers/cuda.h"
#include "hyle/compute/prepared_operation.h"
#include "fp8_provider.h"
#include "grouped_fp8_provider.h"
#include "native_context.h"

namespace c = hyle::compute;
namespace m = hyle::mem;
namespace f = c::cuda_native::fp8;
namespace g = c::cuda_native::grouped_fp8;
namespace d = c::detail;
namespace {
hyle::Status create(const c::Provider&, c::Device device, void* backend,
                 m::AllocatorRef, void** out) noexcept {
  if (device.backend_id() != c::cuda::kBackendId)
    return hyle::Status::Unimplemented("CUDA required");
  *out = c::cuda::detail::borrow_primary_context(backend);
  return *out ? hyle::Status::Ok() : hyle::Status::FailedPrecondition("no primary context");
}
void destroy(void*, m::AllocatorRef) noexcept {}
hyle::Status drain(void*) noexcept { return hyle::Status::Ok(); }
hyle::Status propose(void* ctx, const d::ProviderOperationRequest& request,
    std::span<d::ResourceBindingRequirement> in,
    std::span<d::ResourceBindingRequirement> out,
    d::ProviderOperationProposal* result) noexcept {
  return request.operation.custom_as<c::model_ops::GroupedFloat8Linear>()
      ? g::propose(ctx, request, in, out, result)
      : f::propose(ctx, request, in, out, result);
}
c::ProviderPrepareOutcome prepare(void* ctx, const d::ProviderPrepareRequest& request,
    m::AllocatorRef a, d::ProviderPrepared* result) noexcept {
  return request.operation.custom_as<c::model_ops::GroupedFloat8Linear>()
      ? g::prepare(ctx, request, a, result) : f::prepare(ctx, request, a, result);
}
const d::ProviderVTable table{
  .identity = {.id = c::cuda_native::kSglangProviderId, .name = "sglang-component-probe", .version = "current-host"},
  .create_context = create, .destroy_context = destroy,
  .propose = propose, .prepare = prepare, .drain_context = drain};
struct Tensor {
  m::Buffer b;
  c::TensorView view;
  Tensor(const c::TensorDesc& desc, m::MemoryResourceRef r)
      : b(m::Buffer::create(r, desc.required_bytes().value(), 256).value()),
        view(c::TensorView::create(desc, b.view()).value()) {}
};
void run(bool dynamic, bool grouped, bool bf16) {
  auto provider = d::ProviderAccess::make(&table, std::uint8_t{0});
  auto context = c::Context::create(c::cuda::device(0).value(), provider).value();
  auto resource = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  constexpr std::int64_t rows=3, k=128, n=129, experts=9, slots=8;
  const auto type=bf16?c::DataType::kBFloat16:c::DataType::kFloat32;
  const auto ad=grouped ? c::TensorDesc::dense(type,std::array{rows,std::int64_t{1},k}).value()
    : dynamic ? c::TensorDesc::dense(type,std::array{rows,k}).value()
    : c::float8_activation_description(rows,k,c::Float8ScaleMode::kFloat32Block128).value();
  const auto wd=grouped?c::float8_grouped_weight_description(experts,n,k).value()
    : c::float8_weight_description(k,n,c::Float8ScaleMode::kFloat32Block128).value();
  const auto cd=grouped?c::TensorDesc::dense(type,std::array{rows,slots,n}).value()
    : c::TensorDesc::dense(type,std::array{rows,n}).value();
  Tensor a(ad,resource.ref()), w(wd,resource.ref());
  const auto id_desc=c::TensorDesc::dense(c::DataType::kInt32,std::array{rows,slots}).value();
  Tensor ids(id_desc,resource.ref());
  std::array outputs{Tensor(cd,resource.ref()),Tensor(cd,resource.ref())};
  const auto payload=std::size_t(n*k)*(grouped?experts:1);
  std::vector<std::byte> wb(wd.required_bytes().value(),std::byte{0x38});
  const float one=1;
  for(auto i=payload;i<wb.size();i+=4)std::memcpy(wb.data()+i,&one,4);
  ASSERT_TRUE(w.b.view().write(wb).ok());
  if(grouped){std::vector<std::int32_t> iv(rows*slots);for(std::size_t i=0;i<iv.size();++i)iv[i]=int(i%experts);
    ASSERT_TRUE(ids.b.view().write(std::as_bytes(std::span(iv))).ok());}
  std::vector<c::ConstTensorView> inputs=grouped?std::vector{w.view.as_const(),a.view.as_const(),ids.view.as_const()}
      : std::vector{a.view.as_const(),w.view.as_const()};
  c::Operation operation = grouped ? c::model_ops::grouped_float8_linear()
      : dynamic ? c::model_ops::float8_block_linear(bf16 ? c::model_ops::Float8ScaleRounding::kPowerOfTwo
                                                    : c::model_ops::Float8ScaleRounding::kNone)
                : c::Operation(c::MatMul{});
  auto prepared_result=c::prepare(context,operation,inputs,std::array{outputs[0].view});
  ASSERT_TRUE(prepared_result) << prepared_result.error().message();
  auto prepared=std::move(*prepared_result);
  EXPECT_EQ(prepared.provider().id,c::cuda_native::kSglangProviderId);
  const auto workspace=prepared.workspace_requirement();
  std::array work{m::Buffer::create(resource.ref(),workspace.size,workspace.alignment).value(),
                  m::Buffer::create(resource.ref(),workspace.size,workspace.alignment).value()};
  std::array lanes{prepared.create_invocation(work[0].view()).value(),
                   prepared.create_invocation(work[1].view()).value()};
  std::array queues{context.create_queue().value(),context.create_queue().value()};
  for(int phase=0;phase<2;++phase){
    if(dynamic||grouped){if(bf16){std::vector<std::uint16_t> data(rows*k,std::uint16_t(phase?0x4000:0x3f80));
      ASSERT_TRUE(a.b.view().write(std::as_bytes(std::span(data))).ok());}
      else {std::vector<float> data(rows*k,float(phase+1));ASSERT_TRUE(a.b.view().write(std::as_bytes(std::span(data))).ok());}}
    else {std::vector<std::byte> data(ad.required_bytes().value(),phase?std::byte{0x40}:std::byte{0x38});
      for(std::size_t i=rows*k;i<data.size();i+=4)std::memcpy(data.data()+i,&one,4);
      ASSERT_TRUE(a.b.view().write(data).ok());}
    std::array<c::Completion,2> done;
    for(std::size_t i=0;i<lanes.size();++i){auto r=lanes[i].submit(queues[i],inputs,std::array{outputs[i].view});
      ASSERT_TRUE(r)<<r.error().message();done[i]=std::move(*r);}
    if(phase==1){prepared={};lanes={};ASSERT_TRUE(context.close().ok());}
    for(std::size_t i=0;i<done.size();++i){ASSERT_TRUE(done[i].wait().ok());
      if(bf16){std::vector<std::uint16_t> actual(cd.element_count().value());
        ASSERT_TRUE(outputs[i].b.view().read(std::as_writable_bytes(std::span(actual))).ok());
        for(auto v:actual)EXPECT_EQ(v,std::uint16_t(phase?0x4380:0x4300));}
      else {std::vector<float> actual(cd.element_count().value());
        ASSERT_TRUE(outputs[i].b.view().read(std::as_writable_bytes(std::span(actual))).ok());
        for(auto v:actual)EXPECT_NEAR(v,float(k*(phase+1)),1e-4F);}}
  }
}
TEST(Fp8Driver, EncodedAndDynamicKeepQueuesModulesAndReplay) {run(false,false,false);run(true,false,false);run(true,false,true);}
TEST(Fp8Driver, GroupedKeepsActualKernelAndCompletionOwners) {run(true,true,false);run(true,true,true);}
}
