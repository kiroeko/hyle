from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cuda_cache',ROOT/'.scratch/mtp-completion/run.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
flags=c.flags+['/I'+str(ROOT/'src/compute_provider_cuda'),'/I'+str(ROOT/'third_party/sglang_activation')]
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command,allowed=(0,)):
    command=list(map(str,command));t=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=c.env,capture_output=True,timeout=120)
    (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout)
    (OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-t))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,round(records[-1]['seconds'],2),flush=True)
    if p.returncode not in allowed:
        print(p.stdout.decode(errors='replace')[-5000:]);print(p.stderr.decode(errors='replace')[-4000:]);raise SystemExit(p.returncode)
    return p
def compile(source,stem):
    obj=OUT/(stem+'.obj');run(stem+'-compile',[c.cl,*flags,source,'/Fo'+str(obj)]);return obj
def link(stem,fp8):
    exe=OUT/(stem+'.exe')
    run(stem+'-link',[c.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(exe),'/MAP:'+str(OUT/(stem+'.map')),fp8,OUT/'grouped.obj',OUT/'tests.obj',
        *c.libs,c.BASE/'lib/gtest_main.lib',c.BASE/'lib/gtest.lib',*c.system])
    return exe
if __name__=='__main__':
    old=(OUT/'fp8_provider.before.cc').read_text()
    assert old.count('cuDriverGetVersion(&driver)')==1
    injected='#include <cuda.h>\nCUresult reported_driver(int* result) { *result=13050; return CUDA_SUCCESS; }\n'
    (OUT/'old-reported-13050.cc').write_text(injected+old.replace('cuDriverGetVersion(&driver)','reported_driver(&driver)'))
    current=ROOT/'src/compute_provider_cuda/fp8_provider.cc'
    for file,stem in [(OUT/'old-reported-13050.cc','old-reported-13050'),(current,'new'),
                      (ROOT/'src/compute_provider_cuda/grouped_fp8_provider.cc','grouped'),(OUT/'tests.cc','tests')]:
        if '--reuse-products' not in sys.argv or stem=='tests': compile(file,stem)
    oldexe=link('old-reported-13050',OUT/'old-reported-13050.obj')
    newexe=link('new',OUT/'new.obj')
    run('old-reported-13050', [oldexe,'--gtest_filter=Fp8Driver.EncodedAndDynamicKeepQueuesModulesAndReplay','--gtest_color=no'],(1,))
    run('new',[newexe,'--gtest_color=no'])
    identities=[]
    for file in [current,ROOT/'src/compute_provider_cuda/grouped_fp8_provider.cc',OUT/'tests.cc',oldexe,newexe]:
        identities.append(dict(path=str(file),bytes=file.stat().st_size,sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
    (OUT/'identity.json').write_text(json.dumps(identities,indent=2)+'\n')
