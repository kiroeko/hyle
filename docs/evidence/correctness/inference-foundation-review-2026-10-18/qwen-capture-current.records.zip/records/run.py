from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
BASE=OUT.parent/'qwen-fixed-decode'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x): Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
    p=Path(p); b=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
plan=read(BASE/'matched-link-plan.json')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':plan['command'][0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in plan['command'] if x.endswith('.lib')))+os.pathsep+env['PATH']
def call(tag,argv,outputs=()):
    assert not (OUT/(tag+'.result.json')).exists(),tag
    row=dict(argv=list(map(str,argv)),started=time.time())
    save(OUT/(tag+'.command.json'),row)
    with (OUT/(tag+'.stdout.log')).open('wb') as so,(OUT/(tag+'.stderr.log')).open('wb') as se:
        p=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=p.pid; save(OUT/'live.json',row)
        row['exit']=p.wait()
    row.update(terminal=True,finished=time.time(),outputs=[ident(x) for x in outputs if Path(x).is_file()])
    save(OUT/(tag+'.result.json'),row); save(OUT/'live.json',row)
    print(tag,row['exit'],round(row['finished']-row['started'],3),flush=True)
    if row['exit']:
        print((OUT/(tag+'.stderr.log')).read_text(errors='replace')[-5000:],flush=True)
    return row['exit']
def prepare():
    original=ROOT/'tools/qwen35_text/main.cc'; text=original.read_text(encoding='utf-8')
    needle='check(run.prepare_replay(queues, {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}));'
    assert text.count(needle)==1
    replacement=needle.replace('kCommands','kPreferCapture')+'''
      const auto replay = take(run.replay_report());
      std::cerr << "replay route=" << static_cast<unsigned>(replay.route)
                << " ordered=" << replay.ordered_dependency_count
                << " device_wait=" << replay.device_wait_dependency_count
                << " host_wait=" << replay.host_wait_dependency_count << '\\n';'''
    source=OUT/'consumer-capture.cc'; source.write_text(text.replace(needle,replacement),encoding='utf-8')
    save(OUT/'source-identity.json',dict(original=ident(original),diagnostic=ident(source),only_changes=['ReplayMode::kCommands -> kPreferCapture','report ordinary replay route/dependency counts'],product_source_unchanged=True))
    argv=read(BASE/'compile-consumer.command.json')['argv']
    argv=[str(source) if x.replace('\\','/').endswith('tools/qwen35_text/main.cc') else x for x in argv]
    argv=[x for x in argv if not x.lower().startswith('/fo')]
    idx=argv.index('/sourceDependencies'); argv[idx+1]=str(OUT/'consumer.deps.json')
    argv.append('/Fo'+str(OUT/'consumer.obj'))
    if call('compile-consumer',argv,[OUT/'consumer.obj',OUT/'consumer.deps.json']): raise SystemExit(1)
    argv=[str(OUT/'consumer.obj') if x==str(BASE/'consumer.obj') else x for x in plan['command']]
    assert str(OUT/'consumer.obj') in argv
    argv=[x for x in argv if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
    argv += ['/OUT:'+str(OUT/'qwen-capture.exe'),'/MAP:'+str(OUT/'qwen-capture.map'),'/IMPLIB:'+str(OUT/'qwen-capture.lib')]
    save(OUT/'matched-link-plan.json',dict(command=argv,reused_final_original_closure=str(BASE/'matched-link-plan.json')))
    if call('link-current',argv,[OUT/('qwen-capture'+s) for s in ['.exe','.map','.lib','.exp']]): raise SystemExit(1)
def run():
    code=call('run-fixed-science',[OUT/'qwen-capture.exe','--inputs',BASE/'science-inputs','--decode-ids',BASE/'science-decode.ids','--capacity','64','--trace',OUT/'decisions','--trace-level','decisions'])
    rows=[]
    if code==0:
        for a in sorted((BASE/'science-final-decisions').glob('*/*')):
            if a.name not in {'logits.f32','hidden.bf16'}: continue
            b=OUT/'decisions'/a.relative_to(BASE/'science-final-decisions')
            rows.append(dict(relative=str(a.relative_to(BASE/'science-final-decisions')),baseline=ident(a),candidate=ident(b),equal=a.read_bytes()==b.read_bytes()))
        assert len(rows)==64
        assert all(x['equal'] for x in rows)
    save(OUT/'numerical-parity.json',dict(exit=code,decision_vectors=len(rows),bit_equal=sum(x['equal'] for x in rows),rows=rows,not_a_throughput_or_accuracy_acceptance=True))
    assert ident(ROOT/'tools/qwen35_text/main.cc')==read(OUT/'source-identity.json')['original']
    return code
if __name__=='__main__':
    if sys.argv[1]=='prepare': prepare()
    elif sys.argv[1]=='run': raise SystemExit(run())
    else: raise ValueError(sys.argv[1])
