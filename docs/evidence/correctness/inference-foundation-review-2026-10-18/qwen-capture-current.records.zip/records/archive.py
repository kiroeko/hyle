from pathlib import Path
import hashlib,json,sys,zipfile
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
DEST=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-capture-current.zip'
def ident(p):
    b=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x): p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
allowed={'.py','.cc','.h','.json','.tsv','.ids','.log','.txt','.diff','.f32','.bf16'}
files=[]; omitted=[]
for p in sorted(OUT.rglob('*')):
    if p.is_symlink(): raise RuntimeError('no linked paths allowed: '+str(p))
    if not p.is_file(): continue
    if p.name in {'archive-receipt.json','archive-inventory.json'}: continue
    if p.suffix in allowed: files.append(p)
    else: omitted.append(ident(p))
entries=[dict(relative=p.relative_to(OUT).as_posix(),**ident(p)) for p in files]
inventory=dict(destination=str(DEST),files=len(entries),payload_bytes=sum(x['bytes'] for x in entries),payloads=sum(p.name in {'logits.f32','hidden.bf16'} for p in files),omitted=omitted)
save(OUT/'archive-inventory.json',inventory)
if '--write' not in sys.argv:
    print(json.dumps({k:v for k,v in inventory.items() if k!='omitted'})); raise SystemExit(0)
assert not DEST.exists(),DEST
assert json.loads((OUT/'numerical-parity.json').read_text())['bit_equal']==64
assert (OUT/'capture-review.json').is_file(), 'read-only causal review not frozen'
before={p:ident(p) for p in files}
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files: z.write(p,p.relative_to(OUT).as_posix())
    z.writestr('archive-manifest.json',json.dumps(entries,indent=2)+'\n')
assert all(ident(p)==before[p] for p in files),'stage drift'
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    for e in entries: assert hashlib.sha256(z.read(e['relative'])).hexdigest()==e['sha256']
receipt=dict(archive=ident(DEST),entries=len(entries)+1,decision_payloads=inventory['payloads'],crc_verified=True,all_payload_sha256_verified=True,not_a_throughput_acceptance=True,all_stage_objects_images_and_math_caches_excluded=True)
save(OUT/'archive-receipt.json',receipt)
print(json.dumps(receipt))
