from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
import run as r
source=r.OUT/'consumer-capture.cc'; text=source.read_text(encoding='utf-8')
needle='      std::ofstream boundaries(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".boundaries.tsv"));'
assert text.count(needle)==1
extra='''      std::ofstream capture_facts(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".capture.tsv"));
      capture_facts << "kind\\tindex\\tprovider_or_lane\\tbegin\\tcount\\tcompatible\\tsupported\\n";
      for (std::size_t step = 0; step < phase.compiled.report.step_count(); ++step) {
        const auto fact = take(phase.compiled.report.step(step));
        capture_facts << "step\\t" << step << '\\t' << fact.provider.name << '\\t' << fact.node_begin
                      << '\\t' << fact.node_count << '\\t' << fact.runtime.capture_compatible << "\\t-\\n";
      }
      for (std::size_t index = 0; index < phase.compiled.report.segment_count(); ++index) {
        const auto fact = take(phase.compiled.report.segment(index));
        capture_facts << "segment\\t" << index << '\\t' << fact.lane.ordinal() << '\\t' << fact.step_begin
                      << '\\t' << fact.step_count << '\\t' << fact.capture_compatible << '\\t' << fact.capture_supported << '\\n';
      }
      if (!capture_facts) throw std::runtime_error("cannot write capture diagnostics");
'''
candidate=r.OUT/'consumer-facts.cc'; candidate.write_text(text.replace(needle,extra+needle),encoding='utf-8')
r.save(r.OUT/'facts-source-identity.json',dict(before=r.ident(source),after=r.ident(candidate),only_change='CompileReport segment and step capture facts; ordinary API only'))
argv=r.read(r.BASE/'compile-consumer.command.json')['argv']
argv=[str(candidate) if x.replace('\\','/').endswith('tools/qwen35_text/main.cc') else x for x in argv]
argv=[x for x in argv if not x.lower().startswith('/fo')]
idx=argv.index('/sourceDependencies'); argv[idx+1]=str(r.OUT/'consumer-facts.deps.json')
argv.append('/Fo'+str(r.OUT/'consumer-facts.obj'))
if r.call('compile-facts',argv,[r.OUT/'consumer-facts.obj',r.OUT/'consumer-facts.deps.json']): raise SystemExit(1)
argv=[str(r.OUT/'consumer-facts.obj') if x==str(r.BASE/'consumer.obj') else x for x in r.plan['command']]
assert str(r.OUT/'consumer-facts.obj') in argv
argv=[x for x in argv if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
argv+=['/OUT:'+str(r.OUT/'qwen-facts.exe'),'/MAP:'+str(r.OUT/'qwen-facts.map'),'/IMPLIB:'+str(r.OUT/'qwen-facts.lib')]
r.save(r.OUT/'facts-link-plan.json',dict(command=argv,origin=str(r.BASE/'matched-link-plan.json')))
if r.call('link-facts',argv,[r.OUT/('qwen-facts'+s) for s in ['.exe','.map','.lib','.exp']]): raise SystemExit(1)
(r.OUT/'facts-decode.ids').write_text((r.BASE/'science-decode.ids').read_text().split()[0]+'\n',encoding='ascii')
raise SystemExit(r.call('run-facts',[r.OUT/'qwen-facts.exe','--inputs',r.BASE/'science-inputs','--decode-ids',r.OUT/'facts-decode.ids','--capacity','64','--trace',r.OUT/'facts-decisions','--trace-level','decisions']))
