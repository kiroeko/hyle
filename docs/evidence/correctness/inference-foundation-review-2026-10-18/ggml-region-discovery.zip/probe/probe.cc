#include "tests/graph_ggml_discovery_test.h"
#if defined(HYLE_DISCOVERY_CUDA)
#include "hyle/graph/cuda.h"
#include "hyle/compute/cuda.h"
#include "hyle/compute/backends/cuda.h"
TEST(RegionDiscovery, DefaultCuda) {
  auto context = hyle::graph::cuda::create_context().value();
  auto memory = hyle::compute::cuda::MemoryResource::create(context,
      hyle::compute::cuda::MemoryKind::kDevice).value();
  ggml_discovery_test::exercise(context, memory.ref());
}
#else
#include "hyle/graph/cpu.h"
TEST(RegionDiscovery, DefaultCpu) {
  auto context = hyle::graph::cpu::create_context().value();
  ggml_discovery_test::exercise(context, hyle::mem::system_resource());
}
#endif
