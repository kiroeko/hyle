from pathlib import Path
import importlib.util, json, os, subprocess, sys, time

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
cuda=load('cached_cuda','.scratch/mtp-completion/run.py')
cpu=load('cached_cpu','.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command,env,expect=0):
    start=time.monotonic();command=list(map(str,command))
    p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=150)
    name=f'{len(records)+1}-{tag}'
    (OUT/(name+'.stdout.log')).write_bytes(p.stdout)
    (OUT/(name+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,round(time.monotonic()-start,2),p.stdout.decode(errors='replace')[-4000:],p.stderr.decode(errors='replace')[-1800:],flush=True)
    if (expect==0 and p.returncode) or (expect!=0 and not p.returncode):raise SystemExit(p.returncode or 1)

def build(route):
    if route=='cuda':
        host=load('cached_host','.scratch/inference-feature-completion-2026-10-18/windows-batch/build_host.py')
        cl,link,env,flags=cuda.cl,cuda.link,host.env,cuda.flags+['/I'+str(ROOT),'/DHYLE_DISCOVERY_CUDA=1']
        source=ROOT/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc'
        commands=json.loads((ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/commands.json').read_text())
        command=next(x['command'] for x in reversed(commands) if x['tag']=='default-link')
        replaced=[ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/default-probe.obj',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/region.obj']
    else:
        cl,link,env=cpu.CL,cpu.LINK,cpu.ENV.copy()
        flags=cpu.hyle_flags(dict(cpu.PINS['mixed'],folder=Path('mixed')))+['/I'+str(ROOT)]
        source=ROOT/'src/graph_route_cpu/ggml_region.cc'
        commands=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/commands.json').read_text())
        command=next(x['command'] for x in reversed(commands) if 'link' in x['tag'] and 'consumer.exe' in ' '.join(x['command']))
        replaced=[ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/consumer.obj']
        torch=Path(next(x.split('=',1)[1] for x in (cpu.BASE/'CMakeCache.txt').read_text().splitlines() if x.startswith('TORCH_LIBRARY:'))).parent
        env['PATH']=str(torch)+os.pathsep+env['PATH']
    runtime_dirs=list(dict.fromkeys(str(Path(x).parent) for x in command if x.endswith('.lib') and Path(x).is_absolute()))
    env=env.copy();env['PATH']=os.pathsep.join(runtime_dirs+[env['PATH']])
    flags+=['/I'+str(source.parent)]
    canonical='--canonical' in sys.argv
    test_obj=OUT/(route+('-canonical.obj' if canonical else '-test.obj'))
    if '--run-only' not in sys.argv:
        test_source=ROOT/('tests/graph_route_cuda/ggml_test.cc' if route=='cuda' else 'tests/graph_route_cpu/graph_test.cc') if canonical else OUT/'probe.cc'
        run(route+'-test-compile',[cl,*flags,test_source,'/Fo'+str(test_obj)],env)
    for revision in (['after'] if canonical else ['before','after']):
        region=OUT/(route+'-region.'+revision+'.obj')
        if '--run-only' not in sys.argv and not canonical:
            run(route+'-'+revision+'-compile',[cl,*flags,OUT/(route+'-region.before.cc') if revision=='before' else source,'/Fo'+str(region)],env)
        # The saved source stays beside its original include-relative path.
        # Supply that directory explicitly instead of replicating source trees.
        exe=OUT/(route+('-canonical' if canonical else '-'+revision)+'.exe')
        args=[x for x in command if not x.startswith('/OUT:') and not x.startswith('/MAP:') and Path(x) not in replaced]
        args.extend([str(test_obj),str(region),'/OUT:'+str(exe)])
        if route=='cpu':args.extend([str(cpu.BASE/'bin/hyle_graph_route_cpu.lib'),str(cpu.BASE/'bin/hyle_graph_provider_onednn.lib'),str(cpu.BASE/'lib/gtest_main.lib'),str(cpu.BASE/'lib/gtest.lib')])
        if '--run-only' not in sys.argv:run(route+'-'+revision+'-link',args,env)
        filt='CudaDefaultGraph.NativeRegionsSurviveOtherProviderBoundaries:CudaDefaultGraph.OriginalTensorRegionThroughOrdinaryEntry:CudaDefaultGraph.OriginalSoftmaxRegionThroughOrdinaryEntry:CudaDefaultGraph.OriginalGgmlRegionComposesWithCublas' if route=='cuda' else 'CpuDefaultGraph.NativeRegionsSurviveOtherProviderBoundaries:CpuDefaultGraph.MatureNormPostOpsFuseAndPreserveObservableBoundaries'
        run(route+'-'+revision+'-test',[exe,'--gtest_filter='+ (filt if canonical else 'RegionDiscovery.*'),'--gtest_color=no'],env,expect=1 if revision=='before' else 0)

if __name__=='__main__':build(sys.argv[1])
