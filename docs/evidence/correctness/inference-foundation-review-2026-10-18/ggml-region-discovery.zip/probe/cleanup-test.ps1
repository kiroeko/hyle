# Completed probes only. Source/results packages were copied to docs first.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
foreach ($archive in @('ggml-region-discovery.zip', 'cuda-weight-order.zip')) {
    $path = Join-Path $workspace "docs/evidence/correctness/inference-foundation-review-2026-10-18/$archive"
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing source/results package: $path" }
}
$relative = @(
    '.scratch/inference-foundation-review-2026-10-18/region-discovery/cpu-before.exe',
    '.scratch/inference-foundation-review-2026-10-18/region-discovery/cpu-after.exe',
    '.scratch/inference-foundation-review-2026-10-18/region-discovery/cpu-canonical.exe',
    '.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-before.exe',
    '.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-after.exe',
    '.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-canonical.exe',
    '.scratch/inference-foundation-review-2026-10-18/weight-order/before.exe',
    '.scratch/inference-foundation-review-2026-10-18/weight-order/after.exe',
    '.scratch/inference-foundation-review-2026-10-18/weight-order/canonical.exe'
)
$targets = foreach ($entry in $relative) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $entry))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $parent = Get-Item -LiteralPath ([IO.Path]::GetDirectoryName($path))
    if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected directory link: $path" }
    $path
}
$freed = 0L
foreach ($target in $targets) {
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $item = Get-Item -LiteralPath $target
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected file link: $target" }
        $freed += $item.Length
        Remove-Item -LiteralPath $target
    }
}
Write-Output "Removed completed test executables: $freed bytes. Source, logs and reusable objects retained."
