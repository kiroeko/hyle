from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sources=['src/graph_ggml_shared/region_discovery.h','src/graph_route_cpu/ggml_region.cc',
 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc','tests/graph_ggml_discovery_test.h',
 'tests/graph_route_cpu/graph_test.cc','tests/graph_route_cuda/ggml_test.cc']
files=[ROOT/p for p in sources]
files += [p for p in OUT.iterdir() if p.is_file() and p.suffix in ['.cc','.py','.json','.log','.md','.ps1']]
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,'source/'+p.relative_to(ROOT).as_posix() if p in [ROOT/x for x in sources] else 'probe/'+p.name)
print(json.dumps(dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
