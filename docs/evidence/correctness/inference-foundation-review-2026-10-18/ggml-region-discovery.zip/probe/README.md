# GGML region discovery across actual provider boundaries

CPU and CUDA default rosters, 2026-10-18. Saved before sources include earlier
constant/ID work; only discovery differs. TopK sits between four supported unary
nodes. Data and control re-entry both have 0 regions / 5 steps before, 2 regions /
3 steps after; an independent interleaved TopK retains 1 region / 2 steps.
Every published F32/I32 value is checked exactly over two changed inputs.

Actual canonical TUs: CPU 2/2 and CUDA 4/4 selected tests pass, including original
norm/softmax/tensor/mixed cuBLAS cases. Native binaries and SDKs were reused.
Regions are execution islands, not assertions of one physical GPU kernel or
measured throughput. The new traversal is linear in nodes plus data/control
edges; final compiler contractibility checks remain authoritative.

Initial fixture compilation omitted explicit Operation constructors; initial
default CUDA probe lacked its cached Torch DLL directories, and the CPU link
omitted the graph route library. Those failed logs are preserved. Corrected
baseline failures are four region/step-count assertions, with numerical values
still correct; candidate passes. Canonical runners ran concurrently: their
separate stdout/stderr logs survive, while commands.json retains the serial
probes and final CPU canonical records. run.py contains both exact canonical
commands and filters. No timings here are performance measurements.
