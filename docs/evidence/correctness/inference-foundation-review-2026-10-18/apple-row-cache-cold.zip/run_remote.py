from pathlib import Path
import hashlib, json, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
CODEC = ROOT.parent / 'inference-foundation-review-20261018-apple-row-cache'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
old = json.loads((CODEC/'commands.json').read_text())
compile_base = next(x['command'] for x in old if x['tag']=='row-cache.o-compile')
link_base = next(x['command'] for x in old if x['tag']=='tests-link' and x['exit']==0)
records = json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []

def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def run(tag, command):
    command = list(map(str, command))
    stem = f'{len(records)+1:02d}-{tag}'
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=150)
    (ROOT/(stem+'.stdout.log')).write_bytes(result.stdout)
    (ROOT/(stem+'.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag, command=command, cwd=str(ROOT), exit=result.returncode,
                        seconds=time.monotonic()-start, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log'))
    (ROOT/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(stem, result.returncode, flush=True)
    print(result.stdout.decode(errors='replace')[-5500:]+result.stderr.decode(errors='replace')[-5500:], flush=True)
    if result.returncode:
        raise SystemExit(1)

def link(name, probe=False):
    command = []
    replaced = dict(context=0, operations=0)
    for arg in link_base:
        if arg == str(CODEC/'row-cache-test'):
            command.append(str(ROOT/name))
        elif arg.endswith('/context.o'):
            command.append(str(ROOT/'context.o'))
            replaced['context'] += 1
        elif arg.endswith('/operations.o'):
            command.append(str(ROOT/'operations.o'))
            replaced['operations'] += 1
        elif probe and arg == str(CODEC/'test.o'):
            command.append(str(ROOT/'probe.o'))
        elif probe and arg.endswith(('libgtest.a','libgtest_main.a')):
            continue
        elif arg.startswith('-Wl,-map,'):
            command.append('-Wl,-map,'+str(ROOT/(name+'.map')))
        else:
            command.append(arg)
    assert replaced == dict(context=1, operations=1), replaced
    run(name+'-link', command)
    values = [identity(p) for p in command if p.endswith(('.o','.a','.dylib'))]
    values.append(identity(ROOT/name))
    (ROOT/('identities-'+name+'.json')).write_text(json.dumps(values, indent=2)+'\n')

def build():
    assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
    (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)
        + subprocess.check_output(['xcrun','clang++','--version'],text=True))
    if not (ROOT/'mlx.metallib').exists():
        (ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
    assert (ROOT/'mlx.metallib').resolve() == (SDK/'lib/mlx.metallib').resolve()
    prefix = compile_base[:compile_base.index('-c')]
    prefix[1:1] = ['-I'+str(ROOT/'include'),'-I'+str(ROOT),
                   '-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(ROOT/'src/compute')]
    for source, obj in [('src/compute_route_apple/apple_context.cc','context.o'),
                        ('src/compute_route_apple/apple_operations.cc','operations.o'),
                        ('prepare_probe.cc','probe.o')]:
        run(obj+'-compile', prefix+['-c',ROOT/source,'-o',ROOT/obj])
    link('prepare-only', True)
    link('row-cache-test')

def test():
    run('prepare-only', [ROOT/'prepare-only'])
    run('real-bank-replay', [ROOT/'row-cache-test','--gtest_filter=AppleRowCache.*'])

if __name__=='__main__':
    {'build':build,'test':test}[sys.argv[1]]()
