#include <mlx/memory.h>
#include <mlx/ops.h>

#include <array>
#include <cstdio>
#include <stdexcept>

#include "hyle/compute/apple.h"
#include "hyle/compute/model_ops.h"

namespace c = hyle::compute;
namespace a = c::apple;
namespace mx = mlx::core;

template <class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}

int main() {
  try {
    auto context = take(a::Context::create());
    const auto encoding = c::RowCacheEncoding::float8_block64_tail64();
    constexpr int rows = 262144;
    constexpr std::size_t limit = 16 * 1024 * 1024;
    const auto description = take(c::row_cache_carrier_description(encoding, rows));
    const std::array inputs{
        a::InputSpec{{rows, static_cast<int>(encoding.row_bytes())}, mx::uint8, description},
        a::InputSpec{{2, 3}, mx::int32}};
    mx::clear_cache();
    mx::reset_peak_memory();
    struct RestoreLimit {
      std::size_t value;
      ~RestoreLimit() { mx::set_memory_limit(value); }
    } restore{mx::set_memory_limit(limit)};
    const auto active_before = mx::get_active_memory();
    const auto cache_before = mx::get_cache_memory();
    auto program = take(context.prepare(c::model_ops::row_cache_gather_decode(encoding), inputs));
    const auto active = mx::get_active_memory();
    const auto cache = mx::get_cache_memory();
    const auto peak = mx::get_peak_memory();
    std::printf("{\"mode\":\"typed_prepare_only\",\"rows\":%d,\"row_bytes\":%u,"
        "\"logical_bank_bytes\":%zu,\"ids\":6,\"limit\":%zu,"
        "\"active_before\":%zu,\"cache_before\":%zu,\"active\":%zu,"
        "\"cache\":%zu,\"peak\":%zu,\"real_bank_allocated\":false}\n",
        rows, encoding.row_bytes(), take(description.required_bytes()), limit,
        active_before, cache_before, active, cache, peak);
    if (peak >= limit) throw std::runtime_error("typed prepare materialized a bank-sized allocation");
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "%s\n", error.what());
    return 1;
  }
}
