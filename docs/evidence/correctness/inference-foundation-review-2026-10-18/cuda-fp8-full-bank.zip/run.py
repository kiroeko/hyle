from pathlib import Path
import importlib.util,json,sys
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-fp8-full-bank'
spec=importlib.util.spec_from_file_location('gather',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/run.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
r=g.r;r.OUT=OUT;r.records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import link_run as old
flags=g.flags+['/I'+str(ROOT/'src/compute_provider_cuda'),'/I'+str(ROOT/'third_party/sglang_activation')]
def build():
    for source,stem in [(OUT/'grouped.before.cc','old-grouped'),('src/compute_provider_cuda/grouped_fp8_provider.cc','new-grouped'),('tests/compute_provider_cuda/cuda_provider_test.cc','tests')]:
        r.compile(source,stem,r.cuda.cl,flags,r.cuda.env)
    link()
def link():
    base=ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch';mla=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla';ge=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements'
    replace={base/'public-consumer.obj':OUT/'tests.obj',base/'flashinfer-provider.obj':mla/'flashinfer-provider.obj',base/'batch-execution.obj':mla/'batch-execution.obj',base/'graph-batch.obj':mla/'graph-batch.obj'}
    replace.update({ROOT/'.scratch/mtp-completion'/(s+'.obj'):ge/(s+'.obj') for s in ['provider','tensor','region']})
    common=[replace.get(p,p) for p in old.objects]
    common += [ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices/guard.obj']
    common += [mla/p for p in ['batch-layout.obj','paged-arena.obj','native_mla.obj']]+[base/'highdim-review/native_highdim.obj']
    for arm in ['old','new']:
        objects=[OUT/(arm+'-grouped.obj') if p==base/'cuda-grouped_fp8_provider.obj' else p for p in common]
        for p in [*objects,*old.libs]:assert p.is_file(),p
        r.run(arm+'-link',[r.cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/(arm+'.exe')),'/MAP:'+str(OUT/(arm+'.map')),*objects,*old.libs,r.cuda.BASE/'lib/gtest_main.lib',r.cuda.BASE/'lib/gtest.lib',*old.system],old.b.env)
def test():
    # Baseline must fail prepare before any bank allocation. Its original gate
    # is retained; this expected assertion is not a native/runtime crash.
    import subprocess,time
    cmd=[str(OUT/'old.exe'),'--gtest_filter=SglangFp8.FullGlmBankUsesHighExpertAddressBeyondTwoGiB','--gtest_color=no']
    t=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=old.b.env,capture_output=True,timeout=120)
    (OUT/'old-control.stdout.txt').write_bytes(p.stdout);(OUT/'old-control.stderr.txt').write_bytes(p.stderr)
    r.records.append(dict(tag='old-control',command=cmd,cwd=str(ROOT),exit=p.returncode,expected_exit=1,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(r.records,indent=2)+'\n')
    print('old-control',p.returncode,flush=True);assert p.returncode==1
    r.run('new-test',[OUT/'new.exe','--gtest_filter=SglangFp8.FullGlmBankUsesHighExpertAddressBeyondTwoGiB:SglangFp8.GroupedColdDomainAndActivationAlignment','--gtest_color=no'],old.b.env)
if __name__=='__main__':{'build':build,'link':link,'test':test}[sys.argv[1]]()
