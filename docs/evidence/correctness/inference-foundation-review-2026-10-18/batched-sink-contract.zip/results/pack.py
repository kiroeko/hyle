from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[3]
stage = Path(__file__).resolve().parent
sources = ['include/hyle/compute/model_ops.h',
    'tests/compute_ops/operation_test.cc',
    'tests/compute_models/batched_sink_fixture.h',
    'tests/graph_batched_sink_test.h',
    'tests/graph_route_cpu/graph_test.cc']
records = []
destination = root / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/batched-sink-contract.zip'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sources:
        raw = (root / name).read_bytes()
        archive.writestr('source/' + name, raw)
        records.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest()})
    for p in stage.iterdir():
        if p.suffix in {'.py', '.json', '.log'}:
            archive.write(p, 'results/' + p.name)
    archive.writestr('source-identities.json', json.dumps(records, indent=2) + '\n')
print(destination.name, destination.stat().st_size, hashlib.sha256(destination.read_bytes()).hexdigest())
