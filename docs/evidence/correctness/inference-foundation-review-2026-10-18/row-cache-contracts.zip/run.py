from pathlib import Path
import importlib.util
import json
import subprocess
import time

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cpu_cache',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
c=importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

def main():
    records=[]
    def run(tag,args):
        args=list(map(str,args)); start=time.monotonic()
        result=subprocess.run(args,cwd=ROOT,env=c.ENV,capture_output=True,timeout=90)
        (OUT/(tag+'.stdout.log')).write_bytes(result.stdout)
        (OUT/(tag+'.stderr.log')).write_bytes(result.stderr)
        records.append(dict(tag=tag,command=args,exit=result.returncode,seconds=time.monotonic()-start))
        (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
        print(tag,result.returncode,result.stdout.decode(errors='replace')[-2400:],result.stderr.decode(errors='replace')[-2400:],flush=True)
        if result.returncode: raise SystemExit(result.returncode)
    flags=c.hyle_flags(dict(c.PINS['mixed'],folder=Path('mixed')))+['/I'+str(c.BASE/'_deps/googletest-src/googletest/include')]
    for source,name in [('src/compute_ops/low_precision.cc','low-precision'),('tests/compute_ops/low_precision_test.cc','tests')]:
        run(name+'-compile',[c.CL,*flags,ROOT/source,'/Fo'+str(OUT/(name+'.obj'))])
    libs=[c.BASE/'bin'/(name+'.lib') for name in ['hyle_compute_ops','hyle_compute','hyle_container','hyle_mem','mimalloc_static','hyle_error','hyle_simd','hyle_platform_thread','hyle_platform','hyle_time']]
    exe=OUT/'schema.exe'
    run('link',[c.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),OUT/'tests.obj',OUT/'low-precision.obj',*libs,c.BASE/'lib/gtest_main.lib',c.BASE/'lib/gtest.lib',*c.SYSTEM])
    run('schema',[exe,'--gtest_color=no','--gtest_filter=ComputeOpsRowCache.*:ComputeOpsCacheStorage.*'])

if __name__=='__main__': main()
