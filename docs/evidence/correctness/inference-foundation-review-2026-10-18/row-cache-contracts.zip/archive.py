from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    sources = [
        'include/hyle/compute/low_precision.h',
        'include/hyle/compute/model_ops.h',
        'src/compute_ops/low_precision.cc',
        'tests/compute_ops/low_precision_test.cc',
        'docs/user/compute.md',
    ]
    summary = {
        'scope': 'Provider-independent row-inline cache descriptors and two custom operation schemas; not a native page layout or official model cache ABI.',
        'formats': {
            'main': 'BF16[rows,512] -> U8[rows,584]:448 E4M3FN codes,128 unchanged BF16 tail bytes,7 UE8M0 scales,one zero pad.',
            'index': 'BF16[rows,128] -> U8[rows,68]:64 E2M1 packed bytes (even low nibble),4 UE8M0 scales.',
        },
        'operations': 'RowCacheEncode encodes supplied new rows only; RowCacheGatherDecode decodes only IDs into BF16[IDs...,depth]. Checked requires validating all IDs before writing output. Neither operation supplies visibility metadata or acquires page permissions.',
        'schema_validation': 'Fresh low_precision.cc and existing low_precision_test.cc TUs with /W4 /WX plus original cached compute/core/gtest libraries:7/7 pass (3 RowCache,4 old CacheStorage). Covers both formats,scalar and rank2 IDs,empty input and empty bank/IDs,invalid dtype/layout/format/index rank and required-byte overflow.',
        'compatibility': 'Old CacheStorage remains 8 bytes and is not reinterpreted. New RowCacheEncoding is 4 bytes. No BatchSchema/CacheStorage/page-arena ABI changes.',
        'source_truth': 'Original DeepSeek model stores BF16 QAT. Packed storage is an explicitly defined Hyle capability. Official source identity and mathematical basis are in prior-design/source-proof.json; numeric provider and StateStore consumers are separate linked evidence.',
        'not_verified_here': ['No provider numeric execution in this schema-only package', 'No full-model, native paged attention, packed indexer scoring or throughput claim', 'No full CMake configure or SDK rebuild'],
        'sources': {p: sha(ROOT / p) for p in sources},
    }
    (OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    files = [(OUT / name, name) for name in ['run.py', 'archive.py', 'summary.json', 'commands.json']]
    files += [(p, p.name) for p in sorted(OUT.glob('*.log'))]
    files += [(ROOT / name, 'sources/' + name) for name in sources]
    proof = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/deepseek-packed-history/source-proof.json'
    files.append((proof, 'prior-design/source-proof.json'))
    target = DEST / 'row-cache-contracts.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, name in files:
            assert path.is_file(), path
            archive.writestr(name, path.read_bytes())
    print(json.dumps({'archive': str(target.relative_to(ROOT)), 'entries': len(files), 'bytes': target.stat().st_size, 'sha256': sha(target)}))
    target = DEST / 'row-cache-cpu.zip'
    origin = ROOT / '.scratch/inference-foundation-review-2026-10-18/row-cache-cpu/source-results.zip'
    assert sha(origin) == 'd4b2a3e1300908a7e23c867380464d722dad19bd92a0c221161b929632f12227'
    target.write_bytes(origin.read_bytes())
    target = DEST / 'row-cache-cuda.zip'
    origin = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/deepseek-packed-history/cuda/source-results.zip'
    assert sha(origin) == '5def1ccc3e5303c9465bd08d11ee175c7850d24d53b8d6ff3a7ec7bb6fe4586e'
    target.write_bytes(origin.read_bytes())
    for path in [DEST / 'row-cache-cpu.zip', DEST / 'row-cache-cuda.zip']:
        print(json.dumps({'archive': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': sha(path)}))


if __name__ == '__main__':
    main()
