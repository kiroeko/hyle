#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <limits>

#include "hyle/compute/low_precision.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/operation.h"

namespace {
using namespace hyle::compute;

TEST(ComputeOpsRowCache, EncodedRowsAndSelectedValuesKeepTheirOwnShapes) {
  static_assert(sizeof(CacheStorage)==8);
  static_assert(sizeof(RowCacheEncoding)==4);
  for (const auto encoding : {RowCacheEncoding::float8_block64_tail64(),
                             RowCacheEncoding::float4_block32()}) {
    const auto rows=TensorDesc::dense(DataType::kBFloat16,
        std::array<std::int64_t,2>{3,encoding.depth()}).value();
    const auto carrier=row_cache_carrier_description(encoding,3);
    ASSERT_TRUE(carrier);
    EXPECT_EQ(carrier->data_type(),DataType::kUInt8);
    EXPECT_EQ(carrier->dimensions()[1],encoding.row_bytes());
    EXPECT_EQ(*carrier->required_bytes(),3u*encoding.row_bytes());
    auto encoded=infer_single_output(model_ops::row_cache_encode(encoding),std::array{rows});
    ASSERT_TRUE(encoded);
    EXPECT_EQ(*encoded,*carrier);
    // More selections than bank rows and repeated IDs are legitimate.
    const auto ids=TensorDesc::dense(DataType::kInt32,std::array<std::int64_t,2>{2,5}).value();
    auto selected=infer_single_output(model_ops::row_cache_gather_decode(encoding),std::array{*carrier,ids});
    ASSERT_TRUE(selected);
    EXPECT_EQ(*selected,TensorDesc::dense(DataType::kBFloat16,
        std::array<std::int64_t,3>{2,5,encoding.depth()}).value());
    const auto scalar=TensorDesc::dense(DataType::kInt32,std::span<const std::int64_t>{}).value();
    EXPECT_EQ(*infer_single_output(model_ops::row_cache_gather_decode(encoding),std::array{*carrier,scalar}),
        TensorDesc::dense(DataType::kBFloat16,std::array<std::int64_t,1>{encoding.depth()}).value());
  }
}

TEST(ComputeOpsRowCache, RejectsMismatchedEncodingDtypeAndIndexRank) {
  const auto encoding=RowCacheEncoding::float8_block64_tail64();
  const auto bank=row_cache_carrier_description(encoding,3).value();
  const auto ids=TensorDesc::dense(DataType::kInt32,std::array<std::int64_t,1>{2}).value();
  const auto wrong_ids=TensorDesc::dense(DataType::kInt64,std::array<std::int64_t,1>{2}).value();
  const auto wrong_rows=TensorDesc::dense(DataType::kFloat32,std::array<std::int64_t,2>{3,512}).value();
  const auto wrong_depth=TensorDesc::dense(DataType::kBFloat16,std::array<std::int64_t,2>{3,511}).value();
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_encode(encoding),std::array{wrong_rows}));
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_encode(encoding),std::array{wrong_depth}));
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_gather_decode(encoding),std::array{bank,wrong_ids}));
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_gather_decode(RowCacheEncoding::float4_block32()),std::array{bank,ids}));
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_gather_decode(encoding,static_cast<IndexBoundsPolicy>(255)),std::array{bank,ids}));
  std::array<std::int64_t,kMaxTensorRank> dimensions{}; dimensions.fill(1);
  const auto full_rank=TensorDesc::dense(DataType::kInt32,dimensions).value();
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_gather_decode(encoding),std::array{bank,full_rank}));
}

TEST(ComputeOpsRowCache, EmptySelectionsAndCapacityOverflowAreDistinct) {
  const auto encoding=RowCacheEncoding::float8_block64_tail64();
  const auto empty=row_cache_carrier_description(encoding,0).value();
  const auto no_ids=TensorDesc::dense(DataType::kInt32,std::array<std::int64_t,1>{0}).value();
  const auto one_id=TensorDesc::dense(DataType::kInt32,std::array<std::int64_t,1>{1}).value();
  const auto selected=infer_single_output(model_ops::row_cache_gather_decode(encoding),std::array{empty,no_ids});
  ASSERT_TRUE(selected);
  EXPECT_EQ(*selected->element_count(),0u);
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_gather_decode(encoding),std::array{empty,one_id}));
  EXPECT_FALSE(row_cache_carrier_description(encoding,-1));
  EXPECT_FALSE(row_cache_carrier_description(encoding,std::numeric_limits<std::int64_t>::max()));
  const auto many_ids=TensorDesc::dense(DataType::kInt32,
      std::array<std::int64_t,1>{std::numeric_limits<std::int64_t>::max()/4}).value();
  const auto bank=row_cache_carrier_description(encoding,1).value();
  EXPECT_FALSE(infer_single_output(model_ops::row_cache_gather_decode(encoding),std::array{bank,many_ids}));
}

TEST(ComputeOpsCacheStorage, CacheDepthBlocksAndRealCopyCarrier) {
  const auto storage = CacheStorage::q8_0();
  ASSERT_TRUE(storage);
  constexpr std::array<std::int64_t, 4> shape{2, 16, 2, 256};
  const auto logical = cache_tensor_description(*storage, shape);
  const auto carrier = cache_carrier_description(*storage, shape);
  ASSERT_TRUE(logical);
  ASSERT_TRUE(carrier);
  EXPECT_EQ(logical->storage_format().id(), kGgufQ8_0);
  EXPECT_EQ(logical->block_axis(), 3u);
  EXPECT_TRUE(std::ranges::equal(logical->byte_strides(),
                               std::array<std::int64_t, 4>{8704, 544, 272, 34}));
  EXPECT_EQ(*logical->required_bytes(), 17408u);
  EXPECT_EQ(*carrier->required_bytes(), 17408u);
  EXPECT_TRUE(carrier->is_plain());
  EXPECT_TRUE(carrier->is_dense());
  EXPECT_EQ(carrier->data_type(), DataType::kUInt8);
  EXPECT_TRUE(std::ranges::equal(carrier->dimensions(),
                               std::array<std::int64_t, 2>{64, 272}));
  const auto value = cache_tensor_description(*storage,
      std::array<std::int64_t, 4>{2, 16, 2, 128});
  ASSERT_TRUE(value);
  EXPECT_EQ(*value->required_bytes(), 8704u);
}

TEST(ComputeOpsCacheStorage, Float8ScaleIsSeparateFromCodeBytes) {
  const auto k = CacheStorage::float8(0.25F);
  const auto v = CacheStorage::float8(2.0F);
  ASSERT_TRUE(k);
  ASSERT_TRUE(v);
  EXPECT_NE(*k, *v);
  constexpr std::array<std::int64_t, 3> shape{17, 2, 256};
  const auto logical = cache_tensor_description(*k, shape);
  const auto carrier = cache_carrier_description(*k, shape);
  ASSERT_TRUE(logical);
  ASSERT_TRUE(carrier);
  EXPECT_EQ(*logical, *carrier);
  EXPECT_EQ(logical->data_type(), DataType::kFloat8E4M3FN);
  EXPECT_EQ(*logical->required_bytes(), 17u * 2 * 256);
  EXPECT_EQ(*logical, *cache_tensor_description(*v, shape));
  EXPECT_NE(logical->storage_format().id(), kFloat8ActivationFloat32Block128);
}

TEST(ComputeOpsCacheStorage, RefusesInvalidInterpretationAndOverflow) {
  for (float scale : {0.0F, -1.0F, std::numeric_limits<float>::infinity(),
                     std::numeric_limits<float>::quiet_NaN()})
    EXPECT_FALSE(CacheStorage::float8(scale));
  const auto q8 = CacheStorage::q8_0();
  ASSERT_TRUE(q8);
  EXPECT_FALSE(CacheStorage::plain(DataType::kFloat32));
  EXPECT_FALSE(CacheStorage::plain(DataType::kUnknown));
  EXPECT_FALSE(CacheStorage::plain(DataType::kInt8));
  EXPECT_TRUE(validate_cache_storage(*q8).ok());
  EXPECT_EQ(q8->format().bytes_per_block(), 34u);
  EXPECT_FALSE(cache_tensor_description(*q8, std::array<std::int64_t, 2>{1, 33}));
  EXPECT_FALSE(cache_tensor_description(*q8, std::array<std::int64_t, 2>{-1, 32}));
  EXPECT_FALSE(cache_tensor_description(*q8,
      std::array<std::int64_t, 3>{INT64_MAX, 2, 256}));
  EXPECT_FALSE(cache_tensor_description(*q8, std::array<std::int64_t, 1>{32}));
}

TEST(ComputeOpsCacheStorage, DirtyEncoderOutputIsExactPhysicalCarrier) {
  const auto q8 = CacheStorage::q8_0();
  ASSERT_TRUE(q8);
  const auto fp8 = CacheStorage::float8(0.5F);
  ASSERT_TRUE(fp8);
  for (auto type : {DataType::kFloat16, DataType::kBFloat16, DataType::kFloat32}) {
    const auto input = TensorDesc::dense(type,
        std::array<std::int64_t, 3>{3, 2, 256});
    ASSERT_TRUE(input);
    const auto encoded = infer_single_output(Operation::custom(model_ops::CacheEncode{*q8}),
                                            std::array{*input});
    ASSERT_TRUE(encoded);
    EXPECT_EQ(*encoded->required_bytes(), 3u * 2 * 272);
    EXPECT_EQ(encoded->data_type(), DataType::kUInt8);
    EXPECT_EQ(*encoded, *cache_carrier_description(*q8, input->dimensions()));
    const auto float8 = infer_single_output(Operation::custom(model_ops::CacheEncode{*fp8}),
                                           std::array{*input});
    ASSERT_TRUE(float8);
    EXPECT_EQ(*float8->required_bytes(), 3u * 2 * 256);
  }
  const auto empty = TensorDesc::dense(DataType::kFloat16,
      std::array<std::int64_t, 3>{0, 2, 256});
  ASSERT_TRUE(empty);
  const auto output = infer_single_output(Operation::custom(model_ops::CacheEncode{*q8}),
                                         std::array{*empty});
  ASSERT_TRUE(output);
  EXPECT_EQ(*output->required_bytes(), 0u);
  const auto scalar = TensorDesc::dense(DataType::kFloat16, {});
  ASSERT_TRUE(scalar);
  EXPECT_FALSE(infer_single_output(Operation::custom(model_ops::CacheEncode{*q8}),
                                  std::array{*scalar}));
}

TEST(ComputeOpsLowPrecision, Float8PhysicalSizesAndLogicalOrientation) {
  const auto block = Float8ScaleMode::kFloat32Block128;
  const auto group = Float8ScaleMode::kUnsignedExponent8Group32;
  const auto activation = float8_activation_description(3, 256, block);
  const auto weight = float8_weight_description(256, 128, block);
  ASSERT_TRUE(activation);
  ASSERT_TRUE(weight);
  EXPECT_EQ(activation->data_type(), DataType::kFloat32);
  EXPECT_EQ(*activation->required_bytes(), 3u * 256 + 3u * 2 * 4);
  EXPECT_EQ(*weight->required_bytes(), 128u * 256 + 1u * 2 * 4);
  EXPECT_EQ(weight->dimensions()[0], 256);
  EXPECT_EQ(weight->dimensions()[1], 128);
  EXPECT_EQ(weight->required_alignment(), 4u);
  EXPECT_TRUE(weight->byte_strides().empty());
  EXPECT_NE(activation->storage_format().id(), weight->storage_format().id());
  const auto ue8_activation = float8_activation_description(3, 64, group);
  const auto ue8_weight = float8_weight_description(64, 5, group);
  ASSERT_TRUE(ue8_activation);
  ASSERT_TRUE(ue8_weight);
  EXPECT_EQ(*ue8_activation->required_bytes(), 3u * 64 + 3u * 2);
  EXPECT_EQ(*ue8_weight->required_bytes(), 5u * 64 + 5u * 2);
  EXPECT_NE(weight->storage_format().id(), ue8_weight->storage_format().id());
  const auto output = infer_single_output(Operation(MatMul{}),
                                          std::array{*activation, *weight});
  ASSERT_TRUE(output);
  EXPECT_EQ(output->dimensions()[0], 3);
  EXPECT_EQ(output->dimensions()[1], 128);
  EXPECT_TRUE(output->is_dense());
  EXPECT_EQ(output->data_type(), DataType::kFloat32);
}

TEST(ComputeOpsLowPrecision, GroupedFloat8LayoutAndOverflow) {
  const auto w = float8_grouped_weight_description(9, 129, 256);
  ASSERT_TRUE(w);
  EXPECT_TRUE(std::ranges::equal(w->dimensions(), std::array<std::int64_t, 3>{9, 129, 256}));
  EXPECT_EQ(w->required_bytes().value(), 9u * 129 * 256 + 9u * 2 * 2 * 4);
  EXPECT_EQ(w->required_alignment(), 4u);
  EXPECT_FALSE(float8_grouped_weight_description(0, 129, 256));
  EXPECT_FALSE(float8_grouped_weight_description(9, 129, 257));
  EXPECT_FALSE(float8_grouped_weight_description(INT64_MAX, 129, 256));
  EXPECT_FALSE(float8_grouped_weight_description(2, INT64_MAX, 256));
}

TEST(ComputeOpsLowPrecision, GroupedFloat4LayoutAndOverflow) {
  const auto w = float4_grouped_weight_description(7, 129, 256);
  ASSERT_TRUE(w);
  EXPECT_TRUE(std::ranges::equal(w->dimensions(), std::array<std::int64_t, 3>{7, 129, 256}));
  EXPECT_EQ(w->required_bytes().value(), 7u * 129 * (128 + 8 * 4));
  EXPECT_EQ(w->required_alignment(), 4u);
  EXPECT_EQ(w->storage_format().id(), kFloat4GroupedWeightFloat32Group32);
  EXPECT_NE(w->storage_format().id(), kMxfp4Weight);
  EXPECT_FALSE(float4_grouped_weight_description(0, 129, 256));
  EXPECT_FALSE(float4_grouped_weight_description(7, 129, 257));
  EXPECT_FALSE(float4_grouped_weight_description(INT64_MAX, 129, 256));
  EXPECT_FALSE(float4_grouped_weight_description(2, INT64_MAX, 256));
}

TEST(ComputeOpsLowPrecision, Mxfp4BlockAxisFollowsLogicalK) {
  const auto weight = mxfp4_weight_description(64, 5);
  ASSERT_TRUE(weight);
  EXPECT_EQ(weight->data_type(), DataType::kFloat16);
  EXPECT_EQ(*weight->required_bytes(), 170u);
  ASSERT_TRUE(weight->block_axis());
  EXPECT_EQ(*weight->block_axis(), 0u);
  EXPECT_EQ(weight->byte_strides()[0], 17);
  EXPECT_EQ(weight->byte_strides()[1], 34);
  const auto physical = weight->transposed();
  ASSERT_TRUE(physical);
  EXPECT_TRUE(physical->is_dense());
  EXPECT_EQ(physical->dimensions()[0], 5);
  EXPECT_EQ(physical->dimensions()[1], 64);
  const auto activation =
      TensorDesc::dense(DataType::kFloat16, std::array<std::int64_t, 2>{3, 64});
  ASSERT_TRUE(activation);
  const auto output = infer_single_output(Operation(MatMul{}),
                                          std::array{*activation, *weight});
  ASSERT_TRUE(output);
  EXPECT_EQ(output->data_type(), DataType::kFloat16);
  EXPECT_EQ(output->dimensions()[0], 3);
  EXPECT_EQ(output->dimensions()[1], 5);
}

TEST(ComputeOpsLowPrecision, Float8WeightTailKeepsCeilingScaleRows) {
  for (std::int64_t n : {1, 127, 128, 129, 576}) {
    const auto weight = float8_weight_description(6144, n,
        Float8ScaleMode::kFloat32Block128);
    ASSERT_TRUE(weight);
    EXPECT_EQ(*weight->required_bytes(),
              std::size_t(n * 6144 + ((n + 127) / 128) * 48 * 4));
    const auto activation = float8_activation_description(3, 6144,
        Float8ScaleMode::kFloat32Block128).value();
    const auto output = infer_single_output(Operation(MatMul{}),
                                            std::array{activation, *weight});
    ASSERT_TRUE(output);
    EXPECT_EQ(output->dimensions()[1], n);
  }
}

TEST(ComputeOpsLowPrecision, GgufCatalogPreservesExactNativeBlocks) {
  struct Case final {
    GgufQuantizedType type;
    StorageFormatId id;
    std::size_t bytes;
    std::size_t elements = 256;
  };
  constexpr std::array cases{Case{GgufQuantizedType::kQ3K, kGgufQ3K, 110},
                             Case{GgufQuantizedType::kQ4K, kGgufQ4K, 144},
                             Case{GgufQuantizedType::kQ5K, kGgufQ5K, 176},
                             Case{GgufQuantizedType::kQ6K, kGgufQ6K, 210},
                             Case{GgufQuantizedType::kIq3Xxs, kGgufIq3Xxs, 98},
                             Case{GgufQuantizedType::kIq3S, kGgufIq3S, 110},
                             Case{GgufQuantizedType::kIq4Xs, kGgufIq4Xs, 136},
                             Case{GgufQuantizedType::kQ4_0, kGgufQ4_0, 18, 32},
                             Case{GgufQuantizedType::kQ4_1, kGgufQ4_1, 20, 32},
                             Case{GgufQuantizedType::kQ2K, kGgufQ2K, 84},
                             Case{GgufQuantizedType::kIq2Xxs, kGgufIq2Xxs, 66},
                             Case{GgufQuantizedType::kIq2Xs, kGgufIq2Xs, 74},
                             Case{GgufQuantizedType::kIq2S, kGgufIq2S, 82},
                             Case{GgufQuantizedType::kIq1S, kGgufIq1S, 50},
                             Case{GgufQuantizedType::kIq1M, kGgufIq1M, 56},
                             Case{GgufQuantizedType::kIq1Xxxs, kGgufIq1Xxxs, 38},
                             Case{GgufQuantizedType::kIq1Xxs, kGgufIq1Xxs, 42},
                             Case{GgufQuantizedType::kIq1Xs, kGgufIq1Xs, 46}};
  for (const auto &[type, id, bytes, elements] : cases) {
    const auto weight =
        gguf_weight_description(type, DataType::kFloat32,
                                static_cast<std::int64_t>(elements), 3);
    ASSERT_TRUE(weight);
    EXPECT_EQ(weight->storage_format().id(), id);
    EXPECT_EQ(*weight->required_bytes(), bytes * 3);
    EXPECT_EQ(gguf_quantized_type(id), type);
    EXPECT_EQ(gguf_quantized_type(weight->storage_format()), type);
    EXPECT_EQ(weight->block_axis(), 0u);
    EXPECT_EQ(weight->storage_format().elements_per_block(), elements);
  }
  const auto q8 = gguf_weight_description(GgufQuantizedType::kQ8_0,
                                          DataType::kBFloat16, 64, 3);
  const auto iq4 = gguf_weight_description(GgufQuantizedType::kIq4Nl,
                                           DataType::kFloat16, 64, 3);
  ASSERT_TRUE(q8);
  ASSERT_TRUE(iq4);
  EXPECT_EQ(*q8->required_bytes(), 204u);
  EXPECT_EQ(*iq4->required_bytes(), 108u);
  const auto malformed = StorageFormat::blocked(kGgufQ4K, 256, 143).value();
  EXPECT_FALSE(gguf_quantized_type(malformed));
}

TEST(ComputeOpsLowPrecision, GgufGroupedWeightsKeepExpertRowAndKOrder) {
  const auto weight = gguf_grouped_weight_description(
      GgufQuantizedType::kIq4Xs, DataType::kFloat32, 4, 3, 256);
  ASSERT_TRUE(weight);
  EXPECT_TRUE(weight->is_dense());
  constexpr std::array<std::int64_t, 3> dimensions{4, 3, 256};
  EXPECT_TRUE(std::ranges::equal(weight->dimensions(), dimensions));
  EXPECT_EQ(weight->block_axis(), 2u);
  EXPECT_EQ(weight->byte_strides()[2], 136);
  EXPECT_EQ(weight->byte_strides()[1], 136);
  EXPECT_EQ(weight->byte_strides()[0], 408);
  EXPECT_EQ(*weight->required_bytes(), 1632u);
}

TEST(ComputeOpsLowPrecision, RejectsIncompleteBlocksAndOverflow) {
  const auto block = Float8ScaleMode::kFloat32Block128;
  const auto group = Float8ScaleMode::kUnsignedExponent8Group32;
  EXPECT_FALSE(float8_activation_description(0, 128, block));
  EXPECT_FALSE(float8_activation_description(-1, 128, block));
  EXPECT_FALSE(float8_activation_description(1, 129, block));
  EXPECT_FALSE(float8_weight_description(128, 0, block));
  EXPECT_FALSE(float8_weight_description(33, 1, group));
  EXPECT_FALSE(
      float8_weight_description(32, 1, static_cast<Float8ScaleMode>(255)));
  EXPECT_FALSE(mxfp4_weight_description(31, 1));
  EXPECT_FALSE(mxfp4_weight_description(32, 0));
  EXPECT_FALSE(gguf_weight_description(GgufQuantizedType::kQ4K, DataType::kInt8,
                                       256, 1));
  EXPECT_FALSE(gguf_weight_description(GgufQuantizedType::kQ4K,
                                       DataType::kFloat32, 255, 1));
  EXPECT_FALSE(gguf_grouped_weight_description(GgufQuantizedType::kQ8_0,
                                               DataType::kFloat32, 0, 1, 32));
  constexpr auto maximum = (std::numeric_limits<std::int64_t>::max)();
  EXPECT_FALSE(float8_activation_description(maximum, 128, block));
  EXPECT_FALSE(float8_weight_description(maximum - 31, 128, group));
  EXPECT_FALSE(mxfp4_weight_description(maximum - 31, maximum));
}
} // namespace
