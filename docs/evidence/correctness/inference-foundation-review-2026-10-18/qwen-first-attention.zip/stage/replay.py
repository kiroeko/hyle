"""Independent same-input Torch analysis; never supplies data to Hyle.

CUDA work requires the parent's successful original-results guard. Exit 0
means the analysis completed, not that a numerical budget has been accepted.
"""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import struct
import time
import types

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                  HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false")

ROOT = Path(__file__).resolve().parents[3]
REFERENCE_RECEIPT = ROOT / ".scratch/inference-execution-refactor-2026-10-18/qwen35-text/reference/reference.json"
EXPECTED = {
    "pre_q": ("BF16", [1, 23, 8, 256]),
    "pre_k": ("BF16", [1, 23, 2, 256]),
    "post_q": ("BF16", [1, 23, 8, 256]),
    "post_k": ("BF16", [1, 23, 2, 256]),
    "value": ("BF16", [1, 23, 2, 256]),
    "attention": ("BF16", [23, 8, 256]),
    "positions": ("I32", [23]),
    "frequencies": ("F32", [32]),
}


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def checked_inputs(manifest_path: Path, guard_path: Path):
    guard = read_json(guard_path)
    if guard.get("passed") is not True:
        raise ValueError("Parent original-results guard has not passed; no CUDA work permitted")
    manifest = read_json(manifest_path)
    if "manifest_sha256" in guard and guard["manifest_sha256"] != identity(manifest_path)["sha256"]:
        raise ValueError("Guard names a different probe manifest")
    if manifest.get("T") != 23 or manifest.get("scale") != 0.0625 or manifest.get("causal") is not True:
        raise ValueError("Probe must retain T23, scale1/16 and causal=true")
    rows = manifest["files"]
    names = [row["name"] for row in rows]
    if len(names) != len(set(names)) or set(names) != set(EXPECTED):
        raise ValueError("Probe manifest must name each of the eight actual inputs/outputs exactly once")
    payloads = {}; authenticated = []
    for row in rows:
        name = row["name"]; dtype, shape = EXPECTED[name]
        if row["dtype"] != dtype or row["shape"] != shape:
            raise ValueError(f"Actual description differs for {name}: {row}")
        path = Path(row["path"])
        if not path.is_absolute():
            path = manifest_path.parent / path
        path = path.resolve()
        expected_bytes = math.prod(shape) * (2 if dtype == "BF16" else 4)
        actual = identity(path)
        if row["bytes"] != expected_bytes or actual["bytes"] != expected_bytes or actual["sha256"] != row["sha256"]:
            raise ValueError(f"Input bytes/SHA mismatch: {name}")
        payloads[name] = path.read_bytes()
        authenticated.append({"name": name, "dtype": dtype, "shape": shape, **actual})
    positions = struct.unpack("<23i", payloads["positions"])
    if positions != tuple(range(23)):
        raise ValueError("This first-prefill probe must retain positions0..22")
    frequencies = struct.unpack("<32f", payloads["frequencies"])
    if not all(math.isfinite(x) and x > 0 for x in frequencies):
        raise ValueError("Frequency payload is not finite positive original F32")
    return manifest, guard, payloads, authenticated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--guard", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    manifest_path = args.manifest.resolve(); guard_path = args.guard.resolve()
    if args.output.exists():
        raise ValueError("Analysis output must be new; do not overwrite a prior result")
    manifest, guard, payloads, authenticated = checked_inputs(manifest_path, guard_path)
    receipt = read_json(REFERENCE_RECEIPT)
    official_path = Path(receipt["model_source"])
    if identity(official_path)["sha256"] != receipt["model_source_sha256"]:
        raise ValueError("Installed official Qwen source differs from the authenticated original reference")
    reference_script = ROOT / "tools/qwen35_text/reference.py"
    if identity(reference_script)["sha256"] != receipt["reference_sha256"]:
        raise ValueError("Current reference.py differs from the authenticated reference")

    # No CUDA API or tensor operation occurs before every guard and payload
    # identity above is checked. Import only model functions, no model/weights.
    import numpy as np
    import torch
    from transformers.models.qwen3_5 import modeling_qwen3_5 as official
    if Path(official.__file__).resolve() != official_path.resolve():
        raise ValueError("Imported official module is not the authenticated file")
    torch.set_num_threads(2); torch.set_num_interop_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
    torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
    torch.backends.cudnn.allow_tf32 = False
    device = torch.device("cuda:0")
    arrays = {}
    for name, (dtype, shape) in EXPECTED.items():
        storage_type = {"BF16": torch.bfloat16, "F32": torch.float32, "I32": torch.int32}[dtype]
        arrays[name] = torch.frombuffer(bytearray(payloads[name]), dtype=storage_type).reshape(shape).to(device)
    if not all(bool(torch.isfinite(t).all()) for t in arrays.values()):
        raise ValueError("Actual probe contains nonfinite values")

    args.output.mkdir(parents=True)
    functions = {name: inspect.getsource(getattr(official, name))
                 for name in ["apply_rotary_pos_emb", "eager_attention_forward"]}
    (args.output / "official-functions.py").write_text(
        "# Exact source excerpts for attribution; not the executed replay module.\n\n" +
        "\n\n".join(functions.values()), encoding="utf-8")
    sources = {
        "script": identity(Path(__file__).resolve()),
        "official_module": identity(official_path),
        "reference_script": identity(reference_script),
        "reference_receipt": identity(REFERENCE_RECEIPT),
        "native_rope": identity(ROOT / "src/compute_ggml_runtime/explicit_rope.h"),
        "native_ragged": identity(ROOT / "src/compute_provider_flashinfer/native_batch.cu"),
        "canonical_consumer_template": identity(ROOT / "tools/qwen35_text/main.cc"),
        "candidate_scratch_consumer": identity(Path(__file__).resolve().parent / "consumer.cc"),
        "official_functions": {name: {"sha256": hashlib.sha256(text.encode()).hexdigest(),
                                       "lines": inspect.getsourcelines(getattr(official, name))[1]}
                               for name, text in functions.items()},
    }
    write_json(args.output / "source-refs.json", sources)

    def bf16_bytes(tensor):
        return tensor.detach().to(torch.bfloat16).contiguous().cpu().view(torch.uint16).numpy()

    def statistics(actual, expected):
        if list(actual.shape) != list(expected.shape):
            raise ValueError("Comparison shapes differ")
        a = actual.detach().double().cpu().numpy()
        e = expected.detach().double().cpu().numpy()
        aw = bf16_bytes(actual); ew = bf16_bytes(expected)
        mismatch = aw != ew
        finite = np.isfinite(a) & np.isfinite(e)
        # Monotonic representation distance; -0 and +0 are adjacent codes.
        def ordered(words):
            w = words.astype(np.int32)
            return np.where((w & 0x8000) != 0, (~w) & 0xffff, w | 0x8000)
        distances = np.abs(ordered(aw) - ordered(ew))[finite]
        delta = a[finite] - e[finite]
        den = float(np.linalg.norm(e[finite]))
        first = []
        for flat in np.flatnonzero(mismatch.reshape(-1))[:16]:
            coord = tuple(int(x) for x in np.unravel_index(int(flat), a.shape))
            first.append({"coordinate": list(coord), "actual": float(a[coord]) if np.isfinite(a[coord]) else None,
                          "reference": float(e[coord]) if np.isfinite(e[coord]) else None,
                          "actual_bf16": f"0x{int(aw[coord]):04x}", "reference_bf16": f"0x{int(ew[coord]):04x}",
                          "bf16_ulp": int(abs(ordered(aw)[coord] - ordered(ew)[coord]))})
        return {
            "shape": list(a.shape), "elements": int(a.size),
            "actual_dtype": str(actual.dtype), "reference_dtype": str(expected.dtype),
            "bf16_bit_mismatches": int(np.count_nonzero(mismatch)),
            "numeric_mismatches": int(np.count_nonzero(a != e)),
            "actual_nonfinite": int(np.count_nonzero(~np.isfinite(a))),
            "reference_nonfinite": int(np.count_nonzero(~np.isfinite(e))),
            "max_abs": float(np.max(np.abs(delta))) if delta.size else None,
            "relative_l2": float(np.linalg.norm(delta) / den) if den else float(np.linalg.norm(delta)),
            "bf16_ulp": {"maximum": int(np.max(distances)) if distances.size else None,
                         "mean": float(np.mean(distances)) if distances.size else None,
                         "p50_p95_p99": np.percentile(distances, [50, 95, 99]).tolist() if distances.size else [],
                         "definition": "absolute monotonic BF16 code distance after Torch BF16 storage conversion; signed zeros adjacent; maxAbs/relL2 retain the unrounded reference dtype"},
            "first_coordinates": first,
            "actual_bf16_sha256": hashlib.sha256(aw.tobytes()).hexdigest(),
            "reference_bf16_sha256": hashlib.sha256(ew.tobytes()).hexdigest(),
        }

    def budget_relation(actual, expected):
        # These are existing fixture thresholds, not newly inferred budgets.
        # They are reported for context only: this real model payload differs.
        a = actual.detach().double().cpu().numpy(); e = expected.detach().double().cpu().numpy()
        difference = np.abs(a - e)
        return {
            "former_full_qwen_budget": None,
            "former_full_qwen_contract": "Measurements only; no agreed whole-model numerical tolerance.",
            "existing_primitive_fi_bf16_absolute_0_01": {
                "source": "tests/compute_provider_flashinfer/flashinfer_provider_test.cc:93",
                "elements_exceeding": int(np.count_nonzero(difference > .01))},
            "existing_constant_query_ragged_bf16_absolute_0_008": {
                "source": "tests/compute_batch/native_ragged_layout_test.h:218",
                "elements_exceeding": int(np.count_nonzero(difference > .008))},
            "interpretation": "Context only. Neither old fixture threshold is a new Qwen acceptance decision or a changed budget.",
        }

    def rotate_floating(q, k, phase):
        cosine = phase.cos()[None, :, None, :]
        sine = phase.sin()[None, :, None, :]
        def apply(x):
            x = x.to(phase.dtype)
            first, second = x[..., :32], x[..., 32:64]
            rotated = torch.cat((first * cosine - second * sine,
                                 first * sine + second * cosine), dim=-1)
            return torch.cat((rotated, x[..., 64:]), dim=-1)
        return apply(q), apply(k)

    def attention_floating(q, k, v, dtype, round_probabilities=False):
        # q/k/v are BHSD here. Repeat only the real KV heads; explicit
        # bottom-right causal bounds match ordinary ragged semantics.
        q = q.to(dtype); k = k.to(dtype).repeat_interleave(4, dim=1)
        v = v.to(dtype).repeat_interleave(4, dim=1)
        scores = (q @ k.transpose(-1, -2)) * .0625
        query_length, kv_length = q.shape[-2], k.shape[-2]
        allowed = torch.arange(kv_length, device=device)[None, :] <= (
            kv_length - query_length + torch.arange(query_length, device=device)[:, None])
        probabilities = torch.softmax(scores.masked_fill(~allowed, -torch.inf), dim=-1)
        if round_probabilities:
            # Isolate the score boundary from native tensor-core P storage;
            # this control is not claimed as FlashInfer's exact algorithm.
            probabilities = probabilities.to(torch.bfloat16)
            v = v.to(torch.bfloat16)
        return (probabilities @ v).transpose(1, 2).contiguous().squeeze(0)

    torch.cuda.synchronize(); start = time.perf_counter()
    with torch.inference_mode():
        q = arrays["pre_q"]; k = arrays["pre_k"]
        phase32 = arrays["positions"].float()[:, None] * arrays["frequencies"][None, :]
        # This is the official function with the actual supplied frequencies,
        # not frequencies recomputed from a checkpoint or inferred from data.
        cosine = torch.cat((phase32.cos(), phase32.cos()), dim=-1)[None].to(torch.bfloat16)
        sine = torch.cat((phase32.sin(), phase32.sin()), dim=-1)[None].to(torch.bfloat16)
        oq, ok = official.apply_rotary_pos_emb(q.transpose(1, 2), k.transpose(1, 2), cosine, sine)
        rotations = {"official_bf16": (oq.transpose(1, 2), ok.transpose(1, 2)),
                     "f32_phase_rotation": rotate_floating(q, k, phase32),
                     "fp64_rotation_same_f32_phase": rotate_floating(q, k, phase32.double()),
                     "fp64_phase_rotation": rotate_floating(q, k,
                         arrays["positions"].double()[:, None] * arrays["frequencies"].double()[None, :])}
        rotation_results = {
            name: {"query": statistics(arrays["post_q"], rq), "key": statistics(arrays["post_k"], rk)}
            for name, (rq, rk) in rotations.items()}
        tail_results = {
            "channel_offset": 64, "expected_bitwise_identity": True,
            "query": statistics(arrays["post_q"][..., 64:], arrays["pre_q"][..., 64:]),
            "key": statistics(arrays["post_k"][..., 64:], arrays["pre_k"][..., 64:]),
        }

        # All attention branches consume the candidate's actual post-RoPE
        # payloads. No branch feeds any computed reference tensor to Hyle.
        q = arrays["post_q"].transpose(1, 2)
        k = arrays["post_k"].transpose(1, 2)
        v = arrays["value"].transpose(1, 2)
        allowed = torch.arange(23, device=device)[None, :] <= torch.arange(23, device=device)[:, None]
        mask = torch.zeros((1, 1, 23, 23), dtype=torch.bfloat16, device=device)
        mask.masked_fill_(~allowed, torch.finfo(torch.bfloat16).min)
        module = types.SimpleNamespace(num_key_value_groups=4, training=False)
        eager, _ = official.eager_attention_forward(module, q, k, v, mask, scaling=.0625, dropout=0.)
        controls = {"official_eager_bf16": eager.squeeze(0),
                    "f32_score_softmax_bf16_probability_pv": attention_floating(q, k, v, torch.float32, True),
                    "f32_score_softmax_pv": attention_floating(q, k, v, torch.float32),
                    "fp64_score_softmax_pv": attention_floating(q, k, v, torch.float64)}
        attention_results = {name: {"comparison": statistics(arrays["attention"], expected),
                                   "original_budget_context": budget_relation(arrays["attention"], expected)}
                             for name, expected in controls.items()}
        control_pairs = {
            "eager_vs_f32_scores_with_bf16_probability": statistics(
                controls["official_eager_bf16"], controls["f32_score_softmax_bf16_probability_pv"]),
            "eager_vs_full_f32": statistics(controls["official_eager_bf16"], controls["f32_score_softmax_pv"]),
            "full_f32_vs_fp64": statistics(controls["f32_score_softmax_pv"], controls["fp64_score_softmax_pv"]),
        }
    torch.cuda.synchronize()
    result = {
        "kind": "actual_candidate_inputs_independent_torch_replay_not_model_acceptance",
        "elapsed_seconds": time.perf_counter() - start,
        "manifest": identity(manifest_path), "guard": {"identity": identity(guard_path), "result": guard},
        "authenticated_payloads": authenticated, "source_refs": sources,
        "runtime": {"torch": torch.__version__, "cuda": torch.version.cuda,
                    "gpu": torch.cuda.get_device_name(device), "tf32": False,
                    "bf16_reduced_precision_reduction": False, "fp16_reduced_precision_reduction": False,
                    "cudnn_tf32": False, "autocast": False},
        "geometry": {"T": 23, "query_heads": 8, "kv_heads": 2, "depth": 256,
                     "rotary_dimensions": 64, "scale": .0625, "causal": True,
                     "mask": "explicit bottom-right; first-prefill Q=KV=23"},
        "rotation": rotation_results, "rope_nonrotated_tail": tail_results, "attention": attention_results,
        "attention_control_pairs": control_pairs,
        "limits": ["No candidate execution, model/weight loading or output/state replacement.",
                   "F32/FP64 controls are independent arithmetic formulas, not claims of native instruction-order equivalence.",
                   "Ordered BF16 ULP distances include signed-zero representation differences; nonfinite counts are separate.",
                   "Original-public-results guard is supplied by the parent; this script cannot authenticate an unrecorded execution.",
                   "Numerical mismatch is reported without deriving/changing tolerances or declaring whole-model acceptance."],
    }
    write_json(args.output / "replay.json", result)
    print(json.dumps({"result": identity(args.output / "replay.json"), "numerical_acceptance": "not_decided"}, indent=2))


if __name__ == "__main__":
    main()
