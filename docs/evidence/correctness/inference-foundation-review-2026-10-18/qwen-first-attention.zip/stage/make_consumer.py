from pathlib import Path
import difflib,hashlib,json
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
source=ROOT/'tools/qwen35_text/main.cc';before=source.read_bytes();s=before.decode()
def replace(old,new):
 global s
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
replace('constexpr std::array<const char *, 9> layer0_probe_names{\n    "01-gdn-output", "02-out-proj-input", "03-out-proj-output",\n    "04-down-proj-input", "05-layer-output", "06-post-attn-residual",\n    "07-post-attn-norm", "08-gate-proj-output", "09-up-proj-output"};',
 'constexpr std::array<const char *, 5> layer0_probe_names{\n    "pre_q", "pre_k", "post_q", "post_k", "attention"};')
for kind,name in [('V','probe_ports'),('Tensor','probe_outputs'),('bool','probe_caller')]:
 replace('std::array<'+kind+', 9> '+name,'std::array<'+kind+', 5> '+name)
replace('        if (i == 0) phase.probe_ports[0] = y;\n','')
replace('        if (i == 0) phase.probe_ports[1] = y; // Same BF16 payload before its metadata-only out_proj reshape.\n','')
replace('        if (i == 0) phase.probe_ports[2] = mixed;\n','')
replace('      x = r.ffn(r.binary(c::BinaryKind::kAdd, x, mixed), prefix,\n                i == 0 ? std::span<V>(phase.probe_ports) : std::span<V>{});\n      if (i == 0) phase.probe_ports[4] = x;',
 '      x = r.ffn(r.binary(c::BinaryKind::kAdd, x, mixed), prefix);')
replace('        q = r.one(rope, {q, phase.position_port, frequencies});\n        k = r.one(rope, {k, phase.position_port, frequencies});',
 '        if (i == 3) { phase.probe_ports[0] = q; phase.probe_ports[1] = k; }\n        q = r.one(rope, {q, phase.position_port, frequencies});\n        k = r.one(rope, {k, phase.position_port, frequencies});\n        if (i == 3) { phase.probe_ports[2] = q; phase.probe_ports[3] = k; }')
replace('        auto gated = r.binary(c::BinaryKind::kMultiply, r.reshape(attention, {t, hidden}),',
 '        if (i == 3) phase.probe_ports[4] = attention;\n        auto gated = r.binary(c::BinaryKind::kMultiply, r.reshape(attention, {t, hidden}),')
replace('    const auto frequencies = r.constant(r.literals.back());',
 '    const auto frequencies = r.constant(r.literals.back());\n    if (diagnostic) {\n      std::filesystem::create_directories(layer0_probe);\n      r.literals.back().dump(layer0_probe / "frequencies.f32");\n    }')
replace('    phase.tokens.write<std::int32_t>(ids); phase.positions.write<std::int32_t>(positions);',
 '    phase.tokens.write<std::int32_t>(ids); phase.positions.write<std::int32_t>(positions);\n    if (!layer0_probe.empty()) phase.positions.dump(layer0_probe / "positions.i32");')
s=s.replace('layer0_probe','first_attention_probe').replace('layer0 diagnostic','first-attention diagnostic').replace('--layer0-probe','--first-attention-probe').replace('layer0 route diagnostics','first-attention route diagnostics')
assert len(s.splitlines())<len(before.decode().splitlines())+20
assert source.read_bytes()==before
(OUT/'consumer.cc').write_text(s,encoding='utf-8',newline='\n')
(OUT/'consumer.before.cc').write_bytes(before)
(OUT/'consumer.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile='current-tool-consumer',tofile='scratch-attention-probe')),encoding='utf-8')
(OUT/'consumer-origin.json').write_text(json.dumps(dict(source=str(source),bytes=len(before),sha256=hashlib.sha256(before).hexdigest(),purpose='Same full 24-layer math; compile default and publish-only layer3 probe; execute one diagnostic prefill. No precision override or oracle input.'),indent=2)+'\n')
print('Created scratch consumer; product source unchanged.')
