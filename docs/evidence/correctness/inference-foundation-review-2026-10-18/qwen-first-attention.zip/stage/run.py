from pathlib import Path
import hashlib,json,os,subprocess,sys,time
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,j):(OUT/n).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
base=read(ARCH/'cuda-admitted-ggml-stream-implementation/qwen-link.json')
template=read(ARCH/'strided-reshape/consumer-identity.json')['command']
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':template[0],'CMAKE_C_COMPILER':template[0]})
env['VSLANG']='1033';env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in base['command'] if Path(v).suffix.lower()=='.lib' and Path(v).is_absolute()))+os.pathsep+env['PATH']
def run(tag,cmd,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else [];stem=f'{len(rows)+1:03d}-{tag}'
 r=dict(tag=tag,command=list(map(str,cmd)),cwd=str(OUT),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log');rows.append(r);save('commands.json',rows)
 print('START',stem,flush=True);t=time.monotonic()
 with (OUT/r['stdout']).open('wb') as so,(OUT/r['stderr']).open('wb') as se:
  child=subprocess.Popen(r['command'],cwd=OUT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW);r['pid']=child.pid;save('commands.json',rows);r['exit']=child.wait(timeout=timeout)
 r['seconds']=time.monotonic()-t;save('commands.json',rows);print('END',stem,r['exit'],flush=True)
 print((OUT/r['stdout']).read_text(errors='replace')[-4000:],flush=True);print((OUT/r['stderr']).read_text(errors='replace')[-2500:],flush=True)
 if r['exit']:raise SystemExit(r['exit'])
def build():
 assert not (OUT/'consumer-identity.json').exists()
 args=[v for v in template if not v.lower().startswith(('/fo','/fd')) and not v.lower().endswith('.cc')]
 args += [str(OUT/'consumer.cc'),'/Fo'+str(OUT/'consumer.obj')]
 src=ident(OUT/'consumer.cc');run('consumer-compile',args);assert src==ident(OUT/'consumer.cc')
 save('consumer-identity.json',dict(source=src,object=ident(OUT/'consumer.obj'),command=args))
 for row in base['inputs']:assert ident(row['path'])==row,('link-input drift',row['path'])
 old=read(ARCH/'strided-reshape/consumer-identity.json')['object']['path']
 args=[str(OUT/'consumer.obj') if v==old else v for v in base['command'] if not v.lower().startswith(('/out:','/map:','/implib:','/pdb:'))]
 assert args.count(str(OUT/'consumer.obj'))==1
 args += ['/OUT:'+str(OUT/'consumer.exe'),'/MAP:'+str(OUT/'consumer.map'),'/IMPLIB:'+str(OUT/'consumer.lib')]
 save('link-plan.json',dict(command=args,origin=str(ARCH/'cuda-admitted-ggml-stream-implementation/qwen-link.json'),inputs=[ident(v) for v in args if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}]))
 run('consumer-link',args)
def execute():
 assert not (OUT/'trace').exists() and not (OUT/'probe').exists()
 inp=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
 save('inputs.json',[ident(inp/n) for n in ['input.json','weights.tsv','prompt.ids']])
 run('first-attention',[OUT/'consumer.exe','--inputs',inp,'--steps','1','--capacity','32','--trace',OUT/'trace','--first-attention-probe',OUT/'probe','--progress','direct'])
if __name__=='__main__':
 {'build':build,'run':execute}[sys.argv[1]]()
