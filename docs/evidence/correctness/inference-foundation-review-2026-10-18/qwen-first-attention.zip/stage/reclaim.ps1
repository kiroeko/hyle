param([switch]$ReclaimQwenFirstAttention)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/qwen-first-attention'))
$receipt = Get-Content -Raw -LiteralPath (Join-Path $stage 'archive-receipt.json') | ConvertFrom-Json
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $cursor = $item
    while ($null -ne $cursor -and $cursor.FullName.Length -ge $workspace.Length) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Identity changed: $path" }
}
Assert-Identity $receipt.archive
$traceRoot = [IO.Path]::GetFullPath((Join-Path $stage 'trace/prefill'))
foreach ($entry in $plan.files) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($stage + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside exact stage: $path" }
    $extension = [IO.Path]::GetExtension($path)
    $image = ([IO.Path]::GetDirectoryName($path) -eq $stage) -and ($extension -in '.exe','.map','.exp','.lib')
    $duplicate = ([IO.Path]::GetDirectoryName($path) -eq $traceRoot) -and ($extension -in '.bf16','.f32')
    if (-not $image -and -not $duplicate) { throw "Unexpected cleanup target: $path" }
    Assert-Identity $entry
}
$retained = @($plan.retained_objects) + @($plan.retained_original_trace) + @($plan.retained_unique_probe)
foreach ($entry in $retained) { Assert-Identity $entry }
if (-not $ReclaimQwenFirstAttention) { Write-Output "Verified $($plan.files.Count) archived exact files. Use -ReclaimQwenFirstAttention to reclaim them."; return }
foreach ($entry in $plan.files) { Remove-Item -LiteralPath $entry.path -Force }
foreach ($entry in $retained) { Assert-Identity $entry }
$result = [ordered]@{
    archive_verified=$true
    files=$plan.files.Count
    bytes=($plan.files | Measure-Object bytes -Sum).Sum
    retained_objects=$plan.retained_objects.Count
    retained_original_trace=$plan.retained_original_trace.Count
    retained_unique_probe=$plan.retained_unique_probe.Count
    other_cache_retained=$true
}
$result | ConvertTo-Json | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $stage 'cleanup-result.json')
$result | ConvertTo-Json
