"""Archive this discriminant and prepare exact-file cleanup, without deleting."""
from pathlib import Path
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def ident(p):
    b = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


assert (OUT / 'native-attention-precision-review.json').is_file()
guard = read(OUT / 'guard.json')
replay = read(OUT / 'analysis/replay.json')
online = read(OUT / 'analysis-online.json')
commands = read(OUT / 'commands.json')
assert guard['passed'] and len(commands) == 6 and all(c['exit'] == 0 for c in commands)
assert ident(OUT / 'replay.py') == replay['source_refs']['script']
assert ident(OUT / 'replay_online.py') == online['script']
assert ident(ROOT / 'tools/qwen35_text/main.cc') == replay['source_refs']['canonical_consumer_template']
pairs = read(OUT / 'trace-pairs.json')
for pair in pairs:
    for key in ['original', 'candidate']:
        assert ident(Path(pair[key]['path'])) == pair[key]
    assert pair['original']['sha256'] == pair['candidate']['sha256']

summary = dict(
    status='same-input-first-full-attention-discriminant-completed-not-model-acceptance',
    product_math_changed=False,
    original_results=dict(count=50, bytes=guard['bytes'], byte_identical=50),
    graph=dict(nodes=1878, selected_steps=1204, route_byte_identical=True,
               default_workspace_per_slot=4151296, published_workspace_per_slot=4292608,
               performance_measurement=False),
    rope=dict(f32_final_bf16_mismatch={n: replay['rotation']['f32_phase_rotation'][n]['bf16_bit_mismatches'] for n in ['query', 'key']},
              fp64_final_bf16_mismatch={n: replay['rotation']['fp64_phase_rotation'][n]['bf16_bit_mismatches'] for n in ['query', 'key']},
              official_eager_bf16_mismatch={n: replay['rotation']['official_bf16'][n]['bf16_bit_mismatches'] for n in ['query', 'key']}),
    attention=dict(
        native_vs_unrounded_fp64=replay['attention']['fp64_score_softmax_pv']['comparison'],
        native_vs_eager_bf16=replay['attention']['official_eager_bf16']['comparison'],
        independent_online_control=online['controls']['float32_scaled_terms'],
        online_partition=[16, 7],
        conclusion='Storage precision and native online evaluation explain the main first-attention boundary differences; remaining native instruction-order residuals and whole-model accuracy remain unaccepted.'),
    build=dict(fresh_cpp_translation_units=1, native_translation_units=0, full_model_prefill_runs=1,
               independent_torch_replays=1, independent_cpu_replays=2, rebuilt_sdk=False),
    limits=[
        'Only layer3 first full-attention prefill T23, not all six full-attention layers or continuation/decode.',
        'The diagnostic retained additional outputs, so its workspace/timing are not performance comparisons.',
        'CPU online controls are not native SFU/MMA/reciprocal instruction simulators; 51/47104 BF16 values still differ in the stated F32 control.',
        'No changed numerical tolerance, provider pinning, precision policy, acceptance criterion or candidate oracle input.',
        'Prior whole-model logits relative L2 ~2.151%/1.957%/2.459%, independent acceptance and fair sustained throughput remain unfinished.',
    ],
    files={name: ident(OUT / name) for name in [
        'guard.json', 'probe-manifest.json', 'analysis/replay.json', 'analysis-unnormalized.json',
        'analysis-online.json', 'precision-contract-review.json', 'native-attention-precision-review.json']})
save(OUT / 'summary.json', summary)

# Keep the original test.ps1 as a source record before replacing its entry point.
(OUT / 'previous-test.ps1').write_bytes((ROOT / 'test.ps1').read_bytes())
images = [p for p in OUT.iterdir() if p.suffix in {'.exe', '.map', '.lib', '.exp'}]
duplicates = [Path(pair['candidate']['path']) for pair in pairs]
plan = dict(files=[ident(p) for p in images + duplicates],
            retained_objects=[ident(OUT / 'consumer.obj')],
            retained_original_trace=[pair['original'] for pair in pairs],
            retained_unique_probe=[ident(p) for p in (OUT / 'probe').rglob('*') if p.is_file() and p.suffix in {'.bf16', '.i32', '.f32'}] + [ident(OUT / 'value.active.bf16')])
save(OUT / 'cleanup-plan.json', plan)

archive = DEST / 'qwen-first-attention.zip'
assert not archive.exists()
excluded = {p.resolve() for p in images + duplicates} | {(OUT / 'consumer.obj').resolve()}
files = [p for p in OUT.rglob('*') if p.is_file() and p.resolve() not in excluded
         and '__pycache__' not in p.parts and p.name not in {'archive-receipt.json', 'cleanup-result.json'}]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files):
        z.write(p, 'stage/' + p.relative_to(OUT).as_posix())
    for rel in ['docs/architecture/compute-design.md', 'docs/developer/current-work.md']:
        z.write(ROOT / rel, 'documents/' + rel)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in files:
        assert hashlib.sha256(z.read('stage/' + p.relative_to(OUT).as_posix())).hexdigest() == ident(p)['sha256']
    entries = len(z.namelist())
receipt = dict(archive=ident(archive), entries=entries,
               cleanup_files=len(plan['files']), cleanup_bytes=sum(r['bytes'] for r in plan['files']),
               unique_probe_retained=True, original_trace_retained=True, compiled_consumer_object_retained=True)
save(OUT / 'archive-receipt.json', receipt)
save(DEST / 'qwen-first-attention-results.json', dict(**summary, archive=receipt['archive']))
print(json.dumps(receipt, indent=2))
