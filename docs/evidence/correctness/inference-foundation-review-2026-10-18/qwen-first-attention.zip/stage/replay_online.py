"""Independent CPU control for the native prefill's 16+7 online partition.

Not an instruction-order simulator or a new numerical acceptance budget.
"""
from pathlib import Path
import hashlib
import json
import time
import numpy as np
from replay import checked_inputs, identity

OUT = Path(__file__).resolve().parent
target = OUT / 'analysis-online.json'
if target.exists():
    raise ValueError('Do not overwrite an existing analysis')
manifest, guard, payloads, authenticated = checked_inputs(
    OUT / 'probe-manifest.json', OUT / 'guard.json')
start = time.perf_counter()


def as_bf16(words):
    return (np.asarray(words, dtype=np.uint32) << 16).view(np.float32)


def words_rne(value):
    bits = np.asarray(value, dtype=np.float32).copy().view(np.uint32)
    return ((bits + np.uint32(0x7fff) + ((bits >> 16) & 1)) >> 16).astype(np.uint16)


def rounded(value):
    return as_bf16(words_rne(value))


def tensor(name):
    row = next(r for r in manifest['files'] if r['name'] == name)
    return as_bf16(np.frombuffer(payloads[name], dtype='<u2')).reshape(row['shape'])


def compare(actual, reference):
    a = actual.astype(np.float64)
    e = reference.astype(np.float64)
    delta = a - e
    aw = words_rne(actual)
    ew = words_rne(reference)
    positions = np.argwhere(aw != ew)
    return dict(elements=a.size, max_abs=float(np.abs(delta).max()),
                relative_l2=float(np.linalg.norm(delta) / np.linalg.norm(e)),
                bf16_projection_mismatches=int(np.count_nonzero(aw != ew)),
                first_mismatches=[dict(coordinate=p.tolist(), actual=float(a[tuple(p)]),
                                       reference=float(e[tuple(p)])) for p in positions[:16]],
                actual_nonfinite=int(np.count_nonzero(~np.isfinite(a))),
                reference_nonfinite=int(np.count_nonzero(~np.isfinite(e))),
                actual_bf16_sha256=hashlib.sha256(aw.tobytes()).hexdigest(),
                reference_bf16_sha256=hashlib.sha256(ew.tobytes()).hexdigest())


q = tensor('post_q').transpose(0, 2, 1, 3)
k = np.repeat(tensor('post_k').transpose(0, 2, 1, 3), 4, axis=1)
v = np.repeat(tensor('value').transpose(0, 2, 1, 3), 4, axis=1)
actual = tensor('attention')
results = {}
score_range = []
for score_type in [np.float32, np.float64]:
    for exponent_form in ['scaled_terms', 'scaled_difference', 'fused_scaled_terms']:
        scale_log2 = score_type(.0625) * score_type(1.4426950408889634)
        def exponential(score, maximum):
            if exponent_form == 'scaled_terms':
                exponent = score * scale_log2 - maximum * scale_log2
            elif exponent_form == 'scaled_difference':
                exponent = (score - maximum) * scale_log2
            else:
                # A separately labeled F32 single-rounding control. This does
                # not assert that every native path emits this exact FMA tree.
                base = (maximum * scale_log2).astype(score_type)
                exponent = (score.astype(np.float64) * float(scale_log2) -
                            base.astype(np.float64)).astype(score_type)
            return np.exp2(exponent)
        maximum = np.full((1, 8, 23, 1), -50000., dtype=score_type)
        denominator = np.ones_like(maximum)
        numerator = np.zeros((1, 8, 23, 256), dtype=score_type)
        for begin in [0, 16]:
            end = min(begin + 16, 23)
            score = q.astype(score_type) @ k[..., begin:end, :].astype(score_type).swapaxes(-1, -2)
            allowed = np.arange(begin, end)[None, :] <= np.arange(23)[:, None]
            active = score[..., allowed]
            score_range.append(dict(dtype=str(np.dtype(score_type)), begin=begin, end=end,
                                    minimum=float(active.min()), maximum=float(active.max())))
            score = np.where(allowed, score, score_type(-50000.))
            next_maximum = np.maximum(maximum, score.max(axis=-1, keepdims=True))
            rescale = exponential(maximum, next_maximum)
            denominator *= rescale
            numerator *= rescale
            weights = rounded(exponential(score, next_maximum)).astype(score_type)
            denominator += weights.sum(axis=-1, keepdims=True)
            numerator += weights @ v[..., begin:end, :].astype(score_type)
            maximum = next_maximum
        output = (numerator / denominator).transpose(0, 2, 1, 3)[0]
        results[f'{np.dtype(score_type).name}_{exponent_form}'] = {
            'unrounded_output': compare(actual, output),
            'final_bf16_output': compare(actual, rounded(output)),
        }

review = OUT / 'native-attention-precision-review.json'
result = dict(
    kind='independent_cpu_online_precision_controls_not_native_simulation_or_model_acceptance',
    elapsed_seconds=time.perf_counter() - start,
    script=identity(Path(__file__).resolve()),
    manifest=identity(OUT / 'probe-manifest.json'), guard=identity(OUT / 'guard.json'),
    authenticated_payloads=authenticated,
    native_review=identity(review) if review.is_file() else 'separately recorded source review pending',
    runtime=dict(numpy=np.__version__, processor='CPU', candidate_execution=False),
    partition=dict(kv_tile=16, iterations=[16, 7], split_kv=False,
                   precision='BF16 unnormalized weights, F32 running state on F32 controls'),
    active_score_ranges=score_range, controls=results,
    limits=[
        'Fixed partition derives from actual native source/SM89 resource selection, not fitted output data.',
        'NumPy dot/exp2/reduction/divide do not simulate CUDA MMA/SFU/approximate reciprocal.',
        'F64 changes arithmetic only, retaining the explicit BF16 per-tile weight boundary.',
        'Causal rows always have a real key; actual active score ranges reported against native -50000 sentinel.',
        'No changed tolerance, product math, GPU execution or full-model acceptance.',
    ])
target.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps({'result': identity(target), 'summary': {
    k: {t: {m: v[m] for m in ['max_abs', 'relative_l2', 'bf16_projection_mismatches']}
        for t, v in r.items()} for k, r in results.items()}}, indent=2))
