from pathlib import Path
import csv,json,struct,math
from run import OUT,ROOT,ARCH,read,save,ident

original=ARCH/'qwen-progress-journey/trace-direct/prefill';candidate=OUT/'trace/prefill'
a={p.name:p for p in original.iterdir() if p.suffix in {'.bf16','.f32'}}
b={p.name:p for p in candidate.iterdir() if p.suffix in {'.bf16','.f32'}}
assert len(a)==50 and a.keys()==b.keys()
pairs=[]
for name in sorted(a):
 old=ident(a[name]);new=ident(b[name]);assert old['sha256']==new['sha256'] and a[name].read_bytes()==b[name].read_bytes()
 pairs.append(dict(name=name,original=old,candidate=new,byte_equal=True))
save('trace-pairs.json',pairs)
default=OUT/'probe/default-T23.route.tsv';published=OUT/'probe/published-T23.route.tsv'
baseline=ARCH/'strided-reshape/trace/routes/default-T23.route.tsv'
assert default.read_bytes()==published.read_bytes()==baseline.read_bytes()
rows=list(csv.DictReader(default.open(),delimiter='\t'))
boundaries=list(csv.DictReader((OUT/'probe/published-T23.boundaries.tsv').open(),delimiter='\t'))
ports=[];files=[]
for row in boundaries:
 shape=list(map(int,row['shape'].rstrip(',').split(',')));name=row['point'];producer=row['producer']
 selected=[step for step in rows if any(n.split(':',1)[0]==producer for n in step['nodes'].split(','))]
 assert len(selected)==1
 path=OUT/'probe/prefill'/(name+'.bf16');file=ident(path);assert file['bytes']==math.prod(shape)*2
 files.append(dict(name=name,path=path.relative_to(OUT).as_posix(),shape=shape,dtype='BF16',bytes=file['bytes'],sha256=file['sha256']))
 ports.append(dict(name=name,value=int(row['value']),producer=int(producer),shape=shape,selected_step=selected[0],original_step_output=True))
save('probe-ports.json',ports)
T=23;cache=candidate/'layer3.value.bf16';data=cache.read_bytes();assert len(data)==32*512*2
value=OUT/'value.active.bf16';value.write_bytes(data[:T*512*2]);file=ident(value)
files.append(dict(name='value',path=value.name,shape=[1,T,2,256],dtype='BF16',bytes=file['bytes'],sha256=file['sha256'],origin=dict(cache=ident(cache),byte_offset=0,byte_count=T*512*2,operation='exact active-prefix byte slice of actual completed candidate KV; no numerical recomputation')))
for name,dtype,shape,suffix in [('positions','I32',[T],'i32'),('frequencies','F32',[32],'f32')]:
 path=OUT/'probe'/(name+'.'+suffix);file=ident(path);assert file['bytes']==math.prod(shape)*4
 files.append(dict(name=name,path=path.relative_to(OUT).as_posix(),shape=shape,dtype=dtype,bytes=file['bytes'],sha256=file['sha256']))
assert struct.unpack('<23i',(OUT/'probe/positions.i32').read_bytes())==tuple(range(T))
save('probe-manifest.json',dict(T=T,scale=0.0625,causal=True,files=files,candidate_consumer=ident(OUT/'consumer.cc'),
 scope='Executed same 24-layer prefill math; new publications only. Analysis never feeds any candidate output or oracle value into Hyle.'))
guard=dict(passed=True,observables=50,bytes=sum(r['candidate']['bytes'] for r in pairs),byte_equal=50,
 default_route=ident(default),published_route=ident(published),prior_route=ident(baseline),route_byte_equal=True,
 math_nodes=1878,steps=len(rows),probes_original_selected_step_outputs=ports,
 all_actual_inputs=[ident(OUT/'consumer.cc'),ident(OUT/'probe-manifest.json')],
 qualification='All original 50 public results match frozen default; every math step/provider/implementation/node group matches default and prior. Probe values were already selected-step outputs and original ggml outputs had fusion protection. Publication only changes retention/workspace; no native math or provider pinning added.')
save('guard.json',guard);print(json.dumps(dict(passed=True,observables=50,bytes=guard['bytes'],route_byte_equal=True,steps=len(rows),probes=len(ports))))
