"""CPU-only independent same-input controls for fused attention precision.

No model loading or candidate execution. The probability representation follows
the observed native prefill source; this is not its instruction-order simulator.
"""
from pathlib import Path
import hashlib
import json
import time
import numpy as np
from replay import checked_inputs, identity

OUT = Path(__file__).resolve().parent
target = OUT / 'analysis-unnormalized.json'
if target.exists():
    raise ValueError('Do not overwrite an existing analysis')
manifest, guard, payloads, authenticated = checked_inputs(
    OUT / 'probe-manifest.json', OUT / 'guard.json')
start = time.perf_counter()


def as_bf16(words):
    return (np.asarray(words, dtype=np.uint32) << 16).view(np.float32)


def words_rne(value):
    bits = np.asarray(value, dtype=np.float32).copy().view(np.uint32)
    return ((bits + np.uint32(0x7fff) + ((bits >> 16) & 1)) >> 16).astype(np.uint16)


def rounded(value):
    return as_bf16(words_rne(value))


def tensor(name):
    row = next(r for r in manifest['files'] if r['name'] == name)
    return as_bf16(np.frombuffer(payloads[name], dtype='<u2')).reshape(row['shape'])


def compare(actual, reference):
    a = actual.astype(np.float64)
    e = reference.astype(np.float64)
    delta = a - e
    aw = words_rne(actual)
    ew = words_rne(reference)
    return dict(elements=a.size, max_abs=float(np.abs(delta).max()),
                relative_l2=float(np.linalg.norm(delta) / np.linalg.norm(e)),
                bf16_projection_mismatches=int(np.count_nonzero(aw != ew)),
                actual_nonfinite=int(np.count_nonzero(~np.isfinite(a))),
                reference_nonfinite=int(np.count_nonzero(~np.isfinite(e))),
                actual_bf16_sha256=hashlib.sha256(aw.tobytes()).hexdigest(),
                reference_bf16_sha256=hashlib.sha256(ew.tobytes()).hexdigest())


q = tensor('post_q').transpose(0, 2, 1, 3)
k = np.repeat(tensor('post_k').transpose(0, 2, 1, 3), 4, axis=1)
v = np.repeat(tensor('value').transpose(0, 2, 1, 3), 4, axis=1)
actual = tensor('attention')
allowed = np.arange(23)[None, :] <= np.arange(23)[:, None]
results = {}
for score_type in [np.float32, np.float64]:
    score = q.astype(score_type) @ k.astype(score_type).swapaxes(-1, -2)
    score = np.where(allowed, score, -np.inf)
    maximum = score.max(axis=-1, keepdims=True)
    # Native F32 scale_log2 is formed as scale * log2(e), with exp2 after
    # subtracting the unscaled maximum. FP64 branch is a separate math control.
    scale_log2 = score_type(.0625) * score_type(1.4426950408889634)
    exponent = np.exp2((score - maximum) * scale_log2)
    narrow = rounded(exponent).astype(score_type)
    for name, probability, denominator in [
        ('bf16_exp_rounded_denominator', narrow, narrow.sum(axis=-1, keepdims=True)),
        ('bf16_exp_unrounded_denominator', narrow, exponent.sum(axis=-1, keepdims=True)),
        ('wide_exp_denominator', exponent, exponent.sum(axis=-1, keepdims=True)),
    ]:
        output = ((probability @ v.astype(score_type)) / denominator).transpose(0, 2, 1, 3)[0]
        results[f'{np.dtype(score_type).name}_{name}'] = {
            'unrounded_output': compare(actual, output),
            'final_bf16_output': compare(actual, rounded(output)),
        }

result = dict(
    kind='independent_cpu_unnormalized_exp_precision_controls_not_native_simulation_or_model_acceptance',
    elapsed_seconds=time.perf_counter() - start,
    script=identity(Path(__file__).resolve()),
    manifest=identity(OUT / 'probe-manifest.json'),
    guard=identity(OUT / 'guard.json'),
    original_replay=identity(OUT / 'analysis/replay.json'),
    authenticated_payloads=authenticated,
    runtime=dict(numpy=np.__version__, processor='CPU', candidate_execution=False),
    controls=results,
    limits=[
        'Same actual post-RoPE Q/K and active V, T23, H8/KV2/D256, causal and scale1/16.',
        'NumPy dot, exp2, sum and divide are independent arithmetic, not native MMA/SFU/reduction order.',
        'RNE is explicit on finite F32 words; final BF16 statistics are distinct from unrounded references.',
        'No changed tolerances, product math or full-model numerical acceptance.',
    ])
target.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps({'result': identity(target), 'controls': results}, indent=2))
