from pathlib import Path
import json,hashlib,subprocess
r=Path('/Users/kiro/hyle-scratch/compute-unified');b=r/'a-cpu-apple/selected-graph/source-build';base=b/'hyle/_deps/mlx-490c5876b63c15e8/source';hi=r/'inference-feature-completion-20261018-apple-highdim';mask=r/'library-review-20261018-apple-native-mask-strides/candidate';sdk=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
expected=[{'path': 'CMakeLists.txt', 'bytes': 17323, 'sha256': '9b7b58026aa57e49000b5018323bc5ffd4c38d7394baf1f76eaa4f369091d8d6'}, {'path': 'mlx/backend/common/common.cpp', 'bytes': 8311, 'sha256': 'a93184948cf39a454064e6221e7c1bfe5c3c890ca04173a631ea2fcd4d109100'}, {'path': 'mlx/backend/gpu/primitives.cpp', 'bytes': 9261, 'sha256': '14a318f274a165b63a81f4e8ebfe4425db17671fe44ed121ead7855b59fe0e8f'}, {'path': 'mlx/backend/metal/allocator.cpp', 'bytes': 8028, 'sha256': '79fb0c9f817f8f3777630f06265dce212ace3907384e99ccfd5196c04cc47603'}, {'path': 'mlx/backend/metal/allocator.h', 'bytes': 2068, 'sha256': 'df4f9a4bd104dc783269d6605558689ee858f2f8106dfabf9e28d1405afc5985'}, {'path': 'mlx/backend/metal/jit_kernels.cpp', 'bytes': 44606, 'sha256': '63ca81b97f2c9afad509ebd8ad7687369b0564efada95b067b4410e575e2ec68'}, {'path': 'mlx/backend/metal/kernels/bf16.h', 'bytes': 838, 'sha256': '78f0871b82a1157610867e02cbcee03a37620df032e53f0c1297541d113e164a'}, {'path': 'mlx/backend/metal/kernels/scaled_dot_product_attention.metal', 'bytes': 2798, 'sha256': '143cc4559aa0a9f140be4d714dc39f6d281b855a5ee74264868cfed5188c2b5a'}, {'path': 'mlx/backend/metal/kernels/sdpa_vector.h', 'bytes': 21510, 'sha256': '6f80412a5b8d4b9f30b054051997b7b4b70ef6c5468f1d2ba47c4a98def010b5'}, {'path': 'mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h', 'bytes': 17279, 'sha256': '287c39d121cd252d87f2ff859d3d73e0c048d5ab386160268124b60a06c84a0c'}, {'path': 'mlx/backend/metal/kernels/steel/attn/kernels/steel_attention_nax.h', 'bytes': 30293, 'sha256': 'b351119b2766d77427b3643730b7cdcac6870327e036bcc32b72de516eacb8d2'}, {'path': 'mlx/backend/metal/kernels/steel/attn/loader.h', 'bytes': 10297, 'sha256': 'a1ea2458b08bd2f259024eb5a06e56036fad1ddb703d14847ce7b8209d4c038e'}, {'path': 'mlx/backend/metal/kernels/steel/attn/nax.h', 'bytes': 26486, 'sha256': '3e80d74e70137e59381e9d15bf8d88232d0ea1fad75dfc04223623e240b3882f'}, {'path': 'mlx/backend/metal/kernels/steel/attn/params.h', 'bytes': 1220, 'sha256': '78c77516396d91940f1413004b9fa3f6d1830858e91234fb6648bc54762a4b2c'}, {'path': 'mlx/backend/metal/kernels.h', 'bytes': 10546, 'sha256': 'c40fe30e2f71e19203dac1991d1b340155881d3a94a774752d7c42ff84992e04'}, {'path': 'mlx/backend/metal/scaled_dot_product_attention.cpp', 'bytes': 37318, 'sha256': '201303cdb8152a414913bf01d543e2226c2ca7c3bf7b295639d7e7ef83e80b9c'}, {'path': 'mlx/compile.cpp', 'bytes': 40554, 'sha256': 'd228e64777bec074a04f37c7333bde88b53f33330063eb547768a75197f37a3c'}, {'path': 'mlx/fast.cpp', 'bytes': 38337, 'sha256': '4c38158369d588d4b42c34b74c331b4cd236814b447a4f352192ff84db7cb884'}, {'path': 'mlx/fast.h', 'bytes': 3693, 'sha256': 'df2d37f780abd40411228084aa2e38f13bd6fc92c3b659688c401f0ba09d281f'}, {'path': 'mlx/fast_primitives.h', 'bytes': 14728, 'sha256': 'c7a392a2b331add37103fbc7f50c31c09123facae5478aa921f1452b95c32c59'}]

def ident(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) if p.is_file() else None
comparisons=[]
for e in expected:
 candidates=[hi/'native-candidate'/e['path'],mask/e['path'],base/e['path']]
 actual=next((q for q in candidates if q.is_file()),None)
 item=dict(logical=e['path'],current=e,effective=ident(actual) if actual else None,base=ident(base/e['path']))
 item['matches_current']=bool(actual and ident(actual)['sha256']==e['sha256']);comparisons.append(item)
commands={name:json.loads((hi/name).read_text()) for name in ['compile-native-host.command.json','compile-fast.command.json']}
ninja=(b/'build.ninja').read_text().splitlines();ninja_commands={}
for i,line in enumerate(ninja):
 if line.startswith('build ') and (('scaled_dot_product_attention.air' in line and ': CUSTOM_COMMAND' in line) or ('kernels/mlx.metallib' in line and ': CUSTOM_COMMAND' in line)):
  for following in ninja[i+1:i+7]:
   if following.startswith('  COMMAND = '):ninja_commands['metal_compile' if 'scaled_dot_product_attention.air:' in line else 'metal_link']=following.removeprefix('  COMMAND = ')
paths=[]
for source in ['mlx/backend/common/utils.cpp','mlx/backend/common/utils.h','mlx/utils.cpp','mlx/utils.h']:
 q=base/source
 if not q.exists():continue
 lines=q.read_text().splitlines()
 for i,line in enumerate(lines):
  if 'current_binary_dir(' in line:paths.append(dict(path=str(q),line=i+1,code='\n'.join(lines[max(0,i-3):i+42])))
result=dict(commands=commands,effective_sources=comparisons,ninja=ninja_commands,binary_dir=paths,
 host=ident(hi/'native-host.o'),fast=ident(hi/'fast.o'),steel=ident(mask/'steel_attention.o'),
 archive=ident(sdk/'lib/libmlx.a'),device_source=ident(base/'mlx/backend/metal/device.cpp'),
 sdk_metallib=ident(sdk/'lib/mlx.metallib'),loader_header=ident(base/'mlx/backend/metal/metal.h'),
 air=[ident(q) for q in sorted((b/'hyle/_deps/mlx-build/mlx/backend/metal/kernels').glob('*.air'))],
 device_include_lines=(base/'mlx/backend/metal/device.cpp').read_text().splitlines()[:30])
print(json.dumps(result,indent=2))
