已确认最小闭包为 **1 个 MLX host TU + 1 个 attention AIR + 重链原 8-AIR metallib**，未执行。

当前实际 host 是 highdim/native-host.o，含 HylePagedAttention::eval_gpu 和普通 SDPA；steel_attention.o 仅为 JIT Steel 字符串。当前20-file实现可逐一对上：18份来自实际host的include/source overlay，另common.cpp与gpu/primitives.cpp由已链接的explicit对象覆盖，同源20/20。新host使用20-file小overlay优先及derive490未改头回退，保原fast/common/primitives/Steel对象。

原metallib 1,666,984B，SHA2f149b1a…；attention AIR225,600B，SHA b1a2e28d…，其余7AIR直接按绝对路径复用。真正Metal配方含-fno-fast-math和macOS14.4。默认xcrun找不到metal（exit72），已有Metal17F109 shim/工具可用；不下载工具。旧日志host约1.28s、attention AIR357ms、metallib link146ms，仅是历史构建成本。

推荐在固定overlay内仅新trial子目录放消费者与新mlx.metallib。旧device loader先用get_metallib_path override，再以dladdr当前binary目录找mlx.metallib，最后fallback编译时METAL_PATH；因此无需重编device.cpp，也不改原SDK/root symlink。新host必须与新AIR/resource成对，原半精度partial资源不能配F32 host。实际新link后还需用map确认旧native-host及archive同TU未抽取。

全部精确身份/原命令在runtime-cache.json，新命令模板在planned-commands.json。未编译、链接、同步、改源或运行GPU；不把此调查当数值通过。

最新测试link草案沿实际#288/#289闭包，替换ready消费者main与MLX host，仅补原gtest_main/gtest；四个current Graph/CPU cold对象逐项保留。测试对象130b27d7…实际存在，但未以此代签其Popen退出或数值通过。
