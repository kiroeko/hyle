from pathlib import Path
import base64, hashlib, importlib.util, json, sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
spec = importlib.util.spec_from_file_location('air', OUT.parents[1] / 'apple-page-invocation/air.py')
air = importlib.util.module_from_spec(spec); spec.loader.exec_module(air)
TRIAL = air.REMOTE + '/f32-partials'
PLAN = json.loads((OUT.parent / 'planned-commands.json').read_text())
SDK = '/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk'
OLDHOST = PLAN['link_delta']['replace']['path']

REMOTE = r'''
from pathlib import Path
import base64, hashlib, json, os, subprocess, sys, time
p=json.loads(sys.stdin.buffer.read()); root=Path(p['trial']); root.mkdir(exist_ok=True)
out=root/'validation'; out.mkdir(exist_ok=True)
def identity(path):
 q=Path(path); return dict(path=str(q),bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest())
for row in p.get('writes',[]):
 q=Path(row['path']); assert q.is_relative_to(root.parent); q.parent.mkdir(parents=True,exist_ok=True)
 q.write_bytes(base64.b64decode(row['data']))
for row in p.get('copies',[]):
 source=Path(row['source']);q=Path(row['destination']);assert q.is_relative_to(root) and not q.exists()
 q.write_bytes(source.read_bytes())
for row in p.get('links',[]):
 assert Path(row['target']).is_file(), row['target']
 q=Path(row['path']); q.parent.mkdir(exist_ok=True)
 if q.is_symlink(): assert str(q.readlink())==row['target']
 else: assert not q.exists(); q.symlink_to(row['target'])
if p.get('command_file'):
 d=json.loads(Path(p['command_file']).read_text()); argv=d if isinstance(d,list) else d.get('argv',d.get('command')); assert isinstance(argv,list)
else: argv=p.get('argv')
if argv:
 tag=p['tag']; env=dict(os.environ); env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:'+env['PATH']
 record=dict(tag=tag,argv=argv,cwd=str(root),environment={'PATH_prefix':'/Users/kiro/hyle-verify-tools/metal-17F109/shim'},started=time.time())
 (out/(tag+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
 start=time.monotonic()
 with (out/(tag+'.stdout.log')).open('wb') as a,(out/(tag+'.stderr.log')).open('wb') as b:
  process=subprocess.Popen(argv,cwd=root,env=env,stdout=a,stderr=b)
  record['pid']=process.pid; (out/'live.json').write_text(json.dumps(record,indent=2)+'\n')
  try: code=process.wait(timeout=p.get('timeout',180))
  except subprocess.TimeoutExpired:
   record['timeout']=True; (out/'live.json').write_text(json.dumps(record,indent=2)+'\n'); raise
 record.update(exit=code,seconds=time.monotonic()-start,finished=time.time(),terminal=True)
 record['outputs']=[identity(x) for x in p.get('outputs',[]) if Path(x).is_file()]
 (out/(tag+'.result.json')).write_text(json.dumps(record,indent=2)+'\n'); (out/'live.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record)); print((out/(tag+'.stdout.log')).read_text(errors='replace')[-18000:]); print((out/(tag+'.stderr.log')).read_text(errors='replace')[-6000:])
else:
 print(json.dumps({'writes':[identity(x['path']) for x in p.get('writes',[])], 'files':[identity(x) for x in p.get('inspect',[]) if Path(x).is_file()]}))
'''

def invoke(payload):
 payload['trial']=TRIAL
 result=air.ssh(REMOTE,json.dumps(payload).encode(),timeout=240)
 tag=payload.get('tag','sync')
 (OUT/(tag+'.transport.stdout.log')).write_bytes(result.stdout)
 (OUT/(tag+'.transport.stderr.log')).write_bytes(result.stderr)
 print(result.stdout.decode(errors='replace')); print(result.stderr.decode(errors='replace'))
 if result.returncode: raise SystemExit(result.returncode)

def argv(name):
 return [s.replace('${TRIAL}',TRIAL).replace(TRIAL+'/source',TRIAL+'/math-source') for s in PLAN[name]]

def write(path,local):
 return dict(path=path,data=base64.b64encode(local.read_bytes()).decode())

action=sys.argv[1]
if action=='test':
 source=ROOT/'tests/graph_route_apple/attention_partials_test.cc'
 invoke(dict(tag='001a-test-compile',writes=[write(air.REMOTE+'/tests/graph_route_apple/attention_partials_test.cc',source)],command_file=TRIAL+'/test-compile-command.json',outputs=[TRIAL+'/attention-partials-test.o']))
elif action=='control-link':
 cmd=argv('tests_link_draft'); cmd=[s.replace(TRIAL+'/native-host.f32.o',OLDHOST) for s in cmd]
 cmd=[(TRIAL+'/control/attention-partials') if s==TRIAL+'/attention-partials' else s.replace(',-map,'+TRIAL+'/attention-partials.map',',-map,'+TRIAL+'/control/attention-partials.map') for s in cmd]
 invoke(dict(tag='002a-control-link',argv=cmd,links=[dict(path=TRIAL+'/control/mlx.metallib',target=SDK+'/lib/mlx.metallib')],outputs=[TRIAL+'/control/attention-partials',TRIAL+'/control/attention-partials.map']))
elif action=='control-run':
 invoke(dict(tag='003-control-run',argv=[TRIAL+'/control/attention-partials','--gtest_filter=AppleAttentionPartials.DirectKeepsRepresentable*:AppleAttentionPartials.GroupedDecode*','--gtest_output=json:'+TRIAL+'/control/tests.json'],outputs=[TRIAL+'/control/tests.json']))
elif action=='sync':
 src=ROOT/'.scratch/architecture-refactor-2026-10-18/apple-f32-partials-implementation/current'
 files=sorted(x for x in src.rglob('*') if x.is_file()); assert len(files)==20
 rows=[dict(path=x.relative_to(src).as_posix(),bytes=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest()) for x in files]
 (OUT/'math-source-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
 invoke(dict(tag='004-math-sync',writes=[write(TRIAL+'/math-source/'+x.relative_to(src).as_posix(),x) for x in files]))
elif action in {'host','air','metallib','trial-link','trial-run'}:
 tag,key,outputs={
  'host':('005-host-compile','host_compile',[TRIAL+'/native-host.f32.o']),
  'air':('006-attention-air','metal_compile',[TRIAL+'/scaled_dot_product_attention.f32.air']),
  'metallib':('007-metallib-link','metal_link',[TRIAL+'/mlx.metallib']),
  'trial-link':('008-trial-link','tests_link_draft',[TRIAL+'/attention-partials',TRIAL+'/attention-partials.map']),
  'trial-run':('009-trial-run',None,[TRIAL+'/tests.json'])}[action]
 cmd=argv(key) if key else [TRIAL+'/attention-partials','--gtest_filter=AppleAttentionPartials.Direct*:AppleAttentionPartials.OrdinaryRagged*:AppleAttentionPartials.GroupedDecode*','--gtest_output=json:'+TRIAL+'/tests.json']
 invoke(dict(tag=tag,argv=cmd,outputs=outputs))
elif action=='collect':
 code=r'''from pathlib import Path;import base64,json;r=Path('''+repr(TRIAL)+r''');files=[(str(p.relative_to(r)),p) for p in (r/'validation').iterdir() if p.is_file()]+[(str(p.relative_to(r)),p) for p in [r/'tests.json',r/'control/tests.json',r/'tests-final.json',r/'tests-complete.json']]+[('source/current-attention_partials_test.cc',r.parent/'tests/graph_route_apple/attention_partials_test.cc')];print(json.dumps([{'path':name,'data':base64.b64encode(p.read_bytes()).decode()} for name,p in files if p.is_file()]))'''
 result=air.ssh(code); assert result.returncode==0,result.stderr
 for row in json.loads(result.stdout):
  path=OUT/'results'/row['path']; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(base64.b64decode(row['data']))
 print('collected',len(json.loads(result.stdout)),'records')
elif action=='verify':
 expected=[PLAN['link_delta']['replace'],PLAN['link_delta']['archive'],*PLAN['link_delta']['unchanged_host_objects'],*PLAN['link_delta']['reference_air_identities']]
 expected += [x['object'] for x in PLAN['tests_link_baseline']['kept_fresh_core_cpu_owners']]
 code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read()); r=Path(p['trial'])
def ident(q):
 q=Path(q);return dict(path=str(q),bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest())
verified=[]
for row in p['expected']:
 actual=ident(row['path']); assert actual==row,(row,actual);verified.append(actual)
source=[]
for row in p['sources']:
 actual=ident(r/'math-source'/row['path']);assert actual['sha256']==row['sha256'];source.append(actual)
text=(r/'attention-partials.map').read_text();head=text.split('# Sections:')[0]
assert str(r/'native-host.f32.o') in head
assert p['oldhost'] not in head
assert not any('libmlx.a' in line and 'scaled_dot_product_attention.cpp.o' in line for line in head.splitlines())
hostid=[line for line in head.splitlines() if 'native-host.f32.o' in line]
symbols=[line for line in text.splitlines() if 'eval_gpu' in line and ('ScaledDotProductAttention' in line or 'HylePagedAttention' in line)]
assert len(symbols)>=2
control=ident(r/'control/mlx.metallib'); original=ident(p['sdk']+'/lib/mlx.metallib')
assert control['sha256']==original['sha256']=='2f149b1a4c8fccd585410c1ee4abb0e5a711a574935d4dcc24f4458f5c9951d4'
candidate=ident(r/'mlx.metallib');assert candidate['sha256']!=original['sha256']
outputs=[ident(r/x) for x in ['attention-partials-test.o','native-host.f32.o','scaled_dot_product_attention.f32.air','mlx.metallib','control/attention-partials','attention-partials']]
machine={name:subprocess.run(argv,capture_output=True,text=True).stdout.strip() for name,argv in [('hw_model',['sysctl','-n','hw.model']),('memory',['sysctl','-n','hw.memsize']),('os',['sw_vers'])]}
report=dict(verified_unchanged_inputs=verified,sources=source,selected_host=hostid,selected_eval_gpu=symbols,control_metallib=control,candidate_metallib=candidate,outputs=outputs,machine=machine,terminal=True)
(r/'validation/010-matched-identities.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
 result=air.ssh(code,json.dumps(dict(trial=TRIAL,expected=expected,sources=json.loads((OUT/'math-source-identities.json').read_text()),oldhost=OLDHOST,sdk=SDK)).encode())
 (OUT/'010-verify.transport.stdout.log').write_bytes(result.stdout);(OUT/'010-verify.transport.stderr.log').write_bytes(result.stderr)
 print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'));raise SystemExit(result.returncode)
elif action=='sync-final':
 rows=json.loads((ROOT/'.scratch/architecture-refactor-2026-10-18/apple-f32-partials-journey/source-identities.json').read_text())[:4]
 for row in rows:
  q=ROOT/row['path']; assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256']
 (OUT/'final-source-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
 invoke(dict(tag='011-final-sync',writes=[write(air.REMOTE+'/'+row['path'],ROOT/row['path']) for row in rows]))
elif action=='prepare-final':
 commands=json.loads((OUT.parents[1]/'apple-page-invocation/air-results/commands.json').read_text())
 recipes={}
 for source in ['src/compute_route_apple/apple_batch.cc','src/graph_route_apple/native_paged_region.cc']:
  rows=[r for r in commands if r.get('exit')==0 and '-c' in r.get('command',[]) and r['command'][r['command'].index('-c')+1].endswith('/'+source)]
  assert rows,source
  cmd=list(rows[-1]['command']); obj=TRIAL+'/'+source.replace('/','--').rsplit('.',1)[0]+'.o'
  cmd[cmd.index('-c')+1]=air.REMOTE+'/'+source;cmd[cmd.index('-o')+1]=obj
  cmd[1:1]=['-I'+air.REMOTE+'/include','-I'+air.REMOTE,'-Werror']
  recipes[source]=dict(argv=cmd,object=obj,original_tag=rows[-1]['tag'])
 cmd=argv('tests_link_draft')
 replacements={TRIAL+'/attention-partials-test.o':TRIAL+'/attention-partials-final-test.o',TRIAL+'/attention-partials':TRIAL+'/attention-partials-final'}
 for source,row in recipes.items():
  old=[s for s in cmd if s.endswith('/'+source.replace('/','--').rsplit('.',1)[0]+'.o')]
  assert len(old)==1,(source,old); replacements[old[0]]=row['object']
 cmd=[replacements.get(s,s.replace(',-map,'+TRIAL+'/attention-partials.map',',-map,'+TRIAL+'/attention-partials-final.map')) for s in cmd]
 recipes['link']=dict(argv=cmd,replacements=replacements)
 (OUT/'final-recipes.json').write_text(json.dumps(recipes,indent=2)+'\n')
 print('prepared',[(s,r.get('original_tag')) for s,r in recipes.items()])
elif action=='final-test':
 # Preserve the first test object used by the old-math control and partial trial.
 payload=dict(tag='012-final-test-compile',command_file=TRIAL+'/test-compile-command.json',outputs=[TRIAL+'/attention-partials-final-test.o'])
 # Read the existing exact command, changing only its output path.
 code=r'''from pathlib import Path;import json;p=Path('''+repr(TRIAL+'/test-compile-command.json')+r''');d=json.loads(p.read_text());a=d if isinstance(d,list) else d.get('argv',d.get('command'));a[a.index('-o')+1]='''+repr(TRIAL+'/attention-partials-final-test.o')+r''';print(json.dumps(a))'''
 result=air.ssh(code);assert result.returncode==0,result.stderr
 payload.pop('command_file');payload['argv']=json.loads(result.stdout);invoke(payload)
elif action in {'final-batch','final-page','final-link','final-run'}:
 recipes=json.loads((OUT/'final-recipes.json').read_text())
 tag,key={'final-batch':('013-final-batch-compile','src/compute_route_apple/apple_batch.cc'),'final-page':('014-final-page-compile','src/graph_route_apple/native_paged_region.cc'),'final-link':('015-final-tests-link','link'),'final-run':('016-final-tests-run',None)}[action]
 cmd=recipes[key]['argv'] if key else [TRIAL+'/attention-partials-final','--gtest_filter=AppleAttentionPartials.*','--gtest_output=json:'+TRIAL+'/tests-final.json']
 outputs=([recipes[key]['object']] if key not in {'link',None} else [TRIAL+'/attention-partials-final',TRIAL+'/attention-partials-final.map'] if key=='link' else [TRIAL+'/tests-final.json'])
 invoke(dict(tag=tag,argv=cmd,outputs=outputs))
elif action in {'final-verify','final-verify2'}:
 code=r'''
from pathlib import Path
import hashlib,json,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['trial'])
def ident(q):
 q=Path(q);return dict(path=str(q),bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest())
text=(r/'attention-partials-final.map').read_text();head=text.split('# Sections:')[0];rows=[]
for name in ['src--compute_route_apple--apple_batch.o','src--graph_route_apple--native_paged_region.o','native-host.f32.o','attention-partials-final-test.o']:
 lines=[line for line in head.splitlines() if line.endswith('/'+name)];assert len(lines)==1,(name,lines)
 assert str(r/name) in lines[0];rows+=lines
assert p['oldhost'] not in head
assert not any('libmlx.a' in line and 'scaled_dot_product_attention.cpp.o' in line for line in head.splitlines())
sources=[]
for row in p['sources']:
 actual=ident(r.parent/row['path']);assert actual['sha256']==row['sha256'];sources.append(actual)
newmath=ident(r/'native-host.f32.o');assert newmath['sha256']=='f5fffb14d1ddbff88737830677125b6be027f41c0bf29eb601b95aaf41fafd02'
metallib=ident(r/'mlx.metallib');assert metallib['sha256']=='cabb611108c741e6132c3b518d832dc0b8c730868415d3c44789526823095636'
report=dict(selected_owners=rows,sources=sources,math_host=newmath,metallib=metallib,terminal=True)
(r/('validation/'+p['tag']+'-matched-identities.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
 tag='017-final' if action=='final-verify' else '021-final'
 result=air.ssh(code,json.dumps(dict(trial=TRIAL,sources=json.loads((OUT/'final-source-identities.json').read_text()),oldhost=OLDHOST,tag=tag)).encode())
 (OUT/(tag+'-verify.transport.stdout.log')).write_bytes(result.stdout);(OUT/(tag+'-verify.transport.stderr.log')).write_bytes(result.stderr)
 print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'));raise SystemExit(result.returncode)
elif action=='page-fix':
 source='src/graph_route_apple/native_paged_region.cc';expected='5a62d7339e2dc8d47724c8fc921b80541020dd3deb1f263c02f61bb075c07c79'
 local=ROOT/source;assert hashlib.sha256(local.read_bytes()).hexdigest()==expected
 oldrows=json.loads((OUT/'final-source-identities.json').read_text())
 (OUT/'nonmath-before-seal-fix-source-identities.json').write_text(json.dumps(oldrows,indent=2)+'\n')
 for row in oldrows:
  if row['path']==source:row.update(bytes=local.stat().st_size,sha256=expected)
 (OUT/'final-source-identities.json').write_text(json.dumps(oldrows,indent=2)+'\n')
 recipe=json.loads((OUT/'final-recipes.json').read_text())[source]
 invoke(dict(tag='018-final-page-seal-fix-compile',writes=[write(air.REMOTE+'/'+source,local)],copies=[dict(source=recipe['object'],destination=TRIAL+'/native-page.before-seal-fix.o')],argv=recipe['argv'],outputs=[recipe['object'],TRIAL+'/native-page.before-seal-fix.o']))
elif action in {'complete-link','complete-run'}:
 recipes=json.loads((OUT/'final-recipes.json').read_text())
 if action=='complete-link':tag='019-complete-tests-link';cmd=recipes['link']['argv'];outputs=[TRIAL+'/attention-partials-final',TRIAL+'/attention-partials-final.map']
 else:tag='020-complete-tests-run';cmd=[TRIAL+'/attention-partials-final','--gtest_filter=AppleAttentionPartials.*','--gtest_output=json:'+TRIAL+'/tests-complete.json'];outputs=[TRIAL+'/tests-complete.json']
 invoke(dict(tag=tag,argv=cmd,outputs=outputs))
elif action=='final-metadata':
 code=r'''
from pathlib import Path
import hashlib,json,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['trial'])
def ident(q):
 q=Path(q);return dict(path=str(q),bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest())
objects=sorted(r.glob('*.o'));assert len(objects)==6,[str(q) for q in objects]
images=[r/x for x in ['control/attention-partials','control/attention-partials.map','attention-partials','attention-partials.map','attention-partials-final','attention-partials-final.map']]
retained=[ident(q) for q in objects];resources=[ident(r/q) for q in ['scaled_dot_product_attention.f32.air','mlx.metallib']]
files=[ident(q) for q in images]
cleanup=dict(host='kiro@172.22.10.198',root=str(r),files=files,retain=retained+resources,file_count=len(files),bytes=sum(x['bytes'] for x in files),retain_objects=len(retained),retain_object_bytes=sum(x['bytes'] for x in retained),delete_executed=False)
(r/'validation/cleanup-mac.json').write_text(json.dumps(cleanup,indent=2)+'\n')
rows=[]
for source in p['sources']:
 q=r.parent/source['path'];actual=ident(q);assert actual['sha256']==source['sha256'];rows.append(actual)
math=[]
for source in p['math']:
 actual=ident(r/'math-source'/source['path']);assert actual['sha256']==source['sha256'];math.append(actual)
report=dict(sources=rows,math_sources=math,retained_objects=retained,retained_resources=resources,cleanup_count=cleanup['file_count'],cleanup_bytes=cleanup['bytes'],terminal=json.loads((r/'validation/live.json').read_text()))
(r/'validation/022-final-metadata.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
'''
 result=air.ssh(code,json.dumps(dict(trial=TRIAL,sources=json.loads((OUT/'final-source-identities.json').read_text()),math=json.loads((OUT/'math-source-identities.json').read_text()))).encode())
 (OUT/'022-metadata.transport.stdout.log').write_bytes(result.stdout);(OUT/'022-metadata.transport.stderr.log').write_bytes(result.stderr)
 print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'));raise SystemExit(result.returncode)
else: raise ValueError(action)
