"""Freeze the already completed narrow validation; never builds or deletes."""
from pathlib import Path
import hashlib
import json
import shutil

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
RESULTS=OUT/'results'
RECORDS=RESULTS/'validation'

def read(path): return json.loads(path.read_text())
def write(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def identity(path):
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())

complete=read(RESULTS/'tests-complete.json')
assert complete['tests']==4 and complete['failures']==0
run=read(RECORDS/'020-complete-tests-run.result.json')
assert run['terminal'] and run['exit']==0
before=read(RESULTS/'control/tests.json')
assert before['tests']==2 and before['failures']==2
first_trial=read(RESULTS/'tests.json')
assert first_trial['tests']==3 and first_trial['failures']==1
before_seal_fix=read(RESULTS/'tests-final-first.json')
assert before_seal_fix['tests']==4 and before_seal_fix['failures']==1
metadata=read(RECORDS/'022-final-metadata.json')
assert len(metadata['retained_objects'])==6
cleanup=read(RECORDS/'cleanup-mac.json')
assert cleanup['file_count']==6 and cleanup['bytes']==55492700
cleanup['dir']=cleanup['root']
write(OUT/'cleanup-mac.json',cleanup)
write(OUT/'retained-identities.json',dict(objects=metadata['retained_objects'],resources=metadata['retained_resources']))

for row in read(OUT/'final-source-identities.json'):
    source=ROOT/row['path']
    assert identity(source)['sha256']==row['sha256']
    target=OUT/'current'/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)

commands=[read(p) for p in sorted(RECORDS.glob('*.result.json'))]
write(OUT/'commands.json',commands)
summary=dict(
    status='four_narrow_attention_math_and_original_graph_lifetime_tests_passed',
    hardware=read(RECORDS/'010-matched-identities.json')['machine'],
    final=dict(command='020-complete-tests-run',exit=run['exit'],tests=4,passed=4,
               test_seconds=complete['time'],process_seconds=run['seconds'],
               results='results/tests-complete.json',stdout='results/validation/020-complete-tests-run.stdout.log'),
    control=dict(command='003-control-run',exit=1,tests=2,numerical_failures=2,
                 results='results/control/tests.json',old_host_and_original_colocated_metallib=True),
    retained_failures=[
        dict(command='001-test-compile',kind='scratch_command_file_list_parser_before_any_compiler_launch'),
        dict(command='002-control-link',kind='scratch_output_path_rewrite_incorrectly_rewrote_test_object_path'),
        dict(command='003-control-run',kind='two_original_math_numerical_failures'),
        dict(command='009-trial-run',kind='two_math_passes_and_lazy_reshape_input_bind_fixture_failure'),
        dict(command='016-final-tests-run',kind='three_math_passes_and_real_paged_seal_retired_result_owner_omission'),
    ],
    corrections=dict(
        fixture='Test explicitly evaluates reshape inputs before the original bind-ready gate; no math, budget or tolerance change.',
        product='Paged seal releases its retired ResultStorageOwner before the existing native reuse gate, matching the ordinary Apple region; Graph old-result/source-reader/native uniqueness checks remain.',
    ),
    selected_final_owners=read(RECORDS/'021-final-matched-identities.json')['selected_owners'],
    math_build=dict(new_host_tus=1,new_attention_air=1,reused_original_air=7,
                    host_source_sha256='a3293daa0566c89b473ab1261021d84f2fc98c318afd9dc5c8526cd01c30fa12',
                    partial_header_sha256='7c0672ca90ae3ef2d65e3ab058b8b8ba1df97af37b05880255032a667f7aa6b5',
                    flags='Existing strict Clang, Metal 17F109 shim, -fno-fast-math, deployment 14.4',
                    final_host=metadata['retained_objects'][2],
                    resources=metadata['retained_resources'],
                    original_sdk_and_eight_original_air_unchanged=True,
                    map_excludes_old_sdpa_host_and_archive_member=True),
    scope=['Direct native paged two-pass F16/BF16 representable final results and BF16 cancellation',
           'Default ordinary Graph, two slots, old GraphOutput blocks its own slot, independent slot replay',
           'Ordinary and ragged attention plus adjacent one-pass/full branches',
           'B2 optimized grouped decode with distinct per-batch K and V and FP64 softmax oracle'],
    limits=['Only these four tests on Mac16,12; no whole-model or performance claim.',
            'No tolerance relaxation, zero warm allocation claim, or full SDK rebuild.',
            'New host is paired with the newly linked colocated metallib; shared SDK/base files are read-only.'],
    cleanup=dict(manifest='cleanup-mac.json',files=6,bytes=cleanup['bytes'],executed=False,
                 retained_objects=6,retained_object_bytes=cleanup['retain_object_bytes'],retained_air=1,retained_metallib=1),
    live_processes=False,
)
write(OUT/'summary.json',summary)
receipt=dict(status='frozen',summary=identity(OUT/'summary.json'),commands=identity(OUT/'commands.json'),
             final_results=identity(RESULTS/'tests-complete.json'),cleanup=identity(OUT/'cleanup-mac.json'),
             retained=identity(OUT/'retained-identities.json'),sources=identity(OUT/'final-source-identities.json'),
             math_sources=identity(OUT/'math-source-identities.json'),
             selected_owners=identity(RECORDS/'021-final-matched-identities.json'))
write(OUT/'receipt.json',receipt)
print(json.dumps(dict(receipt=identity(OUT/'receipt.json'),summary=receipt['summary'],cleanup=summary['cleanup']),indent=2))
