from pathlib import Path
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BASE = OUT.parent
IMPLEMENTATION = BASE / 'apple-f32-partials-implementation'
RUNTIME = BASE / 'apple-f32-partials-runtime'
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


plan = read(RUNTIME / 'validation/cleanup-mac.json')
assert plan['host'] == 'kiro@172.22.10.198'
assert len(plan['files']) == 6 and len(plan['retain']) == 8
write(OUT / 'cleanup-plan.json', plan)

extensions = {'.json', '.log', '.txt', '.xml', '.py', '.ps1', '.diff', '.h', '.cpp',
              '.cc', '.cmake', '.md', '.metal', '.map'}
files = {}
for scope, label in [(OUT, 'journey'), (IMPLEMENTATION, 'implementation'), (RUNTIME, 'runtime')]:
    for path in scope.rglob('*'):
        relative = path.relative_to(scope)
        if (path.is_file() and path.suffix in extensions and '__pycache__' not in relative.parts
                and path.name not in {'archive-receipts.json', 'cleanup-result.json', 'final-results.json'}):
            files[label + '/' + relative.as_posix()] = path

extras = [
    'third_party/mlx_cast/patches.json', 'third_party/mlx_cast/NOTICE.md', 'third_party/mlx_cast/LICENSE',
    'cmake/HyleDependencyLock.json', 'include/hyle/compute/detail/apple_batch_access.h',
    'src/compute_route_apple/apple_batch.cc', 'src/graph_route_apple/native_paged_region.cc',
    'tests/graph_route_apple/attention_partials_test.cc', 'tests/graph_route_apple/CMakeLists.txt',
    'docs/architecture/compute-design.md', 'docs/developer/current-work.md', 'docs/user/apple-compute.md',
    'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md', 'test.ps1',
]
for name in extras:
    files['source/' + name] = ROOT / name
files['cleanup-plan.json'] = OUT / 'cleanup-plan.json'
target = EVIDENCE / 'apple-two-pass-partials.zip'
assert not target.exists(), 'Do not overwrite frozen evidence'
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9, strict_timestamps=False) as archive:
    for name, path in sorted(files.items()):
        archive.write(path, name)
    archive.writestr('archive-manifest.json', json.dumps([
        dict(entry=name, **identity(path)) for name, path in sorted(files.items())], indent=2) + '\n')
receipt = dict(archive=identity(target), files=len(plan['files']), bytes=plan['bytes'],
               retained_objects=plan['retain_objects'], retained_matching_shader_bundle=2,
               source_entries=len(files))
write(OUT / 'archive-receipts.json', receipt)
print(json.dumps(receipt))
