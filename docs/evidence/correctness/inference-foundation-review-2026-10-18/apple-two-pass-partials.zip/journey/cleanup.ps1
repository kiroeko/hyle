param([switch]$ReclaimAppleTwoPassPartials)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not $ReclaimAppleTwoPassPartials) { throw 'Specify -ReclaimAppleTwoPassPartials; no default deletion.' }
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace + [IO.Path]::DirectorySeparatorChar
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/apple-f32-partials-journey'
function Get-CheckedFile($row) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $row.path))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $parent = [IO.Path]::GetDirectoryName($path)
    while ($parent -eq $workspace -or $parent.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        if ((Get-Item -LiteralPath $parent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked ancestor: $parent" }
        $parent = [IO.Path]::GetDirectoryName($parent)
    }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $row.bytes -or
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $row.sha256) { throw "File changed: $path" }
    return $item
}
$receipt = Get-Content -LiteralPath (Join-Path $stage 'archive-receipts.json') -Raw | ConvertFrom-Json
$evidence = Get-CheckedFile $receipt.archive
$zip = [IO.Compression.ZipFile]::OpenRead($evidence.FullName)
try {
    $reader = [IO.StreamReader]::new($zip.GetEntry('cleanup-plan.json').Open())
    try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if ($frozen -cne [IO.File]::ReadAllText((Join-Path $stage 'cleanup-plan.json'))) { throw 'Cleanup differs from archive' }
} finally { $zip.Dispose() }
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($frozen))
$remoteScript = @'
from pathlib import Path
import base64,hashlib,json,subprocess
plan=json.loads(base64.b64decode('__MANIFEST__'))
root=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials')
assert plan['root']==plan['dir']==str(root) and root.resolve(strict=True)==root
assert plan['host']=='kiro@172.22.10.198'
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
targets=[]
for row in plan['files']+plan['retain']:
 p=Path(row['path'])
 assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p
 assert p.is_relative_to(root)
 assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 if row in plan['files']:
  assert p.parent in {root,root/'control'}
  assert p.name in {'attention-partials','attention-partials.map','attention-partials-final','attention-partials-final.map'}
  targets.append(p)
 else:
  assert p.parent==root and (p.suffix in {'.o','.air'} or p.name=='mlx.metallib')
assert len(targets)==len(set(targets))==6 and len(plan['retain'])==8
for p in targets:p.unlink()
result=dict(files=6,bytes=sum(r['bytes'] for r in plan['files']),retained_objects=6,retained_matching_shader_bundle=2,other_cache_retained=True)
(root/'cleanup-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
'@
$remoteScript = $remoteScript.Replace('__MANIFEST__', $encoded)
$transport = [Diagnostics.ProcessStartInfo]::new((Get-Command ssh).Source)
$transport.UseShellExecute = $false
$transport.CreateNoWindow = $true
$transport.RedirectStandardOutput = $true
$transport.RedirectStandardError = $true
$transport.RedirectStandardInput = $true
foreach ($argument in @('-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'kiro@172.22.10.198', 'python3 -')) { $transport.ArgumentList.Add($argument) }
$process = [Diagnostics.Process]::Start($transport)
try {
    $outputTask = $process.StandardOutput.ReadToEndAsync()
    $errorTask = $process.StandardError.ReadToEndAsync()
    $process.StandardInput.Write($remoteScript)
    $process.StandardInput.Close()
    $process.WaitForExit()
    $remoteOutput = $outputTask.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) { throw ('Mac cleanup failed: ' + $errorTask.GetAwaiter().GetResult()) }
} finally { $process.Dispose() }
$result = @{ mac = ($remoteOutput | ConvertFrom-Json); archive_verified = $true }
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $stage 'cleanup-result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 6
