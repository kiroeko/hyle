from pathlib import Path
import hashlib,json,subprocess,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
def identity(p):
 p=Path(p);data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
commands=json.loads((OUT/'commands.json').read_text(encoding='utf-8')) if (OUT/'commands.json').exists() else []
for tag,cmd in [('selected-mlx-lock-license-audit',['cmake','-P',str(OUT/'audit.cmake')]),
 ('diff-check',['git','diff','--check','--','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md','cmake/HyleDependencyLock.json'])]:
 if any(r['command']==cmd and r['exit']==0 for r in commands):continue
 stem=f'{len(commands)+1:03d}-'+tag
 start=time.monotonic();result=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=60)
 (OUT/(stem+'.stdout.log')).write_bytes(result.stdout);(OUT/(stem+'.stderr.log')).write_bytes(result.stderr)
 commands.append(dict(tag=tag,command=cmd,exit=result.returncode,seconds=time.monotonic()-start,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
 save('commands.json',commands)
 assert result.returncode==0,(tag,result.stdout.decode(errors='replace'),result.stderr.decode(errors='replace'))
baseline=json.loads((OUT/'before/cmake/HyleDependencyLock.json').read_text(encoding='utf-8'))
current=json.loads((ROOT/'cmake/HyleDependencyLock.json').read_text(encoding='utf-8'))
assert [r for r in baseline['dependencies'] if r['name']!='mlx_cast_patches']==[r for r in current['dependencies'] if r['name']!='mlx_cast_patches']
summary=json.loads((OUT/'summary.json').read_text(encoding='utf-8'))
summary.update(selected_lock_license_audit='PASS:cmake -P audit.cmake, only mlx_cast_patches selected',diff_check='PASS',
 products=[identity(ROOT/p) for p in summary['products']],frozen=True,
 optimized_gqa_fix='Authorized alongside partial fix: original optimized GQA KV address now uses batch_idx*num_kv_heads+kv_head_idx, same normal-pass host stride contract. Actual B2 regression belongs to parent validation; no execution claimed here.')
save('summary.json',summary)
(OUT/'summary.md').write_text('''Apple vector two-pass F32 partials 的本地产品补丁已冻结，尚未编译或运行。

只修改 MLX exact manifest、NOTICE 及锁中 mlx_cast_patches 一项。完整 raw→manifest 重放20文件通过：host中间array改为float32；normal1/GQA1的partial输出、GQA局部指针和store、pass2的partial输入共6处改为float；其余18文件逐字节不变。one-pass、最终T输出/cast、原template/host_name、blocks/page/window/maxsum均保持。

F16/BF16 partial payload由2变4B，新增2*B*Hq*Q*blocks*Dv请求字节；F32不增加。原encoder寿命不变，无新owner/开关/shaderidentity或整KV拷贝。host和原base AIR/metallib必须匹配刷新，未移除C++/Graph精度门。

selected MLX lock/license audit一次PASS，git diff --check PASS；其他dependency条目包括ggml逐项完全不变。before/candidate/current20、appended-edits、source/derived diff及身份均已保存。无编译、远端同步、数值/性能测试，无删除文件。

同时按parent授权修复原optimized GQA的K/V基址遗漏batch_idx：使用与normal pass相同的batch/head合并索引，两KV指针均更新，private逐请求B1原行为不变。实际B2数值回归尚待parent执行。初次身份audit发现WindowsPath排序与CMake大小写排序不一致，失败日志保留，最终portable排序后审计通过。
''',encoding='utf-8',newline='\n')
save('final-manifest.json',dict(summary=identity(OUT/'summary.json'),summary_text=identity(OUT/'summary.md'),
 products=summary['products'],derived_manifest=identity(OUT/'current-identities.json'),
 edits=identity(OUT/'appended-edits.json'),product_diff=identity(OUT/'source.diff'),derived_diff=identity(OUT/'derived.diff'),
 commands=identity(OUT/'commands.json'),all_lock_other_dependencies_unchanged=True,
 compiled=False,remote_synced=False,executed=False,images=[],objects=[]))
print(json.dumps(dict(summary=identity(OUT/'summary.json'),products=summary['products'],audits=commands),indent=2))
