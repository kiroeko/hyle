"""Preserve the uncompiled F32-only stage and append the authorized GQA fix."""
from pathlib import Path
import difflib,hashlib,json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRODUCTS=['third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md','cmake/HyleDependencyLock.json']
HOST='mlx/backend/metal/scaled_dot_product_attention.cpp'
VECTOR='mlx/backend/metal/kernels/sdpa_vector.h'
def sha(data):return hashlib.sha256(data).hexdigest()
def identity(p):
 p=Path(p);d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=sha(d))
def normalized(data):return data.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def exact(data,edit):
 before=edit['before'].encode();assert data.count(before)==1
 return data.replace(before,edit['after'].encode(),1)

for name in PRODUCTS:
 path=OUT/'f32-only'/name;path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists():assert path.read_bytes()==(ROOT/name).read_bytes()
 else:path.write_bytes((ROOT/name).read_bytes())
for name in [HOST,VECTOR]:
 path=OUT/'f32-only/current'/name;path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists():assert path.read_bytes()==(OUT/'current'/name).read_bytes()
 else:path.write_bytes((OUT/'current'/name).read_bytes())
for name in ['appended-edits.json','current-identities.json','source-identities.json','summary.json','structural-checks.json','vendor-tree-manifest.txt']:
 path=OUT/'f32-only'/name
 if path.exists():assert path.read_bytes()==(OUT/name).read_bytes()
 else:path.write_bytes((OUT/name).read_bytes())
edits=[dict(
 before='  const int base_head = batch_idx * num_q_heads + kv_head_idx * G;\n',
 after='  const int base_head = batch_idx * num_q_heads + kv_head_idx * G;\n  const int kv_batch_head_idx = batch_idx * num_kv_heads + kv_head_idx;\n'),dict(
 before='  const device T* kp = keys + kv_head_idx * k_head_stride + (hyle_paged ? 0 : s0 * k_seq_stride) +\n',
 after='  const device T* kp = keys + kv_batch_head_idx * k_head_stride + (hyle_paged ? 0 : s0 * k_seq_stride) +\n'),dict(
 before='  const device T* vp = values + kv_head_idx * v_head_stride +\n',
 after='  const device T* vp = values + kv_batch_head_idx * v_head_stride +\n')]
manifest=json.loads((ROOT/PRODUCTS[0]).read_text(encoding='utf-8'))
entry=next(e for e in manifest['files'] if e['path']==VECTOR)
data=(OUT/'current'/VECTOR).read_bytes();assert sha(data)==entry['after_sha256']
for edit in edits:data=exact(data,edit)
entry['edits'].extend(edits);entry['after_sha256']=sha(data)
replayed={}
for item in manifest['files']:
 d=normalized((OUT.parent/'apple-f32-partials/raw'/item['path']).read_bytes())
 assert sha(d)==item['before_sha256']
 for edit in item['edits']:d=exact(d,edit)
 assert sha(d)==item['after_sha256']
 replayed[item['path']]=d
 assert item['path']==VECTOR or d==(OUT/'current'/item['path']).read_bytes()
notice=(ROOT/PRODUCTS[1]).read_text(encoding='utf-8')+'''
The existing optimized GQA first pass also includes the batch index in its
K/V head address, matching the normal vector pass. The original host already
ensures contiguous batch/head storage for multi-batch, multi-KV-head inputs;
the combined batch/head index uses that existing stride contract. Ordinary
B>1 calls no longer reuse batch0 K/V for later batches. Per-request B1 private
paged/ragged calls retain their original physical addressing.
'''
new={PRODUCTS[0]:(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode(),PRODUCTS[1]:notice.encode()}
vendor=ROOT/'third_party/mlx_cast'
tree=''
for p in sorted((p for p in vendor.rglob('*') if p.is_file()),key=lambda p:p.relative_to(vendor).as_posix()):
 name=p.relative_to(ROOT).as_posix();raw=new.get(name,p.read_bytes())
 tree+=p.relative_to(vendor).as_posix()+'|'+sha(normalized(raw))+'\n'
tree_sha=sha(tree.encode())
lock=json.loads((ROOT/PRODUCTS[2]).read_text(encoding='utf-8'))
entry=next(e for e in lock['dependencies'] if e['name']=='mlx_cast_patches')
entry['vendored']['tree_sha256']=tree_sha
next(e for e in entry['license']['files'] if e['path']==PRODUCTS[1])['sha256']=sha(new[PRODUCTS[1]])
old=json.loads((OUT/'before'/PRODUCTS[2]).read_text(encoding='utf-8'))
assert [e for e in old['dependencies'] if e['name']!='mlx_cast_patches']==[e for e in lock['dependencies'] if e['name']!='mlx_cast_patches']
new[PRODUCTS[2]]=(json.dumps(lock,indent=2,ensure_ascii=False)+'\n').encode()
for name,d in new.items():
 (ROOT/name).write_bytes(d);(OUT/'candidate'/name).write_bytes(d)
(OUT/'current'/VECTOR).write_bytes(replayed[VECTOR])
changes=json.loads((OUT/'appended-edits.json').read_text(encoding='utf-8'))
v=next(e for e in changes if e['path']==VECTOR);v['appended_edits'].extend(edits);v['after_sha256']=sha(replayed[VECTOR])
save('appended-edits.json',changes)
save('current-identities.json',[dict(path=name,bytes=len(d),sha256=sha(d),changed=name in [HOST,VECTOR]) for name,d in sorted(replayed.items())])
save('source-identities.json',[identity(ROOT/p) for p in PRODUCTS])
(OUT/'source.diff').write_text(''.join(''.join(difflib.unified_diff((OUT/'before'/p).read_text(encoding='utf-8').splitlines(True),new[p].decode().splitlines(True),fromfile='before/'+p,tofile='candidate/'+p)) for p in PRODUCTS),encoding='utf-8',newline='\n')
(OUT/'derived.diff').write_text(''.join(''.join(difflib.unified_diff((OUT/'before/derived'/p).read_text(encoding='utf-8').splitlines(True),replayed[p].decode().splitlines(True),fromfile='before/'+p,tofile='current/'+p)) for p in [HOST,VECTOR]),encoding='utf-8',newline='\n')
(OUT/'vendor-tree-manifest.txt').write_text(tree,encoding='utf-8',newline='\n')
checks=json.loads((OUT/'structural-checks.json').read_text(encoding='utf-8'))
checks.update(optimized_gqa_batch_index_in_both_KV_pointers=True,mlx_cast_patch_tree_sha256=tree_sha,
 tree_sort='Portable path strings, case-sensitive like CMake list(SORT); not WindowsPath comparator')
save('structural-checks.json',checks)
summary=json.loads((OUT/'summary.json').read_text(encoding='utf-8'))
summary.update(changed_derived=changes,vendored_tree_sha256=tree_sha,notice_sha256=sha(new[PRODUCTS[1]]),
 optimized_gqa_fix='Original B>1 K/V head base now includes batch_idx*num_kv_heads, same normal-pass stride contract; B1 unchanged.',
 identity_correction='First local audit caught WindowsPath case-insensitive sorting in the scratch tree calculator; corrected to portable case-sensitive strings. First failure log retained. F32-only source phase is preserved in f32-only/.')
save('summary.json',summary)
print(json.dumps(dict(products=[identity(ROOT/p) for p in PRODUCTS],derived_header=identity(OUT/'current'/VECTOR),tree_sha256=tree_sha),indent=2))
