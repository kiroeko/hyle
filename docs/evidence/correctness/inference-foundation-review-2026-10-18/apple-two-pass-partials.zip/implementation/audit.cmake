include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(mlx_cast_patches)
message(STATUS "MLX selected patch tree and license identity PASS")
