"""Exact MLX two-pass partial-storage patch, with full20-file manifest replay.

This edits only the three authorized local product files. It does not compile,
contact a remote machine, alter source caches or change HYLE C++ qualification.
"""
from pathlib import Path
import difflib,hashlib,json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
BASE=OUT.parent/'apple-f32-partials'
RAW=BASE/'raw'
CURRENT=BASE/'current'
PRODUCTS=['third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md','cmake/HyleDependencyLock.json']
HOST='mlx/backend/metal/scaled_dot_product_attention.cpp'
VECTOR='mlx/backend/metal/kernels/sdpa_vector.h'

def sha(data):return hashlib.sha256(data).hexdigest()
def normalized(data):return data.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def identity(p):
 p=Path(p);data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=sha(data))
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def exact(data,edit,label):
 before=edit['before'].encode();after=edit['after'].encode()
 assert data.count(before)==1,(label,data.count(before))
 return data.replace(before,after,1)
def replay(manifest):
 result={}
 for entry in manifest['files']:
  data=normalized((RAW/entry['path']).read_bytes())
  assert sha(data)==entry['before_sha256'],entry['path']
  for i,edit in enumerate(entry['edits']):data=exact(data,edit,(entry['path'],i))
  assert sha(data)==entry['after_sha256'],entry['path']
  result[entry['path']]=data
 return result

assert not (OUT/'before-identities.json').exists(),'One-shot implementation: do not duplicate manifest edits'
old={p:(ROOT/p).read_bytes() for p in PRODUCTS}
manifest=json.loads(old[PRODUCTS[0]])
lock=json.loads(old[PRODUCTS[2]])
assert len(manifest['files'])==20
replayed=replay(manifest)
assert {p.relative_to(CURRENT).as_posix() for p in CURRENT.rglob('*') if p.is_file()}==set(replayed)
for name,data in replayed.items():assert data==(CURRENT/name).read_bytes(),name
for name,data in old.items():
 target=OUT/'before'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
for name in [HOST,VECTOR]:
 target=OUT/'before/derived'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(replayed[name])
save('before-identities.json',dict(products=[identity(ROOT/p) for p in PRODUCTS],
 current=[identity(CURRENT/p) for p in sorted(replayed)],
 raw=[identity(RAW/p) for p in sorted(replayed)],full_manifest_replay_matches_current=True))

edits={HOST:[dict(
 before='  array intermediate(intermediate_shape, q.dtype(), nullptr, {});\n',
 after='  array intermediate(intermediate_shape, float32, nullptr, {});\n')],
 VECTOR:[dict(
 before='''[[kernel]] void sdpa_vector_2pass_1(
    const device T* queries [[buffer(0)]],
    const device T* keys [[buffer(1)]],
    const device T* values [[buffer(2)]],
    device T* out [[buffer(3)]],
''',
 after='''[[kernel]] void sdpa_vector_2pass_1(
    const device T* queries [[buffer(0)]],
    const device T* keys [[buffer(1)]],
    const device T* values [[buffer(2)]],
    device float* out [[buffer(3)]],
'''),dict(
 before='''  for (int i = 0; i < v_per_thread; i++) {
    out[i] = static_cast<T>(o[i]);
  }
}

// Duplication-free variant''',
 after='''  for (int i = 0; i < v_per_thread; i++) {
    out[i] = o[i];
  }
}

// Duplication-free variant'''),dict(
 before='''[[kernel]] void sdpa_vector_2pass_1_gqa(
    const device T* queries [[buffer(0)]],
    const device T* keys [[buffer(1)]],
    const device T* values [[buffer(2)]],
    device T* out [[buffer(3)]],
''',
 after='''[[kernel]] void sdpa_vector_2pass_1_gqa(
    const device T* queries [[buffer(0)]],
    const device T* keys [[buffer(1)]],
    const device T* values [[buffer(2)]],
    device float* out [[buffer(3)]],
'''),dict(
 before='''  device T* op =
      out + o_offset * blocks * V + block_idx * V + simd_lid * v_per_thread;
''',
 after='''  device float* op =
      out + o_offset * blocks * V + block_idx * V + simd_lid * v_per_thread;
'''),dict(
 before='    op[i] = static_cast<T>(acc[i]);\n',
 after='    op[i] = acc[i];\n'),dict(
 before='''[[kernel]] void sdpa_vector_2pass_2(
    const device T* partials [[buffer(0)]],
''',
 after='''[[kernel]] void sdpa_vector_2pass_2(
    const device float* partials [[buffer(0)]],
'''),dict(
 before='  const int base_head = batch_idx * num_q_heads + kv_head_idx * G;\n',
 after='  const int base_head = batch_idx * num_q_heads + kv_head_idx * G;\n  const int kv_batch_head_idx = batch_idx * num_kv_heads + kv_head_idx;\n'),dict(
 before='  const device T* kp = keys + kv_head_idx * k_head_stride + (hyle_paged ? 0 : s0 * k_seq_stride) +\n',
 after='  const device T* kp = keys + kv_batch_head_idx * k_head_stride + (hyle_paged ? 0 : s0 * k_seq_stride) +\n'),dict(
 before='  const device T* vp = values + kv_head_idx * v_head_stride +\n',
 after='  const device T* vp = values + kv_batch_head_idx * v_head_stride +\n')]}
changed=[]
for name,appended in edits.items():
 entry=next(e for e in manifest['files'] if e['path']==name)
 before=replayed[name];data=before
 for i,edit in enumerate(appended):data=exact(data,edit,(name,'new',i))
 entry['edits'].extend(appended)
 entry['after_sha256']=sha(data)
 changed.append(dict(path=name,before_sha256=sha(before),after_sha256=sha(data),appended_edits=appended))
new_replayed=replay(manifest)
assert [p for p in sorted(replayed) if replayed[p]!=new_replayed[p]]==sorted([HOST,VECTOR])

# Structural checks protect the original one-pass/final T output and source ABI.
vector=new_replayed[VECTOR].decode()
old_vector=replayed[VECTOR].decode()
normal=vector[vector.index('[[kernel]] void sdpa_vector_2pass_1('):vector.index('// Duplication-free variant')]
gqa=vector[vector.index('[[kernel]] void sdpa_vector_2pass_1_gqa('):vector.index('[[kernel]] void sdpa_vector_2pass_2(')]
aggregate=vector[vector.index('[[kernel]] void sdpa_vector_2pass_2('):]
assert 'device float* out [[buffer(3)]]' in normal and 'static_cast<T>(o[i])' not in normal
assert 'device float* out [[buffer(3)]]' in gqa and 'device float* op =' in gqa and 'static_cast<T>(acc[i])' not in gqa
assert 'const device float* partials [[buffer(0)]]' in aggregate
assert 'device T* out [[buffer(3)]]' in aggregate and 'out[i] = static_cast<T>(o[i]);' in aggregate
assert vector[:vector.index('template <typename T, int D, int V = D>\n[[kernel]] void sdpa_vector_2pass_1')]==old_vector[:old_vector.index('template <typename T, int D, int V = D>\n[[kernel]] void sdpa_vector_2pass_1')]
metal='mlx/backend/metal/kernels/scaled_dot_product_attention.metal'
assert new_replayed[metal]==replayed[metal]

notice=old[PRODUCTS[1]].decode()
notice+='''
The shared vector two-pass attention helper now stores its partial output in
F32 for ordinary SDPA and private paged/ragged calls. The host intermediate
uses float32; both the normal and optimized GQA first passes store their
existing float accumulators through float pointers, and the second pass reads
float partials. Query/key/value storage, page/window indexing, block selection,
max/sum combination, launch order and final declared-type output cast remain
unchanged. The one-pass, Steel and NAX paths are unchanged. This removes the
intermediate F16/BF16 rounding/overflow boundary; low-precision output bits may
therefore change, and numerical tolerances still require actual validation.

The partial shape remains [B,Hq,Q,blocks,Dv]. F16/BF16 partial payload grows
from 2 to 4 bytes per element, adding 2*B*Hq*Q*blocks*Dv requested bytes;
F32 partial payload is unchanged. Sums/maxs were already F32. The original
encoder retains this same temporary until completion; allocator rounding,
cache and other private costs are not represented as zero. Host and base
metallib must be rebuilt as a matching pair because these precompiled kernels
share the revised partial-buffer contract. Kernel names, template parameters,
function constants and public API are unchanged; no alternate shader,
precision switch, executor or full-history KV copy is added.

The existing optimized GQA first pass also includes the batch index in its
K/V head address, matching the normal vector pass. The original host already
ensures contiguous batch/head storage for multi-batch, multi-KV-head inputs;
the combined batch/head index uses that existing stride contract. Ordinary
B>1 calls no longer reuse batch0 K/V for later batches. Per-request B1 private
paged/ragged calls retain their original physical addressing.
'''
new={PRODUCTS[0]:(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode(),PRODUCTS[1]:notice.encode()}
vendor=ROOT/'third_party/mlx_cast'
tree_manifest=''
for path in sorted((p for p in vendor.rglob('*') if p.is_file()),key=lambda p:p.relative_to(vendor).as_posix()):
 assert not path.is_symlink(),path
 rel=path.relative_to(vendor).as_posix()
 product=path.relative_to(ROOT).as_posix()
 data=new.get(product,path.read_bytes())
 tree_manifest+=rel+'|'+sha(normalized(data))+'\n'
tree_sha=sha(tree_manifest.encode())
original_other=[entry for entry in lock['dependencies'] if entry['name']!='mlx_cast_patches']
entry=next(e for e in lock['dependencies'] if e['name']=='mlx_cast_patches')
entry['version']='hyle-apple-native-patches-v4'
entry['vendored']['tree_sha256']=tree_sha
notice_license=next(e for e in entry['license']['files'] if e['path']==PRODUCTS[1])
notice_license['sha256']=sha(normalized(new[PRODUCTS[1]]))
assert original_other==[entry for entry in lock['dependencies'] if entry['name']!='mlx_cast_patches']
new[PRODUCTS[2]]=(json.dumps(lock,indent=2,ensure_ascii=False)+'\n').encode()

for name,data in new.items():
 (ROOT/name).write_bytes(data)
 target=OUT/'candidate'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
for name,data in new_replayed.items():
 target=OUT/'current'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
save('appended-edits.json',changed)
save('current-identities.json',[dict(path=name,bytes=len(data),sha256=sha(data),changed=name in edits) for name,data in sorted(new_replayed.items())])
save('source-identities.json',[identity(ROOT/p) for p in PRODUCTS])
save('structural-checks.json',dict(raw_to_existing_current_all20_match=True,new_manifest_all20_replay=True,
 changed_files=[HOST,VECTOR],other18_files_byte_identical=True,
 one_pass_byte_identical=True,pass2_final_T_pointer_and_cast_unchanged=True,
 metal_instantiations_byte_identical=True,template_names_and_arguments_unchanged=True,
 other_lock_dependencies_unchanged=True,mlx_cast_patch_tree_sha256=tree_sha,
 numerical_or_build_validation=False,remote_sync=False))
diff=''.join(''.join(difflib.unified_diff(old[p].decode().splitlines(True),new[p].decode().splitlines(True),fromfile='before/'+p,tofile='candidate/'+p)) for p in PRODUCTS)
(OUT/'source.diff').write_text(diff,encoding='utf-8',newline='\n')
diff=''.join(''.join(difflib.unified_diff(replayed[p].decode().splitlines(True),new_replayed[p].decode().splitlines(True),fromfile='before/'+p,tofile='current/'+p)) for p in [HOST,VECTOR])
(OUT/'derived.diff').write_text(diff,encoding='utf-8',newline='\n')
(OUT/'vendor-tree-manifest.txt').write_text(tree_manifest,encoding='utf-8',newline='\n')
(OUT/'audit.cmake').write_text('include("'+(ROOT/'cmake/HyleDependencyVersions.cmake').as_posix()+'")\nhyle_audit_in_tree_dependencies(mlx_cast_patches)\nmessage(STATUS "MLX selected patch tree and license identity PASS")\n',encoding='utf-8',newline='\n')
save('summary.json',dict(status='implemented_local_sources_not_compiled_or_executed',products=PRODUCTS,changed_derived=changed,
 current_file_count=20,other_current_files_unchanged=18,patch_version=entry['version'],vendored_tree_sha256=tree_sha,
 notice_sha256=notice_license['sha256'],partial_payload='F16/BF16 2→4B per partial; F32 unchanged; extra2*B*Hq*Q*blocks*Dv requested bytes.',
 scope='Same original ordinary/private paged/ragged two-pass helper; no new owner, template parameter, kernel identity, dispatch flag, or final dtype change.',
 unverified=['No host/Metal compilation, remote synchronization or numerical test.','Existing Graph/Compute precision analysis/gate not edited; must remain until matching actual host/metallib passes.','Native allocator rounding/cache/peak and throughput are not measured.']))
print(json.dumps(dict(products=[identity(ROOT/p) for p in PRODUCTS],derived=[dict(path=r['path'],after_sha256=r['after_sha256']) for r in changed],tree_sha256=tree_sha),indent=2))
