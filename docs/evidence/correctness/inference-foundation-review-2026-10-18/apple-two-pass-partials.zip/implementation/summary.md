Apple vector two-pass F32 partials 的本地产品补丁已冻结，尚未编译或运行。

只修改 MLX exact manifest、NOTICE 及锁中 mlx_cast_patches 一项。完整 raw→manifest 重放20文件通过：host中间array改为float32；normal1/GQA1的partial输出、GQA局部指针和store、pass2的partial输入共6处改为float；其余18文件逐字节不变。one-pass、最终T输出/cast、原template/host_name、blocks/page/window/maxsum均保持。

F16/BF16 partial payload由2变4B，新增2*B*Hq*Q*blocks*Dv请求字节；F32不增加。原encoder寿命不变，无新owner/开关/shaderidentity或整KV拷贝。host和原base AIR/metallib必须匹配刷新，未移除C++/Graph精度门。

selected MLX lock/license audit一次PASS，git diff --check PASS；其他dependency条目包括ggml逐项完全不变。before/candidate/current20、appended-edits、source/derived diff及身份均已保存。无编译、远端同步、数值/性能测试，无删除文件。

同时按parent授权修复原optimized GQA的K/V基址遗漏batch_idx：使用与normal pass相同的batch/head合并索引，两KV指针均更新，private逐请求B1原行为不变。实际B2数值回归尚待parent执行。初次身份audit发现WindowsPath排序与CMake大小写排序不一致，失败日志保留，最终portable排序后审计通过。
