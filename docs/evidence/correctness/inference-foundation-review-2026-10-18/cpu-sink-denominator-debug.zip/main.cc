#include <gtest/gtest.h>
#include <cstdlib>
#include <windows.h>

int main(int argc, char **argv) {
  SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
  _set_error_mode(_OUT_TO_STDERR);
  _set_abort_behavior(0, _WRITE_ABORT_MSG | _CALL_REPORTFAULT);
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
