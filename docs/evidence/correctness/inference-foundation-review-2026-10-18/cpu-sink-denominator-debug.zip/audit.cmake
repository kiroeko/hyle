get_filename_component(hyle_root "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
include("${hyle_root}/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_cpu_runtime_patches)
message(STATUS "CPU sink denominator selected dependency identity PASS")
