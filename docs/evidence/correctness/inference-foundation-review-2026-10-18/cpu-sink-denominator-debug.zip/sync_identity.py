from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
lock_path=ROOT/'cmake/HyleDependencyLock.json';text=lock_path.read_text(encoding='utf-8');lock=json.loads(text)
entry=next(x for x in lock['dependencies'] if x['name']=='ggml_cpu_runtime_patches')
def digest(path):
    return hashlib.sha256(path.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')).hexdigest()
vendor=ROOT/entry['vendored']['path']
items=sorted((p for p in vendor.rglob('*') if p.is_file()),key=lambda p:p.relative_to(vendor).as_posix())
manifest=''.join(f'{p.relative_to(vendor).as_posix()}|{digest(p)}\n' for p in items)
notice=next(x for x in entry['license']['files'] if x['path'].endswith('NOTICE.md'))
updates={entry['vendored']['tree_sha256']:hashlib.sha256(manifest.encode()).hexdigest(),notice['sha256']:digest(ROOT/notice['path'])}
for before,after in updates.items():
    assert text.count(before)==1
    text=text.replace(before,after,1)
lock_path.write_text(text,encoding='utf-8',newline='\n')
(OUT/'lock-updates.json').write_text(json.dumps(updates,indent=2)+'\n')
print(json.dumps(updates,indent=2))
