from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
native_record=next(x for x in json.loads((ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed-native-commands-recovered.json').read_text()) if x['label']=='mixed-native-baseline')
native_flags=[x for x in native_record['argv'] if not str(x).endswith('.cpp') and not x.lower().startswith('/fo') and not re.match(r'[-/]DNDEBUG(?:=|$)',x,re.I)]
native_flags.append('/UNDEBUG')
batch=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/commands.json').read_text())
host_command=next(x['command'] for x in reversed(batch) if x['tag']=='cpu-canonical-compile')
host_flags=[x for x in host_command if not str(x).endswith('.cc') and not x.lower().startswith('/fo')]
link_command=next(x['command'] for x in reversed(batch) if x['tag']=='cpu-link')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host_command[0],'CMAKE_C_COMPILER':host_command[0]})
env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
runtime=[str(ROOT/'.scratch/build-compute-v2-dev/bin')]+[str(Path(p).parent) for p in link_command if p.endswith('.lib') and Path(p).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
records=[]
def run(tag,args,assertion_failure=False):
    args=list(map(str,args));start=time.monotonic();p=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=args,exit=p.returncode,expected_assertion_failure=assertion_failure,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-3000:],flush=True)
    if assertion_failure:
        assert p.returncode!=0 and b'Assertion failed: sum > 0.0' in p.stderr,(p.returncode,p.stderr)
    elif p.returncode:raise SystemExit(p.returncode)
def host(source,name):
    obj=OUT/(name+'.obj');run(name+'-compile',[*host_flags,source,'/Fo'+str(obj)]);return obj
edit=json.loads((OUT/'edit.json').read_text())
mixed=json.loads((OUT/'mixed-current-patches.json').read_text());entry=next(x for x in mixed['files'] if x['path']=='src/ggml-cpu/ops.cpp')
raw=(Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')/entry['path']).read_bytes().replace(b'\r\n',b'\n');assert hashlib.sha256(raw).hexdigest()==entry['before_sha256']
after=raw
for e in entry['edits']:
    a,b=e['before'].encode(),e['after'].encode();assert after.count(a)==1;after=after.replace(a,b,1)
assert hashlib.sha256(after).hexdigest()==entry['after_sha256']
assert after.count(edit['after'].encode())==1
before=after.replace(edit['after'].encode(),edit['before'].encode(),1)
cached=ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/ops.cpp'
assert before==cached.read_bytes().replace(b'\r\n',b'\n')
(OUT/'source-correspondence.json').write_text(json.dumps(dict(canonical_ffa_before_sha256=hashlib.sha256((OUT/'ffa-product-before.ops.cpp').read_bytes()).hexdigest(),canonical_ffa_after_sha256=hashlib.sha256((OUT/'ffa-product-after.ops.cpp').read_bytes()).hexdigest(),mixed_raw_sha256=entry['before_sha256'],mixed_before_sha256=hashlib.sha256(before).hexdigest(),mixed_after_sha256=entry['after_sha256'],before_matches_cached_release_source=True,only_source_edit=edit),indent=2)+'\n')
tests=host(ROOT/'tests/compute_provider_ggml/attention_math_test.cc','canonical-tests')
main=host(OUT/'main.cc','main')
for arm,data in [('before',before),('after',after)]:
    source=OUT/('mixed-'+arm+'.assert-enabled.cpp')
    source.write_bytes(b'#ifdef NDEBUG\n#error Native ops must retain standard assert checks\n#endif\n'+data)
    obj=OUT/('native-'+arm+'.obj')
    run(arm+'-native-ops-compile',[*native_flags,source,'/Fo'+str(obj)])
    omit={str(ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj'),str(ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cpu-canonical.obj')}
    args=[x for x in link_command if x not in omit and not x.startswith(('/OUT:','/MAP:'))]
    exe=OUT/(arm+'.exe');run(arm+'-link',[*args,tests,main,obj,'/OUT:'+str(exe)])
    if arm=='before':
        run('before-ordinary-controls',[exe,'--gtest_filter=GgmlCpuMathAttention.LayoutsBatchGqaAndOutputDepth','--gtest_color=no'])
        run('before-finite-sink-assertion',[exe,'--gtest_filter=GgmlCpuMathAttention.FiniteSinkAcceptsFullyMaskedSingleKey','--gtest_color=no'],assertion_failure=True)
    else:
        run('after-canonical-regressions',[exe,'--gtest_filter=GgmlCpuMathAttention.FiniteSinkAcceptsFullyMaskedSingleKey:GgmlCpuMathAttention.LayoutsBatchGqaAndOutputDepth:GgmlCpuMathAttention.SinkMaskTailPublishedIntermediateAndRebind','--gtest_color=no'])
paths=[Path(p) for p in link_command if str(p).endswith(('.obj','.lib')) and Path(p).is_file()]+[ROOT/'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',ROOT/'third_party/ggml_cpu_runtime/patches.json',ROOT/'third_party/ggml_cpu_runtime/NOTICE.md',ROOT/'cmake/HyleDependencyLock.json',ROOT/'tests/compute_provider_ggml/attention_math_test.cc']+list(OUT.glob('*.obj'))
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in dict.fromkeys(paths)],indent=2)+'\n')
