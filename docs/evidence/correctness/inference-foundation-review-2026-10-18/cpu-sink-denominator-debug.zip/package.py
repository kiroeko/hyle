from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
names=['third_party/ggml_cpu_runtime/patches.json','third_party/ggml_cpu_runtime/NOTICE.md','cmake/HyleDependencyLock.json','src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py','tests/compute_provider_ggml/attention_math_test.cc']
for name in names+['third_party/ggml_cpu_runtime/LICENSE','tests/compute_models/batched_sink_fixture.h','tests/compute_provider_native/half_test_support.h']:
    target=OUT/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
diff=[]
for name in names:
    before=OUT/'before'/name
    diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),(ROOT/name).read_text(encoding='utf-8').splitlines(True),fromfile=name+'.before',tofile=name))
(OUT/'task.diff').write_text(''.join(diff),encoding='utf-8')
check=subprocess.run(['cmake','-P',str(OUT/'audit.cmake')],cwd=ROOT,capture_output=True,check=True)
(OUT/'selected-dependency-audit.stdout.log').write_bytes(check.stdout)
(OUT/'selected-dependency-audit.stderr.log').write_bytes(check.stderr)
records=json.loads((OUT/'commands.json').read_text())
records.append(dict(tag='selected-dependency-audit',command=['cmake','-P',str(OUT/'audit.cmake')],exit=check.returncode))
(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
before_lock=json.loads((OUT/'before/cmake/HyleDependencyLock.json').read_text(encoding='utf-8'));after_lock=json.loads((ROOT/'cmake/HyleDependencyLock.json').read_text(encoding='utf-8'))
before_entry=next(x for x in before_lock['dependencies'] if x['name']=='ggml_cpu_runtime_patches')
after_entry=next(x for x in after_lock['dependencies'] if x['name']=='ggml_cpu_runtime_patches')
for key in ['version','revision','git_tree','archive']:
    assert before_entry[key]==after_entry[key]
for a,b in zip(before_lock['dependencies'],after_lock['dependencies']):
    if a['name']!='ggml_cpu_runtime_patches':assert a==b,a['name']
summary={
 'problem':'Native CPU standard assert(sum>0) ran before adding a finite sink. An otherwise valid fully -Inf-masked row has ordinary sum0 and sink contribution1, so an assertion-enabled build aborted before normalization.',
 'fix':'Move the same assert below the existing sink addition. Maximum already includes the sink. Exponential, F32 payload arithmetic, sink contribution, reciprocal, normalization, and no-sink checks are retained.',
 'product_files':names,
 'composition':'Canonical CPU patch has one additional exact authenticated edit and new ops after SHA; mixed manifest derivation count23->24 is the only tool change and complete current derivation succeeds.',
 'lock_scope':'Only ggml_cpu_runtime_patches vendored tree and NOTICE hash changed. Version, upstream revision/archive, and every other dependency entry unchanged.',
 'identities':json.loads((OUT/'source-correspondence.json').read_text()),
 'lock':dict(tree=after_entry['vendored']['tree_sha256'],notice=next(x['sha256'] for x in after_entry['license']['files'] if x['path'].endswith('NOTICE.md'))),
 'native_build':'Exactly the original mixed456 ops.cpp translation unit compiled twice (before/after). /DNDEBUG removed, /UNDEBUG and compile-time #error guard enforce active standard assertions. Unchanged release ggml-base/cpu/vector, allocator, selector and current provider objects/libraries reused. No source written back into checkout/cache/SDK. No full SDK, AVX2 module, all-ISA or model rebuild.',
 'baseline':{'ordinary_finite_rows':'Original canonical LayoutsBatchGqaAndOutputDepth PASS with assertion-enabled original ops.','single_key_fully_masked_finite_sink':'Canonical FiniteSinkAcceptsFullyMaskedSingleKey exits3; stderr explicitly asserts sum > 0.0 in mixed-before.assert-enabled.cpp:5697.'},
 'candidate':{'canonical_full_TU_compile':'Current tests/compute_provider_ggml/attention_math_test.cc fresh /W4 /WX PASS.','tests_passed':3,'tests':['FiniteSinkAcceptsFullyMaskedSingleKey','SinkMaskTailPublishedIntermediateAndRebind','LayoutsBatchGqaAndOutputDepth'],'new_regression':'Public prepare with actual ggml provider selected; B1/Q1/H64/D512/S1, allmask=-Inf, finite nonuniform perhead sinks, two changed Q/K/V/sink phases, each of32768 outputs exactly0.','old_budget':'Existing partial/all-masked Sink S17/Q3 and S2049/Q65, dual published intermediate and downstream Neg, two changed replays/independent slots and old result retention all PASS; existing F32 abs2e-6+rel6e-6 budget unchanged. Ordinary two layout controls PASS; maximum logged absolute error7.45058e-9 and all budget_excess0.'},
 'source_boundary':'Canonical FFA source patch SHA reconstructed and authenticated, but no complete FFA SDK execution claimed. Actual native run uses mixed456, whose pre-edit full ops source matches the previous release-cache source byte-for-byte. It differs from candidate only by assertion placement (plus identical assertion guard prefix). Standard assertions are active in ops.cpp only; remaining libraries are release cached binaries.',
 'not_retested':['Other ISA/dynamic native modules','Other platforms','Full model/22 profiles','Throughput/performance'],
 'validation':'Selected CMake dependency identity audit PASS, full mixed manifest derive PASS, canonical FFA and mixed raw/result SHA authentication PASS, git diff --check on touched files PASS.',
 'reproduce':['python src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py --source C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424 --resource-manifest third_party/ggml_runtime/patches.json --cpu-manifest third_party/ggml_cpu_runtime/patches.json --output .scratch/inference-foundation-review-2026-10-18/cpu-sink-denominator-debug/mixed-current-patches.json','python .scratch/inference-foundation-review-2026-10-18/cpu-sink-denominator-debug/build.py'],
 'archive_boundary':'Source, exact task diff, generated actual TU source, compiler/command logs and identities only. No object, executable, import library, SDK, dependency tree or previous stage archive.'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
allowed={'.json','.py','.h','.cc','.cpp','.c','.cmake','.log','.diff','.md'}
files=sorted(p for p in OUT.rglob('*') if p.is_file() and (p.suffix in allowed or p.name=='LICENSE') and '__pycache__' not in p.parts)
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(OUT).as_posix())
print(json.dumps(dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
