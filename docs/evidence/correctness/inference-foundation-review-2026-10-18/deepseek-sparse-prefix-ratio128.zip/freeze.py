from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
OLD = OUT.parent / 'deepseek-sparse-prefix'
SOURCE = ROOT / 'tests/compute_state/deepseek_sparse_prefix_consumer.cc'


def identity(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': digest.hexdigest()}


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n',
                            encoding='utf-8', newline='\n')


assert identity(OUT / 'before.cc')['sha256'] == \
    '0f129d39bc9f55a54c4c09d31c80004cf8ce51d8f2da9812af9f41cbdab379ce'
commands = json.loads((OUT / 'commands.json').read_text())
assert [(x['tag'], x['exit']) for x in commands] == [
    ('consumer-compile', 0), ('link', 0), ('consumer-run', 0),
    ('both-branches-run', 0)]
stdout = (OUT / 'both-branches.stdout.log').read_text()
assert 'ratio4 compressor' in stdout and 'ratio128 compressor' in stdout
assert 'distinct TopK sets=3' in stdout
assert 'no indexer/TopK, visible17->18 at token2, halfFill62->0->6' in stdout
for ratio in (4, 128):
    for accepted in range(9):
        assert f'CPU ratio{ratio} accept={accepted} ' in stdout

# Preserve the initial fixed-only plan and explicitly record the necessary
# parameterization regression, without calling either run a performance result.
plan = json.loads((OUT / 'run-plan.json').read_text())
plan['parameters'] = ('Fixed ratio128-only first run: absolute position2302, '
                      'position%128=126, half-window fill62; verify8, '
                      'accepted0..8 then continue1')
plan['related_regression'] = {
    'command': commands[3]['command'],
    'reason': 'Same linked executable, original ratio4 branch after Case parameterization; default also replays ratio128',
    'geometry_or_accuracy_changes': False,
}
write_json('run-plan.json', plan)

snapshot = OUT / 'source'
pending = [SOURCE, ROOT / 'tests/compute_state/CMakeLists.txt']
seen = set()
while pending:
    path = pending.pop().resolve()
    if path in seen:
        continue
    seen.add(path)
    target = snapshot / path.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    for name in re.findall(r'^\s*#\s*include\s*[<\"]([^>\"]+)[>\"]',
                           path.read_text(encoding='utf-8'), re.MULTILINE):
        for candidate in (path.parent / name, ROOT / 'include' / name,
                          ROOT / name):
            candidate = candidate.resolve()
            if candidate.is_file() and candidate.is_relative_to(ROOT):
                pending.append(candidate)
                break
source_ids = [identity(path) for path in sorted(seen, key=lambda p: p.as_posix())]
write_json('source-identities.json', source_ids)
(OUT / 'scoped.diff').write_text(''.join(difflib.unified_diff(
    (OUT / 'before.cc').read_text().splitlines(keepends=True),
    SOURCE.read_text().splitlines(keepends=True),
    fromfile='deepseek_sparse_prefix_consumer.before-ratio4.cc',
    tofile='tests/compute_state/deepseek_sparse_prefix_consumer.cc')),
    encoding='utf-8', newline='\n')

# Existing heavyweight native archives are not copied or rehashed. Their
# previous-stage identity plus current size is retained separately. Small
# reused objects and this consumer's actual artifacts are freshly hashed.
old_ids = {str(Path(x['path']).resolve()): x for x in
           json.loads((OLD / 'identities.json').read_text())}
link = commands[1]['command']
reused = []
for text in link:
    path = Path(text)
    if path.is_absolute() and path.suffix in ('.obj', '.lib') and path.parent != OUT:
        record = dict(old_ids[str(path.resolve())])
        assert path.stat().st_size == record['bytes']
        if path.suffix == '.obj':
            assert identity(path)['sha256'] == record['sha256']
            record['verification'] = 'fresh SHA256 and size, equal to original ratio4 link input'
        else:
            record['verification'] = 'original frozen ratio4 SHA256; current size matched, no native library rebuild'
        reused.append(record)
write_json('reused-link-identities.json', reused)
artifacts = [identity(OUT / name) for name in
             ('consumer.exe', 'consumer.obj', 'consumer.lib', 'consumer.exp', 'consumer.map')]
write_json('artifact-identities.json', artifacts)
cleanup = {
    'platform': 'Windows', 'root': str(OUT), 'performed': False,
    'delete': [item for item in artifacts if not item['path'].endswith('.map')],
    'delete_count': 4,
    'delete_logical_bytes': sum(item['bytes'] for item in artifacts
                                if not item['path'].endswith('.map')),
    'retain': [str(OUT / 'consumer.map'), 'all source/log/JSON/diff/zip files',
               'all reused native/foundation/provider objects and libraries'],
    'note': 'Only this task\'s four rebuildable artifacts; no deletion performed. Root owns precise test.ps1 cleanup.',
}
write_json('cleanup-candidates.json', cleanup)

summary = {
    'scope': 'DeepSeek-Flash ratio128 projected-boundary compressor, dense per-query Sink, public CPU Graph/leases/StateStore accepted-prefix continuation',
    'result': 'PASS', 'product_bug_found': False,
    'geometry': {
        'heads': 64, 'depth': 512, 'ratio': 128, 'channels': 512,
        'chunk_rows': 64, 'previous_and_current_rows': [64, 64],
        'state_resources': 6, 'token_input_roles': 5,
        'cache_capacity': 20, 'initial_visible': 17,
        'base_position': 2302, 'base_position_mod_128': 126,
        'cursor_fill_definition': 'Occupancy in current 64-row half-window, not position modulo128',
        'base_half_fill': 62, 'verify_tokens': 8,
        'completion_position': 2303, 'completion_token_1based': 2,
        'visible_after_completion': 18, 'half_fill_after_verify8': 6,
        'accepted': list(range(9)), 'continuation_tokens': 1,
        'indexer_or_topk': False,
    },
    'evidence': {
        'absolute_ape': 'Each projected gate adds APE[position%128], including126,127,0,...; compressed RoPE uses absolute block-start position',
        'state_accounting': 'Explicit projected-row/APE/raw-history accounting; current half completes at token2, rolls to previous; compressed row17 changes only on128 completion; other cache rows unchanged',
        'full_prefix': 'All6 resources plus cursor compared for accepted0..8; separate branch starts at base and executes only accepted tokens, then both continue1; resulting resource and metadata bytes are committed and exactly compared via public StateStore reads',
        'visibility': 'Every query uses its own compressed visible count and raw window. No final cache is substituted for earlier prefixes; no ratio4 indexer or IDs used for ratio128.',
        'paired_state_and_sink_max_absolute_error': 0,
        'independent_sink_max_absolute_error': 0.000122070312,
        'independent_sink_oracle': 'Full H64*D512 per query, FP64 softmax+PV given actual visible cache/predecessor and learned sinks, then original explicit BF16 boundary',
        'accuracy_budgets_unchanged': {'sink_absolute': 2e-5, 'sink_relative': 0.025,
                                       'state_pair_absolute': 8e-5, 'state_pair_relative': 4e-5},
    },
    'runs': [{key: value for key, value in entry.items() if key != 'environment'}
             for entry in commands[2:]],
    'related_ratio4_regression': {
        'result': 'PASS', 'same_executable_no_recompile': True,
        'geometry': 'Original H64/D512/index64x128/Top512, capacity516, initial512, position2048, verify8 crosses2 ratio4 completions',
        'distinct_topk_sets': 3, 'accepted_prefixes': list(range(9)),
        'paired_state_and_sink_max_absolute_error': 0,
        'independent_sink_max_absolute_error': 6.10351562e-5,
        'original_package_sha256': '3e5d05fb148d22a3c8c0d6e09e7032ec1319d6a579eb6476dbaa60275b034bea',
        'original_package_modified': False,
    },
    'allocation': {'lease_pool_bytes': 268435456,
                   'state_backing_budget_bytes': 268500992,
                   'note': 'Explicit capacities inherited from original; not a measured peak or timing result'},
    'hardware': json.loads((OLD / 'summary.json').read_text())['hardware'],
    'toolchain': 'MSVC14.50.35717 /O2 /MD /std:c++latest; matched ggml456172 native archives, baseline CPU selector and current provider/native-batch/ATen host objects; OMP/MKL/OPENBLAS threads1',
    'build': 'One fresh consumer TU plus relink only; no native/SDK/provider rebuild or configure. Exact commands and reused identities included.',
    'source': identity(SOURCE),
    'registration': 'Existing conditional compute_state CTest target unchanged; default consumer now covers both branches. CMake not configured in this experiment.',
    'failures_this_task': [],
    'limitations': [
        'Projected-boundary dense composition, no checkpoint projection/FFN/LM-head or complete model engine evidence',
        'Physical state F32 with original explicit BF16/FP8/F4 numerical boundaries; not packed BF16 historical storage',
        'CPU Graph only, no new Direct/GPU/native paging or permission-bridging proof',
        'Compressor reuses existing official math helper; no independent full FP64 compressor/checkpoint oracle',
        'Per-query Sink composition remains multiple launches/materialization; no fused efficiency or timing/peak claim',
    ],
    'cleanup_performed': False,
}
write_json('summary.json', summary)

files = sorted((p for p in OUT.rglob('*') if p.is_file() and
                p.suffix not in ('.exe', '.obj', '.lib', '.exp', '.zip') and
                p.name != 'package-identity.json'),
               key=lambda p: p.relative_to(OUT).as_posix())
archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path in files:
        handle.write(path, path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    assert len(handle.namelist()) == len(files)
result = {'archive': identity(archive), 'members': len(files),
          'source': identity(SOURCE),
          'summary': identity(OUT / 'summary.json'),
          'cleanup': identity(OUT / 'cleanup-candidates.json')}
write_json('package-identity.json', result)
print(json.dumps(result, indent=2))
