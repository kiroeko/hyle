from pathlib import Path
import json,subprocess,os,time,sys
ROOT=Path.cwd();OLD=ROOT/'.scratch/inference-foundation-review-2026-10-18/deepseek-sparse-prefix';OUT=ROOT/'.scratch/inference-foundation-review-2026-10-18/deepseek-sparse-prefix-ratio128'
old=json.loads((OLD/'commands.json').read_text());cc=next(x['command']for x in old if x['tag']=='consumer-compile');link=next(x['command']for x in reversed(old)if x['tag']=='link')
obj=OUT/'consumer.obj';exe=OUT/'consumer.exe';cc=[('/Fo'+str(obj))if x.startswith('/Fo')else x for x in cc];link=[('/OUT:'+str(exe))if x.startswith('/OUT:')else('/MAP:'+str(OUT/'consumer.map'))if x.startswith('/MAP:')else str(obj)if x==str(OLD/'consumer.obj')else x for x in link]
for p in link:
 if p.endswith(('.lib','.obj'))and Path(p).is_absolute()and p!=str(obj):assert Path(p).is_file(),p
sys.path.insert(0,str(ROOT/'scripts'));from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':cc[0],'CMAKE_C_COMPILER':cc[0]});env['VSLANG']='1033';env['PATH']=json.loads((OLD/'run-plan.json').read_text())['env_path']+os.pathsep+str(ROOT/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
records=json.loads((OUT/'commands.json').read_text())if(OUT/'commands.json').exists()else[]
def run(tag,cmd,timeout=180):
 t=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=timeout);attempt=sum(x['tag']==tag for x in records);prefix=f'attempt{attempt}-'if attempt else '';(OUT/(prefix+tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(prefix+tag+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-6500:],p.stderr.decode(errors='replace')[-1800:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run('consumer-compile',cc);run('link',link)
(OUT/'run-plan.json').write_text(json.dumps(dict(command=[str(exe),'--ratio128'],path=env['PATH'],parameters='Fixed new ratio128 only: position2302/fill126, half-window62, 8verify, accepted0..8 then continue1; no ratio4 replay'),indent=2)+'\n')
