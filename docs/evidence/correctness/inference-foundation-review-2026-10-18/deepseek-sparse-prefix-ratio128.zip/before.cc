#include <hyle/compute/leased_operation.h>
#include <hyle/compute/state_versions.h>
#include <hyle/graph/cpu.h>
#include <hyle/graph/leased_invocation.h>

#include "../compute_models/d5_deepseek_official_attention.h"

#include <array>
#include <cstdio>
#include <set>

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace ds = d5_deepseek_official_attention;
namespace sem = ds::sem;
using hyle::Status;
using sem::ValueId;
template <class T> using Result = hyle::Result<T>;

// This consumer starts at the projected attention boundary. Storage is F32,
// with the original explicit BF16/FP8/F4 numerical boundaries; it does not
// claim packed BF16 storage, a paged bridge, or the rest of a decoder block.
constexpr int kHeads = 64, kDepth = 512, kIndexHeads = 64, kIndexDepth = 128;
constexpr int kTop = 512, kCapacity = 516, kRatio = 4, kTokens = 9;
constexpr int kStates = 11, kBasePosition = 2048;
enum State : int { kPastKv, kCurrentKv, kPastScore, kCurrentScore,
                  kPastIndex, kCurrentIndex, kPastIndexScore, kCurrentIndexScore,
                  kCache, kIndex, kRaw };
struct Cursor { std::uint32_t position, visible, fill; };

Status require(bool value, const char *message) {
  return value ? Status::Ok() : Status::Internal(message);
}
c::TensorDesc dense(std::initializer_list<std::int64_t> dims,
                    c::DataType type = c::DataType::kFloat32) {
  return c::TensorDesc::dense(type, {dims.begin(), dims.size()}).value();
}
std::array<c::TensorDesc, kStates> state_descriptions() {
  return {dense({4, 1024}), dense({4, 1024}), dense({4, 1024}), dense({4, 1024}),
          dense({4, 256}), dense({4, 256}), dense({4, 256}), dense({4, 256}),
          dense({kCapacity, kDepth}), dense({kCapacity, kIndexDepth}), dense({127, kDepth})};
}
std::array<c::TensorDesc, 9> token_descriptions(int rows) {
  return {dense({rows, 1024}), dense({rows, 1024}), dense({rows, 256}), dense({rows, 256}),
          dense({rows, kDepth}), dense({1, rows, kHeads, kDepth}),
          dense({rows, kIndexHeads, kIndexDepth}), dense({rows, kIndexHeads}),
          dense({rows}, c::DataType::kInt32)};
}
ValueId copy(sem::Fragment &f, ValueId value) {
  return f.one(c::Operation(c::Copy{}), {value});
}
ValueId write_row(sem::Fragment &f, ValueId window, ValueId row, int index) {
  auto result = row;
  if (index) result = ds::concat(f, ds::slice(f, window, 0, 0, index), result, 0);
  if (index != 3) result = ds::concat(f, result, ds::slice(f, window, 0, index + 1, 3 - index), 0);
  return result;
}
ValueId replace_cache(sem::Fragment &f, ValueId cache, ValueId row, int index) {
  std::vector<std::uint8_t> writing(kCapacity);
  writing[index] = 1;
  const auto mask = f.constant(dense({kCapacity, 1}, c::DataType::kBool), sem::bytes(writing));
  return f.one(c::Operation(c::Select{}), {mask, row, cache});
}

sem::Fragment make_fragment(int count, Cursor cursor) {
  sem::Fragment f{.profile = nullptr, .region = 0x53505245464958};
  const auto descriptions = state_descriptions();
  std::array<ValueId, kStates> state;
  for (int i = 0; i < kStates; ++i) state[i] = f.input(descriptions[i]);
  const auto token_desc = token_descriptions(count);
  std::array<ValueId, 9> tokens;
  for (int i = 0; i < 9; ++i) tokens[i] = f.input(token_desc[i]);
  std::array<ValueId, 2> norm, ape;
  for (int role = 0; role < 2; ++role) {
    const int depth = role ? kIndexDepth : kDepth, channels = 2 * depth;
    std::vector<float> scales(depth), positions(4 * channels);
    for (int d = 0; d < depth; ++d) scales[d] = .75F + float(d % 7) / 16;
    for (int i = 0; i < 4 * channels; ++i) positions[i] = float((i * 7 + 3) % 23 - 11) / 16;
    norm[role] = f.constant(dense({depth}), sem::bytes(scales));
    ape[role] = f.constant(dense({4, channels}), sem::bytes(positions));
  }
  const auto empty_kv = ds::filled(f, dense({4, 1024}), 0);
  const auto empty_score = ds::filled(f, dense({4, 1024}), -INFINITY);
  const auto empty_index = ds::filled(f, dense({4, 256}), 0);
  const auto empty_index_score = ds::filled(f, dense({4, 256}), -INFINITY);
  std::vector<float> sinks(kHeads);
  for (int h = 0; h < kHeads; ++h) sinks[h] = .75F + float(h % 11) / 16;
  const auto sink = f.constant(dense({kHeads}), sem::bytes(sinks));
  std::vector<ValueId> ids_rows, attended_rows;
  for (int t = 0; t < count; ++t) {
    const auto main = ds::slice(f, tokens[0], 0, t, 1);
    const auto index = ds::slice(f, tokens[2], 0, t, 1);
    const auto ape_row = f.constant(dense({1}, c::DataType::kInt32),
                                    sem::bytes(std::vector<std::int32_t>{std::int32_t(cursor.fill)}));
    const auto main_score = ds::binary(f, c::BinaryKind::kAdd,
        ds::slice(f, tokens[1], 0, t, 1), f.one(c::Operation(c::Gather{}), {ape[0], ape_row}));
    const auto index_score = ds::binary(f, c::BinaryKind::kAdd,
        ds::slice(f, tokens[3], 0, t, 1), f.one(c::Operation(c::Gather{}), {ape[1], ape_row}));
    state[kCurrentKv] = write_row(f, state[kCurrentKv], main, cursor.fill);
    state[kCurrentScore] = write_row(f, state[kCurrentScore], main_score, cursor.fill);
    state[kCurrentIndex] = write_row(f, state[kCurrentIndex], index, cursor.fill);
    state[kCurrentIndexScore] = write_row(f, state[kCurrentIndexScore], index_score, cursor.fill);
    if (cursor.fill == 3) {
      const auto position = ds::slice(f, tokens[8], 0, t, 1);
      const auto compressed = ds::compress(f, state[kPastKv], state[kPastScore],
          state[kCurrentKv], state[kCurrentScore], norm[0], position, 4, kDepth, false);
      const auto compressed_index = ds::compress(f, state[kPastIndex], state[kPastIndexScore],
          state[kCurrentIndex], state[kCurrentIndexScore], norm[1], position, 4, kIndexDepth, true);
      state[kCache] = replace_cache(f, state[kCache], compressed, cursor.visible);
      state[kIndex] = replace_cache(f, state[kIndex], compressed_index, cursor.visible);
      state[kPastKv] = state[kCurrentKv]; state[kPastScore] = state[kCurrentScore];
      state[kPastIndex] = state[kCurrentIndex]; state[kPastIndexScore] = state[kCurrentIndexScore];
      state[kCurrentKv] = empty_kv; state[kCurrentScore] = empty_score;
      state[kCurrentIndex] = empty_index; state[kCurrentIndexScore] = empty_index_score;
      ++cursor.visible;
    }
    const auto raw = ds::concat(f, state[kRaw], ds::slice(f, tokens[4], 0, t, 1), 0);
    state[kRaw] = ds::slice(f, raw, 0, 1, 127);
    auto iq = ds::reshape(f, ds::slice(f, tokens[6], 0, t, 1), {64, 128});
    const auto weight = ds::reshape(f, ds::slice(f, tokens[7], 0, t, 1), {64, 1});
    const auto dot = ds::bfloat_boundary(f, f.one(c::Operation(c::MatMul{}),
        {iq, ds::permute(f, state[kIndex], {1, 0})}));
    const auto positive = f.one(c::model_ops::clamp(0, std::numeric_limits<float>::max()), {dot});
    const auto weighted = ds::bfloat_boundary(f, ds::binary(f, c::BinaryKind::kMultiply, positive, weight));
    const auto scores = ds::bfloat_boundary(f, ds::reshape(f, ds::moe::sum(f, weighted, 0), {1, kCapacity}));
    std::vector<float> visible(kCapacity, -INFINITY);
    std::fill_n(visible.begin(), cursor.visible, 0.F);
    const auto visibility = f.constant(dense({1, kCapacity}), sem::bytes(visible));
    const auto ids = f.append(c::Operation(c::TopK{.count = kTop}),
        {ds::binary(f, c::BinaryKind::kAdd, scores, visibility)}, 2)[1];
    const auto compressed = ds::reshape(f, f.one(c::Operation(c::Gather{}), {state[kCache], ids}), {kTop, kDepth});
    const auto compressed_mask = ds::reshape(f, f.one(c::Operation(c::Gather{}),
        {ds::reshape(f, visibility, {kCapacity, 1}), ids}), {1, kTop});
    const auto keys = ds::reshape(f, ds::concat(f, raw, compressed, 0), {1, 128 + kTop, 1, kDepth});
    const auto mask = ds::concat(f, ds::filled(f, dense({1, 128}), 0), compressed_mask, 1);
    const auto query = ds::slice(f, tokens[5], 1, t, 1);
    const auto attention = ds::bfloat_boundary(f, f.one(c::model_ops::sink_attention(1.F / std::sqrt(512.F)),
        {query, keys, keys, mask, sink}));
    for (const auto value : state) f.outputs.push_back(copy(f, value));
    ids_rows.push_back(copy(f, ids)); attended_rows.push_back(copy(f, attention));
    ++cursor.position; cursor.fill = (cursor.fill + 1) % 4;
  }
  auto ids = ids_rows[0], attention = attended_rows[0];
  for (int t = 1; t < count; ++t) {
    ids = ds::concat(f, ids, ids_rows[t], 0);
    attention = ds::concat(f, attention, attended_rows[t], 1);
  }
  f.outputs.push_back(copy(f, ids)); f.outputs.push_back(copy(f, attention));
  return f;
}

struct GraphProgram {
  g::CompiledGraph compiled;
  std::vector<g::ValueId> inputs, outputs;
  std::vector<c::TensorDesc> input_desc, output_desc;
  std::vector<c::ReadLease> constants;
};
struct Route {
  c::Context context;
  c::Queue queue;
  c::LeasePool pool;
  Result<c::ReadLease> load(std::span<const std::byte> data) {
    HYLE_ASSIGN_OR_RETURN(auto writer, pool.allocate(data.size()));
    HYLE_RETURN_IF_ERROR(writer.view()->write(data)); return writer.publish();
  }
  template <class T> Result<std::vector<T>> read(const c::ReadLease &value) {
    std::vector<T> result(value.size() / sizeof(T));
    HYLE_RETURN_IF_ERROR(value.view()->read(std::as_writable_bytes(std::span(result)))); return result;
  }
  Result<GraphProgram> prepare(const sem::Fragment &f) {
    HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
    GraphProgram result; std::vector<g::ValueId> values(f.descriptions.size());
    for (const auto id : f.inputs) {
      HYLE_ASSIGN_OR_RETURN(values[id.ordinal()], builder.input(f.description(id)));
      result.inputs.push_back(values[id.ordinal()]); result.input_desc.push_back(f.description(id));
    }
    // Constants are ordinary immutable leased inputs, not private provider data.
    for (std::size_t i = 0; i < f.constants.size(); ++i) {
      const auto id = f.constants[i];
      HYLE_ASSIGN_OR_RETURN(values[id.ordinal()], builder.input(f.description(id)));
      result.inputs.push_back(values[id.ordinal()]); result.input_desc.push_back(f.description(id));
      HYLE_ASSIGN_OR_RETURN(auto value, load(f.constant_bytes[i])); result.constants.push_back(std::move(value));
    }
    for (const auto &node : f.nodes) {
      std::vector<g::ValueId> inputs;
      for (const auto id : node.inputs) inputs.push_back(values[id.ordinal()]);
      HYLE_ASSIGN_OR_RETURN(auto added, builder.add_node(node.operation, inputs));
      for (std::size_t i = 0; i < node.outputs.size(); ++i) {
        HYLE_ASSIGN_OR_RETURN(values[node.outputs[i].ordinal()], builder.result(added, i));
      }
    }
    for (const auto id : f.outputs) {
      HYLE_RETURN_IF_ERROR(builder.publish(values[id.ordinal()]));
      result.outputs.push_back(values[id.ordinal()]); result.output_desc.push_back(f.description(id));
    }
    HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
    HYLE_ASSIGN_OR_RETURN(result.compiled, g::compile(graph, context)); return result;
  }
  Result<std::vector<c::ReadLease>> execute(GraphProgram &program, std::span<const c::ReadLease> data) {
    HYLE_ASSIGN_OR_RETURN(auto slot, g::LeasedInvocation::create(program.compiled.executable));
    std::vector<c::ReadLease> inputs(data.begin(), data.end());
    inputs.insert(inputs.end(), program.constants.begin(), program.constants.end());
    HYLE_RETURN_IF_ERROR(require(inputs.size() == program.inputs.size(), "sparse consumer input count"));
    for (std::size_t i = 0; i < inputs.size(); ++i)
      HYLE_RETURN_IF_ERROR(slot.bind(program.inputs[i], program.input_desc[i], inputs[i]));
    for (std::size_t i = 0; i < program.outputs.size(); ++i) {
      HYLE_ASSIGN_OR_RETURN(auto bytes, program.output_desc[i].required_bytes());
      HYLE_ASSIGN_OR_RETURN(auto writer, pool.allocate(bytes));
      HYLE_RETURN_IF_ERROR(slot.bind(program.outputs[i], program.output_desc[i], std::move(writer)));
    }
    HYLE_ASSIGN_OR_RETURN(auto done, slot.submit(queue)); HYLE_RETURN_IF_ERROR(done.wait());
    std::vector<c::ReadLease> outputs;
    for (const auto id : program.outputs) {
      HYLE_ASSIGN_OR_RETURN(auto value, slot.output(id));
      HYLE_ASSIGN_OR_RETURN(auto lease, value.storage_lease()); outputs.push_back(std::move(lease));
    }
    return outputs;
  }
};

Cursor cursor(int count) { return {kBasePosition + unsigned(count), kTop + unsigned(count / 4), unsigned(count % 4)}; }
double state_max_error = 0, oracle_max_error = 0;
Status close(std::span<const float> a, std::span<const float> b, const char *label,
             float absolute = 8e-5F, float relative = 4e-5F) {
  HYLE_RETURN_IF_ERROR(require(a.size() == b.size(), "sparse consumer comparison extent"));
  double maximum = 0;
  for (std::size_t i = 0; i < a.size(); ++i) {
    if (a[i] == b[i]) continue;
    maximum = std::max(maximum, double(std::abs(a[i] - b[i])));
    if (!std::isfinite(a[i]) || !std::isfinite(b[i]) ||
        std::abs(a[i] - b[i]) > absolute + relative * std::abs(b[i])) {
      std::fprintf(stderr, "%s index=%zu actual=%.9g expected=%.9g\n", label, i, a[i], b[i]);
      return Status::Internal("sparse prefix state or output differs");
    }
  }
  auto &observed = relative == ds::sem::q::kExpertRelativeTolerance ? oracle_max_error : state_max_error;
  observed = std::max(observed, maximum);
  return Status::Ok();
}

Status run() {
  HYLE_ASSIGN_OR_RETURN(auto context, g::cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto pool, c::LeasePool::create(m::system_resource(), 256u << 20,
      {.max_blocks = 2048}));
  Route route{std::move(context), std::move(queue), std::move(pool)};
  const auto descriptions = state_descriptions();
  std::array<std::vector<float>, kStates> initial;
  std::vector<c::ReadLease> base_values;
  for (int s = 0; s < kStates; ++s) {
    initial[s].resize(*descriptions[s].element_count());
    for (std::size_t i = 0; i < initial[s].size(); ++i)
      initial[s][i] = ds::fp8::bfloat(float(int((i * 7 + s * 3) % 29) - 14) / 32);
    if (s == kPastIndex) std::fill(initial[s].begin(), initial[s].end(), -1.F);
    if (s == kCurrentKv || s == kCurrentIndex) std::fill(initial[s].begin(), initial[s].end(), 0.F);
    if (s == kCurrentScore || s == kCurrentIndexScore) std::fill(initial[s].begin(), initial[s].end(), -INFINITY);
    if (s == kIndex) {
      std::fill(initial[s].begin(), initial[s].end(), 0.F);
      for (int r = 0; r < kTop; ++r) initial[s][r * kIndexDepth] = float(r + 1) / 64;
      initial[s] = ds::quant::reference(ds::bfloat_boundary(std::move(initial[s])), true);
    }
    if (s == kCache || s == kRaw) initial[s] = ds::cache_reference(std::move(initial[s]), kDepth, false);
    HYLE_ASSIGN_OR_RETURN(auto value, route.load(std::as_bytes(std::span(initial[s])))); base_values.push_back(std::move(value));
  }
  std::array<std::vector<float>, 8> features;
  const auto token_desc = token_descriptions(kTokens);
  for (int p = 0; p < 8; ++p) {
    features[p].resize(*token_desc[p].element_count());
    for (std::size_t i = 0; i < features[p].size(); ++i)
      features[p][i] = ds::fp8::bfloat(float(int((i * 5 + p * 11) % 31) - 15) / 32);
  }
  std::fill(features[2].begin(), features[2].end(), -1.F);
  std::fill(features[6].begin(), features[6].end(), 0.F);
  std::fill(features[7].begin(), features[7].end(), 1.F);
  for (int t = 0; t < kTokens; ++t)
    for (int h = 0; h < kIndexHeads; ++h)
      features[6][(t * kIndexHeads + h) * kIndexDepth] = t % 2 ? -1.F : 1.F;
  std::array<c::ReadLease, 9> tokens;
  for (int p = 0; p < 8; ++p) { HYLE_ASSIGN_OR_RETURN(tokens[p], route.load(std::as_bytes(std::span(features[p])))); }
  std::vector<std::int32_t> positions(kTokens);
  for (int t = 0; t < kTokens; ++t) positions[t] = (kBasePosition + t) / 4 * 4;
  HYLE_ASSIGN_OR_RETURN(tokens[8], route.load(std::as_bytes(std::span(positions))));
  const auto inputs = [&](const std::vector<c::ReadLease> &state, int first, int count) -> Result<std::vector<c::ReadLease>> {
    auto result = state;
    for (int p = 0; p < 9; ++p) {
      const auto row_bytes = tokens[p].size() / kTokens;
      HYLE_ASSIGN_OR_RETURN(auto selected, tokens[p].subview(first * row_bytes, count * row_bytes)); result.push_back(std::move(selected));
    }
    return result;
  };
  std::vector<c::StateEntrySpec> specs;
  for (const auto &desc : descriptions) specs.push_back({.description = desc});
  specs.push_back({.kind = c::StateEntryKind::kHostMetadata, .metadata_bytes = sizeof(Cursor)});
  HYLE_ASSIGN_OR_RETURN(auto schema, c::StateSchema::create(specs));
  // StateStore charges the complete shared LeasePool root plus its separately
  // owned metadata snapshots, rather than just the visible resource slices.
  HYLE_ASSIGN_OR_RETURN(auto store, c::StateStore::create(schema,
      {.max_versions = 64, .max_drafts = 4, .max_retained_blocks = 1024,
       .max_backing_bytes = (256u << 20) + (64u << 10)}));
  std::array<c::StateEntryId, kStates + 1> ids;
  for (int i = 0; i <= kStates; ++i) { HYLE_ASSIGN_OR_RETURN(ids[i], schema.entry(i)); }
  std::vector<c::StateMember> members;
  for (int i = 0; i < kStates; ++i) members.push_back({ids[i], base_values[i]});
  const auto zero_cursor = cursor(0);
  members.push_back({ids[kStates], {}, std::as_bytes(std::span(&zero_cursor, 1))});
  HYLE_ASSIGN_OR_RETURN(auto base, store.import(members));
  const auto publish = [&](const c::StateVersion &from, std::span<const c::ReadLease> values, int accepted) -> Result<c::StateVersion> {
    HYLE_ASSIGN_OR_RETURN(auto draft, store.begin(from));
    for (int i = 0; i < kStates; ++i) HYLE_RETURN_IF_ERROR(draft.replace(ids[i], values[i]));
    const auto position = cursor(accepted);
    HYLE_RETURN_IF_ERROR(draft.replace_metadata(ids[kStates], std::as_bytes(std::span(&position, 1)))); return draft.finalize();
  };
  const auto state = [&](const c::StateVersion &version) -> Result<std::vector<c::ReadLease>> {
    std::vector<c::ReadLease> values;
    for (int i = 0; i < kStates; ++i) { HYLE_ASSIGN_OR_RETURN(auto value, version.member(ids[i])); values.push_back(std::move(value)); }
    return values;
  };
  std::printf("CPU sparse: preparing public Graph verify8 and 9 continuation graphs\n"); std::fflush(stdout);
  HYLE_ASSIGN_OR_RETURN(auto block, route.prepare(make_fragment(8, cursor(0))));
  std::vector<GraphProgram> single;
  for (int t = 0; t < kTokens; ++t) { HYLE_ASSIGN_OR_RETURN(auto program, route.prepare(make_fragment(1, cursor(t)))); single.push_back(std::move(program)); }
  HYLE_ASSIGN_OR_RETURN(auto block_inputs, inputs(base_values, 0, 8));
  HYLE_ASSIGN_OR_RETURN(auto verified, route.execute(block, block_inputs));
  std::vector<c::StateVersion> prefixes{base};
  for (int t = 0; t < 8; ++t) {
    HYLE_ASSIGN_OR_RETURN(auto value, publish(base, std::span(verified).subspan(t * kStates, kStates), t + 1)); prefixes.push_back(std::move(value));
  }
  HYLE_ASSIGN_OR_RETURN(auto block_ids, route.read<std::int32_t>(verified[8 * kStates]));
  std::set<std::vector<std::int32_t>> distinct;
  for (int t = 0; t < 8; ++t) {
    std::vector<std::int32_t> row(block_ids.begin() + t * kTop, block_ids.begin() + (t + 1) * kTop);
    std::sort(row.begin(), row.end());
    HYLE_RETURN_IF_ERROR(require(std::adjacent_find(row.begin(), row.end()) == row.end() && row.front() >= 0 && row.back() < int(cursor(t + 1).visible), "TopK duplicate/future index"));
    distinct.insert(std::move(row));
  }
  HYLE_RETURN_IF_ERROR(require(distinct.size() > 1, "queries did not select distinct TopK sets"));
  HYLE_ASSIGN_OR_RETURN(auto block_attention, route.read<float>(verified[8 * kStates + 1]));
  std::vector<float> sink_values(kHeads), zero_mask(128 + kTop);
  for (int h = 0; h < kHeads; ++h) sink_values[h] = .75F + float(h % 11) / 16;
  for (int t = 0; t < 8; ++t) {
    HYLE_ASSIGN_OR_RETURN(auto cache, route.read<float>(verified[t * kStates + kCache]));
    std::vector<float> raw(initial[kRaw]);
    raw.insert(raw.end(), features[4].begin(), features[4].begin() + (t + 1) * kDepth);
    std::vector<float> keys(raw.end() - 128 * kDepth, raw.end());
    for (int k = 0; k < kTop; ++k) {
      const auto row = block_ids[t * kTop + k];
      keys.insert(keys.end(), cache.begin() + row * kDepth, cache.begin() + (row + 1) * kDepth);
    }
    const auto query = std::span(features[5]).subspan(t * kHeads * kDepth, kHeads * kDepth);
    const auto expected = ds::bfloat_boundary(ds::old::sink_reference(query, keys, keys,
        zero_mask, sink_values, 1, 128 + kTop, 1.F / std::sqrt(512.F)));
    HYLE_RETURN_IF_ERROR(close(std::span(block_attention).subspan(t * kHeads * kDepth,
        kHeads * kDepth), expected, "independent FP64 Sink",
        ds::sem::q::kExpertAbsoluteTolerance, ds::sem::q::kExpertRelativeTolerance));
  }
  std::printf("CPU sparse: verify8 PASS, distinct TopK sets=%zu\n", distinct.size()); std::fflush(stdout);
  for (int accepted = 0; accepted <= 8; ++accepted) {
    auto reference = base;
    std::vector<c::ReadLease> reference_output;
    for (int t = 0; t < accepted; ++t) {
      HYLE_ASSIGN_OR_RETURN(auto before, state(reference)); HYLE_ASSIGN_OR_RETURN(auto args, inputs(before, t, 1));
      HYLE_ASSIGN_OR_RETURN(auto output, route.execute(single[t], args));
      HYLE_ASSIGN_OR_RETURN(reference, publish(reference, output, t + 1));
      reference_output = std::move(output);
    }
    if (accepted) {
      HYLE_ASSIGN_OR_RETURN(auto actual_ids, route.read<std::int32_t>(reference_output[kStates]));
      HYLE_RETURN_IF_ERROR(require(std::equal(actual_ids.begin(), actual_ids.end(),
          block_ids.begin() + (accepted - 1) * kTop), "block/reference per-query IDs differ"));
      HYLE_ASSIGN_OR_RETURN(auto actual_attention, route.read<float>(reference_output[kStates + 1]));
      HYLE_RETURN_IF_ERROR(close(actual_attention, std::span(block_attention).subspan(
          (accepted - 1) * kHeads * kDepth, kHeads * kDepth), "block/reference per-query Sink"));
    }
    for (int s = 0; s <= kStates; ++s) {
      HYLE_ASSIGN_OR_RETURN(auto a, prefixes[accepted].member(ids[s])); HYLE_ASSIGN_OR_RETURN(auto b, reference.member(ids[s]));
      if (s == kStates) {
        HYLE_ASSIGN_OR_RETURN(auto x, route.read<std::uint32_t>(a)); HYLE_ASSIGN_OR_RETURN(auto y, route.read<std::uint32_t>(b));
        HYLE_RETURN_IF_ERROR(require(x == y, "accepted cursor differs"));
      } else {
        HYLE_ASSIGN_OR_RETURN(auto x, route.read<float>(a)); HYLE_ASSIGN_OR_RETURN(auto y, route.read<float>(b)); HYLE_RETURN_IF_ERROR(close(x, y, "accepted state"));
      }
    }
    std::array<std::vector<c::ReadLease>, 2> continued;
    int arm = 0;
    for (const auto &version : {prefixes[accepted], reference}) {
      HYLE_ASSIGN_OR_RETURN(auto before, state(version)); HYLE_ASSIGN_OR_RETURN(auto args, inputs(before, accepted, 1));
      HYLE_ASSIGN_OR_RETURN(continued[arm], route.execute(single[accepted], args)); ++arm;
    }
    HYLE_ASSIGN_OR_RETURN(auto committed, publish(prefixes[accepted], continued[0], accepted + 1));
    HYLE_ASSIGN_OR_RETURN(auto reference_committed, publish(reference, continued[1], accepted + 1));
    for (int s = 0; s <= kStates; ++s) {
      HYLE_ASSIGN_OR_RETURN(auto x, committed.member(ids[s]));
      HYLE_ASSIGN_OR_RETURN(auto y, reference_committed.member(ids[s]));
      HYLE_ASSIGN_OR_RETURN(auto a, route.read<std::byte>(x));
      HYLE_ASSIGN_OR_RETURN(auto b, route.read<std::byte>(y));
      HYLE_RETURN_IF_ERROR(require(a == b, "committed continued resource/metadata differs"));
    }
    for (int s = 0; s < kStates + 2; ++s) {
      if (s == kStates) {
        HYLE_ASSIGN_OR_RETURN(auto x, route.read<std::int32_t>(continued[0][s])); HYLE_ASSIGN_OR_RETURN(auto y, route.read<std::int32_t>(continued[1][s]));
        HYLE_RETURN_IF_ERROR(require(x == y, "continued TopK IDs differ"));
      } else {
        HYLE_ASSIGN_OR_RETURN(auto x, route.read<float>(continued[0][s])); HYLE_ASSIGN_OR_RETURN(auto y, route.read<float>(continued[1][s])); HYLE_RETURN_IF_ERROR(close(x, y, "continued state/attention"));
      }
    }
    std::printf("CPU sparse accept=%d full state/IDs/Sink continuation PASS\n", accepted); std::fflush(stdout);
    HYLE_RETURN_IF_ERROR(store.collect());
  }
  for (int s = 0; s < kStates; ++s) {
    HYLE_ASSIGN_OR_RETURN(auto value, base.member(ids[s])); HYLE_ASSIGN_OR_RETURN(auto actual, route.read<float>(value)); HYLE_RETURN_IF_ERROR(close(actual, initial[s], "base preserved"));
  }
  std::printf("CPU sparse numeric: paired state/Sink maxAbs=%.9g; independent FP64 Sink+BF16 boundary maxAbs=%.9g\n",
              state_max_error, oracle_max_error);
  std::printf("CPU sparse/index/compressor: ratio4, H64 D512 index64x128 Top512, accept0..8 across two completions PASS; projected-boundary dense composition only\n");
  return Status::Ok();
}
} // namespace
int main() {
  try {
    const auto status = run();
    if (status.ok()) return 0;
    char message[1024]{}; status.ToString(message, sizeof(message)); std::fprintf(stderr, "%s\n", message);
  } catch (const std::exception &error) { std::fprintf(stderr, "%s\n", error.what()); }
  return 1;
}
