#pragma once

#include "hyle/graph/execution_source.h"
#include "hyle/compute/vulkan.h"

namespace hyle::graph::vulkan::detail {
// Exact-source evidence only. These are uninitialized native output owners,
// not ready ReadLeases and not an alternate Program/Invocation.
HYLE_GRAPH_ROUTE_VULKAN_API Result<compute::vulkan::Tensor> output_backing(
    const ExecutionSource &, compute::vulkan::Invocation &, std::size_t) noexcept;
HYLE_GRAPH_ROUTE_VULKAN_API Status seal_outputs(
    const ExecutionSource &, compute::vulkan::Invocation &) noexcept;
} // namespace hyle::graph::vulkan::detail
