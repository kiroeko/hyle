#include "hyle/graph/vulkan.h"
#include "vulkan_source.h"

#include "../graph/execution_source_internal.h"
#include "../compute_route_vulkan/vulkan_composition_access.h"
#include "../compute_route_vulkan/vulkan_memory_internal.h"
#include "../compute_route_vulkan/vulkan_program_internal.h"

#include <mutex>
#include <utility>

namespace hyle::graph::vulkan {
namespace cv = compute::vulkan;
namespace gd = graph::detail;
namespace {
// This is a real Vulkan endpoint identity, not a Compute Backend factory.
constexpr compute::BackendId vulkan_backend{0x48594c4500000001ULL, 0x56554c4b00000001ULL};
extern const gd::ExecutionSourceVTable source_table;
struct VulkanSource final : gd::ExecutionSourceState {
  VulkanSource(std::shared_ptr<cv::detail::Runtime> retained, mem::AllocatorRef allocator) noexcept
      : ExecutionSourceState(&source_table, allocator, retained.get()), runtime(std::move(retained)) {}
  std::shared_ptr<cv::detail::Runtime> runtime;
};
const VulkanSource &native(const gd::ExecutionSourceState &state) noexcept {
  return static_cast<const VulkanSource &>(state);
}
Status admission(const VulkanSource &state) noexcept {
  std::lock_guard lock(state.runtime->mutex);
  if (state.runtime->closed)
    return Status::FailedPrecondition("Vulkan execution source is closed");
  return state.runtime->failure;
}
const gd::ExecutionSourceVTable source_table{
    [](gd::ExecutionSourceState *state) noexcept {
      const auto allocator = state->allocator;
      allocator.destroy(static_cast<VulkanSource *>(state));
    },
    [](const gd::ExecutionSourceState &state) noexcept { return admission(native(state)).ok(); },
    [](const gd::ExecutionSourceState &a, const gd::ExecutionSourceState &b) noexcept {
      return native(a).runtime->device == native(b).runtime->device;
    },
    [](const gd::ExecutionSourceState &) noexcept { return vulkan_backend; },
    [](const gd::ExecutionSourceState &state) noexcept {
      return native(state).runtime->device->properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_CPU
          ? compute::DeviceClass::kCpu : compute::DeviceClass::kGpu;
    },
    [](const gd::ExecutionSourceState &state) noexcept -> Result<compute::DeviceProperties> {
      const auto &device = *native(state).runtime->device;
      return compute::DeviceProperties{.backend=vulkan_backend,
          .device_class=device.properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_CPU
              ? compute::DeviceClass::kCpu : compute::DeviceClass::kGpu,.backend_name="Vulkan",
          .name=device.environment.device_name,.unified_memory=false,.asynchronous_queues=true};
    },
    [](const gd::ExecutionSourceState &state, mem::MemoryResourceRef resource) noexcept {
      return cv::detail::MemoryAccess::validate_resource(native(state).runtime, resource);
    },
    [](const gd::ExecutionSourceState &state, gd::SourceCall function, void *opaque) noexcept -> Status {
      HYLE_RETURN_IF_ERROR(admission(native(state)));
      // Never hold Runtime::mutex across native calls: prepare/bind/submit
      // enter its original lock themselves. The retained actual Runtime keeps
      // admission races safe; final native acceptance still checks closed.
      return function(opaque);
    },
    nullptr,
    [](const gd::ExecutionSourceState &state) noexcept -> void * { return native(state).runtime.get(); }};

Result<const VulkanSource *> checked_source(const ExecutionSource &source) noexcept {
  const auto *state = gd::ExecutionSourceAccess::state(source);
  if (!state || state->table != &source_table)
    return std::unexpected(Status::InvalidArgument("source is not this actual Vulkan endpoint"));
  return &native(*state);
}
Status matches(const ExecutionSource &source, const cv::Invocation &invocation) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto state, checked_source(source));
  const auto &slot = cv::detail::Access::invocation_state(invocation);
  if (!slot || slot->program->runtime != state->runtime)
    return Status::InvalidArgument("Vulkan invocation belongs to another actual source");
  return Status::Ok();
}
} // namespace

Result<ExecutionSource> execution_source(const cv::Context &context, mem::AllocatorRef allocator) noexcept {
  if (!context.valid() || !allocator.valid())
    return std::unexpected(Status::InvalidArgument("Vulkan execution source requires a Context and allocator"));
  const auto &runtime = cv::detail::Access::runtime(context);
  {
    std::lock_guard lock(runtime->mutex);
    if (runtime->closed)
      return std::unexpected(Status::FailedPrecondition("Vulkan execution source is closed"));
    HYLE_RETURN_IF_ERROR(runtime->failure);
  }
  auto *state = allocator.construct<VulkanSource>(runtime, allocator);
  if (!state)
    return std::unexpected(Status::ResourceExhausted("Vulkan execution source metadata"));
  return gd::ExecutionSourceAccess::adopt(state);
}
namespace detail {
Result<cv::Tensor> output_backing(const ExecutionSource &source, cv::Invocation &invocation,
                                  std::size_t index) noexcept {
  HYLE_RETURN_IF_ERROR(matches(source, invocation));
  return cv::detail::CompositionAccess::output(invocation, index);
}
Status seal_outputs(const ExecutionSource &source, cv::Invocation &invocation) noexcept {
  HYLE_RETURN_IF_ERROR(matches(source, invocation));
  return cv::detail::CompositionAccess::seal(invocation);
}
} // namespace detail
} // namespace hyle::graph::vulkan
