#pragma once

#include "hyle/graph/detail/execution_source.h"
#include "hyle/compute/detail/context_ref.h"
#include "hyle/compute/detail/provider_extension.h"
#include "hyle/util/ref_counted.h"

namespace hyle::graph::detail {
using SourceCall = Status (*)(void *) noexcept;
struct ExecutionSourceState;
struct ExecutionSourceVTable final {
  void (*destroy)(ExecutionSourceState *) noexcept;
  bool (*is_open)(const ExecutionSourceState &) noexcept;
  bool (*same_device)(const ExecutionSourceState &, const ExecutionSourceState &) noexcept;
  compute::BackendId (*backend_id)(const ExecutionSourceState &) noexcept;
  compute::DeviceClass (*device_class)(const ExecutionSourceState &) noexcept;
  Result<compute::DeviceProperties> (*device_properties)(const ExecutionSourceState &) noexcept;
  Status (*validate_resource)(const ExecutionSourceState &, mem::MemoryResourceRef) noexcept;
  Status (*call)(const ExecutionSourceState &, SourceCall, void *) noexcept;
  const compute::detail::ContextRef *(*compute)(const ExecutionSourceState &) noexcept;
  // Actual native Runtime, never a temporary Context or a public raw handle.
  void *(*native_context)(const ExecutionSourceState &) noexcept;
};
struct ExecutionSourceState : util::RefCounted<ExecutionSourceState> {
  ExecutionSourceState(const ExecutionSourceVTable *table_value,
      mem::AllocatorRef allocator_value, const void *identity_value) noexcept
      : table(table_value), allocator(allocator_value), identity(identity_value) {}
  void destroy() noexcept { table->destroy(this); }
  const ExecutionSourceVTable *table;
  mem::AllocatorRef allocator;
  const void *identity;
};

struct ExecutionSourceAccess final {
  static ExecutionSource adopt(ExecutionSourceState *state) noexcept { return ExecutionSource(state); }
  static ExecutionSourceState *state(const ExecutionSource &source) noexcept { return source.state_; }
  static const void *identity_key(const ExecutionSource &source) noexcept {
    return source.state_ ? source.state_->identity : nullptr;
  }
  HYLE_GRAPH_API static Result<const compute::detail::ContextRef *>
  compute(const ExecutionSource &) noexcept;
  HYLE_GRAPH_API static bool owns(const ExecutionSource &, const compute::Queue &) noexcept;
  HYLE_GRAPH_API static bool owns(const ExecutionSource &,
      const compute::detail::ProviderExtensionRef &) noexcept;
  HYLE_GRAPH_API static Status call(const ExecutionSource &, SourceCall, void *) noexcept;
  HYLE_GRAPH_API static Result<void *> native_context(const ExecutionSource &) noexcept;
};

} // namespace hyle::graph::detail
