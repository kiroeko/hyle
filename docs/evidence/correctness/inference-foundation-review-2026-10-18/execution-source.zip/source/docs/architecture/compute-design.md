# Compute：计算语义、实现选择与资源边界

Compute 为 Direct 调用和 Graph 编译提供共同计算合同，保留 CPU、CUDA、Apple 与 Vulkan 的原生执行方式。
它不依赖 Graph，也不解释模型文件、生成策略或 serving。用法与限制见[用户 Compute 指南](../user/compute.md)。

## 语义与执行分开

公共语义描述 operation、全部端口的 dtype/encoding/shape/layout、alias、状态、副作用和资源要求。
Provider 把这个合同绑定成原生调用、完整 region 或原生扩展。设备能分配内存不表示某个 Provider
能计算任意格式；库名称也不能代替实际算子能力。

Direct 用户无需取得图编译器。Graph 在相同语义上组合片段、决定跨片段边界和资源计划，
Provider 继续拥有片段内部的融合、packing 和执行。避免把成熟 region 拆成逐 kernel 的虚调用链，
也避免为统一外观复制一套线程池、队列或 allocator。

## Provider 与资源所有权

接入有三种形状：直接调用原生 primitive；将 op/region 编译为 Provider 自有程序；
在 Provider 明确支持的扩展点内加入原生 kernel。三者可以共存，选择依据是完整计算的成本和能力。

Provider 自有 allocator、tensor、stream、workspace 或 capture 时，HYLE 保留这个执行岛：
边界完成合法 import 或显式 copy/repack，内部使用原生程序，输出由真实 owner 保活。
结果不必复制进 HYLE 影子 buffer；也不能修改第三方内部字段或伪造 buffer 来宣称零复制。

caller-owned storage 只通过实际支持的 typed interop 接入，核对 device、范围、编码、coherence、
borrow/ownership 和完成边界。CPU external pointer 可用，不能推出 CUDA、MLX 或 Vulkan 同样可用；
同一 GPU 上的不同 runtime 也不会自动共享 allocator 或 stream。

对 ggml，合法适配保有 tensor metadata、backend、常量和 invocation state，用原生 graph compute
执行已准备的单 op 或完整 region。其内部仍可能编码、分配或同步，应报告真实成本。
旧桥接中“简单节点成功而 varied-shape 图因伪造 buffer 崩溃”的教训是保留公开 import/allocate 边界，
而不是恢复旧 adapter 或把私有 kernel 函数当稳定接口。

## 冷路由

普通用户只选择可用设备和实际请求，不排列 Provider、不填写 timing profile。
实现规则由库维护，在 Context 创建和 prepare/compile 时匹配；submit 只调用已经绑定的制品。

匹配依赖三类只读事实：

| 事实 | 归属与作用 |
|---|---|
| `RouteEnvironment` | Context 捕获的 OS/ABI、设备、ISA/SM、features/limits、driver/runtime/SDK 与 Provider 身份 |
| workload / `ModelArtifactProfile` | 引擎已核对的模型/制品 revision、配置/manifest digest、phase 和 region 意图；不包含权重或 parser |
| `RouteSubject` | 本次 operation 全部端口，或真实 Graph region、canonical boundary、state/effects 与资源约束 |

模型画像可为空，普通调用仍能使用合法的通用基线。画像、字符串和 digest 由冷 owner 保活，
不借用调用栈；模型名或文件名不能代替真实端口检查。未知事实与明确的零值不同，
规则要求的事实缺失时不命中。region 意图不能替代 Provider 对真实 DAG 的检查。

选择先排除未交付或不满足语义、资源与设备条件的实现，再应用固定规则；Graph 还考虑完整计划的
覆盖、融合、搬运、等待和 workspace。稳定 Provider/implementation identity 用于诊断和缓存，
注册顺序、数组顺序和“规则更具体”均不代表更快。同优先级的冲突须明确处理，不能随机挑选。

只在接纳前、无副作用的能力或预算拒绝时，才可尝试预先声明的合法后备。创建制品或接纳工作后的
真实错误不吞掉、不换设备重算。匹配不到性能规则可使用合法成熟基线，不能把它称为测量赢家。

## 制品与执行状态

不可变代码、权重和 packing 可以共享；bindings、scratch、descriptor/command pool、可变库状态
及输出按原生并发要求独占或池化。同一槽未到真实终态，不得重绑、覆盖输出或回收其资源。
共同Operation/Graph invocation接纳后若失败，终态意味着该槽退休，需要重建槽；
不是错误一返回就可重试。接纳前拒绝可按合同修正输入再试，重建槽也不能修复device loss。

数值/物理格式、shape domain、所读环境事实、Provider/policy版本或相关常量身份改变后需要重新准备。
普通 payload、token值和域内实际尺寸仍是输入。跨制品 cache由消费者明确拥有，不使用裸地址、
仅模型名或进程全局隐式 cache 代替完整 identity，也不承诺跨编译器持久化。

普通prepared成功准备后的replay不再做shape推导、heap分配、JIT、tactic搜索或packing。
managed可承担已声明的metadata/array及cache/shape工作，不因此允许JIT/search/repack或隐藏copy/sync。
需要native planning的批次走独立layout准备，见下文。prepared/managed、capture与是否阻塞是不同轴，
不能以同一个“graph replay”名称掩盖不同成本。

## 存储、同步与生命周期

Mem 提供 allocation、mapping、view、quota 和寿命原语；Compute 解释 native resource及异步使用；
Graph 提供依赖和 liveness/alias事实。host metadata、payload、第三方 heap和driver内存各自计账，
未知私有内存不能记成零。释放使用原 owner、size和alignment。

CPU happens-before、CUDA event、Metal hazard/fence/event和Vulkan execution/memory dependency
保留各自语义。unified/shared内存不消除同步；必要的 host wait应显式报告。
只用于 host编码的临时数据可以按合同提前释放，设备仍引用的数据、参数和代码必须活到真实终态。

部分接纳后保留已提交前缀；事件记录失败不表示没有接纳GPU工作。取消停止后续工作，不等于抢占
既有kernel。停止接纳与显式drain分开，具体close是否等待服从该owner的API；共同Context的close只停止接纳。
未知完成状态不得变成可回收状态，
不能靠析构隐藏无界等待。资源权限和流送还需要下述约束。


## 资源权限与有界流送

只读租约可共享，独占写权限要求相应范围没有读者或在途使用。alias按物理范围而非wrapper地址判断；
成功写入后才发布ready只读内容。Direct/Graph绑定同时保有payload、索引/参数metadata、producer与native owner，
直到真实最后使用。引用归零与GPU退休是两个条件，不满足任一条件都不能回池。

一个重要反例是“事件记录失败”：前面的kernel可能已经接纳，错误返回不能触发正常释放。
资源必须留在仍能推进退休的owner中；若完成状态未知，不能凭Status非OK判断它已经结束。
这种保活也不能形成失败suffix永远持有producer的引用环。

批量byte copy冷准备固定域、范围/groups/slots与bytes上限。独立copy可重复读取source，
不能隐含destination重叠或批内依赖；有依赖时用明确阶段。全批预检后仍可能部分接纳，
需保留实际prefix与所有可能被引用的控制数据。copy保持物理bytes，不替代编码转换。

文件流送只处理已有File/Mapping范围与resource范围：

```text
文件 → 有界staging → native copy → group ready → 计算使用 → 回收
producer完成 → read lease → D2H/共享可见 → positional write → 完成
```

旧ready/use leases继续占slots和预算，容量满产生背压，不自动淘汰用户内容。
已成功组可消费，后面失败不把整批写成成功。direct IO、short progress及不能被逐操作抢占的文件fallback
沿原IO合同；取消不等于中断pread/pwrite。格式解析、文件命名、原子发布政策与模型cache属于引擎/IO。

## 集合发布不是多设备事务

状态schema声明有限opaque成员和资源约束；只读版本共享owner而不复制payload。
draft分享未改成员，显式clone将修改的成员，或替换为成功的out-of-place输出。不能修改base，
也不能把外部仍可写的native alias称为immutable。

```text
base → draft共享/显式clone → 新输出全部ready → expected-base检查 → 发布新只读版本
 └──────────────── 旧读者与native uses继续保活 ─────────────────┘
```

发布仅改变集合可见性，不回滚已发生的外部device写，也不表示文件已持久化。
冲突不改变current，不能按branch完成顺序自动选赢家；token绑定store、schema与generation避免ABA。
旧版本、draft、目录和copy槽有容量上限，clone按dirty bytes计费，不隐式复制整模型。
停止新更新/发布后，按本store合同显式退休自己的工作，不关闭用户Context。

这可承载推理分支，但checkpoint语义、接受前缀、RNG/token和模型策略归引擎。
recurrent算子有initial/final输出，不自动证明任意中间前缀可恢复。

## 分页计算为何需要独立准备尺度

Paged/ragged attention保持typed数学schema，不将单storage Tensor改成含混分页对象。
paged描述arena、page IDs、indptr、tail与真实active counts，ragged描述packed segments；
metadata、device mirror、plan与payload必须有相符generation和owner。
接纳前校验单调、边界、dtype/layout、overflow/GQA、空序列及causal相对位置，padding不能作为真实KV。

| 时机 | 工作与边界 |
|---|---|
| program准备 | 固定算法域、dtype/head/layout、capacity、workspace和slots，绑定实现 |
| layout准备 | 复制/验证host快照、native planning、metadata上传及必要host等待，产生本slot/generation的token |
| native提交 | 执行已准备批次，不再读取可变caller span、搜索Provider或隐藏新planning |

原生planner可能分配临时vectors或查询occupancy，这些是layout准备成本，不是无规划replay。
多个并发槽各有mutable plan/workspace；布局或失败退休改变后旧token失效。
只改page IDs能否复用计划取决于原生算法，不能按地址/尺寸猜测；固定batch和稳定地址也不足以保证capture。

Graph协调同slot的region与prepared token，不能在外部规划A后提交B。
只读attention不制造effect，KV append/scatter等真实写入才需要writer与顺序。
把paged数据gather为连续临时再执行dense数学可以是明确参考路线，但必须计copy/capacity/workspace，
不能把它当原生paged kernel。各后端的dtype/head域与capture能力仍按实际实现说明。

## 推理执行体系的重构形状

2026-10-18 的接线审查暴露了三处结构问题：同一 backend 的承载判定分散在 Direct、Graph lowering
和冷占位路径；共同 Graph 直接识别具体 row-cache 算子和 ProviderId；Apple/Vulkan/混合路线重复维护
计划、值与执行槽。共同 prepared 输出合同又只接受 caller buffer，不能直接承载真实的 MLX/Vulkan
生成结果。单独补白名单无法解决整条推理链的衔接和性能问题。

本节是本次全量重构的目标形状，**尚不代表已实现**。以现有 PreparedOperation、Executable、Invocation、
Completion、ResultLease、资源租约、StateStore 和 SubmissionCursor 为基础迁移；统一它们之间的合同，
保留成熟原生程序与执行岛，不另建一套执行器。

共同 Queue 路线的资源租约、只读结果和完成观察现已收进原 `InvocationState`，不再由
`LeasedInvocation` 持有第二个槽。typed batch/page 只附着布局、frame 与 source controls，
使用同一提交游标和实际退休；被替代的 batch provider/coordinator 公共入口直接删除。
这部分迁移不代表原生生成结果、各混合运行时和剩余模型功能已经统一或补完。

### 完整调用链与职责

```mermaid
flowchart TD
    M[引擎：模型语义、权重角色与推理策略] --> G[语义图：端口、shape、编码、effects、状态边界]
    E[可用端点、放置与精度政策、资源预算] --> C[冷编译：承载分析、融合、桥接、依赖与资源计划]
    G --> C
    C --> P[Executable：不可变计划与原生制品]
    P --> I[Invocation：独立执行槽与结果代际]
    L[实际绑定、请求布局、页权限、状态版本] --> B[prepare / bind / layout 更新]
    I --> B
    B --> S[严格 submit：接纳并推进固定片段]
    S --> R[Completion：成功结果发布或失败退休]
    R --> N[下一次续算 / decode / 状态分支]
    N --> L
```

| 职责 | 唯一归属与复用边界 |
|---|---|
| 模型与语义 | 引擎生成数学图，知道 attention/GDN/MoE 等模型语义；schema 描述端口、encoding、shape、alias 和 effects，不选择 Provider |
| 原生承载 | 同一 backend 的 carrier 分析、准备与绑定事实供 Direct 和 Graph 共用；Graph 另外判断拓扑覆盖、融合与副作用，不能把单 op 支持当成任意 region 支持 |
| 不可变计划 | 一份逻辑值到物理表示的映射、粗粒度片段、显式桥接、依赖、生命周期和预算；CPU/GPU/混合不再各复制一份中间 DAG |
| 独立执行槽 | Invocation 持有本槽 bindings、native plan、workspace、metadata、结果槽和在途完成状态；不可变权重与制品共享，可变资源遵守原生并发要求 |
| 页与状态组合 | batch/state 模块证明逻辑 schema、版本、footprint 与发布条件；共同 Graph 检查限定端口、物理依赖、alias、权限和寿命 |
| 后端适配 | 保留真实 Queue/Program、原生值 owner、依赖导入及进度机制；按粗粒度片段调用，不新增逐 kernel 重型分派 |

普通引擎的执行中间层只处理图入口、绑定、状态、结果与完成，不判断 CUDA/Metal/Vulkan 算子或 ProviderId。
设备放置、精度与预算仍是引擎政策；平台初始化集中在端点装配。Direct 继续可以独立于 Graph 使用，
原生 SDK 的能力由后端适配代码承载，不要求普通消费者学习全部原生 API 或内部 CMake 宏；
不能以 expert 入口为由保留已被替换的 Hyle 公共接口。

### 一个请求到底怎样推理

以 KV 容量固定为 32 的文本请求为例：首次输入 23 个 token，随后续算 4 个 token，再逐 token decode。
这是调用流程约束；当前平台入口、batch wrapper 和原生结果合同仍在迁移，不能将下表当成已经交付的新 API。

| 步骤 | 引擎提供的语义与数据 | Hyle 完成的工作 |
|---|---|---|
| 模型准备 | 解析权重、配置和 tokenizer；描述各层数学及权重角色 | 接纳真实常量和资源 owner；可复用的代码、权重表示和 packing 由明确 owner 共享，避免各 phase 重复持有同一制品 |
| 构图 | 用数学节点表达 embedding、attention、conv/GDN、FFN 等；声明 KV/state 输入、输出和布局语义 | 校验数学、端口和状态依赖；模型有意义的 reshape/permute 保留语义，物理转置/Cast 由实际承载和桥接计划决定 |
| 冷编译 | 可用端点，精度、放置和预算政策；prefill/续算/decode 的 shape 域或有限入口 | 发现实际实现，选择融合片段，确定显式转换/搬运、依赖、常量和资源复用，得到不可变 Executable；每个入口不另造执行体系 |
| 请求准备 | 本请求的 token、绝对位置、KV/state 版本，以及本次不可变 batch/page layout | 选已准备入口，绑定独立 Invocation；更新必要 native plan、metadata/权限与准备版本。布局准备成功后才允许本次提交 |
| prefill | 23 个 token，位置 0…22，旧状态为空，实际 KV 长度 23 | 按固定计划执行整条图，写入新 KV，产生 conv/GDN 新状态与 logits；设备结果保持原生 owner，依赖按实际端点推进 |
| 续算 | 4 个新 token，位置 23…26，直接绑定上轮真实状态与 KV，有效长度 27 | 复用代码与驻留权重，只处理新 token、写新增 KV 行，反馈下一版状态；不重新展开前 23 个 token |
| decode | 一个新 token，位置 27，有效长度 28 | 选择已准备的 T=1 入口，之后每轮复用它；更新输入与实际需要变化的布局，不随历史长度增长重新搜索 Provider |
| 完成与反馈 | 读取 logits、选择下一 token 或结束请求；token/采样政策仍归引擎 | 成功后按状态版本合同发布结果；旧读者、在途资源和失败前已接纳工作保活到真实退休，空闲槽才能重绑/复用 |

KV 的容量与有效长度分别表达。例如 packed/ragged attention 的 Q/K/V 描述保留容量，owned layout 给出
`q_indptr={0,T}`、`kv_indptr={0,L}`；原生 causal 语义使用实际 `L` 而不是容量 32。
23→4→1 三次调用分别使用 `(T,L)=(23,23)、(4,27)、(1,28)`，因此每个 query 的可见范围正确接续。
分页场景同样使用真实 page IDs、generation 与权限。布局可以共享未变的 native planning，但更新本身须显式接纳。

这类有效长度是引擎已知的语义，应作为 typed layout 进入同一图/槽。编译器不从任意 F32 mask 的内容猜测它，
也不强迫引擎为每层再手动装配 batch Provider 或另一套协调器。一般 additive/Boolean mask 仍按其自身数学合同
检查真实承载；长度语义不等于支持任意 mask。这正是测试消费者当前暴露、仍待迁移的接缝。

整个过程保持“一份准备好的计划＋每请求独立可变槽”：不同请求共享不可变权重/代码，KV、conv/GDN state、
workspace 与 native plan 按请求/槽隔离。纯 CPU、单 GPU、CPU＋GPU 采用相同生命周期；混合计划的设备边界及
必要搬运在冷阶段确定，单 GPU 图不强制搭建 CPU 数学路线。原生句柄尚未可用时由既有依赖前沿继续推进，
引擎不插入逐层平台判断、逐算子 host wait 或隐式全历史重算。

### 路由来自能力分析，选择结果冷生成

支持能力由语义和实现自然产生，额外的模型、算子、Provider 接入白名单应移除。选定模型集合用于发现实际负载
和核对覆盖，不是运行时准入条件。路由采用下列分工，复用现有 propose/prepare，而不另建注册语言：

| 层 | 表达的事实 |
|---|---|
| 算子 schema | 计算什么、全部端口与编码、shape 域、alias/effects；不自称某设备最快，也不选择 Provider |
| 后端承载分析 | 根据真实输入和环境提出单 op 或融合 region，声明支持域、输入/输出表示、资源、同步与原生准备要求；与实际 lowering/prepare 共用实现事实 |
| 冷编译器 | 在满足精度、放置、权限和预算的候选中，组合整图的覆盖、桥接、依赖与生命周期，决定最终制品 |
| 性能偏好 | 少量有实测或明确算法依据的偏好数据，只调整合法候选顺序；不授予能力、不绕过端口检查，也不因未知模型而拒绝通用实现 |
| 已编译计划 | 持有固定片段入口、端口表和依赖；执行槽按计划调用，不在每次 submit 查询支持表 |

实现内部用于找到实际 handler 的分派可保留；不再于 Graph/Context/资源核心复制另一张支持名单。
Direct 是同一承载分析的单节点消费者；Graph 还比较较大片段的整体成本，不能按单 op 优先级拆毁成熟融合。
准备成功之后的资源访问事实绑定 exact prepared 与实例，不由模型名或数学算子名称推导。

已有独立原生规划能力时，冷装配可把原 Context 的真实 capability 接入同一个 region 编译协议；
不伪造 Provider、不另建 Context，也不遮蔽原有融合候选。编译借用的适配配置不会进入热提交；
选定制品保有真实源 owner，执行槽用拥有身份的 layout 冷准备，随后走原 Queue、Completion 与结果寿命。

执行目标改为持有 `ExecutionSource`，不再保存可移动的公开 Context 指针。Compute 源保有原 Context 的
内部引用；原生源保有实际 Runtime。源只提供身份、资源检查与接纳，不另造设备、Provider、Queue 或调度器。
共享 region 仍绑定实际 Provider 实例；原生 region 没有 Compute provider slot，不能满足要求特定 Provider 的约束。
常量 packing 同时按实际源 owner 和实现身份隔离；共享 Queue 的热提交仍直接调用已选 prepared 入口。
原生源已接入冷目标与 region 所有权合同，原生生成结果进入共同执行槽的完整链路仍在迁移。

性能选择考虑计算、边界 copy/Cast/repack、同步、常量准备及其复用次数、临时与常驻资源；少一个 dispatch
或较大覆盖本身不证明更快。已知硬限制先排除非法方案，未知成本保持未知；缺少可靠测量时选择明确的成熟基线，
不假装有精确全局最优。候选发现和组合有可解释的界限，避免冷阶段对所有子图/Provider 做组合爆炸搜索。
选择报告使用既有诊断说明命中的实现、转换、等待、预算和选择原因，不新增用户必须填写的路由配置。

性能偏好可以由表承载，但表只记录优化事实；支持域唯一来自实际实现，执行表由编译结果生成。
同一 prepared 入口的数值分支、MoE expert IDs、合法形状 guard 与明确的变体选择不等于热 Provider 路由。
跨制品复用由有界 owner 持有，identity 包含所依赖的设备/版本、语义、精度/编码、布局与常量事实；
不使用仅模型名、裸地址或无界全局 cache。真实执行失败不触发换 Provider/设备重算。

### 冷生成与动态变化

| 阶段 | 必须确定的事实 |
|---|---|
| compile | 校验语义、shape 域、alias/effects；选择承载、放置和融合；准备常量及 packing；记录转换、copy/import、完成与句柄可用依赖、liveness 和资源预算 |
| create | 选择已准备的入口/变体，创建独立槽、固定端口表、scratch、原生可变状态与结果槽 |
| prepare / bind | 检查真实地址、stride、存储表示和权限；接纳不可变请求布局，准备必要 native plan、metadata 上传及其合法 ready/pending 依赖与 capture，成功后发布本槽准备版本；不隐含强制 host wait |
| submit | 检查已准备版本与接纳条件，调用固定片段、推进已有依赖和完成；不隐式搜索实现、JIT、重编图、packing 或增长缓存 |

prefill、cached continuation 和 decode 可以是同一模型制品的不同准备入口，不要求用一张无界动态图覆盖一切。
已证明 domain 的实例化和有限 ExactVariant 选择均为冷操作；严格 submit 不通过便利包装偷偷 prepare。
保留便利 API 时必须说明其包含冷成本。原生 managed 路线必要的 array/metadata 分配仍按真实合同表达，
不能将它标成无分配 replay，也不能借此隐藏新的 JIT、搜索、repack 或 copy。

| 变化 | 处理方式 |
|---|---|
| token 值、MoE IDs、不改变已准备布局/权限 footprint 的数值参数 | 固定程序消费数据；必要 GPU 校验不等于重新选择 Provider |
| 已准备域内的 active 长度 | 按已证明的参数域执行；若原生 planner 依赖它，则显式更新 layout，不能假称只改数据 |
| 同形状的新地址或 stride | 空闲槽 bind，检查既定表示；只失效确实依赖地址/stride 的 capture 或准备事实 |
| request/Q span、page IDs/topology、影响访问范围的 ranges | 本槽冷 layout 更新，接纳新的不可变 metadata、版本和真实 footprint，复用未变的代码、常量与可复用原生计划；失败不能提交旧 layout |
| 页 generation、初始化前缀与权限 | 更新真实权限及 ready gate；与 native 指针/capture identity 分开核对 |
| shape/phase 变化 | 冷选已准备入口或实例化已证明 domain；未准备的点明确返回需要准备，不在热提交时无限 JIT |
| 设备、精度、编码、必要物理布局或预算域变化 | 显式重新编译/准备相应制品，桥接与成本可见；不热切 CPU fallback |

数据依赖输出长度需专门声明能力，不能从固定输出合同推导自动支持。动态变化的失效范围以实际原生依赖为准，
既不复用过期 token，也不因一个页代际变化重建整张图。

### 边界值、结果与状态

一个边界值包含逻辑 TensorDesc、真实 owner 和实际表示；表示可以是合法 Mem view，也可以是适配器私有
native value。复用既有 OwnedResult/ResultLease/ResultStorage 的成功发布与退休机制，不新增数值 tensor 系统。
caller 目标、source alias、Graph backing、Executable 常量和 provider-generated 输出需在计划中分别声明。
CPU/CUDA caller-buffer 快路径仍直接使用 span；MLX arrays/Vulkan Results 原样保活、接续，不先复制进影子 buffer。

同一原生片段内的值保持原生表示。跨片段只有在真实合法时才能零拷贝导出/import；否则冷计划明确插入
copy、Cast、contiguous 或其他编码转换，并计入工作与预算。状态同样保留真实 owner：能合法产生 ready
ReadLease 时复用它，不能时不能伪造 Mem view 或只读权限。原生只读共享与 clone/import 的能力须明确。

完成依赖与句柄可用是两件事。Vulkan 输出 backing 可能预先可用，MLX array 可能在原生 owner job 后才产生；
只有具备句柄和合法 endpoint import 才能直接设备等待，否则由已有 frontier 推进明确的 pending 边界。
不能为表面统一而拆散原生 region，或假装同一 GPU 的不同 runtime 自动互通。原生等待/通知适配只负责进度，
不替代真实终态判断。结果 backing 不反向拥有自己的 ResultSlot，避免完成失败后引用环。

KV、conv、recurrent state 和已有接受前缀能力接入相同版本与完成合同。下一轮消费上一轮真实输出，不能通过
oracle 回填、重新展开全历史或隐式全量 clone 掩盖接缝。StateStore 仍按 ready 成员和 expected-base 发布，
不承诺回滚已经接纳的设备写入，也不接管 token/RNG、请求调度或 MTP 接受策略。

数学能力不自动授予整个 arena 的读取权限。batch 模块验证逻辑访问链一次，选定 prepared 实现声明受限读取
和空 footprint 的能力；共同 core 只检查同计划、同实例、端口、reader、alias 和退休，不点名具体算子/Provider。
禁止额外 reader、私有 capacity 发布、alias 逃逸和空历史载荷读取等保证保留。

在途工作与旧结果仍受保护；拒绝重绑不能销毁其 owner。空闲槽准备失败要明确使本次新准备失效，不能误交旧计划。
接纳失败、取消和关闭保留实际 accepted prefix，按原合同退休；接纳后失败的槽不未经重建就恢复可用。

### 性能是架构约束

统一必须减少重复事实和真实工作，不能只减少类名。编译时固定必要桥接、依赖和资源复用；布局不变时复用
metadata 与 native plan，变化时只更新必要部分。既有 Graph 已按偏序复用 workspace，应保留并改进，
不能把每层临时上界直接相加，或为省显存暗中串行化原来可并行的片段。

单 GPU 的单个原生片段可直接使用原生提交与完成机制，不强制创建 CPU 数学 Context、Scheduler 或私有线程池。
混合计划由同一份依赖计划驱动；需要 host 并行/阻塞进度时才复用已有 Scheduler/BlockingPool。文件与权重流送
移到可选装配层，纯数学不因未使用的便利 IO 接口被迫引入它们。

重点检查随 token 数、历史长度、层数、expert 选择和容量增长的工作量与显存：全历史展开、重复解码权重、
多余实体转置/Cast、上传、host 同步与重复分配优先处理。真实原生成本不能靠包装隐藏；已知编译分配和
workspace 公式进入既有报告，vendor 未知开销保持未知。保留融合 region，避免为统一逐 op 拆分。

迁移前后分别核对冷准备、稳态提交/完成、分配与复制、同步和常驻/峰值资源；必要时测整条推理链。
对照必须完成等价工作，匹配精度和资源寿命，先排除计时边界、噪声与仪器分辨率差异，再处理真实退化。
不能以接口更一致宣称更快，也不能用隐藏准备、提前释放结果或省略状态更新制造收益。

### 迁移次序与完成条件

1. 固定上述合同、普通引擎调用形状和冷热边界；盘点现有重复路径与可复用事实，不先扩展每个专用接口。
2. 确定中立边界值与 generated-output 合同，保持 caller-buffer 快路径；先接 Vulkan owner，再接 MLX owner，
   保留真实 region 和必要的 pending 边界。同时收拢各 backend 的 Direct/Graph 承载分析。
3. 将 native 片段纳入同一份不可变计划，复用现有值映射、端口投影、搬运和偏序分析；统一独立槽与结果代际，
   不再让混合 wrapper 复制另一份 DAG 或重复维护进度/退休状态。
4. 以 selected-prepared 的资源投影和冷 layout 能力替换 core 中具体 op/Provider 判断；把普通、分页、padding
   和状态链路接到相同生命周期，保留旧结果、部分提交与失败保护。
5. 统一端点装配及纯 CPU、单 GPU、混合公共调用，分离可选 IO；直接删除已替换的旧接口、重复实现和失效说明，
   一并迁移当前消费者与测试。不保留兼容层、旧入口 alias、薄包装或双执行体系；原生 SDK 与必要适配代码继续承担真实实现职责。

独立 Qwen3.5-2B 纯文本 CUDA 消费者从首批主链迁移起并行接入，用真实 prefill→续算→decode 及状态反馈发现接缝，
不等待上述步骤全部结束；最后在同源权重、匹配精度/输入与完整计时边界下和 llama.cpp 对照。
它是本次重构的测试产物，用于修正底座的性能、功能覆盖、流程与架构问题；不扩展为正式推理引擎产品。
消费者发现的问题应回修 Hyle 的共用合同与实现，不在消费者中积累 Provider 特殊绕过；它也不替代其他路线和既定模型域的相关检查。

各步以相关翻译单元、小型消费者和受影响生命周期回归验证，使用已有缓存，不增加全库验证矩阵或治理门禁。
必要平台检查按实际硬件记录；未运行的配置不能写成通过。历史源码、日志与数据继续保留。

完成要求是新架构实际承载公共调用链，旧分叉被替换，真实推理可连续反馈并守住性能与资源合同。
新增普通算子通常只改 schema、后端承载/登记及相关消费测试，无需修改共同调度、租约核心或 Context 白名单；
新资源种类则允许补充其真实合同。新模型主要组合既有语义，新融合和量化实现集中在相应 backend。
文档、静态类型设计或单个成功算子片段均不足以宣称全量重构完成。

原非多模态功能审查尚未完成，其未实现、未接线和未验证的完整旅程继续属于本 goal。
迁移后须在既定模型/制品范围继续审查并补完融合、各量化承载、状态/分支/接受前缀、分页与稀疏组合、动态准备、
资源调度和失败恢复；Qwen 测试消费者只提供其中一条反馈。原审查进度估计不是完成证明，架构迁移也不清零已有缺口。
具体事实沿用[功能审查报告](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)与
[模型接线报告](../evidence/correctness/model-route-completion-2026-10-18/README.md)，不另建治理或重复清单。

## 推理负载与数值边界

需求从真实权重角色、端口和跨调用状态出发，不能把文件名Q4/Q8当整模型dtype，也不能用小矩阵
覆盖完整推理。以下区分影响公共合同和Provider选择：

- storage、activation、accumulation、output、cache/state精度分别表达；FP8、GGUF、AWQ/GPTQ、
  NF4、MLX affine/MX等编码具有不同codes、scales、zero-point、group与舍入规则。
- attention包括mask、GQA、位置、空/变长序列和KV反馈；recurrent/causal conv的initial/final state
  与projection权重量化是不同边界。物理布局相同之前不能直接复制编码数据。
- MoE需保持路由tie、重复/偏斜expert IDs、grouped计算与combine顺序；动态IDs不等于重新选Provider。
- MTP/speculative需要可共享旧状态、显式候选更新与成功发布。接受前缀、token/RNG与模型分支策略归引擎；
  基础状态或分页能力存在，不代表已完成MTP引擎。
- 图像encoder/projector需要其实际算子、布局和资源链路；不能从文本投影算子推导多模态完整性。

### 中间值与反馈状态的反例

原生softplus若用`log(1 + exp(x))`，F32负尾的`1 + exp(x)`可能舍入为1，结果变成零。
融合region不单独公开中间gate，只说明它应按实际公开的attended输出和next state核对，
不等于放宽generic Softplus的数值合同。原始GDN primitive也不能自动代替外层Q/K归一化和动态gate计算。

连续状态验证必须让每个实现消费自己上轮输出的state，才能看出误差是否累积。
每轮重新注入oracle state只能验证单步，不能支持长期反馈的结论。

typed custom execution须说明端口、数值、layout、alias、workspace、副作用与失败；配置和原生代码
保活到终态。公开扩展不要求消费者包含`src/`私有头，也不用进程全局字符串注册替代对象局部owner。

## 依赖与性能取舍

公共语义核不拉入GPU SDK；原生runtime接入各有依赖和资源边界，普通产品由构建系统自动组装。
必要实现已在[构建图](build-system.md)中表达，不让用户为每个算子选择第三方库。

性能改动比较完整且等价的候选：同Provider直接调用的包装成本，与不同Provider的整体竞争力分别说明。
packing、数据变换、host submit、最终完成及资源峰值不能省略。收益不足时保留成熟实现；
不为替换单个leaf破坏更大region的融合和资源复用。
