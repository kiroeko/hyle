from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/execution-source.zip'
sources = [
    'include/hyle/compute/detail/context_ref.h',
    'include/hyle/compute/detail/provider_extension.h',
    'src/compute/context_state.h', 'src/compute/provider_internal.h',
    'src/compute/device.cc', 'src/compute/operation.cc',
    'include/hyle/graph/execution_source.h',
    'include/hyle/graph/detail/execution_source.h',
    'include/hyle/graph/detail/region_adapter.h',
    'include/hyle/graph/executable.h', 'include/hyle/graph/vulkan.h',
    'src/graph/execution_source.cc', 'src/graph/execution_source_internal.h',
    'src/graph/executable.cc', 'src/graph/plan_state.h',
    'src/graph/constant_artifact.h', 'src/graph/constant_artifact.cc',
    'src/graph/resources.cc', 'src/graph/region_access.cc',
    'src/graph/CMakeLists.txt', 'src/graph_route_vulkan/CMakeLists.txt',
    'src/graph_route_vulkan/execution_source.cc', 'src/graph_route_vulkan/vulkan_source.h',
    'tests/graph/execution_source_test.cc', 'tests/graph/region_provider_test.cc',
    'tests/graph/CMakeLists.txt', 'tests/graph_route_vulkan/CMakeLists.txt',
    'docs/architecture/compute-design.md', 'docs/developer/current-work.md',
    'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md',
]
parts = [
    '.scratch/architecture-refactor-2026-10-18/materialized-projection/source-results.zip',
    '.scratch/architecture-refactor-2026-10-18/execution-source/source-results.zip',
    '.scratch/architecture-refactor-2026-10-18/execution-source-callers/source-results.zip',
    '.scratch/architecture-refactor-2026-10-18/cold-context-ref-tests/source-results.zip',
    '.scratch/compute-execution-refactor-2026-10-18/qwen35-unique-invocation/source-results.zip',
]

def identity(p):
    data = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())

for relative in sources + parts:
    assert (ROOT / relative).is_file(), relative
summary = dict(
    scope='Actual execution source ownership and deletion of concrete Gather from resource core',
    validation=dict(shared_controls='13/13', materialized='Original complete CPU consumer PASS',
                    native='Vulkan source/backing 1/1, original native Program/Invocation',
                    callers='8 host translation units PASS, 4 retained cold test TUs PASS'),
    limitations=['No SDK/native rebuild or all-platform matrix',
                 'Common native generated values and unified joint runtime still incomplete',
                 'Qwen trace comparison predates this ExecutionSource change; independent oracle precision remains unaccepted',
                 'Inherited unfinished functional/model journeys remain; architecture migration does not close them'],
    failures_preserved=['Initial missing source field in region access',
                        'F32 Neg unsupported in native-only source test, legal retained Exp used instead',
                        'Initial Vulkan mismatched cached host ABI and correction in source capsule'],
    sources=[identity(ROOT / p) for p in sources], parts=[identity(ROOT / p) for p in parts],
    objects=[identity(p) for p in sorted(OUT.glob('*.obj'))])
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', newline='\n')
with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative in sources:
        archive.write(ROOT / relative, 'source/' + relative)
    for relative in parts:
        p = ROOT / relative
        archive.write(p, 'parts/' + p.parent.name + '.zip')
    for p in sorted(OUT.iterdir()):
        if p.suffix in ('.py', '.json', '.log'):
            archive.write(p, 'root/' + p.name)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
receipt = identity(DEST)
(OUT / 'archive.json').write_text(json.dumps(receipt, indent=2) + '\n', newline='\n')
print(json.dumps(receipt))
