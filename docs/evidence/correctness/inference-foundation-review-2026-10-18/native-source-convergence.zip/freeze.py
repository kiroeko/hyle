from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

OUT=Path(__file__).resolve().parent
BASE=OUT.parent
ROOT=BASE.parents[1]
AIR=BASE/'apple-page-invocation'

def identity(path):
    path=Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

products=set()
for group in [OUT/'root',BASE/'apple-configured-source',BASE/'apple-page-pending',BASE/'input-source-frontier',
              BASE/'legacy-native-retirement/encoded-sampling']:
    for before in group.rglob('before'):
        if not before.is_dir():continue
        for path in before.rglob('*'):
            if path.is_file() and (ROOT/path.relative_to(before)).is_file():
                products.add(path.relative_to(before).as_posix())
products.update(['src/compute_route_apple/apple_weights_internal.h','src/graph_route_apple/weight_binding.cc',
    'tests/graph_route_apple/configured_source_test.cc','tests/graph_route_apple/weight_binding_test.cc',
    'tests/graph/input_source_frontier_test.cc','samples/package/graph/cpu_apple/CMakeLists.txt',
    'samples/package/graph/cpu_apple/README.md','docs/user/graph.md','docs/developer/current-work.md'])
for relative in sorted(products):
    target=OUT/'final-candidate'/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/relative,target)
write('final-source-identities.json',[identity(ROOT/p) for p in sorted(products)])
diff=[]
for before in (OUT/'root/before').rglob('*'):
    if before.is_file():
        relative=before.relative_to(OUT/'root/before').as_posix()
        diff+=difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
            (ROOT/relative).read_text(encoding='utf-8').splitlines(True),
            'before/'+relative,'candidate/'+relative)
(OUT/'root/source.diff').write_text(''.join(diff),encoding='utf-8')

windows=[];retain=[]
for folder in ['legacy-native-retirement/encoded-sampling/windows',
               'legacy-native-retirement/encoded-sampling/windows-sampling-boundary']:
    stage=BASE/folder
    plan=json.loads((stage/'cleanup.json').read_text())
    frozen={r['path']:r for r in json.loads((stage/'final-identities.json').read_text())}
    for path in plan['files']:
        row=identity(path);assert row==frozen[path],path;windows.append(row)
    retain += [identity(path) for path in plan['retained_stage_objects']]
stage=BASE/'input-source-frontier/windows'
windows+=json.loads((stage/'cleanup-candidates.json').read_text())['files']
retain+=json.loads((stage/'retained-objects.json').read_text())
for row in windows+retain:assert identity(row['path'])==row,row['path']
mac=json.loads((AIR/'air-results/cleanup.json').read_text())
write('cleanup.json',dict(windows=windows,windows_retain=retain,mac=mac))
write('summary.json',dict(status='bounded_real_chains_passed_goal_still_active',
    apple_final_commands={'frontier':173,'native':175,'page':177,'source':179,'encoded':181,'sampling':183,'sample':185},
    apple_gtests={'frontier':3,'native':11,'source':4,'encoded':4},
    apple_consumers={'same_page_placements':['CPU','CPU/Apple/CPU','AppleMath'],'query_rows':[18,2,0],
        'sampling_steps':65,'sampling_final_cpu_copy_count':2,'sampling_final_cpu_copy_bytes':24,
        'sample':'original Q4 FFN / WeightBatch chunk, 2 slots / 3 FFN replays'},
    windows={'frontier_gtests':3,'encoded_gtests':3,'sampling_steps':65,
             'sampling_relinked_with_current_submission':True},
    preserved_failures={'141':'pending immutable source reported frontier no progress; test early-return allocator lifetime also fixed',
        '149':'new Apple pending adapter used wrong native completion qualifier',
        '151_and_164':'sampling fixture counted only host-domain-0 instead of real CPU readers',
        '162_and_168':'new regression fixture assumptions about segment grouping and per-source poll counts'},
    limits=['old Apple/Vulkan runtimes and remaining contracts/risk fixtures not yet retired',
        'plain Apple two-pass F32 partials still missing','changed-KV MLX eager graph cost remains',
        'package source/static/shared delivery not newly executed','no SDK/kernel/shader rebuild',
        'no full model or throughput rerun; Qwen numerical acceptance remains open']))

archive=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-source-convergence.zip'
assert not archive.exists(),archive
entries={}
suffixes={'.cc','.h','.mm','.json','.txt','.log','.py','.diff','.md','.ps1'}
for label,folder in [('root',OUT/'root'),('final',OUT/'final-candidate'),
        ('configured',BASE/'apple-configured-source'),('pending',BASE/'apple-page-pending'),
        ('frontier',BASE/'input-source-frontier'),
        ('consumer-migration',BASE/'legacy-native-retirement/encoded-sampling')]:
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix in suffixes:
            entries[label+'/'+path.relative_to(folder).as_posix()]=path
for path in (AIR/'air-results').iterdir():
    if not path.is_file() or path.suffix not in suffixes:continue
    if path.name[:3].isdigit() and int(path.name[:3])<125:continue
    entries['air/'+path.name]=path
for name in ['air.py','air_remote.py','host-sources.json']:
    entries['air/'+name]=AIR/name
for name in ['cleanup.json','summary.json','final-source-identities.json','freeze.py']:
    entries[name]=OUT/name
entries['cleanup-test.ps1']=ROOT/'test.ps1'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,path in sorted(entries.items()):output.write(path,name)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None and set(check.namelist())==set(entries)
    for name,path in entries.items():assert check.read(name)==path.read_bytes(),name
receipt=identity(archive);receipt['path']=archive.relative_to(ROOT).as_posix();receipt['entries']=len(entries)
write('archive-receipt.json',receipt)
print(json.dumps(receipt));print('reclaimable',sum(r['bytes'] for r in windows+mac['files']))
