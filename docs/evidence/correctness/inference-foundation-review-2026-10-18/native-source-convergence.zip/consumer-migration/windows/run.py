"""Two migrated Vulkan consumers over the current retained 99-owner closure."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[4]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
BASE=ARCH/'native-page-semantics/windows'
MATCH=ARCH/'legacy-native-retirement/public-mla/windows-current-owners'
SOURCES={'encoded':'tests/compute_batch/encoded_page_native_consumer.cc',
         'sampling':'tests/graph_route_cpu_vulkan/sampling_consumer.cc'}
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def recipe():
    return next(r['command'] for r in read(BASE/'commands.json')
        if r['tag']=='tests--compute_batch--encoded_page_native_consumer-compile' and r['exit']==0)
def run(tag,command,timeout=90):
    rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
    stem=f'{len(rows)+1:03d}-{tag}';command=list(map(str,command))
    row=dict(tag=tag,command=command,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
    rows.append(row);write('commands.json',rows)
    compiler=recipe()[0];env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler,'CMAKE_C_COMPILER':compiler})
    torch=next(str(Path(p).parent) for p in read(MATCH/'matched-link-receipt.json')['command'] if p.lower().endswith('torch_cpu.lib'))
    env['PATH']=torch+os.pathsep+env.get('PATH','');env['VSLANG']='1033'
    start=time.monotonic();result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,
        timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT/row['stdout']).write_bytes(result.stdout);(OUT/row['stderr']).write_bytes(result.stderr)
    row.update(exit=result.returncode,seconds=time.monotonic()-start);write('commands.json',rows)
    print(stem,result.returncode,flush=True)
    print(result.stdout.decode(errors='replace')[-9000:]+result.stderr.decode(errors='replace')[-9000:],flush=True)
    return result.returncode
def compile_one(which):
    source=SOURCES[which]
    command=[p for p in recipe() if not p.lower().startswith(('/fo','/fd')) and not p.lower().endswith('.cc')
        and 'src\\graph_route_cpu_vulkan' not in p.lower() and p!='/DHYLE_FOUNDATION_A_HYBRID=1']
    command.extend([str(ROOT/source),'/Fo'+str(OUT/(which+'.obj'))])
    files=[source,'include/hyle/compute/operation.h','include/hyle/graph/batch.h','include/hyle/graph/vulkan.h',
        'include/hyle/graph/executable.h','include/hyle/graph/region_provider.h','tests/compute_models/sampling_native_joint_consumer.h']
    before=[identity(ROOT/p) for p in files]
    code=run(which+'-compile',command)
    stable=all(identity(r['path'])==r for r in before)
    row=dict(source=before[0],headers=before[1:],sources_unchanged=stable,command=command,exit=code)
    if not code:row['object']=identity(OUT/(which+'.obj'))
    write(which+'-compile-receipt.json',row)
    return code if code else (0 if stable else 1)
def link(which):
    match=read(MATCH/'matched-link-receipt.json');row=read(OUT/(which+'-compile-receipt.json'))
    assert row['exit']==0 and row['sources_unchanged']
    assert identity(row['source']['path'])==row['source'] and identity(row['object']['path'])==row['object']
    for h in row['headers']:assert identity(h['path'])==h
    for obj in match['inherited_product_objects']:assert identity(obj['path'])==obj
    for lib in match['library_identities']:assert identity(lib['path'])==lib
    flags=[p for p in match['command'][1:] if not p.lower().endswith(('.obj','.lib'))
        and not p.upper().startswith(('/OUT:','/MAP:'))]
    libs=[p for p in match['command'] if p.lower().endswith('.lib')]
    if which=='encoded':libs.extend(str(ROOT/'.scratch/build-compute-v2-dev/lib'/p) for p in ['gtest_main.lib','gtest.lib'])
    command=[match['command'][0],'/OUT:'+str(OUT/(which+'.exe')),'/MAP:'+str(OUT/(which+'.map')),
        *flags,row['object']['path'],*[p['path'] for p in match['inherited_product_objects']],*libs]
    write(which+'-link-receipt.json',dict(baseline=identity(MATCH/'matched-link-receipt.json'),
        product_objects=match['inherited_product_objects'],consumer=row,command=command,
        library_identities=[identity(p) for p in libs if Path(p).is_file()]))
    code=run(which+'-link',command)
    if not code:
        data=(OUT/(which+'.map')).read_text(encoding='utf-8',errors='replace')
        markers=['@cpu_vulkan@graph@hyle','@cpu_apple@graph@hyle','graph_route_cpu_vulkan.lib','graph_route_cpu_apple.lib']
        hits=[line for line in data.splitlines() if any(m in line for m in markers)]
        write(which+'-removed-runtime-map-check.json',dict(markers=markers,matches=hits));assert not hits
        write(which+'-images.json',[identity(OUT/(which+s)) for s in ['.exe','.map','.exp','.lib']])
    return code
if __name__=='__main__':
    action,which=sys.argv[1:]
    if action=='compile':code=compile_one(which)
    elif action=='link':code=link(which)
    elif action=='run':
        command=[OUT/(which+'.exe')]
        if which=='encoded':command+=['--gtest_color=no','--gtest_filter=EncodedNativePages.*','--gtest_output=json:'+str(OUT/'encoded-results.json')]
        code=run(which+'-run',command,timeout=180)
    else:raise SystemExit('compile/link/run encoded/sampling')
    raise SystemExit(code)
