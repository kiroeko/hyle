"""Actual CPU-port boundary regression with one current Graph core owner."""
from pathlib import Path
import importlib.util,json,shutil,sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[4]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
spec=importlib.util.spec_from_file_location('consumer_driver',OUT.parent/'windows/run.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
driver.OUT=OUT
PREVIOUS=driver.MATCH
SOURCE='src/graph/submission.cc'

def base():
    receipt=driver.read(OUT/'submission-compile-receipt.json')
    assert receipt['exit']==0 and receipt['sources_unchanged']
    assert driver.identity(ROOT/SOURCE)==receipt['source']
    assert driver.identity(receipt['object']['path'])==receipt['object']
    before=driver.read(PREVIOUS/'matched-link-receipt.json')
    owners=driver.read(ARCH/'native-page-semantics/windows/matched-link-base.json')['selected_sources']
    previous=owners[SOURCE];matches=0
    for i,obj in enumerate(before['inherited_product_objects']):
        if obj['path']==previous:
            before['inherited_product_objects'][i]=receipt['object'];matches+=1
    assert matches==1 and len(before['inherited_product_objects'])==99
    before['command']=[receipt['object']['path'] if p==previous else p for p in before['command']]
    before['latest_submission']=receipt
    before['previous_receipt']=driver.identity(PREVIOUS/'matched-link-receipt.json')
    path=OUT/'current-base';path.mkdir(exist_ok=True)
    (path/'matched-link-receipt.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
    driver.MATCH=path

def compile_core():
    recipe=next(r['command'] for r in driver.read(ARCH/'native-ready-pages/windows/compile-plan.json') if r['source']==SOURCE)
    command=[p for p in recipe if not p.lower().startswith(('/fo','/fd')) and not p.lower().endswith('.cc')]
    command.extend([str(ROOT/SOURCE),'/Fo'+str(OUT/'submission.obj')])
    paths=[SOURCE,'src/graph/submission_internal.h','src/graph/plan_state.h','src/graph/input_sources.h']
    before=[driver.identity(ROOT/p) for p in paths]
    for source in paths+['tests/compute_models/sampling_native_joint_consumer.h','tests/graph_route_cpu_vulkan/sampling_consumer.cc']:
        target=OUT/'sources'/source;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/source,target)
    code=driver.run('submission-compile',command)
    stable=all(driver.identity(p['path'])==p for p in before)
    receipt=dict(source=before[0],headers=before[1:],sources_unchanged=stable,command=command,exit=code)
    if not code:receipt['object']=driver.identity(OUT/'submission.obj')
    driver.write('submission-compile-receipt.json',receipt)
    if not code and stable:base()
    return code if code else (0 if stable else 1)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='compile-core':code=compile_core()
    else:
        base()
        if action=='compile-sampling':code=driver.compile_one('sampling')
        elif action=='link':code=driver.link('sampling')
        elif action=='run':code=driver.run('sampling-run',[OUT/'sampling.exe'],timeout=180)
        else:raise SystemExit('compile-core / compile-sampling / link / run')
    raise SystemExit(code)
