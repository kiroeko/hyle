"""Save this agent's source-only pending-page delta; no build or execution."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
OWNED = ("src/graph_route_apple/native_paged_region.cc",
         "src/graph_route_apple/native_paged_region.h")
SHARED = ("include/hyle/graph/apple.h", "src/graph_route_apple/native_region.h",
          "src/graph_batch/native_paged_regions.h",
          "include/hyle/compute/detail/apple_batch_access.h",
          "src/compute_route_apple/apple_file_stream_access.h",
          "include/hyle/compute/detail/materialized_native_controller.h",
          "include/hyle/compute/detail/copy_outcome_source.h")


def identity(path):
    data = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


diff = []
for relative in OWNED:
    original = STAGE / "before" / relative
    current = ROOT / relative
    snapshot = STAGE / "candidate" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(current.read_bytes())
    first = original.read_text().splitlines(keepends=True)
    final = current.read_text().splitlines(keepends=True)
    assert all(line.rstrip("\n\r").rstrip() == line.rstrip("\n\r")
               for line in final), relative
    assert not any(line.startswith(("<<<<<<<", ">>>>>>>")) for line in final), relative
    diff.extend(difflib.unified_diff(first, final,
        fromfile="before/" + relative, tofile="candidate/" + relative))
(STAGE / "source.diff").write_text("".join(diff), encoding="utf-8")
(STAGE / "source-identities.json").write_text(json.dumps(
    [identity(ROOT / p) for p in OWNED], indent=2) + "\n", encoding="utf-8")
(STAGE / "shared-header-identities.json").write_text(json.dumps(
    [identity(ROOT / p) for p in SHARED], indent=2) + "\n", encoding="utf-8")
summary = {
    "status": "source_ready_not_compiled_or_executed",
    "changed_product_files": [OWNED[0]],
    "unchanged_owned_header": OWNED[1],
    "public_api": [
        "graph::apple::submit(Invocation&, span<const QueueBinding>, compute::apple::CopyBatchUpdate&&) -> Result<compute::Completion>",
        "graph::apple::take_update(Invocation&) -> Result<compute::apple::CopyBatchUpdate>",
    ],
    "implementation": [
        "Cold BatchResources owns one CopyOutcomeSource<Apple CopyBatchUpdate, original CopyStreamAccess>; exact table and retained Runtime identify it.",
        "Original page slot only borrows that source, retains ready/pending frames per physical cache port, and uses original PagedBatchAccess imports.",
        "Every pending frame is checked against source writer/coverage before Update ownership moves. Pre-acceptance rejection restores the original Update.",
        "Original controller.submit_pending admits actual page reads/writers, original native FIFO submits, and original shared DependentCompletion maps source/suffix outcomes.",
        "take_update uses original native_pending_recovery plus source availability and actual in_flight status; no new Completion/state machine.",
        "Ready replay remains original replay_ready; empty-cache proof/owned and deferred Q/output projection are unchanged.",
        "Source Runtime uses typed source_runtime(context) getter, not a first-field/shared_ptr layout cast.",
    ],
    "validation": {
        "git_diff_no_index_check": "exit1 for changed files, no whitespace diagnostics",
        "snapshot_whitespace_conflict_check": "passed",
        "compilation": "not run; parent will use final Air closure",
        "numerical_or_lifetime_tests": "not run",
        "new_tu_or_build_dependency": "none",
        "compute_private_changes": "none",
    },
    "remaining": "Actual Air native typed pending/producer-failure/retirement consumers still required; source-only readiness does not establish those passes.",
}
(STAGE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"source": identity(ROOT / OWNED[0]),
                  "diff": identity(STAGE / "source.diff"),
                  "summary": identity(STAGE / "summary.json")}, indent=2))
