#include "native_paged_region.h"
#include "native_output.h"
#include "native_region.h"

#include "../compute_route_apple/apple_copy_internal.h"
#include "../compute_route_apple/apple_file_stream_access.h"
#include "../graph_batch/native_paged_regions.h"
#include "hyle/compute/detail/apple_batch_access.h"
#include "hyle/compute/detail/copy_outcome_source.h"
#include "hyle/compute/detail/generated_result.h"
#include "hyle/compute/detail/materialized_native_controller.h"
#include "hyle/graph/apple.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <mutex>
#include <optional>

namespace hyle::graph::apple::detail {
namespace {
namespace ca = compute::apple;
namespace an = ca::detail;
namespace cd = compute::detail;
namespace bd = graph::batch::detail;
namespace mx = mlx::core;
const unsigned array_type = 0;
constexpr compute::ProviderRuntimeProperties runtime_properties{
    .mode = compute::ProviderRuntimeMode::kDelegated,
    .workspace_owner = compute::ProviderWorkspaceOwner::kProvider,
    .replay_class = compute::ProviderReplayClass::kManaged,
    .uses_private_threads = true};
struct Recipe final {
  compute::BatchLayoutVersion layout;
  batch::PagedAttentionOptions options;
};
Result<Recipe> recipe(const compute::Operation &operation) noexcept {
  if (const auto value = operation.custom_as<batch::PagedAttention>())
    return Recipe{value->layout, value->options};
  if (const auto value = operation.custom_as<batch::PagedMlaAttention>())
    return Recipe{value->layout, value->options};
  return std::unexpected(Status::Unimplemented("not paged attention"));
}
const std::shared_ptr<an::Runtime> &runtime(void *context) noexcept {
  return source_runtime(context);
}
// Only the original BatchResources payload owns the actual native Update.
// All selected page slots borrow it until the one DependentCompletion retires.
struct NativePagePendingSource final {
  explicit NativePagePendingSource(mem::AllocatorRef selected) noexcept
      : allocator(selected) {}
  mem::AllocatorRef allocator;
  std::shared_ptr<an::Runtime> runtime;
  cd::CopyOutcomeSource<ca::CopyBatchUpdate, an::CopyStreamAccess> source;
};
const bd::NativePendingSourceVTable pending_source_table{
    [](void *opaque) noexcept {
      auto *source = static_cast<NativePagePendingSource *>(opaque);
      const auto allocator = source->allocator;
      allocator.destroy(source);
    },
    [](void *opaque) noexcept -> Status {
      auto &source = static_cast<NativePagePendingSource *>(opaque)->source;
      return source.available() && !source.update().valid() ? Status::Ok() :
          Status::Unavailable("Apple Graph still owns its copy source controls");
    }};
Result<void *> create_pending_source(const std::shared_ptr<an::Runtime> &owner,
    std::size_t capacity, mem::AllocatorRef allocator,
    compute::ResourceBudget budget) noexcept {
  if (!owner || !capacity || !allocator.valid())
    return std::unexpected(Status::InvalidArgument("Apple page source needs its actual Runtime and reserved capacity"));
  auto *source = allocator.construct<NativePagePendingSource>(allocator);
  if (!source) return std::unexpected(Status::ResourceExhausted("Apple copy source metadata"));
  auto created = cd::CopyOutcomeSource<ca::CopyBatchUpdate, an::CopyStreamAccess>::create(
      capacity, {.allocator = allocator, .resource_budget = std::move(budget)});
  if (!created) {
    allocator.destroy(source);
    return std::unexpected(created.error());
  }
  source->runtime = owner;
  source->source = std::move(*created);
  return source;
}
Result<NativePagePendingSource *> pending_source(
    const bd::NativePendingSourceOwner &source,
    const std::shared_ptr<an::Runtime> &owner) noexcept {
  if (source.table != &pending_source_table || !source.state ||
      source.identity != owner.get())
    return std::unexpected(Status::InvalidArgument("Apple page source implementation/Runtime differs"));
  auto *actual = static_cast<NativePagePendingSource *>(source.state);
  if (actual->runtime != owner)
    return std::unexpected(Status::InvalidArgument("Apple page source actual owner differs"));
  return actual;
}
Status qualify_pending_source(NativePagePendingSource &source,
    const ca::CopyBatchUpdate &update) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto prefix, an::CopyStreamAccess::dependency(update));
  // Fully retired native phases have no pending prefix. Their original Update
  // still proves checked status, actual writers and complete page coverage.
  if (prefix.pending()) return an::qualify_copy_dependency(source.runtime, prefix);
  return prefix.terminal_hint ? *prefix.terminal_hint : Status::Ok();
}
Status qualify(const std::shared_ptr<an::Runtime> &owner, const Recipe &value,
    const compute::BatchLayoutVersion &layout) noexcept {
  if (!owner || !value.layout.valid() || !value.layout.schema().owns(layout) ||
      !std::isfinite(value.options.scale))
    return Status::InvalidArgument("Apple page needs its actual Runtime and owned mathematical layout");
  HYLE_ASSIGN_OR_RETURN(auto analysis, an::PagedBatchAccess::analyze_paged(
      owner, layout, value.options.causal, value.options.window_left));
  if (!value.options.allow_bf16_partials) {
    if (!analysis.partial_precision_known)
      return Status::Unimplemented("Apple page precision needs its actual native architecture");
    if (analysis.uses_declared_type_partials)
      return Status::Unimplemented("Apple plain page two-pass partials need declared-type permission");
  }
  return Status::Ok();
}
Result<Recipe> qualify(void *context, const RegionCompileRequest &request) noexcept {
  if (!request.graph || request.graph->dimension_count() || request.route != kNativePagedRoute ||
      request.nodes.size() != 1 || request.outputs.size() > 1 ||
      request.has_unknown_effects || !request.effect_accesses.empty())
    return std::unexpected(Status::Unimplemented("Apple page needs one fixed pure typed node"));
  HYLE_ASSIGN_OR_RETURN(auto operation, request.graph->operation(request.nodes[0]));
  HYLE_ASSIGN_OR_RETURN(auto value, recipe(operation));
  HYLE_RETURN_IF_ERROR(qualify(runtime(context), value, value.layout));
  return value;
}
struct Preparation final { std::shared_ptr<an::Runtime> runtime; };
struct Resource final {
  mem::MemoryResourceRef resource;
  bool valid() const noexcept { return resource.valid(); }
  mem::MemoryResourceRef ref() const noexcept { return resource; }
};
struct Traits final {
  using Context = Preparation; using Memory = Resource; using Program = ca::Program;
  using Invocation = ca::Invocation; using CopyInvocation = ca::CopyBatchInvocation;
  using View = mx::array; using Submission = compute::OwnedResult<ca::Results>;
  using CopyAccess = an::CopyStreamAccess;
  static auto invocation(const Program &program, mem::AllocatorRef allocator) {
    return program.create_invocation(allocator);
  }
  static auto copy_program(const Context &context, std::span<const compute::CopyResourceSpec> specs,
      compute::CopyBatchOptions options) {
    return an::CopyStreamAccess::prepare_program(context.runtime, specs, std::move(options));
  }
  static auto copy_invocation(const ca::CopyBatchProgram &program) { return ca::CopyBatchInvocation::create(program); }
  static auto prepare_program(const Context &context, const compute::NativePagedBatchProgram &program,
      compute::BatchLayoutVersion layout, const compute::WorkloadContext &workload) {
    return an::PagedBatchAccess::prepare_program(context.runtime, program, std::move(layout), workload);
  }
  static auto submit(Invocation &invocation, compute::LeaseUseBatch uses) {
    return an::PagedBatchAccess::submit(invocation, std::move(uses));
  }
  static auto wait_native(Invocation &invocation) { return an::PagedBatchAccess::wait_native(invocation); }
  static auto reuse_gate(Invocation &invocation) { return an::PagedBatchAccess::reuse_gate(invocation); }
  static auto release_inputs(Invocation &invocation) { return an::PagedBatchAccess::release_inputs(invocation); }
  static auto update_layout(Invocation &invocation, const compute::BatchLayoutVersion &layout) {
    return an::PagedBatchAccess::update_layout(invocation, layout);
  }
};
using Controller = cd::MaterializedNativeState<Traits, cd::PagedMetadataPolicy>;
struct Artifact final {
  Recipe recipe;
  compute::NativePagedBatchProgram native_recipe;
  NodeId node;
  std::array<ValueId,3> inputs{};
  std::array<std::uint32_t,3> ports{};
  std::size_t count = 0, public_outputs = 0;
  compute::TensorDesc output;
  Preparation preparation;
  Resource device, staging;
  ca::Program program;
  compute::ResourceBudget budget;
  compute::WorkloadContext workload;
};
struct Slot final {
  Slot(mem::AllocatorRef selected, Artifact &owner)
      : allocator(selected), artifact(owner), controller(selected) {}
  mem::AllocatorRef allocator;
  Artifact &artifact;
  Controller controller;
  std::array<compute::PagedArenaRead,2> frames;
  std::array<compute::PagedArenaPendingRead,2> pending_frames;
  NativePagePendingSource *pending_source = nullptr; // Borrowed from BatchResources.
  std::array<an::InputBinding,4> bindings;
  cd::ResultStorageOwner result;
  std::optional<mx::array> projected;
  std::optional<compute::ReadLease> exported;
  std::mutex output_mutex;
};
void clear_output(Slot &slot) noexcept { slot.exported.reset(); slot.projected.reset(); }
bool empty_program(const Artifact &artifact, const Slot &slot) noexcept {
  const auto &controller = slot.controller;
  const auto &layout = controller.version.layout();
  return controller.prepared && artifact.native_recipe.schema().owns(layout) &&
      !layout.facts().query_rows && !layout.facts().page_refs &&
      an::PagedBatchAccess::empty_cache_reads(controller.native);
}
Status prepare(void *prepared, void *invocation, compute::BatchLayoutVersion layout) noexcept {
  auto &artifact = *static_cast<Artifact *>(prepared); auto &slot = *static_cast<Slot *>(invocation);
  if (!artifact.native_recipe.schema().owns(layout) ||
      layout.facts().query_rows != artifact.recipe.layout.facts().query_rows)
    return Status::InvalidArgument("Apple page schema/active output shape changed");
  HYLE_RETURN_IF_ERROR(qualify(artifact.preparation.runtime, artifact.recipe, layout));
  slot.result.reset(); clear_output(slot);
  HYLE_RETURN_IF_ERROR(slot.controller.prepare(std::move(layout)));
  slot.frames = {}; slot.pending_frames = {}; slot.pending_source = nullptr;
  return Status::Ok();
}
Status reset(void *, void *invocation) noexcept {
  auto &slot = *static_cast<Slot *>(invocation);
  slot.result.reset(); clear_output(slot);
  if (slot.controller.native.valid()) HYLE_RETURN_IF_ERROR(an::PagedBatchAccess::release_inputs(slot.controller.native));
  for (auto &binding : slot.bindings) { binding.value.reset(); binding.source.reset(); }
  slot.frames = {}; slot.pending_frames = {}; slot.pending_source = nullptr;
  slot.controller.keys = {}; slot.controller.values = {}; slot.controller.reads = {};
  slot.controller.prepared = false; slot.controller.bound = false;
  return Status::Ok();
}
template<class Frame> Status validate_frame(void *prepared, void *invocation,
    ValueId input, const Frame &value) noexcept {
  const auto &artifact = *static_cast<Artifact *>(prepared); const auto &slot = *static_cast<Slot *>(invocation);
  const auto &controller = slot.controller;
  if (!controller.prepared || controller.bound || !value.valid() || value.layout() != controller.version.layout())
    return Status::InvalidArgument("Apple page frame needs its unbound prepared owned layout");
  bool selected = false;
  for (std::size_t port = 1; port < artifact.count; ++port) if (artifact.inputs[port] == input) {
    selected = true;
    if (slot.frames[port-1].valid() || slot.pending_frames[port-1].valid())
      return Status::FailedPrecondition("Apple page frame needs reset before rebinding");
    const auto capacity = artifact.native_recipe.schema().capacity();
    HYLE_RETURN_IF_ERROR(cd::PagedArenaAccess::validate_storage(value, port == 1 ? capacity.key_storage : capacity.value_storage));
    HYLE_ASSIGN_OR_RETURN(auto actual, cd::PagedArenaAccess::tensor(value));
    HYLE_ASSIGN_OR_RETURN(auto expected, artifact.native_recipe.input_description(value.layout(), port));
    if (actual.description() != expected || !an::is_copy_resource(actual.storage().resource()))
      return Status::InvalidArgument("Apple page frame physical resource/description differs");
  }
  return selected ? Status::Ok() : Status::InvalidArgument("input is not this Apple page reader");
}
Status frame(void *prepared, void *invocation, ValueId input,
    const compute::PagedArenaRead &value) noexcept {
  return validate_frame(prepared, invocation, input, value);
}
const bd::NativePagedRegionVTable page_table{
    [](void *prepared, void *invocation) noexcept -> Result<bd::NativePagedRegionFacts> {
      const auto &artifact = *static_cast<Artifact *>(prepared); const auto &slot = *static_cast<Slot *>(invocation);
      return bd::NativePagedRegionFacts{artifact.node, &artifact.native_recipe,
          std::span(artifact.inputs).first(artifact.count), std::span(artifact.ports).first(artifact.count),
          slot.controller.version.layout()};
    }, &prepare, &frame,
    [](void *prepared, void *invocation, ValueId input, compute::PagedArenaRead value) noexcept {
      const auto &artifact = *static_cast<Artifact *>(prepared); auto &slot = *static_cast<Slot *>(invocation);
      for (std::size_t port = 1; port < artifact.count; ++port)
        if (artifact.inputs[port] == input) slot.frames[port-1] = value;
    }, &reset,
    [](void *, void *invocation) noexcept { return static_cast<Slot *>(invocation)->controller.report; },
    [](void *prepared, void *invocation, ValueId input,
        const compute::PagedArenaPendingRead &value,
        const bd::NativePendingSourceOwner &source) noexcept -> Status {
      const auto &artifact = *static_cast<Artifact *>(prepared);
      HYLE_ASSIGN_OR_RETURN(auto actual, pending_source(source, artifact.preparation.runtime));
      (void)actual;
      return validate_frame(prepared, invocation, input, value);
    },
    [](void *prepared, void *invocation, ValueId input, compute::PagedArenaPendingRead value,
        const bd::NativePendingSourceOwner &source) noexcept {
      const auto &artifact = *static_cast<Artifact *>(prepared); auto &slot = *static_cast<Slot *>(invocation);
      auto actual = pending_source(source, artifact.preparation.runtime);
      HYLE_FATAL_ASSERT(actual.has_value());
      slot.pending_source = *actual;
      for (std::size_t port = 1; port < artifact.count; ++port)
        if (artifact.inputs[port] == input) slot.pending_frames[port-1] = value;
    },
    [](void *prepared) noexcept -> bd::NativePendingSourceFactory {
      const auto &artifact = *static_cast<Artifact *>(prepared);
      return {&pending_source_table, artifact.preparation.runtime.get(),
          [](void *opaque, std::size_t capacity, mem::AllocatorRef allocator,
              compute::ResourceBudget budget) noexcept -> Result<void *> {
            return create_pending_source(static_cast<Artifact *>(opaque)->preparation.runtime,
                capacity, allocator, std::move(budget));
          }};
    }};
Status create_slot(void *prepared, mem::AllocatorRef allocator, mem::BufferView, void **out) noexcept {
  *out = nullptr; auto &artifact = *static_cast<Artifact *>(prepared);
  auto *slot = allocator.construct<Slot>(allocator, artifact);
  if (!slot) return Status::ResourceExhausted("Apple page slot metadata");
  *out = slot;
  HYLE_RETURN_IF_ERROR(slot->controller.initialize(artifact.preparation, artifact.program, artifact.native_recipe,
      artifact.device, artifact.staging, {.max_metadata_backing_bytes = SIZE_MAX,
          .allocator = allocator, .resource_budget = artifact.budget}, artifact.workload));
  HYLE_ASSIGN_OR_RETURN(slot->controller.version, artifact.native_recipe.version(artifact.recipe.layout));
  return Status::Ok();
}
Status bind(void *prepared, void *invocation, std::span<const RegionValue> inputs,
    std::span<const compute::TensorView> outputs) noexcept {
  auto &artifact = *static_cast<Artifact *>(prepared); auto &slot = *static_cast<Slot *>(invocation);
  auto &controller = slot.controller;
  if (!controller.prepared || outputs.size() != artifact.public_outputs)
    return Status::FailedPrecondition("Apple page layout must be prepared before replay bindings");
  slot.result.reset(); clear_output(slot);
  HYLE_RETURN_IF_ERROR(an::InvocationAccess::reuse_gate(controller.native));
  for (auto &binding : slot.bindings) { binding.value.reset(); binding.source.reset(); }
  for (std::size_t port = 0; port < artifact.count; ++port) {
    HYLE_ASSIGN_OR_RETURN(auto description, artifact.native_recipe.input_description(controller.version.layout(), port));
    if (artifact.ports[port] >= inputs.size()) return Status::InvalidArgument("Apple page boundary port differs");
    const auto &input = inputs[artifact.ports[port]];
    if (input.description != description) return Status::InvalidArgument("Apple page physical input description differs");
    if (!port) {
      controller.reads[0] = {};
      if (input.reference.valid()) {
        HYLE_ASSIGN_OR_RETURN(slot.bindings[0].source,
            native_output_source(input.reference, artifact.preparation.runtime, description));
      } else if (input.lease) {
        HYLE_ASSIGN_OR_RETURN(auto owner, input.lease->view());
        const auto wanted = input.tensor.storage();
        if (!input.tensor.valid() || owner.resource() != wanted.resource() || owner.native_handle() != wanted.native_handle() ||
            wanted.offset() < owner.offset() || wanted.offset()-owner.offset() > owner.size() ||
            wanted.size() > owner.size()-(wanted.offset()-owner.offset()))
          return Status::InvalidArgument("Apple page query lease does not cover its actual input");
        HYLE_ASSIGN_OR_RETURN(auto selected, input.lease->subview(wanted.offset()-owner.offset(), wanted.size()));
        HYLE_ASSIGN_OR_RETURN(slot.bindings[0].value, an::MemoryAccess::owned_tensor(selected, description, controller.import));
        controller.reads[0] = std::move(selected);
      } else {
        HYLE_ASSIGN_OR_RETURN(slot.bindings[0].value, an::MemoryAccess::borrow_tensor(input.tensor));
      }
    } else {
      const auto import = [&](const auto &permission) noexcept -> Status {
        if (!permission.valid() || permission.layout() != controller.version.layout() || input.reference.valid())
          return Status::FailedPrecondition("Apple cache port has no exact typed page frame");
        HYLE_ASSIGN_OR_RETURN(auto actual, cd::PagedArenaAccess::tensor(permission));
        const auto x = actual.storage(), y = input.tensor.storage();
        if (x.resource() != y.resource() || x.native_handle() != y.native_handle() || x.offset() != y.offset() || x.size() != y.size())
          return Status::InvalidArgument("Apple cache input differs from its exact bound frame");
        if (!empty_program(artifact, slot)) {
          HYLE_ASSIGN_OR_RETURN(slot.bindings[port].value,
              an::PagedBatchAccess::binding(x.resource(), permission, controller.import));
        }
        return Status::Ok();
      };
      HYLE_RETURN_IF_ERROR(slot.pending_frames[port-1].valid() ?
          import(slot.pending_frames[port-1]) : import(slot.frames[port-1]));
    }
  }
  if (empty_program(artifact, slot)) {
    HYLE_RETURN_IF_ERROR(an::InvocationAccess::prepare_inputs(controller.native, std::span(slot.bindings).first(1)));
  } else {
    HYLE_ASSIGN_OR_RETURN(auto metadata, artifact.native_recipe.input_description(controller.version.layout(), artifact.count));
    HYLE_ASSIGN_OR_RETURN(slot.bindings[artifact.count].value,
        an::MemoryAccess::owned_tensor(controller.reads[3], metadata, controller.import));
    HYLE_RETURN_IF_ERROR(an::InvocationAccess::prepare_inputs(controller.native,
        std::span(slot.bindings).first(artifact.count+1)));
  }
  controller.keys = slot.frames[0]; controller.values = artifact.count == 3 ? slot.frames[1] : compute::PagedArenaRead{};
  controller.native_bank = controller.prepared_bank; controller.bound = true;
  return Status::Ok();
}
Status seal(void *, void *invocation) noexcept {
  return an::InvocationAccess::reuse_gate(static_cast<Slot *>(invocation)->controller.native);
}
Status project(Slot &slot, std::size_t port) noexcept {
  if (port >= slot.artifact.public_outputs) return Status::OutOfRange("Apple page output port");
  if (!slot.projected) { HYLE_ASSIGN_OR_RETURN(slot.projected, an::InvocationAccess::output(slot.controller.native, port)); }
  return Status::Ok();
}
Status export_port(Slot &slot, std::size_t port) noexcept {
  HYLE_RETURN_IF_ERROR(project(slot, port));
  if (slot.exported) return Status::Ok();
  if (!slot.projected->nbytes()) return Status::Unimplemented("empty Apple page output has no payload lease");
  HYLE_ASSIGN_OR_RETURN(slot.exported, an::MemoryAccess::export_readonly(*slot.projected, slot.artifact.output,
      {.allocator = slot.allocator, .resource_budget = slot.artifact.budget}));
  return Status::Ok();
}
Result<RegionValue> value(void *, void *invocation, std::size_t port) noexcept {
  auto &slot = *static_cast<Slot *>(invocation); std::lock_guard lock(slot.output_mutex);
  HYLE_RETURN_IF_ERROR(project(slot, port));
  RegionValue result{slot.artifact.output, {}, &array_type, &*slot.projected};
  if (!slot.projected->nbytes()) return result;
  HYLE_RETURN_IF_ERROR(export_port(slot, port));
  HYLE_ASSIGN_OR_RETURN(result.tensor, slot.exported->tensor(result.description));
  return result;
}
Result<compute::ReadLease> lease(void *, void *invocation, std::size_t port) noexcept {
  auto &slot = *static_cast<Slot *>(invocation); std::lock_guard lock(slot.output_mutex);
  HYLE_RETURN_IF_ERROR(export_port(slot, port)); return *slot.exported;
}
const NativeOutputVTable output_table{
    [](void *prepared, void *invocation, std::size_t port, const std::shared_ptr<an::Runtime> &owner,
        const compute::TensorDesc &description) noexcept -> Result<an::InputSource> {
      if (!prepared || !invocation) return std::unexpected(Status::InvalidArgument("Apple page source has no actual slot"));
      const auto &artifact = *static_cast<Artifact *>(prepared); const auto &slot = *static_cast<Slot *>(invocation);
      if (&slot.artifact != &artifact || owner != artifact.preparation.runtime ||
          port >= artifact.public_outputs || description != artifact.output)
        return std::unexpected(Status::InvalidArgument("Apple page source owner/Runtime/physical port differs"));
      return an::InvocationAccess::source(slot.controller.native, port);
    },
    [](void *prepared, void *invocation, std::size_t port, const ca::NativeStorage &wanted) noexcept -> Result<NativeOutputOrigins> {
      if (!prepared || !invocation) return std::unexpected(Status::InvalidArgument("Apple page output has no actual slot"));
      const auto &artifact = *static_cast<Artifact *>(prepared); auto &slot = *static_cast<Slot *>(invocation);
      if (&slot.artifact != &artifact || port >= artifact.public_outputs)
        return std::unexpected(Status::InvalidArgument("Apple page output owner/physical port differs"));
      std::lock_guard lock(slot.output_mutex);
      HYLE_RETURN_IF_ERROR(project(slot, port));
      HYLE_ASSIGN_OR_RETURN(auto actual, an::MemoryAccess::storage_info(*slot.projected));
      NativeOutputOrigins result;
      if (!actual.view_bytes || !wanted.view_bytes || actual.buffer != wanted.buffer ||
          !(actual.offset_bytes <= wanted.offset_bytes ? wanted.offset_bytes-actual.offset_bytes < actual.view_bytes :
              actual.offset_bytes-wanted.offset_bytes < wanted.view_bytes)) return result;
      result.owned_overlap = true;
      HYLE_RETURN_IF_ERROR(export_port(slot, port));
      result.owner = *slot.exported;
      return result;
    }};
Result<compute::Completion> submit(void *, void *invocation,
    std::span<const cd::CompletionDependency> dependencies,
    std::span<const compute::ConstTensorView>, std::span<const compute::TensorView>) noexcept {
  auto &slot = *static_cast<Slot *>(invocation);
  for (const auto dependency : dependencies)
    HYLE_RETURN_IF_ERROR(an::qualify_copy_dependency(slot.artifact.preparation.runtime, dependency));
  slot.result.reset(); clear_output(slot);
  const bool pending = std::ranges::any_of(slot.pending_frames, [](const auto &frame) { return frame.valid(); });
  auto accepted = [&]() -> Result<Traits::Submission> {
    if (!pending) return slot.controller.replay_ready();
    HYLE_RETURN_IF_ERROR(an::PagedBatchAccess::reuse_gate(slot.controller.native));
    if (!slot.pending_source)
      return std::unexpected(Status::FailedPrecondition("Apple page has no reserved pending source"));
    HYLE_RETURN_IF_ERROR(qualify_pending_source(*slot.pending_source, slot.pending_source->source.update()));
    return slot.controller.submit_pending<ca::CopyBatchUpdate, an::CopyStreamAccess>(
        slot.pending_frames[0], slot.pending_frames[1], slot.pending_source->source.update());
  }();
  if (!accepted) return std::unexpected(accepted.error());
  auto transfer = cd::ResultAccess::take_storage(std::move(*accepted));
  slot.result = std::move(transfer.owner); return std::move(transfer.completion);
}
const graph::detail::RegionProjectedReadVTable projected_table{
    [](const ProviderRegionPrepared &prepared, void *invocation, std::uint32_t port,
        cd::OperationPreparedAccess *out) noexcept -> Status {
      *out = {};
      if (!prepared.state || !invocation) return Status::InvalidArgument("Apple empty-page proof has no actual slot");
      const auto &artifact = *static_cast<const Artifact *>(prepared.state); const auto &slot = *static_cast<const Slot *>(invocation);
      bool cache = false;
      for (std::size_t p = 1; p < artifact.count; ++p) cache |= artifact.ports[p] == port;
      if (!cache || !empty_program(artifact, slot)) return Status::Unimplemented("Apple page port is not a prepared Q-only reader");
      *out = {.projected_input = port, .allows_empty_footprint = true}; return Status::Ok();
    }};
const ProviderRegionPreparedVTable prepared_table{
    .destroy_prepared = [](void *p, mem::AllocatorRef a) noexcept { a.destroy(static_cast<Artifact *>(p)); },
    .alias_support = [](void *, std::size_t, std::size_t) noexcept { return compute::AliasSupport{}; },
    .create_invocation = &create_slot,
    .destroy_invocation = [](void *p, mem::AllocatorRef a) noexcept { a.destroy(static_cast<Slot *>(p)); },
    .delegated_submit = &submit,
    .endpoint = [](void *p, void *) noexcept { return region_ordered_endpoint(static_cast<Artifact *>(p)->preparation.runtime); },
    .can_import_endpoint = [](void *p, void *, cd::CompletionEndpoint source) noexcept {
      return imports_region_ordered_endpoint(static_cast<Artifact *>(p)->preparation.runtime, source);
    },
    .output_contract = [](void *, std::size_t) noexcept {
      return RegionOutputContract{RegionOutputKind::kDeferredGenerated, RegionOutputProjection::kNativeOnly};
    },
    .output_value = &value, .prepare_bindings = &bind, .seal_bindings = &seal, .output_lease = &lease,
    .query_extension = [](void *, compute::ProviderExtensionId id) noexcept -> const void * {
      if (id == bd::kNativePagedRegionExtensionId) return &page_table;
      if (id == graph::detail::kRegionProjectedReadExtensionId) return &projected_table;
      if (id == kNativeOutputExtensionId) return &output_table;
      return nullptr;
    }};
} // namespace
bool native_paged_operation(const compute::Operation &operation) noexcept {
  return operation.custom_as<batch::PagedAttention>() || operation.custom_as<batch::PagedMlaAttention>();
}
Status propose_native_paged(void *context, const RegionDiscoveryRequest &request,
    std::span<const std::uint8_t> needed, RegionProposalWriter &writer) noexcept {
  for (std::size_t ordinal = 0; ordinal < request.graph.node_count(); ++ordinal) {
    if (!needed[ordinal] || (!request.allowed_nodes.empty() && !request.allowed_nodes[ordinal])) continue;
    HYLE_ASSIGN_OR_RETURN(auto node, request.graph.node_id(ordinal));
    HYLE_ASSIGN_OR_RETURN(auto operation, request.graph.operation(node));
    if (!native_paged_operation(operation)) continue;
    HYLE_ASSIGN_OR_RETURN(auto selected, recipe(operation));
    const auto admitted = qualify(runtime(context), selected, selected.layout);
    if (!admitted.ok()) { if (admitted.IsUnimplemented()) continue; return admitted; }
    const std::array nodes{node};
    HYLE_ASSIGN_OR_RETURN(auto added, writer.try_add({.nodes = nodes, .route = kNativePagedRoute,
        .replay_class = compute::ProviderReplayClass::kManaged,
        .implementation = compute::ProviderImplementationId{0x5041474544415050ULL}, .preference = 100}));
    if (!added) break;
  }
  return Status::Ok();
}
Status native_paged_resources(void *context, const RegionCompileRequest &request,
    std::span<RegionInputRequirement> inputs, std::span<RegionOutputRequirement> outputs,
    RegionResourceProposal *proposal) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto selected, qualify(context, request));
  (void)selected;
  if (inputs.size() != request.inputs.size() || outputs.size() != request.outputs.size())
    return Status::InvalidArgument("Apple page resource boundary differs");
  const cd::ResourceBindingRequirement resource{
      .required_properties = mem::MemoryProperty::kHostAccessible | mem::MemoryProperty::kDeviceAccessible |
          mem::MemoryProperty::kHostDeviceCoherent, .minimum_alignment = 1};
  std::ranges::fill(inputs, RegionInputRequirement{resource, false});
  HYLE_ASSIGN_OR_RETURN(auto query, request.graph->node_input(request.nodes[0], 0));
  const auto found = std::ranges::find(request.inputs, query);
  if (found == request.inputs.end()) return Status::InvalidArgument("Apple page query boundary is missing");
  inputs[std::size_t(found-request.inputs.begin())].accepts_reference = true;
  std::ranges::fill(outputs, RegionOutputRequirement{resource,
      {RegionOutputKind::kDeferredGenerated, RegionOutputProjection::kNativeOnly}});
  *proposal = {.runtime = runtime_properties, .workspace_resource = resource}; return Status::Ok();
}
compute::ProviderPrepareOutcome compile_native_paged(void *context, const RegionCompileRequest &request,
    mem::AllocatorRef allocator, ProviderRegionPrepared *out) noexcept {
  using Outcome = compute::ProviderPrepareOutcome; *out = {};
  auto selected = qualify(context, request);
  if (!selected) return selected.error().IsUnimplemented() ? Outcome::unsupported(selected.error()) : Outcome::error(selected.error());
  if (request.input_resources.size() != request.inputs.size() || request.output_resources.size() != request.outputs.size())
    return Outcome::error(Status::InvalidArgument("Apple page physical resources differ"));
  auto *artifact = allocator.construct<Artifact>();
  if (!artifact) return Outcome::error(Status::ResourceExhausted("Apple page artifact metadata"));
  *out = {.vtable = &prepared_table, .state = artifact};
  const auto build = [&]() noexcept -> Status {
    artifact->recipe = std::move(*selected); artifact->node = request.nodes[0];
    artifact->preparation.runtime = runtime(context); artifact->workload = request.workload;
    artifact->budget = request.resource_budget;
    const auto schema = artifact->recipe.layout.schema();
    const auto refs = std::size_t(schema.capacity().max_page_refs);
    if (refs > SIZE_MAX / sizeof(std::int32_t))
      return Status::OutOfRange("Apple page metadata byte extent overflow");
    const auto bytes = refs * sizeof(std::int32_t);
    HYLE_ASSIGN_OR_RETURN(artifact->native_recipe, compute::NativePagedBatchProgram::prepare(schema,
        {.max_host_metadata_bytes = bytes, .scale = artifact->recipe.options.scale,
         .causal = artifact->recipe.options.causal, .window_left = artifact->recipe.options.window_left,
         .allocator = allocator, .resource_budget = request.resource_budget}));
    artifact->count = schema.mla_layout() == compute::MlaCacheLayout::kNone ? 3 : 2;
    artifact->public_outputs = request.outputs.size();
    HYLE_ASSIGN_OR_RETURN(artifact->output, compute::batch_output_description(schema.capacity(), artifact->recipe.layout.facts().query_rows));
    const auto consider = [&](mem::MemoryResourceRef resource) {
      if (!an::is_copy_resource(resource)) return;
      if (!artifact->device.valid()) artifact->device = {resource};
      if (!artifact->staging.valid()) artifact->staging = {resource};
    };
    consider(request.workspace_resource);
    for (const auto &domain : request.available_storage_domains) consider(domain.resource);
    if (!artifact->device.valid() || !artifact->staging.valid())
      return Status::Unimplemented("Apple page metadata needs actual shared Metal storage");
    for (std::size_t port = 0; port < artifact->count; ++port) {
      HYLE_ASSIGN_OR_RETURN(artifact->inputs[port], request.graph->node_input(artifact->node, port));
      if (port && artifact->inputs[port].kind() != ValueKind::kInput)
        return Status::InvalidArgument("Apple page capacity needs its exact external frame");
      const auto found = std::ranges::find(request.inputs, artifact->inputs[port]);
      if (found == request.inputs.end()) return Status::InvalidArgument("Apple page boundary input is missing");
      artifact->ports[port] = std::uint32_t(found-request.inputs.begin());
      if (!an::is_copy_resource(request.input_resources[artifact->ports[port]]))
        return Status::InvalidArgument("Apple page input does not belong to shared Metal storage");
    }
    HYLE_ASSIGN_OR_RETURN(artifact->program, an::PagedBatchAccess::prepare_program(
        artifact->preparation.runtime, artifact->native_recipe, artifact->recipe.layout, artifact->workload));
    out->properties = {.persistent_bytes = std::nullopt, .runtime = runtime_properties, .invocation_private_bytes = std::nullopt};
    return Status::Ok();
  };
  const auto status = build();
  return status.ok() ? Outcome::prepared() : status.IsUnimplemented() ? Outcome::unsupported(status) : Outcome::error(status);
}
} // namespace hyle::graph::apple::detail

namespace hyle::graph::apple {
Result<compute::Completion> submit(Invocation &invocation,
    std::span<const QueueBinding> queues, compute::apple::CopyBatchUpdate &&update) noexcept {
  namespace bd = batch::detail;
  namespace an = compute::apple::detail;
  namespace cd = compute::detail;
  HYLE_ASSIGN_OR_RETURN(auto access, bd::native_pending_access(invocation,
      &detail::pending_source_table));
  auto &source = *static_cast<detail::NativePagePendingSource *>(access.source);
  for (const auto &input : access.inputs)
    HYLE_RETURN_IF_ERROR((cd::PagedArenaAccess::validate<compute::apple::CopyBatchUpdate,
        an::CopyStreamAccess>(input.frame, update)));
  HYLE_RETURN_IF_ERROR(detail::qualify_pending_source(source, update));
  HYLE_ASSIGN_OR_RETURN(auto sources, source.source.take(std::move(update)));
  auto submitted = bd::submit_native_pending(invocation, queues,
      &detail::pending_source_table, sources);
  if (!submitted) {
    update = std::move(source.source.update());
    sources.release(sources.state);
  }
  return submitted;
}
Result<compute::apple::CopyBatchUpdate> take_update(Invocation &invocation) noexcept {
  namespace bd = batch::detail;
  HYLE_ASSIGN_OR_RETURN(auto opaque, bd::native_pending_recovery(invocation,
      &detail::pending_source_table));
  auto &source = static_cast<detail::NativePagePendingSource *>(opaque)->source;
  if (!source.available() || !source.update().valid() || source.update().in_flight())
    return std::unexpected(Status::Unavailable("Apple copy source controls have not retired"));
  auto result = std::move(source.update());
  bd::finish_native_pending_recovery(invocation);
  return result;
}
} // namespace hyle::graph::apple
