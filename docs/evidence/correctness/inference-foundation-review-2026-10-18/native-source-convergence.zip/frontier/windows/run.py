from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = ROOT / ".scratch/architecture-refactor-2026-10-18"
BASE = ARCH / "native-page-semantics/windows"
sys.path.insert(0, str(ROOT / "scripts"))
from hyle_environment import windows_compiler_environment


def read(path):
    return json.loads(Path(path).read_text())


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def library_identity(argument):
    path = Path(argument)
    if not path.is_file():
        path = next(Path(folder) / argument for folder in env["LIB"].split(os.pathsep)
                    if (Path(folder) / argument).is_file())
    return dict(argument=argument, **identity(path))


recipe_rows = read(ARCH / "native-ready-pages/windows/compile-plan.json")
core_recipe = next(r["command"] for r in recipe_rows if r["source"] == "src/graph/submission.cc")
previous = read(ARCH / "native-pending-pages/windows/commands.json")
test_recipe = next(r["command"] for r in reversed(previous)
    if r.get("exit") == 0 and r.get("tag", "").endswith("-compile")
    and any(x.endswith("region_provider_test.cc") for x in r["command"]))
baseline = read(BASE / "matched-link-base.json")
env = windows_compiler_environment({"CMAKE_CXX_COMPILER": core_recipe[0], "CMAKE_C_COMPILER": core_recipe[0]})
env["VSLANG"] = "1033"
torch = next(str(Path(x).parent) for x in baseline["command"] if x.lower().endswith("torch_cpu.lib"))
env["PATH"] = torch + os.pathsep + env.get("PATH", "")


def run(tag, command):
    records = read(OUT / "commands.json") if (OUT / "commands.json").exists() else []
    stem = f"{len(records)+1:03d}-{tag}"
    record = dict(tag=tag, command=list(map(str, command)), exit=None,
                  stdout=stem + ".stdout.log", stderr=stem + ".stderr.log")
    records.append(record)
    write("commands.json", records)
    start = time.monotonic()
    done = subprocess.run(record["command"], cwd=ROOT, env=env, capture_output=True,
                          timeout=60, creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / record["stdout"]).write_bytes(done.stdout)
    (OUT / record["stderr"]).write_bytes(done.stderr)
    record.update(exit=done.returncode, seconds=time.monotonic()-start)
    write("commands.json", records)
    print(stem, done.returncode, flush=True)
    if done.returncode:
        print((done.stdout + done.stderr).decode(errors="replace")[-9000:], flush=True)
    return done.returncode


def compile_one(source, template, stem):
    command = [x for x in template if not x.lower().startswith(("/fo", "/fd"))
               and not x.lower().endswith(".cc")]
    command.extend([str(ROOT / source), "/Fo" + str(OUT / (stem + ".obj"))])
    before = identity(ROOT / source)
    headers = [identity(ROOT / path) for path in ("src/graph/plan_state.h",
        "src/graph/submission_internal.h", "src/graph/input_sources.h",
        "include/hyle/graph/detail/input_source.h", "include/hyle/compute/provider.h",
        "include/hyle/compute/custom_kernel.h")]
    result = run(stem + "-compile", command)
    record = dict(source=before, command=command, headers=headers, exit=result,
        source_unchanged=before == identity(ROOT / source) and all(h == identity(h["path"]) for h in headers))
    if result == 0:
        record["object"] = identity(OUT / (stem + ".obj"))
    write(stem + "-identity.json", record)
    return result or (0 if record["source_unchanged"] else 1)


def link():
    old = baseline["selected_sources"]["src/graph/submission.cc"]
    source_by_object = {value: source for source, value in baseline["selected_sources"].items()}
    command = []
    for part in baseline["command"]:
        if part.upper().startswith(("/OUT:", "/MAP:")):
            continue
        if part.lower().endswith(".obj") and source_by_object.get(part, "").startswith("tests/"):
            continue
        if part == old:
            part = str(OUT / "submission.obj")
        command.append(part)
    command += [str(OUT / "input-source-frontier-test.obj"),
        str(ROOT / ".scratch/build-compute-v2-dev/lib/gtest_main.lib"),
        str(ROOT / ".scratch/build-compute-v2-dev/lib/gtest.lib"),
        "/OUT:" + str(OUT / "controls.exe"), "/MAP:" + str(OUT / "controls.map")]
    # Existing numeric libraries/SDK stay read-only, and every reused object
    # must retain the exact original matched-closure identity.
    for row in baseline["objects"]:
        assert identity(row["path"]) == row, row["path"]
    write("link-inputs.json", dict(baseline=identity(BASE / "matched-link-base.json"),
        objects=[identity(x) for x in command if x.lower().endswith(".obj")],
        libraries=[library_identity(x) for x in command if x.lower().endswith(".lib")]))
    return run("controls-link", command)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    action = sys.argv[1]
    if action == "compile":
        result = compile_one("src/graph/submission.cc", core_recipe, "submission")
        if not result:
            result = compile_one("tests/graph/input_source_frontier_test.cc", test_recipe, "input-source-frontier-test")
    elif action == "link":
        result = link()
    elif action == "run":
        result = run("controls-run", [OUT / "controls.exe", "--gtest_color=no",
            "--gtest_filter=InputSourceFrontier.*", "--gtest_output=json:" + str(OUT / "results.json")])
    else:
        raise SystemExit("compile/link/run")
    raise SystemExit(result)
