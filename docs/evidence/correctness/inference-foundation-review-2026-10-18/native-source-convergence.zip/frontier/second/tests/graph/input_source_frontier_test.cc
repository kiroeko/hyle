#include <gtest/gtest.h>

#include <array>
#include <utility>

#include "../../src/graph/submission_internal.h"
#include "../compute/custom_kernel_fixture.h"
#include "hyle/graph/detail/input_source.h"
#include "test_environment.h"

namespace {
namespace c = hyle::compute;
namespace cd = c::detail;
namespace g = hyle::graph;
namespace gd = g::detail;
using hyle::Result;
using hyle::Status;

// No thread, clock or poll-count trigger makes this source ready. Only the
// original wait callback settles it, with either success or its own failure.
struct PendingInput final {
  int references = 0, polls = 0, waits = 0, enqueues = 0;
  bool settled = false;
  Status terminal;
  const custom_test::Probe *independent = nullptr;
  int independent_at_wait = -1;
};
const gd::InputSourceVTable source_table{
    [](void *p) noexcept { ++static_cast<PendingInput *>(p)->references; },
    [](void *p) noexcept { --static_cast<PendingInput *>(p)->references; },
    [](void *, const cd::QueueRef *) noexcept -> Result<gd::InputDependencyRoute> {
      return gd::InputDependencyRoute::kHostWait;
    },
    [](void *p) noexcept -> Result<c::CompletionPoll> {
      auto &source = *static_cast<PendingInput *>(p);
      ++source.polls;
      if (!source.settled) return c::CompletionPoll::kPending;
      if (!source.terminal.ok()) return std::unexpected(source.terminal);
      return c::CompletionPoll::kComplete;
    },
    [](void *p) noexcept -> Status {
      auto &source = *static_cast<PendingInput *>(p);
      ++source.waits;
      source.independent_at_wait = source.independent->executions.load();
      source.settled = true;
      return source.terminal;
    },
    [](void *p, cd::QueueSequence &) noexcept {
      ++static_cast<PendingInput *>(p)->enqueues;
      return cd::EnqueueResult::rejected(Status::Internal("HostWait source was imported"));
    },
    [](void *) noexcept { return Status::Ok(); }};

struct Logical final {
  g::Graph graph;
  std::array<g::ValueId, 3> inputs, outputs;
};
Logical graph() {
  auto builder = g::GraphBuilder::create().value();
  Logical logical;
  for (std::size_t i = 0; i < logical.inputs.size(); ++i) {
    logical.inputs[i] = builder.input(custom_test::description()).value();
    logical.outputs[i] = builder.add(c::Operation::custom(custom_test::Affine{1}),
                                    logical.inputs[i]).value();
    EXPECT_TRUE(builder.publish(logical.outputs[i]).ok());
  }
  logical.graph = std::move(builder).finish().value();
  return logical;
}

struct Fixture final {
  std::array<PendingInput, 2> sources;
  custom_test::Probe blocked, independent;
  c::Context first = c::Context::create(c::cpu::device(), custom_test::provider(blocked).value()).value();
  c::Context second = c::Context::create(c::cpu::device(), custom_test::provider(independent).value()).value();
  c::Queue first_queue = first.create_queue().value();
  c::Queue second_queue = second.create_queue().value();
  g::test::Environment environment{{&first, hyle::mem::system_resource()},
                                   {&second, hyle::mem::system_resource()}};
  std::array<custom_test::Tensors, 3> tensors;
  std::array<g::QueueBinding, 2> queues{
      g::QueueBinding{environment.lane(0), &first_queue},
      g::QueueBinding{environment.lane(1), &second_queue}};

  Fixture() {
    for (auto &source : sources) source.independent = &independent;
    for (auto &tensor : tensors) EXPECT_TRUE(tensor.fill().ok());
    const std::array<float, 4> sentinel{99, 99, 99, 99};
    for (auto &tensor : tensors)
      EXPECT_TRUE(tensor.output.view().write(std::as_bytes(std::span(sentinel))).ok());
  }
  ~Fixture() {
    for (const auto &source : sources) EXPECT_EQ(source.references, 0);
  }
  Result<g::CompiledGraph> compile(const Logical &logical) {
    const std::array placements{
        g::NodePlacement{logical.graph.node_id(0).value(), environment.target(0), g::PlacementStrength::kRequired},
        g::NodePlacement{logical.graph.node_id(1).value(), environment.target(1), g::PlacementStrength::kRequired},
        g::NodePlacement{logical.graph.node_id(2).value(), environment.target(0), g::PlacementStrength::kRequired}};
    return g::compile(logical.graph, environment.environment(),
        {.node_placements = placements, .region_selection = g::RegionSelectionPolicy::kDisabled});
  }
  Status bind(g::Invocation &run, const Logical &logical) {
    for (std::size_t i = 0; i < tensors.size(); ++i) {
      if (i == 1) {
        HYLE_RETURN_IF_ERROR(run.bind(logical.inputs[i], tensors[i].in));
      } else {
        auto &source = sources[i / 2];
        HYLE_ASSIGN_OR_RETURN(auto owner, gd::InputSource::acquire(&source, &source_table, &source));
        HYLE_RETURN_IF_ERROR(gd::InputAccess::bind(run, logical.inputs[i], tensors[i].in, std::move(owner)));
      }
      HYLE_RETURN_IF_ERROR(run.bind(logical.outputs[i], tensors[i].out));
    }
    return Status::Ok();
  }
};
constexpr std::array<float, 4> expected{3, 5, 7, 9};
constexpr std::array<float, 4> sentinel{99, 99, 99, 99};

TEST(InputSourceFrontier, OrdinarySubmitSettlesBothSourcesAfterIndependentReadyWork) {
  Fixture fixture;
  const auto logical = graph();
  auto compiled = fixture.compile(logical);
  ASSERT_TRUE(compiled) << compiled.error().message();
  auto run = compiled->executable.create_invocation().value();
  ASSERT_TRUE(fixture.bind(run, logical).ok());
  const auto rejected = run.prepare_replay(fixture.queues, {.host_wait = g::HostWaitPolicy::kReject});
  EXPECT_TRUE(rejected.IsUnimplemented());
  for (const auto &source : fixture.sources) {
    EXPECT_EQ(source.polls, 0);
    EXPECT_EQ(source.waits, 0);
  }
  ASSERT_TRUE(run.prepare_replay(fixture.queues).ok());
  EXPECT_EQ(run.input_source_report()->host_wait_count, 2u);
  auto completion = run.submit(fixture.queues);
  ASSERT_TRUE(completion) << completion.error().message();
  ASSERT_TRUE(completion->wait().ok());
  EXPECT_EQ(fixture.independent.executions, 1);
  EXPECT_EQ(fixture.blocked.executions, 2);
  for (const auto &source : fixture.sources) {
    EXPECT_GT(source.polls, 0);
    EXPECT_EQ(source.waits, 1);
    EXPECT_EQ(source.independent_at_wait, 1);
    EXPECT_EQ(source.enqueues, 0);
  }
  for (auto &tensor : fixture.tensors) EXPECT_EQ(tensor.read(), expected);
  for (const auto output : logical.outputs) EXPECT_TRUE(run.output(output));
}

TEST(InputSourceFrontier, NonblockingPendingObservationDoesNotPoisonTheOriginalCursor) {
  Fixture fixture;
  const auto logical = graph();
  auto compiled = fixture.compile(logical);
  ASSERT_TRUE(compiled) << compiled.error().message();
  auto run = compiled->executable.create_invocation().value();
  ASSERT_TRUE(fixture.bind(run, logical).ok());
  ASSERT_TRUE(run.prepare_replay(fixture.queues).ok());
  auto started = gd::SubmissionCursor::begin(run, fixture.queues);
  ASSERT_TRUE(started) << started.error().message();
  auto cursor = std::move(*started);
  auto advance = cursor.advance(false);
  ASSERT_TRUE(advance) << advance.error().message();
  EXPECT_TRUE(*advance); // The independent branch is accepted before a wait.
  EXPECT_EQ(fixture.independent.executions, 1);
  for (int retry = 0; retry < 2; ++retry) {
    advance = cursor.advance(false);
    ASSERT_TRUE(advance) << advance.error().message();
    EXPECT_FALSE(*advance);
    EXPECT_TRUE(cursor.submission_error().ok());
    EXPECT_FALSE(cursor.done());
    EXPECT_EQ(cursor.pending_dependency(), nullptr); // External, not a Plan cell.
    for (const auto &source : fixture.sources) EXPECT_EQ(source.waits, 0);
  }
  for (int remaining = 0; remaining < 4 && !cursor.done(); ++remaining) {
    advance = cursor.advance(true);
    ASSERT_TRUE(advance) << advance.error().message();
  }
  ASSERT_TRUE(cursor.done());
  ASSERT_TRUE(cursor.submission_error().ok());
  auto completion = cursor.finish();
  ASSERT_TRUE(completion) << completion.error().message();
  ASSERT_TRUE(completion->wait().ok());
  for (auto &tensor : fixture.tensors) EXPECT_EQ(tensor.read(), expected);
  for (const auto &source : fixture.sources) EXPECT_EQ(source.waits, 1);
}

TEST(InputSourceFrontier, ProducerWaitFailurePreservesAcceptedIndependentWorkAndItsStatus) {
  Fixture fixture;
  fixture.sources[0].terminal = Status::DataLoss("immutable producer failed during wait");
  const auto logical = graph();
  auto compiled = fixture.compile(logical);
  ASSERT_TRUE(compiled) << compiled.error().message();
  auto run = compiled->executable.create_invocation().value();
  ASSERT_TRUE(fixture.bind(run, logical).ok());
  ASSERT_TRUE(run.prepare_replay(fixture.queues).ok());
  auto completion = run.submit(fixture.queues);
  ASSERT_TRUE(completion) << completion.error().message();
  const auto terminal = completion->wait();
  EXPECT_TRUE(terminal.IsDataLoss());
  EXPECT_EQ(terminal.message(), "immutable producer failed during wait");
  EXPECT_EQ(fixture.sources[0].waits, 1);
  EXPECT_EQ(fixture.sources[0].independent_at_wait, 1);
  EXPECT_EQ(fixture.independent.executions, 1);
  EXPECT_EQ(fixture.tensors[0].read(), sentinel);
  EXPECT_EQ(fixture.tensors[1].read(), expected);
  // Both consumers in this blocked target share its original segment. The
  // failed source prevents either command; the other target already ran.
  EXPECT_EQ(fixture.tensors[2].read(), sentinel);
  EXPECT_FALSE(run.in_flight());
  for (const auto output : logical.outputs) {
    const auto rejected = run.output(output);
    ASSERT_FALSE(rejected);
    EXPECT_TRUE(rejected.error().IsFailedPrecondition());
  }
}
} // namespace
