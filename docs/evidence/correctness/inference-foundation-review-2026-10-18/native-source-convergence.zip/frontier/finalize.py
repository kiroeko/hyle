from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
WIN = STAGE / "windows"
FILES = ("src/graph/submission.cc", "tests/graph/input_source_frontier_test.cc",
         "tests/graph/CMakeLists.txt")


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


diff = []
for relative in FILES:
    path = ROOT / relative
    snapshot = STAGE / "candidate" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    before = STAGE / "before" / relative
    lines = path.read_text().splitlines(keepends=True)
    assert all(x.rstrip("\r\n").rstrip() == x.rstrip("\r\n") for x in lines)
    diff.extend(difflib.unified_diff(before.read_text().splitlines(keepends=True)
        if before.exists() else [], lines,
        fromfile="before/" + relative if before.exists() else "/dev/null",
        tofile="candidate/" + relative))
(STAGE / "source.diff").write_text("".join(diff), encoding="utf-8")
write(STAGE / "source-identities.json", [identity(ROOT / path) for path in FILES])
commands = json.loads((WIN / "commands.json").read_text())
assert commands[-1]["tag"] == "controls-run" and commands[-1]["exit"] == 0
result = json.loads((WIN / "results.json").read_text())
assert result["tests"] == 3 and result["failures"] == 0 and result["disabled"] == 0
retained = [identity(path) for path in sorted(WIN.glob("*.obj"))]
write(WIN / "retained-objects.json", retained)
images = [identity(WIN / ("controls" + suffix))
          for suffix in (".exe", ".map", ".exp", ".lib")
          if (WIN / ("controls" + suffix)).is_file()]
assert {Path(x["path"]).suffix for x in images} == {".exe", ".map", ".exp", ".lib"}
assert not {x["path"] for x in retained} & {x["path"] for x in images}
cleanup = {"files": images, "retained_objects": retained,
           "count": len(images), "bytes": sum(x["bytes"] for x in images),
           "executed": False}
write(WIN / "cleanup-candidates.json", cleanup)
summary = {
    "status": "fixed_windows_3_of_3_passed",
    "root_cause": "submit_segment returned pending_input for an external source, but advance only remembered/waited original Plan Completion cells and rejected an otherwise valid pending frontier as no progress.",
    "fix": "Save the actual pending-input segment in this bounded ready scan; after independent ready work is offered, nonblocking advance returns false unchanged, or blocking advance calls the original wait_input_sources and continues through existing advance(false). Original source failure rejects successors with the same Status and accepted prefixes remain in the original Completion path.",
    "scope": "submission.cc only, no field/layout/ABI/plan/provider/Apple implementation change; test+CMake registration.",
    "tests": [suite["name"] + "." + test["name"]
              for suite in result["testsuites"] for test in suite["testsuite"]],
    "final": {"compile": ["001-submission-compile", "006-input-source-frontier-test-compile"],
              "link": "007-controls-link", "run": "008-controls-run", "exit": 0,
              "tests": 3, "failed": 0, "numerical_sdk_or_kernel_rebuild": False,
              "baseline": "native-page-semantics/windows matched99 objects; replace original submission object, append one new fake-source test object", "gpu_used": False},
    "preserved_failures": [
        "Initial Air fixture expected3 segments, but compiler legitimately grouped the two same-target consumers into2 total segments. Removing that exact incidental count and preserving sentinel for both blocked consumers fixed only test expectations (parent owns actual Air logs).",
        "Windows link identity preflight first treated bare Synchronization.lib as a repository file; resolved through actual MSVC LIB directories, no linker args/product change.",
        "005-controls-run: 2/3 PASS, only per-source polls>0 was too strong because readiness short-circuits after the first pending source; changed to aggregate polls>0, preserving both wait counts, all independent-progress and mathematical/error assertions. Original result/source/objects/logs retained.",
    ],
    "source": identity(ROOT / FILES[0]),
    "test": identity(ROOT / FILES[1]),
    "retained_stage_objects": len(retained),
    "cleanup_candidates": {"count": len(images), "bytes": cleanup["bytes"]},
    "limits": "This local run covers only the three shared-CPU deterministic controls. Actual Apple WeightSource/ordinary page consumers are parent-run evidence, not claimed from this Windows test.",
}
write(STAGE / "summary.json", summary)
write(WIN / "final-image-identities.json", images)
print(json.dumps({"summary": identity(STAGE / "summary.json"), "source": summary["source"],
                  "test": summary["test"], "retained_stage_objects": len(retained),
                  "cleanup": cleanup["count"], "cleanup_bytes": cleanup["bytes"]}, indent=2))
