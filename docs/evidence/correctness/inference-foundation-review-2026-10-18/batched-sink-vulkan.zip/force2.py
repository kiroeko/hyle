from pathlib import Path
import difflib
import importlib.util
import json

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('sink_graph_runner', OUT / 'run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
canonical = (r.ROOT / 'src/compute_provider_ggml_vulkan/region.cc').read_text()
source = '#include <cstdio>\n' + canonical
needle = '  const auto v = recipe.values[node.inputs[2]].dimensions();\n'
assert source.count(needle) == 1
source = source.replace(needle, needle + '''  // Scratch-only selection: legal aligned tiny graph, no production threshold change.
  if (sink && q[0] == 2 && q[1] == 5 && q[2] == 64 && k[1] == 64) {
    std::fprintf(stderr, "FORCED_SINK_QBLOCK batch2/heads64/query5/keys64 rows2 maskRowBytes256\\n");
    return 2;
  }
''')
node = '      auto *node = ggml_graph_node(graph, i);\n'
assert source.count(node) == 1
source = source.replace(node, node + '''      if (node->op == GGML_OP_MUL_MAT)
        std::fprintf(stderr, "FORCED_MATMUL reduction=%lld rows=%lld heads=%lld batch=%lld\\n",
            (long long)node->src[0]->ne[0], (long long)node->src[1]->ne[1],
            (long long)node->ne[2], (long long)node->ne[3]);
''')
provider = OUT / 'region.force2.cc'
provider.write_text(source, encoding='utf-8', newline='\n')
test_original = (r.ROOT / 'tests/graph_route_vulkan/tensor_test.cc').read_text()
test_source = test_original
for old, new in [
    ('BatchedSinkPreservesPublishedIntermediateAcrossMaskRanksAndReplay', 'BatchedSinkForcedAlignedQueryTilesKeepBatchStrideAndTail'),
    ('for (const auto heads : {64, 128})', 'for (const auto heads : {64})'),
    ('for (const bool batched_mask : {false, true})', 'for (const bool batched_mask : {true})'),
    ('for (const auto queries : {1, 3})', 'for (const auto queries : {5})'),
    ('sink::Fixture fixture(heads, batched_mask, queries);', 'sink::Fixture fixture(heads, batched_mask, queries, 2, 64);'),
]:
    assert test_source.count(old) == 1, old
    test_source = test_source.replace(old, new)
test = OUT / 'tensor_test.force2.cc'
test.write_text(test_source, encoding='utf-8', newline='\n')
(OUT / 'forced-strategy.diff').write_text(''.join(difflib.unified_diff(
    canonical.splitlines(True), source.splitlines(True),
    fromfile='canonical/region.cc', tofile='scratch/region.force2.cc')),
    encoding='utf-8', newline='\n')
(OUT / 'forced-consumer.diff').write_text(''.join(difflib.unified_diff(
    test_original.splitlines(True), test_source.splitlines(True),
    fromfile='canonical/tensor_test.cc', tofile='scratch/tensor_test.force2.cc')),
    encoding='utf-8', newline='\n')
commands = json.loads((r.NATIVE.parent / 'commands.json').read_text())
cc = next(x['command'] for x in reversed(commands) if x['tag'] == 'vulkan-region-compile')
flags = [x for x in cc if not x.lower().startswith('/fo') and not x.endswith('region.cc')]
provider_obj = OUT / 'region.force2.obj'
test_obj = OUT / 'test.force2.obj'
r.run('force2-region-compile', [*flags, provider, '/Fo' + str(provider_obj)])
r.run('force2-tests-compile', [r.cl, *r.flags,
    '/I' + str(r.ROOT / 'tests/graph_route_vulkan'),
    test, '/Fo' + str(test_obj)])
link = next(x['command'] for x in reversed(r.records) if x['tag'] == 'link')
command = [str(provider_obj) if x == str(r.NATIVE) else
           str(test_obj) if x == str(OUT / 'tests.obj') else
           '/OUT:' + str(OUT / 'force2.exe') if x.startswith('/OUT:') else x for x in link]
r.run('force2-link', command)
r.run('force2-tests', [OUT / 'force2.exe',
    '--gtest_filter=VulkanGraph.BatchedSinkForcedAlignedQueryTilesKeepBatchStrideAndTail',
    '--gtest_color=no'])
