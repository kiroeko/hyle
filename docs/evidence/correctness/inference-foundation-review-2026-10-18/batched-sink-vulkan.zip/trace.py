from pathlib import Path
import importlib.util
import json

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('local_graph_runner', OUT / 'run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
source = (r.ROOT / 'src/compute_provider_ggml_vulkan/region.cc').read_text()
source = '#include <cstdio>\n' + source
normalization_needle = '''      } else if (const auto sink = node.operation.custom_as<model_ops::SinkAttention>()) {
        auto *query = ggml_permute(context, arguments[0], 0, 2, 1, 3);
        auto *key = ggml_permute(context, arguments[1], 0, 2, 1, 3);
'''
normalization = '''        const bool contiguous_key = ggml_is_contiguous(key);
        const bool native_pitch = key->ne[3] == 1 || key->nb[3] == key->nb[2] * key->ne[2];
        std::fprintf(stderr, "SINK_KEY_BEFORE contiguous=%d nativePitch=%d nb2=%zu nb3=%zu\\n",
            int(contiguous_key), int(native_pitch), key->nb[2], key->nb[3]);
        if (contiguous_key && !native_pitch) {
          key = ggml_reshape_4d(context, key, key->ne[0], key->ne[1], key->ne[2], key->ne[3]);
          std::fprintf(stderr, "SINK_KEY_AFTER reshape_only nb2=%zu nb3=%zu\\n", key->nb[2], key->nb[3]);
        }
'''
assert source.count(normalization_needle) == 1
source = source.replace(normalization_needle, normalization_needle + normalization)
needle = '      auto *node = ggml_graph_node(graph, i);\n'
assert source.count(needle) == 1
trace = r'''      if (node->op == GGML_OP_MUL_MAT) {
        std::fprintf(stderr, "SINK_MATMUL node=%d prec0=%d prec2=%d prec3=%d\n",
            i, node->op_params[0], node->op_params[2], node->op_params[3]);
        for (int operand = 0; operand < 2; ++operand) {
          const auto *s = node->src[operand];
          const bool dim01 = s->nb[0] == ggml_type_size(s->type) &&
              s->nb[1] == s->nb[0] * s->ne[0] / ggml_blck_size(s->type) &&
              (s->ne[3] == 1 || s->nb[3] == s->nb[2] * s->ne[2]);
          std::fprintf(stderr, "  src%d type=%s ne=[%lld,%lld,%lld,%lld] nb=[%zu,%zu,%zu,%zu] dim01=%d\n",
              operand, ggml_type_name(s->type),
              (long long)s->ne[0], (long long)s->ne[1], (long long)s->ne[2], (long long)s->ne[3],
              s->nb[0], s->nb[1], s->nb[2], s->nb[3], int(dim01));
        }
        std::fflush(stderr);
      }
'''
source = source.replace(needle, needle + trace)
snapshot = OUT / 'region.trace.cc'
snapshot.write_text(source, encoding='utf-8', newline='\n')
commands = json.loads((r.NATIVE.parent / 'commands.json').read_text())
cc = next(x['command'] for x in commands if x['tag'] == 'vulkan-region-compile')
flags = [x for x in cc if not x.lower().startswith('/fo') and not x.endswith('region.cc')]
obj = OUT / 'region.trace.obj'
r.run('trace-region-compile', [*flags, snapshot, '/Fo' + str(obj)])
link = next(x['command'] for x in reversed(r.records) if x['tag'] == 'link')
command = [str(obj) if x == str(r.NATIVE) else
           '/OUT:' + str(OUT / 'trace.exe') if x.startswith('/OUT:') else x for x in link]
r.run('trace-link', command)
r.run('trace-test', [OUT / 'trace.exe',
    '--gtest_filter=VulkanGraph.BatchedSinkPreservesPublishedIntermediateAcrossMaskRanksAndReplay',
    '--gtest_color=no'])
