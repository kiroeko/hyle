from pathlib import Path
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
IREE = ROOT / '.scratch/inference-foundation-review-2026-10-18/vulkan-official-bank'
NATIVE = ROOT / '.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/vulkan-region.obj'
base = json.loads((IREE / 'commands.json').read_text())
cc = next(x['command'] for x in base if x['tag'] == 'tests-compile')
cl = Path(cc[0])
flags = cc[1:-2]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(cl), 'CMAKE_C_COMPILER': str(cl)})
env.update(VSLANG='1033', DISABLE_VULKAN_OBS_CAPTURE='1', VK_LOADER_LAYERS_DISABLE='~all~')
env['PATH'] = str(ROOT / '.scratch/build-compute-v2-dev/bin') + os.pathsep + env['PATH']
records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def run(tag, command):
    command = list(map(str, command))
    attempt = sum(x['tag'] == tag for x in records)
    prefix = f'attempt{attempt}-' if attempt else ''
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=180)
    (OUT / (prefix + tag + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (prefix + tag + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag, command=command, exit=result.returncode,
                        seconds=time.monotonic() - start))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n',
                                      encoding='utf-8', newline='\n')
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-7000:])
        print(result.stderr.decode(errors='replace')[-1800:])
        raise SystemExit(result.returncode)


if __name__ == '__main__':
    for source, stem in [
            ('tests/graph_route_vulkan/tensor_test.cc', 'tests'),
            ('src/compute_route_vulkan/vulkan_operations.cc', 'operations'),
            ('src/compute_route_vulkan/vulkan_region.cc', 'route-region')]:
        obj = OUT / (stem + '.obj')
        if not obj.exists() or obj.stat().st_mtime < (ROOT / source).stat().st_mtime:
            run(stem + '-compile', [cl, *flags, ROOT / source, '/Fo' + str(obj)])
    assert NATIVE.is_file()
    command = []
    for arg in next(x['command'] for x in reversed(base) if x['tag'] == 'link'):
        if arg.startswith('/OUT:'):
            arg = '/OUT:' + str(OUT / 'tests.exe')
        elif arg == str(IREE / 'tests.obj'):
            continue
        elif arg.endswith('vulkan-dense-constant\\native-region.obj'):
            arg = str(NATIVE)
        elif arg.endswith('vulkan-dense-constant\\route-region.obj'):
            continue
        command.append(arg)
    command += [str(OUT / 'tests.obj'), str(OUT / 'operations.obj'),
                str(OUT / 'route-region.obj')]
    run('link', command)
    run('tests', [OUT / 'tests.exe',
        '--gtest_filter=VulkanGraph.BatchedSinkPreservesPublishedIntermediateAcrossMaskRanksAndReplay',
        '--gtest_color=no'])
