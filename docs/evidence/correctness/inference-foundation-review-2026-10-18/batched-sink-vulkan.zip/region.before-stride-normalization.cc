#include "region.h"
#include "native_graph.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <new>
#include <numeric>

#include "ggml-backend.h"
#include "ggml.h"
#include "explicit_rope.h"
#include "sink_mask.h"
#include "hyle/compute/low_precision.h"
#include "hyle/compute/model_ops.h"

namespace hyle::compute::ggml_vulkan::detail {
namespace {
// Host-only tag, ignored by the native backend. Keep it out of its TU seam.
constexpr int kBatchRuntimeRequestSlot = 11;

std::uint32_t gdn_snapshot_count(Operation operation) noexcept {
  if (const auto *gdn = operation.get_if<GatedDeltaNet>())
    return gdn->snapshot_count;
  if (const auto recurrent =
          operation.custom_as<model_ops::RecurrentGatedDeltaNet>())
    return recurrent->snapshot_count;
  return 1;
}

std::int64_t attention_query_block(const RegionRecipe &recipe,
                                   const RegionNode &node,
                                   std::uint64_t alignment) noexcept {
  const bool sink =
      node.operation.custom_as<model_ops::SinkAttention>().has_value();
  if (!sink && !node.operation.get_if<ScaledDotProductAttention>())
    return 0;
  const auto q = recipe.values[node.inputs[0]].dimensions();
  const auto k = recipe.values[node.inputs[1]].dimensions();
  const auto v = recipe.values[node.inputs[2]].dimensions();
  if (!sink && k[3] == v[3] && (k[3] == 64 || k[3] == 128 || k[3] == 256))
    return 0; // Keep the existing fused attention domain unchanged.
  // Four F32 score-sized temporaries conservatively bound each math block.
  // Divide before multiplying so even large legal descriptors cannot overflow.
  const auto threshold_rows = (8ULL << 20) / 16 / q[0] / q[2] / k[1];
  if (std::uint64_t(q[1]) <= threshold_rows)
    return 0;
  const auto budget_rows = (64ULL << 20) / 16 / q[0] / q[2] / k[1];
  const auto &query = recipe.values[node.inputs[0]];
  const auto query_pitch =
      query.data_type() == DataType::kFloat32
          ? std::uint64_t(query.byte_strides()[1])
          : std::uint64_t(q[2]) * std::uint64_t(q[3]) * sizeof(float);
  auto quantum = alignment / std::gcd(alignment, query_pitch);
  if (sink) {
    const auto &mask = recipe.values[node.inputs[3]];
    const auto mask_pitch =
        std::uint64_t(mask.byte_strides()[mask.rank() - 2]);
    quantum = std::lcm(quantum, alignment / std::gcd(alignment, mask_pitch));
  }
  // Native matmul/softmax views require aligned descriptor origins. At least
  // one aligned row quantum is needed even when one row exceeds the budget.
  const auto target = (std::min<std::uint64_t>)(128, budget_rows);
  const auto rows = (std::max)(quantum, target / quantum * quantum);
  if (rows >= std::uint64_t(q[1]))
    return 0;
  // Joining blocks needs a linear F32 output frontier. Do not trade a smaller
  // score matrix for more output storage in the small-KV / wide-value domain.
  const auto frontier = 2 * std::uint64_t(q[1]) * std::uint64_t(v[3]);
  if (std::uint64_t(k[1]) <= frontier / (std::uint64_t(q[1]) - rows))
    return 0;
  return std::int64_t(rows);
}

Result<ggml_tensor *>
tiled_math_attention(ggml_context *context, ggml_tensor *query,
                     ggml_tensor *key, ggml_tensor *value, ggml_tensor *mask,
                     ggml_tensor *sinks, float scale, bool causal,
                     std::int64_t block_rows) {
  const auto queries = query->ne[1];
  const auto heads = query->ne[2];
  const auto batch = query->ne[3];
  const auto depth = value->ne[0];
  value = ggml_cont(context, ggml_transpose(context, value));
  std::vector<ggml_tensor *> parts;
  parts.reserve(std::size_t((queries + block_rows - 1) / block_rows));
  for (std::int64_t begin = 0; begin < queries; begin += block_rows) {
    const auto rows = (std::min)(block_rows, queries - begin);
    // Preserve the full query's batch pitch, including padded resident views.
    auto *part = ggml_view_4d(context, query, query->ne[0], rows, heads, batch,
                              query->nb[1], query->nb[2], query->nb[3],
                              std::size_t(begin) * query->nb[1]);
    part = ggml_cont(context, part);
    auto *scores = ggml_mul_mat(context, key, part);
    if (!ggml_prec_set_acc(scores, GGML_PREC_F32) ||
        !ggml_prec_set_src(scores, GGML_PREC_F32, 1))
      return std::unexpected(
          Status::Unimplemented("ggml Vulkan attention score accumulation"));
    ggml_tensor *probabilities;
    if (mask) {
      auto *rows_mask = ggml_runtime::sink_mask_rows(context, mask, begin, rows);
      probabilities = ggml_soft_max_ext(context, scores, rows_mask, scale, 0.F);
      ggml_soft_max_add_sinks(probabilities, sinks);
    } else {
      scores = ggml_scale(context, scores, scale);
      if (causal)
        scores = ggml_diag_mask_inf(
            context, scores, static_cast<int>(key->ne[1] - queries + begin));
      probabilities = ggml_soft_max(context, scores);
    }
    auto *output = ggml_mul_mat(context, value, probabilities);
    if (!ggml_prec_set_acc(output, GGML_PREC_F32) ||
        !ggml_prec_set_src(output, GGML_PREC_F32, 1))
      return std::unexpected(
          Status::Unimplemented("ggml Vulkan attention value accumulation"));
    output = ggml_cont(context, ggml_permute(context, output, 0, 2, 1, 3));
    parts.push_back(
        ggml_reshape_3d(context, output, depth * heads, rows, batch));
  }
  // An explicit balanced frontier preserves dependencies for downstream nodes
  // and published intermediates. Only the final joined result is an output;
  // gallocr can retire each block's scores while retaining the linear outputs.
  while (parts.size() > 1) {
    const auto count = parts.size();
    std::size_t next = 0;
    for (std::size_t i = 0; i + 1 < count; i += 2)
      parts[next++] = ggml_concat(context, parts[i], parts[i + 1], 1);
    if (count % 2 != 0)
      parts[next++] = parts.back();
    parts.resize(next);
  }
  return ggml_reshape_4d(context, parts.front(), depth, heads, queries, batch);
}

bool runtime_attention_node(const ggml_tensor* node) noexcept {
  return node->op==GGML_OP_FLASH_ATTN_EXT &&
      node->op_params[bridge::kFlashAttentionCacheSlot]==bridge::kFlashAttentionCache &&
      node->op_params[kBatchRuntimeRequestSlot]>=0;
}
Result<std::int32_t> runtime_kv_rows(const ggml_tensor* node,
    std::span<const std::int32_t> indptr,std::span<const std::int32_t> tails) noexcept {
  const auto r=std::size_t(node->op_params[kBatchRuntimeRequestSlot]);
  if(r+1>=indptr.size() || indptr[r]<0 || indptr[r+1]<=indptr[r])
    return std::unexpected(Status::InvalidArgument("Vulkan runtime KV interval differs"));
  const bool paged=node->op_params[bridge::kFlashAttentionPagedSlot]==bridge::kFlashAttentionPaged;
  std::int64_t rows=indptr[r+1]-indptr[r];
  if(paged){
    if(r>=tails.size() || tails[r]<1 || tails[r]>16 || !node->src[5] ||
        indptr[r+1]>ggml_nelements(node->src[5]))
      return std::unexpected(Status::InvalidArgument("Vulkan runtime page table extent differs"));
    rows=(rows-1)*16+tails[r];
  }else if(!node->src[1] || !node->src[2] ||
      indptr[r+1]>node->src[1]->ne[1] || indptr[r+1]>node->src[2]->ne[1]){
    return std::unexpected(Status::InvalidArgument("Vulkan runtime ragged root extent differs"));
  }
  if(rows>INT32_MAX || (node->op_params[bridge::kFlashAttentionCausalSlot] && rows<node->src[0]->ne[1]))
    return std::unexpected(Status::InvalidArgument("Vulkan runtime logical KV extent differs"));
  return static_cast<std::int32_t>(rows);
}

bool floating(DataType type) noexcept {
  return type == DataType::kFloat32 || type == DataType::kFloat16 ||
         type == DataType::kBFloat16;
}
ggml_type native_type(DataType type) noexcept {
  if (type == DataType::kUInt8)
    return GGML_TYPE_I8;
  if (type == DataType::kFloat16)
    return GGML_TYPE_F16;
  if (type == DataType::kBFloat16)
    return GGML_TYPE_BF16;
  return type == DataType::kInt32 ? GGML_TYPE_I32 : GGML_TYPE_F32;
}
ggml_type native_quantized_type(const TensorDesc &description) noexcept {
  const auto type = gguf_quantized_type(description.storage_format());
  if (!type)
    return GGML_TYPE_COUNT;
  switch (*type) {
  case GgufQuantizedType::kQ4_0:
    return GGML_TYPE_Q4_0;
  case GgufQuantizedType::kQ4_1:
    return GGML_TYPE_Q4_1;
  case GgufQuantizedType::kQ2K:
    return GGML_TYPE_Q2_K;
  case GgufQuantizedType::kQ3K:
    return GGML_TYPE_Q3_K;
  case GgufQuantizedType::kQ4K:
    return GGML_TYPE_Q4_K;
  case GgufQuantizedType::kQ5K:
    return GGML_TYPE_Q5_K;
  case GgufQuantizedType::kQ6K:
    return GGML_TYPE_Q6_K;
  case GgufQuantizedType::kQ8_0:
    return GGML_TYPE_Q8_0;
  case GgufQuantizedType::kIq3Xxs:
    return GGML_TYPE_IQ3_XXS;
  case GgufQuantizedType::kIq2Xxs:
    return GGML_TYPE_IQ2_XXS;
  case GgufQuantizedType::kIq2Xs:
    return GGML_TYPE_IQ2_XS;
  case GgufQuantizedType::kIq2S:
    return GGML_TYPE_IQ2_S;
  case GgufQuantizedType::kIq1S:
    return GGML_TYPE_IQ1_S;
  case GgufQuantizedType::kIq1M:
    return GGML_TYPE_IQ1_M;
  case GgufQuantizedType::kIq3S:
    return GGML_TYPE_IQ3_S;
  case GgufQuantizedType::kIq4Nl:
    return GGML_TYPE_IQ4_NL;
  case GgufQuantizedType::kIq4Xs:
    return GGML_TYPE_IQ4_XS;
  case GgufQuantizedType::kMxfp4:
    return GGML_TYPE_MXFP4;
  default:
    break; // Extended IQ1 formats still need original Vulkan qualification.
  }
  return GGML_TYPE_COUNT;
}
bool native_quantized(const TensorDesc &description) noexcept {
  return native_quantized_type(description) != GGML_TYPE_COUNT;
}
bool quantized_weight_domain(const TensorDesc &description) noexcept {
  const auto type = gguf_quantized_type(description.storage_format());
  if (!type || !native_quantized(description) || description.rank() != 2 ||
      (description.data_type() != DataType::kFloat32 &&
       description.data_type() != DataType::kFloat16))
    return false;
  const auto canonical = gguf_weight_description(*type, description.data_type(),
                                                 description.dimensions()[0],
                                                 description.dimensions()[1]);
  return canonical && *canonical == description;
}
bool quantized_grouped_weight_domain(const TensorDesc &description) noexcept {
  const auto type = gguf_quantized_type(description.storage_format());
  if (!type || !native_quantized(description) || description.rank() != 3 ||
      description.data_type() != DataType::kFloat32)
    return false;
  const auto shape = description.dimensions();
  const auto canonical = gguf_grouped_weight_description(
      *type, description.data_type(), shape[0], shape[1], shape[2]);
  return canonical && *canonical == description;
}
bool native_embedding_table(const TensorDesc &description) noexcept {
  const auto type = gguf_quantized_type(description.storage_format());
  if (!type ||
      (*type != GgufQuantizedType::kQ2K && *type != GgufQuantizedType::kQ3K &&
       *type != GgufQuantizedType::kQ4_0 && *type != GgufQuantizedType::kQ4_1 &&
       *type != GgufQuantizedType::kQ5K &&
       *type != GgufQuantizedType::kQ4K && *type != GgufQuantizedType::kQ6K &&
       *type != GgufQuantizedType::kQ8_0 &&
       *type != GgufQuantizedType::kIq2Xxs && *type != GgufQuantizedType::kIq2Xs &&
       *type != GgufQuantizedType::kIq2S && *type != GgufQuantizedType::kIq1S &&
       *type != GgufQuantizedType::kIq1M &&
       *type != GgufQuantizedType::kIq3Xxs && *type != GgufQuantizedType::kIq3S &&
       *type != GgufQuantizedType::kIq4Nl && *type != GgufQuantizedType::kIq4Xs &&
       *type != GgufQuantizedType::kMxfp4) ||
      description.data_type() != DataType::kFloat32 ||
      description.rank() != 2 || description.block_axis() != 1)
    return false;
  const auto stored = gguf_weight_description(*type, DataType::kFloat32,
                                              description.dimensions()[1],
                                              description.dimensions()[0]);
  if (!stored)
    return false;
  const auto natural = stored->transposed();
  return natural && *natural == description;
}
bool resident_attention_view(const TensorDesc &description) noexcept {
  if (!description.is_plain() || description.rank() != 4 ||
      !floating(description.data_type()))
    return false;
  const auto dimensions = description.dimensions();
  if (!std::ranges::all_of(dimensions, [](auto extent) { return extent > 0; }))
    return false;
  const auto strides = description.byte_strides();
  const auto bytes = static_cast<std::int64_t>(
      data_type_size(description.data_type()));
  if (bytes == 0 || strides[3] != bytes)
    return false;
  for (std::size_t axis = 0; axis < 4; ++axis)
    if (strides[axis] <= 0 ||
        strides[axis] % bytes != 0 ||
        (axis < 3 && strides[axis] / dimensions[axis + 1] < strides[axis + 1]))
      return false;
  return true;
}
bool packed_matrix_rhs(const TensorDesc &description) noexcept {
  if (!description.is_plain() || description.rank() < 2 || description.rank() > 4 ||
      !floating(description.data_type())) return false;
  const auto transposed = description.transposed();
  return transposed && transposed->is_dense();
}
bool tensor_domain(const TensorDesc &description) noexcept {
  const bool cache = description.rank() >= 3 && description.rank() <= 4 &&
      description.block_axis() == description.rank()-1 &&
      description.storage_format() == CacheStorage::q8_0().value().format() &&
      description.data_type() == DataType::kFloat32;
  return description.valid() &&
         (cache || native_embedding_table(description) ||
          quantized_weight_domain(description) ||
          quantized_grouped_weight_domain(description) ||
          (description.is_plain() &&
           (description.is_dense() || resident_attention_view(description) ||
            packed_matrix_rhs(description)) &&
           (floating(description.data_type()) ||
            description.data_type() == DataType::kInt32))) &&
         description.element_count() && *description.element_count() > 0 &&
         *description.element_count() <= INT32_MAX;
}
bool same_shape(const TensorDesc &a, const TensorDesc &b) noexcept {
  return a.rank() == b.rank() &&
         std::ranges::equal(a.dimensions(), b.dimensions());
}

std::int64_t columns(const TensorDesc &description) noexcept {
  return description.rank() == 0 ? 1 : description.dimensions().back();
}
std::array<std::int64_t, GGML_MAX_DIMS>
native_shape(const TensorDesc &description) noexcept {
  std::array<std::int64_t, GGML_MAX_DIMS> shape{1, 1, 1, 1};
  if (description.rank() <= GGML_MAX_DIMS)
    std::ranges::reverse_copy(description.dimensions(), shape.begin());
  else {
    shape[0] = columns(description);
    shape[1] =
        static_cast<std::int64_t>(*description.element_count()) / shape[0];
  }
  return shape;
}
ggml_tensor *native_tensor(ggml_context *context,
                           const TensorDesc &description) noexcept {
  auto shape = native_shape(description);
  if (native_quantized(description)) {
    const auto blocked = description.block_axis();
    if (!blocked || description.rank() > GGML_MAX_DIMS)
      return nullptr;
    shape.fill(1);
    shape[0] = description.dimensions()[*blocked];
    std::size_t target = 1;
    for (std::size_t axis = description.rank(); axis-- > 0;)
      if (axis != *blocked)
        shape[target++] = description.dimensions()[axis];
    return ggml_new_tensor(context, native_quantized_type(description),
                           static_cast<int>(description.rank()), shape.data());
  }
  auto *tensor = ggml_new_tensor(context, native_type(description.data_type()),
                                 GGML_MAX_DIMS, shape.data());
  if (!description.is_dense())
    for (std::size_t axis = 0; axis < description.rank(); ++axis)
      tensor->nb[axis] = static_cast<std::size_t>(
          description.byte_strides()[description.rank() - axis - 1]);
  return tensor;
}
ggml_tensor *restore_shape(ggml_context *context, ggml_tensor *value,
                           const TensorDesc &description) {
  const auto shape = native_shape(description);
  if (std::ranges::equal(shape, value->ne))
    return value;
  return ggml_reshape_4d(context, value, shape[0], shape[1], shape[2],
                         shape[3]);
}
std::int64_t extent_product(std::span<const std::int64_t> shape) noexcept {
  std::int64_t result = 1;
  for (const auto extent : shape)
    result *= extent;
  return result;
}
ggml_tensor *matrix(ggml_context *context, ggml_tensor *value,
                    const TensorDesc &description) {
  const auto width = columns(description);
  const auto rows =
      static_cast<std::int64_t>(*description.element_count()) / width;
  if (value->ne[0] == width && value->ne[1] == rows && value->ne[2] == 1 &&
      value->ne[3] == 1)
    return value;
  return ggml_reshape_2d(context, value, width, rows);
}
ggml_tensor *indexed_rows(ggml_context *context, ggml_tensor *value,
                          std::int64_t inner, std::int64_t rows,
                          std::int64_t outer) {
  value = ggml_reshape_3d(context, value, inner, rows, outer);
  if (outer != 1) {
    value = ggml_permute(context, value, 0, 2, 1, 3);
    value = ggml_cont(context, value);
  }
  return ggml_reshape_2d(context, value, inner * outer, rows);
}
ggml_tensor *restore_indexed_rows(ggml_context *context, ggml_tensor *value,
                                  std::int64_t inner, std::int64_t rows,
                                  std::int64_t outer) {
  if (outer != 1) {
    value = ggml_reshape_3d(context, value, inner, outer, rows);
    value = ggml_permute(context, value, 0, 2, 1, 3);
    value = ggml_cont(context, value);
  }
  return value;
}
ggml_tensor *expand_broadcast(ggml_context *context, ggml_tensor *value,
                              const TensorDesc &source,
                              const TensorDesc &output) {
  value = matrix(context, value, source);
  const auto width = columns(output);
  const auto rows = static_cast<std::int64_t>(*output.element_count()) / width;
  if (same_shape(source, output) || *source.element_count() == 1 ||
      (value->ne[0] == width && value->ne[1] == 1) ||
      (value->ne[0] == 1 && value->ne[1] == rows))
    return value;
  std::array<std::int64_t, kMaxTensorRank> dimensions;
  dimensions.fill(1);
  std::ranges::copy(source.dimensions(),
                    dimensions.begin() + output.rank() - source.rank());
  auto shape = std::span(dimensions).first(output.rank());
  for (std::size_t i = shape.size(); i-- > 0;) {
    if (shape[i] == output.dimensions()[i])
      continue;
    const auto inner = extent_product(shape.subspan(i + 1));
    const auto outer = extent_product(shape.first(i));
    value = ggml_reshape_3d(context, value, inner, 1, outer);
    value =
        ggml_repeat_4d(context, value, inner, output.dimensions()[i], outer, 1);
    shape[i] = output.dimensions()[i];
  }
  return matrix(context, value, output);
}
ggml_tensor *reduction_rows(ggml_context *context, ggml_tensor *value,
                            const TensorDesc &source, Axes axes) {
  std::array<bool, kMaxTensorRank> selected{};
  std::array<std::int64_t, kMaxTensorRank> dimensions{};
  std::ranges::copy(source.dimensions(), dimensions.begin());
  auto shape = std::span(dimensions).first(source.rank());
  if (axes.is_all())
    std::fill_n(selected.begin(), source.rank(), true);
  else
    for (const auto axis : axes.values())
      selected[axis < 0 ? axis + static_cast<int>(source.rank()) : axis] = true;
  std::int64_t width = 1;
  for (std::size_t i = 0; i < shape.size(); ++i)
    if (selected[i])
      width *= shape[i];
  // Move selected dimension groups to the suffix. Shape arithmetic is cold;
  // actual data permutation belongs to the original Vulkan cont operation.
  auto target = shape.size();
  for (auto end = shape.size(); end != 0;) {
    if (!selected[end - 1]) {
      --end;
      continue;
    }
    auto begin = end - 1;
    while (begin != 0 && selected[begin - 1])
      --begin;
    if (end != target) {
      const auto outer = extent_product(shape.first(begin));
      const auto group = extent_product(shape.subspan(begin, end - begin));
      const auto between = extent_product(shape.subspan(end, target - end));
      const auto inner = extent_product(shape.subspan(target));
      value = ggml_view_4d(
          context, value, inner, group, between, outer,
          static_cast<std::size_t>(inner * between) * sizeof(float),
          static_cast<std::size_t>(inner) * sizeof(float),
          static_cast<std::size_t>(inner * between * group) * sizeof(float), 0);
      value = ggml_cont(context, value);
      std::rotate(shape.begin() + begin, shape.begin() + end,
                  shape.begin() + target);
    }
    target -= end - begin;
    end = begin;
  }
  return ggml_reshape_2d(context, value, width,
                         static_cast<std::int64_t>(*source.element_count()) /
                             width);
}
ggml_unary_op unary_operation(UnaryKind kind) noexcept {
  switch (kind) {
  case UnaryKind::kAbs:
    return GGML_UNARY_OP_ABS;
  case UnaryKind::kNeg:
    return GGML_UNARY_OP_NEG;
  case UnaryKind::kExp:
    return GGML_UNARY_OP_EXP;
  case UnaryKind::kTanh:
    return GGML_UNARY_OP_TANH;
  case UnaryKind::kSigmoid:
    return GGML_UNARY_OP_SIGMOID;
  case UnaryKind::kSilu:
    return GGML_UNARY_OP_SILU;
  case UnaryKind::kSoftplus:
    return GGML_UNARY_OP_SOFTPLUS;
  default:
    return GGML_UNARY_OP_COUNT;
  }
}
struct Imports final {
  NativeDevice device;
  std::vector<ggml_backend_buffer *> buffers;
  std::vector<ggml_backend_buffer *> constants;
  std::size_t constant_bytes = 0;
  ~Imports() {
    auto active = device.activate();
    for (auto *buffer : buffers)
      ggml_backend_buffer_free(buffer);
    for (auto *buffer : constants)
      ggml_backend_buffer_free(buffer);
  }
};
} // namespace

Status PagedAttentionRead::infer_output_descriptions(
    std::span<const TensorDesc> inputs,
    std::span<TensorDesc> outputs) const noexcept {
  if(compact_mla){
    if(!paged || inputs.size()!=3 || inputs[1].rank()!=4 ||
        !inputs[1].is_dense() || inputs[1].dimensions()[2]!=1 ||
        (inputs[1].dimensions()[3]!=512 && inputs[1].dimensions()[3]!=576))
      return Status::InvalidArgument("Vulkan MLA needs its truthful single packed cache");
    const auto k=inputs[1].dimensions();
    HYLE_ASSIGN_OR_RETURN(auto value,TensorDesc::strided_bytes(inputs[1].data_type(),
        std::array<std::int64_t,4>{k[0],k[1],1,512},inputs[1].byte_strides()));
    auto full=*this;full.compact_mla=false;
    return full.infer_output_descriptions(std::array{inputs[0],inputs[1],value,inputs[2]},outputs);
  }
  if (inputs.size() != (paged ? 4u : 3u) || outputs.size() != 1 || !logical_rows ||
      logical_rows > INT32_MAX || !std::isfinite(scale) ||
      inputs[0].rank() != 4 || inputs[1].rank() != (paged?4u:3u) ||
      inputs[2].rank() != inputs[1].rank() || window_left < -1 || (!causal && window_left != -1) ||
      (paged && (!inputs[3].is_dense() || inputs[3].rank() != 1 ||
                 inputs[3].data_type() != DataType::kInt32)))
    return Status::InvalidArgument("Vulkan paged read domain");
  const auto q = inputs[0].dimensions(), k = inputs[1].dimensions(), v = inputs[2].dimensions();
  const auto heads=k[k.size()-2], value_heads=v[v.size()-2];
  const auto physical_rows=paged?std::uint64_t(k[0])*std::uint64_t(k[1]):std::uint64_t(k[0]);
  const auto refs = (std::uint64_t(logical_rows) + 15) / 16;
  if (q[0] != 1 || k[0] <= 0 || k[0] != v[0] ||
      heads <= 0 || heads != value_heads || q[2] <= 0 || q[2] % heads || q[3] != k.back() ||
      (paged && (k[1] != 16 || v[1] != 16)) || (!paged && std::uint64_t(table_offset)+logical_rows > physical_rows) ||
      q[1] <= 0 || (causal && std::uint64_t(q[1]) > logical_rows) ||
      (paged && std::uint64_t(table_offset) + refs >
          std::uint64_t(inputs[3].dimensions()[0])))
    return Status::InvalidArgument("Vulkan paged logical/table bounds");
  const bool plain = inputs[1].is_plain() && inputs[2].is_plain() &&
      inputs[1].data_type() == DataType::kFloat16 && inputs[2].data_type() == DataType::kFloat16;
  const auto q8 = CacheStorage::q8_0().value();
  const auto key_cache = cache_tensor_description(q8,k), value_cache = cache_tensor_description(q8,v);
  const bool encoded = key_cache && value_cache && inputs[1] == *key_cache && inputs[2] == *value_cache;
  if (!inputs[0].is_plain() || inputs[0].data_type() != DataType::kFloat16 ||
      (!plain && !encoded) ||
      !((q[3] == v.back() && (q[3] == 64 || q[3] == 128 || q[3] == 256)) ||
        (q[3] == 64 && v.back() == 128) ||
        (plain && v.back() == 512 && (q[3] == 512 || q[3] == 576))))
    return Status::Unimplemented("Vulkan paged qualified F16 flash depth");
  HYLE_ASSIGN_OR_RETURN(outputs[0],TensorDesc::dense(DataType::kFloat16,
      std::array<std::int64_t,4>{1,q[1],q[2],v.back()}));
  return Status::Ok();
}

bool region_supports(const Operation &operation,
                     std::span<const TensorDesc> inputs,
                     std::span<const TensorDesc> outputs) noexcept {
  if (const auto encode = operation.custom_as<model_ops::CacheEncode>()) {
    std::array<TensorDesc,1> inferred;
    return encode->storage == CacheStorage::q8_0().value() && inputs.size()==1 &&
        inputs[0].is_dense() && inputs[0].data_type()==DataType::kFloat32 &&
        tensor_domain(inputs[0]) && outputs.size()==1 &&
        infer_output_descriptions(operation,inputs,inferred).ok() && outputs[0]==inferred[0];
  }
  if (inputs.empty() || outputs.empty() ||
      !std::ranges::all_of(outputs, tensor_domain) ||
      !std::ranges::all_of(inputs, tensor_domain))
    return false;
  // Padded resident ports belong to SDPA; MatMul separately checks its exact
  // packed RHS layout. Other operations retain their dense/encoded domain.
  if (!operation.get_if<ScaledDotProductAttention>() &&
      !operation.custom_as<PagedAttentionRead>() && !operation.get_if<MatMul>() &&
      (!std::ranges::all_of(inputs, [](const auto &input) {
        return !input.is_plain() || input.is_dense();
      }) || !std::ranges::all_of(outputs, [](const auto &output) {
        return !output.is_plain() || output.is_dense();
      })))
    return false;
  const bool grouped =
      operation.custom_as<model_ops::GroupedMatMul>().has_value();
  const bool embedding =
      operation.get_if<Gather>() && native_embedding_table(inputs[0]);
  if (!operation.get_if<MatMul>() && !grouped && !operation.custom_as<PagedAttentionRead>() &&
      !embedding && (!std::ranges::all_of(inputs, [](const auto &input) {
        return input.is_plain();
      }) || !std::ranges::all_of(outputs, [](const auto &output) {
        return output.is_plain();
      })))
    return false;
  if (const auto paged = operation.custom_as<PagedAttentionRead>()) {
    std::array<TensorDesc, 1> inferred;
    return outputs.size() == 1 && paged->infer_output_descriptions(inputs, inferred).ok() &&
           inferred[0] == outputs[0];
  }
  if (const auto *view = operation.get_if<View>())
    return view->kind() == ViewKind::kReshape && inputs.size() == 1 &&
           outputs.size() == 1 && inputs[0].is_plain() && outputs[0].is_plain() &&
           inputs[0].rank() <= GGML_MAX_DIMS && outputs[0].rank() <= GGML_MAX_DIMS &&
           inputs[0].data_type() == outputs[0].data_type() &&
           (inputs[0].data_type() == DataType::kFloat32 ||
            inputs[0].data_type() == DataType::kFloat16) &&
           inputs[0].element_count() == outputs[0].element_count();
  if (operation.get_if<Copy>())
    return inputs.size() == 1 && outputs.size() == 1 &&
           outputs[0].data_type() == inputs[0].data_type();
  if (operation.get_if<Concat>())
    return outputs.size() == 1 &&
           std::ranges::all_of(inputs, [&](const auto &input) {
             return input.data_type() == outputs[0].data_type();
           });
  if (operation.get_if<Cast>())
    return inputs.size() == 1 && outputs.size() == 1 &&
           floating(inputs[0].data_type()) &&
           floating(outputs[0].data_type()) &&
           (outputs[0].data_type() != DataType::kBFloat16 ||
            inputs[0].data_type() == DataType::kBFloat16);
  if (operation.custom_as<model_ops::Clamp>()) {
    std::array<TensorDesc, 1> inferred;
    return outputs.size() == 1 &&
           infer_output_descriptions(operation, inputs, inferred).ok() &&
           inferred[0] == outputs[0];
  }
  if (operation.custom_as<model_ops::SinkAttention>()) {
    std::array<TensorDesc, 1> inferred;
    return outputs.size() == 1 &&
           infer_output_descriptions(operation, inputs, inferred).ok() &&
           inferred[0] == outputs[0] &&
           ggml_runtime::sink_score_elements(inputs[0].dimensions(), inputs[1].dimensions()) <=
               std::size_t{INT32_MAX} / sizeof(float);
  }
  if (operation.custom_as<model_ops::CausalConv1d>())
    return inputs.size() == 2 && outputs.size() == 1 &&
           inputs[0].data_type() == DataType::kFloat32 &&
           inputs[1].data_type() == DataType::kFloat32 &&
           outputs[0].data_type() == DataType::kFloat32;
  if (grouped) {
    if (inputs.size() != 3 || outputs.size() != 1)
      return false;
    if (quantized_grouped_weight_domain(inputs[0]))
      return inputs[1].is_plain() && inputs[1].is_dense() &&
             inputs[1].data_type() == DataType::kFloat32 &&
             inputs[2].is_plain() && inputs[2].is_dense() &&
             inputs[2].data_type() == DataType::kInt32 &&
             outputs[0].is_plain() && outputs[0].is_dense() &&
             outputs[0].data_type() == DataType::kFloat32;
    return inputs[0].is_plain() && inputs[0].is_dense() &&
           (inputs[0].data_type() == DataType::kFloat32 ||
            inputs[0].data_type() == DataType::kBFloat16) &&
           inputs[1].is_plain() && inputs[1].is_dense() &&
           inputs[1].data_type() == DataType::kFloat32 &&
           inputs[2].is_plain() && inputs[2].is_dense() &&
           inputs[2].data_type() == DataType::kInt32 &&
           outputs[0].is_plain() && outputs[0].is_dense() &&
           outputs[0].data_type() == DataType::kFloat32;
  }
  if (operation.custom_as<model_ops::BFloatLinearF32>())
    return inputs.size() == 2 && outputs.size() == 1 &&
           outputs[0].data_type() == DataType::kFloat32;
  if (operation.custom_as<model_ops::HyperConnectionCombine>() ||
      operation.custom_as<model_ops::HyperConnectionPre>() ||
      operation.custom_as<model_ops::HyperConnectionPost>())
    return outputs.size() == 1 &&
           std::ranges::all_of(
               inputs,
               [](const auto &description) {
                 return description.is_dense() &&
                        (description.data_type() == DataType::kFloat32 ||
                         description.data_type() == DataType::kInt32);
               }) &&
           outputs[0].data_type() == DataType::kFloat32;
  if (operation.custom_as<model_ops::LightningIndexer>())
    return outputs.size() == 1 && inputs.size() == 4 && inputs[0].is_dense() &&
           inputs[1].is_dense() && inputs[2].is_dense() &&
           inputs[3].is_dense() &&
           inputs[0].data_type() == DataType::kFloat32 &&
           inputs[1].data_type() == DataType::kFloat32 &&
           inputs[2].data_type() == DataType::kFloat32 &&
           inputs[3].data_type() == DataType::kFloat16 &&
           outputs[0].data_type() == DataType::kFloat32;
  if (const auto *matmul = operation.get_if<MatMul>()) {
    if (inputs.size() == 2 && quantized_weight_domain(inputs[1]))
      return inputs.size() == 2 && outputs.size() == 1 &&
             matmul->accumulation_type == DataType::kFloat32 &&
             inputs[0].rank() == 2 && inputs[0].is_plain() &&
             inputs[0].is_dense() && outputs[0].rank() == 2 &&
             outputs[0].is_plain() && outputs[0].is_dense() &&
             inputs[0].data_type() == inputs[1].data_type() &&
             outputs[0].data_type() == inputs[0].data_type() &&
             (inputs[0].data_type() == DataType::kFloat32 ||
              inputs[0].data_type() == DataType::kFloat16);
    if (inputs.size() != 2 || outputs.size() != 1 ||
        matmul->accumulation_type != DataType::kFloat32 ||
        inputs[0].rank() < 2 || inputs[0].rank() > GGML_MAX_DIMS ||
        inputs[1].rank() < 2 || inputs[1].rank() > GGML_MAX_DIMS ||
        !inputs[0].is_dense() ||
        (!inputs[1].is_dense() && !packed_matrix_rhs(inputs[1])) ||
        !outputs[0].is_dense() ||
        inputs[0].data_type() != inputs[1].data_type() ||
        outputs[0].data_type() != inputs[0].data_type() ||
        !floating(inputs[0].data_type()))
      return false;
    std::array<std::int64_t, 2> left_batch{1, 1}, right_batch{1, 1};
    const auto fill_batch = [](const TensorDesc &description,
                               std::array<std::int64_t, 2> &batch) {
      const auto count = description.rank() - 2;
      for (std::size_t i = 0; i < count; ++i)
        batch[2 - count + i] = description.dimensions()[i];
    };
    fill_batch(inputs[0], left_batch);
    fill_batch(inputs[1], right_batch);
    return left_batch[0] % right_batch[0] == 0 &&
           left_batch[1] % right_batch[1] == 0;
  }
  if (const auto *rope = operation.get_if<RoPE>())
    return inputs.size() == 3 && outputs.size() == 1 && inputs[0].rank() == 4 &&
           (rope->sequence_axis == 1 || rope->sequence_axis == -3) &&
           inputs[0].is_dense() &&
           (inputs[0].data_type() == DataType::kFloat32 ||
            inputs[0].data_type() == DataType::kFloat16) &&
           inputs[1].rank() <= 2 && inputs[1].data_type() == DataType::kInt32 &&
           inputs[2].rank() <= 2 &&
           inputs[2].data_type() == DataType::kFloat32 &&
           outputs[0] == inputs[0];
  if (const auto *hadamard = operation.get_if<Hadamard>()) {
    const auto width = inputs[0].dimensions().back();
    return inputs.size() == 1 && outputs.size() == 1 && inputs[0].is_dense() &&
           outputs[0] == inputs[0] &&
           (inputs[0].data_type() == DataType::kFloat32 ||
            inputs[0].data_type() == DataType::kFloat16) &&
           hadamard->accumulation_type == DataType::kFloat32 &&
           (width == 64 || width == 128 || width == 256 || width == 512);
  }
  if (const auto *attention = operation.get_if<ScaledDotProductAttention>()) {
    if (inputs.size() != 3 || outputs.size() != 1 ||
        attention->layout != AttentionLayout::kBatchSequenceHeadDepth ||
        attention->mask != MaskKind::kNone ||
        attention->accumulation_type != DataType::kFloat32 ||
        !std::isfinite(attention->scale))
      return false;
    const auto type = inputs[0].data_type();
    if (type != DataType::kFloat32 && type != DataType::kFloat16)
      return false;
    for (const auto &input : inputs)
      if (!resident_attention_view(input) || input.data_type() != type)
        return false;
    const auto query = inputs[0].dimensions();
    const auto key = inputs[1].dimensions();
    const auto value = inputs[2].dimensions();
    const std::array mla_shape{query[0], query[1], query[2], std::int64_t{512}};
    const auto mla_output = TensorDesc::dense(DataType::kFloat32, mla_shape);
    const bool absorbed_mla = type == DataType::kFloat32 &&
        (query[2] == 64 || query[2] == 96) &&
        key[2] == 1 && query[3] == 576 && value[3] == 512 && value[0] == key[0] &&
        value[1] == key[1] && value[2] == key[2] && mla_output && outputs[0] == *mla_output;
    return query[0] == key[0] && query[1] > 0 && key[1] >= query[1] &&
           query[2] > 0 && key[2] > 0 && query[2] % key[2] == 0 &&
           query[3] == key[3] &&
           outputs[0].is_dense() && outputs[0].data_type() == type &&
           ((same_shape(inputs[1], inputs[2]) &&
             same_shape(outputs[0], inputs[0])) || absorbed_mla);
  }
  const bool recurrent =
      operation.custom_as<model_ops::RecurrentGatedDeltaNet>().has_value();
  if (operation.get_if<GatedDeltaNet>() || recurrent) {
    std::array<TensorDesc, 2> inferred;
    if (inputs.size() != (recurrent ? 8U : 6U) || outputs.size() != 2 ||
        !infer_output_descriptions(operation, inputs, inferred).ok() ||
        !std::ranges::equal(inferred, outputs) ||
        !std::ranges::all_of(inputs, [](const auto &input) {
          return input.rank() == 4 && input.data_type() == DataType::kFloat32;
        }))
      return false;
    const auto q = inputs[0].dimensions();
    const auto v = inputs[2].dimensions();
    const auto depth = q[3];
    const auto scores = *outputs[0].element_count();
    const auto states = *outputs[1].element_count();
    return v[2] % q[2] == 0 && depth == v[3] &&
           (depth == 16 || depth == 32 || depth == 64 || depth == 128) &&
           outputs[0].data_type() == DataType::kFloat32 &&
           outputs[1].data_type() == DataType::kFloat32 &&
           scores <= std::size_t{INT32_MAX} &&
           states <= std::size_t{INT32_MAX} - scores;
  }
  if (const auto *topk = operation.get_if<TopK>())
    return inputs.size() == 1 && outputs.size() == 2 && inputs[0].rank() > 0 &&
           inputs[0].rank() <= GGML_MAX_DIMS &&
           inputs[0].data_type() == DataType::kFloat32 &&
           outputs[0].data_type() == DataType::kFloat32 &&
           outputs[1].data_type() == DataType::kInt32 &&
           (topk->axis == -1 ||
            topk->axis == static_cast<std::int32_t>(inputs[0].rank()) - 1);
  if (const auto gather = operation.custom_as<model_ops::GatherElements>()) {
    std::array<TensorDesc,1> inferred;
    return inputs.size()==2 && outputs.size()==1 && inputs[0].rank()==2 &&
           (gather->axis==1 || gather->axis==-1) &&
           gather->bounds==IndexBoundsPolicy::kUnchecked &&
           gather->infer_output_descriptions(inputs,inferred).ok() && outputs[0]==inferred[0];
  }
  if (const auto *gather = operation.get_if<Gather>()) {
    if (native_embedding_table(inputs[0]))
      return inputs.size() == 2 && outputs.size() == 1 &&
             gather->bounds == IndexBoundsPolicy::kUnchecked &&
             (gather->axis == 0 || gather->axis == -2) &&
             inputs[1].is_plain() && inputs[1].is_dense() &&
             inputs[1].data_type() == DataType::kInt32 &&
             inputs[1].rank() == 1 && outputs[0].is_plain() &&
             outputs[0].is_dense() &&
             outputs[0].data_type() == DataType::kFloat32 &&
             outputs[0].rank() == 2 &&
             outputs[0].dimensions()[0] == inputs[1].dimensions()[0] &&
             outputs[0].dimensions()[1] == inputs[0].dimensions()[1];
    return inputs.size() == 2 && outputs.size() == 1 &&
           gather->bounds == IndexBoundsPolicy::kUnchecked &&
           (gather->axis == 0 || gather->axis == -2) &&
           inputs[0].data_type() == DataType::kInt32 && inputs[0].rank() == 2 &&
           inputs[1].data_type() == DataType::kInt32 && inputs[1].rank() == 1 &&
           outputs[0].data_type() == DataType::kInt32;
  }
  if (const auto *scatter = operation.get_if<Scatter>())
    return inputs.size() == 3 && outputs.size() == 1 &&
           scatter->kind == ScatterKind::kAdd &&
           scatter->bounds == IndexBoundsPolicy::kUnchecked &&
           inputs[1].data_type() == DataType::kInt32 &&
           (inputs[0].data_type() == DataType::kFloat32 ||
            inputs[0].data_type() == DataType::kFloat16) &&
           inputs[2].data_type() == inputs[0].data_type() &&
           outputs[0].data_type() == inputs[0].data_type();
  if (outputs.size() != 1 ||
      (outputs[0].data_type() != DataType::kFloat32 &&
       outputs[0].data_type() != DataType::kFloat16) ||
      !std::ranges::all_of(inputs, [](const auto &input) {
        return floating(input.data_type());
      }))
    return false;
  if (const auto *norm = operation.get_if<RmsNorm>())
    return norm->accumulation_type == DataType::kFloat32;
  if (const auto *norm = operation.get_if<LayerNorm>())
    return norm->accumulation_type == DataType::kFloat32;
  if (const auto *reduce = operation.get_if<Reduce>()) {
    return inputs.size() == 1 && inputs[0].rank() > 0 &&
           (reduce->kind == ReductionKind::kSum ||
            reduce->kind == ReductionKind::kMean) &&
           (reduce->accumulation_type == DataType::kFloat32 ||
            reduce->accumulation_type == DataType::kUnknown);
  }
  if (const auto *softmax = operation.get_if<Softmax>())
    return inputs[0].rank() > 0 && softmax->kind == SoftmaxKind::kSoftmax &&
           (softmax->accumulation_type == DataType::kFloat32 ||
            softmax->accumulation_type == DataType::kUnknown) &&
           ((softmax->mask == MaskKind::kNone && inputs.size() == 1) ||
            (softmax->mask == MaskKind::kAdditive && inputs.size() == 2 &&
             inputs[0].data_type() == inputs[1].data_type()));
  if (const auto *scan = operation.get_if<Scan>())
    return inputs.size() == 1 && inputs[0].data_type() == DataType::kFloat32 &&
           outputs[0].data_type() == DataType::kFloat32 &&
           inputs[0].rank() > 0 && inputs[0].rank() <= GGML_MAX_DIMS &&
           !scan->exclusive &&
           (scan->axis == -1 ||
            scan->axis == static_cast<std::int32_t>(inputs[0].rank()) - 1);
  if (const auto *unary = operation.get_if<Unary>())
    return unary_operation(unary->kind) != GGML_UNARY_OP_COUNT ||
           unary->kind == UnaryKind::kLog || unary->kind == UnaryKind::kSqrt ||
           unary->kind == UnaryKind::kRsqrt;
  if (const auto *binary = operation.get_if<Binary>())
    return inputs.size() == 2 && (binary->kind == BinaryKind::kAdd ||
                                  binary->kind == BinaryKind::kSubtract ||
                                  binary->kind == BinaryKind::kMultiply ||
                                  binary->kind == BinaryKind::kDivide);
  if (const auto *gate = operation.get_if<GatedActivation>())
    return gate->activation == GatedActivationKind::kSilu;
  return false;
}

struct Region::State final {
  NativeDevice device;
  std::shared_ptr<Imports> imports;
  std::vector<ggml_tensor *> ports;
  std::vector<std::size_t> port_alignments;
  std::vector<ggml_tensor *> views;
  NativeGraph graph;
  NativeWork work; // Retires before graph/imports/device.
  bool bound = false;
  bool pending = false;
};

Result<Region> Region::create(NativeDevice device,
                              const RegionRecipe &recipe) noexcept {
  if (!device || recipe.nodes.empty() || recipe.outputs.empty() ||
      recipe.values.size() > INT32_MAX / 8 ||
      recipe.nodes.size() > INT32_MAX / 16)
    return std::unexpected(
        Status::InvalidArgument("ggml Vulkan region recipe"));
  try {
    std::vector<bool> available(recipe.values.size(), false);
    for (const auto input : recipe.inputs) {
      if (input >= available.size() || available[input] ||
          !tensor_domain(recipe.values[input]))
        return std::unexpected(
            Status::InvalidArgument("ggml Vulkan region input"));
      available[input] = true;
    }
    for (const auto &node : recipe.nodes) {
      if (node.outputs.size() != operation_traits(node.operation).outputs)
        return std::unexpected(
            Status::InvalidArgument("ggml Vulkan region SSA"));
      std::vector<TensorDesc> inputs;
      for (const auto input : node.inputs) {
        if (input >= available.size() || !available[input])
          return std::unexpected(
              Status::InvalidArgument("ggml Vulkan region topology"));
        inputs.push_back(recipe.values[input]);
      }
      std::vector<TensorDesc> inferred(node.outputs.size());
      HYLE_RETURN_IF_ERROR(
          infer_output_descriptions(node.operation, inputs, inferred));
      if (!region_supports(node.operation, inputs, inferred))
        return std::unexpected(
            Status::Unimplemented("ggml Vulkan region semantic domain"));
      for (std::size_t port = 0; port < node.outputs.size(); ++port) {
        const auto output = node.outputs[port];
        if (output >= available.size() || available[output] ||
            inferred[port] != recipe.values[output])
          return std::unexpected(
              Status::InvalidArgument("ggml Vulkan region output SSA/schema"));
        available[output] = true;
      }
    }
    std::vector<bool> published(recipe.values.size(), false);
    for (const auto output : recipe.outputs) {
      if (output >= available.size() || !available[output] ||
          published[output] ||
          std::ranges::find(recipe.inputs, output) != recipe.inputs.end())
        return std::unexpected(
            Status::InvalidArgument("ggml Vulkan region output"));
      published[output] = true;
    }
    // TopK/Scan: at most 10/16 nodes including reshape/view/cont adapters.
    // LayerNorm: input reshape, GroupNorm, restored shape, optional Mul/Add.
    // Row reduction: up to three exact row pieces, concat and shape restore.
    // GatedDeltaNet: fused native result, two views and two owning ports.
    // Other operations need at most three (Rsqrt: Fill, Sqrt, Div).
    // Each published alias may need its own owning export tensor.
    auto capacity = recipe.inputs.size() + recipe.outputs.size() + 16;
    for (const auto &node : recipe.nodes) {
      capacity += node.operation.custom_as<model_ops::RecurrentGatedDeltaNet>() ? 9
                  : node.operation.get_if<Scan>()            ? 16
                  : node.operation.get_if<Reduce>()        ? 12
                  : node.operation.get_if<Scatter>()       ? 10
                  : node.operation.get_if<TopK>()          ? 10
                  : node.operation.custom_as<model_ops::GatherElements>() ? 8
                  : node.operation.get_if<LayerNorm>()     ? 5
                  : node.operation.get_if<GatedDeltaNet>() ? 5
                                                           : 3;
      if (gdn_snapshot_count(node.operation) > 1)
        capacity += 3; // Snapshot matrix, immutable row indices and GET_ROWS.
      // Layout translations use at most four nodes per public dimension and
      // two per input port, in addition to the established native recipe.
      auto rank = recipe.values[node.outputs[0]].rank();
      for (const auto input : node.inputs)
        rank = (std::max)(rank, recipe.values[input].rank());
      capacity += 4 * rank + 2 * node.inputs.size() + 4;
      if (const auto rows = attention_query_block(
              recipe, node, device.native().storage_buffer_alignment)) {
        const auto queries = recipe.values[node.inputs[0]].dimensions()[1];
        const auto blocks = std::size_t((queries + rows - 1) / rows);
        // Includes query/mask views, math, layout adapters and balanced joins.
        if (capacity > INT32_MAX / 4 ||
            blocks > (INT32_MAX / 4 - capacity) / 16)
          return std::unexpected(
              Status::ResourceExhausted("ggml Vulkan attention node capacity"));
        capacity += 16 * blocks;
      }
    }
    if (capacity > INT32_MAX / 4)
      return std::unexpected(
          Status::ResourceExhausted("ggml Vulkan region node capacity"));
    const auto graph_bytes = ggml_graph_overhead_custom(capacity, false);
    if (capacity > (SIZE_MAX - graph_bytes) / ggml_tensor_overhead())
      return std::unexpected(
          Status::ResourceExhausted("ggml Vulkan region metadata capacity"));
    HYLE_ASSIGN_OR_RETURN(
        auto arena,
        MetadataArena::create(capacity * ggml_tensor_overhead() + graph_bytes,
                              mem::system_allocator()));
    Region result;
    result.state_ = std::make_shared<State>();
    auto &state = *result.state_;
    state.device = std::move(device);
    state.imports = std::make_shared<Imports>();
    state.imports->device = state.device;
    const auto port_count = recipe.inputs.size() + recipe.outputs.size();
    state.ports.reserve(port_count);
    state.imports->buffers.reserve(port_count);
    auto active = state.device.activate();
    auto *context = arena.get();
    std::vector<ggml_tensor *> tensors(recipe.values.size());
    for (const auto input : recipe.inputs) {
      const auto &description = recipe.values[input];
      tensors[input] = native_tensor(context, description);
      if (tensors[input] == nullptr)
        return std::unexpected(
            Status::Unimplemented("ggml Vulkan input tensor description"));
      ggml_set_input(tensors[input]);
      state.ports.push_back(tensors[input]);
    }
    for (const auto &node : recipe.nodes) {
      const bool arithmetic =
          node.operation.get_if<Unary>() || node.operation.get_if<Binary>() ||
          node.operation.get_if<GatedActivation>() ||
          node.operation.get_if<RmsNorm>() ||
          node.operation.get_if<LayerNorm>() ||
          node.operation.get_if<Reduce>() || node.operation.get_if<Softmax>();
      std::vector<ggml_tensor *> arguments;
      arguments.reserve(node.inputs.size());
      for (const auto input : node.inputs) {
        auto *value = tensors[input];
        arguments.push_back(arithmetic && value->type != GGML_TYPE_F32
                                ? ggml_cast(context, value, GGML_TYPE_F32)
                                : value);
      }
      auto *left = arguments[0];
      ggml_tensor *output = nullptr;
      if (node.operation.custom_as<model_ops::CacheEncode>()) {
        auto *encoded = ggml_cast(context,left,GGML_TYPE_Q8_0);
        encoded->op_params[bridge::kCacheEncoderCopySlot]=bridge::kCacheEncoderCopyExact;
        // Publish the exact block34 bytes through the original U8 carrier.
        // This is a native storage alias of the producer, with no payload copy.
        output = ggml_view_4d(context, encoded, encoded->ne[0], encoded->ne[1],
                              encoded->ne[2], encoded->ne[3], encoded->nb[1],
                              encoded->nb[2], encoded->nb[3], 0);
        output->type = GGML_TYPE_I8;
        const auto shape = native_shape(recipe.values[node.outputs[0]]);
        std::ranges::copy(shape,output->ne);
        output->nb[0]=1;
        for(std::size_t axis=1;axis<GGML_MAX_DIMS;++axis)
          output->nb[axis]=output->nb[axis-1]*std::size_t(output->ne[axis-1]);
      } else if (node.operation.get_if<View>()) {
        // A qualified dense reshape stays inside the original graph; the
        // common shape restoration below creates only the native view.
        output = left;
      } else if (node.operation.get_if<Copy>()) {
        output = ggml_dup(context, left);
      } else if (const auto *cast = node.operation.get_if<Cast>()) {
        const auto target = native_type(cast->output_type);
        if (left->type == target)
          output = ggml_dup(context, left);
        else {
          if (left->type != GGML_TYPE_F32 && target != GGML_TYPE_F32)
            left = ggml_cast(context, left, GGML_TYPE_F32);
          output = ggml_cast(context, left, target);
        }
      } else if (const auto *concat = node.operation.get_if<Concat>()) {
        const auto &description = recipe.values[node.outputs[0]];
        const auto axis = static_cast<std::size_t>(
            concat->axis < 0
                ? concat->axis + static_cast<int>(description.rank())
                : concat->axis);
        const auto inner =
            extent_product(description.dimensions().subspan(axis + 1));
        const auto outer = extent_product(description.dimensions().first(axis));
        std::vector<ggml_tensor *> parts;
        parts.reserve(node.inputs.size());
        for (const auto input : node.inputs)
          parts.push_back(ggml_reshape_3d(
              context, tensors[input], inner,
              recipe.values[input].dimensions()[axis], outer));
        if (parts.size() == 1) {
          output = ggml_dup(context, parts.front());
        } else {
          // Balanced native dependencies avoid copying each growing prefix;
          // gallocr continues to own intermediate payload reuse.
          while (parts.size() > 1) {
            const auto count = parts.size();
            std::size_t next = 0;
            for (std::size_t i = 0; i + 1 < count; i += 2)
              parts[next++] = ggml_concat(context, parts[i], parts[i + 1], 1);
            if (count % 2 != 0)
              parts[next++] = parts.back();
            parts.resize(next);
          }
          output = parts.front();
        }
      } else if (const auto clamp = node.operation.custom_as<model_ops::Clamp>()) {
        output = ggml_clamp(context, arguments[0], clamp->minimum, clamp->maximum);
      } else if (node.operation.custom_as<model_ops::CausalConv1d>()) {
        auto *samples =
            ggml_cont(context, ggml_permute(context, arguments[0], 1, 0, 2, 3));
        output = ggml_ssm_conv(context, samples, arguments[1]);
      } else if (node.operation.custom_as<model_ops::GroupedMatMul>()) {
        output =
            ggml_mul_mat_id(context, arguments[0], arguments[1], arguments[2]);
        if (!ggml_prec_set_acc(output, GGML_PREC_F32))
          return std::unexpected(Status::Unimplemented(
              "original ggml grouped F32 accumulation unavailable"));
        if (arguments[0]->type == GGML_TYPE_F32 &&
            arguments[1]->type == GGML_TYPE_F32 &&
            !ggml_prec_set_src(output, GGML_PREC_F32, 1))
          return std::unexpected(Status::Unimplemented(
              "original ggml grouped F32 operands unavailable"));
      } else if (const auto descriptor =
                     node.operation
                         .custom_as<model_ops::HyperConnectionCombine>()) {
        output =
            ggml_dsv4_hc_comb(context, arguments[0], arguments[1], arguments[2],
                              descriptor->epsilon, descriptor->iterations);
      } else if (node.operation.custom_as<model_ops::HyperConnectionPre>()) {
        output = ggml_dsv4_hc_pre(context, arguments[0], arguments[1]);
      } else if (node.operation.custom_as<model_ops::HyperConnectionPost>()) {
        output = ggml_dsv4_hc_post(context, arguments[0], arguments[1],
                                   arguments[2], arguments[3]);
      } else if (node.operation.custom_as<model_ops::LightningIndexer>()) {
        output = ggml_lightning_indexer(context, arguments[0], arguments[1],
                                        arguments[2], arguments[3]);
      } else if (node.operation.get_if<MatMul>() ||
                 node.operation.custom_as<model_ops::BFloatLinearF32>()) {
        // The fixed upstream Vulkan small-matvec selector admits a BF16
        // activation for up to eight rows (or one native row per batch), but
        // its selected pipeline
        // accepts only F32/F16/Q8_1 on that port. Keep the BF16 weight and
        // FP32 accumulation while widening only the tiny activation boundary;
        // otherwise the backend aborts instead of returning unsupported.
        const bool small_matvec =
            left->ne[1] == 1 ||
            (left->ne[1] <= 8 && left->ne[2] * left->ne[3] == 1);
        if (left->type == GGML_TYPE_BF16 && small_matvec)
          left = ggml_cast(context, left, GGML_TYPE_F32);
        auto *right = arguments[1];
        const bool quantized =
            quantized_weight_domain(recipe.values[node.inputs[1]]);
        if (node.operation.get_if<MatMul>() && !quantized) {
          right = ggml_transpose(context, right);
          if (!ggml_is_contiguous(right))
            right = ggml_cont(context, right);
          else if (ggml_is_transposed(right))
            // A unit axis can be contiguous despite its inherited transpose
            // stride. Rebuild dense unit strides with the original zero-copy
            // view before ggml_mul_mat checks its stronger input contract.
            right = ggml_reshape_4d(context, right, right->ne[0], right->ne[1],
                                    right->ne[2], right->ne[3]);
        }
        auto *product = ggml_mul_mat(context, right, left);
        if (!ggml_prec_set_acc(product, GGML_PREC_F32))
          return std::unexpected(
              Status::Unimplemented("ggml Vulkan MatMul F32 accumulation"));
        if (right->type == GGML_TYPE_F32 && left->type == GGML_TYPE_F32 &&
            !ggml_prec_set_src(product, GGML_PREC_F32, 1))
          return std::unexpected(
              Status::Unimplemented("ggml Vulkan MatMul F32 operands"));
        const auto target =
            native_type(recipe.values[node.outputs[0]].data_type());
        output = product->type == target ? product
                                         : ggml_cast(context, product, target);
      } else if (const auto *rope = node.operation.get_if<RoPE>()) {
        output = ggml_runtime::explicit_rope(
            context, left, arguments[1], arguments[2], rope->rotary_dimensions,
            rope->layout == RopeLayout::kInterleaved);
      } else if (node.operation.get_if<Hadamard>()) {
        const auto width = recipe.values[node.inputs[0]].dimensions().back();
        auto *source = left->type == GGML_TYPE_F32
                           ? left
                           : ggml_cast(context, left, GGML_TYPE_F32);
        auto *transform =
            ggml_new_tensor_2d(context, GGML_TYPE_F32, width, width);
        output = ggml_mul_mat(context, transform, source);
        ggml_mul_mat_set_hint(output, GGML_HINT_SRC0_IS_HADAMARD);
        if (!ggml_prec_set_acc(output, GGML_PREC_F32))
          return std::unexpected(
              Status::Unimplemented("ggml Vulkan Hadamard F32 accumulation"));
        if (recipe.values[node.outputs[0]].data_type() == DataType::kFloat16)
          output = ggml_cast(context, output, GGML_TYPE_F16);
      } else if (const auto sink = node.operation.custom_as<model_ops::SinkAttention>()) {
        auto *query = ggml_permute(context, arguments[0], 0, 2, 1, 3);
        auto *key = ggml_permute(context, arguments[1], 0, 2, 1, 3);
        auto *value = ggml_permute(context, arguments[2], 0, 2, 1, 3);
        auto *mask = ggml_runtime::sink_mask(context, arguments[3]);
        if (const auto rows = attention_query_block(
                recipe, node, state.device.native().storage_buffer_alignment)) {
          HYLE_ASSIGN_OR_RETURN(output,
              tiled_math_attention(context, query, key, value, mask,
                                   arguments[4], sink->scale, false, rows));
        } else {
          query = ggml_cont(context, query);
          auto *scores = ggml_mul_mat(context, key, query);
          if (!ggml_prec_set_acc(scores, GGML_PREC_F32) ||
              !ggml_prec_set_src(scores, GGML_PREC_F32, 1))
            return std::unexpected(Status::Unimplemented("ggml Vulkan sink attention score accumulation"));
          auto *probabilities = ggml_soft_max_ext(context, scores, mask, sink->scale, 0.0F);
          ggml_soft_max_add_sinks(probabilities, arguments[4]);
          value = ggml_cont(context, ggml_transpose(context, value));
          output = ggml_mul_mat(context, value, probabilities);
          if (!ggml_prec_set_acc(output, GGML_PREC_F32) ||
              !ggml_prec_set_src(output, GGML_PREC_F32, 1))
            return std::unexpected(Status::Unimplemented("ggml Vulkan sink attention value accumulation"));
          output = ggml_cont(context, ggml_permute(context, output, 0, 2, 1, 3));
        }
      } else if (const auto paged = node.operation.custom_as<PagedAttentionRead>()) {
        auto *query = ggml_permute(context,
            ggml_cast(context, arguments[0], GGML_TYPE_F32), 0, 2, 1, 3);
        const auto root=[&](ggml_tensor* tensor){return ggml_view_4d(context,tensor,
            tensor->ne[0],tensor->ne[1],tensor->ne[2]*tensor->ne[3],1,
            tensor->nb[1],tensor->nb[2],tensor->nb[3]*std::size_t(tensor->ne[3]),0);};
        auto *key = ggml_permute(context, root(arguments[1]), 0, 2, 1, 3);
        auto *value_root=paged->compact_mla?ggml_view_4d(context,arguments[1],512,
            arguments[1]->ne[1],arguments[1]->ne[2],arguments[1]->ne[3],
            arguments[1]->nb[1],arguments[1]->nb[2],arguments[1]->nb[3],0):arguments[2];
        auto *value = ggml_permute(context, root(value_root), 0, 2, 1, 3);
        output = ggml_flash_attn_ext(context, query, key, value, nullptr,
                                    paged->scale, 0.0F, 0.0F);
        if (paged->paged) output->src[5] = arguments[paged->compact_mla?2:3];
        output->op_params[bridge::kFlashAttentionMathSlot] = bridge::kFlashAttentionFullF32;
        output->op_params[bridge::kFlashAttentionPagedSlot] = paged->paged ? bridge::kFlashAttentionPaged : 0;
        output->op_params[bridge::kFlashAttentionLogicalRowsSlot] = static_cast<std::int32_t>(paged->logical_rows);
        output->op_params[bridge::kFlashAttentionTableOffsetSlot] = static_cast<std::int32_t>(paged->table_offset);
        output->op_params[bridge::kFlashAttentionCausalSlot] = paged->causal;
        output->op_params[bridge::kFlashAttentionWindowSlot] = paged->window_left;
        output->op_params[bridge::kFlashAttentionCacheSlot] = bridge::kFlashAttentionCache;
        output->op_params[kBatchRuntimeRequestSlot] = paged->runtime_request == UINT32_MAX
            ? -1 : static_cast<std::int32_t>(paged->runtime_request);
        if (!ggml_prec_set_acc(output, GGML_PREC_F32))
          return std::unexpected(Status::Unimplemented("Vulkan paged flash accumulation"));
        output = ggml_cast(context, output, GGML_TYPE_F16);
      } else if (const auto *attention =
                     node.operation.get_if<ScaledDotProductAttention>()) {
        auto *query = ggml_permute(
            context, left->type == GGML_TYPE_F32
                         ? left : ggml_cast(context, left, GGML_TYPE_F32),
            0, 2, 1, 3);
        auto *key = ggml_permute(context, arguments[1], 0, 2, 1, 3);
        auto *value = ggml_permute(context, arguments[2], 0, 2, 1, 3);
        if (key->ne[0] == value->ne[0] &&
            (key->ne[0] == 64 || key->ne[0] == 128 || key->ne[0] == 256)) {
          output = ggml_flash_attn_ext(context, query, key, value, nullptr,
                                       attention->scale, 0.0F, 0.0F);
          output->op_params[bridge::kFlashAttentionMathSlot] =
              bridge::kFlashAttentionFullF32;
          if (attention->causal) {
            // The existing scalar FullF32 shader applies bottom-right causal
            // bounds directly to ordinary KV rows; no Q-by-KV mask is needed.
            output->op_params[bridge::kFlashAttentionLogicalRowsSlot] =
                static_cast<std::int32_t>(key->ne[1]);
            output->op_params[bridge::kFlashAttentionTableOffsetSlot] = 0;
            output->op_params[bridge::kFlashAttentionCausalSlot] = 1;
            // A window spanning all KV preserves the unrestricted left edge
            // and lets the existing shader skip wholly future causal tiles.
            output->op_params[bridge::kFlashAttentionWindowSlot] =
                static_cast<std::int32_t>(key->ne[1] - 1);
            output->op_params[bridge::kFlashAttentionCacheSlot] =
                bridge::kFlashAttentionCache;
            // This is a fixed ordinary op, not a runtime batch request.
            output->op_params[kBatchRuntimeRequestSlot] = -1;
          }
          if (!ggml_prec_set_acc(output, GGML_PREC_F32))
            return std::unexpected(Status::Unimplemented(
                "ggml Vulkan fused attention accumulation"));
        } else {
          key = ggml_cast(context, key, GGML_TYPE_F32);
          value = ggml_cast(context, value, GGML_TYPE_F32);
          if (const auto rows = attention_query_block(
                recipe, node, state.device.native().storage_buffer_alignment)) {
            HYLE_ASSIGN_OR_RETURN(output,
                tiled_math_attention(context, query, key, value, nullptr,
                                     nullptr, attention->scale,
                                     attention->causal, rows));
          } else {
            query = ggml_cont(context, query);
          auto *scores = ggml_mul_mat(context, key, query);
            if (!ggml_prec_set_acc(scores, GGML_PREC_F32) ||
                !ggml_prec_set_src(scores, GGML_PREC_F32, 1))
              return std::unexpected(Status::Unimplemented(
                  "ggml Vulkan attention score accumulation"));
            scores = ggml_scale(context, scores, attention->scale);
            if (attention->causal)
              scores = ggml_diag_mask_inf(
                  context, scores, static_cast<int>(key->ne[1] - query->ne[1]));
            auto *probabilities = ggml_soft_max(context, scores);
            value = ggml_cont(context, ggml_transpose(context, value));
            output = ggml_mul_mat(context, value, probabilities);
            if (!ggml_prec_set_acc(output, GGML_PREC_F32) ||
                !ggml_prec_set_src(output, GGML_PREC_F32, 1))
              return std::unexpected(Status::Unimplemented(
                  "ggml Vulkan attention value accumulation"));
            output = ggml_cont(context, ggml_permute(context, output, 0, 2, 1, 3));
          }
        }
        if (recipe.values[node.outputs[0]].data_type() == DataType::kFloat16)
          output = ggml_cast(context, output, GGML_TYPE_F16);
      } else if (node.operation.get_if<GatedDeltaNet>() ||
                 node.operation.custom_as<model_ops::RecurrentGatedDeltaNet>()) {
        auto *value = arguments[2];
        auto *gate = arguments[3];
        auto *beta = arguments[4];
        auto *initial = arguments[5];
        if (node.operation.custom_as<model_ops::RecurrentGatedDeltaNet>()) {
          gate = ggml_mul(context,
                          ggml_softplus(context,
                                        ggml_add(context, gate, arguments[6])),
                          arguments[5]);
          beta = ggml_sigmoid(context, beta);
          initial = arguments[7];
        }
        auto *fused = ggml_gated_delta_net(
            context, left, arguments[1], value, gate, beta, initial,
            gdn_snapshot_count(node.operation));
        // Upstream owns the fused recurrence and concatenates scores/state.
        // Published ports have independent storage; initial state stays
        // read-only.
        auto *scores = ggml_view_4d(context, fused, value->ne[0], value->ne[1],
                                    value->ne[2], value->ne[3], value->nb[1],
                                    value->nb[2], value->nb[3], 0);
        output = ggml_cont(context, scores);
        const auto snapshots = gdn_snapshot_count(node.operation);
        if (snapshots == 1) {
          auto *next =
              ggml_view_4d(context, fused, initial->ne[0], initial->ne[1],
                           initial->ne[2], initial->ne[3], initial->nb[1],
                           initial->nb[2], initial->nb[3], ggml_nbytes(value));
          tensors[node.outputs[1]] = ggml_cont(context, next);
        } else {
          const auto batch = initial->ne[3];
          const auto row = ggml_nelements(initial) / batch;
          const auto rows = batch * snapshots;
          auto *history = ggml_view_2d(
              context, fused, row, rows, std::size_t(row) * sizeof(float),
              ggml_nbytes(value));
          auto *indices = ggml_new_tensor_1d(context, GGML_TYPE_I32, rows);
          std::vector<std::int32_t> order(static_cast<std::size_t>(rows));
          for (std::int64_t b = 0; b < batch; ++b)
            for (std::uint32_t k = 0; k < snapshots; ++k)
              order[std::size_t(b * snapshots + k)] =
                  static_cast<std::int32_t>((snapshots - 1 - k) * batch + b);
          // Native slots are [K,B,H,Dv,Dk], newest first. Gather complete
          // per-batch states into public [B,K,H,Dv,Dk], oldest first. Keep
          // these shape-only indices outside gallocr's reusable workspace.
          state.imports->constants.push_back(nullptr);
          HYLE_ASSIGN_OR_RETURN(
              state.imports->constants.back(),
              state.device.allocate_buffer(ggml_nbytes(indices) +
                  state.device.native().storage_buffer_alignment));
          auto *buffer = state.imports->constants.back();
          const auto buffer_bytes = ggml_backend_buffer_get_size(buffer);
          if (buffer_bytes > SIZE_MAX - state.imports->constant_bytes)
            return std::unexpected(Status::OutOfRange(
                "ggml Vulkan snapshot constant storage overflows"));
          state.imports->constant_bytes += buffer_bytes;
          if (ggml_backend_tensor_alloc(buffer, indices,
                                        ggml_backend_buffer_get_base(buffer)) !=
              GGML_STATUS_SUCCESS)
            return std::unexpected(Status::ResourceExhausted(
                "ggml Vulkan snapshot index allocation"));
          try {
            ggml_backend_tensor_set(indices, order.data(), 0,
                                    order.size() * sizeof(order[0]));
          } catch (...) {
            return std::unexpected(Status::Internal(
                "ggml Vulkan snapshot index upload failed"));
          }
          auto *next = ggml_get_rows(context, history, indices);
          tensors[node.outputs[1]] =
              restore_shape(context, next, recipe.values[node.outputs[1]]);
        }
      } else if (const auto *topk = node.operation.get_if<TopK>()) {
        const auto width = left->ne[0];
        const auto rows = ggml_nelements(left) / width;
        const auto count = static_cast<std::int64_t>(topk->count);
        auto *matrix = ggml_reshape_2d(context, left, width, rows);
        auto *sorted = ggml_argsort(context, matrix,
                                    topk->largest ? GGML_SORT_ORDER_DESC
                                                  : GGML_SORT_ORDER_ASC);
        auto *selected =
            ggml_view_2d(context, sorted, count, rows, sorted->nb[1], 0);
        std::int64_t shape[GGML_MAX_DIMS]{1, 1, 1, 1};
        std::ranges::reverse_copy(recipe.values[node.outputs[0]].dimensions(),
                                  shape);
        auto *indices = ggml_cont_4d(context, selected, shape[0], shape[1],
                                     shape[2], shape[3]);
        auto *row_indices = ggml_reshape_2d(context, indices, count, rows);
        // Reinterpret 32-bit storage, never numerically convert scores to I32.
        // Original GET_ROWS(I32) uses uint loads/stores, retaining NaN
        // payloads, signed zeros and subnormals. Contiguous published tensors
        // own ports.
        auto *raw = ggml_reshape_2d(context, matrix, width, rows);
        raw->type = GGML_TYPE_I32;
        auto *scalars = ggml_reshape_3d(context, raw, 1, width, rows);
        auto *gathered = ggml_get_rows(context, scalars, row_indices);
        auto *floats = ggml_reshape_4d(context, gathered, 1, count, rows, 1);
        floats->type = GGML_TYPE_F32;
        output = ggml_cont_4d(context, floats, shape[0], shape[1], shape[2],
                              shape[3]);
        tensors[node.outputs[1]] = indices;
      } else if (node.operation.custom_as<model_ops::GatherElements>()) {
        const auto width=left->ne[0],rows=left->ne[1];
        const auto count=arguments[1]->ne[0];
        auto* indices=ggml_reshape_2d(context,arguments[1],count,rows);
        // F32 uses the original GET_ROWS(I32) bit carrier, just like TopK.
        // Narrow floating inputs are exactly representable in its F32 output.
        auto* raw=ggml_reshape_3d(context,left,1,width,rows);
        if(left->type==GGML_TYPE_F32)raw->type=GGML_TYPE_I32;
        auto* selected=ggml_get_rows(context,raw,indices);
        auto* values=ggml_reshape_2d(context,selected,count,rows);
        if(left->type==GGML_TYPE_F32)values->type=GGML_TYPE_F32;
        output=ggml_cont_2d(context,values,count,rows);
        if(left->type!=GGML_TYPE_F32)
          output=ggml_cast(context,output,left->type);
      } else if (node.operation.get_if<Gather>()) {
        output = ggml_get_rows(context, left, arguments[1]);
      } else if (const auto *scatter = node.operation.get_if<Scatter>()) {
        const auto &base = recipe.values[node.inputs[0]];
        const auto axis = static_cast<std::size_t>(
            scatter->axis < 0
                ? scatter->axis + static_cast<std::int32_t>(base.rank())
                : scatter->axis);
        const auto inner = extent_product(base.dimensions().subspan(axis + 1));
        const auto outer = extent_product(base.dimensions().first(axis));
        const auto extent = base.dimensions()[axis];
        const auto count = static_cast<std::int64_t>(
            *recipe.values[node.inputs[1]].element_count());
        auto *base_value =
            arguments[0]->type == GGML_TYPE_F32
                ? arguments[0]
                : ggml_cast(context, arguments[0], GGML_TYPE_F32);
        auto *update_value =
            arguments[2]->type == GGML_TYPE_F32
                ? arguments[2]
                : ggml_cast(context, arguments[2], GGML_TYPE_F32);
        auto *base_rows =
            indexed_rows(context, base_value, inner, extent, outer);
        auto *update_rows =
            indexed_rows(context, update_value, inner, count, outer);
        auto *indices = ggml_reshape_1d(context, arguments[1], count);
        auto *delta =
            ggml_get_rows_back(context, update_rows, indices, base_rows);
        output = restore_indexed_rows(
            context, ggml_add(context, base_rows, delta), inner, extent, outer);
        if (base.data_type() == DataType::kFloat16)
          output = ggml_cast(context, output, GGML_TYPE_F16);
      } else if (node.operation.get_if<Scan>()) {
        const auto width = left->ne[0];
        const auto rows = ggml_nelements(left) / width;
        const auto tile = rows > 262144 ? 262144 : 512;
        if (rows > 512 && rows % tile != 0) {
          // Original single-pass CUMSUM rounds the XYZ row dispatch and has
          // no row guard. At most three native pieces cover it exactly.
          auto *matrix = ggml_reshape_2d(context, left, width, rows);
          std::int64_t offset = 0;
          while (offset < rows) {
            const auto remaining = rows - offset;
            const auto block = remaining > 262144 ? 262144
                               : remaining > 512  ? 512
                                                  : 1;
            const auto count = remaining / block * block;
            auto *part = ggml_view_2d(context, matrix, width, count,
                                      matrix->nb[1], offset * matrix->nb[1]);
            // The multi-pass variant requires descriptor-aligned storage.
            if (offset != 0)
              part = ggml_cont(context, part);
            part = ggml_cumsum(context, part);
            output = output ? ggml_concat(context, output, part, 1) : part;
            offset += count;
          }
          if (left->ne[2] != 1 || left->ne[3] != 1)
            output = ggml_cont_4d(context, output, left->ne[0], left->ne[1],
                                  left->ne[2], left->ne[3]);
        } else {
          output = ggml_cumsum(context, left);
        }
      } else if (const auto *reduce = node.operation.get_if<Reduce>()) {
        left = reduction_rows(context, left, recipe.values[node.inputs[0]],
                              reduce->axes);
        const auto row_reduce = [&](ggml_tensor *value) {
          return reduce->kind == ReductionKind::kMean
                     ? ggml_mean(context, value)
                     : ggml_sum_rows(context, value);
        };
        const auto rows = ggml_nelements(left) / left->ne[0];
        const auto tile = rows > 262144 ? 262144 : 512;
        if (rows > 512 && rows % tile != 0) {
          // SUM_ROWS has no padded-row guard. Preserve the upstream kernel,
          // dispatching at most three exact XYZ row tiles, as for CUMSUM.
          auto *matrix = ggml_reshape_2d(context, left, left->ne[0], rows);
          std::int64_t offset = 0;
          while (offset < rows) {
            const auto remaining = rows - offset;
            const auto block = remaining > 262144 ? 262144
                               : remaining > 512  ? 512
                                                  : 1;
            const auto count = remaining / block * block;
            auto *part = ggml_view_2d(context, matrix, left->ne[0], count,
                                      matrix->nb[1], offset * matrix->nb[1]);
            part = row_reduce(part);
            output = output ? ggml_concat(context, output, part, 1) : part;
            offset += count;
          }
          if (left->ne[2] != 1 || left->ne[3] != 1)
            output = ggml_cont_4d(context, output, 1, left->ne[1], left->ne[2],
                                  left->ne[3]);
        } else {
          output = row_reduce(left);
        }
      } else if (const auto *softmax = node.operation.get_if<Softmax>()) {
        const auto &description = recipe.values[node.inputs[0]];
        const auto axis = static_cast<std::size_t>(
            softmax->axis < 0
                ? softmax->axis + static_cast<int>(description.rank())
                : softmax->axis);
        const auto width = description.dimensions()[axis];
        const auto inner =
            extent_product(description.dimensions().subspan(axis + 1));
        const auto outer = extent_product(description.dimensions().first(axis));
        const auto rows = [&](ggml_tensor *value) {
          if (inner != 1) {
            value = ggml_reshape_3d(context, value, inner, width, outer);
            value =
                ggml_cont(context, ggml_permute(context, value, 1, 0, 2, 3));
          }
          return ggml_reshape_2d(context, value, width, inner * outer);
        };
        left = rows(left);
        ggml_tensor *mask = nullptr;
        if (node.inputs.size() == 2) {
          mask = expand_broadcast(context, arguments[1],
                                  recipe.values[node.inputs[1]], description);
          // Binary can broadcast a scalar/row/column directly. Softmax needs
          // the complete logical mask before changing its selected axis.
          if (ggml_nelements(mask) != ggml_nelements(left))
            mask = ggml_repeat_4d(context, mask, columns(description),
                                  ggml_nelements(left) / columns(description),
                                  1, 1);
          mask = rows(mask);
          // The public contract rounds the scale multiplication before mask
          // addition. A separate original Scale prevents fused-multiply-add.
          if (softmax->scale != 1.0F)
            left = ggml_scale(context, left, softmax->scale);
        }
        output = ggml_soft_max_ext(context, left, mask,
                                   mask ? 1.0F : softmax->scale, 0.0F);
        if (inner != 1) {
          output = ggml_reshape_3d(context, output, width, inner, outer);
          output =
              ggml_cont(context, ggml_permute(context, output, 1, 0, 2, 3));
        }
      } else if (const auto *norm = node.operation.get_if<RmsNorm>()) {
        output = ggml_rms_norm(context, left, norm->epsilon);
        if (node.inputs.size() > 1)
          output = ggml_mul(context, output, arguments[1]);
      } else if (const auto *layer = node.operation.get_if<LayerNorm>()) {
        // Original GroupNorm computes centered variance. One group per batch
        // makes each last-axis row a group without changing the shader.
        const auto rows = ggml_nelements(left) / left->ne[0];
        auto *grouped = ggml_reshape_4d(context, left, left->ne[0], 1, 1, rows);
        output = ggml_group_norm(context, grouped, 1, layer->epsilon);
        if (node.inputs.size() == 1) {
          // A published port must own storage, not alias an internal result.
          output = ggml_cont_4d(context, output, left->ne[0], left->ne[1],
                                left->ne[2], left->ne[3]);
        } else {
          output = ggml_reshape_4d(context, output, left->ne[0], left->ne[1],
                                   left->ne[2], left->ne[3]);
          output = ggml_mul(context, output, arguments[1]);
          if (node.inputs.size() > 2)
            output = ggml_add(context, output, arguments[2]);
        }
      } else if (const auto *unary = node.operation.get_if<Unary>()) {
        if (unary->kind == UnaryKind::kLog)
          output = ggml_log(context, left);
        else if (unary->kind == UnaryKind::kSqrt)
          output = ggml_sqrt(context, left);
        else if (unary->kind == UnaryKind::kRsqrt)
          output = ggml_div(context, ggml_fill(context, left, 1.0F),
                            ggml_sqrt(context, left));
        else
          output = ggml_unary(context, left, unary_operation(unary->kind));
      } else if (const auto *gate = node.operation.get_if<GatedActivation>()) {
        output = gate->inputs == GatedInputKind::kPackedHalves
                     ? ggml_swiglu(context, left)
                     : ggml_swiglu_split(context, left, arguments[1]);
      } else {
        auto *right = arguments[1];
        const auto kind = node.operation.get_if<Binary>()->kind;
        const auto &description = recipe.values[node.outputs[0]];
        if (description.rank() > GGML_MAX_DIMS) {
          left = expand_broadcast(context, left, recipe.values[node.inputs[0]],
                                  description);
          right = expand_broadcast(context, right,
                                   recipe.values[node.inputs[1]], description);
          const auto width = columns(description);
          const auto rows =
              static_cast<std::int64_t>(*description.element_count()) / width;
          if (left->ne[0] != width || left->ne[1] != rows)
            left = ggml_repeat_4d(context, left, width, rows, 1, 1);
        } else if (!same_shape(recipe.values[node.inputs[0]],
                               recipe.values[node.outputs[0]])) {
          if ((kind == BinaryKind::kAdd || kind == BinaryKind::kMultiply) &&
              same_shape(recipe.values[node.inputs[1]], description))
            std::swap(left, right);
          else {
            // ggml broadcasts only RHS. Preserve noncommutative order by
            // materializing LHS in the vendor graph and allocator.
            const auto shape = native_shape(description);
            left = ggml_repeat_4d(context, left, shape[0], shape[1], shape[2],
                                  shape[3]);
          }
        }
        switch (kind) {
        case BinaryKind::kAdd:
          output = ggml_add(context, left, right);
          break;
        case BinaryKind::kSubtract:
          output = ggml_sub(context, left, right);
          break;
        case BinaryKind::kMultiply:
          output = ggml_mul(context, left, right);
          break;
        case BinaryKind::kDivide:
          output = ggml_div(context, left, right);
          break;
        default:
          return std::unexpected(
              Status::Internal("ggml Vulkan unqualified binary recipe"));
        }
      }
      if (arithmetic &&
          output->type !=
              native_type(recipe.values[node.outputs[0]].data_type()))
        output =
            ggml_cast(context, output,
                      native_type(recipe.values[node.outputs[0]].data_type()));
      tensors[node.outputs[0]] =
          restore_shape(context, output, recipe.values[node.outputs[0]]);
    }
    auto *graph = ggml_new_graph_custom(context, capacity, false);
    for (const auto output : recipe.outputs) {
      auto *value = tensors[output];
      auto *root = value;
      while (root->view_src)
        root = root->view_src;
      // Public ports bind independent caller storage. A second export of a
      // native root must not replace an input or another output's binding.
      if (std::ranges::find(state.ports, root) != state.ports.end()) {
        value = ggml_dup(context, value);
        root = value;
      }
      ggml_set_output(value);
      // Shape restoration is a view. Bind the actual producer and protect a
      // published intermediate from native fusion and allocator reuse.
      ggml_set_output(root);
      ggml_build_forward_expand(graph, value);
      state.ports.push_back(root);
    }
    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {
      auto *node = ggml_graph_node(graph, i);
      if (node->view_src)
        state.views.push_back(node);
      if (node->op != GGML_OP_FLASH_ATTN_EXT ||
          node->op_params[bridge::kFlashAttentionMathSlot] !=
              bridge::kFlashAttentionFullF32)
        continue;
      const auto alignment = (std::max)(
          std::size_t{16}, static_cast<std::size_t>(
                              state.device.native().storage_buffer_alignment));
      for (std::size_t source = 0; source < 3; ++source) {
        auto *tensor = node->src[source];
        const auto pitch_alignment = tensor->type == GGML_TYPE_Q8_0 ? 2u : 16u;
        for (std::size_t axis = 1; axis < 4; ++axis)
          if (tensor->ne[axis] > 1 && tensor->nb[axis] % pitch_alignment != 0)
            return std::unexpected(
                Status::Unimplemented("ggml Vulkan flash vec4 pitch"));
        if (tensor->view_offs % alignment != 0)
          return std::unexpected(Status::Unimplemented(
              "ggml Vulkan flash view origin alignment"));
        while (tensor->view_src)
          tensor = tensor->view_src;
        const auto port = std::ranges::find(state.ports, tensor);
        if (port == state.ports.end())
          continue;
        if (state.port_alignments.empty())
          state.port_alignments.resize(state.ports.size(), sizeof(float));
        state.port_alignments[static_cast<std::size_t>(port -
                                                     state.ports.begin())] =
            alignment;
      }
    }
    for (auto *tensor : state.ports) {
      HYLE_ASSIGN_OR_RETURN(auto buffer,
                            state.device.binding_buffer(ggml_nbytes(tensor)));
      state.imports->buffers.push_back(buffer);
      if (ggml_backend_tensor_alloc(buffer, tensor,
                                    ggml_backend_buffer_get_base(buffer)) !=
          GGML_STATUS_SUCCESS)
        return std::unexpected(
            Status::Internal("ggml Vulkan region port storage"));
    }
    HYLE_ASSIGN_OR_RETURN(state.graph,
                          NativeGraph::allocate(state.device, std::move(arena),
                                                graph, state.imports));
    if (state.imports->constant_bytes > SIZE_MAX - state.graph.storage_bytes())
      return std::unexpected(
          Status::OutOfRange("ggml Vulkan region storage overflows"));
    HYLE_ASSIGN_OR_RETURN(state.work, state.device.create_work());
    return result;
  } catch (const std::bad_alloc &) {
    return std::unexpected(
        Status::ResourceExhausted("ggml Vulkan typed region"));
  }
}

Status Region::validate_batch_layout(std::span<const std::int32_t> indptr,
    std::span<const std::int32_t> tails) const noexcept {
  if(!state_ || state_->pending)
    return Status::FailedPrecondition("Vulkan runtime layout requires an idle region");
  auto active=state_->device.activate();auto* graph=state_->graph.get();
  for(int i=0;i<ggml_graph_n_nodes(graph);++i){
    const auto* node=ggml_graph_node(graph,i);if(!runtime_attention_node(node))continue;
    if(auto rows=runtime_kv_rows(node,indptr,tails);!rows)return rows.error();
  }
  return Status::Ok();
}
Status Region::update_batch_layout(std::span<const std::int32_t> indptr,
    std::span<const std::int32_t> tails) noexcept {
  HYLE_RETURN_IF_ERROR(validate_batch_layout(indptr,tails));
  auto active=state_->device.activate();auto* graph=state_->graph.get();bool changed=false;
  for(int i=0;i<ggml_graph_n_nodes(graph);++i){
    const auto* node=ggml_graph_node(graph,i);if(!runtime_attention_node(node))continue;
    const auto r=std::size_t(node->op_params[kBatchRuntimeRequestSlot]);
    changed=changed || runtime_kv_rows(node,indptr,tails).value()!=node->op_params[bridge::kFlashAttentionLogicalRowsSlot] ||
        indptr[r]!=node->op_params[bridge::kFlashAttentionTableOffsetSlot];
  }
  if(!changed)return Status::Ok();
  HYLE_RETURN_IF_ERROR(state_->work.invalidate_recording());
  // Preflight completed for every tagged node; the caller serializes control.
  for(int i=0;i<ggml_graph_n_nodes(graph);++i){
    auto* node=ggml_graph_node(graph,i);if(!runtime_attention_node(node))continue;
    const auto r=std::size_t(node->op_params[kBatchRuntimeRequestSlot]);
    node->op_params[bridge::kFlashAttentionLogicalRowsSlot]=runtime_kv_rows(node,indptr,tails).value();
    node->op_params[bridge::kFlashAttentionTableOffsetSlot]=indptr[r];
  }
  return Status::Ok();
}

Status
Region::validate(std::span<const RegionBinding> bindings) const noexcept {
  if (!state_ || state_->pending || bindings.size() != state_->ports.size())
    return Status::FailedPrecondition("ggml Vulkan region binding state");
  auto active = state_->device.activate();
  for (std::size_t i = 0; i < bindings.size(); ++i) {
    const auto &port = bindings[i];
    if (port.handle == VK_NULL_HANDLE && !port.owner)
      continue;
    const auto base = reinterpret_cast<std::uintptr_t>(
        ggml_backend_buffer_get_base(state_->imports->buffers[i]));
    if (port.handle == VK_NULL_HANDLE || !port.owner ||
        port.offset % sizeof(float) ||
        (!state_->port_alignments.empty() &&
         port.offset % state_->port_alignments[i]) ||
        (ggml_is_quantized(state_->ports[i]->type) &&
         port.offset % state_->device.native().storage_buffer_alignment) ||
        port.capacity < ggml_nbytes(state_->ports[i]) ||
        port.offset > SIZE_MAX - port.capacity ||
        port.offset > UINTPTR_MAX - base)
      return Status::InvalidArgument("ggml Vulkan region native buffer range");
  }
  return Status::Ok();
}

Status Region::bind(std::span<const RegionBinding> bindings) noexcept {
  HYLE_RETURN_IF_ERROR(validate(bindings));
  auto active = state_->device.activate();
  bool changed = false;
  for (std::size_t i = 0; i < bindings.size(); ++i) {
    const auto &port = bindings[i];
    auto *buffer = state_->imports->buffers[i];
    const auto size = port.handle ? port.offset + port.capacity
                                  : ggml_nbytes(state_->ports[i]);
    const auto origin =
        reinterpret_cast<std::uintptr_t>(ggml_backend_buffer_get_base(buffer)) +
        port.offset;
    changed =
        changed ||
        !bridge::binding_matches(buffer, port.handle, size, port.owner) ||
        reinterpret_cast<std::uintptr_t>(state_->ports[i]->data) != origin;
  }
  if (changed)
    HYLE_RETURN_IF_ERROR(state_->work.invalidate_recording());
  for (std::size_t i = 0; i < bindings.size(); ++i) {
    const auto &port = bindings[i];
    auto *buffer = state_->imports->buffers[i];
    const auto size = port.handle ? port.offset + port.capacity
                                  : ggml_nbytes(state_->ports[i]);
    state_->device.bind_buffer(buffer, port.handle, size, port.owner);
    state_->ports[i]->data = reinterpret_cast<void *>(
        reinterpret_cast<std::uintptr_t>(ggml_backend_buffer_get_base(buffer)) +
        port.offset);
  }
  // ggml flattens view_src to the allocation root. Refresh the already frozen
  // views after rebinding a port with a different native byte origin.
  for (auto *view : state_->views)
    view->data = static_cast<char *>(view->view_src->data) + view->view_offs;
  state_->bound = std::ranges::all_of(
      bindings, [](const auto &port) { return port.handle != VK_NULL_HANDLE; });
  return Status::Ok();
}
WorkState Region::submit() noexcept {
  if (!state_ || !state_->bound)
    return {Status::FailedPrecondition("ggml Vulkan region ports are unbound")};
  const auto result =
      state_->work.submit(state_->graph.get(), state_->graph.lease());
  state_->pending = result.pending;
  return result;
}
WorkState Region::poll() noexcept {
  if (!state_)
    return {Status::FailedPrecondition("empty ggml Vulkan region")};
  const auto result = state_->work.poll();
  state_->pending = result.pending;
  return result;
}
WorkState Region::wait() noexcept {
  if (!state_)
    return {Status::FailedPrecondition("empty ggml Vulkan region")};
  const auto result = state_->work.wait();
  state_->pending = result.pending;
  return result;
}
VkFence Region::fence() const noexcept {
  return state_ ? state_->work.fence() : VK_NULL_HANDLE;
}
std::size_t Region::storage_bytes() const noexcept {
  return state_ ? state_->graph.storage_bytes() + state_->imports->constant_bytes
                : 0;
}
} // namespace hyle::compute::ggml_vulkan::detail
