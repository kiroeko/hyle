from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
NATIVE = ROOT / '.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/vulkan-region.obj'


def identity(path):
    path = Path(path).resolve()
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(part)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha.hexdigest())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n',
                            encoding='utf-8', newline='\n')


sources = [
    'tests/graph_route_vulkan/tensor_test.cc',
    'tests/compute_models/batched_sink_fixture.h',
    'include/hyle/compute/model_ops.h',
    'src/compute_provider_ggml_vulkan/region.cc',
    'src/compute_ggml_runtime/sink_mask.h',
    'src/compute_route_vulkan/vulkan_operations.cc',
    'src/compute_route_vulkan/vulkan_region.cc',
]
for name in sources:
    target = OUT / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
save('source-identities.json', [identity(ROOT / name) for name in sources])
save('canonical-native-identity.json', identity(NATIVE))
assert identity(NATIVE)['sha256'] == 'f369e2de0d645c30318109771ce86b62800200150e4ea47bd45d603805b24f9f'
canonical = (ROOT / sources[3]).read_text()
normalization = '''        // A singleton KV head can keep its pre-permute nb2 while remaining
        // contiguous. Canonical strides let Vulkan retain the F32 carrier.
        if (ggml_is_contiguous(key) && key->ne[3] != 1 &&
            key->nb[3] != key->nb[2] * std::size_t(key->ne[2]))
          key = ggml_reshape_4d(context, key, key->ne[0], key->ne[1],
                                key->ne[2], key->ne[3]);
'''
assert canonical.count(normalization) == 1
old = canonical.replace(normalization, '')
assert hashlib.sha256(old.encode()).hexdigest() == '4e7a2b1ae1c11eb7104a0891e16d805b5e8f486d949f82babe08cbd4d6758e1d'
(OUT / 'region.before-stride-normalization.cc').write_text(old, encoding='utf-8', newline='\n')
trace_tree = ast.parse((OUT / 'trace.py').read_text())
trace = next(ast.literal_eval(item.value) for item in trace_tree.body
             if isinstance(item, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'trace' for t in item.targets))
old_trace = '#include <cstdio>\n' + old.replace('      auto *node = ggml_graph_node(graph, i);\n',
    '      auto *node = ggml_graph_node(graph, i);\n' + trace)
(OUT / 'region.first-failure.trace.cc').write_text(old_trace, encoding='utf-8', newline='\n')
(OUT / 'graph-test.diff').write_text(''.join(difflib.unified_diff(
    (OUT / 'tensor_test.before.cc').read_text().splitlines(True),
    (ROOT / sources[0]).read_text().splitlines(True),
    fromfile='before/tensor_test.cc', tofile='tests/graph_route_vulkan/tensor_test.cc')),
    encoding='utf-8', newline='\n')
(OUT / 'native-stride-fix.diff').write_text(''.join(difflib.unified_diff(
    old.splitlines(True), canonical.splitlines(True),
    fromfile='before/region.cc', tofile='canonical/region.cc')),
    encoding='utf-8', newline='\n')
commands = json.loads((OUT / 'commands.json').read_text())
regular = [x for x in commands if x['tag'] == 'tests']
assert [x['exit'] for x in regular] == [3, 0]
assert [x['exit'] for x in commands if x['tag'] == 'trace-test'] == [3, 0]
assert next(x for x in commands if x['tag'] == 'force2-tests')['exit'] == 0
forced = (OUT / 'force2-tests.stderr.log').read_text()
assert forced.count('FORCED_MATMUL reduction=512 rows=2') == 2
assert forced.count('FORCED_MATMUL reduction=512 rows=1') == 1
assert forced.count('FORCED_MATMUL reduction=64 rows=2') == 2
assert forced.count('FORCED_MATMUL reduction=64 rows=1') == 1
link = next(x['command'] for x in reversed(commands) if x['tag'] == 'link')
reused = []
for name in link:
    path = Path(name)
    if path.is_absolute() and path.suffix in ('.obj', '.lib') and path.parent != OUT:
        reused.append(identity(path))
save('reused-link-identities.json', reused)
artifacts = [identity(path) for path in sorted(OUT.iterdir())
             if path.suffix in ('.obj', '.exe')]
save('artifact-identities.json', artifacts)
retain = {'operations.obj', 'route-region.obj'}
cleanup = {
    'platform': 'Windows', 'root': str(OUT), 'performed': False,
    'delete': [x for x in artifacts if Path(x['path']).name not in retain],
    'retain': [x for x in artifacts if Path(x['path']).name in retain],
    'note': 'Keep two current small route host overlays and all original native/IREE/foundation caches. Only this stage\'s diagnostic/test executables/objects are delete candidates; no deletion performed. All sources/commands/logs/diffs/JSON/zip retained.',
}
for key in ('delete', 'retain'):
    cleanup[key + '_count'] = len(cleanup[key])
    cleanup[key + '_logical_bytes'] = sum(x['bytes'] for x in cleanup[key])
save('cleanup-candidates.json', cleanup)
save('summary.json', {
    'result': 'PASS',
    'scope': 'Public Vulkan Graph batched F32 SinkAttention then Neg, both values published; same slot two complete input rebindings',
    'canonical': {
        'test': 'VulkanGraph.BatchedSinkPreservesPublishedIntermediateAcrossMaskRanksAndReplay',
        'heads': [64, 128], 'batch': 3, 'query_rows': [1, 3], 'key_rows': 17,
        'key_value_heads': 1, 'qk_and_value_depth': 512,
        'mask_ranks': [2, 3], 'geometries': 8, 'phases_per_geometry': 2,
        'ports': 'Five dense F32 Q/K/V/mask/sink ports, all uploaded and rebound with changed payloads in phase1',
        'result': 'Final canonical child object, no diagnostics/forced selection: 1/1test, all16 submits PASS',
        'checks': 'All Sink output elements checked against shared independent FP64 dot/softmax/sink-denominator/PV; all Neg elements checked against its negative, original abs2e-5+rel2e-5 unchanged',
        'wall_time_note': 'Functional test wall times only, no timing experiment',
    },
    'native_bug': {
        'before_source_sha256': '4e7a2b1ae1c11eb7104a0891e16d805b5e8f486d949f82babe08cbd4d6758e1d',
        'before_object_sha256': 'dda91130e226954bcb5c8b590c2d3561acbb88ca8c0747c440dec29819eb8775',
        'first_real_error': 'Q1 reaches native matvec; Q3 exposed GGML_ASSERT(mmp_map!=nullptr) at retained ggml-vulkan.candidate.cpp:9658',
        'actual_old_key': {'type': 'F32', 'shape': [512, 17, 1, 3], 'strides_bytes': [4, 2048, 2048, 34816],
                           'ggml_is_contiguous': True, 'native_dim01_contiguous': False},
        'mechanism': 'Permuting singleton KV head leaves irrelevant nb2 unchanged; native batched dim01 predicate still compares nb3==nb2*ne2, takes noncontiguous/dequant fallback and missing F16/F32 pipeline map. Existing F32/F32 pipeline is present.',
        'repair': 'Only already-contiguous Sink keys failing the native batch-pitch equality get same-shape ggml_reshape_4d canonical strides. New nb2=nb3=34816, no payload copy or dtype change.',
        'causal_probe': 'One snapshot changes only this metadata normalization plus cold logging; all8 regular geometries pass. QK and PV stay F32, prec0/2/3 stay10/0/10.',
        'canonical_owner': 'Child applies/fresh-compiles native region; parent Graph test owns only test TU',
        'canonical_source_sha256': identity(ROOT / sources[3])['sha256'],
        'canonical_object_sha256': identity(NATIVE)['sha256'],
        'cache_boundary': 'Retained native Vulkan host object and all shader objects unchanged. No native SDK rebuild or new kernel.',
    },
    'forced_tile': {
        'test': 'VulkanGraph.BatchedSinkForcedAlignedQueryTilesKeepBatchStrideAndTail',
        'result': '1/1PASS, one geometry and two phases',
        'geometry': 'B2/H64/Hkv1/D512/Q5/S64/rank3mask',
        'selection': 'Scratch source only returns block_rows2 for this exact geometry, bypassing production threshold/frontier strategy. Canonical strategy unchanged.',
        'actual_qk_rows': [2, 2, 1], 'actual_pv_rows': [2, 2, 1],
        'mask_query_stride_bytes': 256,
        'checks': 'Same complete independent FP64 Sink oracle and Neg double-publish checks, original budget; fixed aligned row cuts preserve per-batch mask stride and real tail1',
        'evidence_limit': 'Execution/layout proof only; not natural production strategy selection, space peak or throughput evidence',
    },
    'mechanical_failure_retained': 'First link needed fresh current route-region host TU for lower_gather_elements symbol referenced by current operations TU. No GPU run occurred before that correction.',
    'build': 'Fresh test/operations/necessary route-region host TUs plus child fresh native-region host overlay; reused frozen IREE overlays and native Vulkan/shader/foundation libraries. /W4/WX; no configure, SDK, shader or kernel rebuild.',
    'limitations': ['No new paged/native-fused Sink implementation',
        'Small numerical/layout/Graph execution scope, no big shape resource measurement',
        'No default production long-tile activation claim from forced snapshot',
        'No new performance or capture claim'],
    'commands': 'commands.json', 'cleanup_performed': False,
})

members = sorted((p for p in OUT.rglob('*') if p.is_file() and
                  p.suffix not in ('.obj', '.exe', '.lib', '.exp', '.zip') and
                  p.name != 'package-identity.json'),
                 key=lambda p: p.relative_to(OUT).as_posix())
archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path in members:
        handle.write(path, path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
result = {'archive': identity(archive), 'members': len(members),
          'summary': identity(OUT / 'summary.json'),
          'cleanup': identity(OUT / 'cleanup-candidates.json')}
save('package-identity.json', result)
print(json.dumps(result, indent=2))
