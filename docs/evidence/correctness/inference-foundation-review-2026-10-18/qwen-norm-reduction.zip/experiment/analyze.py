"""Offline bit analysis; never supplies reference intermediates to a candidate."""
from pathlib import Path
from decimal import Decimal, getcontext
from fractions import Fraction
import collections, difflib, hashlib, json, re, struct

OUT=Path(__file__).resolve().parent
OLD=OUT.parents[1]/'qwen-numerics'
getcontext().prec=100
def f32(value): return struct.unpack('<f',struct.pack('<f',value))[0]
def bits(value): return struct.unpack('<I',struct.pack('<f',value))[0]
def number(value): return dict(value=float(value),bits=f'0x{bits(value):08x}')
def exact(value):
    if isinstance(value,Fraction): return Decimal(value.numerator)/Decimal(value.denominator)
    return Decimal.from_float(value)
def rn(value):
    value=exact(value) if not isinstance(value,Decimal) else value
    candidate=bits(float(value))
    choices=[struct.unpack('<f',struct.pack('<I',v))[0] for v in [candidate-1,candidate,candidate+1]]
    return min(choices,key=lambda v:(abs(Decimal.from_float(v)-value),bits(v)%2))
def butterfly(values):
    for offset in [16,8,4,2,1]: values=[f32(a+values[i^offset]) for i,a in enumerate(values)]
    return values
def identity(p):
    p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name,value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')

raw=(OUT/'telemetry/actual/telemetry.u32').read_bytes()
observed=[struct.unpack('<f',struct.pack('<I',v))[0] for v in struct.unpack('<12I',raw)]
x=struct.unpack('<47104f',(OUT/'control/actual/input.f32').read_bytes())[21*2048:22*2048]
gamma=struct.unpack('<2048f',(OUT/'control/actual/gamma.f32').read_bytes())
partials=[]
for i in range(1024):
    # Original FFMA sequence is exact product 0+x0^2, then FMA(x1,x1,partial).
    first=rn(Fraction.from_float(x[i])**2)
    partials.append(rn(Fraction.from_float(x[i+1024])**2+Fraction.from_float(first)))
warps=[butterfly(partials[i:i+32])[0] for i in range(0,1024,32)]
reduced=butterfly(warps)
assert len(set(reduced))==1 and bits(reduced[0])==bits(observed[2])
assert bits(partials[619])==bits(observed[1])
sum_exact=sum((Fraction.from_float(v)**2 for v in x),Fraction())
sum_rn=rn(sum_exact)
mean_exact=sum_exact/2048
reference=json.loads((OLD/'same-input-comparison.json').read_text())
scalar=reference['norm_rounding_scalar']
torch_mean=scalar['torch_variance']
assert bits(rn(mean_exact))==bits(torch_mean)

def stages(mean, label):
    add=f32(mean+observed[4])
    real_scale=Decimal(1)/Decimal.from_float(add).sqrt()
    scale=rn(real_scale)
    mul1=f32(x[619]*scale)
    weighted=f32(mul1*gamma[619])
    return dict(label=label,mean=number(mean),epsilon=number(observed[4]),mean_plus_epsilon=number(add),
                exact_rsqrt_decimal=str(real_scale),rounded_rsqrt=number(scale),
                multiply1=number(mul1),weighted=number(weighted))
native=stages(observed[3],'Offline RN replay from actually observed native mean; no new GPU computation')
torch=stages(torch_mean,'Offline RN replay from previously saved actual Torch variance; actual Torch scale/multiply1 were not saved')
assert native['rounded_rsqrt']['bits']==f'0x{bits(observed[6]):08x}'
assert native['weighted']['bits']==f'0x{bits(observed[10]):08x}'
assert torch['weighted']['bits']==f'0x{bits(scalar["torch_pre_bf16"]):08x}'
native_mean_product=Fraction.from_float(observed[2])/2048
assert Fraction.from_float(observed[3])==native_mean_product
fused_arg=rn(native_mean_product+Fraction.from_float(observed[4]))
assert bits(fused_arg)==bits(observed[5])

result=dict(scope='Only token21/channel619 on the immutable 23x2048 residual and original weight; offline arithmetic uses no new candidate execution or supplied reference intermediates.',
    prior_torch= dict(source=identity(OLD/'same-input-comparison.json'),script=identity(OLD/'same_input.py'),
                     scalar=scalar,mean=number(torch_mean),scale_saved=False,
                     input_identity_evidence='Prior same-input replay proved tail_residual bytewise equal to the same Hyle residual; current probe input and original weight identities are frozen in input-identities.json.'),
    actual_input=dict(x619=number(x[619]),x1643=number(x[1643]),gamma619=number(gamma[619])),
    reduction=dict(actual_thread619=number(observed[1]),reconstructed_thread619=number(partials[619]),
                   actual_sum=number(observed[2]),reconstructed_original_topology_sum=number(reduced[0]),
                   exact_real_sum=str(exact(sum_exact)),correctly_rounded_exact_sum=number(sum_rn),
                   actual_mean=number(observed[3]),correctly_rounded_exact_mean=number(rn(mean_exact)),
                   native_mean_vs_saved_torch_ulp=int(bits(observed[3]))-int(bits(torch_mean)),
                   source_topology='1024 original per-thread sequential FFMA accumulators; warp XOR offsets16,8,4,2,1;32 lane0 warp sums through shared; second same XOR tree. No subnormal behavior in this captured row.',
                   reconstructed_warp_sums=[number(v) for v in warps]),
    native_offline_stages=native,torch_variance_offline_stages=torch,
    contraction_caveat=dict(original='MUFU.RCP(ncols), FFMA.FTZ(sum, reciprocal, epsilon), MUFU.RSQ; no standalone mean register',
        telemetry='MUFU.RCP(ncols), FMUL.FTZ(sum, reciprocal), FADD.FTZ(mean, epsilon), MUFU.RSQ',
        limited_equivalence='For this ncols2048 and captured finite normal sum, multiplication by exact2^-11 is exactly representable; offline fused and split expressions produce the same captured rsqrt argument. Full47104 F32+BF16 outputs match. This does not prove arbitrary shape/input intermediate fidelity or identical original instruction sequence.',
        original_all_intermediates_observed=False),
    conclusion='The first directly distinguishable saved-stage difference is native mean3b4ae0ec versus actual Torch variance3b4ae0ee. Original reduction topology reconstruction agrees with observed native sum. Observed native rsqrt and final two FMULs agree with RN results given their observed inputs; using the already-saved Torch variance in an offline RN chain lands its saved midpoint3f568000. This localizes this coordinate without establishing a general kernel error, a fastmath cause, or full-model numerical acceptance.',
    missing='Previous actual Torch scale and first multiply were not saved; the Torch downstream scalar chain here is computed offline, not claimed as observed Torch intermediates.')
save('offline-analysis.json',result)

texts={v:(OUT/'sass'/(v+'-target.txt')).read_text() for v in ['original','control','telemetry']}
assert texts['original']==texts['control']
instructions={v:[x.split('/* 0x')[0].rstrip() for x in text.splitlines() if re.match(r'\s*/\*[0-9a-f]+\*/',x)] for v,text in texts.items()}
float_re=re.compile(r'\b(FFMA(?:\.\w+)*|FADD(?:\.\w+)*|FMUL(?:\.\w+)*|MUFU(?:\.\w+)*|SHFL(?:\.\w+)*|BAR(?:\.\w+)*)\b')
arithmetic={v:[x for x in rows if float_re.search(x)] for v,rows in instructions.items()}
for v,rows in arithmetic.items(): (OUT/'sass'/(v+'-arithmetic.txt')).write_text('\n'.join(rows)+'\n',encoding='utf-8',newline='\n')
save('sass-comparison.json',dict(original_control_target_text_identical=True,
    identities=[identity(OUT/'sass'/(v+'-target.txt')) for v in texts],
    opcounts={v:dict(collections.Counter(float_re.search(x)[1] for x in rows)) for v,rows in arithmetic.items()},
    actual_path=dict(control=['0340 FFMA per-thread loop','0a60..0b20 XOR16/8/4/2/1','0b30 STS,0b40 barrier,0b50 LDS','0b60..0c10 XOR16/8/4/2/1','0c70 MUFU.RCP from ncols','0d20 FFMA.FTZ R10,R13,R10,eps','0d80 MUFU.RSQ R10,R10','0f90 LDG R25 from x+sample/channel/row/col (base c160/c164)','1020 LDG R12 from mul+sample/channel/row/col (base c198/c19c)','1090 FMUL.FTZ R25,R10(scale),R25(x)','10a0 FMUL.FTZ R25,R25(normalized),R12(gamma)','10c0 STG dst'],
        telemetry=['04a0 FFMA per-thread loop','0ba0..0d10 first XOR tree','0d20 STS,0d30 barrier,0d60 LDS','0d70..0e00 second XOR tree','0d50 MUFU.RCP from ncols','0e10 FMUL.FTZ R33,R31(sum),R20(reciprocal)','0e20 FADD.FTZ R35,R33(mean),eps','0e30 MUFU.RSQ R15,R35','0e70 sum telemetry uses R31','0ea0 mean telemetry uses R33','0ec0 add telemetry uses R35 (actual MUFU input)','0ef0 scale telemetry uses R15 (actual MUFU output)','1360 FMUL.FTZ R30,R15(scale),R30(x)','1370 FMUL.FTZ R31,R30(normalized),R17(gamma)']),
    caveat='Static full-specialization instruction listings also contain branches/unrolled loops not executed for ncols2048. Register allocation, scheduling, predicates and telemetry stores differ; arithmetic contraction difference is explicitly retained. No throughput/performance inference.'))
(OUT/'sass/target-arithmetic.diff').write_text(''.join(difflib.unified_diff([x+'\n' for x in arithmetic['control']],[x+'\n' for x in arithmetic['telemetry']],fromfile='control',tofile='telemetry')),encoding='utf-8',newline='\n')
print(json.dumps({k:result[k] for k in ['actual_input','reduction','native_offline_stages','torch_variance_offline_stages','conclusion','missing']},indent=2))
