#include <cuda_runtime_api.h>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/cuda.h"
#include "hyle/compute/prepared_operation.h"

extern "C" cudaError_t hyle_norm_probe_read(std::uint32_t*);

namespace c = hyle::compute;
namespace m = hyle::mem;

void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
std::vector<std::uint16_t> read_bf16(const std::filesystem::path& path,
                                     std::size_t count) {
  std::ifstream stream(path, std::ios::binary | std::ios::ate);
  if (!stream || stream.tellg() != std::streamoff(count * 2))
    throw std::runtime_error("input BF16 byte count mismatch");
  std::vector<std::uint16_t> values(count);
  stream.seekg(0);
  stream.read(reinterpret_cast<char*>(values.data()), std::streamsize(count*2));
  if (!stream) throw std::runtime_error("input BF16 read failed");
  return values;
}
void write_bytes(const std::filesystem::path& path, std::span<const std::byte> raw) {
  std::ofstream stream(path, std::ios::binary);
  stream.write(reinterpret_cast<const char*>(raw.data()), std::streamsize(raw.size()));
  if (!stream) throw std::runtime_error("output write failed");
}
c::TensorDesc dense(c::DataType type, std::initializer_list<std::int64_t> dims) {
  return take(c::TensorDesc::dense(type, {dims.begin(), dims.size()}));
}
m::Buffer upload(m::MemoryResourceRef resource, std::span<const float> values) {
  auto buffer=take(m::Buffer::create(resource, values.size_bytes(), 256));
  check(buffer.view().write(std::as_bytes(values)));
  return buffer;
}
struct Call {
  c::PreparedOperation program;
  m::Buffer workspace;
  c::OperationInvocation invocation;
};
Call prepare(const c::Context& context, m::MemoryResourceRef resource,
             c::Operation operation, std::span<const c::TensorDesc> inputs,
             const c::TensorDesc& output) {
  auto program=take(c::prepare(context, std::move(operation), inputs,
                               std::span(&output,1),resource));
  auto requirement=program.workspace_requirement();
  auto workspace=requirement.size ? take(m::Buffer::create(resource,requirement.size,requirement.alignment)) : m::Buffer{};
  auto invocation=take(program.create_invocation(workspace.view()));
  std::cout << "provider=" << program.provider().name << " version=" << program.provider().version
            << " implementation=" << program.implementation().value()
            << " workspace=" << requirement.size << '\n';
  return {std::move(program),std::move(workspace),std::move(invocation)};
}
int main(int argc,char** argv) try {
  if(argc!=4) throw std::runtime_error("usage: probe residual.bf16 weight.bf16 output-directory");
  constexpr std::size_t rows=23,width=2048,elements=rows*width;
  const auto residual=read_bf16(argv[1],elements), weight=read_bf16(argv[2],width);
  std::vector<float> input(elements),gamma(width);
  // BF16 widening is exact. This is only the original weight+1 in F32;
  // no reference, reduction, reciprocal square root or norm output is read.
  for(std::size_t i=0;i<elements;++i) input[i]=std::bit_cast<float>(std::uint32_t(residual[i])<<16);
  for(std::size_t i=0;i<width;++i) gamma[i]=1.0F+std::bit_cast<float>(std::uint32_t(weight[i])<<16);
  const std::filesystem::path out(argv[3]);
  std::filesystem::create_directories(out);
  write_bytes(out/"input.f32",std::as_bytes(std::span(input)));
  write_bytes(out/"gamma.f32",std::as_bytes(std::span(gamma)));
  auto context=take(c::cuda::create_context());
  const auto environment=take(c::cuda::environment(context));
  std::cout << "device=" << environment.device_name.data() << " sm=" << environment.sm_major << environment.sm_minor
            << " driver=" << environment.driver_release.data() << " toolkit=" << environment.build_toolkit_version << '\n';
  auto memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
  auto queue=take(context.create_queue());
  auto x=upload(memory.ref(),input), g=upload(memory.ref(),gamma);
  auto f32=take(m::Buffer::create(memory.ref(),elements*4,256));
  auto bf16=take(m::Buffer::create(memory.ref(),elements*2,256));
  const auto xd=dense(c::DataType::kFloat32,{rows,width}), gd=dense(c::DataType::kFloat32,{width});
  const auto bd=dense(c::DataType::kBFloat16,{rows,width});
  auto norm=prepare(context,memory.ref(),c::Operation(c::RmsNorm{.epsilon=1e-6F}),std::array{xd,gd},xd);
  auto cast=prepare(context,memory.ref(),c::Operation(c::Cast{.output_type=c::DataType::kBFloat16}),std::array{xd},bd);
  const auto xv=take(c::ConstTensorView::create(xd,x.view()));
  const auto gv=take(c::ConstTensorView::create(gd,g.view()));
  const auto fv=take(c::TensorView::create(xd,f32.view()));
  const auto bv=take(c::TensorView::create(bd,bf16.view()));
  auto norm_done=take(norm.invocation.submit(queue,xv,gv,fv));
  check(norm_done.wait());
  auto cast_done=take(cast.invocation.submit(queue,fv.as_const(),bv));
  check(cast_done.wait());
  std::vector<float> native(elements);
  std::vector<std::uint16_t> rounded(elements);
  check(f32.view().read(std::as_writable_bytes(std::span(native))));
  check(bf16.view().read(std::as_writable_bytes(std::span(rounded))));
  write_bytes(out/"weighted-native.f32",std::as_bytes(std::span(native)));
  write_bytes(out/"weighted-native.bf16",std::as_bytes(std::span(rounded)));
  constexpr auto index=21*width+619;
  std::printf("token21/channel619 F32=%.17g bits=0x%08x BF16=0x%04x\n",double(native[index]),
              std::bit_cast<std::uint32_t>(native[index]),unsigned(rounded[index]));
  std::array<std::uint32_t,12> telemetry{};
  const auto telemetry_status=hyle_norm_probe_read(telemetry.data());
  if(telemetry_status!=cudaSuccess) throw std::runtime_error(cudaGetErrorString(telemetry_status));
  if(telemetry[0]!=0x4e4f524d) throw std::runtime_error("target native specialization did not write telemetry");
  write_bytes(out/"telemetry.u32",std::as_bytes(std::span(telemetry)));
  check(queue.drain());
  return 0;
} catch(const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
