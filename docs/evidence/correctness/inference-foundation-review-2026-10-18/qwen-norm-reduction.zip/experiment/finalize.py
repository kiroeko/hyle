from pathlib import Path
import hashlib,json

OUT=Path(__file__).resolve().parent
def identity(p):
    p=Path(p)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name,value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')

analysis=json.loads((OUT/'offline-analysis.json').read_text())
control=json.loads((OUT/'control-comparison.json').read_text())
telemetry=json.loads((OUT/'telemetry-comparison.json').read_text())
assert control['all_bitwise_equal'] and telemetry['all_bitwise_equal']
commands=json.loads((OUT/'commands.json').read_text())
assert len(commands)==11 and all(x['exit']==0 for x in commands)
cleanup=[identity(OUT/v/('probe'+suffix)) for v in ['control','telemetry'] for suffix in ['.exe','.map','.exp','.lib']]
save('cleanup-identities.json',dict(scope='Only these exact8 images/maps/import products; root test.ps1 after archive. No deletion performed. Retain every object/source/raw/log.',files=cleanup))
objects=[identity(OUT/p) for p in ['control/norm.obj','telemetry/norm.obj','telemetry/probe.obj','sass/original-norm.obj']]
save('retained-object-identities.json',objects)
save('audit-note.json',dict(stage='002-control-link post-link Python audit only',
    actual_link_exit=0,initial_audit='Substring ggml_cuda_op_rms_norm also selected independent ggml_cuda_op_rms_norm_mul_rope_fused from rope.cu.obj, tripping the map-only assertion.',
    correction='Use exact MSVC decorated @@ symbol boundaries for the five norm.cu exports. Re-audit passed without recompiling/relinking. Original002 stdout/stderr preserved.',
    candidate_output_anomaly=False))
summary=dict(scope='Single actual weighted RMSNorm paired observation for Qwen layer0 post-attention residual; no product code change or full-model run.',
    task='Recompile only original ggml norm.cu once unchanged and once scratch telemetry, plus one small host consumer; same original flags and audited reference patched headers/native archives.',
    hardware='Actual run prints NVIDIA GeForce RTX4070 SM89, driver617.14, toolkit13030; original paired ncu launch was grid23/block1024/dynamicShared128B.',
    compile=dict(original_norm_sha256='8cb872a9633a7c68c5e9fa8c1f7d39afe9e66636c1299b9fc610b1b4217e7307',
        flags_source='historical-native-command.json; exact argument arrays in compile-recipes.json and commands.json',
        flags=['CUDA13.3 nvcc','SM89','C++17','original -use_fast_math','original -O2/-Ob2/-MD host','original FA macro roster','original compress-mode=size'],
        modifications='Only scratch source/input/output/include/PDB locations; reference patched include/src headers, current original native_bridge.h. No G/lineinfo/math flag changes.',
        warnings='Original NVCC flags do not use Werror;001/004 retain CUDA/reference header C4819 codepage warnings.005 hostconsumer /W4 /WX passed.',
        cached_native_scope='Original reference fixture libraries plus previously audited native main/allocator overlays and the unchanged frozen Direct Compute host closure; not a rebuild or revalidation of every default provider.'),
    fidelity=dict(control='003-control-run:47104/47104 F32 and47104/47104 BF16 bit-identical to frozen actual-f32-probe',
        telemetry='007-telemetry-run:47104/47104 F32 and47104/47104 BF16 bit-identical to frozen actual-f32-probe',
        original_vs_control_sass='Target specialization text exactly identical; sha6a27b07443b165358f2a20b1b200c2fc56477f21b0aacace856896711253828d',
        function='rms_norm_f32<1024,true,false>',
        outputs=dict(f32_sha256='f2dd2f34790cb2b70c9c2dbd3b9e3d1b2b560ad38282c3e19e9aea2b51d00236',bf16_sha256='7f4d1a728944fe56c9b49ab0b956d81995687a1040bdd84cf1679b6df09a053f')),
    observed=telemetry['telemetry'],
    saved_torch=dict(variance=analysis['prior_torch']['mean'],pre_bf16='0x3f568000',bf16='0x3f56',actual_scale_saved=False,actual_first_multiply_saved=False),
    reduction=analysis['reduction'],
    offline_stages=dict(native=analysis['native_offline_stages'],saved_torch_variance=analysis['torch_variance_offline_stages']),
    conclusion='For token21/channel619, the observed and independently reconstructed original reduction order produces mean0x3b4ae0ec, two F32ULP below previously saved actual Torch variance0x3b4ae0ee. The native scale and two ordered multiply results match RN calculations for those observed inputs; an offline RN chain from saved Torch variance yields its saved0x3f568000 midpoint, while native yields0x3f568001. This reduction-order difference crosses the BF16 midpoint and explains this isolated coordinate and its already demonstrated propagation.',
    limits=[
        'Telemetry materializes mean and changes original FFMA(sum,reciprocal,eps) to FMUL+FADD. Original and control SASS are identical; telemetry is output-faithful for this exact23x2048 input, not generally instruction-identical.',
        'For the captured normal sum and ncols2048, division by2048 is exact; offline fused/split epsilon expressions agree. Do not claim every original native temporary was captured unmodified.',
        'Previous actual Torch variance/pre-BF16 were saved; Torch scale and first multiply in this report are offline RN deductions, not observed Torch intermediates.',
        'The original -use_fast_math flag is a fact, not evidence that an arbitrary fastmath setting caused the difference.',
        'No product Cast bug follows: prior actual-F32 probe proved ordinary RNE for all47104 saved native F32→BF16 conversions.',
        'This does not explain or numerically accept the complete24-layer hidden/logit discrepancy around2%.',
        'No new ncu run, full model, kernel suite, SDK rebuild, or throughput experiment.'
    ],
    evidence=['commands.json','input-identities.json','control-link-plan.json','telemetry-link-plan.json','original-member-identity.json','control-comparison.json','telemetry-comparison.json','offline-analysis.json','sass-comparison.json','sass/*-target.txt','sass/*-arithmetic.txt','sass/target-arithmetic.diff','control/actual/*','telemetry/actual/*','norm-telemetry.diff','probe-telemetry.diff'],
    cleanup='cleanup-identities.json lists exact8 products; all4 objects are retained. Root owns archive and cleanup; no delete/move performed.')
save('summary.json',summary)
(OUT/'summary.md').write_text('''单 RMSNorm 原生观测已冻结，未改产品数学。

- 原 norm.cu 未插桩控制版和同 TU telemetry 版各只编一次；两次实际执行全部 **47,104 F32 + 47,104 BF16** 与冻结 actual-f32-probe 逐 bit 相同。原归档 kernel 与控制版目标 SASS 完全相同。
- token21/channel619：实测 sum `40cae0ec`、mean `3b4ae0ec`；旧实际 Torch variance 为 `3b4ae0ee`，相差2ULP。按原1024线程、两级 XOR16/8/4/2/1 归约离线重演精确复现实测 sum。
- 实测 rsqrt `418fc2de`；原 SASS 两乘是 `(scale*x)*gamma`。离线 F32 RN 从原生 mean 得到 `3f532636 → 3f568001`；从已保存 Torch variance 得到 `3f532635 → 3f568000`，分别落在 BF16 中点上侧和中点。这解释该坐标的归约顺序差异及已证明的边界传播。
- 观测限制明确保留：写出 mean 使原 FFMA 变为 FMUL+FADD；本 ncols2048 精确缩放和全输出逐 bit 门成立，但不宣称所有原始临时值/任意输入指令完全未变。Torch 实际只保存 variance 和最终值；Torch scale/mul1 是离线推演。不是 Cast 错误或任意 fastmath 因果结论，也不代签24层约2%数值差异。

实际命令001–011、双 bit 门、原始48B telemetry、SASS拓扑/差异、离线公式和输入/闭包身份均在本目录。cleanup-identities.json 仅列 control/probe 和 telemetry/probe 的 exe/map/exp/lib 共8项；两份 CU object、host probe 与原 archive member object 全保留。无删除/移动。
''',encoding='utf-8',newline='\n')
sources=[identity(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix.lower() in {'.py','.cu','.cc','.diff'}]
save('source-identities.json',sources)
save('final-manifest.json',dict(summary=identity(OUT/'summary.json'),summary_text=identity(OUT/'summary.md'),cleanup=identity(OUT/'cleanup-identities.json'),
     source_manifest=identity(OUT/'source-identities.json'),objects=objects,
     raw=[identity(p) for v in ['control','telemetry'] for p in sorted((OUT/v/'actual').iterdir())],
     reports=[identity(OUT/p) for p in ['commands.json','compile-recipes.json','control-comparison.json','telemetry-comparison.json','offline-analysis.json','sass-comparison.json']]))
print(json.dumps(dict(summary=identity(OUT/'summary.json'),cleanup=identity(OUT/'cleanup-identities.json'),objects=objects),indent=2))
