"""One original norm.cu control and one scratch telemetry overlay; no SDK rebuild."""
from pathlib import Path
import argparse, ctypes, difflib, hashlib, json, os, re, struct, subprocess, sys, time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
FROZEN = OUT.parent / 'actual-f32-probe'
REF = ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows'
RAW = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml-cuda/norm.cu')
HISTORY = ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-static/compile_commands.json'
CUDA = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
RESIDUAL = ROOT / '.scratch/architecture-refactor-2026-10-18/generic-progress/qwen/layer0-probe-01/prefill/06-post-attn-residual.bf16'
FIELDS = ['signature', 'thread619_partial', 'reduced_sum', 'mean', 'epsilon',
          'mean_plus_epsilon', 'rsqrt_scale', 'x619', 'x1643', 'gamma619',
          'weighted619', 'weighted1643']

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8', newline='\n')
def environment():
    sys.path.insert(0, str(ROOT/'scripts'))
    from hyle_environment import windows_compiler_environment
    from hyle_support import read_cache
    result = windows_compiler_environment(read_cache(ROOT/'.scratch/build-compute-v2-dev'))
    link = json.loads((FROZEN/'link-plan.json').read_text())['command']
    dirs = [str(Path(v).parent) for v in link if v.lower().endswith('.lib') and Path(v).is_absolute()]
    dirs += [str(CUDA/'bin/x64'), str(CUDA/'bin'), str(ROOT/'.scratch/build-compute-v2-dev/bin')]
    result['PATH'] = os.pathsep.join(dict.fromkeys(dirs))+os.pathsep+result['PATH']
    result['VSLANG'] = '1033'
    return result
def run(tag, command, timeout=180):
    history = json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
    stem = f'{len(history)+1:03d}-{tag}'
    print('START', stem, flush=True)
    start = time.monotonic()
    with (OUT/(stem+'.stdout.log')).open('wb') as so, (OUT/(stem+'.stderr.log')).open('wb') as se:
        p = subprocess.run(list(map(str,command)), cwd=ROOT, env=environment(), stdout=so, stderr=se, timeout=timeout)
    row = dict(tag=tag,command=list(map(str,command)),exit=p.returncode,seconds=time.monotonic()-start,
               stdout=stem+'.stdout.log',stderr=stem+'.stderr.log')
    history.append(row); save('commands.json',history)
    print('END', stem, p.returncode, flush=True)
    if p.returncode:
        print((OUT/row['stdout']).read_text(errors='replace')[-12000:])
        print((OUT/row['stderr']).read_text(errors='replace')[-12000:])
        raise SystemExit(p.returncode)
    return row
def windows_arguments(command):
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    count = ctypes.c_int(); pointer = shell.CommandLineToArgvW(command, ctypes.byref(count))
    try: return [pointer[i] for i in range(count.value)]
    finally: kernel.LocalFree(pointer)

def prepare():
    for sub in ['control','telemetry','sass']: (OUT/sub).mkdir(parents=True,exist_ok=True)
    assert sha(RAW) == '8cb872a9633a7c68c5e9fa8c1f7d39afe9e66636c1299b9fc610b1b4217e7307'
    assert sha(FROZEN/'probe.cc') == '92cbf275d8b57ac362f43d3c74ad2fa1733a58814f6b87c08431703eeec8e6f1'
    baseline = json.loads((FROZEN/'link-identities.json').read_text())
    for item in baseline: assert sha(item['path']) == item['sha256'], item['path']
    ref = json.loads((REF/'identity.json').read_text())
    headers = []
    for name, expected in ref['files'].items():
        if name.startswith(('include/','src/')):
            assert sha(REF/name) == expected, name
            headers.append(identity(REF/name))
    source = RAW.read_bytes()
    (OUT/'control/norm.cu').write_bytes(source)
    text = source.decode()
    text = text.replace('#include <cstdint>\n', '#include <cstdint>\n\n// Scratch-only diagnostic state. Original kernel parameters and launch are unchanged.\n__device__ std::uint32_t hyle_norm_telemetry[12];\n', 1)
    begin = text.index('template <int block_size, bool do_multiply = false, bool do_add = false>')
    end = text.index('template <int block_size>\nstatic __global__ void rms_norm_back_f32', begin)
    kernel = text[begin:end]
    marker = '    // sum up partial sums\n'
    assert kernel.count(marker) == 1
    partial = '''    if constexpr (block_size == 1024 && do_multiply && !do_add) {
        if (row == 21 && channel == 0 && sample == 0 && tid == 619 && ncols == 2048) {
            hyle_norm_telemetry[0] = 0x4e4f524d;
            hyle_norm_telemetry[1] = __float_as_uint(tmp);
        }
    }

'''
    kernel = kernel.replace(marker, partial+marker, 1)
    marker = '    const float scale = rsqrtf(mean + eps);\n'
    assert kernel.count(marker) == 1
    capture = '''
    if constexpr (block_size == 1024 && do_multiply && !do_add) {
        if (row == 21 && channel == 0 && sample == 0 && tid == 619 && ncols == 2048) {
            hyle_norm_telemetry[2] = __float_as_uint(tmp);
            hyle_norm_telemetry[3] = __float_as_uint(mean);
            hyle_norm_telemetry[4] = __float_as_uint(eps);
            hyle_norm_telemetry[5] = __float_as_uint(mean + eps);
            hyle_norm_telemetry[6] = __float_as_uint(scale);
            hyle_norm_telemetry[7] = __float_as_uint(x[619]);
            hyle_norm_telemetry[8] = __float_as_uint(x[1643]);
            hyle_norm_telemetry[9] = __float_as_uint(mul[fastmodulo(619, mul_ncols_packed)]);
        }
    }
'''
    kernel = kernel.replace(marker, marker+capture, 1)
    original = '            dst[col]          = scale * x[col] * mul[mul_col];\n'
    assert kernel.count(original) == 1
    weighted = '''            if constexpr (block_size == 1024) {
                if (row == 21 && channel == 0 && sample == 0 && tid == 619 && ncols == 2048) {
                    if (col == 619) hyle_norm_telemetry[10] = __float_as_uint(dst[col]);
                    if (col == 1643) hyle_norm_telemetry[11] = __float_as_uint(dst[col]);
                }
            }
'''
    kernel = kernel.replace(original, original+weighted, 1)
    text = text[:begin]+kernel+text[end:]
    text += '''
// Read after the original norm and cast Completions have successfully retired.
extern "C" cudaError_t hyle_norm_probe_read(std::uint32_t* output) {
    return cudaMemcpyFromSymbol(output, hyle_norm_telemetry, sizeof(hyle_norm_telemetry));
}
'''
    (OUT/'telemetry/norm.cu').write_text(text,encoding='utf-8',newline='\n')
    (OUT/'norm-telemetry.diff').write_text(''.join(difflib.unified_diff(source.decode().splitlines(True),text.splitlines(True),fromfile='original/norm.cu',tofile='telemetry/norm.cu')),encoding='utf-8',newline='\n')
    probe = (FROZEN/'probe.cc').read_text()
    probe = probe.replace('#include <array>','#include <cuda_runtime_api.h>\n#include <array>',1)
    probe = probe.replace('namespace c = hyle::compute;', 'extern "C" cudaError_t hyle_norm_probe_read(std::uint32_t*);\n\nnamespace c = hyle::compute;',1)
    marker = '  check(queue.drain());\n'
    probe = probe.replace(marker,'''  std::array<std::uint32_t,12> telemetry{};
  const auto telemetry_status=hyle_norm_probe_read(telemetry.data());
  if(telemetry_status!=cudaSuccess) throw std::runtime_error(cudaGetErrorString(telemetry_status));
  if(telemetry[0]!=0x4e4f524d) throw std::runtime_error("target native specialization did not write telemetry");
  write_bytes(out/"telemetry.u32",std::as_bytes(std::span(telemetry)));
'''+marker,1)
    (OUT/'telemetry/probe.cc').write_text(probe,encoding='utf-8',newline='\n')
    (OUT/'probe-telemetry.diff').write_text(''.join(difflib.unified_diff((FROZEN/'probe.cc').read_text().splitlines(True),probe.splitlines(True),fromfile='frozen/probe.cc',tofile='telemetry/probe.cc')),encoding='utf-8',newline='\n')
    recipe = next(v for v in json.loads(HISTORY.read_text()) if v['file'].replace('\\','/').endswith('/ggml-cuda/norm.cu'))
    parsed = windows_arguments(recipe['command'])
    recipes = {}
    for variant in ['control','telemetry']:
        command = []
        for i,value in enumerate(parsed):
            lower = value.lower()
            if lower.startswith('-i') and 'source-4e1a7b2f39afe15d' in lower:
                value = '-I'+str(REF/('include' if 'src\\..\\include' in lower else 'src'))
            elif lower.endswith('\\norm.cu'): value = str(OUT/variant/'norm.cu')
            elif i and parsed[i-1] == '-o': value = str(OUT/variant/'norm.obj')
            elif lower.startswith('-xcompiler=-fd'): value = '-Xcompiler=-Fd'+str(OUT/variant/'norm.pdb')+',-FS'
            command.append(value)
        command.insert(1,'-I'+str(REF/'src/ggml-cuda'))
        assert not any('c:\\hyle-scratch' in v.lower() for v in command)
        recipes[variant] = dict(source=identity(OUT/variant/'norm.cu'),object=str(OUT/variant/'norm.obj'),command=command)
    host = json.loads((FROZEN/'compile-recipes.json').read_text())[0]['command']
    host = [str(OUT/'telemetry/probe.cc') if v == str(FROZEN/'probe.cc') else
            '/Fo'+str(OUT/'telemetry/probe.obj') if v.lower().startswith('/fo') else v for v in host]
    recipes['host'] = dict(source=identity(OUT/'telemetry/probe.cc'),object=str(OUT/'telemetry/probe.obj'),command=host)
    save('compile-recipes.json', recipes)
    save('historical-native-command.json',recipe)
    save('input-identities.json',dict(original_norm=identity(RAW),reference_manifest=identity(REF/'identity.json'),
         patched_headers=headers,closure=baseline,residual=identity(RESIDUAL),weight=identity(FROZEN/'weight.bf16'),
         frozen_outputs=[identity(FROZEN/'actual'/n) for n in ['weighted-native.f32','weighted-native.bf16']],
         telemetry_fields=FIELDS,scope='One unchanged norm.cu control, one same-TU scratch telemetry overlay, one telemetry host consumer; original numerical archives and host closure unchanged.'))
    # Extract only the original numerical member; do not copy or rebuild the native archive.
    archive = (REF/'lib/ggml-cuda.lib').read_bytes(); assert archive[:8] == b'!<arch>\n'
    offset=8; names=b''; found=[]
    while offset < len(archive):
        header=archive[offset:offset+60]; assert header[58:60] == b'`\n'
        size=int(header[48:58]); name=header[:16].decode().strip(); payload=offset+60
        if name == '//': names=archive[payload:payload+size]
        elif name.startswith('/') and name[1:].isdigit():
            pos=int(name[1:]); name=names[pos:].split(b'\x00')[0].decode()
        if name.replace('\\','/').endswith('/norm.cu.obj'):
            path=OUT/'sass/original-norm.obj'; path.write_bytes(archive[payload:payload+size])
            found.append(dict(archive=identity(REF/'lib/ggml-cuda.lib'),member=name,payload_offset=payload,object=identity(path)))
        offset=payload+size+(size%2)
    assert len(found)==1,found
    save('original-member-identity.json',found[0])
    print('Prepared scratch sources/commands; no compilation or GPU run performed.')

def compile_(variant):
    recipes=json.loads((OUT/'compile-recipes.json').read_text())
    keys=['control'] if variant=='control' else ['telemetry','host']
    for key in keys:
        r=recipes[key]; assert sha(r['source']['path'])==r['source']['sha256']
        assert not Path(r['object']).exists(), 'Do not accidentally recompile an approved one-shot TU'
        run(key+'-compile',r['command'],timeout=240)
    save(variant+'-fresh-identities.json',[dict(source=recipes[k]['source'],object=identity(recipes[k]['object'])) for k in keys])
def link(variant):
    old=json.loads((FROZEN/'link-plan.json').read_text())['command']; command=[]
    for v in old:
        lower=v.lower()
        if lower.startswith('/out:'): v='/OUT:'+str(OUT/variant/'probe.exe')
        elif lower.startswith('/map:'): v='/MAP:'+str(OUT/variant/'probe.map')
        elif v==str(FROZEN/'probe.obj') and variant=='telemetry': v=str(OUT/'telemetry/probe.obj')
        command.append(v)
    command.insert(1,str(OUT/variant/'norm.obj'))
    save(variant+'-link-plan.json',dict(command=command,inputs=[identity(v) for v in command if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}]))
    run(variant+'-link',command)
    audit_map(variant)
def audit_map(variant):
    maptext=(OUT/variant/'probe.map').read_text(errors='replace')
    symbols=['?ggml_cuda_op_'+n+'@@' for n in ['norm','rms_norm','rms_norm_back','rms_norm_fused','rms_norm_fused_add']]
    lines=[x for x in maptext.splitlines() if any(n in x for n in symbols)]
    assert lines and all('norm.obj' in x and 'ggml-cuda:' not in x for x in lines),lines
    (OUT/variant/'map-selected-owners.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
def execute(variant):
    run(variant+'-run',[OUT/variant/'probe.exe',RESIDUAL,FROZEN/'weight.bf16',OUT/variant/'actual'])
    comparisons=[]
    for name,width in [('weighted-native.f32',4),('weighted-native.bf16',2)]:
        expected=(FROZEN/'actual'/name).read_bytes(); actual=(OUT/variant/'actual'/name).read_bytes()
        assert len(expected)==len(actual)==47104*width
        mismatches=[i//width for i in range(0,len(expected),width) if expected[i:i+width]!=actual[i:i+width]]
        comparisons.append(dict(output=name,elements=47104,equal_elements=47104-len(mismatches),
              bitwise_equal=not mismatches,first_mismatches=mismatches[:20],actual=identity(OUT/variant/'actual'/name),expected=identity(FROZEN/'actual'/name)))
    result=dict(variant=variant,comparisons=comparisons,all_bitwise_equal=all(v['bitwise_equal'] for v in comparisons))
    if variant=='telemetry':
        raw=(OUT/'telemetry/actual/telemetry.u32').read_bytes(); bits=struct.unpack('<12I',raw)
        result['telemetry']=[dict(field=n,bits=f'0x{b:08x}',value=struct.unpack('<f',struct.pack('<I',b))[0]) for n,b in zip(FIELDS,bits)]
    save(variant+'-comparison.json',result)
    print(json.dumps(result,indent=2))
    assert result['all_bitwise_equal'],'Fidelity gate failed; retain anomaly and stop diagnosis'
def sass():
    for variant,path in [('original',OUT/'sass/original-norm.obj'),('control',OUT/'control/norm.obj'),('telemetry',OUT/'telemetry/norm.obj')]:
        row=run(variant+'-sass',[CUDA/'bin/cuobjdump.exe','--dump-sass',path])
        text=(OUT/row['stdout']).read_text(errors='replace')
        chunks=text.split('Function : ')
        selected=[v for v in chunks[1:] if 'rms_norm_f32ILi1024ELb1ELb0EE' in v.splitlines()[0]]
        assert len(selected)==1,[v.splitlines()[0] for v in chunks[1:] if 'rms_norm_f32' in v.splitlines()[0]]
        (OUT/'sass'/(variant+'-target.txt')).write_text('Function : '+selected[0],encoding='utf-8',newline='\n')
def resources():
    for variant,path in [('original',OUT/'sass/original-norm.obj'),('control',OUT/'control/norm.obj'),('telemetry',OUT/'telemetry/norm.obj')]:
        run(variant+'-resources',[CUDA/'bin/cuobjdump.exe','--dump-resource-usage',path])

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('action',choices=['prepare','compile-control','link-control','audit-control','run-control','compile-telemetry','link-telemetry','run-telemetry','sass','resources','analysis']); a=p.parse_args()
    if a.action=='prepare': prepare()
    elif a.action=='sass': sass()
    elif a.action=='resources': resources()
    elif a.action=='analysis': run('offline-analysis',[sys.executable,OUT/'analyze.py'])
    else:
        action,variant=a.action.split('-'); {'compile':compile_,'link':link,'audit':audit_map,'run':execute}[action](variant)
