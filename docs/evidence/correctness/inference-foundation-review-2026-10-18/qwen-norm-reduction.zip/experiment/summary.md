单 RMSNorm 原生观测已冻结，未改产品数学。

- 原 norm.cu 未插桩控制版和同 TU telemetry 版各只编一次；两次实际执行全部 **47,104 F32 + 47,104 BF16** 与冻结 actual-f32-probe 逐 bit 相同。原归档 kernel 与控制版目标 SASS 完全相同。
- token21/channel619：实测 sum `40cae0ec`、mean `3b4ae0ec`；旧实际 Torch variance 为 `3b4ae0ee`，相差2ULP。按原1024线程、两级 XOR16/8/4/2/1 归约离线重演精确复现实测 sum。
- 实测 rsqrt `418fc2de`；原 SASS 两乘是 `(scale*x)*gamma`。离线 F32 RN 从原生 mean 得到 `3f532636 → 3f568001`；从已保存 Torch variance 得到 `3f532635 → 3f568000`，分别落在 BF16 中点上侧和中点。这解释该坐标的归约顺序差异及已证明的边界传播。
- 观测限制明确保留：写出 mean 使原 FFMA 变为 FMUL+FADD；本 ncols2048 精确缩放和全输出逐 bit 门成立，但不宣称所有原始临时值/任意输入指令完全未变。Torch 实际只保存 variance 和最终值；Torch scale/mul1 是离线推演。不是 Cast 错误或任意 fastmath 因果结论，也不代签24层约2%数值差异。

实际命令001–011、双 bit 门、原始48B telemetry、SASS拓扑/差异、离线公式和输入/闭包身份均在本目录。cleanup-identities.json 仅列 control/probe 和 telemetry/probe 的 exe/map/exp/lib 共8项；两份 CU object、host probe 与原 archive member object 全保留。无删除/移动。
