from pathlib import Path
import json,subprocess,sys,time
r=Path.cwd();s=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
e=windows_compiler_environment(read_cache(r/'.scratch/build-compute-v2-dev'));e['VSLANG']='1033'
a=[]
def run(tag,c):
 t=time.monotonic();p=subprocess.run(list(map(str,c)),cwd=r,env=e,capture_output=True,timeout=30)
 (s/(tag+'.stdout.log')).write_bytes(p.stdout);(s/(tag+'.stderr.log')).write_bytes(p.stderr)
 a.append(dict(tag=tag,command=list(map(str,c)),exit=p.returncode,seconds=time.monotonic()-t));(s/'commands.json').write_text(json.dumps(a,indent=2)+'\n')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-4000:],p.stderr.decode(errors='replace')[-1000:],flush=True);p.check_returncode()
base=json.loads((r/'.scratch/architecture-refactor-2026-10-18/materialized-projection/commands.json').read_text())[0]['command']
run('01-compile',[*base[:-2],s/'consumer.cc','/Fo'+str(s/'consumer.obj')])
vc=Path(base[0]).parent
libs=['hyle_compute.lib','hyle_mem.lib','mimalloc_static.lib','hyle_container.lib','hyle_platform.lib','hyle_error.lib','hyle_platform_thread.lib','hyle_time.lib','hyle_simd.lib']
run('02-link',[vc/'link.exe','/nologo','/MACHINE:X64','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',s/'consumer.obj',*[r/'.scratch/build-compute-v2-dev/bin'/x for x in libs],'bcrypt.lib','PowrProf.lib','Synchronization.lib','advapi32.lib','shell32.lib','ole32.lib','ws2_32.lib','/OUT:'+str(s/'consumer.exe')])
run('03-run',[s/'consumer.exe'])
