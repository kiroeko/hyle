#include "hyle/compute/detail/generated_result.h"
#include "hyle/compute/detail/completion_access.h"
#include "hyle/mem/stats.h"
#include "completion_internal.h"
#include <cstdio>
#include <type_traits>
#include <utility>
namespace c=hyle::compute;namespace d=c::detail;
using hyle::Status;
Status check(bool good,const char*message){return good?Status::Ok():Status::Internal(message);}
struct Payload final {
  int number;int*live;int*destroyed;
  Payload(int value,int&alive,int&dead)noexcept:number(value),live(&alive),destroyed(&dead){++alive;}
  Payload(Payload&&other)noexcept:number(other.number),live(std::exchange(other.live,nullptr)),destroyed(other.destroyed){}
  ~Payload(){if(live){--*live;++*destroyed;}}
};
struct Pending final {d::CompletionLifetime retired{};int waits=0;};
const d::CompletionVTable table{
 [](void*p,d::CompletionLifetime life,Status)noexcept{static_cast<Pending*>(p)->retired=life;},
 [](void*)noexcept->hyle::Result<c::CompletionPoll>{return c::CompletionPoll::kPending;},
 [](void*p)noexcept->Status{++static_cast<Pending*>(p)->waits;return Status::Internal("test must never hide a wait");},
 [](void*)noexcept->Status{return Status::Unimplemented("test cancel");}};
Status run(){
  static_assert(sizeof(d::ResultStorageOwner)==sizeof(void*));
  static_assert(std::is_nothrow_copy_constructible_v<d::ResultStorageOwner>);
  static_assert(std::is_nothrow_move_constructible_v<d::ResultTransfer>);
  static_assert(!std::is_copy_constructible_v<d::ResultTransfer>);
  HYLE_ASSIGN_OR_RETURN(auto allocator,hyle::mem::StatsAllocator::create(hyle::mem::system_allocator()));
  int live=0,destroyed=0;
  {
    HYLE_ASSIGN_OR_RETURN(auto slot,d::ResultSlot<Payload>::create(allocator.get()));
    HYLE_ASSIGN_OR_RETURN(auto write,slot.begin());HYLE_RETURN_IF_ERROR(write.emplace(Payload(42,live,destroyed)));
    HYLE_ASSIGN_OR_RETURN(auto original,write.publish(c::Completion::completed()));
    const auto cold=allocator.snapshot();
    auto transfer=d::ResultAccess::take_storage(std::move(original));
    HYLE_RETURN_IF_ERROR(check(!original.valid() && !original.completion().valid() && transfer.owner.valid() && transfer.completion.valid(),"transfer did not consume original handles"));
    auto copy=transfer.owner;auto assigned=copy;assigned=copy;auto moved=std::move(assigned);
    HYLE_RETURN_IF_ERROR(check(!assigned.valid() && moved.get()==copy.get() && copy.get()==transfer.owner.get(),"opaque copies changed storage identity"));
    HYLE_RETURN_IF_ERROR(transfer.completion.wait());
    const auto*payload=static_cast<const Payload*>(d::ResultAccess::payload(copy));
    HYLE_RETURN_IF_ERROR(check(payload && payload->number==42 && live==1 && !slot.begin(),"copy lost payload or allowed overwrite"));
    transfer.owner.reset();copy.reset();HYLE_RETURN_IF_ERROR(check(!slot.begin(),"last copied owner did not block overwrite"));
    moved.reset();HYLE_ASSIGN_OR_RETURN(auto next,slot.begin());
    HYLE_RETURN_IF_ERROR(check(live==0 && destroyed==1,"unique slot did not clear original payload exactly once"));
    const auto after=allocator.snapshot();
    HYLE_RETURN_IF_ERROR(check(after.total_allocs==cold.total_allocs && after.reallocs==cold.reallocs,"ownership transfer/copy allocated"));
  }
  HYLE_RETURN_IF_ERROR(check(allocator.balanced(),"immediate storage leaked"));
  Pending pending;
  {
    HYLE_ASSIGN_OR_RETURN(auto slot,d::ResultSlot<Payload>::create(allocator.get()));
    HYLE_ASSIGN_OR_RETURN(auto write,slot.begin());HYLE_RETURN_IF_ERROR(write.emplace(Payload(17,live,destroyed)));
    HYLE_ASSIGN_OR_RETURN(auto original,write.publish(d::CompletionAccess::make(&table,&pending)));
    auto transfer=d::ResultAccess::take_storage(std::move(original));
    HYLE_RETURN_IF_ERROR(check(transfer.completion.poll().value()==c::CompletionPoll::kPending && !slot.begin(),"pending result fabricated readiness"));
    slot={};transfer={};
    HYLE_RETURN_IF_ERROR(check(live==1 && destroyed==1 && pending.waits==0 && pending.retired.valid(),"abandon released payload early or hid wait"));
  }
  auto retired=std::exchange(pending.retired,{});retired.terminal(retired.state,Status::Ok());retired.release(retired.state);
  HYLE_RETURN_IF_ERROR(check(live==0 && destroyed==2 && pending.waits==0 && allocator.balanced(),"actual retirement did not release original payload/storage"));
  auto empty=d::ResultAccess::take_storage(c::OwnedResult<Payload>{});
  HYLE_RETURN_IF_ERROR(check(!empty.owner && !empty.completion && !d::ResultAccess::payload(empty.owner),"empty transfer manufactured owner"));
  std::puts("one-pointer opaque owner / allocation-free transfer+copy / exact slot reuse / pending abandon+actual retirement PASS");
  return Status::Ok();
}
int main(){const auto status=run();if(status.ok())return 0;std::fprintf(stderr,"%.*s\n",int(status.message().size()),status.message().data());return 1;}
