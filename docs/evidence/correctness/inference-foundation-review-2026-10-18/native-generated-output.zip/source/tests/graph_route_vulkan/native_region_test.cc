#include <gtest/gtest.h>

#include <array>
#include <bit>
#include <memory>

#include "hyle/graph/vulkan.h"
#include "hyle/graph/executable.h"
#include "hyle/compute/vulkan_memory.h"
#include "../../src/compute_route_vulkan/vulkan_memory_internal.h"

namespace {
namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace vn = v::detail;

const c::TensorDesc description = c::TensorDesc::dense(c::DataType::kFloat32,
    std::array<std::int64_t, 1>{4}).value();

hyle::Status execute(g::Invocation &slot, g::ValueId input, c::ConstTensorView binding) {
  auto status = slot.bind(input, binding);
  EXPECT_TRUE(status.ok()) << "bind: " << status.message();
  if (!status.ok()) return status;
  status = slot.prepare_replay({});
  EXPECT_TRUE(status.ok()) << "prepare_replay: " << status.message();
  if (!status.ok()) return status;
  auto accepted = slot.submit();
  if (!accepted) {
    ADD_FAILURE() << "submit: " << accepted.error().message();
    return std::move(accepted).error();
  }
  status = accepted->wait();
  EXPECT_TRUE(status.ok()) << "completion: " << status.message();
  return status;
}
void expect(const v::Context &context, c::ConstTensorView actual,
            const std::array<float, 4> &expected) {
  auto native = vn::MemoryAccess::tensor_view(vn::Access::runtime(context), actual,
                                             hyle::mem::system_allocator());
  ASSERT_TRUE(native) << native.error().message();
  std::array<float, 4> host{};
  ASSERT_TRUE(context.download(*native, std::as_writable_bytes(std::span(host))).ok());
  for (std::size_t i = 0; i < host.size(); ++i)
    EXPECT_EQ(std::bit_cast<std::uint32_t>(host[i]), std::bit_cast<std::uint32_t>(expected[i])) << i;
}
c::ReadLease input(const v::Context &context, const v::MemoryResource &memory,
                   const std::array<float, 4> &values) {
  auto native = context.upload(description, std::as_bytes(std::span(values))).value();
  return memory.import_readonly(native).value();
}

TEST(VulkanNativeRegion, UnifiedInvocationKeepsGeneratedViewsSlotsAndOwners) {
  auto context = v::Context::create().value();
  RecordProperty("vulkan_device", context.environment().device_name);
  RecordProperty("vulkan_driver", context.environment().driver_info);
  auto memory = v::MemoryResource::create(context, v::MemoryKind::kDevice).value();
  const auto source = g::vulkan::execution_source(context).value();
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(description).value();
  const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, x).value();
  const auto restored = builder.add(c::Unary{c::UnaryKind::kNeg}, negative).value();
  const auto shape = c::TensorShape::create(std::array<std::int64_t, 2>{2, 2}).value();
  const auto computed_view = builder.add(c::View::reshape(shape).value(), restored).value();
  const auto bound_view = builder.add(c::View::reshape(shape).value(), x).value();
  for (const auto value : {negative, computed_view, bound_view}) ASSERT_TRUE(builder.publish(value).ok());
  auto graph = std::move(builder).finish().value();
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  auto compiled = g::compile(graph, {domains, targets});
  ASSERT_TRUE(compiled) << compiled.error().message();
  EXPECT_EQ(compiled->executable.region_count(), 1U);
  EXPECT_EQ(compiled->executable.required_queue_count(), 0U);
  EXPECT_EQ(compiled->executable.workspace_bytes(), 0U);
  auto first = compiled->executable.create_invocation();
  ASSERT_TRUE(first) << first.error().message();
  auto second = compiled->executable.create_invocation();
  ASSERT_TRUE(second) << second.error().message();
  const std::array<float, 4> a{0.25f, -1.5f, 3.75f, -0.0f}, b{-2.25f, 0.5f, -7.0f, 1.25f};
  auto a_input = input(context, memory, a);
  auto b_input = input(context, memory, b);
  auto a_binding = a_input.tensor(description).value();
  auto b_binding = b_input.tensor(description).value();
  ASSERT_TRUE(execute(*first, x, a_binding).ok());
  auto old = first->result(negative).value();
  auto old_computed = first->result(computed_view).value();
  auto old_bound = first->result(bound_view).value();
  expect(context, old.tensor().value(), {-a[0], -a[1], -a[2], -a[3]});
  expect(context, old_computed.tensor().value(), a);
  expect(context, old_bound.tensor().value(), a);
  EXPECT_FALSE(first->bind(x, b_binding).ok());
  EXPECT_FALSE(first->submit());
  ASSERT_TRUE(second->prepare_resources().ok());
  ASSERT_TRUE(second->bind(x, description, b_input).ok());
  ASSERT_TRUE(second->prepare_replay({}).ok());
  {
    auto accepted = second->submit();
    ASSERT_TRUE(accepted) << accepted.error().message();
    ASSERT_TRUE(accepted->wait().ok());
  }
  expect(context, second->output(computed_view).value(), b);
  expect(context, second->output(bound_view).value(), b);
  expect(context, old.tensor().value(), {-a[0], -a[1], -a[2], -a[3]});
  old.reset(); old_computed.reset(); old_bound.reset();
  ASSERT_TRUE(execute(*first, x, b_binding).ok());
  auto retained = first->result(negative).value();
  auto leased = retained.storage_lease();
  ASSERT_TRUE(leased) << leased.error().message();
  expect(context, leased->tensor(description).value(), {-b[0], -b[1], -b[2], -b[3]});
  retained.reset();
  EXPECT_FALSE(first->prepare_replay({}).ok()); // Escaped native lease is not an internal baseline ref.
  leased->reset();
  ASSERT_TRUE(first->prepare_replay({}).ok());
  {
    auto run = first->submit(); ASSERT_TRUE(run) << run.error().message();
    ASSERT_TRUE(run->wait().ok());
  }
  auto final = first->result(negative).value();
  std::weak_ptr<vn::Buffer> weak;
  {
    auto tensor = vn::MemoryAccess::tensor_view(vn::Access::runtime(context), final.tensor().value(),
                                               hyle::mem::system_allocator()).value();
    weak = vn::Access::buffer(tensor);
  }
  *first = {}; *second = {}; compiled->executable = {}; graph = {};
  ASSERT_TRUE(context.close().ok());
  expect(context, final.tensor().value(), {-b[0], -b[1], -b[2], -b[3]});
  EXPECT_FALSE(weak.expired());
  final.reset();
  EXPECT_TRUE(weak.expired()); // No Buffer -> ResultStorage/Invocation back-reference.
}

TEST(VulkanNativeRegion, UnifiedCompileCapturesBorrowedNativeConstant) {
  auto context = v::Context::create().value();
  RecordProperty("vulkan_device", context.environment().device_name);
  RecordProperty("vulkan_driver", context.environment().driver_info);
  auto memory = v::MemoryResource::create(context, v::MemoryKind::kDevice).value();
  const auto source = g::vulkan::execution_source(context).value();
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(description).value();
  const auto weight = builder.constant(description).value();
  const auto sum = builder.add(c::Binary{c::BinaryKind::kAdd}, x, weight).value();
  const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, sum).value();
  ASSERT_TRUE(builder.publish(sum).ok());
  ASSERT_TRUE(builder.publish(negative).ok());
  auto graph = std::move(builder).finish().value();
  auto constant = input(context, memory, {0.5f, -0.25f, 1.25f, 2.0f});
  const std::array constants{g::ConstantBinding{weight, constant.tensor(description).value(),
                                             g::ConstantPolicy::kBorrow}};
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  auto compiled = g::compile(graph, {domains, targets}, {.constants = constants});
  ASSERT_TRUE(compiled) << compiled.error().message();
  EXPECT_EQ(compiled->report.borrowed_constant_count(), 1U);
  EXPECT_EQ(compiled->executable.workspace_bytes(), 0U);
  auto slot = compiled->executable.create_invocation();
  ASSERT_TRUE(slot) << slot.error().message();
  for (const auto values : {std::array<float, 4>{0.25f, 1.5f, -2.75f, 0.0f},
                            std::array<float, 4>{-2.0f, 3.25f, 1.5f, -0.5f}}) {
    auto inputs = input(context, memory, values);
    ASSERT_TRUE(execute(*slot, x, inputs.tensor(description).value()).ok());
    const std::array<float, 4> expected{values[0] + 0.5f, values[1] - 0.25f,
                                      values[2] + 1.25f, values[3] + 2.0f};
    expect(context, slot->output(sum).value(), expected);
    expect(context, slot->output(negative).value(), {-expected[0], -expected[1], -expected[2], -expected[3]});
  }
}
} // namespace
