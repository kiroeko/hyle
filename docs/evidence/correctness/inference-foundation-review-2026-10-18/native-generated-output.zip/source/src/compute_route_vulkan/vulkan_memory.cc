#include "vulkan_memory_internal.h"
#include "vulkan_copy_internal.h"
#include "hyle/compute/detail/vulkan_batch_access.h"
#include "hyle/compute/detail/paged_arena_access.h"

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <new>

namespace hyle::compute::vulkan {
namespace detail {
struct AllocationToken final {
  std::shared_ptr<Buffer> buffer;
  mem::AllocatorRef allocator;
};
struct LeaseViewOwner final {
  std::shared_ptr<Buffer> backing;
  ReadLease source;
};
template<class Frame>struct PagedViewOwner final {
  std::shared_ptr<Buffer> backing;
  Frame frame;
};

struct MemoryState final : mem::MemoryResource {
  std::shared_ptr<Runtime> runtime;
  MemoryKind kind;
  mem::AllocatorRef allocator;

  std::string_view name() const noexcept override {
    return kind == MemoryKind::kDevice ? "Vulkan device buffer" : "Vulkan mapped staging";
  }
  mem::MemoryProperties properties() const noexcept override {
    return {.flags = kind == MemoryKind::kDevice ? mem::MemoryProperty::kDeviceAccessible
                : mem::MemoryProperty::kDeviceAccessible | mem::MemoryProperty::kHostAccessible,
            .minimum_alignment = 1,
            .maximum_allocation = static_cast<std::size_t>(runtime->device->properties.limits.maxStorageBufferRange),
            .domain = {runtime->device.get(), static_cast<std::uintptr_t>(kind)}};
  }
  Result<mem::ResourceAllocation> allocate(std::size_t bytes, std::size_t alignment) noexcept override {
    if (alignment == 0 || (alignment & (alignment - 1)) != 0)
      return std::unexpected(Status::InvalidArgument("invalid Vulkan memory alignment"));
    if (bytes == 0) return mem::ResourceAllocation{nullptr, 0, alignment};
    std::lock_guard lock(runtime->mutex);
    if (runtime->closed) return std::unexpected(Status::FailedPrecondition("Vulkan context is closed"));
    if (!runtime->failure.ok()) return std::unexpected(runtime->failure);
    HYLE_ASSIGN_OR_RETURN(auto buffer, allocate_buffer(runtime->device, bytes,
        kind == MemoryKind::kStaging, false, {.allocator = allocator, .transfer_access = true}));
    if (buffer->mapped != nullptr && reinterpret_cast<std::uintptr_t>(buffer->mapped) % alignment != 0)
      return std::unexpected(Status::InvalidArgument("Vulkan staging cannot satisfy host alignment"));
    auto *storage = allocator.allocate(sizeof(AllocationToken), alignof(AllocationToken));
    if (storage == nullptr) return std::unexpected(Status::ResourceExhausted("Vulkan resource token metadata"));
    auto *token = std::construct_at(static_cast<AllocationToken *>(storage), std::move(buffer), allocator);
    return mem::ResourceAllocation{token, bytes, alignment};
  }
  void deallocate(mem::ResourceAllocation allocation) noexcept override {
    if (allocation.native_handle == nullptr) return;
    auto *token = static_cast<AllocationToken *>(allocation.native_handle);
    const auto selected = token->allocator;
    std::destroy_at(token);
    selected.deallocate(token, sizeof(AllocationToken), alignof(AllocationToken));
  }
  Result<mem::ResourceHostMapping> map_host(void *handle, std::size_t offset,
                                           std::size_t bytes, mem::HostAccess) noexcept override {
    if (bytes == 0) return mem::ResourceHostMapping{};
    auto *token = static_cast<AllocationToken *>(handle);
    if (kind != MemoryKind::kStaging || token == nullptr || token->buffer->mapped == nullptr ||
        offset > token->buffer->bytes || bytes > token->buffer->bytes - offset)
      return std::unexpected(Status::InvalidArgument("Vulkan map requires an in-range staging allocation"));
    return mem::ResourceHostMapping{static_cast<std::byte *>(token->buffer->mapped) + offset, nullptr};
  }
  Status unmap_host(void *, void *, std::size_t, std::size_t, mem::HostAccess) noexcept override { return Status::Ok(); }
  Status mapped_visibility(void *handle, std::size_t offset, std::size_t bytes, bool flush) noexcept {
    if (bytes == 0) return Status::Ok();
    auto *token = static_cast<AllocationToken *>(handle);
    if (kind != MemoryKind::kStaging || token == nullptr || offset > token->buffer->bytes ||
        bytes > token->buffer->bytes - offset)
      return Status::InvalidArgument("Vulkan visibility range requires staging");
    const auto &buffer = *token->buffer;
    if (buffer.memory_flags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) return Status::Ok();
    VkMappedMemoryRange range{};
    range.sType = VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE;
    range.memory = buffer.memory;
    range.size = VK_WHOLE_SIZE; // Original whole mapping, atom alignment preserved.
    auto &device = *runtime->device;
    return native_status(flush ? device.fn.FlushMappedMemoryRanges(device.native.device, 1, &range)
                              : device.fn.InvalidateMappedMemoryRanges(device.native.device, 1, &range),
                         flush ? "vkFlushMappedMemoryRanges" : "vkInvalidateMappedMemoryRanges");
  }
  Status flush(void *handle, std::size_t offset, std::size_t bytes) noexcept override {
    return mapped_visibility(handle, offset, bytes, true);
  }
  Status invalidate(void *handle, std::size_t offset, std::size_t bytes) noexcept override {
    return mapped_visibility(handle, offset, bytes, false);
  }
};

Status MemoryAccess::validate_resource(const std::shared_ptr<Runtime> &runtime,
                                      mem::MemoryResourceRef resource) noexcept {
  if (!runtime || !resource.valid())
    return Status::InvalidArgument("Vulkan execution source requires a valid resource");
  const auto *native = dynamic_cast<const MemoryState *>(&resource.resource());
  if (!native || native->runtime != runtime)
    return Status::InvalidArgument("Vulkan resource belongs to another actual Runtime");
  return Status::Ok();
}

Result<mem::Buffer> MemoryAccess::export_storage(
    const std::shared_ptr<Runtime> &runtime, mem::MemoryResourceRef resource,
    const Tensor &source, mem::AllocatorRef allocator) noexcept {
  HYLE_RETURN_IF_ERROR(validate_resource(runtime, resource));
  if (!source.valid() || !allocator.valid())
    return std::unexpected(Status::InvalidArgument("invalid Vulkan backing export"));
  const auto &state = static_cast<const MemoryState &>(resource.resource());
  const auto &native = Access::buffer(source);
  const bool unbound_view = native->is_view && native->handle == VK_NULL_HANDLE && native->bytes == 0;
  if (native->device != runtime->device || (!unbound_view && native->bytes == 0) ||
      (state.kind == MemoryKind::kStaging) != (native->mapped != nullptr) ||
      !std::in_range<std::size_t>(native->bytes))
    return std::unexpected(Status::InvalidArgument("Vulkan backing export device/kind differs"));
  auto bytes = native->bytes;
  if (unbound_view) {
    // The actual native view object is stable, but its external input root
    // is bound later. This metadata is not exposed until cold bind succeeds.
    HYLE_ASSIGN_OR_RETURN(auto logical, source.description().required_bytes());
    HYLE_ASSIGN_OR_RETURN(bytes, buffer_capacity(logical));
  }
  auto *memory = allocator.allocate(sizeof(AllocationToken), alignof(AllocationToken));
  if (!memory)
    return std::unexpected(Status::ResourceExhausted("Vulkan backing export metadata"));
  auto *token = std::construct_at(static_cast<AllocationToken *>(memory), native, allocator);
  auto adopted = mem::Buffer::adopt(resource, {token, static_cast<std::size_t>(bytes), 1});
  if (!adopted) {
    std::destroy_at(token);
    allocator.deallocate(token, sizeof(AllocationToken), alignof(AllocationToken));
  }
  return adopted;
}

Result<Tensor> MemoryAccess::tensor_view(const std::shared_ptr<Runtime> &runtime,
    const ConstTensorView &source, mem::AllocatorRef allocator) noexcept {
  if (!source.valid() || !allocator.valid())
    return std::unexpected(Status::InvalidArgument("invalid Vulkan tensor view import"));
  const auto storage = source.storage();
  HYLE_RETURN_IF_ERROR(validate_resource(runtime, storage.resource()));
  const auto &resource = static_cast<const MemoryState &>(storage.resource().resource());
  if (resource.kind != MemoryKind::kDevice)
    return std::unexpected(Status::InvalidArgument("Vulkan tensor inputs require device storage"));
  HYLE_ASSIGN_OR_RETURN(auto bytes, source.description().required_bytes());
  if (!storage.native_handle()) {
    if (bytes != 0 || storage.size() != 0)
      return std::unexpected(Status::InvalidArgument("Vulkan tensor input has no native backing"));
    // Original native descriptors retain a four-byte dummy for empty tensors.
    // This cold allocation has no readable logical payload.
    HYLE_ASSIGN_OR_RETURN(auto empty, allocate_buffer(runtime->device, 0, false, true,
        {.allocator = allocator}));
    return Access::tensor(source.description(), std::move(empty));
  }
  const auto &backing = static_cast<const AllocationToken *>(storage.native_handle())->buffer;
  if (!backing || backing->device != runtime->device ||
      storage.offset() > backing->bytes || storage.size() > backing->bytes - storage.offset() ||
      bytes > storage.size())
    return std::unexpected(Status::InvalidArgument("Vulkan tensor input exceeds original backing"));
  HYLE_ASSIGN_OR_RETURN(auto capacity, buffer_capacity(storage.size()));
  if (storage.offset() == 0 && capacity == backing->bytes)
    return Access::tensor(source.description(), backing);
  try {
    auto view = std::allocate_shared<Buffer>(mem::StdAllocator<Buffer>(allocator));
    view->device = backing->device;
    bind_view_buffer(*view, backing, storage.offset());
    view->bytes = storage.size();
    return Access::tensor(source.description(), std::move(view));
  } catch (const std::bad_alloc &) {
    return std::unexpected(Status::ResourceExhausted("Vulkan tensor input view metadata"));
  }
}

Result<std::shared_ptr<Buffer>> MemoryAccess::buffer(
    const MemoryResource &resource, const mem::Buffer &allocation) noexcept {
  if (!resource.valid() || allocation.resource() != resource.ref() || allocation.native_handle() == nullptr)
    return std::unexpected(Status::InvalidArgument("Vulkan allocation resource differs"));
  return static_cast<const AllocationToken *>(allocation.native_handle())->buffer;
}
const std::shared_ptr<Runtime> &MemoryAccess::runtime(const MemoryResource &resource) noexcept {
  return resource.state_->runtime;
}
Result<CopySpan> MemoryAccess::copy_span(const std::shared_ptr<Runtime> &runtime,
                                       mem::ConstBufferView view) noexcept {
  if (!runtime || !view.valid())
    return std::unexpected(Status::InvalidArgument("Vulkan copy view is invalid"));
  const auto *resource = dynamic_cast<const MemoryState *>(&view.resource().resource());
  if (!resource || resource->runtime != runtime)
    return std::unexpected(Status::InvalidArgument("Vulkan copy resource has another Device/family"));
  if (view.size() == 0 && view.native_handle() == nullptr)
    return CopySpan{{}, {reinterpret_cast<std::uintptr_t>(runtime->device.get()), 0, 0, 0, 4}, 0};
  if (!view.native_handle()) return std::unexpected(Status::InvalidArgument("Vulkan copy token is empty"));
  const auto &buffer = static_cast<const AllocationToken *>(view.native_handle())->buffer;
  if (!buffer || buffer->device != runtime->device || buffer->allocation_bytes == 0)
    return std::unexpected(Status::Unimplemented("Vulkan imported copy backing/usage is not proven"));
  // Every original owned root has independent DeviceMemory and TRANSFER_SRC/
  // DST usage. Its views preserve the same VkBuffer, byte offset and actual
  // allocation_bytes, while clearing memory to prevent duplicate frees.
  // Unknown external imports have no such allocation/usage proof.
  if (view.offset() > buffer->bytes || view.size() > buffer->bytes - view.offset() ||
      buffer->offset > SIZE_MAX || view.offset() > SIZE_MAX - static_cast<std::size_t>(buffer->offset))
    return std::unexpected(Status::OutOfRange("Vulkan copy exceeds native backing"));
  const auto origin = static_cast<std::size_t>(buffer->offset) + view.offset();
  std::uint64_t backing_key = 0;
  static_assert(sizeof(buffer->handle) <= sizeof(backing_key));
  std::memcpy(&backing_key, &buffer->handle, sizeof(buffer->handle));
  return CopySpan{buffer, {reinterpret_cast<std::uintptr_t>(runtime->device.get()), backing_key,
                         origin, view.size(), 4}, static_cast<VkDeviceSize>(origin)};
}
} // namespace detail

MemoryResource::MemoryResource() noexcept = default;
MemoryResource::MemoryResource(std::unique_ptr<detail::MemoryState> state) noexcept : state_(std::move(state)) {}
MemoryResource::MemoryResource(MemoryResource &&) noexcept = default;
MemoryResource &MemoryResource::operator=(MemoryResource &&) noexcept = default;
MemoryResource::~MemoryResource() = default;
Result<MemoryResource> MemoryResource::create(const Context &context, MemoryKind kind,
                                             mem::AllocatorRef allocator) noexcept {
  if (!context.valid() || !allocator.valid() || (kind != MemoryKind::kDevice && kind != MemoryKind::kStaging))
    return std::unexpected(Status::InvalidArgument("invalid Vulkan memory resource creation"));
  try {
    auto state = std::make_unique<detail::MemoryState>();
    state->runtime = detail::Access::runtime(context);
    state->kind = kind;
    state->allocator = allocator;
    return MemoryResource(std::move(state));
  } catch (const std::bad_alloc &) {
    return std::unexpected(Status::ResourceExhausted("Vulkan memory resource metadata"));
  }
}
mem::MemoryResourceRef MemoryResource::ref() const noexcept {
  return state_ ? mem::MemoryResourceRef(*state_) : mem::MemoryResourceRef{};
}
Result<Tensor> MemoryResource::allocate(const TensorDesc &description, AllocationOptions options) const noexcept {
  if (!valid() || !description.valid()) return std::unexpected(Status::InvalidArgument("invalid Vulkan tensor allocation"));
  HYLE_ASSIGN_OR_RETURN(auto bytes, description.required_bytes());
  auto &runtime = *state_->runtime;
  std::lock_guard lock(runtime.mutex);
  if (runtime.closed) return std::unexpected(Status::FailedPrecondition("Vulkan context is closed"));
  if (!runtime.failure.ok()) return std::unexpected(runtime.failure);
  HYLE_ASSIGN_OR_RETURN(auto buffer, detail::allocate_buffer(runtime.device, bytes,
      state_->kind == MemoryKind::kStaging, true,
      {.budget = options.resource_budget, .resource = ref(), .category = options.category, .allocator = state_->allocator,
       .transfer_access = true}));
  return detail::Access::tensor(description, std::move(buffer));
}
Result<Tensor> MemoryResource::binding(ReadLease source, const TensorDesc &description,
                                      LeaseImportOptions options) const noexcept {
  if (!valid() || !options.allocator.valid() || state_->kind != MemoryKind::kDevice)
    return std::unexpected(Status::InvalidArgument("Vulkan lease binding requires a device resource/allocator"));
  HYLE_ASSIGN_OR_RETURN(auto tensor, source.tensor(description));
  const auto storage = tensor.storage();
  if (storage.resource() != ref() || storage.native_handle() == nullptr)
    return std::unexpected(Status::InvalidArgument("Vulkan lease belongs to another resource"));
  HYLE_ASSIGN_OR_RETURN(auto bytes, description.required_bytes());
  HYLE_ASSIGN_OR_RETURN(auto capacity, detail::buffer_capacity(bytes));
  const auto &backing = static_cast<const detail::AllocationToken *>(storage.native_handle())->buffer;
  if (bytes == 0 || ((backing->offset + storage.offset()) & 3u) != 0 || capacity > storage.size() ||
      storage.offset() > backing->bytes || storage.size() > backing->bytes - storage.offset())
    return std::unexpected(Status::InvalidArgument("Vulkan lease origin/tail capacity exceeds owned range"));
  try {
    auto allocator = options.allocator;
    if (options.resource_budget.valid()) {
      HYLE_ASSIGN_OR_RETURN(allocator, options.resource_budget.metadata_allocator());
    }
    auto retained = std::allocate_shared<detail::LeaseViewOwner>(
        mem::StdAllocator<detail::LeaseViewOwner>(allocator));
    retained->backing = backing;
    retained->source = std::move(source);
    auto view = std::allocate_shared<detail::Buffer>(mem::StdAllocator<detail::Buffer>(allocator));
    view->device = backing->device;
    detail::bind_view_buffer(*view, backing, storage.offset());
    view->bytes = storage.size();
    view->external_owner = std::move(retained);
    return detail::Access::tensor(description, std::move(view));
  } catch (const std::bad_alloc &) {
    return std::unexpected(Status::ResourceExhausted("Vulkan lease binding metadata"));
  }
}

template<class Frame>static Result<Tensor> paged_binding(const MemoryResource&memory,
    Frame frame,LeaseImportOptions options)noexcept{
  if(!memory.valid() || !options.allocator.valid())
    return std::unexpected(Status::InvalidArgument("Vulkan paged binding requires a resource/allocator"));
  HYLE_ASSIGN_OR_RETURN(auto tensor,compute::detail::PagedArenaAccess::tensor(frame));
  const auto storage=tensor.storage();auto description=tensor.description();
  if constexpr(std::is_same_v<Frame,PagedRowCacheRead>){const auto cap=frame.layout().schema().capacity();
    HYLE_ASSIGN_OR_RETURN(description,row_cache_carrier_description(cap.encoding,std::int64_t(std::uint64_t(cap.max_pages)*cap.page_size)));}
  if(storage.resource()!=memory.ref() || storage.native_handle()==nullptr ||
      static_cast<const detail::MemoryState&>(memory.ref().resource()).kind!=MemoryKind::kDevice)
    return std::unexpected(Status::InvalidArgument("Vulkan page arena belongs to another device resource"));
  HYLE_ASSIGN_OR_RETURN(auto bytes,description.required_bytes());HYLE_ASSIGN_OR_RETURN(auto capacity,detail::buffer_capacity(bytes));
  const auto&backing=static_cast<const detail::AllocationToken*>(storage.native_handle())->buffer;
  if(!bytes || ((backing->offset+storage.offset())&3u)!=0 || capacity>storage.size() ||
      storage.offset()>backing->bytes || storage.size()>backing->bytes-storage.offset())
    return std::unexpected(Status::InvalidArgument("Vulkan paged origin/tail exceeds original capacity"));
  try{
    auto allocator=options.allocator;if(options.resource_budget.valid()){
      HYLE_ASSIGN_OR_RETURN(allocator,options.resource_budget.metadata_allocator());
    }
    auto retained=std::allocate_shared<detail::PagedViewOwner<Frame>>(mem::StdAllocator<detail::PagedViewOwner<Frame>>(allocator));
    retained->backing=backing;retained->frame=std::move(frame);
    auto view=std::allocate_shared<detail::Buffer>(mem::StdAllocator<detail::Buffer>(allocator));
    view->device=backing->device;detail::bind_view_buffer(*view,backing,storage.offset());
    view->bytes=storage.size();view->external_owner=std::move(retained);
    return detail::Access::tensor(description,std::move(view));
  }catch(const std::bad_alloc&){return std::unexpected(Status::ResourceExhausted("Vulkan paged binding metadata"));}
}

Result<Tensor> detail::PagedBatchAccess::binding(const MemoryResource&memory,
    PagedArenaRead frame,LeaseImportOptions options)noexcept{
  return paged_binding(memory,std::move(frame),options);
}
Result<Tensor> detail::PagedBatchAccess::binding(const MemoryResource&memory,
    PagedRowCacheRead frame,LeaseImportOptions options)noexcept{return paged_binding(memory,std::move(frame),options);}
Result<Tensor> detail::PagedBatchAccess::binding(const MemoryResource&memory,
    PagedArenaPendingRead frame,LeaseImportOptions options)noexcept{
  return paged_binding(memory,std::move(frame),options);
}

Result<ReadLease> MemoryResource::import_readonly(const Tensor &source, LeaseImportOptions options) const noexcept {
  if (!valid() || !source.valid() || !options.allocator.valid())
    return std::unexpected(Status::InvalidArgument("invalid Vulkan readonly import"));
  const auto &native = detail::Access::buffer(source);
  if (native->device != state_->runtime->device || native->bytes == 0 ||
      (state_->kind == MemoryKind::kStaging) != (native->mapped != nullptr))
    return std::unexpected(Status::InvalidArgument("Vulkan import device/memory kind mismatch"));
  auto allocator = options.allocator;
  if (options.resource_budget.valid()) {
    HYLE_ASSIGN_OR_RETURN(allocator, options.resource_budget.metadata_allocator());
  }
  auto *storage = allocator.allocate(sizeof(detail::AllocationToken), alignof(detail::AllocationToken));
  if (!storage) return std::unexpected(Status::ResourceExhausted("Vulkan import token metadata"));
  auto *token = std::construct_at(static_cast<detail::AllocationToken *>(storage), native, allocator);
  auto adopted = mem::Buffer::adopt(ref(), {token, static_cast<std::size_t>(native->bytes), 1});
  if (!adopted) {
    std::destroy_at(token);
    allocator.deallocate(token, sizeof(detail::AllocationToken), alignof(detail::AllocationToken));
    return std::unexpected(std::move(adopted).error());
  }
  return ReadLease::adopt(std::move(*adopted), {.allocator = allocator});
}

Result<NativeStorage> MemoryResource::storage_info(const Tensor &tensor) const noexcept {
  if (!valid() || !tensor.valid() || detail::Access::buffer(tensor)->device != state_->runtime->device)
    return std::unexpected(Status::InvalidArgument("Vulkan tensor belongs to another native Device"));
  const auto &buffer = *detail::Access::buffer(tensor);
  return NativeStorage{buffer.handle, buffer.offset, buffer.bytes,
      buffer.allocation_bytes != 0 ? std::optional<std::size_t>(buffer.allocation_bytes) : std::nullopt,
      buffer.transfer_eligible};
}
Result<detail::CopySpan> detail::result_copy_span(const std::shared_ptr<Runtime>&runtime,
    const Results&result,std::size_t index,const TensorDesc&description)noexcept{
  const auto tensors=result.tensors();
  if(index>=tensors.size())return std::unexpected(Status::OutOfRange("Vulkan result copy output index"));
  const auto&tensor=tensors[index];
  if(!tensor.valid() || tensor.description()!=description || !description.is_plain() || !description.is_dense())
    return std::unexpected(Status::InvalidArgument("Vulkan result copy dense carrier differs"));
  const auto&buffer=Access::buffer(tensor);
  HYLE_ASSIGN_OR_RETURN(auto bytes,description.required_bytes());
  if(!runtime || !buffer || buffer->device!=runtime->device || !buffer->allocation_bytes ||
      buffer->offset>SIZE_MAX || bytes>buffer->bytes)
    return std::unexpected(Status::InvalidArgument("Vulkan result copy backing/Device is not qualified"));
  std::uint64_t key=0;static_assert(sizeof(buffer->handle)<=sizeof(key));
  std::memcpy(&key,&buffer->handle,sizeof(buffer->handle));
  return CopySpan{buffer,{reinterpret_cast<std::uintptr_t>(runtime->device.get()),key,
      static_cast<std::size_t>(buffer->offset),bytes,4},buffer->offset};
}
} // namespace hyle::compute::vulkan
