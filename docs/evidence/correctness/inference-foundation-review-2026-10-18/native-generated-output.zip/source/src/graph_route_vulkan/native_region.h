#pragma once

#include "hyle/graph/region_provider.h"

namespace hyle::graph::vulkan::detail {
const RegionProviderVTable *native_region_provider() noexcept;
} // namespace hyle::graph::vulkan::detail
