from pathlib import Path
import json
import os
import sys

import build

ROOT, OUT = build.ROOT, build.OUT
parent = ROOT / '.scratch/architecture-refactor-2026-10-18/materialized-projection'
callers = ROOT / '.scratch/architecture-refactor-2026-10-18/execution-source-callers'
rows = json.loads((parent / 'commands.json').read_text())
args = next(r['command'] for r in reversed(rows)
            if r['tag'] == 'materialized-link' and r['exit'] == 0)
replacements = {name: OUT / name for name in [
    'device.obj', 'operation.obj', 'executable.obj', 'constant_artifact.obj',
    'resources.obj', 'lease_submission.obj', 'region_access.obj']}
replacements.update({name: callers / name for name in [
    'cpu-context.obj', 'graph-batch.obj', 'materialized.obj']})
previous = ROOT / '.scratch/architecture-refactor-2026-10-18/execution-source-core'
for name in ['device.obj', 'operation.obj', 'lease_submission.obj']:
    replacements[name] = previous / name
for name in ['ggml-region.obj', 'graph-batch.obj', 'materialized.obj']:
    replacements[name] = OUT / name
fresh = []
for arg in args:
    name = Path(arg).name.lower()
    if name == 'consumer.obj':
        continue
    if arg.upper().startswith('/OUT:'):
        fresh.append('/OUT:' + str(OUT / 'controls.exe'))
    elif arg.upper().startswith('/MAP:'):
        fresh.append('/MAP:' + str(OUT / 'controls.map'))
    else:
        fresh.append(str(replacements.get(name, arg)))
fresh += [str(OUT / name) for name in [
    'execution_source.obj', 'region_provider_test.obj', 'execution_source_test.obj']]
fresh += [str(ROOT / '.scratch/build-compute-v2-dev/lib' / name)
          for name in ['gtest_main.lib', 'gtest.lib']]
build.driver.run('controls-link', fresh)
torch = next(Path(p) for p in fresh if Path(p).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
build.driver.run('controls-run', [OUT / 'controls.exe', '--gtest_color=no',
    '--gtest_filter=GraphExecutionSource.*:GraphRouteBoundary.CapabilityAdapter*:'
    'GraphRegions.RawBindingsAndOwnedResultsUseTheSameInvocationGate:'
    'GraphRegions.InvocationRetainsItsCompiledRegionAndWorkspaceOwner:'
    'GraphRegions.OrderedSequenceDoesNotHostWaitAndRetainsInvocationUntilTerminal:'
    'GraphRegions.RejectedTailIsReportedAfterTheAcceptedAsyncPrefix:'
    'GraphRegions.AbandonedAggregateRetainsEveryIndependentSink:'
    'GraphRouteBoundary.ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort'])
