from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-generated-output.zip'
NATIVE = ROOT / '.scratch/architecture-refactor-2026-10-18/vulkan-native-region/source-results.zip'
TRANSFER = ROOT / '.scratch/architecture-refactor-2026-10-18/generated-storage-transfer'
sources = [
    'include/hyle/compute/detail/generated_result.h',
    'include/hyle/graph/region_provider.h', 'include/hyle/graph/result.h',
    'src/graph/execution_source_internal.h', 'src/graph/execution_source.cc',
    'src/graph/executable.cc', 'src/graph/plan_state.h', 'src/graph/resources.cc',
    'src/graph/constant_artifact.h', 'src/graph/constant_artifact.cc',
    'src/graph/region_access.cc', 'src/graph_route_cpu_cuda/invocation.cc',
    'src/graph_route_vulkan/CMakeLists.txt', 'tests/graph_route_vulkan/CMakeLists.txt',
    'src/graph_route_vulkan/native_region.h', 'src/graph_route_vulkan/native_region.cc',
    'src/graph_route_vulkan/execution_source.cc',
    'src/compute_route_vulkan/vulkan_program.cc', 'src/compute_route_vulkan/vulkan_carrier.h',
    'src/compute_route_vulkan/vulkan_memory.cc', 'src/compute_route_vulkan/vulkan_memory_internal.h',
    'tests/graph_route_vulkan/native_region_test.cc',
    'tests/compute_batch/materialized_cpu_consumer.cc',
    'tests/graph/region_provider_test.cc', 'tests/graph/execution_source_test.cc',
    'src/graph_batch/batch.cc', 'src/graph_batch/materialized_invocation.cc',
    'src/graph_route_cpu/ggml_region.cc',
    'docs/architecture/compute-design.md', 'docs/developer/current-work.md',
    'docs/user/graph.md', 'test.ps1',
    'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md',
]

def identity(p):
    data = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())

summary = dict(
    scope='First actual native-generated output path in the original shared Graph plan and Invocation',
    validation=dict(native='2/2 actual Vulkan consumers, RTX 4070, driver 617.14',
                    shared_controls='13/13, including async and accepted-prefix lifetime',
                    materialized='Original complete CPU consumer PASS with final core objects',
                    transfer='Original storage/Completion handoff, unique slot reuse and pending abandonment PASS'),
    contracts=['No fake Compute Context/provider/Queue for the native source',
               'Original native Plan/Program/Invocation and Completion, no shadow output workspace',
               'Stable and cold-bound generated outputs, computed/input Views and two independent slots',
               'Raw and owned ResourceEpisode ReadLease input paths',
               'Old GraphOutput/escaped native lease block reuse; release restores it',
               'Output survives close/public slot destruction, final native weak owner expires',
               'Native borrowed constant consumed for two phases with exact F32 checks'],
    failures_preserved=['Original single lifetime attachment collided with native result retention; existing CompletionRetention now composes both',
                        'Generic cached cold preparation now checks real native reuse without absorbing escaped owners into its baseline',
                        'Native intermediate compilation corrections remain in the nested capsule'],
    limitations=['Only the first fixed pure native coarse region is exercised',
                 'Deferred native handle frontier and Apple integration remain incomplete',
                 'CPU-to-native materialized constants, remaining hybrid runtime unification and old public native entry removal remain',
                 'No full model rerun, fair engine performance comparison or all-platform matrix',
                 'No SDK or shader rebuild; inherited unfinished functional/model review remains'],
    sources=[identity(ROOT / p) for p in sources], native_capsule=identity(NATIVE),
    objects=[identity(p) for p in sorted(OUT.glob('*.obj'))])
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', newline='\n')
with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative in sources:
        archive.write(ROOT / relative, 'source/' + relative)
    archive.write(NATIVE, 'parts/vulkan-native-region.zip')
    for p in sorted(TRANSFER.iterdir()):
        if p.suffix in ('.cc', '.h', '.py', '.json', '.log'):
            archive.write(p, 'storage-transfer/' + p.name)
    for p in sorted(OUT.iterdir()):
        if p.suffix in ('.py', '.json', '.log') and p.name != 'archive.json':
            archive.write(p, 'root/' + p.name)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
receipt = identity(DEST)
(OUT / 'archive.json').write_text(json.dumps(receipt, indent=2) + '\n', newline='\n')
print(json.dumps(receipt))
