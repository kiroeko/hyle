from pathlib import Path
import json
import os

import build

ROOT, OUT = build.ROOT, build.OUT
parent = ROOT / '.scratch/architecture-refactor-2026-10-18/materialized-projection'
callers = ROOT / '.scratch/architecture-refactor-2026-10-18/execution-source-callers'
rows = json.loads((parent / 'commands.json').read_text())
compile_args = next(r['command'] for r in reversed(rows)
                    if r['tag'] == 'consumer-compile' and r['exit'] == 0)
compile_args = [('/Fo' + str(OUT / 'materialized-consumer.obj'))
                if p.lower().startswith('/fo') else p for p in compile_args]
build.driver.run('materialized-consumer-compile', compile_args)
args = next(r['command'] for r in reversed(rows)
            if r['tag'] == 'materialized-link' and r['exit'] == 0)
replacements = {name: OUT / name for name in [
    'device.obj', 'operation.obj', 'executable.obj', 'constant_artifact.obj',
    'resources.obj', 'lease_submission.obj', 'region_access.obj']}
replacements.update({name: callers / name for name in [
    'cpu-context.obj', 'graph-batch.obj', 'materialized.obj']})
replacements['consumer.obj'] = OUT / 'materialized-consumer.obj'
previous = ROOT / '.scratch/architecture-refactor-2026-10-18/execution-source-core'
for name in ['device.obj', 'operation.obj', 'lease_submission.obj']:
    replacements[name] = previous / name
for name in ['ggml-region.obj', 'graph-batch.obj', 'materialized.obj']:
    replacements[name] = OUT / name
fresh = []
for arg in args:
    if arg.upper().startswith('/OUT:'):
        fresh.append('/OUT:' + str(OUT / 'materialized.exe'))
    elif arg.upper().startswith('/MAP:'):
        fresh.append('/MAP:' + str(OUT / 'materialized.map'))
    else:
        fresh.append(str(replacements.get(Path(arg).name.lower(), arg)))
fresh.append(str(OUT / 'execution_source.obj'))
build.driver.run('materialized-link', fresh)
torch = next(Path(p) for p in fresh if Path(p).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
build.driver.run('materialized-run', [OUT / 'materialized.exe'])
