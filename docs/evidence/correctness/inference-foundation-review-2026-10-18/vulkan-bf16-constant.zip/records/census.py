from pathlib import Path
import importlib.util,json
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/vulkan-dense-constant/run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.OUT=OUT;r.records=json.loads((OUT/'commands.json').read_text())
s=(ROOT/'src/compute_provider_ggml_vulkan/region.cc').read_text()
marker='    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {\n      auto *node = ggml_graph_node(graph, i);'
probe='''    std::size_t casts = 0, copies = 0;
    bool matmul = false;
    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {
      const auto *node = ggml_graph_node(graph, i);
      matmul |= node->op == GGML_OP_MUL_MAT;
      if (node->op == GGML_OP_CONT && node->ne[0] == 37 && node->ne[1] == 7) ++copies;
      if (node->op == GGML_OP_CPY && node->src[0] && node->src[0]->type == GGML_TYPE_BF16 &&
          node->type == GGML_TYPE_F32 && node->ne[0] == 7 && node->ne[1] == 37) ++casts;
    }
    std::fprintf(stderr,"BFLOAT_MATRIX_CENSUS nodes=%zu matmul=%d RHS_cast=%zu RHS_cont=%zu\\n",
        recipe.nodes.size(), int(matmul), casts, copies);
'''
assert s.count(marker)==1
source=OUT/'native-census.cc';source.write_bytes(('#include <cstdio>\n'+s.replace(marker,probe+marker)).encode())
obj=OUT/'native-census.obj';r.run('native-census-compile',[r.cl,*r.flags,source,'/Fo'+str(obj)])
oldlink=next(x['command'] for x in r.records if x['tag']=='4-link');command=[]
for arg in oldlink:
 if arg.startswith('/OUT:'):arg='/OUT:'+str(OUT/'census.exe')
 elif Path(arg).name=='native-region.obj':arg=str(obj)
 command.append(arg)
r.run('census-link',command)
r.run('census',[OUT/'census.exe','--gtest_filter=VulkanManaged.DenseConstantRhsPacksOnceAndKeepsOtherConsumersAndDynamicWeights','--gtest_color=no'])
