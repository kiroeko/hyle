from pathlib import Path
import importlib.util,json
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/vulkan-bf16-constant'
spec=importlib.util.spec_from_file_location('previous',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/vulkan-dense-constant/run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
oldout=r.OUT;records=json.loads((oldout/'commands.json').read_text());r.OUT=OUT;r.records=[]
for source,stem in [('src/compute_route_vulkan/vulkan_program.cc','program'),('src/compute_route_vulkan/vulkan_region.cc','route-region'),('tests/compute_route_vulkan/managed_region_test.cc','tests')]:
 r.run(stem+'-compile',[r.cl,*r.flags,ROOT/source,'/Fo'+str(OUT/(stem+'.obj'))])
oldlink=next(x['command'] for x in records if x['tag']=='13-final-link')
command=[]
for arg in oldlink:
 if arg.startswith('/OUT:'):arg='/OUT:'+str(OUT/'tests.exe')
 elif Path(arg).parent==oldout and Path(arg).name in ['program.obj','route-region.obj','tests.obj']:arg=str(OUT/Path(arg).name)
 command.append(arg)
r.run('link',command)
r.run('tests',[OUT/'tests.exe','--gtest_filter=VulkanManaged.DenseConstantRhsPacksOnceAndKeepsOtherConsumersAndDynamicWeights','--gtest_color=no'])
