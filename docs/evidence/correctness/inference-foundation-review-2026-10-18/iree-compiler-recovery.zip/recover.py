from pathlib import Path
import hashlib, json, shutil, subprocess, urllib.request, zipfile
R = Path(__file__).resolve().parents[3]
O = Path(__file__).resolve().parent
PIN = '6ef606b6fa3e12bd2c12d36a07463069eb71185f'
T = R/'.scratch/tools/iree-6ef606b6'
T.mkdir(parents=True, exist_ok=True)
release = json.loads((O/'iree-3.12.0rc20260919.json').read_text())
assert release['target_commitish'] == PIN
asset = next(a for a in release['assets'] if a['name'] == 'iree_base_compiler-3.12.0rc20260919-cp312-abi3-win_amd64.whl')
expected = asset['digest'].removeprefix('sha256:')
wheel = T/asset['name']
if not wheel.exists():
    with urllib.request.urlopen(asset['browser_download_url'], timeout=60) as src, wheel.open('xb') as dst:
        shutil.copyfileobj(src, dst)
assert wheel.stat().st_size == asset['size']
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == expected
with zipfile.ZipFile(wheel) as z:
    assert z.testzip() is None
    for name in z.namelist():
        target = (T/'package'/name).resolve()
        assert target.is_relative_to((T/'package').resolve())
    z.extractall(T/'package')
compiler = T/'package/iree/compiler/_mlir_libs/iree-compile.exe'
command = [str(compiler), '--version']
p = subprocess.run(command, cwd=R, capture_output=True, timeout=30)
(O/'compiler-version.stdout.txt').write_bytes(p.stdout)
(O/'compiler-version.stderr.txt').write_bytes(p.stderr)
assert p.returncode == 0, p.stderr.decode(errors='replace')
assert PIN in p.stdout.decode()
files = [compiler,compiler.with_name('IREECompiler.dll'),T/'package/iree/compiler/version.py']
identity = [dict(path=str(f),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in files if f.exists()]
summary = dict(status='recovered_exact_pin', pin=PIN,release=release['html_url'],asset_url=asset['browser_download_url'],wheel=str(wheel),wheel_bytes=wheel.stat().st_size,wheel_sha256=expected,github_digest_verified=True,compiler=str(compiler),version_command=command,version_exit=p.returncode,version_stdout=p.stdout.decode(),files=identity,unpacked_bytes=sum(f.stat().st_size for f in (T/'package').rglob('*') if f.is_file()),notes=['No global pip install, native SDK/LLVM rebuild, product/source/manifest change or capacity gate change.','Official tool wheel is extracted locally; exact CLI version includes the entire required compiler commit.','Only compiler --version executed; no IREE recipe compilation in recovery phase.'])
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)

