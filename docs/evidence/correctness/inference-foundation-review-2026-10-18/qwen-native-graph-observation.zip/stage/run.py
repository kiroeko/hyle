from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent; ROOT=OUT.parents[2]
ARCH=OUT.parent;BASE=ARCH/'qwen-timing-boundary'; FIXED=ARCH/'qwen-fixed-decode'
NSYS=Path(r"C:\Program Files\NVIDIA Corporation\Nsight Systems 2026.1.3\target-windows-x64\nsys.exe")
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
original=read(BASE/'matched-link-plan.json')
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':original['command'][0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in original['command'] if x.lower().endswith('.lib')))+os.pathsep+env['PATH']
def call(tag,args,outputs=()):
 assert not (OUT/(tag+'.command.json')).exists(), 'No implicit retry: '+tag
 row=dict(argv=list(map(str,args)),started=time.time());save(OUT/(tag+'.command.json'),row)
 with (OUT/(tag+'.stdout.log')).open('wb') as so,(OUT/(tag+'.stderr.log')).open('wb') as se:
  process=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=process.pid;save(OUT/'live.json',row);row['exit']=process.wait()
 row.update(terminal=True,finished=time.time(),outputs=[ident(p) for p in outputs if Path(p).is_file()]);save(OUT/(tag+'.result.json'),row);save(OUT/'live.json',row)
 print(tag,row['exit'],round(row['finished']-row['started'],3),flush=True)
 return row

def link():
 argv=[x for x in original['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 argv += ['/OUT:'+str(OUT/'qwen-observe.exe'),'/MAP:'+str(OUT/'qwen-observe.map'),'/IMPLIB:'+str(OUT/'qwen-observe.lib')]
 original_inputs=[x for x in original['command'] if not x.startswith('/') and x.lower().endswith(('.obj','.lib'))]
 assert all(Path(x).is_file() for x in original_inputs if Path(x).is_absolute()) # Bare Windows system import libraries resolve through unchanged LIB.
 save(OUT/'matched-link-plan.json',dict(command=argv,base=ident(BASE/'matched-link-plan.json'),only_changes=['OUT','MAP','IMPLIB'],reused_objects_and_libraries=len(original_inputs),consumer=ident(BASE/'consumer.obj')))
 ids=(FIXED/'science-decode.ids').read_text().split()[:7];assert len(ids)==7
 (OUT/'decode7.ids').write_text(' '.join(ids)+'\n',encoding='ascii')
 save(OUT/'input-identities.json',dict(original_tape=ident(FIXED/'science-decode.ids'),selected_tape=ident(OUT/'decode7.ids'),decode_ids=list(map(int,ids)),model_inputs=str(FIXED/'science-inputs'),original_sequence=ident(BASE/'run-direct.stdout.log'),capacity=64,phases=8,progress='direct',tensor_trace=False,model_weights_copied=False))
 row=call('link-current',argv,[OUT/('qwen-observe'+ext) for ext in ['.exe','.map','.lib','.exp']]);return row['exit']
def observe():
 assert (OUT/'link-current.result.json').exists() and read(OUT/'link-current.result.json')['exit']==0
 version=call('nsys-version',[NSYS,'--version'])
 if version['exit']:return version['exit']
 args=[NSYS,'profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-graph-trace=graph:host-only','--discard-environment=true','--output='+str(OUT/'native-graphs'),OUT/'qwen-observe.exe','--inputs',FIXED/'science-inputs','--decode-ids',OUT/'decode7.ids','--capacity','64','--progress','direct']
 return call('profile-once',args,[OUT/'native-graphs.nsys-rep'])['exit']
def export():
 profile=read(OUT/'profile-once.result.json')
 if profile['exit'] or not (OUT/'native-graphs.nsys-rep').is_file():raise SystemExit('Collection not successful; preserve actual failure, no retry.')
 return call('official-api-stats',[NSYS,'stats','--report','cuda_api_sum,cuda_api_trace','--format','csv','--output',OUT/'native-graphs',OUT/'native-graphs.nsys-rep'],[OUT/'native-graphs.sqlite',OUT/'native-graphs_cuda_api_sum.csv',OUT/'native-graphs_cuda_api_trace.csv'])['exit']
if __name__=='__main__':raise SystemExit({'link':link,'observe':observe,'export':export}[sys.argv[1]]())
