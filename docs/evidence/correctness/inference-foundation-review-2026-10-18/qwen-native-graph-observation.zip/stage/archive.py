"""Archive this observed run; never rebuild, profile, overwrite, move or delete."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
DESTINATION = ROOT / "docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-native-graph-observation.zip"
EXCLUDED = {".exe", ".map", ".lib", ".exp", ".obj", ".o", ".a", ".dll", ".pdb", ".so", ".dylib", ".zip", ".pyc"}


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def payloads():
    result = []
    for path in sorted(STAGE.iterdir(), key=lambda p: p.name):
        if not path.is_file() or path.name == "archive-receipt.json" or path.suffix.lower() in EXCLUDED:
            continue
        data = path.read_bytes()
        result.append((path, "stage/" + path.name, identity(data)))
    return result


def main():
    selected = payloads()
    manifest = {
        "schema": "hyle.qwen.native-graph-observation.archive.v1",
        "scope": "One existing-closure CUDA Nsight Systems observation; eight fixed-tape phases. No SDK, weights, objects or linked images.",
        "source_stage": str(STAGE),
        "entries": [{"name": name, **record} for _, name, record in selected],
        "payload_entries": len(selected),
        "uncompressed_payload_bytes": sum(record["bytes"] for _, _, record in selected),
        "exclusions": sorted(EXCLUDED),
        "receipt_excluded": "archive-receipt.json is generated only after exclusive publication and verification.",
    }
    if sys.argv[1:] != ["--write"]:
        if sys.argv[1:]:
            raise SystemExit("Use no arguments for inventory, or --write for exclusive publication.")
        print(json.dumps({"destination": str(DESTINATION), **manifest}, indent=2))
        return
    assert not DESTINATION.exists(), "Archive already exists; overwrite is forbidden."
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, name, record in selected:
            data = path.read_bytes()
            assert identity(data) == record, str(path)
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(DESTINATION) as archive:
        assert archive.testzip() is None, "ZIP CRC validation failed."
        expected = {name for _, name, _ in selected} | {"manifest.json"}
        assert len(archive.namelist()) == len(expected)
        assert set(archive.namelist()) == expected
        assert json.loads(archive.read("manifest.json")) == manifest
        for path, name, record in selected:
            assert identity(archive.read(name)) == record, name
            assert identity(path.read_bytes()) == record, "Source drift: " + str(path)
    receipt = {
        "destination": str(DESTINATION),
        **identity(DESTINATION.read_bytes()),
        "zip_entries": len(selected) + 1,
        "payload_entries": len(selected),
        "uncompressed_payload_bytes": manifest["uncompressed_payload_bytes"],
        "exclusive_creation": True,
        "crc_verified": True,
        "every_payload_sha256_verified": True,
        "source_drift": False,
        "images_preserved": True,
        "deleted_or_moved_files": 0,
    }
    (STAGE / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
