from pathlib import Path
import collections,csv,hashlib,json,re,sqlite3
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];BASE=OUT.parent/'qwen-timing-boundary'
def save(name,x):(OUT/name).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
# Statistics come only from the two unmodified official reports. Read the same
# official SQLite export solely to recover original target streams/diagnostics.
connection=sqlite3.connect((OUT/'native-graphs.sqlite').resolve().as_uri()+'?mode=ro',uri=True)
streams=[]
for filename,contents in connection.execute('select a.filename,s.value from ANALYSIS_FILE a join StringIds s on s.id=a.contentId'):
 if '/streams/' not in filename:continue
 name='target-'+('stderr' if 'stderr_' in filename else 'stdout')+'.log'
 (OUT/name).write_text(contents,encoding='utf-8');streams.append(dict(original_nsight_embedded_filename=filename,recovered=ident(OUT/name)))
diagnostics=[dict(timestamp_ns=t,severity=s,text=m) for t,s,m in connection.execute('select timestamp,severity,text from DIAGNOSTIC_EVENT')]
save('nsight-diagnostics.json',dict(events=diagnostics,embedded_streams=streams,scope='Read-only recovery of original target output/diagnostic metadata from the official Nsight SQLite export; no custom tracing or alternate GPU statistics.'))
actual=json.loads((OUT/'target-stdout.log').read_text().strip());original=json.loads((BASE/'run-direct.stdout.log').read_text().strip());tape=list(map(int,(OUT/'decode7.ids').read_text().split()))
assert actual['generated_ids']==original['generated_ids'][:8]
assert actual['decode_input_ids']==original['decode_input_ids'][:7]==tape
assert actual['source_id']==original['source_id'] and actual['text_tensors']==320 and actual['visible_tokens']==28 and actual['fixed_decode']
save('sequence-parity.json',dict(source_id=actual['source_id'],generated_ids=actual['generated_ids'],expected_first_8=original['generated_ids'][:8],all_8_equal=True,decode_inputs=tape,visible_tokens=28,text_tensors=320,tensor_trace=False,raw_tensor_numerical_acceptance=False,target_stdout=ident(OUT/'target-stdout.log'),original_sequence=ident(BASE/'run-direct.stdout.log')))
trace=list(csv.DictReader((OUT/'native-graphs_cuda_api_trace.csv').open()));summary=list(csv.DictReader((OUT/'native-graphs_cuda_api_sum.csv').open()))
selected=lambda s:any(x in s for x in ('StreamBeginCapture','StreamEndCapture','GraphInstantiate','GraphExecUpdate','GraphLaunch'))
api=collections.defaultdict(collections.Counter)
for r in trace:
 if selected(r['Name']):api[r['Name']][r['Result']]+=1
for name,counts in api.items():
 official=next(r for r in summary if r['Name']==name);assert int(official['Num Calls'])==sum(counts.values())
assert sum(v.get('0',0) for name,v in api.items() if 'GraphLaunch' in name)==2017
assert all(set(v)=={'0'} for v in api.values())
readbacks=[r for r in trace if r['Name']=='cuMemcpyDtoH_v2' and r['Result']=='0'];assert len(readbacks)==8
warm=0;warmups=[]
for line in (OUT/'target-stderr.log').read_text().splitlines():
 if 'CUDA graph warmup complete' in line:warm+=1
 if line.startswith('prefill ') or re.match(r'decode\d+ ',line):warmups.append((line.split()[0],warm));warm=0
assert warmups==[('prefill',0),('decode1',0),('decode2',0),('decode3',401),('decode4',401),('decode5',0),('decode6',0),('decode7',0)]
phases=[];previous=-1
for i,readback in enumerate(readbacks):
 end=int(readback['Start (ns)'])+int(readback['Duration (ns)']);counts=collections.Counter(r['Name'] for r in trace if previous<int(r['Start (ns)'])<=end and r['Result']=='0' and selected(r['Name']))
 phases.append(dict(phase=warmups[i][0],interval_start_exclusive_ns=previous,interval_end_inclusive_ns=end,end_boundary=readback,successful_api_calls=dict(counts),original_ggml_warmup_messages=warmups[i][1]));previous=end
assert not any(selected(r['Name']) and int(r['Start (ns)'])>previous for r in trace)
result=dict(schema='hyle.qwen.native-graph-observation.v1',profile_attempts=1,profile_exit=read(OUT/'profile-once.result.json')['exit'],official_reports_exit=read(OUT/'official-api-stats.result.json')['exit'],nsight_version=(OUT/'nsys-version.stdout.log').read_text().strip(),geometry=dict(layers=24,graph_nodes=1878,steps=1204,capacity=64,phases=8,prefill_tokens=21,forced_decode_inputs=7,progress='direct',tensor_trace=False),successful_api_counts={name:v['0'] for name,v in api.items()},all_recorded_selected_api_calls_returned_success=True,sequence_first_8_equal=True,phase_bins=phases,phase_boundary_method='Observed exactly eight successful cuMemcpyDtoH_v2 calls. The no-trace consumer has exactly one final next-token BufferView::read per phase; CudaResourceBase::read issues this original API. Bin ordered official API records up to each read completion. The prefill bin includes loading and cold setup; other intervals include intervening preparation. There are no NVTX markers or added callbacks.',phase_boundary_sources=['tools/qwen35_text/main.cc:503-520 original submit/wait/next-token read','src/compute_backend_cuda/cuda_memory.cc:107-120 device read -> cuMemcpyDtoH','qwen-timing-boundary/candidate/main.cc exact compiled consumer snapshot'],interpretation=['CUDA graph work really occurs despite ordinary Graph replay Commands: 2017 recorded successful native graph launches.','Decode1/2 contain no recorded selected graph APIs; decode3/4 each record 401 begin/end/instantiate/update/launch calls and the original ggml target log independently prints 401 graph-warmup messages. Decode5/6/7 each launch 401 graphs without new recorded captures/instantiations. This is consistent with the original two-slot native warmup then replay mechanism.','The prefill/cold interval has 24 capture/instantiate-with-flags calls and 12 graph launches. No call stack was collected; these early calls are not attributed to a specific provider or node.','The total API/phase counts are not per-node or per-provider graph identities. The 401 correspondence and original ggml logs support native warmup, not unique attribution of every collected graph API.','No full tensor trace was collected; only the first eight generated IDs and input tape are compared with the original frozen run.','No throughput or speedup acceptance. This is a software-instrumented Nsight run, including a driver-version compatibility warning; the profiled target timing fields are not a fair unprofiled performance result.'],diagnostic_limits=['Installed driver reports CUDA13.4 while this Nsight build uses cupti64_133.dll for13.3; Nsight issued the retained warning.','Hardware tracing is unsupported on this system; Nsight explicitly collected a legacy software-instrumented trace.','Default trace-all-apis=false was retained. Counts are for observed named calls; unobserved other APIs are not proved absent. API success means the recorded return value is zero; cudaGraphExecUpdate result-info arguments were not captured and are not separately asserted.','Official API summary/trace are the only GPU statistics exports. SQLite metadata was read only to recover original stdout/stderr and diagnostic records.'],evidence={name:ident(OUT/name) for name in ['matched-link-plan.json','input-identities.json','profile-once.command.json','profile-once.result.json','official-api-stats.command.json','official-api-stats.result.json','native-graphs.nsys-rep','native-graphs.sqlite','native-graphs_cuda_api_sum.csv','native-graphs_cuda_api_trace.csv','target-stdout.log','target-stderr.log','nsight-diagnostics.json','sequence-parity.json']})
save('results.json',result)
images=[ident(OUT/('qwen-observe'+ext)) for ext in ['.exe','.map','.lib','.exp']]
save('linked-image-cleanup.json',dict(policy='Manifest only. Root must write exact removal in repository test.ps1; no deletion or move by this task.',files=images,total_bytes=sum(x['bytes'] for x in images),retain=['all reused objects in original stages','all official report/SQLite/CSV and recovered target streams','scripts, command/result receipts and tape'],nsight_default_temporary_paths=dict(qdstrm='C:/Users/kiro/AppData/Local/Temp/nsys-report-9f15.qdstrm',session='C:/Users/kiro/AppData/Local/Temp/nvidia/nsight_systems/quadd_session_1081092',both_absent_after_success=True)))
plan=read(OUT/'matched-link-plan.json');plan['reused_objects_and_libraries']=sum(1 for x in plan['command'] if not x.startswith('/') and x.lower().endswith(('.obj','.lib')));save('matched-link-plan.json',plan)
save('observation-receipt.json',dict(results=ident(OUT/'results.json'),sequence=ident(OUT/'sequence-parity.json'),report=ident(OUT/'native-graphs.nsys-rep'),sqlite=ident(OUT/'native-graphs.sqlite'),api_csvs=[ident(OUT/n) for n in ['native-graphs_cuda_api_sum.csv','native-graphs_cuda_api_trace.csv']],image_cleanup=ident(OUT/'linked-image-cleanup.json'),product_source_or_sdk_compiled=False,source_changes=False,inference_runs=1,stage_payload_file_bytes_excluding_this_receipt=sum(q.stat().st_size for q in OUT.iterdir() if q.is_file() and q.name!='observation-receipt.json'),gpu_window_released=True))
print(json.dumps(dict(api_counts=result['successful_api_counts'],report_bytes=(OUT/'native-graphs.nsys-rep').stat().st_size,sequence_equal=True,cleanup_bytes=sum(x['bytes'] for x in images))))
