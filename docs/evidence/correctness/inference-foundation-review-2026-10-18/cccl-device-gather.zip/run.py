from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cuda_cache', ROOT / '.scratch/mtp-completion/run.py')
cache = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cache)
FLAGS = cache.flags + ['/I' + str(ROOT / 'src/compute_provider_cuda')]
RECORDS = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def run(tag, args, allowed=(0,), timeout=180):
    args = list(map(str, args))
    stem = tag + '-' + str(1 + sum(r['tag'] == tag for r in RECORDS))
    start = time.monotonic()
    result = subprocess.run(args, cwd=ROOT, env=cache.env, capture_output=True, timeout=timeout)
    (OUT / (stem + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(result.stderr)
    RECORDS.append(dict(tag=tag, command=args, exit=result.returncode, seconds=time.monotonic()-start))
    (OUT / 'commands.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    print(tag, result.returncode, round(RECORDS[-1]['seconds'], 2), flush=True)
    print(result.stdout.decode(errors='replace')[-5500:], result.stderr.decode(errors='replace')[-1800:], flush=True)
    if result.returncode not in allowed:
        raise SystemExit(result.returncode)
    return result


def compile_host(source, stem):
    target = OUT / (stem + '.obj')
    run(stem + '-compile', [cache.cl, *FLAGS, source, '/Fo' + str(target)])
    return target


def link(stem, provider, native):
    args = [cache.link, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
            '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(OUT / (stem + '.exe')),
            provider, native, OUT / 'gather-tests.obj', OUT / 'collectives-tests.obj',
            cache.OUT / 'operation.obj', *cache.libs,
            cache.BASE / 'lib/gtest_main.lib', cache.BASE / 'lib/gtest.lib', *cache.system]
    run(stem + '-link', args)


def before():
    compile_host(ROOT / 'tests/compute_provider_cuda/gather_collectives_test.cc', 'gather-tests')
    compile_host(ROOT / 'tests/compute_provider_cuda/collectives_test.cc', 'collectives-tests')
    provider = compile_host(OUT / 'before/src/compute_provider_cuda/collectives_provider.cc', 'before-provider')
    native = ROOT / '.scratch/b-cuda-d5/src/compute_provider_cuda/CMakeFiles/hyle_compute_provider_cuda.dir/collectives.cu.obj'
    link('before', provider, native)
    run('before-tests', [OUT / 'before.exe', '--gtest_color=no',
        '--gtest_filter=CudaCcclGather.CheckedSubmitStaysPendingBehindProducerAndReportsDeviceError'], allowed=(1,))


def build():
    compile_host(ROOT / 'src/compute_provider_cuda/collectives_provider.cc', 'provider')
    run('native-compile', [cache.toolkit / 'bin/nvcc.exe', '--std=c++20', '--expt-relaxed-constexpr',
        '--gpu-architecture=sm_89', '--compiler-bindir', cache.cl.parent,
        '-Xcompiler=/MD,/EHsc,/Zc:preprocessor,/utf-8,/bigobj', '-O2', '-DNDEBUG', '-DNOMINMAX',
        '-I' + str(ROOT / 'src/compute_backend_cuda'), '-I' + str(cache.toolkit / 'include/cccl'),
        '-c', ROOT / 'src/compute_provider_cuda/collectives.cu', '-o', OUT / 'native.obj'], timeout=600)
    link('after', OUT / 'provider.obj', OUT / 'native.obj')


def refresh_tests():
    compile_host(ROOT / 'tests/compute_provider_cuda/gather_collectives_test.cc', 'gather-tests')
    link('after', OUT / 'provider.obj', OUT / 'native.obj')


def graph():
    source = ROOT / 'tests/graph_route_cuda/gather_test.cc'
    test_object = compile_host(source, 'graph-tests')
    commands = json.loads((ROOT / '.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/commands.json').read_text())
    args = next(r['command'] for r in reversed(commands) if r['tag'] == 'canonical-link')
    excluded = {
        str(ROOT / '.scratch/inference-feature-completion-2026-10-18/windows-batch/cuda-collectives_provider.obj'),
        str(ROOT / '.scratch/b-cuda-d5/src/compute_provider_cuda/CMakeFiles/hyle_compute_provider_cuda.dir/collectives.cu.obj'),
        str(ROOT / '.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/canonical.obj'),
    }
    args = [a for a in args if a not in excluded and not a.startswith(('/OUT:', '/MAP:'))]
    assert len(excluded) == 3
    args += [OUT / 'provider.obj', OUT / 'native.obj', test_object, '/OUT:' + str(OUT / 'graph.exe')]
    runtime = [str(Path(a).parent) for a in args if isinstance(a, str) and a.endswith('.lib') and Path(a).is_absolute()]
    cache.env['PATH'] = os.pathsep.join(dict.fromkeys(runtime)) + os.pathsep + cache.env['PATH']
    run('graph-link', args)
    run('graph-tests', [OUT / 'graph.exe', '--gtest_color=no',
        '--gtest_filter=CudaDefaultGraph.CheckedEmbeddingNormResidualUsesDefaultDirectAndPreparedSlots:CudaDefaultGraph.CheckedGatherErrorsRecoverWithManagedProvider'])


def test():
    run('hardware', ['nvidia-smi', '--query-gpu=name,driver_version,memory.total,memory.free', '--format=csv'])
    filters = 'CudaCcclGather.*:CudaCccl.ScanAxesByteStridesBroadcastAndHighRanks:CudaCccl.TopKFourTypesStableTiesNaNsAndOriginalBits:CudaCccl.OverflowChecksEveryPrefixAndPreservesEntireOutput:CudaCccl.PendingCompletionRetainsPreparedOwnersWithCallerWorkspace'
    run('after-tests', [OUT / 'after.exe', '--gtest_color=no', '--gtest_filter=' + filters])


if __name__ == '__main__':
    for action in sys.argv[1:] or ['before', 'build', 'test']:
        globals()[action]()
