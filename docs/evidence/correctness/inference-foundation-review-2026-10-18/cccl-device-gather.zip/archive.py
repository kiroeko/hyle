from pathlib import Path
import difflib
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    files = [
        'src/compute_provider_cuda/collectives.h',
        'src/compute_provider_cuda/collectives.cu',
        'src/compute_provider_cuda/collectives_provider.cc',
        'tests/compute_provider_cuda/gather_collectives_test.cc',
        'tests/compute_provider_cuda/collectives_test_support.h',
        'tests/compute_provider_cuda/collectives_test.cc',
        'tests/graph_route_cuda/gather_test.cc',
        'src/compute_backend_cuda/device_status_kernel.h',
        'src/compute_provider_cuda/CCCL-LICENSE.txt',
        'docs/user/compute.md',
    ]
    changes = []
    for name in files:
        before = OUT / 'before' / name
        if before.exists():
            changes.extend(difflib.unified_diff(before.read_text('utf-8').splitlines(True),
                (ROOT / name).read_text('utf-8').splitlines(True), fromfile='before/' + name, tofile='after/' + name))
    (OUT / 'task.diff').write_text(''.join(changes), encoding='utf-8')
    objects = [OUT / (name + '.obj') for name in ['provider', 'native', 'gather-tests', 'collectives-tests', 'graph-tests']]
    native_before = ROOT / '.scratch/b-cuda-d5/src/compute_provider_cuda/CMakeFiles/hyle_compute_provider_cuda.dir/collectives.cu.obj'
    (OUT / 'identities.json').write_text(json.dumps({
        'source': [identity(ROOT / name) for name in files],
        'retained_objects': [identity(p) for p in objects],
        'original_native': identity(native_before),
    }, indent=2) + '\n', encoding='utf-8')
    summary = {
        'problem': 'CUDA default plain Checked Gather previously performed CUB Min+Max,16B bounds D2H and stream synchronize before writing gathered values. Kimi residual-bank Gather can reach this route; a fused ggml region may take a different path.',
        'change': 'Reuse original CCCL counting iterators, GatherMap and alignment-safe byte-stride/index reads. First par_nosync for_each validates all I32/I64 IDs into original Queue device-status. Second par_nosync for_each gates every output write on that word. No full-ID or bounds readback, no Gather temporary workspace.',
        'runtime': 'Same SharedQueue managed execution; blocks_host now false for Gather. Original external-capture rejection remains. Queue resets and observes its own status under original Completion/accepted-prefix lifetime. Scan/TopK behavior unchanged, including integer-scan host overflow checks.',
        'validation': {
            'direct': 'Final8/8 canonical tests:4 Gather plus4 Scan/TopK controls. Gather numeric test covers15 scalar storage types*2 index widths*3 axes*2 source layouts*2 index layouts plus high-rank,scalar and broadcast edge cases; raw bit preservation. Invalid-lastID including signed extremes leaves whole output unchanged; fresh sequence/slot recovers. Empty and Unchecked/alias contracts pass.',
            'producer_gate': 'Actual CUDA stream host callback holds producer. Old native/provider cannot return pending before5-second fail-safe opens gate (baseline expectedFAIL). New valid and invalid submit both return pending before release; release then produces exact values or OutOfRange with old sentinel bytes. This is a liveness test, not a throughput or latency benchmark.',
            'default_graph': 'Unmodified existing gather_test.cc compiled against default Graph/CUDA roster with fresh collectives provider+native pair:2/2 PASS, embedding->norm->residual two-slot replay and old-output/metadata-allocation checks, plus invalid IDs/preparation without execution/whole-output retention/fresh invocation recovery.',
            'hardware': 'Actual RTX4070 SM89,driver617.14,CUDA13.3,MSVC14.50.35717; hardware logs retained.',
        },
        'failures_retained': [
            'Old provider baseline gate test fails as expected, including original blocks_host=true.',
            'First native compile hit namespace shadowing after including device-status protocol. Qualify existing SDK cuda::std references with global ::; no algorithm change to those two references.',
            'First candidate8-test run was7/8 solely because the shared old Gather helper expected blocks_host=true. Updated that expectation; no numeric/failure budget change. Recompiled only Gather test TU; final8/8 PASS.',
        ],
        'build_boundary': 'One affected native collectives TU compiled successfully, host provider/tests fresh, original SDK and remaining libraries reused. CMake source list unchanged. No full SDK/configure/build/download. Private submit signature changed and both paired objects must be used together; Program layout and public API unchanged.',
        'not_claimed': ['No whole Kimi/model/22profile execution', 'No native CUDA capture or all-GPU pipeline claim', 'No throughput or full-process peak-memory measurement', 'No change to Scan/TopK synchronization or other providers'],
        'reproduce': 'run.py before/build/test/graph. after-tests-2.stdout.log and graph-tests-1.stdout.log contain final passes. All original failures and command variants retained.',
    }
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    candidates = [identity(p) for p in OUT.iterdir() if p.is_file() and p.suffix.lower() in {'.exe', '.lib', '.exp'}]
    (OUT / 'cleanup-candidates.json').write_text(json.dumps({'files': candidates, 'retain_objects': [str(p) for p in objects]}, indent=2) + '\n', encoding='utf-8')
    entries = [(p, p.name) for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix in {'.py', '.json', '.log', '.diff'}]
    entries += [(p, str(p.relative_to(OUT)).replace('\\', '/')) for p in sorted((OUT / 'before').rglob('*')) if p.is_file()]
    entries += [(ROOT / name, 'sources/' + name) for name in files]
    target = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/cccl-device-gather.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, name in entries:
            archive.writestr(name, path.read_bytes())
    print(json.dumps(identity(target)))


if __name__ == '__main__':
    main()
