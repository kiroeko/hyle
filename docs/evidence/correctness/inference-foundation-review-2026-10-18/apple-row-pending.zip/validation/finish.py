from pathlib import Path
import importlib.util, json, shutil, sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner',OUT/'run.py')
run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
TAGS=['002-control-test','006-context','007-mature','008-operations','009-row-paged',
      '010-lowering','011-region','012-page-region','013-page-pending',
      '015-direct-row-test','016-paged-row-test','017-indexer-test']

code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root'])
def identity(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
def save(name,data):(r/name).write_text(json.dumps(data,indent=2)+'\n')
compiled=[];retained=[]
for tag in p['tags']:
 row=json.loads((r/(tag+'.result.json')).read_text());assert row['exit']==0
 for obj in row['outputs']:
  assert identity(obj['path'])==obj
  if obj['path'].endswith('.o'):retained.append(obj)
 compiled.append(row)
assert len(retained)==12
links={tag:json.loads((r/(tag+'.result.json')).read_text()) for tag in ['003-control-link','018-current-link','020-native-link']}
for row in links.values():
 for item in row['inputs_before']:assert identity(item['path'])==item
for tag in ['018-current-link','020-native-link']:
 for item in links[tag]['outputs']:assert identity(item['path'])==item
selected=[]
for stem in ['row-pending-tests','native-page-pending']:
 text=(r/(stem+'.map')).read_text().split('# Object files:\n',1)[1].split('# Sections:',1)[0]
 for row in compiled:
  if stem=='native-page-pending' and row['tag'] in ['002-control-test','015-direct-row-test','016-paged-row-test','017-indexer-test']:continue
  obj=next(x for x in row['outputs'] if x['path'].endswith('.o'))
  found=[line for line in text.splitlines() if line.endswith(obj['path'])];assert len(found)==1,(stem,obj,found)
  selected.append(dict(image=stem,object=obj,map_entry=found[0]))
save('selected-current-owners.json',selected)
symbols={}
for tag in ['011-region','012-page-region','013-page-pending']:
 obj=next(x['path'] for x in json.loads((r/(tag+'.result.json')).read_text())['outputs'] if x['path'].endswith('.o'))
 result=subprocess.run(['nm','-gU',obj],capture_output=True,text=True);assert result.returncode==0,result.stderr
 symbols[tag]=[line for line in result.stdout.splitlines() if 'N4hyle5graph5apple6submit' in line or 'N4hyle5graph5apple11take_update' in line]
assert not symbols['011-region'] and not symbols['012-page-region']
assert len(symbols['013-page-pending'])==2,symbols
save('typed-source-symbol-owners.json',symbols)
math=[identity(x['path']) for x in p['math']];assert math==p['math']
assert (r/'mlx.metallib').resolve()==Path(math[0]['path']).resolve()
cleanup=dict(host='kiro@172.22.10.198',root=str(r),files=links['018-current-link']['outputs']+links['020-native-link']['outputs'],retain=retained)
assert len({x['path'] for x in cleanup['files']})==4
assert not {x['path'] for x in cleanup['files']} & {x['path'] for x in retained}
save('cleanup-mac.json',cleanup)
for tag in ['019-current-run','021-native-run']:
 row=json.loads((r/(tag+'.result.json')).read_text());assert row['exit']==0 and row['terminal']
 ps=subprocess.run(['ps','-p',str(row['pid']),'-o','command='],capture_output=True,text=True)
 assert ps.returncode!=0 or str(r) not in ps.stdout
save('final-link-input-identities.json',{tag:row['inputs_before'] for tag,row in links.items()})
final=dict(current_gtests=17,current_exit=0,native_exit=0,live_process=False,retained_stage_objects=len(retained),
 current_link_inputs=len(links['018-current-link']['inputs_before']),native_link_inputs=len(links['020-native-link']['inputs_before']),
 selected_owner_rows=len(selected),typed_source_owner='013-page-pending',cleanup_files=4,cleanup_bytes=sum(x['bytes'] for x in cleanup['files']),math=math)
save('final-verification.json',final);print(json.dumps(final))
'''
math=json.loads((OUT/'baseline-identities.json').read_text())['math']
result=run.prior.air.ssh(code,json.dumps(dict(root=run.REMOTE,tags=TAGS,math=math)).encode(),timeout=45)
(OUT/'022-verify.stdout.log').write_bytes(result.stdout);(OUT/'022-verify.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0
run.prior.collect()

def read(name):return json.loads((OUT/'results'/name).read_text())
sources={}
for name in ['001-control-source-sources.json','005-final-products-sources.json','014-existing-test-sources-sources.json']:
 for row in json.loads((OUT/name).read_text()):sources[row['path']]=row
for path in ['tests/graph_route_apple/row_cache_projection_test.cc',
             'tests/compute_batch/pending_paged_receiver_native_consumer.cc',
             'src/graph_route_apple/CMakeLists.txt','tests/graph_route_apple/CMakeLists.txt']:
 sources[path]=run.prior.identify(run.ROOT/path)
for path,row in sources.items():
 assert run.prior.identify(run.ROOT/path)==row,(path,'source drift')
 dest=OUT/'final-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(run.ROOT/path,dest)
save=run.save
save('final-source-identities.json',list(sources.values()))
dependencies={};unmapped=[]
for tag in TAGS:
 for row in read(tag+'.result.json')['dependencies']:
  path=row['path'];logical=None
  if path.startswith(run.REMOTE+'/'):logical=path[len(run.REMOTE)+1:]
  elif path.startswith(run.AIR_BASE+'/'):logical=path[len(run.AIR_BASE)+1:]
  if not logical or not (run.ROOT/logical).is_file():unmapped.append(row);continue
  actual=run.prior.identify(run.ROOT/logical)
  assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),(tag,row,actual)
  dependencies[logical]=actual
save('dependency-check.json',dict(matched_current=len(dependencies),drift=[],unmapped=unmapped))
shutil.copyfile(OUT/'results/cleanup-mac.json',OUT/'cleanup-mac.json')
result=read('019-current-run-tests.json');assert result['tests']==17 and result['failures']==0
verified=read('final-verification.json')
summary=dict(status='passed_current_17_plus_original_native_pending_consumer',
 hardware=json.loads((OUT/'baseline-identities.json').read_text())['hardware'],
 old_control=dict(run='004-control-run',tests=3,passed=0,failed=3,reason='selected projected reader has no pending source admission'),
 current=dict(link='018-current-link',run='019-current-run',tests=17,passed=17,failed=0,groups={'new_pending':3,'ready_projection':6,'direct_row':4,'direct_paged':1,'indexer_direct_graph_empty':3}),
 native=dict(link='020-native-link',run='021-native-run',exit=0,checks=['F16 and BF16 each 64 steps','active Q2/18 and two slots each','two page nodes share one Update','CPU Abs/Cast to native to Cast/Neg','exact pages, untouched history, same generation','196608 dirty bytes each dtype']),
 fresh_product_host_tus=8,fresh_existing_test_tus=3,fresh_new_test_tus=1,reused_ready_test_object=True,reused_native_main=True,
 typed_submit_take_update_owner='013-page-pending',selected_map_owners='results/selected-current-owners.json',
 no_sdk_air_or_metallib_build=True,retained_original_mlx_math=math,
 source_count=len(sources),source_drift=[],dependencies='dependency-check.json',
 cleanup=dict(manifest='cleanup-mac.json',files=verified['cleanup_files'],bytes=verified['cleanup_bytes']),
 retained_stage_objects=12,live_process=False,not_claimed=['new pending cancel-injection coverage','cancellation permits no read after accepted producer cancellation','performance improvement or zero warm allocations'])
save('summary.json',summary)
save('runner-source-identities.json',[run.prior.identify(run.PREVIOUS/'run.py'),run.prior.identify(run.OUT.parents[1]/'apple-page-invocation/air.py'),run.prior.identify(OUT/'run.py'),run.prior.identify(OUT/'finish.py')])
save('receipt.json',dict(summary=run.prior.identify(OUT/'summary.json'),cleanup=run.prior.identify(OUT/'cleanup-mac.json'),sources=run.prior.identify(OUT/'final-source-identities.json'),dependencies=run.prior.identify(OUT/'dependency-check.json')))
print(json.dumps(summary,indent=2))
