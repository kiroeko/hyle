from pathlib import Path
import difflib
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
V = STAGE / 'validation'
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

sources = json.loads((V / 'final-source-identities.json').read_text())
for entry in sources:
    actual = identity(V / 'final-source' / entry['path'])
    assert (actual['bytes'], actual['sha256']) == (entry['bytes'], entry['sha256'])
summary = json.loads((V / 'summary.json').read_text())
assert summary['current']['passed'] == 17 and summary['native']['exit'] == 0
assert len(sources) == 144 and not summary['source_drift']
assert json.loads((V / 'dependency-check.json').read_text()) == dict(matched_current=134, drift=[], unmapped=[])
save(STAGE / 'cleanup-plan.json', dict(remote_manifest=identity(V / 'cleanup-mac.json'),
                                     retained_math=summary['retained_original_mlx_math']))

# The next slice may already be editing the live tree. Archive exactly the
# compiled stage snapshots, not later work under the same product paths.
logical_paths = [
    'include/hyle/compute/detail/apple_plan.h',
    'src/compute_route_apple/apple_context.cc',
    'src/compute_route_apple/apple_mature_float.cc',
    'src/compute_route_apple/apple_operations.cc',
    'src/compute_route_apple/apple_row_cache_paged.cc',
    'src/graph_route_apple/apple_lowering.cc',
    'src/graph_route_apple/native_region.cc',
    'src/graph_route_apple/native_paged_region.cc',
    'src/graph_route_apple/native_paged_pending.h',
    'src/graph_route_apple/native_paged_pending.cc',
    'tests/graph_route_apple/row_cache_pending_projection_test.cc',
]
patch = []
for logical in logical_paths:
    before = STAGE / 'before' / logical
    old = before.read_text(encoding='utf-8-sig') if before.is_file() else ''
    new = (V / 'final-source' / logical).read_text(encoding='utf-8-sig')
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                    fromfile='before/' + logical, tofile='validated/' + logical))
(STAGE / 'changes.diff').write_text(''.join(patch), encoding='utf-8', newline='\n')

result = dict(summary)
result.update(
    archive='apple-row-pending.zip',
    scope='Apple ordinary Graph ready/pending projected rows and cold Direct/Graph bank descriptor unification',
    changes=[
        'One original CopyOutcomeSource factory/table, Runtime identity and typed submit/take_update shared by native page and row regions.',
        'Original Invocation and native Run own exact ready/ordered page uses through actual retirement; consumed pending episode must reset.',
        'Cold bank role comes from actual MLX math for Direct and Graph. Removed warmup decoder/indexer booleans, Direct single-region shell and fake decoder annotation.',
        'Cold bank descriptors do not imply checked-reader permission; actual access facts, private boundary and final lowering proof remain independent.'
    ],
    test_scope=[
        'FP8 D512 fused/split PaddedMap/Decode/Cast/View/Sink/Neg, original FP64 Sink budget; FP4 D128 exact BF16 rows/mask/Cast.',
        'Short copy coverage rejects without consuming Update; original source and Graph Completion actually Pending behind original CPU FIFO gate.',
        'Old GraphOutput blocks source recovery; original writer/copy invocation recovered after actual retirement; consumed frame cannot replay directly.',
        'Original ready projection 6, Direct codecs 4 (checked/unchecked, errors, scalar/empty/reserved), Direct paged 1, Direct/Graph indexer 3.',
        'Original native paging F16/BF16 each 64 steps, Q2/18, two slots/two nodes per Update and original CPU before/after fragments.'
    ],
    limits=[
        'New pending tests do not inject cancellation or prove consumer math is skipped after accepted source-only failure.',
        'Follow-up code review found a missing Apple worker-time source terminal check. A separate apple-source-preflight slice is investigating and fixing it; this green stage does not prove that failure boundary.',
        'The gate delays original CPU FIFO work, not a claim of physical GPU stalling.',
        'No Apple/Vulkan five-port paged scorer, full-model numerical acceptance, new Linux journey or throughput acceptance.',
        'SDK/native host/metallib reused; original MLX cold trace/JIT and necessary metadata/copy costs remain.'
    ],
    broader_goal='active and incomplete')
save(DEST / 'apple-row-pending-results.json', result)

entries = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink() and name not in entries
    entries[name] = path

for name in ['archive.py', 'summary.json', 'source-identities.json', 'source.diff',
             'changes.diff', 'cleanup-plan.json', 'before.json', 'notes.json', 'before-identities.json']:
    path = STAGE / name
    if path.is_file(): add(path, name)
for path in (STAGE / 'before').rglob('*'):
    if path.is_file() and 'docs' not in path.relative_to(STAGE / 'before').parts:
        add(path, path.relative_to(STAGE).as_posix())
for path in V.iterdir():
    if path.is_file() and path.suffix in {'.json', '.log', '.py'}:
        add(path, path.relative_to(STAGE).as_posix())
for folder in ['results', 'final-source']:
    for path in (V / folder).rglob('*'):
        if path.is_file():
            assert path.suffix in {'.json', '.log', '.cc', '.h', '.d', '.txt'}
            add(path, path.relative_to(STAGE).as_posix())
for logical in ['src/graph_route_apple/CMakeLists.txt', 'tests/graph_route_apple/CMakeLists.txt']:
    path = V / 'final-source' / logical
    if not path.is_file(): path = STAGE / 'candidate' / logical
    if not path.is_file(): path = ROOT / logical
    add(path, 'validated/' + logical)
add(ROOT / 'test.ps1', 'test.ps1')
add(DEST / 'apple-row-pending-results.json', 'results.json')
add(STAGE.parent / 'apple-row-projection/validation/run.py', 'transport/prior-run.py')
add(STAGE.parent / 'apple-page-invocation/air.py', 'transport/air.py')
manifest = [dict(entry=name, bytes=identity(path)['bytes'], sha256=identity(path)['sha256'])
            for name, path in sorted(entries.items())]
archive = DEST / 'apple-row-pending.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as package:
    for name, path in sorted(entries.items()): package.write(path, name)
    package.writestr('archive-content-identities.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for item in manifest:
        data = package.read(item['entry'])
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
receipt = dict(archive=identity(archive), entries=len(manifest) + 1,
               results=identity(DEST / 'apple-row-pending-results.json'),
               remote_cleanup_files=4, remote_cleanup_bytes=37032558,
               no_binaries_objects_or_sdk_in_archive=True)
save(STAGE / 'archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
