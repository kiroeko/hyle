from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
OLD = ROOT / '.scratch/inference-foundation-review-2026-10-18/vulkan-official-bank'
DENSE = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/iree-dense-shared-block'
WORD = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/iree-grouped-word-artifact'
old_records = json.loads((OLD / 'commands.json').read_text())
dense_records = json.loads((DENSE / 'commands.json').read_text())
native_command = next(r['command'] for r in old_records if r['tag'] == 'native-program-compile')
route_command = next(r['command'] for r in old_records if r['tag'] == 'iree-compile')
test_command = next(r['command'] for r in dense_records if r['tag'] == 'tests-compile')
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': native_command[0],
                                    'CMAKE_C_COMPILER': native_command[0]})
env['PATH'] = str(ROOT / '.scratch/build-compute-v2-dev/bin') + os.pathsep + env['PATH']
env.update(VSLANG='1033', DISABLE_VULKAN_OBS_CAPTURE='1', VK_LOADER_LAYERS_DISABLE='~all~')
records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def run(tag, command, timeout=180):
    prior = sum(r['tag'] == tag or r['tag'].startswith(tag + '-attempt') for r in records)
    label = tag + ('-attempt' + str(prior + 1) if prior else '')
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=timeout)
    (OUT / (label + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (label + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=label, command=command, cwd=str(ROOT), exit=result.returncode,
                        seconds=time.monotonic() - start))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    print(label, result.returncode, round(records[-1]['seconds'], 3), flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-5000:])
        print(result.stderr.decode(errors='replace')[-2500:])
        raise SystemExit(result.returncode)
    return result


def compile_source(command, relative, stem):
    target = OUT / (stem + '.obj')
    if target.exists() and target.stat().st_mtime_ns >= (ROOT / relative).stat().st_mtime_ns:
        print(stem + '-compile retained current object', flush=True)
        return
    options = [x for x in command if not x.lower().endswith(('.cc', '.cpp'))
               and not x.startswith(('/Fo', '-Fo'))]
    options += [str(ROOT / relative), '/Fo' + str(OUT / (stem + '.obj'))]
    return run(stem + '-compile', options)


def main(action):
    if action == 'build':
        compile_source(native_command, 'src/compute_provider_iree_vulkan/native_program.cc', 'native-program')
        compile_source(route_command, 'src/compute_route_vulkan/vulkan_official.cc', 'official')
        compile_source(route_command, 'src/compute_route_vulkan/vulkan_program.cc', 'program')
        compile_source(test_command, 'tests/graph_route_vulkan/iree_test.cc', 'tests')
        base = next(r['command'] for r in dense_records if r['tag'] == 'new-link')
        for arm in ['old', 'new']:
            command = []
            for arg in base:
                if arg.startswith('/OUT:') or arg.startswith('/MAP:'):
                    continue
                if arg == str(DENSE / 'tests.obj'):
                    arg = str(OUT / 'tests.obj')
                elif arg == str(DENSE / 'new-programs.obj'):
                    arg = str(DENSE / 'new-programs.obj') if arm == 'old' else str(WORD / 'word-programs.obj')
                elif arg == str(OLD / 'native-program.obj') and arm == 'new':
                    arg = str(OUT / 'native-program.obj')
                elif arg.endswith('vulkan-dense-constant\\program.obj') and arm == 'new':
                    arg = str(OUT / 'program.obj')
                command.append(arg)
            if arm == 'new':
                command.append(str(OUT / 'official.obj'))
            command += ['/OUT:' + str(OUT / (arm + '-tests.exe')),
                        '/MAP:' + str(OUT / (arm + '-tests.map'))]
            missing = [x for x in command if len(x) > 1 and x[1] == ':' and
                       Path(x).suffix.lower() in ('.obj', '.lib') and not Path(x).exists()]
            if missing:
                raise RuntimeError('Missing retained object/library: ' + repr(missing))
            run(arm + '-link', command)
    elif action == 'small':
        names = 'VulkanGraph.OfficialConstantBanksBorrowOwnedStorageAcrossSlots:VulkanGraph.OriginalOfficialGroupedFp4Fp8SharedDistinctAndChecked'
        for arm in ['old', 'new']:
            run(arm + '-small', [str(OUT / (arm + '-tests.exe')),
                '--gtest_filter=' + names, '--gtest_color=no'])
    elif action == 'large':
        run('new-glm-fullbank', [str(OUT / 'new-tests.exe'),
            '--gtest_filter=VulkanGraph.OfficialFullGlmFp8BankKeepsWordAndScaleAddresses',
            '--gtest_color=no'])
    else:
        raise ValueError(action)


if __name__ == '__main__':
    main(*sys.argv[1:])
