from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ART = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/iree-grouped-word-artifact'
OLD = ROOT / '.scratch/inference-foundation-review-2026-10-18/vulkan-official-bank'


def ident(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


files = [
    'src/compute_provider_iree_vulkan/native_program.cc',
    'src/compute_provider_iree_vulkan/native_program.h',
    'src/compute_route_vulkan/vulkan_official.cc',
    'src/compute_route_vulkan/vulkan_program.cc',
    'src/compute_route_vulkan/vulkan_iree.cc',
    'tests/graph_route_vulkan/iree_test.cc',
    'tests/compute_route_vulkan/official_test_support.h',
    'third_party/iree_vulkan_runtime/programs/generate_official.py',
]
for relative in files:
    target = OUT / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / relative).read_bytes())

test = (ROOT / files[5]).read_text(encoding='utf-8')
start = test.index('TEST(VulkanGraph, OfficialFullGlmFp8BankKeepsWordAndScaleAddresses)')
end = test.index('TEST(VulkanGraph, OriginalOfficialQatFiniteBfloatExhaustiveAndFailure)', start)
(OUT / 'before/iree_test.cc').write_text(test[:start] + test[end:], encoding='utf-8', newline='\n')
diff = []
for relative in files:
    old = OUT / 'before' / Path(relative).name
    if old.exists():
        diff.extend(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(True),
            (ROOT / relative).read_text(encoding='utf-8').splitlines(True),
            fromfile='before/' + relative, tofile='applied/' + relative))
(OUT / 'source.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
save('source-identities.json', [ident(ROOT / path) for path in files])
artifact = ART / 'artifact-evidence.zip'
assert ident(artifact)['sha256'] == '628e0cbd0277685964dfe007c206e6c04ad3b50d4a25131d505502e22cf9c385'
shutil.copyfile(artifact, OUT / 'artifact-evidence.zip')
save('artifact-reference.json', dict(artifact=ident(artifact),
    embedding=ident(ART / 'word-programs.obj'),
    module=json.loads((ART / 'summary.json').read_text()),
    note='Artifact generation,25 IEEE math schedules+2finite controls and resource audit owned by configuration_consistency_scan. Runtime evidence below is this task.'))

records = json.loads((OUT / 'commands.json').read_text())
links = [r for r in records if r['tag'] in ['old-link-attempt3', 'new-link-attempt3']]
save('linked-object-identities.json', {r['tag']: [ident(Path(arg)) for arg in r['command']
    if len(arg) > 1 and arg[1] == ':' and Path(arg).suffix.lower() == '.obj'] for r in links})
save('map-identities.json', [ident(OUT / (arm + '-tests.map')) for arm in ['old', 'new']])
with (OUT / 'map-symbol-excerpts.txt').open('w', encoding='utf-8') as stream:
    for arm in ['old', 'new']:
        stream.write(arm + '\n')
        for line in (OUT / (arm + '-tests.map')).read_text(errors='replace').splitlines():
            if ('official_program' in line or '?prepare_plan@' in line or
                '?create@NativeProgram' in line or '?lower_official_float@' in line):
                stream.write(line + '\n')

save('summary.json', {
    'status': 'PASS: official grouped FP8/FP4 word carrier; actual complete GLM FP8 bank public Graph consumer',
    'root_cause': 'Original official grouped i8 bank formed signed32 expert byteoffset before division4; full GLM bank was conservatively unsupported. This task does not claim an executed old out-of-bounds numeric failure; it removes the source-level overflow hazard before widening the narrowly qualified carrier.',
    'abi': 'Public float8/float4_grouped_weight_description remains F32 logical opaque storage, identical payload bytes and trailing F32 scales. Only private HAL/MLIR codes input changes SINT8[E,N,K or K/2] to SINT32[E,N,K/4 or K/8]. No cast, repack or extra bank copy; other byte-code inputs remain I8.',
    'math': 'Logical right shift and255/15 mask recover original code; original FP8 decode/FP4 lookup, activation quantization, group size, accumulation/scale order, BF16 boundaries and IEEE flags are unchanged. Dense three generated functions are exactly the preceding dense-stage IR.',
    'bounds': [
        'Original selected-work/input/workspace limits retained: r*n, r*k, r*n*group. Grouped full bank is separately checked by signed word count<=INT32_MAX.',
        'Both route and NativeProgram enforce checked code/scale byte products and combined packed bank<=actual maxStorageBufferRange; sizeof(int32) private input view preserves byte count.',
        'NativeProgram cold-loads vkGetPhysicalDeviceProperties via its existing owner gIPA; no new runtime/API/shaderInt64 requirement.',
        'Global plan exception matches exact named grouped formats and bounded word count. Each large carrier consumer must be grouped weight port0; ordinary producers/Copy/Cast/arbitrary largeU8 are not widened.',
        'Only ready immutable directly owned same-device captured constants are borrowed. Unknown owners/views/WeightBatch/leases/dynamic inputs retain old copying/retention behavior. Minimum64/actual descriptor alignment and4B origin stay unchanged.',
        'Scale byteoffset above2GiB is represented by runtime checked iree_device_size_t and VkDeviceSize descriptor.offset/range (cached IREE command_buffer.c:1283-1350), not shader signed byte arithmetic. Actual high-offset scale consumption passed.'],
    'small_old_new': {
        'filter': 'VulkanGraph.OfficialConstantBanksBorrowOwnedStorageAcrossSlots:VulkanGraph.OriginalOfficialGroupedFp4Fp8SharedDistinctAndChecked',
        'old': {'passed': 2, 'failed': 0, 'stdout': 'old-small-attempt2.stdout.log',
                'pair': 'Original I8 host/gates + preceding dense artifact new-programs.obj (grouped functions unchangedI8).'},
        'new': {'passed': 2, 'failed': 0, 'stdout': 'new-small-attempt2.stdout.log',
                'pair': 'New SINT32 host/gates + grouped-word word-programs.obj.'},
        'coverage': 'Original independent FP8 F32/BF16 and FP4 BF16 oracle, shared/distinct activations, rebinding/invalidIDs; two-slot captured bank handle/offset aliases, scale alignment copy fallback and owner lifetime.'},
    'glm_complete_bank': {
        'passed': 1, 'failed': 0, 'skipped': 0, 'stdout': 'new-glm-fullbank-attempt3.stdout.log',
        'geometry': 'GLM E256/N2048/K6144; BF16 activation/output, one selected expert per token; two public Graph slots/two input phases.',
        'packed_bank_bytes': 3222011904, 'codes_bytes': 3221225472,
        'code_words': 805306368, 'highest_expert': 255,
        'expert255_byte_offset': 3208642560, 'expert255_word_offset': 802160640,
        'scale_byte_offset': 3221225472, 'scale_bytes': 786432,
        'proof': 'Both slots inputcodes and inputscales alias exact original VkBuffer; codes.offset0 and scale.offset3221225472 asserted. Every2048 output checked against unchanged original independent quantized/reference math; bad256 returns OutOfRange and earlier output remains valid. Dropping Graph/Program/resident before runs retains owner; releasing slots/output expires it.',
        'oracle_storage': 'Only one selected12MiB code expert and its float oracle are decoded on host; no12GiB full float bank. Temporary complete packed CPU upload is real and freed after upload. No large payload file or data archive stored.',
        'cold_controls': 'Public Copy of opaque packed description is already schema-rejected; ordinary large denseU8 Copy is rejected by original global index gate.',
        'memory': 'This is input address/lifetime evidence, not a measured VRAM peak. Caller bank is3.0007GiB; upload staging and private selected-work buffers still cost resources. Borrowing avoids per-slot code/scale input clones only in its existing narrow immutable domain.'},
    'hardware_preflight': {'gpu': 'RTX4070, total12282MiB/free9142MiB, driver617.14',
        'host': 'Win32 OS visible66818848KiB/free38557632KiB before fullbank run',
        'gpu_after': '9142MiB free after process exit',
        'compiler': 'MSVC14.50, /O2 /MD /W4 /WX, current host overlays; exact pinned IREE3.12.0rc20260919 @6ef606b6... for offline artifact'},
    'preserved_failures': [
        'new-glm-fullbank.stdout.log: first actual full bank upload reached publicGraph compile but outer logical-I32 gate rejected before newgrouped qualification; fixed exact named wordbank admission and per-consumer checks.',
        'new-glm-fullbank-attempt2.stdout.log: added negative Copy control called.value on an expected publicschema rejection, threw Bad expected access before large upload. Test now explicitly checks that rejection; input/math/budget unchanged.',
        'Initial source-only generator comparison needed its adjacent generate_mlx import path; fixed Python sys.path, no artifact was generated by that failed comparison.'],
    'build': 'Fresh native_program.cc, vulkan_official.cc, necessary vulkan_program.cc (preserving native-derived-constant changes), shared testTU. Unchanged host objects/native libraries reused; one programs embedding TU supplied by artifact subtask. No configure/fullSDK/native compiler/shader-kernel source build.',
    'source_freeze': 'Applied source snapshots exact; before iree_test.cc reconstructed by removing only the new independent full-bank test, retaining the other agent dense test. NativeProgram prechange SHA matches the reused original host source identity.',
    'limits': 'No full FP4 bank, other experts/model sizes, dynamic fullbank copy performance, peak memory, throughput, shared-install, multi-device, or wholemodel inference claim.',
    'cleanup_executed': False,
})
save('cleanup-candidates.json', {
    'delete': [ident(OUT / (arm + '-tests.exe')) for arm in ['old', 'new']],
    'retain': [ident(OUT / (name + '.obj')) for name in ['native-program', 'official', 'program', 'tests']],
    'shared_retain': [ident(ART / 'word-programs.obj')],
    'note': 'Only candidates; root test.ps1 preflight/execution required. Keep all source/log/raw/map/archives, existingSDK/foundation/native caches, and both frozen dense/word artifact evidence. No deletion performed.'})
with zipfile.ZipFile(OUT / 'source-results.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(OUT.rglob('*'), key=lambda p: p.relative_to(OUT).as_posix()):
        if path.is_file() and (path.name == 'artifact-evidence.zip' or
            path.suffix not in ['.zip', '.exe', '.obj', '.lib', '.exp', '.map', '.pyc']):
            archive.write(path, path.relative_to(OUT).as_posix())
print(json.dumps(ident(OUT / 'source-results.zip')))
