#include "contracts.probe-helper.h"

namespace {
std::atomic<cudaStream_t> watched_copy{nullptr};
std::atomic<cudaEvent_t> last_copy_event{nullptr}, watched_first{nullptr}, watched_second{nullptr};
std::atomic<unsigned> upload_waits{0};
std::atomic<bool> dependencies_issued{false};
}
extern "C" cudaError_t CUDARTAPI hyle_counted_wait(cudaStream_t stream, cudaEvent_t event, unsigned flags) {
  if (event == watched_first.load(std::memory_order_acquire) ||
      event == watched_second.load(std::memory_order_acquire))
    upload_waits.fetch_add(1, std::memory_order_relaxed);
  return cudaStreamWaitEvent(stream, event, flags);
}
extern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t event, cudaStream_t stream) {
  if (stream == watched_copy.load(std::memory_order_acquire))
    last_copy_event.store(event, std::memory_order_release);
  return cudaEventRecord(event, stream);
}
extern "C" void hyle_test_dependencies_issued() noexcept {
  dependencies_issued.store(true, std::memory_order_release);
}
namespace {
Status counted_case(const compute::Context &cpu, const compute::Context &cuda,
                    const compute::cuda::MemoryResource &host,
                    const compute::cuda::MemoryResource &device,
                    hyle::sched::Scheduler &scheduler, bool baseline,
                    bool distinct, bool cancel) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto desc, compute::TensorDesc::dense(
      compute::DataType::kFloat32, std::array<std::int64_t,2>{1,64}));
  HYLE_ASSIGN_OR_RETURN(auto input,tensor(mem::system_resource(),desc));
  HYLE_ASSIGN_OR_RETURN(auto first,tensor(mem::system_resource(),desc));
  HYLE_ASSIGN_OR_RETURN(auto second,tensor(mem::system_resource(),desc));
  HYLE_ASSIGN_OR_RETURN(auto output,tensor(mem::system_resource(),desc));
  std::array<float,64> data;data.fill(-2);
  HYLE_RETURN_IF_ERROR(input.buffer.view().write(std::as_bytes(std::span(data))));
  data.fill(3);HYLE_RETURN_IF_ERROR(first.buffer.view().write(std::as_bytes(std::span(data))));
  data.fill(5);HYLE_RETURN_IF_ERROR(second.buffer.view().write(std::as_bytes(std::span(data))));
  const std::array catalog{compute::cuda::WeightSpec{7,desc},compute::cuda::WeightSpec{8,desc}};
  HYLE_ASSIGN_OR_RETURN(auto pool,compute::cuda::WeightSlots::create(cuda,host,device,catalog,512));
  HYLE_ASSIGN_OR_RETURN(auto copy,cuda.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto gpu,cuda.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto cpu_queue,cpu.create_queue());
  HYLE_RETURN_IF_ERROR(copy.reserve_completions(32));
  const std::array fragments{compute::cuda::WeightFragment{7,first.view.as_const()},
                             compute::cuda::WeightFragment{8,second.view.as_const()}};
  HYLE_ASSIGN_OR_RETURN(auto warm,pool.upload(0,fragments,copy));
  HYLE_RETURN_IF_ERROR(warm.wait());
  HYLE_ASSIGN_OR_RETURN(auto builder,graph::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto x,builder.input(desc));
  HYLE_ASSIGN_OR_RETURN(auto w1,builder.input(desc));
  HYLE_ASSIGN_OR_RETURN(auto w2,builder.input(desc));
  HYLE_ASSIGN_OR_RETURN(auto a,builder.add(compute::Unary{compute::UnaryKind::kAbs},x));
  HYLE_ASSIGN_OR_RETURN(auto m,builder.add(compute::Binary{compute::BinaryKind::kMultiply},a,w1));
  HYLE_ASSIGN_OR_RETURN(auto v,builder.add(compute::Binary{compute::BinaryKind::kAdd},m,w2));
  HYLE_ASSIGN_OR_RETURN(auto y,builder.add(compute::Unary{compute::UnaryKind::kAbs},v));
  HYLE_RETURN_IF_ERROR(builder.publish(y));
  HYLE_ASSIGN_OR_RETURN(auto logical,std::move(builder).finish());
  std::array<graph::NodePlacement,4> placements;
  for(std::size_t i=0;i<placements.size();++i){
    HYLE_ASSIGN_OR_RETURN(auto n,logical.node_id(i));
    placements[i]={n,i==0||i==3?bridge::kCpuTarget:bridge::kCudaTarget,graph::PlacementStrength::kRequired};
  }
  const std::array external{graph::ExternalResourceContract{x,bridge::kHostStorage},
      graph::ExternalResourceContract{w1,bridge::kDeviceStorage},
      graph::ExternalResourceContract{w2,bridge::kDeviceStorage},
      graph::ExternalResourceContract{y,bridge::kHostStorage}};
  HYLE_ASSIGN_OR_RETURN(auto compiled,bridge::compile(logical,
      {&cpu,&cuda,mem::system_resource(),&host,&device},
      {.node_placements=placements,.external_resources=external}));
  HYLE_ASSIGN_OR_RETURN(auto native,compiled.executable.create_invocation());
  const std::array queues{graph::QueueBinding{graph::ExecutionLaneId{0},&gpu},
                          graph::QueueBinding{graph::ExecutionLaneId{1},&cpu_queue}};
  HYLE_ASSIGN_OR_RETURN(auto invocation,bridge::Invocation::create(std::move(native),scheduler,queues));
  Drain drain{scheduler};
  const auto bind=[&](const compute::cuda::WeightBatch &left,
                     const compute::cuda::WeightBatch &right) noexcept -> Status {
    HYLE_RETURN_IF_ERROR(invocation.bind(x,input.view.as_const()));
    HYLE_RETURN_IF_ERROR(invocation.bind(w1,left,7));
    HYLE_RETURN_IF_ERROR(invocation.bind(w2,right,8));
    HYLE_RETURN_IF_ERROR(invocation.bind(y,output.view));
    return invocation.prepare_replay();
  };
  HYLE_RETURN_IF_ERROR(bind(warm,warm));
  {HYLE_ASSIGN_OR_RETURN(auto result,invocation.run());}
  HYLE_RETURN_IF_ERROR(invocation.reset());warm={};
  watched_copy.store(compute::cuda::stream(copy).value(),std::memory_order_release);
  watched_first.store(nullptr);watched_second.store(nullptr);
  NativeGate gate;
  HYLE_ASSIGN_OR_RETURN(gate.prefix,compute::cuda::submit(copy,[&](cudaStream_t stream) noexcept {
    return cudaLaunchHostFunc(stream,&NativeGate::block,&gate);
  }));
  const auto gate_deadline=std::chrono::steady_clock::now()+std::chrono::seconds(5);
  while(!gate.entered.load(std::memory_order_acquire)&&std::chrono::steady_clock::now()<gate_deadline)
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  HYLE_RETURN_IF_ERROR(require(gate.entered.load(),"upload gate did not enter"));
  last_copy_event.store(nullptr);
  HYLE_ASSIGN_OR_RETURN(auto left,pool.upload(0,fragments,copy));
  watched_first.store(last_copy_event.load(std::memory_order_acquire),std::memory_order_release);
  compute::cuda::WeightBatch right;
  if(distinct){
    last_copy_event.store(nullptr);
    const std::array fragment{fragments[1]};
    HYLE_ASSIGN_OR_RETURN(right,pool.upload(1,fragment,copy));
    watched_second.store(last_copy_event.load(std::memory_order_acquire),std::memory_order_release);
  }
  HYLE_RETURN_IF_ERROR(require(watched_first.load()!=nullptr&&(!distinct||watched_second.load()!=nullptr),
                               "upload native event was not captured"));
  HYLE_RETURN_IF_ERROR(bind(left,distinct?right:left));
  HYLE_ASSIGN_OR_RETURN(auto report,invocation.replay_report());
  const unsigned expected=baseline||distinct?2:1;
  HYLE_RETURN_IF_ERROR(require(report.weight_device_wait_count==expected,"potential dependency count differs"));
  dependencies_issued.store(false,std::memory_order_release);upload_waits.store(0);
  HYLE_ASSIGN_OR_RETURN(auto pending,invocation.submit());
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(5);
  while(!dependencies_issued.load(std::memory_order_acquire)&&std::chrono::steady_clock::now()<deadline)
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  const bool issued=dependencies_issued.load(std::memory_order_acquire);
  const auto count=upload_waits.load(std::memory_order_relaxed);
  const bool source_pending=left.poll().value()==compute::CompletionPoll::kPending;
  const bool unpublished=!pending.result();
  Status cancelled;
  if(cancel)cancelled=pending.request_cancel();
  // Release before any assertion or error cleanup can retire CUDA backing.
  gate.release();
  auto result=pending.wait();
  HYLE_RETURN_IF_ERROR(require(issued&&source_pending&&unpublished,"gated ordering/visibility differs"));
  HYLE_RETURN_IF_ERROR(require(count==expected,"actual upload cudaStreamWaitEvent count differs"));
  if(cancel){
    HYLE_RETURN_IF_ERROR(cancelled);
    HYLE_RETURN_IF_ERROR(require(!result&&result.error().IsCancelled(),"cancelled prefix did not retire"));
  }else{
    if(!result)return result.error();
    HYLE_ASSIGN_OR_RETURN(auto view,(*result)->output(y));
    std::array<float,64> actual;
    HYLE_RETURN_IF_ERROR(view.storage().read(std::as_writable_bytes(std::span(actual))));
    for(auto value:actual)HYLE_RETURN_IF_ERROR(require(value==11,"gated output differs"));
  }
  HYLE_RETURN_IF_ERROR(gate.prefix.wait());
  watched_first.store(nullptr);watched_second.store(nullptr);watched_copy.store(nullptr);
  std::printf("%s %s%s: upload-pending=true potential=%zu actual-upload-WaitEvent=%u oracle=PASS\n",
      baseline?"before":"after",distinct?"distinct-batches":"same-batch/two-IDs",cancel?"/cancel":"",
      report.weight_device_wait_count,count);
  return Status::Ok();
}
Status probe(bool baseline) noexcept {
 HYLE_ASSIGN_OR_RETURN(auto cpu,graph::cpu::create_context());
 HYLE_ASSIGN_OR_RETURN(auto cuda,graph::cuda::create_context());
 HYLE_ASSIGN_OR_RETURN(auto host,compute::cuda::MemoryResource::create(cuda,compute::cuda::MemoryKind::kPinnedHost));
 HYLE_ASSIGN_OR_RETURN(auto device,compute::cuda::MemoryResource::create(cuda,compute::cuda::MemoryKind::kDevice));
 hyle::sched::Scheduler scheduler(1,mem::system_allocator(),32);
 HYLE_RETURN_IF_ERROR(counted_case(cpu,cuda,host,device,scheduler,baseline,false,false));
 HYLE_RETURN_IF_ERROR(counted_case(cpu,cuda,host,device,scheduler,baseline,true,false));
 HYLE_RETURN_IF_ERROR(counted_case(cpu,cuda,host,device,scheduler,baseline,false,true));
 return Status::Ok();
}
}
int main(int argc,char **argv){
 const auto status=probe(argc>1&&std::string_view(argv[1])=="before");
 if(!status.ok()){std::fprintf(stderr,"FAIL: %.*s\n",int(status.message().size()),status.message().data());return 1;}
 return 0;
}
