from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]; OUT=Path(__file__).resolve().parent
BASE=ROOT/'.scratch/build-compute-v2-dev'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache=read_cache(BASE); env=windows_compiler_environment(cache);env['VSLANG']='1033'
old=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/weight-order/commands.json').read_text())
original=next(x['command'] for x in old if x['tag']=='weights-after-compile')
flags=[x for x in original[1:] if not x.startswith(('/Tp','/Fo'))]
flags+=['/W4','/WX','/wd4324','/wd4702','/I'+str(ROOT),'/I'+str(ROOT/'src/graph_route_cpu_cuda'),'/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_GGML_CPU=1','/DHYLE_COMPUTE_ONEDNN=1','/DHYLE_GRAPH_ONEDNN=1']
CL=original[0]; LINK=Path(CL).with_name('link.exe')
link_old=next(x['command'] for x in reversed(old) if x['tag']=='after-link')
exclude={str(ROOT/'.scratch/inference-foundation-review-2026-10-18/weight-order'/n) for n in ['probe.obj','weights-after.obj','backend-counted.obj']}
closure=[x for x in link_old[1:] if x not in exclude and not x.startswith(('/OUT:','/MAP:'))]
# One ggml pin in this process: the mixed456 CPU carrier shares CUDA's ggml/base.
closure += [str(ROOT/p) for p in [
 '.scratch/inference-foundation-review-2026-10-18/weight-order/weights-after.obj',
 '.scratch/inference-foundation-review-2026-10-18/cpu-mla/native-batch.obj',
 '.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj',
 '.scratch/mtp-gdn-2026-10-18/mixed/selector-baseline.obj',
 '.scratch/mtp-gdn-2026-10-18/mixed/allocator.obj',
 '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj',
 '.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-cpu.lib']]
closure += [str(BASE/'bin'/(n+'.lib')) for n in ['hyle_sched','hyle_compute_backend_cpu','hyle_compute_provider_ggml','hyle_compute_provider_native','hyle_compute_provider_onednn','hyle_graph_provider_onednn','hyle_graph_route_cpu','dnnl']]
for x in closure:
 if x.endswith(('.lib','.obj')) and Path(x).is_absolute():
  assert Path(x).is_file(),x
  env['PATH']=str(Path(x).parent)+os.pathsep+env['PATH']
env['PATH']='C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64'+os.pathsep+str(BASE/'bin')+os.pathsep+env['PATH']
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command,timeout=180):
 cmd=list(map(str,command)); i=len(records);stem=f'{i+1:02d}-{tag}';start=time.monotonic()
 try:
  p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=timeout)
  out,err,code=p.stdout,p.stderr,p.returncode
 except subprocess.TimeoutExpired as e:
  out,err,code=e.stdout or b'',e.stderr or b'',124
 (OUT/(stem+'.stdout.log')).write_bytes(out);(OUT/(stem+'.stderr.log')).write_bytes(err)
 records.append(dict(tag=tag,command=cmd,exit=code,seconds=time.monotonic()-start,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
 (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(stem,code,round(time.monotonic()-start,2),flush=True)
 if code:
  print(out.decode(errors='replace')[-6500:]);print(err.decode(errors='replace')[-1500:]);raise SystemExit(code)
 return out.decode(errors='replace')
def comp(file,name,extra=()):
 run(name+'-compile',[CL,*flags,*extra,'/Tp'+str(file),'/Fo'+str(OUT/(name+'.obj'))]);return OUT/(name+'.obj')
def link(name,consumer,revision):
 objs=[OUT/(n+'.obj') for n in [('joint-'+revision+('-counted' if consumer=='probe' else '')),'joint-compile','joint-progress','graph-cuda-context','graph-cpu-context','cpu-policy','backend-counted',consumer]]
 if consumer=='contracts':objs+=[OUT/'counter-forward.obj']
 run(name+'-link',[LINK,*objs,*closure,'/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map'))])
if __name__=='__main__':
 action=sys.argv[1]
 if action=='build':
  for source,name in [(OUT/'invocation.before.cc','joint-before'),(ROOT/'src/graph_route_cpu_cuda/invocation.cc','joint-after'),(ROOT/'src/graph_route_cpu_cuda/compile.cc','joint-compile'),(ROOT/'src/graph_route_cpu_cuda/progress.cc','joint-progress'),(ROOT/'src/graph_route_cuda/cuda_context.cc','graph-cuda-context'),(ROOT/'src/graph_route_cpu/cpu_context.cc','graph-cpu-context'),(ROOT/'src/compute_route_cpu/default_policy.cc','cpu-policy'),(ROOT/'tests/graph/cpu_cuda_contracts.cc','contracts'),(ROOT/'.scratch/inference-foundation-review-2026-10-18/weight-order/counter_forward.cc','counter-forward')]:comp(source,name)
  comp(ROOT/'src/compute_backend_cuda/cuda_backend.cc','backend-counted',['/FI'+str(ROOT/'.scratch/inference-foundation-review-2026-10-18/weight-order/count_native.h')])
  link('contracts','contracts','after')
 elif action=='refresh':
  comp(ROOT/'src/graph_route_cpu_cuda/invocation.cc','joint-after')
  link('contracts','contracts','after')
 elif action=='link':
  link('contracts','contracts','after')
 elif action=='contracts':
  print(run('canonical-contracts',[OUT/'contracts.exe'],180))
 elif action=='counter-build':
  comp(OUT/'probe.cc','probe',['/I'+str(ROOT/'tests/graph')])
  for revision in ['before','after']:comp(OUT/('invocation.'+revision+'.counted.cc'),'joint-'+revision+'-counted')
  link('before','probe','before');link('after','probe','after')
 elif action=='counter':
  print(run('before-counter',[OUT/'before.exe','before'],90))
  print(run('after-counter',[OUT/'after.exe','after'],90))
