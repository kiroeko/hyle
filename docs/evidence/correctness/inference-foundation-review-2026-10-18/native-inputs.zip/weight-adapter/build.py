from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
spec = importlib.util.spec_from_file_location('runner', ARCH / 'region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def compile_one(name):
    templates = json.loads((ARCH/'vulkan-constant-readback/commands.json').read_text())
    source, tag = {
        'weights': ('src/compute_route_vulkan/vulkan_weights.cc', 'memory-staging-compile'),
        'weight-binding': ('src/graph_route_vulkan/weight_binding.cc', 'source-staging-compile'),
        'weight-test': ('tests/graph_route_vulkan/weight_binding_test.cc', 'native-tests-staging-compile'),
    }[name]
    template = next(row['command'] for row in reversed(templates) if row['tag']==tag and row['exit']==0)
    output = OUT/(name+'.obj')
    command = [str(ROOT/source) if str(arg).endswith('.cc') else
               '/Fo'+str(output) if str(arg).lower().startswith('/fo') else str(arg)
               for arg in template]
    original = sha(ROOT/source)
    b.run(name+'-compile', command, timeout=60)
    assert original == sha(ROOT/source)
    receipt = OUT/(name+'-identity.json')
    receipt.write_text(json.dumps(dict(source=source, source_sha256=original,
        object=str(output), object_sha256=sha(output), bytes=output.stat().st_size,
        flags_from=str(ARCH/'vulkan-constant-readback/commands.json')+':'+tag),indent=2)+'\n')

def link_and_run():
    run_out = ARCH/'native-inputs/vulkan-weights'
    run_out.mkdir(parents=True, exist_ok=True)
    b.OUT = run_out
    base = ARCH/'native-inputs/vulkan-consumers/matched-link-base.json'
    command = json.loads(base.read_text())['command']
    command = [arg for arg in command if not str(arg).upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:'))]
    assert not any('test.obj' in str(arg) for arg in command)
    blocking = ROOT/'.scratch/perf-review-2026-10-18/blocking-pool/candidate.obj'
    if str(blocking) not in command:
        command.insert(1, str(blocking))
    command += ['/OUT:'+str(run_out/'weight-tests.exe'), '/MAP:'+str(run_out/'weight-tests.map'),
        str(OUT/'weight-test.obj'),
        str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),
        str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
    inputs = [Path(arg) for arg in command if str(arg).lower().endswith(('.obj','.lib'))
              and Path(arg).is_file()]
    (run_out/'link-input-identities.json').write_text(json.dumps([
        dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in inputs],indent=2)+'\n')
    (run_out/'link-base-receipt.json').write_text(json.dumps(dict(path=str(base),sha256=sha(base)),indent=2)+'\n')
    torch = next(p.parent for p in inputs if p.name.lower()=='torch_cpu.lib')
    environment = b.windows_compiler_environment
    def with_torch(options):
        env = environment(options)
        env['PATH'] = str(torch)+os.pathsep+env.get('PATH','')
        return env
    b.windows_compiler_environment = with_torch
    b.run('weight-tests-link',command,timeout=60)
    b.run('weight-tests-run',[run_out/'weight-tests.exe','--gtest_color=no',
        '--gtest_filter=VulkanWeightBinding.*',
        '--gtest_output=json:'+str(run_out/'results.json')],timeout=45)

if __name__=='__main__':
    if sys.argv[1:] == ['link-run']: link_and_run()
    else:
        for name in sys.argv[1:]: compile_one(name)
