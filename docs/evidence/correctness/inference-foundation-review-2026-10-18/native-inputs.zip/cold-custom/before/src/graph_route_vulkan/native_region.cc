#include "native_region.h"

#include <algorithm>
#include <mutex>
#include <new>
#include <unordered_set>
#include <utility>
#include <vector>

#include "../graph/native_analysis.h"
#include "../graph/region_discovery.h"
#include "../compute_route_vulkan/vulkan_carrier.h"
#include "../compute_route_vulkan/vulkan_composition_access.h"
#include "../compute_route_vulkan/vulkan_memory_internal.h"
#include "../compute_route_vulkan/vulkan_program_internal.h"
#include "hyle/compute/detail/vulkan_batch_access.h"

namespace hyle::graph::vulkan::detail {
namespace cv = compute::vulkan;
namespace cd = compute::detail;
namespace vn = cv::detail;
namespace {
template<class T> using Vector = std::vector<T, mem::StdAllocator<T>>;
const unsigned tensor_type = 0;
const unsigned ordered_endpoint = 0;
const unsigned observed_endpoint = 0;
constexpr compute::ProviderRuntimeProperties runtime_properties{
    .mode = compute::ProviderRuntimeMode::kDelegated,
    .workspace_owner = compute::ProviderWorkspaceOwner::kProvider,
    .replay_class = compute::ProviderReplayClass::kManaged};

const std::shared_ptr<vn::Runtime> &runtime(void *context) noexcept {
  // Source retains this real owning handle throughout the cold callback.
  return *static_cast<const std::shared_ptr<vn::Runtime> *>(context);
}

struct Artifact final {
  explicit Artifact(mem::AllocatorRef allocator)
      : input_ports(mem::StdAllocator<std::size_t>(allocator)),
        output_resources(mem::StdAllocator<mem::MemoryResourceRef>(allocator)),
        output_contracts(mem::StdAllocator<RegionOutputContract>(allocator)) {}
  cv::Program program;
  Vector<std::size_t> input_ports;
  Vector<mem::MemoryResourceRef> output_resources;
  Vector<RegionOutputContract> output_contracts;
};
struct Slot final {
  explicit Slot(mem::AllocatorRef owner)
      : allocator(owner), inputs(mem::StdAllocator<cv::Tensor>(owner)),
        outputs(mem::StdAllocator<cv::Tensor>(owner)),
        backing(mem::StdAllocator<mem::Buffer>(owner)) {}
  mem::AllocatorRef allocator;
  cv::Invocation invocation;
  Vector<cv::Tensor> inputs, outputs;
  Vector<mem::Buffer> backing;
  cd::ResultStorageOwner result;
  bool sealed = false;
  bool needs_seal = false;
};
const std::shared_ptr<vn::Runtime> &runtime(const Artifact &artifact) noexcept {
  return vn::Access::program(artifact.program)->runtime;
}

Status qualify(const RegionCompileRequest &request) noexcept {
  if (!request.graph || request.graph->dimension_count() != 0 ||
      request.route != 1 || request.nodes.empty() ||
      request.has_unknown_effects || !request.effect_accesses.empty())
    return Status::Unimplemented("Vulkan native region requires a fixed pure boundary");
  for (const auto node : request.nodes) {
    HYLE_ASSIGN_OR_RETURN(auto operation, request.graph->operation(node));
    const auto traits = compute::operation_traits(operation);
    if (traits.effect != compute::EffectKind::kPure || traits.resource_count != 0 ||
        (traits.alias == compute::AliasPolicy::kMustAliasInput0 &&
         !operation.get_if<compute::View>()))
      return Status::Unimplemented("Vulkan native region has unsupported effects/aliasing");
  }
  return Status::Ok();
}

Status propose(void *, const RegionDiscoveryRequest &request,
               mem::AllocatorRef allocator, RegionProposalWriter &writer) noexcept {
  const auto &graph = request.graph;
  if (!request.allowed_nodes.empty() && request.allowed_nodes.size() != graph.node_count())
    return Status::InvalidArgument("Vulkan discovery mask size differs");
  if (graph.dimension_count() || !graph.node_count()) return Status::Ok();
  HYLE_ASSIGN_OR_RETURN(auto analysis,
      graph::detail::analyze_native_reachability(graph, allocator));
  return graph::detail::discover_regions(graph, allocator,
      [&](NodeId node) -> Result<bool> {
        if (!analysis.needed[node.ordinal()] ||
            (!request.allowed_nodes.empty() && !request.allowed_nodes[node.ordinal()]))
          return false;
        HYLE_ASSIGN_OR_RETURN(const auto &operation, graph.operation(node));
        // Discovery is structural, without per-node prepare/JIT. Actual typed
        // mathematics and device limits remain the final lowerer's admission.
        return graph::detail::validate_native_node(operation).ok();
      },
      [&](std::span<const NodeId> nodes) -> Result<bool> {
        if (nodes.empty()) return true;
        return writer.try_add({.nodes = nodes,
            .cost = {.persistent_bytes = std::nullopt, .copy_bytes = std::nullopt,
                     .repack_bytes = std::nullopt, .synchronization_count = 0, .dispatch_count = 1},
            .route = 1, .replay_class = compute::ProviderReplayClass::kManaged,
            .implementation = compute::ProviderImplementationId{1}, .preference = 200});
      });
}

Status resources(void *context, const RegionCompileRequest &request,
    mem::AllocatorRef allocator, std::span<RegionInputRequirement> inputs,
    std::span<RegionOutputRequirement> outputs,
    RegionResourceProposal *proposal) noexcept {
  HYLE_RETURN_IF_ERROR(qualify(request));
  if (inputs.size() != request.inputs.size() || outputs.size() != request.outputs.size())
    return Status::InvalidArgument("Vulkan resource boundary arity differs");
  const cd::ResourceBindingRequirement binding{
      .required_properties = mem::MemoryProperty::kDeviceAccessible,
      .forbidden_properties = mem::MemoryProperty::kHostAccessible,
      .minimum_alignment = 1,
      .exact_domain = {runtime(context)->device.get(),
                      static_cast<std::uintptr_t>(cv::MemoryKind::kDevice)},
      .requires_exact_domain = true};
  std::ranges::fill(inputs, RegionInputRequirement{.resource = binding});
  try {
    // The original native plan only aliases logical outputs through View.
    // Captured constants have stable storage; a View rooted in a true boundary
    // input gets its backing when that input is cold-bound.
    std::unordered_set<std::uint32_t, std::hash<std::uint32_t>,
        std::equal_to<std::uint32_t>, mem::StdAllocator<std::uint32_t>> external{
            mem::StdAllocator<std::uint32_t>(allocator)};
    external.reserve(request.inputs.size());
    for (const auto input : request.inputs)
      if (input.kind() != ValueKind::kConstant)
        external.insert(input.ordinal());
    for (const auto node : request.nodes) {
      HYLE_ASSIGN_OR_RETURN(auto operation, request.graph->operation(node));
      if (!operation.get_if<compute::View>()) continue;
      HYLE_ASSIGN_OR_RETURN(auto input, request.graph->node_input(node, 0));
      HYLE_ASSIGN_OR_RETURN(auto output, request.graph->result(node, 0));
      if (external.contains(input.ordinal()))
        external.insert(output.ordinal());
    }
    for (std::size_t port = 0; port < outputs.size(); ++port)
      outputs[port] = {.resource = binding,
          .value = {.kind = external.contains(request.outputs[port].ordinal())
                       ? RegionOutputKind::kBoundGenerated
                       : RegionOutputKind::kStableGenerated,
                    .projection = RegionOutputProjection::kTensorView}};
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan output contract metadata");
  }
  *proposal = {.runtime = runtime_properties, .workspace_resource = binding};
  return Status::Ok();
}

Status create_slot(void *prepared, mem::AllocatorRef allocator,
                   mem::BufferView, void **output) noexcept {
  *output = nullptr;
  auto &artifact = *static_cast<Artifact *>(prepared);
  auto *slot = allocator.construct<Slot>(allocator);
  if (!slot) return Status::ResourceExhausted("Vulkan region slot metadata");
  *output = slot; // Destruction is valid on every partially prepared suffix.
  try {
    HYLE_ASSIGN_OR_RETURN(slot->invocation, artifact.program.create_invocation(allocator));
    slot->inputs.resize(artifact.input_ports.size());
    slot->outputs.reserve(artifact.output_resources.size());
    slot->backing.reserve(artifact.output_resources.size());
    for (std::size_t port = 0; port < artifact.output_resources.size(); ++port) {
      HYLE_ASSIGN_OR_RETURN(auto tensor, vn::CompositionAccess::output(slot->invocation, port));
      HYLE_ASSIGN_OR_RETURN(auto backing, vn::MemoryAccess::export_storage(
          runtime(artifact), artifact.output_resources[port], tensor, allocator));
      slot->outputs.push_back(std::move(tensor));
      slot->backing.push_back(std::move(backing));
    }
    return Status::Ok();
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan generated port metadata");
  }
}

Status bind(void *prepared, void *invocation, std::span<const RegionValue> inputs,
            std::span<const compute::TensorView> outputs) noexcept {
  auto &artifact = *static_cast<Artifact *>(prepared);
  auto &slot = *static_cast<Slot *>(invocation);
  if (outputs.size() != artifact.output_resources.size())
    return Status::InvalidArgument("Vulkan generated output arity differs");
  // Graph's idle/no-old-output gate precedes this callback. Release only our
  // previous storage ref; escaped native owners still fail the original gate.
  slot.result.reset();
  if (slot.sealed)
    HYLE_RETURN_IF_ERROR(vn::PagedBatchAccess::reuse_gate(slot.invocation));
  for (std::size_t port = 0; port < artifact.input_ports.size(); ++port) {
    const auto index = artifact.input_ports[port];
    if (index >= inputs.size())
      return Status::InvalidArgument("Vulkan region input arity differs");
    const auto &input = inputs[index];
    if (input.native_type == &tensor_type && input.native_handle != nullptr) {
      slot.inputs[port] = *static_cast<const cv::Tensor *>(input.native_handle);
    } else {
      HYLE_ASSIGN_OR_RETURN(slot.inputs[port], vn::MemoryAccess::tensor_view(
          runtime(artifact), input.tensor, slot.allocator));
    }
    if (slot.inputs[port].description() != input.description)
      return Status::InvalidArgument("Vulkan input physical descriptor differs");
  }
  const auto status = slot.invocation.bind(std::span<const cv::Tensor>(slot.inputs));
  if (status.ok()) slot.needs_seal = true;
  return status;
}

Status seal(void *, void *invocation) noexcept {
  auto &slot = *static_cast<Slot *>(invocation);
  if (slot.sealed && !slot.needs_seal) {
    slot.result.reset();
    return vn::PagedBatchAccess::reuse_gate(slot.invocation);
  }
  const auto status = slot.sealed
      ? vn::PagedBatchAccess::reseal_composition(slot.invocation)
      : vn::CompositionAccess::seal(slot.invocation);
  if (status.ok()) {
    slot.sealed = true;
    slot.needs_seal = false;
  }
  return status;
}

Result<RegionValue> value(void *prepared, void *invocation, std::size_t port) noexcept {
  const auto &artifact = *static_cast<Artifact *>(prepared);
  auto &slot = *static_cast<Slot *>(invocation);
  if (port >= slot.outputs.size())
    return std::unexpected(Status::OutOfRange("Vulkan generated output port"));
  const auto &tensor = slot.outputs[port];
  if (tensor.native_buffer() == VK_NULL_HANDLE)
    return std::unexpected(Status::FailedPrecondition("Vulkan alias output is not cold-bound"));
  HYLE_ASSIGN_OR_RETURN(auto binding, compute::ConstTensorView::create(
      tensor.description(), slot.backing[port].view()));
  if (binding.storage().resource() != artifact.output_resources[port])
    return std::unexpected(Status::Internal("Vulkan generated output resource changed"));
  return RegionValue{tensor.description(), binding, &tensor_type, &tensor};
}

Result<compute::ReadLease> lease(void *prepared, void *invocation, std::size_t port) noexcept {
  const auto &artifact = *static_cast<Artifact *>(prepared);
  auto &slot = *static_cast<Slot *>(invocation);
  if (!slot.result || port >= slot.outputs.size())
    return std::unexpected(Status::FailedPrecondition("Vulkan output has no successful result owner"));
  const auto &run = vn::Access::invocation_state(slot.invocation)->run;
  {
    std::lock_guard lock(runtime(artifact)->mutex);
    if (run->pending || run->retiring || !run->terminal.ok() ||
        !run->observation_error.ok() || !run->submission_failure.ok())
      return std::unexpected(Status::FailedPrecondition("Vulkan output has not retired successfully"));
  }
  HYLE_ASSIGN_OR_RETURN(auto backing, vn::MemoryAccess::export_storage(
      runtime(artifact), artifact.output_resources[port], slot.outputs[port], slot.allocator));
  return compute::ReadLease::adopt(std::move(backing), {.allocator = slot.allocator});
}

cd::CompletionEndpoint endpoint(void *, void *invocation) noexcept {
  const auto &slot = *static_cast<const Slot *>(invocation);
  const auto &state = *vn::Access::invocation_state(slot.invocation);
  if (state.run->async || state.run->needs_drain ||
      std::ranges::any_of(state.run->stages, [](const auto &stage) { return bool(stage.iree); }))
    return {&observed_endpoint, state.run.get()};
  return region_ordered_endpoint(state.program->runtime);
}
bool imports(void *prepared, void *invocation, cd::CompletionEndpoint source) noexcept {
  const auto &slot = *static_cast<const Slot *>(invocation);
  const auto &run = *vn::Access::invocation_state(slot.invocation)->run;
  if (run.async || run.needs_drain ||
      std::ranges::any_of(run.stages, [](const auto &stage) { return bool(stage.iree); }))
    return false;
  return imports_region_ordered_endpoint(
      runtime(*static_cast<Artifact *>(prepared)), source);
}
Result<compute::Completion> submit(void *prepared, void *invocation,
    std::span<const cd::CompletionDependency> dependencies,
    std::span<const compute::ConstTensorView>,
    std::span<const compute::TensorView>) noexcept {
  const auto &artifact = *static_cast<Artifact *>(prepared);
  auto &slot = *static_cast<Slot *>(invocation);
  for (const auto dependency : dependencies)
    HYLE_RETURN_IF_ERROR(vn::qualify_copy_dependency(runtime(artifact), dependency));
  slot.result.reset(); // Never pre-retain the original storage before begin().
  HYLE_ASSIGN_OR_RETURN(auto accepted, slot.invocation.submit());
  auto transfer = cd::ResultAccess::take_storage(std::move(accepted));
  slot.result = std::move(transfer.owner);
  return std::move(transfer.completion);
}

const ProviderRegionPreparedVTable prepared_table{
    .destroy_prepared = [](void *state, mem::AllocatorRef allocator) noexcept {
      allocator.destroy(static_cast<Artifact *>(state));
    },
    .alias_support = [](void *, std::size_t, std::size_t) noexcept {
      return compute::AliasSupport{};
    },
    .create_invocation = &create_slot,
    .destroy_invocation = [](void *state, mem::AllocatorRef allocator) noexcept {
      allocator.destroy(static_cast<Slot *>(state));
    },
    .delegated_submit = &submit, .endpoint = &endpoint,
    .can_import_endpoint = &imports,
    .output_contract = [](void *prepared, std::size_t port) noexcept {
      return static_cast<Artifact *>(prepared)->output_contracts[port];
    },
    .output_value = &value, .prepare_bindings = &bind,
    .seal_bindings = &seal, .output_lease = &lease};

compute::ProviderPrepareOutcome compile(void *context,
    const RegionCompileRequest &request, mem::AllocatorRef allocator,
    ProviderRegionPrepared *result) noexcept {
  using Outcome = compute::ProviderPrepareOutcome;
  *result = {};
  auto status = qualify(request);
  if (!status.ok()) return Outcome::unsupported(std::move(status));
  auto *artifact = allocator.construct<Artifact>(allocator);
  if (!artifact) return Outcome::error(Status::ResourceExhausted("Vulkan region artifact metadata"));
  result->vtable = &prepared_table;
  result->state = artifact;
  try {
    const auto build = [&]() -> Status {
      const auto &graph = *request.graph;
      HYLE_ASSIGN_OR_RETURN(auto analysis, graph::detail::analyze_native_fragment(graph, request.nodes, allocator));
      vn::Plan plan;
      plan.workload = request.workload;
      Vector<std::uint32_t> ids(graph.value_count(), UINT32_MAX,
                                mem::StdAllocator<std::uint32_t>(allocator));
      const auto add = [&](ValueId value) -> Result<std::uint32_t> {
        auto &index = ids[value.ordinal()];
        if (index == UINT32_MAX) {
          HYLE_ASSIGN_OR_RETURN(auto description, graph.value_description(value));
          index = static_cast<std::uint32_t>(plan.values.size());
          plan.values.push_back({description, {}});
        }
        return index;
      };
      for (std::size_t port = 0; port < request.inputs.size(); ++port) {
        const auto input = request.inputs[port];
        HYLE_ASSIGN_OR_RETURN(auto index, add(input));
        const auto constant = std::ranges::find_if(request.constants,
            [&](const ConstantBinding &entry) { return entry.value == input; });
        if (constant != request.constants.end()) {
          HYLE_ASSIGN_OR_RETURN(plan.values[index].constant,
              vn::MemoryAccess::tensor_view(runtime(context), constant->tensor, allocator));
        } else {
          plan.inputs.push_back(index);
          artifact->input_ports.push_back(port);
        }
      }
      for (const auto node : request.nodes) {
        vn::PlanStep step;
        HYLE_ASSIGN_OR_RETURN(step.operation, graph.operation(node));
        step.control_boundary = analysis.boundary[node.ordinal()] != 0;
        step.preserve_outputs = analysis.control_predecessor[node.ordinal()] != 0;
        HYLE_ASSIGN_OR_RETURN(auto count, graph.node_input_count(node));
        for (std::size_t port = 0; port < count; ++port) {
          HYLE_ASSIGN_OR_RETURN(auto input, graph.node_input(node, port));
          HYLE_ASSIGN_OR_RETURN(auto index, add(input));
          step.inputs.push_back(index);
        }
        HYLE_ASSIGN_OR_RETURN(count, graph.node_output_count(node));
        for (std::size_t port = 0; port < count; ++port) {
          HYLE_ASSIGN_OR_RETURN(auto output, graph.result(node, port));
          HYLE_ASSIGN_OR_RETURN(auto index, add(output));
          step.outputs.push_back(index);
        }
        plan.steps.push_back(std::move(step));
      }
      for (const auto output : request.outputs) plan.outputs.push_back(ids[output.ordinal()]);
      // A control-only fragment still evaluates real terminal arrays and its
      // checked algorithm status. These outputs never become Graph ports.
      if (plan.outputs.empty()) {
        const auto &terminal = plan.steps.back().outputs;
        if (terminal.empty())
          return Status::Unimplemented("Vulkan control fragment has no native terminal result");
        plan.outputs.assign(terminal.begin(), terminal.end());
      }
      HYLE_ASSIGN_OR_RETURN(artifact->program, vn::prepare_plan(runtime(context), plan));
      artifact->output_resources.assign(request.output_resources.begin(), request.output_resources.end());
      const auto &native = *vn::Access::program(artifact->program);
      for (std::size_t port = 0; port < request.outputs.size(); ++port) {
        const auto output = native.outputs[port];
        const auto root = native.aliases[output].root;
        const bool external = std::ranges::find(native.inputs, root) != native.inputs.end();
        artifact->output_contracts.push_back({.kind = external
            ? RegionOutputKind::kBoundGenerated : RegionOutputKind::kStableGenerated,
            .projection = RegionOutputProjection::kTensorView});
      }
      result->properties = {.persistent_bytes = std::nullopt,
          .runtime = runtime_properties, .invocation_private_bytes = std::nullopt};
      return Status::Ok();
    };
    status = build();
    if (!status.ok()) {
      if (status.IsUnimplemented()) return Outcome::unsupported(std::move(status));
      return Outcome::error(std::move(status));
    }
    return Outcome::prepared();
  } catch (const std::bad_alloc &) {
    return Outcome::error(Status::ResourceExhausted("Vulkan region preparation metadata"));
  }
}
const RegionProviderVTable region_table{&propose, &resources, &compile};
} // namespace

cd::CompletionEndpoint region_ordered_endpoint(
    const std::shared_ptr<vn::Runtime> &owner) noexcept {
  return {&ordered_endpoint, owner.get()};
}
bool imports_region_ordered_endpoint(const std::shared_ptr<vn::Runtime> &owner,
                                     cd::CompletionEndpoint source) noexcept {
  return source.authority == &ordered_endpoint && source.identity == owner.get();
}

const RegionProviderVTable *native_region_provider() noexcept { return &region_table; }
} // namespace hyle::graph::vulkan::detail
