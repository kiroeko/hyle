"""Archive focused native migration evidence and exact disposable images."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ARCH = STAGE.parent
TARGET = ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-inputs.zip'

def identity(path):
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

sources=set([
    'include/hyle/graph/detail/input_source.h','src/graph/input_sources.cc',
    'src/graph_route_cuda/weight_binding.cc','include/hyle/graph/region_provider.h',
    'src/graph/executable.cc','src/graph/execution_source.cc','src/graph/region_access.cc',
    'tests/graph/region_provider_test.cc',
    'src/graph_route_vulkan/weight_binding.cc','src/graph_route_vulkan/CMakeLists.txt',
    'src/compute_route_vulkan/vulkan_weights.cc',
    'src/compute_route_vulkan/vulkan_weights_internal.h',
    'include/hyle/compute/vulkan_weights.h',
    'tests/graph_route_vulkan/weight_binding_test.cc',
    'tests/graph_route_vulkan/native_region_test.cc',
    'tests/graph_route_vulkan/CMakeLists.txt',
    'tests/graph_route_cpu_vulkan/CMakeLists.txt',
    'src/graph_route_apple/native_region.cc','src/graph_route_apple/execution_source.cc',
    'samples/package/graph/cpu_vulkan/main.cc',
    'samples/package/graph/cpu_vulkan/CMakeLists.txt',
    'samples/package/graph/cpu_vulkan/README.md',
    'tests/graph/route_symmetry_vulkan.cc','cmake/HyleComponents.cmake',
    'docs/developer/current-work.md','docs/architecture/compute-design.md',
    'docs/user/vulkan-compute.md','test.ps1',
])
for manifest in [ARCH/'vulkan-cold-custom/candidate-sha.json',STAGE/'vulkan-budget/candidate-sha.json']:
    sources.update(row['path'] for row in json.loads(manifest.read_text()))
for name in sorted(sources):
    path=ROOT/name
    dest=STAGE/'final-source'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(path.read_bytes())
(STAGE/'final-source-identities.json').write_text(json.dumps(
    [dict(relative=name,**identity(ROOT/name)) for name in sorted(sources)],indent=2)+'\n',encoding='utf-8')

targets=[]
for folder,stems in [('windows',['controls']),('vulkan-consumers',['sample','finite','tests']),
                     ('vulkan-weights',['weight-tests'])]:
    for stem in stems:
        for ext in ['.exe','.map','.exp','.lib']:
            path=STAGE/folder/(stem+ext)
            if path.exists():
                assert not path.is_symlink()
                targets.append(identity(path))
(STAGE/'cleanup.json').write_text(json.dumps(dict(files=targets,
    bytes=sum(x['bytes'] for x in targets),retained='all objects, SDKs, sources, logs and data'),indent=2)+'\n',encoding='utf-8')

extensions={'.py','.ps1','.json','.md','.cc','.h','.hpp','.log','.diff','.txt','.cmake','.csv','.rsp','.gz'}
entries={}
for stage,prefix in [(STAGE,''),(ARCH/'vulkan-cold-custom','cold-custom/'),
                     (ARCH/'vulkan-weight-input','weight-adapter/')]:
    for path in stage.rglob('*'):
        if not path.is_file() or path.is_symlink():continue
        relative=path.relative_to(stage)
        if 'build' in relative.parts or path.name in ['archive-receipt.json','cleanup-result.json']:continue
        if path.suffix.lower() in extensions:
            entries[prefix+relative.as_posix()]=path
assert 'cleanup.json' in entries
assert not TARGET.exists(),'Do not overwrite frozen evidence'
with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(entries.items()):z.write(path,name)
with zipfile.ZipFile(TARGET) as z:assert z.testzip() is None
receipt=identity(TARGET)
receipt['path']=TARGET.relative_to(ROOT).as_posix()
receipt['entries']=len(entries)
(STAGE/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archive=receipt,cleanup_files=len(targets),reclaim_bytes=sum(x['bytes'] for x in targets))))
