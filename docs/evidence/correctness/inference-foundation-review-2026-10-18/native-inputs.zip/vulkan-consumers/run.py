"""Narrow current Vulkan/common-Graph host overlay; vendor caches stay read-only."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import shlex
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = ROOT / '.scratch/architecture-refactor-2026-10-18'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

def read(path):
    return json.loads(Path(path).read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def last(stage, tag):
    return next(r for r in reversed(read(ARCH / stage / 'commands.json'))
                if r['tag'] == tag and r['exit'] == 0)

def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def recipe(stage, tag, source, stem, extra=()):
    original = last(stage, tag)['command']
    command = [x for x in original if not x.lower().startswith('/fo')
               and not x.lower().endswith(('.cc', '.cpp', '.cxx'))]
    command += list(extra) + [str(ROOT / source), '/Fo' + str(OUT / (stem + '.obj'))]
    return {'tag': stem + '-compile', 'source': source,
            'origin': f'{stage}/commands.json:{tag}', 'command': command}

def recipes():
    rows = [recipe('cpu-vulkan-finite', 'hybrid-replay-consumer-compile', source, stem)
            for source, stem in [('samples/package/graph/cpu_vulkan/main.cc', 'sample'),
                                 ('tests/graph/route_symmetry_vulkan.cc', 'finite')]]
    for source, stem in [('src/graph_route_vulkan/execution_source.cc', 'vulkan-source'),
                         ('src/graph_route_vulkan/native_region.cc', 'vulkan-region'),
                         ('src/graph_route_vulkan/vulkan_lowering.cc', 'vulkan-lowering')]:
        rows.append(recipe('port-contract-adapters', 'vulkan-region-compile', source, stem))
    shader = ROOT / '.scratch/compute-execution-refactor-2026-10-18/carrier-vulkan/affine.spv'
    assert shader.is_file()
    for source, stem in [('tests/graph_route_vulkan/graph_test.cc', 'graph-test'),
                         ('tests/graph_route_vulkan/execution_source_test.cc', 'source-test'),
                         ('tests/graph_route_vulkan/native_region_test.cc', 'native-graph-test'),
                         ('tests/compute_route_vulkan/native_test.cc', 'native-budget-test')]:
        rows.append(recipe('carrier-copy-contract', 'vulkan-test-compile', source, stem,
                           ['/DHYLE_VULKAN_TEST_SHADER="' + shader.as_posix() + '"']))
    for source, stem in [('src/compute_route_vulkan/vulkan_program.cc', 'native-program'),
                         ('src/compute_route_vulkan/vulkan_row_cache_paged.cc', 'row-paged')]:
        rows.append(recipe('vulkan-native-region', 'program-compile', source, stem))
    rows.append(recipe('../inference-foundation-review-2026-10-18/vulkan-official-bank',
                       'iree-compile', 'src/compute_route_vulkan/vulkan_iree.cc', 'iree'))
    database = ROOT / '.scratch/bench-api-runtime/vulkan/build/compile_commands.json'
    original = next(r for r in read(database) if r['file'].endswith('vulkan_device.cc'))
    command = [x.strip('"') for x in shlex.split(original['command'], posix=False)
               if not x.lower().startswith(('/fo','/fd')) and x != '/FS']
    command += ['/WX', '/Fo' + str(OUT/'native-device.obj')]
    rows.append({'tag': 'native-device-compile', 'source': 'src/compute_route_vulkan/vulkan_device.cc',
                 'origin': str(database)+':vulkan_device.cc', 'command': command})
    for tag, source, stem in [
            ('native-provider-compile', 'src/compute_provider_native/native_provider.cc', 'native-provider'),
            ('aten-provider-compile', 'src/compute_provider_native/aten_cpu_provider.cc', 'aten-provider'),
            ('ggml-provider-compile', 'src/compute_provider_ggml/ggml_cpu_provider.cc', 'ggml-provider'),
            ('onednn-provider-compile', 'src/compute_provider_onednn/onednn_provider.cc', 'onednn-provider'),
            ('onednn-region-compile', 'src/graph_provider_onednn/onednn_region_provider.cc', 'onednn-region'),
            ('cpu-region-compile', 'src/graph_route_cpu/ggml_region.cc', 'cpu-region'),
            ('graph-batch-compile', 'src/graph_batch/batch.cc', 'graph-batch')]:
        rows.append(recipe('admitted-queue-sequence', tag, source, stem))
    return rows

def run(tag, args, timeout=150):
    records = read(OUT / 'commands.json') if (OUT / 'commands.json').exists() else []
    stem = f'{len(records) + 1:02d}-{tag}'
    compiler = recipes()[0]['command'][0]
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': compiler,
                                        'CMAKE_C_COMPILER': compiler})
    env['VSLANG'] = '1033'
    args = list(map(str, args))
    for arg in args:
        if Path(arg).name.lower() == 'torch_cpu.lib':
            env['PATH'] = str(Path(arg).parent) + os.pathsep + env.get('PATH', '')
    # Runtime executables use the exact cached libtorch selected in the base closure.
    base = read(OUT / 'base-carrier-copy-contract-link.json')['command']
    torch = next(Path(x) for x in base if Path(x).name.lower() == 'torch_cpu.lib')
    env['PATH'] = str(torch.parent) + os.pathsep + env.get('PATH', '')
    start = time.monotonic()
    p = subprocess.run(args, cwd=ROOT, env=env, capture_output=True, timeout=timeout,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / (stem + '.stdout.log')).write_bytes(p.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(p.stderr)
    records.append({'tag': tag, 'command': args, 'exit': p.returncode,
                    'seconds': time.monotonic()-start, 'stdout': stem+'.stdout.log',
                    'stderr': stem+'.stderr.log'})
    write('commands.json', records)
    print(stem, p.returncode, flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-7000:] + p.stderr.decode(errors='replace')[-3000:])
        raise SystemExit(p.returncode)

def compile_selected(stems):
    available = recipes()
    write('compile-recipes.json', available)
    for stem in stems:
        row = next(r for r in available if r['tag'] == stem + '-compile')
        before = identity(ROOT / row['source'])
        run(row['tag'], row['command'])
        after = identity(ROOT / row['source'])
        assert before == after, row['source'] + ' changed during compilation'
        write(stem + '-identity.json', {'source': after, 'object': identity(OUT / (stem+'.obj')),
                                      'origin': row['origin']})

def link_base():
    old = read(OUT / 'base-carrier-copy-contract-link.json')['command']
    current = read(OUT / 'base-windows-link.json')['command']
    # Shared CPU objects come from the final Provider15/QueueSequence closure.
    # Do not bring its fake/test backend overrides into a real native consumer.
    shared = [x for x in current if x.lower().endswith('.obj') and
              'test' not in Path(x).name.lower() and
              Path(x).name != 'cpu-gallocr-faults.obj']
    replacements = {stem + '.obj': OUT / (stem + '.obj') for stem in
        ['native-provider', 'aten-provider', 'ggml-provider', 'onednn-provider',
         'onednn-region', 'cpu-region', 'graph-batch']}
    for stem in ['executable', 'execution_source', 'region_access', 'input_sources']:
        replacements[stem + '.obj'] = ARCH / 'native-inputs/windows' / (stem + '.obj')
    shared = [str(replacements.get(Path(x).name, x)) for x in shared]
    # These are exact source owners from the last successful real Vulkan closure,
    # not a basename replacement (two independent modules name vulkan-region.obj).
    native_old = [x for x in old if x.lower().endswith('.obj')]
    last_native = next(i for i, x in enumerate(native_old) if Path(x).name == 'programs.obj')
    native_paths = [x for x in native_old[:last_native+1] if Path(x).name != 'device.obj']
    native_paths = [str(OUT / 'iree.obj') if Path(x).name == 'iree.obj' else
                    str(OUT / 'row-paged.obj') if Path(x).name == 'paged.obj' else x
                    for x in native_paths]
    native_paths += [str(OUT / (stem+'.obj')) for stem in
                     ['native-program', 'native-device', 'vulkan-source', 'vulkan-region', 'vulkan-lowering']]
    native_paths += [x for x in old if any(x.endswith(suffix) for suffix in
        ['vulkan-constant-readback\\memory-staging.obj',
         'vulkan-constant-readback\\transfer.obj',
         'vulkan-replay-copy\\copy-recording.obj',
         'vulkan-replay-copy\\copy-program.obj'])]
    native_paths += [str(ARCH / 'vulkan-weight-input' / (stem+'.obj'))
                     for stem in ['weights', 'weight-binding']]
    objects = list(dict.fromkeys(native_paths + shared + [str(ROOT /
        '.scratch/perf-review-2026-10-18/blocking-pool/candidate.obj')]))
    assert all(Path(x).is_file() for x in objects), [x for x in objects if not Path(x).is_file()]
    assert not any('cuda' in x.lower() for x in objects), 'Vulkan must not import CUDA owners'
    libs = [x for x in old if x.lower().endswith('.lib')]
    flags = [x for x in old[1:] if not x.lower().endswith(('.obj','.lib')) and
             not x.upper().startswith(('/OUT:', '/MAP:'))]
    command = [old[0], *flags, *objects, *libs]
    write('matched-link-base.json', {'command': command, 'objects': [identity(x) for x in objects],
        'base': 'carrier-copy-contract Vulkan native objects/libraries + final weight-inputs CPU/shared owners',
        'source_table': 'native-inputs/windows current actual source',
        'excluded': 'All old CPUCUDA runtime, all CUDA kernels/providers, CPU test/fault objects',
        'scope': 'Actual F32/Q8_0 consumers; preserves the prior successful CPU/Vulkan numerical cache, no claim about unexecuted added IQ1 enum formats.'})
    return command

def link(which):
    base = link_base()
    if which == 'tests':
        objects = [OUT / (x+'.obj') for x in ['graph-test','source-test','native-graph-test','native-budget-test']]
        libs = [ROOT / '.scratch/build-compute-v2-dev/lib' / name for name in ['gtest_main.lib','gtest.lib']]
    else:
        objects, libs = [OUT / (which+'.obj')], []
    command = [*base[:1], '/OUT:'+str(OUT/(which+'.exe')), '/MAP:'+str(OUT/(which+'.map')),
               *map(str, objects), *base[1:], *map(str,libs)]
    run(which+'-link', command)

def execute(which):
    command = [OUT / (which+'.exe')]
    if which == 'tests':
        command += ['--gtest_color=no', '--gtest_filter=VulkanGraph.*:VulkanExecutionSource.*:'
            'VulkanNativeRegion.OriginalGraphChargesNativeBackingAndRetainsEscapedOwner:'
            'VulkanNative.InvocationBudgetUsesActualResourcesAndFollowsEscapedBacking',
            '--gtest_output=json:'+str(OUT/'tests-results.json')]
    run(which+'-run', command)

if __name__ == '__main__':
    if sys.argv[1:2] == ['compile']:
        compile_selected(sys.argv[2:])
    elif sys.argv[1:2] == ['prepare']:
        write('compile-recipes.json', recipes())
    elif sys.argv[1:2] == ['link']:
        for which in sys.argv[2:]: link(which)
    elif sys.argv[1:2] == ['run']:
        for which in sys.argv[2:]: execute(which)
    elif sys.argv[1:2] == ['run-budget']:
        run('native-budget-run', [OUT/'tests.exe', '--gtest_color=no',
            '--gtest_filter=VulkanNative.InvocationBudgetUsesActualResourcesAndFollowsEscapedBacking'])
    else:
        raise SystemExit('Use prepare or compile <stems>; linking waits for frozen SPI25 core/native objects.')
