from pathlib import Path
import difflib
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]

def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n',encoding='utf-8')
def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def snapshot(name):
    path=ROOT/name
    dest=OUT/'candidate'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(path.read_bytes())
    return dict(path=name, bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

commands=read(OUT/'commands.json')
for tag in ['tests-run','sample-run','finite-run']:
    final=next(r for r in reversed(commands) if r['tag']==tag)
    assert final['exit']==0,tag
result=read(OUT/'tests-results.json')
assert result['tests']==11 and result['failures']==0
owners=[]
for path in sorted(OUT.glob('*-identity.json')):
    row=read(path)
    if not isinstance(row.get('source'),dict): continue
    source=row['source']
    assert identity(source['path'])==source,path
    assert identity(row['object']['path'])==row['object'],path
    name=Path(source['path']).relative_to(ROOT).as_posix()
    owners.append(dict(source=snapshot(name), object=row['object'], origin=row['origin']))
write('compiled-source-identities.json',owners)
owned=[r['path'] for r in read(OUT/'before-identities.json')]
write('consumer-source-identities.json',[snapshot(n) for n in owned])
diff=[]
for name in owned:
    diff.extend(difflib.unified_diff((OUT/'before'/name).read_text(encoding='utf-8').splitlines(True),
        (ROOT/name).read_text(encoding='utf-8').splitlines(True),fromfile='before/'+name,tofile='current/'+name))
(OUT/'consumer-source.diff').write_text(''.join(diff),encoding='utf-8')
headers=['include/hyle/graph/region_provider.h','include/hyle/graph/executable.h',
    'include/hyle/graph/vulkan.h','include/hyle/compute/vulkan.h',
    'include/hyle/compute/low_precision.h','src/compute_route_vulkan/vulkan_internal.h',
    'src/compute_route_vulkan/vulkan_program_internal.h','src/graph_route_vulkan/vulkan_source.h',
    'src/graph/execution_source_internal.h','include/hyle/graph/detail/input_source.h']
write('header-identities.json',[snapshot(n) for n in headers])
retained=[identity(p) for p in sorted(OUT.glob('*.obj'))]
write('retained-objects.json',retained)
images=[identity(p) for p in sorted(OUT.iterdir()) if p.suffix.lower() in {'.exe','.map','.lib','.exp'}]
write('cleanup-candidates.json',dict(files=images,retain=retained,
    count=len(images),bytes=sum(p['bytes'] for p in images),action='candidate_only_parent_test.ps1_no_deletion'))
write('summary.json',dict(status='PASS',stage=str(OUT),
    focused_tests=dict(total=11,failed=0,command='43-tests-run',results='tests-results.json'),
    consumers=[dict(command='35-sample-run',exit=0),dict(command='36-finite-run',exit=0)],
    companion=dict(stage=str(OUT.parent/'vulkan-weights'),tests=2,failed=0,
                   owner='backend_assembly_design; not rerun by this driver'),
    implementation=[
        'Package CPU/Vulkan consumer uses ordinary Graph compile, Executable, original Invocation, Completion, GraphOutput and optional prepare_progress; no old CPU/Vulkan Invocation/Results alias or second driver.',
        'Actual CPU/native sources and host/device/staging resources retain required node placements. Only CPU shared lanes receive caller QueueBindings.',
        'Complete four-node GGUF Q8_0 native FFN fusion retained, two original slots submitted in three changed-input phases; original independent oracle is checked on slot0, as before. Old GraphOutput prevents mutation.',
        'The existing down boundary is additionally published to observe its real VkBuffer owner; this prolongs liveness without adding arithmetic or splitting native fusion.',
        'Typed Vulkan immutable input binding declares actual device storage. Pending native upload remains an explicit HostWait source, with Reject/Allow and original progress.',
        'Finite/control consumer covers shapes1/4, held output owners, cumulative quotas, CPU->Vulkan->CPU same-address two-phase strict replay after one cold prepare, and checked control failure preserving CPU output99.',
        'SPI25 propagates actual resource budget/storage domains. Native known backing blocks retain their budget through escaped actual native outputs.'],
    native_budget=dict(slot_bytes=32,escaped_output_bytes=16,after_last_owner_bytes=0,
        evidence='43-tests-run stderr: dispatch0 native input0->adapted2; dispatch1 managed2->output1; two independent16B blocks',
        exclusions='The additional16B is the existing unknown-byte-origin input adapter, not a duplicated Neg output or a stale elementwise result cast.'),
    retained_failures=[
        '01-sample-compile: migrated CompileOptions designator order; fixed in own consumer.',
        '24-tests-run: original9 passed, Graph new fixture omitted required System metadata budget domain; native new fixture assumed16B for actual32B plan.',
        '25-sample-run: typed Weight input lacked actual device ExternalResourceContract; explicit contract restored,35 passed.',
        '27-native-device-compile: initial reused Program flags omitted generated vulkan_build.h include; switched to actual module compileDB.',
        '34-tests-run: matched native_device ruled out old allocator cache; exact16B fixtures still rejected correctly.',
        '39-native-budget-run: original16B fixture failed, diagnostic proved32B actual block plan; final tests retain insufficient-budget rejection and correct escaped-owner accounting.'],
    cache_provenance=[
        'Twenty unique current Hyle host objects in this stage, actual flags/commands and source/object SHA retained; no numerical SDK/kernel/shader rebuild.',
        'Root current executable,execution_source,region_access,input_sources replace prior shared objects; remaining compatible current weight-inputs core owners retained.',
        'Current source-matching BlockingPool candidate explicitly precedes its old archive. Original Vulkan numerical and CPU libraries retained read-only.',
        'The inherited successful mixed numerical closure contains Vulkan bdb COUNT43 and CPU added-IQ1 COUNT67 sources. This stage tests F32 and Q8_0 only; it does not claim coverage or type compatibility for unexecuted extra IQ1 formats.'],
    limits=[
        'No whole-model/large-bank/performance matrix. Timings are single functional runs.',
        'Graph domain workspace512B and logical boundary320B are separate from native allocated blocks. Shared ResourceBudget charges known native backing, private unknown remains explicit.',
        'Common report does not provide native upload queue counts. No inferred zero, copy/compute overlap, or native DeviceWait claim.',
        'No old runtime compatibility layer retained by these consumers; root owns deletion of old module runtime.'],
    cleanup=dict(files=len(images),bytes=sum(p['bytes'] for p in images),retained_objects=len(retained))))

archive=OUT/'source-results.zip'
assert not archive.exists(),'Do not overwrite a frozen capsule'
allowed={'.py','.json','.log','.diff','.cc','.h','.mm','.md','.txt'}
files=[p for p in OUT.rglob('*') if p.is_file() and p.suffix.lower() in allowed
       and p.name!='archive-receipt.json']
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(files): z.write(path,path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)
    for path in z.namelist():
        assert Path(path).suffix.lower() in allowed
        assert not z.read(path).startswith((b'MZ',b'\x7fELF',b'!<arch>'))
write('archive-receipt.json',dict(**identity(archive),entries=len(files),
    no_objects_images_maps_libraries_sdk=True,retained_objects=len(retained),
    cleanup_files=len(images),cleanup_bytes=sum(p['bytes'] for p in images)))
print((OUT/'archive-receipt.json').read_text())
