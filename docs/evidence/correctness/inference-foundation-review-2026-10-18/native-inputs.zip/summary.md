# Native inputs, cold lowering, and actual native budget ownership

This batch extends the original Graph runtime; it does not complete the full
refactor. No SDK or native kernel collection was rebuilt.

The immutable input source now distinguishes actual producer identity from an
adapter's ownership representation. CUDA uses its existing WeightState identity;
Vulkan adapters retain the original shared WeightState and exported native
storage, with the same producer deduplicated across ports. Vulkan's real upload
has no Compute QueueSequence import, so it explicitly uses HostWait and the
original optional progress service. Pending tests still invoke the actual native
fence API; no synthetic Queue or alternate Graph execution/result owner exists.

Vulkan SourceOptions retains custom lowering only for cold compilation. Distinct
configurations have distinct source identities; actual Device and completion
endpoints remain the original Runtime. Custom callbacks capture real Context or
Kernel owners explicitly; original native Programs retain resolved pipelines.

The CPU+Vulkan sample and hybrid finite consumer use ordinary compile,
Invocation, QueueBindings, Completion and GraphOutput. The actual Q8 FFN keeps
four native nodes fused, two slots and three replays; the original independent
scalar oracle checks the original slot-0 output. Two slots execute and old
results block reuse; this is not a claim of an additional slot-1 oracle. Weight
chunk and CPU/native/CPU two-phase continuations also pass.

Review found a real budget omission: generated native outputs skipped Graph
workspace charging, while native create_slot omitted the existing native
InvocationAllocation. Region SPI25 now supplies the original scope and available
actual domains. Vulkan allocation uses real MemoryResourceRefs, validates exact
Runtime/kind, reserves before real Buffer allocation, and retains reservations
inside those actual Buffers through escaped native results. Checked native and
IREE dispatches require their real mapped staging domain. Driver/provider private
cost remains unknown; requested-byte accounting is not a physical VRAM total.

The new budget fixtures initially confused logical output size with full native
slot capacity. Actual diagnostics proved an external-input byte-origin adapter
copy of 16B plus a 16B output: dispatch0 is native input0 -> adapter2, dispatch1
is managed adapter2 -> output1. The original 16B insufficient-quota rejection is
preserved; exact 32B succeeds, failed allocation rolls back, escaped output keeps
16B, and the last owner releases it to zero. The earlier missing metadata-domain
test error and rejected stale-device-cache hypothesis are preserved in raw logs;
no numerical implementation was changed in response to either hypothesis.

Validation:
- Matched selected host/core regressions: 96/96 after SPI25; exact sources and
  objects are recorded by windows/commands.json and controls-closure.json.
- Actual Vulkan graph/custom/source/native-budget cases: 11/11, record43.
- Actual native immutable-weight cases: 2/2, including held native observation,
  original progress, owner deduplication, old outputs and cold metadata reuse.
- Migrated full CPU+Vulkan sample and finite/control/roundtrip consumers: exit0.
- Configure-only production/fixture/progress selection passed; normal test CMake
  links the new progress dependency explicitly.
- Mac16,12 current SPI25 Apple Source and native-region TUs: 2/2 compile-only
  with strict warnings. No current common-core link/run or Apple shared-budget
  qualification is claimed. The earlier SPI24 compilation is separately kept.

The reused Vulkan ggml cache has COUNT43 base/Vulkan owners, while the CPU-side
provider metadata has its earlier extended headers. Actual evidence here is
limited to F32 and Q8_0; it does not qualify all quantization types or the full
model matrix. No duplicate CUDA closure or replacement SDK was introduced.

Still open: original native page recipe/layout/permission and pending-update
migration, deletion of remaining Apple/Vulkan hybrid runtimes, optional IO
assembly separation, remaining model/function coverage, and Qwen independent
numerical and fair-throughput acceptance. The new SPI requires fresh matching
region-ID owners when using old validation caches; full Qwen was not rerun here.

This archive excludes objects/images/maps/SDKs. All reusable objects, source,
logs and data remain local. cleanup.json identifies only disposable test images,
maps and linker exports for root test.ps1 verification and removal.
