"""Incremental shared producer-identity validation; original native caches."""
from pathlib import Path
import importlib.util
import json
import sys

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
ARCH = OUT.parents[1]
ROOT = ARCH.parents[1]
PRIOR = ARCH/'weight-inputs/windows'
spec = importlib.util.spec_from_file_location('previous', PRIOR/'run.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
d = previous.d
d.OUT = OUT

def compile():
    d.compile_one('src/graph/input_sources.cc', 'input_sources', d.CORE)
    recipe = next(row['command'] for row in reversed(d.read(PRIOR/'commands.json'))
                  if row['tag']=='weight_binding-compile' and row['exit']==0)
    d.compile_one('src/graph_route_cuda/weight_binding.cc', 'cuda_weight_binding', recipe)

def budget():
    d.compile_one('src/graph/executable.cc', 'executable', d.CORE)
    d.compile_one('tests/graph/region_provider_test.cc', 'region_provider_test', d.TEST)

def bridges():
    d.compile_one('src/graph/execution_source.cc', 'execution_source', d.CORE)
    d.compile_one('src/graph/region_access.cc', 'region_access', d.CORE)

def controls():
    base = next(row['command'] for row in reversed(d.read(PRIOR/'commands.json'))
                if row['tag']=='controls-link' and row['exit']==0)
    command = []
    for arg in base:
        if Path(arg).name in ['input_sources.obj','executable.obj','region_provider_test.obj',
                              'execution_source.obj','region_access.obj']:
            command.append(OUT/Path(arg).name)
        elif str(arg).upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:')):
            prefix = str(arg).split(':',1)[0]
            command.append(prefix+':'+str(OUT/Path(str(arg).split(':',1)[1]).name))
        else:
            command.append(arg)
    d.save('controls-closure.json', [d.identity(arg) for arg in command
           if Path(arg).suffix in ['.obj','.lib'] and Path(arg).exists()])
    d.run('controls-link', command)
    selected = d.read(PRIOR/'summary.json')['filter']
    d.run('controls-run',[OUT/'controls.exe','--gtest_color=no','--gtest_filter='+selected,
          '--gtest_output=json:'+str(OUT/'results.json')])
    results=d.read(OUT/'results.json')
    assert results['failures']==0 and results['errors']==0
    d.save('summary.json', dict(tests=results['tests'], failures=0,
        scope='shared immutable producer identity core; native consumers separate', sdk_rebuilt=False))
    print(results['tests'], 'passed', flush=True)

if __name__=='__main__':
    {'compile':compile,'controls':controls,'budget':budget,'bridges':bridges}[sys.argv[1]]()
