Vulkan immutable WeightBatch �� original Graph Invocation: **2/2 PASS**, RTX 4070, 328 ms.

Cold binding retains and exports the actual selected native storage without a payload copy. Same-upload IDs deduplicate by real WeightState identity; different batches remain separate. Both slots, changed weights, old results, invalid IDs/foreign Runtime, repeated cold preparation metadata, and upload-slot recovery passed.

The original progress path returned Pending while successful real-fence observation was withheld; cold bind/prepare made no fence poll/wait calls, a normal Scheduler task ran, and release produced the unchanged exact F32 result. The test always calls the real Vulkan API. This is an observation/ownership control, not a DMA-duration or throughput measurement.

Native Vulkan weight upload still uses an explicit HostWait frontier; Reject remains a rejection. No DeviceWait import, new executor, fake Queue, SDK rebuild, or shader rebuild is claimed. Resource/allocator objects keep their original borrowed lifetime.

Compile commands and three retained objects: `../../vulkan-weight-input/`. Final matched link/run, source/object identities, raw results, and precise cleanup candidates: this directory. No artifacts were deleted.
