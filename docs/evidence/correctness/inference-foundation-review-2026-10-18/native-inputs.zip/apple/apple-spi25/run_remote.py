from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def identity(path):
    path = Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip() == 'Mac16,12'
    manifest = json.loads((ROOT/'sources.json').read_text())
    for row in manifest['sources']:
        assert identity(ROOT/row['path'])['sha256'] == row['sha256'],row['path']
    baseline = json.loads((ROOT/'baseline.json').read_text())
    assert identity(Path(baseline['root'])/'compile-plan.json')['sha256'] == baseline['compile_plan_sha256']
    (ROOT/'machine.txt').write_text(subprocess.check_output(
        ['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)
        + subprocess.check_output(['xcrun','clang++','--version'],text=True))
    # Current complete two-TU Hyle header closure precedes retained numerical
    # SDK includes. No core object or old InvocationState layout is linked.
    includes = [ROOT/'include',ROOT,ROOT/'src/graph',ROOT/'src/compute',
                ROOT/'src/graph_route_apple',ROOT/'src/compute_route_apple']
    commands = []
    objects = []
    for index,row in enumerate(baseline['sources'],1):
        args = []
        skip = False
        for arg in row['command']:
            if skip:
                skip = False
                continue
            if arg in {'-c','-o'}:
                skip = True
                continue
            args.append(arg)
        args[1:1] = ['-I'+str(path) for path in includes]
        assert '-Werror' in args and '-Wall' in args and '-Wextra' in args and '-Wpedantic' in args
        name = 'apple-source' if row['source'].endswith('execution_source.cc') else 'apple-region'
        output = ROOT/(name+'.o')
        command = args+['-MMD','-MF',str(ROOT/(name+'.d')),'-c',str(ROOT/row['source']),'-o',str(output)]
        stem = f'{index:02d}-{name}-compile'
        started = time.monotonic()
        with (ROOT/(stem+'.stdout.log')).open('wb') as out,(ROOT/(stem+'.stderr.log')).open('wb') as err:
            process = subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err)
            (ROOT/'live.json').write_text(json.dumps(dict(pid=process.pid,tag=stem))+'\n')
            code = process.wait()
        commands.append(dict(tag=stem,command=command,exit=code,
            seconds=time.monotonic()-started,source=identity(ROOT/row['source']),
            stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
        (ROOT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        (ROOT/'live.json').write_text(json.dumps(dict(terminal=True,tag=stem,exit=code))+'\n')
        print(stem,code,flush=True)
        if code:
            print((ROOT/(stem+'.stderr.log')).read_text(errors='replace')[-10000:])
            raise SystemExit(code)
        objects.append(identity(output))
    (ROOT/'object-identities.json').write_text(json.dumps(objects,indent=2)+'\n')
    summary = dict(machine='Mac16,12',compile_only=True,compiled=len(commands),passed=len(commands),
        linked=False,executed=False,provider_contract=15,region_spi=25,
        scope='Apple actual FIFO uses_private_threads diagnostic; no SDK/core compilation or link')
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'cleanup-mac.json').write_text(json.dumps(dict(root=str(ROOT),files=[],retain=objects),indent=2)+'\n')
    print(json.dumps(summary),flush=True)


if __name__ == '__main__':
    main()

