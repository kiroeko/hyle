from pathlib import Path
import importlib.util
import hashlib
import io
import json
import tarfile

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('stage',OUT/'stage.py')
stage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stage)
code = '''from pathlib import Path
import io,sys,tarfile
r=Path(''' + repr(stage.REMOTE) + ''')
names=['commands.json','object-identities.json','summary.json','machine.txt','live.json','cleanup-mac.json']
names.extend(p.name for p in r.glob('*.log'))
names.extend(p.name for p in r.glob('*.d'))
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w:gz') as a:
 for name in sorted(names):a.add(r/name,arcname=name)
sys.stdout.buffer.write(data.getvalue())
'''
raw = stage.ssh(code)
(OUT/'results.tar.gz').write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
               for m in archive.getmembers())
    archive.extractall(OUT/'results')
summary = json.loads((OUT/'results/summary.json').read_text())
summary['results_archive'] = dict(path=str(OUT/'results.tar.gz'),bytes=len(raw),
    sha256=hashlib.sha256(raw).hexdigest())
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
