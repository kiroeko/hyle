from pathlib import Path
import importlib.util

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('base_stage',OUT.parent/'stage.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
REMOTE = base.REMOTE+'/apple-spi25'
ssh = base.ssh
base.OUT = OUT
base.ROOT = OUT.parents[4]
base.REMOTE = REMOTE

if __name__ == '__main__':
    base.main()
