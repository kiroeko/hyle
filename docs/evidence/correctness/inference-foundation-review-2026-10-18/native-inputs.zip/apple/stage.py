from pathlib import Path
import importlib.util
import hashlib
import io
import json
import re
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-native-inputs-apple'
BASE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-admitted-queue-sequence'
spec = importlib.util.spec_from_file_location('transport', OUT.parents[1]/'apple-readonly-ports/stage.py')
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)
ssh = transport.ssh
SEEDS = ['src/graph_route_apple/execution_source.cc', 'src/graph_route_apple/native_region.cc']


def main():
    code = '''from pathlib import Path
import hashlib,json,subprocess
r=Path(''' + repr(BASE) + ''')
p=r/'compile-plan.json'
data=json.loads(p.read_text())
rows=[row for row in data['sources'] if row['source'] in ''' + repr(SEEDS) + ''']
assert len(rows)==2
print(json.dumps(dict(machine=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),
    root=str(r),compile_plan_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),sources=rows)))
'''
    baseline = json.loads(ssh(code))
    assert baseline['machine'] == 'Mac16,12'
    (OUT/'baseline.json').write_text(json.dumps(baseline, indent=2)+'\n')
    files = {'run_remote.py':OUT/'run_remote.py', 'baseline.json':OUT/'baseline.json'}
    seen = set()

    def add(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:
            return
        seen.add(path)
        files[path.relative_to(ROOT).as_posix()] = path
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',
                                  path.read_text(encoding='utf-8-sig'), re.M):
            for directory in [path.parent, ROOT, ROOT/'include', ROOT/'src/graph',
                              ROOT/'src/compute', ROOT/'src/compute_route_apple',
                              ROOT/'src/graph_route_apple']:
                candidate = directory/include
                if candidate.is_file():
                    add(candidate)
                    break

    for source in SEEDS:
        add(ROOT/source)
    manifest = dict(remote=REMOTE, compile_only=True, sources=[
        dict(path=name, bytes=path.stat().st_size,
             sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        for name,path in sorted(files.items())])
    (OUT/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
    files['sources.json'] = OUT/'sources.json'
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload,mode='w:gz') as archive:
        for name,path in sorted(files.items()):
            archive.add(path,arcname=name)
    (OUT/'minimal-sources.tar.gz').write_bytes(payload.getvalue())
    code = '''from pathlib import Path
import io,sys,tarfile
r=Path(''' + repr(REMOTE) + ''')
assert not r.exists(),r
r.mkdir()
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as a:
 assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in a.getmembers())
 a.extractall(r)
print(r)
'''
    result = ssh(code,payload.getvalue())
    (OUT/'stage.log').write_bytes(result)
    print(result.decode().strip(),len(files),'files',len(payload.getvalue()),'bytes')


if __name__ == '__main__':
    main()
