from pathlib import Path
import difflib,zipfile,json,hashlib
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
changed={'src/compute_provider_native/aten_cpu_provider.cc':'aten.before.cc','tests/compute_provider_native/indexing_test.cc':'indexing.before.cc'}
(OUT/'product-tests.diff').write_text(''.join(''.join(difflib.unified_diff((OUT/old).read_text().splitlines(True),(ROOT/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p))for p,old in changed.items()))
(OUT/'summary.txt').write_text('''CPU GatherElements implementation, 2026-10-18.
Product change only src/compute_provider_native/aten_cpu_provider.cc.
Public model_ops schema and shared fixture are supplied by root and included
as reproduction dependencies, not claimed as this agent's edits.
The existing ATen CPU provider admits the custom operation for the schema's
plain dense F32/F16/BF16 data, dense same-rank I32 indices and normalized axis.
It reuses the cold aligned I32 index buffer, expands a view over its byte axis,
and calls mature at::gather_out on byte views. No payload numeric conversion,
new kernel or T*T intermediate. The fixed index buffer is O(indices.size).
Checked validates all IDs in the existing boundary before mapping/writing the
output; Unchecked omits this Hyle host scan. Native ATen may still check bounds.
Empty output returns the original common no-op. Existing alias/error/retirement
semantics stay in the original prepared invocation/Queue.

Fresh Windows MSVC 14.50.35717 /O2 /MD /W4 /WX host builds: ATen CPU provider
TU and complete canonical tests/compute_provider_native/indexing_test.cc.
Existing CPU default roster, native/oneDNN/ggml/base libs and locked torch-cpu
SDK were reused. No configure, native SDK/full library build, GPU/model run.
The exact before TU fails default-route admission for all three dtypes.
After: complete canonical TU 7 tests/3 suites PASS, no skips.
New tests cover shared independent oracle T3/E5/K7 (K>E, repeated IDs), seed0/7
changed source and IDs, Checked/Unchecked, explicit ATen and actual public
cpu::create_context default route, both negative/E IDs with poisoned output
unchanged, axis0, K0 empty output, and raw F32/F16/BF16 signalling-NaN payload,
signed-zero and subnormal storage retention. A failed invocation is not reused
for a second failure case. Existing Gather/Scatter/Concat cases also PASS.
The implementation uses generic same-rank ATen gather on all schema axes;
the actual directed tests cover rank2 last-axis and axis0, not every rank/axis.
Additional independent public CPU Graph probe: actual graph::cpu::create_context,
T3/E5/K2 TopK -> produced I32 IDs -> GatherElements(Unchecked) -> Neg,
publishing selected values, IDs and negation. Two changed-score/ID replays
match an independent per-row stable-sort oracle exactly. Compile report is
3 nodes/3 steps/0 regions, proving ordinary leaf fallback accepts the new
custom schema. Fresh one probe TU + current ATen host object; cached Graph
libraries. The original cache's AVX2 program DLL path was stale, so this
correctness closure reuses the previously validated mixed baseline selector
and native ops objects, without rebuilding the SDK or changing product policy.
This is an independent probe, not a new canonical Graph test or a complete
MoE model/performance claim. See graph-commands.json and graph-identities.json.

Additional Linux compile boundary: Ubuntu-24.04 x86_64 g++-14 14.2.0,
-std=c++23 -fsyntax-only on current public model_ops.h self-contained,
complete canonical tests/compute_ops/operation_test.cc and current ATen provider
TU all PASS. Existing locked Linux torch-cpu and gtest headers, direct /mnt/c
Windows authoritative sources. No object, link, Linux numerical run, buildtree,
source copy or dependency install. TorchConfig.cmake has no ABI macro override;
compiler's observed _GLIBCXX_USE_CXX11_ABI=1. Logs/commands/identities from
.scratch/inference-foundation-review-2026-10-18/gather-elements-linux-syntax
are included under repro/linux-syntax. This does not prove Linux numerical
behavior or binary-link ABI compatibility.

Repro: python .scratch/inference-feature-completion-2026-10-18/gather-elements-cpu/run.py
Exact compile/link/run commands and exit codes: commands.json; source/library
SHA256 identities: identities.json. Small source/results only, no obj/exe/SDK.
''')
graph_commands=OUT/'graph-commands.json'
if graph_commands.exists():
    linked=next(row['command']for row in json.loads(graph_commands.read_text())if row['tag']=='graph-link')
    paths=[Path(p)for p in linked if p.endswith(('.obj','.lib'))and Path(p).is_file()]
    (OUT/'graph-identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
files={'source/'+p:ROOT/p for p in changed}
for p in ['include/hyle/compute/model_ops.h','tests/compute_models/gather_elements_fixture.h','tests/compute_provider_native/half_test_support.h','tests/compute/native_context_fixture.h']:
    files['source/'+p]=ROOT/p
for p in OUT.iterdir():
    if p.suffix in ['.py','.cc','.h','.json','.log','.diff','.txt']:files['repro/'+p.name]=p
linux=ROOT/'.scratch/inference-foundation-review-2026-10-18/gather-elements-linux-syntax'
if (linux/'summary.txt').exists():
    for p in linux.iterdir():
        if p.suffix in ['.py','.json','.log','.txt']:files['repro/linux-syntax/'+p.name]=p
    files['source/tests/compute_ops/operation_test.cc']=ROOT/'tests/compute_ops/operation_test.cc'
out=OUT/'source-results.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
    for name,path in sorted(files.items()):z.write(path,name)
print(json.dumps(dict(path=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest())))
