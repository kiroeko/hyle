#include <hyle/graph/cpu.h>
#include <hyle/compute/model_ops.h>
#include "tests/compute_models/gather_elements_fixture.h"
#include <algorithm>
#include <array>
#include <cstdio>
#include <numeric>
namespace c=hyle::compute;namespace g=hyle::graph;namespace m=hyle::mem;
hyle::Status run(){
  constexpr std::int64_t rows=3,columns=5,selected=2;
  HYLE_ASSIGN_OR_RETURN(auto context,g::cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto desc,c::TensorDesc::dense(c::DataType::kFloat32,std::array{rows,columns}));
  HYLE_ASSIGN_OR_RETURN(auto out_desc,c::TensorDesc::dense(c::DataType::kFloat32,std::array{rows,selected}));
  HYLE_ASSIGN_OR_RETURN(auto id_desc,c::TensorDesc::dense(c::DataType::kInt32,std::array{rows,selected}));
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto input,builder.input(desc));const std::array top_input{input};
  HYLE_ASSIGN_OR_RETURN(auto top,builder.add_node(c::Operation(c::TopK{.count=selected}),top_input));
  HYLE_ASSIGN_OR_RETURN(auto ids,builder.result(top,1));
  const std::array gather_inputs{input,ids};
  HYLE_ASSIGN_OR_RETURN(auto gathered,builder.add_node(c::model_ops::gather_elements(-1,c::IndexBoundsPolicy::kUnchecked),gather_inputs));
  HYLE_ASSIGN_OR_RETURN(auto output,builder.result(gathered));
  HYLE_ASSIGN_OR_RETURN(auto negative,builder.add(c::Unary{c::UnaryKind::kNeg},output));
  for(auto value:{output,ids,negative})HYLE_RETURN_IF_ERROR(builder.publish(value));
  HYLE_ASSIGN_OR_RETURN(auto logical,std::move(builder).finish());
  HYLE_ASSIGN_OR_RETURN(auto compiled,g::compile(logical,context));
  HYLE_ASSIGN_OR_RETURN(auto invocation,compiled.executable.create_invocation());
  HYLE_ASSIGN_OR_RETURN(auto source,m::Buffer::create(m::system_resource(),rows*columns*4,64));
  HYLE_ASSIGN_OR_RETURN(auto values,m::Buffer::create(m::system_resource(),rows*selected*4,64));
  HYLE_ASSIGN_OR_RETURN(auto indices,m::Buffer::create(m::system_resource(),rows*selected*4,64));
  HYLE_ASSIGN_OR_RETURN(auto negated,m::Buffer::create(m::system_resource(),rows*selected*4,64));
  HYLE_ASSIGN_OR_RETURN(auto source_view,c::ConstTensorView::create(desc,source.view()));
  HYLE_ASSIGN_OR_RETURN(auto value_view,c::TensorView::create(out_desc,values.view()));
  HYLE_ASSIGN_OR_RETURN(auto index_view,c::TensorView::create(id_desc,indices.view()));
  HYLE_ASSIGN_OR_RETURN(auto negative_view,c::TensorView::create(out_desc,negated.view()));
  HYLE_RETURN_IF_ERROR(invocation.bind(input,source_view));HYLE_RETURN_IF_ERROR(invocation.bind(output,value_view));
  HYLE_RETURN_IF_ERROR(invocation.bind(ids,index_view));HYLE_RETURN_IF_ERROR(invocation.bind(negative,negative_view));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
  HYLE_RETURN_IF_ERROR(invocation.prepare_replay(queues));
  for(unsigned replay=0;replay<2;++replay){
    std::array<float,rows*columns> data{};const auto base=gather_elements_test::data(int(replay));
    for(unsigned row=0;row<rows;++row)for(unsigned col=0;col<columns;++col)
      data[row*columns+col]=float(base[row*columns+(col+replay*(row+1))%columns]);
    HYLE_RETURN_IF_ERROR(source.view().write(std::as_bytes(std::span(data))));
    HYLE_ASSIGN_OR_RETURN(auto done,invocation.submit(queue));HYLE_RETURN_IF_ERROR(done.wait());
    std::array<float,rows*selected> actual{},neg{};std::array<std::int32_t,rows*selected> actual_ids{};
    HYLE_RETURN_IF_ERROR(values.view().read(std::as_writable_bytes(std::span(actual))));
    HYLE_RETURN_IF_ERROR(negated.view().read(std::as_writable_bytes(std::span(neg))));
    HYLE_RETURN_IF_ERROR(indices.view().read(std::as_writable_bytes(std::span(actual_ids))));
    for(unsigned row=0;row<rows;++row){
      std::array<std::int32_t,columns> order;std::iota(order.begin(),order.end(),0);
      std::stable_sort(order.begin(),order.end(),[&](auto a,auto b){return data[row*columns+a]>data[row*columns+b];});
      for(unsigned at=0;at<selected;++at){const auto i=row*selected+at;const auto expected=data[row*columns+order[at]];
        if(actual_ids[i]!=order[at] || actual[i]!=expected || neg[i]!=-expected)
          return hyle::Status::DataLoss("default CPU Graph rowwise TopK/GatherElements/Neg differs from independent oracle");}
    }
    std::printf("CPU default Graph T3/E5/K2 replay=%u TopK->device I32 IDs->GatherElements(unchecked)->Neg rows/IDs/value oracle PASS\n",replay);
  }
  std::printf("graph steps=%zu regions=%zu nodes=%zu\n",compiled.report.step_count(),compiled.report.region_count(),logical.node_count());
  return hyle::Status::Ok();
}
int main(){auto status=run();if(status.ok())return 0;char text[512]{};status.ToString(text,sizeof(text));std::fprintf(stderr,"%s\n",text);return 1;}
