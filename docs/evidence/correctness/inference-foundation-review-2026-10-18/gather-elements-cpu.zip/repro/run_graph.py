from pathlib import Path
import importlib.util,json,subprocess,time,os,hashlib
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cached_cpu',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(cpu)
TORCH=Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
env=cpu.ENV.copy();env['PATH']=str(TORCH/'lib')+os.pathsep+env['PATH']
records=[]
def run(tag,command):
 command=list(map(str,command));start=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=120)
 (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start));(OUT/'graph-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-1500:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
flags=cpu.hyle_flags(dict(cpu.PINS['mixed'],folder=Path('mixed')))+['/I'+str(ROOT)]
obj=OUT/'graph.obj';run('graph-compile',[cpu.CL,*flags,OUT/'graph_probe.cc','/Fo'+str(obj)])
libs=[cpu.BASE/'bin'/name for name in ['hyle_graph_route_cpu.lib','hyle_graph_provider_onednn.lib','hyle_graph.lib','hyle_compute_route_cpu.lib','hyle_compute_provider_native.lib','hyle_compute_provider_onednn.lib','dnnl.lib']]+cpu.common_libs()+[TORCH/'lib'/name for name in ['torch.lib','torch_cpu.lib','c10.lib']]
exe=OUT/'graph.exe'
selector=ROOT/'.scratch/mtp-gdn-2026-10-18/mixed/selector-baseline.obj'
native=ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj'
run('graph-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),obj,OUT/'aten.obj',selector,native,*libs,*cpu.SYSTEM])
run('graph',[exe])
paths=[ROOT/'src/compute_provider_native/aten_cpu_provider.cc',OUT/'aten.obj',selector,native,*libs]
(OUT/'graph-identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
