from pathlib import Path
import importlib.util,json,subprocess,time,hashlib,os
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cached_cpu',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(cpu)
TORCH=Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
flags=cpu.hyle_flags(dict(cpu.PINS['mixed'],folder=Path('mixed')))+['/I'+str(ROOT),'/I'+str(ROOT/'src/compute_provider_native'),'/DHYLE_COMPUTE_TORCH_CPU=1','/external:I'+str(TORCH/'include'),'/external:I'+str(TORCH/'include/torch/csrc/api/include')]
env=cpu.ENV.copy();env['PATH']=str(TORCH/'lib')+os.pathsep+env['PATH']
records=[]
def run(tag,command,reject=False):
    command=list(map(str,command));start=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=180)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,expected_nonzero=reject,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-6500:],p.stderr.decode(errors='replace')[-1500:],flush=True)
    if (p.returncode!=0)!=reject:raise SystemExit(p.returncode or 2)
def compile(source,name):
    obj=OUT/(name+'.obj');run(name+'-compile',[cpu.CL,*flags,source,'/Fo'+str(obj)]);return obj
aten=compile(ROOT/'src/compute_provider_native/aten_cpu_provider.cc','aten')
tests=compile(ROOT/'tests/compute_provider_native/indexing_test.cc','tests')
libs=[cpu.BASE/'bin'/name for name in ['hyle_compute_route_cpu.lib','hyle_compute_provider_native.lib','hyle_compute_provider_onednn.lib','dnnl.lib']]+cpu.common_libs()+[TORCH/'lib'/name for name in ['torch.lib','torch_cpu.lib','c10.lib']]+[cpu.BASE/'lib/gtest.lib',cpu.BASE/'lib/gtest_main.lib']
exe=OUT/'tests.exe'
run('tests-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),tests,aten,*libs,*cpu.SYSTEM])
before=compile(OUT/'aten.before.cc','aten-before')
baseline=OUT/'before.exe'
run('before-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(baseline),tests,before,*libs,*cpu.SYSTEM])
run('before-tests',[baseline,'--gtest_filter=AtenCpuIndexing.DefaultRouteAdmitsGatherElementsForAllThreeStorageTypes'],reject=True)
run('tests',[exe])
paths=[ROOT/p for p in ['src/compute_provider_native/aten_cpu_provider.cc','tests/compute_provider_native/indexing_test.cc','include/hyle/compute/model_ops.h','tests/compute_models/gather_elements_fixture.h']]+libs+[TORCH/'lib/torch_cpu.dll']
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
