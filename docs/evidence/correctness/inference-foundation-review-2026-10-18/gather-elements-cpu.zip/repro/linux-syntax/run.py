from pathlib import Path
import subprocess,json,time,hashlib
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
SOURCE='/mnt/c/public/project-hyle/hyle'
TORCH='/root/.cache/hyle/dependencies/v1/sdks/torch-cpu/Linux-8dea5bcfed4b53ca0f6852517bea4b4d1f3ff1cc0c21da662e834d34af1ec824/libtorch'
GTEST='/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
WSL=['wsl.exe','-d','Ubuntu-24.04','--'];records=[]
def run(tag,args,stdin=None):
    command=WSL+args;start=time.monotonic();p=subprocess.run(command,cwd=ROOT,input=stdin,capture_output=True,timeout=180)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,stdin=stdin.decode()if stdin else None,exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-1000:],p.stderr.decode(errors='replace')[-2500:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
    return p.stdout.decode(errors='replace')
run('toolchain',['g++-14','--version'])
config=run('torch-config',['python3','-c','from pathlib import Path;print(Path('+repr(TORCH+'/share/cmake/Torch/TorchConfig.cmake')+').read_text())'])
macros=run('abi-macros',['g++-14','-std=c++23','-dM','-E','-x','c++','-include','string','-'],b'')
abi=[line for line in macros.splitlines()if line.startswith('#define _GLIBCXX_USE_CXX11_ABI ')]
(OUT/'abi.txt').write_text('\n'.join(abi)+'\nTorchConfig.cmake has no explicit _GLIBCXX_USE_CXX11_ABI override: '+str('_GLIBCXX_USE_CXX11_ABI' not in config)+'\n')
flags=['g++-14','-std=c++23','-fsyntax-only','-Wall','-Wextra','-Wpedantic','-DHYLE_STATIC','-I'+SOURCE+'/include','-I'+SOURCE+'/src/compute','-I'+SOURCE+'/src/compute_provider_native']
run('public-model-ops-header',flags+['-x','c++','-'],b'#include "hyle/compute/model_ops.h"\n')
run('canonical-operation-test',flags+['-isystem',GTEST,SOURCE+'/tests/compute_ops/operation_test.cc'])
run('current-aten-provider',flags+['-DHYLE_COMPUTE_TORCH_CPU=1','-isystem',TORCH+'/include','-isystem',TORCH+'/include/torch/csrc/api/include',SOURCE+'/src/compute_provider_native/aten_cpu_provider.cc'])
paths=[ROOT/p for p in ['include/hyle/compute/model_ops.h','tests/compute_ops/operation_test.cc','src/compute_provider_native/aten_cpu_provider.cc']]
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
(OUT/'summary.txt').write_text('Ubuntu-24.04 x86_64 g++-14 14.2.0: current public model_ops.h self-contained, complete canonical compute_ops operation_test.cc and current ATen provider TU all syntax-only PASS. Existing Linux torch-cpu and gtest headers; Windows authoritative sources consumed directly through /mnt/c. No objects, link, Linux numerical execution, build directory, SDK rebuild, source copy or dependency installation. ABI facts: abi.txt. This is Linux host syntax/compilation evidence only.\n')
