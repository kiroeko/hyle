from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache

env = windows_compiler_environment(read_cache(ROOT / '.scratch/build-compute-v2-dev'))
env['VSLANG'] = '1033'
env.update(OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def execute(tag, command, timeout=180, additions=()):
    previous = sum(r['tag'] == tag or r['tag'].startswith(tag + '-attempt') for r in records)
    if previous:
        tag += '-attempt' + str(previous + 1)
    active = env.copy()
    active['PATH'] = os.pathsep.join([*map(str, additions), active['PATH']])
    start = time.monotonic()
    run = subprocess.run(command, cwd=ROOT, env=active, capture_output=True, timeout=timeout)
    (OUT / (tag + '.stdout.log')).write_bytes(run.stdout)
    (OUT / (tag + '.stderr.log')).write_bytes(run.stderr)
    records.append(dict(tag=tag, command=command, cwd=str(ROOT), exit=run.returncode,
                        seconds=time.monotonic() - start, path_additions=list(map(str, additions))))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(tag, run.returncode, round(records[-1]['seconds'], 3), flush=True)
    if run.returncode:
        print(run.stdout.decode(errors='replace')[-7000:])
        print(run.stderr.decode(errors='replace')[-3000:])
        raise SystemExit(run.returncode)
    return run


def main(kind, action):
    base = ROOT / '.scratch/inference-foundation-review-2026-10-18'
    command_file = base / ('deepseek-sparse-prefix/commands.json' if kind == 'cpu' else
                           'row-cache-paged-reader/cuda-test-commands.json')
    original = json.loads(command_file.read_text())
    source = ROOT / 'tests/compute_state/public_state_consumer.cc'
    obj = OUT / (kind + '-consumer.obj')
    exe = OUT / (kind + '-consumer.exe')
    if action == 'build':
        old_compile = next(r['command'] for r in reversed(original) if 'compile' in r['tag'])
        command = [x for x in old_compile if not x.lower().endswith(('.cc', '.cpp')) and not x.startswith('/Fo')]
        if kind == 'cpu':
            command += ['/DHYLE_COMPUTE_CPU=1']
        command.extend(['/I' + str(ROOT), str(source), '/Fo' + str(obj)])
        execute(kind + '-compile', command)
        old_link = next(r['command'] for r in reversed(original) if 'link' in r['tag'])
        old_test = 'consumer.obj' if kind == 'cpu' else 'cuda-test.obj'
        command = []
        for x in old_link:
            if x.startswith('/OUT:') or x.startswith('/MAP:'):
                continue
            if Path(x).name == old_test:
                command.append(str(obj))
            else:
                command.append(x)
        command.extend(['/OUT:' + str(exe), '/MAP:' + str(OUT / (kind + '.map'))])
        missing = [x for x in command if len(x) > 1 and x[1] == ':' and
                   Path(x).suffix.lower() in ('.obj', '.lib') and not Path(x).exists()]
        if missing:
            raise RuntimeError('Missing retained closure: ' + repr(missing))
        execute(kind + '-link', command)
    elif action == 'test':
        paths = [ROOT / '.scratch/build-compute-v2-dev/bin']
        for line in next(r['command'] for r in reversed(original) if 'link' in r['tag']):
            p = Path(line)
            if p.suffix == '.lib' and ('torch' in p.parts or 'libtorch' in p.parts):
                paths.append(p.parent)
        paths += [Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64')]
        result = execute(kind + '-run', [str(exe), '--kda-prefix'], timeout=180, additions=paths)
        assert result.stdout.count(b'continuation PASS') == 8, 'Expected all eight KDA branch checks'
    else:
        raise ValueError(action)


if __name__ == '__main__':
    main(*sys.argv[1:])
