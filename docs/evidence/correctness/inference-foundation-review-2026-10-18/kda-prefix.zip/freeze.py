from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


sources = [
    'tests/compute_state/public_state_consumer.cc',
    'tests/compute_state/kda_prefix_consumer.h',
    'tests/compute_state/mtp_prefix_consumer.h',
    'tests/compute_models/gdn_snapshot_fixture.h',
    'tests/compute_models/d5_kda_full_fragments.h',
    'tests/compute_models/d5_qwen38_24t_semantic_fragments.h',
    'include/hyle/compute/operation.h',
    'include/hyle/compute/model_ops.h',
    'src/compute_ops/operation.cc',
    'src/compute_provider_ggml/ggml_cpu_provider.cc',
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'src/compute_provider_ggml_vulkan/region.cc',
    'src/compute_provider_ggml_metal/native_program.cc',
    'src/compute_route_apple/apple_recurrent.cc',
]
for relative in sources:
    destination = OUT / 'source' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((ROOT / relative).read_bytes())
(OUT / 'public_state_consumer.before.cc').write_bytes(subprocess.check_output(
    ['git', 'show', 'HEAD:tests/compute_state/public_state_consumer.cc'], cwd=ROOT))
(OUT / 'candidate.diff').write_bytes(subprocess.check_output(
    ['git', 'diff', '--', 'tests/compute_state/public_state_consumer.cc'], cwd=ROOT))
save('source-identities.json', [identity(ROOT / p) for p in sources])

# The successful final CPU run was concurrent with the CUDA compilation. Their
# aggregate commands.json rewrites raced; retain the actual terminal evidence
# explicitly instead of inventing an exact subprocess duration.
records = json.loads((OUT / 'commands.json').read_text())
if not any(r['tag'] == 'cpu-run-attempt4' for r in records):
    records.append(dict(tag='cpu-run-attempt4',
        command=[str(OUT / 'cpu-consumer.exe'), '--kda-prefix'], cwd=str(ROOT), exit=0,
        seconds_rounded_from_terminal_stdout=0.391,
        provenance='Recovered from actual exec terminal result; raw stdout/stderr files retained. '
                   'Only the aggregate JSON entry was lost to concurrent harness writes; no additional run.',
        stdout='cpu-run-attempt4.stdout.log', stderr='cpu-run-attempt4.stderr.log'))
    save('commands.json', records)

selected_inputs = {}
for kind in ['cpu', 'cuda']:
    final = next(r for r in reversed(records) if r['tag'].startswith(kind + '-link'))
    objects = [Path(x) for x in final['command'] if len(x) > 1 and x[1] == ':' and
               Path(x).suffix.lower() == '.obj']
    selected_inputs[kind] = [identity(p) for p in objects]
save('linked-object-identities.json', selected_inputs)
save('maps-identities.json', [identity(OUT / (k + '.map')) for k in ['cpu', 'cuda']])
with (OUT / 'map-symbol-excerpts.txt').open('w', encoding='utf-8') as stream:
    for kind in ['cpu', 'cuda']:
        stream.write(kind + '\n')
        for line in (OUT / (kind + '.map')).read_text(errors='replace').splitlines():
            if re.search(r'gated_delta_net|\?create_context@(?:cpu|cuda)@', line):
                stream.write(line + '\n')

save('source-review.json', {
    'selected_shapes': {
        'Qwen': 'D128, F32 recurrent gates/state; value heads16/48/128; key heads16 or explicitly expanded official heads.',
        'KDA': 'Kimi H96/GLM Flash H64, D128, F32 per-key-channel decay and scalar beta; projection storage separately BF16/Q8.'},
    'contracts': [
        ['include/hyle/compute/operation.h:425', 'Pure six-input/two-output GDN, cyclic h%Hk, F32 state. K1 rank4; K>1 chronological tail [B,K,Hv,Dv,Dk], excludes S0.'],
        ['src/compute_ops/operation.cc:170', 'Scalar/per-channel log decay admitted; matching F16/BF16/F32 QKV generic schema, F32 gates/state.'],
        ['src/compute_ops/operation.cc:1610', 'K0/K>T/shape byte overflow rejected atomically.'],
        ['include/hyle/compute/model_ops.h:631', 'CausalConv1d consumes an explicit window, no hidden state; accepted k keeps rows k..k+K-2.'],
        ['include/hyle/compute/model_ops.h:679', 'Raw-gate recurrent is F32 B1 T>0 D128; per-token a/b, broadcast negative_a/dt_bias, snapshots forwarded.'],
        ['tests/compute_models/d5_qwen38_24t_semantic_fragments.h:550', 'Official contiguous heads explicitly Gather-expand Q/K; GGUF reordered cyclic heads retained. Not a new head-mapping defect.'],
        ['tests/compute_models/d5_kda_full_fragments.h:77', 'Actual KDA model fragment H96/H64/D128; -5 sigmoid(alpha*(raw+dt)), beta sigmoid, conv and normalized Q/K. Its existing complete fragment is eight sequential T1 replays.']],
    'snapshot_mapping': {
        'cpu': 'ggml_cpu_provider.cc:1237/2321: cold host indices (K-1-k)*B+b, native GET_ROWS rearranges payload.',
        'cuda': 'tensor_program.cc:874: same cold device constant and native GET_ROWS, no host payload readback.',
        'vulkan': 'region.cc:1296: same [K,B] newest-first native slots to [B,K] oldest-first via cold index upload/GET_ROWS.',
        'apple': 'native_program.cc:385: same mapping; packed native output and F32 score/state output slices; checked native completion.'},
    'existing_evidence_not_repeated': [
        'docs/evidence/correctness/mtp-2026-10-18/README.md: B2/T5/K1,3,5 snapshots/rebind/input-state immutability; four-backend public scalar-GDN accept0..4 + conv/KV and CPU/CUDA transfers.',
        '.scratch/inference-feature-completion-2026-10-18/fusion/summary.json: per-channel KDA B1/T5/D128 K3, actual retained S4 -> token5; CPU/CUDA Graph components, Vulkan public Direct, Metal native component.'],
    'resource_and_failure_boundaries': [
        'Selected recurrent math is already F32; no necessary recurrent BF16->F32 cast was found in these lowerers. Projection/weight conversions remain separate.',
        'K>1 necessarily materializes K full states and currently also device-reorders reverse native slots. K1 retains its old native payload path, no snapshot indices.',
        'apple_recurrent.cc:75-108: non-row-contiguous inputs may require CONT and checked ready boundary; every run owns a new packed output. These are concrete bridge/allocation costs, not demonstrated performance bugs.',
        'native_program.cc:250: Metal T<=32767 is necessary for existing short token loop. Larger prefill requires caller chunking; no automatic recurrent chunking is claimed.',
        'CPU native copies const input state to output/scratch; CUDA uses const curr_state and separate state output. Public provider aliases remain unadvertised.',
        'Apple checked native sync and whole-Job native-use retirement remain unchanged. New consumer covers cancelled StateStore draft nonpublication, not injected hardware failure.'],
    'not_a_product_fix': True,
    'remaining_evidence': 'No full weight projections, H96 second model, Apple/Vulkan new public H64 state journey, a single fused whole-chain graph, large prefill scheduling, capture/allocation or throughput were newly tested.'
})

final_runs = {}
for kind, tag in [('cpu', 'cpu-run-attempt4'), ('cuda', 'cuda-run-attempt2')]:
    stdout = (OUT / (tag + '.stdout.log')).read_text()
    checks = [line for line in stdout.splitlines() if line.startswith('KDA ')]
    assert len(checks) == 8 and all(line.endswith('continuation PASS') for line in checks)
    final_runs[kind] = dict(exit=0, stdout=tag + '.stdout.log', stderr=tag + '.stderr.log', checks=checks)
save('summary.json', {
    'purpose': 'Public selected-shape KDA/conv accepted-prefix continuation evidence; no product repair and no performance measurement.',
    'geometry': 'GLM Flash post-projection F32 B1/H64/D128, conv K4, 3-token verification, K3 chronological snapshots, accept k=0..3 then one token.',
    'route': 'Real default graph::cpu::create_context and graph::cuda::create_context, full cached rosters, Direct and per-operation public Graph execution.',
    'oracle': 'Same immutable base executed token-by-token through independent public branch. Compare every state/scores/history element, original absolute3e-6 budget, actual device/CPU output feedback. Existing FP64 KDA fixtures are cited, not rerun or falsely claimed as the new full-matrix oracle.',
    'common_state': 'KDA F32 state, conv history and uint64 cursor finalized/published together for both accepted prefix and continuation. Old base bytes remain exactly equal; cancelled speculative draft cannot publish.',
    'scope': 'Projection-boundary QKV and activated KDA gates are test inputs. Actual conv, SiLU, L2 normalization, GDN KDA recurrence run through public APIs; no host payload supplies a continued state. Multiple public operations/launches, not one fused model graph.',
    'runs': final_runs,
    'hardware': {'cpu_reported': '13th Gen Intel Core i9-13900K; Win32_Processor.NumberOfLogicalProcessors read1 in this environment',
        'gpu': 'NVIDIA GeForce RTX4070, UUID GPU-e7376560-6f5d-ec19-6ee4-3dd3a2c81ef8, driver617.14, CC8.9/12281MiB from actual runtime',
        'toolchain': 'MSVC14.50.35717, current host TU /O2 /MD /W4 /WX /std:c++latest; cached CUDA13.3/native ggml456172. CPU mixed pin baseline native selector; no FFA/AVX2 matrix repeated.'},
    'allocation_boundaries': 'Fixture LeasePool root128MiB, StateStore backing budget256MiB to include shared root capacity plus owned cursor metadata. No peak/zero-allocation/capture claim.',
    'preserved_mechanical_failures': [
        'First CPU executable inherited a source-specific compile line lacking HYLE_COMPUTE_CPU; returned0 with no checks. Excluded from functional success. Added macro and mandatory eight-check runner assertion.',
        'First instantiated CUDA and CPU builds rejected unsigned dynamic dimensions narrowing into int64. Test-only explicit signed row count/constants fixed; original diagnostics retained.',
        'First active CPU fixture hit StateStore snapshot capacity: the entire128MiB root plus cursor exceeded default128MiB backing limit. Explicit256MiB fixture budget fixed, no product change.',
        'Final CPU run raw log/exit retained; aggregate commands entry was recovered from actual terminal after concurrent run/build JSON writes raced. No new run invented.'],
    'no_additional_product_defect_found': True,
    'limitations': 'No native failure injection, complete model projections/FFN/head, sampler/acceptance policy, whole-chain fusion, other H96/Apple/Vulkan new journey, long-context/batched accept lengths, timing or full SDK/default roster rebuild.',
})
products = [OUT / (kind + '-consumer' + suffix) for kind in ['cpu', 'cuda']
            for suffix in ['.exe', '.obj', '.lib', '.exp']]
save('cleanup-candidates.json', dict(delete=[identity(p) for p in products], retain=[],
    counts={'delete': len(products), 'logical_bytes': sum(p.stat().st_size for p in products)},
    policy='Candidates only; do not delete without root test.ps1 preflight. Keep all source, logs, map data, commands, SDK and shared caches.'))

with zipfile.ZipFile(OUT / 'source-results.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(OUT.rglob('*'), key=lambda p: p.relative_to(OUT).as_posix()):
        if path.is_file() and path.suffix not in ['.zip', '.exe', '.obj', '.lib', '.exp', '.map', '.pyc']:
            archive.write(path, path.relative_to(OUT).as_posix())
print(json.dumps(identity(OUT / 'source-results.zip')))
