from pathlib import Path
import difflib,hashlib,json

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,j):(OUT/n).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')

link=read(OUT/'current-link.json');commands=read(OUT/'commands.json')
last_link=next(x for x in reversed(commands) if x['tag']=='current-link' and x['exit']==0)
assert last_link['command']==link['command']
assert commands[-1]['tag']=='current-run' and commands[-1]['exit']==0
tests=read(OUT/'current-results.json');control=read(OUT/'control-results.json')
assert tests['tests']==6 and tests['failures']==0 and control['tests']==4 and control['failures']==2

records=[read(p) for p in sorted(OUT.glob('src--*.cc.json'))+sorted(OUT.glob('tests--*.cc.json'))]
assert len(records)==15
for row in records:
 assert row['exit']==0 and ident(row['source']['path'])==row['source'] and ident(row['object']['path'])==row['object']
 assert link['command'].count(row['object']['path'])==1
for row in link['objects']:assert ident(row['path'])==row
# Correct the source-index bookkeeping to match the already recorded exact
# command. This does not change the executable or repeat a completed test.
ops=read(OUT.parent/'strided-reshape/operation-identity.json')
assert ops['object']['path'] in link['command']
link['selected_sources']['src/compute_ops/operation.cc']=ops['object']['path']
save('current-link.json',link)

text=(OUT/'current.map').read_text(errors='replace')
owners={}
for row in records:
 name=Path(row['object']['path']).name
 hits=[x for x in text.splitlines() if x.rstrip().endswith(name)]
 assert hits,name
 owners[name]=hits[:4]
native=[x for x in text.splitlines() if 'ggml_backend_vk_device_supports_op' in x or 'ggml_backend_vk_init' in x]
assert native and all('native-host' in x for x in native)
save('selected-map-owners.json',dict(fresh=owners,retained_native=native))

files=[Path(r['source']['path']) for r in records]
files += [ROOT/p for p in ['include/hyle/graph/detail/region_access.h','include/hyle/compute/detail/vulkan_plan.h',
 'src/compute_route_vulkan/vulkan_carrier.h','src/compute_route_vulkan/vulkan_tensor.h',
 'src/graph/execution_source_internal.h','tests/graph_route_vulkan/CMakeLists.txt',
 'docs/architecture/compute-design.md','docs/developer/current-work.md','docs/user/batch-attention.md']]
save('final-source-identities.json',[ident(p) for p in files])
diff=[]
for p in files:
 old=OUT/'before'/p.relative_to(ROOT)
 if old.is_file():
  diff.extend(difflib.unified_diff(old.read_text(encoding='utf-8-sig').splitlines(True),
   p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+p.relative_to(ROOT).as_posix(),
   tofile='current/'+p.relative_to(ROOT).as_posix()))
(OUT/'final-source.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
summary=dict(status='vulkan-ready-row-region-projection-and-cold-metadata-wiring-implemented',
 tests=dict(passed=6,total=6,new_vulkan=3,existing_vulkan=1,existing_cpu_ready_pending=2),
 original_control=dict(total=4,failed=2,reason='old core requires ordinary singleton at first typed preparation',original_expert_control_passed=True),
 source_files=len(files),fresh_cpp_translation_units=15,native_sdk_shader_rebuild=False,
 selected_owners=ident(OUT/'selected-map-owners.json'),
 changes=[
  'One selected-node access/configuration path for ordinary prepared operations and native regions; old configure_operation name removed.',
  'Private v3 native capability preserves physical-port inspection and adds exact logical-node inspection/configuration; pending is a separate opt-in, default false.',
  'Actual Vulkan lowerer/final dispatches prove checked indexed bank reads; sparse cold facts map original node to Graph boundary port, including constant-filter remapping.',
  'Original slot copies only cold layout booleans; empty permission requires actual configured padded checked computation.',
  'Owned row metadata uses original lane Source cold transfer, charged scratch, and publish only after successful retirement; unchanged prepared version skips upload.',
 ],
 verified_scope=[
  'FP8 depth512 padded Map -> Decode -> existing F32 Sink, real Vulkan kDevice bank and metadata, original shader and numeric budget.',
  'Actual fused/split artifacts, permuted pages, two slots, changed query grouping/page order in same slot, retained GraphOutput and exported lease.',
  'Unused page writer during nonempty read; all page writers during true-empty history; exact decoded BF16/mask and original FP64 Sink oracle.',
  'Extra bank Copy reader and private physical IDs publication rejected; no failed result publication.',
  'CPU existing FP8/FP4 ready and actual pending-copy typed consumers remain correct.',
 ],
 limits=[
  'No new whole-model, Apple/Linux runtime, throughput or total device-memory measurement.',
  'Vulkan projected row pending remains unimplemented; ready capability cannot grant pending permissions.',
  'Apple projected row Graph and Apple/Vulkan five-port paged scorer remain unfinished.',
  'Native cold metadata transfer has staging/control allocation and a wait per changed layout; no allocation-free or zero-copy claim.',
  'Original pending fixture needed its omitted explicit warm prepare_replay, and split fixture needed a distinct configured Source on the same actual Runtime. Product behavior was not relaxed.',
 ],
 goal='active; full model accuracy/performance and inherited eight-model/22-profile review remain')
save('summary.json',summary)
print(json.dumps(dict(passed=6,fresh_cpp=15,original_control_failed=2,source_files=len(files)),indent=2))
