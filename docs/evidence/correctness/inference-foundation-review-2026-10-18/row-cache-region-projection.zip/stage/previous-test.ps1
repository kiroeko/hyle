param([switch]$ReclaimAppleCrossRuntime)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/apple-cross-runtime'
$receipt = Get-Content -Raw -LiteralPath (Join-Path $stage 'archive-receipt.json') | ConvertFrom-Json
$archive = [IO.Path]::GetFullPath([string]$receipt.archive.path)
if (-not $archive.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Archive outside workspace' }
$item = Get-Item -LiteralPath $archive
$cursor = $item
while ($null -ne $cursor -and $cursor.FullName.Length -ge $workspace.Length) {
    if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse archive path' }
    if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
}
if ($item.Length -ne $receipt.archive.bytes -or (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.archive.sha256) { throw 'Archive identity differs' }
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
if (-not $ReclaimAppleCrossRuntime) { Write-Output "Verified archive; $($plan.files.Count) exact Air image/map files planned. Use -ReclaimAppleCrossRuntime to reclaim."; return }
$code = @'
from pathlib import Path
import hashlib,json,sys
p=json.loads(sys.stdin.buffer.read());root=Path(p['root'])
expected=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/cross-runtime')
assert root==expected and root.resolve()==expected and not root.is_symlink()
def check(row,removable=False):
 q=Path(row['path']);assert q.is_absolute() and q.is_relative_to(root)
 assert not q.is_symlink() and q.resolve().is_relative_to(root)
 for parent in q.parents:
  assert not parent.is_symlink()
  if parent==root:break
 if removable:assert q.parent==root and q.name in {'cross-runtime-test','cross-runtime-test.map'}
 assert q.is_file() and q.stat().st_size==row['bytes']
 assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256']
for row in p['files']:check(row,True)
for row in p['retain']:check(row)
for row in p['files']:Path(row['path']).unlink()
for row in p['retain']:check(row)
result=dict(archive_verified=True,host='Mac16,12 Air',files=len(p['files']),bytes=sum(r['bytes'] for r in p['files']),retained_objects=len(p['retain']),native_sdk_and_metallib_retained=True)
(root/'cleanup-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'@
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($code))
$remoteCommand = "python3 -c `"import base64;exec(base64.b64decode('$encoded'))`""
$payload = $plan | ConvertTo-Json -Depth 12 -Compress
$output = $payload | & ssh -o BatchMode=yes -o ConnectTimeout=8 kiro@172.22.10.198 $remoteCommand
if ($LASTEXITCODE -ne 0) { throw "Air cleanup failed: $LASTEXITCODE" }
$output | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $stage 'cleanup-result.json')
$output
