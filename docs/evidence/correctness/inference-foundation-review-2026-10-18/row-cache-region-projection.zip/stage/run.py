from pathlib import Path
import hashlib,json,os,subprocess,sys,time

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(name,j):(OUT/name).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

BASE=read(ARCH/'vulkan-attention-dtype-axes/matched-link-inputs.json')
LINK=next(r['command'] for r in reversed(read(ARCH/'vulkan-attention-dtype-axes/commands.json')) if r['tag']=='attention-tests-link' and r['exit']==0)
RECIPES={r['source']:r['command'] for r in read(ARCH/'native-ready-pages/windows/compile-plan.json')}
PADDED=ROOT/'.scratch/inference-foundation-review-2026-10-18/native-row-cache-padded/vulkan-commands.json'
PADDED_COMMAND=next(r['command'] for r in reversed(read(PADDED)) if r['tag']=='test-compile' and r['exit']==0)
TEST='tests/graph_route_vulkan/row_cache_projection_test.cc'
CONTROL='tests/compute_route_vulkan/row_cache_padded_test.cc'
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':LINK[0].replace('link.exe','cl.exe'),'CMAKE_C_COMPILER':LINK[0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in LINK if Path(x).suffix.lower()=='.lib' and Path(x).is_absolute()))+os.pathsep+env['PATH']
env.update(DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~',VSLANG='1033')

def run(tag,command,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';row=dict(tag=tag,command=list(map(str,command)),cwd=str(ROOT),stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
 rows.append(row);save('commands.json',rows);print('START',stem,flush=True)
 start=time.monotonic()
 with (OUT/row['stdout']).open('wb') as a,(OUT/row['stderr']).open('wb') as b:
  p=subprocess.Popen(row['command'],cwd=ROOT,env=env,stdout=a,stderr=b,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=p.pid;save('commands.json',rows);row['exit']=p.wait(timeout=timeout)
 row['seconds']=time.monotonic()-start;save('commands.json',rows)
 print('END',stem,row['exit'],flush=True)
 print((OUT/row['stdout']).read_text(errors='replace')[-6500:],flush=True)
 print((OUT/row['stderr']).read_text(errors='replace')[-4000:],flush=True)
 return row['exit']

def object_path(source):return OUT/(source.replace('/','--').replace('.cc','.obj'))

def compile_one(source):
 original=RECIPES.get(source,PADDED_COMMAND)
 args=[x for x in original if not x.lower().endswith(('.cc','.cpp')) and not x.lower().startswith(('/fo','/fd'))]
 if '/W4' not in args:args.append('/W4')
 if '/WX' not in args:args.append('/WX')
 args += [str(ROOT/source),'/Fo'+str(object_path(source))]
 before=ident(ROOT/source);code=run('compile-'+Path(source).stem,args)
 assert ident(ROOT/source)==before
 result=dict(source=before,command=args,exit=code)
 if code==0:result['object']=ident(object_path(source))
 save(source.replace('/','--')+'.json',result)
 return code

def link(control=False):
 selected=BASE['selected_sources'].copy()
 test_paths={v for k,v in selected.items() if k.startswith('tests/')}
 replacements={}
 # Both closures use the current already-compiled generic view mathematics.
 ops=read(ARCH/'strided-reshape/operation-identity.json')
 assert ident(ops['source']['path'])==ops['source'] and ident(ops['object']['path'])==ops['object']
 replacements[selected['src/compute_ops/operation.cc']]=ops['object']['path']
 selected['src/compute_ops/operation.cc']=ops['object']['path']
 if not control:
  for receipt in OUT.glob('src--*.cc.json'):
   row=read(receipt);assert row['exit']==0 and ident(row['source']['path'])==row['source'] and ident(row['object']['path'])==row['object']
   source=Path(row['source']['path']).relative_to(ROOT).as_posix();assert source in selected,source
   replacements[selected[source]]=row['object']['path'];selected[source]=row['object']['path']
 for row in BASE['objects']:
  if row['path'] not in replacements:assert ident(row['path'])==row
 objects=[replacements.get(x,x) for x in LINK if x.lower().endswith('.obj') and x not in test_paths]
 objects += [str(object_path(TEST)),str(object_path(CONTROL))]
 if not control:
  for source in ['tests/graph_batch/row_cache_graph_test.cc','tests/graph_batch/row_cache_pending_graph_test.cc']:
   path=object_path(source)
   if path.is_file():objects.append(str(path))
 assert len(objects)==len(set(objects))
 flags=[x for x in LINK[1:] if not x.lower().endswith(('.obj','.lib')) and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 libs=[x for x in LINK if x.lower().endswith('.lib')]
 name='control' if control else 'current'
 args=[LINK[0],*flags,*objects,*libs,'/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map')),'/IMPLIB:'+str(OUT/(name+'.lib'))]
 save(name+'-link.json',dict(command=args,replacements=replacements,objects=[ident(p) for p in objects],selected_sources=selected,libraries=BASE['libraries']))
 return run(name+'-link',args)

if __name__=='__main__':
 action=sys.argv[1]
 if action=='compile':
  for source in sys.argv[2:]:
   code=compile_one(source)
   if code:raise SystemExit(code)
 elif action in {'link','control-link'}:raise SystemExit(link(action=='control-link'))
 elif action in {'run','control-run'}:
  name='control' if action=='control-run' else 'current'
  filter='VulkanProjectedRowGraph.*:VulkanRowCachePadded.TypedFirstPrefillConsumesMaskAndEmptyHistoryHoldsAllWriters'
  if name=='current':filter += ':CpuPagedRowCacheGraph.*'
  raise SystemExit(run(name+'-run',[OUT/(name+'.exe'),'--gtest_filter='+filter,'--gtest_color=no','--gtest_output=json:'+str(OUT/(name+'-results.json'))]))
 else:raise ValueError(action)
