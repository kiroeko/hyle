param([switch]$ReclaimRowCacheRegionProjection)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/row-cache-region-projection'))
$receipt = Get-Content -Raw -LiteralPath (Join-Path $stage 'archive-receipt.json') | ConvertFrom-Json
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $cursor = $item
    while ($null -ne $cursor -and $cursor.FullName.Length -ge $workspace.Length) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Identity changed: $path" }
}
Assert-Identity $receipt.archive
foreach ($entry in $plan.files) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if ([IO.Path]::GetDirectoryName($path) -ne $stage -or [IO.Path]::GetExtension($path) -notin '.exe','.map','.exp','.lib') { throw "Unexpected cleanup target: $path" }
    Assert-Identity $entry
}
foreach ($entry in @($plan.retained_objects) + @($plan.retained_native)) { Assert-Identity $entry }
if (-not $ReclaimRowCacheRegionProjection) { Write-Output "Verified $($plan.files.Count) exact archived images/maps. Use -ReclaimRowCacheRegionProjection to reclaim."; return }
foreach ($entry in $plan.files) { Remove-Item -LiteralPath $entry.path -Force }
foreach ($entry in @($plan.retained_objects) + @($plan.retained_native)) { Assert-Identity $entry }
$result = [ordered]@{archive_verified=$true;files=$plan.files.Count;bytes=($plan.files | Measure-Object bytes -Sum).Sum;retained_objects=$plan.retained_objects.Count;retained_native=$plan.retained_native.Count;other_cache_retained=$true}
$result | ConvertTo-Json | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $stage 'cleanup-result.json')
$result | ConvertTo-Json
