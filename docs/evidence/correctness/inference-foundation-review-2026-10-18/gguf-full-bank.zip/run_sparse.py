from pathlib import Path
import importlib.util
p=Path('.scratch/inference-fusion-quantization-2026-10-18/gguf-full-bank/run.py').resolve();spec=importlib.util.spec_from_file_location('bank',p);b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
cfg=dict(b.r.cpu.PINS['mixed'],folder=Path('mixed'));flags=b.r.cpu.hyle_flags(cfg)+['/I'+str(b.ROOT)]
b.r.compile(b.OUT/'cpu_sparse.cc','cpu-sparse',b.r.cpu.CL,flags,b.r.cpu.ENV)
b.cpu_link([b.OUT/'cpu-sparse.obj'],'cpu-sparse',cfg)
b.r.run('cpu-sparse',[b.OUT/'cpu-sparse.exe'],b.r.cpu.ENV)
