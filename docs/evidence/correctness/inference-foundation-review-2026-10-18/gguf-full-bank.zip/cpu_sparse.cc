#include <windows.h>
#include <psapi.h>
#include <ggml.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <vector>
#include "tests/compute_models/d5_gguf_test_support.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/mem/buffer.h"
namespace c=hyle::compute;namespace m=hyle::mem;
struct SparseBank final:m::MemoryResource {
  std::size_t offset, bytes, committed=0;
  SparseBank(std::size_t o,std::size_t b):offset(o),bytes(b){}
  std::string_view name()const noexcept override{return "sparse-index-address-probe";}
  m::MemoryProperties properties()const noexcept override{return {.flags=m::MemoryProperty::kHostAccessible|m::MemoryProperty::kHostDeviceCoherent,.minimum_alignment=65536};}
  hyle::Result<m::ResourceAllocation> allocate(std::size_t n,std::size_t a) noexcept override {
    auto *p=VirtualAlloc(nullptr,n,MEM_RESERVE,PAGE_READWRITE);
    if(!p)return std::unexpected(hyle::Status::ResourceExhausted("reserve"));
    SYSTEM_INFO info{};GetSystemInfo(&info);const std::size_t page=info.dwPageSize;
    const auto begin=offset/page*page;const auto end=(offset+bytes+page-1)/page*page;committed=end-begin;
    if(!VirtualAlloc(static_cast<char*>(p)+begin,committed,MEM_COMMIT,PAGE_READWRITE)) {VirtualFree(p,0,MEM_RELEASE);return std::unexpected(hyle::Status::ResourceExhausted("commit"));}
    return m::ResourceAllocation{p,n,a};
  }
  void deallocate(m::ResourceAllocation a)noexcept override{VirtualFree(a.native_handle,0,MEM_RELEASE);}
  hyle::Result<m::ResourceHostMapping> map_host(void*p,std::size_t o,std::size_t,m::HostAccess)noexcept override{return m::ResourceHostMapping{static_cast<char*>(p)+o,nullptr};}
};
void check(hyle::Status s){if(!s.ok())throw std::runtime_error(std::string(s.message()));}
int main(){try{
  d5_gguf_test::QuantizerCleanup cleanup;
  constexpr std::int64_t e=512,n=2048,k=8192;constexpr auto format=c::GgufQuantizedType::kIq4Xs;
  const auto w=c::gguf_grouped_weight_description(format,c::DataType::kFloat32,e,n,k).value();
  const auto x=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,3>{1,2,k}).value();
  const auto ids=c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,2>{1,2}).value();
  const std::array desc{w,x,ids};const auto y=c::infer_single_output(c::model_ops::grouped_matmul(),desc).value();
  const auto rowdesc=c::gguf_weight_description(format,c::DataType::kFloat32,k,1).value();
  const auto packed=d5_gguf_test::pack(format,std::vector<float>(k,0.75F),1,k,*rowdesc.required_bytes());
  const auto expert_bytes=static_cast<std::size_t>(n)*packed.bytes.size(),offset=static_cast<std::size_t>(e-1)*expert_bytes;
  SparseBank resource(offset,expert_bytes);auto weight=m::Buffer::create(m::MemoryResourceRef(resource),*w.required_bytes(),256).value();
  std::vector<std::byte> payload(expert_bytes);for(std::int64_t col=0;col<n;++col)std::copy(packed.bytes.begin(),packed.bytes.end(),payload.begin()+static_cast<std::size_t>(col)*packed.bytes.size());
  check(weight.view().subview(offset,expert_bytes)->write(payload));
  auto activation=m::Buffer::create(m::system_resource(),*x.required_bytes(),64).value();
  auto index=m::Buffer::create(m::system_resource(),*ids.required_bytes(),64).value();
  const std::array<std::int32_t,2> selected{511,511};check(index.view().write(std::as_bytes(std::span(selected))));
  auto result=m::Buffer::create(m::system_resource(),*y.required_bytes(),64).value();
  auto context=c::Context::create(c::cpu::device(),c::ggml_cpu::provider()).value();auto queue=context.create_queue().value();
  const std::array views{c::ConstTensorView::create(w,weight.view()).value(),c::ConstTensorView::create(x,activation.view()).value(),c::ConstTensorView::create(ids,index.view()).value()};
  const auto output=c::TensorView::create(y,result.view()).value();
  auto plan=c::prepare(context,c::model_ops::grouped_matmul(),views,std::span(&output,1));if(!plan)throw std::runtime_error(std::string(plan.error().message()));
  auto run=plan->create_invocation().value();std::size_t checked=0;double maxerr=0;
  for(float v:{0.25F,0.5F}){
    const std::vector<float> a(2*k,v);check(activation.view().write(std::as_bytes(std::span(a))));
    auto done=run.submit(queue,views,std::span(&output,1));if(!done)throw std::runtime_error(std::string(done.error().message()));check(done->wait());
    std::vector<float> actual(2*n);check(result.view().read(std::as_writable_bytes(std::span(actual))));double expected=0;for(float z:packed.decoded)expected+=double(z)*v;
    for(float z:actual){const double err=std::abs(z-expected);maxerr=std::max(maxerr,err);if(err>std::abs(expected)*0.002+1e-5)throw std::runtime_error("oracle");++checked;}
  }
  std::printf("{\"reserved_bytes\":%zu,\"committed_bytes\":%zu,\"expert_offset\":%zu,\"checked\":%zu,\"max_abs\":%.17g,\"actual_sparse_host_only\":true}\n",*w.required_bytes(),resource.committed,offset,checked,maxerr);
  return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
