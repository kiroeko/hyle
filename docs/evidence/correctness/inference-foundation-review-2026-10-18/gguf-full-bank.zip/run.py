from pathlib import Path
import importlib.util,json,sys,subprocess,time
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/gguf-full-bank'
spec=importlib.util.spec_from_file_location('dense',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/dense-constants/run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.OUT=OUT;r.records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def gpu_build():
    data=(ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc').read_text()
    for codec in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
        assert data.count('return GGML_TYPE_'+codec+';')==1
        data=data.replace('return GGML_TYPE_'+codec+';','return GGML_TYPE_COUNT; // Validation-only: cached native lacks this unrelated IQ1 codec.')
    p=OUT/'tensor.probe.cc';p.write_bytes(data.encode())
    flags=r.cuda.flags+['/I'+str(ROOT)]
    r.compile(p,'cuda-tensor',r.cuda.cl,flags,r.cuda.env)
    r.compile('tests/compute_provider_ggml_cuda/tensor_test.cc','cuda-tests',r.cuda.cl,flags,r.cuda.env)
    ge=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements'
    objects=[OUT/'cuda-tensor.obj',OUT/'cuda-tests.obj',ge/'provider.obj',ge/'region.obj',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices/guard.obj',ROOT/'.scratch/mtp-completion/operation.obj',r.cuda.OLD/'ggml-cuda.strict.obj']
    r.run('cuda-link',[r.cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/'cuda-tests.exe'),'/MAP:'+str(OUT/'cuda-tests.map'),*objects,*r.cuda.libs,r.cuda.BASE/'lib/gtest_main.lib',r.cuda.BASE/'lib/gtest.lib',*r.cuda.system],r.cuda.env)
def gpu_test():
    r.run('cuda-info',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.free','--format=csv'],r.cuda.env)
    r.run('cuda-tests',[OUT/'cuda-tests.exe','--gtest_filter=GgmlCudaTensor.QuantizedGroupedBanksKeepNativeBlockCapacity:GgmlCudaTensor.FullIq4BankReadsLastExpertBeyondFourGiB:GgmlCudaTensor.NativeQ8GroupedExpertsUseExactExpertIds:GgmlCudaTensor.DenseBfloatGroupedExpertsUseNativeMulMatIdAndReplay:GgmlCudaTensor.CheckedExpertIdsKeepOutputAndAllowRecreatedInvocationRetry','--gtest_color=no'],r.cuda.env)
def cpu_build():
    cfg=dict(r.cpu.PINS['mixed'],folder=Path('mixed'));flags=r.cpu.hyle_flags(cfg)+['/I'+str(ROOT)]
    r.compile('src/compute_provider_ggml/ggml_cpu_provider.cc','cpu-provider',r.cpu.CL,flags,r.cpu.ENV)
    r.compile('tests/compute_provider_ggml/cpu_provider_test.cc','cpu-tests',r.cpu.CL,flags,r.cpu.ENV)
    cpu_link([OUT/'cpu-tests.obj'],'cpu-tests',cfg)
def cpu_link(extra,stem,cfg=None):
    cfg=cfg or dict(r.cpu.PINS['mixed'],folder=Path('mixed'))
    c=r.cpu; cache=ROOT/'.scratch/mtp-gdn-2026-10-18';mla=ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla';generic=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla'
    objects=[OUT/'cpu-provider.obj',*extra,mla/'native-batch.obj',cache/'ffa4/operation.obj',cache/'mixed/selector-baseline.obj',cache/'mixed/allocator.obj',ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj',*[generic/(x+'.obj') for x in ['batch-layout','batch-execution','paged-arena']]]
    r.run(stem+'-link',[c.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/(stem+'.exe')),'/MAP:'+str(OUT/(stem+'.map')),*objects,*c.common_libs(cfg),c.BASE/'lib/gtest_main.lib',c.BASE/'lib/gtest.lib',*c.SYSTEM],c.ENV)
def cpu_test():
    r.run('cpu-tests',[OUT/'cpu-tests.exe','--gtest_filter=GgmlCpuProvider.QuantizedGroupedBanksKeepNativeBlockCapacity:GgmlCpuProvider.NativeQ8GroupedExpertsUseExactExpertIds:GgmlCpuProvider.DenseBfloatGroupedExpertsUseNativeMulMatIdAndReplay','--gtest_color=no'],r.cpu.ENV)
if __name__=='__main__':{'gpu-build':gpu_build,'gpu-test':gpu_test,'cpu-build':cpu_build,'cpu-test':cpu_test}[sys.argv[1]]()
