#include "apple_row_cache_indexer.h"
#include <algorithm>
#include <limits>
#include <vector>
#include <mlx/fast.h>
#include <mlx/ops.h>
#include "apple_checks.h"
namespace hyle::compute::apple::detail {
namespace mx=mlx::core;
Result<mx::array> row_cache_indexer_scores_matmul(std::span<const mx::array> inputs,mx::Stream s) {
  const int tokens=inputs[0].shape(0), rows=inputs[1].shape(0);
  auto begin=mx::slice(inputs[3],{0,0},{tokens,1},s);
  auto end=mx::slice(inputs[3],{0,1},{tokens,2},s);
  auto valid=mx::logical_and(mx::greater_equal(begin,mx::array(0),s),
      mx::logical_and(mx::less_equal(begin,end,s),mx::less_equal(end,mx::array(rows),s),s),s);
  auto all_valid=mx::all(valid,false,s);
  auto status=mx::where(all_valid,mx::array(0),mx::array(kIndexOutOfRange),s);
  if(!tokens || !rows)
    return with_device_status(mx::zeros({tokens,rows},mx::float32,s),std::move(status),s);
  // Decode a bounded union of referenced rows, shared by all query heads.
  // The scalar is a real dependency on complete GPU range validation; even
  // another query's otherwise legal row must not be read after a failure.
  static const auto decoder=mx::fast::metal_kernel("hyle_row_fp4_indexer_keys",
      {"bank","ranges","all_valid","columns"},{"keys"},R"METAL(
    const uint lane=thread_index_in_threadgroup;
    const uint offset=threadgroup_position_in_grid.x;
    const ulong row=columns[offset];
    bool referenced=false;
    if(all_valid)for(int t=0;t<ranges_shape[0];++t) {
      const int begin=ranges[t*ranges_strides[0]], end=ranges[t*ranges_strides[0]+ranges_strides[1]];
      if(row>=ulong(begin) && row<ulong(end)){referenced=true;break;}
    }
    if(!referenced){keys[offset*128+lane]=0;return;}
    const uint packed=bank[row*bank_strides[0]+(lane/2)*bank_strides[1]];
    const uint code=(packed>>((lane&1)*4))&15;
    const uint scale=bank[row*bank_strides[0]+(64+lane/32)*bank_strides[1]];
    keys[offset*128+lane]=hyle_key(code,scale);
  )METAL",R"METAL(
    inline uint hyle_key(uint code,uint scale) {
      const uint mantissas[8]={0,1,2,3,4,6,8,12};
      const uint magnitude=mantissas[code&7], sign=(code&8)<<12;
      if(scale==255)return sign|0x7fc0;
      if(!magnitude)return sign;
      const int power=int(scale)-128, top=31-clz(magnitude), exponent=top+power;
      if(exponent>127)return sign|0x7f80;
      if(exponent>=-126)return sign|(uint(exponent+127)<<7)|((magnitude<<uint(7-top))&127);
      const int shift=power+133;
      uint value=0;
      if(shift>=0)value=magnitude<<uint(shift);
      else if(shift>-32) {
        const uint right=uint(-shift), high=magnitude>>right;
        const uint low=magnitude&((1u<<right)-1), halfway=1u<<(right-1);
        value=high+uint(low>halfway || (low==halfway && (high&1)));
      }
      return sign|value;
    }
  )METAL",false,false,mx::CompileOptions{});
  // Keep the original explicit BF16 product and sequential F32 head sum.
  // Only the dot is delegated to MLX's mature BF16/F32-accumulator matmul.
  static const auto finish=mx::fast::metal_kernel("hyle_row_fp4_indexer_reduce",
      {"dots","weights","ranges","columns"},{"scores"},R"METAL(
    const ulong pair=ulong(thread_position_in_grid.y)*GRID_X+thread_position_in_grid.x;
    const ulong width=columns_shape[0], tokens=weights_shape[0];
    if(pair>=tokens*width)return;
    const ulong t=pair/width, k=pair%width, row=columns[k];
    const int begin=ranges[t*ranges_strides[0]], end=ranges[t*ranges_strides[0]+ranges_strides[1]];
    if(row<ulong(begin) || row>=ulong(end)){scores[pair]=-INFINITY;return;}
    float total=0.f;
    for(uint h=0;h<64;++h) {
      const float dot=as_type<float>(uint(dots[t*dots_strides[0]+h*dots_strides[1]+k*dots_strides[2]])<<16);
      const float positive=isnan(dot)?dot:(dot>0.f?dot:0.f);
      const float weight=as_type<float>(uint(weights[t*weights_strides[0]+h*weights_strides[1]])<<16);
      total=total+hyle_bfloat(positive*weight);
    }
    scores[pair]=hyle_bfloat(total);
  )METAL",R"METAL(
    #pragma clang fp contract(off)
    inline float hyle_bfloat(float x) {
      uint bits=as_type<uint>(x);
      if((bits&0x7fffffff)>0x7f800000)return as_type<float>((bits&0xffff0000)|0x00400000);
      return as_type<float>((bits+0x7fff+((bits>>16)&1))&0xffff0000);
    }
  )METAL",false,false,mx::CompileOptions{});
  constexpr int tile_rows=256;
  auto query=inputs[0];
  const bool flatten=tokens<=std::numeric_limits<int>::max()/64;
  if(flatten)query=mx::reshape(query,{tokens*64,128},s);
  const auto weights=mx::view(inputs[2],mx::uint16,s);
  std::vector<mx::array> blocks;
  blocks.reserve((std::size_t(rows)+tile_rows-1)/tile_rows);
  for(int first=0;first<rows;) {
    const int width=std::min(tile_rows,rows-first);
    std::vector<mx::array> sources{mx::arange(first,first+width,mx::int32,s)};
    // Sequence decode itself, not merely matmul. Otherwise MLX may schedule
    // independent keys ahead of consumers and retain a whole decoded bank.
    if(!blocks.empty())sources=mx::depends(sources,{blocks.back()});
    auto bits=decoder({inputs[1],inputs[3],all_valid,sources[0]},{{width,128}},{mx::uint16},
        {width*128,1,1},{128,1,1},{},std::nullopt,false,s)[0];
    auto keys=mx::view(bits,mx::bfloat16,s);
    auto dots=mx::matmul(query,mx::transpose(keys,{1,0},s),s);
    if(flatten)dots=mx::reshape(dots,{tokens,64,width},s);
    const auto count=std::uint64_t(tokens)*std::uint64_t(width);
    const int grid_x=static_cast<int>(std::min<std::uint64_t>((count+127)/128*128,65536));
    const auto grid_y=(count+grid_x-1)/grid_x;
    if(grid_y>std::uint64_t(std::numeric_limits<int>::max()))
      return std::unexpected(Status::Unimplemented("Apple row indexer native grid capacity"));
    blocks.push_back(finish({mx::view(dots,mx::uint16,s),weights,inputs[3],sources[0]},
        {{tokens,width}},{mx::float32},{grid_x,static_cast<int>(grid_y),1},{128,1,1},
        {{"GRID_X",grid_x}},std::nullopt,false,s)[0]);
    first+=width;
  }
  auto output=mx::concatenate(blocks,1,s);
  return with_device_status(std::move(output),std::move(status),s);
}
}
