#include "tests/compute_route_vulkan/row_cache_indexer_test.cc"
#include "src/compute_route_apple/apple_row_cache_indexer.h"
#include <atomic>
#include <chrono>
#include <cstdio>

namespace hyle::compute::apple::detail {
Result<mlx::core::array> row_cache_indexer_scores_scalar(
    std::span<const mlx::core::array>,mlx::core::Stream);
Result<mlx::core::array> row_cache_indexer_scores_matmul(
    std::span<const mlx::core::array>,mlx::core::Stream);
std::atomic<int> paired_mode{-1};
std::array<std::atomic<unsigned>,2> paired_calls{};
Result<mlx::core::array> row_cache_indexer_scores(
    std::span<const mlx::core::array> inputs,mlx::core::Stream stream) {
  const int mode=paired_mode.load();
  if(mode<0 || mode>1)return std::unexpected(Status::Internal("perf must not retrace a hot scorer"));
  ++paired_calls[mode];
  return mode?row_cache_indexer_scores_matmul(inputs,stream):row_cache_indexer_scores_scalar(inputs,stream);
}
}
int main() {
  namespace d=hyle::compute::apple::detail;
  auto context=n::Context::create().value();F f(513,3);
  d::paired_mode=0;auto scalar=direct(context,f);
  d::paired_mode=1;auto matmul=direct(context,f);
  d::paired_mode=-1;
  const std::array calls{d::paired_calls[0].load(),d::paired_calls[1].load()};
  if(!calls[0] || !calls[1])return 1;
  auto slots=std::array{scalar.create_invocation().value(),matmul.create_invocation().value()};
  // Check the exact public Programs with the rich fixture before changing
  // only their bound payloads to the same rounding-identity timing subset.
  for(int phase:{0,1}) {
    f.update(phase);auto args=inputs(context,f,0);const auto expected=f.expected();
    for(int arm:{0,1}) {
      if(!slots[arm].bind(args).ok())return 2;
      auto result=slots[arm].submit().value().wait().value();
      if(read(context,outputs(*result.get())[0])!=expected)return 3;
    }
  }
  f.update(0);
  std::fill(f.query.begin(),f.query.end(),row_cache_test::bfloat(0.f));
  std::fill(f.weights.begin(),f.weights.end(),row_cache_test::bfloat(1.f/64));
  for(int t=0;t<3;++t)for(int h=0;h<64;++h)
    f.query[(t*64+h)*128+t]=row_cache_test::bfloat(1.f);
  const auto args=inputs(context,f,0);const auto expected=f.expected();
  for(auto&slot:slots)if(!slot.bind(args).ok())return 4;
  const auto sample=[&](int arm)->double {
    const auto start=std::chrono::steady_clock::now();
    auto result=slots[arm].submit().value().wait().value();
    const auto stop=std::chrono::steady_clock::now();
    if(read(context,outputs(*result.get())[0])!=expected)
      throw std::runtime_error("paired result differs from independent BF16 oracle");
    return std::chrono::duration<double,std::nano>(stop-start).count();
  };
  for(int pair=0;pair<2;++pair){sample(pair%2);sample(1-pair%2);}
  std::puts("public packed op: same process/Context/inputs;2warm pairs+9measured pairs; submit+wait only");
  for(int pair=0;pair<9;++pair) {
    std::array<double,2> elapsed{};const int first=pair%2;
    elapsed[first]=sample(first);elapsed[1-first]=sample(1-first);
    std::printf("pair=%d order=%s scalar_ns=%.0f matmul_ns=%.0f\n",pair,first?"BA":"AB",elapsed[0],elapsed[1]);
  }
  if(d::paired_calls[0].load()!=calls[0] || d::paired_calls[1].load()!=calls[1])return 5;
  std::printf("cold_dispatch_calls scalar=%u matmul=%u; hot_retrace=0; rich two-phase and all paired oracles PASS\n",calls[0],calls[1]);
}
