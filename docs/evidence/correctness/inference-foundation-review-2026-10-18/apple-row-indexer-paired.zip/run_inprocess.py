from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
BASE=R.parent/'inference-foundation-review-20261018-row-cache-indexer-native'
NEW=R.parent/'inference-foundation-review-20261018-apple-row-indexer-matmul'
prior=json.loads((NEW/'commands.json').read_text())
cc=next(x['command']for x in prior if x['tag']=='01-indexer-compile');flags=cc[:cc.index('-c')]
flags[1:1]=['-I'+str(R),'-I'+str(NEW/'src/compute_route_apple')]
base=next(x['command']for x in prior if x['tag']=='05-perf-link')
records=[]
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,cmd):
  start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,capture_output=True,timeout=180)
  (R/(tag+'.stdout.log')).write_bytes(p.stdout);(R/(tag+'.stderr.log')).write_bytes(p.stderr)
  records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start))
  (R/'inprocess-commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(tag,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-1500:],flush=True);p.check_returncode()
def environment(tag):
  thermal=subprocess.run(['pmset','-g','therm'],capture_output=True,text=True)
  ps=subprocess.run(['ps','-A','-o','pid,pcpu,comm'],capture_output=True,text=True)
  lines=ps.stdout.splitlines();body=sorted(lines[1:],key=lambda s:float(s.split(None,2)[1]),reverse=True)[:8]
  (R/(tag+'.txt')).write_text(thermal.stdout+thermal.stderr+'\n'+lines[0]+'\n'+'\n'.join(body)+'\n')
environment('environment-before')
for arm,path in [('scalar',R/'scalar.cc'),('matmul',R/'matmul.cc')]:
  run(arm+'-renamed-compile',[*flags,'-c',path,'-o',R/(arm+'.o')])
run('paired-compile',[*flags,'-c',R/'paired.cc','-o',R/'paired.o'])
cmd=[]
for x in base:
  if x==str(NEW/'indexer.o'):cmd.extend([str(R/'scalar.o'),str(R/'matmul.o')])
  elif x==str(NEW/'perf.o'):cmd.append(str(R/'paired.o'))
  elif x==str(NEW/'perf'):cmd.append(str(R/'paired'))
  else:cmd.append(x)
run('paired-link',cmd);run('paired-inprocess',[R/'paired'])
environment('environment-after')
(R/'inprocess-identities.json').write_text(json.dumps([ident(Path(x))for x in cmd if Path(x).is_file()and Path(x).suffix in{'.o','.a','.dylib'}],indent=2)+'\n')
(R/'retain-objects.json').write_text(json.dumps([ident(p)for p in R.glob('*.o')],indent=2)+'\n')
old=json.loads((R/'deletable-artifacts.json').read_text());old.append(ident(R/'paired'))
(R/'deletable-artifacts.json').write_text(json.dumps(old,indent=2)+'\n')
