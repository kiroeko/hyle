#include "apple_row_cache_indexer.h"
#include <algorithm>
#include <limits>
#include <mlx/fast.h>
#include <mlx/ops.h>
#include "apple_checks.h"
namespace hyle::compute::apple::detail {
namespace mx=mlx::core;
Result<mx::array> row_cache_indexer_scores_scalar(std::span<const mx::array> inputs,mx::Stream s) {
  const int tokens=inputs[0].shape(0), rows=inputs[1].shape(0);
  auto begin=mx::slice(inputs[3],{0,0},{tokens,1},s);
  auto end=mx::slice(inputs[3],{0,1},{tokens,2},s);
  auto valid=mx::logical_and(mx::greater_equal(begin,mx::array(0),s),
      mx::logical_and(mx::less_equal(begin,end,s),mx::less_equal(end,mx::array(rows),s),s),s);
  auto all_valid=mx::all(valid,false,s);
  auto status=mx::where(all_valid,mx::array(0),mx::array(kIndexOutOfRange),s);
  if(!tokens || !rows)
    return with_device_status(mx::zeros({tokens,rows},mx::float32,s),std::move(status),s);
  // One key row per group: only128 decoded BF16 values and64 head products
  // live in threadgroup storage. Never decode/broadcast the complete history.
  static const auto kernel=mx::fast::metal_kernel("hyle_row_fp4_indexer",
      {"query","bank","weights","ranges","all_valid"},{"scores"},R"METAL(
    const uint lane=thread_index_in_threadgroup;
    const ulong pair=ulong(threadgroup_position_in_grid.y)*GROUPS_X+threadgroup_position_in_grid.x;
    const ulong rows=bank_shape[0], tokens=query_shape[0];
    if(pair>=tokens*rows)return;
    // This scalar is a data dependency on the whole GPU range validation.
    // No group may read even a legal query's bank row after another failed.
    if(!all_valid){if(lane==0)scores[pair]=-INFINITY;return;}
    const ulong t=pair/rows, row=pair%rows;
    const int begin=ranges[t*ranges_strides[0]], end=ranges[t*ranges_strides[0]+ranges_strides[1]];
    if(begin<0 || end<begin || ulong(end)>rows || row<ulong(begin) || row>=ulong(end)) {
      if(lane==0)scores[pair]=-INFINITY;
      return;
    }
    threadgroup float key[128], products[64];
    const uint packed=bank[row*bank_strides[0]+(lane/2)*bank_strides[1]];
    const uint code=(packed>>((lane&1)*4))&15;
    const uint scale=bank[row*bank_strides[0]+(64+lane/32)*bank_strides[1]];
    key[lane]=as_type<float>(hyle_key(code,scale)<<16);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if(lane<64) {
      float dot=0.f;
      for(uint d=0;d<128;++d) {
        const float q=as_type<float>(uint(query[t*query_strides[0]+lane*query_strides[1]+d*query_strides[2]])<<16);
        const float product=q*key[d];
        dot=dot+product;
      }
      const float rounded=hyle_bfloat(dot);
      const float positive=isnan(rounded)?rounded:(rounded>0.f?rounded:0.f);
      const float weight=as_type<float>(uint(weights[t*weights_strides[0]+lane*weights_strides[1]])<<16);
      products[lane]=hyle_bfloat(positive*weight);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if(lane==0) {
      float total=0.f;
      for(uint h=0;h<64;++h)total=total+products[h];
      scores[pair]=hyle_bfloat(total);
    }
  )METAL",R"METAL(
    #pragma clang fp contract(off)
    inline float hyle_bfloat(float x) {
      uint bits=as_type<uint>(x);
      if((bits&0x7fffffff)>0x7f800000)return as_type<float>((bits&0xffff0000)|0x00400000);
      return as_type<float>((bits+0x7fff+((bits>>16)&1))&0xffff0000);
    }
    inline uint hyle_key(uint code,uint scale) {
      const uint mantissas[8]={0,1,2,3,4,6,8,12};
      const uint magnitude=mantissas[code&7], sign=(code&8)<<12;
      if(scale==255)return sign|0x7fc0;
      if(!magnitude)return sign;
      const int power=int(scale)-128, top=31-clz(magnitude), exponent=top+power;
      if(exponent>127)return sign|0x7f80;
      if(exponent>=-126)return sign|(uint(exponent+127)<<7)|((magnitude<<uint(7-top))&127);
      const int shift=power+133;
      uint value=0;
      if(shift>=0)value=magnitude<<uint(shift);
      else if(shift>-32) {
        const uint right=uint(-shift), high=magnitude>>right;
        const uint low=magnitude&((1u<<right)-1), halfway=1u<<(right-1);
        value=high+uint(low>halfway || (low==halfway && (high&1)));
      }
      return sign|value;
    }
  )METAL",false,false,mx::CompileOptions{});
  const auto count=std::uint64_t(tokens)*std::uint64_t(rows);
  const int x=static_cast<int>(std::min(count,std::uint64_t{65535}));
  if((count+x-1)/x>std::uint64_t(std::numeric_limits<int>::max()))
    return std::unexpected(Status::Unimplemented("Apple row indexer native grid capacity"));
  auto output=kernel({mx::view(inputs[0],mx::uint16,s),inputs[1],
      mx::view(inputs[2],mx::uint16,s),inputs[3],all_valid},{{tokens,rows}},{mx::float32},
      {x*128,static_cast<int>((count+x-1)/x),1},{128,1,1},{{"GROUPS_X",x}},
      std::nullopt,false,s)[0];
  return with_device_status(std::move(output),std::move(status),s);
}
}
