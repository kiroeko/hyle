from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
BASE=R.parent/'inference-foundation-review-20261018-row-cache-indexer-native'
NEW=R.parent/'inference-foundation-review-20261018-apple-row-indexer-matmul'
prior=json.loads((NEW/'commands.json').read_text())
test=next(x['command']for x in prior if x['tag']=='02-canonical-link')
perf=next(x['command']for x in prior if x['tag']=='05-perf-link')
records=[]
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
objects={'scalar':BASE/'indexer.o','matmul':NEW/'indexer.o'}
assert hashlib.sha256(objects['scalar'].read_bytes()).hexdigest()=='d7490a76de21eab0d40982233b4bba0e313db7e466cef030081e058b9fa948bc'
assert hashlib.sha256(objects['matmul'].read_bytes()).hexdigest()=='c0b82998baee7d492f75ec8088cb2e1041b3a5cd678bab948d8c1cab846621c5'
assert hashlib.sha256((NEW/'perf.o').read_bytes()).hexdigest()=='191537ffbc76742a2a9d08e8f2b911342b6bcfc90ff88b02aa827c7a7fc190e2'
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
(R/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
if not(R/'mlx.metallib').exists():(R/'mlx.metallib').symlink_to(NEW/'mlx.metallib')
def run(tag,cmd):
  start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,capture_output=True,timeout=180)
  (R/(tag+'.stdout.log')).write_bytes(p.stdout);(R/(tag+'.stderr.log')).write_bytes(p.stderr)
  records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start))
  (R/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(tag,p.returncode,p.stdout.decode(errors='replace')[-5500:],p.stderr.decode(errors='replace')[-1000:],flush=True)
  p.check_returncode()
for arm,obj in objects.items():
  for kind,base in [('oracle',test),('perf',perf)]:
    cmd=[str(obj)if x==str(NEW/'indexer.o')else str(R/(arm+'-'+kind))if x==str(NEW/('indexer-test'if kind=='oracle'else'perf'))else x for x in base]
    run(arm+'-'+kind+'-link',cmd)
  run(arm+'-oracle',[R/(arm+'-oracle'),'--gtest_filter=AppleRowCacheIndexer.*'])
for i,arm in enumerate(['scalar','matmul','matmul','scalar']):
  run(f'paired-{i}-{arm}',[R/(arm+'-perf')])
(R/'identities.json').write_text(json.dumps([ident(p)for p in [objects['scalar'],objects['matmul'],NEW/'perf.o',BASE/'test.o']]+[ident(Path(x))for x in test if Path(x).is_file()and Path(x).suffix in{'.o','.a','.dylib'}and Path(x)not in{objects['matmul'],BASE/'test.o'}],indent=2)+'\n')
(R/'deletable-artifacts.json').write_text(json.dumps([ident(R/(a+'-'+k))for a in objects for k in['oracle','perf']],indent=2)+'\n')
