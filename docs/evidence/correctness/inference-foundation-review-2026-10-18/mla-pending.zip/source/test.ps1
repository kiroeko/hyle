# Remove completed, reproducible test executables; keep source/logs/objects.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$evidence = Join-Path $workspace 'docs/evidence/correctness/inference-foundation-review-2026-10-18/mla-pending.zip'
if (-not (Test-Path -LiteralPath $evidence -PathType Leaf)) { throw 'Source/results archive is missing' }
$directory = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-foundation-review-2026-10-18/mla-pending'))
$prefix = $directory.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$targets = @('capacity-probe.exe', 'consumer.exe', 'legacy-cpu-consumer.exe') | ForEach-Object {
    $target = [IO.Path]::GetFullPath((Join-Path $directory $_))
    if (-not $target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside test directory: $target" }
    $target
}
$freed = 0L
foreach ($target in $targets) {
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $item = Get-Item -LiteralPath $target
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected reparse point: $target" }
        $freed += $item.Length
        Remove-Item -LiteralPath $target
    }
}
Write-Output "Removed completed test executables: $freed bytes. Source, logs and reusable objects retained."
