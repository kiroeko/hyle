from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sources=['include/hyle/compute/batch_execution.h','src/compute_batch/batch_execution.cc',
    'tests/compute_batch/public_mla_pending_cuda_consumer.cc','tests/compute_batch/mla_test_support.h',
    'tests/compute_batch/pending_paged_receiver_cpu_risks.cc','tests/graph_batch/CMakeLists.txt','test.ps1']
summary={
 'scope':'common PagedBatchReceiver single compact MLA pending cache; legacy Q/K/V unchanged',
 'cuda':'F16/BF16 H64/D576 Q1/KV2, actual gated GPU producer -> F2 -> attention before gate release; full FP64 maxAbs0; rejection preserves Update; old output and original writer recovery PASS',
 'cpu_regression':'original pending_paged_receiver_cpu_risks.cc all9 modes PASS; matched baseline native cache, current common receiver object',
 'source_capacity':'two phases and one producer require3 source slots. Initial fixture used2 and early-return destruction before releasing gate self-blocked; capacity-probe proves immediate ResourceExhausted and preserved Update before gate release. No MLA native hidden-wait defect established.',
 'first_fixture_limit':'initial8MiB float cap rejected correctly; fixture increased16MiB for the original bounded planner. Later active-workspace optimization may change this requirement.',
 'trace':'probe-only local API interposition and instrumented common source copies; not product changes; initial link collision / dll lookup failure / timeouts retained',
 'untested':'complete models, native Apple/Vulkan pending MLA journeys, Linux runtime, throughput',
 'sources':[dict(path=p,sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest()) for p in sources]}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
archive=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/mla-pending.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in sources:z.write(ROOT/name,'source/'+name)
    for p in sorted(OUT.iterdir()):
        if p.is_file() and p.suffix in ('.py','.cc','.json','.log','.ps1'):
            z.write(p,'run/'+p.name)
    fixture=ROOT/'.scratch/inference-foundation-review-2026-10-18/test-wiring'
    for p in sorted(fixture.rglob('*')):
        if p.is_file() and (p.suffix in ('.py','.json','.log') or p.name=='CMakeLists.txt'):
            z.write(p,'wiring/'+p.relative_to(fixture).as_posix())
print(archive.name,archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest())
