from pathlib import Path
import hashlib, json, sys, subprocess, time

ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import build_host as b
import link_run as old
PREVIOUS=b.OUT;MLA=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla'
b.OUT=OUT;b.records=json.loads((OUT/'host-commands.json').read_text()) if (OUT/'host-commands.json').exists() else []
b.flags.append('/I'+str(ROOT/'tests/compute_batch'))
if '--link-only' not in sys.argv:
    b.comp('src/compute_batch/batch_execution.cc','batch-execution')
    b.comp('tests/compute_batch/public_mla_pending_cuda_consumer.cc','consumer')
if '--compile-only' in sys.argv:raise SystemExit(0)
replacements={PREVIOUS/'public-consumer.obj':OUT/'consumer.obj',PREVIOUS/'flashinfer-provider.obj':MLA/'flashinfer-provider.obj',
              PREVIOUS/'batch-execution.obj':OUT/'batch-execution.obj',PREVIOUS/'graph-batch.obj':MLA/'graph-batch.obj'}
objects=[replacements.get(p,p) for p in old.objects]
objects += [MLA/(n+'.obj') for n in ('batch-layout','paged-arena','native_mla')]
objects.append(PREVIOUS/'highdim-review/native_highdim.obj')
if '--capacity-probe' in sys.argv:
    source=(ROOT/'tests/compute_batch/public_mla_pending_cuda_consumer.cc').read_text()
    source=source.replace('create(std::move(native),3)','create(std::move(native),2)')
    needle='  HYLE_ASSIGN_OR_RETURN(auto done,receiver.submit(query,frame,std::move(update)));'
    assert source.count(needle)==1
    source=source.replace(needle,'''  auto submitted=receiver.submit(query,frame,std::move(update));
  if(!submitted){
    const bool rejected=submitted.error().IsResourceExhausted() && update.valid() && guards.active_batches()==1 && !receiver.output();
    std::fprintf(stderr,"two-phase/one-producer capacity2 returned error=%.*s, original Update retained=%d before gate release\\n",int(submitted.error().message().size()),submitted.error().message().data(),int(update.valid()));
    gate.release();HYLE_RETURN_IF_ERROR(update.wait());
    return check(rejected,"source capacity rejection changed original pending controls");
  }
  auto done=std::move(*submitted);''')
    path=OUT/'capacity-probe.cc';path.write_text(source)
    b.comp(path.relative_to(ROOT).as_posix(),'capacity-probe')
    objects=[OUT/'capacity-probe.obj' if p==OUT/'consumer.obj' else p for p in objects]
if '--control-trace' in sys.argv:
    source=(ROOT/'src/compute_batch/batch_execution.cc').read_text()
    position=source.index('Result<Completion> PagedBatchReceiver::submit_pages(')
    end=source.index('Result<ReadLease> PagedBatchReceiver::output()',position)
    body=source[position:end]
    for index,needle in enumerate([
        '  if(!data_)return', '  const auto capacity=',
        '    HYLE_RETURN_IF_ERROR((d::PagedArenaAccess::validate<',
        '  HYLE_ASSIGN_OR_RETURN(auto descriptions,',
        '  if(!s->completion.available()',
        '  HYLE_ASSIGN_OR_RETURN(auto views,',
        '  auto sources=p.source.take(',
        '  auto sequence=d::QueueSequence::begin(',
        '  auto prefix=d::CopyStreamAccess::dependency(',
        '  if(sequence->terminal().ok())',
        '  auto suffix=finish_native(',
        '  s->ran=true;',
    ]):
        assert body.count(needle)==1,(index,needle)
        body=body.replace(needle,'  std::fprintf(stderr,"RECEIVER checkpoint '+str(index)+'\\n");\n'+needle)
    source='#include <cstdio>\n'+source[:position]+body+source[end:]
    path=OUT/'batch-trace.cc';path.write_text(source)
    b.comp(path.relative_to(ROOT).as_posix(),'batch-trace')
    objects=[OUT/'batch-trace.obj' if p==OUT/'batch-execution.obj' else p for p in objects]
if '--trace' in sys.argv:
    b.comp('.scratch/inference-foundation-review-2026-10-18/mla-pending/api_trace.cc','api-trace')
    objects.append(OUT/'api-trace.obj')
exe=OUT/('capacity-probe.exe' if '--capacity-probe' in sys.argv else 'consumer.exe')
b.run('link',[b.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',*(['/FORCE:MULTIPLE'] if '--trace' in sys.argv else []),'/OUT:'+str(exe),*objects,*old.libs,*old.system])
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [*objects,*old.libs,exe]],indent=2)+'\n')
try:
    b.run('capacity-probe' if '--capacity-probe' in sys.argv else 'pending-mla',[exe],timeout=20)
except subprocess.TimeoutExpired as error:
    attempt=len([r for r in b.records if r.get('tag','').startswith('pending-mla-timeout')])
    tag='pending-mla-timeout-'+str(attempt)
    (OUT/(tag+'.stdout.log')).write_bytes(error.stdout or b'')
    (OUT/(tag+'.stderr.log')).write_bytes(error.stderr or b'')
    b.records.append(dict(tag=tag,command=[str(exe)],exit='timeout',seconds=20))
    (OUT/'host-commands.json').write_text(json.dumps(b.records,indent=2)+'\n')
    print((error.stdout or b'').decode(errors='replace'),flush=True)
    raise
