#include <cuda_runtime_api.h>
#include <windows.h>
#include <cstdio>
#include <cstdlib>
namespace {
template<class T>T original(const char*name){
  const auto module=LoadLibraryW(L"C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cudart64_13.dll");
  const auto pointer=reinterpret_cast<T>(GetProcAddress(module,name));
  if(!pointer){std::fprintf(stderr,"missing CUDA runtime trace original %s\n",name);std::abort();}
  return pointer;
}
void trace(const char*name,const char*phase){std::fprintf(stderr,"API %s %s\n",name,phase);std::fflush(stderr);}
}
extern "C" cudaError_t CUDARTAPI cudaFuncSetAttribute(const void*f,cudaFuncAttribute a,int n){
  const auto call=original<cudaError_t(CUDARTAPI*)(const void*,cudaFuncAttribute,int)>("cudaFuncSetAttribute");
  trace("cudaFuncSetAttribute","enter");const auto status=call(f,a,n);trace("cudaFuncSetAttribute","return");return status;
}
extern "C" cudaError_t CUDARTAPI cudaLaunchCooperativeKernel(const void*f,dim3 grid,dim3 block,void**args,size_t shared,cudaStream_t stream){
  const auto call=original<cudaError_t(CUDARTAPI*)(const void*,dim3,dim3,void**,size_t,cudaStream_t)>("cudaLaunchCooperativeKernel");
  trace("cudaLaunchCooperativeKernel","enter");const auto status=call(f,grid,block,args,shared,stream);trace("cudaLaunchCooperativeKernel","return");return status;
}
