from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
source=(ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/run.py').read_text()
source=source.replace("[OUT/'native-batch.obj',OUT/'provider.obj']",
    "[ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/native-batch.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj']")
source=source.replace("'tests/compute_batch/public_mla_cpu_consumer.cc'","'tests/compute_batch/pending_paged_receiver_cpu_risks.cc'")
source=source.replace("objects += [generic/(name+'.obj') for name in ('batch-layout','batch-execution','paged-arena')]",
    "objects += [generic/(name+'.obj') for name in ('batch-layout','paged-arena')]\nobjects.append(OUT/'batch-execution.obj')")
source=source.replace("OUT/'graph-batch.obj'","ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/graph-batch.obj'")
source=source.replace("compile(ROOT/'src/graph_batch/batch.cc','graph-batch')","ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/graph-batch.obj'")
source=source.replace("'consumer.obj'","'legacy-cpu-consumer.obj'").replace("'consumer')","'legacy-cpu-consumer')")
source=source.replace("'consumer.exe'","'legacy-cpu-consumer.exe'")
sys.argv=[__file__,'--reuse-products']
exec(compile(source,str(__file__),'exec'),{'__file__':__file__,'__name__':'__main__'})
