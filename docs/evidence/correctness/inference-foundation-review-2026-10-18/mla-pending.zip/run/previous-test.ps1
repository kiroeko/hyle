# Retire one obsolete Windows-absence consumer; preserve its source for evidence.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$source = [IO.Path]::GetFullPath((Join-Path $workspace 'tests/compute_batch/public_batch_cuda_absence_consumer.cc'))
$destination = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-feature-completion-2026-10-18/windows-batch/retired-public-batch-cuda-absence.cc'))
$prefix = $workspace.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
foreach ($path in @($source, $destination)) {
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Path outside Hyle workspace: $path" }
}
if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Obsolete consumer missing' }
if (Test-Path -LiteralPath $destination) { throw 'Retired source already exists' }
Move-Item -LiteralPath $source -Destination $destination
Write-Output "Historical source retained at $destination"
