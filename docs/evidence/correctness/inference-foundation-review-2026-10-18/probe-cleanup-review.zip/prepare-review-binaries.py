from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
DOC = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'
cases = [('row-cache-indexer-native', 'row-cache-indexer-native.zip'),
         ('cpu-grouped-expert-reuse', 'cpu-grouped-expert-reuse.zip'),
         ('paged-indexer', 'paged-indexer-cpu.zip'),
         ('cuda-row-cache-padded', 'cuda-row-cache-padded.zip'),
         ('cuda-row-cache-indexer', 'cuda-row-cache-indexer.zip'),
         ('packed-indexer-cpu', 'packed-indexer-cpu.zip')]


def digest(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


files, retain, archives = [], [], []
for name, archive in cases:
    directory = (BASE / name).resolve(strict=True)
    assert directory.parent == BASE.resolve(strict=True) and not directory.is_symlink()
    frozen = DOC / archive
    assert frozen.is_file()
    archives.append(dict(name=archive, sha256=digest(frozen)))
    for p in directory.iterdir():
        if p.is_file() and p.suffix in ('.exe', '.lib', '.exp', '.obj', '.o'):
            assert not p.is_symlink() and p.parent == directory
            record = dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p))
            (retain if p.suffix in ('.obj', '.o') else files).append(record)
plan = dict(roots=[str((BASE / name).resolve()) for name, archive in cases], archives=archives,
            files=files, retain=retain)
(OUT / 'review-binaries.json').write_text(json.dumps(plan, indent=2) + '\n')
backup = OUT / 'test-before-review-binaries.ps1'
if not backup.exists():
    shutil.copyfile(ROOT / 'test.ps1', backup)
print(json.dumps(dict(files=len(files), bytes=sum(r['bytes'] for r in files), retained_objects=len(retain))))
