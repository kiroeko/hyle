from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DOC = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'
plan = json.loads((OUT / 'review-binaries.json').read_text())
assert all(not Path(r['path']).exists() for r in plan['files'])
for r in plan['retain']:
    path = Path(r['path'])
    assert path.stat().st_size == r['bytes']
    with path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == r['sha256']
result = dict(removed=len(plan['files']), bytes=sum(r['bytes'] for r in plan['files']),
              retained_objects=len(plan['retain']),
              method='Root test.ps1: exact nonrecursive paths, archived-source identities, all target size/SHA and every retained object checked BEFORE deletion.',
              retained='All .obj/.o, maps, sources/logs/data and original SDK/tool caches; current live CUDA paged stage untouched')
(OUT / 'review-result.json').write_text(json.dumps(result, indent=2) + '\n')
shutil.copyfile(ROOT / 'test.ps1', OUT / 'test-review-binaries.ps1')
target = DOC / 'probe-cleanup-review.zip'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in ('prepare-review-binaries.py', 'finalize-review-binaries.py', 'review-binaries.json',
                 'review-result.json', 'review-result.log', 'test-review-binaries.ps1'):
        z.write(OUT / name, name)
print(json.dumps(dict(path=str(target), bytes=target.stat().st_size,
                      sha256=hashlib.sha256(target.read_bytes()).hexdigest(), result=result), indent=2))
