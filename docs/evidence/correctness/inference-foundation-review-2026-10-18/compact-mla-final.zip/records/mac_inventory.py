from pathlib import Path
import subprocess
code='''from pathlib import Path
import json
p=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib')
print(json.dumps(dict(providers=[x.name for x in p.glob('libhyle_compute_provider*.a')],cpu_graph=(p/'libhyle_graph_route_cpu_apple.a').exists())))
'''
p=subprocess.run(['ssh','kiro@172.22.10.198','python3 -'],input=code.encode(),capture_output=True)
out=Path(__file__).resolve().parent
(out/'mac-inventory.stdout.log').write_bytes(p.stdout);(out/'mac-inventory.stderr.log').write_bytes(p.stderr)
print(p.stdout.decode(),p.stderr.decode());p.check_returncode()
