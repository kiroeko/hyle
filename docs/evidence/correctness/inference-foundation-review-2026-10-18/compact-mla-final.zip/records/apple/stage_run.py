from pathlib import Path
import hashlib,io,json,tarfile,subprocess,base64
r=Path.cwd();o=r/'.scratch/inference-feature-completion-2026-10-18/mla/apple';remote='/Users/kiro/hyle-scratch/compute-unified/inference-foundation-review-20261018-mla'
files={}
for base in ['include','src/compute','src/compute_route_apple','src/graph','src/graph_batch','src/graph_route_cpu_apple']:
 for p in (r/base).rglob('*.h'):files[p.relative_to(r).as_posix()]=p
for rel in ['src/compute_batch/batch_layout.cc','src/compute_batch/paged_arena.cc','src/compute_batch/batch_paged_native.cc','src/graph_batch/native_paged_node.cc','src/compute_route_apple/apple_batch.cc','src/compute_route_apple/apple_materialized_invocation.cc','src/graph_route_cpu_apple/compile.cc','src/graph_route_cpu_apple/invocation.cc','tests/compute_batch/public_mla_native_consumer.cc','tests/compute_batch/mla_test_support.h']:
 files[rel]=r/rel
files['run_remote.py']=o/'run_remote.py'
items=[dict(path=k,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for k,p in sorted(files.items())];(o/'staged-sources.json').write_text(json.dumps(items,indent=2)+'\n')
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w:gz') as t:
 for k,p in sorted(files.items()):t.add(p,arcname=k)
(o/'staged-sources.tar.gz').write_bytes(data.getvalue())
code=f'''import pathlib,sys,tarfile,io
r=pathlib.Path({remote!r});assert not r.exists();r.mkdir()
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts and m.isfile()
 t.extractall(r)
print(r)
'''
cmd='python3 -c '+repr('import base64;exec(base64.b64decode('+repr(base64.b64encode(code.encode()).decode())+'))')
p=subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=data.getvalue(),capture_output=True)
(o/'stage.stdout.log').write_bytes(p.stdout);(o/'stage.stderr.log').write_bytes(p.stderr);print('stage',p.returncode,'source',sum(x['bytes'] for x in items),'compressed',len(data.getvalue()));print(p.stdout.decode(),p.stderr.decode());p.check_returncode()
p=subprocess.run(['ssh','kiro@172.22.10.198','cd '+remote+' && python3 run_remote.py'],capture_output=True,timeout=360)
(o/'remote.stdout.log').write_bytes(p.stdout);(o/'remote.stderr.log').write_bytes(p.stderr);print(p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'));p.check_returncode()
