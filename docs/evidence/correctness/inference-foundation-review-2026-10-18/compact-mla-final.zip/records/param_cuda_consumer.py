from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'tests/compute_batch/public_mla_cuda_consumer.cc';s=p.read_text()
a=s.index('Status exercise(');b=s.index('Status split_partials(',a)
part=s[a:b]
part=part.replace('Status exercise(bool bf,unsigned heads){','Status exercise(bool bf,unsigned heads,unsigned depth=576){')
part=part.replace('.max_requests=2,','.layout=depth==576?c::MlaCacheLayout::kCkv512Rope64:c::MlaCacheLayout::kCkv512,\n      .max_requests=2,',1)
part=part.replace('UINT32_MAX/576/heads','UINT32_MAX/depth/heads')
part=part.replace('*576','*depth')
part=part.replace('i/576','i/depth')
s=s[:a]+part+s[b:]
s=s.replace('HYLE_RETURN_IF_ERROR(exercise(true,64));return split_partials();','HYLE_RETURN_IF_ERROR(exercise(true,64));HYLE_RETURN_IF_ERROR(exercise(false,64,512));HYLE_RETURN_IF_ERROR(exercise(true,64,512));return split_partials();')
p.write_text(s,newline='\n')
