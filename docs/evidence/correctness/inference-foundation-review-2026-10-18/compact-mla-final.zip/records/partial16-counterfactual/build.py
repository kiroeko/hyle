from pathlib import Path
import json,sys,subprocess,time,os,re
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];BASE=OUT.parent
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import build_host as b
records=[]
def run(tag,cmd,env=b.env):
 t=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=ROOT,env=env,capture_output=True,timeout=240)
 (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,flush=True)
 if p.returncode:
  for line in (p.stdout+p.stderr).decode(errors='replace').splitlines():
   if re.search(r'(?:\berror(?: \w+\d+)?:|fatal error)',line,re.I):print(line[:500])
 return p.returncode
cmd=json.loads((BASE/'native-command.json').read_text())['command'];cmd[cmd.index('-c')+1]=str(OUT/'native-partial16.cu');cmd[cmd.index('-o')+1]=str(OUT/'native-partial16.obj');cmd+=['-I'+str(ROOT/'src/compute_provider_flashinfer')]
assert run('native-compile',cmd)==0
assert run('consumer-compile',[b.cl,*b.flags,'/I'+str(ROOT/'tests/compute_batch'),OUT/'consumer.cc','/Fo'+str(OUT/'consumer.obj')])==0
cmd=next(x['command'] for x in reversed(json.loads((BASE/'host-commands.json').read_text())) if x['tag']=='mla-link')
cmd=[str(OUT/'consumer.obj') if x==str(BASE/'consumer.obj') else str(OUT/'native-partial16.obj') if x==str(BASE/'native_mla.obj') else '/OUT:'+str(OUT/'counterfactual.exe') if x.startswith('/OUT:') else '/MAP:'+str(OUT/'counterfactual.map') if x.startswith('/MAP:') else x for x in cmd]
assert run('link',cmd)==0
