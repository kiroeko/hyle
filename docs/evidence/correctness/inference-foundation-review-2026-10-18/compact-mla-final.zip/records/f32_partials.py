from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
RAW=ROOT/'.scratch/g04-bf16-partials-vendor/upstream'
mp=ROOT/'third_party/flashinfer_cache/patches.json';m=json.loads(mp.read_text())
def patch(path,edits):
 e=next((x for x in m['files'] if x['path']==path),None)
 data=(RAW/path).read_text()
 if e is None:
  e=dict(path=path,before_sha256=hashlib.sha256(data.encode()).hexdigest(),edits=[]);m['files'].append(e)
 for x in e['edits']:
  assert data.count(x['before'])==1
  data=data.replace(x['before'],x['after'],1)
 for a,b in edits:
  assert data.count(a)==1,(path,a[:120],data.count(a))
  data=data.replace(a,b,1);e['edits'].append(dict(before=a,after=b))
 e['after_sha256']=hashlib.sha256(data.encode()).hexdigest()
patch('include/flashinfer/attention/mla_params.cuh',[
 ('typename DTypeO_, typename IdType_>','typename DTypeO_, typename IdType_, typename DTypePartial_ = DTypeO_>'),
 ('  using IdType = IdType_;','  using IdType = IdType_;\n  using DTypePartial = DTypePartial_;'),
 ('  DTypeO* partial_o;','  DTypePartial* partial_o;')])
patch('include/flashinfer/attention/mla.cuh',[
 ('typename DTypeKV_, typename DTypeO_, typename IdType_>\nstruct KernelTraits',
  'typename DTypeKV_, typename DTypeO_, typename IdType_, typename DTypePartial_ = DTypeO_>\nstruct KernelTraits'),
 ('  using DTypeO = DTypeO_;','  using DTypeO = DTypeO_;\n  using DTypePartial = DTypePartial_;'),
 ('typename KTraits::DTypeO* partial_o,\n    float* partial_lse,',
  'typename KTraits::DTypePartial* partial_o,\n    float* partial_lse,'),
 ('                                              typename KTraits::DTypeO* partial_o,',
  '                                              typename KTraits::DTypePartial* partial_o,'),
 ('                                        typename KTraits::DTypeO* partial_o, float* partial_lse,',
  '                                        typename KTraits::DTypePartial* partial_o, float* partial_lse,'),
 ('      DTypeO* o_partial_ptr =','      typename KTraits::DTypePartial* o_partial_ptr ='),
 ('  DTypeO* partial_o = params.partial_o;','  typename Params::DTypePartial* partial_o = params.partial_o;'),
 ('/*CTA_TILE_Q_=*/64, EFF_CTA_TILE_KV, DTypeQ, DTypeKV, DTypeO, IdType>;',
  '/*CTA_TILE_Q_=*/64, EFF_CTA_TILE_KV, DTypeQ, DTypeKV, DTypeO, IdType, typename Params::DTypePartial>;'),
 ('  smem_t<KTraits::SWIZZLE_MODE_O> o_smem(smem_storage->o_smem);\n#pragma unroll\n  for (uint32_t mma_d',
'''  // A private F32-partial consumer stores the normalized accumulator before
  // final-output conversion. Keep the original 16-bit shared tile and final
  // writeback; a separate F32 shared tile would exceed SM89 block capacity.
  if constexpr (std::is_same_v<typename KTraits::DTypePartial, float>) {
    if (partial_o != nullptr) {
#pragma unroll
      for (uint32_t mma_d = 0; mma_d < NUM_MMA_D_CKV / 2; ++mma_d) {
#pragma unroll
        for (uint32_t reg = 0; reg < 8; ++reg) {
          const uint32_t row = warp_idx_in_wg * 16 + lane_idx / 4 + ((reg % 4) / 2) * 8;
          const uint32_t col = warpgroup_idx * (HEAD_DIM_CKV / 2) + mma_d * 16 +
                               (reg / 4) * 8 + (lane_idx % 4) * 2 + reg % 2;
          if ((packed_offset + row) / num_heads < q_len)
            partial_o[(blockIdx.x * CTA_TILE_Q + row) * HEAD_DIM_CKV + col] = o_frag[mma_d][reg];
        }
      }
#pragma unroll
      for (uint32_t j = 0; j < 2; ++j) {
        const uint32_t row = warp_idx_in_wg * 16 + lane_idx / 4 + 8 * j;
        if (lane_idx % 4 == 0 && (packed_offset + row) / num_heads < q_len)
          partial_lse[blockIdx.x * CTA_TILE_Q + row] =
              m[j] == typename KTraits::DTypeQKAccum(-math::inf) ?
                  -cuda::std::numeric_limits<float>::infinity() : math::ptx_log2(d[j]) + float(m[j]);
      }
      return;
    }
  }
  smem_t<KTraits::SWIZZLE_MODE_O> o_smem(smem_storage->o_smem);
#pragma unroll
  for (uint32_t mma_d''')])
patch('include/flashinfer/attention/scheduler.cuh',[
 ('size_t* hyle_float_bytes = nullptr, size_t* hyle_int_bytes = nullptr) {',
  'size_t* hyle_float_bytes = nullptr, size_t* hyle_int_bytes = nullptr,\n                           uint32_t hyle_partial_bytes = 2) {'),
 ('  constexpr size_t sizeof_dtype_o = 2;\n  AlignedAllocator float_allocator = hyle_query',
  '  const size_t sizeof_dtype_o = hyle_partial_bytes;\n  AlignedAllocator float_allocator = hyle_query')])
m['scope']+='; typed MLA keeps normalized split partial outputs in F32 and merges them with the original F32 state reducer; final caller dtype and probability tile stay unchanged'
mp.write_text(json.dumps(m,indent=2)+'\n',newline='\n')
