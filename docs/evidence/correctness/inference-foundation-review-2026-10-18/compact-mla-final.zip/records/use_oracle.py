from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'tests/compute_batch/public_mla_cuda_consumer.cc'
s=p.read_text();a=s.index('Status check(');b=s.index('Status exercise(',a)
s=s[:a]+'using mla_test::check;\nusing mla_test::encode;\nusing mla_test::decode;\nusing mla_test::oracle;\n'+s[b:]
s=s.replace('#include <hyle/simd/dtype.h>','#include "mla_test_support.h"')
p.write_text(s,newline='\n')
