from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'third_party/flashinfer_cache/patches.json';m=json.loads(p.read_text())
e=next(x for x in m['files'] if x['path']=='include/flashinfer/attention/mla.cuh')
ed=e['edits'][-1];assert ed['after'].count('blockIdx.x * CTA_TILE_Q')==2
ed['after']=ed['after'].replace('blockIdx.x * CTA_TILE_Q','blockIdx.x * KTraits::CTA_TILE_Q')
data=(ROOT/'.scratch/g04-bf16-partials-vendor/upstream'/e['path']).read_text()
for x in e['edits']:
 assert data.count(x['before'])==1
 data=data.replace(x['before'],x['after'],1)
e['after_sha256']=hashlib.sha256(data.encode()).hexdigest()
p.write_text(json.dumps(m,indent=2)+'\n',newline='\n')
