from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'src/compute_route_apple/apple_batch.cc';s=p.read_text()
def once(a,b,n=1):
 global s
 assert s.count(a)==n,(a[:70],s.count(a));s=s.replace(a,b,1)
once('  const auto c=recipe.schema().capacity();','  const auto c=recipe.schema().capacity();\n  const bool mla=recipe.schema().mla_layout()!=MlaCacheLayout::kNone;',2)
once('for(std::size_t i=0;i<4;++i){HYLE_ASSIGN_OR_RETURN(specs[i],input_spec(recipe.descriptions()[i]));}',
 'for(std::size_t i=0;i<recipe.descriptions().size();++i){HYLE_ASSIGN_OR_RETURN(specs[i],input_spec(recipe.descriptions()[i]));}')
once('return prepare_runtime_program(context,layout,specs,[recipe]',
 'return prepare_runtime_program(context,layout,std::span(specs).first(mla?3:4),[recipe]')
once('if(inputs.size()!=4)return std::unexpected(Status::InvalidArgument("Apple paged needs four native ports"));',
 'const bool mla=recipe.schema().mla_layout()!=MlaCacheLayout::kNone;\n      if(inputs.size()!=(mla?3u:4u))return std::unexpected(Status::InvalidArgument("Apple paged native port count"));')
once('const auto v=mlx::core::transpose(mlx::core::reshape(inputs[2],value_root,stream),{0,2,1,3},stream);',
'''// The value prefix is a strided alias of the same physical packed row.
      // The existing private kernel accepts independent K/V sequence pitches.
      const auto v=mla?mlx::core::slice(k,{0,0,0,0},{1,int(c.kv_heads),int(std::int64_t(c.max_pages)*16),512},stream):
          mlx::core::transpose(mlx::core::reshape(inputs[2],value_root,stream),{0,2,1,3},stream);''')
once('hyle_paged_attention(q,k,v,inputs[3],','hyle_paged_attention(q,k,v,inputs[mla?2:3],')
p.write_text(s,newline='\n')
for backend in ['apple','vulkan']:
 p=ROOT/f'src/compute_route_{backend}/{backend}_materialized_invocation.cc';s=p.read_text()
 token='Result<OwnedResult<Results>> PagedBatchInvocation::submit()'
 i=s.index(token)
 s=s[:i]+f'''Status PagedBatchInvocation::bind(ReadLease q,PagedArenaRead cache)noexcept{{
  return data_?data_->bind(std::move(q),std::move(cache)):Status::FailedPrecondition("empty {backend} paged MLA controller");
}}
'''+s[i:]
 p.write_text(s,newline='\n')
p=ROOT/'src/compute_route_vulkan/vulkan_batch.cc';s=p.read_text()
once('detail::Plan plan;plan.workload=workload;plan.inputs={0,1,2,3};',
 'const bool mla=recipe.schema().mla_layout()!=MlaCacheLayout::kNone;\n    detail::Plan plan;plan.workload=workload;plan.inputs=mla?std::vector<std::uint32_t>{0,1,2}:std::vector<std::uint32_t>{0,1,2,3};')
once('.runtime_request=request.index});','.runtime_request=request.index,.compact_mla=mla});')
once('HYLE_ASSIGN_OR_RETURN(auto output,add(op,{request.q,k,v,3}));',
 'HYLE_ASSIGN_OR_RETURN(auto output,add(op,mla?std::vector<std::uint32_t>{request.q,k,2}:std::vector<std::uint32_t>{request.q,k,v,3}));')
p.write_text(s,newline='\n')
