#include <array>
#include <cstdio>
#include <vector>
#if defined(HYLE_MHC_CPU)
#include "hyle/graph/cpu.h"
#else
#include "hyle/graph/cuda.h"
#include "hyle/compute/backends/cuda.h"
#endif
#include "hyle/mem/buffer.h"

int main() {
  using namespace hyle;
  namespace c=compute; namespace g=graph;
#if defined(HYLE_MHC_CPU)
  auto context=g::cpu::create_context();
#else
  auto context=g::cuda::create_context();
#endif
  if(!context){std::fprintf(stderr,"context: %.*s\n",int(context.error().message().size()),context.error().message().data());return 1;}
#if defined(HYLE_MHC_CPU)
  auto resource=mem::system_resource();
#else
  auto memory=c::cuda::MemoryResource::create(*context,c::cuda::MemoryKind::kDevice).value();
  auto resource=memory.ref();
#endif
  const auto bf=c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{24,16384}).value();
  const auto scale_desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{16384}).value();
  auto weight=mem::Buffer::create(resource,bf.required_bytes().value(),256).value();
  auto scale=mem::Buffer::create(resource,scale_desc.required_bytes().value(),256).value();
  const std::vector<std::uint16_t> zeros(24*16384);
  const std::vector<float> ones(16384,1.f);
  if(!weight.view().write(std::as_bytes(std::span(zeros))).ok() || !scale.view().write(std::as_bytes(std::span(ones))).ok())return 2;
  auto b=g::GraphBuilder::create().value();
  auto x=b.input(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,3>{1,4,4096}).value()).value();
  auto w=b.constant(bf).value(); auto s=b.constant(scale_desc).value();
  auto flat=b.add(c::View::reshape(c::TensorShape::create(std::array<std::int64_t,2>{1,16384}).value()).value(),x).value();
  auto norm=b.add(c::RmsNorm{},flat,s).value();
  auto cast=b.add(c::Cast{c::DataType::kFloat32},w).value();
  auto transpose=b.add(c::View::permute(std::array<std::int32_t,2>{1,0}).value(),cast).value();
  auto y=b.add(c::MatMul{},norm,transpose).value();
  if(!b.publish(y).ok())return 3;
  auto logical=std::move(b).finish().value();
  const std::array constants{g::ConstantBinding{w,c::ConstTensorView::create(bf,weight.view()).value()},g::ConstantBinding{s,c::ConstTensorView::create(scale_desc,scale.view()).value()}};
  const std::array storage{g::StorageDomain{.resource=resource}};
  const std::array targets{g::ExecutionTarget{.context=&*context,.default_storage=g::StorageDomainId{0}}};
  const std::array lanes{g::ExecutionLane{.target=g::ExecutionTargetId{0}}};
  auto compiled=g::compile(logical,{.storage_domains=storage,.targets=targets,.lanes=lanes},{.constants=constants});
  if(!compiled){std::fprintf(stderr,"compile: %.*s\n",int(compiled.error().message().size()),compiled.error().message().data());return 4;}
  const auto &r=compiled->report;
  std::printf("nodes=%zu steps=%zu regions=%zu packed_count=%zu packed_bytes=%zu materialized_bytes=%zu\n",r.node_count(),r.step_count(),r.region_count(),r.packed_constant_count(),r.packed_constant_bytes(),r.materialized_constant_bytes());
  for(std::size_t i=0;i<r.step_count();++i){
    const auto step=r.step(i).value();
    std::printf("step%zu kind=%u provider=%.*s preference=%u nodes=",i,unsigned(step.kind),int(step.provider.name.size()),step.provider.name.data(),step.preference);
    for(std::size_t j=0;j<step.node_count;++j)std::printf("%s%u",j?",":"",r.step_node(i,j).value().ordinal());
    std::printf(" dispatches=%u copy_bytes=%zu\n",step.dispatch_count,step.copy_bytes);
  }
  auto first=compiled->executable.create_invocation();
  auto second=compiled->executable.create_invocation();
  if(!first || !second)return 5;
  // Initialize two native graphs only: no user input binding, submit, or timing.
}
