#pragma once

#include <array>
#include <new>
#include <utility>
#include <vector>
#include "hyle/compute/model_ops.h"
#include "hyle/graph/region_provider.h"
#include "hyle/mem/buffer.h"

// Header-only ownership glue for ggml region adapters. Native execution stays
// inside each existing provider; Graph core has no ggml/context dependency.
namespace hyle::graph::ggml_shared {
using Pack = Status (*)(void *, compute::ConstTensorView, compute::TensorView,
                        mem::AllocatorRef) noexcept;
inline constexpr std::uint64_t kBfloatToFloat = 0x4747435542463332ULL;
inline constexpr std::uint64_t kMatrixTranspose = 0x47474d5452414e53ULL;
struct PackedConstant final {
  mem::Buffer storage;
  compute::TensorDesc description;
};
struct PackingRequest final {
  void *native_context;
  Pack pack;
  compute::TensorDesc description;
};
inline Status make_constant(void *opaque, compute::ConstTensorView source,
                            mem::MemoryResourceRef resource,
                            mem::AllocatorRef allocator,
                            ConstantArtifactPayload *output) noexcept {
  const auto &request = *static_cast<const PackingRequest *>(opaque);
  void *storage = allocator.allocate(sizeof(PackedConstant), alignof(PackedConstant));
  if (!storage)
    return Status::ResourceExhausted("ggml packed constant metadata");
  auto *packed = ::new (storage) PackedConstant{{}, request.description};
  *output = {packed, +[](void *value, mem::AllocatorRef owner) noexcept {
    auto *constant = static_cast<PackedConstant *>(value);
    constant->~PackedConstant();
    owner.deallocate(constant, sizeof(PackedConstant), alignof(PackedConstant));
  }};
  HYLE_ASSIGN_OR_RETURN(auto bytes, packed->description.required_bytes());
  HYLE_ASSIGN_OR_RETURN(packed->storage, mem::Buffer::create(resource, bytes, 256));
  HYLE_ASSIGN_OR_RETURN(auto target, compute::TensorView::create(
      packed->description, packed->storage.view()));
  return request.pack(request.native_context, source, target, allocator);
}
inline compute::ProviderPrepareOutcome
acquire(ConstantArtifactAccess access, ValueId source,
        compute::TensorDesc description, mem::MemoryResourceRef resource,
        std::uint64_t format, Pack pack, void *native_context,
        compute::ConstTensorView *binding) noexcept {
  PackingRequest request{native_context, pack, description};
  ConstantArtifactView result;
  const auto bytes = description.required_bytes().value();
  const auto outcome = access.get_or_create(source,
      {.key = {format, 1}, .storage = resource, .packed_bytes = bytes,
       .persistent_bytes = sizeof(PackedConstant),
       // Native cold execution can allocate handles/workspace. The immutable
       // payload is exact; the native preparation peak remains unknown.
       .private_storage = {.resident_bytes = bytes, .peak_bytes = std::nullopt}},
      &make_constant, &request, &result);
  if (outcome.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
    return outcome;
  const auto &packed = *static_cast<const PackedConstant *>(result.state);
  auto view = compute::ConstTensorView::create(packed.description, packed.storage.view());
  if (!view)
    return compute::ProviderPrepareOutcome::error(std::move(view).error());
  *binding = std::move(*view);
  return compute::ProviderPrepareOutcome::prepared();
}
inline Result<compute::TensorDesc>
matrix_description(const compute::TensorDesc &source) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto transposed, source.transposed());
  HYLE_ASSIGN_OR_RETURN(auto physical, compute::TensorDesc::dense(
      source.data_type(), transposed.dimensions()));
  return physical.transposed(); // Same logical [...,K,N], packed [...,N,K].
}
// Both native adapters use the same immutable-only selection/key/ownership
// protocol. A null widening callback leaves that backend's expert path alone.
template <class Recipe>
compute::ProviderPrepareOutcome
pack_constants(void *context, const RegionCompileRequest &request,
               std::span<const ValueId> values, Recipe &recipe,
               Pack widen_bfloat, Pack transpose_matrix,
               std::vector<ValueId> *packed_matrices = nullptr) {
  using Outcome = compute::ProviderPrepareOutcome;
  if (!request.constant_artifacts.available()) return Outcome::prepared();
  std::vector<std::array<std::uint32_t, 2>> replacements(values.size(), {UINT32_MAX, UINT32_MAX});
  for (auto &node : recipe.nodes) {
    const bool expert = widen_bfloat && node.operation.template custom_as<compute::model_ops::GroupedMatMul>().has_value();
    const bool matrix = node.operation.template get_if<compute::MatMul>() != nullptr;
    if (!expert && !matrix) continue;
    const auto port = expert ? 0u : 1u;
    const auto original = node.inputs[port];
    const auto &description = recipe.values[original];
    if (!description.is_plain() || !description.is_dense() ||
        (expert && description.data_type() != compute::DataType::kBFloat16)) continue;
    const auto source = std::ranges::find_if(request.constants,
        [&](const auto &constant) { return constant.value == values[original]; });
    if (source == request.constants.end()) continue; // Dynamic inputs never enter the cache.
    const auto physical = description.transposed();
    if (matrix && (!physical || physical->is_dense())) continue;
    const auto transform = expert ? 0u : 1u;
    if (replacements[original][transform] == UINT32_MAX) {
      const auto input = std::ranges::find(request.inputs, values[original]);
      if (input == request.inputs.end()) return Outcome::error(
          Status::Internal("ggml constant misses region boundary"));
      auto packed = expert ? compute::TensorDesc::dense(compute::DataType::kFloat32, description.dimensions())
                           : matrix_description(description);
      if (!packed) return Outcome::error(std::move(packed).error());
      compute::ConstTensorView binding;
      const auto outcome = acquire(request.constant_artifacts, values[original], *packed,
          request.input_resources[static_cast<std::size_t>(input - request.inputs.begin())],
          expert ? kBfloatToFloat : kMatrixTranspose,
          expert ? widen_bfloat : transpose_matrix, context, &binding);
      if (outcome.kind != compute::ProviderPrepareOutcomeKind::kPrepared) return outcome;
      const auto id = static_cast<std::uint32_t>(recipe.values.size());
      recipe.values.push_back(*packed);
      recipe.constants.push_back({id, std::move(binding)});
      replacements[original][transform] = id;
      if (matrix && packed_matrices) packed_matrices->push_back(values[original]);
    }
    node.inputs[port] = replacements[original][transform];
  }
  return Outcome::prepared();
}
} // namespace hyle::graph::ggml_shared
