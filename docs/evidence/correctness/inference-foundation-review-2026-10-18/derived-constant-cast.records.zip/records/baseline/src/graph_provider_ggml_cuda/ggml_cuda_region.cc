#include "hyle/graph/providers/ggml_cuda.h"

#include <algorithm>
#include <array>
#include <exception>
#include <limits>
#include <new>
#include <vector>

#include "hyle/graph/region_provider.h"
#include "hyle/compute/model_ops.h"
#include "../graph_ggml_shared/constant_packing.h"
#include "../graph_ggml_shared/region_discovery.h"
#include "program.h"

namespace hyle::graph::ggml_cuda {
namespace native = compute::ggml_cuda::internal;
namespace {

inline constexpr compute::RoutePolicyId kGgmlCudaRegionPolicy{
    0x48594c4547474355ULL, 1, 1};
inline constexpr std::uint32_t kGgmlCudaRegionPreference = 200;

Result<bool> supported_node(void *context, const Graph &graph,
                            NodeId node) noexcept {
  auto operation = graph.operation(node);
  if (!operation)
    return false; // Symbolic metadata views are not this exact native domain.
  // Keep ordinary attention on its independently ranked fused providers.
  // A region's preference must not replace FlashInfer/Torch with math SDPA.
  // SinkAttention has the same native math program inside this region.
  if (operation->get_if<compute::ScaledDotProductAttention>())
    return false;
  auto input_count = graph.node_input_count(node);
  auto output_count = graph.node_output_count(node);
  auto effects = graph.node_resource_count(node);
  if (!input_count || !output_count || !effects)
    return std::unexpected(
        Status::InvalidArgument("ggml CUDA region node is invalid"));
  if (*output_count == 0 || *effects != 0)
    return false;
  try {
    std::vector<compute::TensorDesc> inputs(*input_count);
    std::vector<compute::TensorDesc> outputs(*output_count);
    for (std::size_t i = 0; i < *input_count; ++i) {
      auto id = graph.node_input(node, i);
      if (!id)
        return std::unexpected(std::move(id).error());
      auto description = graph.value_description(*id);
      if (!description)
        return false;
      inputs[i] = *description;
    }
    for (std::size_t i = 0; i < *output_count; ++i) {
      auto id = graph.result(node, i);
      if (!id)
        return std::unexpected(std::move(id).error());
      auto description = graph.value_description(*id);
      if (!description)
        return false;
      outputs[i] = *description;
    }
    return native::supports(context, *operation, inputs, outputs);
  } catch (const std::bad_alloc &) {
    return std::unexpected(Status::ResourceExhausted(
        "ggml CUDA region descriptor allocation failed"));
  }
}

bool single_constant_expert(const Graph &graph, NodeId node) noexcept {
  const auto operation = graph.operation(node);
  if (!operation || !operation->custom_as<compute::model_ops::GroupedMatMul>())
    return false;
  const auto weight = graph.node_input(node, 0);
  if (!weight || weight->kind() != ValueKind::kConstant) return false;
  const auto description = graph.value_description(*weight);
  return description && description->is_plain() && description->is_dense() &&
         description->rank() == 3 &&
         description->data_type() == compute::DataType::kBFloat16;
}

Status propose(void *context, const Graph &graph, mem::AllocatorRef allocator,
               RegionProposalWriter &writer) noexcept {
  if (graph.node_count() == 0)
    return Status::Ok();
  const auto emit = [&](std::span<const NodeId> nodes) -> Result<bool> {
    // A lone immutable BF16 expert uses exactly the same native widening
    // recipe. Other singleton operations keep their ordinary provider ranks.
    if (nodes.empty() || (nodes.size() == 1 && !single_constant_expert(graph, nodes[0])))
      return true;
    return writer.try_add(
        {.nodes = nodes,
         .cost = {.workspace = compute::WorkspaceRequirement{},
                  .persistent_bytes = std::nullopt,
                  .copy_bytes = std::nullopt,
                  .repack_bytes = std::nullopt,
                  .synchronization_count = 2,
                  .dispatch_count = 1},
         .route = 1,
         .replay_class = compute::ProviderReplayClass::kManaged,
         .implementation = compute::ProviderImplementationId{2},
         .policy = kGgmlCudaRegionPolicy,
         .preference = kGgmlCudaRegionPreference});
  };
  return ggml_shared::discover_regions(graph, allocator,
      [&](NodeId node) { return supported_node(context, graph, node); }, emit);
}

Status qualify(void *context, const RegionCompileRequest &request) noexcept {
  if (!request.graph || request.route != 1 || request.nodes.empty() ||
      request.outputs.empty() || request.has_unknown_effects ||
      !request.effect_accesses.empty())
    return Status::Unimplemented("ggml CUDA region boundary is not admitted");
  if (request.nodes.size() == 1 &&
      !single_constant_expert(*request.graph, request.nodes.front()))
    return Status::Unimplemented("ggml CUDA singleton needs an immutable BF16 expert");
  for (const auto node : request.nodes) {
    auto supported = supported_node(context, *request.graph, node);
    if (!supported)
      return std::move(supported).error();
    if (!*supported)
      return Status::Unimplemented(
          "ggml CUDA region contains an unsupported node");
  }
  return Status::Ok();
}
Status resources(void *context, const RegionCompileRequest &request,
                 mem::AllocatorRef,
                 std::span<compute::detail::ResourceBindingRequirement> inputs,
                 std::span<compute::detail::ResourceBindingRequirement> outputs,
                 RegionResourceProposal *proposal) noexcept {
  *proposal = {};
  HYLE_RETURN_IF_ERROR(qualify(context, request));
  std::ranges::fill(inputs, native::kBinding);
  std::ranges::fill(outputs, native::kBinding);
  for (auto &binding : inputs)
    binding.minimum_alignment = 1;
  for (auto &binding : outputs)
    binding.minimum_alignment = 1;
  for (const auto node : request.nodes) {
    const auto operation = request.graph->operation(node).value();
    const auto require = [&](ValueId id) {
      const auto type = request.graph->value_description(id)->data_type();
      const auto alignment = native::boundary_alignment(operation, type);
      // Published values may also be read by another native node. Its input
      // requirement is part of the external output's binding contract too.
      for (std::size_t i = 0; i < request.inputs.size(); ++i)
        if (request.inputs[i] == id)
          inputs[i].minimum_alignment =
              std::max(inputs[i].minimum_alignment, alignment);
      for (std::size_t i = 0; i < request.outputs.size(); ++i)
        if (request.outputs[i] == id)
          outputs[i].minimum_alignment =
              std::max(outputs[i].minimum_alignment, alignment);
    };
    for (std::size_t i = 0; i < request.graph->node_input_count(node).value();
         ++i)
      require(request.graph->node_input(node, i).value());
    for (std::size_t i = 0;
         i < request.graph->node_output_count(node).value(); ++i)
      require(request.graph->result(node, i).value());
  }
  *proposal = {.runtime = native::kRuntime,
               .workspace_resource = native::kBinding};
  return Status::Ok();
}

struct Artifact final {
  compute::detail::ProviderPrepared native;
};
void destroy(void *value, mem::AllocatorRef allocator) noexcept {
  auto *artifact = static_cast<Artifact *>(value);
  if (!artifact)
    return;
  artifact->native.vtable->destroy_prepared(artifact->native.state, allocator);
  artifact->~Artifact();
  allocator.deallocate(artifact, sizeof(Artifact), alignof(Artifact));
}
compute::AliasSupport alias(void *, std::size_t, std::size_t) noexcept {
  return {};
}
Status create_invocation(void *value, mem::AllocatorRef allocator,
                         mem::BufferView workspace, void **output) noexcept {
  const auto &artifact = static_cast<Artifact *>(value)->native;
  return artifact.vtable->create_invocation(artifact.state, allocator,
                                            workspace, output);
}
// Both Direct and Graph use the same invocation callbacks; this table keeps
// only an immutable pointer to that table, never a second execution program.
struct Invocation final {
  const compute::detail::ProviderPreparedVTable *vtable = nullptr;
  void *state = nullptr;
};
Status create_region_invocation(void *value, mem::AllocatorRef allocator,
                                mem::BufferView workspace,
                                void **output) noexcept {
  *output = nullptr;
  void *storage = allocator.allocate(sizeof(Invocation), alignof(Invocation));
  if (!storage)
    return Status::ResourceExhausted(
        "ggml CUDA region invocation allocation failed");
  const auto &artifact = static_cast<Artifact *>(value)->native;
  auto *invocation = ::new (storage) Invocation{artifact.vtable, nullptr};
  *output = invocation;
  return create_invocation(value, allocator, workspace, &invocation->state);
}
void destroy_region_invocation(void *value,
                               mem::AllocatorRef allocator) noexcept {
  auto *invocation = static_cast<Invocation *>(value);
  if (!invocation)
    return;
  invocation->vtable->destroy_invocation(invocation->state, allocator);
  invocation->~Invocation();
  allocator.deallocate(invocation, sizeof(Invocation), alignof(Invocation));
}
compute::detail::EnqueueResult
submit(void *value, void *lane, compute::Queue &queue,
       std::span<const compute::ConstTensorView> inputs,
       std::span<const compute::TensorView> outputs) noexcept {
  const auto &artifact = static_cast<Artifact *>(value)->native;
  return artifact.vtable->shared_submit(artifact.state,
                                        static_cast<Invocation *>(lane)->state,
                                        queue, inputs, outputs);
}
const ProviderRegionPreparedVTable kPrepared{
    .destroy_prepared = &destroy,
    .alias_support = &alias,
    .create_invocation = &create_region_invocation,
    .destroy_invocation = &destroy_region_invocation,
    .shared_submit = &submit};

compute::ProviderPrepareOutcome
compile(void *context, const RegionCompileRequest &request,
        mem::AllocatorRef allocator, ProviderRegionPrepared *output) noexcept {
  *output = {};
  auto status = qualify(context, request);
  if (!status.ok())
    return compute::ProviderPrepareOutcome::unsupported(std::move(status));
  try {
    native::Recipe recipe;
    std::vector<ValueId> values(request.inputs.begin(), request.inputs.end());
    for (std::uint32_t i = 0; i < values.size(); ++i)
      recipe.inputs.push_back(i);
    for (const auto node : request.nodes)
      for (std::size_t port = 0;
           port < request.graph->node_output_count(node).value(); ++port)
        values.push_back(request.graph->result(node, port).value());
    const auto local = [&](ValueId value) -> std::uint32_t {
      return static_cast<std::uint32_t>(std::ranges::find(values, value) -
                                        values.begin());
    };
    for (const auto id : values)
      recipe.values.push_back(request.graph->value_description(id).value());
    for (const auto node : request.nodes) {
      native::Node lowered{request.graph->operation(node).value(), {}, {}};
      for (std::size_t port = 0;
           port < request.graph->node_output_count(node).value(); ++port)
        lowered.outputs.push_back(
            local(request.graph->result(node, port).value()));
      for (std::size_t i = 0; i < request.graph->node_input_count(node).value();
           ++i) {
        const auto id = local(request.graph->node_input(node, i).value());
        if (id >= values.size())
          return compute::ProviderPrepareOutcome::error(Status::InvalidArgument(
              "ggml CUDA region misses an input boundary"));
        lowered.inputs.push_back(id);
      }
      recipe.nodes.push_back(std::move(lowered));
    }
    for (const auto id : request.outputs)
      recipe.outputs.push_back(local(id));
    const auto packing = ggml_shared::pack_constants(context, request, values, recipe,
        &native::widen_bfloat_constant, &native::pack_matrix_constant);
    if (packing.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
      return packing;
    std::size_t checked_copy_bytes = 0;
    std::uint32_t dispatches = 1;
    const auto add_checked_copy = [&](const compute::TensorDesc &description) {
      const auto bytes = description.required_bytes().value();
      if (bytes > SIZE_MAX - checked_copy_bytes ||
          dispatches == std::numeric_limits<std::uint32_t>::max())
        return false;
      checked_copy_bytes += bytes;
      if (bytes != 0) ++dispatches;
      return true;
    };
    bool checked = false;
    for (const auto &node : recipe.nodes) {
      const auto *gather = node.operation.get_if<compute::Gather>();
      const auto elements = node.operation.custom_as<compute::model_ops::GatherElements>();
      const bool grouped = node.operation.custom_as<compute::model_ops::GroupedMatMul>().has_value();
      if (!grouped && !(gather && gather->bounds == compute::IndexBoundsPolicy::kChecked) &&
          !(elements && elements->bounds == compute::IndexBoundsPolicy::kChecked))
        continue;
      checked = true;
      if (!add_checked_copy(recipe.values[node.inputs[grouped ? 2 : 1]]))
        return compute::ProviderPrepareOutcome::error(
            Status::OutOfRange("ggml CUDA checked copy cost overflows"));
    }
    if (checked)
      for (const auto id : recipe.outputs)
        if (!add_checked_copy(recipe.values[id]))
          return compute::ProviderPrepareOutcome::error(
              Status::OutOfRange("ggml CUDA checked output cost overflows"));
    void *storage = allocator.allocate(sizeof(Artifact), alignof(Artifact));
    if (!storage)
      return compute::ProviderPrepareOutcome::resource_declined(
          Status::ResourceExhausted(
              "ggml CUDA region artifact allocation failed"));
    auto *artifact = ::new (storage) Artifact;
    const auto outcome = native::compile(context, std::move(recipe), allocator,
                                         &artifact->native);
    if (!artifact->native.state) {
      artifact->~Artifact();
      allocator.deallocate(artifact, sizeof(Artifact), alignof(Artifact));
      return outcome;
    }
    *output = {.vtable = &kPrepared,
               .state = artifact,
               .properties = {.workspace = {},
                              .persistent_bytes = std::nullopt,
                              // Indexed consumers use private safe IDs and
                              // publish all outputs only after device checks.
                              // Native scratch/materialization remains unknown.
                              .copy_bytes = checked_copy_bytes,
                              .synchronization_count = 2,
                              .dispatch_count = dispatches,
                              .runtime = native::kRuntime,
                              .invocation_private_bytes = std::nullopt}};
    return outcome;
  } catch (const std::bad_alloc &) {
    return compute::ProviderPrepareOutcome::error(
        Status::ResourceExhausted("ggml CUDA region recipe allocation failed"));
  } catch (const std::exception &error) {
    return compute::ProviderPrepareOutcome::error(
        Status::Internal(error.what()));
  }
}
const RegionProviderVTable kRegion{
    .propose = &propose, .propose_resources = &resources, .compile = &compile};
} // namespace

compute::Provider provider() noexcept {
  return native::with_extension(kRegionProviderExtensionId, &kRegion);
}
} // namespace hyle::graph::ggml_cuda
