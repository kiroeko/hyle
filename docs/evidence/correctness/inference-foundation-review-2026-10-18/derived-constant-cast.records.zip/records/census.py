from pathlib import Path
import importlib.util,json,os
spec=importlib.util.spec_from_file_location('guarded_builder',Path(__file__).with_name('build.py'))
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ROOT=b.ROOT;OUT=b.OUT
def cpu():
 b.compile(OUT/'census/cpu-provider.cc','census-cpu-provider')
 b.run('census-cpu-probe-compile',[b.c.CL,*b.cpu_flags,'/DHYLE_MHC_CPU',OUT/'census/probe.cc','/Fo'+str(OUT/'census-cpu-probe.obj')])
 cmd=next(x['command']for x in reversed(b.records)if x['tag']=='cpu-link')
 omit={str(OUT/n)for n in ('cpu-provider.obj','cpu-tests.obj')}
 cmd=[x for x in cmd if x not in omit and not x.startswith(('/OUT:','/MAP:'))and not x.endswith(('gtest_main.lib','gtest.lib'))]
 b.run('census-cpu-link',[*cmd,OUT/'census-cpu-provider.obj',OUT/'census-cpu-probe.obj','/OUT:'+str(OUT/'census-cpu.exe'),'/MAP:'+str(OUT/'census-cpu.map')])
 b.run('census-cpu',[OUT/'census-cpu.exe'])
def cuda():
 forced=[x for x in b.cuda_cc if x.lower().startswith('/fi')]
 b.run('census-cuda-provider-compile',[b.c.CL,*b.cuda_flags,*forced,OUT/'census/cuda-provider.cc','/Fo'+str(OUT/'census-cuda-provider.obj')])
 b.compile(OUT/'census/probe.cc','census-cuda-probe',True)
 cmd=next(x['command']for x in reversed(b.records)if x['tag']=='cuda-link')
 omit={str(OUT/n)for n in ('cuda-provider.obj','cuda-tests.obj')}
 cmd=[x for x in cmd if x not in omit and not x.startswith(('/OUT:','/MAP:'))and not x.endswith(('gtest_main.lib','gtest.lib'))]
 env=dict(b.c.ENV);toolkit=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
 paths=[str(toolkit/'bin/x64'),str(toolkit/'bin'),str(ROOT/'.scratch/build-compute-v2-dev/bin')]+[str(Path(x).parent)for x in cmd if x.endswith('.lib')and Path(x).is_absolute()]
 env['PATH']=os.pathsep.join(dict.fromkeys(paths))+os.pathsep+env['PATH']
 b.run('census-cuda-link',[*cmd,OUT/'census-cuda-provider.obj',OUT/'census-cuda-probe.obj','/OUT:'+str(OUT/'census-cuda.exe'),'/MAP:'+str(OUT/'census-cuda.map')],env)
 b.run('census-cuda',[OUT/'census-cuda.exe'],env)
if __name__=='__main__':cpu();cuda()
