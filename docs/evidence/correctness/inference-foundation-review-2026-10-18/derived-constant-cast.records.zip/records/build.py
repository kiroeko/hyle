from pathlib import Path
import importlib.util,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('guarded_cpu_cache',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
cfg=dict(c.PINS['mixed'],folder=Path('mixed'))
cpu_flags=c.hyle_flags(cfg)+['/I'+str(ROOT),'/I'+str(ROOT/'src/graph'),'/I'+str(ROOT/'src/compute_provider_ggml')]
cuda_cache=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/commands.json').read_text())
cuda_cc=next(x['command'] for x in reversed(cuda_cache)if x['tag']=='canonical-compile')
cuda_flags=[x for x in cuda_cc[1:]if not x.lower().startswith(('/fo','/fp','/fi'))and not x.endswith(('.cc','.cpp'))]
records=json.loads((OUT/'commands.json').read_text())if(OUT/'commands.json').exists()else[]
def run(tag,cmd,env=None):
 cmd=list(map(str,cmd));stem=str(len(records)+1)+'-'+tag;start=time.monotonic()
 p=subprocess.run(cmd,cwd=ROOT,env=env or c.ENV,capture_output=True,timeout=180)
 (OUT/(stem+'.stdout.log')).write_bytes(p.stdout);(OUT/(stem+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-start));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(stem,p.returncode,p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-1200:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
def compile(source,stem,cuda=False):
 run(stem+'-compile',[c.CL,*(cuda_flags if cuda else cpu_flags),ROOT/source,'/Fo'+str(OUT/(stem+'.obj'))])
def products():
 for name in ('executable','constant_artifact','leased_invocation','lease_submission','region_access'):compile('src/graph/'+name+'.cc','graph-'+name)
 compile('src/compute_provider_ggml/ggml_cpu_provider.cc','cpu-provider')
 compile('src/graph_route_cpu/ggml_region.cc','cpu-region')
 compile('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','cuda-region',True)
def cuda_provider():
 forced=[x for x in cuda_cc if x.lower().startswith('/fi')]
 run('cuda-provider-compile',[c.CL,*cuda_flags,*forced,ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','/Fo'+str(OUT/'cuda-provider.obj')])
def tests():
 compile('tests/graph_route_cpu/graph_test.cc','cpu-tests')
 compile('tests/graph_route_cuda/ggml_test.cc','cuda-tests',True)
def graph_objects():
 return [OUT/('graph-'+name+'.obj')for name in ('executable','constant_artifact','leased_invocation','lease_submission','region_access')]
def cpu_link():
 cache=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/commands.json').read_text())
 ld=next(x['command']for x in cache if x['tag']=='7-link')
 omit={str(ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla'/n)for n in ('consumer.obj','provider.obj')}
 cmd=[x for x in ld if x not in omit and not x.startswith(('/OUT:','/MAP:'))]
 libs=[c.BASE/'bin'/name for name in ('hyle_graph_route_cpu.lib','hyle_graph_provider_onednn.lib')]+[c.BASE/'lib'/name for name in ('gtest_main.lib','gtest.lib')]
 run('cpu-link',[*cmd,*graph_objects(),OUT/'cpu-provider.obj',OUT/'cpu-region.obj',OUT/'cpu-tests.obj',*libs,'/OUT:'+str(OUT/'cpu-tests.exe'),'/MAP:'+str(OUT/'cpu-tests.map')])
def cuda_link():
 ld=next(x['command']for x in reversed(cuda_cache)if x['tag']=='canonical-link')
 omit={str(ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/canonical.obj'),str(ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cuda-region.after.obj'),str(ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/provider.obj')}
 cmd=[x for x in ld if x not in omit and not x.startswith(('/OUT:','/MAP:'))]
 env=dict(c.ENV)
 toolkit=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
 paths=[str(ROOT/'.scratch/build-compute-v2-dev/bin'),str(toolkit/'bin'),str(toolkit/'bin/x64')]+[str(Path(x).parent)for x in cmd if x.endswith('.lib')and Path(x).is_absolute()]
 env['PATH']=os.pathsep.join(dict.fromkeys(paths))+os.pathsep+env['PATH']
 run('cuda-link',[*cmd,*graph_objects(),OUT/'cuda-region.obj',OUT/'cuda-provider.obj',OUT/'cuda-tests.obj','/OUT:'+str(OUT/'cuda-tests.exe'),'/MAP:'+str(OUT/'cuda-tests.map')],env)
def cpu_test():run('cpu-test',[OUT/'cpu-tests.exe','--gtest_filter=CpuDefaultGraph.ImmutableBfloatCastFeedsOriginalGemmRoute','--gtest_color=no'])
def cuda_test():
 env=dict(c.ENV);toolkit=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
 ld=next(x['command']for x in reversed(cuda_cache)if x['tag']=='canonical-link')
 paths=[str(toolkit/'bin/x64'),str(toolkit/'bin'),str(ROOT/'.scratch/build-compute-v2-dev/bin')]+[str(Path(x).parent)for x in ld if x.endswith('.lib')and Path(x).is_absolute()]
 env['PATH']=os.pathsep.join(dict.fromkeys(paths))+os.pathsep+env['PATH']
 run('cuda-test',[OUT/'cuda-tests.exe','--gtest_filter=CudaDefaultGraph.ImmutableBfloatCastFeedsOriginalGemmRoute','--gtest_color=no'],env)
if __name__=='__main__':
 for name in sys.argv[1:]or['products']:globals()[name]()
