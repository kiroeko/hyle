from pathlib import Path
import importlib.util, json, os, sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build', HERE.parent/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)

def link(backend,stage):
    command=next(x['command'] for x in reversed(b.records) if x['tag']==backend+'-link')
    command=[x for x in command if not x.startswith(('/OUT:','/MAP:'))]
    command=[str(HERE/(backend+'-tests.obj')) if x==str(b.OUT/(backend+'-tests.obj')) else x for x in command]
    env=dict(b.c.ENV)
    if backend=='cuda':
        paths=[str(Path(x).parent) for x in command if x.endswith('.lib') and Path(x).is_absolute()]
        paths+=['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',str(b.ROOT/'.scratch/build-compute-v2-dev/bin')]
        env['PATH']=os.pathsep.join(dict.fromkeys(paths))+os.pathsep+env['PATH']
    exe=HERE/(backend+'-'+stage+'.exe')
    b.run('control-'+backend+'-'+stage+'-link',[*command,'/OUT:'+str(exe),'/MAP:'+str(exe.with_suffix('.map'))],env)
    b.run('control-'+backend+'-'+stage+'-test',[exe,'--gtest_filter='+('CpuDefaultGraph' if backend=='cpu' else 'CudaDefaultGraph')+'.PreparedCastKeepsIncomingControlForDataOnlyConsumer','--gtest_color=no'],env)

if __name__=='__main__':
    for stage in sys.argv[1:]:
        if stage=='cpu-compile':b.run('control-cpu-compile',[b.c.CL,*b.cpu_flags,b.ROOT/'tests/graph_route_cpu/graph_test.cc','/Fo'+str(HERE/'cpu-tests.obj')])
        elif stage=='cuda-compile':b.run('control-cuda-compile',[b.c.CL,*b.cuda_flags,b.ROOT/'tests/graph_route_cuda/ggml_test.cc','/Fo'+str(HERE/'cuda-tests.obj')])
        elif stage=='product':b.compile('src/graph/executable.cc','graph-executable')
        else:link(*stage.split('-',1))
