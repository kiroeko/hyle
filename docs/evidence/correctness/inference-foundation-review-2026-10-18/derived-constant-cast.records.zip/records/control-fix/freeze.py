from pathlib import Path
import difflib, hashlib, json, shutil, zipfile

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parents[1]
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def main():
    for name in ('summary.json','source-sha.json','source.diff','artifacts.json'):
        backup=HERE/('original-'+name)
        if not backup.exists():shutil.copy2(OUT/name,backup)
    original=json.loads((HERE/'original-source-sha.json').read_text())
    for name in original:
        path=OUT/'applied'/name
        path.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/name,path)
    # Records 54/56 and 59 used this exact helper before the test's required
    # multi-target replay preparation was added; its pre-fix assertion ran first.
    helper=(ROOT/'tests/graph_ggml_constant_cast_test.h').read_bytes()
    helper=helper.replace(b'  ASSERT_TRUE(invocation.prepare_replay(queues).ok());\n',b'')
    (HERE/'test-helper.before-replay-fix.h').write_bytes(helper)
    hashes={name:sha(OUT/'applied'/name) for name in original}
    dump(OUT/'source-sha.json',hashes)
    delta=[]
    for name in hashes:
        before=OUT/'baseline'/name
        a=before.read_text().splitlines(keepends=True) if before.exists() else []
        b=(OUT/'applied'/name).read_text().splitlines(keepends=True)
        delta+=difflib.unified_diff(a,b,fromfile='before/'+name,tofile='after/'+name)
    (OUT/'source.diff').write_text(''.join(delta),encoding='utf-8')
    original_src=(HERE/'executable.before.cc').read_text().splitlines(keepends=True)
    fixed=(ROOT/'src/graph/executable.cc').read_text().splitlines(keepends=True)
    (HERE/'scheduling-fix.diff').write_text(''.join(difflib.unified_diff(original_src,fixed,fromfile='prepared-output-before.cc',tofile='prepared-output-fixed.cc')),encoding='utf-8')
    summary=json.loads((HERE/'original-summary.json').read_text())
    summary['status']='implemented_focused_tests_pass_including_prepared_output_control_fix_no_performance_claim'
    summary['native_closure']='PlanState has six direct .cc consumers: graph/executable.cc, constant_artifact.cc, leased_invocation.cc, lease_submission.cc, region_access.cc, and graph_route_cpu_cuda/invocation.cc. The five generic Graph TUs were freshly compiled/linked together in these ordinary CPU/CUDA tests. Joint CPU+CUDA invocation.cc is not linked by these ordinary tests; any future joint closure MUST freshly compile it for this private layout. Final scheduling-only correction changes no layout and freshly compiles executable.cc only. CPU provider/callback, CPU/CUDA adapters, and CUDA provider are fresh matched versions; native SDK/tensor objects reused. No Recipe field/public vtable layout change.'
    summary['tests']['incoming_control_regression']={
        'scope':'Two targets: native TopK A on target0 -> control-only dependency into immutable CastF32 plus independent Neg in one ggml target1 region -> data-only TopK consumer on target0. Consumer does not read Neg. Both targets are actual default Contexts; packed_constant_count=1 and region_count=1 asserted.',
        'before':'56-control-cpu-before-test.stdout.log FAIL: A and data-only consumer incorrectly share segment 0. Saved executable.before.cc and its object. No native race needed to expose the missing schedule/segment edge.',
        'fix':'Private helper restores prepared instance producer from the unchanged logical value producer through current plan.node_steps in BOTH schedule_steps and build_segments; visit_sources and final segment dependency emission use the latter table. No native output write or hot Copy reinstated.',
        'CPU':'62-control-cpu-after-test.stdout.log 1/1 PASS',
        'CUDA':'65-control-cuda-after-test.stdout.log 1/1 PASS',
        'checks':'Explicit A->region and region->consumer segment dependency assertions; two phases of real checked submit/wait plus independent Neg and TopK payloads.',
        'old_test_source_difference':'Pre-fix test omitted prepare_replay; it failed the segment assertion before reaching submit. First fixed-source run passed metadata assertions then reported the harness missing prepare_replay (59 log); adding that existing API call yielded final passes. Exact preceding helper snapshot retained.'}
    summary['tests']['final_source_scope']='Original six-mode tests 51/53 predate only the producer-table correction and added control regression. Final source was run only through the new focused control regression, as requested; no broad rerun/census/timing.'
    summary['actual_GLM_census']['source_limit']+=' Census also predates the prepared-output producer-table scheduling correction, which does not alter native recipe nodes. Final numerical control tests use fixed canonical executable.cc; census was not rerun.'
    summary['failures_retained'] += [
        'Original prepared-output optimization lost incoming control -> prepared Cast -> data-only consumer ordering; pre-fix failing regression retained and producer-table fix applied.',
        'Control build wrapper first used a slash in its log tag; compiler ran but log file creation raised FileNotFoundError. Wrapper fixed and same TU rebuilt with captured output (54). No product change due to this script error.',
        '59-control-cpu-after-test failed because new multi-target test omitted prepare_replay; original segment assertions passed. Added existing replay preparation and 62/65 passed.'
    ]
    summary['historical_package']={'path':'source-results.zip','bytes':(OUT/'source-results.zip').stat().st_size,'sha256':sha(OUT/'source-results.zip'),'status':'Superseded historical pre-control-fix snapshot; known scheduling bug, not final correctness evidence. Kept unchanged.'}
    summary['frozen_source_sha256']=hashes
    summary['cleanup']='artifacts-control-fixed.json gives current exact generated obj/exe/lib/exp paths/size/SHA including control regression and preserved pre-fix executable object. No deletion or commit. The previous artifacts.json is retained as an earlier identity snapshot.'
    dump(OUT/'summary.json',summary)
    generated=[]
    for path in sorted(OUT.rglob('*')):
        if path.is_file() and path.suffix.lower() in {'.obj','.exe','.exp','.lib','.pdb'}:
            generated.append({'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)})
    dump(OUT/'artifacts-control-fixed.json',generated)
    dump(HERE/'source-identities.json',{'pre_fix_executable':sha(HERE/'executable.before.cc'),'pre_fix_test_helper':sha(HERE/'test-helper.before-replay-fix.h'),'final_sources':hashes})
    package=OUT/'source-results-control-fixed.zip'
    allow={'.h','.cc','.py','.json','.log','.map','.diff','.txt','.cmake'}
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(OUT.rglob('*')):
            if path.is_file() and path.suffix.lower() in allow and '__pycache__' not in path.parts:
                archive.write(path,path.relative_to(OUT).as_posix())
    print(json.dumps({'package':str(package),'bytes':package.stat().st_size,'sha256':sha(package),'artifacts':len(generated),'sources':hashes},indent=2))

if __name__=='__main__':main()
