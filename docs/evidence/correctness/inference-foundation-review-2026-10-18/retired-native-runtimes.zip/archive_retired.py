from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


files = [f'include/hyle/graph/cpu_{api}.h' for api in ['apple', 'vulkan']]
files += [f'src/graph_route_cpu_{api}/{name}' for api in ['apple', 'vulkan']
          for name in ['CMakeLists.txt', 'compile.cc', 'invocation.cc', 'paged.h', 'plan.h']]
files += ['src/graph_native_shared/compile.h', 'src/graph_native_shared/plan.h',
          'src/graph_batch/native_paged_nodes.h', 'src/graph_batch/native_paged_slots.h',
          'src/graph/joint_pipeline.h', 'tests/graph/joint_pipeline_test.cc',
          'tests/graph_route_cpu_apple/CMakeLists.txt', 'tests/graph_route_cpu_vulkan/CMakeLists.txt']
assert len(files) == len(set(files)) == 20
rows = [identity(ROOT / name) for name in files]
helper = identity(ROOT / 'test.ps1')
plan = dict(reason='Retire duplicate CPU+Apple/Vulkan Plan/Invocation/driver after real consumers migrated; no compatibility aliases.',
            commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            files=rows, historical_cleanup_helper=helper)
payload = (json.dumps(plan, ensure_ascii=False, indent=2) + '\n').encode()
archive = DEST / 'retired-native-runtimes.zip'
assert not archive.exists(), 'Do not overwrite a frozen source archive'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('retirement-plan.json', payload)
    for row in rows:
        z.write(ROOT / row['path'], 'source/' + row['path'])
    z.write(ROOT / 'test.ps1', 'historical/test.ps1')
    z.write(__file__, 'archive_retired.py')
with zipfile.ZipFile(archive) as z:
    assert z.read('retirement-plan.json') == payload
    for row in rows:
        data = z.read('source/' + row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
(OUT / 'retirement-plan.json').write_bytes(payload)
(OUT / 'retirement-archive-receipt.json').write_text(json.dumps(identity(archive), indent=2) + '\n')
print(json.dumps(dict(files=len(rows), source_bytes=sum(r['bytes'] for r in rows), archive=identity(archive))))
