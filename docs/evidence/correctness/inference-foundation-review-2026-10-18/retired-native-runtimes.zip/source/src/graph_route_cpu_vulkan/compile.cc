#include "plan.h"
#include "../graph_native_shared/compile.h"
#include "hyle/compute/detail/vulkan_batch_access.h"

namespace hyle::graph::cpu_vulkan {
namespace {
namespace native = compute::vulkan;

// Endpoint-specific native operations only. Reachability, port mapping,
// constants, effects, dependencies and physical-plan formation are shared.
struct Adapter final {
  using Plan = detail::Plan;
  using Environment = cpu_vulkan::Environment;
  using Options = CompileOptions;
  using Report = CompileReport;
  using FragmentReport = cpu_vulkan::FragmentReport;
  static constexpr bool contiguous_native_outputs = false;
  static bool endpoints_valid(const Environment &environment) noexcept {
    return environment.vulkan != nullptr && environment.vulkan->valid() &&
           environment.device != nullptr && environment.device->valid() &&
           environment.staging != nullptr && environment.staging->valid();
  }
  static Result<native::Tensor> upload_constant(
      Plan &plan, compute::TensorDesc description,
      compute::ConstTensorView source) noexcept {
    const auto &environment = plan.environment;
    HYLE_ASSIGN_OR_RETURN(auto tensor, environment.device->allocate(description,
        {.resource_budget = plan.budget, .category = compute::ResourceBudgetCategory::kConstant}));
    HYLE_ASSIGN_OR_RETURN(auto bytes, description.required_bytes());
    HYLE_ASSIGN_OR_RETURN(auto transfer, native::TransferSlot::create(
        *environment.vulkan, *environment.staging, std::max<std::size_t>(1, bytes),
        {.resource_budget = plan.budget, .category = compute::ResourceBudgetCategory::kConstant}));
    HYLE_ASSIGN_OR_RETURN(auto completion, transfer.upload(tensor, source));
    HYLE_RETURN_IF_ERROR(completion.wait());
    return tensor;
  }
  static Result<native::Program> prepare_page(
      const Plan &plan, const batch::NativePagedNodeBinding &binding) noexcept {
    return native::detail::PagedBatchAccess::prepare_program(
        *plan.environment.vulkan, binding.program, binding.layout, plan.workload);
  }
  static Result<native::Program> compile_native(
      const Plan &plan, const Graph &graph,
      std::span<const native::Tensor> constants, const Options &options,
      FragmentReport *report) noexcept {
    return vulkan::compile(*plan.environment.vulkan, graph, constants,
        {.custom = options.custom, .report = report != nullptr ? &report->vulkan : nullptr,
         .workload = plan.workload});
  }
};
static_assert(kCpuTarget == ExecutionTargetId{1});
static_assert(kVulkanTarget == ExecutionTargetId{0});
} // namespace

Result<Executable> compile(const Graph &graph, Environment environment,
                           CompileOptions options, CompileReport *report) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto plan, graph::detail::compile_native<Adapter>(
      graph, environment, std::move(options), report));
  return Executable(std::move(plan));
}
} // namespace hyle::graph::cpu_vulkan
