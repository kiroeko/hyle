#pragma once

#include <optional>
#include <vector>

#include "../graph/compile_internal.h"
#include "../graph/joint_pipeline.h"
#include "hyle/compute/detail/context_ref.h"
#include "hyle/graph/batch.h"
#include "hyle/mem/std_allocator.h"

namespace hyle::graph::detail {

// Common cold boundary/fragment representation. Native Tensor and Program
// keep their original owners and ABI; sharing this plan never materializes a
// native value into caller storage or adds an executor.
template <class T>
using NativePlanVector = std::vector<T, mem::StdAllocator<T>>;

template <class NativeTensor> struct NativePlanValue final {
  ValueId id;
  compute::TensorDesc description, carrier;
  compute::ResourceBudget::Reservation constant_charge;
  mem::Buffer constant_storage;
  compute::ConstTensorView constant;
  ConstantPolicy constant_policy = ConstantPolicy::kBorrow;
  std::optional<NativeTensor> native_constant;
  graph::Executable repack;
  ValueId repack_input, repack_output;
  bool cpu_use = false, native_use = false, published = false,
       fragment_output = false;
  ExecutionTargetId producer;
};

template <class NativeProgram> struct NativePlanFragment final {
  explicit NativePlanFragment(mem::AllocatorRef allocator)
      : inputs(mem::StdAllocator<std::size_t>(allocator)),
        outputs(mem::StdAllocator<std::size_t>(allocator)),
        dependencies(mem::StdAllocator<std::size_t>(allocator)),
        cpu_inputs(mem::StdAllocator<ValueId>(allocator)),
        cpu_outputs(mem::StdAllocator<ValueId>(allocator)) {}
  ExecutionTargetId target;
  NativePlanVector<std::size_t> inputs, outputs, dependencies;
  NativePlanVector<ValueId> cpu_inputs, cpu_outputs;
  graph::Executable cpu;
  NativeProgram program;
  compute::ResourceBudget::Reservation private_storage;
};

template <class NativeProgram> struct NativePagedFragment final {
  std::size_t fragment = 0;
  batch::NativePagedNodeBinding binding;
  NativeProgram initial_program;
};

template <class Environment, class NativeTensor, class NativeProgram>
struct NativePlan {
  using Tensor = NativeTensor;
  using Value = NativePlanValue<NativeTensor>;
  using Fragment = NativePlanFragment<NativeProgram>;
  using PagedFragment = NativePagedFragment<NativeProgram>;

  explicit NativePlan(mem::AllocatorRef owner)
      : allocator(owner), values(mem::StdAllocator<Value>(owner)),
        inputs(mem::StdAllocator<std::size_t>(owner)),
        fragments(mem::StdAllocator<Fragment>(owner)),
        paged(mem::StdAllocator<PagedFragment>(owner)), effect_bindings(owner),
        pipeline(owner),
        pipeline_stages(mem::StdAllocator<NativePipelineStage>(owner)) {}
  mem::AllocatorRef allocator;
  compute::ResourceBudget budget;
  compute::WorkloadContext workload;
  Environment environment;
  compute::detail::ContextRef cpu_context;
  NativePlanVector<Value> values;
  NativePlanVector<std::size_t> inputs;
  NativePlanVector<Fragment> fragments;
  NativePlanVector<PagedFragment> paged;
  EffectBindings effect_bindings;
  JointPipelinePlan pipeline;
  NativePlanVector<NativePipelineStage> pipeline_stages;
  std::size_t host_workspace_bytes = 0;
};

} // namespace hyle::graph::detail
