#pragma once

#include "hyle/graph/cpu_apple.h"
#include "../graph_native_shared/plan.h"

namespace hyle::graph::cpu_apple::detail {
template <class T> using Vector = graph::detail::NativePlanVector<T>;
using CommonPlan = graph::detail::NativePlan<Environment, mlx::core::array, compute::apple::Program>;
using Value = CommonPlan::Value;
using Fragment = CommonPlan::Fragment;
using PagedFragment = CommonPlan::PagedFragment;
struct Plan final : CommonPlan {
  using CommonPlan::CommonPlan;
};
} // namespace hyle::graph::cpu_apple::detail
