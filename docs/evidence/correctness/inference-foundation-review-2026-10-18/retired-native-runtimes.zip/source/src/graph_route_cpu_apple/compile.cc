#include "plan.h"
#include "../graph_native_shared/compile.h"
#include "hyle/compute/detail/apple_batch_access.h"

namespace hyle::graph::cpu_apple {
namespace {
namespace native = compute::apple;

// Endpoint-specific native operations only. Reachability, port mapping,
// constants, effects, dependencies and physical-plan formation are shared.
struct Adapter final {
  using Plan = detail::Plan;
  using Environment = cpu_apple::Environment;
  using Options = CompileOptions;
  using Report = CompileReport;
  using FragmentReport = cpu_apple::FragmentReport;
  static constexpr bool contiguous_native_outputs = true;
  static bool endpoints_valid(const Environment &environment) noexcept {
    return environment.apple != nullptr && environment.apple->valid() &&
           environment.native != nullptr && environment.native->valid();
  }
  static Result<mlx::core::array> upload_constant(
      Plan &plan, compute::TensorDesc description,
      compute::ConstTensorView source) noexcept {
    HYLE_ASSIGN_OR_RETURN(auto tensor, plan.environment.native->allocate(
        description, plan.budget, compute::ResourceBudgetCategory::kConstant));
    HYLE_RETURN_IF_ERROR(plan.environment.native->copy_from_host(tensor, source));
    return tensor;
  }
  static Result<native::Program> prepare_page(
      const Plan &plan, const batch::NativePagedNodeBinding &binding) noexcept {
    return native::detail::PagedBatchAccess::prepare_program(
        *plan.environment.apple, binding.program, binding.layout, plan.workload);
  }
  static Result<native::Program> compile_native(
      const Plan &plan, const Graph &graph,
      std::span<const mlx::core::array> constants, const Options &options,
      FragmentReport *report) noexcept {
    return apple::compile(*plan.environment.apple, graph, constants,
        {.custom = options.custom, .report = report != nullptr ? &report->apple : nullptr,
         .workload = plan.workload, .contiguous_outputs = true});
  }
};
static_assert(kCpuTarget == ExecutionTargetId{1});
static_assert(kAppleTarget == ExecutionTargetId{0});
} // namespace

Result<Executable> compile(const Graph &graph, Environment environment,
                           CompileOptions options, CompileReport *report) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto plan, graph::detail::compile_native<Adapter>(
      graph, environment, std::move(options), report));
  return Executable(std::move(plan));
}
} // namespace hyle::graph::cpu_apple
