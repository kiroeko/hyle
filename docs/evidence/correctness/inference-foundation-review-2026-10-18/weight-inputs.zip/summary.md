# Original Graph weight inputs and CPU+CUDA runtime retirement

This focused batch unifies actual immutable CUDA WeightBatch bindings with the
original Graph Invocation. It does not complete the architecture refactor.

- Cold source planning follows actual physical readers and exact Queue groups.
  Actual first accepted consumers import pending upload events once per group;
  explicit host readers retain HostWaitPolicy. No second Invocation, result
  owner, scheduler or source-to-Graph retirement subscription was added.
- Input ownership is independent of leased/page payload ownership. Source error
  reconciliation occurs after successful actual consuming suffix retirement.
  The public Completion now preserves terminal diagnostics from retirement.
- Original resource reporting supports arbitrary storage domains. CPU+CUDA's
  separate Invocation/Results/RunState/progress files were archived and deleted
  by root test.ps1; cpu_cuda.h retains only its cold environment helper.
- A real accepted CopyBatchUpdate plus public cancellation before any Graph
  suffix exposed a skipped ordered-source mapper. Common finish now maps both
  successful completions and zero-suffix errors; final observation itself is
  not counted as native acceptance. Original source controls are recoverable
  after real retirement, with canceled data still unavailable.
- The page batch's pending mapper previously borrowed a stack Call. It now
  borrows the actual retained BatchResources attachment.

Validation reused existing SDK/kernel caches on Windows RTX 4070. Ten updated
core units, two typed-weight units and selected test units were freshly built;
96/96 matched host regressions passed. Four default CPU/CUDA public consumers
(weights sample, contracts, finite family, 65-step sampling), plus an actual
pending page success/cancel probe passed. Exact commands, source/object hashes,
closures, original failures and final results are recorded in windows/ and cuda/.

The sample's initial missing QueueBindings and the contracts test's incorrect
foreign-resource compile-stage assumption were corrected in consumers. Actual
foreign Buffer plus original CUDA Queue is rejected by cold prepare; no extra
wrapper-only compile gate was added. After public-header trimming, three units
were rebuilt and both weight consumers relinked; native math was not rerun for
that declaration/dependency-only trim. Both final maps contain no old hybrid
Invocation/Results/RunState symbols or old runtime objects.

Configure-only actual manifest checks passed for cold CPU+CUDA assembly, test
progress fixtures and explicit graph+sched progress selection. The complete CPU
route still legitimately carries Sched through compute_stream. The cold hybrid
helper itself has no Sched edge. No SDK was configured or built by these checks.

Not claimed: native performance results, full late-error injection matrix,
direct published-source/View qualification, Apple/Linux execution, remaining
Apple/Vulkan runtime migration, or complete model/function coverage. Qwen's
independent numerical differences and fair throughput acceptance remain open.
Evidence excludes reproducible images/maps and objects; all objects, raw data
and dependency caches remain local. cleanup.json lists only exact disposable
images/maps/exports, verified before deletion by root test.ps1.
