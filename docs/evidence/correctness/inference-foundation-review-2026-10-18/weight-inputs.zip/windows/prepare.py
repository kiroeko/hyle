"""Prepare exact existing host recipes only. This file never compiles or links.

Weight API and final core object identities must be supplied by the parent
before a subsequent driver may execute any of these proposed commands.
"""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = OUT.parents[1]
BASE = ARCH / 'generic-progress'

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def last(stage, tag):
    return next(row for row in reversed(read(stage / 'commands.json'))
                if row['tag'] == tag and row['exit'] == 0)

def rebase_command(original, source, output):
    command = []
    for value in original:
        if value.lower().startswith('/fo'):
            command.append('/Fo' + str(output))
        elif value.lower().endswith(('.cc', '.cpp', '.cxx')):
            command.append(str(ROOT / source))
        else:
            command.append(value)
    return command

OUT.mkdir(parents=True, exist_ok=True)
recipes = []
core_names = ['executable', 'submission', 'resources', 'region_access',
              'constant_artifact', 'lease_submission']
for name in core_names:
    source = 'src/graph/' + name + '.cc'
    row = last(BASE / 'windows', name + '-compile')
    recipes.append(dict(owner='root core; execute only if new layout changes require it',
        source=source, current_sha256=sha(ROOT / source),
        command=rebase_command(row['command'], source, OUT / (name + '.obj')),
        origin=str(BASE / 'windows/commands.json') + ':' + row['tag']))

consumer_recipe = next(row for row in read(BASE / 'cuda/compile-recipes.json')
                       if row['source'].replace('\\', '/') == 'tests/graph/cpu_cuda_pipeline.cc')
for source, stem in [
    ('tests/graph/cpu_cuda_contracts.cc', 'contracts'),
    ('samples/package/graph/cpu_cuda/main.cc', 'public-consumer'),
    ('tests/graph/route_symmetry_cuda.cc', 'finite-consumer'),
    ('tests/graph_route_cpu_cuda/sampling_consumer.cc', 'sampling-consumer')]:
    recipes.append(dict(owner='consumer owner; wait for migrated API/source freeze',
        source=source, current_sha256=sha(ROOT / source),
        command=rebase_command(consumer_recipe['command'], source, OUT / (stem + '.obj')),
        origin=str(BASE / 'cuda/compile-recipes.json') + ': canonical pipeline host flags',
        main='standalone actual consumer; do not link gtest_main or another consumer main'))

save('compile-recipes.json', recipes)
save('verification-plan.json', dict(
    status='prepared_not_executed_waiting_for_new_weight_API_and_matched_core',
    compiler='/W4 /WX original actual module/consumer recipes; Hyle host only',
    no_rebuild=['CUDA/ggml/ATen/oneDNN kernels', 'SDKs', 'models'],
    inherited_core=[str(BASE / 'windows' / (x + '.obj')) for x in
        [*core_names, 'retained_completion', 'progress']],
    inherited_shared_controls=dict(commands=str(BASE / 'windows/commands.json'),
        link_tag='controls-link', result=str(BASE / 'windows/summary.json')),
    actual_mixed_link_base=dict(commands=str(BASE / 'cuda/commands.json'),
        link_tag='finite-consumer-link',
        reason='Has real default CPU and native CUDA runtime/provider dependencies; the CPU-only controls closure alone cannot link the mixed contracts'),
    default_cuda_roster=dict(commands=str(BASE / 'qwen/commands.json'), link_tag='consumer-link',
        source_and_object_identities=str(BASE / 'qwen/link-identities.json'),
        reason='Default CUDA consumer must retain its actual providers. Never replace the test with explicit native-only provider to make linking or admission easier.'),
    native_reference=str(BASE / 'ggml-cache/native-closure.json'),
    native_main_and_allocator='Reuse the two audited existing explicit objects before the exact reference three libraries; do not restore legacy COUNT43 libraries/objects',
    final_link_not_generated='New weight adapter names/ABI are not frozen. Parent supplies exact new objects; derive a single source-owner replacement map before linking, never blindly concatenate old/new closures.',
    forbidden_old_runtime=['joint-invocation.obj', 'joint-progress.obj',
        'hyle_graph_route_cpu_cuda invocation/progress archive members'],
    optional_cold_compile_helper='May retain old compile.cc only while still a real current public assembly function; delete it when parent removes that API, without an alias or compatibility shim.',
    pending_fresh=['New neutral weight input adapter owner(s)',
        'src/compute_route_cuda/weights.cc if its prepared dependency/owner interface changes',
        'Source or compute operation owner only when the frozen API actually changes its ABI',
        'Every direct reader of changed PlanState/InvocationState; otherwise reuse matched generic-progress objects'],
    focused_runs=['Migrated cpu_cuda_contracts standalone executable',
        'Original package CPU/CUDA consumer', 'Finite {1,4}x8 and missing2/quota controls',
        'Sampling TopK->Multinomial two-slot changed input only if its consumer changes'],
    results='Record exact commands/exit/stdout/stderr/source-object identities; preserve first failures; no broader model, benchmark, or unrelated tests'))

runtime_candidates = [
    ('samples/package/graph/cpu_cuda/main.cc', 'typed weight inputs, two slots, reports, results, cancellation, abandonment'),
    ('tests/graph/cpu_cuda_contracts.cc', 'includes sample setup; rejection/OOM/prefix/weight dedup/control/resource ownership'),
    ('tests/graph/route_symmetry_cuda.cc', 'finite shape parent and original old-result/quota semantics'),
    ('tests/graph_route_cpu_cuda/sampling_consumer.cc', 'TopK/Multinomial state loop, staging report, two slots')]
compile_only = [
    'tests/graph/cpu_cuda_pipeline.cc',
    'tests/graph_batch/pending_cuda_graph_risks.cc',
    'tests/compute_batch/public_hybrid_batch_consumer.cc',
    'tests/compute_batch/pending_paged_receiver_cpu_consumer.cc',
    'tests/compute_batch/encoded_page_common_consumer.cc']
save('consumer-inventory.json', dict(
    runtime_candidates=[dict(path=p, sha256=sha(ROOT / p), scope=s,
        still_uses_old_runtime=any(marker in (ROOT/p).read_text()
            for marker in ('bridge::Invocation', 'b::Invocation'))) for p,s in runtime_candidates],
    included_actual_consumer=dict(path='samples/package/graph/cpu_cuda/inference.h',
        sha256=sha(ROOT/'samples/package/graph/cpu_cuda/inference.h'),
        scope='Included by main.cc and therefore contracts.cc; CPU normalization/cast -> CUDA half gated FFN -> CPU F32 cast, one batch contains both101/102 weights'),
    compile_helper_only=[dict(path=p, sha256=sha(ROOT / p)) for p in compile_only],
    excludes='Apple/Vulkan b::Invocation and graph::batch namespace aliases are not CUDA old-runtime users',
    public_header='include/hyle/graph/cpu_cuda.h',
    old_implementation=['src/graph_route_cpu_cuda/compile.cc',
        'src/graph_route_cpu_cuda/invocation.cc', 'src/graph_route_cpu_cuda/progress.cc'],
    docs=['docs/user/graph.md:143-176,1098', 'samples/package/graph/cpu_cuda/README.md',
        'include/hyle/compute/cuda_weights.h:37-41'],
    registration=['tests/graph_route_cpu_cuda/CMakeLists.txt',
        'samples/package/graph/cpu_cuda/CMakeLists.txt', 'src/graph_route_cpu_cuda/CMakeLists.txt']))
print(json.dumps(dict(stage=str(OUT), recipes=len(recipes), compiled=False, linked=False, ran=False)))
