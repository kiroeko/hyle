"""Two actual migrated consumers, using cached host flags and native closure."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def environment(command=()):
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    from hyle_support import read_cache
    env = windows_compiler_environment(read_cache(ROOT / '.scratch/build-compute-v2-dev'))
    directories = [str(Path(v).parent) for v in command if str(v).lower().endswith('.lib')]
    directories += ['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64',
        'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',
        str(ROOT / '.scratch/build-compute-v2-dev/bin')]
    env['PATH'] = os.pathsep.join(dict.fromkeys(directories)) + os.pathsep + env['PATH']
    env['VSLANG'] = '1033'
    return env

def run(tag, command, timeout=60):
    command = list(map(str, command))
    path = OUT / 'consumer-commands.json'
    rows = json.loads(path.read_text()) if path.exists() else []
    stem = f'consumer-{len(rows)+1:02d}-' + tag
    print('START', stem, flush=True)
    started = time.monotonic()
    with (OUT/(stem+'.stdout.log')).open('wb') as stdout, (OUT/(stem+'.stderr.log')).open('wb') as stderr:
        process = subprocess.run(command, cwd=ROOT, env=environment(command),
            stdout=stdout, stderr=stderr, timeout=timeout)
    row = dict(tag=tag, command=command, exit=process.returncode,
        seconds=time.monotonic()-started, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    rows.append(row)
    save(path.name, rows)
    print('END', stem, row['exit'], flush=True)
    if process.returncode:
        print((OUT/row['stdout']).read_text(errors='replace')[-10000:])
        print((OUT/row['stderr']).read_text(errors='replace')[-10000:])
        raise SystemExit(process.returncode)

def compile_consumers():
    identities = []
    for name in ('public-consumer', 'contracts'):
        row = next(x for x in json.loads((OUT/'compile-recipes.json').read_text())
                   if Path(next(v[3:] for v in x['command'] if v.lower().startswith('/fo'))).stem == name)
        sources = [ROOT / row['source'], ROOT / 'samples/package/graph/cpu_cuda/inference.h',
            ROOT / 'samples/package/graph/cpu_cuda/main.cc', ROOT / 'include/hyle/graph/cuda.h',
            ROOT / 'include/hyle/graph/executable.h', ROOT / 'include/hyle/graph/cpu_cuda.h']
        before = [dict(path=str(p), sha256=sha(p)) for p in dict.fromkeys(sources)]
        run(name+'-compile', row['command'])
        assert before == [dict(path=str(p), sha256=sha(p)) for p in dict.fromkeys(sources)]
        obj = OUT / (name+'.obj')
        identities.append(dict(source=row['source'], before=before, unchanged=True,
            object=str(obj), object_bytes=obj.stat().st_size, object_sha256=sha(obj)))
        save('compiled-consumers.json', identities)

def compile_cold_helper():
    stage = OUT.parents[1] / 'admitted-queue-sequence/cuda'
    source = ROOT / 'src/graph_route_cpu_cuda/compile.cc'
    old = next(r['command'] for r in reversed(json.loads((stage/'commands.json').read_text()))
        if r['exit'] == 0 and any(str(v).replace('\\','/').endswith('/src/graph_route_cpu_cuda/compile.cc')
                                for v in r.get('command', [])))
    command = ['/Fo'+str(OUT/'cpu-cuda-compile.obj') if v.lower().startswith('/fo') else v for v in old]
    before = [dict(path=str(p), sha256=sha(p)) for p in
        [source, ROOT/'include/hyle/graph/cpu_cuda.h']]
    run('cpu-cuda-cold-compile', command)
    assert before == [dict(path=x['path'], sha256=sha(x['path'])) for x in before]
    save('compiled-cold-helper.json', dict(before=before, unchanged=True,
        object=str(OUT/'cpu-cuda-compile.obj'), object_sha256=sha(OUT/'cpu-cuda-compile.obj'),
        flag_origin=str(stage/'commands.json')+': src/graph_route_cpu_cuda/compile.cc'))

def link_consumer(name):
    native_stage = OUT.parent / 'cuda'
    base = next(r['command'] for r in reversed(json.loads((native_stage/'commands.json').read_text()))
                if r['tag'] == 'finite-consumer-link' and r['exit'] == 0)
    root_names = ['executable', 'submission', 'resources', 'region_access',
        'constant_artifact', 'lease_submission', 'retained_completion', 'progress',
        'input_sources', 'resource_report', 'weights', 'weight_binding']
    replacements = {n+'.obj': OUT/(n+'.obj') for n in root_names}
    if (OUT/'cpu-cuda-compile.obj').exists():
        replacements['joint-compile.obj'] = OUT/'cpu-cuda-compile.obj'
    records = json.loads((OUT/'commands.json').read_text())
    root_receipts = []
    for n in root_names:
        row = next(r for r in reversed(records) if r['tag'] == n+'-compile' and r['exit'] == 0)
        obj = next(x for x in row['objects'] if Path(x['path']).name == n+'.obj')
        assert row['unchanged'] and obj['sha256'] == sha(obj['path']), n
        root_receipts.append(dict(tag=row['tag'], object=obj, compiled_sources=row['after']))
    arguments = [base[0]]
    seen = set()
    removed = []
    for value in base[1:]:
        filename = Path(value).name
        if value.upper().startswith(('/OUT:', '/MAP:')):
            continue
        if filename == 'finite-consumer.obj' or filename == 'compute_route_cuda--weights.obj':
            removed.append(value)
            continue
        assert filename not in ('joint-invocation.obj', 'joint-progress.obj'), value
        value = str(replacements.get(filename, value))
        if value.lower() not in seen:
            arguments.append(value)
            seen.add(value.lower())
    for value in [*replacements.values(), OUT/(name+'.obj')]:
        if str(value).lower() not in seen:
            arguments.append(str(value))
            seen.add(str(value).lower())
    arguments += ['/OUT:'+str(OUT/(name+'.exe')), '/MAP:'+str(OUT/(name+'.map'))]
    inputs = [dict(path=v, bytes=Path(v).stat().st_size, sha256=sha(v)) for v in arguments
              if Path(v).is_file() and Path(v).suffix.lower() in ('.obj', '.lib')]
    save(name+'-closure.json', dict(base=str(native_stage/'commands.json')+':finite-consumer-link exit0',
        removed=removed, root_receipts=root_receipts, inputs=inputs,
        actual_default_cpu_cuda_roster=True, no_legacy_invocation_or_progress=True))
    run(name+'-link', arguments)

def run_consumer(name):
    link = next(r['command'] for r in reversed(json.loads((OUT/'consumer-commands.json').read_text()))
                if r['tag'] == name+'-link' and r['exit'] == 0)
    # Runtime DLL directories come from the actual successful link, without
    # replacing either default provider roster or introducing another SDK.
    os.environ.update(environment(link))
    run(name+'-run', [OUT/(name+'.exe')], timeout=60)

if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        compile_consumers()
    elif sys.argv[1] == 'compile-cold':
        compile_cold_helper()
    elif sys.argv[1] == 'link':
        link_consumer(sys.argv[2])
    elif sys.argv[1] == 'run':
        run_consumer(sys.argv[2])
    else:
        raise ValueError(sys.argv[1])
