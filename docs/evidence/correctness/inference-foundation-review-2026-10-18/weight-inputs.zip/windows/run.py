"""Incremental original-Invocation input dependency validation; reuse SDKs."""
from pathlib import Path
import importlib.util
import json
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = OUT.parents[1]
PRIOR = ARCH/'generic-progress/windows'
spec = importlib.util.spec_from_file_location('host_driver', PRIOR/'run.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
d = prior.driver
d.OUT = OUT
d.BASE = next(row['command'] for row in reversed(d.read(PRIOR/'commands.json'))
              if row['tag']=='controls-link' and row['exit']==0)
d.ABI_HEADERS = (*d.ABI_HEADERS, 'src/graph/input_sources.h',
    'include/hyle/graph/detail/input_source.h', 'include/hyle/graph/executable.h')

def core():
    d.core()
    for name in ['input_sources','resource_report']:
        d.compile_one('src/graph/'+name+'.cc',name,d.CORE)
    d.compile_one('src/graph_progress/progress.cc','progress',d.CORE)
    d.compile_one('src/compute/retained_completion.cc','retained_completion',d.CORE)

def weights():
    rows=d.read(ARCH/'admitted-queue-sequence/cuda/compile-recipes.json')
    recipe=next(row['command'] for row in rows if row['source']=='src/compute_route_cuda/weights.cc')
    d.compile_one('src/compute_route_cuda/weights.cc','weights',recipe)
    d.compile_one('src/graph_route_cuda/weight_binding.cc','weight_binding',recipe)

def link():
    replaced={'retained_completion.obj','progress.obj','completion_test.obj'}
    d.BASE=[d.BASE[0],str(OUT/'input_sources.obj'),str(OUT/'resource_report.obj'),*(
        str(OUT/Path(arg).name) if Path(arg).name in replaced else arg for arg in d.BASE[1:])]
    d.link()

def run():
    selected=d.read(PRIOR/'summary.json')['filter']
    d.run('controls-run',[OUT/'controls.exe','--gtest_color=no','--gtest_filter='+selected,
        '--gtest_output=json:'+str(OUT/'results.json')])
    result=d.read(OUT/'results.json')
    assert result['failures']==0 and result['errors']==0
    d.save('summary.json',dict(tests=result['tests'],failures=0,filter=selected,
        scope='matched core regression; actual CUDA/paging consumers recorded separately'))
    print(result['tests'],'passed',flush=True)

if __name__=='__main__':
    {'core':core,'weights':weights,'tests':d.tests,'link':link,'run':run,
     'input':lambda:d.compile_one('src/graph/input_sources.cc','input_sources',d.CORE),
     'resources':lambda:d.compile_one('src/graph/resources.cc','resources',d.CORE),
     'retained':lambda:d.compile_one('src/compute/retained_completion.cc','retained_completion',d.CORE)}[sys.argv[1]]()
