from pathlib import Path
import difflib
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n')

commands = json.loads((OUT/'consumer-commands.json').read_text())
assert len(commands) == 18
assert [r['tag'] for r in commands if r['exit']] == ['public-consumer-run', 'contracts-run']
assert commands[7]['tag'] == 'public-consumer-run' and commands[7]['exit'] == 0
assert commands[12]['tag'] == 'contracts-run' and commands[12]['exit'] == 0
assert all(r['exit'] == 0 for r in commands[13:])

files = ['samples/package/graph/cpu_cuda/main.cc',
    'samples/package/graph/cpu_cuda/inference.h',
    'samples/package/graph/cpu_cuda/CMakeLists.txt', 'tests/graph/cpu_cuda_contracts.cc']
identities = []
diff = []
for name in files:
    path = ROOT/name
    snapshot = OUT/'candidate'/name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    identities.append(dict(path=name, bytes=path.stat().st_size, sha256=sha(path)))
    before = OUT/'before'/name
    diff.extend(difflib.unified_diff(before.read_text().splitlines(True),path.read_text().splitlines(True),
        fromfile='before/'+name,tofile='candidate/'+name))
save('consumer-source-identities.json', identities)
(OUT/'consumer-source.diff').write_text(''.join(diff))

for row in json.loads((OUT/'compiled-consumers.json').read_text()):
    assert row['object_sha256'] == sha(row['object'])
    assert row['unchanged'] and all(x['sha256'] == sha(x['path']) for x in row['before'])
cold = json.loads((OUT/'compiled-cold-helper.json').read_text())
assert cold['object_sha256'] == sha(cold['object'])
assert all(x['sha256'] == sha(x['path']) for x in cold['before'])

for name in ['public-consumer', 'contracts']:
    closure = json.loads((OUT/(name+'-closure.json')).read_text())
    assert closure['actual_default_cpu_cuda_roster'] and closure['no_legacy_invocation_or_progress']
    paths = [Path(x['path']) for x in closure['inputs']]
    assert OUT/'cpu-cuda-compile.obj' in paths
    assert not any(p.name in ['joint-invocation.obj','joint-progress.obj',
        'joint-compile.obj','compute_route_cuda--weights.obj'] for p in paths)
    assert all(x['sha256'] == sha(x['path']) for x in closure['inputs'])
    text = (OUT/(name+'.map')).read_text(errors='replace')
    assert '@Invocation@cpu_cuda@graph@hyle' not in text
    assert '@Results@cpu_cuda@graph@hyle' not in text
    assert '@RunState@detail@cpu_cuda@graph@hyle' not in text
    assert 'hyle_graph_route_cpu_cuda.lib:invocation' not in text

save('consumer-cleanup-candidates.json', [dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
    for name in ['public-consumer','contracts'] for suffix in ['exe','map','exp','lib']
    if (p:=OUT/(name+'.'+suffix)).exists()])
save('retained-consumer-objects.json', [dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
    for name in ['public-consumer','contracts','cpu-cuda-compile']
    if (p:=OUT/(name+'.obj')).exists()])
save('consumer-summary.json', dict(status='PASS within stated scope',
    actual_runs=[dict(log=commands[i]['stdout'],stderr=commands[i]['stderr'],exit=0)
        for i in [7,12]],
    final_header_trim='Three fresh host TUs passed: public consumer, contracts, cold CPU/CUDA compile.cc. Both final matched links passed; native mathematics was not rerun after this declaration-only trim.',
    closure='Actual default CPU + full default CUDA roster, single audited IQ1 reference three-library set and current main/allocator explicit native objects; original Invocation only.',
    actual_proofs=['Two native mathematical slots, typed pending weights, old GraphOutput reset protection, replay and independent cancellation/abandonment; original F16 gated FFN oracle.',
        'Wrong format/shape/range/ID/capacity, metadata OOM rollback for WeightSlots and original input-source/progress control; retry succeeds.',
        'Ordinary two-source same-device pinned-host route accepts; missing required target rejects; actual foreign CUDA buffer rejects original Queue cold prepare.',
        'Accepted native tail failure remains failed/unreadable; in-flight gate rejects reuse/rebind and preserves cancellation.',
        'Eight existing owned-resource replays preserve lease allocator count, both domains drain, old results retain actual metadata/backing and shared migration quota.',
        'Same batch two IDs deduplicates dependency; ID swap and distinct batch update math; BF16-derived constant keeps incoming CPU control and D2H consumer across two slots/two phases.'],
    failure_history=[dict(log=commands[3]['stderr'],reason='Consumer migration omitted QueueBindings on later submit; fixed only consumer to pass original bindings.'),
        dict(log=commands[9]['stderr'],reason='Legacy wrapper rejected foreign resources during compile. Common compile admits device capability; exact Context rejection belongs to real buffer/Queue cold prepare. Test phase corrected with original isolation assertion preserved.')],
    no_product_core_changes=True,no_vendor_sdk_or_kernel_rebuild=True,
    not_run='No full model, new backend matrix, throughput benchmark or additional native math after final header-only compilation.',
    cleanup='Eight precisely identified consumer images/maps/auto-linker files; do not delete here. Keep three fresh consumer/helper objects and every reused native/core object.',
    sources=identities))
print(json.dumps(dict(summary=str(OUT/'consumer-summary.json'),sha256=sha(OUT/'consumer-summary.json'),
    cleanup_count=len(json.loads((OUT/'consumer-cleanup-candidates.json').read_text())),
    cleanup_bytes=sum(x['bytes'] for x in json.loads((OUT/'consumer-cleanup-candidates.json').read_text())))))
