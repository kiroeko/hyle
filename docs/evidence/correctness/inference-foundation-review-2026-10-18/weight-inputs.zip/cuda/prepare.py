from pathlib import Path
import hashlib
import json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=OUT.parents[1]

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def last(stage,tag):return next(r['command']for r in reversed(json.loads((stage/'commands.json').read_text()))if r['tag']==tag and r['exit']==0)
def rebase(command,source,target):
    return [str(source)if v.endswith('.cc')else('/Fo'+str(target))if v.lower().startswith('/fo')else v for v in command]
def replace(text,before,after):
    assert text.count(before)==1,(text.count(before),before[:80])
    return text.replace(before,after,1)

def prepare():
    before=OUT/'before';before.mkdir(exist_ok=True)
    canonical=ROOT/'tests/graph_batch/pending_cuda_graph_risks.cc'
    text=canonical.read_text()
    (before/'pending_cuda_graph_risks.cc').write_bytes(canonical.read_bytes())
    text=replace(text,'#include "../../src/compute_backend_cuda/cuda_internal.h"',
        '#include "src/compute_backend_cuda/cuda_internal.h"')
    text=replace(text,'#include <hyle/graph/cuda.h>',
        '#include <hyle/graph/cuda.h>\n#include <hyle/graph/progress.h>\n#include <hyle/sched/blocking.h>\n#include <hyle/sched/scheduler.h>')
    text=replace(text,'  Gate gate;', '''  Gate gate;
  hyle::sched::Scheduler scheduler(1,hyle::mem::system_allocator(),32);
  hyle::sched::BlockingPool blocking(hyle::mem::system_allocator(),1);''')
    text=replace(text,'  HYLE_RETURN_IF_ERROR(b::prepare(receiver,lanes,versions,prepare_options));',
        '  HYLE_RETURN_IF_ERROR(b::prepare(receiver,lanes,versions,prepare_options));\n  HYLE_RETURN_IF_ERROR(g::prepare_progress(receiver,scheduler,blocking));')
    text=replace(text,'  HYLE_ASSIGN_OR_RETURN(auto submitted,b::submit(receiver,lanes,std::move(update)));', '''  // In the cancel control, real source work is already accepted and gated.
  // Hold only the existing Scheduler's driver admission so cancel is latched
  // before any Graph suffix can be accepted. This is not a fake Completion.
  Gate progress_gate;
  struct ProgressGateDrain final {
    Gate&gate;hyle::sched::Scheduler&scheduler;
    ~ProgressGateDrain(){gate.release();scheduler.drain();}
  } progress_gate_drain{progress_gate,scheduler};
  if(mode==Mode::cancel_after){
    HYLE_RETURN_IF_ERROR(scheduler.spawn_detached([](void*p)noexcept{static_cast<Gate*>(p)->wait();},&progress_gate));
    HYLE_RETURN_IF_ERROR(require(progress_gate.await(),"actual Scheduler did not enter pending-admission gate"));
  }
  HYLE_ASSIGN_OR_RETURN(auto submitted,b::submit(receiver,lanes,std::move(update)));''')
    start=text.index('  if(mode==Mode::cancel_after){\n#if !defined(HYLE_PENDING_CPU_CUDA_GRAPH_RISKS)')
    end=text.index('\n#if !defined(HYLE_PENDING_CPU_CUDA_GRAPH_RISKS)\n  fail_source=mode==Mode::late_source_error;',start)
    text=text[:start]+'''  if(mode==Mode::cancel_after){
    HYLE_RETURN_IF_ERROR(submitted.request_cancel());
    HYLE_RETURN_IF_ERROR(require(guards.active_batches()==1 && !receiver.result(output_id) && !b::take_update(receiver),
        "pending progress cancel released source guards or fabricated successful output"));
    progress_gate.release();gate.release();
    const auto terminal=submitted.wait();
    HYLE_RETURN_IF_ERROR(require(terminal.IsCancelled() && !receiver.result(output_id),
        "pending progress cancellation lost its terminal or published output"));
    submitted={};
    HYLE_ASSIGN_OR_RETURN(update,b::take_update(receiver));
    HYLE_RETURN_IF_ERROR(require(guards.active_batches()==0,
        "cancelled progress returned source controls before actual native retirement"));
    HYLE_RETURN_IF_ERROR(require(!update.take_mutable({1}),
        "cancelled original source fabricated successful mutable output"));
    HYLE_ASSIGN_OR_RETURN(auto recovered,update.release_invocation());
    HYLE_RETURN_IF_ERROR(require(recovered.valid(),
        "cancelled progress lost original closed source controls after retirement"));
    std::fprintf(stderr,"CUDA pending progress cancel preserves original closed CopyBatchUpdate controls and guards until actual retirement PASS\\n");
    return Status::Ok();
  }''' +text[end:]
    text=replace(text,'  gate.release();context.drain().IgnoreError();',
        '  gate.release();scheduler.drain();context.drain().IgnoreError();')
    # These two controls inject no observation failure. Use the ordinary native
    # backend and real prefix directly, without the old thread-local test seam
    # (which would not follow an asynchronous driver onto another thread).
    start=text.index('  source_events.clear();recording=true;fail_source=false;')
    end=text.index('  const auto observed=update.observe();',start)
    text=text[:start]+text[end:]
    text=replace(text,'auto prefix=c::detail::CopyStreamAccess::dependency(update);recording=false;',
        'auto prefix=c::detail::CopyStreamAccess::dependency(update);')
    text=replace(text,'prefix->pending() && !source_events.empty()', 'prefix->pending()')
    text=replace(text,'cudaError_t query_event(cudaEvent_t event)noexcept{',
        '[[maybe_unused]] cudaError_t query_event(cudaEvent_t event)noexcept{')
    text=replace(text,'cudaError_t synchronize(cudaEvent_t event)noexcept{',
        '[[maybe_unused]] cudaError_t synchronize(cudaEvent_t event)noexcept{')
    start=text.index('int main(){bool failed=false;')
    text=text[:start]+'''int main(){bool failed=false;for(auto mode:{Mode::success,Mode::cancel_after}){const auto status=run(mode);if(!status.ok()){
  std::fprintf(stderr,"CUDA pending progress risk=%u: %.*s\\n",unsigned(mode),int(status.message().size()),status.message().data());failed=true;
}}return failed?1:0;}
'''
    scratch=OUT/'pending-progress.cc';scratch.write_text(text,encoding='utf-8',newline='\n')
    rows=json.loads((ARCH/'generic-progress/consumer-migration/compile-recipes.json').read_text())
    recipes=[]
    for row,name in zip(rows,['finite-consumer','sampling-consumer']):
        source=ROOT/row['source']
        recipes.append(dict(source=str(source.relative_to(ROOT)),command=rebase(row['command'],source,OUT/(name+'.obj'))))
    source=ROOT/'src/graph_batch/batch.cc'
    (before/'batch.cc').write_bytes(source.read_bytes())
    recipes.append(dict(source=str(source.relative_to(ROOT)),command=rebase(last(ARCH/'admitted-queue-sequence','graph-batch-compile'),source,OUT/'graph-batch.obj')))
    recipes.append(dict(source=str(scratch.relative_to(ROOT)),command=rebase(last(ARCH/'resource-episode/pending-consumers','pending_cuda_graph_risks-final-compile'),scratch,OUT/'pending-progress.obj')))
    save('compile-recipes.json',recipes)
    save('source-identities.json',[dict(path=str(ROOT/r['source']),bytes=(ROOT/r['source']).stat().st_size,sha256=sha(ROOT/r['source']))for r in recipes])
    cpu=ROOT/'.scratch/validation/cpu-final-f1/mixed-iq1/source'
    gpu=ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows'
    checked=[]
    for name in ['include/ggml.h','include/ggml-backend.h','src/ggml-backend-impl.h']:
        assert sha(cpu/name)==sha(gpu/name)
        checked.append(dict(relative_path=name,cpu=str(cpu/name),cuda=str(gpu/name),sha256=sha(cpu/name)))
    save('single-ggml-base-admission.json',dict(cpu_backend=str(ROOT/'.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-cpu.lib'),
        identical_abi_headers=checked,one_base_only=True,cuda_native_closure=str(ARCH/'generic-progress/ggml-cache/native-closure.json'),
        scope='Exact existing CPU backend for F32 consumer; does not claim revalidation of every current CPU quantization/kernel patch'))

if __name__=='__main__':prepare()
