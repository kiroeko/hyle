"""Focused mixed consumers and true pending-page progress; no SDK builds."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=OUT.parents[1]
spec=importlib.util.spec_from_file_location('weight_consumer_host_driver',ARCH/'region-adapter/run.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.OUT=OUT
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def last(stage,tag):return next(r['command']for r in reversed(json.loads((stage/'commands.json').read_text()))if r['tag']==tag and r['exit']==0)
def compile_hosts(only=None):
    identities=json.loads((OUT/'compiled-hosts.json').read_text())if (OUT/'compiled-hosts.json').exists()else[]
    for row in json.loads((OUT/'compile-recipes.json').read_text()):
        if only and Path(row['source']).stem!=only:continue
        source=ROOT/row['source'];before=sha(source);command=row['command']
        target=Path(next(v[3:]for v in command if v.lower().startswith('/fo')))
        b.run(target.stem+'-compile',command)
        assert before==sha(source)
        identities.append(dict(source=str(source),source_sha256=before,object=str(target),bytes=target.stat().st_size,object_sha256=sha(target)))
        save('compiled-hosts.json',identities)

def link(name):
    prior=ARCH/'generic-progress/cuda'
    base=last(prior,'finite-consumer-link')
    qwen=ARCH/'generic-progress/qwen'
    extra=last(qwen,'consumer-link')
    common=ARCH/'weight-inputs/windows'
    replacements={n:common/n for n in ['executable.obj','submission.obj','resources.obj',
        'region_access.obj','constant_artifact.obj','lease_submission.obj','retained_completion.obj','progress.obj']}
    replacements['graph-batch.obj']=OUT/'graph-batch.obj'
    args=[base[0]];seen=set();removed=[];changed=[]
    def add(value):
        key=value.lower()
        if key not in seen:args.append(value);seen.add(key)
    for n in ['input_sources.obj','resource_report.obj']:
        add(str(common/n))
    for label,original in [('cpu_native_cuda',base),('default_cuda',extra)]:
        for value in original[1:]:
            path=Path(value);stem=path.name.lower()
            if value.upper().startswith(('/OUT:','/MAP:')):continue
            if (label=='cpu_native_cuda' and stem in ['finite-consumer.obj','compute_route_cuda--weights.obj'])or(label=='default_cuda'and stem=='consumer.obj'):
                removed.append(value);continue
            if label=='cpu_native_cuda'and value==str(ROOT/'.scratch/mtp-gdn-2026-10-18/mixed/allocator.obj'):
                removed.append(value);continue
            if label=='cpu_native_cuda'and stem in ['ggml.lib','ggml-base.lib']:
                removed.append(value);continue
            if stem in ['joint-invocation.obj','joint-progress.obj']:
                raise AssertionError('Second execution driver entered closure: '+value)
            if path.name in replacements:
                target=str(replacements[path.name])
                changed.append(dict(before=value,after=target));value=target
            add(value)
    add(str(OUT/(name+'.obj')))
    libraries=[v for v in args if Path(v).name.lower()in ['ggml.lib','ggml-base.lib','ggml-cuda.lib']]
    reference=ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows/lib'
    assert sorted(libraries)==sorted(str(reference/n)for n in ['ggml.lib','ggml-base.lib','ggml-cuda.lib']),libraries
    # Native main/allocator are explicit before archive lookup, as in the
    # audited default-CUDA closure. Both are the current overlay objects.
    native=ARCH/'generic-progress/ggml-cache'
    for n in ['ggml-cuda.obj','ggml-alloc.obj']:
        position=args.index(str(native/n));args.insert(1,args.pop(position))
    for value in args:
        if Path(value).is_absolute()and Path(value).suffix.lower()in ['.obj','.lib']:
            assert Path(value).is_file(),value
    args+=['/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map'))]
    save(name+'-closure.json',dict(removed=removed,replacements=changed,
        sources=[str(prior/'commands.json'),str(qwen/'commands.json')],default_cuda_context_preserved=True,
        second_ggml_base=False,inputs=[dict(path=v,bytes=Path(v).stat().st_size,sha256=sha(v))for v in args if Path(v).is_file()and Path(v).suffix.lower()in ['.obj','.lib']]))
    b.run(name+'-link',args)

def run(name):
    command=last(OUT,name+'-link')
    paths=[str(Path(v).parent)for v in command if Path(v).is_absolute()and v.lower().endswith('.lib')]
    paths+=['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64',
        'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',str(ROOT/'.scratch/build-compute-v2-dev/bin')]
    os.environ['PATH']=os.pathsep.join(dict.fromkeys(paths))+os.pathsep+os.environ['PATH']
    b.run(name+'-run',[OUT/(name+'.exe')],timeout=30)

if __name__=='__main__':
    if sys.argv[1]=='compile':compile_hosts(sys.argv[2]if len(sys.argv)>2 else None)
    elif sys.argv[1]=='link':link(sys.argv[2])
    elif sys.argv[1]=='run':run(sys.argv[2])
    else:raise ValueError(sys.argv[1])
