"""Freeze this focused migration, excluding images, objects and SDKs."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/weight-inputs.zip'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

sources = [
    'include/hyle/graph/detail/input_source.h', 'include/hyle/graph/executable.h',
    'include/hyle/graph/cpu_cuda.h', 'include/hyle/graph/cuda.h',
    'include/hyle/compute/cuda_weights.h',
    'src/graph/input_sources.h', 'src/graph/input_sources.cc',
    'src/graph/resource_report.cc', 'src/graph/plan_state.h',
    'src/graph/executable.cc', 'src/graph/submission.cc', 'src/graph/resources.cc',
    'src/graph/submission_internal.h', 'src/graph/region_access.cc',
    'src/graph/constant_artifact.cc', 'src/graph/lease_submission.cc',
    'src/graph/CMakeLists.txt', 'src/graph_progress/progress.cc',
    'src/graph_batch/batch.cc', 'src/compute/retained_completion.cc',
    'src/compute_route_cuda/weights.cc', 'src/compute_route_cuda/weights_internal.h',
    'src/graph_route_cuda/weight_binding.cc', 'src/graph_route_cuda/CMakeLists.txt',
    'src/graph_route_cpu_cuda/compile.cc', 'src/graph_route_cpu_cuda/CMakeLists.txt',
    'cmake/HyleComponents.cmake', 'tests/tooling/compute_routes_test.py',
    'tests/compute/completion_test.cc', 'tests/graph/cpu_cuda_contracts.cc',
    'tests/graph/route_symmetry_cuda.cc',
    'tests/graph_route_cpu_cuda/sampling_consumer.cc',
    'tests/graph_route_cpu_cuda/CMakeLists.txt',
    'samples/package/graph/cpu_cuda/main.cc',
    'samples/package/graph/cpu_cuda/inference.h',
    'samples/package/graph/cpu_cuda/README.md',
    'samples/package/graph/cpu_cuda/CMakeLists.txt',
    'docs/architecture/compute-design.md', 'docs/developer/current-work.md',
    'docs/user/graph.md', 'test.ps1',
]
snapshot = STAGE/'final-source'
for name in sources:
    dest = snapshot/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((ROOT/name).read_bytes())
(STAGE/'final-source-identities.json').write_text(json.dumps(
    [dict(relative=name, **identity(ROOT/name)) for name in sources], indent=2)+'\n', encoding='utf-8')

targets = []
for folder, stems in [('windows', ['controls', 'public-consumer', 'contracts']),
                      ('cuda', ['finite-consumer', 'sampling-consumer', 'pending-progress'])]:
    for stem in stems:
        for ext in ['.exe', '.map', '.exp', '.lib']:
            path = STAGE/folder/(stem+ext)
            if path.exists():
                assert not path.is_symlink()
                targets.append(identity(path))
(STAGE/'cleanup.json').write_text(json.dumps(dict(files=targets,
    bytes=sum(row['bytes'] for row in targets),
    retained='all objects, SDKs, source, logs and data'), indent=2)+'\n', encoding='utf-8')

entries = {}
extensions = {'.py', '.ps1', '.json', '.md', '.cc', '.h', '.hpp', '.log', '.diff', '.txt', '.cmake', '.csv', '.rsp'}
for stage, prefix in [(STAGE, ''), (STAGE.parent/'weight-input-dependencies', 'input-dependency-design/')]:
    for path in stage.rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(stage)
        if 'build' in relative.parts or path.name in ['archive-receipt.json', 'cleanup-result.json']:
            continue
        if path.suffix.lower() in extensions:
            entries[prefix+relative.as_posix()] = path
assert 'cleanup.json' in entries
assert all(not (ROOT/name).exists() for name in [
    'src/graph_route_cpu_cuda/invocation.cc',
    'src/graph_route_cpu_cuda/progress.cc', 'src/graph_route_cpu_cuda/progress.h'])
assert not EVIDENCE.exists(), 'Do not overwrite frozen evidence'
with zipfile.ZipFile(EVIDENCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(entries.items()):
        z.write(path, name)
with zipfile.ZipFile(EVIDENCE) as z:
    assert z.testzip() is None
receipt = dict(relative=str(EVIDENCE.relative_to(ROOT)).replace('\\', '/'), **identity(EVIDENCE), entries=len(entries))
receipt['path'] = receipt.pop('relative')
(STAGE/'archive-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(archive=receipt, cleanup_files=len(targets), reclaim_bytes=sum(x['bytes'] for x in targets))))
