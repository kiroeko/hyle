"""Prepare manifests by default; archive only after an explicit parent final signal.

No compilation, execution, network access, or deletion is performed here.
  python -B freeze_evidence.py --prepare
  python -B freeze_evidence.py --freeze --final-signal
The second command must only be used after the parent authorizes final freezing.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import zipfile


STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ARCH = STAGE.parent
TARGET = ROOT / "docs/evidence/correctness/inference-foundation-review-2026-10-18/admitted-queue-sequence.zip"
COMPONENTS = ("retained-queue-core", "admitted-provider-sequence",
              "graph-queue-ref", "queue-protocol-consumers")
MAC_TAR_SHA = "7b02a7e0f2cb88110ac29e0da4c6f9d0793d02cfbd8b2a23fb2ab3a6f66124b4"
SOURCE_PREFIXES = ("include/", "src/", "tests/", "samples/", "bench/", "scripts/", "cmake/", "docs/")
TEXT_SUFFIXES = {".py", ".json", ".log", ".diff", ".patch", ".txt", ".md", ".cc", ".c", ".cpp",
                 ".h", ".hpp", ".cu", ".cuh", ".mm", ".m", ".cmake", ".ps1", ".comp"}
FORBIDDEN_SUFFIXES = {".obj", ".o", ".a", ".lib", ".exp", ".exe", ".dll", ".pdb", ".map", ".bin",
                      ".dylib", ".so", ".metallib", ".pyc", ".zip", ".tar", ".gz", ".7z"}
GENERATED = {"evidence-candidate.json", "current-source-candidate.json", "object-candidate.json",
             "prepare-summary.json", "cleanup.json", "cleanup-mac.json", "freeze-receipt.json",
             "frozen-summary.json", "frozen-source-identities.json", "frozen-object-identities.json",
             "archive-entries.json", "archive-receipt.json"}
EXTRA_SOURCES = (
    "src/compute/provider_internal.h", "src/compute/device.cc", "src/compute/context_state.h",
    "src/compute/operation.cc", "src/compute/operation_cold.h", "src/compute/transfer.cc",
    "src/compute/command_capture.cc", "src/compute/batch_transfer.cc", "src/compute/custom_kernel.cc",
    "include/hyle/compute/detail/context_ref.h", "include/hyle/compute/detail/queue_ref.h",
    "include/hyle/compute/detail/queue_sequence.h", "include/hyle/compute/detail/prepared_callbacks.h",
    "include/hyle/compute/detail/provider_extension.h", "include/hyle/compute/detail/backend_extension.h",
    "include/hyle/compute/detail/batch_provider.h", "include/hyle/compute/batch_ops.h",
    "include/hyle/compute/custom_kernel.h", "include/hyle/compute/detail/command_capture.h",
    "src/compute_batch/batch_execution.cc", "src/compute_batch/row_cache_paged_reader.cc",
    "src/compute_backend_cuda/cuda_backend.cc", "src/compute_backend_cuda/cuda_internal.h",
    "src/compute_backend_cuda/native_context.h", "src/compute_backend_cuda/cuda_device_status.cc",
    "include/hyle/compute/providers/cuda.h", "src/graph_route_cpu_cuda/progress.cc",
    "src/graph_route_cpu_cuda/invocation.cc", "src/compute_provider_cuda/row_cache_provider.cc",
    "src/compute_provider_cuda/row_cache_indexer_provider.cc", "src/compute_provider_native/row_cache.cc",
    "src/compute_provider_native/torch_cpu_program.cc", "src/graph_batch/batch.cc",
    "include/hyle/graph/region_provider.h", "src/graph/plan_state.h", "src/graph/submission_internal.h",
    "src/graph/execution_source_internal.h", "src/graph_route_cpu/cpu_context.cc",
    "src/graph_route_cpu/compile.cc", "src/graph_route_cpu/CMakeLists.txt",
    "docs/architecture/compute-design.md", "docs/developer/current-work.md", "docs/user/compute.md",
    "docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md",
)
HELPERS = ("scripts/hyle_environment.py", ".scratch/architecture-refactor-2026-10-18/region-adapter/run.py",
           ".scratch/architecture-refactor-2026-10-18/apple-readonly-ports/stage.py")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(name: str, value):
    (STAGE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")


def identity(path: Path):
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": sha(data)}


def safe_name(name: str) -> str:
    name = name.replace("\\", "/")
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or re.match(r"^[A-Za-z]:", name):
        raise ValueError(f"Unsafe archive path: {name}")
    return str(p)


def canonical_source(value: str):
    value = value.replace("\\", "/")
    root = str(ROOT).replace("\\", "/")
    if value.casefold().startswith(root.casefold() + "/"):
        value = value[len(root) + 1:]
    if not value.startswith(SOURCE_PREFIXES):
        # Remote validation paths have a fixed checkout prefix; never import it.
        hits = [value.find("/" + p) for p in SOURCE_PREFIXES if "/" + p in value]
        if not hits:
            return None
        value = value[min(hits) + 1:]
    if not value.startswith(SOURCE_PREFIXES) or ".." in PurePosixPath(value).parts:
        return None
    candidate = ROOT / value
    return value if candidate.is_file() else None


def source_rows(value):
    if isinstance(value, list):
        for item in value:
            yield from source_rows(item)
    elif isinstance(value, dict):
        location = value.get("source") or value.get("path")
        digest = value.get("source_sha256") or value.get("sha256")
        if isinstance(location, str) and isinstance(digest, str):
            relative = canonical_source(location)
            if relative:
                yield relative, digest
        for key, nested in value.items():
            if key not in ("command", "before", "after") and isinstance(nested, (list, dict)):
                yield from source_rows(nested)


def admissible_file(path: Path):
    return (path.is_file() and path.suffix.lower() in TEXT_SUFFIXES
            and not any(part.lower() in ("__pycache__", "sdk", "vendor", "node_modules") for part in path.parts))


class Evidence:
    def __init__(self):
        self.items = {}
        self.source_origins = {}
        self.historical_drift = []
        self.strict_drift = []
        self.mac_source_count = 0

    def add(self, name: str, data: bytes, origin: str):
        name = safe_name(name)
        if Path(name).suffix.lower() in FORBIDDEN_SUFFIXES:
            raise ValueError(f"Excluded artifact entered archive: {name}")
        prior = self.items.get(name)
        if prior and prior["data"] != data:
            raise ValueError(f"Conflicting archive entry: {name}")
        if prior:
            prior["origins"].append(origin)
        else:
            self.items[name] = {"data": data, "origins": [origin]}

    def add_file(self, name: str, path: Path):
        self.add(name, path.read_bytes(), str(path))

    def add_source(self, relative: str, origin: str, expected=None, strict=False, data=None):
        actual = (ROOT / relative).read_bytes()
        if data is not None and actual != data:
            self.strict_drift.append({"path": relative, "origin": origin, "expected": sha(data), "actual": sha(actual)})
        if expected and expected != sha(actual):
            record = {"path": relative, "origin": origin, "expected": expected, "actual": sha(actual)}
            (self.strict_drift if strict else self.historical_drift).append(record)
        self.source_origins.setdefault(relative, set()).add(origin)
        self.add("current/" + relative, actual, origin)

    def add_mac(self):
        path = STAGE / "mac/mac-results.tar.gz"
        if sha(path.read_bytes()) != MAC_TAR_SHA:
            raise ValueError("Mac final evidence tar identity changed")
        with tarfile.open(path) as tar:
            for item in tar.getmembers():
                if not item.isfile():
                    raise ValueError(f"Non-regular Mac entry: {item.name}")
                name = safe_name(item.name)
                data = tar.extractfile(item).read()
                if name == "final-sources.tar.gz":
                    with tarfile.open(fileobj=io.BytesIO(data)) as sources:
                        for member in sources.getmembers():
                            if not member.isfile():
                                raise ValueError(f"Non-regular source entry: {member.name}")
                            source_name = safe_name(member.name)
                            payload = sources.extractfile(member).read()
                            relative = canonical_source(source_name)
                            if relative:
                                self.add_source(relative, "mac/final-sources/" + source_name, data=payload)
                            else:
                                self.add("mac/source-helpers/" + source_name, payload, str(path) + "!final-sources.tar.gz")
                            self.mac_source_count += 1
                else:
                    self.add("mac/" + name, data, str(path) + "!" + name)
        if self.mac_source_count != 230:
            raise ValueError(f"Expected 230 final Mac source files, got {self.mac_source_count}")
        for path in sorted((STAGE / "mac").iterdir()):
            if admissible_file(path) and path.name != "cleanup-mac.json":
                self.add_file("mac/local/" + path.name, path)

    def collect(self):
        self.add_mac()
        for path in sorted(STAGE.iterdir()):
            if admissible_file(path) and path.name not in GENERATED:
                self.add_file("windows/" + path.name, path)
        for path in sorted((STAGE / "cuda").rglob("*")):
            if admissible_file(path):
                self.add_file("cuda/" + path.relative_to(STAGE / "cuda").as_posix(), path)
        for component in COMPONENTS:
            base = ARCH / component
            for path in sorted(base.rglob("*")):
                if admissible_file(path):
                    self.add_file("components/" + component + "/" + path.relative_to(base).as_posix(), path)
        manifests = set(STAGE.rglob("*source-identit*.json"))
        manifests.update(ARCH / name / "source-identities.json" for name in COMPONENTS)
        manifests.update((STAGE / "cuda/compile-status.json", STAGE / "cuda/consumer-objects.json"))
        for path in sorted(manifests):
            if not path.is_file():
                continue
            strict = path in (STAGE / "cpu-source-identities.json", STAGE / "cuda/final-source-identities.json",
                              STAGE / "cuda/compile-status.json", STAGE / "cuda/consumer-objects.json")
            for relative, digest in source_rows(read_json(path)):
                self.add_source(relative, str(path.relative_to(ROOT)), digest, strict=strict)
        for relative in EXTRA_SOURCES:
            if not (ROOT / relative).is_file():
                raise FileNotFoundError(f"Required source missing: {relative}")
            self.add_source(relative, "explicit current product/docs scope")
        for relative in HELPERS:
            self.add_file("helpers/" + relative.removeprefix(".scratch/"), ROOT / relative)
        return self

    def manifest(self):
        return [{"path": name, "bytes": len(item["data"]), "sha256": sha(item["data"]), "origins": item["origins"]}
                for name, item in sorted(self.items.items())]

    def sources(self):
        return [{"path": relative, "bytes": len(self.items["current/" + relative]["data"]),
                 "sha256": sha(self.items["current/" + relative]["data"]), "origins": sorted(origins)}
                for relative, origins in sorted(self.source_origins.items())]


def command_status():
    cpu = read_json(STAGE / "cpu-results.json")
    cpu_summary = read_json(STAGE / "cpu-summary.json")
    cpu_commands = read_json(STAGE / "commands.json")
    mac = read_json(STAGE / "mac/mac-summary.json")
    cuda_commands = read_json(STAGE / "cuda/commands.json")
    runs = {}
    for tag in ("native-consumer-run", "checked-gather-run"):
        rows = [(i + 1, row) for i, row in enumerate(cuda_commands) if row["tag"] == tag]
        if rows:
            index, row = rows[-1]
            runs[tag] = {"record": index, "exit": row["exit"], "stdout": row["stdout"], "stderr": row["stderr"]}
    ready = (cpu["tests"] == 69 and cpu["failures"] == 0 and cpu["errors"] == 0
             and cpu_commands[cpu_summary["final_run_record"] - 1]["exit"] == 0
             and mac["tests"] == 24 and mac["failures"] == 0 and mac["errors"] == 0
             and mac["finite_consumer_exit"] == 0 and len(runs) == 2
             and all(row["exit"] == 0 for row in runs.values()))
    return {"observed_final_results_ready": ready, "windows": {"tests": cpu["tests"], "failures": cpu["failures"],
            "errors": cpu["errors"], "final_run_record": cpu_summary["final_run_record"]}, "mac": mac,
            "cuda_observed_runs": runs, "cuda_final_summary": read_json(STAGE / "cuda/summary.json"),
            "scope": "CUDA native expert finite consumer and two checked Gather regressions; full default CUDA runtime is not claimed.",
            "remaining": "Common Graph hot progression uses retained QueueRef/QueueSequence. Independent Batch submit/receiver begin still borrow the public Queue on hot paths. Explicit host-wait advancement and old CPU+GPU coordinator remain; no single-Job asynchronous executor claim."}


def prepare_cleanup():
    files = [STAGE / ("controls" + suffix) for suffix in (".exe", ".map", ".exp", ".lib")]
    cuda = STAGE / "cuda"
    commands = json.dumps(read_json(cuda / "commands.json")).replace("\\\\", "/").replace("\\", "/").casefold()
    for path in sorted(cuda.iterdir()):
        if path.suffix.lower() not in (".exe", ".map", ".exp", ".lib"):
            continue
        executable = path.with_suffix(".exe")
        if not executable.is_file() or executable.resolve().as_posix().casefold() not in commands:
            raise ValueError(f"Image is not associated with a recorded CUDA executable: {path}")
        files.append(path)
    objects = sorted(path for path in STAGE.rglob("*") if path.is_file() and path.suffix.lower() in (".obj", ".o"))
    cleanup = {"root": str(STAGE.resolve()), "files": [identity(path) for path in files],
               "retained_stage_objects": [identity(path) for path in objects],
               "policy": "Exact candidates only. Do not execute deletion from this script; root test.ps1 owns cleanup after archive receipt verification."}
    cuda_declared = read_json(cuda / "cleanup-candidates.json")["files"]
    if sorted(cuda_declared, key=lambda x: x["path"]) != sorted(cleanup["files"][4:], key=lambda x: x["path"]):
        raise ValueError("Actual CUDA images do not match its final cleanup candidates")
    if set(row["path"] for row in cleanup["files"]) & set(row["path"] for row in cleanup["retained_stage_objects"]):
        raise ValueError("Cleanup intersects retained objects")
    save("cleanup.json", cleanup)
    mac_cleanup = (STAGE / "mac/cleanup-mac.json").read_bytes()
    (STAGE / "cleanup-mac.json").write_bytes(mac_cleanup)
    return cleanup


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--prepare", action="store_true")
    group.add_argument("--freeze", action="store_true")
    parser.add_argument("--final-signal", action="store_true")
    args = parser.parse_args()
    if args.freeze and not args.final_signal:
        parser.error("Freeze requires the parent's final signal and --final-signal")
    if args.freeze and TARGET.exists():
        raise FileExistsError(f"Refusing to overwrite existing evidence: {TARGET}")
    evidence = Evidence().collect()
    cleanup = prepare_cleanup()
    sources = evidence.sources()
    status = command_status()
    summary = {"mode": "prepared, not frozen", "archive_target": str(TARGET), "archive_exists": TARGET.exists(),
               "candidate_entries": len(evidence.items), "candidate_bytes": sum(len(x["data"]) for x in evidence.items.values()),
               "unique_current_sources": len(sources), "mac_final_sources_deduplicated": evidence.mac_source_count,
               "strict_compiled_source_drift": evidence.strict_drift, "historical_identity_drift": evidence.historical_drift,
               "cleanup_windows_files": len(cleanup["files"]), "cleanup_windows_bytes": sum(x["bytes"] for x in cleanup["files"]),
               "retained_windows_objects": len(cleanup["retained_stage_objects"]), "result_status": status,
               "no_tests_or_compiles_run": True, "no_files_deleted": True,
               "archive_exclusions": "SDK/vendor, objects, binary images, maps, libraries, pycache, nested archives; no repository-wide dirty diff.",
               "mac_layout": "mac-results outer payload expanded; its 230 final sources merged into current/ once; transport scripts under mac/local; historical before-delta retained."}
    save("evidence-candidate.json", evidence.manifest())
    save("current-source-candidate.json", sources)
    save("object-candidate.json", cleanup["retained_stage_objects"])
    save("prepare-summary.json", summary)
    if not args.freeze:
        print(json.dumps({k: summary[k] for k in ("mode", "candidate_entries", "unique_current_sources", "cleanup_windows_files", "retained_windows_objects")}, indent=2))
        print("Strict source drift:", len(evidence.strict_drift), "; no archive created and no deletion performed.")
        return
    if not status["observed_final_results_ready"] or evidence.strict_drift:
        raise RuntimeError("Final results or current compiled-source identity are not ready; manifests retained, no archive created")
    summary["mode"] = "frozen after explicit parent final signal"
    evidence.add("summary.json", (json.dumps(summary, indent=2, ensure_ascii=False) + "\n").encode(), "generated at freeze")
    evidence.add("current-source-identities.json", (json.dumps(sources, indent=2) + "\n").encode(), "generated at freeze")
    evidence.add("current-object-identities.json", (json.dumps(cleanup["retained_stage_objects"], indent=2) + "\n").encode(), "generated at freeze")
    evidence.add_file("windows/cleanup.json", STAGE / "cleanup.json")
    evidence.add_file("windows/cleanup-mac.json", STAGE / "cleanup-mac.json")
    entries = evidence.manifest()
    evidence.add("manifest.json", (json.dumps(entries, indent=2, ensure_ascii=False) + "\n").encode(), "generated at freeze")
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(TARGET, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, item in sorted(evidence.items.items()):
            archive.writestr(name, item["data"])
    with zipfile.ZipFile(TARGET) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(evidence.items):
            raise RuntimeError("Archive verification failed; do not clean any candidate")
        for name, item in evidence.items.items():
            if archive.read(name) != item["data"]:
                raise RuntimeError(f"Archive data verification failed: {name}")
    save("frozen-summary.json", summary)
    save("frozen-source-identities.json", sources)
    save("frozen-object-identities.json", cleanup["retained_stage_objects"])
    save("archive-entries.json", evidence.manifest())
    receipt = {**identity(TARGET), "entries": len(evidence.items), "verified_uncompressed_entries": True,
               "cleanup_windows": str(STAGE / "cleanup.json"), "cleanup_mac": str(STAGE / "cleanup-mac.json"),
               "deleted_files": 0}
    save("freeze-receipt.json", receipt)
    save("archive-receipt.json", receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
