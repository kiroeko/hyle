from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def identity(p):
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


rows = json.loads((OUT/'commands.json').read_text())
result = json.loads((OUT/'cpu-results.json').read_text())
assert result['tests'] == 69 and result['failures'] == 0 and result['errors'] == 0
assert rows[-1]['tag'] == 'cpu-controls-run' and rows[-1]['exit'] == 0
assert all(r.get('unchanged', True) for r in rows)
sources = {Path(arg) for r in rows for arg in r['command']
           if isinstance(arg,str) and arg.endswith('.cc') and Path(arg).is_file()}
sources.update(ROOT/name for name in [
    'src/graph/plan_state.h', 'src/graph/submission_internal.h',
    'src/graph/execution_source_internal.h', 'src/compute/provider_internal.h',
    'include/hyle/compute/detail/queue_ref.h',
    'include/hyle/compute/detail/queue_sequence.h',
    'include/hyle/compute/detail/context_ref.h',
    'include/hyle/compute/detail/prepared_callbacks.h',
    'include/hyle/compute/detail/batch_provider.h',
    'include/hyle/compute/custom_kernel.h', 'include/hyle/graph/region_provider.h',
    'tests/compute/custom_kernel_fixture.h',
    'tests/compute_ggml_runtime/gallocr_faults.c',
])
objects = {Path(arg) for r in rows for arg in r['command']
           if isinstance(arg,str) and arg.endswith('.obj') and Path(arg).is_file()}
objects.update(OUT.glob('*.obj'))
for name, paths in [('cpu-source-identities.json', sources),
                    ('cpu-object-identities.json', objects)]:
    (OUT/name).write_text(json.dumps([identity(p) for p in sorted(paths)],indent=2)+'\n')
summary = json.loads((OUT/'cpu-summary.json').read_text())
summary.update({
    'product_abi': dict(provider=15, region=24, batch=5, mla=3),
    'cpu_owner_compile_records': [12,24], 'test_compile_records': [25,34],
    'first_link_record': 36, 'first_run_record': 37,
    'final_link_record': max(i+1 for i,r in enumerate(rows) if r['tag']=='cpu-controls-link' and r['exit']==0),
    'final_run_record': len(rows),
    'final_single_tu_rebuild': 'Two successive isolated refreshes: torch_cpu_program.cc explicit empty Quantized.ids initializer, then graph_batch/batch.cc explicit default BatchPlanReport initializer; same 69-case filter after each, initial and prior-final result/identities preserved separately.',
    'first_link_failure': {
        'record': 35, 'exit': 1120,
        'reason': 'Manual closure initially omitted the existing seven gallocr test-fault symbols required by the complete attention_math test TU.',
        'fix': 'Reused cached batched-sink-ggml/cpu-gallocr-faults.obj; no test/product/native-source edit or vendor rebuild.',
    },
    'source_edits_during_validation': 'Root added explicit aggregate member initializers after initial/prior-final runs to match Clang and MSVC; no edits by this validation driver.',
    'not_run': 'CUDA tests and representative GPU regression are owned by root; no full-library or shape-matrix run.',
    'cached_numerical_libraries': 'Actual prior CPU ggml/ATen/oneDNN libraries preserved; every selected Hyle ProviderVTable owner and callback owner was refreshed.',
    'onednn_flags': 'Current static linkage flags plus actual cached c531fe1a5cd6 source/generated includes; normalization retains its CMake /EHsc- exception setting.',
    'new_regressions': [
        'Queue.AdmittedSequenceKeepsItsActualOwnerAfterPublicHandlesClose',
        'Invocation.PreparedReplayFollowsQueueIdentityAcrossPublicHandleMoves',
    ],
})
(OUT/'cpu-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(tests=result['tests'], sources=len(sources), objects=len(objects))))
