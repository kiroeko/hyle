from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment


def prior(path, tag):
    return next(r['command'] for r in reversed(json.loads(path.read_text()))
                if r['tag'] == tag and r['exit'] == 0)


def cached(stage, tag):
    return prior(ARCH / stage / 'commands.json', tag)


CORE = cached('carrier-copy-contract', 'executable-compile')
NATIVE = cached('materialized-projection', 'native-provider-compile')
GGML = cached('materialized-projection', 'ggml-provider-compile')
REGION = cached('port-contract-adapters', 'cpu-region-compile')
CPU = cached('execution-convergence', 'cpu-context-compile')
TEST = cached('execution-convergence', 'executable-test-compile')
BASE = cached('execution-convergence', 'controls-link')
ONEDNN = [*CORE[:-2],
          '/DHYLE_COMPUTE_ONEDNN=1', '/DHYLE_GRAPH_ONEDNN=1',
          '/I' + str(ROOT / 'src/compute_provider_onednn'),
          '/external:IC:/public/tools/hyle-dependencies/v1/sources/onednn-c531fe1a5cd6-5c0c833df87c/include',
          '/external:I' + str(ROOT / '.scratch/build-compute-v2-dev/_deps/onednn-build/include')]
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': CORE[0], 'CMAKE_C_COMPILER': CORE[0]})
env['VSLANG'] = '1033'
torch = next(Path(x) for x in BASE if Path(x).name.lower() == 'torch_cpu.lib')
env['PATH'] = str(torch.parent) + os.pathsep + env['PATH']


def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def run(tag, command, sources=()):
    history = OUT / 'commands.json'
    rows = json.loads(history.read_text())
    stem = f'{len(rows) + 1:02d}-{tag}'
    print('starting', stem, 'driver_pid', os.getpid(), flush=True)
    before = [identity(p) for p in sources]
    command = list(map(str, command))
    started = time.monotonic()
    try:
        r = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                           timeout=55, creationflags=subprocess.CREATE_NO_WINDOW)
        code, stdout, stderr = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        code, stdout, stderr = 124, e.stdout or b'', e.stderr or b''
    (OUT / (stem + '.stdout.log')).write_bytes(stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(stderr)
    after = [identity(p) for p in sources]
    row = dict(tag=tag, command=command, exit=code, seconds=time.monotonic()-started,
               stdout=stem+'.stdout.log', stderr=stem+'.stderr.log',
               before=before, after=after, unchanged=before == after)
    if code == 0:
        row['objects'] = [identity(x[3:]) for x in command if x.lower().startswith('/fo')]
    rows.append(row)
    history.write_text(json.dumps(rows, indent=2)+'\n')
    print(stem, code, flush=True)
    if code:
        print(stdout.decode(errors='replace')[-9000:])
        print(stderr.decode(errors='replace')[-3000:])
    if before != after:
        raise SystemExit('Source changed while compiling')
    if code:
        raise SystemExit(code)


def compile_one(source, name, old, extra=()):
    flags = [x for x in old[1:] if not x.lower().startswith(('/fo', '/tp'))
             and not x.endswith('.cc')]
    run(name+'-compile', [old[0], *flags, *extra, ROOT/source,
                          '/Fo'+str(OUT/(name+'.obj'))],
        [ROOT/source, ROOT/'src/compute/provider_internal.h',
         ROOT/'include/hyle/compute/detail/prepared_callbacks.h',
         ROOT/'include/hyle/compute/detail/queue_ref.h',
         ROOT/'include/hyle/graph/region_provider.h', ROOT/'src/graph/plan_state.h'])


OWNERS = [
    ('src/compute_provider_native/native_provider.cc', 'native-provider', NATIVE),
    ('src/compute_provider_native/aten_cpu_provider.cc', 'aten-provider', NATIVE),
    ('src/compute_provider_ggml/ggml_cpu_provider.cc', 'ggml-provider', GGML),
    ('src/compute/custom_kernel.cc', 'custom-kernel', CORE),
    ('src/compute_route_cpu/default_policy.cc', 'cpu-policy', CPU),
    ('src/compute_provider_native/torch_cpu_program.cc', 'cpu-torch', NATIVE),
    ('src/compute_provider_onednn/onednn_provider.cc', 'onednn-provider', ONEDNN),
    ('src/compute_provider_onednn/normalization_internal.cc', 'onednn-normalization', ONEDNN, ['/EHsc-']),
    ('src/graph_provider_onednn/onednn_region_provider.cc', 'onednn-region', ONEDNN),
    ('src/compute_provider_ggml/standard_index.cc', 'ggml-index', GGML),
    ('src/compute_provider_ggml/native_batch.cc', 'native-batch', GGML),
    ('src/graph_route_cpu/ggml_region.cc', 'cpu-region', REGION),
    ('src/graph_batch/batch.cc', 'graph-batch', cached('port-contract-adapters', 'graph-batch-compile')),
]
TESTS = [
    ('tests/compute/device_test.cc', 'device-test', TEST),
    ('tests/compute/custom_kernel_test.cc', 'compute-custom-test', TEST),
    ('tests/graph/custom_kernel_test.cc', 'graph-custom-test', TEST),
    ('tests/compute_backend_cpu/runtime_provider_test.cc', 'runtime-provider-test', TEST),
    ('tests/compute_provider_native/provider_shape_test.cc', 'provider-shape-test', NATIVE),
    ('tests/compute_batch/workspace_test.cc', 'workspace-test', TEST),
    ('tests/compute_provider_ggml/attention_math_test.cc', 'attention-math-test', GGML),
    ('tests/graph/region_provider_test.cc', 'region_provider_test', TEST),
    ('tests/graph/constant_artifact_cache_test.cc', 'constant_artifact_cache_test', TEST),
    ('tests/graph/executable_test.cc', 'executable-test', TEST),
]


def compile_jobs(jobs):
    for args in jobs:
        compile_one(*args)


def link():
    replace = {
        'device.obj': 'device', 'operation.obj': 'operation',
        'resources.obj': 'resources', 'region_access.obj': 'region_access',
        'executable.obj': 'executable', 'submission.obj': 'submission',
        'execution_source.obj': 'execution_source',
        'constant_artifact.obj': 'constant_artifact',
        'batch.obj': 'batch_execution', 'copy.obj': 'batch-transfer',
        'native-provider.obj': 'native-provider', 'aten-provider.obj': 'aten-provider',
        'ggml-provider.obj': 'ggml-provider', 'cpu-torch.obj': 'cpu-torch',
        'cpu-region.obj': 'cpu-region', 'graph-batch.obj': 'graph-batch',
        'region_provider_test.obj': 'region_provider_test',
        'constant_artifact_cache_test.obj': 'constant_artifact_cache_test',
        'executable-test.obj': 'executable-test', 'native-batch.obj': 'native-batch',
    }
    command = []
    for arg in BASE:
        p = Path(arg)
        if p.name in replace:
            name = replace[p.name]
            if name == 'batch-transfer':
                command.append(arg)  # No signature/ABI changes in this TU.
            else:
                command.append(OUT/(name+'.obj'))
        elif arg.upper().startswith('/OUT:'):
            command.append('/OUT:'+str(OUT/'controls.exe'))
        elif arg.upper().startswith('/MAP:'):
            command.append('/MAP:'+str(OUT/'controls.map'))
        else:
            command.append(arg)
    added = ['custom-kernel', 'cpu-policy', 'onednn-provider', 'onednn-normalization',
             'onednn-region', 'ggml-index', 'transfer', 'command_capture']
    added += [job[1] for job in TESTS if job[1] not in
              {'region_provider_test','constant_artifact_cache_test','executable-test'}]
    command.extend(OUT/(name+'.obj') for name in added)
    command.append(ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cpu-gallocr-faults.obj')
    explicit = [str(x).lower() for x in command if str(x).endswith('.obj')]
    assert len(explicit) == len(set(explicit))
    run('cpu-controls-link', command)


def test():
    old = json.loads((ARCH/'execution-convergence/summary.json').read_text())['filter']
    selected = old + ':' + ':'.join([
        'Device.*','Context.*','Queue.*','CustomKernel.*','GraphCustomKernel.*',
        'Invocation.PreparedReplayFollowsQueueIdentityAcrossPublicHandleMoves',
        'RuntimeProviders.ExtensionSubmissionRequiresItsExactOpenContext',
        'RuntimeProviders.OrderedQueueAdmitsOnlyOneRecordingSequenceAtATime',
        'RuntimeProviders.QueueSequenceEnqueuesOnlyCompatibleCompletionWaits',
        'GraphRegions.ColdRegionAccessUsesActualLaneAndExactContextQueue',
        'GraphRegions.PreparedReplayChecksReplacedQueueOwnerAndClosedContext',
        'GraphRegions.BorrowedCaptureLaunchUsesOriginalAdmissionAndRejectsForeignContext',
        'GraphRegions.CapturesAndReplaysACommandSegmentWithoutRewalkingItsSteps',
        'GraphRegions.FailedCommandAndCapturedSlotsRetireAtTheActualTerminal',
        'GraphRegions.RejectedTailIsReportedAfterTheAcceptedAsyncPrefix',
        'GraphRegions.MultiTargetIndependentSinksUseANonblockingAggregate',
        'GraphRegions.AbandonedAggregateRetainsEveryIndependentSink',
        'BatchWorkspace.*','PreparedDomainContract.RejectsBrokenInstancesAndDestroysOwnedPartials',
        'GgmlCpuMathAttention.FiniteSinkAcceptsFullyMaskedSingleKey',
    ])
    run('cpu-controls-run', [OUT/'controls.exe', '--gtest_color=no',
        '--gtest_filter='+selected, '--gtest_output=json:'+str(OUT/'cpu-results.json')])
    result = json.loads((OUT/'cpu-results.json').read_text())
    assert result['failures'] == 0 and result['errors'] == 0
    (OUT/'cpu-summary.json').write_text(json.dumps(dict(tests=result['tests'],
        failures=result['failures'], errors=result['errors'], filter=selected,
        vendor_rebuilt=False), indent=2)+'\n')


if __name__ == '__main__':
    {'owners': lambda: compile_jobs(OWNERS), 'tests': lambda: compile_jobs(TESTS),
     'torch': lambda: compile_one(*OWNERS[5]),
     'batch': lambda: compile_one(*OWNERS[-1]),
     'link': link, 'run': test}[sys.argv[1]]()
