from pathlib import Path
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PREVIOUS = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/derived-constant-implementation'
commands = json.loads((PREVIOUS / 'commands.json').read_text())
cc = next(row['command'] for row in reversed(commands) if row['tag'] == 'graph-executable-compile')
flags = [arg for arg in cc[1:] if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]
flags += ['/I' + str(ROOT / 'src/graph')]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

def run(tag, args, timeout=180):
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': cc[0], 'CMAKE_C_COMPILER': cc[0]})
    env['VSLANG'] = '1033'
    args = list(map(str, args))
    records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []
    stem = f'{len(records)+1:02d}-{tag}'
    start = time.monotonic()
    result = subprocess.run(args, cwd=ROOT, env=env, capture_output=True,
        timeout=timeout, creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / (stem + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag, command=args, exit=result.returncode,
        seconds=time.monotonic()-start, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log'))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(stem, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:] + result.stderr.decode(errors='replace')[-2500:])
        raise SystemExit(result.returncode)

if __name__ == '__main__':
    source = sys.argv[1]
    run(Path(source).stem+'-compile', [cc[0], *flags, ROOT/source,
        '/Fo'+str(OUT/(Path(source).stem+'.obj'))])
