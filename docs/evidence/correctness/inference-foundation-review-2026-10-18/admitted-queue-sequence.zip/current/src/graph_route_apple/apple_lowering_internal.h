#pragma once

#include "hyle/graph/apple.h"
#include "hyle/graph/region_provider.h"

namespace hyle::graph::apple::detail {
// The original typed lowering and native Program, restricted to the selected
// Graph boundary. Constants follow request.constants order and are ready real
// native array views; no second graph or per-submit lowering is constructed.
Result<compute::apple::Program> prepare_region(
    const std::shared_ptr<compute::apple::detail::Runtime> &,
    const RegionCompileRequest &, std::span<const mlx::core::array>) noexcept;
}
