#pragma once

#include "hyle/error/status.h"
#include "hyle/graph/visibility.h"

namespace hyle::compute { class ReadLease; class ConstTensorView; }

namespace hyle::graph {
class ValueId;
namespace detail {
struct InvocationState;
struct ResourceEpisode;

// Cold opt-in storage owned by the one original InvocationState. Provider
// invocations are destroyed before this owner and its external payloads.
class ResourceEpisodeOwner final {
public:
  ResourceEpisodeOwner() noexcept = default;
  explicit ResourceEpisodeOwner(ResourceEpisode *state) noexcept : state_(state) {}
  ResourceEpisodeOwner(const ResourceEpisodeOwner &) = delete;
  ResourceEpisodeOwner &operator=(const ResourceEpisodeOwner &) = delete;
  HYLE_GRAPH_API ResourceEpisodeOwner(ResourceEpisodeOwner &&) noexcept;
  HYLE_GRAPH_API ResourceEpisodeOwner &operator=(ResourceEpisodeOwner &&) noexcept;
  HYLE_GRAPH_API ~ResourceEpisodeOwner();
  ResourceEpisode *get() const noexcept { return state_; }
  explicit operator bool() const noexcept { return state_ != nullptr; }
  HYLE_GRAPH_API void reset() noexcept;

private:
  ResourceEpisode *state_ = nullptr;
};

HYLE_GRAPH_API Status resource_control_ready(const InvocationState *) noexcept;
HYLE_GRAPH_API Status reset_resource_payload(InvocationState &) noexcept;
HYLE_GRAPH_API void reset_resource_bindings(InvocationState &) noexcept;
// Called only after a raw TensorView binding succeeds. Its storage remains
// explicitly borrowed; a later owned bind replaces this marker with its lease.
HYLE_GRAPH_API void note_borrowed_binding(InvocationState &, ValueId) noexcept;
// Borrow only a genuinely owned ready read covering this exact physical view.
// Native cold adapters may copy it into an independent array owner.
HYLE_GRAPH_API const compute::ReadLease *input_lease(
    const InvocationState &, compute::ConstTensorView) noexcept;
} // namespace detail
} // namespace hyle::graph
