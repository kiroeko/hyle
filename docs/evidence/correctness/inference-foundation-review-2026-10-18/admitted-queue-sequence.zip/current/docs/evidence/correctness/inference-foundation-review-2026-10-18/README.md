# 非多模态推理底座全量审查

2026-10-18，按用户要求启动大 goal，当前审查进行中。范围是既定8个文本模型、22个官方/GGUF制品配置，
覆盖受支持系统上的CPU、单GPU、CPU＋单GPU。模型事实沿用[来源目录](../../../implementation/tasks/compute/llm-moe-model-sources.json)
和[制品目录](../../../implementation/tasks/compute/llm-moe-provider-demand-matrix.json)，旧表的流程状态不作为当前结论。
此前已完成的局部修复及其证据见[接线与高维批次报告](../model-route-completion-2026-10-18/README.md)，本轮在当前源码上继续检查。

原功能审查未完成的范围继续由架构重构承接，不以迁移完成代替功能补齐，也不保留旧 API 兼容层。
本批已把资源租约、结果和 batch/page/pending 控制收进原 Invocation，删除旧 Graph 租约与批次协调入口；
原 core 六项、CPU 租约重放、CPU pending 九模式、CUDA F16/BF16 真 gate→F2→MLA，以及两槽 CPU＋CUDA
控制通过。复用现有 native/SDK；旧缓存闭包和迁移漏冷准备造成的失败及其更正均保留。
[源码与原始记录](unified-invocation.zip)。generated-output、其余混合运行时及下文未完成的模型功能仍须继续。

后续批次将执行目标、region 与常量制品改为保有实际 `ExecutionSource`，删除原 Context 指针入口；
共同资源核心的 Gather 数学特判也已移到 typed 模块，由实际 singleton/融合制品证明受限读取。
共享源与原异步资源控制 13/13、迁移后的原 CPU materialized 完整消费者、真实 Vulkan 源与输出 backing 1/1 通过；
调用方按新接口迁移，未保留旧字段或转发入口。Vulkan 检查使用原生 Program/Invocation，不能代签统一 Graph 的原生结果链。
首次闭包 ABI 崩溃和新测试误选 native 未承载的 F32 Neg 均保留，分别复用匹配闭包、改用实际承载的 Exp 后通过。
[本批源码、命令与结果](execution-source.zip)。没有重建 SDK，也未运行多平台全矩阵。

统一 Invocation 后的 Qwen 三 phase 另有 150/150 trace 文件与冻结基线逐字节一致记录（同包保留），
它验证该次迁移没有改变既有输出；与独立 oracle 约 2% 的原数值差异仍未接受。本批 ExecutionSource 变更后未另跑完整模型。

原生生成结果随后已接通第一条普通 Graph 纵向：实际 Vulkan Source 通过 `graph::compile` 发现真实 region，
同一 Executable／Invocation 持原 Program、原结果 storage 与原 Completion；生成端口不分配影子 workspace。
Windows RTX 4070 上两个原始消费者通过，覆盖两槽、创建时／绑定后 backing、computed/input View、
旧 GraphOutput 和独立 lease 阻止覆盖、释放后复用、关闭后保活与无回指环，以及借用原生常量的两 phase。
其中一槽走统一 ResourceEpisode 的拥有式 ReadLease 绑定。共同异步寿命控制 13/13 和原 CPU materialized 消费者亦通过。
实际执行检出了已有原生结果附件与 cursor 的单附件冲突，现用原 CompletionRetention 组合，且在节点释放后才发布槽可复用；
失败日志与更正保留在[源码、命令与结果](native-generated-output.zip)。未重建 SDK／shader，也未重跑完整 Qwen。
这证明固定纯图链路，尚未证明 Apple 晚生成句柄、全部混合／跨片段路线、CPU→native 常量物化或完整模型／性能。

后续[冷常量搬运与能力准入](cold-constant-copy.zip)已把 CPU→Vulkan 的 `kMaterialize` 接入同一编译入口：
先校验实际资源和完整批次，再复用一份最大容量 staging／原 TransferSlot 上传；临时字节计入编译峰值，
成功后捕获目标常量，重放不再读取源。RTX 4070 上四项原生用例通过，含 16／4／3B 常量、释放源后两 phase、
预算预拒绝、外来资源整批拒绝、读取错误及一次真实 fence 观察 OOM 的原生退休与首错保留。
共同编译同时删除同 Device 总门和 `compile_cpu_gpu` 后端 ID 特例，仍保留实际 owner、资源、搬运与完成依赖检查；
相关常量／共享／失败／跨 Device 准入控制 26/26，原完整 CPU materialized 消费者通过。
测试使用匹配 host 对象和现有 SDK；旧对象引用已删私有签名的链接失败、测试预算漏 metadata 域的失败及修正均保留。
没有重建 SDK／shader；本批未重跑完整模型或实际 CPU＋CUDA 消费者，不代签其余混合路线、Apple 晚句柄、旧入口删除或性能。

后续[原生晚端口与有限形状](native-ports-finite.zip)已接通 Apple 同一 Runtime 的普通 Graph 原生结果链：
原槽／原 Job 解析真实端口，consumer 接纳后短期 pin producer，checked 失败不发布后继；指定 MacBook Air
原生四例通过。零公开输出的控制片段保留 Program 私有终点。只读输入、借用常量及结果导出按实际 Source
证明资源族；独占输入不额外捕获将升级回 writer 的 reader，最终相关控制 3/3 通过。
有限精确表现由共同冷编译承载，没有通用路线、热编译或独立执行器；形状／预算控制 11/11，
实际 Vulkan、Apple 及 CPU＋CUDA 消费者通过，三者旧形状表薄包装已删除。Apple／Vulkan 的其余混合入口仍在迁移。

同包记录了 Apple 拥有式 View 反馈的实际前后对照：同一 16B 子范围、64 轮，旧版存活元数据从
39块／51,152B 增至615块／245,712B；复用原 ReadLease 子范围后，各采样点均为23块／45,280B。
原生 Graph 原两例与反馈例 3/3 通过，含精确权限、原 owner、新计算结果、关闭后读取与最终释放。
这是元数据寿命修复，未测吞吐，未宣称少复制 payload。包保留定位失败、匹配对象身份、源码和命令，
没有 SDK／binary；本批未重跑完整 Qwen、Linux 或大矩阵，不代签跨 Runtime、全部混合路线与剩余模型功能。

后续[canonical 常量所有权](canonical-constant-owners.zip)改为逐项保有真实分配，按精确描述、实际资源与足够对齐
共享 ready owner；候选重试恢复原始来源，释放不兼容副本，family 只扣除真实共享字节。
三项隔离对照确认修复必要：旧重试留下4条对齐记录对应2实例并残留256；禁用实际偏移检查后，+4B/min64输入
被提交且改写哨兵；旧版允许将可写输出绑到借用常量。修复版最终13/13通过，包含+8B/min8合法双View链、
独立输出重复执行、只读常量/View及packing累计预算。此前family相关19/19、RTX4070原Vulkan四例4/4也保留各自
源码与对象身份；Vulkan四例发生在最后常量alias保护之前，不作为该保护的测试。初始fixture构造/资格错误均如实保留。
同计划跨存储常量副本的冷准备、CPU/native动态copy和分段发现仍未完成；本批未重跑整模型或新增跨平台验证。
归档786,133B，不含SDK或binary；随后经根目录`test.ps1`逐项核对并清理18个可重建文件，共275,013,775B，保留全部对象缓存。

后续[原生重放搬运与分段发现](native-replay-discovery.zip)将 CPU＋Vulkan 固定／有限形状数据链接入共同入口，
删除其旧形状表包装。实际 host、staging、device 域双向搬运；原 CopyRecording 仅冷绑定录制，同槽同址改内容后
直接重复 submit。控制失败保留 CPU 输出哨兵，原生待退休提交拒绝复用，已 settle 的旧 Completion 与新 Run 独立。
发现协议直接升级为22，按实际 target/Provider 许可和原承载资格生成片段；共享入口前沿算法为 O(V+E)，
后继新增外部前驱时切分，避免早期工作额外等待。零公开输出片段仍执行实际私有终点。
最终 Windows 相关控制16/16、原生 Vulkan及原 CopyProgram回归6/6、CPU→Vulkan→CPU 两个形状各两轮通过；
MacBook Air 最终原生5/5及 finite/control 消费者通过。原生冷适配同时保留真实来源校验和原 admission，
两实际片段交接、四类无效适配拒绝、旧结果和 checked 失败均有实测。初始测试对已 settle Completion 的错误期待、
融合后旧 region 数断言与旧适配门拒绝日志保留，未据此伪造产品性能缺陷。没有重建 SDK、shader或跑全矩阵。
同计划常量跨存储冷准备、其余混合／跨 Runtime、分页与 custom 迁移、完整模型数值及公平性能比较仍未完成。
归档1,706,069B，不含SDK／object／binary；经根目录`test.ps1`核对后清理 Windows 12个、Mac 10个
可重建binary/map/export文件，共314,322,548B，全部源码、日志、数据和对象缓存保留。

后续[冷常量物理副本](cold-constant-replicas.zip)把同计划跨存储的 Graph 常量根移到冷准备，
每个物理实例关联唯一 allocation owner，主借用政策保持不变；metadata View 共享完整目的根，再恢复具体偏移。
region 与 packing factory 使用实际本地副本；候选重试按真实 key 重新关联 ready owner，累计预算只扣一次。
主机11/11通过，含双存储不同偏移、目的域 View 发布、双槽直接重放/reset、有限形状共享、子路线寿命和精确预算边界。
Vulkan 最终9/9及原 CPU→Vulkan→CPU 消费者通过；冷上传、下载与对齐 D2D 复用原 Slot/Recording/Completion，
实际复制错误包含 Unimplemented 均不换路重试。逻辑分配长度与本次复制长度共同约束 padding，裁短 span 或短描述
不能借完整根的尾部权限。host staging 与 D2D 容量分别计算，纯 D2D payload 暂存为0，16B D2D＋3B host 批次为4B；
这是请求字节和实际分配参数的结构证明，不是 driver/RSS 峰值或吞吐测量。
Apple 原生源补齐无 CPU Context 的冷物化，真实共享 Metal 目标校验 device、范围及可写性；readonly 导入只能作源。
指定 Air 最终7/7及 native finite/control 通过，含16B权重跨两个形状只读源一次、源释放后双槽数学、odd3B和实际源错误。
初始测试遗漏 CPU caller 输出／HostResource map 的失败与更正均保留；共同层新别名曾提前检查 Provider 对齐，
现恢复在 prepare_replay 校验并通过原动态偏移回归。未重建 SDK、shader、跑矩阵或完整 Qwen；其余跨 Runtime、
分页/custom/旧执行链与继承的模型功能审查仍未完成。归档1,652,687B，不含SDK/object/binary；经根目录
`test.ps1`核对后清理 Windows12个、Mac8个可重建文件，共301,688,977B，保留源码、日志、数据和全部对象缓存。

后续[Apple 只读结果权限](apple-readonly-ports.zip)修复 ImportedArrayStorage 继承可写映射的问题，
并让原 Metal copy 的源／目标校验显式区分读写。真实 Graph 成功输出仍由原 ReadLease 与实际 resource 保活；
主机写映射、write/fill/copy 目标、普通与晚生成源 blit 的目标均拒绝，合法只读源和普通可写分配保持可用。
指定 Air 仅新编 memory、copy recording、copy program、native test 四个 TU，复用原 SDK 与最新共同图对象，
最终8/8通过，包含原融合、常量、拥有式结果、晚端口、epoch 与 checked 失败用例。
CPU＋Apple 的跨域晚端口冷选路与异步交接仍在迁移；本批没有实现该桥接或重跑整模型／性能比较。
归档后经根目录 `test.ps1` 精确清理本批 Mac binary／map 共14,171,868B，保留四个新对象及源码、日志、数据和SDK。

后续[端口承载与原生晚源 Copy](carrier-copy-contract.zip)将输入的原引用接纳、输出的可用时机及 Mem 投影承诺
放到同一冷提议中，最终制品按逻辑端口核对；共享／原生分类不再冒充引用能力。同 storage 也可明确准备 caller
副本，原 producer 保留给合法原生消费者；普通 Copy 不因 HostAccessible 就认未来句柄已存在。
Apple 复用原 InputSource／CopyRecording／FIFO Job／Completion，冷映射目标、每轮按新 epoch pin，
成功校验后才复制和 flush，失败／取消／拒绝 admission 均放 pin，实际接受后才消费 epoch；只读导出保持只读。
结果观察同时核实际 Source 的资源匹配与 Mem 投影承诺。Vulkan 的逐输出资源提议只存边界和所选 View 的稀疏事实，
不再为每个候选清整图大小的数组；这是结构复杂度改进，没有据此宣称吞吐收益。
最终 Windows host9/9、Vulkan9/9及原 CPU→Vulkan→CPU 有限形状／控制消费者通过。
指定 Air 最终11/11：真实默认 CPU→Apple→CPU 的两种 shape、双槽、两轮原绑定严格重放、旧结果保护与 checked
失败目标不变；原生所有权、常量和晚端口回归及新 Copy 的旧 epoch 拒绝、pending pin、旧 Completion 和失败退休通过。
新混合测试最初缺头／误用 Result 及错误地仅绑定不承载 F32 Abs/Neg 的参考 Provider，修正后使用默认 CPU 组合；
所需 CPU／batch host 对象及同456 pin当前锁定 native ops／allocator 差异按实际缓存准备，未混入另一 CPU-only pin。
当前 ContextRef 接口的两个旧缓存链接缺口也已用相应当前 TU 补齐，全部失败和 source／object 身份保留。
没有重建 Metal、shader 或整套 SDK，也没有跑整模型或性能比较。现有公开 submit 的显式 host-wait 仍可阻塞调用线程；
本批未实现统一 continuation，不把数据链通过等同于旧混合执行器已删除或完整异步迁移已完成。
归档共2,395,626B，SHA256 `3b2d90626b94a9e6dc02edc7a697c317b7c3184b8000ec9765862c75e2472aaf`。
归档后经根目录 `test.ps1` 精确清理 Windows 12个 image／map／导出文件共247,896,469B及 Mac 两个 image／map
共17,565,669B；保留本批 Windows 九个对象、Mac 13个主对象及15个 CPU overlay 对象，源码、日志、数据及SDK不删除。

后续[执行职责与有限形状收敛](execution-convergence.zip)将同一个提交游标、终点聚合与实际退休实现移至
`submission.cc`，冷 capture 和热提交仍复用原片段录制函数，未添加 Plan／Invocation 状态或调度器。
默认 CPU Provider 装配与 batch 冷编译拆开 TU；原生形状表模板和最后 CPU＋Apple 薄包装删除，实际 finite
消费者改用共同 family。通用 exact specialization／native analysis 回归保留，原模板的工厂测试由已有共同
family 的真实 finite、重复／非法点、部分分配失败与预算回归承接。Windows 六个相关 TU fresh、24/24通过；
指定 Air 六个相关 TU fresh、22/22及完整 Apple finite／control／旧结果消费者通过，原数值SDK／shader未重建。
Windows 另一个仅 create_context 的缩小链接仍未闭合：新 context 对象没有 graph_batch 编译直接引用，但
实际默认 Provider 仍带 native Batch／MLA 能力；补其既有缓存闭包时遇旧 operation 重复定义，三次失败均保留。
对象符号证明不等于整个默认路线已经剥离 batch。Queue 原状态、已接纳回调和原 Completion 的异步移交仍待贯通；
本批只改变职责归属与删除重复形状入口，没有宣称完整异步支持或整模型／性能接受。
归档共1,026,593B，SHA256 `2d1f0a19c15f8cffb52224ece82ea1627f23df9fbee0905851efec2866a0189d`。
归档后经根目录 `test.ps1` 精确清理 Windows 七个可重建产物55,635,606B和 Mac 四个 image／map 34,344,118B；
本批 Windows 七个对象、Mac 六个对象及全部复用缓存、历史源码、命令、日志和数据保留。

后续[原队列寿命与已接纳序列](admitted-queue-sequence.zip)将共同 Graph 的队列绑定改为持有原 QueueState，
原 QueueSequence 从接纳到 finish 保活同一状态；prepared／region／extension、CUDA stream／status、batch 和
custom-kernel 热回调均传原序列。删除回借公开 Queue 的旧内部入口，直接升级 Provider15、Region24、Batch5、MLA3。
公开句柄移动不改变绑定，close 拒绝新接纳，已接纳的原序列仍完成；没有会关闭原队列的第二个 Queue 包装。
两项新增回归使用真实 CPU backend 和 Graph 数学，覆盖移动／销毁／关闭、单 producer、精确状态释放与关闭后输出保护。
Windows 最终相关69/69通过；指定 Air 鲜编36个 Hyle host TU，24/24及原 Apple finite 消费者通过。
CUDA 的28个相关 host TU源码编译通过，RTX4070 上真实 native CUDA Provider 的原 finite 数学／非法点／配额／
旧结果消费者和两项 checked Gather 通过。该消费者仅在实验源码中显式装配真实 native Provider，原默认消费者未改。
默认 ggml CUDA 当前补丁的配套 native 缓存未找到；旧缓存头缺 IQ1 枚举，独立原始参考库也缺 Hyle resource 桥，
均未混用。tensor_program 使用已核同 pin 的公共头鲜编只证明源码编译，不证明当前 ggml CUDA native 闭包运行。
Mac 严格编译另修两个显式缺省初始化，以及原 DS4 header 未用函数的局部 Clang 护栏；失败命令、补闭包过程均保留。
数值库、CUDA kernel、Metal shader和整套SDK未重建。独立 batch/copy、旧混合协调器仍有公开句柄借用合同；
原 Completion 的异步移交、统一前沿和旧执行链删除仍未完成，本批未运行 Linux、完整模型或性能比较。
后续只读设计审查确认当前线性游标遇 HostWait 会挡住后续独立片段；A异步GPU、B等待A的CPU、C独立GPU copy
可冷排成A/B/C，B pending使C不能提交。这是源码推导，未运行新的吞吐实验。旧CPU＋CUDA已有并行CPU child；
下一步须在原计划依赖表和同游标上推进前沿，保CPU/GPU重叠、实际Queue prefix、工作回调与原生退休，
避免让BlockingPool进度任务等待同pool的排队child；本批未把它记作已修性能问题。

## 怎样审查

沿实际模型的prefill、cached continuation、decode、混合请求批次、MTP验证块与接受前缀恢复，
追踪公共API→Provider选择→原生计算→存储与状态反馈。只存在算子或测试源码，不代表整条调用链已验证。

| 部分 | 核查内容 |
|---|---|
| 融合与量化 | embedding/LM head、dense/batched投影、norm/gate/RoPE、MoE路由及expert/combine、GDN/KDA/conv；按实际dtype、block/scale、形状、布局及数值合同核对 |
| Attention与KV | 普通/分页/ragged、MLA共享latent、稀疏indexer/TopK/Gather、逐query可见性与sink、cache编码/追加/窗口/压缩 |
| Graph编译与执行 | 分区/融合边界、路由偏好、常量、别名、内存复用、动态形状、规划/重放与多queue/lane调度 |
| 驻留与搬运 | 权重和状态驻留、host/device桥接、增量上传、重复分配/解码/repack/contiguous/cast/实体转置及同步 |
| 状态与寿命 | GDN/conv/KV/压缩索引的共同版本、fork/COW/回收、接受前缀恢复、pending来源、失败/取消/关闭/排空及输出保留 |
| 接入完整性 | 普通Direct/Graph入口能否表达真实推理；内部布局/Provider细节是否不必要地交给消费者 |

结论分别标明缺功能、可组合但缺高效承载、实现错误、实际资源/数值限制及未验证。
以当前路由和实际执行成本判断，不以现有白名单缩小需求，也不把不同工作、显式参考成本或普通数值要求当作性能缺陷。
先修确定问题，围绕改动做小范围编译、数值/寿命或成本对照；复用现有工具链与依赖缓存，不反复全库重编。

当前已首轮核对模型主路径，并对下表事项深入修复；还不能称为全面完成，也不能用修复条数计算覆盖率。
仍需横向补审全部制品的实际默认路由、CPU＋GPU混合旅程、prefill→续算→decode→接受前缀的连续消费，
以及各路线的动态长度、规划/重放、分配与失败寿命。四后端的局部消费不等于每个模型在每条路线均已闭环；
完整bank个例与轻量缩形状也分别记录，避免将未实际运行的容量或组合计作通过。
这些未完范围继续由新架构承接：删除重复路径、收拢承载分析和权限合同，不等于补齐数学实现或证明模型整链。
完成状态按具体需求、路线和消费证据判断，不从修复条数或历史百分比推算；迁移目标不保留兼容层、旧入口薄包装或双执行体系。

## 模型域核对

以下为仓库选定制品的源码接线审查，不是22个完整模型的运行记录。普通provider仍按具体描述与资源
接纳；不因为模型名相同就假定算子、激活量化或存储格式相同。

| 模型（制品数） | 实际主路径 | 仍需区分的边界 |
|---|---|---|
| Qwen3.5-2B（3） | 官方BF16投影；GGUF的K/IQ4/Q8投影及Q6K或F16 tied vocabulary；GQA、conv、F32 GDN状态 | 官方BF16完整24层CUDA消费者已有三phase执行及token一致证据，精度接受仍未确定；不代签其他制品或完整引擎 |
| Qwen3.8-27B（3） | 同族投影与GQA24/4；实际vocabulary为Q4K→Q6K或Q8→BF16；F32 recurrent | 不把制品级混合dtype压成一个“Q4”标签 |
| Qwen3.8-2.4T-A95B（3） | BF16或IQ4_XS/K/Q8专家、F32 router/GDN；完整bank E512/N2048/K8192 | resident11与完整bank分开；CPU/CUDA压缩bank过度门已修，设备实际容量仍有限 |
| Kimi-K3（3） | 官方FP4无损冷repack为GGUF MXFP4，再以F32 activation作GroupedMatMul；GGUF同族专家，Q8/BF16 dense/vocabulary；KDA | 不误接为DeepSeek A8 FP4；缺3584↔3072的A8制品不构成此模型缺口 |
| DeepSeek-V4-Pro（1） | 官方block FP8 dense、原A8 FP4专家3072↔7168；compressor、Indexer、Sink、Hyperconnection | 无本轮选定GGUF；密集组合、分页原生承载、packed物理历史分别判断 |
| DeepSeek-V4-Flash（3） | 官方原A8 FP4专家2048↔4096及FP8；GGUF MXFP4专家、Q8/BF16 dense；原roundtrip数值边界 | ratio4及ratio128的多query/接受前缀CPU消费见后文，不外推其他后端整链 |
| GLM-5.3（3） | 官方block128 FP8；GGUF Q4K/Q5K/Q8及Q8 vocabulary；吸收后MLA H64、576→512 | CUDA官方E256单projection完整bank已实际验证；不以同dtype代签packed gate/up或全层 |
| GLM-5.3-Flash（3） | 同族FP8/GGUF及KDA；MLA512→512 | E288总bank已无上述CUDA误门，但本轮未另分配完整bank实跑；Vulkan BF16 attention仍不支持 |

主路由为：plain dense由CPU oneDNN／CUDA cuBLAS与相应native浮点路线承载；GGUF投影/专家由各端
ggml承载；官方FP8/FP4由CPU ATen、CUDA SGLang/DeepSeek、Apple MLX、Vulkan IREE等原组合按域接纳。
直接源码锚点是各端`default_policy`、`torch_cpu_program.cc`、`apple_mature_float.cc`、`vulkan_official.cc`
与模型fixture中的实际storage descriptor。GPU GET_ROWS缺的三个IQ1 narrow变体不在所选embedding列表中，
仍作为公共catalog边界保留，不能通过白名单放开冒称已有native行解码。

## 已完成的修复与补全

以下是本轮已完成的局部修复，不代表全量审查结束。测试使用实际现有硬件和缓存原生库，重新编译改动的host/测试翻译单元。

| 事项 | 原因与修复 | 验证与边界 |
|---|---|---|
| CUDA FP8误拒兼容驱动 | 精确driver版本判断与SM89 AOT模块的真实加载能力无关；移除精确版本门槛，保留SM、模块/函数加载及错误处理 | 实际driver API 13040下2/2组件测试通过，覆盖F32/BF16、grouped、重复调用和寿命；13050只是host报告事实的对照，未声称测过另一台驱动机器。[包](fp8-driver.zip) |
| CCCL误拒新SDK/runtime | 删除历史toolkit/runtime上下限和固定CCCL版本选择器；保留实际环境、形状和native configure/launch检查 | 实际环境7/7通过；同一原生闭包报告13050时，旧代码7项prepare失败，新代码7/7通过。此对照不更换真实SDK。[包](cccl-qualification.zip) |
| FlashInfer非正QK scale错误 | 原生softmax实现不能承载非正scale：旧代码scale=0最大绝对误差0.45456，scale=-0.5所有128个输出为NaN；普通及batch入口现在提前拒绝该域 | 新规范测试1/1通过，正scale对照误差5.84e-5。普通SDPA可以选其他合格provider；专用batch明确返回不支持，不伪装存在自动fallback。[包](flashinfer-scale.zip) |
| 状态metadata重复分配 | 每次replace_metadata新建小buffer；现在在原StateStore预算及租约体系内复用空闲、唯一且实际可写的同尺寸snapshot，压力时优先释放空闲项 | StateVersions/StateClone 31/31通过；32步中前2步热身，后30步禁止metadata allocator后仍零新增调用。逃逸只读视图和native use保持不可覆盖；Store销毁后仍可读。未声称整模型延迟收益。[包](state-metadata.zip) |
| CUDA BF16专家常量每次转F32 | 保留F32激活计算合同，仅将Graph不可变专家权重放进现有ConstantArtifactAccess，冷准备一次；动态权重仍按输入处理 | 独立FP64数值/寿命回归1/1通过；实际native图计数为冷准备1次copy、两次常量调用均0次copy、动态调用每次1次copy。[包](cuda-constant-expert.zip) |
| Graph重复output bind扫描全部常量 | 所有后续绑定都已检查既有output范围，重复绑定相同resource/handle/offset/size无需重新扫描全部input/constant/output | 仍执行原绑定、发布及capture失效流程，变化的输入/输出继续检查。新回归及相关Invocation/GraphViews 32/32通过。[包](graph-rebind.zip) |
| CUDA/Vulkan多请求RoPE接线缺失 | 公共schema允许positions[B,S]与frequencies[S,pairs]，原ggml接线只允许共享向量；沿原原生算子补reshape/broadcast，并接受等价的sequence_axis=-3 | CUDA新旧2/2测试通过（F32/F16/BF16），Vulkan1/1通过（F32/F16）；覆盖两种旋转布局、两种位置、两种频率及两次变更输入。原phase F32及输出dtype不变，无新kernel/SDK构建。[包](batched-rope.zip) |
| CPU/CUDA Dense常量RHS每次转置 | 原native MatMul每个invocation构造contiguous转置并每步执行；沿既有ConstantArtifactAccess冷准备一份，动态RHS与原权重其他consumer不变 | CPU2/2、CUDA2/2组件数值/寿命测试通过；CUDA native图计数cold CONT=1、两constant调用各0、dynamic各1。CPU ggml也补齐同域RoPE，并通过F32/F16/BF16回归。未测完整roster/吞吐。[包](dense-cpu-cuda.zip) |
| Vulkan Dense常量RHS每次转置 | 沿原captured Tensor/Program持有和View/Copy冷准备，仅替换MatMul消费者；原权重仍可被Neg等其他节点使用，不新建cache框架 | public graph::vulkan::compile的F32/F16常量/动态、两slot回放数值及原RoPE共2/2通过；两dtype计数constant CONT各0/0、dynamic各1/1。BF16 widening不在此修复内。[包](vulkan-dense-constant.zip) |
| 紧凑MLA缺公共单cache承载 | 新typed MLA schema/独立extension、单kMla arena和2payload Direct/3port Graph；普通独立Q/K/V合同不变。CUDA接原专用CKV512/KPE64内核，避免普通576→512超SM89共享内存 | F16/H96、BF16/H64，两request Q1+Q3、KV31+33、非顺序/重复页/尾页，Direct/Graph及原Queue capture、重绑、预算/整数上界检查通过。单cache73728B，native float/int workspace约5.77/0.56MiB；并非总显存。无sink/mask/F32/encoded支持声明。[包](cuda-compact-mla.zip) |
| MLA H96 causal漏算可见tile | 实测首条输出错误，native scheduler已用ceil而kernel用floor求cluster的query上界；统一为ceil，保留逐element causal mask | 同输入/预算修前maxAbs0.012644，修后F16 maxAbs5.52e-5、BF16重绑最大4.69e-4；原独立Q/K/V consumer也通过。FlashInfer补丁lock/source/NOTICE身份已同步v17。[同包](cuda-compact-mla.zip) |
| CPU紧凑MLA承载 | 沿原flash paged/ragged计算，V为同一CKV buffer的只读strided前512项，保留576行跨度，无V拷贝 | 8组合通过：F16/H96、BF16/H64 × CKV512/CKV512+KPE64 × paged/ragged；每组Direct三episode＋Graph、default Context、Q1 native plan复用、完整FP64数值。最大误差2.44e-4；原Q/K/V三项相关回归3/3通过。[包](cpu-compact-mla.zip) |
| CUDA单节点BF16专家仍重复转换 | 先前cold-pack只在多节点region生效；现在仅对原ggml承载的不可变plain BF16专家权重接纳单节点region，不改变普通dense的oneDNN/cuBLAS选择 | 单节点、多消费者、dense共3/3回归通过；新增单节点cold Cast=1，两constant invocation热Cast=0/0，dynamic=1/1。[包](cuda-single-constant-expert.zip) |
| 同布局反复分配和排序页集合 | 将immutable layout的active页ID排序去重结果按需保留，由K/V及后续读取共享；每个frame/guard仍独立分配和取得实际权限 | 49项BatchLayout/PagedArena/PagedAdmission测试通过；32页同version的8对K/V读取48→32次metadata分配，新version首次读取6→5。OOM可重试、并发首次构造、旧版本与权限不驻留均覆盖。[包](paged-footprint.zip) |
| Vulkan BF16常量RHS仍热宽化 | 原BF16 carrier每个invocation重新Cast权重并CONT；沿原Cast/View/Copy冷准备一份F32 packed常量，仅替换该MatMul port | F32/F16/BF16×constant/dynamic、两slot、原权重Neg消费者及独立FP64通过；BF16冷weight Cast=1，热MatMul weight Cast/CONT各0/0，dynamic仍各1/1。Neg自己的宽化保持原语义，未泛称全图零Cast。[包](vulkan-bf16-constant.zip) |
| MLA默认partial精度合同 | 原生MLAParams曾把F32累加结果收窄为输出类型的split partial；改为F32 partial并按4B计费，直接从原register布局存储，无shared膨胀 | 真split BF16 Q1/KV8192，正负16384抵消、首row额外256，全32768输出的独立期望值0.03125，当前maxAbs=0；仅恢复旧partial16的对照明确失败。F16/BF16×512/576四组合Direct/Graph通过。[最终包](compact-mla-final.zip) |
| Apple/Vulkan紧凑MLA接线 | 公共typed单cache传到原native/controller与独立Graph，V只读别名CKV前512项、保持原512/576行跨度 | Apple四组合（F16/BF16×512/576）、Vulkan F16两组合，均Direct＋Graph→Neg并发布两结果，完整FP64通过。单cache65536/73728B，不含workspace；Vulkan BF16仍未承载。[同包](compact-mla-final.zip) |
| Vulkan page输出接下游时owner基线失配 | prepare_batch过早记录输出owner数，后续Graph内部GPU绑定增加合法引用；现在准备前原reuse_gate拒旧结果，内部绑定完成后专用reseal | MLA→Neg成功；保留旧OwnedResult或escaped Tensor仍拒绝prepare，实际释放后可重绑和复用；公共submit的owner equality未放宽。[同包](compact-mla-final.zip) |
| 双MLA节点的page-input越界比较 | 原NativePagedSlots共享页检查固定遍历三个tensor输入，MLA只有两个；改按各自真实port数 | 两纯host回归检出旧源码2个断言失败，新canonical TU共5/5通过；覆盖共享cache同layout、异layout与独立cache边界。[包](mla-slot-bounds.zip) |
| CUDA单cache pending追加未接 | 原公共PagedBatchReceiver直接拒绝MLA且只有独立K/V submit；新增单cache overload，与旧入口共用原source/Queue/页面权限及聚合退休逻辑 | F16/BF16真实gate producer→F2→MLA在gate释放前返回submit，完整FP64误差0，拒绝保Update、旧output阻复用、页writer恢复均过；旧CPU receiver九种风险/成功模式全部通过。[包](mla-pending.zip) |
| CUDA专家/量化embedding整ID回读 | 原ggml每次把全部I32 IDs读回host并stream同步；现在局部safe-ID leaf与原Queue device-status结合，整region公开结果只在校验成功时发布 | 最终9项组件/Graph回归通过，含旧18格式embedding、Grouped/BF16、非法ID与多输出、同ID不同extent、两slot及失败寿命；unknown private预算保持。未声称ggml内部TopK融合。[包](cuda-device-indices.zip) |
| 多token MoE路由产生T²中间结果 | 新独立GatherElements逐row选择[T,E]分数，保留旧Gather语义；模型fixture改为TopK自身合法IDs直接选择，只生成[T,K] | CPU/CUDA/Apple/Vulkan三浮点类型、Checked/Unchecked、K>E、重复IDs与变更回放均有独立参考；GPU公开Graph→Neg双结果也通过。真实默认CUDA为CCCL TopK→ggml两step，默认CPU三leaf；无整模型吞吐声明。[CPU](gather-elements-cpu.zip)、[CUDA](cuda-gather-elements.zip)、[Apple/Vulkan](gather-elements-native.zip) |
| MLA按最大工作表预留scratch | 原planner无split也预留约12 MiB partial；现在按实际work/partial项计费，保留16384工作项准入边界、cluster和merge完整容量及F32 partial | 四种小计划用16字节float＋4 KiB integer通过Direct/Graph/更新；真实BF16 split需求4,202,496/2,172字节，精确容量通过、任一少1字节prepare拒绝，敏感残差maxAbs=0。默认slot容量未自动缩小。[包](mla-active-workspace.zip) |
| CUDA完整FP8专家bank误拒 | 原adapter将整个E×N×K限制为I32；原AOT按I64计算专家基址，实际只有单expert的N×K需该限制，删除过度总量门槛 | GLM形状E256/N2048/K6144、codes＋scales共3,222,011,904字节，实际选expert255（codes偏移3,208,642,560）并重复数值验证；新旧组件2/2通过，非法ID仍返回原Completion错误。未分配更大的packed gate/up bank。[包](cuda-fp8-full-bank.zip) |
| CPU/CUDA完整GGUF专家bank误拒 | 仅对canonical rank3压缩Grouped权重按实际block寻址域接纳，保留单dim/单expert stride、压缩block索引及其他端口原限制，不全局删除I32门 | CPU3/3、CUDA5/5通过。E512/N2048/K8192 IQ4_XS共4,563,402,752字节，高expert511偏移4,554,489,856；CUDA实际整bank分配、仅初始化所需expert并两次核全部结果，CPU保留完整虚拟范围、仅commit8,912,896字节后两轮maxAbs=0。Q8仅prepare，Vulkan真实单buffer范围仍拒此bank。[包](gguf-full-bank.zip) |
| CPU＋CUDA权重每步重复排序上传 | WeightBatch的原upload尚未被观察时，即使native event已完成仍被当成pending；在保留Context和Queue admission检查后先非阻塞poll，成功ready时空sequence完成 | 实际CUDA同一ready batch八轮WaitEvent/EventRecord从8/8变为0/0；真pending仍1/1。两项canonical测试通过，另覆盖busy/closed/foreign及源late-error；错误保持sticky且不提交后继，未测整模型吞吐。[包](cuda-weight-order.zip) |
| 跨provider导致前后融合片段一起丢失 | CPU/CUDA ggml discovery只提一个全图eligible集合，经过TopK/FlashInfer等外部节点后整体不合法；改为沿数据与控制边线性切分合法prefix，独立穿插不切分 | 真实默认CPU/CUDA的数据、控制两种边界均由0 region/5 step变为2 region/3 step，独立TopK仍1 region/2 step；所有输出两轮精确对照。canonical CPU2/2、CUDA4/4相关测试通过。region不等于一个物理kernel，未测吞吐。[包](ggml-region-discovery.zip) |
| 同形reshape阻断原生双投影融合 | CUDA每个node恢复shape时即使ne相同也新建RESHAPE，双投影失去同一src1身份且native节点不连续；仅在原contiguous且四维ne完全相同时直接返回 | Q8_0同输入gate/up→SwiGLU，默认八provider图仍1region/1step，但native图8→3节点、5→0 RESHAPE；CUPTI原生kernel发射记录从5变2，单独发布gate/up仍5。两轮完整FP64 maxAbs2.70e-8，canonical3/3通过。非吞吐或CUDA Graph重放测量；对应GLM GGUF denseFFN同语义缩形状，不声称Kimi SiTU或完整GLM已融合。[包](cuda-native-shape-fusion.zip) |
| Apple FP8先展开全bank scale | Grouped路径先将全E的block scale repeat为每row，才take本次IDs；将codes/紧凑scale的选择移到repeat之前，保持原scale乘法及量化次序 | 实际managed图的展开expert维64→本次8；N257含尾block，两phase各2056结果、重复高ID，新旧全部4112个F32逐bit相同，原预算maxAbs=0；三种非法ID仍OutOfRange，旧结果保留。未测物理peak或吞吐。[包](apple-selected-fp8-scale.zip) |
| CPU先复制所选专家完整权重 | ATen grouped先index_select全部K，再逐block计算；改为先借用bank的当前K块，再选IDs，scale也先选当前block/IDs再展开FP8 row128 | canonical五项通过；T3/S4/E17/N129/K512，FP8 F32和FP4 BF16、共享/独立activation、重复高ID、两phase全部结果与独立FP64精确一致，越界仍拒且不写输出。实际selected codes最大物化量FP8 792,576→198,144B，FP4 396,288→24,768B；每block仍有decode/计算临时量，不声称总体峰值或吞吐。[包](cpu-grouped-block-selection.zip) |
| Apple完整FP8 bank受一维carrier限制 | 大GroupedFloat8权重改为U8[bytes/4,4]私有carrier，按4B行slice后显式reshape/view，不经总长度int flatten；只豁免该weight端口的整bank门，保留单轴/单expert及其他算子限制 | 小case旧1D与强制2D的4112个结果逐bit相同。实际GLM E256/N2048/K6144完整3,222,011,904B bank读取expert255，codes偏移3,208,642,560B；两phase各32768输出原预算下maxAbs=0。warm大buffer退回MLX cache后被实际bank复用；未测peak或吞吐，按token复制所选权重的问题另查。[包](apple-full-fp8-carrier.zip) |
| Apple按token复制完整FP8专家 | 沿同一个SIMDgroup kernel加私有INDEXED模板，直接用safe IDs及64位stride寻址原encoded bank，scale按column/128读compact bank；不再Take出每个token所选完整权重或展开scale | T3/S8/E64/N257/K256两phase共12,336输出及普通GLM linear对照12,288输出，新旧24,624个F32逐bit相同；三种非法ID和旧输出寿命不变。managed图47→39节点，权重kernel输入保持E64而非T×S24，Gather/Repeat权重均消失；未测总peak/吞吐，activation广播仍可能物化。[包](apple-indexed-fp8.zip) |
| Apple FP4先整份展开再计算 | 复用同一indexed kernel，以原32项分组直接解码bank中的低/高nibble；移除完整选中权重Take、E4M3转换、F32 decode与全K块dots，保原A128量化、A/W scale次序及BF16最终舍入。大canonical FP4 bank也使用二维私有carrier | E64/N257/K256、T3/S8、A1/AS双phase，24,672个BF16结果与独立FP64→BF16精确oracle、旧路径及强制小2D carrier均逐bit相同；原tiny/非法ID/旧输出寿命及FP8回归通过。Pro 5,284,823,040B仅核InputSpec，未prepare/分配；无峰值或吞吐声明。[包](apple-indexed-fp4.zip) |
| Vulkan不可变专家bank按slot重复驻留 | 仅为ready、直接owned的官方FP8/FP4 Graph常量建立只读borrowed HAL view，保真实native owner；各slot codes及对齐scale共享原buffer，动态及未知view仍复制 | 真实公开Graph两slot、三小case，数值/变更重放/输出保活/最终owner回收及三项非法参数通过，旧dynamic grouped也通过，共2/2。native对齐16、有效门64；人工收紧到256验证scale回退复制，非真实硬件反例。未松原寻址门、未跑完整bank/峰值/吞吐。[包](vulkan-official-bank.zip) |
| 每query不同KV只能拆成多个Sink调用 | 原SinkAttention仅B1；扩大为相同正batch的Q/K/V，支持共享[Q,S]或独立[B,Q,S] mask，保F32/H64或128/KV1/D512。三ggml端统一native mask轴及必要的tile打包，Apple短/长路径保持batch轴 | 四端8几何×两phase通过独立FP64；CPU/CUDA另实跑shared cache→Gather IDs[B,S]→一个Sink→Neg双publish。CPU/CUDA真实小tile、Apple128+1及Vulkan2+2+1强制小tile通过；两强制项不代表产品收益策略会选中。无分页/新融合kernel或吞吐声明。[合同](batched-sink-contract.zip)、[CPU/CUDA](batched-sink-ggml.zip)、[Apple](batched-sink-apple.zip)、[Vulkan](batched-sink-vulkan.zip) |
| Vulkan退化KV-head stride误触降型分支 | contiguous K从[D,1,S,B] permute后，单head的nb2仍是D行跨度；native的batch pitch判断不忽略该退化轴，B>1/Q3时误入缺失的F16 map并assert。仅在合法contiguous且退化stride需规范时same-shape reshape | 旧实际K ne[512,17,1,3]/nb[4,2048,2048,34816]，规范后nb2=nb3=34816；无CONT搬运，F32类型/精度参数均不变，四类组合的8几何及双publish数值通过。[同包](batched-sink-vulkan.zip) |
| CPU有限sink的合法全屏蔽行触发断言 | 原softmax在加入sink前检查普通分母为正；全屏蔽行此时为0，有限sink加入后才为正。将同一断言移到原sink加法之后，保留原计算与无sink检查 | 同一mixed456原生ops TU启用标准assert：旧S1/H64例在sum>0处真实退出，新例两phase全部32768输出为0，原Sink/普通attention共3项通过、预算不变。仅该TU前后各编一次，其余Release闭包复用；canonical FFA仅精确补丁重放与身份核对，未声明完整FFA Debug SDK运行。[包](cpu-sink-denominator-debug.zip) |
| CUDA Sink缺多节点分块region | 原Graph主动排除Sink；其Compute分块实现也使用不适合下游依赖的独立输出leaf。现仅接纳同数学的Sink region，以真实平衡Concat依赖连接各块，按node规划并给cold scalar/dense与safe-ID leaf独立存储，再复用原gallocr | 真实B8/H128/Q3/S2049小tile→Neg双publish通过；不同Q的双attention/两slot/冷常量，以及checked IDs失败保全部输出通过，另强制小tile两项核实际gallocr叶存储。普通SDPA继续独立排名以保FlashInfer/Torch融合路线。本阶段是组件公开Graph，非默认全roster/峰值/吞吐证明。[包](cuda-attention-regions.zip) |
| CPU＋CUDA同一上传依赖按port重复排序 | 同一不可变WeightBatch绑定多个ValueId时分别排入相同pending依赖；冷prepare按原WeightState总序排序，稳定列表仅线性is_sorted检查，提交线性合并同state，保每port引用及原prefix退休 | 持有真实上传gate至全部order完成，实际cudaStreamWaitEvent同batch两port由2→1、不同batch保持2；取消、ID交换、rebind/reset、OOM及原合同通过。统计shim仍调用原API，不是时延/吞吐测量，delegated host wait保留。[包](hybrid-weight-dependencies.zip) |
| Apple冷准备分配整份encoded bank | 官方Grouped FP8/FP4的隔离占位改为单U8零广播，原生reshape识别单实存元素以避免INT_MAX分组后整份复制；真实bind容量与scale CONT不变 | Air公开GLM FP8 3,222,011,904B规格prepare在128MiB native limit内成功，active24/cache956,693/peak956,713B；旧归档同阶段cache3,326,810,389B，未重跑旧大分配。5项canonical、非零/负stride控制及原FP8/FP4 bitwise数值/非法ID/寿命回归通过；未分配真实bank，Pro FP4 scales仍约1.057GB。[包](apple-prepare-placeholder.zip) |
| MLX清单版权字符损坏阻断依赖派生 | 两个native文件的四组整文件edit首行将©损坏为漏，导致原锁定源码匹配失败；只恢复8个before/after字符，原18文件最终native内容哈希不变 | 从原MLX1f8/0.32.2 archive逐项重放全部19文件及before/after SHA通过（含新增common修复），仅同步对应patch tree/NOTICE身份，不重编SDK或改变原数学。[同包](apple-prepare-placeholder.zip) |
| CPU＋Apple/Vulkan重复创建权重alias | 已绑定的不可变WeightBatch每次prepare仍创建native alias metadata；现在复用既有native输入，显式rebind及其他绑定路径仍清除旧alias并重新准备 | Apple、Vulkan完整合同通过；仅禁止WeightSlots metadata allocator后，变更activation的重复prepare/执行仍通过，显式weight rebind按预期OOM、恢复allocator后重试成功。原取消、输出保活和退休语义保留；不把metadata复用称为payload上传优化。Vulkan旧缓存adapter的私有Recipe ABI不匹配曾导致前置CPU段崩溃，只补编该host TU后原完整测试通过。[包](hybrid-weight-alias.zip) |
| 逐行压缩历史缺独立编码和选中行解码 | 新RowCacheEncoding与Encode/GatherDecode，主KV每行584B、index历史每行68B；CPU/CUDA只编码所给新行、只解码选中行，保原StateStore/F2及8B CacheStorage合同 | schema新旧7/7、CPU两项、CUDA组件及默认路由四项通过，双格式完整bytes/选中BF16与独立FP64 oracle一致；非法ID及非有限编码输入不写结果，含signed zero、极值、空输入及奇地址carrier。另有下文真实StateStore→Sink消费。布局是Hyle显式row-inline ABI，并非官方或原生分页布局。[合同](row-cache-contracts.zip)、[CPU](row-cache-cpu.zip)、[CUDA](row-cache-cuda.zip) |
| CUDA普通Checked Gather每次同步读回bounds | 原CCCL以两次Min/Max和16B D2H判界，再同步stream后才Gather；现复用原CCCL索引/字节布局，以同stream全ID校验、Queue device-status及门控Gather写入，去除这段回读/同步和临时workspace | Direct相关8项及现默认Graph原有2项通过；全部15 storage types、I32/I64、轴/非整齐stride/broadcast及raw bits不变，非法末ID保全输出、fresh slot恢复、空与Unchecked合同均过。真实producer gate下旧提交被阻塞，新valid/invalid均先返回pending，释放后分别成功/OutOfRange；仍为原managed runtime、不扩大外部capture支持，原Scan/TopK不改。非吞吐或完整Kimi执行证明。[包](cccl-device-gather.zip) |
| Apple scale视图仍实体化整区 | 原FP8/FP4 wrapper无条件对scale slice做CONT；即使冷codes占位已是1B，U8广播转F32也会整份复制。去掉scale CONT，并仅对单实存byte重复为完整word的情况，用原Scalar Copy构造一个真实4B word后作零stride视图；真实dense绑定沿原owner/offset共享 | 原View control失败、新canonical6/6及普通/transpose/reversed/empty控制通过；Pro FP4 5,284,823,040B规格公开prepare-only的native allocator peak268,509B，在128MiB cap内，无真实bank分配。原FP4 24,672 BF16、FP8 grouped/linear 24,624 F32与历史bytes一致，tiny/非法ID/旧输出寿命保持。20个MLX文件精确重放与lock身份通过；仅相关host TU，无新shader/SDK重编，不是整模型峰值声明。[包](apple-prepare-scale-view.zip) |
| 压缩行历史缺真实页几何与权限句柄 | 新typed RowCacheBatchSchema/LayoutVersion与PagedRowCacheRead，复用原layout owner、F1独立页、F2和初始化前缀，真实U8[P,page_size,584或68]，不伪造attention容量或whole-arena lease | 相关71/71及四个公共头独立编译通过，覆盖两编码、缺/多/外来/子范围页、旧分支、原native use阻回收、空历史及OOM重试。7个受影响host TU fresh；该包仅核页合同与Graph错误域，跨页decoder、pending及Sink的后续证据分阶段列于下文。[包](row-cache-pages.zip) |
| Apple逐行codec接线缺失 | 沿原MLX整数/bitcast/Take和private status补Encode/GatherDecode，编码新增行、先Gather选中压缩行再解码；保raw BF16尾部与signed zero，整数处理极小scale避免FTZ | Air Direct/Graph共4/4，双格式两phase逐bytes/BF16bits对齐共享独立oracle；两slot/重绑/保留旧结果、奇byte origin、非法ID/非有限输入、空/scalar及保留编码通过。只编相关4个host TU，无新SDK/kernel；原INT_MAX承载及普通U8冷bank占位仍在，不是分页reader或全模型证明。[包](apple-row-cache.zip) |
| Vulkan逐行codec接线缺失 | 一个原体系U32 residual shader，先全输入/ID校验再门控编码或仅选中行解码；整数scale/dyadic BF16重建保RNE/子正规数，无ID回读或整历史展开 | Direct及公开Graph共3/3，双格式、两phase/两slot/旧结果、全bytes/BF16bits、非法末ID/非有限源保全输出、奇地址和特殊编码通过。仅相关host TU与9个轻量residual shader重编；新shader仅Shader capability。保设备descriptor/U32寻址/grid限制，尚无分页联合消费/吞吐声明。[包](row-cache-vulkan.zip) |
| 常量BF16→F32中间值仍热转换 | 沿原artifact冷准备不可变rank2 BF16 Cast，供已选ggml多节点region外的消费者只读借用，不改GEMM选择；公开Cast/View链和动态输入仍走原路。复查发现的control→prepared Cast→data consumer丢边一并修正，两处producer表保逻辑生产者 | CPU/CUDA各1项六mode数值/两phase两slot/源释放寿命通过；实际GLM[24,16384]权重cold CAST1、两次hot CAST/COPY/CONT各0。控制边旧例明确失败，修后CPU/CUDA各1项含真实提交通过；最终调度修复后未重跑旧宽测/census。F32 artifact1,572,864B，原BF16786,432B仍保留，不是空间/吞吐声明。[最终包](derived-constant-cast.zip) |
| Apple typed行decoder冷准备整bank占位 | 仅typed Direct RowCacheGatherDecode在原私有RegionPlan标明operation，只有bank port用单U8广播占位；真实绑定检查、普通U8和opaque Graph保持原行为 | Air 153,092,096B bank规格、16MiB native cap下prepare-only峰值126,317B，无真实bank分配；原tiny realbank/Graph4/4重放通过，含变更真实输入、奇地址及旧结果。只fresh context/operations/probe host，无新SDK/native；此改动不解决opaque Graph整bank冷占位。[包](apple-row-cache-cold.zip) |
| 共同MLA Graph不能表达已有Direct窗口 | Paged/RaggedMlaAttention补同一window_left合同与选项校验，Graph provider按实际descriptor/program窗口匹配，移除强制全窗口门；descriptor payload版本升v2，无新native数学 | CPU公开consumer两例通过：BF16 H64/D576 paged window0与F16 H96/D512 ragged window7，每例三次Direct及一次Graph，两个request含Q1/Q3、Q1更新和页交换；独立完整FP64最大误差0/6.076e-5，原预算及Q1计划复用保持。只编wrapper/consumer两host TU，GPU数学资格不扩大。[包](mla-graph-window.zip) |
| Apple TopK专家ID仍重复CPU扫描 | 仅原TopK的I32索引输出、可经保值reshape、同SSA且selected轴长度恰等于consumer专家E时，冷计划证明范围；private native入口再核port2/E。外来ID、values、不同E、hash与Direct保持原检查 | Air counterfactual强制旧scan、计数candidate及无计数canonical均2/2；原CPU loop由12次/39ID降为6次/15ID，减少恰为6次同E调用，无新GPU检查/等待。小E4完整bank实测；历史MoE缩bank的E与完整router不同，不适用且未冒称全GGUF覆盖。原ready/native同步保留，无吞吐声明。[包](apple-topk-index-proof.zip) |
| Apple/Vulkan中间常量仍热宽化 | 两端原captured owner冷求一次rank2 BF16→F32，保原Node/PlanStep及control边界；Apple捕获ready叶，Vulkan在原RHS packing前传播derived View，不改变GEMM选择或精度。公开Cast/View、动态与原BF16消费者保原合同 | 两端新旧同6小控制各1/1，独立FP64/两slot/输入变更及旧输出保持。Apple实际hot AsType1→0，原Permute仍view；Vulkan实际hot Cast1/MatMul CONT1→0/0，TopK自己的CONT仍在。原BF16与派生F32按消费者需要保留，cold peak未知，不声称整模型/吞吐或Metal私有pack消除。[包](native-derived-constant.zip) |
| 压缩历史缺按请求跨页选中行读取 | 该阶段Direct PagedRowCacheGatherInvocation在原QueueSequence中将逻辑ID映射为physical row，再复用原checked codec；零query分组正确跳过，越请求长度置无效ID，保准确页/代际/初始化前缀，无whole-arena lease | 默认CPU1项/CUDA2项通过，双格式/两phase/换页、K0空footprint、逻辑越界但物理合法ID不写输出。CUDA gate下先返回pending，drop caller owner后backing保活，used页阻复用而unused页可用；mapping已接受后decoder拒绝仍返回实际prefix并保权限。metadata冷同步write显式计费；该包为ready Direct及I32物理行域，后续Graph、pending和其他后端证据另列，不能据本包代签。[包](row-cache-paged-reader.zip) |
| CPU dense FP8按token重复解码权重块 | 移除共享矩阵的token轴expand，保留单份encoded/scale，沿原ATen matmul及scale广播；原K128累加和输出精度不变 | canonical6/6；新增T3/N129/K256覆盖encoded、normal与power2动态激活，两phase/两slot与独立FP64完整结果精确一致。同一例实际24个block观察的F32 decoded payload从198,144降为66,048B/block，encoded从49,536降为16,512B。仅组件native context实跑，默认route另核源码，不是整过程峰值/吞吐。[包](cpu-dense-fp8-block.zip) |
| Graph生成的IDs不能直接消费typed压缩页 | 新薄PagedRowCacheGather宏展开原Map→checked codec，沿原LeasedInvocation保准确页权限及元数据；冷核同一source Graph、原CPU/CUDA普通provider、唯一容量reader，拒绝私有容量发布/alias/复制，无新executor或whole-arena lease | CPU6/6含原5项分页host回归、CUDA新项1/1；TopK→跨页FP8解码→Cast/View→单Sink→Neg，四输出、两phase换scores/query/cache/pages，独立FP64预算不变。FP4 K0空footprint、额外reader/容量发布、非空选择配空历史控制通过。ready frame限定，cold metadata同步write；未声称pending、混合route或整模型。[包](row-cache-paged-graph.zip) |
| Vulkan dense FP8按query展开当前权重块 | 原IREE三dense导出改为A[R,128]及单W[N,128]，沿同pin的原linalg.matmul转置索引计算；保持K128顺序、activation/weight scale次序及最终BF16。generator、MLIR、实际VMFB、manifest/embedding与lock均更新 | 原/新各4/4，含T3/N129/K256 F32/BF16×normal/power、两phase/两slot独立FP64精确结果及原encoded/grouped回归。实际compiled stream allocation的W块从198,144降为66,048B，含A为199,680→67,584B；原生VkDeviceMemory peak均134,288,448B，128MiB池掩盖物理峰值差，未声称峰值/吞吐胜出。25个math schedule全部保IEEE32 mode；后续grouped制品另记。[包](iree-dense-shared-block.zip) |
| Graph不能消费pending压缩行页 | 新typed PagedRowCachePendingRead复用原pending页身份/覆盖合同，原PendingInvocation在准确decoder lane等待CopyBatchUpdate后才准入ordered页读取；empty footprint仍沿ready frame，无新executor/whole-arena lease | CPU7/7、CUDA2/2，含原ready TopK→Sink及5项host回归。两编码×整2行新页/1行新尾页四episode，真实CUDA producer gate下submit先返pending，放行后BF16/CastF32/Neg全部raw bits一致。缺末byte的新增行拒收且保Update，原writer取回后补齐重试；输出副本阻控制回收。新增共享路径的两处页几何误取已改真实geometry。旧CUDA缓存fast-math导致的Neg FTZ按现有precise-unary设置仅补编1CU排除，不作为新产品缺陷。[包](row-cache-pending-graph.zip) |
| Apple/Vulkan缺typed压缩页Direct读取 | 两native namespace补同名薄reader，在一个原Program内Map→原checked codec，沿原OwnedResult/页Use保活；不伪装common Context。Apple非法ID的求值替代行只取准确授权footprint首行，避免误读未授权page0；普通codec保持原行为 | Air5/5、Vulkan4/4含原codec回归；两格式/两phase、zero-query/zero-KV段、重复高页、K0、逻辑非法ID及布局错配全部按独立oracle核BF16 bits。page0故意未初始化/无权限；释放caller reader/frame/arena/IDs后原native结果仍正确。每新version整metadata F2冷copy+wait、每次binding/result仍有费用，无Graph/pending/capture或零分配声明。[包](row-cache-paged-native.zip) |
| Vulkan官方完整bank受signed byte寻址限制 | 仅IREE grouped codes改私有32位word视图和取码，公共opaque格式/bytes/scale偏移不变，无重排；保持原workspace门，独立校验word数与真实descriptor字节上限。外层Graph只为精确格式和grouped weight port0放开逻辑I32门，普通producer/大U8不扩大 | 最终小例旧2/2、新2/2；GLM E256/N2048/K6144实际3,222,011,904B完整bank新1/1，两slot/两phase独立原oracle通过，expert255 codes偏移3,208,642,560B、scale偏移3,221,225,472B均实际消费。两slot借同VkBuffer，bad256拒绝、旧输出及owner回收保持。实际FP4只小例，未声称完整FP4 bank、吞吐或峰值；离线制品及全部IEEE源证同包。[包](vulkan-official-word-bank.zip) |
| CUDA紧凑MLA缺ragged承载 | 沿原MLA planner与24个已有kernel实例，以packed KV indptr直接定位单份512/576行；私有linear标记允许unit-row且16-bit时省去页表，普通paged仍拒绝缺失页表。V继续只读别名CKV前512项，无虚构页表或K/V展开 | 新1/1覆盖F16/BF16×H64/128×D512/576、两请求Q1/Q3及Q1/Q1、Direct/Graph共32次完整独立FP64核对；非零第二请求起点、split workspace不足、双slot旧输出保持通过。最大绝对误差F16 5.48e-5、BF16 4.25e-4；原paged/capture/换页及敏感F32 split回归通过。仅新编1个已有实例CU和相关host TU，不增加窗口、mask、sink或编码cache资格。[包](cuda-ragged-mla.zip) |
| Apple recurrent热调用无条件分配两个容器 | 将最多8个输入的CONT owner和最多9个BufferView改为固定栈数组；只有实际CONT时保留原async_eval所需vector。保留MLX等待、跨runtime就绪、checked状态及逃逸输出owner | Air旧/新计数版及无hook当前产品均5/5；15次实际调用中两个指定容器的分配共30→0。GDN T1/T17、KDA、strided CONT、取消/放弃及CONT接受后checked ID失败退休覆盖；未称整个run零分配、吞吐提升或可删除同步。[包](apple-recurrent-metadata.zip) |
| 压缩索引历史缺直接评分入口 | 新RowCacheIndexerScores显式接BF16 Q/权重、Hyle FP4行内bank与逐query半开范围，保dot/product/headsum的BF16边界。CPU沿原ATen以至多256行BF16 tile评分；keytile外层共享已解码行，只读所有合法range的并集，并跳过空gap，不解码整段历史 | 最终默认CPU4/4，含T3/L513两phase两slot独立oracle、三类非法末range全输出保护、T0/L0及T2/L8193两端各1行。v2实测decoder旧1023→新513次；C10最大请求65,536B，私有F32输出6,156B，无完整decoded bank请求；分配请求27→32，总bytes同470,662，真实OOM保护及fresh slot重试通过。v3仅补空gap跳跃及最终canonical，未重跑census；完整score初始化仍O(T*L)，未称时延/RSS收益。该包为CPU contiguous bank；其他后端与typed分页后续证据另列，不等于完整sparse模型链。[当前包](packed-indexer-cpu.zip)、[v2计数包](packed-indexer-cpu-v2.zip) |
| CUDA缺packed indexer普通承载 | 新四port操作沿原SharedQueue复合256-key BF16解码tile、cuBLASLt F32累加/BF16输出及已有ReLU/乘权/归约；所有range先在设备检查，原checked终态及accepted-prefix寿命保留，无新executor/逐tile主机等待/整历史解码 | 默认Direct/Graph新3项及原codec2项共5/5；T3/L513、256+256+1、严格BF16阶段oracle、两slot/两phase/同slot重放、变更输入、非法末range全输出不变、T0/L0与全空区间通过。实际caller workspace165,632B/slot，含64KiB keys与96KiB dots，Lt workspace0；vendor内部分配未知，无额外私有T*L输出。仅SM89实际验证，无独立capture/吞吐声明；当前GEMM仍遍历全部L的tile，不能声称计算仅随可见range增长。[包](cuda-row-cache-indexer.zip) |
| Apple/Vulkan缺packed indexer普通承载 | 四port接原native Direct/Graph与checked发布；完整range校验先于bank读取。Vulkan按可见query/key对直接评分；Apple改用共享256-key BF16 tile和原MLX matmul，保留显式BF16乘权、逐head F32累加及最终BF16边界 | Apple新3＋原codec4共7/7，Vulkan新3＋原codec3共6/6，含两phase/两slot/重放、变化origin、非法末range、旧结果、T0/L0及NaN/Inf。Apple最终矩阵版同7/7；固定T3/L513子域同进程9对AB/BA均更快，配对ratio中位数0.84786，不能外推整模型。跨进程漂移及全部异常值保留；resident dense不含预解码成本，不能据此判输赢。Apple实测active peak增量342,695B，保分块及拼接两份score payload，不称仅768B总空间。[功能包](row-cache-indexer-native.zip)、[Apple矩阵包](apple-row-indexer-matmul.zip)、[公平对照](apple-row-indexer-paired.zip) |
| CPU按token重复解码同一专家块 | validated IDs按expert分组，再按出现次数分桶，以原ATen BMM共享一次解码；保持K块、scale次序及原输出cast。共享activation先解码当前块再选row；无重复专家保持原batched路径，不按最大次数padding | native 6/6及普通default CPU route 2/2，T1/T3、FP8 F32/FP4 BF16、A1/A=S、尾N129、重复/高ID、变化输入、非法ID全输出保护和失败/并发原回归通过。精确产品函数T128/S4/E17/N129/K512同工9对AB/BA：A1 FP8中位26.25→2.56ms，FP4 122.74→15.62ms；C10最大请求33,816,576→990,720B和8,454,144→264,192B，更多小请求、累计bytes显著减少。T1无重复保持原C10请求，小样本时延有噪声；非整模型/RSS或vendor heap测量，Linux/macOS未重跑。[包](cpu-grouped-expert-reuse.zip) |
| CPU分页评分及首次prefill padding未闭环 | 新typed五port评分按request映射实际FP4行页，输出请求内score；每request最多256行tile共享解码并跳空gap。新独立padded decoder仅将-1视作无bank读取的BF16正零，宏产生0/-Inf mask，非法column/range仍失败；原checked合同不变 | 最终5/5，真实评分→TopK visible0/1<K3→FP8 sparse与raw未来窗口→B3/H64/D512 Sink→Neg，检查全部中间/输出；空历史零ReadLease footprint、C257跨tile、两slot不同Q分组、旧输出、非法输入sentinel和private/alias发布拒绝通过。保真实页权限，不造wholearena lease；未测吞吐/总peak，不含完整模型或pending评分。mask可能是accepted-prefix写，不承诺失败Graph原子回滚；CPU为首条闭环，其他后端资格独立。[包](paged-indexer-cpu.zip) |
| CUDA缺安全的padding行消费 | 独立padded codec沿原decode kernel默认false模板扩展，不改变旧Program/checked语义；private Map为-1或不可见合法列生成padding和mask，坏metadata/range/列生成-2使checked decoder失败 | 最终7/7（新5＋原codec2），默认Direct/Graph两format、odd bank、两phase/两slot、旧结果、非法末ID全decoded保护、L0全padding/K0以及真实typed Graph visible0/1<K通过；空history执行时同时持全部4个真实page writer，证明无页面读取权限/载荷访问，不等于零VRAM。无D2H IDs/逐tile hostwait，未测吞吐/peak；本包不含typed CUDA评分。失败mask仍按accepted-prefix不可消费。[包](cuda-row-cache-padded.zip) |
| 新row-cache接线破坏组件配置/头交付 | 三份public头未登记而误归compute；中性Graph为检查ID引用可选provider工厂头，graph_batch新row节点又缺直接compute_ops依赖。登记准确header owner、仅加私有schema边；两既有ProviderId移至同一中性来源，工厂alias与原权限检查数值不变 | 真实graph_batch最小factor configure原先直接失败；修后0.1s通过，三份header owner/所属安装列表均核对。仅四个core头的C++ TU在无可选工厂头下编译通过；没有新增CUDA/native factor依赖、vtable变化或SDK/全库重编。源码快照含独立施工中的cold-span代码，本包不代签其数学/完整状态。[包](row-cache-header-ownership.zip) |
| CUDA typed分页评分与请求跨度接线 | 同一原SharedQueue按真实request的Q span准备Lt；每request共享至多256行BF16 keytile，不按request重复全T计算。layout变化只在idle冷配置，失败使旧batch不可提交；准确页权限及原BF16阶段保持 | 默认CUDA分页4/4、原contiguous Direct/Graph2/2、共享CPU5/5通过，含首次prefill、空历史、C257跨tile、两slot与同slot跨度重配、OOM重试和非法range保护。C4/T3实际报告caller workspace33,557,504B，含32MiB Lt上限；capture=false，未测peak/吞吐。非空request仍逐完整declared history tile做GEMM，不声称稀疏计算复杂度已解决。[结果](../../../../.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer/summary.json) |
| IREE grouped逐slot解码权重临时量 | 将原FP8/FP4 word取码及decode嵌入同一原生F32 reduction，移除强制物化的W[R,N,G]及后继batchmatmul，保持K块、scale和BF16次序；实际generator/MLIR/VMFB/embedding/lock链均更新 | 当前完整制品Direct4/4、Graph2/2通过。独立单函数固定T128/S4/N1024/K128点的9对AB/BA中，两格式均较快，实际各Context peak为FP8 408,094,976→141,494,528B、FP4 272,354,336→139,054,112B；这些不是完整制品重测或模型收益。仍按slot读取/解码原bank，不等于重复expert共享解码，原容量门保持。[结果](../../../../.scratch/inference-foundation-review-2026-10-18/iree-grouped-inline-product/summary.json) |
| Apple/Vulkan padded首次prefill消费 | 两端独立padded codec仅-1返回BF16正零且不读取bank；ready页Map产生准确physical IDs及0/-Inf mask，再由原owner/页权限保活。原strict reader不放宽 | Apple8/8、Vulkan7/7通过，两格式、odd origin、两phase/slot、非法ID、空bank及实际持全部page writer的空history控制；选中输出和mask接普通native Graph Sink→Neg有完整oracle。未接native五port分页评分、page Graph/pending授权；零ReadLease footprint不等于零arena分配。[结果](../../../../.scratch/inference-foundation-review-2026-10-18/native-row-cache-padded/summary.json) |
| 资源投影依赖具体op/Provider判断 | 现由exact selected prepared的object-local能力描述真实physical input、空footprint及可选cold configure；typed模块证明逻辑访问链，core只核计划/实例/端口/alias/权限/退休，无新增替代白名单 | CUDA4/4、CPU6/6通过；同provider的checked/padded实现可声明能力，unchecked sibling仍拒绝。原pending、失效及旧结果门保持，无热submit新hook或数学变化；仅迁移ordinary singleton子域，不代签全部region或其他后端。[结果](../../../../.scratch/inference-architecture-refactor-2026-10-18/prepared-access/summary.json) |
| Apple/Vulkan承载分析重复名单 | Direct/Graph共用真实handler与native validator，删除重复custom/GGUF/multi-output前置名单；仅未解析custom可走显式cold expert resolver，不把它留到回放 | Vulkan9/9、Apple11/11通过，含原融合、callback冷调用次数、native/MLX状态组合、padded及旧输出owner。保持真实执行岛和结果表示，不新增kernel/SDK；此步未完成共同generated-output合同或所有公共入口迁移。[结果](../../../../.scratch/compute-execution-refactor-2026-10-18/carrier-shared-summary.json) |
| CPU＋Apple/Vulkan冷图生成与Plan重复 | 两端冷编译和Plan提取共用现有数据/控制依赖、常量、资源及物理图逻辑，平台adapter保真实native上传、prepare和输出规则 | CPU＋Vulkan原contracts及CPU＋Apple原contracts均通过，覆盖拒绝、OOM、旧输出、取消、abandon和accepted prefix；Apple保原MLX owner与contiguous输出要求。尚未将全部执行槽/进度合为共同实现，GPU-only旧joint入口仍要求CPU端点，不能称全量架构完成。[Vulkan日志](../../../../.scratch/architecture-refactor-2026-10-18/native-plan/06-contracts-run.stdout.log)、[Apple结果](../../../../.scratch/compute-execution-refactor-2026-10-18/joint-apple/summary.json) |
| 无覆盖节点触发路由前缀组合爆炸 | 按实际leaf/region全部成员建立incidence，增量维护兼容候选support，select/undo及单调reject剪去不可能覆盖的前缀；不扩大预算、不拆模型或增加名单 | 假provider预算/拒绝/重选/coverage等15/15通过。早期Qwen T23/1932节点图从耗尽65,536状态变为直接定位node300四port SDPA无承载；后续消费者以真实typed RaggedAttention执行完整三phase，见下文。普通F32 additive-mask SDPA候选洞仍未补齐。[回归](../../../../.scratch/architecture-refactor-2026-10-18/route-search/tests/summary.json)、[早期模型诊断](../../../../.scratch/architecture-refactor-2026-10-18/route-search/08-model-diagnostic.stderr.log) |

CUDA MLA首包是早期partial16阶段，工作区与小用例结果仅描述当时源码；最终F32 partial、
512/576四组合及跨后端数学结果以上表最终包为准；active workspace另见后续包。
FlashInfer lock/source/NOTICE已与最终数学及ragged补丁同步。
共享内存fragment的F32存储映射另做64×512坐标双射核对，非GPU数值证据；真正精度证据是敏感split对照。

后续native能力已在原Graph槽内冷准备：默认CUDA的16个组合通过Direct及两个共享metadata的attention节点完整oracle，
第二节点metadata staging为0，旧结果仍阻止重用；这一步不含row-cache/pending迁移或性能结论。[包与日志](../../../../.scratch/compute-execution-refactor-2026-10-18/graph-batch/source-results.zip)
原exact Context能力与实际workspace query/grow-only路径另通过CPU九项控制、canonical CUDA gated MLA及两个mock测试；
没有在submit新增scratch分配。[结果](../../../../.scratch/compute-execution-refactor-2026-10-18/batch-retained-workspace/summary.json)、[包](../../../../.scratch/compute-execution-refactor-2026-10-18/batch-retained-workspace/source-results.zip)
中性core adapter初始17项通过，修正同provider多能力共享原proposal上限后仅重跑三项、3/3通过；
保留原Context/实例及compile-only adapter寿命，不代表旧包装已经删除。[原始日志](../../../../.scratch/architecture-refactor-2026-10-18/region-adapter/tests/02-focused-tests.stdout.log)、[上限修正日志](../../../../.scratch/architecture-refactor-2026-10-18/region-adapter/tests/04-capability-tests.stdout.log)
页投影另已改为exact prepared artifact/物理端口证明，移除该处ProviderID判断；原CPU ready/pending、
CUDA低维pending及错误artifact/port拒绝通过，旧coordinator尚未删除。[迁移证据](../../../../.scratch/compute-execution-refactor-2026-10-18/projected-readers/source-results.zip)
实际workspace暴露并修复MLA零字节分配：no-split不构造float allocator，空指针不做偏移；原16B上限与
报告float=0断言保持，F16/BF16 Graph页消费通过；BF16真split的4,202,496B路径也通过。
只重编一个native CU。[零空间日志](../../../../.scratch/compute-execution-refactor-2026-10-18/mla-zero-workspace/02-graph-no-split-test.stdout.log)、[split日志](../../../../.scratch/compute-execution-refactor-2026-10-18/mla-zero-workspace/05-split-test.stdout.log)

GatherElements另有[公共schema及模型接线包](gather-elements-contract.zip)：两项schema测试通过；
Linux g++14的公共头、schema测试TU和ATen provider TU仅做syntax检查，三项通过，未声称Linux运行。
[低精度边界包](gather-elements-finite-edge.zip)中Apple、Vulkan各1/1通过，F16/BF16
子正规数、±0、最小正规数及±Inf重排后raw bits保持，不扩大为NaN payload承诺。

CUDA单cache的[Graph pending消费](mla-pending-graph.zip)另补F16/BF16实测：
同页先写负旧值，gate持有的producer再复制正新值；submit在gate释放前返回，释放后两dtype全32768输出
的FP64误差均为0。错layout/port拒绝、真实LeasedGraphOutput副本阻复用、独立caller-output lease跨reset
保持原值、页writer回收和producer guards归零均通过。此项未发现新的产品缺陷；只补消费者与条件测试目标，
证明组件Context的command replay，不扩大为全roster或新capture证明。

BF16专家cold-pack的空间成本明确计入资源报告：F32 packed payload是原BF16的2倍，原canonical常量仍保留，
不能在adapter内私自释放可能被其他consumer使用的源。旧实现每个invocation有一份F32 cast scratch，新实现由多个
invocation共享一份；单invocation没有降低总权重payload，多个invocation才减少重复驻留。此改动首先消除重复转换。

新增prepared常量使私有PlanState布局变化，直接消费者共6个TU：Graph内的executable、constant_artifact、
leased_invocation、lease_submission、region_access，以及CPU＋CUDA的invocation。上述普通两端测试fresh
了前5个；[混合消费者补证](hybrid-derived-control.zip)又fresh了第6个，并匹配当前前5个对象。
实际CPU TopK→control→CUDA prepared BF16 Cast→D2H→CPU TopK，以及同region的变更输入Neg，
两slot各两phase完整精确结果和report的传递依赖均通过，原混合合同也通过。旧调度core亦通过此跨存储例，
因此此项是新增调用链覆盖，不是原丢边的隔离复现或新增修复计数。后续仍不能混用旧私有ABI对象。

## 当前线索

以下未完范围由新架构继续承接，区分缺实现/接线、实际域限制及缺整链证据；已有局部成功不替代其余模型、制品或路线。
确定缺接线仍包括默认CUDA普通四port SDPA的F32 additive mask；Qwen改用语义匹配的typed RaggedAttention不等于补齐任意显式mask承载。
GPU三个IQ1 narrow GET_ROWS、Vulkan native BF16 attention等仍按真实实现边界保留。
其余有成熟组合的需求先检查真实默认路由和连续消费，不以片段尚未实跑为由新造API，也不把设备硬限制当作可删白名单。

Qwen3.5-2B官方BF16完整24层CUDA消费者现已执行prefill Q23/KV23→continuation Q4/KV27→decode Q1/KV28，
每phase均为1938节点、998 step；next token 20→248046→198与独立reference一致。
150份导出张量全finite、未使用KV尾部全0；logits相对L2依次为1.874%/1.549%/2.067%，hidden为1.990%/1.323%/2.460%。
尚无既定精度接受容差，不能称整模型数值PASS。首层已定位到相同输入的post-attention RMSNorm一个BF16值差1 ULP；
独立CPU F64数学参考及F64→F32→BF16控制均与Hyle全部47,104个输出逐位相同，Torch仅该点不同，
不应为贴合Torch修改这个正确舍入结果。此定位不证明24层全部偏差只有一个来源，模型域审查仍未完成。
[首层高精度对照](../../../../.scratch/compute-execution-refactor-2026-10-18/qwen35-layer0-probe/ffn-slice/f64-reference.json)
现有trace仅一次三phase旅程，不是性能benchmark。[执行日志](../../../../.scratch/compute-execution-refactor-2026-10-18/qwen35-ragged/05-full-text.stderr.log)、[完整比较](../../../../.scratch/compute-execution-refactor-2026-10-18/qwen35-ragged/comparison.json)

| 事项 | 当前事实 | 本轮工作 |
|---|---|---|
| 紧凑MLA各route覆盖 | CPU paged/ragged、CUDA paged/ragged与Apple/Vulkan paged已有上表定向实测；CUDA单cache pending追加已验证。共同Graph window描述与CPU实际窗口消费现已补通 | GPU窗口、Apple/Vulkan单cache ragged及其他未验证域仍按实际native资格，不因共同schema可表达就伪装支持 |
| F32及编码高维KV | 共同BatchSchema的plain Q/output/cache以F16/BF16为域。DeepSeek官方源码实际存BF16 QAT，并未规定packed cache wire布局；四后端逐行codec及contiguous packed indexer、CPU/CUDA typed分页评分和状态追加→选中KV→Sink均已有上表定向实测 | 继续核分页/稀疏sink联合承载与模型数值需求。CUDA/Apple contiguous及CUDA paged scorer仍逐完整history tile做GEMM，只跳无效bank读；CPU可跳空gap。旧CacheStorage固定scale与新row-inline布局独立，不能按字节数假定原生page-footer兼容 |
| 稀疏attention联合链 | CPU/CUDA typed分页评分→TopK→padded跨页Gather→Sink的ready首次prefill已有实测；CPU/CUDA Graph pending行读取另有证据。通用paged batch仍没有逐query显式mask/sink端口 | pending评分仍需单独验证。Apple/Vulkan现有native padded ready Direct及选中输出接普通Graph，但无native五port分页评分或page Graph/pending授权；原生稀疏sink亦未据此补齐。迁移时保真实页权限，禁止whole-arena假lease |
| 首次prefill的稀疏padding消费 | 四端padded codec及ready选中行→Sink消费均有上述定向证据；CPU/CUDA另有typed评分联合链。旧prefix消费者从visible512/base2048开始，不能独自证明空历史全过程 | 仍需完整prefix从空状态连续推进、原始QAT→重编码等价性及其余后端整链；现例从post-QAT/encoded bank出发，不是完整模型。原官方参考同[评分包](packed-indexer-cpu.zip)保留 |
| 常量优化的路由覆盖 | CPU/CUDA上述packing适用于已选ggml region，CUDA另接不可变BF16专家单节点；普通单节点dense可能选oneDNN/cuBLAS。GLM mHC中间常量冷准备现四后端均有上表定向证据；ATen/IREE dense共享权重块重复解码已修，CUDA SGLang/DeepSeek沿原encoded weight pointer | 沿实际默认路由继续核热成本。保F32 activation精度、公开中间及其他消费者，不泛称所有常量表达式均已折叠 |
| MoE重复专家的原生成本 | CPU重复专家块共享解码与Vulkan IREE逐slot大权重临时量均已有上表实际修复/证据；CUDA原encoded pointer、Apple indexed读取及IREE inline reduction的成本不能直接类比 | IREE仍按slot取码/解码，并未共享重复expert结果。现固定点收益不代签所有T/S或decode；继续沿模型实际route核必要工作，不从逻辑tensor或不同算法的局部计数直接认定退化 |
| Apple区域同步 | 原生Metal recurrent桥需要就绪输入，MLX array wait还承担事件/错误状态退休，attention分块等待约束峰值内存；recurrent两个无条件容器分配已按上表移除 | 保留真实等待与逃逸输出寿命，不能用局部容器计数推导整个run零分配或吞吐收益；其余热成本继续审查 |
| 热调用资源成本 | Apple/Vulkan已共用各自Direct/Graph承载分析，CPU＋Apple/Vulkan已收拢冷compiler/Plan，selected-prepared投影与cold layout也有局部迁移证据 | 共同generated-output、统一执行槽/进度、普通有效长度与layout接入及旧入口删除仍须完成；随后继续核实际冷准备、每步分配/转换/上传/同步，不能以结构消重代替功能或性能结果 |
| 混合路线的不可变权重准备 | CPU＋CUDA重复上传依赖、CPU＋Apple/Vulkan未变WeightBatch的alias metadata重复分配已修 | 后续仍核跨runtime顺序及寿命；原delegated host wait保留。reset后旧内部binding可能保留alias至后续bind/prepare/submit或析构，不声明reset立即释放全部旧WeightSlots |
| Apple冷准备与真实bank资源 | 官方codes/scale与typed row decoder的冷占位已按上表窄修，规格prepare-only已在小native cap下实跑；普通U8/opaque Graph不因此获得相同占位优化 | 该结果不包含真实bank、计算临时量或整模型峰值。继续按实际绑定、activation广播、checked状态及输出寿命核资源成本，不将冷占位改动外推到全部GPU驻留 |
| GPU路由ID接专家/embedding | CUDA ggml整ID回读及普通CCCL Checked Gather的16B bounds回读/stream同步已修；Apple同E TopK索引已可静态免扫，非Q4K Metal的外来/Direct IDs等仍CPU扫共享buffer，不能把它说成实测D2H copy | 区分整数组回读、共享memory CPU walk、终态少量观察及已有MLX/native ready等待。少量ID改为新增GPU归约/等待可能更贵，不据O(ID)本身断言性能输项，不删除实际边界检查 |
| 完整expert bank容量 | CUDA/Apple官方FP8、CPU/CUDA GGUF的上述过度门已修；本Qwen IQ4_XS bank的物理4,563,402,752字节超Vulkan单descriptor的uint32范围 | 区分真实设备限制和carrier设计；不能以resident11代签完整模型常驻；更大packed gate/up及其他bank按实际单buffer限制判断 |
| Vulkan官方bank寻址与副本 | 原IREE grouped signed byte寻址门已改word并更新实际VMFB/host/Graph接线，GLM完整3.22GB FP8有上表实测；直接owned常量共享已修，动态及lease/WeightBatch等view仍按slot分配和复制 | 原真实descriptor、word数和workspace限制保留，不能外推超过设备单buffer的bank。精确离线compiler已恢复到项目内工具缓存，[恢复记录](iree-compiler-recovery.zip)。其余输入的借用需明确owner/资源证明，不猜opaque根 |

缺整链证据的继承范围仍是8模型/22制品的实际embedding/LM-head、dense/batched、MoE、norm/RoPE/GDN/KDA/conv调用，
以及prefill→续算→decode→接受前缀后继续的状态反馈。普通默认Direct/Graph、CPU＋GPU旅程、动态长度/请求增删与布局变化、
两slot重绑、跨runtime权重/状态驻留和失败/取消/关闭退休都按各自现有证据补查；不要求无意义的format×op笛卡尔积，
也不以Qwen一个消费者代替其他模型、系统或后端的有关检查。完整bank只核过的容量与物理限制继续逐项保留。

DeepSeek的压缩/索引/接受前缀已有一条新的[公开CPU消费](deepseek-sparse-prefix.zip)：
H64/D512、index64×128、Top512/516、ratio4，8 token跨两个完成点，出现3种TopK集合，
每query的未来slot均不可见。接受k=0..8后再继续1 token，11项资源与cursor、IDs、Sink输出
与从同base只逐token执行接受前缀的独立分支完全相同；继续提交StateStore后的资源与metadata
逐字节相同，base未变。给定实际选中前驱的独立FP64 Sink最大误差6.1035e-5，沿用原BF16链预算。
另补[ratio128分支](deepseek-sparse-prefix-ratio128.zip)：此分支没有Indexer/TopK，采用64行半窗口，
从absolute position2302、当前半窗口62行、17个已发布压缩项开始，8 token在第2个token完成128边界，
可见项17→18，最终半窗口6行。APE、窗口滚动、raw更新和仅在完成点发布cache均有独立核对；
接受k=0..8后继续1 token，6项状态与metadata逐字节一致，配对Sink maxAbs=0，独立FP64 Sink
最大误差1.2207e-4，沿用原BF16链预算。参数化后的同一程序也重跑原ratio4分支，通过原几何及误差要求。
两分支均未发现新的产品缺陷。这证明投影后F32物理状态＋原显式低精度数值边界的密集组合可用；
未证明分页权限桥、packed物理历史、其他后端整链或原生融合，不能据此删掉上表稀疏attention线索。

新的[逐行压缩状态消费](row-cache-state.zip)在CPU与CUDA使用同一源码：base可见3行，
接受0时取消草稿；接受1或2时只编码新行，对固定5行chunk做COW，并用原F2精确追加新字节，
取回原整writer后才publish/complete，与可见长度4/5共同发布。主KV chunk为2,920B、index chunk为340B，
没有按整个历史长度做COW；旧base的bytes与metadata、未改prefix/suffix均保持，失败producer不发布。
主KV再经公开Graph的选中BF16解码→CastF32→View→单Sink（B2/H64/Q1/S3）→Neg双publish，
CPU最大FP64误差1.581e-7、CUDA2.176e-7，沿用原2e-5绝对＋2e-5相对预算。
可见性由该消费者显式保证IDs小于metadata长度；codec只检查物理容量，不隐式读取状态metadata。
这不是TopK/indexer整链、原生分页直读或完整MTP引擎证明；不得把固定chunk例子当成可无限增长的单bank方案。

另补[GLM KDA公开接受前缀消费](kda-prefix.zip)：投影后B1/H64/D128、F32 state、K4 conv，
3-token验证产生K3快照，接受k=0..3后各继续1 token。默认CPU/CUDA context中Direct与逐算子Graph
各8分支通过；实际conv→SiLU→Q/K L2→per-channel KDA反馈设备结果，完整state/scores/history
与同base逐token独立分支符合原3e-6预算。状态、history、cursor共同发布，旧base不变，取消不发布。
本项未发现新产品缺陷，不计新增修复；没有完整投影/模型、整链融合、原生故障注入或Apple/Vulkan新旅程证据。

完整模型加载、tokenizer、请求/生成/接受政策由引擎负责；本轮审查其所需的可复用底座。
整模型执行与跨平台交付未运行的部分保持明确，不以局部用例代签。

归档只含源码、脚本、命令、结果与缓存身份，不复制SDK、object或可执行文件。
本批归档后经根目录test.ps1按路径、字节数和SHA精确清理Windows 23个、Mac 10个实验binary，
共552,637,943B；源码、日志、数据、maps、product/test objects与SDK均保留。[清理记录](probe-cleanup-row-followup.zip)
本轮另按同一test.ps1精确清理6个已归档stage的36个实验exe/lib/exp，共547,277,745B；
所有object、原SDK及恢复的精确IREE compiler仍保留。[本轮清理](probe-cleanup-pending-followup.zip)
随后按同一根目录test.ps1精确清理3个已归档stage的14个实验exe/lib/exp，共568,680,588B；
全部object、maps、源码、日志、数据和SDK保留。[清理记录](probe-cleanup-current.zip)
上述评分、padding与CPU专家复用阶段归档后，又通过根目录`test.ps1`逐项核对并删除38个
exe/exp/lib，共436,566,645B；40个复用object、全部源码/日志/数据和SDK保留，当时尚在施工的CUDA分页评分目录未清理。
[清理记录](probe-cleanup-review.zip)
pending行测试发现的旧CUDA fast-math缓存差异及按现有canonical flags替换单个unary对象另留
[缓存身份记录](cuda-precise-unary-cache.zip)，没有修改Neg产品数学或放宽逐bit检查。

首扫还区分了两类容易误报的情况：混合route的allocate_host/allocate_boundary有已分配即返回的保护，
函数出现在prepare中不代表每步重复分配；CUDA best_of的精确环境条件选择特定测量域的优先级decorator，
域外仍有普通provider，不同于本轮已修的FP8/CCCL底层能力误拒。
