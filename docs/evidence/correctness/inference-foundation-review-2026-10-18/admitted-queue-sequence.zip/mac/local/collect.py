from pathlib import Path
import io
import json
import tarfile
import stage

code = '''from pathlib import Path
import hashlib,io,json,sys,tarfile
r=Path('''+repr(stage.REMOTE)+''')
def identity(p):
 data=p.read_bytes()
 return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
commands=json.loads((r/'commands.json').read_text())
if (r/'test-results.json').exists():
 tests=json.loads((r/'test-results.json').read_text())
else:
 tests={}
if commands[-1]['tag']=='finite-consumer' and commands[-1]['exit']==0:
 assert tests['tests']==24 and tests['failures']==0 and tests['errors']==0,tests
 plan=dict(root=str(r),files=[identity(r/name) for name in (
  'native-tests','native-tests.map','finite-consumer','finite-consumer.map')],
  retain=[identity(p) for p in sorted(r.glob('*.o'))])
 (r/'cleanup-mac.json').write_text(json.dumps(plan,indent=2)+'\\n')
source_rows=json.loads((r/'staged-sources.json').read_text())
source_data=io.BytesIO()
with tarfile.open(fileobj=source_data,mode='w:gz') as a:
 for row in source_rows:
  p=r/row['path']
  assert identity(p)['sha256']==row['sha256'],row['path']
  a.add(p,arcname=row['path'])
(r/'final-sources.tar.gz').write_bytes(source_data.getvalue())
out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w:gz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and not p.is_symlink() and p.suffix in {'.json','.log','.txt','.py'}:
   a.add(p,arcname=p.name)
 a.add(r/'final-sources.tar.gz',arcname='final-sources.tar.gz')
 for p in sorted((r/'before-delta').rglob('*')) if (r/'before-delta').exists() else []:
  if p.is_file(): a.add(p,arcname=str(p.relative_to(r)))
sys.stdout.buffer.write(out.getvalue())
'''
data = stage.ssh(code)
(stage.OUT/'mac-results.tar.gz').write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as a:
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in a.getmembers())
    a.extractall(stage.OUT/'results',filter='data')
commands = json.loads((stage.OUT/'results/commands.json').read_text())
print(json.dumps(dict(commands=len(commands),last=commands[-1]['tag'],
    exit=commands[-1]['exit'],bytes=len(data))))
