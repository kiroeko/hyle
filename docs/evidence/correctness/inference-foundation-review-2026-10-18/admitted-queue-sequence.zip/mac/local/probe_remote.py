from pathlib import Path
import importlib.util
import json

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('transport', OUT.parents[1] / 'apple-readonly-ports/stage.py')
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)

CODE = r'''from pathlib import Path
import json,platform,subprocess
root=Path('/Users/kiro/hyle-scratch/compute-unified')
build=root/'a-cpu-apple/selected-graph/source-build'
database=build/'compile_commands.json'
assert database.is_file(),database
entries=json.loads(database.read_text())
names={
'device.cc','operation.cc','transfer.cc','command_capture.cc','custom_kernel.cc','batch_transfer.cc',
'batch_execution.cc','native_provider.cc','aten_cpu_provider.cc','torch_cpu_program.cc',
'onednn_provider.cc','normalization_internal.cc','ggml_cpu_provider.cc','standard_index.cc','native_batch.cc',
'default_policy.cc','cpu_context.cc','ggml_region.cc','batch.cc','device_test.cc','executable_test.cc',
'execution_source.cc','native_region.cc','cpu_backend.cc'}
selected=[row for row in entries if Path(row['file']).name in names]
histories={}
for name in ['architecture-refactor-20261018-execution-convergence',
             'architecture-refactor-20261018-apple-carrier-copy',
             'architecture-refactor-20261018-apple-carrier-copy/cpu-overlay',
             'architecture-refactor-20261018-apple-native-region']:
 p=root/name/'commands.json'
 assert p.is_file(),p
 histories[name]=json.loads(p.read_text())
print(json.dumps(dict(machine=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),
 compile_database=str(database),selected_commands=selected,histories=histories)))
'''

if __name__ == '__main__':
    result = json.loads(transport.ssh(CODE))
    (OUT / 'remote-preflight.json').write_text(json.dumps(result, indent=2) + '\n')
    print(result['machine'], result['compile_database'])
    for row in result['selected_commands']:
        print(row['file'])
