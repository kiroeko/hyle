from pathlib import Path
import hashlib
import json
import shutil

OUT = Path(__file__).resolve().parent
RESULTS = OUT/'results'
commands = json.loads((RESULTS/'commands.json').read_text())
tests = json.loads((RESULTS/'test-results.json').read_text())
plan = json.loads((RESULTS/'compile-plan.json').read_text())
objects = json.loads((RESULTS/'new-object-identities.json').read_text())
assert tests['tests'] == 24 and tests['failures'] == tests['errors'] == tests['disabled'] == 0
assert len(plan['sources']) == len(objects) == 36
assert commands[-1]['tag'] == 'finite-consumer' and commands[-1]['exit'] == 0
source_rows = json.loads((RESULTS/'staged-sources.json').read_text())
for row in source_rows:
    path = OUT/'run_remote.py' if row['path'] == 'run_remote.py' else OUT.parents[3]/row['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], row['path']
summary = dict(
    machine='Mac16,12', provider_contract=15, region_spi=24, batch_spi=5, mla_spi=3,
    fresh_host_tus=len(objects), vendor_or_kernel_tus_rebuilt=0,
    tests=24, failures=0, errors=0, disabled=0, finite_consumer_exit=0,
    source_files_matched_to_windows=len(source_rows),
    actual_selected_cpu_families=['native','ATen','ggml'],
    onednn_selected=False, cuda_tested=False,
    ggml_cpu_pin='456172ec733a135778adcd32d00e576a58232e45+cpu-overlay-fwht-32d9239586c2be90',
    compiler_checks=['-Wall','-Wextra','-Wpedantic','-Werror'],
    initial_failures=[dict(index=i+1,tag=row['tag'],exit=row['exit'],stderr=row['stderr'])
                      for i,row in enumerate(commands) if row['exit']],
    final_runs=[dict(index=i+1,tag=row['tag'],exit=row['exit']) for i,row in enumerate(commands)
                if i+1 in {43,44,45,46}],
    cleanup_manifest='cleanup-mac.json', retained_objects=36, rebuilt_images_or_maps=4,
    products_edited_by_validation_agent=False, files_deleted=False)
(OUT/'mac-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copyfile(RESULTS/'cleanup-mac.json',OUT/'cleanup-mac.json')
archive = OUT/'mac-results.tar.gz'
receipt = dict(path=str(archive.resolve()),bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(OUT/'mac-results-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps(receipt))
