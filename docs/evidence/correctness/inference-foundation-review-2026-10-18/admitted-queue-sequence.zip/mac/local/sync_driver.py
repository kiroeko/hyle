from pathlib import Path
import base64
import hashlib
import json
import stage

driver = stage.OUT / 'run_remote.py'
digest = hashlib.sha256(driver.read_bytes()).hexdigest()
rows = json.loads((stage.OUT/'staged-sources.json').read_text())
old = next(row for row in rows if row['path'] == 'run_remote.py')
code = '''from pathlib import Path
import base64,hashlib,json
r=Path('''+repr(stage.REMOTE)+''')
p=r/'run_remote.py'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='''+repr(old['sha256'])+'''
p.write_bytes(base64.b64decode('''+repr(base64.b64encode(driver.read_bytes()).decode())+'''))
rows=json.loads((r/'staged-sources.json').read_text())
row=next(row for row in rows if row['path']=='run_remote.py')
row.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(r/'staged-sources.json').write_text(json.dumps(rows,indent=2)+'\\n')
print(row['sha256'])
'''
print(stage.ssh(code).decode().strip())
old.update(bytes=driver.stat().st_size, sha256=digest)
(stage.OUT/'staged-sources.json').write_text(json.dumps(rows,indent=2)+'\n')
