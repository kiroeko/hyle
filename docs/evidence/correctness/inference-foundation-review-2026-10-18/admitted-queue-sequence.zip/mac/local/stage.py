from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-admitted-queue-sequence'
spec = importlib.util.spec_from_file_location('transport',
    OUT.parents[1] / 'apple-readonly-ports/stage.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.ROOT, b.OUT, b.REMOTE = ROOT, OUT, REMOTE
b.SEEDS = [
    'src/compute/device.cc', 'src/compute/operation.cc',
    'src/compute/transfer.cc', 'src/compute/command_capture.cc',
    'src/compute/custom_kernel.cc', 'src/compute/batch_transfer.cc',
    'src/compute_batch/batch_execution.cc', 'src/compute_batch/row_cache_paged_reader.cc',
    'src/compute_provider_native/native_provider.cc',
    'src/compute_provider_native/aten_cpu_provider.cc',
    'src/compute_provider_native/torch_cpu_program.cc',
    'src/compute_provider_ggml/ggml_cpu_provider.cc',
    'src/compute_provider_ggml/standard_index.cc',
    'src/compute_provider_ggml/native_batch.cc',
    'src/compute_route_cpu/default_policy.cc',
    'src/compute_route_cpu/cpu_context.cc',
    'src/graph_route_cpu/cpu_context.cc', 'src/graph_route_cpu/ggml_region.cc',
    'src/graph_batch/batch.cc',
    'src/graph/executable.cc', 'src/graph/submission.cc',
    'src/graph/resources.cc', 'src/graph/region_access.cc',
    'src/graph/constant_artifact.cc', 'src/graph/execution_source.cc',
    'src/graph_route_apple/native_region.cc',
    'src/graph_route_apple/execution_source.cc',
    'tests/compute/device_test.cc', 'tests/graph/executable_test.cc',
    'tests/graph/native_analysis_test.cc', 'tests/graph/route_symmetry_apple.cc',
    'tests/graph_route_apple/native_region_test.cc',
    'tests/graph_route_apple/mixed_region_test.cc',
    'tests/compute_route_apple/late_input_test.cc',
]
ssh = b.ssh

if __name__ == '__main__':
    b.main()
