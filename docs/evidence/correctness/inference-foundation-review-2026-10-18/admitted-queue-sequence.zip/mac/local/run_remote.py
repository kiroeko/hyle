from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CACHE = ROOT.parent
BASE = CACHE / 'architecture-refactor-20261018-execution-convergence'
OLD = CACHE / 'architecture-refactor-20261018-apple-carrier-copy'
BUILD = CACHE / 'a-cpu-apple/selected-graph/source-build'
DATABASE = json.loads((BUILD / 'compile_commands.json').read_text())
HISTORY = json.loads((BASE / 'commands.json').read_text())
OLD_HISTORY = json.loads((OLD / 'commands.json').read_text())
CPU_HISTORY = json.loads((OLD / 'cpu-overlay/commands.json').read_text())
RECORDS = json.loads((ROOT / 'commands.json').read_text()) if (ROOT / 'commands.json').exists() else []


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def command_for(records, tag):
    return next(row['command'] for row in reversed(records) if row['tag'] == tag and row['exit'] == 0)


def run(tag, command):
    command = list(map(str, command))
    if '--resume' in sys.argv:
        previous = next((r for r in reversed(RECORDS) if r['tag'] == tag), None)
        if previous and previous['exit'] == 0:
            print('retained-command', tag, flush=True)
            return
    stem = f'{len(RECORDS) + 1:02d}-{tag}'
    started = time.monotonic()
    with (ROOT / (stem + '.stdout.log')).open('wb') as out, (ROOT / (stem + '.stderr.log')).open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err)
        (ROOT / 'live.json').write_text(json.dumps(dict(tag=tag, pid=process.pid)) + '\n')
        code = process.wait()
    RECORDS.append(dict(tag=tag, command=command, exit=code,
                        seconds=time.monotonic()-started, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log'))
    (ROOT / 'commands.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    (ROOT / 'live.json').write_text(json.dumps(dict(terminal=True, tag=tag, exit=code)) + '\n')
    print(stem, code, flush=True)
    if code:
        print((ROOT / (stem+'.stdout.log')).read_text(errors='replace')[-3000:])
        print((ROOT / (stem+'.stderr.log')).read_text(errors='replace')[-9000:])
        raise SystemExit(code)


def selected_flags(source):
    rows = [row for row in DATABASE if row['file'].endswith('/' + source)]
    if not rows and source == 'src/compute_batch/row_cache_paged_reader.cc':
        rows = [row for row in DATABASE if row['file'].endswith('/src/compute_batch/batch_execution.cc')]
    if not rows and source == 'src/compute_provider_native/row_cache.cc':
        rows = [row for row in DATABASE if row['file'].endswith('/src/compute_provider_native/native_provider.cc')]
    assert len(rows) == 1, source
    row = rows[0]
    return row.get('arguments') or shlex.split(row['command'])


def flags_for(source, template):
    if template == 'selected':
        raw = selected_flags(source)
    elif template == 'overlay':
        raw = next(row['command'] for row in reversed(CPU_HISTORY)
                   if row['exit'] == 0 and any(str(arg).endswith('/'+source) for arg in row['command']))
    elif template == 'core':
        raw = command_for(OLD_HISTORY, 'executable-compile')
    elif template == 'test':
        raw = command_for(OLD_HISTORY, 'mixed-test-compile')
    elif template == 'apple-source':
        raw = command_for(OLD_HISTORY, 'apple-source-compile')
    elif template == 'apple-region':
        raw = command_for(OLD_HISTORY, 'apple-region-compile')
    else:
        raise AssertionError(template)
    args = []
    skip = False
    for i, arg in enumerate(raw):
        if skip:
            skip = False
            continue
        if arg in {'-c', '-o'}:
            skip = True
            continue
        args.append(str(arg))
    includes = [ROOT / 'include', ROOT, ROOT / 'src/compute', ROOT / 'src/graph',
                ROOT / 'src/compute_ggml_runtime', ROOT / 'src/compute_provider_ggml',
                ROOT / 'src/graph_route_cpu', ROOT / 'tests/graph']
    args[1:1] = ['-I'+str(path) for path in includes] + ['-DHYLE_STATIC', '-Werror']
    return args


SOURCES = [
    ('src/compute/device.cc', 'device', 'selected'),
    ('src/compute/operation.cc', 'operation', 'selected'),
    ('src/compute/transfer.cc', 'transfer', 'selected'),
    ('src/compute/command_capture.cc', 'command-capture', 'selected'),
    ('src/compute/custom_kernel.cc', 'custom-kernel', 'selected'),
    ('src/compute/batch_transfer.cc', 'batch-transfer', 'selected'),
    ('src/compute_batch/batch_execution.cc', 'batch-execution', 'selected'),
    ('src/compute_batch/row_cache_paged_reader.cc', 'row-cache-reader', 'selected'),
    ('src/compute_provider_native/native_provider.cc', 'native-provider', 'selected'),
    ('src/compute_provider_native/aten_cpu_provider.cc', 'aten-provider', 'selected'),
    ('src/compute_provider_native/torch_cpu_program.cc', 'torch-program', 'selected'),
    ('src/compute_provider_native/indexing.cc', 'native-indexing', 'selected'),
    ('src/compute_provider_native/row_cache.cc', 'native-row-cache', 'selected'),
    ('src/compute_provider_ggml/ggml_cpu_provider.cc', 'ggml-provider', 'overlay'),
    ('src/compute_provider_ggml/standard_index.cc', 'standard-index', 'overlay'),
    ('src/compute_provider_ggml/native_batch.cc', 'native-batch', 'overlay'),
    ('src/compute_route_cpu/default_policy.cc', 'default-policy', 'overlay'),
    ('src/compute_route_cpu/cpu_context.cc', 'cpu-context', 'selected'),
    ('src/graph_route_cpu/cpu_context.cc', 'graph-context', 'overlay'),
    ('src/graph_route_cpu/ggml_region.cc', 'graph-region', 'overlay'),
    ('src/graph_batch/batch.cc', 'graph-batch', 'overlay'),
    ('src/graph/executable.cc', 'executable', 'core'),
    ('src/graph/submission.cc', 'submission', 'core'),
    ('src/graph/resources.cc', 'resources', 'core'),
    ('src/graph/region_access.cc', 'region-access', 'core'),
    ('src/graph/constant_artifact.cc', 'constant-artifact', 'core'),
    ('src/graph/execution_source.cc', 'common-source', 'core'),
    ('src/graph_route_apple/native_region.cc', 'apple-region', 'apple-region'),
    ('src/graph_route_apple/execution_source.cc', 'apple-source', 'apple-source'),
    ('tests/compute/device_test.cc', 'device-test', 'test'),
    ('tests/graph/executable_test.cc', 'executable-test', 'test'),
    ('tests/graph/native_analysis_test.cc', 'analysis-test', 'test'),
    ('tests/graph/route_symmetry_apple.cc', 'finite-consumer', 'test'),
    ('tests/graph_route_apple/native_region_test.cc', 'native-test', 'test'),
    ('tests/graph_route_apple/mixed_region_test.cc', 'mixed-test', 'test'),
    ('tests/compute_route_apple/late_input_test.cc', 'late-test', 'test'),
]


def main():
    assert subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True).strip() == 'Mac16,12'
    (ROOT / 'machine.txt').write_text(subprocess.check_output(
        ['sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'], text=True)
        + subprocess.check_output(['xcrun', 'clang++', '--version'], text=True))
    for row in json.loads((ROOT/'staged-sources.json').read_text()):
        assert identity(ROOT/row['path'])['sha256'] == row['sha256'], row['path']
    baseline = command_for(HISTORY, 'native-tests-link')
    replace = {
        str(OLD/'cpu-overlay/provider.o'): 'ggml-provider',
        str(OLD/'cpu-overlay/standard-index.o'): 'standard-index',
        str(OLD/'cpu-overlay/native-batch.o'): 'native-batch',
        str(OLD/'cpu-overlay/default-policy.o'): 'default-policy',
        str(OLD/'cpu-overlay/graph-region.o'): 'graph-region',
        str(OLD/'cpu-overlay/batch.o'): 'graph-batch',
        str(OLD/'cpu-overlay/batch-execution.o'): 'batch-execution',
        str(OLD/'cpu-overlay/batch-transfer.o'): 'batch-transfer',
        str(BASE/'graph-context.o'): 'graph-context',
        str(BASE/'executable.o'): 'executable',
        str(BASE/'submission.o'): 'submission',
        str(BASE/'analysis-test.o'): 'analysis-test',
        str(OLD/'resources.o'): 'resources',
        str(OLD/'region-access.o'): 'region-access',
        str(OLD/'constant-artifact.o'): 'constant-artifact',
        str(OLD/'common-source.o'): 'common-source',
        str(OLD/'apple-region.o'): 'apple-region',
        str(OLD/'apple-source.o'): 'apple-source',
        str(OLD/'test.o'): 'native-test',
        str(OLD/'mixed-test.o'): 'mixed-test',
        str(OLD/'late-test.o'): 'late-test',
        str(CACHE/'architecture-refactor-20261018-apple-native-region/device.o'): 'device',
        str(CACHE/'architecture-refactor-20261018-apple-native-region/operation.o'): 'operation',
    }
    assert set(replace).issubset(set(baseline)), set(replace)-set(baseline)
    baseline_ids = json.loads((BASE / 'native-tests-identities.json').read_text())
    retained = [row for row in baseline_ids if Path(row['path']).suffix in {'.o', '.a', '.dylib'} and row['path'] not in replace]
    for row in retained:
        assert identity(row['path'])['sha256'] == row['sha256'], row['path']
    (ROOT/'retained-identities.json').write_text(json.dumps(retained, indent=2)+'\n')
    plan = [dict(source=source, object=str(ROOT/(name+'.o')), template=template,
                 command=flags_for(source, template)+['-c', str(ROOT/source), '-o', str(ROOT/(name+'.o'))])
            for source, name, template in SOURCES]
    (ROOT/'compile-plan.json').write_text(json.dumps(dict(database=str(BUILD/'compile_commands.json'),
        provider=15, region=24, batch=5, mla=3, onednn_in_selected=False, sources=plan), indent=2)+'\n')
    if '--plan-only' in sys.argv:
        print('compile-plan-ready', len(plan), 'host TUs', flush=True)
        return
    metal = (BASE/'mlx.metallib').resolve(strict=True)
    if not (ROOT/'mlx.metallib').exists():
        (ROOT/'mlx.metallib').symlink_to(metal)
    for row in plan:
        run(Path(row['object']).stem+'-compile', row['command'])
        assert Path(row['object']).is_file(), row['object']
    new_objects = {name for source, name, template in SOURCES if name not in replace.values() and name != 'finite-consumer'}
    command = [baseline[0]] + [str(ROOT/(name+'.o')) for name in sorted(new_objects)]
    skip = False
    for arg in baseline[1:]:
        if skip:
            skip = False
            continue
        if arg == '-o':
            command += ['-o', str(ROOT/'native-tests')]
            skip = True
            continue
        if arg.startswith('-Wl,-map,'):
            arg = '-Wl,-map,'+str(ROOT/'native-tests.map')
        if arg in replace:
            arg = str(ROOT/(replace[arg]+'.o'))
        command.append(arg)
    run('native-tests-link', command)
    (ROOT/'native-tests-identities.json').write_text(json.dumps(
        [identity(p) for p in command if str(p).endswith(('.o','.a','.dylib'))]
        + [identity(ROOT/'native-tests'),identity(ROOT/'native-tests.map')], indent=2)+'\n')
    test_filter = ('AppleNativeRegion.*:AppleLateInput.*:AppleMixedRegion.*:'
        'ExactGraphSpecialization.*:NativeReachability.*:NativePartition.*:'
        'Queue.AdmittedSequenceKeepsItsActualOwnerAfterPublicHandlesClose:'
        'Invocation.PreparedReplayFollowsQueueIdentityAcrossPublicHandleMoves')
    run('native-tests', [ROOT/'native-tests', '--gtest_filter='+test_filter,
        '--gtest_color=no', '--gtest_output=json:'+str(ROOT/'test-results.json')])
    tests = {str(ROOT/(name+'.o')) for name in ['device-test','executable-test','analysis-test','native-test','mixed-test','late-test']}
    consumer = []
    skip = False
    for arg in command:
        if skip:
            skip = False
            continue
        if arg in tests:
            continue
        if arg == '-o':
            consumer += ['-o', str(ROOT/'finite-consumer')]
            skip = True
            continue
        if arg.startswith('-Wl,-map,'):
            arg = '-Wl,-map,'+str(ROOT/'finite-consumer.map')
        consumer.append(arg)
    consumer[1:1] = [str(ROOT/'finite-consumer.o')]
    run('finite-consumer-link', consumer)
    run('finite-consumer', [ROOT/'finite-consumer'])
    (ROOT/'new-object-identities.json').write_text(json.dumps([identity(row['object']) for row in plan], indent=2)+'\n')
    (ROOT/'final-source-identities.json').write_text(json.dumps([identity(ROOT/source) for source,name,template in SOURCES], indent=2)+'\n')


if __name__ == '__main__':
    main()
