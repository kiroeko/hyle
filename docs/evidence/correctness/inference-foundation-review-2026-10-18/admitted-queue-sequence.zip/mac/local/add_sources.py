from pathlib import Path
import hashlib
import io
import json
import re
import sys
import tarfile
import stage

rows = json.loads((stage.OUT/'staged-sources.json').read_text())
known = {row['path']: row for row in rows}
files = {}
seen = set()

def add(path):
    path = path.resolve()
    if path in seen or not path.is_relative_to(stage.ROOT):
        return
    seen.add(path)
    name = path.relative_to(stage.ROOT).as_posix()
    if name in known:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == known[name]['sha256'], name
        return
    files[name] = path
    for include in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]', path.read_text(encoding='utf-8-sig'), re.M):
        for directory in [path.parent, stage.ROOT, stage.ROOT/'include', stage.ROOT/'src/compute', stage.ROOT/'src/graph']:
            candidate = directory/include
            if candidate.is_file():
                add(candidate)
                break

for source in sys.argv[1:]:
    add(stage.ROOT/source)
new_rows = [dict(path=name, bytes=path.stat().st_size,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in sorted(files.items())]
data = io.BytesIO()
with tarfile.open(fileobj=data,mode='w:gz') as a:
    for name,path in sorted(files.items()):
        a.add(path,arcname=name)
(stage.OUT/'additional-sources.tar.gz').write_bytes(data.getvalue())
code = '''from pathlib import Path
import hashlib,io,json,sys,tarfile
r=Path('''+repr(stage.REMOTE)+''')
new_rows=json.loads('''+repr(json.dumps(new_rows))+''')
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as a:
 assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and not (r/m.name).exists() for m in a.getmembers())
 a.extractall(r)
for row in new_rows:
 p=r/row['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
rows=json.loads((r/'staged-sources.json').read_text())
rows.extend(new_rows)
(r/'staged-sources.json').write_text(json.dumps(rows,indent=2)+'\\n')
print(len(new_rows))
'''
print(stage.ssh(code,data.getvalue()).decode().strip())
rows.extend(new_rows)
(stage.OUT/'staged-sources.json').write_text(json.dumps(rows,indent=2)+'\n')
(stage.OUT/'additional-source-identities.json').write_text(json.dumps(new_rows,indent=2)+'\n')
