from pathlib import Path
import base64
import hashlib
import json
import sys
import stage

rows = json.loads((stage.OUT/'staged-sources.json').read_text())
changes = []
for name in sys.argv[1:]:
    assert not Path(name).is_absolute() and '..' not in Path(name).parts, name
    path = stage.ROOT/name
    old = next(row for row in rows if row['path'] == name)
    data = path.read_bytes()
    changes.append(dict(path=name, old_sha256=old['sha256'],
        new_sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
        data=base64.b64encode(data).decode()))
code = '''from pathlib import Path
import base64,hashlib,json,sys
r=Path('''+repr(stage.REMOTE)+''')
changes=json.loads(sys.stdin.buffer.read())
rows=json.loads((r/'staged-sources.json').read_text())
history=json.loads((r/'source-deltas.json').read_text()) if (r/'source-deltas.json').exists() else []
for change in changes:
 p=r/change['path']
 assert p.resolve().is_relative_to(r.resolve())
 assert hashlib.sha256(p.read_bytes()).hexdigest()==change['old_sha256'],change['path']
 before=r/'before-delta'/str(len(history))/change['path']
 before.parent.mkdir(parents=True,exist_ok=True)
 before.write_bytes(p.read_bytes())
 p.write_bytes(base64.b64decode(change.pop('data')))
 assert hashlib.sha256(p.read_bytes()).hexdigest()==change['new_sha256']
 row=next(row for row in rows if row['path']==change['path'])
 row.update(bytes=change['bytes'],sha256=change['new_sha256'])
 history.append(change)
(r/'staged-sources.json').write_text(json.dumps(rows,indent=2)+'\\n')
(r/'source-deltas.json').write_text(json.dumps(history,indent=2)+'\\n')
print(json.dumps(changes))
'''
output = stage.ssh(code, json.dumps(changes).encode())
print(output.decode().strip())
for change in changes:
    old = next(row for row in rows if row['path'] == change['path'])
    old.update(bytes=change['bytes'],sha256=change['new_sha256'])
(stage.OUT/'staged-sources.json').write_text(json.dumps(rows,indent=2)+'\n')
(stage.OUT/'last-sync-delta.json').write_bytes(output)
