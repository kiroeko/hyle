import json
import run_remote as b

plan = json.loads((b.ROOT/'compile-plan.json').read_text())['sources']
first = next(i for i, row in enumerate(plan) if row['source'] == 'src/graph_batch/batch.cc') + 1
for row in plan[first:]:
    b.run(b.Path(row['object']).stem+'-compile', row['command'])
