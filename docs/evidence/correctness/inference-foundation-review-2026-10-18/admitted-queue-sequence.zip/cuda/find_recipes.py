from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
paths = subprocess.check_output(['rg', '--files', '.scratch', '-g', '*commands*.json'],
    cwd=ROOT, text=True).splitlines()
rows = []
for relative in paths:
    path = ROOT / relative
    try:
        value = json.loads(path.read_text(encoding='utf-8-sig'))
    except (ValueError, OSError):
        continue
    entries = value if isinstance(value, list) else [value]
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict):
            continue
        command = entry.get('command', [])
        if not isinstance(command, list) or not command:
            continue
        if Path(str(command[0])).name.lower() != 'cl.exe' or '/c' not in command:
            continue
        for arg in command[1:]:
            text = str(arg)
            source = Path(text[3:] if text.lower().startswith('/tp') else text)
            if source.suffix.lower() != '.cc':
                continue
            try:
                name = source.resolve().relative_to(ROOT).as_posix()
            except ValueError:
                continue
            if not name.startswith(('src/compute_backend_cuda/',
                    'src/compute_provider_cuda/', 'src/compute_provider_cublas/',
                    'src/compute_provider_flashinfer/', 'src/compute_provider_ggml_cuda/',
                    'src/compute_provider_torch_cuda/', 'src/compute_route_cuda/',
                    'src/graph_route_cuda/', 'src/graph_provider_ggml_cuda/')):
                continue
            rows.append(dict(source=name, record=relative, row=index,
                tag=entry.get('tag'), exit=entry.get('exit'), command=command,
                modified=path.stat().st_mtime))
(OUT/'cached-recipes-index.json').write_text(json.dumps(rows,indent=2)+'\n',
    encoding='utf-8',newline='\n')
for source in sorted({row['source'] for row in rows}):
    found = sorted([row for row in rows if row['source']==source and row['exit']==0],
        key=lambda row:row['modified'],reverse=True)
    print(source, len(found), [(row['record'],row['tag']) for row in found[:2]])
