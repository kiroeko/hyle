#include "progress.h"

#include <chrono>
#include <utility>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/detail/queue_sequence.h"
#include "hyle/sched/sync.h"

namespace hyle::graph::cpu_cuda::detail {
namespace {

void CUDART_CB signal_ready(void *opaque) noexcept {
  static_cast<sched::Event *>(opaque)->signal();
}

} // namespace

Status wait_cuda_prefix(const compute::detail::QueueRef &queue, sched::Event &ready) noexcept {
  ready.reset();
  HYLE_ASSIGN_OR_RETURN(auto sequence, compute::detail::QueueSequence::begin(queue));
  auto stream = compute::cuda::stream(sequence);
  if (!stream) {
    sequence.record(compute::detail::EnqueueResult::rejected(stream.error()));
  } else {
    cudaStreamCaptureStatus capture = cudaStreamCaptureStatusNone;
    const auto queried = cudaStreamIsCapturing(*stream, &capture);
    if (queried != cudaSuccess) {
      sequence.record(compute::detail::EnqueueResult::rejected(compute::cuda::status(queried)));
    } else if (capture != cudaStreamCaptureStatusNone) {
      sequence.record(compute::detail::EnqueueResult::rejected(
          Status::FailedPrecondition("CUDA progress cannot wait on a recording capture")));
    } else {
      sequence.record(compute::detail::EnqueueResult::accepted_command(
          compute::cuda::status(cudaLaunchHostFunc(*stream, &signal_ready, &ready))));
    }
  }
  auto notification = sequence.finish();
  if (!notification)
    return std::move(notification).error();
  // A CUDA error may suppress the host callback. The existing fiber-aware
  // timer wait provides a bounded error-observation fallback, not a busy loop.
  while (!ready.wait_for(std::chrono::milliseconds(1))) {
    auto state = notification->poll();
    if (!state)
      return std::move(state).error();
    if (*state == compute::CompletionPoll::kComplete)
      break;
  }
  // The prefix event is after the callback. Retire it before a slot can reset
  // or destroy ready, even if the fiber was woken before signal() returned.
  return notification->wait();
}

} // namespace hyle::graph::cpu_cuda::detail
