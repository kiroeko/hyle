"""Prepare host-only command arrays from actual local cached module recipes.

Never executes a compiler, imports an experiment driver, or changes a product.
"""
from pathlib import Path
import ctypes
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = ROOT/'.scratch/build-compute-v2-dev'
NINJA = BASE/'build.ninja'
CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')

def read(path):
    return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))

def cached(path, tag):
    rows = read(path)
    row = next(row for row in reversed(rows) if row.get('tag')==tag and row.get('exit')==0)
    return row['command'], dict(record=path, tag=tag, exit=0)

def split_windows(text):
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
    count = ctypes.c_int()
    pointer = shell.CommandLineToArgvW('ignored '+text, ctypes.byref(count))
    try:
        return [pointer[i] for i in range(1,count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree(pointer)

def ninja(source):
    text = NINJA.read_text()
    basename = Path(source).name
    start = next(match.start() for match in re.finditer(r'^build .+',text,re.M)
        if ('\\'+basename+'.obj: CXX_COMPILER_') in match.group(0)
        and source.replace('/','\\').split('src\\',1)[1] in match.group(0))
    body = text[start:text.index('\n\n',start)]
    fields = {name:re.search(r'^  '+name+r' = (.*)$',body,re.M).group(1)
        for name in ['DEFINES','FLAGS','INCLUDES']}
    flags = split_windows(' '.join(fields.values()))
    flags = [('/'+flag[1:]) if flag.startswith('-') else flag for flag in flags]
    return [str(CL),'/nologo','/c',*flags],dict(record=NINJA.relative_to(ROOT).as_posix(),
        source_rule=source, fields=fields, note='CMake generated CXX module flags; no compile_commands.json used')

def flags_only(command):
    result=[]
    for flag in command[1:]:
        lower=flag.lower()
        if lower.startswith(('/fo','/fp','/fd','/tp','/tc')) or lower.endswith(('.cc','.cpp','.cxx')):
            continue
        if re.match(r'^[-/]D(HYLE_COMPUTE_[A-Z_]+|HYLE_TEST_GGML_CPU|HYLE_GGML_CPU_PROVIDER_VERSION)(=|$)',flag):
            continue
        if re.match(r'^[-/]D(HYLE_TESTING|HYLE_GRAPH_ONEDNN)(=|$)',flag):
            continue
        result.append(flag)
    return result

rows=[]
details=[]
def add(source, template, origin, module, capabilities, extra=()):
    flags=flags_only(template)
    flags += ['/DHYLE_'+module.upper()+'_BUILD']
    flags += ['/DHYLE_COMPUTE_'+name.upper()+'=1' for name in capabilities]
    flags += list(extra)
    flags += ['/I'+str(ROOT/'src'/module)]
    for flag in ['/W4','/WX','/wd4324','/bigobj','/Zc:preprocessor','/Zc:__cplusplus','/utf-8']:
        if flag not in flags: flags.append(flag)
    flags=list(dict.fromkeys(flags))
    output=OUT/(module+'--'+Path(source).stem+'.obj')
    command=[str(CL),*flags,str(ROOT/source),'/Fo'+str(output)]
    checks=[]
    for flag in command:
        path=None
        for prefix in ['/external:I','/I','/FI']:
            if flag.lower().startswith(prefix.lower()):
                path=Path(flag[len(prefix):]);break
        if path is not None:
            checks.append(dict(path=str(path),exists=path.exists(),
                purpose='forced include' if flag.lower().startswith('/fi') else 'include'))
    assert (ROOT/source).is_file(),source
    assert CL.is_file(),CL
    assert all(check['exists'] for check in checks),[check for check in checks if not check['exists']]
    rows.append(dict(source=source,command=command))
    details.append(dict(source=source,object=str(output),flags_from=origin,
        capability_definitions=capabilities,source_sha256=hashlib.sha256((ROOT/source).read_bytes()).hexdigest(),
        includes=checks))

host='.scratch/inference-feature-completion-2026-10-18/windows-batch/host-commands.json'
for source in ['src/compute_backend_cuda/cuda_backend.cc','src/compute_backend_cuda/cuda_device_status.cc']:
    command,origin=ninja(source)
    add(source,command,origin,'compute_backend_cuda',['cuda'])

native,origin=cached(host,'cuda-collectives_provider-compile')
for path in sorted((ROOT/'src/compute_provider_cuda').glob('*.cc')):
    add(path.relative_to(ROOT).as_posix(),native,origin,'compute_provider_cuda',['cuda'])

command,origin=cached(host,'cublas-provider-compile')
add('src/compute_provider_cublas/cublas_provider.cc',command,origin,'compute_provider_cublas',['cuda'])
command,origin=cached(host,'flashinfer-provider-compile')
add('src/compute_provider_flashinfer/flashinfer_provider.cc',command,origin,
    'compute_provider_flashinfer',['cuda','flashinfer'],['/DFLASHINFER_ENABLE_BF16','/DFLASHINFER_ENABLE_F16'])

derived='.scratch/inference-fusion-quantization-2026-10-18/derived-constant-implementation/commands.json'
command,origin=cached(derived,'cuda-provider-compile')
for name in ['ggml_cuda_provider','tensor_program']:
    add('src/compute_provider_ggml_cuda/'+name+'.cc',command,origin,
        'compute_provider_ggml_cuda',['cuda','ggml_cuda'])

command,origin=ninja('src/compute_provider_torch_cuda/artifact_provider.cc')
add('src/compute_provider_torch_cuda/artifact_provider.cc',command,origin,
    'compute_provider_torch_cuda',['cuda','torch_cuda'])

roster=['cuda','flashinfer','ggml_cuda','torch_cuda']
for name,tag in [('cuda_context','default-context-compile'),('default_policy','default-policy-compile'),
                 ('best_of','best-of-compile')]:
    command,origin=cached(host,tag)
    add('src/compute_route_cuda/'+name+'.cc',command,origin,'compute_route_cuda',roster)
command,origin=cached('.scratch/inference-foundation-review-2026-10-18/weight-order/commands.json','weights-after-compile')
add('src/compute_route_cuda/weights.cc',command,origin,'compute_route_cuda',roster)
command,origin=cached('.scratch/architecture-refactor-2026-10-18/port-contract-adapters/commands.json','cuda-region-compile')
add('src/graph_provider_ggml_cuda/ggml_cuda_region.cc',command,origin,
    'graph_provider_ggml_cuda',['cuda','ggml_cuda'])
command,origin=cached('.scratch/architecture-refactor-2026-10-18/cold-constant-copy/commands.json','cuda-context.obj-compile')
add('src/graph_route_cuda/cuda_context.cc',command,origin,'graph_route_cuda',roster)

(OUT/'compile-recipes.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
metadata=dict(scope='host C++ recipes only; none executed',compiler=str(CL),
    environment='Use scripts/hyle_environment.py windows_compiler_environment with this cl.exe; cwd repository root',
    module_capability_source='cmake/HyleComputeCapabilities.cmake and current per-module CMakeLists.txt',
    macro_policy='Remove unrelated cached HYLE_COMPUTE_* roster flags and reconstruct only the actual target capabilities; retain target build macro and all other cached compiler/native pin flags',
    cublas='Current target declares capability cuda; HYLE_COMPUTE_CUBLAS is not defined or invented',
    default_c2='No HYLE_CUDA_DEFAULT_C2_RECIPE added: cached actual native-provider source identity differs from that qualified original recipe',
    includes_checked=True,compile_run=False,missing_modules=[],recipes=details,
    boundary=['No native CUDA .cu or SDK rebuild commands are included',
        'Backend test hooks are not enabled in these product host commands; HYLE_TESTING may be added only for an explicitly instrumented host object',
        'Old cached binary objects and their PreparedProvider callback ABI must not be reused for the changed vtable owners; these recipes compile current source'])
(OUT/'compile-recipes-provenance.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(recipes=len(rows),all_includes_exist=True,compile_executed=False,
    output=str(OUT/'compile-recipes.json')),indent=2))
