from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):
    path=Path(path)
    return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=sha(path))
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
commands=json.loads((OUT/'commands.json').read_text())
compiled=json.loads((OUT/'compile-status.json').read_text())
recipes=json.loads((OUT/'compile-recipes.json').read_text())
assert len(compiled)==27
for row in compiled:
    assert row['sha256']==sha(ROOT/row['source']),row['source']
    assert row['object_sha256']==sha(row['object']),row['object']
assert {row['source']for row in recipes}-{row['source']for row in compiled}=={'src/compute_provider_ggml_cuda/tensor_program.cc'}
header=json.loads((OUT/'ggml-header-only.json').read_text())
assert header['source_sha256']==sha(ROOT/header['source'])

sources=[row['source']for row in recipes]+[
    'src/graph_route_cpu_cuda/compile.cc','src/graph_route_cpu_cuda/invocation.cc',
    'src/graph_route_cpu_cuda/progress.cc','tests/graph/route_symmetry_cuda.cc',
    'tests/compute_provider_cuda/gather_collectives_test.cc',
    'tests/compute_provider_cuda/collectives_test_support.h',
    'src/compute/provider_internal.h','src/compute_backend_cuda/native_context.h',
    'src/compute_backend_cuda/device_status_kernel.h',
    'include/hyle/compute/detail/queue_ref.h','include/hyle/compute/detail/queue_sequence.h',
    'include/hyle/compute/detail/backend_extension.h',
    'include/hyle/compute/detail/provider_extension.h']
source_identities=[]
for name in dict.fromkeys(sources):
    path=ROOT/name;target=OUT/'candidate'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(path.read_bytes())
    source_identities.append(identity(path))
save('final-source-identities.json',source_identities)
save('retained-objects.json',[identity(path)for path in sorted(OUT.glob('*.obj'))])
images=[identity(path)for path in sorted(OUT.iterdir())if path.suffix.lower()in['.exe','.map','.exp','.lib']]
save('cleanup-candidates.json',dict(scope='Only these exact images/maps; no deletion performed. All .obj, source, SDK and raw logs retained.',files=images))
def passed(tag):return next(row for row in reversed(commands)if row['tag']==tag and row['exit']==0)
runs=[passed(tag)for tag in ['hardware','native-consumer-run','checked-gather-run']]
save('summary.json',dict(
    scope='Actual admitted QueueSequence host integration and representative native CUDA GPU consumers; no product source changed by this verification stage',
    host_compile=dict(passed_sources=28,ordinary_cached_header_sources=27,
        iq1_public_header_only_sources=1,strict_flags='/W4 /WX and original CMake /wd4324',
        boundary='28/28 current host source TUs compiled, but the tensor_program object is source-only and never linked to mismatched old CUDA native binaries'),
    common_host_closure='Current parent admitted-queue-sequence CPU/core objects. Current joint compile/invocation/progress and source consumer fresh. Only one CPU ggml/base library set.',
    hardware=dict(name='NVIDIA GeForce RTX 4070',compute_capability='8.9',driver='617.14',memory_mib=12282),
    actual_runs=[dict(tag=row['tag'],exit=row['exit'],seconds=row['seconds'],stdout=row['stdout'],stderr=row['stderr'])for row in runs],
    finite_consumer=dict(result='PASS',assembly='Real cuda_native::provider expert Context; default CPU context',
        unchanged='Original finite exact shapes1/4, CPU Abs -> CUDA Neg -> host output, exact numeric oracle, undeclared shape rejection, cumulative budget rejection, held-result slot gate',
        delta='Scratch clone only replaces default CUDA Context construction with explicit actual native ProviderBinding. Canonical default source compiled but not changed or run.',
        source='expert-route-symmetry-cuda.cc',output='43-native-consumer-run.stdout.log'),
    checked_status=dict(result='2/2 PASS',tests=['CudaCcclGather.CheckedFailurePreservesAllOutputAndFreshSlotRecovers',
        'CudaCcclGather.CheckedSubmitStaysPendingBehindProducerAndReportsDeviceError'],
        boundary='Original numerical collectives native.obj reused, current host callback/status Sequence compiled. Real GPU producer gate/pending/device error and full-output preservation exercised.'),
    default_cuda_consumer=dict(compiled=True,linked=False,run=False,
        reason='No located current Hyle resource-bridge CUDA IQ1 native library cache. Old original mixed source-4e1a7b2f39afe15d has no IQ1_XS/XXS/XXXS. Reference-windows f99368c68335266b public headers and libraries are internally paired but original independent native libraries are not current Hyle resource-bridge binaries; not used as product runtime.'),
    native_sdk='Existing numerical CUDA kernels and CPU ggml native caches reused; no CUDA/ggml/Torch SDK/native shader compilation performed',
    failures_retained=[dict(command='03-host-compute_provider_cuda-collectives_provider',
        classification='Recipe omission',detail='Added current CMake /wd4324 after enabling /W4 /WX; no capability macro changed'),
        dict(command='22-host-compute_provider_ggml_cuda-tensor_program',classification='Cached native header mismatch',detail='Old CUDA header lacks existing current IQ1 enums. Source-only compile with same-pin actual public IQ1 headers passed; native default runtime remains unverified'),
        dict(command='32-joint-invocation.obj-compile',classification='Actual MSVC product compile defect fixed by root',detail='Ambiguous Status/ResultError conditional split to explicit if/else at invocation.cc537-541; fresh35 passed'),
        dict(command='38-expert-consumer-compile',classification='Scratch fixture correction',detail='Actual cuda::device requires ordinal; changed to device(0)'),
        dict(command='40-native-consumer-link',classification='Verification closure omission',detail='Added existing hyle_sched.lib plus preserved matching BlockingPool candidate.obj; fresh41 linked')],
    product_fix_owner='root only; this stage wrote scratch recipes/consumer/commands/evidence',
    no_performance_claim=True,git_diff_check='PASS',
    retained_objects='retained-objects.json',cleanup='cleanup-candidates.json',
    evidence=['commands.json','compile-recipes.json','compile-recipes-provenance.json',
        'compile-status.json','consumer-objects.json','final-source-identities.json',
        'native-consumer-link-identities.json','checked-gather-link-identities.json',
        'candidate/','43-native-consumer-run.stdout.log','46-checked-gather-run.stdout.log']))
print(json.dumps(dict(summary=str(OUT/'summary.json'),host_sources=28,actual_gpu_runs=2,
    image_candidates=len(images),objects_retained=len(list(OUT.glob('*.obj')))),indent=2))
