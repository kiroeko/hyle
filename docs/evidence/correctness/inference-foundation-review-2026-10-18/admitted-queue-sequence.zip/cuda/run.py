from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
ARCH=OUT.parents[1]
spec=importlib.util.spec_from_file_location('queue_parent',OUT.parent/'build.py')
parent=importlib.util.module_from_spec(spec)
spec.loader.exec_module(parent)
b=parent.b
b.OUT=OUT

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def records(path=OUT/'commands.json'):
    return json.loads(path.read_text())if path.exists()else[]
def successful(stage,tag):
    return next(row['command']for row in reversed(records(stage/'commands.json'))if row['tag']==tag and row['exit']==0)
def flags(command):
    return [v for v in command[1:]if not v.lower().startswith(('/fo','/tp'))and not v.endswith('.cc')]
def compile_recipes(resume=False,skip=()):
    state=records(OUT/'compile-status.json')
    for row in records(OUT/'compile-recipes.json'):
        source=ROOT/row['source'];command=row['command']
        if row['source']in skip:
            print('explicit skip pending correction',row['source'],flush=True);continue
        output=Path(next(v[3:]for v in command if v.lower().startswith('/fo')))
        if resume and output.is_file()and any(old.get('source')==row['source']and old.get('command')==command
                and old.get('sha256')==sha(source)and old.get('object_sha256')==sha(output)for old in state):
            print('reuse',row['source'],flush=True);continue
        b.run('host-'+source.parent.name+'-'+source.stem,command)
        state.append(dict(source=row['source'],command=command,sha256=sha(source),object=str(output),object_sha256=sha(output)))
        save('compile-status.json',state)

def compile_consumer():
    stage=ARCH/'cuda-finite-consumer'
    recipes=[(stage,'route-symmetry-cuda-compile','tests/graph/route_symmetry_cuda.cc','consumer.obj'),
        (stage,'joint-compile.obj-compile','src/graph_route_cpu_cuda/compile.cc','joint-compile.obj'),
        (stage,'joint-invocation.obj-compile','src/graph_route_cpu_cuda/invocation.cc','joint-invocation.obj'),
        (ROOT/'.scratch/inference-foundation-review-2026-10-18/hybrid-weight-dependencies',
            'joint-progress-compile','src/graph_route_cpu_cuda/progress.cc','joint-progress.obj')]
    for stage,tag,source,name in recipes:
        old=successful(stage,tag)
        command=[old[0],*flags(old),str(ROOT/source),'/Fo'+str(OUT/name)]
        b.run(name+'-compile',command)
    save('consumer-objects.json',[dict(source=source,source_sha256=sha(ROOT/source),
        object=str(OUT/name),object_sha256=sha(OUT/name))for _,_,source,name in recipes])

def compile_expert():
    source=ROOT/'tests/graph/route_symmetry_cuda.cc'
    text=source.read_text()
    text=text.replace('#include <hyle/graph/cuda.h>',
        '#include <hyle/graph/cuda.h>\n#include <hyle/compute/providers/cuda.h>')
    previous='HYLE_ASSIGN_OR_RETURN(auto cuda,g::cuda::create_context());'
    replacement='''HYLE_ASSIGN_OR_RETURN(auto selected,c::cuda::device(0));
  // Scratch-only actual expert assembly; the canonical default consumer stays unchanged.
  const std::array native_providers{c::ProviderBinding{c::cuda_native::provider()}};
  HYLE_ASSIGN_OR_RETURN(auto cuda,c::Context::create(selected,{.providers=native_providers}));'''
    assert text.count(previous)==1
    applied=OUT/'expert-route-symmetry-cuda.cc'
    applied.write_text(text.replace(previous,replacement),encoding='utf-8',newline='\n')
    old=successful(ARCH/'cuda-finite-consumer','route-symmetry-cuda-compile')
    b.run('expert-consumer-compile',[old[0],*flags(old),str(applied),'/Fo'+str(OUT/'expert-consumer.obj')])
    save('expert-consumer-difference.json',dict(original=str(source),original_sha256=sha(source),
        scratch=str(applied),scratch_sha256=sha(applied),difference='Only actual CUDA Context assembly changes from default to cuda_native::provider; CPU and Graph/shape/math/control/oldresult assertions unchanged'))

def compile_tensor_header_only():
    row=next(row for row in records(OUT/'compile-recipes.json')if row['source'].endswith('/tensor_program.cc'))
    reference=ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows'
    identity=json.loads((reference/'identity.json').read_text())
    for name in ['include/ggml.h','include/ggml-backend.h','src/ggml-backend-impl.h']:
        assert sha(reference/name)==identity['files'][name]
    command=[('/external:I'+str(reference/'include'))if v.startswith('/external:I')and 'source-4e1a7b2f39afe15d' in v else v for v in row['command']]
    command=[('/Fo'+str(OUT/'ggml-tensor-header-only.obj'))if v.lower().startswith('/fo')else v for v in command]
    b.run('ggml-tensor-current-public-headers-only-compile',command)
    save('ggml-header-only.json',dict(source=row['source'],source_sha256=sha(ROOT/row['source']),
        headers_identity=str(reference/'identity.json'),source_pin=identity['source_pin'],source_id=identity['source_id'],
        scope='Current Hyle tensor adapter source compiled using actual same-pin IQ1 public headers only; object is not linked to mismatched old CUDA native binaries',
        native_runtime_validated=False,default_cuda_runtime_validated=False))

def expert_link(gtest=False):
    cpu=successful(OUT.parent,'cpu-controls-link')
    cuda=successful(ARCH/'cuda-finite-runtime','cuda-finite-consumer-link')
    args=[cpu[0]];seen=set();excluded=[]
    for value in cpu[1:]:
        path=Path(value);name=path.name.lower()
        if value.upper().startswith(('/OUT:','/MAP:')):continue
        if (path.suffix.lower()=='.obj'and ('test' in name or 'fault' in name))or name in ['gtest_main.lib','gtest.lib']:
            excluded.append(value);continue
        if value.lower()not in seen:args.append(value);seen.add(value.lower())
    for value in cuda[1:]:
        path=Path(value)
        if (path.suffix.lower()=='.obj'and ('.cu.obj'in path.name or 'concat_kernel.current'in path.name or 'sampling_kernel.current'in path.name)):
            if path.name=='collectives.cu.obj':
                value=str(ROOT/'.scratch/inference-foundation-review-2026-10-18/cccl-device-gather/native.obj')
            if value.lower()not in seen:args.append(value);seen.add(value.lower())
        if path.suffix.lower()=='.lib'and (path.name.lower()=='hyle_compute_backend_cuda.lib'or path.name.lower()in ['cudart.lib','cuda.lib','cublas.lib','cublaslt.lib']):
            if value.lower()not in seen:args.append(value);seen.add(value.lower())
    extra=[OUT/'compute_backend_cuda--cuda_backend.obj',OUT/'compute_backend_cuda--cuda_device_status.obj']
    extra += sorted(OUT.glob('compute_provider_cuda--*.obj'))
    extra += [OUT/'compute_provider_cublas--cublas_provider.obj',
        ROOT/'.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer/row-codec.obj',
        ROOT/'.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer/indexer-kernel.obj',
        ROOT/'.scratch/perf-review-2026-10-18/blocking-pool/candidate.obj',
        ROOT/'.scratch/build-compute-v2-dev/bin/hyle_sched.lib']
    if gtest:
        extra += [OUT/'checked-gather-tests.obj',ROOT/'.scratch/build-compute-v2-dev/lib/gtest_main.lib',ROOT/'.scratch/build-compute-v2-dev/lib/gtest.lib']
    else:extra += [OUT/'expert-consumer.obj',OUT/'joint-compile.obj',OUT/'joint-invocation.obj',OUT/'joint-progress.obj',OUT/'compute_route_cuda--weights.obj']
    for path in extra:
        assert path.is_file(),path
        if str(path).lower()not in seen:args.append(str(path));seen.add(str(path).lower())
    for value in args:
        if Path(value).suffix.lower()in ['.obj','.lib']and Path(value).is_absolute():assert Path(value).is_file(),value
    name='checked-gather'if gtest else'native-consumer'
    args += ['/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map'))]
    save(name+'-link-identities.json',[dict(path=v,bytes=Path(v).stat().st_size,sha256=sha(v))for v in args if Path(v).is_file()and Path(v).suffix.lower()in ['.obj','.lib']])
    save(name+'-closure-boundary.json',dict(base='Current parent CPU controls host closure plus actual original CUDA numeric kernel objects and new v15 native CUDA host adapters',
        no_cuda_ggml_library=True,no_second_cpu_base=True,excluded_tests=excluded,
        default_cuda_runtime=False,expert_cuda_runtime=True))
    b.run(name+'-link',args)

def check_compile():
    old=successful(ROOT/'.scratch/inference-foundation-review-2026-10-18/cccl-device-gather','gather-tests-compile')
    command=[old[0],*flags(old),str(ROOT/'tests/compute_provider_cuda/gather_collectives_test.cc'),'/Fo'+str(OUT/'checked-gather-tests.obj')]
    b.run('checked-gather-tests-compile',command)

def test(name):
    command=successful(OUT,name+'-link')
    directories=[str(Path(v).parent)for v in command if v.endswith('.lib')and Path(v).is_absolute()]
    directories += ['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64',
        'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',str(ROOT/'.scratch/build-compute-v2-dev/bin')]
    # The shared run helper constructs its environment from this process.
    os.environ['PATH']=os.pathsep.join(dict.fromkeys(directories))+os.pathsep+os.environ['PATH']
    args=[str(OUT/(name+'.exe'))]
    if name=='checked-gather':args+=['--gtest_color=no','--gtest_filter=CudaCcclGather.CheckedFailurePreservesAllOutputAndFreshSlotRecovers:CudaCcclGather.CheckedSubmitStaysPendingBehindProducerAndReportsDeviceError']
    b.run(name+'-run',args,timeout=60)

if __name__=='__main__':
    if sys.argv[1]=='compile':compile_recipes('--resume'in sys.argv,
        [arg.split('=',1)[1]for arg in sys.argv if arg.startswith('--skip=')])
    elif sys.argv[1]=='consumer':compile_consumer()
    elif sys.argv[1]=='expert':compile_expert()
    elif sys.argv[1]=='tensor-header':compile_tensor_header_only()
    elif sys.argv[1]=='link':expert_link()
    elif sys.argv[1]=='checked-compile':check_compile()
    elif sys.argv[1]=='checked-link':expert_link(True)
    elif sys.argv[1]=='run':test('native-consumer')
    elif sys.argv[1]=='checked-run':test('checked-gather')
    elif sys.argv[1]=='hardware':b.run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
    else:raise ValueError(sys.argv[1])
