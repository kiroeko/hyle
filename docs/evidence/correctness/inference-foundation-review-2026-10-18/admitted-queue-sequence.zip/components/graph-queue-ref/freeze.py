from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
files = [
    'src/graph/plan_state.h', 'src/graph/executable.cc',
    'src/graph/submission.cc', 'src/graph/submission_internal.h',
    'src/graph/execution_source_internal.h', 'src/graph/execution_source.cc',
]
identities, diff = [], []
for name in files:
    source = ROOT / name
    destination = OUT / 'candidate' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(source.read_bytes())
    identities.append(dict(path=name, bytes=source.stat().st_size,
        sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
    diff.extend(difflib.unified_diff(
        (OUT / 'before' / name).read_text().splitlines(keepends=True),
        source.read_text().splitlines(keepends=True),
        fromfile='before/' + name, tofile='candidate/' + name))
(OUT / 'source.diff').write_text(''.join(diff))
(OUT / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
(OUT / 'summary.json').write_text(json.dumps({
    'compiled': False, 'tested': False, 'diff_check': 'passed',
    'changes': [
        'Prepared shared region callbacks receive the admitted QueueSequence directly.',
        'Prepared lanes retain QueueRef actual state, including one reusable cold candidate vector.',
        'Cold candidate refs are dropped on failure; successful validation commits them without allocation.',
        'Cold reservation dedup, replay identity checks and hot aggregate selection use actual Queue identity.',
        'Hot segments begin QueueSequence from retained QueueRef; cursor pending queue borrows the same retained ref.',
        'Real Queue owners are declared before resource payload/workspace/provider slots so they are released last.',
    ],
    'remaining_public_queue_uses': 'Cold transfer properties and capture query use original caller Queue bindings; public submit only validates current handle identity before retained-state progression.',
    'storage': 'sizeof(InvocationState) and existing allocator-backed vector accounting include the extra candidate vector; it is sized once at cold slot creation.',
    'fresh_private_readers': [
        'src/graph/executable.cc', 'src/graph/submission.cc',
        'src/graph/resources.cc', 'src/graph/region_access.cc',
        'src/graph/constant_artifact.cc', 'src/graph_route_cpu_cuda/invocation.cc',
        'tests/graph/region_provider_test.cc',
        'tests/graph/constant_artifact_cache_test.cc',
        'tests/graph/aggregate_native_retirement_test.cc',
    ],
    'coordinator_migration': 'Parent owns the unique CPU+CUDA pending_queue reader and its native wait helper.',
}, indent=2) + '\n')
print(json.dumps(identities, indent=2))
