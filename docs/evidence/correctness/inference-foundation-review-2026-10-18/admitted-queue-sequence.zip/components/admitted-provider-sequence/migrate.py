from pathlib import Path
import difflib
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def main():
    paths = [p for prefix in ('compute_provider_', 'graph_provider_')
             for directory in (ROOT / 'src').iterdir()
             if directory.is_dir() and directory.name.startswith(prefix)
             for p in directory.rglob('*') if p.is_file() and p.suffix in ('.cc', '.cu', '.h')]
    paths += [ROOT / 'src/graph_route_cpu/ggml_region.cc', ROOT / 'src/graph_batch/batch.cc']
    changes = []
    for path in sorted(paths):
        original = path.read_bytes()
        text = original.decode('utf-8')
        if 'shared_submit' not in text and path.name != 'native_batch.cc':
            continue
        selected = text
        if path.parent.name.startswith('compute_provider_'):
            selected = re.sub(r'\bQueue\s*&\s*queue\b', 'detail::QueueSequence &sequence', selected)
            selected = re.sub(r'\bQueue\s*&(?=\s*,)', 'detail::QueueSequence &', selected)
            if path.name == 'flashinfer_provider.cc':
                # query_batch_layout and workspace are cold, non-submitting APIs.
                selected = selected.replace('query_batch_layout(BatchSlot&slot,detail::QueueSequence &sequence,',
                                            'query_batch_layout(BatchSlot&slot,Queue&queue,')
                selected = selected.replace('batch_workspace(void*opaque,detail::QueueSequence &sequence,',
                                            'batch_workspace(void*opaque,Queue&queue,')
                begin = selected.index('detail::EnqueueResult plan_batch_slot(')
                selected = selected[:begin] + selected[begin:].replace('cuda::stream(queue)', 'cuda::stream(sequence)')
            else:
                selected = selected.replace('cuda::stream(queue)', 'cuda::stream(sequence)')
            selected = re.sub(r'(acquire_device_status\()queue\b', r'\1sequence', selected)
            if path.name == 'native_batch.cc':
                selected = selected.replace('request->invocation, queue, views', 'request->invocation, sequence, views')
        elif path.name == 'batch.cc':
            selected = selected.replace('c::Queue&queue,std::span', 'cd::QueueSequence&sequence,std::span')
            selected = selected.replace('BatchGraphAccess::enqueue(s.token,queue,', 'BatchGraphAccess::enqueue(s.token,sequence,')
        else:
            selected = selected.replace('compute::Queue &queue,', 'compute::detail::QueueSequence &sequence,')
            selected = re.sub(r'(?<!::)\bQueue &queue,', 'compute::detail::QueueSequence &sequence,', selected)
            selected = selected.replace('queue, inputs, outputs', 'sequence, inputs, outputs')
            selected = selected.replace('invocation, queue,', 'invocation, sequence,')
            selected = selected.replace('using compute::Queue;\r\n', '').replace('using compute::Queue;\n', '')
        if selected == text:
            continue
        name = path.relative_to(ROOT).as_posix()
        before = OUT / 'before' / name
        assert not before.exists(), ('refuse replacing before source', name)
        changes.append((path, before, name, original, selected.encode('utf-8')))
    assert len(changes) == 31, len(changes)
    manifest = []
    delta = []
    for path, before, name, original, selected in changes:
        before.parent.mkdir(parents=True, exist_ok=True)
        before.write_bytes(original)
        path.write_bytes(selected)
        manifest.append(dict(path=name, before_sha256=hashlib.sha256(original).hexdigest(),
                             sha256=hashlib.sha256(selected).hexdigest()))
        delta.extend(difflib.unified_diff(original.decode().splitlines(keepends=True), selected.decode().splitlines(keepends=True),
                                         fromfile='before/' + name, tofile=name))
    (OUT / 'source-identities.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (OUT / 'source.diff').write_text(''.join(delta))
    print(json.dumps(dict(changed_files=len(changes), delta_lines=len(delta))))


if __name__ == '__main__':
    main()
