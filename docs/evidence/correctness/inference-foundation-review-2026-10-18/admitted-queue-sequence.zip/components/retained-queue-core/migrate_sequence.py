from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[3]
path = ROOT / 'src/compute/device.cc'
source = path.read_text(encoding='utf-8')
start = source.index('detail::QueueSequence::QueueSequence(QueueSequence &&other) noexcept')
tail = re.sub(r'\bqueue_\b', 'state_', source[start:])
begin = tail.index('Result<detail::QueueSequence>\ndetail::QueueSequence::begin(Queue &queue) noexcept {')
end = tail.index('Result<detail::QueueDependencyRoute>', begin)
tail = tail[:begin] + '''Result<detail::QueueSequence>
detail::QueueSequence::begin(Queue &queue) noexcept {
  return begin(ContextAccess::state(queue));
}

Result<detail::QueueSequence>
detail::QueueSequence::begin(const QueueRef &queue) noexcept {
  return begin(ContextAccess::state(queue));
}

Result<detail::QueueSequence>
detail::QueueSequence::begin(QueueState *state) noexcept {
  if (!state)
    return std::unexpected(Status::FailedPrecondition("queue is invalid"));
  // Hold the actual state through admission, command recording and finish.
  // A public Queue may move or close without replacing this sequence's owner.
  detail::retain(state);
  Status status = state->begin_submission();
  if (!status.ok()) {
    detail::release(state);
    return std::unexpected(std::move(status));
  }
  void *backend_sequence = nullptr;
  status = state->context->backend_vtable->begin_sequence(state->backend_state,
                                                        &backend_sequence);
  if (!status.ok()) {
    state->end_submission();
    detail::release(state);
    return std::unexpected(std::move(status));
  }
  return QueueSequence(state, backend_sequence);
}

''' + tail[end:]

old = '''detail::QueueSequence::dependency_route(const Queue &destination,
                                        const Queue &source) noexcept {
  detail::QueueState *destination_state =
      detail::ContextAccess::state(destination);
  detail::QueueState *source_state = detail::ContextAccess::state(source);
'''
new = '''detail::QueueSequence::dependency_route(const Queue &destination,
                                        const Queue &source) noexcept {
  return dependency_route(ContextAccess::state(destination), ContextAccess::state(source));
}

Result<detail::QueueDependencyRoute>
detail::QueueSequence::dependency_route(const QueueRef &destination,
                                        const QueueRef &source) noexcept {
  return dependency_route(ContextAccess::state(destination), ContextAccess::state(source));
}

Result<detail::QueueDependencyRoute>
detail::QueueSequence::dependency_route(QueueState *destination_state,
                                        QueueState *source_state) noexcept {
'''
assert tail.count(old) == 1
tail = tail.replace(old, new, 1)
tail = tail.replace('if (!destination.is_open() || !source.is_open()) {',
    '''if (!destination_state->admission.is_open() ||
      !destination_state->context->admission.is_open() ||
      !source_state->admission.is_open() || !source_state->context->admission.is_open()) {''', 1)

old = '''detail::QueueSequence::completion_endpoint(const Queue &queue) noexcept {
  detail::QueueState *state = detail::ContextAccess::state(queue);
  if (state == nullptr || !queue.is_open()) {'''
new = '''detail::QueueSequence::completion_endpoint(const Queue &queue) noexcept {
  return completion_endpoint(ContextAccess::state(queue));
}

Result<detail::CompletionEndpoint>
detail::QueueSequence::completion_endpoint(const QueueRef &queue) noexcept {
  return completion_endpoint(ContextAccess::state(queue));
}

Result<detail::CompletionEndpoint>
detail::QueueSequence::completion_endpoint(QueueState *state) noexcept {
  if (state == nullptr || !state->admission.is_open() ||
      !state->context->admission.is_open()) {'''
assert tail.count(old) == 1
tail = tail.replace(old, new, 1)

old = '''detail::QueueSequence::can_import_endpoint(const Queue &destination,
                                           CompletionEndpoint source) noexcept {
  detail::QueueState *state = detail::ContextAccess::state(destination);
  if (state == nullptr || !destination.is_open()) {'''
new = '''detail::QueueSequence::can_import_endpoint(const Queue &destination,
                                           CompletionEndpoint source) noexcept {
  return can_import_endpoint(ContextAccess::state(destination), source);
}

Result<bool>
detail::QueueSequence::can_import_endpoint(const QueueRef &destination,
                                           CompletionEndpoint source) noexcept {
  return can_import_endpoint(ContextAccess::state(destination), source);
}

Result<bool>
detail::QueueSequence::can_import_endpoint(QueueState *state,
                                           CompletionEndpoint source) noexcept {
  if (state == nullptr || !state->admission.is_open() ||
      !state->context->admission.is_open()) {'''
assert tail.count(old) == 1
tail = tail.replace(old, new, 1)

tail = tail.replace('detail::QueueState *state = detail::ContextAccess::state(*state_);',
                    'detail::QueueState *state = state_;', 1)
tail = tail.replace('auto *state = detail::ContextAccess::state(*state_);',
                    'auto *state = state_;', 1)
old = '''  Queue *queue = state_;
  detail::QueueState *state = detail::ContextAccess::state(*queue);'''
assert tail.count(old) == 1
tail = tail.replace(old, '  detail::QueueState *state = state_;', 1)
tail = tail.replace('  queue->end_submission();',
                    '  state->end_submission();\n  detail::release(state);', 1)
assert 'sequence.queue()' not in tail
assert 'ContextAccess::state(*state_)' not in tail
path.write_text(source[:start] + tail, encoding='utf-8', newline='\n')
