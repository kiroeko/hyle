from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
files = ['src/compute/device.cc', 'src/compute/context_state.h',
    'include/hyle/compute/device.h', 'include/hyle/compute/detail/context_ref.h',
    'include/hyle/compute/detail/queue_ref.h',
    'include/hyle/compute/detail/queue_sequence.h',
    'include/hyle/compute/detail/backend_extension.h',
    'include/hyle/compute/detail/provider_extension.h',
    'tests/compute/device_test.cc', 'tests/graph/executable_test.cc']
identities, diff = [], []
for relative in files:
    path = ROOT / relative
    data = path.read_bytes()
    target = OUT / 'candidate' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    identities.append(dict(path=relative, bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest()))
    previous = OUT / 'before' / relative
    diff.extend(difflib.unified_diff(
        previous.read_text().splitlines(True) if previous.exists() else [],
        path.read_text().splitlines(True), fromfile='before/' + relative,
        tofile=relative))
(OUT / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n',
    encoding='utf-8', newline='\n')
(OUT / 'source.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
