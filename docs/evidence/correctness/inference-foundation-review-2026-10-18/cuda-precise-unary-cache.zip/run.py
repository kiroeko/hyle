from pathlib import Path
import ctypes, hashlib, importlib.util, json, os, shutil, subprocess, sys, time
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
RAW=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
LEGACY=R/'.scratch/legacy-root/hyle-scratch/ggml-native-static'
source=O/'source';source.mkdir(parents=True,exist_ok=True)
manifest=json.loads((R/'third_party/ggml_cuda_runtime/patches.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
for entry in manifest['files']:
    raw=(RAW/entry['path']).read_bytes().replace(b'\r\n',b'\n')
    assert sha(raw)==entry['before_sha256']
    for edit in entry['edits']:
        before,after=edit['before'].encode(),edit['after'].encode();assert raw.count(before)==1;raw=raw.replace(before,after,1)
    assert sha(raw)==entry['after_sha256']
    (source/Path(entry['path']).name).write_bytes(raw)
for name in ['unary.cu','unary.cuh','convert.cuh']:
    shutil.copyfile(RAW/'src/ggml-cuda'/name,source/name)
db=json.loads((LEGACY/'compile_commands.json').read_text())
row=next(x for x in db if x['file'].endswith('/unary.cu'))
argc=ctypes.c_int();parse=ctypes.windll.shell32.CommandLineToArgvW
parse.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
parse.restype=ctypes.POINTER(ctypes.c_wchar_p)
argv=parse(row['command'],ctypes.byref(argc));args=[argv[i]for i in range(argc.value)]
ctypes.windll.kernel32.LocalFree(ctypes.cast(argv,ctypes.c_void_p))
old_prefix='C:\\hyle-scratch\\ggml-native-static'
args=[a.replace(old_prefix,str(LEGACY))for a in args]
command=[];skip=False
for a in args:
    if skip:skip=False;continue
    if a=='-o':skip=True;continue
    if a=='-use_fast_math' or a.startswith('-Xcompiler=-Fd') or a.replace('\\','/').endswith('/unary.cu'):continue
    command.append(a)
command+=['-I'+str(LEGACY/'src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src/ggml-cuda'),str(source/'unary.cu'),'-o',str(O/'unary-precise.obj')]
assert not any('fast_math'in a or a.startswith(('--ftz','-ftz'))for a in command)
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
CL='C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':CL,'CMAKE_C_COMPILER':CL});env['VSLANG']='1033'
start=time.monotonic();p=subprocess.run(command,cwd=O,env=env,capture_output=True,timeout=180)
(O/'compile.stdout.log').write_bytes(p.stdout);(O/'compile.stderr.log').write_bytes(p.stderr)
(O/'compile-command.json').write_text(json.dumps(dict(command=command,cwd=str(O),exit=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n')
(O/'legacy-command.json').write_text(json.dumps(row,indent=2)+'\n')
print(p.returncode,p.stdout.decode(errors='replace')[-3000:],p.stderr.decode(errors='replace')[-3000:],flush=True)
p.check_returncode()
obj=O/'unary-precise.obj'
(O/'identity.json').write_text(json.dumps(dict(object=str(obj),bytes=obj.stat().st_size,sha256=sha(obj.read_bytes()),source_sha256=sha((source/'unary.cu').read_bytes()),common_sha256=sha((source/'common.cuh').read_bytes()),canonical_flags='Existing canonical CMake removes -use_fast_math for unary only; this compilation uses original unary source and same strict-dispatch headers with that removal. No product source/manifest change.',legacy_flags='Cached native lib original compdb uses -use_fast_math; not canonical current build behavior.'),indent=2)+'\n')
print((O/'identity.json').read_text(),flush=True)
