from pathlib import Path
import importlib.util,sys,json
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements'
spec=importlib.util.spec_from_file_location('r',OUT/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import link_run as old
flags=r.flags+['/I'+str(ROOT/'src/compute_route_cuda')]
r.r.compile(OUT/'default_probe.cc','default-probe',r.r.cuda.cl,flags,r.r.cuda.env)
r.r.compile('src/graph_route_cuda/cuda_context.cc','graph-default-context',r.r.cuda.cl,flags,r.r.cuda.env)
base=ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch';mla=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla'
replace={base/'public-consumer.obj':OUT/'default-probe.obj',base/'flashinfer-provider.obj':mla/'flashinfer-provider.obj',base/'batch-execution.obj':mla/'batch-execution.obj',base/'graph-batch.obj':mla/'graph-batch.obj'}
replace.update({ROOT/'.scratch/mtp-completion'/(s+'.obj'):OUT/(s+'.obj') for s in ['provider','tensor','region']})
objects=[replace.get(p,p) for p in old.objects]
objects += [OUT/'graph-default-context.obj',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices/guard.obj']
objects += [mla/p for p in ['batch-layout.obj','paged-arena.obj','native_mla.obj']]+[base/'highdim-review/native_highdim.obj']
for p in [*objects,*old.libs]:assert p.is_file(),p
exe=OUT/'default-probe.exe'
r.r.run('default-link',[r.r.cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/'default-probe.map'),*objects,*old.libs,r.r.cuda.BASE/'lib/gtest_main.lib',r.r.cuda.BASE/'lib/gtest.lib',*old.system],old.b.env)
r.r.run('default-test',[exe,'--gtest_filter=CudaDefaultGatherElements.DeviceTopKFeedsPerRowSelectionAndNegative','--gtest_color=no'],old.b.env)
