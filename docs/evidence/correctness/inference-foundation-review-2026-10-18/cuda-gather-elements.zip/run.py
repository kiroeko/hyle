from pathlib import Path
import importlib.util,json,sys
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements'
spec=importlib.util.spec_from_file_location('dense_runner',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/dense-constants/run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.OUT=OUT;r.records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
flags=r.cuda.flags+['/I'+str(ROOT)]
def build():
    source=(ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc').read_text()
    for codec in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
        assert source.count('return GGML_TYPE_'+codec+';')==1
        source=source.replace('return GGML_TYPE_'+codec+';','return GGML_TYPE_COUNT; // Validation-only: legacy native lacks this unrelated IQ1 codec.')
    p=OUT/'tensor_program.probe.cc';p.write_bytes(source.encode())
    for source,stem in [('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','provider'),('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','region'),(p,'tensor'),('tests/compute_provider_ggml_cuda/tensor_test.cc','direct-tests'),('tests/graph_provider_ggml_cuda/region_test.cc','graph-tests')]:
        r.compile(source,stem,r.cuda.cl,flags,r.cuda.env)
    link()
def link():
    common=[OUT/'provider.obj',OUT/'tensor.obj',OUT/'region.obj',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices/guard.obj',ROOT/'.scratch/mtp-completion/operation.obj',r.cuda.OLD/'ggml-cuda.strict.obj']
    for stem in ['direct','graph']:
        r.run(stem+'-link',[r.cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/(stem+'.exe')),'/MAP:'+str(OUT/(stem+'.map')),OUT/(stem+'-tests.obj'),*common,*r.cuda.libs,r.cuda.BASE/'lib/gtest_main.lib',r.cuda.BASE/'lib/gtest.lib',*r.cuda.system],r.cuda.env)
def test():
    filters={'direct':'GgmlCudaTensor.GatherElementsUsesPerRowIdsAndPreservesDtypeAndBounds:GgmlCudaTensor.CheckedExpertIdsKeepOutputAndAllowRecreatedInvocationRetry:GgmlCudaTensor.DenseBfloatGroupedExpertsUseNativeMulMatIdAndReplay',
             'graph':'GgmlCudaGraph.GatherElementsAndNegativeShareLinearPerRowResults:GgmlCudaGraph.CheckedIdsKeepEveryPublishedOutputAndOtherConsumersIntact:GgmlCudaGraph.SingleBfloatExpertConstantPacksOnceAndDynamicWeightRemainsRebindable:GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable:GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs'}
    for stem,filt in filters.items():r.run(stem+'-tests',[OUT/(stem+'.exe'),'--gtest_filter='+filt,'--gtest_color=no'],r.cuda.env)
if __name__=='__main__':{'build':build,'link':link,'test':test}[sys.argv[1]]()
