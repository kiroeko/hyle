#include "tests/compute_provider_ggml_cuda/tensor_test_support.h"
#include "hyle/graph/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/providers/cuda.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include <iostream>

TEST(CudaDefaultGatherElements, DeviceTopKFeedsPerRowSelectionAndNegative) {
  using namespace ggml_cuda_tensor_test;
  namespace graph = hyle::graph;
  auto context = graph::cuda::create_context().value();
  auto memory = cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
  const auto scores_desc = dense(DataType::kFloat32, {3,5});
  const auto ids_desc = dense(DataType::kInt32, {3,2});
  const auto out_desc = dense(DataType::kFloat32, {3,2});
  const std::array<float,15> scores{-0.75F, 0.125F, 0.5F, -1.5F, 0.25F,
      2.0F, 0.0F, 1.0F, -0.5F, 1.5F, -2.0F, -1.0F, 0.25F, 0.0F, 0.5F};
  auto input = upload<float>(memory.ref(), scores);
  auto indices = output_buffer(memory.ref(),ids_desc);
  auto selected = output_buffer(memory.ref(),out_desc), negative = output_buffer(memory.ref(),out_desc);
  auto builder = graph::GraphBuilder::create().value();
  const auto x = builder.input(scores_desc).value();
  const auto top = builder.add_node(Operation(TopK{.count=2}),std::array{x}).value();
  const auto ids = builder.result(top,1).value();
  const auto values = builder.result(builder.add_node(
      model_ops::gather_elements(-1,IndexBoundsPolicy::kUnchecked),std::array{x,ids}).value()).value();
  const auto neg = builder.add(Unary{UnaryKind::kNeg},values).value();
  for(const auto value:{ids,values,neg}) ASSERT_TRUE(builder.publish(value).ok());
  const auto logical = std::move(builder).finish().value();
  auto compiled=graph::cuda::compile(logical,context,memory.ref());
  ASSERT_TRUE(compiled)<<compiled.error().message();
  std::cout<<"default_provider_count="<<context.provider_count()<<" steps="<<compiled->report.step_count()<<"\n";
  bool cccl=false,ggml=false;
  for(std::size_t i=0;i<compiled->report.step_count();++i) {
    const auto step=compiled->report.step(i).value();
    std::cout<<"step="<<i<<" provider="<<step.provider.name<<" version="<<step.provider.version<<"\n";
    cccl|=step.provider.id==cuda_native::kCcclProviderId;
    ggml|=step.provider.id==ggml_cuda::kProviderId;
  }
  EXPECT_TRUE(cccl);EXPECT_TRUE(ggml);
  auto call=compiled->executable.create_invocation().value();auto queue=context.create_queue().value();
  ASSERT_TRUE(call.bind(x,ConstTensorView::create(scores_desc,input.view()).value()).ok());
  ASSERT_TRUE(call.bind(ids,TensorView::create(ids_desc,indices.view()).value()).ok());
  ASSERT_TRUE(call.bind(values,TensorView::create(out_desc,selected.view()).value()).ok());
  ASSERT_TRUE(call.bind(neg,TensorView::create(out_desc,negative.view()).value()).ok());
  const auto ready=graph::cuda::prepare_replay(call,queue);ASSERT_TRUE(ready.ok())<<ready.message();
  auto done=call.submit(queue);ASSERT_TRUE(done)<<done.error().message();
  ASSERT_TRUE(done->wait().ok());
  const auto actual_ids=half_test::read<std::int32_t>(indices);
  const auto actual=half_test::read<float>(selected),inverted=half_test::read<float>(negative);
  const std::array<std::int32_t,6> expected_ids{2,4,0,4,4,2};
  ASSERT_EQ(actual.size(),expected_ids.size());
  for(std::size_t i=0;i<expected_ids.size();++i) {
    EXPECT_EQ(actual_ids[i],expected_ids[i]);
    const auto expected=scores[(i/2)*5+std::size_t(expected_ids[i])];
    EXPECT_EQ(actual[i],expected);EXPECT_EQ(inverted[i],-expected);
  }
}
