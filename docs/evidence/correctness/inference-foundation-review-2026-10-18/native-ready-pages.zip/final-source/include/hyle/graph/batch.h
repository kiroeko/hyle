#pragma once
#include "hyle/graph/executable.h"
#include "hyle/compute/batch_execution.h"
#include "hyle/compute/batch_materialize.h"
#include "hyle/compute/batch_paged_native.h"
#include "hyle/compute/paged_arena.h"
#include <array>
#include <cstdint>
#include <string_view>

namespace hyle::graph::batch {
struct NodeLayout final {NodeId node;compute::BatchLayoutVersion layout;};
// Cold native planning uses this same ordinary Graph invocation. Geometry and
// attention mathematics come from the typed node; these are resource limits,
// never a second copy of scale/causal/window/precision policy.
struct PrepareOptions final {
  mem::MemoryResourceRef host_workspace = mem::system_resource();
  std::size_t max_float_workspace_bytes = 64u * 1024u * 1024u;
  std::size_t max_int_workspace_bytes = 8u * 1024u * 1024u;
  mem::AllocatorRef allocator = mem::system_allocator();
  compute::ResourceBudget resource_budget{};
  bool update = true;
  // Producer plus accepted copy phases; zero keeps pending controls absent.
  std::size_t max_source_completions = 0;
};
HYLE_GRAPH_BATCH_API Status prepare(graph::Invocation &,
    std::span<const QueueBinding>, std::span<const NodeLayout>,
    PrepareOptions = {}) noexcept;
HYLE_GRAPH_BATCH_API Result<compute::BatchPlanReport> report(
    graph::Invocation &, NodeId) noexcept;
HYLE_GRAPH_BATCH_API Result<compute::NativePagedBatchReport> native_report(
    graph::Invocation &, NodeId) noexcept;
// Optional cold capture inside the already selected native slots. Bind every
// ordinary tensor first; the enclosing Invocation still owns replay/submit.
HYLE_GRAPH_BATCH_API Status prepare_replay(graph::Invocation &,
    std::span<const QueueBinding>) noexcept;
namespace detail {struct RowCacheAccess;}
// A small macro over two original ordinary Graph nodes: private request/page
// address translation followed by the existing checked row codec. IDs may be
// produced on device (for example by TopK). Only its typed preparation may
// bind the truthful physical capacity and owned metadata input.
class PagedRowCacheGather final {
public:
  PagedRowCacheGather()noexcept=default;
  bool valid()const noexcept{return schema_.valid() && decode_.valid();}
  ValueId bank_input()const noexcept{return bank_;}
  ValueId output()const noexcept{return output_;}
  NodeId node()const noexcept{return decode_;}
  compute::RowCacheBatchSchema schema()const noexcept{return schema_;}
private:
  friend struct detail::RowCacheAccess;
  friend Result<PagedRowCacheGather> add_row_cache_gather(GraphBuilder&,compute::RowCacheBatchSchema,ValueId)noexcept;
  compute::RowCacheBatchSchema schema_;
  NodeId map_,decode_;ValueId bank_,metadata_,ids_,mapped_,output_;
};
HYLE_GRAPH_BATCH_API Result<PagedRowCacheGather> add_row_cache_gather(
    GraphBuilder&,compute::RowCacheBatchSchema,ValueId logical_ids)noexcept;
// Padding-aware macro: only -1 or a legal score column outside its query's
// request-local [begin,end) becomes padding. It returns a 0/-Inf mask along
// with selected BF16 rows. Invalid columns/ranges/metadata still fail checked
// decode. Include reader() in the original invocation's row binding set.
class PagedRowCacheGatherPadded final {
public:
  bool valid()const noexcept{return reader_.valid();}
  const PagedRowCacheGather& reader()const noexcept{return reader_;}
  ValueId bank_input()const noexcept{return reader_.bank_input();}
  ValueId output()const noexcept{return reader_.output();}
  ValueId mask()const noexcept{return mask_;}
  NodeId node()const noexcept{return reader_.node();}
private:
  friend struct detail::RowCacheAccess;
  friend Result<PagedRowCacheGatherPadded> add_row_cache_gather_padded(GraphBuilder&,compute::RowCacheBatchSchema,ValueId,ValueId,std::uint32_t)noexcept;
  PagedRowCacheGather reader_;ValueId mask_;
};
HYLE_GRAPH_BATCH_API Result<PagedRowCacheGatherPadded> add_row_cache_gather_padded(
    GraphBuilder&,compute::RowCacheBatchSchema,ValueId logical_ids,ValueId ranges,std::uint32_t score_columns)noexcept;
// Bounded-tile FP4 row-inline scoring over exact typed page permissions.
// Five original ordinary-node ports are Q/physical bank/weights/ranges/owned
// metadata. Q/weights and rounding match RowCacheIndexerScores. Output [T,C]
// columns and ranges are request-local logical rows; C is a static score width
// covering each active request history, not a tile option or physical capacity.
class PagedRowCacheIndexer final {
public:
  bool valid()const noexcept{return reader_.valid();}
  ValueId bank_input()const noexcept{return reader_.bank_input();}
  ValueId output()const noexcept{return reader_.output();}
  NodeId node()const noexcept{return reader_.node();}
  const PagedRowCacheGather& reader()const noexcept{return reader_;}
  compute::RowCacheBatchSchema schema()const noexcept{return reader_.schema();}
private:
  friend struct detail::RowCacheAccess;
  friend Result<PagedRowCacheIndexer> add_row_cache_indexer(GraphBuilder&,compute::RowCacheBatchSchema,ValueId,ValueId,ValueId,std::uint32_t)noexcept;
  PagedRowCacheGather reader_;
};
HYLE_GRAPH_BATCH_API Result<PagedRowCacheIndexer> add_row_cache_indexer(
    GraphBuilder&,compute::RowCacheBatchSchema,ValueId query,ValueId weights,ValueId ranges,std::uint32_t score_columns)noexcept;
// As with the original Builder calls, a failure may follow successful input/
// node appends. Recreate the builder before retrying a failed macro.
struct RowCacheBinding final {
  PagedRowCacheGather reader;
  compute::RowCacheLayoutVersion layout;
};
// The immutable source is borrowed only for cold macro/private-port validation.
HYLE_GRAPH_BATCH_API Status prepare(graph::Invocation &, const Graph &,
    std::span<const QueueBinding>, std::span<const NodeLayout>,
    std::span<const RowCacheBinding>, PrepareOptions = {}) noexcept;
HYLE_GRAPH_BATCH_API Status bind(graph::Invocation &, ValueId, compute::PagedArenaRead) noexcept;
HYLE_GRAPH_BATCH_API Status bind(graph::Invocation &, ValueId, compute::PagedArenaPendingRead) noexcept;
HYLE_GRAPH_BATCH_API Status bind(graph::Invocation &, ValueId, compute::PagedRowCacheRead) noexcept;
HYLE_GRAPH_BATCH_API Status bind(graph::Invocation &, ValueId, compute::PagedRowCachePendingRead) noexcept;
// One source joins the original Graph queue sequence and public completion.
// Before acceptance, failure returns Update to its caller; accepted prefixes
// retain their true source controls and resource owners through retirement.
HYLE_GRAPH_BATCH_API Result<compute::Completion> submit(graph::Invocation &,
    std::span<const QueueBinding>, compute::CopyBatchUpdate &&) noexcept;
HYLE_GRAPH_BATCH_API Result<compute::CopyBatchUpdate> take_update(graph::Invocation &) noexcept;
// Owned cold recipe and initial layout of an ordinary Graph node. Explicit
// layout updates stay on the original Invocation; page permissions are bound
// separately. No raw tensor port authorizes reading an arena's full capacity.
struct NativePagedOptions final {
  // Optional per-node cap. The fixed recipe determines actual allocation;
  // the original Graph budget and slot allocator apply to every backing.
  std::size_t max_metadata_backing_bytes = SIZE_MAX;
};
struct NativePagedAttention final {
  compute::NativePagedBatchProgram program;
  compute::BatchLayoutVersion layout;
  NativePagedOptions options;
  static constexpr compute::OperationId operation_id{
      0x48594c4547524241ULL, 0x4e41544956455002ULL};
  static constexpr std::string_view operation_name = "native-paged-graph-attention";
  constexpr compute::OperationTraits operation_traits() const noexcept {
    return {{3,3},1,compute::AliasPolicy::kNone,compute::EffectKind::kPure,
            compute::PrecisionPolicy::kExact,compute::DataType::kFloat32};
  }
  HYLE_GRAPH_BATCH_API Status infer_output_descriptions(
      std::span<const compute::TensorDesc>,std::span<compute::TensorDesc>) const noexcept;
};
static_assert(compute::detail::InlineCustomOperationDescriptor<NativePagedAttention>);
HYLE_GRAPH_BATCH_API Result<NativePagedAttention> native_paged_attention(
    const compute::NativePagedBatchProgram&,compute::BatchLayoutVersion,
    NativePagedOptions = {}) noexcept;
struct NativePagedMlaAttention final {
  compute::NativePagedBatchProgram program;
  compute::BatchLayoutVersion layout;
  NativePagedOptions options;
  static constexpr compute::OperationId operation_id{0x48594c4547524241ULL,0x4e41544956454d02ULL};
  static constexpr std::string_view operation_name="native-paged-graph-mla";
  constexpr compute::OperationTraits operation_traits()const noexcept{
    return {{2,2},1,compute::AliasPolicy::kNone,compute::EffectKind::kPure,
        compute::PrecisionPolicy::kExact,compute::DataType::kFloat32};
  }
  HYLE_GRAPH_BATCH_API Status infer_output_descriptions(
      std::span<const compute::TensorDesc>,std::span<compute::TensorDesc>)const noexcept;
};
static_assert(compute::detail::InlineCustomOperationDescriptor<NativePagedMlaAttention>);
HYLE_GRAPH_BATCH_API Result<NativePagedMlaAttention> native_paged_mla_attention(
    const compute::NativePagedBatchProgram&,compute::BatchLayoutVersion,
    NativePagedOptions = {})noexcept;
// Borrowed only by compile; the immutable joint plan copies these owners.
// Allocator/budget and native resources retain their original lifetime rules.
// Another active-Q output shape requires the original exact variant/compile.
struct NativePagedNodeBinding final {
  NodeId node;
  compute::NativePagedBatchProgram program;
  compute::BatchLayoutVersion layout;
  compute::NativePagedInvocationOptions options;
};
struct MaterializedGraph final {
  Graph graph;
  std::array<ValueId,5> inputs{};
  ValueId output;
};
// Explicitly selected reference recipe over the original ordinary Graph.
// Native route compile/prepare still qualifies each operation and its cost.
// Bind owned same-version indices/mask; upload them with original F2 first.
HYLE_GRAPH_BATCH_API Result<MaterializedGraph> materialized_graph(
    const compute::MaterializedBatchProgram&,GraphBuilderOptions = {}) noexcept;
namespace detail {struct MaterializedInvocationData;}
struct MaterializedInvocationOptions final {
  // One cold output backing, including alignment padding; explicit byte cap.
  std::size_t max_output_bytes=0;
  CompileOptions compile{};
  ResourceOptions resources{};
};
// Host/system-memory reference over the original shared-Queue Graph. Owns the
// fixed recipe/compiled graph, exact metadata generation and one output slot.
// Native GPU reference uses its own typed resources and preparation contract.
// Control is thread-compatible. Borrowed Context/Queue and injected allocators
// outlive native work/results; readonly metadata and output leases retain their
// original owners. Independent controllers have separate compiled slots.
class MaterializedInvocation final {
public:
  MaterializedInvocation()noexcept=default;
  MaterializedInvocation(const MaterializedInvocation&)=delete;
  MaterializedInvocation&operator=(const MaterializedInvocation&)=delete;
  HYLE_GRAPH_BATCH_API MaterializedInvocation(MaterializedInvocation&&)noexcept;
  HYLE_GRAPH_BATCH_API MaterializedInvocation&operator=(MaterializedInvocation&&)noexcept;
  HYLE_GRAPH_BATCH_API ~MaterializedInvocation();
  HYLE_GRAPH_BATCH_API static Result<MaterializedInvocation> create(
      const compute::Context&,compute::MaterializedBatchProgram,compute::Queue&,
      MaterializedInvocationOptions)noexcept;
  bool valid()const noexcept{return data_!=nullptr;}
  // Explicit update boundary. Old results/completions/storage/native reads
  // prevent output reuse. Repeated prepare before execution is supported.
  HYLE_GRAPH_BATCH_API Status prepare_batch(compute::BatchLayoutVersion)noexcept;
  HYLE_GRAPH_BATCH_API Status bind(compute::ReadLease query,compute::PagedArenaRead keys,
      compute::PagedArenaRead values)noexcept;
  HYLE_GRAPH_BATCH_API Status bind(compute::ReadLease query,compute::ReadLease keys,
      compute::ReadLease values)noexcept;
  // Consumes this prepared episode; each subsequent run needs prepare/bind.
  HYLE_GRAPH_BATCH_API Result<compute::Completion> submit()noexcept;
  HYLE_GRAPH_BATCH_API Result<GraphOutput> output()noexcept;
  HYLE_GRAPH_BATCH_API compute::MaterializedBatchVersion version()const noexcept;
  HYLE_GRAPH_BATCH_API Status close()noexcept;
  HYLE_GRAPH_BATCH_API Status drain()noexcept;
private:
  explicit MaterializedInvocation(detail::MaterializedInvocationData*p)noexcept:data_(p){}
  detail::MaterializedInvocationData*data_=nullptr;
};
} // namespace hyle::graph::batch
