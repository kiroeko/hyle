from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,os,subprocess,sys,threading,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def src(command):return next((x for x in command if x.lower().endswith(('.cc','.cpp','.c','.mm'))),None)
def obj(command):return next((x[3:] for x in command if x.lower().startswith('/fo')),None)
def command_for(command,source,stem):
 args=[x for x in command if not x.lower().startswith(('/fo','/fd')) and x!='/FS'
       and not x.lower().endswith(('.cc','.cpp','.c','.mm'))]
 if not any(x.lower()=='/wx' for x in args):args.append('/WX')
 return args+[str(ROOT/source),'/Fo'+str(OUT/(stem+'.obj'))]

def plan():
 rows={}
 for row in read(OUT/'matched-object-recipes.json'):
  source=row.get('canonical_source')
  if source and source.startswith('src/'):
   rows[source]=dict(source=source,original=row['command'],origin=row['origin'])
 for row in read(OUT/'additional-archive-owners.json'):
  if row['source'] not in rows and row['recipes']:
   recipe=row['recipes'][0]
   rows[row['source']]=dict(source=row['source'],original=recipe['command'],origin=recipe['origin'])
 # Current schema overlays already passed with the final ownership header.
 reuse={}
 for row in read(ARCH/'native-ready-pages/schema/commands.json'):
  if row['exit']!=0 or not row['tag'].endswith('-compile'):continue
  source=src(row['command']);target=obj(row['command'])
  if not source or not target:continue
  source=Path(source).relative_to(ROOT).as_posix()
  after={x['path']:x for x in row.get('after',[])}
  current=after.get(str(ROOT/source))
  if current and current['sha256']==sha(ROOT/source):
   reuse[source]=dict(source=source,object=identity(target),origin='native-ready-pages/schema/'+row['tag'])
 for path in sorted((ARCH/'native-paged-region/vulkan').glob('*-identity.json')):
  row=read(path)
  source=Path(row['source']).relative_to(ROOT).as_posix()
  if row['source_sha256']==sha(ROOT/source):
   reuse[source]=dict(source=source,object=identity(row['object']),origin=str(path))
 pending={'src/compute_route_vulkan/vulkan_batch.cc',
          'src/graph_route_vulkan/native_paged_region.cc'}
 for i,row in enumerate(rows.values()):
  stem=row['source'].removeprefix('src/').replace('/','--').removesuffix('.cc')
  row['stem']=stem
  row['command']=command_for(row.pop('original'),row['source'],stem)
  row['source_sha256']=sha(ROOT/row['source'])
  if row['source'] in reuse:row['reuse']=reuse[row['source']]
  row['pending_backend']=row['source'] in pending and row['source'] not in reuse
 write('compile-plan.json',list(rows.values()))
 write('reused-objects.json',list(reuse.values()))
 return list(rows.values())

lock=threading.Lock()
def run(tag,command,timeout=180):
 command=list(map(str,command))
 with lock:
  records=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
  index=len(records)+1;stem=f'{index:03d}-{tag}'
  row=dict(tag=tag,command=command,exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log')
  records.append(row);write('commands.json',records)
 env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler,'CMAKE_C_COMPILER':compiler})
 env['VSLANG']='1033'
 torch=next((str(Path(x).parent) for x in read(ARCH/'native-inputs/vulkan-consumers/matched-link-base.json')['command']
             if x.lower().endswith('torch_cpu.lib')),None)
 if torch:env['PATH']=torch+os.pathsep+env.get('PATH','')
 t=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout,
   creationflags=subprocess.CREATE_NO_WINDOW)
 (OUT/row['stdout']).write_bytes(p.stdout);(OUT/row['stderr']).write_bytes(p.stderr)
 with lock:
  records=read(OUT/'commands.json');records[index-1].update(exit=p.returncode,seconds=time.monotonic()-t)
  write('commands.json',records)
 print(stem,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-4500:]+p.stderr.decode(errors='replace')[-2000:],flush=True)
 return p.returncode

def compile_one(row):
 path=ROOT/row['source'];before=identity(path)
 headers=[identity(ROOT/n) for n in ['include/hyle/compute/operation.h','src/compute/provider_internal.h',
          'include/hyle/graph/region_provider.h','include/hyle/graph/batch.h']]
 code=run(row['stem']+'-compile',row['command'])
 after=identity(path);unchanged=before==after and all(identity(h['path'])==h for h in headers)
 receipt=dict(source=after,headers=headers,source_unchanged=unchanged,origin=row['origin'],exit=code)
 if code==0:receipt['object']=identity(OUT/(row['stem']+'.obj'))
 write(row['stem']+'-identity.json',receipt)
 if not unchanged:print('SOURCE DRIFT',row['source'],flush=True)
 return code==0 and unchanged

all_plan=plan();compiler=all_plan[0]['command'][0]

def current_objects():
 selected={}
 for row in all_plan:
  if row.get('reuse'):
   selected[row['source']]=row['reuse']['object']['path']
  elif not row['pending_backend']:
   receipt=read(OUT/(row['stem']+'-identity.json'))
   assert receipt['exit']==0 and receipt['source_unchanged']
   assert receipt['source']==identity(ROOT/row['source']),row['source']
   assert all(identity(h['path'])==h for h in receipt['headers']),row['source']
   assert identity(receipt['object']['path'])==receipt['object']
   selected[row['source']]=receipt['object']['path']
 for row in read(OUT/'reused-objects.json'):
  if row['source'].startswith('src/'):
   assert identity(row['object']['path'])==row['object']
   selected[row['source']]=row['object']['path']
 return selected

def link():
 base=read(ARCH/'native-inputs/vulkan-consumers/matched-link-base.json')
 selected=current_objects();objects=[];retained=[]
 for row in read(OUT/'matched-object-recipes.json'):
  source=row.get('canonical_source')
  # Old /Tp row-cache and scratch BlockingPool are actual Hyle owners.
  if Path(row['object']).name=='cpu-codec.obj':source='src/compute_provider_native/row_cache.cc'
  if source:
   assert source in selected,source
   objects.append(selected[source])
  else:
   old=next(x for x in base['objects'] if x['path']==row['object'])
   assert identity(row['object'])==old,row['object']
   objects.append(row['object']);retained.append(old)
 objects.extend(selected.values());objects=list(dict.fromkeys(objects))
 assert not any('cuda' in x.lower() for x in objects)
 libs=[x for x in base['command'] if x.lower().endswith('.lib')]
 assert not any('cpu_vulkan' in x.lower() or 'cpu_cuda' in x.lower() for x in libs)
 flags=[x for x in base['command'][1:] if not x.lower().endswith(('.obj','.lib'))
        and not x.upper().startswith(('/OUT:','/MAP:'))]
 command=[base['command'][0],'/OUT:'+str(OUT/'native-page-ready.exe'),
          '/MAP:'+str(OUT/'native-page-ready.map'),*flags,*objects,*libs]
 write('matched-link-base.json',dict(command=command,objects=[identity(x) for x in objects],
       selected_sources=selected,retained_unchanged=retained,
       scope='Current owned Operation/Provider16/Region26 Hyle hosts; unchanged numerical vendor and generated cache only.'))
 return run('native-page-ready-link',command,120)

def execute():
 return run('native-page-ready-64-causal-run',[OUT/'native-page-ready.exe','64','1'],60)

if __name__=='__main__':
 if sys.argv[1:2]==['compile']:
  subset=sys.argv[2:]
  todo=[r for r in all_plan if not r.get('reuse') and not r['pending_backend']
        and (not subset or any(x in r['source'] for x in subset))]
  # Preserve already successful current owners when a later group is appended.
  selected=[]
  for row in todo:
   p=OUT/(row['stem']+'-identity.json')
   if p.exists():
    old=read(p)
    if old['exit']==0 and old['source_unchanged'] and old['source']==identity(ROOT/row['source']) \
       and all(identity(h['path'])==h for h in old['headers']):continue
   selected.append(row)
  print('compile',len(selected),'reuse',len([r for r in all_plan if r.get('reuse')]),flush=True)
  ok=True
  with ThreadPoolExecutor(max_workers=2) as pool:
   for result in pool.map(compile_one,selected):ok=ok and result
  raise SystemExit(0 if ok else 1)
 elif sys.argv[1:2]==['prepare']:
  print('prepared',len(all_plan),'Hyle sources',flush=True)
 elif sys.argv[1:2]==['link']:raise SystemExit(link())
 elif sys.argv[1:2]==['run']:raise SystemExit(execute())
 else:raise SystemExit('prepare or compile [source substring ...]; no link/run before final backend freeze')
