"""Read-only recipe discovery for the current mixed Vulkan/CPU closure.

No compiler, linker, SDK generator or executable is run by this script.
"""
from pathlib import Path
import hashlib
import json
import shlex

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
BASE=ARCH/'native-inputs/vulkan-consumers'

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(n,v): (OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def key(p): return str(p).replace('/','\\').lower()
def records(value):
    if isinstance(value,list):
        if value and all(isinstance(x,str) for x in value):
            yield value
            return
        for row in value:
            yield from records(row)
    elif isinstance(value,dict):
        if isinstance(value.get('command'),list): yield value['command']
        elif isinstance(value.get('command'),str):
            yield [p.strip('"') for p in shlex.split(value['command'],posix=False)]
        elif isinstance(value.get('arguments'),list): yield value['arguments']
        for name in ['compile','commands','recipes','plan','rows']:
            if name in value: yield from records(value[name])

def source(command):
    return next((x for x in command if x.lower().endswith(('.cc','.cpp','.cxx','.c','.mm'))),None)

def output(command):
    for i,arg in enumerate(command):
        if arg.lower().startswith('/fo'):
            return arg[3:] if len(arg)>3 else command[i+1]
    return None

def rebased(command,src,stem):
    args=[x for x in command if not x.lower().startswith(('/fo','/fd'))
          and not x.lower().endswith(('.cc','.cpp','.cxx','.c','.mm')) and x!='/FS']
    return [*args,str(src),'/Fo'+str(OUT/(stem+'.obj'))]

def canonical(path):
    p=Path(path)
    try: rel=p.relative_to(ROOT).as_posix()
    except ValueError: return None
    return rel if rel.startswith(('src/','include/','tests/')) else None

OUT.mkdir(parents=True,exist_ok=True)
base=read(BASE/'matched-link-base.json')
objects=[Path(row['path']) for row in base['objects']]
index={}
evidence=[]
for directory in sorted({p.parent for p in objects}):
    for path in sorted({directory/n for n in ['commands.json','vulkan-commands.json','compile-plan.json','compile-recipes.json']}
                       | set(directory.glob('*compile-command.json'))):
        if not path.exists(): continue
        evidence.append(str(path))
        for command in records(read(path)):
            src=source(command);target=output(command)
            if src and target:
                index[key(target)]=dict(source=src,command=command,origin=str(path))

rows=[]
for i,obj in enumerate(objects):
    recipe=index.get(key(obj))
    row=dict(object=str(obj),object_sha256=sha(obj),object_bytes=obj.stat().st_size)
    if recipe:
        rel=canonical(recipe['source'])
        row.update(recipe)
        row['canonical_source']=rel
        row['source_sha256']=sha(recipe['source']) if Path(recipe['source']).is_file() else None
        row['classification']='current_hyle_host' if rel and rel.startswith('src/') else 'vendor_or_generated_or_derived'
        row['candidate_object']=str(OUT/(f'owner-{i:02d}-'+obj.stem+'.obj'))
        row['candidate_command']=rebased(recipe['command'],ROOT/rel if rel else recipe['source'],
                                        f'owner-{i:02d}-'+obj.stem)
    else:
        row['classification']='recipe_not_yet_located'
    rows.append(row)
write('matched-object-recipes.json',rows)
write('recipe-index-sources.json',evidence)

# The mixed closure still draws ordinary schema/Graph helpers from old archives.
# These same-build owners must be considered even though not explicit objects.
additional_sources=[
 'src/graph/graph.cc','src/graph/effect_order.cc','src/graph/view_domain.cc',
 'src/compute_ops/operation.cc','src/compute_ops/sampling_ops.cc',
 'src/compute_route_vulkan/vulkan_tensor.cc','src/compute_route_vulkan/vulkan_recorder.cc',
 'src/compute_route_vulkan/vulkan_elementwise.cc','src/compute_route_vulkan/vulkan_normalization.cc',
 'src/compute_route_vulkan/vulkan_reduction.cc','src/compute_route_vulkan/vulkan_sampling.cc',
 'src/compute_route_vulkan/vulkan_mlx.cc','src/compute_route_vulkan/vulkan_iq1.cc',
 'src/compute_route_vulkan/vulkan_leased_invocation.cc',
 'src/compute_ggml_runtime/cpu_program.cc','src/compute_ggml_runtime/cpu_program_export.cc',
 'src/compute_ggml_runtime/cpu_execution.cc',
 'src/compute_provider_native/elementwise.cc',
 'src/compute_provider_native/row_cache.cc',
 'src/compute_provider_native/cast.cc','src/compute_provider_native/ds4_quantization.cc',
 'src/compute_provider_native/normalization.cc','src/compute_provider_native/reduction.cc',
 'src/compute_provider_native/sampling.cc','src/compute_provider_native/transform.cc',
 'src/compute_provider_native/transformer.cc','src/compute_provider_native/default_rules.cc',
 'src/compute_route_vulkan/vulkan_scatter.cc',
 'src/graph_batch/native_paged_node.cc','src/graph_batch/native_paged_regions.cc',
 'tests/graph_batch/native_paged_joint_consumer.cc']
databases=[ROOT/'.scratch/build-cpu-final-mixed-probe/compile_commands.json',
           ROOT/'.scratch/build-compute-v2-dev/compile_commands.json',
           ROOT/'.scratch/bench-api-runtime/vulkan/build/compile_commands.json']
db_index={}
for db in databases:
    if not db.exists(): continue
    for row in read(db):
        for command in records(row):
            if source(command): db_index.setdefault(key(row.get('file',source(command))),[]).append((command,str(db)))
extra=[]
for name in additional_sources:
    path=ROOT/name
    if not path.exists(): continue
    variants=db_index.get(key(path),[])
    if not variants and name.startswith('src/compute_provider_native/'):
        native=next(row for row in rows if row.get('canonical_source')=='src/compute_provider_native/native_provider.cc')
        variants=[(rebased(native['command'],path,'pending'),native['origin']+' (same actual module flags)')]
    if not variants and name=='src/graph_batch/native_paged_regions.cc':
        batch=next(row for row in rows if row.get('canonical_source')=='src/graph_batch/batch.cc')
        variants=[(rebased(batch['command'],path,'pending'),batch['origin']+' (same actual module flags)')]
    if not variants and name.startswith('tests/'):
        c=read(BASE/'compile-recipes.json')
        original=next(row for row in c if row['source']=='tests/graph/route_symmetry_vulkan.cc')
        variants=[(rebased(original['command'],path,'pending'),str(BASE/'compile-recipes.json')+' finite consumer actual flags')]
    extra.append(dict(source=name,current_sha256=sha(path),
        recipes=[dict(command=c,origin=o) for c,o in variants],
        note='cold candidate only; choose matching actual module macros and include family; no compile executed'))
write('additional-archive-owners.json',extra)
write('summary.json',dict(status='prepared_not_compiled',explicit_objects=len(objects),
    located=sum('source' in row for row in rows),
    hyle=sum(row['classification']=='current_hyle_host' for row in rows),
    unresolved=[row['object'] for row in rows if row['classification']=='recipe_not_yet_located'],
    reason='Operation now retains owned inline native-page payload. Equal sizeof does not make old copy/destructor/vtable/Result return ABI compatible.',
    no_sdk_kernel_shader_build=True))
print((OUT/'summary.json').read_text(encoding='utf-8'))
