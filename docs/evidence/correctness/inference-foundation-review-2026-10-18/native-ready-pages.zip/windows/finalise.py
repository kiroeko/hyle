"""Freeze this focused consumer's current identities; never build or delete."""
from pathlib import Path
import difflib,hashlib,json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def identity(path):
 p=Path(path);b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

base=read(OUT/'matched-link-base.json')
records=read(OUT/'commands.json')
assert records[-1]['tag']=='native-page-ready-64-causal-run' and records[-1]['exit']==0
assert all(identity(x['path'])==x for x in base['objects'])
headers=['include/hyle/compute/operation.h','src/compute/provider_internal.h',
 'include/hyle/graph/region_provider.h','include/hyle/graph/batch.h',
 'include/hyle/compute/detail/materialized_native_controller.h',
 'include/hyle/graph/detail/region_access.h','src/graph/plan_state.h']
sources=sorted(set(base['selected_sources'])|set(headers)|{'tests/graph_batch/CMakeLists.txt'})
rows=[]
for source in sources:
 p=ROOT/source;dest=OUT/'candidate'/source
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
 rows.append(dict(relative=source,**identity(p)))
write('final-source-identities.json',rows)
write('final-object-identities.json',base['objects'])
write('final-library-identities.json',[identity(x) for x in base['command'] if x.lower().endswith('.lib') and Path(x).is_file()])
write('final-image-identities.json',[identity(OUT/'native-page-ready.exe'),identity(OUT/'native-page-ready.map')])

consumer='tests/graph_batch/native_paged_joint_consumer.cc'
before=ARCH/'native-page-graph/consumer/before'/consumer
after=ROOT/consumer
(OUT/'consumer.diff').write_text(''.join(difflib.unified_diff(
 before.read_text(encoding='utf-8').splitlines(True),after.read_text(encoding='utf-8').splitlines(True),
 fromfile='before/'+consumer,tofile=consumer)),encoding='utf-8')

# The first compiled migration failed before accepting work because the
# ordinary Graph output had no caller writer. Recover that exact source for
# the failure log, while the only retained object is the final corrected one.
first=after.read_text(encoding='utf-8')
first=first.replace('  HYLE_ASSIGN_OR_RETURN(auto output_description,graph.value_description(output));\n'
 '  HYLE_ASSIGN_OR_RETURN(auto output_bytes,output_description.required_bytes());\n'
 '  std::array<c::LeasePool,2> output_pools;\n'
 '  for(auto& output_pool:output_pools){\n'
 '    HYLE_ASSIGN_OR_RETURN(output_pool,c::LeasePool::create(hyle::mem::system_resource(),output_bytes+64,{.max_blocks=1}));\n'
 '  }\n','')
first=first.replace('    HYLE_ASSIGN_OR_RETURN(auto output_writer,output_pools[episode%2].allocate(output_bytes,64));\n'
 '    HYLE_RETURN_IF_ERROR(slot.bind(output,output_description,std::move(output_writer)));\n','')
expected='a023159c3e254668a4d2c50c9c4cca9616fd298a92648be26b77a5dc47422dad'
variants=[first.encode(),first.replace('\n','\r\n').encode()]
failed=next((b for b in variants if hashlib.sha256(b).hexdigest()==expected),None)
assert failed is not None,'initial failure source reconstruction must match its recorded SHA'
failure=OUT/'failures/first-migration'/consumer
failure.parent.mkdir(parents=True,exist_ok=True);failure.write_bytes(failed)
write('failure-source-identity.json',dict(recorded_sha256=expected,reconstructed=identity(failure),
 note='Exact initial migration source reconstructed from final fixture and checked against command079-era source SHA. The overwritten historical executable/object were not retained; raw commands/logs remain.'))

old=OUT/'summary.json'
if old.exists() and not (OUT/'prepare-index-summary.json').exists():
 (OUT/'prepare-index-summary.json').write_bytes(old.read_bytes())
compile_rows=[r for r in records if r['tag'].endswith('-compile')]
summary=dict(status='actual_ready_consumer_passed',
 final_run=records[-1],final_link=records[-2],
 geometry=dict(depth=64,query_type='F16',causal=True,episodes=64,slots=2,layouts=3,
               active_query_rows=18,requests=3,physical_pages=4,page_refs=7,page_size=16,query_heads=8,kv_heads=2),
 preserved=['CPU Abs and F32-to-F16 cast -> actual native paged attention -> CPU F32 cast and Neg',
  'Original independent FP64 attention oracle, unchanged F16 absolute tolerance 0.002',
  'Repeated and shuffled physical page references, partial last pages, a zero-query/zero-history request',
  'Unused physical page2 retains writer and poisoned payload; no whole-arena permission',
  'Ordinary dense lease cannot bypass exact typed page binding',
  'Two original Invocations, actual owned host output WriteLease per slot, one pool block reused',
  'Old GraphOutput rejects prepare/reset/repeated submit',
  'Episode0 same Q/frame/layout strict replay without bind/gb::prepare/prepare_replay; same FP64 oracle',
  'Original metadata generation/<=32-byte upload/same-page-table zero-upload assertions'],
 compilation=dict(unique_current_hyle_objects=len(base['selected_sources']),
  fresh_unique_windows_objects=len(list(OUT.glob('*.obj'))),
  compile_calls=len(compile_rows),successful_compile_calls=sum(r['exit']==0 for r in compile_rows),
  schema_reused=7,backend_final_reused=5,linked_objects=len(base['objects']),
  operation_header_sha256=identity(ROOT/headers[0])['sha256'],provider_contract=16,region_spi=26,
  no_vendor_sdk_kernel_or_shader_build=True),
 retained_unchanged=base['retained_unchanged'],
 failures=[dict(command='082-native-page-ready-64-causal-run',cause='Migration omitted required CPU caller output writer; common preflight correctly rejected before work.',product_modified=False),
  dict(command='083-tests--graph_batch--native_paged_joint_consumer-compile',cause='Fixture local output pool loop name shadowed the existing input pool under /W4 /WX; renamed.',product_modified=False)],
 boundaries=['Only nonempty ready Vulkan F16 D64 causal1 was run in this phase; other five default Vulkan geometries were not run.',
  'All-empty history and native pending admission are not supported by this new path and are not proved by ready success.',
  'Apple legacy conditional consumer remains; no Apple runtime result is claimed here.',
  'The old public native controller paths/risk consumers have not all migrated.',
  'No throughput/latency comparison was performed. Strict replay proves functional reuse, not an allocation or performance census.',
  'Retained mixed CPU/Vulkan vendor cache is the prior successful F32/F16 closure; unexecuted added IQ1 enum formats are not qualified.'],
 evidence=dict(source_identities='final-source-identities.json',objects='final-object-identities.json',
  libraries='final-library-identities.json',link='matched-link-base.json',commands='commands.json',
  raw_result='086-native-page-ready-64-causal-run.stderr.log',initial_failure='082-native-page-ready-64-causal-run.stderr.log'),
 no_live_process=True,no_deletion=True)
write('summary.json',summary)
print(json.dumps(dict(status=summary['status'],sources=len(rows),objects=len(base['objects']),
 retained_objects=len(list(OUT.glob('*.obj'))),source_sha256=identity(after)['sha256'],summary=identity(OUT/'summary.json'))))
