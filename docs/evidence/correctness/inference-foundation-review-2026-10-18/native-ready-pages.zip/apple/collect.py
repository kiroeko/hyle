from pathlib import Path
import importlib.util
import hashlib
import io
import json
import sys
import tarfile

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stage',OUT/'stage.py')
stage=importlib.util.module_from_spec(spec)
spec.loader.exec_module(stage)
name=sys.argv[1] if len(sys.argv)>1 else 'final'
code='''from pathlib import Path
import io,sys,tarfile
r=Path('''+repr(stage.REMOTE)+''')
names=['commands.json','sources.json','summary.json','machine.txt','live.json','cleanup-mac.json','run_remote.py']
names.extend(p.name for p in r.glob('*.log'))
names.extend(p.name for p in r.glob('*.d'))
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w:gz') as a:
 for name in sorted(set(names)):
  if (r/name).is_file():a.add(r/name,arcname=name)
sys.stdout.buffer.write(data.getvalue())
'''
raw=stage.ssh(code)
archive_path=OUT/('results-'+name+'.tar.gz')
archive_path.write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
               for m in archive.getmembers())
    archive.extractall(OUT/('results-'+name))
commands=json.loads((OUT/('results-'+name)/'commands.json').read_text())
result=dict(archive=str(archive_path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
            attempts=len(commands),passed=sum(r['exit']==0 for r in commands),
            failed=sum(r['exit']!=0 for r in commands),linked=False,executed=False)
(OUT/('collection-'+name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
