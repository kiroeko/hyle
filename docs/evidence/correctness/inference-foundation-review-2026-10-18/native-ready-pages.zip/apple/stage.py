from pathlib import Path, PurePosixPath
import importlib.util
import hashlib
import io
import json
import re
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
OLD = ROOT/'.scratch/architecture-refactor-2026-10-18/native-inputs/apple/apple-spi25'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-native-ready-pages-apple'
BASE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-native-inputs-apple/apple-spi25'
spec = importlib.util.spec_from_file_location('transport', OLD/'stage.py')
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)
ssh = transport.ssh
SEEDS = ['src/graph_route_apple/execution_source.cc',
         'src/graph_route_apple/native_region.cc',
         'src/graph_route_cpu_apple/compile.cc',
         'src/graph_batch/native_paged_node.cc']


def main():
    old_manifest = json.loads((OLD/'sources.json').read_text())
    old_rows = {r['path']: r for r in old_manifest['sources']}
    baseline = json.loads((OLD/'baseline.json').read_text())
    (OUT/'baseline.json').write_text(json.dumps(baseline, indent=2)+'\n')
    files, seen = {}, set()

    def add(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:
            return
        seen.add(path)
        files[path.relative_to(ROOT).as_posix()] = path
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',
                                  path.read_text(encoding='utf-8-sig'), re.M):
            for directory in [path.parent, ROOT, ROOT/'include', ROOT/'src/graph',
                              ROOT/'src/compute', ROOT/'src/compute_route_apple',
                              ROOT/'src/graph_route_apple', ROOT/'src/graph_route_cpu_apple']:
                candidate = directory/include
                if candidate.is_file():
                    add(candidate)
                    break

    for source in SEEDS:
        add(ROOT/source)
    # The private provider contract is part of this batch even if the selected
    # four syntax units do not include its callback declarations themselves.
    add(ROOT/'src/compute/provider_internal.h')
    rows = []
    payload_files = {'run_remote.py': OUT/'run_remote.py', 'baseline.json': OUT/'baseline.json'}
    for name, path in sorted(files.items()):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        reuse = name in old_rows and old_rows[name]['sha256'] == digest
        rows.append(dict(path=name, bytes=path.stat().st_size, sha256=digest,
                         cache=str(PurePosixPath(BASE)/name) if reuse else None))
        if not reuse:
            payload_files[name] = path
    manifest = dict(remote=REMOTE, base=BASE, syntax_only=True, sources=rows, seeds=SEEDS)
    (OUT/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
    payload_files['sources.json'] = OUT/'sources.json'
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode='w:gz') as archive:
        for name, path in sorted(payload_files.items()):
            archive.add(path, arcname=name)
    (OUT/'source-delta.tar.gz').write_bytes(payload.getvalue())
    code = '''from pathlib import Path
import hashlib,io,json,os,sys,tarfile
r=Path(''' + repr(REMOTE) + ''')
assert r.parent.is_dir(),r.parent
r.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as a:
 assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in a.getmembers())
 a.extractall(r)
manifest=json.loads((r/'sources.json').read_text())
for row in manifest['sources']:
 p=r/row['path']
 if row['cache']:
  original=Path(row['cache'])
  assert hashlib.sha256(original.read_bytes()).hexdigest()==row['sha256'],original
  p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():os.link(original,p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p
print(json.dumps(dict(root=str(r),sources=len(manifest['sources']),cached=sum(bool(v['cache']) for v in manifest['sources']))))
'''
    result = ssh(code, payload.getvalue())
    (OUT/'stage.log').write_bytes(result)
    print(result.decode().strip(), 'delta',len(payload_files), 'entries',len(payload.getvalue()),'bytes')


if __name__ == '__main__':
    main()
