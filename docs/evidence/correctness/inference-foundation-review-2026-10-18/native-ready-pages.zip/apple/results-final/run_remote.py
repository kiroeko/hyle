from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip() == 'Mac16,12'
    manifest = json.loads((ROOT/'sources.json').read_text())
    for row in manifest['sources']:
        assert identity(ROOT/row['path'])['sha256'] == row['sha256'],row['path']
    baseline = json.loads((ROOT/'baseline.json').read_text())
    assert identity(Path(baseline['root'])/'compile-plan.json')['sha256'] == baseline['compile_plan_sha256']
    (ROOT/'machine.txt').write_text(subprocess.check_output(
        ['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)
        + subprocess.check_output(['xcrun','clang++','--version'],text=True))
    # Retain the original selected native SDK/system flags; every Hyle include
    # comes from the current closed minimal tree, not an earlier overlay.
    args = []
    skip = False
    for arg in baseline['sources'][0]['command']:
        if skip:
            skip = False
            continue
        if arg in {'-c','-o'}:
            skip = True
            continue
        if arg.startswith('-I'):
            continue
        args.append(arg)
    includes = [ROOT/'include',ROOT,ROOT/'src/graph',ROOT/'src/compute',
                ROOT/'src/graph_route_apple',ROOT/'src/compute_route_apple',
                ROOT/'src/graph_route_cpu_apple',ROOT/'src/graph_batch']
    args[1:1] = ['-I'+str(p) for p in includes]
    assert all(flag in args for flag in ['-Werror','-Wall','-Wextra','-Wpedantic'])
    commands = json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
    for index, source in enumerate(manifest['seeds'],1):
        name = ['apple-source','apple-region','cpu-apple-compile','native-schema'][index-1]
        command = args+['-MMD','-MF',str(ROOT/(name+'.d')),'-fsyntax-only',str(ROOT/source)]
        stem = f'{len(commands)+1:02d}-{name}-syntax'
        started = time.monotonic()
        with (ROOT/(stem+'.stdout.log')).open('wb') as out,(ROOT/(stem+'.stderr.log')).open('wb') as err:
            process = subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err)
            (ROOT/'live.json').write_text(json.dumps(dict(pid=process.pid,tag=stem))+'\n')
            code = process.wait()
        commands.append(dict(tag=stem,command=command,exit=code,
            seconds=time.monotonic()-started,source=identity(ROOT/source),
            stdout=stem+'.stdout.log',stderr=stem+'.stderr.log'))
        (ROOT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        (ROOT/'live.json').write_text(json.dumps(dict(terminal=True,tag=stem,exit=code))+'\n')
        print(stem,code,flush=True)
        if code:
            print((ROOT/(stem+'.stderr.log')).read_text(errors='replace')[-10000:])
            raise SystemExit(code)
    summary = dict(machine='Mac16,12',syntax_only=True,compiled=len(manifest['seeds']),passed=len(manifest['seeds']),
        attempts=len(commands),failed_attempts=sum(r['exit']!=0 for r in commands),
        linked=False,executed=False,provider_contract=16,region_spi=26,
        scope='Current owned inline schema, Apple sources and retained CPUApple cold compiler; no SDK/core compilation or link')
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'cleanup-mac.json').write_text(json.dumps(dict(root=str(ROOT),files=[],retain=[]),indent=2)+'\n')
    print(json.dumps(summary),flush=True)


if __name__ == '__main__':
    main()
