from pathlib import Path
import importlib.util
import json
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=OUT.parents[1]
spec=importlib.util.spec_from_file_location('host',ARCH/'submission-frontier/windows/run.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
d.OUT=OUT
d.ABI_HEADERS=('include/hyle/compute/operation.h','include/hyle/graph/batch.h',
    'include/hyle/graph/region_provider.h')

def compile():
    for source,stem,test in [
        ('src/compute_ops/operation.cc','ops',False),
        ('src/compute_ops/sampling_ops.cc','sampling',False),
        ('src/graph/graph.cc','graph',False),
        ('src/graph_batch/native_paged_node.cc','schema',False),
        ('src/compute_batch/batch_layout.cc','layout',False),
        ('src/graph_batch/native_paged_regions.cc','regions',False),
        ('src/graph_batch/batch.cc','batch',False),
        ('tests/compute_ops/operation_test.cc','ops-test',True),
        ('tests/graph_batch/native_paged_node_test.cc','schema-test',True)]:
        d.compile_one(source,stem,d.TEST if test else d.CORE)

def link():
    libs=ROOT/'.scratch/build-compute-v2-dev'
    order=['hyle_graph.lib','hyle_compute_batch.lib','hyle_compute.lib',
        'hyle_compute_ops.lib','hyle_mem.lib','hyle_error.lib','hyle_time.lib',
        'hyle_platform.lib','mimalloc_static.lib']
    command=[str(Path(d.CORE[0]).with_name('link.exe')),'/nologo','/MACHINE:X64',
        '/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(OUT/'schema.exe'),'/MAP:'+str(OUT/'schema.map')]
    command += [str(OUT/(x+'.obj')) for x in ['ops-test','schema-test','ops','sampling','graph','schema','layout']]
    command += [str(libs/'bin'/x) for x in order]
    command += [str(libs/'lib'/x) for x in ['gtest_main.lib','gtest.lib']]
    command += ['bcrypt.lib','PowrProf.lib','Synchronization.lib','kernel32.lib','advapi32.lib']
    d.run('schema-link',command)
    d.run('schema-run',[OUT/'schema.exe','--gtest_color=no',
        '--gtest_filter=OperationCustom.*:NativePagedGraphNode.*',
        '--gtest_output=json:'+str(OUT/'results.json')])
    r=d.read(OUT/'results.json');assert r['failures']==0 and r['errors']==0
    print(r['tests'],'passed',flush=True)

if __name__=='__main__':
    if sys.argv[1]=='one': d.compile_one(sys.argv[2],sys.argv[3],d.TEST if 'tests/' in sys.argv[2] else d.CORE)
    else: {'compile':compile,'link':link}[sys.argv[1]]()
