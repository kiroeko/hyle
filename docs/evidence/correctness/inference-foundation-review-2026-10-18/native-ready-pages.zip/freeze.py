"""Freeze focused source/results, retaining build caches outside the archive."""
from pathlib import Path
import hashlib,json,zipfile

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
TARGET=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/native-ready-pages.zip'
BACKEND=STAGE.parent/'native-paged-region/vulkan'
def ident(p):
    p=Path(p);data=p.read_bytes()
    return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

sources={
 'include/hyle/compute/operation.h','src/compute/provider_internal.h',
 'include/hyle/compute/detail/materialized_native_controller.h',
 'include/hyle/graph/region_provider.h','include/hyle/graph/batch.h',
 'include/hyle/graph/detail/region_access.h','src/graph/resources.cc',
 'src/graph_route_cpu/ggml_region.cc','src/graph_batch/CMakeLists.txt',
 'src/graph_batch/batch.cc','src/graph_batch/native_paged_node.cc',
 'src/graph_batch/native_paged_nodes.h','src/graph_batch/native_paged_regions.h',
 'src/graph_batch/native_paged_regions.cc','src/graph_route_vulkan/native_paged_region.h',
 'src/graph_route_vulkan/native_paged_region.cc','src/graph_route_vulkan/native_region.cc',
 'src/graph_route_vulkan/CMakeLists.txt','src/compute_route_vulkan/vulkan_batch.cc',
 'src/compute_route_vulkan/vulkan_memory.cc','src/compute_route_vulkan/vulkan_memory_internal.h',
 'src/compute_route_vulkan/vulkan_copy_program.cc','src/compute_route_vulkan/vulkan_file_stream_access.h',
 'include/hyle/compute/detail/vulkan_batch_access.h','tests/compute_ops/operation_test.cc',
 'tests/graph_batch/native_paged_node_test.cc','tests/graph_batch/native_paged_joint_consumer.cc',
 'tests/graph_batch/CMakeLists.txt','docs/architecture/compute-design.md',
 'docs/developer/current-work.md','docs/user/batch-attention.md','test.ps1',
}
for rel in sorted(sources):
    src=ROOT/rel;dest=STAGE/'final-source'/rel
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
(STAGE/'final-source-identities.json').write_text(json.dumps(
    [dict(relative=s,**ident(ROOT/s)) for s in sorted(sources)],indent=2)+'\n',encoding='utf-8')
files=[]
for folder in ['schema','windows']:
    for p in (STAGE/folder).iterdir():
        if p.is_file() and p.suffix.lower() in ['.exe','.map','.exp','.lib']:
            files.append(ident(p))
(STAGE/'cleanup.json').write_text(json.dumps(dict(files=files,bytes=sum(x['bytes'] for x in files),
    retained='all objects, dependency/kernel caches, sources, failures, logs and numerical data'),indent=2)+'\n',encoding='utf-8')
extensions={'.py','.ps1','.json','.md','.cc','.h','.hpp','.log','.diff','.patch','.txt','.cmake','.csv','.rsp','.gz'}
entries={}
for directory,prefix in [(STAGE,''),(BACKEND,'native-adapter/')]:
    for p in directory.rglob('*'):
        if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:continue
        if p.name in ['archive-receipt.json','cleanup-result.json']:continue
        if p.suffix.lower() in extensions:entries[prefix+p.relative_to(directory).as_posix()]=p
assert not TARGET.exists(),'Frozen evidence must never be overwritten'
with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(TARGET) as z:assert z.testzip() is None
receipt=ident(TARGET);receipt.update(path=TARGET.relative_to(ROOT).as_posix(),entries=len(entries))
(STAGE/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archive=receipt,cleanup_files=len(files),reclaim_bytes=sum(x['bytes'] for x in files))))
