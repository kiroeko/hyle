from pathlib import Path
import hashlib
import importlib.util
import json
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
ARCH=OUT.parents[1]
spec=importlib.util.spec_from_file_location('runner',ARCH/'region-adapter/run.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.OUT=OUT
SOURCE={
 'page-region':'src/graph_route_vulkan/native_paged_region.cc',
 'region':'src/graph_route_vulkan/native_region.cc',
 'native-batch':'src/compute_route_vulkan/vulkan_batch.cc',
 'memory':'src/compute_route_vulkan/vulkan_memory.cc',
 'copy-program':'src/compute_route_vulkan/vulkan_copy_program.cc',
}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def compile_one(name):
 rows=json.loads((ARCH/'vulkan-constant-readback/commands.json').read_text())
 old=next(r['command'] for r in reversed(rows) if r['tag']=='source-staging-compile' and r['exit']==0)
 source=ROOT/SOURCE[name];obj=OUT/(name+'.obj')
 command=[str(source) if str(x).endswith('.cc') else '/Fo'+str(obj)
          if str(x).lower().startswith('/fo') else x for x in old]
 before=sha(source);b.run(name+'-compile',command,timeout=60);assert before==sha(source)
 (OUT/(name+'-identity.json')).write_text(json.dumps(dict(source=str(source),source_sha256=before,
   object=str(obj),object_bytes=obj.stat().st_size,object_sha256=sha(obj)),indent=2)+'\n')
if __name__=='__main__':
 for name in sys.argv[1:]:compile_one(name)
