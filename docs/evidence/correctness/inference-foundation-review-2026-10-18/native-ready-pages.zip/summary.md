# Original Graph native ready-page vertical

The ordinary Graph now carries CPU pre-processing → native Vulkan paged attention → CPU post-processing in one Executable/Invocation. A typed node retains the original immutable recipe and initial layout; it does not duplicate geometry or require an external node registration. Its only optional native limit is metadata backing bytes. The original Graph compile budget and slot allocator remain authoritative.

The selected prepared artifact exposes cold layout/frame/report capabilities. The batch module keeps borrowed original-slot references in the one existing ResourcePayload; core independently verifies every actual physical reader, publication, alias and copy. Vulkan retains one original MaterializedNativeState, native Invocation, metadata banks, real F2 uploader and permission pool. Runtime/resource factories factor original bodies without fake Context/Queue handles. Generated output backing is refreshed after cold layout replacement, then the original prepare_replay rebinds downstream consumers. No second Graph executor or shadow output is introduced.

Fixed ready bindings can replay without cold preparation. Each replay still enters the original native retirement/result gate and admits actual permission uses. A pre-admission busy gate does not poison the controller; actual native submit failure preserves original failure semantics. The expert single-episode submit still consumes its preparation.

Validation:

- Windows current Operation/schema/Graph owner tests: **61/61**. Includes nontrivial owner copy/move/replacement and Graph retaining recipe/layout after input handles die. Operation retains its original inline capacity and performs no descriptor allocation.
- RTX 4070 actual F16/D64/causal consumer: **64 episodes, two independently owned slots, three layouts, PASS**, plus one same-binding strict replay without batch::prepare, bind or prepare_replay. Preserves independent FP64 oracle and original 0.002 absolute error threshold, exact page permissions, an unreferenced page writer, old GraphOutput/reset/preparation checks and metadata delta checks. Slots are exercised serially; this is not a new simultaneous-slot concurrency or throughput measurement.
- MacBook Air Mac16,12: **four syntax checks PASS** for the actual Apple Source/native region, old CPU+Apple compile adapter and native page schema. No current Apple binary link/run or shared-budget runtime claim.
- Hyle host owners relevant to changed Operation ownership/Provider16/Region26 are matched; original numerical SDK/kernel/shader caches are reused. Vendor cache identities are preserved. The actual numerical qualification is this F16 vertical, not all ggml types or all model profiles.

Failures retained: initial Apple libc++ variant noexcept trait difference (fixed explicit outer contract with nothrow alternatives); missing PagedArenaRead declaration in a private Vulkan header (fixed typed include); first actual consumer missing its ordinary caller CPU output writer (fixed per-slot reusable original LeasePool/WriteLease). No numerical tolerances or core completeness gates were weakened.

Remaining: native pending CopyUpdate and true empty footprint are explicitly unimplemented in this new ready-page vertical; Apple/other legacy native-page consumers and old mixed runtimes are not retired here. Metadata initialization and changed-page-table uploads still have real cold F2 waits. No full Qwen rerun, fair tokens/s comparison, new Linux runtime qualification, broad dtype/MLA/fault matrix or claim that the architecture goal is complete.

Detailed commands/results are in schema/, windows/ and apple/; exact native adapter changes are included under native-adapter/ in the archive. Source, failures, logs, numerical evidence and all object/SDK caches are retained. Only frozen rebuildable images/maps/exports are reclaimed through root test.ps1.
