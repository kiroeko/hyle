from pathlib import Path
import importlib.util
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-single-constant-expert'
spec=importlib.util.spec_from_file_location('dense_runner',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/dense-constants/run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
s=(ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc').read_text()
marker='    bind_views();\n    for (const auto &constant : constants)'
probe='''    std::size_t casts = 0;
    for (int i = 0; i < nodes; ++i) {
      const auto *tensor = ggml_graph_node(graph, i);
      if (tensor->op == GGML_OP_CPY && tensor->src[0] &&
          tensor->src[0]->type == GGML_TYPE_BF16 && tensor->type == GGML_TYPE_F32) ++casts;
    }
    std::fprintf(stderr,"EXPERT_CENSUS recipe_nodes=%zu constants=%zu BF16_to_F32=%zu\\n",
        recipe.nodes.size(), recipe.constants.size(), casts);
'''
assert s.count(marker)==1
source=OUT/'provider-census.cc';source.write_bytes(('#include <cstdio>\n'+s.replace(marker,probe+marker)).encode())
# The runner keeps unique attempts, but place this batch's logs and objects here.
r.OUT=OUT;r.records=[]
flags=r.cuda.flags+['/I'+str(ROOT)]
objects=[]
for file,stem in [(source,'provider-census'),('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','region'),('tests/graph_provider_ggml_cuda/region_test.cc','tests')]:
 objects.append(r.compile(file,stem,r.cuda.cl,flags,r.cuda.env))
objects += [ROOT/'.scratch/mtp-completion/operation.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-rope/cuda-tensor.obj',r.cuda.OLD/'ggml-cuda.strict.obj']
exe=OUT/'tests.exe'
r.run('link',[r.cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/'tests.map'),*objects,*r.cuda.libs,r.cuda.BASE/'lib/gtest_main.lib',r.cuda.BASE/'lib/gtest.lib',*r.cuda.system],r.cuda.env)
r.run('tests',[exe,'--gtest_filter=GgmlCudaGraph.SingleBfloatExpertConstantPacksOnceAndDynamicWeightRemainsRebindable:GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable:GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs','--gtest_color=no'],r.cuda.env)
