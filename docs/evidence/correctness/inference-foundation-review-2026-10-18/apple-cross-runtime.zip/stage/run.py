from pathlib import Path
import base64, hashlib, importlib.util, json, re, sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('air_transport', OUT.parent / 'apple-page-invocation/air.py')
air = importlib.util.module_from_spec(spec)
spec.loader.exec_module(air)
TRIAL = air.REMOTE + '/cross-runtime'
RECIPES = json.loads((OUT.parent / 'apple-f32-partials-runtime/validation/final-recipes.json').read_text())
TEST = json.loads((OUT.parent / 'apple-f32-partials-runtime/validation/results/validation/012-final-test-compile.command.json').read_text())['argv']


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


REMOTE = r'''
from pathlib import Path
import hashlib, json, os, subprocess, sys, time
p=json.loads(sys.stdin.buffer.read()); root=Path(p['trial']); root.mkdir(exist_ok=True)
def identity(path):
 q=Path(path)
 h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
if p.get('inspect'):
 hardware={key:subprocess.run(cmd,capture_output=True,text=True).stdout.strip() for key,cmd in {
 'model':['sysctl','-n','hw.model'],'memory':['sysctl','-n','hw.memsize'],
 'system':['sw_vers'],'compiler':['/usr/bin/clang++','--version'],
 'space':['df','-k',str(root)]}.items()}
 report=dict(hardware=hardware,link_inputs=[identity(x) for x in p['inputs']],
             source_comparisons=[dict(source=x['source'],actual=identity(x['path']) if Path(x['path']).is_file() else None) for x in p['sources']])
 (root/'inspect.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(hardware=hardware,link_inputs=len(report['link_inputs']),source_comparisons=report['source_comparisons'])));sys.exit(0)
if p.get('link'):
 target=root/'mlx.metallib'; source=Path(p['metallib'])
 assert source.is_file()
 if target.is_symlink(): assert target.resolve()==source.resolve()
 else: assert not target.exists();target.symlink_to(source)
tag=p['tag']; argv=p['argv']; env=dict(os.environ)
row=dict(tag=tag,argv=argv,cwd=str(root),started=time.time(),exit=None)
(root/(tag+'.command.json')).write_text(json.dumps(row,indent=2)+'\n')
with (root/(tag+'.stdout.log')).open('wb') as so,(root/(tag+'.stderr.log')).open('wb') as se:
 child=subprocess.Popen(argv,cwd=root,env=env,stdout=so,stderr=se)
 row['pid']=child.pid;(root/'live.json').write_text(json.dumps(row,indent=2)+'\n')
 row['exit']=child.wait(timeout=240)
row.update(finished=time.time(),terminal=True,outputs=[identity(x) for x in p.get('outputs',[]) if Path(x).is_file()])
(root/(tag+'.result.json')).write_text(json.dumps(row,indent=2)+'\n');(root/'live.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(dict(tag=tag,exit=row['exit'],seconds=row['finished']-row['started'],outputs=row['outputs'])));print((root/(tag+'.stdout.log')).read_text(errors='replace')[-9000:]);print((root/(tag+'.stderr.log')).read_text(errors='replace')[-7000:])
sys.exit(row['exit'])
'''


def invoke(tag, **payload):
    payload.update(trial=TRIAL, tag=tag)
    result = air.ssh(REMOTE, json.dumps(payload).encode(), timeout=270)
    (OUT / (tag + '.transport.stdout.log')).write_bytes(result.stdout)
    (OUT / (tag + '.transport.stderr.log')).write_bytes(result.stderr)
    print(result.stdout.decode(errors='replace')); print(result.stderr.decode(errors='replace'))
    if result.returncode:
        raise SystemExit(result.returncode)


def recipe(source, obj):
    old_source = next(x for x in TEST if x.endswith('.cc'))
    args = [x for x in TEST if x not in [old_source]]
    index = args.index('-o'); args[index+1] = TRIAL + '/' + obj
    args[1:1] = ['-I'+TRIAL+'/include', '-I'+TRIAL, '-I'+TRIAL+'/src/graph',
                 '-I'+TRIAL+'/src/compute', '-I'+TRIAL+'/src/compute_route_apple']
    args.insert(args.index('-c')+1, TRIAL+'/'+source)
    return args


def link_plan():
    args = RECIPES['link']['argv'].copy()
    old_test = next(x for x in args if x.endswith('/attention-partials-final-test.o'))
    args[args.index(old_test)] = TRIAL + '/test.o'
    for source, obj in [('src/graph/executable.cc', 'executable.o'),
                        ('src/graph/input_sources.cc', 'input_sources.o'),
                        ('src/compute_ops/operation.cc', 'operation.o')]:
        name = 'src--' + source[4:].replace('/', '--').replace('.cc', '.o')
        old = [x for x in args if x.endswith('/'+name)]
        assert len(old) == 1, (name, old)
        args[args.index(old[0])] = TRIAL + '/' + obj
    args[args.index('-o')+1] = TRIAL + '/cross-runtime-test'
    args = [('-Wl,-map,'+TRIAL+'/cross-runtime-test.map') if x.startswith('-Wl,-map,') else x for x in args]
    return args


def stage():
    files={}
    def add(path):
        path=path.resolve()
        if path in files or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:return
        files[path]=path.relative_to(ROOT).as_posix()
        for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
            candidates=[path.parent/name,ROOT/name,ROOT/'include'/name]
            candidates += [ROOT/folder/name for folder in ['src/graph','src/compute','src/compute_route_apple',
                'src/compute_provider_ggml','src/compute_ggml_runtime','third_party/ds4_quantization',
                'third_party/torchao_cpu','third_party/bitsandbytes_cpu','third_party/awq_cpu',
                'third_party/compressed_tensors_cpu','third_party/mlx_cpu_quant']]
            for candidate in candidates:
                if candidate.is_file():add(candidate);break
    for source in ['src/graph/executable.cc','src/graph/input_sources.cc',
                   'src/compute_ops/operation.cc','tests/graph_route_apple/cross_runtime_test.cc']:
        if (ROOT/source).is_file():add(ROOT/source)
    rows=[]
    for path,name in sorted(files.items(),key=lambda x:x[1]):
        b=path.read_bytes();rows.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
    save('staged-sources.json',[{k:v for k,v in x.items() if k!='data'} for x in rows])
    code=r'''
from pathlib import Path
import base64,hashlib,json,sys
p=json.loads(sys.stdin.buffer.read());root=Path(p['trial']).resolve();root.mkdir(exist_ok=True)
for row in p['files']:
 q=(root/row['path']).resolve();assert q.is_relative_to(root)
 b=base64.b64decode(row['data']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(root/'staged-sources.json').write_text(json.dumps([{k:v for k,v in r.items() if k!='data'} for r in p['files']],indent=2)+'\n')
print(json.dumps(dict(files=len(p['files']),bytes=sum(r['bytes'] for r in p['files']))))
'''
    result=air.ssh(code,json.dumps(dict(trial=TRIAL,files=rows)).encode())
    (OUT/'stage.stdout.log').write_bytes(result.stdout);(OUT/'stage.stderr.log').write_bytes(result.stderr)
    print(result.stdout.decode(errors='replace'));print(result.stderr.decode(errors='replace'))
    if result.returncode:raise SystemExit(result.returncode)


def inspect():
    args=link_plan()
    inputs=[x for x in args if x.startswith('/') and x.endswith(('.o','.a','.dylib'))
            and not x.startswith(TRIAL+'/')]
    sources=[dict(source=x, path=air.REMOTE+'/'+x) for x in [
        'src/graph/executable.cc','src/graph/input_sources.cc','src/compute_ops/operation.cc']]
    invoke('000-inspect',inspect=True,inputs=inputs,sources=sources)


def build(key):
    source,obj,tag={
      'core':('src/graph/executable.cc','executable.o','001-core'),
      'inputs':('src/graph/input_sources.cc','input_sources.o','002-inputs'),
      'ops':('src/compute_ops/operation.cc','operation.o','003-ops'),
      'test':('tests/graph_route_apple/cross_runtime_test.cc','test.o','004-test')}[key]
    if key=='test' and list(OUT.glob('004*transport.stdout.log')):
        tag='004-'+str(len(list(OUT.glob('004*transport.stdout.log')))+1)+'-test'
    args=recipe(source,obj);save(tag+'.planned.json',dict(argv=args))
    invoke(tag,argv=args,outputs=[TRIAL+'/'+obj])


def collect():
    code=r'''from pathlib import Path;import base64,json;r=Path('''+repr(TRIAL)+r'''); print(json.dumps([dict(path=p.name,data=base64.b64encode(p.read_bytes()).decode()) for p in r.iterdir() if p.is_file() and p.suffix in {'.json','.log'}]))'''
    result=air.ssh(code);assert result.returncode==0,result.stderr
    path=OUT/'results';path.mkdir(exist_ok=True)
    for row in json.loads(result.stdout):
        (path/row['path']).write_bytes(base64.b64decode(row['data']))
    print('collected records',len(json.loads(result.stdout)))


if __name__=='__main__':
    action=sys.argv[1]
    if action=='stage':stage()
    elif action=='inspect':inspect()
    elif action in {'core','inputs','ops','test'}:build(action)
    elif action=='link':
        path=OUT/'link-plan.json'
        revision=len(list(OUT.glob('005*transport.stdout.log')))+1
        if path.exists():save('link-plan.previous.json',json.loads(path.read_text()))
        args=link_plan();save('link-plan.json',dict(argv=args));invoke(f'005-{revision}-link',argv=args,link=True,
            metallib=air.REMOTE+'/f32-partials/mlx.metallib',outputs=[TRIAL+'/cross-runtime-test',TRIAL+'/cross-runtime-test.map'])
    elif action=='run':
        revision=len(list(OUT.glob('006*transport.stdout.log')))+1
        result=TRIAL+'/tests-'+str(revision)+'.json'
        invoke('006-'+str(revision)+'-run',argv=[TRIAL+'/cross-runtime-test','--gtest_filter=AppleCrossRuntime.*','--gtest_output=json:'+result],outputs=[result])
    elif action=='collect':collect()
    else:raise ValueError(action)
