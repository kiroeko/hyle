from pathlib import Path
import hashlib,json,zipfile

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
DEST=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

assert (OUT/'row-projection-next.json').is_file()
facts=read(OUT/'results/final-identities.json')
test=read(OUT/'results/tests-2.json')
assert test['tests']==1 and test['failures']==0 and test['errors']==0
assert facts['terminal']['exit']==0 and facts['terminal']['terminal']
sources=read(OUT/'staged-sources.json')
for row in sources:
 assert ident(ROOT/row['path'])['sha256']==row['sha256'],row['path']
summary=dict(
 status='actual-cross-runtime-consumer-pass-existing-architecture-no-product-mechanism-added',
 tests=dict(passed=1,total=1,name='AppleCrossRuntime.ProducerCopyUsesOriginalFrontierAndKeepsTwoSlots'),
 hardware=read(OUT/'results/inspect.json')['hardware'],
 behavior=[
  'Two actual Apple Context/Runtime/MemoryResource/ExecutionSource owners, one public graph and two original Invocation slots.',
  'Required A Abs -> B Neg compiles to two native regions plus one 16-byte producer-owned native Copy; no shared Queue.',
  'HostWait reject fails cold replay preparation; allow uses original frontier and optional original progress service.',
  'Original A FIFO gate holds real producer jobs; both public Completions remain Pending and foreign successor is not admitted early.',
  'Two changed runs per slot give bit-exact independently computed -abs(input) values.',
  'Escaped GraphOutput protects slot0 while slot1 replays; exported readonly Array survives GraphOutput release and slot0 reprepare/replay.',
 ],
 changes=['Permanent cross-runtime consumer and CMake target; correct stale architecture claim of missing bridge. Product execution mechanisms unchanged.'],
 build=dict(fresh_translation_units=4,native_or_sdk_rebuild=False,current_map_owners=facts['selected_owners']),
 investigation=[
  'Initial link script accidentally kept both old and fresh operation owners; corrected by replacement. No product issue.',
  'Initial regression required the destination default domain B. Actual consumer capability also legally accepts shared domain A; narrowed that assertion, keeping producer Copy/bytes/ordering/math/lifetimes.',
 ],
 limits=[
  'One ordinary math bridge, not a new paged sparse chain, whole model, throughput or all-runtime import proof.',
  'The bridge performs actual payload copy and declared HostWait; no zero-copy or allocation-free claim.',
  'Failure/cancel/close lifetime was source-reviewed against existing original owners; no new fault injection in this consumer.',
  'Row-cache projected permission/cold layout still has ordinary-singleton constraints; native region integration and Apple/Vulkan five-port paged scoring remain incomplete.',
  'Full-model numerical acceptance, fair tokens/s and inherited eight-model/22-profile review remain active.',
 ],
 final_source=ident(ROOT/'tests/graph_route_apple/cross_runtime_test.cc'))
save(OUT/'summary.json',summary)
plan=dict(root=str(Path(facts['cleanup_files'][0]['path']).parent).replace('\\','/'),
 files=facts['cleanup_files'],retain=facts['retained_objects'])
# Windows Path does not parse POSIX parents: derive from the authenticated file.
plan['root']=facts['cleanup_files'][0]['path'].rsplit('/',1)[0]
save(OUT/'cleanup-plan.json',plan)
(OUT/'previous-test.ps1').write_bytes((ROOT/'test.ps1').read_bytes())
archive=DEST/'apple-cross-runtime.zip';assert not archive.exists()
rows=[p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
 and p.name not in {'archive-receipt.json','cleanup-result.json'}]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(rows):z.write(p,'stage/'+p.relative_to(OUT).as_posix())
 for row in sources:z.write(ROOT/row['path'],'current/'+row['path'])
 for rel in ['tests/graph_route_apple/CMakeLists.txt','docs/architecture/compute-design.md','docs/developer/current-work.md']:
  z.write(ROOT/rel,'current/'+rel)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in rows:assert hashlib.sha256(z.read('stage/'+p.relative_to(OUT).as_posix())).hexdigest()==ident(p)['sha256']
 entries=len(z.namelist())
receipt=dict(archive=ident(archive),entries=entries,cleanup_files=len(plan['files']),cleanup_bytes=sum(x['bytes'] for x in plan['files']))
save(OUT/'archive-receipt.json',receipt)
save(DEST/'apple-cross-runtime-results.json',dict(**summary,archive=receipt['archive']))
print(json.dumps(receipt,indent=2))
