from pathlib import Path
import json,subprocess,time,hashlib,sys
r=Path.cwd();base=r.parent
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
records=json.loads((base/'commands.json').read_text());cc=next(x['command'] for x in reversed(records) if x['tag']=='test-compile');ln=next(x['command'] for x in reversed(records) if x['tag']=='link')
source=r/'tests/compute_route_apple/gather_elements_test.cc';obj=r/'test.o';exe=r/'gather-edge'
cc=[str(source) if x==str(base/'tests/compute_route_apple/gather_elements_test.cc') else str(obj) if x==str(base/'test.o') else x for x in cc]
ln=[str(exe) if x==str(base/'gather-elements') else str(obj) if x==str(base/'test.o') else '-Wl,-map,'+str(r/'gather-edge.map') if x.startswith('-Wl,-map,') else x for x in ln]
if not (r/'mlx.metallib').exists():(r/'mlx.metallib').symlink_to(base/'mlx.metallib')
assert (r/'mlx.metallib').resolve()==(base/'mlx.metallib').resolve()
new=[]
for tag,args in [('test-compile',cc),('link',ln),('edge-test',[str(exe),'--gtest_filter=AppleGatherElements.NarrowValuesKeepSubnormalsSignedZeroAndInfinity'])]:
 t=time.monotonic();p=subprocess.run(args,cwd=r,capture_output=True,timeout=180);(r/(tag+'.stdout.log')).write_bytes(p.stdout);(r/(tag+'.stderr.log')).write_bytes(p.stderr);new.append(dict(tag=tag,command=args,cwd=str(r),exit=p.returncode,seconds=time.monotonic()-t));(r/'commands.json').write_text(json.dumps(new,indent=2)+'\n');print(tag,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-3500:]);sys.exit(p.returncode)
print((r/'edge-test.stdout.log').read_text())
(r/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [source,obj,exe]],indent=2)+'\n')
