from pathlib import Path
import re
root=Path.cwd();path=root/'tests/graph_batch/native_paged_joint_risk_fixture.h'
s=path.read_text(encoding='utf-8');start=s.index('inline Status domain_checks(');cold=s.index('inline Status cold_failures(',start)
d=s[start:cold];f=s[cold:]
def common(body):
    body=body.replace('#if !defined(HYLE_JOINT_PAGE_APPLE)\n  hyle::sched::BlockingPool completion_waiters(hyle::mem::system_allocator(),1);\n#endif','hyle::sched::BlockingPool workers(hyle::mem::system_allocator(),1);')
    body=re.sub(r'#if defined\(HYLE_JOINT_PAGE_APPLE\)\n(.*?)\n#else\n.*?\n#endif',lambda m:m.group(1),body,flags=re.S)
    body=body.replace('.prepare_replay()', '.prepare_replay(lanes)').replace('.submit()', '.submit(lanes)')
    return body
d=common(d);f=common(f)
a=d.index('  auto env=');b=d.index('  hyle::sched::Scheduler',a)
d=d[:a]+'''  HYLE_ASSIGN_OR_RETURN(auto env,environment(cpu,native,device,staging));
  HYLE_ASSIGN_OR_RETURN(auto shape,graph(data));
  HYLE_ASSIGN_OR_RETURN(auto foreign,c::BatchSchema::create(data.schema.capacity()));
  const auto host=data.layout.host();HYLE_ASSIGN_OR_RETURN(auto foreign_layout,foreign.version(host));
  HYLE_ASSIGN_OR_RETURN(auto two,graph(data,true));HYLE_ASSIGN_OR_RETURN(auto program,compile(two,env));
  for(std::size_t i=0;i<program.report.step_count();++i){HYLE_ASSIGN_OR_RETURN(auto step,program.report.step(i));
    for(std::size_t j=0;j<step.node_count;++j){HYLE_ASSIGN_OR_RETURN(auto node,program.report.step_node(i,j));
      if(std::ranges::any_of(two.layouts,[&](const auto&entry){return entry.node==node;}))
        HYLE_RETURN_IF_ERROR(require(step.target==native_target && step.runtime.mode==c::ProviderRuntimeMode::kDelegated,
            "required native page silently selected another implementation"));}}
''' + d[b:]
d=d.replace('program.create_invocation(scheduler,queue)','create(program,scheduler,workers)')
d=d.replace('  const std::array incomplete', '''  HYLE_ASSIGN_OR_RETURN(auto lanes,queues(program.report,queue));HYLE_ASSIGN_OR_RETURN(auto outputs,output_pools(two));
  HYLE_RETURN_IF_ERROR(require(!g::batch::prepare(slot,lanes,{}).ok() && !slot.submit(lanes),"missing owned layout set admitted"));
  for(unsigned misuse:{1U,2U}){
    HYLE_ASSIGN_OR_RETURN(auto bad,graph(data,false,false,misuse));auto made=compile(bad,env);
    if(made){HYLE_ASSIGN_OR_RETURN(auto denied,create(*made,scheduler,workers));HYLE_ASSIGN_OR_RETURN(auto bad_lanes,queues(made->report,queue));
      HYLE_RETURN_IF_ERROR(g::batch::prepare(denied,bad_lanes,bad.layouts));
      HYLE_RETURN_IF_ERROR(require(!g::batch::bind(denied,bad.key,data.key_frame).ok(),"capacity publisher or ordinary extra reader acquired page permission"));}
  }
  HYLE_ASSIGN_OR_RETURN(auto foreign_graph,graph(data,true));auto wrong_nodes=two.layouts;wrong_nodes[0].node=foreign_graph.layouts[0].node;
  HYLE_RETURN_IF_ERROR(require(!g::batch::prepare(slot,lanes,wrong_nodes).ok(),"foreign graph page node accepted"));
  const std::array incomplete''',1)
d=re.sub(r'slot\.prepare_batch\((\w+)\)',r'g::batch::prepare(slot,lanes,\1)',d)
d=d.replace('prepare(slot,two,data,source)','prepare(slot,lanes,two,data,source,outputs)')
d=d.replace('result(slot,two)','result(slot,lanes,two)')
for v in ['data.next_keys','c::PagedArenaRead{}','wrong_resource']:
    d=d.replace('slot.bind(two.key,'+v+')','g::batch::bind(slot,two.key,'+v+')')
d=d.replace('slot.bind(two.query,data.key_frame).IsFailedPrecondition()','g::batch::bind(slot,two.query,data.key_frame).IsInvalidArgument()')
d=d.replace('empty_program.create_invocation(scheduler,queue)','create(empty_program,scheduler,workers)')
d=d.replace('  HYLE_RETURN_IF_ERROR(prepare(empty,zero,data,empty_query));','  HYLE_ASSIGN_OR_RETURN(auto empty_lanes,queues(empty_program.report,queue));HYLE_ASSIGN_OR_RETURN(auto empty_outputs,output_pools(zero));\n  HYLE_RETURN_IF_ERROR(prepare(empty,empty_lanes,zero,data,empty_query,empty_outputs));')
d=d.replace('empty.bind(zero.key,data.key_frame)','g::batch::bind(empty,zero.key,data.key_frame)')
d=d.replace('empty.prepare_replay(lanes)','empty.prepare_replay(empty_lanes)').replace('result(empty,zero,true)','result(empty,empty_lanes,zero,true)')
f=f.replace('auto env=environment(cpu,native,device,staging);','HYLE_ASSIGN_OR_RETURN(auto env,environment(cpu,native,device,staging));')
f=f.replace('program.create_invocation(scheduler,queue)','create(program,scheduler,workers,fault.ref())')
f=f.replace('  const auto plan_live=fault.live;','  HYLE_ASSIGN_OR_RETURN(auto lanes,queues(program.report,queue));HYLE_ASSIGN_OR_RETURN(auto outputs,output_pools(shape));\n  const auto plan_live=fault.live;',1)
f=re.sub(r'(baseline|slot)\.prepare_batch\(versions\)',r'g::batch::prepare(\1,lanes,versions,{.allocator=fault.ref()})',f)
f=f.replace('prepare(baseline,shape,data,source)','prepare(baseline,lanes,shape,data,source,outputs,fault.ref())')
f=f.replace('prepare(slot,shape,data,source)','prepare(slot,lanes,shape,data,source,outputs,fault.ref())')
f=f.replace('baseline.bind(shape.key,data.key_frame)','g::batch::bind(baseline,shape.key,data.key_frame)').replace('slot.bind(shape.key,data.key_frame)','g::batch::bind(slot,shape.key,data.key_frame)')
f=f.replace('result(slot,shape)','result(slot,lanes,shape)')
a=f.index('  auto capped=');b=f.index('  const std::array limits',a)
f=f[:a]+'''  // The removed per-node metadata cap is now the original shared resource
  // scope. A zero native allowance must reject its actual backing/mirrors.
  const std::array native_limits{c::ResourceBudgetLimit{hyle::mem::system_resource(),SIZE_MAX},c::ResourceBudgetLimit{device.ref(),0},c::ResourceBudgetLimit{staging.ref(),SIZE_MAX}};
  HYLE_ASSIGN_OR_RETURN(auto native_budget,c::ResourceBudget::create({.limits=native_limits,.allow_unattributed=true}));
  auto narrow=compile(shape,env,hyle::mem::system_allocator(),native_budget);
  if(narrow)HYLE_RETURN_IF_ERROR(require(!create(*narrow,scheduler,workers,hyle::mem::system_allocator(),native_budget),"native fixed backing scope budget ignored"));
  auto no_host=env;no_host.domains[0].workspace_budget_bytes=0;auto host_refused=compile(shape,no_host);
  if(host_refused)HYLE_RETURN_IF_ERROR(require(!create(*host_refused,scheduler,workers),"host workspace limit ignored"));
''' + f[b:]
path.write_text(s[:start]+d+f,encoding='utf-8')
