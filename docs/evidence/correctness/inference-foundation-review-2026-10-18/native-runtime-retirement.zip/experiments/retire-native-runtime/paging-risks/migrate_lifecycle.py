from pathlib import Path
import re
root=Path.cwd();path=root/'tests/graph_batch/native_paged_joint_lifecycle.h';s=path.read_text(encoding='utf-8')
s=s.replace('HYLE_ASSIGN_OR_RETURN(auto program,compile(shape,environment(cpu,native,device,staging),metadata.get()));','HYLE_ASSIGN_OR_RETURN(auto env,environment(cpu,native,device,staging));\n    HYLE_ASSIGN_OR_RETURN(auto program,compile(shape,env,metadata.get()));')
s=s.replace('#if !defined(HYLE_JOINT_PAGE_APPLE)\n    hyle::sched::BlockingPool completion_waiters(hyle::mem::system_allocator(),1);\n#endif','hyle::sched::BlockingPool workers(hyle::mem::system_allocator(),1);')
old='''#if defined(HYLE_JOINT_PAGE_APPLE)
    HYLE_ASSIGN_OR_RETURN(auto slot,program.create_invocation(scheduler,queue));
#else
    HYLE_ASSIGN_OR_RETURN(auto slot,program.create_invocation(scheduler,queue,completion_waiters));
#endif'''
new='''    HYLE_ASSIGN_OR_RETURN(auto lanes,queues(program.report,queue));HYLE_ASSIGN_OR_RETURN(auto outputs,output_pools(shape));
    HYLE_ASSIGN_OR_RETURN(auto slot,create(program,scheduler,workers,metadata.get()));'''
assert old in s;s=s.replace(old,new)
s=s.replace('prepare(slot,shape,data,source)','prepare(slot,lanes,shape,data,source,outputs,metadata.get())')
s=s.replace('shape.bindings','shape.layouts').replace('slot.prepare_batch(layouts)','g::batch::prepare(slot,lanes,layouts,{.allocator=metadata.get()})')
s=s.replace('slot.prepare_replay()','slot.prepare_replay(lanes)').replace('slot.submit()','slot.submit(lanes)')
s=s.replace('    HYLE_ASSIGN_OR_RETURN(auto work,slot.submit(lanes));','''    auto submitted=slot.submit(lanes);c::Completion work;Status admission;
    if(submitted)work=std::move(*submitted);
    else{admission=submitted.error();HYLE_RETURN_IF_ERROR(require(!mode && admission.IsFailedPrecondition(),"unexpected pre-acceptance Graph rejection"));}''')
s=s.replace('!work.result()','!slot.result(shape.outputs[0])')
s=s.replace('return slot.close();','return slot.drain();')
s=s.replace('auto terminal=work.wait();','auto terminal=work.valid()?work.wait():admission;')
s=s.replace('const bool expected=!terminal && (!mode?terminal.error().IsFailedPrecondition():','const bool expected=!terminal.ok() && (!mode?terminal.IsFailedPrecondition():')
s=s.replace('terminal.error().IsCancelled()','terminal.IsCancelled()').replace('terminal.error().IsInternal()','terminal.IsInternal()').replace('terminal.error().IsResourceExhausted()','terminal.IsResourceExhausted()')
s=s.replace('joint close returned or released uses','Graph drain returned or released uses').replace('joint pending close lost','Graph pending drain lost')
path.write_text(s,encoding='utf-8')
