from pathlib import Path
p=Path('tests/graph_batch/native_pending_joint_risks.cc')
s=p.read_text()
s=s.replace('namespace joint=jr::joint;','namespace route=jr::route;')
s=s.replace('  HYLE_ASSIGN_OR_RETURN(auto program,jr::compile(shape,jr::environment(cpu,context,device,staging),allocator.ref(),budget));','  HYLE_ASSIGN_OR_RETURN(auto env,jr::environment(cpu,context,device,staging));\n  HYLE_ASSIGN_OR_RETURN(auto program,jr::compile(shape,env,allocator.ref(),budget));')
s=s.replace('#if !defined(HYLE_G01_PAGE_RISK_APPLE)\n  hyle::sched::BlockingPool completion_waiters(hyle::mem::system_allocator(),1);\n#endif','  hyle::sched::BlockingPool completion_waiters(hyle::mem::system_allocator(),1);')
a=s.index('#if defined(HYLE_G01_PAGE_RISK_APPLE)\n  HYLE_ASSIGN_OR_RETURN(auto receiver,program.create_invocation')
b=s.index('  const auto baseline=',a)
s=s[:a]+'''  HYLE_ASSIGN_OR_RETURN(auto lanes,jr::queues(program.report,cpu_queue));
  HYLE_ASSIGN_OR_RETURN(auto outputs,jr::output_pools(shape));
  HYLE_ASSIGN_OR_RETURN(auto receiver,jr::create(program,scheduler,completion_waiters,allocator.ref(),budget));
  std::vector<g::batch::NodeLayout> versions;
  for(const auto&node:shape.layouts)versions.push_back({node.node,layout});
  const auto prepare_sources=[&](std::size_t capacity){return g::batch::prepare(receiver,lanes,versions,
      {.allocator=allocator.ref(),.resource_budget=budget,.max_source_completions=capacity});};
  HYLE_RETURN_IF_ERROR(prepare_sources(0));
'''+s[b:]
s=s.replace('receiver.reserve_pending_sources(2)','prepare_sources(source_capacity)')
s=s.replace('receiver.reserve_pending_sources(mode==Mode::capacity?1:source_capacity)','prepare_sources(mode==Mode::capacity?1:source_capacity)')
s=s.replace('  HYLE_RETURN_IF_ERROR(receiver.bind(shape.query,shape.query_desc,query.read));','  HYLE_RETURN_IF_ERROR(receiver.bind(shape.query,shape.query_desc,query.read));\n  HYLE_RETURN_IF_ERROR(jr::bind_outputs(receiver,shape,outputs));')
s=s.replace('receiver.bind(shape.key,k)','g::batch::bind(receiver,shape.key,k)')
s=s.replace('receiver.bind(shape.query,k)','g::batch::bind(receiver,shape.query,k)')
s=s.replace('receiver.bind(shape.value,v)','g::batch::bind(receiver,shape.value,v)')
s=s.replace('receiver.prepare_replay()','receiver.prepare_replay(lanes)')
s=s.replace('auto result=receiver.submit(std::move(update));','auto result=route::submit(receiver,lanes,std::move(update));')
s=s.replace('receiver.take_update()','route::take_update(receiver)')
s=s.replace('receiver.prepare_batch(versions)','prepare_sources(source_capacity)')
s=s.replace('''  HYLE_RETURN_IF_ERROR(r::require(result.has_value() && !update.valid() && !route::take_update(receiver) &&
      query.pool.stats().active_uses>0,"accepted receiver lost source/native page guard"));''','''  HYLE_RETURN_IF_ERROR(r::require(result.has_value() && !update.valid() && !route::take_update(receiver),
      "accepted receiver lost its original source controls"));
  // Progress admission is asynchronous. Wait only for the real query guard,
  // while the original native source remains gated and cannot retire.
  const auto accepted_deadline=std::chrono::steady_clock::now()+std::chrono::seconds(3);
  while(!query.pool.stats().active_uses && std::chrono::steady_clock::now()<accepted_deadline)
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  HYLE_RETURN_IF_ERROR(r::require(query.pool.stats().active_uses>0,
      "accepted receiver never admitted its actual query use"));''')
s=s.replace('release_native();HYLE_RETURN_IF_ERROR(context.close());\n    HYLE_RETURN_IF_ERROR(r::require(pool.stats()', 'release_native();HYLE_RETURN_IF_ERROR(context.close());scheduler.drain();\n    HYLE_RETURN_IF_ERROR(r::require(pool.stats()')
a=s.index('    release_native();auto outcome=result->wait();')
b=s.index('    const auto unrecovered=',a)
s=s[:a]+'''    release_native();const auto outcome=result->wait();
    HYLE_RETURN_IF_ERROR(r::require(mode==Mode::cancel_after?outcome.IsCancelled():
        (mode==Mode::unknown || mode==Mode::native_rejection)?outcome.IsResourceExhausted():outcome.ok(),
        "receiver original completion did not merge the expected source/suffix terminal"));
    const auto observed=result->wait();
    HYLE_RETURN_IF_ERROR(r::require(observed.code()==outcome.code(),
        "repeated original completion observation changed its cached terminal"));
    std::vector<g::GraphOutput> held_outputs;
#if defined(HYLE_PENDING_MULTI_NATIVE_PRODUCERS)
    if(mode==Mode::success){
      for(const auto output:shape.outputs){
        HYLE_ASSIGN_OR_RETURN(auto owner,receiver.result(output));
        HYLE_ASSIGN_OR_RETURN(auto tensor,owner.tensor());
        HYLE_ASSIGN_OR_RETURN(auto bytes,tensor.description().required_bytes());
        std::vector<float> actual(bytes/sizeof(float));
        HYLE_RETURN_IF_ERROR(tensor.storage().read(std::as_writable_bytes(std::span(actual))));
        for(auto value:actual)HYLE_RETURN_IF_ERROR(r::require(value==-.25F,
            "two real native Abs producers and Graph CPU suffix differ from independent constant-value oracle"));
        held_outputs.push_back(std::move(owner));
      }
    }
#endif
    HYLE_RETURN_IF_ERROR(r::require(query.pool.stats().active_uses==0 && !route::take_update(receiver),
        "retained public completion/output allowed original source reuse"));
    held_outputs.clear();*result={};
'''+s[b:]
s=s.replace('#include "native_paged_joint_risk_fixture.h"','#include "native_paged_joint_risk_fixture.h"\n#include <chrono>\n#include <thread>')
s=s.replace('  const auto release_native=[&]{masked=false;};','  const auto release_native=[&]{masked=false;};\n  struct Release final {std::atomic<bool>& masked;~Release(){masked=false;}}release{masked};')
p.write_text(s)
p=Path('tests/graph_batch/native_paged_joint_risk_fixture.h')
s=p.read_text().replace('auto empty,empty_create(program,scheduler,workers)','auto empty,create(empty_program,scheduler,workers)')
s=s.replace('\nhyle::sched::BlockingPool workers','\n  hyle::sched::BlockingPool workers')
p.write_text(s)
p=Path('tests/graph_batch/native_paged_joint_lifecycle.h')
s=p.read_text().replace('\nhyle::sched::BlockingPool workers','\n    hyle::sched::BlockingPool workers')
p.write_text(s)
