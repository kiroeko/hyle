#include "tests/graph_batch/native_paged_joint_risk_fixture.h"
#include <Windows.h>
namespace jr=hyle_joint_page_risk;
struct Trace final {
 hyle_f5_fault_fixture::Allocator fault;
 void dump(std::size_t bytes) noexcept {
  void* stack[32]{};const auto n=CaptureStackBackTrace(0,32,stack,nullptr);
  const auto base=reinterpret_cast<std::uintptr_t>(GetModuleHandleW(nullptr));
  std::fprintf(stderr,"TRACE failure bytes=%zu nth=%zu base=%p frames=%u\n",bytes,fault.attempts-1,reinterpret_cast<void*>(base),unsigned(n));
  for(unsigned i=0;i<n;++i)std::fprintf(stderr,"RVA %016llx\n",static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(stack[i])-base));
 }
 hyle::mem::AllocatorRef ref() noexcept {
  return {[](void*p,std::size_t bytes,std::size_t a)noexcept->void*{auto&s=*static_cast<Trace*>(p);auto*r=s.fault.ref().allocate(bytes,a);if(!r)s.dump(bytes);return r;},
   [](void*p,void*v,std::size_t bytes,std::size_t a)noexcept{static_cast<Trace*>(p)->fault.ref().deallocate(v,bytes,a);},
   [](void*p,void*v,std::size_t old,std::size_t bytes,std::size_t a)noexcept->void*{auto&s=*static_cast<Trace*>(p);auto*r=s.fault.ref().reallocate(v,old,bytes,a);if(bytes&&!r)s.dump(bytes);return r;},this};
 }
};
hyle::Status check(){
 HYLE_ASSIGN_OR_RETURN(auto cpu,jr::g::cpu::create_context());HYLE_ASSIGN_OR_RETURN(auto native,jr::n::Context::create());
 HYLE_ASSIGN_OR_RETURN(auto device,jr::n::MemoryResource::create(native,jr::n::MemoryKind::kDevice));
 HYLE_ASSIGN_OR_RETURN(auto staging,jr::n::MemoryResource::create(native,jr::n::MemoryKind::kStaging));
 HYLE_ASSIGN_OR_RETURN(auto data,jr::r::inputs(native,device,staging));HYLE_ASSIGN_OR_RETURN(auto shape,jr::graph(data));
 HYLE_ASSIGN_OR_RETURN(auto env,jr::environment(cpu,native,device,staging));
 Trace trace;trace.fault.fail=39;auto result=jr::compile(shape,env,trace.ref());
 std::fprintf(stderr,"TRACE compiled=%d attempts=%zu live=%zu\n",result.has_value(),trace.fault.attempts,trace.fault.live);
 if(result)*result=jr::g::CompiledGraph{};std::fprintf(stderr,"TRACE plan released live=%zu\n",trace.fault.live);
 return hyle::Status::Ok();
}
int main(){auto status=check();if(!status.ok())std::fprintf(stderr,"%.*s\n",int(status.message().size()),status.message().data());return status.ok()?0:1;}


