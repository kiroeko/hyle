from pathlib import Path
root=Path.cwd()
path=root/'tests/graph_batch/native_paged_joint_risk_fixture.h'
s=path.read_text(encoding='utf-8')
s=s.replace('#include <hyle/graph/cpu_apple.h>','#include <hyle/graph/apple.h>')
s=s.replace('#include <hyle/graph/cpu_vulkan.h>\n#include <hyle/sched/blocking.h>','#include <hyle/graph/vulkan.h>')
s=s.replace('#include <hyle/graph/cpu.h>','#include <hyle/graph/cpu.h>\n#include <hyle/graph/batch.h>\n#include <hyle/graph/progress.h>\n#include <hyle/sched/blocking.h>')
s=s.replace('namespace joint=g::cpu_apple;','namespace route=g::apple;').replace('namespace joint=g::cpu_vulkan;','namespace route=g::vulkan;')
s=s.replace('using r::require;','using r::require;\ninline constexpr g::ExecutionTargetId cpu_target{0},native_target{1};\ninline constexpr g::StorageDomainId host_storage{0},native_storage{1};')
s=s.replace('std::vector<g::batch::NativePagedNodeBinding> bindings;','std::vector<g::batch::NodeLayout> layouts;')
s=s.replace('result.bindings.push_back({node,std::move(recipe),layout,{.max_metadata_backing_bytes=4096}});','result.layouts.push_back({node,layout});\n    result.placements.push_back({node,native_target,g::PlacementStrength::kRequired});')
s=s.replace('joint::kCpuTarget','cpu_target')
start=s.index('inline joint::Environment environment(')
end=s.index('struct HostQuery final',start)
s=s[:start]+'''// Test-owned cold environment only; all work uses the ordinary Invocation.
struct Environment final {
  std::array<g::StorageDomain,3> domains;
  std::array<g::ExecutionTarget,2> targets;
};
inline Result<Environment> environment(c::Context& cpu,n::Context& native,n::MemoryResource& device,n::MemoryResource& staging){
  HYLE_ASSIGN_OR_RETURN(auto host,g::ExecutionSource::acquire(cpu));
  HYLE_ASSIGN_OR_RETURN(auto gpu,route::execution_source(native));
  return Environment{{g::StorageDomain{hyle::mem::system_resource()},g::StorageDomain{device.ref()},g::StorageDomain{staging.ref()}},
      {g::ExecutionTarget{host,host_storage},g::ExecutionTarget{gpu,native_storage}}};
}
inline Result<g::CompiledGraph> compile(const GraphData& shape,const Environment& env,
    hyle::mem::AllocatorRef allocator=hyle::mem::system_allocator(),c::ResourceBudget budget={}){
  std::vector<g::ExternalResourceContract> external{{shape.query,host_storage},{shape.key,native_storage},{shape.value,native_storage}};
  for(auto output:shape.outputs)external.push_back({output,host_storage});
  return g::batch::compile(shape.graph,{.storage_domains=env.domains,.targets=env.targets},
      {.node_placements=shape.placements,.external_resources=external,.resource_budget=budget,.allocator=allocator});
}
inline Result<std::vector<g::QueueBinding>> queues(const g::CompileReport& report,c::Queue& queue){
  std::vector<g::QueueBinding> result;
  for(std::size_t i=0;i<report.lane_count();++i){HYLE_ASSIGN_OR_RETURN(auto lane,report.lane(i));
    if(lane.queue_required)result.push_back({lane.lane,&queue});}
  return result;
}
inline Result<g::Invocation> create(const g::CompiledGraph& program,hyle::sched::Scheduler& scheduler,
    hyle::sched::BlockingPool& workers,hyle::mem::AllocatorRef allocator=hyle::mem::system_allocator(),c::ResourceBudget budget={}){
  HYLE_ASSIGN_OR_RETURN(auto slot,program.executable.create_invocation({.resources=g::ResourceOptions{allocator,budget}}));
  HYLE_RETURN_IF_ERROR(g::prepare_progress(slot,scheduler,workers));return slot;
}
using OutputPools=std::vector<c::LeasePool>;
inline Result<OutputPools> output_pools(const GraphData& shape){
  OutputPools result;
  for(auto output:shape.outputs){HYLE_ASSIGN_OR_RETURN(auto desc,shape.graph.value_description(output));
    HYLE_ASSIGN_OR_RETURN(auto bytes,desc.required_bytes());
    HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(hyle::mem::system_resource(),bytes+128,{.max_blocks=1}));result.push_back(std::move(pool));}
  return result;
}
inline Status bind_outputs(g::Invocation& slot,const GraphData& shape,OutputPools& pools){
  for(std::size_t i=0;i<shape.outputs.size();++i){HYLE_ASSIGN_OR_RETURN(auto desc,shape.graph.value_description(shape.outputs[i]));
    HYLE_ASSIGN_OR_RETURN(auto bytes,desc.required_bytes());HYLE_ASSIGN_OR_RETURN(auto writer,pools[i].allocate(std::max<std::size_t>(bytes,1),64));
    HYLE_RETURN_IF_ERROR(slot.bind(shape.outputs[i],desc,std::move(writer)));}
  return Status::Ok();
}
''' + s[end:]
start=s.index('inline Status prepare(')
end=s.index('inline Status domain_checks(',start)
s=s[:start]+'''inline Status prepare(g::Invocation& slot,std::span<const g::QueueBinding> lanes,const GraphData& shape,
    const r::Inputs& data,const HostQuery& source,OutputPools& outputs,
    hyle::mem::AllocatorRef allocator=hyle::mem::system_allocator(),c::ResourceBudget budget={}){
  HYLE_RETURN_IF_ERROR(g::batch::prepare(slot,lanes,shape.layouts,{.allocator=allocator,.resource_budget=budget}));
  HYLE_RETURN_IF_ERROR(slot.bind(shape.query,shape.query_desc,source.read));
  if(shape.layouts[0].layout.facts().query_rows){
    HYLE_RETURN_IF_ERROR(g::batch::bind(slot,shape.key,data.key_frame));HYLE_RETURN_IF_ERROR(g::batch::bind(slot,shape.value,data.value_frame));
  }else{
    HYLE_ASSIGN_OR_RETURN(auto keys,data.keys.read(shape.layouts[0].layout,{}));
    HYLE_ASSIGN_OR_RETURN(auto values,data.values.read(shape.layouts[0].layout,{}));
    HYLE_RETURN_IF_ERROR(g::batch::bind(slot,shape.key,std::move(keys)));HYLE_RETURN_IF_ERROR(g::batch::bind(slot,shape.value,std::move(values)));
  }
  HYLE_RETURN_IF_ERROR(bind_outputs(slot,shape,outputs));return slot.prepare_replay(lanes);
}
inline Status result(g::Invocation& slot,std::span<const g::QueueBinding> lanes,const GraphData& shape,bool empty=false){
  HYLE_ASSIGN_OR_RETURN(auto done,slot.submit(lanes));HYLE_RETURN_IF_ERROR(done.wait());
  for(auto id:shape.outputs){HYLE_ASSIGN_OR_RETURN(auto output,slot.result(id));HYLE_ASSIGN_OR_RETURN(auto tensor,output.tensor());
    HYLE_ASSIGN_OR_RETURN(auto bytes,tensor.description().required_bytes());
    HYLE_RETURN_IF_ERROR(require(empty?bytes==0:bytes>0,"Graph result active size differs"));
    std::vector<float> values(bytes/4);HYLE_RETURN_IF_ERROR(tensor.storage().read(std::as_writable_bytes(std::span(values))));
    for(float value:values)HYLE_RETURN_IF_ERROR(require(std::isfinite(value) && value<=0,"Graph result nonfinite or missed real CPU negative suffix"));}
  return Status::Ok();
}
''' + s[end:]
s=s.replace('.bindings','.layouts')
path.write_text(s,encoding='utf-8')
