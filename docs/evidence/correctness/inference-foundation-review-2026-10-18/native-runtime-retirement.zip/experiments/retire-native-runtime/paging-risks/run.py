from pathlib import Path
import importlib.util, json, hashlib, subprocess, os, time, sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
BASE=ROOT/'.scratch/architecture-refactor-2026-10-18/native-page-semantics/windows'
spec=importlib.util.spec_from_file_location('semantics',BASE/'run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
recipes=module.recipes
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def run(tag,cmd,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';cmd=list(map(str,cmd));row={'tag':tag,'command':cmd,'stdout':stem+'.stdout.log','stderr':stem+'.stderr.log','exit':None}
 rows.append(row);write(OUT/'commands.json',rows)
 compiler=recipes['src/graph/executable.cc'][0]
 env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler,'CMAKE_C_COMPILER':compiler})
 native=read(BASE/'matched-link-base.json')
 torch=next(str(Path(x).parent) for x in native['command'] if x.lower().endswith('torch_cpu.lib'))
 env['PATH']=torch+os.pathsep+env.get('PATH','');env['VSLANG']='1033';start=time.monotonic()
 try:r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW);out,err,code=r.stdout,r.stderr,r.returncode
 except subprocess.TimeoutExpired as e:out,err,code=e.stdout or b'',e.stderr or b'',124
 (OUT/row['stdout']).write_bytes(out);(OUT/row['stderr']).write_bytes(err)
 rows[-1].update(exit=code,seconds=time.monotonic()-start);write(OUT/'commands.json',rows)
 print(stem,code,flush=True)
 if code: print(out.decode(errors='replace')[-5000:]+err.decode(errors='replace')[-5000:],flush=True)
 return code
SOURCES={'native-pending':'src/graph_route_vulkan/native_paged_pending.cc','ggml-cpu':'src/compute_provider_ggml/ggml_cpu_provider.cc','standard-index':'src/compute_provider_ggml/standard_index.cc','aten-cpu':'src/compute_provider_native/aten_cpu_provider.cc','native-cpu':'src/compute_provider_native/native_provider.cc','torch-cpu':'src/compute_provider_native/torch_cpu_program.cc','onednn-norm':'src/compute_provider_onednn/normalization_internal.cc','onednn-cpu':'src/compute_provider_onednn/onednn_provider.cc','cpu-region':'src/graph_route_cpu/ggml_region.cc','onednn-region':'src/graph_provider_onednn/onednn_region_provider.cc','executable':'src/graph/executable.cc','constant_artifact':'src/graph/constant_artifact.cc','compile-oom-trace':'.scratch/architecture-refactor-2026-10-18/retire-native-runtime/paging-risks/compile_oom_trace.cc','resources':'src/graph/resources.cc','submission':'src/graph/submission.cc','batch':'src/graph_batch/batch.cc','leaf':'src/graph_route_vulkan/native_paged_region.cc',
 'ready-risks':'tests/graph_batch/native_paged_joint_risks.cc','pending-risks':'tests/graph_batch/native_pending_joint_risks.cc','native-producer-risks':'tests/graph_batch/native_pending_joint_risks.cc'}
def compile_one(name):
 source=SOURCES[name];orig=recipes.get(source,recipes['tests/graph_batch/native_paged_joint_consumer.cc'])
 cmd=[x for x in orig if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]
 if name=='native-producer-risks':cmd.append('/DHYLE_PENDING_MULTI_NATIVE_PRODUCERS=1')
 cmd += [str(ROOT/source),'/Fo'+str(OUT/(name+'.obj'))]
 before=ident(ROOT/source);headers=[ident(ROOT/'tests/graph_batch'/x) for x in ['native_paged_joint_risk_fixture.h','native_paged_joint_lifecycle.h']] if source.startswith('tests/') else [];code=run(name+'-compile',cmd)
 r={'source':before,'command':cmd,'exit':code,'headers':headers,'source_unchanged':ident(ROOT/source)==before and all(ident(x['path'])==x for x in headers)}
 if not code:r['object']=ident(OUT/(name+'.obj'))
 write(OUT/(name+'-identity.json'),r);return code

def link(name):
 base=read(BASE/'matched-link-base.json');selected=dict(base['selected_sources']);compiled=dict(base['compiled_source_sha256'])
 for key in ['executable', 'constant_artifact', 'resources', 'submission', 'batch', 'leaf', 'native-pending', 'ggml-cpu', 'standard-index', 'aten-cpu', 'native-cpu', 'torch-cpu', 'onednn-norm', 'onednn-cpu', 'cpu-region', 'onednn-region']:
  r=read(OUT/(key+'-identity.json'));assert r['exit']==0 and ident(r['source']['path'])==r['source'];s=Path(r['source']['path']).relative_to(ROOT).as_posix();selected[s]=r['object']['path'];compiled[s]=r['source']['sha256']
 s='src/graph_batch/materialized_invocation.cc';selected[s]=str(ROOT/'.scratch/architecture-refactor-2026-10-18/legacy-native-retirement/public-mla/windows-current-owners/src--graph_batch--materialized_invocation.obj');compiled[s]=ident(ROOT/s)['sha256']
 # These header-only entries are retained by the previous closure as identities,
 # not standalone objects; their actual consumers are the fresh owners above.
 for s in compiled:
  if s.startswith('include/'):compiled[s]=ident(ROOT/s)['sha256']
 for s in selected:
  if not s.startswith('tests/'):assert ident(ROOT/s)['sha256']==compiled[s],s+' stale'
 reverse={p:s for s,p in base['selected_sources'].items()};objects=[]
 for old in base['objects']:
  s=reverse.get(old['path'])
  if s:
   if not s.startswith('tests/'):objects.append(selected[s])
  else:assert ident(old['path'])==old;objects.append(old['path'])
 objects=list(dict.fromkeys(objects));libs=[x for x in base['command'] if x.lower().endswith('.lib')]
 flags=[x for x in base['command'][1:] if not x.lower().endswith(('.obj','.lib')) and not x.upper().startswith(('/OUT:','/MAP:'))]
 cmd=[base['command'][0],*flags,'/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map')),str(OUT/(name+'.obj')),*objects,*libs]
 write(OUT/'matched-link-base.json',{'command':[base['command'][0],*flags,*objects,*libs],'selected_sources':selected,'compiled_source_sha256':compiled,'objects':[ident(x) for x in objects]})
 return run(name+'-link',cmd)
if __name__=='__main__':
 action,*items=sys.argv[1:]
 for name in items:
  code=compile_one(name) if action=='compile' else link(name) if action=='link' else run(name+'-run',[OUT/(name+'.exe')])
  if code:raise SystemExit(code)

