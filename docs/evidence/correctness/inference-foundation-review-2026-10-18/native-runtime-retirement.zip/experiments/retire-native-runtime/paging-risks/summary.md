All three Windows Vulkan paging risk targets passed through the ordinary Graph Invocation.

- Ready: run 090. Exact pages/layout/output-refusal recovery and Q0, all 85 compile / 137 create / 11 prepare / 1 atomic frame-replacement OOM refusals, actual backing/all-host/shared budgets, and all six lifecycle modes passed.
- Pending: run 084. All 11 original source/admission/error/recovery modes passed, including 11 cold source-control OOM refusals, binding budget/OOM rollback, closed-source Update return, and unknown actual-prefix retirement.
- Independent native producers: run 093. Two real F16 Abs owners feed four original F2 controls, two actual page nodes and the CPU suffix; success (-0.25 oracle), second-source cancel and abandon passed.

The unknown fixture observes the actual page-prefix completion fence: the compute submit has no fence and its following transfer carries the real proof. No product behavior was changed to restore the old two-submit assumption. Completion observes terminal work; successful GraphOutput owners retain result reuse. Close stops admission, while drain waits actual work/callback tails and does not implicitly cancel.

Source/API migrations and historical failures are retained. Nine current CPU metadata owners and the required Graph/native host owners were compiled from current sources; existing SDK/kernel libraries were reused. Root owns the matching Apple run. No performance claim or additional matrix. See summary.json, final-targets.json and cleanup-identities.json. All .obj files are retained; no cleanup was executed here.
