from pathlib import Path
import importlib.util,json,hashlib,sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
PRIOR=ROOT/'.scratch/architecture-refactor-2026-10-18/retire-native-runtime/paging-risks'
spec=importlib.util.spec_from_file_location('previous',PRIOR/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.OUT=OUT
read=m.read;write=m.write;ident=m.ident
SOURCE='tests/graph/cpu_vulkan_contracts.cc'
def compile_test():
 orig=m.recipes['tests/graph_batch/native_paged_joint_consumer.cc']
 cmd=[x for x in orig if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc') and x!='/DHYLE_FOUNDATION_A_HYBRID=1']
 cmd += [str(ROOT/SOURCE),'/Fo'+str(OUT/'contracts.obj')]
 sources=[ident(ROOT/SOURCE),ident(ROOT/'tests/graph/cpu_vulkan_waiter_cases.h'),ident(ROOT/'samples/package/graph/cpu_vulkan/main.cc')]
 code=m.run('contracts-compile',cmd)
 row={'sources':sources,'command':cmd,'exit':code,'unchanged':sources==[ident(x['path']) for x in sources]}
 if not code:row['object']=ident(OUT/'contracts.obj')
 write(OUT/'contracts-identity.json',row);return code
def link():
 base=read(PRIOR/'matched-link-base.json')
 # Parent-authorized current batch transaction owner may precede the shared
 # base refresh; use its actual compile receipt, never update a digest alone.
 receipt=read(PRIOR/'batch-identity.json')
 src='src/graph_batch/batch.cc';old=base['selected_sources'][src]
 assert receipt['exit']==0 and ident(receipt['source']['path'])==receipt['source']
 assert ident(receipt['object']['path'])==receipt['object']
 base['selected_sources'][src]=receipt['object']['path']
 base['compiled_source_sha256'][src]=receipt['source']['sha256']
 for row in base['objects']:
  if row['path']==old:row.update(receipt['object'])
 base['command']=[receipt['object']['path'] if x==old else x for x in base['command']]
 write(OUT/'base-current-batch-receipt.json',receipt)
 objects=[x['path'] for x in base['objects']]
 for row in base['objects']:assert ident(row['path'])==row,row['path']
 assert all('graph_route_cpu_vulkan--invocation' not in x.lower() for x in objects)
 drift=[]
 for src,sha in base['compiled_source_sha256'].items():
  if src.startswith('tests/'):continue
  now=ident(ROOT/src)
  if now['sha256']!=sha:drift.append({'source':src,'compiled':sha,'current':now})
 write(OUT/'base-source-drift.json',drift)
 assert not drift, drift
 flags=[x for x in base['command'][1:] if not x.lower().endswith(('.obj','.lib')) and not x.upper().startswith(('/OUT:','/MAP:'))]
 libs=[x for x in base['command'] if x.lower().endswith('.lib')]
 cmd=[base['command'][0],*flags,'/OUT:'+str(OUT/'contracts.exe'),'/MAP:'+str(OUT/'contracts.map'),str(OUT/'contracts.obj'),*objects,*libs]
 write(OUT/'matched-link-inputs.json',{'base':str(PRIOR/'matched-link-base.json'),'objects':[ident(x) for x in [str(OUT/'contracts.obj'),*objects]],'command':cmd})
 return m.run('contracts-link',cmd)
if __name__=='__main__':
 action=sys.argv[1]
 raise SystemExit(compile_test() if action=='compile' else link() if action=='link' else m.run('contracts-run',[OUT/'contracts.exe'],timeout=60))
