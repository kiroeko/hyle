from pathlib import Path
import difflib
import hashlib
import json
import shutil
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
FILES = ["tests/graph_batch/native_paged_node_test.cc", "tests/compute_batch/public_mla_native_consumer.cc"]
phase = sys.argv[1]
identities = []
for relative in FILES:
    source = ROOT / relative
    target = OUT / phase / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if phase == "before" and target.exists():
        raise SystemExit("before snapshot already exists")
    shutil.copy2(source, target)
    data = source.read_bytes()
    identities.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
(OUT / (phase + "-identities.json")).write_text(json.dumps(identities, indent=2) + "\n", encoding="utf-8")
if phase == "candidate":
    diff = []
    for relative in FILES:
        before = (OUT / "before" / relative).read_text(encoding="utf-8")
        after = (ROOT / relative).read_text(encoding="utf-8")
        diff.extend(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
            fromfile="before/" + relative, tofile="candidate/" + relative))
    (OUT / "source.diff").write_text("".join(diff), encoding="utf-8")
print(json.dumps(identities, indent=2))
