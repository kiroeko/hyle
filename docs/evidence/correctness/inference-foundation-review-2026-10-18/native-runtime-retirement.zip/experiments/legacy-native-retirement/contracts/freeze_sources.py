from pathlib import Path
import difflib
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
TESTS = [
    "tests/graph/cpu_apple_contracts.cc",
    "tests/graph/cpu_completion_publication.cc",
]
identities = []
diffs = []
for relative in TESTS:
    source = ROOT / relative
    target = OUT / "candidate" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    data = source.read_bytes()
    identities.append({"path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    original = OUT / "before" / relative
    diffs.extend(difflib.unified_diff(
        original.read_text(encoding="utf-8").splitlines(keepends=True),
        source.read_text(encoding="utf-8").splitlines(keepends=True),
        fromfile="before/" + relative, tofile="candidate/" + relative))
(OUT / "source.diff").write_text("".join(diffs), encoding="utf-8")
(OUT / "source-identities.json").write_text(json.dumps(identities, indent=2) + "\n", encoding="utf-8")
print(json.dumps(identities, indent=2))
