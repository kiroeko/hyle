"""Compile the ordinary Completion publication consumer; link only a frozen matched closure."""
from pathlib import Path
import importlib.util
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[4]
ARCH = ROOT / ".scratch/architecture-refactor-2026-10-18"
spec = importlib.util.spec_from_file_location("consumer_driver",
    ARCH / "legacy-native-retirement/encoded-sampling/windows/run.py")
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.OUT = OUT
driver.MATCH = ARCH / "legacy-native-retirement/encoded-sampling/windows-sampling-boundary/current-base"
driver.SOURCES = {"publication": "tests/graph/cpu_completion_publication.cc"}

def compile_publication():
    source = driver.SOURCES["publication"]
    receipt = OUT / "publication-compile-receipt.json"
    if receipt.exists():
        previous = driver.read(receipt)
        driver.write("publication-compile-receipt-" + previous["source"]["sha256"][:12] + ".json", previous)
    selected_object = OUT / ("publication-" + driver.identity(ROOT / source)["sha256"][:12] + ".obj")
    command = [p for p in driver.recipe()
        if not p.lower().startswith(("/fo", "/fd")) and not p.lower().endswith(".cc")
        and "src\\graph_route_cpu_vulkan" not in p.lower() and p != "/DHYLE_FOUNDATION_A_HYBRID=1"]
    command.extend([str(ROOT / source), "/Fo" + str(selected_object)])
    files = [source, "samples/package/graph/cpu_vulkan/main.cc",
        "include/hyle/compute/operation.h", "include/hyle/graph/executable.h",
        "include/hyle/graph/progress.h", "include/hyle/graph/result.h",
        "include/hyle/compute/detail/generated_result.h", "src/compute/completion_internal.h"]
    before = [driver.identity(ROOT / p) for p in files]
    code = driver.run("publication-compile", command)
    stable = all(driver.identity(r["path"]) == r for r in before)
    row = dict(source=before[0], headers=before[1:], sources_unchanged=stable, command=command, exit=code)
    if not code:
        row["object"] = driver.identity(selected_object)
    driver.write("publication-compile-receipt.json", row)
    return code if code else (0 if stable else 1)

def link_current(path):
    path = Path(path).resolve()
    base = driver.read(path)
    consumer = driver.read(OUT / "publication-compile-receipt.json")
    assert consumer["exit"] == 0 and consumer["sources_unchanged"]
    for value in [consumer["source"], consumer["object"], *consumer["headers"]]:
        assert driver.identity(value["path"]) == value
    selected = dict(base["selected_sources"])
    compiled = dict(base["compiled_source_sha256"])
    objects = list(base["objects"])
    resource_receipt = OUT / "resources-compile-receipt.json"
    if resource_receipt.exists():
        resources = driver.read(resource_receipt)
        assert resources["exit"] == 0 and resources["sources_unchanged"]
        assert driver.identity(resources["source"]["path"]) == resources["source"]
        assert driver.identity(resources["object"]["path"]) == resources["object"]
        source = "src/graph/resources.cc"
        previous = selected[source]
        objects = [resources["object"] if obj["path"] == previous else obj for obj in objects]
        selected[source] = resources["object"]["path"]
        compiled[source] = resources["source"]["sha256"]
    reverse = {p: s for s, p in selected.items()}
    for obj in objects:
        assert driver.identity(obj["path"]) == obj
        source = reverse.get(obj["path"])
        if source and not source.startswith("tests/"):
            assert driver.identity(ROOT / source)["sha256"] == compiled[source], source
    flags = [p for p in base["command"][1:] if not p.lower().endswith((".obj", ".lib"))
        and not p.upper().startswith(("/OUT:", "/MAP:"))]
    libs = [p for p in base["command"] if p.lower().endswith(".lib")]
    command = [base["command"][0], *flags, "/OUT:" + str(OUT / "publication.exe"),
        "/MAP:" + str(OUT / "publication.map"), consumer["object"]["path"],
        *[p["path"] for p in objects], *libs]
    driver.write("publication-link-receipt.json", dict(baseline=driver.identity(path),
        product_objects=objects, consumer=consumer, command=command,
        library_identities=[driver.identity(p) for p in libs if Path(p).is_file()]))
    result = driver.run("publication-link", command)
    if not result:
        data = (OUT / "publication.map").read_text(encoding="utf-8", errors="replace")
        markers = ["@cpu_vulkan@graph@hyle", "@cpu_apple@graph@hyle",
            "graph_route_cpu_vulkan.lib", "graph_route_cpu_apple.lib"]
        matches = [line for line in data.splitlines() if any(marker in line for marker in markers)]
        driver.write("publication-removed-runtime-map-check.json", dict(markers=markers, matches=matches))
        assert not matches
        driver.write("publication-images.json", [driver.identity(OUT / ("publication" + suffix))
            for suffix in [".exe", ".map", ".exp", ".lib"]])
    return result

def compile_resources():
    source = "src/graph/resources.cc"
    receipts = driver.read(ARCH / "retire-native-runtime/paging-risks/commands.json")
    recipe = next(row["command"] for row in receipts if row["tag"] == "resources-compile" and row["exit"] == 0)
    command = [p for p in recipe if not p.lower().startswith(("/fo", "/fd")) and not p.lower().endswith(".cc")]
    before = driver.identity(ROOT / source)
    output = OUT / ("resources-" + before["sha256"][:12] + ".obj")
    command.extend([str(ROOT / source), "/Fo" + str(output)])
    result = driver.run("resources-compile", command)
    stable = driver.identity(ROOT / source) == before
    row = dict(source=before, command=command, exit=result, sources_unchanged=stable)
    if not result:
        row["object"] = driver.identity(output)
    driver.write("resources-compile-receipt.json", row)
    return result if result else (0 if stable else 1)

if __name__ == "__main__":
    action = sys.argv[1]
    if action == "compile":
        result = compile_publication()
    elif action == "compile-resources":
        result = compile_resources()
    elif action == "link":
        if len(sys.argv) != 3:
            raise SystemExit("link requires an explicit current matched-link-base.json")
        result = link_current(sys.argv[2])
    elif action == "run":
        result = driver.run("publication-run", [OUT / "publication.exe"], timeout=90)
    else:
        raise SystemExit("compile / link current-match-directory / run")
    raise SystemExit(result)
