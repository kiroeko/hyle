"""Keep source, commands and results only. Exact image cleanup is delegated to root test.ps1."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

resources = ROOT / "src/graph/resources.cc"
text = resources.read_text(encoding="utf-8")
slice_text = text[text.index("Status Invocation::close()"):]
(OUT / "product-candidate").mkdir(exist_ok=True)
(OUT / "product-candidate/resources-drain.txt").write_text(slice_text, encoding="utf-8")
(OUT / "product-candidate/resources.cc").write_bytes(resources.read_bytes())
(OUT / "drain.diff").write_text("".join(difflib.unified_diff(
    (OUT / "product-before/resources-drain.txt").read_text(encoding="utf-8").splitlines(keepends=True),
    slice_text.splitlines(keepends=True), fromfile="before/resources-drain.txt",
    tofile="candidate/resources-drain.txt")), encoding="utf-8")
(OUT / "product-source-identity.json").write_text(json.dumps(identity(resources), indent=2) + "\n", encoding="utf-8")
for relative in ["samples/package/graph/cpu_vulkan/main.cc", "samples/package/graph/cpu_apple/main.cc"]:
    target = OUT / "included-sources" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / relative, target)

windows = OUT / "windows"
cleanup = dict(root=str(windows),
    files=[identity(windows / ("publication" + suffix)) for suffix in [".exe", ".map", ".exp", ".lib"]],
    retained_stage_objects=[identity(path) for path in sorted(windows.glob("*.obj"))])
(windows / "cleanup.json").write_text(json.dumps(cleanup, indent=2) + "\n", encoding="utf-8")
commands = json.loads((windows / "commands.json").read_text(encoding="utf-8"))
summary = dict(
    consumer="tests/graph/cpu_completion_publication.cc",
    exact_sources=json.loads((OUT / "source-identities.json").read_text(encoding="utf-8")),
    product=identity(resources),
    windows_commands=[dict(tag=row["tag"], exit=row["exit"], stdout=row["stdout"], stderr=row["stderr"]) for row in commands],
    final_result="PASS: both original publication branches, one Scheduler worker and one BlockingPool worker",
    causal_failure="006 run: ordinary close+drain returned before the retained callback tail; same consumer passed at 009 after drain joined original observation",
    unrun_here=["Apple contracts", "Apple publication", "full contract or backend matrix"],
    deleted_files=[])
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
excluded = {".obj", ".exe", ".map", ".exp", ".lib", ".pdb", ".ilk", ".zip", ".pyc"}
archive = OUT / "source-results.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(OUT.rglob("*")):
        if not path.is_file() or path.suffix.lower() in excluded or "__pycache__" in path.parts or path.name == "archive-receipt.json":
            continue
        output.write(path, path.relative_to(OUT).as_posix())
receipt = identity(archive)
(OUT / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
