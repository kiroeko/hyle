"""Reconstruct the exact initial migrated fixtures; verify recorded SHA before saving."""
from pathlib import Path
import hashlib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
target = OUT / "intermediate"
target.mkdir(exist_ok=True)

publication = (ROOT / "tests/graph/cpu_completion_publication.cc").read_text(encoding="utf-8")
publication = publication.replace(
    "        // Ordinary close only stops admission. The original waiting contract\n"
    "        // belongs to drain, including the accepted callback tail.\n"
    "        invocation.close().IgnoreError();\n"
    "        close_terminal = invocation.drain();\n",
    "        close_terminal = invocation.close();\n")
publication = publication.replace("drain escaped the live callback tail", "close escaped the live callback tail")
publication = publication.replace("drain did not join the callback tail", "close did not join the callback tail")
expected = "e88a048b6480c95224fd2f90a7bf04b8277f7e4e9f06ee82fa2b804d904d492e"
data = publication.encode("utf-8")
assert hashlib.sha256(data).hexdigest() == expected
(target / "cpu_completion_publication-close-only.cc").write_bytes(data)

apple = (ROOT / "tests/graph/cpu_apple_contracts.cc").read_text(encoding="utf-8")
start = apple.index("Status require_native_product(")
end = apple.index("Status leased_contracts()", start)
apple = apple[:start] + apple[end:]
apple = apple.replace("                            g::NodePlacement{*graph.node_id(1), kAppleTarget, g::PlacementStrength::kRequired},\n", "")
apple = apple.replace("      g::NodePlacement{*graph.node_id(1), kAppleTarget, g::PlacementStrength::kRequired},\n", "")
for program in ["program", "native_program"]:
    apple = apple.replace("  HYLE_RETURN_IF_ERROR(require_native_product(" + program + ".report, *graph.node_id(1)));\n", "")
apple = apple.replace(
    "  HYLE_RETURN_IF_ERROR(invocation.bind(x, row, input).WithContext(\"leased host input bind\"));\n"
    "  HYLE_RETURN_IF_ERROR(invocation.bind(w, matrix, weight).WithContext(\"leased host weight bind\"));\n",
    "  HYLE_RETURN_IF_ERROR(invocation.bind(x, row, input)); HYLE_RETURN_IF_ERROR(invocation.bind(w, matrix, weight));\n")
apple = apple.replace(
    "  HYLE_RETURN_IF_ERROR(invocation.bind(x, row, input).WithContext(\"leased native input bind\"));\n"
    "  HYLE_RETURN_IF_ERROR(invocation.bind(w, matrix, imported).WithContext(\"leased readonly native weight bind\"));\n",
    "  HYLE_RETURN_IF_ERROR(invocation.bind(x, row, input)); HYLE_RETURN_IF_ERROR(invocation.bind(w, matrix, imported));\n")
expected = "110d600740674778dc1553f5f74ebb3e5bbca00fd759a776f933e469567418f6"
data = apple.encode("utf-8")
assert hashlib.sha256(data).hexdigest() == expected
(target / "cpu_apple_contracts-implicit-middle-placement.cc").write_bytes(data)
print("Both intermediate source byte identities match their actual failed-run receipts.")
