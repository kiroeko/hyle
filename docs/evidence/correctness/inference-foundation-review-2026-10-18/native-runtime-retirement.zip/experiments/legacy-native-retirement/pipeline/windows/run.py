"""Compile migrated pipeline sources; execute only original selected cases."""
from pathlib import Path
import importlib.util,sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[4]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
spec=importlib.util.spec_from_file_location('consumer_driver',ARCH/'legacy-native-retirement/encoded-sampling/windows/run.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
driver.OUT=OUT
driver.MATCH=ARCH/'legacy-native-retirement/encoded-sampling/windows-sampling-boundary/current-base'
driver.SOURCES={'pipeline':'tests/graph/native_joint_pipeline.cc','trace':'tests/graph/cpu_vulkan_pipeline_trace.cc',
    'selected':(OUT/'selected.cc').relative_to(ROOT).as_posix()}

def compile_one(which):
    source=driver.SOURCES[which]
    command=[p for p in driver.recipe() if not p.lower().startswith(('/fo','/fd')) and not p.lower().endswith('.cc')
        and 'src\\graph_route_cpu_vulkan' not in p.lower() and p!='/DHYLE_FOUNDATION_A_HYBRID=1']
    command.extend([str(ROOT/source),'/Fo'+str(OUT/(which+'.obj'))])
    paths=list(dict.fromkeys([source,'tests/graph/native_joint_pipeline.cc','tests/graph/vulkan_pipeline_trace.h',
        'include/hyle/compute/operation.h','include/hyle/graph/executable.h','include/hyle/graph/progress.h',
        'include/hyle/graph/vulkan.h','include/hyle/graph/region_provider.h']))
    before=[driver.identity(ROOT/p) for p in paths]
    code=driver.run(which+'-compile',command)
    stable=all(driver.identity(p['path'])==p for p in before)
    row=dict(source=before[0],headers=before[1:],sources_unchanged=stable,command=command,exit=code)
    if not code:row['object']=driver.identity(OUT/(which+'.obj'))
    driver.write(which+'-compile-receipt.json',row)
    return code if code else (0 if stable else 1)

if __name__=='__main__':
    action,which=sys.argv[1:]
    if action=='compile':code=compile_one(which)
    elif action=='link':code=driver.link(which)
    elif action=='run':code=driver.run(which+'-run',[OUT/'selected.exe',which],timeout=180)
    else:raise SystemExit('compile/link pipeline/trace/selected; run original-case-name')
    raise SystemExit(code)
