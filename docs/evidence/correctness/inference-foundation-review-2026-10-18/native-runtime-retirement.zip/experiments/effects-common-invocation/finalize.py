from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
WIN = STAGE / "windows"
FILES = ("tests/graph/route_effects_test.cc", "tests/graph/public_effect_consumer.cc",
         "tests/graph/native_effect_fixture.h")


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


diff = []
for relative in FILES:
    path = ROOT / relative
    snapshot = STAGE / "candidate" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    lines = path.read_text().splitlines(keepends=True)
    assert all(x.rstrip("\r\n").rstrip() == x.rstrip("\r\n") for x in lines)
    previous = STAGE / "before" / relative
    diff.extend(difflib.unified_diff(previous.read_text().splitlines(keepends=True)
        if previous.exists() else [], lines,
        fromfile="before/" + relative if previous.exists() else "/dev/null",
        tofile="candidate/" + relative))
(STAGE / "source.diff").write_text("".join(diff), encoding="utf-8")
write(STAGE / "source-identities.json", [identity(ROOT / p) for p in FILES])
records = json.loads((WIN / "commands.json").read_text())
assert records[-2]["tag"] == "route-effects-run" and records[-2]["exit"] == 0
assert records[-1]["tag"] == "public-effects-run" and records[-1]["exit"] == 0
result = json.loads((WIN / "route-effects-results.json").read_text())
assert result["tests"] == 1 and result["failures"] == 0
for stem in ("route-effects", "public-effects"):
    receipt = json.loads((WIN / (stem + "-identity.json")).read_text())
    assert receipt["exit"] == 0 and receipt["unchanged"]
    assert all(identity(row["path"]) == row for row in receipt["inputs"])
    assert identity(receipt["object"]["path"]) == receipt["object"]
images = [identity(WIN / (stem + suffix)) for stem in ("route-effects", "public-effects")
          for suffix in (".exe", ".map", ".exp", ".lib")]
objects = [identity(WIN / (stem + ".obj")) for stem in ("route-effects", "public-effects")]
cleanup = dict(files=images, retained_objects=objects, count=len(images),
               bytes=sum(x["bytes"] for x in images), executed=False)
write(WIN / "cleanup-candidates.json", cleanup)
write(WIN / "retained-objects.json", objects)
summary = {
    "status": "windows_vulkan_effects_common_invocation_passed",
    "source": [identity(ROOT / p) for p in FILES],
    "product_changes": [],
    "common_path": "actual Sources/storage domains -> graph::compile -> original Invocation -> report-required CPU Queue bindings -> prepare_replay + prepare_progress -> submit/Completion -> GraphOutput + original native readonly owner",
    "preserved": [
        "Explicit CPU resource write -> required native Neg -> CPU resource read; exact effect memory/object footprints and cross-fragment alias rejection.",
        "Missing effect binding and explicitly required native effect reject without executing a resource touch; no fake native effect capability.",
        "Native mathematical result -3, old GraphOutput blocks reset and survives close; direct native view owns its original output backing.",
        "Accepted CPU write failure keeps state41, reports DataLoss and suppresses downstream observation.",
        "Original controlled CPU gate cancellation retires accepted write41, reports Cancelled and suppresses downstream observation.",
        "Zero-output effect-only graph still executes its required CPU write.",
    ],
    "validation": {"compile": "002/003 strict /W4 /WX PASS",
        "link": "004/005 PASS over matched99 closure plus final input-source-frontier submission.obj",
        "run": "006 FoundationEffects.* 1/1 PASS; 007 standalone normal/accepted-failure/cancel/zero-output exit0",
        "first_failure": "001 compile lacked existing region_provider_test fixture's private plan_state.h include; reused its original src/graph + src/compute flags, no product change.",
        "sdk_or_kernel_rebuild": False, "apple": "not compiled/run by this agent; parent uses its Air closure"},
    "cmake_for_parent": [
        "Standalone tests/graph/public_effect_consumer: select graph+sched and link hyle::graph + hyle::sched.",
        "Any module registration of these two sources needs graph_progress; route_effects retains original graph fixture's private src/graph + src/compute includes and existing CPU/provider test dependencies.",
    ],
    "cleanup": dict(count=cleanup["count"], bytes=cleanup["bytes"]),
    "no_cleanup_executed": True,
}
write(STAGE / "summary.json", summary)
print(json.dumps(dict(summary=identity(STAGE / "summary.json"), source=summary["source"],
    cleanup_count=cleanup["count"], cleanup_bytes=cleanup["bytes"]), indent=2))
