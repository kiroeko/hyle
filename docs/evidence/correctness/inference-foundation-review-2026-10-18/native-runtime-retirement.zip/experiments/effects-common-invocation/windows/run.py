from pathlib import Path
import importlib.util
import json
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = ROOT / ".scratch/architecture-refactor-2026-10-18"
spec = importlib.util.spec_from_file_location("matched_frontier", ARCH / "input-source-frontier/windows/run.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.OUT = OUT

native_commands = base.read(ARCH / "native-inputs/vulkan-consumers/commands.json")
native_test_flags = next(r["command"] for r in reversed(native_commands)
    if r.get("exit") == 0 and any(x.endswith("native_region_test.cc") for x in r.get("command", [])))
ready_recipes = base.read(ARCH / "native-ready-pages/windows/compile-plan.json")
consumer_flags = next(r["command"] for r in ready_recipes
    if r["source"] == "tests/graph_batch/native_paged_joint_consumer.cc")


def compile_one(source, template, stem):
    command = [x for x in template if not x.lower().startswith(("/fo", "/fd"))
               and not x.lower().endswith(".cc")]
    if stem == "route-effects":
        # The reused graph mechanism fixture includes its existing PlanState
        # private header; reuse that target's actual private include flags.
        for flag in base.test_recipe:
            if flag.startswith("/I") and flag.endswith(("src\\graph", "src\\compute", "src/graph", "src/compute")) and flag not in command:
                command.append(flag)
    command.extend([str(ROOT / source), "/Fo" + str(OUT / (stem + ".obj"))])
    inputs = [base.identity(ROOT / source), base.identity(ROOT / "tests/graph/native_effect_fixture.h")]
    if stem == "route-effects":
        inputs.append(base.identity(ROOT / "tests/graph/region_provider_test.cc"))
    result = base.run(stem + "-compile", command)
    record = dict(source=inputs[0], inputs=inputs, command=command, exit=result,
        unchanged=all(x == base.identity(x["path"]) for x in inputs))
    if not result:
        record["object"] = base.identity(OUT / (stem + ".obj"))
    base.write(stem + "-identity.json", record)
    return result or (0 if record["unchanged"] else 1)


def link(stem):
    prior = base.read(ARCH / "input-source-frontier/windows/commands.json")
    linked = next(row["command"] for row in reversed(prior) if row["tag"] == "controls-link" and row["exit"] == 0)
    command = [x for x in linked if not x.upper().startswith(("/OUT:", "/MAP:"))
        and not x.endswith("input-source-frontier-test.obj")]
    if stem == "public-effects":
        command = [x for x in command if Path(x).name.lower() not in ("gtest.lib", "gtest_main.lib")]
    command.extend([str(OUT / (stem + ".obj")), "/OUT:" + str(OUT / (stem + ".exe")),
                    "/MAP:" + str(OUT / (stem + ".map"))])
    base.write(stem + "-link-inputs.json", dict(command=command,
        objects=[base.identity(x) for x in command if x.lower().endswith(".obj")],
        libraries=[base.library_identity(x) for x in command if x.lower().endswith(".lib")]))
    return base.run(stem + "-link", command)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    action, *items = sys.argv[1:]
    for item in items:
        if action == "compile":
            if item == "route-effects":
                code = compile_one("tests/graph/route_effects_test.cc", native_test_flags, item)
            elif item == "public-effects":
                code = compile_one("tests/graph/public_effect_consumer.cc", consumer_flags, item)
            else:
                raise SystemExit(item)
        elif action == "link":
            code = link(item)
        elif action == "run":
            args = [OUT / (item + ".exe")]
            if item == "route-effects":
                args.extend(["--gtest_color=no", "--gtest_filter=FoundationEffects.*",
                             "--gtest_output=json:" + str(OUT / "route-effects-results.json")])
            code = base.run(item + "-run", args)
        else:
            raise SystemExit("compile/link/run route-effects/public-effects")
        if code:
            raise SystemExit(code)
