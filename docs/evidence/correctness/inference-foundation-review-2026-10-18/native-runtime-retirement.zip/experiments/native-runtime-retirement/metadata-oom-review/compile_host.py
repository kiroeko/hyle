"""Only exact cached CXX recipes for the changed CUDA provider host files."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = ROOT / ".scratch/architecture-refactor-2026-10-18"
sys.path.insert(0, str(ROOT / "scripts"))
from hyle_environment import windows_compiler_environment

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

classification = ARCH / "native-runtime-retirement/root/metadata-oom-classification.json"
cached = ARCH / "admitted-queue-sequence/cuda/compile-recipes.json"
recipes = {row["source"].replace("\\", "/"): row for row in read(cached)}
wanted = [row for row in read(classification)
    if "cuda" in row["source"] or "cublas" in row["source"] or "flashinfer" in row["source"]]
headers = [identity(ROOT / name) for name in [
    "include/hyle/compute/operation.h", "include/hyle/compute/detail/provider_internal.h",
    "include/hyle/graph/region_provider.h"] if (ROOT / name).is_file()]
write("inputs.json", dict(classification=identity(classification), recipes=identity(cached),
    selected_sources=wanted, headers=headers, scope="host CXX only; no linking, SDK compilation, kernels or model runtime"))
rows = read(OUT / "commands.json") if (OUT / "commands.json").exists() else []
for selection in wanted:
    source = selection["source"]
    if source not in recipes:
        write("missing-recipe.json", dict(source=source))
        raise SystemExit("No exact cached recipe; stopped: " + source)
    original = recipes[source]["command"]
    assert Path(original[0]).name.lower() == "cl.exe" and source.endswith(".cc")
    output = OUT / (source.replace("src/", "").replace("/", "--").removesuffix(".cc") + ".obj")
    command = [flag for flag in original if not flag.lower().startswith(("/fo", "/fd"))]
    command.append("/Fo" + str(output))
    before = identity(ROOT / source)
    assert before["sha256"] == selection["sha256"], source + " changed after classification"
    assert "/WX" in command and "/W4" in command
    if output.exists() and any(row.get("source") == before and row.get("object") == identity(output)
            and row.get("exit") == 0 for row in rows):
        print("reuse actual successful object", source, flush=True)
        continue
    stem = f"{len(rows) + 1:03d}-" + source.split("/")[-2] + "--" + Path(source).stem
    row = dict(source=before, command=command, stdout=stem + ".stdout.log", stderr=stem + ".stderr.log", exit=None)
    rows.append(row)
    write("commands.json", rows)
    environment = windows_compiler_environment({"CMAKE_CXX_COMPILER": original[0], "CMAKE_C_COMPILER": original[0]})
    environment["VSLANG"] = "1033"
    started = time.monotonic()
    try:
        completed = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True,
            timeout=180, creationflags=subprocess.CREATE_NO_WINDOW)
        stdout, stderr, exit_code = completed.stdout, completed.stderr, completed.returncode
    except subprocess.TimeoutExpired as failure:
        stdout, stderr, exit_code = failure.stdout or b"", failure.stderr or b"", 124
    (OUT / row["stdout"]).write_bytes(stdout)
    (OUT / row["stderr"]).write_bytes(stderr)
    row.update(exit=exit_code, seconds=time.monotonic() - started,
        source_unchanged=identity(ROOT / source) == before)
    if not exit_code:
        row["object"] = identity(output)
    write("commands.json", rows)
    print(stem, "exit=" + str(exit_code), flush=True)
    if exit_code or not row["source_unchanged"]:
        print(stdout.decode(errors="replace")[-6000:] + stderr.decode(errors="replace")[-6000:], flush=True)
        raise SystemExit(exit_code or 1)
assert all(identity(header["path"]) == header for header in headers)
write("summary.json", dict(compiled=len(wanted), passed=len(wanted), linked=False,
    kernels_compiled=False, sdk_compiled=False, model_executed=False, commands=len(rows)))
print("PASS", len(wanted), "changed CUDA provider host translation units", flush=True)
