from pathlib import Path
import difflib
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BEFORE = OUT.parent / "root/before"
classification = json.loads((OUT.parent / "root/metadata-oom-classification.json").read_text())

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

changes = []
for row in classification:
    source = ROOT / row["source"]
    assert identity(source)["sha256"] == row["sha256"]
    original = (BEFORE / row["source"]).read_text(encoding="utf-8")
    candidate = source.read_text(encoding="utf-8")
    changes.append(dict(source=row["source"], sites=row["sites"],
        diff="".join(difflib.unified_diff(original.splitlines(keepends=True),
            candidate.splitlines(keepends=True), fromfile="before/" + row["source"],
            tofile=row["source"], n=3))))
review = dict(files=len(classification), sites=sum(row["sites"] for row in classification),
    changes=changes,
    core=[identity(ROOT / source) for source in ["src/graph/storage_budget.h",
        "src/graph/executable.cc", "src/graph/constant_artifact.cc", "src/compute/provider_internal.h"]],
    conclusion="No concrete misclassification or remaining supplied-allocator raw OOM decline found in this scope",
    facts=[
        "33 changed sites are actual host allocator null results or explicit std::bad_alloc; no geometry/capability check changed",
        "reserve_private sets budget_declined only for quota/unattributed reservation rejection; charge record allocation failure leaves false",
        "Both reserve_compilation_storage and ConstantArtifactCache propagate charge metadata failures as fatal original errors",
        "Provider kError propagates through Compute and Graph; packing get_or_create preserves the original outcome kind",
        "The 11 remaining resource_declined calls are 1 arithmetic overflow, 1 actual packing budget and 9 original vendor/native resource refusals",
        "oneDNN create_brgemm_plan failure now remains error, including supplied-allocator BrgemmPlan metadata allocation; destruction of kernel partials unchanged"],
    boundaries=["No vendor OOM policy rewrite or vendor-internal allocator audit",
        "No numerical/model execution", "Only the 20 changed CUDA-family host translation units are compiled here",
        "The other 9 changed CPU provider/Graph TUs and the 3 core files are statically reviewed here; parent owns their actual host verification"])
(OUT / "static-review.json").write_text(json.dumps(review, indent=2) + "\n", encoding="utf-8")
print(review["files"], "files /", review["sites"], "changed sites; no concrete static issue found")
