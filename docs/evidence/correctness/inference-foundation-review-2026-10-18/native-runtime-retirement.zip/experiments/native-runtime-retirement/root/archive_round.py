from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18'
AIR = BASE / 'apple-page-invocation'
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


groups = [
    ('legacy-native-retirement/pipeline/windows', 'cleanup.json'),
    ('effects-common-invocation/windows', 'cleanup-candidates.json'),
    ('legacy-native-retirement/contracts/windows', 'cleanup.json'),
    ('retire-native-runtime/vulkan-contracts', 'cleanup.json'),
    ('retire-native-runtime/paging-risks', 'cleanup-identities.json'),
]
files, retain = [], []
for relative, name in groups:
    directory = BASE / relative
    plan = load(directory / name)
    rows = plan if isinstance(plan, list) else plan['files']
    targets = [Path(row if isinstance(row, str) else row['path']) for row in rows]
    actual = sorted(p for p in directory.iterdir() if p.suffix in {'.exe', '.map', '.exp', '.lib'})
    assert sorted(targets) == actual, f'unfrozen images in {directory}'
    for row, path in zip(rows, targets):
        assert path.parent == directory and not path.is_symlink()
        now = identity(path)
        if isinstance(row, dict):
            assert row['bytes'] == now['bytes'] and row['sha256'] == now['sha256']
        files.append(now)
    retain.extend(identity(p) for p in sorted(directory.glob('*.obj')))
    for path in directory.glob('*.map'):
        text = path.read_text(errors='replace')
        old = re.findall(r'@cpu_(?:apple|vulkan)@graph@hyle', text)
        assert not old, f'old mixed runtime symbol in {path}'
        members = sorted(set(line.split()[-1] for line in text.splitlines()
                             if re.match(r'\s*[0-9A-Fa-f]{4}:[0-9A-Fa-f]+\s+\S+\s+[0-9A-Fa-f]{8,}\s+', line)))
        path.with_name(path.stem + '-map-members.txt').write_text('\n'.join(members) + '\n')
        path.with_name(path.stem + '-map-check.json').write_text(json.dumps(dict(
            map=now if path == targets[-1] else identity(path), members=len(members), old_mixed_runtime_symbols=0), indent=2) + '\n')
assert len(files) == len(set(row['path'] for row in files))
mac = load(AIR / 'air-results/cleanup.json')
cleanup = dict(windows=dict(files=files, retain=retain), mac=mac)
(OUT / 'cleanup-plan.json').write_text(json.dumps(cleanup, indent=2) + '\n')

# These are the already executed final metadata checks, not native execution.
checks = []
for name, source, count in [('routes', 'tests/tooling/compute_routes_test.py', 13),
                            ('macros', 'tests/tooling/product_macro_contract_test.py', 3)]:
    text = (OUT / (name + '.stderr.log')).read_text(encoding='utf-8-sig')
    assert f'Ran {count} tests' in text and '\nOK' in text and 'FAILED' not in text
    checks.append(dict(command=['python', source], source=identity(ROOT / source), exit=0, tests=count))
(OUT / 'metadata-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
(OUT / 'metadata-configure-first-failure.txt').write_text(
    'Initial metadata-only route checks found missing direct dependencies after new native owners were wired:\n'
    'graph_route_vulkan -> compute (copy_outcome_source.h); graph_route_apple -> mem (std_allocator.h).\n'
    'Source inspection also requires graph_route_apple -> compute/util_core.\n'
    'The manifest now records these actual private dependencies. Existing checks remain enabled.\n'
    'The Apple test now checks the actual selected endpoints and optional progress, rather than a deleted mixed module.\n')

archive_files = {}


def add(path, name):
    assert path.is_file() and not path.is_symlink()
    assert name not in archive_files or archive_files[name] == path
    archive_files[name] = path


scopes = ['legacy-native-retirement/pipeline', 'legacy-native-retirement/contracts',
          'legacy-native-retirement/mla-layout-contracts', 'effects-common-invocation',
          'retire-native-runtime/vulkan-contracts', 'retire-native-runtime/paging-risks',
          'native-runtime-retirement/metadata-oom-review', 'native-runtime-retirement/root']
extensions = {'.json', '.log', '.txt', '.md', '.py', '.ps1', '.cc', '.h', '.mm', '.diff'}
for relative in scopes:
    scope = BASE / relative
    for path in sorted(scope.rglob('*')):
        if not path.is_file() or path.is_symlink() or path.suffix not in extensions:
            continue
        if path.name in {'cleanup-script.txt', 'round-archive-receipt.json', 'cleanup-result.json'}:
            continue
        add(path, 'experiments/' + path.relative_to(BASE).as_posix())
for name in ['air.py', 'air_remote.py']:
    add(AIR / name, 'apple/' + name)
for path in sorted((AIR / 'air-results').iterdir()):
    if path.is_file() and path.suffix in {'.json', '.log', '.txt'}:
        add(path, 'apple/results/' + path.name)

# Keep the actual Hyle source/header closure, not SDKs, weights or binary objects.
final_air = load(AIR / 'air-results/final-source-identities.json')
remote_root = mac['root'] + '/'
for row in [entry['source'] for entry in final_air['compiled_owners']] + final_air['headers']:
    logical = row['path'].removeprefix(remote_root)
    path = ROOT / logical
    if logical.startswith(('include/', 'src/', 'tests/')) and path.is_file():
        assert identity(path)['sha256'] == row['sha256'], logical
        add(path, 'source/' + logical)
for row in load(OUT / 'metadata-oom-classification.json'):
    path = ROOT / row['source']
    assert identity(path)['sha256'] == row['sha256']
    add(path, 'source/' + row['source'])
extras = [
    'cmake/HyleComponents.cmake', 'cmake/HyleComputeRoutes.cmake',
    'include/hyle/visibility.h', 'include/hyle/graph/batch.h',
    'tests/graph/CMakeLists.txt', 'tests/graph_batch/CMakeLists.txt',
    'tests/graph_route_apple/CMakeLists.txt', 'tests/graph_route_vulkan/CMakeLists.txt',
    'tests/graph/cpu_apple_contracts/CMakeLists.txt', 'tests/graph/cpu_vulkan_contracts/CMakeLists.txt',
    'tests/graph/public_effect_consumer/CMakeLists.txt', 'tests/tooling/compute_routes_test.py',
    'tests/tooling/product_macro_contract_test.py', 'tests/graph/cpu_vulkan_contracts.cc',
    'tests/graph/cpu_vulkan_waiter_cases.h', 'tests/graph/cpu_vulkan_pipeline_trace.cc',
    'tests/graph_batch/native_paged_joint_risk_fixture.h', 'tests/graph_batch/native_paged_joint_lifecycle.h',
    'tests/graph_batch/native_paged_joint_risks.cc', 'tests/graph_batch/native_pending_joint_risks.cc',
    'docs/architecture/compute-design.md', 'docs/architecture/graph-design.md',
    'docs/user/graph.md', 'docs/user/apple-compute.md', 'docs/user/batch-attention.md',
    'docs/developer/current-work.md', 'test.ps1',
]
for name in extras:
    add(ROOT / name, 'source/' + name)
tracked = [name for name in extras if name != 'test.ps1'] + [row['source'] for row in load(OUT / 'metadata-oom-classification.json')]
(OUT / 'product-and-docs.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', *tracked], cwd=ROOT))
add(OUT / 'product-and-docs.diff', 'product-and-docs.diff')
add(OUT / 'cleanup-plan.json', 'cleanup-plan.json')
summary = dict(
    windows_native=dict(ready_run='090', pending_run='084', independent_producers_run='093', contracts_run='012', all_exit=0),
    apple_native=dict(contracts='232', publication='234', mla='245', descriptor_tests='247',
                      pending_64_steps='249', pending_risks='257', independent_producers='259', ready_risks='265', all_exit=0),
    metadata_tests=checks,
    source_retirement=load(OUT / 'retirement-result.json'),
    cleanup_planned=dict(windows_bytes=sum(row['bytes'] for row in files), windows_files=len(files),
                         mac_bytes=sum(row['bytes'] for row in mac['files']), mac_files=len(mac['files'])),
    limits=['No SDK/kernel rebuild; current object caches retained.',
            'CUDA metadata classification: 20 host owners strict compiled, not newly linked/model executed.',
            'No Linux native execution or throughput measurement in this round.',
            'Apple pending consumer selected D64 causal=1, both dtypes/original64 steps; not full geometry matrix.',
            'Apple plain F16/BF16 two-pass F32 partial kernels and full Qwen numerical acceptance remain open.'])
(OUT / 'round-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
add(OUT / 'round-summary.json', 'round-summary.json')
archive = EVIDENCE / 'native-runtime-retirement.zip'
assert not archive.exists(), 'Do not replace a frozen archive'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(archive_files.items()):
        z.write(path, name)
    z.writestr('archive-manifest.json', json.dumps([
        dict(entry=name, **identity(path)) for name, path in sorted(archive_files.items())], indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.read('cleanup-plan.json') == (OUT / 'cleanup-plan.json').read_bytes()
(OUT / 'round-archive-receipt.json').write_text(json.dumps(identity(archive), indent=2) + '\n')
print(json.dumps(dict(archive=identity(archive), entries=len(archive_files), cleanup=summary['cleanup_planned'])))
