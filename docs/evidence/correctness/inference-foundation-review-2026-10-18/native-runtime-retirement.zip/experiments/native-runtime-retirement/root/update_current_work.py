from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[3]
path = root / 'docs/developer/current-work.md'
text = path.read_text(encoding='utf-8')
start = text.index('当前不再按旧结构扩专用接口。')
end = text.index('\n## 已确认范围', start)
(out / 'current-work-before-this-round.md').write_bytes(path.read_bytes())
replacement = '''当前普通调用链已回到一份Graph计划与原Invocation：

- Direct/Graph共用实际承载分析；selected prepared说明端口、输出表示、阻塞与资源事实。
  共同核心核依赖、权限、alias和寿命，不再为具体row-cache算子或Provider复制准入名单。
- ExecutionSource保活真实Context/Runtime，QueueRef/QueueSequence负责真实队列身份与本次接纳；
  SubmissionCursor按原依赖的O(S+E)前沿推进。可选prepare_progress只驱动该游标，阻塞粗片段交原BlockingPool。
- caller输出与Apple/Vulkan生成结果共用GraphOutput及退休合同；跨存储搬运使用实际CopyRecording。
  finite family、canonical常量与冷packing共享原制品，可变bindings、workspace、layout与结果代际归独立槽。
- typed WeightBatch、ready/pending分页与状态控制附着原Invocation；owned layout区分Q活动行与KV容量。
  GQA三载荷、MLA两载荷不再要求引擎装配另一套batch Provider或专用协调器。

CPU＋CUDA旧运行时以及CPU＋Apple/Vulkan旧Plan、Invocation、driver均已归档删除，不保兼容入口。
CUDA仅保留冷环境helper；三条混合路线的权重、custom/finite、effects、pipeline和分页消费者复用普通入口。
本批实际Windows/Vulkan与MacBook Air/Apple检查包括64轮页消费、双槽与旧结果、D512/576 MLA、
真实多源pending及取消/关闭/abandon；冷OOM逐点检查没有放宽原数学预算。具体范围见[证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。

真实消费者修出的共同问题包括：ready同布局帧替换缺失、pending冷准备半提交、drain遗漏observer回调尾部，
以及metadata分配失败被误当成可换路由的资源拒绝。已修复并保留对应失败恢复控制。
设备差异继续留在真实适配处：Vulkan固定backing的逃逸结果阻止复用，Apple独立生成Array可跨后续准备保活；
Scheduler空闲不等于GPU退休，取消须显式请求，close只停止接纳，drain等待实际完成。

性能尚未完成收工：Scheduler每轮task/stack仍有原有成本；native metadata镜像容量与必要上传保留，
Apple变KV布局仍可能构建eager数组图。plain低精度two-pass的F32 partial仍待补，不能宣传零热分配或全部数学域覆盖。
可选IO/权重流送依赖、默认Context装配与共同冷编译文件的职责仍需收敛，按实际链路拆解，不增加转发层或第二套核心状态。

完整Qwen3.5-2B CUDA测试消费者已执行24层的23-token prefill→4-token续算→1-token decode，
生成token与独立参考相同，150个观察tensor全finite，但三阶段logits约2%的相对L2差异尚未接受。
首层明显传播定位到同输入RMSNorm→BF16的一个舍入边界；单坐标诊断能复现后续layer0/layer1变化，
仍缺native归约/rsqrt/乘法的中间观察，不能认定或修成fastmath问题。top1/top5相同不构成数值接受。
公平tokens/s对照未完成；本批没有重建SDK/kernel，也没有重跑完整模型或Linux执行。

后续继续按既定8模型/22制品范围补原功能审查遗留，核对融合、量化接线、状态/接受前缀、稀疏分页与连续推理旅程。
架构迁移不等于功能完成，此前约75%仅是旧审查的粗估，不作为当前完成比例。
'''
path.write_text(text[:start] + replacement + text[end:], encoding='utf-8')
print('compressed current-work migration notes:', text[start:end].count('\n'), '->', replacement.count('\n'), 'lines')
