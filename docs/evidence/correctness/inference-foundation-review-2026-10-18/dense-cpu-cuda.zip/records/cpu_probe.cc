#include "tests/graph_ggml_constant_test.h"
#include "src/graph_route_cpu/ggml_region.h"
#include "hyle/compute/backends/cpu.h"
TEST(CpuConstantComponent, DenseRhs) {
  auto context=hyle::compute::Context::create(hyle::compute::cpu::device(),
      hyle::graph::cpu::internal::ggml_regions({})).value();
  ggml_constant_test::dense_rhs(context,hyle::mem::system_resource());
}

#include "tests/compute_models/batched_rope_fixture.h"
#include "tests/compute_provider_native/half_test_support.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/prepared_operation.h"
namespace compute=hyle::compute;
TEST(CpuConstantComponent, BatchedRopePositionsAndFrequenciesUseOriginalNativeOps) {
  namespace fixture = batched_rope_test;
  auto context = compute::Context::create(compute::cpu::device(), compute::ggml_cpu::provider()).value();
  const auto exercise = [&]<class T>() {
    const auto input_desc = compute::TensorDesc::dense(half_test::data_type<T>(),
        std::array<std::int64_t, 4>{2, 3, 2, 8}).value();
    for (const bool requests : {false, true}) for (const bool token_frequency : {false, true})
      for (const auto layout : {compute::RopeLayout::kHalfSplit, compute::RopeLayout::kInterleaved}) {
        SCOPED_TRACE(::testing::Message() << requests << '/' << token_frequency << '/' << int(layout));
        const auto positions_desc = requests ? compute::TensorDesc::dense(compute::DataType::kInt32,
            std::array<std::int64_t, 2>{2, 3}).value() : compute::TensorDesc::dense(
                compute::DataType::kInt32, std::array<std::int64_t, 1>{3}).value();
        const auto frequencies_desc = token_frequency ? compute::TensorDesc::dense(compute::DataType::kFloat32,
            std::array<std::int64_t, 2>{3, 2}).value() : compute::TensorDesc::dense(
                compute::DataType::kFloat32, std::array<std::int64_t, 1>{2}).value();
        auto data = hyle::mem::Buffer::create(hyle::mem::system_resource(), *input_desc.required_bytes(), 256).value();
        auto output = hyle::mem::Buffer::create(hyle::mem::system_resource(), *input_desc.required_bytes(), 256).value();
        auto positions = half_test::buffer<std::int32_t>(std::span(fixture::kPositions).first(requests ? 6 : 3));
        auto frequencies = half_test::buffer<float>(std::span(fixture::kFrequencies).first(token_frequency ? 6 : 2));
        const std::array inputs{compute::ConstTensorView::create(input_desc, data.view()).value(),
            compute::ConstTensorView::create(positions_desc, positions.view()).value(),
            compute::ConstTensorView::create(frequencies_desc, frequencies.view()).value()};
        const auto target = compute::TensorView::create(input_desc, output.view()).value();
        auto prepared = compute::prepare(context, compute::Operation{compute::RoPE{
            .rotary_dimensions = 4, .sequence_axis = -3, .layout = layout}}, inputs, std::array{target});
        ASSERT_TRUE(prepared) << prepared.error().message();
        EXPECT_EQ(prepared->provider().id, compute::ggml_cpu::kProviderId);
        auto invocation = prepared->create_invocation().value();
        auto queue = context.create_queue().value();
        for (int phase = 0; phase < 2; ++phase) {
          const auto source = fixture::data(phase);
          std::vector<T> encoded; for (const auto value : source) encoded.push_back(half_test::encode<T>(value));
          ASSERT_TRUE(data.view().write(std::as_bytes(std::span(encoded))).ok());
          auto done = invocation.submit(queue, inputs, std::array{target});
          ASSERT_TRUE(done) << done.error().message(); ASSERT_TRUE(done->wait().ok());
          const auto expected = fixture::reference(source, fixture::kPositions, requests, token_frequency, layout);
          const auto actual = half_test::read<T>(output);
          for (std::size_t i = 0; i < actual.size(); ++i) half_test::expect_near(actual[i], expected[i]);
        }
      }
  };
  exercise.template operator()<float>();
  exercise.template operator()<hyle::simd::float16_t>();
  exercise.template operator()<hyle::simd::bfloat16_t>();
}

