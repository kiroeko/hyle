#include "hyle/graph/providers/ggml_cuda.h"

#include <algorithm>
#include <array>
#include <exception>
#include <new>
#include <vector>

#include "hyle/graph/region_provider.h"
#include "hyle/compute/model_ops.h"
#include "hyle/mem/buffer.h"
#include "program.h"

namespace hyle::graph::ggml_cuda {
namespace native = compute::ggml_cuda::internal;
namespace {

inline constexpr compute::RoutePolicyId kGgmlCudaRegionPolicy{
    0x48594c4547474355ULL, 1, 1};
inline constexpr std::uint32_t kGgmlCudaRegionPreference = 200;

Result<bool> supported_node(void *context, const Graph &graph,
                            NodeId node) noexcept {
  auto operation = graph.operation(node);
  if (!operation)
    return false; // Symbolic metadata views are not this exact native domain.
  // Attention already lowers to a complete native program through Compute.
  // Keep its independent native program while batching the pure tensor set.
  if (operation->get_if<compute::ScaledDotProductAttention>() ||
      operation->custom_as<compute::model_ops::SinkAttention>())
    return false;
  auto input_count = graph.node_input_count(node);
  auto output_count = graph.node_output_count(node);
  auto effects = graph.node_resource_count(node);
  if (!input_count || !output_count || !effects)
    return std::unexpected(
        Status::InvalidArgument("ggml CUDA region node is invalid"));
  if (*output_count == 0 || *effects != 0)
    return false;
  try {
    std::vector<compute::TensorDesc> inputs(*input_count);
    std::vector<compute::TensorDesc> outputs(*output_count);
    for (std::size_t i = 0; i < *input_count; ++i) {
      auto id = graph.node_input(node, i);
      if (!id)
        return std::unexpected(std::move(id).error());
      auto description = graph.value_description(*id);
      if (!description)
        return false;
      inputs[i] = *description;
    }
    for (std::size_t i = 0; i < *output_count; ++i) {
      auto id = graph.result(node, i);
      if (!id)
        return std::unexpected(std::move(id).error());
      auto description = graph.value_description(*id);
      if (!description)
        return false;
      outputs[i] = *description;
    }
    return native::supports(context, *operation, inputs, outputs);
  } catch (const std::bad_alloc &) {
    return std::unexpected(Status::ResourceExhausted(
        "ggml CUDA region descriptor allocation failed"));
  }
}

Status propose(void *context, const Graph &graph, mem::AllocatorRef allocator,
               RegionProposalWriter &writer) noexcept {
  struct Scratch final {
    mem::AllocatorRef allocator;
    NodeId *data;
    std::size_t capacity;
    ~Scratch() { allocator.deallocate_n(data, capacity); }
  } scratch{allocator, nullptr, graph.node_count()};
  if (scratch.capacity < 2)
    return Status::Ok();
  scratch.data = allocator.allocate_n<NodeId>(scratch.capacity);
  if (!scratch.data)
    return Status::ResourceExhausted(
        "ggml CUDA region discovery allocation failed");
  std::size_t size = 0;
  const auto emit = [&]() -> Result<bool> {
    if (size < 2)
      return true;
    const auto nodes = std::span(scratch.data, size);
    auto contractible = is_region_contractible(graph, nodes, allocator);
    if (!contractible)
      return std::unexpected(std::move(contractible).error());
    if (!*contractible)
      return true;
    return writer.try_add(
        {.nodes = nodes,
         .cost = {.workspace = compute::WorkspaceRequirement{},
                  .persistent_bytes = std::nullopt,
                  .copy_bytes = std::nullopt,
                  .repack_bytes = std::nullopt,
                  .synchronization_count = 2,
                  .dispatch_count = 1},
         .route = 1,
         .replay_class = compute::ProviderReplayClass::kManaged,
         .implementation = compute::ProviderImplementationId{2},
         .policy = kGgmlCudaRegionPolicy,
         .preference = kGgmlCudaRegionPreference});
  };
  // A third-party node inserted between two related ggml nodes does not
  // break their region. The DAG contraction check, not insertion adjacency,
  // decides whether the eligible set has a legal native boundary. A set that
  // leaves and re-enters retains the existing single-operation routes.
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    auto node = graph.node_id(i);
    if (!node)
      return std::move(node).error();
    auto supported = supported_node(context, graph, *node);
    if (!supported)
      return std::move(supported).error();
    if (*supported)
      scratch.data[size++] = *node;
  }
  auto accepted = emit();
  if (!accepted)
    return std::move(accepted).error();
  return Status::Ok();
}

Status qualify(void *context, const RegionCompileRequest &request) noexcept {
  if (!request.graph || request.route != 1 || request.nodes.size() < 2 ||
      request.outputs.empty() || request.has_unknown_effects ||
      !request.effect_accesses.empty())
    return Status::Unimplemented("ggml CUDA region boundary is not admitted");
  for (const auto node : request.nodes) {
    auto supported = supported_node(context, *request.graph, node);
    if (!supported)
      return std::move(supported).error();
    if (!*supported)
      return Status::Unimplemented(
          "ggml CUDA region contains an unsupported node");
  }
  return Status::Ok();
}
Status resources(void *context, const RegionCompileRequest &request,
                 mem::AllocatorRef,
                 std::span<compute::detail::ResourceBindingRequirement> inputs,
                 std::span<compute::detail::ResourceBindingRequirement> outputs,
                 RegionResourceProposal *proposal) noexcept {
  *proposal = {};
  HYLE_RETURN_IF_ERROR(qualify(context, request));
  std::ranges::fill(inputs, native::kBinding);
  std::ranges::fill(outputs, native::kBinding);
  for (auto &binding : inputs)
    binding.minimum_alignment = 1;
  for (auto &binding : outputs)
    binding.minimum_alignment = 1;
  for (const auto node : request.nodes) {
    const auto operation = request.graph->operation(node).value();
    const auto require = [&](ValueId id) {
      const auto type = request.graph->value_description(id)->data_type();
      const auto alignment = native::boundary_alignment(operation, type);
      // Published values may also be read by another native node. Its input
      // requirement is part of the external output's binding contract too.
      for (std::size_t i = 0; i < request.inputs.size(); ++i)
        if (request.inputs[i] == id)
          inputs[i].minimum_alignment =
              std::max(inputs[i].minimum_alignment, alignment);
      for (std::size_t i = 0; i < request.outputs.size(); ++i)
        if (request.outputs[i] == id)
          outputs[i].minimum_alignment =
              std::max(outputs[i].minimum_alignment, alignment);
    };
    for (std::size_t i = 0; i < request.graph->node_input_count(node).value();
         ++i)
      require(request.graph->node_input(node, i).value());
    for (std::size_t i = 0;
         i < request.graph->node_output_count(node).value(); ++i)
      require(request.graph->result(node, i).value());
  }
  *proposal = {.runtime = native::kRuntime,
               .workspace_resource = native::kBinding};
  return Status::Ok();
}

struct Artifact final {
  compute::detail::ProviderPrepared native;
};
struct PackedBfloatWeights final {
  mem::Buffer storage;
  compute::TensorDesc description;
};
Status pack_bfloat_weights(void *context, compute::ConstTensorView source,
                          mem::MemoryResourceRef resource,
                          mem::AllocatorRef allocator,
                          ConstantArtifactPayload *output) noexcept {
  void *storage = allocator.allocate(sizeof(PackedBfloatWeights),
                                      alignof(PackedBfloatWeights));
  if (!storage)
    return Status::ResourceExhausted("ggml CUDA packed weight metadata");
  auto *packed = ::new (storage) PackedBfloatWeights;
  *output = {packed, +[](void *opaque, mem::AllocatorRef owner) noexcept {
    auto *value = static_cast<PackedBfloatWeights *>(opaque);
    value->~PackedBfloatWeights();
    owner.deallocate(value, sizeof(PackedBfloatWeights),
                     alignof(PackedBfloatWeights));
  }};
  HYLE_ASSIGN_OR_RETURN(packed->description, compute::TensorDesc::dense(
      compute::DataType::kFloat32, source.description().dimensions()));
  HYLE_ASSIGN_OR_RETURN(auto bytes, packed->description.required_bytes());
  HYLE_ASSIGN_OR_RETURN(packed->storage,
                       mem::Buffer::create(resource, bytes, 256));
  HYLE_ASSIGN_OR_RETURN(auto target, compute::TensorView::create(
      packed->description, packed->storage.view()));
  return native::widen_bfloat_constant(context, source, target, allocator);
}

compute::ProviderPrepareOutcome
pack_constant_experts(void *context, const RegionCompileRequest &request,
                      std::span<const ValueId> values,
                      native::Recipe &recipe) {
  if (!request.constant_artifacts.available())
    return compute::ProviderPrepareOutcome::prepared();
  std::vector<std::uint32_t> replacements(values.size(), UINT32_MAX);
  for (auto &node : recipe.nodes) {
    if (!node.operation.custom_as<compute::model_ops::GroupedMatMul>())
      continue;
    const auto original = node.inputs[0];
    const auto &description = recipe.values[original];
    if (!description.is_plain() ||
        description.data_type() != compute::DataType::kBFloat16)
      continue;
    const auto source = std::ranges::find_if(request.constants,
        [&](const auto &constant) { return constant.value == values[original]; });
    if (source == request.constants.end())
      continue; // A rebindable weight is never packed or cached.
    if (replacements[original] == UINT32_MAX) {
      const auto input = std::ranges::find(request.inputs, values[original]);
      if (input == request.inputs.end())
        return compute::ProviderPrepareOutcome::error(Status::Internal(
            "ggml CUDA constant weight misses region boundary"));
      const auto packed_description = compute::TensorDesc::dense(
          compute::DataType::kFloat32, description.dimensions());
      if (!packed_description)
        return compute::ProviderPrepareOutcome::error(packed_description.error());
      const auto bytes = packed_description->required_bytes().value();
      const auto resource = request.input_resources[
          static_cast<std::size_t>(input - request.inputs.begin())];
      ConstantArtifactView result;
      const auto outcome = request.constant_artifacts.get_or_create(
          values[original],
          {.key = {0x4747435542463332ULL, 1},
           .storage = resource, .packed_bytes = bytes,
           .persistent_bytes = sizeof(PackedBfloatWeights),
           // The persistent device payload is exact. The native cold backend
           // may allocate private handles/workspace, so its peak is unknown.
           .private_storage = {.resident_bytes = bytes,
                               .peak_bytes = std::nullopt}},
          &pack_bfloat_weights, context, &result);
      if (outcome.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
        return outcome;
      const auto &packed = *static_cast<const PackedBfloatWeights *>(result.state);
      auto binding = compute::ConstTensorView::create(
          packed.description, packed.storage.view());
      if (!binding)
        return compute::ProviderPrepareOutcome::error(std::move(binding).error());
      const auto id = static_cast<std::uint32_t>(recipe.values.size());
      recipe.values.push_back(packed.description);
      recipe.constants.push_back({id, std::move(*binding)});
      replacements[original] = id;
    }
    node.inputs[0] = replacements[original];
  }
  return compute::ProviderPrepareOutcome::prepared();
}
void destroy(void *value, mem::AllocatorRef allocator) noexcept {
  auto *artifact = static_cast<Artifact *>(value);
  if (!artifact)
    return;
  artifact->native.vtable->destroy_prepared(artifact->native.state, allocator);
  artifact->~Artifact();
  allocator.deallocate(artifact, sizeof(Artifact), alignof(Artifact));
}
compute::AliasSupport alias(void *, std::size_t, std::size_t) noexcept {
  return {};
}
Status create_invocation(void *value, mem::AllocatorRef allocator,
                         mem::BufferView workspace, void **output) noexcept {
  const auto &artifact = static_cast<Artifact *>(value)->native;
  return artifact.vtable->create_invocation(artifact.state, allocator,
                                            workspace, output);
}
// Both Direct and Graph use the same invocation callbacks; this table keeps
// only an immutable pointer to that table, never a second execution program.
struct Invocation final {
  const compute::detail::ProviderPreparedVTable *vtable = nullptr;
  void *state = nullptr;
};
Status create_region_invocation(void *value, mem::AllocatorRef allocator,
                                mem::BufferView workspace,
                                void **output) noexcept {
  *output = nullptr;
  void *storage = allocator.allocate(sizeof(Invocation), alignof(Invocation));
  if (!storage)
    return Status::ResourceExhausted(
        "ggml CUDA region invocation allocation failed");
  const auto &artifact = static_cast<Artifact *>(value)->native;
  auto *invocation = ::new (storage) Invocation{artifact.vtable, nullptr};
  *output = invocation;
  return create_invocation(value, allocator, workspace, &invocation->state);
}
void destroy_region_invocation(void *value,
                               mem::AllocatorRef allocator) noexcept {
  auto *invocation = static_cast<Invocation *>(value);
  if (!invocation)
    return;
  invocation->vtable->destroy_invocation(invocation->state, allocator);
  invocation->~Invocation();
  allocator.deallocate(invocation, sizeof(Invocation), alignof(Invocation));
}
compute::detail::EnqueueResult
submit(void *value, void *lane, compute::Queue &queue,
       std::span<const compute::ConstTensorView> inputs,
       std::span<const compute::TensorView> outputs) noexcept {
  const auto &artifact = static_cast<Artifact *>(value)->native;
  return artifact.vtable->shared_submit(artifact.state,
                                        static_cast<Invocation *>(lane)->state,
                                        queue, inputs, outputs);
}
const ProviderRegionPreparedVTable kPrepared{
    .destroy_prepared = &destroy,
    .alias_support = &alias,
    .create_invocation = &create_region_invocation,
    .destroy_invocation = &destroy_region_invocation,
    .shared_submit = &submit};

compute::ProviderPrepareOutcome
compile(void *context, const RegionCompileRequest &request,
        mem::AllocatorRef allocator, ProviderRegionPrepared *output) noexcept {
  *output = {};
  auto status = qualify(context, request);
  if (!status.ok())
    return compute::ProviderPrepareOutcome::unsupported(std::move(status));
  try {
    native::Recipe recipe;
    std::vector<ValueId> values(request.inputs.begin(), request.inputs.end());
    for (std::uint32_t i = 0; i < values.size(); ++i)
      recipe.inputs.push_back(i);
    for (const auto node : request.nodes)
      for (std::size_t port = 0;
           port < request.graph->node_output_count(node).value(); ++port)
        values.push_back(request.graph->result(node, port).value());
    const auto local = [&](ValueId value) -> std::uint32_t {
      return static_cast<std::uint32_t>(std::ranges::find(values, value) -
                                        values.begin());
    };
    for (const auto id : values)
      recipe.values.push_back(request.graph->value_description(id).value());
    for (const auto node : request.nodes) {
      native::Node lowered{request.graph->operation(node).value(), {}, {}};
      for (std::size_t port = 0;
           port < request.graph->node_output_count(node).value(); ++port)
        lowered.outputs.push_back(
            local(request.graph->result(node, port).value()));
      for (std::size_t i = 0; i < request.graph->node_input_count(node).value();
           ++i) {
        const auto id = local(request.graph->node_input(node, i).value());
        if (id >= values.size())
          return compute::ProviderPrepareOutcome::error(Status::InvalidArgument(
              "ggml CUDA region misses an input boundary"));
        lowered.inputs.push_back(id);
      }
      recipe.nodes.push_back(std::move(lowered));
    }
    for (const auto id : request.outputs)
      recipe.outputs.push_back(local(id));
    const auto packing = pack_constant_experts(context, request, values, recipe);
    if (packing.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
      return packing;
    void *storage = allocator.allocate(sizeof(Artifact), alignof(Artifact));
    if (!storage)
      return compute::ProviderPrepareOutcome::resource_declined(
          Status::ResourceExhausted(
              "ggml CUDA region artifact allocation failed"));
    auto *artifact = ::new (storage) Artifact;
    const auto outcome = native::compile(context, std::move(recipe), allocator,
                                         &artifact->native);
    if (!artifact->native.state) {
      artifact->~Artifact();
      allocator.deallocate(artifact, sizeof(Artifact), alignof(Artifact));
      return outcome;
    }
    *output = {.vtable = &kPrepared,
               .state = artifact,
               .properties = {.workspace = {},
                              .persistent_bytes = std::nullopt,
                              // Existing device buffers bind directly at the
                              // boundary. Native materialization cost remains
                              // unknown in the proposal, not a free replay.
                              .copy_bytes = 0,
                              .synchronization_count = 2,
                              .dispatch_count = 1,
                              .runtime = native::kRuntime,
                              .invocation_private_bytes = std::nullopt}};
    return outcome;
  } catch (const std::bad_alloc &) {
    return compute::ProviderPrepareOutcome::error(
        Status::ResourceExhausted("ggml CUDA region recipe allocation failed"));
  } catch (const std::exception &error) {
    return compute::ProviderPrepareOutcome::error(
        Status::Internal(error.what()));
  }
}
const RegionProviderVTable kRegion{
    .propose = &propose, .propose_resources = &resources, .compile = &compile};
} // namespace

compute::Provider provider() noexcept {
  return native::with_extension(kRegionProviderExtensionId, &kRegion);
}
} // namespace hyle::graph::ggml_cuda
