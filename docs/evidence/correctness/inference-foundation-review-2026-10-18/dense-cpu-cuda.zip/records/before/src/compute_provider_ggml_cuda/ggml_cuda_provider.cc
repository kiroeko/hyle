#include "program.h"
#include "hyle/core/environment.h"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdlib>
#include <exception>
#include <limits>
#include <new>

#include <ggml-backend.h>
#include <ggml-alloc.h>
#include <ggml-cuda.h>
#include <ggml.h>

#include "hyle/compute/route_policy.h"
#include "hyle/compute/model_ops.h"
#include "metadata_arena.h"
#include "native_bridge.h"
#include "native_context.h"
#include "tensor_program.h"

namespace hyle::compute::ggml_cuda {
namespace {

inline constexpr std::string_view kProviderVersion =
    HYLE_GGML_CUDA_PROVIDER_VERSION;

bool default_cublas_precision() noexcept {
#if HYLE_OS_WINDOWS
  std::size_t bytes = 0;
  return ::getenv_s(&bytes, nullptr, 0, "GGML_CUDA_CUBLAS_COMPUTE_TYPE") == 0 &&
         bytes == 0;
#else
  return std::getenv("GGML_CUDA_CUBLAS_COMPUTE_TYPE") == nullptr;
#endif
}

struct Extension final {
  ProviderExtensionId id{};
  const void *table = nullptr;
};
struct Context final {
  CUcontext primary = nullptr;
  int device = -1;
  bool bfloat16_attention = false;
  Extension extension;
};
struct Program final {
  struct IndexCheck final {
    std::uint32_t input = 0;
    std::size_t offset = 0;
    std::size_t count = 0;
    std::int64_t extent = 0;
  };

  CUcontext primary = nullptr;
  int device = -1;
  internal::Recipe recipe;
  std::vector<std::size_t> alignments;
  std::vector<std::vector<float>> hadamards;
  std::vector<std::vector<std::int32_t>> snapshot_indices;
  std::vector<IndexCheck> index_checks;
  std::size_t index_value_count = 0;
};

// Keep small attention programs unchanged. A large standalone attention can
// reuse its row-independent intermediates without changing the KV reduction.
std::int64_t attention_query_block(const internal::Recipe &recipe) noexcept {
  if (recipe.nodes.size() != 1)
    return 0;
  const auto &node = recipe.nodes.front();
  if (!node.operation.get_if<ScaledDotProductAttention>() &&
      !node.operation.custom_as<model_ops::SinkAttention>())
    return 0;
  const auto &query = recipe.values[node.inputs[0]];
  const auto q = query.dimensions();
  const auto k = recipe.values[node.inputs[1]].dimensions();
  if (q[1] <= 1)
    return 0;
  constexpr std::uint64_t threshold = 8ULL * 1024 * 1024;
  constexpr std::uint64_t budget = 64ULL * 1024 * 1024;
  // The admitted full score element count fits int32, so these products fit
  // uint64. Include scale/mask/softmax storage before liveness reuse.
  const auto original_row = 16ULL * static_cast<std::uint64_t>(q[0]) *
      static_cast<std::uint64_t>(q[2]) * static_cast<std::uint64_t>(k[1]);
  if (static_cast<std::uint64_t>(q[1]) <= threshold / original_row)
    return 0;
  const auto rows = std::max<std::uint64_t>(
      1, std::min<std::uint64_t>(128, budget / original_row));
  return rows < static_cast<std::uint64_t>(q[1])
      ? static_cast<std::int64_t>(rows) : 0;
}

// Called only from catch blocks; native namespaces and numbers survive the
// private vendor exception boundary. No exception crosses a public callback.
Status failure() noexcept {
  try {
    throw;
  } catch (const bridge::NativeFailure<cudaError_t> &error) {
    return cuda::status(error.code);
  } catch (const bridge::NativeFailure<CUresult> &error) {
    return cuda::status(error.code);
  } catch (const bridge::NativeFailure<cublasStatus_t> &error) {
    const auto code = error.code == CUBLAS_STATUS_ALLOC_FAILED
                          ? StatusCode::ResourceExhausted
                          : StatusCode::Internal;
    return Status::FromNative(
        code,
        NativeError{NativeErrorDomain::Unknown,
                    static_cast<std::int64_t>(error.code)},
        error.operation);
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("ggml CUDA host allocation failed");
  } catch (const std::exception &error) {
    return Status::Internal(error.what());
  } catch (...) {
    return Status::Internal("ggml CUDA unknown native failure");
  }
}

struct Invocation final {
  CUcontext primary = nullptr;
  ggml_runtime::MetadataArena arena;
  ggml_backend *backend = nullptr;
  cudaStream_t root = nullptr;
  cudaEvent_t entry = nullptr;
  cudaEvent_t exit = nullptr;
  ggml_cgraph *graph = nullptr;
  ggml_gallocr_t attention_allocator = nullptr;
  bool attention_allocated = false;
  std::vector<ggml_tensor *> attention_roots;
  std::vector<ggml_tensor *> tensors;
  std::vector<ggml_tensor *> roots;
  std::vector<ggml_backend_buffer *> buffers;
  std::vector<ggml_backend_buffer *> scratch;
  std::vector<internal::ScalarConstant> constants;
  std::vector<internal::DenseConstant> dense_constants;
  std::vector<ggml_tensor *> views;
  std::vector<void *> pointers;
  std::vector<std::int32_t> index_values;
  bool failed = false;

  Invocation() = default;
  Invocation(const Invocation &) = delete;
  Invocation &operator=(const Invocation &) = delete;
  ~Invocation() {
    cuda::detail::ScopedPrimaryContext scope(primary);
    if (backend)
      (void)bridge::drain(backend);
    if (entry)
      (void)cudaEventDestroy(entry);
    if (exit)
      (void)cudaEventDestroy(exit);
    ggml_gallocr_free(attention_allocator);
    for (auto *buffer : buffers)
      ggml_backend_buffer_free(buffer);
    for (auto *buffer : scratch)
      ggml_backend_buffer_free(buffer);
    ggml_backend_free(backend);
  }

  ggml_tensor *attention(const internal::Node &node) {
    if (const auto sink = node.operation.custom_as<model_ops::SinkAttention>()) {
      auto *context = arena.get();
      auto *query = ggml_permute(context, tensors[node.inputs[0]], 0, 2, 1, 3);
      auto *key = ggml_permute(context, tensors[node.inputs[1]], 0, 2, 1, 3);
      auto *value = ggml_permute(context, tensors[node.inputs[2]], 0, 2, 1, 3);
      auto *scores = ggml_mul_mat(context, key, query);
      (void)ggml_prec_set_acc(scores, GGML_PREC_F32);
      (void)ggml_prec_set_src(scores, GGML_PREC_F32, 1);
      auto *probabilities = ggml_soft_max_ext(context, scores,
          tensors[node.inputs[3]], sink->scale, 0.0F);
      ggml_soft_max_add_sinks(probabilities, tensors[node.inputs[4]]);
      value = ggml_cont(context, ggml_transpose(context, value));
      auto *result = ggml_mul_mat(context, value, probabilities);
      (void)ggml_prec_set_acc(result, GGML_PREC_F32);
      (void)ggml_prec_set_src(result, GGML_PREC_F32, 1);
      return ggml_cont(context, ggml_permute(context, result, 0, 2, 1, 3));
    }
    const auto &operation = *node.operation.get_if<ScaledDotProductAttention>();
    auto *context = arena.get();
    auto *query = tensors[node.inputs[0]];
    auto *key = tensors[node.inputs[1]];
    auto *value = tensors[node.inputs[2]];
    const auto type = query->type;
    // BSHD is [D,H,S,B] in ggml. Its attention/GQA inputs are [D,S,H,B].
    query = ggml_permute(context, ggml_cast(context, query, GGML_TYPE_F32), 0,
                         2, 1, 3);
    // This CUDA flash pin has Half PV accumulation even with PREC_F32, and
    // narrows BF16 K/V on SM89. The original F32 math path honors accumulation
    // and source precision; only the final output narrows to the port type.
    key = ggml_permute(context, ggml_cast(context, key, GGML_TYPE_F32), 0, 2, 1,
                       3);
    value = ggml_permute(context, ggml_cast(context, value, GGML_TYPE_F32), 0,
                         2, 1, 3);
    auto *scores = ggml_mul_mat(context, key, query);
    (void)ggml_prec_set_acc(scores, GGML_PREC_F32);
    (void)ggml_prec_set_src(scores, GGML_PREC_F32, 1);
    // Scale before masking: a zero or negative scale must not turn -inf
    // into NaN or +inf. Bottom-right causal offset is KV length - Q length.
    scores = ggml_scale(context, scores, operation.scale);
    if (operation.causal)
      scores = ggml_diag_mask_inf(context, scores,
                                  static_cast<int>(key->ne[1] - query->ne[1]));
    auto *probabilities = ggml_soft_max(context, scores);
    value = ggml_cont(context, ggml_transpose(context, value));
    auto *result = ggml_mul_mat(context, value, probabilities);
    (void)ggml_prec_set_acc(result, GGML_PREC_F32);
    (void)ggml_prec_set_src(result, GGML_PREC_F32, 1);
    return ggml_cast(context, ggml_permute(context, result, 0, 2, 1, 3), type);
  }

  ggml_tensor *tiled_attention(const internal::Recipe &recipe,
                               const internal::Node &node,
                               std::int64_t block_rows) {
    const auto *operation = node.operation.get_if<ScaledDotProductAttention>();
    const auto sink = node.operation.custom_as<model_ops::SinkAttention>();
    auto *context = arena.get();
    auto *source = tensors[node.inputs[0]];
    auto *key = tensors[node.inputs[1]];
    auto *value = tensors[node.inputs[2]];
    const auto type = source->type;
    const auto queries = source->ne[2];
    const auto keys = key->ne[2];
    auto *output = internal::create_tensor_input(
        context, recipe.values[node.outputs[0]]);
    key = ggml_permute(context, ggml_cast(context, key, GGML_TYPE_F32),
                       0, 2, 1, 3);
    value = ggml_permute(context, ggml_cast(context, value, GGML_TYPE_F32),
                         0, 2, 1, 3);
    // Shared by every block in this single graph, not recopied per block.
    value = ggml_cont(context, ggml_transpose(context, value));
    for (std::int64_t begin = 0; begin < queries; begin += block_rows) {
      const auto rows = std::min(block_rows, queries - begin);
      auto *query = ggml_view_4d(context, source, source->ne[0], source->ne[1],
          rows, source->ne[3], source->nb[1], source->nb[2], source->nb[3],
          static_cast<std::size_t>(begin) * source->nb[2]);
      query = ggml_permute(context, ggml_cast(context, query, GGML_TYPE_F32),
                           0, 2, 1, 3);
      const auto past = static_cast<int>(keys - queries + begin);
      auto *scores = ggml_mul_mat(context, key, query);
      (void)ggml_prec_set_acc(scores, GGML_PREC_F32);
      (void)ggml_prec_set_src(scores, GGML_PREC_F32, 1);
      ggml_tensor *probabilities = nullptr;
      if (sink) {
        auto *mask = tensors[node.inputs[3]];
        mask = ggml_view_2d(context, mask, mask->ne[0], rows, mask->nb[1],
            static_cast<std::size_t>(begin) * mask->nb[1]);
        probabilities = ggml_soft_max_ext(context, scores, mask,
                                           sink->scale, 0.0F);
        ggml_soft_max_add_sinks(probabilities, tensors[node.inputs[4]]);
      } else {
        scores = ggml_scale(context, scores, operation->scale);
        if (operation->causal)
          scores = ggml_diag_mask_inf(context, scores, past);
        probabilities = ggml_soft_max(context, scores);
      }
      auto *result = ggml_mul_mat(context, value, probabilities);
      (void)ggml_prec_set_acc(result, GGML_PREC_F32);
      (void)ggml_prec_set_src(result, GGML_PREC_F32, 1);
      result = ggml_cast(context,
          ggml_permute(context, result, 0, 2, 1, 3), type);
      // B > 1 retains the full output's batch stride. MLA output depth may
      // differ from query depth, so all output strides come from output.
      auto *destination = ggml_view_4d(context, output, output->ne[0],
          output->ne[1], rows, output->ne[3], output->nb[1], output->nb[2],
          output->nb[3], static_cast<std::size_t>(begin) * output->nb[2]);
      attention_roots.push_back(ggml_cpy(context, result, destination));
    }
    return output;
  }

  Status allocate(ggml_tensor *tensor, ggml_backend_buffer_type_t type) {
    if (tensor->view_src) {
      views.push_back(tensor);
      return Status::Ok();
    }
    if (tensor->buffer)
      return Status::Ok(); // Already bound external tensor.
    auto *buffer = ggml_backend_buft_alloc_buffer(
        type, ggml_backend_buft_get_alloc_size(type, tensor));
    if (!buffer)
      return Status::ResourceExhausted("ggml CUDA scratch allocation failed");
    scratch.push_back(buffer); // Capacity reserved before acquiring resources.
    if (ggml_backend_tensor_alloc(buffer, tensor,
                                  ggml_backend_buffer_get_base(buffer)) !=
        GGML_STATUS_SUCCESS)
      return Status::Internal("ggml CUDA scratch binding failed");
    return Status::Ok();
  }

  void bind_views() noexcept {
    for (auto *tensor : views) {
      const auto *source = tensor->view_src;
      tensor->buffer = source->buffer;
      tensor->data = source->data ? static_cast<std::byte *>(source->data) +
                                        tensor->view_offs
                                  : nullptr;
    }
  }

  void bind(std::uint32_t id, void *pointer) noexcept {
    bridge::bind_buffer(buffers[id], pointer);
    roots[id]->data = pointer;
  }

  Status initialize(const Program &program, mem::AllocatorRef allocator) {
    primary = program.primary;
    cuda::detail::ScopedPrimaryContext scope(primary);
    HYLE_RETURN_IF_ERROR(scope.status());
    const auto &recipe = program.recipe;
    const auto attention_rows = attention_query_block(recipe);
    const auto count = recipe.values.size();
    constexpr auto maximum = static_cast<std::size_t>(INT32_MAX) - 16;
    if (count > maximum / 4 || recipe.nodes.size() > (maximum - count * 4) / 64)
      return Status::OutOfRange("ggml CUDA metadata count overflows");
    auto capacity = count * 4 + recipe.nodes.size() * 64;
    if (attention_rows != 0) {
      const auto queries = recipe.values[recipe.nodes[0].inputs[0]].dimensions()[1];
      const auto blocks = static_cast<std::size_t>(
          (queries - 1) / attention_rows + 1);
      if (blocks > (maximum - capacity) / 32)
        return Status::OutOfRange("ggml CUDA attention metadata count overflows");
      capacity += blocks * 32;
      attention_roots.reserve(blocks);
    }
    for (const auto &node : recipe.nodes) {
      if (!node.operation.get_if<Concat>())
        continue;
      // A region can concatenate the same value many times. Count ports,
      // not just unique recipe values, before reserving the fixed arena.
      if (node.inputs.size() > (maximum - capacity) / 4)
        return Status::OutOfRange("ggml CUDA concat metadata count overflows");
      capacity += node.inputs.size() * 4;
    }
    capacity += 16;
    auto metadata =
        ggml_runtime::MetadataArena::for_graph(capacity, capacity, allocator);
    if (!metadata)
      return std::move(metadata).error();
    arena = std::move(*metadata);
    tensors.resize(count, nullptr);
    roots.resize(count, nullptr);
    buffers.resize(count, nullptr);
    pointers.resize(recipe.inputs.size() + recipe.outputs.size());
    index_values.resize(program.index_value_count);
    backend = ggml_backend_cuda_init(program.device);
    if (!backend)
      return Status::ResourceExhausted("ggml CUDA backend allocation failed");
    root = bridge::root_stream(backend);
    HYLE_RETURN_IF_ERROR(
        cuda::status(cudaEventCreateWithFlags(&entry, cudaEventDisableTiming)));
    HYLE_RETURN_IF_ERROR(
        cuda::status(cudaEventCreateWithFlags(&exit, cudaEventDisableTiming)));
    for (const auto id : recipe.inputs) {
      const auto &description = recipe.values[id];
      tensors[id] = internal::create_tensor_input(arena.get(), description);
      ggml_set_input(tensors[id]);
    }
    for (const auto &constant : recipe.constants) {
      tensors[constant.value] = internal::create_tensor_input(
          arena.get(), recipe.values[constant.value]);
      ggml_set_input(tensors[constant.value]);
    }
    for (std::size_t node_index = 0; node_index < recipe.nodes.size();
         ++node_index) {
      const auto &node = recipe.nodes[node_index];
      std::vector<ggml_tensor *> results;
      if (node.operation.get_if<ScaledDotProductAttention>() ||
          node.operation.custom_as<model_ops::SinkAttention>()) {
        if (auto *result = attention_rows != 0
                ? tiled_attention(recipe, node, attention_rows) : attention(node))
          results.push_back(result);
      } else {
        results = internal::lower_tensor_operation(
            arena.get(), recipe, node, tensors, constants, dense_constants,
            program.hadamards[node_index],
            program.snapshot_indices.empty()
                ? std::span<const std::int32_t>{}
                : program.snapshot_indices[node_index]);
      }
      if (results.size() != node.outputs.size())
        return Status::Unimplemented("ggml CUDA tensor lowering declined");
      for (std::size_t i = 0; i < results.size(); ++i) {
        if (!ggml_backend_supports_op(backend, results[i]))
          return Status::Unimplemented("ggml CUDA native operation declined");
        tensors[node.outputs[i]] = results[i];
      }
    }
    for (std::size_t id = 0; id < count; ++id) {
      roots[id] = tensors[id];
      while (roots[id] && roots[id]->view_src)
        roots[id] = roots[id]->view_src;
    }
    graph = ggml_new_graph_custom(arena.get(), capacity, false);
    for (const auto id : recipe.outputs) {
      ggml_set_output(tensors[id]);
      // Reshape is a view: bind and protect the actual producer as well.
      // Native fusion must not consume a separately published intermediate.
      ggml_set_output(roots[id]);
      ggml_build_forward_expand(graph, tensors[id]);
    }
    // Each copy is a graph terminal. Expanding only the external output leaf
    // would omit them. Keep this order and the existing direct backend route
    // (no graph_optimize/multistream reordering) for liveness reuse.
    for (auto *copy : attention_roots) {
      ggml_set_output(copy);
      ggml_build_forward_expand(graph, copy);
    }
    for (std::size_t id = 0; id < count; ++id) {
      if (!tensors[id])
        return Status::InvalidArgument("ggml CUDA recipe has an unused value");
      const auto bytes = ggml_nbytes(roots[id]);
      const bool external =
          std::ranges::find(recipe.inputs, id) != recipe.inputs.end() ||
          std::ranges::find(recipe.outputs, id) != recipe.outputs.end() ||
          std::ranges::any_of(recipe.constants, [id](const auto &constant) {
            return constant.value == id;
          });
      if (external) {
        buffers[id] = bridge::binding_buffer(program.device, bytes);
        // An idle external binding has no payload. Submission installs both
        // the buffer base and tensor address after provenance/size admission.
        roots[id]->buffer = buffers[id];
      }
    }
    for (const auto &constant : recipe.constants) {
      HYLE_ASSIGN_OR_RETURN(auto pointer, cuda::detail::const_pointer(
          constant.binding.storage(), program.alignments[constant.value], 1));
      bind(constant.value, const_cast<void *>(pointer));
    }
    const auto nodes = ggml_graph_n_nodes(graph);
    std::size_t resources = 0;
    for (auto *tensor = ggml_get_first_tensor(arena.get()); tensor;
         tensor = ggml_get_next_tensor(arena.get(), tensor))
      ++resources;
    scratch.reserve(resources);
    views.reserve(resources);
    auto *type = ggml_backend_cuda_buffer_type(program.device);
    if (attention_rows != 0) {
      // Standalone attention has no cold uploaded constants. Intermediates are
      // allocated by lifetime rather than retaining every block's payload.
      for (auto *tensor = ggml_get_first_tensor(arena.get()); tensor;
           tensor = ggml_get_next_tensor(arena.get(), tensor))
        if (tensor->view_src)
          views.push_back(tensor);
      attention_allocator = ggml_gallocr_new(type);
      if (!attention_allocator ||
          !ggml_gallocr_reserve(attention_allocator, graph))
        return Status::ResourceExhausted("ggml CUDA attention workspace allocation failed");
      // Binding-only external roots have null data here. alloc_graph must wait
      // until submit supplies real ports; reserve already owns the workspace.
    } else {
      for (auto *tensor = ggml_get_first_tensor(arena.get()); tensor;
           tensor = ggml_get_next_tensor(arena.get(), tensor))
        HYLE_RETURN_IF_ERROR(allocate(tensor, type));
    }
    for (int i = 0; i < nodes; ++i) {
      auto *tensor = ggml_graph_node(graph, i);
      if (!ggml_backend_supports_op(backend, tensor))
        return Status::Unimplemented("ggml CUDA native graph node declined");
    }
    bind_views();
    for (const auto &constant : constants)
      ggml_backend_tensor_set(constant.tensor, &constant.value, 0,
                              sizeof(constant.value));
    for (const auto &constant : dense_constants)
      ggml_backend_tensor_set(constant.tensor, constant.data, 0,
                              constant.bytes);
    return Status::Ok();
  }
};

Status create_context(const Provider &provider, Device device, void *backend,
                      mem::AllocatorRef allocator, void **output) noexcept {
  *output = nullptr;
  if (device.backend_id() != cuda::kBackendId)
    return Status::Unimplemented("ggml CUDA requires a CUDA device");
  const auto primary = cuda::detail::borrow_primary_context(backend);
  const auto *environment = cuda::detail::borrow_environment(backend);
  if (!primary || !environment)
    return Status::FailedPrecondition("ggml CUDA backend context is invalid");
  cuda::detail::ScopedPrimaryContext scope(primary);
  HYLE_RETURN_IF_ERROR(scope.status());
  try {
#if HYLE_OS_WINDOWS
    // This DLL embeds its own ggml copy. MetadataArena initializes a separate
    // copy; native graph-cache timestamps need this copy's thread-safe timer.
    ggml_time_init();
#endif
    const int native_device = bridge::device_index(environment->device_ordinal);
    if (native_device < 0)
      return Status::Unimplemented("ggml CUDA physical device is unavailable");
    void *storage = allocator.allocate(sizeof(Context), alignof(Context));
    if (!storage)
      return Status::ResourceExhausted("ggml CUDA context allocation failed");
    *output = ::new (storage)
        Context{primary, native_device,
                default_cublas_precision(),
                detail::ProviderAccess::payload<Extension>(provider)};
    return Status::Ok();
  } catch (...) {
    return failure();
  }
}
void destroy_context(void *value, mem::AllocatorRef allocator) noexcept {
  auto *context = static_cast<Context *>(value);
  if (context) {
    context->~Context();
    allocator.deallocate(context, sizeof(Context), alignof(Context));
  }
}
void destroy_program(void *value, mem::AllocatorRef allocator) noexcept {
  auto *program = static_cast<Program *>(value);
  if (program) {
    program->~Program();
    allocator.deallocate(program, sizeof(Program), alignof(Program));
  }
}
void destroy_invocation(void *value, mem::AllocatorRef allocator) noexcept {
  auto *invocation = static_cast<Invocation *>(value);
  if (invocation) {
    invocation->~Invocation();
    allocator.deallocate(invocation, sizeof(Invocation), alignof(Invocation));
  }
}
Status create_invocation(void *value, mem::AllocatorRef allocator,
                         mem::BufferView, void **output) noexcept {
  *output = nullptr;
  void *storage = allocator.allocate(sizeof(Invocation), alignof(Invocation));
  if (!storage)
    return Status::ResourceExhausted("ggml CUDA invocation allocation failed");
  auto *invocation = ::new (storage) Invocation;
  *output = invocation; // The caller owns cleanup even after partial failure.
  try {
    return invocation->initialize(*static_cast<Program *>(value), allocator);
  } catch (...) {
    return failure();
  }
}
detail::EnqueueResult submit(void *value, void *lane, Queue &queue,
                             std::span<const ConstTensorView> inputs,
                             std::span<const TensorView> outputs) noexcept {
  const auto &program = *static_cast<Program *>(value);
  auto &invocation = *static_cast<Invocation *>(lane);
  const auto &recipe = program.recipe;
  if (invocation.failed)
    return detail::EnqueueResult::rejected(Status::FailedPrecondition(
        "ggml CUDA invocation failed; instantiate another"));
  if (inputs.size() != recipe.inputs.size() ||
      outputs.size() != recipe.outputs.size())
    return detail::EnqueueResult::rejected(
        Status::InvalidArgument("ggml CUDA binding counts differ"));
  auto stream = cuda::stream(queue);
  if (!stream)
    return detail::EnqueueResult::rejected(std::move(stream).error());
  for (std::size_t i = 0; i < inputs.size(); ++i) {
    auto pointer = cuda::detail::const_pointer(
        inputs[i].storage(), program.alignments[recipe.inputs[i]], 1);
    if (!pointer)
      return detail::EnqueueResult::rejected(std::move(pointer).error());
    invocation.pointers[i] = const_cast<void *>(*pointer);
  }
  for (std::size_t i = 0; i < outputs.size(); ++i) {
    auto pointer = cuda::detail::mutable_pointer(
        outputs[i].storage(), program.alignments[recipe.outputs[i]], 1);
    if (!pointer)
      return detail::EnqueueResult::rejected(std::move(pointer).error());
    invocation.pointers[inputs.size() + i] = *pointer;
  }
  cuda::detail::ScopedPrimaryContext scope(program.primary);
  if (!scope)
    return detail::EnqueueResult::rejected(scope.status());
  for (std::size_t i = 0; i < inputs.size(); ++i)
    invocation.bind(recipe.inputs[i], invocation.pointers[i]);
  for (std::size_t i = 0; i < outputs.size(); ++i)
    invocation.bind(recipe.outputs[i], invocation.pointers[inputs.size() + i]);
  if (invocation.attention_allocator && !invocation.attention_allocated) {
    try {
      if (!ggml_gallocr_alloc_graph(invocation.attention_allocator,
                                    invocation.graph)) {
        invocation.failed = true;
        return detail::EnqueueResult::rejected(Status::ResourceExhausted(
            "ggml CUDA attention workspace binding failed"));
      }
      invocation.attention_allocated = true;
    } catch (...) {
      invocation.failed = true;
      return detail::EnqueueResult::rejected(failure());
    }
  }
  invocation.bind_views();

  Status terminal = Status::Ok();
  for (const auto &check : program.index_checks) {
    terminal = cuda::status(cudaMemcpyAsync(
        invocation.index_values.data() + check.offset,
        invocation.pointers[check.input], check.count * sizeof(std::int32_t),
        cudaMemcpyDeviceToHost, *stream));
    if (!terminal.ok())
      break;
  }
  if (terminal.ok() && !program.index_checks.empty())
    terminal = cuda::status(cudaStreamSynchronize(*stream));
  if (!terminal.ok())
    return detail::EnqueueResult::accepted_command(std::move(terminal));
  for (const auto &check : program.index_checks) {
    const auto begin = invocation.index_values.begin() +
                       static_cast<std::ptrdiff_t>(check.offset);
    const auto end = begin + static_cast<std::ptrdiff_t>(check.count);
    if (std::ranges::any_of(begin, end, [&](const auto index) {
          return index < 0 || index >= check.extent;
        }))
      return detail::EnqueueResult::accepted_command(Status::OutOfRange(
          "ggml CUDA index out of range; output unchanged"));
  }

  terminal = cuda::status(cudaEventRecord(invocation.entry, *stream));
  if (terminal.ok())
    terminal =
        cuda::status(cudaStreamWaitEvent(invocation.root, invocation.entry, 0));
  if (terminal.ok()) {
    try {
      if (ggml_backend_graph_compute_async(
              invocation.backend, invocation.graph) != GGML_STATUS_SUCCESS)
        terminal = Status::Internal("ggml CUDA native graph failed");
    } catch (...) {
      terminal = failure();
    }
  }
  if (terminal.ok())
    terminal = cuda::status(cudaEventRecord(invocation.exit, invocation.root));
  if (terminal.ok())
    terminal = cuda::status(cudaStreamWaitEvent(*stream, invocation.exit, 0));
  if (!terminal.ok()) {
    invocation.failed = true;
    // A failed exit event cannot transfer native ownership to HYLE's stream.
    // Quiesce every accepted upstream stream before exposing the failure.
    (void)bridge::drain(invocation.backend);
  }
  return detail::EnqueueResult::accepted_command(std::move(terminal));
}
AliasSupport alias_support(void *opaque, std::size_t input,
                           std::size_t output) noexcept {
  const auto &recipe = static_cast<Program *>(opaque)->recipe;
  if (input != 0 || output != 0 || recipe.nodes.size() != 1 ||
      !recipe.nodes[0].operation.get_if<Softmax>())
    return {};
  // Native row softmax is safe at the same address. Nontrailing axes and
  // half storage first materialize their native input before writing back.
  const auto &source = recipe.values[recipe.inputs[0]];
  return {.supported =
              source.is_dense() && source == recipe.values[recipe.outputs[0]]};
}
const detail::ProviderPreparedVTable kPrepared{
    .destroy_prepared = &destroy_program,
    .alias_support = &alias_support,
    .create_invocation = &create_invocation,
    .destroy_invocation = &destroy_invocation,
    .shared_submit = &submit};

Status propose(void *context, const detail::ProviderOperationRequest &request,
               std::span<detail::ResourceBindingRequirement> inputs,
               std::span<detail::ResourceBindingRequirement> outputs,
               detail::ProviderOperationProposal *output) noexcept {
  *output = {};
  if (!request.shape.exact() ||
      !internal::supports(context, request.operation, request.inputs,
                          request.outputs))
    return Status::Unimplemented("ggml CUDA operation domain is not admitted");
  std::ranges::fill(inputs, internal::kBinding);
  std::ranges::fill(outputs, internal::kBinding);
  for (std::size_t i = 0; i < inputs.size(); ++i)
    inputs[i].minimum_alignment = internal::boundary_alignment(
        request.operation, request.inputs[i].data_type());
  for (std::size_t i = 0; i < outputs.size(); ++i)
    outputs[i].minimum_alignment = internal::boundary_alignment(
        request.operation, request.outputs[i].data_type());
  *output = {.route = 1,
             .runtime = internal::kRuntime,
             .workspace_resource = internal::kBinding,
             .cost = {.workspace = WorkspaceRequirement{},
                      .persistent_bytes = std::nullopt,
                      .copy_bytes = std::nullopt,
                      .repack_bytes = std::nullopt,
                      .synchronization_count = 2,
                      .dispatch_count = std::nullopt},
             .implementation = ProviderImplementationId{1}};
  return Status::Ok();
}
ProviderPrepareOutcome prepare(void *context,
                               const detail::ProviderPrepareRequest &request,
                               mem::AllocatorRef allocator,
                               detail::ProviderPrepared *output) noexcept {
  *output = {};
  if (request.route != 1 || !request.shape.exact() ||
      !internal::supports(context, request.operation, request.inputs,
                          request.outputs))
    return ProviderPrepareOutcome::unsupported(
        Status::Unimplemented("ggml CUDA prepare domain differs"));
  try {
    internal::Recipe recipe;
    recipe.values.assign(request.inputs.begin(), request.inputs.end());
    internal::Node node{request.operation, {}, {}};
    for (std::uint32_t i = 0; i < request.inputs.size(); ++i) {
      recipe.inputs.push_back(i);
      node.inputs.push_back(i);
    }
    for (const auto &description : request.outputs) {
      const auto id = static_cast<std::uint32_t>(recipe.values.size());
      recipe.values.push_back(description);
      node.outputs.push_back(id);
      recipe.outputs.push_back(id);
    }
    recipe.nodes.push_back(std::move(node));
    return internal::compile(context, std::move(recipe), allocator, output);
  } catch (...) {
    return ProviderPrepareOutcome::error(failure());
  }
}
Status drain_context(void *) noexcept { return Status::Ok(); }
const void *query_extension(void *value, ProviderExtensionId id) noexcept {
  const auto &extension = static_cast<Context *>(value)->extension;
  return id == extension.id ? extension.table : nullptr;
}
const detail::ProviderVTable kProvider{
    .identity = {.id = kProviderId,
                 .name = "ggml-cuda",
                 .version = kProviderVersion},
    .create_context = &create_context,
    .destroy_context = &destroy_context,
    .propose = &propose,
    .prepare = &prepare,
    .drain_context = &drain_context,
    .query_extension = &query_extension};
} // namespace

namespace internal {
Status widen_bfloat_constant(void *value, ConstTensorView source,
                            TensorView destination,
                            mem::AllocatorRef allocator) noexcept {
  const auto &from = source.description();
  const auto &to = destination.description();
  if (!value || !from.is_plain() || !from.is_dense() ||
      from.data_type() != DataType::kBFloat16 || !to.is_plain() ||
      !to.is_dense() || to.data_type() != DataType::kFloat32 ||
      !std::ranges::equal(from.dimensions(), to.dimensions()))
    return Status::InvalidArgument("ggml CUDA constant widening schema differs");
  const auto &context = *static_cast<Context *>(value);
  cuda::detail::ScopedPrimaryContext scope(context.primary);
  HYLE_RETURN_IF_ERROR(scope.status());
  try {
    Program program;
    program.primary = context.primary;
    program.device = context.device;
    program.recipe.values = {from, to};
    program.recipe.inputs = {0};
    program.recipe.outputs = {1};
    program.recipe.nodes.push_back(
        {Operation(Cast{.output_type = DataType::kFloat32}), {0}, {1}});
    program.alignments = {data_type_size(from.data_type()),
                          data_type_size(to.data_type())};
    program.hadamards.resize(1);
    Invocation invocation;
    HYLE_RETURN_IF_ERROR(invocation.initialize(program, allocator));
    HYLE_ASSIGN_OR_RETURN(auto input, cuda::detail::const_pointer(
        source.storage(), program.alignments[0], 1));
    HYLE_ASSIGN_OR_RETURN(auto output, cuda::detail::mutable_pointer(
        destination.storage(), program.alignments[1], 1));
    invocation.bind(0, const_cast<void *>(input));
    invocation.bind(1, output);
    invocation.bind_views();
    if (ggml_backend_graph_compute_async(invocation.backend, invocation.graph) !=
        GGML_STATUS_SUCCESS)
      return Status::Internal("ggml CUDA constant widening failed");
    // Invocation retains every native temporary until this checked drain;
    // its destructor also drains a failed accepted prefix before releasing it.
    return cuda::status(bridge::drain(invocation.backend));
  } catch (...) {
    return failure();
  }
}

bool supports(void *value, Operation operation,
              std::span<const TensorDesc> inputs,
              std::span<const TensorDesc> outputs) noexcept {
  if (!value || outputs.empty())
    return false;
  if (const auto *attention = operation.get_if<ScaledDotProductAttention>()) {
    if (outputs.size() != 1 || inputs.size() != 3 ||
        attention->layout != AttentionLayout::kBatchSequenceHeadDepth ||
        attention->mask != MaskKind::kNone ||
        attention->accumulation_type != DataType::kFloat32 ||
        !std::isfinite(attention->scale))
      return false;
    const auto type = inputs[0].data_type();
    if ((type != DataType::kFloat32 && type != DataType::kFloat16 &&
         type != DataType::kBFloat16) ||
        (type == DataType::kBFloat16 &&
         !static_cast<Context *>(value)->bfloat16_attention))
      return false;
    for (const auto &description : inputs)
      if (!description.valid() || !description.is_plain() ||
          !description.is_dense() || description.rank() != 4 ||
          description.data_type() != type || !description.element_count() ||
          *description.element_count() > INT32_MAX)
        return false;
    const auto q = inputs[0].dimensions();
    const auto k = inputs[1].dimensions();
    const auto v = inputs[2].dimensions();
    const std::array mla_shape{q[0], q[1], q[2], std::int64_t{512}};
    const auto mla_output = TensorDesc::dense(DataType::kFloat32, mla_shape);
    const bool absorbed_mla = type == DataType::kFloat32 &&
        (q[2] == 64 || q[2] == 96) &&
        k[2] == 1 && q[3] == 576 && v[3] == 512 && v[0] == k[0] &&
        v[1] == k[1] && v[2] == k[2] && mla_output && outputs[0] == *mla_output;
    if (q[0] <= 0 || q[0] > 65535 || q[1] <= 0 || k[1] <= 0 ||
        (attention->causal && k[1] < q[1]) ||
        q[2] <= 0 || k[2] <= 0 || q[2] % k[2] != 0 || q[3] <= 0 ||
        q[3] != k[3] || q[0] != k[0] ||
        (!(inputs[1] == inputs[2] && outputs[0] == inputs[0]) && !absorbed_mla))
      return false;
    // Bound native indexing and the BF16 score/mask allocation before any
    // upstream API asserts or buffer-size arithmetic can be reached.
    return k[1] <= INT32_MAX / q[1] / q[2] / q[0];
  }
  return tensor_operation_supports(operation, inputs, outputs);
}

ProviderPrepareOutcome compile(void *value, Recipe recipe,
                               mem::AllocatorRef allocator,
                               detail::ProviderPrepared *output) noexcept {
  *output = {};
  const auto &context = *static_cast<Context *>(value);
  std::vector<std::size_t> alignments;
  std::vector<std::vector<float>> hadamards;
  std::vector<std::vector<std::int32_t>> snapshot_indices;
  std::vector<Program::IndexCheck> index_checks;
  std::size_t index_value_count = 0;
  try {
    alignments.resize(recipe.values.size(), 1);
    hadamards.resize(recipe.nodes.size());
    for (std::size_t node_index = 0; node_index < recipe.nodes.size();
         ++node_index) {
      const auto &node = recipe.nodes[node_index];
      const auto require = [&](std::uint32_t id) {
        alignments[id] = std::max(
            alignments[id],
            boundary_alignment(node.operation, recipe.values[id].data_type()));
      };
      for (const auto id : node.inputs)
        require(id);
      for (const auto id : node.outputs)
        require(id);
      const auto *gdn = node.operation.get_if<GatedDeltaNet>();
      const auto recurrent =
          node.operation.custom_as<model_ops::RecurrentGatedDeltaNet>();
      const auto snapshots = gdn ? gdn->snapshot_count
                                 : recurrent ? recurrent->snapshot_count : 1;
      if (snapshots > 1) {
        if (snapshot_indices.empty())
          snapshot_indices.resize(recipe.nodes.size());
        const auto batches = recipe.values[node.inputs[0]].dimensions()[0];
        auto &order = snapshot_indices[node_index];
        order.reserve(static_cast<std::size_t>(batches) * snapshots);
        for (std::int64_t batch = 0; batch < batches; ++batch)
          for (std::uint32_t token = 0; token < snapshots; ++token)
            order.push_back(static_cast<std::int32_t>(
                (snapshots - 1 - token) * batches + batch));
      }
      const auto *gather = node.operation.get_if<Gather>();
      const bool grouped =
          node.operation.custom_as<model_ops::GroupedMatMul>().has_value();
      if (grouped || (gather && gather->bounds == IndexBoundsPolicy::kChecked)) {
        const auto index_port = grouped ? 2 : 1;
        const auto input =
            std::ranges::find(recipe.inputs, node.inputs[index_port]);
        if (input == recipe.inputs.end())
          return ProviderPrepareOutcome::unsupported(Status::Unimplemented(
              "ggml CUDA dynamic indices require a checked boundary"));
        const auto count =
            recipe.values[node.inputs[index_port]].element_count().value();
        if (count > SIZE_MAX - index_value_count)
          return ProviderPrepareOutcome::error(
              Status::OutOfRange("ggml CUDA index-check size overflows"));
        index_checks.push_back(
            {static_cast<std::uint32_t>(input - recipe.inputs.begin()),
             index_value_count, count,
             recipe.values[node.inputs[0]].dimensions()[0]});
        index_value_count += count;
      }
      if (node.operation.get_if<Hadamard>()) {
        const auto width = recipe.values[node.outputs[0]].dimensions().back();
        if (width <= 0 || width > 4096 ||
            static_cast<std::uint64_t>(width) *
                    static_cast<std::uint64_t>(width) >
                SIZE_MAX / sizeof(float))
          return ProviderPrepareOutcome::unsupported(
              Status::Unimplemented("ggml CUDA Hadamard width is outside the "
                                    "admitted original backend domain"));
        auto &matrix = hadamards[node_index];
        if (width > 512) {
          const auto factors = internal::hadamard_factors(width);
          matrix.resize(factors.constant_elements());
          const auto fill = [&](std::int64_t n, std::size_t offset) {
            const auto scale = 1.0F / std::sqrt(static_cast<float>(n));
            for (std::int64_t row = 0; row < n; ++row)
              for (std::int64_t column = 0; column < n; ++column)
                matrix[offset + static_cast<std::size_t>(row * n + column)] =
                    std::popcount(static_cast<std::uint64_t>(row & column)) % 2
                        ? -scale
                        : scale;
          };
          fill(factors.low, 0);
          if (factors.high != factors.low)
            fill(factors.high,
                 static_cast<std::size_t>(factors.low * factors.low));
          continue;
        }
        matrix.resize(static_cast<std::size_t>(width * width));
        const auto scale = 1.0F / std::sqrt(static_cast<float>(width));
        for (std::int64_t row = 0; row < width; ++row)
          for (std::int64_t column = 0; column < width; ++column)
            matrix[static_cast<std::size_t>(row * width + column)] =
                std::popcount(static_cast<std::uint64_t>(row & column)) % 2
                    ? -scale
                    : scale;
      }
    }
  } catch (...) {
    return ProviderPrepareOutcome::error(failure());
  }
  void *storage = allocator.allocate(sizeof(Program), alignof(Program));
  if (!storage)
    return ProviderPrepareOutcome::resource_declined(
        Status::ResourceExhausted("ggml CUDA program allocation failed"));
  *output = {.vtable = &kPrepared,
             .state = ::new (storage)
                 Program{context.primary, context.device, std::move(recipe),
                         std::move(alignments), std::move(hadamards),
                         std::move(snapshot_indices),
                         std::move(index_checks), index_value_count},
             .workspace = {},
             .runtime = kRuntime,
             .persistent_bytes = std::nullopt,
             .invocation_private_bytes = std::nullopt};
  return ProviderPrepareOutcome::prepared();
}
Provider with_extension(ProviderExtensionId id, const void *table) noexcept {
  return detail::ProviderAccess::make(&kProvider, Extension{id, table});
}
} // namespace internal

Provider provider() noexcept { return internal::with_extension({}, nullptr); }
} // namespace hyle::compute::ggml_cuda
