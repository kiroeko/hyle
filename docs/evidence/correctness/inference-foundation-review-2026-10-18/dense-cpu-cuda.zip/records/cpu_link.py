from pathlib import Path
import importlib.util
out=Path('.scratch/inference-fusion-quantization-2026-10-18/dense-constants').resolve()
spec=importlib.util.spec_from_file_location('runner',out/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
cfg=dict(r.cpu.PINS['mixed'],folder=Path('mixed'))
cache=r.ROOT/'.scratch/mtp-gdn-2026-10-18'
objects=[r.ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj',out/'cpu-region.obj',out/'cpu-probe.obj',r.ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/native-batch.obj']
objects += [r.ROOT/'.scratch/inference-feature-completion-2026-10-18/mla/batch-layout.obj']
objects += [cache/p for p in ['ffa4/operation.obj','mixed/selector-baseline.obj','mixed/allocator.obj']]
objects += [r.ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj']
exe=out/'cpu-tests.exe'
r.run('cpu-link',[r.cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(out/'cpu-tests.map'),*objects,r.cpu.BASE/'bin/hyle_graph.lib',*r.cpu.common_libs(cfg),r.cpu.BASE/'lib/gtest_main.lib',r.cpu.BASE/'lib/gtest.lib',*r.cpu.SYSTEM],r.cpu.ENV)
r.run('cpu-tests',[exe,'--gtest_filter=CpuConstantComponent.*','--gtest_color=no'],r.cpu.ENV)
