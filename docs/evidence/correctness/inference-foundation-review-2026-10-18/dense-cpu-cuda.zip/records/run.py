from pathlib import Path
import importlib.util,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
cuda=load('cuda_cache','.scratch/mtp-completion/run.py')
cpu=load('cpu_cache','.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command,env):
    command=list(map(str,command));start=time.monotonic()
    attempt=1+sum(x['tag']==tag for x in records)
    stem=tag+f'-{attempt}'
    p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=180)
    (OUT/(stem+'.stdout.txt')).write_bytes(p.stdout);(OUT/(stem+'.stderr.txt')).write_bytes(p.stderr)
    records.append(dict(tag=tag,attempt=attempt,command=command,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(stem,p.returncode,round(records[-1]['seconds'],2),flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-6000:]);print(p.stderr.decode(errors='replace')[-2500:]);raise SystemExit(p.returncode)
def compile(source,stem,cl,flags,env):
    obj=OUT/(stem+'.obj');run(stem,[cl,*flags,ROOT/source,'/Fo'+str(obj)],env);return obj
def gpu():
    flags=cuda.flags+['/I'+str(ROOT)]
    objects=[(OUT/(stem+'.obj') if '--reuse-products' in sys.argv and stem!='cuda-tests' else compile(file,stem,cuda.cl,flags,cuda.env)) for file,stem in [
        ('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','cuda-provider'),
        ('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','cuda-region'),
        ('tests/graph_provider_ggml_cuda/region_test.cc','cuda-tests')]]
    objects += [ROOT/'.scratch/mtp-completion/operation.obj',
        ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-rope/cuda-tensor.obj',
        cuda.OLD/'ggml-cuda.strict.obj']
    exe=OUT/'cuda-tests.exe'
    run('cuda-link',[cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(exe),'/MAP:'+str(OUT/'cuda-tests.map'),*objects,*cuda.libs,
        cuda.BASE/'lib/gtest_main.lib',cuda.BASE/'lib/gtest.lib',*cuda.system],cuda.env)
    run('cuda-tests',[exe,'--gtest_filter=GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs:GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable','--gtest_color=no'],cuda.env)
def host():
    cfg=dict(cpu.PINS['mixed'],folder=Path('mixed'))
    flags=cpu.hyle_flags(cfg)+['/I'+str(ROOT)]
    objects=[(OUT/(stem+'.obj') if '--reuse-products' in sys.argv and stem=='cpu-region' else compile(file,stem,cpu.CL,flags,cpu.ENV)) for file,stem in [
        ('src/compute_provider_ggml/ggml_cpu_provider.cc','cpu-provider'),
        ('src/graph_route_cpu/ggml_region.cc','cpu-region'),
        ('.scratch/inference-fusion-quantization-2026-10-18/dense-constants/cpu_probe.cc','cpu-probe')]]
    compile('tests/graph_route_cpu/graph_test.cc','cpu-canonical-test',cpu.CL,flags,cpu.ENV)
    if '--compile-only' in sys.argv: return
    cache=ROOT/'.scratch/mtp-gdn-2026-10-18'
    objects += [cache/p for p in ['ffa4/operation.obj','mixed/selector-baseline.obj','mixed/allocator.obj']]
    objects += [ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj']
    exe=OUT/'cpu-tests.exe'
    run('cpu-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(exe),'/MAP:'+str(OUT/'cpu-tests.map'),*objects,cpu.BASE/'bin/hyle_graph.lib',*cpu.common_libs(cfg),
        cpu.BASE/'lib/gtest_main.lib',cpu.BASE/'lib/gtest.lib',*cpu.SYSTEM],cpu.ENV)
    run('cpu-tests',[exe,'--gtest_filter=CpuConstantComponent.*','--gtest_color=no'],cpu.ENV)
if __name__=='__main__':
    {'cuda':gpu,'cpu':host}[sys.argv[1]]()
