from pathlib import Path
import importlib.util
out=Path('.scratch/inference-fusion-quantization-2026-10-18/dense-constants').resolve()
spec=importlib.util.spec_from_file_location('runner',out/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
s=(r.ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc').read_text()
marker='    bind_views();\n    for (const auto &constant : constants)'
probe='''    std::size_t transposes = 0;
    for (int i = 0; i < nodes; ++i) {
      const auto *value = ggml_graph_node(graph, i);
      if (value->op == GGML_OP_CONT && value->ne[0] == 37 && value->ne[1] == 7)
        ++transposes;
    }
    std::fprintf(stderr, "MATRIX_CENSUS nodes=%zu immutable_bindings=%zu RHS_transpose_cont=%zu\\n",
        recipe.nodes.size(), recipe.constants.size(), transposes);
'''
assert s.count(marker)==1
source=out/'cuda-provider-census.cc';source.write_bytes(('#include <cstdio>\n'+s.replace(marker,probe+marker)).encode())
obj=r.compile(source,'cuda-provider-census',r.cuda.cl,r.cuda.flags+['/I'+str(r.ROOT)],r.cuda.env)
exe=out/'cuda-census.exe'
objs=[obj,out/'cuda-region.obj',out/'cuda-tests.obj',r.ROOT/'.scratch/mtp-completion/operation.obj',r.ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-rope/cuda-tensor.obj',r.cuda.OLD/'ggml-cuda.strict.obj']
r.run('cuda-census-link',[r.cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),*objs,*r.cuda.libs,r.cuda.BASE/'lib/gtest_main.lib',r.cuda.BASE/'lib/gtest.lib',*r.cuda.system],r.cuda.env)
r.run('cuda-census',[exe,'--gtest_filter=GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs','--gtest_color=no'],r.cuda.env)
