from pathlib import Path
import base64,hashlib,io,json,re,subprocess,tarfile,sys
R=Path.cwd();O=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-foundation-review-20261018-row-cache-indexer-native'
def ssh(code,payload=None):
 cmd='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
 return subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=payload,capture_output=True,timeout=60)
def stage():
 files={'run_remote.py':O/'run_remote.py','perf.cc':O/'perf.cc'};seen=set()
 def add(p):
  p=p.resolve()
  if p in seen:return
  seen.add(p)
  if p.is_relative_to(R) and '.scratch' not in p.relative_to(R).parts:files[p.relative_to(R).as_posix()]=p
  for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',p.read_text(encoding='utf-8-sig'),re.M):
   for candidate in [p.parent/name,R/name,R/'include'/name,R/'src/compute_route_apple'/name,R/'src/compute'/name]:
    if candidate.is_file():add(candidate);break
 for name in ['src/compute_route_apple/apple_row_cache_indexer.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc','src/compute_route_apple/apple_context.cc','src/graph_route_apple/apple_lowering.cc','tests/compute_route_vulkan/row_cache_indexer_test.cc']:add(R/name)
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w:gz')as z:
  for name,p in sorted(files.items()):z.add(p,arcname=name)
 (O/'minimal-sources.tar.gz').write_bytes(b.getvalue());(O/'staged-sha.json').write_text(json.dumps([dict(path=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in sorted(files.items())],indent=2)+'\n')
 code='from pathlib import Path;import io,sys,tarfile;r=Path('+repr(REMOTE)+');r.mkdir(exist_ok=True);z=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");assert all(m.isfile()and not Path(m.name).is_absolute()and".."not in Path(m.name).parts for m in z.getmembers());z.extractall(r);print(r)'
 p=ssh(code,b.getvalue());(O/'stage.stdout.log').write_bytes(p.stdout);(O/'stage.stderr.log').write_bytes(p.stderr);print(p.returncode,len(files),len(b.getvalue()),p.stdout.decode(),p.stderr.decode());p.check_returncode()
def build():
 p=subprocess.run(['ssh','kiro@172.22.10.198','cd '+REMOTE+' && python3 run_remote.py'],capture_output=True,timeout=300)
 (O/'build.stdout.log').write_bytes(p.stdout);(O/'build.stderr.log').write_bytes(p.stderr);print(p.returncode,p.stdout.decode(errors='replace')[-20000:],p.stderr.decode(errors='replace')[-4000:]);p.check_returncode()
def collect():
 code='from pathlib import Path;import tarfile,io,sys;r=Path('+repr(REMOTE)+');b=io.BytesIO();z=tarfile.open(fileobj=b,mode="w:gz");[z.add(p,arcname=p.name)for p in r.iterdir()if p.is_file()and p.suffix in[".json",".log",".txt"]];z.close();sys.stdout.buffer.write(b.getvalue())'
 p=ssh(code);p.check_returncode();(O/'results.tar.gz').write_bytes(p.stdout)
 with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:gz')as z:
  assert all(m.isfile()and len(Path(m.name).parts)==1 for m in z.getmembers());z.extractall(O)
if __name__=='__main__':
 for action in sys.argv[1:]:globals()[action]()
