from pathlib import Path
import json,sys,subprocess,os,time
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-indexer-native';S=O/'shaders';S.mkdir(exist_ok=True)
old=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/row-cache-vulkan/commands.json').read_text());cc=next(x['command']for x in old if x['tag']=='row-cache-compile');flags=['/I'+str(S)]+[x for x in cc[1:]if not x.endswith('.cc')and not x.lower().startswith('/fo')]
sys.path.insert(0,str(R/'scripts'));from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':cc[0],'CMAKE_C_COMPILER':cc[0]});env.update(VSLANG='1033',DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~')
records=json.loads((O/'vulkan-commands.json').read_text())if(O/'vulkan-commands.json').exists()else[]
def run(tag,cmd):
 stem=str(len(records)+1)+'-'+tag;start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(stem+'.stdout.log')).write_bytes(p.stdout);(O/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'vulkan-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-2500:],flush=True);p.check_returncode()
def compile(source,stem):run(stem+'-compile',[cc[0],*flags,R/source,'/Fo'+str(O/(stem+'.obj'))])
if __name__=='__main__':
 run('shaders',[sys.executable,R/'src/compute_route_vulkan/build_shaders.py','--compiler','C:/public/tools/glslang/glslangValidator.exe','--source',R/'third_party/ggml_vulkan_shaders/shaders','--tensor-source',R/'src/compute_route_vulkan/shaders','--output',S])
 for source,stem in [('src/compute_route_vulkan/vulkan_row_cache_indexer.cc','vulkan-indexer'),('src/compute_route_vulkan/vulkan_operations.cc','vulkan-operations'),('src/compute_route_vulkan/vulkan_pipeline.cc','vulkan-pipeline'),('src/compute_route_vulkan/vulkan_run.cc','vulkan-run'),('src/graph_route_vulkan/vulkan_lowering.cc','vulkan-graph')]:compile(source,stem)
 compile(str((S/'vulkan_shaders.cc').relative_to(R)),'vulkan-shaders')
 compile('tests/compute_route_vulkan/row_cache_indexer_test.cc','vulkan-test')
