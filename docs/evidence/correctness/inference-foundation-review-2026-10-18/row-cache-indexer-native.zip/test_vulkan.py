from pathlib import Path
import json,sys,os
sys.path.insert(0,str(Path(__file__).resolve().parent));import build_vulkan as b
R=b.R;O=b.O;OLD=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-native'
prior=json.loads((OLD/'vulkan-commands.json').read_text());link=next(x['command']for x in reversed(prior)if x['tag']=='vulkan-link'and x['exit']==0)
cmd=[]
for x in link:
 p=Path(x)
 if x.startswith(('/OUT:','/MAP:')):continue
 if p.name in {'vulkan-operations.obj','vulkan-shaders.obj','vulkan-test.obj'}:cmd.append(str(O/p.name))
 elif p.name=='graph-lowering.obj':cmd.append(str(O/'vulkan-graph.obj'))
 else:cmd.append(x)
cmd += [str(O/n)for n in ['vulkan-indexer.obj','vulkan-pipeline.obj','vulkan-run.obj']]
paths=[str(R/'.scratch/build-compute-v2-dev/bin')]+[str(Path(x).parent)for x in cmd if x.endswith('.lib')and Path(x).is_absolute()]
b.env['PATH']=os.pathsep.join(dict.fromkeys(paths))+os.pathsep+b.env['PATH']
b.run('vulkan-link',[*cmd,'/OUT:'+str(O/'vulkan-test.exe')])
b.run('vulkan-test',[O/'vulkan-test.exe','--gtest_filter=VulkanRowCacheIndexer.*:VulkanRowCache.*'])
