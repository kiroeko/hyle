#include "tests/compute_route_vulkan/row_cache_indexer_test.cc"
#include <chrono>
#include <cstdio>
#include <algorithm>
int main() {
  auto context=n::Context::create().value();F f(513,3);
  std::fill(f.query.begin(),f.query.end(),row_cache_test::bfloat(0.f));
  std::fill(f.weights.begin(),f.weights.end(),row_cache_test::bfloat(1.f/64));
  for(int t=0;t<3;++t)for(int h=0;h<64;++h)f.query[(t*64+h)*128+t]=row_cache_test::bfloat(1.f);
  auto packed=direct(context,f);auto packed_slot=packed.create_invocation().value();auto packed_inputs=inputs(context,f,0);
  std::vector<float> q(3*64*128),k(513*128),w(3*64,1.f/64),mask(3*513);
  for(std::size_t i=0;i<q.size();++i)q[i]=float(row_cache_test::decode(f.query[i]));
  for(int row=0;row<513;++row)for(int d=0;d<128;++d)k[row*128+d]=float(f.key(row,d));
  for(int t=0;t<3;++t)for(int row=0;row<513;++row)mask[t*513+row]=(row>=f.ranges[t*2] && row<f.ranges[t*2+1])?0.f:-std::numeric_limits<float>::infinity();
  [[maybe_unused]] const std::array desc{
    c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,4>{1,3,64,128}).value(),
    c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,4>{1,513,1,128}).value(),
    c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,4>{1,1,3,64}).value(),
    c::TensorDesc::dense(c::DataType::kFloat16,std::array<std::int64_t,4>{1,1,3,513}).value()};
#if defined(HYLE_ROW_INDEXER_APPLE)
  const std::array dense_inputs{mx::array(q.data(),{1,3,64,128}),mx::array(k.data(),{1,513,1,128}),mx::array(w.data(),{1,1,3,64}),mx::array(mask.data(),{1,1,3,513},mx::float16)};
  auto dense=context.prepare(c::model_ops::lightning_indexer(),dense_inputs).value();
#else
  std::vector<std::uint16_t> halfmask(mask.size());for(std::size_t i=0;i<mask.size();++i)halfmask[i]=std::isinf(mask[i])?0xfc00:0;
  const std::array dense_inputs{context.upload(desc[0],std::as_bytes(std::span(q))).value(),context.upload(desc[1],std::as_bytes(std::span(k))).value(),context.upload(desc[2],std::as_bytes(std::span(w))).value(),context.upload(desc[3],std::as_bytes(std::span(halfmask))).value()};
  std::vector<n::Argument> arguments;for(const auto&d:desc)arguments.emplace_back(d);
  auto dense=n::prepare(context,c::model_ops::lightning_indexer(),arguments).value();
#endif
  auto dense_slot=dense.create_invocation().value();
  const auto wanted=f.expected();std::array<std::vector<double>,2> times;
  for(int arm=0;arm<2;++arm) {
    auto&slot=arm?packed_slot:dense_slot;const auto&bound_inputs=arm?packed_inputs:dense_inputs;
    if(!slot.bind(bound_inputs).ok())return 2;
    for(int repeat=0;repeat<11;++repeat) {
      const auto start=std::chrono::steady_clock::now();auto work=slot.submit().value();auto result=work.wait().value();
      const auto end=std::chrono::steady_clock::now();
      if(repeat>=2)times[arm].push_back(std::chrono::duration<double,std::nano>(end-start).count());
      const auto values=read(context,outputs(*result.get())[0]);
      if(values!=wanted){std::fprintf(stderr,"arm%d output differs\n",arm);return 3;}
    }
    auto sorted=times[arm];std::sort(sorted.begin(),sorted.end());
    std::printf("%s ns:",arm?"packed-tile1":"dense-Lightning-resident");for(auto t:times[arm])std::printf(" %.0f",t);
    std::printf(" median=%.0f\n",sorted[4]);
  }
  std::puts("Exact outputs match independent BF16 oracle only on this rounding-identity onehot/power2 subset. Dense key decode/upload is excluded. Submit+wait includes native output/metadata cost; no throughput/full-model claim.");
}
