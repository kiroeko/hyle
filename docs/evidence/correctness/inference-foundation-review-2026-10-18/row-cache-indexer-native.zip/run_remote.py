from pathlib import Path
import hashlib,json,subprocess,time
R=Path(__file__).resolve().parent
OLD=R.parent/'inference-foundation-review-20261018-apple-recurrent-metadata'
BASE=R.parent/'inference-foundation-review-20261018-row-cache-paged-native'
records=json.loads((R/'apple-commands.json').read_text()) if (R/'apple-commands.json').exists()else[]
prior=json.loads((BASE/'commands.json').read_text());cc=next(x['command']for x in prior if x['tag']=='row.o-compile');flags=cc[:cc.index('-c')]
flags[1:1]=['-I'+str(R/'include'),'-I'+str(R),'-I'+str(R/'src/compute_route_apple'),'-DHYLE_ROW_INDEXER_APPLE=1']
link=next(x['command']for x in json.loads((OLD/'commands.json').read_text())if x['tag']=='canonical-link')
def run(tag,cmd):
 tag='apple-'+str(len(records)+1)+'-'+tag;start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,capture_output=True,timeout=180)
 (R/(tag+'.stdout.log')).write_bytes(p.stdout);(R/(tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(R/'apple-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-4000:],flush=True);p.check_returncode()
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
(R/'apple-machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
if not(R/'mlx.metallib').exists():(R/'mlx.metallib').symlink_to(BASE/'mlx.metallib')
for source,obj in [('src/compute_route_apple/apple_row_cache_indexer.cc','indexer'),('src/compute_route_apple/apple_mature_float.cc','mature'),('src/compute_route_apple/apple_context.cc','context'),('src/compute_route_apple/apple_operations.cc','operations'),('src/graph_route_apple/apple_lowering.cc','graph'),('tests/compute_route_vulkan/row_cache_indexer_test.cc','test')]:
 if not(R/(obj+'.o')).exists() or (R/(obj+'.o')).stat().st_mtime<(R/source).stat().st_mtime:
  run(obj+'-compile',[*flags,'-c',R/source,'-o',R/(obj+'.o')])
cmd=[]
for x in link:
 p=Path(x)
 if p.name=='canonical-test':cmd.append(str(R/'indexer-test'))
 elif p.name in {'test.o','mature.o','context.o','operations.o'}:cmd.append(str(R/p.name))
 else:cmd.append(x)
cmd+=[str(R/'indexer.o'),str(R/'graph.o')]
cmd+=[str(R.parent/'inference-foundation-review-20261018-apple-row-cache/test.o')]
run('link',cmd);run('test',[R/'indexer-test','--gtest_filter=AppleRowCacheIndexer.*:AppleRowCache.*'])
if not any(x['tag'].endswith('-perf') and x['exit']==0 for x in records):
 run('perf-compile',[*flags,'-c',R/'perf.cc','-o',R/'perf.o'])
 perf=[str(R/'perf.o') if x==str(R/'test.o') else str(R/'perf') if x==str(R/'indexer-test') else x for x in cmd]
 run('perf-link',perf);run('perf',[R/'perf'])
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(R/'apple-identities.json').write_text(json.dumps([identity(p)for p in map(Path,cmd)if p.is_file()and p.suffix in{'.o','.a','.dylib'}],indent=2)+'\n')
(R/'apple-retain-objects.json').write_text(json.dumps([identity(p)for p in sorted(R.glob('*.o'))],indent=2)+'\n')
(R/'apple-deletable-artifacts.json').write_text(json.dumps([identity(R/n)for n in ['indexer-test','perf']],indent=2)+'\n')
