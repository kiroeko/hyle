from pathlib import Path
import difflib,hashlib,json,re,shutil,subprocess,zipfile
R=Path.cwd();O=Path(__file__).resolve().parent
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=json.loads((O/'paths.json').read_text());new=['src/compute_route_apple/apple_row_cache_indexer.h','src/compute_route_apple/apple_row_cache_indexer.cc','src/compute_route_vulkan/vulkan_row_cache_indexer.cc','src/compute_route_vulkan/shaders/row_cache_indexer.comp','tests/compute_route_vulkan/row_cache_indexer_test.cc']
diff=[];sources=[]
for name in old+new:
 p=R/name;b=O/'before'/name
 before=b.read_text(encoding='utf-8-sig').splitlines(True)if b.exists()else[]
 diff.extend(difflib.unified_diff(before,p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='a/'+name if b.exists()else'/dev/null',tofile='b/'+name))
 dst=O/'source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 sources.append(dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(O/'source.diff').write_text(''.join(diff),encoding='utf-8');write('source-sha.json',sources)
shared=[]
for name in ['include/hyle/compute/model_ops.h','tests/compute_models/row_cache_indexer_fixture.h','tests/compute_models/row_cache_fixture.h']:
 p=R/name;dst=O/'shared-reference'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst);shared.append(dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
write('shared-reference-sha.json',shared)
commands=json.loads((O/'vulkan-commands.json').read_text());link=next(x['command']for x in reversed(commands)if x['tag']=='vulkan-link'and x['exit']==0)
write('vulkan-identities.json',[ident(p)for p in map(Path,link)if p.is_file()and p.suffix.lower()in{'.obj','.lib','.dll'}])
write('retain-objects.json',dict(windows=[ident(p)for p in sorted(O.glob('*.obj'))],apple=json.loads((O/'apple-retain-objects.json').read_text()),rule='Retain all product/test/perf host objects and all pre-existing dependency/native caches.'))
write('deletable-artifacts.json',dict(windows=[ident(p)for p in sorted(O.glob('*.exe'))],apple=json.loads((O/'apple-deletable-artifacts.json').read_text()),rule='Hash-exact proposal only. No deletion performed; root may use test.ps1.'))
performance={}
for platform,filename in [('vulkan','16-perf.stdout.log'),('apple','apple-31-perf.stdout.log')]:
 lines=(O/filename).read_text().splitlines();arms={}
 for line in lines:
  if ' ns:'not in line:continue
  name,tail=line.split(' ns:');samples,median=tail.split(' median=');values=list(map(float,samples.split()));assert len(values)==9
  arms[name]=dict(samples_ns=values,median_ns=float(median))
 performance[platform]=dict(arms=arms,packed_over_dense=arms['packed-tile1']['median_ns']/arms['dense-Lightning-resident']['median_ns'])
write('summary.json',{
 'status':'functional slice implemented/tested/frozen; Apple execution-efficiency remains open',
 'entry':'Existing model_ops::row_cache_indexer_scores() through Apple/Vulkan native Direct and ordinary Graph compile; no custom caller lowering required.',
 'schema':'BF16 Q[T,64,128], U8 canonical row-inline FP4 bank[L,68], BF16 prescaled weights[T,64], I32 ranges[T,2] -> F32 scores[T,L]. No ggml MXFP4 reinterpretation/query quantization/head scale/TopK.',
 'math':'Exact row-code/UE8 decode to BF16; F32 dot -> explicit BF16 RNE -> NaN-preserving ReLU -> weight product rounded BF16 -> sequential F32 head sum -> BF16 RNE widened F32. Outside legal half-open per-query range is -Inf. FMA disabled for these scalar dot implementations.',
 'execution':[
  'Each workgroup handles one(query,key). Only its referenced128 decoded key values and64 head products use shared memory (768B per workgroup, not total device memory). No whole-history decoded tensor, [T,H,L] temporary, per-key host loop or host wait.',
  'Vulkan validates every range in a separate GPU dispatch before a shader barrier; scorer returns before bank access if status is nonzero. Apple all(valid) GPU scalar is an actual fifth private kernel input; the whole validation completes before any bank read. This scalar is passed as a native constant-buffer reference, not host .item/data observation.',
  'Both implementations read bank rows only inside a legal query range; rows outside the active union are not read, including empty ranges. Original checked-status completion stops invalid result publication and preserves escaped older native results.',
  'Apple Direct and Graph exact scorer nodes retain typed operation annotation, so only its bank1 receives a scalar-U8 zero-stride cold placeholder. Real bind shape/extent/stride stays exact. Graph makes this one MLX region boundary, with original per-region synchronize/status cost.',
  'Vulkan expands residual byte-origin protocol to a named six-word per-dispatch array (five caller inputs plus private status capacity), with cold push/binding checks. Current scorer uses20B/five origins and six descriptors. Same-slot weight/range offsets can change without Q/bank origins changing. No weight/range normalization copy was added. General raw custom push constants retain their original device-limit contract.'
 ],
 'memory_limits':['Public output4*T*L remains necessary; input bank remains caller-owned68*L. Per-invocation status/descriptor/recording/result metadata and normal output allocations remain.',
                  'Vulkan retains real maxStorageBufferRange/U32 byte-address, descriptor/workgroup/shared/grid limits. Apple uses ulong data offsets and shape/device grid admission; it does not add an arbitrary2GiB byte gate for this exact scorer.',
                  'No paged scorer/permission binding added in this slice. Ordinary bank is an actual full caller tensor, not a fabricated arena lease.'],
 'actual':{
  'apple':'MacBook Air Mac16,12 M4 arm64 16GiB clang21; final apple-40-test.stdout.log:7/7 (new3 + original codec4).',
  'vulkan':'RTX4070 Windows/MSVC14.50 /W4 /WX; final33-vulkan-test.stdout.log:6/6 (new3 + original codec3).',
  'cases':'Shared canonical test T3/L513, two phases/two independent slots with two replays, every score and Graph Neg dual publish checked against independent FP64+BF16 oracle; counterfactual omitting BF16 boundaries differs. Same-slot only weights/ranges origins change. Three invalid final-query ranges, old result preservation, T0/L0 and L0 invalid range, selected UE255 NaN/finite-to-Inf plus empty-range no-payload behavior.',
  'source':'tests/compute_route_vulkan/row_cache_indexer_test.cc, compiled for Apple with HYLE_ROW_INDEXER_APPLE=1; canonical CMake entries added for both.',
  'reuse':'Fresh only affected Hyle host TUs, residual SPIR-V/generated TU and tests. Original Air SDK/MLX/ggml/metallib and Windows native ggml/IREE/dependencies reused. No SDK/native source rebuild/download.',
  'private_closure':'Run/Dispatch vector object field offsets do not change. Native recorded-origin element construction/destruction is owned by vulkan_run.cc and all accesses by vulkan_pipeline.cc; both fresh, with scorer/operations/Graph lowering fresh. No implicit tail encoding retained.'
 },
 'initial_performance_probe':performance,
 'performance_boundary':'Exactly one2-warmup+9-sample submit/wait batch per arm per device at T3/L513. Resident dense LightningIndexer baseline excludes its prior decode/upload and is equivalent only on onehot Q +1/64 weights where BF16 boundaries are identities; output still matches independent oracle. This is not the richer numerical test and not a full-model benchmark. Initial tile1 Apple median was3.21x slower and remains an open efficiency issue. Vulkan arms close in this small run; no default winner/throughput claim. Probe preceded final all-range-before-bank data edge and six-word origin-record cleanup; GPU dot/decode math was unchanged, but these recorded numbers are not a final-version host-overhead measurement.',
 'failures_retained':['Initial new Vulkan TU compiled before regenerating new shader header; fixed runner order.','Canonical new test lacked model_ops.h; added explicit include.','MSL helper used reserved half identifier; renamed halfway.','Final all_valid GPU scalar is generated as constant bool reference by MLX; corrected pointer-style[0] to scalar use.','Scratch perf had a shadowed local under MSVC/WX; renamed local. No kernel numerical mismatch was observed.'],
 'remaining':'Root requested bounded-keytile MLX BF16 matmul source assessment next; typed paged scorer descriptor/carriers are a separate forthcoming stage. No claim that this feature closes Apple performance, native paged sparse selection, full model or MTP engine.',
 'cleanup':'deletable-artifacts.json exact current executables only; all .obj/.o and original SDK remain reusable.'
})
check=subprocess.run(['git','diff','--check'],cwd=R,capture_output=True);(O/'diff-check.stdout.log').write_bytes(check.stdout);(O/'diff-check.stderr.log').write_bytes(check.stderr);write('diff-check.json',dict(command=['git','diff','--check'],exit=check.returncode));check.check_returncode()
with zipfile.ZipFile(O/'source-results.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(O.rglob('*')):
  rel=p.relative_to(O)
  if not p.is_file()or rel.parts[0]in{'__pycache__','before'}or p.name=='source-results.zip'or p.suffix.lower()in{'.gz','.o','.obj','.exe','.a','.lib','.exp','.spv'}:continue
  z.write(p,rel.as_posix())
with zipfile.ZipFile(O/'source-results.zip')as z:assert z.testzip()is None
print(json.dumps(ident(O/'source-results.zip'),indent=2));print('owned files',len(sources));print(json.dumps(performance,indent=2))
