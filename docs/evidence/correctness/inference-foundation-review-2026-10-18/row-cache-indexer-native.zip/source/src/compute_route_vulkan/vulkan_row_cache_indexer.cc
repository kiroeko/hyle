#include "vulkan_tensor.h"
#include <algorithm>
#include <array>
#include <limits>
#include "hyle/compute/model_ops.h"
#include "vulkan_shaders.h"
namespace hyle::compute::vulkan::detail {
Status lower_row_cache_indexer(ProgramState&program,const PlanStep&step)noexcept try {
  if(step.inputs.size()!=4 || step.outputs.size()!=1)
    return Status::InvalidArgument("Vulkan row indexer ports differ");
  std::array<TensorDesc,4> inputs;for(std::size_t i=0;i<4;++i)inputs[i]=program.values[step.inputs[i]].description;
  std::array<TensorDesc,1> output;HYLE_RETURN_IF_ERROR(infer_output_descriptions(step.operation,inputs,output));
  if(output[0]!=program.values[step.outputs[0]].description)return Status::InvalidArgument("Vulkan row indexer output differs");
  const auto tokens=std::uint64_t(inputs[0].dimensions()[0]),rows=std::uint64_t(inputs[1].dimensions()[0]);
  if(!tokens)return Status::Ok();
  const auto&limits=program.runtime->device->properties.limits;
  if(limits.maxComputeWorkGroupInvocations<128 || limits.maxComputeWorkGroupSize[0]<128 ||
      limits.maxComputeSharedMemorySize<192*4 || limits.maxPerStageDescriptorStorageBuffers<6 ||
      limits.maxDescriptorSetStorageBuffers<6)
    return Status::Unimplemented("Vulkan row indexer workgroup/descriptor limits");
  for(const auto&desc:std::array{inputs[0],inputs[1],inputs[2],inputs[3],output[0]}) {
    HYLE_ASSIGN_OR_RETURN(auto bytes,desc.required_bytes());
    if(bytes>limits.maxStorageBufferRange || bytes>UINT32_MAX-3u)
      return Status::Unimplemented("Vulkan row indexer byte-address capacity");
  }
  while(program.aliases.size()<program.values.size()) {
    const auto id=std::uint32_t(program.aliases.size());program.aliases.push_back({id,0});
  }
  if(!program.status_value) {
    HYLE_ASSIGN_OR_RETURN(auto desc,TensorDesc::dense(DataType::kInt32,{}));
    const auto id=std::uint32_t(program.values.size());program.values.push_back({desc,{}});
    program.aliases.push_back({id,0});program.status_value=id;
  }
  const auto append=[&](std::uint32_t phase,std::uint64_t groups)->Status {
    const auto x=std::min(groups,std::uint64_t(limits.maxComputeWorkGroupCount[0]));
    if(!x || (groups+x-1)/x>limits.maxComputeWorkGroupCount[1])
      return Status::Unimplemented("Vulkan row indexer native dispatch grid");
    const std::array<SpecializationConstant,3> constants{{{0,phase},{1,std::uint32_t(tokens)},{2,std::uint32_t(rows)}}};
    Dispatch d;d.values={step.inputs[0],step.inputs[1],*program.status_value,step.inputs[2],step.inputs[3],step.outputs[0]};
    HYLE_ASSIGN_OR_RETURN(d.pipeline,create_pipeline(program.runtime->device,{shaders::row_cache_indexer(),6,20,constants}));
    d.groups={std::uint32_t(x),std::uint32_t((groups+x-1)/x),1};
    d.tensor_byte_origins=true;d.checked_status=true;d.push.resize(20);
    program.dispatches.push_back(std::move(d));return Status::Ok();
  };
  HYLE_RETURN_IF_ERROR(append(0,(tokens+127)/128));
  return rows?append(1,tokens*rows):Status::Ok();
}catch(const std::bad_alloc&){return Status::ResourceExhausted("Vulkan row indexer metadata");}
}
