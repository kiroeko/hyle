from pathlib import Path
import sys,json,time,subprocess,os,hashlib
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-foundation-review-2026-10-18/mla-pending-graph';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import build_host as b
flags=b.flags+['/I'+str(ROOT/'tests/compute_batch')]
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,cmd,timeout=180):
 cmd=list(map(str,cmd));attempt=sum(x['tag']==tag for x in records);prefix=f'attempt{attempt}-' if attempt else '';t=time.monotonic()
 try:p=subprocess.run(cmd,cwd=ROOT,env=b.env,capture_output=True,timeout=timeout)
 except subprocess.TimeoutExpired as e:
  (OUT/(prefix+tag+'.stdout.log')).write_bytes(e.stdout or b'');(OUT/(prefix+tag+'.stderr.log')).write_bytes(e.stderr or b'');records.append(dict(tag=tag,command=cmd,exit='timeout',seconds=timeout));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print((e.stdout or b'').decode(errors='replace'));raise
 (OUT/(prefix+tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(prefix+tag+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-6500:],p.stderr.decode(errors='replace')[-1800:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
for src,name in [('src/graph_batch/batch.cc','graph-batch'),('tests/compute_batch/public_mla_pending_graph_cuda_consumer.cc','consumer')]:
 if name=='graph-batch' and '--reuse-graph' in sys.argv:continue
 run(name+'-compile',[b.cl,*flags,ROOT/src,'/Fo'+str(OUT/(name+'.obj'))])
old=ROOT/'.scratch/inference-feature-completion-2026-10-18/mla';active=ROOT/'.scratch/inference-foundation-review-2026-10-18/mla-active-workspace'
link=next(x['command'] for x in json.loads((active/'commands.json').read_text()) if x['tag']=='budget-link')
exe=OUT/'consumer.exe'
replace={str(active/'consumer.obj'):str(OUT/'consumer.obj'),str(old/'graph-batch.obj'):str(OUT/'graph-batch.obj'),str(active/'budget.exe'):str(exe),str(active/'budget.map'):str(OUT/'consumer.map'),str(old/'batch-execution.obj'):str(ROOT/'.scratch/inference-foundation-review-2026-10-18/mla-pending/batch-execution.obj')}
link=[('/OUT:'+str(exe)) if x.startswith('/OUT:') else ('/MAP:'+str(OUT/'consumer.map')) if x.startswith('/MAP:') else replace.get(x,x) for x in link]
for x in link:
 if x.endswith('.lib') and Path(x).is_absolute():b.env['PATH']=str(Path(x).parent)+os.pathsep+b.env['PATH']
run('link',link)
(OUT/'run-plan.json').write_text(json.dumps(dict(command=[str(exe)],path=b.env['PATH'],cold='Graph default command replay + same native specialization warm before gated producer; no native capture requested',source_sha256=hashlib.sha256((ROOT/'tests/compute_batch/public_mla_pending_graph_cuda_consumer.cc').read_bytes()).hexdigest()),indent=2)+'\n')
paths=[Path(x)for x in link if x.endswith(('.obj','.lib'))and Path(x).is_file()]
paths += [ROOT/'tests/compute_batch/public_mla_pending_graph_cuda_consumer.cc',ROOT/'src/graph_batch/batch.cc',active/'native_mla.obj']
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in dict.fromkeys(paths)],indent=2)+'\n')
