from pathlib import Path
import subprocess,json,time,os,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
plan=json.loads((OUT/'run-plan.json').read_text());env=os.environ.copy();env['PATH']=plan['path'];records=json.loads((OUT/'commands.json').read_text());attempt=sum(x['tag']=='consumer-run'for x in records);tag=f'attempt{attempt}-consumer';t=time.monotonic()
try:p=subprocess.run(plan['command'],cwd=ROOT,env=env,capture_output=True,timeout=20)
except subprocess.TimeoutExpired as e:
 (OUT/(tag+'.stdout.log')).write_bytes(e.stdout or b'');(OUT/(tag+'.stderr.log')).write_bytes(e.stderr or b'');records.append(dict(tag='consumer-run',command=plan['command'],exit='timeout',seconds=20));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print((e.stdout or b'').decode(errors='replace'));raise
(OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag='consumer-run',command=plan['command'],exit=p.returncode,seconds=time.monotonic()-t));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'),'EXIT',p.returncode);sys.exit(p.returncode)
