from pathlib import Path
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SHADERS = OUT / 'shaders'
SHADERS.mkdir(exist_ok=True)
cache = json.loads((ROOT / '.scratch/inference-foundation-review-2026-10-18/gather-elements-native/vulkan/commands.json').read_text())
cc = next(r['command'] for r in cache if r['tag'] == 'operations-compile')
CL = Path(cc[0])
FLAGS = ['/I' + str(SHADERS)] + cc[1:-2]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
ENV.update(VSLANG='1033', DISABLE_VULKAN_OBS_CAPTURE='1', VK_LOADER_LAYERS_DISABLE='~all~')
ENV['PATH'] = str(ROOT / '.scratch/build-compute-v2-dev/bin') + os.pathsep + ENV['PATH']
RECORDS = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def run(tag, args):
    args = list(map(str, args))
    stem = tag + '-' + str(1 + sum(r['tag'] == tag for r in RECORDS))
    start = time.monotonic()
    result = subprocess.run(args, cwd=ROOT, env=ENV, capture_output=True, timeout=180)
    (OUT / (stem + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(result.stderr)
    RECORDS.append(dict(tag=tag, command=args, exit=result.returncode, seconds=time.monotonic()-start))
    (OUT / 'commands.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    print(tag, result.returncode, round(RECORDS[-1]['seconds'], 2), flush=True)
    print(result.stdout.decode(errors='replace')[-6000:], result.stderr.decode(errors='replace')[-2400:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


def shaders():
    run('shaders', [sys.executable, ROOT / 'src/compute_route_vulkan/build_shaders.py',
        '--compiler', 'C:/public/tools/glslang/glslangValidator.exe',
        '--source', ROOT / 'third_party/ggml_vulkan_shaders/shaders',
        '--tensor-source', ROOT / 'src/compute_route_vulkan/shaders', '--output', SHADERS])


def build():
    for path, stem in [(ROOT / 'src/compute_route_vulkan/vulkan_row_cache.cc', 'row-cache'),
                        (ROOT / 'src/compute_route_vulkan/vulkan_operations.cc', 'operations'),
                        (SHADERS / 'vulkan_shaders.cc', 'shaders'),
                        (ROOT / 'src/graph_route_vulkan/vulkan_lowering.cc', 'graph-lowering'),
                        (ROOT / 'tests/compute_route_vulkan/row_cache_test.cc', 'tests')]:
        target = OUT / (stem + '.obj')
        if not target.exists() or target.stat().st_mtime < path.stat().st_mtime:
            run(stem + '-compile', [CL, *FLAGS, path, '/Fo' + str(target)])
    link()


def link():
    old = ROOT / '.scratch/inference-foundation-review-2026-10-18/batched-sink-vulkan-graph'
    records = json.loads((old / 'commands.json').read_text())
    ld = next(r['command'] for r in reversed(records) if r['tag'] == 'link')
    exclude = {str(old / 'tests.obj'), str(old / 'operations.obj')}
    args = [a for a in ld if a not in exclude and not a.startswith(('/OUT:', '/MAP:'))
            and not a.endswith(('graph-lowering.obj', '\\graph.obj'))]
    missing = [a for a in args if a.endswith(('.obj', '.lib')) and Path(a).is_absolute() and not Path(a).exists()]
    assert not missing, missing
    runtime = [str(Path(a).parent) for a in args if a.endswith('.lib') and Path(a).is_absolute()]
    ENV['PATH'] = os.pathsep.join(dict.fromkeys(runtime)) + os.pathsep + ENV['PATH']
    args += [OUT / (stem + '.obj') for stem in ['row-cache', 'operations', 'shaders', 'graph-lowering', 'tests']]
    args += [ROOT / '.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj',
             '/OUT:' + str(OUT / 'row-cache.exe')]
    run('link', args)


def test():
    run('tests', [OUT / 'row-cache.exe', '--gtest_color=no', '--gtest_filter=VulkanRowCache.*'])


if __name__ == '__main__':
    for action in sys.argv[1:] or ['shaders', 'build', 'test']:
        globals()[action]()
