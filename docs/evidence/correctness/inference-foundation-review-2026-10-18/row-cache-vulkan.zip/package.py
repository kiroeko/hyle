from pathlib import Path
import difflib
import hashlib
import json
import struct
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    product = [
        'src/compute_route_vulkan/vulkan_row_cache.cc',
        'src/compute_route_vulkan/shaders/row_cache.comp',
        'src/compute_route_vulkan/vulkan_tensor.h',
        'src/compute_route_vulkan/vulkan_operations.cc',
        'src/compute_route_vulkan/CMakeLists.txt',
        'src/compute_route_vulkan/build_shaders.py',
        'src/graph_route_vulkan/vulkan_lowering.cc',
        'tests/compute_route_vulkan/CMakeLists.txt',
        'tests/compute_route_vulkan/row_cache_test.cc',
    ]
    support = [
        'tests/compute_models/row_cache_fixture.h',
        'tests/compute_route_vulkan/tensor_test_support.h',
        'tests/compute_route_vulkan/fixture.h',
        'include/hyle/compute/low_precision.h',
        'include/hyle/compute/model_ops.h',
        'src/compute_ops/low_precision.cc',
        'src/compute_route_vulkan/vulkan_pipeline.cc',
        'src/compute_route_vulkan/vulkan_program_internal.h',
    ]
    diff = []
    for name in product:
        before = OUT / 'before' / name
        original = before.read_text('utf-8').splitlines(True) if before.exists() else []
        diff.extend(difflib.unified_diff(original, (ROOT / name).read_text('utf-8').splitlines(True),
                    fromfile='before/' + name, tofile='after/' + name))
    (OUT / 'task.diff').write_text(''.join(diff), encoding='utf-8')
    hardware = subprocess.run(['nvidia-smi', '--query-gpu=name,driver_version,memory.total',
        '--format=csv,noheader'], capture_output=True, check=True)
    (OUT / 'machine.txt').write_bytes(hardware.stdout)
    words = struct.unpack('<' + 'I' * ((OUT / 'shaders/row_cache.spv').stat().st_size // 4),
                          (OUT / 'shaders/row_cache.spv').read_bytes())
    capabilities = []
    at = 5
    while at < len(words):
        size, opcode = words[at] >> 16, words[at] & 65535
        assert size > 0
        if opcode == 17:
            capabilities.append(words[at + 1])
        at += size
    assert at == len(words) and capabilities == [1], capabilities
    (OUT / 'identities.json').write_text(json.dumps({
        'sources': [identity(ROOT / n) for n in product + support],
        'objects': [identity(p) for p in sorted(OUT.glob('*.obj'))],
        'generated': [identity(p) for p in sorted((OUT / 'shaders').iterdir())],
        'shader_capabilities': capabilities,
        'compiler': identity(Path('C:/public/tools/glslang/glslangValidator.exe')),
    }, indent=2) + '\n', encoding='utf-8')
    summary = {
        'status': 'Implemented Vulkan Direct and public Graph row cache codec; actual 3/3 PASS',
        'format': 'Same explicit Hyle row-inline 584B/68B ABI and frozen independent FP64 fixture; not official/native page-footer ABI.',
        'implementation': 'One residual U32 shader with specialization phases: validate all finite BF16 input then encode; validate all I32 IDs then decode only selected rows. Original private status/dispatch barriers/publication protocol, byte origins, dense output and padded descriptors. No optional 8/16/64-bit shader capability.',
        'numeric': 'Exact integer absmax/ceil-power scale and integer dyadic-to-BF16 decode avoid log/divide boundary and FTZ dependence. Original nearest-even FP8/FP4 codes, signed zero, pad0 and raw BF16 tail.',
        'validation': [
            'Both encodings, two changed phases, public Graph Encode->GatherDecode with dual published output, two independent slots, replay and retained old tensors: complete bytes and selected BF16 bits equal shared oracle.',
            'Direct encode/decode, checked/unchecked, repeated/high IDs, odd byte-origin U8 bank; last invalid {-1,5,INT_MAX} preserves entire recorded output sentinel, fresh calls recover.',
            'Late NaN/+Inf/-Inf encoder input preserves whole recorded output; scalar IDs, empty encode and empty bank+IDs, UE8=0/255, E4 reserved NaN, negative zero, raw BF16 tail.',
        ],
        'hardware': 'Windows existing default Vulkan context; machine.txt reports RTX4070 driver617.14. MSVC14.50.35717 and cached glslang.',
        'build': 'Fresh Vulkan row-cache/operations/public Graph lowering/test host TUs and generated residual shader TU. Nine residual variants generated in0.73s; ggml/IREE/SDK reused, no configure/full SDK/native rebuild or download. Product/test CMake registrations source-reviewed, not a full CMake build.',
        'failures_retained': [
            'Initial test2/3: Direct passed, public Graph explicitly lacked custom schema admission. Added the two public RowCache op IDs to actual custom lowering allowlist.',
            'Initial link of refreshed Graph lowering retained another old graph.obj implementing the same entry. Removed that old whole-object override from the link closure; no native runtime failure.',
        ],
        'review': 'Root source review and independent partial numeric/descriptor/status review found no further confirmed blocking issue. Existing 4B padded descriptor range validation protects cross-word U8 loads.',
        'limits': [
            'Input/output descriptors remain within device maxStorageBufferRange and UINT32 byte addressing; workgroup and dispatch grid limits checked.',
            'Selected rows only, no full-history decode, full-output scratch, host ID readback or new queue. Existing terminal private-status observation remains.',
            'No paged row reader, per-query sparse Sink integration, entire model, throughput or whole-process peak-memory claim.',
        ],
        'reproduce': 'run.py shaders/build/test; final tests-2.stdout.log; first failure and exact command ledger retained.',
        'product_files': product,
    }
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    (OUT / 'cleanup-candidates.json').write_text(json.dumps({
        'files': [identity(p) for p in OUT.glob('*.exe')],
        'retain_objects': [str(p) for p in OUT.glob('*.obj')],
        'intent': 'Candidates only; root test.ps1 owns deletion after central archive verification.',
    }, indent=2) + '\n', encoding='utf-8')
    entries = [(p, p.name) for p in sorted(OUT.iterdir())
               if p.is_file() and p.suffix in {'.py', '.json', '.log', '.diff', '.txt'}]
    entries += [(p, p.relative_to(OUT).as_posix()) for p in sorted((OUT / 'before').rglob('*')) if p.is_file()]
    entries += [(ROOT / name, 'source/' + name) for name in product + support]
    entries += [(OUT / 'shaders' / name, 'generated/' + name)
                for name in ['vulkan_shaders.h', 'vulkan_shaders.cc']]
    target = OUT / 'source-results.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, name in entries:
            archive.writestr(name, path.read_bytes())
    print(json.dumps(identity(target)))


if __name__ == '__main__':
    main()
