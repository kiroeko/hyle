from pathlib import Path
import difflib,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];BASE=OUT.parent/'qwen-fixed-decode'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
    p=Path(p); b=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
plan=read(BASE/'matched-link-plan.json')
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':plan['command'][0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent)for x in plan['command']if x.endswith('.lib')))+os.pathsep+env['PATH']
def call(tag,argv,outputs=()):
    assert not(OUT/(tag+'.result.json')).exists(),tag
    row=dict(argv=list(map(str,argv)),started=time.time());save(OUT/(tag+'.command.json'),row)
    with(OUT/(tag+'.stdout.log')).open('wb')as so,(OUT/(tag+'.stderr.log')).open('wb')as se:
        p=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=p.pid;save(OUT/'live.json',row);row['exit']=p.wait()
    row.update(terminal=True,finished=time.time(),outputs=[ident(p)for p in outputs if Path(p).is_file()]);save(OUT/(tag+'.result.json'),row);save(OUT/'live.json',row)
    print(tag,row['exit'],round(row['finished']-row['started'],3),flush=True)
    if row['exit']:print((OUT/(tag+'.stderr.log')).read_text(errors='replace')[-4000:]);raise SystemExit(1)
def build():
    sources=[];diff=[]
    for name in ['main.cc','README.md']:
        original=ROOT/'tools/qwen35_text'/name;before=OUT/'before'/name;after=OUT/'candidate'/name
        after.parent.mkdir(exist_ok=True);after.write_bytes(original.read_bytes())
        sources.append(dict(relative='tools/qwen35_text/'+name,before=ident(before),candidate=ident(after)))
        diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),after.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+name,tofile='candidate/'+name))
    save(OUT/'source-identities.json',sources);(OUT/'source.diff').write_text(''.join(diff),encoding='utf-8')
    argv=read(BASE/'compile-consumer.command.json')['argv']
    argv=[x for x in argv if not x.lower().startswith('/fo')]
    i=argv.index('/sourceDependencies');argv[i+1]=str(OUT/'consumer.deps.json');argv.append('/Fo'+str(OUT/'consumer.obj'))
    call('compile-consumer',argv,[OUT/'consumer.obj',OUT/'consumer.deps.json'])
    argv=[str(OUT/'consumer.obj')if x==str(BASE/'consumer.obj')else x for x in plan['command']]
    assert str(OUT/'consumer.obj')in argv
    argv=[x for x in argv if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
    argv+=['/OUT:'+str(OUT/'qwen-timed.exe'),'/MAP:'+str(OUT/'qwen-timed.map'),'/IMPLIB:'+str(OUT/'qwen-timed.lib')]
    save(OUT/'matched-link-plan.json',dict(command=argv,base=str(BASE/'matched-link-plan.json')))
    call('link-current',argv,[OUT/('qwen-timed'+s)for s in ['.exe','.map','.lib','.exp']])
def execute(mode):
    call('run-'+mode,[OUT/'qwen-timed.exe','--inputs',BASE/'science-inputs','--decode-ids',BASE/'science-decode.ids','--capacity','64','--progress',mode])
    expected=json.loads((BASE/'run-final-science.stdout.log').read_text().splitlines()[-1]);actual=json.loads((OUT/('run-'+mode+'.stdout.log')).read_text().splitlines()[-1])
    assert actual==expected
    rows=[]
    for line in(OUT/('run-'+mode+'.stderr.log')).read_text().splitlines():
        if not(line.startswith('decode')or line.startswith('prefill ')):continue
        fields=line.split();row={'phase':fields[0]}
        for item in fields[1:]:
            key,val=item.split('=',1)
            row[key]=val if key=='progress'else float(val)if 'seconds'in key else int(val)
        assert row['step_seconds']>=row['seconds']>=row['submit_seconds']
        row['pre_submit_seconds']=row['step_seconds']-row['seconds'];rows.append(row)
    assert len(rows)==32
    save(OUT/('timings-'+mode+'.json'),dict(phases=rows,outputs_equal_original_fixed_sequence=True,trace_enabled=False,isolated_performance_trial=False,precision_or_throughput_acceptance=False,step_boundary='after shape lookup/create, before positions/input uploads through token read; includes batch/bind/replay preparation; excludes model loading, cold shape compilation and trace'))
if __name__=='__main__':
    if sys.argv[1]=='build':build()
    elif sys.argv[1]in{'direct','scheduler'}:execute(sys.argv[1])
    else:raise ValueError(sys.argv[1])
