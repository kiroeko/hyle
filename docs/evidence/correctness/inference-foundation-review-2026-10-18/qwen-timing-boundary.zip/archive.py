from pathlib import Path
import hashlib,json,zipfile
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def ident(p):
    b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
for mode in ['direct','scheduler']:
    receipt=json.loads((OUT/('timings-'+mode+'.json')).read_text())
    assert len(receipt['phases'])==32 and receipt['outputs_equal_original_fixed_sequence']
files=[p for p in sorted(OUT.rglob('*'))if p.is_file()and p.suffix in {'.py','.json','.cc','.md','.diff','.log'}and p.name not in {'archive-receipt.json'}]
assert all(not p.is_symlink()for p in files)
entries=[dict(relative=p.relative_to(OUT).as_posix(),**ident(p))for p in files]
dest=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-timing-boundary.zip'
assert not dest.exists()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for p in files:z.write(p,p.relative_to(OUT).as_posix())
    z.writestr('archive-manifest.json',json.dumps(entries,indent=2)+'\n')
with zipfile.ZipFile(dest)as z:
    assert z.testzip()is None
    for e in entries:assert hashlib.sha256(z.read(e['relative'])).hexdigest()==e['sha256']
assert all(ident(p)['sha256']==e['sha256']for p,e in zip(files,entries))
result=dict(archive=ident(dest),entries=len(entries)+1,crc_verified=True,all_payload_sha256_verified=True,throughput_or_quality_acceptance=False)
save(OUT/'archive-receipt.json',result);print(json.dumps(result))
