from pathlib import Path
p=Path('src/graph/leased_invocation.cc');s=p.read_text();a=s.index('  const auto codec=decode.custom_as<compute::model_ops::RowCacheGatherDecode>();',s.index('Result<mem::MemoryResourceRef> RegionAccess::row_cache_resource'));b=s.index('  for(const auto node:{mapping,decoder})',a)
s=s[:a]+'''  const auto codec=decode.custom_as<compute::model_ops::RowCacheGatherDecode>();
  const auto padded=decode.custom_as<compute::model_ops::RowCacheGatherDecodePadded>();
  const auto scorer=map.custom_as<compute::detail::RowCachePagedIndexerScores>();
  const auto padded_map=map.custom_as<compute::detail::RowCachePaddedMap>();
  const auto ordinary_map=map.custom_as<compute::detail::RowCacheMap>();
  const auto bank_port=scorer?1u:0u,metadata_port=scorer?4u:(padded_map?2u:1u);
  HYLE_ASSIGN_OR_RETURN(auto bank,graph.node_input(decoder,bank_port));
  HYLE_ASSIGN_OR_RETURN(auto meta,graph.node_input(mapping,metadata_port));
  HYLE_ASSIGN_OR_RETURN(auto map_inputs,graph.node_input_count(mapping));HYLE_ASSIGN_OR_RETURN(auto map_outputs,graph.node_output_count(mapping));
  HYLE_ASSIGN_OR_RETURN(auto decode_inputs,graph.node_input_count(decoder));HYLE_ASSIGN_OR_RETURN(auto decode_outputs,graph.node_output_count(decoder));
  ValueId mapped;
  if(scorer){
    if(mapping!=decoder || map_inputs!=5 || map_outputs!=1 || decode_inputs!=5 || decode_outputs!=1)
      return std::unexpected(Status::InvalidArgument("row scorer role/ports differ"));
  }else{
    HYLE_ASSIGN_OR_RETURN(mapped,graph.result(mapping,0));HYLE_ASSIGN_OR_RETURN(auto ids,graph.node_input(decoder,1));
    if((padded_map?(!padded || map_inputs!=3 || map_outputs!=2):(!ordinary_map || !codec || codec->bounds!=compute::IndexBoundsPolicy::kChecked || map_inputs!=2 || map_outputs!=1)) ||
        decode_inputs!=2 || decode_outputs!=1 || ids!=mapped)
      return std::unexpected(Status::InvalidArgument("row projection has no exact Map-to-checked-codec producer chain"));
  }
  if(bank!=capacity || meta!=metadata || mapping.ordinal()>=plan->node_steps.size() || decoder.ordinal()>=plan->node_steps.size() ||
      plan->node_steps[mapping.ordinal()]>=plan->steps.size() || plan->node_steps[decoder.ordinal()]>=plan->steps.size())
    return std::unexpected(Status::InvalidArgument("row projection identities differ"));
  // Metadata and translated physical IDs remain private even when the
  // additive padding mask or logical score output is published/branched.
  for(std::size_t i=0;i<graph.output_count();++i){HYLE_ASSIGN_OR_RETURN(auto v,graph.output_id(i));
    if(v==metadata || v==capacity || (mapped.valid() && v==mapped))
      return std::unexpected(Status::InvalidArgument("row projection publishes private storage"));}
  for(std::size_t i=0;i<graph.node_count();++i){HYLE_ASSIGN_OR_RETURN(auto node,graph.node_id(i));HYLE_ASSIGN_OR_RETURN(auto count,graph.node_input_count(node));
    for(std::size_t port=0;port<count;++port){HYLE_ASSIGN_OR_RETURN(auto value,graph.node_input(node,port));
      if((value==metadata && (node!=mapping || port!=metadata_port)) ||
         (value==capacity && (node!=decoder || port!=bank_port)) ||
         (mapped.valid() && value==mapped && (node!=decoder || port!=1)))
        return std::unexpected(Status::InvalidArgument("row projection has an unrelated private reader"));}}
'''+s[b:]
s=s.replace('if(input!=root || i!=plan->node_steps[decoder.ordinal()] || step.kind!=PlanStepKind::kOperation)','if(input!=root || i!=plan->node_steps[decoder.ordinal()] || step.kind!=PlanStepKind::kOperation || port!=bank_port)',1)
s=s.replace('''  if(!binding || !binding->input || !tensor.valid() || tensor.description()!=description || tensor.storage().resource()!=resource || (pages.empty() && count && !pending) || (pending && !pages.empty()))''','''  HYLE_ASSIGN_OR_RETURN(auto operation,graph.operation(decoder));
  const bool empty_safe=operation.custom_as<compute::model_ops::RowCacheGatherDecodePadded>() || operation.custom_as<compute::detail::RowCachePagedIndexerScores>();
  if(!binding || !binding->input || !tensor.valid() || tensor.description()!=description || tensor.storage().resource()!=resource ||
      (pages.empty() && count && !pending && !empty_safe) || (pending && !pages.empty()))''')
p.write_text(s,newline='\n')
p=Path('src/graph_batch/batch.cc');s=p.read_text();a=s.index('Status Invocation::prepare_batch(std::span<const NodeLayout>layouts,bool update)')
s=s[:a]+'''Result<Invocation> Invocation::create(const Graph&graph,const Executable&executable,std::span<const LaneBinding>lanes,
    std::span<const PagedRowCacheGather>rows,std::span<const PagedRowCacheIndexer>scorers,LeasedInvocationOptions options,ReplayOptions replay)noexcept{
  std::vector<PagedRowCacheGather,mem::StdAllocator<PagedRowCacheGather>>all{mem::StdAllocator<PagedRowCacheGather>(options.allocator)};
  if(scorers.size()>SIZE_MAX-rows.size())return std::unexpected(Status::ResourceExhausted("row Graph macro count overflows"));
  try{all.reserve(rows.size()+scorers.size());all.insert(all.end(),rows.begin(),rows.end());
    for(const auto&s:scorers)all.push_back(detail::RowCacheAccess::reader(s));}
  catch(...){return std::unexpected(Status::ResourceExhausted("row Graph macro metadata"));}
  return create(graph,executable,lanes,all,options,replay);
}
'''+s[a:]
s=s.replace('if(count && !rows[i].layout.facts().kv_rows)return Status::OutOfRange("row Graph nonempty selections cannot read empty histories");','''if(count && !rows[i].layout.facts().kv_rows && !detail::RowCacheAccess::empty_safe(data_->graph,found->recipe))
      return Status::OutOfRange("row Graph nonempty selections cannot read empty histories");
    HYLE_ASSIGN_OR_RETURN(auto operation,data_->graph.operation(found->recipe.node()));
    if(const auto scorer=operation.custom_as<cd::RowCachePagedIndexerScores>()){
      const auto host=rows[i].layout.host();const auto page_size=found->recipe.schema().capacity().page_size;
      for(std::size_t request=0;request<rows[i].layout.facts().requests;++request){
        const auto refs=host.kv_indptr[request+1]-host.kv_indptr[request];
        const auto length=refs?std::uint64_t(refs-1)*page_size+std::uint32_t(host.last_page_lengths[request]):0;
        if(length>scorer->score_columns)return Status::OutOfRange("row Graph history exceeds logical score columns");}
    }''')
p.write_text(s,newline='\n')
