#pragma once
#include "hyle/graph/batch.h"
#include "../compute_batch/row_cache_map.h"
namespace hyle::graph::batch::detail {
struct RowCacheAccess final {
  static ValueId metadata(const PagedRowCacheGather&v)noexcept{return v.metadata_;}
  static NodeId map(const PagedRowCacheGather&v)noexcept{return v.map_;}
  static compute::detail::RowCacheMap operation(const PagedRowCacheGather&v)noexcept{
    const auto offsets=v.schema_.metadata_offsets();const auto cap=v.schema_.capacity();
    return {offsets.query_indptr,offsets.kv_indptr,offsets.page_indices,offsets.last_page_lengths,offsets.bytes,cap.page_size,cap.max_pages};
  }
  static Status validate(const Graph&,const PagedRowCacheGather&)noexcept;
};
}
