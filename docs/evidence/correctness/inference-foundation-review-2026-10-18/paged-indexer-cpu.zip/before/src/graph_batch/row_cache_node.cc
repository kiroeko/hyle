#include "row_cache_node.h"
#include "hyle/compute/model_ops.h"
#include <array>
namespace hyle::graph::batch {
namespace c=compute;
Result<PagedRowCacheGather> add_row_cache_gather(GraphBuilder&builder,c::RowCacheBatchSchema schema,ValueId ids)noexcept{
  if(!schema.valid())return std::unexpected(Status::InvalidArgument("row Graph schema is empty"));
  const auto cap=schema.capacity();const auto rows=std::uint64_t(cap.max_pages)*cap.page_size;
  if(rows>std::uint64_t(INT32_MAX)+1)return std::unexpected(Status::OutOfRange("row Graph physical I32 row capacity"));
  PagedRowCacheGather result;result.schema_=std::move(schema);result.ids_=ids;
  HYLE_ASSIGN_OR_RETURN(auto bank,c::row_cache_carrier_description(cap.encoding,std::int64_t(rows)));
  HYLE_ASSIGN_OR_RETURN(result.bank_,builder.input(bank));
  HYLE_ASSIGN_OR_RETURN(auto metadata,c::TensorDesc::dense(c::DataType::kUInt8,std::array<std::int64_t,1>{std::int64_t(result.schema_.metadata_offsets().bytes)}));
  HYLE_ASSIGN_OR_RETURN(result.metadata_,builder.input(metadata));
  HYLE_ASSIGN_OR_RETURN(result.map_,builder.add_node(c::Operation::custom(detail::RowCacheAccess::operation(result)),std::array{ids,result.metadata_}));
  HYLE_ASSIGN_OR_RETURN(result.mapped_,builder.result(result.map_));
  HYLE_ASSIGN_OR_RETURN(result.decode_,builder.add_node(c::model_ops::row_cache_gather_decode(cap.encoding),std::array{result.bank_,result.mapped_}));
  HYLE_ASSIGN_OR_RETURN(result.output_,builder.result(result.decode_));return result;
}
Status detail::RowCacheAccess::validate(const Graph&graph,const PagedRowCacheGather&r)noexcept{
  if(!graph.valid() || !r.valid())return Status::InvalidArgument("row Graph macro is empty");
  HYLE_ASSIGN_OR_RETURN(auto map,graph.operation(r.map_));HYLE_ASSIGN_OR_RETURN(auto decode,graph.operation(r.decode_));
  const auto actual=map.custom_as<c::detail::RowCacheMap>();const auto expected=operation(r);
  const auto codec=decode.custom_as<c::model_ops::RowCacheGatherDecode>();
  if(!actual || actual->query_offset!=expected.query_offset || actual->kv_offset!=expected.kv_offset ||
     actual->page_offset!=expected.page_offset || actual->tail_offset!=expected.tail_offset || actual->metadata_bytes!=expected.metadata_bytes ||
     actual->page_size!=expected.page_size || actual->max_pages!=expected.max_pages || !codec ||
     codec->encoding!=r.schema_.capacity().encoding || codec->bounds!=c::IndexBoundsPolicy::kChecked)
    return Status::InvalidArgument("row Graph operations differ from the owned macro");
  HYLE_ASSIGN_OR_RETURN(auto a,graph.node_input(r.map_,0));HYLE_ASSIGN_OR_RETURN(auto b,graph.node_input(r.map_,1));
  HYLE_ASSIGN_OR_RETURN(auto d,graph.node_input(r.decode_,0));HYLE_ASSIGN_OR_RETURN(auto e,graph.node_input(r.decode_,1));
  HYLE_ASSIGN_OR_RETURN(auto m,graph.result(r.map_));HYLE_ASSIGN_OR_RETURN(auto o,graph.result(r.decode_));
  HYLE_ASSIGN_OR_RETURN(auto id_desc,graph.value_description(a));
  if(a!=r.ids_ || b!=r.metadata_ || d!=r.bank_ || e!=r.mapped_ || m!=r.mapped_ || o!=r.output_ ||
      r.bank_.kind()!=ValueKind::kInput || r.metadata_.kind()!=ValueKind::kInput ||
      std::uint64_t(id_desc.dimensions()[0])>r.schema_.capacity().max_query_rows)
    return Status::InvalidArgument("row Graph macro ports/selection rows differ");
  for(std::size_t i=0;i<graph.output_count();++i){HYLE_ASSIGN_OR_RETURN(auto v,graph.output_id(i));
    if(v==r.bank_ || v==r.metadata_ || v==r.mapped_)return Status::InvalidArgument("row Graph private capacity/metadata/map cannot be published");}
  for(std::size_t i=0;i<graph.node_count();++i){HYLE_ASSIGN_OR_RETURN(auto node,graph.node_id(i));HYLE_ASSIGN_OR_RETURN(auto count,graph.node_input_count(node));
    for(std::size_t p=0;p<count;++p){HYLE_ASSIGN_OR_RETURN(auto v,graph.node_input(node,p));
      if((v==r.bank_ && (node!=r.decode_ || p!=0)) || (v==r.metadata_ && (node!=r.map_ || p!=1)) ||
          (v==r.mapped_ && (node!=r.decode_ || p!=1)))return Status::InvalidArgument("row Graph private input has an extra reader");}}
  return Status::Ok();
}
}
