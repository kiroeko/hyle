from pathlib import Path
import json,sys,subprocess,os,time
R=Path.cwd();O=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
history=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-graph/commands.json').read_text())
flagcmd=next(x['command']for x in history if x['tag']=='leased-compile'and x['exit']==0)
graphflags=[x for x in flagcmd if not x.endswith('.cc')and not x.startswith('/Fo')]
torchhist=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/packed-indexer-cpu/commands.json').read_text())
torchcmd=next(x['command']for x in reversed(torchhist)if x['tag']=='torch-cpu-v3-compile'and x['exit']==0)
torchflags=[x for x in torchcmd if not x.startswith(('/Tp','/Fo'))]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':graphflags[0],'CMAKE_C_COMPILER':graphflags[0]});env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
torch=Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
env['PATH']=str(torch/'lib')+os.pathsep+str(R/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
records=json.loads((O/'commands.json').read_text())if(O/'commands.json').exists()else[]
def run(tag,cmd):
 cmd=list(map(str,cmd));t=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,timeout=240,creationflags=subprocess.CREATE_NO_WINDOW)
 stem=str(len(records)+1)+'-'+tag;(O/(stem+'.stdout.log')).write_bytes(p.stdout);(O/(stem+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-t));(O/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(stem,p.returncode,p.stdout.decode(errors='replace')[-5500:],p.stderr.decode(errors='replace')[-2500:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
def compile(src,name,flags=graphflags):run(name+'-compile',[*flags,'/Tp'+str(R/src),'/Fo'+str(O/(name+'.obj'))])
action=sys.argv[1]
if action=='build':
 selected=sys.argv[2:]
 for src,name,flags in [('src/compute_provider_native/row_cache.cc','codec',torchflags),('src/compute_provider_native/native_provider.cc','native-provider',torchflags),('src/compute_provider_native/torch_cpu_program.cc','torch',torchflags),('src/graph/leased_invocation.cc','leased',graphflags),('src/graph_batch/batch.cc','batch',graphflags),('src/graph_batch/row_cache_node.cc','node',graphflags),('tests/graph_batch/row_cache_indexer_graph_test.cc','tests',graphflags),('tests/compute_route_cpu/row_cache_padded_test.cc','padded-tests',graphflags)]:
  if not selected or name in selected:compile(src,name,flags)
elif action=='link':
 old=next(x['command']for x in reversed(history)if x['tag']=='cpu-link'and x['exit']==0)
 remove={'leased.obj','batch.obj','node.obj','cpu-test.obj','cpu-codec.obj','cpu-native-provider.obj','native-node-test.obj'}
 cmd=[x for x in old if not x.startswith(('/OUT:','/MAP:')) and Path(x).name not in remove]
 fresh=[O/(x+'.obj')for x in ['tests','padded-tests','codec','native-provider','torch','leased','batch','node']]
 fresh+=[R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-graph/cpu-test.obj']
 cmd=[str(R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pending-graph/arena.obj') if str(x).endswith('row-cache-pages\\paged_arena.obj') else x for x in cmd]

 run('link',[cmd[0],*fresh,*cmd[1:],'/OUT:'+str(O/'tests.exe'),'/MAP:'+str(O/'tests.map')])
elif action=='test':run('canonical-test',[O/'tests.exe','--gtest_color=no'])
else:raise SystemExit(action)
