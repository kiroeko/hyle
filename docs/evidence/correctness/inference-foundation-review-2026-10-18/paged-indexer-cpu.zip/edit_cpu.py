from pathlib import Path
p=Path('src/compute_batch/row_cache_map.h');s=p.read_text().replace('in.size()!=3 || out.size()!=2 || score_columns>','in.size()!=3 || out.size()!=2 || (in[0].valid() && in[0].rank()==2 && in[0].dimensions()[0] && !in[0].dimensions()[1]) || score_columns>');p.write_text(s,newline='\n')
p=Path('src/compute_batch/row_cache_table.h');p.write_text('''#pragma once
#include "row_cache_map.h"
#include <cstring>
namespace hyle::compute::detail {
// Checked read-only access to the same owned metadata ABI used by RowCacheMap.
// No page permission is created here; the Graph adapter retains exact leases.
struct RowCacheTable final {
  RowCacheMap mapping{};const std::byte* bytes=nullptr;std::uint32_t requests=0,refs=0;
  static std::int32_t i32(const std::byte*p)noexcept{std::int32_t v;std::memcpy(&v,p,4);return v;}
  std::int32_t query(std::size_t i)const noexcept{return i32(bytes+mapping.query_offset+i*4);}
  std::int32_t kv(std::size_t i)const noexcept{return i32(bytes+mapping.kv_offset+i*4);}
  std::int32_t tail(std::size_t i)const noexcept{return i32(bytes+mapping.tail_offset+i*4);}
  std::uint64_t length(std::size_t r)const noexcept{
    return kv(r+1)==kv(r)?0:std::uint64_t(kv(r+1)-kv(r)-1)*mapping.page_size+std::uint32_t(tail(r));
  }
  std::size_t request(std::size_t row)const noexcept{
    std::size_t lo=0,hi=requests;while(lo<hi){const auto mid=lo+(hi-lo)/2;if(query(mid+1)<=std::int64_t(row))lo=mid+1;else hi=mid;}return lo;
  }
  std::int32_t physical(std::size_t r,std::uint64_t id)const noexcept{
    const auto page=i32(bytes+mapping.page_offset+(std::size_t(kv(r))+std::size_t(id/mapping.page_size))*4);
    return std::int32_t(std::uint64_t(std::uint32_t(page))*mapping.page_size+id%mapping.page_size);
  }
  static Result<RowCacheTable> create(RowCacheMap m,const std::byte*data,std::size_t rows)noexcept{
    RowCacheTable t{m,data,std::uint32_t(i32(data+16)),std::uint32_t(i32(data+28))};
    if(t.requests>m.max_requests() || t.refs>m.max_refs() || std::uint32_t(i32(data+20))!=rows ||
       t.query(0)!=0 || t.query(t.requests)!=std::int64_t(rows) || t.kv(0)!=0 || t.kv(t.requests)!=std::int64_t(t.refs))
      return std::unexpected(Status::OutOfRange("row cache metadata counts differ"));
    for(std::size_t r=0;r<t.requests;++r){
      const auto a=t.kv(r),b=t.kv(r+1),tail=t.tail(r);
      if(t.query(r)<0 || t.query(r+1)<t.query(r) || a<0 || b<a || std::uint32_t(b)>t.refs ||
         (a==b?tail!=0:(tail<=0 || std::uint32_t(tail)>m.page_size)))
        return std::unexpected(Status::OutOfRange("row cache metadata request span differs"));
    }
    for(std::size_t p=0;p<t.refs;++p){const auto id=i32(data+m.page_offset+p*4);
      if(id<0 || std::uint32_t(id)>=m.max_pages)return std::unexpected(Status::OutOfRange("row cache metadata page differs"));}
    return t;
  }
};
}
''',newline='\n')
p=Path('src/compute_provider_native/row_cache.cc');s=p.read_text().replace('#include "../compute_batch/row_cache_map.h"','#include "../compute_batch/row_cache_map.h"\n#include "../compute_batch/row_cache_table.h"')
s=s.replace('template <bool Four>\ndetail::EnqueueResult submit_gather','template <bool Four, bool Padded = false>\ndetail::EnqueueResult submit_gather')
s=s.replace('if (index < 0 || static_cast<std::uint64_t>(index) >= rows) {','if ((Padded && index == -1)) continue;\n      if (index < 0 || static_cast<std::uint64_t>(index) >= rows) {',1)
s=s.replace('  auto source = read_mapping(inputs[0].storage());\n  if (!source) { ids->close().IgnoreError(); return completed(std::move(source).error()); }','''  bool needs_bank = !Padded;
  if constexpr (Padded) for (std::size_t i=0;i<count && !needs_bank;++i)
    needs_bank=index_value(indices,i)>=0;
  Result<mem::HostMapping> source = mem::HostMapping{};
  if(needs_bank)source=read_mapping(inputs[0].storage());
  if (!source) { ids->close().IgnoreError(); return completed(std::move(source).error()); }''',1)
s=s.replace('''  for (std::size_t i = 0; i < count; ++i)
    decode_row<Four>(source->bytes().data() + static_cast<std::size_t>(index_value(indices, i)) * width,
                    writable->data() + i * plan.row_output_stride * 2);''','''  for (std::size_t i = 0; i < count; ++i) {
    const auto id=index_value(indices,i);auto*row=writable->data()+i*plan.row_output_stride*2;
    if constexpr(Padded){if(id==-1){std::memset(row,0,plan.row_output_stride*2);continue;}}
    decode_row<Four>(source->bytes().data()+static_cast<std::size_t>(id)*width,row);
  }''')
at=s.index('} // namespace\n\nvoid decode_row_cache_float4')
s=s[:at]+'''detail::EnqueueResult submit_padded_page_map(const NativePlan&plan,
    std::span<const ConstTensorView> in,std::span<const TensorView> out)noexcept{
  const auto execute=[&]()noexcept->Status{
    const auto rows=plan.parameters[0],selected=plan.parameters[1];
    if(!rows)return Status::Ok();
    HYLE_ASSIGN_OR_RETURN(auto ids,read_mapping(in[0].storage()));
    HYLE_ASSIGN_OR_RETURN(auto ranges,read_mapping(in[1].storage()));
    HYLE_ASSIGN_OR_RETURN(auto metadata,read_mapping(in[2].storage()));
    detail::RowCacheMap geometry{plan.axis,plan.row_first_stride,plan.row_second_stride,
      plan.row_output_stride,in[2].storage().size(),std::uint32_t(plan.parameters[2]),std::uint32_t(plan.scalar_bits)};
    const auto table=detail::RowCacheTable::create(geometry,metadata.bytes().data(),rows);
    bool valid=bool(table);
    if(valid)for(std::size_t q=0;q<rows;++q){const auto request=table->request(q);
      const auto b=index_value(ranges.bytes().data(),q*2),e=index_value(ranges.bytes().data(),q*2+1);
      if(request>=table->requests || b<0 || e<b || std::uint64_t(e)>table->length(request) ||
         std::uint64_t(e)>plan.alias_input0_offset){valid=false;break;}}
    HYLE_ASSIGN_OR_RETURN(auto output,out[0].storage().map_host(mem::HostAccess::kWrite));
    HYLE_ASSIGN_OR_RETURN(auto mask,out[1].storage().map_host(mem::HostAccess::kWrite));
    HYLE_ASSIGN_OR_RETURN(auto target,output.writable_bytes());HYLE_ASSIGN_OR_RETURN(auto masks,mask.writable_bytes());
    for(std::size_t q=0;q<rows;++q)for(std::size_t k=0;k<selected;++k){
      const auto id=index_value(ids.bytes().data(),q*selected+k);std::int32_t physical=-2;float bias=-std::numeric_limits<float>::infinity();
      if(valid && id>=-1 && (id==-1 || std::uint64_t(id)<plan.alias_input0_offset)){
        physical=-1;
        if(id>=index_value(ranges.bytes().data(),q*2) && id<index_value(ranges.bytes().data(),q*2+1)){
          physical=table->physical(table->request(q),std::uint32_t(id));bias=0;}
      }
      std::memcpy(target.data()+(q*selected+k)*4,&physical,4);std::memcpy(masks.data()+(q*selected+k)*4,&bias,4);
    }
    auto status=finish_output(output,out[0].storage());preserve_first_error(status,finish_output(mask,out[1].storage()));
    preserve_first_error(status,metadata.close());preserve_first_error(status,ranges.close());preserve_first_error(status,ids.close());return status;
  };return completed(execute());
}
'''+s[at:]
at=s.index('  if (outputs.size() != 1) return Status::InvalidArgument("row cache output count differs");')
s=s[:at]+'''  if(const auto map=operation.custom_as<detail::RowCachePaddedMap>()){
    std::array<TensorDesc,2> inferred;HYLE_RETURN_IF_ERROR(map->infer_output_descriptions(inputs,inferred));
    if(outputs.size()!=2 || outputs[0]!=inferred[0] || outputs[1]!=inferred[1])return Status::InvalidArgument("padded map outputs differ");
    const auto&m=map->mapping;plan.parameters={std::size_t(inputs[0].dimensions()[0]),std::size_t(inputs[0].dimensions()[1]),m.page_size};
    plan.axis=std::size_t(m.query_offset);plan.row_first_stride=std::size_t(m.kv_offset);
    plan.row_second_stride=std::size_t(m.page_offset);plan.row_output_stride=std::size_t(m.tail_offset);
    plan.scalar_bits=m.max_pages;plan.alias_input0_offset=map->score_columns;
    plan.submit_route=&submit_padded_page_map;return Status::Ok();
  }
'''+s[at:]
at=s.index('  if (const auto gather = operation.custom_as<model_ops::RowCacheGatherDecode>())')
s=s[:at]+'''  if(const auto gather=operation.custom_as<model_ops::RowCacheGatherDecodePadded>()){
    HYLE_RETURN_IF_ERROR(gather->infer_output_descriptions(inputs,inferred));
    if(outputs[0]!=inferred[0])return Status::InvalidArgument("padded row gather output differs");
    HYLE_ASSIGN_OR_RETURN(auto count,inputs[1].element_count());
    plan.parameters={count,std::size_t(inputs[0].dimensions()[0]),gather->encoding.row_bytes()};
    plan.row_output_stride=gather->encoding.depth();plan.index_bounds=IndexBoundsPolicy::kChecked;
    plan.submit_route=gather->encoding.format()==RowCacheFormat::kFloat4Block32?&submit_gather<true,true>:&submit_gather<false,true>;
    return Status::Ok();
  }
'''+s[at:];p.write_text(s,newline='\n')
p=Path('src/compute_provider_native/native_provider.cc');s=p.read_text().replace('operation.custom_as<model_ops::RowCacheGatherDecode>() ||','operation.custom_as<model_ops::RowCacheGatherDecode>() ||\n                          operation.custom_as<model_ops::RowCacheGatherDecodePadded>() ||\n                          operation.custom_as<detail::RowCachePaddedMap>() ||');p.write_text(s,newline='\n')
