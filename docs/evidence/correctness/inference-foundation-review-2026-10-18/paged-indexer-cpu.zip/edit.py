from pathlib import Path
root=Path.cwd()
stage=root/'.scratch/inference-foundation-review-2026-10-18/paged-indexer'
for p in ['include/hyle/compute/model_ops.h','src/compute_batch/row_cache_map.h','src/compute_provider_native/row_cache.cc','src/compute_provider_native/torch_cpu_program.cc','src/graph_batch/row_cache_node.cc','src/graph_batch/row_cache_node.h','src/graph_batch/batch.cc','src/graph/leased_invocation.cc','include/hyle/graph/batch.h']:
 t=stage/'before'/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes((root/p).read_bytes())
p=root/'include/hyle/compute/model_ops.h'
s=p.read_text();at=s.index('// DeepSeek indexer scoring over')
s=s[:at]+'''// Checked padding-aware decode. Only -1 is padding: it produces a BF16
// positive-zero row without accessing the bank. Other invalid IDs fail before
// any output write. A zero-row bank is valid when all runtime IDs are -1.
// Use the corresponding additive mask when padding participates in attention.
struct RowCacheGatherDecodePadded final {
  RowCacheEncoding encoding{};
  static constexpr OperationId operation_id{0x48594c454d4f444cULL,0x524f574744500001ULL};
  static constexpr std::string_view operation_name="row-cache-gather-decode-padded";
  constexpr OperationTraits operation_traits()const noexcept{
    return {{2,2},1,AliasPolicy::kNone,EffectKind::kPure,PrecisionPolicy::kExact};
  }
  Status infer_output_descriptions(std::span<const TensorDesc> in,std::span<TensorDesc> out)const noexcept{
    if(in.size()!=2 || out.size()!=1 || !encoding.depth() ||
       !in[0].valid() || !in[1].valid() || !in[0].is_plain() || !in[1].is_plain() ||
       !in[0].is_dense() || !in[1].is_dense() || in[0].rank()!=2 ||
       in[0].data_type()!=DataType::kUInt8 || in[0].dimensions()[1]!=encoding.row_bytes() ||
       in[1].data_type()!=DataType::kInt32 || in[1].rank()>=kMaxTensorRank)
      return Status::InvalidArgument("padded row decode requires matching byte rows and dense I32 IDs");
    std::array<std::int64_t,kMaxTensorRank> shape{};
    for(std::size_t i=0;i<in[1].rank();++i)shape[i]=in[1].dimensions()[i];
    shape[in[1].rank()]=encoding.depth();
    HYLE_ASSIGN_OR_RETURN(out[0],TensorDesc::dense(DataType::kBFloat16,std::span(shape).first(in[1].rank()+1)));
    return Status::Ok();
  }
};
static_assert(detail::InlineCustomOperationDescriptor<RowCacheGatherDecodePadded>);
inline Operation row_cache_gather_decode_padded(RowCacheEncoding encoding)noexcept{
  return Operation::custom(RowCacheGatherDecodePadded{encoding});
}

'''+s[at:];p.write_text(s,newline='\n')
p=root/'src/compute_batch/row_cache_map.h';s=p.read_text();at=s.index('} // namespace hyle::compute::detail')
s=s[:at]+'''// A separate producer chain for padded TopK. A valid score column outside
// its query range is padding; malformed columns/ranges/metadata become -2,
// which the checked padded decoder must reject. Result1 is 0/-Inf additive
// attention mask, so zero-filled decoded padding cannot affect normalization.
struct RowCachePaddedMap final {
  RowCacheMap mapping{};
  std::uint32_t score_columns=0;
  static constexpr OperationId operation_id{0x48594c45524f5743ULL,0x5041474550410001ULL};
  static constexpr std::string_view operation_name="private-row-cache-padded-map";
  constexpr OperationTraits operation_traits()const noexcept{
    return {{3,3},2,AliasPolicy::kNone,EffectKind::kPure,PrecisionPolicy::kExact};
  }
  Status infer_output_descriptions(std::span<const TensorDesc> in,std::span<TensorDesc> out)const noexcept{
    if(in.size()!=3 || out.size()!=2 || score_columns>std::uint32_t(INT32_MAX))
      return Status::InvalidArgument("padded row map input/output count or columns differ");
    std::array<TensorDesc,1> inferred;
    HYLE_RETURN_IF_ERROR(mapping.infer_output_descriptions(std::array{in[0],in[2]},inferred));
    if(!in[1].valid() || !in[1].is_plain() || !in[1].is_dense() || in[1].data_type()!=DataType::kInt32 ||
       in[1].rank()!=2 || in[1].dimensions()[0]!=in[0].dimensions()[0] || in[1].dimensions()[1]!=2)
      return Status::InvalidArgument("padded row map needs one half-open range per query");
    out[0]=inferred[0];
    HYLE_ASSIGN_OR_RETURN(out[1],TensorDesc::dense(DataType::kFloat32,in[0].dimensions()));
    return Status::Ok();
  }
};
static_assert(InlineCustomOperationDescriptor<RowCachePaddedMap>);

// Typed-only five-port scorer. Columns are request-local logical row IDs;
// owned query/page metadata selects each query's request. The raw capacity is
// never an ordinary public bank input and requires exact page read guards.
struct RowCachePagedIndexerScores final {
  RowCacheMap mapping{};
  std::uint32_t score_columns=0;
  static constexpr OperationId operation_id{0x48594c45524f5743ULL,0x5041474549440001ULL};
  static constexpr std::string_view operation_name="private-row-cache-paged-indexer-scores";
  constexpr OperationTraits operation_traits()const noexcept{
    return {{5,5},1,AliasPolicy::kNone,EffectKind::kPure,PrecisionPolicy::kAccumulateInDeclaredType,DataType::kFloat32,true};
  }
  Status infer_output_descriptions(std::span<const TensorDesc> in,std::span<TensorDesc> out)const noexcept{
    if(in.size()!=5 || out.size()!=1 || score_columns>std::uint32_t(INT32_MAX))
      return Status::InvalidArgument("paged row indexer input/output count or columns differ");
    std::array<TensorDesc,1> inferred;
    HYLE_RETURN_IF_ERROR(model_ops::RowCacheIndexerScores{}.infer_output_descriptions(in.first(4),inferred));
    HYLE_RETURN_IF_ERROR(mapping.infer_output_descriptions(std::array{in[3],in[4]},inferred));
    HYLE_ASSIGN_OR_RETURN(out[0],TensorDesc::dense(DataType::kFloat32,std::array{in[0].dimensions()[0],std::int64_t(score_columns)}));
    return Status::Ok();
  }
};
static_assert(InlineCustomOperationDescriptor<RowCachePagedIndexerScores>);
'''+s[at:];s=s.replace('#include "hyle/compute/operation.h"','#include "hyle/compute/model_ops.h"');p.write_text(s,newline='\n')
