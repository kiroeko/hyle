from pathlib import Path
p=Path('include/hyle/graph/batch.h');s=p.read_text();at=s.index('// As with the original Builder calls')
s=s[:at]+'''// Padding-aware macro: only -1 or a legal score column outside its query's
// request-local [begin,end) becomes padding. It returns a 0/-Inf mask along
// with selected BF16 rows. Invalid columns/ranges/metadata still fail checked
// decode. Include reader() in the same original coordinator's row macro set.
class PagedRowCacheGatherPadded final {
public:
  bool valid()const noexcept{return reader_.valid();}
  const PagedRowCacheGather& reader()const noexcept{return reader_;}
  ValueId bank_input()const noexcept{return reader_.bank_input();}
  ValueId output()const noexcept{return reader_.output();}
  ValueId mask()const noexcept{return mask_;}
  NodeId node()const noexcept{return reader_.node();}
private:
  friend struct detail::RowCacheAccess;
  friend Result<PagedRowCacheGatherPadded> add_row_cache_gather_padded(GraphBuilder&,compute::RowCacheBatchSchema,ValueId,ValueId,std::uint32_t)noexcept;
  PagedRowCacheGather reader_;ValueId mask_;
};
HYLE_GRAPH_BATCH_API Result<PagedRowCacheGatherPadded> add_row_cache_gather_padded(
    GraphBuilder&,compute::RowCacheBatchSchema,ValueId logical_ids,ValueId ranges,std::uint32_t score_columns)noexcept;
// Bounded-tile FP4 row-inline scoring over exact typed page permissions.
// Five original ordinary-node ports are Q/physical bank/weights/ranges/owned
// metadata. Q/weights and rounding match RowCacheIndexerScores. Output [T,C]
// columns and ranges are request-local logical rows; C is a static score width
// covering each active request history, not a tile option or physical capacity.
class PagedRowCacheIndexer final {
public:
  bool valid()const noexcept{return reader_.valid();}
  ValueId bank_input()const noexcept{return reader_.bank_input();}
  ValueId output()const noexcept{return reader_.output();}
  NodeId node()const noexcept{return reader_.node();}
  compute::RowCacheBatchSchema schema()const noexcept{return reader_.schema();}
private:
  friend struct detail::RowCacheAccess;
  friend Result<PagedRowCacheIndexer> add_row_cache_indexer(GraphBuilder&,compute::RowCacheBatchSchema,ValueId,ValueId,ValueId,std::uint32_t)noexcept;
  PagedRowCacheGather reader_;
};
HYLE_GRAPH_BATCH_API Result<PagedRowCacheIndexer> add_row_cache_indexer(
    GraphBuilder&,compute::RowCacheBatchSchema,ValueId query,ValueId weights,ValueId ranges,std::uint32_t score_columns)noexcept;
'''+s[at:]
at=s.index('  bool valid() const noexcept{return data_!=nullptr;}',s.index('class Invocation final'))
s=s[:at]+'''  HYLE_GRAPH_BATCH_API static Result<Invocation> create(const Graph&,const Executable&,
      std::span<const LaneBinding>,std::span<const PagedRowCacheGather>,std::span<const PagedRowCacheIndexer>,
      LeasedInvocationOptions = {},ReplayOptions = {})noexcept;
'''+s[at:];p.write_text(s,newline='\n')
p=Path('src/graph_batch/row_cache_node.h');s=p.read_text().replace('  static Status validate','''  static PagedRowCacheGather make(compute::RowCacheBatchSchema schema,NodeId map,NodeId decode,
      ValueId bank,ValueId metadata,ValueId ids,ValueId mapped,ValueId output)noexcept{
    PagedRowCacheGather r;r.schema_=std::move(schema);r.map_=map;r.decode_=decode;
    r.bank_=bank;r.metadata_=metadata;r.ids_=ids;r.mapped_=mapped;r.output_=output;return r;
  }
  static const PagedRowCacheGather& reader(const PagedRowCacheIndexer&v)noexcept{return v.reader_;}
  static bool empty_safe(const Graph&,const PagedRowCacheGather&)noexcept;
  static Status validate''');p.write_text(s,newline='\n')
p=Path('src/graph_batch/row_cache_node.cc');s=p.read_text();at=s.index('Status detail::RowCacheAccess::validate')
s=s[:at]+'''Result<PagedRowCacheGatherPadded> add_row_cache_gather_padded(GraphBuilder&builder,c::RowCacheBatchSchema schema,
    ValueId ids,ValueId ranges,std::uint32_t columns)noexcept{
  if(!schema.valid())return std::unexpected(Status::InvalidArgument("padded row schema is empty"));
  const auto cap=schema.capacity();const auto rows=std::uint64_t(cap.max_pages)*cap.page_size;
  if(rows>std::uint64_t(INT32_MAX)+1)return std::unexpected(Status::OutOfRange("padded row physical I32 capacity"));
  HYLE_ASSIGN_OR_RETURN(auto bankdesc,c::row_cache_carrier_description(cap.encoding,std::int64_t(rows)));
  HYLE_ASSIGN_OR_RETURN(auto bank,builder.input(bankdesc));
  HYLE_ASSIGN_OR_RETURN(auto metadesc,c::TensorDesc::dense(c::DataType::kUInt8,std::array{std::int64_t(schema.metadata_offsets().bytes)}));
  HYLE_ASSIGN_OR_RETURN(auto meta,builder.input(metadesc));
  auto reader=detail::RowCacheAccess::make(schema,{},{},bank,meta,ids,{},{});
  HYLE_ASSIGN_OR_RETURN(auto map,builder.add_node(c::Operation::custom(c::detail::RowCachePaddedMap{detail::RowCacheAccess::operation(reader),columns}),std::array{ids,ranges,meta}));
  HYLE_ASSIGN_OR_RETURN(auto mapped,builder.result(map,0));HYLE_ASSIGN_OR_RETURN(auto mask,builder.result(map,1));
  HYLE_ASSIGN_OR_RETURN(auto decoder,builder.add_node(c::model_ops::row_cache_gather_decode_padded(cap.encoding),std::array{bank,mapped}));
  HYLE_ASSIGN_OR_RETURN(auto out,builder.result(decoder));
  PagedRowCacheGatherPadded result;result.reader_=detail::RowCacheAccess::make(std::move(schema),map,decoder,bank,meta,ids,mapped,out);result.mask_=mask;return result;
}
Result<PagedRowCacheIndexer> add_row_cache_indexer(GraphBuilder&builder,c::RowCacheBatchSchema schema,
    ValueId query,ValueId weights,ValueId ranges,std::uint32_t columns)noexcept{
  if(!schema.valid() || schema.capacity().encoding!=c::RowCacheEncoding::float4_block32())
    return std::unexpected(Status::InvalidArgument("paged indexer requires its FP4 row schema"));
  const auto cap=schema.capacity();const auto rows=std::uint64_t(cap.max_pages)*cap.page_size;
  if(rows>std::uint64_t(INT32_MAX)+1)return std::unexpected(Status::OutOfRange("paged indexer physical I32 capacity"));
  HYLE_ASSIGN_OR_RETURN(auto bankdesc,c::row_cache_carrier_description(cap.encoding,std::int64_t(rows)));
  HYLE_ASSIGN_OR_RETURN(auto bank,builder.input(bankdesc));
  HYLE_ASSIGN_OR_RETURN(auto metadesc,c::TensorDesc::dense(c::DataType::kUInt8,std::array{std::int64_t(schema.metadata_offsets().bytes)}));
  HYLE_ASSIGN_OR_RETURN(auto meta,builder.input(metadesc));
  auto reader=detail::RowCacheAccess::make(schema,{},{},bank,meta,query,{},{});
  HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(c::Operation::custom(c::detail::RowCachePagedIndexerScores{detail::RowCacheAccess::operation(reader),columns}),std::array{query,bank,weights,ranges,meta}));
  HYLE_ASSIGN_OR_RETURN(auto out,builder.result(node));
  PagedRowCacheIndexer result;result.reader_=detail::RowCacheAccess::make(std::move(schema),node,node,bank,meta,query,{},out);return result;
}
namespace {
bool same_geometry(const c::detail::RowCacheMap&a,const c::detail::RowCacheMap&b)noexcept{
  return a.query_offset==b.query_offset && a.kv_offset==b.kv_offset && a.page_offset==b.page_offset &&
    a.tail_offset==b.tail_offset && a.metadata_bytes==b.metadata_bytes && a.page_size==b.page_size && a.max_pages==b.max_pages;
}
}
bool detail::RowCacheAccess::empty_safe(const Graph&graph,const PagedRowCacheGather&r)noexcept{
  const auto op=graph.operation(r.decode_);return op && (op->custom_as<c::model_ops::RowCacheGatherDecodePadded>() || op->custom_as<c::detail::RowCachePagedIndexerScores>());
}
Status detail::RowCacheAccess::validate(const Graph&graph,const PagedRowCacheGather&r)noexcept{
  if(!graph.valid() || !r.valid())return Status::InvalidArgument("row Graph macro is empty");
  HYLE_ASSIGN_OR_RETURN(auto map,graph.operation(r.map_));HYLE_ASSIGN_OR_RETURN(auto decode,graph.operation(r.decode_));
  const auto ordinary=map.custom_as<c::detail::RowCacheMap>();
  const auto padded=map.custom_as<c::detail::RowCachePaddedMap>();
  const auto scorer=map.custom_as<c::detail::RowCachePagedIndexerScores>();
  const auto codec=decode.custom_as<c::model_ops::RowCacheGatherDecode>();
  const auto padded_codec=decode.custom_as<c::model_ops::RowCacheGatherDecodePadded>();
  const auto expected=operation(r);const c::detail::RowCacheMap*actual=nullptr;
  std::size_t metadata_port=1,bank_port=0,map_inputs=2,map_outputs=1,decode_inputs=2;
  if(scorer){actual=&scorer->mapping;metadata_port=4;bank_port=1;map_inputs=decode_inputs=5;
    if(r.map_!=r.decode_ || r.mapped_.valid() || r.schema_.capacity().encoding!=c::RowCacheEncoding::float4_block32())
      return Status::InvalidArgument("paged indexer macro role differs");
  }else if(padded){actual=&padded->mapping;metadata_port=2;map_inputs=3;map_outputs=2;
    if(!padded_codec || padded_codec->encoding!=r.schema_.capacity().encoding)return Status::InvalidArgument("padded row macro codec differs");
  }else if(ordinary){actual=ordinary;
    if(!codec || codec->encoding!=r.schema_.capacity().encoding || codec->bounds!=c::IndexBoundsPolicy::kChecked)
      return Status::InvalidArgument("row macro checked codec differs");
  }
  if(!actual || !same_geometry(*actual,expected))return Status::InvalidArgument("row Graph geometry differs from its owned schema");
  HYLE_ASSIGN_OR_RETURN(auto ni,graph.node_input_count(r.map_));HYLE_ASSIGN_OR_RETURN(auto no,graph.node_output_count(r.map_));
  HYLE_ASSIGN_OR_RETURN(auto di,graph.node_input_count(r.decode_));HYLE_ASSIGN_OR_RETURN(auto dout,graph.node_output_count(r.decode_));
  HYLE_ASSIGN_OR_RETURN(auto a,graph.node_input(r.map_,0));HYLE_ASSIGN_OR_RETURN(auto b,graph.node_input(r.map_,metadata_port));
  HYLE_ASSIGN_OR_RETURN(auto d,graph.node_input(r.decode_,bank_port));HYLE_ASSIGN_OR_RETURN(auto o,graph.result(r.decode_));
  HYLE_ASSIGN_OR_RETURN(auto id_desc,graph.value_description(a));
  if(ni!=map_inputs || no!=map_outputs || di!=decode_inputs || dout!=1 || a!=r.ids_ || b!=r.metadata_ || d!=r.bank_ || o!=r.output_ ||
      r.bank_.kind()!=ValueKind::kInput || r.metadata_.kind()!=ValueKind::kInput ||
      std::uint64_t(id_desc.dimensions()[0])>r.schema_.capacity().max_query_rows)
    return Status::InvalidArgument("row Graph macro ports/selection rows differ");
  if(!scorer){HYLE_ASSIGN_OR_RETURN(auto e,graph.node_input(r.decode_,1));HYLE_ASSIGN_OR_RETURN(auto m,graph.result(r.map_,0));
    if(e!=r.mapped_ || m!=r.mapped_)return Status::InvalidArgument("row Graph mapped producer port differs");}
  HYLE_ASSIGN_OR_RETURN(auto bank_desc,graph.value_description(r.bank_));
  HYLE_ASSIGN_OR_RETURN(auto required,c::row_cache_carrier_description(r.schema_.capacity().encoding,
    std::int64_t(std::uint64_t(r.schema_.capacity().max_pages)*r.schema_.capacity().page_size)));
  if(bank_desc!=required)return Status::InvalidArgument("row Graph physical capacity differs");
  for(std::size_t i=0;i<graph.output_count();++i){HYLE_ASSIGN_OR_RETURN(auto v,graph.output_id(i));
    if(v==r.bank_ || v==r.metadata_ || (r.mapped_.valid() && v==r.mapped_))return Status::InvalidArgument("row Graph private capacity/metadata/map cannot be published");}
  for(std::size_t i=0;i<graph.node_count();++i){HYLE_ASSIGN_OR_RETURN(auto node,graph.node_id(i));HYLE_ASSIGN_OR_RETURN(auto count,graph.node_input_count(node));
    for(std::size_t port=0;port<count;++port){HYLE_ASSIGN_OR_RETURN(auto v,graph.node_input(node,port));
      if((v==r.bank_ && (node!=r.decode_ || port!=bank_port)) || (v==r.metadata_ && (node!=r.map_ || port!=metadata_port)) ||
          (r.mapped_.valid() && v==r.mapped_ && (node!=r.decode_ || port!=1)))return Status::InvalidArgument("row Graph private input has an extra reader");}}
  return Status::Ok();
}
}
''';p.write_text(s,newline='\n')
