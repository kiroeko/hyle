from pathlib import Path
p=Path('tests/compute_route_cpu/row_cache_padded_test.cc');p.write_text(r'''#include <gtest/gtest.h>
#include "../compute_models/row_cache_fixture.h"
#include "../compute_provider_native/half_test_support.h"
#include "hyle/compute/cpu.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
namespace {
namespace c=hyle::compute;namespace m=hyle::mem;
TEST(CpuRowCachePadded, OnlyMinusOnePadsAndInvalidIdsNeverPublish){
  auto context=c::cpu::create_context().value();auto queue=context.create_queue().value();
  for(auto encoding:{c::RowCacheEncoding::float4_block32(),c::RowCacheEncoding::float8_block64_tail64()}){
    SCOPED_TRACE(encoding.depth());const auto bank_desc=c::row_cache_carrier_description(encoding,5).value();
    const auto ids_desc=c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,2>{2,3}).value();
    const auto operation=c::model_ops::row_cache_gather_decode_padded(encoding);
    const auto output_desc=c::infer_single_output(operation,std::array{bank_desc,ids_desc}).value();
    auto prepared=c::prepare(context,operation,std::array{bank_desc,ids_desc},std::array{output_desc},m::system_resource()).value();
    std::array outputs{half_test::buffer<std::uint16_t>(std::vector<std::uint16_t>(6*encoding.depth())),half_test::buffer<std::uint16_t>(std::vector<std::uint16_t>(6*encoding.depth()))};
    std::vector<std::uint16_t> old;
    for(int phase:{0,1}){const auto source=row_cache_test::reference(encoding,row_cache_test::input_values(encoding,phase));
      auto bank=half_test::buffer<std::uint8_t>(source.bytes);auto ids=half_test::buffer<std::int32_t>(std::array<std::int32_t,6>{-1,4,0,2,-1,1});
      const std::array input{c::ConstTensorView::create(bank_desc,bank.view()).value(),c::ConstTensorView::create(ids_desc,ids.view()).value()};
      auto slot=prepared.create_invocation().value();auto done=slot.submit(queue,input,std::array{c::TensorView::create(output_desc,outputs[phase].view()).value()});
      ASSERT_TRUE(done);ASSERT_TRUE(done->wait().ok());const auto actual=half_test::read<std::uint16_t>(outputs[phase]);
      const std::array<std::int32_t,6> selected{-1,4,0,2,-1,1};for(std::size_t row=0;row<6;++row)for(std::size_t d=0;d<encoding.depth();++d)
        EXPECT_EQ(actual[row*encoding.depth()+d],selected[row]<0?std::uint16_t{0}:source.decoded[std::size_t(selected[row])*encoding.depth()+d]);
      if(!phase)old=actual;else EXPECT_EQ(half_test::read<std::uint16_t>(outputs[0]),old);
      for(std::int32_t invalid:{-2,5}){auto bad=half_test::buffer<std::int32_t>(std::array<std::int32_t,6>{-1,4,0,2,-1,invalid});
        const std::vector<std::uint16_t> sentinel(6*encoding.depth(),0x5a5a);auto output=half_test::buffer<std::uint16_t>(sentinel);
        auto failed=prepared.create_invocation().value();auto completion=failed.submit(queue,std::array{input[0],c::ConstTensorView::create(ids_desc,bad.view()).value()},std::array{c::TensorView::create(output_desc,output.view()).value()});
        ASSERT_TRUE(completion);EXPECT_TRUE(completion->wait().IsOutOfRange());EXPECT_EQ(half_test::read<std::uint16_t>(output),sentinel);}
    }
    // Empty physical bank, nonempty padded IDs: the decoder may not map/read
    // a source row or form a bank pointer for these positive-zero outputs.
    const auto empty_desc=c::row_cache_carrier_description(encoding,0).value();auto empty_bank=half_test::buffer<std::uint8_t>(std::vector<std::uint8_t>{});
    auto ids=half_test::buffer<std::int32_t>(std::vector<std::int32_t>(6,-1));
    auto padded=c::prepare(context,operation,std::array{empty_desc,ids_desc},std::array{output_desc},m::system_resource()).value();
    auto invocation=padded.create_invocation().value();auto done=invocation.submit(queue,std::array{c::ConstTensorView::create(empty_desc,empty_bank.view()).value(),c::ConstTensorView::create(ids_desc,ids.view()).value()},std::array{c::TensorView::create(output_desc,outputs[1].view()).value()});
    ASSERT_TRUE(done);EXPECT_TRUE(done->wait().ok());EXPECT_EQ(half_test::read<std::uint16_t>(outputs[1]),std::vector<std::uint16_t>(6*encoding.depth(),0));
    EXPECT_FALSE(c::infer_single_output(c::model_ops::row_cache_gather_decode(encoding),std::array{empty_desc,ids_desc}));
  }
}
}
''',newline='\n')
p=Path('tests/compute_route_cpu/CMakeLists.txt');s=p.read_text().replace('  row_cache_test.cc\n','  row_cache_test.cc\n  row_cache_padded_test.cc\n');p.write_text(s,newline='\n')
p=Path('tests/compute_models/row_cache_paged_indexer_fixture.h');s=p.read_text();at=s.index('} // namespace row_cache_paged_indexer_test')
s=s[:at]+r'''
template<class Compile>void rejected_private_readers(c::Context&context,Compile compile){
  const auto schema=c::RowCacheBatchSchema::create(capacity(c::RowCacheEncoding::float4_block32())).value();
  auto queue=context.create_queue().value();const std::array lanes{gb::LaneBinding{.lane=g::ExecutionLaneId{0},.context=&context,.queue=&queue}};
  for(bool alias:{false,true}){auto b=g::GraphBuilder::create().value();
    const auto q=b.input(dense(c::DataType::kBFloat16,{3,64,128})).value(),w=b.input(dense(c::DataType::kBFloat16,{3,64})).value(),r=b.input(dense(c::DataType::kInt32,{3,2})).value();
    const auto scorer=gb::add_row_cache_indexer(b,schema,q,w,r,4).value();ASSERT_TRUE(b.publish(scorer.output()).ok());
    auto leaked=scorer.bank_input();if(alias)leaked=b.add(c::View::reshape(c::TensorShape::create(std::array<std::int64_t,2>{8,68}).value()).value(),leaked).value();
    ASSERT_TRUE(b.publish(leaked).ok());const auto graph=std::move(b).finish().value();auto compiled=f::take(compile(graph),"private-capacity negative compile");
    const auto denied=gb::Invocation::create(graph,compiled.executable,lanes,std::span<const gb::PagedRowCacheGather>{},std::array{scorer});ASSERT_FALSE(denied);EXPECT_TRUE(denied.error().IsInvalidArgument());
  }
}
template<class Compile>void invalid_padded(c::Context&context,m::MemoryResourceRef resource,Compile compile){
  const auto encoding=c::RowCacheEncoding::float8_block64_tail64();const auto schema=c::RowCacheBatchSchema::create(capacity(encoding)).value();
  for(int failure:{0,1,2,3}){SCOPED_TRACE(failure);auto builder=g::GraphBuilder::create().value();const auto id_desc=dense(c::DataType::kInt32,{3,3}),range_desc=dense(c::DataType::kInt32,{3,2});
    const auto ids=builder.input(id_desc).value(),ranges=builder.input(range_desc).value();const auto macro=gb::add_row_cache_gather_padded(builder,schema,ids,ranges,4).value();
    ASSERT_TRUE(builder.publish(macro.output()).ok());ASSERT_TRUE(builder.publish(macro.mask()).ok());const auto graph=std::move(builder).finish().value();auto compiled=f::take(compile(graph),"invalid padded compile");
    auto queue=context.create_queue().value();const std::array lanes{gb::LaneBinding{.lane=g::ExecutionLaneId{0},.context=&context,.queue=&queue}};
    auto slot=gb::Invocation::create(graph,compiled.executable,lanes,std::array{macro.reader()}).value();
    auto arena=c::PagedArena::create(schema,resource,{.max_backing_bytes=8*584+1}).value();
    // No bank contents need reading: all other IDs are padding. The true
    // page frame still carries exactly the visible layout's required pages.
    std::vector<std::uint8_t> bank(8*584);auto pages=upload(arena,bank,584);auto version=layout(schema,false);
    ASSERT_TRUE(slot.prepare_row_cache(std::array{gb::RowCacheNodeLayout{macro.node(),version}}).ok());ASSERT_TRUE(slot.bind(macro.bank_input(),frame(arena,version,pages,false)).ok());
    auto pool=c::LeasePool::create(resource,32768).value();std::vector<std::int32_t> selected(9,-1),r{0,0,0,1,0,1};
    if(failure<2)selected.back()=failure?-2:4;else{r[4]=failure==2?-1:0;r[5]=failure==2?1:2;}
    ASSERT_TRUE(slot.bind(ids,id_desc,f::load(pool,std::as_bytes(std::span(selected)))).ok());ASSERT_TRUE(slot.bind(ranges,range_desc,f::load(pool,std::as_bytes(std::span(r)))).ok());
    const auto desc=graph.value_description(macro.output()).value();auto writer=pool.allocate(*desc.required_bytes()).value();const auto raw=writer.view().value();const std::vector<std::uint16_t> sentinel(9*512,0x5a5a);
    ASSERT_TRUE(raw.write(std::as_bytes(std::span(sentinel))).ok());ASSERT_TRUE(slot.bind(macro.output(),desc,std::move(writer)).ok());
    const auto md=graph.value_description(macro.mask()).value();auto mw=pool.allocate(*md.required_bytes()).value();ASSERT_TRUE(slot.bind(macro.mask(),md,std::move(mw)).ok());
    auto done=slot.submit();ASSERT_TRUE(done);EXPECT_TRUE(done->wait().IsOutOfRange());EXPECT_FALSE(slot.output(macro.output()));
    std::vector<std::uint16_t> actual(sentinel.size());ASSERT_TRUE(raw.read(std::as_writable_bytes(std::span(actual))).ok());EXPECT_EQ(actual,sentinel);
    // The Map's mask is an accepted prefix write; Graph failure does not
    // promise to roll back arbitrary earlier caller buffers.
  }
}
'''+s[at:];p.write_text(s,newline='\n')
p=Path('tests/graph_batch/row_cache_indexer_graph_test.cc');s=p.read_text();s += '''
#if !defined(HYLE_ROW_CACHE_GRAPH_CUDA)
TEST(CpuPagedRowCacheIndexerGraph, InvalidPaddingAndPrivateCapacityCannotEscape){
  auto context=hyle::graph::cpu::create_context().value();
  const auto compile=[&](const hyle::graph::Graph&g){return hyle::graph::compile(g,context);};
  row_cache_paged_indexer_test::rejected_private_readers(context,compile);
  row_cache_paged_indexer_test::invalid_padded(context,hyle::mem::system_resource(),compile);
}
#endif
''';p.write_text(s,newline='\n')
