from pathlib import Path
p=Path('src/compute_provider_native/torch_cpu_program.cc');s=p.read_text().replace('#include "row_cache_codec.h"','#include "row_cache_codec.h"\n#include "../compute_batch/row_cache_table.h"')
s=s.replace('  model_ops::MlxQuantized mlx{};','  model_ops::MlxQuantized mlx{};\n  detail::RowCachePagedIndexerScores paged{};\n  bool is_paged=false;')
s=s.replace('  if (op.custom_as<model_ops::RowCacheIndexerScores>()) {','''  if(const auto paged=op.custom_as<detail::RowCachePagedIndexerScores>()){
    s.kind=Kind::kRowCacheIndexer;s.is_paged=true;s.paged=*paged;
    s.tokens=inputs[0].dimensions()[0];s.n=paged->score_columns;s.k=128;
  } else if (op.custom_as<model_ops::RowCacheIndexerScores>()) {''',1)
at=s.index('template <Kind Selected>\nStatus execute')
s=s[:at]+'''Result<at::Tensor> paged_indexer_scores(const std::array<at::Tensor,6>&input,const Shape&s){
  const auto*ranges=input[3].const_data_ptr<std::int32_t>();
  const auto*bank=input[1].const_data_ptr<std::uint8_t>();
  HYLE_ASSIGN_OR_RETURN(auto table,detail::RowCacheTable::create(s.paged.mapping,
    reinterpret_cast<const std::byte*>(input[4].const_data_ptr<std::uint8_t>()),std::size_t(s.tokens)));
  // Validate every request and query before allocating/writing the private
  // result or reading a packed row. Columns remain request-local, not slots.
  for(std::size_t r=0;r<table.requests;++r){
    if(table.length(r)>std::uint64_t(s.n))return std::unexpected(Status::OutOfRange("paged indexer history exceeds score columns"));
    for(auto q=table.query(r);q<table.query(r+1);++q)
      if(ranges[q*2]<0 || ranges[q*2+1]<ranges[q*2] || std::uint64_t(ranges[q*2+1])>table.length(r))
        return std::unexpected(Status::OutOfRange("paged indexer range is outside its request history"));
  }
  auto result=at::full({s.tokens,s.n},-std::numeric_limits<float>::infinity(),at::kFloat);
  if(!s.tokens || !s.n)return result;
  constexpr std::int64_t tile_rows=256;
  auto decoded=at::empty({(std::min)(tile_rows,s.n),128},at::kBFloat16);
  auto*decoded_bytes=reinterpret_cast<std::byte*>(decoded.data_ptr<c10::BFloat16>());
  for(std::size_t request=0;request<table.requests;++request){
    const auto qbegin=table.query(request),qend=table.query(request+1);
    std::int64_t first=s.n,last=0;
    for(auto q=qbegin;q<qend;++q)if(ranges[q*2]<ranges[q*2+1]){
      first=(std::min)(first,std::int64_t(ranges[q*2]));last=(std::max)(last,std::int64_t(ranges[q*2+1]));}
    while(first<last){const auto rows=(std::min)(tile_rows,last-first);
      for(std::int64_t row=0;row<rows;++row){const auto key=first+row;bool referenced=false;
        for(auto q=qbegin;q<qend && !referenced;++q)referenced=ranges[q*2]<=key && key<ranges[q*2+1];
        if(referenced)decode_row_cache_float4(reinterpret_cast<const std::byte*>(bank+std::size_t(table.physical(request,std::uint64_t(key)))*68),
          decoded_bytes+row*128*sizeof(c10::BFloat16));}
      for(auto q=qbegin;q<qend;++q){const auto begin=(std::max)(first,std::int64_t(ranges[q*2]));
        const auto end=(std::min)(first+rows,std::int64_t(ranges[q*2+1]));if(begin>=end)continue;
        auto dots=at::matmul(input[0].select(0,q),decoded.slice(0,begin-first,end-first).transpose(0,1));
        auto weighted=dots.relu()*input[2].select(0,q).unsqueeze(1);
        result.select(0,q).slice(0,begin,end).copy_(weighted.sum(0).to(at::kFloat));}
      const auto tile_end=first+rows;first=last;
      for(auto q=qbegin;q<qend;++q)if(ranges[q*2+1]>tile_end)
        first=(std::min)(first,(std::max)(tile_end,std::int64_t(ranges[q*2])));
    }
  }
  return result;
}

'''+s[at:]
s=s.replace('HYLE_ASSIGN_OR_RETURN(result, indexer_scores(input, s));','''if(s.is_paged){HYLE_ASSIGN_OR_RETURN(result,paged_indexer_scores(input,s));}
      else{HYLE_ASSIGN_OR_RETURN(result, indexer_scores(input, s));}''')
s=s.replace('if (operation.custom_as<model_ops::RowCacheIndexerScores>())','if (operation.custom_as<model_ops::RowCacheIndexerScores>() || operation.custom_as<detail::RowCachePagedIndexerScores>())')
p.write_text(s,newline='\n')
