from pathlib import Path
p=Path('tests/compute_models/row_cache_paged_indexer_fixture.h');p.write_text(r'''#pragma once
#include "row_cache_graph_fixture.h"
#include "row_cache_indexer_fixture.h"
namespace row_cache_paged_indexer_test {
namespace c=hyle::compute;namespace g=hyle::graph;namespace m=hyle::mem;namespace gb=g::batch;
namespace f=row_cache_paged_test;using row_cache_graph_test::dense;using row_cache_graph_test::read;
inline c::RowCacheBatchCapacity capacity(c::RowCacheEncoding e){return {.encoding=e,.max_requests=2,.max_query_rows=3,.max_kv_rows=8,.max_pages=4,.max_page_refs=4,.page_size=2};}
inline c::RowCacheLayoutVersion layout(const c::RowCacheBatchSchema&s,bool empty){
  const std::array<std::int32_t,3> q{0,2,3},kv=empty?std::array<std::int32_t,3>{0,0,0}:std::array<std::int32_t,3>{0,2,3};
  const std::array<std::int32_t,3> pages{3,1,0};const std::array<std::int32_t,2> tails=empty?std::array<std::int32_t,2>{0,0}:std::array<std::int32_t,2>{1,1};
  return s.version({q,kv,empty?std::span<const std::int32_t>{}:std::span(pages),tails}).value();
}
inline std::int32_t physical(std::size_t q,std::int32_t logical){return q<2?(logical<2?6+logical:2):logical;}
inline std::vector<c::ReadLease> upload(c::PagedArena&a,std::span<const std::uint8_t>bytes,std::size_t width){
  std::vector<c::ReadLease> pages;for(unsigned p=0;p<4;++p){auto writer=a.acquire(p).value();
    EXPECT_TRUE(writer.lease().view()->write(std::as_bytes(bytes.subspan(p*2*width,2*width))).ok());pages.push_back(writer.publish(2).value());}return pages;
}
inline c::PagedRowCacheRead frame(c::PagedArena&a,c::RowCacheLayoutVersion v,const std::vector<c::ReadLease>&p,bool empty){
  if(empty)return a.read(v,{}).value();const std::array exact{p[1],p[0],p[3]};return a.read(v,exact).value();
}
template<class Compile>void exercise(c::Context&context,m::MemoryResourceRef resource,Compile compile){
  auto scorer_schema=c::RowCacheBatchSchema::create(capacity(c::RowCacheEncoding::float4_block32())).value();
  auto value_schema=c::RowCacheBatchSchema::create(capacity(c::RowCacheEncoding::float8_block64_tail64())).value();
  row_cache_indexer_test::Fixture values(8,3);values.ranges={0,8,0,8,0,8};const auto dense_scores=values.expected();
  std::vector<std::uint16_t> attention_source(8*512);for(std::size_t i=0;i<attention_source.size();++i)attention_source[i]=row_cache_test::bfloat(double(int((i*7)%31)-15)/8);
  const auto attention=row_cache_test::reference(value_schema.capacity().encoding,attention_source);
  auto builder=g::GraphBuilder::create().value();
  const auto q=builder.input(values.descriptions[0]).value(),w=builder.input(values.descriptions[2]).value();
  const auto rd=dense(c::DataType::kInt32,{3,2}),rawid_desc=dense(c::DataType::kInt32,{3,3});
  const auto ranges=builder.input(rd).value(),raw_ranges=builder.input(rd).value(),raw_ids=builder.input(rawid_desc).value();
  const auto sqdesc=dense(c::DataType::kFloat32,{3,1,64,512}),sdesc=dense(c::DataType::kFloat32,{64});
  const auto sq=builder.input(sqdesc).value(),sink=builder.input(sdesc).value();
  const auto scorer=f::take(gb::add_row_cache_indexer(builder,scorer_schema,q,w,ranges,4),"paged indexer macro");
  const auto top=builder.add_node(c::TopK{.count=3},std::array{scorer.output()}).value();const auto ids=builder.result(top,1).value();
  const auto selected=f::take(gb::add_row_cache_gather_padded(builder,value_schema,ids,ranges,4),"compressed padding macro");
  const auto raw=f::take(gb::add_row_cache_gather_padded(builder,value_schema,raw_ids,raw_ranges,4),"raw window padding macro");
  const auto joined=builder.add_node(c::Concat{.axis=1},std::array{raw.output(),selected.output()}).value();
  const auto floats=builder.add(c::Cast{c::DataType::kFloat32},builder.result(joined).value()).value();
  const auto key=builder.add(c::View::reshape(c::TensorShape::create(std::array<std::int64_t,4>{3,6,1,512}).value()).value(),floats).value();
  const auto both_masks=builder.add_node(c::Concat{.axis=1},std::array{raw.mask(),selected.mask()}).value();
  const auto mask=builder.add(c::View::reshape(c::TensorShape::create(std::array<std::int64_t,3>{3,1,6}).value()).value(),builder.result(both_masks).value()).value();
  const auto attn=builder.add_node(c::model_ops::sink_attention(.0625F),std::array{sq,key,key,mask,sink}).value();
  const auto out=builder.result(attn).value(),neg=builder.add(c::Unary{c::UnaryKind::kNeg},out).value();
  const std::array published{scorer.output(),ids,raw.output(),selected.output(),raw.mask(),selected.mask(),out,neg};
  for(auto v:published)ASSERT_TRUE(builder.publish(v).ok());
  const auto graph=std::move(builder).finish().value();auto compiled=f::take(compile(graph),"paged score/TopK/padded/raw/Sink compile");
  auto queue=context.create_queue().value();const std::array lanes{gb::LaneBinding{.lane=g::ExecutionLaneId{0},.context=&context,.queue=&queue}};
  auto slot=f::take(gb::Invocation::create(graph,compiled.executable,lanes,std::array{selected.reader(),raw.reader()},std::array{scorer}),"typed scorer/gather coordinator");
  auto score_arena=c::PagedArena::create(scorer_schema,resource,{.max_backing_bytes=8*68+1}).value();
  auto value_arena=c::PagedArena::create(value_schema,resource,{.max_backing_bytes=8*584+1}).value();
  const auto score_pages=upload(score_arena,values.bank,68),value_pages=upload(value_arena,attention.bytes,584);
  auto pool=c::LeasePool::create(resource,4u<<20).value();
  for(bool empty:{false,true}){SCOPED_TRACE(empty);const auto sv=layout(scorer_schema,empty),vv=layout(value_schema,empty);
    const std::array layouts{gb::RowCacheNodeLayout{scorer.node(),sv},gb::RowCacheNodeLayout{selected.node(),vv},gb::RowCacheNodeLayout{raw.node(),vv}};
    ASSERT_TRUE(slot.prepare_row_cache(layouts).ok());
    ASSERT_TRUE(slot.bind(scorer.bank_input(),frame(score_arena,sv,score_pages,empty)).ok());
    ASSERT_TRUE(slot.bind(selected.bank_input(),frame(value_arena,vv,value_pages,empty)).ok());
    ASSERT_TRUE(slot.bind(raw.bank_input(),frame(value_arena,vv,value_pages,empty)).ok());
    // First compressed prefill: query0 has no compressed history, query1/2
    // have one visible row, yet TopK count is 3. Raw windows also include
    // future entries and an explicit -1; neither may read an unleased row0.
    const std::vector<std::int32_t> r=empty?std::vector<std::int32_t>(6):std::vector<std::int32_t>{0,0,0,1,0,1};
    const std::vector<std::int32_t> rr=empty?std::vector<std::int32_t>(6):std::vector<std::int32_t>{0,1,0,2,0,1};
    const std::vector<std::int32_t> ri{-1,0,1,0,1,2,0,1,2};
    ASSERT_TRUE(slot.bind(q,values.descriptions[0],f::load(pool,std::as_bytes(std::span(values.query)))).ok());
    ASSERT_TRUE(slot.bind(w,values.descriptions[2],f::load(pool,std::as_bytes(std::span(values.weights)))).ok());
    ASSERT_TRUE(slot.bind(ranges,rd,f::load(pool,std::as_bytes(std::span(r)))).ok());
    ASSERT_TRUE(slot.bind(raw_ranges,rd,f::load(pool,std::as_bytes(std::span(rr)))).ok());
    ASSERT_TRUE(slot.bind(raw_ids,rawid_desc,f::load(pool,std::as_bytes(std::span(ri)))).ok());
    const std::vector<float> query(3*64*512,0.F),sinks(64,.25F);
    ASSERT_TRUE(slot.bind(sq,sqdesc,f::load(pool,std::as_bytes(std::span(query)))).ok());
    ASSERT_TRUE(slot.bind(sink,sdesc,f::load(pool,std::as_bytes(std::span(sinks)))).ok());
    for(auto v:published){const auto desc=graph.value_description(v).value();auto writer=pool.allocate((std::max)(std::size_t{4},*desc.required_bytes())).value();ASSERT_TRUE(slot.bind(v,desc,std::move(writer)).ok());}
    auto done=slot.submit();ASSERT_TRUE(done)<<done.error().message();ASSERT_TRUE(done->wait().ok());
    const auto actual_scores=read<float>(slot.output(scorer.output()).value());
    for(std::size_t row=0;row<3;++row)for(int key=0;key<4;++key){const auto expected=key>=r[row*2]&&key<r[row*2+1]?dense_scores[row*8+physical(row,key)]:-std::numeric_limits<float>::infinity();EXPECT_FLOAT_EQ(actual_scores[row*4+key],expected);}
    const auto selected_ids=read<std::int32_t>(slot.output(ids).value());
    const auto raw_values=read<std::uint16_t>(slot.output(raw.output()).value()),selected_values=read<std::uint16_t>(slot.output(selected.output()).value());
    const auto rm=read<float>(slot.output(raw.mask()).value()),sm=read<float>(slot.output(selected.mask()).value());
    std::vector<double> expected(3*64*512);
    for(std::size_t row=0;row<3;++row){std::size_t valid_rows=0;
      for(int kind=0;kind<2;++kind)for(std::size_t k=0;k<3;++k){const auto id=kind?selected_ids[row*3+k]:ri[row*3+k];const auto begin=kind?r[row*2]:rr[row*2],end=kind?r[row*2+1]:rr[row*2+1];const bool valid=id>=begin&&id<end;
        ASSERT_GE(id,-1);ASSERT_LT(id,4);EXPECT_EQ((kind?sm:rm)[row*3+k],valid?0.F:-std::numeric_limits<float>::infinity());
        if(valid)++valid_rows;
        for(std::size_t d=0;d<512;++d){const auto wanted=valid?attention.decoded[physical(row,id)*512+d]:0;EXPECT_EQ((kind?selected_values:raw_values)[(row*3+k)*512+d],wanted);
          if(valid)for(std::size_t h=0;h<64;++h)expected[(row*64+h)*512+d]+=row_cache_test::decode(wanted);}}
      const auto denominator=std::exp(.25)+double(valid_rows);for(std::size_t h=0;h<64;++h)for(std::size_t d=0;d<512;++d)expected[(row*64+h)*512+d]/=denominator;
    }
    const auto actual=read<float>(slot.output(out).value()),negative=read<float>(slot.output(neg).value());
    for(std::size_t i=0;i<actual.size();++i){ASSERT_LE(std::abs(double(actual[i])-expected[i]),2e-5+2e-5*std::abs(expected[i]))<<i;ASSERT_EQ(negative[i],-actual[i]);}
    {auto retained=slot.output(out).value();EXPECT_TRUE(slot.prepare_row_cache(layouts).IsUnavailable());}
  }
  ASSERT_TRUE(slot.drain().ok());
}
} // namespace row_cache_paged_indexer_test
''',newline='\n')
p=Path('tests/graph_batch/row_cache_indexer_graph_test.cc');p.write_text('''#include "../compute_models/row_cache_paged_indexer_fixture.h"
#if defined(HYLE_ROW_CACHE_GRAPH_CUDA)
#include "hyle/graph/cuda.h"
#include "hyle/compute/backends/cuda.h"
TEST(CudaPagedRowCacheIndexerGraph, FirstPrefillTopKAndRawWindowPaddingUseExactPages){
  auto context=hyle::graph::cuda::create_context().value();
  auto resource=hyle::compute::cuda::MemoryResource::create(context,hyle::compute::cuda::MemoryKind::kDevice).value();
  row_cache_paged_indexer_test::exercise(context,resource.ref(),[&](const hyle::graph::Graph&g){return hyle::graph::cuda::compile(g,context,resource.ref());});
}
#else
#include "hyle/graph/cpu.h"
TEST(CpuPagedRowCacheIndexerGraph, FirstPrefillTopKAndRawWindowPaddingUseExactPages){
  auto context=hyle::graph::cpu::create_context().value();
  row_cache_paged_indexer_test::exercise(context,hyle::mem::system_resource(),[&](const hyle::graph::Graph&g){return hyle::graph::compile(g,context);});
}
#endif
''',newline='\n')
