#include "../compute_models/row_cache_paged_indexer_fixture.h"
#if defined(HYLE_ROW_CACHE_GRAPH_CUDA)
#include "hyle/graph/cuda.h"
#include "hyle/compute/backends/cuda.h"
TEST(CudaPagedRowCacheIndexerGraph, FirstPrefillTopKAndRawWindowPaddingUseExactPages){
  auto context=hyle::graph::cuda::create_context().value();
  auto resource=hyle::compute::cuda::MemoryResource::create(context,hyle::compute::cuda::MemoryKind::kDevice).value();
  row_cache_paged_indexer_test::exercise(context,resource.ref(),[&](const hyle::graph::Graph&g){return hyle::graph::cuda::compile(g,context,resource.ref());});
}
#else
#include "hyle/graph/cpu.h"
TEST(CpuPagedRowCacheIndexerGraph, FirstPrefillTopKAndRawWindowPaddingUseExactPages){
  auto context=hyle::graph::cpu::create_context().value();
  row_cache_paged_indexer_test::exercise(context,hyle::mem::system_resource(),[&](const hyle::graph::Graph&g){return hyle::graph::compile(g,context);});
}
#endif

#if !defined(HYLE_ROW_CACHE_GRAPH_CUDA)
TEST(CpuPagedRowCacheIndexerGraph, InvalidPaddingAndPrivateCapacityCannotEscape){
  auto context=hyle::graph::cpu::create_context().value();
  const auto compile=[&](const hyle::graph::Graph&g){return hyle::graph::compile(g,context);};
  row_cache_paged_indexer_test::rejected_private_readers(context,compile);
  row_cache_paged_indexer_test::invalid_padded(context,hyle::mem::system_resource(),compile);
}
#endif

#if !defined(HYLE_ROW_CACHE_GRAPH_CUDA)
TEST(CpuPagedRowCacheIndexerGraph, RequestLocalRangesCrossTheBoundedKeyTile){
  auto context=hyle::graph::cpu::create_context().value();
  row_cache_paged_indexer_test::crosses_tile(context,hyle::mem::system_resource(),[&](const hyle::graph::Graph&g){return hyle::graph::compile(g,context);});
}
#endif
