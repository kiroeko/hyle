from pathlib import Path
import json,hashlib,zipfile,difflib
R=Path.cwd();O=Path('.scratch/inference-foundation-review-2026-10-18/paged-indexer')
def ident(p):
 p=p.resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
# Update only the final test/cmake snapshots; host snapshots remain the exact
# CPU phase before the subsequent independently owned CUDA cold-span work.
for f in ['tests/compute_models/row_cache_paged_indexer_fixture.h','tests/graph_batch/row_cache_indexer_graph_test.cc','tests/compute_route_cpu/row_cache_padded_test.cc','tests/graph_batch/CMakeLists.txt','tests/compute_route_cpu/CMakeLists.txt']:
 t=O/'applied'/f;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(Path(f).read_bytes())
identities=[]
for p in sorted((O/'applied').rglob('*'),key=lambda p:p.as_posix()):
 if p.is_file():
  b=p.read_bytes();identities.append(dict(path=p.relative_to(O/'applied').as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(O/'source-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
parts=[]
for p in sorted((O/'applied').rglob('*'),key=lambda p:p.as_posix()):
 if not p.is_file():continue
 rel=p.relative_to(O/'applied');before=O/'before'/rel
 parts.extend(difflib.unified_diff(before.read_text().splitlines(True)if before.exists()else[],p.read_text().splitlines(True),fromfile='before/'+rel.as_posix(),tofile='applied/'+rel.as_posix()))
(O/'product.diff').write_text(''.join(parts),newline='\n')
objects=[ident(O/(n+'.obj'))for n in ['codec','native-provider','torch','leased','batch','node','tests','padded-tests']]
(O/'object-identities.json').write_text(json.dumps(dict(fresh=objects,executable=ident(O/'tests.exe'),map=ident(O/'tests.map'),current_torch_after_independent_grouped_change=ident(R/'.scratch/inference-foundation-review-2026-10-18/cpu-grouped-expert-reuse/product.obj')),indent=2)+'\n')
delete=[ident(O/f)for f in ['tests.exe','tests.exp','tests.lib']]
retain=[*objects,ident(O/'tests.map')]
cleanup=dict(platform='Windows',root=str(O.resolve()),delete=delete,retain=retain,delete_count=len(delete),delete_logicalbytes=sum(x['bytes']for x in delete),retain_count=len(retain),retain_logicalbytes=sum(x['bytes']for x in retain),executed=False,notes=['Only exact listed rebuildable paths. No source/log/SDK/shared cache deletion.','Root must review and execute through test.ps1; this stage performs no deletion.'])
(O/'cleanup-candidates.json').write_text(json.dumps(cleanup,indent=2)+'\n')
summary=dict(status='CPU public typed paged scoring and safe padded row decode implemented and verified',
 api=dict(padded='RowCacheGatherDecodePadded(encoding), checked-only; ID -1 => BF16 positive-zero without bank read, other invalid IDs OutOfRange before output writes; old checked gather unchanged',
  macro='add_row_cache_gather_padded(builder,schema,IDs,ranges,C) => reader()+BF16 rows+F32 additive mask; private Map result0 physical IDs and result1 0/-Inf mask',
  scorer='add_row_cache_indexer(builder,FP4schema,Q,W,ranges,C) => request-local F32[T,C]; original coordinator new create overload rows+scorers; original metadata/arena/queue/lease used',
  ports=['BF16[T,64,128] Q already QAT','U8[physical_capacity,68] row-inline FP4 bank','BF16[T,64] prescaled weights','I32[T,2] request-local half-open ranges','owned U8 metadata'],
  empty='Scorer may have empty history and nonempty query output(-Inf). Padded decoder admits zero-row bank with nonempty all-1 IDs. Private padded Map requires K>0 when T>0 to propagate invalid range sentinel; decoder itself keeps K0 no-op.'),
 mathematics='F32-accumulating BF16 dot -> BF16 -> ReLU -> BF16 weighted product -> F32-accumulating head sum -> BF16 -> F32; outside-range -Inf',
 implementation=['CPU ATen private scorer validates all metadata/ranges before any packed row decode/result publication.','Per-request keytile <=256x128 BF16; each request logical union row decoded once within its tile, then per-query intersected matmul. Empty gaps jumped; no whole-history BF16 materialization.','Physical bank rows must equal metadata max_pages*page_size in private scorer schema; page references/ranges fully validated.','Typed Graph cold qualification allows only exact Map-to-codec or scorer operation chain on audited ordinary native CPU/CUDA. Extra private readers, bank aliases/copies, private publication are rejected.','Every frame retains the exact initialized/generation-valid page leases of the original full layout footprint. Query ranges do not manufacture tighter leases or whole-arena permission.'],
 validation=dict(command='python -B .scratch/inference-foundation-review-2026-10-18/paged-indexer/run.py build ...; link; test (exact commands.json)',final_log='40-canonical-test.stdout.log',tests='5/5 PASS, exit0',
  cases=['First prefill compressed visible0/1<K3, raw window future and explicit-1; FP4 paged scorer→TopK→FP8 padded readers→Concat→B3/H64/D512 Sink→Neg; scores/IDs/decoded bits/masks/full outputs checked.','Same graph repeated with empty histories: zero ReadLease footprint and correct all-zero attention with learned sink. Arena capacity remains allocated.','C257/P128 crossed 256-row tile, two requests/page mappings, two independent slots with query splits(2,1) and(1,2), old output retained; final invalid range preserves complete score sentinel.','Padded FP4 and FP8 decode, two phases/two outputs, IDs -2 and >=rows fail without writes; L0 plus nonempty all-1 IDs produces exact BF16 zero.','New private capacity direct/alias publication rejected; invalid column/range preserves decoded caller buffer and failed Graph output cannot publish. Original checked Graph macro compatibility/empty/private controls passed.'],
  proof_limits=['No throughput/latency or RSS/total allocator peak measurement. Decoded keytile bound is source-proven; F32[T,C] score output is required and separately staged before publish.','Zero page footprint means no read permission or payload access, not zero arena allocation/VRAM.','Map mask may be an accepted-prefix write before a downstream decoder failure. Original Graph is not a transaction over all caller buffers.','Fixture begins at finite post-projection/post-QAT encoded bank boundary; it does not establish every model raw-QAT re-encode equivalence or a complete model.','Two slots have distinct request Q grouping; this stage did not prepare both slots before interleaved execution, or test pending scoring.']),
 failures_retained=['6-node-compile: optional-to-pointer compile error corrected.','8-tests-compile: explicit Operation conversion/warning corrections in new fixture.','10/11-link: duplicate/mismatched old cached GGML object and missing pending-arena symbols; replaced with matched existing closure, no SDK rebuild.','13/16-canonical-test: new fixture incorrectly passed eight rows to existing fixed-five-row reference helper, causing insufficient encoded bytes. Corrected by two independent five-row reference calls and truncation to eight; inputs/mathematics/budgets unchanged.','One transient fixture write PermissionError while a different cl consumer held the file; no product operation ran for that attempted write.','33-tests-compile: ambiguous Result assignment in fixture corrected to explicit Completion move.'],
 source_scope=dict(tested_torch='applied/src/compute_provider_native/torch_cpu_program.cc reconstructed exactly from frozen before plus recorded edit_torch.py; compiled before root independent grouped change',
  later_changes='Root subsequently compiled same scorer body plus independent grouped-expert optimization; final source SHA ebb3fe3f6e08bee5a79ccbde50c52ec6fb0a62d1967922b93a63b0cf244e8131. CUDA cold-span extension is a later separately owned phase; this package preserves prior Graph host identity.',
  extra_guard='New create overload invalid-allocator early guard found in independent review; CUDA cold-span author owns adding and validating it in subsequent batch.cc overlay.'),
 remaining=['CUDA typed scorer in progress; CUDA padded carrier already independently passed but not counted as CPU evidence.','Apple/Vulkan four-port scorer exists; typed paged scorer/padded Graph/native page authorization remains to be implemented, not silently opened.','No raw whole-arena permission API, no new executor, no public tile option or schema layout version change.'],
 artifacts=dict(source_identities='source-identities.json',objects='object-identities.json',cleanup='cleanup-candidates.json',commands='commands.json',hardware='hardware.json'))
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for p in O.rglob('*'):
 if p.is_file()and p.suffix in {'.json','.py','.log','.cc','.h','.txt','.diff'} and not p.name.endswith('.zip'):files.append(p)
with zipfile.ZipFile(O/'source-results.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(files,key=lambda p:p.relative_to(O).as_posix()):z.write(p,p.relative_to(O).as_posix())
print(json.dumps(ident(O/'source-results.zip')))
