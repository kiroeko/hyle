#pragma once

#include "hyle/compute/resource_leases.h"
#include "hyle/compute/tensor.h"
#include "hyle/graph/visibility.h"

namespace hyle::graph {
namespace detail { struct InvocationState; }
class Invocation;

// A readonly result retaining its original execution slot and owned backing.
// Copies prevent reuse of that slot. Raw external TensorView storage remains
// borrowed and must outlive its consumers; exporting an owned storage lease
// independently protects that backing against writer reuse.
class GraphOutput final {
public:
  GraphOutput() noexcept = default;
  HYLE_GRAPH_API GraphOutput(const GraphOutput &) noexcept;
  HYLE_GRAPH_API GraphOutput &operator=(const GraphOutput &) noexcept;
  HYLE_GRAPH_API GraphOutput(GraphOutput &&) noexcept;
  HYLE_GRAPH_API GraphOutput &operator=(GraphOutput &&) noexcept;
  HYLE_GRAPH_API ~GraphOutput();
  bool valid() const noexcept { return state_ != nullptr; }
  HYLE_GRAPH_API Result<compute::ConstTensorView> tensor() const noexcept;
  // Exports an actual external storage owner. Private workspace and constants
  // retain their Graph owner and cannot become independent external leases.
  HYLE_GRAPH_API Result<compute::ReadLease> storage_lease() const noexcept;
  HYLE_GRAPH_API void reset() noexcept;

private:
  friend class Invocation;
  GraphOutput(detail::InvocationState *, compute::ConstTensorView) noexcept;
  detail::InvocationState *state_ = nullptr;
  compute::ConstTensorView tensor_{};
};

} // namespace hyle::graph
