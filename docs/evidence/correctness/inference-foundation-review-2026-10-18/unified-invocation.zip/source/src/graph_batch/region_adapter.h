#pragma once

#include "hyle/graph/executable.h"
#include "hyle/graph/batch.h"

namespace hyle::graph::batch::detail {
// Default route assembly. Adapters borrow each original Context capability;
// the ordinary compiler retains the selected native owner and slot.
HYLE_GRAPH_BATCH_API Result<CompiledGraph> compile(
    const Graph &, CompileEnvironment, CompileOptions,
    compute::BackendId cpu = {}, compute::BackendId gpu = {}) noexcept;
} // namespace hyle::graph::batch::detail
