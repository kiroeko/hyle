#include "hyle/graph/detail/region_access.h"
#include "plan_state.h"

namespace hyle::graph::detail {
Result<bool> RegionAccess::configure_operation(Invocation&invocation,NodeId node,
    compute::ProviderExtensionId extension,const void*configuration)noexcept{
  auto*state=InvocationAccess::state(invocation);
  if(!state || GraphIdentity::generation(node)!=state->plan->generation || node.ordinal()>=state->plan->node_steps.size())
    return std::unexpected(Status::InvalidArgument("cold operation node is foreign"));
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  const auto index=state->plan->node_steps[node.ordinal()];
  if(index>=state->plan->steps.size() || state->plan->steps[index].kind!=PlanStepKind::kOperation ||
      state->plan->steps[index].node_count!=1)
     return std::unexpected(Status::Unimplemented("cold operation must remain an ordinary singleton"));
  return compute::detail::OperationInvocationAccess::configure_cold(
      state->invocations[index].operation,extension,configuration);
}
Status RegionAccess::validate_queue(const Executable&executable,ExecutionLaneId lane,const compute::Queue&queue)noexcept{
  const auto*plan=ExecutableAccess::state(executable);
  if(!plan || !lane.valid() || lane.ordinal()>=plan->lanes.size() ||
     !plan->targets[plan->lanes[lane.ordinal()].target.ordinal()].context.owns(queue))
    return Status::InvalidArgument("Graph adapter Queue belongs to a different execution target");
  return Status::Ok();
}
Status RegionAccess::visit(const Executable&executable,RegionAccessFn callback,void*user)noexcept{
  auto*plan=ExecutableAccess::state(executable);
  if(!plan || !callback)return Status::InvalidArgument("region access requires an executable and callback");
  for(std::size_t i=0;i<plan->steps.size();++i){
    const auto&step=plan->steps[i];if(step.kind!=PlanStepKind::kRegion)continue;
    RegionAccessView view{std::uint32_t(i),plan->generation,std::span<const std::uint32_t>(plan->step_nodes).subspan(step.node_set_begin,step.node_count),
      &step.region.extension_,step.region.prepared_.state,nullptr,step.lane,
      {},{},step.region.prepared_.vtable};
    HYLE_RETURN_IF_ERROR(callback(user,view));
  }return Status::Ok();
}
Status RegionAccess::visit(Invocation&invocation,RegionAccessFn callback,void*user)noexcept{
  auto*state=InvocationAccess::state(invocation);
  if(!state || !callback)return Status::InvalidArgument("region access requires an invocation and callback");
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  auto*plan=state->plan;
  for(std::size_t i=0;i<plan->steps.size();++i){
    const auto&step=plan->steps[i];if(step.kind!=PlanStepKind::kRegion)continue;
    const auto&slot=state->invocations[i].region;
    RegionAccessView view{std::uint32_t(i),plan->generation,std::span<const std::uint32_t>(plan->step_nodes).subspan(step.node_set_begin,step.node_count),
      &step.region.extension_,step.region.prepared_.state,slot.state_,step.lane,
      {},{},step.region.prepared_.vtable};
    HYLE_RETURN_IF_ERROR(callback(user,view));
  }return Status::Ok();
}
} // namespace hyle::graph::detail
