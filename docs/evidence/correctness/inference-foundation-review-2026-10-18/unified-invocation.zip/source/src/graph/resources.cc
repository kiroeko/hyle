#include "hyle/graph/executable.h"
#include "hyle/graph/detail/region_access.h"
#include "hyle/graph/result.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <mutex>
#include <new>
#include <utility>
#include <vector>

#include "hyle/compute/detail/completion_access.h"
#include "hyle/core/assert.h"
#include "hyle/mem/std_allocator.h"
#include "hyle/util/spin_lock.h"
#include "plan_state.h"
#include "resource_episode.h"
#include "submission_internal.h"
#include "../compute/provider_internal.h"

namespace hyle::graph {
namespace detail {
struct LeaseBinding final {
  ValueId value{};
  ValueId projection{};
  compute::TensorDesc description{};
  compute::ReadLease read{};
  compute::WriteLease write{};
  bool exclusive = false;
  bool input = false;
  bool permissionless = false;
  bool borrowed = true;
};

struct ResourceEpisode final {
  ResourceEpisode(InvocationState &invocation, mem::AllocatorRef selected) noexcept
      : owner(invocation), allocator(selected),
        bindings(mem::StdAllocator<LeaseBinding>(selected)), permissions(selected),
        retentions(mem::StdAllocator<compute::detail::CompletionRetention>(selected)) {}
  ~ResourceEpisode() {
    if (payload) payload_table->destroy(payload);
  }
  InvocationState &owner;
  mem::AllocatorRef allocator;
  std::vector<LeaseBinding, mem::StdAllocator<LeaseBinding>> bindings;
  LeasePermissionSet permissions;
  compute::LeaseUsePool uses;
  std::vector<compute::detail::CompletionRetention,
              mem::StdAllocator<compute::detail::CompletionRetention>> retentions;
  compute::LeaseUseBatch batch;
  compute::detail::CompletionLifetime observation_retirement{};
  util::SpinLock lock;
  Status first_error;
  std::atomic<std::size_t> remaining{0};
  bool accepted = false;
  std::uint32_t reserved_reads = 0;
  const ResourcePayloadVTable *payload_table = nullptr;
  void *payload = nullptr;
};

ResourceEpisodeOwner::ResourceEpisodeOwner(ResourceEpisodeOwner &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)) {}
ResourceEpisodeOwner &ResourceEpisodeOwner::operator=(ResourceEpisodeOwner &&other) noexcept {
  if (this != &other) { reset(); state_ = std::exchange(other.state_, nullptr); }
  return *this;
}
ResourceEpisodeOwner::~ResourceEpisodeOwner() { reset(); }
void ResourceEpisodeOwner::reset() noexcept {
  if (auto *episode = std::exchange(state_, nullptr)) {
    const auto allocator = episode->allocator;
    allocator.destroy(episode);
  }
}

Status resource_control_ready(const InvocationState *state) noexcept {
  if (!state) return Status::FailedPrecondition("graph invocation is empty");
  if (state->closed) return Status::FailedPrecondition("graph invocation is closed");
  const auto phase = state->phase.load(std::memory_order_acquire);
  if (phase == InvocationPhase::kRunning)
    return Status::Unavailable("graph invocation is in flight");
  if (phase == InvocationPhase::kFailed)
    return Status::FailedPrecondition("failed graph invocation must be recreated");
  if (state->results.load(std::memory_order_acquire))
    return Status::Unavailable("graph results still retain this invocation");
  if (!state->observation.available())
    return Status::Unavailable("old graph completion retains its observation slot");
  return Status::Ok();
}

Status reset_resource_payload(InvocationState &state) noexcept {
  HYLE_RETURN_IF_ERROR(resource_control_ready(&state));
  if (!state.resources || !state.resources.get()->payload) return Status::Ok();
  auto &episode = *state.resources.get();
  return episode.payload_table->reset(episode.payload);
}

Result<void *> RegionAccess::resource_payload(Invocation &invocation,
    const ResourcePayloadVTable *table) noexcept {
  auto *state = InvocationAccess::state(invocation);
  if (!state)
    return std::unexpected(Status::FailedPrecondition("graph invocation is empty"));
  if (!table || !table->reset || !table->destroy)
    return std::unexpected(Status::InvalidArgument("resource payload implementation is incomplete"));
  if (!state->resources || !state->resources.get()->payload) return nullptr;
  auto &episode = *state->resources.get();
  if (episode.payload_table != table)
    return std::unexpected(Status::InvalidArgument("resource payload belongs to another implementation"));
  return episode.payload;
}

Result<ResourceEpisode *> require_resources(InvocationState *state) noexcept {
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  if (!state->resources)
    return std::unexpected(Status::FailedPrecondition(
        "owned bindings require prepare_resources or factory.resources"));
  return state->resources.get();
}
Status RegionAccess::attach_resource_payload(Invocation &invocation,
    const ResourcePayloadVTable *table, void *payload) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto *episode, require_resources(state));
  if (!table || !table->reset || !table->destroy || !payload)
    return Status::InvalidArgument("resource payload requires an implementation and owner");
  if (episode->payload)
    return Status::FailedPrecondition("graph invocation already owns a resource payload");
  episode->payload_table = table;
  episode->payload = payload;
  return Status::Ok();
}
LeaseBinding *find_binding(InvocationState *state, ValueId value) noexcept {
  if (!state || !state->resources) return nullptr;
  for (auto &binding : state->resources.get()->bindings)
    if (binding.value == value) return &binding;
  return nullptr;
}
void reset_resource_bindings(InvocationState &state) noexcept {
  if (!state.resources) return;
  auto &bindings = state.resources.get()->bindings;
  std::erase_if(bindings, [](const auto &binding) { return !binding.value.valid(); });
  for (auto &binding : bindings) {
    binding.read.reset(); binding.write.reset(); binding.description = {};
    binding.exclusive = false; binding.permissionless = false; binding.borrowed = true;
  }
}
void note_borrowed_binding(InvocationState &state, ValueId value) noexcept {
  if (!state.resources) return;
  auto &bindings = state.resources.get()->bindings;
  std::erase_if(bindings, [&](const auto &binding) {
    return !binding.value.valid() && binding.projection == value;
  });
  if (auto *binding = find_binding(&state, value)) {
    binding->read.reset(); binding->write.reset(); binding->description = {};
    binding->exclusive = false; binding->permissionless = false; binding->borrowed = true;
  }
}

Status RegionAccess::reserve_reads(Invocation &invocation, std::uint32_t extra,
                                 ResourceOptions options) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto *episode, require_resources(state));
  // Repeated layout preparation reuses the same fixed permission/use storage.
  // Only actual capacity growth needs an unbound cold slot.
  if (extra <= episode->reserved_reads) return Status::Ok();
  for (const auto &binding : episode->bindings)
    if (binding.read.valid() || binding.write.valid())
      return Status::FailedPrecondition("reserve page permissions before owned bindings");
  if (extra > UINT32_MAX - 1 || episode->bindings.size() > UINT32_MAX - 1 - extra)
    return Status::ResourceExhausted("graph permission capacity overflow");
  HYLE_ASSIGN_OR_RETURN(auto uses, compute::LeaseUsePool::create({.max_batches = 1,
      .max_resources_per_batch = std::uint32_t(episode->bindings.size() + extra + 1),
      .allocator = options.allocator, .resource_budget = options.resource_budget}));
  try { episode->bindings.reserve(episode->bindings.size() + extra); }
  catch (...) { return Status::ResourceExhausted("graph fixed permission metadata"); }
  if (extra) HYLE_RETURN_IF_ERROR(episode->permissions.reserve(episode->bindings.size() + extra));
  episode->uses = std::move(uses);
  episode->reserved_reads = extra;
  return Status::Ok();
}
Status bind_projected(Invocation&invocation,ValueId value,
    compute::ConstTensorView tensor,std::span<const compute::ReadLease> pages,
    std::span<const ProjectedReader> readers,
    bool pending)noexcept{
  auto*state=InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto*episode, require_resources(state));
  auto*binding=find_binding(state,value);
  if(!binding || !binding->input || !tensor.valid() || (!pending && pages.empty()) || readers.empty())
    return Status::InvalidArgument("projected graph requires an input and actual page permissions");
  if(binding->read.valid() || binding->write.valid())
    return Status::FailedPrecondition("projected graph input needs an explicit reset before rebinding");
  const auto&plan=*state->plan;
  const auto logical=value.ordinal();const auto physical=plan.external_instances[logical];
  if((plan.binding_roles[logical]&kExternalOutput)!=0)
    return Status::InvalidArgument("projected capacity cannot be a graph output");
  for(std::size_t i=0;i<plan.alias_sources.size();++i){
    // Every descendant chain must contain a direct child of this root.
    if(i!=physical && plan.alias_sources[i]==physical)
      return Status::InvalidArgument("projected capacity cannot have a physical alias descendant");
  }
  for(std::size_t i=0;i<readers.size();++i){
    const auto&proof=readers[i];
    if(proof.step>=plan.steps.size())
      return Status::InvalidArgument("projected reader step is foreign");
    const auto&step=plan.steps[proof.step];
    if(step.kind!=PlanStepKind::kRegion || proof.input_port>=step.input_count ||
       !step.region.matches_artifact(proof.implementation,proof.prepared) ||
       plan.node_inputs[step.input_begin+proof.input_port]!=physical)
      return Status::InvalidArgument("projected reader differs from its selected artifact/port");
    for(std::size_t j=0;j<i;++j)
      if(readers[j].step==proof.step && readers[j].input_port==proof.input_port)
        return Status::InvalidArgument("projected reader physical port is duplicated");
  }
  bool consumed=false;
  for(std::size_t i=0;i<plan.steps.size();++i){const auto&step=plan.steps[i];
    for(std::size_t port=0;port<step.input_count;++port){
      const auto input=plan.node_inputs[step.input_begin+port];
      if(plan.instance_values[input]!=logical)continue;
      consumed=true;
      if(input!=physical || step.kind!=PlanStepKind::kRegion ||
         std::none_of(readers.begin(),readers.end(),[&](const auto&proof)noexcept{
           return proof.step==i && proof.input_port==port;
         }))
        return Status::InvalidArgument("projected capacity has an unqualified physical reader");
    }
  }
  if(!consumed)return Status::InvalidArgument("projected capacity has no qualified reader");
  if(!pages.empty() && pages.size()-1>episode->bindings.capacity()-episode->bindings.size())
    return Status::ResourceExhausted("projected graph permission capacity exhausted");
  const auto storage=tensor.storage();
  for(const auto&page:pages){HYLE_ASSIGN_OR_RETURN(auto view,page.view());
    if(view.resource()!=storage.resource() || view.native_handle()!=storage.native_handle() ||
       view.offset()<storage.offset() || view.offset()-storage.offset()>storage.size() ||
       view.size()>storage.size()-(view.offset()-storage.offset()))
      return Status::InvalidArgument("projected page permission is outside its native capacity");
  }
  HYLE_RETURN_IF_ERROR(invocation.bind(value,tensor));
  if(!pages.empty())binding->read=pages.front();
  binding->description=tensor.description();binding->exclusive=false;binding->borrowed=false;
  for(std::size_t i=1;i<pages.size();++i)episode->bindings.push_back({.projection=value,.read=pages[i],.borrowed=false});
  return Status::Ok();
}
Status RegionAccess::bind_projected(Invocation&invocation,ValueId value,
    compute::ConstTensorView tensor,std::span<const compute::ReadLease> pages,
    std::span<const ProjectedReader> readers)noexcept{
  return detail::bind_projected(invocation,value,tensor,pages,readers,false);
}
Status RegionAccess::bind_pending_projected(Invocation&invocation,ValueId value,
    compute::ConstTensorView tensor,std::span<const ProjectedReader> readers)noexcept{
  return detail::bind_projected(invocation,value,tensor,{},readers,true);
}
bool RegionAccess::outcome_available(const Invocation&invocation)noexcept{
  const auto*state=InvocationAccess::state(invocation);
  return state && state->phase.load(std::memory_order_acquire)!=InvocationPhase::kRunning &&
      !state->results.load(std::memory_order_acquire) && state->observation.available();
}
Status RegionAccess::bind_gather(Invocation&invocation,const Graph&graph,
    ValueId capacity,ValueId indices,compute::ConstTensorView tensor,
    std::span<const compute::ReadLease> pages)noexcept{
  auto*state=InvocationAccess::state(invocation);HYLE_ASSIGN_OR_RETURN(auto*episode, require_resources(state));
  auto*binding=find_binding(state,capacity);const auto*source=GraphAccess::state(graph);
  const auto&plan=*state->plan;
  if(!source || source->generation!=plan.generation || capacity==indices ||
     GraphIdentity::generation(capacity)!=source->generation || GraphIdentity::generation(indices)!=source->generation ||
     capacity.kind()!=ValueKind::kInput || indices.kind()!=ValueKind::kInput ||
     !binding || !binding->input || !tensor.valid() || !tensor.description().is_dense() || pages.empty())
    return Status::InvalidArgument("gather projection requires the exact graph/input/footprint");
  if(binding->read.valid() || binding->write.valid())
    return Status::FailedPrecondition("gather projection needs reset before rebinding");
  if(std::find(source->inputs.begin(),source->inputs.end(),indices.ordinal())==source->inputs.end())
    return Status::InvalidArgument("gather indices are not an input of this graph");
  NodeId reshape{},gather{};ValueId alias{};
  for(std::size_t i=0;i<source->nodes.size();++i){const auto node=GraphIdentity::node(source->generation,std::uint32_t(i));
    HYLE_ASSIGN_OR_RETURN(auto count,graph.node_input_count(node));
    for(std::size_t port=0;port<count;++port){HYLE_ASSIGN_OR_RETURN(auto input,graph.node_input(node,port));if(input!=capacity)continue;
      HYLE_ASSIGN_OR_RETURN(auto operation,graph.operation(node));const auto*view=operation.get_if<compute::View>();
      if(reshape.valid() || !view || view->kind()!=compute::ViewKind::kReshape || count!=1)
        return Status::InvalidArgument("capacity has a reader outside its unique reshape");
      HYLE_ASSIGN_OR_RETURN(auto outputs,graph.node_output_count(node));if(outputs!=1)return Status::InvalidArgument("capacity reshape arity");
      reshape=node;HYLE_ASSIGN_OR_RETURN(alias,graph.result(node));
    }
  }
  if(!reshape.valid())return Status::InvalidArgument("capacity has no unique reshape");
  for(std::size_t i=0;i<source->nodes.size();++i){const auto node=GraphIdentity::node(source->generation,std::uint32_t(i));
    HYLE_ASSIGN_OR_RETURN(auto count,graph.node_input_count(node));
    for(std::size_t port=0;port<count;++port){HYLE_ASSIGN_OR_RETURN(auto input,graph.node_input(node,port));if(input!=alias)continue;
      HYLE_ASSIGN_OR_RETURN(auto operation,graph.operation(node));const auto*op=operation.get_if<compute::Gather>();
      if(gather.valid() || !op || op->axis!=0 || op->bounds!=compute::IndexBoundsPolicy::kChecked || count!=2 || port!=0)
        return Status::InvalidArgument("capacity alias has a reader outside its unique checked Gather");
      HYLE_ASSIGN_OR_RETURN(auto supplied_indices,graph.node_input(node,1));if(supplied_indices!=indices)
        return Status::InvalidArgument("capacity Gather uses foreign metadata");
      gather=node;
    }
  }
  if(!gather.valid() || std::find(source->outputs.begin(),source->outputs.end(),capacity.ordinal())!=source->outputs.end() ||
     std::find(source->outputs.begin(),source->outputs.end(),alias.ordinal())!=source->outputs.end())
    return Status::InvalidArgument("capacity/reshape cannot be published");
  const auto root=plan.external_instances[capacity.ordinal()];bool consumed=false;
  for(const auto&step:plan.steps){const auto nodes=std::span<const std::uint32_t>(plan.step_nodes).subspan(step.node_set_begin,step.node_count);
    for(std::size_t port=0;port<step.input_count;++port){auto input=plan.node_inputs[step.input_begin+port];
      auto origin=input;while(plan.alias_sources[origin]!=kNoInPlaceSource)origin=plan.alias_sources[origin];if(origin!=root)continue;
      const auto logical=plan.instance_values[input];
      if(logical!=capacity.ordinal() && logical!=alias.ordinal())return Status::InvalidArgument("capacity has an extra physical alias reader");
      const auto has=[&](NodeId node){return std::find(nodes.begin(),nodes.end(),node.ordinal())!=nodes.end();};
      if(step.kind==PlanStepKind::kView && !step.materializes && has(reshape))continue;
      if(!has(gather) || (step.kind!=PlanStepKind::kRegion &&
         !(step.kind==PlanStepKind::kOperation && step.operation.kind()==compute::OperationKind::kGather)))
        return Status::InvalidArgument("capacity physical reader materializes/copies outside Gather");
      consumed=true;
    }
  }
  if(!consumed)return Status::InvalidArgument("capacity has no physical Gather reader");
  if(pages.size()-1>episode->bindings.capacity()-episode->bindings.size())
    return Status::ResourceExhausted("gather projection guard capacity exhausted");
  const auto storage=tensor.storage();for(const auto&page:pages){HYLE_ASSIGN_OR_RETURN(auto view,page.view());
    if(view.resource()!=storage.resource() || view.native_handle()!=storage.native_handle() ||
       view.offset()<storage.offset() || view.offset()-storage.offset()>storage.size() ||
       view.size()>storage.size()-(view.offset()-storage.offset()))return Status::InvalidArgument("gather page guard outside native capacity");
  }
  HYLE_RETURN_IF_ERROR(invocation.bind(capacity,tensor));
  binding->read=pages.front();binding->description=tensor.description();binding->exclusive=false;binding->borrowed=false;
  for(std::size_t i=1;i<pages.size();++i)episode->bindings.push_back({.projection=capacity,.read=pages[i],.borrowed=false});return Status::Ok();
}
Result<compute::WriteLease> RegionAccess::take_write(Invocation&invocation,ValueId value)noexcept{
  auto*state=InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto*episode,require_resources(state));
  (void)episode;
  if(state->phase.load(std::memory_order_acquire)!=InvocationPhase::kIdle)
    return std::unexpected(Status::FailedPrecondition("failed graph output cannot be reclaimed"));
  auto*binding=find_binding(state,value);if(!binding || binding->input)
    return std::unexpected(Status::InvalidArgument("only caller output writer can be reclaimed"));
  return std::move(binding->write);
}
namespace {
Result<compute::detail::OperationPreparedAccess> projection_access(
    const PlanState &plan, ResourceProjection projection) noexcept {
  if (!projection.capability.valid() || projection.access_nodes.empty())
    return std::unexpected(Status::InvalidArgument("projection needs its selected access implementations"));
  compute::detail::OperationPreparedAccess reader_access;
  bool found = false;
  for (const auto node : projection.access_nodes) {
    if (GraphIdentity::generation(node) != plan.generation || node.ordinal() >= plan.node_steps.size())
      return std::unexpected(Status::InvalidArgument("projection access node is foreign"));
    const auto index = plan.node_steps[node.ordinal()];
    if (index >= plan.steps.size() || plan.steps[index].kind != PlanStepKind::kOperation || plan.steps[index].node_count != 1)
      return std::unexpected(Status::Unimplemented("projection needs an ordinary selected prepared implementation"));
    HYLE_ASSIGN_OR_RETURN(auto access, compute::detail::OperationPreparationAccess::inspect_access(
        plan.steps[index].operation, projection.capability));
    if (node == projection.reader) { reader_access = access; found = true; }
  }
  if (!found || reader_access.projected_input == compute::detail::OperationPreparedAccess::kNoInput)
    return std::unexpected(Status::Unimplemented("selected reader does not project a physical input"));
  const auto &reader = plan.steps[plan.node_steps[projection.reader.ordinal()]];
  if (reader_access.projected_input >= reader.input_count)
    return std::unexpected(Status::InvalidArgument("projection prepared input port is outside its selected step"));
  const auto physical = plan.node_inputs[reader.input_begin + reader_access.projected_input];
  if (plan.instance_values[physical] != projection.capacity.ordinal())
    return std::unexpected(Status::InvalidArgument("projection capacity differs from selected prepared input"));
  return reader_access;
}
} // namespace
Result<mem::MemoryResourceRef> RegionAccess::projection_resource(const Executable&executable,
    ResourceProjection projection,ExecutionLaneId*reader_lane)noexcept{
  const auto*plan=ExecutableAccess::state(executable);
  const auto capacity=projection.capacity,metadata=projection.metadata;
  const auto decoder=projection.reader;
  if(!plan || capacity==metadata ||
      capacity.kind()!=ValueKind::kInput || metadata.kind()!=ValueKind::kInput ||
      GraphIdentity::generation(capacity)!=plan->generation || GraphIdentity::generation(metadata)!=plan->generation ||
      capacity.ordinal()>=plan->external_instances.size() || metadata.ordinal()>=plan->external_instances.size() ||
      !(plan->binding_roles[capacity.ordinal()]&kExternalInput) ||
      !(plan->binding_roles[metadata.ordinal()]&kExternalInput))
    return std::unexpected(Status::InvalidArgument("projection needs its exact plan and input identities"));
  HYLE_ASSIGN_OR_RETURN(auto access,projection_access(*plan,projection));
  const auto bank_port=access.projected_input;
  const auto root=plan->external_instances[capacity.ordinal()];
  for(std::size_t i=0;i<plan->alias_sources.size();++i)if(i!=root && plan->alias_sources[i]==root)
    return std::unexpected(Status::InvalidArgument("row capacity cannot have a physical alias descendant"));
  bool consumed=false;
  for(std::size_t i=0;i<plan->steps.size();++i){const auto&step=plan->steps[i];
    for(std::size_t port=0;port<step.input_count;++port){const auto input=plan->node_inputs[step.input_begin+port];
      if(plan->instance_values[input]!=capacity.ordinal())continue;
      if(input!=root || i!=plan->node_steps[decoder.ordinal()] || step.kind!=PlanStepKind::kOperation || port!=bank_port)
        return std::unexpected(Status::InvalidArgument("row capacity has a copy or unrelated physical reader"));
      consumed=true;
    }}
  if(!consumed || (plan->binding_roles[capacity.ordinal()]&kExternalOutput)!=0)
    return std::unexpected(Status::InvalidArgument("row capacity is published or has no checked reader"));
  const auto a=plan->external_storage[capacity.ordinal()],b=plan->external_storage[metadata.ordinal()];
  if(a>=plan->storage_domains.size() || b>=plan->storage_domains.size() ||
      plan->storage_domains[a].resource!=plan->storage_domains[b].resource)
    return std::unexpected(Status::Unimplemented("row capacity and metadata require the same native resource"));
  if(reader_lane)*reader_lane=plan->steps[plan->node_steps[decoder.ordinal()]].lane;
  return plan->storage_domains[a].resource;
}
Status RegionAccess::bind_projection(Invocation&invocation,ResourceProjection projection,
    compute::ConstTensorView tensor,std::span<const compute::ReadLease>pages,bool pending)noexcept{
  auto*state=InvocationAccess::state(invocation);HYLE_ASSIGN_OR_RETURN(auto*episode, require_resources(state));
  HYLE_ASSIGN_OR_RETURN(auto resource,projection_resource(invocation.executable(),projection));
  HYLE_ASSIGN_OR_RETURN(auto access,projection_access(*state->plan,projection));
  const auto capacity=projection.capacity;
  auto*binding=find_binding(state,capacity);
  const auto&description=state->plan->domain_graph.valid()?state->concrete_descriptions[capacity.ordinal()]:state->plan->descriptions[capacity.ordinal()];
  if(!binding || !binding->input || !tensor.valid() || tensor.description()!=description || tensor.storage().resource()!=resource ||
      (pages.empty() && !pending && !access.allows_empty_footprint) || (pending && !pages.empty()))
    return Status::InvalidArgument("row projection needs its native capacity and exact page guards");
  if(binding->read.valid() || binding->write.valid() || binding->permissionless)return Status::FailedPrecondition("row projection needs reset before rebinding");
  if(!pages.empty() && pages.size()-1>episode->bindings.capacity()-episode->bindings.size())return Status::ResourceExhausted("row projection page guard capacity");
  const auto storage=tensor.storage();for(const auto&page:pages){HYLE_ASSIGN_OR_RETURN(auto view,page.view());
    if(view.resource()!=storage.resource() || view.native_handle()!=storage.native_handle() || view.offset()<storage.offset() ||
        view.offset()-storage.offset()>storage.size() || view.size()>storage.size()-(view.offset()-storage.offset()))
      return Status::InvalidArgument("row page guard outside original capacity");}
  HYLE_RETURN_IF_ERROR(invocation.bind(capacity,tensor));
  if(!pages.empty())binding->read=pages.front();binding->description=description;binding->exclusive=false;binding->borrowed=false;binding->permissionless=pages.empty()&&!pending;
  for(std::size_t i=1;i<pages.size();++i)episode->bindings.push_back({.projection=capacity,.read=pages[i],.borrowed=false});return Status::Ok();
}
void record_error(ResourceEpisode &episode, const Status &error) noexcept {
  if (!error.ok()) {
    std::lock_guard guard(episode.lock);
    episode.first_error.Update(error);
  }
}
void child_terminal(void *opaque, const Status &terminal) noexcept {
  auto &state = *static_cast<InvocationState *>(opaque);
  record_error(*state.resources.get(), terminal);
}
void release_episode(void *opaque) noexcept {
  auto &state = *static_cast<InvocationState *>(opaque);
  auto &episode = *state.resources.get();
  if (episode.remaining.fetch_sub(1, std::memory_order_acq_rel) != 1) return;
  Status terminal;
  {
    std::lock_guard guard(episode.lock);
    terminal = episode.first_error;
  }
  // All accepted children have actually released their guards. Finish every
  // resource mutation before making the original invocation idle/failed.
  if (episode.accepted) {
    auto retired = compute::Completion::completed(terminal);
    HYLE_FATAL_ASSERT(episode.batch.attach(retired).ok());
  } else {
    episode.batch = {};
  }
  episode.permissions.reset();
  const auto observation = std::exchange(episode.observation_retirement, {});
  if (episode.accepted) InvocationAccess::retire(state, terminal);
  observation.terminal(observation.state, terminal);
  observation.release(observation.state);
  // No episode access after publication: another cold call may now reuse it.
  release(&state);
}
void retain_accepted(void *opaque, std::size_t segment,
                     compute::Completion &completion) noexcept {
  auto &state = *static_cast<InvocationState *>(opaque);
  auto &episode = *state.resources.get();
  auto &node = episode.retentions[segment];
  HYLE_FATAL_ASSERT(!node.own.valid());
  episode.accepted = true;
  episode.remaining.fetch_add(1, std::memory_order_relaxed);
  node.own = {&state, &child_terminal, &release_episode};
  HYLE_FATAL_ASSERT(compute::detail::CompletionAccess::attach_retention(completion, node).ok());
}

Result<compute::ReadLease> output_storage(InvocationState &state,
    compute::ConstTensorView tensor) noexcept {
  if (state.resources) {
    const auto wanted = tensor.storage();
    HYLE_ASSIGN_OR_RETURN(const auto bytes, tensor.description().required_bytes());
    for (auto &binding : state.resources.get()->bindings) {
      if (!binding.read.valid()) continue;
      HYLE_ASSIGN_OR_RETURN(auto source, binding.read.view());
      if (source.resource() != wanted.resource() || source.native_handle() != wanted.native_handle() ||
          wanted.offset() < source.offset()) continue;
      const auto offset = wanted.offset() - source.offset();
      if (offset <= source.size() && bytes <= source.size() - offset)
        return binding.read.subview(offset, bytes);
    }
  }
  return std::unexpected(Status::FailedPrecondition(
      "graph-owned or borrowed output has no independent storage lease"));
}
} // namespace detail

GraphOutput::GraphOutput(detail::InvocationState *state,
    compute::ConstTensorView tensor) noexcept : state_(state), tensor_(tensor) {
  detail::retain(state_);
  state_->results.fetch_add(1, std::memory_order_relaxed);
}
GraphOutput::GraphOutput(const GraphOutput &other) noexcept
    : state_(other.state_), tensor_(other.tensor_) {
  if (state_) { detail::retain(state_); state_->results.fetch_add(1, std::memory_order_relaxed); }
}
GraphOutput &GraphOutput::operator=(const GraphOutput &other) noexcept {
  if (this != &other) { GraphOutput copy(other); *this = std::move(copy); }
  return *this;
}
GraphOutput::GraphOutput(GraphOutput &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)), tensor_(other.tensor_) {}
GraphOutput &GraphOutput::operator=(GraphOutput &&other) noexcept {
  if (this != &other) { reset(); state_ = std::exchange(other.state_, nullptr); tensor_ = other.tensor_; }
  return *this;
}
GraphOutput::~GraphOutput() { reset(); }
void GraphOutput::reset() noexcept {
  if (auto *state = std::exchange(state_, nullptr)) {
    state->results.fetch_sub(1, std::memory_order_release);
    detail::release(state);
  }
  tensor_ = {};
}
Result<compute::ConstTensorView> GraphOutput::tensor() const noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("graph output is empty"));
  return tensor_;
}
Result<compute::ReadLease> GraphOutput::storage_lease() const noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("graph output is empty"));
  return detail::output_storage(*state_, tensor_);
}

Status Invocation::prepare_resources(ResourceOptions options) noexcept {
  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state_));
  if (!options.allocator.valid()) return Status::InvalidArgument("graph resource allocator is invalid");
  if (state_->resources) return Status::Ok();
  const auto actual = executable();
  const auto inputs = actual.input_count(), outputs = actual.output_count();
  if (inputs > UINT32_MAX - 1 || outputs > UINT32_MAX - 1 - inputs)
    return Status::ResourceExhausted("graph resource binding capacity");
  auto allocator = options.allocator;
  if (options.resource_budget.valid()) {
    HYLE_ASSIGN_OR_RETURN(allocator, options.resource_budget.metadata_allocator());
  }
  HYLE_ASSIGN_OR_RETURN(auto uses, compute::LeaseUsePool::create({.max_batches = 1,
      .max_resources_per_batch = static_cast<std::uint32_t>(inputs + outputs + 1),
      .allocator = allocator, .resource_budget = options.resource_budget}));
  auto *episode = allocator.construct<detail::ResourceEpisode>(*state_, allocator);
  if (!episode) return Status::ResourceExhausted("graph resource episode metadata");
  detail::ResourceEpisodeOwner candidate(episode);
  episode->uses = std::move(uses);
  try {
    episode->bindings.resize(inputs);
    episode->bindings.reserve(inputs + outputs);
    episode->retentions.resize(actual.segment_count() + 1);
    for (std::size_t i = 0; i < inputs; ++i) {
      HYLE_ASSIGN_OR_RETURN(episode->bindings[i].value, actual.input_id(i));
      episode->bindings[i].input = true;
    }
    for (std::size_t i = 0; i < outputs; ++i) {
      HYLE_ASSIGN_OR_RETURN(auto ownership, actual.output_ownership(i));
      if (ownership != OutputOwnership::kCaller) continue;
      HYLE_ASSIGN_OR_RETURN(auto value, actual.output_id(i));
      if (std::none_of(episode->bindings.begin(), episode->bindings.end(),
                       [&](const auto &binding) { return binding.value == value; }))
        episode->bindings.push_back({.value = value});
    }
  } catch (...) { return Status::ResourceExhausted("graph fixed resource metadata"); }
  state_->resources = std::move(candidate);
  return Status::Ok();
}
Status Invocation::bind(ValueId value, compute::TensorDesc description,
                        compute::ReadLease lease) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto *episode, detail::require_resources(state_));
  (void)episode;
  auto *binding = detail::find_binding(state_, value);
  if (!binding || !binding->input) return Status::InvalidArgument("read lease must bind a graph input");
  HYLE_ASSIGN_OR_RETURN(auto tensor, lease.tensor(description));
  HYLE_RETURN_IF_ERROR(bind(value, tensor));
  binding->read = std::move(lease); binding->description = description;
  binding->exclusive = false; binding->permissionless = false; binding->borrowed = false;
  return Status::Ok();
}
Status Invocation::bind(ValueId value, compute::TensorDesc description,
                        compute::WriteLease &&lease) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto *episode, detail::require_resources(state_));
  (void)episode;
  auto *binding = detail::find_binding(state_, value);
  if (!binding) return Status::InvalidArgument("write lease must bind an external graph value");
  HYLE_ASSIGN_OR_RETURN(auto tensor, lease.tensor(description));
  HYLE_RETURN_IF_ERROR(bind(value, tensor));
  binding->write = std::move(lease); binding->description = description;
  binding->exclusive = true; binding->permissionless = false; binding->borrowed = false;
  return Status::Ok();
}
Result<compute::Completion> detail::RegionAccess::submit(Invocation &invocation,
    std::span<const QueueBinding> queues, OrderedGraphSubmission ordered) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto *episode, require_resources(state));
  if (bool(ordered.admit) != bool(ordered.map) ||
      bool(ordered.admit) != bool(ordered.pending_input) || (ordered.admit && !ordered.owner))
    return std::unexpected(Status::InvalidArgument("ordered graph submission requires admission and mapping"));
  for (auto &binding : episode->bindings) {
    if (binding.exclusive && binding.read.valid()) {
      HYLE_ASSIGN_OR_RETURN(binding.write, binding.read.try_write());
    }
  }
  HYLE_ASSIGN_OR_RETURN(auto batch, episode->uses.begin());
  auto &permissions = episode->permissions;
  permissions.reset();
  for (const auto &binding : episode->bindings) {
    if (binding.borrowed || binding.permissionless) continue;
    if (!binding.exclusive && !binding.read.valid() && binding.input &&
        ordered.pending_input && ordered.pending_input(ordered.owner, binding.value)) continue;
    if (permissions.enabled()) {
      HYLE_RETURN_IF_ERROR(binding.exclusive ? permissions.add(binding.write) : permissions.add(binding.read));
    } else {
      HYLE_RETURN_IF_ERROR(binding.exclusive ? batch.write(binding.write) : batch.read(binding.read));
    }
  }
  if (permissions.enabled()) HYLE_RETURN_IF_ERROR(permissions.admit(batch));
  HYLE_ASSIGN_OR_RETURN(auto cursor, SubmissionCursor::begin(invocation, queues));
  episode->observation_retirement = state->observation.reserve_retirement();
  {
    std::lock_guard guard(episode->lock);
    episode->first_error = Status::Ok(); episode->accepted = false;
    episode->batch = std::move(batch);
    episode->remaining.store(1, std::memory_order_relaxed);
    retain(state);
  }
  struct Admission final { InvocationState *state; OrderedGraphSubmission ordered; } admission{state, ordered};
  const SharedSequenceFn before = ordered.admit ? +[](void *opaque, ExecutionLaneId lane,
      compute::detail::QueueSequence &sequence) noexcept -> Status {
    auto &call = *static_cast<Admission *>(opaque);
    return call.ordered.admit(call.ordered.owner, lane, sequence, call.state->resources.get()->batch);
  } : nullptr;
  while (!cursor.done()) {
    auto advanced = cursor.advance(true, &retain_accepted, state, before, &admission);
    if (!advanced) cursor.reject_successors(std::move(advanced).error());
  }
  record_error(*episode, cursor.submission_error());
  auto completion = cursor.finish(true);
  if (completion) {
    if (ordered.map) *completion = ordered.map(ordered.owner, std::move(*completion));
    retain_accepted(state, episode->retentions.size() - 1, *completion);
  } else {
    record_error(*episode, completion.error());
  }
  release_episode(state); // Admission sentinel; accepted guards own actual retirement.
  if (!completion) return std::unexpected(std::move(completion).error());
  return state->observation.publish(std::move(*completion), true);
}

Result<GraphOutput> Invocation::result(ValueId value) noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("graph invocation is empty"));
  HYLE_ASSIGN_OR_RETURN(auto tensor, output(value));
  if (state_->resources) {
    for (auto &binding : state_->resources.get()->bindings) {
      if (binding.write.valid()) {
        HYLE_ASSIGN_OR_RETURN(binding.read, binding.write.publish());
      }
    }
  }
  return GraphOutput(state_, tensor);
}
Status Invocation::close() noexcept {
  if (!state_) return Status::Ok();
  state_->closed = true;
  return in_flight() ? Status::Unavailable("graph invocation still has native work") : Status::Ok();
}
Status Invocation::drain() noexcept {
  if (!state_) return Status::Ok();
  close().IgnoreError();
  auto terminal = state_->observation.wait();
  auto phase = state_->phase.load(std::memory_order_acquire);
  while (phase == detail::InvocationPhase::kRunning) {
    state_->phase.wait(phase, std::memory_order_acquire);
    phase = state_->phase.load(std::memory_order_acquire);
  }
  if (state_->resources) {
    auto &episode = *state_->resources.get();
    std::lock_guard guard(episode.lock);
    terminal.Update(episode.first_error);
  }
  return terminal;
}
} // namespace hyle::graph
