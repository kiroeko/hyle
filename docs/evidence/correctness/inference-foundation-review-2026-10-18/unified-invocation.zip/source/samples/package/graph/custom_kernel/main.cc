#include "kernel.h"

#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <span>
#include <string>
#include <utility>

#include <hyle/graph/cpu.h>
#include <hyle/graph/executable.h>
#include <hyle/mem/buffer.h>

namespace {

// This second journey exercises the public domain API through the same source,
// static and shared package boundaries; it does not use a private Provider SPI.
hyle::Status bounded_normalization() {
  using namespace hyle::compute;
  using namespace hyle::graph;
  HYLE_ASSIGN_OR_RETURN(auto context, hyle::graph::cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto builder, GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto rows, builder.dimension({0, 4, 1}));
  HYLE_ASSIGN_OR_RETURN(
      auto spec,
      TensorSpec::dense(DataType::kFloat32,
                        std::array{Dimension(rows), Dimension::fixed(4)}));
  HYLE_ASSIGN_OR_RETURN(auto input, builder.input(spec));
  HYLE_ASSIGN_OR_RETURN(auto output, builder.add(RmsNorm{}, spec, input));
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  const std::array one_row{ShapeBinding{rows, 1}};
  const std::array variants{ExactShapeVariant{one_row}};
  HYLE_ASSIGN_OR_RETURN(
      auto compiled,
      compile(graph, context,
              {.shape_policy = CompileShapePolicy::kDeclaredDomain,
               .exact_variants = variants,
               .compiled_storage = {.max_bytes = 1024 * 1024},
               .compilation_storage =
                   CompilationStorageLimits{.max_resident_bytes = 1024 * 1024,
                                            .max_peak_bytes = 2 * 1024 * 1024},
               .invocation_storage =
                   InvocationStorageLimits{.max_bytes = 1024 * 1024}}));
  if (!compiled.executable.is_shape_domain() ||
      !compiled.report.is_shape_domain() ||
      compiled.executable.specialization().valid())
    return hyle::Status::Internal("domain report has an exact signature");
  HYLE_ASSIGN_OR_RETURN(auto exact_report, compiled.report.exact_variant(0));
  HYLE_ASSIGN_OR_RETURN(auto exact_route, compiled.executable.exact_variant(0));
  if (compiled.report.exact_variant_count() != 1 ||
      compiled.executable.exact_variant_count() != 1 ||
      exact_report.specialization() != exact_route.specialization() ||
      compiled.report.total_search().placement_attempts <=
          compiled.report.search().placement_attempts)
    return hyle::Status::Internal("finite variant report is incomplete");
  const auto storage = compiled.report.total_compiled_storage();
  const auto general_storage = compiled.report.compiled_storage();
  const auto exact_storage = exact_report.compiled_storage();
  if (!storage.total_bytes() || *storage.total_bytes() > 1024 * 1024 ||
      storage.known_bytes() !=
          general_storage.known_bytes() + exact_storage.known_bytes())
    return hyle::Status::Internal("compiled storage report is incomplete");
  const auto compilation = compiled.report.compilation_storage();
  const auto exact_compilation = exact_report.compilation_storage();
  if (!compilation || !exact_compilation || compilation->resident_bytes == 0 ||
      compilation->resident_bytes > 1024 * 1024 ||
      compilation->peak_bytes > 2 * 1024 * 1024 ||
      compilation->peak_bytes < compilation->resident_bytes ||
      compilation->has_unknown_storage ||
      exact_compilation->resident_bytes != compilation->resident_bytes ||
      exact_compilation->peak_bytes != compilation->peak_bytes)
    return hyle::Status::Internal("compilation storage report is incomplete");
  graph = {};
  HYLE_ASSIGN_OR_RETURN(auto source, hyle::mem::Buffer::create(
                                         hyle::mem::system_resource(), 64, 64));
  HYLE_ASSIGN_OR_RETURN(
      auto destination,
      hyle::mem::Buffer::create(hyle::mem::system_resource(), 64, 64));
  std::array<float, 16> values;
  values.fill(1.0F);
  HYLE_RETURN_IF_ERROR(source.view().write(std::as_bytes(std::span(values))));
  for (std::int64_t count : {0, 1, 4}) {
    const std::array shape{ShapeBinding{rows, count}};
    HYLE_ASSIGN_OR_RETURN(auto run,
                          compiled.executable.create_invocation({.shape = shape}));
    const auto run_storage = compiled.executable.invocation_storage_usage();
    const auto shared_storage = exact_route.invocation_storage_usage();
    if (!run_storage || !shared_storage || run_storage->live_bytes == 0 ||
        run_storage->live_bytes != shared_storage->live_bytes ||
        run_storage->live_bytes > run_storage->limit_bytes ||
        run_storage->has_unknown_storage)
      return hyle::Status::Internal("invocation storage budget is incomplete");
    if (run.exact_variant_index().has_value() != (count == 1) ||
        run.executable().is_shape_domain() != (count != 1))
      return hyle::Status::Internal("finite variant selected the wrong route");
    HYLE_ASSIGN_OR_RETURN(auto binding, run.specialization().binding());
    if (binding != shape[0])
      return hyle::Status::Internal("domain instance has the wrong shape");
    HYLE_ASSIGN_OR_RETURN(
        auto description,
        TensorDesc::dense(DataType::kFloat32,
                          std::array{count, std::int64_t{4}}));
    HYLE_ASSIGN_OR_RETURN(auto in,
                          ConstTensorView::create(description, source.view()));
    HYLE_ASSIGN_OR_RETURN(auto out,
                          TensorView::create(description, destination.view()));
    HYLE_RETURN_IF_ERROR(run.bind(input, in));
    HYLE_RETURN_IF_ERROR(run.bind(output, out));
    for (int repeat = 0; repeat < 3; ++repeat) {
      HYLE_ASSIGN_OR_RETURN(auto completion, run.submit(queue));
      HYLE_RETURN_IF_ERROR(completion.wait());
    }
    std::array<float, 16> result{};
    HYLE_RETURN_IF_ERROR(out.storage().read(std::as_writable_bytes(
        std::span(result).first(static_cast<std::size_t>(count * 4)))));
    for (std::int64_t i = 0; i < count * 4; ++i)
      if (std::abs(result[static_cast<std::size_t>(i)] -
                   1.0F / std::sqrt(1.0F + RmsNorm{}.epsilon)) > 1.0e-5F)
        return hyle::Status::Internal("domain normalization output mismatch");
  }
  return hyle::Status::Ok();
}

// Exact and declared-domain ViewSpec lowering use the same public symbols in
// all three deliveries. Only Copy materializes; views retain true strides.
hyle::Status symbolic_views(hyle::graph::CompileShapePolicy policy) {
  using namespace hyle::compute;
  using namespace hyle::graph;
  HYLE_ASSIGN_OR_RETURN(auto context, hyle::graph::cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto builder, GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto rows, builder.dimension({1, 8, 1}));
  HYLE_ASSIGN_OR_RETURN(auto offset, builder.dimension({0, 8, 1}));
  HYLE_ASSIGN_OR_RETURN(
      auto end, builder.dimension_sum(Dimension(offset), Dimension::fixed(1)));
  HYLE_RETURN_IF_ERROR(
      builder.require_dimension_less_equal(Dimension(end), Dimension(rows)));
  HYLE_ASSIGN_OR_RETURN(
      auto input_spec,
      TensorSpec::dense(DataType::kFloat32,
                        std::array{Dimension(rows), Dimension::fixed(4)}));
  HYLE_ASSIGN_OR_RETURN(auto input, builder.input(input_spec));
  HYLE_ASSIGN_OR_RETURN(
      auto slice, ViewSpec::slice(0, Dimension(offset), Dimension::fixed(1)));
  HYLE_ASSIGN_OR_RETURN(auto sliced, builder.add(slice, input));
  HYLE_ASSIGN_OR_RETURN(auto permute,
                        ViewSpec::permute(std::array<std::int32_t, 2>{1, 0}));
  HYLE_ASSIGN_OR_RETURN(auto transposed, builder.add(permute, sliced));
  const std::array expanded_shape{Dimension::fixed(4), Dimension::fixed(2)};
  HYLE_ASSIGN_OR_RETURN(auto broadcast, ViewSpec::broadcast_to(expanded_shape));
  HYLE_ASSIGN_OR_RETURN(auto expanded, builder.add(broadcast, transposed));
  HYLE_ASSIGN_OR_RETURN(auto copied_spec,
                        TensorSpec::dense(DataType::kFloat32, expanded_shape));
  HYLE_ASSIGN_OR_RETURN(auto copied,
                        builder.add(Copy{}, copied_spec, expanded));
  HYLE_ASSIGN_OR_RETURN(auto flatten,
                        ViewSpec::reshape(std::array{Dimension::fixed(8)}));
  HYLE_ASSIGN_OR_RETURN(auto output, builder.add(flatten, copied));
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  HYLE_ASSIGN_OR_RETURN(auto slice_node, graph.producer(sliced));
  HYLE_ASSIGN_OR_RETURN(auto kind, graph.operation_kind(slice_node));
  HYLE_ASSIGN_OR_RETURN(const auto &logical, graph.view_spec(slice_node));
  if (kind != OperationKind::kView || !logical.is_symbolic() ||
      logical.start() != Dimension(offset) || graph.operation(slice_node))
    return hyle::Status::Internal("logical ViewSpec introspection mismatch");
  const std::array bindings{ShapeBinding{rows, 3}, ShapeBinding{offset, 1}};
  const bool domain = policy == CompileShapePolicy::kDeclaredDomain;
  HYLE_ASSIGN_OR_RETURN(
      auto compiled,
      compile(graph, context,
              {.shape = domain ? std::span<const ShapeBinding>{} : bindings,
               .shape_policy = policy}));
  graph = {};
  HYLE_ASSIGN_OR_RETURN(auto run,
                        compiled.executable.create_invocation(
                            {.shape = domain ? std::span<const ShapeBinding>(bindings)
                                             : std::span<const ShapeBinding>{}}));
  HYLE_ASSIGN_OR_RETURN(auto source, hyle::mem::Buffer::create(
                                         hyle::mem::system_resource(), 48, 64));
  const std::array values{0.F, 1.F, 2.F, 3.F, 4.F,  5.F,
                          6.F, 7.F, 8.F, 9.F, 10.F, 11.F};
  HYLE_RETURN_IF_ERROR(source.view().write(std::as_bytes(std::span(values))));
  HYLE_ASSIGN_OR_RETURN(
      auto description,
      TensorDesc::dense(DataType::kFloat32, std::array<std::int64_t, 2>{3, 4}));
  HYLE_ASSIGN_OR_RETURN(auto tensor,
                        ConstTensorView::create(description, source.view()));
  HYLE_RETURN_IF_ERROR(run.bind(input, tensor));
  for (int repeat = 0; repeat < 3; ++repeat) {
    HYLE_ASSIGN_OR_RETURN(auto done, run.submit(queue));
    HYLE_RETURN_IF_ERROR(done.wait());
    HYLE_ASSIGN_OR_RETURN(auto result, run.output(output));
    std::array<float, 8> actual{};
    HYLE_RETURN_IF_ERROR(
        result.storage().read(std::as_writable_bytes(std::span(actual))));
    if (actual != std::array{4.F, 4.F, 5.F, 5.F, 6.F, 6.F, 7.F, 7.F})
      return hyle::Status::Internal("symbolic View graph output mismatch");
  }
  return hyle::Status::Ok();
}

} // namespace

int main() {
  using namespace hyle::compute;
  auto provider = example::make_provider();
  if (!provider)
    return 1;
  auto context =
      Context::create(hyle::compute::cpu::device(), std::move(*provider));
  if (!context)
    return 2;
  auto queue = context->create_queue();
  auto desc =
      TensorDesc::dense(DataType::kFloat32, std::array<std::int64_t, 1>{4});
  auto source = hyle::mem::Buffer::create(hyle::mem::system_resource(), 16, 64);
  auto target = hyle::mem::Buffer::create(hyle::mem::system_resource(), 16, 64);
  if (!queue || !desc || !source || !target)
    return 3;
  const std::array<float, 4> values{1, 2, 3, 4};
  if (!source->view().write(std::as_bytes(std::span(values))).ok())
    return 4;
  auto input = ConstTensorView::create(*desc, source->view());
  auto output = TensorView::create(*desc, target->view());
  if (!input || !output)
    return 5;
  const auto operation = Operation::custom(example::Affine{3});
  auto prepared =
      prepare(*context, operation, std::array{*input}, std::array{*output});
  if (!prepared) {
    const auto message = prepared.error().message();
    std::fprintf(stderr, "custom prepare: %.*s\n",
                 static_cast<int>(message.size()), message.data());
    return 6;
  }
  auto invocation = prepared->create_invocation();
  if (!invocation)
    return 7;
  auto done = invocation->submit(*queue, *input, *output);
  if (!done || !done->wait().ok())
    return 8;
  std::array<float, 4> actual{};
  if (!target->view().read(std::as_writable_bytes(std::span(actual))).ok() ||
      actual != std::array<float, 4>{5, 7, 9, 11})
    return 9;

  auto builder = hyle::graph::GraphBuilder::create();
  if (!builder)
    return 10;
  auto in = builder->constant(*desc);
  if (!in)
    return 11;
  auto out = builder->add(operation, *in);
  if (!out || !builder->publish(*out).ok())
    return 12;
  auto graph = std::move(*builder).finish();
  if (!graph)
    return 13;
  const auto family = context->provider_identity(0);
  const auto instance = context->provider_instance_id(0);
  const auto node = graph->node_id(0);
  if (!family || !instance || !node)
    return 14;
  const std::array allowed{family->id};
  const std::array required{
      hyle::graph::NodeProviderConstraint{*node, family->id, *instance}};
  const std::array constants{hyle::graph::ConstantBinding{
      *in, *input, hyle::graph::ConstantPolicy::kMaterialize}};
  auto compiled = hyle::graph::compile(*graph, *context,
                                       {.constants = constants,
                                        .allowed_providers = allowed,
                                        .node_providers = required,
                                        .max_operation_proposals = 1});
  if (!compiled || compiled->report.search().operation_proposals != 1 ||
      compiled->report.search().placement_attempts != 1 ||
      compiled->report.search().optimization_limited())
    return 14;
  if (!source->reset().ok() ||
      compiled->report.borrowed_constant_count() != 0 ||
      compiled->report.materialized_constant_bytes() != 16)
    return 19;
  const std::string provider_name(compiled->report.provider().name);
  const std::string provider_version(compiled->report.provider().version);
  auto run = compiled->executable.create_invocation();
  if (!run || !run->bind(*out, *output).ok())
    return 15;
  compiled->executable = {}; // Invocation retains the kernel/factory owner.
  for (int repeat = 0; repeat < 3; ++repeat) {
    auto complete = run->submit(*queue);
    if (!complete || !complete->wait().ok())
      return 16;
    if (!target->view().read(std::as_writable_bytes(std::span(actual))).ok() ||
        actual != std::array<float, 4>{5, 7, 9, 11})
      return 17;
  }
  // Diagnostic reports own their text, not the factory or execution resources.
  *done = {};
  *invocation = {};
  *prepared = {};
  *run = {};
  *queue = {};
  *context = {};
  if (compiled->report.provider().name != provider_name ||
      compiled->report.step(0)->provider.version != provider_version ||
      compiled->report.step(0)->implementation !=
          hyle::compute::ProviderImplementationId{1} ||
      compiled->report.constant()->policy !=
          hyle::graph::ConstantPolicy::kMaterialize)
    return 18;
  const auto bounded = bounded_normalization();
  if (!bounded.ok()) {
    const auto message = bounded.message();
    std::fprintf(stderr, "bounded graph: %.*s\n",
                 static_cast<int>(message.size()), message.data());
    return 22;
  }
  for (auto policy : {hyle::graph::CompileShapePolicy::kExact,
                      hyle::graph::CompileShapePolicy::kDeclaredDomain}) {
    const auto views = symbolic_views(policy);
    if (!views.ok()) {
      const auto message = views.message();
      std::fprintf(stderr, "symbolic views: %.*s\n",
                   static_cast<int>(message.size()), message.data());
      return 23;
    }
  }
  return 0;
}
