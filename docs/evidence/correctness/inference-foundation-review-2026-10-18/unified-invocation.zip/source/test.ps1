param([switch]$Mac, [switch]$MoveRowController, [switch]$UnifyGraphResources)
# Reclaim frozen probe images; retain source, logs, data, all objects and SDKs.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if ($UnifyGraphResources) {
    $source = [IO.Path]::GetFullPath((Join-Path $workspace 'src/graph/leased_invocation.cc'))
    $destination = [IO.Path]::GetFullPath((Join-Path $workspace 'src/graph/resources.cc'))
    $header = [IO.Path]::GetFullPath((Join-Path $workspace 'include/hyle/graph/leased_invocation.h'))
    $archive = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/invocation-resources/removed-apis/leased_invocation.h'))
    foreach ($path in @($source, $destination, $header, $archive)) {
        if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Graph migration outside workspace' }
        $ancestor = [IO.Path]::GetDirectoryName($path)
        while ($ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            if ((Test-Path -LiteralPath $ancestor) -and ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected migration directory link' }
            $ancestor = [IO.Path]::GetDirectoryName($ancestor)
        }
    }
    foreach ($entry in @(
        @{Path=$source;Bytes=38169;SHA='EE5E7498A920B96ADC3C3BBC3753FCFF38DF12108CDFC84AF407C6B1D4752AB1'},
        @{Path=$header;Bytes=4694;SHA='D64ADB7098C5C92740540625C9DCC002F69C68413F5C0F93C59580F9B40AEDF1'}
    )) {
        $item = Get-Item -LiteralPath $entry.Path
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $entry.Bytes -or
            (Get-FileHash -LiteralPath $entry.Path -Algorithm SHA256).Hash -ne $entry.SHA) { throw 'Graph API source changed; review before migration' }
    }
    if ((Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath $archive)) { throw 'Graph migration destination already exists' }
    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($archive)) -Force | Out-Null
    Copy-Item -LiteralPath $header -Destination $archive
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne 'D64ADB7098C5C92740540625C9DCC002F69C68413F5C0F93C59580F9B40AEDF1') { throw 'Removed API archive identity mismatch' }
    Move-Item -LiteralPath $source -Destination $destination
    Remove-Item -LiteralPath $header
    Write-Output 'Unified Graph resource source renamed; replaced public API removed. Historical header preserved within workspace.'
    return
}
if ($MoveRowController) {
    $source = (Resolve-Path -LiteralPath (Join-Path $workspace 'src/compute_ggml_runtime/row_cache_native_controller.h')).Path
    $destination = [IO.Path]::GetFullPath((Join-Path $workspace 'src/compute_batch/row_cache_native_controller.h'))
    foreach ($path in @($source, $destination)) {
        if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Source move outside workspace' }
    }
    $destinationParent = (Resolve-Path -LiteralPath ([IO.Path]::GetDirectoryName($destination))).Path
    if ((Get-Item -LiteralPath $destinationParent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected destination link' }
    if (Test-Path -LiteralPath $destination) { throw 'Source destination already exists' }
    $item = Get-Item -LiteralPath $source
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or $item.Length -ne 8923 -or
        (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne '7B05BE4D10455F6528C4A0784F4B444A82293CF90209AED624481EBC92D58455') {
        throw 'Source controller changed; review before moving'
    }
    Move-Item -LiteralPath $source -Destination $destination
    Write-Output 'Moved typed row/page controller to its owning compute_batch module; no source deleted.'
    return
}
$stage = Join-Path $workspace '.scratch/inference-foundation-review-2026-10-18'
$plan = Get-Content -LiteralPath (Join-Path $stage 'archive-cleanup/review-binaries.json') -Raw | ConvertFrom-Json
$allowed = @(
    (Join-Path $stage 'row-cache-indexer-native'),
    (Join-Path $stage 'cpu-grouped-expert-reuse'),
    (Join-Path $stage 'paged-indexer'),
    (Join-Path $stage 'cuda-row-cache-padded'),
    (Join-Path $stage 'cuda-row-cache-indexer'),
    (Join-Path $stage 'packed-indexer-cpu')
) | ForEach-Object { (Resolve-Path -LiteralPath $_).Path }
foreach ($directory in $allowed) {
    if (-not $directory.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Stage outside workspace' }
    if ((Get-Item -LiteralPath $directory).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected stage link' }
}
foreach ($archive in $plan.archives) {
    $path = Join-Path $workspace ('docs/evidence/correctness/inference-foundation-review-2026-10-18/' + $archive.name)
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $archive.sha256) { throw 'Archive identity mismatch' }
}
foreach ($entry in $plan.retain) {
    $path = [IO.Path]::GetFullPath($entry.path)
    if ([IO.Path]::GetDirectoryName($path) -notin $allowed -or [IO.Path]::GetExtension($path) -notin @('.obj','.o')) { throw 'Unexpected retained object' }
    $item = Get-Item -LiteralPath $path
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or $item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Changed retained object: $path" }
}
$targets = foreach ($entry in $plan.files) {
    $path = [IO.Path]::GetFullPath($entry.path)
    $parent = [IO.Path]::GetDirectoryName($path)
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($parent -notin $allowed -or $extension -notin @('.exe','.lib','.exp','.pdb')) { throw "Unexpected target: $path" }
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside workspace' }
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $item = Get-Item -LiteralPath $path
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected file link: $path" }
        if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Changed artifact: $path" }
        $item
    }
}
$freed = 0L
foreach ($item in $targets) {
    $freed += $item.Length
    Remove-Item -LiteralPath $item.FullName
}
Write-Output "Removed $($targets.Count) frozen probe binaries: $freed bytes. All objects, SDKs and source/results retained."
if ($Mac) {
    $manifestPath = Join-Path $stage 'archive-cleanup/mac-review-binaries.json'
    $macPlan = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    foreach ($archive in $macPlan.archives) {
        $path = Join-Path $workspace ('docs/evidence/correctness/inference-foundation-review-2026-10-18/' + $archive.name)
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $archive.sha256) { throw 'Mac archive identity mismatch' }
    }
    $encoded = [Convert]::ToBase64String([IO.File]::ReadAllBytes($manifestPath))
    $remoteScript = @'
import base64, hashlib, json
from pathlib import Path
plan = json.loads(base64.b64decode('__MANIFEST__'))
base = Path('/Users/kiro/hyle-scratch/compute-unified').resolve(strict=True)
roots = {Path(p).resolve(strict=True) for p in plan['roots']}
assert all(p.parent == base for p in roots)
targets = []
for record in plan['files']:
    path = Path(record['path'])
    assert path.parent.resolve(strict=True) in roots
    assert path.suffix == '' and not path.is_symlink()
    if not path.exists():
        continue
    assert path.is_file() and path.resolve(strict=True).parent in roots
    assert path.stat().st_size == record['bytes'], str(path)
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == record['sha256'], str(path)
    assert data[:4] in (bytes.fromhex('cffaedfe'), bytes.fromhex('feedfacf')), str(path)
    targets.append((path, record['bytes']))
for record in plan['retain']:
    path = Path(record['path'])
    assert path.is_file() and path.stat().st_size == record['bytes'], str(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256'], str(path)
for path, size in targets:
    path.unlink()
print(json.dumps({'removed': len(targets), 'bytes': sum(size for path,size in targets),
    'retained_product_and_test_objects': len(plan['retain']), 'retained_source_logs_maps_sdk': True}))
'@
    $remoteScript.Replace('__MANIFEST__', $encoded) | & ssh -o BatchMode=yes -o ConnectTimeout=10 kiro@172.22.10.198 'python3 -'
    if ($LASTEXITCODE -ne 0) { throw 'Mac cleanup verification failed' }
}
