import build

for source, name in [
    ('samples/package/graph/resource_leases/main.cc', 'sample-resources'),
    ('samples/package/graph/custom_kernel/main.cc', 'sample-custom-kernel'),
]:
    build.driver.run(name + '-compile', [build.driver.cc[0], *build.driver.flags,
        '/DHYLE_COMPUTE_CPU=1', build.ROOT / source,
        '/Fo' + str(build.OUT / (name + '.obj'))])
