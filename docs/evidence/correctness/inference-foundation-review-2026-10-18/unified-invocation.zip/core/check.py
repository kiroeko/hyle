from pathlib import Path
import json
import os

import build

ROOT, OUT = build.ROOT, build.OUT
base = ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/projected-reader-test/commands.json'
args = next(row['command'] for row in reversed(json.loads(base.read_text()))
            if row['tag'] == 'projected-link')
core = {
    'executable.obj': OUT / 'executable.obj',
    'graph-executable.obj': OUT / 'executable.obj',
    'constant_artifact.obj': OUT / 'constant_artifact.obj',
    'graph-constant_artifact.obj': OUT / 'constant_artifact.obj',
    'leased_invocation.obj': OUT / 'resources.obj',
    'graph-leased_invocation.obj': OUT / 'resources.obj',
    'lease_submission.obj': OUT / 'lease_submission.obj',
    'graph-lease_submission.obj': OUT / 'lease_submission.obj',
    'region_access.obj': OUT / 'region_access.obj',
    'region_provider_test.obj': OUT / 'region_provider_test.obj',
}
fresh = []
for arg in args:
    name = Path(arg).name.lower()
    if name in ('graph-batch.obj', 'hyle_graph_batch.lib'):
        continue
    if arg.upper().startswith('/OUT:'):
        fresh.append('/OUT:' + str(OUT / 'core-controls.exe'))
    elif arg.upper().startswith('/MAP:'):
        fresh.append('/MAP:' + str(OUT / 'core-controls.map'))
    elif name in core:
        fresh.append(str(core[name]))
    else:
        fresh.append(arg)
build.driver.run('core-link', fresh)

runtime = next(ROOT.glob('.scratch/build-compute-v2-dev/bin/hyle_compute_route_cpu_test.exe'), None)
torch = next((Path(p) for p in fresh if Path(p).name.lower() == 'torch_cpu.lib'), None)
if torch:
    os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
build.driver.run('core-controls', [OUT / 'core-controls.exe', '--gtest_color=no',
    '--gtest_filter=GraphRegions.RawBindingsAndOwnedResultsUseTheSameInvocationGate:'
    'GraphRegions.InvocationRetainsItsCompiledRegionAndWorkspaceOwner:'
    'GraphRegions.OrderedSequenceDoesNotHostWaitAndRetainsInvocationUntilTerminal:'
    'GraphRegions.RejectedTailIsReportedAfterTheAcceptedAsyncPrefix:'
    'GraphRegions.AbandonedAggregateRetainsEveryIndependentSink:'
    'GraphRouteBoundary.ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort'])
