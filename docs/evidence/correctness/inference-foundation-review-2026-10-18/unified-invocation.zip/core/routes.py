from pathlib import Path
import json
import build

ROOT, OUT = build.ROOT, build.OUT
records = json.loads((ROOT / '.scratch/inference-foundation-review-2026-10-18/hybrid-weight-dependencies/commands.json').read_text())
base = next(row['command'] for row in reversed(records) if row['tag'] == 'joint-compile-compile')
flags = [arg for arg in base[1:] if not arg.lower().startswith(('/fo', '/tp')) and not arg.endswith('.cc')]
for source, name in [('src/graph_route_cpu/cpu_context.cc', 'cpu-context'),
                     ('src/graph_route_cuda/cuda_context.cc', 'cuda-context'),
                     ('src/graph_route_cpu_cuda/compile.cc', 'joint-compile')]:
    build.driver.run(name + '-compile', [base[0], *flags,
        '/Tp' + str(ROOT / source), '/Fo' + str(OUT / (name + '.obj'))])
