from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/unified-invocation.zip'
assert not DEST.exists(), 'Review an existing evidence archive before replacing it'

def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

sources = set(json.loads((ROOT / '.scratch/compute-execution-refactor-2026-10-18/invocation-consumer-unify/migration-files.json').read_text()))
sources.update('''include/hyle/graph/executable.h
include/hyle/graph/resources.h
include/hyle/graph/result.h
include/hyle/graph/batch.h
include/hyle/graph/cpu.h
include/hyle/graph/cuda.h
include/hyle/graph/detail/region_access.h
include/hyle/graph/detail/region_adapter.h
src/graph/executable.cc
src/graph/resources.cc
src/graph/plan_state.h
src/graph/resource_episode.h
src/graph/region_access.cc
src/graph/compile_internal.h
src/graph/CMakeLists.txt
src/graph_batch/batch.cc
src/graph_batch/row_cache_node.h
src/graph_batch/row_cache_node.cc
src/graph_batch/region_adapter.h
src/graph_batch/materialized_invocation.cc
src/graph_route_cpu/cpu_context.cc
src/graph_route_cuda/cuda_context.cc
src/graph_route_cpu_cuda/compile.cc
cmake/HyleComponents.cmake
samples/package/graph/resource_leases/main.cc
samples/package/graph/batched_transfers/main.cc
samples/package/graph/file_streaming/main.cc
samples/package/graph/file_streaming/qwen_main.cc
samples/package/graph/custom_kernel/main.cc
docs/architecture/compute-design.md
docs/developer/current-work.md
docs/user/graph.md
docs/user/compute.md
docs/user/batch-attention.md
test.ps1'''.splitlines())
source_paths = sorted({ROOT / source for source in sources})
assert all(path.is_file() for path in source_paths)
parts = [
    ROOT / '.scratch/architecture-refactor-2026-10-18/resource-episode/pending-consumers/source-results.zip',
    ROOT / '.scratch/compute-execution-refactor-2026-10-18/batch-single-invocation/source-results.zip',
    ROOT / '.scratch/compute-execution-refactor-2026-10-18/invocation-consumer-unify/source-results.zip',
]
objects = [identity(path) for path in sorted(OUT.glob('*.obj'))]
summary = dict(
    scope='One original Graph Invocation resource/result/typed-batch lifetime; old public wrappers deleted directly',
    validation=dict(core_controls=6, cpu_owned_resource_control='8 allocation-free replays and source-alias retirement',
                    cpu_pending='9 existing modes passed', cuda_pending='F16/BF16 true producer gate, full FP64 maxAbs=0',
                    hybrid='original mixed math/weights/derived constant, 2 slots/2 phases passed',
                    representative_samples='resource_leases and custom_kernel MSVC /W4 /WX compile passed'),
    limitations=['No SDK/native rebuild or broad matrix', 'Other migrated consumers not all compiled/run',
                 'Qwen and Apple/Vulkan runtime not rerun in this batch',
                 'Native-generated common values, remaining joint runtime unification, materialized Gather proof in core, and inherited model/functional gaps remain'],
    failures_preserved='Old cached host carrier closure, omitted explicit cold replay preparation, and old wrapper-specific closed-context error expectation are kept with their corrections',
    sources=[identity(path) for path in source_paths], parts=[identity(path) for path in parts], objects=objects)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in source_paths:
        archive.write(path, 'source/' + path.relative_to(ROOT).as_posix())
    for path in sorted(OUT.rglob('*')):
        if path.is_file() and path.suffix in ('.py', '.json', '.log', '.h', '.map'):
            archive.write(path, 'core/' + path.relative_to(OUT).as_posix())
    for path in parts:
        archive.write(path, 'parts/' + path.parent.name + '.zip')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert all(Path(name).suffix.lower() not in ('.obj', '.exe', '.lib', '.exp', '.pdb') for name in archive.namelist())
receipt = identity(DEST)
(OUT / 'archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
