#pragma once
#include <cstddef>
extern "C" void hyle_grouped_bytes(bool four, int stage, std::size_t bytes);
