#include "counts.h"
#include <atomic>
#include <cstdio>
namespace {
struct Counts {
  std::atomic<std::size_t> peak[2][2]{};
  std::atomic<std::size_t> calls[2][2]{};
  ~Counts() {
    for(int kind=0;kind<2;++kind)
      std::printf("GROUPED_BYTES fp%d selected_bank_max=%zu selected_block_max=%zu bank_calls=%zu block_calls=%zu\n",
          kind?4:8,peak[kind][0].load(),peak[kind][1].load(),calls[kind][0].load(),calls[kind][1].load());
  }
} counts;
}
extern "C" void hyle_grouped_bytes(bool four, int stage, std::size_t bytes) {
  auto &peak=counts.peak[four][stage];auto old=peak.load();
  while(old<bytes&&!peak.compare_exchange_weak(old,bytes)) {}
  ++counts.calls[four][stage];
}
