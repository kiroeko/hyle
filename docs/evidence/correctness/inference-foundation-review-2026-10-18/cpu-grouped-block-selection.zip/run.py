from pathlib import Path
import importlib.util,json,subprocess,time,hashlib,os
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cached_cpu',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(cpu)
TORCH=Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
flags=cpu.hyle_flags(dict(cpu.PINS['mixed'],folder=Path('mixed')))+['/I'+str(ROOT),'/I'+str(ROOT/'src/compute_provider_native'),'/DHYLE_COMPUTE_TORCH_CPU=1','/external:I'+str(TORCH/'include'),'/external:I'+str(TORCH/'include/torch/csrc/api/include')]
flags+=['/I'+str(ROOT/'third_party'/d) for d in ['torchao_cpu','bitsandbytes_cpu','awq_cpu','compressed_tensors_cpu','mlx_cpu_quant']]
env=cpu.ENV.copy();env['PATH']=str(TORCH/'lib')+os.pathsep+env['PATH'];env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
(OUT/'runtime-environment.json').write_text(json.dumps({key:env[key] for key in ['PATH','OMP_NUM_THREADS','MKL_NUM_THREADS']},indent=2)+'\n')
records=[]
def run(tag,command):
    command=list(map(str,command));start=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=180)
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-10000:],p.stderr.decode(errors='replace')[-2500:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
def compile(source,name,extra=()):
    obj=OUT/(name+'.obj');run(name+'-compile',[cpu.CL,*flags,*extra,'/Tp'+str(source),'/Fo'+str(obj)]);return obj
libs=[cpu.BASE/'bin'/name for name in ['hyle_compute_route_cpu.lib','hyle_compute_provider_native.lib','hyle_compute_provider_onednn.lib','dnnl.lib']]+cpu.common_libs()+[TORCH/'lib'/name for name in ['torch.lib','torch_cpu.lib','c10.lib']]+[cpu.BASE/'lib/gtest.lib',cpu.BASE/'lib/gtest_main.lib']
def link(name,objects):
    exe=OUT/(name+'.exe');run(name+'-link',[cpu.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),*objects,*libs,*cpu.SYSTEM]);return exe
tests=compile(ROOT/'tests/compute_provider_native/torch_cpu_test.cc','canonical-tests')
candidate=compile(ROOT/'src/compute_provider_native/torch_cpu_program.cc','product')
exe=link('canonical',[tests,candidate]);run('canonical-tests',[exe,'--gtest_filter=NativeTorchCpu.*'])
counts=compile(OUT/'counts.cc','counts')
for arm in ['before','after']:
    source=(OUT/'torch_cpu_program.cc.before').read_text() if arm=='before' else (ROOT/'src/compute_provider_native/torch_cpu_program.cc').read_text()
    source='#include "counts.h"\n'+source
    if arm=='before':
        marker='    codes = codes.index_select(0, ids).contiguous();'
        assert source.count(marker)==1
        source=source.replace(marker,marker+'\n    hyle_grouped_bytes(four, 0, codes.nbytes());',1)
        marker='                                 (block + 1) * encoded_group).contiguous();'
    else:
        marker='                              : encoded.contiguous();'
    assert source.count(marker)==1,arm
    source=source.replace(marker,marker+'\n    if (s.kind == Kind::kGrouped8 || s.kind == Kind::kGrouped4)\n      hyle_grouped_bytes(s.kind == Kind::kGrouped4, 1, encoded.nbytes());',1)
    path=OUT/('instrumented-'+arm+'.cc');path.write_text(source)
    obj=compile(path,'instrumented-'+arm,['/I'+str(OUT)])
    exe=link('instrumented-'+arm,[tests,obj,counts])
    run(arm+'-bytes-and-numerics',[exe,'--gtest_filter=NativeTorchCpu.GroupedBlocksKeepMultiTokenIdsScalesAndTailRows'])
paths=[ROOT/'src/compute_provider_native/torch_cpu_program.cc',ROOT/'tests/compute_provider_native/torch_cpu_test.cc',TORCH/'lib/torch_cpu.dll',cpu.CL]+libs
(OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
