from pathlib import Path
import difflib,hashlib,json,shutil,zipfile,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sources=['src/compute_provider_native/torch_cpu_program.cc','tests/compute_provider_native/torch_cpu_test.cc']
diff=[]
for name in sources:
    target=OUT/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
    before=OUT/(Path(name).name+'.before')
    diff.extend(difflib.unified_diff(before.read_text().splitlines(True),(ROOT/name).read_text().splitlines(True),fromfile=name+'.before',tofile=name))
(OUT/'product-and-test.diff').write_text(''.join(diff))
for name in ['tests/compute/native_context_fixture.h','tests/compute_provider_native/half_test_support.h']:
    target=OUT/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
hardware=subprocess.run(['powershell','-NoProfile','-Command','Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json -Compress'],capture_output=True,check=True)
(OUT/'hardware.json').write_bytes(hardware.stdout)
summary={
 'scope':'CPU original ATen GroupedFloat8Linear and GroupedFloat4Linear encoded-weight selection; no public API changes',
 'build':'Fresh only current torch_cpu_program.cc and complete canonical torch_cpu_test.cc plus diagnostic-only variants. Existing Windows MSVC 14.50.35717 / Torch CPU 2.8 static closure and DLL reused. No SDK rebuild.',
 'runtime_environment':{'OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2'},
 'canonical':{'filter':'NativeTorchCpu.*','passed':5,'failed':0},
 'new_case':{'name':'NativeTorchCpu.GroupedBlocksKeepMultiTokenIdsScalesAndTailRows','E':17,'T':3,'S':4,'N':129,'K':512,'activation_layouts':['A1 broadcast','AS independent'],'phases':2,'outputs':['FP8 grouped F32','FP4 grouped BF16'],'oracle':'Independent scalar FP64 decode of actual encoded weight bytes and scales; dyadic activation values with exact scale1 quantization. Exact F32 / BF16 bit equality, no tolerance expansion. All inputs/scales/weights/IDs change across phases. Duplicate high ID16 and negative/out-of-range IDs. Error leaves poisoned output unchanged.'},
 'diagnostic':{'method':'Scratch-only calls to Tensor.nbytes immediately after selected whole-bank index_select and after current encoded block materialization. Same new canonical case linked with pre-task and current adapter variants. Both PASS. Counts cover 2 activation layouts x 2 changed phases for each operator.',
   'fp8':{'before_selected_bank_max_bytes':792576,'before_current_block_bytes':198144,'after_selected_bank_max_bytes':0,'after_current_block_bytes':198144,'before_bank_calls':4,'after_bank_calls':0,'block_calls_each':16,'selected_code_max_reduction_factor':4},
   'fp4':{'before_selected_bank_max_bytes':396288,'before_current_block_bytes':24768,'after_selected_bank_max_bytes':0,'after_current_block_bytes':24768,'before_bank_calls':4,'after_bank_calls':0,'block_calls_each':64,'selected_code_max_reduction_factor':16}},
 'source_review':['Group selection now slices original borrowed bank K dimension before index_select. Only ids ownership is added privately; no host data roundtrip or persistent cache.','FP8 compact scales select current block then IDs before row128 repeat/sliceN; FP4 retains per-row scale convention.','Original activation quantizer, K-block order, scale multiplication/F32 accumulation order, output conversion, finite/ID validation and final output.copy_ remain unchanged.','No-id decode/linear expands FP8 scales through original path; non-grouped block selection remains contiguous().'],
 'limits':['Counters measure materialized selected encoded tensors, not total allocator high-water mark or all temporaries. Decoded current block, activation codes, accumulation and ATen object metadata remain.','More per-block index_select calls replace one full-K selection. No throughput claim or benchmark.','Full GLM T128/S8/N2048/K6144 was not allocated or run; source-derived FP8 selected-code bound is 12GiB whole-K to 256MiB per128 block, FP4 6GiB to32MiB per32 block.','Canonical native_context fixture selects native provider; no full-model or 22-profile execution is claimed.'],
 'reproduce':'python .scratch/inference-foundation-review-2026-10-18/cpu-grouped-block-selection/run.py (existing repo CPU cache flags and libraries required)',
 'self_review':'git diff --check on both product/test files PASS; baseline and current same new oracle case PASS; full current canonical TU compiles /W4 /WX and five tests PASS.'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[*list((OUT/'source').rglob('*')),*OUT.glob('*.py'),*OUT.glob('*.h'),*OUT.glob('*.cc'),*OUT.glob('*.before'),*OUT.glob('*.json'),*OUT.glob('*.diff'),*OUT.glob('*.log')]
files=sorted({p for p in files if p.is_file()})
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(OUT).as_posix())
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
