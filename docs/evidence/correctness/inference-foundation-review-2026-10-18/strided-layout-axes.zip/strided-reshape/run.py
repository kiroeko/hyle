from pathlib import Path
import hashlib,json,os,subprocess,sys,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
ARCH=OUT.parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
template=read(ARCH/'input-source-scratch/compile-template.json')['command']
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':template[0],'CMAKE_C_COMPILER':template[0]})
env['VSLANG']='1033'

def run(tag,cmd,expected=0,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';r=dict(tag=tag,command=list(map(str,cmd)),cwd=str(OUT),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log');rows.append(r);save('commands.json',rows)
 print('START',stem,flush=True);start=time.monotonic()
 with (OUT/r['stdout']).open('wb') as so,(OUT/r['stderr']).open('wb') as se:
  child=subprocess.Popen(r['command'],cwd=OUT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW);r['pid']=child.pid;save('commands.json',rows);r['exit']=child.wait(timeout=timeout)
 r['seconds']=time.monotonic()-start;save('commands.json',rows)
 print('END',stem,r['exit'],flush=True)
 print((OUT/r['stdout']).read_text(errors='replace')[-6000:],flush=True)
 print((OUT/r['stderr']).read_text(errors='replace')[-2000:],flush=True)
 if r['exit']!=expected:raise SystemExit(r['exit'] or 99)

def compile(source,name,flags=template):
 receipt=OUT/(name+'-identity.json')
 if receipt.exists():
  old=read(receipt)
  if ident(ROOT/source)==old['source'] and ident(old['object']['path'])==old['object']:return
 cmd=[x for x in flags if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]
 cmd += [str(ROOT/source),'/Fo'+str(OUT/(name+'.obj'))]
 before=ident(ROOT/source);run(name+'-compile',cmd);assert ident(ROOT/source)==before
 save(name+'-identity.json',dict(source=before,object=ident(OUT/(name+'.obj')),command=cmd))

def test(mode):
 compile('tests/compute_ops/view_reshape_test.cc','reshape-test')
 if mode=='candidate':
  compile('src/compute_ops/operation.cc','operation')
  compile('tests/compute_ops/operation_test.cc','operation-test')
 base=read(ARCH/'qwen-alias-source-journey/link-plan.json')['command']
 libraries=['hyle_compute_ops.lib','hyle_mem.lib','hyle_error.lib','hyle_mem_vm.lib','gtest_main.lib','gtest.lib']
 args=[base[0],'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',str(OUT/'reshape-test.obj')]
 if mode=='control':
  original=next(r for r in read(ARCH/'qwen-alias-source-journey/link-plan.json')['source_objects'] if Path(r['source']['path'])==ROOT/'src/compute_ops/operation.cc')
  assert ident(OUT/'operation.before.cc')['sha256']==original['source']['sha256']
  assert ident(original['object']['path'])==original['object']
  args.append(original['object']['path'])
 if mode=='candidate':args += [str(OUT/'operation.obj'),str(OUT/'operation-test.obj')]
 test_base=read(ARCH/'cold-placement-facts/link-plan.json')['command']
 args += [next(v for v in base+test_base if Path(v).name.lower()==lib) for lib in libraries]
 args += ['/OUT:'+str(OUT/(mode+'.exe')),'/MAP:'+str(OUT/(mode+'.map'))]
 save(mode+'-link.json',dict(command=args,inputs=[ident(x) for x in args if Path(x).suffix.lower() in {'.lib','.obj'} and Path(x).is_file()]))
 run(mode+'-link',args)
 pattern='StridedReshape.*' if mode=='control' else 'StridedReshape.*:OperationViews.*:OperationViewAlias.*:OperationMaterialization.*'
 run(mode+'-run',[OUT/(mode+'.exe'),'--gtest_color=no','--gtest_filter='+pattern,'--gtest_output=xml:'+str(OUT/(mode+'.xml'))],expected=1 if mode=='control' else 0)

if __name__=='__main__':test(sys.argv[1])
