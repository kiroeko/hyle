from pathlib import Path
import difflib,json,zipfile,xml.etree.ElementTree as ET
from run import OUT,ROOT,ARCH,read,save,ident

VK=ARCH/'vulkan-attention-dtype-axes'
STREAM=ARCH/'cuda-admitted-ggml-stream'
DEST=ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/strided-layout-axes.zip'
sources=['src/compute_ops/operation.cc','src/graph/view_domain.h',
 'tests/compute_ops/view_reshape_test.cc','tests/compute_ops/CMakeLists.txt',
 'tools/qwen35_text/main.cc','tools/qwen35_text/README.md',
 'docs/architecture/compute-design.md','docs/user/compute.md',
 'docs/developer/current-work.md',
 'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md',
 'docs/user/vulkan-compute.md','test.ps1']
assert ET.parse(OUT/'candidate.xml').getroot().attrib['tests']=='9'
assert ET.parse(OUT/'candidate.xml').getroot().attrib['failures']=='0'
assert ET.parse(OUT/'control.xml').getroot().attrib['tests']=='5'
assert ET.parse(OUT/'control.xml').getroot().attrib['failures']=='5'
assert read(VK/'summary.json')['verification']['tests']==6
assert read(VK/'summary.json')['verification']['failures']==0
pairs=read(OUT/'qwen-trace-pairs.json')
assert len(pairs)==150 and all(row['byte_equal'] for row in pairs)
for row in pairs:
 assert ident(row['original']['path'])==row['original']
 assert ident(row['candidate']['path'])==row['candidate']
 assert row['original']['sha256']==row['candidate']['sha256']
compiled=[read(OUT/name) for name in ['operation-identity.json','reshape-test-identity.json','operation-test-identity.json','consumer-identity.json']]
compiled += [read(VK/name) for name in ['batch-identity.json','region-identity.json','cache-test-identity.json','graph-test-identity.json']]
for row in compiled:
 assert ident(row['source']['path'])==row['source']
 assert ident(row['object']['path'])==row['object']
save('compiled-identities.json',compiled)
for source in sources:
 target=OUT/'current'/source;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/source).read_bytes())
save('source-identities.json',[ident(ROOT/source) for source in sources])
for old,new,label in [('operation.before.cc','src/compute_ops/operation.cc','operation'),('main.before.cc','tools/qwen35_text/main.cc','consumer')]:
 diff=difflib.unified_diff((OUT/old).read_text().splitlines(True),(ROOT/new).read_text().splitlines(True),fromfile=old,tofile=new)
 (OUT/(label+'.diff')).write_text(''.join(diff),encoding='utf-8')
selected=[]
for name in ['control.map','candidate.map','qwen.map']:
 rows=[line.rstrip() for line in (OUT/name).read_text(errors='replace').splitlines() if line.rstrip().endswith(('operation.obj','ops.obj','reshape-test.obj','operation-test.obj','consumer.obj'))]
 assert rows,name;selected += [name,*rows,'']
(OUT/'map-owners.txt').write_text('\n'.join(selected),encoding='utf-8')
images=[ident(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix in {'.exe','.map','.exp','.lib'}]
images+=read(VK/'cleanup.json')['files']
retained=[row['object'] for row in compiled]
assert len({r['path'] for r in images})==len(images)
for r in images:assert ident(r['path'])==r
save('cleanup-plan.json',dict(files=images+[r['candidate'] for r in pairs],retained_objects=retained,
 retained_trace=[r['original'] for r in pairs],retained_native=read(VK/'cleanup.json')['reused_native'],
 images=len(images),image_bytes=sum(r['bytes'] for r in images),duplicate_trace=len(pairs),duplicate_bytes=sum(r['candidate']['bytes'] for r in pairs),other_cache_retained=True))
result=dict(strided_reshape=dict(result='9/9 PASS, including 5 new logical-address cases; exact prior operation object fails all 5 new cases.',
 contract='Plain, zero-copy, contiguous stride chunks only. Preserve singleton, broadcast and byte-span semantics; gap flatten needs explicit Copy. Whole-domain reshape still requires its original dense proof.',
 hot_cost='O(rank) fixed metadata; no new allocation, dispatch cache, executor or Plan/Invocation ABI.'),
 qwen=dict(result='150/150 byte-identical, 62,785,536 bytes; full 24 layers and 320 original tensors.',
 journey='prefill T23/KV23 -> continuation T4/KV27 -> decode T1/KV28; next 20 -> 248046 -> 198.',
 graph_nodes=dict(before=1938,after=1878),copy_nodes=dict(before=85,after=25),reported_steps=dict(before=1252,after=1204),
 retained_copy='18 caller history, 6 gapped gate flatten, 1 caller final hidden.',
 workspace_bytes_per_slot=dict(T23=[4104704,4151296],T4=[1427776,1443840],T1=[933568,937536]),
 limits='Single direct trace journey, no new scheduler/platform/throughput acceptance; original independent-oracle approx 2% logits discrepancy remains. Native CONT may remain; no total memory-reduction claim.'),
 vulkan_dtype_axes=read(VK/'summary.json'),
 stream_bridge=dict(status='Read-only private implementation design only; not implemented or tested.',
 original_fact='Old T23 route used 449 ggml submit entries; current matched T23 route uses 401. Existing per-entry event bridge remains.'),
 validation_scope='8 unique small TUs in this slice; cached SDK/native host/shaders reused. No full project rebuild.',
 prior_control='Latest control links the identified original ops.obj whose source SHA matches operation.before.cc; the earlier archive-only negative run is retained as history.')
save('summary.json',result)
exclude={'.obj','.exe','.map','.lib','.exp','.zip','.pyc','.f32','.bf16'}
paths=[p for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix.lower() not in exclude]
for r in read(VK/'archive-files.json'):
 assert ident(r['path'])==r
 paths.append(Path(r['path']))
paths += [VK/'receipt.json',*sorted(STREAM.glob('*'))]
paths=list(dict.fromkeys(paths));assert not DEST.exists(),'Do not overwrite evidence'
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in paths:archive.write(p,p.relative_to(ARCH).as_posix())
receipt=dict(archive=ident(DEST),entries=len(paths),files=len(images)+len(pairs),
 bytes=sum(r['bytes'] for r in images)+sum(r['candidate']['bytes'] for r in pairs),
 retained_objects=len(retained),retained_original_trace=len(pairs))
save('archive-receipt.json',receipt)
result=dict(archive=dict(path=DEST.relative_to(ROOT).as_posix(),bytes=receipt['archive']['bytes'],sha256=receipt['archive']['sha256']),**result,
 cleanup_plan=dict(files=receipt['files'],bytes=receipt['bytes'],retained_objects=len(retained),original_trace_retained=len(pairs),script='test.ps1 -ReclaimStridedLayouts'))
DEST.with_name('strided-layout-axes-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
