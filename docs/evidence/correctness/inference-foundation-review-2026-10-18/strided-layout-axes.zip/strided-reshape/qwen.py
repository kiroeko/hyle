from pathlib import Path
import collections,csv,hashlib,json,os,sys
from run import OUT,ROOT,ARCH,read,save,ident,run,compile,env

base=read(ARCH/'qwen-alias-source-journey/link-plan.json')
fresh=read(ARCH/'qwen-alias-source-journey/consumer-identities.json')
old_consumer=next(r for r in fresh if Path(r['source']['path'])==ROOT/'tools/qwen35_text/main.cc')
old_operation=next(r for r in base['source_objects'] if Path(r['source']['path'])==ROOT/'src/compute_ops/operation.cc')
args=[v for v in base['command'] if not v.lower().startswith(('/out:','/map:','/implib:','/pdb:'))]
replacements={old_consumer['object']['path']:str(OUT/'consumer.obj'),old_operation['object']['path']:str(OUT/'operation.obj')}
args=[replacements.get(v,v) for v in args]
args += ['/OUT:'+str(OUT/'qwen.exe'),'/MAP:'+str(OUT/'qwen.map'),'/IMPLIB:'+str(OUT/'qwen.lib')]
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in args if Path(x).suffix.lower()=='.lib' and Path(x).is_absolute()))+os.pathsep+env['PATH']

def check_sources():
 before=ident(OUT/'main.before.cc')
 assert before['bytes']==old_consumer['source']['bytes'] and before['sha256']==old_consumer['source']['sha256']
 for row in base['source_objects']:
  if Path(row['source']['path']) in {ROOT/'tools/qwen35_text/main.cc',ROOT/'src/compute_ops/operation.cc'}:continue
  assert ident(row['source']['path'])==row['source'],('source drift',row['source']['path'])
  assert ident(row['object']['path'])==row['object'],('object drift',row['object']['path'])
 for row in base['checked_headers']:assert ident(row['path'])==row,('header drift',row['path'])
 for row in read(ARCH/'qwen-alias-source-journey/link-input-identities.json'):
  assert ident(row['path'])==row,('cached link drift',row['path'])
 op=read(OUT/'operation-identity.json');assert ident(op['source']['path'])==op['source'];assert ident(op['object']['path'])==op['object']

mode=sys.argv[1]
if mode=='link':
 check_sources()
 compile('tools/qwen35_text/main.cc','consumer',old_consumer['command'])
 save('qwen-link.json',dict(command=args,origin=str(ARCH/'qwen-alias-source-journey/link-plan.json'),source_objects=[read(OUT/'operation-identity.json'),read(OUT/'consumer-identity.json')]+[r for r in base['source_objects'] if r['object']['path'] not in replacements],headers=base['checked_headers'],inputs=[ident(x) for x in args if Path(x).suffix.lower() in {'.obj','.lib'} and Path(x).is_file()]))
 run('qwen-link',args)
elif mode=='run':
 trace=OUT/'trace';assert not trace.exists(),'Never overwrite traces'
 inp=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
 save('qwen-inputs.json',[ident(inp/n) for n in ['input.json','weights.tsv','prompt.ids','continuation.ids']])
 run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
 run('qwen-direct',[OUT/'qwen.exe','--inputs',inp,'--continuation',inp/'continuation.ids','--steps','2','--capacity','32','--trace',trace,'--progress','direct'],timeout=300)
elif mode=='compare':
 prior=ARCH/'qwen-progress-journey/trace-direct';trace=OUT/'trace'
 a={p.relative_to(prior).as_posix():p for p in prior.rglob('*') if p.is_file() and p.suffix in {'.f32','.bf16'}}
 b={p.relative_to(trace).as_posix():p for p in trace.rglob('*') if p.is_file() and p.suffix in {'.f32','.bf16'}}
 assert len(a)==150 and set(a)==set(b),(len(a),len(b))
 pairs=[]
 for key in sorted(a):
  old=ident(a[key]);new=ident(b[key]);eq=a[key].read_bytes()==b[key].read_bytes()
  pairs.append(dict(name=key,original=old,candidate=new,byte_equal=eq))
 save('qwen-trace-pairs.json',pairs)
 routes=[]
 for p in sorted((trace/'routes').glob('*.route.tsv')):
  rows=list(csv.DictReader(p.open(),delimiter='\t'));counts=collections.Counter()
  for r in rows:
   counts.update(n.split(':',1)[1] for n in r['nodes'].split(',') if n)
  routes.append(dict(route=ident(p),steps=len(rows),node_kinds=dict(counts),providers=dict(collections.Counter(r['provider'] for r in rows))))
 prior_route=ARCH/'generic-progress/qwen/layer0-probe-01/default-T23.route.tsv'
 old_rows=list(csv.DictReader(prior_route.open(),delimiter='\t'))
 old_counts=collections.Counter(n.split(':',1)[1] for r in old_rows for n in r['nodes'].split(',') if n)
 result=dict(tensors=len(pairs),byte_equal=sum(r['byte_equal'] for r in pairs),bytes=sum(r['candidate']['bytes'] for r in pairs),differences=[r['name'] for r in pairs if not r['byte_equal']],routes=routes,original_t23=dict(route=ident(prior_route),steps=len(old_rows),node_kinds=dict(old_counts)))
 save('qwen-comparison.json',result);print(json.dumps(result,indent=2))
else:raise SystemExit('link/run/compare required')
