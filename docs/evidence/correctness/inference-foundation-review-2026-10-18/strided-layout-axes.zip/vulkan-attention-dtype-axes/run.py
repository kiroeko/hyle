"""Four wrapper/test overlays over the preceding exact BF16 native closure."""
from pathlib import Path
import hashlib,importlib.util,json,sys
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
BASE=OUT.parent/'vulkan-bf16-attention'
spec=importlib.util.spec_from_file_location('bf16_base',BASE/'run.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
helper.OUT=OUT
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
FILTER='VulkanCache.QueryCacheAndOutputTypesAreIndependent:VulkanNativeRegion.IndependentQueryCacheOutputTypesKeepOriginalSlotsAndOwners:VulkanCache.EmptyIndependentValueDepthKeepsOutputShape:VulkanCache.OriginalPlainCoupledUnboundedPaths:VulkanCache.BfloatQwenDepthKeepsCacheWordsAndFinalBfloatOutput:VulkanNativeRegion.BfloatPagedAndCompactMlaKeepOriginalSlotsAndOwners'
def link():
 base=read(BASE/'matched-link-inputs.json');command=next(r['command'] for r in reversed(read(BASE/'commands.json')) if r['tag']=='attention-tests-link' and r['exit']==0)
 selected=base['selected_sources'].copy();changes={helper.SOURCES[k]:str(OUT/(k+'.obj')) for k in ['batch','region','cache-test','graph-test']}
 replacements={selected[s]:p for s,p in changes.items()};selected.update(changes)
 for name in ['batch','region','cache-test','graph-test']:
  r=read(OUT/(name+'-identity.json'));assert r['exit']==0 and r['source_unchanged'];assert identity(r['source']['path'])==r['source'];assert identity(r['object']['path'])==r['object']
 objects=[]
 for old in base['objects']:
  if old['path'] in replacements:objects.append(replacements[old['path']])
  else:assert identity(old['path'])==old;objects.append(old['path'])
 final=[command[0],*[replacements.get(x,x) for x in command[1:] if not x.upper().startswith(('/OUT:','/MAP:'))],
  '/OUT:'+str(OUT/'attention-tests.exe'),'/MAP:'+str(OUT/'attention-tests.map')]
 write('matched-link-inputs.json',dict(objects=[identity(p) for p in objects],libraries=base['libraries'],selected_sources=selected,
  reused_base=identity(BASE/'matched-link-inputs.json'),reused_native_host=read(BASE/'native-host-identity.json')))
 code=helper.run('attention-tests-link',final)
 if not code:
  text=(OUT/'attention-tests.map').read_text(errors='replace')
  owners=[x for x in text.splitlines() if 'ggml_backend_vk_init ' in x or 'ggml_backend_vk_device_supports_op@@' in x]
  assert owners and all('native-host.obj' in x for x in owners)
  write('map-owners.json',dict(native=owners,old_native_member_selected='ggml-vulkan.cpp.obj' in text))
 return code
if __name__=='__main__':
 if sys.argv[1]=='compile':
  for name in sys.argv[2:]:
   assert name in ['batch','region','cache-test','graph-test'];code=helper.compile_one(name)
   if code:raise SystemExit(code)
 elif sys.argv[1]=='link':raise SystemExit(link())
 elif sys.argv[1]=='run':raise SystemExit(helper.run('attention-tests-run',[OUT/'attention-tests.exe','--gtest_color=no',
  '--gtest_filter='+FILTER,'--gtest_output=json:'+str(OUT/'attention-tests.json')],60))
 else:raise SystemExit('compile batch region cache-test graph-test | link | run')
