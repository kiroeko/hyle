"""Freeze text evidence and exact image candidates; never remove files."""
from pathlib import Path
import difflib,hashlib,json,subprocess
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];BASE=OUT.parent/'vulkan-bf16-attention'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
names=[p.relative_to(OUT/'before').as_posix() for p in sorted((OUT/'before').rglob('*')) if p.is_file()]
sources=[];diff=[]
for name in names:
 before=OUT/'before'/name;source=ROOT/name;target=OUT/'candidate'/name
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes());sources.append(identity(source))
 diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),source.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+name,tofile='current/'+name))
(OUT/'source.diff').write_text(''.join(diff),encoding='utf-8');write('source-identities.json',sources)
retained=[]
for name in ['batch','region','cache-test','graph-test']:
 receipt=read(OUT/(name+'-identity.json'));assert receipt['exit']==0 and receipt['source_unchanged']
 assert identity(receipt['source']['path'])==receipt['source'];assert identity(receipt['object']['path'])==receipt['object'];retained.append(receipt['object'])
write('retained-objects.json',retained)
matched=read(OUT/'matched-link-inputs.json')
for row in matched['objects']:assert identity(row['path'])==row
native=read(BASE/'native-host-identity.json');assert identity(native['source']['path'])==native['source'];assert identity(native['object']['path'])==native['object']
write('reused-native.json',dict(host=native,shader_and_headers=read(BASE/'retained-native-header-shader-match.json'),
 original_library_identities=read(BASE/'native-cache-identities.json')['libraries'],recipe_helper=identity(BASE/'run.py'),recompiled=False))
result=read(OUT/'attention-tests.json');assert result['tests']==6 and result['failures']==0
commands=read(OUT/'commands.json');assert len(commands)==6 and all(row['exit']==0 for row in commands)
device=next(t['vulkan_device'] for suite in result['testsuites'] for t in suite['testsuite'] if 'vulkan_device' in t)
summary=dict(status='passed_for_tested_domains',device=device,commands=dict(fresh_wrappers_tests='001..004',link='005',run='006'),
 implementation=['Paired F16/BF16 plain KV and paired Q8_0 use existing FaType decoding independently of the query dtype.',
 'Private flash output and request join remain F32 for either supported query dtype; round only once to selected public output.',
 'True-empty output also preserves independently selected output dtype.'],
 verification=dict(tests=6,failures=0,new_tests=2,fresh_wrapper_tus=2,fresh_test_tus=2,reused_native_host=True,
 rebuilt_shaders=False,rebuilt_core=False,two_graph_slots=True,strict_same_bindings_replay=True,old_output_gate=True,
 q0_output_f16_bf16=True,mixed_fp64_max_abs=[6.10259588e-5,7.62799728e-6,6.10254565e-5]),
 tested_combinations=['BF16 query / F16 KV -> BF16, D256 Direct and ordinary Graph.',
 'F16 query / BF16 KV -> F16, D256 Direct and ordinary Graph.',
 'F16 query / BF16 KV -> BF16, D256 Direct and ordinary Graph.',
 'Original short F16 D64/128/256, BF16 plain/Q8 D256, and BF16 compact MLA 576/512 controls.'],
 limits=['Common BatchCapacity continues to accept F16/BF16 query/output; F32 was not added.',
 'K/V remain the same storage format. Original depth/page16/device/shared-memory checks remain.',
 'Compact MlaBatchCapacity has one data_type; this change does not add a new schema API.',
 'No pending numerical, full-model, performance or other-device acceptance; original FP64 tolerances unchanged.'],
 sources=identity(OUT/'source-identities.json'),matched_objects=len(matched['objects']),failures=[])
write('summary.json',summary)
files=[identity(OUT/('attention-tests'+suffix)) for suffix in ['.exe','.map','.exp','.lib']]
write('cleanup.json',dict(root=str(ROOT),dir=str(OUT),files=files,retain=retained,reused_native=identity(BASE/'native-host.obj'),
 total_files=len(files),total_bytes=sum(row['bytes'] for row in files),delete_executed=False))
p=subprocess.run(['git','diff','--check','--',*names],cwd=ROOT,capture_output=True)
(OUT/'diff-check.stdout.log').write_bytes(p.stdout);(OUT/'diff-check.stderr.log').write_bytes(p.stderr);assert p.returncode==0
write('checks.json',dict(diff_check_exit=0,source_drift=0,matched_object_identities=len(matched['objects']),image_reads_complete=True))
entries=[identity(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix.lower() in ['.py','.json','.log','.diff','.cc','.md'] and p.name not in ['archive-files.json','receipt.json']]
write('archive-files.json',entries)
write('receipt.json',dict(summary=identity(OUT/'summary.json'),sources=identity(OUT/'source-identities.json'),objects=identity(OUT/'retained-objects.json'),
 cleanup=identity(OUT/'cleanup.json'),archive_files=identity(OUT/'archive-files.json'),cleanup_files=len(files),cleanup_bytes=sum(row['bytes'] for row in files),
 retained_objects=len(retained),all_writes_finished=True))
print(json.dumps(read(OUT/'receipt.json'),indent=2))
