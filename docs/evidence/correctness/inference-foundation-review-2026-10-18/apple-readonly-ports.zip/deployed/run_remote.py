from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
COLD = ROOT.parent / 'architecture-refactor-20261018-apple-cold-constants'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
OLD = json.loads((COLD / 'commands.json').read_text())
RECORDS = []


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def run(tag, command):
    command = list(map(str, command))
    stem = f'{len(RECORDS) + 1:02d}-{tag}'
    started = time.monotonic()
    with (ROOT / (stem + '.stdout.log')).open('wb') as out, (ROOT / (stem + '.stderr.log')).open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err)
        (ROOT / 'live.json').write_text(json.dumps(dict(tag=tag, pid=process.pid)) + '\n')
        try:
            code = process.wait(timeout=55)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            code = 124
    RECORDS.append(dict(tag=tag, command=command, cwd=str(ROOT), exit=code,
                        seconds=time.monotonic() - started,
                        stdout=stem + '.stdout.log', stderr=stem + '.stderr.log'))
    (ROOT / 'commands.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    (ROOT / 'live.json').write_text(json.dumps(dict(terminal=True, tag=tag, exit=code)) + '\n')
    print(stem, code, flush=True)
    if code:
        print((ROOT / (stem + '.stdout.log')).read_text(errors='replace')[-3000:], flush=True)
        print((ROOT / (stem + '.stderr.log')).read_text(errors='replace')[-6000:], flush=True)
        raise SystemExit(code)


def main():
    model = subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True).strip()
    assert model == 'Mac16,12', model
    (ROOT / 'machine.txt').write_text(subprocess.check_output(
        ['sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'], text=True)
        + subprocess.check_output(['xcrun', 'clang++', '--version'], text=True))
    for row in json.loads((ROOT / 'staged-sources.json').read_text()):
        assert identity(ROOT / row['path'])['sha256'] == row['sha256'], row['path']
    (ROOT / 'mlx.metallib').symlink_to((SDK / 'lib/mlx.metallib').resolve())
    replacement = {str(COLD / 'memory.o'): ROOT / 'memory.o', str(COLD / 'test.o'): ROOT / 'test.o'}
    retained = []
    for row in json.loads((COLD / 'native-tests-identities.json').read_text()):
        path = Path(row['path'])
        if path.suffix not in {'.o', '.a', '.dylib'} or str(path) in replacement:
            continue
        actual = identity(path)
        assert actual['sha256'] == row['sha256'], path
        retained.append(actual)
    (ROOT / 'retained-identities.json').write_text(json.dumps(retained, indent=2) + '\n')
    for source, name, historical in [
            ('src/compute_route_apple/apple_memory.mm', 'memory', 'memory-compile'),
            ('src/compute_route_apple/apple_copy_recording.mm', 'copy-recording', 'memory-compile'),
            ('src/compute_route_apple/apple_copy_program.cc', 'copy-program', 'memory-compile'),
            ('tests/graph_route_apple/native_region_test.cc', 'test', 'test-compile')]:
        old = next(row['command'] for row in OLD if row['tag'] == historical and row['exit'] == 0)
        prefix = old[:old.index('-c')]
        prefix[1:1] = ['-I' + str(ROOT / 'include'), '-I' + str(ROOT),
                       '-I' + str(ROOT / 'src/graph'), '-I' + str(ROOT / 'src/compute'),
                       '-I' + str(ROOT / 'src/compute_route_apple')]
        run(name + '-compile', prefix + ['-c', ROOT / source, '-o', ROOT / (name + '.o')])
    old = next(row['command'] for row in OLD if row['tag'] == 'native-tests-link' and row['exit'] == 0)
    output = ROOT / 'native-tests'
    command, seen = [], set()
    skip = False
    for arg in old:
        if skip:
            skip = False
            continue
        if arg == '-o':
            command += ['-o', str(output)]
            skip = True
            continue
        if arg.startswith('-Wl,-map,'):
            arg = '-Wl,-map,' + str(output) + '.map'
        if arg in replacement:
            seen.add(arg)
            arg = str(replacement[arg])
        command.append(arg)
    assert seen == set(replacement), (seen, set(replacement))
    command[1:1] = [str(ROOT / 'copy-recording.o'), str(ROOT / 'copy-program.o')]
    run('native-tests-link', command)
    (ROOT / 'native-tests-identities.json').write_text(json.dumps(
        [identity(path) for path in command if path.endswith(('.o', '.a', '.dylib'))]
        + [identity(output), identity(str(output) + '.map')], indent=2) + '\n')
    run('native-tests', [output, '--gtest_filter=AppleNativeRegion.*:AppleLateInput.*',
                         '--gtest_color=no', '--gtest_output=json:' + str(ROOT / 'test-results.json')])


if __name__ == '__main__':
    main()
