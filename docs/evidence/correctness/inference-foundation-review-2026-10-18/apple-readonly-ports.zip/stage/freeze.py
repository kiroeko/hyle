from pathlib import Path
import hashlib
import io
import json
import tarfile
import zipfile
import stage

ROOT, OUT, REMOTE = stage.ROOT, stage.OUT, stage.REMOTE


def main():
    code = '''from pathlib import Path
import io,sys,tarfile
r=Path(''' + repr(REMOTE) + ''')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and not p.is_symlink() and p.suffix in {'.json','.log','.txt','.py'}:
   a.add(p,arcname=p.name)
sys.stdout.buffer.write(b.getvalue())
'''
    payload = stage.ssh(code)
    (OUT / 'remote-evidence.tar.gz').write_bytes(payload)
    destination = OUT / 'remote'
    destination.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        assert all(m.isfile() and Path(m.name).name == m.name for m in archive.getmembers())
        archive.extractall(destination)
    results = json.loads((destination / 'test-results.json').read_text())
    assert results['tests'] == 8 and results['failures'] == 0 and results['errors'] == 0
    commands = json.loads((destination / 'commands.json').read_text())
    assert len(commands) == 6 and all(row['exit'] == 0 for row in commands)
    identities = json.loads((destination / 'native-tests-identities.json').read_text())
    fresh = [row for row in identities if Path(row['path']).parent == Path(REMOTE)]
    cleanup = dict(root=REMOTE, files=[r for r in fresh if Path(r['path']).suffix != '.o'],
                   retain=[r for r in fresh if Path(r['path']).suffix == '.o'])
    assert len(cleanup['files']) == 2 and len(cleanup['retain']) == 4
    (OUT / 'cleanup-mac.json').write_text(json.dumps(cleanup, indent=2) + '\n')
    expected = json.loads((OUT.parent / 'apple-readonly-import/final-sha256.json').read_text())
    # The agent's delta and the deployed source manifest describe the same five files.
    deployed = {r['path']: r for r in json.loads((OUT / 'staged-sources.json').read_text())}
    for name in stage.SEEDS + ['src/compute_route_apple/apple_copy_internal.h']:
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == deployed[name]['sha256'], name
    summary = dict(scope='Actual readonly Apple Graph output permissions in Mem and Metal copy destinations',
                   host='kiro@172.22.10.198', remote_stage=REMOTE,
                   hardware=(destination / 'machine.txt').read_text(),
                   fresh_tus=stage.SEEDS, actual_tests=8, failures=0,
                   source_manifest='staged-sources.json', commands='remote/commands.json',
                   retained_objects='remote/retained-identities.json',
                   limits=['No new CPU+Apple bridge or public SPI change.',
                           'No SDK/common Graph rebuild, whole checkout, full model or performance run.'])
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    evidence = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/apple-readonly-ports.zip'
    assert not evidence.exists(), evidence
    with zipfile.ZipFile(evidence, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        with tarfile.open(OUT / 'minimal-sources.tar.gz', mode='r:gz') as sources:
            for item in sources.getmembers():
                assert item.isfile() and not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
                archive.writestr('deployed/' + item.name, sources.extractfile(item).read())
        for file in sorted(OUT.glob('*.py')):
            archive.write(file, 'stage/' + file.name)
        for file in sorted(OUT.glob('*.json')):
            archive.write(file, 'stage/' + file.name)
        for file in sorted(destination.iterdir()):
            if file.is_file():
                archive.write(file, 'stage/remote/' + file.name)
        for file in sorted((OUT.parent / 'apple-readonly-import').iterdir()):
            if file.is_file() and file.suffix in {'.json', '.diff'}:
                archive.write(file, 'delta/' + file.name)
        for name in ['docs/architecture/compute-design.md', 'docs/developer/current-work.md',
                     'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md', 'test.ps1']:
            archive.write(ROOT / name, 'repo/' + name)
    with zipfile.ZipFile(evidence) as archive:
        assert archive.testzip() is None
    receipt = dict(path=str(evidence), bytes=evidence.stat().st_size,
                   sha256=hashlib.sha256(evidence.read_bytes()).hexdigest())
    (OUT / 'archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
