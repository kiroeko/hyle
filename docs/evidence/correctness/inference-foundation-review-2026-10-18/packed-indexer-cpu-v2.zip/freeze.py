from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
R=Path.cwd();O=Path(__file__).resolve().parent if '__file__' in globals() else R/'.scratch/inference-foundation-review-2026-10-18/packed-indexer-cpu'
O=R/'.scratch/inference-foundation-review-2026-10-18/packed-indexer-cpu'
files=['include/hyle/compute/model_ops.h','src/compute_provider_native/torch_cpu_program.cc','src/compute_provider_native/row_cache.cc','src/compute_provider_native/row_cache_codec.h','src/compute_provider_native/native_provider.cc','tests/compute_models/row_cache_indexer_fixture.h','tests/compute_route_cpu/row_cache_indexer_test.cc','tests/compute_route_cpu/CMakeLists.txt']
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
identities=[]
for rel in files:
 p=R/rel;d=O/'source'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d);identities.append(identity(p))
commands=json.loads((O/'commands.json').read_text())
for x in commands:
 for s in x['command']:
  p=Path(s)
  if s.endswith(('.obj','.lib')) and p.is_file() and not any(i['path']==str(p) for i in identities):identities.append(identity(p))
for filename in ['official-model.py','official-kernel.py']:
 p=R/'.scratch/validation/d5-f38-dynamic-fp8'/filename;d=O/'reference'/filename;d.parent.mkdir(exist_ok=True);shutil.copyfile(p,d);identities.append(identity(p))
(O/'identities.json').write_text(json.dumps(identities,indent=2)+'\n',encoding='utf-8')
hardware=subprocess.run(['powershell','-NoProfile','-Command','[ordered]@{processor=(Get-CimInstance Win32_Processor|Select-Object Name,NumberOfCores,NumberOfLogicalProcessors);os=(Get-CimInstance Win32_OperatingSystem|Select-Object Caption,Version,BuildNumber)}|ConvertTo-Json -Depth 4'],capture_output=True,text=True)
(O/'hardware.json').write_text(hardware.stdout,encoding='utf-8')
summary={
 'status':'CPU implemented, not committed; other backends and paged scorer remain separate work',
 'scope':'New four-port model_ops::RowCacheIndexerScores only; old LightningIndexer and all existing dense/quantized routes retain their contracts.',
 'ports':['BF16 query[T,64,128], already explicit Hadamard/FP4-QAT','plain U8 HYLE row-inline FP4/UE8 bank[L,68]','BF16 prescaled weights[T,64]','I32 half-open ranges[T,2]'],
 'output':'F32[T,L], outside range=-Inf; dot F32acc->BF16->ReLU->weighted product BF16->F32 head accumulation->BF16->F32. No implicit quantization/scaling/TopK.',
 'implementation':'Key tiles are outermost; each packed row referenced by any query range is decoded once and query matmuls read only their intersections. Pinned original ATen BF16 matmul/relu/mul/sum in fixed private key tiles <=256. Same private decoder as original row codec. Only <=256x128 BF16 decoded tile; no full-history BF16/F32 bank or ggml MXFP4 reinterpretation. Complete private F32 output is copied to caller only after success.',
 'validation':{'canonical':'3/3 PASS with default cpu::create_context; native provider selected, managed replay/private threads/no capture. T3/L513, 256+256+1 tail, two payload phases/two slots, independent FP64/table/BF16 full-output oracle; omission-of-BF16 counterfactual differs. Negative/descending/out-of-bank last-query ranges leave all public output unchanged. T0/L0 execute, not only infer.',
 'resource':'Separate isolated real C10 CPUAllocator wrapper, same T3/L513, 1/1 PASS. Candidate32 payload requests total470662B; max65536B (256x128x2); private output6156B and caller output6156B separately. Full-history BF16 would131328B; no such request occurred. Raw request histogram retained.',
 'oom':'One real ATen allocation failure injected by allocator throwing bad_alloc: ResourceExhausted, caller sentinel unchanged, fresh invocation retry numerically PASS.',
 'build':'MSVC14.50 /O2 /MD /W4 /WX, pinned libtorch CPU 2.8 Windows SDK. Fresh torch adapter/row codec/native provider/test TUs + scratch resource TU; existing static CPU default roster/libs only. No SDK/configure/native kernel rebuild.',
 'runs':'First canonical2test run also passed; added actual T0/L0 execution, original query-outer version3/3 PASS, keytile-outer finalversion3/3 PASS. No timing/benchmark.',
 'decode_sharing':'The same scratch-only wrapper increments once at the actual shared decoder entry, with identical fixture and retained v1 torch object versus fresh v2 torch object. Actual1023->513 decoded rows (two overlapping query ranges length513+510, union513). Both arms full oracle/OOM/retry PASS. Tile-aligned query intersections change C10 requests27->32 with the same470662 cumulative bytes; max65536 unchanged. Do not infer time improvement from this count.'},
 'limits':['C10 requests are not process RSS or total peak: allocator metadata and internal BLAS/oneDNN allocations outside C10 were not monitored. No throughput claim.','Private output T*L remains allocated to preserve errors before publication; tiles are transient managed ATen allocations, not a prepared/no-heap replay promise.','Contiguous bank only. No typed PagedArena scorer/Graph permission macro, no automatic full DeepSeek model integration. Existing selected-row reader is not a TopK-before-scoring solution.','Query QAT/weights projections and Hadamard remain explicit upstream. Sparse prefix fixtures still use dense scoring until separately switched.'],
 'failures_retained':[{'stage':'initial link','exit':1120,'reason':'Old foundation compute_ops library predates row_cache_carrier_description; link required already-built current row-cache-contracts/low-precision.obj. No product or oracle change.','log_provenance':'Exact failed command/exit remains in commands.json. Helper later overwrote same link stdout filename; original LNK2019 text was read in tool transcript, not presented as an original frozen raw log.'}],
 'probe_mechanical_failure':'Initial scratch counter compile rejected deprecated getenv under /WX (C4996); changed probe to getenv_s, raw original compiler failure retained as census-env-failed.stdout.log. No product/oracle change.',
 'source_identity':identities[:len(files)],
 'runtime_environment':{'OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2','PATH_prepend':'Pinned libtorch/lib and existing build-compute-v2-dev/bin'},
 'numerical_budget':'EXPECT_FLOAT_EQ against independent explicit BF16 reference on all finite outputs; outside-range infinities exact. No tolerance widened.'}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cleanup={'scope':'Candidates only. No files deleted; root writes/executes exact test.ps1 cleanup later. Source/log/map/data/SDK/cache preserved.','delete':[identity(p) for p in sorted(O.iterdir()) if p.suffix in ['.exe','.exp','.lib']],'retain':[identity(p) for p in sorted(O.iterdir()) if p.suffix=='.obj']}
(O/'cleanup-candidates.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf-8')
for mapfile in O.glob('*.map'):
 selected=[line for line in mapfile.read_text(errors='replace').splitlines() if any(k in line for k in ['row_cache_indexer','decode_row_cache_float4','torch_cpu_program','create_context@cpu'])]
 (O/(mapfile.stem+'.map-excerpt.txt')).write_text('\n'.join(selected)+'\n',encoding='utf-8')
archive=O/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(O.rglob('*')):
  if p.is_file() and p!=archive and p.suffix not in ['.obj','.exe','.lib','.exp','.map']:
   z.write(p,p.relative_to(O).as_posix())
print(json.dumps(identity(archive),indent=2))
