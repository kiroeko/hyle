from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
source = ROOT / 'src/compute_provider_native/torch_cpu_program.cc'
text = source.read_text(encoding='utf-8')
original = text[text.index('struct Quantized final'):text.index('Result<at::Tensor> indexer_scores(')]
(OUT / 'baseline-block.cc.inc').write_text(original, encoding='utf-8')
(OUT / 'source-identity.json').write_text(json.dumps({
    'path': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'scope': 'Exact existing quantize/weight/block_dot extracted; standalone ATen probe, not yet a product repair',
}, indent=2) + '\n')
parts = [OUT / name for name in ('probe-prefix.cc.inc', 'baseline-block.cc.inc',
                                'candidate.cc.inc', 'probe-main.cc.inc')]
(OUT / 'probe.cc').write_text('\n'.join(p.read_text(encoding='utf-8') for p in parts), encoding='utf-8')
