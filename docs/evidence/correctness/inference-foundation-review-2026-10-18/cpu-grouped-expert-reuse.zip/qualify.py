from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cached_cpu', ROOT / '.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
cpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cpu)
TORCH = Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
flags = cpu.hyle_flags(dict(cpu.PINS['mixed'], folder=Path('mixed')))
flags += ['/I' + str(ROOT), '/I' + str(ROOT / 'src/compute_provider_native'), '/DHYLE_COMPUTE_TORCH_CPU=1',
          '/external:I' + str(TORCH / 'include'), '/external:I' + str(TORCH / 'include/torch/csrc/api/include')]
flags += ['/I' + str(ROOT / 'third_party' / name) for name in ('torchao_cpu', 'bitsandbytes_cpu', 'awq_cpu', 'compressed_tensors_cpu', 'mlx_cpu_quant')]
env = dict(cpu.ENV)
env['PATH'] = str(TORCH / 'lib') + os.pathsep + env['PATH']
env['OMP_NUM_THREADS'] = env['MKL_NUM_THREADS'] = '2'
records = json.loads((OUT / 'qualification-commands.json').read_text()) if (OUT / 'qualification-commands.json').exists() else []


def run(tag, command):
    command = list(map(str, command))
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=180,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    stem = str(len(records) + 1) + '-' + tag
    (OUT / (stem + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag, command=command, exit=result.returncode, seconds=time.monotonic() - start,
                        stdout=stem + '.stdout.log', stderr=stem + '.stderr.log'))
    (OUT / 'qualification-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(stem, result.returncode, result.stdout.decode(errors='replace')[-6000:], result.stderr.decode(errors='replace')[-3000:], flush=True)
    result.check_returncode()


def compile(source, name):
    obj = OUT / (name + '.obj')
    run(name + '-compile', [cpu.CL, *flags, '/Tp' + str(source), '/Fo' + str(obj)])
    return obj


def main():
    source = ROOT / 'src/compute_provider_native/torch_cpu_program.cc'
    (OUT / 'torch_cpu_program.cc.applied').write_bytes(source.read_bytes())
    tests, product = OUT / 'canonical-tests.obj', OUT / 'product.obj'
    if '--reuse-objects' not in sys.argv:
        tests = compile(ROOT / 'tests/compute_provider_native/torch_cpu_test.cc', 'canonical-tests')
        product = compile(source, 'product')
    libs = [cpu.BASE / 'bin' / name for name in ('hyle_compute_route_cpu.lib', 'hyle_compute_provider_native.lib', 'hyle_compute_provider_onednn.lib', 'dnnl.lib')]
    libs += cpu.common_libs() + [TORCH / 'lib' / name for name in ('torch.lib', 'torch_cpu.lib', 'c10.lib')]
    libs += [cpu.BASE / 'lib/gtest.lib', cpu.BASE / 'lib/gtest_main.lib']
    exe = OUT / 'canonical.exe'
    run('canonical-link', [cpu.LINK, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
                          '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(exe), tests, product,
                          ROOT / '.scratch/inference-foundation-review-2026-10-18/packed-indexer-cpu/row-cache.obj',
                          ROOT / '.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj',
                          *libs, *cpu.SYSTEM])
    run('canonical-tests', [exe, '--gtest_filter=NativeTorchCpu.*'])
    text = source.read_text(encoding='utf-8')
    original = text[text.index('struct Quantized final'):text.index('Result<at::Tensor> indexer_scores(')]
    body = (OUT / 'probe-main.cc.inc').read_text().replace('candidate_dot(a,w,s)', 'grouped_block_dot(a,w,s)')
    body = body.replace('PASS standalone original/candidate FP8 and FP4; richer canonical/default-route qualification still required before product change.',
                        'PASS exact current product grouped_block_dot versus retained original block_dot; dot-only, no full-model timing.')
    probe = OUT / 'product-probe.cc'
    probe.write_text((OUT / 'probe-prefix.cc.inc').read_text() + '\n' + original + '\n' + body)
    obj = compile(probe, 'product-probe')
    probe_exe = OUT / 'product-probe.exe'
    run('product-probe-link', [cpu.LINK, '/nologo', obj, *(TORCH / 'lib' / n for n in ('torch.lib', 'torch_cpu.lib', 'c10.lib')),
                             '/OUT:' + str(probe_exe)])
    run('product-probe', [probe_exe])
    paths = [source, ROOT / 'tests/compute_provider_native/torch_cpu_test.cc', cpu.CL, TORCH / 'lib/torch_cpu.dll',
             ROOT / '.scratch/inference-foundation-review-2026-10-18/packed-indexer-cpu/row-cache.obj',
             ROOT / '.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj', *libs]
    (OUT / 'qualification-identities.json').write_text(json.dumps([
        dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths], indent=2) + '\n')


if __name__ == '__main__':
    main()
