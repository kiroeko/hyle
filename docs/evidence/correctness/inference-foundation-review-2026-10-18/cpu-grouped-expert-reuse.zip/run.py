from pathlib import Path
import importlib.util
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cached_cpu', ROOT / '.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
TORCH = Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
env = dict(b.ENV)
env['PATH'] = str(TORCH / 'lib') + os.pathsep + env['PATH']
env['OMP_NUM_THREADS'] = '2'
env['MKL_NUM_THREADS'] = '2'
records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def run(tag, cmd):
    cmd = list(map(str, cmd))
    start = time.monotonic()
    p = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, timeout=180,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    stem = str(len(records) + 1) + '-' + tag
    (OUT / (stem + '.stdout.log')).write_bytes(p.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(p.stderr)
    records.append({'tag': tag, 'command': cmd, 'exit': p.returncode,
                    'seconds': time.monotonic() - start, 'stdout': stem + '.stdout.log',
                    'stderr': stem + '.stderr.log'})
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(stem, p.returncode, p.stdout.decode(errors='replace')[-5000:], p.stderr.decode(errors='replace')[-2000:], flush=True)
    p.check_returncode()


run('generate', ['python', '-B', '-X', 'utf8', OUT / 'generate.py'])
flags = b.hyle_flags(dict(b.PINS['mixed'], folder=Path('mixed')))
flags += ['/I' + str(ROOT / 'third_party/torchao_cpu'), '/external:I' + str(TORCH / 'include'),
          '/external:I' + str(TORCH / 'include/torch/csrc/api/include')]
run('probe-compile', [b.CL, *flags, '/Tp' + str(OUT / 'probe.cc'), '/Fo' + str(OUT / 'probe.obj')])
run('probe-link', [b.LINK, '/nologo', OUT / 'probe.obj',
                  *(TORCH / 'lib' / n for n in ('torch.lib', 'torch_cpu.lib', 'c10.lib')),
                  '/OUT:' + str(OUT / 'probe.exe')])
run('probe', [OUT / 'probe.exe'])
