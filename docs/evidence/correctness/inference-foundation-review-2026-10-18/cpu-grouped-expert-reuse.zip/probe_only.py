from pathlib import Path
import importlib.util

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qualify', OUT / 'qualify.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
text = (q.ROOT / 'src/compute_provider_native/torch_cpu_program.cc').read_text(encoding='utf-8')
original = text[text.index('struct Quantized final'):text.index('Result<at::Tensor> indexer_scores(')]
body = (OUT / 'probe-main.cc.inc').read_text().replace('candidate_dot(a,w,s)', 'grouped_block_dot(a,w,s)')
body = body.replace('PASS standalone original/candidate FP8 and FP4; richer canonical/default-route qualification still required before product change.',
                    'PASS exact product grouped_block_dot versus original block_dot; counterbalanced matched dot-only, activation expansion inside both timed paths.')
probe = OUT / 'product-probe-counterbalanced.cc'
probe.write_text((OUT / 'probe-prefix.cc.inc').read_text() + '\n' + original + '\n' + body)
obj = q.compile(probe, 'product-probe-counterbalanced')
exe = OUT / 'product-probe-counterbalanced.exe'
q.run('product-probe-counterbalanced-link', [q.cpu.LINK, '/nologo', obj,
      *(q.TORCH / 'lib' / n for n in ('torch.lib', 'torch_cpu.lib', 'c10.lib')), '/OUT:' + str(exe)])
q.run('product-probe-counterbalanced', [exe])
