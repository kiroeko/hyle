from pathlib import Path
import difflib
import hashlib
import json
import re
import statistics
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
product = ROOT / 'src/compute_provider_native/torch_cpu_program.cc'
tests = ROOT / 'tests/compute_provider_native/torch_cpu_test.cc'
assert product.read_bytes() == (OUT / 'torch_cpu_program.cc.applied').read_bytes()
(OUT / 'torch_cpu_test.cc.applied').write_bytes(tests.read_bytes())
changes = []
for path in (product, tests):
    changes += difflib.unified_diff((OUT / (path.name + '.before')).read_text().splitlines(True),
                                    path.read_text().splitlines(True),
                                    fromfile=str(path.relative_to(ROOT)) + '.before',
                                    tofile=str(path.relative_to(ROOT)))
(OUT / 'source.diff').write_text(''.join(changes), encoding='utf-8')
raw = (OUT / '18-product-probe-counterbalanced.stdout.log').read_text()
cases = []
for segment in raw.split('CASE ')[1:]:
    tokens, shared = map(int, re.search(r'tokens=(\d+) shared=(\d+)', segment).groups())
    census, timings = [], []
    for match in re.finditer(r'CENSUS fp4=(\d) candidate=(\d) max_request=(\d+) requested_bytes=(\d+) calls=(\d+)', segment):
        four, candidate, maximum, total, calls = map(int, match.groups())
        census.append(dict(candidate=bool(candidate), max_request=maximum, requested_bytes=total, calls=calls))
    for match in re.finditer(r'DOT_ONLY fp4=(\d) candidate=(\d) median_us=([\d.]+) samples_us=([\d.,]+)', segment):
        four, candidate, median, samples = match.groups()
        timings.append(dict(candidate=bool(int(candidate)), median_us=float(median),
                            samples_us=[float(v) for v in samples.split(',') if v]))
    old, new = timings
    cases.append(dict(fp4=bool(int(four)), tokens=tokens, shared_activation=bool(shared), census=census,
                      timings=timings, new_over_old=statistics.median(
                          [n / o for o, n in zip(old['samples_us'], new['samples_us'])])))
summary = dict(
    status='Implemented; focused canonical 6/6 and actual default CPU route 2/2 PASS',
    cause='CPU grouped FP8/FP4 decoded a selected K block once for every (token,slot), repeating weights for duplicate experts. Shared A=1 activation was also widened after slot broadcast.',
    repair='Sort validated IDs, group referenced experts by equal row occurrence count, decode each expert once per original K block and use original ATen batched GEMM without padding to a maximum count. Scatter rows back to original order. Decode activation one block at a time before slot selection. No-repeat selection keeps original batched path.',
    math='Original TorchAO FP8 activation quantization and FP4/FP8 codecs/scales, F32 dot and original K-block accumulation order, original activation-scale then weight-scale product, one final output cast. GEMM row grouping may use a different native reduction order for general non-dyadic data; no new bitwise-equality promise.',
    validation=dict(canonical='8-canonical-tests.stdout.log: 6/6, including real OOM/recovery, grouped duplicate IDs/independent concurrent slots, rich all-output FP64 oracle, invalid ID sentinel protection, dense linear controls.',
                    grouped='T1/T3, S4/E17/N129/K512, FP8 F32 and FP4 BF16, A1 and A=S, two changed phases. T1 phase0 distinct IDs takes old path; phase1 duplicates and T3 exercise grouped buckets.',
                    default_route='15-default-route-tests.stdout.log: 2/2 with original rich/duplicate tests changed only to ordinary cpu::create_context; explicit implementation IDs assert actual Torch FP8/FP4 selection.',
                    probe='18-product-probe-counterbalanced.stdout.log: independent encoded-weight output formula for every element, T1/T128, A1/A=S, both formats. Functions are extracted exactly from the current product source; original block_dot retained as control.'),
    protocol='CPU i9-13900K, pinned libtorch/MSVC caches, at::set_num_threads(2), OMP_NUM_THREADS=MKL_NUM_THREADS=2. Dot-only excludes identical quantization/ID validation/weight views; shared activation expansion is INSIDE both timed paths. 2 warmup pairs + 9 AB/BA counterbalanced pairs; all raw samples retained. C10 recording active only in separate census. No process isolation or whole-model throughput claim.',
    memory='C10 max_request and cumulative requested_bytes are allocation request counts, not RSS/peak live storage/vendor heap. Host vector/map metadata is not counted. New path uses more small C10 allocations while reducing total requested bytes; no whole-run zero-allocation promise.',
    actual_cases=cases,
    limitations=['Linux/macOS CPU execution not rerun here.',
                 'IREE grouped route has a related source-level per-slot weight tensor; not repaired or counted by this slice.',
                 'Native metadata sort/buckets are rebuilt per invocation because expert IDs may change; no new persistent cache or public configuration.',
                 'Earlier standalone and fixed-order probe logs retained. The final counterbalanced run corrects the original baseline exclusion of shared activation expansion.',
                 'Unrelated newly added typed paged scorer remains in the source snapshot but is independently qualified by its author, not claimed by these MoE tests.'],
    build='Only original test TU, product host TU, small standalone probe and default-route test-copy TU compiled. Cached original libraries and row-cache/low-precision objects linked; no SDK/dependency rebuild. Two incomplete link closures and one relocated scratch include-path failure retained.')
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
identities = []
for path in (product, tests):
    identities.append(dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size,
                           sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(OUT / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
retain = []
deletable = []
for path in sorted(OUT.iterdir()):
    if path.suffix in ('.obj', '.exe', '.lib', '.exp'):
        info = dict(path=str(path.resolve()), bytes=path.stat().st_size,
                    sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        (retain if path.suffix == '.obj' else deletable).append(info)
(OUT / 'retain-objects.json').write_text(json.dumps(retain, indent=2) + '\n')
(OUT / 'deletable-artifacts.json').write_text(json.dumps(deletable, indent=2) + '\n')
bundle = OUT / 'source-results.zip'
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as z:
    for path in sorted(OUT.iterdir()):
        if path.is_file() and path.suffix not in ('.obj', '.exe', '.lib', '.exp', '.zip'):
            z.write(path, path.name)
print(json.dumps(dict(path=str(bundle.relative_to(ROOT)), bytes=bundle.stat().st_size,
                      sha256=hashlib.sha256(bundle.read_bytes()).hexdigest()), indent=2))
