from pathlib import Path
import hashlib
import importlib.util
import json

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qualify', OUT / 'qualify.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
source = q.ROOT / 'tests/compute_provider_native/torch_cpu_test.cc'
body = source.read_text(encoding='utf-8')
body = '#include "hyle/compute/cpu.h"\n' + body
body = body.replace('c::test::native_context()', 'c::cpu::create_context()')
marker = 'auto prepared=c::prepare(context,op,descriptions,output,mem::system_resource()).value();'
assert body.count(marker) == 1
body = body.replace(marker, marker + '\n    ASSERT_EQ(prepared.implementation().value(),four?0x544f524348000005ULL:0x544f524348000004ULL);')
path = OUT / 'default-route-tests.cc'
path.write_text(body, encoding='utf-8')
q.flags += ['/I' + str(source.parent)]
obj = q.compile(path, 'default-route-tests')
exe = OUT / 'default-route.exe'
libs = [q.cpu.BASE / 'bin' / name for name in ('hyle_compute_route_cpu.lib', 'hyle_compute_provider_native.lib', 'hyle_compute_provider_onednn.lib', 'dnnl.lib')]
libs += q.cpu.common_libs() + [q.TORCH / 'lib' / name for name in ('torch.lib', 'torch_cpu.lib', 'c10.lib')]
libs += [q.cpu.BASE / 'lib/gtest.lib', q.cpu.BASE / 'lib/gtest_main.lib']
objects = [obj, OUT / 'product.obj', q.ROOT / '.scratch/inference-foundation-review-2026-10-18/packed-indexer-cpu/row-cache.obj',
           q.ROOT / '.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj']
q.run('default-route-link', [q.cpu.LINK, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
                           '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(exe), *objects, *libs, *q.cpu.SYSTEM])
q.run('default-route-tests', [exe, '--gtest_filter=NativeTorchCpu.GroupedBlocksKeepMultiTokenIdsScalesAndTailRows:NativeTorchCpu.DuplicateExpertIdsAndFailedInvocationRecovery'])
(OUT / 'default-route-identities.json').write_text(json.dumps([
    dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    for p in [source, path, *objects, *libs]], indent=2) + '\n')
