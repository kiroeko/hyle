#include <ATen/ATen.h>
#include <ATen/Parallel.h>
#include <ATen/core/grad_mode.h>
#include <c10/core/CPUAllocator.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <map>
#include <mutex>
#include <stdexcept>
#include <tuple>
#include <vector>
#include "torchao_cpu.h"
enum class Kind { kGrouped4, kGrouped8 };
struct Shape final {
  Kind kind{};
  std::int64_t e=17,n=129,k=512,tokens=128,slots=4,activations=1;
  bool power=false;
  float floor=1.e-10F;
  at::ScalarType output=at::kFloat;
};

struct Quantized final { at::Tensor codes, scales, ids; };
Quantized quantize(const at::Tensor &input, const Shape &s) {
  auto data = input.to(at::kFloat).reshape({-1, 128});
  at::Tensor scale;
  if (s.power) {
    // Original TorchAO _to_mx_rceil receives the model's explicit absmax floor.
    auto maximum = data.abs().amax(-1, true).clamp_min(s.floor);
    auto exponent = torchao_cpu::f32_to_e8m0_rceil(maximum * (1.0 / 448.0));
    scale = torchao_cpu::e8m0_scale_to_reciprocal_fp32(exponent).reciprocal();
  } else scale = torchao_cpu::choose_scale_float8(data, s.floor);
  return {torchao_cpu::quantize_affine_float8(data, scale), std::move(scale)};
}
Quantized weight(const at::Tensor &carrier, const Shape &s, const at::Tensor &ids) {
  const bool four = s.kind == Kind::kGrouped4;
  const auto payload = s.e * s.n * (s.k / (four ? 2 : 1));
  auto codes = carrier.slice(0, 0, payload).reshape({s.e, s.n, s.k / (four ? 2 : 1)});
  auto scales = carrier.slice(0, payload).view(at::kFloat).reshape(
      {s.e, four ? s.n : (s.n + 127) / 128, s.k / (four ? 32 : 128)});
  // Retain encoded weights. The original FP4 codec creates several tensors;
  // select grouped rows only after slicing their current K block.
  if (!four && !ids.defined())
    scales = scales.repeat_interleave(128, 1).slice(1, 0, s.n);
  return {std::move(codes), std::move(scales), ids};
}
at::Tensor block_dot(Quantized a, Quantized w, const Shape &s) {
  const auto rows = s.tokens * s.slots;
  const auto group = s.kind == Kind::kGrouped4 ? 32 : 128;
  const auto blocks = s.k / group;
  auto lhs = a.codes.to(at::kFloat).reshape({rows, blocks, 1, group});
  auto scales = a.scales.reshape({rows, s.k / 128});
  if (group == 32) scales = scales.repeat_interleave(4, 1);
  auto accumulated = at::zeros({rows, 1, s.n}, at::kFloat);
  // Fixed original K-block order. Decode and matrix temporaries are bounded
  // by one original block; all codec and payload arithmetic remains in ATen.
  const auto encoded_group = s.kind == Kind::kGrouped4 ? group / 2 : group;
  for (std::int64_t block = 0; block < blocks; ++block) {
    auto encoded = w.codes.slice(2, block * encoded_group,
                                 (block + 1) * encoded_group);
    encoded = w.ids.defined() ? encoded.index_select(0, w.ids)
                              : encoded.contiguous();
    auto weight_scales = w.scales.select(2, block);
    if (w.ids.defined()) {
      weight_scales = weight_scales.index_select(0, w.ids);
      if (s.kind != Kind::kGrouped4)
        weight_scales = weight_scales.repeat_interleave(128, 1).slice(1, 0, s.n);
    }
    auto decoded = s.kind == Kind::kGrouped4
        ? torchao_cpu::f4_unpacked_to_f32(torchao_cpu::unpack_uint4(encoded))
        : encoded.view(at::kFloat8_e4m3fn).to(at::kFloat);
    auto dots = at::matmul(lhs.select(1, block), decoded.transpose(1, 2));
    auto scaled = dots * scales.select(1, block).reshape({rows, 1, 1});
    accumulated = accumulated + scaled * weight_scales.unsqueeze(1);
  }
  return accumulated.reshape({s.tokens, s.slots, s.n}).to(s.output);
}

at::Tensor grouped_block_dot(Quantized a, Quantized w, const Shape &s) {
  const auto rows = s.tokens * s.slots;
  const auto *ids = w.ids.const_data_ptr<std::int64_t>();
  std::vector<std::pair<std::int64_t, std::int64_t>> ordered;
  ordered.reserve(static_cast<std::size_t>(rows));
  for (std::int64_t row = 0; row < rows; ++row)
    ordered.emplace_back(ids[row], row);
  std::sort(ordered.begin(), ordered.end());
  const bool repeated =
      std::adjacent_find(ordered.begin(), ordered.end(),
                         [](const auto &left, const auto &right) {
                           return left.first == right.first;
                         }) != ordered.end();
  if (!repeated) {
    // Decode has no reusable expert here. Keep the original batched path,
    // including the single-token case, without constructing bucket tensors.
    if (s.activations == 1 && s.slots != 1) {
      a.codes = a.codes.expand({s.tokens, s.slots, s.k});
      a.scales = a.scales.expand({s.tokens, s.slots, s.k / 128});
    }
    return block_dot(std::move(a), std::move(w), s);
  }
  struct Bucket final {
    std::vector<std::int64_t> experts, positions, activations;
    at::Tensor expert_ids, row_ids, activation_ids;
  };
  // Equal occurrence counts share a native batched GEMM. This avoids both
  // per-token weight copies and padding every expert to the largest count.
  std::map<std::int64_t, Bucket> buckets;
  for (std::size_t first = 0; first < ordered.size();) {
    auto end = first + 1;
    while (end < ordered.size() && ordered[end].first == ordered[first].first)
      ++end;
    auto &bucket = buckets[static_cast<std::int64_t>(end - first)];
    bucket.experts.push_back(ordered[first].first);
    for (auto item = first; item < end; ++item) {
      const auto row = ordered[item].second;
      bucket.positions.push_back(row);
      bucket.activations.push_back((row / s.slots) * s.activations +
                                   (s.activations == 1 ? 0 : row % s.slots));
    }
    first = end;
  }
  for (auto &[count, bucket] : buckets) {
    (void)count;
    bucket.expert_ids = at::tensor(bucket.experts, at::kLong);
    bucket.row_ids = at::tensor(bucket.positions, at::kLong);
    bucket.activation_ids = at::tensor(bucket.activations, at::kLong);
  }
  const auto group = s.kind == Kind::kGrouped4 ? 32 : 128;
  const auto encoded_group = s.kind == Kind::kGrouped4 ? group / 2 : group;
  const auto codes = a.codes.reshape({s.tokens * s.activations, s.k});
  const auto scales = a.scales.reshape({s.tokens * s.activations, s.k / 128});
  auto accumulated = at::zeros({rows, s.n}, at::kFloat);
  // Preserve the original K-block accumulation/scale order. Each referenced
  // expert is decoded once per block; shared activations stay unexpanded.
  for (std::int64_t block = 0; block < s.k / group; ++block) {
    const auto activation =
        codes.slice(1, block * group, (block + 1) * group).to(at::kFloat);
    const auto activation_scales =
        scales.select(1, group == 32 ? block / 4 : block);
    const auto selected_codes =
        w.codes.slice(2, block * encoded_group, (block + 1) * encoded_group);
    const auto selected_scales = w.scales.select(2, block);
    for (const auto &[count, bucket] : buckets) {
      const auto experts = static_cast<std::int64_t>(bucket.experts.size());
      const auto encoded = selected_codes.index_select(0, bucket.expert_ids);
      const auto decoded =
          s.kind == Kind::kGrouped4
              ? torchao_cpu::f4_unpacked_to_f32(
                    torchao_cpu::unpack_uint4(encoded))
              : encoded.view(at::kFloat8_e4m3fn).to(at::kFloat);
      auto weight_scales = selected_scales.index_select(0, bucket.expert_ids);
      if (s.kind != Kind::kGrouped4)
        weight_scales =
            weight_scales.repeat_interleave(128, 1).slice(1, 0, s.n);
      const auto lhs = activation.index_select(0, bucket.activation_ids)
                           .reshape({experts, count, group});
      const auto dots = at::matmul(lhs, decoded.transpose(1, 2));
      const auto scaled =
          dots * activation_scales.index_select(0, bucket.activation_ids)
                     .reshape({experts, count, 1});
      const auto prior = accumulated.index_select(0, bucket.row_ids)
                             .reshape({experts, count, s.n});
      const auto next = prior + scaled * weight_scales.unsqueeze(1);
      accumulated.index_copy_(0, bucket.row_ids,
                              next.reshape({experts * count, s.n}));
    }
  }
  return accumulated.reshape({s.tokens, s.slots, s.n}).to(s.output);
}

struct Recorder final:at::Allocator{
  at::Allocator*original=c10::GetCPUAllocator();
  std::atomic<bool> active{false};std::mutex mutex;std::map<std::size_t,std::size_t> requests;
  at::DataPtr allocate(std::size_t n)override{
    if(active.load()){std::lock_guard lock(mutex);++requests[n];}
    return original->allocate(n);
  }
  void copy_data(void*d,const void*s,std::size_t n)const override{original->copy_data(d,s,n);}
  at::DeleterFnPtr raw_deleter()const override{return original->raw_deleter();}
};
void check(const at::Tensor&result,const Shape&s,const std::vector<std::int64_t>&ids){
  const auto values=result.to(at::kFloat).contiguous();const auto*p=values.const_data_ptr<float>();
  for(std::int64_t r=0;r<s.tokens*s.slots;++r)for(std::int64_t n=0;n<s.n;++n){
    const auto code=double(ids[std::size_t(r)]%3+1)*(s.kind==Kind::kGrouped4?.5:1);
    const auto expected=float(s.k*code*.5*(n%3==0?-1:1));
    if(p[r*s.n+n]!=expected)throw std::runtime_error("independent encoded-weight oracle differs");
  }
}
int main(){try{
  at::set_num_threads(2);at::NoGradGuard no_grad;static Recorder recorder;c10::SetCPUAllocator(&recorder,255);
  for(const bool four:{false,true})for(const std::int64_t tokens:{1,128})for(const bool shared:{true,false}){
    Shape s;s.kind=four?Kind::kGrouped4:Kind::kGrouped8;s.power=four;s.floor=four?1.e-4F:448.F;s.output=four?at::kBFloat16:at::kFloat;
    s.tokens=tokens;s.activations=shared?1:s.slots;
    std::printf("CASE tokens=%lld shared=%d\n",static_cast<long long>(tokens),int(shared));
    const auto group=four?32:128;
    const auto payload=s.e*s.n*s.k/(four?2:1),scale_rows=four?s.n:(s.n+127)/128;
    auto carrier=at::zeros({payload+s.e*scale_rows*(s.k/group)*4},at::kByte);
    auto*bytes=carrier.data_ptr<std::uint8_t>();
    for(std::int64_t e=0;e<s.e;++e)for(std::int64_t n=0;n<s.n;++n){
      const std::array<std::uint8_t,3> fp8{0x38,0x40,0x44};
      auto code=four?std::uint8_t(e%3+1):fp8[std::size_t(e%3)];
      if(n%3==0)code|=four?8:128;
      std::fill_n(bytes+(e*s.n+n)*(s.k/(four?2:1)),std::size_t(s.k/(four?2:1)),four?std::uint8_t(code|(code<<4)):code);
    }
    carrier.slice(0,payload).view(at::kFloat).fill_(.5);
    auto input=at::ones({s.tokens,s.activations,s.k},four?at::kBFloat16:at::kFloat);
    std::vector<std::int64_t> ids(std::size_t(s.tokens*s.slots));
    for(std::size_t i=0;i<ids.size();++i)ids[i]=std::int64_t((i*5+3)%std::size_t(s.e));
    const auto selected=at::tensor(ids,at::kLong);const auto w=weight(carrier,s,selected);
    auto a=quantize(input,s);a.codes=a.codes.reshape({s.tokens,s.activations,s.k});a.scales=a.scales.reshape({s.tokens,s.activations,s.k/128});
    const auto execute=[&](bool candidate){
      if(candidate)return grouped_block_dot(a,w,s);
      auto expanded=a;
      if(s.activations==1&&s.slots!=1){expanded.codes=expanded.codes.expand({s.tokens,s.slots,s.k});expanded.scales=expanded.scales.expand({s.tokens,s.slots,s.k/128});}
      return block_dot(expanded,w,s);
    };
    for(const bool candidate:{false,true}){
      check(execute(candidate),s,ids);recorder.requests.clear();recorder.active=true;
      const auto result=execute(candidate);recorder.active=false;check(result,s,ids);
      std::size_t bytes_total=0,calls=0;for(const auto&[n,count]:recorder.requests){bytes_total+=n*count;calls+=count;}
      std::printf("CENSUS fp4=%d candidate=%d max_request=%zu requested_bytes=%zu calls=%zu\n",int(four),int(candidate),recorder.requests.rbegin()->first,bytes_total,calls);
    }
    std::array<std::vector<double>,2> times;
    for(int repeat=-2;repeat<9;++repeat)for(int order=0;order<2;++order){
      const auto arm=(repeat&1)?1-order:order;
      const auto start=std::chrono::steady_clock::now();const auto result=execute(arm==1);
      const auto elapsed=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count();
      check(result,s,ids);if(repeat>=0)times[std::size_t(arm)].push_back(elapsed);
    }
    for(int arm=0;arm<2;++arm){auto v=times[std::size_t(arm)];std::sort(v.begin(),v.end());
      std::printf("DOT_ONLY fp4=%d candidate=%d median_us=%.3f samples_us=",int(four),arm,v[v.size()/2]);for(auto x:times[std::size_t(arm)])std::printf("%.3f,",x);std::puts("");}
  }
  std::puts("PASS exact product grouped_block_dot versus original block_dot; counterbalanced matched dot-only, activation expansion inside both timed paths.");return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
