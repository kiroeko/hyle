from pathlib import Path
import hashlib,json,os,subprocess,sys,time,difflib

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
BASE=ARCH/'optional-file-stream/windows/cpu_tests-link-inputs.json'
BEFORE=json.loads((OUT/'before-identities.json').read_text(encoding='utf-8-sig'))
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

oldready=read(ARCH/'native-ready-pages/windows/commands.json')
gr=next(r for r in reversed(oldready) if r['exit']==0 and any(v.replace('\\','/').endswith('src/graph_route_cpu/cpu_context.cc') for v in r['command']))
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':gr['command'][0],'CMAKE_C_COMPILER':gr['command'][0]})
env['VSLANG']='1033'
base=read(BASE)
dirs=[str(Path(v).parent) for v in base['command'] if v.lower().endswith('.lib') and Path(v).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(dirs))+os.pathsep+env['PATH']
def run(tag,cmd,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';row=dict(tag=tag,command=list(map(str,cmd)),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log');rows.append(row);save('commands.json',rows)
 print('START',stem,flush=True);started=time.monotonic()
 with (OUT/row['stdout']).open('wb') as so,(OUT/row['stderr']).open('wb') as se:
  r=subprocess.run(row['command'],cwd=OUT,env=env,stdout=so,stderr=se,timeout=timeout)
 row.update(exit=r.returncode,seconds=time.monotonic()-started);save('commands.json',rows);print('END',stem,r.returncode,flush=True)
 if r.returncode:
  print((OUT/row['stdout']).read_text(errors='replace')[-10000:]);print((OUT/row['stderr']).read_text(errors='replace')[-10000:]);raise SystemExit(r.returncode)
 return row
SOURCES={'compute-context':'src/compute_route_cpu/cpu_context.cc','graph-context':'src/graph_route_cpu/cpu_context.cc',
 'ggml-provider':'src/compute_provider_ggml/ggml_cpu_provider.cc','context-test':'tests/compute_route_cpu/context_test.cc'}
def freeze_sources():
 identities=[];patch=[]
 for r in BEFORE:
  src=ROOT/r['path'];dst=OUT/'candidate'/r['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
  identities.append(identity(src))
  patch.extend(difflib.unified_diff((OUT/'before'/r['path']).read_text().splitlines(keepends=True),src.read_text().splitlines(keepends=True),fromfile='before/'+r['path'],tofile='candidate/'+r['path']))
 (OUT/'source.diff').write_text(''.join(patch),encoding='utf-8',newline='\n');save('candidate-identities.json',identities)
def recipes():
 gg=next(r for r in reversed(read(ARCH/'retire-native-runtime/paging-risks/commands.json')) if r['exit']==0 and any(Path(v).name=='ggml_cpu_provider.cc' for v in r['command']))
 rows=[]
 for name,source in SOURCES.items():
  template=gg['command'] if name=='ggml-provider' else gr['command']
  flags=[v for v in template[1:] if not v.lower().startswith(('/fo','/fd')) and not v.lower().endswith('.cc')]
  if name=='context-test':
   flags+=['/DHYLE_TEST_GRAPH_ROUTE_CPU=1','/DHYLE_TEST_TORCH_CPU=1','/DHYLE_TEST_GGML_CPU=1']
   flags += [v for v in gg['command'] if v.lower().startswith('/external:i') or v.lower()=='/external:w0']
  cmd=[template[0],*flags,str(ROOT/source),'/Fo'+str(OUT/(name+'.obj'))]
  rows.append(dict(source=identity(ROOT/source),object=str(OUT/(name+'.obj')),command=cmd,origin='paging-risks last successful ggml provider compile' if name=='ggml-provider' else 'native-ready-pages last successful graph CPU context compile'))
 save('compile-recipes.json',rows);return rows
def compile_():
 freeze_sources();fresh=[]
 for row in recipes():
  if not Path(row['object']).is_file():run(Path(row['object']).stem+'-compile',row['command'])
  assert identity(row['source']['path'])==row['source']
  fresh.append(dict(source=row['source'],object=identity(row['object']),command=row['command']));save('fresh-identities.json',fresh)
def link():
 args=[];removed=[]
 replace={
  str(ARCH/'native-ready-pages/windows/graph_route_cpu--cpu_context.obj'):str(OUT/'graph-context.obj'),
  str(ARCH/'retire-native-runtime/paging-risks/ggml-cpu.obj'):str(OUT/'ggml-provider.obj')}
 for v in base['command'][1:]:
  if v.upper().startswith(('/OUT:','/MAP:')):continue
  if any(v==str(ARCH/'optional-file-stream/windows'/(n+'.obj')) for n in ['cpu_tests','cpu','common','sources']):removed.append(v);continue
  v=replace.get(v,v)
  args.append(v)
 args=[str(OUT/'context-test.obj'),str(OUT/'compute-context.obj'),*args]
 # Current same-ABI copy source owner from the completed CUDA bridge test.
 args=[str(ARCH/'optional-file-stream/cuda/batch-transfer-final.obj') if Path(v).name=='compute--batch_transfer.obj' else v for v in args]
 for v in [str(OUT/'graph-context.obj'),str(OUT/'ggml-provider.obj')]:assert v in args,v
 args=list(dict.fromkeys(args));objs=[v for v in args if v.lower().endswith('.obj')];rest=[v for v in args if not v.lower().endswith('.obj')]
 command=[base['command'][0],*objs,*rest,'/OUT:'+str(OUT/'context-tests.exe'),'/MAP:'+str(OUT/'context-tests.map')]
 save('link-plan.json',dict(command=command,removed=removed,replacements=replace,base=str(BASE)))
 save('link-identities.json',[identity(v) for v in command if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}])
 run('context-tests-link',command)
def execute():
 filters=['OneGgmlInstanceServesOrdinaryAndFusedGraphRoutes','MatureDefaultsHavePolicyWithoutModelOrHardwareProfile','ColdFailureReleasesPartialProviderAssembly','PlainAndTransposedMatricesKeepQualifiedDefaults','StableActivationDefaultUsesOriginalAtenProgram','LeasedGraphRetainsCallerOutputAndSourceAliasThroughDrain']
 run('context-tests-run',[OUT/'context-tests.exe','--gtest_filter='+':'.join('CpuDefaultContext.'+s for s in filters),'--gtest_color=no','--gtest_output=xml:'+str(OUT/'tests.xml')])
def shared():
 row=read(OUT/'compile-recipes.json')[0]
 cmd=[v for v in row['command'] if v!='/DHYLE_STATIC']
 cmd=[('/Fo'+str(OUT/'compute-context-shared.obj')) if v.lower().startswith('/fo') else v for v in cmd]
 cmd.insert(1,'/DHYLE_COMPUTE_ROUTE_CPU_BUILD=1')
 run('compute-context-shared-compile',cmd)
 run('compute-context-shared-exports',[Path(cmd[0]).with_name('dumpbin.exe'),'/nologo','/directives',OUT/'compute-context-shared.obj'])
 audit_shared()
def audit_shared():
 records=read(OUT/'commands.json')
 last=next(r for r in reversed(records) if r['tag']=='compute-context-shared-exports' and r['exit']==0)
 command=next(r['command'] for r in reversed(records) if r['tag']=='compute-context-shared-compile' and r['exit']==0)
 text=(OUT/last['stdout']).read_text(errors='replace')
 assert '/EXPORT:?create_context@internal@cpu@compute@hyle@@' in text,text
 save('shared-export-identity.json',dict(source=identity(ROOT/SOURCES['compute-context']),object=identity(OUT/'compute-context-shared.obj'),command=command,exports=last))
if __name__=='__main__':{'compile':compile_,'link':link,'run':execute,'shared':shared,'audit-shared':audit_shared,'freeze':freeze_sources}[sys.argv[1]]()
