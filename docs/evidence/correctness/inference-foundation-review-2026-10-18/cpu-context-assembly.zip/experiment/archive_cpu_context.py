from pathlib import Path
import hashlib
import json
import re
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


summary = json.loads((OUT / 'summary.json').read_text())
assert summary['result'] == 'PASS' and summary['tests'] == 6
assert '[  PASSED  ] 6 tests.' in (OUT / '007-context-tests-run.stdout.log').read_text()
text = (OUT / 'context-tests.map').read_text(errors='replace')
members = sorted(set(line.split()[-1] for line in text.splitlines()
                     if re.match(r'\s*[0-9A-Fa-f]{4}:[0-9A-Fa-f]+\s+\S+\s+[0-9A-Fa-f]{8,}\s+', line)))
(OUT / 'map-members.txt').write_text('\n'.join(members) + '\n')
write(OUT / 'map-identity.json', identity(OUT / 'context-tests.map'))
plan = dict(files=[identity(OUT / ('context-tests' + suffix)) for suffix in ['.exe', '.map', '.exp', '.lib']],
            retain=[identity(path) for path in sorted(OUT.glob('*.obj'))])
assert len(plan['retain']) == 5
write(OUT / 'cleanup-plan.json', plan)
files = {}
for path in OUT.rglob('*'):
    if path.is_file() and path.suffix in {'.json', '.txt', '.xml', '.py', '.ps1', '.log', '.diff', '.cc', '.h'}:
        if path.name not in {'archive-receipt.json', 'cleanup-result.json'}:
            files['experiment/' + path.relative_to(OUT).as_posix()] = path
for row in json.loads((OUT / 'candidate-identities.json').read_text()):
    path = ROOT / row['path']
    assert identity(path)['sha256'] == row['sha256']
    files['source/' + path.relative_to(ROOT).as_posix()] = path
for name in ['test.ps1', 'docs/architecture/compute-design.md', 'docs/developer/current-work.md']:
    files['source/' + name] = ROOT / name
files['cleanup-plan.json'] = OUT / 'cleanup-plan.json'
target = EVIDENCE / 'cpu-context-assembly.zip'
assert not target.exists()
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.writestr('archive-manifest.json', json.dumps([
        dict(entry=name, **identity(path)) for name, path in sorted(files.items())], indent=2) + '\n')
write(OUT / 'archive-receipt.json', identity(target))
print(json.dumps(dict(archive=identity(target), cleanup_files=len(plan['files']),
      cleanup_bytes=sum(row['bytes'] for row in plan['files']), retained_objects=len(plan['retain']))))
