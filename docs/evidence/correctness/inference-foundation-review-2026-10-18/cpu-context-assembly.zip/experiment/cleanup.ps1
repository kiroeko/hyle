param([switch]$ReclaimCpuContextAssembly)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not $ReclaimCpuContextAssembly) { throw 'Specify -ReclaimCpuContextAssembly; no default deletion.' }
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cpu-context-assembly'
function Get-CheckedFile($row) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $row.path))
    if (-not $path.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Outside workspace: $path"
    }
    $parent = [IO.Path]::GetDirectoryName($path)
    while ($parent.StartsWith($workspace, [StringComparison]::OrdinalIgnoreCase)) {
        if ((Get-Item -LiteralPath $parent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked ancestor: $parent" }
        $parent = [IO.Path]::GetDirectoryName($parent)
    }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $row.bytes -or
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $row.sha256) { throw "File changed: $path" }
    return $item
}
$receipt = Get-Content -LiteralPath (Join-Path $stage 'archive-receipt.json') -Raw | ConvertFrom-Json
$evidence = Get-CheckedFile $receipt
$zip = [IO.Compression.ZipFile]::OpenRead($evidence.FullName)
try {
    $reader = [IO.StreamReader]::new($zip.GetEntry('cleanup-plan.json').Open())
    try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if ($frozen -cne [IO.File]::ReadAllText((Join-Path $stage 'cleanup-plan.json'))) { throw 'Cleanup differs from archive' }
} finally { $zip.Dispose() }
$plan = $frozen | ConvertFrom-Json
$targets = @()
foreach ($row in $plan.files) {
    $item = Get-CheckedFile $row
    if ($item.DirectoryName -ne $stage -or $item.BaseName -ne 'context-tests' -or
        $item.Extension -notin @('.exe', '.map', '.exp', '.lib')) { throw "Unexpected image: $item" }
    $targets += $item
}
foreach ($row in $plan.retain) {
    $item = Get-CheckedFile $row
    if ($item.DirectoryName -ne $stage -or $item.Extension -ne '.obj') { throw "Unexpected retained object: $item" }
}
if ($targets.Count -ne 4 -or @($targets.FullName | Select-Object -Unique).Count -ne 4) { throw 'Unexpected image set' }
foreach ($item in $targets) { Remove-Item -LiteralPath $item.FullName -Force }
$result = @{ files = $targets.Count; bytes = ($targets | Measure-Object Length -Sum).Sum; retained_objects = @($plan.retain).Count; archive_verified = $true }
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $stage 'cleanup-result.json') -Encoding utf8
$result | ConvertTo-Json
