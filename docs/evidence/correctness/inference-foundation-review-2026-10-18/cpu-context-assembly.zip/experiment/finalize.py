import run as b
import xml.etree.ElementTree as ET

b.freeze_sources()
fresh=b.read(b.OUT/'fresh-identities.json')
for row in fresh:
 assert b.identity(row['source']['path'])==row['source']
 assert b.identity(row['object']['path'])==row['object']
for row in b.read(b.OUT/'candidate-identities.json'):
 assert b'\r' not in b.Path(row['path']).read_bytes()
suite=ET.parse(b.OUT/'tests.xml').getroot()
assert int(suite.attrib['tests'])==6 and int(suite.attrib['failures'])==0
text=(b.OUT/'context-tests.map').read_text(errors='replace')
map_rows=[]
for marker,owner in [
 ('?create_context@internal@cpu@compute@hyle@@','compute-context.obj'),
 ('?create_context@cpu@graph@hyle@@','graph-context.obj'),
 ('?provider@ggml_cpu@compute@hyle@@','ggml-provider.obj')]:
 rows=[line.strip() for line in text.splitlines() if marker in line and '$unwind$' not in line]
 assert rows and all(line.endswith(owner) for line in rows),(marker,rows)
 map_rows.extend(rows)
b.save('selected-map-owners.json',dict(map=b.identity(b.OUT/'context-tests.map'),symbols=map_rows))
b.save('cleanup-identities.json',[b.identity(p) for p in sorted(b.OUT.iterdir()) if p.suffix.lower() in {'.exe','.map','.exp','.lib'}])
b.save('retained-object-identities.json',[b.identity(p) for p in sorted(b.OUT.glob('*.obj'))])
summary=dict(
 result='PASS',tests=6,source_files=6,
 change='One real configured ggml CPU provider instance serves ordinary operations and its original region extension. Direct and Graph CPU factories use the same existing roster assembly; the duplicate ggml Graph slot is removed.',
 math_abi='No mathematics, public API/ABI, prepared/region tables, Context/Invocation/Plan layout or numerical kernel changed. The private cross-module assembly function has HYLE_COMPUTE_ROUTE_CPU_API and its actual shared-mode export is checked.',
 priorities=dict(graph_ggml_region=100,graph_ggml_ordinary=300,onednn_region=150,native_fallback=1000,direct_and_graph_scope='preserved; Graph startup-thread marking behavior deliberately unchanged'),
 actual_proof='OneGgmlInstanceServesOrdinaryAndFusedGraphRoutes counts exactly one ggml slot, requires the ordinary prepared operation and both fused/region-disabled Graph steps to select that exact provider_instance, checks region/leaf preferences100/300, and executes independent exp/-exp numeric oracles.',
 original_controls=['MatureDefaultsHavePolicyWithoutModelOrHardwareProfile','PlainAndTransposedMatricesKeepQualifiedDefaults','StableActivationDefaultUsesOriginalAtenProgram','ColdFailureReleasesPartialProviderAssembly','LeasedGraphRetainsCallerOutputAndSourceAliasThroughDrain'],
 analyzed_extension_assumptions='The only extension-dependent ordinary admission exclusion was ggml_cpu_provider.cc::propose. Existing prepare/runtime, batch and projected-read queries, compiled region callbacks and Configuration ownership already operate independently. No new callbacks or owner are needed.',
 risks=['Configured Graph provider indices change because one duplicate installation is removed; provider family and per-route selection preferences remain intact.','Validation is the six targeted current static CPU tests plus one shared-mode owner compile/export check; no complete shared math DLL link, full suite, model rerun or performance claim.'],
 compilation=dict(static_host_tus=4,shared_mode_same_owner_additional_compile=1,kernel_sdk_rebuild=False,closure='link-plan.json/link-identities.json; original CPU numerical cache reused'),
 evidence=dict(run='007-context-tests-run',shared_exports='009-compute-context-shared-exports',before='before/',candidate='candidate/',diff='source.diff',sources='candidate-identities.json',fresh='fresh-identities.json',map='selected-map-owners.json',shared='shared-export-identity.json',tests='tests.xml'),
 harness_notes=['004 test compilation lacked the existing ggml include path; cached matching provider include flags were added and 005 compiled successfully without changing product source.','Shared owner and dumpbin both passed008/009; the first local audit expected quoted EXPORT formatting, corrected to the actual unquoted MSVC directive without recompilation.'],
 cleanup='cleanup-identities.json; root test.ps1 only. All five objects, sources, logs and receipts retained. No file deleted or moved.')
b.save('summary.json',summary)
(b.OUT/'summary.md').write_text('''CPU context assembly now installs one original ggml CPU provider instance with both ordinary and region capabilities. Both default factories share one roster assembly. Original region100/ordinary Graph300 and fallback/provider scopes are preserved; Graph startup-thread behavior is unchanged.

Targeted **6/6 tests PASS** (007): the new test executes ordinary Exp and fused/region-disabled Exp→Neg, checking every selected provider_instance against the single actual ggml slot and retaining original preference100/300. Original defaults, oneDNN/ATen preference, cold assembly OOM rollback and GraphOutput/lease controls also pass.

Three product host TUs plus the existing context consumer compiled with strict flags. The same Compute context owner additionally compiled in shared mode; dumpbin009 confirms its private assembly export. Existing numerical libraries and kernels were reused, with no SDK rebuild or performance claim.

The six changed files are exact LF snapshots in before/candidate, with source.diff and byte/SHA receipts. Configured Graph provider indices naturally change when the duplicate slot is removed. This does not claim a full shared-DLL link or whole-suite/model validation. All initial harness errors remain logged. No files were deleted or moved; cleanup-identities.json lists only the rebuildable image/map/import-library candidates for root test.ps1.
''',encoding='utf-8',newline='\n')
print(b.identity(b.OUT/'summary.json'))
print(b.identity(b.OUT/'cleanup-identities.json'))
print(b.read(b.OUT/'cleanup-identities.json'))
