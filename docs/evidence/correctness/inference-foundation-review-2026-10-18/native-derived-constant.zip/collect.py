from pathlib import Path
import base64, hashlib, io, json, subprocess, tarfile
OUT=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-fusion-quantization-20261018-native-derived-constant'
code='''from pathlib import Path
import hashlib,json,tarfile,sys
r=Path(REMOTE)
names=['apple-old-graph.o','apple-tests.o','apple-context-census.o','apple-census-tests.o','apple-old','apple-new','apple-old-census','apple-new-census']
files=[dict(path=str(r/n),bytes=(r/n).stat().st_size,sha256=hashlib.sha256((r/n).read_bytes()).hexdigest())for n in names]
(r/'cleanup-candidates.json').write_text(json.dumps(dict(host='kiro@172.22.10.198',files=files,deleted=False,shared_objects_not_in_this_list=True),indent=2)+'\\n')
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in {'.log','.json','.map','.txt'}:t.add(p,arcname=p.name)
'''.replace('REMOTE',repr(REMOTE))
command='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
p=subprocess.run(['ssh','kiro@172.22.10.198',command],capture_output=True,timeout=40)
(OUT/'apple-collect.stderr.log').write_bytes(p.stderr);p.check_returncode()
(OUT/'apple-results.tar.gz').write_bytes(p.stdout)
dest=OUT/'apple-results';dest.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:gz')as t:
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in t.getmembers())
    t.extractall(dest,filter='data')
print('collected',len(p.stdout),'bytes',len(list(dest.iterdir())),'small result files')
