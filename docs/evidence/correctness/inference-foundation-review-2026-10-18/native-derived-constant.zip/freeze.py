from pathlib import Path
import difflib, hashlib, json, shutil, zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    names=['src/graph_route_apple/apple_lowering.cc','src/compute_route_vulkan/vulkan_program.cc','tests/graph_route_apple/tensor_test.cc','tests/compute_route_vulkan/managed_region_test.cc','tests/compute_models/derived_cast_fixture.h']
    hashes={}
    diff=[]
    for name in names:
        target=OUT/'applied'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
        hashes[name]=sha(target)
        before=OUT/('apple_lowering.baseline.cc' if name=='src/graph_route_apple/apple_lowering.cc' else 'before/'+name)
        text=before.read_text().splitlines(keepends=True) if before.exists() else []
        diff+=difflib.unified_diff(text,target.read_text().splitlines(keepends=True),fromfile='before/'+name,tofile='after/'+name)
    (OUT/'source.diff').write_text(''.join(diff),encoding='utf-8');dump(OUT/'source-sha.json',hashes)
    windows=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix.lower() in {'.obj','.exe','.lib','.exp','.pdb'}]
    apple=json.loads((OUT/'apple-results/cleanup-candidates.json').read_text())
    dump(OUT/'cleanup-candidates.json',dict(windows=windows,apple=apple,performed=False,retain='All sources/headers/commands/maps/logs/metadata/SDK and shared cached objects. Only exact generated products are candidates; parent owns final test.ps1 selection.'))
    summary=dict(status='implemented_focused_default_native_graph_tests_and_census_pass',committed=False,
      scope='Immutable plain dense rank2 BF16 Constant -> F32 Cast inside default public Apple/Vulkan Graph. No general expression evaluator, new SDK/shader, public ABI change or GEMM-route change. Explicitly published Cast and transitive View outputs keep their original paths; dynamic weights stay dynamic.',
      actual_model=dict(source='GLM mHC selected input[1,4,4096] -> reshape[1,16384] -> RMSNorm; BF16 weight[24,16384] -> CastF32 -> Permute -> MatMul. Same source mechanism, not full-model execution.',
          Apple='Captured BF16 matrix leaf is ready, but native compile_replace reconstructs its AsType for every call. Original Permute is a metadata view, not an independently asserted CONT.',
          Vulkan='Only direct MatMul RHS captures entered the existing cold pack. Cast output was not a capture; View propagation happened after packing. Actual native census confirmed the hot Cast and MatMul CONT.'),
      implementation=dict(Apple='One original Context::prepare Cast/Invocation bind+submit+checked wait produces a ready MLX array captured by the existing private Plan. Logical Cast Node and region input/output/control endpoints remain. MLX compile_replace reuses the ready leaf; no native output/producer filtering. Cache is scoped to one captured Plan/source value; duplicate Casts may share that source conversion.',
          Vulkan='After original SSA/schema validation, cold Cast uses original prepare/submit/checked wait. Program owns the derived Tensor; immutable Views are propagated before existing RHS packing/qualification. The original logical PlanStep stays as a managed-region boundary and its hot Cast is omitted. No physical producer table or public port is deleted; original single-native-queue dispatch order/control boundaries remain.',
          lifetime='Source examples/constants outlive accepted work; existing checked wait and invocation/work destructors retain/drain accepted prefixes on failure. Derived arrays/Tensors are retained by compiled lifetime and shared across invocation slots. Original BF16 consumers retain their source payload.'),
      tests=dict(geometry='rows2/K37/N7, actual rounded BF16 weights and nonbinary F32 activations, independent FP64 RMSNorm+MatMul. Six modes: immutable, dynamic phase changes, published Cast, published Permute, separate original BF16 Copy consumer, incoming TopK control endpoint. Two phases/two invocation slots, old native output payload kept alive and checked.',
          budget='F32 abs2e-6 + rel6e-6 unchanged; auxiliary BF16/F32 values exact where appropriate. No input/budget changes after failures.',
          Vulkan='6-vulkan-old-test.stdout.log / 8-vulkan-new-test.stdout.log: 1/1 PASS each; census copies also 1/1 each.',
          Apple='apple-results/4-apple-old-test.stdout.log / 6-apple-new-test.stdout.log: 1/1 PASS each; census copies also 1/1 each.',
          not_run=['full GLM model/numerical graph','throughput/latency','whole-device memory peak','OOM/cancel fault injection','full backend test suites']),
      census=dict(Vulkan=dict(raw=['12-vulkan-old-census-test.stderr.log','14-vulkan-new-census-test.stderr.log'],
            immutable_old='Each of two prepared invocation graphs: BF16->F32 Cast1; corresponding MatMul CONT1.',
            immutable_new='One cold conversion Cast1; both invocation graphs hot Cast0/MatMul CONT0.',
            controls='Dynamic and published Cast/View modes retain hot Cast1/MatMul CONT1. Original BF16 Copy consumer intentionally retains COPY1. TopK control-case CONT2 is its own existing work, retained.',
            limits='Counts inspect actual native ggml graphs created by each invocation, not undocumented internal shader/driver packing or a timing estimate.'),
        Apple=dict(raw=['apple-results/11-apple-old-census-test.stderr.log','apple-results/13-apple-new-census-test.stderr.log'],
            immutable_old='Each actual replay DAG contains BF16->F32 AsType1.',
            immutable_new='One cold Cast submission AsType1; each of two hot replay DAGs AsType0. Same for original BF16 other-consumer and explicit control modes.',
            controls='Dynamic and published Cast/View retain hot AsType1.',
            limits='Inspects unevaluated replay DAG immediately after compiled(inputs), before native eval. Original Permute remains a view. No claim that Metal GEMM has no private packing.')), 
      memory=dict(small_F32_derived_bytes=7*37*4,small_original_BF16_bytes=7*37*2,
          GLM_F32_derived_bytes=24*16384*4,GLM_original_BF16_bytes=24*16384*2,
          scope='Payload sizes, not measured native peaks. F32 payload is twice BF16. Apple retains original captures as well; Vulkan existing final referenced-owner sweep drops originals only when no other consumer needs them.'),
      closure=dict(Vulkan='Fresh old/new program.cc, current route region.cc, one canonical existing test TU; existing native SDK/shaders and current RowCache link closure reused. One extra instrumented native-region TU/test copy only for census.',
          Apple='Air Mac16,12 / M4 / 16 GiB / Apple clang21. Existing SDK and newly matched TopK-proof context/operations/recurrent/native/graph objects reused; candidate graph.o source SHA matched exact current canonical. Fresh old Graph strips only this task from the same current source, preserving TopK-proof code. One canonical existing test TU. Census adds only a scratch context/test TU.',
          private_ABI='No new shared private class fields: Apple Plan is local to apple_lowering.cc; Vulkan ProgramState layout unchanged. TopK-proof private Region header/5-host closure was matched as a separate concurrent change.'),
      source_proof=dict(pin='1f8e74e3f12f31365464a6867c6579f0e9b29d85',compile_current_sha256='d228e64777bec074a04f37c7333bde88b53f33330063eb547768a75197f37a3c',
          source='mlx-compile.current.cc recreated from local locked archive + exact current manifest and before/after SHA checked. compile_dfs/simplify/fuse have no matrix-constant eval; compile_replace(1049+) reconstructs primitive-backed nodes and reuses leaves. Hyle owner warmup does not mutate that cached tape.'),
      failures_retained=['Scratch-only Apple replay census first used typeid(a.primitive()) and failed -Wpotentially-evaluated-expression under -Werror. Bound primitive reference first; no product/numerical change. Failed source and log7 retained.'],
      identities=hashes,limits='No performance conclusion from gtest elapsed durations: initial JIT/cache state is unequal and these are correctness/census runs only. No cleanup or commit performed.')
    dump(OUT/'summary.json',summary)
    package=OUT/'source-results.zip'
    allow={'.cc','.h','.py','.json','.log','.txt','.map','.diff','.gz'}
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file() and p.suffix.lower() in allow and '__pycache__' not in p.parts:z.write(p,p.relative_to(OUT).as_posix())
    with zipfile.ZipFile(package)as z:
        assert z.testzip()is None
        assert all(hashlib.sha256(z.read('applied/'+name)).hexdigest()==value for name,value in hashes.items())
        assert not any(Path(name).suffix.lower() in {'.o','.obj','.exe','.lib','.exp','.pdb'}for name in z.namelist())
    print(json.dumps(dict(package=str(package),bytes=package.stat().st_size,sha256=sha(package),windows_products=len(windows),apple_products=len(apple['files']),sources=hashes),indent=2))
if __name__=='__main__':main()
