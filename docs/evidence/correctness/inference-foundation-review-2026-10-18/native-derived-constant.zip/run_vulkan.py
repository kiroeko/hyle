from pathlib import Path
import importlib.util, json, os, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('guarded_cache',ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
cache=json.loads((ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-vulkan/commands.json').read_text())
cc=next(x['command'] for x in cache if x['tag']=='row-cache-compile')
flags=[x for x in cc[1:] if not x.lower().startswith('/fo') and not x.endswith(('.cc','.cpp'))]
flags+=['/I'+str(ROOT),'/I'+str(ROOT/'src/compute_route_vulkan'),'/I'+str(ROOT/'src/compute_provider_ggml_vulkan'),'/I'+str(ROOT/'tests/compute_route_vulkan')]
env=dict(c.ENV);env['PATH']=str(ROOT/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
env.update(DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~')
records=json.loads((OUT/'vulkan-commands.json').read_text()) if(OUT/'vulkan-commands.json').exists() else []
def run(tag,cmd):
    cmd=list(map(str,cmd));stem=str(len(records)+1)+'-'+tag;start=time.monotonic()
    p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=180)
    (OUT/(stem+'.stdout.log')).write_bytes(p.stdout);(OUT/(stem+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=cmd,exit=p.returncode,seconds=time.monotonic()-start));(OUT/'vulkan-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(stem,p.returncode,p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-3500:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
def comp(source,name):run(name+'-compile',[cc[0],*flags,source,'/Fo'+str(OUT/(name+'.obj'))])
def build():
    for source,name in [(OUT/'before/src/compute_route_vulkan/vulkan_program.cc','vulkan-old-program'),(ROOT/'src/compute_route_vulkan/vulkan_program.cc','vulkan-new-program'),(ROOT/'src/compute_route_vulkan/vulkan_region.cc','vulkan-route-region'),(ROOT/'tests/compute_route_vulkan/managed_region_test.cc','vulkan-tests')]:comp(source,name)
def link(arm,census=False):
    command=next(x['command'] for x in reversed(cache) if x['tag']=='link')
    remove={'program.obj','route-region.obj','tests.obj'}
    command=[x for x in command if not x.startswith(('/OUT:','/MAP:')) and Path(x).name not in remove]
    if census:command=[x for x in command if Path(x).name!='vulkan-region.obj']
    exe=OUT/('vulkan-'+arm+('-census' if census else '')+'.exe')
    objects=[OUT/('vulkan-'+arm+'-program.obj'),OUT/'vulkan-route-region.obj',OUT/('vulkan-census-tests.obj' if census else 'vulkan-tests.obj')]
    if census:objects.append(OUT/'vulkan-native-census.obj')
    run(exe.stem+'-link',[*command,*objects,'/OUT:'+str(exe),'/MAP:'+str(exe.with_suffix('.map'))])
    run(exe.stem+'-test',[exe,'--gtest_filter=VulkanManaged.ImmutableBfloatCastCapturesOneReadyPayloadAndKeepsPublicValues','--gtest_color=no'])
def census():
    native=(ROOT/'src/compute_provider_ggml_vulkan/region.cc').read_text()
    marker='    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {\n      auto *node = ggml_graph_node(graph, i);'
    code='''    unsigned casts=0, copies=0, cont=0, matmul=0;
    for(int j=0;j<ggml_graph_n_nodes(graph);++j){
      const auto *n=ggml_graph_node(graph,j);
      casts+=n->op==GGML_OP_CPY && n->src[0] && n->type!=n->src[0]->type;
      copies+=n->op==GGML_OP_DUP || (n->op==GGML_OP_CPY && n->src[0] && n->type==n->src[0]->type);
      cont+=n->op==GGML_OP_CONT;matmul+=n->op==GGML_OP_MUL_MAT;
    }
    std::fprintf(stderr,"NATIVE_GRAPH recipe=%zu CAST=%u COPY=%u CONT=%u MATMUL=%u\\n",recipe.nodes.size(),casts,copies,cont,matmul);
'''
    assert native.count(marker)==1
    path=OUT/'vulkan-native-census.cc';path.write_text('#include <cstdio>\n'+native.replace(marker,code+marker))
    comp(path,'vulkan-native-census')
    test=(ROOT/'tests/compute_route_vulkan/managed_region_test.cc').read_text()
    marker='    f::Fixture fixture(mode);'
    assert test.count(marker)==1
    path=OUT/'vulkan-census-tests.cc';path.write_text('#include <cstdio>\n'+test.replace(marker,'    std::fprintf(stderr,"CASE mode=%d\\n",mode);\n'+marker))
    comp(path,'vulkan-census-tests')
    link('old',True);link('new',True)
if __name__=='__main__':
    for action in sys.argv[1:]:
        if action=='build':build()
        elif action=='census':census()
        else:link(action)
