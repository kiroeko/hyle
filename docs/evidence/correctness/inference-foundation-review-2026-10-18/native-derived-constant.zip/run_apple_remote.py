from pathlib import Path
import hashlib, json, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'inference-foundation-review-20261018-apple-topk-index-proof'
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
cache=json.loads((OLD/'commands.json').read_text())
base_compile=next(x['command'] for x in cache if x['tag']=='graph.o-compile')
base_link=next(x['command'] for x in cache if x['tag']=='canonical-link')
records=json.loads((ROOT/'commands.json').read_text()) if(ROOT/'commands.json').exists() else []
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):
    path=Path(path);return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
def run(tag,args):
    args=list(map(str,args));stem=str(len(records)+1)+'-'+tag;start=time.monotonic()
    p=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=180)
    (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=args,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start));(ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(stem,p.returncode,p.stdout.decode(errors='replace')[-3800:],p.stderr.decode(errors='replace')[-12000:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
def comp(source,name):
    prefix=base_compile[:base_compile.index('-c')]
    prefix[1:1]=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),'-I'+str(ROOT/'src/compute'),'-I'+str(ROOT/'src/graph_route_apple'),'-I'+str(ROOT/'tests/graph_route_apple')]
    run(name+'-compile',prefix+['-c',ROOT/source,'-o',ROOT/(name+'.o')])
def build():
    assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
    (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
    assert sha(ROOT/'src/graph_route_apple/apple_lowering.cc')==sha(OLD/'src/graph_route_apple/apple_lowering.cc')
    if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
    comp('apple_lowering.baseline.cc','apple-old-graph')
    comp('tests/graph_route_apple/tensor_test.cc','apple-tests')
def link(arm,census=False):
    exe=ROOT/('apple-'+arm+('-census' if census else ''))
    command=[]
    for arg in base_link:
        if arg==str(OLD/'canonical'):arg=str(exe)
        elif arg==str(OLD/'graph.o') and arm=='old':arg=str(ROOT/'apple-old-graph.o')
        elif arg==str(OLD/'test.o'):arg=str(ROOT/('apple-census-tests.o' if census else 'apple-tests.o'))
        elif arg==str(OLD/'context.o') and census:arg=str(ROOT/'apple-context-census.o')
        elif arg.startswith('-Wl,-map,'):arg='-Wl,-map,'+str(exe)+'.map'
        command.append(arg)
    run(exe.name+'-link',command)
    (ROOT/(exe.name+'-identities.json')).write_text(json.dumps([identity(p) for p in command if p.endswith(('.o','.a','.dylib'))]+[identity(exe)],indent=2)+'\n')
    run(exe.name+'-test',[exe,'--gtest_filter=AppleGraph.ImmutableBfloatCastCapturesOneReadyPayloadAndKeepsPublicValues','--gtest_color=no'])
def census():
    comp('apple-context-census.cc','apple-context-census')
    comp('apple-census-tests.cc','apple-census-tests')
    link('old',True);link('new',True)
if __name__=='__main__':
    for action in sys.argv[1:]:
        if action=='build':build()
        elif action=='census':census()
        else:link(action)
