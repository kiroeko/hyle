from pathlib import Path
import base64, hashlib, io, json, re, subprocess, tarfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-fusion-quantization-20261018-native-derived-constant'
def prepare():
    source=(ROOT/'src/graph_route_apple/apple_lowering.cc').read_text()
    baseline=source
    field='  // Only immutable rank2 BF16 -> F32 Casts, evaluated on the existing owner\n  // before tracing. Logical nodes/control boundaries stay in this plan.\n  std::vector<std::optional<mx::array>> prepared_casts;\n'
    assert baseline.count(field)==1;baseline=baseline.replace(field,'')
    start=baseline.index('Status prepare_constant_casts(');end=baseline.index('Result<std::vector<mx::array>> trace(',start)
    baseline=baseline[:start]+baseline[end:]
    block='''    if (node.outputs.size() == 1 && !plan.prepared_casts.empty() &&
        plan.prepared_casts[node.outputs[0]]) {
      values[node.outputs[0]] = *plan.prepared_casts[node.outputs[0]];
      continue; // Captured ready array: MLX compile_replace reuses this leaf.
    }
'''
    assert baseline.count(block)==1;baseline=baseline.replace(block,'')
    call='    HYLE_RETURN_IF_ERROR(prepare_constant_casts(context, graph, *plan));\n'
    assert baseline.count(call)==1;baseline=baseline.replace(call,'')
    (OUT/'apple_lowering.baseline.cc').write_text(baseline)
    context=(ROOT/'src/compute_route_apple/apple_context.cc').read_text()
    marker='  outputs = program.compiled(inputs);\n'
    assert context.count(marker)==1
    code='''  {
    std::unordered_set<std::uintptr_t> visited;
    unsigned cast_count=0;
    std::function<void(const mx::array&)> visit=[&](const mx::array &a){
      if(!visited.insert(a.id()).second || a.status()==mx::array::available || !a.has_primitive())return;
      const auto &primitive=a.primitive();
      if(typeid(primitive)==typeid(mx::AsType) && a.dtype()==mx::float32 &&
          a.inputs()[0].dtype()==mx::bfloat16)++cast_count;
      for(const auto &in:a.inputs())visit(in);
    };
    for(const auto &out:outputs)visit(out);
    std::fprintf(stderr,"MLX_RUNTIME BF16_F32=%u\\n",cast_count);
  }
'''
    (OUT/'apple-context-census.cc').write_text('#include <cstdio>\n#include <unordered_set>\n'+context.replace(marker,marker+code))
    test=(ROOT/'tests/graph_route_apple/tensor_test.cc').read_text();marker='    f::Fixture fixture(mode);'
    assert test.count(marker)==1
    (OUT/'apple-census-tests.cc').write_text('#include <cstdio>\n'+test.replace(marker,'    std::fprintf(stderr,"CASE mode=%d\\n",mode);\n'+marker))
    files={name:OUT/name for name in ['run_apple_remote.py','apple_lowering.baseline.cc','apple-context-census.cc','apple-census-tests.cc']}
    seen=set()
    def add(path):
        path=path.resolve()
        if path in seen:return
        seen.add(path)
        if path.is_relative_to(ROOT) and '.scratch' not in path.relative_to(ROOT).parts:files[path.relative_to(ROOT).as_posix()]=path
        for rel in re.findall(r'^\s*#\s*include\s*"([^\"]+)"',path.read_text(encoding='utf-8-sig'),re.M):
            for q in [path.parent/rel,ROOT/rel,ROOT/'include'/rel,ROOT/'src/compute_route_apple'/rel]:
                if q.is_file():add(q);break
    for path in [ROOT/'src/graph_route_apple/apple_lowering.cc',ROOT/'src/compute_route_apple/apple_context.cc',ROOT/'tests/graph_route_apple/tensor_test.cc']:add(path)
    items=[dict(path=k,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for k,p in sorted(files.items())]
    (OUT/'apple-staged-sources.json').write_text(json.dumps(items,indent=2)+'\n')
    data=io.BytesIO()
    with tarfile.open(fileobj=data,mode='w:gz')as archive:
        for name,path in files.items():archive.add(path,arcname=name)
    (OUT/'apple-minimal-sources.tar.gz').write_bytes(data.getvalue())
    script='from pathlib import Path;import tarfile,io,sys;r=Path('+repr(REMOTE)+');assert not r.exists();r.mkdir();t=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in t.getmembers());t.extractall(r);print(r)'
    cmd='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(script.encode()).decode()+'\'))"'
    p=subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=data.getvalue(),capture_output=True,timeout=40)
    (OUT/'apple-stage.stdout.log').write_bytes(p.stdout);(OUT/'apple-stage.stderr.log').write_bytes(p.stderr)
    print('stage',p.returncode,len(files),len(data.getvalue()),p.stdout.decode(),p.stderr.decode());p.check_returncode()
if __name__=='__main__':prepare()
