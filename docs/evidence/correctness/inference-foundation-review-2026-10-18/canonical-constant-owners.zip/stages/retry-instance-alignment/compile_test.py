from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
tag = sys.argv[1] if len(sys.argv) > 1 else 'compile'
object_name = 'region_provider_test.obj' if tag == 'compile' else 'region_provider_test-' + tag + '.obj'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

command = json.loads((ROOT / '.scratch/architecture-refactor-2026-10-18/exclusive-native-input/compile.json').read_text())['command']
command = [('/Fo' + str(OUT / object_name))
           if arg.lower().startswith('/fo') else arg for arg in command]
cache = {}
for line in (ROOT / '.scratch/build-compute-v2-dev/CMakeCache.txt').read_text(encoding='utf-8').splitlines():
    if line and not line.startswith(('#', '//')) and '=' in line and ':' in line.split('=', 1)[0]:
        key, value = line.split('=', 1)
        cache[key.split(':', 1)[0]] = value
environment = windows_compiler_environment(cache)
environment['VSLANG'] = '1033'
identities = []
for name in ['tests/graph/region_provider_test.cc', 'src/graph/plan_state.h',
             'src/graph/constant_artifact.h', 'include/hyle/graph/region_provider.h']:
    data = (ROOT / name).read_bytes()
    identities.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
started = time.monotonic()
result = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True,
                        timeout=180, creationflags=subprocess.CREATE_NO_WINDOW)
(OUT / (tag + '.stdout.log')).write_bytes(result.stdout)
(OUT / (tag + '.stderr.log')).write_bytes(result.stderr)
record = dict(command=command, exit=result.returncode, seconds=time.monotonic()-started,
              source_identities=identities, status='compile only; parent links matched control/candidate')
(OUT / (tag + '.json')).write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps({key: record[key] for key in ['exit', 'seconds']}))
if result.returncode:
    print(result.stdout.decode(errors='replace')[-4000:])
    print(result.stderr.decode(errors='replace')[-2000:])
raise SystemExit(result.returncode)
