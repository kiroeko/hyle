from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    'immutable_alias_driver', ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.OUT = OUT

if __name__ == '__main__':
    driver.run('executable-test-compile', [driver.cc[0], *driver.flags,
        ROOT / 'tests/graph/executable_test.cc',
        '/Fo' + str(OUT / 'executable_test.obj')])
