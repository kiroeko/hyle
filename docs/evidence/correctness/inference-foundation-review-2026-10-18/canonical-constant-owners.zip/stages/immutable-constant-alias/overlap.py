import build

build.driver.run('executable-test-overlap-compile', [
    build.driver.cc[0], *build.driver.flags,
    build.ROOT / 'tests/graph/executable_test.cc',
    '/Fo' + str(build.OUT / 'executable_test-overlap.obj')])
