import build

build.driver.run('executable-test-rank5-compile', [
    build.driver.cc[0], *build.driver.flags,
    build.ROOT / 'tests/graph/executable_test.cc',
    '/Fo' + str(build.OUT / 'executable_test-rank5.obj')])
