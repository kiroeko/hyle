from pathlib import Path
import hashlib, importlib.util, json, sys

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('driver',ROOT/'.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.OUT=OUT
history=json.loads((ROOT/'.scratch/architecture-refactor-2026-10-18/vulkan-constant-copy/commands.json').read_text())
cc=next(r['command'] for r in reversed(history) if r['tag']=='native-tests-compile' and r['exit']==0)
flags=[a for a in cc[1:] if not a.lower().startswith('/fo') and not a.endswith('.cc')]

def identity(path):
    p=Path(path)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def main():
    if '--resume' not in sys.argv[1:]:
        b.run('native-test-compile',[cc[0],*flags,ROOT/'tests/graph_route_vulkan/native_region_test.cc','/Fo'+str(OUT/'tests.obj')])
    old=next(r['command'] for r in reversed(history) if r['tag']=='native-tests-link' and r['exit']==0)
    skip={'executable.obj','resources.obj','region_access.obj','constant_artifact.obj','execution_source.obj','source.obj','tests.obj','region.obj'}
    command=[old[0]]
    for arg in old[1:]:
        p=Path(arg)
        if arg.startswith(('/OUT:','/MAP:')):continue
        if p.suffix=='.obj' and p.name in skip:continue
        command.append(arg)
    core=ROOT/'.scratch/architecture-refactor-2026-10-18/canonical-constants'
    command += [str(core/(name+'.obj')) for name in ['executable','resources','region_access']]
    command += [str(ROOT/'.scratch/architecture-refactor-2026-10-18/canonical-constants-cache/constant_artifact-retry.obj'),
                str(ROOT/'.scratch/architecture-refactor-2026-10-18/readonly-resource/execution_source.obj')]
    native=ROOT/'.scratch/architecture-refactor-2026-10-18/finite-native-migration'
    command += [str(native/(name+'.obj')) for name in ['vulkan-source','vulkan-region']]
    command += [str(OUT/'tests.obj'),'/OUT:'+str(OUT/'native-tests.exe'),'/MAP:'+str(OUT/'native-tests.map')]
    (OUT/'input-identities.json').write_text(json.dumps([identity(arg) for arg in command if Path(arg).is_file()]+[
        identity(ROOT/'tests/graph_route_vulkan/native_region_test.cc'),
        *[identity(ROOT/name) for name in ['src/graph/plan_state.h','src/graph/executable.cc','src/graph/resources.cc',
            'src/graph/region_access.cc','src/graph/constant_artifact.h','src/graph/constant_artifact.cc']]],indent=2)+'\n')
    b.run('native-test-link',command)
    b.run('native-test-run',[OUT/'native-tests.exe','--gtest_filter=VulkanNativeRegion.*','--gtest_color=no',
                            '--gtest_output=json:'+str(OUT/'test-results.json')])
    (OUT/'summary.json').write_text(json.dumps(dict(scope='Original VulkanNativeRegion 4 cases only; current canonical cache/core',
        result=json.loads((OUT/'test-results.json').read_text()),fresh=['tests/graph_route_vulkan/native_region_test.cc'],
        reused='Matched prior Vulkan runtime/native/SDK; current 4 PlanState readers and ABI21 native Source/Region',
        output=identity(OUT/'native-tests.exe')),indent=2)+'\n')
    print('4-case stage complete',flush=True)

if __name__=='__main__':main()
