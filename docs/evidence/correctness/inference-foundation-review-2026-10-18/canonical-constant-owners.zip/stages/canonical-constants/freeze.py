from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/canonical-constant-owners.zip'
STAGES = ['canonical-constants', 'canonical-constants-cache',
          'canonical-constants-vulkan', 'retry-instance-alignment',
          'immutable-constant-alias']
SOURCES = '''
src/graph/executable.cc
src/graph/constant_artifact.cc
src/graph/constant_artifact.h
src/graph/plan_state.h
src/graph/storage_budget.h
src/graph/resources.cc
src/graph/region_access.cc
include/hyle/graph/region_provider.h
tests/graph/CMakeLists.txt
tests/graph/constant_artifact_cache_test.cc
tests/graph/executable_test.cc
tests/graph/region_provider_test.cc
tests/graph_route_vulkan/native_region_test.cc
'''.split()


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=path.relative_to(ROOT).as_posix(),
                bytes=path.stat().st_size, sha256=digest.hexdigest())


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    # The individual raw run logs remain authoritative, including initial
    # fixture mistakes. Only successful completed runs enter final claims.
    candidate = json.loads((OUT / 'candidate-results.json').read_text())
    vulkan = json.loads((ARCH / 'canonical-constants-vulkan/test-results.json').read_text())
    assert candidate['tests'] == 13 and candidate['failures'] == 0
    names = {test['name'] for suite in candidate['testsuites']
             for test in suite['testsuite']}
    assert {'ImmutableConstantsAndTheirViewsNeverUseDestructiveAliases',
            'DomainConstantViewChecksActualPortAlignmentBeforeEnqueue',
            'RetryRebuildsPhysicalInstanceAlignmentsWithoutRejectedRequirements'} <= names
    assert vulkan['tests'] == 4 and vulkan['failures'] == 0
    root_commands = json.loads((OUT / 'commands.json').read_text())
    latest = next(row for row in reversed(root_commands)
                  if row['tag'] == 'candidate-controls-run')
    assert latest['exit'] == 0
    closure = next(row['command'] for row in reversed(root_commands)
                   if row['tag'] == 'controls-link')
    objects = sorted({Path(arg).resolve() for arg in closure
                      if Path(arg).suffix.lower() == '.obj' and Path(arg).is_file()})
    dump('final-identities.json', {
        'sources': [identity(ROOT / path) for path in SOURCES],
        'actual_final_host_objects': [identity(path) for path in objects],
        'native_validation': 'canonical-constants-vulkan/input-identities.json',
    })
    dump('summary.json', {
        'scope': 'Per-allocation canonical constant ownership and cold family sharing; partial architecture migration',
        'actual_host_result': candidate,
        'actual_vulkan_result': vulkan,
        'isolated_controls': [
            '14: reverting only retry alignment clear/reserve yields 4 alignment entries for 2 instances and stale 256',
            '29: disabling only actual binding alignment checking accepts the invalid +4B/min64 input, submits and overwrites sentinel output',
            '31: pre-guard core accepts a real writable output range overlapping a borrowed constant; final core rejects it',
        ],
        'changes': [
            'Family-local cache keyed by logical constant, exact description, actual resource and sufficient allocation alignment',
            'Ready compatible copies survive rejected candidates; original sources restored for every candidate',
            'Obsolete rejected allocations released before replacement; exact shared bytes charged once across selected Plans',
            'Parallel physical-instance alignment metadata rebuilt on retry',
            'Alias alignment uses total root-relative offset; actual dynamic View offsets checked before enqueue',
            'Constants and metadata Views rooted in them excluded from optional destructive in-place aliases',
        ],
        'limits': [
            'Goal remains active; this is not complete inference-architecture acceptance',
            'Vulkan original four tests use frozen root09 core, before the later optional-alias guard; identities retained',
            'Initial domain and immutable test-fixture construction/qualification failures retained, not product regression evidence',
            'Cross-storage immutable replicas, ordinary CPU/native replay transfers and native region cut discovery remain',
            'No complete Qwen rerun, numerical acceptance, throughput comparison, Linux or new Apple validation in this batch',
            'Existing SDK and native caches reused; no binaries, objects or SDK copied into evidence',
        ],
    })
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source in SOURCES:
            archive.write(ROOT / source, 'final-source/' + source)
        for name in STAGES:
            stage = ARCH / name
            for path in sorted(stage.rglob('*')):
                if not path.is_file() or '__pycache__' in path.parts:
                    continue
                if path.suffix.lower() in {'.py', '.json', '.log', '.cc', '.h', '.diff', '.txt'}:
                    if path.parent == OUT and path.name in {'archive.json', 'cleanup.json', 'cleanup-result.json'}:
                        continue
                    archive.write(path, 'stages/' + path.relative_to(ARCH).as_posix())
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
    receipt = identity(DEST)
    dump('archive.json', receipt)
    allowed = [ARCH / name for name in STAGES]
    files = [identity(path) for stage in allowed for path in sorted(stage.iterdir())
             if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.lib', '.exp'}]
    dump('cleanup.json', {'evidence': receipt['path'],
        'allowed': [stage.relative_to(ROOT).as_posix() for stage in allowed], 'files': files})
    print(json.dumps({'archive': receipt, 'reclaim_files': len(files),
        'reclaim_bytes': sum(row['bytes'] for row in files)}))


if __name__ == '__main__':
    main()
