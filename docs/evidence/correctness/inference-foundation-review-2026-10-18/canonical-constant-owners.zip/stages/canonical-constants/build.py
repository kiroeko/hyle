from pathlib import Path
import importlib.util
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('host',
    ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT

if __name__ == '__main__':
    for source in sys.argv[1:]:
        b.run(Path(source).stem + '-compile', [b.cc[0], *b.flags, ROOT / source,
            '/Fo' + str(OUT / (Path(source).stem + '.obj'))])
