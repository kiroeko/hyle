from pathlib import Path
import json
import os
import sys
import build

ROOT, OUT, b = build.ROOT, build.OUT, build.b
ARCH = OUT.parent
previous = json.loads((ARCH / 'finite-native-migration/commands.json').read_text())

def before_compile():
    source = (ROOT / 'src/graph/executable.cc').read_text(encoding='utf-8')
    for statement in ['  plan.instance_alignments.clear();\n',
                      '      !plan.instance_alignments.try_reserve(maximum_instances) ||\n']:
        assert source.count(statement) == 1
        source = source.replace(statement, '')
    target = OUT / 'executable-alignment-before.cc'
    target.write_bytes(source.encode('utf-8'))
    b.run('alignment-before-compile', [b.cc[0], *b.flags, target,
          '/Fo' + str(OUT / 'executable-alignment-before.obj')])

def domain_before_compile():
    source = (ROOT / 'src/graph/executable.cc').read_text(encoding='utf-8')
    start = source.index('Status validate_known_binding_alignment(')
    body = source.index('{', start)
    end = source.index('\nStatus project_generated_output(', body)
    source = source[:body] + '''{
  (void)invocation;
  (void)instance;
  (void)view;
  return Status::Ok();
}
''' + source[end:]
    target = OUT / 'executable-domain-before.cc'
    target.write_bytes(source.encode('utf-8'))
    b.run('domain-before-compile', [b.cc[0], *b.flags, target,
          '/Fo' + str(OUT / 'executable-domain-before.obj')])

def link(before=False, immutable_before=False, domain_before=False):
    old = next(row['command'] for row in reversed(previous) if row['tag'] == 'controls-link')
    replacements = {
        'executable.obj': OUT / ('executable-alignment-before.obj' if before else
                                'executable-immutable-before.obj' if immutable_before else
                                'executable-domain-before.obj' if domain_before else 'executable.obj'),
        'resources.obj': OUT / 'resources.obj',
        'region_access.obj': OUT / 'region_access.obj',
        'constant_artifact.obj': ARCH / 'canonical-constants-cache/constant_artifact-retry.obj',
        'region_provider_test.obj': ARCH / 'retry-instance-alignment/region_provider_test-domain-instantiation.obj',
        'executable_test.obj': ARCH / 'immutable-constant-alias/executable_test-overlap.obj',
    }
    name = 'before-controls' if before else 'immutable-before-controls' if immutable_before else 'domain-before-controls' if domain_before else 'controls'
    command = []
    for arg in old:
        if arg.upper().startswith('/OUT:'):
            command.append('/OUT:' + str(OUT / (name + '.exe')))
        elif arg.upper().startswith('/MAP:'):
            command.append('/MAP:' + str(OUT / (name + '.map')))
        else:
            command.append(str(replacements.get(Path(arg).name.lower(), arg)))
    command.append(str(ARCH / 'canonical-constants-cache/constant_artifact_cache_test.obj'))
    b.run(name + '-link', command)
    torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
    os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
    return OUT / (name + '.exe')

if __name__ == '__main__':
    if '--compile-before' in sys.argv:
        before_compile()
    elif '--compile-domain-before' in sys.argv:
        domain_before_compile()
    else:
        before = '--before' in sys.argv
        immutable_before = '--immutable-before' in sys.argv
        domain_before = '--domain-before' in sys.argv
        assert sum([before, immutable_before, domain_before]) <= 1
        executable = link(before, immutable_before, domain_before)
        selected = next(arg.split('=', 1)[1] for arg in sys.argv if arg.startswith('--filter='))
        label = 'before' if before else 'immutable-before' if immutable_before else 'domain-before' if domain_before else 'candidate'
        b.run(label + '-controls-run', [executable,
            '--gtest_color=no', '--gtest_filter=' + selected,
            '--gtest_output=json:' + str(OUT / (label + '-results.json'))])
