import build

build.driver.run('constant-artifact-retry-compile', [
    build.driver.cc[0], *build.driver.flags,
    build.ROOT / 'src/graph/constant_artifact.cc',
    '/Fo' + str(build.OUT / 'constant_artifact-retry.obj')])
