#include <gtest/gtest.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>
#include <utility>

#include "../../src/graph/constant_artifact.h"
#include "../../src/graph/plan_state.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace d = hyle::graph::detail;
namespace m = hyle::mem;

class TrackedHostResource final : public m::MemoryResource {
public:
  std::size_t allocations = 0;
  std::size_t live_allocations = 0;
  bool fail_allocation = false;
  const c::ResourceBudget *observed_budget = nullptr;
  bool deallocated_with_constant_charge = false;

  std::string_view name() const noexcept override { return "canonical.test.host"; }
  m::MemoryProperties properties() const noexcept override {
    // Both distinct real resources share host accessibility and coherence;
    // canonical allocation identity must still remain exact.
    return m::system_resource().properties();
  }
  hyle::Result<m::ResourceAllocation>
  allocate(std::size_t size, std::size_t alignment) noexcept override {
    if (fail_allocation)
      return std::unexpected(hyle::Status::ResourceExhausted(
          "canonical test allocation failure"));
    auto result = m::system_resource().resource().allocate(size, alignment);
    if (result) {
      ++allocations;
      ++live_allocations;
    }
    return result;
  }
  void deallocate(m::ResourceAllocation allocation) noexcept override {
    if (observed_budget) {
      const auto usage = observed_budget->usage(m::MemoryResourceRef(*this));
      deallocated_with_constant_charge =
          usage && usage->live_by_category[static_cast<std::size_t>(
                       c::ResourceBudgetCategory::kConstant)] >= allocation.size;
    }
    --live_allocations;
    m::system_resource().resource().deallocate(allocation);
  }
  hyle::Result<m::ResourceHostMapping>
  map_host(void *handle, std::size_t offset, std::size_t bytes,
           m::HostAccess access) noexcept override {
    return m::system_resource().resource().map_host(handle, offset, bytes, access);
  }
  hyle::Status unmap_host(void *handle, void *token, std::size_t offset,
                         std::size_t bytes, m::HostAccess access) noexcept override {
    return m::system_resource().resource().unmap_host(handle, token, offset,
                                                    bytes, access);
  }
};

struct LogicalConstant final {
  c::TensorDesc description = c::TensorDesc::dense(
      c::DataType::kFloat32, std::array<std::int64_t, 1>{4}).value();
  g::Graph graph;
  g::ValueId value;
  m::Buffer source;
  c::ConstTensorView binding;

  LogicalConstant() {
    auto builder = g::GraphBuilder::create().value();
    value = builder.constant(description).value();
    EXPECT_TRUE(builder.publish(value).ok());
    graph = std::move(builder).finish().value();
    source = m::Buffer::create(m::system_resource(),
        description.required_bytes().value(), 64).value();
    const std::array values{1.0F, -2.0F, 3.0F, -4.0F};
    EXPECT_TRUE(source.write(0, std::as_bytes(std::span(values))).ok());
    binding = c::ConstTensorView::create(description, source.view()).value();
  }
  std::uint64_t generation() const {
    return d::GraphAccess::state(graph)->generation;
  }
};

void initialize(d::PlanState &plan, const LogicalConstant &constant,
                std::span<const m::MemoryResourceRef> resources) {
  ASSERT_TRUE(plan.constant_ids.try_push_back(constant.value));
  ASSERT_TRUE(plan.constant_bindings.try_push_back(constant.binding));
  ASSERT_TRUE(plan.canonical_constants.try_resize(1));
  ASSERT_TRUE(plan.descriptions.try_resize(constant.value.ordinal() + 1));
  plan.descriptions[constant.value.ordinal()] = constant.description;
  for (auto resource : resources)
    ASSERT_TRUE(plan.storage_domains.try_push_back({.resource = resource}));
}

void copy_and_ready(d::CanonicalConstantState &owner,
                    const LogicalConstant &constant) {
  std::array<std::byte, 16> bytes{};
  ASSERT_TRUE(constant.source.view().read(bytes).ok());
  ASSERT_TRUE(owner.buffer.write(0, bytes).ok());
  owner.ready = true;
}

void expect_contents(const m::Buffer &buffer) {
  std::array<float, 4> actual{};
  ASSERT_TRUE(buffer.view().read(std::as_writable_bytes(std::span(actual))).ok());
  EXPECT_EQ(actual, (std::array{1.0F, -2.0F, 3.0F, -4.0F}));
}

TEST(CanonicalConstantCache, ReadyOwnersKeepExactResourcesAndDescriptions) {
  TrackedHostResource first, second, foreign;
  const std::array resources{m::MemoryResourceRef(first),
                             m::MemoryResourceRef(second)};
  const LogicalConstant constant;
  d::PlanState original(m::system_allocator(), constant.generation());
  d::PlanState same(m::system_allocator(), constant.generation());
  d::PlanState another(m::system_allocator(), constant.generation());
  initialize(original, constant, resources);
  initialize(same, constant, resources);
  initialize(another, constant, resources);
  d::ConstantArtifactCache cache;
  ASSERT_TRUE(cache.begin_candidate().ok());
  auto invalid = cache.acquire_canonical(original, 0, resources[0], 3);
  ASSERT_FALSE(invalid);
  EXPECT_TRUE(invalid.error().IsInvalidArgument());
  auto unconfigured = cache.acquire_canonical(
      original, 0, m::MemoryResourceRef(foreign), 64);
  ASSERT_FALSE(unconfigured);
  EXPECT_TRUE(unconfigured.error().IsInvalidArgument());
  EXPECT_EQ(first.allocations, 0U);

  auto created = cache.acquire_canonical(original, 0, resources[0], 64);
  ASSERT_TRUE(created);
  ASSERT_TRUE(created->created);
  EXPECT_FALSE(created->owner->ready);
  EXPECT_EQ(original.owned_constant(0), nullptr);
  auto unfinished = cache.acquire_canonical(original, 0, resources[0], 64);
  ASSERT_FALSE(unfinished);
  EXPECT_TRUE(unfinished.error().IsFailedPrecondition());
  EXPECT_EQ(first.allocations, 1U);
  copy_and_ready(*created->owner, constant);
  ASSERT_NE(original.owned_constant(0), nullptr);
  cache.commit_plan();

  ASSERT_TRUE(cache.begin_candidate().ok());
  auto hit = cache.acquire_canonical(same, 0, resources[0], 16);
  ASSERT_TRUE(hit);
  EXPECT_FALSE(hit->created);
  EXPECT_EQ(hit->owner.get(), created->owner.get());
  EXPECT_EQ(same.shared_artifact_storage.materialized_constant_bytes, 16U);
  ASSERT_TRUE(cache.acquire_canonical(same, 0, resources[0], 16));
  EXPECT_EQ(same.shared_artifact_storage.materialized_constant_bytes, 16U);
  EXPECT_EQ(first.allocations, 1U);
  expect_contents(*same.owned_constant(0));
  cache.commit_plan();

  ASSERT_EQ(resources[0].domain(), resources[1].domain());
  ASSERT_TRUE(cache.begin_candidate().ok());
  auto other = cache.acquire_canonical(another, 0, resources[1], 64);
  ASSERT_TRUE(other);
  EXPECT_TRUE(other->created);
  EXPECT_NE(other->owner.get(), created->owner.get());
  EXPECT_EQ(other->owner->buffer.resource(), resources[1]);
  EXPECT_EQ(another.shared_artifact_storage.materialized_constant_bytes, 0U);
  copy_and_ready(*other->owner, constant);
  EXPECT_EQ(second.allocations, 1U);
  expect_contents(*another.owned_constant(0));

  auto different = created->owner->key;
  different.description = c::TensorDesc::dense(
      c::DataType::kFloat32, std::array<std::int64_t, 1>{8}).value();
  EXPECT_NE(created->owner->key, different);
  auto differently_shaped = m::Buffer::create(m::system_resource(), 32, 64).value();
  same.constant_bindings[0] = c::ConstTensorView::create(
      different.description, differently_shaped.view()).value();
  auto mismatched = cache.acquire_canonical(same, 0, resources[0], 16);
  ASSERT_FALSE(mismatched);
  EXPECT_TRUE(mismatched.error().IsInvalidArgument());
}

TEST(CanonicalConstantCache, RejectedAlignmentOwnerReleasesOnlyItsOwnBytes) {
  TrackedHostResource resource;
  const std::array resources{m::MemoryResourceRef(resource)};
  const LogicalConstant constant;
  d::PlanState original(m::system_allocator(), constant.generation());
  d::PlanState rejected(m::system_allocator(), constant.generation());
  d::PlanState stronger(m::system_allocator(), constant.generation());
  d::PlanState weaker(m::system_allocator(), constant.generation());
  initialize(original, constant, resources);
  initialize(rejected, constant, resources);
  initialize(stronger, constant, resources);
  initialize(weaker, constant, resources);
  {
    d::ConstantArtifactCache cache;
    ASSERT_TRUE(cache.begin_candidate().ok());
    auto first = cache.acquire_canonical(original, 0, resources[0], 64);
    ASSERT_TRUE(first);
    copy_and_ready(*first->owner, constant);
    cache.commit_plan();

    ASSERT_TRUE(cache.begin_candidate().ok());
    auto unused = cache.acquire_canonical(rejected, 0, resources[0], 256);
    ASSERT_TRUE(unused);
    EXPECT_TRUE(unused->created);
    EXPECT_GE(unused->owner->buffer.alignment(), 256U);
    EXPECT_NE(unused->owner.get(), first->owner.get());
    copy_and_ready(*unused->owner, constant);
    rejected.canonical_constants[0].reset();
    unused->owner.reset();
    ASSERT_TRUE(cache.begin_candidate().ok());
    EXPECT_EQ(resource.live_allocations, 1U);
    expect_contents(*original.owned_constant(0));

    auto replacement = cache.acquire_canonical(stronger, 0, resources[0], 256);
    ASSERT_TRUE(replacement);
    EXPECT_TRUE(replacement->created);
    copy_and_ready(*replacement->owner, constant);
    cache.commit_plan();
    ASSERT_TRUE(cache.begin_candidate().ok());
    auto sufficient = cache.acquire_canonical(weaker, 0, resources[0], 128);
    ASSERT_TRUE(sufficient);
    EXPECT_FALSE(sufficient->created);
    EXPECT_EQ(sufficient->owner.get(), replacement->owner.get());
    EXPECT_EQ(weaker.shared_artifact_storage.materialized_constant_bytes, 16U);
    EXPECT_EQ(resource.allocations, 3U);
  }
  EXPECT_EQ(resource.live_allocations, 2U);
  original.canonical_constants[0].reset();
  EXPECT_EQ(resource.live_allocations, 1U);
  expect_contents(*stronger.owned_constant(0));
  expect_contents(*weaker.owned_constant(0));
}

TEST(CanonicalConstantCache, ChargesAreSharedAndFailedAllocationsRollBack) {
  TrackedHostResource first, second;
  const std::array resources{m::MemoryResourceRef(first),
                             m::MemoryResourceRef(second)};
  const std::array limits{
      c::ResourceBudgetLimit{m::system_resource(), SIZE_MAX},
      c::ResourceBudgetLimit{resources[0], 16},
      c::ResourceBudgetLimit{resources[1], 16}};
  auto resource_budget = c::ResourceBudget::create({.limits = limits}).value();
  first.observed_budget = &resource_budget;
  second.observed_budget = &resource_budget;
  const auto backing = resource_budget.metadata_allocator().value();
  auto budget = hyle::util::adopt_ref(d::StorageBudgetState::create(
      backing, {}, {}, false, resource_budget).value());
  const LogicalConstant constant;
  {
    d::PlanState original(budget->allocator(), constant.generation());
    d::PlanState same(budget->allocator(), constant.generation());
    d::PlanState alignment_failure(budget->allocator(), constant.generation());
    d::PlanState allocation_failure(budget->allocator(), constant.generation());
    for (auto *plan : {&original, &same, &alignment_failure, &allocation_failure}) {
      plan->compilation_storage = budget;
      initialize(*plan, constant, resources);
    }
    d::ConstantArtifactCache cache;
    ASSERT_TRUE(cache.begin_candidate().ok());
    auto created = cache.acquire_canonical(original, 0, resources[0], 64);
    ASSERT_TRUE(created);
    copy_and_ready(*created->owner, constant);
    cache.commit_plan();
    ASSERT_TRUE(cache.begin_candidate().ok());
    auto reused = cache.acquire_canonical(same, 0, resources[0], 64);
    ASSERT_TRUE(reused);
    EXPECT_FALSE(reused->created);
    EXPECT_EQ(resource_budget.usage(resources[0])->live_by_category[
        static_cast<std::size_t>(c::ResourceBudgetCategory::kConstant)], 16U);

    ASSERT_TRUE(cache.begin_candidate().ok());
    auto quota = cache.acquire_canonical(alignment_failure, 0, resources[0], 128);
    ASSERT_FALSE(quota);
    EXPECT_TRUE(quota.error().IsResourceExhausted());
    EXPECT_EQ(first.allocations, 1U);
    EXPECT_FALSE(alignment_failure.canonical_constants[0]);
    ASSERT_TRUE(cache.begin_candidate().ok());
    second.fail_allocation = true;
    auto failed = cache.acquire_canonical(allocation_failure, 0, resources[1], 64);
    ASSERT_FALSE(failed);
    EXPECT_TRUE(failed.error().IsResourceExhausted());
    EXPECT_FALSE(allocation_failure.canonical_constants[0]);
    EXPECT_EQ(resource_budget.usage(resources[1])->live_by_category[
        static_cast<std::size_t>(c::ResourceBudgetCategory::kConstant)], 0U);
    EXPECT_EQ(second.allocations, 0U);
  }
  EXPECT_EQ(first.live_allocations, 0U);
  EXPECT_TRUE(first.deallocated_with_constant_charge);
  EXPECT_EQ(resource_budget.usage(resources[0])->live_by_category[
      static_cast<std::size_t>(c::ResourceBudgetCategory::kConstant)], 0U);
  EXPECT_EQ(resource_budget.usage(resources[1])->live_by_category[
      static_cast<std::size_t>(c::ResourceBudgetCategory::kConstant)], 0U);
}
} // namespace
