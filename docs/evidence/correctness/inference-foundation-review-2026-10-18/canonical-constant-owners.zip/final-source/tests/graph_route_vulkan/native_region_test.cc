#include <gtest/gtest.h>

#include <array>
#include <bit>
#include <memory>

#include "hyle/graph/vulkan.h"
#include "hyle/graph/executable.h"
#include "hyle/compute/vulkan_memory.h"
#include "../../src/compute_route_vulkan/vulkan_memory_internal.h"
#include "../../src/graph/execution_source_internal.h"

namespace {
namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace vn = v::detail;

const c::TensorDesc description = c::TensorDesc::dense(c::DataType::kFloat32,
    std::array<std::int64_t, 1>{4}).value();

hyle::Status execute(g::Invocation &slot, g::ValueId input, c::ConstTensorView binding) {
  auto status = slot.bind(input, binding);
  EXPECT_TRUE(status.ok()) << "bind: " << status.message();
  if (!status.ok()) return status;
  status = slot.prepare_replay({});
  EXPECT_TRUE(status.ok()) << "prepare_replay: " << status.message();
  if (!status.ok()) return status;
  auto accepted = slot.submit();
  if (!accepted) {
    ADD_FAILURE() << "submit: " << accepted.error().message();
    return std::move(accepted).error();
  }
  status = accepted->wait();
  EXPECT_TRUE(status.ok()) << "completion: " << status.message();
  return status;
}
void expect(const v::Context &context, c::ConstTensorView actual,
            const std::array<float, 4> &expected) {
  auto native = vn::MemoryAccess::tensor_view(vn::Access::runtime(context), actual,
                                             hyle::mem::system_allocator());
  ASSERT_TRUE(native) << native.error().message();
  std::array<float, 4> host{};
  ASSERT_TRUE(context.download(*native, std::as_writable_bytes(std::span(host))).ok());
  for (std::size_t i = 0; i < host.size(); ++i)
    EXPECT_EQ(std::bit_cast<std::uint32_t>(host[i]), std::bit_cast<std::uint32_t>(expected[i])) << i;
}
c::ReadLease input(const v::Context &context, const v::MemoryResource &memory,
                   const std::array<float, 4> &values) {
  auto native = context.upload(description, std::as_bytes(std::span(values))).value();
  return memory.import_readonly(native).value();
}

struct TrackedHost final : hyle::mem::MemoryResource {
  unsigned reads = 0;
  bool fail = false;
  std::string_view name() const noexcept override { return "constant test host"; }
  hyle::mem::MemoryProperties properties() const noexcept override {
    return hyle::mem::system_resource().properties();
  }
  hyle::Result<hyle::mem::ResourceAllocation> allocate(std::size_t bytes,
      std::size_t alignment) noexcept override {
    return hyle::mem::system_resource().resource().allocate(bytes, alignment);
  }
  void deallocate(hyle::mem::ResourceAllocation allocation) noexcept override {
    hyle::mem::system_resource().resource().deallocate(allocation);
  }
  hyle::Status read(void *handle, std::size_t offset, std::span<std::byte> bytes) noexcept override {
    ++reads;
    if (fail) return hyle::Status::Unavailable("injected host constant read failure");
    return hyle::mem::system_resource().resource().read(handle, offset, bytes);
  }
  hyle::Status write(void *handle, std::size_t offset, std::span<const std::byte> bytes) noexcept override {
    return hyle::mem::system_resource().resource().write(handle, offset, bytes);
  }
};

struct OneFenceFailure final {
  vn::Device &device;
  PFN_vkWaitForFences original;
  unsigned calls = 0;
  static inline OneFenceFailure *active = nullptr;
  explicit OneFenceFailure(const v::Context &context)
      : device(*vn::Access::runtime(context)->device), original(device.fn.WaitForFences) {
    active = this; device.fn.WaitForFences = invoke;
  }
  ~OneFenceFailure() { device.fn.WaitForFences = original; active = nullptr; }
  static VKAPI_ATTR VkResult VKAPI_CALL invoke(VkDevice device, std::uint32_t count,
      const VkFence *fences, VkBool32 all, std::uint64_t timeout) {
    if (++active->calls == 1) return VK_ERROR_OUT_OF_HOST_MEMORY;
    return active->original(device, count, fences, all, timeout);
  }
};

TEST(VulkanNativeRegion, UnifiedInvocationKeepsGeneratedViewsSlotsAndOwners) {
  auto context = v::Context::create().value();
  RecordProperty("vulkan_device", context.environment().device_name);
  RecordProperty("vulkan_driver", context.environment().driver_info);
  auto memory = v::MemoryResource::create(context, v::MemoryKind::kDevice).value();
  const auto source = g::vulkan::execution_source(context).value();
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(description).value();
  const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, x).value();
  const auto restored = builder.add(c::Unary{c::UnaryKind::kNeg}, negative).value();
  const auto shape = c::TensorShape::create(std::array<std::int64_t, 2>{2, 2}).value();
  const auto computed_view = builder.add(c::View::reshape(shape).value(), restored).value();
  const auto bound_view = builder.add(c::View::reshape(shape).value(), x).value();
  for (const auto value : {negative, computed_view, bound_view}) ASSERT_TRUE(builder.publish(value).ok());
  auto graph = std::move(builder).finish().value();
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  auto compiled = g::compile(graph, {domains, targets});
  ASSERT_TRUE(compiled) << compiled.error().message();
  EXPECT_EQ(compiled->executable.region_count(), 1U);
  EXPECT_EQ(compiled->executable.required_queue_count(), 0U);
  EXPECT_EQ(compiled->executable.workspace_bytes(), 0U);
  auto first = compiled->executable.create_invocation();
  ASSERT_TRUE(first) << first.error().message();
  auto second = compiled->executable.create_invocation();
  ASSERT_TRUE(second) << second.error().message();
  const std::array<float, 4> a{0.25f, -1.5f, 3.75f, -0.0f}, b{-2.25f, 0.5f, -7.0f, 1.25f};
  auto a_input = input(context, memory, a);
  auto b_input = input(context, memory, b);
  auto a_binding = a_input.tensor(description).value();
  auto b_binding = b_input.tensor(description).value();
  ASSERT_TRUE(execute(*first, x, a_binding).ok());
  auto old = first->result(negative).value();
  auto old_computed = first->result(computed_view).value();
  auto old_bound = first->result(bound_view).value();
  expect(context, old.tensor().value(), {-a[0], -a[1], -a[2], -a[3]});
  expect(context, old_computed.tensor().value(), a);
  expect(context, old_bound.tensor().value(), a);
  EXPECT_FALSE(first->bind(x, b_binding).ok());
  EXPECT_FALSE(first->submit());
  ASSERT_TRUE(second->prepare_resources().ok());
  ASSERT_TRUE(second->bind(x, description, b_input).ok());
  ASSERT_TRUE(second->prepare_replay({}).ok());
  {
    auto accepted = second->submit();
    ASSERT_TRUE(accepted) << accepted.error().message();
    ASSERT_TRUE(accepted->wait().ok());
  }
  expect(context, second->output(computed_view).value(), b);
  expect(context, second->output(bound_view).value(), b);
  expect(context, old.tensor().value(), {-a[0], -a[1], -a[2], -a[3]});
  old.reset(); old_computed.reset(); old_bound.reset();
  ASSERT_TRUE(execute(*first, x, b_binding).ok());
  auto retained = first->result(negative).value();
  auto leased = retained.storage_lease();
  ASSERT_TRUE(leased) << leased.error().message();
  expect(context, leased->tensor(description).value(), {-b[0], -b[1], -b[2], -b[3]});
  retained.reset();
  EXPECT_FALSE(first->prepare_replay({}).ok()); // Escaped native lease is not an internal baseline ref.
  leased->reset();
  ASSERT_TRUE(first->prepare_replay({}).ok());
  {
    auto run = first->submit(); ASSERT_TRUE(run) << run.error().message();
    ASSERT_TRUE(run->wait().ok());
  }
  auto final = first->result(negative).value();
  std::weak_ptr<vn::Buffer> weak;
  {
    auto tensor = vn::MemoryAccess::tensor_view(vn::Access::runtime(context), final.tensor().value(),
                                               hyle::mem::system_allocator()).value();
    weak = vn::Access::buffer(tensor);
  }
  *first = {}; *second = {}; compiled->executable = {}; graph = {};
  ASSERT_TRUE(context.close().ok());
  expect(context, final.tensor().value(), {-b[0], -b[1], -b[2], -b[3]});
  EXPECT_FALSE(weak.expired());
  final.reset();
  EXPECT_TRUE(weak.expired()); // No Buffer -> ResultStorage/Invocation back-reference.
}

TEST(VulkanNativeRegion, UnifiedCompileCapturesBorrowedNativeConstant) {
  auto context = v::Context::create().value();
  RecordProperty("vulkan_device", context.environment().device_name);
  RecordProperty("vulkan_driver", context.environment().driver_info);
  auto memory = v::MemoryResource::create(context, v::MemoryKind::kDevice).value();
  const auto source = g::vulkan::execution_source(context).value();
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(description).value();
  const auto weight = builder.constant(description).value();
  const auto sum = builder.add(c::Binary{c::BinaryKind::kAdd}, x, weight).value();
  const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, sum).value();
  ASSERT_TRUE(builder.publish(sum).ok());
  ASSERT_TRUE(builder.publish(negative).ok());
  auto graph = std::move(builder).finish().value();
  auto constant = input(context, memory, {0.5f, -0.25f, 1.25f, 2.0f});
  const std::array constants{g::ConstantBinding{weight, constant.tensor(description).value(),
                                             g::ConstantPolicy::kBorrow}};
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  auto compiled = g::compile(graph, {domains, targets}, {.constants = constants});
  ASSERT_TRUE(compiled) << compiled.error().message();
  EXPECT_EQ(compiled->report.borrowed_constant_count(), 1U);
  EXPECT_EQ(compiled->executable.workspace_bytes(), 0U);
  auto slot = compiled->executable.create_invocation();
  ASSERT_TRUE(slot) << slot.error().message();
  for (const auto values : {std::array<float, 4>{0.25f, 1.5f, -2.75f, 0.0f},
                            std::array<float, 4>{-2.0f, 3.25f, 1.5f, -0.5f}}) {
    auto inputs = input(context, memory, values);
    ASSERT_TRUE(execute(*slot, x, inputs.tensor(description).value()).ok());
    const std::array<float, 4> expected{values[0] + 0.5f, values[1] - 0.25f,
                                      values[2] + 1.25f, values[3] + 2.0f};
    expect(context, slot->output(sum).value(), expected);
    expect(context, slot->output(negative).value(), {-expected[0], -expected[1], -expected[2], -expected[3]});
  }
}

TEST(VulkanNativeRegion, UnifiedCompileMaterializesHostConstantsOnce) {
  auto context = v::Context::create().value();
  RecordProperty("vulkan_device", context.environment().device_name);
  RecordProperty("vulkan_driver", context.environment().driver_info);
  auto memory = v::MemoryResource::create(context, v::MemoryKind::kDevice).value();
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{g::vulkan::execution_source(context).value(), g::StorageDomainId{0}}};
  const auto single = c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t, 1>{1}).value();
  const auto odd = c::TensorDesc::dense(c::DataType::kUInt8, std::array<std::int64_t, 1>{3}).value();
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(description).value();
  const auto weight = builder.constant(description).value();
  const auto scalar = builder.constant(single).value();
  const auto raw = builder.constant(odd).value();
  const auto sum = builder.add(c::Binary{c::BinaryKind::kAdd}, x, weight).value();
  const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, sum).value();
  for (const auto value : {sum, negative, scalar, raw}) ASSERT_TRUE(builder.publish(value).ok());
  auto graph = std::move(builder).finish().value();
  const std::array placements{
      g::NodePlacement{graph.producer(sum).value(), g::ExecutionTargetId{0}, g::PlacementStrength::kRequired},
      g::NodePlacement{graph.producer(negative).value(), g::ExecutionTargetId{0}, g::PlacementStrength::kRequired}};
  TrackedHost host;
  auto weights = hyle::mem::Buffer::create(hyle::mem::MemoryResourceRef(host), 16, 4).value();
  auto one = hyle::mem::Buffer::create(hyle::mem::MemoryResourceRef(host), 4, 4).value();
  auto bytes = hyle::mem::Buffer::create(hyle::mem::MemoryResourceRef(host), 3, 1).value();
  const std::array<float, 4> w{0.5f, -0.25f, 1.25f, 2.0f};
  const std::array<float, 1> s{3.75f};
  const std::array<std::byte, 3> raw_values{std::byte{1}, std::byte{127}, std::byte{255}};
  ASSERT_TRUE(weights.view().write(std::as_bytes(std::span(w))).ok());
  ASSERT_TRUE(one.view().write(std::as_bytes(std::span(s))).ok());
  ASSERT_TRUE(bytes.view().write(raw_values).ok());
  const std::array constants{
      g::ConstantBinding{weight, c::ConstTensorView::create(description, weights.view()).value(), g::ConstantPolicy::kMaterialize},
      g::ConstantBinding{scalar, c::ConstTensorView::create(single, one.view()).value(), g::ConstantPolicy::kMaterialize},
      g::ConstantBinding{raw, c::ConstTensorView::create(odd, bytes.view()).value(), g::ConstantPolicy::kMaterialize}};
  const std::array limits{c::ResourceBudgetLimit{memory.ref(), 22},
                          c::ResourceBudgetLimit{hyle::mem::system_resource(), 16 * 1024 * 1024}};
  auto selected_budget = c::ResourceBudget::create({.limits = limits, .allow_unattributed = true});
  ASSERT_TRUE(selected_budget) << selected_budget.error().message();
  auto budget = std::move(*selected_budget);
  auto rejected = g::compile(graph, {domains, targets},
      {.constants = constants, .resource_budget = budget, .node_placements = placements});
  ASSERT_FALSE(rejected);
  EXPECT_TRUE(rejected.error().IsResourceExhausted()) << rejected.error().message();
  EXPECT_EQ(host.reads, 0U); // The full canonical batch is admitted before accepting any upload.
  auto compiled = g::compile(graph, {domains, targets},
      {.constants = constants, .node_placements = placements});
  ASSERT_TRUE(compiled) << compiled.error().message();
  EXPECT_EQ(host.reads, 3U);
  // Query the exact batch policy without reading or allocating through it.
  auto d16 = hyle::mem::Buffer::create(memory.ref(), 16, 4).value();
  auto d4 = hyle::mem::Buffer::create(memory.ref(), 4, 4).value();
  auto d3 = hyle::mem::Buffer::create(memory.ref(), 3, 1).value();
  const std::array copies{
      g::detail::ConstantCopy{c::TensorView::create(description, d16.view()).value(), constants[0].tensor},
      g::detail::ConstantCopy{c::TensorView::create(single, d4.view()).value(), constants[1].tensor},
      g::detail::ConstantCopy{c::TensorView::create(odd, d3.view()).value(), constants[2].tensor}};
  EXPECT_EQ(g::detail::ExecutionSourceAccess::constant_copy_scratch_bytes(targets[0].source, copies).value(), 16U);
  EXPECT_EQ(host.reads, 3U);
  EXPECT_EQ(compiled->report.materialized_constant_bytes(), 23U);
  EXPECT_EQ(compiled->report.materialized_constant_count(), 3U);
  ASSERT_TRUE(weights.reset().ok()); ASSERT_TRUE(one.reset().ok()); ASSERT_TRUE(bytes.reset().ok());
  auto slot = compiled->executable.create_invocation().value();
  for (const auto values : {std::array<float, 4>{0.25f, 1.5f, -2.75f, 0.0f},
                            std::array<float, 4>{-2.0f, 3.25f, 1.5f, -0.5f}}) {
    auto inputs = input(context, memory, values);
    ASSERT_TRUE(execute(slot, x, inputs.tensor(description).value()).ok());
    const std::array<float, 4> expected{values[0] + w[0], values[1] + w[1], values[2] + w[2], values[3] + w[3]};
    expect(context, slot.output(sum).value(), expected);
    expect(context, slot.output(negative).value(), {-expected[0], -expected[1], -expected[2], -expected[3]});
    for (const auto value : {scalar, raw}) {
      auto native = vn::MemoryAccess::tensor_view(vn::Access::runtime(context), slot.output(value).value(),
          hyle::mem::system_allocator()).value();
      if (value == scalar) {
        std::array<float, 1> actual{};
        ASSERT_TRUE(context.download(native, std::as_writable_bytes(std::span(actual))).ok());
        EXPECT_EQ(actual, s);
      } else {
        std::array<std::byte, 3> actual{};
        ASSERT_TRUE(context.download(native, actual).ok()); EXPECT_EQ(actual, raw_values);
      }
    }
  }
  EXPECT_EQ(host.reads, 3U); // Replay never reads the released source or invokes cold copy again.
}

TEST(VulkanNativeRegion, ConstantCopyPreflightsWholeBatchAndDoesNotRetryReadFailure) {
  auto context = v::Context::create().value();
  auto memory = v::MemoryResource::create(context, v::MemoryKind::kDevice).value();
  auto foreign_context = v::Context::create().value();
  auto foreign = v::MemoryResource::create(foreign_context, v::MemoryKind::kDevice).value();
  auto destination = hyle::mem::Buffer::create(memory.ref(), 16, 4).value();
  auto other = hyle::mem::Buffer::create(foreign.ref(), 16, 4).value();
  TrackedHost host;
  auto source = hyle::mem::Buffer::create(hyle::mem::MemoryResourceRef(host), 16, 4).value();
  const auto input_view = c::ConstTensorView::create(description, source.view()).value();
  const auto target_view = c::TensorView::create(description, destination.view()).value();
  const auto wrong_view = c::TensorView::create(description, other.view()).value();
  const auto native = vn::MemoryAccess::tensor_view(vn::Access::runtime(context), target_view.as_const(),
      hyle::mem::system_allocator()).value();
  const std::array<float, 4> sentinel{7, 8, 9, 10};
  ASSERT_TRUE(context.upload(native, std::as_bytes(std::span(sentinel))).ok());
  const auto &runtime = vn::Access::runtime(context);
  ASSERT_TRUE(vn::MemoryAccess::can_copy_constant(runtime, {target_view, input_view}).value());
  EXPECT_FALSE(vn::MemoryAccess::can_copy_constant(runtime, {wrong_view, input_view}).value());
  EXPECT_EQ(host.reads, 0U);
  const std::array invalid_batch{vn::ConstantUpload{target_view, input_view},
                                vn::ConstantUpload{wrong_view, input_view}};
  EXPECT_TRUE(vn::MemoryAccess::copy_constants(runtime, invalid_batch,
      hyle::mem::system_allocator()).IsUnimplemented());
  EXPECT_EQ(host.reads, 0U);
  expect(context, target_view.as_const(), sentinel);
  auto builder = g::GraphBuilder::create().value();
  const auto constant = builder.constant(description).value();
  const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, constant).value();
  ASSERT_TRUE(builder.publish(negative).ok());
  auto graph = std::move(builder).finish().value();
  const std::array constants{g::ConstantBinding{constant, input_view, g::ConstantPolicy::kMaterialize}};
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{g::vulkan::execution_source(context).value(), g::StorageDomainId{0}}};
  host.fail = true;
  auto failed = g::compile(graph, {domains, targets}, {.constants = constants});
  ASSERT_FALSE(failed); EXPECT_TRUE(failed.error().IsUnavailable()) << failed.error().message();
  EXPECT_EQ(host.reads, 1U); // Actual copy failure is fatal, never retried on another route.
  EXPECT_EQ(runtime->pending, nullptr);
  host.fail = false;
  ASSERT_TRUE(source.view().write(std::as_bytes(std::span(sentinel))).ok());
  OneFenceFailure observation(context);
  const std::array accepted_batch{vn::ConstantUpload{target_view, input_view}};
  const auto terminal = vn::MemoryAccess::copy_constants(runtime, accepted_batch,
      hyle::mem::system_allocator());
  EXPECT_TRUE(terminal.IsResourceExhausted()) << terminal.message();
  EXPECT_EQ(observation.calls, 1U); // Original queue drain retires the real accepted prefix.
  EXPECT_EQ(host.reads, 2U); // No copy retry after the real native error.
  EXPECT_EQ(runtime->pending, nullptr);
}
} // namespace
