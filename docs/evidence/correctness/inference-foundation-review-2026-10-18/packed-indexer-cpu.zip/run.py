from pathlib import Path
import json,subprocess,sys,os,time,hashlib
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
cached=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/cpu-grouped-block-selection/commands.json').read_text())
old_compile=next(x['command'] for x in cached if x['tag']=='product-compile' and x['exit']==0)
flags=[x for x in old_compile if not str(x).startswith(('/Tp','/Fo'))]
flags+=['/I'+str(R/'third_party/ds4_quantization'),'/DHYLE_TEST_TORCH_CPU=1','/W4','/WX']
old_link=next(x['command'] for x in cached if x['tag']=='canonical-link' and x['exit']==0)
link=[x for x in old_link if not str(x).endswith('.obj') and not str(x).startswith(('/OUT:','/MAP:'))]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':flags[0],'CMAKE_C_COMPILER':flags[0]})
torch=Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
env['PATH']=str(torch/'lib')+os.pathsep+str(R/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
records=json.loads((O/'commands.json').read_text()) if (O/'commands.json').exists() else []
def run(tag,command):
 command=list(map(str,command));start=time.monotonic()
 p=subprocess.run(command,cwd=R,env=env,capture_output=True,timeout=240,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(tag+'.stdout.log')).write_bytes(p.stdout);(O/(tag+'.stderr.log')).write_bytes(p.stderr)
 records.append(dict(tag=tag,command=command,cwd=str(R),exit=p.returncode,seconds=time.monotonic()-start))
 (O/'commands.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
 print(tag,p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-4000:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
def compile(source,name):
 obj=O/(name+'.obj')
 if not obj.exists() or obj.stat().st_mtime < source.stat().st_mtime:run(name+'-compile',[*flags,'/Tp'+str(source),'/Fo'+str(obj)])
 return obj
def create(name,objects):
 exe=O/(name+'.exe');run(name+'-link',[*link[:1],*objects,*link[1:],'/OUT:'+str(exe),'/MAP:'+str(O/(name+'.map'))]);return exe
objects=[O/(n+'.obj') for n in ['torch-cpu-v3','row-cache','native-provider']]+[R/'.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj']
action=sys.argv[1] if len(sys.argv)>1 else 'build'
if action=='build':
 for source,name in [('src/compute_provider_native/torch_cpu_program.cc','torch-cpu-v3'),('src/compute_provider_native/row_cache.cc','row-cache'),('src/compute_provider_native/native_provider.cc','native-provider')]:compile(R/source,name)
 test=compile(R/'tests/compute_route_cpu/row_cache_indexer_test.cc','tests')
 create('tests',[test,*objects])
elif action=='test':run('canonical-v3-tests',[O/'tests.exe','--gtest_filter=CpuRowCacheIndexer.*','--gtest_color=no'])
elif action=='census':
 source=(R/'src/compute_provider_native/row_cache.cc').read_text()
 marker='  decode_row<true>(source, output);'
 assert source.count(marker)==1
 source='extern \"C\" void hyle_indexer_decoded_row() noexcept;\n'+source.replace(marker,'  hyle_indexer_decoded_row();\n'+marker,1)
 counted=O/'row_cache.counted.cc';counted.write_text(source,encoding='utf-8',newline='\n')
 counted_obj=compile(counted,'row-cache-counted')
 probe=compile(O/'census.cc','census-v2')
 for arm,product,expected in [('before',O/'torch-cpu.obj',1023),('after',O/'torch-cpu-v2.obj',513)]:
  env['HYLE_EXPECT_DECODED_ROWS']=str(expected)
  exe=create('census-'+arm,[probe,product,counted_obj,*objects[2:]])
  run('allocator-decoder-'+arm,[exe,'--gtest_filter=RowCacheIndexerResource.*','--gtest_color=no'])
else:raise SystemExit(action)
