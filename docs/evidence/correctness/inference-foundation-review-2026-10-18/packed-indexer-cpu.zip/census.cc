#include <gtest/gtest.h>
#include <c10/core/CPUAllocator.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <vector>
#include "tests/compute_models/row_cache_indexer_fixture.h"
#include "tests/compute_provider_native/half_test_support.h"
#include "hyle/compute/cpu.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
static std::size_t decoded_rows=0;
extern "C" void hyle_indexer_decoded_row() noexcept {++decoded_rows;}
namespace {
namespace c=hyle::compute;namespace m=hyle::mem;
struct Allocator final:at::Allocator {
 at::Allocator*original=c10::GetCPUAllocator();bool active=false,fail=false;
 std::map<std::size_t,std::size_t> requests;
 at::DataPtr allocate(std::size_t bytes)override {
  if(active)++requests[bytes];
  if(fail){fail=false;throw std::bad_alloc();}
  return original->allocate(bytes);
 }
 void copy_data(void*d,const void*s,std::size_t n)const override{original->copy_data(d,s,n);}
 at::DeleterFnPtr raw_deleter()const override{return original->raw_deleter();}
};
Allocator&allocator(){static Allocator a;return a;}
TEST(RowCacheIndexerResource, ActualAtEnRequestsAreTileBoundedAndOomKeepsCallerOutput){
 auto&a=allocator();c10::SetCPUAllocator(&a,255);
 const row_cache_indexer_test::Fixture f;
 auto context=c::cpu::create_context().value();auto queue=context.create_queue().value();
 const auto op=c::model_ops::row_cache_indexer_scores();const auto od=c::infer_single_output(op,f.descriptions).value();
 auto p=c::prepare(context,op,f.descriptions,std::array{od},m::system_resource()).value();
 auto q=half_test::buffer<std::uint16_t>(f.query);auto k=half_test::buffer<std::uint8_t>(f.bank);
 auto w=half_test::buffer<std::uint16_t>(f.weights);auto r=half_test::buffer<std::int32_t>(f.ranges);
 auto out=half_test::buffer<float>(std::vector<float>(std::size_t(f.queries*f.rows),91.F));
 const std::array inputs{c::ConstTensorView::create(f.descriptions[0],q.view()).value(),c::ConstTensorView::create(f.descriptions[1],k.view()).value(),c::ConstTensorView::create(f.descriptions[2],w.view()).value(),c::ConstTensorView::create(f.descriptions[3],r.view()).value()};
 const std::array outputs{c::TensorView::create(od,out.view()).value()};
 auto slot=p.create_invocation().value();a.active=true;
 auto done=slot.submit(queue,inputs,outputs);a.active=false;ASSERT_TRUE(done);ASSERT_TRUE(done->wait().ok());
 const auto actual=half_test::read<float>(out),expected=f.expected();
 for(std::size_t i=0;i<actual.size();++i)EXPECT_FLOAT_EQ(actual[i],expected[i]);
 char expected_rows[32]{};std::size_t required=0;ASSERT_EQ(getenv_s(&required,expected_rows,sizeof(expected_rows),"HYLE_EXPECT_DECODED_ROWS"),0);ASSERT_GT(required,0u);
 std::printf("DECODED_ROWS actual=%zu expected=%s\n",decoded_rows,expected_rows);
 EXPECT_EQ(decoded_rows,std::strtoull(expected_rows,nullptr,10));
 const auto full_history_bf16=std::size_t(f.rows)*128*2;
 std::size_t total=0,count=0;for(const auto&[bytes,calls]:a.requests){total+=bytes*calls;count+=calls;std::printf("ATEN_REQUEST bytes=%zu count=%zu\n",bytes,calls);}
 ASSERT_FALSE(a.requests.empty());
 std::printf("ATEN_CENSUS query_rows=%lld key_rows=%lld tile_rows=256 caller_output=%llu private_output=%llu full_history_bf16=%zu max_request=%zu calls=%zu requested_bytes=%zu\n",(long long)f.queries,(long long)f.rows,(unsigned long long)od.required_bytes().value(),(unsigned long long)od.required_bytes().value(),full_history_bf16,a.requests.rbegin()->first,count,total);
 EXPECT_EQ(a.requests.count(full_history_bf16),0u);EXPECT_LT(a.requests.rbegin()->first,full_history_bf16);
 EXPECT_NE(a.requests.find(256*128*2),a.requests.end());EXPECT_NE(a.requests.find(od.required_bytes().value()),a.requests.end());
 const auto sentinel=std::vector<float>(actual.size(),91.F);ASSERT_TRUE(out.view().write(std::as_bytes(std::span(sentinel))).ok());
 auto failed=p.create_invocation().value();a.fail=true;auto failure=failed.submit(queue,inputs,outputs);
 ASSERT_TRUE(failure);EXPECT_TRUE(failure->wait().IsResourceExhausted());EXPECT_FALSE(a.fail);EXPECT_EQ(half_test::read<float>(out),sentinel);
 auto retry=p.create_invocation().value();auto again=retry.submit(queue,inputs,outputs);ASSERT_TRUE(again);ASSERT_TRUE(again->wait().ok());EXPECT_EQ(half_test::read<float>(out),actual);
}
}
