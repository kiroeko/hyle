from pathlib import Path
import json,hashlib,zipfile,subprocess,difflib
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['tests/compute_state/row_cache_consumer.cc','tests/compute_state/CMakeLists.txt']
diff=''
for n in files:
 p=O/'before'/n;a=p.read_text(encoding='utf-8').splitlines(True)if p.exists()else[];b=(R/n).read_text(encoding='utf-8').splitlines(True)
 diff+=''.join(difflib.unified_diff(a,b,fromfile='a/'+n,tofile='b/'+n))
(O/'task.diff').write_text(diff,encoding='utf-8')
p=subprocess.run(['git','diff','--check','--',*files],capture_output=True);(O/'diff-check.stdout.log').write_bytes(p.stdout);(O/'diff-check.stderr.log').write_bytes(p.stderr);p.check_returncode()
dependencies=set()
for name in ['cpu','cuda']:
 commands=json.loads((O/(name+'-commands.json')).read_text())
 for record in commands:
  if record['tag']==name+'-link'and record['exit']==0:
   dependencies.update(Path(x)for x in record['command']if x.endswith(('.obj','.lib'))and Path(x).is_file())
(O/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(dependencies)],indent=2)+'\n')
gpu=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version,compute_cap','--format=csv,noheader'],capture_output=True)
(O/'hardware.stdout.log').write_bytes(gpu.stdout);(O/'hardware.stderr.log').write_bytes(gpu.stderr)
summary={
 'status':'Frozen same canonical consumer actual CPU and CUDA PASS',
 'source':{n:sha(R/n)for n in files},
 'prerequisite_codec':{'archive':'../row-cache-cpu/source-results.zip','sha256':'d4b2a3e1300908a7e23c867380464d722dad19bd92a0c221161b929632f12227','source':'CPU rowcache slice frozen separately; CUDA original3product objects reused from deepseek-packed-history/cuda.'},
 'journey':'Fixed5-row chunk. Encode only initial3 BF16 rows, F2copy into initialized full chunk and import visible3. Separate accept1/2 branches begin frombase,clone only this fixed chunk,Encode only new1/2 rows,range-copy at row3. Copywait then dropSubmission,unbind original full writer,verify same native root/offset/extent/generation,publish full writer,StateWriter.complete. Metadata4/5 finalized and StateHead published together. SelectedBF16 and mainSink actually consume library-produced stored bytes.',
 'actual_checks':[
  'accept0 cancels speculative metadata draft and leaves head atbase; no fake suffix publication',
  'accept1/2 encoded chunk complete bytes match independent sharedFP64-table/BF16 oracle; untouched prefix and unused physical suffix preserved',
  'oldbase payload and visible3 metadata retain exact original bytes after both branches',
  'returned F2 writer matches original full root/generation/extent; retained submission rejects unbind; Submission.output is not used for a whole-chunk claim',
  'only new rows passed to Encode; F2offset/count main1752+584/1168,index204+68/136',
  'bothformats ReadLease->RowCacheGatherDecode checked repeated highIDs with IDs<logicalvisible->selectedBF16 matches independent oracle',
  'late NaN row producer returnsInvalidArgument; draft explicitly cancels, cannot finalize, and published head identity stays unchanged',
  'mainD512 actual ordinaryGraph selecteddecode->CastF32->View[B2,S3,1,512]->oneSinkH64/Q1->Neg dualpublished; all2*64*512 outputs compared to independent FP64 perhead sink-denominator formula, Neg sign exact'],
 'fixed_capacity':{'rows':5,'main_chunk_logical_bytes':2920,'index_chunk_logical_bytes':340,'clone_pool_capacity_bytes':32768,'scope':'COW copies only this fixed chunk. No claim that whole long-history COW everytoken is efficient. Physical capacity5 and logical visible3/4/5 are distinct; consumer chooses IDs below visible metadata.'},
 'sink_accuracy':{'budget':'original abs2e-5+rel2e-5 unchanged','cpu_max_absolute':[1.42443377e-7,1.58015873e-7],'cuda_max_absolute':[2.11957693e-7,2.17565631e-7],'source_values':'BF16 input bounded[-2,2]; extreme cases stay in prior codec regression to avoid nonfinite attention.'},
 'build':{'source':'same tests/compute_state/row_cache_consumer.cc compiled once per CPU/CUDA finalvariant /W4 /WX','cuda_hardware':'RTX4070 cc8.9; actual runtime and nvidia-smi log retained','reuse':'Existing State/F2 libraries include unbind_mutable; no blind/native/fullSDK rebuild. Reuse CPU codec2objects/root low-precision.obj; CUDA codec3objects; frozen batchedSink provider/tensor overlay and allnative libraries.','canonical':'CPU and CUDA CMake registrations added. Manual component closure compiled canonical source and ran it; no fullCMakeconfigure/build.'},
 'validation_closure_correction':'FirstCUDA link mistakenly replaced native ggml-cuda.strict.obj in addition to keeping oldHyle GE provider, causing duplicate symbols. Corrected to retain strictnative object and replace oldGE provider.obj with frozen batchedSink cuda-provider.obj; tensor-after also replaced by frozen batchedSink tensor. No productsource fix was needed. Original failure log retained.',
 'known_cached_SDK_boundary':'Reused CUDA batchedSink tensor validation object statically declines exactly3 unrelated IQ1 narrow formats absent in oldstrict nativepin. No IQ1 domain claimed; current rowcodec/Sink isBF16/F32/U8 and unaffected.',
 'not_claimed':['Nativepaged selected packed carrier','RealTopK/indexer-selected IDs (this consumer explicitly chooses IDs belowvisible)','PackedFP4 indexer scoring/MatMul','FullMTP/multimodal/model engine/all8model22profile run','Throughput or peak-memory improvement','No-host-wait pipeline; explicit F1/F2waits follow requested public protocol'],
 'readback_boundary':'Hostpayload reads are explicit testoracle observations. Native feedback uses ReadLease/F2 and Graph outputs directly; no host-decoded cache is fed back into Sink.',
 'validation':'Final CPU/CUDA executions and touched-file diffcheck PASS. No expansion beyond accept0/1/2, twoencodings and mainSink geometry.',
 'reproduce':['python .scratch/inference-foundation-review-2026-10-18/row-cache-state/build_cpu.py','python .scratch/inference-foundation-review-2026-10-18/row-cache-state/build_cuda.py'],
 'archive':'Source/sharedfixture/contracts,commands/logs/identities and exact taskdiff; no executable,object,library,SDK.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
candidates=[p for p in O.iterdir()if p.is_file()and p.suffix in['.exe','.lib','.exp']]
(O/'cleanup-candidates.json').write_text(json.dumps(dict(intent='No deletion performed. Root owns cleanup through exacttest.ps1.',candidates=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in candidates],total_bytes=sum(p.stat().st_size for p in candidates),retain_objects=[str(p)for p in O.glob('*.obj')],retain_other_cached_objects=True),indent=2)+'\n')
extra=['tests/compute_models/row_cache_fixture.h','include/hyle/compute/model_ops.h','include/hyle/compute/low_precision.h','include/hyle/compute/state_versions.h','include/hyle/compute/state_clone.h','include/hyle/compute/batch_transfer.h']
with zipfile.ZipFile(O/'source-results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in O.iterdir():
  if p.is_file()and p.suffix in['.py','.json','.log','.diff']:z.write(p,p.name)
 for n in files+extra:z.write(R/n,'source/'+n)
 z.write(O/'before/tests/compute_state/CMakeLists.txt','before/tests/compute_state/CMakeLists.txt')
p=O/'source-results.zip';print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),retained_objects=[str(p)for p in O.glob('*.obj')]),indent=2))
