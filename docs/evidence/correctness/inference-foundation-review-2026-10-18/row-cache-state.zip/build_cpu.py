from pathlib import Path
import json,sys,subprocess,os,time
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
cached=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/commands.json').read_text())
host=next(x['command']for x in reversed(cached)if x['tag']=='cpu-canonical-compile'and x['exit']==0)
flags=[x for x in host if not x.endswith('.cc')and not x.lower().startswith('/fo')]
records=json.loads((O/'cpu-commands.json').read_text())if(O/'cpu-commands.json').exists()else[]
link=next(x['command']for x in reversed(json.loads((R/'.scratch/inference-foundation-review-2026-10-18/row-cache-cpu/graph-commands.json').read_text()))if x['tag']=='graph-link'and x['exit']==0)
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]});env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
runtime=[str(R/'.scratch/build-compute-v2-dev/bin')]+[str(Path(p).parent)for p in link if p.endswith('.lib')and Path(p).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
def run(tag,cmd):
 start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(tag+'.stdout.log')).write_bytes(p.stdout);(O/(tag+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'cpu-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-3000:],flush=True);p.check_returncode()
run('cpu-compile',[*flags,R/'tests/compute_state/row_cache_consumer.cc','/Fo'+str(O/'cpu.obj')])
omit=str(R/'.scratch/inference-foundation-review-2026-10-18/row-cache-cpu/graph.obj')
cmd=[x for x in link if x!=omit and not x.startswith(('/OUT:','/MAP:'))]
run('cpu-link',[*cmd,O/'cpu.obj',R/'.scratch/build-compute-v2-dev/bin/hyle_compute_state.lib','/OUT:'+str(O/'cpu.exe')])
run('cpu',[O/'cpu.exe'])
