from pathlib import Path
import json,sys,subprocess,os,time
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
cache=R/'.scratch/inference-fusion-quantization-2026-10-18/deepseek-packed-history/cuda'
records=json.loads((O/'cuda-commands.json').read_text())if(O/'cuda-commands.json').exists()else[]
old=json.loads((cache/'commands.json').read_text())
host=next(x['command']for x in reversed(old)if x['tag']=='tests-compile'and x['exit']==0)
link=next(x['command']for x in reversed(old)if x['tag']=='link'and x['exit']==0)
flags=[x for x in host if not x.endswith('.cc')and not x.lower().startswith('/fo')]+['/DHYLE_ROW_CACHE_CUDA=1']
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]});env['VSLANG']='1033'
toolkit=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
runtime=[str(R/'.scratch/build-compute-v2-dev/bin'),str(toolkit/'bin'),str(toolkit/'bin/x64')]+[str(Path(p).parent)for p in link if p.endswith('.lib')and Path(p).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
def run(tag,cmd):
 start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(tag+'.stdout.log')).write_bytes(p.stdout);(O/(tag+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'cuda-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tag,p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-3000:],flush=True);p.check_returncode()
if not (O/'cuda.obj').exists() or (O/'cuda.obj').stat().st_mtime<(R/'tests/compute_state/row_cache_consumer.cc').stat().st_mtime:
 run('cuda-compile',[*flags,R/'tests/compute_state/row_cache_consumer.cc','/Fo'+str(O/'cuda.obj')])
replace={str(R/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/provider.obj'):str(R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cuda-provider.obj'),str(R/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/tensor-after.obj'):str(R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cuda-tensor.obj')}
cmd=[replace.get(x,x)for x in link if x!=str(cache/'tests.obj')and not x.startswith(('/OUT:','/MAP:'))]
run('cuda-link',[*cmd,O/'cuda.obj','/OUT:'+str(O/'cuda.exe')]);run('cuda',[O/'cuda.exe'])
