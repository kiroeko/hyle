#include <hyle/graph/progress.h>
#include <hyle/mem/allocator.h>
#include <hyle/sched/blocking.h>
#include <hyle/sched/scheduler.h>
#include <cstdio>

int main() {
  const auto allocator = hyle::mem::system_allocator();
  hyle::sched::Scheduler scheduler(1, allocator, 32);
  hyle::sched::BlockingPool pool(allocator, 1);
  hyle::graph::Invocation empty;
  const auto status = hyle::graph::prepare_progress(empty, scheduler, pool);
  if (status.code() != hyle::StatusCode::FailedPrecondition) return 1;
  scheduler.drain();
  pool.shutdown();
  std::puts("graph_progress: installed shared service and public Scheduler/BlockingPool dependencies verified");
  return 0;
}
