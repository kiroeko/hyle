from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BUILD = OUT.parent / 'optional-file-stream/cpu-service-build'
PREFIX = OUT / 'service-prefix'
CONSUMER_SOURCE = OUT / 'service-consumer-source'
CONSUMER = OUT / 'service-consumer-build'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def cache():
    rows = {}
    for line in (BUILD / 'CMakeCache.txt').read_text().splitlines():
        match = re.match(r'^([^/#][^:=]*):[^=]*=(.*)$', line)
        if match:
            rows[match[1]] = match[2]
    return rows


ENV = windows_compiler_environment(cache())
CMAKE = shutil.which('cmake', path=ENV['PATH'])
assert CMAKE


def run(label, command, cwd=ROOT, timeout=180):
    rows = read(OUT / 'delivery-commands.json') if (OUT / 'delivery-commands.json').exists() else []
    stem = f'{len(rows) + 1:03d}-{label}'
    row = dict(label=label, command=list(map(str, command)), cwd=str(cwd),
               stdout=stem + '.stdout.log', stderr=stem + '.stderr.log',
               started=time.strftime('%Y-%m-%dT%H:%M:%S%z'), exit_code=None)
    rows.append(row)
    save('delivery-commands.json', rows)
    print('START', stem, flush=True)
    started = time.monotonic()
    with (OUT / row['stdout']).open('wb') as out, (OUT / row['stderr']).open('wb') as err:
        child = subprocess.Popen(row['command'], cwd=cwd, env=ENV, stdout=out, stderr=err,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = child.pid
        save('delivery-commands.json', rows)
        row['exit_code'] = child.wait(timeout=timeout)
    row['seconds'] = round(time.monotonic() - started, 3)
    save('delivery-commands.json', rows)
    print('END', stem, row['exit_code'], row['seconds'], flush=True)
    for key in ('stdout', 'stderr'):
        print((OUT / row[key]).read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
    if row['exit_code']:
        raise SystemExit(row['exit_code'])
    return row


def snapshot():
    assert cache()['HYLE_COMPONENTS'] == 'compute_stream'
    destination = OUT / 'before-build-metadata'
    assert not destination.exists()
    destination.mkdir()
    for name in ['CMakeCache.txt', 'build.ninja', 'compile_commands.json', '.ninja_log', '.ninja_deps',
                 'HyleConfig.cmake', 'HylePackageIndex.cmake', 'install_manifest.txt']:
        shutil.copyfile(BUILD / name, destination / name)
    files = [p for p in BUILD.rglob('*') if p.is_file() and p.suffix.lower() in {'.obj', '.dll', '.lib'}]
    save('before-build-identities.json', [identity(p) for p in sorted(files)])
    save('delivery-machine.json', dict(computer=os.environ.get('COMPUTERNAME'),
                                      compiler=cache()['CMAKE_CXX_COMPILER'],
                                      build=str(BUILD), profile='MSVC 14.50 Ninja Release shared /MD'))
    print('saved original metadata and', len(files), 'object/library identities')


def configure():
    run('service-configure', [CMAKE, '-S', ROOT, '-B', BUILD,
        '-DHYLE_COMPONENTS=graph_progress', '-UHYLE_COMPUTE_ROUTES',
        '-DHYLE_STATIC=OFF', '-DHYLE_BUILD_TESTS=OFF', '-DHYLE_BUILD_BENCH=OFF',
        '-DHYLE_TRACE=OFF', '-DHYLE_INSTALL=ON', f'-DCMAKE_INSTALL_PREFIX={PREFIX}',
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DFETCHCONTENT_UPDATES_DISCONNECTED=ON'])
    values = cache()
    assert values['HYLE_COMPONENTS'] == 'graph_progress' and values['HYLE_STATIC'] == 'OFF'
    assert 'HYLE_COMPUTE_ROUTES' not in values
    current = read(BUILD / 'compile_commands.json')
    old = read(OUT / 'before-build-metadata/compile_commands.json')
    indexed = {row['file']: row for row in old}
    matched = [row for row in current if row['file'] in indexed and row['command'] == indexed[row['file']]['command']]
    new = [row for row in current if row['file'] not in indexed]
    changed = [row for row in current if row['file'] in indexed and row not in matched]
    assert len(new) == 13 and not changed, (len(new), changed)
    for row in new:
        relative = Path(row['file']).relative_to(ROOT / 'src')
        assert relative.parts[0] in {'graph', 'graph_progress'}, row
    assert not any(any(value in row['file'].lower() for value in
        ['compute_provider_', 'compute_route_', 'graph_route_', 'graph_batch', 'compute_batch', 'io_core']) for row in current)
    save('service-closure.json', dict(compile_units=len(current), reused_same_commands=len(matched),
         new_compile_units=new, current_compile_database=identity(BUILD / 'compile_commands.json'),
         forbidden_math_native_route_io=False, sdk_rebuild=False))
    print('closure:', len(current), 'compile rows;', len(matched), 'same commands;', len(new), 'new Graph/progress')


def dry_run():
    row = run('service-dry-run', [CMAKE, '--build', BUILD, '--parallel', '2', '--', '-n'])
    text = (OUT / row['stdout']).read_text()
    compiles = [line for line in text.splitlines() if re.search(r'Building (CXX|C|ASM_MASM) object', line)]
    links = [line for line in text.splitlines() if 'Linking ' in line]
    assert len(compiles) <= 30, compiles
    assert all('src/graph/' in line.replace('\\', '/') or 'src/graph_progress/' in line.replace('\\', '/')
               for line in compiles), compiles
    assert len(compiles) == 13 and len(links) == 2, (compiles, links)
    save('dry-run-plan.json', dict(compiles=compiles, links=links, build_authorized_within_scope=True))


def build():
    # Parent accepted the exact command comparison. CONFIGURE_DEPENDS prevents
    # an ordinary Ninja dry-run from looking past its simulated regeneration.
    closure = read(OUT / 'service-closure.json')
    assert closure['reused_same_commands'] == 73 and len(closure['new_compile_units']) == 13
    run('service-build', [CMAKE, '--build', BUILD, '--parallel', '2'])


def install():
    run('service-install', [CMAKE, '--install', BUILD])


def consumer_source():
    CONSUMER_SOURCE.mkdir(exist_ok=True)
    (CONSUMER_SOURCE / 'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(HyleProgressDelivery LANGUAGES CXX)
find_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph_progress)
if(TARGET hyle::graph OR TARGET hyle::_factor_graph_batch OR TARGET hyle::_factor_compute_backend_cpu OR TARGET hyle::_factor_io_core)
  message(FATAL_ERROR "The standalone service acquired a complete route or IO")
endif()
add_executable(progress-service main.cc)
target_compile_features(progress-service PRIVATE cxx_std_23)
target_link_libraries(progress-service PRIVATE hyle::graph_progress)
target_compile_options(progress-service PRIVATE /W4 /WX)
hyle_stage_runtime(progress-service)
''', encoding='utf-8')
    (CONSUMER_SOURCE / 'main.cc').write_text('''#include <hyle/graph/progress.h>
#include <hyle/mem/allocator.h>
#include <hyle/sched/blocking.h>
#include <hyle/sched/scheduler.h>
#include <cstdio>

int main() {
  const auto allocator = hyle::mem::system_allocator();
  hyle::sched::Scheduler scheduler(1, allocator, 32);
  hyle::sched::BlockingPool pool(allocator, 1);
  hyle::graph::Invocation empty;
  const auto status = hyle::graph::prepare_progress(empty, scheduler, pool);
  if (status.code() != hyle::StatusCode::FailedPrecondition) return 1;
  scheduler.drain();
  pool.shutdown();
  std::puts("graph_progress: installed shared service and public Scheduler/BlockingPool dependencies verified");
  return 0;
}
''', encoding='utf-8')


def consumer_configure():
    consumer_source()
    values = cache()
    run('consumer-configure', [CMAKE, '-S', CONSUMER_SOURCE, '-B', CONSUMER,
        '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
        f'-DCMAKE_C_COMPILER={values["CMAKE_C_COMPILER"]}',
        f'-DCMAKE_CXX_COMPILER={values["CMAKE_CXX_COMPILER"]}',
        f'-DCMAKE_MAKE_PROGRAM={values["CMAKE_MAKE_PROGRAM"]}',
        f'-DHyle_DIR={PREFIX / "lib/cmake/Hyle"}', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])


def exports():
    dumpbin = shutil.which('dumpbin', path=ENV['PATH'])
    assert dumpbin
    if not any(row['label'] == 'service-exports' and row['exit_code'] == 0
               for row in read(OUT / 'delivery-commands.json')):
        run('service-exports', [dumpbin, '/exports', BUILD / 'bin/hyle_graph_progress.dll'])
    run('consumer-imports', [dumpbin, '/imports', CONSUMER / 'progress-service.exe'])


def finalize():
    before = read(OUT / 'before-build-identities.json')
    changed = [row for row in before if identity(row['path']) != row]
    assert not changed, changed
    db = read(BUILD / 'compile_commands.json')
    compiled = []
    for row in read(OUT / 'service-closure.json')['new_compile_units']:
        compiled.append(dict(source=identity(row['file']), object=identity(row['output']), command=row['command']))
    save('fresh-service-identities.json', compiled)
    actual_db = read(CONSUMER / 'compile_commands.json')
    assert len(actual_db) == 1
    save('consumer-source-identities.json', [identity(CONSUMER_SOURCE / name) for name in ['CMakeLists.txt', 'main.cc']])
    commands = read(OUT / 'delivery-commands.json')
    final_run = next(row for row in reversed(commands) if row['label'] == 'consumer-run' and row['exit_code'] == 0)
    stdout = (OUT / final_run['stdout']).read_text()
    assert 'installed shared service' in stdout
    selected_exports = (OUT / next(row for row in commands if row['label'] == 'service-exports')['stdout']).read_text()
    assert 'prepare_progress' in selected_exports
    imports = (OUT / next(row for row in reversed(commands) if row['label'] == 'consumer-imports' and row['exit_code'] == 0)['stdout']).read_text()
    assert 'hyle_graph_progress.dll' in imports and 'prepare_progress' in imports and 'hyle_sched.dll' in imports
    installed = sorted(p for p in PREFIX.rglob('*') if p.is_file())
    save('installed-file-identities.json', [identity(p) for p in installed])
    files = [p for p in installed if p.suffix.lower() in {'.dll', '.lib', '.exp', '.pdb', '.ilk', '.map', '.exe'}]
    images = sorted(p for p in CONSUMER.iterdir() if p.is_file() and p.suffix.lower() in {'.dll', '.exe', '.lib', '.exp', '.pdb', '.ilk', '.map'})
    retain = sorted(p for p in BUILD.rglob('*.obj')) + sorted(CONSUMER.rglob('*.obj'))
    save('service-cleanup-candidates.json', dict(
        files=[identity(p) for p in files + images],
        bytes=sum(p.stat().st_size for p in files + images),
        installed_duplicate_images=[identity(p) for p in files],
        consumer_images=[identity(p) for p in images],
        retain=[identity(p) for p in retain], build_cache=str(BUILD),
        retained_install_metadata=[identity(p) for p in installed if p not in files],
        delete_executed=False))
    summary = dict(result='PASS', product='graph_progress', linkage='shared', offline=True,
         real_sdk_install=True, complete_graph_sdk=False, native_or_math_sdk_rebuild=False,
         base_commands_reused=73, freshly_compiled_hyle_tus=13, new_dlls=2,
         previous_cpu_service_objects_and_libraries_unchanged=True,
         installed_consumer_tus=1, consumer_result=stdout.strip(),
         final_run=final_run['stdout'],
         failure_history=['007 scratch consumer used a nonexistent k-prefixed enum; corrected to actual FailedPrecondition contract',
                          '008 was not started; 010 import inspection lacked the image after the compile failure',
                          '002/003 ordinary dry-run stopped at simulated CONFIGURE_DEPENDS regeneration; actual normal build was used'],
         export_owner='hyle_graph_progress.dll', direct_scheduler_product_request=False,
         build_cache=str(BUILD), fresh='fresh-service-identities.json',
         cleanup='service-cleanup-candidates.json', cleanup_count=len(files + images),
         cleanup_bytes=sum(p.stat().st_size for p in files + images),
         limits=['Only service delivery and public dependency/import validation',
                 'No numerical Graph execution, full Graph SDK, static build or performance claim'])
    save('service-summary.json', summary)
    save('service-receipt.json', dict(summary=identity(OUT / 'service-summary.json'),
         service_dll=identity(BUILD / 'bin/hyle_graph_progress.dll'),
         graph_dll=identity(BUILD / 'bin/hyle_graph.dll'),
         consumer=identity(CONSUMER / 'progress-service.exe'),
         commands=identity(OUT / 'delivery-commands.json')))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    action = argparse.ArgumentParser()
    action.add_argument('action', choices=['snapshot', 'configure', 'dry-run', 'build', 'install',
        'consumer-configure', 'consumer-build', 'consumer-run', 'exports', 'finalize'])
    name = action.parse_args().action
    if name == 'consumer-build':
        run('consumer-build', [CMAKE, '--build', CONSUMER, '--parallel', '2'])
    elif name == 'consumer-run':
        run('consumer-run', [CONSUMER / 'progress-service.exe'], cwd=CONSUMER, timeout=30)
    else:
        {'snapshot': snapshot, 'configure': configure, 'dry-run': dry_run, 'build': build,
         'install': install, 'consumer-configure': consumer_configure,
         'exports': exports, 'finalize': finalize}[name]()
