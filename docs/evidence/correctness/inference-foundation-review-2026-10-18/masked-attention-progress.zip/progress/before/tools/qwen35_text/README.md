# Qwen3.5-2B 推理架构实验消费者

这是用于验证新执行架构的独立测试产物，尚未完成，不是已交付的推理引擎。
只运行本地官方权重的 24 层 CUDA 纯文本计算，关闭 MTP 和视觉；不提供服务、安装规则或 Provider 绕过。

`prepare.py` 校验原输入清单的 13 个文件并输出原始权重偏移及固定 token IDs；Python 只负责输入准备和 tokenizer。
`main.cc` 使用公共 Compute/Graph 构建一个完整模型语义图。首次 prefill、带状态的多 token continuation、decode
分别使用相应 token 数的冷准备入口。conv/GDN 状态真实反馈，KV 使用固定容量并只更新新增行；失败会使当前请求失效。
六个 BF16 GQA attention 使用 typed `RaggedAttention`：Q/K/V 以 metadata-only reshape 表达为 THD，
每个 phase 持有真实 `BatchSchema`，六个节点共享同一 owned layout 与 metadata 输入。`q_indptr={0,T}`、
`kv_indptr={0,L}` 和 bottom-right causal 语义明确当前可见范围；本机固定旅程为 T/L=23/23、4/27、1/28。
每次冷准备在原 `graph::Invocation` slot 上调用 `graph::batch::prepare`，随后绑定普通输入与输出，
再调用原 `prepare_replay` / `submit`；保留两个原始 slot、完整 24 层和全部 KV/conv/GDN 状态。
`reference.py` 是独立 Torch oracle，显式保留 continuation 的 conv/GDN 初始状态，候选不会读取它的状态或结果。

`--progress direct|scheduler` 选择原 Invocation 的直接提交或可选进度驱动，默认 `direct`。
构建本消费者的已安装 SDK 须包含 CUDA Compute、Graph 和 Sched 产品；CMake 只查包和链接，不构建原生依赖。
`scheduler` 在冷创建的原槽上调用 `prepare_progress`，由原 Scheduler/BlockingPool 按实际片段的阻塞属性推进；
两种模式均在 Completion 成功后反馈状态、读取 token。同一 Model 的 tokens、KV 和状态共享，`evaluate` 须顺序调用，
两个槽不授权并发覆盖这些输入。成功或异常退出均先 drain 原槽，再结束池和 Scheduler，最后释放模型数据。

当前 RTX 4070 已完成两种模式的 prefill23 → continuation4 → decode1，每个 phase 为完整 1938 节点、
1252 个报告步骤（含 metadata View）；next token 为 20 → 248046 → 198。两模式的 150 个输出与状态 trace
逐字节一致，当前 direct 与上一冻结结果也全部一致。`submit_seconds` 只记录调用返回时间；完整 `seconds` 仍包含
完成等待与读取 next token。带 trace 的单次旅程用于接线与寿命核对，不作吞吐结论。
独立 Torch 参考的 logits 相对 L2 差异约 2.151%、1.957%、2.459%，数值接受和公平 llama.cpp 对照仍未完成。

显式 `--layer0-probe DIR` 用于诊断：另行发布 layer0 的五个 BF16 边界及四个 FFN 切片，
并导出默认图和诊断图的实际路由；默认运行的图与 trace 不新增这些输出。
首个明显传播位于 post-attention RMSNorm 的 token21/channel619。原 native 归约 mean 比已保存 Torch variance
低 2 个 F32 ULP，后续两乘跨过 BF16 中点；实际 F32→BF16 全部符合 RNE。原 kernel 控制与诊断重放的
47,104 个 F32/BF16 元素均与原 Hyle 逐 bit 相同，未改数学去匹配 Torch。归约顺序解释此点，不证明全部层误差同源；
插桩的 FFMA 变化、离线推演与实际观察的界限保留在[审查证据](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md)。
本地原输入与参考仍位于 `.scratch/inference-execution-refactor-2026-10-18/qwen35-text/`，没有复制权重或 SDK。
