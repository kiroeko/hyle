"""Exact one-member diagnostic-mask correction, no native SDK/cache mutation."""
from pathlib import Path
import hashlib,importlib.util,json

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('mask_runner',OUT/'run.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ROOT=b.ROOT
REF=ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows'
source=OUT/'diagmask-patch/diagmask-current.cu'
raw=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml-cuda/diagmask.cu')
manifest=ROOT/'third_party/ggml_cuda_runtime/patches.json'
item=next(v for v in b.read(manifest)['files'] if v['path']=='src/ggml-cuda/diagmask.cu')
data=raw.read_bytes().replace(b'\r\n',b'\n')
assert hashlib.sha256(data).hexdigest()==item['before_sha256']
for edit in item['edits']:
 assert data.count(edit['before'].encode())==1
 data=data.replace(edit['before'].encode(),edit['after'].encode(),1)
assert hashlib.sha256(data).hexdigest()==item['after_sha256']
assert data==source.read_bytes()
record=b.read(OUT/'diagmask-reference-audit/compile-recipe.json')
# The audit has already parsed the historical Windows command without shell expansion.
parsed=record['argv']
command=[]
for i,v in enumerate(parsed):
 low=v.lower()
 if low.startswith('-i') and 'source-4e1a7b2f39afe15d' in low:
  v='-I'+str(REF/('include' if 'src\\..\\include' in low else 'src'))
 elif low.endswith('\\diagmask.cu'):v=str(source)
 elif i and parsed[i-1]=='-o':v=str(OUT/'diagmask-current.obj')
 elif low.startswith('-xcompiler=-fd'):v='-Xcompiler=-Fd'+str(OUT/'diagmask-current.pdb')+',-FS'
 command.append(v)
command.insert(1,'-I'+str(REF/'src/ggml-cuda'))
assert not any('c:\\hyle-scratch' in v.lower() for v in command)
assert not (OUT/'diagmask-current.obj').exists(),'Only one approved CU compilation'
b.save('diagmask-compile-recipe.json',dict(command=command,source=b.identity(source),upstream=b.identity(raw),manifest=b.identity(manifest),
 headers=[b.identity(REF/p) for p in ['src/ggml-cuda/common.cuh','src/ggml-cuda/diagmask.cuh','src/ggml-cuda/vendors/cuda.h','include/ggml.h'] if (REF/p).is_file()],
 scope='Original SM89 norm-independent diagmask TU flags; exact current patch materialization; original reference patched headers and native bridge. One native archive member replaced explicitly. Other native SDK members not rebuilt.'))
b.run('diagmask-current-compile',command)
b.save('diagmask-fresh-identity.json',dict(source=b.identity(source),object=b.identity(OUT/'diagmask-current.obj'),command=command))
