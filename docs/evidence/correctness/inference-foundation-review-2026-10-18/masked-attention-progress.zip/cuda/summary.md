默认 CUDA 四口 SDPA 的 **dense F32 additive mask** 已由原 ggml F32 程序承载，实际 **5/5** 测试通过（010 link、012 run）。不改 schema、Graph core、默认排名或数学 dtype，不扫描 mask 内容；QKV 沿既有 F32 提升，mask 原精度参与广播 ADD，随后 causal exclusion、原 softmax/PV。只有私有新生 score 缓冲原地复用。

测试覆盖真实 default Direct/Graph、两槽两轮换地址、F32 bias 精度、BF16 Qwen23/32 GQA、query/key/head/batch 广播，以及128/128/1分块和因果 future+Inf。全-inf/未屏蔽+inf行按原普通 softmax 保留 NaN，未改成零。原无mask F16/BF16 prefill/decode回归也通过。

007 before真实失败暴露原CUDA diagmask减FLT_MAX不能覆盖+Inf：NaN vs FP64期望0.00659589516。Root以exactpatch改为future?-INFINITY:x；009只编这一个原CU，010 map确认显式替代原归档member，012同原断言通过。两个Hyle host TU严格编译通过，未重SDK/其他kernel。004真实component metadata闭包检查通过；只有attention测试target引入default/Graph路由依赖。

这仍是原 materialized/tiled F32 math 路径：score/softmax、QKV转换、provider私有分配、managed/host阻塞与同步成本均存在，不称融合或性能提升。Qwen形状一份score为23552B，既有QKV F32提升319488B，原mask2944B；新增inplace ADD不额外拥有score payload，完整私有峰值仍未知。未跑全模型或性能矩阵。外部mask仅dense F32；内部tile真实stride已测。

before/candidate/source.diff、旧失败XML/log、最终命令/XML、SDK/补丁/对象身份均保存。cleanup.json 的 files 是根目录4个 exe/map/exp/lib；retain保provider/test/currentdiag与old archive member对象。未删除或移动文件，等待root test.ps1精确回收。
