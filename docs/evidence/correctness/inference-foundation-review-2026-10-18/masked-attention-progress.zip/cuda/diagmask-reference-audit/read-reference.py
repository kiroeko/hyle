"""Inspect the immutable reference diagmask member; no compile or GPU execution."""
from pathlib import Path
import ctypes
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
REFERENCE = ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows'
RAW = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
REVISION = '7f6c9107235868d63892d9117a293d1007ba3471'
CUOBJDUMP = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/cuobjdump.exe')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def historical(name):
    return subprocess.run(['git', 'show', REVISION + ':' + name], cwd=ROOT,
                          check=True, capture_output=True).stdout


def arguments(command):
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    count = ctypes.c_int()
    pointer = shell.CommandLineToArgvW(command, ctypes.byref(count))
    try:
        return [pointer[i] for i in range(count.value)]
    finally:
        kernel.LocalFree(pointer)


def main():
    library = REFERENCE / 'lib/ggml-cuda.lib'
    archive = library.read_bytes()
    assert sha(archive) == 'ebc36f3034c307facbbbb2b7e75643551bb6324f23cceceae08901999c88aa11'
    assert archive[:8] == b'!<arch>\n'
    offset, names, members = 8, None, []
    while offset < len(archive):
        header = archive[offset:offset + 60]
        assert header[58:60] == b'`\n'
        size = int(header[48:58])
        token = header[:16].decode('ascii').strip()
        payload_offset = offset + 60
        payload = archive[payload_offset:payload_offset + size]
        if token == '//':
            names = payload
        name = token
        if token.startswith('/') and token[1:].isdigit():
            start = int(token[1:])
            name = names[start:names.index(b'\0', start)].decode('ascii')
        if name.endswith('diagmask.cu.obj'):
            members.append(dict(name=name, header_offset=offset,
                                payload_offset=payload_offset, bytes=size,
                                sha256=sha(payload)))
            assert sha(payload) == '23046bcdbfaa257c8d2926814e6585497e63edca542c9f1788a839963e0acf60'
            (OUT / 'diagmask-reference.obj').write_bytes(payload)
        offset = payload_offset + size + (size & 1)
    assert len(members) == 1
    save('archive-member.json', dict(library=identity(library), member=members[0]))

    recipe_path = ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-static/compile_commands.json'
    recipes = json.loads(recipe_path.read_text(encoding='utf-8'))
    recipe = [item for item in recipes if item['file'].replace('\\', '/').endswith('/ggml-cuda/diagmask.cu')]
    assert len(recipe) == 1
    save('compile-recipe.json', dict(locator=str(recipe_path), locator_only=True,
        old_root_paths_must_not_be_executed=True, recipe=recipe[0],
        command_utf8_sha256=sha(recipe[0]['command'].encode()),
        argv=arguments(recipe[0]['command']),
        rewrite_includes=[str(REFERENCE / p) for p in ['src', 'include', 'src/ggml-cuda']] +
                         [str(ROOT / 'src/compute_provider_ggml_cuda')],
        rewrite_only='Use the scratch overlay input/object/PDB and actual reference headers; preserve original flags.'))

    source_paths = [RAW / 'src/ggml-cuda/diagmask.cu',
        ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src/ggml-cuda/diagmask.cu',
        ROOT / '.scratch/b-cuda-d5/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src/ggml-cuda/diagmask.cu']
    source_identities = [identity(p) for p in source_paths]
    assert all(p['sha256'] == 'dbd7dcd55bbe033bb34d8ead3733c37a7e4e2eecb905a9199315d98cc3e04f7a' for p in source_identities)
    manifests = []
    for name in ['third_party/ggml_runtime/patches.json',
                 'third_party/ggml_cpu_runtime/patches.json',
                 'third_party/ggml_cuda_runtime/patches.json',
                 'third_party/ggml_cuda_runtime/iq1-patches.json']:
        data = historical(name)
        manifest = json.loads(data)
        assert not any('diagmask' in item['path'] for item in manifest['files'])
        manifests.append(dict(revision=REVISION, path=name, bytes=len(data), sha256=sha(data),
                              edited_paths=[item['path'] for item in manifest['files']],
                              diagmask_edited=False))
    lock = {item['name']: item for item in json.loads(historical('cmake/HyleDependencyLock.json'))['dependencies']}
    seed = (lock['ggml_runtime_patches']['vendored']['tree_sha256'] +
            lock['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
            sha(historical('src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py')) +
            sha(historical('src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py')) +
            lock['ggml_cuda_runtime_patches']['vendored']['tree_sha256'])
    historical_source_id = sha(seed.encode())[:16]
    assert historical_source_id == 'f99368c68335266b'
    reference_identity = json.loads((REFERENCE / 'identity.json').read_text())
    assert reference_identity['source_id'] == historical_source_id
    assert 'src/ggml-cuda/diagmask.cu' not in reference_identity['files']
    headers = []
    for name in ['src/ggml-cuda/common.cuh', 'src/ggml-cuda/diagmask.cuh']:
        item = identity(REFERENCE / name)
        assert item['sha256'] == reference_identity['files'][name]
        headers.append(item)
    save('source-provenance.json', dict(
        limitation='Reference identity captures diagmask.cuh but not diagmask.cu; binary arithmetic is established independently by the original archive member SASS.',
        reference_identity=identity(REFERENCE / 'identity.json'),
        historical_revision=REVISION, historical_generated_source_id=historical_source_id,
        sources=source_identities, historical_manifests=manifests, actual_patched_headers=headers,
        source_line=14,
        original_expression='dst[i] = x[i] - (col > n_past + row % rows_per_channel) * FLT_MAX;',
        materializer_rule='prepare_source.py:75-77 copies raw bytes for paths absent from edited; prepare_cuda_iq1_manifest.py:21-28 only combines the listed path edits.',
        compiled=False, gpu_execution=False, product_modified=False))

    obj = OUT / 'diagmask-reference.obj'
    command = [str(CUOBJDUMP), '--dump-sass', '--function', '_Z17diag_mask_inf_f32PKfPfiii', str(obj)]
    result = subprocess.run(command, capture_output=True, check=True)
    (OUT / 'diagmask-reference.sass.txt').write_bytes(result.stdout)
    (OUT / 'cuobjdump.stderr.txt').write_bytes(result.stderr)
    sass = result.stdout.decode('utf-8')
    assert 'FFMA.FTZ R9, R0, -3.40282346638528859812e+38, R9' in sass
    assert 'FSEL R0, RZ, 1, !P0' in sass
    save('summary.json', dict(scope='Read-only original SDK diagmask arithmetic/recipe review; scratch evidence writes only.',
        result='CONFIRMED_ORIGINAL_FINITE_FLT_MAX_ARITHMETIC',
        kernel='_Z17diag_mask_inf_f32PKfPfiii', architecture='sm_89',
        evidence=['0x0240 ISETP.GT.AND future comparison',
                  '0x0260 FSEL R0, RZ, 1, !P0: future becomes 0/1',
                  '0x0270 FFMA.FTZ R9, R0, -FLT_MAX, R9; immediate 0xff7fffff',
                  '0x0280 STG.E result'],
        interpretation='Actual compiled expression is x + (future ? 1 : 0) * (-FLT_MAX), not a select of -INFINITY.',
        cuobjdump_command=command, artifacts=[identity(OUT / name) for name in [
            'archive-member.json', 'compile-recipe.json', 'source-provenance.json',
            'diagmask-reference.obj', 'diagmask-reference.sass.txt', 'cuobjdump.stderr.txt']]))
    print(json.dumps(dict(result='CONFIRMED', output=str(OUT),
                          member=members[0], summary=identity(OUT / 'summary.json')), indent=2))


if __name__ == '__main__':
    main()
