include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)
message(STATUS "CUDA runtime patch and license identity PASS")
