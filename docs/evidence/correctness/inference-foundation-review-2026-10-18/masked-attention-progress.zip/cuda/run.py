from pathlib import Path
import argparse,difflib,hashlib,json,os,subprocess,sys,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
ARCH=OUT.parent
BASE=ARCH/'qwen-progress-journey'
META=ARCH/'native-runtime-retirement/metadata-oom-review'
SOURCE='src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
TEST='tests/compute_provider_ggml_cuda/attention_test.cc'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(n,v): (OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def env():
 sys.path.insert(0,str(ROOT/'scripts'))
 from hyle_environment import windows_compiler_environment
 from hyle_support import read_cache
 e=windows_compiler_environment(read_cache(ROOT/'.scratch/build-compute-v2-dev'))
 dirs=[str(Path(v).parent) for v in read(BASE/'link-plan.json')['command'] if v.lower().endswith('.lib') and Path(v).is_absolute()]
 dirs+=['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',str(ROOT/'.scratch/build-compute-v2-dev/bin')]
 e['PATH']=os.pathsep.join(dict.fromkeys(dirs))+os.pathsep+e['PATH'];e['VSLANG']='1033'
 return e
def run(tag,cmd,timeout=180):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';cmd=list(map(str,cmd))
 row=dict(tag=tag,command=cmd,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
 rows.append(row);save('commands.json',rows);print('START',stem,flush=True);start=time.monotonic()
 with (OUT/row['stdout']).open('wb') as so,(OUT/row['stderr']).open('wb') as se:
  result=subprocess.run(cmd,cwd=ROOT,env=env(),stdout=so,stderr=se,timeout=timeout)
 row.update(exit=result.returncode,seconds=time.monotonic()-start);save('commands.json',rows)
 print('END',stem,result.returncode,flush=True)
 if result.returncode:
  print((OUT/row['stdout']).read_text(errors='replace')[-14000:]);print((OUT/row['stderr']).read_text(errors='replace')[-14000:]);raise SystemExit(result.returncode)
 return row
def recipes():
 old=next(v['command'] for v in read(META/'commands.json') if Path(v['source']['path']).name=='ggml_cuda_provider.cc')
 product=[('/Fo'+str(OUT/'ggml-provider.obj')) if v.lower().startswith('/fo') else
          '/external:I'+str(ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows/include') if v.lower().startswith('/external:i') and 'source-4e1a7b2f39afe15d' in v else v for v in old]
 old=next(v['command'] for v in read(BASE/'compile-recipes.json') if v['tag']=='consumer')
 test=[('/Fo'+str(OUT/'attention-test.obj')) if v.lower().startswith('/fo') else str(ROOT/TEST) if v.lower().endswith('.cc') else v for v in old]
 rows=[dict(source=identity(ROOT/SOURCE),object=str(OUT/'ggml-provider.obj'),command=product),dict(source=identity(ROOT/TEST),object=str(OUT/'attention-test.obj'),command=test)]
 save('compile-recipes.json',rows);return rows
def compile_():
 rows=[]
 previous={v['object']['path']:v for v in read(OUT/'fresh-identities.json')} if (OUT/'fresh-identities.json').exists() else {}
 for r in recipes():
  old=previous.get(r['object'])
  if old and old['command']==r['command'] and identity(r['source']['path'])==old['source'] and identity(old['object']['path'])==old['object']:
   rows.append(old);save('fresh-identities.json',rows);continue
  run(Path(r['object']).stem+'-compile',r['command'])
  assert identity(r['source']['path'])==r['source']
  rows.append(dict(source=r['source'],object=identity(r['object']),command=r['command']))
  save('fresh-identities.json',rows)
def link():
 base=read(BASE/'link-plan.json');old=base['command']
 for r in read(BASE/'link-input-identities.json'): assert identity(r['path'])==r,r['path']
 original=next(v for v in base['source_objects'] if Path(v['source']['path']).as_posix().endswith(SOURCE))
 assert original['source']['sha256']==next(v['sha256'] for v in read(OUT/'before-identities.json') if v['path']==SOURCE)
 consumer=next(v['output'] for v in base['compile_recipes'] if v['tag']=='consumer')
 chosen=[]
 for v in old[1:]:
  if v==consumer or v.upper().startswith(('/OUT:','/MAP:')): continue
  if v==original['object']['path']:v=str(OUT/'ggml-provider.obj')
  chosen.append(v)
 chosen.insert(0,str(OUT/'attention-test.obj'))
 if (OUT/'diagmask-current.obj').exists():chosen.insert(0,str(OUT/'diagmask-current.obj'))
 io=read(ARCH/'optional-file-stream/cuda/link-plan.json')['command']
 chosen += [v for v in io if Path(v).name.lower() in {'gtest_main.lib','gtest.lib'}]
 chosen=list(dict.fromkeys(chosen));objects=[v for v in chosen if v.lower().endswith('.obj')];rest=[v for v in chosen if not v.lower().endswith('.obj')]
 cmd=[old[0],*objects,*rest,'/OUT:'+str(OUT/'attention-tests.exe'),'/MAP:'+str(OUT/'attention-tests.map')]
 save('link-plan.json',dict(command=cmd,base=str(BASE/'link-plan.json'),replaced=original,removed_model_consumer=consumer))
 save('link-input-identities.json',[identity(v) for v in cmd if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}])
 run('attention-tests-link',cmd)
 text=(OUT/'attention-tests.map').read_text(errors='replace')
 selected=[x for x in text.splitlines() if '?supports@internal@ggml_cuda@compute@hyle@@' in x]
 assert selected and all('ggml-provider.obj' in x for x in selected)
 save('map-selected-owners.json',dict(symbols=selected,provider=identity(OUT/'ggml-provider.obj'),test=identity(OUT/'attention-test.obj')))
 if (OUT/'diagmask-current.obj').exists():
  diag=[x for x in text.splitlines() if '?ggml_cuda_op_diag_mask_inf@@' in x]
  assert diag and all('diagmask-current.obj' in x for x in diag)
  save('diagmask-selected-owner.json',dict(symbols=diag,object=identity(OUT/'diagmask-current.obj')))
def execute():
 run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
 run('attention-tests-run',[OUT/'attention-tests.exe','--gtest_filter=GgmlCudaMaskedAttention.*:GgmlCudaAttention.OriginalPrefillDecodeAndIndependentReplays','--gtest_color=no','--gtest_output=xml:'+str(OUT/'tests.xml')],timeout=180)
def before():
 save('old-diag-image-identities.json',[identity(OUT/('attention-tests'+s)) for s in ['.exe','.map','.exp','.lib']])
 (OUT/'old-diag-link-plan.json').write_bytes((OUT/'link-plan.json').read_bytes())
 run('old-diag-causal-before',[OUT/'attention-tests.exe','--gtest_filter=GgmlCudaMaskedAttention.DefaultDirectAndGraphTilesPreserveMaskPitchAndCausality','--gtest_color=no','--gtest_output=xml:'+str(OUT/'old-diag-tests.xml')],timeout=180)
def metadata():
 source=OUT/'metadata-src';source.mkdir(exist_ok=True)
 (source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(masked_attention_component_selection LANGUAGES NONE)
set(HYLE_SOURCE_DIR "'''+ROOT.as_posix()+'''")
set(HYLE_TARGET_PROCESSOR x86_64)
set(HYLE_COMPONENTS compute)
set(HYLE_COMPUTE_ROUTES cuda)
set(HYLE_BUILD_TESTS OFF)
include("${HYLE_SOURCE_DIR}/cmake/HyleComponents.cmake")
set(original_products "${HYLE_PRODUCTION_COMPONENT_LIST}")
if("graph_route_cuda" IN_LIST HYLE_PRODUCTION_COMPONENT_LIST OR HYLE_TEST_FIXTURE_COMPONENT_LIST)
 message(FATAL_ERROR "Provider tests changed a test-disabled product")
endif()
set(HYLE_BUILD_TESTS ON)
include("${HYLE_SOURCE_DIR}/cmake/HyleComponents.cmake")
if(NOT original_products STREQUAL HYLE_PRODUCTION_COMPONENT_LIST)
 message(FATAL_ERROR "Provider test dependencies changed the product closure")
endif()
if(NOT "graph_route_cuda" IN_LIST HYLE_TEST_FIXTURE_COMPONENT_LIST)
 message(FATAL_ERROR "Missing actual default Graph attention test assembly")
endif()
if("graph" IN_LIST HYLE_PRODUCTION_PRODUCT_LIST)
 message(FATAL_ERROR "Test Graph became a public production product")
endif()
message(STATUS "CUDA provider TEST_DEPS closure is finite and product-independent")
''',encoding='utf-8',newline='\n')
 run('component-metadata',['cmake','-S',source,'-B',OUT/'metadata-build','-Werror=dev'])
def freeze():
 import xml.etree.ElementTree as ET
 suites=ET.parse(OUT/'tests.xml').getroot();assert int(suites.attrib['tests'])==5 and int(suites.attrib['failures'])==0
 sources=[SOURCE,TEST,'tests/compute_provider_ggml_cuda/CMakeLists.txt','cmake/HyleComponents.cmake']
 diff='';rows=[]
 for source in sources:
  before=(OUT/'before'/source).read_bytes();after=(ROOT/source).read_bytes()
  target=OUT/'candidate'/source;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after)
  rows.append(identity(ROOT/source))
  diff+=''.join(difflib.unified_diff(before.decode().replace('\r\n','\n').splitlines(True),after.decode().replace('\r\n','\n').splitlines(True),fromfile='before/'+source,tofile='candidate/'+source))
 (OUT/'source.diff').write_text(diff,encoding='utf-8',newline='\n');save('source-identities.json',rows)
 for r in read(OUT/'fresh-identities.json'):
  assert identity(r['source']['path'])==r['source'];assert identity(r['object']['path'])==r['object']
 save('cleanup-identities.json',[identity(OUT/('attention-tests'+s)) for s in ['.exe','.map','.exp','.lib']])
 save('retained-object-identities.json',[identity(OUT/n) for n in ['ggml-provider.obj','attention-test.obj']])
 print('Frozen candidate source/object/cleanup identities; no deletion.')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['compile','link','run','before','metadata','freeze']);a=p.parse_args()
 {'compile':compile_,'link':link,'run':execute,'before':before,'metadata':metadata,'freeze':freeze}[a.action]()
