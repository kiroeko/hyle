from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
tests=ET.parse(OUT/'tests.xml').getroot()
assert tests.attrib['tests']=='5' and tests.attrib['failures']=='0'
before=ET.parse(OUT/'old-diag-tests.xml').getroot()
assert before.attrib['tests']=='1' and before.attrib['failures']=='1'
fresh=read(OUT/'fresh-identities.json')
for r in fresh:
 assert identity(r['source']['path'])==r['source']
 assert identity(r['object']['path'])==r['object']
diag=read(OUT/'diagmask-fresh-identity.json')
assert identity(diag['source']['path'])==diag['source']
assert identity(diag['object']['path'])==diag['object']
objects=[identity(OUT/n) for n in ['ggml-provider.obj','attention-test.obj','diagmask-current.obj','diagmask-reference-audit/diagmask-reference.obj']]
files=read(OUT/'cleanup-identities.json')
assert len(files)==4
for r in files:assert identity(r['path'])==r
save('cleanup.json',dict(files=files,retain=objects,rule='Root test.ps1 exact cleanup after archive; retain all source/raw/log/JSON and every object. No deletion or moving performed by this agent.'))
own_sources=read(OUT/'source-identities.json')
patch_files=['third_party/ggml_cuda_runtime/patches.json','third_party/ggml_cuda_runtime/NOTICE.md','cmake/HyleDependencyLock.json']
save('final-source-identities.json',dict(owned=own_sources,root_patch=[identity(ROOT/p) for p in patch_files],generated_native=diag['source'],
 notes='Product provider file already used CRLF before this task and retains CRLF. Exact before/candidate/source/object identities preserve those bytes; review source.diff normalizes only diff text to LF. No post-test source normalization/recompile.'))
(OUT/'combined-source.diff').write_text((OUT/'source.diff').read_text()+(OUT/'diagmask-patch/source.diff').read_text(),encoding='utf-8',newline='\n')
summary=dict(result='PASS',scope='Default CUDA ordinary four-port SDPA with dense Float32 additive mask; original single Invocation/Completion, Direct and Graph.',
    implementation=dict(provider='ggml CUDA original Float32 score/softmax/PV program',
        source='src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
        functions=['internal::supports','Invocation::attention_bias','Invocation::attention','Invocation::tiled_attention'],
        admission='Existing dense BSHD Float32/Float16/BFloat16 QKV domain and Float32 accumulation; optional fourth input is plain dense Float32 rank0..4 with native indexing bounds and schema-validated right-aligned broadcasting over B,Hq,Q,S. Boolean and non-Float32 mask domains remain unimplemented.',
        lowering='Original Q/K/V Float32 casts, QK matmul and scale; Float32 native broadcast ADD on a fresh private scaled-score buffer; causal exclusion after bias; original Float32 softmax/PV and final output conversion.',
        strides='External mask remains dense. Tiled internal mask query views preserve original head/batch pitches; singleton query/key/head/batch dimensions broadcast through the original native binary kernel. No host/content scan or length inference.',
        ownership='ADD aliases only a fresh private score intermediate with one local consumer. Caller inputs/mask/output alias support is unchanged; no new owner, plan, executor, registry or route rule.'),
    native_fix=dict(reason='The actual cached original diagmask kernel subtracts FLT_MAX instead of replacing future values; positive infinity remained visible and produced NaN.',
        before='007-old-diag-causal-before: actual default Direct b0/q0/h0/d0 NaN vs independent FP64 expected0.006595895159997457; original assertion and tolerance retained.',
        actual_original='diagmask-reference-audit: extracted original archive member77404B sha23046bcdbfaa257c8d2926814e6585497e63edca542c9f1788a839963e0acf60; actual SASS FSEL0/1 then FFMA with -FLT_MAX.',
        patch='Exact upstream diagmask.cu replaces future scores with -INFINITY; root owns patches.json/NOTICE/lock update. Upstreamdbd7dcd5→candidate666b6e64; locked patch tree5afe4f76 versionv5.',
        validation='009 compiles only that original CUDA TU under original SM89/fastmath/host flags against actual reference patched headers;010 map confirms explicit diagmask-current.obj supersedes original member. All other SDK kernels remain cached.',
        manifest=identity(ROOT/patch_files[0]),native_source=diag['source'],native_object=diag['object']),
    validation=dict(hardware='RTX4070 SM89, driver617.14, CUDA13.3 cached native SDK',
        final_link='010-attention-tests-link',final_run='012-attention-tests-run',tests=5,failures=0,
        fresh_host_TUs=['ggml_cuda_provider.cc','attention_test.cc'],fresh_native_TUs=['diagmask.cu'],
        new_tests=[v.attrib['name'] for s in tests for v in s if v.tag=='testcase' and v.attrib.get('classname')=='GgmlCudaMaskedAttention'],
        coverage=['Real default Direct and default Graph select ggml for explicit Float32 masks,2originalslots each with2runs changing all input addresses.',
          'Float32 QKV/output bias1+2^-11 distinguishes trueFloat32 from both Float16/BFloat16 narrowing; independent FP64 oracle.',
          'All-inf and unexcluded+inf rows preserve ordinary softmax NaNs; no zero-normalization change.',
          'BF16 Qwen Q[1,23,8,256],KV[1,32,2,256],mask[23,32],scale1/16,causalfalse.',
          'Right-aligned query/head broadcast[2,1,1,7],key/batch broadcast[1,4,5,1],zero/negative scale.',
          'B2/H8/Q257/K273/D8 creates real128/128/1querytiles; full per-head/batch mask retains pitch and global causal position, including future+Inf values.',
          'GraphOutput blocks rebind until released; second run then succeeds on changed actual addresses.',
          'Original unmasked F16/BF16 prefill/decode independent replay regression preserved.'],
        compile_checks='Final provider008 and test005 /W4 /WX pass.009 native flags match original; original CUDA header C4819 warnings retained. Native SDK was not rebuilt.',
        metadata='004 configure-only real HyleComponents TEST_DEPS resolution passes with identical test-disabled/enabled production closure, finite Graph fixture closure. Only attention_test.cc target gains default/Graph routes; other ggml provider test target dependencies stay unchanged.',
        diff_check='git diff --check passed for the four owned product/test/config files.'),
    costs=dict(fused_sdpa=False,runtime='Existing Managed, provider-owned workspace/private allocations, blocks_host=true,capture_compatible=false; original bridge reports2synchronizations.',
        qwen_logical_bytes=dict(existing_QKV_F32_widening=319488,one_F32_score_plane=23552,borrowed_mask=2944,new_score_payload_from_inplace_ADD=0),
        actual_peak='Not measured and not represented as zero. Existing score/scale/softmax/PV payloads, F32 widening/transposition/final conversion, metadata, provider buffers and original native allocations remain. Long shapes retain original query tiling/liveness rather than full-query score allocation.',
        proposal='Existing provider persistent/copy/repack/private peak cost fields remain unknown (nullopt) where not supplied; no fabricated precise budget or performance win.'),
    failure_history=['002 test compilation rejected private Completion::reset; corrected to public move assignment.','003 test compilation rejected Status as bool; corrected explicit .ok().','007 actual old diag +Inf causal failure retained; fixed original native implementation, no test weakening.','First freeze helper had an incorrect LF-only assumption for a preexisting CRLF product file; helper fixed to retain exact source bytes, no product/test change after passing execution.'],
    unverified=['No full Qwen/model run or throughput/peak-memory benchmark.','This is a materialized/tiled Float32 math SDPA route, not new fused masked FlashAttention.','New mask support is dense Float32, not arbitrary floating dtype or arbitrary caller strides.','Scalar mask admitted by existing native broadcast geometry but no extra scalar Cartesian test was added; key singleton/query/head/batch broadcasts were actually tested.','No broader native kernel suite or other system/device revalidation.'],
    files=dict(source_diff='source.diff',combined_diff='combined-source.diff',source_identities='final-source-identities.json',object_identities='retained-object-identities.json',cleanup='cleanup.json',commands='commands.json',xml='tests.xml'),
    frozen=True)
save('summary.json',summary)
(OUT/'summary.md').write_text('''默认 CUDA 四口 SDPA 的 **dense F32 additive mask** 已由原 ggml F32 程序承载，实际 **5/5** 测试通过（010 link、012 run）。不改 schema、Graph core、默认排名或数学 dtype，不扫描 mask 内容；QKV 沿既有 F32 提升，mask 原精度参与广播 ADD，随后 causal exclusion、原 softmax/PV。只有私有新生 score 缓冲原地复用。

测试覆盖真实 default Direct/Graph、两槽两轮换地址、F32 bias 精度、BF16 Qwen23/32 GQA、query/key/head/batch 广播，以及128/128/1分块和因果 future+Inf。全-inf/未屏蔽+inf行按原普通 softmax 保留 NaN，未改成零。原无mask F16/BF16 prefill/decode回归也通过。

007 before真实失败暴露原CUDA diagmask减FLT_MAX不能覆盖+Inf：NaN vs FP64期望0.00659589516。Root以exactpatch改为future?-INFINITY:x；009只编这一个原CU，010 map确认显式替代原归档member，012同原断言通过。两个Hyle host TU严格编译通过，未重SDK/其他kernel。004真实component metadata闭包检查通过；只有attention测试target引入default/Graph路由依赖。

这仍是原 materialized/tiled F32 math 路径：score/softmax、QKV转换、provider私有分配、managed/host阻塞与同步成本均存在，不称融合或性能提升。Qwen形状一份score为23552B，既有QKV F32提升319488B，原mask2944B；新增inplace ADD不额外拥有score payload，完整私有峰值仍未知。未跑全模型或性能矩阵。外部mask仅dense F32；内部tile真实stride已测。

before/candidate/source.diff、旧失败XML/log、最终命令/XML、SDK/补丁/对象身份均保存。cleanup.json 的 files 是根目录4个 exe/map/exp/lib；retain保provider/test/currentdiag与old archive member对象。未删除或移动文件，等待root test.ps1精确回收。
''',encoding='utf-8',newline='\n')
save('final-manifest.json',dict(summary=identity(OUT/'summary.json'),summary_text=identity(OUT/'summary.md'),cleanup=identity(OUT/'cleanup.json'),
 sources=identity(OUT/'final-source-identities.json'),objects=objects,
 logs=[identity(OUT/n) for n in ['007-old-diag-causal-before.stdout.log','007-old-diag-causal-before.stderr.log','012-attention-tests-run.stdout.log','012-attention-tests-run.stderr.log','tests.xml','old-diag-tests.xml']]))
print(json.dumps(dict(summary=identity(OUT/'summary.json'),cleanup=identity(OUT/'cleanup.json'),objects=objects),indent=2))
