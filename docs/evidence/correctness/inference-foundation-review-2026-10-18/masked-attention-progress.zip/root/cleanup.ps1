param([switch]$ReclaimMaskedAttentionProgress)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not $ReclaimMaskedAttentionProgress) { throw 'Specify -ReclaimMaskedAttentionProgress; no default deletion.' }
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace + [IO.Path]::DirectorySeparatorChar
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/masked-attention-progress/root'
function Get-CheckedFile($row) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $row.path))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $parent = [IO.Path]::GetDirectoryName($path)
    while ($parent -eq $workspace -or $parent.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        if ((Get-Item -LiteralPath $parent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked ancestor: $parent" }
        $parent = [IO.Path]::GetDirectoryName($parent)
    }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $row.bytes -or
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $row.sha256) { throw "File changed: $path" }
    return $item
}
$receipt = Get-Content -LiteralPath (Join-Path $stage 'archive-receipts.json') -Raw | ConvertFrom-Json
$evidence = Get-CheckedFile $receipt.archive
$zip = [IO.Compression.ZipFile]::OpenRead($evidence.FullName)
try {
    $reader = [IO.StreamReader]::new($zip.GetEntry('cleanup-plan.json').Open())
    try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if ($frozen -cne [IO.File]::ReadAllText((Join-Path $stage 'cleanup-plan.json'))) { throw 'Cleanup differs from archive' }
} finally { $zip.Dispose() }
$plan = $frozen | ConvertFrom-Json
$scope = '.scratch/architecture-refactor-2026-10-18/'
$allowed = @('cuda-sdpa-mask', 'explicit-graph-progress/service-prefix/bin',
    'explicit-graph-progress/service-prefix/lib', 'explicit-graph-progress/service-consumer-build') |
    ForEach-Object { [IO.Path]::GetFullPath((Join-Path $workspace ($scope + $_))) }
$targets = @()
foreach ($row in $plan.files) {
    $item = Get-CheckedFile $row
    if ($item.DirectoryName -notin $allowed -or $item.Extension -notin @('.exe', '.map', '.exp', '.lib', '.dll')) {
        throw "Unexpected image: $item"
    }
    $targets += $item
}
foreach ($row in $plan.retain) { $null = Get-CheckedFile $row }
if ($targets.Count -ne $receipt.files -or @($targets.FullName | Select-Object -Unique).Count -ne $receipt.files) {
    throw 'Unexpected image set'
}
foreach ($item in $targets) { Remove-Item -LiteralPath $item.FullName -Force }
$result = @{ files = $targets.Count; bytes = ($targets | Measure-Object Length -Sum).Sum;
    retained_files = @($plan.retain).Count; archive_verified = $true; other_cache_retained = $true }
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'cleanup-result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 5
