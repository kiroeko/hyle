from pathlib import Path
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18'
CUDA = BASE / 'cuda-sdpa-mask'
PROGRESS = BASE / 'explicit-graph-progress'
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve(strict=True)
    assert path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def checked(row):
    current = identity(ROOT / row['path'])
    assert current['bytes'] == row['bytes'] and current['sha256'] == row['sha256'], row['path']
    return current


def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


service = read(PROGRESS / 'service-cleanup-candidates.json')
cuda_files = read(CUDA / 'cleanup-identities.json')
cuda_retained = read(CUDA / 'retained-object-identities.json')
plan = dict(files=[checked(row) for row in service['files'] + cuda_files],
            retain=[checked(row) for row in service['retain'] + cuda_retained])
assert len({row['path'] for row in plan['files']}) == len(plan['files'])
assert not ({row['path'] for row in plan['files']} & {row['path'] for row in plan['retain']})
write(OUT / 'cleanup-plan.json', plan)

extensions = {'.json', '.log', '.xml', '.txt', '.py', '.ps1', '.diff', '.cc', '.cpp',
              '.h', '.cuh', '.cu', '.cmake', '.md', '.sass', '.ptx', '.map'}
files = {}
for scope, label, omitted in [
    (CUDA, 'cuda', {'metadata-build', '__pycache__'}),
    (PROGRESS, 'progress', {'component-selection', 'service-prefix', 'service-consumer-build',
                          'service-consumer-first', '__pycache__'}),
    (BASE / 'apple-f32-partials-review', 'apple-review', set()),
    (OUT, 'root', set()),
]:
    for path in scope.rglob('*'):
        relative = path.relative_to(scope)
        if (path.is_file() and path.suffix in extensions and not set(relative.parts) & omitted
                and path.name not in {'archive-receipts.json', 'cleanup-result.json'}):
            files[label + '/' + relative.as_posix()] = path

extras = [
    'cmake/HyleComponents.cmake', 'cmake/HyleDependencyLock.json',
    'third_party/ggml_cuda_runtime/patches.json', 'third_party/ggml_cuda_runtime/NOTICE.md',
    'third_party/ggml_cuda_runtime/LICENSE', 'third_party/mlx_cast/LICENSE',
    'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'tests/compute_provider_ggml_cuda/attention_test.cc', 'tests/compute_provider_ggml_cuda/CMakeLists.txt',
    'docs/developer/current-work.md', 'docs/architecture/compute-design.md', 'docs/user/compute.md',
    'docs/user/batch-attention.md', 'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md', 'test.ps1',
]
for name in read(PROGRESS / 'summary.json')['files'] + extras:
    files['source/' + name] = ROOT / name
files['cleanup-plan.json'] = OUT / 'cleanup-plan.json'

target = EVIDENCE / 'masked-attention-progress.zip'
assert not target.exists(), 'Do not overwrite frozen evidence'
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9, strict_timestamps=False) as archive:
    for name, path in sorted(files.items()):
        archive.write(path, name)
    archive.writestr('archive-manifest.json', json.dumps([
        dict(entry=name, **identity(path)) for name, path in sorted(files.items())], indent=2) + '\n')
receipt = dict(archive=identity(target), files=len(plan['files']),
               bytes=sum(row['bytes'] for row in plan['files']),
               retained_files=len(plan['retain']), source_entries=len(files))
write(OUT / 'archive-receipts.json', receipt)
print(json.dumps(receipt))
