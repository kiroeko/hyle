param([switch]$ReclaimColdPlanningProgress)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not $ReclaimColdPlanningProgress) { throw 'Specify -ReclaimColdPlanningProgress; no default deletion.' }
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace + [IO.Path]::DirectorySeparatorChar
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cold-planning-progress/root'
function Get-CheckedFile($row) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $row.path))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    $parent = [IO.Path]::GetDirectoryName($path)
    while ($parent -eq $workspace -or $parent.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        if ((Get-Item -LiteralPath $parent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked ancestor: $parent" }
        $parent = [IO.Path]::GetDirectoryName($parent)
    }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $row.bytes -or
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $row.sha256) { throw "File changed: $path" }
    return $item
}
$receipts = Get-Content -LiteralPath (Join-Path $stage 'archive-receipts.json') -Raw | ConvertFrom-Json
$evidence = Get-CheckedFile $receipts.architecture
$null = Get-CheckedFile $receipts.numerical
$zip = [IO.Compression.ZipFile]::OpenRead($evidence.FullName)
try {
    $reader = [IO.StreamReader]::new($zip.GetEntry('cleanup-plan.json').Open())
    try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if ($frozen -cne [IO.File]::ReadAllText((Join-Path $stage 'cleanup-plan.json'))) { throw 'Cleanup differs from archive' }
} finally { $zip.Dispose() }
$plan = $frozen | ConvertFrom-Json
$scope = '.scratch/architecture-refactor-2026-10-18/'
$allowed = @('cold-placement-facts', 'qwen-progress-journey',
    'qwen-numerical-localization/norm-intermediates/control', 'qwen-numerical-localization/norm-intermediates/telemetry') |
    ForEach-Object { [IO.Path]::GetFullPath((Join-Path $workspace ($scope + $_))) }
$targets = @()
foreach ($row in $plan.windows.files) {
    $item = Get-CheckedFile $row
    if ($item.DirectoryName -notin $allowed -or $item.BaseName -notin @('cold-tests', 'qwen35-progress', 'probe') -or
        $item.Extension -notin @('.exe', '.map', '.exp', '.lib')) { throw "Unexpected image: $item" }
    $targets += $item
}
foreach ($row in $plan.windows.retain) {
    $item = Get-CheckedFile $row
    $normSass = [IO.Path]::GetFullPath((Join-Path $workspace ($scope + 'qwen-numerical-localization/norm-intermediates/sass')))
    if ($item.Extension -ne '.obj' -or ($item.DirectoryName -notin $allowed -and $item.DirectoryName -ne $normSass)) {
        throw "Unexpected retained object: $item"
    }
}
if ($targets.Count -ne 16 -or @($targets.FullName | Select-Object -Unique).Count -ne 16) { throw 'Unexpected image set' }
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($plan.mac | ConvertTo-Json -Depth 12 -Compress)))
$remoteScript = @'
from pathlib import Path
import base64,hashlib,json,subprocess
plan=json.loads(base64.b64decode('__MANIFEST__'))
root=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation')
assert Path(plan['root'])==root and root.resolve(strict=True)==root
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
targets=[]
for row in plan['files']+plan['retain']:
 p=Path(row['path']);assert not p.is_symlink() and p.is_file()
 assert p.resolve(strict=True).is_relative_to(root)
 assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 if row in plan['files']:
  assert p.parent==root and p.name in {'ready-page','ready-page.map'};targets.append(p)
 else:assert p.parent==root/'cold-placement-check' and p.suffix=='.o'
assert len(targets)==2 and len(set(targets))==2
for p in targets:p.unlink()
result=dict(files=2,bytes=sum(row['bytes'] for row in plan['files']),retained_current_objects=len(plan['retain']))
(root/'cold-placement-check/cleanup-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
'@
$remoteScript = $remoteScript.Replace('__MANIFEST__', $encoded)
$transport = [Diagnostics.ProcessStartInfo]::new((Get-Command ssh).Source)
$transport.UseShellExecute = $false
$transport.CreateNoWindow = $true
$transport.RedirectStandardOutput = $true
$transport.RedirectStandardError = $true
$transport.RedirectStandardInput = $true
foreach ($argument in @('-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'kiro@172.22.10.198', 'python3 -')) { $transport.ArgumentList.Add($argument) }
$process = [Diagnostics.Process]::Start($transport)
try {
    $outputTask = $process.StandardOutput.ReadToEndAsync()
    $errorTask = $process.StandardError.ReadToEndAsync()
    $process.StandardInput.Write($remoteScript)
    $process.StandardInput.Close()
    $process.WaitForExit()
    $remoteOutput = $outputTask.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) { throw ('Mac cleanup failed; Windows files retained: ' + $errorTask.GetAwaiter().GetResult()) }
} finally { $process.Dispose() }
foreach ($item in $targets) { Remove-Item -LiteralPath $item.FullName -Force }
$result = @{ windows = @{ files = $targets.Count; bytes = ($targets | Measure-Object Length -Sum).Sum; retained_current_objects = 8 }
    mac = ($remoteOutput | ConvertFrom-Json); archive_verified = $true; other_cache_and_trace_retained = $true }
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stage 'cleanup-result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 8
