# Apple F32 partials: read-only design freeze

Status: **analyzed, not implemented or tested**. No product edit, compile,
Metal build, SDK reconstruction, or model run occurred in this review.
The accurate current 20-file MLX tree is the parent's
`apple-f32-partials/current`; the review independently reconstructed the two
complete replacements already present in `patches.json`, with exact final
manifest hashes. `manifest-review-identities.json` records that limited work.

## Actual gap and responsibility

- `apple_batch.cc:27–59` proves the page16 domain/layout, then predicts the
  old vector dispatch's partial dtype. Q<=8 plain F16/BF16 can use two passes
  on architecture suffix d/s with KV>=1024, or GQA with KV>=4096. Q8 first
  promotes active Q to F32; plain high-dimensional MLA uses its existing
  F32-accumulating full path. Neither needs this low-precision exception.
- `native_paged_region.cc:114–120` truthfully rejects default Graph math when
  that selected native path stores declared-type partials, or precision cannot
  be determined. `allow_bf16_partials=true` permits reduced intermediate
  storage; it does not require an implementation to narrow intermediates.
- Current MLX host `scaled_dot_product_attention.cpp:677` allocates partials
  in q.dtype. Normal first pass `sdpa_vector.h:202/206/352` and GQA first
  pass `:362/366/492` accumulate in float but store to T. Second pass
  `:504–508` reloads T partials and accumulates in float before final T output.
  This intermediate narrowing is distinct from the required final output cast.
- Compute's Direct native recipe has no partial-permission flag, and the
  current prepare path explicitly retains its original declared-type policy
  (`apple_batch.cc:80`). Higher-precision intermediate storage preserves the
  Direct mathematical contract; it can change low-precision output bits, so
  original numerical budgets must still be checked, not bitwise assumed.
- `apple_plan.h` only describes Region/RegionPlan ownership and lowering.
  Precision analysis actually belongs to `apple_batch_access.h`. No new
  Graph/core plan field, public knob, executor, or array ownership system is
  needed for this change.

## Smallest coherent future patch

1. In MLX's existing host two-pass helper allocate `intermediate` as float32.
   Keep its shape, blocks, sums/maxs, encoder lifetime, binding indices and
   dispatch order unchanged.
2. In `sdpa_vector_2pass_1` and `_1_gqa`, change only partial output pointers
   to `device float*`; retain float accumulator stores without narrowing.
   GQA's local `device T* op` must also become float. In `_2`, consume
   `const device float* partials`. Keep final `device T* out` and T cast.
3. Apply this to the original shared two-pass helpers, including ordinary
   SDPA and private paged/ragged calls. A private-only condition would need a
   second shader/partial-type identity, especially because pass2 currently
   uses `get_kernel(kname)` without a page-specific hash. It adds avoidable
   ABI/cache choices. A single F32 partial contract is smaller and also meets
   `allow_bf16_partials=true` because that flag is permission, not a demand.
4. No template-argument-count or existing .metal instantiation change is
   required: the current macros deduce the functions' revised signatures.
   These vector functions are precompiled base-metallib entries, **not** an
   existing vector JIT getter. Host and Metal must be refreshed together;
   MLX_METAL_JIT=ON does not make a stale base metallib correct.
5. Only after the above is real and verified, remove the precision-only
   `PagedBatchAnalysis` struct/fields, architecture-suffix precision predictor,
   and Graph's declared-type/unknown-architecture precision rejection.
   Preserve genuine page16/cache-domain/layout/nonempty-KV/bounded-index
   validation, shared by Compute and Graph. Its private function can become
   a plain Status validator (renamed naturally, no old alias). Remove the
   obsolete Direct declared-type-policy comment. Do not remove the public
   math permission, which still describes other implementations.

All existing call sites of this analysis are the private header declaration,
Compute definition/prepare call, and Graph qualification call. The plan has
no broader registry or provider list to update. The manifest hashes and
dependency identity/notice must describe the eventual numerical change.

## Exact resource effect

For one existing two-pass primitive the partial shape is
`[B,Hq,Q,blocks,Dv]`. F16/BF16 partial payload changes from 2 to 4 bytes:
additional requested bytes are `2*B*Hq*Q*blocks*Dv`. Existing sums/maxs are
already F32; Q/K/V and final output remain their original storage/dtype. The
native encoder retains this same temporary through its original completion.
For Hq8/Q1/Dv128/blocks64 the extra payload is 128 KiB; Q=8 at that geometry
adds 1 MiB. This is a bounded active-query/split temporary, not an entire
historical KV expansion. Native allocator rounding/cache/other private costs
remain unknown and must not be reported as zero. No throughput win is implied;
ordinary low-precision two-pass bandwidth/temp cost also increases.

## Necessary next-round checks, not executed here

Use the original Direct/Graph oracles and unchanged tolerances, plus actual
dispatch/temporary evidence. Existing short-KV consumers do not cover this.

| Focus | Small concrete path | Required observation |
|---|---|---|
| Normal vector two-pass | Plain F16/BF16, H8/KVheads2, Q1 and Q8, KV>=4096, D64 | Actual `_1` and `_2`; Direct and default Graph permission=false succeed; final dtype unchanged |
| Optimized GQA two-pass | H16/KVheads2 or H8/KVheads1, Q1, coupled D64/128, KV>=8192 | Actual `_1_gqa` and `_2`; its local output pointer must be F32 too |
| Numerical necessity | Zero Q/K and long-KV constant F16 V=2048; sensitive BF16 cancellation/weak probabilities | Final result stays representable while old unnormalized partials can overflow/round; independent oracle, no budget relaxation |
| Shared helper callers | One long-KV private ragged and one ordinary SDPA two-pass control | No host/shader ABI mismatch; original Direct numerical contract remains valid |
| Adjacent boundaries | Existing short-KV one-pass plus Q16 full-path control; retained Q8_0/highdim controls as affected | Actual branch separation, no full-KV conversion, unchanged output/resource lifetime |

The optimized GQA predicate is exactly Q1, Hq=8*Hkv, coupled D64/128,
KV>=8192, no mask/sinks, and no private Q8/window. H8/KVheads2 alone does
**not** exercise that function. Keep block rounding to multiples of 32 and
the original page/window indexing, max/sum combination and final cast.

Do not delete today's Graph permission gate before the new matching host and
metallib actually run. A stale half-partial shader with a float host allocation
can misaddress results even though allocation is larger. The parent can update
one existing attention .metal AIR and re-link the original AIR set, with the
matching host TU; this is not permission for an unrelated SDK/kernel rebuild.
