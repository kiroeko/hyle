"""Read-only product review: reconstruct manifest-owned complete replacements.

No upstream cache, SDK build, shader compilation, or product edit is performed.
Only complete file replacement texts already in patches.json are materialized
in this review directory and checked against the manifest's final file hashes.
"""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
manifest_path = ROOT/'third_party/mlx_cast/patches.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
records = []
for file in manifest['files']:
    complete = [(i, edit['after']) for i, edit in enumerate(file['edits'])
                if len(edit['after']) > 10000 and edit['after'].startswith('// Copyright')]
    if not complete:
        continue
    index, text = complete[-1]
    for edit in file['edits'][index+1:]:
        assert text.count(edit['before']) == 1, (file['path'], index)
        text = text.replace(edit['before'], edit['after'])
    digest = hashlib.sha256(text.encode()).hexdigest()
    assert digest == file['after_sha256'], (file['path'], digest, file['after_sha256'])
    target = OUT/'manifest-final'/file['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(text.encode())
    records.append(dict(path=file['path'], bytes=len(text.encode()), sha256=digest,
                        complete_replacement_edit=index, following_edits=len(file['edits'])-index-1,
                        final_manifest_hash_matches=True))
(OUT/'manifest-review-identities.json').write_text(json.dumps(dict(
    manifest_sha256=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    derived_from_existing_manifest_only=True, source_cache_modified=False,
    products_modified=False, compiled=False, executed=False, files=records), indent=2)+'\n', encoding='utf-8')
print(json.dumps(records, indent=2))
