from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
DOC = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'
cases = [
    ('hybrid-derived-control', 'hybrid-derived-control.zip'),
    ('cuda-ragged-mla', 'cuda-ragged-mla.zip'),
    ('vulkan-official-word-bank', 'vulkan-official-word-bank.zip'),
]


def digest(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()


records = []
archives = []
for stage, archive in cases:
    directory = (BASE / stage).resolve(strict=True)
    assert directory.parent == BASE.resolve(strict=True)
    frozen = DOC / archive
    assert frozen.is_file()
    archives.append({'name': archive, 'sha256': digest(frozen)})
    for image in directory.glob('*.exe'):
        for p in (image, image.with_suffix('.exp'), image.with_suffix('.lib')):
            if p.is_file():
                assert not p.is_symlink() and p.parent == directory
                records.append({'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)})
plan = {'roots': [str(BASE / stage) for stage, archive in cases], 'archives': archives,
        'files': records, 'retain': 'All .obj, .o, maps, source, logs, data and every native SDK/tool cache'}
(OUT / 'current-binaries.json').write_text(json.dumps(plan, indent=2) + '\n')
backup = OUT / 'test-before-current-binaries.ps1'
if not backup.exists():
    shutil.copyfile(ROOT / 'test.ps1', backup)
print(json.dumps({'files': len(records), 'bytes': sum(p['bytes'] for p in records)}))
