from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DOC = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def digest(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()


cpu = OUT.parent / 'packed-indexer-cpu'
archive = cpu / 'source-results.zip'
assert archive.stat().st_size == 156908
assert digest(archive) == '89415d8892975d1be86874cd4fdd0aae5b7cf5c06e9b5a3b26026dd375ac0360'
for entry in json.loads((cpu / 'summary.json').read_text())['source_identity']:
    assert digest(Path(entry['path'])) == entry['sha256'], entry['path']
shutil.copyfile(archive, DOC / 'packed-indexer-cpu.zip')
plan = json.loads((OUT / 'current-binaries.json').read_text())
assert all(not Path(x['path']).exists() for x in plan['files'])
shutil.copyfile(ROOT / 'test.ps1', OUT / 'test-current-binaries.ps1')
result = {
    'removed': len(plan['files']), 'bytes': sum(x['bytes'] for x in plan['files']),
    'method': 'Exact nonrecursive paths, archive identities and per-file size/SHA256 checked in root test.ps1 before Remove-Item.',
    'retained': 'Every .obj/.o, map, source/log/data, original native SDK and tool cache',
}
(OUT / 'current-result.json').write_text(json.dumps(result, indent=2) + '\n')
target = DOC / 'probe-cleanup-current.zip'
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in ['prepare-current.py', 'finalize-current.py', 'current-binaries.json',
                 'current-result.json', 'current-result.log', 'test-current-binaries.ps1']:
        z.write(OUT / name, name)
print(json.dumps({'cleanup_archive': str(target), 'bytes': target.stat().st_size,
                  'sha256': digest(target), 'removed': result, 'cpu_archive_integrated': True}))
