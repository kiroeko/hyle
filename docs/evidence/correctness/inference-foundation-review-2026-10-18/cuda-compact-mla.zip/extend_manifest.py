from pathlib import Path
import hashlib, json
ROOT = Path(__file__).resolve().parents[3]
RAW = ROOT / '.scratch/g04-bf16-partials-vendor/upstream'
p = ROOT / 'third_party/flashinfer_cache/patches.json'
m = json.loads(p.read_text())
def patch(path, edits):
    e = next((e for e in m['files'] if e['path'] == path), None)
    raw = (RAW/path).read_bytes().replace(b'\r\n', b'\n')
    if e is None:
        e = dict(path=path,before_sha256=hashlib.sha256(raw).hexdigest(),edits=[])
        m['files'].append(e)
    data = raw.decode()
    for x in e['edits']:
        assert data.count(x['before']) == 1
        data = data.replace(x['before'],x['after'],1)
    for before,after in edits:
        assert data.count(before) == 1, before[:120]
        data = data.replace(before,after,1)
        e['edits'].append(dict(before=before,after=after))
    e['after_sha256'] = hashlib.sha256(data.encode()).hexdigest()
patch('include/flashinfer/attention/mla.cuh', [
    ('smem_storage.q_nope.template '+x, 'smem_storage.q_nope.template '+x) for x in []])
# MSVC requires an empty template argument list for these dependent calls.
path='include/flashinfer/attention/mla.cuh'
raw=(RAW/path).read_text()
edits=[]
for name in ['store_128b','load_128b','store_64b']:
    pass
for line in raw.splitlines():
    if '.template ' in line and '(' in line and '<' not in line.split('.template ',1)[1].split('(',1)[0]:
        before=line
        after=line.replace('(', '<>(',1)
        edits.append((before,after))
patch(path,edits)
float_block='''  constexpr size_t sizeof_dtype_o = 2;
  AlignedAllocator float_allocator(float_buffer, float_workspace_size_in_bytes);
  plan_info.partial_o_offset = float_allocator.aligned_alloc_offset(
      2 * num_clusters * cluster_tile_q * sizeof_dtype_o * head_dim_o, 16, "mla_partial_o");
  plan_info.partial_lse_offset = float_allocator.aligned_alloc_offset(
      2 * num_clusters * cluster_tile_q * sizeof(float), 16, "mla_partial_lse");
'''
patch('include/flashinfer/attention/scheduler.cuh', [
('bool causal, cudaStream_t stream) {\n  int num_sm = 0;',
 'bool causal, cudaStream_t stream, bool hyle_query = false,\n                           size_t* hyle_float_bytes = nullptr, size_t* hyle_int_bytes = nullptr) {\n  int num_sm = 0;'),
('  int total_num_works = work_indptr_vec.back();\n  auto q_indptr_vec',
 '  int total_num_works = work_indptr_vec.back();\n  FLASHINFER_CHECK(total_num_works <= max_total_num_works && num_clusters + 1 <= uint32_t(max_total_num_works),\n                   "MLA plan exceeds its original fixed work capacity");\n  auto q_indptr_vec'),
('  AlignedAllocator int_allocator(int_buffer, int_workspace_size_in_bytes);\n  plan_info.q_indptr_offset',
 '  AlignedAllocator int_allocator = hyle_query ? AlignedAllocator() :\n      AlignedAllocator(int_buffer, int_workspace_size_in_bytes);\n  plan_info.q_indptr_offset'),
(float_block, ''),
('  IdType* cluster_q_indptr_h =\n',
 float_block.replace('AlignedAllocator float_allocator(float_buffer, float_workspace_size_in_bytes);',
 'AlignedAllocator float_allocator = hyle_query ? AlignedAllocator() :\n      AlignedAllocator(float_buffer, float_workspace_size_in_bytes);')+
 '\n  if (hyle_float_bytes) *hyle_float_bytes = float_allocator.num_allocated_bytes();\n  if (hyle_int_bytes) *hyle_int_bytes = int_allocator.num_allocated_bytes();\n  if (hyle_query) return cudaSuccess;\n\n  IdType* cluster_q_indptr_h =\n')])
m['scope'] += '; MLA uses the original scheduler in count-only workspace queries and bounds its fixed work arrays before upload; dependent template calls use portable explicit empty argument lists'
p.write_text(json.dumps(m,indent=2)+'\n',newline='\n')
