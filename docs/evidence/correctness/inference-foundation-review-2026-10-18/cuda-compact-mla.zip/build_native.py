from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
RAW=ROOT/'.scratch/g04-bf16-partials-vendor/upstream'
OVERLAY=OUT/'verified-headers'
m=json.loads((ROOT/'third_party/flashinfer_cache/patches.json').read_text())
for e in m['files']:
 data=(RAW/e['path']).read_bytes().replace(b'\r\n',b'\n')
 assert hashlib.sha256(data).hexdigest()==e['before_sha256']
 for edit in e['edits']:
  a,b=edit['before'].encode(),edit['after'].encode()
  assert data.count(a)==1
  data=data.replace(a,b,1)
 assert hashlib.sha256(data).hexdigest()==e['after_sha256']
 p=OVERLAY/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
c=read_cache(ROOT/'.scratch/build-compute-v2-dev');env=windows_compiler_environment(c)
tk=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
env['PATH']=str(tk/'bin/x64')+os.pathsep+env['PATH'];env['VSLANG']='1033'
cmd=[str(tk/'bin/nvcc.exe'),'--std=c++17','--gpu-architecture=sm_89','--compiler-bindir',str(Path(c['CMAKE_CXX_COMPILER']).parent),'-Xcompiler=/MD,/EHsc,/Zc:preprocessor,/utf-8','-O2','-DNDEBUG','-DNOMINMAX','-DFLASHINFER_ENABLE_BF16','-DFLASHINFER_ENABLE_F16']
for d in [OVERLAY/'include',OVERLAY/'include/flashinfer',OVERLAY/'include/flashinfer/attention',RAW/'include',RAW/'include/flashinfer',RAW/'include/flashinfer/attention']:cmd+=['-I'+str(d)]
for f in ['vec_dtypes.cuh','math.cuh','pos_enc.cuh','attention/scheduler.cuh']:
 cmd+=['--pre-include',str(OVERLAY/'include/flashinfer'/f)]
cmd+=['-c',str(ROOT/'src/compute_provider_flashinfer/native_mla.cu'),'-o',str(OUT/'native_mla.obj')]
t=time.monotonic();p=subprocess.run(cmd,cwd=OUT,env=env,capture_output=True)
(OUT/'native.stdout.log').write_bytes(p.stdout);(OUT/'native.stderr.log').write_bytes(p.stderr)
(OUT/'native-command.json').write_text(json.dumps(dict(command=cmd,cwd=str(OUT),exit=p.returncode,seconds=time.monotonic()-t),indent=2)+'\n')
print('MLA native compile',p.returncode,flush=True)
if p.returncode:
 for line in (p.stdout+p.stderr).decode(errors='replace').splitlines():
  if 'error' in line.lower() and 'warning' not in line.lower():print(line[:600])
sys.exit(p.returncode)
