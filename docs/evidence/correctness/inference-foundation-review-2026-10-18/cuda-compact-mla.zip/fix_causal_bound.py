from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'third_party/flashinfer_cache/patches.json';m=json.loads(p.read_text())
e=next(e for e in m['files'] if e['path']=='include/flashinfer/attention/mla.cuh')
data=(ROOT/'.scratch/g04-bf16-partials-vendor/upstream'/e['path']).read_text()
for x in e['edits']:
 assert data.count(x['before'])==1
 data=data.replace(x['before'],x['after'],1)
a='kv_len - q_len + (packed_qo_start + cluster_tile_q) / num_heads'
b='kv_len - q_len + ceil_div(packed_qo_start + cluster_tile_q, num_heads)'
assert data.count(a)==1
data=data.replace(a,b,1)
e['edits'].append(dict(before=a,after=b));e['after_sha256']=hashlib.sha256(data.encode()).hexdigest()
m['scope']+='; MLA causal cluster upper bounds use the same ceil query-row bound as its original scheduler, preserving per-element masks for non-divisor head counts'
p.write_text(json.dumps(m,indent=2)+'\n',newline='\n')
