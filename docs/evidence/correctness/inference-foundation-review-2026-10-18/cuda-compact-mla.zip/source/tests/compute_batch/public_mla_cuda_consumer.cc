#include <hyle/compute/cuda.h>
#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/providers/flashinfer.h>
#include <hyle/graph/batch.h>
#include <hyle/simd/dtype.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <vector>

namespace {
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace gb=g::batch;
using hyle::Status;
Status check(bool value,const char*message){return value?Status::Ok():Status::Internal(message);}
std::uint16_t encode(float x,bool bf){return bf?hyle::simd::f32_to_bf16(x).bits:hyle::simd::f32_to_f16(x).bits;}
float decode(std::uint16_t x,bool bf){return bf?hyle::simd::bf16_to_f32({x}):hyle::simd::f16_to_f32({x});}
Status oracle(c::BatchCapacity cap,c::BatchLayoutVersion layout,
    const std::vector<std::uint16_t>&q,const std::vector<std::uint16_t>&cache,
    const c::ReadLease&out,bool bf){
  const auto host=layout.host();
  std::vector<std::uint16_t> actual(std::size_t(cap.max_query_rows)*cap.query_heads*512);
  HYLE_RETURN_IF_ERROR(out.view()->read(std::as_writable_bytes(std::span(actual))));
  double maximum=0;
  for(unsigned r=0;r<layout.facts().requests;++r){
    const auto rows=host.query_indptr[r+1]-host.query_indptr[r];
    const auto pages=host.kv_indptr[r+1]-host.kv_indptr[r];
    const auto keys=(pages-1)*int(cap.page_size)+host.last_page_lengths[r];
    const auto base=[&](int k){return std::size_t(host.page_indices[host.kv_indptr[r]+k/cap.page_size]*cap.page_size+k%cap.page_size)*576;};
    for(int row=0;row<rows;++row)for(unsigned head=0;head<cap.query_heads;++head){
      const auto qb=(std::size_t(host.query_indptr[r]+row)*cap.query_heads+head)*576;
      const auto count=keys-rows+row+1;
      std::vector<double> p(count);double high=-1e100,sum=0;
      for(int k=0;k<count;++k){double dot=0;for(unsigned d=0;d<576;++d)dot+=double(decode(q[qb+d],bf))*decode(cache[base(k)+d],bf);p[k]=dot/16;high=std::max(high,p[k]);}
      for(auto&x:p){x=std::exp(x-high);sum+=x;}
      const auto ob=(std::size_t(host.query_indptr[r]+row)*cap.query_heads+head)*512;
      for(unsigned d=0;d<512;++d){double expected=0;for(int k=0;k<count;++k)expected+=p[k]/sum*decode(cache[base(k)+d],bf);
        const auto error=std::abs(decode(actual[ob+d],bf)-expected);maximum=std::max(maximum,error);
        if(!std::isfinite(error) || error>=.007)std::fprintf(stderr,"MLA mismatch req=%u row=%d head=%u d=%u actual=%.9g expected=%.12g error=%.9g\n",r,row,head,d,decode(actual[ob+d],bf),expected,error);
        HYLE_RETURN_IF_ERROR(check(std::isfinite(error) && error<.007,"MLA independent FP64 oracle differs"));
      }
    }
  }
  std::printf("MLA H%u %s full FP64 maxAbs=%.9g PASS\n",cap.query_heads,bf?"BF16":"F16",maximum);return Status::Ok();
}
Status exercise(bool bf,unsigned heads){
  const c::MlaBatchCapacity mc{.data_type=bf?c::DataType::kBFloat16:c::DataType::kFloat16,
      .max_requests=2,.max_query_rows=4,.max_kv_rows=64,.max_pages=4,.max_page_refs=5,
      .query_heads=heads,.page_size=16};
  HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create_mla(mc));
  const auto cap=schema.capacity();
  const std::array<std::int32_t,3> qptr{0,1,4},kptr{0,2,5};
  const std::array<std::int32_t,5> pages{3,1,0,2,1};
  const std::array<std::int32_t,2> tails{15,1};
  HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({qptr,kptr,pages,tails}));
  HYLE_ASSIGN_OR_RETURN(auto default_context,c::cuda::create_context());
  HYLE_ASSIGN_OR_RETURN(auto default_device,c::cuda::MemoryResource::create(default_context,c::cuda::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto default_host,c::cuda::MemoryResource::create(default_context,c::cuda::MemoryKind::kPinnedHost));
  HYLE_ASSIGN_OR_RETURN(auto default_program,c::BatchProgram::prepare(default_context,schema,{
      .resource=default_device.ref(),.host_workspace=default_host.ref(),.scale=1.F/16}));
  auto too_large=mc;too_large.max_query_rows=std::uint32_t(UINT32_MAX/576/heads+1);
  HYLE_ASSIGN_OR_RETURN(auto large_schema,c::BatchSchema::create_mla(too_large));
  auto bad=c::BatchProgram::prepare(default_context,large_schema,{
      .resource=default_device.ref(),.host_workspace=default_host.ref(),.scale=1.F/16});
  HYLE_RETURN_IF_ERROR(check(!bad && bad.error().IsOutOfRange(),"MLA native query offset overflow was admitted"));
  std::puts("Default CUDA context discovers distinct MLA BatchPlanning PASS");
  c::BatchProgramOptions options{.max_float_workspace_bytes=16u<<20,.max_int_workspace_bytes=1u<<20,.scale=1.F/16};
  HYLE_ASSIGN_OR_RETURN(auto wrapped,gb::provider(c::flashinfer::provider(),schema,options));
  HYLE_ASSIGN_OR_RETURN(auto id,c::cuda::device(0));
  HYLE_ASSIGN_OR_RETURN(auto context,c::Context::create(id,wrapped));
  HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto device,c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto host,c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
  struct Drain{c::Context&context;~Drain(){context.drain().IgnoreError();}}drain{context};
  options.resource=device.ref();options.host_workspace=host.ref();
  HYLE_ASSIGN_OR_RETURN(auto program,c::BatchProgram::prepare(context,schema,options));
  {
    auto tiny=options;tiny.max_float_workspace_bytes=16;tiny.max_int_workspace_bytes=16;
    HYLE_ASSIGN_OR_RETURN(auto limited,c::BatchProgram::prepare(context,schema,tiny));
    HYLE_ASSIGN_OR_RETURN(auto limited_invocation,c::BatchInvocation::create(limited,queue));
    auto exhausted=limited_invocation.prepare_batch(layout);
    HYLE_RETURN_IF_ERROR(check(!exhausted && exhausted.error().IsResourceExhausted(),"MLA workspace preflight did not reject capacity exhaustion"));
  }
  HYLE_ASSIGN_OR_RETURN(auto direct,c::BatchInvocation::create(program,queue));
  std::vector<std::uint16_t> q(std::size_t(cap.max_query_rows)*heads*576),cache(4*16*576);
  for(std::size_t i=0;i<q.size();++i)q[i]=encode(float(int(i%29)-14)/64,bf);
  for(std::size_t i=0;i<cache.size();++i)cache[i]=encode(float(int((i*13+i/576)%37)-18)/32,bf);
  HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(device.ref(),q.size()*2+4*heads*512*2+4096));
  HYLE_ASSIGN_OR_RETURN(auto writer,pool.allocate(q.size()*2));
  HYLE_RETURN_IF_ERROR(writer.view()->write(std::as_bytes(std::span(q))));
  HYLE_ASSIGN_OR_RETURN(auto query,writer.publish());
  HYLE_ASSIGN_OR_RETURN(auto arena,c::PagedArena::create(schema,c::BatchCacheRole::kMla,device.ref(),{.max_backing_bytes=cache.size()*2+1}));
  HYLE_RETURN_IF_ERROR(check(!c::PagedArena::create(schema,c::BatchCacheRole::kValue,device.ref(),{.max_backing_bytes=cache.size()*2+1}),"MLA accepted an independent V arena"));
  std::array<c::ReadLease,4> ready;
  for(unsigned page=0;page<4;++page){
    HYLE_ASSIGN_OR_RETURN(auto page_writer,arena.acquire(page));
    HYLE_RETURN_IF_ERROR(page_writer.lease().view()->write(std::as_bytes(std::span(cache).subspan(page*16*576,16*576))));
    HYLE_ASSIGN_OR_RETURN(ready[page],page_writer.publish(16));
  }
  HYLE_ASSIGN_OR_RETURN(auto frame,arena.read(layout,ready));
  HYLE_ASSIGN_OR_RETURN(auto token,direct.prepare_batch(layout));
  HYLE_RETURN_IF_ERROR(check(!token.run(std::array{query,query,query}),"MLA accepted legacy three-payload run"));
  HYLE_RETURN_IF_ERROR(token.prepare_replay(query,frame));
  HYLE_ASSIGN_OR_RETURN(auto done,token.run(query,frame));HYLE_RETURN_IF_ERROR(done.wait());
  HYLE_ASSIGN_OR_RETURN(auto output,direct.output());HYLE_RETURN_IF_ERROR(oracle(cap,layout,q,cache,output,bf));
  std::printf("MLA Direct single arena %zu bytes, native float=%zu int=%zu capture=%d PASS\n",cache.size()*2,direct.report().float_workspace_bytes,direct.report().int_workspace_bytes,int(direct.report().capture_compatible));
  HYLE_RETURN_IF_ERROR(check(!direct.prepare_batch(layout),"MLA retained output allowed overwrite"));
  output.reset();done={};token={};
  auto changed_pages=pages;std::swap(changed_pages[2],changed_pages[3]);
  HYLE_ASSIGN_OR_RETURN(auto updated,schema.version({qptr,kptr,changed_pages,tails}));
  HYLE_ASSIGN_OR_RETURN(auto updated_frame,arena.read(updated,ready));
  HYLE_ASSIGN_OR_RETURN(auto updated_token,direct.update_batch(updated));
  HYLE_RETURN_IF_ERROR(check(direct.report().reused_native_plan,"MLA page-ID-only update rebuilt its schedule"));
  HYLE_RETURN_IF_ERROR(updated_token.prepare_replay(query,updated_frame));
  HYLE_ASSIGN_OR_RETURN(auto updated_done,updated_token.run(query,updated_frame));HYLE_RETURN_IF_ERROR(updated_done.wait());
  HYLE_ASSIGN_OR_RETURN(auto updated_output,direct.output());HYLE_RETURN_IF_ERROR(oracle(cap,updated,q,cache,updated_output,bf));
  HYLE_ASSIGN_OR_RETURN(auto qdesc,c::batch_query_description(cap));
  HYLE_ASSIGN_OR_RETURN(auto cdesc,c::batch_cache_description(schema,c::BatchCacheRole::kMla));
  HYLE_ASSIGN_OR_RETURN(auto mdesc,schema.metadata_description());
  HYLE_ASSIGN_OR_RETURN(auto odesc,c::batch_output_description(cap,cap.max_query_rows));
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  std::array<g::ValueId,3> inputs;
  const std::array descriptions{qdesc,cdesc,mdesc};
  for(unsigned i=0;i<3;++i){HYLE_ASSIGN_OR_RETURN(inputs[i],builder.input(descriptions[i]));}
  HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(c::Operation::custom(c::PagedMlaAttention{mc,options.scale}),inputs));
  HYLE_ASSIGN_OR_RETURN(auto result,builder.result(node));HYLE_RETURN_IF_ERROR(builder.publish(result));
  HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
  const std::array storage{g::StorageDomain{device.ref()}};
  const std::array targets{g::ExecutionTarget{&context,g::StorageDomainId{0}}};
  HYLE_ASSIGN_OR_RETURN(auto compiled,g::compile(graph,{storage,targets,{}},{.operation_fallback=g::OperationFallbackPolicy::kReject}));
  HYLE_ASSIGN_OR_RETURN(auto invocation,gb::Invocation::create(compiled.executable,std::array{gb::LaneBinding{g::ExecutionLaneId{0},&context,&queue,host.ref()}}));
  HYLE_RETURN_IF_ERROR(invocation.prepare_batch(std::array{gb::NodeLayout{node,layout}}));
  HYLE_RETURN_IF_ERROR(invocation.bind(inputs[0],qdesc,query));HYLE_RETURN_IF_ERROR(invocation.bind(inputs[1],frame));
  HYLE_ASSIGN_OR_RETURN(auto graph_writer,pool.allocate(4*heads*512*2));
  HYLE_RETURN_IF_ERROR(invocation.bind(result,odesc,std::move(graph_writer)));
  HYLE_RETURN_IF_ERROR(invocation.prepare_replay());
  HYLE_ASSIGN_OR_RETURN(auto graph_done,invocation.submit());HYLE_RETURN_IF_ERROR(graph_done.wait());
  HYLE_ASSIGN_OR_RETURN(auto graph_output,invocation.output(result));
  HYLE_ASSIGN_OR_RETURN(auto graph_read,graph_output.storage_lease());HYLE_RETURN_IF_ERROR(oracle(cap,layout,q,cache,graph_read,bf));
  std::puts("MLA Graph 3 ports, same single arena, captured original Queue PASS");return Status::Ok();
}
Status run(){HYLE_RETURN_IF_ERROR(exercise(false,96));return exercise(true,64);}
}
int main(){std::setvbuf(stdout,nullptr,_IONBF,0);const auto status=run();if(status.ok())return 0;char message[768]{};status.ToString(message,sizeof(message));std::fprintf(stderr,"public CUDA MLA: %s\n",message);return 1;}
