from pathlib import Path
import json,sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import build_host as b
import link_run as old
OLD=b.OUT
b.OUT=OUT
b.records=json.loads((OUT/'host-commands.json').read_text()) if (OUT/'host-commands.json').exists() else []
legacy=len(sys.argv)>1 and sys.argv[1]=='legacy'
stem='legacy-consumer' if legacy else 'consumer'
b.comp('tests/compute_batch/public_batch_cuda_consumer.cc' if legacy else 'tests/compute_batch/public_mla_cuda_consumer.cc',stem)
replace={OLD/'public-consumer.obj':OUT/(stem+'.obj'),OLD/'flashinfer-provider.obj':OUT/'flashinfer-provider.obj',OLD/'batch-execution.obj':OUT/'batch-execution.obj',OLD/'graph-batch.obj':OUT/'graph-batch.obj'}
objects=[replace.get(p,p) for p in old.objects]
objects += [OUT/'batch-layout.obj',OUT/'paged-arena.obj',OUT/'native_mla.obj',OLD/'highdim-review/native_highdim.obj']
tag='legacy' if legacy else 'mla'
exe=OUT/('public-'+tag+'.exe')
b.run(tag+'-link',[b.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(OUT/('public-'+tag+'.map')),*objects,*old.libs,*old.system])
(OUT/(tag+'-link-identities.json')).write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=b.sha(p)) for p in [*objects,*old.libs,exe]],indent=2)+'\n')
b.run(tag+'-public-run',[exe])
