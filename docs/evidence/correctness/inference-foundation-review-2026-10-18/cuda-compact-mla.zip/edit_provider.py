from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'src/compute_provider_flashinfer/flashinfer_provider.cc'
s=p.read_text()
def sub(a,b,n=1):
 global s
 assert s.count(a)==n,(a[:90],s.count(a),n)
 s=s.replace(a,b)
sub('  BatchLayoutVersion layout;\n  BatchPlanReport report;', '  BatchLayoutVersion layout;\n  BatchPlanReport report;\n  bool mla=false;')
pos=s.index('Status create_batch_slot(')
s=s[:pos]+'''Status qualify_mla(void*opaque,BatchCapacity c,const BatchProgramOptions&o)noexcept {
  HYLE_RETURN_IF_ERROR(validate_batch_capacity(c));
  const auto&context=*static_cast<ProviderContext*>(opaque);
  if(!context.maximum_grid || c.storage!=BatchStorage::kPaged || c.kv_heads!=1 ||
      c.qk_head_dim!=576 || c.value_head_dim!=512 || c.query_type!=c.output_type ||
      !c.key_storage.format().is_plain() || !c.value_storage.format().is_plain() ||
      c.key_storage.data_type()!=c.query_type || c.value_storage.data_type()!=c.query_type ||
      o.window_left!=-1 || o.allow_bf16_partials)
    return Status::Unimplemented("FlashInfer MLA requires plain packed CKV512/KPE64 with full causal/noncausal attention");
  if(!std::isfinite(o.scale) || o.scale<=0 || o.scale>std::numeric_limits<float>::max()/1.4426950408889634F)
    return Status::Unimplemented("FlashInfer MLA requires positive finite log2 QK scale");
  const auto packed=std::uint64_t(c.max_query_rows)*c.query_heads;
  if(packed>(std::uint64_t(INT32_MAX)-128) || packed*576>UINT32_MAX ||
      std::uint64_t(c.max_pages)*c.page_size*576>UINT32_MAX ||
      std::uint64_t(c.max_page_refs)*c.page_size>UINT32_MAX || c.max_kv_rows>std::uint32_t(INT32_MAX/2))
    return Status::OutOfRange("FlashInfer MLA packed tensor or scheduler offsets exceed native integer fields");
  return Status::Ok();
}
''' +s[pos:]
pos=s.index('void destroy_batch_slot(')
a=s.index('Status create_batch_slot(')
block=s[a:pos]
block=block.replace('create_batch_slot(','create_mla_slot(',1).replace('qualify_batch(opaque,capacity,options)','qualify_mla(opaque,capacity,options)',1)
block=block.replace('native::batch_state_bytes()','native::mla_state_bytes()').replace('native::initialize_batch_state(p->plan);','native::initialize_mla_state(p->plan);p->mla=true;')
s=s[:pos]+block+s[pos:]
sub('native::destroy_batch_state(p->plan);allocator.deallocate',
    'if(p->mla)native::destroy_mla_state(p->plan);else native::destroy_batch_state(p->plan);allocator.deallocate')
sub('auto status=cuda::status(native::query_batch_workspace(spec,metadata.query_indptr.data(),metadata.kv_indptr.data(),*stream,facts));',
'''std::vector<std::int32_t> lengths;
    if(slot.mla){lengths.reserve(spec.requests);for(std::size_t r=0;r<spec.requests;++r){
      const auto pages=metadata.kv_indptr[r+1]-metadata.kv_indptr[r];
      lengths.push_back(pages?(pages-1)*std::int32_t(spec.page_size)+metadata.last_page_lengths[r]:0);
    }}
    auto status=cuda::status(slot.mla?
        native::query_mla_workspace(spec,metadata.query_indptr.data(),metadata.kv_indptr.data(),lengths.data(),*stream,facts):
        native::query_batch_workspace(spec,metadata.query_indptr.data(),metadata.kv_indptr.data(),*stream,facts));''')
sub('status=cuda::status(native::plan_batch(slot.plan,spec,metadata.query_indptr.data(),metadata.kv_indptr.data(),*floating,workspace.float_workspace.size(),*integer,host_pointer,workspace.int_workspace.size(),*stream,facts));',
'''status=cuda::status(slot.mla?
          native::plan_mla(slot.plan,spec,metadata.query_indptr.data(),metadata.kv_indptr.data(),lengths.data(),*floating,workspace.float_workspace.size(),*integer,host_pointer,workspace.int_workspace.size(),*stream,facts):
          native::plan_batch(slot.plan,spec,metadata.query_indptr.data(),metadata.kv_indptr.data(),*floating,workspace.float_workspace.size(),*integer,host_pointer,workspace.int_workspace.size(),*stream,facts));''')
sub('inputs.size()!=3)return detail::EnqueueResult::rejected', 'inputs.size()!=(slot.mla?2u:3u))return detail::EnqueueResult::rejected')
sub('for(std::size_t i=0;i<3;++i){auto p=cuda::detail::const_pointer', 'for(std::size_t i=0;i<inputs.size();++i){auto p=cuda::detail::const_pointer')
sub('try{const auto run=slot.spec.qk_head_dim==512?',
'''try{if(slot.mla)return detail::EnqueueResult::accepted_command(cuda::status(
      native::run_mla(slot.plan,slot.spec,pointers[0],pointers[1],*metadata,*output,*floating,*integer,*stream)));
    const auto run=slot.spec.qk_head_dim==512?''')
sub('if(!equal(old.query_indptr,next.query_indptr))return false;',
'''if(!equal(old.query_indptr,next.query_indptr))return false;
  // MLA schedules bake KV lengths and offsets; only physical page IDs may
  // change without rebuilding that original plan.
  if(slot.mla && (!equal(old.kv_indptr,next.kv_indptr) || !equal(old.last_page_lengths,next.last_page_lengths)))return false;''')
sub('const void*query_extension(void*,ProviderExtensionId id)noexcept{return id==detail::kBatchPlanningExtensionId?&kBatchVTable:nullptr;}',
'''const detail::BatchProviderVTable kMlaVTable{&qualify_mla,&create_mla_slot,&destroy_batch_slot,&update_batch_slot,&plan_batch_slot,&run_batch_slot,true};
const void*query_extension(void*,ProviderExtensionId id)noexcept{
  if(id==detail::kBatchPlanningExtensionId)return &kBatchVTable;
  if(id==detail::kMlaBatchPlanningExtensionId)return &kMlaVTable;return nullptr;
}''')
if '#include <vector>' not in s:s=s.replace('#include <new>','#include <new>\n#include <vector>')
p.write_text(s,newline='\n')
p=ROOT/'src/compute_provider_flashinfer/CMakeLists.txt'
s=p.read_text();assert s.count('native_cache.cu native_cache_encoder.cu native_highdim.cu)')==1
p.write_text(s.replace('native_cache.cu native_cache_encoder.cu native_highdim.cu)','native_cache.cu native_cache_encoder.cu native_highdim.cu native_mla.cu)'),newline='\n')
