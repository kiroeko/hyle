from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'src/graph_batch/batch.cc'
s=p.read_text()
def sub(a,b,n=1):
 global s
 assert s.count(a)==n,(a[:90],s.count(a),n)
 s=s.replace(a,b)
sub('struct Context final {',
'''std::size_t ports(const Config&c)noexcept{return c.schema.mla_layout()==c::MlaCacheLayout::kNone?4:3;}
bool has_value_port(const Config&c)noexcept{return c.schema.mla_layout()==c::MlaCacheLayout::kNone;}
c::ProviderExtensionId batch_extension(const Config&c)noexcept{
  return has_value_port(c)?cd::kBatchPlanningExtensionId:cd::kMlaBatchPlanningExtensionId;
}
struct Context final {''')
sub('  if(const auto value=op.custom_as<c::PagedAttention>()){',
'''  if(const auto value=op.custom_as<c::PagedMlaAttention>()){
    HYLE_ASSIGN_OR_RETURN(auto capacity,c::mla_batch_capacity(value->capacity));
    if(config.schema.mla_layout()!=value->capacity.layout || capacity!=config.schema.capacity() ||
        value->scale!=config.options.scale || value->causal!=config.options.causal || config.options.window_left!=-1 || config.options.allow_bf16_partials)
      return Status::Unimplemented("MLA graph node differs from its packed-cache domain");
    return Status::Ok();
  }
  if(!has_value_port(config))return Status::Unimplemented("MLA requires its distinct typed graph operation");
  if(const auto value=op.custom_as<c::PagedAttention>()){''')
sub('inputs.size()!=4 || outputs.size()!=1','inputs.size()!=ports(*context.config) || outputs.size()!=1')
sub('inputs[3].minimum_alignment=8','inputs[ports(*context.config)-1].minimum_alignment=8')
sub('inputs.size()!=4)return cd::EnqueueResult::rejected','inputs.size()!=ports(*r.config))return cd::EnqueueResult::rejected')
sub('for(std::size_t i=0;i<4;++i)ordered[i]=inputs[r.inputs[i]];',
    'for(std::size_t i=0;i<ports(*r.config);++i)ordered[i]=inputs[r.inputs[i]];')
sub('for(std::size_t port=1;port<3;++port)', 'for(std::size_t port=1;port+1<ports(*r.config);++port)')
sub('cd::BatchGraphAccess::enqueue(s.token,queue,ordered,outputs)',
    'cd::BatchGraphAccess::enqueue(s.token,queue,std::span(ordered).first(ports(*r.config)),outputs)')
sub('r.inputs.size()!=4 || r.outputs.size()!=1', 'r.inputs.size()!=ports(*context.config) || r.outputs.size()!=1')
sub('for(std::size_t i=0;i<4;++i){auto value=r.graph->node_input',
    'for(std::size_t i=0;i<ports(*context.config);++i){auto value=r.graph->node_input')
sub('if(i==3){if(value->kind()', 'if(i+1==ports(*context.config)){if(value->kind()')
sub('query_extension(p->base,cd::kBatchPlanningExtensionId)', 'query_extension(p->base,batch_extension(*config))')
sub('if(id==cd::kBatchPlanningExtensionId)return &ctx.forwarding;',
    'if(id==batch_extension(*ctx.config))return &ctx.forwarding;')
sub('if(view.inputs.size()!=4 || view.outputs.size()!=1)', 'if(view.inputs.size()!=ports(*r.config) || view.outputs.size()!=1)')
sub('for(std::size_t i=0;i<4;++i)ordered[i]=view.inputs[r.inputs[i]];',
    'for(std::size_t i=0;i<ports(*r.config);++i)ordered[i]=view.inputs[r.inputs[i]];')
sub('s.token,*queued->queue,ordered,view.outputs)',
    's.token,*queued->queue,std::span(ordered).first(ports(*r.config)),view.outputs)',2)
# All cache-role checks distinguish the MLA metadata port from the old V port.
sub('r.values[0]==value || r.values[3]==value','r.values[0]==value || r.metadata==value',2)
sub('r.values[1]!=value && r.values[2]!=value','r.values[1]!=value && (!has_value_port(*r.config) || r.values[2]!=value)',2)
sub('if(r.values[2]==value)HYLE_RETURN_IF_ERROR', 'if(has_value_port(*r.config) && r.values[2]==value)HYLE_RETURN_IF_ERROR',2)
sub('(r.values[2]==value && b.slot->values.valid())','(has_value_port(*r.config) && r.values[2]==value && b.slot->values.valid())',2)
sub('(b.region->values[2]==value && b.slot->values.valid())','(has_value_port(*b.region->config) && b.region->values[2]==value && b.slot->values.valid())',2)
sub('if(b.region->values[2]==value)b.slot->values=frame;',
    'if(has_value_port(*b.region->config) && b.region->values[2]==value)b.slot->values=frame;')
p.write_text(s,newline='\n')
