from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'src/compute_batch/batch_execution.cc'
s=p.read_text()
def sub(a,b,n=1):
 global s
 assert s.count(a)==n,(a[:90],s.count(a),n)
 s=s.replace(a,b)
sub('Result<std::array<TensorDesc,3>> input_descriptions(BatchCapacity c)noexcept{',
'''std::size_t input_count(const BatchSchema&schema)noexcept{return schema.mla_layout()==MlaCacheLayout::kNone?3:2;}
Result<std::array<TensorDesc,3>> input_descriptions(const BatchSchema&schema)noexcept{
  const auto c=schema.capacity();''')
sub('HYLE_ASSIGN_OR_RETURN(result[1],batch_cache_description(c,BatchCacheRole::kKey));\n  HYLE_ASSIGN_OR_RETURN(result[2],batch_cache_description(c,BatchCacheRole::kValue));return result;',
'''HYLE_ASSIGN_OR_RETURN(result[1],batch_cache_description(schema,schema.mla_layout()==MlaCacheLayout::kNone?BatchCacheRole::kKey:BatchCacheRole::kMla));
  if(input_count(schema)==3){HYLE_ASSIGN_OR_RETURN(result[2],batch_cache_description(schema,BatchCacheRole::kValue));}return result;''')
sub('return {inputs[0].storage(),inputs[1].storage(),inputs[2].storage(),views.metadata,mem::ConstBufferView(views.output)};',
 'return {inputs[0].storage(),inputs[1].storage(),inputs.size()==3?inputs[2].storage():mem::ConstBufferView{},views.metadata,mem::ConstBufferView(views.output)};')
sub('if(inputs.size()!=3 || s.closed', 'if(inputs.size()!=input_count(s.program->schema) || s.closed')
sub('if(inputs.size()!=4 || outputs.size()!=1)', 'if(inputs.size()!=input_count(s->program->schema)+1 || outputs.size()!=1)')
sub('input_descriptions(s->program->schema.capacity())','input_descriptions(s->program->schema)',3)
sub('input_descriptions(s.program->schema.capacity())','input_descriptions(s.program->schema)',2)
sub('input_descriptions(capacity)','input_descriptions(s->program->schema)')
sub('for(std::size_t i=0;i<3;++i)if(inputs[i].description()!=descriptions[i])',
    'for(std::size_t i=0;i<input_count(s->program->schema);++i)if(inputs[i].description()!=descriptions[i])')
sub('same_storage(inputs[3].storage(),mirror)','same_storage(inputs[input_count(s->program->schema)].storage(),mirror)')
sub('d::ProviderExtensionAccess::query(context,index,d::kBatchPlanningExtensionId)',
    'd::ProviderExtensionAccess::query(context,index,p->schema.mla_layout()==MlaCacheLayout::kNone?d::kBatchPlanningExtensionId:d::kMlaBatchPlanningExtensionId)')
sub('if(leases.size()!=3)return Status::InvalidArgument("batch replay needs Q/K/V readonly leases");',
    'if(leases.size()!=input_count(s->program->schema))return Status::InvalidArgument("batch replay payload count differs from schema");')
sub('for(std::size_t i=0;i<3;++i){HYLE_ASSIGN_OR_RETURN(inputs[i],leases[i].tensor(descriptions[i]));}',
    'for(std::size_t i=0;i<leases.size();++i){HYLE_ASSIGN_OR_RETURN(inputs[i],leases[i].tensor(descriptions[i]));}',2)
sub('return capture_batch(*s,inputs,views);','return capture_batch(*s,std::span(inputs).first(input_count(s->program->schema)),views);',2)
sub('if(leases.size()!=3)return std::unexpected(Status::InvalidArgument("batch run needs Q/K/V readonly leases"));',
    'if(leases.size()!=input_count(data_->program->schema))return std::unexpected(Status::InvalidArgument("batch payload count differs from schema"));')
sub('validate_replay_storage(s,inputs,views));\n  auto submitted=submit_native(s,false,leases,inputs,views);',
    'validate_replay_storage(s,std::span(inputs).first(leases.size()),views));\n  auto submitted=submit_native(s,false,leases,std::span(inputs).first(leases.size()),views);')
# Existing K/V overloads must never reinterpret the compact MLA cache.
sub('s->program->schema.capacity().storage!=BatchStorage::kPaged)',
    's->program->schema.capacity().storage!=BatchStorage::kPaged || s->program->schema.mla_layout()!=MlaCacheLayout::kNone)',2)
sub('s.program->schema.capacity().storage!=BatchStorage::kPaged)',
    's.program->schema.capacity().storage!=BatchStorage::kPaged || s.program->schema.mla_layout()!=MlaCacheLayout::kNone)')
sub('inputs.first(3)','inputs.first(inputs.size()-1)',4)
anchor='PagedBatchReceiver::PagedBatchReceiver(PagedBatchReceiver&&v)'
pos=s.index(anchor)
extra='''Status PreparedBatch::prepare_replay(MlaBatchInputs inputs)noexcept{
  if(!data_ || data_->program->schema.mla_layout()==MlaCacheLayout::kNone)
    return Status::InvalidArgument("MLA inputs require an MLA schema");
  const std::array leases{std::move(inputs.query),std::move(inputs.cache)};
  return prepare_replay(leases);
}
Result<Completion> PreparedBatch::run(MlaBatchInputs inputs)noexcept{
  if(!data_ || data_->program->schema.mla_layout()==MlaCacheLayout::kNone)
    return std::unexpected(Status::InvalidArgument("MLA inputs require an MLA schema"));
  const std::array leases{std::move(inputs.query),std::move(inputs.cache)};
  return run(leases);
}
Status PreparedBatch::prepare_replay(const ReadLease&query,const PagedArenaRead&cache)noexcept{
  auto*s=data_;
  if(!s || s->external_output || s->closed || s->failed || !s->prepared || s->ran || epoch_!=s->epoch ||
      s->program->schema.mla_layout()==MlaCacheLayout::kNone || s->program->schema.capacity().storage!=BatchStorage::kPaged)
    return Status::FailedPrecondition("MLA replay needs a prepared paged MLA token");
  if(cache.layout()!=s->layout)return Status::InvalidArgument("MLA cache layout differs from prepared metadata");
  HYLE_RETURN_IF_ERROR(d::PagedArenaAccess::validate_storage(cache,s->program->schema.capacity().key_storage));
  HYLE_ASSIGN_OR_RETURN(auto descriptions,input_descriptions(s->program->schema));
  std::array<ConstTensorView,2>inputs;
  HYLE_ASSIGN_OR_RETURN(inputs[0],query.tensor(descriptions[0]));
  HYLE_ASSIGN_OR_RETURN(inputs[1],d::PagedArenaAccess::tensor(cache));
  if(inputs[1].description()!=descriptions[1] || inputs[1].storage().resource()!=s->program->options.resource)
    return Status::InvalidArgument("MLA cache capacity/resource differs from native slot");
  HYLE_ASSIGN_OR_RETURN(auto views,workspace_views(*s));return capture_batch(*s,inputs,views);
}
Result<Completion> PreparedBatch::run(const ReadLease&query,const PagedArenaRead&cache)noexcept{
  auto*s=data_;
  if(!s || s->external_output || s->closed || s->failed || !s->prepared || s->ran || epoch_!=s->epoch ||
      s->program->schema.mla_layout()==MlaCacheLayout::kNone || s->program->schema.capacity().storage!=BatchStorage::kPaged)
    return std::unexpected(Status::FailedPrecondition("MLA run needs a prepared paged MLA token"));
  if(cache.layout()!=s->layout)return std::unexpected(Status::InvalidArgument("MLA cache layout differs from prepared metadata"));
  HYLE_RETURN_IF_ERROR(d::PagedArenaAccess::validate_storage(cache,s->program->schema.capacity().key_storage));
  HYLE_ASSIGN_OR_RETURN(auto descriptions,input_descriptions(s->program->schema));
  std::array<ConstTensorView,2>inputs;
  HYLE_ASSIGN_OR_RETURN(inputs[0],query.tensor(descriptions[0]));
  HYLE_ASSIGN_OR_RETURN(inputs[1],d::PagedArenaAccess::tensor(cache));
  if(inputs[1].description()!=descriptions[1] || inputs[1].storage().resource()!=s->program->options.resource)
    return std::unexpected(Status::InvalidArgument("MLA cache capacity/resource differs from native slot"));
  HYLE_ASSIGN_OR_RETURN(auto views,workspace_views(*s));
  HYLE_RETURN_IF_ERROR(validate_replay_storage(*s,inputs,views));
  const std::array ordinary{query};
  auto submitted=submit_native(*s,false,ordinary,inputs,views,d::PagedArenaAccess::pages(cache));
  if(!submitted){s->failed=true;s->prepared=false;return std::unexpected(submitted.error());}
  s->ran=true;s->prepared=false;return std::move(*submitted);
}
'''
s=s[:pos]+extra+s[pos:]
p.write_text(s,newline='\n')
