from pathlib import Path
import json,sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
sys.path.insert(0,str(ROOT/'.scratch/inference-feature-completion-2026-10-18/windows-batch'))
import build_host as b
b.OUT=OUT
b.records=json.loads((OUT/'host-commands.json').read_text()) if (OUT/'host-commands.json').exists() else []
if __name__=='__main__':
 records=[]
 for relative,name in [
  ('src/compute_batch/batch_layout.cc','batch-layout'),
  ('src/compute_batch/batch_execution.cc','batch-execution'),
  ('src/compute_batch/paged_arena.cc','paged-arena'),
  ('src/graph_batch/batch.cc','graph-batch'),
  ('src/compute_provider_flashinfer/flashinfer_provider.cc','flashinfer-provider')]:
  records.append(b.comp(relative,name))
 (OUT/'host-identities.json').write_text(json.dumps(records,indent=2)+'\n')
