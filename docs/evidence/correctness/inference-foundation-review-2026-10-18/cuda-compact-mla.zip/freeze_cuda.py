from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
DEST=OUT/'cuda-first'
DEST.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=['include/hyle/compute/batch_layout.h','include/hyle/compute/batch_ops.h','include/hyle/compute/batch_execution.h','include/hyle/compute/detail/batch_provider.h','src/compute_batch/batch_layout.cc','src/compute_batch/batch_execution.cc','src/compute_batch/paged_arena.cc','src/graph_batch/batch.cc','src/compute_provider_flashinfer/flashinfer_provider.cc','src/compute_provider_flashinfer/native_batch.h','src/compute_provider_flashinfer/native_mla.cu','src/compute_provider_flashinfer/CMakeLists.txt','third_party/flashinfer_cache/patches.json','third_party/flashinfer_cache/NOTICE.md','tests/compute_batch/public_mla_cuda_consumer.cc','tests/compute_batch/public_batch_cuda_consumer.cc']
summary=dict(scope='CUDA typed compact paged MLA CKV512/KPE64, one physical payload; no timing',hardware='Windows RTX 4070 SM89 CUDA 13.3 MSVC 14.50',dtype_heads=[dict(dtype='F16',heads=96),dict(dtype='BF16',heads=64)],geometry=dict(requests=2,query_indptr=[0,1,4],kv_page_indptr=[0,2,5],page_indices=[3,1,0,2,1],tails=[15,1],page_size=16,query_depth=576,output_depth=512),native_cache_payload_bytes=73728,native_float_workspace_bytes=6052864,native_int_workspace_bytes=590784,checks=['default CUDA Context discovers independent MLA extension','Direct + Graph full FP64 all-output oracle, budget 0.007','original Queue capture/replay','single arena with shared CKV as V; no V copy','page-ID-only rebind preserves plan/capture','old three-payload run and V arena rejected','query native-offset overflow rejected','tiny workspace returns ResourceExhausted before native plan upload','old Q/K/V public CUDA consumer complete PASS'],max_abs=dict(F16=5.52125161e-5,BF16_initial=0.000412140391,BF16_rebind=0.000468725344),first_failure=dict(retained=True,req=1,query_row=2,head=0,depth=1,actual=-0.0148162842,oracle=-0.00217224988359,error=0.0126440343,source_cause='MLA kernel cluster-end / num_heads floor truncated the last visible tile for 96 heads; scheduler already uses ceil. One kernel upper bound changed to ceil, per-element mask unchanged.',same_input_and_budget=True,source_note='Final consumer adds subsequent negative/rebind checks; first inputs/formula remain identical. Early per-command logs are retained.'),limitations=['Only CUDA paged 512/64 native path tested here; kCkv512 and ragged schemas are representable but declined by this native extension','No arbitrary mask, sinks, window, encoded or F32 cache','Workspace counters are explicit allocations, not total VRAM','Other four native CUDA TUs and foundation reused, no full SDK build'],source_identities=[dict(path=s,bytes=(ROOT/s).stat().st_size,sha256=sha(ROOT/s)) for s in sources])
(DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
artifacts=[p for p in OUT.iterdir() if p.is_file() and p.suffix in ['.exe','.obj']]
(DEST/'cleanup-candidates.json').write_text(json.dumps(dict(execute=False,files=[dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p)) for p in artifacts]),indent=2)+'\n')
with zipfile.ZipFile(DEST/'source-results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for s in sources:z.write(ROOT/s,'source/'+s)
 for p in OUT.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.log','.map']:z.write(p,p.name)
 for p in [DEST/'summary.json',DEST/'cleanup-candidates.json']:z.write(p,p.name)
p=DEST/'source-results.zip'
print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))))
