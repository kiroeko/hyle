from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'third_party/flashinfer_cache/patches.json';m=json.loads(p.read_text())
e=next(e for e in m['files'] if e['path']=='include/flashinfer/attention/scheduler.cuh')
data=(ROOT/'.scratch/g04-bf16-partials-vendor/upstream'/e['path']).read_text()
for x in e['edits']:
 assert data.count(x['before'])==1
 data=data.replace(x['before'],x['after'],1)
a='  int kv_len_limit = f(std::max<int64_t>(ceil_div(total_kv_lens, num_clusters), 1));'
b='''  const auto hyle_average_kv = std::max<int64_t>(ceil_div(total_kv_lens, num_clusters), 1);
  FLASHINFER_CHECK(hyle_average_kv <= std::numeric_limits<int>::max() - 255,
                   "MLA scheduler KV chunk rounding exceeds its native int field");
  int kv_len_limit = f(static_cast<int>(hyle_average_kv));'''
assert data.count(a)==1
data=data.replace(a,b,1);e['edits'].append(dict(before=a,after=b));e['after_sha256']=hashlib.sha256(data.encode()).hexdigest()
p.write_text(json.dumps(m,indent=2)+'\n',newline='\n')
