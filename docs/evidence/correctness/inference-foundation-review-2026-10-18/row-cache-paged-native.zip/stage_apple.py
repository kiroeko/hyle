from pathlib import Path
import base64,hashlib,io,json,re,subprocess,tarfile,sys
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-native';REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-foundation-review-20261018-row-cache-paged-native'
def ssh(code,payload=None):
 cmd='python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"'
 return subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=payload,capture_output=True,timeout=60)
def stage():
 files={'run_apple.py':O/'run_apple.py'};seen=set()
 def add(path):
  path=path.resolve()
  if path in seen:return
  seen.add(path)
  if path.is_relative_to(R)and'.scratch'not in path.relative_to(R).parts:files[path.relative_to(R).as_posix()]=path
  for name in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
   for candidate in [path.parent/name,R/name,R/'include'/name,R/'src/compute_route_apple'/name,R/'src/compute'/name]:
    if candidate.is_file():add(candidate);break
 for name in ['src/compute_route_apple/apple_row_cache.cc','src/compute_route_apple/apple_row_cache_paged.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_memory.mm','src/compute_batch/batch_layout.cc','src/compute_batch/paged_arena.cc','src/compute_ops/low_precision.cc','tests/compute_route_vulkan/row_cache_paged_test.cc']:add(R/name)
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w:gz')as z:
  for name,p in sorted(files.items()):z.add(p,arcname=name)
 (O/'apple-minimal-sources.tar.gz').write_bytes(b.getvalue());(O/'apple-staged-sha.json').write_text(json.dumps([dict(path=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for n,p in sorted(files.items())],indent=2)+'\n')
 code='from pathlib import Path;import tarfile,io,sys;r=Path('+repr(REMOTE)+');r.mkdir(exist_ok=True);z=tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode="r:gz");assert all(m.isfile()and not Path(m.name).is_absolute()and ".."not in Path(m.name).parts for m in z.getmembers());z.extractall(r);print(r)'
 p=ssh(code,b.getvalue());(O/'apple-stage.stdout.log').write_bytes(p.stdout);(O/'apple-stage.stderr.log').write_bytes(p.stderr);print(p.returncode,len(files),len(b.getvalue()),p.stdout.decode(),p.stderr.decode());p.check_returncode()
def action(name):
 p=subprocess.run(['ssh','kiro@172.22.10.198','cd '+REMOTE+' && python3 run_apple.py '+name],capture_output=True,timeout=300)
 (O/('apple-'+name+'.stdout.log')).write_bytes(p.stdout);(O/('apple-'+name+'.stderr.log')).write_bytes(p.stderr);print(p.returncode,p.stdout.decode(errors='replace')[-18000:],p.stderr.decode(errors='replace')[-3000:]);p.check_returncode()
def collect():
 p=ssh('from pathlib import Path;import tarfile,io,sys;r=Path('+repr(REMOTE)+');b=io.BytesIO();z=tarfile.open(fileobj=b,mode="w:gz");[z.add(p,arcname="apple-"+p.name)for p in r.iterdir()if p.is_file()and p.suffix in[".json",".log",".txt"]];z.close();sys.stdout.buffer.write(b.getvalue())');p.check_returncode();(O/'apple-results.tar.gz').write_bytes(p.stdout)
 with tarfile.open(fileobj=io.BytesIO(p.stdout),mode='r:gz')as z:
  assert all(m.isfile()and len(Path(m.name).parts)==1 for m in z.getmembers());z.extractall(O)
if __name__=='__main__':
 for name in sys.argv[1:]:
  {'stage':stage,'build':lambda:action('build'),'test':lambda:action('test'),'collect':collect}[name]()
