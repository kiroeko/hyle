from pathlib import Path
import sys,json,os
sys.path.insert(0,str(Path(__file__).resolve().parent));import build_vulkan as b
R=b.R;O=b.O;C=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-vulkan';old=json.loads((C/'commands.json').read_text());link=next(x['command']for x in reversed(old)if x['tag']=='link'and x['exit']==0)
if __name__=='__main__':
 b.compile('tests/compute_route_vulkan/row_cache_paged_test.cc','vulkan-test')
 replacement={str(C/'row-cache.obj'):str(O/'vulkan-row.obj'),str(C/'operations.obj'):str(O/'vulkan-operations.obj'),str(C/'shaders.obj'):str(O/'vulkan-shaders.obj')}
 cmd=[replacement.get(x,x)for x in link if not x.startswith(('/OUT:','/MAP:'))]
 # Locate the one native MemoryResource object, not the SDK/native backend.
 cmd=[x for x in cmd if not x.endswith(('\\compute-vulkan_memory.obj','\\vulkan-memory.obj','\\memory.obj'))]
 extras=[O/'vulkan-memory.obj',O/'vulkan-paged.obj',O/'vulkan-test.obj',R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages/batch_layout.obj',R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages/paged_arena.obj',R/'.scratch/build-compute-v2-dev/bin/hyle_compute_batch.lib']
 paths=[str(R/'.scratch/build-compute-v2-dev/bin')]+[str(Path(x).parent)for x in cmd if x.endswith('.lib')and Path(x).is_absolute()];b.env['PATH']=os.pathsep.join(dict.fromkeys(paths))+os.pathsep+b.env['PATH']
 b.run('vulkan-link',[*cmd,*extras,'/OUT:'+str(O/'vulkan-test.exe')]);b.run('vulkan-test',[O/'vulkan-test.exe','--gtest_filter=VulkanPagedRowCache.*:VulkanRowCache.*'])
