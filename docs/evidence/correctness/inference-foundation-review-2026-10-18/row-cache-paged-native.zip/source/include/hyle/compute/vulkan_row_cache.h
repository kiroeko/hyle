#pragma once
#include "hyle/compute/vulkan_memory.h"
#include "hyle/compute/batch_layout.h"
#include "hyle/compute/paged_arena.h"
#if defined(HYLE_COMPUTE_VULKAN)
namespace hyle::compute::vulkan {
struct PagedRowCacheGatherOptions final {
  std::size_t max_metadata_backing_bytes=SIZE_MAX;
  mem::AllocatorRef allocator=mem::system_allocator();ResourceBudget resource_budget{};
};
namespace detail {struct PagedRowCacheGatherState;}
// Native ready-frame Direct reader. One original Program/command submission
// maps request IDs then invokes the checked row codec. Results retain their
// original native storage; there is no whole-arena read lease or host ID copy.
// Same-Context device/staging resources and allocator remain borrowed. Explicit
// cold prepare copies metadata through original F2 and waits; replay does not.
class PagedRowCacheGatherInvocation final {
public:
  PagedRowCacheGatherInvocation()noexcept=default;
  PagedRowCacheGatherInvocation(const PagedRowCacheGatherInvocation&)=delete;
  PagedRowCacheGatherInvocation&operator=(const PagedRowCacheGatherInvocation&)=delete;
  HYLE_COMPUTE_ROUTE_VULKAN_API PagedRowCacheGatherInvocation(PagedRowCacheGatherInvocation&&)noexcept;
  HYLE_COMPUTE_ROUTE_VULKAN_API PagedRowCacheGatherInvocation&operator=(PagedRowCacheGatherInvocation&&)noexcept;
  HYLE_COMPUTE_ROUTE_VULKAN_API ~PagedRowCacheGatherInvocation();
  HYLE_COMPUTE_ROUTE_VULKAN_API static Result<PagedRowCacheGatherInvocation> create(const Context&,
      const MemoryResource&device,const MemoryResource&staging,RowCacheBatchSchema,TensorDesc ids,PagedRowCacheGatherOptions={})noexcept;
  bool valid()const noexcept{return data_!=nullptr;}
  HYLE_COMPUTE_ROUTE_VULKAN_API TensorDesc output_description()const noexcept;
  HYLE_COMPUTE_ROUTE_VULKAN_API Status prepare_layout(RowCacheLayoutVersion)noexcept;
  HYLE_COMPUTE_ROUTE_VULKAN_API Result<OwnedResult<Results>> submit(PagedRowCacheRead,ReadLease ids)noexcept;
  HYLE_COMPUTE_ROUTE_VULKAN_API Status close()noexcept;
  HYLE_COMPUTE_ROUTE_VULKAN_API Status drain()noexcept;
private:
  explicit PagedRowCacheGatherInvocation(detail::PagedRowCacheGatherState*p)noexcept:data_(p){}
  detail::PagedRowCacheGatherState*data_=nullptr;
};
}
#endif
