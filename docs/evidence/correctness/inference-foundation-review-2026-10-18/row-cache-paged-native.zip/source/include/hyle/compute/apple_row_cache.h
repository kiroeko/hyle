#pragma once
#include "hyle/compute/apple_memory.h"
#include "hyle/compute/batch_layout.h"
#include "hyle/compute/paged_arena.h"
#if defined(HYLE_COMPUTE_APPLE)
namespace hyle::compute::apple {
struct PagedRowCacheGatherOptions final {
  std::size_t max_metadata_backing_bytes=SIZE_MAX;
  mem::AllocatorRef allocator=mem::system_allocator();ResourceBudget resource_budget{};
};
namespace detail {struct PagedRowCacheGatherState;}
// Native ready-frame Direct reader. One original Program performs device
// request/page mapping and the checked row codec. Result storage is owned by
// the original native invocation, unlike the common caller-output API.
// Device/staging resources and allocator remain borrowed; the two resources
// may be the same Apple shared MemoryResource. Cold prepare copies metadata
// through original F2 and waits. IDs never undergo host observation.
class PagedRowCacheGatherInvocation final {
public:
  PagedRowCacheGatherInvocation()noexcept=default;
  PagedRowCacheGatherInvocation(const PagedRowCacheGatherInvocation&)=delete;
  PagedRowCacheGatherInvocation&operator=(const PagedRowCacheGatherInvocation&)=delete;
  HYLE_COMPUTE_ROUTE_APPLE_API PagedRowCacheGatherInvocation(PagedRowCacheGatherInvocation&&)noexcept;
  HYLE_COMPUTE_ROUTE_APPLE_API PagedRowCacheGatherInvocation&operator=(PagedRowCacheGatherInvocation&&)noexcept;
  HYLE_COMPUTE_ROUTE_APPLE_API ~PagedRowCacheGatherInvocation();
  HYLE_COMPUTE_ROUTE_APPLE_API static Result<PagedRowCacheGatherInvocation> create(const Context&,
      const MemoryResource&device,const MemoryResource&staging,RowCacheBatchSchema,TensorDesc ids,PagedRowCacheGatherOptions={})noexcept;
  bool valid()const noexcept{return data_!=nullptr;}
  HYLE_COMPUTE_ROUTE_APPLE_API TensorDesc output_description()const noexcept;
  HYLE_COMPUTE_ROUTE_APPLE_API Status prepare_layout(RowCacheLayoutVersion)noexcept;
  HYLE_COMPUTE_ROUTE_APPLE_API Result<OwnedResult<Results>> submit(PagedRowCacheRead,ReadLease ids)noexcept;
  HYLE_COMPUTE_ROUTE_APPLE_API Status close()noexcept;
  HYLE_COMPUTE_ROUTE_APPLE_API Status drain()noexcept;
private:
  explicit PagedRowCacheGatherInvocation(detail::PagedRowCacheGatherState*p)noexcept:data_(p){}
  detail::PagedRowCacheGatherState*data_=nullptr;
};
}
#endif
