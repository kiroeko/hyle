from pathlib import Path
import json,subprocess,time,sys,hashlib
R=Path(__file__).resolve().parent;OLD=R.parent/'inference-foundation-review-20261018-apple-row-cache-cold';CODEC=R.parent/'inference-foundation-review-20261018-apple-row-cache';SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
old=json.loads((OLD/'commands.json').read_text());cc=next(x['command']for x in old if x['tag']=='context.o-compile');link=next(x['command']for x in reversed(old)if x['tag']=='row-cache-test-link'and x['exit']==0)
records=json.loads((R/'commands.json').read_text())if(R/'commands.json').exists()else[]
def run(tag,cmd):
 stem=f'{len(records)+1:02d}-'+tag;start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,capture_output=True,timeout=180)
 (R/(stem+'.stdout.log')).write_bytes(p.stdout);(R/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(R/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,p.stdout.decode(errors='replace')[-6000:]+p.stderr.decode(errors='replace')[-4500:],flush=True);p.check_returncode()
def build():
 assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
 (R/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
 if not(R/'mlx.metallib').exists():(R/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
 prefix=cc[:cc.index('-c')];prefix[1:1]=['-I'+str(R/'include'),'-I'+str(R),'-I'+str(R/'src/compute_route_apple'),'-I'+str(R/'src/compute'),'-DHYLE_ROW_CACHE_PAGED_APPLE=1']
 for source,obj in [('src/compute_route_apple/apple_row_cache.cc','row.o'),('src/compute_route_apple/apple_mature_float.cc','mature.o'),('src/compute_route_apple/apple_row_cache_paged.cc','paged.o'),('src/compute_route_apple/apple_memory.mm','memory.o'),('src/compute_batch/batch_layout.cc','layout.o'),('src/compute_batch/paged_arena.cc','arena.o'),('src/compute_ops/low_precision.cc','low.o'),('tests/compute_route_vulkan/row_cache_paged_test.cc','test.o')]:run(obj+'-compile',[*prefix,'-c',R/source,'-o',R/obj])
 cmd=[]
 for x in link:
  if x==str(OLD/'row-cache-test'):cmd.append(str(R/'native-test'))
  elif x==str(CODEC/'row-cache.o'):cmd.append(str(R/'row.o'))
  elif x==str(CODEC/'mature.o'):cmd.append(str(R/'mature.o'))
  elif x==str(CODEC/'test.o'):cmd.append(str(R/'test.o'))
  elif x==str(CODEC/'low-precision.o'):cmd.append(str(R/'low.o'))
  elif x.endswith('/apple-memory.o')or x.endswith('/compute_route_apple/apple_memory.mm.o'):cmd.append(str(R/'memory.o'))
  elif x.startswith('-Wl,-map,'):continue
  else:cmd.append(x)
 cmd +=[str(R/'paged.o'),str(R/'layout.o'),str(R/'arena.o')]
 if str(R/'memory.o')not in cmd:cmd.append(str(R/'memory.o'))
 run('link',cmd)
 (R/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in map(Path,cmd)if p.suffix in{'.o','.a','.dylib'}and p.exists()],indent=2)+'\n')
def relink():
 cmd=next(x['command']for x in reversed(records)if x['tag']=='link'and x['exit']==0);cmd=[*cmd,str(CODEC/'test.o')];run('compatibility-link',cmd)
def test():run('test',[R/'native-test','--gtest_filter=ApplePagedRowCache.*:AppleRowCache.*'])
if __name__=='__main__':
 for name in sys.argv[1:]:globals()[name]()
