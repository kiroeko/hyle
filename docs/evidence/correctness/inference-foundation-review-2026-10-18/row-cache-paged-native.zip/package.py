from pathlib import Path
import difflib, hashlib, json, shutil, subprocess, zipfile

R=Path.cwd()
O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-native'
old=json.loads((O/'paths.json').read_text())
new=['include/hyle/compute/apple_row_cache.h','include/hyle/compute/vulkan_row_cache.h',
     'src/compute_ggml_runtime/row_cache_native_controller.h',
     'src/compute_route_apple/apple_row_cache_paged.cc',
     'src/compute_route_vulkan/vulkan_row_cache_paged.cc',
     'tests/compute_models/row_cache_native_fixture.h',
     'tests/compute_route_vulkan/row_cache_paged_test.cc']
def identity(p):
 return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(name,value):
 (O/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
changes=[];sources=[]
for name in old+new:
 p=R/name;b=O/'before'/name
 before=b.read_text(encoding='utf-8-sig').splitlines(True) if b.exists() else []
 after=p.read_text(encoding='utf-8-sig').splitlines(True)
 changes.extend(difflib.unified_diff(before,after,fromfile='a/'+name if b.exists() else '/dev/null',tofile='b/'+name))
 target=O/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 sources.append(dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(O/'source.diff').write_text(''.join(changes),encoding='utf-8')
write('source-sha.json',sources)
commands=json.loads((O/'vulkan-commands.json').read_text())
link=next(x['command'] for x in reversed(commands) if x['tag']=='vulkan-link' and x['exit']==0)
deps=[]
for name in link:
 p=Path(name)
 if p.suffix.lower() in {'.obj','.lib','.dll'} and p.is_file():deps.append(identity(p))
write('vulkan-identities.json',deps)
write('retain-objects.json',dict(windows=[identity(p) for p in sorted(O.glob('*.obj'))],
 apple=json.loads((O/'apple-retain-objects.json').read_text()),
 rule='Retain all listed fresh host objects and all original dependency/native SDK caches.'))
write('deletable-artifacts.json',dict(windows=[identity(p) for p in sorted(O.iterdir()) if p.suffix.lower() in {'.exe','.lib','.exp'}],
 apple=json.loads((O/'apple-deletable-artifacts.json').read_text()),
 rule='Exact targets only; no deletion performed. Root may put checked paths into test.ps1.'))
shutil.copyfile(R/'.scratch/inference-foundation-review-2026-10-18/row-cache-vulkan/machine.txt',O/'vulkan-machine.txt')
write('summary.json',{
 'scope':'Native namespace Direct ready PagedRowCacheGatherInvocation for Apple and Vulkan; original typed page owner/permissions and ordinary codec semantics retained.',
 'api':{'apple':'hyle::compute::apple::PagedRowCacheGatherInvocation',
        'vulkan':'hyle::compute::vulkan::PagedRowCacheGatherInvocation',
        'input':'Exact RowCacheLayoutVersion/PagedRowCacheRead plus device I32[T,K] ReadLease.',
        'output':'Original native OwnedResult<Results>; these entry points use native Context/MemoryResource and do not impersonate the common CPU/CUDA Context/Queue API.',
        'resources':'Caller supplies original device and staging resources. Optional max_metadata_backing_bytes defaults SIZE_MAX; allocator and ResourceBudget retained.'},
 'implementation':[
  'One original native Program maps per-query logical IDs to physical rows, then existing checked RowCacheGatherDecode decodes only selected rows. No host IDs readback or fabricated whole-arena ReadLease.',
  'Device upper_bound of query_indptr skips zero-query requests; request logical length is validated before page index/address. Invalid IDs become -1 and existing checked codec rejects without publishing a ready result.',
  'Native typed bank binding has full physical TensorDesc but retains exact PagedRowCacheRead page permissions; unknown providers/Graph paths are not newly qualified.',
  'Apple checked decoder invalid-row speculative read is redirected to the first initialized row of the actual compact authorized page footprint. Page0 is deliberately uninitialized/unowned in the regression. Ordinary codec behavior is unchanged.',
  'Each new layout version copies the entire fixed metadata mirror through original F2 and waits, with exact same-version reuse. Each submit still constructs original native binding metadata, result owners and permission-use records. Native submit retains actual page/IDs/metadata LeaseUse and backing through completion/result; output holds block reuse. This is not hot zero-allocation or capture.',
  'K0 uses an empty metadata view over an original one-word I32 lease, without broadening generic empty native bindings or reading payload. K>0 with globally empty history is cold rejected.',
 ],
 'validation':{
  'vulkan':{'final':'4/4 PASS (new typed reader1 + original ordinary row codec3)',
            'log':'17-vulkan-test.stdout.log','hardware':'NVIDIA GeForce RTX 4070',
            'fresh':'4 provider/controller/memory/operations host TUs + existing residual shader generator output TU + canonical test; reused original native SDK/libs and ABI-compatible row-ready foundation objects.',
            'flags':'Recorded verbatim in vulkan-commands.json; MSVC14.50 /W4 /WX /O2 /MD.'},
  'apple':{'final':'5/5 PASS (new typed reader1 + original ordinary row codec4)',
           'log':'apple-12-test.stdout.log','hardware':'MacBook Air Mac16,12 Apple M4 arm64 16GiB; Apple clang21',
           'fresh':'8 host TUs: row codec, mature dispatch, native controller, native memory, batch layout, arena, low precision, canonical test. Original SDK/MLX native/metallib reused; no SDK/native rebuild.',
           'sdk':'/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk',
           'identities':'apple-identities-final.json includes actual successful compatibility-link inputs.'},
  'coverage':'Both encodings, two layout/IDs phases, repeated high physical pages, zero-query/zero-KV segments, request logical -1/3/8 invalids despite physical arena capacity, independent layout mismatch, retained output reuse rejection, K0 empty footprint, and FP8 caller reader/frame/arena released before result wait. Selected BF16 bits compared with independent table/FP64/BF16 oracle.',
  'limitations':'Lifetime test does not prove pending-behind-gate timing. No native pending row support or new Graph qualification; no joint sparse attention kernel, packed indexer MatMul, or complete model/MTP engine validation. Cold metadata upload waits and per-bind native view metadata remain real costs. Existing MLX shape/I32, Vulkan storage/grid/workgroup limits remain.',
 },
 'iterations':[
  'Initial Vulkan test compile lacked batch_layout.h in the shared fixture; corrected include.',
  'Initial test required a specific Unavailable status for retained results; corrected to require rejection as the native contract promises.',
  'Initial Vulkan K0 generic slice/reshape rejected a non-dense empty description; replaced with private metadata-only empty view over the original lease. Original ordinary codec tests passed throughout.',
  'No kernel numerical mismatch was observed; final tests above are the claimed results.'
 ],
 'isolation':'IREE native_program/generator/manifest, common reader, Graph/pending-row runtime and original SDK/caches were not modified by this stage. Root confirmed pending foundation additions do not change reused ready-object ABI.',
 'self_review':['Device mapping validates logical visibility before physical address.',
                'First compact page reference always contributes an initialized row; zero-KV requests contribute no references, zero-query requests may safely contribute authorized references, and duplicates remain authorized.',
                'Actual native Completion/Results own uses and typed bindings rather than the controller; no queued callable captures a controller pointer.',
                'Original native submission/error/reuse gates and F1/F2 authority are reused; no separate executor or nested common QueueSequence.'],
 'cleanup':'deletable-artifacts.json is a hash-exact proposal only; retain-objects.json and original native caches must remain. No cleanup performed.'
})
check=subprocess.run(['git','diff','--check'],cwd=R,capture_output=True)
(O/'diff-check.stdout.log').write_bytes(check.stdout);(O/'diff-check.stderr.log').write_bytes(check.stderr)
write('diff-check.json',dict(command=['git','diff','--check'],exit=check.returncode))
check.check_returncode()
include=[]
for p in sorted(O.rglob('*')):
 rel=p.relative_to(O)
 if not p.is_file() or rel.parts[0] in {'before','__pycache__'}:continue
 if p.name=='source-results.zip' or p.suffix.lower() in {'.obj','.o','.lib','.a','.exe','.exp','.spv','.gz'}:continue
 if rel.parts[0]=='shaders' and p.suffix.lower() not in {'.cc','.h','.json','.log'}:continue
 include.append(p)
with zipfile.ZipFile(O/'source-results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in include:z.write(p,p.relative_to(O).as_posix())
print(json.dumps(identity(O/'source-results.zip'),indent=2))
print('source files',len(sources),'archive files',len(include))
