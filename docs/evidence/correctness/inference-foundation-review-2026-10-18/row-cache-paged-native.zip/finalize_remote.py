from pathlib import Path
import json
import stage_apple

code = '''from pathlib import Path
import hashlib,json
r=Path(%r)
records=json.loads((r/'commands.json').read_text())
cmd=next(x['command'] for x in reversed(records) if x['tag']=='compatibility-link' and x['exit']==0)
def identity(p):
 return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
deps=[identity(p) for p in map(Path,cmd) if p.suffix in {'.o','.a','.dylib'} and p.is_file()]
(r/'identities-final.json').write_text(json.dumps(deps,indent=2)+'\\n')
(r/'deletable-artifacts.json').write_text(json.dumps([identity(r/'native-test')],indent=2)+'\\n')
(r/'retain-objects.json').write_text(json.dumps([identity(r/n) for n in ['row.o','mature.o','paged.o','memory.o','layout.o','arena.o','low.o','test.o']],indent=2)+'\\n')
print('Recorded final dependency identities, one executable cleanup target, and eight retained host objects.')
''' % stage_apple.REMOTE
p=stage_apple.ssh(code)
stage_apple.O.joinpath('apple-finalize.stdout.log').write_bytes(p.stdout)
stage_apple.O.joinpath('apple-finalize.stderr.log').write_bytes(p.stderr)
print(p.returncode,p.stdout.decode(),p.stderr.decode())
p.check_returncode()
stage_apple.collect()
