from pathlib import Path
import importlib.util,sys,json,subprocess,time,hashlib
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'inference-fusion-quantization-20261018-apple-selected-fp8-scale'
spec=importlib.util.spec_from_file_location('cache',OLD/'run_remote.py');cache=importlib.util.module_from_spec(spec);spec.loader.exec_module(cache)
FLAGS=cache.FLAGS;INC=['-I'+str(ROOT/'include'),'-I'+str(ROOT),*cache.INC];SDK=cache.SDK
records=json.loads((ROOT/'commands.json').read_text())if(ROOT/'commands.json').exists()else[]
def run(tag,command,expected=0):
 command=list(map(str,command));stem=tag+'-'+str(1+sum(x['tag']==tag for x in records));start=time.monotonic();p=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=120)
 (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=command,cwd=str(ROOT),exit=p.returncode,expected=expected,seconds=time.monotonic()-start));(ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,flush=True)
 if p.returncode!=expected:print(p.stdout.decode(errors='replace')[-3500:],p.stderr.decode(errors='replace')[-7000:]);raise SystemExit(p.returncode or 2)
 return p.stdout

def link(name,probe,mature):
 exe=ROOT/name
 run(name+'-link',['clang++','-O3','-std=c++23','-arch','arm64','-o',exe,probe,mature,*cache.retained,*cache.LIBS,'-Wl,-rpath,'+str(cache.TORCH),'-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore','-Wl,-map,'+str(ROOT/(name+'.map'))])
def build():
 if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
 for file,stem in [('apple_mature_float.candidate.cc','mature'),('apple_mature_float.small-2d.cc','small-2d-mature'),('small_probe.cc','small-probe'),('full_probe.cc','full-probe')]:
  if not(ROOT/(stem+'.o')).exists()or(ROOT/file).stat().st_mtime>(ROOT/(stem+'.o')).stat().st_mtime:run(stem+'-compile',['clang++',*FLAGS,*INC,'-c',ROOT/file,'-o',ROOT/(stem+'.o')])
 link('small-old',ROOT/'small-probe.o',OLD/'new-mature.o')
 link('small-new',ROOT/'small-probe.o',ROOT/'small-2d-mature.o')
 link('full-bank',ROOT/'full-probe.o',ROOT/'mature.o')
def small():
 for arm in ['old','new']:
  run('small-'+arm+'-test',[ROOT/('small-'+arm)]);(ROOT/'output.f32').rename(ROOT/('small-'+arm+'-output.f32'))
 old=(ROOT/'small-old-output.f32').read_bytes();new=(ROOT/'small-new-output.f32').read_bytes();assert old==new
 (ROOT/'comparison.json').write_text(json.dumps(dict(bytes=len(old),outputs=len(old)//4,all_bits_equal=True,sha256=hashlib.sha256(old).hexdigest()),indent=2)+'\n')
def full():run('full-bank-test',[ROOT/'full-bank'])
if __name__=='__main__':{'build':build,'small':small,'full':full}[sys.argv[1]]()
