#include <mlx/mlx.h>
#include <mlx/memory.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <optional>
#include <stdexcept>
#include <vector>
#include "hyle/compute/apple_memory.h"
#include "hyle/compute/model_ops.h"
namespace c=hyle::compute;namespace a=c::apple;namespace mx=mlx::core;
template<class T>T take(hyle::Result<T>&&r,const char*phase){if(!r)throw std::runtime_error(std::string(phase)+": "+std::string(r.error().message()));return std::move(*r);}
void check(hyle::Status s){if(!s.ok())throw std::runtime_error(std::string(s.message()));}
mx::array ready(mx::array x){mx::async_eval({x});mx::synchronize(mx::default_stream(mx::Device::gpu));x.wait();return x;}
std::vector<float> values(mx::array x){x=ready(mx::contiguous(x,false));return {x.data<float>(),x.data<float>()+x.size()};}
float scale(int group_n,int group_k){return float(256*(group_n+1)*(group_k+1))/1048576.0F;}
int main(){try{
 constexpr std::int64_t e=256,n=2048,k=6144,expert=255,slots=8;
 const std::size_t codes_bytes=std::size_t(e)*n*k,expert_bytes=std::size_t(n)*k,expert_offset=std::size_t(expert)*expert_bytes;
 const std::size_t scale_bytes=std::size_t(e)*(n/128)*(k/128)*4,total_bytes=codes_bytes+scale_bytes;
 auto context=take(a::Context::create(),"context");
 auto memory=take(a::MemoryResource::create(context),"memory resource");
 const auto wd=take(c::float8_grouped_weight_description(e,n,k),"weight description");
 const auto xd=take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,3>{1,1,k}),"activation description");
 const auto id=take(c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,2>{1,slots}),"IDs description");
 const auto ws=take(a::input_spec(wd),"large weight spec");
 if(ws.shape!=mx::Shape{static_cast<int>(total_bytes/4),4}||ws.dtype!=mx::uint8)throw std::runtime_error("carrier shape");
 const std::array specs{ws,take(a::input_spec(xd),"activation spec"),take(a::input_spec(id),"IDs spec")};
 auto prepared=take(context.prepare(c::model_ops::grouped_float8_linear(),specs),"prepare");
 const auto after_prepare=mx::get_active_memory(),cache_after_prepare=mx::get_cache_memory();
 std::printf("{\"phase\":\"prepared\",\"active\":%zu,\"cache\":%zu}\n",after_prepare,cache_after_prepare);std::fflush(stdout);
 // InputSpec warmup is unchanged. Do not allocate another full bank if its
 // warm inputs remained active or the actual native allocator cannot retire.
 if(after_prepare>(std::size_t{1}<<30))throw std::runtime_error("warm active owners exceed conservative probe headroom");
 auto bank=take(memory.allocate(wd),"full bank allocation");
 const auto storage=take(memory.storage_info(bank),"native buffer");
 if(storage.view_bytes!=total_bytes||storage.backing_bytes<total_bytes)throw std::runtime_error("native allocation size");
 auto*bytes=bank.data<std::uint8_t>();std::memset(bytes+expert_offset,0,expert_bytes);
 for(std::int64_t row=0;row<n;++row){const auto col=std::size_t((row*17+expert*7)%128);bytes[expert_offset+std::size_t(row)*k+col]=0x38;bytes[expert_offset+std::size_t(row)*k+128+col]=0xc0;}
 const std::size_t scale_offset=codes_bytes+std::size_t(expert)*std::size_t(n/128)*std::size_t(k/128)*4;
 for(int nr=0;nr<n/128;++nr)for(int kr=0;kr<k/128;++kr){const float x=scale(nr,kr);std::memcpy(bytes+scale_offset+(nr*(k/128)+kr)*4,&x,4);}
 auto invocation=take(prepared.create_invocation(),"invocation");std::size_t checked=0;double maxerr=0;std::optional<mx::array> old;std::vector<float> oldvalues;
 for(int phase:{0,1}){
  std::vector<float>x(k);for(std::size_t j=0;j<x.size();++j)x[j]=float(j%2?224:448)/(phase?2.0F:1.0F);
  const std::array<std::int32_t,slots> ids{255,255,255,255,255,255,255,255};
  auto input=ready(mx::array(x.data(),{1,1,int(k)},mx::float32));auto native_ids=ready(mx::array(ids.data(),{1,int(slots)},mx::int32));const std::array inputs{bank,input,native_ids};
  check(invocation.bind(inputs));auto done=take(invocation.submit(),"submit");
  {auto result=take(done.wait(),"wait");auto native=result->arrays()[0];const auto actual=values(native);if(actual.size()!=slots*n)throw std::runtime_error("output shape");
   for(std::size_t j=0;j<actual.size();++j){const auto row=j%std::size_t(n);const auto col=std::size_t((row*17+std::size_t(expert)*7)%128);const double expected=double(x[col])*scale(int(row/128),0)-2.0*double(x[128+col])*scale(int(row/128),1);const double err=std::abs(double(actual[j])-expected);maxerr=std::max(maxerr,err);if(!std::isfinite(actual[j])||err>2e-6+2e-6*std::abs(expected))throw std::runtime_error("oracle");++checked;}
   if(!old){old=native;oldvalues=actual;}}
  if(values(*old)!=oldvalues)throw std::runtime_error("old output changed");
 }
 std::printf("{\"phase\":\"complete\",\"total_bytes\":%zu,\"codes_bytes\":%zu,\"expert_offset\":%zu,\"scale_offset\":%zu,\"explicit_host_written_bytes\":%zu,\"native_view_bytes\":%zu,\"native_backing_bytes\":%zu,\"checked\":%zu,\"max_abs\":%.17g,\"old_output_preserved\":true,\"active\":%zu,\"cache\":%zu}\n",total_bytes,codes_bytes,expert_offset,scale_offset,expert_bytes+std::size_t(n/128)*std::size_t(k/128)*4,storage.view_bytes,storage.backing_bytes,checked,maxerr,mx::get_active_memory(),mx::get_cache_memory());
 return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
