#include <mlx/mlx.h>
#include <mlx/primitives.h>
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <typeinfo>
#include <vector>
#include "hyle/compute/apple.h"
#include "hyle/compute/detail/apple_plan.h"
#include "hyle/compute/model_ops.h"
#include <cstring>
#include <optional>
namespace c=hyle::compute;namespace a=c::apple;namespace mx=mlx::core;
mx::array ready(mx::array x){mx::async_eval({x});mx::synchronize(mx::default_stream(mx::Device::gpu));x.wait();return x;}
void check(hyle::Status s){if(!s.ok())throw std::runtime_error(std::string(s.message()));}
std::vector<float> values(mx::array x){x=ready(mx::contiguous(x,false));return {x.data<float>(),x.data<float>()+x.size()};}
std::vector<std::uint32_t> bits(mx::array x){const auto v=values(x);std::vector<std::uint32_t>b;for(auto z:v)b.push_back(std::bit_cast<std::uint32_t>(z));return b;}
float scale(int expert,int group_n,int group_k){return float((expert+1)*(group_n+1)*(group_k+1))/4096.0F;}
std::vector<float> activation(int k,int phase){std::vector<float>x(k);for(int j=0;j<k;++j)x[j]=float(j%2?224:448)/(phase?2.0F:1.0F);return x;}
std::vector<std::byte> weight_bytes(int e,int n,int k){const auto nb=(n+127)/128,kb=k/128;std::vector<std::byte>b(static_cast<std::size_t>(e)*(n*k+nb*kb*4));for(int ex=0;ex<e;++ex){for(int row=0;row<n;++row){const int col=(row*17+ex*7)%128;b[(ex*n+row)*k+col]=std::byte{0x38};b[(ex*n+row)*k+128+col]=std::byte{0xc0};}for(int nr=0;nr<nb;++nr)for(int kr=0;kr<kb;++kr){const auto x=scale(ex,nr,kr);std::memcpy(b.data()+e*n*k+((ex*nb+nr)*kb+kr)*4,&x,4);}}return b;}
std::vector<float> reference(std::span<const float>x,std::span<const std::int32_t>ids,int n){std::vector<float>out(ids.size()*n);for(std::size_t slot=0;slot<ids.size();++slot)for(int row=0;row<n;++row){const int ex=ids[slot],col=(row*17+ex*7)%128;const double expected=double(x[col])*scale(ex,row/128,0)-2.0*double(x[128+col])*scale(ex,row/128,1);out[slot*n+row]=float(expected);}return out;}
template<class T>T take(hyle::Result<T>&& r,const char*phase){if(!r)throw std::runtime_error(std::string(phase)+": "+std::string(r.error().message()));return std::move(*r);}
int main(){try{
 constexpr int e=64,n=257,k=256,slots=8;
 auto context=take(a::Context::create(),"context");
 const auto wd=take(c::float8_grouped_weight_description(e,n,k),"weight description");
 const auto xd=take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,3>{1,1,k}),"activation description");
 const auto id=take(c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,2>{1,slots}),"IDs description");
 const std::array descriptions{wd,xd,id};const auto yd=take(c::infer_single_output(c::model_ops::grouped_float8_linear(),descriptions),"output description");
 auto payload=weight_bytes(e,n,k);const auto weight_spec=take(a::input_spec(wd),"weight spec");auto w=ready(mx::array(reinterpret_cast<std::uint8_t*>(payload.data()),weight_spec.shape,mx::uint8));
 const std::array specs{weight_spec,take(a::input_spec(xd),"activation spec"),take(a::input_spec(id),"IDs spec")};
 auto prepared=context.prepare(c::model_ops::grouped_float8_linear(),specs);if(!prepared)throw std::runtime_error(std::string(prepared.error().message()));
 auto invocation=take(prepared->create_invocation(),"invocation");std::vector<std::uint32_t> allbits;std::optional<mx::array> old;std::vector<std::uint32_t> oldbits;
 std::size_t total=0;double maxerr=0;std::vector<int> repeated_experts;
 for(int seed:{0,1}){
  auto xdata=activation(k,seed);
  const std::array<std::int32_t,8> ids=seed?std::array<std::int32_t,8>{2,2,63,3,1,9,31,0}:std::array<std::int32_t,8>{63,63,3,1,62,0,3,9};
  auto x=ready(mx::array(xdata.data(),{1,1,k},mx::float32));auto i=ready(mx::array(ids.data(),{1,slots},mx::int32));const std::array inputs{w,x,i};
  if(seed==0){
   auto census=context.compile([&](const std::vector<mx::array>&arguments,mx::Stream stream)->hyle::Result<std::vector<mx::array>>{
    auto graph=a::detail::lower_mlx_float(c::model_ops::grouped_float8_linear(),descriptions,arguments,stream);if(!graph)return std::unexpected(std::move(graph).error());
    std::set<std::uintptr_t> seen;
    const auto visit=[&](auto&& self,const mx::array&v)->void{
     if(!seen.insert(v.id()).second)return;
     if(v.has_primitive()&&v.dtype()==mx::float32&&v.ndim()==3&&v.shape(1)==384&&v.shape(2)==2){const auto&primitive=v.primitive();if(std::string(typeid(primitive).name()).find("Reshape")!=std::string::npos)repeated_experts.push_back(v.shape(0));}
     for(const auto&input:v.inputs())self(self,input);
    };for(const auto&output:*graph)visit(visit,output);
    return graph;
   },specs);if(!census)throw std::runtime_error(std::string(census.error().message()));
  }
  check(invocation.bind(inputs));auto submitted=invocation.submit();if(!submitted)throw std::runtime_error(std::string(submitted.error().message()));
  {
   auto result=submitted->wait();if(!result)throw std::runtime_error(std::string(result.error().message()));auto native=result->get()->arrays()[0];const auto actual=values(native);const auto expected=reference(xdata,ids,n);if(actual.size()!=*yd.element_count())throw std::runtime_error("output shape");
   for(std::size_t j=0;j<actual.size();++j){const double err=std::abs(double(actual[j])-expected[j]);maxerr=std::max(maxerr,err);if(!std::isfinite(actual[j])||err>2e-6+2e-6*std::abs(expected[j]))throw std::runtime_error("oracle");++total;}
   const auto b=bits(native);allbits.insert(allbits.end(),b.begin(),b.end());if(!old){old=native;oldbits=b;}
  }
  if(bits(*old)!=oldbits)throw std::runtime_error("old result changed");
 }
 for(std::int32_t bad:{-1,e,std::numeric_limits<std::int32_t>::max()}){
  auto xdata=activation(k,1);auto x=ready(mx::array(xdata.data(),{1,1,k},mx::float32));const std::array<std::int32_t,8> ids{1,1,2,3,4,5,6,bad};auto i=ready(mx::array(ids.data(),{1,slots},mx::int32));const std::array inputs{w,x,i};
  auto fresh=take(prepared->create_invocation(),"invocation");check(fresh.bind(inputs));auto done=fresh.submit();if(!done)throw std::runtime_error(std::string(done.error().message()));auto failed=done->wait();if(failed||!failed.error().IsOutOfRange())throw std::runtime_error("checked ID error changed");if(bits(*old)!=oldbits)throw std::runtime_error("old result changed after failure");
 }
 std::ofstream raw("output.f32",std::ios::binary);raw.write(reinterpret_cast<const char*>(allbits.data()),std::streamsize(allbits.size()*sizeof(std::uint32_t)));raw.close();
 std::printf("{\"checked\":%zu,\"max_abs\":%.17g,\"invalid_cases\":3,\"old_result_preserved\":true,\"repeat_scale_expert_counts\":[",total,maxerr);for(std::size_t j=0;j<repeated_experts.size();++j)std::printf("%s%d",j?",":"",repeated_experts[j]);std::puts("]}");return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
