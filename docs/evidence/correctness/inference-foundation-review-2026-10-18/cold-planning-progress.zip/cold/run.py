from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('cpu_context_validation_base', ARCH / 'cpu-context-assembly/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def run(tag, command):
    rows = read(OUT / 'commands.json') if (OUT / 'commands.json').exists() else []
    stem = f'{len(rows) + 1:03d}-{tag}'
    row = dict(tag=tag, command=list(map(str, command)), cwd=str(OUT), exit=None,
               stdout=stem + '.stdout.log', stderr=stem + '.stderr.log')
    rows.append(row)
    save('commands.json', rows)
    print('START', stem, flush=True)
    started = time.monotonic()
    with (OUT / row['stdout']).open('wb') as out, (OUT / row['stderr']).open('wb') as err:
        child = subprocess.Popen(row['command'], cwd=OUT, env=b.env, stdout=out, stderr=err,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = child.pid
        save('commands.json', rows)
        row['exit'] = child.wait(timeout=180)
    row['seconds'] = round(time.monotonic() - started, 3)
    save('commands.json', rows)
    print('END', stem, row['exit'], row['seconds'], flush=True)
    for stream in ('stdout', 'stderr'):
        text = (OUT / row[stream]).read_text(encoding='utf-8', errors='replace')
        print(text[-8500:], flush=True)
    if row['exit']:
        raise SystemExit(row['exit'])
    return row


def compile_():
    recipes = []
    for source, object_name, history in [
        ('src/graph/executable.cc', 'graph-executable.obj', 'retire-native-runtime/paging-risks'),
        ('tests/graph/region_provider_test.cc', 'region-test.obj', 'native-inputs/windows'),
    ]:
        template = next(row for row in reversed(read(ARCH / history / 'commands.json'))
                        if row.get('exit', row.get('exit_code')) == 0 and
                        any(Path(value).name == Path(source).name for value in row['command']))
        flags = [value for value in template['command'][1:]
                 if not value.lower().startswith(('/fo', '/fd')) and not value.lower().endswith('.cc')]
        assert '/W4' in flags and '/WX' in flags
        command = [template['command'][0], *flags, str(ROOT / source), '/Fo' + str(OUT / object_name)]
        before = identity(ROOT / source)
        run(Path(object_name).stem + '-compile', command)
        assert identity(ROOT / source) == before
        recipes.append(dict(source=before, object=identity(OUT / object_name), command=command,
                            origin=f'{history}/commands.json:{template.get("tag")}'))
        save('fresh-identities.json', recipes)


def link():
    base_path = ARCH / 'cpu-context-assembly/link-plan.json'
    base = read(base_path)['command']
    old_test = ARCH / 'cpu-context-assembly/context-test.obj'
    old_executable = ARCH / 'retire-native-runtime/paging-risks/executable.obj'
    replacements = {str(old_test): str(OUT / 'region-test.obj'),
                    str(old_executable): str(OUT / 'graph-executable.obj')}
    assert all(name in base for name in replacements)
    command = [base[0]] + [replacements.get(value, value) for value in base[1:]
                          if not value.upper().startswith(('/OUT:', '/MAP:'))]
    command += ['/OUT:' + str(OUT / 'cold-tests.exe'), '/MAP:' + str(OUT / 'cold-tests.map')]
    assert not any(value in command for value in replacements)
    for name in ('compute-context.obj', 'graph-context.obj', 'ggml-provider.obj'):
        assert str(ARCH / 'cpu-context-assembly' / name) in command
    save('link-plan.json', dict(base=str(base_path), replacements=replacements, command=command))
    save('link-identities.json', [identity(value) for value in command
                                if Path(value).suffix.lower() in {'.obj', '.lib'} and Path(value).is_file()])
    run('cold-tests-link', command)


FILTERS = [
    'GraphRegions.AllRejectedRegionsTerminateWithoutRediscoveryOrLeafWork',
    'GraphRegions.RegionRetryCanChangeTargetButHonorsRequiredPlacement',
    'GraphRegions.FinalWorkspaceRetryKeepsHardConstraintsAndBudgets',
    'GraphRegions.EveryAllocationFailureInRegionReselectionRollsBack',
]


def execute():
    run('cold-tests-run', [OUT / 'cold-tests.exe', '--gtest_filter=' + ':'.join(FILTERS),
                          '--gtest_color=no', '--gtest_output=xml:' + str(OUT / 'tests.xml')])


def finalize():
    suite = ET.parse(OUT / 'tests.xml').getroot()
    assert int(suite.attrib['tests']) == 4 and int(suite.attrib['failures']) == 0
    fresh = read(OUT / 'fresh-identities.json')
    for row in fresh:
        assert identity(row['source']['path']) == row['source']
        assert identity(row['object']['path']) == row['object']
    text = (OUT / 'cold-tests.map').read_text(errors='replace')
    selected = []
    for marker, owner in [('?compile@graph@hyle@@', 'graph-executable.obj'),
                          ('?provider@ggml_cpu@compute@hyle@@', 'ggml-provider.obj')]:
        rows = [line.strip() for line in text.splitlines() if marker in line and '$unwind$' not in line]
        assert rows and all(line.endswith(owner) for line in rows), (marker, rows)
        selected.extend(rows)
    assert 'region-test.obj' in text
    link_command = read(OUT / 'link-plan.json')['command']
    context_inputs = [identity(ARCH / 'cpu-context-assembly' / name)
                      for name in ('compute-context.obj', 'graph-context.obj')]
    assert all(row['path'] in link_command for row in context_inputs)
    save('selected-map-owners.json', dict(
        map=identity(OUT / 'cold-tests.map'), symbols=selected,
        context_factory_inputs=context_inputs,
        context_factory_note='Explicit current assembly objects retained in link command; '
                             'these probe-based tests do not call the default factories, '
                             'so no factory symbols survived /OPT:REF.'))
    cleanup = [identity(path) for path in sorted(OUT.iterdir())
               if path.suffix.lower() in {'.exe', '.map', '.exp', '.lib'}]
    assert len(cleanup) == 4
    save('cleanup-manifest.json', dict(files=cleanup, bytes=sum(row['bytes'] for row in cleanup),
                                       retain=[row['object'] for row in fresh], delete_executed=False))
    summary = read(OUT / 'summary.json')
    summary.update(status='four_cold_compile_controls_passed', tests=4, filters=FILTERS,
                   verification=dict(git_diff_check='pass',
                                     strict_host_compile='two TU /W4 /WX PASS', tests='4/4 PASS',
                                     sdk_kernel_rebuild=False,
                                     finalization_audit='Initial factory map-symbol assertion was too strong; '
                                                        'actual unused factory objects were linker-discarded. '
                                                        'Audit now distinguishes selected symbols from explicit inputs.'),
                   validation=dict(commands='commands.json', fresh='fresh-identities.json',
                                   link='link-plan.json', map='selected-map-owners.json', xml='tests.xml',
                                   cleanup='cleanup-manifest.json'))
    save('summary.json', summary)
    print(json.dumps(dict(tests=4, cleanup_count=len(cleanup),
                          cleanup_bytes=sum(row['bytes'] for row in cleanup)), indent=2))


if __name__ == '__main__':
    {'compile': compile_, 'link': link, 'run': execute, 'finalize': finalize}[sys.argv[1]]()
