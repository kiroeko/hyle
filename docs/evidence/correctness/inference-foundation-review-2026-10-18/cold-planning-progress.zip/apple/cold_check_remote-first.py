from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'cold-placement-check'
OUT.mkdir(exist_ok=True)
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('existing_air_driver', ROOT / 'air_remote.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
SOURCES = ['src/graph/executable.cc', 'src/compute_route_cpu/cpu_context.cc',
           'src/graph_route_cpu/cpu_context.cc', 'src/compute_provider_ggml/ggml_cpu_provider.cc']


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def check_sources():
    expected = json.loads((OUT / 'source-identities.json').read_text())
    for row in expected:
        actual = a.identity(ROOT / row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row
    return expected


def compile_one(source):
    assert source in SOURCES
    check_sources()
    stem = source.replace('/', '--').rsplit('.', 1)[0]
    output = OUT / (stem + '.o')
    command = a.command(source) + ['-MMD', '-MF', str(OUT / (stem + '.d')),
                                  '-c', str(ROOT / source), '-o', str(output)]
    before = a.identity(ROOT / source)
    a.run('cold-' + stem + '-compile', command)
    assert before == a.identity(ROOT / source)
    row = dict(source=before, object=a.identity(output), command=command)
    # Existing linker discovers one current receipt per logical Hyle owner.
    a.write(stem + '.o.json', row)
    save(stem + '-identity.json', row)


def link():
    check_sources()
    for source in SOURCES:
        stem = source.replace('/', '--').rsplit('.', 1)[0]
        receipt = json.loads((ROOT / (stem + '.o.json')).read_text())
        assert receipt['object']['path'] == str(OUT / (stem + '.o'))
        assert receipt['object'] == a.identity(receipt['object']['path'])
    a.link('ready-page')
    rows = json.loads((ROOT / 'commands.json').read_text())
    final = next(row for row in reversed(rows) if row['tag'] == 'ready-page-link')
    save('link-command.json', final)
    inputs = json.loads((ROOT / 'ready-page-link-inputs.json').read_text())
    save('link-inputs.json', inputs)


def run():
    a.execute('ready-page')


def finish():
    current = check_sources()
    rows = json.loads((ROOT / 'commands.json').read_text())
    compiles = [row for row in rows if row['tag'].startswith('cold-') and row['tag'].endswith('-compile')]
    assert len(compiles) == 4 and all(row['exit'] == 0 for row in compiles)
    execution = next(row for row in reversed(rows) if row['tag'] == 'ready-page-run')
    link = next(row for row in reversed(rows) if row['tag'] == 'ready-page-link')
    assert execution['exit'] == link['exit'] == 0
    identities = [json.loads((OUT / (source.replace('/', '--').rsplit('.', 1)[0] + '-identity.json')).read_text())
                  for source in SOURCES]
    for row in identities:
        assert row['source'] == a.identity(row['source']['path'])
        assert row['object'] == a.identity(row['object']['path'])
    text = (ROOT / 'ready-page.map').read_text()
    objects_text = text.split('# Object files:', 1)[1].split('# Sections:', 1)[0]
    selected = []
    for row in identities:
        matches = [line.strip() for line in objects_text.splitlines() if row['object']['path'] in line]
        assert len(matches) == 1, (row['source']['path'], matches)
        selected.extend(matches)
    old_joint = [line for line in objects_text.splitlines() if 'libhyle_graph_route_cpu_apple.a(' in line]
    assert not old_joint
    # CPU factories must use the new explicit common assembly; its old archive member is forbidden.
    old_factory = [line for line in objects_text.splitlines()
                   if 'libhyle_compute_route_cpu.a(' in line and 'cpu_context' in line]
    assert not old_factory, old_factory
    save('map-selected-owners.json', dict(selected=selected, old_joint=old_joint,
                                        old_compute_cpu_factory=old_factory,
                                        map=a.identity(ROOT / 'ready-page.map')))
    save('fresh-identities.json', identities)
    save('commands.json', [*compiles, link, execution])
    (OUT / 'machine.txt').write_text((ROOT / 'machine.txt').read_text())
    save('cleanup-mac.json', dict(root=str(ROOT),
         files=[a.identity(ROOT / 'ready-page'), a.identity(ROOT / 'ready-page.map')],
         retain=[row['object'] for row in identities], delete_executed=False))
    save('summary.json', dict(result='PASS', machine='Mac16,12 Apple M4 16GiB',
         compiled_hyle_owners=4, sdk_kernel_rebuild=False, source_replica=False,
         consumer='ready-page 64 1', run_command_index=rows.index(execution) + 1,
         link_command_index=rows.index(link) + 1,
         retained_baseline='ready-page-link-inputs.json; same fixed 105-owner cache',
         product_source_changes=False, current_sources=current,
         selected_objects='map-selected-owners.json', identities='fresh-identities.json',
         limits=['One original ready consumer; no new pending or platform matrix run',
                 'No performance measurement or new numerical tolerance']))
    print(json.dumps(json.loads((OUT / 'summary.json').read_text()), indent=2), flush=True)


if __name__ == '__main__':
    action, *args = sys.argv[1:]
    if action == 'compile':
        compile_one(*args)
    elif action == 'link':
        link()
    elif action == 'run':
        run()
    elif action == 'finish':
        finish()
    else:
        raise SystemExit(action)
