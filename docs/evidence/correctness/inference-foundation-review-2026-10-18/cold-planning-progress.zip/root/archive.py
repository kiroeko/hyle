from pathlib import Path
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18'
COLD = BASE / 'cold-placement-facts'
QWEN = BASE / 'qwen-progress-journey'
NORM = BASE / 'qwen-numerical-localization/norm-intermediates'
AIR = BASE / 'apple-page-invocation/cold-placement-check'
EVIDENCE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def checked(row):
    path = Path(row['path'])
    now = identity(path)
    assert now['bytes'] == row['bytes'] and now['sha256'] == row['sha256'], str(path)
    return now


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


cp = read(COLD / 'cleanup-manifest.json')
qp = read(QWEN / 'cleanup.json')
files = [checked(row) for row in cp['files'] + qp['files'] + read(NORM / 'cleanup-identities.json')['files']]
retain = [checked(row) for row in cp['retain'] + qp['retained_stage_objects'] + read(NORM / 'retained-object-identities.json')]
assert len(files) == 16 and len(retain) == 8
plan = dict(windows=dict(files=files, retain=retain), mac=read(AIR / 'cleanup-mac.json'))
write(OUT / 'cleanup-plan.json', plan)


def archive(target, files):
    if target.exists():
        with zipfile.ZipFile(target) as prior:
            assert 'archive-manifest.json' not in prior.namelist(), 'Do not overwrite frozen evidence'
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=False) as z:
        for name, path in sorted(files.items()):
            z.write(path, name)
        z.writestr('archive-manifest.json', json.dumps([
            dict(entry=name, **identity(path)) for name, path in sorted(files.items())], indent=2) + '\n')
    return identity(target)


extensions = {'.json', '.log', '.txt', '.xml', '.py', '.ps1', '.diff', '.cc', '.h', '.d', '.md'}
files = {}
for scope, label in [(COLD, 'cold'), (AIR, 'apple'), (OUT, 'root')]:
    for path in scope.rglob('*'):
        if path.is_file() and path.suffix in extensions and path.name not in {'archive-receipts.json', 'cleanup-result.json'}:
            files[label + '/' + path.relative_to(scope).as_posix()] = path
for name in read(QWEN / 'archive-files.json')['files'] + ['archive-files.json']:
    path = QWEN / name
    assert path.is_file()
    files['qwen/' + name] = path
extras = ['src/graph/executable.cc', 'tools/qwen35_text/main.cc', 'tools/qwen35_text/CMakeLists.txt',
          'tools/qwen35_text/README.md', 'docs/developer/current-work.md', 'docs/architecture/compute-design.md', 'test.ps1']
for name in extras:
    files['source/' + name] = ROOT / name
files['cleanup-plan.json'] = OUT / 'cleanup-plan.json'
architecture = archive(EVIDENCE / 'cold-planning-progress.zip', files)

files = {}
for path in NORM.rglob('*'):
    if path.is_file() and path.suffix in extensions | {'.cu', '.cuh', '.sass', '.f32', '.bf16', '.bin'}:
        files['experiment/' + path.relative_to(NORM).as_posix()] = path
for row in read(NORM / 'source-identities.json'):
    checked(row)
numerical = archive(EVIDENCE / 'qwen-norm-reduction.zip', files)
receipts = dict(architecture=architecture, numerical=numerical)
write(OUT / 'archive-receipts.json', receipts)
print(json.dumps(dict(archives=receipts, windows_files=16,
      windows_bytes=sum(row['bytes'] for row in plan['windows']['files']),
      retained_windows_objects=8, mac_files=len(plan['mac']['files']),
      mac_bytes=sum(row['bytes'] for row in plan['mac']['files']), retained_mac_objects=len(plan['mac']['retain']))))
