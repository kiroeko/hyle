from pathlib import Path
import importlib.util
import json
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
INPUT = ROOT / '.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
spec = importlib.util.spec_from_file_location('qwen_current_build', OUT / 'build.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
mode = sys.argv[1]
assert mode in {'direct', 'scheduler'}
trace = OUT / ('trace-' + mode)
assert not trace.exists(), 'Do not overwrite actual model results'
if mode == 'direct':
    runner.run_command('hardware', ['nvidia-smi', '--query-gpu=name,compute_cap,driver_version,memory.total', '--format=csv'])
runner.run_command('full-text-' + mode, [str(OUT / 'qwen35-progress.exe'), '--inputs', str(INPUT),
    '--continuation', str(INPUT / 'continuation.ids'), '--steps', '2', '--capacity', '32',
    '--trace', str(trace), '--progress', mode])
