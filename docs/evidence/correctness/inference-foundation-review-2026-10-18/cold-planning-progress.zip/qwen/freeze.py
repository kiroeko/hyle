"""Freeze existing results only; never compile, link, launch, or delete."""
from pathlib import Path
import hashlib
import json
import re
import shutil

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(4*1024*1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def check(expected):
    assert identity(expected['path']) == expected, expected['path']


history = read(OUT/'commands.json')
link = next(row for row in history if row['tag'] == 'qwen-link')
assert link['exit'] == 0
runs = {mode: next(row for row in reversed(history)
                  if row['tag'] == 'full-text-'+mode and row['exit'] == 0)
        for mode in ['direct', 'scheduler']}
loader = next(row for row in history if row['tag'] == 'full-text-direct' and row['exit'] != 0)
assert loader['exit'] == 0xC0000135
plan = read(OUT/'link-plan.json')
assert not plan['pending_root_sources']
for row in plan['source_objects']:
    check(row['source'])
    check(row['object'])
for row in plan['checked_headers']:
    check(row)
for row in read(OUT/'link-input-identities.json'):
    check(row)
fresh = read(OUT/'fresh-identities.json')
assert len(fresh) == 2
for row in fresh:
    check(row['source'])
    check(row['object'])

# Keep the current application source, not another SDK/source-tree copy.
for path in ['tools/qwen35_text/main.cc', 'tools/qwen35_text/CMakeLists.txt',
             'tools/qwen35_text/README.md', 'src/graph_route_cuda/cuda_context.cc']:
    destination = OUT/'source'/path
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT/path, destination)
save('source-identities.json', [identity(ROOT/path) for path in
     ['tools/qwen35_text/main.cc', 'tools/qwen35_text/CMakeLists.txt', 'tools/qwen35_text/README.md',
      'src/graph_route_cuda/cuda_context.cc']])
save('retained-object-identities.json', [row['object'] for row in fresh])

mapping = (OUT/'qwen35-progress.map').read_text(errors='replace')
definitions = [line.strip() for line in mapping.splitlines()
               if re.match(r'\s+[0-9a-fA-F]{4}:[0-9a-fA-F]{8}\s+\?', line)
               and ' f ' in line]
expected = {
    'ordinary_graph_compile': ('?compile_with_adapters@detail@graph@hyle@@', 'graph-executable.obj'),
    'original_invocation_factory': ('?create_invocation@Executable@graph@hyle@@', 'graph-executable.obj'),
    'optional_progress': ('?prepare_progress@graph@hyle@@', 'graph_progress--progress.obj'),
    'common_cursor': ('?claim_ready@SubmissionCursor@detail@graph@hyle@@', 'submission.obj'),
    'common_retirement': ('?retire@InvocationAccess@detail@graph@hyle@@', 'submission.obj'),
    'batch_prepare': ('?prepare@batch@graph@hyle@@', 'batch.obj'),
    'cuda_graph_factory': ('?create_context@cuda@graph@hyle@@', 'graph-cuda-context.obj'),
    'cuda_graph_compile': ('?compile@cuda@graph@hyle@@', 'graph-cuda-context.obj'),
    'actual_ggml_carrier': ('?compile@internal@ggml_cuda@compute@hyle@@',
                            'compute_provider_ggml_cuda--ggml_cuda_provider.obj'),
}
owners = {}
for key, (prefix, owner) in expected.items():
    rows = [line for line in definitions if line.split()[1].startswith(prefix)]
    assert rows and all(line.endswith(owner) for line in rows), (key, rows)
    owners[key] = dict(expected_owner=owner, definitions=rows)
for prohibited in ['hyle_graph_route_cpu_cuda', 'hyle_graph_route_cpu_vulkan',
                   'hyle_graph_route_cpu_apple', '@cpu_cuda@graph@hyle@@',
                   '@cpu_vulkan@graph@hyle@@', '@cpu_apple@graph@hyle@@']:
    assert prohibited.lower() not in mapping.lower(), prohibited
assert not any(Path(path).name.lower() in {'hyle_graph.lib', 'hyle_graph_batch.lib'}
               for path in plan['libraries'])
save('map-owners.json', dict(map=identity(OUT/'qwen35-progress.map'), owners=owners,
    objects=len(plan['objects']), current_common_sources=len(plan['common_sources']),
    stale_graph_archives_linked=False, legacy_hybrid_runtime_selected=False,
    cpu_vulkan_math_added=False,
    note='Original CUDA Torch backend still uses its existing torch_cpu DLL dependency; no CPU Provider roster is added.'))

prior = read(OUT/'direct-vs-prior.json')
parity = read(OUT/'progress-parity.json')
assert len(prior) == len(parity['tensors']) == 150
assert all(row['prior_equal'] for row in prior) and parity['all_equal']
traces = []
for row in parity['tensors']:
    assert row['scheduler_equal']
    direct = identity(OUT/'trace-direct'/row['path'])
    scheduler = identity(OUT/'trace-scheduler'/row['path'])
    assert direct['bytes'] == scheduler['bytes'] == row['bytes']
    assert direct['sha256'] == scheduler['sha256'] == row['sha256']
    traces.append(dict(relative_path=row['path'], bytes=direct['bytes'], sha256=direct['sha256']))
save('local-trace-identities.json', dict(roots=[str(OUT/'trace-direct'), str(OUT/'trace-scheduler')],
    files_per_run=len(traces), files=traces, archive_raw_traces=False,
    instruction='Retain raw traces locally. Archive identities and comparison metadata only.'))

phase_pattern = re.compile(r'^(prefill|continuation|decode\d+) tokens=(\d+) visible=(\d+) '
    r'seconds=([\d.e+-]+) submit_seconds=([\d.e+-]+) progress=(\w+) next=(\d+)$', re.M)
results = {}
for mode, row in runs.items():
    output = read(OUT/row['stdout'])
    stderr = (OUT/row['stderr']).read_text()
    phases = [dict(name=m[0], tokens=int(m[1]), visible_tokens=int(m[2]),
                   seconds=float(m[3]), submit_seconds=float(m[4]),
                   mode=m[5], next_id=int(m[6])) for m in phase_pattern.findall(stderr)]
    assert [p['tokens'] for p in phases] == [23, 4, 1]
    assert [p['next_id'] for p in phases] == [20, 248046, 198]
    routes = re.findall(r'compiled T=(\d+) steps=(\d+) workspace/slot=(\d+)', stderr)
    assert [(int(t), int(steps)) for t, steps, _ in routes] == [(23, 1252), (4, 1252), (1, 1252)]
    results[mode] = dict(command=row, stdout=identity(OUT/row['stdout']),
        stderr=identity(OUT/row['stderr']), result=output, phases=phases,
        cold_routes=[dict(tokens=int(t), steps=int(steps), workspace_bytes_per_slot=int(work))
                     for t, steps, work in routes])
assert results['direct']['result'] == results['scheduler']['result']
save('run-identities.json', results)

images = [identity(OUT/('qwen35-progress'+extension)) for extension in ['.exe', '.map', '.exp', '.lib']]
save('cleanup.json', dict(root=str(OUT), files=images,
     retained_stage_objects=[row['object'] for row in fresh]))
summary = dict(result='PASS: execution equivalence only',
    hardware=identity(OUT/'006-hardware.stdout.log'),
    fresh_host_translation_units=[row['source'] for row in fresh],
    compiled_with='/W4 /WX; 2 Hyle/application host TUs only',
    root_current_executable=read(OUT/'executable-receipt.json'),
    closure=dict(objects=len(plan['objects']), current_common_sources=len(plan['common_sources']),
                 cached_cuda_metadata_hosts=20, numerical_objects_rebuilt=0,
                 sdk_rebuilt=False, optional_progress_is_original_cursor=True),
    successful_runs={mode: results[mode]['command']['tag'] for mode in results},
    model=dict(layers=24, nodes_per_phase=1938, steps_per_phase=1252,
               phases=[23, 4, 1], visible_tokens=[23, 27, 28], next_ids=[20, 248046, 198],
               resident_weight_tensors=320, resident_weight_bytes=3763655360),
    comparisons=dict(current_direct_vs_prior_exact=150, scheduler_vs_current_direct_exact=150),
    failure=dict(kind='runner environment DLL loader failure before main',
                 code='0xC0000135', original_command=loader,
                 absent_original_sdk_dlls=['c10_cuda.dll', 'torch_cuda.dll'],
                 correction='Use frozen link command SDK library directories in runtime PATH; no copied DLL, product change, recompilation, or relink.'),
    limits=['One traced complete journey per mode; times are not a throughput benchmark or performance acceptance.',
            'Existing approximately 2% logits L2 difference versus independent numerical reference remains unaccepted.',
            'Each phase and slot executes sequentially over shared tokens/output/KV/recurrent state. Two slots do not prove concurrent evaluate safety.',
            'Independent finite families, cross-phase artifact sharing, full-model numerical acceptance, and fair tokens/s comparison remain separate work.'],
    storage=dict(raw_traces_retained_locally=True, archive_includes_raw_traces=False,
                 archive_includes_sdk_weights_objects_binaries=False,
                 exact_cleanup_manifest='cleanup.json', deletion_performed=False))
save('summary.json', summary)
closure = read(OUT/'closure-summary.json')
closure.update(compiled=True, linked=True, executed=True, successful_model_modes=['direct', 'scheduler'],
               status_evidence='commands.json: 001/002 compile, 003 link, 007/008 model runs',
               numerical_acceptance=False, throughput_acceptance=False)
save('closure-summary.json', closure)
(OUT/'summary.md').write_text(
    '# Qwen optional progress journey\n\n'
    'The same current 24-layer CUDA consumer completed T23 prefill → T4 continuation → T1 decode '
    'in direct and optional Scheduler modes. Each phase has 1,938 nodes / 1,252 compiled steps; '
    'the original 320 resident tensors occupy 3,763,655,360 bytes. Next IDs were 20 → 248046 → 198. '
    'Current direct vs prior and Scheduler vs current direct each match **150/150 trace files exactly**.\n\n'
    'Only the consumer and Graph CUDA Context host TUs were newly compiled here with /W4 /WX. '
    'The link uses the root’s current cold-placement Graph executable owner, 32 current common owners '
    'and matching cached CUDA Provider16/Region26 host objects, original numerical kernels and SDKs. '
    'The map confirms original Graph/Invocation/SubmissionCursor/progress/batch owners; '
    'no legacy hybrid runtime, CPU Provider roster, or Vulkan math was added.\n\n'
    'The first model launch (005) failed before main with 0xC0000135: runtime PATH had been built '
    'from model argv, which has no .lib paths, so c10_cuda.dll and torch_cuda.dll were absent. '
    'The runner now derives SDK directories from the actual frozen link command. Original failure, '
    'dumpbin dependency logs and exact environment patch are retained; no DLL was copied or rebuilt. '
    'Successful direct and Scheduler launches are 007 and 008.\n\n'
    'This is one traced journey per mode, not a throughput benchmark or numerical acceptance. '
    'The roughly 2% independent-reference logits L2 discrepancy remains unaccepted. Slots still '
    'execute sequentially over shared input/output/KV/recurrent state; this does not prove concurrent '
    'evaluate safety. Raw traces remain local; the archive keeps only identities/comparisons, source, '
    'commands and logs. cleanup.json lists exactly four rebuildable image/map/export files; '
    'both fresh objects and all previous caches are retained. No deletion was performed.\n', encoding='utf-8')

# Explicit small-file selection for the parent archive; never traverse raw
# traces, numerical caches, SDKs, weights, objects or the 33MB linker map.
archive = [str(path.relative_to(OUT)) for path in sorted(OUT.iterdir())
           if path.is_file() and path.suffix.lower() in {'.json', '.py', '.log', '.diff', '.md'}
           and path.name != 'archive-files.json']
archive += [str(path.relative_to(OUT)) for path in sorted((OUT/'source').rglob('*')) if path.is_file()]
save('archive-files.json', dict(root=str(OUT), files=archive,
     exclusions=['trace-direct/**', 'trace-scheduler/**', '*.obj', '*.exe', '*.map', '*.exp', '*.lib', 'SDKs', 'weights'],
     include_this_manifest=True))
print(json.dumps(dict(summary=identity(OUT/'summary.json'), map_owners=identity(OUT/'map-owners.json'),
                     archive_files=len(archive), cleanup=images), indent=2))
