"""Narrow current-Qwen host assembly. No SDK/kernel build or model launcher.

Plan is read-only apart from this evidence directory. Compile/link are explicit
actions for the parent after its consumer/core source freeze; the parent alone
executes and cleans up the two actual model journeys.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
QWEN = ARCH / 'generic-progress/qwen'
MATCHED = ARCH / 'retire-native-runtime/paging-risks'
META = ARCH / 'native-runtime-retirement/metadata-oom-review'
PROBE = ARCH / 'qwen-numerical-localization/actual-f32-probe'
SERVICE = ARCH / 'optional-file-stream'
ADMITTED = ARCH / 'admitted-queue-sequence/cuda'
COMMON_PREFIXES = ('src/compute/', 'src/compute_ops/', 'src/compute_batch/',
                   'src/graph/', 'src/graph_batch/', 'src/graph_progress/')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def source_path(source):
    path = Path(source)
    return path if path.is_absolute() else ROOT / path


def source_key(source):
    return source_path(source).relative_to(ROOT).as_posix()


def asserted_identity(expected):
    actual = identity(expected['path'])
    assert actual == expected, ('cached file changed', expected, actual)
    return actual


def source_matches(source, expected_sha):
    actual = identity(source_path(source))
    assert actual['sha256'] == expected_sha, ('source differs', source)
    return actual


def normalized_recipe(command, source, output):
    result = []
    reference = ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows/include'
    for value in command:
        low = value.lower()
        if low.startswith(('/fo', '/fd')):
            continue
        if low.endswith('.cc'):
            value = str(ROOT / source)
        elif low.startswith(('/external:i', '/i')) and 'source-4e1a7b2f39afe15d' in low:
            value = ('/external:I' if low.startswith('/external:i') else '/I') + str(reference)
        result.append(value)
    result += ['/Fo' + str(output)]
    assert '/WX' in result and '/W4' in result
    assert not any('source-4e1a7b2f39afe15d' in value for value in result)
    return result


def recipes():
    previous = read(QWEN / 'compile-recipes.json')
    admitted = read(ADMITTED / 'compile-recipes.json')
    wanted = [('consumer', 'tools/qwen35_text/main.cc',
               next(row['command'] for row in previous if row['tag'] == 'consumer')),
              ('graph-cuda-context', 'src/graph_route_cuda/cuda_context.cc',
               next(row['command'] for row in admitted
                    if row['source'] == 'src/graph_route_cuda/cuda_context.cc'))]
    return [dict(tag=tag, source=identity(ROOT / source),
                 output=str(OUT / (tag + '.obj')),
                 command=normalized_recipe(command, source, OUT / (tag + '.obj')))
            for tag, source, command in wanted]


def plan(executable_receipt=None):
    old = read(QWEN / 'link-plan.json')['command']
    matched = read(MATCHED / 'matched-link-base.json')
    objects, selected, pending = [], [], []

    # Current common source/ABI closure only: no CPU/Vulkan mathematics comes
    # from the large CPU validation executable whose receipts supply these.
    header_rows = read(MATCHED / 'final-header-identities.json')
    checked_headers = [asserted_identity(row) for row in header_rows
                       if '/tests/' not in row['path'].replace('\\', '/')]
    by_object = {row['path']: row for row in matched['objects']}
    corrected = read(SERVICE / 'cuda/summary.json')['corrected_source']
    for source, obj in matched['selected_sources'].items():
        if not source.startswith(COMMON_PREFIXES):
            continue
        if source == 'src/graph/executable.cc':
            if executable_receipt:
                receipt = read(executable_receipt)
                asserted_identity(receipt['source'])
                assert source_key(receipt['source']['path']) == source
                asserted_identity(receipt['object'])
                obj = receipt['object']['path']
                record = dict(source=receipt['source'], object=receipt['object'],
                              origin=str(executable_receipt))
            else:
                obj = str(OUT / 'root-executable-pending.obj')
                record = dict(source=identity(ROOT/source), object=dict(path=obj),
                              origin='root cold-placement-facts owner: not yet provided')
                pending.append(source)
        elif source == 'src/compute/batch_transfer.cc':
            asserted_identity(corrected['source'])
            asserted_identity(corrected['object'])
            obj = corrected['object']['path']
            record = dict(source=corrected['source'], object=corrected['object'],
                          origin=str(SERVICE / 'cuda/summary.json'))
        else:
            src = source_matches(source, matched['compiled_source_sha256'][source])
            record = dict(source=src, object=asserted_identity(by_object[obj]),
                          origin=str(MATCHED / 'matched-link-base.json'))
        selected.append(record)
        objects.append(obj)

    # Keep original numeric kernels/ggml caches, not the old Graph private ABI.
    numerical_markers = ('/windows-batch/', '/cccl-device-gather/',
                         '/b-cuda-d5/src/compute_provider_cuda/', '/cuda-device-indices/',
                         '/cuda-ragged-mla/', '/cuda-paged-indexer/',
                         '/generic-progress/ggml-cache/')
    numeric = [value for value in old if value.lower().endswith('.obj') and
               any(marker in value.replace('\\', '/').lower() for marker in numerical_markers)]
    objects.extend(numeric)

    # Provider16/current owned Operation host objects, including Graph's CUDA
    # region carrier (Region26). The metadata check already compiled all 20.
    metadata = read(META / 'commands.json')
    for row in metadata:
        assert row['exit'] == 0
        asserted_identity(row['source'])
        objects.append(asserted_identity(row['object'])['path'])
        selected.append(dict(source=row['source'], object=row['object'], origin=str(META / 'commands.json')))

    for row in read(PROBE / 'fresh-object-identities.json'):
        if not str(row['source']).replace('\\', '/').startswith(str(ROOT).replace('\\', '/') + '/src/'):
            continue
        src = source_matches(row['source'], row['source_sha256'])
        objects.append(asserted_identity(row['object'])['path'])
        selected.append(dict(source=src, object=row['object'], origin=str(PROBE / 'fresh-object-identities.json')))
    for row in read(ADMITTED / 'compile-status.json'):
        if not row['source'].startswith('src/compute_backend_cuda/'):
            continue
        src = source_matches(row['source'], row['sha256'])
        obj = identity(row['object'])
        assert obj['sha256'] == row['object_sha256']
        objects.append(obj['path'])
        selected.append(dict(source=src, object=obj, origin=str(ADMITTED / 'compile-status.json')))

    # Match the existing actual-f32 probe's private/provider header identities.
    for row in read(PROBE / 'source-identities.json'):
        normalized = row['path'].replace('\\', '/')
        if normalized.endswith(('.h', '.cuh')):
            checked_headers.append(asserted_identity(row))

    compile_rows = recipes()
    for row in compile_rows:
        objects.append(row['output'])
    # The actual current BlockingPool implementation was reused by the current
    # Graph/frontier checks. No CPU provider or IO object is needed here.
    blocking = ROOT / '.scratch/perf-review-2026-10-18/blocking-pool/candidate.obj'
    objects.append(str(blocking))

    old_flags = [v for v in old[1:] if not v.lower().endswith(('.obj', '.lib'))
                 and not v.upper().startswith(('/OUT:', '/MAP:'))]
    libraries = [v for v in old if v.lower().endswith('.lib') and Path(v).name.lower()
                 not in {'hyle_graph.lib', 'hyle_graph_batch.lib'}]
    current = read(ARCH / 'cpu-context-assembly/link-plan.json')['command']
    libraries += [v for v in current if Path(v).name.lower() in {'hyle_sched.lib', 'hyle_mem_vm.lib'}]
    objects, libraries = list(dict.fromkeys(objects)), list(dict.fromkeys(libraries))
    assert not any(any(marker in value.replace('\\', '/').lower() for marker in
                       ['/compute_provider_native/', 'compute_provider_native--',
                        'compute_provider_ggml--', 'compute_provider_onednn',
                        'graph_route_cpu_', 'compute_route_vulkan', 'graph_route_vulkan'])
                   for value in objects)
    command = [old[0], *old_flags, *objects, *libraries,
               '/OUT:' + str(OUT / 'qwen35-progress.exe'), '/MAP:' + str(OUT / 'qwen35-progress.map')]
    cached = [identity(v) for v in objects + libraries if Path(v).is_file()]
    result = dict(command=command, common_sources=[r['source']['path'] for r in selected
                  if source_key(r['source']['path']).startswith(COMMON_PREFIXES)],
                  source_objects=selected, objects=objects, libraries=libraries,
                  native_numeric_objects=numeric, pending_root_sources=pending,
                  compile_recipes=compile_rows, checked_headers=checked_headers,
                  cached_files=cached, origin=str(QWEN/'link-plan.json'),
                  rule='Only plan until root source freeze. No IO/CPU/Vulkan provider, legacy runtime, SDK build, numerical kernel build, or model run.')
    save('link-plan.json', result)
    save('compile-recipes.json', compile_rows)
    save('closure-summary.json', dict(objects=len(objects), common=len(result['common_sources']),
        numerical_objects=len(numeric), cuda_metadata_hosts=len(metadata),
        fresh_host_sources=[r['source']['path'] for r in compile_rows],
        pending_root_sources=pending, compiled=False, linked=False, executed=False))
    return result


def environment(command):
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    from hyle_support import read_cache
    env = windows_compiler_environment(read_cache(ROOT / '.scratch/build-compute-v2-dev'))
    env['VSLANG'] = '1033'
    directories = [str(Path(v).parent) for v in command if v.lower().endswith('.lib') and Path(v).is_absolute()]
    directories += ['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64',
                    'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',
                    str(ROOT/'.scratch/build-compute-v2-dev/bin')]
    env['PATH'] = os.pathsep.join(dict.fromkeys(directories)) + os.pathsep + env['PATH']
    return env


def run_command(tag, command):
    rows = read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
    stem = f'{len(rows)+1:03d}-{tag}'
    row = dict(tag=tag, command=command, exit=None, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    rows.append(row)
    save('commands.json', rows)
    start = time.monotonic()
    with (OUT/row['stdout']).open('wb') as out, (OUT/row['stderr']).open('wb') as err:
        process = subprocess.run(command, cwd=ROOT, env=environment(command), stdout=out, stderr=err, timeout=180)
    row.update(exit=process.returncode, seconds=time.monotonic()-start)
    save('commands.json', rows)
    print(stem, process.returncode, flush=True)
    if process.returncode:
        print((OUT/row['stdout']).read_text(errors='replace')[-10000:])
        print((OUT/row['stderr']).read_text(errors='replace')[-10000:])
        raise SystemExit(process.returncode)


def compile_hosts():
    rows = []
    for recipe in recipes():
        snapshot = OUT/'source'/source_key(recipe['source']['path'])
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(Path(recipe['source']['path']).read_bytes())
        run_command(recipe['tag']+'-compile', recipe['command'])
        asserted_identity(recipe['source'])
        rows.append(dict(source=recipe['source'], object=identity(recipe['output']), command=recipe['command']))
        save('fresh-identities.json', rows)


def link(executable_receipt):
    if not executable_receipt:
        raise SystemExit('Supply root final executable source/object receipt; no stale core fallback.')
    result = plan(executable_receipt)
    for row in read(OUT/'fresh-identities.json'):
        asserted_identity(row['source'])
        asserted_identity(row['object'])
    for value in result['objects']:
        assert Path(value).is_file(), value
    save('link-input-identities.json', [identity(v) for v in result['command']
         if Path(v).is_file() and Path(v).suffix.lower() in {'.obj', '.lib'}])
    run_command('qwen-link', result['command'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['plan', 'compile', 'link'])
    parser.add_argument('--executable-receipt', type=Path)
    args = parser.parse_args()
    if args.action == 'plan':
        plan(args.executable_receipt)
        print((OUT/'closure-summary.json').read_text())
    elif args.action == 'compile':
        compile_hosts()
    else:
        link(args.executable_receipt)
