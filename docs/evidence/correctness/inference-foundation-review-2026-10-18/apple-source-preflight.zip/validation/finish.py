from pathlib import Path
import importlib.util, json, shutil, sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner',OUT/'run.py')
run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
TAGS=['002-new-test','006-context','007-copy-program','008-leased',
      '009-materialized','010-page-region','011-region']
code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root'])
def identity(path):
 q=Path(path);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
compiled=[];retained=[]
for tag in p['tags']:
 row=json.loads((r/(tag+'.result.json')).read_text());assert row['exit']==0
 assert row['source_before']==row['source_after']
 for item in row['outputs']:
  assert identity(item['path'])==item
  if item['path'].endswith('.o'):retained.append(item)
 compiled.append(row)
assert len(retained)==7
links={tag:json.loads((r/(tag+'.result.json')).read_text()) for tag in ['003-old-link','012-current-link','014-native-link']}
selected=[];leased_members={}
for tag,row in links.items():
 assert row['exit']==0
 for item in row['inputs_before']+row['outputs']:assert identity(item['path'])==item
 text=Path(row['outputs'][1]['path']).read_text().split('# Object files:\n',1)[1].split('# Sections:',1)[0]
 leased_members[tag]=[line for line in text.splitlines() if 'apple_leased_invocation' in line]
 for entry in compiled:
  if tag=='003-old-link' and entry['tag']!='002-new-test':continue
  if tag=='014-native-link' and entry['tag']=='002-new-test':continue
  obj=next(x for x in entry['outputs'] if x['path'].endswith('.o'))
  found=[line for line in text.splitlines() if line.endswith(obj['path'])];assert len(found)==1,(tag,obj,found)
  selected.append(dict(link=tag,source=entry['source_before'],object=obj,map_entry=found[0]))
 if tag!='003-old-link':
  assert len(leased_members[tag])==1,leased_members[tag]
  assert '008-leased-src--' in leased_members[tag][0],leased_members[tag]
 else:
  assert all('/apple-source-preflight/validation/' not in x['path'] for x in row['inputs_before'] if x['path'].endswith('.o') and x['path']!=retained[0]['path'])
save('selected-current-owners.json',selected)
save('leased-symbol-owner-map.json',leased_members)
for item in p['baseline_retained']+p['math']:assert identity(item['path'])==item
assert (r/'mlx.metallib').resolve()==Path(p['math'][0]['path']).resolve()
for tag in ['004-old-run','013-current-run','015-native-run']:
 row=json.loads((r/(tag+'.result.json')).read_text());assert row['terminal']
 assert row['exit']==(1 if tag=='004-old-run' else 0)
 ps=subprocess.run(['ps','-p',str(row['pid']),'-o','command='],capture_output=True,text=True)
 assert ps.returncode!=0 or str(r) not in ps.stdout
cleanup=dict(host='kiro@172.22.10.198',root=str(r),files=[x for row in links.values() for x in row['outputs']],
 retain=retained,retain_previous_stage=p['baseline_retained'])
assert len({x['path'] for x in cleanup['files']})==6
assert not {x['path'] for x in cleanup['files']} & {x['path'] for x in retained+p['baseline_retained']}
save('cleanup-mac.json',cleanup)
save('final-link-input-identities.json',{tag:row['inputs_before'] for tag,row in links.items()})
result=dict(current_gtests=19,current_exit=0,native_exit=0,old_tests=2,old_failed=2,
 live_process=False,retained_stage_objects=len(retained),retained_previous_stage_objects=len(p['baseline_retained']),
 selected_owner_rows=len(selected),link_inputs={tag:len(row['inputs_before']) for tag,row in links.items()},
 cleanup_files=6,cleanup_bytes=sum(x['bytes'] for x in cleanup['files']),math=p['math'])
save('final-verification.json',result);print(json.dumps(result))
'''
baseline=json.loads((OUT/'baseline-identities.json').read_text())
result=run.prior.air.ssh(code,json.dumps(dict(root=run.REMOTE,tags=TAGS,
    baseline_retained=baseline['retained'],math=baseline['math'])).encode(),timeout=45)
(OUT/'016-verify.stdout.log').write_bytes(result.stdout)
(OUT/'016-verify.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0
run.prior.collect()

def read(name):return json.loads((OUT/'results'/name).read_text())
sources={}
for name in ['001-new-test-sources.json','005-final-products-sources.json']:
    for row in json.loads((OUT/name).read_text()):sources[row['path']]=row
for path,row in sources.items():
    assert run.prior.identify(run.ROOT/path)==row,(path,'current source drift')
    dest=OUT/'final-source'/path;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(run.ROOT/path,dest)
dependencies={};unmapped=[]
for tag in TAGS:
    for row in read(tag+'.result.json')['dependencies']:
        assert row['path'].startswith(run.REMOTE+'/'),row
        logical=row['path'][len(run.REMOTE)+1:]
        if logical not in sources:unmapped.append(row);continue
        actual=sources[logical]
        assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),(tag,row,actual)
        dependencies[logical]=actual
assert not unmapped,unmapped
run.save('final-source-identities.json',list(sources.values()))
run.save('dependency-check.json',dict(matched_current=len(dependencies),drift=[],unmapped=[]))
shutil.copyfile(OUT/'results/cleanup-mac.json',OUT/'cleanup-mac.json')
old=read('004-old-run-tests.json');assert old['tests']==2 and old['failures']==2
current=read('013-current-run-tests.json');assert current['tests']==19 and current['failures']==0
verified=read('final-verification.json')
summary=dict(status='old_two_fail_current_19_and_original_native_pending_pass',hardware=baseline['hardware'],
 old_control=dict(link='003-old-link',run='004-old-run',tests=2,passed=0,failed=2,
  product_provenance='baseline-links.json and previous frozen-source proof; no new product objects',
  reason='outer source Cancelled masked original native decoder success in both cases'),
 current=dict(link='012-current-link',run='013-current-run',tests=19,passed=19,failed=0,
  new_cases=['LateCancelledWritingPhaseMustFailNativeDecoder','SuccessfulIndependentLatestPhaseCannotMaskFailedPageSource'],
  assertions=['native decoder returns Cancelled and has no result','outer Graph Cancelled and no published output',
              'Runtime remains unpoisoned','original Update controls recover after actual retirement']),
 native=dict(link='014-native-link',run='015-native-run',exit=0,
  checks=['F16 and BF16 each 64 steps','active Q2/18 and two slots each','two page nodes share one Update',
          'CPU Abs/Cast to native to Cast/Neg','exact pages, untouched history, same generation','196608 dirty bytes each dtype']),
 fresh_product_host_tus=6,fresh_test_tus=1,retained_prior_objects=12,
 actual_current_link_inputs=verified['link_inputs'],selected_owners='results/selected-current-owners.json',
 leased_symbol_owner='008-leased explicit object; old SDK member not selected in current links',
 no_sdk_air_metallib_build=True,retained_original_mlx_math=baseline['math'],
 source_count=len(sources),dependency_count=len(dependencies),source_drift=[],
 cleanup=dict(manifest='cleanup-mac.json',files=6,bytes=verified['cleanup_bytes']),
 retained_stage_objects=7,live_process=False,
 not_claimed=['Direct materialized late-source-failure injection coverage',
              'all possible failure races or cancellation interleavings','performance improvement or zero warm allocations'])
run.save('summary.json',summary)
run.save('runner-source-identities.json',[run.prior.identify(OUT/'run.py'),run.prior.identify(OUT/'finish.py'),
    run.prior.identify(run.BASE/'run.py'),run.prior.identify(run.BASE.parents[1]/'apple-row-projection/validation/run.py'),
    run.prior.identify(run.BASE.parents[1]/'apple-page-invocation/air.py')])
run.save('receipt.json',{key:run.prior.identify(OUT/name) for key,name in
    [('summary','summary.json'),('cleanup','cleanup-mac.json'),('sources','final-source-identities.json'),
     ('dependencies','dependency-check.json'),('baseline_source_proof','baseline-source-proof.json')]})
print(json.dumps(summary,indent=2))
