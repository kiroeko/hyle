from pathlib import Path
import importlib.util, json, shlex, sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = OUT.parents[1] / 'apple-row-pending/validation'
spec = importlib.util.spec_from_file_location('green_air', BASE / 'run.py')
green = importlib.util.module_from_spec(spec); spec.loader.exec_module(green)
prior = green.prior
AIR_BASE = green.AIR_BASE
REMOTE = AIR_BASE + '/apple-source-preflight/validation'
prior.OUT = OUT; prior.REMOTE = REMOTE
TEST = 'tests/graph_route_apple/row_cache_pending_projection_test.cc'
PRODUCTS = [
    'src/compute_route_apple/apple_context.cc',
    'src/compute_route_apple/apple_copy_program.cc',
    'src/compute_route_apple/apple_leased_invocation.cc',
    'src/compute_route_apple/apple_materialized_invocation.cc',
    'src/graph_route_apple/native_paged_region.cc',
    'src/graph_route_apple/native_region.cc',
]


def save(name, value): prior.save(name, value)


def inventory():
    links = {name: json.loads((BASE / ('results/' + tag + '.result.json')).read_text())
             for name, tag in [('gtest', '018-current-link'), ('native', '020-native-link')]}
    retained = json.loads((BASE / 'cleanup-mac.json').read_text())['retain']
    math = json.loads((BASE / 'baseline-identities.json').read_text())['math']
    owners = json.loads((BASE / 'baseline-objects.json').read_text())
    owners.update(json.loads((BASE / 'objects.json').read_text()))
    proof = {name: prior.identify(BASE / name) for name in
             ['receipt.json', 'summary.json', 'final-source-identities.json', 'dependency-check.json']}
    frozen = json.loads((BASE / 'final-source-identities.json').read_text())
    for row in frozen:
        got = prior.identify(BASE / 'final-source' / row['path'])
        assert (got['bytes'], got['sha256']) == (row['bytes'], row['sha256'])
    save('baseline-source-proof.json', dict(
        source='previous frozen source snapshots, never current product source',
        stage=str(BASE.relative_to(ROOT)).replace('\\', '/'), files=proof, sources=frozen))
    save('baseline-links.json', {key: dict(argv=row['argv'], inputs=row['inputs_before'])
                                 for key, row in links.items()})
    save('baseline-objects.json', owners)
    recipes = {}
    for source, tag in [(TEST, '002-control-test'), (PRODUCTS[0], '006-context'),
                        (PRODUCTS[4], '012-page-region'), (PRODUCTS[5], '011-region')]:
        record = BASE / 'results' / (tag + '.command.json')
        recipes[source] = dict(argv=json.loads(record.read_text())['argv'],
                               record=str(record.relative_to(ROOT)).replace('\\', '/'))
    code = r'''
from pathlib import Path
import hashlib,json,shlex,subprocess,sys
p=json.loads(sys.stdin.buffer.read());r=Path(p['root']);r.mkdir(parents=True,exist_ok=True)
def identity(q):
 q=Path(q);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest())
all_inputs={x['path']:x for rows in p['links'].values() for x in rows}
for row in list(all_inputs.values())+p['retained']+p['math']:
 assert identity(row['path'])==row,(row,identity(row['path']))
history=json.loads((Path(p['base'])/'commands.json').read_text())
recipes={}
for source in p['sources']:
 rows=[x for x in history if x.get('exit')==0 and x['tag'].endswith('-compile') and any(str(v).endswith('/'+source) for v in x.get('command',[]))]
 if rows:recipes[source]=dict(argv=rows[-1]['command'],record=str(Path(p['base'])/'commands.json'),record_tag=rows[-1]['tag'])
 else:
  db=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/compile_commands.json')
  found=[x for x in json.loads(db.read_text()) if x['file'].endswith('/'+source)];assert len(found)==1,(source,found)
  argv=shlex.split(found[0]['command']);argv[1:1]=['-DHYLE_STATIC','-Werror']
  recipes[source]=dict(argv=argv,record=str(db),entry=found[0],reason='exact cached module command; strict static overlay flags')
archive=next(x['path'] for x in all_inputs.values() if x['path'].endswith('/libhyle_compute_route_apple.a'))
members=subprocess.check_output(['ar','-t',archive],text=True).splitlines()
member=next(x for x in members if 'apple_leased_invocation' in x)
blob=subprocess.check_output(['ar','-p',archive,member])
old_leased=dict(archive=identity(archive),member=member,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),
 source_provenance='cached SDK member; no current canonical source is asserted to be its compile source')
hardware={k:subprocess.check_output(v,text=True).strip() for k,v in {
 'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],
 'memory':['sysctl','-n','hw.memsize'],'system':['sw_vers'],'compiler':['/usr/bin/clang++','--version']}.items()}
assert hardware['model']=='Mac16,12'
result=dict(hardware=hardware,matched_unique_inputs=len(all_inputs),link_counts={k:len(v) for k,v in p['links'].items()},
 retained=p['retained'],math=p['math'],old_leased=old_leased,recipes=recipes,compiled=0,tests_run=0)
(r/'baseline-identities.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
    payload=dict(root=REMOTE,base=AIR_BASE,links={key:row['inputs_before'] for key,row in links.items()},
                 retained=retained,math=math,sources=PRODUCTS[1:4])
    result=prior.air.ssh(code,json.dumps(payload).encode(),timeout=45)
    (OUT/'000-inventory.stdout.log').write_bytes(result.stdout)
    (OUT/'000-inventory.stderr.log').write_bytes(result.stderr)
    assert result.returncode==0,result.stderr
    data=json.loads(result.stdout);save('baseline-identities.json',data)
    recipes.update(data['recipes']);save('recipes.json',recipes)
    save('preparation-summary.json',dict(status='inventoried_waiting_for_test_and_product_freeze',
        hardware=data['hardware'],baseline=data['link_counts'],preserved_stage_objects=len(retained),
        fresh_product_sources=PRODUCTS,new_test_source=TEST,old_leased=data['old_leased'],
        planned_runs=['old products: only two new source-cancel tests','current products: original 17 plus two new tests','original native pending F16/BF16 64 steps'],
        no_sdk_air_metallib_build=True,compiled=0,tests_run=0))
    print(json.dumps(dict(hardware=data['hardware'],baseline=data['link_counts'],retained=len(retained),recipes=len(recipes),compiled=0,tests_run=0)))


def compile_source(tag,source):
    recipes=json.loads((OUT/'recipes.json').read_text());argv=recipes[source]['argv'].copy()
    argv[argv.index('-c')+1]=REMOTE+'/'+source
    obj=REMOTE+'/'+tag+'-'+source.replace('/','--').replace('.cc','.o')
    argv[argv.index('-o')+1]=obj
    if '-MF' in argv:
        i=argv.index('-MF');del argv[i:i+2]
    argv=[x for x in argv if x!='-MMD']
    argv[1:1]=['-I'+REMOTE+'/include','-I'+REMOTE,'-I'+REMOTE+'/src/graph',
               '-I'+REMOTE+'/src/compute','-I'+REMOTE+'/src/compute_route_apple',
               '-I'+REMOTE+'/src/graph_route_apple']
    argv+=['-MMD','-MF',obj+'.d']
    status=prior.call(tag,argv,source=REMOTE+'/'+source,dependency=obj+'.d',outputs=[obj,obj+'.d'])
    if status==0:
        rows=json.loads((OUT/'objects.json').read_text()) if (OUT/'objects.json').exists() else {}
        rows[source]=obj;save('objects.json',rows)
    return status


def link(tag,phase):
    assert phase in {'old','current','native'}
    native=phase=='native';key='native' if native else 'gtest'
    argv=json.loads((OUT/'baseline-links.json').read_text())[key]['argv'].copy()
    owners=json.loads((OUT/'baseline-objects.json').read_text())
    objects=json.loads((OUT/'objects.json').read_text())
    if not native:
        assert argv.count(owners[TEST])==1;argv[argv.index(owners[TEST])]=objects[TEST]
    if phase!='old':
        assert all(source in objects for source in PRODUCTS)
        for source in PRODUCTS:
            old=owners.get(source);new=objects[source]
            if old:assert argv.count(old)==1;argv[argv.index(old)]=new
            else:assert source==PRODUCTS[2];argv.insert(1,new)
    stem='native-page-pending' if native else phase+'-tests'
    image=REMOTE+'/'+stem;map_path=image+'.map'
    argv[argv.index('-o')+1]=image
    argv=[('-Wl,-map,'+map_path) if x.startswith('-Wl,-map,') else x for x in argv]
    math=json.loads((OUT/'baseline-identities.json').read_text())['math'][0]['path']
    code='from pathlib import Path;r=Path('+repr(REMOTE)+');p=r/"mlx.metallib";t=Path('+repr(math)+');assert t.is_file();assert not p.exists() or p.resolve()==t.resolve();p.symlink_to(t) if not p.exists() else None'
    result=prior.air.ssh(code,timeout=30);assert result.returncode==0,result.stderr
    return prior.call(tag,argv,map=map_path,outputs=[image,map_path])


if __name__=='__main__':
    action,*args=sys.argv[1:];status=0
    if action=='inventory':inventory()
    elif action=='sync':prior.sync(args[0],args[1:])
    elif action=='compile':status=compile_source(*args)
    elif action=='link':status=link(*args)
    elif action=='run':
        tag,phase,pattern=args;result=REMOTE+'/'+tag+'-tests.json'
        status=prior.call(tag,[REMOTE+'/'+phase+'-tests','--gtest_filter='+pattern,'--gtest_output=json:'+result],outputs=[result])
    elif action=='native-run':status=prior.call(args[0],[REMOTE+'/native-page-pending'])
    elif action=='collect':prior.collect()
    else:raise ValueError(action)
    raise SystemExit(status)
