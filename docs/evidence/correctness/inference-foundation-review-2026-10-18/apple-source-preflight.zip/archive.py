from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
V = STAGE / 'validation'
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

sources = json.loads((V / 'final-source-identities.json').read_text())
assert len(sources) == 122
for entry in sources:
    for base in [ROOT, V / 'final-source']:
        actual = identity(base / entry['path'])
        assert (actual['bytes'], actual['sha256']) == (entry['bytes'], entry['sha256'])
summary = json.loads((V / 'summary.json').read_text())
assert summary['old_control']['failed'] == 2 and summary['current']['passed'] == 19 and summary['native']['exit'] == 0
assert json.loads((V / 'dependency-check.json').read_text()) == dict(matched_current=122, drift=[], unmapped=[])
save(STAGE / 'cleanup-plan.json', dict(remote_manifest=identity(V / 'cleanup-mac.json'),
                                     retained_math=summary['retained_original_mlx_math']))
result = dict(summary)
result.update(
    archive='apple-source-preflight.zip',
    defect='FIFO ordering allowed an accepted native decoder to run after copy source failure; final DependentCompletion failure only hid publication.',
    fix='Original Apple Job invokes a borrowed, fixed source predicate before resolve_inputs/evaluate. CopyStreamAccess checks every original CopyRecording under the existing observations lock, without consuming public Completion observers.',
    lifetime='Original CopyOutcomeSource fixed heap payload is retained by the existing source/suffix DependentCompletion. The Job clears its two borrowed fields before execution and any finish callback; enqueue rejection clears them too.',
    consumers='Selected row Graph uses PagedBatchAccess::submit_pending; page Graph and Direct materialized receiver select the same capability through their actual trait. Other traits keep their original submit implementation.',
    cases=[
        'A: after Graph acceptance, cancel only the original writing phase behind the FIFO gate; native copy calls=0.',
        'B: cancel phase0 that writes the pending page; independent phase1 successfully copies 4 bytes elsewhere (one native copy call). The last successful prefix cannot stand for the whole Update.',
        'Both: original physical page has valid unpublished sentinel bytes; outer Graph is Cancelled, actual selected native decoder has no result and reports Cancelled, Runtime remains healthy, failed page cannot be published.'
    ],
    interpretation='Actual native outcome probes plus source control flow establish the execution-before-read fix. This is not a hardware trace of individual GPU loads.',
    limits=[
        'No new Direct materialized late-failure injection or exhaustive cancellation interleavings.',
        'No Vulkan worker-failure claim, new Linux journey, complete-model precision or throughput acceptance.',
        'Original SDK/native host/metallib reused. Necessary original MLX tracing/JIT, metadata and native costs remain.',
        'Old leased implementation came from the identified cached SDK archive member; its current Windows source is not asserted to be its original compile source.'
    ],
    broader_goal='active and incomplete')
save(DEST / 'apple-source-preflight-results.json', result)

entries = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink() and name not in entries
    entries[name] = path

for path in STAGE.iterdir():
    if path.is_file() and path.name not in {'archive-receipt.json', 'cleanup-result.json'}:
        assert path.suffix in {'.json', '.py', '.diff'}
        add(path, path.name)
for path in (STAGE / 'before').rglob('*'):
    if path.is_file(): add(path, path.relative_to(STAGE).as_posix())
for path in V.iterdir():
    if path.is_file() and path.suffix in {'.json', '.py', '.log'}:
        add(path, path.relative_to(STAGE).as_posix())
for folder in ['results', 'final-source']:
    for path in (V / folder).rglob('*'):
        if path.is_file():
            assert path.suffix in {'.json', '.log', '.h', '.cc', '.d', '.txt'}
            add(path, path.relative_to(STAGE).as_posix())
add(ROOT / 'test.ps1', 'test.ps1')
add(DEST / 'apple-source-preflight-results.json', 'results.json')
for logical, name in [
    ('apple-row-pending/validation/run.py', 'transport/green-run.py'),
    ('apple-row-projection/validation/run.py', 'transport/prior-run.py'),
    ('apple-page-invocation/air.py', 'transport/air.py')]:
    add(STAGE.parent / logical, name)
manifest = [dict(entry=name, bytes=identity(path)['bytes'], sha256=identity(path)['sha256'])
            for name, path in sorted(entries.items())]
archive = DEST / 'apple-source-preflight.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as package:
    for name, path in sorted(entries.items()): package.write(path, name)
    package.writestr('archive-content-identities.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for item in manifest:
        data = package.read(item['entry'])
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
receipt = dict(archive=identity(archive), entries=len(manifest) + 1,
               results=identity(DEST / 'apple-source-preflight-results.json'),
               remote_cleanup_files=6, remote_cleanup_bytes=56175643,
               no_binaries_objects_or_sdk_in_archive=True)
save(STAGE / 'archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
