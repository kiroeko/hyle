from pathlib import Path
import importlib.util, json, sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
PREVIOUS=OUT.parents[1]/'apple-row-projection/validation'
spec=importlib.util.spec_from_file_location('prior_air_runner',PREVIOUS/'run.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
AIR_BASE=prior.air.REMOTE
REMOTE=AIR_BASE+'/apple-row-pending/validation'
prior.OUT=OUT;prior.REMOTE=REMOTE
BASE_LINK=json.loads((PREVIOUS/'results/019-current-link.result.json').read_text())
BASE_OBJECTS=json.loads((PREVIOUS/'objects.json').read_text())
BASE_TEST='tests/graph_route_apple/row_cache_projection_test.cc'

def save(name,data):prior.save(name,data)

def inventory():
    expected=BASE_LINK['inputs_before']
    math=json.loads((PREVIOUS/'000-baseline-identities.json').read_text())['math']
    code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
p=json.loads(sys.stdin.buffer.read());root=Path(p['root']);root.mkdir(parents=True,exist_ok=True)
def check(row):
 q=Path(row['path']);h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 actual=dict(path=str(q),bytes=q.stat().st_size,sha256=h.hexdigest());assert actual==row,(actual,row);return actual
inputs=[check(x) for x in p['inputs']];math=[check(x) for x in p['math']]
hardware={key:subprocess.check_output(argv,text=True).strip() for key,argv in {
 'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],
 'memory':['sysctl','-n','hw.memsize'],'system':['sw_vers'],'compiler':['/usr/bin/clang++','--version'],
 'space':['df','-k',str(root)]}.items()}
previous=json.loads((Path(p['prior'])/'live.json').read_text())
ps=subprocess.run(['ps','-p',str(previous['pid']),'-o','command='],capture_output=True,text=True)
old_process_live=ps.returncode==0 and (p['prior']+'/control-tests') in ps.stdout
assert previous['terminal'] and not old_process_live
result=dict(hardware=hardware,inputs=inputs,math=math,previous_terminal=previous['terminal'],previous_test_live=old_process_live)
(root/'baseline-identities.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
    result=prior.air.ssh(code,json.dumps(dict(root=REMOTE,prior=AIR_BASE+'/apple-row-projection/validation',inputs=expected,math=math)).encode(),timeout=40)
    (OUT/'000-inventory.stderr.log').write_bytes(result.stderr)
    assert result.returncode==0,result.stderr
    data=json.loads(result.stdout);save('baseline-identities.json',data)
    recipes={}
    for tag in ['007-final-test','012-context','013-mature','014-row','015-row-paged','016-operations','017-lowering','018-region']:
        row=json.loads((PREVIOUS/'results'/(tag+'.command.json')).read_text())
        source=BASE_TEST if tag=='007-final-test' else next(k for k,v in BASE_OBJECTS.items() if v==row['argv'][row['argv'].index('-o')+1])
        recipes[source]=dict(argv=row['argv'],record=str((PREVIOUS/'results'/(tag+'.command.json')).relative_to(ROOT)))
    save('recipes.json',recipes)
    owners={k:v for k,v in BASE_OBJECTS.items() if k.startswith('src/') or k==BASE_TEST}
    for obj in [x['path'] for x in expected if x['path'].endswith('.o')]:
        name=Path(obj).name
        if name.startswith('src--'):
            source='src/'+name[len('src--'):-2].replace('--','/')+'.cc'
            if (ROOT/source).is_file():owners.setdefault(source,obj)
        elif name.startswith(('graph--','graph_batch--','graph_route_')):
            source='src/'+name[:-2].replace('--','/')+'.cc'
            if (ROOT/source).is_file():owners.setdefault(source,obj)
    save('baseline-objects.json',owners)
    save('baseline-link.json',dict(argv=BASE_LINK['argv']))
    save('runner-source-identities.json',[prior.identify(PREVIOUS/'run.py'),prior.identify(OUT.parents[1]/'apple-page-invocation/air.py'),prior.identify(OUT/'run.py')])
    print(json.dumps(dict(hardware=data['hardware'],matched_inputs=len(expected),recipes=len(recipes),identified_hyle_owners=len(owners),math=math,compiled=0,tests_run=0)))

def compile_source(tag,source,*flags):
    recipes=json.loads((OUT/'recipes.json').read_text())
    selected=BASE_TEST if source.startswith('tests/') else source
    if selected in recipes:argv=recipes[selected]['argv'].copy()
    else:
        template='src/graph_route_apple/native_paged_region.cc' if source=='src/graph_route_apple/native_paged_pending.cc' else source
        code='from pathlib import Path;import json;r=Path('+repr(AIR_BASE)+');rows=json.loads((r/"commands.json").read_text());source='+repr(template)+';print(json.dumps(next(x["command"] for x in reversed(rows) if x.get("exit")==0 and x["tag"].endswith("-compile") and any(str(z).endswith("/"+source) for z in x["command"]))))'
        result=prior.air.ssh(code,timeout=30);assert result.returncode==0,result.stderr;argv=json.loads(result.stdout)
        save(tag+'-recipe.json',dict(source=source,flags_source=template,cached_argv=argv))
    argv[argv.index('-c')+1]=REMOTE+'/'+source
    obj=REMOTE+'/'+tag+'-'+source.replace('/','--').replace('.cc','.o')
    argv[argv.index('-o')+1]=obj
    if '-MF' in argv:
        i=argv.index('-MF');del argv[i:i+2]
    argv=[x for x in argv if x!='-MMD']
    argv[1:1]=['-I'+REMOTE+'/include','-I'+REMOTE,'-I'+REMOTE+'/src/graph','-I'+REMOTE+'/src/compute','-I'+REMOTE+'/src/compute_route_apple','-I'+REMOTE+'/src/graph_route_apple']
    argv[1:1]=list(flags)
    argv+=['-MMD','-MF',obj+'.d']
    status=prior.call(tag,argv,source=REMOTE+'/'+source,dependency=obj+'.d',outputs=[obj,obj+'.d'])
    if status==0:
        rows=json.loads((OUT/'objects.json').read_text()) if (OUT/'objects.json').exists() else {}
        rows[source]=obj;save('objects.json',rows)
    return status

def link(tag,test_source,*additional_tests):
    argv=json.loads((OUT/'baseline-link.json').read_text())['argv'].copy()
    owners=json.loads((OUT/'baseline-objects.json').read_text());new=json.loads((OUT/'objects.json').read_text())
    old_test=owners[BASE_TEST];assert old_test in argv and test_source in new
    argv[argv.index(old_test)]=new[test_source]
    for source in additional_tests:
        obj=new.get(source) or owners.get(source)
        assert obj and obj not in argv,(source,obj)
        argv.insert(1,obj)
    for source,obj in new.items():
        if not source.startswith('src/'):continue
        old=owners.get(source)
        if old:assert argv.count(old)==1;argv[argv.index(old)]=obj
        else:argv.insert(1,obj)
    image=REMOTE+'/row-pending-tests';map_path=image+'.map'
    argv[argv.index('-o')+1]=image
    argv=[('-Wl,-map,'+map_path) if x.startswith('-Wl,-map,') else x for x in argv]
    code='from pathlib import Path;r=Path('+repr(REMOTE)+');p=r/"mlx.metallib";target=Path('+repr(json.loads((OUT/'baseline-identities.json').read_text())['math'][0]['path'])+');assert target.is_file();assert not p.exists() or p.resolve()==target.resolve();p.symlink_to(target) if not p.exists() else None'
    result=prior.air.ssh(code,timeout=30);assert result.returncode==0,result.stderr
    return prior.call(tag,argv,map=map_path,outputs=[image,map_path])

def native_link(tag):
    argv=json.loads((OUT/'baseline-link.json').read_text())['argv'].copy()
    owners=json.loads((OUT/'baseline-objects.json').read_text());new=json.loads((OUT/'objects.json').read_text())
    old_test=owners[BASE_TEST]
    native=AIR_BASE+'/tests--compute_batch--pending_paged_receiver_native_consumer.o'
    argv[argv.index(old_test)]=native
    for source,obj in new.items():
        if not source.startswith('src/'):continue
        old=owners.get(source)
        if old:assert argv.count(old)==1;argv[argv.index(old)]=obj
        else:argv.insert(1,obj)
    image=REMOTE+'/native-page-pending';map_path=image+'.map'
    argv[argv.index('-o')+1]=image
    argv=[('-Wl,-map,'+map_path) if x.startswith('-Wl,-map,') else x for x in argv]
    return prior.call(tag,argv,map=map_path,outputs=[image,map_path])

if __name__=='__main__':
    action,*args=sys.argv[1:];status=0
    if action=='inventory':inventory()
    elif action=='sync':prior.sync(args[0],args[1:])
    elif action=='compile':status=compile_source(*args)
    elif action=='link':status=link(*args)
    elif action=='native-link':status=native_link(*args)
    elif action=='native-run':status=prior.call(args[0],[REMOTE+'/native-page-pending'])
    elif action=='run':
        tag,pattern=args;result=REMOTE+'/'+tag+'-tests.json'
        status=prior.call(tag,[REMOTE+'/row-pending-tests','--gtest_filter='+pattern,'--gtest_output=json:'+result],outputs=[result])
    elif action=='collect':prior.collect()
    else:raise ValueError(action)
    raise SystemExit(status)
