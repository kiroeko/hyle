#include <mlx/mlx.h>
#include <mlx/primitives.h>
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <typeinfo>
#include <vector>
#include "hyle/compute/apple.h"
#include "hyle/compute/detail/apple_plan.h"
#include "hyle/compute/model_ops.h"
#include <cstring>
#include <optional>
namespace c=hyle::compute;namespace a=c::apple;namespace mx=mlx::core;
mx::array ready(mx::array x){mx::async_eval({x});mx::synchronize(mx::default_stream(mx::Device::gpu));x.wait();return x;}
void check(hyle::Status s){if(!s.ok())throw std::runtime_error(std::string(s.message()));}
std::vector<float> values(mx::array x){x=ready(mx::contiguous(x,false));return {x.data<float>(),x.data<float>()+x.size()};}
std::vector<std::uint32_t> bits(mx::array x){const auto v=values(x);std::vector<std::uint32_t>b;for(auto z:v)b.push_back(std::bit_cast<std::uint32_t>(z));return b;}
float scale(int expert,int group_n,int group_k){return float((expert+1)*(group_n+1)*(group_k+1))/4096.0F;}
std::vector<float> activation(int k,int phase){std::vector<float>x(3*k);for(int t=0;t<3;++t)for(int j=0;j<k;++j)x[t*k+j]=float((j%2?224:448)*(t+1))/(phase?2.0F:1.0F);return x;}
std::vector<std::byte> weight_bytes(int e,int n,int k){const auto nb=(n+127)/128,kb=k/128;std::vector<std::byte>b(static_cast<std::size_t>(e)*(n*k+nb*kb*4));for(int ex=0;ex<e;++ex){for(int row=0;row<n;++row){const int col=(row*17+ex*7)%128;b[(ex*n+row)*k+col]=std::byte{0x38};b[(ex*n+row)*k+128+col]=std::byte{0xc0};}for(int nr=0;nr<nb;++nr)for(int kr=0;kr<kb;++kr){const auto x=scale(ex,nr,kr);std::memcpy(b.data()+e*n*k+((ex*nb+nr)*kb+kr)*4,&x,4);}}return b;}
std::vector<float> reference(std::span<const float>x,std::span<const std::int32_t>ids,int n){std::vector<float>out(ids.size()*n);for(std::size_t slot=0;slot<ids.size();++slot)for(int row=0;row<n;++row){const int ex=ids[slot],col=(row*17+ex*7)%128;const double expected=double(x[(slot/8)*256+col])*scale(ex,row/128,0)-2.0*double(x[(slot/8)*256+128+col])*scale(ex,row/128,1);out[slot*n+row]=float(expected);}return out;}
template<class T>T take(hyle::Result<T>&& r,const char*phase){if(!r)throw std::runtime_error(std::string(phase)+": "+std::string(r.error().message()));return std::move(*r);}

// Ordinary control copied from the existing d5_dynamic_fp8_fragments::projection:
// kCases[4], M3/N2048/K6144, seeds0/1, F32/non-power2, original 2e-6+rel2e-6.
constexpr std::array<float,8> lv{.5F,1,1.5F,2,-.5F,-1,-1.5F,-2};
constexpr std::array<std::uint8_t,8> lc{0x30,0x38,0x3c,0x40,0xb0,0xb8,0xbc,0xc0};
float ls(int row,int block){return float(17+(row*3+block+13)%11)/1024.0F;}
float fp8_round(float x){float best=0,error=std::numeric_limits<float>::infinity();unsigned best_code=0;for(unsigned code=0;code<127;++code){const auto exponent=code>>3,mantissa=code&7;const float value=exponent==0?std::ldexp(float(mantissa),-9):std::ldexp(1.F+float(mantissa)/8,int(exponent)-7);const float distance=std::abs(std::abs(x)-value);if(distance<error||(distance==error&&(code&1)==0&&(best_code&1))){best=value;best_code=code;error=distance;}}return std::copysign(best,x);}
void linear(a::Context&context,std::vector<std::uint32_t>&allbits){constexpr int m=3,n=2048,k=6144,kb=k/128;auto wd=take(c::float8_weight_description(k,n,c::Float8ScaleMode::kFloat32Block128),"linear weights");auto xd=take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{m,k}),"linear input");std::vector<std::byte>payload(*wd.required_bytes());for(int ng=0;ng<(n+127)/128;++ng)for(int kg=0;kg<kb;++kg){float v=ls(ng,kg);std::memcpy(payload.data()+n*k+(ng*kb+kg)*4,&v,4);}for(int row=0;row<n;++row)for(int term=0;term<2;++term){const int col=(row*17+31+term*(k/2+13))%k;payload[row*k+col]=std::byte{lc[(row+term*3)%8]};}auto w=ready(mx::array(reinterpret_cast<std::uint8_t*>(payload.data()),{int(payload.size())},mx::uint8));const std::array specs{take(a::input_spec(xd),"linear xspec"),take(a::input_spec(wd),"linear wspec")};auto p=take(context.prepare(c::model_ops::float8_block_linear(c::model_ops::Float8ScaleRounding::kNone,1e-10F),specs),"linear prepare");auto inv=take(p.create_invocation(),"linear invocation");double maxerr=0;std::size_t count=0;for(int seed:{0,1}){std::vector<float>x(m*k);for(int row=0;row<m;++row)for(int col=0;col<k;++col){const float scale=std::ldexp(1.F,int((row+col/128+seed)%4)-7);float value=lv[(row*3+col+seed)%8]*scale;if(col%128==0)value=448*scale;if(col<128)value=0;else if(col<256)value=1e-5F;x[row*k+col]=value;}std::vector<double>quant(x.size());for(std::size_t begin=0;begin<x.size();begin+=128){float maximum=1e-10F;for(int i=0;i<128;++i)maximum=std::max(maximum,std::abs(x[begin+i]));const float scale=maximum/448.F;for(int i=0;i<128;++i)quant[begin+i]=double(fp8_round(x[begin+i]/scale))*scale;}auto input=ready(mx::array(x.data(),{m,k},mx::float32));const std::array inputs{input,w};check(inv.bind(inputs));auto ticket=take(inv.submit(),"linear submit");{auto out=take(ticket.wait(),"linear wait");auto native=out.get()->arrays()[0];auto actual=values(native);for(int row=0;row<m;++row)for(int col=0;col<n;++col){double sum=0;for(int term=0;term<2;++term){const int idx=(col*17+31+term*(k/2+13))%k;sum+=quant[row*k+idx]*double(lv[(col+term*3)%8])*ls(col/128,idx/128);}const float target=float(sum);const double err=std::abs(double(actual[row*n+col])-target);maxerr=std::max(maxerr,err);if(!std::isfinite(actual[row*n+col])||err>2e-6+2e-6*std::abs(target))throw std::runtime_error("linear oracle");++count;}auto b=bits(native);allbits.insert(allbits.end(),b.begin(),b.end());}}std::printf("{\"linear_checked\":%zu,\"max_abs\":%.17g}\n",count,maxerr);}
int main(){try{
 constexpr int e=64,n=257,k=256,slots=8;
 auto context=take(a::Context::create(),"context");
 const auto wd=take(c::float8_grouped_weight_description(e,n,k),"weight description");
 const auto xd=take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,3>{3,1,k}),"activation description");
 const auto id=take(c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,2>{3,slots}),"IDs description");
 const std::array descriptions{wd,xd,id};const auto yd=take(c::infer_single_output(c::model_ops::grouped_float8_linear(),descriptions),"output description");
 auto payload=weight_bytes(e,n,k);auto w=ready(mx::array(reinterpret_cast<std::uint8_t*>(payload.data()),{int(payload.size())},mx::uint8));
 const std::array specs{take(a::input_spec(wd),"weight spec"),take(a::input_spec(xd),"activation spec"),take(a::input_spec(id),"IDs spec")};
 auto prepared=context.prepare(c::model_ops::grouped_float8_linear(),specs);if(!prepared)throw std::runtime_error(std::string(prepared.error().message()));
 auto invocation=take(prepared->create_invocation(),"invocation");std::vector<std::uint32_t> allbits;std::optional<mx::array> old;std::vector<std::uint32_t> oldbits;
 std::size_t total=0;double maxerr=0;std::vector<int> repeated_experts;
 for(int seed:{0,1}){
  auto xdata=activation(k,seed);
  const std::array<std::int32_t,24> ids=seed?std::array<std::int32_t,24>{2,2,63,3,1,9,31,0,63,63,3,1,62,0,3,9,1,63,2,62,9,2,0,63}:std::array<std::int32_t,24>{63,63,3,1,62,0,3,9,1,63,2,62,9,2,0,63,2,2,63,3,1,9,31,0};
  auto x=ready(mx::array(xdata.data(),{3,1,k},mx::float32));auto i=ready(mx::array(ids.data(),{3,slots},mx::int32));const std::array inputs{w,x,i};
  if(seed==0){
   auto census=context.compile([&](const std::vector<mx::array>&arguments,mx::Stream stream)->hyle::Result<std::vector<mx::array>>{
    auto graph=a::detail::lower_mlx_float(c::model_ops::grouped_float8_linear(),descriptions,arguments,stream);if(!graph)return std::unexpected(std::move(graph).error());
    std::set<std::uintptr_t> seen;
    std::ofstream census_out("graph-census.txt");
    const auto visit=[&](auto&& self,const mx::array&v)->void{
     if(!seen.insert(v.id()).second)return;
     if(v.has_primitive()){const auto&primitive=v.primitive();census_out<<typeid(primitive).name()<<" dtype="<<v.itemsize()<<" shape=[";for(auto d:v.shape())census_out<<d<<",";census_out<<"] inputs=";for(const auto&in:v.inputs()){census_out<<"[";for(auto d:in.shape())census_out<<d<<",";census_out<<"]";}census_out<<"\n";}
     if(v.has_primitive()&&v.dtype()==mx::float32&&v.ndim()==3&&v.shape(1)==384&&v.shape(2)==2){const auto&primitive=v.primitive();if(std::string(typeid(primitive).name()).find("Reshape")!=std::string::npos)repeated_experts.push_back(v.shape(0));}
     for(const auto&input:v.inputs())self(self,input);
    };for(const auto&output:*graph)visit(visit,output);
    return graph;
   },specs);if(!census)throw std::runtime_error(std::string(census.error().message()));
  }
  check(invocation.bind(inputs));auto submitted=invocation.submit();if(!submitted)throw std::runtime_error(std::string(submitted.error().message()));
  {
   auto result=submitted->wait();if(!result)throw std::runtime_error(std::string(result.error().message()));auto native=result->get()->arrays()[0];const auto actual=values(native);const auto expected=reference(xdata,ids,n);if(actual.size()!=*yd.element_count())throw std::runtime_error("output shape");
   for(std::size_t j=0;j<actual.size();++j){const double err=std::abs(double(actual[j])-expected[j]);maxerr=std::max(maxerr,err);if(!std::isfinite(actual[j])||err>2e-6+2e-6*std::abs(expected[j]))throw std::runtime_error("oracle");++total;}
   const auto b=bits(native);allbits.insert(allbits.end(),b.begin(),b.end());if(!old){old=native;oldbits=b;}
  }
  if(bits(*old)!=oldbits)throw std::runtime_error("old result changed");
 }
 for(std::int32_t bad:{-1,e,std::numeric_limits<std::int32_t>::max()}){
  auto xdata=activation(k,1);auto x=ready(mx::array(xdata.data(),{3,1,k},mx::float32));std::array<std::int32_t,24> ids{};ids.fill(1);ids.back()=bad;auto i=ready(mx::array(ids.data(),{3,slots},mx::int32));const std::array inputs{w,x,i};
  auto fresh=take(prepared->create_invocation(),"invocation");check(fresh.bind(inputs));auto done=fresh.submit();if(!done)throw std::runtime_error(std::string(done.error().message()));auto failed=done->wait();if(failed||!failed.error().IsOutOfRange())throw std::runtime_error("checked ID error changed");if(bits(*old)!=oldbits)throw std::runtime_error("old result changed after failure");
 }
 linear(context,allbits);
 std::ofstream raw("output.f32",std::ios::binary);raw.write(reinterpret_cast<const char*>(allbits.data()),std::streamsize(allbits.size()*sizeof(std::uint32_t)));raw.close();
 std::printf("{\"checked\":%zu,\"max_abs\":%.17g,\"invalid_cases\":3,\"old_result_preserved\":true,\"repeat_scale_expert_counts\":[",total,maxerr);for(std::size_t j=0;j<repeated_experts.size();++j)std::printf("%s%d",j?",":"",repeated_experts[j]);std::puts("]}");return 0;
}catch(const std::exception&e){std::fprintf(stderr,"%s\n",e.what());return 1;}}
