from pathlib import Path
import importlib.util,sys,json,subprocess,time,hashlib
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'inference-fusion-quantization-20261018-apple-full-fp8-carrier'
spec=importlib.util.spec_from_file_location('cache',OLD/'run_remote.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior);cache=prior.cache
FLAGS=cache.FLAGS;INC=['-I'+str(ROOT/'include'),'-I'+str(ROOT),'-I'+str(ROOT/'src/compute_route_apple'),*cache.INC];SDK=cache.SDK
records=json.loads((ROOT/'commands.json').read_text())if(ROOT/'commands.json').exists()else[]
def run(tag,command):
 command=list(map(str,command));stem=tag+'-'+str(1+sum(x['tag']==tag for x in records));start=time.monotonic();p=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=120)
 (ROOT/(stem+'.stdout.log')).write_bytes(p.stdout);(ROOT/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=command,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start));(ROOT/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-3000:],p.stderr.decode(errors='replace')[-7000:]);raise SystemExit(p.returncode)
 return p.stdout
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def build():
 assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
 (ROOT/'machine.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['xcrun','clang++','--version'],text=True))
 if not(ROOT/'mlx.metallib').exists():(ROOT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
 for file,name in [('apple_mature_float.candidate.cc','mature'),('probe.cc','probe')]:
  if not(ROOT/(name+'.o')).exists()or(ROOT/file).stat().st_mtime>(ROOT/(name+'.o')).stat().st_mtime:run(name+'-compile',['clang++',*FLAGS,*INC,'-c',ROOT/file,'-o',ROOT/(name+'.o')])
 for arm,mature in [('old',OLD/'mature.o'),('new',ROOT/'mature.o')]:
  if arm=='old'and(ROOT/'old-compare').exists():continue
  run(arm+'-link',['clang++','-O3','-std=c++23','-arch','arm64','-o',ROOT/(arm+'-compare'),ROOT/'probe.o',mature,*cache.retained,*cache.LIBS,'-Wl,-rpath,'+str(cache.TORCH),'-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore','-Wl,-map,'+str(ROOT/(arm+'.map'))])
 (ROOT/'identities.json').write_text(json.dumps([identity(p)for p in [OLD/'mature.o',ROOT/'mature.o',ROOT/'probe.o',ROOT/'old-compare',ROOT/'new-compare']],indent=2)+'\n')
def test():
 for arm in ['old','new']:
  if(ROOT/(arm+'-output.f32')).exists():continue
  run(arm+'-test',[ROOT/(arm+'-compare')]);(ROOT/'output.f32').rename(ROOT/(arm+'-output.f32'));(ROOT/'graph-census.txt').rename(ROOT/(arm+'-graph-census.txt'))
 old=(ROOT/'old-output.f32').read_bytes();new=(ROOT/'new-output.f32').read_bytes();assert old==new
 (ROOT/'comparison.json').write_text(json.dumps(dict(bytes=len(old),float_outputs=len(old)//4,all_bits_equal=True,old_sha256=hashlib.sha256(old).hexdigest(),new_sha256=hashlib.sha256(new).hexdigest()),indent=2)+'\n')
if __name__=='__main__':{'build':build,'test':test}[sys.argv[1]]()
