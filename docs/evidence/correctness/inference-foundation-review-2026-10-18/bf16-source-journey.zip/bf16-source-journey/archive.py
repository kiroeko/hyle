from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
ROOT = OUT.parents[2]
DEST = ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/bf16-source-journey.zip'
STAGES = [ARCH/name for name in ['input-source-scratch','vulkan-bf16-attention','qwen-alias-source-journey']]

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(name, value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def ident(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

host, vk, qwen = STAGES
suite=ET.parse(host/'candidate.xml').getroot()
assert suite.attrib['tests']=='4' and suite.attrib['failures']=='0'
assert read(vk/'bf16-final.json')['failures']==0
assert read(vk/'bf16-final.json')['tests']==2
assert read(vk/'resource-check.json')['pass']
assert read(qwen/'summary.json')['trace']['byte_equal']==150
pairs=read(qwen/'trace-pairs.json')
assert len(pairs)==150 and all(row['byte_equal'] for row in pairs)
for row in pairs:
    assert ident(row['prior']['path'])==row['prior']
    assert ident(row['current']['path'])==row['current']
    assert row['prior']['sha256']==row['current']['sha256']

receipts=[read(host/name) for name in ['input-sources-identity.json','frontier-test-identity.json']]
receipts += [read(vk/name) for name in ['batch-identity.json','region-identity.json',
    'cache-test-identity.json','graph-test-identity.json','native-host-identity.json']]
for row in receipts:
    assert ident(row['source']['path'])==row['source']
    assert ident(row['object']['path'])==row['object']
save('compiled-identities.json',receipts)
sources=['src/graph/input_sources.cc','src/compute_route_vulkan/vulkan_batch.cc',
    'src/compute_provider_ggml_vulkan/region.cc','tests/graph/input_source_frontier_test.cc',
    'tests/compute_route_vulkan/native_cache_test.cc','tests/graph_route_vulkan/native_region_test.cc',
    'tests/graph_route_vulkan/CMakeLists.txt','third_party/ggml_vulkan_runtime/patches.json',
    'third_party/ggml_vulkan_runtime/NOTICE.md','cmake/HyleDependencyLock.json',
    'docs/architecture/compute-design.md','docs/developer/current-work.md',
    'docs/user/vulkan-compute.md','docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md',
    'test.ps1']
for source in sources:
    target=OUT/'current'/source;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((ROOT/source).read_bytes())
save('final-source-identities.json',[ident(ROOT/source) for source in sources])
files=[ident(host/(stem+suffix)) for stem in ['control','candidate'] for suffix in ['.exe','.map','.exp','.lib']]
files += read(vk/'cleanup.json')['files']
files += read(qwen/'cleanup-identities.json')['files']
files += read(qwen/'cleanup-identities.json')['duplicate_trace_files']
assert len({row['path'] for row in files})==len(files)
for row in files: assert ident(row['path'])==row
retained=[ident(path) for stage in STAGES for path in sorted(stage.glob('*.obj'))]
save('cleanup-plan.json',dict(files=files,retained_objects=retained,
    retained_trace=[row['prior'] for row in pairs],other_cache_retained=True))
selected=[]
for path in [host/'control.map',host/'candidate.map']:
    rows=[line.rstrip() for line in path.read_text(errors='replace').splitlines()
        if line.rstrip().endswith(('input-sources.obj','graph--input_sources.obj','frontier-test.obj'))]
    assert rows
    selected += [path.name,*rows,'']
(OUT/'selected-input-source-map-owners.txt').write_text('\n'.join(selected),encoding='utf-8')
assert not DEST.exists(), 'do not overwrite frozen evidence'
exclude={'.obj','.exe','.lib','.exp','.map','.zip','.pyc','.f32','.bf16'}
paths=[path for stage in [OUT,host,qwen,ARCH/'graph-lifecycle-review/input-source-scratch-test']
    for path in sorted(stage.rglob('*')) if path.is_file() and path.suffix.lower() not in exclude]
paths += [Path(row['path']) for row in read(vk/'archive-files.json')]
paths += [vk/'receipt.json']
paths=list(dict.fromkeys(paths))
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in paths:archive.write(path,path.relative_to(ARCH).as_posix())
receipt=dict(archive=ident(DEST),source_entries=len(paths),files=len(files),
    bytes=sum(row['bytes'] for row in files),retained_objects=len(retained),retained_trace=len(pairs))
save('archive-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
