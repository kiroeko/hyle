from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(name, value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def ident(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

base = read(ARCH/'graph-lifecycle-review/alias-liveness/paged-final-link.json')
source_template = read(OUT/'compile-template.json')['command']
test_template = read(ARCH/'input-source-frontier/windows/input-source-frontier-test-identity.json')['command']
env = windows_compiler_environment({'CMAKE_CXX_COMPILER':source_template[0], 'CMAKE_C_COMPILER':source_template[0]})
env['PATH'] = os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in base['command']
    if Path(v).suffix.lower()=='.lib' and Path(v).is_file()))+os.pathsep+env['PATH']
env['VSLANG'] = '1033'

def run(tag, command, expected=0):
    rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
    stem=f'{len(rows)+1:03d}-{tag}'
    row=dict(tag=tag,command=list(map(str,command)),cwd=str(OUT),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log')
    rows.append(row); save('commands.json',rows)
    print('START',stem,flush=True); start=time.monotonic()
    with (OUT/row['stdout']).open('wb') as out, (OUT/row['stderr']).open('wb') as err:
        child=subprocess.Popen(row['command'],cwd=OUT,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=child.pid; save('commands.json',rows)
        row['exit']=child.wait(timeout=180)
    row['seconds']=time.monotonic()-start;save('commands.json',rows)
    print('END',stem,row['exit'],flush=True)
    print((OUT/row['stdout']).read_text(errors='replace')[-6500:],flush=True)
    print((OUT/row['stderr']).read_text(errors='replace')[-2200:],flush=True)
    if row['exit']!=expected:raise SystemExit(row['exit'] or 99)

def compile_source(source, template, name):
    receipt=OUT/(name+'-identity.json')
    if receipt.exists():
        old=read(receipt)
        if ident(ROOT/source)==old['source'] and ident(old['object']['path'])==old['object']:
            return
    cmd=[v for v in template if not v.lower().startswith(('/fo','/fd')) and not v.lower().endswith('.cc')]
    assert '/W4' in cmd and '/WX' in cmd
    cmd += [str(ROOT/source), '/Fo'+str(OUT/(name+'.obj'))]
    before=ident(ROOT/source);run(name+'-compile',cmd);assert ident(ROOT/source)==before
    save(name+'-identity.json',dict(source=before,object=ident(OUT/(name+'.obj')),command=cmd))

def link(mode):
    old_tests={v for s,v in base['selected_sources'].items() if s.startswith('tests/')}
    old_source=base['selected_sources']['src/graph/input_sources.cc']
    if mode=='control':
        assert ident(OUT/'input_sources.before.cc')['sha256']==base['compiled_source_sha256']['src/graph/input_sources.cc']
    command=[]
    for value in base['command']:
        if value in old_tests or value.lower().startswith(('/out:','/map:','/implib:')):continue
        if mode=='candidate' and value==old_source:value=str(OUT/'input-sources.obj')
        command.append(value)
    command.append(str(OUT/'frontier-test.obj'))
    cold=read(ARCH/'cold-placement-facts/link-plan.json')['command']
    for library in ['gtest_main.lib','gtest.lib']:
        if not any(Path(v).name.lower()==library for v in command):
            command.append(next(v for v in cold if Path(v).name.lower()==library))
    command += ['/OUT:'+str(OUT/(mode+'.exe')), '/MAP:'+str(OUT/(mode+'.map')), '/IMPLIB:'+str(OUT/(mode+'.lib'))]
    selected=dict(base['selected_sources'])
    selected={s:v for s,v in selected.items() if not s.startswith('tests/')}
    selected['tests/graph/input_source_frontier_test.cc']=str(OUT/'frontier-test.obj')
    if mode=='candidate':selected['src/graph/input_sources.cc']=str(OUT/'input-sources.obj')
    save(mode+'-link.json',dict(command=command,selected_sources=selected,
        reused_math='Original cached math is unused by these custom-host fixtures; full updated Vulkan math closure is validated separately.',
        objects=[ident(v) for v in command if Path(v).suffix.lower() in {'.lib','.obj'} and Path(v).is_file()]))
    run(mode+'-link',command)

mode=sys.argv[1]
if mode=='control':
    compile_source('tests/graph/input_source_frontier_test.cc',test_template,'frontier-test')
    link(mode)
    run('control-run',[OUT/'control.exe','--gtest_filter=InputSourceFrontier.*','--gtest_color=no',
        '--gtest_output=xml:'+str(OUT/'control.xml')],expected=1)
elif mode=='candidate':
    compile_source('src/graph/input_sources.cc',source_template,'input-sources')
    link(mode)
    run('candidate-run',[OUT/'candidate.exe','--gtest_filter=InputSourceFrontier.*','--gtest_color=no',
        '--gtest_output=xml:'+str(OUT/'candidate.xml')])
else:raise SystemExit('control or candidate required')
