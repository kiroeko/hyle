Full Qwen direct journey with alias/source fixes

001 link and 003 direct run passed. Same 24-layer consumer/inputsv2, prefill23→continuation4→decode1, next20→248046→198. All150 raw tensors match the prior frozen direct run byte for byte. trace-pairs.json records both absolute paths, byte counts and SHA256.

Reused all existing host/numeric objects and SDK libraries; replaced current Graph executable, InputSources and ggmlCUDA provider, plus already compiled faithful diagmask CU object. Zero compilation; no scheduler run or benchmark. Previous oracle ~2% logits discrepancy remains unresolved.

Archive small sources/JSON/logs only. cleanup-identities.json lists exact images/maps and duplicate new trace files; prior frozen trace and all objects remain. No files deleted/moved.
