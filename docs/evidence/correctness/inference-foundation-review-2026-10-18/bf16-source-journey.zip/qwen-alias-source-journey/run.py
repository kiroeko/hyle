from pathlib import Path
import hashlib,json,os,subprocess,sys,time
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
PRIOR=ARCH/'qwen-progress-journey'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(n,j):(OUT/n).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
def ident(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
base=read(PRIOR/'link-plan.json')
receipts=[read(ARCH/'graph-lifecycle-review/alias-liveness/graph-executable.obj.json'),read(ARCH/'input-source-scratch/input-sources-identity.json'),read(ARCH/'cuda-sdpa-mask/fresh-identities.json')[0]]
fresh=read(PRIOR/'fresh-identities.json');diag=read(ARCH/'cuda-sdpa-mask/diagmask-fresh-identity.json')
replacements={};sources=[]
lookup={r['source']['path']:r for r in receipts+fresh}
for row in base['source_objects']:
 r=lookup.get(row['source']['path'],row)
 assert ident(r['source']['path'])==r['source'],('source drift',r['source']['path'])
 assert ident(r['object']['path'])==r['object'],('object drift',r['object']['path'])
 sources.append(r)
 if r is not row:replacements[row['object']['path']]=r['object']['path']
for r in fresh:
 assert ident(r['source']['path'])==r['source'];assert ident(r['object']['path'])==r['object']
for r in base['checked_headers']:assert ident(r['path'])==r,('header drift',r['path'])
for r in base['cached_files']:assert ident(r['path'])==r,('cached input drift',r['path'])
assert ident(diag['source']['path'])==diag['source'];assert ident(diag['object']['path'])==diag['object']
args=[replacements.get(x,x) for x in base['command'] if not x.lower().startswith(('/out:','/map:','/pdb:','/implib:'))]
# Explicit original one-CU patched owner precedes the unchanged native archive.
lib_index=next(i for i,x in enumerate(args) if x.lower().endswith('ggml-cuda.lib'))
args.insert(lib_index,diag['object']['path'])
exe=OUT/'qwen-alias-source.exe'
args+=['/OUT:'+str(exe),'/MAP:'+str(OUT/'qwen-alias-source.map'),'/IMPLIB:'+str(OUT/'qwen-alias-source.lib')]
inputs=[ident(x) for x in args if x.lower().endswith(('.obj','.lib')) and Path(x).exists()]
save('link-plan.json',dict(command=args,source_objects=sources,checked_headers=base['checked_headers'],replacements=replacements,diagmask=diag,origin=str(PRIOR/'link-plan.json')))
save('link-input-identities.json',inputs)
save('consumer-identities.json',fresh)
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
compiler=fresh[0]['command'][0]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler,'CMAKE_C_COMPILER':compiler})
dirs=list(dict.fromkeys(str(Path(x).parent) for x in args if x.lower().endswith('.lib') and Path(x).is_absolute()))
env['PATH']=os.pathsep.join(dirs)+os.pathsep+env['PATH'];env['VSLANG']='1033'
save('runtime-environment.json',dict(dll_search_directories=dirs,method='all actual link .lib parent directories before inherited PATH; no SDK copies'))
def run(tag,cmd,timeout=300):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';row=dict(tag=tag,command=list(map(str,cmd)),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log');rows.append(row);save('commands.json',rows)
 print('START',stem,flush=True);t=time.monotonic()
 with (OUT/row['stdout']).open('wb') as so,(OUT/row['stderr']).open('wb') as se:r=subprocess.run(row['command'],cwd=ROOT,env=env,stdout=so,stderr=se,timeout=timeout)
 row.update(exit=r.returncode,seconds=time.monotonic()-t);save('commands.json',rows);print('END',stem,r.returncode,flush=True)
 if r.returncode:
  print((OUT/row['stdout']).read_text(errors='replace')[-4000:]);print((OUT/row['stderr']).read_text(errors='replace')[-4000:]);raise SystemExit(1)
if sys.argv[1]=='link':run('qwen-link',args)
elif sys.argv[1]=='run':
 trace=OUT/'trace-direct';assert not trace.exists(),'Never overwrite a trace'
 inp=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
 save('input-identities.json',[ident(inp/n) for n in ['input.json','weights.tsv','prompt.ids','continuation.ids']])
 run('hardware',['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'])
 run('qwen-direct',[exe,'--inputs',inp,'--continuation',inp/'continuation.ids','--steps','2','--capacity','32','--trace',trace,'--progress','direct'])
elif sys.argv[1]=='compare':
 prior=PRIOR/'trace-direct';trace=OUT/'trace-direct'
 a={p.relative_to(prior).as_posix():p for p in prior.rglob('*') if p.is_file() and p.suffix in ('.f32','.bf16')}
 b={p.relative_to(trace).as_posix():p for p in trace.rglob('*') if p.is_file() and p.suffix in ('.f32','.bf16')}
 assert len(a)==150,(len(a),len(b));assert set(a)==set(b)
 results=[]
 for key in sorted(a):
  old=a[key].read_bytes();new=b[key].read_bytes();eq=old==new
  results.append(dict(path=key,bytes=len(new),sha256=hashlib.sha256(new).hexdigest(),prior_sha256=hashlib.sha256(old).hexdigest(),equal=eq,first_different_byte=next((i for i,(x,y) in enumerate(zip(old,new)) if x!=y),None) if not eq else None))
 save('trace-comparison.json',results)
 print(json.dumps(dict(tensors=len(results),equal=sum(r['equal'] for r in results),differences=[r['path'] for r in results if not r['equal']]),indent=2))
