"""Record this narrow run; no build, execution, SDK copy, archive or deletion."""
from pathlib import Path
import difflib,hashlib,json,subprocess
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
names=[p.relative_to(OUT/'before').as_posix() for p in sorted((OUT/'before').rglob('*')) if p.is_file()]
diff=[];sources=[]
for name in names:
 src=ROOT/name;before=OUT/'before'/name;dst=OUT/'candidate'/name
 dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
 diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),src.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+name,tofile='current/'+name))
 sources.append(identity(src))
(OUT/'source.diff').write_text(''.join(diff),encoding='utf-8');write(OUT/'source-identities.json',sources)
retained=[]
for name in ['native-host','batch','region','cache-test','graph-test']:
 r=read(OUT/(name+'-identity.json'));assert r['exit']==0 and r['source_unchanged']
 assert identity(r['source']['path'])==r['source'];assert identity(r['object']['path'])==r['object']
 retained.append(r['object'])
write(OUT/'retained-objects.json',retained)
inputs=read(OUT/'matched-link-inputs.json')
for r in inputs['objects']:assert identity(r['path'])==r
paths={r['path'] for r in inputs['objects']}
inputs['selected_sources'].update({'tests/compute_route_vulkan/native_cache_test.cc':str(OUT/'cache-test.obj'),
 'tests/graph_route_vulkan/native_region_test.cc':str(OUT/'graph-test.obj')})
inputs['selected_sources']={s:p for s,p in inputs['selected_sources'].items() if p in paths}
write(OUT/'matched-link-inputs.json',inputs)
baseline=read(ROOT/'.scratch/architecture-refactor-2026-10-18/retire-native-runtime/paging-risks/matched-link-base.json')
retained_libraries=[r for r in inputs['libraries'] if 'path' in r and Path(r['path']).name in ['ggml.lib','ggml-base.lib','ggml-vulkan.lib']]
prior={r['path']:r for r in baseline.get('objects',[])}
for r in retained_libraries:assert identity(r['path'])==r
write(OUT/'native-cache-identities.json',dict(libraries=retained_libraries,
 patched_headers_shaders=read(OUT/'retained-native-header-shader-match.json'),
 lock_check=read(OUT/'resource-check.json'),shader_rebuild=False,
 explanation='Only explicit ggml-vulkan.cpp host TU compiled; unchanged original ggml-vulkan library supplies original compiled SPIR-V. All 12 other patched native files match their manifest after-SHAs.'))
first=read(OUT/'attention-tests.json');final=read(OUT/'bf16-final.json')
assert first['tests']==5 and first['failures']==1 and final['tests']==2 and final['failures']==0
records=read(OUT/'commands.json');assert records[-1]['tag']=='bf16-final-run' and records[-1]['exit']==0
device=next(t['vulkan_device'] for s in final['testsuites'] for t in s['testsuite'] if 'vulkan_device'in t)
summary=dict(status='passed_for_tested_domains',device=device,
 changes=['Paired plain BF16 cache uses original BF16 FaType reads in existing FullF32 flash.',
 'BF16 query with original Q8_0 KV follows the same F32 query/output path.',
 'Private request results and packed join stay F32; one original IREE RNE Cast creates public BF16 output.'],
 commands=dict(native_host='005',final_hyle_batch='015',hyle_region='007',cache_test='008',graph_test='012',final_link='016',final_bf16='017',old_controls='011'),
 verification=dict(final_bf16_tests=2,final_failures=0,old_f16_low_high_and_q8_tests_passed=3,
 d256_graph_fp64_max_abs=6.09797296e-5,compact_mla_576_512_graph_fp64_max_abs=.000121891445,
 plain_d256_paged_ragged=True,q8_d256_bfloat_query=True,two_slots=True,strict_same_bindings_replay=True,old_output_gate=True,
 original_spirv_rebuilt=False,native_host_unique_tus=1,hyle_product_unique_tus=2,test_unique_tus=2),
 failures_retained=[dict(command='004',reason='New fixture omitted required Direct create options argument; compile failed.'),
 dict(command='011',reason='Four mathematical cases passed; new Graph fixture Direct setup used empty options with metadata cap zero and correctly failed before Graph arithmetic. Fixed to existing 4096-byte setup contract.'),
 dict(command='005',reason='Native compile exit0 retained cached exception-option override warning D9025.')],
 limits=['Current plain KV/query dtype match and public output/query dtype match remain the selected domain; independent BatchCapacity axes have not been generalized.',
 'No pending numerical, full-model, performance or other-device acceptance.',
 'Original FP64 budgets unchanged (.008 new BF16 case; existing Direct and old controls retain their original budgets).'],
 sources=identity(OUT/'source-identities.json'),retained_objects=identity(OUT/'retained-objects.json'),matched_inputs=identity(OUT/'matched-link-inputs.json'))
write(OUT/'summary.json',summary)
images=[identity(OUT/('attention-tests'+s)) for s in ['.exe','.map','.lib','.exp']]
write(OUT/'cleanup.json',dict(root=str(ROOT),dir=str(OUT),files=images,retain=retained,
 total_files=len(images),total_bytes=sum(r['bytes'] for r in images),delete_executed=False))
check=subprocess.run(['git','diff','--check','--',*names],cwd=ROOT,capture_output=True)
(OUT/'diff-check.stdout.log').write_bytes(check.stdout);(OUT/'diff-check.stderr.log').write_bytes(check.stderr);assert check.returncode==0
write(OUT/'checks.json',dict(source_drift=0,matched_object_identities=len(inputs['objects']),native_cache_checked=True,diff_check_exit=0,
 resource_command=['cmake','-P',str(OUT/'resource-check.cmake')],image_reads_complete=True))
allowed=[]
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OUT).as_posix()
 if p.suffix.lower() not in ['.py','.json','.log','.diff','.cmake','.md','.cc','.h']:continue
 if p.name.startswith('native-host') and p.suffix=='.cpp':continue
 if rel=='archive-files.json':continue
 allowed.append(identity(p))
write(OUT/'archive-files.json',allowed)
write(OUT/'receipt.json',dict(summary=identity(OUT/'summary.json'),sources=identity(OUT/'source-identities.json'),
 objects=identity(OUT/'retained-objects.json'),cleanup=identity(OUT/'cleanup.json'),archive_files=identity(OUT/'archive-files.json'),
 cleanup_files=len(images),cleanup_bytes=sum(r['bytes'] for r in images),retained_objects=len(retained),all_writes_finished=True))
print(json.dumps(read(OUT/'receipt.json'),indent=2))
