from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
ARCH=ROOT/'.scratch/architecture-refactor-2026-10-18'
CACHE=ROOT/'.scratch/bench-api-runtime/vulkan/build'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def read(p):return json.loads(Path(p).read_text())
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def hyle_recipe(source):
 rows=read(ARCH/'native-ready-pages/windows/compile-plan.json')
 original=next((r['command'] for r in rows if r['source']==source),None)
 if original is None:
  if source.endswith('native_region_test.cc'):
   rows=read(ARCH/'native-inputs/vulkan-consumers/commands.json')
   original=next(r['command'] for r in reversed(rows) if r.get('exit')==0 and any(x.replace('\\','/').endswith(source) for x in r['command']) and any(x.startswith('/Fo') for x in r['command']))
  else:original=read(ARCH/'graph-lifecycle-review/vulkan-page-seal/leaf-final-identity.json')['command']
 flags=[x for x in original if not x.lower().endswith(('.cc','.cpp')) and not x.lower().startswith(('/fo','/fd'))]
 return flags
def native_recipe():
 row=next(r for r in read(CACHE/'compile_commands.json') if r['file'].replace('\\','/').endswith('/ggml-vulkan.cpp'))
 tokens=[x.strip('"') for x in shlex.split(row['command'],posix=False)]
 return [x for x in tokens if not x.lower().startswith(('/fo','/fd')) and x.lower() not in ['/fs','-c','/c'] and x.replace('\\','/')!=row['file'].replace('\\','/')]+['/c','/utf-8']
def run(tag,command,timeout=60):
 command=list(map(str,command));rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';row=dict(tag=tag,command=command,cwd=str(ROOT),stdout=stem+'.stdout.log',stderr=stem+'.stderr.log',exit=None)
 rows.append(row);write('commands.json',rows)
 cl=hyle_recipe('src/compute_route_vulkan/vulkan_batch.cc')[0]
 env=windows_compiler_environment({'CMAKE_CXX_COMPILER':cl,'CMAKE_C_COMPILER':cl})
 base=read(ARCH/'retire-native-runtime/paging-risks/matched-link-base.json')
 torch=next(str(Path(x).parent) for x in base['command'] if x.lower().endswith('torch_cpu.lib'))
 env['PATH']=torch+os.pathsep+str(ROOT/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']
 env['DISABLE_VULKAN_OBS_CAPTURE']='1';env['VK_LOADER_LAYERS_DISABLE']='~all~';env['VSLANG']='1033'
 start=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
 (OUT/row['stdout']).write_bytes(p.stdout);(OUT/row['stderr']).write_bytes(p.stderr)
 row.update(exit=p.returncode,seconds=time.monotonic()-start);write('commands.json',rows)
 print(stem,p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-6500:]+p.stderr.decode(errors='replace')[-6500:],flush=True)
 return p.returncode
SOURCES={'batch':'src/compute_route_vulkan/vulkan_batch.cc','region':'src/compute_provider_ggml_vulkan/region.cc',
 'cache-test':'tests/compute_route_vulkan/native_cache_test.cc','graph-test':'tests/graph_route_vulkan/native_region_test.cc'}
def compile_one(name):
 source=OUT/'native-host.cpp' if name=='native-host' else ROOT/SOURCES[name]
 flags=native_recipe() if name=='native-host' else hyle_recipe(SOURCES[name])
 before=identity(source);command=[*flags,str(source),'/Fo'+str(OUT/(name+'.obj'))]
 code=run(name+'-compile',command)
 result=dict(source=before,source_unchanged=identity(source)==before,command=command,exit=code)
 if code==0:result['object']=identity(OUT/(name+'.obj'))
 write(name+'-identity.json',result);return code
def link():
 base=read(ARCH/'retire-native-runtime/paging-risks/matched-link-base.json')
 selected=base['selected_sources'].copy()
 replacement={SOURCES[k]:str(OUT/(k+'.obj')) for k in ['batch','region']}
 for source,receipt in [('src/graph/executable.cc',ARCH/'graph-lifecycle-review/alias-liveness/graph-executable.obj.json'),
   ('src/graph_route_vulkan/native_paged_region.cc',ARCH/'graph-lifecycle-review/vulkan-page-seal/leaf-final-identity.json'),
   ('src/graph/input_sources.cc',ARCH/'input-source-scratch/input-sources-identity.json')]:
  r=read(receipt);assert identity(r['source']['path'])==r['source'];assert identity(r['object']['path'])==r['object'];replacement[source]=r['object']['path']
 old_to_new={selected[s]:p for s,p in replacement.items()};selected.update(replacement)
 old_native=str(ROOT/'.scratch/inference-feature-completion-2026-10-18/vulkan-highdim/native-host.obj')
 objects=[]
 testpaths={p for s,p in base['selected_sources'].items() if s.startswith('tests/')}
 for token in base['command'][1:]:
  if not token.lower().endswith('.obj') or token in testpaths:continue
  objects.append(str(OUT/'native-host.obj') if token==old_native else old_to_new.get(token,token))
 objects=list(dict.fromkeys(objects));assert str(OUT/'native-host.obj') in objects
 objects += [str(OUT/'cache-test.obj'),str(OUT/'graph-test.obj')]
 selected.update({SOURCES[k]:str(OUT/(k+'.obj')) for k in ['cache-test','graph-test']})
 selected={s:p for s,p in selected.items() if p in objects}
 libs=[x for x in base['command'][1:] if x.lower().endswith('.lib')]
 for stem in ['gtest','gtest_main']:
  if not any(Path(x).name.lower()==stem+'.lib' for x in libs):libs.append(str(ROOT/f'.scratch/build-compute-v2-dev/lib/{stem}.lib'))
 flags=[x for x in base['command'][1:] if not x.lower().endswith(('.obj','.lib')) and not x.upper().startswith(('/OUT:','/MAP:'))]
 command=[base['command'][0],*flags,*objects,*libs,'/OUT:'+str(OUT/'attention-tests.exe'),'/MAP:'+str(OUT/'attention-tests.map')]
 write('matched-link-inputs.json',dict(objects=[identity(p) for p in objects],libraries=[identity(p) if Path(p).is_file() else dict(system_library=p) for p in libs],selected_sources=selected,replacements=replacement))
 code=run('attention-tests-link',command)
 if not code:
  text=(OUT/'attention-tests.map').read_text(errors='replace')
  rows=[x for x in text.splitlines() if 'ggml_backend_vk_device_supports_op' in x or 'ggml_backend_vk_init' in x]
  assert rows and all('native-host' in x for x in rows),rows
  write('map-owners.json',dict(native=rows,old_native_selected=any('ggml-vulkan:ggml-vulkan.cpp.obj' in x for x in text.splitlines())))
 return code
FILTER='VulkanCache.BfloatQwenDepthKeepsCacheWordsAndFinalBfloatOutput:VulkanNativeRegion.BfloatPagedAndCompactMlaKeepOriginalSlotsAndOwners:VulkanCache.OriginalPlainCoupledUnboundedPaths:VulkanCache.PlainHighDimensionsKeepIndependentValuesAndCausalPositions:VulkanCache.Q8PagedRaggedWindowsAndIndependentValueDepth'
if __name__=='__main__':
 if sys.argv[1]=='compile':
  for name in sys.argv[2:]:
   code=compile_one(name)
   if code:raise SystemExit(code)
 elif sys.argv[1]=='link':raise SystemExit(link())
 elif sys.argv[1]=='run':
  graph_only=sys.argv[2:]==['graph'];bf16_only=sys.argv[2:]==['bf16']
  name='bf16-final' if bf16_only else ('graph-final' if graph_only else 'attention-tests')
  filter='VulkanNativeRegion.BfloatPagedAndCompactMlaKeepOriginalSlotsAndOwners' if graph_only else (':'.join(FILTER.split(':')[:2]) if bf16_only else FILTER)
  raise SystemExit(run(name+'-run',[OUT/'attention-tests.exe','--gtest_color=no','--gtest_filter='+filter,'--gtest_output=json:'+str(OUT/(name+'.json'))],120))
 else:raise SystemExit('compile native-host batch region cache-test graph-test | link | run')
