from pathlib import Path
import hashlib,json,shutil

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
RAW=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
OWNED=['src/compute_route_vulkan/vulkan_batch.cc','src/compute_provider_ggml_vulkan/region.cc',
       'third_party/ggml_vulkan_runtime/patches.json','third_party/ggml_vulkan_runtime/NOTICE.md',
       'cmake/HyleDependencyLock.json','tests/compute_route_vulkan/native_cache_test.cc',
       'tests/graph_route_vulkan/native_region_test.cc','tests/graph_route_vulkan/CMakeLists.txt']

def identity(path):
 return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())

if __name__=='__main__':
 import sys
 phase=sys.argv[1]
 if phase=='lock-values':
  base=ROOT/'third_party/ggml_vulkan_runtime'
  normalized=lambda p:p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
  text=''.join(p.relative_to(base).as_posix()+'|'+hashlib.sha256(normalized(p)).hexdigest()+'\n' for p in sorted(base.rglob('*')) if p.is_file())
  print('tree',hashlib.sha256(text.encode()).hexdigest())
  print('notice',hashlib.sha256(normalized(base/'NOTICE.md')).hexdigest())
 if phase=='before':
  for name in OWNED:
   target=OUT/'before'/name;assert not target.exists(),target
   target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
  (OUT/'before-identities.json').write_text(json.dumps([identity(ROOT/x) for x in OWNED],indent=2)+'\n')
 if phase in {'before','replay','refresh'}:
  manifest=json.loads((ROOT/'third_party/ggml_vulkan_runtime/patches.json').read_text())
  rows=[]
  for patch in manifest['files']:
   source=RAW/patch['path'];data=source.read_bytes().replace(b'\r\n',b'\n')
   assert hashlib.sha256(data).hexdigest()==patch['before_sha256'],patch['path']
   for index,edit in enumerate(patch['edits']):
    before=edit['before'].encode();after=edit['after'].encode()
    assert data.count(before)==1,(patch['path'],index,data.count(before))
    data=data.replace(before,after,1)
   sha=hashlib.sha256(data).hexdigest()
   if phase=='refresh' and patch['path']=='src/ggml-vulkan/ggml-vulkan.cpp':
    print('new native host after_sha256:',sha)
   else:
    assert sha==patch['after_sha256'],(patch['path'],sha,patch['after_sha256'])
   rows.append(dict(path=patch['path'],raw_sha256=patch['before_sha256'],sha256=sha,edits=len(patch['edits']),pass_=True))
   if patch['path']=='src/ggml-vulkan/ggml-vulkan.cpp':
    target=OUT/('native-host.before.cpp' if phase=='before' else 'native-host.cpp');target.write_bytes(data)
  (OUT/('before-manifest-replay.json' if phase=='before' else 'manifest-replay.json')).write_text(json.dumps(rows,indent=2)+'\n')
  print(phase,len(rows),'raw identities / exact contexts / resulting identities PASS; only native host source materialized')
