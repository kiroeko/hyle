from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
BUILD = Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
CACHE = BUILD / 'hyle/src/compute_ggml_runtime/source-0bae7e9e90b384d8'
UPSTREAM = Path('/Users/kiro/hyle-scratch/compute-unified/g01-original-ggml-peer')
PIN = '456172ec733a135778adcd32d00e576a58232e45'
JOBS = {
    'provider': 'src/compute_provider_ggml/ggml_cpu_provider.cc',
    'standard-index': 'src/compute_provider_ggml/standard_index.cc',
    'native-batch': 'src/compute_provider_ggml/native_batch.cc',
    'metadata': 'src/compute_ggml_runtime/metadata_arena.cc',
    'cpu-execution': 'src/compute_ggml_runtime/cpu_execution.cc',
    'cpu-program': 'src/compute_ggml_runtime/cpu_program.cc',
    'graph-context': 'src/graph_route_cpu/cpu_context.cc',
    'graph-region': 'src/graph_route_cpu/ggml_region.cc',
    'default-policy': 'src/compute_route_cpu/default_policy.cc',
    'batch': 'src/graph_batch/batch.cc',
    'row-node': 'src/graph_batch/row_cache_node.cc',
    'batch-execution': 'src/compute_batch/batch_execution.cc',
    'batch-transfer': 'src/compute/batch_transfer.cc',
    'native-ops': 'src/ggml-cpu/ops.cpp',
    'native-alloc': 'src/ggml-alloc.c',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit():
    assert subprocess.check_output(['git', '-C', UPSTREAM, 'rev-parse', 'HEAD'], text=True).strip() == PIN
    spec = importlib.util.spec_from_file_location('mixed', ROOT / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    target = ROOT / 'mixed-cpu-patches.json'
    module.derive(UPSTREAM, ROOT / 'third_party/ggml_runtime/patches.json',
                  ROOT / 'third_party/ggml_cpu_runtime/patches.json', target)
    entries, diffs = [], []
    for entry in json.loads(target.read_text())['files']:
        name = entry['path']
        raw = (UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n')
        assert hashlib.sha256(raw).hexdigest() == entry['before_sha256'], name
        patched = raw
        for edit in entry['edits']:
            before = edit['before'].encode()
            assert patched.count(before) == 1, name
            patched = patched.replace(before, edit['after'].encode(), 1)
        assert hashlib.sha256(patched).hexdigest() == entry['after_sha256'], name
        cached = (CACHE / name).read_bytes().replace(b'\r\n', b'\n')
        changed = cached != patched
        entries.append(dict(path=name, changed=changed, cached_sha256=hashlib.sha256(cached).hexdigest(),
                            current_sha256=entry['after_sha256']))
        if changed:
            diffs.extend(difflib.unified_diff(cached.decode().splitlines(True), patched.decode().splitlines(True),
                                             fromfile='cached/' + name, tofile='current/' + name))
        if name in ('src/ggml-cpu/ops.cpp', 'src/ggml-alloc.c'):
            output = ROOT / 'native' / name
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(patched)
    (ROOT / 'native-patch.diff').write_text(''.join(diffs))
    (ROOT / 'native-audit.json').write_text(json.dumps(dict(pin=PIN, cache=str(CACHE),
        upstream=str(UPSTREAM), entries=entries, mixed_manifest_sha256=sha(target)), indent=2) + '\n')
    print('changed native files:', [e['path'] for e in entries if e['changed']], flush=True)
    print('native-patch.diff', (ROOT / 'native-patch.diff').stat().st_size, flush=True)


def compile_job(name):
    source = JOBS[name]
    rows = json.loads((BUILD / 'compile_commands.json').read_text())
    native = name in ('native-ops', 'native-alloc')
    lookup = ('/' + source.removeprefix('src/')) if native else source
    if name == 'row-node':
        lookup = 'src/graph_batch/batch.cc'  # Same actual module flags; this TU is newer than the SDK.
    old = next(row for row in rows if row['file'].endswith(lookup))
    command = shlex.split(old['command'])
    # The native ABI remains this actual old-core SDK, never the CPU-only ffa pin.
    if native:
        current = ROOT / 'native' / source
    else:
        current = ROOT / source
    args, skip = [], False
    for arg in command:
        if skip:
            skip = False
            continue
        if arg in ('-o', '-c'):
            skip = True
            continue
        if arg.startswith('-DHYLE_GGML_CPU_PROVIDER_VERSION='):
            ops = sha(ROOT / 'native/src/ggml-cpu/ops.cpp')[:16]
            arg = '-DHYLE_GGML_CPU_PROVIDER_VERSION="' + PIN + '+cpu-overlay-fwht-' + ops + '"'
        args.append(arg)
    native_includes = ['-I' + str(CACHE / 'include'), '-I' + str(CACHE / 'src'),
                       '-I' + str(CACHE / 'src/ggml-cpu')]
    includes = ['-I' + str(ROOT / 'include'), '-I' + str(ROOT),
                '-I' + str(ROOT / 'src/compute'), '-I' + str(ROOT / 'src/compute_ggml_runtime'),
                '-I' + str(ROOT / 'src/compute_provider_ggml'), '-I' + str(ROOT / 'src/graph'),
                '-I' + str(ROOT / 'src/graph_route_cpu')]
    extra = ['-DHYLE_STATIC'] + ([] if name == 'batch' else ['-Werror'])
    args[1:1] = (includes + native_includes + extra) if not native else native_includes
    output = ROOT / (name + '.o')
    args += ['-c', str(current), '-o', str(output)]
    before = sha(current)
    start = time.monotonic()
    process = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (ROOT / 'live.json').write_text(json.dumps(dict(pid=process.pid, job=name, terminal=False)) + '\n')
    try:
        stdout, stderr = process.communicate(timeout=55)
        code = process.returncode
    except subprocess.TimeoutExpired:
        process.kill()
        stdout, stderr = process.communicate()
        code = 124
    records_path = ROOT / 'commands.json'
    rows = json.loads(records_path.read_text()) if records_path.exists() else []
    stem = f'{len(rows) + 1:02d}-{name}-compile'
    (ROOT / (stem + '.stdout.log')).write_bytes(stdout)
    (ROOT / (stem + '.stderr.log')).write_bytes(stderr)
    row = dict(tag=name + '-compile', command=args, cwd=str(ROOT), exit=code,
               seconds=time.monotonic() - start, stdout=stem + '.stdout.log',
               stderr=stem + '.stderr.log', flags_from=str(BUILD / 'compile_commands.json'),
               source_sha256=before, source_unchanged=before == sha(current))
    if not code:
        row['object'] = dict(path=str(output), sha256=sha(output), bytes=output.stat().st_size)
    rows.append(row)
    records_path.write_text(json.dumps(rows, indent=2) + '\n')
    (ROOT / 'live.json').write_text(json.dumps(dict(terminal=True, job=name, exit=code)) + '\n')
    print(stem, code, flush=True)
    if code:
        print(stdout.decode(errors='replace')[-4000:] + stderr.decode(errors='replace')[-5000:], flush=True)
    assert before == sha(current), 'source changed during compile'
    raise SystemExit(code)


if __name__ == '__main__':
    if sys.argv[1] == '--audit':
        audit()
    else:
        compile_job(sys.argv[1])
