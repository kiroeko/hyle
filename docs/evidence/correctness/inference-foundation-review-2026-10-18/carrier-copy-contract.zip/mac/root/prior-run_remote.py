from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
READONLY = BASE / 'architecture-refactor-20261018-apple-readonly-ports'
COLD = BASE / 'architecture-refactor-20261018-apple-cold-constants'
COMMON = BASE / 'architecture-refactor-20261018-apple-constant-replicas'
DISCOVERY = BASE / 'architecture-refactor-20261018-apple-discovery-spi'
NATIVE = BASE / 'architecture-refactor-20261018-apple-native-region'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
OLD = json.loads((READONLY / 'commands.json').read_text())
RECORDS = []


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def run(tag, command):
    command = list(map(str, command))
    stem = f'{len(RECORDS) + 1:02d}-{tag}'
    started = time.monotonic()
    with (ROOT / (stem + '.stdout.log')).open('wb') as out, (ROOT / (stem + '.stderr.log')).open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err)
        (ROOT / 'live.json').write_text(json.dumps(dict(tag=tag, pid=process.pid)) + '\n')
        try:
            code = process.wait(timeout=55)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            code = 124
    RECORDS.append(dict(tag=tag, command=command, cwd=str(ROOT), exit=code,
                        seconds=time.monotonic() - started,
                        stdout=stem + '.stdout.log', stderr=stem + '.stderr.log'))
    (ROOT / 'commands.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    (ROOT / 'live.json').write_text(json.dumps(dict(terminal=True, tag=tag, exit=code)) + '\n')
    print(stem, code, flush=True)
    if code:
        print((ROOT / (stem + '.stdout.log')).read_text(errors='replace')[-4000:], flush=True)
        print((ROOT / (stem + '.stderr.log')).read_text(errors='replace')[-7000:], flush=True)
        raise SystemExit(code)


def main():
    model = subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True).strip()
    assert model == 'Mac16,12', model
    (ROOT / 'machine.txt').write_text(subprocess.check_output(
        ['sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'], text=True)
        + subprocess.check_output(['xcrun', 'clang++', '--version'], text=True))
    for row in json.loads((ROOT / 'staged-sources.json').read_text()):
        assert identity(ROOT / row['path'])['sha256'] == row['sha256'], row['path']
    (ROOT / 'mlx.metallib').symlink_to((SDK / 'lib/mlx.metallib').resolve())
    replacement = {
        str(COMMON / 'executable.o'): ROOT / 'executable.o',
        str(COMMON / 'resources.o'): ROOT / 'resources.o',
        str(COMMON / 'region-access.o'): ROOT / 'region-access.o',
        str(COMMON / 'constant-artifact.o'): ROOT / 'constant-artifact.o',
        str(DISCOVERY / 'execution-source.o'): ROOT / 'common-source.o',
        str(DISCOVERY / 'region.o'): ROOT / 'apple-region.o',
        str(COLD / 'source.o'): ROOT / 'apple-source.o',
        str(NATIVE / 'context.o'): ROOT / 'context.o',
        str(READONLY / 'copy-recording.o'): ROOT / 'copy-recording.o',
        str(READONLY / 'copy-program.o'): ROOT / 'copy-program.o',
        str(READONLY / 'test.o'): ROOT / 'test.o',
        str(NATIVE / 'late-test.o'): ROOT / 'late-test.o',
    }
    retained = []
    for row in json.loads((READONLY / 'native-tests-identities.json').read_text()):
        path = Path(row['path'])
        if path.suffix not in {'.o', '.a', '.dylib'} or str(path) in replacement:
            continue
        actual = identity(path)
        assert actual['sha256'] == row['sha256'], path
        retained.append(actual)
    (ROOT / 'retained-identities.json').write_text(json.dumps(retained, indent=2) + '\n')
    sources = [
        ('src/graph/executable.cc', 'executable'), ('src/graph/resources.cc', 'resources'),
        ('src/graph/region_access.cc', 'region-access'), ('src/graph/constant_artifact.cc', 'constant-artifact'),
        ('src/graph/execution_source.cc', 'common-source'), ('src/graph_route_apple/native_region.cc', 'apple-region'),
        ('src/graph_route_apple/execution_source.cc', 'apple-source'), ('src/compute_route_apple/apple_context.cc', 'context'),
        ('src/compute_route_apple/apple_copy_recording.mm', 'copy-recording'),
        ('src/compute_route_apple/apple_copy_program.cc', 'copy-program'),
        ('tests/graph_route_apple/native_region_test.cc', 'test'),
        ('tests/graph_route_apple/mixed_region_test.cc', 'mixed-test'),
        ('tests/compute_route_apple/late_input_test.cc', 'late-test')]
    for source, name in sources:
        historical = 'test-compile' if source.startswith('tests/') else 'memory-compile'
        old = next(row['command'] for row in OLD if row['tag'] == historical and row['exit'] == 0)
        prefix = old[:old.index('-c')]
        prefix[1:1] = ['-I' + str(ROOT / 'include'), '-I' + str(ROOT),
                       '-I' + str(ROOT / 'src/graph'), '-I' + str(ROOT / 'src/compute'),
                       '-I' + str(ROOT / 'src/compute_route_apple'), '-I' + str(ROOT / 'src/graph_route_apple')]
        run(name + '-compile', prefix + ['-c', ROOT / source, '-o', ROOT / (name + '.o')])
    old = next(row['command'] for row in OLD if row['tag'] == 'native-tests-link' and row['exit'] == 0)
    output = ROOT / 'native-tests'
    command, seen = [], set()
    skip = False
    for arg in old:
        if skip:
            skip = False
            continue
        if arg == '-o':
            command += ['-o', str(output)]
            skip = True
            continue
        if arg.startswith('-Wl,-map,'):
            arg = '-Wl,-map,' + str(output) + '.map'
        if arg in replacement:
            seen.add(arg)
            arg = str(replacement[arg])
        command.append(arg)
    assert seen == set(replacement), (seen, set(replacement))
    command[1:1] = [str(ROOT / 'mixed-test.o')]
    run('native-tests-link', command)
    (ROOT / 'native-tests-identities.json').write_text(json.dumps(
        [identity(path) for path in command if path.endswith(('.o', '.a', '.dylib'))]
        + [identity(output), identity(str(output) + '.map')], indent=2) + '\n')
    run('native-tests', [output, '--gtest_filter=AppleNativeRegion.*:AppleLateInput.*:AppleMixedRegion.*',
                         '--gtest_color=no', '--gtest_output=json:' + str(ROOT / 'test-results.json')])


if __name__ == '__main__':
    main()
