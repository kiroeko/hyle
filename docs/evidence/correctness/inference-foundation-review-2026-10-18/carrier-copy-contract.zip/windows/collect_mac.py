from pathlib import Path
import importlib.util
import io
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-carrier-copy'
spec = importlib.util.spec_from_file_location('transport', OUT.parent / 'apple-carrier-copy/stage.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)

CODE = r'''from pathlib import Path
import hashlib,io,json,sys,tarfile
r=Path(REMOTE)
overlay=r/'cpu-overlay'
def identity(p):
 return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
rows=json.loads((r/'commands.json').read_text())
assert len(rows)>=23 and rows[21]['tag']=='native-tests-link' and rows[21]['exit']==0, rows[21]
assert rows[22]['tag']=='native-tests' and rows[22]['exit']==0, rows[22]
result=json.loads((r/'test-results.json').read_text())
assert (result['tests'],result['failures'],result['errors'])==(11,0,0),result
old=rows[16]
assert old['tag']=='native-tests' and old['exit']!=0,old
link=rows[21]['command']
linked={str(Path(arg).resolve()) for arg in link if arg.endswith(('.o','.a','.dylib')) and Path(arg).exists()}
root_objects=sorted(r.glob('*.o'))
overlay_objects=sorted(overlay.glob('*.o'))
assert len(root_objects)==13, [p.name for p in root_objects]
assert len(overlay_objects)==15, [p.name for p in overlay_objects]
assert all(str(p.resolve()) in linked for p in root_objects+overlay_objects)
binary=r/'native-tests'
for p in root_objects+overlay_objects:
 assert p.stat().st_mtime_ns<=binary.stat().st_mtime_ns, ('object newer than final executable',p)
overlay_rows=json.loads((overlay/'commands.json').read_text())
latest={row['object']['path']:row for row in overlay_rows if row['exit']==0}
for p in overlay_objects:
 actual=identity(p); row=latest[str(p)]
 assert row['object']['sha256']==actual['sha256'],p
 source=Path(row['command'][row['command'].index('-c')+1])
 assert row['source_sha256']==identity(source)['sha256'],source
cleanup=[identity(r/'native-tests'),identity(r/'native-tests.map')]
summary=dict(final_run=dict(record=23,tag=rows[22]['tag'],exit=0,tests=11,failures=0,errors=0),
 final_link=dict(record=22,exit=0), original_failed_run=dict(record=17,exit=old['exit']),
 root_objects=[identity(p) for p in root_objects],overlay_objects=[identity(p) for p in overlay_objects],
 actual_linked_objects=[identity(Path(p)) for p in sorted(linked) if Path(p).suffix=='.o'],
 final_binary=identity(binary), final_map=identity(r/'native-tests.map'),
 root_sources=[],overlay_sources=[],library_identities=[])
archive_names={}
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.py','.txt'):
  archive_names['root/'+p.name]=p
for p in overlay.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.py','.diff'):
  archive_names['cpu-overlay/'+p.name]=p
for folder,key in ((r,'root_sources'),(overlay,'overlay_sources')):
 manifest=json.loads((folder/'staged-sources.json').read_text())
 for entry in manifest:
  p=folder/entry['path']
  if not p.exists():continue
  actual=identity(p)
  summary[key].append(dict(relative=entry['path'],**actual,staged_sha256=entry['sha256'],matches_staged=actual['sha256']==entry['sha256']))
  if key=='root_sources' and entry['path'].startswith(('include/','src/','tests/')):
   archive_names['root/tested-source/'+entry['path']]=p
for name in ('src/ggml-cpu/ops.cpp','src/ggml-alloc.c'):
 archive_names['cpu-overlay/native/'+name]=overlay/'native'/name
for item in link:
 p=Path(item)
 if p.is_file() and p.suffix=='.a' and (p.name.startswith('libhyle_') or p.name.startswith('libggml')):
  if not any(x['path']==str(p) for x in summary['library_identities']):summary['library_identities'].append(identity(p))
cleanup_manifest=dict(root=str(r),action='inventory only; root test.ps1 owns deletion',files=cleanup,
 retained_root_objects=summary['root_objects'],retained_cpu_overlay_objects=summary['overlay_objects'])
(r/'archive-current-identities.json').write_text(json.dumps(summary,indent=2)+'\n')
(r/'cleanup-carrier-copy-mac.json').write_text(json.dumps(cleanup_manifest,indent=2)+'\n')
archive_names['root/archive-current-identities.json']=r/'archive-current-identities.json'
archive_names['cleanup-mac.json']=r/'cleanup-carrier-copy-mac.json'
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as a:
 for name,path in sorted(archive_names.items()):
  assert path.suffix not in ('.o','.a','.dylib','.map','.exe','.obj','.lib','.exp')
  a.add(path,arcname=name)
sys.stdout.buffer.write(b.getvalue())
'''


def main():
    data = helper.ssh('REMOTE=' + repr(REMOTE) + '\n' + CODE)
    path = OUT / 'mac-current-evidence.tar.gz'
    assert not path.exists(), path
    path.write_bytes(data)
    target = OUT / 'mac-current'
    assert not target.exists(), target
    target.mkdir()
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        assert all(member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                   for member in archive.getmembers())
        archive.extractall(target, filter='data')
    print(target, len(data), 'bytes', flush=True)


if __name__ == '__main__':
    main()
