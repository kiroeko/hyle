from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sources = [Path('src/graph/executable.cc'), Path('src/graph/plan_state.h')]

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

diff = []
for relative in sources:
    current = ROOT / relative
    target = OUT / 'candidate' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(current.read_bytes())
    before = OUT / 'before' / relative
    diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
        current.read_text(encoding='utf-8').splitlines(True),
        fromfile='before/' + relative.as_posix(), tofile=relative.as_posix()))
(OUT / 'source.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
(OUT / 'source-identities.json').write_text(json.dumps([identity(ROOT / p) for p in sources],
    indent=2) + '\n', encoding='utf-8', newline='\n')
(OUT / 'object-identities.json').write_text(json.dumps([identity(OUT / 'executable.obj')],
    indent=2) + '\n', encoding='utf-8', newline='\n')
