from pathlib import Path
import json
import os
import sys
import build

ROOT, OUT, b = build.ROOT, build.OUT, build.b
ARCH = OUT.parent
history = json.loads((ARCH / 'vulkan-constant-readback/commands.json').read_text())
if '--build' in sys.argv:
    for tag, source, name in [
            ('source-staging-compile', 'src/graph_route_vulkan/execution_source.cc', 'vulkan-source'),
            ('native-tests-staging-compile', 'tests/graph_route_vulkan/native_region_test.cc', 'vulkan-test')]:
        old = next(r['command'] for r in reversed(history) if r['tag'] == tag and r['exit'] == 0)
        args = [arg for arg in old if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]
        b.run(name + '-compile', args + [ROOT / source, '/Fo' + str(OUT / (name + '.obj'))])
records = json.loads((ARCH / 'constant-replicas/commands.json').read_text())
consumer = '--consumer' in sys.argv
tag = 'vulkan-consumer-link' if consumer else 'native-tests-link'
old = next(row['command'] for row in reversed(records) if row['tag'] == tag and row['exit'] == 0)
replacements = {
    'executable.obj': OUT / 'executable.obj', 'resources.obj': OUT / 'resources.obj',
    'region_access.obj': OUT / 'region_access.obj', 'execution_source.obj': OUT / 'execution_source.obj',
    'constant-artifact.obj': OUT / 'constant_artifact.obj',
    'graph-batch.obj': ARCH / 'port-contract-adapters/graph-batch.obj',
    'ggml_region.obj': ARCH / 'port-contract-adapters/cpu-region.obj',
    'source-staging.obj': OUT / 'vulkan-source.obj',
    'native_region.obj': ARCH / 'port-contract-adapters/vulkan-region.obj',
    'native-tests-staging.obj': OUT / 'vulkan-test.obj',
}
name = 'vulkan-consumer' if consumer else 'vulkan-tests'
command = []
for arg in old:
    if arg.upper().startswith('/OUT:'):
        command.append('/OUT:' + str(OUT / (name + '.exe')))
    elif arg.upper().startswith('/MAP:'):
        command.append('/MAP:' + str(OUT / (name + '.map')))
    else:
        command.append(str(replacements.get(Path(arg).name, arg)))
b.run(name + '-link', command)
torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
if consumer:
    b.run(name + '-run', [OUT / (name + '.exe')])
else:
    b.run(name + '-run', [OUT / (name + '.exe'), '--gtest_color=no',
        '--gtest_filter=VulkanNativeRegion.*:VulkanCopyProgram.TwoSlotsPhaseReadyOldResultsAndReplayKeepActualMetadataFixed',
        '--gtest_output=json:' + str(OUT / 'vulkan-results.json')])
