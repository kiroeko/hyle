from pathlib import Path
import difflib
import hashlib
import io
import json
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/carrier-copy-contract.zip'
FORBIDDEN = {'.obj', '.o', '.exe', '.map', '.exp', '.lib', '.a', '.dylib', '.dll', '.pdb', '.metallib', '.spv', '.vmfb'}
DOCS = ['docs/architecture/compute-design.md', 'docs/developer/current-work.md',
        'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md']
PRODUCTS = [
    'include/hyle/graph/region_provider.h',
    'src/graph/executable.cc', 'src/graph/plan_state.h', 'src/graph/resources.cc',
    'src/graph/region_access.cc', 'src/graph/constant_artifact.cc',
    'src/graph/execution_source.cc', 'src/graph/execution_source_internal.h',
    'src/graph_route_cpu/ggml_region.cc', 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
    'src/graph_provider_onednn/onednn_region_provider.cc',
    'src/graph_batch/batch.cc', 'src/graph_batch/region_adapter.h',
    'src/graph_route_vulkan/native_region.cc', 'src/graph_route_vulkan/native_region.h',
    'src/graph_route_vulkan/execution_source.cc',
    'src/graph_route_apple/native_region.cc', 'src/graph_route_apple/native_region.h',
    'src/graph_route_apple/execution_source.cc',
    'src/compute_route_apple/apple_copy_internal.h', 'src/compute_route_apple/apple_copy_recording.mm',
    'src/compute_route_apple/apple_copy_program.cc', 'src/compute_route_apple/apple_carrier.h',
    'src/compute_route_apple/apple_context.cc',
    'src/compute_route_vulkan/vulkan_memory_internal.h', 'src/compute_route_vulkan/vulkan_memory.cc',
    'src/compute_provider_ggml/ggml_cpu_provider.cc', 'src/compute_provider_ggml/native_batch.cc',
    'src/compute_provider_ggml/standard_index.cc',
    'src/compute_ggml_runtime/cpu_program.cc', 'src/compute_ggml_runtime/cpu_program_abi.h',
    'src/compute_ggml_runtime/cpu_execution.cc', 'src/compute_ggml_runtime/metadata_arena.cc',
    'src/compute_route_cpu/default_policy.cc', 'src/graph_route_cpu/cpu_context.cc',
    'src/compute_batch/batch_execution.cc', 'src/compute/batch_transfer.cc',
    'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
    'third_party/ggml_runtime/patches.json', 'third_party/ggml_cpu_runtime/patches.json',
    'tests/graph/region_provider_test.cc', 'tests/graph/constant_artifact_cache_test.cc',
    'tests/graph_route_vulkan/native_region_test.cc', 'tests/graph/route_symmetry_vulkan.cc',
    'tests/graph_route_apple/native_region_test.cc', 'tests/graph_route_apple/mixed_region_test.cc',
    'tests/compute_route_apple/late_input_test.cc',
    'src/graph_route_apple/CMakeLists.txt', 'tests/graph_route_apple/CMakeLists.txt',
]
CPU_ZIPS = ['source-results.zip', 'source-results-batch-execution-delta.zip',
            'source-results-batch-transfer-delta.zip']


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest.hexdigest())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def assert_source_archive(path):
    with zipfile.ZipFile(path) as archive:
        for entry in archive.infolist():
            assert Path(entry.filename).suffix.lower() not in FORBIDDEN, (path, entry.filename)
            if entry.filename.endswith('.tar.gz'):
                with tarfile.open(fileobj=io.BytesIO(archive.read(entry)), mode='r:gz') as nested:
                    assert all(Path(member.name).suffix.lower() not in FORBIDDEN for member in nested.getmembers())


def main():
    assert not DESTINATION.exists(), DESTINATION
    commands = json.loads((OUT / 'commands.json').read_text())
    for index, tag in ((23, 'controls-run'), (25, 'vulkan-tests-run'), (27, 'vulkan-consumer-run')):
        row = commands[index - 1]
        assert row['tag'] == tag and row['exit'] == 0, row
    controls = json.loads((OUT / 'controls-results.json').read_text())
    vulkan = json.loads((OUT / 'vulkan-results.json').read_text())
    for result in (controls, vulkan):
        assert (result['tests'], result['failures'], result['errors']) == (9, 0, 0)
    assert 'rows=1' in (OUT / commands[26]['stdout']).read_text()
    assert 'rows=4' in (OUT / commands[26]['stdout']).read_text()
    mac = json.loads((OUT / 'mac-current/root/archive-current-identities.json').read_text())
    assert mac['final_run'] == dict(record=23, tag='native-tests', exit=0, tests=11, failures=0, errors=0)
    assert len(mac['root_objects']) == 13 and len(mac['overlay_objects']) == 15
    assert not [row for row in mac['root_sources'] if not row['matches_staged']]
    mac_source = OUT / 'mac-current/root/tested-source/tests/graph_route_apple/mixed_region_test.cc'
    assert 'g::cpu::create_context' in mac_source.read_text()

    source_paths = sorted({name for name in PRODUCTS if (ROOT / name).is_file()})
    source_before = {name: identity(ROOT / name) for name in source_paths + DOCS}
    canonical_vs_mac = []
    for row in mac['root_sources'] + mac['overlay_sources']:
        path = ROOT / row['relative']
        if row['relative'].startswith(('src/', 'include/', 'tests/')) and path.is_file():
            actual = identity(path)
            assert actual['sha256'] == row['sha256'], ('canonical/tested source differs', row['relative'])
            canonical_vs_mac.append(dict(path=row['relative'], sha256=actual['sha256']))

    files = sorted(path.resolve() for path in OUT.rglob('*')
                   if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.exp', '.lib'})
    assert len(files) == 12, files
    for path in files:
        assert path.is_relative_to(OUT.resolve())
    cleanup = dict(root=str(OUT.resolve()), action='inventory only; root test.ps1 owns deletion',
                   files=[identity(path) for path in files],
                   retained_stage_objects=[identity(path) for path in sorted(OUT.glob('*.obj'))])
    write_json(OUT / 'cleanup.json', cleanup)
    cleanup_mac = json.loads((OUT / 'mac-current/cleanup-mac.json').read_text())
    assert len(cleanup_mac['files']) == 2
    assert all(Path(row['path']).name in {'native-tests', 'native-tests.map'} for row in cleanup_mac['files'])
    write_json(OUT / 'cleanup-mac.json', cleanup_mac)

    linked_objects = {}
    for number in (22, 24, 26):
        row = commands[number - 1]
        assert row['exit'] == 0
        for arg in row['command']:
            if arg.lower().endswith('.obj') and Path(arg).is_file():
                linked_objects[str(Path(arg).resolve())] = identity(Path(arg))
    write_json(OUT / 'actual-object-identities.json', dict(
        windows=list(linked_objects.values()), mac_root=mac['root_objects'], mac_cpu_overlay=mac['overlay_objects']))
    write_json(OUT / 'canonical-source-identities.json', list(source_before.values()))

    diff = subprocess.run(['git', 'diff', '--binary', '--', *source_paths], cwd=ROOT,
                          capture_output=True, check=True).stdout
    # These are full current working-tree diffs, explicitly separate from the
    # exact batch before/candidate diffs retained under history/.
    for name in source_paths:
        tracked = subprocess.run(['git', 'ls-files', '--error-unmatch', name], cwd=ROOT,
                                 capture_output=True).returncode == 0
        if not tracked:
            diff += ''.join(difflib.unified_diff([], (ROOT / name).read_text(encoding='utf-8').splitlines(True),
                fromfile='/dev/null', tofile='b/' + name)).encode()
    (OUT / 'current-scoped-working-tree.diff').write_bytes(diff)
    cpu = OUT.parent / 'apple-cpu-overlay'
    packages = []
    for name in CPU_ZIPS:
        path = cpu / name
        assert_source_archive(path)
        packages.append(identity(path))

    mac_commands = json.loads((OUT / 'mac-current/root/commands.json').read_text())
    overlay_commands = json.loads((OUT / 'mac-current/cpu-overlay/commands.json').read_text())
    summary = dict(
        scope='SPI23 per-port carrier/reference contracts, actual native-copy routes, Apple original-epoch copy, default CPU/Apple dense journey and exact replay',
        final=dict(windows_host=dict(tests=9, failures=0, record=23),
                   windows_vulkan=dict(tests=9, failures=0, record=25),
                   windows_cpu_vulkan_cpu=dict(exit=0, record=27, rows=[1, 4], replays=2),
                   mac=dict(tests=11, failures=0, record=23, link_record=22)),
        original_failures=dict(windows=[dict(record=i + 1, tag=r['tag'], exit=r['exit']) for i, r in enumerate(commands) if r['exit']],
                               mac=[dict(record=i + 1, tag=r['tag'], exit=r['exit']) for i, r in enumerate(mac_commands) if r['exit']],
                               cpu_overlay=[dict(record=i + 1, tag=r['tag'], exit=r['exit']) for i, r in enumerate(overlay_commands) if r['exit']]),
        retained_cache_counts=dict(mac_root_objects=13, mac_cpu_overlay_objects=15),
        canonical_tested_source_checks=canonical_vs_mac,
        cpu_overlay_archives=packages,
        limitations=['Dense fixed/finite geometries only; not a full-model or all-layout claim',
                     'Explicit HostWait still blocks its calling thread; no asynchronous progress implementation claimed',
                     'Legacy hybrid execution chains are not deleted by this batch',
                     'No throughput or latency benchmark was performed',
                     'CPU overlay keeps original mixed-456 ggml libraries and adds current locked ops.cpp/allocator objects; no SDK/Metal/shader rebuild'],
        history_note='Prior phase summaries and logs are retained as history. Final assertions above use the actual last Windows 23/25/27 and Mac 22/23 records. current-scoped-working-tree.diff is not a batch-only baseline.',
        docs=DOCS, cleanup_manifests=['cleanup.json', 'cleanup-mac.json'])
    write_json(OUT / 'archive-summary.json', summary)

    entries = {}
    def add(path, name):
        path = Path(path)
        assert path.suffix.lower() not in FORBIDDEN, path
        assert name not in entries, name
        entries[name] = path
    for path in OUT.iterdir():
        if path.is_file() and path.suffix.lower() in {'.py', '.json', '.log', '.diff', '.md'}:
            add(path, 'windows/' + path.name)
    for folder in ('before', 'candidate', 'output-contract-phase'):
        for path in sorted((OUT / folder).rglob('*')):
            if path.is_file() and path.suffix.lower() not in FORBIDDEN:
                add(path, 'history/root/' + path.relative_to(OUT).as_posix())
    for path in sorted((OUT / 'mac-current').rglob('*')):
        if path.is_file():
            add(path, 'mac/' + path.relative_to(OUT / 'mac-current').as_posix())
    for stage in ('apple-replay-copy', 'port-contract-adapters'):
        directory = OUT.parent / stage
        for path in sorted(directory.rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts or path.suffix.lower() in FORBIDDEN:
                continue
            if path.suffix.lower() in {'.py', '.json', '.log', '.diff', '.md', '.cc', '.h'}:
                add(path, 'history/' + stage + '/' + path.relative_to(directory).as_posix())
    for name in CPU_ZIPS:
        add(cpu / name, 'cpu-overlay-history/' + name)
    for name in source_paths:
        add(ROOT / name, 'current-product/' + name)
    for name in DOCS:
        add(ROOT / name, name)
    manifest = [dict(archive_path=name, bytes=path.stat().st_size, sha256=identity(path)['sha256'])
                for name, path in sorted(entries.items())]
    write_json(OUT / 'archive-entry-identities.json', manifest)
    add(OUT / 'archive-entry-identities.json', 'archive-entry-identities.json')
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DESTINATION, 'x', zipfile.ZIP_DEFLATED) as archive:
        for name, path in sorted(entries.items()):
            archive.write(path, name)
    assert_source_archive(DESTINATION)
    source_after = {name: identity(ROOT / name) for name in source_paths + DOCS}
    assert source_before == source_after, 'products/docs changed during archive'
    with zipfile.ZipFile(DESTINATION) as archive:
        assert archive.testzip() is None
        for row in manifest:
            assert hashlib.sha256(archive.read(row['archive_path'])).hexdigest() == row['sha256']
    receipt = dict(**identity(DESTINATION), entries=len(entries),
                   final_results=summary['final'],
                   cleanup_windows=str((OUT / 'cleanup.json').resolve()),
                   cleanup_mac=str((OUT / 'cleanup-mac.json').resolve()),
                   excluded='objects, binaries, maps, export/import libraries, native SDK and shader artifacts',
                   deleted=False)
    write_json(OUT / 'archive-receipt.json', receipt)
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
