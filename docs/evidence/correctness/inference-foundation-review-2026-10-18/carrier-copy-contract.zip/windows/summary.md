This stage changes only src/graph/executable.cc and src/graph/plan_state.h.

The cached cold region proposal now carries each output's availability and
projection contract, and each input's explicit original-reference acceptance.
Reference acceptance additionally requires the same actual Source owner; the
compiled artifact must have prepare_bindings, whose real handler still checks
the exact source artifact, port, runtime and description. This also admits the
existing shared delegated test carrier without treating every shared or native
handler as late-reference-capable.

Physical copy routing sees the description, actual nominated resource, carrier
contract and actual producer Source. Shared/raw copies require a concrete,
non-deferred Tensor view. A Tensor consumer may need a charged Caller replica
even in the same storage domain; the original producer remains available to
reference-capable consumers. The instance matrix caches the Caller replica,
while the separate producer index retains the actual original. Metadata Views
use their concrete input and keep its provenance with the real View offset.
Native fused View handling remains in the actual backend implementation.

Final compiled output contracts are checked against the exact cached proposal
using logical ValueId and the actual live output port. Immutable prepared
outputs are ready owners, not runtime native ports. Tensor projection promises
are checked when a generated output is projected; actual exported resources
are checked by the Source's real read-resource matcher.

Validation in this stage: one fresh executable.cc TU for the output contract
phase and one for the final explicit input contract, with /W4 /WX and current
SPI23 headers, both passed. The final compile is 09-executable-compile (exit0).
git diff --check passed. No linked executable, runtime test, SDK/kernel build,
performance experiment or cleanup was performed by this stage. Parent owns
the targeted runtime controls and the current native integration tests.

output-contract-phase retains the first phase source and object identity; its
large object was overwritten only after its identity and logs were retained.
candidate, source.diff, source-identities.json and object-identities.json are
the current final source/object pair. PlanState private layout changed and
its readers must be compiled with the matching current header.
