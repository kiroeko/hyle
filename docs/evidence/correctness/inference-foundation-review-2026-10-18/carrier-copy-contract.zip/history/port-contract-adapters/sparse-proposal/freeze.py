from pathlib import Path
import difflib
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
source = ROOT / 'src/graph_route_vulkan/native_region.cc'
obj = OUT.parent / 'vulkan-region.obj'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

(OUT / 'native-region.applied.cc').write_bytes(source.read_bytes())
(OUT / 'identities.json').write_text(json.dumps([identity(source), identity(obj)],
    indent=2) + '\n', encoding='utf-8', newline='\n')
(OUT / 'source.diff').write_text(''.join(difflib.unified_diff(
    (OUT / 'native-region.before.cc').read_text().splitlines(True),
    source.read_text().splitlines(True), fromfile='native-region.before.cc',
    tofile='src/graph_route_vulkan/native_region.cc')),
    encoding='utf-8', newline='\n')
