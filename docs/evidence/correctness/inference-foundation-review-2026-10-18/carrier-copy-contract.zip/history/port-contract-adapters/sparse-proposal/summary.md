Vulkan native region resource proposal now uses an allocator-backed sparse set
of mutable boundary-input ordinals and their selected View descendants. It no
longer allocates/clears graph.value_count bytes for every candidate or scans
request.constants separately for each boundary input. Cost is expected linear
in boundary inputs, selected nodes and public outputs; memory is proportional
to inserted boundary inputs and View descendants, not the whole Graph.

Logical ValueKind::kConstant is the exact stable literal criterion. Core
bind_constants requires exactly one valid literal binding for every constant.
Final region_constants includes only logical kConstant inputs. A previously
prepared NodeOutput remains an external native input despite its physical
instance's immutable role, so it does not silently change Bound to Stable.
The final actual native alias table remains the independent artifact check.

Only native_region.cc's include and resource proposal changed. Real math,
alias lowering, artifact construction and route selection are unchanged.
11-vulkan-region-compile passed /W4 /WX using cached host flags; stderr empty.
git diff --check passed. No runtime, SDK or kernel build was run here. Parent
will rerun the existing nine-item Vulkan control group with this object.
Prior source/object identity and earlier compile logs remain preserved.
