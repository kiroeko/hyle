from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

JOBS = {
    'cpu-region': ('region-discovery-spi', 'cpu-ggml-region-compile'),
    'cuda-region': ('region-discovery-spi', 'cuda-ggml-region-compile'),
    'onednn-region': ('region-discovery-spi', 'onednn-region-compile'),
    'graph-batch': ('constant-physical-owners', 'graph-batch-physical-owners-compile'),
    'vulkan-region': ('native-fragment-discovery', 'vulkan-region-compile'),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    name = sys.argv[1]
    directory, tag = JOBS[name]
    history_path = OUT.parent / directory / 'commands.json'
    history = json.loads(history_path.read_text())
    old = next(row['command'] for row in reversed(history)
               if row['tag'] == tag and row['exit'] == 0)
    command = [arg for arg in old if not arg.lower().startswith('/fo')]
    output = OUT / (name + '.obj')
    command.append('/Fo' + str(output))
    source = next(Path(arg) for arg in command if arg.endswith('.cc'))
    header = ROOT / 'include/hyle/graph/region_provider.h'
    before = {str(path): sha(path) for path in (source, header)}
    env = windows_compiler_environment(
        {'CMAKE_CXX_COMPILER': command[0], 'CMAKE_C_COMPILER': command[0]})
    env['VSLANG'] = '1033'
    records_path = OUT / 'commands.json'
    records = json.loads(records_path.read_text()) if records_path.exists() else []
    stem = f'{len(records) + 1:02d}-{name}-compile'
    print('starting', stem, 'driver_pid', os.getpid(), flush=True)
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                            timeout=55, creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / (stem + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(result.stderr)
    after = {str(path): sha(path) for path in (source, header)}
    row = dict(tag=name + '-compile', command=command, exit=result.returncode,
               seconds=time.monotonic() - start, stdout=stem + '.stdout.log',
               stderr=stem + '.stderr.log', flags_from=str(history_path),
               before=before, after=after, unchanged=before == after)
    if not result.returncode:
        row['object'] = dict(path=str(output), sha256=sha(output), size=output.stat().st_size)
    records.append(row)
    records_path.write_text(json.dumps(records, indent=2) + '\n')
    print(stem, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:])
        print(result.stderr.decode(errors='replace')[-2000:])
    if before != after:
        raise SystemExit('Source or public contract changed during compilation')
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
