"""Matched host closure for original-Invocation optional asynchronous progress."""
from pathlib import Path
import importlib.util
import sys

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
ROOT = OUT.parents[3]
ARCH = OUT.parents[1]
PRIOR = ARCH / "submission-lifetime"
spec = importlib.util.spec_from_file_location("frontier_validation", ARCH / "submission-frontier/windows/run.py")
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.OUT = OUT
driver.BASE = next(row["command"] for row in reversed(driver.read(PRIOR / "commands.json"))
                   if row["tag"] == "controls-link" and row["exit"] == 0)
driver.ABI_HEADERS = (*driver.ABI_HEADERS, "src/graph/submission_lifetime.h",
    "src/graph/progress_internal.h", "include/hyle/compute/detail/retained_completion.h")

def recipe(stage, tag):
    return next(row["command"] for row in reversed(driver.read(stage / "validation-commands.json"))
                if row["tag"] == tag and row["exit"] == 0)

def extras():
    retained = ARCH / "async-progress/retained"
    driver.compile_one("src/compute/retained_completion.cc", "retained_completion",
                       recipe(retained, "retained_completion-compile"))
    driver.compile_one("tests/compute/completion_test.cc", "completion_test",
                       recipe(retained, "completion_test-compile"))
    driver.compile_one("src/graph_progress/progress.cc", "progress", driver.CORE)
    driver.compile_one("tests/graph_progress/progress_test.cc", "progress_test", driver.TEST)

def link():
    originals = driver.BASE
    replacements = {"retained_completion.obj", "completion_test.obj"}
    extra = [OUT / "progress.obj", OUT / "progress_test.obj",
             ROOT / ".scratch/build-compute-v2-dev/bin/hyle_sched.lib",
             ROOT / ".scratch/build-compute-v2-dev/bin/hyle_mem_vm.lib"]
    if not any(Path(arg).name == "completion_test.obj" for arg in originals):
        extra.append(OUT / "completion_test.obj")
    driver.BASE = [originals[0], *map(str, extra), *(
        str(OUT / Path(arg).name) if Path(arg).name in replacements else arg
        for arg in originals[1:])]
    driver.link()

def run_tests():
    selected = driver.read(PRIOR / "summary.json")["filter"] + ":Completion.*:GraphProgress.*"
    driver.run("controls-run", [OUT / "controls.exe", "--gtest_color=no",
        "--gtest_filter=" + selected, "--gtest_output=json:" + str(OUT / "results.json")])
    result = driver.read(OUT / "results.json")
    assert not result["failures"] and not result["errors"]
    driver.save("summary.json", {"tests": result["tests"], "failures": result["failures"],
        "errors": result["errors"], "filter": selected, "fresh_host_tus": 12,
        "sdk_rebuilt": False, "scope": "original Invocation core and real native CPU asynchronous progress",
        "not_run": "macOS/Linux, full model numerical and performance comparison"})
    print(result["tests"], "tests passed", flush=True)

if __name__ == "__main__":
    {"core": driver.core, "tests": driver.tests, "extras": extras, "link": link,
     "progress": lambda: driver.compile_one("src/graph_progress/progress.cc", "progress", driver.CORE),
     "progress-test": lambda: driver.compile_one("tests/graph_progress/progress_test.cc", "progress_test", driver.TEST),
     "run": run_tests}[sys.argv[1]]()
