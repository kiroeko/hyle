"""Read-only numerical/route provenance check; never builds or runs a model."""
from pathlib import Path
import collections
import csv
import hashlib
import importlib.util
import json
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
NATIVE = OUT.parent / 'ggml-cache'
OLD = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/derived-constant-implementation'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

spec = importlib.util.spec_from_file_location('native_audit_only', NATIVE / 'build.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
old_command = json.loads((ROOT / '.scratch/perf-review-2026-10-18/ggml-attention-provider/native-overlay-compile-command.json').read_text())
old_flags = native.arguments(old_command)
new_flags = json.loads((NATIVE / 'compile-recipes.json').read_text())[0]['command']

def math_flags(arguments):
    # Include complete macro, language, host optimization and device arithmetic
    # options. Source/include/output paths have separate SHA provenance.
    return [a for a in arguments if a.startswith(('-D', '-std=', '--generate-code=',
        '-Xcompiler=', '-use_fast_math', '--fmad', '-fmad', '--ftz', '-ftz',
        '--prec-div', '--prec-sqrt', '-compress-mode=')) and '-Fd' not in a]

legacy = ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-static'
unary_command = next(x['command'] for x in json.loads((legacy / 'compile_commands.json').read_text())
                     if x['file'].replace('\\', '/').endswith('/unary.cu'))
routes = {}
for name in ('default', 'published'):
    p = OUT / 'layer0-probe-01' / (name + '-T23.route.tsv')
    rows = list(csv.DictReader(p.open(), delimiter='\t'))
    routes[name] = dict(steps=len(rows), sha256=sha(p),
        kinds=dict(collections.Counter(x['kind'] for x in rows)),
        providers=dict(collections.Counter(x['provider'] or '(metadata)' for x in rows)))
old_provider = OLD / 'census/cuda-provider.cc'
provider = old_provider.read_text().removeprefix('#include <cstdio>\n')
begin = provider.index('static void hyle_census(')
end = provider.index('\n}', begin) + 2
provider = provider[:begin] + provider[end:]
provider = '\n'.join(line for line in provider.split('\n') if 'hyle_census(' not in line)
provider = provider.replace('Queue &queue', 'detail::QueueSequence &sequence')
provider = provider.replace('cuda::stream(queue)', 'cuda::stream(sequence)')
provider = provider.replace('acquire_device_status(queue,', 'acquire_device_status(sequence,')
current_provider = (ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc').read_text()

result = dict(
    status='read_only_audit_finished_numeric_root_cause_unresolved',
    native_main=dict(old_flags=math_flags(old_flags), current_flags=math_flags(new_flags),
        arithmetic_flags_identical=math_flags(old_flags) == math_flags(new_flags),
        source_diff='old-strict-vs-current-native.diff',
        fact='Actual old strict main already includes the same F32 cuBLAS math-mode restore and MMF precision guard. Current differs only by three IQ1 supports cases, unused by this BF16/F32 consumer.',
        allocator='Recoverable allocation changes allocation failure behavior, not successful arithmetic.'),
    unary=dict(old_compile_db=str(legacy / 'compile_commands.json'),
        old_uses_fast_math='-use_fast_math' in unary_command,
        current_member='ggml-cuda-precise-unary.dir/source-f99368c68335266b/src/ggml-cuda/unary.cu.obj',
        current_recipe='src/compute_ggml_runtime/CMakeLists.txt:254-294 removes -use_fast_math from unchanged unary.cu',
        source_identical='native-kernel-source-comparison.json',
        conclusion='Confirmed numerical build-setting difference, affecting intrinsic transcendental/division/FTZ behavior. A plausible accumulation source; no A/B execution proves it accounts for the final logits difference.'),
    preparation=dict(
        provider_snapshot=str(old_provider), old_provider_snapshot_sha256=sha(old_provider),
        provider_equal_after_instrumentation_queue_protocol_and_whitespace=
            re.sub(r'\s+', '', provider) == re.sub(r'\s+', '', current_provider),
        provider_provenance_limit='The preserved census source is authenticated as that experiment, not independently as the exact original default object source. Do not elevate this to an exact binary equivalence claim.',
        provider_diff='old-census-vs-current-provider.diff',
        tensor_diff='old-vs-current-tensor.diff',
        tensor='Changes limited to IQ1 type mappings and unrelated SinkAttention score-capacity calculation.',
        consumer_diff='old-vs-current-consumer.diff',
        consumer='Default mathematics retained; changes add optional diagnostic publications/recording. Original full run had no --layer0-probe.'),
    routes=dict(current=routes,
        default_and_published_route_identical=routes['default']['sha256'] == routes['published']['sha256'],
        enum={'0':'operation', '1':'region', '2':'physical copy', '3':'zero-copy metadata View'},
        counts='1252 = 534 operations + 200 regions + 518 metadata Views; physical Plan Copy = 0.',
        probe='08-layer0-probe-prefill exit0, only T23/steps1/no continuation. Default graph compiled only; extra-publication diagnostic graph executed. Do not substitute its results for the earlier ordinary full journey.',
        old_limit='Original 998 report has no per-step route TSV. The 254-step delta cannot be assigned exactly or treated as a work/time ratio.',
        changed_discovery='src/graph/region_discovery.h:54-70 now cuts on a new external entry frontier; source change retained in region-entry-frontier/source.diff. This may change region boundaries/native fusion; it is not evidence of a tensor-binding defect.'),
    unresolved=['No proved incorrect binding or changed default mathematical graph found in this narrow source audit.',
        'Only 6/150 old/new state tensors byte-match; layer0 recurrent state differs by up to 1.1920928955078125e-7. Final logits relL2 differs 1.42-1.99% versus prior run.',
        'Native unary flags and changed region/fusion boundaries prevent attributing differences purely to architecture. No accepted numerical tolerance; matching tokens is not numerical PASS.',
        'No full journey rerun, native recompile, source change or benchmark during this follow-up audit.'],
    files=[dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(OUT.glob('old-*.diff'))]
)
assert result['native_main']['arithmetic_flags_identical']
assert result['unary']['old_uses_fast_math']
assert result['preparation']['provider_equal_after_instrumentation_queue_protocol_and_whitespace']
assert result['routes']['default_and_published_route_identical']
(OUT / 'numerical-route-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'unary', 'routes')}, indent=2))
