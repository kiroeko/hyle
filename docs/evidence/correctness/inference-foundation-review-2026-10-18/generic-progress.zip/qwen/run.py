"""Current full-Qwen handoff. Compilation is explicit; link/run require core-ready.

Only Hyle host TUs compile here. Models, old traces, numerical archives and SDKs
remain at their original read-only locations.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parents[1]
ADMITTED = ARCH / 'admitted-queue-sequence'
CORE = OUT.parent / 'windows'
NATIVE = OUT.parent / 'ggml-cache'
REFERENCE = ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows'
OLD = ROOT / '.scratch/compute-execution-refactor-2026-10-18/qwen35-ragged'
INPUT = ROOT / '.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
ORACLE = INPUT.parent / 'reference'
CORE_SOURCES = ['executable', 'submission', 'resources', 'region_access', 'constant_artifact', 'lease_submission']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def successful(stage, tag):
    return next(row for row in reversed(json.loads((stage / 'commands.json').read_text()))
                if row['tag'] == tag and row['exit'] == 0)


def environment(command=()):
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    from hyle_support import read_cache
    env = windows_compiler_environment(read_cache(ROOT / '.scratch/build-compute-v2-dev'))
    env['VSLANG'] = '1033'
    directories = [str(Path(value).parent) for value in command
                   if value.lower().endswith('.lib') and Path(value).is_absolute()]
    directories += ['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64',
                    'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',
                    str(ROOT / '.scratch/build-compute-v2-dev/bin')]
    env['PATH'] = os.pathsep.join(dict.fromkeys(directories)) + os.pathsep + env['PATH']
    return env


def run_command(tag, command, timeout=180, env=None):
    records = json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
    stem = f'{len(records)+1:02d}-' + tag
    print('START', stem, flush=True)
    started = time.monotonic()
    with (OUT/(stem+'.stdout.log')).open('wb') as stdout, (OUT/(stem+'.stderr.log')).open('wb') as stderr:
        process = subprocess.run(list(map(str, command)), cwd=ROOT, env=env or environment(),
                                 stdout=stdout, stderr=stderr, timeout=timeout)
    row = dict(tag=tag, command=list(map(str, command)), exit=process.returncode,
               seconds=time.monotonic()-started, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    records.append(row)
    save('commands.json', records)
    print('END', stem, process.returncode, row['seconds'], flush=True)
    if process.returncode:
        print((OUT/row['stdout']).read_text(errors='replace')[-10000:])
        print((OUT/row['stderr']).read_text(errors='replace')[-10000:])
        raise SystemExit(process.returncode)
    return row


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    native_audit = json.loads((NATIVE/'cache-audit.json').read_text())
    version = '456172ec+iq1-46cbf0e9-resource-' + native_audit['current_source_id']
    (OUT/'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "'+version+'"\n')
    admitted = json.loads((ADMITTED/'cuda/compile-recipes.json').read_text())
    recipes = []
    for source, name in [
        ('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc', 'ggml-provider'),
        ('src/compute_provider_ggml_cuda/tensor_program.cc', 'ggml-tensor'),
        ('src/graph_provider_ggml_cuda/ggml_cuda_region.cc', 'ggml-region'),
        ('tools/qwen35_text/main.cc', 'consumer')]:
        if name == 'consumer':
            old = successful(OLD, 'consumer-compile')['command']
            origin = str(OLD/'commands.json') + ': consumer-compile exit0'
        else:
            old = next(row['command'] for row in admitted if row['source'] == source)
            origin = str(ADMITTED/'cuda/compile-recipes.json') + ': ' + source
        command = []
        for value in old:
            low = value.lower()
            if low.startswith('/fo'):
                value = '/Fo' + str(OUT/(name+'.obj'))
            elif low.startswith('/fi') and 'provider-version.h' in low:
                value = '/FI' + str(OUT/'provider-version.h')
            elif low.startswith(('/external:i','/i')) and 'source-4e1a7b2f39afe15d' in low:
                prefix = '/external:I' if low.startswith('/external:i') else '/I'
                value = prefix + str(REFERENCE/'include')
            command.append(value)
        assert not any('source-4e1a7b2f39afe15d' in x for x in command)
        recipes.append(dict(source=source, tag=name, command=command,
                            source_sha256=sha(ROOT/source), output=str(OUT/(name+'.obj')), origin=origin))
    save('compile-recipes.json', recipes)
    save('handoff.json', dict(
        source='tools/qwen35_text/main.cc', source_sha256=sha(ROOT/'tools/qwen35_text/main.cc'),
        original_full_journey=str(OLD/'commands.json')+': full-text exit0',
        original_shapes='23/23 -> 4/27 -> 1/28, all24layers/1938nodes each phase',
        inputs=str(INPUT), oracle=str(ORACLE),
        compile='python -B '+str(OUT/'run.py')+' compile',
        link='python -B '+str(OUT/'run.py')+' link --core-ready',
        run='python -B '+str(OUT/'run.py')+' run --core-ready',
        compare='python -B '+str(OUT/'run.py')+' compare',
        must_fresh_current_plan_readers=[str(CORE/(name+'.obj')) for name in CORE_SOURCES],
        must_fresh_pending_observer=str(CORE/'retained_completion.obj'),
        unchanged_provider_contracts='Provider15 / Region24 / Batch5 / MLA3 and backend native_context.h checked against admitted source identities',
        numeric_acceptance='Compare measurements and tokens, no established tolerance; token match alone is not numerical PASS',
        remaining='Root core readiness and actual final link are explicit gates; this recipe never imports or executes old auto launchers'))
    return recipes


def compile_hosts():
    important = ['include/hyle/compute/provider.h', 'include/hyle/compute/detail/prepared_callbacks.h',
        'include/hyle/compute/detail/batch_provider.h', 'include/hyle/graph/region_provider.h',
        'include/hyle/graph/executable.h', 'src/compute/provider_internal.h',
        'src/compute_backend_cuda/native_context.h', 'src/compute_provider_ggml_cuda/tensor_program.h',
        'src/compute_provider_ggml_cuda/native_bridge.h', 'src/compute_provider_ggml_cuda/native_bridge_impl.h']
    headers = [dict(path=path, sha256=sha(ROOT/path)) for path in important]
    save('compile-header-identities-before.json', headers)
    rows = []
    for recipe in prepare():
        row = run_command(recipe['tag']+'-compile', recipe['command'])
        assert sha(ROOT/recipe['source']) == recipe['source_sha256']
        rows.append(dict(source=recipe['source'], source_sha256=recipe['source_sha256'],
                         object=recipe['output'], object_sha256=sha(recipe['output']),
                         object_bytes=Path(recipe['output']).stat().st_size,
                         command_tag=row['tag'], exit=row['exit']))
        save('fresh-host-identities.json', rows)
    after = [dict(path=path, sha256=sha(ROOT/path)) for path in important]
    save('compile-header-identities-after.json', after)
    assert headers == after, 'Hyle header changed during this compilation; do not link'


def link_plan():
    old = successful(OLD, 'consumer-link')['command']
    replacements = {
        'batch.obj': ADMITTED/'batch_execution.obj', 'graph-batch.obj': ADMITTED/'graph-batch.obj',
        'operation.obj': ADMITTED/'operation.obj', 'device.obj': ADMITTED/'device.obj',
        'graph-cuda-context.obj': ADMITTED/'cuda/graph_route_cuda--cuda_context.obj',
        'tensor-after.obj': OUT/'ggml-tensor.obj', 'cuda-provider.obj': OUT/'ggml-provider.obj',
        'cuda-region.obj': OUT/'ggml-region.obj', 'consumer.obj': OUT/'consumer.obj',
        'executable.obj': CORE/'executable.obj', 'graph-constant_artifact.obj': CORE/'constant_artifact.obj',
        'leased.obj': CORE/'resources.obj', 'graph-lease_submission.obj': CORE/'lease_submission.obj',
        'region_access.obj': CORE/'region_access.obj',
        'collectives.cu.obj': ROOT/'.scratch/inference-foundation-review-2026-10-18/cccl-device-gather/native.obj',
        'native_mla.obj': ROOT/'.scratch/inference-foundation-review-2026-10-18/cuda-ragged-mla/native_mla.obj',
        'node.obj': ROOT/'.scratch/compute-execution-refactor-2026-10-18/batch-single-invocation/row-cache-node.obj',
    }
    replaced_host_names = {'flashinfer-provider.obj', 'cublas-provider.obj', 'default-context.obj',
                           'default-policy.obj', 'best-of.obj'}
    args = [old[0]]
    dropped, substitutions = [], []
    for value in old[1:]:
        name = Path(value).name.lower()
        if value.upper().startswith(('/OUT:','/MAP:')):
            continue
        if (name in {'ggml-cuda.strict.obj','ggml.lib','ggml-cuda.lib','ggml-base.lib'} or
            name in replaced_host_names or (name.startswith('cuda-') and name.endswith('_provider.obj')) or
            'graph_route_cpu_cuda' in value.lower() or name.startswith('joint-')):
            dropped.append(value)
            continue
        if name in replacements:
            substitutions.append(dict(before=value, after=str(replacements[name])))
            value = str(replacements[name])
        args.append(value)
    # These are fresh current Provider15 owners. The source and object identity
    # are checked; ggml owners are the newly compiled COUNT67 versions instead.
    rows = json.loads((ADMITTED/'cuda/compile-status.json').read_text())
    for row in rows:
        if row['source'] in ['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
                             'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
                             'src/compute_route_cuda/weights.cc']:
            continue
        assert sha(ROOT/row['source']) == row['sha256'], row['source']
        assert sha(row['object']) == row['object_sha256'], row['object']
        args.append(row['object'])
    args += [str(CORE/'submission.obj'), str(CORE/'retained_completion.obj'),
             str(ADMITTED/'execution_source.obj'), str(ADMITTED/'transfer.obj'),
             str(ADMITTED/'command_capture.obj'),
             str(ROOT/'.scratch/architecture-refactor-2026-10-18/finite-exact/materialized.obj'),
             str(ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-graph/native-node.obj'),
             str(ROOT/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages/batch_paged_native.obj'),
             str(ROOT/'.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer/row-codec.obj'),
             str(ROOT/'.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer/indexer-kernel.obj')]
    # Explicit replacements must appear before archive scanning. Keep exactly
    # one core native set; no CPU ggml or old source-4e1 archive can enter.
    args += [str(NATIVE/'ggml-cuda.obj'), str(NATIVE/'ggml-alloc.obj')]
    args += [str(REFERENCE/'lib'/name) for name in ['ggml.lib','ggml-cuda.lib','ggml-base.lib']]
    unique = []
    seen = set()
    for value in args:
        key = value.lower()
        if key not in seen:
            seen.add(key)
            unique.append(value)
    args = unique + ['/OUT:'+str(OUT/'qwen35.exe'), '/MAP:'+str(OUT/'qwen35.map')]
    assert not any('ggml-cuda.strict.obj' in v or 'graph_route_cpu_cuda' in v.lower() for v in args)
    for name in ['ggml.lib','ggml-cuda.lib','ggml-base.lib']:
        assert [v for v in args if Path(v).name.lower() == name] == [str(REFERENCE/'lib'/name)]
    save('link-plan.json', dict(command=args, removed=dropped, replacements=substitutions,
        root_core_pending=[str(CORE/(name+'.obj')) for name in CORE_SOURCES+['retained_completion']],
        rule='Do not execute before root confirms current private ABI/core objects frozen'))
    return args


def link():
    args = link_plan()
    for value in args:
        if Path(value).suffix.lower() in {'.obj','.lib'} and Path(value).is_absolute():
            assert Path(value).is_file(), value
    save('link-identities.json', [dict(path=v, bytes=Path(v).stat().st_size, sha256=sha(v))
        for v in args if Path(v).is_file() and Path(v).suffix.lower() in {'.obj','.lib'}])
    run_command('consumer-link', args)


def model_run():
    command = successful(OUT, 'consumer-link')['command']
    prior = json.loads((OUT/'commands.json').read_text())
    trace = OUT/f'trace-{1+sum(row["tag"]=="full-text" for row in prior):02d}'
    save('candidate-run.json', dict(trace=str(trace)))
    run_command('hardware', ['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'], env=environment(command))
    run_command('full-text', [str(OUT/'qwen35.exe'), '--inputs', str(INPUT),
        '--continuation', str(INPUT/'continuation.ids'), '--steps','2','--capacity','32',
        '--trace',str(trace)], timeout=600, env=environment(command))


def compare():
    import numpy as np
    reference = json.loads((ORACLE/'reference.json').read_text())
    trace = Path(json.loads((OUT/'candidate-run.json').read_text())['trace'])
    result = successful(OUT,'full-text')
    candidate_result = json.loads((OUT/result['stdout']).read_text().strip())
    stderr = (OUT/result['stderr']).read_text()
    next_ids = {name:int(token) for name,token in re.findall(
        r'^(prefill|continuation|decode\d+) tokens=.*? next=(\d+)$',stderr,re.MULTILINE)}

    def values(path):
        if path.suffix == '.bf16':
            return (np.fromfile(path,dtype='<u2').astype('<u4')<<16).view('<f4').astype(np.float64)
        return np.fromfile(path,dtype='<f4').astype(np.float64)

    rows = []
    for step in reference['steps']:
        name = step['name']
        for source in sorted((ORACLE/name).iterdir()):
            path = trace/name/source.name
            assert path.is_file(), path
            expected, actual = values(source), values(path)
            tail = np.empty(0)
            if source.name.endswith(('.key.bf16','.value.bf16')):
                assert actual.size >= expected.size
                tail, actual = actual[expected.size:], actual[:expected.size]
            else:
                assert actual.size == expected.size
            delta = actual-expected
            den = float(np.linalg.norm(expected))
            rows.append(dict(phase=name,tensor=source.name,elements=int(actual.size),
                finite=bool(np.isfinite(actual).all() and np.isfinite(expected).all()),
                max_abs=float(np.max(np.abs(delta))),mean_abs=float(np.mean(np.abs(delta))),
                relative_l2=float(np.linalg.norm(delta)/den) if den else float(np.linalg.norm(delta)),
                equal_elements=int(np.count_nonzero(actual==expected)),inactive_kv_elements=int(tail.size),
                inactive_kv_all_zero=bool(np.all(tail==0)),candidate_sha256=sha(path),reference_sha256=sha(source)))
    report = dict(kind='full_24_layer_measurements_no_inferred_tolerance',
        oracle_script_origin=str(OLD/'compare.py'),oracle_script_sha256=sha(OLD/'compare.py'),
        reference_source_id=reference['source_id'],reference_generated_ids=reference['generated_ids'],
        candidate_result=candidate_result,generated_ids_equal=candidate_result['generated_ids']==reference['generated_ids'],
        phase_next_ids=next_ids,phase_next_ids_equal=all(next_ids[x['name']]==x['next_id'] for x in reference['steps']),
        all_finite=all(x['finite'] for x in rows),all_inactive_kv_zero=all(x['inactive_kv_all_zero'] for x in rows),tensors=rows)
    save('comparison.json', report)
    print(json.dumps({k:v for k,v in report.items() if k!='tensors'},indent=2))
    for row in rows:
        if row['tensor'] in {'hidden.bf16','logits.f32'}:
            print(json.dumps(row))


def compare_prior():
    import numpy as np
    trace = Path(json.loads((OUT/'candidate-run.json').read_text())['trace'])
    old_trace = OLD/'trace-01'

    def values(path):
        if path.suffix == '.bf16':
            return (np.fromfile(path,dtype='<u2').astype('<u4')<<16).view('<f4').astype(np.float64)
        return np.fromfile(path,dtype='<f4').astype(np.float64)

    rows = []
    for phase in ['prefill','continuation','decode1']:
        for path in sorted((trace/phase).iterdir()):
            previous = old_trace/phase/path.name
            assert previous.is_file(),previous
            actual, expected = values(path),values(previous)
            assert actual.shape == expected.shape
            delta = actual-expected
            den = float(np.linalg.norm(expected))
            rows.append(dict(phase=phase,tensor=path.name,elements=int(actual.size),
                byte_equal=sha(path)==sha(previous),
                max_abs=float(np.max(np.abs(delta))),
                relative_l2=float(np.linalg.norm(delta)/den) if den else float(np.linalg.norm(delta)),
                current_sha256=sha(path),prior_sha256=sha(previous)))
    report = dict(kind='current_vs_prior_trace_measurements_not_a_numerical_acceptance_test',
        current_trace=str(trace),prior_trace=str(old_trace),tensors=len(rows),
        byte_equal_tensors=sum(row['byte_equal']for row in rows),measurements=rows)
    save('comparison-prior-trace.json',report)
    print(json.dumps({k:v for k,v in report.items()if k!='measurements'},indent=2))
    for row in rows:
        if row['tensor']in {'hidden.bf16','logits.f32','layer0.conv.bf16','layer0.gdn.f32','layer1.conv.bf16'}:
            print(json.dumps(row))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode',choices=['plan','compile','link','run','compare','compare-prior'])
    parser.add_argument('--core-ready',action='store_true')
    args = parser.parse_args()
    if args.mode in {'link','run'} and not args.core_ready:
        parser.error('Root must explicitly confirm its current core ABI/object freeze; pass --core-ready only after that signal')
    if args.mode=='plan':
        prepare();link_plan();print('PLAN ONLY',OUT)
    elif args.mode=='compile':compile_hosts()
    elif args.mode=='link':link()
    elif args.mode=='run':model_run()
    elif args.mode=='compare':compare()
    else:compare_prior()
