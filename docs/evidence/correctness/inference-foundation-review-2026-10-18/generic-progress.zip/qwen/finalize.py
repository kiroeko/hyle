from pathlib import Path
import hashlib
import json
import re

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
CORE=OUT.parent/'windows'
OLD=ROOT/'.scratch/compute-execution-refactor-2026-10-18/qwen35-ragged'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


commands=json.loads((OUT/'commands.json').read_text())
assert len(commands)==8 and all(row['exit']==0 for row in commands)
assert commands[-1]['tag']=='layer0-probe-prefill'
audit=json.loads((OUT/'numerical-route-audit.json').read_text())
assert audit['native_main']['arithmetic_flags_identical']
assert audit['routes']['default_and_published_route_identical']
fresh=json.loads((OUT/'fresh-host-identities.json').read_text())
for row in fresh:
    assert sha(ROOT/row['source'])==row['source_sha256']
    assert sha(Path(row['object']))==row['object_sha256']
linked=json.loads((OUT/'link-identities.json').read_text())
for row in linked:
    assert sha(Path(row['path']))==row['sha256'],row['path']
core_commands=json.loads((CORE/'commands.json').read_text())
core_receipts=[]
for name in ['executable','submission','resources','region_access','constant_artifact','lease_submission','retained_completion']:
    row=next(row for row in reversed(core_commands)if row['tag']==name+'-compile'and row['exit']==0)
    assert row['unchanged'] and row['before']==row['after']
    actual=next(item for item in row['objects']if Path(item['path']).name==name+'.obj')
    assert sha(Path(actual['path']))==actual['sha256']
    assert next(item['sha256']for item in linked if item['path']==actual['path'])==actual['sha256']
    for source in row['after']:
        source_path=Path(source['path'])
        if sha(source_path)!=source['sha256']:
            # Root's announced post-build change adds comments only. Keep the
            # actual compiled snapshot identity and prove token equivalence.
            assert source_path.name=='submission_lifetime.h',source['path']
            compiled=CORE/'source-snapshots'/source['sha256']/source_path.name
            assert sha(compiled)==source['sha256']
            tokens=lambda text:re.sub(r'\s+','',re.sub(r'//[^\n]*','',text))
            assert tokens(compiled.read_text())==tokens(source_path.read_text())
            save('post-build-comment-only.json',dict(path=source['path'],
                compiled_sha256=source['sha256'],current_sha256=sha(source_path),
                compiled_snapshot=str(compiled),noncomment_tokens_identical=True))
    core_receipts.append(dict(tag=row['tag'],object=actual,sources=row['after']))
save('matched-core-identities.json',core_receipts)
sources=[dict(path=row['source'],bytes=(ROOT/row['source']).stat().st_size,sha256=row['source_sha256'])for row in fresh]
for name in ['run.py','finalize.py','audit.py','provider-version.h']:
    sources.append(dict(path=str((OUT/name).relative_to(ROOT)),bytes=(OUT/name).stat().st_size,sha256=sha(OUT/name)))
save('source-identities.json',sources)
candidate=OUT/'candidate'
for row in fresh:
    destination=candidate/row['source']
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((ROOT/row['source']).read_bytes())
originals=json.loads((OLD/'trace-identities.json').read_text())
assert len(originals)==150
for row in originals:
    assert sha(ROOT/row['path'])==row['sha256'],row['path']
trace=Path(json.loads((OUT/'candidate-run.json').read_text())['trace'])
trace_rows=[dict(path=str(path.relative_to(ROOT)),bytes=path.stat().st_size,sha256=sha(path))
    for phase in ['prefill','continuation','decode1']for path in sorted((trace/phase).iterdir())]
assert len(trace_rows)==150
save('trace-identities.json',trace_rows)
comparison=json.loads((OUT/'comparison.json').read_text())
prior=json.loads((OUT/'comparison-prior-trace.json').read_text())
assert len(comparison['tensors'])==150 and comparison['all_finite'] and comparison['all_inactive_kv_zero']
assert comparison['generated_ids_equal'] and comparison['phase_next_ids_equal']
run=next(row for row in commands if row['tag']=='full-text')
stderr=(OUT/run['stderr']).read_text()
phases=[dict(query=int(q),steps=int(steps),workspace_per_slot=int(workspace))
    for q,steps,workspace in re.findall(r'^compiled T=(\d+) steps=(\d+) workspace/slot=(\d+)',stderr,re.MULTILINE)]
assert len(phases)==3
maptext=(OUT/'qwen35.map').read_text(errors='replace')
assert 'ggml-cuda.lib:ggml-cuda.cu.obj'not in maptext and 'ggml-base.lib:ggml-alloc.c.obj'not in maptext
evidence=[line for line in maptext.splitlines()if len(parts:=line.split())>1 and
    (parts[1].startswith('?root_stream@bridge@')or parts[1]=='ggml_gallocr_new')]
assert len(evidence)==2 and any('ggml-cuda.obj'in line for line in evidence)and any('ggml-alloc.obj'in line for line in evidence)
(OUT/'native-member-map-excerpt.txt').write_text('\n'.join(evidence)+'\n')
save('cleanup-candidates.json',[dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
    for suffix in ['exe','map','exp','lib']if(path:=OUT/('qwen35.'+suffix)).exists()])
save('retained-objects.json',[dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
    for path in sorted(OUT.glob('*.obj'))])
summary_path=OUT/'summary.json'
initial_path=OUT/'summary-before-audit.json'
if not initial_path.exists():
    initial_path.write_bytes(summary_path.read_bytes())
save('summary.json',dict(
    status='complete_current_default_cuda_journey_token_match_numeric_acceptance_unresolved',
    hardware=(OUT/'06-hardware.stdout.log').read_text().strip(),
    source='tools/qwen35_text/main.cc',source_sha256=sha(ROOT/'tools/qwen35_text/main.cc'),
    fresh_host='4/4 actual current Hyle provider/region/tensor/consumer; /W4 /WX; exact IQ1 COUNT67 header',
    current_native='Sibling ggml-cache: current main+recoverable allocator explicit objects before the single audited reference native archive set',
    core='Six root generic-progress/windows current private-ABI readers plus current retained_completion; every compiled source/object receipt matched',
    actual_run=dict(command=run['command'],exit=run['exit'],process_seconds=run['seconds'],phases=phases,
        layers=24,nodes_each_phase=1938,weight_tensors=320,resident_weight_bytes=3763655360,
        query_kv=[[23,23],[4,27],[1,28]],next_ids=comparison['phase_next_ids'],generated_ids=[248046,198]),
    oracle=dict(tensor_count=150,all_finite=True,inactive_kv_tail_zero=True,tokens_match=True,
        metrics=[row for row in comparison['tensors']if row['tensor']in ['hidden.bf16','logits.f32']],
        acceptance='No established tolerance; these measurements are not a numerical PASS'),
    prior_trace=dict(path=str(OLD/'trace-01'),original_150_receipts_match=True,
        byte_equal_tensors=prior['byte_equal_tensors'],total=prior['tensors'],
        layer0_gdn_max_abs=max(row['max_abs']for row in prior['measurements']if row['tensor']=='layer0.gdn.f32'),
        logits_relative_l2=[row['relative_l2']for row in prior['measurements']if row['tensor']=='logits.f32']),
    followup_audit=dict(path='numerical-route-audit.json',sha256=sha(OUT/'numerical-route-audit.json'),
        probe=commands[-1],
        report='T23 default and published routes byte-identical: 534 operations + 200 regions + 518 metadata Views = 1252; physical Plan Copy zero',
        numerical_setting='Actual old strict main and new main have identical arithmetic flags/precision guards; old unary fast-math vs canonical precise-unary differs',
        conclusion='No proved misbinding found. Unary flags and region entry-frontier/fusion changes remain candidates, not a proved explanation for final logits differences'),
    limits=[
        'Current total report steps1252 differs from prior998. One permitted follow-up T23 probe supplies current default route TSV; original998 has none, so do not infer extra math or a throughput regression from total steps',
        'Probe compiled the default graph then executed its nine-extra-publication diagnostic graph; routes identical, workspace different. It is not a second ordinary full journey or a native A/B experiment',
        'One three-phase traced journey only; no warm/repeat benchmark or deterministic same-shape repeat claim',
        'Consumer uses ordinary Invocation submit, without prepare_progress: this validates current core/native integration, not model execution through the optional scheduler adapter',
        'Layer0/1 conv traces match prior bytes; later differences and larger independent-reference relative errors have no established root cause',
        'No product source edits, model/SDK/library copying, cleanup or numerical-kernel rebuild in this Hyle host/model stage'],
    preserved='Old traces, inputs/model and original native libraries remain read-only; new trace only under this stage',
    native_link_proof='native-member-map-excerpt.txt; no old main/allocator archive member extracted',
    artifacts='Source snapshots, commands/logs, exact source/core/object/library identities, comparison JSON; raw150 traces remain local'))
print(json.dumps(dict(summary=str(OUT/'summary.json'),sha256=sha(OUT/'summary.json'),
    images=json.loads((OUT/'cleanup-candidates.json').read_text()),retained_local_objects=len(fresh)),indent=2))
